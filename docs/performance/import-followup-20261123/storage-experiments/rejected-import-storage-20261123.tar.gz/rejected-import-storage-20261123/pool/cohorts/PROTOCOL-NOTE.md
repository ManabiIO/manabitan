# Preserved diagnostics and corrected Jitendex protocol

The original `pair-*-*.json` cohort used the full Jitendex term contents with a
`null` compression dictionary. Production resolves the locked Jitendex title to
`jmdict`, using its trained dictionary and compression level -1. The original
cohort also instrumented candidate buffer acquisition inside the timed packing
path. Its allocation counts describe that diagnostic workload; its elapsed
times do not rank the production Jitendex component.

The separate `diagnostic-*-*.json` two-pair cohort removed instrumentation but
retained the incorrect null dictionary. Those receipts are preserved unchanged
and also do not rank the production Jitendex component.

`run-jitendex.mjs` corrects codec selection using the locked expected title and
the production resolver outside timing, asserts dictionary `jmdict` and level
-1, records source and codec resource hashes, and disables allocation and worker
counter instrumentation. It uses the unchanged candidate c38459dcd and baseline
46706765, with a fixed 32 MiB / 32-buffer pool limit. Its prescribed cohort is
four fresh AB/BA pairs. Persisted-byte hashing occurs after the timer. Fixed
10-bank component grouping, Node worker threads, and the memory-backed content
store are explicit limits; this is not a browser or full-import benchmark.
