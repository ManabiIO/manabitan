import fs from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {Worker as NodeWorker} from 'node:worker_threads'
import {pathToFileURL} from 'node:url'
import {execFileSync} from 'node:child_process'
import path from 'node:path'

const [root, prepared, output] = process.argv.slice(2)
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const sources = ['ext/js/dictionary/term-content-block-store.js', 'ext/js/dictionary/zstd-term-content.js', 'ext/js/dictionary/zstd-term-content-compression-worker.js', 'ext/js/dictionary/term-content-buffer-pool.js']
const sourceHashes = {}
for (const file of sources) {
    try { sourceHashes[file] = hash(await fs.readFile(path.join(root, file))) }
    catch (error) { if (error.code !== 'ENOENT') throw error; sourceHashes[file] = null }
}
const manifest = JSON.parse(await fs.readFile(path.join(prepared, 'manifest.json'), 'utf8'))
const groups = []
for (const group of manifest.groups) {
    const bytes = {}
    for (const [kind, file] of Object.entries(group.files)) {
        const raw = await fs.readFile(path.join(prepared, file))
        if (hash(raw) !== group.hashes[kind]) throw new Error(`Changed prepared ${file}`)
        bytes[kind] = new Uint8Array(raw)
    }
    groups.push({source: bytes.source,
        offsets: new Uint32Array(bytes.offsets.buffer), lengths: new Uint32Array(bytes.lengths.buffer)})
}
const workers = []
let stats = {}
const resetStats = () => {
    stats = {packedLogicalBytes: 0, packedChunks: 0, allocatedCapacityBytes: 0, allocatedBuffers: 0,
        reusedLogicalBytes: 0, reusedCapacityBytes: 0, reusedBuffers: 0, retainedPeakCapacityBytes: 0,
        returnedBuffers: 0, returnedCapacityBytes: 0, transferredBuffers: 0, transferredLogicalBytes: 0,
        transferredCapacityBytes: 0, sourceConsumedMessages: 0}
}
resetStats()
class CompressionWorker {
    constructor(url) {
        this.listeners = new Map()
        this.worker = new NodeWorker(new URL('./node-compression-worker.mjs', import.meta.url), {workerData: {url: url.href}})
        workers.push(this)
        this.worker.on('message', (data) => {
            if (data.inputBuffer instanceof ArrayBuffer) {
                stats.returnedBuffers++
                stats.returnedCapacityBytes += data.inputBuffer.byteLength
            }
            if (data.type === 'source-consumed') stats.sourceConsumedMessages++
            this.emit('message', {data})
        })
        this.worker.on('error', (error) => this.emit('error', {message: error.message}))
        this.worker.on('messageerror', () => this.emit('messageerror', {}))
    }
    addEventListener(type, listener) {
        this.listeners.set(type, (this.listeners.get(type) ?? new Set()).add(listener))
    }
    removeEventListener(type, listener) { this.listeners.get(type)?.delete(listener) }
    emit(type, event) { for (const listener of this.listeners.get(type) ?? []) listener(event) }
    postMessage(message, transfer = []) {
        if (message.content instanceof Uint8Array && transfer.includes(message.content.buffer)) {
            stats.transferredBuffers++
            stats.transferredLogicalBytes += message.content.byteLength
            stats.transferredCapacityBytes += message.content.buffer.byteLength
        }
        this.worker.postMessage(message, transfer)
    }
    terminate() { return this.worker.terminate() }
}
globalThis.Worker = CompressionWorker
globalThis.fetch = async (input) => {
    const url = new URL(String(input), pathToFileURL(path.join(root, 'ext/')))
    if (url.protocol !== 'file:') throw new Error(`Unexpected resource ${url}`)
    return new Response(await fs.readFile(url), {headers: {'Content-Type': 'application/wasm'}})
}
const {TermContentBlockStore} = await import(pathToFileURL(path.join(root, sources[0])))
const {TermContentOpfsStore} = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-content-opfs-store.js')))
const codec = await import(pathToFileURL(path.join(root, sources[1])))
await codec.initializeTermContentZstd()
let recycling = false
if (sourceHashes[sources[3]] !== null) {
    recycling = true
    const {TermContentBufferPool} = await import(pathToFileURL(path.join(root, sources[3])))
    const acquire = TermContentBufferPool.prototype.acquire
    const release = TermContentBufferPool.prototype.release
    TermContentBufferPool.prototype.acquire = function (length) {
        const previous = [...this._buffers]
        const output = acquire.call(this, length)
        if (previous.includes(output.buffer)) {
            stats.reusedBuffers++
            stats.reusedLogicalBytes += length
            stats.reusedCapacityBytes += output.buffer.byteLength
        } else {
            stats.allocatedBuffers++
            stats.allocatedCapacityBytes += output.buffer.byteLength
        }
        return output
    }
    TermContentBufferPool.prototype.release = function (buffer) {
        release.call(this, buffer)
        stats.retainedPeakCapacityBytes = Math.max(stats.retainedPeakCapacityBytes, this._bytes)
    }
}
const appendPacked = TermContentBlockStore.prototype._tryAppendPacked
TermContentBlockStore.prototype._tryAppendPacked = function (pack, ...args) {
    return appendPacked.call(this, () => {
        const packed = pack()
        for (const bytes of packed.packedChunks) {
            stats.packedChunks++
            stats.packedLogicalBytes += bytes.byteLength
            if (!recycling) {
                stats.allocatedBuffers++
                stats.allocatedCapacityBytes += bytes.buffer.byteLength
            }
        }
        return packed
    }, ...args)
}
async function execute(verify) {
    resetStats()
    const content = new TermContentOpfsStore()
    const blocks = new TermContentBlockStore(content, {blockTargetBytes: 1024 * 1024})
    const session = blocks.beginImportSession()
    const phases = {packMs: 0, compressMs: 0, envelopeMs: 0, referenceMs: 0, opfsAppendMs: 0}
    let compressedBytes = 0
    let storedContents = 0
    const started = performance.now()
    try {
        for (const group of groups) {
            const result = await session.appendSpans('jitendex.org', group.source, group.offsets, group.lengths, null)
            if (result === null) throw new Error('Block storage rejected real Jitendex content')
            for (const key of Object.keys(phases)) phases[key] += result[key]
            compressedBytes += result.compressedBytes
            storedContents += result.contentOffsets.length
        }
    } finally { session.close() }
    const elapsedMs = performance.now() - started
    const operationStats = {...stats}
    const outputBytes = content._length
    const persistedSha256 = verify ? hash(await content.readSlice(0, outputBytes)) : null
    return {elapsedMs, phases, compressedBytes, storedContents, outputBytes, persistedSha256, operationStats}
}
await execute(false)
globalThis.gc?.()
const result = await execute(true)
for (const file of sources) {
    if (sourceHashes[file] !== null && sourceHashes[file] !== hash(await fs.readFile(path.join(root, file)))) throw new Error(`Source changed: ${file}`)
}
const report = {...result, sourceRoot: root, sourceHashes, sourceCommit: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim(),
    archiveSha256: manifest.archiveSha256, inputDigest: manifest.inputDigest, sourceJsonBytes: manifest.sourceJsonBytes,
    sourceBytes: manifest.sourceBytes, selectedBytes: manifest.selectedBytes, rows: manifest.rows, selectedContents: manifest.selectedContents,
    groups: groups.length, node: process.version, workers: workers.length,
    scope: 'Packing, real Zstd in four Node worker_threads using actual worker entry points, references, and memory-backed TermContentOpfsStore; excludes parser, dedup, record/index writes, media, browser OPFS, import finalization',
    runnerSha256: hash(await fs.readFile(new URL(import.meta.url))), recycling}
await Promise.all(workers.map((worker) => worker.terminate()))
await fs.writeFile(output, `${JSON.stringify(report, null, 2)}\n`)
console.log(JSON.stringify(report))
