"""Run the preserved byte-only proof with paths rewritten into a fresh directory."""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--prepared', type=Path, required=True)
parser.add_argument('--repository', type=Path, required=True)
parser.add_argument('--zstd-source', type=Path, required=True)
parser.add_argument('--library', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
original_root = Path(__file__).resolve().parent
original = original_root / 'prove.py'
code = original.read_text()
replacements = {
    'ROOT = pathlib.Path(__file__).resolve().parent': args.output,
    "PREPARED = SCRATCH / 'content-recycle-screen' / 'prepared'": args.prepared,
    "REPOSITORY = SCRATCH / 'manabitan-next'": args.repository,
    "PINNED = pathlib.Path('/workspace/scratch/f34c9c9fae89/zstd-pinned-audit')": args.zstd_source,
    "LIBRARY = SCRATCH / 'zstd-cdict-proof-lib.so'": args.library
}
for old, value in replacements.items():
    assert code.count(old) == 1, f'Unexpected preserved source: {old}'
    name = old.split(' = ', 1)[0]
    code = code.replace(old, f'{name} = pathlib.Path({str(value.resolve())!r})', 1)
args.output.mkdir(parents=True, exist_ok=False)
derived = args.output / 'prove-with-local-paths.py'
derived.write_text(code)
shutil.copyfile(original_root / 'PROTOCOL.md', args.output / 'PROTOCOL.md')
digest = lambda data: hashlib.sha256(data).hexdigest()
provenance = {
    'originalProofSha256': digest(original.read_bytes()),
    'launcherSha256': digest(Path(__file__).read_bytes()),
    'derivedProofSha256': digest(derived.read_bytes()),
    'change': 'Five filesystem path constants only; proof logic unchanged',
    'paths': {name: str(value.resolve()) for name, value in vars(args).items()}
}
(args.output / 'reproduction-provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
with (args.output / 'result.log').open('wb') as output:
    result = subprocess.run([sys.executable, str(derived)], stdout=output, stderr=subprocess.STDOUT)
print((args.output / 'result.log').read_text())
sys.exit(result.returncode)
