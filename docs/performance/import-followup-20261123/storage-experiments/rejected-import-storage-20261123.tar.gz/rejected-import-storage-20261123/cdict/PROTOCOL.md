# Pinned native CDict byte-equivalence proof

Frozen before execution on 2026-11-23.

Hypothesis: reuse an advanced Zstd CDict keyed by every field in the complete `ZSTD_getCParams(-1, blockLength, dictionaryLength)` tuple, while preserving every compressed frame byte produced by `ZSTD_compress_usingDict`.

Source is Manabitan's pinned Zstd commit `82d322c4973d9e2968d94047a40892bc6d9a9bdf`, amalgamated with its own single-file generator and compiled with native GCC `-O3 -DNDEBUG -fPIC -shared`. This is a native feasibility proof, not WASM or browser qualification.

Input is the previously prepared complete Jitendex corpus: 22 fixed groups, 363,243 selected contents, 389,687,485 selected bytes, input digest `bb4a7ffc8a206dd7b4bff985cc35c697deb14b98ebafdc00f96c3b11622b3d93`. Every prepared source and span metadata hash is checked. The production 1,048,576-byte target and existing per-group block splitting are unchanged, producing exactly 382 blocks. The same checked-in 16 KiB JMdict dictionary and production level -1 are used by both arms.

Baseline uses one reused CCtx and `ZSTD_compress_usingDict`. Candidate uses a separate reused CCtx and `ZSTD_compress_usingCDict`, with `ZSTD_createCDict_advanced` in by-reference/automatic-content mode and a cache indexed by all seven compression-parameter fields. The retained dictionary bytes outlive every cached CDict. Frames are compared by length and every byte. Both outputs are decoded against the original block as a harness sanity check.

This invocation contains no timing measurement. Any differing frame rejects the candidate. Completing the remaining byte checks after a mismatch only quantifies the mismatch; it cannot authorize timing or a runtime implementation. Only a complete 382-frame match would allow a separately specified native kernel timing comparison, followed by toolchain and browser feasibility review. No compression level, block size, parser behavior, runtime source, or rejected pool code changes are included.
