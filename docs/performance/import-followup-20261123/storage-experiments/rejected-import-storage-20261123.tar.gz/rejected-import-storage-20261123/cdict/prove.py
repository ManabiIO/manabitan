import ctypes
import hashlib
import json
import pathlib
import struct
import subprocess
import sys


ROOT = pathlib.Path(__file__).resolve().parent
SCRATCH = ROOT.parent
PREPARED = SCRATCH / 'content-recycle-screen' / 'prepared'
REPOSITORY = SCRATCH / 'manabitan-next'
PINNED = pathlib.Path('/workspace/scratch/f34c9c9fae89/zstd-pinned-audit')
LIBRARY = SCRATCH / 'zstd-cdict-proof-lib.so'
DICTIONARY = REPOSITORY / 'ext/lib/zstd-dicts/jmdict.zdict'
BLOCK_TARGET = 1048576
LEVEL = -1
EXPECTED_COMMIT = '82d322c4973d9e2968d94047a40892bc6d9a9bdf'
EXPECTED_INPUT = 'bb4a7ffc8a206dd7b4bff985cc35c697deb14b98ebafdc00f96c3b11622b3d93'


def sha256(data):
    return hashlib.sha256(data).hexdigest()


class CompressionParameters(ctypes.Structure):
    _fields_ = [(name, ctypes.c_uint) for name in (
        'windowLog', 'chainLog', 'hashLog', 'searchLog', 'minMatch',
        'targetLength', 'strategy'
    )]

    def key(self):
        return tuple(getattr(self, name) for name, _ in self._fields_)

    def record(self):
        return {name: getattr(self, name) for name, _ in self._fields_}


class CustomMemory(ctypes.Structure):
    _fields_ = [
        ('customAlloc', ctypes.c_void_p),
        ('customFree', ctypes.c_void_p),
        ('opaque', ctypes.c_void_p)
    ]


library = ctypes.CDLL(str(LIBRARY))


def bind(name, result, arguments):
    function = getattr(library, name)
    function.restype = result
    function.argtypes = arguments
    return function


pointer = ctypes.c_void_p
size = ctypes.c_size_t
create_cctx = bind('ZSTD_createCCtx', pointer, [])
free_cctx = bind('ZSTD_freeCCtx', size, [pointer])
create_dctx = bind('ZSTD_createDCtx', pointer, [])
free_dctx = bind('ZSTD_freeDCtx', size, [pointer])
get_params = bind('ZSTD_getCParams', CompressionParameters,
                  [ctypes.c_int, ctypes.c_ulonglong, size])
get_cdict_params = bind('ZSTD_getCParamsFromCDict', CompressionParameters, [pointer])
create_cdict = bind('ZSTD_createCDict_advanced', pointer,
                    [pointer, size, ctypes.c_int, ctypes.c_int,
                     CompressionParameters, CustomMemory])
free_cdict = bind('ZSTD_freeCDict', size, [pointer])
sizeof_cdict = bind('ZSTD_sizeof_CDict', size, [pointer])
compress_bound = bind('ZSTD_compressBound', size, [size])
using_dict = bind('ZSTD_compress_usingDict', size,
                 [pointer, pointer, size, pointer, size, pointer, size, ctypes.c_int])
using_cdict = bind('ZSTD_compress_usingCDict', size,
                  [pointer, pointer, size, pointer, size, pointer])
decompress = bind('ZSTD_decompress_usingDict', size,
                  [pointer, pointer, size, pointer, size, pointer, size])
is_error = bind('ZSTD_isError', ctypes.c_uint, [size])
error_name = bind('ZSTD_getErrorName', ctypes.c_char_p, [size])
version = bind('ZSTD_versionString', ctypes.c_char_p, [])


def checked(result):
    if is_error(result):
        raise RuntimeError(error_name(result).decode())
    return result


manifest_bytes = (PREPARED / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
assert manifest['inputDigest'] == EXPECTED_INPUT
assert manifest['selectedContents'] == 363243
assert manifest['selectedBytes'] == 389687485
assert len(manifest['groups']) == 22
source_commit = subprocess.check_output(
    ['git', '-C', str(PINNED), 'rev-parse', 'HEAD'], text=True
).strip()
assert source_commit == EXPECTED_COMMIT
dictionary = DICTIONARY.read_bytes()
assert len(dictionary) == 16384
dictionary_buffer = ctypes.create_string_buffer(dictionary)
baseline_context = create_cctx()
candidate_context = create_cctx()
decompression_context = create_dctx()
assert baseline_context and candidate_context and decompression_context
cache = {}
parameter_records = []
blocks = []
baseline_digest = hashlib.sha256()
candidate_digest = hashlib.sha256()
selected_bytes = 0
selected_contents = 0
baseline_bytes = 0
candidate_bytes = 0
decompressions = 0

try:
    for group_index, group in enumerate(manifest['groups']):
        files = {}
        for key, filename in group['files'].items():
            data = (PREPARED / filename).read_bytes()
            assert sha256(data) == group['hashes'][key], (group_index, key)
            files[key] = data
        source = memoryview(files['source'])
        assert len(files['offsets']) == len(files['lengths'])
        assert len(files['offsets']) % 4 == 0
        offsets = [value for (value,) in struct.iter_unpack('<I', files['offsets'])]
        lengths = [value for (value,) in struct.iter_unpack('<I', files['lengths'])]
        assert len(offsets) == group['selected']
        selected_contents += len(offsets)
        start = 0
        while start < len(lengths):
            total = 0
            end = start
            while end < len(lengths):
                next_length = lengths[end]
                if total > 0 and total + next_length > BLOCK_TARGET and next_length > 0:
                    break
                total += next_length
                end += 1
            chunks = []
            for index in range(start, end):
                offset = offsets[index]
                length = lengths[index]
                assert offset + length <= len(source)
                chunks.append(source[offset:offset + length])
            packed = b''.join(chunks)
            assert len(packed) == total
            selected_bytes += total
            params = get_params(LEVEL, total, len(dictionary))
            key = params.key()
            if key not in cache:
                cdict = create_cdict(dictionary_buffer, len(dictionary), 1, 0,
                                     params, CustomMemory())
                assert cdict
                actual = get_cdict_params(cdict)
                cache[key] = (cdict, len(parameter_records))
                parameter_records.append({
                    'requestedParameters': params.record(),
                    'storedCDictParameters': actual.record(),
                    'nativeCDictBytes': sizeof_cdict(cdict)
                })
            cdict, parameter_index = cache[key]
            source_buffer = ctypes.create_string_buffer(packed)
            capacity = compress_bound(total)
            baseline_output = ctypes.create_string_buffer(capacity)
            candidate_output = ctypes.create_string_buffer(capacity)
            baseline_size = checked(using_dict(
                baseline_context, baseline_output, capacity,
                source_buffer, total, dictionary_buffer, len(dictionary), LEVEL
            ))
            candidate_size = checked(using_cdict(
                candidate_context, candidate_output, capacity,
                source_buffer, total, cdict
            ))
            baseline_frame = baseline_output.raw[:baseline_size]
            candidate_frame = candidate_output.raw[:candidate_size]
            equal = baseline_frame == candidate_frame
            baseline_bytes += baseline_size
            candidate_bytes += candidate_size
            baseline_digest.update(struct.pack('<Q', baseline_size))
            baseline_digest.update(baseline_frame)
            candidate_digest.update(struct.pack('<Q', candidate_size))
            candidate_digest.update(candidate_frame)
            decoded = ctypes.create_string_buffer(total)
            for output, output_size in ((baseline_output, baseline_size),
                                        (candidate_output, candidate_size)):
                decoded_size = checked(decompress(
                    decompression_context, decoded, total, output, output_size,
                    dictionary_buffer, len(dictionary)
                ))
                assert decoded_size == total
                assert decoded.raw[:decoded_size] == packed
                decompressions += 1
            block = {
                'index': len(blocks), 'group': group_index,
                'selectedStart': start, 'selectedEnd': end,
                'sourceBytes': total, 'parameters': parameter_index,
                'baselineBytes': baseline_size, 'candidateBytes': candidate_size,
                'equal': equal,
                'baselineSha256': sha256(baseline_frame),
                'candidateSha256': sha256(candidate_frame)
            }
            if not equal:
                block['firstDifferingByte'] = next(
                    (index for index, (left, right) in enumerate(zip(baseline_frame, candidate_frame))
                     if left != right), min(baseline_size, candidate_size)
                )
                if not any(not item['equal'] for item in blocks):
                    (ROOT / 'first-mismatch-source.bin').write_bytes(packed)
                    (ROOT / 'first-mismatch-usingDict.zstd').write_bytes(baseline_frame)
                    (ROOT / 'first-mismatch-usingCDict.zstd').write_bytes(candidate_frame)
            blocks.append(block)
            start = end
finally:
    for cdict, _ in cache.values():
        free_cdict(cdict)
    free_cctx(baseline_context)
    free_cctx(candidate_context)
    free_dctx(decompression_context)

assert len(blocks) == 382
assert selected_bytes == manifest['selectedBytes']
assert selected_contents == manifest['selectedContents']
different = [block for block in blocks if not block['equal']]
result = {
    'hypothesis': 'Exact-parameter advanced CDict cache preserves usingDict frame bytes',
    'decision': 'REJECT: frame bytes differ' if different else 'BYTE GATE PASSED; timings not performed',
    'protocolSha256': sha256((ROOT / 'PROTOCOL.md').read_bytes()),
    'runnerSha256': sha256(pathlib.Path(__file__).read_bytes()),
    'zstdCommit': source_commit,
    'zstdVersion': version().decode(),
    'amalgamationSha256': sha256((PINNED / 'build/single_file_libs/zstd.c').read_bytes()),
    'nativeLibrarySha256': sha256(LIBRARY.read_bytes()),
    'compiler': subprocess.check_output(['cc', '--version'], text=True).splitlines()[0],
    'compilerFlags': ['-O3', '-DNDEBUG', '-fPIC', '-shared'],
    'manifestSha256': sha256(manifest_bytes),
    'inputDigest': manifest['inputDigest'],
    'archiveSha256': manifest['archiveSha256'],
    'dictionarySha256': sha256(dictionary),
    'dictionaryBytes': len(dictionary),
    'level': LEVEL,
    'blockTargetBytes': BLOCK_TARGET,
    'groups': len(manifest['groups']),
    'blocks': len(blocks),
    'selectedContents': selected_contents,
    'selectedBytes': selected_bytes,
    'byteIdenticalBlocks': len(blocks) - len(different),
    'differentBlocks': len(different),
    'firstDifference': different[0] if different else None,
    'baselineBytes': baseline_bytes,
    'candidateBytes': candidate_bytes,
    'baselineFramedDigest': baseline_digest.hexdigest(),
    'candidateFramedDigest': candidate_digest.hexdigest(),
    'verifiedNativeDecompressions': decompressions,
    'parameterTuples': parameter_records,
    'timingPerformed': False,
    'blockReceipts': blocks
}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'blockReceipts'}, indent=2))
sys.exit(2 if different else 0)
