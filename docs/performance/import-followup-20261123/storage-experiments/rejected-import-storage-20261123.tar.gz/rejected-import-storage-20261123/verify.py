"""Check archived evidence identity and arithmetic; does not rerun workloads."""

from pathlib import Path
import hashlib
import json
import math
import statistics


ROOT = Path(__file__).resolve().parent
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
read_json = lambda path: json.loads(path.read_text())
manifest = ROOT / 'SHA256SUMS'
if manifest.exists():
    for line in manifest.read_text().splitlines():
        expected, relative = line.split('  ', 1)
        assert digest(ROOT / relative) == expected, relative

pool = ROOT / 'pool'
runners = pool / 'runners'
cohorts = pool / 'cohorts'
expected_output = '647d1b757c3e206aa037b4a31205651d8708e1a2a1f041162d96bb78344a9e2f'
production = cohorts / '03-production-uninstrumented'
summary = read_json(production / 'jitendex-summary.json')
ratios = []
times = {'A': [], 'B': []}
hashes_by_arm = {}
for pair in range(1, 5):
    observations = {}
    for arm in ('A', 'B'):
        receipt = read_json(production / f'jitendex-{pair}-{arm}.json')
        observations[arm] = receipt
        assert receipt['sourceCommit'] == summary['sourceCommits'][arm]
        for key, value in summary['verifiedConstants'].items():
            assert receipt[key] == value, (pair, arm, key)
        assert receipt['persistedSha256'] == expected_output
        assert receipt['runnerSha256'] == digest(runners / 'run-jitendex.mjs')
        assert receipt['workerBridgeSha256'] == digest(runners / 'node-compression-worker.mjs')
        if arm not in hashes_by_arm:
            hashes_by_arm[arm] = receipt['sourceHashes']
        assert receipt['sourceHashes'] == hashes_by_arm[arm]
        times[arm].append(receipt['elapsedMs'])
    ratio = observations['B']['elapsedMs'] / observations['A']['elapsedMs']
    ratios.append(ratio)
    recorded = summary['pairs'][pair - 1]
    assert math.isclose(recorded['wallPercent'], (ratio - 1) * 100, abs_tol=1e-10)
    assert recorded['order'] == ('AB' if pair % 2 else 'BA')
    first, second = recorded['order']
    assert observations[first]['measuredWallFinishedAt'] <= observations[second]['measuredWallStartedAt']
assert math.isclose(summary['medianPairedWallPercent'], (statistics.median(ratios) - 1) * 100, abs_tol=1e-10)
assert math.isclose(summary['geometricPairedWallPercent'], (math.exp(statistics.mean(map(math.log, ratios))) - 1) * 100, abs_tol=1e-10)
changed_runtime_files = {
    'ext/js/dictionary/term-content-block-store.js',
    'ext/js/dictionary/zstd-term-content.js',
    'ext/js/dictionary/zstd-term-content-compression-worker.js',
    'ext/js/dictionary/term-content-buffer-pool.js'
}
assert {key for key in hashes_by_arm['A'] if hashes_by_arm['A'][key] != hashes_by_arm['B'][key]} == changed_runtime_files

for arm in ('A', 'B'):
    receipt = read_json(cohorts / '04-production-allocation' / f'jitendex-allocation-{arm}.json')
    assert receipt['persistedSha256'] == expected_output
    assert receipt['allocationOnly'] and receipt['instrument']
    assert receipt['sourceHashes'] == hashes_by_arm[arm]
    assert receipt['runnerSha256'] == digest(runners / 'run-jitendex-allocation.mjs')
    counts = receipt['operationStats']
    assert counts['packedChunks'] == 382 and counts['packedLogicalBytes'] == 389687485
    if arm == 'A':
        assert counts['allocatedBuffers'] == 382
        assert counts['allocatedCapacityBytes'] == 389687485
    else:
        assert counts['allocatedBuffers'] == 24 and counts['reusedBuffers'] == 358
        assert counts['allocatedCapacityBytes'] == counts['retainedPeakCapacityBytes'] == 24903680

historical = [
    ('01-generic-instrumented', 'pair-*-*.json', 'run-instrumented.mjs', True, 8),
    ('02-generic-uninstrumented', 'diagnostic-*-*.json', 'run.mjs', False, 4)
]
for directory, pattern, runner, instrumented, count in historical:
    files = sorted((cohorts / directory).glob(pattern))
    assert len(files) == count
    for file in files:
        receipt = read_json(file)
        assert receipt['runnerSha256'] == digest(runners / runner), str(file)
        if 'instrument' in receipt:
            assert receipt['instrument'] == instrumented
        current_hashes = hashes_by_arm['A' if file.stem.endswith('-A') else 'B']
        assert changed_runtime_files.issubset(receipt['sourceHashes'])
        assert all(current_hashes[key] == value for key, value in receipt['sourceHashes'].items())

cdict = ROOT / 'cdict'
proof = read_json(cdict / 'result.json')
assert proof['runnerSha256'] == digest(cdict / 'prove.py')
assert proof['protocolSha256'] == digest(cdict / 'PROTOCOL.md')
assert proof['blocks'] == proof['differentBlocks'] == 382
assert proof['byteIdenticalBlocks'] == 0
assert proof['verifiedNativeDecompressions'] == 764
assert not proof['timingPerformed']
assert all(not block['equal'] for block in proof['blockReceipts'])
assert sum(block['sourceBytes'] for block in proof['blockReceipts']) == proof['selectedBytes'] == 389687485
assert sum(block['baselineBytes'] for block in proof['blockReceipts']) == proof['baselineBytes'] == 31103602
assert sum(block['candidateBytes'] for block in proof['blockReceipts']) == proof['candidateBytes'] == 31076057
assert proof['dictionarySha256'] == hashes_by_arm['A']['ext/lib/zstd-dicts/jmdict.zdict']
assert proof['zstdCommit'] == read_json(ROOT / 'provenance.json')['zstdSourceCommit']
assert digest(pool / 'frozen-c38459dcd.patch') == read_json(ROOT / 'provenance.json')['poolPatchSha256']
print(json.dumps({
    'bundleChecksPassed': True,
    'correctedProductionObservations': 8,
    'historicalObservations': 12,
    'separateAllocationObservations': 2,
    'poolMedianPairedWallPercent': (statistics.median(ratios) - 1) * 100,
    'poolEqualWorkWallPercent': (sum(times['B']) / sum(times['A']) - 1) * 100,
    'cdictDifferentFrames': 382,
    'timingOrNativeExecutionPerformed': False
}, indent=2))
