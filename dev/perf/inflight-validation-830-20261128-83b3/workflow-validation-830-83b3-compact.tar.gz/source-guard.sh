set -euo pipefail
mkdir -p builds/perf/import-inflight-validation-830-83b3-logs
{
  printf 'baseline=%s\ncandidate=%s\ndatabase-sha256=%s\n' \
    "$PERF_BASELINE" "$PERF_CANDIDATE" "$PERF_DATABASE_SHA256"
  test "$(git rev-parse HEAD)" = "$PERF_CANDIDATE"
  test -z "$(git status --porcelain)"
  test "$(git diff --name-only "$PERF_BASELINE" "$PERF_CANDIDATE" -- ext)" = \
    ext/js/dictionary/dictionary-database.js
  printf '%s  %s\n' "$PERF_DATABASE_SHA256" ext/js/dictionary/dictionary-database.js \
    | sha256sum --check --strict
  git diff --exit-code "$PERF_BASELINE" "$PERF_CANDIDATE" -- \
    package.json package-lock.json .github/actions/setup/action.yml \
    test/perf/dictionaries.lock.json test/e2e test/chromium \
    ':(glob)dev/*.js' dev/bin dev/data dev/lib \
    ':(glob)dev/perf/**/*.js' ':(glob)dev/perf/**/*.mjs' \
    ':(glob)dev/perf/**/*.html' ':(glob)dev/perf/**/*.py'
  git diff --stat "$PERF_BASELINE" "$PERF_CANDIDATE" -- ext
} 2>&1 | tee builds/perf/import-inflight-validation-830-83b3-logs/source-guard.log
