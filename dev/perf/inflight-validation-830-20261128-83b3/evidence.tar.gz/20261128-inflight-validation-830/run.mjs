// Fixed prospective #830 screen. Preflight is correctness-only and never enters
// the timing cohort. A failed measured child stops the cohort without retry.
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createWriteStream} from 'node:fs';
import {mkdir, readFile, stat} from 'node:fs/promises';
import path from 'node:path';
import {
    assertResources, baselineCommit, baselineRoot, candidateCommit, candidateDbSha,
    candidateRoot, correctedOraclePath, dbFile, evidenceRoot, fileHashes,
    fileIdentity, helperFiles, orders, originalOraclePath, resourcePolicy,
    resources, saveJson, sha, sourceReceipt,
} from './common.mjs';

assert.equal(process.version, 'v22.22.0');
const mode = process.argv[2];
const runName = process.argv[3];
assert(['preflight', 'freeze', 'cohort', 'analyze'].includes(mode));
assert(typeof runName === 'string' && /^[a-z0-9-]+$/.test(runName));
const directory = path.join(evidenceRoot, runName);
const readJson = async (file) => JSON.parse(await readFile(file, 'utf8'));
async function exclusiveDirectory(location) {
    await mkdir(location); // Never overwrite an earlier attempt or observation.
}
async function createInputs() {
    const baseline = await sourceReceipt(baselineRoot, baselineCommit);
    const candidate = await sourceReceipt(candidateRoot, candidateCommit);
    assert.equal(candidate.identity[dbFile], candidateDbSha);
    assert.deepEqual({...candidate.identity, [dbFile]: baseline.identity[dbFile]}, baseline.identity);
    const helpers = await fileHashes(evidenceRoot, helperFiles);
    const oracles = {original: (await fileIdentity(originalOraclePath)).sha256, corrected: (await fileIdentity(correctedOraclePath)).sha256};
    return {baseline, candidate, helpers, oracles};
}
async function child(inputs, arm, output, childMode, round, expectedFinalOracle) {
    const resourceBefore = await resources();
    assertResources(resourceBefore);
    await exclusiveDirectory(output);
    const config = {
        schemaVersion: 1, arm, mode: childMode, round, output,
        preciseCoverage: childMode === 'admission',
        source: arm === 'B' ? inputs.candidate : inputs.baseline,
        helpers: inputs.helpers, oracles: inputs.oracles,
        expectedFinalOracle,
    };
    const configPath = path.join(output, 'config.json');
    await saveJson(configPath, config);
    const arguments_ = [`--max-old-space-size=${resourcePolicy.nodeHeapMiB}`, path.join(evidenceRoot, 'sink-child.mjs'), configPath];
    const startedUtc = new Date().toISOString();
    const start = performance.now();
    const stdout = createWriteStream(path.join(output, 'stdout.log'), {flags: 'wx'});
    const stderr = createWriteStream(path.join(output, 'stderr.log'), {flags: 'wx'});
    const process_ = spawn(process.execPath, arguments_, {cwd: baselineRoot, stdio: ['ignore', 'pipe', 'pipe']});
    process_.stdout.pipe(stdout);
    process_.stderr.pipe(stderr);
    let deadlineExceeded = false;
    const timeout = setTimeout(() => { deadlineExceeded = true; process_.kill('SIGKILL'); }, resourcePolicy.childDeadlineMs);
    const status = await new Promise((resolve) => {
        process_.once('error', (error) => resolve({spawnError: String(error), exitCode: null, signal: null}));
        process_.once('close', (exitCode, signal) => resolve({exitCode, signal}));
    });
    clearTimeout(timeout);
    await Promise.all([stdout, stderr].map((stream) => new Promise((resolve, reject) => {
        if (stream.writableFinished) { resolve(); } else { stream.once('finish', resolve); stream.once('error', reject); }
    })));
    const receipt = {arm, round, mode: childMode, startedUtc, finishedUtc: new Date().toISOString(), processElapsedMsDiagnostic: performance.now() - start, executable: process.execPath, arguments: arguments_, resourceBefore, resourceAfter: await resources(), deadlineExceeded, ...status};
    await saveJson(path.join(output, 'process.json'), receipt);
    assert.equal(receipt.spawnError, undefined);
    assert.equal(receipt.deadlineExceeded, false, 'Frozen child deadline exceeded');
    assert.equal(receipt.signal, null, 'Child terminated by signal; no replacement trial');
    assert.equal(receipt.exitCode, 0, 'Child failed; no replacement trial');
    const result = await readJson(path.join(output, 'result.json'));
    assert.equal(result.success, true);
    assert.equal(result.mode, childMode);
    assert.equal(result.timingEligible, childMode === 'measured');
    return {receipt, resultPath: path.join(output, 'result.json'), resultSha256: (await fileIdentity(path.join(output, 'result.json'))).sha256, result};
}
if (mode === 'preflight') {
    await exclusiveDirectory(directory);
    const inputs = await createInputs();
    await saveJson(path.join(directory, 'inputs.json'), inputs);
    const observations = [];
    try {
        observations.push(await child(inputs, 'A', path.join(directory, 'A'), 'correctness', null, null));
        const oraclePath = path.join(directory, 'A/final-output-oracle.json');
        const expectedFinalOracle = {path: oraclePath, ...await fileIdentity(oraclePath)};
        observations.push(await child(inputs, 'B', path.join(directory, 'B'), 'admission', null, expectedFinalOracle));
        assert(observations[1].result.coverageProof);
        assert.deepEqual(await createInputs(), inputs);
        await saveJson(path.join(directory, 'result.json'), {
            success: true, purpose: 'Untimed actual-producer admission and complete-output parity only',
            inputs, expectedFinalOracle,
            observations: observations.map(({result, ...entry}) => ({...entry, rows: result.rows, frames: result.compressionReplies, admissionProved: result.coverageProof !== null})),
        });
        console.log(JSON.stringify({preflight: directory, success: true, admittedCalls: observations[1].result.coverageProof.trueReturnCount}));
    } catch (error) {
        await saveJson(path.join(directory, 'failure.json'), {error: String(error?.stack ?? error), inputs, completedChildren: observations.map(({result, ...entry}) => entry)});
        throw error;
    }
} else if (mode === 'freeze') {
    const preflightPath = path.join(directory, 'result.json');
    const preflight = await readJson(preflightPath);
    assert.equal(preflight.success, true);
    assert.deepEqual(await createInputs(), preflight.inputs);
    const frozenPath = path.join(evidenceRoot, 'protocol.json');
    await assert.rejects(stat(frozenPath), {code: 'ENOENT'});
    const protocol = {
        schemaVersion: 1, frozenUtc: new Date().toISOString(),
        purpose: 'Current-source first-use actual-sink component screen of unchanged final #830 safeguards',
        sourceQuestion: 'Does the final private-origin fixed-column guard reduce cold actual current JMdict sink work beyond identical-code variation?',
        orders, rounds: orders.length, armCount: orders.length * 3,
        resourcePolicy, childArguments: [`--max-old-space-size=${resourcePolicy.nodeHeapMiB}`],
        inputs: preflight.inputs, expectedFinalOracle: preflight.expectedFinalOracle,
        preflight: {path: preflightPath, ...await fileIdentity(preflightPath)},
        primary: 'primaryForegroundSinkAndDrainMs: noncontiguous sum of 12 bulkAddArtifactTermsChunk intervals plus final public session drain',
        secondary: 'directRegistrationMs: aggregate synchronous _registerInFlightTermContentSources interval; factory work is only in the primary',
        diagnostics: ['each public sink interval', 'separate final drain', 'pipeline envelope including parser/oracle gaps', 'child resource snapshots'],
        unchangedControls: 'A and C use the identical baseline root/source with fresh child processes; B is exactly the upstream two-file patch port',
        noWarmup: true, noInspectorInMeasuredChildren: true, noRerunOrSubstitution: true,
        failurePolicy: 'Retain every child exit/failure/raw observation. Stop on the first failed timed child; never replace it or change arguments/corpus.',
    };
    await saveJson(frozenPath, protocol);
    console.log(JSON.stringify({protocol: frozenPath, ...await fileIdentity(frozenPath)}));
} else if (mode === 'cohort') {
    const frozenPath = path.join(evidenceRoot, 'protocol.json');
    const frozenBytes = await readFile(frozenPath);
    const frozenSha256 = sha(frozenBytes);
    const frozen = JSON.parse(frozenBytes);
    assert.deepEqual(frozen.orders, orders);
    assert.deepEqual(frozen.resourcePolicy, resourcePolicy);
    assert.deepEqual(await createInputs(), frozen.inputs);
    assert.equal((await fileIdentity(frozen.preflight.path)).sha256, frozen.preflight.sha256);
    assert.equal((await fileIdentity(frozen.expectedFinalOracle.path)).sha256, frozen.expectedFinalOracle.sha256);
    await exclusiveDirectory(directory);
    const observations = [];
    const checkpoint = async (success, error = null) => {
        assert.equal((await fileIdentity(frozenPath)).sha256, frozenSha256, 'Frozen protocol changed during acquisition');
        await saveJson(path.join(directory, 'result.json'), {
            schemaVersion: 1, success, error, protocolSha256: frozenSha256,
            orders, observations, resources: await resources(),
        });
    };
    await checkpoint(false, 'In progress');
    try {
        for (let round = 0; round < orders.length; ++round) {
            for (const arm of orders[round]) {
                const output = path.join(directory, `round-${String(round + 1).padStart(2, '0')}-${arm}`);
                const observation = await child(frozen.inputs, arm, output, 'measured', round + 1, frozen.expectedFinalOracle);
                observations.push(observation);
                await checkpoint(false, 'In progress');
                process.stdout.write(`Finished round ${round + 1}/${orders.length} arm ${arm}\n`);
            }
        }
        assert.deepEqual(await createInputs(), frozen.inputs);
        await checkpoint(true);
    } catch (error) {
        await checkpoint(false, String(error?.stack ?? error));
        throw error;
    }
} else {
    const report = await readJson(path.join(directory, 'result.json'));
    assert(report.success);
    assert.equal(report.observations.length, 36);
    const median = (values) => {
        const sorted = [...values].sort((a, b) => a - b);
        return (sorted[(sorted.length - 1) >> 1] + sorted[sorted.length >> 1]) / 2;
    };
    const summary = (values) => ({mean: values.reduce((sum, value) => sum + value, 0) / values.length, median: median(values), minimum: Math.min(...values), maximum: Math.max(...values)});
    const metrics = {};
    for (const field of ['primaryForegroundSinkAndDrainMs', 'directRegistrationMs', 'sinkCallMs', 'drainMs']) {
        const rounds = orders.map((order, index) => {
            const values = Object.fromEntries(report.observations.filter((entry) => entry.receipt.round === index + 1).map((entry) => [entry.receipt.arm, entry.result[field]]));
            assert.deepEqual(Object.keys(values).sort(), ['A', 'B', 'C']);
            const controlMean = (values.A + values.C) / 2;
            return {round: index + 1, order, ...values, candidateMinusControlMeanMs: values.B - controlMean, candidateMinusControlMeanPercent: 100 * (values.B / controlMean - 1), candidateMinusAMs: values.B - values.A, candidateMinusCMs: values.B - values.C, unchangedCMinusAMs: values.C - values.A, unchangedCMinusAPercent: 100 * (values.C / values.A - 1)};
        });
        metrics[field] = {
            rounds,
            candidateMinusControlMeanMs: summary(rounds.map((entry) => entry.candidateMinusControlMeanMs)),
            candidateMinusControlMeanPercent: summary(rounds.map((entry) => entry.candidateMinusControlMeanPercent)),
            candidateMinusAMs: summary(rounds.map((entry) => entry.candidateMinusAMs)),
            candidateMinusCMs: summary(rounds.map((entry) => entry.candidateMinusCMs)),
            unchangedCMinusAMs: summary(rounds.map((entry) => entry.unchangedCMinusAMs)),
            unchangedCMinusAPercent: summary(rounds.map((entry) => entry.unchangedCMinusAPercent)),
            candidateBeatsBoth: rounds.filter((entry) => entry.B < entry.A && entry.B < entry.C).length,
        };
    }
    const analysis = {schemaVersion: 1, resultSha256: (await fileIdentity(path.join(directory, 'result.json'))).sha256, metrics, qualification: 'Component evidence only; all observations retained and whole-browser qualification remains separate'};
    await saveJson(path.join(directory, 'analysis.json'), analysis);
    console.log(JSON.stringify(analysis));
}
