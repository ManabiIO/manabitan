# Current-source JMdict qualification of #830

The unchanged final #830 guard produced a consistent **direct-registration
component saving** on the current complete JMdict corpus. Its median paired
difference against the mean of two identical-code controls was **−16.9997 ms
(−63.919%)**, and the candidate was faster than both controls in all twelve
rounds. The broader foreground sink-and-drain aggregate is too variable to
establish a total storage or import gain from this cohort. Runtime is not
promoted by this evidence alone; complete browser qualification remains a
separate step.

## Exact source and question

Baseline A and identical control C are develop
`9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. Candidate B is local commit
`3eb1b7afa13c821af96e95fee1d6b4583af8e434`, tree
`28e0dd109918bc63a106e78cee718a7eb8c9d91e`: the exact two-file diff of upstream
#830 head `a628c6c7915576dcf280e98bc9129a508f2f9644` applied to that baseline.
Independent review compared all 434 added and 18 removed lines with the fixed
upstream patch. No safeguard or additional optimization was introduced.

The runtime SHA256 is
`12569a57197d4923fff7ed74fe6da071b4fff6d7a01bb9112e848c2a9d25cbbd`.
The test SHA256 is
`0b162f3d4889fba176a08aaee15bd8641115db7012f75c5124dcaf43119c30fe`.
See [port-source.json](port-source.json), [upstream.diff](upstream.diff), and
[port.diff](port.diff). [port-commit.txt](port-commit.txt) contains the exact
commit object payload, so the private port can be reconstructed with its
original identity after applying the patch and verifying the tree.

This resolves a previously unmeasured question about the **final guarded source
on the current first full-corpus pass**. The PR's historical pre-hardening warmed
result used a different corpus and is not pooled with these observations.

## Prospective protocol and actual admission

[protocol.md](protocol.md) records the boundaries and failure policy.
[protocol.json](protocol.json), SHA256
`a9dd8b81161d03830c098b58fd1c63bb67b07e80be81feaab30a76664e962e4c`, froze the
source/helper/oracle identities, the twelve orders `ABC, BCA, CAB, ACB, CBA,
BAC` repeated twice, and resource gates before the first measured child.

Every arm used a fresh Node 22.22.0 process and four actual native codec workers,
without corpus warmup or inspector instrumentation. Initialization was outside
the sink intervals. All children processed the same 528,299 rows in the twelve
current three-parser-policy groups: 362,032 unique spans and 103 native frames.
The parser execution was sequential in this explicit Node adapter. This is
first-use/JIT-cold component evidence, not hardware-cache-cold measurement or a
complete browser import.

The untimed [preflight result](preflight-1/result.json) proves actual producer
admission on unchanged source. Candidate
[precise coverage](preflight-1/B/precise-coverage.json) records twelve private
producer calls, twelve validator true returns, twelve registrations, and zero
generic-loop body executions. Each registration covers exactly its captured
group's unique spans. The real parser parent's owned-content receipt is applied
before the public sink; all twelve groups adopt the expected source bytes.
Measured children contain no admission coverage or shape inspection.

The primary is the **noncontiguous aggregate** of the twelve complete public
`bulkAddArtifactTermsChunk` intervals plus the final session drain. That includes
the new producer witness work. Parsing and oracle gaps are excluded; the separate
contiguous pipeline envelope is diagnostic only. The direct synchronous
registration aggregate is a secondary metric and excludes producer factory
work. The Node filesystem-backed OPFS adapter is not performance-equivalent to
browser OPFS.

## Complete fixed-cohort results

All 36 measured children completed with exit 0. No child was replaced, no outlier
was removed, and no optional round or alternative implementation ran.
[Raw results](cohort-1/result.json), SHA256
`c9a77c4417ac8525b1c4ab78c9e339eb4a8ac74f88ac429c43ea030518bb0ad9`, retain every
chronological observation and original child receipt. Each round directory also
retains its configuration, stdout/stderr, result, output oracle, raw file hashes,
and process/resource receipt.

| Metric, whole-corpus milliseconds            | A median | B median | C median | Median B − mean(A,C) | B faster than both |
| -------------------------------------------- | -------: | -------: | -------: | -------------------: | -----------------: |
| Direct registration                          |  29.0262 |  10.2345 |  30.0897 |  −16.9997 (−63.919%) |            12 / 12 |
| Foreground sink plus final drain             | 749.2108 | 670.5080 | 729.4417 |  −90.2432 (−11.217%) |             4 / 12 |
| Foreground sink calls, excluding final drain | 604.6724 | 580.4469 | 608.9094 |    −6.5019 (−1.112%) |             4 / 12 |
| Final drain                                  | 107.2654 | 105.2060 | 140.7896 |  −35.7792 (−21.328%) |             7 / 12 |

The table's paired medians are calculated within each matched round, not by
subtracting the displayed marginal medians. Paired percentages likewise use
each round's own control mean. The detailed calculations are in
[analysis.json](cohort-1/analysis.json).

Direct registration saved 8.7007–28.0118 ms against the matched control mean in
every round. The unchanged controls' direct-registration differences ranged
from −23.3239 to +15.1954 ms; the candidate nevertheless beat each individual
control in all twelve pairs. That is credible evidence for this specific
current-source component improvement.

The primary aggregate has much larger unrelated variation: unchanged C−A
differences ranged from −455.6119 to +353.5686 ms (−38.960% to +60.918%). Its
favorable paired median must not be presented as a demonstrated 11% total sink
or import speedup. Final-drain variation alone is larger than the direct
registration saving. The complete raw tails remain visible.

[Independent readback](cohort-1/independent-readback.json), SHA256
`96a890c4de9e1bc2d18eb6fde9c3602cc45e91dac0a58690ac529cecae29c9fe`, recomputed all
four metrics across all twelve rounds and checked every source/config/result
identity and oracle. No further timing was run after this fixed cohort.

## Correctness, resource gates, and limitations

All 36 children matched the existing twelve source-window and descriptor hashes
and all 103 native frame hashes. Every sink boundary had zero outstanding codec
jobs, equal planned/dispatched/source-consumed/completed counts, and no live
registration batch. All twelve parent ownership receipts and expected adopted
byte counts passed.

All three persisted files, totaling 43,315,677 bytes, and all 23 database metadata
fields matched the baseline oracle. The only normalization is each intentionally
random 16-byte shard generation ID in the record header and its paired index
header. Their exact linkage is checked first; complete raw file hashes and IDs
are retained. No product randomness is replaced. The normalized output oracle
is identical in all 36 children:
`5a2d8167f046e313949af8005ed493b651d10a4de95bfc5a2de24699ec61a58e`.

Before acquisition, 293 focused contract cases across five files passed, and
scoped TypeScript validation passed. This actual command set is recorded in
[focused-tests-receipt.json](focused-tests-receipt.json); it is not claimed to
reproduce the PR's undocumented historical 220-test command. The initial scoped
ESLint attempt was terminated by SIGKILL without a reported source violation;
its cause was not established. One later authorized attempt on the unchanged
two files **passed with exit 0** in 26.431 seconds, using the same 768 MiB Node
heap cap. Both attempts, their complete logs and the retry's resource snapshot
remain in the evidence. See
[the passing receipt](scoped-eslint-retry-receipt.json). No new complete browser
qualification was acquired here.

The frozen gates required a 512 MiB Node heap cap, a 120-second child deadline,
160 MiB free temporary storage and 32 MiB free report storage before each child.
All measured children passed these gates. A separate checkpoint-packaging
attempt hit workspace ENOSPC before timing. Its partial archive and
[failure receipt](setup-failures/workspace-checkpoint-enospc.json) were preserved
in the durable preflight checkpoint; after safe resource
reclamation, the original gates passed unchanged. It was not a failed or
substituted timing trial.

## Reproduction and preservation

The measured helpers are [common.mjs](common.mjs), [sink-child.mjs](sink-child.mjs)
and [run.mjs](run.mjs). Their frozen hashes are in the protocol. They expect this
evidence directory under `builds/perf/` in the baseline checkout, the exact port
as sibling `inflight-validation-830`, the locked JMdict ZIP, and the pinned
native libraries. The shared dependency and library links were not committed.

Two earlier immutable receipts are required at their original sibling paths:
`../20261128-compression-request-batches/capture.json` and
`../20261128-canonical-sink-profile/run-1/result.json`. They provide the existing
native/source/descriptor oracle and the corrected parent-ownership accounting.
Their hashes are pinned in the protocol. The raw compression capture slabs are
not required. The original frozen protocol and observations must remain intact;
a reproduction in a different checkout requires its own new prospective
preflight and protocol paths, not relabeling these observations.

Before timing, the full source/test/preflight/freeze checkpoint was saved as
unreferenced Git blobs: archive `10c2b7dd636c87e0912285c77810a10c8d70295f` and
manifest `7f4425631db4049d838d12c40a1d054bca969dbe`. Every archive member and both
returned remote object identities were verified. No remote runtime branch or PR
was changed by this experiment.
