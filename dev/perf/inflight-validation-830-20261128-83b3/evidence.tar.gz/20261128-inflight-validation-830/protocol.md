# Prospective current-source #830 JMdict component screen

Status: preparation only. No measured child may start until the complete runner,
source identities and untimed admission/parity receipt have passed independent
review, and the coordinator has granted a quiet CPU slot. This is a new study;
the historical pre-hardening warmed result is not included in its observations.

## Fixed source and workload

A and C use byte-identical develop `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
B is local commit `3eb1b7afa13c821af96e95fee1d6b4583af8e434`, the exact two-file
diff of upstream #830 head `a628c6c7915576dcf280e98bc9129a508f2f9644` applied to
that baseline. Only `dictionary-database.js` changes at runtime. No safeguard,
configuration, export, native module or toolchain is changed.

Use the complete locked JMdict fixture: 528,299 rows, 53 term banks, the existing
three-parser-policy partition into twelve groups, and four actual native codec
workers. Run the actual parser-worker entry point with transferred output and
the exact parent owned-content receipt. The public database sink creates each
pending-span object; reconstructed objects would lose #830's private origin
witness and are not an acceptable measurement input.

Each arm gets a fresh Node 22.22.0 process, fresh stores and fresh codec workers.
Initialization and module acquisition finish before the first sink call. There
is no corpus warmup. Each child processes the groups sequentially through the
same corrected Node OPFS adapter. This is first-use/JIT-cold component evidence,
not a hardware-cache-cold test or complete browser import timing.

## Boundaries

The primary value is the **noncontiguous foreground sink-and-drain aggregate**:
the sum of twelve complete `bulkAddArtifactTermsChunk` call intervals, plus a
separately retained final session drain interval. The latter closes the block
session and awaits both public content-store and record-store
`endImportSession` methods. Each individual call and the drain remain visible.

The secondary value is the aggregate of direct synchronous registration calls.
Its identical wrapper is present in all arms. It does not include producer
factory work; that work is included in the primary public-sink intervals.

A separate contiguous pipeline envelope includes parsing and oracle gaps and
is diagnostic only. It must not be renamed storage latency or substituted for
the primary result. Parser calls, source/descriptor/native-frame hashing,
persisted-file and metadata hashing, report allocation and disk report writes
are outside the authoritative sink/registration/drain intervals.

Untimed preflight must prove there is no outstanding codec work at every sink
boundary. Record the observed pool's pending map, planned block count,
dispatched request count, source-consumed replies and completed result replies.
The pinned shared-span implementation creates and dispatches its entire block
plan synchronously; planned equals dispatched guards undispatched work as well.
All 103 frames must still be accounted for after final drain.

## Untimed admission and parity gate

Run a fresh baseline and fresh candidate correctness acquisition before freezing
the timing protocol. Candidate-only V8 precise coverage may be enabled for this
untimed gate, on the unchanged source module. It must prove the real producer
factory and validator execute, the validator reaches its true return, and the
generic registration loop body is skipped for the actual admitted calls. Keep
the exact coverage ranges and source SHA. Measured children use no inspector,
coverage, breakpoint or admission-specific instrumentation.

Every child verifies the twelve existing source-window and descriptor hashes,
all 103 existing native frame hashes, original block geometry/order, twelve
owned-content receipts and exact expected adopted-byte accounting. The baseline
preflight also freezes complete final OPFS content/record/index file hashes and
all database metadata table, scalar and map digests. Candidate preflight and
every measured child must match them. The only cross-run normalization is the
intentionally random 16-byte shard generation ID in the record header (bytes
8–23) and its paired lookup index header (bytes 24–39). Validate exact linkage
between each pair, retain each raw complete-file hash and original ID, and
normalize only those documented fields for cross-run comparison. Product
randomness is unchanged. All normalization occurs after the final timer.
No full-corpus source or output snapshots
are retained solely for measurement: keep one group's views until its untimed
checks complete, then release them, and remove temporary OPFS files after the
compact receipt has been saved.

## Fixed schedule and failure policy

Exactly twelve rounds use `ABC`, `BCA`, `CAB`, `ACB`, `CBA`, `BAC`, repeated twice.
Every arm starts a fresh child. Compare whole-corpus totals by matched round;
do not pool differently sized group medians. Report paired B minus mean(A,C),
both individual-control comparisons and unchanged C-minus-A variation. Retain
every chronological observation, outlier, child exit status and stderr.

Freeze script/source/oracle hashes and child arguments before the first timed
child. Use a 120-second child deadline, a 512 MiB Node heap cap, at least 160 MiB
free temporary storage and 32 MiB free report storage before starting each
child. Record host/resource snapshots, while recognizing they do not establish
browser-tree peak memory. Resource failure stops the acquisition; it does not
authorize changing the corpus, thresholds, arguments or substituting a trial.

No optional rounds, alternate implementations, outlier removal or rerun of a
failed timed child. Stop after the fixed cohort. A positive component result
would still require separately specified full-browser qualification before a
whole-import claim. No original #830 or #820 remote branch changes are part of
this preparation.
