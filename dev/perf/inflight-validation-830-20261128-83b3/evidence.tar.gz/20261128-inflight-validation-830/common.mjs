import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createReadStream} from 'node:fs';
import {readFile, statfs, writeFile} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

export const evidenceRoot = path.dirname(fileURLToPath(import.meta.url));
export const baselineRoot = path.resolve(evidenceRoot, '../../..');
export const candidateRoot = path.resolve(baselineRoot, '../inflight-validation-830');
export const baselineCommit = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2';
export const candidateCommit = '3eb1b7afa13c821af96e95fee1d6b4583af8e434';
export const dbFile = 'ext/js/dictionary/dictionary-database.js';
export const candidateDbSha = '12569a57197d4923fff7ed74fe6da071b4fff6d7a01bb9112e848c2a9d25cbbd';
export const originalOraclePath = path.resolve(evidenceRoot, '../20261128-compression-request-batches/capture.json');
export const correctedOraclePath = path.resolve(evidenceRoot, '../20261128-canonical-sink-profile/run-1/result.json');
export const orders = ['ABC', 'BCA', 'CAB', 'ACB', 'CBA', 'BAC', 'ABC', 'BCA', 'CAB', 'ACB', 'CBA', 'BAC'];
export const resourcePolicy = {childDeadlineMs: 120000, nodeHeapMiB: 512, minTempFreeBytes: 160 * 1024 * 1024, minReportFreeBytes: 32 * 1024 * 1024};
export const helperFiles = ['common.mjs', 'sink-child.mjs', 'run.mjs', 'protocol.md'];
export const sourceFiles = [
    'ext/js/dictionary/term-bank-wasm-parser.js',
    'ext/js/dictionary/term-bank-wasm-parser-worker.js',
    'ext/js/dictionary/term-bank-source-pipeline.js',
    dbFile,
    'ext/js/dictionary/dictionary-importer.js',
    'ext/js/dictionary/term-content-ownership.js',
    'ext/js/dictionary/term-content-opfs-store.js',
    'ext/js/dictionary/term-record-opfs-store.js',
    'ext/js/dictionary/term-content-block-envelope.js',
    'ext/js/dictionary/term-bank-experiments.js',
    'ext/js/dictionary/raw-term-content.js',
    'ext/js/dictionary/zstd-term-content-compression-worker.js',
    'test/fixtures/opfs-continuation/node-opfs-adapter.mjs',
    'ext/js/dictionary/term-content-canonical-scan.js',
    'ext/js/dictionary/term-content-block-store.js',
    'ext/js/dictionary/zstd-term-content.js',
    'ext/lib/term-bank-parser.wasm',
    'ext/lib/term-content-canonical-scan-v1.wasm',
    'ext/lib/zstd-wasm.js',
    'ext/lib/zstd.wasm',
    'ext/lib/zstd-dicts/jmdict.zdict',
];
export const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
export async function fileIdentity(file) {
    const hash = createHash('sha256');
    let bytes = 0;
    for await (const chunk of createReadStream(file)) { bytes += chunk.byteLength; hash.update(chunk); }
    return {bytes, sha256: hash.digest('hex')};
}
export async function fileHashes(root, files) {
    return Object.fromEntries(await Promise.all(files.map(async (file) => [file, (await fileIdentity(path.join(root, file))).sha256])));
}
export async function sourceReceipt(root, commit) {
    const actualCommit = execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim();
    assert.equal(actualCommit, commit);
    const diff = execFileSync('git', ['-C', root, 'diff', 'HEAD', '--binary']);
    assert.equal(diff.byteLength, 0, 'Tracked source must remain unchanged');
    return {root, commit, diffSha256: sha(diff), identity: await fileHashes(root, sourceFiles)};
}
export async function resources() {
    const free = async (location) => {
        const s = await statfs(location);
        return {location, availableBytes: s.bavail * s.bsize, totalBytes: s.blocks * s.bsize};
    };
    const optional = async (file) => {
        try { return (await readFile(file, 'utf8')).trim(); } catch (error) { return {unavailable: error.code}; }
    };
    return {
        utc: new Date().toISOString(),
        pid: process.pid,
        node: process.version,
        execArgv: process.execArgv,
        platform: process.platform,
        arch: process.arch,
        cpus: os.availableParallelism(),
        loadAverage: os.loadavg(),
        freeMemoryBytes: os.freemem(),
        processMemory: process.memoryUsage(),
        processUsage: process.resourceUsage(),
        temp: await free(os.tmpdir()),
        reports: await free(evidenceRoot),
        cgroup: Object.fromEntries(await Promise.all([
            '/sys/fs/cgroup/memory.max', '/sys/fs/cgroup/memory.current',
            '/sys/fs/cgroup/memory/memory.limit_in_bytes', '/sys/fs/cgroup/memory/memory.usage_in_bytes',
        ].map(async (file) => [file, await optional(file)]))),
    };
}
export function assertResources(receipt) {
    assert(receipt.temp.availableBytes >= resourcePolicy.minTempFreeBytes, 'Insufficient frozen temporary-storage budget');
    assert(receipt.reports.availableBytes >= resourcePolicy.minReportFreeBytes, 'Insufficient frozen report-storage budget');
}
export async function saveJson(file, value) { await writeFile(file, `${JSON.stringify(value, null, 2)}\n`); }
