#!/usr/bin/env python3
"""Independent arithmetic check from raw browser start/completion timestamps."""

from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import statistics


STAGE = Path(__file__).resolve().parent
SOURCE = STAGE.parent / 'ci-parser-confirm'


def main():
    expected = json.loads((SOURCE / 'confirmation-summary.json').read_text())
    results = {}
    for cell in ['jmdict-AB', 'jmdict-BA']:
        directory = SOURCE / cell
        receipt = json.loads((directory / 'cohort-receipt.json').read_text())
        assert receipt['planned'] == receipt['attempted']
        durations = {}
        sources = []
        for label in receipt['planned']:
            file = directory / label / 'run-1.json'
            raw = file.read_bytes()
            report = json.loads(raw)
            timings = [phase['data']['browserTiming'] for phase in report['phases']
                       if isinstance(phase.get('data'), dict) and 'browserTiming' in phase['data']]
            assert len(timings) == 1
            timing = timings[0]
            assert timing['trigger'] == 'file-input-change' and timing['errorCount'] == 0
            duration = timing['completedAtMs'] - timing['startedAtMs']
            durations[label] = duration
            summary = json.loads((directory / label / 'summary.json').read_text())
            assert len(summary['runs']) == 1 and summary['authoritativeTiming'] is True
            assert abs(duration - summary['runs'][0]['totalImportMs']) < 1e-9
            sources.append({'relativePath': str(file.relative_to(SOURCE)),
                            'sha256': hashlib.sha256(raw).hexdigest(),
                            'startedAtMs': timing['startedAtMs'],
                            'completedAtMs': timing['completedAtMs'],
                            'elapsedMs': duration})
        comparisons = {}
        for name, first, second, count, key in [
            ('candidate', 'A', 'B', 12, 'candidateMetrics'),
            ('control', 'C', 'D', 4, 'controlMetrics'),
        ]:
            pairs = []
            for number in range(1, count + 1):
                a = durations[first + str(number)]
                b = durations[second + str(number)]
                pairs.append({'pair': number, 'firstMs': a, 'secondMs': b,
                              'differenceMs': b - a, 'percent': (b / a - 1) * 100})
            median = statistics.median(pair['percent'] for pair in pairs)
            faster = sum(pair['secondMs'] < pair['firstMs'] for pair in pairs)
            target = expected['cells'][cell][key]['totalImportMs']
            assert abs(median - target['pairedMedianPercent']) < 1e-9
            assert faster == target['secondRoleFasterPairs']
            comparisons[name] = {'pairCount': count, 'pairedMedianPercent': median,
                                 'secondRoleFasterPairs': faster, 'pairs': pairs}
        results[cell] = {'rawBrowserDurations': sources, 'comparisons': comparisons}
    result = {
        'generatedAtUtc': datetime.now(timezone.utc).isoformat(),
        'purpose': 'Independent arithmetic verification, not a new timing experiment',
        'source': str(SOURCE), 'runId': 44605775330,
        'method': 'Raw browser completedAtMs minus startedAtMs; paired median of 100 * (second / first - 1)',
        'summaryMatches': True, 'rawObservationCount': sum(len(r['rawBrowserDurations']) for r in results.values()),
        'limitations': ['Same observations as the original analyzer, not independent replication',
                        'Only the two JMdict cells recomputed here; all six cells remain in the primary analyzer',
                        'Warmups retained but excluded by the predefined plan',
                        'No inferential or universal performance claim'],
        'cells': results,
    }
    (STAGE / 'jmdict-arithmetic-recheck.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: {a: {b: c for b, c in v.items() if b != 'pairs'} for a, v in r['comparisons'].items()}
                      for k, r in results.items()}, indent=2))


if __name__ == '__main__':
    main()
