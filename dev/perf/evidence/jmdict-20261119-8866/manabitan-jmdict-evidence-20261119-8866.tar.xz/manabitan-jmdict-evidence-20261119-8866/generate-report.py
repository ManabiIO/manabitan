#!/usr/bin/env python3
"""Refresh a readable evidence report without changing source evidence."""

from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json


STAGE = Path(__file__).resolve().parent
PERF = STAGE.parent
ROOT = PERF.parent.parent
BASELINE = 'd829f5b6e6a75ee8859d38d537d224ec33c4930e'


def read(relative):
    return json.loads((PERF / relative).read_text())


def artifact(relative, role):
    file = PERF / relative
    raw = file.read_bytes()
    return {
        'path': 'builds/perf/' + relative,
        'archivePath': 'repo/builds/perf/' + relative,
        'bytes': len(raw),
        'sha256': hashlib.sha256(raw).hexdigest(),
        'role': role,
    }


def pct(value):
    return f'{value:+.2f}%'


def cells_table(summary):
    lines = [
        '| Dictionary / initial order | Candidate B/A | Candidate faster | A/A control D/C | Control faster |',
        '|---|---:|---:|---:|---:|',
    ]
    for dictionary in ['jmdict', 'jmnedict', 'jitendex']:
        for order in ['AB', 'BA']:
            key = dictionary + '-' + order
            cell = summary.get('cells', {}).get(key)
            if not cell or not cell.get('candidateMetrics', {}).get('totalImportMs', {}).get('complete'):
                lines.append(f'| {dictionary} / {order} | Pending | — | Pending | — |')
                continue
            candidate = cell['candidateMetrics']['totalImportMs']
            control = cell['controlMetrics']['totalImportMs']
            lines.append(f'| {dictionary} / {order} | {pct(candidate["pairedMedianPercent"])} | '
                         f'{candidate["secondRoleFasterPairs"]}/{candidate["pairCount"]} | '
                         f'{pct(control["pairedMedianPercent"])} | '
                         f'{control["secondRoleFasterPairs"]}/{control["pairCount"]} |')
    return '\n'.join(lines)


def main():
    now = datetime.now(timezone.utc).isoformat()
    decisions = json.loads((STAGE / 'decision-status.json').read_text())
    gates = json.loads((STAGE / 'gate-status.json').read_text())
    storage = read('ci-storage-confirm/confirmation-summary.json')
    parser = read('ci-parser-confirm/confirmation-summary.json')
    parser_complete = parser.get('completeSuccessfulConfirmation') is True
    state = 'Final evidence snapshot' if decisions['parserFinal'] and decisions['gatesFinal'] else 'Provisional evidence snapshot'
    gate_rows = '\n'.join(f'| `{name}` | {value["status"]} | {value["detail"]} |' for name, value in gates.items())
    oracle_rows = []
    total_rows = 0
    for dictionary in ['jmdict', 'jmnedict', 'jitendex']:
        output = read('combined-output-' + dictionary + '.json')
        assert output['complete'] and output['authoritativeTiming'] is False
        oracle = output['summary']['fullOutputOracle']
        assert oracle['beforeAndAfterMatch']
        total_rows += oracle['rows']
        oracle_rows.append(f'| {dictionary} | {oracle["rows"]:,} | {oracle["indexBytes"]:,} | 4 | Equal full and supplemental digests |')
    mutation = read('parser-mutation-combined-seed886619.json')
    assert mutation['complete'] and mutation['ok']
    parser_progress = (f'All {parser["observationsRead"]} planned observations validated across six cells.'
                       if parser_complete else
                       f'The archived interim summary currently contains {parser.get("observationsRead", 0)} of 216 planned observations; remaining cells are pending.')
    report = f'''# Manabitan JMdict import investigation

{state}, generated **{now}**. Baseline: `{BASELINE}`.

## Outcome

The completed reusable change is the benchmark harness fix in [draft PR #757](https://github.com/ManabiIO/manabitan/pull/757). It makes the requested candidate source root reach the measured child process and applies production glossary validation. Its recorded checks passed at [`323e3f1369e5dce86fe8cd86e44c2a739f67a2ff`](https://github.com/ManabiIO/manabitan/commit/323e3f1369e5dce86fe8cd86e44c2a739f67a2ff).

**The storage candidate is not a whole-import optimization and remains unpromoted.** Its metadata index phase improves, but the stronger browser confirmation did not produce a repeatable complete-import benefit. The fused storage follow-on also remains parked after its direct confirmation changed direction.

**Parser decision:** {decisions['parser']}

The investigation retains the failed experiments, unchanged-code controls, invalid initial screen, intermediate source revisions, and every planned observation. Smaller component measurements support choosing experiments; the complete browser import is the relevant performance boundary for this task.

## Complete browser import results

The fixed confirmation protocol uses six independent Linux browser cells: JMdict, JMnedict and Jitendex, each with initial order AB and BA. Each cell contains **12 candidate pairs, four interleaved unchanged-code control pairs, and four predefined warmup observations**. A completed candidate confirmation therefore retains 216 observations: 144 candidate observations, 48 control observations, and 24 warmups. Only the predefined warmups are excluded from statistics. There are no selective retries or discarded slow measurements.

Values below are median paired percent changes. Negative means the second arm is faster. Candidate B/A compares changed code against baseline; control D/C compares two instances of unchanged baseline. AB/BA describes the first pair's order, with subsequent pairs alternating. Phase counters overlap, and worker totals cannot be added to infer elapsed wall time.

### Corrected storage publication

[Completed confirmation run 44603372923](https://github.com/ManabiIO/manabitan/actions/runs/44603372923), source [`88416a0b0403edde1d30e2765c7fb16edbc7f4a0`](https://github.com/ManabiIO/manabitan/commit/88416a0b0403edde1d30e2765c7fb16edbc7f4a0), qualification commit `cf9363ddd01aadb9bc9a9df0b73e514b26c37625`.

{cells_table(storage)}

JMdict is slower by approximately **0.96% and 1.40%**, with only 4/12 faster candidate pairs in each ordering. JMnedict changes from −1.65% to +0.05%; Jitendex's small negative medians coexist with appreciable control variation. These results do not qualify a whole-import improvement.

There is a real localized signal worth preserving for later work: JMdict's metadata-index phase **excluding recent-source caching** is lower in **23/24 pairs**, with paired medians of −26.38% and −26.95%. The larger content-metadata publication boundary has approximately −5.11% and −4.15% paired medians. Neither establishes a faster complete import. The candidate reduces repeated metadata work, but that phase occupies only part of the total task.

The earlier four-pair browser pilot is preserved separately in `repo/builds/perf/ci-storage/storage-summary.json`: whole-import medians were +0.342% for JMdict, −4.242% for JMnedict, and −0.0146% for Jitendex, with order dependence. The stronger fixed confirmation controls the conclusion.

### Combined parser

[Confirmation run 44605775330](https://github.com/ManabiIO/manabitan/actions/runs/44605775330), remote source [`49ecfc8fce6688bcad1838a9d0f8083a1eb3d348`](https://github.com/ManabiIO/manabitan/commit/49ecfc8fce6688bcad1838a9d0f8083a1eb3d348), qualification commit `b4611de92fdc2aad7d3086a837b3fae927226043`.

{parser_progress}

{cells_table(parser)}

JMdict's repeated point estimates, **−3.104% and −2.098%**, are promising, and the native parser phase is lower by approximately **−5.67% and −5.81%**, with 11/12 and 10/12 faster pairs. However, the paired-bootstrap 95% intervals for complete import still include zero in both independent cohorts: **AB [−5.905%, +0.354%]** and **BA [−4.651%, +1.849%]**. These intervals and every pair are retained in `repo/builds/perf/parser-confirmation-uncertainty.json`. Cohorts ran on separate hosts; any pooled calculation is diagnostic and does not qualify promotion. Incomplete whole-browser memory, lookup and reliability gates add further limits. The decision is **HOLD**, with no runtime PR.

The combined source has four narrowly scoped hypotheses: recognize an existing common tag immediately before a closing brace; consume an adjacent comma after a validated child container closes; avoid redundant metadata initialization for strictly validated eight-field rows; and recognize the exact literal structured-content type pair while preserving fallback parsing and ordinary required-field validation. Each change was first built independently. Their combination was declared before its browser comparison; independent component timings are not used to predict an additive speedup.

## Correctness and source identity

The frozen combined local commit is **`87f4a024dcf8199f043774b99ab931828c048f07`**, tree **`f0c4587e7b747506127672d2b01d80680a2997a4`**. The remote product commit has the same tree. Relative to baseline, the complete diff is seven files: parser C source, generated WASM and manifest, two modified parser tests, and two new parser tests. The tracked worktree, committed blobs, and frozen evidence WASM were checked for equality. There is no storage change in this parser candidate.

The parser WASM is 53,509 bytes, SHA-256 **`ffd8611377f5266713462c6f8594ee9a5a76f24dffa7726e6ff6a14d43b216e6`**. Its C source SHA-256 is `6e86d0a9103b31b7c1fdef20c6b54c174e7a669cf6ccaabb46a16ab4a1c0b823`; the manifest is `43fe18f6659201c2c75866c1d547fdef8bc98ef770a105aa4c3cf818153672da`. Builds used pinned LLVM/linker **21.1.8**. All individual identities and test scopes are in the detailed index; the unchanged canonical scanner is separately hashed.

The combined parser passed **533 focused tests across eight suites**, plus scoped lint. Its deterministic direct-WASM checker used seed **886619**, **{mutation['completedCases']:,} cases**, **{mutation['comparisons']:,} candidate comparisons**, and **{mutation['metadataRowsCompared']:,} successful metadata-row comparisons**. It compared all 17 metadata fields, acceptance and rejection, plain and media-hint exports, strict and permissive modes, logical EOF with physical trailing bytes, alignment, poisoned/reused metadata, legacy rows, escapes, duplicate keys/types, required fields, and mutated inputs. All comparisons passed. The separate five-component mutation cohort passed 81,920 comparisons and 118,630 successful metadata-row comparisons; these runs overlap and should not be added as unique input coverage.

The completed whole-corpus checks compare baseline and combined outputs four times per dictionary, in A/B then B/A order, with production glossary validation enabled:

| Dictionary | Fixture rows | Constructed index bytes | Full passes | Result |
|---|---:|---:|---:|---|
{chr(10).join(oracle_rows)}

That covers **{total_rows:,} fixture rows** and **{total_rows * 4:,} row-pass visits**. This does not imply unique definitions across dictionaries. The reports explicitly set `authoritativeTiming: false`; their incidental elapsed fields are not performance evidence. The initially incorrect C-snapshot path failed before parsing and its log is retained.

Browser qualification independently verifies fixture locks, package-entry identities, expected source changes, full row/count and write-byte parity, and a **12-query sampled persisted-content digest with restart**. This is not a full hash of every persisted OPFS content, record and index file. The direct parser oracle is broader over constructed parser/index outputs but does not prove complete persisted database identity. These distinct correctness scopes are recorded without conflating them.

## Earlier experiments and measurement corrections

The first apparent tag A/B comparison was actually **A/A**: all eight observations loaded the baseline WASM because the parent screen ignored the supplied source root. Its approximately +21.9% difference is evidence of noise and a harness defect, not a tag regression. The first CPU profile also omitted `validateGlossaryTypes`, unlike production. It remains a diagnostic hotspot map only. Two later source-root smoke runs verify identities, validation mode, and output equality; their timings are excluded.

Local explicit-WASM warm, group and native controls showed material schedule/JIT/GC variation. One identical-binary native control pinned to CPU 0 still showed −9.97% median current-thread CPU difference. All full raw measurements and equal-work summaries remain archived; these results did not qualify any parser component.

The earliest metadata publication prototype improved its index-only phase in 16/16 pairs, but its full-boundary confirmation fell to −1.15%, and review then found four source-alias failures. The correction is retained in the candidate lineage and passed focused tests. Corrected local publication cohorts showed larger component reductions, including a 48 MiB cache-pressure run with 835 simulated source reads per arm. The browser confirmation above supersedes those component measurements for the whole-import decision. The fused follow-on moved from −20.39% against corrected storage in AB to +12.44% in BA, so it was parked.

The strict-row initialization assembly diagnostic shows six baseline WASM stores versus three stores plus a mode branch. It avoids 52 logical initialized bytes per row, about 27.4 million across JMdict. That is a concrete mechanism, not measured DRAM traffic or an established runtime saving.

## Build and validation limits

The corrected storage source originally froze at local `676808f375170e55552682a797c9189439910e3f`, database SHA-256 `b163391e6b34678d0eed61d66da57f4bf1545dc918c03c2bef45e358f512176d`. It passed 158 focused tests plus 13 overlapping post-lint tests; fused storage passed 184 plus 39 overlapping post-lint tests. Product source identity is recorded independently from subsequent test-only corrections.

The final local test-only correction is `fb7bc7d0f1bdb5951d94bf3bcf4ebe3b266f998d`, tree `981565a0e7ba9d0291d30de6924a2a4db05a4d76`. It fixes unchecked access in a collision assertion; the runtime source hash is unchanged and the measured remote product commit was untouched. The final changed test file passed 13 tests and lint. The terminal validation receipt records every attempt and source identity.

| Preserved gate log | Status | Scope or limitation |
|---|---|---|
{gate_rows}

The interrupted full unit run is explicitly **not a pass**. No complete all-unit-test verdict was recovered. Scoped tests and the successful build cannot substitute for that missing gate. Browser runs were Linux-only; this investigation supplies no cross-runtime or macOS performance qualification, complete peak process-tree memory qualification, or comprehensive cancellation/update/reimport gate.

The harness PR's recorded [Linux CI](https://github.com/ManabiIO/manabitan/actions/runs/44598783611), [restart interruption](https://github.com/ManabiIO/manabitan/actions/runs/44598783535), [link check](https://github.com/ManabiIO/manabitan/actions/runs/44598783642), [workflow lint](https://github.com/ManabiIO/manabitan/actions/runs/44598783685), [CodeQL](https://github.com/ManabiIO/manabitan/actions/runs/44598783536), and [dependency review](https://github.com/ManabiIO/manabitan/actions/runs/44598783643) passed at the cited head. Those checks qualify that harness revision, not every local product experiment.

## Zstd dictionary reuse: a future investigation

Non-timing probes used **native system Zstd 1.5.7**, one real first content block of approximately 4 MiB, and the 16 KiB dictionary. Plain `usingCDict` at level −1 produced the same 432,776 compressed bytes and exact compressed hash as `usingDict`, with exact round trips, while retaining an additional 47,680-byte dictionary object. Inspection of the [pinned upstream implementation](https://github.com/meta/zstd/blob/82d322c4973d9e2968d94047a40892bc6d9a9bdf/lib/compress/zstd_compress.c) explains why: for this known input size, ordinary dictionary creation does not take the precomputed reset path.

An explicit size-matched parameter probe activates that path. Both outputs round-trip every byte; compressed size changes from 432,776 to 432,672 bytes, a 104-byte difference, and frames differ. The context retains the same 549,912 bytes, plus a separate 64,064-byte prepared dictionary. This establishes API feasibility only. There is no timing result, shipped-WASM build, whole-corpus verification, peak-memory or lifecycle qualification. The C/Python/JavaScript probes, library/compiler identities and upstream source context are preserved; reconstructible dictionary-content input and the native executable are excluded.

## Reproduction and evidence integrity

The separately accessible `README.md`, `evidence-index.json`, `archive-inventory.json`, and `ARCHIVE-SHA256SUMS` describe the package. The main compressed archive contains every completed local raw report and CI observation/receipt, exact experiment drivers, source identities, test logs, frozen WASMs, C sources, manifests, and a Git bundle of local experiment heads requiring baseline `{BASELINE}`. The optional trace archive overlays large trace files at their original relative paths. Gzip and xz variants represent identical payloads. Downloaded CI transfer ZIPs are omitted only after every extracted member matches; wrapper hashes and verified member counts remain recorded.

After extraction, run `sha256sum -c SHA256SUMS_MAIN`, and `sha256sum -c SHA256SUMS_TRACES` if traces were extracted. The exact restore map translates original absolute paths into a fresh checkout. Verify the Git bundle against a clone containing the baseline before fetching its heads. Dictionary fixture hashes and lock data are included; fixture ZIPs, dependencies, browser profiles, and extension packages are not.

`repo/builds/perf/investigation-draft.md` and its original index are preserved historical snapshots. The updated top-level report and index supersede their provisional decisions. All raw files remain verbatim. Commands in the index use new output names to avoid overwriting evidence. The bundled qualification workflows retain the fixed order, source/package checks, and complete observation schedule needed to repeat the browser cohorts. Repeating a diagnostic does not change its stated limitations or turn a correctness-only run into timing evidence.
'''
    (STAGE / 'REPORT.md').write_text(report)

    index = read('evidence-index.json')
    index['updatedAtUtc'] = now
    index['decision'] = decisions
    index['historicalSnapshot'] = {
        'path': 'repo/builds/perf/evidence-index.json',
        'note': 'Original local report index preserved verbatim; current decision and additional evidence appear here.',
    }
    index['gateStatus'] = gates
    index['additionalEvidence'] = []
    for relative, role in [
        ('ci-control/control-summary.json', 'Initial independent unchanged-code browser control; raw observations retained'),
        ('ci-storage/storage-summary.json', 'Initial corrected storage browser pilot; not qualifying'),
        ('ci-storage-confirm/confirmation-summary.json', 'Completed fixed whole-import storage confirmation; candidate unpromoted'),
        ('ci-parser-confirm/confirmation-summary.json', 'Fixed whole-import combined parser confirmation; ' + ('complete' if parser_complete else 'partial, pending')),
        ('parser-mutation-combined-seed886619.json', 'Combined candidate direct-WASM differential correctness; no timing'),
        ('parser-product-provenance.json', 'Exact frozen combined tree and full baseline diff file identities'),
        ('parser-confirmation-uncertainty.json', 'Per-cohort paired-bootstrap intervals; any pooled diagnostic is non-qualifying'),
        ('combined-output-jmdict.json', 'Four whole-corpus output verification passes; authoritativeTiming false'),
        ('combined-output-jmnedict.json', 'Four whole-corpus output verification passes; authoritativeTiming false'),
        ('combined-output-jitendex.json', 'Four whole-corpus output verification passes; authoritativeTiming false'),
        ('combined-output-jmdict-missing-source.log', 'Initial source snapshot path failure before parsing'),
        ('zstd-cdict-feasibility.json', 'Native system API feasibility only; not shipped WASM or timing'),
        ('zstd-cdict-input.json', 'Reconstructible real content probe input provenance; content binary excluded'),
        ('zstd-cdict-api-check.json', 'Plain prepared-dictionary equivalence and retained memory; no timing'),
        ('zstd-cdict-source-context.json', 'Pinned upstream source explains plain-CDict path'),
        ('zstd-cdict-explicit-check.json', 'Explicit parameter feasibility; frames differ, exact round trips; no timing'),
    ]:
        index['additionalEvidence'].append(artifact(relative, role))
    index['confirmationSummaries'] = {
        'storage': {k:v for k,v in storage.items() if k != 'cells'},
        'parser': {k:v for k,v in parser.items() if k != 'cells'},
    }
    index['completeWholeCorpusRows'] = total_rows
    index['combinedMutation'] = mutation
    if (PERF / 'storage-original-validation-status.json').exists():
        index['storageValidationFinal'] = read('storage-original-validation-status.json')
        index['additionalEvidence'].append(artifact('storage-original-validation-status.json',
                                                   'Terminal full-gate status, failed attempts, and test-only correction identity'))
    index['archivePolicy'] = {
        'rawEvidence': 'Verbatim complete reports, every planned CI observation and warmup, receipts, package identities, negative/failed/control records',
        'sourceWrites': 'None; only ignored durable-evidence staging is written',
        'restoreMap': 'restore-map.json in archive',
        'perFileSha256': 'manifest.json and SHA256SUMS_MAIN / SHA256SUMS_TRACES in archive',
        'completeGateStatus': decisions['gatesFinal'],
    }
    (STAGE / 'evidence-index.json').write_text(json.dumps(index, indent=2) + '\n')
    print(json.dumps({'generatedAtUtc': now, 'reportWords': len(report.split()),
                      'parserConfirmationComplete': parser_complete,
                      'parserObservationRecords': parser.get('observationsRead'),
                      'gateStatuses': {k:v['status'] for k,v in gates.items()}}, indent=2))


if __name__ == '__main__':
    main()
