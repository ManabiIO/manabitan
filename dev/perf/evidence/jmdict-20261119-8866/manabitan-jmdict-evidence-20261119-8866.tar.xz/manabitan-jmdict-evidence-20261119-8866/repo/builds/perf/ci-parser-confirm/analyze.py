#!/usr/bin/env python3
"""Read fixed confirmation artifacts; preserve every row and predefined pair."""

import hashlib
import json
import math
from pathlib import Path
import statistics


BASE = Path(__file__).resolve().parent
PERF = BASE.parent
BASELINE = 'd829f5b6e6a75ee8859d38d537d224ec33c4930e'
QUALIFIER = 'b4611de92fdc2aad7d3086a837b3fae927226043'
PRODUCT = '49ecfc8fce6688bcad1838a9d0f8083a1eb3d348'
WORKFLOW_SHA256 = '8187e6499c80029a918ee4192177deb1d7ae40ddaa338749ab77e9fd938e5ef1'
BROWSER = '153.0.8010.12'
METRICS = [
    'bulkAddTermsMs', 'contentMetadataPublishMs', 'contentMetadataIndexPublishMs',
    'dedupRecentSourceCacheMs', 'contentCompressMs', 'dedupScanMs',
    'dedupCanonicalScanMs', 'dedupExactCompareMs', 'termRecordEncodeMs',
    'termRecordValidationMs', 'termRecordWriteMs', 'parserParseBankMs',
    'parserSourceInflateMs', 'parserParallelWorkerWallMs',
]
CONTENT_METRICS = [
    'rows', 'parserEncodedContentBytes', 'parserSourceCompressedBytes',
    'parserSourceUncompressedBytes', 'parserRecentContentDedupHitCount',
    'dedupNativeScannedRows', 'dedupNativeBulkPendingRows',
    'dedupNativeExactCandidates', 'dedupPendingHitCount',
    'dedupPersistedHitCount', 'dedupUniqueCount', 'dedupExactFallbackCount',
    'dedupRecentSourceHitCount', 'dedupRecentSourceCacheBytes',
]
WRITE_METRICS = [
    'termContentTotalWriteBytes', 'termContentWriteCallCount',
    'termContentMergedWriteBytes', 'termRecordTotalWriteBytes',
    'termRecordWriteCallCount', 'termRecordLookupIndexWriteBytes',
    'termRecordLookupIndexWriteCallCount',
]
ALL_METRICS = [
    'totalImportMs', 'workerImportMs', *METRICS,
    'metadataIndexExcludingRecentCacheMs', 'metadataBeforeIndexPublicationMs',
]


def read(path):
    return json.loads(path.read_text())


def expected_plan(initial):
    warmups = ['Aw1', 'Bw1', 'Bw2', 'Aw2'] if initial == 'AB' else ['Bw1', 'Aw1', 'Aw2', 'Bw2']
    observations, pairs, controls = list(warmups), [], []
    for number in range(1, 13):
        pair = [f'A{number}', f'B{number}']
        if (number % 2 == 0) != (initial == 'BA'):
            pair.reverse()
        pairs.append(pair)
        observations.extend(pair)
        if number % 3 == 0:
            control_number = number // 3
            control = [f'C{control_number}', f'D{control_number}']
            if (control_number % 2 == 0) != (initial == 'BA'):
                control.reverse()
            controls.append(control)
            observations.extend(control)
    return observations, warmups, pairs, controls


def pair_statistics(rows, schedule, first_role, second_role, metric):
    observations = {row['label']: row for row in rows}
    pairs = []
    for execution_order in schedule:
        first = next(label for label in execution_order if label.startswith(first_role))
        second = next(label for label in execution_order if label.startswith(second_role))
        a = observations.get(first, {}).get('metrics', {}).get(metric)
        b = observations.get(second, {}).get('metrics', {}).get(metric)
        valid = all(isinstance(value, (int, float)) and math.isfinite(value) for value in (a, b))
        pairs.append({
            'executionOrder': execution_order, 'firstRoleLabel': first,
            'secondRoleLabel': second, 'firstRoleMs': a, 'secondRoleMs': b,
            'differenceMs': b - a if valid else None,
            'percent': 100 * (b / a - 1) if valid and a > 0 else None,
            'complete': valid,
        })
    result = {'pairs': pairs, 'complete': all(pair['complete'] for pair in pairs)}
    if not result['complete']:
        return result
    a = [pair['firstRoleMs'] for pair in pairs]
    b = [pair['secondRoleMs'] for pair in pairs]
    percents = [pair['percent'] for pair in pairs]
    result.update({
        'pairCount': len(pairs), 'firstRoleMedianMs': statistics.median(a),
        'secondRoleMedianMs': statistics.median(b),
        'pairedMedianDifferenceMs': statistics.median(pair['differenceMs'] for pair in pairs),
        'pairedMedianPercent': statistics.median(percents) if all(value is not None for value in percents) else None,
        'totalPercent': 100 * (sum(b) / sum(a) - 1) if sum(a) > 0 else None,
        'secondRoleFasterPairs': sum(pair['differenceMs'] < 0 for pair in pairs),
        'pairPercentRange': [min(percents), max(percents)] if all(value is not None for value in percents) else None,
    })
    by_order = {}
    for order in (first_role + second_role, second_role + first_role):
        selected = [pair for pair in pairs if ''.join(label[0] for label in pair['executionOrder']) == order]
        changes = [pair['percent'] for pair in selected]
        by_order[order] = {
            'pairCount': len(selected),
            'pairedMedianPercent': statistics.median(changes) if changes and all(value is not None for value in changes) else None,
            'secondRoleFasterPairs': sum(pair['differenceMs'] < 0 for pair in selected),
        }
    result['byExecutionOrder'] = by_order
    return result


control = read(PERF / 'ci-control/control-summary.json')
pilot = read(PERF / 'ci-storage/storage-summary.json')
baseline_entries = read(PERF / 'ci-control/jmdict/A-package-entry-sha256.json')
candidate_entries = read(BASE / 'expected-package-entry-sha256.json')
report = {
    'runId': 44605775330,
    'runUrl': 'https://github.com/ManabiIO/manabitan/actions/runs/44605775330',
    'baselineSha': BASELINE, 'qualificationSha': QUALIFIER, 'productSourceSha': PRODUCT,
    'workflowSha256': WORKFLOW_SHA256,
    'scope': 'Six independent dictionary/order cells. All 216 planned observations retained; statistics use only the predefined 72 candidate pairs and 24 same-source control pairs. The 24 warmup observations are excluded only by the fixed plan.',
    'interpretation': 'Positive candidate B/A changes mean slower. Positive control D/C changes mean slower. Phase counters overlap and worker totals are not additive wall time. No automatic promotion decision is made.',
    'persistedEvidenceScope': 'Input/package hashes and full count/write-byte metrics, plus 12-query sampled content digest with restart. No complete persisted OPFS content/record/index file hashes are recorded by this harness.',
    'cells': {},
}

for dictionary in ('jmdict', 'jmnedict', 'jitendex'):
    for initial in ('AB', 'BA'):
        cell = f'{dictionary}-{initial}'
        root = BASE / cell
        if not root.exists():
            report['cells'][cell] = {'status': 'pending', 'dictionary': dictionary, 'initialOrder': initial}
            continue
        record = {'status': 'complete', 'dictionary': dictionary, 'initialOrder': initial, 'validationFailures': [], 'observations': []}
        report['cells'][cell] = record
        planned, warmups, pairs, controls = expected_plan(initial)
        observation_inputs = {}
        for label in planned:
            row = {'label': label, 'role': 'warmup' if label in warmups else 'control' if label[0] in 'CD' else 'candidate-pair', 'evidenceFiles': {}, 'evidenceReadErrors': {}}
            inputs = {}
            for name, filename in [('summary', 'summary.json'), ('raw', 'run-1.json'), ('status', 'status.json')]:
                evidence_path = root / label / filename
                row['evidenceFiles'][name] = str(evidence_path.relative_to(BASE))
                try:
                    inputs[name] = read(evidence_path)
                except Exception as error:
                    row['evidenceReadErrors'][name] = str(error)
            if 'status' in inputs:
                row['status'] = inputs['status']
            if 'raw' in inputs:
                row['rawReportStatus'] = inputs['raw'].get('status')
                row['rawFailureReason'] = inputs['raw'].get('failureReason')
            observation_inputs[label] = inputs
            record['observations'].append(row)
        try:
            plan = read(root / 'confirmation-plan.json')
            receipt = read(root / 'cohort-receipt.json')
            identity = read(root / 'package-identity.json')
            lock = read(root / 'dictionaries.lock.json')
            fixture = lock['dictionaries'][dictionary]
            a_entries = read(root / 'A-package-entry-sha256.json')
            b_entries = read(root / 'B-package-entry-sha256.json')
            actual_changes = sorted(name for name in set(a_entries) | set(b_entries) if a_entries.get(name) != b_entries.get(name))
            patch = (root / 'qualification-only.patch').read_text()
            workflow = '\n'.join(line[1:] for line in patch.splitlines() if line.startswith('+') and not line.startswith('+++')) + '\n'
            receipt_rows = {row['label']: row for row in receipt['observations']}
            record.update({'plan': plan, 'receipt': receipt, 'packageIdentity': identity})
            record['identityChecks'] = {
                'fixedPlan': plan['initialOrder'] == initial and plan['observations'] == planned and plan['warmupsExcludedFromTiming'] == warmups and plan['candidatePairing'] == pairs and plan['sameSourceControlPairing'] == controls,
                'completeReceipt': receipt['completeSuccessfulCohort'] is True and receipt['failures'] == [] and receipt['planned'] == planned and receipt['attempted'] == planned and len(receipt['observations']) == 36 and list(receipt_rows) == planned,
                'receiptRoles': receipt['pairing'] == pairs and receipt['controlPairing'] == controls and receipt['warmupsExcludedFromTiming'] == warmups,
                'attemptedFile': (root / 'observations-attempted.txt').read_text().split() == planned,
                'baselineSource': identity['A']['gitSha'] == BASELINE,
                'candidateSource': identity['B']['gitSha'] == QUALIFIER and identity['candidateProductSourceSha'] == PRODUCT,
                'controlSource': identity['C'] == identity['A'] and identity['D'] == identity['A'],
                'sourceFiles': (root / 'baseline-sha.txt').read_text().strip() == BASELINE and (root / 'candidate-source-sha.txt').read_text().strip() == PRODUCT and (root / 'candidate-qualification-sha.txt').read_text().strip() == QUALIFIER,
                'workflowHash': hashlib.sha256(workflow.encode()).hexdigest() == WORKFLOW_SHA256,
                'packageChangeScope': identity['sameSourceControl'] is False and identity['packageEntriesEqual'] is False and identity['changedPackageEntries'] == actual_changes == ['js/dictionary/wasm/term-bank-parser.c', 'lib/term-bank-parser.wasm'],
                'frozenBaselinePackageEntries': a_entries == baseline_entries,
                'frozenCandidatePackageEntries': b_entries == candidate_entries,
                'pinnedArchives': all(identity[arm]['archives'] == {key: {'sha256': value['sha256'], 'sizeBytes': value['sizeBytes']} for key, value in lock['dictionaries'].items()} for arm in ('A', 'B', 'C', 'D')),
                'lockHash': all(identity[arm]['dictionaryLockSha256'] == hashlib.sha256((root / 'dictionaries.lock.json').read_bytes()).hexdigest() for arm in ('A', 'B', 'C', 'D')),
            }
            for row in record['observations']:
                label = row['label']
                try:
                    if row['evidenceReadErrors']:
                        raise ValueError(f"Missing or unreadable observation evidence: {row['evidenceReadErrors']}")
                    summary = observation_inputs[label]['summary']
                    raw = observation_inputs[label]['raw']
                    status = observation_inputs[label]['status']
                    if len(summary['runs']) != 1:
                        raise ValueError('Expected exactly one observation in summary')
                    run = summary['runs'][0]
                    validation, debug = run['validation'], run['importDebug']
                    runtime, benchmark = raw['runtimeDiagnostics'], raw['benchmark']
                    term_phases = [phase for phase in debug['importerPhaseTimings'] if phase['phase'].startswith('term-file-fast-path:')]
                    final_phases = [phase for phase in debug['importerPhaseTimings'] if phase['phase'] == 'bulk-finalization']
                    total_phases = [phase for phase in raw['phases'] if phase['name'] == fixture['label'] + ': total import']
                    if len(term_phases) != 1 or len(final_phases) != 1 or len(total_phases) != 1:
                        raise ValueError('Expected exactly one term fast path, finalization, and raw total-import phase')
                    term, final, raw_total = term_phases[0]['details'], final_phases[0]['details'], total_phases[0]
                    raw_data = raw_total['data']
                    browser_timing = raw_data['browserTiming']
                    metrics = {'totalImportMs': run['totalImportMs'], 'workerImportMs': run['workerImportMs'], **{key: term.get(key) for key in METRICS}}
                    metrics['metadataIndexExcludingRecentCacheMs'] = term['contentMetadataIndexPublishMs'] - term['dedupRecentSourceCacheMs']
                    metrics['metadataBeforeIndexPublicationMs'] = term['contentMetadataPublishMs'] - term['contentMetadataIndexPublishMs']
                    row.update({
                        'metrics': metrics, 'contentCounts': {key: term.get(key) for key in CONTENT_METRICS},
                        'writeMetrics': {key: final.get(key) for key in WRITE_METRICS}, 'status': status,
                        'validation': validation, 'browserVersion': summary['browserVersion'],
                        'gitSha': summary['gitSha'], 'packageSha256': run['packageSha256'],
                        'sourceDirty': summary['source']['dirty'],
                        'opfs': {'mode': runtime['openStorageMode'], 'installed': runtime['opfsSahpoolInstallResult'], 'usesFallbackStorage': debug['usesFallbackStorage']},
                        'flags': {key: benchmark.get(key) for key in ['pinnedDictionaries', 'productionImportDefaults', 'traceEnabled', 'authoritativeTiming', 'phaseProfiling', 'phaseScreenshots', 'processSampling', 'importFlags']},
                    })
                    row['checks'] = {
                        'status': set(status) == {'benchmarkExitCode', 'logExitCode', 'hostBeforeExitCode', 'hostAfterExitCode'} and all(code == 0 for code in status.values()) and raw['status'] == 'success' and raw['skippedVerification'] is False,
                        'sourcePackage': summary['gitSha'] == identity[label[0]]['gitSha'] and run['packageSha256'] == identity[label[0]]['packageSha256'] and raw['packageSha256'] == run['packageSha256'],
                        'cleanSourceProvenance': summary['source']['dirty'] is False and summary['source']['gitSha'] == summary['gitSha'],
                        'fixture': summary['fixture'] == fixture and summary['dictionary'] == dictionary and summary['buildTarget'] == 'chrome',
                        'rawFixture': raw['buildTarget'] == 'chrome' and benchmark['dictionary'] == dictionary and raw_data['kind'] == 'dictionary-import' and raw_data['dictionary'] == fixture['label'],
                        'rawTimingAndDiagnostics': raw_data['importDebug'] == debug and run['totalImportMs'] == browser_timing['completedAtMs'] - browser_timing['startedAtMs'] and run['automationObservedImportMs'] == raw_total['durationMs'],
                        'rawTimingBoundary': browser_timing['trigger'] == 'file-input-change' and browser_timing['errorCount'] == 0 and browser_timing['sequenceBefore'] == 0 and browser_timing['sequence'] == 1,
                        'finiteReportedMetrics': all(isinstance(value, (int, float)) and math.isfinite(value) for value in metrics.values()),
                        'uninstrumentedProduction': summary['authoritativeTiming'] is True and summary['traceEnabled'] is False and summary['importFlags'] is None and benchmark['authoritativeTiming'] is True and benchmark['productionImportDefaults'] is True and benchmark['pinnedDictionaries'] is True and benchmark['importFlags'] is None and all(benchmark[key] is False for key in ['traceEnabled', 'phaseProfiling', 'phaseScreenshots', 'processSampling']),
                        'browser': summary['browserVersion'] == raw['browserVersion'] == BROWSER,
                        'opfs': runtime['openStorageMode'] == 'opfs-sahpool' and runtime['opfsSahpoolInstallResult'] == 'installed' and debug['usesFallbackStorage'] is False,
                        'noErrors': debug['errorCount'] == 0 and debug['addSettingsErrorCount'] == 0,
                        'sampledContent': validation == benchmark['validation'] and validation['title'] == fixture['expectedTitle'] and validation['revision'] == fixture['revision'] and validation['termRows'] == fixture['termRows'] and validation['contentReadable'] is True and validation['probeCount'] >= 12,
                        'restart': validation['restart']['title'] == validation['title'] and validation['restart']['revision'] == validation['revision'] and validation['restart']['termRows'] == validation['termRows'] and validation['restart']['contentReadable'] is True and validation['restart']['probeCount'] >= 12,
                        'digestMatchesControlAndPilot': [validation['outputDigestSha256']] == control['dictionaryResults'][dictionary]['sampledContentDigests'] == pilot['dictionaryResults'][dictionary]['sampledContentDigests'],
                        'receiptMatches': receipt_rows[label]['totalImportMs'] == run['totalImportMs'] and receipt_rows[label]['warmupExcludedFromTiming'] == (label in warmups) and receipt_rows[label]['sameSourceControl'] == (label[0] in 'CD'),
                        'positiveWholeImport': isinstance(run['totalImportMs'], (int, float)) and math.isfinite(run['totalImportMs']) and run['totalImportMs'] > 0,
                    }
                    record['validationFailures'].extend(f'{label}: {name}' for name, valid in row['checks'].items() if not valid)
                except Exception as error:
                    row['readError'] = str(error)
                    record['validationFailures'].append(f'{label}: {error}')
            record['candidateMetrics'] = {metric: pair_statistics(record['observations'], pairs, 'A', 'B', metric) for metric in ALL_METRICS}
            record['controlMetrics'] = {metric: pair_statistics(record['observations'], controls, 'C', 'D', metric) for metric in ALL_METRICS}
            record['countAndWriteMetricComparisons'] = {}
            for category, keys in [('contentCounts', CONTENT_METRICS), ('writeMetrics', WRITE_METRICS)]:
                for metric in keys:
                    values = {row['label']: row.get(category, {}).get(metric) for row in record['observations']}
                    prior = pilot['dictionaryResults'][dictionary]['fullCountAndWriteMetricComparisons'][metric]['observations']
                    prior_control = pilot['dictionaryResults'][dictionary]['countAndWriteMetricsAgainstControl'][metric]['controlObservations']
                    record['countAndWriteMetricComparisons'][metric] = {
                        'observations': values,
                        'equalAcrossAll36': len(set(values.values())) == 1 and all(value is not None for value in values.values()),
                        'matchesAllControlAndPilotValues': len(set(values.values()) | set(prior.values()) | set(prior_control.values())) == 1 and all(value is not None for value in values.values()),
                    }
            record['validationFailures'].extend(f'identity: {name}' for name, valid in record['identityChecks'].items() if not valid)
            record['allObservationChecksPassed'] = not record['validationFailures']
            record['countAndWriteParityPreserved'] = all(value['equalAcrossAll36'] and value['matchesAllControlAndPilotValues'] for value in record['countAndWriteMetricComparisons'].values())
        except Exception as error:
            record['status'] = 'incomplete'
            record['validationFailures'].append(f'cell evidence: {error}')
            record['allObservationChecksPassed'] = False

report['completeSuccessfulConfirmation'] = len(report['cells']) == 6 and all(cell.get('allObservationChecksPassed') is True and cell.get('countAndWriteParityPreserved') is True for cell in report['cells'].values())
report['observationRecords'] = sum(len(cell.get('observations', [])) for cell in report['cells'].values())
report['observationsRead'] = sum('metrics' in row for cell in report['cells'].values() for row in cell.get('observations', []))
report['warmupsRetainedAndExcluded'] = sum(row['role'] == 'warmup' for cell in report['cells'].values() for row in cell.get('observations', []))
(BASE / 'confirmation-summary.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
for cell, record in report['cells'].items():
    output = {'cell': cell, 'status': record['status'], 'checksPassed': record.get('allObservationChecksPassed'), 'countAndWriteParityPreserved': record.get('countAndWriteParityPreserved'), 'failures': record.get('validationFailures')}
    for category in ('candidateMetrics', 'controlMetrics'):
        metric = record.get(category, {}).get('totalImportMs')
        if metric:
            output[category] = {key: value for key, value in metric.items() if key != 'pairs'}
    print(json.dumps(output))
print(json.dumps({'completeSuccessfulConfirmation': report['completeSuccessfulConfirmation'], 'observationsRead': report['observationsRead'], 'warmupsRetainedAndExcluded': report['warmupsRetainedAndExcluded']}))
