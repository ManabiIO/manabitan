import assert from 'node:assert/strict'
import {readFile, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {parseArgs} from 'node:util'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
import os from 'node:os'

const {values} = parseArgs({options: {
  root: {type: 'string', default: '/workspace/scratch/8866feedb165/storage-candidate'},
  'baseline-root': {type: 'string', default: '/workspace/scratch/8866feedb165/manabitan'},
  dictionary: {type: 'string', default: 'jmdict'},
  cache: {type: 'string', default: '/workspace/scratch/8866feedb165/manabitan/builds/e2e-dictionary-cache'},
  runs: {type: 'string'},
  pairs: {type: 'string', default: '8'},
  'initial-order': {type: 'string', default: 'AB'},
  out: {type: 'string'},
  'cache-mib': {type: 'string', default: '96'}
}})
const root = path.resolve(values.root)
const baselineRoot = path.resolve(values['baseline-root'])
const singleRoot = typeof values.runs === 'string'
const repetitions = Number(singleRoot ? values.runs : values.pairs)
assert(Number.isSafeInteger(repetitions) && repetitions >= (singleRoot ? 1 : 2), 'Invalid run count')
assert(['AB', 'BA'].includes(values['initial-order']), 'Initial order must be AB or BA')
const cacheBytes = Number(values['cache-mib']) * 1024 * 1024
assert(Number.isSafeInteger(cacheBytes) && cacheBytes >= 0, 'Invalid cache budget')
const load = (sourceRoot, file) => import(pathToFileURL(path.join(sourceRoot, file)).href)
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const filesPerGroup = {jmdict: 7, jmnedict: 9, jitendex: 10}[values.dictionary]
assert(filesPerGroup)
const parserFiles = ['ext/js/dictionary/term-bank-wasm-parser.js', 'ext/js/dictionary/term-bank-experiments.js', 'ext/js/dictionary/term-lookup-scratch.js', 'ext/js/dictionary/term-lookup-index-preparation.js', 'ext/js/dictionary/term-lookup-index.js', 'ext/js/dictionary/term-record-preinterned-plan.js']
const sourceFiles = ['ext/js/dictionary/dictionary-database.js', 'ext/js/dictionary/term-content-canonical-scan.js', 'ext/js/dictionary/term-content-metadata-arena.js', 'ext/js/dictionary/term-import-metrics.js', 'ext/js/dictionary/raw-term-content.js', ...parserFiles]
async function loadArm(sourceRoot) {
  const [{DictionaryDatabase}, {NativeCanonicalScanner}, {createTermImportMetrics}, raw] = await Promise.all([
    load(sourceRoot, 'ext/js/dictionary/dictionary-database.js'),
    load(sourceRoot, 'ext/js/dictionary/term-content-canonical-scan.js'),
    load(sourceRoot, 'ext/js/dictionary/term-import-metrics.js'),
    load(sourceRoot, 'ext/js/dictionary/raw-term-content.js')
  ])
  const sourceHashes = Object.fromEntries(await Promise.all(sourceFiles.map(async (file) => [file, sha256(await readFile(path.join(sourceRoot, file)))])))
  const wasmBytes = await readFile(path.join(sourceRoot, 'ext/lib/term-bank-parser.wasm'))
  const canonicalBytes = await readFile(path.join(sourceRoot, 'ext/lib/term-content-canonical-scan-v1.wasm'))
  const lockBytes = await readFile(path.join(sourceRoot, 'test/perf/dictionaries.lock.json'))
  return {
    DictionaryDatabase,
    NativeCanonicalScanner,
    createTermImportMetrics,
    codec: raw.RAW_TERM_CONTENT_TOKEN_DICT_NAME,
    identity: {root: sourceRoot, sourceHashes, parserWasmSha256: sha256(wasmBytes), canonicalWasmSha256: sha256(canonicalBytes), lockSha256: sha256(lockBytes)},
    wasmBytes,
    canonicalBytes,
    lockBytes
  }
}
const arms = singleRoot ? {B: await loadArm(root)} : {A: await loadArm(baselineRoot), B: await loadArm(root)}
if (!singleRoot) {
  for (const name of ['parserWasmSha256', 'canonicalWasmSha256', 'lockSha256']) {
    assert.equal(arms.A.identity[name], arms.B.identity[name], `${name} must match across storage arms`)
  }
  for (const file of parserFiles) assert.equal(arms.A.identity.sourceHashes[file], arms.B.identity.sourceHashes[file], `Parser source differs: ${file}`)
  assert.equal(arms.A.codec, arms.B.codec)
}
const fixtureArm = singleRoot ? arms.B : arms.A
const {ZipReader, Uint8ArrayReader, Uint8ArrayWriter} = await load(fixtureArm.identity.root, 'node_modules/@zip.js/zip.js/index.js')
const parser = await load(fixtureArm.identity.root, 'ext/js/dictionary/term-bank-wasm-parser.js')
const RAW_TERM_CONTENT_TOKEN_DICT_NAME = fixtureArm.codec
const lockBytes = fixtureArm.lockBytes
const spec = JSON.parse(lockBytes).dictionaries[values.dictionary]
const archive = await readFile(path.join(values.cache, spec.cacheFile))
assert.equal(archive.byteLength, spec.sizeBytes)
assert.equal(sha256(archive), spec.sha256)
const wasm = fixtureArm.wasmBytes
const canonical = fixtureArm.canonicalBytes
parser.setTermBankWasmModule(await WebAssembly.compile(wasm))
const canonicalModule = await WebAssembly.compile(canonical)
const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)))
const sources = []
try {
  const entries = (await reader.getEntries()).filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename))
    .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
  for (const entry of entries) sources.push(await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}))
} finally {
  await reader.close()
}
const fixtures = []
for (let start = 0; start < sources.length; start += filesPerGroup) {
  await parser.parseTermBankWithWasmColumnChunks(sources.slice(start, start + filesPerGroup), 3, (chunk) => {
    const {contentBytesBuffer, contentBytesBaseOffset, contentMetaList, contentDedupPlan} = chunk
    assert(contentBytesBuffer && contentMetaList && contentDedupPlan)
    let end = 0
    for (let row = 0; row < chunk.rowCount; ++row) end = Math.max(end, contentMetaList[row * 4] + contentMetaList[row * 4 + 1])
    fixtures.push({
      rowCount: chunk.rowCount,
      contentRowStart: chunk.contentRowStart,
      contentBytesBaseOffset: 0,
      contentBytesBuffer: contentBytesBuffer.slice(contentBytesBaseOffset, contentBytesBaseOffset + end),
      contentMetaList: contentMetaList.slice(),
      contentUniqueIndexList: chunk.contentUniqueIndexList.slice(),
      uniqueRowIndexes: contentDedupPlan.uniqueRowIndexes.slice(),
      uniqueSignatures: contentDedupPlan.uniqueSignatures.slice(),
      uniqueCount: contentDedupPlan.resolvedFlags.length,
      sourceRowCount: contentDedupPlan.sourceRowCount,
      uniformContentDictName: RAW_TERM_CONTENT_TOKEN_DICT_NAME,
      useResolvedContentReferences: true,
      dictionaryTotalRows: spec.termRows,
      contentBytesList: [],
      contentHash1List: [],
      contentHash2List: []
    })
  }, 2048, {singleChunk: true, emitTermByteLists: false, computeContentHashes: true, emitContentSlab: true, emitTokenBinaryContent: true, mediaHintFastScan: true, validateGlossaryTypes: true})
}
assert.equal(fixtures.reduce((sum, group) => sum + group.rowCount, 0), spec.termRows)
sources.length = 0
function digestFixtures() {
  const digest = createHash('sha256')
  for (const fixture of fixtures) {
    digest.update(JSON.stringify([fixture.rowCount, fixture.contentRowStart, fixture.uniqueCount, fixture.sourceRowCount]))
    for (const name of ['contentBytesBuffer', 'contentMetaList', 'contentUniqueIndexList', 'uniqueRowIndexes', 'uniqueSignatures']) {
      const view = fixture[name]
      digest.update(new Uint8Array(view.buffer, view.byteOffset, view.byteLength))
    }
  }
  return digest.digest('hex')
}
const fixtureDigest = digestFixtures()

async function execute(arm) {
  const database = new arm.DictionaryDatabase()
  database._nativeCanonicalScanner = new arm.NativeCanonicalScanner({loadModule: async () => canonicalModule})
  database._recentTermContentSourceCacheMaxBytes = cacheBytes
  const storedContent = new Map()
  let storageReads = 0
  database._readTermEntryContentBytesDetailed = async (offset, length) => {
    ++storageReads
    const bytes = storedContent.get(offset)
    assert(bytes && bytes.byteLength === length)
    return {status: 'ok', bytes}
  }
  let offset = 0x100000000
  const metrics = arm.createTermImportMetrics()
  const samples = []
  const digest = createHash('sha256')
  const update = (view) => digest.update(new Uint8Array(view.buffer, view.byteOffset, view.byteLength))
  for (const fixture of fixtures) {
    const plan = {
      uniqueCount: fixture.uniqueCount,
      sourceRowCount: fixture.sourceRowCount,
      uniqueRowIndexes: fixture.uniqueRowIndexes,
      uniqueSignatures: fixture.uniqueSignatures,
      resolvedFlags: new Uint8Array(fixture.uniqueCount),
      resolvedOffsets: new Float64Array(fixture.uniqueCount),
      resolvedLengths: new Uint32Array(fixture.uniqueCount),
      resolvedDictNames: null,
      pendingEpochs: new Uint32Array(fixture.uniqueCount),
      pendingIndexes: new Uint32Array(fixture.uniqueCount),
      nextEpoch: 1
    }
    const chunk = {...fixture, contentDedupPlan: plan}
    const dedup = await database._resolveArtifactTermContentDedup(chunk, true)
    const count = dedup.pendingContentCount
    const pendingOffsets = new Float64Array(count)
    const pendingLengths = dedup.pendingContentSpans.lengths
    for (let i = 0; i < count; ++i) {
      pendingOffsets[i] = offset
      const sourceOffset = dedup.pendingContentSpans.offsets[i]
      storedContent.set(offset, fixture.contentBytesBuffer.subarray(sourceOffset, sourceOffset + pendingLengths[i]))
      offset += pendingLengths[i] + 1
      const uniqueIndex = dedup.pendingPlanUniqueStart === null ? dedup.pendingPlanUniqueIndexes[i] : dedup.pendingPlanUniqueStart + i
      plan.resolvedFlags[uniqueIndex] = 1
      plan.resolvedOffsets[uniqueIndex] = pendingOffsets[i]
      plan.resolvedLengths[uniqueIndex] = pendingLengths[i]
    }
    plan.resolvedUniformDictName = RAW_TERM_CONTENT_TOKEN_DICT_NAME
    const publication = {
      ...dedup,
      count: fixture.rowCount,
      pendingOffsets,
      pendingLengths,
      pendingResolvedDictNames: RAW_TERM_CONTENT_TOKEN_DICT_NAME,
      contentUniqueIndexList: fixture.contentUniqueIndexList,
      importMetrics: metrics,
      metadataValidated: true,
      useResolvedContentReferences: true
    }
    const beforeCache = metrics.dedupRecentSourceCacheMs
    const beforePublish = metrics.contentMetadataIndexPublishMs
    const beforeProjection = metrics.contentMetadataProjectionMs
    const beforeCpu = process.cpuUsage()
    const beforeThreadCpu = typeof process.threadCpuUsage === 'function' ? process.threadCpuUsage() : null
    const before = performance.now()
    const result = database._publishArtifactTermContentMetadata(publication)
    const elapsedMs = performance.now() - before
    const afterThreadCpu = beforeThreadCpu === null ? null : process.threadCpuUsage()
    const cpu = process.cpuUsage(beforeCpu)
    const threadCpuMs = beforeThreadCpu === null ? null : (afterThreadCpu.user + afterThreadCpu.system - beforeThreadCpu.user - beforeThreadCpu.system) / 1000
    const cacheMs = metrics.dedupRecentSourceCacheMs - beforeCache
    const publicationMs = metrics.contentMetadataIndexPublishMs - beforePublish
    assert.equal(result, RAW_TERM_CONTENT_TOKEN_DICT_NAME)
    samples.push({rows: fixture.rowCount, pending: count, persistedHits: dedup.persistedHitCount, exactFallbacks: dedup.exactFallbackCount, wallMs: elapsedMs, cpuMs: (cpu.user + cpu.system) / 1000, threadCpuMs, cacheMs, publicationMs, indexPublishWithoutCacheMs: publicationMs - cacheMs, projectionMs: metrics.contentMetadataProjectionMs - beforeProjection})
    assert.equal(database._termEntryContentMetaHashPairPendingCount, 0)
    for (let row = 0; row < fixture.rowCount; ++row) {
      const unique = fixture.contentUniqueIndexList[row]
      assert.equal(plan.resolvedFlags[unique], 1)
    }
    update(plan.resolvedFlags)
    update(plan.resolvedOffsets)
    update(plan.resolvedLengths)
  }
  const denseCount = database._termEntryContentMetaDenseCount
  for (const name of ['Hash1', 'Hash2', 'State', 'Id', 'Offset', 'Length', 'DictNameId', 'SignaturePresent', 'Signature1', 'Signature2', 'Signature3', 'RecentSourceBatchId', 'RecentSourceOffset']) {
    update(database[`_termEntryContentMeta${name}Table`].subarray(0, denseCount))
  }
  for (const [id, bytes] of database._recentTermContentSourceBatches) {
    digest.update(String(id))
    update(bytes)
  }
  return {wallMs: samples.reduce((sum, row) => sum + row.wallMs, 0), cpuMs: samples.reduce((sum, row) => sum + row.cpuMs, 0), threadCpuMs: samples.some((row) => row.threadCpuMs === null) ? null : samples.reduce((sum, row) => sum + row.threadCpuMs, 0), cacheMs: metrics.dedupRecentSourceCacheMs, publicationMs: metrics.contentMetadataIndexPublishMs, indexPublishWithoutCacheMs: metrics.contentMetadataIndexPublishMs - metrics.dedupRecentSourceCacheMs, projectionMs: metrics.contentMetadataProjectionMs, cacheBytes: database._recentTermContentSourceBatchBytes, denseCount, uniqueCount: database._termEntryContentMetaHashPairCount, storageReads, digest: digest.digest('hex'), samples}
}
const loadBefore = os.loadavg()
const startedAt = new Date().toISOString()
const runnerSha256 = sha256(await readFile(new URL(import.meta.url)))
const warmups = []
const observations = []
let expectedDigest = null
const metadata = {
  label: 'Real-dictionary metadata-publication component replay; deterministic reserved offsets, no OPFS I/O or compression',
  mode: singleRoot ? 'single-root' : 'same-process-paired',
  armIdentity: Object.fromEntries(Object.entries(arms).map(([name, arm]) => [name, arm.identity])),
  parserFixtureRoot: fixtureArm.identity.root,
  dictionary: values.dictionary,
  archiveSha256: spec.sha256,
  fixtureDigest,
  runnerSha256,
  parserOptions: {singleChunk: true, emitTermByteLists: false, computeContentHashes: true, emitContentSlab: true, emitTokenBinaryContent: true, mediaHintFastScan: true, validateGlossaryTypes: true},
  node: process.version,
  timingBoundary: 'Synchronous _publishArtifactTermContentMetadata invocation, including recent source cache; fixture parsing, reservation, canonical resolution, simulated source storage and all digest verification excluded',
  cpuBoundaries: {cpuMs: 'process CPU; includes V8 and GC worker threads', threadCpuMs: 'current main-thread CPU only, if supported'},
  explicitGcBetweenObservations: typeof globalThis.gc === 'function',
  warmupsPerArm: 3,
  repetitions,
  initialOrder: values['initial-order'],
  cacheBudgetBytes: cacheBytes,
  filesPerGroup,
  rows: spec.termRows,
  groupCount: fixtures.length,
  startedAt,
  loadBefore
}
async function save(complete, summary = null) {
  const output = JSON.stringify({...metadata, complete, endedAt: complete ? new Date().toISOString() : null, loadAfter: os.loadavg(), maxRssKiB: process.resourceUsage().maxRSS, warmups, observations, summary}, null, 2)
  if (values.out) await writeFile(values.out, output + '\n')
  else if (complete) console.log(output)
}
async function observe(armName, pair, warmup) {
  const observationLoadBefore = os.loadavg()
  const observationStartedAt = new Date().toISOString()
  const result = await execute(arms[armName])
  if (expectedDigest === null) expectedDigest = result.digest
  assert.equal(result.digest, expectedDigest, `Output mismatch for ${armName} ${warmup ? 'warmup' : 'pair'} ${pair + 1}`)
  const row = {pair, arm: armName, startedAt: observationStartedAt, loadBefore: observationLoadBefore, loadAfter: os.loadavg(), result}
  if (warmup) warmups.push(row)
  else observations.push(row)
  globalThis.gc?.()
  await save(false)
}
const orderFor = (pair) => singleRoot ? 'B' : (pair % 2 === 0 ? values['initial-order'] : [...values['initial-order']].reverse().join(''))
for (let warmup = 0; warmup < 3; ++warmup) {
  for (const arm of orderFor(warmup)) await observe(arm, warmup, true)
}
for (let pair = 0; pair < repetitions; ++pair) {
  for (const arm of orderFor(pair)) await observe(arm, pair, false)
}
for (const arm of Object.values(arms)) {
  for (const file of sourceFiles) assert.equal(arm.identity.sourceHashes[file], sha256(await readFile(path.join(arm.identity.root, file))), `Source changed during run: ${file}`)
  assert.equal(arm.identity.parserWasmSha256, sha256(await readFile(path.join(arm.identity.root, 'ext/lib/term-bank-parser.wasm'))))
  assert.equal(arm.identity.canonicalWasmSha256, sha256(await readFile(path.join(arm.identity.root, 'ext/lib/term-content-canonical-scan-v1.wasm'))))
}
assert.equal(digestFixtures(), fixtureDigest, 'Shared fixture mutated during replay')
assert.equal(sha256(await readFile(new URL(import.meta.url))), runnerSha256, 'Runner changed during replay')
const median = (numbers) => {
  const sorted = [...numbers].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  return sorted.length % 2 === 1 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2
}
const summary = {}
for (const metric of ['wallMs', 'cpuMs', 'threadCpuMs', 'cacheMs', 'publicationMs', 'indexPublishWithoutCacheMs', 'projectionMs']) {
  const candidate = observations.filter((row) => row.arm === 'B').map((row) => row.result[metric])
  if (candidate.some((value) => value === null)) {
    summary[metric] = null
    continue
  }
  if (singleRoot) {
    summary[metric] = {median: median(candidate), samples: candidate}
    continue
  }
  const baseline = observations.filter((row) => row.arm === 'A').map((row) => row.result[metric])
  if (baseline.some((value) => value === null)) {
    summary[metric] = null
    continue
  }
  const differences = []
  const ratios = []
  for (let pair = 0; pair < repetitions; ++pair) {
    const a = observations.find((row) => row.pair === pair && row.arm === 'A').result
    const b = observations.find((row) => row.pair === pair && row.arm === 'B').result
    for (const name of ['digest', 'cacheBytes', 'denseCount', 'uniqueCount', 'storageReads']) assert.equal(a[name], b[name], `Pair ${pair + 1} differs in ${name}`)
    differences.push(b[metric] - a[metric])
    ratios.push(a[metric] > 0 ? b[metric] / a[metric] : null)
  }
  summary[metric] = {baselineMedian: median(baseline), candidateMedian: median(candidate), pairedMedianChangeMs: median(differences), pairedMedianPercent: ratios.every((value) => value !== null) ? (median(ratios) - 1) * 100 : null, candidateFasterPairs: differences.filter((value) => value < 0).length, pairCount: repetitions, pairedDifferencesMs: differences, pairedRatios: ratios}
}
await save(true, summary)
