#!/usr/bin/env python3
"""Audit the frozen four-pair durability screen without changing its evidence.

Usage: python analyze_durability_screen.py EXTRACTED_JOB [EXTRACTED_JOB ...]
Prints JSON to stdout. All two warmups and sixteen measured observations must
be present. Candidate B/A and same-product D/C controls remain separate.
"""

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import sys


ORDER = "C1 D1 D2 C2 A1 B1 B2 A2 B3 A3 A4 B4 C3 D3 D4 C4".split()
WARMUPS = ["warmup-A", "warmup-B"]
CHECKPOINT_KEYS = ["CheckpointCount", "CheckpointBytes", "CheckpointMs", "FinalFlushMs"]
CHECKPOINT_PREFIX = "termRecordLookupIndex"
ALLOWED_PACKAGE_CHANGES = {
    "js/dictionary/term-record-import-index-writer.js",
    "js/dictionary/term-record-opfs-store.js",
    "js/dictionary/dictionary-database.js",
}
# These are retained and compared separately, never silently omitted. They can
# vary with asynchronous admission/coalescing while logical input stays fixed.
OPERATIONAL_KEYS = {
    "parserParallelPeakQueuedOwnedContentBytes",
    "fastPathParserParallelPeakQueuedOwnedContentBytes",
    "termRecordLookupIndexWriteCallCount",
    "termRecordLookupIndexMaxQueuedBytes",
}
for _prefix in ("termContent", "termRecord"):
    OPERATIONAL_KEYS.update(_prefix + suffix for suffix in (
        "DrainCycleCount", "WriteCallCount", "SingleChunkWriteCount",
        "MergedWriteCount", "MergedWriteBytes", "MaxWriteBytes", "MinWriteBytes",
        "MergedGroupChunkCount", "MaxMergedGroupChunkCount", "MinMergedGroupChunkCount",
        "FlushDueToBytesCount", "FlushDueToChunkCount", "FlushFinalGroupCount",
    ))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def finite(value, label, positive=False):
    require(type(value) in (int, float) and math.isfinite(value)
            and (value > 0 if positive else value >= 0),
            f"{label}: invalid nonnegative finite number {value!r}")
    return value


def same_number(left, right, label):
    finite(left, label)
    finite(right, label)
    require(math.isclose(left, right, rel_tol=0, abs_tol=1e-7),
            f"{label}: values disagree ({left!r}, {right!r})")


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def canonical_hash(value):
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                            allow_nan=False).encode())


def read_json(path):
    raw = path.read_bytes()
    return json.loads(raw), sha256(raw)


def flatten(value, prefix=""):
    """Keep every scalar, and retain empty containers rather than losing fields."""
    if isinstance(value, dict) and value:
        for key, child in value.items():
            yield from flatten(child, f"{prefix}.{key}" if prefix else key)
    elif isinstance(value, list) and value:
        for index, child in enumerate(value):
            yield from flatten(child, f"{prefix}[{index}]")
    else:
        yield prefix, value


def collect_phases(debug):
    metrics, fixed_work, operational, mechanism = {}, {}, {}, {}
    phase_shape = {}
    for group in ("importerPhaseTimings", "localPhaseTimings"):
        phases = debug.get(group)
        require(isinstance(phases, list) and phases, f"Missing {group}")
        phase_shape[group] = [phase["phase"] for phase in phases]
        for index, phase in enumerate(phases):
            prefix = f"{group}[{index}]:{phase['phase']}"
            metrics[prefix + ".elapsedMs"] = finite(phase["elapsedMs"], prefix)
            for key, value in flatten(phase.get("details", {})):
                path = prefix + ".details." + key
                root_key = key.split(".", 1)[0].split("[", 1)[0]
                if root_key in {CHECKPOINT_PREFIX + key for key in CHECKPOINT_KEYS}:
                    mechanism[path] = value
                if key.endswith("Ms"):
                    # Epoch boundaries live on phase objects, outside details.
                    metrics[path] = finite(value, path) if value is not None else None
                elif root_key in {CHECKPOINT_PREFIX + key for key in CHECKPOINT_KEYS}:
                    continue
                elif root_key in OPERATIONAL_KEYS:
                    operational[path] = value
                else:
                    fixed_work[path] = value
    fixed_work["phaseShape"] = phase_shape
    for key in ("hasResult", "errorCount", "addSettingsErrorCount", "usesFallbackStorage",
                "fallbackDatabaseContentBase64Length", "useImportSession", "finalizeImportSession"):
        if key in debug:
            fixed_work["importDebug." + key] = debug[key]
    return metrics, fixed_work, operational, mechanism


def read_observation(directory, name, comparison):
    where = f"{directory}/{name}"
    summary, summary_hash = read_json(directory / name / "summary.json")
    report, report_hash = read_json(directory / name / "run-1.json")
    arm = name[-1] if name.startswith("warmup-") else name[0]
    require(summary["dictionary"] == comparison["dictionary"], f"{where}: dictionary changed")
    require(summary["gitSha"] == comparison["checkoutShas"][arm], f"{where}: checkout changed")
    require(summary["fixture"] == comparison["fixture"], f"{where}: fixture changed")
    require(summary["browserVersion"] == comparison["browser"], f"{where}: browser changed")
    require(summary["buildTarget"] == report["buildTarget"] == "chrome", f"{where}: wrong target")
    require(summary["authoritativeTiming"] is True and summary["traceEnabled"] is False
            and summary["importFlags"] is None, f"{where}: timing mode changed")
    require(report["status"] == "success" and report["skippedVerification"] is False,
            f"{where}: unsuccessful or unverified run")
    benchmark = report["benchmark"]
    require(benchmark["authoritativeTiming"] is True and benchmark["traceEnabled"] is False
            and benchmark["importFlags"] is None, f"{where}: raw timing mode changed")
    require(benchmark["productionImportDefaults"] is True and benchmark["pinnedDictionaries"] is True,
            f"{where}: production/default fixture path changed")
    require(report["browserVersion"] == comparison["browser"], f"{where}: raw browser changed")
    require(len(summary["runs"]) == 1, f"{where}: expected one summarized run")
    run = summary["runs"][0]
    require(run["packageSha256"] == report["packageSha256"] == comparison["packageHashes"][arm],
            f"{where}: package identity changed")
    require(run["validation"] == comparison["validation"] == benchmark["validation"],
            f"{where}: sampled stored content/media validation changed")
    imports = [phase["data"] for phase in report["phases"]
               if isinstance(phase.get("data"), dict)
               and phase["data"].get("kind") == "dictionary-import"]
    require(len(imports) == 1, f"{where}: expected one complete dictionary import")
    imported = imports[0]
    timing, debug = imported["browserTiming"], imported["importDebug"]
    require(timing["trigger"] == "file-input-change", f"{where}: timing boundary changed")
    require(timing["errorCount"] == debug["errorCount"] == debug["addSettingsErrorCount"] == 0,
            f"{where}: import/settings error")
    duration = finite(timing["completedAtMs"] - timing["startedAtMs"], where, positive=True)
    same_number(duration, run["totalImportMs"], where + " total import")
    require(run["importDebug"] == debug, f"{where}: raw/summary import instrumentation differs")
    metrics, work, operational, mechanism = collect_phases(debug)
    metrics = {"completeImportMs": duration, **metrics}
    phases = debug["importerPhaseTimings"]
    finals = [phase for phase in phases if phase["phase"] == "bulk-finalization"]
    banks = [phase for phase in phases if phase["phase"] == "import-data-banks"]
    fast = [phase for phase in phases if phase["phase"].startswith("term-file-fast-path:")]
    require(len(finals) == len(banks) == 1 and finals[0]["details"]["ok"] is True,
            f"{where}: expected successful data/finalization phases")
    require(fast and sum(phase["details"]["rows"] for phase in fast) == comparison["fixture"]["termRows"],
            f"{where}: complete parser row count changed")
    require(banks[0]["details"]["terms"] == comparison["fixture"]["termRows"],
            f"{where}: complete importer term count changed")
    details = finals[0]["details"]
    checkpoints = {key: {"present": CHECKPOINT_PREFIX + key in details,
                         "value": details.get(CHECKPOINT_PREFIX + key)} for key in CHECKPOINT_KEYS}
    if arm == "B":
        require(all(item["present"] for item in checkpoints.values()), f"{where}: missing checkpoint metrics")
        for key, item in checkpoints.items():
            finite(item["value"], where + " " + key)
        require(checkpoints["CheckpointCount"]["value"] > 0
                and checkpoints["CheckpointBytes"]["value"] > 0,
                f"{where}: checkpoint path did not activate")
    else:
        require(all(not item["present"] or item["value"] == 0 for item in checkpoints.values()),
                f"{where}: baseline contains active candidate checkpoint instrumentation")
    return {"arm": arm, "metrics": metrics, "work": work, "operational": operational,
            "mechanism": mechanism, "checkpointMetrics": checkpoints,
            "bulkFinalizationMs": finals[0]["elapsedMs"],
            "hashes": {"summarySha256": summary_hash, "rawReportSha256": report_hash,
                       "packageSha256": report["packageSha256"],
                       "sampledValidationCanonicalSha256": canonical_hash(run["validation"])}}


def paired_metric(observations, metric, left_arm, right_arm):
    names = [f"{arm}{index}" for index in range(1, 5) for arm in (left_arm, right_arm)]
    missing = [name for name in names if observations[name]["metrics"].get(metric) is None]
    if missing:
        return {"available": False, "expectedPairCount": 4, "missingObservations": missing,
                "valuesByObservation": {name: observations[name]["metrics"].get(metric) for name in names}}
    pairs = []
    for index in range(1, 5):
        left_name, right_name = f"{left_arm}{index}", f"{right_arm}{index}"
        left, right = (observations[name]["metrics"][metric] for name in (left_name, right_name))
        pairs.append({"pair": index, "left": left_name, "right": right_name,
                      "order": sorted((left_name, right_name), key=ORDER.index),
                      "leftMs": left, "rightMs": right, "differenceMs": right - left,
                      "changePercent": 100 * (right / left - 1) if left else None})
    lefts = [pair["leftMs"] for pair in pairs]
    rights = [pair["rightMs"] for pair in pairs]
    percentages = [pair["changePercent"] for pair in pairs]
    return {"available": True, "pairCount": 4,
            "leftMedianMs": statistics.median(lefts), "rightMedianMs": statistics.median(rights),
            "medianPairedDifferenceMs": statistics.median(pair["differenceMs"] for pair in pairs),
            "medianPairedChangePercent": statistics.median(percentages) if None not in percentages else None,
            "equalWorkTotalChangePercent": 100 * (sum(rights) / sum(lefts) - 1) if sum(lefts) else None,
            "fasterPairs": sum(right < left for left, right in zip(lefts, rights)),
            "slowerPairs": sum(right > left for left, right in zip(lefts, rights)),
            "equalPairs": sum(right == left for left, right in zip(lefts, rights)), "pairs": pairs}


def equality(observations, field):
    keys = sorted({key for observation in observations.values() for key in observation[field]})
    equal, differing = {}, {}
    for key in keys:
        values = {name: {"present": key in observation[field], "value": observation[field].get(key)}
                  for name, observation in observations.items()}
        first = next(iter(values.values()))
        if all(value == first for value in values.values()):
            equal[key] = first["value"]
        else:
            differing[key] = values
    return {"allEqual": not differing, "fieldCount": len(keys),
            "equalValues": equal, "differingValuesByObservation": differing}


def verify_comparison(directory):
    comparison, comparison_hash = read_json(directory / "comparison.json")
    require(comparison["comparisonKind"] == "exploratory-durability-screen-with-bracketing-controls",
            f"{directory}: incorrect comparison type")
    require(comparison["warmups"] == 2 and comparison["measuredImports"] == 16
            and comparison["pairCount"] == comparison["unchangedCodeControlPairCount"] == 4,
            f"{directory}: incomplete declared cohort")
    require([row["name"] for row in comparison["observations"]] == ORDER,
            f"{directory}: measured order changed")
    require((directory / "observation-order.txt").read_text().split() == ORDER,
            f"{directory}: order file changed")
    observed_dirs = {path.name for path in directory.iterdir() if path.is_dir()
                     and (re.fullmatch(r"[ABCD]\d+", path.name) or path.name.startswith("warmup-"))}
    require(observed_dirs == set(ORDER + WARMUPS), f"{directory}: unexpected/missing observation directories")
    baseline, candidate, qualification = (comparison[key] for key in
                                           ("baselineSha", "candidateSha", "qualificationSha"))
    require(candidate == qualification and candidate != baseline, f"{directory}: source identities changed")
    expected = {"A": baseline, "B": candidate, "C": baseline, "D": baseline}
    require(comparison["productSourceShas"] == comparison["checkoutShas"] == expected,
            f"{directory}: source/checkout arm identity changed")
    for filename, value in (("baseline-sha.txt", baseline), ("candidate-sha.txt", candidate),
                            ("qualification-sha.txt", qualification)):
        require((directory / filename).read_text().strip() == value, f"{directory}: {filename} mismatch")
    hashes = comparison["packageHashes"]
    require(hashes["A"] == hashes["C"] == hashes["D"] and hashes["B"] != hashes["A"],
            f"{directory}: control/candidate package identity mismatch")
    old, old_hash = read_json(directory / "baseline-package-entry-sha256.json")
    new, new_hash = read_json(directory / "candidate-package-entry-sha256.json")
    changes = {key for key in old.keys() | new.keys() if old.get(key) != new.get(key)}
    require(changes == ALLOWED_PACKAGE_CHANGES == set(comparison["changedPackageEntries"]),
            f"{directory}: unexpected package change set")
    require(old["lib/term-bank-parser.wasm"] == new["lib/term-bank-parser.wasm"],
            f"{directory}: parser WASM changed")
    require(comparison["identicalSampledContentAndMedia"] is True,
            f"{directory}: stored content/media guard failed")
    return comparison, {"comparisonSha256": comparison_hash,
                        "baselinePackageEntryMapSha256": old_hash,
                        "candidatePackageEntryMapSha256": new_hash}


def analyze(directory):
    directory = directory.resolve()
    comparison, input_hashes = verify_comparison(directory)
    all_observations = {name: read_observation(directory, name, comparison) for name in WARMUPS + ORDER}
    observations = {name: all_observations[name] for name in ORDER}
    for declared in comparison["observations"]:
        name = declared["name"]
        observation = observations[name]
        require(declared["arm"] == observation["arm"], f"{directory}/{name}: declared arm differs")
        same_number(declared["milliseconds"], observation["metrics"]["completeImportMs"], name)
        same_number(declared["bulkFinalizationMs"], observation["bulkFinalizationMs"], name + " finalization")
        for key in CHECKPOINT_KEYS:
            value = observation["checkpointMetrics"][key]
            same_number(declared["flushMetrics"][key], value["value"] if value["present"] else 0,
                        name + " checkpoint " + key)
    metric_keys = sorted({key for item in observations.values() for key in item["metrics"]})
    candidate = {key: paired_metric(observations, key, "A", "B") for key in metric_keys}
    control = {key: paired_metric(observations, key, "C", "D") for key in metric_keys}
    for values, field in ((candidate, "pairedChangesPercent"), (control, "controlChangesPercent")):
        actual = [pair["changePercent"] for pair in values["completeImportMs"]["pairs"]]
        require(len(actual) == len(comparison[field]) == 4, f"{directory}: missing declared pairs")
        for actual_value, declared_value in zip(actual, comparison[field]):
            require(math.isclose(actual_value, declared_value, rel_tol=0, abs_tol=1e-9),
                    f"{directory}: declared paired complete duration differs")
    fixed = equality(all_observations, "work")
    for filename in ("verify-import-comparison.py", "import-optimization-comparison.yml",
                     "qualification-vndb-overlay.py", "measurement-overlay-sha256.txt"):
        path = directory / filename
        if path.exists():
            input_hashes[filename] = sha256(path.read_bytes())
    return {
        "directory": str(directory),
        "identity": {key: comparison[key] for key in ("dictionary", "baselineSha", "candidateSha",
            "qualificationSha", "productSourceShas", "checkoutShas", "browser", "fixture", "timingBoundary")},
        "schedule": {"warmups": WARMUPS, "measured": ORDER, "candidatePairs": 4, "controlPairs": 4},
        "qualification": {
            "all18ImportsSuccessfulAndVerified": True,
            "allSampledContentAndMediaIdentical": True,
            "completeParserAndImporterRowCountsMatchFixture": True,
            "allFixedReportedWorkAndConfigurationEqual": fixed["allEqual"],
            "allCandidateImportsActivatedCheckpoints": True,
            "phaseMetricCount": len(metric_keys),
        },
        "candidateComparisons_B_over_A": candidate,
        "sameProductControls_D_over_C": control,
        "fixedReportedWorkAndConfigurationEqualityIncludingWarmups": fixed,
        "timingDependentOperationalWorkIncludingWarmups": equality(all_observations, "operational"),
        "declaredCheckpointMechanismDifferencesIncludingWarmups": equality(all_observations, "mechanism"),
        "checkpointMetricsByObservation": {name: item["checkpointMetrics"] for name, item in all_observations.items()},
        "inputHashes": {**input_hashes, "observations": {name: item["hashes"] for name, item in all_observations.items()}},
        "notes": [
            "All fixed observations retained; warmups validated but excluded from paired timing statistics.",
            "Four candidate B/A pairs and four same-product D/C controls are separate; no control subtraction or pooling.",
            "Every importer/local phase duration and numeric details field ending in Ms is compared; missing instrumentation is never replaced with zero.",
            "Checkpoint metrics absent in the baseline are marked absent. FinalFlushMs has no directly instrumented baseline comparator.",
            "Every non-timing phase-detail leaf is retained in fixed work/configuration, operational work, or declared checkpoint mechanism differences.",
            "Operational fields are queue peaks or write/coalescing counters that can vary with scheduling; their exact values remain visible.",
            "Worker sums and wall intervals overlap; phase durations must not be added to infer critical-path savings.",
            "Reported work equality and sampled restart/readback equality are not an exhaustive persisted-byte or peak-memory proof.",
            "This is a four-pair exploratory screen on one host per corpus; it requires independent confirmation before a speed claim.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directories", nargs="+", type=Path)
    args = parser.parse_args()
    result = {"schemaVersion": 1, "scriptSha256": sha256(Path(__file__).read_bytes()),
              "cohorts": [analyze(directory) for directory in args.directories]}
    print(json.dumps(result, indent=4, allow_nan=False))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        print(f"Analysis failed: {error}", file=sys.stderr)
        sys.exit(1)
