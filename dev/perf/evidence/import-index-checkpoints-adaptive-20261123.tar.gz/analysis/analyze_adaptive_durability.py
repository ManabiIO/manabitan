#!/usr/bin/env python3
"""Audit frozen adaptive durability jobs; preserve each host and decision mode.

Usage: python analyze_adaptive_durability.py --qualification-sha SHA EXTRACTED_JOB [...]
Add --require-complete to require all six jobs. Prints JSON; reads evidence only.
The frozen screen helper beside this file supplies common report validation and
complete field extraction. Its exact hash is checked before any analysis.
"""

import argparse
import json
import math
from pathlib import Path
import re
import statistics
import sys

import analyze_durability_screen as common


COMMON_SHA256 = "901946b409e95d6d0c96e023eb8a5b79fecf12f0f242d31863284f47ba31a58d"
BASELINE_SHA = "5e1f8c12f7ff798ba407323aff675cb23b22af02"
PRODUCT_SHA = "32e7c9144f58268b07f92323e9c0f6f34e1189ed"
PUBLISHED_QUALIFICATION_SHA = "dba340e1548b0b88edfe96aa179c0e7d548e7547"
EXPECTED_CANDIDATE_ENTRIES = {
    "js/dictionary/term-record-import-index-writer.js": "f17389b93c2489c5366bab1f36653c58e5cb2f6cf2cc39f3c7f4e98cf9cc9850",
    "js/dictionary/term-record-opfs-store.js": "4af400818645c21c8abc330c4eda6677c484b23f79cd52fefa8a0e95438a898b",
    "js/dictionary/dictionary-database.js": "033fb1cbaec7e3b80a56bfb82472dd067f4536c2b66ec54e888326fc4375ff65",
}
ORDERS = {
    1: "C1 D1 D2 C2 A1 B1 B2 A2 B3 A3 A4 B4 A5 B5 B6 A6 B7 A7 A8 B8 C3 D3 D4 C4".split(),
    2: "D1 C1 C2 D2 B1 A1 A2 B2 A3 B3 B4 A4 B5 A5 A6 B6 A7 B7 B8 A8 D3 C3 C4 D4".split(),
}
require = common.require



MIB_BYTES = 1024 * 1024
MAX_WRITE_BYTES = 512 * 1024
CHECKPOINT_KEYS = ["CheckpointCount", "CheckpointBytes", "CheckpointMs", "FirstCheckpointBytes", "FirstCheckpointMs",
                   "LastCheckpointBytes", "LastCheckpointMs", "CheckpointDisabledCount", "FinalFlushMs"]
CHECKPOINT_PREFIX = common.CHECKPOINT_PREFIX
CHECKPOINT_POLICY = {"firstMinimumWrittenBytes": 32 * MIB_BYTES, "firstComparison": "strictly-greater",
                     "subsequentBytes": 16 * MIB_BYTES, "minFlushMsPerMiB": 2, "stopAfterAnyCheapFlush": True}
read_json = common.read_json
finite = common.finite
same_number = common.same_number
canonical_hash = common.canonical_hash


def collect_phases(debug):
    metrics, work, operational, mechanism = common.collect_phases(debug)
    for group in ("importerPhaseTimings", "localPhaseTimings"):
        for index, phase in enumerate(debug[group]):
            prefix = f"{group}[{index}]:{phase['phase']}.details."
            for suffix in CHECKPOINT_KEYS:
                key = CHECKPOINT_PREFIX + suffix
                if key not in phase.get("details", {}):
                    continue
                path = prefix + key
                mechanism[path] = phase["details"][key]
                work.pop(path, None)
                operational.pop(path, None)
    return metrics, work, operational, mechanism


def verify_adaptive_metrics(checkpoints, write_bytes, arm, dictionary, label):
    if arm != "B":
        require(all(not item["present"] or item["value"] == 0 for item in checkpoints.values()),
                f"{label}: baseline has adaptive instrumentation/work")
        return {"mode": "baseline", "diagnosticsPresent": all(item["present"] for item in checkpoints.values())}
    require(all(item["present"] for item in checkpoints.values()), f"{label}: adaptive diagnostics missing")
    values = {key: finite(item["value"], label + " " + key) for key, item in checkpoints.items()}
    count, disabled = values["CheckpointCount"], values["CheckpointDisabledCount"]
    require(type(count) is int and type(disabled) is int and disabled in (0, 1), f"{label}: invalid writer/count diagnostics")
    for key in ("CheckpointBytes", "FirstCheckpointBytes", "LastCheckpointBytes"):
        require(type(values[key]) is int, f"{label}: noninteger written byte count")
    if dictionary != "vndb":
        require(write_bytes + 80 <= 32 * MIB_BYTES, f"{label}: small-sidecar premise failed")
        require(all(value == 0 for key, value in values.items() if key != "FinalFlushMs"),
                f"{label}: small sidecar performed a periodic checkpoint")
        return {"mode": "inactive-small-file", "diagnosticsPresent": True,
                "sidecarWrittenBytesIncludingBothHeaders": write_bytes + 80}
    require(count > 0, f"{label}: large-sidecar path inactive")
    first, last, total = (values[key] for key in ("FirstCheckpointBytes", "LastCheckpointBytes", "CheckpointBytes"))
    require(32 * MIB_BYTES < first <= 32 * MIB_BYTES + MAX_WRITE_BYTES,
            f"{label}: first checkpoint is outside the strict initial byte gate")
    require(first <= total <= write_bytes + 80, f"{label}: checkpoint bytes exceed actual writes")
    require(last > 0, f"{label}: missing last checkpoint")
    first_cost = values["FirstCheckpointMs"] / (first / MIB_BYTES)
    last_cost = values["LastCheckpointMs"] / (last / MIB_BYTES)
    first_cheap = values["FirstCheckpointMs"] < (first / MIB_BYTES) * 2
    last_cheap = values["LastCheckpointMs"] < (last / MIB_BYTES) * 2
    require(bool(disabled) == last_cheap, f"{label}: last cost and permanent stop decision disagree")
    if first_cheap:
        require(count == 1 and disabled == 1, f"{label}: continued after a cheap first checkpoint")
    if count == 1:
        require(disabled == 1 and first == last == total, f"{label}: invalid sole-checkpoint state for complete VNDB")
        require(values["FirstCheckpointMs"] == values["LastCheckpointMs"] == values["CheckpointMs"],
                f"{label}: sole-checkpoint timing differs")
    else:
        require(not first_cheap and 16 * MIB_BYTES <= last <= 16 * MIB_BYTES + MAX_WRITE_BYTES,
                f"{label}: invalid continued checkpoint cadence")
        require(first + (count - 1) * 16 * MIB_BYTES <= total
                <= first + (count - 1) * (16 * MIB_BYTES + MAX_WRITE_BYTES),
                f"{label}: cumulative checkpoint bytes violate bounded cadence")
        require(values["CheckpointMs"] >= values["FirstCheckpointMs"] + values["LastCheckpointMs"],
                f"{label}: checkpoint total omits first/last work")
    if not disabled:
        require(write_bytes + 80 - total < 16 * MIB_BYTES,
                f"{label}: enabled cadence left a whole checkpoint interval unflushed")
    return {"mode": "stopped-cheap-writeback" if disabled else "periodic-expensive-writeback",
            "diagnosticsPresent": True, "firstCostMsPerMiB": first_cost, "lastCostMsPerMiB": last_cost,
            "firstCheckpointWasCheap": first_cheap, "lastCheckpointWasCheap": last_cheap,
            "checkpointCount": count, "disabledWriterCount": disabled,
            "singleCheckpointingWriterPremise": "Pinned VNDB fixture uses one lookup-index sidecar"}


def read_adaptive_observation(directory, name, comparison):
    where = f"{directory}/{name}"
    summary, summary_hash = read_json(directory / name / "summary.json")
    report, report_hash = read_json(directory / name / "run-1.json")
    arm = name[-1] if name.startswith("warmup-") else name[0]
    require(summary["dictionary"] == comparison["dictionary"], f"{where}: dictionary changed")
    require(summary["gitSha"] == comparison["checkoutShas"][arm], f"{where}: checkout changed")
    require(summary["fixture"] == comparison["fixture"], f"{where}: fixture changed")
    require(summary["browserVersion"] == comparison["browser"], f"{where}: browser changed")
    require(summary["buildTarget"] == report["buildTarget"] == "chrome", f"{where}: wrong target")
    require(summary["authoritativeTiming"] is True and summary["traceEnabled"] is False
            and summary["importFlags"] is None, f"{where}: timing mode changed")
    require(report["status"] == "success" and report["skippedVerification"] is False,
            f"{where}: unsuccessful or unverified run")
    benchmark = report["benchmark"]
    require(benchmark["authoritativeTiming"] is True and benchmark["traceEnabled"] is False
            and benchmark["importFlags"] is None, f"{where}: raw timing mode changed")
    require(benchmark["productionImportDefaults"] is True and benchmark["pinnedDictionaries"] is True,
            f"{where}: production/default fixture path changed")
    require(report["browserVersion"] == comparison["browser"], f"{where}: raw browser changed")
    require(len(summary["runs"]) == 1, f"{where}: expected one summarized run")
    run = summary["runs"][0]
    require(run["packageSha256"] == report["packageSha256"] == comparison["packageHashes"][arm],
            f"{where}: package identity changed")
    require(run["validation"] == comparison["validation"] == benchmark["validation"],
            f"{where}: sampled stored content/media validation changed")
    imports = [phase["data"] for phase in report["phases"]
               if isinstance(phase.get("data"), dict)
               and phase["data"].get("kind") == "dictionary-import"]
    require(len(imports) == 1, f"{where}: expected one complete dictionary import")
    imported = imports[0]
    timing, debug = imported["browserTiming"], imported["importDebug"]
    require(timing["trigger"] == "file-input-change", f"{where}: timing boundary changed")
    require(timing["errorCount"] == debug["errorCount"] == debug["addSettingsErrorCount"] == 0,
            f"{where}: import/settings error")
    duration = finite(timing["completedAtMs"] - timing["startedAtMs"], where, positive=True)
    same_number(duration, run["totalImportMs"], where + " total import")
    require(run["importDebug"] == debug, f"{where}: raw/summary import instrumentation differs")
    metrics, work, operational, mechanism = collect_phases(debug)
    metrics = {"completeImportMs": duration, **metrics}
    phases = debug["importerPhaseTimings"]
    finals = [phase for phase in phases if phase["phase"] == "bulk-finalization"]
    banks = [phase for phase in phases if phase["phase"] == "import-data-banks"]
    fast = [phase for phase in phases if phase["phase"].startswith("term-file-fast-path:")]
    require(len(finals) == len(banks) == 1 and finals[0]["details"]["ok"] is True,
            f"{where}: expected successful data/finalization phases")
    require(fast and sum(phase["details"]["rows"] for phase in fast) == comparison["fixture"]["termRows"],
            f"{where}: complete parser row count changed")
    require(banks[0]["details"]["terms"] == comparison["fixture"]["termRows"],
            f"{where}: complete importer term count changed")
    details = finals[0]["details"]
    checkpoints = {key: {"present": CHECKPOINT_PREFIX + key in details,
                         "value": details.get(CHECKPOINT_PREFIX + key)} for key in CHECKPOINT_KEYS}
    decision = verify_adaptive_metrics(checkpoints, details["termRecordLookupIndexWriteBytes"], arm, comparison["dictionary"], where)
    return {"arm": arm, "metrics": metrics, "work": work, "operational": operational,
            "mechanism": mechanism, "checkpointMetrics": checkpoints, "checkpointDecision": decision,
            "bulkFinalizationMs": finals[0]["elapsedMs"],
            "hashes": {"summarySha256": summary_hash, "rawReportSha256": report_hash,
                       "packageSha256": report["packageSha256"],
                       "sampledValidationCanonicalSha256": canonical_hash(run["validation"])}}


def verify_comparison(directory, qualification_sha):
    comparison, comparison_hash = common.read_json(directory / "comparison.json")
    require(comparison["comparisonKind"] == "adaptive-index-durability-confirmation-with-bracketing-controls",
            f"{directory}: wrong protocol")
    require(comparison["checkpointPolicy"] == CHECKPOINT_POLICY, f"{directory}: adaptive cutoff/policy changed")
    replication = comparison["replication"]
    require(replication in ORDERS and comparison["dictionary"] in ("jmdict", "jitendex", "vndb"),
            f"{directory}: unknown corpus/replication")
    require(comparison["warmups"] == 2 and comparison["measuredImports"] == 24
            and comparison["pairCount"] == 8 and comparison["unchangedCodeControlPairCount"] == 4,
            f"{directory}: incomplete declared cohort")
    order = ORDERS[replication]
    warmup_order = ["A", "B"] if replication == 1 else ["B", "A"]
    require([item["name"] for item in comparison["observations"]] == order,
            f"{directory}: measured order changed")
    require((directory / "observation-order.txt").read_text().split() == order,
            f"{directory}: order file changed")
    require((directory / "warmup-order.txt").read_text().split() == warmup_order,
            f"{directory}: warmup order changed")
    require(int((directory / "replication.txt").read_text()) == replication,
            f"{directory}: replication file changed")
    actual = {path.name for path in directory.iterdir() if path.is_dir()
              and (re.fullmatch(r"[ABCD]\d+", path.name) or path.name.startswith("warmup-"))}
    require(actual == set(order + common.WARMUPS), f"{directory}: unexpected/missing observations")
    identities = {"baselineSha": BASELINE_SHA, "candidateSha": PRODUCT_SHA,
                  "qualificationSha": qualification_sha}
    for key, expected in identities.items():
        require(comparison[key] == expected, f"{directory}: {key} differs from frozen campaign")
    products = {"A": BASELINE_SHA, "B": PRODUCT_SHA, "C": BASELINE_SHA, "D": BASELINE_SHA}
    checkouts = {**products, "B": qualification_sha}
    require(comparison["productSourceShas"] == products and comparison["checkoutShas"] == checkouts,
            f"{directory}: checkout/product identity mismatch")
    for filename, expected in (("baseline-sha.txt", BASELINE_SHA), ("candidate-sha.txt", PRODUCT_SHA),
                                ("qualification-sha.txt", qualification_sha)):
        require((directory / filename).read_text().strip() == expected,
                f"{directory}: {filename} differs from frozen campaign")
    hashes = comparison["packageHashes"]
    require(hashes["A"] == hashes["C"] == hashes["D"] and hashes["A"] != hashes["B"],
            f"{directory}: same-product or candidate package identity failed")
    old, old_hash = common.read_json(directory / "baseline-package-entry-sha256.json")
    new, new_hash = common.read_json(directory / "candidate-package-entry-sha256.json")
    require(all(new.get(path) == expected for path, expected in EXPECTED_CANDIDATE_ENTRIES.items()),
            f"{directory}: candidate package bytes differ from the frozen adaptive runtime")
    changed = {key for key in old.keys() | new.keys() if old.get(key) != new.get(key)}
    require(changed == common.ALLOWED_PACKAGE_CHANGES == set(comparison["changedPackageEntries"]),
            f"{directory}: package changes exceed the three frozen runtime files")
    require(old["lib/term-bank-parser.wasm"] == new["lib/term-bank-parser.wasm"],
            f"{directory}: native parser changed")
    validation = comparison["validation"]
    fixture = comparison["fixture"]
    require(comparison["identicalSampledContentAndMedia"] is True
            and validation["contentReadable"] is True and validation["probeCount"] == 12
            and validation["termRows"] == fixture["termRows"]
            and validation["restart"]["contentReadable"] is True
            and validation["restart"]["termRows"] == fixture["termRows"],
            f"{directory}: incomplete stored content/restart validation")
    if comparison["dictionary"] == "vndb":
        require(validation["mediaRows"] == fixture["mediaRows"]
                and 0 < validation["generationMedia"]["count"] <= fixture["mediaRows"]
                and validation["packedMediaActivation"]["entries"] == validation["generationMedia"]["count"]
                and validation["mediaBeforeRestart"] == validation["mediaAfterRestart"]
                and len(validation["mediaBeforeRestart"]) == 5
                and "img/cc18737.webp" in [item["path"] for item in validation["mediaBeforeRestart"]],
                f"{directory}: incomplete packed media/restart validation")
    return comparison, {
        "comparisonSha256": comparison_hash,
        "baselinePackageEntryMapSha256": old_hash,
        "candidatePackageEntryMapSha256": new_hash,
        "baselinePackageEntryMapCanonicalSha256": common.canonical_hash(old),
        "candidatePackageEntryMapCanonicalSha256": common.canonical_hash(new),
    }


def paired_metric(observations, metric, left_arm, right_arm, count, order):
    names = [f"{arm}{index}" for index in range(1, count + 1) for arm in (left_arm, right_arm)]
    missing = [name for name in names if observations[name]["metrics"].get(metric) is None]
    if missing:
        return {"available": False, "expectedPairCount": count, "missingObservations": missing,
                "valuesByObservation": {name: observations[name]["metrics"].get(metric) for name in names}}
    pairs = []
    for index in range(1, count + 1):
        left_name, right_name = f"{left_arm}{index}", f"{right_arm}{index}"
        left, right = (observations[name]["metrics"][metric] for name in (left_name, right_name))
        pairs.append({"pair": index, "left": left_name, "right": right_name,
                      "order": sorted((left_name, right_name), key=order.index),
                      "leftMs": left, "rightMs": right, "differenceMs": right - left,
                      "changePercent": 100 * (right / left - 1) if left else None})
    lefts = [pair["leftMs"] for pair in pairs]
    rights = [pair["rightMs"] for pair in pairs]
    percentages = [pair["changePercent"] for pair in pairs]
    return {"available": True, "pairCount": count,
            "leftMedianMs": statistics.median(lefts), "rightMedianMs": statistics.median(rights),
            "medianPairedDifferenceMs": statistics.median(pair["differenceMs"] for pair in pairs),
            "medianPairedChangePercent": statistics.median(percentages) if None not in percentages else None,
            "equalWorkTotalChangePercent": 100 * (sum(rights) / sum(lefts) - 1) if sum(lefts) else None,
            "fasterPairs": sum(right < left for left, right in zip(lefts, rights)),
            "slowerPairs": sum(right > left for left, right in zip(lefts, rights)),
            "equalPairs": sum(right == left for left, right in zip(lefts, rights)), "pairs": pairs}


def analyze(directory, qualification_sha):
    directory = directory.resolve()
    comparison, hashes = verify_comparison(directory, qualification_sha)
    replication = comparison["replication"]
    order = ORDERS[replication]
    warmups = common.WARMUPS if replication == 1 else list(reversed(common.WARMUPS))
    all_observations = {name: read_adaptive_observation(directory, name, comparison) for name in warmups + order}
    observations = {name: all_observations[name] for name in order}
    host_identities = {}
    for declared in comparison["observations"]:
        name = declared["name"]
        item = observations[name]
        require(declared["arm"] == item["arm"], f"{directory}/{name}: arm differs")
        common.same_number(declared["milliseconds"], item["metrics"]["completeImportMs"], name)
        common.same_number(declared["bulkFinalizationMs"], item["bulkFinalizationMs"], name + " finalization")
        for key in CHECKPOINT_KEYS:
            value = item["checkpointMetrics"][key]
            common.same_number(declared["flushMetrics"][key], value["value"] if value["present"] else 0,
                               name + " checkpoint " + key)
        require(declared["checkpointMode"] == item["checkpointDecision"]["mode"],
                f"{directory}/{name}: declared adaptive mode differs")
        for suffix in ("before", "after"):
            filename = f"host-{suffix}.json"
            host, host_hash = common.read_json(directory / name / filename)
            item["hashes"][filename] = host_hash
            identity = {key: host.get(key) for key in ("cpuModel", "logicalCpuCount", "availableParallelism",
                "totalMemoryBytes", "nodeVersion", "v8Version", "platform", "arch", "cgroupCpuQuotaCores")}
            host_identities[f"{name}/{suffix}"] = identity
            item["hashes"][f"uptime-{suffix}.txt"] = common.sha256((directory / name / f"uptime-{suffix}.txt").read_bytes())
    metrics = sorted({key for item in observations.values() for key in item["metrics"]})
    candidate = {key: paired_metric(observations, key, "A", "B", 8, order) for key in metrics}
    control = {key: paired_metric(observations, key, "C", "D", 4, order) for key in metrics}
    for comparisons, field, count in ((candidate, "pairedChangesPercent", 8), (control, "controlChangesPercent", 4)):
        actual = [pair["changePercent"] for pair in comparisons["completeImportMs"]["pairs"]]
        require(len(actual) == len(comparison[field]) == count, f"{directory}: pair counts differ")
        for actual_value, declared_value in zip(actual, comparison[field]):
            require(math.isclose(actual_value, declared_value, rel_tol=0, abs_tol=1e-9),
                    f"{directory}: paired complete durations differ from verifier")
    fixed = common.equality(all_observations, "work")
    for filename in ("verify-import-comparison.py", "import-optimization-comparison.yml",
                     "qualification-vndb-overlay.py", "measurement-overlay-sha256.txt",
                     "qualified-harness.js", "qualified-dictionaries.lock.json",
                     "shared-import-tools-sha256.txt", "shared-harness-sha256.txt"):
        hashes[filename] = common.sha256((directory / filename).read_bytes())
    return {
        "directory": str(directory),
        "identity": {key: comparison[key] for key in ("dictionary", "replication", "baselineSha", "candidateSha",
            "qualificationSha", "productSourceShas", "checkoutShas", "browser", "fixture", "timingBoundary")},
        "schedule": {"warmups": warmups, "measured": order, "candidatePairs": 8, "controlPairs": 4},
        "qualification": {"all26ImportsSuccessfulAndVerified": True,
            "allSampledContentAndMediaIdentical": True,
            "completeParserAndImporterRowCountsMatchFixture": True,
            "allFixedReportedWorkAndConfigurationEqual": fixed["allEqual"],
            "allCandidateCheckpointPoliciesVerified": True, "phaseMetricCount": len(metrics)},
        "candidateComparisons_B_over_A": candidate,
        "sameProductControls_D_over_C": control,
        "fixedReportedWorkAndConfigurationEqualityIncludingWarmups": fixed,
        "timingDependentOperationalWorkIncludingWarmups": common.equality(all_observations, "operational"),
        "declaredCheckpointMechanismDifferencesIncludingWarmups": common.equality(all_observations, "mechanism"),
        "checkpointMetricsByObservation": {name: item["checkpointMetrics"] for name, item in all_observations.items()},
        "checkpointDecisionByObservation": {name: item["checkpointDecision"] for name, item in all_observations.items()},
        "measuredCandidateModeCounts": {mode: sum(item["checkpointDecision"]["mode"] == mode for name, item in observations.items() if name.startswith("B")) for mode in ("inactive-small-file", "stopped-cheap-writeback", "periodic-expensive-writeback")},
        "hostIdentityBySnapshot": host_identities,
        "inputHashes": {**hashes, "observations": {name: item["hashes"] for name, item in all_observations.items()}},
    }


def campaign_checks(cohorts, require_complete=False):
    keys = [(cohort["identity"]["dictionary"], cohort["identity"]["replication"]) for cohort in cohorts]
    require(len(keys) == len(set(keys)), "Duplicate dictionary/replication jobs")
    expected = {(dictionary, replication) for dictionary in ("jmdict", "jitendex", "vndb") for replication in (1, 2)}
    complete = set(keys) == expected
    require(not require_complete or complete, "Expected all six frozen confirmation jobs")
    global_hash_keys = ("baselinePackageEntryMapCanonicalSha256", "candidatePackageEntryMapCanonicalSha256",
                       "verify-import-comparison.py", "import-optimization-comparison.yml",
                       "qualification-vndb-overlay.py", "qualified-harness.js", "qualified-dictionaries.lock.json")
    global_values = {}
    for key in global_hash_keys:
        values = {cohort["inputHashes"][key] for cohort in cohorts}
        require(len(values) == 1, f"Campaign package/harness differs: {key}")
        global_values[key] = next(iter(values))
    replicated = {}
    for dictionary in ("jmdict", "jitendex", "vndb"):
        jobs = [cohort for cohort in cohorts if cohort["identity"]["dictionary"] == dictionary]
        if not jobs:
            continue
        fixtures = {common.canonical_hash(job["identity"]["fixture"]) for job in jobs}
        validation = {item["sampledValidationCanonicalSha256"] for job in jobs
                      for item in job["inputHashes"]["observations"].values()}
        require(len(fixtures) == len(validation) == 1, f"{dictionary}: fixture/readback differs across replications")
        replicated[dictionary] = {"replicationsPresent": sorted(job["identity"]["replication"] for job in jobs),
                                  "fixtureIdentical": True, "sampledReadbackIdentical": True}
    return {"completeSixJobCampaign": complete,
            "missingJobs": [{"dictionary": corpus, "replication": replica} for corpus, replica in sorted(expected - set(keys))],
            "identicalPackageAndHarnessHashes": global_values, "perDictionary": replicated}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directories", nargs="+", type=Path)
    parser.add_argument("--require-complete", action="store_true")
    parser.add_argument("--qualification-sha", required=True, help="Exact published qualification commit for all input jobs")
    args = parser.parse_args()
    require(re.fullmatch(r"[a-f0-9]{40}", args.qualification_sha) is not None, "Expected a full qualification commit SHA")
    require(args.qualification_sha == PUBLISHED_QUALIFICATION_SHA, "Qualification differs from the frozen adaptive campaign")
    common_path = Path(common.__file__)
    require(common.sha256(common_path.read_bytes()) == COMMON_SHA256, "Frozen screen helper changed")
    cohorts = [analyze(directory, args.qualification_sha) for directory in args.directories]
    result = {"schemaVersion": 1, "scriptSha256": common.sha256(Path(__file__).read_bytes()),
              "sharedScreenHelperSha256": COMMON_SHA256,
              "checkpointPolicy": CHECKPOINT_POLICY,
              "qualificationSha": args.qualification_sha,
              "campaignChecks": campaign_checks(cohorts, args.require_complete),
              "cohorts": cohorts,
              "notes": [
                  "Each corpus/replication remains separate; no pooling of hosts, screen observations, or controls.",
                  "Every fixed observation is retained. Warmups are validated and excluded from paired timing summaries.",
                  "B/A uses eight adjacent matched pairs; D/C uses four same-product pairs, with no correction/subtraction.",
                  "Each candidate percentage is calculated from its own paired durations, not a ratio of arm medians.",
                  "All importer/local phase metrics are included; worker sums and wall intervals overlap and are not additive.",
                  "Absent baseline instrumentation remains absent; all nine adaptive checkpoint diagnostics are reported absolutely.",
                  "Small sidecars must not checkpoint. VNDB first/last arithmetic assumes the pinned fixture has one checkpointing writer.",
                  "Adaptive mode is reported for every observation; slow and cheap hosts are not selected, discarded, or pooled.",
                  "All non-timing phase-detail fields remain visible in fixed work/configuration, operational work, or mechanism differences.",
                  "Identical reported work and sampled restart/readback results do not establish exhaustive stored-byte equality or peak memory.",
              ]}
    print(json.dumps(result, indent=4, allow_nan=False))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        print(f"Analysis failed: {error}", file=sys.stderr)
        sys.exit(1)
