#!/usr/bin/env python3
"""Bind the complete fixed adaptive campaign to exact source and artifact bytes."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/scratch/86c25f65109c')
PHASE = ROOT / 'phase-analysis'
REPO = ROOT / 'manabitan-storage-round2'
BASE = '5e1f8c12f7ff798ba407323aff675cb23b22af02'
PRODUCT = '32e7c9144f58268b07f92323e9c0f6f34e1189ed'
QUALIFICATION = 'dba340e1548b0b88edfe96aa179c0e7d548e7547'
COMMITS = {
    'baseline': BASE,
    'productLocal': 'de4d0c4761316b0a7e5f1dc0eb63eed6d9a7d27c',
    'productPublic': PRODUCT,
    'qualificationLocal': 'aa351810399cca8a1fe4ca76eeff70ba59d0dd0e',
    'qualificationPublic': QUALIFICATION,
}
RUNTIME_PATHS = [
    'ext/js/dictionary/dictionary-database.js',
    'ext/js/dictionary/term-record-import-index-writer.js',
    'ext/js/dictionary/term-record-opfs-store.js',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.run(['git', *args], cwd=REPO, check=True, capture_output=True).stdout


def write_new_or_equal(path, data):
    if path.exists():
        assert path.read_bytes() == data, ('Refusing to overwrite', path)
    else:
        with path.open('xb') as stream:
            stream.write(data)


def write_json(path, value):
    write_new_or_equal(path, (json.dumps(value, indent=4, sort_keys=True) + '\n').encode())


def file_input(path, archive_path):
    path = Path(path)
    return {'path': str(path), 'archivePath': archive_path, 'sha256': sha(path.read_bytes())}


def snapshot(commit, path, prefix):
    return {'repo': str(REPO), 'commit': commit, 'path': path,
            'archivePath': f'{prefix}/{path}', 'sha256': sha(git('show', f'{commit}:{path}'))}


analysis_path = PHASE / 'adaptive-durability-complete.json'
analysis = json.loads(analysis_path.read_bytes())
assert analysis['campaignChecks']['completeSixJobCampaign']
assert not analysis['campaignChecks']['missingJobs']
assert analysis['qualificationSha'] == QUALIFICATION
assert len(analysis['cohorts']) == 6
index_path = ROOT / 'adaptive-artifact-index.json'
index = json.loads(index_path.read_bytes())
assert index['runId'] == 45123841069
assert index['qualificationCommit'] == QUALIFICATION
assert len(index['artifacts']) == 6
artifacts = {item['name']: item for item in index['artifacts']}

identities = {}
commit_inputs = []
for label, commit in COMMITS.items():
    raw = git('cat-file', 'commit', commit)
    commit_path = PHASE / f'adaptive-commit-{label}.txt'
    write_new_or_equal(commit_path, raw)
    commit_inputs.append(file_input(commit_path, f'source/commits/{label}.txt'))
    headers = raw.decode().split('\n\n', 1)[0].splitlines()
    identities[label] = {
        'commit': commit,
        'tree': next(line[5:] for line in headers if line.startswith('tree ')),
        'parents': [line[7:] for line in headers if line.startswith('parent ')],
        'commitObjectSha256': sha(raw),
        'runtimeSourceSha256': {path: sha(git('show', f'{commit}:{path}')) for path in RUNTIME_PATHS},
    }
assert identities['productLocal']['tree'] == identities['productPublic']['tree'] == '28c46e332dc76ccea7bf67e1819087b6477c5a3f'
assert identities['qualificationLocal']['tree'] == identities['qualificationPublic']['tree'] == 'ec61ce0c3c58f5cd3ec65486ea8a1260a967385f'
assert not git('diff', '--name-only', PRODUCT, QUALIFICATION, '--', 'ext', 'test').strip()
identities['productAndQualificationRuntimeAndTestsIdentical'] = True
identities['snapshotPolicy'] = 'Runtime and test snapshots come from frozen Git commit blobs. Live worktree production files are not used.'
identity_path = PHASE / 'adaptive-source-identities.json'
write_json(identity_path, identities)

frozen = json.loads((REPO / 'builds/perf/storage-adaptive32-validation/frozen-source-sha256.json').read_bytes())
for path, expected in frozen['sha256'].items():
    assert sha(git('show', f'{PRODUCT}:{path}')) == expected, path
    source_snapshot = REPO / 'builds/perf/storage-adaptive32-validation/source-snapshots' / path
    assert sha(source_snapshot.read_bytes()) == expected, source_snapshot
validation = json.loads((REPO / 'builds/perf/storage-adaptive32-validation/validation-receipt.json').read_bytes())
assert validation['sourceSha256'] == frozen['sha256']
for name, expected in validation['logSha256'].items():
    assert sha((REPO / 'builds/perf/storage-adaptive32-validation' / name).read_bytes()) == expected, name

ci_run_path = PHASE / 'adaptive-ci-run-45123840948.json'
ci_jobs_path = PHASE / 'adaptive-ci-jobs-45123840948.json'
ci_log_path = PHASE / 'adaptive-ci-unit-job-137523535378.log'
ci_run = json.loads(ci_run_path.read_bytes())
ci_jobs = json.loads(ci_jobs_path.read_bytes())
assert ci_run['id'] == 45123840948 and ci_run['head_sha'] == QUALIFICATION and ci_run['conclusion'] == 'success'
assert all(job['conclusion'] in ('success', 'skipped') for job in ci_jobs['jobs'])
unit = next(job for job in ci_jobs['jobs'] if job['id'] == 137523535378)
assert unit['name'] == 'Unit Tests' and unit['conclusion'] == 'success'
clean_log = re.sub(r'\x1b\[[0-9;]*m', '', ci_log_path.read_text())
assert re.search(r'Test Files\s+628 passed', clean_log)
assert re.search(r'Tests\s+14016 passed\s+\|\s+47 skipped', clean_log)
ci_receipt_path = PHASE / 'adaptive-ci-receipt.json'
write_json(ci_receipt_path, {
    'runId': 45123840948, 'qualificationSha': QUALIFICATION, 'conclusion': 'success',
    'runUrl': ci_run['html_url'], 'unitJobId': unit['id'], 'unitJobUrl': unit['html_url'],
    'unitTests': {'testFilesPassed': 628, 'testsPassed': 14016, 'testsSkipped': 47},
    'jobs': [{'id': job['id'], 'name': job['name'], 'conclusion': job['conclusion']} for job in ci_jobs['jobs']],
    'inputSha256': {path.name: sha(path.read_bytes()) for path in (ci_run_path, ci_jobs_path, ci_log_path)},
    'apiAndLogCapture': 'Exact response text returned by the GitHub connector; no ANSI stripping or log filtering in retained source files.',
})

old_recipe = json.loads((PHASE / 'import-index-checkpoints-fixed-recipe.json').read_bytes())
git_snapshots = [entry for entry in old_recipe['gitSnapshots'] if entry['commit'] == BASE]
for path in RUNTIME_PATHS + ['test/term-record-import-checkpoints.test.js']:
    git_snapshots.append(snapshot(PRODUCT, path, 'source/adaptive-candidate'))
for path in ['.github/workflows/import-optimization-comparison.yml',
             'dev/perf/verify-import-comparison.py', 'dev/perf/qualification-vndb-overlay.py']:
    git_snapshots.append(snapshot(QUALIFICATION, path, 'source/adaptive-qualification'))

entry_hashes = {
    'A': {path.removeprefix('ext/'): value for path, value in identities['baseline']['runtimeSourceSha256'].items()},
    'B': {path.removeprefix('ext/'): value for path, value in identities['productPublic']['runtimeSourceSha256'].items()},
}
wasm_hash = sha(git('show', f'{BASE}:dev/data/dictionary-wasm/term-bank-parser.wasm'))
assert wasm_hash == sha(git('show', f'{PRODUCT}:dev/data/dictionary-wasm/term-bank-parser.wasm'))
for values in entry_hashes.values():
    values['lib/term-bank-parser.wasm'] = wasm_hash

zip_inputs = []
summary = []
for cohort in analysis['cohorts']:
    identity = cohort['identity']
    dictionary, replication = identity['dictionary'], identity['replication']
    assert identity['baselineSha'] == BASE and identity['candidateSha'] == PRODUCT
    assert identity['qualificationSha'] == QUALIFICATION
    path = ROOT / 'browser-evidence' / f'pr813-adaptive-{dictionary}-r{replication}'
    zip_path = path.with_suffix('.zip')
    artifact = artifacts[f'adaptive-durability-{dictionary}-replication-{replication}']
    original = zip_path.read_bytes()
    assert len(original) == artifact['size_in_bytes']
    assert sha(original) == artifact['digest'].removeprefix('sha256:')
    comparison = json.loads((path / 'comparison.json').read_bytes())
    assert comparison['checkpointPolicy'] == analysis['checkpointPolicy']
    assert comparison['comparisonKind'] == 'adaptive-index-durability-confirmation-with-bracketing-controls'
    assert cohort['qualification']['all26ImportsSuccessfulAndVerified']
    assert cohort['qualification']['allFixedReportedWorkAndConfigurationEqual']
    assert cohort['qualification']['allCandidateCheckpointPoliciesVerified']
    assert cohort['fixedReportedWorkAndConfigurationEqualityIncludingWarmups']['fieldCount'] == 221
    expected = {key: comparison[key] for key in (
        'dictionary', 'comparisonKind', 'baselineSha', 'candidateSha', 'qualificationSha',
        'checkoutShas', 'productSourceShas', 'pairCount', 'unchangedCodeControlPairCount', 'replication')}
    expected.update({'observationOrder': cohort['schedule']['measured'], 'timedCount': 24, 'warmupCount': 2,
                     'changedPackageEntries': [path.removeprefix('ext/') for path in RUNTIME_PATHS],
                     'expectedPackageEntrySha256': entry_hashes})
    zip_inputs.append({'path': str(zip_path), 'extractRoot': str(path),
                       'archivePrefix': f'browser/adaptive/{dictionary}/r{replication}',
                       'sha256': sha(original), 'sizeBytes': len(original), 'cohort': expected})
    candidate = cohort['candidateComparisons_B_over_A']['completeImportMs']
    control = cohort['sameProductControls_D_over_C']['completeImportMs']
    summary.append({
        'dictionary': dictionary, 'replication': replication,
        'candidateMedianPairedChangePercent': candidate['medianPairedChangePercent'],
        'candidateMedianPairedDifferenceMs': candidate['medianPairedDifferenceMs'],
        'candidateFasterPairs': candidate['fasterPairs'], 'candidatePairs': candidate['pairCount'],
        'controlMedianPairedChangePercent': control['medianPairedChangePercent'],
        'controlPairs': control['pairCount'], 'candidateModeCounts': cohort['measuredCandidateModeCounts'],
    })

file_inputs = [
    file_input(PHASE / 'analyze_adaptive_durability.py', 'analysis/analyze_adaptive_durability.py'),
    file_input(PHASE / 'analyze_durability_screen.py', 'analysis/analyze_durability_screen.py'),
    file_input(analysis_path, 'analysis/adaptive-durability-complete.json'),
    file_input(identity_path, 'source/identities.json'),
    file_input(index_path, 'provenance/workflow-artifact-index.json'),
    file_input(ci_run_path, 'validation/hosted/ci-run-45123840948.json'),
    file_input(ci_jobs_path, 'validation/hosted/ci-jobs-45123840948.json'),
    file_input(ci_log_path, 'validation/hosted/unit-job-137523535378.log'),
    file_input(ci_receipt_path, 'validation/hosted/ci-receipt.json'),
    file_input(Path(__file__), 'packaging/prepare-adaptive-evidence-recipe.py'),
    *commit_inputs,
]
recipe = {
    'schemaVersion': 1,
    'output': str(REPO / 'dev/perf/evidence/import-index-checkpoints-adaptive-20261123.tar.gz'),
    'metadata': {
        'title': 'Adaptive import-index checkpoints: complete fixed two-replica qualification',
        'decision': {
            'status': 'ready-for-review-with-conditional-benefit',
            'reason': 'VNDB expensive-writeback replica improved in all eight pairs with separate near-zero controls. The cheap-writeback replica stopped after one probe and had similar candidate/control change magnitudes, with no demonstrated speedup. Small sidecars never checkpoint and show no demonstrated benefit.',
            'notClaimed': ['Universal or hardware-independent speedup', 'JMdict or Jitendex speedup', 'A cheap-writeback speedup distinguishable from controls', 'Replicated expensive-path benefit across two independent expensive hosts'],
        },
        'baselineSourceSha': BASE, 'candidateProductSourceSha': PRODUCT, 'qualificationSha': QUALIFICATION,
        'workflowRunId': 45123841069, 'ordinaryCiRunId': 45123840948,
        'counts': {'jobs': 6, 'dictionaries': 3, 'independentReplicasPerDictionary': 2,
                   'candidatePairsPerJob': 8, 'sameProductControlPairsPerJob': 4,
                   'timedImports': 144, 'warmupImports': 12, 'authoritativeImportsRetained': 156},
        'checkpointPolicy': analysis['checkpointPolicy'],
        'completeImportResultsByJob': summary,
        'localPublicTreeEquivalence': identities,
        'sameProductPackageAndHarnessMapsIdenticalAcrossAllSixJobs': analysis['campaignChecks']['identicalPackageAndHarnessHashes'],
        'timingInterpretation': 'Every corpus, replication, adaptive mode and same-product control remains separate. No host pooling, control subtraction, tail removal, outcome-dependent retries, or additional timing observations.',
        'correctness': 'All 156 complete imports passed. All 221 fixed work/configuration fields agreed within each job. Complete importer/parser row counts, sampled public content/media readbacks and post-restart probes matched. All 130 phase metrics are retained.',
        'limitations': [
            'One expensive VNDB host and one cheap VNDB host exercised distinct adaptive modes; the expensive-host speedup is conditional evidence, not two independent expensive-host replications.',
            'The cheap-host candidate/control comparison does not establish statistical equivalence. No browser observation exercised an expensive-to-cheap transition; that transition is covered by focused tests.',
            'Reported phases overlap and are not additive; worker timing sums are not critical-path shares.',
            'Sampled public readbacks and complete reported counts do not prove exhaustive byte equality of all stored records.',
            'Memory observations are retained as originally reported; this campaign does not establish production peak memory equivalence.',
        ],
        'sourceSnapshotPolicy': 'Frozen Git blobs bind baseline, candidate product and qualification helpers; local/public tree equivalence is checked. No current mutable runtime files are used.',
        'localValidation': 'Retains all adaptive receipts, frozen source snapshots, the initial test-fixture setup timeout and passing recheck. An unmeasured size-only 32 MiB intermediate is included solely for source/validation provenance.',
        'hostedValidation': 'Ordinary CI run 45123840948 succeeded at qualification dba340e1548b0b88edfe96aa179c0e7d548e7547. Full unit log: 628 test files, 14016 passed tests, 47 skipped tests. Run and all job metadata retained.',
        'priorRejectedCampaign': {'archive': 'import-index-checkpoints-fixed-20261123.tar.gz',
                                  'sha256': 'f895e8c75121e7e538284466c391c38a3afd06866fab789e50b7b1585b79c07c',
                                  'decision': 'Fixed 16 MiB screen improvement failed independent confirmation; retained separately and not pooled with this revision.'},
        'originalWorkflowArtifactIndex': 'provenance/workflow-artifact-index.json',
        'omissions': 'Only duplicate rendered HTML reports are omitted from these six original ZIPs. No adaptive diagnostic trace was collected. Every raw timed and warmup JSON, run log, source map, harness, overlay, verifier, lock, order, host snapshot and comparison is retained exactly.',
    },
    'zipInputs': zip_inputs,
    'fileInputs': file_inputs,
    'treeInputs': [
        {'path': str(REPO / 'builds/perf/storage-adaptive32-validation'), 'archivePrefix': 'validation/local-adaptive'},
        {'path': str(REPO / 'builds/perf/storage-gate32-validation'), 'archivePrefix': 'validation/unmeasured-size-only-intermediate'},
    ],
    'gitSnapshots': git_snapshots,
}
recipe_path = PHASE / 'import-index-checkpoints-adaptive-recipe.json'
write_json(recipe_path, recipe)
print(json.dumps({'recipe': str(recipe_path), 'sha256': sha(recipe_path.read_bytes()),
                  'zipInputs': len(zip_inputs), 'fileInputs': len(file_inputs),
                  'gitSnapshots': len(git_snapshots), 'summary': summary}, indent=2))
