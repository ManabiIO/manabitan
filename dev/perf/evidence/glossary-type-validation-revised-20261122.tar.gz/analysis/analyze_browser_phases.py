#!/usr/bin/env python3
"""Read complete browser cohorts; print paired phase statistics as JSON.

Usage: python analyze_browser_phases.py EXTRACTED_COHORT [EXTRACTED_COHORT ...]
Only A1..A8/B1..B8 run-1.json files are read. No files are written. Warmups,
traces, automation phase durations, and sampled CPU profiles are not timings.
Worker sums overlap each other and wall intervals; do not add phase metrics.
"""

import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys


FAST_COUNTERS = """
batchedFileCount rows chunkCount parserFusedAttempts parserFusedFallbacks
parserDiscardedFusedRows parserBankSpanCount parserEscapedKeyDecodeCount
parserValidatedGlossaryReuseCount parserGlobalExactContentReuseCount
parserFastGlossaryNormalizationCount parserFastGlossaryNormalizationFallbackCount
parserFusedSingleBankGroups parserNativeLookupScratchReusedBytes
parserNativeLookupScratchReuseGroups parserNativeLookupScratchReuseMisses
parserNativeSegmentedLookupSegments parserNativeSegmentedLookupFallbacks
parserDirectLookupArenaSegments parserDirectLookupArenaCopiedBytesAvoided
parserLookupCompactionSourceValidationPasses parserRecentContentDedupHitCount
parserSourceTransferredBytes parserSourceCompressedBytes parserSourceUncompressedBytes
parserBorrowedContentResultCount parserParallelGroupCount parserParallelOwnedContentBytes
parserEncodedContentBytes dedupNativeCallCount dedupNativeScannedRows
dedupNativeBulkPendingRows dedupNativeExactCandidates dedupNativeCopiedInputBytes
dedupNativeCopiedOutputBytes dedupNativeSnapshotBytes dedupNativeFallbackCount
dedupNativeFallbackEligibilityCount dedupNativeFallbackAssetCount
dedupNativeFallbackUnsupportedCount dedupPendingHitCount dedupPersistedHitCount
dedupUniqueCount dedupExactFallbackCount dedupRecentSourceHitCount
dedupRecentSourceCacheBytes dedupRecentSourceAdoptedBytes
""".split()
DATA_COUNTERS = """
terms termMeta kanji kanjiMeta tagMeta media step4MediaZipBatchCount
step4MediaZipBatchEntryCount step4MediaZipBatchRangeBytes
step4MediaZipBatchCompressedBytes step4MediaZipBatchUncompressedBytes
step4SourcePackedMediaEntryCount step4SourcePackedMediaBytes fastPathChunkCount
""".split()
FINAL_COUNTERS = """
termContentTotalWriteBytes termRecordTotalWriteBytes termRecordLookupIndexWriteBytes
""".split()
CONFIG_KEYS = """
parserExperiments parserParallelWorkerCount parserParallelPipelineGroupsPerWorker
parserMaxWasmHeapBytes parserMetaCapacity parserMetaAllocatedBytes
parserContentCapacity parserInitialContentBytesPerRow parserChunkSize
parserMinimalDecode parserParallelSkipReason sourceBatchMaxBytes
sourcePrefetchMaxBytes zipUseWebWorkers sourceFirstBatchFileCount
sourceFirstBatchEstimatedBytes
""".split()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def finite(value, label):
    require(type(value) in (int, float) and math.isfinite(value) and value >= 0,
            f"{label}: expected a finite nonnegative number, got {value!r}")
    return value


def phase_sum(phases, field=None):
    """Missing instrumentation stays missing; never omit a measured pair."""
    if not phases:
        return None
    values = [p.get("elapsedMs") if field is None else p.get("details", {}).get(field)
              for p in phases]
    if any(value is None for value in values):
        return None
    return sum(finite(value, field or "elapsedMs") for value in values)


def counter_fields(phases, keys, prefix):
    result = {}
    for index, phase in enumerate(phases):
        result[f"{prefix}[{index}].phase"] = phase["phase"]
        for key in keys:
            if key in phase.get("details", {}):
                result[f"{prefix}[{index}].{key}"] = phase["details"][key]
    return result


def read_observation(directory, name):
    filename = directory / name / "run-1.json"
    raw = filename.read_bytes()
    report = json.loads(raw)
    require(report.get("status") == "success", f"{filename}: run did not succeed")
    require(report.get("skippedVerification") is False, f"{filename}: verification skipped")
    benchmark = report.get("benchmark", {})
    require(benchmark.get("traceEnabled") is False, f"{filename}: trace timing forbidden")
    require(benchmark.get("authoritativeTiming") is True, f"{filename}: not an authoritative timing run")
    imports = [p["data"] for p in report["phases"]
               if p["name"].endswith(": total import")]
    require(len(imports) == 1, f"{filename}: expected exactly one dictionary import")
    data = imports[0]
    debug = data["importDebug"]
    timing = data["browserTiming"]
    require(timing.get("trigger") == "file-input-change", f"{filename}: unexpected timing boundary")
    require(timing.get("errorCount") == 0 and debug.get("errorCount") == 0,
            f"{filename}: import errors")
    phases = debug["importerPhaseTimings"]
    fast = [p for p in phases if p["phase"].startswith("term-file-fast-path:")]
    banks = [p for p in phases if p["phase"] == "import-data-banks"]
    final = [p for p in phases if p["phase"] == "bulk-finalization"]
    descriptor = [p for p in phases if p["phase"] == "finalize-descriptor"]
    metrics = {
        "endToEndMs": finite(timing["completedAtMs"] - timing["startedAtMs"], "end-to-end"),
        "nativeParseSumMs": phase_sum(fast, "parserParseBankMs"),
        "sourceInflateSumMs": phase_sum(fast, "parserSourceInflateMs"),
        "parserResultCopySumMs": phase_sum(fast, "parserResultCopyMs"),
        "importerTermParseMs": phase_sum(banks, "step4TermParseMs"),
        "termFastPathWallMs": phase_sum(fast),
        "parserWorkerWallMs": phase_sum(fast, "parserParallelWorkerWallMs"),
        "dataBankWallMs": phase_sum(banks),
        "bulkFinalizationMs": phase_sum(final),
        "finalizeDescriptorMs": phase_sum(descriptor),
    }
    work = {
        **counter_fields(fast, FAST_COUNTERS, "fastPath"),
        **counter_fields(banks, DATA_COUNTERS, "dataBanks"),
        **counter_fields(final, FINAL_COUNTERS, "finalization"),
    }
    require(fast and "rows" in fast[0]["details"], f"{filename}: missing workload counters")
    config = counter_fields(fast, CONFIG_KEYS, "fastPath")
    config["importFlags"] = benchmark.get("importFlags")
    return {"metrics": metrics, "work": work, "config": config,
            "reportSha256": hashlib.sha256(raw).hexdigest(),
            "packageSha256": report.get("packageSha256")}


def summarize(observations, metric, count):
    missing = [name for name, value in observations.items() if value["metrics"][metric] is None]
    if missing:
        return {"available": False, "missingObservations": missing, "expectedPairCount": count}
    pairs = []
    for index in range(1, count + 1):
        a = observations[f"A{index}"]["metrics"][metric]
        b = observations[f"B{index}"]["metrics"][metric]
        pairs.append({"pair": index, "baselineMs": a, "candidateMs": b,
                      "differenceMs": b - a, "changePercent": 100 * (b / a - 1) if a else None})
    baseline = [pair["baselineMs"] for pair in pairs]
    candidate = [pair["candidateMs"] for pair in pairs]
    changes = [pair["changePercent"] for pair in pairs]
    return {
        "available": True, "pairCount": count,
        "baselineMedianMs": statistics.median(baseline),
        "candidateMedianMs": statistics.median(candidate),
        "medianPairedDifferenceMs": statistics.median(pair["differenceMs"] for pair in pairs),
        "medianPairedChangePercent": statistics.median(changes) if None not in changes else None,
        "equalWorkTotalChangePercent": 100 * (sum(candidate) / sum(baseline) - 1) if sum(baseline) else None,
        "fasterPairs": sum(b < a for a, b in zip(baseline, candidate)),
        "slowerPairs": sum(b > a for a, b in zip(baseline, candidate)),
        "equalPairs": sum(b == a for a, b in zip(baseline, candidate)),
        "pairs": pairs,
    }


def equality(observations, field, count):
    keys = sorted({key for item in observations.values() for key in item[field]})
    equal, different = {}, {}
    for key in keys:
        values = {name: {"present": key in item[field], "value": item[field].get(key)}
                  for name, item in observations.items()}
        first = next(iter(values.values()))
        if all(value == first for value in values.values()):
            equal[key] = first["value"]
        else:
            different[key] = values
    return {"allEqualAcrossAllObservations": not different, "fieldCount": len(keys),
            "equalValues": equal, "differingValuesByObservation": different,
            "pairEquality": [{"pair": index, "equal": observations[f"A{index}"][field] == observations[f"B{index}"][field]}
                             for index in range(1, count + 1)]}


def analyze(directory, count):
    directory = directory.resolve()
    comparison = json.loads((directory / "comparison.json").read_text())
    require(comparison.get("pairCount") == count, f"{directory}: expected all {count} declared pairs")
    require(comparison.get("measuredImports") == 2 * count, f"{directory}: incomplete declared cohort")
    expected = {f"{arm}{index}" for arm in "AB" for index in range(1, count + 1)}
    order = [item["name"] for item in comparison["observations"]]
    require(len(order) == len(expected) and set(order) == expected,
            f"{directory}: measured observations must contain each A/B pair exactly once")
    actual = {p.name for p in directory.iterdir() if p.is_dir() and p.name[:1] in "AB" and p.name[1:].isdigit()}
    require(actual == expected, f"{directory}: unexpected or missing measured observation directories")
    observations = {name: read_observation(directory, name) for name in order}
    for declared in comparison["observations"]:
        require(math.isclose(observations[declared["name"]]["metrics"]["endToEndMs"], declared["milliseconds"], abs_tol=1e-7),
                f"{directory}: end-to-end duration disagrees with comparison.json")
    metrics = {key: summarize(observations, key, count) for key in next(iter(observations.values()))["metrics"]}
    return {
        "directory": str(directory),
        "identity": {key: comparison.get(key) for key in ("dictionary", "baselineSha", "candidateSha", "browser", "fixture", "timingBoundary")},
        "pairCount": count, "observationOrder": order,
        "notes": ["All measured pairs included; warmups and traces excluded.",
                  "Paired percentages use each Bn/An ratio, not the ratio of arm medians.",
                  "Worker duration sums and wall intervals overlap; phase metrics are not additive.",
                  "Exact counter equality describes reported workload, not exhaustive persisted-byte equality.",
                  "Peak queue sizes and coalescing call counts are timing-dependent and excluded from work equality."],
        "metrics": metrics,
        "workCounterEquality": equality(observations, "work", count),
        "configurationAndCapacityEquality": equality(observations, "config", count),
        "inputHashes": {name: {key: item[key] for key in ("reportSha256", "packageSha256")}
                        for name, item in observations.items()},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directories", nargs="+", type=Path)
    parser.add_argument("--pairs", type=int, default=8, help="Required complete pair count (default: 8)")
    args = parser.parse_args()
    require(args.pairs > 0, "Pair count must be positive")
    result = {"schemaVersion": 1, "scriptSha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "cohorts": [analyze(directory, args.pairs) for directory in args.directories]}
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(f"Analysis failed: {error}", file=sys.stderr)
        sys.exit(1)
