#!/usr/bin/env python3
"""Build or verify deterministic, exact-byte import evidence from a JSON recipe.

build RECIPE: refuses existing output tar/manifest paths; includes all ZIP members
except disclosed rendered HTML and candidate-trace. Each cohort explicitly binds
qualification, checkout and product identities plus complete observation counts.
Same-product controls require identical, nonempty package-entry hash maps.
Optional trees, files and Git blobs preserve component data and source snapshots.
verify ARCHIVE: rehashes every member and rejects extras, omissions or duplicates.
"""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
import zipfile
import zlib


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=4, ensure_ascii=False, sort_keys=True) + "\n").encode()


def safe_name(name):
    path = PurePosixPath(name)
    if not name or path.is_absolute() or ".." in path.parts or str(path) != name or name == ".":
        raise ValueError(f"Invalid archive member path: {name!r}")
    return name


def make_archive(payload):
    result = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=result, mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode="w", format=tarfile.USTAR_FORMAT) as tar:
            for name, data in sorted(payload.items()):
                item = tarfile.TarInfo(safe_name(name))
                item.size = len(data)
                item.mode = 0o644
                item.mtime = item.uid = item.gid = 0
                item.uname = item.gname = ""
                tar.addfile(item, io.BytesIO(data))
    return result.getvalue()


def verify_bytes(data, external_manifest=None):
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tar:
        members = tar.getmembers()
        names = [safe_name(m.name) for m in members]
        assert len(names) == len(set(names)) and names == sorted(names)
        for member in members:
            assert member.isfile() and member.uid == member.gid == member.mtime == 0
            assert member.mode == 0o644 and not member.uname and not member.gname
        manifest_bytes = tar.extractfile("MANIFEST.json").read()
        if external_manifest is not None:
            assert manifest_bytes == external_manifest
        manifest = json.loads(manifest_bytes)
        entries = manifest["files"]
        assert len({e["path"] for e in entries}) == len(entries)
        assert set(names) == {"MANIFEST.json", *(e["path"] for e in entries)}
        for entry in entries:
            payload = tar.extractfile(entry["path"]).read()
            assert len(payload) == entry["bytes"] and digest(payload) == entry["sha256"], entry["path"]
    return {"bytes": len(data), "sha256": digest(data), "payloadFiles": len(entries),
            "manifestBytes": len(manifest_bytes), "manifestSha256": digest(manifest_bytes)}


def inspect_cohort(members, expected):
    comparison = json.loads(members[expected.get("comparisonPath", "comparison.json")])
    order = members[expected.get("orderPath", "observation-order.txt")].decode().split()
    assert comparison["baselineSha"] == expected["baselineSha"]
    assert comparison["candidateSha"] == expected["candidateSha"]
    kind = comparison.get("comparisonKind", "revision-comparison")
    assert kind in ("revision-comparison", "same-product-control")
    assert kind == expected.get("comparisonKind", "revision-comparison")
    qualification = comparison.get("qualificationSha", comparison["candidateSha"])
    assert qualification == expected.get("qualificationSha", expected["candidateSha"])
    products = comparison.get("productSourceShas", {
        "A": comparison["baselineSha"], "B": comparison["candidateSha"]})
    checkouts = comparison.get("checkoutShas", {
        "A": comparison["baselineSha"], "B": qualification})
    assert products == {"A": comparison["baselineSha"], "B": comparison["candidateSha"]}
    assert checkouts == {"A": comparison["baselineSha"], "B": qualification}
    assert products == expected.get("productSourceShas", {
        "A": expected["baselineSha"], "B": expected["candidateSha"]})
    assert checkouts == expected.get("checkoutShas", {
        "A": expected["baselineSha"], "B": qualification})
    if "dictionary" in expected:
        assert comparison["dictionary"] == expected["dictionary"]
    assert members["baseline-sha.txt"].decode().strip() == products["A"]
    assert members["candidate-sha.txt"].decode().strip() == products["B"]
    if "qualification-sha.txt" in members:
        assert members["qualification-sha.txt"].decode().strip() == qualification
    if "comparison-kind.txt" in members:
        assert members["comparison-kind.txt"].decode().strip() == kind
    if kind == "same-product-control":
        for field in ("comparisonKind", "qualificationSha", "checkoutShas", "productSourceShas"):
            assert field in comparison and field in expected, ("Control identity must be explicit", field)
        assert "qualification-sha.txt" in members and "comparison-kind.txt" in members
        assert products["A"] == products["B"], "Control product source commits differ"
        assert members["product-source.txt"].decode().strip() == products["A"]
    else:
        assert products["B"] == qualification, "Revision product differs from qualification commit"

    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            assert key not in result, ("Duplicate package-map entry", key)
            result[key] = value
        return result

    package_maps = {}
    package_map_hashes = {}
    for arm, label in (("A", "baseline"), ("B", "candidate")):
        raw_map = members[f"{label}-package-entry-sha256.json"]
        package_map = json.loads(raw_map, object_pairs_hook=unique_object)
        assert isinstance(package_map, dict) and package_map, "Empty product package map"
        for path, sha in package_map.items():
            safe_name(path)
            assert isinstance(sha, str) and len(sha) == 64 and all(c in "0123456789abcdef" for c in sha)
        assert "lib/term-bank-parser.wasm" in package_map, "Parser WASM package entry missing"
        for path, sha in expected.get("expectedPackageEntrySha256", {}).get(arm, {}).items():
            assert package_map.get(path) == sha, (arm, "Unexpected packaged source hash", path)
        package_maps[arm] = package_map
        package_map_hashes[arm] = digest(raw_map)
    changed_entries = sorted(path for path in package_maps["A"].keys() | package_maps["B"].keys()
                             if package_maps["A"].get(path) != package_maps["B"].get(path))
    assert changed_entries == comparison["changedPackageEntries"], "Reported package differences are incorrect"
    if kind == "same-product-control":
        assert package_maps["A"] == package_maps["B"], "Control product package entries differ"
    assert comparison["measuredImports"] == expected["timedCount"] == len(order)
    assert comparison["pairCount"] == expected["pairCount"]
    assert comparison["warmups"] == expected["warmupCount"]
    observations = comparison["observations"]
    assert [o["name"] for o in observations] == order and len(set(order)) == len(order)
    warmups = sorted({PurePosixPath(n).parts[0] for n in members
                      if n.startswith("warmup-") and len(PurePosixPath(n).parts) > 1})
    assert len(warmups) == expected["warmupCount"]
    expected_report_dirs = set(order + warmups)
    report_dirs = {str(PurePosixPath(n).parent) for n in members
                   if PurePosixPath(n).name == "summary.json" and not n.startswith("candidate-trace/")}
    assert report_dirs == expected_report_dirs, "Incomplete or extra unclassified report directories"
    identities = []
    for name in warmups + order:
        summary = json.loads(members[f"{name}/summary.json"])
        assert isinstance(json.loads(members[f"{name}/run-1.json"]), dict)
        assert f"{name}/run.log" in members
        assert summary["authoritativeTiming"] is True and summary["traceEnabled"] is False
        assert len(summary["runs"]) == 1
        run = summary["runs"][0]
        is_warmup = name in warmups
        observation = None if is_warmup else next(o for o in observations if o["name"] == name)
        arm = name.removeprefix("warmup-") if is_warmup else observation["arm"]
        assert arm in ("A", "B")
        expected_source = checkouts[arm]
        assert summary["gitSha"] == expected_source == summary["source"]["gitSha"]
        assert run["packageSha256"] == comparison["packageHashes"][arm]
        if not is_warmup:
            assert run["totalImportMs"] == observation["milliseconds"]
            for host in ("host-before.json", "host-after.json", "uptime-before.txt", "uptime-after.txt"):
                assert f"{name}/{host}" in members
        identities.append({"name": name, "warmup": is_warmup, "arm": arm,
                           "checkoutSha": checkouts[arm], "productSourceSha": products[arm],
                           "qualificationSha": qualification,
                           "source": summary["source"], "packageSha256": run["packageSha256"]})
    return {"expected": expected, "order": order, "warmups": warmups,
            "comparisonKind": kind, "qualificationSha": qualification,
            "checkoutShas": checkouts, "productSourceShas": products,
            "packageEntryIdentity": {"mapSha256": package_map_hashes,
                "entryCounts": {arm: len(entries) for arm, entries in package_maps.items()},
                "identical": not changed_entries, "changedEntries": changed_entries},
            "fixture": comparison["fixture"], "sourceIdentities": identities,
            "allTimedAndWarmupReportsRetained": True}


def build(recipe_path):
    recipe_bytes = recipe_path.read_bytes()
    recipe = json.loads(recipe_bytes)
    assert recipe["schemaVersion"] == 1
    output = Path(recipe["output"]).resolve()
    assert output.name.endswith(".tar.gz")
    manifest_output = output.with_name(output.name[:-7] + ".manifest.json")
    for path in (output, manifest_output):
        if path.exists():
            raise FileExistsError(path)
    files = []
    payload = {}
    originals = []
    omissions = []
    cohorts = []

    def add(name, data, source, expected_hash=None):
        safe_name(name)
        assert name not in payload and name != "MANIFEST.json", f"Duplicate payload path: {name}"
        if expected_hash is not None:
            assert digest(data) == expected_hash, name
        payload[name] = data
        files.append({"path": name, "bytes": len(data), "sha256": digest(data), "source": source})

    for spec in recipe.get("zipInputs", []):
        path = Path(spec["path"]).resolve()
        original = path.read_bytes()
        if "sha256" in spec:
            assert digest(original) == spec["sha256"], (path, "Original workflow ZIP hash mismatch")
        if "sizeBytes" in spec:
            assert len(original) == spec["sizeBytes"], (path, "Original workflow ZIP size mismatch")
        prefix = safe_name(spec["archivePrefix"])
        with zipfile.ZipFile(io.BytesIO(original)) as zip_input:
            infos = [i for i in zip_input.infolist() if not i.is_dir()]
            assert len({i.filename for i in infos}) == len(infos)
            members = {safe_name(i.filename): zip_input.read(i) for i in infos}
        if spec.get("extractRoot"):
            extracted_root = Path(spec["extractRoot"]).resolve()
            extracted_files = {str(p.relative_to(extracted_root)) for p in extracted_root.rglob("*") if p.is_file()}
            assert extracted_files == set(members), path
            for name, data in members.items():
                assert (extracted_root / name).read_bytes() == data, (path, name)
        if "cohort" in spec:
            cohort = inspect_cohort(members, spec["cohort"])
            cohort.update({"archive": path.name, "archivePrefix": prefix})
            cohorts.append(cohort)
        omitted = 0
        for name, data in sorted(members.items()):
            reason = None
            if PurePosixPath(name).parts[0] == "candidate-trace":
                reason = "Separate post-timing diagnostic trace outside fixed cohort"
            elif PurePosixPath(name).suffix == ".html":
                reason = "Rendered HTML duplicate; original raw JSON reports retained"
            if reason:
                omissions.append({"archive": path.name, "path": name, "bytes": len(data),
                                  "sha256": digest(data), "reason": reason})
                omitted += 1
            else:
                add(f"{prefix}/{name}", data, {"kind": "workflow-artifact-zip-member",
                    "archive": path.name, "member": name})
        originals.append({"path": str(path), "filename": path.name, "bytes": len(original),
                          "sha256": digest(original), "memberCount": len(members),
                          "retainedMemberCount": len(members) - omitted, "omittedMemberCount": omitted,
                          "allExtractedBytesMatchOriginalZip": True if spec.get("extractRoot") else None})
    for spec in recipe.get("treeInputs", []):
        root = Path(spec["path"]).resolve()
        assert root.is_dir()
        for path in sorted(root.rglob("*")):
            assert not path.is_symlink(), path
            if path.is_file():
                assert path.resolve() not in (output, manifest_output), "Output inside an input tree"
                name = f"{safe_name(spec['archivePrefix'])}/{path.relative_to(root)}"
                add(name, path.read_bytes(), {"kind": "workspace-file", "path": str(path)})
    for spec in recipe.get("fileInputs", []):
        path = Path(spec["path"]).resolve()
        add(spec["archivePath"], path.read_bytes(), {"kind": "workspace-file", "path": str(path)}, spec.get("sha256"))
    for spec in recipe.get("gitSnapshots", []):
        result = subprocess.run(["git", "show", f"{spec['commit']}:{spec['path']}"],
                                cwd=spec["repo"], check=True, capture_output=True)
        add(spec["archivePath"], result.stdout, {"kind": "git-blob", "commit": spec["commit"],
            "path": spec["path"]}, spec.get("sha256"))
    add("packaging/recipe.json", recipe_bytes, {"kind": "packaging-recipe", "path": str(recipe_path.resolve())})
    add("packaging/package-import-evidence-generic.py", Path(__file__).read_bytes(), {"kind": "packaging-source"})
    manifest = {"schemaVersion": 1, "archiveName": output.name, "metadata": recipe.get("metadata", {}),
                "cohorts": cohorts, "originalWorkflowArchives": originals,
                "files": sorted(files, key=lambda x: x["path"]),
                "omittedWorkflowMembers": sorted(omissions, key=lambda x: (x["archive"], x["path"])),
                "retentionPolicy": {"originalWorkflowZipBytesEmbedded": False,
                    "originalWorkflowZipSizeAndSha256Preserved": True,
                    "includedMemberBytesPreservedExactly": True,
                    "onlyOmittedZipMembers": ["Rendered .html duplicates", "Separate candidate-trace directory"],
                    "treeAndFileInputsHaveNoOmissions": True},
                "packaging": {"format": "USTAR then gzip level 9", "memberOrder": "lexicographic",
                    "uid": 0, "gid": 0, "mtime": 0, "mode": "0644", "uname": "", "gname": "",
                    "gzipFilename": "", "gzipMtime": 0, "pythonVersion": sys.version.split()[0],
                    "zlibVersion": zlib.ZLIB_VERSION, "manifestExcludedFromItsOwnPayloadHashes": True}}
    manifest_bytes = json_bytes(manifest)
    payload["MANIFEST.json"] = manifest_bytes
    archive_bytes = make_archive(payload)
    assert archive_bytes == make_archive(payload), "Nondeterministic archive output"
    report = verify_bytes(archive_bytes, manifest_bytes)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("xb") as file:
        file.write(archive_bytes)
    with manifest_output.open("xb") as file:
        file.write(manifest_bytes)
    return {"archive": str(output), "manifest": str(manifest_output), **report}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    create = commands.add_parser("build")
    create.add_argument("recipe", type=Path)
    verify = commands.add_parser("verify")
    verify.add_argument("archive", type=Path)
    verify.add_argument("--manifest", type=Path)
    args = parser.parse_args()
    if args.command == "build":
        result = build(args.recipe)
    else:
        external = args.manifest.read_bytes() if args.manifest else None
        result = verify_bytes(args.archive.read_bytes(), external)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
