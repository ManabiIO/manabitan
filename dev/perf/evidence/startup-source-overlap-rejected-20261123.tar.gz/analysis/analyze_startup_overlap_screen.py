#!/usr/bin/env python3
"""Read the frozen PR815 screen and its separate diagnostic Chrome traces."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import statistics


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def trace_summary(path):
    events = json.loads(path.read_text())["traceEvents"]
    handles = {
        event["args"]["data"]["traceId"]: event
        for event in events
        if event["name"] == "HandlePostMessage"
        and "traceId" in event.get("args", {}).get("data", {})
    }
    messages = []
    for event in events:
        if event["name"] != "SchedulePostMessage":
            continue
        data = event.get("args", {}).get("data", {})
        frame = next((frame for frame in data.get("stackTrace", [])
                      if "/term-bank-wasm-parser" in frame.get("url", "")), None)
        if frame is None:
            continue
        handle = handles.get(data["traceId"])
        messages.append({
            "postTimestampUs": event["ts"],
            "handleTimestampUs": handle["ts"] if handle else None,
            "postingThreadId": event["tid"],
            "handlingThreadId": handle["tid"] if handle else None,
            "function": frame.get("functionName", ""),
            "script": frame["url"].split("/")[-1],
            "lineZeroBased": frame.get("lineNumber"),
            "traceId": data["traceId"],
        })
    messages.sort(key=lambda item: item["postTimestampUs"])
    ready = [item for item in messages if item["script"] == "term-bank-wasm-parser-worker.js"
             and item["function"] == "initialize"]
    assert len(ready) == 3 and all(item["handleTimestampUs"] is not None for item in ready)
    owner = [item for item in messages if item["script"] == "term-bank-wasm-parser.js"]
    assert len({item["lineZeroBased"] for item in owner[:3]}) == 1
    assert owner[3]["lineZeroBased"] != owner[0]["lineZeroBased"]
    origin = owner[0]["postTimestampUs"]
    ready_at = max(item["handleTimestampUs"] for item in ready)
    first_parse = owner[3]["postTimestampUs"]
    assert owner[2]["postTimestampUs"] < ready_at < first_parse
    owner_thread = owner[0]["postingThreadId"]

    # Incremental CPU profiles are keyed by process and profile id. Chunks may
    # be emitted on another thread; the Profile record owns the sampled thread.
    profiles = {}
    for event in events:
        if event["name"] == "Profile":
            profiles[(event["pid"], event["id"])] = {
                "thread": event["tid"], "time": event["args"]["data"]["startTime"],
                "nodes": {}, "samples": [],
            }
    for event in events:
        if event["name"] != "ProfileChunk":
            continue
        profile = profiles[(event["pid"], event["id"])]
        data = event["args"]["data"]
        cpu = data.get("cpuProfile", {})
        profile["nodes"].update({node["id"]: node for node in cpu.get("nodes", [])})
        samples = cpu.get("samples", [])
        deltas = data.get("timeDeltas", [])
        assert len(samples) == len(deltas)
        lines = data.get("lines", [None] * len(samples))
        assert len(lines) == len(samples)
        for node, delta, line in zip(samples, deltas, lines):
            profile["time"] += delta
            profile["samples"].append((profile["time"], delta, node, line))
    weights = Counter()
    for profile in profiles.values():
        if profile["thread"] != owner_thread:
            continue
        for timestamp, delta, node_id, line in profile["samples"]:
            # Clip interval weights at the same-owner-thread message boundaries.
            weight = max(0, min(timestamp, first_parse) - max(timestamp - delta, ready_at))
            if weight == 0:
                continue
            frame = profile["nodes"][node_id]["callFrame"]
            weights[(frame.get("functionName", ""), frame.get("url", "").split("/")[-1], line)] += weight / 1000
    return {
        "traceSha256": sha256(path),
        "diagnosticOnly": True,
        "sameThreadBoundary": "owner handles last ready message to owner posts first parse job",
        "originTimestampUs": origin,
        "ownerThreadId": owner_thread,
        "initializePostOffsetsMs": [(item["postTimestampUs"] - origin) / 1000 for item in owner[:3]],
        "readyHandleOffsetsMs": [(item["handleTimestampUs"] - origin) / 1000 for item in ready],
        "lastReadyOffsetMs": (ready_at - origin) / 1000,
        "firstParsePostOffsetMs": (first_parse - origin) / 1000,
        "readyToFirstParseMs": (first_parse - ready_at) / 1000,
        "gapSampleIntervalWeights": [
            {"function": key[0], "script": key[1], "sampleLine": key[2], "milliseconds": value}
            for key, value in weights.most_common()
        ],
        "initialMessages": messages[:9],
        "limitations": [
            "Separate post-cohort traced observation; excluded from timed estimates",
            "No matched baseline trace in this cohort",
            "CPU sample interval weights are approximate attribution, not exact function durations",
            "No explicit Blob read completion event; no direct measurement of overlap savings",
            "Ready/parse boundaries use owner-thread events; cross-thread trace skew is not used",
        ],
    }


def analyze(root):
    result = {"schemaVersion": 1, "decision": "reject", "cohorts": {}}
    for dictionary in ("jmdict", "jitendex", "vndb"):
        directory = root / f"pr815-screen-{dictionary}"
        comparison_path = directory / "comparison.json"
        comparison = json.loads(comparison_path.read_text())
        observations = {item["name"]: item["milliseconds"] for item in comparison["observations"]}
        assert len(observations) == 16 and comparison["pairCount"] == 4
        pairs = [(observations[f"B{i}"] / observations[f"A{i}"] - 1) * 100 for i in range(1, 5)]
        controls = [(observations[f"D{i}"] / observations[f"C{i}"] - 1) * 100 for i in range(1, 5)]
        for actual, expected in zip(pairs, comparison["pairedChangesPercent"]):
            assert abs(actual - expected) < 1e-10
        for actual, expected in zip(controls, comparison["controlChangesPercent"]):
            assert abs(actual - expected) < 1e-10
        assert abs(statistics.median(pairs) - comparison["medianPairedChangePercent"]) < 1e-10
        assert abs(statistics.median(controls) - comparison["medianControlChangePercent"]) < 1e-10
        assert comparison["identicalSampledContentAndMedia"] is True
        item = {key: comparison[key] for key in (
            "baselineSha", "candidateSha", "qualificationSha", "fixture", "baselineMedianMs",
            "candidateMedianMs", "medianPairedChangePercent", "pairedChangesPercent",
            "medianControlChangePercent", "controlChangesPercent", "observations",
            "changedPackageEntries", "identicalSampledContentAndMedia", "validation",
        )}
        item.update({
            "comparisonSha256": sha256(comparison_path),
            "candidateFasterPairs": sum(value < 0 for value in pairs),
            "candidateRangePercent": [min(pairs), max(pairs)],
            "controlRangePercent": [min(controls), max(controls)],
        })
        trace = directory / "candidate-trace/run-1.trace.json"
        if trace.exists():
            item["diagnosticTrace"] = trace_summary(trace)
        result["cohorts"][dictionary] = item
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("evidence_root", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    result = analyze(args.evidence_root)
    args.output.write_text(json.dumps(result, indent=4, sort_keys=True) + "\n")
    print(json.dumps({"output": str(args.output), "sha256": sha256(args.output),
                      "cohorts": {key: {field: value[field] for field in (
                          "medianPairedChangePercent", "medianControlChangePercent", "candidateFasterPairs"
                      )} for key, value in result["cohorts"].items()}}, indent=2))


if __name__ == "__main__":
    main()
