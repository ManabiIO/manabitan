#!/usr/bin/env python3
"""Audit frozen durability confirmation jobs; preserve each host/replication.

Usage: python analyze_durability_confirmation.py EXTRACTED_JOB [EXTRACTED_JOB ...]
Add --require-complete to require all six jobs. Prints JSON; reads evidence only.
The frozen screen helper beside this file supplies common report validation and
complete field extraction. Its exact hash is checked before any analysis.
"""

import argparse
import json
import math
from pathlib import Path
import re
import statistics
import sys

import analyze_durability_screen as common


COMMON_SHA256 = "901946b409e95d6d0c96e023eb8a5b79fecf12f0f242d31863284f47ba31a58d"
BASELINE_SHA = "5e1f8c12f7ff798ba407323aff675cb23b22af02"
PRODUCT_SHA = "5e2335ef34f86b45f8e54b0dd40fa27db0f3bfc8"
QUALIFICATION_SHA = "3ca96a8c8dc075a240f3bc8f5bc7de45efd5d75e"
ORDERS = {
    1: "C1 D1 D2 C2 A1 B1 B2 A2 B3 A3 A4 B4 A5 B5 B6 A6 B7 A7 A8 B8 C3 D3 D4 C4".split(),
    2: "D1 C1 C2 D2 B1 A1 A2 B2 A3 B3 B4 A4 B5 A5 A6 B6 A7 B7 B8 A8 D3 C3 C4 D4".split(),
}
require = common.require


def verify_comparison(directory):
    comparison, comparison_hash = common.read_json(directory / "comparison.json")
    require(comparison["comparisonKind"] == "durability-confirmation-with-bracketing-controls",
            f"{directory}: wrong protocol")
    replication = comparison["replication"]
    require(replication in ORDERS and comparison["dictionary"] in ("jmdict", "jitendex", "vndb"),
            f"{directory}: unknown corpus/replication")
    require(comparison["warmups"] == 2 and comparison["measuredImports"] == 24
            and comparison["pairCount"] == 8 and comparison["unchangedCodeControlPairCount"] == 4,
            f"{directory}: incomplete declared cohort")
    order = ORDERS[replication]
    warmup_order = ["A", "B"] if replication == 1 else ["B", "A"]
    require([item["name"] for item in comparison["observations"]] == order,
            f"{directory}: measured order changed")
    require((directory / "observation-order.txt").read_text().split() == order,
            f"{directory}: order file changed")
    require((directory / "warmup-order.txt").read_text().split() == warmup_order,
            f"{directory}: warmup order changed")
    require(int((directory / "replication.txt").read_text()) == replication,
            f"{directory}: replication file changed")
    actual = {path.name for path in directory.iterdir() if path.is_dir()
              and (re.fullmatch(r"[ABCD]\d+", path.name) or path.name.startswith("warmup-"))}
    require(actual == set(order + common.WARMUPS), f"{directory}: unexpected/missing observations")
    identities = {"baselineSha": BASELINE_SHA, "candidateSha": PRODUCT_SHA,
                  "qualificationSha": QUALIFICATION_SHA}
    for key, expected in identities.items():
        require(comparison[key] == expected, f"{directory}: {key} differs from frozen campaign")
    products = {"A": BASELINE_SHA, "B": PRODUCT_SHA, "C": BASELINE_SHA, "D": BASELINE_SHA}
    checkouts = {**products, "B": QUALIFICATION_SHA}
    require(comparison["productSourceShas"] == products and comparison["checkoutShas"] == checkouts,
            f"{directory}: checkout/product identity mismatch")
    for filename, expected in (("baseline-sha.txt", BASELINE_SHA), ("candidate-sha.txt", PRODUCT_SHA),
                                ("qualification-sha.txt", QUALIFICATION_SHA)):
        require((directory / filename).read_text().strip() == expected,
                f"{directory}: {filename} differs from frozen campaign")
    hashes = comparison["packageHashes"]
    require(hashes["A"] == hashes["C"] == hashes["D"] and hashes["A"] != hashes["B"],
            f"{directory}: same-product or candidate package identity failed")
    old, old_hash = common.read_json(directory / "baseline-package-entry-sha256.json")
    new, new_hash = common.read_json(directory / "candidate-package-entry-sha256.json")
    changed = {key for key in old.keys() | new.keys() if old.get(key) != new.get(key)}
    require(changed == common.ALLOWED_PACKAGE_CHANGES == set(comparison["changedPackageEntries"]),
            f"{directory}: package changes exceed the three frozen runtime files")
    require(old["lib/term-bank-parser.wasm"] == new["lib/term-bank-parser.wasm"],
            f"{directory}: native parser changed")
    validation = comparison["validation"]
    fixture = comparison["fixture"]
    require(comparison["identicalSampledContentAndMedia"] is True
            and validation["contentReadable"] is True and validation["probeCount"] == 12
            and validation["termRows"] == fixture["termRows"]
            and validation["restart"]["contentReadable"] is True
            and validation["restart"]["termRows"] == fixture["termRows"],
            f"{directory}: incomplete stored content/restart validation")
    if comparison["dictionary"] == "vndb":
        require(validation["mediaRows"] == fixture["mediaRows"]
                and 0 < validation["generationMedia"]["count"] <= fixture["mediaRows"]
                and validation["packedMediaActivation"]["entries"] == validation["generationMedia"]["count"]
                and validation["mediaBeforeRestart"] == validation["mediaAfterRestart"]
                and len(validation["mediaBeforeRestart"]) == 5
                and "img/cc18737.webp" in [item["path"] for item in validation["mediaBeforeRestart"]],
                f"{directory}: incomplete packed media/restart validation")
    return comparison, {
        "comparisonSha256": comparison_hash,
        "baselinePackageEntryMapSha256": old_hash,
        "candidatePackageEntryMapSha256": new_hash,
        "baselinePackageEntryMapCanonicalSha256": common.canonical_hash(old),
        "candidatePackageEntryMapCanonicalSha256": common.canonical_hash(new),
    }


def paired_metric(observations, metric, left_arm, right_arm, count, order):
    names = [f"{arm}{index}" for index in range(1, count + 1) for arm in (left_arm, right_arm)]
    missing = [name for name in names if observations[name]["metrics"].get(metric) is None]
    if missing:
        return {"available": False, "expectedPairCount": count, "missingObservations": missing,
                "valuesByObservation": {name: observations[name]["metrics"].get(metric) for name in names}}
    pairs = []
    for index in range(1, count + 1):
        left_name, right_name = f"{left_arm}{index}", f"{right_arm}{index}"
        left, right = (observations[name]["metrics"][metric] for name in (left_name, right_name))
        pairs.append({"pair": index, "left": left_name, "right": right_name,
                      "order": sorted((left_name, right_name), key=order.index),
                      "leftMs": left, "rightMs": right, "differenceMs": right - left,
                      "changePercent": 100 * (right / left - 1) if left else None})
    lefts = [pair["leftMs"] for pair in pairs]
    rights = [pair["rightMs"] for pair in pairs]
    percentages = [pair["changePercent"] for pair in pairs]
    return {"available": True, "pairCount": count,
            "leftMedianMs": statistics.median(lefts), "rightMedianMs": statistics.median(rights),
            "medianPairedDifferenceMs": statistics.median(pair["differenceMs"] for pair in pairs),
            "medianPairedChangePercent": statistics.median(percentages) if None not in percentages else None,
            "equalWorkTotalChangePercent": 100 * (sum(rights) / sum(lefts) - 1) if sum(lefts) else None,
            "fasterPairs": sum(right < left for left, right in zip(lefts, rights)),
            "slowerPairs": sum(right > left for left, right in zip(lefts, rights)),
            "equalPairs": sum(right == left for left, right in zip(lefts, rights)), "pairs": pairs}


def analyze(directory):
    directory = directory.resolve()
    comparison, hashes = verify_comparison(directory)
    replication = comparison["replication"]
    order = ORDERS[replication]
    warmups = common.WARMUPS if replication == 1 else list(reversed(common.WARMUPS))
    all_observations = {name: common.read_observation(directory, name, comparison) for name in warmups + order}
    observations = {name: all_observations[name] for name in order}
    host_identities = {}
    for declared in comparison["observations"]:
        name = declared["name"]
        item = observations[name]
        require(declared["arm"] == item["arm"], f"{directory}/{name}: arm differs")
        common.same_number(declared["milliseconds"], item["metrics"]["completeImportMs"], name)
        common.same_number(declared["bulkFinalizationMs"], item["bulkFinalizationMs"], name + " finalization")
        for key in common.CHECKPOINT_KEYS:
            value = item["checkpointMetrics"][key]
            common.same_number(declared["flushMetrics"][key], value["value"] if value["present"] else 0,
                               name + " checkpoint " + key)
        for suffix in ("before", "after"):
            filename = f"host-{suffix}.json"
            host, host_hash = common.read_json(directory / name / filename)
            item["hashes"][filename] = host_hash
            identity = {key: host.get(key) for key in ("cpuModel", "logicalCpuCount", "availableParallelism",
                "totalMemoryBytes", "nodeVersion", "v8Version", "platform", "arch", "cgroupCpuQuotaCores")}
            host_identities[f"{name}/{suffix}"] = identity
            item["hashes"][f"uptime-{suffix}.txt"] = common.sha256((directory / name / f"uptime-{suffix}.txt").read_bytes())
    metrics = sorted({key for item in observations.values() for key in item["metrics"]})
    candidate = {key: paired_metric(observations, key, "A", "B", 8, order) for key in metrics}
    control = {key: paired_metric(observations, key, "C", "D", 4, order) for key in metrics}
    for comparisons, field, count in ((candidate, "pairedChangesPercent", 8), (control, "controlChangesPercent", 4)):
        actual = [pair["changePercent"] for pair in comparisons["completeImportMs"]["pairs"]]
        require(len(actual) == len(comparison[field]) == count, f"{directory}: pair counts differ")
        for actual_value, declared_value in zip(actual, comparison[field]):
            require(math.isclose(actual_value, declared_value, rel_tol=0, abs_tol=1e-9),
                    f"{directory}: paired complete durations differ from verifier")
    fixed = common.equality(all_observations, "work")
    for filename in ("verify-import-comparison.py", "import-optimization-comparison.yml",
                     "qualification-vndb-overlay.py", "measurement-overlay-sha256.txt",
                     "qualified-harness.js", "qualified-dictionaries.lock.json",
                     "shared-import-tools-sha256.txt", "shared-harness-sha256.txt"):
        hashes[filename] = common.sha256((directory / filename).read_bytes())
    return {
        "directory": str(directory),
        "identity": {key: comparison[key] for key in ("dictionary", "replication", "baselineSha", "candidateSha",
            "qualificationSha", "productSourceShas", "checkoutShas", "browser", "fixture", "timingBoundary")},
        "schedule": {"warmups": warmups, "measured": order, "candidatePairs": 8, "controlPairs": 4},
        "qualification": {"all26ImportsSuccessfulAndVerified": True,
            "allSampledContentAndMediaIdentical": True,
            "completeParserAndImporterRowCountsMatchFixture": True,
            "allFixedReportedWorkAndConfigurationEqual": fixed["allEqual"],
            "allCandidateImportsActivatedCheckpoints": True, "phaseMetricCount": len(metrics)},
        "candidateComparisons_B_over_A": candidate,
        "sameProductControls_D_over_C": control,
        "fixedReportedWorkAndConfigurationEqualityIncludingWarmups": fixed,
        "timingDependentOperationalWorkIncludingWarmups": common.equality(all_observations, "operational"),
        "declaredCheckpointMechanismDifferencesIncludingWarmups": common.equality(all_observations, "mechanism"),
        "checkpointMetricsByObservation": {name: item["checkpointMetrics"] for name, item in all_observations.items()},
        "hostIdentityBySnapshot": host_identities,
        "inputHashes": {**hashes, "observations": {name: item["hashes"] for name, item in all_observations.items()}},
    }


def campaign_checks(cohorts, require_complete=False):
    keys = [(cohort["identity"]["dictionary"], cohort["identity"]["replication"]) for cohort in cohorts]
    require(len(keys) == len(set(keys)), "Duplicate dictionary/replication jobs")
    expected = {(dictionary, replication) for dictionary in ("jmdict", "jitendex", "vndb") for replication in (1, 2)}
    complete = set(keys) == expected
    require(not require_complete or complete, "Expected all six frozen confirmation jobs")
    global_hash_keys = ("baselinePackageEntryMapCanonicalSha256", "candidatePackageEntryMapCanonicalSha256",
                       "verify-import-comparison.py", "import-optimization-comparison.yml",
                       "qualification-vndb-overlay.py", "qualified-harness.js", "qualified-dictionaries.lock.json")
    global_values = {}
    for key in global_hash_keys:
        values = {cohort["inputHashes"][key] for cohort in cohorts}
        require(len(values) == 1, f"Campaign package/harness differs: {key}")
        global_values[key] = next(iter(values))
    replicated = {}
    for dictionary in ("jmdict", "jitendex", "vndb"):
        jobs = [cohort for cohort in cohorts if cohort["identity"]["dictionary"] == dictionary]
        if not jobs:
            continue
        fixtures = {common.canonical_hash(job["identity"]["fixture"]) for job in jobs}
        validation = {item["sampledValidationCanonicalSha256"] for job in jobs
                      for item in job["inputHashes"]["observations"].values()}
        require(len(fixtures) == len(validation) == 1, f"{dictionary}: fixture/readback differs across replications")
        replicated[dictionary] = {"replicationsPresent": sorted(job["identity"]["replication"] for job in jobs),
                                  "fixtureIdentical": True, "sampledReadbackIdentical": True}
    return {"completeSixJobCampaign": complete,
            "missingJobs": [{"dictionary": corpus, "replication": replica} for corpus, replica in sorted(expected - set(keys))],
            "identicalPackageAndHarnessHashes": global_values, "perDictionary": replicated}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directories", nargs="+", type=Path)
    parser.add_argument("--require-complete", action="store_true")
    args = parser.parse_args()
    common_path = Path(common.__file__)
    require(common.sha256(common_path.read_bytes()) == COMMON_SHA256, "Frozen screen helper changed")
    cohorts = [analyze(directory) for directory in args.directories]
    result = {"schemaVersion": 1, "scriptSha256": common.sha256(Path(__file__).read_bytes()),
              "sharedScreenHelperSha256": COMMON_SHA256,
              "campaignChecks": campaign_checks(cohorts, args.require_complete),
              "cohorts": cohorts,
              "notes": [
                  "Each corpus/replication remains separate; no pooling of hosts, screen observations, or controls.",
                  "Every fixed observation is retained. Warmups are validated and excluded from paired timing summaries.",
                  "B/A uses eight adjacent matched pairs; D/C uses four same-product pairs, with no correction/subtraction.",
                  "Each candidate percentage is calculated from its own paired durations, not a ratio of arm medians.",
                  "All importer/local phase metrics are included; worker sums and wall intervals overlap and are not additive.",
                  "Absent baseline final-flush instrumentation remains absent; checkpoint count/bytes/time are reported absolutely.",
                  "All non-timing phase-detail fields remain visible in fixed work/configuration, operational work, or mechanism differences.",
                  "Identical reported work and sampled restart/readback results do not establish exhaustive stored-byte equality or peak memory.",
              ]}
    print(json.dumps(result, indent=4, allow_nan=False))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
        print(f"Analysis failed: {error}", file=sys.stderr)
        sys.exit(1)
