#!/usr/bin/env python3
"""Package exact initial import-comparison evidence; refuse existing outputs."""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import statistics
import subprocess
import sys
import tarfile
import zipfile
import zlib


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=4, sort_keys=True) + "\n").encode()


def git_bytes(repo, commit, path):
    return subprocess.run(
        ["git", "show", f"{commit}:{path}"], cwd=repo, check=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
    ).stdout


def deterministic_archive(payload):
    stream = io.BytesIO()
    with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode="w", format=tarfile.USTAR_FORMAT) as tar:
            for name, content in sorted(payload.items()):
                info = tarfile.TarInfo(name)
                info.size = len(content)
                info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ""
                tar.addfile(info, io.BytesIO(content))
    return stream.getvalue()


def package(workspace, pr, worktree_name, stem, candidate_commit, runtime_commit):
    repo = workspace / worktree_name
    baseline_repo = workspace / "manabitan"
    evidence = workspace / "browser-evidence"
    baseline_commit = "5e1f8c12f7ff798ba407323aff675cb23b22af02"
    output_dir = repo / "dev/perf/evidence"
    archive_path = output_dir / f"{stem}.tar.gz"
    manifest_path = output_dir / f"{stem}.manifest.json"
    for path in (archive_path, manifest_path):
        if path.exists():
            raise FileExistsError(path)
    payload = {}
    entries = []
    omissions = []
    originals = []
    jobs = []
    phase_metrics = {}
    reports = {}

    def add(name, data, source):
        if name in payload:
            assert payload[name] == data, name
            return
        assert not PurePosixPath(name).is_absolute() and ".." not in PurePosixPath(name).parts
        payload[name] = data
        entries.append({"path": name, "bytes": len(data), "sha256": sha256(data), "source": source})

    def add_file(path, name, expected_hash=None):
        data = path.read_bytes()
        if expected_hash is not None:
            assert sha256(data) == expected_hash, path
        add(name, data, {"kind": "workspace-file", "path": str(path.relative_to(workspace))})

    def add_git(commit, path, expected_hash=None):
        data = git_bytes(repo, commit, path)
        if expected_hash is not None:
            assert sha256(data) == expected_hash, (commit, path)
        add(f"git-snapshots/{commit}/{path}", data,
            {"kind": "git-blob", "commit": commit, "path": path})
        return data

    fixed_order = "A1 B1 B2 A2 B3 A3 A4 B4 A5 B5 B6 A6 B7 A7 A8 B8".split()
    for dictionary in ("jmdict", "jitendex", "vndb"):
        job_name = f"pr{pr}-{dictionary}"
        root = evidence / job_name
        original = evidence / f"{job_name}.zip"
        original_bytes = original.read_bytes()
        kept_count = omitted_count = 0
        with zipfile.ZipFile(io.BytesIO(original_bytes)) as archive:
            members = [m for m in archive.infolist() if not m.is_dir()]
            names = [m.filename for m in members]
            assert len(set(names)) == len(names), job_name
            extracted = {str(p.relative_to(root)) for p in root.rglob("*") if p.is_file()}
            assert set(names) == extracted, (job_name, "extraction membership")
            for member in sorted(members, key=lambda m: m.filename):
                path = PurePosixPath(member.filename)
                assert not path.is_absolute() and ".." not in path.parts
                data = archive.read(member)
                assert data == (root / member.filename).read_bytes(), (job_name, member.filename)
                source = {"kind": "workflow-artifact-zip-member", "archive": original.name,
                          "member": member.filename}
                reason = None
                if path.parts[0] == "candidate-trace":
                    reason = "Separate post-timing diagnostic trace, outside the fixed cohort"
                elif path.suffix == ".html":
                    reason = "Rendered HTML duplicate; original summary.json and run-1.json retained"
                if reason:
                    omissions.append({"archive": original.name, "path": member.filename,
                                      "bytes": len(data), "sha256": sha256(data), "reason": reason})
                    omitted_count += 1
                else:
                    add(f"browser/{dictionary}/{member.filename}", data, source)
                    kept_count += 1
        originals.append({"path": f"browser-evidence/{original.name}", "filename": original.name,
                          "bytes": len(original_bytes), "sha256": sha256(original_bytes),
                          "memberCount": len(members), "retainedMemberCount": kept_count,
                          "omittedMemberCount": omitted_count, "allExtractedBytesMatchOriginalZip": True})
        comparison = json.loads((root / "comparison.json").read_bytes())
        assert comparison["dictionary"] == dictionary
        assert comparison["baselineSha"] == baseline_commit
        assert comparison["candidateSha"] == candidate_commit
        assert comparison["warmups"] == 2 and comparison["measuredImports"] == 16
        assert comparison["pairCount"] == 8
        assert (root / "observation-order.txt").read_text().split() == fixed_order
        assert [o["name"] for o in comparison["observations"]] == fixed_order
        observations = []
        parse_totals = {}
        for name in ["warmup-A", "warmup-B"] + fixed_order:
            summary = json.loads((root / name / "summary.json").read_bytes())
            raw = json.loads((root / name / "run-1.json").read_bytes())
            assert isinstance(raw, dict)
            assert len(summary["runs"]) == 1 and summary["authoritativeTiming"] is True
            assert summary["traceEnabled"] is False
            arm = name[-1] if name.startswith("warmup-") else name[0]
            assert summary["gitSha"] == (baseline_commit if arm == "A" else candidate_commit)
            run = summary["runs"][0]
            assert run["packageSha256"] == comparison["packageHashes"][arm]
            if not name.startswith("warmup-"):
                expected = next(o["milliseconds"] for o in comparison["observations"] if o["name"] == name)
                assert run["totalImportMs"] == expected
                for host_file in ("host-before.json", "host-after.json", "uptime-before.txt", "uptime-after.txt"):
                    assert (root / name / host_file).is_file()
                parse_totals[name] = sum(p["details"].get("parserParseBankMs", 0)
                    for p in run["importDebug"]["importerPhaseTimings"]
                    if p["phase"].startswith("term-file-fast-path:"))
            assert (root / name / "run.log").is_file()
            observations.append({"name": name, "arm": arm, "warmup": name.startswith("warmup-"),
                                 "source": summary["source"], "packageSha256": run["packageSha256"],
                                 "summaryPath": f"browser/{dictionary}/{name}/summary.json",
                                 "rawReportPath": f"browser/{dictionary}/{name}/run-1.json"})
            reports[(dictionary, name)] = summary
        changes = [(parse_totals[f"B{i}"] / parse_totals[f"A{i}"] - 1) * 100 for i in range(1, 9)]
        phase_metrics[dictionary] = {"field": "sum of term-file-fast-path details.parserParseBankMs",
                                     "scope": "Summed native parser work across parallel groups, not wall time",
                                     "observationsMs": parse_totals, "pairedChangePercent": changes,
                                     "medianPairedChangePercent": statistics.median(changes),
                                     "candidateSlowerPairs": sum(x > 0 for x in changes)}
        jobs.append({"dictionary": dictionary, "candidateSha": candidate_commit,
                     "baselineSha": baseline_commit, "timedObservationCount": 16,
                     "warmupObservationCount": 2, "timedOrder": fixed_order,
                     "fixture": comparison["fixture"], "packageHashes": comparison["packageHashes"],
                     "comparisonPath": f"browser/{dictionary}/comparison.json", "observations": observations})

    # Snapshot original Git tools and exact measured products without reading a revised worktree.
    for commit, arm in ((baseline_commit, "A"), (candidate_commit, "B")):
        source = reports[("jmdict", f"{arm}1")]["source"]["sha256"]
        for path, expected_hash in source.items():
            if path.startswith("builds/") or expected_hash is None:
                continue
            if path in ("test/perf/dictionaries.lock.json", "test/chromium/extension-two-dictionary-import.e2e.js"):
                artifact_name = "qualified-dictionaries.lock.json" if path.endswith(".json") else "qualified-harness.js"
                for dictionary in ("jmdict", "jitendex", "vndb"):
                    assert sha256(payload[f"browser/{dictionary}/{artifact_name}"]) == expected_hash
                continue
            if path == "dev/perf/dictionary-fixtures.js":
                original = git_bytes(repo, candidate_commit, path)
                old = b"        jmdictPath: paths.jmdict,\n        fixtures,"
                new = b"        jmdictPath: paths.jmdict,\n        vndbPath: paths.vndb,\n        fixtures,"
                assert original.count(old) == 1
                qualified = original.replace(old, new, 1)
                assert sha256(qualified) == expected_hash
                add("snapshots/qualified-dictionary-fixtures.js", qualified,
                    {"kind": "git-blob-plus-recorded-overlay", "commit": candidate_commit, "path": path,
                     "verifiedAgainstAllMeasuredSourceMaps": True})
                continue
            add_git(commit, path, expected_hash)
        package_map = json.loads(payload[f"browser/jmdict/{'baseline' if arm == 'A' else 'candidate'}-package-entry-sha256.json"])
        for path, entry in (
            ("ext/js/dictionary/term-bank-wasm-parser.js", "js/dictionary/term-bank-wasm-parser.js"),
            ("ext/js/dictionary/wasm/term-bank-parser.c", "js/dictionary/wasm/term-bank-parser.c"),
            ("dev/data/dictionary-wasm/term-bank-parser.wasm", "lib/term-bank-parser.wasm"),
        ):
            product = add_git(commit, path, package_map[entry])
            if arm == "B":
                assert product == git_bytes(repo, runtime_commit, path), (runtime_commit, path)
    add_git(candidate_commit, ".github/workflows/import-optimization-comparison.yml")
    add_git(candidate_commit, ".github/actions/setup/action.yml")
    for (dictionary, name), report in reports.items():
        arm = name[-1] if name.startswith("warmup-") else name[0]
        first = reports[("jmdict", f"{arm}1")]["source"]["sha256"]
        current = report["source"]["sha256"]
        assert {k: v for k, v in first.items() if not k.startswith("builds/")} == {
            k: v for k, v in current.items() if not k.startswith("builds/")}, (dictionary, name)

    component = {}
    if pr == 800:
        component_root = repo / "builds/perf/20261122-source-zip-media"
        names = ("baseline-control.json", "comparison.json", "candidate-control.json",
                 "summary.json", "smoke-candidate.json", "wasm-function-comparison.json")
        assert {p.name for p in component_root.iterdir() if p.is_file()} == set(names)
        for name in names:
            add_file(component_root / name, f"component/{name}")
        summary = json.loads(payload["component/summary.json"])
        assert summary["sourceCommits"] == {"A": baseline_commit, "B": runtime_commit}
        add_file(repo / "dev/perf/source-zip-media-screen.js", "component/source-zip-media-screen.js",
                 summary["runnerSha256"])
        add_file(baseline_repo / "builds/perf/20261122-import-baseline/vndb-inventory.json",
                 "component/vndb-inventory.json")
        for name, expected in summary["reports"].items():
            assert sha256(payload[f"component/{name}.json"]) == expected["sha256"]
        component = {"boundary": summary["boundary"], "decision": summary["decision"],
                     "candidateObservationCount": 24, "controlObservationCount": 8,
                     "smokeObservationCount": 1, "sourceCommits": summary["sourceCommits"],
                     "summaryPath": "component/summary.json"}
        decision = {"status": "No complete-import speedup established by the retained cohort",
                    "component": summary["decision"],
                    "scope": "Structural validation work reduction and correctness evidence; timing results remain qualified"}
    else:
        component_root = baseline_repo / "builds/perf/20261122-terms-screen"
        for name in ("jmdict-exploratory.json", "jitendex-exploratory.json", "host-before.json", "host-after.json"):
            add_file(component_root / name, f"component/{name}")
        runner_hashes = set()
        lock_hashes = set()
        for dictionary in ("jmdict", "jitendex"):
            initial = json.loads(payload[f"component/{dictionary}-exploratory.json"])
            assert initial["complete"] and initial["pairs"] == 2 and len(initial["observations"]) == 4
            for observation in initial["observations"]:
                runner_hashes.add(observation["result"]["runnerSha256"])
                lock_hashes.add(observation["result"]["lockSha256"])
        assert len(runner_hashes) == len(lock_hashes) == 1
        add_file(baseline_repo / "dev/perf/import-lookup-screen.js", "component/import-lookup-screen.js", runner_hashes.pop())
        add_git(baseline_commit, "test/perf/dictionaries.lock.json", lock_hashes.pop())
        component = {"boundary": "Sequential full-corpus parser and completed lookup construction, not whole import",
                     "pairsPerDictionary": 2, "totalObservationCount": 8,
                     "decision": "Exploratory only; does not qualify speed or override the rejected browser candidate"}
        decision = {"status": "Rejected initial glossary-discriminator browser candidate",
                    "reason": "Native parser work slowed by about 4.8% for JMdict and 4.2% for Jitendex",
                    "exactNativeParserMetrics": {k: phase_metrics[k] for k in ("jmdict", "jitendex")},
                    "scope": "Only the initial candidate. Later revised source and cohorts are separate evidence."}
    add_file(Path(__file__), "package-import-evidence.py")
    manifest = {
        "schemaVersion": 1, "archiveName": archive_path.name, "pullRequest": pr,
        "baselineCommit": baseline_commit, "browserCandidateCommit": candidate_commit,
        "runtimeCandidateCommit": runtime_commit,
        "decision": decision, "browserJobs": jobs, "browserPhaseMetrics": phase_metrics,
        "component": component, "originalWorkflowArchives": originals,
        "retentionPolicy": {
            "allTimedObservationsRetained": True, "allWarmupObservationsRetained": True,
            "timedBrowserObservations": 48, "warmupBrowserObservations": 6,
            "rawBrowserReportPairs": 54, "fileBytesPreservedExactly": True,
            "onlyOmittedWorkflowMembers": ["Rendered .html duplicates", "Separate candidate-trace directory"],
            "originalWorkflowZipBytesEmbedded": False,
            "originalWorkflowZipIdentityPreserved": "Each original ZIP size/SHA256 and exact member-byte comparison recorded",
            "dictionaryArchiveBytesEmbedded": False,
            "dictionaryArchiveIdentityPreserved": "Pinned source URL, byte length and SHA256 in original lock and comparisons",
        },
        "packaging": {"format": "USTAR then gzip level 9", "memberOrder": "lexicographic",
                      "uid": 0, "gid": 0, "uname": "", "gname": "", "mtime": 0,
                      "mode": "0644", "gzipFilename": "", "gzipMtime": 0,
                      "pythonVersion": sys.version.split()[0], "zlibVersion": zlib.ZLIB_VERSION,
                      "manifestExcludedFromItsOwnPayloadHashes": True},
        "files": sorted(entries, key=lambda e: e["path"]),
        "omittedWorkflowMembers": sorted(omissions, key=lambda e: (e["archive"], e["path"])),
    }
    manifest_bytes = json_bytes(manifest)
    payload["MANIFEST.json"] = manifest_bytes
    archive_bytes = deterministic_archive(payload)
    assert archive_bytes == deterministic_archive(payload), "Nondeterministic archive output"
    with tarfile.open(fileobj=io.BytesIO(archive_bytes), mode="r:gz") as archive:
        assert archive.getnames() == sorted(payload)
        for info in archive.getmembers():
            assert info.isfile() and info.uid == info.gid == info.mtime == 0 and info.mode == 0o644
            assert archive.extractfile(info).read() == payload[info.name], info.name
    output_dir.mkdir(parents=True, exist_ok=True)
    with archive_path.open("xb") as output:
        output.write(archive_bytes)
    with manifest_path.open("xb") as output:
        output.write(manifest_bytes)
    return {"archive": str(archive_path), "bytes": len(archive_bytes), "sha256": sha256(archive_bytes),
            "manifest": str(manifest_path), "manifestBytes": len(manifest_bytes),
            "manifestSha256": sha256(manifest_bytes), "payloadFileCount": len(entries),
            "omittedWorkflowMemberCount": len(omissions), "originalWorkflowArchives": originals}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("workspace", type=Path)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    specs = [
        (800, "manabitan-vndb", "vndb-media-validation-20261122",
         "0f614ccdabd867f8c682e8c488d5f34ccd7509ae", "d0ed2fe397b4f2d3284421691d91058e82cedacd"),
        (802, "manabitan-terms", "glossary-discriminators-rejected-20261122",
         "1bf95d706e9ccf1d7e83ccf46b39b18fce21b485", "dbe08e4b71d05bb5eca06e4f9002d358372020b0"),
    ]
    for spec in specs:
        print(json.dumps(package(workspace, *spec), indent=2), flush=True)


if __name__ == "__main__":
    main()
