from pathlib import Path
import json
import os
import re
import subprocess

root = Path('/workspace/scratch/1b47f6463b98')
out = root / 'evidence/crc-tail'
out.mkdir(exist_ok=True)
source = (root / 'manabitan/ext/js/dictionary/wasm/term-bank-parser.c').read_text()
prefix = source[source.index('static uint32_t crc32_table'):source.index('#if defined(TERM_BANK_CRC_TEST)')]
gap = re.search(r'static uint32_t crc32_update_gap\(.*?\n}\n', source, re.S).group(0)
tail = '''    while (offset < length) {
        crc = (crc >> 8u) ^ crc32_table[0][(crc ^ data[offset++]) & 0xffu];
    }
'''
step8 = '''static inline uint32_t crc32_step8(const uint8_t* data, uint32_t crc) {
    crc ^= crc32_read_u32_le(data);
    const uint32_t second = crc32_read_u32_le(data + 4u);
    return crc32_table[7][crc & 0xffu] ^ crc32_table[6][(crc >> 8u) & 0xffu] ^
        crc32_table[5][(crc >> 16u) & 0xffu] ^ crc32_table[4][crc >> 24u] ^
        crc32_table[3][second & 0xffu] ^ crc32_table[2][(second >> 8u) & 0xffu] ^
        crc32_table[1][(second >> 16u) & 0xffu] ^ crc32_table[0][second >> 24u];
}
'''
step4 = '''static inline uint32_t crc32_step4(const uint8_t* data, uint32_t crc) {
    crc ^= crc32_read_u32_le(data);
    return crc32_table[3][crc & 0xffu] ^ crc32_table[2][(crc >> 8u) & 0xffu] ^
        crc32_table[1][(crc >> 16u) & 0xffu] ^ crc32_table[0][crc >> 24u];
}
'''
test = '''extern unsigned char __heap_base;
uint32_t probe_heap(void) { return (uint32_t)(uintptr_t)&__heap_base; }
uint32_t probe_gap(uint32_t crc, uint32_t data_ptr, uint32_t length) {
    (void)crc32_bytes((const uint8_t*)(uintptr_t)data_ptr, 0u);
    return crc32_update_gap(crc, (const uint8_t*)(uintptr_t)data_ptr, length);
}
uint32_t probe_batch(uint32_t data_ptr, uint32_t spans_ptr, uint32_t count, uint32_t repeats) {
    const uint8_t* data = (const uint8_t*)(uintptr_t)data_ptr;
    const uint32_t* spans = (const uint32_t*)(uintptr_t)spans_ptr;
    (void)crc32_bytes(data, 0u);
    uint32_t crc = 0u;
    for (uint32_t repeat = 0; repeat < repeats; ++repeat) {
        for (uint32_t i = 0; i < count; ++i) {
            crc = crc32_update_gap(crc, data + spans[i * 2u], spans[i * 2u + 1u]);
        }
    }
    return crc;
}
'''
variants = {'baseline': gap}
for name, widths in [('tail8', [8]), ('tail4', [4]), ('tail8_4', [8, 4])]:
    replacement = ''
    for width in widths:
        loop = 'while' if widths == [4] else 'if'
        replacement += f'''    {loop} (length - offset >= {width}u) {{
        crc = crc32_step{width}(data + offset, crc);
        offset += {width}u;
    }}
'''
    variants[name] = gap.replace(tail, replacement + tail)

compiler = '/home/agent/.cache/manabitan-b9cacc/toolchain/usr/lib/llvm-21/bin/clang'
linker = '/home/agent/.cache/manabitan-b9cacc/toolchain/usr/lib/llvm-21/bin/wasm-ld'
env = dict(os.environ, LD_LIBRARY_PATH='/home/agent/.cache/manabitan-b9cacc/toolchain/usr/lib/x86_64-linux-gnu', TMPDIR=str(out))
for name, body in variants.items():
    source_path = out / f'{name}.c'
    source_path.write_text('#include <stdint.h>\n' + prefix + step8 + step4 + body + test)
    command = [compiler, '--target=wasm32-freestanding', '-O3', '-matomics', '-mbulk-memory', '-msimd128', '-nostdlib', f'-fuse-ld={linker}', '-Wl,--no-entry', '-Wl,--shared-memory', '-Wl,--max-memory=4294967296', '-Wl,--export=probe_heap', '-Wl,--export=probe_gap', '-Wl,--export=probe_batch', '-Wl,--strip-all', '-o', str(out / f'{name}.wasm'), str(source_path)]
    subprocess.run(command, check=True, env=env)
print(json.dumps({'directory': str(out), 'variants': list(variants)}))
