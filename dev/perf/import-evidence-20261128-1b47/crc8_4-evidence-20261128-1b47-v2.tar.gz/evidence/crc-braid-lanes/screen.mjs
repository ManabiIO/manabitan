import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {crc32, inflateRawSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';

const root = path.dirname(fileURLToPath(import.meta.url));
const fixtureRoot = '/tmp/manabitan-1b47-fixtures';
const files = fs.readdirSync(fixtureRoot, {recursive: true}).filter(x => /jmdict.*\.zip$/i.test(x));
assert.equal(files.length, 1);
const archive = fs.readFileSync(path.join(fixtureRoot, files[0]));
const sha = x => createHash('sha256').update(x).digest('hex');
assert.equal(sha(archive), '3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f');
let eocd = archive.length - 22;
while (archive.readUInt32LE(eocd) !== 0x06054b50) --eocd;
const count = archive.readUInt16LE(eocd + 10);
let central = archive.readUInt32LE(eocd + 16);
const banks = [];
for (let i = 0; i < count; ++i) {
    assert.equal(archive.readUInt32LE(central), 0x02014b50);
    const method = archive.readUInt16LE(central + 10);
    const signature = archive.readUInt32LE(central + 16);
    const compressed = archive.readUInt32LE(central + 20);
    const length = archive.readUInt32LE(central + 24);
    const nameLength = archive.readUInt16LE(central + 28);
    const extraLength = archive.readUInt16LE(central + 30);
    const commentLength = archive.readUInt16LE(central + 32);
    const offset = archive.readUInt32LE(central + 42);
    const name = archive.toString('utf8', central + 46, central + 46 + nameLength);
    central += 46 + nameLength + extraLength + commentLength;
    if (!/^term_bank_\d+\.json$/.test(name)) continue;
    assert.equal(archive.readUInt32LE(offset), 0x04034b50);
    const start = offset + 30 + archive.readUInt16LE(offset + 26) + archive.readUInt16LE(offset + 28);
    const payload = archive.subarray(start, start + compressed);
    const bytes = method === 8 ? inflateRawSync(payload) : payload;
    assert.equal(bytes.length, length);
    assert.equal(crc32(bytes), signature);
    banks.push({name, bytes, signature, length, sha256: sha(bytes)});
}
banks.sort((a, b) => Number(a.name.match(/\d+/)[0]) - Number(b.name.match(/\d+/)[0]));
assert.equal(banks.length, 53);
const capacity = Math.max(...banks.map(x => x.length)) + 256;
const variants = [];
for (const [name, lanes] of [['A8', 8], ['B4', 4], ['B6', 6], ['B12', 12], ['B16', 16], ['C8', 8]]) {
    const wasm = fs.readFileSync(path.join(root, `braid${lanes}.wasm`));
    const instance = new WebAssembly.Instance(new WebAssembly.Module(wasm)).exports;
    instance.wasm_reset_heap();
    const source = instance.wasm_alloc(capacity);
    const spans = instance.wasm_alloc(8);
    const signature = instance.wasm_alloc(4);
    const stats = instance.wasm_alloc(12);
    const memory = new Uint8Array(instance.memory.buffer);
    const spanValues = new Uint32Array(instance.memory.buffer, spans, 2);
    const signatureValues = new Uint32Array(instance.memory.buffer, signature, 1);
    const statValues = new Uint32Array(instance.memory.buffer, stats, 3);
    const prepare = (bytes, expected, alignment = 0) => {
        memory.set(bytes, source + alignment);
        spanValues.set([0, bytes.length]);
        signatureValues[0] = expected;
    };
    const verify = (length, alignment = 0) => instance.verify_term_bank_source_crcs(source + alignment, length, spans, 1, signature, 0, 0, 0, stats);
    // Exercise every terminal tail for these braid sizes, all alignments,
    // threshold boundaries, corruption rejection, and the ordinary fallback.
    let cases = 0;
    const oracle = Buffer.alloc(262400);
    for (let i = 0; i < oracle.length; ++i) oracle[i] = (Math.imul(i, 73) ^ (i >>> 7)) & 255;
    for (const length of [0, 1, 15, 16, 17, 63, 64, 65, 262143, ...Array.from({length: 129}, (_, i) => 262144 + i)]) {
        const bytes = oracle.subarray(0, length);
        const expected = crc32(bytes);
        for (let alignment = 0; alignment < 8; ++alignment) {
            prepare(bytes, expected, alignment);
            assert.equal(verify(length, alignment), 0);
            assert.deepEqual(Array.from(statValues), [length, 0, 0]);
            signatureValues[0] = expected ^ 1;
            assert.equal(verify(length, alignment), -4);
            cases += 2;
        }
    }
    for (const bank of banks) {
        prepare(bank.bytes, bank.signature);
        assert.equal(verify(bank.length), 0);
    }
    variants.push({name, lanes, prepare, verify, statValues, cases, wasmSha256: sha(wasm)});
}
const blocks = 12;
const repeats = 2;
const plan = {scope: 'Whole-bank CRC production verifier only; no full import speed claim', baseline: '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2', node: process.version, v8: process.versions.v8,
    blocks, repeats, control: 'C8 is identical production WASM with independent instance', variants: variants.map(({name, lanes, cases, wasmSha256}) => ({name, lanes, cases, wasmSha256})), banks: banks.map(({bytes, ...rest}) => rest)};
fs.writeFileSync(path.join(root, 'plan.json'), JSON.stringify(plan, null, 2) + '\n');
const observations = [];
const raw = fs.openSync(path.join(root, 'observations.jsonl'), 'w');
for (let block = -2; block < blocks; ++block) {
    const totals = Object.fromEntries(variants.map(v => [v.name, 0]));
    for (let bankIndex = 0; bankIndex < banks.length; ++bankIndex) {
        const bank = banks[bankIndex];
        const rotation = (block + 2 + bankIndex) % variants.length;
        const order = Array.from({length: variants.length}, (_, i) => variants[(i + rotation) % variants.length]);
        if (block % 2) order.reverse();
        for (const v of order) {
            v.prepare(bank.bytes, bank.signature);
            const start = performance.now();
            let status = 0;
            for (let repeat = 0; repeat < repeats; ++repeat) status |= v.verify(bank.length);
            const elapsed = performance.now() - start;
            assert.equal(status, 0);
            assert.deepEqual(Array.from(v.statValues), [bank.length, 0, 0]);
            totals[v.name] += elapsed;
        }
    }
    const row = {block, warmup: block < 0, totals};
    fs.writeSync(raw, JSON.stringify(row) + '\n');
    if (block >= 0) observations.push(row);
}
fs.closeSync(raw);
const median = xs => { const a = [...xs].sort((a, b) => a - b); return (a[(a.length - 1) >>> 1] + a[a.length >>> 1]) / 2; };
const results = variants.filter(v => v.name !== 'A8').map(v => {
    const ratios = observations.map(o => o.totals[v.name] / o.totals.A8);
    return {name: v.name, pairedMedianPercent: 100 * (median(ratios) - 1), geometricPercent: 100 * (Math.exp(ratios.reduce((s, x) => s + Math.log(x), 0) / ratios.length) - 1), faster: ratios.filter(x => x < 1).length, ratios};
});
const report = {plan, observations, results};
fs.writeFileSync(path.join(root, 'screen.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({banks: banks.length, sourceBytes: banks.reduce((s, x) => s + x.length, 0), results}, null, 2));
