import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/1b47f6463b98/manabitan')
CLANG = Path('/tmp/manabitan-native-9bb32/native-toolchain/bin/clang')
LINKER = CLANG.with_name('wasm-ld')
SOURCE = REPO / 'ext/js/dictionary/wasm/term-bank-parser.c'
INFLATE = SOURCE.with_name('term-bank-inflate.c')
manifest = json.loads((REPO / 'dev/data/dictionary-wasm/manifest.json').read_text())
target = next(x for x in manifest['targets'] if x['name'] == 'term-bank-parser.wasm')
original = SOURCE.read_text()
assert original.count('#define CRC32_BRAIDS 8u') == 1
rows = []
for lanes in [4, 6, 8, 12, 16]:
    source = original.replace('#define CRC32_BRAIDS 8u', f'#define CRC32_BRAIDS {lanes}u')
    path = ROOT / f'braid{lanes}.c'
    path.write_text(source)
    output = ROOT / f'braid{lanes}.wasm'
    command = [str(CLANG), f'-fuse-ld={LINKER}', *target['arguments'], '-o', str(output), str(path), str(INFLATE)]
    subprocess.run(command, check=True)
    rows.append({'lanes': lanes, 'sourceSha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                 'wasmSha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'bytes': output.stat().st_size,
                 'command': command})
baseline = REPO / 'dev/data/dictionary-wasm/term-bank-parser.wasm'
assert (ROOT / 'braid8.wasm').read_bytes() == baseline.read_bytes()
result = {'baseline': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2', 'baselineReproduced': True,
          'compiler': subprocess.check_output([str(CLANG), '--version'], text=True), 'variants': rows}
(ROOT / 'build-manifest.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
