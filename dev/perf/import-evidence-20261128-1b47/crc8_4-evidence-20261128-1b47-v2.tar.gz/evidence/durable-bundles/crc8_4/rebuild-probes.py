#!/usr/bin/env python3
"""Portable rebuild of the archived CRC probes; no measurements are run."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--source', type=Path, required=True, help='Archived evidence/crc-tail directory')
parser.add_argument('--output', type=Path, required=True, help='New output directory')
parser.add_argument('--clang', required=True)
parser.add_argument('--wasm-ld', required=True)
args = parser.parse_args()
clang_version = subprocess.check_output([args.clang, '--version'], text=True)
linker_version = subprocess.check_output([args.wasm_ld, '--version'], text=True)
assert '21.1.8' in clang_version and '21.1.8' in linker_version
args.output.mkdir(parents=True, exist_ok=False)
sha = lambda value: hashlib.sha256(value).hexdigest()
records = []
for name in ['baseline', 'tail8', 'tail4', 'tail8_4']:
    source = args.source / (name + '.c')
    target = args.output / (name + '.wasm')
    command = [args.clang, '--target=wasm32-freestanding', '-O3', '-matomics',
               '-mbulk-memory', '-msimd128', '-nostdlib', '-fuse-ld=' + args.wasm_ld,
               '-Wl,--no-entry', '-Wl,--shared-memory', '-Wl,--max-memory=4294967296',
               '-Wl,--export=probe_heap', '-Wl,--export=probe_gap',
               '-Wl,--export=probe_batch', '-Wl,--strip-all', '-o', str(target), str(source)]
    subprocess.run(command, check=True)
    expected = (args.source / (name + '.wasm')).read_bytes()
    actual = target.read_bytes()
    assert actual == expected, name
    records.append({'name': name, 'sourceSha256': sha(source.read_bytes()),
                    'wasmSha256': sha(actual), 'wasmBytes': len(actual), 'command': command})
report = {'scope': 'Rebuild only; no timing', 'clang': clang_version, 'linker': linker_version,
          'allArchivedWasmBytesMatch': True, 'records': records}
(args.output / 'rebuild-receipt.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'allArchivedWasmBytesMatch': True, 'variants': len(records)}))
