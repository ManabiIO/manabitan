#include <stdint.h>
static uint32_t crc32_table[64][256];
static uint32_t crc32_table_initialized = 0u;
#define CRC32_BRAID_THRESHOLD 262144u

static uint32_t crc32_read_u32_le(const uint8_t* data) {
    return
        (uint32_t)data[0] |
        ((uint32_t)data[1] << 8u) |
        ((uint32_t)data[2] << 16u) |
        ((uint32_t)data[3] << 24u);
}

static __attribute__((always_inline)) inline uint32_t crc32_step16(const uint8_t* data, uint32_t crc) {
    const uint32_t first = crc32_read_u32_le(data);
    const uint32_t second = crc32_read_u32_le(data + 4u);
    const uint32_t third = crc32_read_u32_le(data + 8u);
    const uint32_t fourth = crc32_read_u32_le(data + 12u);
    crc ^= first;
    return
        crc32_table[15][crc & 0xffu] ^
        crc32_table[14][(crc >> 8u) & 0xffu] ^
        crc32_table[13][(crc >> 16u) & 0xffu] ^
        crc32_table[12][crc >> 24u] ^
        crc32_table[11][second & 0xffu] ^
        crc32_table[10][(second >> 8u) & 0xffu] ^
        crc32_table[9][(second >> 16u) & 0xffu] ^
        crc32_table[8][second >> 24u] ^
        crc32_table[7][third & 0xffu] ^
        crc32_table[6][(third >> 8u) & 0xffu] ^
        crc32_table[5][(third >> 16u) & 0xffu] ^
        crc32_table[4][third >> 24u] ^
        crc32_table[3][fourth & 0xffu] ^
        crc32_table[2][(fourth >> 8u) & 0xffu] ^
        crc32_table[1][(fourth >> 16u) & 0xffu] ^
        crc32_table[0][fourth >> 24u];
}

static __attribute__((always_inline)) inline uint32_t crc32_bytes_serial(const uint8_t* data, uint32_t length) {
    uint32_t crc = 0xffffffffu;
    uint32_t offset = 0u;
    while (length - offset >= 16u) {
        crc = crc32_step16(data + offset, crc);
        offset += 16u;
    }
    while (offset < length) {
        crc = (crc >> 8u) ^ crc32_table[0][(crc ^ data[offset++]) & 0xffu];
    }
    return ~crc;
}

/* Each lane tracks interleaved eight-byte words. The table advances a
 * lane past the other lanes' words. Merge the final words in source order
 * using the ordinary slicing table to reconstruct the IEEE CRC. */
#define CRC32_BRAIDS 8u
static uint32_t crc32_braid_table[8][256];
static uint32_t crc32_braid_initialized;

static inline uint32_t crc32_word8(uint64_t word, uint32_t table[8][256]) {
    return table[7][(word >> 0u) & 0xffu] ^
        table[6][(word >> 8u) & 0xffu] ^
        table[5][(word >> 16u) & 0xffu] ^
        table[4][(word >> 24u) & 0xffu] ^
        table[3][(word >> 32u) & 0xffu] ^
        table[2][(word >> 40u) & 0xffu] ^
        table[1][(word >> 48u) & 0xffu] ^
        table[0][word >> 56u];
}

static uint32_t crc32_bytes_braided(const uint8_t* data, uint32_t length) {
    const uint32_t step = CRC32_BRAIDS * 8u;
    if (crc32_braid_initialized == 0u) {
        for (uint32_t i = 0u; i < 8u; ++i) {
            for (uint32_t j = 0u; j < 256u; ++j) {
                uint32_t crc = crc32_table[i][j];
                for (uint32_t k = 8u; k < step; ++k) {
                    crc = (crc >> 8u) ^ crc32_table[0][crc & 0xffu];
                }
                crc32_braid_table[i][j] = crc;
            }
        }
        crc32_braid_initialized = 1u;
    }
    uint32_t state[CRC32_BRAIDS] = {0xffffffffu};
    const uint32_t final_group = (length / step - 1u) * step;
    for (uint32_t offset = 0u; offset < final_group; offset += step) {
        for (uint32_t i = 0u; i < CRC32_BRAIDS; ++i) {
            uint64_t word;
            __builtin_memcpy(&word, data + offset + i * 8u, sizeof(word));
            state[i] = crc32_word8(word ^ state[i], crc32_braid_table);
        }
    }
    uint32_t crc = 0u;
    for (uint32_t i = 0u; i < CRC32_BRAIDS; ++i) {
        uint64_t word;
        __builtin_memcpy(&word, data + final_group + i * 8u, sizeof(word));
        crc = crc32_word8(word ^ state[i] ^ crc, crc32_table);
    }
    for (uint32_t offset = final_group + step; offset < length; ++offset) {
        crc = (crc >> 8u) ^ crc32_table[0][(crc ^ data[offset]) & 0xffu];
    }
    return ~crc;
}

static uint32_t crc32_bytes(const uint8_t* data, uint32_t length) {
    if (crc32_table_initialized == 0u) {
        for (uint32_t i = 0u; i < 256u; ++i) {
            uint32_t value = i;
            for (uint32_t bit = 0u; bit < 8u; ++bit) {
                value = (value >> 1u) ^ ((value & 1u) != 0u ? 0xedb88320u : 0u);
            }
            crc32_table[0][i] = value;
        }
        for (uint32_t slice = 1u; slice < 64u; ++slice) {
            for (uint32_t i = 0u; i < 256u; ++i) {
                const uint32_t value = crc32_table[slice - 1u][i];
                crc32_table[slice][i] = (value >> 8u) ^ crc32_table[0][value & 0xffu];
            }
        }
        crc32_table_initialized = 1u;
    }

    if (length < CRC32_BRAID_THRESHOLD) {
        return crc32_bytes_serial(data, length);
    }

    return crc32_bytes_braided(data, length);
}

static __attribute__((always_inline)) inline uint32_t crc32_step32(const uint8_t* data, uint32_t crc) {
    const uint32_t word0 = crc32_read_u32_le(data + 0u);
    const uint32_t word1 = crc32_read_u32_le(data + 4u);
    const uint32_t word2 = crc32_read_u32_le(data + 8u);
    const uint32_t word3 = crc32_read_u32_le(data + 12u);
    const uint32_t word4 = crc32_read_u32_le(data + 16u);
    const uint32_t word5 = crc32_read_u32_le(data + 20u);
    const uint32_t word6 = crc32_read_u32_le(data + 24u);
    const uint32_t word7 = crc32_read_u32_le(data + 28u);
    crc ^= word0;
    return
        crc32_table[31][crc & 0xffu] ^
        crc32_table[30][(crc >> 8u) & 0xffu] ^
        crc32_table[29][(crc >> 16u) & 0xffu] ^
        crc32_table[28][crc >> 24u] ^
        crc32_table[27][word1 & 0xffu] ^
        crc32_table[26][(word1 >> 8u) & 0xffu] ^
        crc32_table[25][(word1 >> 16u) & 0xffu] ^
        crc32_table[24][word1 >> 24u] ^
        crc32_table[23][word2 & 0xffu] ^
        crc32_table[22][(word2 >> 8u) & 0xffu] ^
        crc32_table[21][(word2 >> 16u) & 0xffu] ^
        crc32_table[20][word2 >> 24u] ^
        crc32_table[19][word3 & 0xffu] ^
        crc32_table[18][(word3 >> 8u) & 0xffu] ^
        crc32_table[17][(word3 >> 16u) & 0xffu] ^
        crc32_table[16][word3 >> 24u] ^
        crc32_table[15][word4 & 0xffu] ^
        crc32_table[14][(word4 >> 8u) & 0xffu] ^
        crc32_table[13][(word4 >> 16u) & 0xffu] ^
        crc32_table[12][word4 >> 24u] ^
        crc32_table[11][word5 & 0xffu] ^
        crc32_table[10][(word5 >> 8u) & 0xffu] ^
        crc32_table[9][(word5 >> 16u) & 0xffu] ^
        crc32_table[8][word5 >> 24u] ^
        crc32_table[7][word6 & 0xffu] ^
        crc32_table[6][(word6 >> 8u) & 0xffu] ^
        crc32_table[5][(word6 >> 16u) & 0xffu] ^
        crc32_table[4][word6 >> 24u] ^
        crc32_table[3][word7 & 0xffu] ^
        crc32_table[2][(word7 >> 8u) & 0xffu] ^
        crc32_table[1][(word7 >> 16u) & 0xffu] ^
        crc32_table[0][word7 >> 24u];
}
static __attribute__((always_inline)) inline uint32_t crc32_step64(const uint8_t* data, uint32_t crc) {
    const uint32_t word0 = crc32_read_u32_le(data + 0u);
    const uint32_t word1 = crc32_read_u32_le(data + 4u);
    const uint32_t word2 = crc32_read_u32_le(data + 8u);
    const uint32_t word3 = crc32_read_u32_le(data + 12u);
    const uint32_t word4 = crc32_read_u32_le(data + 16u);
    const uint32_t word5 = crc32_read_u32_le(data + 20u);
    const uint32_t word6 = crc32_read_u32_le(data + 24u);
    const uint32_t word7 = crc32_read_u32_le(data + 28u);
    const uint32_t word8 = crc32_read_u32_le(data + 32u);
    const uint32_t word9 = crc32_read_u32_le(data + 36u);
    const uint32_t word10 = crc32_read_u32_le(data + 40u);
    const uint32_t word11 = crc32_read_u32_le(data + 44u);
    const uint32_t word12 = crc32_read_u32_le(data + 48u);
    const uint32_t word13 = crc32_read_u32_le(data + 52u);
    const uint32_t word14 = crc32_read_u32_le(data + 56u);
    const uint32_t word15 = crc32_read_u32_le(data + 60u);
    crc ^= word0;
    return
        crc32_table[63][crc & 0xffu] ^
        crc32_table[62][(crc >> 8u) & 0xffu] ^
        crc32_table[61][(crc >> 16u) & 0xffu] ^
        crc32_table[60][crc >> 24u] ^
        crc32_table[59][word1 & 0xffu] ^
        crc32_table[58][(word1 >> 8u) & 0xffu] ^
        crc32_table[57][(word1 >> 16u) & 0xffu] ^
        crc32_table[56][word1 >> 24u] ^
        crc32_table[55][word2 & 0xffu] ^
        crc32_table[54][(word2 >> 8u) & 0xffu] ^
        crc32_table[53][(word2 >> 16u) & 0xffu] ^
        crc32_table[52][word2 >> 24u] ^
        crc32_table[51][word3 & 0xffu] ^
        crc32_table[50][(word3 >> 8u) & 0xffu] ^
        crc32_table[49][(word3 >> 16u) & 0xffu] ^
        crc32_table[48][word3 >> 24u] ^
        crc32_table[47][word4 & 0xffu] ^
        crc32_table[46][(word4 >> 8u) & 0xffu] ^
        crc32_table[45][(word4 >> 16u) & 0xffu] ^
        crc32_table[44][word4 >> 24u] ^
        crc32_table[43][word5 & 0xffu] ^
        crc32_table[42][(word5 >> 8u) & 0xffu] ^
        crc32_table[41][(word5 >> 16u) & 0xffu] ^
        crc32_table[40][word5 >> 24u] ^
        crc32_table[39][word6 & 0xffu] ^
        crc32_table[38][(word6 >> 8u) & 0xffu] ^
        crc32_table[37][(word6 >> 16u) & 0xffu] ^
        crc32_table[36][word6 >> 24u] ^
        crc32_table[35][word7 & 0xffu] ^
        crc32_table[34][(word7 >> 8u) & 0xffu] ^
        crc32_table[33][(word7 >> 16u) & 0xffu] ^
        crc32_table[32][word7 >> 24u] ^
        crc32_table[31][word8 & 0xffu] ^
        crc32_table[30][(word8 >> 8u) & 0xffu] ^
        crc32_table[29][(word8 >> 16u) & 0xffu] ^
        crc32_table[28][word8 >> 24u] ^
        crc32_table[27][word9 & 0xffu] ^
        crc32_table[26][(word9 >> 8u) & 0xffu] ^
        crc32_table[25][(word9 >> 16u) & 0xffu] ^
        crc32_table[24][word9 >> 24u] ^
        crc32_table[23][word10 & 0xffu] ^
        crc32_table[22][(word10 >> 8u) & 0xffu] ^
        crc32_table[21][(word10 >> 16u) & 0xffu] ^
        crc32_table[20][word10 >> 24u] ^
        crc32_table[19][word11 & 0xffu] ^
        crc32_table[18][(word11 >> 8u) & 0xffu] ^
        crc32_table[17][(word11 >> 16u) & 0xffu] ^
        crc32_table[16][word11 >> 24u] ^
        crc32_table[15][word12 & 0xffu] ^
        crc32_table[14][(word12 >> 8u) & 0xffu] ^
        crc32_table[13][(word12 >> 16u) & 0xffu] ^
        crc32_table[12][word12 >> 24u] ^
        crc32_table[11][word13 & 0xffu] ^
        crc32_table[10][(word13 >> 8u) & 0xffu] ^
        crc32_table[9][(word13 >> 16u) & 0xffu] ^
        crc32_table[8][word13 >> 24u] ^
        crc32_table[7][word14 & 0xffu] ^
        crc32_table[6][(word14 >> 8u) & 0xffu] ^
        crc32_table[5][(word14 >> 16u) & 0xffu] ^
        crc32_table[4][word14 >> 24u] ^
        crc32_table[3][word15 & 0xffu] ^
        crc32_table[2][(word15 >> 8u) & 0xffu] ^
        crc32_table[1][(word15 >> 16u) & 0xffu] ^
        crc32_table[0][word15 >> 24u];
}
static inline uint32_t crc32_step8(const uint8_t* data, uint32_t crc) {
    crc ^= crc32_read_u32_le(data);
    const uint32_t second = crc32_read_u32_le(data + 4u);
    return crc32_table[7][crc & 0xffu] ^ crc32_table[6][(crc >> 8u) & 0xffu] ^
        crc32_table[5][(crc >> 16u) & 0xffu] ^ crc32_table[4][crc >> 24u] ^
        crc32_table[3][second & 0xffu] ^ crc32_table[2][(second >> 8u) & 0xffu] ^
        crc32_table[1][(second >> 16u) & 0xffu] ^ crc32_table[0][second >> 24u];
}
static inline uint32_t crc32_step4(const uint8_t* data, uint32_t crc) {
    crc ^= crc32_read_u32_le(data);
    return crc32_table[3][crc & 0xffu] ^ crc32_table[2][(crc >> 8u) & 0xffu] ^
        crc32_table[1][(crc >> 16u) & 0xffu] ^ crc32_table[0][crc >> 24u];
}
static uint32_t crc32_update_gap(uint32_t crc, const uint8_t* data, uint32_t length) {
    crc = ~crc;
    uint32_t offset = 0u;
    while (length - offset >= 64u) {
        crc = crc32_step64(data + offset, crc);
        offset += 64u;
    }
    if (length - offset >= 32u) {
        crc = crc32_step32(data + offset, crc);
        offset += 32u;
    }
    if (length - offset >= 16u) {
        crc = crc32_step16(data + offset, crc);
        offset += 16u;
    }
    if (length - offset >= 8u) {
        crc = crc32_step8(data + offset, crc);
        offset += 8u;
    }
    if (length - offset >= 4u) {
        crc = crc32_step4(data + offset, crc);
        offset += 4u;
    }
    while (offset < length) {
        crc = (crc >> 8u) ^ crc32_table[0][(crc ^ data[offset++]) & 0xffu];
    }
    return ~crc;
}

extern unsigned char __heap_base;
uint32_t probe_heap(void) { return (uint32_t)(uintptr_t)&__heap_base; }
uint32_t probe_gap(uint32_t crc, uint32_t data_ptr, uint32_t length) {
    (void)crc32_bytes((const uint8_t*)(uintptr_t)data_ptr, 0u);
    return crc32_update_gap(crc, (const uint8_t*)(uintptr_t)data_ptr, length);
}
uint32_t probe_batch(uint32_t data_ptr, uint32_t spans_ptr, uint32_t count, uint32_t repeats) {
    const uint8_t* data = (const uint8_t*)(uintptr_t)data_ptr;
    const uint32_t* spans = (const uint32_t*)(uintptr_t)spans_ptr;
    (void)crc32_bytes(data, 0u);
    uint32_t crc = 0u;
    for (uint32_t repeat = 0; repeat < repeats; ++repeat) {
        for (uint32_t i = 0; i < count; ++i) {
            crc = crc32_update_gap(crc, data + spans[i * 2u], spans[i * 2u + 1u]);
        }
    }
    return crc;
}
