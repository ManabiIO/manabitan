import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';
import {crc32} from 'node:zlib';

const variants = ['slice16', 'slice32', 'slice64', 'slice16_table64'];
const data = await readFile(new URL('../corpus-gaps.bin', import.meta.url));
const spanBytes = await readFile(new URL('../corpus-spans.bin', import.meta.url));
const spans = new Uint32Array(spanBytes.buffer.slice(spanBytes.byteOffset, spanBytes.byteOffset + spanBytes.byteLength));
const census = JSON.parse(await readFile(new URL('../corpus-census.json', import.meta.url), 'utf8'));
const build = JSON.parse(await readFile(new URL('build-manifest.json', import.meta.url), 'utf8'));
const randomBytes = new Uint8Array(1 << 20);
let randomState = 0x8b29c153;
const random = () => (randomState = (Math.imul(randomState, 1664525) + 1013904223) >>> 0);
for (let i = 0; i < randomBytes.length; ++i) randomBytes[i] = random() >>> 24;
const probes = {};
const storage = {};
for (const arm of variants) {
    const {exports: wasm} = await WebAssembly.instantiate(await WebAssembly.compile(await readFile(new URL(`${arm}.wasm`, import.meta.url))));
    const initialMemoryBytes = wasm.memory.buffer.byteLength;
    const pointer = wasm.probe_heap();
    const spansPointer = Math.ceil((pointer + data.length) / 4) * 4;
    const randomPointer = spansPointer + spanBytes.length;
    const required = randomPointer + randomBytes.length;
    wasm.memory.grow(Math.max(0, Math.ceil(required / 65536) - wasm.memory.buffer.byteLength / 65536));
    new Uint8Array(wasm.memory.buffer, pointer, data.length).set(data);
    new Uint32Array(wasm.memory.buffer, spansPointer, spans.length).set(spans);
    new Uint8Array(wasm.memory.buffer, randomPointer, randomBytes.length).set(randomBytes);
    const initStart = performance.now();
    assert.equal(wasm.probe_gap(0, pointer, 0) >>> 0, 0);
    const initMs = performance.now() - initStart;
    probes[arm] = {wasm, pointer, spansPointer, randomPointer};
    storage[arm] = {initialMemoryBytes, heapBase: pointer, tableInitMsSingleObservation: initMs};
}

let checks = 0;
const lengths = [...Array.from({length: 257}, (_, length) => length), 511, 512, 513, 1023, 1024, 1025, 65503, 65504, 65535, 65536];
for (const length of lengths) {
    for (let alignment = 0; alignment < 16; ++alignment) {
        const view = randomBytes.subarray(alignment, alignment + length);
        for (const seed of [0, 0xffffffff, random()]) {
            const expected = crc32(view, seed);
            for (const {wasm, randomPointer} of Object.values(probes)) {
                assert.equal(wasm.probe_gap(seed, randomPointer + alignment, length) >>> 0, expected);
                ++checks;
            }
        }
    }
}
for (let i = 0; i < 512; ++i) {
    const length = random() % 65536;
    const offset = random() % (randomBytes.length - length);
    const seed = random();
    const expected = crc32(randomBytes.subarray(offset, offset + length), seed);
    for (const {wasm, randomPointer} of Object.values(probes)) {
        assert.equal(wasm.probe_gap(seed, randomPointer + offset, length) >>> 0, expected);
        ++checks;
    }
}
for (const {wasm, pointer, spansPointer} of Object.values(probes)) {
    assert.equal(wasm.probe_batch(pointer, spansPointer, spans.length / 2, 1) >>> 0, crc32(data));
    ++checks;
}

const repeats = 16;
let expected = 0;
for (let i = 0; i < repeats; ++i) expected = crc32(data, expected);
const observations = [];
const run = (arm) => {
    const {wasm, pointer, spansPointer} = probes[arm];
    const start = performance.now();
    const value = wasm.probe_batch(pointer, spansPointer, spans.length / 2, repeats) >>> 0;
    const durationMs = performance.now() - start;
    assert.equal(value, expected);
    return durationMs;
};
for (let warmup = 0; warmup < 4; ++warmup) for (const arm of variants) run(arm);
const blocks = 24;
for (let block = 0; block < blocks; ++block) {
    const start = block % variants.length;
    let order = [...variants.slice(start), ...variants.slice(0, start)];
    if (Math.floor(block / variants.length) % 2 !== 0) order.reverse();
    for (const arm of order) observations.push({block, arm, durationMs: run(arm)});
}
const median = (values) => {
    const sorted = [...values].sort((a, b) => a - b);
    return (sorted[Math.floor((sorted.length - 1) / 2)] + sorted[Math.floor(sorted.length / 2)]) / 2;
};
const medians = Object.fromEntries(variants.map((arm) => [arm, median(observations.filter((x) => x.arm === arm).map((x) => x.durationMs))]));
const paired = Object.fromEntries(variants.slice(1).map((arm) => {
    const ratios = Array.from({length: blocks}, (_, block) => observations.find((x) => x.block === block && x.arm === arm).durationMs / observations.find((x) => x.block === block && x.arm === 'slice16').durationMs);
    return [arm, {medianChangePct: 100 * (median(ratios) - 1), geometricMeanChangePct: 100 * (Math.exp(ratios.reduce((sum, x) => sum + Math.log(x), 0) / ratios.length) - 1), fasterBlocks: ratios.filter((x) => x < 1).length, ratios}];
}));
const report = {
    scope: 'Isolated CRC update component on captured VNDB gap bytes. Continuous CRC state over concatenated gaps; actual glossary combination and parser/storage work excluded. Slicing tables initialized before timing; whole-bank braid source unchanged. Expanded-table same-step control included.',
    runtime: process.version, checks, repeats, blocks, expected,
    corpus: {...census, lengths: undefined, groupStats: undefined},
    dataSha256: createHash('sha256').update(data).digest('hex'),
    spansSha256: createHash('sha256').update(spanBytes).digest('hex'),
    bytesPerObservation: data.length * repeats, spanCount: spans.length / 2,
    build, storage, medians, paired, observations,
};
await writeFile(new URL('screen.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({checks, storage, medians, paired: Object.fromEntries(Object.entries(paired).map(([arm, value]) => [arm, {...value, ratios: undefined}]))}));
