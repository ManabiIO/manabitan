import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
CLANG = Path('/tmp/manabitan-native-9bb32/native-toolchain/bin/clang')
LINKER = CLANG.with_name('wasm-ld')
original = (ROOT.parent / 'tail8_4.c').read_text()


def step(width):
    lines = [f'static __attribute__((always_inline)) inline uint32_t crc32_step{width}(const uint8_t* data, uint32_t crc) {{']
    for i in range(width // 4):
        lines.append(f'    const uint32_t word{i} = crc32_read_u32_le(data + {i * 4}u);')
    lines.append('    crc ^= word0;')
    lines.append('    return')
    terms = []
    for i in range(width // 4):
        word = 'crc' if i == 0 else f'word{i}'
        for j in range(4):
            value = f'{word} & 0xffu' if j == 0 else f'({word} >> {j * 8}u) & 0xffu'
            if j == 3:
                value = f'{word} >> 24u'
            terms.append(f'        crc32_table[{width - i * 4 - j - 1}][{value}]')
    lines.append(' ^\n'.join(terms) + ';')
    lines.append('}\n')
    return '\n'.join(lines)


def make_source(width, table_size):
    source = original.replace('static uint32_t crc32_table[16][256];', f'static uint32_t crc32_table[{table_size}][256];')
    source = source.replace('slice < 16u;', f'slice < {table_size}u;')
    helpers = ''.join(step(size) for size in (32, 64) if size <= width)
    source = source.replace('static inline uint32_t crc32_step8(', helpers + 'static inline uint32_t crc32_step8(')
    start = source.index('static uint32_t crc32_update_gap(')
    end = source.index('\nextern unsigned char __heap_base;', start)
    lines = [
        'static uint32_t crc32_update_gap(uint32_t crc, const uint8_t* data, uint32_t length) {',
        '    crc = ~crc;',
        '    uint32_t offset = 0u;',
        f'    while (length - offset >= {width}u) {{',
        f'        crc = crc32_step{width}(data + offset, crc);',
        f'        offset += {width}u;',
        '    }',
    ]
    for size in (32, 16, 8, 4):
        if size >= width:
            continue
        lines += [
            f'    if (length - offset >= {size}u) {{',
            f'        crc = crc32_step{size}(data + offset, crc);',
            f'        offset += {size}u;',
            '    }',
        ]
    lines += [
        '    while (offset < length) {',
        '        crc = (crc >> 8u) ^ crc32_table[0][(crc ^ data[offset++]) & 0xffu];',
        '    }',
        '    return ~crc;',
        '}\n',
    ]
    return source[:start] + '\n'.join(lines) + source[end:]


variants = [('slice16', 16, 16), ('slice32', 32, 32), ('slice64', 64, 64), ('slice16_table64', 16, 64)]
manifest = {'scope': 'Isolated CRC gap component probes; production parser and whole-bank braided loop unchanged', 'variants': []}
for name, width, table_size in variants:
    source = original if name == 'slice16' else make_source(width, table_size)
    source_path = ROOT / f'{name}.c'
    output_path = ROOT / f'{name}.wasm'
    source_path.write_text(source)
    command = [str(CLANG), f'-fuse-ld={LINKER}', '--target=wasm32-freestanding', '-O3', '-matomics', '-mbulk-memory', '-msimd128', '-nostdlib', '-Wl,--no-entry', '-Wl,--shared-memory', '-Wl,--max-memory=4294967296', '-Wl,--export=probe_heap', '-Wl,--export=probe_gap', '-Wl,--export=probe_batch', '-Wl,--strip-all', '-o', str(output_path), str(source_path)]
    subprocess.run(command, check=True)
    manifest['variants'].append({'name': name, 'sliceBytes': width, 'tableBytes': table_size * 256 * 4, 'sourceSha256': hashlib.sha256(source_path.read_bytes()).hexdigest(), 'wasmSha256': hashlib.sha256(output_path.read_bytes()).hexdigest(), 'wasmBytes': output_path.stat().st_size, 'command': command})
manifest['compiler'] = subprocess.check_output([str(CLANG), '--version'], text=True).strip()
(ROOT / 'build-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'variants': [{k: row[k] for k in ('name', 'tableBytes', 'wasmBytes', 'wasmSha256')} for row in manifest['variants']]}))
