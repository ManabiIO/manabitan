#include <stdint.h>
static uint32_t crc32_table[16][256];
static uint32_t crc32_table_initialized = 0u;
#define CRC32_BRAID_THRESHOLD 262144u

static uint32_t crc32_read_u32_le(const uint8_t* data) {
    return
        (uint32_t)data[0] |
        ((uint32_t)data[1] << 8u) |
        ((uint32_t)data[2] << 16u) |
        ((uint32_t)data[3] << 24u);
}

static __attribute__((always_inline)) inline uint32_t crc32_step16(const uint8_t* data, uint32_t crc) {
    const uint32_t first = crc32_read_u32_le(data);
    const uint32_t second = crc32_read_u32_le(data + 4u);
    const uint32_t third = crc32_read_u32_le(data + 8u);
    const uint32_t fourth = crc32_read_u32_le(data + 12u);
    crc ^= first;
    return
        crc32_table[15][crc & 0xffu] ^
        crc32_table[14][(crc >> 8u) & 0xffu] ^
        crc32_table[13][(crc >> 16u) & 0xffu] ^
        crc32_table[12][crc >> 24u] ^
        crc32_table[11][second & 0xffu] ^
        crc32_table[10][(second >> 8u) & 0xffu] ^
        crc32_table[9][(second >> 16u) & 0xffu] ^
        crc32_table[8][second >> 24u] ^
        crc32_table[7][third & 0xffu] ^
        crc32_table[6][(third >> 8u) & 0xffu] ^
        crc32_table[5][(third >> 16u) & 0xffu] ^
        crc32_table[4][third >> 24u] ^
        crc32_table[3][fourth & 0xffu] ^
        crc32_table[2][(fourth >> 8u) & 0xffu] ^
        crc32_table[1][(fourth >> 16u) & 0xffu] ^
        crc32_table[0][fourth >> 24u];
}

static __attribute__((always_inline)) inline uint32_t crc32_bytes_serial(const uint8_t* data, uint32_t length) {
    uint32_t crc = 0xffffffffu;
    uint32_t offset = 0u;
    while (length - offset >= 16u) {
        crc = crc32_step16(data + offset, crc);
        offset += 16u;
    }
    while (offset < length) {
        crc = (crc >> 8u) ^ crc32_table[0][(crc ^ data[offset++]) & 0xffu];
    }
    return ~crc;
}

/* Each lane tracks interleaved eight-byte words. The table advances a
 * lane past the other lanes' words. Merge the final words in source order
 * using the ordinary slicing table to reconstruct the IEEE CRC. */
#define CRC32_BRAIDS 8u
static uint32_t crc32_braid_table[8][256];
static uint32_t crc32_braid_initialized;

static inline uint32_t crc32_word8(uint64_t word, uint32_t table[8][256]) {
    return table[7][(word >> 0u) & 0xffu] ^
        table[6][(word >> 8u) & 0xffu] ^
        table[5][(word >> 16u) & 0xffu] ^
        table[4][(word >> 24u) & 0xffu] ^
        table[3][(word >> 32u) & 0xffu] ^
        table[2][(word >> 40u) & 0xffu] ^
        table[1][(word >> 48u) & 0xffu] ^
        table[0][word >> 56u];
}

static uint32_t crc32_bytes_braided(const uint8_t* data, uint32_t length) {
    const uint32_t step = CRC32_BRAIDS * 8u;
    if (crc32_braid_initialized == 0u) {
        for (uint32_t i = 0u; i < 8u; ++i) {
            for (uint32_t j = 0u; j < 256u; ++j) {
                uint32_t crc = crc32_table[i][j];
                for (uint32_t k = 8u; k < step; ++k) {
                    crc = (crc >> 8u) ^ crc32_table[0][crc & 0xffu];
                }
                crc32_braid_table[i][j] = crc;
            }
        }
        crc32_braid_initialized = 1u;
    }
    uint32_t state[CRC32_BRAIDS] = {0xffffffffu};
    const uint32_t final_group = (length / step - 1u) * step;
    for (uint32_t offset = 0u; offset < final_group; offset += step) {
        for (uint32_t i = 0u; i < CRC32_BRAIDS; ++i) {
            uint64_t word;
            __builtin_memcpy(&word, data + offset + i * 8u, sizeof(word));
            state[i] = crc32_word8(word ^ state[i], crc32_braid_table);
        }
    }
    uint32_t crc = 0u;
    for (uint32_t i = 0u; i < CRC32_BRAIDS; ++i) {
        uint64_t word;
        __builtin_memcpy(&word, data + final_group + i * 8u, sizeof(word));
        crc = crc32_word8(word ^ state[i] ^ crc, crc32_table);
    }
    for (uint32_t offset = final_group + step; offset < length; ++offset) {
        crc = (crc >> 8u) ^ crc32_table[0][(crc ^ data[offset]) & 0xffu];
    }
    return ~crc;
}

static uint32_t crc32_bytes(const uint8_t* data, uint32_t length) {
    if (crc32_table_initialized == 0u) {
        for (uint32_t i = 0u; i < 256u; ++i) {
            uint32_t value = i;
            for (uint32_t bit = 0u; bit < 8u; ++bit) {
                value = (value >> 1u) ^ ((value & 1u) != 0u ? 0xedb88320u : 0u);
            }
            crc32_table[0][i] = value;
        }
        for (uint32_t slice = 1u; slice < 16u; ++slice) {
            for (uint32_t i = 0u; i < 256u; ++i) {
                const uint32_t value = crc32_table[slice - 1u][i];
                crc32_table[slice][i] = (value >> 8u) ^ crc32_table[0][value & 0xffu];
            }
        }
        crc32_table_initialized = 1u;
    }

    if (length < CRC32_BRAID_THRESHOLD) {
        return crc32_bytes_serial(data, length);
    }

    return crc32_bytes_braided(data, length);
}

static inline uint32_t crc32_step8(const uint8_t* data, uint32_t crc) {
    crc ^= crc32_read_u32_le(data);
    const uint32_t second = crc32_read_u32_le(data + 4u);
    return crc32_table[7][crc & 0xffu] ^ crc32_table[6][(crc >> 8u) & 0xffu] ^
        crc32_table[5][(crc >> 16u) & 0xffu] ^ crc32_table[4][crc >> 24u] ^
        crc32_table[3][second & 0xffu] ^ crc32_table[2][(second >> 8u) & 0xffu] ^
        crc32_table[1][(second >> 16u) & 0xffu] ^ crc32_table[0][second >> 24u];
}
static inline uint32_t crc32_step4(const uint8_t* data, uint32_t crc) {
    crc ^= crc32_read_u32_le(data);
    return crc32_table[3][crc & 0xffu] ^ crc32_table[2][(crc >> 8u) & 0xffu] ^
        crc32_table[1][(crc >> 16u) & 0xffu] ^ crc32_table[0][crc >> 24u];
}
static uint32_t crc32_update_gap(uint32_t crc, const uint8_t* data, uint32_t length) {
    crc = ~crc;
    uint32_t offset = 0u;
    while (length - offset >= 16u) {
        crc = crc32_step16(data + offset, crc);
        offset += 16u;
    }
    if (length - offset >= 8u) {
        crc = crc32_step8(data + offset, crc);
        offset += 8u;
    }
    while (offset < length) {
        crc = (crc >> 8u) ^ crc32_table[0][(crc ^ data[offset++]) & 0xffu];
    }
    return ~crc;
}
extern unsigned char __heap_base;
uint32_t probe_heap(void) { return (uint32_t)(uintptr_t)&__heap_base; }
uint32_t probe_gap(uint32_t crc, uint32_t data_ptr, uint32_t length) {
    (void)crc32_bytes((const uint8_t*)(uintptr_t)data_ptr, 0u);
    return crc32_update_gap(crc, (const uint8_t*)(uintptr_t)data_ptr, length);
}
uint32_t probe_batch(uint32_t data_ptr, uint32_t spans_ptr, uint32_t count, uint32_t repeats) {
    const uint8_t* data = (const uint8_t*)(uintptr_t)data_ptr;
    const uint32_t* spans = (const uint32_t*)(uintptr_t)spans_ptr;
    (void)crc32_bytes(data, 0u);
    uint32_t crc = 0u;
    for (uint32_t repeat = 0; repeat < repeats; ++repeat) {
        for (uint32_t i = 0; i < count; ++i) {
            crc = crc32_update_gap(crc, data + spans[i * 2u], spans[i * 2u + 1u]);
        }
    }
    return crc;
}
