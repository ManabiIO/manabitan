/* SPDX-License-Identifier: GPL-3.0-or-later */
// Capture production verifier inputs before its destructive witness update.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream, openAsBlob} from 'node:fs';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';

const [sourcePath, cachePath, destinationPath] = process.argv.slice(2);
assert(sourcePath && cachePath && destinationPath);
const root = resolve(sourcePath);
const destination = resolve(destinationPath);
assert(destination.startsWith('/tmp/manabitan-1b47-'));
const sha = (value) => createHash('sha256').update(value).digest('hex');
const sourceCommit = execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim();
assert.equal(sourceCommit, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
const relativeImport = (path) => import(pathToFileURL(join(root, path)));
const parser = await relativeImport('ext/js/dictionary/term-bank-wasm-parser.js');
const {readDenseZipDirectory} = await relativeImport('ext/js/dictionary/dense-zip-directory.js');
const {RawZipPayloadReader} = await relativeImport('ext/js/dictionary/term-bank-source-pipeline.js');
const lockBytes = await readFile(join(root, 'test/perf/dictionaries.lock.json'));
const fixture = JSON.parse(lockBytes).dictionaries.vndb;
const archivePath = join(cachePath, fixture.cacheFile);
const archiveDigest = createHash('sha256');
for await (const bytes of createReadStream(archivePath)) { archiveDigest.update(bytes); }
assert.equal(archiveDigest.digest('hex'), fixture.sha256);
const archive = await openAsBlob(archivePath);
assert.equal(archive.size, fixture.sizeBytes);
const directory = await readDenseZipDirectory(archive);
assert(directory);
const entries = new Map(directory.map((entry) => [entry.filename, entry]));
const reader = new RawZipPayloadReader(archive);
const signal = new AbortController().signal;
const wasmBytes = await readFile(join(root, 'dev/data/dictionary-wasm/term-bank-parser.wasm'));
const nativeManifest = JSON.parse(await readFile(join(root, 'dev/data/dictionary-wasm/manifest.json')));
assert.equal(sha(wasmBytes), nativeManifest.targets.find(({name}) => name === 'term-bank-parser.wasm').sha256);
parser.setTermBankWasmModule(await WebAssembly.compile(wasmBytes));
const options = {
    computeContentHashes: true,
    emitContentSlab: true,
    emitTokenBinaryContent: true,
    emitTermByteLists: false,
    useNativeStringPlan: true,
    singleChunk: true,
    validateGlossaryTypes: true,
    mediaHintFastScan: true,
    projectImagePaths: true,
    prepareLookupIndexes: true,
    prepareLookupRoute: true,
};
const selectedGroups = [
    {name: 'banks-001-002', indexes: [1, 2]},
    {name: 'banks-333-334', indexes: [333, 334]},
    {name: 'banks-663-665', indexes: [663, 664, 665]},
];
await mkdir(destination, {recursive: true});
const groups = [];
for (const selected of selectedGroups) {
    const files = selected.indexes.map((index) => `term_bank_${index}.json`);
    const sources = await Promise.all(files.map(async (filename) => {
        const entry = entries.get(filename);
        assert(entry);
        return {bytes: await reader.read(entry, signal), compressionMethod: entry.compressionMethod, compressedSize: entry.compressedSize, uncompressedSize: entry.uncompressedSize, signature: entry.signature, filename};
    }));
    const preloaded = await parser.inflateCompressedTermBankSourcesWasm(sources, options, true);
    assert(preloaded.crcSignaturesPtr, 'Selected group must use deferred production CRC');
    const wasm = preloaded.wasm;
    const originalVerify = wasm.verify_term_bank_source_crcs;
    assert.equal(typeof originalVerify, 'function');
    let captured = null;
    let callCount = 0;
    wasm.verify_term_bank_source_crcs = (...args) => {
        ++callCount;
        assert.equal(callCount, 1, 'Capture exactly one successful glossary-witness verifier call');
        const [jsonPtr, jsonLength, spansPtr, bankCount, signaturesPtr, metasPtr, rowCount, witnessesPtr, statsPtr] = args;
        assert(rowCount > 0 && witnessesPtr > 0 && statsPtr > 0);
        const copyBytes = (pointer, length) => Buffer.from(new Uint8Array(wasm.memory.buffer, pointer, length));
        const inputs = {
            json: copyBytes(jsonPtr, jsonLength),
            spans: copyBytes(spansPtr, bankCount * 2 * 4),
            signatures: copyBytes(signaturesPtr, bankCount * 4),
            metadata: copyBytes(metasPtr, rowCount * 17 * 4),
            witnesses: copyBytes(witnessesPtr, rowCount * 4),
            stats: copyBytes(statsPtr, 3 * 4),
        };
        const result = originalVerify(...args);
        assert.equal(result, 0);
        const outputs = {
            witnesses: copyBytes(witnessesPtr, rowCount * 4),
            stats: copyBytes(statsPtr, 3 * 4),
        };
        captured = {args, jsonLength, bankCount, rowCount, inputs, outputs};
        return result;
    };
    let parsedRows = 0;
    try {
        await parser.parseTermBankWithWasmColumnChunks(new Uint8Array(), 3, (chunk) => { parsedRows += chunk.rowCount; }, 2048, {...options, preloadedSource: preloaded});
    } finally {
        wasm.verify_term_bank_source_crcs = originalVerify;
    }
    assert.equal(preloaded.crcVerified, true);
    assert.equal(callCount, 1);
    assert(captured);
    assert.equal(captured.rowCount, parsedRows);
    const metadata = new Uint32Array(captured.inputs.metadata.buffer, captured.inputs.metadata.byteOffset, captured.rowCount * 17);
    const witnesses = new Uint32Array(captured.inputs.witnesses.buffer, captured.inputs.witnesses.byteOffset, captured.rowCount);
    let rawGlossaries = 0;
    let reusedGlossaries = 0;
    for (let row = 0; row < captured.rowCount; ++row) {
        if (witnesses[row] === 0xffffffff) { ++rawGlossaries; }
        else {
            assert(witnesses[row] < row);
            assert.equal(metadata[witnesses[row] * 17 + 10], metadata[row * 17 + 10]);
            ++reusedGlossaries;
        }
    }
    const stats = [...new Uint32Array(captured.outputs.stats.buffer, captured.outputs.stats.byteOffset, 3)];
    assert.equal(stats[0] + stats[1], captured.jsonLength);
    assert.equal(stats[2], reusedGlossaries);
    const groupPath = join(destination, selected.name);
    await mkdir(groupPath);
    const records = {};
    for (const [kind, values] of Object.entries({input: captured.inputs, output: captured.outputs})) {
        for (const [name, bytes] of Object.entries(values)) {
            const filename = `${kind}-${name}.bin`;
            await writeFile(join(groupPath, filename), bytes, {flag: 'wx'});
            records[`${kind}.${name}`] = {filename, bytes: bytes.byteLength, sha256: sha(bytes)};
        }
    }
    const group = {
        name: selected.name, files, originalNativeArguments: captured.args,
        jsonLength: captured.jsonLength, bankCount: captured.bankCount, rowCount: captured.rowCount,
        rawGlossaries, reusedGlossaries, expectedStats: stats,
        zipSources: sources.map(({bytes, ...source}) => ({...source, compressedPayloadSha256: sha(bytes)})),
        records,
    };
    await writeFile(join(groupPath, 'manifest.json'), JSON.stringify(group, null, 2) + '\n', {flag: 'wx'});
    groups.push(group);
    process.stdout.write(JSON.stringify({group: group.name, rows: group.rowCount, jsonBytes: group.jsonLength, rawGlossaries, reusedGlossaries, expectedStats: stats}) + '\n');
}
const manifest = {
    scope: 'Immutable production verify_term_bank_source_crcs input snapshots captured before its destructive witness-ID-to-CRC transformation; expected witness CRCs and stats captured immediately after the unchanged baseline export returned zero. Not a performance measurement.',
    sourceCommit, node: process.version, fixture, lockSha256: sha(lockBytes),
    wasmSha256: sha(wasmBytes), wasmBytes: wasmBytes.byteLength,
    parserWrapperSha256: sha(await readFile(join(root, 'ext/js/dictionary/term-bank-wasm-parser.js'))),
    nativeSourceSha256: sha(await readFile(join(root, 'ext/js/dictionary/wasm/term-bank-parser.c'))),
    nativeManifest, captureScriptSha256: sha(await readFile(new URL(import.meta.url))),
    destination, options, groups,
    totalSnapshotBytes: groups.reduce((sum, group) => sum + Object.values(group.records).reduce((part, record) => part + record.bytes, 0), 0),
};
await writeFile(join(destination, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n', {flag: 'wx'});
await writeFile(new URL('verify-inputs-manifest.json', import.meta.url), JSON.stringify(manifest, null, 2) + '\n', {flag: 'wx'});
process.stdout.write(JSON.stringify({destination, groups: groups.length, totalSnapshotBytes: manifest.totalSnapshotBytes, peakRssKiB: process.resourceUsage().maxRSS}) + '\n');
