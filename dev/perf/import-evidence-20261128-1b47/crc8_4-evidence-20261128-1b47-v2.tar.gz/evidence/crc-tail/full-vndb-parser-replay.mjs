/* SPDX-License-Identifier: GPL-3.0-or-later */
// Native parser component replay. No database, compression sink, browser, media
// import, publication, or whole-import timing is represented by this experiment.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream, openAsBlob} from 'node:fs';
import {readFile, writeFile, appendFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';

const [baselinePath, candidatePath, cachePath, outputPath, bankLimitText = '0', candidateNativeCommit, candidateWasmOverride, initialOrder = 'AB'] = process.argv.slice(2);
assert(baselinePath && candidatePath && cachePath && outputPath);
assert.equal(Boolean(candidateNativeCommit), Boolean(candidateWasmOverride), 'Native checkpoint override requires both commit and WASM path');
assert(initialOrder === 'AB' || initialOrder === 'BA');
const roots = {A: resolve(baselinePath), B: resolve(candidatePath)};
const limit = Number(bankLimitText);
assert(Number.isInteger(limit) && limit >= 0);
const output = resolve(outputPath);
const sha = (value) => createHash('sha256').update(value).digest('hex');
const sourceFile = 'ext/js/dictionary/term-bank-wasm-parser.js';
const wasmFile = 'dev/data/dictionary-wasm/term-bank-parser.wasm';
assert.deepEqual(await readFile(join(roots.A, sourceFile)), await readFile(join(roots.B, sourceFile)), 'Only native WASM may differ between parser arms');
assert.deepEqual(await readFile(join(roots.A, 'package-lock.json')), await readFile(join(roots.B, 'package-lock.json')));
const lockBytes = await readFile(join(roots.A, 'test/perf/dictionaries.lock.json'));
assert.deepEqual(lockBytes, await readFile(join(roots.B, 'test/perf/dictionaries.lock.json')));
const fixture = JSON.parse(lockBytes).dictionaries.vndb;
const parsers = {};
const identities = {};
const loadedWasmPaths = {};
for (const arm of ['A', 'B']) {
    const checkpoint = arm === 'B' ? candidateNativeCommit : null;
    const readNativeFile = async (path) => checkpoint ? execFileSync('git', ['show', checkpoint + ':' + path], {cwd: roots[arm], maxBuffer: 4 * 1024 * 1024}) : await readFile(join(roots[arm], path));
    loadedWasmPaths[arm] = checkpoint ? resolve(candidateWasmOverride) : join(roots[arm], wasmFile);
    const wasmBytes = await readFile(loadedWasmPaths[arm]);
    if (checkpoint) {
        assert.deepEqual(wasmBytes, await readNativeFile(wasmFile), 'Checkpoint WASM must equal the binary committed with its recorded source');
        assert.deepEqual(await readFile(join(roots[arm], sourceFile)), await readNativeFile(sourceFile), 'Checkpoint JS wrapper must equal the loaded wrapper');
    }
    const manifest = JSON.parse(await readNativeFile('dev/data/dictionary-wasm/manifest.json'));
    assert.equal(manifest.targets.find((target) => target.name === 'term-bank-parser.wasm').sha256, sha(wasmBytes));
    parsers[arm] = await import(pathToFileURL(join(roots[arm], sourceFile)));
    parsers[arm].setTermBankWasmModule(await WebAssembly.compile(wasmBytes));
    identities[arm] = {
        root: roots[arm],
        commit: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: roots[arm], encoding: 'utf8'}).trim(),
        nativeCheckpointCommit: checkpoint ?? null,
        loadedWasmPath: loadedWasmPaths[arm],
        dirty: execFileSync('git', ['status', '--porcelain'], {cwd: roots[arm], encoding: 'utf8'}).trim(),
        parserSourceSha256: sha(await readFile(join(roots[arm], sourceFile))),
        nativeParserSourceSha256: sha(await readNativeFile('ext/js/dictionary/wasm/term-bank-parser.c')),
        nativeInflateSourceSha256: sha(await readNativeFile('ext/js/dictionary/wasm/term-bank-inflate.c')),
        wasmSha256: sha(wasmBytes),
        wasmBytes: wasmBytes.byteLength,
        manifest,
    };
}
const archivePath = join(cachePath, fixture.cacheFile);
const archiveHash = createHash('sha256');
for await (const data of createReadStream(archivePath)) { archiveHash.update(data); }
assert.equal(archiveHash.digest('hex'), fixture.sha256);
const archive = await openAsBlob(archivePath);
assert.equal(archive.size, fixture.sizeBytes);
const {readDenseZipDirectory} = await import(pathToFileURL(join(roots.A, 'ext/js/dictionary/dense-zip-directory.js')));
const {RawZipPayloadReader} = await import(pathToFileURL(join(roots.A, 'ext/js/dictionary/term-bank-source-pipeline.js')));
const entries = await readDenseZipDirectory(archive);
assert(entries);
const allBanks = entries.filter(({filename}) => /^term_bank_\d+\.json$/.test(filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)));
const banks = limit ? allBanks.slice(0, limit) : allBanks;
const groups = [];
for (let start = 0; start < banks.length;) {
    const count = banks.length - start === 3 ? 3 : Math.min(2, banks.length - start);
    groups.push(banks.slice(start, start + count));
    start += count;
}
const reader = new RawZipPayloadReader(archive);
const signal = new AbortController().signal;
const options = {
    computeContentHashes: true,
    emitContentSlab: true,
    emitTokenBinaryContent: true,
    emitTermByteLists: false,
    useNativeStringPlan: true,
    singleChunk: true,
    validateGlossaryTypes: true,
    mediaHintFastScan: true,
    projectImagePaths: true,
    prepareLookupIndexes: true,
    prepareLookupRoute: true,
};
const sourceDigest = {A: createHash('sha256'), B: createHash('sha256')};
const outputDigest = {A: createHash('sha256'), B: createHash('sha256')};
const observations = [];
let comparedByteCount = 0;
let comparedLeafCount = 0;
let rows = 0;
let completed = false;
let failure = null;
const beginning = performance.now();
const scope = 'Sequential native-parser component only: real compressed ZIP payloads → native inflation and unchanged source CRC validation → native column parser and prepared lookup plans. Complete two-bank groups, final three banks together; AB/BA alternates per group after an untimed first-group warmup in each arm. Exact byte/value comparisons happen outside phase timers. No full-import speed claim. parseBankMs includes crcMs; never add them together.';

async function readSources(files) {
    return await Promise.all(files.map(async (entry) => ({
        bytes: await reader.read(entry, signal),
        compressionMethod: entry.compressionMethod,
        compressedSize: entry.compressedSize,
        uncompressedSize: entry.uncompressedSize,
        signature: entry.signature,
        filename: entry.filename,
    })));
}

async function parse(arm, sources) {
    const parser = parsers[arm];
    const chunks = [];
    const cpuStart = process.cpuUsage();
    const start = performance.now();
    const preloaded = await parser.inflateCompressedTermBankSourcesWasm(sources, options, true);
    const afterInflate = performance.now();
    await parser.parseTermBankWithWasmColumnChunks(new Uint8Array(), 3, (chunk) => { chunks.push(chunk); }, 2048, {...options, preloadedSource: preloaded});
    const end = performance.now();
    const cpu = process.cpuUsage(cpuStart);
    const profile = parser.consumeLastTermBankWasmParseProfile();
    const deferred = Boolean(preloaded.crcSignaturesPtr);
    if (deferred) { assert.equal(preloaded.crcVerified, true, 'Deferred ZIP CRC must be verified before output comparison'); }
    assert.equal(chunks.length, 1, 'Expected one complete native group');
    return {
        chunks,
        preloaded,
        measurement: {
            elapsedMs: end - start,
            inflateWallMs: afterInflate - start,
            parseWallMs: end - afterInflate,
            inflateMs: preloaded.inflateMs,
            crcMs: preloaded.crcMs ?? 0,
            crcScannedBytes: preloaded.crcScannedBytes ?? 0,
            crcReusedBytes: preloaded.crcReusedBytes ?? 0,
            crcReusedGlossaryCount: preloaded.crcReusedGlossaryCount ?? 0,
            deferred,
            crcValidation: deferred ? 'verified-after-parse' : 'verified-during-inflate',
            compressedBytes: preloaded.compressedBytes,
            uncompressedBytes: preloaded.uncompressedBytes,
            wasmHeapBytes: preloaded.wasm.memory.buffer.byteLength,
            cpuUserMs: cpu.user / 1000,
            cpuSystemMs: cpu.system / 1000,
            cpuTotalMs: (cpu.user + cpu.system) / 1000,
            profile,
        },
    };
}

function compareValue(a, b, path) {
    ++comparedLeafCount;
    const label = path + '\n';
    outputDigest.A.update(label);
    outputDigest.B.update(label);
    if (ArrayBuffer.isView(a) || ArrayBuffer.isView(b)) {
        assert(ArrayBuffer.isView(a) && ArrayBuffer.isView(b), path);
        assert.equal(a.constructor.name, b.constructor.name, path + ': typed array class');
        assert.equal(a.byteLength, b.byteLength, path + ': typed array size');
        const left = Buffer.from(a.buffer, a.byteOffset, a.byteLength);
        const right = Buffer.from(b.buffer, b.byteOffset, b.byteLength);
        assert(left.equals(right), path + ': byte mismatch');
        outputDigest.A.update(a.constructor.name + ':' + a.byteLength + '\n');
        outputDigest.B.update(b.constructor.name + ':' + b.byteLength + '\n');
        outputDigest.A.update(left);
        outputDigest.B.update(right);
        comparedByteCount += a.byteLength;
    } else if (Array.isArray(a) || Array.isArray(b)) {
        assert(Array.isArray(a) && Array.isArray(b), path);
        assert.equal(a.length, b.length, path + ': array size');
        for (let i = 0; i < a.length; ++i) { compareValue(a[i], b[i], path + '[' + i + ']'); }
    } else if (a instanceof Map || b instanceof Map) {
        assert(a instanceof Map && b instanceof Map, path);
        assert.deepEqual([...a.keys()], [...b.keys()], path + ': map keys');
        for (const [key, value] of a) { compareValue(value, b.get(key), path + '.map(' + key + ')'); }
    } else if (a !== null && typeof a === 'object' || b !== null && typeof b === 'object') {
        assert(a !== null && b !== null && typeof a === 'object' && typeof b === 'object', path);
        const keys = Object.keys(a).sort();
        assert.deepEqual(keys, Object.keys(b).sort(), path + ': object keys');
        for (const key of keys) { compareValue(a[key], b[key], path + '.' + key); }
    } else {
        assert.equal(a, b, path + ': scalar mismatch');
        assert.notEqual(typeof a, 'function', path + ': unsupported opaque function');
        const value = typeof a + ':' + (Object.is(a, -0) ? '-0' : String(a)) + '\n';
        outputDigest.A.update(value);
        outputDigest.B.update(value);
    }
}

function normalizeChunk(chunk) {
    assert(Number.isSafeInteger(chunk.contentBytesLength));
    const start = chunk.contentBytesBaseOffset ?? 0;
    const end = start + chunk.contentBytesLength;
    const value = {...chunk, contentBytesBuffer: chunk.contentBytesBuffer.subarray(start, end), contentBytesBaseOffset: 0};
    delete value.preparedLookupIndexEncodeMs;
    return value;
}

function summarize() {
    const phaseKeys = ['elapsedMs', 'inflateWallMs', 'parseWallMs', 'inflateMs', 'crcMs', 'crcScannedBytes', 'crcReusedBytes', 'crcReusedGlossaryCount', 'compressedBytes', 'uncompressedBytes', 'cpuUserMs', 'cpuSystemMs', 'cpuTotalMs'];
    const totals = {};
    for (const arm of ['A', 'B']) {
        totals[arm] = Object.fromEntries(phaseKeys.map((key) => [key, observations.reduce((sum, row) => sum + row[arm][key], 0)]));
        totals[arm].parseBankMs = observations.reduce((sum, row) => sum + row[arm].profile.parseBankMs, 0);
        totals[arm].maximumWasmHeapBytes = Math.max(0, ...observations.map((row) => row[arm].wasmHeapBytes));
        totals[arm].deferredGroupCount = observations.filter((row) => row[arm].deferred).length;
    }
    const percent = Object.fromEntries(['elapsedMs', 'inflateMs', 'parseWallMs', 'parseBankMs', 'crcMs', 'cpuTotalMs'].map((key) => [key, totals.A[key] > 0 ? 100 * (totals.B[key] / totals.A[key] - 1) : null]));
    const ratios = observations.filter((row) => row.A.crcMs > 0).map((row) => row.B.crcMs / row.A.crcMs).sort((a, b) => a - b);
    const medianRatio = ratios.length ? (ratios[Math.floor((ratios.length - 1) / 2)] + ratios[Math.floor(ratios.length / 2)]) / 2 : null;
    return {totals, equalCorpusCandidateChangePercent: percent, medianGroupCrcChangePercent: medianRatio === null ? null : 100 * (medianRatio - 1), fasterCrcGroups: ratios.filter((ratio) => ratio < 1).length, comparableCrcGroups: ratios.length};
}

await writeFile(output + '.groups.jsonl', '', {flag: 'wx'});
try {
    const warmupSources = await readSources(groups[0]);
    for (const arm of initialOrder) { await parse(arm, warmupSources); }
    for (let index = 0; index < groups.length; ++index) {
        const sources = await readSources(groups[index]);
        const order = (index % 2 === 0 ? initialOrder : [...initialOrder].reverse().join('')).split('');
        const results = {};
        for (const arm of order) { results[arm] = await parse(arm, sources); }
        const left = results.A;
        const right = results.B;
        assert.equal(left.measurement.deferred, right.measurement.deferred);
        assert.equal(left.measurement.crcScannedBytes, right.measurement.crcScannedBytes);
        assert.equal(left.measurement.crcReusedBytes, right.measurement.crcReusedBytes);
        assert.equal(left.measurement.crcReusedGlossaryCount, right.measurement.crcReusedGlossaryCount);
        const sourceA = new Uint8Array(left.preloaded.wasm.memory.buffer, left.preloaded.jsonPtr, left.preloaded.jsonLength);
        const sourceB = new Uint8Array(right.preloaded.wasm.memory.buffer, right.preloaded.jsonPtr, right.preloaded.jsonLength);
        assert.equal(sourceA.byteLength, sourceB.byteLength);
        assert(Buffer.from(sourceA.buffer, sourceA.byteOffset, sourceA.byteLength).equals(Buffer.from(sourceB.buffer, sourceB.byteOffset, sourceB.byteLength)), 'Inflated source mismatch');
        sourceDigest.A.update(sourceA);
        sourceDigest.B.update(sourceB);
        for (let i = 0; i < left.chunks.length; ++i) {
            compareValue(normalizeChunk(left.chunks[i]), normalizeChunk(right.chunks[i]), 'group-' + index + '.chunk-' + i);
        }
        const count = left.chunks.reduce((sum, chunk) => sum + chunk.rowCount, 0);
        rows += count;
        const observation = {index, files: groups[index].map((entry) => entry.filename), order: order.join(''), rows: count, A: left.measurement, B: right.measurement};
        observations.push(observation);
        await appendFile(output + '.groups.jsonl', JSON.stringify(observation) + '\n');
        if ((index + 1) % 16 === 0 || index + 1 === groups.length) {
            process.stdout.write(JSON.stringify({groups: index + 1, totalGroups: groups.length, rows, elapsedSeconds: (performance.now() - beginning) / 1000, peakRssKiB: process.resourceUsage().maxRSS, ...summarize().equalCorpusCandidateChangePercent}) + '\n');
        }
    }
    if (!limit) { assert.equal(rows, fixture.termRows); }
    completed = true;
} catch (error) {
    failure = error.stack ?? String(error);
    process.stderr.write(failure + '\n');
    process.exitCode = 1;
} finally {
    for (const arm of ['A', 'B']) { assert.equal(sha(await readFile(loadedWasmPaths[arm])), identities[arm].wasmSha256, 'Native module changed during replay'); }
    const report = {completed, failure, scope, node: process.version, harnessSha256: sha(await readFile(new URL(import.meta.url))), initialOrder, identities, fixture, lockSha256: sha(lockBytes), totalBanks: allBanks.length, selectedBanks: banks.length, groupCount: groups.length, completedGroups: observations.length, rows, options, comparedByteCount, comparedLeafCount, sourceDigestSha256: {A: sourceDigest.A.digest('hex'), B: sourceDigest.B.digest('hex')}, outputDigestSha256: {A: outputDigest.A.digest('hex'), B: outputDigest.B.digest('hex')}, peakRssKiB: process.resourceUsage().maxRSS, overallElapsedSeconds: (performance.now() - beginning) / 1000, ...summarize(), observations};
    await writeFile(output, JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
    process.stdout.write('SUMMARY ' + JSON.stringify({...report, observations: undefined, identities: undefined}) + '\n');
}
