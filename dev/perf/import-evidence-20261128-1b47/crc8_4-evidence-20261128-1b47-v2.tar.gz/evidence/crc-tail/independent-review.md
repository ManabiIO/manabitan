# Independent review: 8 + 4 byte source-CRC tails

## Recommendation

**Keep the existing browser trial; wait for its fixed results before opening a performance PR.** The change is small and proportionate to the demonstrated CRC-stage work reduction. It is stronger than a purely synthetic optimization, but the current evidence does not establish a complete-import gain, and the more direct production-verifier diagnostic is less decisive than the isolated gap benchmark.

If the unchanged qualification protocol demonstrates a useful VNDB complete-import improvement beyond its identical-code variation, with the original correctness and other-corpus gates passing, this is a reasonable focused PR. If that cohort is flat or inconclusive, retain the result as a withheld component candidate. There is no justification to combine it with the rejected wider-table or padding variants to strengthen a claim.

This review reads existing source, tests, reports and hosted metadata. It runs no benchmarks or tests and changes no product source.

## Exact candidate and source review

Frozen baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
Local runtime checkpoint: `565ea5d2e712b44bd6a33db65f5a8d3d34d8db6a`.
Production parser WASM: SHA-256 `b362d9b0106c28e9cb495d66c650463c771e165cb8ebadc4a66adda973466fd9`, 67,943 bytes.

The runtime adds 25 lines to `crc32_update_gap`, using the existing slicing tables for an optional eight-byte remainder and optional four-byte remainder after the existing sixteen-byte loop. The remaining scalar tail shrinks from at most fifteen bytes to at most three. All source bytes still contribute to the same complemented IEEE CRC; this reduces dependency length rather than weakening the checksum.

The new reads are guarded by `length - offset >= 8` and `>= 4`. The existing loop preserves `offset <= length`, and the existing little-endian reader performs bounded byte reads, so unaligned data is supported without an alignment cast. No allocation, larger table, cache, worker, source grouping, admission threshold, witness policy, stored format or error ordering changes. The test-only export is under the existing `TERM_BANK_CRC_TEST` macro.

The retained WASM structure report confirms that **only function 5, `crc32_update_gap`, changes**: 538→822 body bytes. All other 50 production function bodies match exactly, including whole-bank CRC, inflation, the verifier, parser and encoders. The complete module grows by 284 bytes; the export surface and initial memory remain the same. These facts make the maintenance and allocation cost modest, but cannot by themselves prove browser speed.

The current published trial is `perf/vndb-crc-screen-20261127-1b47`, head `3080deb631a7536fabe8ccb2f77f8f55e11ef061`. Its sole change from initial trial head `9836d4d62a20bf886bfdb03f7392aaed307e716e` is line wrapping in the test's length list. Runtime bytes remain frozen. The local worktree has subsequently moved to the rejected slicing32 commit; reports explicitly bind the eight-plus-four checkpoint and loaded WASM hash, which I independently reconciled against Git.

## Meaningful correctness coverage

The added test compares against independent Node zlib CRC for **8,160 combinations**: 170 lengths, sixteen alignments and three preceding CRC states (zero, all ones and a deterministic random state). It covers every short tail, zero length, boundaries around 256/512/1024 and tails near 64 KiB. It exercises incremental arbitrary-state CRC, not only a checksum starting at zero.

Existing tests preserve whole-bank vectors, corrupted DEFLATE-bank CRC rejection, exact raw-glossary witness semantics, canonical-equal but raw-distinct content, wrong CRCs before row delivery, fallback/error precedence and sticky verifier failures. Both complete local eight-plus-four parser cohorts match all 6,648,310 VNDB rows and complete compared parser outputs against baseline. These are parser/component byte oracles; they do not replace persisted browser, restart or media checks.

Initial hosted trial run `46104536301` reproduced the pinned native module and passed **15,136 tests across 669 files**, with 47 skipped, plus the all-target build. It then failed the new test's array-linebreak lint rule. That failure remains in `../hosted-crc8_4-initial-validation-failed.log`; it is not relabeled as a passing run. The follow-up changes formatting only. Current run `46107723369` was queued at review time, so current-head validation and browser qualification are still pending.

## What the measurements support

| Evidence | Observation | Limit |
| --- | --- | --- |
| Synthetic gap screen | Eight-plus-four improves several tested gap-size distributions | Mechanism exploration only; does not establish corpus or browser speed. |
| Captured raw-gap microbenchmark | 120,012 actual gaps from the first 12 VNDB banks; paired change −21.21%; medians 103.97→82.49 ms for sixteen repeats | Gaps are concatenated into a continuous CRC state and omit glossary combination, parser/cache behavior and storage. This is a selected 120,000-row sample, not the full verifier. |
| First complete sequential parser cohort | CRC sum 716.61→654.60 ms (**−8.65%, 62.01 ms**); 257/332 groups faster | Whole component improves 300.74 ms, much more than the CRC decrease. Unchanged inflation also improves 3.35%. |
| Reversed complete sequential parser cohort | CRC sum 731.06→681.19 ms (**−6.82%, 49.87 ms**); 241/332 groups faster | Whole component improves 189.92 ms; unchanged inflation improves 13.35%. This prevents attributing the complete component difference to the changed CRC function. |
| Order-balanced view of both full-source cohorts | CRC equal work −7.73%; source-group paired median −9.58%; 258/332 groups faster after balancing each group in both positions | Descriptive component evidence. AB and BA CRC totals still differ: −12.60% versus −2.52%. Summing two process runs does not create independent complete-import observations. |
| Direct production verifier, selected three groups | 24 fixed blocks; paired median −6.47%, geometric −3.19%, equal work −2.42%; 16/24 blocks faster | Geometric descriptive interval **[−7.38%, +1.74%]** crosses zero. Only three deliberately selected two/three-bank groups are replayed. |
| Same diagnostic, unchanged whole-bank route | Equal work **+3.89%**, paired median +4.32%, 2/8 blocks faster | These executed production function bodies are unchanged. The variation must remain visible; it cannot be subtracted from the witness result or dismissed as a proven cause. |

The complete parser cohorts use **332 sequential two-bank groups, with the final three banks together**. The production census uses **170 groups and three workers**. That changes exact-content reuse and the verifier's byte mix:

| Work | Local complete-parser cohorts | Existing production-group census |
| --- | ---: | ---: |
| CRC source bytes scanned | 872,007,039 | 568,284,368 |
| CRC source bytes reused | 3,395,985,928 | 3,699,708,599 |
| Total original term-bank bytes | 4,267,992,967 | 4,267,992,967 |

The local grouping scans about 53% more bytes. Its CRC percentages must not be applied to the production worker-duration sum or complete-browser clock. The source and output hashes match within each comparison, but equality does not make the scheduling/grouping representative.

No quoted component elapsed change is a whole-import gain. `parseBankMs` includes CRC time, so those phase counters must not be added. The component process-CPU reductions also include unchanged work. The reversed cohort strengthens the direction of the CRC-stage finding, while its inflation drift and the weaker direct verifier prevent a precise general latency claim.

Wider slicing32 was rejected after the complete parser CRC phase regressed 23.56% and the direct verifier regressed 6.55% equal work. A padded-table follow-up remained inconclusive in the combined fixed cohort. Neither result belongs to the eight-plus-four candidate, and the earlier roughly 29% combined microbenchmark figure must not be attributed to eight-plus-four alone.

## Prior overlap

[#817](https://github.com/ManabiIO/manabitan/pull/817) changes wide arithmetic in the **whole-bank eight-lane braid**, retaining its 256 KiB threshold and scalar tail. It is closed with a held complete-import result. This candidate changes the separate incremental row-gap helper and leaves that whole-bank function byte-identical. It is not a repeat of #817's mechanism or evidence.

[#910](https://github.com/ManabiIO/manabitan/pull/910) changes the **verifier's run construction and eligibility**: it keeps unused source spans contiguous, flattens witness chains, introduces incremental braided CRC and broadens admission beyond the compression-ratio gate. That draft has inconclusive complete-import results and incomplete VNDB memory qualification. Eight-plus-four changes none of those decisions and creates no new witness allocation. The changes are conceptually different, although a future #910 integration would need to preserve whichever small-tail helper it actually calls and receive fresh composed qualification.

## Remaining decision gates

The queued frozen browser study must finish its original all-three-dictionary complete-import comparisons, identical-product controls, source/package/fixture binding, full storage/media/restart checks and separate memory checks. The observed gain should be attributable to the complete VNDB import under its real grouping and concurrency, while JMdict and Jitendex remain within the registered regression policy. If a strong general speed claim is intended, it needs independent corroboration rather than promotion of one favorable component subset.

No additional local timing or broad test sweep is needed for this review. The current small runtime and independent correctness evidence justify the existing trial; they do not justify declaring its pending result passed.
