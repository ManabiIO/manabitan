import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {crc32} from 'node:zlib';

const data = await readFile(new URL('corpus-gaps.bin', import.meta.url));
const spanBytes = await readFile(new URL('corpus-spans.bin', import.meta.url));
const spans = new Uint32Array(spanBytes.buffer.slice(spanBytes.byteOffset, spanBytes.byteOffset + spanBytes.byteLength));
const census = JSON.parse(await readFile(new URL('corpus-census.json', import.meta.url), 'utf8'));
const variants = ['baseline', 'tail8', 'tail4', 'tail8_4'];
const probes = {};
for (const name of variants) {
    const module = await WebAssembly.compile(await readFile(new URL(`${name}.wasm`, import.meta.url)));
    const {exports: wasm} = await WebAssembly.instantiate(module);
    const pointer = wasm.probe_heap();
    const spansPointer = Math.ceil((pointer + data.length) / 4) * 4;
    const required = spansPointer + spanBytes.length;
    wasm.memory.grow(Math.max(0, Math.ceil(required / 65536) - wasm.memory.buffer.byteLength / 65536));
    new Uint8Array(wasm.memory.buffer, pointer, data.length).set(data);
    new Uint32Array(wasm.memory.buffer, spansPointer, spans.length).set(spans);
    probes[name] = {wasm, pointer, spansPointer};
    assert.equal(wasm.probe_batch(pointer, spansPointer, spans.length / 2, 1) >>> 0, crc32(data));
}
const repeats = 16;
let expected = 0;
for (let i = 0; i < repeats; ++i) expected = crc32(data, expected);
const observations = [];
const run = (arm) => {
    const {wasm, pointer, spansPointer} = probes[arm];
    const start = performance.now();
    const value = wasm.probe_batch(pointer, spansPointer, spans.length / 2, repeats) >>> 0;
    const durationMs = performance.now() - start;
    assert.equal(value, expected);
    return durationMs;
};
for (let warmup = 0; warmup < 4; ++warmup) for (const arm of variants) run(arm);
for (let block = 0; block < 24; ++block) {
    for (const arm of block % 2 ? [...variants].reverse() : variants) observations.push({block, arm, durationMs: run(arm)});
}
const median = (values) => {
    const sorted = [...values].sort((a, b) => a - b);
    return (sorted[Math.floor((sorted.length - 1) / 2)] + sorted[Math.floor(sorted.length / 2)]) / 2;
};
const medians = Object.fromEntries(variants.map((arm) => [arm, median(observations.filter((x) => x.arm === arm).map((x) => x.durationMs))]));
const pairedChangesPct = Object.fromEntries(variants.slice(1).map((arm) => [arm, median(Array.from({length: 24}, (_, block) => 100 * (observations.find((x) => x.block === block && x.arm === arm).durationMs / observations.find((x) => x.block === block && x.arm === 'baseline').durationMs - 1)))]));
const report = {scope: 'CRC-only component replay using actual source-verifier gap bytes; excludes glossary CRC combination, parsing, storage and browser import. Sample ordering/CRC state is a continuous concatenation of captured gaps.', runtime: process.version, census: {...census, lengths: undefined, groupStats: undefined}, repeats, spans: spans.length / 2, bytesPerObservation: data.length * repeats, expected, medians, pairedChangesPct, observations};
await writeFile(new URL('corpus-screen.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({...report, observations: undefined}));
