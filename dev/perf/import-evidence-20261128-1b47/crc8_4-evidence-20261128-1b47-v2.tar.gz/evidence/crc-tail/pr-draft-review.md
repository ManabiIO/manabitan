# Independent review of the CRC PR draft

Read-only review of `evidence/crc8_4-pr-draft.md` on 2026-11-28. No benchmark,
test, source edit, GitHub comment or publication was performed.

The draft's runtime size, WASM growth, 8,160-case independent oracle, complete
VNDB row counts, measured component scopes, weaker direct-verifier interval,
332-versus-170 grouping distinction, retained negative variants and acquisition
script limitation reconcile with the source and raw evidence. Current hosted
validation is successful; browser qualification remains queued. A clean product
diff containing only C, generated native manifest/WASM and the current test is
consistent with the reviewed candidate.

Three small wording corrections were recommended:

1. Use “exact raw spans covered by CRC witnesses” instead of “reused canonical
   spans.” Semantic canonical equality alone does not prove raw-byte CRC reuse.
2. Label the unchanged whole-bank control's +3.89% as an **equal-work time**
   change; the candidate statistic in that table row is geometric.
3. Describe the second complete corpus run as “reverse initial order,” avoiding
   wording that might imply a different host or independent whole-import trial.

These are precision corrections. No additional substantive claim or source
correctness issue was found. The review does not promote the pending complete
browser/regression/correctness observations to passed results.
