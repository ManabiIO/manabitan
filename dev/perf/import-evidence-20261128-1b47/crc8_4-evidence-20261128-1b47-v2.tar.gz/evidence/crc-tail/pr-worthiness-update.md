# CRC tail candidate: review scope and publication judgment

This updates the publication recommendation in `independent-review.md`; it
does not change any observation, candidate, qualification gate or measurement
scope. No new timing or tests were performed.

Under the user's request for “some kind of gain worth reviewing,” this is a
reasonable **component-scoped draft for review** once the source/evidence is
durable. The earlier recommendation to wait for a complete-import win was a
conservative threshold for an import-speed claim, not a condition imposed by
the user. Opening a review does not turn queued validation into a pass or
qualify the candidate for merging.

## Why the change is proportionate

The production change adds 25 C lines to the incremental source-gap CRC helper.
It reuses existing tables to consume an optional eight-byte and four-byte tail,
leaving at most three dependent scalar bytes. It adds no allocation or table,
changes no witness/admission/grouping policy, and leaves all other production
function bodies identical. The complete WASM grows 284 bytes. Independent
Node-zlib checks cover 8,160 length/alignment/preceding-state combinations, and
complete VNDB parser outputs match for all 6,648,310 rows.

There is a useful measured mechanism, with important limits:

- The exploratory 24-block replay of **120,012 captured source-gap spans** from
  the first 12 VNDB banks improves the CRC-only paired result by **21.21%**;
  sixteen repeats take medians 103.97 → 82.49 ms. It concatenates gaps into a
  continuous CRC state and excludes the real verifier's combination work.
  Several tail variants were explored; this is not a fresh confirmatory
  whole-import cohort.
- Two complete sequential parser runs in opposite orders reduce the summed
  CRC phase by **62.01 ms (8.65%)** and **49.87 ms (6.82%)**. That supports a
  corpus-level CRC-stage signal. Unchanged inflation also drifts by 3.35% and
  13.35%, so the larger whole-component changes are not attributable to CRC.
- The more direct selected production-verifier diagnostic is weaker:
  geometric change **−3.19%**, descriptive interval **[−7.38%, +1.74%]**.
  The unchanged whole-bank route moves **+3.89%**. This must be disclosed;
  there is no decisive general verifier-latency estimate.
- Local full-parser grouping scans 872 MB in 332 groups; the production census
  scans 568 MB in 170 groups with three workers. Applying the local percentage
  to browser import time or production worker sums would be invalid.

## Current validation and remaining risk

The initial hosted source passed 669 unit files / 15,136 tests (47 skips), pinned
native reproduction and all-target build, then failed a test-only line-wrap
lint rule. The current head `3080deb631a7536fabe8ccb2f77f8f55e11ef061` changes
only that formatting and retains runtime WASM hash
`b362d9b0106c28e9cb495d66c650463c771e165cb8ebadc4a66adda973466fd9`.
Current run **46107723369**, validation job **140864123481**, is still queued at
this review. Full current-head validation and all three complete-browser
comparison/memory/storage/media/restart gates remain pending.

A draft should therefore say “reduce short-gap CRC work,” present the measured
component scopes above, and explicitly withhold a whole-import speedup claim.
It should not claim the current-head gate passed, quote the rejected slicing32
variant's roughly 29% micro result, or treat #910's broader witness changes as
part of this candidate. #817 changes the separate whole-bank braid; #910 changes
verifier construction and eligibility, so neither is a duplicate of this helper.

I would keep the draft unmerged pending current-head correctness validation and
the already registered browser regression/correctness observations. If those
show a reproducible regression, withdraw the candidate. If the browser result
is flat, this remains a modest component optimization whose review value rests
on the small maintenance cost and demonstrated CRC work improvement; a flat
result must remain visible and does not become an import-speed claim.
