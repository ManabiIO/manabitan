/* SPDX-License-Identifier: GPL-3.0-or-later */
// Five-arm bounded production CRC-verifier diagnostic. No parse/import claim.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile, appendFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import os from 'node:os';

const [inputPath, outputPath, baselinePath, nativePath, cohort = 'five-arm'] = process.argv.slice(2);
assert(inputPath && outputPath && baselinePath && nativePath);
assert(cohort === 'five-arm' || cohort === 'tail-padding-opposite');
const inputsRoot = resolve(inputPath);
const output = resolve(outputPath);
const baselineRoot = resolve(baselinePath);
const nativeRoot = resolve(nativePath);
const evidenceRoot = fileURLToPath(new URL('.', import.meta.url));
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const inputManifestBytes = await readFile(join(inputsRoot, 'manifest.json'));
const inputManifest = JSON.parse(inputManifestBytes);
assert.equal(inputManifest.sourceCommit, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
const paddedManifestBytes = await readFile(join(evidenceRoot, 'padded-verifier/build-manifest.json'));
const paddedManifest = JSON.parse(paddedManifestBytes);
const oracleBytes = await readFile(join(evidenceRoot, 'padded-verifier/oracle-results.json'));
const snapshots = [];
for (const group of inputManifest.groups) {
    const values = {};
    for (const [name, record] of Object.entries(group.records)) {
        const bytes = await readFile(join(inputsRoot, group.name, record.filename));
        assert.equal(bytes.byteLength, record.bytes);
        assert.equal(sha(bytes), record.sha256);
        values[name] = bytes;
    }
    snapshots.push({...group, values});
}
const wasmRelativePath = 'dev/data/dictionary-wasm/term-bank-parser.wasm';
const nativeSourcePath = 'ext/js/dictionary/wasm/term-bank-parser.c';
const committed = (root, commit, path) => execFileSync('git', ['show', commit + ':' + path], {cwd: root, maxBuffer: 4 * 1024 * 1024});
const arms = [];
for (const spec of [
    {name: 'baseline', root: baselineRoot, commit: '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2', wasmPath: join(baselineRoot, wasmRelativePath)},
    {name: 'tail8_4', root: nativeRoot, commit: '565ea5d2e712b44bd6a33db65f5a8d3d34d8db6a', wasmPath: join(evidenceRoot, 'checkpoint8_4/term-bank-parser.wasm')},
    {name: 'slicing32', root: nativeRoot, commit: '92815fb8a5df090db95025c1b2d26e2677dc1d5a', wasmPath: join(nativeRoot, wasmRelativePath)},
]) {
    const bytes = await readFile(spec.wasmPath);
    assert.deepEqual(bytes, committed(spec.root, spec.commit, wasmRelativePath));
    const manifest = JSON.parse(committed(spec.root, spec.commit, 'dev/data/dictionary-wasm/manifest.json'));
    assert.equal(manifest.targets.find(({name}) => name === 'term-bank-parser.wasm').sha256, sha(bytes));
    arms.push({name: spec.name, bytes, identity: {...spec, wasmSha256: sha(bytes), wasmBytes: bytes.byteLength, nativeSourceSha256: sha(committed(spec.root, spec.commit, nativeSourcePath)), manifest}});
}
for (const variant of paddedManifest.variants) {
    const production = variant.builds.production;
    const bytes = await readFile(production.wasmPath);
    assert.equal(sha(bytes), production.wasmSha256);
    assert.equal(bytes.byteLength, production.wasmBytes);
    assert.equal(sha(await readFile(variant.sourcePath)), variant.sourceSha256);
    assert.equal(sha(committed(nativeRoot, variant.parentCommit, nativeSourcePath)), variant.originalSourceSha256);
    arms.push({name: variant.name, bytes, identity: {...variant, wasmPath: production.wasmPath, wasmSha256: production.wasmSha256, wasmBytes: production.wasmBytes, compiler: paddedManifest.compiler, linker: paddedManifest.linker, inflateSourceSha256: paddedManifest.inflateSourceSha256, buildManifestSha256: sha(paddedManifestBytes)}});
}
assert.deepEqual(arms.map(({name}) => name), ['baseline', 'tail8_4', 'slicing32', 'tail8_4_padded272', 'slicing32_padded272']);
const allArmNames = arms.map(({name}) => name);
if (cohort === 'tail-padding-opposite') {
    arms.splice(0, arms.length, ...arms.filter(({name}) => name === 'tail8_4' || name === 'tail8_4_padded272'));
}
let exportsIdentity = null;
for (const arm of arms) {
    const module = await WebAssembly.compile(arm.bytes);
    assert.deepEqual(WebAssembly.Module.imports(module), []);
    const exports = WebAssembly.Module.exports(module);
    if (exportsIdentity === null) { exportsIdentity = exports; }
    else { assert.deepEqual(exports, exportsIdentity, 'All arms must retain exact production export surface'); }
    const instance = await WebAssembly.instantiate(module, {});
    arm.wasm = instance.exports;
    arm.wasm.wasm_reset_heap();
    arm.frames = [];
    for (const snapshot of snapshots) {
        const pointers = {};
        for (const name of ['json', 'spans', 'signatures', 'metadata', 'witnesses', 'stats']) {
            const size = snapshot.values['input.' + name].byteLength;
            pointers[name] = arm.wasm.wasm_alloc(size);
            assert(pointers[name] > 0);
        }
        arm.frames.push({snapshot, pointers});
    }
    for (const frame of arm.frames) {
        const {snapshot, pointers} = frame;
        frame.views = {};
        for (const [name, pointer] of Object.entries(pointers)) {
            const bytes = snapshot.values['input.' + name];
            const view = new Uint8Array(arm.wasm.memory.buffer, pointer, bytes.byteLength);
            view.set(bytes);
            frame.views[name] = view;
        }
        frame.witnessBytes = Buffer.from(frame.views.witnesses.buffer, frame.views.witnesses.byteOffset, frame.views.witnesses.byteLength);
        frame.statsBytes = Buffer.from(frame.views.stats.buffer, frame.views.stats.byteOffset, frame.views.stats.byteLength);
        frame.witnessArgs = [pointers.json, snapshot.jsonLength, pointers.spans, snapshot.bankCount, pointers.signatures, pointers.metadata, snapshot.rowCount, pointers.witnesses, pointers.stats];
        frame.wholeBankArgs = [pointers.json, snapshot.jsonLength, pointers.spans, snapshot.bankCount, pointers.signatures, 0, 0, 0, pointers.stats];
        frame.wholeBankStats = Buffer.alloc(12);
        frame.wholeBankStats.writeUInt32LE(snapshot.jsonLength, 0);
    }
    arm.identity.allocatedMemoryBytes = arm.wasm.memory.buffer.byteLength;
    arm.identity.frames = arm.frames.map(({snapshot, pointers}) => ({name: snapshot.name, pointers}));
}

// Each pair is an order plus its reverse, so every arm precedes every other
// arm in exactly half of the blocks. Source-group positions also rotate.
function orderForBlock(index) {
    const rotation = Math.floor(index / 2) % allArmNames.length;
    const names = Array.from({length: allArmNames.length}, (_, position) => allArmNames[(rotation + position) % allArmNames.length]);
    if (index % 2) { names.reverse(); }
    if (cohort === 'tail-padding-opposite') { names.reverse(); }
    return names.map((name) => arms.findIndex((arm) => arm.name === name)).filter((index) => index >= 0);
}

function invoke(arm, frame, mode, timed) {
    frame.views.witnesses.set(frame.snapshot.values['input.witnesses']);
    frame.views.stats.set(frame.snapshot.values['input.stats']);
    const args = mode === 'witnesses' ? frame.witnessArgs : frame.wholeBankArgs;
    const started = timed ? performance.now() : 0;
    const result = arm.wasm.verify_term_bank_source_crcs(...args);
    const elapsedMs = timed ? performance.now() - started : 0;
    assert.equal(result, 0, `${arm.name}/${frame.snapshot.name}/${mode}: ZIP CRC result`);
    assert(frame.statsBytes.equals(mode === 'witnesses' ? frame.snapshot.values['output.stats'] : frame.wholeBankStats), 'Every verifier call must reproduce complete expected stats');
    assert(frame.witnessBytes.equals(mode === 'witnesses' ? frame.snapshot.values['output.witnesses'] : frame.snapshot.values['input.witnesses']), 'Every verifier call must reproduce all witness CRCs (or leave them unchanged in whole-bank mode)');
    return elapsedMs;
}

function median(values) {
    const sorted = [...values].sort((a, b) => a - b);
    return (sorted[Math.floor((sorted.length - 1) / 2)] + sorted[Math.floor(sorted.length / 2)]) / 2;
}

function summarize(observations, blocks) {
    const perArm = {};
    for (const arm of arms) {
        const selected = observations.filter((observation) => observation.arm === arm.name);
        perArm[arm.name] = {
            totalMs: selected.reduce((sum, observation) => sum + observation.totalMs, 0),
            calls: selected.reduce((sum, observation) => sum + observation.samplesMs.length, 0),
            perGroup: Object.fromEntries(snapshots.map(({name}) => {
                const rows = selected.filter((observation) => observation.group === name);
                const samples = rows.flatMap((observation) => observation.samplesMs);
                return [name, {totalMs: rows.reduce((sum, observation) => sum + observation.totalMs, 0), medianCallMs: median(samples), calls: samples.length}];
            })),
        };
    }
    const comparisons = {};
    for (const [left, right] of [
        ...arms.filter(({name}) => name !== 'baseline').map(({name}) => ['baseline', name]),
        ['tail8_4', 'slicing32'],
        ['tail8_4', 'tail8_4_padded272'],
        ['slicing32', 'slicing32_padded272'],
    ].filter(([left, right]) => perArm[left] && perArm[right])) {
        const ratios = Array.from({length: blocks}, (_, block) => {
            const totals = Object.fromEntries([left, right].map((arm) => [arm, observations.filter((observation) => observation.block === block && observation.arm === arm).reduce((sum, observation) => sum + observation.totalMs, 0)]));
            return totals[right] / totals[left];
        });
        comparisons[`${right}_vs_${left}`] = {
            aggregateChangePercent: 100 * (perArm[right].totalMs / perArm[left].totalMs - 1),
            pairedMedianBlockChangePercent: 100 * (median(ratios) - 1),
            pairedGeometricBlockChangePercent: 100 * (Math.exp(ratios.reduce((sum, ratio) => sum + Math.log(ratio), 0) / ratios.length) - 1),
            fasterBlocks: ratios.filter((ratio) => ratio < 1).length,
            blocks: ratios.length,
            perBlockRatios: ratios,
        };
    }
    return {perArm, comparisons};
}

const plan = {
    witnesses: {blocks: 24, callsPerGroupPerArmPerBlock: 32, warmupCallsPerGroupPerArm: 32},
    ...(cohort === 'five-arm' ? {wholeBankControl: {blocks: 8, callsPerGroupPerArmPerBlock: 4, warmupCallsPerGroupPerArm: 4}} : {}),
};
const reports = {};
const startedAt = new Date().toISOString();
const beginning = performance.now();
let completed = false;
let failure = null;
await writeFile(output + '.observations.jsonl', '', {flag: 'wx'});
try {
    for (const [mode, configuration] of Object.entries(plan)) {
        for (const armIndex of orderForBlock(0)) {
            const arm = arms[armIndex];
            for (const frame of arm.frames) {
                for (let call = 0; call < configuration.warmupCallsPerGroupPerArm; ++call) { invoke(arm, frame, mode, false); }
            }
        }
        const observations = [];
        reports[mode] = {configuration, observations};
        for (let block = 0; block < configuration.blocks; ++block) {
            const order = orderForBlock(block);
            const groupOrder = Array.from({length: snapshots.length}, (_, index) => (block + index) % snapshots.length);
            for (const groupIndex of groupOrder) {
                for (const armIndex of order) {
                    const arm = arms[armIndex];
                    const frame = arm.frames[groupIndex];
                    const samplesMs = [];
                    for (let call = 0; call < configuration.callsPerGroupPerArmPerBlock; ++call) { samplesMs.push(invoke(arm, frame, mode, true)); }
                    const observation = {mode, block, order: order.map((index) => arms[index].name), groupOrder: groupOrder.map((index) => snapshots[index].name), arm: arm.name, group: frame.snapshot.name, samplesMs, totalMs: samplesMs.reduce((sum, value) => sum + value, 0)};
                    observations.push(observation);
                    await appendFile(output + '.observations.jsonl', JSON.stringify(observation) + '\n');
                }
            }
            process.stdout.write(JSON.stringify({mode, completedBlocks: block + 1, totalBlocks: configuration.blocks, elapsedSeconds: (performance.now() - beginning) / 1000}) + '\n');
        }
        Object.assign(reports[mode], summarize(observations, configuration.blocks));
    }
    completed = true;
} catch (error) {
    failure = error.stack ?? String(error);
    process.stderr.write(failure + '\n');
    process.exitCode = 1;
} finally {
    for (const arm of arms) {
        assert.equal(sha(await readFile(arm.identity.wasmPath)), arm.identity.wasmSha256, 'WASM changed during verifier replay');
        for (const frame of arm.frames) {
            for (const name of ['json', 'spans', 'signatures', 'metadata']) {
                assert.equal(sha(frame.views[name]), frame.snapshot.records['input.' + name].sha256, `Immutable ${name} input changed`);
            }
        }
    }
    const result = {
        completed, failure, cohort, startedAt, completedAt: new Date().toISOString(),
        scope: 'Bounded direct production-export CRC verifier diagnostic on three exact baseline source groups. Reuses parser-produced raw witness IDs, full17u32 metadata, bank boundaries and ZIP signatures; resets witnesses/stats outside every timer and compares complete outputs after every call. No parser, database, storage, browser or whole-import speed claim. Snapshots are a deliberately selected diagnostic sample, not a full-corpus performance estimate.',
        timer: 'performance.now immediately around verify_term_bank_source_crcs; excludes witness/stat reset, output verification, logging and input allocation',
        method: cohort === 'five-arm' ? 'Fixed24-block primary plan and8-block whole-bank control. Each adjacent block pair reverses all arm ordering; source-group order rotates. All samples and observations retained. No import flags or test-only WASM exports.' : 'Independent two-arm process run: same captured inputs and24×32 primary plan, with8+4/padded8+4 relative arm order reversed in every block against the retained first five-arm cohort. Source order matches. No whole-bank control repeated. All observations retained.',
        node: process.version, v8: process.versions.v8, cpuModel: os.cpus()[0]?.model, logicalCpuCount: os.cpus().length,
        inputManifestSha256: sha(inputManifestBytes), inputManifest,
        paddedBuildManifestSha256: sha(paddedManifestBytes), paddedOracleResultsSha256: sha(oracleBytes),
        scriptSha256: sha(await readFile(new URL(import.meta.url))),
        armIdentities: Object.fromEntries(arms.map((arm) => [arm.name, arm.identity])),
        exportsIdentity, plan, reports, peakRssKiB: process.resourceUsage().maxRSS,
        elapsedSeconds: (performance.now() - beginning) / 1000,
    };
    await writeFile(output, JSON.stringify(result, null, 2) + '\n', {flag: 'wx'});
    process.stdout.write('SUMMARY ' + JSON.stringify({completed, failure, peakRssKiB: result.peakRssKiB, elapsedSeconds: result.elapsedSeconds, reports: Object.fromEntries(Object.entries(reports).map(([mode, report]) => [mode, {configuration: report.configuration, comparisons: report.comparisons}]))}) + '\n');
}
