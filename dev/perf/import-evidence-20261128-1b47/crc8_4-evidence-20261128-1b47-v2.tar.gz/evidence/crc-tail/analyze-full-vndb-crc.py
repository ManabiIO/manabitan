#!/usr/bin/env python3
"""Summarize complete retained native-parser component cohorts; no import claim."""
import hashlib
import json
import pathlib
import statistics

ROOT = pathlib.Path(__file__).resolve().parent
NAMES = ["slicing32", "tail8_4", "tail8_4-reversed"]
PHASES = ["elapsedMs", "inflateMs", "parseWallMs", "crcMs", "cpuTotalMs"]
documents = {}


def summarize(rows):
    phases = {}
    for key in PHASES:
        a = sum(row["A"][key] for row in rows)
        b = sum(row["B"][key] for row in rows)
        phases[key] = {"A": a, "B": b, "candidateChangePercent": 100 * (b / a - 1)}
    return {"groupObservations": len(rows), "phases": phases}


cohorts = {}
for name in NAMES:
    path = ROOT / f"full-vndb-parser-{name}.json"
    raw = path.read_bytes()
    data = json.loads(raw)
    assert data["completed"] and data["failure"] is None
    assert data["rows"] == 6648310 and data["completedGroups"] == 332
    assert data["sourceDigestSha256"]["A"] == data["sourceDigestSha256"]["B"]
    assert data["outputDigestSha256"]["A"] == data["outputDigestSha256"]["B"]
    documents[name] = data
    observations = data["observations"]
    cohorts[name] = {
        "path": str(path),
        "reportSha256": hashlib.sha256(raw).hexdigest(),
        "initialOrder": data.get("initialOrder", "AB"),
        "identities": data["identities"],
        **{key: data[key] for key in [
            "completed", "rows", "comparedByteCount", "comparedLeafCount",
            "sourceDigestSha256", "outputDigestSha256", "peakRssKiB",
            "equalCorpusCandidateChangePercent", "medianGroupCrcChangePercent",
            "fasterCrcGroups", "comparableCrcGroups",
        ]},
        "all": summarize(observations),
        "AB": summarize([row for row in observations if row["order"] == "AB"]),
        "BA": summarize([row for row in observations if row["order"] == "BA"]),
    }

first = documents["tail8_4"]
second = documents["tail8_4-reversed"]
assert first["sourceDigestSha256"] == second["sourceDigestSha256"]
assert first["outputDigestSha256"] == second["outputDigestSha256"]
per_group_ratios = []
for left, right in zip(first["observations"], second["observations"], strict=True):
    assert left["index"] == right["index"] and left["files"] == right["files"]
    assert left["rows"] == right["rows"] and left["order"] != right["order"]
    a = left["A"]["crcMs"] + right["A"]["crcMs"]
    b = left["B"]["crcMs"] + right["B"]["crcMs"]
    per_group_ratios.append(b / a)
combined_rows = first["observations"] + second["observations"]
combined = {
    "all": summarize(combined_rows),
    "AB": summarize([row for row in combined_rows if row["order"] == "AB"]),
    "BA": summarize([row for row in combined_rows if row["order"] == "BA"]),
    "medianOrderBalancedSourceGroupCrcChangePercent": 100 * (statistics.median(per_group_ratios) - 1),
    "fasterOrderBalancedSourceGroups": sum(ratio < 1 for ratio in per_group_ratios),
    "sourceGroups": len(per_group_ratios),
}
report = {
    "scope": "Sequential full-corpus Node24 native-parser component comparisons only. All observations retained. Exact output comparison is outside timers. Local groups contain two banks (final three), unlike production's 170 groups; this alters source dedup and CRC scan/reuse counts. Neither total component deltas nor phase deltas estimate full-browser import gains.",
    "method": "Slicing32 and first8+4 cohorts start AB, then alternate per source group. The second8+4 cohort starts BA, balancing every identical source group in both positions across two complete process runs. One first-group warmup per arm precedes measured groups. JIT/tiering, cache order, and shared-host variation remain possible.",
    "rowsPerCohort": 6648310,
    "rawTermBankBytes": 4267992967,
    "localCrcScannedBytes": 872007039,
    "localCrcReusedBytes": 3395985928,
    "productionBaselineCensus": {"runId": 46102060382, "jobId": 140846486486, "groups": 170, "crcScannedBytes": 568284368, "crcReusedBytes": 3699708599},
    "cohorts": cohorts,
    "combinedTail8_4": combined,
}
destination = ROOT / "full-vndb-crc-comparison.json"
destination.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"report": str(destination), "combinedTail8_4": combined}, indent=2))
