import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream, openAsBlob} from 'node:fs';
import {readFile, writeFile} from 'node:fs/promises';
import {resolve, join} from 'node:path';
import {pathToFileURL} from 'node:url';

const [sourcePath, cachePath, bankLimitText = '12', sampleEveryText = '1'] = process.argv.slice(2);
assert(sourcePath && cachePath);
const root = resolve(sourcePath);
const bankLimit = Number(bankLimitText);
const sampleEvery = Number(sampleEveryText);
assert(Number.isInteger(bankLimit) && bankLimit >= 0);
assert(Number.isInteger(sampleEvery) && sampleEvery > 0);
const localImport = (file) => import(pathToFileURL(join(root, file)));
const parser = await localImport('ext/js/dictionary/term-bank-wasm-parser.js');
const {readDenseZipDirectory} = await localImport('ext/js/dictionary/dense-zip-directory.js');
const {RawZipPayloadReader} = await localImport('ext/js/dictionary/term-bank-source-pipeline.js');
const lock = JSON.parse(await readFile(join(root, 'test/perf/dictionaries.lock.json'), 'utf8'));
const fixture = lock.dictionaries.vndb;
const filename = join(cachePath, fixture.cacheFile);
const hash = createHash('sha256');
for await (const bytes of createReadStream(filename)) hash.update(bytes);
assert.equal(hash.digest('hex'), fixture.sha256);
const blob = await openAsBlob(filename);
assert.equal(blob.size, fixture.sizeBytes);
const entries = await readDenseZipDirectory(blob);
assert(entries);
const allBanks = entries.filter(({filename}) => /^term_bank_\d+\.json$/.test(filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)));
const banks = bankLimit > 0 ? allBanks.slice(0, bankLimit) : allBanks;
const reader = new RawZipPayloadReader(blob);
const signal = new AbortController().signal;
const wasmBytes = await readFile(join(root, 'ext/lib/term-bank-parser.wasm'));
parser.setTermBankWasmModule(await WebAssembly.compile(wasmBytes));
const options = {computeContentHashes: true, emitContentSlab: true, emitTokenBinaryContent: true, emitTermByteLists: false, useNativeStringPlan: true, singleChunk: true, validateGlossaryTypes: true, mediaHintFastScan: true, projectImagePaths: true};
let rows = 0;
let gapCount = 0;
let gapBytes = 0;
let sampledBytes = 0;
const gapSamples = [];
const lengths = new Map();
const remainders = new Array(16).fill(0);
const groupStats = [];
const capture = (bytes) => {
    if (gapCount % sampleEvery === 0) {
        gapSamples.push(bytes.slice());
        sampledBytes += bytes.byteLength;
    }
    ++gapCount;
    gapBytes += bytes.byteLength;
    remainders[bytes.byteLength % 16]++;
    lengths.set(bytes.byteLength, (lengths.get(bytes.byteLength) ?? 0) + 1);
};
for (let first = 0; first < banks.length; first += 2) {
    const sources = await Promise.all(banks.slice(first, first + 2).map(async (entry) => ({bytes: await reader.read(entry, signal), compressionMethod: entry.compressionMethod, compressedSize: entry.compressedSize, uncompressedSize: entry.uncompressedSize, signature: entry.signature, filename: entry.filename})));
    const preloaded = await parser.inflateCompressedTermBankSourcesWasm(sources, options, true);
    if (!preloaded.crcSignaturesPtr) {
        groupStats.push({files: sources.map((x) => x.filename), deferred: false});
        continue;
    }
    const wasm = preloaded.wasm;
    const originalVerify = wasm.verify_term_bank_source_crcs;
    let observed = 0;
    wasm.verify_term_bank_source_crcs = (...args) => {
        const [jsonPtr, jsonLength, spansPtr, bankCount, , metasPtr, rowCount] = args;
        assert(rowCount > 0, 'Expected raw glossary witness path');
        const source = new Uint8Array(wasm.memory.buffer, jsonPtr, jsonLength);
        const spans = new Uint32Array(wasm.memory.buffer, spansPtr, bankCount * 2);
        const meta = new Uint32Array(wasm.memory.buffer, metasPtr, rowCount * 17);
        let row = 0;
        for (let bank = 0; bank < bankCount; ++bank) {
            let cursor = spans[bank * 2];
            const end = cursor + spans[bank * 2 + 1];
            while (row < rowCount && meta[row * 17 + 9] < end) {
                const start = meta[row * 17 + 9];
                const length = meta[row * 17 + 10];
                assert(start >= cursor && start + length <= end);
                capture(source.subarray(cursor, start));
                cursor = start + length;
                ++row;
            }
            capture(source.subarray(cursor, end));
        }
        assert.equal(row, rowCount);
        observed += rowCount;
        return originalVerify(...args);
    };
    try {
        let parsedRows = 0;
        await parser.parseTermBankWithWasmColumnChunks(new Uint8Array(), 3, (chunk) => { parsedRows += chunk.rowCount; }, 2048, {...options, preloadedSource: preloaded});
        assert.equal(parsedRows, observed);
        assert.equal(preloaded.crcVerified, true);
        rows += parsedRows;
        groupStats.push({files: sources.map((x) => x.filename), deferred: true, rows: parsedRows, scanned: preloaded.crcScannedBytes, reused: preloaded.crcReusedBytes, sourceCrcMs: preloaded.crcMs});
    } finally {
        wasm.verify_term_bank_source_crcs = originalVerify;
    }
}
const packed = new Uint8Array(sampledBytes);
const spans = new Uint32Array(gapSamples.length * 2);
let offset = 0;
for (let i = 0; i < gapSamples.length; ++i) {
    const value = gapSamples[i];
    spans[i * 2] = offset;
    spans[i * 2 + 1] = value.length;
    packed.set(value, offset);
    offset += value.length;
}
assert.equal(offset, sampledBytes);
const summary = {scope: 'Observed byte gaps passed to the unchanged production VNDB source-CRC verifier; two-bank groups, sequential component replay', source: '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2', dictionarySha256: fixture.sha256, wasmSha256: createHash('sha256').update(wasmBytes).digest('hex'), runtime: process.version, selectedBanks: banks.length, totalBanks: allBanks.length, rows, gapCount, gapBytes, sampleEvery, sampledCount: gapSamples.length, sampledBytes, remainders, lengths: Object.fromEntries([...lengths].sort((a, b) => a[0] - b[0])), groupStats};
await writeFile(new URL('corpus-gaps.bin', import.meta.url), packed);
await writeFile(new URL('corpus-spans.bin', import.meta.url), new Uint8Array(spans.buffer));
await writeFile(new URL('corpus-census.json', import.meta.url), JSON.stringify(summary, null, 2) + '\n');
console.log(JSON.stringify({...summary, lengths: undefined, groupStats: undefined}));
