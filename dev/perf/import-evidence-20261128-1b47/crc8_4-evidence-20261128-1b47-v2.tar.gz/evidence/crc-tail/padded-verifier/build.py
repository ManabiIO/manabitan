import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parent
REPOSITORY = Path('/tmp/manabitan-crc-1b47')
CLANG = Path('/tmp/manabitan-native-9bb32/native-toolchain/bin/clang')
LINKER = CLANG.with_name('wasm-ld')
SOURCE_PATH = 'ext/js/dictionary/wasm/term-bank-parser.c'
INFLATE_PATH = REPOSITORY / 'ext/js/dictionary/wasm/term-bank-inflate.c'
PINNED = json.loads((REPOSITORY / 'dev/data/dictionary-wasm/manifest.json').read_text())
TARGET = next(target for target in PINNED['targets'] if target['name'] == 'term-bank-parser.wasm')
VARIANTS = [
    ('tail8_4_padded272', '565ea5d2e712b44bd6a33db65f5a8d3d34d8db6a', 16),
    ('slicing32_padded272', '92815fb8a5df090db95025c1b2d26e2677dc1d5a', 32),
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def replace_once(source, old, new):
    if source.count(old) != 1:
        raise RuntimeError(f'Expected one source occurrence: {old}')
    return source.replace(old, new, 1)


manifest = {
    'scope': 'Scratch production-export CRC table-padding variants only; no product changes or import-speed claim',
    'compiler': subprocess.check_output([str(CLANG), '--version'], text=True).strip(),
    'linker': subprocess.check_output([str(LINKER), '--version'], text=True).strip(),
    'productionArguments': TARGET['arguments'],
    'inflateSourceSha256': digest(INFLATE_PATH.read_bytes()),
    'variants': [],
}
for name, commit, slices in VARIANTS:
    original = subprocess.check_output(['git', 'show', f'{commit}:{SOURCE_PATH}'], cwd=REPOSITORY).decode()
    source = replace_once(original, f'crc32_table[{slices}][256]', f'crc32_table[{slices}][272]')
    source = replace_once(source, 'crc32_braid_table[8][256]', 'crc32_braid_table[8][272]')
    source = replace_once(source, 'crc32_word8(uint64_t word, uint32_t table[8][256])', 'crc32_word8(uint64_t word, uint32_t table[8][272])')
    source_file = ROOT / f'{name}.c'
    source_file.write_text(source)
    row = {
        'name': name,
        'parentCommit': commit,
        'sourcePath': str(source_file),
        'sourceSha256': digest(source.encode()),
        'originalSourceSha256': digest(original.encode()),
        'rowStrideWords': 272,
        'tableEntriesInitializedPerRow': 256,
        'mainTableSlices': slices,
        'mainTableBytes': slices * 272 * 4,
        'braidTableBytes': 8 * 272 * 4,
        'paddingBytes': (slices + 8) * 16 * 4,
        'builds': {},
    }
    for mode in ('production', 'test'):
        output = ROOT / f'{name}{"-test" if mode == "test" else ""}.wasm'
        extras = [] if mode == 'production' else [
            '-DTERM_BANK_CRC_TEST',
            '-Wl,--export=term_bank_crc32_test',
            '-Wl,--export=term_bank_crc32_update_test',
            '-Wl,--export=term_bank_crc32_combine_test',
        ]
        command = [str(CLANG), f'-fuse-ld={LINKER}', *TARGET['arguments'], *extras,
                   '-o', str(output), str(source_file), str(INFLATE_PATH)]
        subprocess.run(command, check=True)
        row['builds'][mode] = {
            'wasmPath': str(output),
            'wasmSha256': digest(output.read_bytes()),
            'wasmBytes': output.stat().st_size,
            'command': command,
        }
    manifest['variants'].append(row)

(ROOT / 'build-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'variants': [{key: row[key] for key in ('name', 'sourceSha256', 'paddingBytes', 'builds')} for row in manifest['variants']]}))
