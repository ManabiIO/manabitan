import assert from 'node:assert/strict';
import fs from 'node:fs';
import {crc32, deflateRawSync} from 'node:zlib';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

const root = path.dirname(fileURLToPath(import.meta.url));
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'build-manifest.json'), 'utf8'));
const baseline = new WebAssembly.Module(fs.readFileSync('/workspace/scratch/1b47f6463b98/manabitan/dev/data/dictionary-wasm/term-bank-parser.wasm'));
const expectedExports = WebAssembly.Module.exports(baseline);
const results = [];

function randomBytes(length, seed) {
    const bytes = new Uint8Array(length);
    for (let i = 0; i < length; ++i) {
        seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
        bytes[i] = seed >>> 24;
    }
    return bytes;
}

function functionCount(data) {
    let offset = 8;
    const leb = () => {
        let value = 0, shift = 0, byte;
        do { byte = data[offset++]; value += (byte & 127) * 2 ** shift; shift += 7; } while (byte & 128);
        return value;
    };
    while (offset < data.length) {
        const id = data[offset++];
        const length = leb();
        if (id === 3) { return leb(); }
        offset += length;
    }
    throw new Error('No function section');
}

for (const variant of manifest.variants) {
    const productionBytes = fs.readFileSync(variant.builds.production.wasmPath);
    const productionModule = new WebAssembly.Module(productionBytes);
    assert.deepEqual(WebAssembly.Module.exports(productionModule), expectedExports);
    assert.deepEqual(WebAssembly.Module.imports(productionModule), []);
    assert.equal(functionCount(productionBytes), 51);
    const production = new WebAssembly.Instance(productionModule).exports;
    const test = new WebAssembly.Instance(new WebAssembly.Module(fs.readFileSync(variant.builds.test.wasmPath))).exports;
    const result = {
        name: variant.name,
        productionFunctions: 51,
        productionExportsMatchBaseline: true,
        initialMemoryBytes: production.memory.buffer.byteLength,
        heapBase: production.wasm_alloc(0),
        gapCases: 0,
        wholeBankCases: 0,
        combineCases: 0,
        productionFallbackCases: 0,
        productionInflateCases: 0,
    };

    test.wasm_reset_heap();
    const gaps = randomBytes(65568, 0x8931a5e7);
    const gapPointer = test.wasm_alloc(gaps.length);
    new Uint8Array(test.memory.buffer, gapPointer, gaps.length).set(gaps);
    const gapLengths = [...Array.from({length: 129}, (_, i) => i), 255, 256, 257, 511, 512, 513, 1023, 1024, 1025,
        ...Array.from({length: 32}, (_, i) => 65520 + i)];
    let state = 0x51a73b92;
    for (const length of gapLengths) {
        for (let alignment = 0; alignment < 16; ++alignment) {
            state = (Math.imul(state, 1664525) + 1013904223) >>> 0;
            const view = gaps.subarray(alignment, alignment + length);
            for (const seed of [0, 0xffffffff, state]) {
                assert.equal(test.term_bank_crc32_update_test(seed, gapPointer + alignment, length) >>> 0, crc32(view, seed) >>> 0);
                ++result.gapCases;
            }
        }
    }

    const wholeLengths = [...Array.from({length: 257}, (_, i) => i), 65535, 65536, 65537, 131071, 131072, 131073,
        262143, 262144, 262145, 262207, 262208, 262209, 1048576, 1048639];
    for (const length of wholeLengths) {
        const bytes = randomBytes(length, 0x9e3779b9 ^ length);
        const expected = crc32(bytes) >>> 0;
        test.wasm_reset_heap();
        const pointer = test.wasm_alloc(length + 16);
        for (let alignment = 0; alignment < 16; ++alignment) {
            new Uint8Array(test.memory.buffer, pointer + alignment, length).set(bytes);
            assert.equal(test.term_bank_crc32_test(pointer + alignment, length) >>> 0, expected);
            ++result.wholeBankCases;
        }
    }
    const first = randomBytes(8192, 0x51a73b92);
    for (const length of [0, 1, 2, 3, 4, 7, 8, 15, 16, 17, 31, 32, 63, 64, 255, 256, 257, 511, 512, 1023, 1024, 65535, 65536, 1048577]) {
        const second = randomBytes(length, 0x4d595df4 ^ length);
        for (const prefix of [0, 1, 13, 256, first.length]) {
            const firstCrc = crc32(first.subarray(0, prefix));
            assert.equal(test.term_bank_crc32_combine_test(firstCrc, crc32(second), length) >>> 0, crc32(second, firstCrc) >>> 0);
            ++result.combineCases;
        }
    }

    for (const length of [2, 256, 65536, 262143, 262144, 262145, 1048639]) {
        const bytes = randomBytes(length, 0xe18668b3 ^ length);
        bytes[0] = 91;
        bytes[length - 1] = 93;
        const expected = crc32(bytes) >>> 0;
        production.wasm_reset_heap();
        const pointer = production.wasm_alloc(length);
        const spans = production.wasm_alloc(8);
        const signatures = production.wasm_alloc(4);
        const stats = production.wasm_alloc(12);
        new Uint8Array(production.memory.buffer, pointer, length).set(bytes);
        new Uint32Array(production.memory.buffer, spans, 2).set([0, length]);
        new Uint32Array(production.memory.buffer, signatures, 1)[0] = expected;
        const verify = () => production.verify_term_bank_source_crcs(pointer, length, spans, 1, signatures, 0, 0, 0, stats);
        assert.equal(verify(), 0);
        assert.deepEqual(Array.from(new Uint32Array(production.memory.buffer, stats, 3)), [length, 0, 0]);
        new Uint32Array(production.memory.buffer, signatures, 1)[0] = expected ^ 1;
        assert.equal(verify(), -4);
        result.productionFallbackCases += 2;

        const compressed = deflateRawSync(bytes);
        const input = production.wasm_alloc(compressed.length);
        const metadata = production.wasm_alloc(20);
        const output = production.wasm_alloc(length);
        new Uint8Array(production.memory.buffer, input, compressed.length).set(compressed);
        const values = new Uint32Array(production.memory.buffer, metadata, 5);
        values.set([0, compressed.length, length, 8, expected]);
        const inflate = () => production.inflate_and_join_term_banks(input, compressed.length, metadata, metadata + 4,
            metadata + 8, metadata + 12, metadata + 16, 1, output, length, spans);
        assert.equal(inflate(), length);
        assert.deepEqual(new Uint8Array(production.memory.buffer, output, length), bytes);
        values[4] = expected ^ 1;
        assert.equal(inflate(), -4);
        result.productionInflateCases += 2;
    }
    results.push(result);
}

const report = {scope: 'Independent zlib oracle, production whole-bank verification/inflate, and export-structure checks; no timing claim', variants: results};
fs.writeFileSync(path.join(root, 'oracle-results.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(report, null, 2));
