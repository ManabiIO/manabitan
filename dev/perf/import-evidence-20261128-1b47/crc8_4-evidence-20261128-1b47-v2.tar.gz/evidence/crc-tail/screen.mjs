import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {crc32} from 'node:zlib';

const variants = ['baseline', 'tail8', 'tail4', 'tail8_4'];
const dataLength = 1 << 20;
const data = new Uint8Array(dataLength);
let state = 0x51a73b92;
const random = () => (state = (Math.imul(state, 1664525) + 1013904223) >>> 0);
for (let i = 0; i < data.length; ++i) data[i] = random() >>> 24;
const probes = {};
for (const name of variants) {
    const module = await WebAssembly.compile(await readFile(new URL(`${name}.wasm`, import.meta.url)));
    const {exports: wasm} = await WebAssembly.instantiate(module);
    const pointer = wasm.probe_heap();
    const required = pointer + data.byteLength + 65536 * 8;
    wasm.memory.grow(Math.max(0, Math.ceil(required / 65536) - wasm.memory.buffer.byteLength / 65536));
    new Uint8Array(wasm.memory.buffer, pointer, data.byteLength).set(data);
    probes[name] = {wasm, pointer, spansPointer: pointer + data.byteLength};
}
let checks = 0;
for (let length = 0; length <= 512; ++length) {
    for (let alignment = 0; alignment < 16; ++alignment) {
        const seed = random();
        const expected = crc32(data.subarray(alignment, alignment + length), seed);
        for (const {wasm, pointer} of Object.values(probes)) {
            assert.equal(wasm.probe_gap(seed, pointer + alignment, length) >>> 0, expected);
            ++checks;
        }
    }
}
for (let i = 0; i < 2048; ++i) {
    const length = random() % 65536;
    const offset = random() % (data.length - length);
    const seed = random();
    const expected = crc32(data.subarray(offset, offset + length), seed);
    for (const {wasm, pointer} of Object.values(probes)) {
        assert.equal(wasm.probe_gap(seed, pointer + offset, length) >>> 0, expected);
        ++checks;
    }
}
const reports = [];
const repeats = 32;
const spanCount = 16384;
for (const [name, min, max] of [['tiny', 0, 31], ['row-sized', 32, 127], ['broad', 0, 255], ['larger', 256, 511]]) {
    const spans = new Uint32Array(spanCount * 2);
    let bytesPerPass = 0;
    for (let i = 0; i < spanCount; ++i) {
        const length = min + ((random() >>> 16) % (max - min + 1));
        spans[2 * i] = random() % (data.length - length);
        spans[2 * i + 1] = length;
        bytesPerPass += length;
    }
    for (const {wasm, spansPointer} of Object.values(probes)) {
        new Uint32Array(wasm.memory.buffer, spansPointer, spans.length).set(spans);
    }
    let oracle;
    const run = (arm) => {
        const {wasm, pointer, spansPointer} = probes[arm];
        const start = performance.now();
        const value = wasm.probe_batch(pointer, spansPointer, spanCount, repeats) >>> 0;
        const durationMs = performance.now() - start;
        oracle ??= value;
        assert.equal(value, oracle);
        return durationMs;
    };
    for (let warmup = 0; warmup < 3; ++warmup) for (const arm of variants) run(arm);
    const observations = [];
    for (let block = 0; block < 12; ++block) {
        const order = block % 2 ? [...variants].reverse() : variants;
        for (const arm of order) observations.push({block, arm, durationMs: run(arm)});
    }
    const median = (values) => {
        const sorted = [...values].sort((a, b) => a - b);
        return (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2;
    };
    const medians = Object.fromEntries(variants.map((arm) => [arm, median(observations.filter((x) => x.arm === arm).map((x) => x.durationMs))]));
    reports.push({name, min, max, bytesPerPass, repeats, spanCount, oracle, medians, changesPct: Object.fromEntries(variants.slice(1).map((arm) => [arm, (medians[arm] / medians.baseline - 1) * 100])), observations});
    console.log(JSON.stringify({name, medians, changesPct: reports.at(-1).changesPct}));
}
await writeFile(new URL('screen.json', import.meta.url), JSON.stringify({scope: 'Synthetic CRC gap microbenchmark, not browser import timing or a production-corpus replay', checks, runtime: process.version, reports}, null, 2) + '\n');
console.log(JSON.stringify({checks}));
