#!/usr/bin/env python3
"""Read-only revalidation of an existing, frozen hosted qualification artifact."""
import argparse
import hashlib
import io
import json
import pathlib
import random
import statistics
import subprocess
import sys
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--archive', type=pathlib.Path, required=True)
parser.add_argument('--expected-sha256', required=True)
parser.add_argument('--dictionary', choices=('jmdict', 'jitendex', 'vndb'), required=True)
parser.add_argument('--output', type=pathlib.Path, required=True)
parser.add_argument('--extract', type=pathlib.Path, required=True)
parser.add_argument('--baseline-root', type=pathlib.Path, default=pathlib.Path('/workspace/scratch/1b47f6463b98/manabitan'))
args = parser.parse_args()
baseline = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
sha = lambda data: hashlib.sha256(data).hexdigest()
blob = args.archive.read_bytes()
assert sha(blob) == args.expected_sha256
dependency_root = args.baseline_root / 'dev/perf/import-memory-20261125-a7f7'
dependencies = {}
for path in sorted(dependency_root.glob('*.py')):
    relative = str(path.relative_to(args.baseline_root))
    data = path.read_bytes()
    expected = subprocess.check_output(['git', 'show', baseline + ':' + relative], cwd=args.baseline_root)
    assert data == expected, relative
    dependencies[relative] = sha(data)
sys.path.insert(0, str(dependency_root))
from qualification_receipts import validate_import_summary, require_matching_receipts
from audit_memory import audit_cell

assert not args.extract.exists(), 'Never overwrite an earlier artifact extraction'
args.extract.mkdir(parents=True)
inventory = []
with zipfile.ZipFile(io.BytesIO(blob)) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names))
    for member in archive.infolist():
        path = pathlib.PurePosixPath(member.filename)
        assert not path.is_absolute() and '..' not in path.parts
        if member.is_dir():
            continue
        data = archive.read(member)
        inventory.append({'path': member.filename, 'bytes': len(data), 'sha256': sha(data)})
        if not member.filename.endswith(('.zip', '.html')):
            target = args.extract / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    root = args.extract / args.dictionary
    read = lambda name: json.loads((root / name).read_text())
    plan = read('registered-plan.json')
    assert plan['baseline'] == baseline and plan['dictionary'] == args.dictionary
    assert plan['flags'] == {} and plan['pairs'] == 6
    identities = read('source-identities.json')
    browser = read('browser-identity.json')
    package_entries = {}
    for arm in ('A', 'B'):
        data = archive.read(args.dictionary + '/package-' + arm + '.zip')
        assert sha(data) == identities['arms'][arm]['packageSha256']
        with zipfile.ZipFile(io.BytesIO(data)) as package:
            assert len(package.namelist()) == len(set(package.namelist()))
            entries = {item.filename: sha(package.read(item)) for item in package.infolist() if not item.is_dir()}
        assert entries == identities['arms'][arm]['entries']
        package_entries[arm] = entries
    changed = sorted(name for name in set(package_entries['A']) | set(package_entries['B']) if package_entries['A'].get(name) != package_entries['B'].get(name))
    assert changed == sorted(plan['expectedPackageEntries']) == identities['changedPackageEntries']
    fixture = read(plan['schedule'][0]['id'] + '/summary.json')['fixture']
    sah = plan.get('vndbSahAllocationPolicy')
    if sah is not None:
        # The exact frozen current-baseline receipt declared 37 units prospectively.
        assert args.dictionary == 'vndb'
        assert sah == {'origin': 'explicit', 'rangeUnits': [37, 37], 'unitBytes': 4096}
        sah = tuple(sah['rangeUnits'])
    reference = None
    full_media_reference = None
    receipts = []
    phase_metrics = []
    all_items = [(item['id'], item['arm'], 'sample', False) for item in plan['schedule']]
    all_items += [('exhaustive-media-' + arm, arm, 'all', False) for arm in ('A', 'B')]
    all_items += [('memory/' + item['name'], item['arm'], 'sample', True) for item in plan['memorySchedule']]
    for name, arm, media, memory in all_items:
        arm = 'B' if arm == 'B' else 'A'
        identity = identities['arms'][arm]
        hashes = identity['sourceHashes'].copy()
        if memory:
            hashes['test/chromium/extension-two-dictionary-import.e2e.js'] = sha((root / 'memory/harness-instrumented.js').read_bytes())
        summary = read(name + '/summary.json')
        report = read(name + '/run-1.json')
        receipt = validate_import_summary(summary, report, dictionary=args.dictionary, fixture=fixture,
            source_sha=identity['sha'], package_sha256=identity['packageSha256'],
            browser_version=browser['version'], import_flags=None, source_hashes=hashes,
            source_dirty=memory, media_check=media, vndb_sah_allocation_units=sah)
        assert receipt == read(name + '/canonical-receipt.json'), name
        if reference is None:
            reference = receipt
        else:
            require_matching_receipts(reference, receipt, compare_media=media != 'all')
        if media == 'all':
            if full_media_reference is None:
                full_media_reference = receipt
            else:
                require_matching_receipts(full_media_reference, receipt)
        receipts.append({'path': name, 'arm': arm, 'mediaCheck': media, 'memoryInstrumentation': memory,
                         'rawReportStatus': report['status'], 'canonicalReceiptSha256': sha(json.dumps(receipt, sort_keys=True).encode())})
        if name.startswith('pair-'):
            phase_metrics.append({'path': name, 'arm': arm, 'metrics': summary['runs'][0]['step4Breakdown']['dictionaries'][0]})
    memory_audit = audit_cell(root / 'memory')
    assert memory_audit == read('memory/memory-audit.json')
    observations = read('observations.json')
    assert len(observations) == len(plan['schedule'])
    for original, item in zip(plan['schedule'], observations):
        assert all(item[key] == value for key, value in original.items())
    def paired(kind, left, right):
        pairs = {}
        for item in observations:
            if item['kind'] == kind:
                pairs.setdefault(item['pair'], {})[item['arm']] = item['totalImportMs']
        assert all(set(pair) == {left, right} for pair in pairs.values())
        ratios = [v[right] / v[left] for v in pairs.values()]
        rng = random.Random(897)
        resampled = sorted(statistics.median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
        return {'count': len(ratios), 'ratios': ratios,
                'medianPairedChangePercent': (statistics.median(ratios) - 1) * 100,
                'equalWorkChangePercent': (sum(v[right] for v in pairs.values()) / sum(v[left] for v in pairs.values()) - 1) * 100,
                'worstPairChangePercent': (max(ratios) - 1) * 100,
                'descriptiveBootstrap95Percent': [(resampled[index] - 1) * 100 for index in (249, 9749)],
                'fasterPairs': sum(ratio < 1 for ratio in ratios)}
    candidate = paired('candidate', 'A', 'B')
    control = paired('control', 'A', 'C')
    analysis = read('analysis.json')
    assert analysis['candidateVsBaseline'] == candidate and analysis['identicalCodeControl'] == control
    result = {'scope': 'Read-only artifact audit; no observation, source, protocol, gate, or result modified',
        'auditorSha256': sha(pathlib.Path(__file__).read_bytes()),
        'archive': str(args.archive), 'archiveSha256': sha(blob), 'archiveBytes': len(blob),
        'memberCount': len(inventory), 'memberInventory': inventory, 'extraction': str(args.extract),
        'validatorDependencies': dependencies, 'allPackageBytesMatchIdentity': True,
        'changedPackageEntries': changed, 'receiptsRevalidated': receipts,
        'all26ReceiptsExact': len(receipts) == 26, 'rawMemoryScanAudit': memory_audit,
        'candidateVsBaselineRecomputed': candidate, 'identicalCodeControlRecomputed': control,
        'phaseMetrics': phase_metrics,
        'status': analysis['status'], 'semanticFailures': read('memory/semantic-failures.json'),
        'sourceIdentities': identities, 'registeredPlan': plan}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('archiveSha256', 'memberCount', 'all26ReceiptsExact', 'changedPackageEntries', 'rawMemoryScanAudit', 'candidateVsBaselineRecomputed', 'identicalCodeControlRecomputed', 'status')}, indent=2))
