#!/usr/bin/env python3
"""Count preserved existing browser observations; never acquire a new run."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


parser = argparse.ArgumentParser()
parser.add_argument('--earlier-manifest', type=Path, required=True)
parser.add_argument('--staging-root', type=Path, required=True)
args = parser.parse_args()
manifest_bytes = args.earlier_manifest.read_bytes()
manifest = json.loads(manifest_bytes)
assert sha(manifest_bytes) == '5d418c9cd6176cc22dd56cd81d3cad13eb3880bf095c0662aea5efa42f5fbe20'
assert manifest['archive']['sha256'] == '76b1ae9451052684192902916b5cdeb1e812ff806b064d0773e6d2bdf242ec98'
archive = args.earlier_manifest.parent / manifest['archive']['file']
with archive.open('rb') as stream:
    assert hashlib.file_digest(stream, 'sha256').hexdigest() == manifest['archive']['sha256']
inventory = {x['path']: x for x in manifest['members']}
earlier = {
    'checkpoint-jmdict': {'rawReports': 0, 'canonicalReceipts': 0, 'memoryScanRows': 0, 'memoryFiles': []},
    'checkpoint-jitendex': {'rawReports': 0, 'canonicalReceipts': 0, 'memoryScanRows': 0, 'memoryFiles': []},
    'pipeline-vndb': {'rawReports': 0, 'canonicalReceipts': 0, 'memoryScanRows': 0, 'memoryFiles': []},
}
with tarfile.open(archive, 'r:gz') as source:
    seen = set()
    for item in source:
        assert item.isfile() and item.name in inventory and item.name not in seen
        seen.add(item.name)
        data = source.extractfile(item).read()
        expected = inventory[item.name]
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
        prefix = 'evidence/browser-results-addendum-20261128-1b47/raw/'
        if not item.name.startswith(prefix):
            continue
        cohort, relative = item.name[len(prefix):].split('/', 1)
        row = earlier[cohort]
        row['rawReports'] += relative.endswith('/run-1.json')
        row['canonicalReceipts'] += relative.endswith('/canonical-receipt.json')
        if relative.endswith('/memory.json') and '/memory/' in relative:
            count = len(json.loads(data)['samples'])
            row['memoryScanRows'] += count
            row['memoryFiles'].append({'archiveMember': item.name, 'bytes': len(data),
                                       'sha256': sha(data), 'sampleRows': count})
    assert seen == set(inventory)
assert [earlier[k]['memoryScanRows'] for k in earlier] == [250, 299, 503]

root = args.staging_root.absolute()
bundle = root / 'evidence/completed-browser-raw-addendum-20261128-1b47'
receipt = json.loads((bundle / 'staging-receipt.json').read_text())
current = {}
for entry in receipt['cohorts']:
    label = entry['cohort']
    current[label] = {'rawReports': entry['rawReports'],
                      'canonicalReceipts': entry['canonicalReceipts'],
                      'memoryScanRows': 0, 'memoryFiles': []}
for item in receipt['rawMembers']:
    relative = item['originalArtifactMember']
    if not (relative.endswith('/memory.json') and '/memory/' in relative):
        continue
    path = root / item['memberPath']
    assert not path.is_symlink()
    data = path.read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256']
    count = len(json.loads(data)['samples'])
    row = current[item['cohort']]
    row['memoryScanRows'] += count
    row['memoryFiles'].append({'archiveMember': item['memberPath'], 'bytes': len(data),
                              'sha256': sha(data), 'sampleRows': count})
assert [current[k]['memoryScanRows'] for k in current] == [328, 276, 421]
for row in [*earlier.values(), *current.values()]:
    assert row['rawReports'] == row['canonicalReceipts'] == 26
    assert len(row['memoryFiles']) == 4
report = {
    'observationStatusCutoffUtc': '2026-11-28T06:58:33Z',
    'earlierEvidence': {
        'commit': '28332c2fc3a291f1728cd0441a878e3d5bd335ae',
        'archiveFile': archive.name, 'archiveSha256': manifest['archive']['sha256'],
        'manifestSha256': sha(manifest_bytes), 'allArchiveMembersReverified': len(inventory),
        'cohorts': earlier,
    },
    'currentEvidence': {'name': 'completed-browser-raw-addendum-20261128-1b47',
                        'cohorts': current, 'stagingReceiptSha256': sha((bundle / 'staging-receipt.json').read_bytes())},
    'totals': {'cohorts': len(earlier) + len(current),
               'rawReports': sum(x['rawReports'] for x in [*earlier.values(), *current.values()]),
               'canonicalReceipts': sum(x['canonicalReceipts'] for x in [*earlier.values(), *current.values()]),
               'rawMemoryScanRows': sum(x['memoryScanRows'] for x in [*earlier.values(), *current.values()])},
    'scope': 'Durable byte/row coverage only. No performance pooling, new observation, retry, replacement, or gate change.',
}
assert report['totals'] == {'cohorts': 6, 'rawReports': 156, 'canonicalReceipts': 156, 'rawMemoryScanRows': 2077}
(bundle / 'completed-cohort-durability.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['totals']))
