# Local index checkpoints: closed without a PR

Candidate `0efd7507eb19b0b7f15410b14aac427e80e22244`, baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`, Actions run `46104738613`. This later addendum preserves the already sealed 06:32:35 session snapshot.

The main JMdict hypothesis is not supported by the completed whole-import clock. Its paired median is nearly flat and its equal-work ratio is positive. That result is independently sufficient to reject promotion; the separate memory-coverage failures are preserved additional qualifications, not the only reason to hold it. No further acquisition or PR follows.

| Corpus | Median B/A | Equal-work | Descriptive95% median interval | Same-code median | Memory | Route |
| --- | ---: | ---: | --- | ---: | --- | --- |
| jmdict | -0.347% | +0.175% | [-1.264%, +2.173%] | +1.567% | Coverage unqualified | Local |
| jitendex | -1.753% | +1.382% | [-3.972%, +9.805%] | -1.344% | Coverage unqualified | Local |
| vndb | -0.714% | -0.186% | [-3.955%, +4.049%] | +1.102% | Pass | Unchanged worker |

All three corpora completed the six paired timings, two identical-code pairs, excluded warmups, exhaustive-media runs and four separate memory imports. All 78 raw browser reports/canonical receipts pass the unchanged semantic validator, including exact source/package bindings, declared work, storage and media/restart comparisons. Actual package ZIP bytes and every member hash were revalidated. All 970 raw memory scans were recomputed.

JMdict candidate B1 has a 414.681 ms covered-import scan gap; Jitendex candidate B2 has 303.792 ms. Both exceed the fixed 250 ms coverage limit, so their memory maxima remain null and the complete memory comparisons fail. VNDB’s coverage and memory-size gates pass. These are sampling qualification failures, not browser import failures or semantic exceptions.

Every JMdict/Jitendex report selects the local writer. The candidate adds 8 MiB periodic checkpoints to the baseline’s final-only local flush policy. In this repeated JMdict cohort, baseline record-close median is 8.65 ms, not the single motivating orientation observation’s 130.6 ms. Candidate close median is 4.30 ms (paired close delta median −4.45 ms), but whole import does not improve. A lower inclusive tail is insufficient when work can move earlier. The overlapping end-phase metrics are retained but never summed into a saving.

Every VNDB report selects two remote index-worker files. That route keeps the same 16 MiB checkpoint policy in both arms, and its flat timing is a control for the unchanged path rather than a test of the local mechanism.

All original logs, raw observations, failed memory records, archive digests, independent audit recipes and full member inventories remain in `hosted-checkpoint-{jmdict,jitendex,vndb}-46104738613`. The exact machine-readable disposition is `checkpoint-final-disposition-1b47.json`. No result is excluded, retried or pooled with another cohort.
