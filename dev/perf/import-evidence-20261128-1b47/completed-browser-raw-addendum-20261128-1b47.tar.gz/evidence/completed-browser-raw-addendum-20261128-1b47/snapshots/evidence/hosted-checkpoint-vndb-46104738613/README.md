# Checkpoint VNDB: complete qualification; no useful speed signal

Frozen candidate `0efd7507eb19b0b7f15410b14aac427e80e22244` versus baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. Actions run 46104738613, job 140863903012, completed 2026-11-28 05:58:52 UTC successfully.

All 20 declared warmup/timing/control observations, two full-media imports and four separate sampled-memory imports complete. All 26 raw canonical receipts, package identities, six candidate pairs, two identical-code pairs,421 raw memory scans and bound markers were independently revalidated from the archive. Every frozen memory coverage and size gate passes; no semantic failures occur.

Timing is flat within variation: paired median −0.713612623%, equal-work −0.185725976%, descriptive 95% paired-median interval [−3.955042251%,+4.049348587%], 3/6 pairs faster, worst +5.636965256%. Identical-code control median +1.102086878%. Sampled private bytes rise median +1.949324366%/maximum +3.559963429%; PSS rises median +1.799394070%/maximum +2.735624080%. These are non-atomic sampled measurements, not exact peaks.

All 26 reports select two dedicated index-worker files. The candidate changes local checkpoint policy while retaining the worker’s 16 MiB policy. This result therefore does not test the local 8 MiB mechanism targeted by queued/running JMdict/Jitendex jobs. No VNDB speedup is claimed.

Artifact 15251240742 has 206 members, 35,116,853 bytes and SHA-256 `3342e9490f00283e96553f492236fae0c61b2723f81bd1fa5098e2934b91aedf`. The complete ZIP and non-package/non-HTML extraction remain in task-owned `/home/agent/manabitan-import-capture-1b47/hosted-artifacts`. The full job log, emitted raw JSON, independent recomputation, full archive/member/package proof and mechanism census are preserved in this directory. `../audit-hosted-import-artifact-1b47.py` performs the read-only audit against the unchanged baseline validator; no new observation was acquired.
