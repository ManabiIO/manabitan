#!/usr/bin/env python3
"""Read-only reconciliation of retained observations; acquires no measurements."""
import hashlib
import io
import json
from pathlib import Path
import random
import statistics
import sys
import zipfile

workspace = Path(__file__).resolve().parents[1]
repository = workspace / 'manabitan'
retained = workspace / 'evidence/hosted-pipeline-jitendex-46105215670'
raw = Path(sys.argv[1]).resolve()
archive = Path(sys.argv[2]).resolve()
output = Path(sys.argv[3]).resolve()
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
plan = read(raw / 'registered-plan.json')
identities = read(raw / 'source-identities.json')
observations = read(raw / 'observations.json')
original_analysis = read(raw / 'analysis.json')
peer = read(retained / 'independent-artifact-audit.json')
assert sha(archive.read_bytes()) == peer['archiveSha256']
assert plan['baseline'] == '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
assert plan['candidate'] == '05907e30c83b4cc7cc8d653e069427a6141b0e85'
assert plan['pairs'] == 6 and len(plan['schedule']) == len(observations) == 20
assert [{key: row[key] for key in ('arm', 'id', 'kind', 'pair')} for row in observations] == plan['schedule']
assert identities['arms']['A']['sha'] == plan['baseline']
assert identities['arms']['B']['sha'] == plan['candidate']
assert identities['controlC'] == 'Same A source, package, runtime, and flags under a distinct observation label'
package_checks = []
with zipfile.ZipFile(archive) as outer:
    for arm in ('A', 'B'):
        package = outer.read(f'jitendex/package-{arm}.zip')
        identity = identities['arms'][arm]
        assert sha(package) == identity['packageSha256']
        with zipfile.ZipFile(io.BytesIO(package)) as inner:
            entries = {name: sha(inner.read(name)) for name in inner.namelist() if not name.endswith('/')}
        assert entries == identity['entries']
        package_checks.append({'arm': arm, 'sha256': sha(package), 'entries': len(entries), 'allEntryDigestsMatch': True})
changed = sorted(name for name in set(identities['arms']['A']['entries']) | set(identities['arms']['B']['entries'])
                 if identities['arms']['A']['entries'].get(name) != identities['arms']['B']['entries'].get(name))
assert changed == sorted(plan['expectedPackageEntries']) == sorted(identities['changedPackageEntries'])
for name in changed:
    assert sha((workspace / 'pipeline-experiment' / 'ext' / name).read_bytes()) == identities['arms']['B']['entries'][name]

helpers = repository / 'dev/perf/import-memory-20261125-a7f7'
for name, expected in peer['validatorDependencies'].items():
    assert sha((repository / name).read_bytes()) == expected
sys.path.insert(0, str(helpers))
from qualification_receipts import validate_import_summary, require_matching_receipts
from protocol import memory_overlay
from audit_memory import audit_cell

fixture_path = repository / 'test/perf/dictionaries.lock.json'
fixture = read(fixture_path)['dictionaries']['jitendex']
assert sha(fixture_path.read_bytes()) == identities['arms']['A']['fixtureLockSha256']
assert fixture['termRows'] == 436555
harness_path = 'test/chromium/extension-two-dictionary-import.e2e.js'
overlay_hash = sha(memory_overlay((repository / harness_path).read_text()).encode())
browser = read(raw / 'browser-identity.json')['version']
schedule = [(row['id'], 'B' if row['arm'] == 'B' else 'A', 'sample', False) for row in plan['schedule']]
schedule += [('exhaustive-media-A', 'A', 'all', False), ('exhaustive-media-B', 'B', 'all', False)]
schedule += [('memory/' + row['name'], row['arm'], 'sample', True) for row in plan['memorySchedule']]
assert len(schedule) == 26
assert set(name + '/summary.json' for name, *_ in schedule) == {str(path.relative_to(raw)) for path in raw.rglob('summary.json')}
receipts = []
reference = None
full_media_reference = None
details_by_name = {}
candidate_activation = []
for name, arm, mode, instrumented in schedule:
    summary = read(raw / name / 'summary.json')
    report = read(raw / name / 'run-1.json')
    identity = identities['arms'][arm]
    hashes = identity['sourceHashes'].copy()
    if instrumented:
        hashes[harness_path] = overlay_hash
    receipt = validate_import_summary(summary, report, dictionary='jitendex', fixture=fixture,
        source_sha=identity['sha'], package_sha256=identity['packageSha256'], browser_version=browser,
        import_flags=plan['flags'] or None, source_hashes=hashes, source_dirty=instrumented, media_check=mode)
    assert receipt == read(raw / name / 'canonical-receipt.json')
    if reference is None:
        reference = receipt
    require_matching_receipts(reference, receipt, compare_media=mode == 'sample')
    if mode == 'all':
        if full_media_reference is None:
            full_media_reference = receipt
        require_matching_receipts(full_media_reference, receipt)
    run = summary['runs'][0]
    matching = [row for row in observations if row['id'] == name]
    if matching:
        assert matching[0]['totalImportMs'] == run['totalImportMs']
    phases = [phase for phase in run['importDebug']['importerPhaseTimings'] if phase['phase'].startswith('term-file-fast-path:')]
    assert len(phases) == 1
    details = phases[0]['details']
    details_by_name[name] = details
    assert details['rows'] == 436555 and details['chunkCount'] == 22
    if arm == 'B':
        keys = ['contentDeferredPersistenceCount', 'contentDeferredWaitMs', 'dedupRecentSourceAdoptedBytes',
                'parserParallelOwnedContentBytes', 'parserBorrowedContentResultCount']
        activation = {'observation': name, **{key: details[key] for key in keys}}
        assert all(activation[key] == 0 for key in keys[:-1])
        assert activation[keys[-1]] == 22
        candidate_activation.append(activation)
    receipts.append({'observation': name, 'arm': arm, 'mediaCheck': mode, 'memoryInstrumentation': instrumented,
                     'rawStatus': report['status'], 'summarySha256': sha((raw / name / 'summary.json').read_bytes()),
                     'canonicalReceiptSha256': sha(json.dumps(receipt, sort_keys=True).encode())})
assert len(candidate_activation) == 11

def paired_summary(kind, left, right):
    pairs = {}
    for row in observations:
        if row['kind'] == kind:
            pairs.setdefault(row['pair'], {})[row['arm']] = row['totalImportMs']
    assert all(left in pair and right in pair for pair in pairs.values())
    ratios = [pair[right] / pair[left] for pair in pairs.values()]
    rng = random.Random(897)
    draws = sorted(statistics.median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
    return {'count': len(pairs), 'ratios': ratios, 'medianPairedChangePercent': (statistics.median(ratios) - 1) * 100,
            'equalWorkChangePercent': (sum(pair[right] for pair in pairs.values()) / sum(pair[left] for pair in pairs.values()) - 1) * 100,
            'worstPairChangePercent': (max(ratios) - 1) * 100,
            'descriptiveBootstrap95Percent': [(draws[index] - 1) * 100 for index in (249, 9749)],
            'fasterPairs': sum(ratio < 1 for ratio in ratios)}

timing = paired_summary('candidate', 'A', 'B')
control = paired_summary('control', 'A', 'C')
assert timing == original_analysis['candidateVsBaseline']
assert control == original_analysis['identicalCodeControl']
phase_metrics = ['importerChunkSinkMs', 'parserParseBankMs', 'parserSourceInflateMs', 'parserOrderedSinkWaitMs',
                 'dedupScanMs', 'dedupCanonicalScanMs', 'contentStoreMs', 'contentCompressMs', 'contentOpfsAppendMs',
                 'termRecordEncodeMs', 'termRecordWriteMs', 'termRecordFieldEncodeMs', 'termRecordValidationMs']
phase_comparisons = {}
for metric in phase_metrics:
    pairs = [(details_by_name[f'pair-{index:02}-A'][metric], details_by_name[f'pair-{index:02}-B'][metric]) for index in range(1, 7)]
    phase_comparisons[metric] = {'medianA': statistics.median(a for a, b in pairs), 'medianB': statistics.median(b for a, b in pairs),
        'medianPairedChangePercent': (statistics.median(b / a for a, b in pairs) - 1) * 100,
        'pairs': [{'A': a, 'B': b} for a, b in pairs]}

memory_audit = audit_cell(raw / 'memory')
assert memory_audit == read(raw / 'memory/memory-audit.json')
memory = read(raw / 'memory/A1/memory.json')
start, end = (int(marker['monotonicNs']) for marker in memory['windowMarkers'])
covered = [sample for sample in memory['samples'] if sample['qualifiedForWholeTreePss'] and
           sample['startedAtMonotonicNs'] >= start and sample['finishedAtMonotonicNs'] <= end]
points = [start] + [(sample['startedAtMonotonicNs'] + sample['finishedAtMonotonicNs']) // 2 for sample in covered] + [end]
gaps = [(b - a) / 1e6 for a, b in zip(points, points[1:])]
assert max(gaps) == memory['maximumCoveredSampleGapMs'] == 350.393048
assert memory['qualificationFailures'] == ['covered-import-scan-gap-over-250ms']
assert memory['maxSampledPssKiB'] is None and memory['maxSampledPrivateKiB'] is None
assert read(raw / 'memory/semantic-failures.json') == []
validation = reference['common']['validation']
result = {
    'scope': 'Independent read-only reconciliation and activation interpretation; no new acquisition or gate changes',
    'scriptSha256': sha(Path(__file__).read_bytes()), 'rawArtifactRoot': str(raw),
    'archiveSha256': sha(archive.read_bytes()), 'baseline': plan['baseline'], 'candidate': plan['candidate'],
    'packageChecks': package_checks, 'changedPackageEntries': changed,
    'browserRuns': 26, 'scheduledWarmupTimingControlObservations': 20, 'allReceiptsRevalidated': True,
    'receipts': receipts, 'semanticSummary': {'rows': validation['termRows'], 'probeTerms': validation['probeCount'],
        'lookupObservationsPerRun': len(validation['lookup']['observations']), 'restart': validation['restart'],
        'storage': validation['storage'], 'sampleMedia': reference['media'], 'exhaustiveMedia': full_media_reference['media']},
    'timing': timing, 'identicalCodeControl': control, 'candidateActivation': candidate_activation,
    'phaseComparisons': phase_comparisons, 'phaseCaution': 'Worker and main-thread durations overlap; phase deltas are descriptive and must not be added or treated as causal attribution.',
    'memoryAudit': memory_audit, 'memoryA1': {'coveredScans': len(covered), 'coveredGapsMs': gaps,
        'maximumGapMs': max(gaps), 'requiredMaximumMs': 250, 'qualificationFailures': memory['qualificationFailures'],
        'sampledMaxima': {'pssKiB': memory['maxSampledPssKiB'], 'privateKiB': memory['maxSampledPrivateKiB']}},
    'interpretation': [
        'All recorded source, package, row-count, content-probe, lookup, restart, logical-storage and media proofs match. This does not claim an exhaustive byte-by-byte check of every stored definition.',
        'All six candidate timing pairs are slower. The two identical-code controls also drift, so the small one-host effect is not a precise causal estimate; it does not establish a gain.',
        'Every candidate Jitendex observation uses 22 borrowed content groups, no owned source bytes or adopted source cache, and zero deferred persistence/wait. The new cross-chunk overlap never activates.',
        'The candidate still executes changed common orchestration and promise bookkeeping on the fallback route; source/layout or host scheduling cost remains possible. These data cannot attribute the slowdown specifically to active dedup/compression overlap.',
        'A1 fails the predeclared 250ms coverage rule. This is an incomplete sampled-memory observation, not a semantic failure or evidence that the candidate uses more memory. Missing A1 maxima make the complete paired memory comparison unqualified; dropping or replacing it is not allowed.',
        'JMdict can still exercise the owned-source mechanism already demonstrated in local replay, but a queued result cannot supply evidence. This Jitendex result supports hold/no-PR now; no source change, new acquisition or relaxed gate is proposed.'
    ]
}
with output.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'output': str(output), 'all26ReceiptsExact': True, 'activationBObservations': len(candidate_activation),
                  'candidateTiming': timing, 'control': control, 'memoryAudit': memory_audit,
                  'phaseComparisons': {key: {k: v for k, v in value.items() if k != 'pairs'} for key, value in phase_comparisons.items()}}))
