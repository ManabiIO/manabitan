# Content-persistence pipeline: no useful complete-import gain

Frozen candidate `05907e30c83b4cc7cc8d653e069427a6141b0e85`, baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`, Actions run `46105215670`. Each corpus has its own fixed host/cohort; no times or controls are pooled. This readout recommends no PR or further acquisition; root owns final disposition.

| Corpus | Median B/A | Equal-work | Descriptive95% median interval | Same-code median | Deferred entries per B run | Memory |
| --- | ---: | ---: | --- | ---: | ---: | --- |
| jmdict | -0.226% | +0.339% | [-0.989%, +2.274%] | -0.574% | 12 | Coverage unqualified |
| jitendex | +2.282% | +3.693% | [+0.699%, +8.163%] | +3.576% | 0 | Coverage unqualified |
| vndb | -0.649% | -0.207% | [-1.296%, +1.379%] | -0.273% | 0 | Pass |

All three corpora completed all scheduled timing, warmups, identical-code controls, exhaustive-media checks and four separate memory imports. All 78 raw semantic receipts match the unchanged source-bound validator. Both actual extension ZIPs and complete member inventories were checked for each job. All 1,107 raw memory scans were independently recomputed. These semantic checks do not establish exhaustive byte equality of every persisted definition; the earlier separate Node full-output comparisons retain their own boundary.

The critical JMdict whole-import result is flat even though all 11 candidate observations enter the owned-source deferred route. Each has 12 deferrals, 101,143,281 adopted bytes, 101,143,985 owned parser bytes and zero borrowed results. Jitendex never enters it (22 borrowed groups, zero owned/adopted bytes). VNDB has owned parser bytes but zero adopted bytes and no deferrals. The two non-JM corpora therefore provide control observations for unchanged-path behavior, not proof of the overlap benefit.

The independent five-file source review confirms that the early sourceConsumed promise survives every wrapper through plain operation objects and separate promise adoption. There is no custom Promise property loss. However, the counter increments even when terminal completion already settled; all-block copy acknowledgement, completed prior jobs, record work and message delivery can narrow the remaining interval. Existing hosted counters do not measure useful overlap duration. No mechanistic time saving is inferred from route entry alone.

The JMdict median improvement is smaller than its same-code median and its equal-work ratio is positive. Jitendex has all six candidate pairs slower, but its wide same-code drift limits causal attribution. VNDB is flat. None establishes a worthwhile complete-import benefit, independently of the separate memory qualifications. The original and source-consumed Node cohorts remain separately retained unfavorable/inconclusive evidence; they are not pooled with browser timing.

Memory coverage fails for JMdict baseline A2 (266.882 ms gap) and Jitendex baseline A1 (350.393 ms), each above the frozen 250 ms limit. Corresponding maxima remain null; these are sampling-coverage failures rather than semantic failures or demonstrated memory regressions. All VNDB memory gates pass. All failed observations remain included, with no rerun, replacement or relaxed threshold.

Evidence is in `hosted-pipeline-{jmdict,jitendex,vndb}-46105215670`, `pipeline-jmdict-independent-review-1b47.{md,json}`, `pipeline-jitendex-independent-review-1b47.json` and `pipeline-final-readout-1b47.json`. The JMdict result is later than the sealed 06:46:37 addendum and is preserved separately.
