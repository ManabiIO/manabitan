# Pipeline JMdict: independent activation and source-signal review

The exact candidate enters the intended owned-source route, and the ordinary multi-block call chain preserves the early copy-completion signal. **The complete browser comparison nevertheless shows no useful whole-import gain.** Aggregate deferral counts do not establish how much work overlapped.

This is a bounded read-only review of the completed study, separate from the sealed 06:46:37 addendum. No source, test, benchmark, protocol or gate was changed. Detailed per-observation values and source hashes are in `pipeline-jmdict-independent-review-1b47.json`.

## Source and activation

Baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. Candidate: `05907e30c83b4cc7cc8d653e069427a6141b0e85`.

All five inspected runtime files match the candidate's recorded built-package member hashes. The content-block store, Zstd dispatcher and compression worker are byte-identical in A and B; only the database and metric registry differ.

All **11 B observations**, comprising six timing imports, two warmups, one exhaustive-media import and two memory imports, record exactly:

- 528,299 rows in 12 groups;
- 12 deferred-persistence entries;
- 101,143,281 adopted source-cache bytes;
- 101,143,985 independently owned parser bytes;
- zero borrowed-content results.

This establishes admission into the candidate route. The counter increments after the source-consumed wait even if terminal completion has already settled, so it is not an overlap-duration or successful-overlap counter.

## The early signal survives the wrappers

1. `zstd-term-content-compression-worker.js:60-69` prepares/copies the spans into retained Zstd memory, posts `source-consumed`, then calls the synchronous compression finish function.
2. `zstd-term-content.js:231-291,356-437` maintains distinct source-consumed and terminal promises per worker job. The source message resolves the former. The batch joins every block's copy acknowledgement.
3. `zstd-term-content.js:706-759` uses an async initialization IIFE whose result is a **plain operation object**. Separate `.then(({sourceConsumed: value}) => value)` and completion expressions adopt the two child promises. There is no custom Promise property for the async wrapper to strip.
4. `term-content-block-store.js:794-869` explicitly bridges the early compressor signal into its own source-consumed promise. The session wrapper at `134-148` spreads the plain object. The independent terminal promise at `917-965` joins compression and storage.
5. `dictionary-database.js:9803-9846` forwards the source promise unchanged. At `8706-8754`, the candidate waits for the record append and source consumption, then records its bounded terminal owner. Successor dedup can proceed before the predecessor is drained; successor writes/publication and finalization still join it.

The single-block path intentionally resolves source consumption only after compression. A pre-consumption worker failure can also fall back to synchronous packing/compression before resolution. These explicit conservative paths are different from losing a custom property through an async wrapper.

The batch copy barrier is inherently later than the first block's copy. Each worker finishes its current synchronous prepare/compress sequence before processing another job, so earlier jobs can already be compressed by the time the final copy acknowledgements arrive. Record work and message delivery can narrow the remaining interval further. This is a source-level limitation, not a measured attribution of the flat result.

The hosted summaries do not contain per-group source-consumed, successor-dedup-start and predecessor-completion timestamps. They therefore cannot quantify the useful overlap window. Earlier Node timelines remain evidence from a separate environment and are not substituted for missing hosted timestamps.

## Complete-import result

The existing 20 schedule records and original paired-statistic calculation independently reproduce:

| Statistic                              |      Candidate B/A | Identical-code C/A |
| -------------------------------------- | -----------------: | -----------------: |
| Paired median                          |            −0.226% |            −0.574% |
| Equal-work change                      |            +0.339% |            −0.573% |
| Descriptive 95% paired-median interval | [−0.989%, +2.274%] | [−0.675%, −0.472%] |
| Faster pairs                           |             4 of 6 |             2 of 2 |

This is flat evidence for the tested candidate, independently of the separate memory failure. It does not establish a useful gain or justify a pipeline PR. It also does not prove that every possible overlap design is ineffective.

Baseline memory observation A2 has a **266.882013 ms** covered-sample gap, above the unchanged **250 ms** limit. Its PSS/private maxima correctly remain null and the complete paired memory screen fails. That is insufficient sampling coverage, not a semantic failure or demonstrated memory regression.

## Audit boundary and disposition

`evidence/hosted-pipeline-jmdict-46105215670/independent-artifact-audit.json` is the separate setup-owned full audit of all 26 semantic receipts, both actual nested extension ZIPs and all 328 raw memory scans. This review references that receipt; it does not imply a second full archive audit was performed here.

Preserve the exact candidate, all observations, control drift and failed memory coverage. **No pipeline PR, source fix, rerun, new acquisition or relaxed gate follows from this result.**
