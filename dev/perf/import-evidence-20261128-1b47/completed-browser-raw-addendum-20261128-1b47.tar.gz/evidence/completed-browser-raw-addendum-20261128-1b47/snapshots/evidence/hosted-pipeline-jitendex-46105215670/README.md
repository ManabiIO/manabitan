# Pipeline Jitendex: complete timing; memory coverage unqualified

Frozen candidate `05907e30c83b4cc7cc8d653e069427a6141b0e85` versus baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. Actions run 46105215670, job 140867306558, completed 2026-11-28 06:20:09 UTC with failure.

## Exact outcome

All 20 declared warmup/timing/control observations completed, plus two exhaustive-media imports and four instrumented memory imports. All 26 raw browser reports have success status; all 26 canonical receipts were independently recomputed with the unchanged, source-verified validator and matched exactly. No semantic failures occurred. Package hashes and every package entry were independently verified; only the two declared JS entries differ.

The separate baseline A1 memory sample has a 350.393048 ms covered-import scan gap, above the frozen 250 ms limit. Its maxima are null by policy. The other three memory observations qualify; pair 2 alone is not a substitute for the required complete comparison. The job failed at final memory qualification, after all timing was retained. The raw 276 scans and bound markers reproduce this finding through the unchanged auditor. No retry, substituted observation, relaxed gate or product change was made.

## Complete timing

Six fresh-profile B/A pairs are all slower: paired median +2.282203806%, equal-work +3.692944279%, descriptive 95% paired-median interval [+0.698748459%,+8.162554320%], worst +11.592611728%. The two identical-code C/A pairs are −3.036770535% and +10.188438199%, median +3.575833832%. Their drift limits causal attribution and precision. The result provides no useful gain; it is not a qualified memory result or evidence of a precise product slowdown.

The pipeline gate is owned-source dependent. Independent activation review confirms all 11 candidate observations have 22 borrowed groups, zero owned parser bytes, zero adopted source bytes and zero deferred persistence/wait. A complete-import timing on an inactive path must not be described as a measured overlap benefit.

## Artifact preservation and independent audit

Artifact 15252160244 contains 206 members, 34,974,199 bytes; SHA-256 `2cc1f7be18bd2a9afb1145020c6f854741762cdc863150f4cc15bc29cf430aa4`. Complete ZIP and non-package/non-HTML extraction are in the task-owned `/home/agent/manabitan-import-capture-1b47/hosted-artifacts` directory; metadata gives the GitHub artifact URL and expiry. No signed temporary download URL is stored here.

`independent-artifact-audit.json` preserves every member hash, both complete package inventories, all 26 receipt checks,276-scan audit and exact independent statistic recomputation. `job-140867306558.log` is the complete job log. Emitted plans, source identities, observations, analysis, memory records and statuses are preserved unchanged. `../audit-hosted-import-artifact-1b47.py` reconstructs the audit from the pinned archive and baseline validator sources. No new benchmark was run by this audit.
