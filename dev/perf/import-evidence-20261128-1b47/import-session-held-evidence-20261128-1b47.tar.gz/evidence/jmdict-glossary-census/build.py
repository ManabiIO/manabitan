import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / 'jmdict-native-census'
REPO = ROOT.parent.parent / 'manabitan'
CLANG = Path('/tmp/manabitan-native-9bb32/native-toolchain/bin/clang')
LINKER = CLANG.with_name('wasm-ld')
old_manifest = json.loads((PREVIOUS / 'build-manifest.json').read_text())
source = (PREVIOUS / 'instrumented.c').read_text()
assert hashlib.sha256(source.encode()).hexdigest() == old_manifest['sourceSha256']
labels = old_manifest['counterLabels'] + [
    'glossaryLookbackNone', 'glossaryLookbackOne', 'glossaryLookbackFour',
    'existingGlossaryReuseCalls', 'existingGlossaryReuseCandidates',
    'existingGlossaryReuseCandidateBytes', 'existingGlossaryReuseBoundsRejected',
    'existingGlossaryReuseTailRejected', 'existingGlossaryReuseMiddleRejected',
    'existingGlossaryReuseFullCompared', 'existingGlossaryReuseFullBytes',
    'existingGlossaryReuseFullRejected', 'existingGlossaryReuseMatches',
    'shortUnadmittedCandidates', 'shortUnadmittedCandidateBytes',
    'shortUnadmittedBoundsRejected', 'shortUnadmittedTailRejected',
    'shortUnadmittedMiddleRejected', 'shortUnadmittedFullCompared',
    'shortUnadmittedFullBytes', 'shortUnadmittedFullRejected',
    'shortUnadmittedMatches', 'shortUnadmittedMatchedBytes',
    'shortUnadmittedMatchedCompositeTokens', 'shortUnadmittedMatchedCompositeBytes',
    'shortUnadmittedMatchedContentEqual', 'shortUnadmittedMatchedContentDifferent',
]
gates = ['ReadingLength', 'ExpressionLength', 'ReadingExact', 'ExpressionExact',
         'EitherKeyExact', 'RulesAndDefinitionExact']
for gate in gates:
    labels += [f'shortGate{gate}Candidates', f'shortGate{gate}Matches']
for bucket in ['Under64', '64To127', '128To255', '256To511']:
    labels += [f'short{bucket}Candidates', f'short{bucket}Matches',
               f'short{bucket}MatchedCompositeTokens', f'short{bucket}MatchedCompositeBytes']
for bucket in ['Under64', '64To127', '128To255', '256To511', '512Plus']:
    labels += [f'recentWithoutWitness{bucket}Rows', f'recentWithoutWitness{bucket}Bytes',
               f'recentWithoutWitness{bucket}CompositeTokens', f'recentWithoutWitness{bucket}CompositeBytes']
for distance in range(1, 5):
    labels += [f'recentWithoutWitnessDistance{distance}Rows', f'recentWithoutWitnessDistance{distance}Bytes']
indexes = {label: index for index, label in enumerate(labels)}


def once(text, old, new):
    assert text.count(old) == 1, (text.count(old), old)
    return text.replace(old, new, 1)


def counter(label):
    return f'parser_probe_counters[{indexes[label]}]'


source = once(source, 'static uint32_t parser_probe_counters[40];',
              f'static uint32_t parser_probe_counters[{len(labels)}];\nstatic uint32_t parser_probe_short_match;')
source = once(source, 'probe < 40u', f'probe < {len(labels)}u')
start = source.index('static int reuse_validated_glossary(')
end = source.index('\nstatic inline int next_format3_field', start)
reuse = source[start:end]
reuse = once(reuse, '    const uint32_t first =',
             f'    ++{counter("existingGlossaryReuseCalls")};\n    const uint32_t first =')
reuse = once(reuse,
    '        if (n == 0u || n > end - start || src[start] != src[p]) { continue; }',
    f'        ++{counter("existingGlossaryReuseCandidates")};\n'
    f'        {counter("existingGlossaryReuseCandidateBytes")} += n;\n'
    f'        if (n == 0u || n > end - start || src[start] != src[p]) {{ ++{counter("existingGlossaryReuseBoundsRejected")}; continue; }}')
reuse = once(reuse,
    '        if (!content_bytes_equal_between(src, start + n - sample, src, p + n - sample, sample) ||\n'
    '            !content_bytes_equal_between(src, start + (n - sample) / 2u, src, p + (n - sample) / 2u, sample) ||\n'
    '            !content_bytes_equal_between(src, start, src, p, n)) { continue; }',
    f'        if (!content_bytes_equal_between(src, start + n - sample, src, p + n - sample, sample)) {{ ++{counter("existingGlossaryReuseTailRejected")}; continue; }}\n'
    f'        if (!content_bytes_equal_between(src, start + (n - sample) / 2u, src, p + (n - sample) / 2u, sample)) {{ ++{counter("existingGlossaryReuseMiddleRejected")}; continue; }}\n'
    f'        ++{counter("existingGlossaryReuseFullCompared")};\n'
    f'        {counter("existingGlossaryReuseFullBytes")} += n;\n'
    f'        if (!content_bytes_equal_between(src, start, src, p, n)) {{ ++{counter("existingGlossaryReuseFullRejected")}; continue; }}\n'
    f'        ++{counter("existingGlossaryReuseMatches")};')
source = source[:start] + reuse + source[end:]

# Census-only speculative probes. They do not alter row metadata, acceptance,
# normal admission/budget, content witnesses, or published parser output.
helper = '''
static void parser_probe_unadmitted_short_glossary(
    const uint8_t* src, uint32_t end, uint32_t start,
    const TermRowMeta* rows, uint32_t row_count, const TermRowMeta* meta,
    uint32_t lookback
) {
    if (lookback != 0u || row_count == 0u) { return; }
    const TermRowMeta* prior = &rows[row_count - 1u];
    const uint32_t n = prior->glossary_length;
    const uint32_t p = prior->glossary_start;
    if (n == 0u || n >= VALIDATED_GLOSSARY_REUSE_MIN_PREVIOUS_BYTES) { return; }
    const uint32_t bucket = n < 64u ? 0u : n < 128u ? 1u : n < 256u ? 2u : 3u;
    const uint32_t reading_length = meta->reading_length == prior->reading_length;
    const uint32_t expression_length = meta->expression_length == prior->expression_length;
    const uint32_t reading_exact = reading_length && content_bytes_equal_between(
        src, meta->reading_start, src, prior->reading_start, meta->reading_length);
    const uint32_t expression_exact = expression_length && content_bytes_equal_between(
        src, meta->expression_start, src, prior->expression_start, meta->expression_length);
    const uint32_t tags_rules_exact = meta->rules_length == prior->rules_length &&
        meta->definition_tags_length == prior->definition_tags_length &&
        content_bytes_equal_between(src, meta->rules_start, src, prior->rules_start, meta->rules_length) &&
        content_bytes_equal_between(src, meta->definition_tags_start, src, prior->definition_tags_start, meta->definition_tags_length);
    const uint32_t gates[6] = {reading_length, expression_length, reading_exact, expression_exact,
        reading_exact || expression_exact, tags_rules_exact};
    ++SHORT_CANDIDATES;
    SHORT_CANDIDATE_BYTES += n;
    ++parser_probe_counters[BUCKET_BASE + bucket * 4u];
    for (uint32_t gate = 0u; gate < 6u; ++gate) {
        parser_probe_counters[GATE_BASE + gate * 2u] += gates[gate];
    }
    if (start >= end || n > end - start || src[start] != src[p]) { ++SHORT_BOUNDS_REJECTED; return; }
    const uint32_t sample = n < 8u ? n : 8u;
    if (!content_bytes_equal_between(src, start + n - sample, src, p + n - sample, sample)) { ++SHORT_TAIL_REJECTED; return; }
    if (!content_bytes_equal_between(src, start + (n - sample) / 2u, src, p + (n - sample) / 2u, sample)) { ++SHORT_MIDDLE_REJECTED; return; }
    ++SHORT_FULL_COMPARED;
    SHORT_FULL_BYTES += n;
    if (!content_bytes_equal_between(src, start, src, p, n)) { ++SHORT_FULL_REJECTED; return; }
    ++SHORT_MATCHES;
    SHORT_MATCHED_BYTES += n;
    ++parser_probe_counters[BUCKET_BASE + bucket * 4u + 1u];
    for (uint32_t gate = 0u; gate < 6u; ++gate) {
        parser_probe_counters[GATE_BASE + gate * 2u + 1u] += gates[gate];
    }
    parser_probe_short_match = 1u;
}
'''
for key, label in {
    'SHORT_CANDIDATES': 'shortUnadmittedCandidates',
    'SHORT_CANDIDATE_BYTES': 'shortUnadmittedCandidateBytes',
    'SHORT_BOUNDS_REJECTED': 'shortUnadmittedBoundsRejected',
    'SHORT_TAIL_REJECTED': 'shortUnadmittedTailRejected',
    'SHORT_MIDDLE_REJECTED': 'shortUnadmittedMiddleRejected',
    'SHORT_FULL_COMPARED': 'shortUnadmittedFullCompared',
    'SHORT_FULL_BYTES': 'shortUnadmittedFullBytes',
    'SHORT_FULL_REJECTED': 'shortUnadmittedFullRejected',
    'SHORT_MATCHES': 'shortUnadmittedMatches',
    'SHORT_MATCHED_BYTES': 'shortUnadmittedMatchedBytes',
}.items():
    helper = helper.replace(key, counter(label))
helper = helper.replace('BUCKET_BASE', str(indexes['shortUnder64Candidates']) + 'u')
helper = helper.replace('GATE_BASE', str(indexes['shortGateReadingLengthCandidates']) + 'u')
source = once(source, '\nstatic inline int next_format3_field', helper + '\nstatic inline int next_format3_field')
source = once(source, '    meta->glossary_requires_text_normalization = 0u;\n    if (\n',
    '    meta->glossary_requires_text_normalization = 0u;\n'
    '    parser_probe_unadmitted_short_glossary(src, len, i, prior_rows, prior_count, meta, glossary_lookback);\n    if (\n')

start = source.index('int32_t parse_and_encode_term_bank_token_binary_dedup(')
end = source.index('\n/* Segment compaction consumes', start)
fused = source[start:end]
fused = once(fused, '        uint32_t key_escape_mask;',
    f'        ++parser_probe_counters[{indexes["glossaryLookbackNone"]}u + (glossary_lookback == 0u ? 0u : glossary_lookback == 1u ? 1u : 2u)];\n'
    '        parser_probe_short_match = 0u;\n'
    '        const uint32_t probe_tokens_before = parser_probe_counters[32];\n'
    '        const uint32_t probe_bytes_before = parser_probe_counters[31];\n'
    '        uint32_t key_escape_mask;')
fused = once(fused, '        const TermRowMeta* parsed_row = &rows[row_count];',
    '        const TermRowMeta* parsed_row = &rows[row_count];\n'
    '        const uint32_t probe_scanned_tokens = parser_probe_counters[32] - probe_tokens_before;\n'
    '        const uint32_t probe_scanned_bytes = parser_probe_counters[31] - probe_bytes_before;\n'
    '        if (parser_probe_short_match) {\n'
    f'            {counter("shortUnadmittedMatchedCompositeTokens")} += probe_scanned_tokens;\n'
    f'            {counter("shortUnadmittedMatchedCompositeBytes")} += probe_scanned_bytes;\n'
    '            const uint32_t n = parsed_row->glossary_length;\n'
    '            const uint32_t bucket = n < 64u ? 0u : n < 128u ? 1u : n < 256u ? 2u : 3u;\n'
    f'            parser_probe_counters[{indexes["shortUnder64Candidates"]}u + bucket * 4u + 2u] += probe_scanned_tokens;\n'
    f'            parser_probe_counters[{indexes["shortUnder64Candidates"]}u + bucket * 4u + 3u] += probe_scanned_bytes;\n'
    '        }')
fused = once(fused, '        if (recent_match != 0xffffffffu) {\n            ++parser_probe_counters[26];',
    '        if (parser_probe_short_match) {\n'
    '            const int same_adjacent_content = raw_term_content_tokens_equal(src, parsed_row, &rows[row_count - 1u], 1);\n'
    f'            ++parser_probe_counters[{indexes["shortUnadmittedMatchedContentEqual"]}u + (same_adjacent_content ? 0u : 1u)];\n'
    '        }\n'
    '        if (recent_match != 0xffffffffu) {\n'
    '            if (glossary_witness == 0xffffffffu) {\n'
    '                const uint32_t n = parsed_row->glossary_length;\n'
    '                const uint32_t bucket = n < 64u ? 0u : n < 128u ? 1u : n < 256u ? 2u : n < 512u ? 3u : 4u;\n'
    f'                const uint32_t base = {indexes["recentWithoutWitnessUnder64Rows"]}u + bucket * 4u;\n'
    '                ++parser_probe_counters[base];\n'
    '                parser_probe_counters[base + 1u] += n;\n'
    '                parser_probe_counters[base + 2u] += probe_scanned_tokens;\n'
    '                parser_probe_counters[base + 3u] += probe_scanned_bytes;\n'
    '                const uint32_t distance = row_count - recent_match;\n'
    '                if (distance <= 4u) {\n'
    f'                    ++parser_probe_counters[{indexes["recentWithoutWitnessDistance1Rows"]}u + (distance - 1u) * 2u];\n'
    f'                    parser_probe_counters[{indexes["recentWithoutWitnessDistance1Bytes"]}u + (distance - 1u) * 2u] += n;\n'
    '                }\n'
    '            }\n'
    '            ++parser_probe_counters[26];')
source = source[:start] + fused + source[end:]
source_path = ROOT / 'instrumented.c'
wasm_path = ROOT / 'instrumented.wasm'
source_path.write_text(source)
manifest = json.loads((REPO / 'dev/data/dictionary-wasm/manifest.json').read_text())
target = next(item for item in manifest['targets'] if item['name'] == 'term-bank-parser.wasm')
command = [str(CLANG), f'-fuse-ld={LINKER}', *target['arguments'], '-o', str(wasm_path), str(source_path),
           str(REPO / 'ext/js/dictionary/wasm/term-bank-inflate.c')]
subprocess.run(command, check=True)
report = {
    'scope': 'Instrumented exact-baseline glossary work census only. Extra speculative comparisons never alter parser admission, witnesses, metadata, or output. Counters change cost; no timing claim.',
    'baseline': old_manifest['baseline'], 'previousManifest': str(PREVIOUS / 'build-manifest.json'),
    'sourcePath': str(source_path), 'sourceSha256': hashlib.sha256(source.encode()).hexdigest(),
    'wasmPath': str(wasm_path), 'wasmSha256': hashlib.sha256(wasm_path.read_bytes()).hexdigest(),
    'wasmBytes': wasm_path.stat().st_size, 'counterExport': 'parser_probe_snapshot',
    'counterWordCount': len(labels), 'counterLabels': labels,
    'compiler': subprocess.check_output([str(CLANG), '--version'], text=True).strip(), 'command': command,
}
(ROOT / 'build-manifest.json').write_text(json.dumps(report, indent=2) + '\n')
runner = (PREVIOUS / 'run-census.mjs').read_text()
runner = runner.replace('assert.equal(manifest.counterWordCount, 40);', f'assert.equal(manifest.counterWordCount, {len(labels)});')
runner = runner.replace('assert.equal(manifest.counterLabels.length, 40);', f'assert.equal(manifest.counterLabels.length, {len(labels)});')
(ROOT / 'run-census.mjs').write_text(runner)
print(json.dumps({key: report[key] for key in ('sourceSha256', 'wasmSha256', 'wasmBytes', 'counterWordCount')}))
