/* SPDX-License-Identifier: GPL-3.0-or-later */
/* eslint @stylistic/semi: ["error", "never"] */

import {readFile} from 'node:fs/promises'
import {crc32, deflateRawSync} from 'node:zlib'
import {beforeAll, describe, expect, test, vi} from 'vitest'
import {DictionarySourceIntegrityError} from '../ext/js/dictionary/dictionary-source-integrity-error.js'
import {encodePersistedTermLookupIndexFromPreinternedPlan} from '../ext/js/dictionary/term-lookup-index.js'
import {
    consumeLastTermBankWasmParseProfile,
    inflateCompressedTermBankSourcesWasm,
    parseTermBankWithWasmColumnChunks,
    setTermBankWasmModule,
} from '../ext/js/dictionary/term-bank-wasm-parser.js'

const encoder = new TextEncoder()
const decoder = new TextDecoder()
const definition = [{type: 'structured-content', content: {tag: 'span', content: 'shared definition'}}]
const forms = ['first spelling', 'second spelling']

beforeAll(async () => {
    setTermBankWasmModule(await WebAssembly.compile(await readFile(new URL('../ext/lib/term-bank-parser.wasm', import.meta.url))))
})

/**
 * @param {string} expression
 * @param {string} reading
 * @param {unknown} glossary
 * @param {number} [index]
 * @returns {unknown[]}
 */
function row(expression, reading, glossary, index = 0) {
    return [expression, reading, 'noun', '', index, glossary, 100 + index, 'common']
}

/**
 * @param {string} key
 * @param {unknown} glossary
 * @returns {string}
 */
function rawRow(key, glossary) {
    return `[${key},"","noun","",0,${JSON.stringify(glossary)},100,"common"]`
}

/**
 * @param {string[]} banks
 * @returns {import('../ext/js/dictionary/term-bank-wasm-parser.js').CompressedTermBankSource[]}
 */
function compressed(banks) {
    return banks.map((bank) => {
        const source = encoder.encode(bank)
        const bytes = new Uint8Array(deflateRawSync(source))
        return {bytes, compressionMethod: 8, compressedSize: bytes.length, uncompressedSize: source.length, signature: crc32(source)}
    })
}

/**
 * Capture all observable row fields and lookup bytes before native memory is
 * reused. Disabled glossary reuse independently scans each current glossary.
 * @param {string[]} banks
 * @param {{reuse?: boolean, strict?: boolean, preload?: boolean, reuseCrc?: boolean}} [settings]
 * @returns {Promise<{rows: Array<Record<string, unknown>>, lookup: number[], profile: NonNullable<ReturnType<typeof consumeLastTermBankWasmParseProfile>>, preloaded: import('../ext/js/dictionary/term-bank-wasm-parser.js').PreloadedTermBankSource|undefined}>}
 */
async function parse(banks, {reuse = true, strict = true, preload = false, reuseCrc = false} = {}) {
    // Exercise the ordinary multi-bank fused route even for small fixtures.
    const sourceBanks = [...banks, '[]']
    /** @type {import('../ext/js/dictionary/term-bank-wasm-parser.js').TermBankColumnParserOptions} */
    const options = {
        computeContentHashes: true,
        emitContentSlab: true,
        emitTokenBinaryContent: true,
        emitTermByteLists: false,
        singleChunk: true,
        useNativeStringPlan: true,
        validateGlossaryTypes: strict,
        mediaHintFastScan: true,
        experimentalNativeEscapedKeys: true,
        experimentalValidatedGlossaryReuse: reuse,
        experimentalTermBankSpans: true,
    }
    const preloaded = preload ? await inflateCompressedTermBankSourcesWasm(compressed(sourceBanks), options, reuseCrc) : undefined
    /** @type {Array<Record<string, unknown>>} */
    const rows = []
    /** @type {number[]} */
    const lookup = []
    await parseTermBankWithWasmColumnChunks(preloaded ? new Uint8Array() : sourceBanks.map((bank) => encoder.encode(bank)), 3, (chunk) => {
        const plan = chunk.termRecordPreinternedPlan
        const offsets = plan.stringOffsets
        const meta = chunk.contentMetaList
        const content = chunk.contentBytesBuffer
        if (!(offsets instanceof Uint32Array) || !(meta instanceof Uint32Array) || !(content instanceof Uint8Array)) {
            throw new Error('Missing complete native output')
        }
        const strings = Array.from(plan.stringLengths, (length, index) => decoder.decode(plan.stringsBuffer.subarray(offsets[index], offsets[index] + length)))
        for (let index = 0; index < chunk.rowCount; ++index) {
            const start = (chunk.contentBytesBaseOffset ?? 0) + meta[index * 4]
            rows.push({
                expression: strings[plan.expressionIndexes[index]],
                reading: strings[plan.readingIndexes[index]],
                equality: chunk.readingEqualsExpressionList[index],
                score: chunk.scoreList[index],
                sequence: chunk.sequenceList[index],
                content: [...content.subarray(start, start + meta[index * 4 + 1])],
                hashes: [...meta.subarray(index * 4 + 2, index * 4 + 4)],
                media: chunk.mediaRows.filter((entry) => entry.index === index).map((entry) => entry.row.glossaryJson),
            })
        }
        lookup.push(...encodePersistedTermLookupIndexFromPreinternedPlan(plan, chunk.readingEqualsExpressionList, chunk.sequenceList, chunk.rowCount))
    }, 2048, {...options, preloadedSource: preloaded})
    const profile = consumeLastTermBankWasmParseProfile()
    if (!profile) { throw new Error('Missing native profile') }
    expect(profile.fusedParseAttempts).toBe(1)
    return {rows, lookup, profile, preloaded}
}

describe('bounded glossary reuse within proven term-key runs', () => {
    test.each([false, true])('reuses alternating short definitions and forms with exact row and lookup parity; preload=%s', async (preload) => {
        const source = JSON.stringify([
            row('甲', 'こう', definition, 1),
            row('甲', 'こう', forms, 2),
            row('乙', 'こう', definition, 3),
            row('乙', 'こう', forms, 4),
        ])
        const actual = await parse([source], {preload})
        const ordinary = await parse([source], {reuse: false, preload})
        expect(actual.rows).toStrictEqual(ordinary.rows)
        expect(actual.lookup).toStrictEqual(ordinary.lookup)
        expect(actual.profile.validatedGlossaryReuseCount).toBe(2)
        expect(actual.profile.fusedParseFallbacks).toBe(0)
        expect(ordinary.profile.validatedGlossaryReuseCount).toBe(0)
    })

    test('keeps the generic row path and explicit disabled-reuse route independent', async () => {
        const source = JSON.stringify([row('same', 'reading', definition), row('same', 'reading', forms), row('same', 'reading', definition)])
        const strict = await parse([source])
        const generic = await parse([source], {strict: false})
        expect(strict.rows).toStrictEqual(generic.rows)
        expect(strict.lookup).toStrictEqual(generic.lookup)
        expect(strict.profile.validatedGlossaryReuseCount).toBe(1)
        expect(generic.profile.validatedGlossaryReuseCount).toBe(0)
    })

    test('does not treat empty raw readings of different expressions as a shared key', async () => {
        const source = JSON.stringify([
            row('first', '', definition),
            row('second', '', forms),
            row('third', '', definition),
            row('fourth', '', forms),
        ])
        const actual = await parse([source])
        expect(actual.rows).toStrictEqual((await parse([source], {reuse: false})).rows)
        expect(actual.profile.validatedGlossaryReuseCount).toBe(0)
    })

    test('preserves empty and explicit expression-equal readings across an alternating run', async () => {
        const source = JSON.stringify([
            row('同じ', '', definition),
            row('同じ', '同じ', forms),
            row('同じ', '', definition),
            row('同じ', '同じ', forms),
        ])
        const actual = await parse([source])
        expect(actual.rows).toStrictEqual((await parse([source], {reuse: false})).rows)
        expect(actual.rows.map((value) => value.equality)).toStrictEqual([1, 1, 1, 1])
        expect(actual.profile.validatedGlossaryReuseCount).toBe(2)
    })

    test.each([
        {name: '31 ASCII bytes', token: JSON.stringify('a'.repeat(31)), hits: 2},
        {name: '32 ASCII bytes', token: JSON.stringify('a'.repeat(32)), hits: 2},
        {name: '33 ASCII bytes', token: JSON.stringify('a'.repeat(33)), hits: 0},
        {name: '32 UTF-8 bytes', token: JSON.stringify('日'.repeat(10) + 'ab'), hits: 2},
        {name: '33 UTF-8 bytes', token: JSON.stringify('日'.repeat(11)), hits: 0},
        {name: '32 escaped raw bytes', token: `"${String.raw`\u0061`.repeat(5)}ab"`, hits: 2},
        {name: '33 escaped raw bytes', token: `"${String.raw`\u0061`.repeat(5)}abc"`, hits: 0},
    ])('retains the existing adjacent-key bound: $name', async ({token, hits}) => {
        const source = `[${[definition, forms, definition, forms].map((glossary) => rawRow(token, glossary)).join(',')}]`
        const actual = await parse([source])
        const ordinary = await parse([source], {reuse: false})
        expect(actual.rows).toStrictEqual(ordinary.rows)
        expect(actual.lookup).toStrictEqual(ordinary.lookup)
        expect(actual.profile.validatedGlossaryReuseCount).toBe(hits)
    })

    test('stops after four failed rows in one key run and admits again only after a new run', async () => {
        // All samples agree; the changed byte is outside the tail/middle
        // rejects. Full byte equality must reject each unique glossary.
        const glossaries = Array.from({length: 5}, (_, index) => [`${'x'.repeat(23)}${index}${'x'.repeat(160)}`])
        const source = JSON.stringify([
            ...glossaries.map((glossary) => row('same', 'reading', glossary)),
            row('same', 'reading', glossaries[4]),
            row('different', 'new-reading', definition),
            row('different', 'new-reading', definition),
        ])
        const actual = await parse([source])
        expect(actual.rows).toStrictEqual((await parse([source], {reuse: false})).rows)
        // The repeated fifth glossary arrives after the key budget is spent.
        expect(actual.profile.validatedGlossaryReuseCount).toBe(1)
    })

    test('retains the four-row witness window even when the same key continues', async () => {
        const source = JSON.stringify([
            row('same', 'reading', definition),
            row('same', 'reading', forms),
            row('same', 'reading', ['third']),
            row('same', 'reading', ['fourth']),
            // This in-window hit refreshes the budget before distance five.
            row('same', 'reading', forms),
            row('same', 'reading', definition),
        ])
        const actual = await parse([source])
        expect(actual.rows).toStrictEqual((await parse([source], {reuse: false})).rows)
        expect(actual.profile.validatedGlossaryReuseCount).toBe(1)
    })

    test('does not let a key-only hit admit unrelated following keys', async () => {
        const source = JSON.stringify([
            row('same', 'reading', definition),
            row('same', 'reading', definition),
            row('different', 'other-reading', definition),
        ])
        const actual = await parse([source])
        expect(actual.rows).toStrictEqual((await parse([source], {reuse: false})).rows)
        expect(actual.profile.validatedGlossaryReuseCount).toBe(1)
    })

    test.each([
        {label: 'invalid escape', glossary: String.raw`["\q"]`, tail: '100,"common"]'},
        {label: 'trailing comma', glossary: '[1,]', tail: '100,"common"]'},
        {label: 'missing required field', glossary: '[{"type":"structured-content"}]', tail: '100,"common"]'},
        {label: 'bad sequence after exact glossary', glossary: JSON.stringify(definition), tail: '01,"common"]'},
        {label: 'extra field after exact glossary', glossary: JSON.stringify(definition), tail: '100,"common",0]'},
    ])('rejects a malformed row after key proof: $label', async ({glossary, tail}) => {
        const prelude = JSON.stringify([row('same', 'reading', definition), row('same', 'reading', forms)]).slice(0, -1)
        const source = `${prelude},["same","reading","noun","",0,${glossary},${tail}]`
        await expect(parse([source])).rejects.toThrow()
        await expect(parse([source], {reuse: false})).rejects.toThrow()
        const valid = JSON.stringify([row('same', 'reading', definition), row('same', 'reading', definition)])
        expect((await parse([valid])).profile.validatedGlossaryReuseCount).toBe(1)
    })

    test('does not carry a proof across independent parser calls', async () => {
        const source = JSON.stringify([row('same', 'reading', definition), row('same', 'reading', definition)])
        expect((await parse([source])).profile.validatedGlossaryReuseCount).toBe(1)
        expect((await parse([JSON.stringify([row('same', 'reading', definition)])])).profile.validatedGlossaryReuseCount).toBe(0)
    })

    test('preserves media and text-normalization hints together with independent tags and rules', async () => {
        const glossary = [{type: 'image', path: 'image.webp'}, {type: 'text', text: ' one\n two '}]
        const first = row('same', 'reading', glossary)
        const second = row('same', 'reading', glossary)
        second[2] = 'other-tag'
        second[3] = 'v1'
        second[7] = 'other-term-tag'
        const source = JSON.stringify([first, second])
        const actual = await parse([source])
        expect(actual.rows).toStrictEqual((await parse([source], {reuse: false})).rows)
        expect(actual.rows[0].content).not.toStrictEqual(actual.rows[1].content)
        expect(actual.profile.validatedGlossaryReuseCount).toBe(1)
    })

    test('keeps separate bank bounds, empty banks, and cross-bank witnesses', async () => {
        const banks = [JSON.stringify([row('same', 'reading', definition)]),
            '[]',
            JSON.stringify([row('same', 'reading', forms), row('same', 'reading', definition)]),
            JSON.stringify([row('same', 'reading', forms)])]
        const actual = await parse(banks, {preload: true})
        expect(actual.rows).toStrictEqual((await parse(banks, {preload: true, reuse: false})).rows)
        expect(actual.profile.validatedGlossaryReuseCount).toBe(2)
        const truncated = `[["same","reading","noun","",0,${JSON.stringify(definition).slice(0, -1)}`
        await expect(parse([...banks.slice(0, 3), truncated, banks[3]], {preload: true})).rejects.toThrow()
    })

    test('verifies independent bank CRCs before publishing new short-glossary witnesses', async () => {
        const values = [row('same', 'reading', definition), row('same', 'reading', forms)]
        // Padding exercises the ordinary 4MiB deferred-CRC gate without
        // enlarging glossaries or changing any production admission setting.
        const banks = [' '.repeat(4 * 1024 * 1024) + JSON.stringify(values), JSON.stringify(values)]
        const actual = await parse(banks, {preload: true, reuseCrc: true})
        const ordinary = await parse(banks, {preload: true, reuse: false})
        expect(actual.rows).toStrictEqual(ordinary.rows)
        expect(actual.preloaded?.crcSignaturesPtr).toBeGreaterThan(0)
        expect(actual.preloaded?.crcVerified).toBe(true)
        expect(actual.preloaded?.crcReusedGlossaryCount).toBe(2)
        const bad = compressed(banks)
        bad[1].signature = (bad[1].signature ^ 1) >>> 0
        const options = {validateGlossaryTypes: true, singleChunk: true, emitContentSlab: true, emitTokenBinaryContent: true}
        const preloadedSource = await inflateCompressedTermBankSourcesWasm(bad, options, true)
        expect(preloadedSource.crcSignaturesPtr).toBeGreaterThan(0)
        const sink = vi.fn()
        await expect(parseTermBankWithWasmColumnChunks(new Uint8Array(), 3, sink, 2048, {...options, preloadedSource})).rejects.toBeInstanceOf(DictionarySourceIntegrityError)
        expect(sink).not.toHaveBeenCalled()
    })
})
