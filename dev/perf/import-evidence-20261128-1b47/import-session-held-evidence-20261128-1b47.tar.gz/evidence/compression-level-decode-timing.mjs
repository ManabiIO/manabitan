/* SPDX-License-Identifier: GPL-3.0-or-later */
// Separate lookup-decode component screen; no compression timing is pooled here.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {appendFile, readFile, writeFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {installFileFetch} from './node-sink-file-fetch.mjs';

const [sourcePath, censusPath, independentPath, outputPath] = process.argv.slice(2);
assert(sourcePath && censusPath && independentPath && outputPath,
    'Usage: node compression-level-decode-timing.mjs SOURCE CENSUS INDEPENDENT_DECODE OUTPUT_JSON');
const root = resolve(sourcePath);
const censusBytes = await readFile(censusPath);
const census = JSON.parse(censusBytes);
const independent = JSON.parse(await readFile(independentPath, 'utf8'));
const sha = (value) => createHash('sha256').update(value).digest('hex');
assert.equal(census.complete, true);
assert.equal(independent.complete, true);
assert.equal(independent.censusSha256, sha(censusBytes));
assert.equal(census.sourceCommit, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
assert.equal(census.totals.B.withinProspectiveTwoPercentCeiling, true);
for (const [file, expectedHash] of Object.entries(census.codecSourceFiles)) {
    assert.equal(sha(await readFile(join(root, file))), expectedHash, file);
}
const frames = [];
for (const frame of census.frames) {
    const byLevel = {};
    for (const arm of ['A', 'B']) {
        const encoded = new Uint8Array(await readFile(frame.outputs[arm].path));
        assert.equal(sha(encoded), frame.outputs[arm].sha256);
        byLevel[arm] = encoded;
    }
    frames.push({metadata: frame, byLevel});
}
const dictionary = new Uint8Array(await readFile(join(root, 'ext/lib/zstd-dicts/jmdict.zdict')));
assert.equal(sha(dictionary), census.dictionarySha256);
const jsonLinesPath = `${outputPath}.observations.jsonl`;
await writeFile(jsonLinesPath, '', {flag: 'wx'});
installFileFetch();
const originalInstantiate = WebAssembly.instantiate;
const originalStreaming = WebAssembly.instantiateStreaming;
let loadingArm = null;
const memories = new Map();
function observeInstance(result) {
    const instance = result instanceof WebAssembly.Instance ? result : result.instance;
    if (loadingArm !== null && instance) {
        const found = Object.values(instance.exports).filter((value) => value instanceof WebAssembly.Memory);
        assert.equal(found.length, 1);
        memories.set(loadingArm, found[0]);
    }
    return result;
}
WebAssembly.instantiate = async (...args) => observeInstance(await Reflect.apply(originalInstantiate, WebAssembly, args));
WebAssembly.instantiateStreaming = async (...args) => observeInstance(await Reflect.apply(originalStreaming, WebAssembly, args));
const arms = {};
try {
    for (const name of ['A', 'B', 'C']) {
        loadingArm = name;
        const codec = await import(`${pathToFileURL(join(root, 'ext/lib/zstd-wasm.js')).href}?decode-level-probe=${name}`);
        await codec.init(pathToFileURL(join(root, 'ext/lib/zstd.wasm')).href);
        assert(memories.has(name));
        const context = codec.createDCtx();
        assert(context > 0);
        arms[name] = {name, level: name === 'B' ? -2 : -1, codec, context, memory: memories.get(name)};
    }
} finally {
    loadingArm = null;
    WebAssembly.instantiate = originalInstantiate;
    WebAssembly.instantiateStreaming = originalStreaming;
}
assert.equal(new Set(memories.values()).size, 3);
const orders = [['A', 'B', 'C'], ['B', 'C', 'A'], ['C', 'A', 'B'],
    ['C', 'B', 'A'], ['B', 'A', 'C'], ['A', 'C', 'B']];
const observations = [];
const warmups = [];
async function observe(arm, block, orderIndex, excluded = false) {
    let decodeWallMs = 0;
    let decodeCpuMs = 0;
    let maxWasmCapacityBytes = arm.memory.buffer.byteLength;
    const measurements = [];
    for (const {metadata, byLevel} of frames) {
        const compressed = byLevel[arm.level === -2 ? 'B' : 'A'].subarray(12);
        const capacityBefore = arm.memory.buffer.byteLength;
        const cpuBefore = process.cpuUsage();
        const before = performance.now();
        const raw = arm.codec.decompressUsingDict(arm.context, compressed, dictionary,
            {defaultHeapSize: metadata.expectedRawBytes, maxOutputSize: metadata.expectedRawBytes});
        const wallMs = performance.now() - before;
        const cpu = process.cpuUsage(cpuBefore);
        const cpuMs = (cpu.user + cpu.system) / 1000;
        assert.equal(raw.byteLength, metadata.expectedRawBytes);
        assert.equal(sha(raw), metadata.rawSha256);
        const capacityAfter = arm.memory.buffer.byteLength;
        decodeWallMs += wallMs;
        decodeCpuMs += cpuMs;
        maxWasmCapacityBytes = Math.max(maxWasmCapacityBytes, capacityAfter);
        measurements.push({frame: metadata.index, wallMs, cpuMs, capacityBefore, capacityAfter});
    }
    const result = {block, orderIndex, arm: arm.name, level: arm.level, excluded,
        decodeWallMs, decodeCpuMs, maxWasmCapacityBytes, measurements};
    (excluded ? warmups : observations).push(result);
    await appendFile(jsonLinesPath, `${JSON.stringify(result)}\n`);
}
const median = (values) => {
    const sorted = [...values].sort((a, b) => a - b);
    const middle = Math.floor(sorted.length / 2);
    return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
};
function summarize() {
    const byArm = Object.fromEntries(['A', 'B', 'C'].map((name) => {
        const rows = observations.filter((row) => row.arm === name);
        return [name, {observations: rows.length, medianDecodeWallMs: median(rows.map((row) => row.decodeWallMs)),
            medianDecodeCpuMs: median(rows.map((row) => row.decodeCpuMs)),
            maxWasmCapacityBytes: Math.max(...rows.map((row) => row.maxWasmCapacityBytes))}];
    }));
    const comparisons = {};
    for (const [candidate, control] of [['B', 'A'], ['B', 'C'], ['C', 'A']]) {
        const left = observations.filter((row) => row.arm === candidate);
        const right = observations.filter((row) => row.arm === control);
        comparisons[`${candidate}/${control}`] = {};
        for (const metric of ['decodeWallMs', 'decodeCpuMs']) {
            const ratios = left.map((row, index) => row[metric] / right[index][metric]);
            comparisons[`${candidate}/${control}`][metric] = {
                medianPairedChangePercent: median(ratios.map((ratio) => 100 * (ratio - 1))),
                geometricMeanPairedChangePercent: 100 * (Math.exp(ratios.reduce((sum, ratio) => sum + Math.log(ratio), 0) / ratios.length) - 1),
                equalWorkChangePercent: 100 * (left.reduce((sum, row) => sum + row[metric], 0) / right.reduce((sum, row) => sum + row[metric], 0) - 1),
                medianAbsoluteSavedMs: median(left.map((row, index) => right[index][metric] - row[metric])),
                faster: ratios.filter((ratio) => ratio < 1).length, pairs: ratios.length, ratios,
            };
        }
    }
    return {byArm, comparisons};
}
let complete = false;
let failure = null;
try {
    for (const [block, order] of [['A', 'B', 'C'], ['C', 'B', 'A']].entries()) {
        for (const [index, name] of order.entries()) { await observe(arms[name], block, index, true); }
    }
    for (const [block, order] of orders.entries()) {
        for (const [index, name] of order.entries()) { await observe(arms[name], block, index); }
        process.stdout.write(`decode block ${block + 1}/${orders.length} complete\n`);
    }
    complete = true;
} catch (error) {
    failure = error.stack ?? String(error);
    process.stderr.write(`${failure}\n`);
    process.exitCode = 1;
} finally {
    for (const arm of Object.values(arms)) { arm.codec.freeDCtx(arm.context); }
    const sourceAfter = {};
    for (const [file, expectedHash] of Object.entries(census.codecSourceFiles)) {
        sourceAfter[file] = sha(await readFile(join(root, file)));
        assert.equal(sourceAfter[file], expectedHash, file);
    }
    const report = {complete, failure, dictionary: census.dictionary, sourceCommit: census.sourceCommit,
        censusPath: resolve(censusPath), censusSha256: sha(censusBytes), independentDecodePath: resolve(independentPath),
        scope: 'Separate sequential full-block decoder throughput comparison of retained level -1/-2 frames using production decompressUsingDict with independent contexts. Includes bounded allocation/copies/native decode; excludes compressed envelope verification, lookup cache, storage reads, UI and whole-import behavior.',
        timingScope: 'Per-call wall/CPU sums; exact raw SHA256 checks outside timers. Two excluded warmup triplets, six fixed balanced measured triplets, same-code level -1 A/C controls. All raw calls and outliers retained.',
        memoryScope: 'Exported WASM module capacity, not live allocation or browser peak memory.',
        codecSourceFiles: census.codecSourceFiles, codecSourceFilesAfter: sourceAfter,
        node: process.version, versions: process.versions, frameCount: frames.length, rawBytes: census.rawBytes,
        orders, summary: complete ? summarize() : null, observations, excludedWarmups: warmups,
        jsonLinesPath: resolve(jsonLinesPath)};
    await writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'});
    process.stdout.write(`${JSON.stringify({complete, failure, dictionary: census.dictionary, summary: report.summary})}\n`);
}
