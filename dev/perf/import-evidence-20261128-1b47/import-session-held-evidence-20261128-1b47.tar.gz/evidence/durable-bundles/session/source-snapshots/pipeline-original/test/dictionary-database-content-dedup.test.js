/*
 * Copyright (C) 2026 Manabitan authors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import {describe, expect, test, vi} from 'vitest';
import {DictionaryDatabase} from '../ext/js/dictionary/dictionary-database.js';
import {
    encodeRawTermContentSharedGlossaryBinary,
    RAW_TERM_CONTENT_SHARED_GLOSSARY_DICT_NAME,
} from '../ext/js/dictionary/raw-term-content.js';
import {hashTermEntryContentBytes, hashTermEntryContentBytesPair} from '../ext/js/dictionary/term-entry-content-hash.js';
import {TermRecordOpfsStore} from '../ext/js/dictionary/term-record-opfs-store.js';
import {registerOwnedTermContent, takeOwnedTermContent} from '../ext/js/dictionary/term-content-ownership.js';

/**
 * @typedef {object} TermContentMeta
 * @property {number} id
 * @property {number} offset
 * @property {number} length
 * @property {string} dictName
 * @property {number} [hash2]
 */

/** @typedef {Parameters<DictionaryDatabase['_resolveArtifactTermContentDedup']>[0]} ArtifactTermContentChunk */
/** @typedef {NonNullable<ArtifactTermContentChunk['contentDedupPlan']>} ArtifactTermContentDedupPlan */
/** @typedef {ArtifactTermContentChunk & {dictionary?: string, dictionaryTotalRows?: number}} ArtifactTermContentChunkWithExtras */
/** @typedef {Parameters<DictionaryDatabase['_bulkAddArtifactTermsChunkWithContentDedup']>[0]} ArtifactTermContentChunkFixture */

/**
 * @param {DictionaryDatabase} database
 * @param {number} hash1
 * @param {number} hash2
 * @returns {TermContentMeta|undefined}
 */
function getMeta(database, hash1, hash2) {
    const getTermEntryContentMetaByHashPair = /** @type {(this: DictionaryDatabase, hash1: number, hash2: number) => {id: number, offset: number, length: number, dictName: string, hash2?: number}|undefined} */ (
        Reflect.get(database, '_getTermEntryContentMetaByHashPair')
    );
    return getTermEntryContentMetaByHashPair.call(database, hash1, hash2);
}

/**
 * @param {DictionaryDatabase} database
 * @param {string|null} contentHash
 * @param {number} offset
 * @param {number} length
 * @param {string} dictName
 * @param {number} hash1
 * @param {number} hash2
 */
function cacheMeta(database, contentHash, offset, length, dictName, hash1, hash2) {
    const cacheTermEntryContentMeta = /** @type {(this: DictionaryDatabase, contentHash: string|null, offset: number, length: number, dictName: string, id?: number, hash1?: number, hash2?: number) => {id: number, offset: number, length: number, dictName: string, hash2?: number}} */ (
        Reflect.get(database, '_cacheTermEntryContentMeta')
    );
    cacheTermEntryContentMeta.call(database, contentHash, offset, length, dictName, 0, hash1, hash2);
}

/**
 * @param {DictionaryDatabase} database
 * @param {Uint8Array} source
 * @param {number} sourceOffset
 * @param {number} length
 * @param {number} hash1
 * @param {number} hash2
 * @param {{indexes: Int32Array, active: boolean}|null} [stagedMetadata]
 * @returns {{staged: {indexes: Int32Array, active: boolean}, meta: TermContentMeta}}
 */
function publishSlabMeta(database, source, sourceOffset, length, hash1, hash2, stagedMetadata = null) {
    const spans = {
        buffer: source,
        offsets: new Uint32Array([sourceOffset]),
        lengths: new Uint32Array([length]),
    };
    const stage = Reflect.get(database, '_stageArtifactTermContentMetadata').bind(database);
    const publish = Reflect.get(database, '_publishArtifactTermContentMetadata').bind(database);
    const staged = stagedMetadata ?? stage([hash1], [hash2], [], spans);
    publish({
        count: 1,
        contentOffsets: new Float64Array(1),
        contentLengths: new Uint32Array(1),
        resolvedContentDictNames: 'raw',
        pendingRowToUniqueIndex: new Int32Array([0]),
        pendingContentBytes: [],
        pendingContentHash1s: [hash1],
        pendingContentHash2s: [hash2],
        pendingOffsets: [1000 + hash1],
        pendingLengths: [length],
        pendingResolvedDictNames: 'raw',
        pendingContentSpans: spans,
        stagedContentMetadata: staged,
    });
    const meta = getMeta(database, hash1, hash2);
    if (typeof meta === 'undefined') { throw new Error('Expected published term content metadata'); }
    return {staged, meta};
}

/**
 * @param {number[]} [sourceValues]
 * @param {number} [hash1]
 * @param {number} [hash2]
 * @returns {{database: DictionaryDatabase, chunk: ArtifactTermContentChunkFixture, plan: ArtifactTermContentDedupPlan, appendRecords: ReturnType<typeof vi.fn>, releaseBorrowedContent: ReturnType<typeof vi.fn>, resolveContent: () => void, rejectContent: (error: Error) => void, resolveRecords: () => void, rejectRecords: (error: Error) => void, run: () => Promise<void>}}
 */
function createArtifactOverlapHarness(sourceValues = [1, 2, 3], hash1 = 10, hash2 = 20) {
    const database = new DictionaryDatabase();
    Reflect.set(database, '_bulkImportTransactionOpen', true);
    Reflect.set(database, '_deferTermsVirtualTableSync', true);
    Reflect.set(database, '_termContentZstdInitialized', true);

    /** @type {() => void} */
    let resolveContent = () => {};
    /** @type {(error: Error) => void} */
    let rejectContent = () => {};
    const contentCompletion = new Promise((resolve, reject) => {
        resolveContent = () => {
            resolve({packMs: 1, compressMs: 2, envelopeMs: 3, referenceMs: 4, opfsAppendMs: 5});
        };
        rejectContent = reject;
    });
    /** @type {() => void} */
    let resolveRecords = () => {};
    /** @type {(error: Error) => void} */
    let rejectRecords = () => {};
    const recordCompletion = new Promise((resolve, reject) => {
        resolveRecords = () => {
            resolve({
                buildRecordsMs: 0,
                encodeMs: 0,
                appendWriteMs: 0,
                internMs: 0,
                packLengthsMs: 0,
                heapCopyMs: 0,
                recordFieldEncodeMs: 0,
                validationMs: 0,
                lookupIndexEncodeMs: 0,
            });
        };
        rejectRecords = reject;
    });
    const appendRecords = vi.fn(async () => await recordCompletion);
    Reflect.set(database, '_termRecordStore', {
        appendBatchFromArtifactChunkResolvedContent: appendRecords,
    });
    Reflect.set(database, '_termContentBlockImportSession', {
        tryBeginAppendSpans: vi.fn(() => ({
            initialSelection: true,
            sourceConsumed: Promise.resolve(),
            storage: Promise.resolve({
                contentOffsets: new Float64Array([100]),
                contentLengths: new Uint32Array([sourceValues.length]),
                contentDictName: 'raw-block-v2:jmdict',
            }),
            completion: contentCompletion.then((profile) => ({
                contentOffsets: new Float64Array([100]),
                contentLengths: new Uint32Array([sourceValues.length]),
                contentDictName: 'raw-block-v2:jmdict',
                ...profile,
            })),
        })),
    });

    const source = new Uint8Array(new SharedArrayBuffer(sourceValues.length));
    source.set(sourceValues);
    const releaseBorrowedContent = vi.fn();
    const plan = /** @type {ArtifactTermContentDedupPlan} */ ({
        uniqueCount: 1,
        sourceRowCount: 1,
        resolvedFlags: new Uint8Array(1),
        resolvedOffsets: new Float64Array(1),
        resolvedLengths: new Uint32Array(1),
        resolvedDictNames: null,
        pendingEpochs: new Uint32Array(1),
        pendingIndexes: new Uint32Array(1),
        nextEpoch: 1,
        nextUnresolvedUniqueIndex: 0,
        persistedLookupRequired: false,
    });
    const chunk = {
        dictionary: 'JMdict',
        rowCount: 1,
        dictionaryTotalRows: 1,
        expressionBytesList: [new TextEncoder().encode('test')],
        readingBytesList: [new Uint8Array(0)],
        readingEqualsExpressionList: new Uint8Array([1]),
        scoreList: new Int32Array(1),
        sequenceList: new Int32Array([-1]),
        contentBytesList: [],
        contentHash1List: new Uint32Array(0),
        contentHash2List: new Uint32Array(0),
        contentBytesBuffer: source,
        contentBytesBaseOffset: 0,
        contentMetaList: new Uint32Array([0, sourceValues.length, hash1, hash2]),
        contentUniqueIndexList: new Uint32Array([0]),
        contentDedupPlan: plan,
        releaseBorrowedContent,
        contentDictNameList: null,
        uniformContentDictName: 'raw-v6',
        termRecordPreinternedPlan: null,
    };
    const bulkAdd = Reflect.get(database, '_bulkAddArtifactTermsChunkWithContentDedup').bind(database);
    return {
        database,
        chunk,
        plan,
        appendRecords,
        releaseBorrowedContent,
        resolveContent,
        rejectContent,
        resolveRecords,
        rejectRecords,
        run: async () => await bulkAdd(chunk),
    };
}

/** @returns {ReturnType<typeof createArtifactOverlapHarness>} */
function createOwnedArtifactOverlapHarness() {
    const harness = createArtifactOverlapHarness();
    const source = harness.chunk.contentBytesBuffer;
    if (!(source instanceof Uint8Array)) { throw new Error('Expected a content slab'); }
    registerOwnedTermContent(source);
    Reflect.deleteProperty(harness.chunk, 'releaseBorrowedContent');
    harness.run = async () => await harness.database.bulkAddArtifactTermsChunk(harness.chunk);
    return harness;
}

/**
 * @param {ReturnType<typeof createArtifactOverlapHarness>} harness
 * @returns {{exec: ReturnType<typeof vi.fn>, endContent: ReturnType<typeof vi.fn>, endRecords: ReturnType<typeof vi.fn>, rollbackContent: ReturnType<typeof vi.fn>, rollbackRecords: ReturnType<typeof vi.fn>}}
 */
function configureArtifactOverlapLifecycle(harness) {
    const exec = vi.fn();
    const endContent = vi.fn(async () => {});
    const endRecords = vi.fn(async () => {});
    const rollbackContent = vi.fn(async () => {});
    const rollbackRecords = vi.fn(async () => {});
    Reflect.set(harness.database, '_db', {exec, close: vi.fn()});
    Reflect.set(harness.database, '_bulkImportState', 'active');
    Reflect.set(harness.database, '_bulkImportJournalRecord', {
        version: 1, sessionId: 'owned-overlap', contentCheckpoint: {segments: []}, recordCheckpoint: {shards: []}, createdAt: 0,
    });
    Reflect.set(harness.database, '_importJournal', {clear: vi.fn(async () => {})});
    Reflect.set(harness.database, '_termContentStore', {
        endImportSession: endContent, rollbackImportSession: rollbackContent, getLastEndImportSessionMetrics: () => null,
    });
    Object.assign(Reflect.get(harness.database, '_termRecordStore'), {
        endImportSession: endRecords, rollbackImportSession: rollbackRecords, getLastEndImportSessionMetrics: () => null,
    });
    Reflect.set(Reflect.get(harness.database, '_termContentBlockImportSession'), 'close', vi.fn());
    Reflect.set(harness.database, '_applyRuntimePragmas', vi.fn());
    Reflect.set(harness.database, '_syncTermsVirtualTableFromRecordStore', vi.fn(async () => {}));
    Reflect.set(harness.database, '_rollbackGenerationMedia', vi.fn(async () => {}));
    Reflect.set(harness.database, '_createIndexesSql', () => []);
    return {exec, endContent, endRecords, rollbackContent, rollbackRecords};
}

describe('DictionaryDatabase bounded owned-content persistence overlap', () => {
    test('returns after records are copied and drains the one remaining content owner exactly once', async () => {
        const harness = createOwnedArtifactOverlapHarness();
        harness.resolveRecords();
        await harness.run();
        expect(harness.database.getLastBulkAddTermsMetrics()).toMatchObject({contentDeferredPersistenceCount: 1, contentCompressMs: 0});
        expect(Reflect.get(harness.database, '_inFlightTermContentSourceBatches').size).toBe(1);
        const drain = Reflect.get(harness.database, '_drainDeferredArtifactContentPersistence').bind(harness.database);
        let drained = false;
        const completion = drain().then((metrics) => {
            drained = true;
            return metrics;
        });
        await Promise.resolve();
        expect(drained).toBe(false);
        expect(Reflect.get(harness.database, '_deferredArtifactContentPersistence')).not.toBeNull();
        harness.resolveContent();
        expect(await completion).toMatchObject({contentPackMs: 1, contentCompressMs: 2, contentEnvelopeMs: 3});
        expect(Reflect.get(harness.database, '_inFlightTermContentSourceBatches').size).toBe(0);
        expect(Reflect.get(harness.database, '_deferredArtifactContentPersistence')).toBeNull();
        expect(await drain()).toBeNull();
        expect(harness.releaseBorrowedContent).not.toHaveBeenCalled();
    });

    test.each(['borrowed', 'unowned', 'partial'])('joins content before returning for a %s source', async (kind) => {
        const harness = createArtifactOverlapHarness();
        const source = harness.chunk.contentBytesBuffer;
        if (!(source instanceof Uint8Array)) { throw new Error('Expected a content slab'); }
        if (kind !== 'unowned') { registerOwnedTermContent(source); }
        if (kind !== 'borrowed') { Reflect.deleteProperty(harness.chunk, 'releaseBorrowedContent'); }
        if (kind === 'partial') { harness.plan.sourceRowCount = 2; }
        harness.resolveRecords();
        let settled = false;
        const completion = harness.run().then(() => { settled = true; });
        await vi.waitFor(() => expect(harness.appendRecords).toHaveBeenCalledOnce());
        expect(settled).toBe(false);
        expect(Reflect.get(harness.database, '_deferredArtifactContentPersistence')).toBeNull();
        harness.resolveContent();
        await completion;
        expect(harness.database.getLastBulkAddTermsMetrics()).toMatchObject({contentDeferredPersistenceCount: 0, contentCompressMs: 2});
    });

    test('resolves a successor duplicate from immutable bytes while its predecessor still compresses', async () => {
        const first = createOwnedArtifactOverlapHarness();
        first.resolveRecords();
        await first.run();
        const second = createArtifactOverlapHarness();
        second.plan.persistedLookupRequired = true;
        const persistedRead = vi.fn(() => { throw new Error('Deferred source must not require a persisted read'); });
        Reflect.set(first.database, '_readTermEntryContentBytesDetailed', persistedRead);
        const completion = first.database.bulkAddArtifactTermsChunk(second.chunk);
        await vi.waitFor(() => expect(second.plan.resolvedFlags[0]).toBe(1));
        expect(second.plan.resolvedOffsets[0]).toBe(100);
        expect(first.appendRecords).toHaveBeenCalledOnce();
        expect(persistedRead).not.toHaveBeenCalled();
        first.resolveContent();
        await completion;
        expect(first.appendRecords).toHaveBeenCalledTimes(2);
        expect(first.database.getLastBulkAddTermsMetrics()).toMatchObject({dedupPersistedHitCount: 1, contentCompressMs: 2});
    });

    test('admits no second reservation until the preceding content operation settles', async () => {
        const first = createOwnedArtifactOverlapHarness();
        first.resolveRecords();
        await first.run();
        const second = createArtifactOverlapHarness([4, 5, 6], 30, 40);
        second.plan.persistedLookupRequired = true;
        second.plan.uniqueRowIndexes = new Uint32Array([0]);
        second.chunk.contentRowStart = 0;
        const reserve = Reflect.get(first.database, '_termContentBlockImportSession').tryBeginAppendSpans;
        const completion = first.database.bulkAddArtifactTermsChunk(second.chunk);
        await vi.waitFor(() => expect(Reflect.get(first.database, '_termEntryContentMetaHashPairPendingCount')).toBe(1));
        expect(reserve).toHaveBeenCalledOnce();
        expect(first.appendRecords).toHaveBeenCalledOnce();
        first.resolveContent();
        await completion;
        expect(reserve).toHaveBeenCalledTimes(2);
        expect(first.appendRecords).toHaveBeenCalledTimes(2);
        expect(Reflect.get(first.database, '_deferredArtifactContentPersistence')).toBeNull();
    });

    test.each([false, true])('rolls back successor resolution when deferred content fails; duplicate=%s', async (duplicate) => {
        const first = createOwnedArtifactOverlapHarness();
        first.resolveRecords();
        await first.run();
        const second = duplicate ? createArtifactOverlapHarness() : createArtifactOverlapHarness([4, 5, 6], 30, 40);
        second.plan.persistedLookupRequired = true;
        second.plan.uniqueRowIndexes = new Uint32Array([0]);
        second.chunk.contentRowStart = 0;
        const outcome = first.database.bulkAddArtifactTermsChunk(second.chunk).then(() => null, (error) => error);
        await vi.waitFor(() => {
            expect(duplicate ? second.plan.resolvedFlags[0] : Reflect.get(first.database, '_termEntryContentMetaHashPairPendingCount')).toBe(1);
        });
        first.rejectContent(new Error('predecessor compression failed'));
        expect(await outcome).toMatchObject({message: 'predecessor compression failed'});
        expect(first.appendRecords).toHaveBeenCalledOnce();
        expect(getMeta(first.database, 10, 20)).toBeUndefined();
        expect(getMeta(first.database, 30, 40)).toBeUndefined();
        expect(Reflect.get(first.database, '_termEntryContentMetaHashPairCount')).toBe(0);
        expect(Reflect.get(first.database, '_termEntryContentMetaHashPairPendingCount')).toBe(0);
        expect(Reflect.get(first.database, '_recentTermContentSourceBatches').size).toBe(0);
        expect(first.plan.resolvedFlags[0]).toBe(0);
        expect(second.plan.resolvedFlags[0]).toBe(0);
        expect(second.plan.resolvedOffsets[0]).toBe(0);
    });

    test('retains the immutable owner until an awaiting exact matcher has returned', async () => {
        const first = createOwnedArtifactOverlapHarness();
        first.resolveRecords();
        await first.run();
        const second = createArtifactOverlapHarness();
        second.plan.persistedLookupRequired = true;
        const matcher = Reflect.get(first.database, '_findMatchingPersistedTermEntryContentMeta').bind(first.database);
        /** @type {() => void} */
        let releaseMatcher = () => {};
        const matcherGate = new Promise((resolve) => { releaseMatcher = () => resolve(void 0); });
        let matcherWaiting = false;
        Reflect.set(first.database, '_findMatchingPersistedTermEntryContentMeta', async (...args) => {
            const result = await matcher(...args);
            matcherWaiting = true;
            await matcherGate;
            return result;
        });
        const outcome = first.database.bulkAddArtifactTermsChunk(second.chunk).then(() => null, (error) => error);
        await vi.waitFor(() => expect(matcherWaiting).toBe(true));
        first.rejectContent(new Error('late content failure'));
        await Promise.resolve();
        await Promise.resolve();
        expect(Reflect.get(first.database, '_recentTermContentSourceBatches').size).toBe(1);
        expect(getMeta(first.database, 10, 20)).toBeDefined();
        releaseMatcher();
        expect(await outcome).toMatchObject({message: 'late content failure'});
        expect(Reflect.get(first.database, '_recentTermContentSourceBatches').size).toBe(0);
        expect(second.plan.resolvedFlags[0]).toBe(0);
    });

    test('preserves both record and content failures on an otherwise eligible owned source', async () => {
        const harness = createOwnedArtifactOverlapHarness();
        const outcome = harness.run().then(() => null, (error) => error);
        await vi.waitFor(() => expect(harness.appendRecords).toHaveBeenCalledOnce());
        harness.rejectRecords(new Error('record append failed'));
        await Promise.resolve();
        harness.rejectContent(new Error('content append failed'));
        const error = await outcome;
        expect(error).toBeInstanceOf(AggregateError);
        expect(error.errors.map((/** @type {Error} */ item) => item.message)).toEqual(['content append failed', 'record append failed']);
        expect(getMeta(harness.database, 10, 20)).toBeUndefined();
        expect(Reflect.get(harness.database, '_deferredArtifactContentPersistence')).toBeNull();
    });

    test('keeps concurrent cleanup behind the same pending owner and rolls it back once', async () => {
        const harness = createOwnedArtifactOverlapHarness();
        harness.resolveRecords();
        await harness.run();
        const pending = Reflect.get(harness.database, '_deferredArtifactContentPersistence');
        const rollback = vi.fn(pending.rollback);
        pending.rollback = rollback;
        const endContent = vi.fn(async () => {});
        const endRecords = vi.fn(async () => {});
        Reflect.set(harness.database, '_termContentStore', {endImportSession: endContent});
        Reflect.set(Reflect.get(harness.database, '_termRecordStore'), 'endImportSession', endRecords);
        const drain = Reflect.get(harness.database, '_drainDeferredArtifactContentPersistence').bind(harness.database);
        const first = drain().then(() => null, (error) => error);
        /** @type {Error[]} */
        const errors = [];
        const cleanup = Reflect.get(harness.database, '_endBulkImportStoreSessions').call(harness.database, errors, true, true);
        await Promise.resolve();
        expect(endContent).not.toHaveBeenCalled();
        expect(endRecords).not.toHaveBeenCalled();
        harness.rejectContent(new Error('deferred write failed'));
        expect(await first).toMatchObject({message: 'deferred write failed'});
        await cleanup;
        expect(errors.map((error) => error.message)).toEqual(['deferred write failed']);
        expect(endContent).toHaveBeenCalledOnce();
        expect(endRecords).toHaveBeenCalledOnce();
        expect(rollback).toHaveBeenCalledOnce();
        expect(Reflect.get(harness.database, '_deferredArtifactContentPersistence')).toBeNull();
    });

    test.each([false, true])('joins the final content operation before publication; failure=%s', async (failure) => {
        const harness = createOwnedArtifactOverlapHarness();
        const lifecycle = configureArtifactOverlapLifecycle(harness);
        harness.resolveRecords();
        await harness.run();
        const outcome = harness.database.finishBulkImport().then((result) => ({result}), (error) => ({error}));
        await vi.waitFor(() => expect(Reflect.get(harness.database, '_bulkImportState')).toBe('finalizing'));
        expect(lifecycle.endContent).not.toHaveBeenCalled();
        expect(lifecycle.endRecords).not.toHaveBeenCalled();
        expect(lifecycle.exec).not.toHaveBeenCalledWith('COMMIT');
        if (failure) {
            harness.rejectContent(new Error('final content failed'));
        } else {
            harness.resolveContent();
        }
        const settled = await outcome;
        if ('error' in settled) {
            expect(failure).toBe(true);
            expect(settled.error).toMatchObject({message: 'final content failed'});
            expect(lifecycle.exec).not.toHaveBeenCalledWith('COMMIT');
            expect(lifecycle.exec).toHaveBeenCalledWith('ROLLBACK');
            expect(lifecycle.rollbackContent).toHaveBeenCalledOnce();
            expect(lifecycle.rollbackRecords).toHaveBeenCalledOnce();
        } else {
            expect(failure).toBe(false);
            expect(settled.result).toMatchObject({deferredTermContentMetrics: {contentCompressMs: 2}});
            expect(lifecycle.exec).toHaveBeenCalledWith('COMMIT');
            expect(lifecycle.rollbackContent).not.toHaveBeenCalled();
        }
        expect(Reflect.get(harness.database, '_deferredArtifactContentPersistence')).toBeNull();
        expect(Reflect.get(harness.database, '_bulkImportState')).toBe('idle');
    });

    test.each(['close', 'abortBulkImport'])('joins an active exact matcher before %s retires metadata or checkpoints', async (operation) => {
        const first = createOwnedArtifactOverlapHarness();
        const lifecycle = configureArtifactOverlapLifecycle(first);
        first.resolveRecords();
        await first.run();
        const second = createArtifactOverlapHarness();
        second.plan.persistedLookupRequired = true;
        const matcher = Reflect.get(first.database, '_findMatchingPersistedTermEntryContentMeta').bind(first.database);
        /** @type {() => void} */
        let releaseMatcher = () => {};
        const matcherGate = new Promise((resolve) => { releaseMatcher = () => resolve(void 0); });
        let matcherWaiting = false;
        Reflect.set(first.database, '_findMatchingPersistedTermEntryContentMeta', async (...args) => {
            const result = await matcher(...args);
            matcherWaiting = true;
            await matcherGate;
            return result;
        });
        const writeOutcome = first.database.bulkAddArtifactTermsChunk(second.chunk).then(() => null, (error) => error);
        await vi.waitFor(() => expect(matcherWaiting).toBe(true));
        const cleanupOutcome = Reflect.get(first.database, operation).call(first.database).then(() => null, (error) => error);
        await vi.waitFor(() => expect(Reflect.get(first.database, '_bulkImportState')).toBe('finalizing'));
        first.rejectContent(new Error('owned content failed during cleanup'));
        await Promise.resolve();
        await Promise.resolve();
        expect(getMeta(first.database, 10, 20)).toBeDefined();
        expect(lifecycle.rollbackContent).not.toHaveBeenCalled();
        expect(lifecycle.rollbackRecords).not.toHaveBeenCalled();
        expect(lifecycle.exec).not.toHaveBeenCalledWith('ROLLBACK');
        releaseMatcher();
        expect(await writeOutcome).toMatchObject({message: 'owned content failed during cleanup'});
        expect(await cleanupOutcome).toMatchObject({message: 'owned content failed during cleanup'});
        expect(lifecycle.rollbackContent).toHaveBeenCalledOnce();
        expect(lifecycle.rollbackRecords).toHaveBeenCalledOnce();
        expect(second.plan.resolvedFlags[0]).toBe(0);
        expect(Reflect.get(first.database, '_activeArtifactTermImportWrite')).toBeNull();
    });

    test('drains deferred content before switching to the artifact fallback writer', async () => {
        const harness = createOwnedArtifactOverlapHarness();
        harness.resolveRecords();
        await harness.run();
        harness.database.setTermEntryContentDedupEnabled(false);
        const fallback = vi.fn(async () => { Reflect.set(harness.database, '_lastBulkAddTermsMetrics', {}); });
        Reflect.set(harness.database, '_bulkAddArtifactTermsChunkWithoutContentDedup', fallback);
        const completion = harness.database.bulkAddArtifactTermsChunk(harness.chunk);
        await Promise.resolve();
        expect(fallback).not.toHaveBeenCalled();
        harness.resolveContent();
        await completion;
        expect(fallback).toHaveBeenCalledOnce();
        expect(harness.database.getLastBulkAddTermsMetrics()).toMatchObject({contentCompressMs: 2});
    });
});

describe('DictionaryDatabase term content hash validation', () => {
    test.each([
        'deadbeeX0000000Y',
        '0000000z00000000',
    ])('does not index partially parsed hexadecimal hash %s', (contentHash) => {
        const database = new DictionaryDatabase();
        cacheMeta(database, contentHash, 10, 3, 'raw', -1, -1);

        expect(getMeta(database, 0x0deadbee, 0)).toBeUndefined();
        expect(getMeta(database, 0, 0)).toBeUndefined();
    });

    test.each([
        'not-a-hash',
        'deadbeeX0000000Y',
    ])('canonicalizes malformed precomputed hash %s before publishing metadata', async (contentHash) => {
        const database = new DictionaryDatabase();
        Reflect.set(database, '_db', {});
        Reflect.set(database, '_bulkImportTransactionOpen', true);
        Reflect.set(database, '_enableTermEntryContentDedup', true);
        Reflect.set(database, '_termContentZstdInitialized', true);
        Reflect.set(database, '_termContentStore', {
            appendBatch: vi.fn(async (/** @type {Uint8Array[]} */ chunks) => chunks.map((chunk, index) => ({
                offset: 100 + index * 100,
                length: chunk.byteLength,
            }))),
        });
        Reflect.set(database, '_createTermContentStorageChunks', vi.fn((chunks) => ({
            storedChunks: chunks,
            entryToStoredChunkIndexes: new Uint32Array(chunks.length),
            entryToStoredChunkOffsets: new Uint32Array(chunks.length),
            contentDictNames: new Array(chunks.length).fill('raw'),
        })));
        Reflect.set(database, '_insertResolvedImportTermEntries', vi.fn(async () => ({
            termRecordAppendMs: 0,
            termRecordEncodeMs: 0,
            termRecordWriteMs: 0,
            termsVtabInsertMs: 0,
        })));

        const contentBytes = Uint8Array.of(1, 2, 3, 4, 5);
        const expectedHash = hashTermEntryContentBytes(contentBytes);
        const row = {
            dictionary: 'hash-test',
            expression: 'x',
            reading: 'x',
            definitionTags: '',
            rules: '',
            score: 0,
            glossary: [],
            termTags: '',
            termEntryContentBytes: contentBytes,
            termEntryContentHash: contentHash,
        };
        const bulkAddTerms = Reflect.get(database, '_bulkAddTerms').bind(database);

        await bulkAddTerms([row], 0, 1);

        expect(Reflect.get(database, '_termEntryContentMetaByHash').has(contentHash)).toBe(false);
        expect(Reflect.get(database, '_termEntryContentMetaByHash').has(expectedHash)).toBe(true);
    });
});

describe('DictionaryDatabase term content dedup metadata cache', () => {
    test.each(['stage', 'reserve', 'fast'].flatMap((writer) => (
        Array.from({length: 5}, (_, length) => ({writer, length}))
    )))('bounds $writer signatures to a logical slab span of length $length', async ({writer, length}) => {
        const database = new DictionaryDatabase();
        const contentBytes = Uint8Array.from({length}, (_, i) => i + 1);
        const source = Uint8Array.of(90, ...contentBytes, 91, 92, 93, 94);
        const [hash1, hash2] = hashTermEntryContentBytesPair(contentBytes);
        const spans = {buffer: source, offsets: Uint32Array.of(1), lengths: Uint32Array.of(length)};
        const stage = Reflect.get(database, '_stageArtifactTermContentMetadata').bind(database);
        const reserve = Reflect.get(database, '_reserveArtifactTermContentMetadata').bind(database);
        const rollback = Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').bind(database);
        Reflect.get(database, '_ensureTermEntryContentMetaHashPairCapacity').call(database, 1);
        if (writer === 'fast') {
            const dictNameId = Reflect.get(database, '_internTermEntryContentMetaDictName').call(database, 'raw');
            Reflect.get(database, '_insertTermEntryContentMetaByHashPairFast').call(database, hash1, hash2, 1000, length, 'raw', dictNameId, source, 1);
        } else {
            const reserveMetadata = () => (writer === 'stage' ?
                stage([hash1], [hash2], [], spans) :
                {indexes: Int32Array.of(reserve(hash1, hash2, source, 1, length)), active: true});
            const staged = reserveMetadata();
            expect(getMeta(database, hash1, hash2)).toBeUndefined();
            expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(1);
            rollback(staged);
            expect(getMeta(database, hash1, hash2)).toBeUndefined();
            expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(0);
            const retried = reserveMetadata();
            expect(retried.indexes[0]).toBe(staged.indexes[0]);
            publishSlabMeta(database, source, 1, length, hash1, hash2, retried);
        }
        const meta = getMeta(database, hash1, hash2);
        if (typeof meta === 'undefined') { throw new Error('Expected published term content metadata'); }
        const expectedSignature = contentBytes.reduce((value, byte, i) => value | (byte << (i * 8)), 0) >>> 0;
        expect(meta).toMatchObject({
            length,
            signature1: expectedSignature,
            signature2: expectedSignature,
            signature3: expectedSignature,
        });
        expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(0);
        expect(Reflect.get(database, '_termEntryContentMetaHashPairCount')).toBe(1);
        const readStorage = vi.fn(async () => [{status: 'ok', bytes: Uint8Array.from(contentBytes)}]);
        Reflect.set(database, '_readTermEntryContentBytesDetailedBatch', readStorage);
        const findBatch = Reflect.get(database, '_findMatchingPersistedTermEntryContentMetaBatch').bind(database);
        const [result] = await findBatch([{hash1, hash2, contentBytes, primary: meta}]);
        expect(result.existingMeta).toEqual(meta);
        expect(result.exactFallback).toBe(true);
    });

    test('owns recent published source bytes across borrowed slab reuse', async () => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array([90, 1, 2, 3, 4, 91]);
        const expected = source.slice(1, 5);
        const {meta} = publishSlabMeta(database, source, 1, expected.length, 10, 20);
        const readStorage = vi.fn(async () => {
            throw new Error('recent source hit should not read storage');
        });
        Reflect.set(database, '_readTermEntryContentBytesDetailedBatch', readStorage);

        source.fill(0);
        const findBatch = Reflect.get(database, '_findMatchingPersistedTermEntryContentMetaBatch').bind(database);
        const [result] = await findBatch([{hash1: 10, hash2: 20, contentBytes: expected, primary: meta}]);

        expect(result).toMatchObject({existingMeta: meta, exactFallback: true, recentSourceHit: true});
        expect(readStorage).not.toHaveBeenCalled();
    });

    test('does not deduplicate unequal bytes with matching hashes and signatures', async () => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array(20);
        source.set([1, 2, 3, 4], 0);
        source.set([5, 6, 7, 8], 9);
        source.set([9, 10, 11, 12], 16);
        const collision = Uint8Array.from(source);
        collision[6] = 99;
        const {meta} = publishSlabMeta(database, source, 0, source.length, 10, 20);
        const readStorage = vi.fn();
        Reflect.set(database, '_readTermEntryContentBytesDetailedBatch', readStorage);

        const findBatch = Reflect.get(database, '_findMatchingPersistedTermEntryContentMetaBatch').bind(database);
        const [result] = await findBatch([{hash1: 10, hash2: 20, contentBytes: collision, primary: meta}]);

        expect(result).toStrictEqual({existingMeta: void 0, exactFallback: true});
        expect(readStorage).not.toHaveBeenCalled();
    });

    test('falls back to validated storage after a recent source batch is evicted', async () => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array([1, 2, 3, 4]);
        const {meta} = publishSlabMeta(database, source, 0, source.length, 10, 20);
        Reflect.get(database, '_recentTermContentSourceBatches').clear();
        Reflect.set(database, '_recentTermContentSourceBatchBytes', 0);
        const readStorage = vi.fn(async () => [{status: 'ok', bytes: Uint8Array.from(source)}]);
        Reflect.set(database, '_readTermEntryContentBytesDetailedBatch', readStorage);

        const findBatch = Reflect.get(database, '_findMatchingPersistedTermEntryContentMetaBatch').bind(database);
        const [result] = await findBatch([{hash1: 10, hash2: 20, contentBytes: source, primary: meta}]);

        expect(result).toStrictEqual({existingMeta: meta, exactFallback: true});
        expect(readStorage).toHaveBeenCalledOnce();
    });

    test('preserves recent source mappings across dense metadata growth', async () => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array([1, 2, 3, 4]);
        const {meta} = publishSlabMeta(database, source, 0, source.length, 10, 20);
        Reflect.get(database, '_ensureTermEntryContentMetaDenseCapacity').call(database, 4096);
        const readStorage = vi.fn();
        Reflect.set(database, '_readTermEntryContentBytesDetailedBatch', readStorage);

        const findBatch = Reflect.get(database, '_findMatchingPersistedTermEntryContentMetaBatch').bind(database);
        const [result] = await findBatch([{hash1: 10, hash2: 20, contentBytes: source, primary: meta}]);

        expect(result.recentSourceHit).toBe(true);
        expect(readStorage).not.toHaveBeenCalled();
    });

    test.each(Array.from({length: 14}, (_, i) => i + 1))(
        'retains coherent metadata when dense allocation %i fails and permits retry',
        async (failureIndex) => {
            const database = new DictionaryDatabase();
            const source = new Uint8Array([1, 2, 3, 4]);
            const {meta} = publishSlabMeta(database, source, 0, source.length, 10, 20);
            const stage = Reflect.get(database, '_stageArtifactTermContentMetadata').bind(database);
            const pending = stage([30], [40], [source], null);
            const tableNames = [
                '_termEntryContentMetaHash1Table',
                '_termEntryContentMetaHash2Table',
                '_termEntryContentMetaStateTable',
                '_termEntryContentMetaIdTable',
                '_termEntryContentMetaOffsetTable',
                '_termEntryContentMetaLengthTable',
                '_termEntryContentMetaDictNameIdTable',
                '_termEntryContentMetaSignaturePresentTable',
                '_termEntryContentMetaSignature1Table',
                '_termEntryContentMetaSignature2Table',
                '_termEntryContentMetaSignature3Table',
                '_termEntryContentMetaRecentSourceBatchIdTable',
                '_termEntryContentMetaRecentSourceOffsetTable',
            ];
            const originalTables = tableNames.map((name) => Reflect.get(database, name));
            const originalValues = originalTables.map((table) => [...table]);
            const grow = Reflect.get(database, '_ensureTermEntryContentMetaDenseCapacity').bind(database);
            const failure = new RangeError('injected metadata allocation failure');
            let allocationCount = 0;
            for (const name of /** @type {const} */ (['Uint8Array', 'Uint32Array', 'Float64Array'])) {
                vi.stubGlobal(name, new Proxy(globalThis[name], {
                    construct(target, args, newTarget) {
                        if (++allocationCount === failureIndex) { throw failure; }
                        return Reflect.construct(target, args, newTarget);
                    },
                }));
            }
            try {
                expect(() => grow(4096)).toThrow(failure);
            } finally {
                vi.unstubAllGlobals();
            }
            for (let i = 0; i < tableNames.length; ++i) {
                expect(Reflect.get(database, tableNames[i])).toBe(originalTables[i]);
                expect([...originalTables[i]]).toEqual(originalValues[i]);
            }
            expect(getMeta(database, 10, 20)).toEqual(meta);
            expect(getMeta(database, 30, 40)).toBeUndefined();
            expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(1);

            // The failed grow must not suppress a retry because one published
            // vector already advertises the new capacity.
            grow(4096);
            for (let i = 0; i < tableNames.length; ++i) {
                const table = Reflect.get(database, tableNames[i]);
                expect(table.length).toBe(4096);
                expect([...table.subarray(0, originalTables[i].length)]).toEqual(originalValues[i]);
            }
            const readStorage = vi.fn();
            Reflect.set(database, '_readTermEntryContentBytesDetailedBatch', readStorage);
            const findBatch = Reflect.get(database, '_findMatchingPersistedTermEntryContentMetaBatch').bind(database);
            const [result] = await findBatch([{hash1: 10, hash2: 20, contentBytes: source, primary: meta}]);
            expect(result.recentSourceHit).toBe(true);
            expect(readStorage).not.toHaveBeenCalled();
            Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').call(database, pending);
            expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(0);
            expect(getMeta(database, 10, 20)).toEqual(meta);
            expect(getMeta(database, 30, 40)).toBeUndefined();
            const retried = stage([30], [40], [source], null);
            expect(retried.indexes[0]).toBe(pending.indexes[0]);
        },
    );

    test('uses an owned aligned copy of misaligned shared spans for exact deduplication', async () => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array(new SharedArrayBuffer(32), 3, 12);
        source.set([5, 6, 7, 8], 2);
        const first = publishSlabMeta(database, source, 2, 4, 10, 20);
        const recentBatch = Reflect.get(database, '_recentTermContentSourceBatches').get(1);
        if (typeof recentBatch === 'undefined') { throw new Error('Expected the published shared source to be cached'); }
        expect(recentBatch.byteLength).toBe(4);
        expect(recentBatch.byteOffset % 8).toBe((source.byteOffset + 2) % 8);
        expect(recentBatch.buffer.byteLength).toBe(9);
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(9);
        source.fill(0);
        const findRecent = Reflect.get(database, '_findRecentTermContentSource').bind(database);
        const cachedSource = findRecent(first.meta);
        if (typeof cachedSource === 'undefined') { throw new Error('Expected a recent shared source lookup hit'); }
        expect([...cachedSource.buffer]).toEqual([5, 6, 7, 8]);
        const readStorage = vi.fn();
        Reflect.set(database, '_readTermEntryContentBytesDetailedBatch', readStorage);
        const plan = /** @type {ArtifactTermContentDedupPlan} */ ({
            uniqueCount: 1,
            sourceRowCount: 1,
            uniqueRowIndexes: new Uint32Array([0]),
            resolvedFlags: new Uint8Array(1),
            resolvedOffsets: new Float64Array(1),
            resolvedLengths: new Uint32Array(1),
            resolvedDictNames: new Array(1),
            pendingEpochs: new Uint32Array(1),
            pendingIndexes: new Uint32Array(1),
            nextEpoch: 1,
            persistedLookupRequired: true,
        });
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);

        const result = await resolve(/** @type {ArtifactTermContentChunkWithExtras} */ ({
            rowCount: 1,
            contentRowStart: 0,
            dictionaryTotalRows: 1,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: Uint8Array.of(5, 6, 7, 8),
            contentBytesBaseOffset: 0,
            contentMetaList: new Uint32Array([0, 4, 10, 20]),
            contentUniqueIndexList: new Uint32Array([0]),
            contentDedupPlan: plan,
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        }), true);

        expect(result.pendingContentCount).toBe(0);
        expect(result.persistedHitCount).toBe(1);
        expect(result.exactFallbackCount).toBe(1);
        expect(result.recentSourceHitCount).toBe(1);
        expect(readStorage).not.toHaveBeenCalled();
        Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').call(database, first.staged);
        expect(Reflect.get(database, '_recentTermContentSourceBatches').size).toBe(0);
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(0);
    });

    test('removes recent source mappings on rollback and cache reset', () => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array([1, 2, 3, 4]);
        const first = publishSlabMeta(database, source, 0, source.length, 10, 20);
        const findRecent = Reflect.get(database, '_findRecentTermContentSource').bind(database);
        expect(findRecent(first.meta)).toBeDefined();

        Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').call(database, first.staged);
        expect(findRecent(first.meta)).toBeUndefined();
        expect(Reflect.get(database, '_recentTermContentSourceBatches').size).toBe(0);
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(0);

        const second = publishSlabMeta(database, source, 0, source.length, 30, 40);
        expect(findRecent(second.meta)).toBeDefined();
        Reflect.get(database, '_clearTermEntryContentMetaCaches').call(database);
        expect(findRecent(second.meta)).toBeUndefined();
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(0);
    });

    test('charges padded shared backing bytes on cache admission and eviction', () => {
        const database = new DictionaryDatabase();
        const seed = publishSlabMeta(database, Uint8Array.of(42), 0, 1, 10, 20);
        const published = Reflect.get(database, '_termEntryContentMetaStateTable')[seed.staged.indexes[0]];
        const cacheRecent = Reflect.get(database, '_cacheRecentPublishedTermContentSources');
        const owner = {
            _termEntryContentMetaStateTable: new Uint8Array(2).fill(published),
            _termEntryContentMetaRecentSourceBatchIdTable: new Uint32Array(2),
            _termEntryContentMetaRecentSourceOffsetTable: new Uint32Array(2),
            _recentTermContentSourceBatches: new Map(),
            _recentTermContentSourceBatchBytes: 0,
            _recentTermContentSourceCacheMaxBytes: 8,
            _nextRecentTermContentSourceBatchId: 1,
        };

        const firstSource = new Uint8Array(new SharedArrayBuffer(32), 3, 12);
        firstSource.set([5, 6, 7, 8], 2);
        const firstSpans = {buffer: firstSource, offsets: new Uint32Array([2]), lengths: new Uint32Array([4])};
        const firstStage = {indexes: new Int32Array([0]), active: true};
        expect(cacheRecent.call(owner, firstStage, firstSpans)).toBe(0);
        expect(owner._recentTermContentSourceBatches.size).toBe(0);
        expect(owner._recentTermContentSourceBatchBytes).toBe(0);

        owner._recentTermContentSourceCacheMaxBytes = 9;
        expect(cacheRecent.call(owner, firstStage, firstSpans)).toBe(4);
        expect(owner._recentTermContentSourceBatchBytes).toBe(9);
        const secondSource = new Uint8Array(new SharedArrayBuffer(32), 5, 12);
        secondSource.set([9, 10, 11, 12], 2);
        owner._recentTermContentSourceCacheMaxBytes = 11;
        expect(cacheRecent.call(owner, {indexes: new Int32Array([1]), active: true}, {
            buffer: secondSource,
            offsets: new Uint32Array([2]),
            lengths: new Uint32Array([4]),
        })).toBe(4);
        expect(owner._recentTermContentSourceBatches.size).toBe(1);
        expect(owner._recentTermContentSourceBatches.has(1)).toBe(false);
        expect(owner._recentTermContentSourceBatches.get(2).buffer.byteLength).toBe(11);
        expect(owner._recentTermContentSourceBatchBytes).toBe(11);
    });

    test('ignores incomplete recent source span metadata', () => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array([1, 2, 3, 4]);
        const stage = Reflect.get(database, '_stageArtifactTermContentMetadata').bind(database);
        const cacheRecent = Reflect.get(database, '_cacheRecentPublishedTermContentSources').bind(database);
        const staged = stage([10], [20], [source], null);

        expect(cacheRecent(staged, {
            buffer: source,
            offsets: new Uint32Array(0),
            lengths: new Uint32Array(0),
        })).toBe(0);
        expect(Reflect.get(database, '_recentTermContentSourceBatches').size).toBe(0);
    });

    /* eslint-disable @stylistic/semi */
    test('retains a detached boundary snapshot for a large definition', () => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array(513);

        const {meta} = publishSlabMeta(database, source, 0, source.length, 10, 20);

        const retained = Reflect.get(database, '_findRecentTermContentSource').call(database, meta)
        expect(retained?.length).toBe(source.length)
        expect(retained?.buffer).toEqual(source)
        expect(retained?.buffer.buffer).not.toBe(source.buffer)
        source.fill(99)
        expect(retained?.buffer).toEqual(new Uint8Array(513))
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(513)
    })
    /* eslint-enable @stylistic/semi */

    test('fails fast when metadata insertion is attempted without reserved capacity', () => {
        const database = new DictionaryDatabase();
        const contentBytes = Uint8Array.of(1);
        const reserve = Reflect.get(database, '_reserveArtifactTermContentMetadata').bind(database);
        const insert = Reflect.get(database, '_insertTermEntryContentMetaByHashPairFast').bind(database);

        expect(() => reserve(10, 20, contentBytes, 0, 1)).toThrow('has no free slot');
        expect(() => insert(10, 20, 0, 1, 'raw', 0, contentBytes)).toThrow('has no free slot');
    });

    test('uses parser-prepared signatures without resampling reserved content', () => {
        const database = new DictionaryDatabase();
        const ensureCapacity = Reflect.get(database, '_ensureTermEntryContentMetaHashPairCapacity').bind(database);
        const reserve = Reflect.get(database, '_reserveArtifactTermContentMetadata').bind(database);
        const readSignature = vi.spyOn(database, '_readTermContentSignature');
        ensureCapacity(1);

        const index = reserve(10, 20, Uint8Array.of(1), 0, 1, 101, 202, 303);

        expect(index).toBe(0);
        expect(readSignature).not.toHaveBeenCalled();
        expect(Reflect.get(database, '_termEntryContentMetaSignature1Table')[index]).toBe(101);
        expect(Reflect.get(database, '_termEntryContentMetaSignature2Table')[index]).toBe(202);
        expect(Reflect.get(database, '_termEntryContentMetaSignature3Table')[index]).toBe(303);
    });

    test('routes typed parser plans through prepared metadata reservation', async () => {
        const database = new DictionaryDatabase();
        const genericReserve = vi.spyOn(database, '_reserveArtifactTermContentMetadata');
        const preparedReserve = vi.spyOn(database, '_reservePreparedArtifactTermContentMetadata');
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const source = Uint8Array.of(1, 2, 3);
        const plan = {
            uniqueCount: 1,
            sourceRowCount: 1,
            uniqueRowIndexes: new Uint32Array([0]),
            uniqueSignatures: new Uint32Array([101, 202, 303]),
            resolvedFlags: new Uint8Array(1),
            resolvedOffsets: new Float64Array(1),
            resolvedLengths: new Uint32Array(1),
            resolvedDictNames: new Array(1),
            pendingEpochs: new Uint32Array(1),
            pendingIndexes: new Uint32Array(1),
            nextEpoch: 1,
            nextUnresolvedUniqueIndex: 0,
            persistedLookupRequired: false,
        };

        const result = await resolve(/** @type {ArtifactTermContentChunkWithExtras} */ ({
            rowCount: 1,
            contentRowStart: 0,
            dictionaryTotalRows: 1,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 0,
            contentMetaList: new Uint32Array([0, 3, 10, 20]),
            contentUniqueIndexList: new Uint32Array([0]),
            contentDedupPlan: plan,
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        }), true);

        expect(genericReserve).not.toHaveBeenCalled();
        expect(preparedReserve).toHaveBeenCalledWith(10, 20, 3, 101, 202, 303);
        const index = result.stagedContentMetadata?.indexes[0];
        if (typeof index !== 'number') { throw new Error('Expected staged metadata index'); }
        expect(index).toBe(0);
        expect(Reflect.get(database, '_termEntryContentMetaSignature1Table')[index]).toBe(101);
        expect(Reflect.get(database, '_termEntryContentMetaSignature2Table')[index]).toBe(202);
        expect(Reflect.get(database, '_termEntryContentMetaSignature3Table')[index]).toBe(303);
    });

    test('leases cleared dedup scratch tables without sharing active leases', () => {
        const database = new DictionaryDatabase();
        const acquire = Reflect.get(database, '_acquireArtifactTermContentDedupScratch').bind(database);
        const release = Reflect.get(database, '_releaseArtifactTermContentDedupScratch').bind(database);

        const first = acquire(16);
        first.hash1Table[3] = 123;
        first.indexTable[3] = 4;
        release(first);

        const reused = acquire(16);
        expect(reused).toBe(first);
        expect(reused.hash1Table[3]).toBe(123);
        expect(reused.indexTable[3]).toBe(0);

        const concurrent = acquire(16);
        expect(concurrent).not.toBe(reused);
        release(reused);
        release(concurrent);

        expect(Reflect.get(database, '_artifactTermContentDedupScratchPool')).toHaveLength(2);
    });

    test('promotes weighted content-cache hits without re-weighing them', () => {
        const database = new DictionaryDatabase();
        const cache = /** @type {import('../ext/js/core/weighted-lru-map.js').WeightedLruMap} */ (Reflect.get(database, '_termEntryContentCache'));
        const getCached = Reflect.get(database, '_getCachedTermEntryContent').bind(database);
        const setCached = Reflect.get(database, '_setCachedTermEntryContent').bind(database);
        const value = {definitionTags: null, termTags: '', rules: '', glossaryJson: '[]', glossary: []};
        setCached('first', value);
        setCached('second', {...value});
        const weightBefore = cache.weight;
        const setSpy = vi.spyOn(cache, 'set');

        expect(getCached('first')).toBe(value);

        expect(setSpy).not.toHaveBeenCalled();
        expect(cache.weight).toBe(weightBefore);
        expect([...cache.keys()]).toStrictEqual(['second', 'first']);
    });

    test('groups duplicate external content spans for sequential row materialization', () => {
        const database = new DictionaryDatabase();
        const groupEntries = /** @type {(entries: Array<[number, unknown]>) => Array<Array<[number, unknown]>>} */ (
            Reflect.get(database, '_groupTermRecordEntriesByContentCacheKey').bind(database)
        );

        const groups = groupEntries([
            [1, {entryContentOffset: 10, entryContentLength: 5, entryContentDictName: 'raw'}],
            [2, {entryContentOffset: 10, entryContentLength: 5, entryContentDictName: 'raw'}],
            [3, {entryContentOffset: 20, entryContentLength: 5, entryContentDictName: 'raw'}],
            [4, {entryContentOffset: -1, entryContentLength: 0, entryContentDictName: 'raw'}],
            [5, {entryContentOffset: 10, entryContentLength: 5, entryContentDictName: 'jmdict'}],
        ]);

        expect(groups.map((group) => group.map(([id]) => id))).toEqual([[1, 2], [3], [4], [5]]);
    });

    test('reuses deserialized term rows until lookup caches are reset', async () => {
        const database = new DictionaryDatabase();
        const record = {
            id: 1,
            dictionary: 'JMdict',
            expression: '日本',
            reading: 'にほん',
            expressionReverse: null,
            readingReverse: null,
            entryContentOffset: -1,
            entryContentLength: 0,
            entryContentDictName: null,
            score: 10,
            sequence: 100,
        };
        const getByIds = vi.fn((ids) => new Map([...ids].map((id) => [id, {...record, id}])));
        /** @type {Array<{offset: number, length: number}>} */
        const warmedSpans = [];
        const warmSlices = vi.fn(async (/** @type {Iterable<{offset: number, length: number}>} */ spans) => {
            warmedSpans.push(...spans);
        });
        Reflect.set(database, '_termContentStore', {
            ensureLoadedForRead: vi.fn(async () => {}),
            warmSlices,
        });
        Reflect.set(database, '_termRecordStore', {getByIds, getDictionaryHealth: () => ({status: 'available', reason: null})});
        const fetchTermRowsByIds = /** @type {(this: DictionaryDatabase, ids: Iterable<number>) => Promise<Map<number, unknown>>} */ (
            Reflect.get(database, '_fetchTermRowsByIds')
        );

        const firstRows = await fetchTermRowsByIds.call(database, [1]);
        const secondRows = await fetchTermRowsByIds.call(database, [1]);

        expect(getByIds).toHaveBeenCalledTimes(1);
        expect(firstRows.get(1)).toBe(secondRows.get(1));
        expect(warmedSpans).toEqual([{offset: -1, length: 0}]);

        Reflect.get(database, '_clearDirectTermIndexCaches').call(database);
        await fetchTermRowsByIds.call(database, [1]);

        expect(getByIds).toHaveBeenCalledTimes(2);
    });

    test('does not cache transient content read failures as empty glossaries', async () => {
        const database = new DictionaryDatabase();
        const readDetailed = vi.fn()
            .mockResolvedValueOnce({status: 'temporarilyUnavailable', reason: 'injected OPFS failure'})
            .mockResolvedValueOnce({
                status: 'ok',
                bytes: new TextEncoder().encode(JSON.stringify({
                    definitionTags: '',
                    termTags: '',
                    rules: '',
                    glossary: ['definition'],
                })),
            });
        Reflect.set(database, '_termContentBlockStore', {readDetailed});
        const markDictionaryReimportRequired = vi.spyOn(
            Reflect.get(database, '_termRecordStore'),
            'markDictionaryReimportRequired',
        );
        const deserialize = Reflect.get(database, '_deserializeTermRow').bind(database);
        const row = {
            id: 1,
            dictionary: 'JMdict',
            expression: '日本',
            reading: 'にほん',
            expressionReverse: null,
            readingReverse: null,
            entryContentId: null,
            entryContentOffset: 10,
            entryContentLength: 20,
            entryContentDictName: 'raw',
            score: 1,
            sequence: 1,
        };

        await expect(deserialize(row)).rejects.toThrow('temporarily unavailable');
        expect(Reflect.get(database, '_termEntryContentCache').size).toBe(0);
        expect(markDictionaryReimportRequired).not.toHaveBeenCalled();

        await expect(deserialize(row)).resolves.toMatchObject({glossary: ['definition']});
        expect(readDetailed).toHaveBeenCalledTimes(2);
        expect(Reflect.get(database, '_termEntryContentCache').size).toBe(1);
    });

    test('does not misclassify a transient shared-glossary read as corruption', async () => {
        const database = new DictionaryDatabase();
        const textEncoder = new TextEncoder();
        const glossaryBytes = textEncoder.encode('["shared definition"]');
        const sharedHeader = encodeRawTermContentSharedGlossaryBinary(
            '',
            '',
            '',
            200,
            glossaryBytes.byteLength,
            textEncoder,
        );
        const readDetailed = vi.fn()
            .mockResolvedValueOnce({status: 'ok', bytes: sharedHeader})
            .mockResolvedValueOnce({status: 'temporarilyUnavailable', reason: 'injected shared OPFS failure'})
            .mockResolvedValueOnce({status: 'ok', bytes: sharedHeader})
            .mockResolvedValueOnce({status: 'ok', bytes: glossaryBytes});
        Reflect.set(database, '_termContentBlockStore', {readDetailed});
        const markDictionaryReimportRequired = vi.spyOn(
            Reflect.get(database, '_termRecordStore'),
            'markDictionaryReimportRequired',
        );
        const deserialize = Reflect.get(database, '_deserializeTermRow').bind(database);
        const row = {
            id: 1,
            dictionary: 'JMdict',
            expression: '日本',
            reading: 'にほん',
            entryContentId: null,
            entryContentOffset: 10,
            entryContentLength: sharedHeader.byteLength,
            entryContentDictName: RAW_TERM_CONTENT_SHARED_GLOSSARY_DICT_NAME,
            score: 1,
            sequence: 1,
        };

        await expect(deserialize(row)).rejects.toThrow('temporarily unavailable');
        expect(markDictionaryReimportRequired).not.toHaveBeenCalled();
        expect(Reflect.get(database, '_termEntryContentCache').size).toBe(0);

        await expect(deserialize(row)).resolves.toMatchObject({glossary: ['shared definition']});
        expect(readDetailed).toHaveBeenCalledTimes(4);
        expect(Reflect.get(database, '_termEntryContentCache').size).toBe(1);
    });

    test('marks confirmed term-content corruption as requiring reimport', async () => {
        const database = new DictionaryDatabase();
        Reflect.set(database, '_termContentBlockStore', {
            readDetailed: vi.fn(async () => ({status: 'corrupt', reason: 'injected checksum mismatch'})),
        });
        const markDictionaryReimportRequired = vi.spyOn(
            Reflect.get(database, '_termRecordStore'),
            'markDictionaryReimportRequired',
        );
        const deserialize = Reflect.get(database, '_deserializeTermRow').bind(database);

        await expect(deserialize({
            id: 1,
            dictionary: 'JMdict',
            expression: '日本',
            reading: 'にほん',
            entryContentId: null,
            entryContentOffset: 10,
            entryContentLength: 20,
            entryContentDictName: 'raw-block-v2',
            score: 1,
            sequence: 1,
        })).rejects.toThrow('must be re-imported');
        expect(markDictionaryReimportRequired).toHaveBeenCalledWith('JMdict', 'injected checksum mismatch');
        expect(Reflect.get(database, '_termEntryContentCache').size).toBe(0);
    });

    test('keeps exact hash-pair matches distinct through collisions and resize', () => {
        const database = new DictionaryDatabase();
        Reflect.set(database, '_getTermEntryContentMetaHashPairSlot', () => 0);

        for (let i = 0; i < 64; ++i) {
            cacheMeta(database, null, i * 10, i + 1, `raw-${i}`, 0x1000 + i, 0x2000 + (i * 17));
        }

        expect(Reflect.get(database, '_termEntryContentMetaHashPairCount')).toBe(64);
        for (let i = 0; i < 64; ++i) {
            expect(getMeta(database, 0x1000 + i, 0x2000 + (i * 17))).toMatchObject({
                offset: i * 10,
                length: i + 1,
                dictName: `raw-${i}`,
            });
        }
        expect(getMeta(database, 0x1000, 0x2001)).toBeUndefined();
        expect(getMeta(database, 0x1999, 0x2000)).toBeUndefined();
        expect(Reflect.get(database, '_termEntryContentMetaHashPairTable')).toBeInstanceOf(Uint32Array);
        expect(Reflect.get(database, '_termEntryContentMetaStateTable')).toBeInstanceOf(Uint8Array);
        expect(Reflect.get(database, '_termEntryContentMetaOffsetTable')).toBeInstanceOf(Float64Array);
        expect(Reflect.get(database, '_termEntryContentMetaLengthTable')).toBeInstanceOf(Uint32Array);
        expect(Reflect.get(database, '_termEntryContentMetaDictNameIdTable')).toBeInstanceOf(Uint32Array);
        expect(Reflect.get(database, '_termEntryContentMetaHashPairTable').length).toBeGreaterThan(
            Reflect.get(database, '_termEntryContentMetaOffsetTable').length,
        );
    });

    test('preserves large offsets and signatures through typed-table resizes', async () => {
        const database = new DictionaryDatabase();
        const cache = Reflect.get(database, '_cacheTermEntryContentMeta').bind(database);
        const findMatching = Reflect.get(database, '_findMatchingTermEntryContentMeta').bind(database);
        const contentBytes = new Uint8Array([1, 2, 3, 4, 5, 6, 7, 8]);
        const largeOffset = 0x100000000 + 123;
        Reflect.set(database, '_readTermEntryContentBytesDetailed', vi.fn(async () => ({status: 'ok', bytes: contentBytes})));
        cache(null, largeOffset, contentBytes.byteLength, 'raw-block-v1:jmdict', 0, 123, 456, contentBytes);
        for (let i = 0; i < 128; ++i) {
            cacheMeta(database, null, i * 10, i + 1, `raw-${i}`, 1000 + i, 2000 + i);
        }

        expect(getMeta(database, 123, 456)).toMatchObject({
            offset: largeOffset,
            length: contentBytes.byteLength,
            dictName: 'raw-block-v1:jmdict',
        });
        await expect(findMatching(123, 456, new Uint8Array(contentBytes))).resolves.toMatchObject({offset: largeOffset});
    });

    test('preallocates bounded metadata capacity using the parser unique ratio', () => {
        const database = new DictionaryDatabase();
        const getCapacityHint = Reflect.get(database, '_getArtifactTermContentMetaCapacityHint').bind(database);

        expect(getCapacityHint({
            rowCount: 250,
            dictionaryTotalRows: 1000,
            contentDedupPlan: {sourceRowCount: 250, uniqueCount: 125},
        }, 125)).toBe(500);
        expect(getCapacityHint({
            rowCount: 100,
            dictionaryTotalRows: 10_000,
            contentDedupPlan: {sourceRowCount: 100, uniqueCount: 90},
        }, 90)).toBe(9000);
        expect(getCapacityHint({
            rowCount: 100,
            dictionaryTotalRows: 10_000_000,
            contentDedupPlan: {sourceRowCount: 100, uniqueCount: 100},
        }, 100)).toBe(1024 * 1024);
        expect(getCapacityHint({
            rowCount: 100,
            dictionaryTotalRows: 1000,
            contentDedupPlan: {sourceRowCount: 0, uniqueCount: 50},
        }, 50)).toBe(50);

        cacheMeta(database, null, 0, 1, 'raw', 1, 2);
        expect(getCapacityHint({
            rowCount: 250,
            dictionaryTotalRows: 1000,
            contentDedupPlan: {sourceRowCount: 250, uniqueCount: 125},
        }, 125)).toBe(126);
    });

    test('keeps staged metadata invisible until persisted offsets are published', () => {
        const database = new DictionaryDatabase();
        const stage = Reflect.get(database, '_stageArtifactTermContentMetadata').bind(database);
        const publish = Reflect.get(database, '_publishArtifactTermContentMetadata').bind(database);
        const contentBytes = new Uint8Array([1, 2, 3, 4, 5]);
        const stagedContentMetadata = stage([101], [202], [contentBytes], null);

        expect(getMeta(database, 101, 202)).toBeUndefined();
        expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(1);
        publish({
            count: 1,
            contentOffsets: new Float64Array(1),
            contentLengths: new Uint32Array(1),
            resolvedContentDictNames: 'raw',
            pendingRowToUniqueIndex: new Int32Array([0]),
            pendingContentBytes: [contentBytes],
            pendingContentHash1s: [101],
            pendingContentHash2s: [202],
            pendingOffsets: [1234],
            pendingLengths: [contentBytes.byteLength],
            pendingResolvedDictNames: 'raw',
            pendingContentSpans: null,
            stagedContentMetadata,
        });

        expect(getMeta(database, 101, 202)).toMatchObject({
            offset: 1234,
            length: contentBytes.byteLength,
            dictName: 'raw',
        });
        expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(0);
        expect(Reflect.get(database, '_termEntryContentMetaHashPairCount')).toBe(1);
    });

    test('retains colliding published keys through free-ID reuse and pending rehash rollback', () => {
        const database = new DictionaryDatabase();
        Reflect.set(database, '_getTermEntryContentMetaHashPairSlot', () => 0);
        const stage = Reflect.get(database, '_stageArtifactTermContentMetadata').bind(database);
        const rollback = Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').bind(database);
        const ensureCapacity = Reflect.get(database, '_ensureTermEntryContentMetaHashPairCapacity').bind(database);
        const bytes = new Uint8Array([1, 2, 3]);
        for (const key of [10, 20, 30]) { cacheMeta(database, null, key * 100, 3, 'raw', key, key + 1); }
        const abandoned = stage([40, 50], [41, 51], [bytes, bytes], null);
        rollback(abandoned);
        const staged = stage([60], [61], [bytes], null);
        expect([...abandoned.indexes]).toContain(staged.indexes[0]);

        ensureCapacity(128);
        for (const key of [10, 20, 30]) {
            expect(getMeta(database, key, key + 1)).toMatchObject({offset: key * 100, length: 3});
        }
        for (const key of [40, 50, 60]) { expect(getMeta(database, key, key + 1)).toBeUndefined(); }
        expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(1);
        rollback(staged);
        expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(0);
        for (const key of [10, 20, 30]) {
            expect(getMeta(database, key, key + 1)).toMatchObject({offset: key * 100, length: 3});
        }
        publishSlabMeta(database, bytes, 0, 3, 60, 61);
        ensureCapacity(128);
        expect(getMeta(database, 60, 61)).toMatchObject({offset: 1060, length: 3});
        expect(Reflect.get(database, '_termEntryContentMetaHashPairCount')).toBe(4);
    });

    test('rehashes a sparse arena after a large reservation is rolled back', () => {
        const database = new DictionaryDatabase();
        const stage = Reflect.get(database, '_stageArtifactTermContentMetadata').bind(database);
        const rollback = Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').bind(database);
        const ensureCapacity = Reflect.get(database, '_ensureTermEntryContentMetaHashPairCapacity').bind(database);
        const bytes = new Uint8Array([1, 2, 3]);
        const hashes = Array.from({length: 200}, (_, i) => i + 1);
        const abandoned = stage(hashes, hashes, hashes.map(() => bytes), null);
        rollback(abandoned);
        const slots = Reflect.get(database, '_termEntryContentMetaHashPairTable');
        expect(Reflect.get(database, '_termEntryContentMetaDenseCount')).toBeGreaterThan(slots.length);
        publishSlabMeta(database, bytes, 0, 3, 1001, 1002);
        ensureCapacity(128);
        expect(getMeta(database, 1001, 1002)).toMatchObject({offset: 2001, length: 3});
        for (const hash of hashes) { expect(getMeta(database, hash, hash)).toBeUndefined(); }
        expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(0);
        expect(Reflect.get(database, '_termEntryContentMetaHashPairCount')).toBe(1);
    });

    test('keeps staged dense indexes stable across hash-table rehashes', () => {
        const database = new DictionaryDatabase();
        const stage = Reflect.get(database, '_stageArtifactTermContentMetadata').bind(database);
        const ensureCapacity = Reflect.get(database, '_ensureTermEntryContentMetaHashPairCapacity').bind(database);
        const publish = Reflect.get(database, '_publishArtifactTermContentMetadata').bind(database);
        const contentBytes = new Uint8Array([1, 2, 3, 4]);
        const staged = stage([101], [202], [contentBytes], null);
        const denseIndex = staged.indexes[0];
        const oldHashSlots = Reflect.get(database, '_termEntryContentMetaHashPairTable');

        ensureCapacity(128);

        expect(Reflect.get(database, '_termEntryContentMetaHashPairTable')).not.toBe(oldHashSlots);
        expect(staged.indexes[0]).toBe(denseIndex);
        publish({
            count: 1,
            contentOffsets: new Float64Array(1),
            contentLengths: new Uint32Array(1),
            resolvedContentDictNames: 'raw',
            pendingRowToUniqueIndex: new Int32Array([0]),
            pendingContentBytes: [contentBytes],
            pendingContentHash1s: [101],
            pendingContentHash2s: [202],
            pendingOffsets: [9876],
            pendingLengths: [contentBytes.byteLength],
            pendingResolvedDictNames: 'raw',
            pendingContentSpans: null,
            stagedContentMetadata: staged,
        });
        expect(getMeta(database, 101, 202)).toMatchObject({offset: 9876, length: 4});
    });

    test('rejects untrusted persisted offsets before publishing staged metadata', () => {
        const database = new DictionaryDatabase();
        const stage = Reflect.get(database, '_stageArtifactTermContentMetadata').bind(database);
        const publish = Reflect.get(database, '_publishArtifactTermContentMetadata').bind(database);
        const rollback = Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').bind(database);
        const contentBytes = new Uint8Array([1, 2, 3]);
        const stagedContentMetadata = stage([101], [202], [contentBytes], null);

        expect(() => publish({
            count: 1,
            contentOffsets: new Float64Array(1),
            contentLengths: new Uint32Array(1),
            resolvedContentDictNames: 'raw',
            pendingRowToUniqueIndex: new Int32Array([0]),
            pendingContentBytes: [contentBytes],
            pendingContentHash1s: [101],
            pendingContentHash2s: [202],
            pendingOffsets: [-1],
            pendingLengths: [contentBytes.byteLength],
            pendingResolvedDictNames: 'raw',
            pendingContentSpans: null,
            stagedContentMetadata,
        })).toThrow('Invalid term content metadata offset');

        rollback(stagedContentMetadata);
        expect(getMeta(database, 101, 202)).toBeUndefined();
    });

    test('clears unpublished staged metadata after persistence failure', () => {
        const database = new DictionaryDatabase();
        const stage = Reflect.get(database, '_stageArtifactTermContentMetadata').bind(database);
        const clear = Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').bind(database);
        const staged = stage(
            [101, 303],
            [202, 404],
            [new Uint8Array([1]), new Uint8Array([2])],
            null,
        );

        clear(staged);

        expect(getMeta(database, 101, 202)).toBeUndefined();
        expect(getMeta(database, 303, 404)).toBeUndefined();
        expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(0);
        expect(Reflect.get(database, '_termEntryContentMetaHashPairCount')).toBe(0);
    });

    test('rolls back already-published staged metadata without losing prior entries', () => {
        const database = new DictionaryDatabase();
        cacheMeta(database, null, 50, 3, 'raw', 11, 22);
        const stage = Reflect.get(database, '_stageArtifactTermContentMetadata').bind(database);
        const publish = Reflect.get(database, '_publishArtifactTermContentMetadata').bind(database);
        const rollback = Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').bind(database);
        const contentBytes = new Uint8Array([9, 8, 7, 6]);
        const stagedContentMetadata = stage([101], [202], [contentBytes], null);
        publish({
            count: 1,
            contentOffsets: new Float64Array(1),
            contentLengths: new Uint32Array(1),
            resolvedContentDictNames: 'raw',
            pendingRowToUniqueIndex: new Int32Array([0]),
            pendingContentBytes: [contentBytes],
            pendingContentHash1s: [101],
            pendingContentHash2s: [202],
            pendingOffsets: [1234],
            pendingLengths: [contentBytes.byteLength],
            pendingResolvedDictNames: 'raw',
            pendingContentSpans: null,
            stagedContentMetadata,
        });

        rollback(stagedContentMetadata);
        rollback(stagedContentMetadata);

        expect(getMeta(database, 101, 202)).toBeUndefined();
        expect(getMeta(database, 11, 22)).toMatchObject({offset: 50, length: 3});
        expect(Reflect.get(database, '_termEntryContentMetaHashPairCount')).toBe(1);
    });

    test('rolls back parser-verified hash collisions with staged metadata', async () => {
        const database = new DictionaryDatabase();
        const stage = Reflect.get(database, '_stageArtifactTermContentMetadata').bind(database);
        const publish = Reflect.get(database, '_publishArtifactTermContentMetadata').bind(database);
        const rollback = Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').bind(database);
        const findMatching = Reflect.get(database, '_findMatchingTermEntryContentMeta').bind(database);
        const first = new Uint8Array([1, 2, 3, 4, 5]);
        const second = new Uint8Array([6, 7, 8, 9, 10]);
        Reflect.set(database, '_readTermEntryContentBytesDetailed', vi.fn(async (offset) => ({
            status: 'ok',
            bytes: offset === 1000 ? first : second,
        })));
        const staged = stage([101, 101], [202, 202], [first, second], null);

        expect([...staged.indexes]).toEqual([0, -1]);
        publish({
            count: 2,
            contentOffsets: new Float64Array(2),
            contentLengths: new Uint32Array(2),
            resolvedContentDictNames: 'raw',
            pendingRowToUniqueIndex: new Int32Array([0, 1]),
            pendingContentBytes: [first, second],
            pendingContentHash1s: [101, 101],
            pendingContentHash2s: [202, 202],
            pendingOffsets: [1000, 2000],
            pendingLengths: [first.byteLength, second.byteLength],
            pendingResolvedDictNames: 'raw',
            pendingContentSpans: null,
            stagedContentMetadata: staged,
        });

        await expect(findMatching(101, 202, first)).resolves.toMatchObject({offset: 1000});
        await expect(findMatching(101, 202, second)).resolves.toMatchObject({offset: 2000});
        rollback(staged);
        expect(findMatching(101, 202, first)).toBeUndefined();
        expect(findMatching(101, 202, second)).toBeUndefined();
        expect(Reflect.get(database, '_termEntryContentMetaCollisionsByHashPair').size).toBe(0);
    });

    test('updates existing hash pairs without growing the cache', () => {
        const database = new DictionaryDatabase();

        cacheMeta(database, null, 10, 5, 'raw', 0xabcdef01, 0x12345678);
        cacheMeta(database, null, 20, 7, 'raw-v3', 0xabcdef01, 0x12345678);

        expect(Reflect.get(database, '_termEntryContentMetaHashPairCount')).toBe(1);
        expect(getMeta(database, 0xabcdef01, 0x12345678)).toMatchObject({
            offset: 20,
            length: 7,
            dictName: 'raw-v3',
        });
    });

    test('uses content signatures to disambiguate identical hash pairs', async () => {
        const database = new DictionaryDatabase();
        const cache = Reflect.get(database, '_cacheTermEntryContentMeta').bind(database);
        const findMatching = Reflect.get(database, '_findMatchingTermEntryContentMeta').bind(database);
        const firstBytes = new Uint8Array([1, 2, 3]);
        const secondBytes = new Uint8Array([1, 2, 4]);
        Reflect.set(database, '_readTermEntryContentBytesDetailed', vi.fn(async (offset) => ({
            status: 'ok',
            bytes: offset === 10 ? firstBytes : secondBytes,
        })));

        cache(null, 10, firstBytes.byteLength, 'raw', 0, 123, 456, firstBytes);
        expect(findMatching(123, 456, secondBytes)).toBeUndefined();
        cache(null, 20, secondBytes.byteLength, 'raw', 0, 123, 456, secondBytes);

        await expect(findMatching(123, 456, firstBytes)).resolves.toMatchObject({offset: 10});
        await expect(findMatching(123, 456, secondBytes)).resolves.toMatchObject({offset: 20});
    });

    test('retains byte-distinct same-hash candidates with identical sampled signatures', async () => {
        const database = new DictionaryDatabase();
        const cache = Reflect.get(database, '_cacheTermEntryContentMeta').bind(database);
        const findMatching = Reflect.get(database, '_findMatchingTermEntryContentMeta').bind(database);
        const firstBytes = Uint8Array.from({length: 16}, (_, index) => index);
        const secondBytes = Uint8Array.from(firstBytes);
        // The three sampled signatures cover offsets 0..3, 6..9, and 12..15.
        // Change only an unsampled byte so both candidates have identical
        // signatures despite different exact content.
        secondBytes[4] ^= 0xff;
        Reflect.set(database, '_readTermEntryContentBytesDetailed', vi.fn(async (offset) => ({
            status: 'ok',
            bytes: offset === 10 ? firstBytes : secondBytes,
        })));

        cache(null, 10, firstBytes.byteLength, 'raw', 0, 123, 456, firstBytes);
        cache(null, 20, secondBytes.byteLength, 'raw', 0, 123, 456, secondBytes);

        await expect(findMatching(123, 456, firstBytes)).resolves.toMatchObject({offset: 10});
        await expect(findMatching(123, 456, secondBytes)).resolves.toMatchObject({offset: 20});
        expect(Reflect.get(database, '_termEntryContentMetaCollisionsByHashPair').get('123:456')).toHaveLength(1);
    });

    test('does not trust matching hashes and sampled signatures without exact bytes', async () => {
        const database = new DictionaryDatabase();
        const cache = Reflect.get(database, '_cacheTermEntryContentMeta').bind(database);
        const findMatching = Reflect.get(database, '_findMatchingTermEntryContentMeta').bind(database);
        const persistedBytes = Uint8Array.from({length: 16}, (_, index) => index);
        const collidingBytes = new Uint8Array(persistedBytes);
        collidingBytes[4] ^= 0xff;
        Reflect.set(database, '_readTermEntryContentBytesDetailed', vi.fn(async () => ({status: 'ok', bytes: persistedBytes})));

        cache(null, 10, persistedBytes.byteLength, 'raw', 0, 123, 456, persistedBytes);

        await expect(findMatching(123, 456, collidingBytes)).resolves.toBeUndefined();
    });

    test.each(['temporarilyUnavailable', 'corrupt'])('fails closed when exact persisted content is %s', async (status) => {
        const database = new DictionaryDatabase();
        const cache = Reflect.get(database, '_cacheTermEntryContentMeta').bind(database);
        const findMatching = Reflect.get(database, '_findMatchingTermEntryContentMeta').bind(database);
        const contentBytes = new Uint8Array([1, 2, 3, 4]);
        Reflect.set(database, '_readTermEntryContentBytesDetailed', vi.fn(async () => ({status, reason: 'injected read failure'})));
        cache(null, 10, contentBytes.byteLength, 'raw', 0, 123, 456, contentBytes);

        await expect(findMatching(123, 456, new Uint8Array(contentBytes))).rejects.toMatchObject({
            name: 'TermContentLookupReadError',
            status,
        });
    });

    test('exactly compares persisted candidates which predate content signatures', async () => {
        const database = new DictionaryDatabase();
        const cache = Reflect.get(database, '_cacheTermEntryContentMeta').bind(database);
        const findMatching = Reflect.get(database, '_findMatchingTermEntryContentMeta').bind(database);
        const persistedBytes = new Uint8Array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]);
        const collidingBytes = Uint8Array.from(persistedBytes);
        collidingBytes[5] = 99;
        Reflect.set(database, '_readTermEntryContentBytesDetailed', vi.fn(async () => ({status: 'ok', bytes: persistedBytes})));

        cache(null, 10, persistedBytes.byteLength, 'raw', 0, 123, 456);

        const result = findMatching(123, 456, collidingBytes);
        expect(result).toBeInstanceOf(Promise);
        await expect(result).resolves.toBeUndefined();
    });

    test('exactly compares persisted block content after a database reload', async () => {
        const database = new DictionaryDatabase();
        const cache = Reflect.get(database, '_cacheTermEntryContentMeta').bind(database);
        const findMatching = Reflect.get(database, '_findMatchingTermEntryContentMeta').bind(database);
        const persistedBytes = new Uint8Array([1, 2, 3, 4]);
        const readTermEntryContentBytesDetailed = vi.fn(async () => ({status: 'ok', bytes: persistedBytes}));
        Reflect.set(database, '_readTermEntryContentBytesDetailed', readTermEntryContentBytesDetailed);

        cache(null, 10, persistedBytes.byteLength, 'raw-block-v1:jmdict', 0, 123, 456);

        const result = findMatching(123, 456, Uint8Array.from(persistedBytes));
        expect(result).toBeInstanceOf(Promise);
        await expect(result).resolves.toMatchObject({offset: 10, dictName: 'raw-block-v1:jmdict'});
        expect(readTermEntryContentBytesDetailed).toHaveBeenCalledWith(10, persistedBytes.byteLength, 'raw-block-v1:jmdict');
    });

    test('returns synchronously when a hash pair has no persisted candidate', () => {
        const database = new DictionaryDatabase();
        const findMatching = Reflect.get(database, '_findMatchingTermEntryContentMeta').bind(database);

        const result = findMatching(123, 456, new Uint8Array([1, 2, 3]));

        expect(result).toBeUndefined();
    });

    test('parses string content hashes into the numeric cache and clears both indexes', () => {
        const database = new DictionaryDatabase();
        const clearBlockCache = vi.spyOn(Reflect.get(database, '_termContentBlockStore'), 'clearCache');
        const clearTermEntryContentMetaCaches = /** @type {(this: DictionaryDatabase) => void} */ (
            Reflect.get(database, '_clearTermEntryContentMetaCaches')
        );

        cacheMeta(database, '0000000100000002', 30, 9, 'raw', -1, -1);
        expect(getMeta(database, 1, 2)).toMatchObject({offset: 30, length: 9, dictName: 'raw'});
        expect(Reflect.get(database, '_termEntryContentMetaByHash').get('0000000100000002')).toMatchObject({
            offset: 30,
            length: 9,
            dictName: 'raw',
        });

        clearTermEntryContentMetaCaches.call(database);
        expect(getMeta(database, 1, 2)).toBeUndefined();
        expect(Reflect.get(database, '_termEntryContentMetaByHash').size).toBe(0);
        expect(Reflect.get(database, '_termEntryContentMetaHashPairCount')).toBe(0);
        expect(clearBlockCache).toHaveBeenCalledOnce();
    });
});

describe('DictionaryDatabase artifact term content dedup import', () => {
    test('compares content bytes across unrolled-loop boundaries', () => {
        const database = new DictionaryDatabase();
        const compare = Reflect.get(database, '_termContentBytesEqual').bind(database);
        for (const length of [0, 1, 7, 8, 9, 15, 16, 17, 63, 64, 65]) {
            const a = new Uint8Array(length);
            const b = new Uint8Array(length);
            for (let i = 0; i < length; ++i) {
                a[i] = i & 0xff;
                b[i] = i & 0xff;
            }
            expect(compare(a, b)).toBe(true);
            for (const index of new Set([0, Math.floor(length / 2), length - 1])) {
                if (index < 0 || index >= length) { continue; }
                b[index] ^= 0xff;
                expect(compare(a, b)).toBe(false);
                b[index] ^= 0xff;
            }
        }
        expect(compare(new Uint8Array(8), new Uint8Array(9))).toBe(false);
    });

    test('compares bounded content spans', () => {
        const database = new DictionaryDatabase();
        const compare = Reflect.get(database, '_termContentBytesEqualSpan').bind(database);
        const buffer = new Uint8Array([9, 1, 2, 3, 8, 1, 2, 4, 7]);

        expect(compare(new Uint8Array([1, 2, 3]), buffer, 1, 3)).toBe(true);
        expect(compare(new Uint8Array([1, 2, 3]), buffer, 5, 3)).toBe(false);
        expect(compare(new Uint8Array([1, 2]), buffer, 1, 3)).toBe(false);
    });

    test('deduplicates slab content while materializing only unique views', async () => {
        const database = new DictionaryDatabase();
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const buffer = new Uint8Array([99, 1, 2, 3, 1, 2, 4, 1, 2, 3, 88]);
        const result = await resolve(/** @type {ArtifactTermContentChunkWithExtras} */ ({
            rowCount: 3,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: buffer,
            contentBytesBaseOffset: 1,
            contentMetaList: new Uint32Array([
                0,
                3,
                10,
                20,
                3,
                3,
                10,
                20,
                6,
                3,
                10,
                20,
            ]),
            contentDictNameList: null,
            uniformContentDictName: 'raw',
        }));

        expect(result.pendingContentBytes).toHaveLength(2);
        expect([...result.pendingContentBytes[0]]).toEqual([1, 2, 3]);
        expect([...result.pendingContentBytes[1]]).toEqual([1, 2, 4]);
        const pendingRowToUniqueIndex = result.pendingRowToUniqueIndex;
        if (pendingRowToUniqueIndex === null) { throw new Error('Expected pending row indexes'); }
        expect([...pendingRowToUniqueIndex]).toEqual([0, 1, 0]);
        expect(result.pendingHitCount).toBe(1);

        await expect(resolve({
            rowCount: 1,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: buffer,
            contentBytesBaseOffset: 1,
            contentMetaList: new Uint32Array([buffer.byteLength, 1, 10, 20]),
            contentDictNameList: null,
            uniformContentDictName: 'raw',
        })).rejects.toThrow('Artifact term content bytes are invalid at row 0');
    });

    test('skips persisted probes only when a native bank plan starts against an empty store', async () => {
        const database = new DictionaryDatabase();
        const findPersistedIndex = vi.spyOn(
            /** @type {DictionaryDatabase & {_findTermEntryContentMetaHashPairIndex: (hash1: number, hash2: number) => number}} */ (database),
            '_findTermEntryContentMetaHashPairIndex',
        );
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const plan = {
            resolvedFlags: new Uint8Array(2),
            resolvedOffsets: new Float64Array(2),
            resolvedLengths: new Uint32Array(2),
            resolvedDictNames: new Array(2),
            pendingEpochs: new Uint32Array(2),
            pendingIndexes: new Uint32Array(2),
            nextEpoch: 1,
            persistedLookupRequired: null,
        };
        /**
         * @param {number} uniqueIndex
         * @param {number} byte
         * @param {number} hash
         * @returns {ArtifactTermContentChunk}
         */
        const makeChunk = (uniqueIndex, byte, hash) => ({
            rowCount: 1,
            contentBytesList: [new Uint8Array([byte])],
            contentHash1List: new Uint32Array([hash]),
            contentHash2List: new Uint32Array([hash + 1]),
            contentUniqueIndexList: new Uint32Array([uniqueIndex]),
            contentDedupPlan: plan,
            contentDictNameList: null,
            uniformContentDictName: 'raw',
        });

        await resolve(makeChunk(0, 1, 10));
        cacheMeta(database, null, 100, 1, 'raw', 99, 100);
        findPersistedIndex.mockClear();
        await resolve(makeChunk(1, 2, 20));

        expect(plan.persistedLookupRequired).toBe(false);
        expect(findPersistedIndex).not.toHaveBeenCalled();

        const secondDatabase = new DictionaryDatabase();
        cacheMeta(secondDatabase, null, 200, 1, 'raw', 30, 31);
        Reflect.set(secondDatabase, '_readTermEntryContentBytesDetailed', vi.fn(async () => ({
            status: 'ok',
            bytes: new Uint8Array([3]),
        })));
        const secondFindPersistedIndex = vi.spyOn(
            /** @type {DictionaryDatabase & {_findTermEntryContentMetaHashPairIndex: (hash1: number, hash2: number) => number}} */ (secondDatabase),
            '_findTermEntryContentMetaHashPairIndex',
        );
        const secondResolve = Reflect.get(secondDatabase, '_resolveArtifactTermContentDedup').bind(secondDatabase);
        const secondPlan = {
            ...plan,
            resolvedFlags: new Uint8Array(1),
            resolvedOffsets: new Float64Array(1),
            resolvedLengths: new Uint32Array(1),
            resolvedDictNames: new Array(1),
            pendingEpochs: new Uint32Array(1),
            pendingIndexes: new Uint32Array(1),
            nextEpoch: 1,
            persistedLookupRequired: null,
        };
        await secondResolve({
            ...makeChunk(0, 3, 30),
            contentDedupPlan: secondPlan,
        });

        expect(secondPlan.persistedLookupRequired).toBe(true);
        expect(secondFindPersistedIndex).toHaveBeenCalled();
    });

    test('resolves empty-store native unique indexes as contiguous ranges across chunks', async () => {
        const database = new DictionaryDatabase();
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const plan = {
            uniqueCount: 2,
            resolvedFlags: new Uint8Array([1, 0]),
            resolvedOffsets: new Float64Array([123, 0]),
            resolvedLengths: new Uint32Array([3, 0]),
            resolvedDictNames: null,
            resolvedUniformDictName: 'raw-block-v1:jmdict',
            pendingEpochs: new Uint32Array(2),
            pendingIndexes: new Uint32Array(2),
            nextEpoch: 1,
            nextUnresolvedUniqueIndex: 1,
            persistedLookupRequired: false,
        };
        const first = new Uint8Array([1, 2, 3]);
        const second = new Uint8Array([4, 5]);
        const result = await resolve({
            rowCount: 3,
            contentBytesList: [first, second, second],
            contentHash1List: new Uint32Array([10, 30, 30]),
            contentHash2List: new Uint32Array([20, 40, 40]),
            contentUniqueIndexList: new Uint32Array([0, 1, 1]),
            contentDedupPlan: plan,
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        });

        expect(result.pendingContentBytes).toEqual([second]);
        expect(result.pendingRowToUniqueIndex).toBeNull();
        expect(result.pendingPlanUniqueStart).toBe(1);
        expect(result.pendingHitCount).toBe(2);
        expect(result.contentOffsets[0]).toBe(123);
        expect(result.contentLengths[0]).toBe(3);
        expect(result.resolvedContentDictNames).toEqual(['raw-block-v1:jmdict', void 0, void 0]);
        expect(plan.nextUnresolvedUniqueIndex).toBe(2);
    });

    test('keeps empty-store native unique content as shared slab spans', async () => {
        const database = new DictionaryDatabase();
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const source = new Uint8Array([99, 1, 2, 3, 4, 5, 88]);
        const plan = /** @type {ArtifactTermContentDedupPlan} */ ({
            uniqueCount: 2,
            resolvedFlags: new Uint8Array(2),
            resolvedOffsets: new Float64Array(2),
            resolvedLengths: new Uint32Array(2),
            resolvedDictNames: new Array(2),
            pendingEpochs: new Uint32Array(2),
            pendingIndexes: new Uint32Array(2),
            nextEpoch: 1,
            nextUnresolvedUniqueIndex: 0,
            persistedLookupRequired: false,
        });

        const result = await resolve({
            rowCount: 3,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 1,
            contentMetaList: new Uint32Array([
                0,
                3,
                10,
                20,
                3,
                2,
                30,
                40,
                3,
                2,
                30,
                40,
            ]),
            contentUniqueIndexList: new Uint32Array([0, 1, 1]),
            contentDedupPlan: plan,
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        });

        expect(result.pendingContentBytes).toHaveLength(0);
        expect(result.pendingContentCount).toBe(2);
        const pendingContentSpans = result.pendingContentSpans;
        if (pendingContentSpans === null) { throw new Error('Expected pending content spans'); }
        expect(pendingContentSpans.buffer).toBe(source);
        expect([...pendingContentSpans.offsets]).toEqual([1, 4]);
        expect([...pendingContentSpans.lengths]).toEqual([3, 2]);
        expect(result.pendingRowToUniqueIndex).toBeNull();
        expect(result.pendingHitCount).toBe(1);
        expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(0);

        const offsetScratch = plan.pendingSpanOffsetsScratch;
        const lengthScratch = plan.pendingSpanLengthsScratch;
        plan.resolvedFlags.fill(1);
        plan.resolvedOffsets.set([100, 200]);
        plan.resolvedLengths.set([3, 2]);
        if (plan.resolvedDictNames === null) { throw new Error('Expected resolved dictionary names'); }
        plan.resolvedDictNames.splice(0, 2, 'raw-v6', 'raw-v6');
        const repeated = await resolve({
            rowCount: 1,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 1,
            contentMetaList: new Uint32Array([0, 3, 10, 20]),
            contentUniqueIndexList: new Uint32Array([0]),
            contentDedupPlan: plan,
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        });
        expect(plan.pendingSpanOffsetsScratch).toBe(offsetScratch);
        expect(plan.pendingSpanLengthsScratch).toBe(lengthScratch);
        expect(repeated.pendingContentCount).toBe(0);
        expect(repeated.contentOffsets[0]).toBe(plan.resolvedOffsets[0]);
    });

    test('keeps resolver-reserved native metadata invisible until publication', async () => {
        const database = new DictionaryDatabase();
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const rollback = Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').bind(database);
        const source = new Uint8Array([1, 2, 3]);
        const result = await resolve(/** @type {ArtifactTermContentChunkWithExtras} */ ({
            dictionary: 'JMdict',
            rowCount: 1,
            dictionaryTotalRows: 1,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 0,
            contentMetaList: new Uint32Array([0, 3, 10, 20]),
            contentUniqueIndexList: new Uint32Array([0]),
            contentDedupPlan: {
                uniqueCount: 1,
                sourceRowCount: 1,
                resolvedFlags: new Uint8Array(1),
                resolvedOffsets: new Float64Array(1),
                resolvedLengths: new Uint32Array(1),
                resolvedDictNames: null,
                pendingEpochs: new Uint32Array(1),
                pendingIndexes: new Uint32Array(1),
                nextEpoch: 1,
                nextUnresolvedUniqueIndex: 0,
                persistedLookupRequired: false,
            },
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        }), true);

        expect(result.stagedContentMetadata?.indexes[0]).toBeGreaterThanOrEqual(0);
        expect(getMeta(database, 10, 20)).toBeUndefined();
        expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(1);
        const stagedContentMetadata = result.stagedContentMetadata;
        if (typeof stagedContentMetadata === 'undefined') { throw new Error('Expected staged metadata'); }
        rollback(stagedContentMetadata);
        expect(Reflect.get(database, '_termEntryContentMetaHashPairPendingCount')).toBe(0);
    });

    test('projects persisted native-plan metadata without allocating a row map', () => {
        const database = new DictionaryDatabase();
        Reflect.get(database, '_ensureTermEntryContentMetaHashPairCapacity').call(database, 2);
        const publish = Reflect.get(database, '_publishArtifactTermContentMetadata').bind(database);
        const contentOffsets = new Float64Array(3);
        const contentLengths = new Uint32Array(3);
        const first = new Uint8Array([1, 2, 3]);
        const second = new Uint8Array([4, 5, 6, 7]);
        const resolvedContentDictNames = publish({
            count: 3,
            contentOffsets,
            contentLengths,
            resolvedContentDictNames: 'raw',
            pendingRowToUniqueIndex: null,
            pendingContentBytes: [first, second],
            pendingContentHash1s: [11, 22],
            pendingContentHash2s: [33, 44],
            pendingOffsets: [100, 200],
            pendingLengths: [3, 4],
            pendingResolvedDictNames: 'raw',
            pendingContentSpans: null,
            contentDedupPlan: {
                resolvedFlags: new Uint8Array([1, 1]),
                resolvedOffsets: new Float64Array([100, 200]),
                resolvedLengths: new Uint32Array([3, 4]),
                resolvedDictNames: ['raw', 'raw'],
                pendingEpochs: new Uint32Array(2),
                pendingIndexes: new Uint32Array(2),
                nextEpoch: 1,
            },
            contentUniqueIndexList: new Uint32Array([0, 1, 0]),
        });

        expect([...contentOffsets]).toEqual([100, 200, 100]);
        expect([...contentLengths]).toEqual([3, 4, 3]);
        expect(resolvedContentDictNames).toBe('raw');
        expect(getMeta(database, 11, 33)).toMatchObject({offset: 100, length: 3, dictName: 'raw'});
        expect(getMeta(database, 22, 44)).toMatchObject({offset: 200, length: 4, dictName: 'raw'});
    });

    test('keeps unmatched persisted-plan content as shared slab spans', async () => {
        const database = new DictionaryDatabase();
        cacheMeta(database, null, 400, 1, 'raw', 90, 91);
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const source = new Uint8Array([99, 1, 2, 3, 4, 5, 88]);
        const plan = {
            uniqueCount: 2,
            resolvedFlags: new Uint8Array(2),
            resolvedOffsets: new Float64Array(2),
            resolvedLengths: new Uint32Array(2),
            resolvedDictNames: new Array(2),
            pendingEpochs: new Uint32Array(2),
            pendingIndexes: new Uint32Array(2),
            nextEpoch: 1,
            persistedLookupRequired: true,
        };

        const result = await resolve({
            rowCount: 3,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 1,
            contentMetaList: new Uint32Array([
                0,
                3,
                10,
                20,
                3,
                2,
                30,
                40,
                3,
                2,
                30,
                40,
            ]),
            contentUniqueIndexList: new Uint32Array([0, 1, 1]),
            contentDedupPlan: plan,
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        });

        expect(result.pendingContentBytes).toHaveLength(0);
        expect(result.pendingContentCount).toBe(2);
        const pendingContentSpans = result.pendingContentSpans;
        if (pendingContentSpans === null) { throw new Error('Expected pending content spans'); }
        expect(pendingContentSpans.buffer).toBe(source);
        expect([...pendingContentSpans.offsets]).toEqual([1, 4]);
        expect([...pendingContentSpans.lengths]).toEqual([3, 2]);
        const pendingRowToUniqueIndex = result.pendingRowToUniqueIndex;
        if (pendingRowToUniqueIndex === null) { throw new Error('Expected pending row indexes'); }
        expect([...pendingRowToUniqueIndex]).toEqual([0, 1, 1]);
        expect(result.pendingHitCount).toBe(1);
    });

    test('checks persisted metadata once per parser-verified unique slab content', async () => {
        const database = new DictionaryDatabase();
        const findPersistedIndex = vi.spyOn(
            /** @type {DictionaryDatabase & {_findTermEntryContentMetaHashPairIndex: (hash1: number, hash2: number) => number}} */ (database),
            '_findTermEntryContentMetaHashPairIndex',
        );
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const source = new Uint8Array([99, 1, 2, 3, 4, 5, 88]);
        const plan = {
            uniqueCount: 2,
            sourceRowCount: 3,
            uniqueRowIndexes: new Uint32Array([0, 1]),
            resolvedFlags: new Uint8Array(2),
            resolvedOffsets: new Float64Array(2),
            resolvedLengths: new Uint32Array(2),
            resolvedDictNames: new Array(2),
            pendingEpochs: new Uint32Array(2),
            pendingIndexes: new Uint32Array(2),
            nextEpoch: 1,
            persistedLookupRequired: true,
        };

        const result = await resolve({
            rowCount: 3,
            contentRowStart: 0,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 1,
            contentMetaList: new Uint32Array([
                0,
                3,
                10,
                20,
                3,
                2,
                30,
                40,
                3,
                2,
                30,
                40,
            ]),
            contentUniqueIndexList: new Uint32Array([0, 1, 1]),
            contentDedupPlan: plan,
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        });

        expect(findPersistedIndex).toHaveBeenCalledTimes(2);
        expect(result.pendingContentCount).toBe(2);
        expect(result.pendingRowToUniqueIndex).toBeNull();
        const pendingContentSpans = result.pendingContentSpans;
        if (pendingContentSpans === null) { throw new Error('Expected pending content spans'); }
        expect([...pendingContentSpans.offsets]).toEqual([1, 4]);
        expect([...pendingContentSpans.lengths]).toEqual([3, 2]);
        expect(result.pendingPlanUniqueIndexes).toEqual([0, 1]);
        expect(result.pendingHitCount).toBe(1);
    });

    test('projects one persisted canonical hit onto every duplicate row', async () => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array([99, 1, 2, 3, 1, 2, 3, 88]);
        Reflect.set(database, '_readTermEntryContentBytesDetailed', vi.fn(async () => ({status: 'ok', bytes: source.subarray(1, 4)})));
        Reflect.get(database, '_cacheTermEntryContentMeta').call(
            database,
            null,
            400,
            3,
            'raw-v6',
            0,
            10,
            20,
            source.subarray(1, 4),
        );
        const findPersistedIndex = vi.spyOn(
            /** @type {DictionaryDatabase & {_findTermEntryContentMetaHashPairIndex: (hash1: number, hash2: number) => number}} */ (database),
            '_findTermEntryContentMetaHashPairIndex',
        );
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const result = await resolve({
            rowCount: 2,
            contentRowStart: 0,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 1,
            contentMetaList: new Uint32Array([
                0,
                3,
                10,
                20,
                3,
                3,
                10,
                20,
            ]),
            contentUniqueIndexList: new Uint32Array([0, 0]),
            contentDedupPlan: {
                uniqueCount: 1,
                sourceRowCount: 2,
                uniqueRowIndexes: new Uint32Array([0]),
                resolvedFlags: new Uint8Array(1),
                resolvedOffsets: new Float64Array(1),
                resolvedLengths: new Uint32Array(1),
                resolvedDictNames: new Array(1),
                pendingEpochs: new Uint32Array(1),
                pendingIndexes: new Uint32Array(1),
                nextEpoch: 1,
                persistedLookupRequired: true,
            },
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        });

        expect(findPersistedIndex).toHaveBeenCalledOnce();
        expect(result.pendingContentCount).toBe(0);
        expect(result.persistedHitCount).toBe(1);
        expect([...result.contentOffsets]).toEqual([400, 400]);
        expect([...result.contentLengths]).toEqual([3, 3]);
        expect(result.resolvedContentDictNames).toBe('raw-v6');
    });

    test('resolves persisted canonical contents concurrently while preserving source order', async () => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array([1, 2, 3, 4, 5, 6]);
        const cache = Reflect.get(database, '_cacheTermEntryContentMeta').bind(database);
        cache(null, 100, 3, 'raw-v6', 0, 10, 20, source.subarray(0, 3));
        cache(null, 200, 3, 'raw-v6', 0, 30, 40, source.subarray(3, 6));
        const resolvers = new Map();
        const readDetailed = vi.fn(async (offset) => await new Promise((resolve) => {
            resolvers.set(offset, resolve);
        }));
        Reflect.set(database, '_readTermEntryContentBytesDetailed', readDetailed);
        const resolveDedup = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const resolving = resolveDedup({
            rowCount: 2,
            contentRowStart: 0,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 0,
            contentMetaList: new Uint32Array([0, 3, 10, 20, 3, 3, 30, 40]),
            contentUniqueIndexList: new Uint32Array([0, 1]),
            contentDedupPlan: {
                uniqueCount: 2,
                sourceRowCount: 2,
                uniqueRowIndexes: new Uint32Array([0, 1]),
                resolvedFlags: new Uint8Array(2),
                resolvedOffsets: new Float64Array(2),
                resolvedLengths: new Uint32Array(2),
                resolvedDictNames: new Array(2),
                pendingEpochs: new Uint32Array(2),
                pendingIndexes: new Uint32Array(2),
                nextEpoch: 1,
                persistedLookupRequired: true,
            },
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        });

        await vi.waitFor(() => expect(readDetailed).toHaveBeenCalledTimes(2));
        resolvers.get(200)({status: 'ok', bytes: source.subarray(3, 6)});
        resolvers.get(100)({status: 'ok', bytes: source.subarray(0, 3)});
        const result = await resolving;

        expect(result.persistedHitCount).toBe(2);
        expect(result.exactFallbackCount).toBe(2);
        expect(result.pendingContentCount).toBe(0);
        expect([...result.contentOffsets]).toEqual([100, 200]);
        expect([...result.contentLengths]).toEqual([3, 3]);
    });

    test('bounds concurrent persisted canonical reads to one verification wave', async () => {
        const count = 4097;
        const database = new DictionaryDatabase();
        const source = Uint8Array.from({length: count}, (_, index) => index & 0xff);
        const contentMetaList = new Uint32Array(count * 4);
        const indexes = Uint32Array.from({length: count}, (_, index) => index);
        const cache = Reflect.get(database, '_cacheTermEntryContentMeta').bind(database);
        for (let i = 0; i < count; ++i) {
            const hash1 = i + 1;
            const hash2 = (i ^ 0x9e3779b9) >>> 0;
            const metaOffset = i * 4;
            contentMetaList[metaOffset] = i;
            contentMetaList[metaOffset + 1] = 1;
            contentMetaList[metaOffset + 2] = hash1;
            contentMetaList[metaOffset + 3] = hash2;
            cache(null, i, 1, 'raw-v6', 0, hash1, hash2, source.subarray(i, i + 1));
        }
        /** @type {() => void} */
        let releaseReads = () => {};
        const readGate = new Promise((resolve) => {
            releaseReads = () => { resolve(void 0); };
        });
        let activeReadCount = 0;
        let maxActiveReadCount = 0;
        const readDetailed = vi.fn(async (offset, length) => {
            ++activeReadCount;
            maxActiveReadCount = Math.max(maxActiveReadCount, activeReadCount);
            await readGate;
            --activeReadCount;
            return {status: 'ok', bytes: source.subarray(offset, offset + length)};
        });
        Reflect.set(database, '_readTermEntryContentBytesDetailed', readDetailed);
        const resolveDedup = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const resolving = resolveDedup({
            rowCount: count,
            contentRowStart: 0,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 0,
            contentMetaList,
            contentUniqueIndexList: indexes,
            contentDedupPlan: {
                uniqueCount: count,
                sourceRowCount: count,
                uniqueRowIndexes: indexes,
                resolvedFlags: new Uint8Array(count),
                resolvedOffsets: new Float64Array(count),
                resolvedLengths: new Uint32Array(count),
                resolvedDictNames: new Array(count),
                pendingEpochs: new Uint32Array(count),
                pendingIndexes: new Uint32Array(count),
                nextEpoch: 1,
                persistedLookupRequired: true,
            },
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        });

        await vi.waitFor(() => expect(readDetailed).toHaveBeenCalledTimes(4096));
        expect(maxActiveReadCount).toBe(4096);
        releaseReads();
        const result = await resolving;

        expect(readDetailed).toHaveBeenCalledTimes(count);
        expect(maxActiveReadCount).toBe(4096);
        expect(result.persistedHitCount).toBe(count);
        expect(result.pendingContentCount).toBe(0);
    });

    test.each([false, true])('keeps unsigned pending hashes bounded and owned with allResolved=%s', async (allResolved) => {
        const database = new DictionaryDatabase();
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const plan = {
            uniqueCount: 3,
            sourceRowCount: 3,
            uniqueRowIndexes: new Uint32Array([0, 1, 2]),
            resolvedFlags: new Uint8Array([1, allResolved ? 1 : 0, 1]),
            resolvedOffsets: new Float64Array([100, 200, 300]),
            resolvedLengths: new Uint32Array([1, 1, 1]),
            resolvedDictNames: ['raw-v6', 'raw-v6', 'raw-v6'],
            pendingEpochs: new Uint32Array(3),
            pendingIndexes: new Uint32Array(3),
            nextEpoch: 1,
            persistedLookupRequired: true,
        };
        const contentMetaList = new Uint32Array([0, 1, 1, 2, 1, 1, 0x80000000, 0xffffffff, 2, 1, 3, 4]);
        const chunk = {
            rowCount: 3,
            contentRowStart: 0,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: new Uint8Array([9, 8, 7]),
            contentBytesBaseOffset: 0,
            contentMetaList,
            contentUniqueIndexList: new Uint32Array([0, 1, 2]),
            contentDedupPlan: plan,
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        };
        const result = await resolve(chunk, true);
        const {pendingContentHash1s: first, pendingContentHash2s: second} = result;
        if (!(first instanceof Uint32Array) || !(second instanceof Uint32Array)) {
            throw new Error('Expected bounded canonical hash buffers');
        }
        expect([...first]).toEqual(allResolved ? [] : [0x80000000]);
        expect([...second]).toEqual(allResolved ? [] : [0xffffffff]);
        expect(result.pendingContentCount).toBe(allResolved ? 0 : 1);
        expect(first.buffer.byteLength).toBe(allResolved ? 0 : 12);
        expect(second.buffer.byteLength).toBe(allResolved ? 0 : 12);
        if (!allResolved) {
            if (typeof result.stagedContentMetadata === 'undefined') { throw new Error('Expected staged metadata ownership'); }
            Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').call(database, result.stagedContentMetadata);
            contentMetaList[6] = 0xffffffff;
            contentMetaList[7] = 0;
            const next = await resolve(chunk, true);
            expect([...next.pendingContentHash1s]).toEqual([0xffffffff]);
            expect([...next.pendingContentHash2s]).toEqual([0]);
            expect([...first]).toEqual([0x80000000]);
            expect([...second]).toEqual([0xffffffff]);
        }
    });

    test('preserves unique-content mapping when an exact candidate is a hash collision', async () => {
        const database = new DictionaryDatabase();
        const persisted = new Uint8Array([1, 2, 3]);
        const source = new Uint8Array([1, 2, 4, 5, 6, 7]);
        cacheMeta(database, null, 100, 3, 'raw-v6', 10, 20);
        Reflect.set(database, '_readTermEntryContentBytesDetailed', vi.fn(async () => ({
            status: 'ok',
            bytes: persisted,
        })));
        const resolveDedup = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const result = await resolveDedup({
            rowCount: 2,
            contentRowStart: 0,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 0,
            contentMetaList: new Uint32Array([0, 3, 10, 20, 3, 3, 30, 40]),
            contentUniqueIndexList: new Uint32Array([0, 1]),
            contentDedupPlan: {
                uniqueCount: 2,
                sourceRowCount: 2,
                uniqueRowIndexes: new Uint32Array([0, 1]),
                resolvedFlags: new Uint8Array(2),
                resolvedOffsets: new Float64Array(2),
                resolvedLengths: new Uint32Array(2),
                resolvedDictNames: new Array(2),
                pendingEpochs: new Uint32Array(2),
                pendingIndexes: new Uint32Array(2),
                nextEpoch: 1,
                persistedLookupRequired: true,
            },
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        });

        expect(result.persistedHitCount).toBe(0);
        expect(result.exactFallbackCount).toBe(1);
        expect(result.pendingContentCount).toBe(2);
        expect(result.pendingPlanUniqueIndexes).toEqual([1, 0]);
        const pendingContentSpans = result.pendingContentSpans;
        if (pendingContentSpans === null) { throw new Error('Expected pending content spans'); }
        expect([...pendingContentSpans.offsets]).toEqual([3, 0]);
        expect([...pendingContentSpans.lengths]).toEqual([3, 3]);
        expect([...result.pendingContentHash1s]).toEqual([30, 10]);
        expect([...result.pendingContentHash2s]).toEqual([40, 20]);
    });

    test('settles every concurrent exact comparison before reporting a failure', async () => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array([1, 2, 3, 4, 5, 6]);
        const cache = Reflect.get(database, '_cacheTermEntryContentMeta').bind(database);
        cache(null, 100, 3, 'raw-v6', 0, 10, 20, source.subarray(0, 3));
        cache(null, 200, 3, 'raw-v6', 0, 30, 40, source.subarray(3, 6));
        const resolvers = new Map();
        const rejecters = new Map();
        const readDetailed = vi.fn(async (offset) => await new Promise((resolve, reject) => {
            resolvers.set(offset, resolve);
            rejecters.set(offset, reject);
        }));
        Reflect.set(database, '_readTermEntryContentBytesDetailed', readDetailed);
        const resolveDedup = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const resolving = resolveDedup({
            rowCount: 2,
            contentRowStart: 0,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 0,
            contentMetaList: new Uint32Array([0, 3, 10, 20, 3, 3, 30, 40]),
            contentUniqueIndexList: new Uint32Array([0, 1]),
            contentDedupPlan: {
                uniqueCount: 2,
                sourceRowCount: 2,
                uniqueRowIndexes: new Uint32Array([0, 1]),
                resolvedFlags: new Uint8Array(2),
                resolvedOffsets: new Float64Array(2),
                resolvedLengths: new Uint32Array(2),
                resolvedDictNames: new Array(2),
                pendingEpochs: new Uint32Array(2),
                pendingIndexes: new Uint32Array(2),
                nextEpoch: 1,
                persistedLookupRequired: true,
            },
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        });
        let settled = false;
        void resolving.finally(() => { settled = true; }).catch(() => {});

        await vi.waitFor(() => expect(readDetailed).toHaveBeenCalledTimes(2));
        rejecters.get(100)(new Error('injected exact comparison failure'));
        await Promise.resolve();
        expect(settled).toBe(false);
        resolvers.get(200)({status: 'ok', bytes: source.subarray(3, 6)});

        await expect(resolving).rejects.toThrow('injected exact comparison failure');
        expect(settled).toBe(true);
    });

    test('defers mixed canonical projection until pending offsets are published', async () => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array([1, 2, 3, 1, 2, 3, 4, 5]);
        Reflect.set(database, '_readTermEntryContentBytesDetailed', vi.fn(async () => ({status: 'ok', bytes: source.subarray(0, 3)})));
        Reflect.get(database, '_cacheTermEntryContentMeta').call(
            database,
            null,
            400,
            3,
            'raw-v6',
            0,
            10,
            20,
            source.subarray(0, 3),
        );
        const plan = {
            uniqueCount: 2,
            sourceRowCount: 3,
            uniqueRowIndexes: new Uint32Array([0, 2]),
            resolvedFlags: new Uint8Array(2),
            resolvedOffsets: new Float64Array(2),
            resolvedLengths: new Uint32Array(2),
            resolvedDictNames: new Array(2),
            pendingEpochs: new Uint32Array(2),
            pendingIndexes: new Uint32Array(2),
            nextEpoch: 1,
            persistedLookupRequired: true,
        };
        const chunk = {
            rowCount: 3,
            contentRowStart: 0,
            dictionaryTotalRows: 3,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 0,
            contentMetaList: new Uint32Array([
                0,
                3,
                10,
                20,
                3,
                3,
                10,
                20,
                6,
                2,
                30,
                40,
            ]),
            contentUniqueIndexList: new Uint32Array([0, 0, 1]),
            contentDedupPlan: plan,
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        };
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const result = await resolve(chunk, true);

        expect(result.pendingContentCount).toBe(1);
        expect(result.contentOffsets).toStrictEqual(new Float64Array(3));

        plan.resolvedOffsets[1] = 500;
        plan.resolvedLengths[1] = 2;
        plan.resolvedDictNames[1] = 'raw-block-v2:jmdict';
        plan.resolvedFlags[1] = 1;
        const publish = Reflect.get(database, '_publishArtifactTermContentMetadata').bind(database);
        const names = publish({
            count: 3,
            contentOffsets: result.contentOffsets,
            contentLengths: result.contentLengths,
            resolvedContentDictNames: result.resolvedContentDictNames,
            pendingRowToUniqueIndex: null,
            pendingContentBytes: result.pendingContentBytes,
            pendingContentHash1s: result.pendingContentHash1s,
            pendingContentHash2s: result.pendingContentHash2s,
            pendingOffsets: new Float64Array([500]),
            pendingLengths: new Uint32Array([2]),
            pendingResolvedDictNames: 'raw-block-v2:jmdict',
            pendingContentSpans: result.pendingContentSpans,
            contentDedupPlan: plan,
            contentUniqueIndexList: chunk.contentUniqueIndexList,
            stagedContentMetadata: result.stagedContentMetadata,
            metadataValidated: true,
        });

        expect([...result.contentOffsets]).toEqual([400, 400, 500]);
        expect([...result.contentLengths]).toEqual([3, 3, 2]);
        expect(names).toEqual(['raw-v6', 'raw-v6', 'raw-block-v2:jmdict']);
    });

    test('does not merge a canonical row with a persisted hash collision', async () => {
        const database = new DictionaryDatabase();
        const persisted = new Uint8Array([1, 2, 3, 4]);
        Reflect.get(database, '_cacheTermEntryContentMeta').call(
            database,
            null,
            400,
            persisted.byteLength,
            'raw',
            0,
            10,
            20,
            persisted,
        );
        Reflect.set(database, '_termContentStore', {
            readSlice: vi.fn(async () => persisted),
        });
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const source = new Uint8Array([99, 1, 2, 3, 5, 88]);
        const result = await resolve({
            rowCount: 1,
            contentRowStart: 0,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 1,
            contentMetaList: new Uint32Array([0, 4, 10, 20]),
            contentUniqueIndexList: new Uint32Array([0]),
            contentDedupPlan: {
                uniqueCount: 1,
                sourceRowCount: 1,
                uniqueRowIndexes: new Uint32Array([0]),
                resolvedFlags: new Uint8Array(1),
                resolvedOffsets: new Float64Array(1),
                resolvedLengths: new Uint32Array(1),
                resolvedDictNames: new Array(1),
                pendingEpochs: new Uint32Array(1),
                pendingIndexes: new Uint32Array(1),
                nextEpoch: 1,
                persistedLookupRequired: true,
            },
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        });

        expect(result.persistedHitCount).toBe(0);
        expect(result.exactFallbackCount).toBe(0);
        expect(result.pendingContentCount).toBe(1);
        const pendingContentSpans = result.pendingContentSpans;
        if (pendingContentSpans === null) { throw new Error('Expected pending content spans'); }
        expect([...pendingContentSpans.offsets]).toEqual([1]);
    });

    test('uses global canonical row indexes with nonzero chunk starts', async () => {
        const database = new DictionaryDatabase();
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const plan = /** @type {ArtifactTermContentDedupPlan} */ ({
            uniqueCount: 3,
            sourceRowCount: 5,
            uniqueRowIndexes: new Uint32Array([0, 2, 4]),
            resolvedFlags: new Uint8Array([1, 0, 0]),
            resolvedOffsets: new Float64Array([100, 0, 0]),
            resolvedLengths: new Uint32Array([3, 0, 0]),
            resolvedDictNames: /** @type {string[]} */ (/** @type {unknown} */ (['raw-v6', void 0, void 0])),
            pendingEpochs: new Uint32Array(3),
            pendingIndexes: new Uint32Array(3),
            nextEpoch: 1,
            persistedLookupRequired: true,
        });
        const source = new Uint8Array([99, 4, 5, 4, 5, 6, 88]);
        const result = await resolve({
            rowCount: 3,
            contentRowStart: 2,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: source,
            contentBytesBaseOffset: 1,
            contentMetaList: new Uint32Array([
                0,
                2,
                30,
                40,
                2,
                2,
                30,
                40,
                4,
                1,
                50,
                60,
            ]),
            contentUniqueIndexList: new Uint32Array([1, 1, 2]),
            contentDedupPlan: plan,
            contentDictNameList: null,
            uniformContentDictName: 'raw-v6',
        });

        expect(result.pendingPlanUniqueIndexes).toEqual([1, 2]);
        const pendingContentSpans = result.pendingContentSpans;
        if (pendingContentSpans === null) { throw new Error('Expected pending content spans'); }
        expect([...pendingContentSpans.offsets]).toEqual([1, 5]);
        expect([...pendingContentSpans.lengths]).toEqual([2, 1]);
        expect(result.pendingHitCount).toBe(1);
    });

    test('rolls back canonical-row plan publication after persistence failure', async () => {
        const harness = createArtifactOverlapHarness();
        Reflect.set(harness.plan, 'uniqueRowIndexes', new Uint32Array([0]));
        Reflect.set(harness.plan, 'persistedLookupRequired', true);
        Reflect.set(harness.chunk, 'contentRowStart', 0);
        const stageMetadata = vi.spyOn(harness.database, '_stageArtifactTermContentMetadata');
        const importing = harness.run();

        await vi.waitFor(() => expect(harness.appendRecords).toHaveBeenCalledOnce());
        harness.rejectContent(new Error('injected canonical content failure'));
        harness.resolveRecords();

        await expect(importing).rejects.toThrow('injected canonical content failure');
        expect(getMeta(harness.database, 10, 20)).toBeUndefined();
        expect(Reflect.get(harness.database, '_termEntryContentMetaHashPairPendingCount')).toBe(0);
        expect(stageMetadata).not.toHaveBeenCalled();
        expect(harness.plan.resolvedFlags).toStrictEqual(new Uint8Array([0]));
        expect(harness.plan.resolvedOffsets).toStrictEqual(new Float64Array([0]));
        expect(harness.plan.resolvedLengths).toStrictEqual(new Uint32Array([0]));
    });

    test('retains parser content until reserved content is durable', async () => {
        const harness = createArtifactOverlapHarness();
        Reflect.set(harness.plan, 'uniqueRowIndexes', new Uint32Array([0]));
        Reflect.set(harness.chunk, 'contentRowStart', 0);
        Reflect.set(harness.chunk, 'useResolvedContentReferences', true);
        const importing = harness.run();

        await vi.waitFor(() => expect(harness.appendRecords).toHaveBeenCalledOnce());
        expect(harness.releaseBorrowedContent).not.toHaveBeenCalled();
        const [recordChunk, contentOffsets, contentLengths, contentDictName] = harness.appendRecords.mock.calls[0];
        expect(contentOffsets).toStrictEqual(new Float64Array(0));
        expect(contentLengths).toStrictEqual(new Uint32Array(0));
        expect(contentDictName).toBe('raw-block-v2:jmdict');
        expect(recordChunk.resolvedContentReferences).toEqual({
            uniqueIndexList: harness.chunk.contentUniqueIndexList,
            offsets: harness.plan.resolvedOffsets,
            lengths: harness.plan.resolvedLengths,
        });

        harness.resolveContent();
        await vi.waitFor(() => expect(harness.releaseBorrowedContent).toHaveBeenCalledOnce());
        harness.resolveRecords();
        await importing;
        expect(harness.releaseBorrowedContent).toHaveBeenCalledOnce();
    });

    test('does not release parser content on source consumption before metadata publication', async () => {
        const harness = createArtifactOverlapHarness();
        /** @type {(value: Record<string, unknown>) => void} */
        let resolveStorage = () => {};
        const storage = new Promise((resolve) => { resolveStorage = resolve; });
        Reflect.set(harness.database, '_termContentBlockImportSession', {
            tryBeginAppendSpans: vi.fn(() => ({
                initialSelection: true,
                sourceConsumed: Promise.resolve(),
                storage,
                completion: storage.then((result) => ({
                    ...result,
                    packMs: 1,
                    compressMs: 2,
                    envelopeMs: 3,
                    referenceMs: 4,
                    opfsAppendMs: 5,
                })),
            })),
        });
        const importing = harness.run();

        await Promise.resolve();
        await Promise.resolve();
        expect(harness.releaseBorrowedContent).not.toHaveBeenCalled();
        resolveStorage({
            contentOffsets: new Float64Array([100]),
            contentLengths: new Uint32Array([3]),
            contentDictName: 'raw-block-v2:jmdict',
        });
        await vi.waitFor(() => expect(harness.appendRecords).toHaveBeenCalledOnce());
        await vi.waitFor(() => expect(harness.releaseBorrowedContent).toHaveBeenCalledOnce());

        harness.resolveRecords();
        await importing;
    });

    test('verifies a duplicate against canonical bytes while its OPFS write is pending', async () => {
        const harness = createArtifactOverlapHarness();
        const readPersisted = vi.spyOn(harness.database, '_readTermEntryContentBytesDetailed');
        const importing = harness.run();

        await vi.waitFor(() => expect(harness.appendRecords).toHaveBeenCalledOnce());
        expect(Reflect.get(harness.database, '_inFlightTermContentSourceBatches').size).toBe(1);
        const findMatching = Reflect.get(harness.database, '_findMatchingTermEntryContentMeta').bind(harness.database);
        await expect(findMatching(10, 20, Uint8Array.of(1, 2, 3))).resolves.toMatchObject({
            offset: 100,
            length: 3,
        });
        expect(readPersisted).not.toHaveBeenCalled();

        harness.resolveContent();
        await vi.waitFor(() => {
            expect(Reflect.get(harness.database, '_inFlightTermContentSourceBatches').size).toBe(0);
        });
        harness.resolveRecords();
        await importing;
    });

    test('does not merge an exact hash collision while its OPFS write is pending', async () => {
        const original = Array.from({length: 16}, (_, index) => index);
        const collision = [...original];
        collision[4] = 0xff;
        const harness = createArtifactOverlapHarness(original);
        const readPersisted = vi.spyOn(harness.database, '_readTermEntryContentBytesDetailed');
        const importing = harness.run();

        await vi.waitFor(() => expect(harness.appendRecords).toHaveBeenCalledOnce());
        const findMatching = Reflect.get(harness.database, '_findMatchingTermEntryContentMeta').bind(harness.database);
        await expect(findMatching(10, 20, Uint8Array.from(collision))).resolves.toBeUndefined();
        expect(readPersisted).not.toHaveBeenCalled();

        harness.resolveContent();
        harness.resolveRecords();
        await importing;
        expect(Reflect.get(harness.database, '_inFlightTermContentSourceBatches').size).toBe(0);
    });

    test('finds ordered and unordered in-flight content without per-entry maps', () => {
        const database = new DictionaryDatabase();
        const register = Reflect.get(database, '_registerInFlightTermContentSources').bind(database);
        const find = Reflect.get(database, '_findInFlightTermContentSource').bind(database);
        const buffer = Uint8Array.of(1, 2, 3, 4, 5, 6);
        const unregisterOrdered = register(
            new Float64Array([100, 200, 300]),
            new Uint32Array([2, 2, 2]),
            'raw',
            [],
            {
                buffer,
                offsets: new Uint32Array([0, 2, 4]),
                lengths: new Uint32Array([2, 2, 2]),
            },
        );

        expect(find(200, 2, 'raw')).toEqual({buffer, offset: 2, length: 2});
        expect(find(200, 1, 'raw')).toBeUndefined();
        expect(find(200, 2, 'other')).toBeUndefined();

        const unorderedBytes = [Uint8Array.of(7), Uint8Array.of(8)];
        const unregisterUnordered = register(
            [500, 400],
            [1, 1],
            ['a', 'b'],
            unorderedBytes,
            null,
        );
        expect(find(400, 1, 'b')).toEqual({buffer: unorderedBytes[1], offset: 0, length: 1});
        expect(() => register([500], [1], ['a'], [Uint8Array.of(9)], null)).toThrow(
            'Duplicate in-flight term content storage reference',
        );

        unregisterUnordered();
        unregisterOrdered();
        expect(Reflect.get(database, '_inFlightTermContentSourceBatches').size).toBe(0);
    });

    test.each(['raw', 'raw-block-v2:jmdict'])('matches persisted empty %s spans without reading storage', async (dictName) => {
        const database = new DictionaryDatabase();
        const contentBytes = new Uint8Array(0);
        const meta = {id: 1, offset: 1234, length: 0, dictName};
        const read = vi.fn(() => { throw new Error('Expected no storage read'); });
        Reflect.set(database, '_readTermEntryContentBytesDetailed', read);
        const find = Reflect.get(database, '_findMatchingPersistedTermEntryContentMeta').bind(database);
        const findBatch = Reflect.get(database, '_findMatchingPersistedTermEntryContentMetaBatch').bind(database);
        const nonempty = {...meta, length: 1};

        await expect(find([nonempty, meta], contentBytes)).resolves.toBe(meta);
        await expect(find([nonempty], contentBytes)).resolves.toBeUndefined();
        await expect(findBatch([
            {hash1: 10, hash2: 20, contentBytes, primary: meta},
            {hash1: 10, hash2: 20, contentBytes, primary: nonempty},
        ])).resolves.toStrictEqual([
            {existingMeta: meta, exactFallback: true},
            {existingMeta: undefined, exactFallback: false},
        ]);
        expect(read).not.toHaveBeenCalled();
    });

    test('bounds persisted signatures for short slab content', async () => {
        const database = new DictionaryDatabase();
        const contentBytes = new Uint8Array([1, 2, 3]);
        Reflect.set(database, '_readTermEntryContentBytesDetailed', vi.fn(async () => ({status: 'ok', bytes: contentBytes})));
        Reflect.get(database, '_cacheTermEntryContentMeta').call(
            database,
            null,
            1234,
            contentBytes.byteLength,
            'raw',
            0,
            10,
            20,
            contentBytes,
        );
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const result = await resolve({
            rowCount: 1,
            contentBytesList: [],
            contentHash1List: new Uint32Array(0),
            contentHash2List: new Uint32Array(0),
            contentBytesBuffer: new Uint8Array([99, 1, 2, 3, 0xff, 0xff, 0xff, 0xff]),
            contentBytesBaseOffset: 1,
            contentMetaList: new Uint32Array([0, 3, 10, 20]),
            contentDictNameList: null,
            uniformContentDictName: 'raw',
        });

        expect(result.persistedHitCount).toBe(1);
        expect(result.pendingContentBytes).toHaveLength(0);
        expect(result.contentOffsets[0]).toBe(1234);
    });

    test('reuses discovered insertion slots without merging exact hash collisions', async () => {
        const database = new DictionaryDatabase();
        const resolve = Reflect.get(database, '_resolveArtifactTermContentDedup').bind(database);
        const first = new Uint8Array([1, 2, 3]);
        const second = new Uint8Array([1, 2, 4]);

        const result = await resolve({
            rowCount: 4,
            contentBytesList: [first, second, Uint8Array.from(first), Uint8Array.from(second)],
            contentHash1List: new Uint32Array([10, 10, 10, 10]),
            contentHash2List: new Uint32Array([20, 20, 20, 20]),
            contentDictNameList: null,
            uniformContentDictName: 'raw',
        });

        expect(result.pendingContentBytes).toHaveLength(2);
        if (result.pendingRowToUniqueIndex === null) { throw new Error('Expected pending row indexes'); }
        expect([...result.pendingRowToUniqueIndex]).toEqual([0, 1, 0, 1]);
        expect(result.pendingHitCount).toBe(2);
        expect(result.persistedHitCount).toBe(0);
    });

    test('rolls back reserved metadata when content persistence fails during record append', async () => {
        const harness = createArtifactOverlapHarness();
        const importing = harness.run();

        await vi.waitFor(() => expect(harness.appendRecords).toHaveBeenCalledOnce());
        expect(harness.appendRecords.mock.calls[0][1]).toStrictEqual(new Float64Array([100]));
        expect(Reflect.get(harness.database, '_inFlightTermContentSourceBatches').size).toBe(1);
        harness.rejectContent(new Error('injected reserved content failure'));
        harness.resolveRecords();

        await expect(importing).rejects.toThrow('injected reserved content failure');
        expect(getMeta(harness.database, 10, 20)).toBeUndefined();
        expect(harness.plan.resolvedFlags).toStrictEqual(new Uint8Array([0]));
        expect(harness.plan.nextUnresolvedUniqueIndex).toBe(0);
        expect(Reflect.get(harness.database, '_inFlightTermContentSourceBatches').size).toBe(0);
        expect(harness.releaseBorrowedContent).toHaveBeenCalledOnce();

        const resolve = Reflect.get(harness.database, '_resolveArtifactTermContentDedup').bind(harness.database);
        const retry = await resolve(harness.chunk, true);
        expect(retry.stagedContentMetadata?.indexes[0]).toBeGreaterThanOrEqual(0);
        expect(getMeta(harness.database, 10, 20)).toBeUndefined();
        const stagedContentMetadata = retry.stagedContentMetadata;
        if (typeof stagedContentMetadata === 'undefined') { throw new Error('Expected staged metadata'); }
        Reflect.get(harness.database, '_rollbackStagedArtifactTermContentMetadata').call(
            harness.database,
            stagedContentMetadata,
        );
        expect(Reflect.get(harness.database, '_termEntryContentMetaHashPairPendingCount')).toBe(0);
    });

    test('drains failed reserved content when record preparation throws', async () => {
        const harness = createArtifactOverlapHarness();
        const failure = new Error('injected record preparation failure');
        const prepareRecords = vi.fn(() => { throw failure; });
        Reflect.set(harness.database, '_createResolvedArtifactTermRecordChunk', prepareRecords);
        const importing = harness.run();
        const rejected = expect(importing).rejects.toBe(failure);

        await vi.waitFor(() => expect(prepareRecords).toHaveBeenCalledOnce());
        expect(harness.releaseBorrowedContent).not.toHaveBeenCalled();
        harness.rejectContent(new Error('injected reserved content failure'));

        await rejected;
        expect(harness.appendRecords).not.toHaveBeenCalled();
        expect(getMeta(harness.database, 10, 20)).toBeUndefined();
        expect(harness.plan.resolvedFlags).toStrictEqual(new Uint8Array([0]));
        expect(Reflect.get(harness.database, '_inFlightTermContentSourceBatches').size).toBe(0);
        expect(harness.releaseBorrowedContent).toHaveBeenCalledOnce();
    });

    test('reports source-driven initial content reservation', async () => {
        const harness = createArtifactOverlapHarness();
        const importing = harness.run();

        await vi.waitFor(() => expect(harness.appendRecords).toHaveBeenCalledOnce());
        harness.resolveContent();
        harness.resolveRecords();
        await importing;

        expect(getMeta(harness.database, 10, 20)).toMatchObject({
            offset: 100,
            length: 3,
            dictName: 'raw-block-v2:jmdict',
        });
        expect(harness.database.getLastBulkAddTermsMetrics()).toMatchObject({
            contentInitialReservationCount: 1,
        });
    });

    test('waits for pending content before surfacing a concurrent record failure', async () => {
        const harness = createArtifactOverlapHarness();
        const importing = harness.run();
        let importSettled = false;
        void importing.finally(() => { importSettled = true; }).catch(() => {});

        await vi.waitFor(() => expect(harness.appendRecords).toHaveBeenCalledOnce());
        harness.rejectRecords(new Error('injected term record failure'));
        await Promise.resolve();
        expect(importSettled).toBe(false);

        harness.resolveContent();
        await expect(importing).rejects.toThrow('injected term record failure');
        expect(getMeta(harness.database, 10, 20)).toBeUndefined();
        expect(harness.plan.resolvedFlags).toStrictEqual(new Uint8Array([0]));
        expect(harness.plan.nextUnresolvedUniqueIndex).toBe(0);
    });

    test('keeps local non-journaled imports on completed-content ordering', async () => {
        const database = new DictionaryDatabase();
        const db = {exec: vi.fn()};
        Reflect.set(database, '_db', db);
        Reflect.set(database, '_deferTermsVirtualTableSync', true);
        vi.spyOn(database, '_beginImmediateTransaction').mockResolvedValue();
        const tryBeginPersistence = vi.spyOn(database, '_tryBeginPersistArtifactTermContent');
        const persist = vi.spyOn(database, '_persistArtifactTermContent').mockResolvedValue({
            pendingOffsets: [50],
            pendingLengths: [3],
            pendingResolvedDictNames: 'raw',
            blockProfile: null,
        });
        Reflect.set(database, '_termRecordStore', {
            appendBatchFromArtifactChunkResolvedContent: vi.fn(async () => ({
                buildRecordsMs: 0,
                encodeMs: 0,
                appendWriteMs: 0,
                internMs: 0,
                packLengthsMs: 0,
                heapCopyMs: 0,
                recordFieldEncodeMs: 0,
            })),
        });
        const bytes = new Uint8Array([1, 2, 3]);
        const chunk = {
            dictionary: 'JMdict',
            rowCount: 1,
            dictionaryTotalRows: 1,
            expressionBytesList: [new TextEncoder().encode('test')],
            readingBytesList: [new Uint8Array(0)],
            readingEqualsExpressionList: new Uint8Array([1]),
            scoreList: new Int32Array(1),
            sequenceList: new Int32Array([-1]),
            contentBytesList: [bytes],
            contentHash1List: new Uint32Array([10]),
            contentHash2List: new Uint32Array([20]),
            contentDictNameList: null,
            uniformContentDictName: 'raw',
            termRecordPreinternedPlan: null,
        };
        const bulkAdd = Reflect.get(database, '_bulkAddArtifactTermsChunkWithContentDedup').bind(database);

        await bulkAdd(chunk);

        expect(tryBeginPersistence).not.toHaveBeenCalled();
        expect(persist).toHaveBeenCalledOnce();
        expect(db.exec).toHaveBeenCalledWith('COMMIT');
    });

    test('reuses duplicate artifact content within and across chunks', async () => {
        const database = new DictionaryDatabase();
        Reflect.set(database, '_bulkImportTransactionOpen', true);
        Reflect.set(database, '_termContentStorageMode', 'raw-bytes');
        Reflect.set(database, '_rawTermContentPackTargetBytes', 1024);

        /** @type {Array<{chunks: Uint8Array[], offsets: number[], lengths: number[]}>} */
        const appendCalls = [];
        Reflect.set(database, '_termContentStore', {
            appendBatchToArrays: vi.fn((chunks, offsets, lengths) => {
                appendCalls.push({chunks: [...chunks], offsets, lengths});
                let offset = 1000;
                for (let i = 0; i < chunks.length; ++i) {
                    offsets.push(offset);
                    lengths.push(chunks[i].byteLength);
                    offset += chunks[i].byteLength;
                }
            }),
            readSlice: vi.fn(async (offset, length) => {
                const call = appendCalls.find(({offsets, lengths}) => offsets.some((value, index) => value === offset && lengths[index] >= length));
                if (typeof call === 'undefined') { throw new Error('Missing test content span'); }
                const index = call.offsets.indexOf(offset);
                return call.chunks[index].slice(0, length);
            }),
        });
        Reflect.set(database, '_readTermEntryContentBytesDetailed', vi.fn(async (offset, length) => {
            const call = appendCalls.find(({offsets, lengths}) => offsets.some((value, index) => value === offset && lengths[index] >= length));
            if (typeof call === 'undefined') { throw new Error('Missing test content span'); }
            const index = call.offsets.indexOf(offset);
            return {status: 'ok', bytes: call.chunks[index].slice(0, length)};
        }));

        /** @type {Array<{contentOffsets: number[], contentLengths: number[], contentDictNames: string|string[]}>} */
        const termRecordCalls = [];
        Reflect.set(database, '_termRecordStore', {
            appendBatchFromArtifactChunkResolvedContent: vi.fn(async (_chunk, contentOffsets, contentLengths, contentDictNames) => {
                termRecordCalls.push({
                    contentOffsets: [...contentOffsets],
                    contentLengths: [...contentLengths],
                    contentDictNames: Array.isArray(contentDictNames) ? [...contentDictNames] : contentDictNames,
                });
                return {
                    buildRecordsMs: 0,
                    encodeMs: 0,
                    appendWriteMs: 0,
                    internMs: 0,
                    packLengthsMs: 0,
                    heapCopyMs: 0,
                    recordFieldEncodeMs: 0,
                };
            }),
        });
        const bulkAddArtifactTermsChunkWithContentDedup = /** @type {(this: DictionaryDatabase, chunk: unknown) => Promise<void>} */ (
            Reflect.get(database, '_bulkAddArtifactTermsChunkWithContentDedup')
        );
        const makeChunk = (
            /** @type {Uint8Array[]} */ contentBytesList,
            /** @type {number[]} */ hash1List,
            /** @type {number[]} */ hash2List,
        ) => ({
            dictionary: 'dedup-test',
            rowCount: contentBytesList.length,
            dictionaryTotalRows: contentBytesList.length,
            expressionBytesList: contentBytesList.map((/** @type {Uint8Array} */ _, index) => new TextEncoder().encode(`term-${index}`)),
            readingBytesList: contentBytesList.map(() => new Uint8Array(0)),
            readingEqualsExpressionList: new Uint8Array(contentBytesList.length).fill(1),
            scoreList: new Int32Array(contentBytesList.length),
            sequenceList: new Int32Array(contentBytesList.length).fill(-1),
            contentBytesList,
            contentHash1List: new Uint32Array(hash1List),
            contentHash2List: new Uint32Array(hash2List),
            contentDictNameList: null,
            uniformContentDictName: 'raw',
            termRecordPreinternedPlan: null,
        });

        await bulkAddArtifactTermsChunkWithContentDedup.call(database, makeChunk(
            [
                new Uint8Array([1, 2, 3]),
                new Uint8Array([1, 2, 3]),
                new Uint8Array([4, 5]),
            ],
            [10, 10, 30],
            [20, 20, 40],
        ));
        await bulkAddArtifactTermsChunkWithContentDedup.call(database, makeChunk(
            [new Uint8Array([1, 2, 3])],
            [10],
            [20],
        ));

        expect(appendCalls).toHaveLength(1);
        expect(getMeta(database, 10, 20)).toMatchObject({offset: termRecordCalls[0].contentOffsets[0], length: 3});
        expect(termRecordCalls).toHaveLength(2);
        expect(termRecordCalls[0].contentOffsets[0]).toBe(termRecordCalls[0].contentOffsets[1]);
        expect(termRecordCalls[0].contentLengths).toEqual([3, 3, 2]);
        expect(termRecordCalls[0].contentDictNames).toBe('raw');
        expect(termRecordCalls[1].contentOffsets).toEqual([termRecordCalls[0].contentOffsets[0]]);
        expect(termRecordCalls[1].contentLengths).toEqual([3]);
        expect(termRecordCalls[1].contentDictNames).toBe('raw');
    });
});

describe('DictionaryDatabase term lookup warming', () => {
    test('does not reload direct term indexes already cached for lookup', async () => {
        const database = new DictionaryDatabase();
        Reflect.get(database, '_directTermIndexByDictionary').set('JMdict', {
            expression: new Map(),
            reading: new Map(),
            expressionReverse: new Map(),
            readingReverse: new Map(),
            sequence: new Map(),
        });
        const ensureDictionariesLoaded = vi.fn(async () => {});
        Reflect.set(database, '_termRecordStore', {ensureDictionariesLoaded});

        const ensureDirectTermIndexesLoaded = /** @type {(this: DictionaryDatabase, dictionaryNames: Iterable<string>) => Promise<void>} */ (
            Reflect.get(database, '_ensureDirectTermIndexesLoaded')
        );
        await ensureDirectTermIndexesLoaded.call(database, ['JMdict']);

        expect(ensureDictionariesLoaded).not.toHaveBeenCalled();
    });

    test('loads and indexes missing direct term indexes as one batch', async () => {
        const database = new DictionaryDatabase();
        const indexes = new Map([
            ['JMdict', {
                expression: new Map([['日本', [1]]]),
                reading: new Map(),
                expressionReverse: new Map(),
                readingReverse: new Map(),
                sequence: new Map(),
            }],
            ['Jitendex', {
                expression: new Map([['日本', [2]]]),
                reading: new Map(),
                expressionReverse: new Map(),
                readingReverse: new Map(),
                sequence: new Map(),
            }],
        ]);
        const ensureDictionariesLoaded = vi.fn(async () => {});
        const ensureDictionaryIndexes = vi.fn();
        const getDictionaryIndex = vi.fn((name) => indexes.get(name));
        Reflect.set(database, '_termRecordStore', {ensureDictionariesLoaded, ensureDictionaryIndexes, getDictionaryIndex, getDictionaryHealth: () => ({status: 'available', reason: null})});

        const ensureDirectTermIndexesLoaded = /** @type {(this: DictionaryDatabase, dictionaryNames: Iterable<string>) => Promise<void>} */ (
            Reflect.get(database, '_ensureDirectTermIndexesLoaded')
        );
        await ensureDirectTermIndexesLoaded.call(database, ['JMdict', 'Jitendex']);

        expect(ensureDictionariesLoaded).toHaveBeenCalledOnce();
        expect(ensureDictionariesLoaded).toHaveBeenCalledWith(['JMdict', 'Jitendex'], {repairMode: 'background'});
        expect(ensureDictionaryIndexes).toHaveBeenCalledOnce();
        expect(ensureDictionaryIndexes).toHaveBeenCalledWith(['JMdict', 'Jitendex']);
        expect(getDictionaryIndex).toHaveBeenCalledTimes(2);
        expect(Reflect.get(database, '_directTermIndexByDictionary').get('JMdict')).toBe(indexes.get('JMdict'));
        expect(Reflect.get(database, '_directTermIndexByDictionary').get('Jitendex')).toBe(indexes.get('Jitendex'));
    });

    test('warms exact lookup storage and transient persisted prefix indexes', async () => {
        const database = new DictionaryDatabase();
        const index = {
            expression: new Map([['日本', [1]]]),
            reading: new Map([['にほん', [1]]]),
            expressionReverse: new Map(),
            readingReverse: new Map(),
            sequence: new Map(),
        };
        Reflect.set(database, '_termContentStore', {ensureLoadedForRead: vi.fn(async () => {})});
        const warmPrefixIndexes = vi.fn(async () => {});
        Reflect.set(database, '_termRecordStore', {
            ensureDictionariesLoaded: vi.fn(async () => {}),
            getDictionaryIndex: vi.fn(() => index),
            warmPrefixIndexes,
        });
        Reflect.set(database, '_warmSharedGlossaryArtifacts', vi.fn(async () => {}));
        const warmLookupProbeTerms = vi.fn(async () => {});
        Reflect.set(database, '_warmLookupProbeTerms', warmLookupProbeTerms);
        const getSortedTermIndexKeys = vi.fn(() => []);
        Reflect.set(database, '_getSortedTermIndexKeys', getSortedTermIndexKeys);

        await database.warmTermLookupCaches(['JMdict']);

        expect(Reflect.get(database, '_termContentStore').ensureLoadedForRead).toHaveBeenCalledOnce();
        expect(Reflect.get(database, '_termRecordStore').ensureDictionariesLoaded).toHaveBeenCalledWith(['JMdict'], {repairMode: 'background'});
        expect(warmPrefixIndexes).toHaveBeenCalledWith(['JMdict']);
        expect(Reflect.get(database, '_warmSharedGlossaryArtifacts')).toHaveBeenCalledWith(['JMdict']);
        expect(warmLookupProbeTerms).toHaveBeenCalledWith(['JMdict']);
        expect(warmLookupProbeTerms.mock.invocationCallOrder[0]).toBeLessThan(
            warmPrefixIndexes.mock.invocationCallOrder[0],
        );
        expect(getSortedTermIndexKeys).not.toHaveBeenCalled();
    });

    test('exact term-reading lookup filters expression candidates without building pair indexes', async () => {
        const database = new DictionaryDatabase();
        Reflect.set(database, '_db', {});
        const index = {
            expression: new Map([['日本', [1, 2]]]),
            reading: new Map([['にほん', [1]], ['にっぽん', [2]]]),
            expressionReverse: new Map(),
            readingReverse: new Map(),
            sequence: new Map(),
        };
        const ensureDictionariesLoaded = vi.fn(async () => {});
        const ensureDictionaryIndexes = vi.fn();
        const getDictionaryIndex = vi.fn(() => index);
        Reflect.set(database, '_termRecordStore', {ensureDictionariesLoaded, ensureDictionaryIndexes, getDictionaryIndex, getDictionaryHealth: () => ({status: 'available', reason: null})});
        const fetchTermRowsByIds = vi.fn(
            /**
             * @param {Iterable<number>} ids
             * @returns {Promise<Map<number, unknown>>}
             */
            async (ids) => {
                void ids;
                return new Map([
                    [1, {
                        id: 1,
                        dictionary: 'JMdict',
                        expression: '日本',
                        reading: 'にほん',
                        definitionTags: '',
                        termTags: '',
                        rules: '',
                        score: 0,
                        glossary: ['Japan'],
                        sequence: 100,
                    }],
                    [2, {
                        id: 2,
                        dictionary: 'JMdict',
                        expression: '日本',
                        reading: 'にっぽん',
                        definitionTags: '',
                        termTags: '',
                        rules: '',
                        score: 0,
                        glossary: ['Japan'],
                        sequence: 101,
                    }],
                ]);
            },
        );
        Reflect.set(database, '_fetchTermRowsByIds', fetchTermRowsByIds);

        const results = await database.findTermsExactBulk([{term: '日本', reading: 'にほん'}], new Set(['JMdict']));

        expect([...fetchTermRowsByIds.mock.calls[0][0]]).toEqual([1]);
        expect(results).toHaveLength(1);
        expect(results[0].term).toBe('日本');
    });
});

describe('TermRecordOpfsStore batch dictionary indexes', () => {
    test('builds multiple missing dictionary indexes with one record pass', () => {
        const store = new TermRecordOpfsStore();
        const recordsById = Reflect.get(store, '_recordsById');
        recordsById.set(1, {
            id: 1,
            dictionary: 'JMdict',
            expression: '日本',
            reading: 'にほん',
            entryContentOffset: 10,
            entryContentLength: 5,
            entryContentDictName: 'raw',
            score: 1,
            sequence: 100,
        });
        recordsById.set(2, {
            id: 2,
            dictionary: 'Jitendex',
            expression: '日本',
            reading: 'にほん',
            entryContentOffset: 20,
            entryContentLength: 5,
            entryContentDictName: 'raw',
            score: 2,
            sequence: 200,
        });
        recordsById.set(3, {
            id: 3,
            dictionary: 'Other',
            expression: '猫',
            reading: 'ねこ',
            entryContentOffset: 30,
            entryContentLength: 5,
            entryContentDictName: 'raw',
            score: 3,
            sequence: 300,
        });

        store.ensureDictionaryIndexes(['JMdict', 'Jitendex']);

        const jmdict = store.getDictionaryIndex('JMdict');
        const jitendex = store.getDictionaryIndex('Jitendex');
        expect(jmdict.expression.get('日本')).toEqual([1]);
        expect(jmdict.reading.get('にほん')).toEqual([1]);
        expect(jmdict.sequence.get(100)).toEqual([1]);
        expect(jitendex.expression.get('日本')).toEqual([2]);
        expect(jitendex.reading.get('にほん')).toEqual([2]);
        expect(jitendex.sequence.get(200)).toEqual([2]);
        expect(Reflect.get(store, '_indexByDictionary').has('Other')).toBe(false);
    });
});


describe('recent-source cache metadata mapping', () => {
    test('adopts independently owned shared memory while unmarked shared memory is copied', () => {
        const database = new DictionaryDatabase();
        const owned = new Uint8Array(new SharedArrayBuffer(4));
        owned.set([1, 2, 3, 4]);
        registerOwnedTermContent(owned);
        const adopted = publishSlabMeta(database, owned, 0, owned.length, 10, 20);
        const findRecent = Reflect.get(database, '_findRecentTermContentSource').bind(database);
        expect(findRecent(adopted.meta)?.buffer).toBe(owned);
        const borrowed = new Uint8Array(new SharedArrayBuffer(4));
        borrowed.set([5, 6, 7, 8]);
        const copied = publishSlabMeta(database, borrowed, 0, borrowed.length, 30, 40);
        borrowed.fill(0);
        expect(findRecent(copied.meta)?.buffer).toEqual(Uint8Array.of(5, 6, 7, 8));
        expect(findRecent(copied.meta)?.buffer.buffer).not.toBe(borrowed.buffer);
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(8);
    });

    test('adopts the entire transferred slab and releases it on rollback', () => {
        const database = new DictionaryDatabase();
        const source = Uint8Array.of(1, 2, 3, 4);
        const transferred = structuredClone(source, {transfer: [source.buffer]});
        registerOwnedTermContent(transferred);
        const published = publishSlabMeta(database, transferred, 0, transferred.length, 10, 20);
        const cached = Reflect.get(database, '_findRecentTermContentSource').call(database, published.meta);
        if (typeof cached === 'undefined') { throw new Error('Expected adopted content'); }
        expect(source.byteLength).toBe(0);
        expect(cached.buffer).toBe(transferred);
        expect([...cached.buffer]).toEqual([1, 2, 3, 4]);
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(4);
        expect(takeOwnedTermContent(transferred)).toBe(false);
        Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').call(database, published.staged);
        expect(Reflect.get(database, '_recentTermContentSourceBatches').size).toBe(0);
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(0);
    });

    test.each([false, true])('retains a partial immutable slab view with its full budget charge; shared=%s', async (shared) => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array(shared ? new SharedArrayBuffer(24) : new ArrayBuffer(24));
        source.set([90, 91, ...Array.from({length: 20}, (_, i) => i + 1), 92, 93]);
        registerOwnedTermContent(source);
        const {meta, staged} = publishSlabMeta(database, source, 2, 20, 10, 20);
        const cached = Reflect.get(database, '_findRecentTermContentSource').call(database, meta);
        if (typeof cached === 'undefined') { throw new Error('Expected retained content'); }
        expect(cached.buffer.buffer).toBe(source.buffer);
        expect(cached.buffer.byteOffset).toBe(2);
        expect(cached.buffer.byteLength).toBe(20);
        expect(cached.offset).toBe(0);
        expect(cached.length).toBe(20);
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(24);
        expect(takeOwnedTermContent(source)).toBe(false);
        const read = vi.fn(() => { throw new Error('Retained source must avoid a storage read'); });
        Reflect.set(database, '_readTermEntryContentBytesDetailed', read);
        const match = Reflect.get(database, '_findMatchingTermEntryContentMeta').bind(database);
        expect(await match(10, 20, source.slice(2, 22))).toMatchObject(meta);
        const collision = source.slice(2, 22);
        collision[5] ^= 1; // Preserve all three sampled signatures; exact bytes must still differ.
        expect(await match(10, 20, collision)).toBeUndefined();
        expect(read).not.toHaveBeenCalled();
        Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').call(database, staged);
        expect(Reflect.get(database, '_recentTermContentSourceBatches').size).toBe(0);
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(0);
    });

    test('copies the retained range when the owned backing buffer exceeds the budget', () => {
        const database = new DictionaryDatabase();
        Reflect.set(database, '_recentTermContentSourceCacheMaxBytes', 4);
        const source = Uint8Array.of(1, 2, 3, 4, 5, 6);
        registerOwnedTermContent(source);
        const {meta} = publishSlabMeta(database, source, 1, 4, 10, 20);
        const cached = Reflect.get(database, '_findRecentTermContentSource').call(database, meta);
        if (typeof cached === 'undefined') { throw new Error('Expected copied content'); }
        expect(cached.buffer.buffer).not.toBe(source.buffer);
        expect(cached.buffer).toEqual(Uint8Array.of(2, 3, 4, 5));
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(4);
        expect(takeOwnedTermContent(source)).toBe(true);
        source.fill(0);
        expect(cached.buffer).toEqual(Uint8Array.of(2, 3, 4, 5));
    });

    test('evicts by the entire adopted backing buffer and releases that charge on rollback', () => {
        const database = new DictionaryDatabase();
        Reflect.set(database, '_recentTermContentSourceCacheMaxBytes', 10);
        const first = Uint8Array.of(1, 2, 3, 4);
        registerOwnedTermContent(first);
        const firstPublished = publishSlabMeta(database, first, 0, 4, 10, 20);
        const source = Uint8Array.of(90, 91, 5, 6, 7, 8, 92, 93);
        registerOwnedTermContent(source);
        const published = publishSlabMeta(database, source, 2, 4, 30, 40);
        const findRecent = Reflect.get(database, '_findRecentTermContentSource').bind(database);
        expect(findRecent(firstPublished.meta)).toBeUndefined();
        expect(findRecent(published.meta)?.buffer.buffer).toBe(source.buffer);
        expect(findRecent(published.meta)?.buffer).toEqual(Uint8Array.of(5, 6, 7, 8));
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(8);
        Reflect.get(database, '_rollbackStagedArtifactTermContentMetadata').call(database, published.staged);
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(0);
        expect(Reflect.get(database, '_recentTermContentSourceBatches').size).toBe(0);
    });

    test.each([false, true])('copies an unowned partial source without consuming a complete owner; shared=%s', (shared) => {
        const database = new DictionaryDatabase();
        const source = new Uint8Array(shared ? new SharedArrayBuffer(8) : new ArrayBuffer(8));
        source.set([90, 1, 2, 3, 4, 5, 6, 91]);
        registerOwnedTermContent(source);
        const borrowed = source.subarray(1, 7);
        const {meta} = publishSlabMeta(database, borrowed, 1, 4, 10, 20);
        const cached = Reflect.get(database, '_findRecentTermContentSource').call(database, meta);
        if (typeof cached === 'undefined') { throw new Error('Expected copied content'); }
        expect(cached.buffer.buffer).not.toBe(source.buffer);
        expect(cached.buffer).toEqual(Uint8Array.of(2, 3, 4, 5));
        expect(takeOwnedTermContent(source)).toBe(true);
        source.fill(0);
        expect(cached.buffer).toEqual(Uint8Array.of(2, 3, 4, 5));
    });

    test('preserves exact admission and FIFO eviction for adopted slabs', () => {
        const database = new DictionaryDatabase();
        Reflect.set(database, '_recentTermContentSourceCacheMaxBytes', 6);
        const first = Uint8Array.of(1, 2, 3, 4);
        registerOwnedTermContent(first);
        const firstPublished = publishSlabMeta(database, first, 0, first.length, 10, 20);
        const second = Uint8Array.of(5, 6, 7, 8);
        registerOwnedTermContent(second);
        const secondPublished = publishSlabMeta(database, second, 0, second.length, 30, 40);
        const findRecent = Reflect.get(database, '_findRecentTermContentSource').bind(database);
        expect(findRecent(firstPublished.meta)).toBeUndefined();
        expect(findRecent(secondPublished.meta)?.buffer).toBe(second);
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(4);
        expect(Reflect.get(database, '_recentTermContentSourceBatches').size).toBe(1);
        const oversized = new Uint8Array(7).fill(9);
        registerOwnedTermContent(oversized);
        const oversizedPublished = publishSlabMeta(database, oversized, 0, oversized.length, 50, 60);
        expect(findRecent(oversizedPublished.meta)).toBeUndefined();
        expect(findRecent(secondPublished.meta)?.buffer).toBe(second);
        expect(Reflect.get(database, '_recentTermContentSourceBatchBytes')).toBe(4);
        expect(takeOwnedTermContent(oversized)).toBe(true);
    });

    test.each([0, 2])('joins in-flight readers before rolling back adopted content with edge padding %s', async (padding) => {
        const harness = createArtifactOverlapHarness();
        const source = new Uint8Array(new SharedArrayBuffer(3 + 2 * padding)).fill(90);
        source.set([1, 2, 3], padding);
        const expected = Uint8Array.from(source);
        registerOwnedTermContent(source);
        harness.chunk.contentBytesBuffer = source;
        harness.chunk.contentBytesBaseOffset = padding;
        Reflect.deleteProperty(harness.chunk, 'releaseBorrowedContent');
        const outcome = harness.run().then(() => null, (error) => error);
        await vi.waitFor(() => expect(harness.appendRecords).toHaveBeenCalledOnce());
        const retained = Reflect.get(harness.database, '_recentTermContentSourceBatches').get(1);
        expect(retained?.buffer).toBe(source.buffer);
        expect(retained?.byteOffset).toBe(padding);
        expect(retained).toEqual(Uint8Array.of(1, 2, 3));
        expect(Reflect.get(harness.database, '_recentTermContentSourceBatchBytes')).toBe(source.byteLength);
        harness.rejectContent(new Error('cancelled owned content write'));
        let settled = false;
        void outcome.then(() => { settled = true; });
        await Promise.resolve();
        await Promise.resolve();
        expect(settled).toBe(false);
        expect(source).toEqual(expected);
        harness.resolveRecords();
        expect(await outcome).toMatchObject({message: 'cancelled owned content write'});
        expect(Reflect.get(harness.database, '_recentTermContentSourceBatches').size).toBe(0);
        expect(Reflect.get(harness.database, '_recentTermContentSourceBatchBytes')).toBe(0);
        expect(harness.plan.resolvedFlags[0]).toBe(0);
        expect(harness.releaseBorrowedContent).not.toHaveBeenCalled();
    });

    test.each([
        [null, 48],
        [4, 48],
        [8, 96],
    ])('sets the import cache budget for a device reporting %s GiB', (memoryGiB, expectedMiB) => {
        const detectMemory = vi.spyOn(DictionaryDatabase.prototype, '_getApproximateDeviceMemoryGiB').mockReturnValue(memoryGiB);
        try {
            const database = new DictionaryDatabase();
            expect(Reflect.get(database, '_recentTermContentSourceCacheMaxBytes')).toBe(expectedMiB * 1024 * 1024);
        } finally {
            detectMemory.mockRestore();
        }
    });

    const cases = [
        {name: 'dense zero-base spans', indexes: [2, 3, 4], offsets: [0, 4, 8, 999], lengths: [2, 2, 2], unpublished: [], mapping: [[2, 0], [3, 4], [4, 8]], minimum: 0, end: 10, wrap: false},
        {name: 'dense relative spans', indexes: [2, 3, 4], offsets: [3, 7, 11, 999], lengths: [2, 2, 2], unpublished: [], mapping: [[2, 0], [3, 4], [4, 8]], minimum: 3, end: 13, wrap: false},
        {name: 'permuted published slots', indexes: [4, 2, 3], offsets: [0, 4, 8, 999], lengths: [2, 2, 2], unpublished: [], mapping: [[4, 0], [2, 4], [3, 8]], minimum: 0, end: 10, wrap: false},
        {name: 'skipped collision slots', indexes: [4, -1, 1], offsets: [0, 12345, 8, 999], lengths: [2, 99999, 2], unpublished: [], mapping: [[4, 0], [1, 8]], minimum: 0, end: 10, wrap: false},
        {name: 'unpublished slots', indexes: [2, 3, 4], offsets: [0, 12345, 8, 999], lengths: [2, 99999, 2], unpublished: [3], mapping: [[2, 0], [4, 8]], minimum: 0, end: 10, wrap: false},
        {name: 'repeated slot fallback', indexes: [2, 2, 4], offsets: [0, 4, 8, 999], lengths: [2, 2, 2], unpublished: [], mapping: [[2, 4], [4, 8]], minimum: 0, end: 10, wrap: false},
        {name: 'dense identifier wrap', indexes: [2, 3, 4], offsets: [0, 4, 8, 999], lengths: [2, 2, 2], unpublished: [], mapping: [[2, 0], [3, 4], [4, 8]], minimum: 0, end: 10, wrap: true},
        {name: 'permuted identifier wrap', indexes: [4, 2, 3], offsets: [0, 4, 8, 999], lengths: [2, 2, 2], unpublished: [], mapping: [[4, 0], [2, 4], [3, 8]], minimum: 0, end: 10, wrap: true},
    ];

    test.each(cases.flatMap((fixture) => [false, true].map((owned) => ({...fixture, owned}))))('preserves exact mappings for $name with owned=$owned', (fixture) => {
        const database = new DictionaryDatabase();
        const seed = publishSlabMeta(database, Uint8Array.of(42), 0, 1, 10, 20);
        const published = Reflect.get(database, '_termEntryContentMetaStateTable')[seed.staged.indexes[0]];
        const cache = Reflect.get(database, '_cacheRecentPublishedTermContentSources');
        const states = new Uint8Array(8);
        for (const index of fixture.indexes) {
            if (index >= 0) { states[index] = published; }
        }
        for (const index of fixture.unpublished) { states[index] = published + 1; }
        const batchIds = new Uint32Array(8).fill(99);
        const offsets = new Uint32Array(8).fill(77);
        const owner = {
            _termEntryContentMetaStateTable: states,
            _termEntryContentMetaRecentSourceBatchIdTable: batchIds,
            _termEntryContentMetaRecentSourceOffsetTable: offsets,
            _recentTermContentSourceBatches: fixture.wrap ? new Map([[99, Uint8Array.of(1)]]) : new Map(),
            _recentTermContentSourceBatchBytes: fixture.wrap ? 1 : 0,
            _recentTermContentSourceCacheMaxBytes: 48 * 1024 * 1024,
            _nextRecentTermContentSourceBatchId: fixture.wrap ? 0x100000000 : 1,
        };
        const source = Uint8Array.from({length: 20}, (_, i) => i + 1);
        if (fixture.owned) { registerOwnedTermContent(source); }
        const expectedBytes = source.slice(fixture.minimum, fixture.end);
        const offsetBacking = new Uint32Array(fixture.offsets.length + 2).fill(9999);
        offsetBacking.set(fixture.offsets, 1);
        const spans = {buffer: source, offsets: offsetBacking.subarray(1, fixture.offsets.length + 1), lengths: Uint32Array.from(fixture.lengths)};
        /** @type {Record<string, number>} */
        const metrics = {};
        expect(cache.call(owner, {indexes: Int32Array.from(fixture.indexes), active: true}, spans, metrics)).toBe(expectedBytes.length);
        const expectedIds = new Uint32Array(8).fill(fixture.wrap ? 0 : 99);
        const expectedOffsets = new Uint32Array(8).fill(77);
        for (const [index, offset] of fixture.mapping) {
            expectedIds[index] = 1;
            expectedOffsets[index] = offset;
        }
        expect(batchIds).toEqual(expectedIds);
        expect(offsets).toEqual(expectedOffsets);
        expect([...spans.offsets]).toEqual(fixture.offsets);
        expect(owner._recentTermContentSourceBatchBytes).toBe(fixture.owned ? source.byteLength : expectedBytes.length);
        expect(owner._recentTermContentSourceBatches.size).toBe(1);
        if (fixture.owned) {
            expect(owner._recentTermContentSourceBatches.get(1)?.buffer).toBe(source.buffer);
            expect(takeOwnedTermContent(source)).toBe(false);
            expect(metrics).toEqual({dedupRecentSourceAdoptedBytes: expectedBytes.length});
        } else {
            source.fill(0);
            expect(metrics).toEqual({});
        }
        expect(owner._recentTermContentSourceBatches.get(1)).toEqual(expectedBytes);
    });

    test('rejects an invalid later span without publishing any cache mappings', () => {
        const database = new DictionaryDatabase();
        const seed = publishSlabMeta(database, Uint8Array.of(42), 0, 1, 10, 20);
        const published = Reflect.get(database, '_termEntryContentMetaStateTable')[seed.staged.indexes[0]];
        const owner = {
            _termEntryContentMetaStateTable: new Uint8Array(2).fill(published),
            _termEntryContentMetaRecentSourceBatchIdTable: new Uint32Array(2),
            _termEntryContentMetaRecentSourceOffsetTable: new Uint32Array(2),
            _recentTermContentSourceBatches: new Map(),
            _recentTermContentSourceBatchBytes: 0,
            _recentTermContentSourceCacheMaxBytes: 48 * 1024 * 1024,
            _nextRecentTermContentSourceBatchId: 1,
        };
        const cache = Reflect.get(database, '_cacheRecentPublishedTermContentSources');
        expect(cache.call(owner, {indexes: new Int32Array([0, 1]), active: true}, {
            buffer: new Uint8Array(4), offsets: new Uint32Array([0, 3]), lengths: new Uint32Array([2, 2]),
        })).toBe(0);
        expect(owner._recentTermContentSourceBatches.size).toBe(0);
        expect([...owner._termEntryContentMetaRecentSourceBatchIdTable]).toEqual([0, 0]);
        expect([...owner._termEntryContentMetaRecentSourceOffsetTable]).toEqual([0, 0]);
        expect(owner._nextRecentTermContentSourceBatchId).toBe(1);
    });
});
