# Compact session evidence bundle: selection plan

This is a preparation plan only. No archive, hashing campaign or upload is authorized by this file. Root owns publication. Acquisition CPU remains reserved for the current fixed score-cache v2 cohort.

## Purpose and boundary

Preserve the negative and held results of this session so a future optimization attempt can inspect exact mechanisms, source identities, timing boundaries, complete observations, controls and failures without repeating the same investigation. Keep the experiments and revisions separate. No favorable partial acquisition becomes a completed cohort, and no current driver is silently substituted for an earlier unbound driver.

Baseline is `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`, tree `d99ea4d04658f7ec1c76acdc5f3684594212a471`, in `ManabiIO/manabitan`. The root indexes are `evidence/READOUT-1b47.md`, `evidence/evidence-inventory-1b47.json`, and `evidence/input-identities-1b47.json`. Copy their final source-bound snapshots when packaging; current files remain live session indexes until then.

Score restoration and CRC already have complete dedicated bundles at immutable evidence commit `3c3ba7600a8811df6b8631b72a0ac5379f8b60d1`, under `dev/perf/import-evidence-20261128-1b47`. Reference those exact archives/manifests instead of duplicating their raw data. The new package may retain small cross-experiment decision summaries and the published bundle identities.

## Included experiments

| Scope | Preserve | Reproduction / interpretation boundary |
| --- | --- | --- |
| Original and source-consumed content pipeline | Both separate eight-pair public-sink reports, logs, warmups, exact verification outputs, original patch, final frozen source/test changes, source-bound runtime identities, driver versions with provenance, lifetime reviews, validation failures and corrected receipts | Async Node storage is narrower than browser sync handles/SQLite/UI. Original negative result and revised inconclusive result stay separate. Other branch #977 is an overlapping alternative, never an additive gain. |
| Source-cache statistics fusion | Full eight-pair cohort, exact verification, abandoned runtime patch, concrete proxy failure and reproduction, inclusive phase analysis | The cache-only phase drop moved work. Preserve the failing exotic-caller path and inclusive non-win, not only the isolated metric. |
| Local 8 MiB checkpoint | Exact 19-line runtime diff and focused tests, validation logs, frozen workflow/protocol identities, available complete hosted raw receipts and memory audit | Keep unchanged remote-worker policy explicit. The completed VNDB cohort is a non-win and does not measure the local JMdict/Jitendex checkpoint path. |
| Compression levels −2 / rejected −3 | Every raw compression/decoder observation and JSONL, complete size and independent-decoder census, frame manifests, two full-sink capture reports, all helper scripts and source/test diff, exact storage policy/driver/tests, standalone worker sequence, every Vitest failure and signal/resource observation, hosted small receipts, independent reassessment | Preserve fresh versus retained context schedules separately, exact +312,404/+750,018 B costs, noisy decoder controls, and the −3 size rejection before timing. Do not attribute the retained result causally to CCtx reuse. |
| SIMD inflater match copies | Exact native variants/patches and manifests, full JM/Jit inflate screens, all oracle hashes, both incomplete Jit parser acquisitions and their declarations/failure status, source/layout controls and preparation erratum | No complete parser qualification; no pooled or retried observations. |
| Broad key-run glossary reuse | Frozen source/test changes and generated-module identity, full JM/Jit six-block screens, controls, both earlier preparation failures, census and complete validation receipts | More witnesses did not become a useful gain against both controls. |
| Distance-two key-run | Frozen source/test changes and module identity, complete JM/control data, untimed census, Jit warmup kill/zero-measured-groups evidence | Preserve the acquisition failure and no-retry decision. |
| Delayed key hint | Frozen source/test changes and module identity, native function-body audit, both full 18-child cohorts, all plans/proofs/logs/observations, attribution | Favorable Jit phase has no eliminated work; caller code layout differs. Keep the held conclusion. |
| Immediate comma guard | Source/test diff and manifests, all focused validation, original six-block child screens and separate 24-block confirmations, every child record/proof/log, frozen bootstrap protocol and decision note | No control-qualified mechanism gain; no pooling, promotion or further acquisition. |
| Read-only and bounded leads | Owned-copy width probe, exact grouping/copy/score-radius censuses, native/glossary/key-run work censuses, canonical-header overlap, accidental-reversion audit and typed-loop audit | Work counts and isolated probes remain counts/probes, not full-import gains. |

The exact-tag score cache is **outside this package for now**. Its v1/v2 source, actual encoder input backings, protocols, observations and controls belong in a separate small bundle if root decides that result warrants review. The completed score/CRC archives remain the authority for their promoted component claims.

## Common material to preserve

- Exact fixture locks, source/native/runtime identities, toolchain version/build flags and reconstruction scripts. Include one unique frozen source snapshot or patch per candidate and its meaningful tests; avoid repeated worktree/build copies.
- Node sink and native-child protocols, each historical revision actually used, registration manifests, raw output/source/storage oracles, failure-stop semantics and independent reviews.
- Final readout/inventory and source-bound claim notes. Make each claimed validation explicitly refer to the source it tested; later test-only repairs do not relabel earlier runs.
- Small ordinary browser baseline receipts and extracted diagnostic analyses, plus hosted study status snapshots and complete small raw receipts already downloaded at packaging time. Pending remote jobs remain pending; later data requires a separately identified supplement.
- Local browser setup failure and environment/resource failures, without unrelated workspace or credential data.

## Exclusions and omission records

Do not include full dictionary ZIPs, media payloads, `node_modules`, compiler/browser distributions, raw 100–400 MB source slabs, raw compression frame payloads, full DB directories, duplicate extension packages or repeated generated builds. Large browser traces can be represented by exact original artifact/file hashes and the extraction script plus extracted relevant analysis.

Record each omitted input's original relative path, byte count, SHA-256 from an existing verified manifest or relocation receipt, role, and reconstruction source/command. If no original hash was captured, say so explicitly; do not fabricate an exact binding from a later reconstruction. Any absent original driver gets an explicit provenance limitation, as the dedicated CRC bundle already does for its first rejected slicing32 acquisition.

`evidence/compression-level-payload-relocation.json` is the authority for the 976 relocated compression payloads. Retain the receipt, original frame/census hashes and reconstruction helpers. Never dereference its replacement symlinks while selecting or packaging. The earlier rejected −3 deletion receipt is also retained.

## Packaging mechanics after CPU release

1. Build an explicit allowlist using `lstat` and traversal with symlink following disabled. Classify every symlink as an omitted payload reference; never add its target bytes. Exclude generated caches and unrelated files. Produce a dry selection report with member counts and uncompressed sizes before archive creation.
2. Resolve source/driver bindings. Prefer immutable remote commits where available and exact local patches/objects for unpublished candidates. Verify historical driver hashes against retained versions where possible; add limitations where impossible. Do not modify original observations.
3. Write README/reproduction commands and a machine-readable experiment-to-members map. Link the already published score/CRC bundles by immutable commit, archive hash and manifest. Keep validation and negative evidence complete within the stated scope.
4. Reuse the deterministic archive format from `package-evidence.py`: exact workspace-relative payload paths, normalized archive metadata, one SHA-256/byte count per member, external archive/manifest digests. Verify the complete archive member set and every member after construction.
5. Run a bounded sensitive-pattern scan on text members, reporting only filenames/counts. Exclude signed artifact-download URLs, credentials and unrelated personal data. Public repository receipt metadata can be classified explicitly.
6. Root reviews selection, provenance limitations and size before any upload. If authorized, upload only unreferenced Git blobs, compare returned blob IDs to local `git hash-object`, and perform exact text readback. Binary fetch limitations must remain explicit; no claim of remote binary readback without a successful download.

No packaging CPU, bulk hash/read work, upload, ref, commit or PR has occurred for this planned session package.
