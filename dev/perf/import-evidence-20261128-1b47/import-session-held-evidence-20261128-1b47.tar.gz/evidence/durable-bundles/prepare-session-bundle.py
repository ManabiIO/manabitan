#!/usr/bin/env python3
"""Select held-session evidence without following any relocated payload link."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT / 'manabitan'
EVIDENCE = ROOT / 'evidence'
OUT = EVIDENCE / 'durable-bundles/session'
BASE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
sha = lambda data: hashlib.sha256(data).hexdigest()
git = lambda *args: subprocess.check_output(['git', '-C', str(REPO), *args])
selected = set()
omissions = []
expected = {}
bindings = []
OUT.mkdir(parents=True, exist_ok=True)

relocation = json.loads((EVIDENCE / 'compression-level-payload-relocation.json').read_text())
assert relocation['complete'] is True
relocated = {str(Path(item['source']).relative_to(ROOT)): item for item in relocation['files']}


def add_file(path):
    relative = path.relative_to(ROOT).as_posix()
    mode = path.lstat().st_mode
    if stat.S_ISLNK(mode):
        assert relative in relocated, f'Unclassified symlink: {relative}'
        item = relocated[relative]
        assert os.readlink(path) == item['destination']
        omissions.append({'path': relative, 'bytes': item['bytes'], 'sha256': item['sha256'],
                          'included': False, 'kind': 'relocated-regenerable-compression-payload',
                          'hashOrigin': 'Verified original relocation receipt; target was not read',
                          'reconstruction': 'Original capture/census helpers plus exact fixture/source manifests; see compression-level-payload-relocation.json'})
        return
    assert stat.S_ISREG(mode), relative
    if path.name.endswith('.trace.json'):
        data = path.read_bytes()
        omissions.append({'path': relative, 'bytes': len(data), 'sha256': sha(data),
                          'included': False, 'kind': 'full-browser-diagnostic-trace',
                          'reconstruction': 'Recorded baseline run 46100401987 and downloaded-artifact-archives.json; analyze_current_profiles.py and extracted analysis included'})
        return
    assert path.suffix not in {'.zip', '.html'}, f'Unexpected large payload needs explicit classification: {relative}'
    selected.add(relative)


def add_tree(path):
    assert not path.is_symlink(), path
    if path.is_file():
        add_file(path)
        return
    for directory, dirs, files in os.walk(path, followlinks=False):
        dirs[:] = [name for name in dirs if name != '__pycache__']
        for name in dirs:
            assert not (Path(directory) / name).is_symlink(), f'Symlink directory: {name}'
        for name in files:
            add_file(Path(directory) / name)


native = {
    'broad-keyrun': '538163eed5d45072dd8ca39462994d81215c0ecc',
    'distance-two': 'f6251f8118516ac3ebe7d21e56e6436461052e93',
    'delayed-keyhint': '640e78d7c94d841b14d0b62e08529dcdbfbd60b7',
    'immediate-comma': '252686b2edb70dd365838d1730098281653b82b5',
}
for label, commit in native.items():
    paths = git('diff', '--name-only', BASE, commit).decode().splitlines()
    rows = []
    for name in paths:
        data = git('show', f'{commit}:{name}')
        rows.append({'path': name, 'bytes': len(data), 'sha256': sha(data),
                     'gitBlob': git('rev-parse', f'{commit}:{name}').decode().strip()})
    patch_paths = [name for name in paths if not name.endswith('.wasm')]
    (OUT / f'{label}-source.patch').write_bytes(git('diff', BASE, commit, '--', *patch_paths))
    bindings.append({'study': label, 'commit': commit,
                     'tree': git('rev-parse', f'{commit}^{{tree}}').decode().strip(), 'changedFiles': rows})
pack = OUT / 'native-checkpoints.pack'
pack_bytes = subprocess.check_output(['git', '-C', str(REPO), 'pack-objects', '--stdout', '--revs'],
                                    input=('\n'.join(native.values()) + '\n^' + BASE + '\n').encode())
pack.write_bytes(pack_bytes)
pack_id = subprocess.check_output(['git', '-C', str(REPO), 'index-pack', '--strict', str(pack)]).decode().strip()
subprocess.run(['git', '-C', str(REPO), 'verify-pack', str(pack.with_suffix('.idx'))], check=True,
               stdout=subprocess.DEVNULL)

dirty = [
    ('pipeline', 'pipeline-experiment', '05907e30c83b4cc7cc8d653e069427a6141b0e85'),
    ('checkpoint', 'checkpoint-experiment', '0efd7507eb19b0b7f15410b14aac427e80e22244'),
    ('compression-level', 'compression-level-experiment', 'f7980e638ea1808701ac28339987663fd8b3dc4e'),
]
for label, tree, remote in dirty:
    local = ROOT / tree
    assert subprocess.check_output(['git', '-C', str(local), 'rev-parse', 'HEAD']).decode().strip() == BASE
    paths = subprocess.check_output(['git', '-C', str(local), 'diff', '--name-only']).decode().splitlines()
    rows = []
    for name in paths:
        path = local / name
        data = path.read_bytes()
        rel = path.relative_to(ROOT).as_posix()
        rows.append({'path': rel, 'bytes': len(data), 'sha256': sha(data),
                     'gitBlob': subprocess.check_output(['git', 'hash-object', str(path)]).decode().strip()})
        expected[rel] = sha(data)
        add_file(path)
    (OUT / f'{label}-current.patch').write_bytes(subprocess.check_output(
        ['git', '-C', str(local), 'diff', '--binary', 'HEAD', '--']))
    bindings.append({'study': label, 'baseline': BASE, 'publishedStudyHead': remote,
                     'localSnapshotKind': 'Frozen working-tree changes on baseline; not a local commit',
                     'changedFiles': rows})

# Reconstruct the abandoned/earlier patches in private evidence directories and
# prove their runtime byte identity against the original cohort fingerprints.
for label, patch_name, cohort, prototype in [
    ('pipeline-original', 'pipeline-initial-overlap.patch', 'node-jmdict-pairs', 'pipeline'),
    ('cache-fusion', 'cache-range-abandoned.patch', 'node-jmdict-cache-pairs', 'cache'),
]:
    patch = EVIDENCE / patch_name
    target = OUT / 'source-snapshots' / label
    if target.exists():
        # Only this preparer's regenerable, task-owned patch derivation is replaced.
        assert target.parent == OUT / 'source-snapshots' and not target.is_symlink()
        shutil.rmtree(target)
    target.mkdir(parents=True)
    paths = re.findall(r'^diff --git a/(.+) b/.+$', patch.read_text(), re.M)
    for name in paths:
        result = subprocess.run(['git', '-C', str(REPO), 'show', f'{BASE}:{name}'], capture_output=True)
        if result.returncode == 0:
            destination = target / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(result.stdout)
    subprocess.run(['git', '-C', str(target), 'apply', '--check', str(patch)], check=True)
    subprocess.run(['git', '-C', str(target), 'apply', str(patch)], check=True)
    report = json.loads((EVIDENCE / cohort / 'summary.json').read_text())
    source = target / 'ext/js/dictionary/dictionary-database.js'
    observed = sha(source.read_bytes())
    assert observed == report['fingerprints']['B']['ext/js/dictionary/dictionary-database.js'], label
    bindings.append({'study': label, 'source': source.relative_to(ROOT).as_posix(), 'sha256': observed,
                     'proof': 'Reconstructed original patch matches original measured runtime fingerprint',
                     'cohort': f'evidence/{cohort}/summary.json'})

pipeline = json.loads((EVIDENCE / 'node-jmdict-source-consumed-pairs/summary.json').read_text())
assert sha((ROOT / 'pipeline-experiment/ext/js/dictionary/dictionary-database.js').read_bytes()) == pipeline['fingerprints']['B']['ext/js/dictionary/dictionary-database.js']
assert sha((ROOT / 'checkpoint-experiment/ext/js/dictionary/term-record-import-index-writer.js').read_bytes()) == '60b1dc2ed95ae7f313c34247f00e150dfb8a62ef5500c2f5c0297421ba924cba'
assert sha((ROOT / 'compression-level-experiment/ext/js/dictionary/zstd-term-content.js').read_bytes()) == 'e4f3858167076d76c6ad4729afb26ba637530fe9edd6c966fe2a86f6fa856de5'
(OUT / 'source-bindings.json').write_text(json.dumps({'baseline': BASE, 'studies': bindings,
    'nativePack': {'path': pack.relative_to(ROOT).as_posix(), 'bytes': len(pack_bytes),
                   'sha256': sha(pack_bytes), 'packId': pack_id, 'ancestryRequired': BASE, 'refsCreated': False},
}, indent=2) + '\n')

directories = [
    'compression-level', 'compression-level-study', 'current-baseline-jmdict',
    'current-baseline-jitendex', 'current-baseline-vndb', 'node-jmdict-pairs',
    'node-jmdict-source-consumed-pairs', 'node-jmdict-cache-pairs', 'inflate-match-copy',
    'jmdict-keyrun-candidate', 'jmdict-distance2-candidate', 'jmdict-delayed-keyhint-candidate',
    'immediate-comma', 'jmdict-native-census', 'jmdict-glossary-census', 'jmdict-keyrun-census',
    'jmdict-distance2-census', 'jmdict-delayed-keyhint-census', 'native-child-screen-1b47',
    'native-child-screen-1b47-v2', 'native-child-screen-1b47-v3', 'hosted-queue-audit-20261128',
    'publication-review-1b47', 'hosted-checkpoint-vndb-46104738613',
    'hosted-pipeline-jitendex-46105215670',
]
for name in directories:
    add_tree(EVIDENCE / name)
exclude_top = {
    'crc8_4-pr-draft.md', 'build_crc_tail_probes.py', 'hosted-crc8_4-initial-validation-failed.log',
    'jmdict-score-validation-screen-1b47.yml', 'node-jmdict-score-validation-pairs.log',
    'node-score-capture-replay.mjs', 'node-score-encoder-input-capture.mjs', 'node-score-verify-replay.mjs',
    'node-sink-jmdict-score-validation-initial-setup-failure.log',
    'node-sink-jmdict-score-validation-verify.json', 'node-sink-jmdict-score-validation-verify.log',
    'run-jmdict-score-validation-pairs.py', 'score-restoration-pr-draft.md',
    'score-restoration-pr-review.md', 'score-validation-baseline-capture.log',
    'score-validator-real-input-probe.mjs', 'compression-level-payload-relocation.json.new',
}
for path in EVIDENCE.iterdir():
    if path.is_file() and path.name not in exclude_top:
        if path.name.startswith('hosted-import-screens-status-'):
            stamp = ''.join(re.findall(r'\d', path.name)).ljust(14, '0')
            if stamp > '20261128063235':
                continue
        add_file(path)
for name in ['package-evidence-v2.py', 'prepare-session-bundle.py']:
    add_file(EVIDENCE / 'durable-bundles' / name)
for name in ['package.json', 'package-lock.json', 'dev/data/dictionary-wasm/README.md',
             'dev/data/dictionary-wasm/manifest.json']:
    add_file(REPO / name)

# Bind currently retained drivers to recorded hashes without retroactively
# asserting that an unbound historical helper is the original acquisition.
hash_to_paths = {}
for name in sorted(selected):
    if Path(name).suffix in {'.mjs', '.py', '.js', '.cjs'}:
        hash_to_paths.setdefault(sha((ROOT / name).read_bytes()), []).append(name)
driver_bindings = []
for name in sorted(selected):
    if Path(name).suffix != '.json':
        continue
    try:
        data = json.loads((ROOT / name).read_text())
    except (ValueError, UnicodeError):
        continue
    if isinstance(data, dict) and isinstance(data.get('driverSha256'), str):
        digest = data['driverSha256']
        driver_bindings.append({'report': name, 'driverSha256': digest,
                                'exactRetainedMatches': hash_to_paths.get(digest, []),
                                'status': 'exact retained driver' if digest in hash_to_paths else 'unresolved original driver; no later substitute asserted'})
(OUT / 'driver-bindings.json').write_text(json.dumps(driver_bindings, indent=2) + '\n')
add_tree(OUT)
spec_rel = 'evidence/durable-bundles/session/bundle-spec.json'
selected.add(spec_rel)
omissions.extend([
    {'kind': 'already-published-component-evidence', 'included': False,
     'commit': '3c3ba7600a8811df6b8631b72a0ac5379f8b60d1',
     'directory': 'dev/perf/import-evidence-20261128-1b47',
     'archives': {
         'score-restoration-evidence-20261128-1b47.tar.gz': '56e214cf9107725113593c25eb290e36c390b02bf51e169e2632a3726a518841',
         'crc8_4-evidence-20261128-1b47-v2.tar.gz': '4d47af5543a594dfc4083efabfd568250dfc28d48f53e9361b53722f0d3dd823'},
     'reason': 'Complete separate archives retained at immutable public commit; no duplicate payload'},
    {'kind': 'separate-held-cache-evidence', 'included': False,
     'archive': 'score-cache-held-evidence-20261128-1b47.tar.gz',
     'reason': 'Complete actual numeric inputs, both source revisions and all v1/v2 reports retained in separate companion bundle'},
    {'kind': 'large-reconstructible-runtime-and-corpus-payload', 'included': False,
     'items': ['dictionary ZIPs/media', 'node_modules', 'browser/compiler distributions', 'full OPFS stores', 'duplicate extension packages'],
     'reconstruction': 'Exact fixture/source/runtime manifests, complete file-set receipts and original capture/build helpers retained; see README'},
])
selected.add('evidence/durable-bundles/session/selection.json')
selection = {'asOfHostedSnapshotUtc': '2026-11-28T06:32:35Z', 'selectedMembers': len(selected), 'symlinkPayloadsSkipped': sum(x.get('kind') == 'relocated-regenerable-compression-payload' for x in omissions),
             'sourceSnapshotsVerified': True, 'driverBindings': driver_bindings,
             'paths': sorted(selected)}
(OUT / 'selection.json').write_text(json.dumps(selection, indent=2) + '\n')
spec = {'name': 'import-session-held-evidence-20261128-1b47',
        'study': 'Held and negative import optimization experiments, 2026-11-27/28',
        'scope': 'Source-bound native, pipeline, cache-fusion, checkpoint and compression protocols, complete/failed observations and small hosted receipts; no unqualified promotion',
        'sourceBindings': {'baseline': BASE, 'details': 'evidence/durable-bundles/session/source-bindings.json'},
        'include': sorted(selected), 'expectedSha256': expected, 'omitExternal': omissions}
(ROOT / spec_rel).write_text(json.dumps(spec, indent=2) + '\n')
print(json.dumps({'spec': spec_rel, 'members': len(selected),
                  'payloadBytes': sum((ROOT / name).stat().st_size for name in selected),
                  'omissions': len(omissions), 'skippedSymlinks': selection['symlinkPayloadsSkipped'],
                  'unresolvedDriverBindings': [x for x in driver_bindings if not x['exactRetainedMatches']]}))
