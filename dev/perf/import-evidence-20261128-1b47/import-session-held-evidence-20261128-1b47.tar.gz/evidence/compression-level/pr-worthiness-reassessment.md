# Compression level −2: independent review recommendation

## Recommendation

Keep the existing experimental branch and wait for its already registered browser result before opening a product PR. This is a judgment about whether the proposed storage policy is worth adopting, not an additional requirement imposed by the user. The user permits a component-scoped gain to justify review, and the retained-context Jitendex component result is credible enough to justify the browser trial. It does not yet establish that increasing persistent storage for both JMdict and Jitendex is a useful product tradeoff.

The case differs from the score restoration and CRC tail change. Those remove work while retaining output bytes and allocation policy. This one-line level change deliberately increases stored bytes and changes compressed match/literal structure. Its strongest evidence is for warm Jitendex compression; JMdict, the user's priority, has only a small signal comparable to its identical-code control variation. No extra measurement, altered gate, or new product variant is recommended here.

## What is actually measured

The complete frozen frame captures contain 103 JMdict frames and 385 Jitendex frames. The baseline recompression reproduces every original envelope/frame byte. Every level −1/−2 frame decodes exactly through both the production WASM decoder and independent libzstd. The level −3 size failure is retained and was rejected before timing.

The fixed retained-context campaign has 12 balanced A/B/C blocks, with A and C independently instantiated identical level −1 modules and B at level −2. It reports these paired results:

| Corpus | B/A median wall change | B/C median wall change | Paired absolute savings | Faster blocks B/A, B/C |
| --- | ---: | ---: | ---: | ---: |
| JMdict | −2.960% | −1.751% | 5.257 / 3.316 ms | 7/12, 6/12 |
| Jitendex | −7.959% | −8.355% | 43.358 / 46.668 ms | 9/12, 10/12 |

For Jitendex, geometric wall changes are −7.310% and −7.273%; CPU paired medians also improve, by −6.842% and −9.484%. Its identical C/A wall median is +0.741% and geometric change is −0.040%. This is an owning-phase signal against both controls, not merely a faster unrelated parser phase. However, individual retained Jitendex B/A wall ratios range from about 0.695 to 1.285. Twelve blocks do not provide a tight universal magnitude guarantee. JMdict's identical C/A wall median is −1.735%, approximately the size of its B/C median improvement.

The endpoint sums serial per-frame calls to the shipped compression wrapper. It includes copies, native compression, envelope work and owned output copying. It excludes gathering, parallel worker scheduling, parser, storage and publication. The 43–47 ms Jitendex saving is therefore not a 43–47 ms browser-import saving. Production can distribute this work across four compression workers.

## CCtx lifetime: an important qualification

Production `initializeTermContentZstd` creates one module-global compression context. Each compression worker initializes its own module once and reuses that context for subsequent jobs. This makes context reuse relevant.

But the diagnostic's **fresh-context** phase already creates one CCtx per complete corpus and reuses it for all 103 or 385 frames. Its **retained-context** phase creates contexts once, performs two excluded full-corpus warmups, then measures 12 further complete corpora. A first production import initializes fresh worker contexts and assigns only a subset of frames to each worker. Consequently, production CCtx reuse does not make the fresh-context result irrelevant or prove that the retained phase is the uniquely representative one.

In the six-block Jitendex fresh-context phase, median B/A wall improvement is 2.779%, but B/C is only 0.322% (about 1.803 ms). Geometric improvements are 3.734% and 2.236%, while the identical C/A wall median is −2.115%. Both phases are retained; their disagreement cannot be causally attributed to context lifetime from this experiment alone. Shared-host variation and phase history remain plausible contributors. The already registered fresh-profile browser screen is the appropriate next evidence.

## Exact policy cost and remaining risk

Using complete browser receipt denominators:

| Corpus | Baseline persisted bytes | Candidate persisted bytes | Exact increase |
| --- | ---: | ---: | ---: |
| JMdict | 43,520,477 | 43,832,881 | +312,404 B / +0.717832% |
| Jitendex | 67,466,332 | 68,216,350 | +750,018 B / +1.111692% |
| VNDB | 609,176,779 | 609,176,779 | 0 B |

These pass the prospectively declared 2% total-storage ceiling. Passing that ceiling establishes admissibility for the tradeoff study, not that the extra storage is worthwhile. It is a deterministic cost even if import latency does not improve.

The separate decoder campaign has large identical-code control movement. It establishes exact decoding, but neither a reliable decoder gain nor a tight lookup/decode non-regression bound. The reported 16,908,288-byte per-module WASM capacity is heap capacity, not live-context allocation or browser peak memory.

## Current gates and overlap

At this read-only review, exact trial head `f7980e638ea1808701ac28339987663fd8b3dc4e` has green hosted validation in run `46108665276`, job `140867047169`: pinned native reproduction, unchanged receipt validator plus separate exact-delta policy, full unit tests, all build targets, scoped lint, and runtime/test types. Browser jobs `140885881806` (JMdict), `140885881799` (Jitendex), and `140885881812` (VNDB) remain queued. The separate actionlint run `46108665225` also completed successfully. No browser qualification is claimed.

The local real-worker Vitest failures remain retained. Exact standalone worker sequence/ownership parity passed, and one original child was observed terminating with SIGKILL; unavailable cgroup evidence prevents calling that a proven OOM. Hosted success resolves the current test gate without erasing those failures.

Fresh PR searches for the constant and quoted level −2 found no competing level-policy proposal. Related open work such as #974 concerns startup asset/module sharing and #977 concerns bounded content overlap; neither is this compression-level change. The earlier #771 prepared-dictionary audit is also a different mechanism.

## Sources

- Frozen production source: `manabitan/ext/js/dictionary/zstd-term-content.js`, `zstd-term-content-compression-worker.js` at baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
- Exact diagnostic schedule and boundaries: `evidence/compression-level-timing.mjs`.
- All raw observations and summaries: `evidence/compression-level/{jmdict,jitendex}/compression-timing.json`, their JSONL companions, decoder reports, and `summary.json`.
- Exact storage policy: `evidence/compression-level-study/real-baseline-policy-projection.json` and `compression_receipts.py`.
- Current hosted metadata: `https://github.com/ManabiIO/manabitan/actions/runs/46108665276`.
