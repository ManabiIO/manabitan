# Real-frame Zstd level diagnostic

Baseline: `ManabiIO/manabitan` develop `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.

The component diagnostic changed no product source, level constant, native binary, grouping, worker policy or stored format. It calls the existing production compression/decompression APIs with explicit levels. It is component evidence, not a complete browser import or lookup-latency measurement. An isolated one-constant browser-trial candidate was subsequently published at `f7980e638ea1808701ac28339987663fd8b3dc4e`; its validation boundary is recorded below. No PR was opened.

## Decision

Level **−2** stays within the prospectively fixed **2% total persisted term-store byte ceiling** for both affected corpora. Its retained-context compression benefit is appreciable for Jitendex and small/noisy for JMdict. Fresh-context results are weaker. The separate decoder screen has substantial identical-code variation and cannot establish a tight lookup decode nonregression bound. **These results alone do not establish a reviewer-worthy complete-import gain or justify a PR.**

Level **−3** fails the Jitendex storage ceiling and was dropped before any timing campaign. The ceiling was not changed after observing sizes. A dictionary-specific level split was not tried.

## Exact coverage and storage tradeoff

The capture observes complete admitted primary chunks at the production `beginAppendBatchWithDerivedPrefix` and `appendBatchWithDerivedChunks` storage boundaries. Snapshots own compressed bytes. The unmodified public sink still parses the pinned archives, performs real canonical deduplication, uses the production compression workers, and serializes the actual record/index files. Only Node worker/fetch/async-OPFS boundaries are adapted; SQLite, media storage and browser OPFS synchronous-handle costs are outside this component.

| Corpus | Production groups | Actual frames | Raw bytes represented by frames | Baseline frame/envelope bytes | Compact references | Complete content file |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| JMdict | 12 | 103 | 100,300,626 | 12,326,040 | 362,032 × 20 B = 7,240,640 B | 19,566,680 B |
| Jitendex | 22 | 385 | 389,687,485 | 31,121,935 | 363,243 × 20 B = 7,264,860 B | 38,386,795 B |

The earlier informal count of 102 JMdict frames was an arithmetic error; the actual group counts sum to **103**. The smaller captured byte total is fully explained by excluding the separate fixed-width references. Captured frame bytes plus references exactly equal the complete content file for each corpus.

| Corpus | Baseline total persisted term-store bytes | Level −2 added bytes | Level −2 total increase | Level −3 added bytes | Level −3 total increase |
| --- | ---: | ---: | ---: | ---: | ---: |
| JMdict | 43,315,677 | 312,404 | +0.7212% | 774,370 | +1.7877% |
| Jitendex | 61,977,692 | 750,018 | +1.2101% | 2,873,633 | **+4.6366%, rejected** |

These component totals exclude SQLite and media. Adding them to the denominator makes the percentage smaller; the component screen deliberately used the stricter captured term-store denominator. The new browser protocol binds the same exact byte deltas to the complete canonical browser inventory:

| Corpus | Exact baseline complete browser storage | Prospective candidate complete storage | Exact permitted increase |
| --- | ---: | ---: | ---: |
| JMdict | 43,520,477 B | 43,832,881 B | 312,404 B; +0.7178% |
| Jitendex | 67,466,332 B | 68,216,350 B | 750,018 B; +1.1117% |
| VNDB | 609,176,779 B | 609,176,779 B | 0 B; 0% |

The browser policy checks both the exact term-content-file delta and exact complete-inventory delta, plus an integer 2% ceiling. Only a labeled comparison copy subtracts these two quantities from arm B before applying the unchanged receipt matcher. Raw reports and canonical receipts remain intact. A/C and within-arm comparisons remain exact; VNDB permits no change. Source, package, semantic, restart, media, memory and original receipt-validator gates remain binding. Hardware/grouping differences that change the predicted delta must fail this protocol rather than silently enlarge its allowance.

The capture's full source digest and every persisted file match the independently obtained exact-baseline census. Recompressing every captured frame at −1 reproduces the entire original MBC2 envelope and compressed payload byte-for-byte. Every −1/−2/−3 output independently decompresses to the same exact raw bytes with both the production WASM decoder and system **libzstd 1.5.7**. Raw blocks were decoded one at a time and never materialized as a large disk dataset.

## Fixed compression campaign

Each arm has its own unchanged JS module, WASM module, linear memory and compression context. A and C both use level −1; B uses −2. A fourth module performs input decoding outside compression timers. All output hashes must match the prior untimed census.

The fixed schedule contains one descriptive first-module corpus per arm, six balanced fresh-context triplets, two excluded retained-context warmup triplets, and twelve balanced retained-context triplets. Cold, fresh and retained results remain separate. There were no retries, optional stopping, discarded observations or product-code changes during the campaign.

Wall and process CPU are summed around each existing `compressUsingDictWithPrefix` call. This includes copying input/dictionary bytes, native compression, the integrity envelope and the owned output copy. It excludes span gathering, decoding, hashes, worker scheduling, parsing, storage and import publication. CPU boundaries include adjacent timer reads equally in every arm. Complete-observation CPU, which also includes decoding/hash work, is separately retained.

### Retained-context results

Negative percentages are faster. Absolute savings are paired corpus-level differences, not differences of independently selected medians.

| Corpus | Wall B/A; B/C paired median | CPU B/A; B/C paired median | Wall savings B/A; B/C | Faster wall pairs B/A; B/C | Same-code wall C/A |
| --- | --- | --- | --- | --- | --- |
| JMdict | −2.960%; −1.751% | −3.267%; −2.577% | 5.257 ms; 3.316 ms | 7/12; 6/12 | −1.735% |
| Jitendex | −7.959%; −8.355% | −6.842%; −9.484% | 43.358 ms; 46.668 ms | 9/12; 10/12 | +0.741% |

Retained-context geometric paired wall changes are −2.663%/−1.958% for JMdict and −7.310%/−7.273% for Jitendex. Equal-work and every individual observation remain in the machine-readable reports.

The **six fresh-context triplets are weaker**: JMdict wall B/A/B/C is −2.776%/−4.199%; Jitendex is −2.779%/−0.322%. Their CPU comparisons and control variation are retained rather than pooled into the warm results. The single cold-module comparisons visibly disagree with their same-code control, so they are descriptive only.

Every compression arm's maximum observed exported WASM capacity is exactly **16,908,288 B**, with no candidate capacity increase. This is allocated linear-memory capacity at call boundaries, not live native context allocation or whole-browser peak memory. Creation/free events and per-frame growth boundaries are recorded.

Production initializes and retains a compression context per owner/worker, so the retained-context component is relevant. The browser's existing parallel compression and storage overlap still means that the 43–47 ms sequential Jitendex saving cannot be added directly to complete-import wall time.

## Separate decoder tradeoff screen

The unmodified production `decompressUsingDict` API reads the retained −1 or −2 compressed frames, using three independent decoder modules/contexts, two excluded warmup triplets and six balanced measured triplets. Raw SHA-256 checks run outside timing and match on every call. Compression results and decoder results are not pooled.

| Corpus | Wall B/A; B/C paired median | CPU B/A; B/C paired median | Same-code wall C/A | Same-code CPU C/A |
| --- | --- | --- | --- | --- |
| JMdict | −6.533%; −5.427% | −17.512%; −8.546% | −1.246% | −1.903% |
| Jitendex | −1.398%; −9.813% | +1.680%; −12.967% | **+11.609%** | **+13.913%** |

These small decoder cohorts are noisy. JMdict's same-code geometric wall change is −9.668%, with an equal-work change of −12.182%; its favorable paired medians should not be presented without those retained tails. Jitendex's large C/A difference makes its B/C improvement especially ambiguous. No clear decode regression is established, but a tight nonregression or lookup latency guarantee is also unsupported. All decoder module capacities remain 16,908,288 B.

## Isolated browser-trial candidate and local validation boundary

Experimental branch: `perf/compression-level-screen-20261128-1b47`, head `f7980e638ea1808701ac28339987663fd8b3dc4e`. This is a trial branch, not a PR or a promoted optimization.

The runtime diff changes only `JMDICT_COMPRESSION_LEVEL` from −1 to −2 in `ext/js/dictionary/zstd-term-content.js`. Existing dictionary selection applies this to JMdict and Jitendex; generic/VNDB compression remains at level 1. Two existing test files change three expected level arguments. There is exactly one permitted packaged runtime member change. Native codec/parser bytes, dictionary bytes, block planning, worker counts and stored formats remain unchanged.

All three uploaded blobs were read back and compared exactly with their local UTF-8 contents and locally computed Git object hashes. `candidate-files.json` records the paths, sizes, Git blob SHAs and SHA-256 hashes. The runtime SHA-256 is `e4f3858167076d76c6ad4729afb26ba637530fe9edd6c966fe2a86f6fa856de5`.

Local validation did **not** complete the original full focused test batch:

- The 17-suite Zstd/block-store batch reported 16 completed suites and 203/205 passed tests, then an unhandled Vitest fork exit. The original failure log is retained.
- Both changed suites passed separately: 10/10 tests. No assertion, timeout or test case was removed.
- The unchanged packed-dispatch suite passed its 12 mock/snapshot cases, but its real three-worker case terminated the Vitest fork. An isolated baseline run of that single case passed; the corresponding candidate run still terminated. Neither failed candidate run is relabeled as a pass.
- Two diagnostic copies preserved the original assertions while recording source identities, phases, frame hashes and raw hashes. Main and all three workers loaded the exact candidate path/hash and level −2. Generic frames and decoded bytes matched, including the 1,048,585-byte input. The process then died during the following JMdict worker batch rather than reporting a codec exception or a mismatching byte assertion.
- A separate bounded diagnostic reproduced the **exact** existing sequence: six generic blocks, the intervening two 4-byte generic jobs that advance round-robin state, six JMdict blocks, and the later output-ownership checks. It used the same production API, three actual workers and unchanged source, and checked every byte with `Buffer.compare`. All 12 frames and decoded blocks matched, including 1- and 11-byte inputs and 1 MiB + 9 bytes. All worker identities matched the frozen candidate. Runtime was 0.324 seconds and process peak RSS was 135,212 KiB. This is a correctness diagnostic, not timing evidence or a substitute for the original tests.
- A diagnostic preload observed the original Vitest child exiting with **`signal: SIGKILL`, `code: null`**. This distinguishes external process termination from a caught codec/assertion failure. Standard cgroup counters were unavailable. The resource sampler captured the Vitest parent but missed the fork's RSS, so the evidence does **not** prove a particular kernel OOM cause or the fork's peak memory. Memory limits were not changed.

Every original failure, single-test control, diagnostic source/log, standalone byte/ownership report and child-exit record remains under this directory. Diagnostic test copies were moved out of the product checkout. The actual runtime and original tests remained frozen throughout this diagnosis.

Remaining mandatory hosted gates are the original full unit suite, all-target build, pinned native reproducibility, changed-file lint, main/test types, and complete browser import qualification on all three dictionaries. The browser study retains six pairs, identical-code controls, excluded warmups, exhaustive media checks, restart/readback, all raw failed observations and separate memory checks. A passing correctness gate alone does not establish useful speed or justify a PR. Decoder noise remains an explicit limitation, and an independent timing replication would be needed before a strong general speed claim.

## Evidence and reproduction

`summary.json` binds the exact helper/report hashes and includes every phase summary. Each corpus directory retains its original captured frames, frame manifest, full public-sink report, untimed level census, independent decoder proof, fixed compression report, fixed decoder report, log and raw per-frame observation JSONL.

The initial JMdict census attempt failed before processing frames because the bundled loader required a `file:` URL rather than a plain local path. Its log and empty output directory remain. The helper's loader argument was corrected, and the successful census used a distinct `levels-v2` directory. This was a tool setup failure; no acquired observation was discarded.

After rejection, only level −3 compressed output files were removed to release 47,095,978 B of workspace space. `rejected-minus3-preserved.json` retains all 488 byte counts/hashes, the census and independent decoder proof hashes, helper identities and exact regeneration commands. Original captured frames and level −2 outputs remain. The complete rejected size/correctness result is retained.

From `/workspace/scratch/1b47f6463b98`, use new output paths for every reproduction; helpers fail on existing result paths. A workspace-specific `TMPDIR` keeps the full-import OPFS shim off the crowded shared temporary filesystem.

```sh
TMPDIR=/workspace/scratch/1b47f6463b98/evidence/compression-level/opfs-temp \
  MANABITAN_COMPRESSION_CAPTURE_DIR=evidence/compression-level/reproduce-jmdict/frames \
  node evidence/node-compression-capture-replay.mjs \
  manabitan /tmp/manabitan-1b47-fixtures \
  evidence/compression-level/reproduce-jmdict-capture.json jmdict 0 1

node evidence/compression-level-census.mjs manabitan \
  evidence/compression-level/reproduce-jmdict/frames/manifest.json \
  evidence/compression-level/reproduce-jmdict/levels

python evidence/verify-compression-level-frames.py \
  evidence/compression-level/reproduce-jmdict/levels/census.json \
  manabitan/ext/lib/zstd-dicts/jmdict.zdict \
  evidence/compression-level/reproduce-jmdict/independent-decoder.json

node evidence/compression-level-timing.mjs manabitan \
  evidence/compression-level/reproduce-jmdict/levels/census.json \
  evidence/compression-level/reproduce-jmdict/independent-decoder.json \
  evidence/compression-level/reproduce-jmdict/compression-timing.json

node evidence/compression-level-decode-timing.mjs manabitan \
  evidence/compression-level/reproduce-jmdict/levels/census.json \
  evidence/compression-level/reproduce-jmdict/independent-decoder.json \
  evidence/compression-level/reproduce-jmdict/decode-timing.json
```

Use `jitendex` and distinct corresponding paths for the second corpus. Before running another timed cohort, coordinate exclusive local timing ownership. The documented commands reproduce the fixed completed study; they are not a recommendation for optional retiming.
