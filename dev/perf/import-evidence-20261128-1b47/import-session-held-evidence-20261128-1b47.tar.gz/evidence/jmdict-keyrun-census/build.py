import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / 'jmdict-glossary-census'
REPO = ROOT.parent.parent / 'manabitan'
CLANG = Path('/tmp/manabitan-native-9bb32/native-toolchain/bin/clang')
LINKER = CLANG.with_name('wasm-ld')
old = json.loads((PREVIOUS / 'build-manifest.json').read_text())
source = (PREVIOUS / 'instrumented.c').read_text()
assert hashlib.sha256(source.encode()).hexdigest() == old['sourceSha256']
labels = old['counterLabels'] + [
    *[f'keyRun{n}Rows' for n in range(5)],
    *[f'adjacentKeyProofMask{n}Rows' for n in range(4)],
    *[f'simulatedLookback{n}Rows' for n in range(5)],
    'simulatedReuseCandidates', 'simulatedReuseCandidateBytes', 'simulatedReuseBoundsRejected',
    'simulatedReuseTailRejected', 'simulatedReuseMiddleRejected', 'simulatedReuseFullCompared',
    'simulatedReuseFullBytes', 'simulatedReuseFullRejected', 'simulatedReuseMatches',
    'simulatedNewWitnessRows', 'simulatedNewWitnessBytes', 'simulatedNewWitnessCompositeTokens',
    'simulatedNewWitnessCompositeBytes', 'simulatedLostBaselineWitnessRows',
    'simulatedNewWitnessWithKeyRunRows', 'simulatedNewWitnessWithoutKeyRunRows',
    'simulatedKeyRunBudgetExhaustedRows',
]
for distance in range(1, 5):
    labels += [f'simulatedNewWitnessDistance{distance}Rows', f'simulatedNewWitnessDistance{distance}Bytes']
indexes = {label: index for index, label in enumerate(labels)}


def once(text, previous, replacement):
    assert text.count(previous) == 1, (text.count(previous), previous)
    return text.replace(previous, replacement, 1)


def counter(label):
    return f'parser_probe_counters[{indexes[label]}]'


source = once(source, f'parser_probe_counters[{len(old["counterLabels"])}]', f'parser_probe_counters[{len(labels)}]')
source = once(source, f'probe < {len(old["counterLabels"])}u', f'probe < {len(labels)}u')
helper = '''
// Census-only mirror of exact glossary comparison. A hypothetical witness is
// never passed into the real parser or published as a source CRC witness.
static uint32_t parser_probe_keyrun_glossary(
    const uint8_t* src, uint32_t end, uint32_t start,
    const TermRowMeta* rows, uint32_t row_count, uint32_t lookback
) {
    const uint32_t first = row_count > lookback ? row_count - lookback : 0u;
    for (uint32_t k = row_count; k > first;) {
        const TermRowMeta* prior = &rows[--k];
        const uint32_t n = prior->glossary_length;
        const uint32_t p = prior->glossary_start;
        ++CANDIDATES;
        CANDIDATE_BYTES += n;
        if (start >= end || n == 0u || n > end - start || src[start] != src[p]) { ++BOUNDS_REJECTED; continue; }
        const uint32_t sample = n < 8u ? n : 8u;
        if (!content_bytes_equal_between(src, start + n - sample, src, p + n - sample, sample)) { ++TAIL_REJECTED; continue; }
        if (!content_bytes_equal_between(src, start + (n - sample) / 2u, src, p + (n - sample) / 2u, sample)) { ++MIDDLE_REJECTED; continue; }
        ++FULL_COMPARED;
        FULL_BYTES += n;
        if (!content_bytes_equal_between(src, start, src, p, n)) { ++FULL_REJECTED; continue; }
        ++MATCHES;
        return k;
    }
    return 0xffffffffu;
}
'''
for name, label in {
    'CANDIDATES': 'simulatedReuseCandidates', 'CANDIDATE_BYTES': 'simulatedReuseCandidateBytes',
    'BOUNDS_REJECTED': 'simulatedReuseBoundsRejected', 'TAIL_REJECTED': 'simulatedReuseTailRejected',
    'MIDDLE_REJECTED': 'simulatedReuseMiddleRejected', 'FULL_COMPARED': 'simulatedReuseFullCompared',
    'FULL_BYTES': 'simulatedReuseFullBytes', 'FULL_REJECTED': 'simulatedReuseFullRejected',
    'MATCHES': 'simulatedReuseMatches',
}.items():
    helper = helper.replace(name, counter(label))
source = once(source, '\nstatic inline int next_format3_field', helper + '\nstatic inline int next_format3_field')
start = source.index('int32_t parse_and_encode_term_bank_token_binary_dedup(')
end = source.index('\n/* Segment compaction consumes', start)
fused = source[start:end]
fused = once(fused, '    uint32_t recent_content_match_streak = 0u;',
    '    uint32_t recent_content_match_streak = 0u;\n'
    '    uint32_t probe_expression_run = 0u;\n'
    '    uint32_t probe_reading_run = 0u;\n'
    '    uint32_t probe_key_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;\n'
    '    uint32_t probe_reuse_budget = 0u;\n'
    '    uint32_t probe_content_streak = 0u;')
fused = once(fused, '        for (uint32_t field = 0u; field < 2u; ++field) {',
    '        uint32_t probe_adjacent_key_mask = 0u;\n'
    '        for (uint32_t field = 0u; field < 2u; ++field) {')
fused = once(fused, '                    ++parser_probe_counters[3];',
    '                    probe_adjacent_key_mask |= 1u << field;\n'
    '                    ++parser_probe_counters[3];')
insert = '''
        // These are only proofs already produced by existing adjacent-key
        // comparisons. Reading-equals-expression propagates an expression
        // proof when both effective readings equal their expressions.
        const uint32_t probe_expression_equal = probe_adjacent_key_mask & 1u;
        const uint32_t probe_reading_equal = (probe_adjacent_key_mask & 2u) ||
            (reading_equals_expression && row_count > 0u && reading_equals[row_count - 1u] && probe_expression_equal);
        probe_expression_run = probe_expression_equal ?
            (probe_expression_run < RECENT_CONTENT_DEDUP_WINDOW ? probe_expression_run + 1u : RECENT_CONTENT_DEDUP_WINDOW) : 0u;
        probe_reading_run = probe_reading_equal ?
            (probe_reading_run < RECENT_CONTENT_DEDUP_WINDOW ? probe_reading_run + 1u : RECENT_CONTENT_DEDUP_WINDOW) : 0u;
        const uint32_t probe_key_run = probe_expression_run > probe_reading_run ? probe_expression_run : probe_reading_run;
        if (probe_key_run == 0u) { probe_key_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET; }
        ++parser_probe_counters[KEY_RUN_BASE + probe_key_run];
        ++parser_probe_counters[KEY_MASK_BASE + probe_adjacent_key_mask];
        uint32_t probe_lookback = 0u;
        if (validated_glossary_reuse_enabled && row_count > 0u) {
            if (probe_reuse_budget > 0u) { probe_lookback = RECENT_CONTENT_DEDUP_WINDOW; }
            else if (rows[row_count - 1u].glossary_length >= VALIDATED_GLOSSARY_REUSE_MIN_PREVIOUS_BYTES) { probe_lookback = 1u; }
            if (probe_key_budget > 0u && probe_key_run > probe_lookback) { probe_lookback = probe_key_run; }
            else if (probe_key_budget == 0u && probe_key_run > probe_lookback) { ++KEY_BUDGET_EXHAUSTED; }
        }
        ++parser_probe_counters[LOOKBACK_BASE + probe_lookback];
        const uint32_t probe_witness = parser_probe_keyrun_glossary(
            src, source.end, parsed_row->glossary_start, rows, row_count, probe_lookback);
        if (probe_witness != 0xffffffffu) {
            probe_reuse_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;
            probe_key_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;
        } else {
            if (probe_reuse_budget > 0u) { --probe_reuse_budget; }
            if (probe_key_run > 0u && probe_key_budget > 0u) { --probe_key_budget; }
        }
        if (probe_witness != 0xffffffffu && glossary_witness == 0xffffffffu) {
            ++NEW_ROWS;
            NEW_BYTES += parsed_row->glossary_length;
            NEW_TOKENS += probe_scanned_tokens;
            NEW_COMPOSITE_BYTES += probe_scanned_bytes;
            const uint32_t distance = row_count - probe_witness;
            ++parser_probe_counters[NEW_DISTANCE_ROWS_BASE + (distance - 1u) * 2u];
            parser_probe_counters[NEW_DISTANCE_BYTES_BASE + (distance - 1u) * 2u] += parsed_row->glossary_length;
            if (probe_key_run) { ++NEW_WITH_KEY_RUN; } else { ++NEW_WITHOUT_KEY_RUN; }
        } else if (probe_witness == 0xffffffffu && glossary_witness != 0xffffffffu) { ++LOST_ROWS; }
'''
for name, value in {
    'KEY_RUN_BASE': str(indexes['keyRun0Rows']) + 'u',
    'KEY_MASK_BASE': str(indexes['adjacentKeyProofMask0Rows']) + 'u',
    'LOOKBACK_BASE': str(indexes['simulatedLookback0Rows']) + 'u',
    'NEW_DISTANCE_ROWS_BASE': str(indexes['simulatedNewWitnessDistance1Rows']) + 'u',
    'NEW_DISTANCE_BYTES_BASE': str(indexes['simulatedNewWitnessDistance1Bytes']) + 'u',
    'NEW_ROWS': counter('simulatedNewWitnessRows'),
    'NEW_BYTES': counter('simulatedNewWitnessBytes'),
    'NEW_TOKENS': counter('simulatedNewWitnessCompositeTokens'),
    'NEW_COMPOSITE_BYTES': counter('simulatedNewWitnessCompositeBytes'),
    'NEW_WITH_KEY_RUN': counter('simulatedNewWitnessWithKeyRunRows'),
    'NEW_WITHOUT_KEY_RUN': counter('simulatedNewWitnessWithoutKeyRunRows'),
    'LOST_ROWS': counter('simulatedLostBaselineWitnessRows'),
    'KEY_BUDGET_EXHAUSTED': counter('simulatedKeyRunBudgetExhaustedRows'),
}.items():
    insert = insert.replace(name, value)
fused = once(fused, '        reading_equals[row_count] = reading_equals_expression ? 1u : 0u;',
    '        reading_equals[row_count] = reading_equals_expression ? 1u : 0u;\n' + insert)
fused = once(fused, '        if (parser_probe_short_match) {\n            const int same_adjacent_content',
    '        if (recent_match != 0xffffffffu) {\n'
    '            if (probe_content_streak >= VALIDATED_GLOSSARY_REUSE_ADMISSION_MATCHES ||\n'
    '                ++probe_content_streak >= VALIDATED_GLOSSARY_REUSE_ADMISSION_MATCHES) {\n'
    '                probe_reuse_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;\n'
    '            }\n'
    '        } else { probe_content_streak = 0u; }\n'
    '        if (parser_probe_short_match) {\n            const int same_adjacent_content')
source = source[:start] + fused + source[end:]
source_path = ROOT / 'instrumented.c'
wasm_path = ROOT / 'instrumented.wasm'
source_path.write_text(source)
manifest = json.loads((REPO / 'dev/data/dictionary-wasm/manifest.json').read_text())
target = next(item for item in manifest['targets'] if item['name'] == 'term-bank-parser.wasm')
command = [str(CLANG), f'-fuse-ld={LINKER}', *target['arguments'], '-o', str(wasm_path), str(source_path),
           str(REPO / 'ext/js/dictionary/wasm/term-bank-inflate.c')]
subprocess.run(command, check=True)
report = {
    'scope': 'Instrumented exact-baseline key-run admission simulation. Hypothetical budget and witnesses never alter real parser output. Key proofs come only from actual existing interner comparisons or equality transitivity. No timing claim.',
    'baseline': old['baseline'], 'previousManifest': str(PREVIOUS / 'build-manifest.json'),
    'sourcePath': str(source_path), 'sourceSha256': hashlib.sha256(source.encode()).hexdigest(),
    'wasmPath': str(wasm_path), 'wasmSha256': hashlib.sha256(wasm_path.read_bytes()).hexdigest(),
    'wasmBytes': wasm_path.stat().st_size, 'counterExport': 'parser_probe_snapshot',
    'counterWordCount': len(labels), 'counterLabels': labels,
    'compiler': subprocess.check_output([str(CLANG), '--version'], text=True).strip(), 'command': command,
}
(ROOT / 'build-manifest.json').write_text(json.dumps(report, indent=2) + '\n')
runner = (PREVIOUS / 'run-census.mjs').read_text()
runner = runner.replace(f'assert.equal(manifest.counterWordCount, {old["counterWordCount"]});', f'assert.equal(manifest.counterWordCount, {len(labels)});')
runner = runner.replace(f'assert.equal(manifest.counterLabels.length, {old["counterWordCount"]});', f'assert.equal(manifest.counterLabels.length, {len(labels)});')
(ROOT / 'run-census.mjs').write_text(runner)
print(json.dumps({key: report[key] for key in ('sourceSha256', 'wasmSha256', 'wasmBytes', 'counterWordCount')}))
