#!/usr/bin/env python3
"""Fresh-process Node component comparisons; never a browser import benchmark."""
import hashlib
import json
import math
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys
import time

root = Path(__file__).resolve().parent.parent
out = root / 'evidence' / 'node-jmdict-cache-pairs'
out.mkdir(exist_ok=False)
arms = {'A': root / 'manabitan', 'B': root / 'cache-experiment'}
driver = root / 'evidence' / 'node-sink-replay.mjs'
fixtures = Path('/tmp/manabitan-1b47-fixtures')
reference = json.loads((root / 'evidence' / 'node-sink-jmdict-baseline-verify2.json').read_text())
runtime_files = [
    'ext/js/dictionary/dictionary-database.js',
    'ext/js/dictionary/dictionary-importer.js',
    'ext/js/dictionary/term-bank-wasm-parser.js',
    'ext/js/dictionary/term-record-opfs-store.js',
    'ext/js/dictionary/term-content-block-store.js',
    'ext/js/dictionary/zstd-term-content.js',
    'ext/lib/term-bank-parser.wasm',
    'ext/lib/term-content-canonical-scan-v1.wasm',
    'ext/lib/zstd.wasm',
]
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
fingerprints = {arm: {name: sha(path / name) for name in runtime_files} for arm, path in arms.items()}
start = time.time()
observations = []
def run(arm, name, warmup=False):
    for key, path in arms.items():
        assert fingerprints[key] == {n: sha(path / n) for n in runtime_files}, 'Source changed during comparison'
    path = out / (name + '.json')
    with (out / (name + '.log')).open('w') as log:
        command = ['node', str(driver), str(arms[arm]), str(fixtures), str(path), 'jmdict', '0', '0']
        subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, check=True)
    report = json.loads(path.read_text())
    assert report['complete'] and report['rows'] == 528299
    assert report['files'] == reference['files'], 'Persisted bytes differ from verified full baseline'
    assert report['sinkApi'] == 'bulkAddArtifactTermsChunk'
    assert not report['sourceHashingInsideTimer']
    observation = {'name': name, 'arm': arm, 'warmup': warmup, **report['timings']}
    observations.append(observation)
    print(json.dumps(observation), flush=True)

run('A', 'warmup-A', True)
run('B', 'warmup-B', True)
for pair in range(8):
    order = ['A', 'B'] if pair % 2 == 0 else ['B', 'A']
    for arm in order:
        run(arm, f'pair-{pair + 1:02d}-{arm}')

samples = [item for item in observations if not item['warmup']]
pairs = []
for i in range(0, len(samples), 2):
    pair = {item['arm']: item for item in samples[i:i+2]}
    pairs.append({'pair': i // 2 + 1, 'order': ''.join(item['arm'] for item in samples[i:i+2]),
                  'baselineMs': pair['A']['elapsedMs'], 'candidateMs': pair['B']['elapsedMs'],
                  'candidateChangePct': 100 * (pair['B']['elapsedMs'] / pair['A']['elapsedMs'] - 1),
                  'cpuChangePct': 100 * (pair['B']['cpuTotalMs'] / pair['A']['cpuTotalMs'] - 1)})
log_ratios = [math.log1p(pair['candidateChangePct'] / 100) for pair in pairs]
rng = random.Random(1)
resampled = sorted(100 * math.expm1(statistics.mean(rng.choices(log_ratios, k=len(log_ratios)))) for _ in range(10000))
summary = {
    'scope': 'Node24 component, actual source/parser/dedup/Zstd/record algorithms, public sink; asynchronous Node filesystem boundary. Two warmups, eight alternating AB/BA pairs of fresh processes; every persisted output matches full baseline. Excludes SQLite publication, media, browser OPFS and browser restart. Not a browser import speed result.',
    'node': subprocess.check_output(['node', '--version'], text=True).strip(),
    'driverSha256': sha(driver), 'fingerprints': fingerprints,
    'comparisonWallSeconds': time.time() - start,
    'baselineMedianMs': statistics.median(x['elapsedMs'] for x in samples if x['arm'] == 'A'),
    'candidateMedianMs': statistics.median(x['elapsedMs'] for x in samples if x['arm'] == 'B'),
    'pairedGeometricMeanCandidateChangePct': 100 * math.expm1(statistics.mean(log_ratios)),
    'descriptivePairBootstrap95Pct': [resampled[250], resampled[9749]],
    'baselineMedianCpuMs': statistics.median(x['cpuTotalMs'] for x in samples if x['arm'] == 'A'),
    'candidateMedianCpuMs': statistics.median(x['cpuTotalMs'] for x in samples if x['arm'] == 'B'),
    'baselineMedianPeakRssKiB': statistics.median(x['peakRssKiB'] for x in samples if x['arm'] == 'A'),
    'candidateMedianPeakRssKiB': statistics.median(x['peakRssKiB'] for x in samples if x['arm'] == 'B'),
    'pairs': pairs, 'observations': observations,
}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print('SUMMARY ' + json.dumps(summary), flush=True)
