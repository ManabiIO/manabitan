// Deterministic component controls. These are not import-speed evidence.
// Generate once and reuse identical source bytes for both production modules.
const encoder = new TextEncoder();

function meaning(index) {
    // The changing six ASCII bytes are outside the glossary's tail and middle
    // samples, so matching samples still require complete byte equality.
    return [{type: 'structured-content', content: {tag: 'span',
        content: 'x'.repeat(24) + String(index).padStart(6, '0') + 'x'.repeat(160)}}];
}

function makeRows(count, keys) {
    return Array.from({length: count}, (_, index) => {
        const [expression, reading] = keys(index);
        return [expression, reading, 'noun', '', index % 17, meaning(index), index + 1, ''];
    });
}

function control(name, rows, expectedCandidateWitnesses = 0) {
    const middle = Math.floor(rows.length / 2);
    return {name, rowCount: rows.length, expectedBaselineWitnesses: 0, expectedCandidateWitnesses,
        banks: [rows.slice(0, middle), rows.slice(middle)].map((bank) => encoder.encode(JSON.stringify(bank)))};
}

export function makeKeyRunControls() {
    const count = 16384;
    const id = (index) => String(index).padStart(6, '0');
    const cases = [
        control('unique_short_keys_common_prefix_glossaries', makeRows(count, (index) => [`key-${id(index)}`, ''])),
        control('same_key_unique_unsampled_near_misses', makeRows(count, () => ['same-key', 'same-reading'])),
        control('paired_keys_unique_unsampled_near_misses', makeRows(count, (index) => [`key-${id(Math.floor(index / 2))}`, `reading-${id(Math.floor(index / 2))}`])),
        control('unique_long_common_prefix_keys', makeRows(4096, (index) => ['key-'.repeat(256) + id(index), ''])),
    ];
    const alternating = Array.from({length: count}, (_, index) => {
        const group = Math.floor(index / 4);
        const kind = index % 2;
        const expression = `form-${id(group)}-${Math.floor(index % 4 / 2)}`;
        const reading = `reading-${id(group)}`;
        const glossary = kind === 0 ? meaning(group) : [`form-one-${id(group)}`, `form-two-${id(group)}`];
        return [expression, reading, kind === 0 ? 'noun' : 'forms', '', index % 17, glossary, group + 1, ''];
    });
    cases.push(control('alternating_short_definition_and_forms', alternating, count / 2));
    return cases;
}
