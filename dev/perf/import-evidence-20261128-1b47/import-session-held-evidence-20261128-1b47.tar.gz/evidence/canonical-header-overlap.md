# Canonical header counters: existing experiment, no new prototype

The proposed localization of ordinary native scan header fields is already
implemented in open draft [#864](https://github.com/ManabiIO/manabitan/pull/864),
head `d147a60fc4845e898d98d8924968d6094b417007`, based on
`d24b4e56ceb1fe14ad96ef3853f4d397efa6fa26`.

It keeps journal progress volatile and retains the compiler barrier before
authoritative mutation. Cursor, pending, exact, resolved and dense counts become
locals and are published on every normal/negative return, exact-batch boundary
and intentional trap. The ABI and journal width stay unchanged. Its native
module grows from1,624 to1,760 bytes. The retained12-round local component study
is inconclusive against unchanged-product drift; no whole-import gain is claimed.

This is an exact source-level overlap, not merely a similar title. The canonical
C source at #864's baseline and frozen current develop9e10 has the same Git blob
`2035b8e2859bb4dc6a770812361040ff5b8c370f`. Both manifests also bind identical
canonical WASM SHA-256
`40948d5c20d26253e86c93d267e3cbb3817ea87c9731e02bcca0523c0eb3d6af`
and the same compiler/linker arguments. The surrounding application evolved,
but the canonical kernel itself offers no changed-context reason to repeat this
implementation as a new proposal.

Nearby work is distinct but also prevents broad rediscovery:

- [#880](https://github.com/ManabiIO/manabitan/pull/880), head
  `2dfa72962c9d9f1976011e41b9bbce2375f4dbb5`, snapshots immutable configuration and
  row words while retaining volatile header writes. Its complete browser screen
  was held: all candidate intervals cross zero; every raw observation and
  identical-product drift are retained. No further unchanged-candidate
  qualification was planned.
- [#856](https://github.com/ManabiIO/manabitan/pull/856), head
  `8282d596809d76ca2960f926719d94877925489e`, compresses each insertion journal
  from three words to one and advances the private ABI. It proves fewer writes
  and complete output/rollback parity, without establishing whole-import
  latency or memory gains.

Root and the implementation reviewer were notified before any new prototype.
No canonical source, artifact, branch or measurement was changed in this audit.
