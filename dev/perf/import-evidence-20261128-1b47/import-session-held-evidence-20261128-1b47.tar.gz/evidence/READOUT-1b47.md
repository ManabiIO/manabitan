# Import optimization evidence readout

Updated 2026-11-28, 06:32 UTC. This is an evidence index for the ongoing work;
pending studies have not been converted into performance claims. Root published draft PRs [#978](https://github.com/ManabiIO/manabitan/pull/978) (indexed score validation) and [#979](https://github.com/ManabiIO/manabitan/pull/979) (CRC 8+4 tails), each with narrow component claims and immutable evidence.

## Source and measurement boundaries

Every candidate starts from ManabiIO/manabitan baseline
`9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`, tree
`d99ea4d04658f7ec1c76acdc5f3684594212a471`. Full source, native module, fixture
and runtime identities are in `input-identities-1b47.json`. The machine-readable
candidate index is `evidence-inventory-1b47.json`; it includes exact source
identities, complete and failed cohort paths, and existence checks.

Pinned full-browser baseline run 46100401987 covers all three corpora with
restart, lookup, media and persisted-storage checks. Its three individual import
times (JMdict 738.9 ms, Jitendex 1,926.3 ms, VNDB 6,602.2 ms) are orientation,
not comparative estimates. Ordinary receipts and separate traces are in
`current-baseline-{jmdict,jitendex,vndb}`. Overlapping trace phases cannot be added.
The parser source-read wall metric includes worker startup; JMdict's 53.7 ms is
not an isolated Blob I/O measurement.

Local public-sink replay includes the actual compressed source pipeline, parser,
dedup, compression workers, complete record encoder and stored bytes. Its async
filesystem boundary excludes browser synchronous handles, SQLite, publication,
UI, media and restart. Parser-only and codec-only diagnostics have narrower
boundaries. None is a substitute for a browser whole-import measurement.

## Candidates with useful component evidence

| Candidate | Concrete evidence | Current limit / disposition |
| --- | --- | --- |
| Restore indexed compact-score validation | Exact 12 real compact field buffers; 24 balanced A/B/C blocks. Approximately 1.57–1.60 ms saved per warm validation of 528,299 rows. Same-code median control +0.88457%. | Draft PR #978. Full local and exact-head hosted validation pass. Browser timing still pending. The much larger whole-Node apparent gain is not attributed to these two lines. |
| CRC gap tails, eight then four bytes | Two complete, opposite-order VNDB parser cohorts cover all 665 banks and 6,648,310 rows with exact output/source checks. Combined CRC phase improvement about 7.73%. | Draft PR #979. Narrow CRC mechanism supported; unrelated phase drift prevents a whole-parser/import claim. Current-head full validation passes; browser screens are queued. Slicing32/padding alternatives were not promoted. |
| Zstd level −2 for JMdict/Jitendex content | Every captured production frame decodes exactly, including independent libzstd verification. Jitendex retained-context compression improves about 8% / 43–47 ms; JMdict improvement is small. | Explicit storage tradeoff: exact complete-import deltas +312,404 B JMdict, +750,018 B Jitendex, zero VNDB; 2% total ceiling. Decoder timing is noisy. Fresh-context already reuses CCtx across every frame; retained adds two full-corpus warmups. First-import value remains uncertain, so hold a product PR for the frozen browser study. |

Clean score product head is `b15bad43acdfd54d541895cac1109c0e5ba51b2f`; clean CRC product head is `5909db31ebe859fce1cc4b38324271ddf9f3dd59`. Their product files exactly match the validated experimental heads `915268441352c3c7aa50fc0fbd44f73f5a826d79` and `3080deb631a7536fabe8ccb2f77f8f55e11ef061`. Compression experimental head is `f7980e638ea1808701ac28339987663fd8b3dc4e`. Publication source/tree maps and PR metadata are in `product-publication-1b47.json`; no experimental head changed.

Detailed readouts:

- `score-restoration-pr-review.md`, `score-checkpoint-claim-audit.md`,
  `score-validation/full-validation/summary.json`.
- `crc-tail/{independent-review.md,pr-worthiness-update.md,full-vndb-crc-comparison.json}`.
- `compression-level/{README.md,summary.json,pr-worthiness-reassessment.md}` and `compression-level-study`. Production first-import contexts see only worker subsets; retaining a context does not make the twice-warmed corpus result uniquely representative.

## Experiments still awaiting a decisive result

| Candidate | Completed evidence | Pending work / interpretation |
| --- | --- | --- |
| Content-persistence overlap | Two separate eight-pair Node sink cohorts were slower/inconclusive. Jitendex browser completed all six pairs: all slower, median +2.282%, equal-work +3.693%, descriptive interval [+0.699%, +8.163%]; identical control median +3.576% with wide drift. All 26 browser runs pass semantic checks. | Separate memory baseline A1 failed the frozen coverage gate (350.393 ms gap >250 ms), so the job is unqualified. No gain or precise causal slowdown claim. JMdict queued; VNDB running. No retry or protocol change. |
| Local 8 MiB index checkpoints | Focused and full hosted validation pass. VNDB's six complete-import pairs pass all correctness/memory gates but have median −0.714%, 95% descriptive interval [−3.955%, +4.049%], versus control +1.102%. | No useful VNDB speed signal; the local-writer JMdict/Jitendex jobs are running. The remote worker's policy remains unchanged. No 20% improvement claim. |

## Rejected or held experiments

| Experiment | Why it did not advance | Retained evidence |
| --- | --- | --- |
| Exact-tag score cache v1/v2 | Positive actual warm encoder saving retained, but all four v2 common144 upper bounds fail the prospective <+5% rule (7.394%, 9.995%, 9.384%, 9.621%). All-in-range wall changes +5.240%/+5.686% have positive intervals against both baselines. | `score-cache` and `score-cache-repeat-v2`: all actual backing/output bytes, v1/v2 complete cohorts, unstarted superseded plan, full CPU/control attribution and disposition. Stop: no PR, first-use implementation/acquisition, Jitendex capture or optional full gates. |
| Source-cache statistics fusion | Lower isolated cache metric mostly moved work; inclusive metadata change was about 1.4 ms, whole component geometric change +11.86%. | `node-jmdict-cache-pairs`, exact source/storage verification, abandoned patch and proxy regression log. |
| CRC slicing32 and padded table stride | Packed-gap micro wins did not survive actual verifier/parser work. Second padded cohort remained inconclusive; stopped. | Full VNDB slicing32, five-arm actual verifier, opposite-order padding and combined analysis, all inputs' hashes and reconstruction recipe. |
| CRC braid lanes 4/6/8/12/16 | Four-lane apparent gain tracked identical-code eight-lane control; 12/16 slower. | `crc-braid-lanes`, all 53 JMdict bank oracles and 12 balanced blocks. |
| SIMD inflater match copies | JMdict showed no useful controlled gain. Jitendex phase signal lacked a completed full-parser qualification: both independently declared attempts were externally killed. | `inflate-match-copy`, both partial cohorts, failure notes, bank-count preparation erratum and corrected interpretation of RSS. No more acquisitions. |
| Broad key-run glossary reuse | 128,388 JMdict witnesses but no useful gain versus both controls; Jitendex no gain. | `jmdict-keyrun-candidate`, full six-block corpora, corrected controls and both earlier control-preparation failures. |
| Distance-two key-run | 96,940 expected witnesses reached, but JMdict point estimate mostly tracked control variation. Jitendex killed in warmup with no measured groups. | `jmdict-distance2-candidate`, complete JM/control data and preserved Jit failure. No retry. |
| Delayed key hint | JMdict reaches 116,812 predicted witnesses but no gain versus both controls. Favorable six-block Jitendex signal has no eliminated work; only caller code generation differs. | `jmdict-delayed-keyhint-candidate`, both complete 18-child studies, attribution and native function-body audit. No remeasure. |
| Immediate-comma guard | Both separate 24-block confirmations completed. JMdict inclusive median B/A +1.14%, B/C −0.33%; native +0.42%/−0.53%, with intervals crossing zero. Jitendex B/C geometric −3.73% tracks unchanged inflate −3.50%; B/A remains inconclusive. No control-qualified mechanism gain. | `immediate-comma/confirmation-v3-readout.{md,json}` and both `confirmation-*-v3` directories retain 72 children per corpus, every proof/observation, and frozen bootstrap analysis. Original six-block screens are retained separately. Stop: no promotion or further acquisition. |
| Zstd level −3 | Jitendex storage increase 4.637% exceeded the predeclared budget before timing. | Size/oracle census, rejected payload hash inventory and reconstruction scripts. |
| Wider SAB copies / single-block worker routing / wider inline score radius | Copy-width control did not improve; zero eligible single-block production groups; score-radius expansion has little additional reach. | Bounded probe and exact production censuses. These are not import timing results. |
| Repeated canonical-header scan | Exact source overlap with an existing held proposal; no duplicate implementation. | `canonical-header-overlap.md`. |

## Score-cache result retained despite rejection

V2's actual 528,299-row, 12-call JMdict encoder scenario completed 24 balanced
blocks with exact full outputs, private factory proofs and backing layouts.
Median A/B/C wall times were 12.018/8.337/11.248 ms; geometric B/A was −27.664%
(95% descriptive interval [−34.124%, −20.139%]) and B/C −25.438%
([−34.564%, −14.531%]). CPU also improved against both baselines. Actual Map
reads fell from 269,193 to 7,676; v1 had 6,223. This warm component benefit is
preserved, with no first-import or full-browser claim.

Each common-score scenario completed its prospectively fixed 144 balanced blocks.
Uniform-zero geometric wall changes were +2.486% versus A (interval
[−2.400%, +7.394%]) and +4.960% versus C ([+0.224%, +9.995%]). All-in-range
changes were +5.240% ([+1.159%, +9.384%]) and +5.686%
([+1.905%, +9.621%]). All four upper bounds exceed the required +5% margin.
Same-code wall controls were −2.358% and −0.423%, both with intervals crossing
zero. All-in-range paired CPU medians were also positive (+4.563%/+3.479%),
while geometric CPU intervals remained broad. Synthetic controls retain the
actual JMdict reference layout and are not actual Jitendex/VNDB measurements.

The complete report is `score-cache-repeat-v2/actual-encoder-screen-v2-common144/README.md`;
`final-study-summary.json` and `disposition.json` retain the exact result and
stop rule. Source, protocol, actual inputs and all observations remain frozen.
The original 24/24/24 v2 plan was superseded before any observations. The
conditional `score-cache-repeat-v2/first-use-design.md` is unimplemented, with
zero observations, because its prerequisite failed. No larger or replacement
cohort is planned.

## Hosted studies and failures

Current status is recorded in `hosted-import-screens-status-20261128063235.json`.
All five frozen experimental heads have green full validation. Checkpoint VNDB
completed all correctness, media/restart and memory gates, with no useful speed
signal. Pipeline Jitendex completed all timing but failed separate memory coverage;
its raw observations remain usable only with that qualification failure explicit.
Pipeline VNDB and checkpoint JMdict/Jitendex are in progress; all remaining browser jobs are queued. Complete logs,
emitted raw observations/analysis, source identities and memory audits are in
`hosted-checkpoint-vndb-46104738613` and `hosted-pipeline-jitendex-46105215670`.
No failed study is retried or replaced.

| Study | Actions run |
| --- | --- |
| Pipeline | 46105215670 |
| Checkpoint | 46104738613 |
| Score restoration | 46106456744 |
| CRC 8+4 | 46107723369 |
| Compression −2 | 46108665276 |

Earlier pipeline validation failed only newly added test annotations; earlier
CRC validation failed only test formatting. Both failures remain preserved and
acquired no browser observations. Full source/WASM bytes were unchanged by their
test-only repairs. The compression local real-worker Vitest failure was observed
as external SIGKILL; the exact standalone worker sequence passes. Its full
hosted full unit gate now also passes. Score full validation retains initial
missing-fixture/toolchain prerequisite failures as well as the corrected passing
run; no product source changed between those attempts.

The queue audit in `hosted-queue-audit-20261128` shows both ubuntu-latest browser
jobs and ubuntu-26.04 validation jobs progressing with substantial waits. There
is no established alternate Linux capacity advantage and no ETA assertion.

## Durable evidence packaging

Root published compact score-restoration and CRC bundles at immutable evidence commit `3c3ba7600a8811df6b8631b72a0ac5379f8b60d1` on `perf/import-evidence-20261128-1b47`. The nine-file tree and both archives were verified; exact paths/digests are in `product-publication-1b47.json`. Prior_work_audit is preparing separate cache and final-session evidence bundles. They retain protocols, scripts, source patches/identities, complete raw observations and preserved failures, input/fixture manifests, correctness oracles and validation receipts. Small numeric score buffers are useful to make
the direct component reproducible. Full dictionary archives, media, large
temporary source captures and repeated extension packages need not be duplicated
inside these compact bundles; their exact hashes and reconstruction path remain.

For compression, preserve all raw timings, exact-frame size/oracle/decode census,
both source-bound full-sink captures, the new policy/helper/tests and all hosted
raw receipts/comparison-copy audits when available. Regenerable frame payloads
were moved with verified hashes to task-owned temporary storage; the complete
976-entry receipt is `compression-level-payload-relocation.json`. No observations,
manifests or failure logs were removed. The same rule applies to rejected
experiments: retain the decisive negative controls and failures rather than
publishing only a favorable subset.

The bounded read-only assessment of pending local-path mechanisms is `pending-study-review-20261128.md`; it proposes no new acquisitions or altered gates.
