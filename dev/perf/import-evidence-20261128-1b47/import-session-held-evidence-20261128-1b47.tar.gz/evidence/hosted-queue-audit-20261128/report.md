# Hosted runner queue audit — 2026-11-28

## Finding

The existing Ubuntu browser studies are waiting in a busy queue, while both `ubuntu-latest` browser jobs and `ubuntu-26.04` validation jobs continue to start and finish. There is no evidence here that our browser label is unavailable, or that changing a Linux label would improve capacity.

The run collection query reported 234 queued repository workflows. This is a point-in-time API count, not a concurrency limit or an ETA. The raw run/job records are preserved in `snapshot.json`.

## Observed recent browser work

| Run / job | Label | Created UTC | Runner started UTC | Finished UTC | Observation |
| --- | --- | --- | --- | --- | --- |
| 46104891607 / 140855308122 | ubuntu-latest | 03:52:19 | 04:39:09 | 04:48:42 | Jitendex browser study succeeded |
| 46104891607 / 140855308284 | ubuntu-latest | 03:52:19 | 04:45:01 | 04:54:03 | Second Jitendex host succeeded |
| 46104891607 / 140855308334 | ubuntu-latest | 03:52:19 | 04:51:14 | 04:58:28 | JMdict browser study succeeded |
| 46106789570 / 140861233444 | ubuntu-latest | 04:16:50 | 05:14:29 | 05:15:43 | Four complete JMdict imports and storage byte audit succeeded |
| 46104836788 / 140855140861 | ubuntu-latest | 03:51:36 | 05:15:32 | 05:20:16 | Jitendex import study succeeded |
| 46104891607 / 140855308397 | ubuntu-latest | 03:52:19 | 05:20:28 | In progress at snapshot | VNDB acquisition step active |
| 46104891607 / 140855308411 | ubuntu-latest | 03:52:19 | 05:21:51 | In progress at snapshot | JMdict acquisition step active |

Observed waits for these jobs ranged from about 47 to 90 minutes. Jobs are not starting in a simple run-creation FIFO sequence, so these observations do not yield a dependable completion prediction.

The newest sampled `ubuntu-26.04` validation jobs started at 05:21:19 and 05:22:32 after approximately 70 and 67 minutes respectively. Another validation started at 05:13:54 after 59 minutes. An `ubuntu-latest` actionlint job started at 05:21:59 and completed at 05:22:11.

## Our actual browser queue entry times

Checkpoint validation succeeded at 04:27:50; its three browser jobs entered the queue at 04:27:51. Pipeline validation succeeded at 04:41:58; its three browser jobs entered at 04:41:58. At the 05:25:30 snapshot, these browser waits were approximately 58 and 44 minutes. Earlier validation and test-repair time contributes to the longer overall workflow elapsed time.

Queued job records contain a `started_at` value equal to creation time but have no assigned runner. That placeholder is not evidence that browser execution has begun.

## Alternate runner evidence

GitHub documents `ubuntu-latest`, `ubuntu-24.04`, `ubuntu-22.04`, and `ubuntu-26.04` as standard x64 Linux labels. The documentation also lists `macos-15-intel` and `macos-26-intel` as Intel macOS labels. It does not promise a shorter queue for a particular label.

Two older Intel macOS validation jobs did receive runners quickly:

- Run 46107296378 / job 140862787329: created 04:23:16, started 04:24:10 (0.9 minutes), failed at 04:26:24.
- Run 46107794765 / job 140864351728: created 04:29:45, started 04:32:02 (2.3 minutes), failed at 04:35:05.

Both failures occurred at `npm run test:ts:test`, before any browser measurements. Their downstream browser jobs were cancelled. These observations establish that the Intel label was usable at those times; they do not establish current capacity or compatibility of our complete qualification protocol.

A newer `macos-15` ARM job (run 46110764990 / job 140873557403), created at 05:08:57, still had no assigned runner at 05:26:12. Platform-specific memory/receipt compatibility requires a separate source audit before any alternative cohort could be considered.

No workflow was altered, published, retried, or cancelled during this audit. Current frozen studies should remain intact. There is no evidence-supported reason for a speculative Linux label swap.

## Sources

- [Raw job metadata, in-flight import study](https://api.github.com/repos/ManabiIO/manabitan/actions/runs/46104891607/jobs?per_page=100)
- [Raw job metadata, prepared score import study](https://api.github.com/repos/ManabiIO/manabitan/actions/runs/46104836788/jobs?per_page=100)
- [Raw job metadata, complete JMdict storage audit](https://api.github.com/repos/ManabiIO/manabitan/actions/runs/46106789570/jobs?per_page=100)
- [Raw job metadata, source validation](https://api.github.com/repos/ManabiIO/manabitan/actions/runs/46106649952/jobs?per_page=100)
- [GitHub: Choosing the runner for a job](https://docs.github.com/en/actions/how-tos/write-workflows/choose-where-workflows-run/choose-the-runner-for-a-job)
- [GitHub: Hosted runner reference](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)
