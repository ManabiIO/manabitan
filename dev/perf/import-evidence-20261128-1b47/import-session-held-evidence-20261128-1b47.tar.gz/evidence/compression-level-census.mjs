/* SPDX-License-Identifier: GPL-3.0-or-later */
// Untimed, complete real-frame size/correctness screen. No product mutation.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import {dirname, join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {installFileFetch} from './node-sink-file-fetch.mjs';

const [sourcePath, captureManifestPath, outputDirectory] = process.argv.slice(2);
assert(sourcePath && captureManifestPath && outputDirectory,
    'Usage: node compression-level-census.mjs SOURCE CAPTURE_MANIFEST OUTPUT_DIRECTORY');
const root = resolve(sourcePath);
const output = resolve(outputDirectory);
const manifestPath = resolve(captureManifestPath);
const manifest = JSON.parse(await readFile(manifestPath, 'utf8'));
const sha = (value) => createHash('sha256').update(value).digest('hex');
const expected = {
    jmdict: {groups: 12, frames: 103, rows: 528299, rawBytes: 100300626, primaryBytes: 12326040, persistedBytes: 43315677,
        source: 'e61445478202dbbda9c22d91a5bc51e87b6b77ce0096898a37aad149cefa0400',
        files: 'b9200f034c262f240ab55c1598c3c8a9703122c4495c1379deac06d6c80ac5f8',
        fixture: '3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f'},
    jitendex: {groups: 22, frames: 385, rows: 436555, rawBytes: 389687485, primaryBytes: 31121935, persistedBytes: 61977692,
        source: '3bb9249c04772a0a2f9137f716148cc8e86e49d938d3119339d835eb40bf4585',
        files: '9deee3c73d0a822778e356d897932e0992578a7a798d063f44cf9e7452736aa7',
        fixture: 'e914c76596220dffc6ee0c069cd05992f03adb2988c12c3cebe817a3ac271356'},
};
const oracle = expected[manifest.dictionary];
assert(oracle);
assert.equal(manifest.complete, true);
assert.equal(manifest.sourceCommit, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
assert.equal(manifest.sourceDigestSha256, oracle.source);
assert.equal(manifest.filesDigestSha256, oracle.files);
assert.equal(manifest.fixture.sha256, oracle.fixture);
assert.equal(manifest.groups, oracle.groups);
assert.equal(manifest.frameCount, oracle.frames);
assert.equal(manifest.rows, oracle.rows);
assert.equal(manifest.rawBytes, oracle.rawBytes);
assert.equal(manifest.primaryBytes, oracle.primaryBytes);
assert.equal(manifest.totalPersistedBytes, oracle.persistedBytes);
assert.equal(manifest.blockTargetBytes, 1024 * 1024);
for (const [file, expectedHash] of Object.entries(manifest.codecSourceFiles)) {
    assert.equal(sha(await readFile(join(root, file))), expectedHash, file);
}
await mkdir(dirname(output), {recursive: true});
await mkdir(output);
for (const level of [-2, -3]) { await mkdir(join(output, `minus${-level}`)); }
installFileFetch();
const codec = await import(pathToFileURL(join(root, 'ext/lib/zstd-wasm.js')));
const {hashTermEntryContentBytesPair} = await import(pathToFileURL(join(root, 'ext/js/dictionary/term-entry-content-hash.js')));
await codec.init(pathToFileURL(join(root, 'ext/lib/zstd.wasm')).href);
const dictionary = new Uint8Array(await readFile(join(root, 'ext/lib/zstd-dicts/jmdict.zdict')));
const arms = [
    {name: 'A', level: -1, context: codec.createCCtx()},
    {name: 'B', level: -2, context: codec.createCCtx()},
    {name: 'C', level: -3, context: codec.createCCtx()},
    {name: 'D', level: -1, context: codec.createCCtx()},
];
const decoder = codec.createDCtx();
const verifyEnvelope = (bytes) => {
    assert(bytes.byteLength > 12);
    assert.deepEqual(Array.from(bytes.subarray(0, 4)), [0x4d, 0x42, 0x43, 0x32]);
    const [hash1, hash2] = hashTermEntryContentBytesPair(bytes.subarray(12));
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    assert.equal(view.getUint32(4, true), hash1);
    assert.equal(view.getUint32(8, true), hash2);
};
const rawDigest = createHash('sha256');
const frameResults = [];
const totals = Object.fromEntries(arms.map(({name, level}) => [name, {level, primaryBytes: 0}]));
let complete = false;
let failure = null;
try {
    for (const frame of manifest.frames) {
        const compressed = new Uint8Array(await readFile(join(dirname(manifestPath), frame.name)));
        assert.equal(compressed.byteLength, frame.bytes);
        assert.equal(sha(compressed), frame.sha256);
        verifyEnvelope(compressed);
        const raw = codec.decompressUsingDict(decoder, compressed.subarray(12), dictionary,
            {defaultHeapSize: frame.expectedRawBytes, maxOutputSize: frame.expectedRawBytes});
        assert.equal(raw.byteLength, frame.expectedRawBytes);
        const rawSha256 = sha(raw);
        rawDigest.update(raw);
        const outputs = {};
        for (const arm of arms) {
            const encoded = codec.compressUsingDictWithPrefix(arm.context, raw, dictionary, 12, arm.level, true);
            verifyEnvelope(encoded);
            if (arm.level === -1) {
                assert.deepEqual(encoded, compressed, `Existing API must reproduce the captured production frame exactly: ${frame.name}/${arm.name}`);
            }
            const decoded = codec.decompressUsingDict(decoder, encoded.subarray(12), dictionary,
                {defaultHeapSize: frame.expectedRawBytes, maxOutputSize: frame.expectedRawBytes});
            assert.equal(sha(decoded), rawSha256);
            assert.deepEqual(decoded, raw);
            const outputPath = arm.level === -1 ? join(dirname(manifestPath), frame.name) : join(output, `minus${-arm.level}`, frame.name);
            if (arm.level !== -1) { await writeFile(outputPath, encoded, {flag: 'wx'}); }
            outputs[arm.name] = {level: arm.level, bytes: encoded.byteLength, sha256: sha(encoded), path: outputPath};
            totals[arm.name].primaryBytes += encoded.byteLength;
        }
        assert.equal(sha(raw), rawSha256, 'Compression must not mutate the decoded source');
        frameResults.push({...frame, rawSha256, outputs});
    }
    assert.equal(frameResults.length, oracle.frames);
    for (const total of Object.values(totals)) {
        total.addedBytes = total.primaryBytes - manifest.primaryBytes;
        total.projectedPersistedBytes = manifest.totalPersistedBytes + total.addedBytes;
        total.persistedChangePercent = 100 * total.addedBytes / manifest.totalPersistedBytes;
        total.withinProspectiveTwoPercentCeiling = total.addedBytes <= manifest.totalPersistedBytes * 0.02;
    }
    complete = true;
} catch (error) {
    failure = error.stack ?? String(error);
    process.stderr.write(`${failure}\n`);
    process.exitCode = 1;
} finally {
    for (const arm of arms) { codec.freeCCtx(arm.context); }
    codec.freeDCtx(decoder);
    const report = {
        complete, failure, dictionary: manifest.dictionary, sourceCommit: manifest.sourceCommit,
        scope: 'Untimed existing-API Zstd level comparison on every real admitted production frame. No product setting change and no full-import speed claim.',
        prospectiveTotalPersistedIncreaseCeilingPercent: 2,
        caveat: 'Projected persisted bytes keep reference widths and all other stores fixed; complete browser physical inventory is required before promotion.',
        captureManifestPath: manifestPath, captureManifestSha256: sha(await readFile(manifestPath)),
        codecSourceFiles: manifest.codecSourceFiles, dictionarySha256: sha(dictionary),
        rawBytes: manifest.rawBytes, rawDigestSha256: rawDigest.digest('hex'),
        baselinePrimaryBytes: manifest.primaryBytes, baselineTotalPersistedBytes: manifest.totalPersistedBytes,
        baselineReferenceBytes: manifest.referenceBytes, totals, frames: frameResults,
        node: process.version, versions: process.versions,
    };
    await writeFile(join(output, 'census.json'), `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'});
    process.stdout.write(`${JSON.stringify({complete, failure, dictionary: manifest.dictionary, frames: frameResults.length, totals})}\n`);
}
