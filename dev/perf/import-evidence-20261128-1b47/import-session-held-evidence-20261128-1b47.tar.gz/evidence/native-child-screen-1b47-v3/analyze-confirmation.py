#!/usr/bin/env python3
"""Fixed prospective paired-block analysis for the v3 comma confirmation."""
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument("cohort", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
assert not args.output.exists(), "Never overwrite an analysis"
plan_bytes = (args.cohort / "plan.json").read_bytes()
plan = json.loads(plan_bytes)
registration = json.loads((args.cohort.parent / "confirmation-registration-v3.json").read_bytes())
assert hashlib.sha256(plan_bytes).hexdigest() == registration["cohorts"][plan["dictionary"]]["planSha256"]
assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest() == registration["analysis"]["helperSha256"]
assert hashlib.sha256(Path(registration["analysis"]["notePath"]).read_bytes()).hexdigest() == registration["analysis"]["noteSha256"]
end = json.loads((args.cohort / "acquisition-end.json").read_bytes())
observations_bytes = (args.cohort / "observations.json").read_bytes()
observations = json.loads(observations_bytes)
assert plan["protocol"] == "one-arm-native-parser-20261128-1b47-v3-comma-confirmation"
assert plan["measuredBlocks"] == 24
assert end["complete"] is True and end["completedChildren"] == 72
assert len(observations) == 72
expected = [(b, p, a) for b, order in enumerate(plan["orders"]) for p, a in enumerate(order)]
assert [(o["block"], o["position"], o["arm"]) for o in observations] == expected
for o in observations:
    assert o["totals"]["rows"] == plan["reference"]["fixture"]["termRows"]
    assert o["totals"]["counts"]["fusedParseFallbacks"] == 0
    assert o["outcome"]["exitCode"] == 0 and o["outcome"]["signal"] is None
rng = np.random.Generator(np.random.PCG64(20261128))
indices = rng.integers(0, 24, size=(100000, 24), dtype=np.int64)
fields = ["elapsedMs", "parseBankMs", "parseWallMs", "cpuTotalMs",
          "inflateWallMs", "inflateMs", "lookupIndexEncodeMs"]
out = {
    "protocol": plan["protocol"], "dictionary": plan["dictionary"], "complete": True,
    "planSha256": hashlib.sha256(plan_bytes).hexdigest(),
    "observationsSha256": hashlib.sha256(observations_bytes).hexdigest(),
    "method": {"blocks": 24, "resamples": 100000, "seed": 20261128,
               "generator": "NumPy PCG64", "numpyVersion": np.__version__,
               "percentiles": [2.5, 97.5], "percentileMethod": "linear",
               "sharedIndicesAcrossMetricsAndComparisons": True,
               "indexMatrixSha256": hashlib.sha256(indices.astype("<i8").tobytes()).hexdigest()},
    "scope": "Descriptive native-parser component only; systematic drift is not removed; no pooling or automatic PR decision.",
    "comparisons": {},
}
values = {a: {key: np.array([next(o for o in observations if o["block"] == b and o["arm"] == a)["totals"][key]
                            for b in range(24)], dtype=np.float64) for key in fields} for a in "ABC"}
for name, left, right in [("BoverA", "A", "B"), ("BoverC", "C", "B"), ("CoverA", "A", "C")]:
    metrics = {}
    for key in fields:
        ratios = values[right][key] / values[left][key]
        assert np.all(np.isfinite(ratios)) and np.all(ratios > 0)
        samples = ratios[indices]
        median_samples = 100 * (np.median(samples, axis=1) - 1)
        geometric_samples = 100 * (np.exp(np.mean(np.log(samples), axis=1)) - 1)
        metrics[key] = {
            "ratios": ratios.tolist(),
            "medianPairedChangePercent": float(100 * (np.median(ratios) - 1)),
            "medianPaired95PercentileInterval": np.percentile(median_samples, [2.5, 97.5], method="linear").tolist(),
            "geometricChangePercent": float(100 * (np.exp(np.mean(np.log(ratios))) - 1)),
            "geometric95PercentileInterval": np.percentile(geometric_samples, [2.5, 97.5], method="linear").tolist(),
            "medianSavedMs": float(np.median(values[left][key] - values[right][key])),
            "fasterBlocks": int(np.sum(ratios < 1)),
        }
    out["comparisons"][name] = metrics
with args.output.open("x") as stream:
    json.dump(out, stream, indent=2)
    stream.write("\n")
print(json.dumps({"complete": True, "dictionary": plan["dictionary"], "output": str(args.output)}))
