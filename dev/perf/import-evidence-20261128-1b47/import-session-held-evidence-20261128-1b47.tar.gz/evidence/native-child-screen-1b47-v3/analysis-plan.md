# Prospective comma confirmation analysis

Registered before any v3 observations. This note belongs only to `one-arm-native-parser-20261128-1b47-v3-comma-confirmation`.

## Fixed cohorts and comparisons

Both JMdict and Jitendex use 24 complete blocks: four cycles of ABC, BCA, CAB, ACB, CBA, BAC. Each block has one measured complete-corpus observation for each arm, following that child's complete excluded warmup. A and C are identical baseline source/native controls. B is the frozen immediate-comma candidate. Both plans must be registered before either acquisition starts.

For B/A, B/C and C/A, report all 24 within-block ratios, the paired median percentage change, the paired geometric percentage change, paired milliseconds saved, and the number of faster blocks. Negative change means faster. Do not replace these with a difference between independently chosen arm medians.

## Fixed uncertainty procedure

Use a paired block bootstrap with 100,000 resamples. Each resample draws 24 block indices with replacement and keeps the A/B/C observations from those blocks together. Use one shared index matrix for all comparisons and metrics within each corpus, generated with NumPy `Generator(PCG64(20261128))`; record the NumPy version and the index-matrix SHA256.

For each resample, compute the paired median ratio and geometric mean ratio. Report the 2.5th and 97.5th percentiles using linear interpolation as descriptive 95% intervals for both effects. Retain every block, including outliers and large same-code differences. These intervals do not remove systematic host/order drift or prove browser-import performance.

The fixed primary fields are inclusive native-component `elapsedMs` and native parse `parseBankMs`. Also report `parseWallMs`, process `cpuTotalMs`, and the unchanged-phase controls `inflateWallMs`, `inflateMs` and `lookupIndexEncodeMs`. The lookup prepare/encode diagnostics overlap; do not add them or sum overlapping parser phases.

## Decision and stopping rule

A worthwhile candidate must show a gain against both identical baselines, with phase attribution supporting the changed parser work. Examine Jitendex regressions as well as JMdict gains. Point estimates alone do not qualify a PR; unresolved C/A drift, contradictory comparisons, or an unresolved Jitendex regression means hold.

This is exactly one prospective confirmation per corpus. Do not retry, replace failed children, discard observations, extend the schedule, or pool it with the original six-block screen. If either acquisition fails, preserve all partial evidence and report the failure; no complete-cohort interval is reported for an incomplete corpus. Stop after the registered confirmation regardless of result.
