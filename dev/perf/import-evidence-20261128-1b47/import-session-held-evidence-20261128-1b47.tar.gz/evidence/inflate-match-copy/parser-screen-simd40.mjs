/* SPDX-License-Identifier: GPL-3.0-or-later */
// Frozen native-parser component screen. No browser, worker scheduling, storage,
// compression sink, media import, publication, or complete-import timing.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream, openAsBlob} from 'node:fs';
import {readFile, writeFile, appendFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {cpus, totalmem, freemem} from 'node:os';
import {crc32, deflateRawSync} from 'node:zlib';

const [baselinePath, candidatePath, cachePath, dictionary, referencePath, outputPath] = process.argv.slice(2);
assert(baselinePath && candidatePath && cachePath && referencePath && outputPath);
assert(['jmdict', 'jitendex'].includes(dictionary));
const roots = {A: resolve(baselinePath), B: resolve(candidatePath), C: resolve(baselinePath)};
const output = resolve(outputPath);
const sha = (value) => createHash('sha256').update(value).digest('hex');
const git = (root, ...args) => execFileSync('git', args, {cwd: root, encoding: 'utf8'}).trim();
const fixedBaseline = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2';
const fixedCandidate = fixedBaseline; // Scratch native variant; unchanged production JS source.
const experimentRoot = '/workspace/scratch/1b47f6463b98/evidence/inflate-match-copy';
const experimentManifestBytes = await readFile(join(experimentRoot, 'build-manifest.json'));
const experimentManifest = JSON.parse(experimentManifestBytes);
assert.equal(experimentManifest.baseline, fixedBaseline);
assert.equal(experimentManifest.baselineReproduced, true);
const variantManifest = experimentManifest.variants.find(({name}) => name === 'simd40');
assert.equal(sha(await readFile(join(experimentRoot, 'simd40/vendor/libdeflate/lib/decompress_template.h'))), variantManifest.templateSha256);
const loadedWasmPaths = {};
const parserRelative = 'ext/js/dictionary/term-bank-wasm-parser.js';
const wasmRelative = 'dev/data/dictionary-wasm/term-bank-parser.wasm';
const manifestRelative = 'dev/data/dictionary-wasm/manifest.json';
const parserSource = await readFile(join(roots.A, parserRelative));
assert.equal(git(roots.A, 'rev-parse', 'HEAD'), fixedBaseline);
assert.equal(git(roots.B, 'rev-parse', 'HEAD'), fixedCandidate);
assert.deepEqual(parserSource, await readFile(join(roots.B, parserRelative)));
assert.deepEqual(await readFile(join(roots.A, 'package-lock.json')), await readFile(join(roots.B, 'package-lock.json')));
const referenceBytes = await readFile(referencePath);
const reference = JSON.parse(referenceBytes);
assert.equal(reference.complete, true);
assert.equal(reference.sourceCommit, fixedBaseline);
const lockBytes = await readFile(join(roots.A, 'test/perf/dictionaries.lock.json'));
assert.deepEqual(lockBytes, await readFile(join(roots.B, 'test/perf/dictionaries.lock.json')));
const fixture = JSON.parse(lockBytes).dictionaries[dictionary === 'controls' ? 'jmdict' : dictionary];
assert.equal(reference.fixture.sha256, fixture.sha256);
const options = {...reference.parserOptions, maxPendingChunks: 1, singleChunk: true, compactContentMetadata: true};
const arms = ['A', 'B', 'C'];
const orders = ['ABC', 'BCA', 'CAB', 'ACB', 'CBA', 'BAC'];
const parsers = {};
const identities = {};
for (const arm of arms) {
    loadedWasmPaths[arm] = arm === 'B' ? join(experimentRoot, 'simd40/term-bank-parser.wasm') : join(roots[arm], wasmRelative);
    const wasm = await readFile(loadedWasmPaths[arm]);
    const nativeManifest = JSON.parse(await readFile(join(roots[arm], manifestRelative)));
    assert.equal(arm === 'B' ? variantManifest.wasmSha256 : nativeManifest.targets.find(({name}) => name === 'term-bank-parser.wasm').sha256, sha(wasm));
    assert.equal(sha(wasm), arm === 'B' ? '5e83f5a7b98e3b347f911f6605a8259c91d629b24da662be9aee2cdabd3c5427' : reference.parserWasmSha256);
    // Separate module instances retain separate native memories. A and C use
    // identical source/WASM, and B uses exactly the same JS source as both.
    const parserUrl = pathToFileURL(join(roots.A, parserRelative));
    parserUrl.searchParams.set('simd40-screen-arm', arm);
    parsers[arm] = await import(parserUrl.href);
    parsers[arm].setTermBankWasmModule(await WebAssembly.compile(wasm));
    identities[arm] = {
        sourceCommit: git(roots[arm], 'rev-parse', 'HEAD'),
        nativeVariant: arm === 'B' ? 'scratch-simd40' : 'baseline',
        loadedWasmPath: loadedWasmPaths[arm],
        experimentManifestSha256: sha(experimentManifestBytes),
        nativeInflateSourceSha256: sha(await readFile(arm === 'B' ? join(experimentRoot, 'simd40/term-bank-inflate.c') : join(roots[arm], 'ext/js/dictionary/wasm/term-bank-inflate.c'))),
        inflateTemplateSha256: sha(await readFile(arm === 'B' ? join(experimentRoot, 'simd40/vendor/libdeflate/lib/decompress_template.h') : join(roots[arm], 'ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h'))),
        dirty: git(roots[arm], 'status', '--porcelain'),
        parserSourceSha256: sha(parserSource),
        nativeSourceSha256: sha(await readFile(join(roots[arm], 'ext/js/dictionary/wasm/term-bank-parser.c'))),
        wasmSha256: sha(wasm), wasmBytes: wasm.byteLength,
        manifestSha256: sha(await readFile(join(roots[arm], manifestRelative))),
    };
}
assert.equal(identities.A.wasmSha256, identities.C.wasmSha256);
const sourceGroups = [];
let zipReader = null;
let rawReader = null;
let controls = null;
let controlSourceSha256 = null;
let archive = null;
const signal = new AbortController().signal;
if (dictionary === 'controls') {
    const controlUrl = new URL('./control-fixtures.mjs', import.meta.url);
    controlSourceSha256 = sha(await readFile(controlUrl));
    const {makeKeyRunControls} = await import(controlUrl.href);
    controls = makeKeyRunControls().map((control) => ({...control, sources: control.banks.map((bytes, index) => {
        const compressed = new Uint8Array(deflateRawSync(bytes));
        return {bytes: compressed, compressionMethod: 8, compressedSize: compressed.byteLength,
            uncompressedSize: bytes.byteLength, signature: crc32(bytes), filename: `${control.name}-${index}.json`};
    })}));
    for (const control of controls) {
        sourceGroups.push({files: control.sources.map(({filename}) => filename), rows: control.rowCount,
            compressedBytes: control.sources.map(({compressedSize}) => compressedSize),
            rawBytes: control.banks.reduce((sum, value) => sum + value.byteLength, 0),
            sourceSha256: sha(Buffer.concat(control.banks)), name: control.name,
            expectedBaselineWitnesses: control.expectedBaselineWitnesses,
            expectedCandidateWitnesses: control.expectedCandidateWitnesses});
        delete control.banks;
    }
} else {
    const archivePath = join(cachePath, fixture.cacheFile);
    const archiveDigest = createHash('sha256');
    for await (const bytes of createReadStream(archivePath)) { archiveDigest.update(bytes); }
    assert.equal(archiveDigest.digest('hex'), fixture.sha256);
    archive = await openAsBlob(archivePath);
    assert.equal(archive.size, fixture.sizeBytes);
    const {readDenseZipDirectory} = await import(pathToFileURL(join(roots.A, 'ext/js/dictionary/dense-zip-directory.js')));
    const {RawZipPayloadReader} = await import(pathToFileURL(join(roots.A, 'ext/js/dictionary/term-bank-source-pipeline.js')));
    let entries = await readDenseZipDirectory(archive);
    if (entries === null) {
        const require = createRequire(join(roots.A, 'package.json'));
        const {BlobReader, ZipReader} = require('@zip.js/zip.js');
        zipReader = new ZipReader(new BlobReader(archive));
        entries = await zipReader.getEntries();
    }
    const byName = new Map(entries.map((entry) => [entry.filename, entry]));
    rawReader = new RawZipPayloadReader(archive);
    const expectedBanks = dictionary === 'jmdict' ? 53 : 219;
    const expectedGroups = dictionary === 'jmdict' ? 12 : 22;
    assert.equal(reference.sourceGroups.length, expectedGroups);
    assert.equal(reference.groups.length, expectedGroups);
    assert.equal(reference.sourceGroups.flatMap(({files}) => files).length, expectedBanks);
    assert.equal(new Set(reference.sourceGroups.flatMap(({files}) => files)).size, expectedBanks);
    for (const [index, group] of reference.sourceGroups.entries()) {
        const files = group.files.map((name) => { const entry = byName.get(name); assert(entry); return entry; });
        sourceGroups.push({files: group.files, entries: files, compressedBytes: group.bytes,
            rows: reference.groups[index].rows,
            rawBytes: files.reduce((sum, {uncompressedSize}) => sum + uncompressedSize, 0)});
    }
}

const measured = [];
const warmup = [];
const expected = [];
const initialRss = process.memoryUsage().rss;
const cohortStart = performance.now();
let completed = false;
let failure = null;
let comparedBytes = 0;
let comparedLeaves = 0;
const warmupCanonical = Object.fromEntries(arms.map((arm) => [arm, createHash('sha256')]));
const warmupRaw = Object.fromEntries(arms.map((arm) => [arm, createHash('sha256')]));
const warmupOutput = Object.fromEntries(arms.map((arm) => [arm, createHash('sha256')]));

async function readSources(index) {
    if (controls !== null) { return controls[index].sources; }
    const group = sourceGroups[index];
    const sources = await Promise.all(group.entries.map(async (entry) => ({
        bytes: await rawReader.read(entry, signal), compressionMethod: entry.compressionMethod,
        compressedSize: entry.compressedSize, uncompressedSize: entry.uncompressedSize,
        signature: entry.signature, filename: entry.filename,
    })));
    assert.deepEqual(sources.map(({bytes}) => bytes.byteLength), group.compressedBytes);
    return sources;
}

async function parse(arm, sources) {
    const parser = parsers[arm];
    const chunks = [];
    const cpuStart = process.cpuUsage();
    const start = performance.now();
    const preloaded = await parser.inflateCompressedTermBankSourcesWasm(sources, options, true);
    const inflatedAt = performance.now();
    await parser.parseTermBankWithWasmColumnChunks(new Uint8Array(), 3, (chunk) => { chunks.push(chunk); }, 2048,
        {...options, preloadedSource: preloaded});
    const end = performance.now();
    const cpu = process.cpuUsage(cpuStart);
    const profile = parser.consumeLastTermBankWasmParseProfile();
    assert.equal(chunks.length, 1);
    assert.equal(profile.fusedParseAttempts, 1);
    assert.equal(profile.fusedParseFallbacks, 0);
    if (preloaded.crcSignaturesPtr) { assert.equal(preloaded.crcVerified, true); }
    const measurement = {elapsedMs: end - start, inflateWallMs: inflatedAt - start, parseWallMs: end - inflatedAt,
        cpuUserMs: cpu.user / 1000, cpuSystemMs: cpu.system / 1000, cpuTotalMs: (cpu.user + cpu.system) / 1000,
        inflateMs: preloaded.inflateMs, crcMs: preloaded.crcMs ?? 0,
        sourceCrcDeferred: Boolean(preloaded.crcSignaturesPtr), crcScannedBytes: preloaded.crcScannedBytes ?? 0,
        crcReusedBytes: preloaded.crcReusedBytes ?? 0, crcReusedGlossaryCount: preloaded.crcReusedGlossaryCount ?? 0,
        wasmHeapBytes: preloaded.wasm.memory.buffer.byteLength, profile};
    const raw = new Uint8Array(preloaded.wasm.memory.buffer, preloaded.jsonPtr, preloaded.jsonLength);
    // Production result normalization and all exact comparisons/hashes happen
    // after the timers. The native buffers remain private to this arm.
    const stable = parser.copyWasmBackedColumnChunk(chunks[0], true, false, true, preloaded);
    delete stable.preparedLookupIndexEncodeMs;
    return {measurement, raw, stable};
}

function hashCanonical(hash, chunk) {
    for (const key of ['rowCount', 'contentBytesBaseOffset', 'contentBytesLength', 'contentMetaByUniqueIndex']) { hash.update(`${key}:${chunk[key]}\n`); }
    for (const key of ['contentBytesBuffer', 'contentMetaList', 'contentUniqueIndexList', 'scoreList', 'sequenceList', 'readingEqualsExpressionList']) {
        const value = chunk[key];
        hash.update(`${key}:${value?.byteLength}\n`);
        if (ArrayBuffer.isView(value)) { hash.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)); }
    }
}

function hashValue(hash, value, path) {
    hash.update(path + '\n');
    if (ArrayBuffer.isView(value)) {
        hash.update(value.constructor.name + ':' + value.byteLength + '\n');
        hash.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength));
    } else if (Array.isArray(value)) {
        hash.update('Array:' + value.length + '\n');
        for (let i = 0; i < value.length; ++i) { hashValue(hash, value[i], `${path}[${i}]`); }
    } else if (value instanceof Map) {
        hash.update('Map:' + value.size + '\n');
        for (const [key, item] of value) { hashValue(hash, item, `${path}.map(${key})`); }
    } else if (value !== null && typeof value === 'object') {
        assert.equal(Object.getPrototypeOf(value), Object.prototype, 'Unknown opaque output at ' + path);
        for (const key of Object.keys(value).sort()) { hashValue(hash, value[key], `${path}.${key}`); }
    } else {
        assert.notEqual(typeof value, 'function', 'Opaque callback at ' + path);
        hash.update(typeof value + ':' + (Object.is(value, -0) ? '-0' : String(value)) + '\n');
    }
}

function compareValue(left, right, path) {
    ++comparedLeaves;
    if (ArrayBuffer.isView(left) || ArrayBuffer.isView(right)) {
        assert(ArrayBuffer.isView(left) && ArrayBuffer.isView(right), path);
        assert.equal(left.constructor.name, right.constructor.name, path);
        assert.equal(left.byteLength, right.byteLength, path);
        assert(Buffer.from(left.buffer, left.byteOffset, left.byteLength).equals(Buffer.from(right.buffer, right.byteOffset, right.byteLength)), 'Different bytes at ' + path);
        comparedBytes += left.byteLength;
    } else if (Array.isArray(left) || Array.isArray(right)) {
        assert(Array.isArray(left) && Array.isArray(right), path);
        assert.equal(left.length, right.length, path);
        for (let i = 0; i < left.length; ++i) { compareValue(left[i], right[i], `${path}[${i}]`); }
    } else if (left instanceof Map || right instanceof Map) {
        assert(left instanceof Map && right instanceof Map, path);
        assert.deepEqual([...left.keys()], [...right.keys()], path);
        for (const [key, value] of left) { compareValue(value, right.get(key), `${path}.map(${key})`); }
    } else if (left !== null && typeof left === 'object' || right !== null && typeof right === 'object') {
        assert(left !== null && right !== null && typeof left === 'object' && typeof right === 'object', path);
        assert.equal(Object.getPrototypeOf(left), Object.prototype, path);
        assert.equal(Object.getPrototypeOf(right), Object.prototype, path);
        assert.deepEqual(Object.keys(left).sort(), Object.keys(right).sort(), path);
        for (const key of Object.keys(left).sort()) { compareValue(left[key], right[key], `${path}.${key}`); }
    } else {
        assert.notEqual(typeof left, 'function', path);
        assert.equal(left, right, path);
    }
}

const metricKeys = ['elapsedMs', 'inflateWallMs', 'parseWallMs', 'cpuTotalMs', 'inflateMs', 'crcMs'];
const profileKeys = ['parseBankMs', 'encodeContentMs', 'nativeStringPlanMs', 'rowDecodeMs', 'validatedGlossaryReuseCount',
    'recentContentDedupHitCount', 'globalExactContentReuseCount', 'lookupIndexPrepareMs', 'lookupIndexCompactMs', 'lookupIndexEncodeMs'];
const median = (values) => { const a = [...values].sort((x, y) => x - y); return (a[Math.floor((a.length - 1) / 2)] + a[Math.floor(a.length / 2)]) / 2; };
function blockTotals(rows) {
    const totals = [];
    for (let block = 0; block < 6; ++block) {
        const selected = rows.filter((row) => row.block === block);
        totals.push({block, ...Object.fromEntries(arms.map((arm) => [arm, {
            ...Object.fromEntries(metricKeys.map((key) => [key, selected.reduce((sum, row) => sum + row[arm][key], 0)])),
            ...Object.fromEntries(profileKeys.map((key) => [key, selected.reduce((sum, row) => sum + (row[arm].profile[key] ?? 0), 0)])),
        }]))});
    }
    return totals;
}
function summarize(rows) {
    const totals = blockTotals(rows);
    const comparisons = {};
    for (const [name, left, right] of [['BoverA', 'A', 'B'], ['BoverC', 'C', 'B'], ['CoverA', 'A', 'C']]) {
        comparisons[name] = Object.fromEntries([...metricKeys, ...profileKeys].map((key) => {
            const ratios = totals.map((row) => row[right][key] / row[left][key]).filter((ratio) => Number.isFinite(ratio) && ratio > 0);
            return [key, ratios.length === 6 ? {medianPairedChangePercent: 100 * (median(ratios) - 1),
                geometricChangePercent: 100 * (Math.exp(ratios.reduce((sum, value) => sum + Math.log(value), 0) / ratios.length) - 1),
                medianSavedMs: median(totals.map((row) => row[left][key] - row[right][key])),
                fasterBlocks: ratios.filter((value) => value < 1).length, ratios} : null];
        }));
    }
    return {blockTotals: totals, comparisons};
}

const scope = 'Sequential native-parser component only. Exact production source groups and options, three independent module/WASM memories; A and C identical, B scratch SIMD40 inflater variant with unchanged parser source. One complete-corpus correctness/warmup pass per arm is excluded, followed by six fixed balanced blocks. Timers cover native inflate/source CRC and parser/prepared lookup plans, excluding source I/O, production result copy, hashing, database/storage/compression/worker scheduling. Every output/source digest is checked outside timers. No full-import speed claim. Native parseBankMs includes deferred crcMs; never sum overlapping phases.';
const plan = {baseline: fixedBaseline, candidateSourceBase: fixedCandidate, candidate: 'scratch SIMD40 inflater', dictionary, measuredBlocks: 6, orders,
    groupOrder: 'original source order; rotate each block permutation by group index modulo3',
    warmup: 'one full corpus per arm, complete exact equality and source digest validation',
    scope, options, identities, referencePath: resolve(referencePath), referenceSha256: sha(referenceBytes),
    controlSourceSha256, sourceGroups: sourceGroups.map(({entries, ...group}) => group)};
await writeFile(output + '.plan.json', JSON.stringify(plan, null, 2) + '\n', {flag: 'wx'});
await writeFile(output + '.groups.jsonl', '', {flag: 'wx'});
try {
    for (let block = -1; block < 6; ++block) {
        for (let index = 0; index < sourceGroups.length; ++index) {
            const group = sourceGroups[index];
            const sources = await readSources(index);
            const baseOrder = block < 0 ? 'ABC' : orders[block];
            const offset = index % 3;
            const order = baseOrder.slice(offset) + baseOrder.slice(0, offset);
            const results = {};
            for (const arm of order) { results[arm] = await parse(arm, sources); }
            for (const arm of arms) {
                assert.equal(results[arm].stable.rowCount, group.rows);
                assert.equal(results[arm].raw.byteLength, group.rawBytes);
                if (dictionary === 'controls') {
                    assert.equal(results[arm].measurement.profile.validatedGlossaryReuseCount,
                        arm === 'B' ? group.expectedCandidateWitnesses : group.expectedBaselineWitnesses,
                        `${group.name}: unexpected ${arm} glossary witnesses`);
                }
            }
            const observation = {block, index, name: group.name, files: group.files, order, rows: group.rows,
                ...Object.fromEntries(arms.map((arm) => [arm, results[arm].measurement]))};
            if (block < 0) {
                compareValue(results.A.stable, results.B.stable, 'group-' + index);
                compareValue(results.A.stable, results.C.stable, 'group-' + index);
                compareValue(results.A.raw, results.B.raw, 'source-' + index);
                compareValue(results.A.raw, results.C.raw, 'source-' + index);
                for (const arm of arms) {
                    hashCanonical(warmupCanonical[arm], results[arm].stable);
                    warmupRaw[arm].update(results[arm].raw);
                    hashValue(warmupOutput[arm], results[arm].stable, 'group-' + index);
                }
                const outputHash = createHash('sha256');
                hashValue(outputHash, results.A.stable, 'group-' + index);
                expected.push({raw: sha(results.A.raw), output: outputHash.digest('hex')});
                if (group.sourceSha256) { assert.equal(expected[index].raw, group.sourceSha256); }
                warmup.push(observation);
            } else {
                for (const arm of arms) {
                    assert.equal(sha(results[arm].raw), expected[index].raw, arm + ': raw source changed');
                    const outputHash = createHash('sha256');
                    hashValue(outputHash, results[arm].stable, 'group-' + index);
                    assert.equal(outputHash.digest('hex'), expected[index].output, arm + ': complete output changed');
                }
                measured.push(observation);
            }
            await appendFile(output + '.groups.jsonl', JSON.stringify(observation) + '\n');
        }
        if (block < 0 && dictionary !== 'controls') {
            assert.equal(sourceGroups.reduce((sum, group) => sum + group.rows, 0), fixture.termRows);
            for (const arm of arms) {
                assert.equal(warmupCanonical[arm].copy().digest('hex'), reference.sourceDigestSha256,
                    `${arm}: correctness warmup differs from the frozen canonical/row sink digest`);
            }
        }
        process.stdout.write(JSON.stringify({phase: block < 0 ? 'correctness-warmup' : 'measurement', block,
            groups: sourceGroups.length, rows: sourceGroups.reduce((sum, group) => sum + group.rows, 0),
            elapsedSeconds: (performance.now() - cohortStart) / 1000, peakRssKiB: process.resourceUsage().maxRSS}) + '\n');
    }
    completed = true;
} catch (error) {
    failure = error.stack ?? String(error);
    process.stderr.write(failure + '\n');
    process.exitCode = 1;
} finally {
    if (zipReader !== null) { await zipReader.close(); }
    const canonicalDigests = Object.fromEntries(arms.map((arm) => [arm, warmupCanonical[arm].digest('hex')]));
    const rawDigests = Object.fromEntries(arms.map((arm) => [arm, warmupRaw[arm].digest('hex')]));
    const outputDigests = Object.fromEntries(arms.map((arm) => [arm, warmupOutput[arm].digest('hex')]));
    if (completed && dictionary !== 'controls') {
        for (const arm of arms) {
            if (canonicalDigests[arm] !== reference.sourceDigestSha256) {
                completed = false;
                failure = `Canonical and row output digest differs from frozen sink reference: ${arm}`;
                process.exitCode = 1;
            }
        }
    }
    for (const arm of arms) { assert.equal(sha(await readFile(loadedWasmPaths[arm])), identities[arm].wasmSha256, 'Runtime changed during cohort'); }
    const report = {completed, failure, ...plan, node: process.version, cpuModel: cpus()[0]?.model,
        totalMemoryBytes: totalmem(), freeMemoryAtEndBytes: freemem(), initialRssBytes: initialRss,
        peakRssKiB: process.resourceUsage().maxRSS, scriptSha256: sha(await readFile(new URL(import.meta.url))),
        warmup, measured, comparedBytes, comparedLeaves, expectedGroupDigests: expected,
        canonicalDigests, rawDigests, outputDigests, referenceSourceDigestSha256: dictionary === 'controls' ? null : reference.sourceDigestSha256,
        summary: measured.length === sourceGroups.length * 6 ? summarize(measured) : null,
        controls: dictionary === 'controls' && measured.length === sourceGroups.length * 6 ?
            Object.fromEntries(sourceGroups.map((group, index) => [group.name, summarize(measured.filter((row) => row.index === index))])) : null};
    await writeFile(output, JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
    process.stdout.write('SUMMARY ' + JSON.stringify({completed, failure, dictionary, canonicalDigests,
        summary: report.summary?.comparisons, controls: report.controls && Object.fromEntries(Object.entries(report.controls).map(([name, value]) => [name, value.comparisons]))}) + '\n');
}
