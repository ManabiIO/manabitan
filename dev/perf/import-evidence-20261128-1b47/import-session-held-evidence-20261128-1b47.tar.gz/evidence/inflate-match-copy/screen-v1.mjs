import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {crc32, inflateRawSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';

const root = path.dirname(fileURLToPath(import.meta.url));
const dictionary = process.argv[2] ?? 'jmdict';
const fixtures = {
    jmdict: ['JMdict.zip', '3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f', 53],
    jitendex: ['jitendex-yomitan.zip', 'e914c76596220dffc6ee0c069cd05992f03adb2988c12c3cebe817a3ac271356', 44],
    vndb: ['vndb_characters_by_bee.zip', 'da5baed5332761513dcef8d0b07ad0d9201cdd7f37831dea37e7162994ec3792', 665],
};
assert.ok(dictionary in fixtures);
const [filename, fixtureSha, expectedBanks] = fixtures[dictionary];
const sha = x => createHash('sha256').update(x).digest('hex');
const archive = fs.readFileSync(path.join('/tmp/manabitan-1b47-fixtures', filename));
assert.equal(sha(archive), fixtureSha);
let eocd = archive.length - 22;
while (archive.readUInt32LE(eocd) !== 0x06054b50) --eocd;
const count = archive.readUInt16LE(eocd + 10);
let central = archive.readUInt32LE(eocd + 16);
const banks = [];
for (let i = 0; i < count; ++i) {
    assert.equal(archive.readUInt32LE(central), 0x02014b50);
    const method = archive.readUInt16LE(central + 10);
    const signature = archive.readUInt32LE(central + 16);
    const compressedLength = archive.readUInt32LE(central + 20);
    const length = archive.readUInt32LE(central + 24);
    const nameLength = archive.readUInt16LE(central + 28);
    const extraLength = archive.readUInt16LE(central + 30);
    const commentLength = archive.readUInt16LE(central + 32);
    const offset = archive.readUInt32LE(central + 42);
    const name = archive.toString('utf8', central + 46, central + 46 + nameLength);
    central += 46 + nameLength + extraLength + commentLength;
    if (!/^term_bank_\d+\.json$/.test(name)) continue;
    assert.equal(method, 8);
    assert.equal(archive.readUInt32LE(offset), 0x04034b50);
    const start = offset + 30 + archive.readUInt16LE(offset + 26) + archive.readUInt16LE(offset + 28);
    const compressed = archive.subarray(start, start + compressedLength);
    const bytes = inflateRawSync(compressed);
    assert.equal(bytes.length, length);
    assert.equal(crc32(bytes), signature);
    banks.push({name, compressed, signature, length, compressedLength, sha256: sha(bytes)});
}
banks.sort((a, b) => Number(a.name.match(/\d+/)[0]) - Number(b.name.match(/\d+/)[0]));
assert.equal(banks.length, expectedBanks);
const inputCapacity = Math.max(...banks.map(x => x.compressedLength));
const outputCapacity = Math.max(...banks.map(x => x.length));
const variants = [];
for (const [name, directory] of [['A', 'baseline'], ['B32', 'simd32'], ['B40', 'simd40'], ['C', 'baseline']]) {
    const wasm = fs.readFileSync(path.join(root, directory, 'term-bank-parser.wasm'));
    const module = new WebAssembly.Module(wasm);
    assert.equal(WebAssembly.Module.imports(module).length, 0);
    const instance = new WebAssembly.Instance(module).exports;
    instance.wasm_reset_heap();
    const input = instance.wasm_alloc(inputCapacity + 16);
    const metadata = instance.wasm_alloc(20);
    const output = instance.wasm_alloc(outputCapacity + 32) + 16;
    const spans = instance.wasm_alloc(8);
    const memory = new Uint8Array(instance.memory.buffer);
    const meta = new Uint32Array(instance.memory.buffer, metadata, 5);
    const spanValues = new Uint32Array(instance.memory.buffer, spans, 2);
    const prepare = bank => {
        memory.set(bank.compressed, input);
        meta.set([0, bank.compressedLength, bank.length, 8, bank.signature]);
        memory.fill(0xa5, output - 16, output);
        memory.fill(0xa5, output + bank.length, output + bank.length + 16);
    };
    const inflate = (bank, defer) => instance.inflate_and_join_term_banks(input, bank.compressedLength,
        metadata, metadata + 4, metadata + 8, metadata + 12, metadata + 16,
        1, output, bank.length, spans, defer);
    let oracleCalls = 0;
    for (const bank of banks) {
        const expected = inflateRawSync(bank.compressed);
        for (const defer of [0, 1]) {
            prepare(bank);
            assert.equal(inflate(bank, defer), bank.length);
            assert.deepEqual(Array.from(spanValues), [0, bank.length]);
            assert.ok(Buffer.from(memory.buffer, output, bank.length).equals(expected));
            assert.ok(memory.subarray(output - 16, output).every(x => x === 0xa5));
            assert.ok(memory.subarray(output + bank.length, output + bank.length + 16).every(x => x === 0xa5));
            ++oracleCalls;
        }
        meta[4] = bank.signature ^ 1;
        assert.equal(inflate(bank, 0), -4);
        ++oracleCalls;
    }
    variants.push({name, directory, prepare, inflate, oracleCalls, wasmSha256: sha(wasm)});
}
const blocks = Number(process.env.INFLATE_SCREEN_BLOCKS ?? 12);
const plan = {scope: 'Production native inflation, separately with/without original bank CRC; no complete import claim',
    baseline: '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2', dictionary, fixtureSha, node: process.version, v8: process.versions.v8,
    blocks, excludedWarmups: 2, control: 'C is exact baseline with a separate instance',
    variants: variants.map(({name, directory, oracleCalls, wasmSha256}) => ({name, directory, oracleCalls, wasmSha256})),
    banks: banks.map(({compressed, ...rest}) => rest)};
fs.writeFileSync(path.join(root, `${dictionary}-plan.json`), JSON.stringify(plan, null, 2) + '\n');
const rows = [];
const raw = fs.openSync(path.join(root, `${dictionary}-observations.jsonl`), 'w');
for (let block = -2; block < blocks; ++block) {
    const totals = Object.fromEntries(variants.map(v => [v.name, {inflate: 0, inflateAndCrc: 0}]));
    for (let bankIndex = 0; bankIndex < banks.length; ++bankIndex) {
        const bank = banks[bankIndex];
        const rotation = (block + 2 + bankIndex) % variants.length;
        const order = Array.from({length: variants.length}, (_, i) => variants[(i + rotation) % variants.length]);
        if (block % 2) order.reverse();
        const modes = block % 2 ? [0, 1] : [1, 0];
        for (const defer of modes) {
            for (const v of order) {
                v.prepare(bank);
                const started = performance.now();
                const status = v.inflate(bank, defer);
                const elapsed = performance.now() - started;
                assert.equal(status, bank.length);
                totals[v.name][defer ? 'inflate' : 'inflateAndCrc'] += elapsed;
            }
        }
    }
    const row = {block, warmup: block < 0, totals};
    fs.writeSync(raw, JSON.stringify(row) + '\n');
    if (block >= 0) rows.push(row);
}
fs.closeSync(raw);
const median = xs => { const a = [...xs].sort((a, b) => a - b); return (a[(a.length - 1) >>> 1] + a[a.length >>> 1]) / 2; };
const results = [];
for (const mode of ['inflate', 'inflateAndCrc']) {
    for (const name of ['B32', 'B40', 'C']) {
        const ratios = rows.map(o => o.totals[name][mode] / o.totals.A[mode]);
        results.push({mode, name, pairedMedianPercent: 100 * (median(ratios) - 1),
            geometricPercent: 100 * (Math.exp(ratios.reduce((s, x) => s + Math.log(x), 0) / ratios.length) - 1),
            faster: ratios.filter(x => x < 1).length, ratios});
    }
}
fs.writeFileSync(path.join(root, `${dictionary}-screen.json`), JSON.stringify({plan, rows, results}, null, 2) + '\n');
console.log(JSON.stringify({dictionary, banks: banks.length, sourceBytes: banks.reduce((s, x) => s + x.length, 0), results}, null, 2));
