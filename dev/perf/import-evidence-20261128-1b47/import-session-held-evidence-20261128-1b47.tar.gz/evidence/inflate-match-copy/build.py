import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/1b47f6463b98/manabitan')
SOURCE_ROOT = REPO / 'ext/js/dictionary/wasm'
CLANG = Path('/tmp/manabitan-native-9bb32/native-toolchain/bin/clang')
LINKER = CLANG.with_name('wasm-ld')
manifest = json.loads((REPO / 'dev/data/dictionary-wasm/manifest.json').read_text())
target = next(x for x in manifest['targets'] if x['name'] == 'term-bank-parser.wasm')
original = (SOURCE_ROOT / 'vendor/libdeflate/lib/decompress_template.h').read_text()
needle = '\t\tif (UNALIGNED_ACCESS_IS_FAST && offset >= WORDBYTES) {'
assert original.count(needle) == 1
rows = []
for name, stride in [('baseline', 0), ('simd32', 32), ('simd40', 40)]:
    directory = ROOT / name
    directory.mkdir(exist_ok=True)
    if stride:
        vendor = directory / 'vendor/libdeflate'
        shutil.copytree(SOURCE_ROOT / 'vendor/libdeflate', vendor, dirs_exist_ok=True)
        extra = '' if stride == 32 else '\t\t\t\tstore_word_unaligned(load_word_unaligned(src), dst);\n\t\t\t\tsrc += WORDBYTES;\n\t\t\t\tdst += WORDBYTES;\n'
        replacement = '''#if defined(__wasm_simd128__)
        /* Two sequential vector copies preserve LZ overlap for offset >=16.
         * The maximum overrun remains within the existing39-byte slack. */
        if (offset >=16u) {
            do {
                wasm_v128_store(dst, wasm_v128_load(src));
                src +=16;
                dst +=16;
                wasm_v128_store(dst, wasm_v128_load(src));
                src +=16;
                dst +=16;
''' + extra + '''            } while (dst < out_next);
        } else
#endif
''' + needle
        altered = original.replace(needle, replacement, 1)
        (vendor / 'lib/decompress_template.h').write_text(altered)
        wrapper = (SOURCE_ROOT / 'term-bank-inflate.c').read_text()
        wrapper = '#if defined(__wasm_simd128__)\n#include <wasm_simd128.h>\n#endif\n' + wrapper
        inflate_path = directory / 'term-bank-inflate.c'
        inflate_path.write_text(wrapper)
    else:
        altered = original
        inflate_path = SOURCE_ROOT / 'term-bank-inflate.c'
    output = directory / 'term-bank-parser.wasm'
    command = [str(CLANG), f'-fuse-ld={LINKER}', *target['arguments'], '-o', str(output),
               str(SOURCE_ROOT / 'term-bank-parser.c'), str(inflate_path)]
    subprocess.run(command, check=True)
    rows.append({'name': name, 'stride': stride, 'templateSha256': hashlib.sha256(altered.encode()).hexdigest(),
                 'wasmSha256': hashlib.sha256(output.read_bytes()).hexdigest(), 'bytes': output.stat().st_size,
                 'command': command})
assert (ROOT / 'baseline/term-bank-parser.wasm').read_bytes() == (REPO / 'dev/data/dictionary-wasm/term-bank-parser.wasm').read_bytes()
report = {'baseline': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2', 'baselineReproduced': True,
          'scope': 'Scratch inflater copy experiment only; no product changes', 'variants': rows}
(ROOT / 'build-manifest.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
