# Native inflater copy experiment

## Decision

Do not promote either scratch variant to a PR from this evidence. SIMD32 has no
useful gain and substantially repeats the mechanism in held PR #812. SIMD40 has
a Jitendex inflation-only signal, but neither full-parser acquisition completed.
JMdict has no useful signal. Stop further local SIMD40 acquisitions after the one
declared heap-bounded follow-up also ended with external process termination.

## Source and correctness boundary

The exact source baseline is `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
Clang/LLD 21.1.8 reproduced the checked-in baseline WASM byte-for-byte.
`build.py` creates scratch-only changes to libdeflate's fast history-copy loop.
There are no product checkout changes.

- SIMD32: two sequential 16-byte copies for distances at least 16.
- SIMD40: those copies followed by the existing 8-byte word copy.
- Existing smaller-distance and bounded-tail paths remain unchanged.
- Current wasm32 uses an 8-byte word. SIMD40's maximum 39-byte overrun fits the
  original fast-loop slack. The sequential stores preserve overlap at distances
  16 through 31; independent source review found no present bounds defect.
- Any future production version needs an explicit compile-time slack guard and
  targeted fast-loop overlap tests around lengths 39/40/41 and 79/80/81.

All 53 JMdict and 219 Jitendex source banks in the isolated inflation screens
matched independent Node zlib output. Tests also exercised wrong-CRC rejection,
logical lengths and output canaries. No corpus bytes were relaxed or omitted.
The first Jitendex preparation mistakenly asserted 44 banks; it failed before
timing. The original script/error and the narrow 219-bank correction are retained.

## Completed isolated component screens

Each screen used 12 balanced blocks, two excluded warmups, separate A/B32/B40/C
WASM instances and exact identical-code C. Negative percentages mean less time.
These are sequential native components, not complete extension imports.

| Corpus and phase | SIMD40/A geometric change | SIMD40/C geometric change | Identical C/A |
| --- | ---: | ---: | ---: |
| JMdict inflation | -0.63% | +1.15% | -1.76% |
| JMdict inflation plus CRC | +0.63% | -1.14% | +1.79% |
| Jitendex inflation | -5.50% | -4.65% | -0.89% |
| Jitendex inflation plus CRC | -1.56% | -1.61% | +0.05% |

SIMD40 was faster than both A and C in all 12 Jitendex inflation-only blocks.
The larger combined phase has a smaller and less certain effect. All observations,
including unfavorable blocks and controls, remain in the original JSONL/JSON
reports. `analysis.json` records descriptive paired/bootstrap calculations.

## Incomplete full-parser acquisitions

The full-parser driver uses the exact production groups and options, unchanged
JavaScript wrapper, source CRC checks, native parsing/prepared lookup output, and
complete output/source digests. Copying and digest checks are outside timers.
It was derived from the independently reviewed key-run screen; the exact script
derivation and hashes are retained.

1. The original six-block Jitendex cohort completed its full correctness warmup,
   four measured blocks and five groups of the fifth block, then the shell
   reported `Killed` with exit 137. Last recorded peak RSS was 407,772 KiB.
2. One separately declared follow-up used `--max-old-space-size=128`, with the
   runtime policy saved in its plan. It completed correctness warmup and 18
   groups of the first measured block, then also ended with exit 137. Last
   recorded peak RSS was 380,456 KiB.

Every completed comparison passed. Neither process reached its final report.
The partial raw observations, plans, logs and explicit incomplete-status records
are retained separately. They are not pooled, substituted for a successful
cohort, or treated as qualification. A separate completed Jitendex experiment
peaked at 404,944 KiB, so the RSS does not establish abnormal retention here.
The specific cause of external termination is unresolved; no OOM attribution is
made without counter evidence.

## Prior work

[PR #812](https://github.com/ManabiIO/manabitan/pull/812) implements the same SIMD
history-copy mechanism with a 32-byte stride. Its 252 complete-import study did
not establish a repeatable gain and remains held. SIMD40 is a stride follow-up
to that mechanism, not a novel SIMD design. These local phase observations do not
overrule its full-import result.
