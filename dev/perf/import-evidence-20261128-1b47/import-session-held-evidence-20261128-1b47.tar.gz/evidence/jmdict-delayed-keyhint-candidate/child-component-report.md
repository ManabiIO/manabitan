# Delayed key-hint component cohorts

These are separate native-parser component measurements. They exclude complete browser import, storage, compression, media import, and publication. They must not be pooled with earlier multi-instance cohorts.

## Frozen source and protocol

- Baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
- Candidate: `640e78d7c94d841b14d0b62e08529dcdbfbd60b7`.
- Candidate parser WASM SHA256: `14ba4800e3ac943ed2647a9635609eb2afa58126128f2213c443cfca55c2be2d`, 67,750 bytes.
- Candidate C SHA256: `f8c3f27e7ac5f3a64ee16d0f3d2fa890f3ab366a872b89f09bf580e1e11f872f`.
- Pinned Clang/LLD 21.1.8 native reproducibility check passed; 295 focused tests passed before acquisition.
- Protocol: `one-arm-native-parser-20261128-1b47-v2`, independently reviewed before registration.
- Protocol files and review/freeze records: `../native-child-screen-1b47-v2/`.
- Six fixed balanced orders: ABC, BCA, CAB, ACB, CBA, BAC. Eighteen sequential fresh child processes per corpus, one complete excluded warmup and one measured corpus per child.
- A and C use identical baseline JS and WASM. B uses the same baseline JS with candidate WASM. Full baseline JS, generated library, and installed ZIP-package inventories are checked before/after acquisition.
- No runtime flags. Stop on the first failed child or invariant; no retry/replacement or post-hoc exclusions.

Both cohorts were registered before the first observation. JMdict plan SHA256 is `d23fdbf0f2fae9852cb2df08272febc784170f3639da0f5103a486667440550a`; Jitendex plan SHA256 is `c4234ee9d9edeac56be8216a3ef1f21839533ea608f0264d6cf1f3e9f79245cb`.

## Acquisition and exact work

Both cohorts completed all 18 children. Every warmup and measured pass retained the frozen group count, row count, fused route, exact raw source digest, complete canonical digest, and full output digest. No child failed, no fallback occurred, and no observation was replaced.

| Corpus | Rows per pass | Groups | Baseline/C witnesses | Candidate witnesses | Maximum child RSS |
| --- | ---: | ---: | ---: | ---: | ---: |
| JMdict | 528,299 | 12 | 54,641 | 116,812 | 182,316 KiB |
| Jitendex | 436,555 | 22 | 85,996 | 85,996 | 285,592 KiB |

JMdict's candidate witness count exactly matches the prospectively declared census prediction. Jitendex gains no additional witnesses.

## Fixed primary comparisons

Values below are the median within-block relative changes across six blocks. Negative is faster. These are descriptive component results, with identical-code C/A shown explicitly.

| Corpus / metric | B/A | B/C | C/A control |
| --- | ---: | ---: | ---: |
| JMdict inclusive native component | -4.390% | +2.785% | -7.448% |
| JMdict native parse phase | -7.227% | +2.696% | -6.090% |
| JMdict measured process CPU | -3.864% | +0.582% | -5.317% |
| Jitendex inclusive native component | -5.346% | -8.939% | +1.130% |
| Jitendex native parse phase | -7.868% | -8.933% | +0.312% |
| Jitendex measured process CPU | -5.925% | -10.488% | +0.215% |

JMdict does not establish a worthwhile gain: the apparent A comparison is explained by the same-code control, and B is slower than C.

Jitendex has a favorable descriptive pattern, but it is not an established mechanism gain. Its witness count is unchanged. Unchanged native inflate is -0.342% B/A and -8.863% B/C, so the latter comparison includes substantial phase drift. B is faster in four of six inclusive comparisons against A and five of six against C. All blocks, including large control differences, remain in the result. Architecture review is required before attributing the pattern to the patch.

## Evidence

- `child-jmdict/` and `child-jitendex/`: immutable registration plan; acquisition start/end; each child's raw group observations, warmup/measured summaries, complete report, process exit, host snapshots, and log; cumulative observations; fixed analysis.
- `child-component-attribution.json`: all per-block totals, additional phase ratios, medians, counts, and frozen digest identities.
- `child-jmdict-binding.json` and `child-jitendex-binding.json`: exact pre-registration source/reference bindings.

The parent directed that delayed hint not be remeasured after these complete cohorts. No browser gain or PR qualification is claimed here.
