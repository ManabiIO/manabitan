/* SPDX-License-Identifier: GPL-3.0-or-later */
// Existing production API only. Independent modules/contexts and a same-code
// control; compressed inputs stay resident, one raw block is decoded at a time.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {appendFile, readFile, writeFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {installFileFetch} from './node-sink-file-fetch.mjs';

const [sourcePath, censusPath, independentPath, outputPath] = process.argv.slice(2);
assert(sourcePath && censusPath && independentPath && outputPath,
    'Usage: node compression-level-timing.mjs SOURCE CENSUS INDEPENDENT_DECODE OUTPUT_JSON');
const root = resolve(sourcePath);
const censusBytes = await readFile(censusPath);
const census = JSON.parse(censusBytes);
const independent = JSON.parse(await readFile(independentPath, 'utf8'));
const sha = (value) => createHash('sha256').update(value).digest('hex');
assert.equal(census.complete, true);
assert.equal(independent.complete, true);
assert.equal(independent.censusSha256, sha(censusBytes));
assert.equal(census.sourceCommit, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
assert.equal(census.totals.B.level, -2);
assert.equal(census.totals.B.withinProspectiveTwoPercentCeiling, true);
for (const [file, expectedHash] of Object.entries(census.codecSourceFiles)) {
    assert.equal(sha(await readFile(join(root, file))), expectedHash, file);
}
const frames = [];
for (const frame of census.frames) {
    const encoded = new Uint8Array(await readFile(frame.outputs.A.path));
    assert.equal(sha(encoded), frame.outputs.A.sha256);
    frames.push({metadata: frame, encoded});
}
const dictionary = new Uint8Array(await readFile(join(root, 'ext/lib/zstd-dicts/jmdict.zdict')));
assert.equal(sha(dictionary), census.dictionarySha256);
const jsonLinesPath = `${outputPath}.observations.jsonl`;
await writeFile(jsonLinesPath, '', {flag: 'wx'});
installFileFetch();

// Observe exported memory only during module initialization. Product source and
// compression functions are untouched. Each JS URL creates an independent WASM.
const originalInstantiate = WebAssembly.instantiate;
const originalStreaming = WebAssembly.instantiateStreaming;
let loadingModule = null;
const memories = new Map();
function observeInstance(result) {
    const instance = result instanceof WebAssembly.Instance ? result : result.instance;
    if (loadingModule !== null && instance) {
        const candidates = Object.values(instance.exports).filter((value) => value instanceof WebAssembly.Memory);
        assert.equal(candidates.length, 1, 'Codec must expose exactly one linear memory');
        const previous = memories.get(loadingModule);
        if (previous) { assert.equal(previous, candidates[0]); }
        memories.set(loadingModule, candidates[0]);
    }
    return result;
}
WebAssembly.instantiate = async (...args) => observeInstance(await Reflect.apply(originalInstantiate, WebAssembly, args));
WebAssembly.instantiateStreaming = async (...args) => observeInstance(await Reflect.apply(originalStreaming, WebAssembly, args));
const modules = new Map();
const moduleInitialState = [];
try {
    for (const name of ['A', 'B', 'C', 'decoder']) {
        loadingModule = name;
        const codec = await import(`${pathToFileURL(join(root, 'ext/lib/zstd-wasm.js')).href}?compression-level-probe=${name}`);
        const started = performance.now();
        await codec.init(pathToFileURL(join(root, 'ext/lib/zstd.wasm')).href);
        const initializationMs = performance.now() - started;
        assert(memories.has(name));
        modules.set(name, codec);
        moduleInitialState.push({name, initializationMs, wasmCapacityBytes: memories.get(name).buffer.byteLength});
    }
} finally {
    loadingModule = null;
    WebAssembly.instantiate = originalInstantiate;
    WebAssembly.instantiateStreaming = originalStreaming;
}
assert.equal(new Set(memories.values()).size, 4, 'Each arm and decoder must own separate memory');
const decoder = modules.get('decoder');
const decoderContext = decoder.createDCtx();
const arms = Object.fromEntries(['A', 'B', 'C'].map((name) => [name, {
    name, level: name === 'B' ? -2 : -1, codec: modules.get(name), memory: memories.get(name), context: null,
}]));
const observations = [];
const warmups = [];
const orders = [['A', 'B', 'C'], ['B', 'C', 'A'], ['C', 'A', 'B'],
    ['C', 'B', 'A'], ['B', 'A', 'C'], ['A', 'C', 'B']];
const contextEvents = [];
function createContext(arm, phase, block) {
    assert.equal(arm.context, null);
    const capacityBefore = arm.memory.buffer.byteLength;
    const cpuBefore = process.cpuUsage();
    const before = performance.now();
    arm.context = arm.codec.createCCtx();
    const wallMs = performance.now() - before;
    const cpu = process.cpuUsage(cpuBefore);
    assert(arm.context > 0);
    contextEvents.push({type: 'create', arm: arm.name, phase, block, wallMs,
        cpuMs: (cpu.user + cpu.system) / 1000, capacityBefore, capacityAfter: arm.memory.buffer.byteLength});
}
function freeContext(arm, phase, block) {
    if (arm.context === null) { return; }
    const capacityBefore = arm.memory.buffer.byteLength;
    const cpuBefore = process.cpuUsage();
    const before = performance.now();
    arm.codec.freeCCtx(arm.context);
    const wallMs = performance.now() - before;
    const cpu = process.cpuUsage(cpuBefore);
    arm.context = null;
    contextEvents.push({type: 'free', arm: arm.name, phase, block, wallMs,
        cpuMs: (cpu.user + cpu.system) / 1000, capacityBefore, capacityAfter: arm.memory.buffer.byteLength});
}
async function observe(arm, phase, block, orderIndex, excluded = false) {
    assert(arm.context > 0);
    const started = performance.now();
    const observationCpu = process.cpuUsage();
    const measurements = [];
    let compressionWallMs = 0;
    let compressionCpuUserMs = 0;
    let compressionCpuSystemMs = 0;
    let totalEncodedBytes = 0;
    let maxWasmCapacityBytes = arm.memory.buffer.byteLength;
    for (const {metadata, encoded} of frames) {
        const raw = decoder.decompressUsingDict(decoderContext, encoded.subarray(12), dictionary,
            {defaultHeapSize: metadata.expectedRawBytes, maxOutputSize: metadata.expectedRawBytes});
        assert.equal(raw.byteLength, metadata.expectedRawBytes);
        assert.equal(sha(raw), metadata.rawSha256);
        const capacityBefore = arm.memory.buffer.byteLength;
        const cpuBefore = process.cpuUsage();
        const before = performance.now();
        const output = arm.codec.compressUsingDictWithPrefix(arm.context, raw, dictionary, 12, arm.level, true);
        const wallMs = performance.now() - before;
        const cpu = process.cpuUsage(cpuBefore);
        const expectedOutput = metadata.outputs[arm.level === -2 ? 'B' : 'A'];
        assert.equal(output.byteLength, expectedOutput.bytes);
        assert.equal(sha(output), expectedOutput.sha256);
        const capacityAfter = arm.memory.buffer.byteLength;
        const userMs = cpu.user / 1000;
        const systemMs = cpu.system / 1000;
        compressionWallMs += wallMs;
        compressionCpuUserMs += userMs;
        compressionCpuSystemMs += systemMs;
        totalEncodedBytes += output.byteLength;
        maxWasmCapacityBytes = Math.max(maxWasmCapacityBytes, capacityAfter);
        measurements.push({frame: metadata.index, wallMs, cpuUserMs: userMs, cpuSystemMs: systemMs,
            outputBytes: output.byteLength, capacityBefore, capacityAfter});
    }
    const wholeCpu = process.cpuUsage(observationCpu);
    const result = {phase, block, orderIndex, arm: arm.name, level: arm.level, excluded,
        compressionWallMs, compressionCpuUserMs, compressionCpuSystemMs,
        compressionCpuMs: compressionCpuUserMs + compressionCpuSystemMs,
        completeObservationWallMs: performance.now() - started,
        completeObservationCpuMs: (wholeCpu.user + wholeCpu.system) / 1000,
        totalEncodedBytes, maxWasmCapacityBytes, measurements};
    assert.equal(totalEncodedBytes, census.totals[arm.level === -2 ? 'B' : 'A'].primaryBytes);
    if (excluded) { warmups.push(result); } else { observations.push(result); }
    await appendFile(jsonLinesPath, `${JSON.stringify(result)}\n`);
    return result;
}
const median = (values) => {
    const sorted = [...values].sort((a, b) => a - b);
    const middle = Math.floor(sorted.length / 2);
    return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
};
const geometric = (ratios) => 100 * (Math.exp(ratios.reduce((sum, ratio) => sum + Math.log(ratio), 0) / ratios.length) - 1);
function summarize(phase) {
    const rows = observations.filter((row) => row.phase === phase);
    const byArm = Object.fromEntries(['A', 'B', 'C'].map((name) => {
        const armRows = rows.filter((row) => row.arm === name);
        return [name, {observations: armRows.length,
            medianCompressionWallMs: median(armRows.map((row) => row.compressionWallMs)),
            medianCompressionCpuMs: median(armRows.map((row) => row.compressionCpuMs)),
            maxWasmCapacityBytes: Math.max(...armRows.map((row) => row.maxWasmCapacityBytes))}];
    }));
    const comparisons = {};
    for (const [candidate, control] of [['B', 'A'], ['B', 'C'], ['C', 'A']]) {
        const left = rows.filter((row) => row.arm === candidate);
        const right = rows.filter((row) => row.arm === control);
        assert.equal(left.length, right.length);
        const metrics = {};
        for (const metric of ['compressionWallMs', 'compressionCpuMs']) {
            const ratios = left.map((row, index) => row[metric] / right[index][metric]);
            metrics[metric] = {medianPairedChangePercent: median(ratios.map((ratio) => 100 * (ratio - 1))),
                geometricMeanPairedChangePercent: geometric(ratios),
                equalWorkChangePercent: 100 * (left.reduce((sum, row) => sum + row[metric], 0) / right.reduce((sum, row) => sum + row[metric], 0) - 1),
                medianAbsoluteSavedMs: median(left.map((row, index) => right[index][metric] - row[metric])),
                faster: ratios.filter((ratio) => ratio < 1).length, pairs: ratios.length, ratios};
        }
        comparisons[`${candidate}/${control}`] = metrics;
    }
    return {byArm, comparisons};
}
let complete = false;
let failure = null;
try {
    // One first corpus per genuinely cold module/context. Descriptive only:
    // first allocation/growth may differ from the steady-state worker path.
    for (const [index, name] of ['A', 'B', 'C'].entries()) {
        createContext(arms[name], 'cold-module', 0);
        await observe(arms[name], 'cold-module', 0, index);
        freeContext(arms[name], 'cold-module', 0);
    }
    // Every balanced block gets a fresh CCtx; module memory is already resident.
    for (let block = 0; block < orders.length; ++block) {
        for (const [index, name] of orders[block].entries()) {
            createContext(arms[name], 'fresh-context', block);
            await observe(arms[name], 'fresh-context', block, index);
            freeContext(arms[name], 'fresh-context', block);
        }
        process.stdout.write(`fresh-context block ${block + 1}/${orders.length} complete\n`);
    }
    for (const name of ['A', 'B', 'C']) { createContext(arms[name], 'retained-context', -1); }
    for (const [block, order] of [['A', 'B', 'C'], ['C', 'B', 'A']].entries()) {
        for (const [index, name] of order.entries()) { await observe(arms[name], 'warmup', block, index, true); }
    }
    for (let block = 0; block < 12; ++block) {
        for (const [index, name] of orders[block % orders.length].entries()) {
            await observe(arms[name], 'retained-context', block, index);
        }
        process.stdout.write(`retained-context block ${block + 1}/12 complete\n`);
    }
    complete = true;
} catch (error) {
    failure = error.stack ?? String(error);
    process.stderr.write(`${failure}\n`);
    process.exitCode = 1;
} finally {
    for (const arm of Object.values(arms)) { freeContext(arm, 'cleanup', -1); }
    decoder.freeDCtx(decoderContext);
    const sourceAfter = {};
    for (const [file, expectedHash] of Object.entries(census.codecSourceFiles)) {
        sourceAfter[file] = sha(await readFile(join(root, file)));
        assert.equal(sourceAfter[file], expectedHash, file);
    }
    const report = {complete, failure, dictionary: census.dictionary,
        sourceCommit: census.sourceCommit, codecSourceFiles: census.codecSourceFiles, codecSourceFilesAfter: sourceAfter,
        censusPath: resolve(censusPath), censusSha256: sha(censusBytes), independentDecodePath: resolve(independentPath),
        scope: 'Sequential existing production compressUsingDictWithPrefix API on all captured real 1MiB frames. Includes input/dictionary copy, native compression, envelope and owned output copy. Excludes span gather, worker scheduling, source parser, storage, UI and publication. No complete-import claim.',
        timingScope: 'Wall/CPU sums cover only each compression API call. CPU includes adjacent timer reads; whole-observation values additionally include independent decode, SHA256 checks and loop work. All raw calls and outliers retained.',
        memoryScope: 'Per-arm exported WASM memory capacity at every compression boundary, including growth. This is allocated module capacity, not exact live CCtx malloc size or browser/process peak memory.',
        contextScope: 'Three independent source-identical JS/WASM module instances and contexts; A/C level -1 identical-code controls, B level -2. A separate fourth module decodes outside the compression timers.',
        node: process.version, versions: process.versions,
        frameCount: frames.length, rawBytes: census.rawBytes, baselinePrimaryBytes: census.baselinePrimaryBytes,
        sizeTradeoff: census.totals.B, moduleInitialState, contextEvents, orders,
        summaries: complete ? Object.fromEntries(['cold-module', 'fresh-context', 'retained-context'].map((phase) => [phase, summarize(phase)])) : null,
        observations, excludedWarmups: warmups, jsonLinesPath: resolve(jsonLinesPath)};
    await writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'});
    process.stdout.write(`${JSON.stringify({complete, failure, dictionary: census.dictionary, summaries: report.summaries})}\n`);
}
