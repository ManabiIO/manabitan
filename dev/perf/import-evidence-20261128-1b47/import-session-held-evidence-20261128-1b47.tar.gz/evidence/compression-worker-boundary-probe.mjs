/* SPDX-License-Identifier: GPL-3.0-or-later */
// The existing packed-dispatch real-worker workload, with exact bounded byte
// comparisons instead of a framework rendering million-element array values.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, realpath, writeFile} from 'node:fs/promises';
import {resolve, join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {Worker} from 'node:worker_threads';
import {installFileFetch} from './node-sink-file-fetch.mjs';

const [sourcePath, outputPath] = process.argv.slice(2);
assert(sourcePath && outputPath, 'Usage: node compression-worker-boundary-probe.mjs SOURCE REPORT');
const root = resolve(sourcePath);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const runtimePath = join(root, 'ext/js/dictionary/zstd-term-content.js');
const source = await readFile(runtimePath, 'utf8');
const runtime = {path: runtimePath, realpath: await realpath(runtimePath), sha256: sha(source),
    level: Number(source.match(/const JMDICT_COMPRESSION_LEVEL = (-?\d+)/)?.[1])};
assert([-1, -2].includes(runtime.level));
const libraryFiles = {};
for (const name of ['ext/lib/zstd-wasm.js', 'ext/lib/zstd.wasm', 'ext/lib/zstd-dicts/jmdict.zdict']) {
    const path = join(root, name);
    libraryFiles[name] = {realpath: await realpath(path), sha256: sha(await readFile(path))};
}
globalThis.Worker = undefined;
installFileFetch();
const api = await import(pathToFileURL(runtimePath));
await api.initializeTermContentZstd();
const moduleUrl = pathToFileURL(join(root, 'ext/js/dictionary/zstd-term-content-compression-worker.js')).href;
const bridge = `
    import {parentPort, workerData} from 'node:worker_threads';
    import {readFile, realpath} from 'node:fs/promises';
    import {createHash} from 'node:crypto';
    const runtimeUrl = new URL('./zstd-term-content.js', workerData.moduleUrl);
    const source = await readFile(runtimeUrl, 'utf8');
    const identity = {path: runtimeUrl.href, realpath: await realpath(runtimeUrl),
        sha256: createHash('sha256').update(source).digest('hex'),
        level: Number(source.match(/const JMDICT_COMPRESSION_LEVEL = (-?\\d+)/)?.[1])};
    const log = (value) => console.log(JSON.stringify({worker: workerData.index, ...value}));
    globalThis.self = {
        addEventListener(type, listener) {
            if (type === 'message') parentPort.on('message', (data) => {
                log({event: 'request', id: data.id, dictName: data.dictName ?? null,
                    contentBytes: data.content?.byteLength, wrap: data.wrap});
                return listener({data});
            });
        },
        postMessage(message, transfer = []) {
            log({event: 'response', type: message.type, id: message.id,
                compressedBytes: message.compressed?.byteLength, error: message.error});
            parentPort.postMessage(message.type === 'ready' ? {...message, probeIdentity: identity} : message, transfer);
        },
    };
    globalThis.fetch = async (input) => new Response(await readFile(new URL(String(input))), {headers: {'Content-Type': 'application/wasm'}});
    await import(workerData.moduleUrl);
`;
const workerIdentities = [];
const workerLogs = [];
const workerErrors = [];
const nativeWorkers = Array.from({length: 3}, (_, index) => new Worker(
    new URL(`data:text/javascript,${encodeURIComponent(bridge)}`),
    {workerData: {moduleUrl, index}, stdout: true, stderr: true},
));
for (const [index, worker] of nativeWorkers.entries()) {
    worker.stdout.on('data', (data) => { workerLogs.push({worker: index, stream: 'stdout', text: String(data)}); });
    worker.stderr.on('data', (data) => { workerLogs.push({worker: index, stream: 'stderr', text: String(data)}); });
    worker.on('error', (error) => { workerErrors.push({worker: index, error: error.stack ?? String(error)}); });
}
const blocks = [];
let pool = null;
let complete = false;
let failure = null;
let deadline;
const timeout = new Promise((_, reject) => { deadline = setTimeout(() => reject(new Error('Worker workload exceeded 10-second diagnostic deadline')), 10000); });
void timeout.catch(() => {});
try {
    await Promise.race([timeout, Promise.all(nativeWorkers.map((worker, index) => new Promise((resolveReady, reject) => {
        worker.once('error', reject);
        worker.once('message', (message) => {
            try {
                assert.equal(message.type, 'ready', JSON.stringify(message));
                assert.equal(message.probeIdentity.sha256, runtime.sha256);
                assert.equal(message.probeIdentity.level, runtime.level);
                workerIdentities.push({worker: index, ...message.probeIdentity});
                resolveReady();
            } catch (error) { reject(error); }
        });
    })))]);
    const workers = nativeWorkers.map((worker) => ({
        addEventListener(type, listener) { worker.on(type, (data) => listener(type === 'message' ? {data} : data)); },
        postMessage(message, transfer) { worker.postMessage(message, transfer); },
        terminate() { void worker.terminate(); },
    }));
    pool = new api.TermContentCompressionPool(workers);
    for (const dictName of [null, 'jmdict']) {
        const lengths = Uint32Array.of(1, 1023, 1024, 65_537, 1_048_585, 11);
        const sourceBlocks = Array.from(lengths, (length, block) => Uint8Array.from({length}, (_, index) => (index * 131 + block + (index >>> 7)) & 255));
        const options = {experimentalGenericSpanCompression: true};
        const expected = sourceBlocks.map((content) => api.compressWrappedTermContentZstd(content, dictName, options).bytes);
        const result = await Promise.race([timeout, pool.compressWrappedBlocks(lengths, (index) => Uint8Array.from(sourceBlocks[index]), dictName, options)]);
        assert.equal(result.wrapped, true);
        for (let index = 0; index < expected.length; ++index) {
            const actual = result.chunks[index];
            const decoded = api.decompressTermContentZstd(actual.subarray(12), dictName);
            const row = {dictName, index, sourceBytes: sourceBlocks[index].byteLength,
                sourceSha256: sha(sourceBlocks[index]), rawSha256: sha(decoded),
                actualBytes: actual.byteLength, expectedBytes: expected[index].byteLength,
                actualSha256: sha(actual), expectedSha256: sha(expected[index])};
            blocks.push(row);
            assert.equal(Buffer.compare(Buffer.from(actual), Buffer.from(expected[index])), 0, JSON.stringify(row));
            assert.equal(Buffer.compare(Buffer.from(decoded), Buffer.from(sourceBlocks[index])), 0, JSON.stringify(row));
        }
        await Promise.race([timeout, pool.compressWrappedBlocks(Uint32Array.of(4, 4), () => Uint8Array.of(9, 8, 7, 6), dictName, options)]);
        for (let index = 0; index < expected.length; ++index) {
            assert.equal(Buffer.compare(Buffer.from(result.chunks[index]), Buffer.from(expected[index])), 0, 'Returned owned output changed after later compression');
        }
    }
    complete = true;
} catch (error) {
    failure = error.stack ?? String(error);
    process.stderr.write(`${failure}\n`);
    process.exitCode = 1;
} finally {
    clearTimeout(deadline);
    pool?.close();
    await Promise.all(nativeWorkers.map((worker) => worker.terminate()));
    const report = {complete, failure, runtime, libraryFiles, workerIdentities, workerErrors, workerLogs, blocks,
        processResourceUsage: process.resourceUsage(), processMemoryUsage: process.memoryUsage(),
        node: process.version, scope: 'Diagnostic reproduction of the existing packed-dispatch real three-worker test, with unchanged production source and exact bounded byte comparisons. Does not replace the original Vitest or hosted full-unit gate.'};
    await writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'});
    process.stdout.write(`${JSON.stringify({complete, failure, level: runtime.level, blocks: blocks.length, workers: workerIdentities.length, outputPath})}\n`);
}
