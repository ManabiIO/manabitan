/* SPDX-License-Identifier: GPL-3.0-or-later */
// Register before acquisition. Exactly one child runs at a time; never retry.
import assert from 'node:assert/strict';
import {readFile, writeFile, mkdir, open} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {spawn} from 'node:child_process';
import {cpus, totalmem, freemem, loadavg} from 'node:os';
import {PROTOCOL, BASELINE, ORDERS, PARSER, WASM, LOCK, sha, directory,
    scriptHashes, identity, requireIdentity, loadReferences, summarize} from './protocol.mjs';

const [mode, inputPath] = process.argv.slice(2);
assert(['register', 'run'].includes(mode) && inputPath,
    'Usage: node controller.mjs register binding.json | run plan.json');
assert.deepEqual(process.execArgv, [], 'This protocol uses no Node runtime flags');
assert.equal(process.env.NODE_OPTIONS ?? null, null, 'NODE_OPTIONS must be unset for this protocol');

async function writeJson(path, value, exclusive = true) {
    await writeFile(path, JSON.stringify(value, null, 2) + '\n', exclusive ? {flag: 'wx'} : undefined);
}

async function host() {
    return {utc: new Date().toISOString(), nodeVersion: process.version,
        execArgv: process.execArgv, nodeOptions: process.env.NODE_OPTIONS ?? null,
        cpuModel: cpus()[0]?.model, logicalCpus: cpus().length,
        totalMemoryBytes: totalmem(), freeMemoryBytes: freemem(), loadAverage: loadavg(),
        procMeminfo: await readFile('/proc/meminfo', 'utf8').catch(() => null)};
}

if (mode === 'register') {
    const bindingBytes = await readFile(inputPath);
    const binding = JSON.parse(bindingBytes);
    const keys = ['baselinePath', 'candidatePath', 'candidateCommit', 'candidateWasmSha256',
        'cachePath', 'dictionary', 'sinkReferencePath', 'outputReferencePath', 'outputDirectory'];
    assert.deepEqual(Object.keys(binding).sort(), keys.sort(), 'Unexpected binding fields');
    assert(/^[a-f0-9]{40}$/.test(binding.candidateCommit));
    assert(/^[a-f0-9]{64}$/.test(binding.candidateWasmSha256));
    for (const key of ['baselinePath', 'candidatePath', 'cachePath', 'sinkReferencePath', 'outputReferencePath', 'outputDirectory']) {
        binding[key] = resolve(binding[key]);
    }
    const A = await identity(binding.baselinePath);
    const B = await identity(binding.candidatePath);
    assert.equal(A.commit, BASELINE);
    assert.equal(B.commit, binding.candidateCommit);
    assert.equal(B.hashes[WASM], binding.candidateWasmSha256);
    assert.notEqual(A.hashes[WASM], B.hashes[WASM], 'A native candidate must change native bytes');
    for (const path of [PARSER, LOCK, 'package-lock.json', 'ext/js/dictionary/wasm/term-bank-inflate.c']) {
        assert.equal(A.hashes[path], B.hashes[path], 'Unexpected changed source: ' + path);
    }
    const reference = await loadReferences(binding);
    assert.equal(A.hashes[PARSER], reference.parserSourceSha256);
    assert.equal(A.hashes[WASM], reference.parserWasmSha256);
    assert.equal(A.hashes[LOCK], reference.lockSha256);
    const fixture = JSON.parse(await readFile(join(A.root, LOCK))).dictionaries[binding.dictionary];
    assert.deepEqual(fixture, reference.fixture);
    const schedule = ORDERS.flatMap((order, block) => [...order].map((arm, position) => ({
        id: `block-${String(block + 1).padStart(2, '0')}-${arm}`, block, position, arm,
    })));
    const plan = {protocol: PROTOCOL, ...binding, bindingSha256: sha(bindingBytes),
        identities: {A, B}, reference, referenceHashes: reference.referenceHashes,
        scriptHashes: await scriptHashes(), nodeVersion: process.version, nodeOptions: null,
        schedule, measuredBlocks: 6, orders: ORDERS, childTimeoutMs: 180000,
        acquisition: '18 sequential fresh children. Each has one production WASM module, '
            + 'one complete excluded warmup and one complete measured corpus. A and C use identical baseline source.',
        scope: 'Native-parser component only. Per-group timers/process CPU cover native inflate/source CRC '
            + 'through column parsing/prepared lookup plans. Source I/O, result copies, byte hashing, module setup, '
            + 'and the full warmup are excluded. No workers, database/storage, compression sink, media import, '
            + 'publication, or whole-import claim. Every source and complete output digest matches the frozen baseline. '
            + 'Native parseBankMs may include deferred crcMs; overlapping fields must not be summed.',
        failurePolicy: 'Stop on the first failed child or failed invariant. Preserve every partial file. '
            + 'No retries, replacements, post-hoc observation exclusions, or pooling with earlier protocols.',
        registrationHost: await host()};
    await mkdir(binding.outputDirectory, {recursive: false});
    await writeJson(join(binding.outputDirectory, 'plan.json'), plan);
    process.stdout.write(JSON.stringify({registered: true, observationsAcquired: 0,
        planPath: join(binding.outputDirectory, 'plan.json'), planSha256: sha(JSON.stringify(plan, null, 2) + '\n')}) + '\n');
} else {
    const planPath = resolve(inputPath);
    const planBytes = await readFile(planPath);
    const plan = JSON.parse(planBytes);
    assert.equal(plan.protocol, PROTOCOL);
    assert.equal(plan.nodeVersion, process.version);
    assert.equal(plan.nodeOptions, null);
    assert.deepEqual(plan.orders, ORDERS);
    assert.equal(plan.measuredBlocks, 6);
    assert.equal(plan.childTimeoutMs, 180000);
    assert.deepEqual(plan.schedule, ORDERS.flatMap((order, block) => [...order].map((arm, position) => ({
        id: `block-${String(block + 1).padStart(2, '0')}-${arm}`, block, position, arm,
    }))));
    assert.deepEqual(await scriptHashes(), plan.scriptHashes);
    await requireIdentity(plan.identities.A);
    await requireIdentity(plan.identities.B);
    assert.deepEqual(await loadReferences(plan), plan.reference);
    const output = resolve(plan.outputDirectory);
    assert.equal(planPath, join(output, 'plan.json'));
    await writeJson(join(output, 'acquisition-start.json'), {planSha256: sha(planBytes), host: await host()});
    const observations = [];
    let failure = null;
    try {
        for (const item of plan.schedule) {
            assert.equal(sha(await readFile(planPath)), sha(planBytes), 'Plan changed during acquisition');
            assert.deepEqual(await scriptHashes(), plan.scriptHashes);
            const childOutput = join(output, item.id);
            await mkdir(childOutput, {recursive: false});
            await writeJson(join(childOutput, 'host-before.json'), await host());
            const log = await open(join(childOutput, 'child.log'), 'wx');
            let outcome;
            const start = performance.now();
            try {
                outcome = await new Promise((resolveOutcome) => {
                    const child = spawn(process.execPath, [join(directory, 'child.mjs'), planPath, item.id, childOutput], {
                        cwd: plan.identities.A.root, env: process.env, stdio: ['ignore', log.fd, log.fd],
                    });
                    let timedOut = false;
                    const timer = setTimeout(() => { timedOut = true; child.kill('SIGKILL'); }, plan.childTimeoutMs);
                    child.once('error', (error) => {
                        clearTimeout(timer);
                        resolveOutcome({exitCode: null, signal: null, timedOut, spawnError: error.stack ?? String(error)});
                    });
                    child.once('close', (exitCode, signal) => {
                        clearTimeout(timer);
                        resolveOutcome({exitCode, signal, timedOut, spawnError: null});
                    });
                });
            } finally {
                await log.close();
            }
            outcome.childWallMsIncludingSetupWarmupIoAndVerification = performance.now() - start;
            await writeJson(join(childOutput, 'child-exit.json'), outcome);
            await writeJson(join(childOutput, 'host-after.json'), await host());
            assert.equal(outcome.spawnError, null, 'Failed to spawn child');
            assert.equal(outcome.timedOut, false, 'Child exceeded the declared timeout');
            assert.equal(outcome.signal, null, 'Child terminated by a signal');
            assert.equal(outcome.exitCode, 0, 'Child exited unsuccessfully');
            const reportBytes = await readFile(join(childOutput, 'report.json'));
            const report = JSON.parse(reportBytes);
            assert.equal(report.complete, true, report.failure);
            assert.equal(report.protocol, PROTOCOL);
            assert.equal(report.planSha256, sha(planBytes));
            assert.deepEqual(report.observation, item);
            assert.deepEqual(report.identity, plan.identities[item.arm === 'B' ? 'B' : 'A']);
            assert.deepEqual(report.scriptHashes, plan.scriptHashes);
            assert.equal(report.nodeVersion, plan.nodeVersion);
            assert.deepEqual(report.execArgv, []);
            assert.equal(report.nodeOptions, null);
            assert.deepEqual(report.passes.map(({kind}) => kind), ['excluded-warmup', 'measured']);
            for (const pass of report.passes) {
                assert.deepEqual(pass.digests, plan.reference.expectedDigests);
                assert.equal(pass.totals.rows, plan.reference.fixture.termRows);
                assert.equal(pass.totals.counts.fusedParseFallbacks, 0);
                assert.equal(pass.totals.counts.fusedParseAttempts, plan.reference.sourceGroups.length);
            }
            const measured = report.passes[1];
            const recorded = {...item, totals: measured.totals, peakRssKiB: report.peakRssKiB,
                wholeChildCpuMsIncludingSetupWarmupIoAndVerification: report.wholeChildCpuMsIncludingSetupWarmupIoAndVerification,
                reportSha256: sha(reportBytes), reportPath: join(childOutput, 'report.json'), outcome};
            observations.push(recorded);
            await writeJson(join(output, 'observations.json'), observations, false);
            process.stdout.write(JSON.stringify({id: item.id, complete: true, measuredNativeMs: recorded.totals.elapsedMs,
                phaseCpuMs: recorded.totals.cpuTotalMs, peakRssKiB: recorded.peakRssKiB}) + '\n');
        }
        await requireIdentity(plan.identities.A);
        await requireIdentity(plan.identities.B);
        assert.deepEqual(await scriptHashes(), plan.scriptHashes);
        const analysis = {complete: true, protocol: PROTOCOL, planSha256: sha(planBytes),
            scope: plan.scope, observations: observations.length, comparisons: summarize(observations),
            note: 'A descriptive component comparison only. Never pool with multi-instance cohorts or interpret as whole-import performance.'};
        await writeJson(join(output, 'analysis.json'), analysis);
        process.stdout.write('SUMMARY ' + JSON.stringify(analysis) + '\n');
    } catch (error) {
        failure = error.stack ?? String(error);
        process.exitCode = 1;
        await writeJson(join(output, 'acquisition-failure.json'), {complete: false, protocol: PROTOCOL,
            planSha256: sha(planBytes), completedChildren: observations.length,
            failedObservation: plan.schedule[observations.length], failure, retry: false, host: await host()});
        process.stderr.write(failure + '\n');
    } finally {
        await writeJson(join(output, 'acquisition-end.json'), {complete: failure === null,
            completedChildren: observations.length, failure, host: await host()});
    }
}
