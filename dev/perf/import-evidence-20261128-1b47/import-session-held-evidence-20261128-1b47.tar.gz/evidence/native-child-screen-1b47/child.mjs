/* SPDX-License-Identifier: GPL-3.0-or-later */
// One production WASM module, one complete excluded warmup, one measured corpus.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream, openAsBlob} from 'node:fs';
import {readFile, writeFile, appendFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
import {PROTOCOL, PARSER, WASM, LOCK, sha, scriptHashes, requireIdentity, loadReferences,
    hashCanonical, hashValue, totals} from './protocol.mjs';

const [planPath, observationId, outputPath] = process.argv.slice(2);
assert(planPath && observationId && outputPath);
const output = resolve(outputPath);
const planBytes = await readFile(planPath);
const plan = JSON.parse(planBytes);
assert.equal(plan.protocol, PROTOCOL);
assert.equal(process.version, plan.nodeVersion);
assert.deepEqual(process.execArgv, []);
assert.equal(process.env.NODE_OPTIONS ?? null, plan.nodeOptions);
assert.deepEqual(await scriptHashes(), plan.scriptHashes);
const observation = plan.schedule.find(({id}) => id === observationId);
assert(observation);
const frozen = plan.identities[observation.arm === 'B' ? 'B' : 'A'];
await requireIdentity(frozen);
const reference = await loadReferences(plan);
assert.deepEqual(reference, plan.reference);
const fixture = JSON.parse(await readFile(join(frozen.root, LOCK))).dictionaries[plan.dictionary];
assert.deepEqual(fixture, reference.fixture);
const parser = await import(pathToFileURL(join(plan.identities.A.root, PARSER)));
const wasm = await readFile(join(frozen.root, WASM));
assert.equal(sha(wasm), frozen.hashes[WASM]);
parser.setTermBankWasmModule(await WebAssembly.compile(wasm));
const archivePath = join(plan.cachePath, fixture.cacheFile);
const archiveDigest = createHash('sha256');
for await (const bytes of createReadStream(archivePath)) { archiveDigest.update(bytes); }
assert.equal(archiveDigest.digest('hex'), fixture.sha256);
const archive = await openAsBlob(archivePath);
assert.equal(archive.size, fixture.sizeBytes);
const {readDenseZipDirectory} = await import(pathToFileURL(join(plan.identities.A.root, 'ext/js/dictionary/dense-zip-directory.js')));
const {RawZipPayloadReader} = await import(pathToFileURL(join(plan.identities.A.root, 'ext/js/dictionary/term-bank-source-pipeline.js')));
let entries = await readDenseZipDirectory(archive);
let zipReader = null;
if (entries === null) {
    const require = createRequire(join(plan.identities.A.root, 'package.json'));
    const {BlobReader, ZipReader} = require('@zip.js/zip.js');
    zipReader = new ZipReader(new BlobReader(archive));
    entries = await zipReader.getEntries();
}
const byName = new Map(entries.map((entry) => [entry.filename, entry]));
const reader = new RawZipPayloadReader(archive);
const signal = new AbortController().signal;
const options = reference.options;
const passes = [];
let complete = false;
let failure = null;
await writeFile(join(output, 'groups.jsonl'), '', {flag: 'wx'});

async function parse(sources) {
    const chunks = [];
    const cpuStart = process.cpuUsage();
    const start = performance.now();
    const preloaded = await parser.inflateCompressedTermBankSourcesWasm(sources, options, true);
    const inflatedAt = performance.now();
    await parser.parseTermBankWithWasmColumnChunks(new Uint8Array(), 3, (chunk) => { chunks.push(chunk); }, 2048,
        {...options, preloadedSource: preloaded});
    const end = performance.now();
    const cpu = process.cpuUsage(cpuStart);
    const profile = parser.consumeLastTermBankWasmParseProfile();
    assert.equal(chunks.length, 1);
    assert.equal(profile.fusedParseAttempts, 1);
    assert.equal(profile.fusedParseFallbacks, 0, 'Frozen real corpus must retain its fused route');
    if (preloaded.crcSignaturesPtr) { assert.equal(preloaded.crcVerified, true); }
    const measurement = {elapsedMs: end - start, inflateWallMs: inflatedAt - start, parseWallMs: end - inflatedAt,
        cpuUserMs: cpu.user / 1000, cpuSystemMs: cpu.system / 1000, cpuTotalMs: (cpu.user + cpu.system) / 1000,
        inflateMs: preloaded.inflateMs, crcMs: preloaded.crcMs ?? 0,
        sourceCrcDeferred: Boolean(preloaded.crcSignaturesPtr), crcScannedBytes: preloaded.crcScannedBytes ?? 0,
        crcReusedBytes: preloaded.crcReusedBytes ?? 0, crcReusedGlossaryCount: preloaded.crcReusedGlossaryCount ?? 0,
        wasmHeapBytes: preloaded.wasm.memory.buffer.byteLength, profile};
    const raw = new Uint8Array(preloaded.wasm.memory.buffer, preloaded.jsonPtr, preloaded.jsonLength);
    const stable = parser.copyWasmBackedColumnChunk(chunks[0], true, false, true, preloaded);
    delete stable.preparedLookupIndexEncodeMs;
    return {measurement, raw, stable};
}

try {
    for (const kind of ['excluded-warmup', 'measured']) {
        const canonical = createHash('sha256');
        const raw = createHash('sha256');
        const outputDigest = createHash('sha256');
        const groups = [];
        const diagnosticWallStart = performance.now();
        for (const [index, group] of reference.sourceGroups.entries()) {
            const sources = await Promise.all(group.files.map(async (filename) => {
                const entry = byName.get(filename); assert(entry);
                return {bytes: await reader.read(entry, signal), compressionMethod: entry.compressionMethod,
                    compressedSize: entry.compressedSize, uncompressedSize: entry.uncompressedSize,
                    signature: entry.signature, filename};
            }));
            assert.deepEqual(sources.map(({bytes}) => bytes.byteLength), group.compressedBytes);
            const parsed = await parse(sources);
            assert.equal(parsed.stable.rowCount, group.rows);
            assert.equal(parsed.raw.byteLength, group.rawBytes);
            assert.equal(sha(parsed.raw), group.expected.raw, 'Inflated source differs from frozen baseline');
            const groupHash = createHash('sha256');
            hashValue(groupHash, parsed.stable, 'group-' + index);
            assert.equal(groupHash.digest('hex'), group.expected.output, 'Complete output differs from frozen baseline');
            hashCanonical(canonical, parsed.stable);
            raw.update(parsed.raw);
            hashValue(outputDigest, parsed.stable, 'group-' + index);
            const record = {kind, index, files: group.files, rows: group.rows, measurement: parsed.measurement};
            groups.push(record);
            await appendFile(join(output, 'groups.jsonl'), JSON.stringify(record) + '\n');
        }
        const digests = {canonical: canonical.digest('hex'), raw: raw.digest('hex'), output: outputDigest.digest('hex')};
        assert.deepEqual(digests, reference.expectedDigests, 'Full corpus differs from frozen baseline');
        const summary = totals(groups);
        assert.equal(summary.rows, fixture.termRows);
        passes.push({kind, digests, totals: summary, diagnosticCorpusWallMs: performance.now() - diagnosticWallStart});
        await writeFile(join(output, kind + '.json'), JSON.stringify(passes.at(-1), null, 2) + '\n', {flag: 'wx'});
    }
    await requireIdentity(frozen);
    await requireIdentity(plan.identities.A);
    assert.deepEqual(await scriptHashes(), plan.scriptHashes);
    complete = true;
} catch (error) {
    failure = error.stack ?? String(error);
    process.exitCode = 1;
} finally {
    if (zipReader !== null) { await zipReader.close(); }
    const cpu = process.cpuUsage();
    const report = {complete, failure, protocol: PROTOCOL, planSha256: sha(planBytes), observation,
        nodeVersion: process.version, execArgv: process.execArgv, nodeOptions: process.env.NODE_OPTIONS ?? null,
        identity: frozen, scriptHashes: plan.scriptHashes, passes,
        peakRssKiB: process.resourceUsage().maxRSS, endRssBytes: process.memoryUsage().rss,
        wholeChildCpuMsIncludingSetupWarmupIoAndVerification: (cpu.user + cpu.system) / 1000,
        scope: plan.scope};
    await writeFile(join(output, 'report.json'), JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
    process.stdout.write(JSON.stringify({complete, failure, observation, peakRssKiB: report.peakRssKiB}) + '\n');
}
