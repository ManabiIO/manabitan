/* SPDX-License-Identifier: GPL-3.0-or-later */
// Separate native-component protocol. No data are pooled with multi-instance runs.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';

export const PROTOCOL = 'one-arm-native-parser-20261128-1b47-v1';
export const BASELINE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2';
export const ORDERS = ['ABC', 'BCA', 'CAB', 'ACB', 'CBA', 'BAC'];
export const PARSER = 'ext/js/dictionary/term-bank-wasm-parser.js';
export const WASM = 'dev/data/dictionary-wasm/term-bank-parser.wasm';
export const MANIFEST = 'dev/data/dictionary-wasm/manifest.json';
export const LOCK = 'test/perf/dictionaries.lock.json';
export const FILES = [PARSER, WASM, MANIFEST, LOCK, 'package-lock.json',
    'ext/js/dictionary/wasm/term-bank-parser.c', 'ext/js/dictionary/wasm/term-bank-inflate.c'];
export const SCRIPTS = ['protocol.mjs', 'child.mjs', 'controller.mjs'];
export const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
export const git = (root, ...args) => execFileSync('git', args, {cwd: root, encoding: 'utf8'}).trim();
export const directory = fileURLToPath(new URL('.', import.meta.url));

export async function scriptHashes() {
    return Object.fromEntries(await Promise.all(SCRIPTS.map(async (name) => [name, sha(await readFile(join(directory, name)))])));
}

export async function identity(root) {
    root = resolve(root);
    assert.equal(git(root, 'diff', 'HEAD', '--', ...FILES), '', 'Tracked runtime files must be clean');
    const bytes = await Promise.all(FILES.map((name) => readFile(join(root, name))));
    const hashes = Object.fromEntries(FILES.map((name, index) => [name, sha(bytes[index])]));
    const manifest = JSON.parse(bytes[FILES.indexOf(MANIFEST)]);
    assert.equal(manifest.targets.find(({name}) => name === 'term-bank-parser.wasm').sha256, hashes[WASM]);
    return {root, commit: git(root, 'rev-parse', 'HEAD'), hashes, wasmBytes: bytes[FILES.indexOf(WASM)].byteLength};
}

export async function requireIdentity(expected) {
    assert.deepEqual(await identity(expected.root), expected, 'Frozen source/native identity changed');
}

export async function loadReferences(binding) {
    assert(['jmdict', 'jitendex'].includes(binding.dictionary));
    const sinkBytes = await readFile(binding.sinkReferencePath);
    const outputBytes = await readFile(binding.outputReferencePath);
    if (binding.referenceHashes) {
        assert.equal(sha(sinkBytes), binding.referenceHashes.sink);
        assert.equal(sha(outputBytes), binding.referenceHashes.output);
    }
    const sink = JSON.parse(sinkBytes);
    const witness = JSON.parse(outputBytes);
    assert.equal(sink.complete, true);
    assert.equal(sink.sourceCommit, BASELINE);
    assert.equal(witness.completed, true);
    assert.equal(witness.dictionary, binding.dictionary);
    assert.equal(witness.identities.A.sourceCommit, BASELINE);
    assert.equal(witness.identities.A.wasmSha256, sink.parserWasmSha256);
    for (const arm of ['A', 'B', 'C']) {
        assert.equal(witness.canonicalDigests[arm], sink.sourceDigestSha256);
        assert.equal(witness.rawDigests[arm], witness.rawDigests.A);
        assert.equal(witness.outputDigests[arm], witness.outputDigests.A);
    }
    const groups = binding.dictionary === 'jmdict' ? 12 : 22;
    const banks = binding.dictionary === 'jmdict' ? 53 : 219;
    assert.equal(sink.sourceGroups.length, groups);
    assert.equal(sink.groups.length, groups);
    assert.equal(witness.sourceGroups.length, groups);
    assert.equal(witness.expectedGroupDigests.length, groups);
    assert.equal(sink.sourceGroups.flatMap(({files}) => files).length, banks);
    assert.equal(new Set(sink.sourceGroups.flatMap(({files}) => files)).size, banks);
    const sourceGroups = sink.sourceGroups.map((group, index) => {
        assert.deepEqual(group.files, witness.sourceGroups[index].files);
        assert.equal(sink.groups[index].rows, witness.sourceGroups[index].rows);
        return {files: group.files, compressedBytes: group.bytes, rows: sink.groups[index].rows,
            rawBytes: witness.sourceGroups[index].rawBytes, expected: witness.expectedGroupDigests[index]};
    });
    assert.equal(sourceGroups.reduce((sum, {rows}) => sum + rows, 0), sink.fixture.termRows);
    return {referenceHashes: {sink: sha(sinkBytes), output: sha(outputBytes)}, fixture: sink.fixture,
        options: {...sink.parserOptions, maxPendingChunks: 1, singleChunk: true, compactContentMetadata: true},
        sourceGroups, expectedDigests: {canonical: sink.sourceDigestSha256,
            raw: witness.rawDigests.A, output: witness.outputDigests.A},
        parserWasmSha256: sink.parserWasmSha256,
        parserSourceSha256: witness.identities.A.parserSourceSha256, lockSha256: sink.lockSha256};
}

export function hashCanonical(hash, chunk) {
    for (const key of ['rowCount', 'contentBytesBaseOffset', 'contentBytesLength', 'contentMetaByUniqueIndex']) { hash.update(`${key}:${chunk[key]}\n`); }
    for (const key of ['contentBytesBuffer', 'contentMetaList', 'contentUniqueIndexList', 'scoreList', 'sequenceList', 'readingEqualsExpressionList']) {
        const value = chunk[key];
        hash.update(`${key}:${value?.byteLength}\n`);
        if (ArrayBuffer.isView(value)) { hash.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)); }
    }
}

export function hashValue(hash, value, path) {
    hash.update(path + '\n');
    if (ArrayBuffer.isView(value)) {
        hash.update(value.constructor.name + ':' + value.byteLength + '\n');
        hash.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength));
    } else if (Array.isArray(value)) {
        hash.update('Array:' + value.length + '\n');
        for (let i = 0; i < value.length; ++i) { hashValue(hash, value[i], `${path}[${i}]`); }
    } else if (value instanceof Map) {
        hash.update('Map:' + value.size + '\n');
        for (const [key, item] of value) { hashValue(hash, item, `${path}.map(${key})`); }
    } else if (value !== null && typeof value === 'object') {
        assert.equal(Object.getPrototypeOf(value), Object.prototype, 'Unknown opaque output at ' + path);
        for (const key of Object.keys(value).sort()) { hashValue(hash, value[key], `${path}.${key}`); }
    } else {
        assert.notEqual(typeof value, 'function', 'Opaque callback at ' + path);
        hash.update(typeof value + ':' + (Object.is(value, -0) ? '-0' : String(value)) + '\n');
    }
}

export function totals(groups) {
    const ordinary = ['elapsedMs', 'inflateWallMs', 'parseWallMs', 'cpuUserMs', 'cpuSystemMs', 'cpuTotalMs', 'inflateMs', 'crcMs'];
    const phases = ['parseBankMs', 'nativeStringPlanMs', 'lookupIndexPrepareMs', 'lookupIndexEncodeMs'];
    const counts = ['validatedGlossaryReuseCount', 'recentContentDedupHitCount', 'globalExactContentReuseCount', 'fusedParseAttempts', 'fusedParseFallbacks'];
    return {
        ...Object.fromEntries(ordinary.map((key) => [key, groups.reduce((sum, row) => sum + row.measurement[key], 0)])),
        ...Object.fromEntries(phases.map((key) => [key, groups.reduce((sum, row) => sum + (row.measurement.profile[key] ?? 0), 0)])),
        counts: Object.fromEntries(counts.map((key) => [key, groups.reduce((sum, row) => sum + (row.measurement.profile[key] ?? 0), 0)])),
        rows: groups.reduce((sum, row) => sum + row.rows, 0),
        maximumWasmHeapBytes: Math.max(0, ...groups.map((row) => row.measurement.wasmHeapBytes)),
    };
}

export function summarize(observations) {
    assert.equal(observations.length, 18);
    const blocks = ORDERS.map((_, block) => Object.fromEntries(observations.filter((row) => row.block === block).map((row) => [row.arm, row])));
    const median = (values) => { const a = [...values].sort((x, y) => x - y); return (a[2] + a[3]) / 2; };
    return Object.fromEntries([['BoverA', 'A', 'B'], ['BoverC', 'C', 'B'], ['CoverA', 'A', 'C']].map(([name, left, right]) => [name,
        Object.fromEntries(['elapsedMs', 'parseWallMs', 'parseBankMs', 'cpuTotalMs'].map((key) => {
            const ratios = blocks.map((block) => block[right].totals[key] / block[left].totals[key]);
            assert(ratios.every((value) => Number.isFinite(value) && value > 0));
            return [key, {ratios, medianPairedChangePercent: 100 * (median(ratios) - 1),
                geometricChangePercent: 100 * (Math.exp(ratios.reduce((sum, value) => sum + Math.log(value), 0) / 6) - 1),
                medianSavedMs: median(blocks.map((block) => block[left].totals[key] - block[right].totals[key])),
                fasterBlocks: ratios.filter((value) => value < 1).length}];
        }))]));
}
