from pathlib import Path
import hashlib, json, zipfile, collections

ROOT=Path('/workspace/scratch/1b47f6463b98/evidence')
REPO=Path('/workspace/scratch/1b47f6463b98/manabitan')
BASE='9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
DIGESTS={'jmdict':'6e2e05b5dd3ac90df8198dd5d0b5aef50fac99d191792e6c26d28ff42cefbe2f','jitendex':'bf156b35710cb78e23ed4726729f938ca460a889d2dc1c2effa22a6b1d5e3b26','vndb':'9ee777d33320fcce8e16d86058182e69c9c07422e0b8853c7b12efbde33853e6'}
def sha(b):return hashlib.sha256(b).hexdigest()
def uleb(b,i):
 v=0;shift=0
 while True:
  n=b[i];i+=1;v|=(n&127)<<shift
  if n<128:return v,i
  shift+=7

def wstring(b,i):
 n,i=uleb(b,i);return b[i:i+n].decode(),i+n

def sections(b):
 assert b[:8]==b'\0asm\x01\0\0\0'
 i=8;out=[]
 while i<len(b):
  typ=b[i];i+=1;n,i=uleb(b,i);out.append((typ,b[i:i+n]));i+=n
 return out

named=(ROOT/'current-parser-named.wasm').read_bytes()
base=(REPO/'dev/data/dictionary-wasm/term-bank-parser.wasm').read_bytes()
noncustom_match=[s for s in sections(base) if s[0]]==[s for s in sections(named) if s[0]]
assert noncustom_match, 'Named and production WASM differ in executable sections'
functions={}
for typ,b in sections(named):
 if typ:continue
 name,i=wstring(b,0)
 if name!='name':continue
 while i<len(b):
  subtype=b[i];i+=1;n,i=uleb(b,i);body=b[i:i+n];i+=n
  if subtype!=1:continue
  count,j=uleb(body,0)
  for _ in range(count):
   index,j=uleb(body,j);fn,j=wstring(body,j);functions[index]=fn
mapping={'baseline':BASE,'baselineWasmSha256':sha(base),'namedWasmSha256':sha(named),'noncustomSectionsEqual':noncustom_match,'functions':functions}
(ROOT/'current-parser-symbols.json').write_text(json.dumps(mapping,indent=2)+'\n')

for dictionary,expected in DIGESTS.items():
 archive=ROOT/f'current-baseline-{dictionary}.zip'
 assert sha(archive.read_bytes())==expected
 folder=ROOT/f'current-baseline-{dictionary}'
 folder.mkdir(exist_ok=True)
 with zipfile.ZipFile(archive) as z:
  for name in ['identity.json','acquisition.json','completion.json','host-before.json','ordinary/summary.json','ordinary/run-1.json','trace/summary.json','trace/run-1.json','trace/run-1.trace.json']:
   p=folder/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
 identity=json.loads((folder/'identity.json').read_text());assert identity['source']==BASE
 assert identity['package']['members']['lib/term-bank-parser.wasm']['sha256']==sha(base)
 ordinary=json.loads((folder/'ordinary/summary.json').read_text());diagnostic=json.loads((folder/'trace/summary.json').read_text())
 assert ordinary['authoritativeTiming'] and not diagnostic['authoritativeTiming']
 assert ordinary['gitSha']==diagnostic['gitSha']==BASE
 assert ordinary['runs'][0]['packageSha256']==identity['package']['sha256']==diagnostic['runs'][0]['packageSha256']
 events=json.loads((folder/'trace/run-1.trace.json').read_text())['traceEvents']
 nodes={};chunks=[];thread_names={};process_names={}
 for e in events:
  if e.get('name')=='thread_name':thread_names[(e.get('pid'),e.get('tid'))]=e.get('args',{}).get('name')
  if e.get('name')=='process_name':process_names[e.get('pid')]=e.get('args',{}).get('name')
  d=e.get('args',{}).get('data',{});profile=d.get('cpuProfile');key=(e.get('pid'),e.get('tid'),str(e.get('id2',e.get('id'))))
  if profile:
   for n in profile.get('nodes',[]): nodes[(key,n['id'])]=n
   chunks.append((key,profile.get('samples',[]),d.get('timeDeltas',[])))
 counters=collections.Counter();counts=collections.Counter();threadtime=collections.Counter();module_callers=collections.defaultdict(collections.Counter)
 for key,samples,deltas in chunks:
  for index,nodeid in enumerate(samples):
   n=nodes.get((key,nodeid),{});f=n.get('callFrame',{});name=(f.get('functionName'),f.get('url',''),f.get('lineNumber'))
   counts[name]+=1
   if index<len(deltas) and deltas[index]>=0:
    counters[name]+=deltas[index];threadtime[(key[0],key[1],name[0]=='(idle)')]+=deltas[index]
   if name[0] and name[0].startswith('wasm-function['):
    p=n;seen=set()
    while 'parent' in p and p['parent'] not in seen:
     seen.add(p['parent']);p=nodes.get((key,p['parent']),{});caller=p.get('callFrame',{})
     if caller.get('url','').startswith('chrome-extension:'):
      module_callers[name[1]][(caller.get('functionName'),caller.get('url'))]+=1;break
 hotspots=[{'sampledMs':round(t/1000,2),'samples':counts[n],'function':n[0],'source':n[1],'line':n[2]} for n,t in counters.most_common(120)]
 threads=[{'pid':p,'tid':t,'name':thread_names.get((p,t)),'process':process_names.get(p),'idle':idle,'sampledMs':round(v/1000,2)} for (p,t,idle),v in threadtime.most_common()]
 callers={u:[{'function':k[0],'source':k[1],'samples':v} for k,v in c.most_common(12)] for u,c in module_callers.items()}
 report={'dictionary':dictionary,'baseline':BASE,'artifactSha256':expected,'runId':46100401987,'node':identity['node'],'browser':identity['browser']['version'],'ordinaryTiming':ordinary['timing'],'ordinaryStep4':ordinary['runs'][0]['step4Breakdown'],'traceStep4':diagnostic['runs'][0]['step4Breakdown'],'ordinaryValidation':ordinary['runs'][0]['validation'],'hotspots':hotspots,'threads':threads,'moduleCallers':callers}
 (folder/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
 print(dictionary,ordinary['timing']['medianMs'], 'ms, exact source/package verified')
 print('Threads:',json.dumps(threads[:10]))
 print('Hotspots:',json.dumps(hotspots[:18]))
 print('Modules:',json.dumps(callers))
