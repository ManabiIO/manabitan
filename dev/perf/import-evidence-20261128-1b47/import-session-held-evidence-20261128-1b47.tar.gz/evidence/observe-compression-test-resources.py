#!/usr/bin/env python3
"""Observe only the launched Vitest process tree; no memory limits are changed."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

assert len(sys.argv) == 4, 'Usage: observe-compression-test-resources.py SOURCE OUTPUT_JSON OUTPUT_LOG'
source, output_path, log_path = map(lambda value: Path(value).resolve(), sys.argv[1:])
observer = Path(__file__).resolve().with_name('observe-compression-test-child-exit.cjs')
events_path = output_path.with_suffix('.child-exits.jsonl')
with events_path.open('x'):
    pass
environment = os.environ.copy()
environment['NODE_OPTIONS'] = (environment.get('NODE_OPTIONS', '') + ' --require=' + str(observer)).strip()
environment['MANABITAN_CHILD_EXIT_LOG'] = str(events_path)
command = ['./node_modules/.bin/vitest', 'run', 'test/zstd-term-content-packed-dispatch.test.js',
           '-t', 'preserves frames, envelopes and output ownership',
           '--maxWorkers=1', '--no-file-parallelism', '--reporter=verbose']


def cgroup_status():
    result = {}
    for name in ['memory.events', 'memory.max', 'memory.current', 'memory.peak',
                 'memory/memory.oom_control', 'memory/memory.limit_in_bytes',
                 'memory/memory.usage_in_bytes', 'memory/memory.max_usage_in_bytes']:
        path = Path('/sys/fs/cgroup') / name
        if path.is_file():
            result[name] = path.read_text()
    return result


def own_tree(root_pid):
    pending = [root_pid]
    seen = set()
    rows = []
    while pending:
        pid = pending.pop()
        if pid in seen:
            continue
        seen.add(pid)
        path = Path('/proc') / str(pid)
        try:
            values = dict(line.split(':', 1) for line in (path / 'status').read_text().splitlines() if ':' in line)
            selected = {name: values.get(name, '').strip() for name in ('Name', 'State', 'Pid', 'PPid', 'VmRSS', 'VmPeak', 'VmHWM')}
            selected['pid'] = pid
            rows.append(selected)
            pending.extend(int(value) for value in (path / 'task' / str(pid) / 'children').read_text().split())
        except (FileNotFoundError, ProcessLookupError):
            continue
    return rows


before = cgroup_status()
started = time.monotonic()
samples = []
with log_path.open('xb') as log:
    process = subprocess.Popen(command, cwd=source, env=environment, stdout=log, stderr=subprocess.STDOUT)
    while process.poll() is None:
        samples.append({'elapsedMs': (time.monotonic() - started) * 1000, 'processes': own_tree(process.pid)})
        time.sleep(0.05)
    exit_code = process.wait()
after = cgroup_status()
events = [json.loads(line) for line in events_path.read_text().splitlines()]
report = {'source': str(source), 'command': command, 'exitCode': exit_code,
          'elapsedMs': (time.monotonic() - started) * 1000,
          'scope': 'Read-only RSS/high-water sampling of the launched Vitest process and its descendants plus child exit events. No memory limit change; original test/runtime untouched.',
          'cgroupBefore': before, 'cgroupAfter': after, 'childEvents': events,
          'samples': samples, 'stdoutPath': str(log_path), 'childEventsPath': str(events_path)}
with output_path.open('x') as output:
    json.dump(report, output, indent=2)
    output.write('\n')
print(json.dumps({'exitCode': exit_code, 'childEvents': events, 'cgroupAvailable': bool(before), 'report': str(output_path)}))
sys.exit(exit_code)
