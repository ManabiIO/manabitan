// Isolate typed-view width only; preallocation excludes SAB allocation/first touch.
// This is a local Node component probe, not a browser import benchmark.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import {performance} from 'node:perf_hooks';

const length = 8 * 1024 * 1024 + 3;
const sourceOffset = 8;
const pages = Math.ceil((length + sourceOffset) / 65536);
const memory = new WebAssembly.Memory({initial: pages, maximum: pages, shared: true});
const source = new Uint8Array(memory.buffer, sourceOffset, length);
for (let i = 0; i < length; ++i) { source[i] = (i * 29 + (i >>> 15)) & 255; }
const destination = new Uint8Array(new SharedArrayBuffer(length));
const words = Math.floor(length / 4);
const sourceWords = new Uint32Array(source.buffer, source.byteOffset, words);
const destinationWords = new Uint32Array(destination.buffer, 0, words);
const sourceTail = source.subarray(words * 4);
const byteCopy = () => destination.set(source);
const wordCopy = () => {
    destinationWords.set(sourceWords);
    destination.set(sourceTail, words * 4);
};
for (const copy of [byteCopy, wordCopy]) {
    destination.fill(0);
    copy();
    assert.equal(Buffer.compare(Buffer.from(source), Buffer.from(destination)), 0);
}
for (let i = 0; i < 12; ++i) { byteCopy(); wordCopy(); }
const copiesPerObservation = 16;
const pairs = [];
const timed = (copy) => {
    const start = performance.now();
    for (let i = 0; i < copiesPerObservation; ++i) { copy(); }
    return performance.now() - start;
};
for (let pair = 0; pair < 16; ++pair) {
    const order = pair % 2 === 0 ? ['byte', 'word'] : ['word', 'byte'];
    const row = {pair, order};
    for (const arm of order) { row[arm] = timed(arm === 'byte' ? byteCopy : wordCopy); }
    row.changePercent = (row.word / row.byte - 1) * 100;
    pairs.push(row);
}
const median = (values) => {
    values = [...values].sort((a, b) => a - b);
    return (values[values.length / 2 - 1] + values[values.length / 2]) / 2;
};
const report = {
    scope: 'Preallocated aligned shared WASM source to owned SAB; width only, no import claim',
    node: process.version, v8: process.versions.v8, cpu: os.cpus()[0]?.model,
    sourceOffset, length, copiesPerObservation, pairs,
    byteMedianMs: median(pairs.map((p) => p.byte)),
    wordMedianMs: median(pairs.map((p) => p.word)),
    medianPairedChangePercent: median(pairs.map((p) => p.changePercent)),
    wordFasterPairs: pairs.filter((p) => p.word < p.byte).length,
    exactBytes: Buffer.compare(Buffer.from(source), Buffer.from(destination)) === 0,
};
fs.writeFileSync(new URL('./aligned-owned-copy-probe.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({...report, pairs: undefined}, null, 2));
