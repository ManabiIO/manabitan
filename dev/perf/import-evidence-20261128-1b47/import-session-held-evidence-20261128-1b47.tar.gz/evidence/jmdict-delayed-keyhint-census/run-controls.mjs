// Untimed controls for two admission models. Real output remains baseline.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {crc32, deflateRawSync} from 'node:zlib';
import {execFileSync} from 'node:child_process';
import {makeKeyRunControls} from '../jmdict-keyrun-candidate/control-fixtures.mjs';

const [rootPath, referencePath, manifestPath, outputPath] = process.argv.slice(2);
assert(rootPath && referencePath && manifestPath && outputPath);
const root = resolve(rootPath);
const manifest = JSON.parse(await readFile(manifestPath));
const reference = JSON.parse(await readFile(referencePath));
const sha = (value) => createHash('sha256').update(value).digest('hex');
const sourceCommit = execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim();
assert.equal(sourceCommit, manifest.baseline);
assert.equal(sourceCommit, reference.sourceCommit);
assert.equal(manifest.counterWordCount, 184);
assert.equal(manifest.counterLabels.length, 184);
assert.equal(sha(await readFile(manifest.sourcePath)), manifest.sourceSha256);
const bytes = await readFile(manifest.wasmPath);
assert.equal(sha(bytes), manifest.wasmSha256);
const instrumentedModule = await WebAssembly.compile(bytes);
const originalModule = await WebAssembly.compile(await readFile(join(root, 'dev/data/dictionary-wasm/term-bank-parser.wasm')));
let native = null;
const instantiate = WebAssembly.instantiate;
WebAssembly.instantiate = async (module, imports) => {
    const result = await instantiate(module, imports);
    if (module === instrumentedModule) { native = result.exports; }
    return result;
};
const parsers = {};
for (const arm of ['baseline', 'instrumented']) {
    const url = pathToFileURL(join(root, 'ext/js/dictionary/term-bank-wasm-parser.js'));
    url.searchParams.set('delayed-hint-control', arm);
    parsers[arm] = await import(url);
    parsers[arm].setTermBankWasmModule(arm === 'baseline' ? originalModule : instrumentedModule);
}
const options = {...reference.parserOptions, maxPendingChunks: 1, singleChunk: true, compactContentMetadata: true};

function digest(value) {
    const hash = createHash('sha256');
    const visit = (item, path) => {
        hash.update(path + '\n');
        if (ArrayBuffer.isView(item)) {
            hash.update(`${item.constructor.name}:${item.byteLength}\n`);
            hash.update(new Uint8Array(item.buffer, item.byteOffset, item.byteLength));
        } else if (Array.isArray(item)) {
            hash.update(`array:${item.length}\n`);
            item.forEach((entry, index) => visit(entry, `${path}[${index}]`));
        } else if (item instanceof Map) {
            hash.update(`map:${item.size}\n`);
            for (const [key, entry] of item) { visit(entry, `${path}.map(${key})`); }
        } else if (item !== null && typeof item === 'object') {
            const keys = Object.keys(item).sort();
            hash.update(`object:${keys.join(',')}\n`);
            for (const key of keys) { visit(item[key], `${path}.${key}`); }
        } else {
            assert.notEqual(typeof item, 'function');
            hash.update(`${typeof item}:${Object.is(item, -0) ? '-0' : String(item)}\n`);
        }
    };
    visit(value, 'chunk');
    return hash.digest('hex');
}

const reports = [];
let failure = null;
try {
    for (const control of makeKeyRunControls()) {
        const sources = control.banks.map((source) => {
            const bytes = new Uint8Array(deflateRawSync(source));
            return {bytes, compressionMethod: 8, compressedSize: bytes.length, uncompressedSize: source.length, signature: crc32(source)};
        });
        const expectedRawSha = sha(Buffer.concat(control.banks));
        const outputs = {};
        let counters = null;
        for (const arm of ['baseline', 'instrumented']) {
            const parser = parsers[arm];
            const preloaded = await parser.inflateCompressedTermBankSourcesWasm(sources, options, true);
            // Hash before parse: the long-key fallback reuses this arena.
            const sourceSha256 = sha(new Uint8Array(preloaded.wasm.memory.buffer, preloaded.jsonPtr, preloaded.jsonLength));
            assert.equal(sourceSha256, expectedRawSha);
            const chunks = [];
            await parser.parseTermBankWithWasmColumnChunks(new Uint8Array(), 3, (chunk) => {
                const normalized = parser.copyWasmBackedColumnChunk(chunk, true, false, true, preloaded);
                delete normalized.preparedLookupIndexEncodeMs;
                chunks.push(normalized);
            }, 2048, {...options, preloadedSource: preloaded});
            const profile = parser.consumeLastTermBankWasmParseProfile();
            assert.equal(profile.fusedParseAttempts, 1);
            const expectedFallbacks = control.name === 'unique_long_common_prefix_keys' ? 1 : 0;
            assert.equal(profile.fusedParseFallbacks, expectedFallbacks);
            assert.equal(profile.validatedGlossaryReuseCount, control.expectedBaselineWitnesses);
            assert.equal(chunks.reduce((sum, chunk) => sum + chunk.rowCount, 0), control.rowCount);
            outputs[arm] = {sourceSha256, completeOutputSha256: digest(chunks),
                fusedParseFallbacks: profile.fusedParseFallbacks, validatedGlossaryReuseCount: profile.validatedGlossaryReuseCount};
            if (arm === 'instrumented') {
                assert(native);
                const ptr = native[manifest.counterExport]();
                const words = new Uint32Array(native.memory.buffer, ptr, manifest.counterWordCount);
                counters = Object.fromEntries(manifest.counterLabels.map((key, index) => [key, words[index]]));
                if (expectedFallbacks === 0) { assert.equal(counters.rows, control.rowCount); }
            }
        }
        assert.deepEqual(outputs.baseline, outputs.instrumented);
        reports.push({name: control.name, rowCount: control.rowCount, sourceBytes: control.banks.reduce((sum, source) => sum + source.length, 0),
            outputs, counters, fullFusedCensus: outputs.instrumented.fusedParseFallbacks === 0});
    }
} catch (error) {
    failure = error.stack ?? String(error);
    process.stderr.write(failure + '\n');
    process.exitCode = 1;
} finally {
    WebAssembly.instantiate = instantiate;
    const report = {completed: failure === null, failure,
        scope: 'Untimed admission-model census on unchanged five controls. Real instrumented parser remains baseline. Every complete output/source digest matches an independent baseline module. Long-key input retains its existing fallback, so its partial native counters are not interpreted as a whole-control census.',
        sourceCommit, manifest, scriptSha256: sha(await readFile(new URL(import.meta.url))),
        controlSourceSha256: sha(await readFile(new URL('../jmdict-keyrun-candidate/control-fixtures.mjs', import.meta.url))),
        options, reports};
    await writeFile(outputPath, JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
    process.stdout.write(JSON.stringify({completed: report.completed, failure, controls: reports.length}) + '\n');
}
