import hashlib
import json
from pathlib import Path
import re
import subprocess


ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / 'jmdict-distance2-census' / 'distance2'
REPO = ROOT.parent.parent / 'manabitan'
CLANG = Path('/tmp/manabitan-native-9bb32/native-toolchain/bin/clang')
LINKER = CLANG.with_name('wasm-ld')
old = json.loads((PREVIOUS / 'build-manifest.json').read_text())
source = (PREVIOUS / 'instrumented.c').read_text()
assert hashlib.sha256(source.encode()).hexdigest() == old['sourceSha256']


def once(text, previous, replacement):
    assert text.count(previous) == 1, (text.count(previous), previous)
    return text.replace(previous, replacement, 1)


labels = old['counterLabels'] + [
    'delayedHintRows',
    'delayedAddedProbeRows',
    'delayedBoundaryProbeRows',
    'delayedFieldSwitchProbeRows',
    'delayedBoundaryNewWitnessRows',
    'delayedFieldSwitchNewWitnessRows',
    'delayedBoundaryFullCompared',
    'delayedBoundaryFullBytes',
    'exactDistanceNewWitnessRows',
    'exactDistanceAvoidedCompositeTokens',
    'exactDistanceAvoidedCompositeBytes',
    'exactDistanceAddedProbeRows',
    'commonNewWitnessRows',
    'delayedOnlyNewWitnessRows',
    'delayedOnlyAvoidedCompositeTokens',
    'delayedOnlyAvoidedCompositeBytes',
    'exactOnlyNewWitnessRows',
    'exactOnlyAvoidedCompositeTokens',
    'exactOnlyAvoidedCompositeBytes',
    'delayedBoundaryNewWitnessBytes',
    'delayedProbesOutsideExactAdmissionRows',
    'exactProbesOutsideDelayedAdmissionRows',
]
assert len(labels) == 184
source = once(source, 'parser_probe_counters[162]', 'parser_probe_counters[184]')
source = once(source, 'probe < 162u', 'probe < 184u')
source = once(source, '    uint32_t probe_key_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;', '''    uint32_t probe_key_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;
    uint32_t probe_previous_adjacent_key = 0u;
    uint32_t probe_exact_distance_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;''')

# A second, counter-free oracle mirrors the frozen exact-current-key policy.
# Neither hypothetical witness is passed to the real parser or CRC verifier.
start = source.index('static uint32_t parser_probe_keyrun_glossary(')
end = source.index('\nstatic inline int next_format3_field', start)
helper = source[start:end]
plain = helper.replace('parser_probe_keyrun_glossary', 'parser_probe_plain_glossary')
plain = re.sub(r'\+\+parser_probe_counters\[\d+\];\s*', '', plain)
plain = re.sub(r'parser_probe_counters\[\d+\] \+= n;\s*', '', plain)
assert 'parser_probe_counters' not in plain
source = source[:end] + '\n' + plain + source[end:]

start = source.index('        if (probe_key_run == 0u) { probe_key_budget')
end = source.index('        if (probe_witness != 0xffffffffu && glossary_witness == 0xffffffffu)', start)
source = source[:start] + '''        if (probe_key_run == 0u) { probe_exact_distance_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET; }
        ++parser_probe_counters[123u + probe_key_run];
        ++parser_probe_counters[128u + probe_adjacent_key_mask];

        const uint32_t delayed_hint = probe_previous_adjacent_key;
        if (delayed_hint) { ++parser_probe_counters[162]; }
        const uint32_t exact_probe = validated_glossary_reuse_enabled && glossary_lookback == 0u &&
            probe_key_run >= 2u && probe_exact_distance_budget > 0u;
        uint32_t exact_witness = glossary_witness;
        if (exact_probe) {
            ++parser_probe_counters[173];
            exact_witness = parser_probe_plain_glossary(src, source.end, parsed_row->glossary_start, rows, row_count, 2u, 1u);
        }
        if (exact_witness != 0xffffffffu) {
            probe_exact_distance_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;
        } else if ((glossary_lookback > 0u || exact_probe) && probe_key_run > 0u && probe_exact_distance_budget > 0u) {
            --probe_exact_distance_budget;
        }

        // The current row uses only the previous row's existing bounded
        // interner result. No current-row key comparisons move or duplicate.
        uint32_t probe_lookback = glossary_lookback;
        uint32_t distance_two_only = 0u;
        if (validated_glossary_reuse_enabled && glossary_lookback == 0u && row_count >= 2u && delayed_hint) {
            if (probe_key_budget > 0u) {
                probe_lookback = 2u;
                distance_two_only = 1u;
                ++parser_probe_counters[163];
                if (probe_key_run == 0u) { ++parser_probe_counters[164]; }
                else if (probe_key_run == 1u) { ++parser_probe_counters[165]; }
            } else { ++parser_probe_counters[153]; }
        }
        if (distance_two_only && !exact_probe) { ++parser_probe_counters[182]; }
        if (exact_probe && !distance_two_only) { ++parser_probe_counters[183]; }
        ++parser_probe_counters[132u + probe_lookback];
        const uint32_t full_before = parser_probe_counters[142];
        const uint32_t full_bytes_before = parser_probe_counters[143];
        const uint32_t probe_witness = parser_probe_keyrun_glossary(
            src, source.end, parsed_row->glossary_start, rows, row_count, probe_lookback, distance_two_only);
        if (probe_witness != 0xffffffffu) {
            probe_key_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;
        } else if (probe_lookback > 0u && delayed_hint && probe_key_budget > 0u) {
            --probe_key_budget;
        }
        if (distance_two_only && probe_key_run < 2u) {
            parser_probe_counters[168] += parser_probe_counters[142] - full_before;
            parser_probe_counters[169] += parser_probe_counters[143] - full_bytes_before;
        }
        // This update happens after the current interner in the prospective
        // product route. It cannot alter that row's already-completed probe.
        probe_previous_adjacent_key = probe_adjacent_key_mask != 0u;
        if (!probe_previous_adjacent_key) { probe_key_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET; }

        if (glossary_witness == 0xffffffffu) {
            const uint32_t exact_hit = exact_witness != 0xffffffffu;
            const uint32_t delayed_hit = probe_witness != 0xffffffffu;
            if (exact_hit) {
                ++parser_probe_counters[170];
                parser_probe_counters[171] += probe_scanned_tokens;
                parser_probe_counters[172] += probe_scanned_bytes;
            }
            if (exact_hit && delayed_hit) { ++parser_probe_counters[174]; }
            if (delayed_hit && !exact_hit) {
                ++parser_probe_counters[175];
                parser_probe_counters[176] += probe_scanned_tokens;
                parser_probe_counters[177] += probe_scanned_bytes;
            }
            if (exact_hit && !delayed_hit) {
                ++parser_probe_counters[178];
                parser_probe_counters[179] += probe_scanned_tokens;
                parser_probe_counters[180] += probe_scanned_bytes;
            }
            if (delayed_hit && probe_key_run == 0u) {
                ++parser_probe_counters[166];
                parser_probe_counters[181] += parsed_row->glossary_length;
            }
            if (delayed_hit && probe_key_run == 1u) { ++parser_probe_counters[167]; }
        }
''' + source[end:]

source_path = ROOT / 'instrumented.c'
wasm_path = ROOT / 'instrumented.wasm'
source_path.write_text(source)
manifest = json.loads((REPO / 'dev/data/dictionary-wasm/manifest.json').read_text())
target = next(item for item in manifest['targets'] if item['name'] == 'term-bank-parser.wasm')
command = [str(CLANG), f'-fuse-ld={LINKER}', *target['arguments'], '-o', str(wasm_path), str(source_path),
           str(REPO / 'ext/js/dictionary/wasm/term-bank-inflate.c')]
subprocess.run(command, check=True)
report = {
    'scope': 'Untimed admission census only. Real parser is exact frozen baseline; neither model changes metadata, witnesses, budgets, source CRCs, or canonical output.',
    'policy': 'delayed-prior-row-adjacent-key-hint',
    'policyDetails': 'Original admission inactive, row>=2, prior interner reported a bounded adjacent key match, four unsuccessful probe rows per hint run; probe only distance2. Any exact hit refreshes key budget; current interner clears hint and resets key budget only after this row probe. Original long/streak budget remains baseline.',
    'baseline': old['baseline'], 'previousManifest': str(PREVIOUS / 'build-manifest.json'),
    'sourcePath': str(source_path), 'sourceSha256': hashlib.sha256(source.encode()).hexdigest(),
    'wasmPath': str(wasm_path), 'wasmSha256': hashlib.sha256(wasm_path.read_bytes()).hexdigest(),
    'wasmBytes': wasm_path.stat().st_size, 'counterExport': old['counterExport'],
    'counterWordCount': len(labels), 'counterLabels': labels,
    'compiler': subprocess.check_output([str(CLANG), '--version'], text=True).strip(), 'command': command,
}
(ROOT / 'build-manifest.json').write_text(json.dumps(report, indent=2) + '\n')
runner = (PREVIOUS / 'run-census.mjs').read_text().replace(', 162);', ', 184);')
(ROOT / 'run-census.mjs').write_text(runner)
print(json.dumps({key: report[key] for key in ['policy', 'sourceSha256', 'wasmSha256', 'wasmBytes', 'counterWordCount']}, indent=2))
