/* SPDX-License-Identifier: GPL-3.0-or-later */
// Instrumented work census only. Counters change cost; no timing is reported.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream, openAsBlob} from 'node:fs';
import {readFile, writeFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';

const [sourcePath, cachePath, referencePath, manifestPath, outputPath] = process.argv.slice(2);
assert(sourcePath && cachePath && referencePath && manifestPath && outputPath);
const root = resolve(sourcePath);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const referenceBytes = await readFile(referencePath);
const reference = JSON.parse(referenceBytes);
const manifestBytes = await readFile(manifestPath);
const manifest = JSON.parse(manifestBytes);
const commit = execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim();
assert.equal(commit, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
assert.equal(manifest.baseline, commit);
assert.equal(reference.rows, 528299);
assert.equal(reference.sourceGroups.length, 12);
assert.equal(manifest.counterWordCount, 162);
assert.equal(manifest.counterLabels.length, 162);
assert.equal(sha(await readFile(manifest.sourcePath)), manifest.sourceSha256);
const wasmBytes = await readFile(manifest.wasmPath);
assert.equal(sha(wasmBytes), manifest.wasmSha256);
const module = await WebAssembly.compile(wasmBytes);
assert(WebAssembly.Module.exports(module).some(({name}) => name === manifest.counterExport));
let instrumentedExports = null;
const originalInstantiate = WebAssembly.instantiate;
WebAssembly.instantiate = async (input, imports) => {
    const result = await originalInstantiate(input, imports);
    if (input === module) {
        assert.equal(instrumentedExports, null, 'Only one sequential parser instance expected');
        instrumentedExports = result.exports;
    }
    return result;
};
const relativeImport = (path) => import(pathToFileURL(join(root, path)));
const parser = await relativeImport('ext/js/dictionary/term-bank-wasm-parser.js');
const {readDenseZipDirectory} = await relativeImport('ext/js/dictionary/dense-zip-directory.js');
const {RawZipPayloadReader} = await relativeImport('ext/js/dictionary/term-bank-source-pipeline.js');
parser.setTermBankWasmModule(module);
const lockBytes = await readFile(join(root, 'test/perf/dictionaries.lock.json'));
const fixture = JSON.parse(lockBytes).dictionaries.jmdict;
assert.equal(fixture.sha256, reference.fixture.sha256);
const archivePath = join(cachePath, fixture.cacheFile);
const archiveDigest = createHash('sha256');
for await (const bytes of createReadStream(archivePath)) { archiveDigest.update(bytes); }
assert.equal(archiveDigest.digest('hex'), fixture.sha256);
const archive = await openAsBlob(archivePath);
assert.equal(archive.size, fixture.sizeBytes);
let entries = await readDenseZipDirectory(archive);
let zipReader = null;
if (entries === null) {
    const require = createRequire(join(root, 'package.json'));
    const {BlobReader, ZipReader} = require('@zip.js/zip.js');
    zipReader = new ZipReader(new BlobReader(archive));
    entries = await zipReader.getEntries();
}
const byName = new Map(entries.map((entry) => [entry.filename, entry]));
const allFileNames = reference.sourceGroups.flatMap(({files}) => files);
assert.equal(allFileNames.length, 53);
assert.equal(new Set(allFileNames).size, 53);
const reader = new RawZipPayloadReader(archive);
const signal = new AbortController().signal;
const requestedOptions = reference.parserOptions;
// These are the exact production worker's additions to the recorded options.
const effectiveOptions = {...requestedOptions, maxPendingChunks: 1, singleChunk: true, compactContentMetadata: true};
const rawSourceDigest = createHash('sha256');
const canonicalChunkDigest = createHash('sha256');
const completeOutputDigest = createHash('sha256');
const groups = [];
let totalRows = 0;
let completed = false;
let failure = null;

function hashCanonicalChunk(chunk) {
    for (const key of ['rowCount', 'contentBytesBaseOffset', 'contentBytesLength', 'contentMetaByUniqueIndex']) { canonicalChunkDigest.update(`${key}:${chunk[key]}\n`); }
    for (const key of ['contentBytesBuffer', 'contentMetaList', 'contentUniqueIndexList', 'scoreList', 'sequenceList', 'readingEqualsExpressionList']) {
        const value = chunk[key];
        canonicalChunkDigest.update(`${key}:${value?.byteLength}\n`);
        if (ArrayBuffer.isView(value)) { canonicalChunkDigest.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)); }
    }
}

function hashValue(value, path) {
    completeOutputDigest.update(path + '\n');
    if (ArrayBuffer.isView(value)) {
        completeOutputDigest.update(value.constructor.name + ':' + value.byteLength + '\n');
        completeOutputDigest.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength));
    } else if (Array.isArray(value)) {
        completeOutputDigest.update('array:' + value.length + '\n');
        for (let index = 0; index < value.length; ++index) { hashValue(value[index], `${path}[${index}]`); }
    } else if (value instanceof Map) {
        completeOutputDigest.update('map:' + value.size + '\n');
        for (const [key, item] of value) { hashValue(item, `${path}.map(${key})`); }
    } else if (value !== null && typeof value === 'object') {
        const keys = Object.keys(value).sort();
        completeOutputDigest.update('object:' + keys.join(',') + '\n');
        for (const key of keys) { hashValue(value[key], path + '.' + key); }
    } else {
        assert.notEqual(typeof value, 'function', path + ': opaque function cannot be hashed');
        completeOutputDigest.update(typeof value + ':' + (Object.is(value, -0) ? '-0' : String(value)) + '\n');
    }
}

try {
    for (const [index, sourceGroup] of reference.sourceGroups.entries()) {
        const sources = await Promise.all(sourceGroup.files.map(async (filename) => {
            const entry = byName.get(filename);
            assert(entry);
            return {bytes: await reader.read(entry, signal), compressionMethod: entry.compressionMethod, compressedSize: entry.compressedSize, uncompressedSize: entry.uncompressedSize, signature: entry.signature, filename};
        }));
        assert.deepEqual(sources.map(({bytes}) => bytes.byteLength), sourceGroup.bytes);
        const preloaded = await parser.inflateCompressedTermBankSourcesWasm(sources, effectiveOptions, true);
        assert.equal(preloaded.crcSignaturesPtr, 0, 'JMdict production gate verifies CRC during inflate');
        assert(instrumentedExports);
        rawSourceDigest.update(new Uint8Array(preloaded.wasm.memory.buffer, preloaded.jsonPtr, preloaded.jsonLength));
        let chunks = 0;
        let observedRows = 0;
        let contentSlab = null;
        await parser.parseTermBankWithWasmColumnChunks(new Uint8Array(), 3, (chunk) => {
            ++chunks;
            observedRows += chunk.rowCount;
            contentSlab = {baseOffset: chunk.contentBytesBaseOffset, bytes: chunk.contentBytesLength, byteOffsetModulo8: ((chunk.contentBytesBuffer?.byteOffset ?? 0) + (chunk.contentBytesBaseOffset ?? 0)) % 8};
            const normalized = parser.copyWasmBackedColumnChunk(chunk, true, false, true, preloaded);
            hashCanonicalChunk(normalized);
            const stable = {...normalized};
            delete stable.preparedLookupIndexEncodeMs;
            hashValue(stable, `group-${index}`);
        }, 2048, {...effectiveOptions, preloadedSource: preloaded});
        assert.equal(chunks, 1);
        assert.equal(observedRows, reference.groups[index].rows);
        const counterPtr = instrumentedExports[manifest.counterExport]();
        assert(counterPtr > 0);
        const values = [...new Uint32Array(instrumentedExports.memory.buffer, counterPtr, manifest.counterWordCount)];
        const counters = Object.fromEntries(manifest.counterLabels.map((label, counterIndex) => [label, values[counterIndex]]));
        assert.equal(counters.rows, observedRows, 'Each fused group must reset counters exactly once');
        const profile = parser.consumeLastTermBankWasmParseProfile();
        assert.equal(profile.fusedParseAttempts, 1);
        assert.equal(profile.fusedParseFallbacks, 0);
        totalRows += observedRows;
        const group = {index, files: sourceGroup.files, rows: observedRows, rawSourceBytes: preloaded.jsonLength, contentSlab, wasmHeapBytes: instrumentedExports.memory.buffer.byteLength, counters};
        groups.push(group);
        // Per-group counters are retained in the final JSON report.
    }
    assert.equal(totalRows, fixture.termRows);
    completed = true;
} catch (error) {
    failure = error.stack ?? String(error);
    process.stderr.write(failure + '\n');
    process.exitCode = 1;
} finally {
    WebAssembly.instantiate = originalInstantiate;
    if (zipReader !== null) { await zipReader.close(); }
    const sourceDigestSha256 = canonicalChunkDigest.digest('hex');
    const parity = sourceDigestSha256 === reference.sourceDigestSha256;
    if (completed && !parity) {
        completed = false;
        failure = 'Instrumented native canonical/row columns differ from verified baseline source digest';
        process.exitCode = 1;
    }
    assert.equal(sha(await readFile(manifest.wasmPath)), manifest.wasmSha256);
    const totals = Object.fromEntries(manifest.counterLabels.map((label) => [label, groups.reduce((sum, group) => sum + group.counters[label], 0)]));
    const result = {
        completed, failure,
        scope: 'Instrumented native work census, no timing interpretation. Exact12productionJMdictsourcegroups replayed sequentially through unchanged wrapper and production worker options; counters change execution cost. Real native inflation verifies all53ZIPbankCRCs. Canonical bytes and row columns reproduce the verified baseline sink source digest; broader output digest is recorded for reproducibility but not separately baseline-compared.',
        node: process.version, sourceCommit: commit, fixture, lockSha256: sha(lockBytes),
        referencePath: resolve(referencePath), referenceSha256: sha(referenceBytes),
        nativeBuildManifest: manifest, nativeBuildManifestSha256: sha(manifestBytes),
        scriptSha256: sha(await readFile(new URL(import.meta.url))),
        requestedOptions, effectiveOptions, totalRows, groups,
        rawSourceDigestSha256: rawSourceDigest.digest('hex'), sourceDigestSha256,
        referenceSourceDigestSha256: reference.sourceDigestSha256, canonicalAndRowOutputMatchesReference: parity,
        completeOutputDigestSha256: completeOutputDigest.digest('hex'), totals,
    };
    await writeFile(outputPath, JSON.stringify(result, null, 2) + '\n', {flag: 'wx'});
    process.stdout.write('SUMMARY ' + JSON.stringify({completed, failure, totalRows, canonicalAndRowOutputMatchesReference: parity, sourceDigestSha256, totals}) + '\n');
}
