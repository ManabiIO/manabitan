import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / 'jmdict-keyrun-census'
REPO = ROOT.parent.parent / 'manabitan'
CLANG = Path('/tmp/manabitan-native-9bb32/native-toolchain/bin/clang')
LINKER = CLANG.with_name('wasm-ld')
old = json.loads((PREVIOUS / 'build-manifest.json').read_text())
original = (PREVIOUS / 'instrumented.c').read_text()
assert hashlib.sha256(original.encode()).hexdigest() == old['sourceSha256']
manifest = json.loads((REPO / 'dev/data/dictionary-wasm/manifest.json').read_text())
target = next(item for item in manifest['targets'] if item['name'] == 'term-bank-parser.wasm')


def once(text, previous, replacement):
    assert text.count(previous) == 1, (text.count(previous), previous)
    return text.replace(previous, replacement, 1)


reports = []
for policy in ['broad-scoped', 'distance2']:
    directory = ROOT / policy
    directory.mkdir(exist_ok=True)
    source = original
    start = source.index('static uint32_t parser_probe_keyrun_glossary(')
    end = source.index('\nstatic inline int next_format3_field', start)
    helper = source[start:end]
    helper = once(helper, 'uint32_t row_count, uint32_t lookback',
                  'uint32_t row_count, uint32_t lookback, uint32_t distance_two_only')
    helper = once(helper, '    for (uint32_t k = row_count; k > first;) {',
                  '    for (uint32_t k = row_count - distance_two_only; k > first;) {')
    source = source[:start] + helper + source[end:]
    start = source.index('        uint32_t probe_lookback = 0u;')
    end = source.index('        if (probe_witness != 0xffffffffu && glossary_witness == 0xffffffffu)', start)
    if policy == 'broad-scoped':
        gate = '''
        if (validated_glossary_reuse_enabled && row_count > 0u) {
            if (probe_key_budget > 0u && probe_key_run > probe_lookback) { probe_lookback = probe_key_run; }
            else if (probe_key_budget == 0u && probe_key_run > probe_lookback) { ++parser_probe_counters[153]; }
        }
'''
    else:
        gate = '''
        if (validated_glossary_reuse_enabled && glossary_lookback == 0u && probe_key_run >= 2u) {
            if (probe_key_budget > 0u) {
                probe_lookback = 2u;
                distance_two_only = 1u;
            } else { ++parser_probe_counters[153]; }
        }
'''
    block = '''
        // Mirror the real parser's original admission exactly. A key-only
        // witness does not change its dense-repeat or long-adjacent budget.
        uint32_t probe_lookback = glossary_lookback;
        uint32_t distance_two_only = 0u;
''' + gate + '''
        ++parser_probe_counters[132u + probe_lookback];
        const uint32_t probe_witness = parser_probe_keyrun_glossary(
            src, source.end, parsed_row->glossary_start, rows, row_count, probe_lookback, distance_two_only);
        if (probe_witness != 0xffffffffu) {
            probe_key_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;
        } else if (probe_lookback > 0u && probe_key_run > 0u && probe_key_budget > 0u) {
            --probe_key_budget;
        }
'''
    source = source[:start] + block + source[end:]
    source_path = directory / 'instrumented.c'
    wasm_path = directory / 'instrumented.wasm'
    source_path.write_text(source)
    command = [str(CLANG), f'-fuse-ld={LINKER}', *target['arguments'], '-o', str(wasm_path), str(source_path),
               str(REPO / 'ext/js/dictionary/wasm/term-bank-inflate.c')]
    subprocess.run(command, check=True)
    report = {
        'scope': 'Untimed exact-baseline admission simulation. Extra comparisons never affect real parser metadata, witnesses, budgets, or output.',
        'policy': policy,
        'policyDetails': 'Keep original admission/budget exactly; broad-scoped mirrors frozen538163e. Distance2 adds only the second previous row when original admission is inactive and an existing key proof spans at least two previous rows. Both stop after four unsuccessful probe rows within a continuous key run.',
        'baseline': old['baseline'], 'previousManifest': str(PREVIOUS / 'build-manifest.json'),
        'sourcePath': str(source_path), 'sourceSha256': hashlib.sha256(source.encode()).hexdigest(),
        'wasmPath': str(wasm_path), 'wasmSha256': hashlib.sha256(wasm_path.read_bytes()).hexdigest(),
        'wasmBytes': wasm_path.stat().st_size, 'counterExport': old['counterExport'],
        'counterWordCount': old['counterWordCount'], 'counterLabels': old['counterLabels'],
        'compiler': subprocess.check_output([str(CLANG), '--version'], text=True).strip(), 'command': command,
    }
    (directory / 'build-manifest.json').write_text(json.dumps(report, indent=2) + '\n')
    (directory / 'run-census.mjs').write_text((PREVIOUS / 'run-census.mjs').read_text())
    reports.append({key: report[key] for key in ('policy', 'sourceSha256', 'wasmSha256', 'wasmBytes')})
print(json.dumps(reports, indent=2))
