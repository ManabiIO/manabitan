#!/usr/bin/env python3
"""Independent libzstd decode of every retained existing-WASM level output."""
import ctypes
import ctypes.util
import hashlib
import json
from pathlib import Path
import sys

assert len(sys.argv) == 4, 'Usage: verify-compression-level-frames.py CENSUS DICTIONARY OUTPUT_JSON'
census_path, dictionary_path, output_path = map(Path, sys.argv[1:])
census_bytes = census_path.read_bytes()
census = json.loads(census_bytes)
assert census['complete'] is True
assert census['sourceCommit'] == '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
dictionary = dictionary_path.read_bytes()
assert hashlib.sha256(dictionary).hexdigest() == census['dictionarySha256']
library_name = ctypes.util.find_library('zstd')
assert library_name
library = ctypes.CDLL(library_name)
library.ZSTD_versionString.restype = ctypes.c_char_p
library.ZSTD_createDCtx.restype = ctypes.c_void_p
library.ZSTD_freeDCtx.argtypes = [ctypes.c_void_p]
library.ZSTD_freeDCtx.restype = ctypes.c_size_t
library.ZSTD_isError.argtypes = [ctypes.c_size_t]
library.ZSTD_isError.restype = ctypes.c_uint
library.ZSTD_getErrorName.argtypes = [ctypes.c_size_t]
library.ZSTD_getErrorName.restype = ctypes.c_char_p
library.ZSTD_decompress_usingDict.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t,
                                             ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t]
library.ZSTD_decompress_usingDict.restype = ctypes.c_size_t
context = library.ZSTD_createDCtx()
assert context
dictionary_buffer = ctypes.create_string_buffer(dictionary)
destination = ctypes.create_string_buffer(max(frame['expectedRawBytes'] for frame in census['frames']))
raw_digest = hashlib.sha256()
rows = []
failure = None
complete = False
try:
    for frame in census['frames']:
        outputs = {}
        for arm in ('A', 'B', 'C'):
            encoded = frame['outputs'][arm]
            data = Path(encoded['path']).read_bytes()
            assert len(data) == encoded['bytes']
            assert hashlib.sha256(data).hexdigest() == encoded['sha256']
            assert data[:4] == b'MBC2'
            compressed = ctypes.create_string_buffer(data[12:])
            size = library.ZSTD_decompress_usingDict(context, destination, frame['expectedRawBytes'],
                                                     compressed, len(data) - 12, dictionary_buffer, len(dictionary))
            assert not library.ZSTD_isError(size), library.ZSTD_getErrorName(size).decode()
            assert size == frame['expectedRawBytes']
            raw = destination.raw[:size]
            digest = hashlib.sha256(raw).hexdigest()
            assert digest == frame['rawSha256']
            if arm == 'A':
                raw_digest.update(raw)
            outputs[arm] = {'level': encoded['level'], 'rawBytes': size, 'rawSha256': digest}
        assert frame['outputs']['D']['sha256'] == frame['outputs']['A']['sha256']
        rows.append({'index': frame['index'], 'groupIndex': frame['groupIndex'], 'outputs': outputs})
    assert raw_digest.hexdigest() == census['rawDigestSha256']
    complete = True
except Exception as error:
    failure = repr(error)
    raise
finally:
    library.ZSTD_freeDCtx(context)
    report = {'complete': complete, 'failure': failure,
              'scope': 'Independent system libzstd decoder, separate from the production WASM encoder/decoder. All three levels and all real blocks checked; raw bytes never retained on disk.',
              'censusPath': str(census_path.resolve()), 'censusSha256': hashlib.sha256(census_bytes).hexdigest(),
              'library': library_name, 'version': library.ZSTD_versionString().decode(),
              'dictionarySha256': hashlib.sha256(dictionary).hexdigest(),
              'rawDigestSha256': raw_digest.hexdigest(), 'verifiedFrames': len(rows), 'frames': rows}
    with output_path.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'complete': complete, 'failure': failure, 'verifiedFrames': len(rows),
                      'version': report['version'], 'output': str(output_path)}))
