# Immediate format-3 comma guard: prospective experiment

## Scope and mechanism

Baseline is `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. The isolated worktree is
`/workspace/scratch/1b47f6463b98/comma-experiment` on
`perf/immediate-format3-comma-20261128-1b47`.

The only intended runtime source change is in `next_format3_field`: check the
logical bound, accept an immediately adjacent comma, and use the existing
whitespace scan and comma validation otherwise. The post-comma whitespace scan,
failure result, position publication, parser modes, and inlining annotation stay
unchanged. The source diff is six insertions and two deletions. Native artifacts
must be regenerated together with their manifest using pinned Clang/LLD 21.1.8.

The baseline source calls the helper seven times per valid strict row. That is
3,698,093 logical separator checks for 528,299 JMdict rows, and 3,055,885 for
436,555 Jitendex rows. These are counts, not elapsed-time predictions.

The actual baseline module, SHA-256
`8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee`, retains a
180-byte outlined helper at function 44. The row parser calls it at five sites;
two other separator checks are inlined. For an immediate comma, current compiled
code first loads the byte for the whitespace test (`byte - 9 > 23`), then repeats
the bound check and byte load before comparing with comma. The proposed guard
can avoid that work. Native engine optimization and code-layout effects still
need measurement. `compiler-baseline.json` preserves the decoded helper and call
locations; no candidate was compiled to obtain this baseline diagnosis.

## Prior-work overlap audit

- [#826](https://github.com/ManabiIO/manabitan/pull/826) introduced the strict
  eight-field parser and the current helper; [#835](https://github.com/ManabiIO/manabitan/pull/835)
  integrated it. The helper is unchanged in the frozen baseline.
- [#669](https://github.com/ManabiIO/manabitan/pull/669) consumes string-value
  commas inside composite glossary parsing. [#892](https://github.com/ManabiIO/manabitan/pull/892)
  consumes child-container commas, and #797 concerns consecutive closing
  containers. These are different parser boundaries.
- Unmerged branch `perf/separator-spaces-fz__3exi`, head
  `784f4569caa5fc9b0cf862764dc0986415ac6581`, includes source commit
  `bed460a0d76794cdab464658c68aa6cea2606dea`. It skips ASCII spaces after
  comma/colon transitions inside the composite parser. It predates the strict
  helper and does not implement this pre-comma guard. The branch has no
  associated PR.
- Searches for `next_format3_field`, `skip_ws`, field separators, comma and
  whitespace PRs/branches found no exact duplicate. This is a scoped audit,
  not proof that every historical unreferenced experiment was discovered.

## Correctness coverage

The new `test/term-bank-format3-separators.test.js` exercises both existing native
parser exports with strict validation enabled. Its 42 cases cover each JSON
whitespace character independently before and after commas, malformed delimiters
at all seven field boundaries, and logical source ends before/inside/after
separators while the remaining valid source is still physically accessible.
Existing strict/generic parity, numeric fallback, source-CRC and fused-output
suites will also run against the generated candidate.

The 42 new cases passed against the unchanged baseline WASM before candidate
compilation. The raw log is `baseline-new-tests.log`. This validates that the
fixtures describe the existing contract, not a new accepted grammar.

## Prospective measurement and current status

No candidate timing or speed claim exists yet. The intended component comparison
uses the independently reviewed `one-arm-native-parser-20261128-1b47-v2`
protocol: six fixed balanced A/B/C blocks, one fresh process and one native
instance per observation, a full excluded warmup, then the complete corpus.
Every source/canonical/full-output digest must match the frozen baseline witness.
The schedule stops at the first failure and cannot retry or replace observations.
It remains a native component diagnostic, with storage, worker concurrency and
whole-import qualification separate.

Execution is waiting for the shared pinned compiler restoration and the earlier
delayed-key-hint candidate's reserved validation/timing slot. No PR is warranted
from the source mechanism alone.
