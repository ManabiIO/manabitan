# Immediate-comma guard: prospective confirmation

The confirmation does not establish a useful parser gain. No promotion or more
measurements follow under the registered stop rule. The original six-block
screen and this separate 24-block confirmation remain intact and unpooled.

Both corpora completed all 72 sequential fresh children. Every child completed
one excluded whole-corpus warmup and one measured corpus, with exact canonical,
raw-source and full-output digests and frozen runtime/native identities. There
were no failed or replaced observations. Peak process RSS was 182,528 KiB for
JMdict and 280,296 KiB for Jitendex.

Baseline is `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`; candidate is
`252686b2edb70dd365838d1730098281653b82b5`, WASM SHA256
`7b65e1c6984a7cd224bdc5aec85e70609f349850d834c7a55703dc94c6fa12a3`.
Both plans were registered before either corpus acquired data. The same-code
controls, all 24 blocks, all phases and the fixed paired-block bootstrap remain.

| Corpus / metric | B/A paired median | B/C paired median | B/A geometric, 95% interval | B/C geometric, 95% interval |
| --- | ---: | ---: | ---: | ---: |
| JMdict inclusive parser component | +1.14% | −0.33% | −0.21% [−3.60%, +2.48%] | −1.19% [−5.50%, +2.92%] |
| JMdict native parse | +0.42% | −0.53% | −0.35% [−4.04%, +2.54%] | −1.58% [−6.41%, +2.86%] |
| Jitendex inclusive parser component | +0.89% | −2.30% | −1.86% [−6.08%, +2.00%] | −3.73% [−7.28%, −0.32%] |
| Jitendex native parse | +1.20% | −2.64% | −1.90% [−6.22%, +2.08%] | −4.07% [−8.73%, +0.22%] |

JMdict's initial small native-phase pattern did not persist. Its inclusive
component arm medians are A 554.52 ms, B 560.77 ms, C 563.75 ms; candidate
medians versus both controls and native intervals do not support a gain.

Jitendex is lower versus C in the geometric inclusive estimate, but its unchanged
inflater also improves 3.50% versus C, closely tracking the 3.73% inclusive
change. B/A and native-parse intervals cross zero. This does not identify the
comma guard as the cause. Identical-code C/A inclusive paired medians are
+1.64% for JMdict and +1.46% for Jitendex; their geometric intervals are wide.

The frozen analysis uses 100,000 complete paired-block resamples, NumPy PCG64
seed 20261128, linear 95% percentile endpoints, and the same index matrix for
all metrics and comparisons. No outlier was removed. These intervals describe
this component protocol; they do not eliminate systematic host drift or measure
the complete browser import.

Raw evidence is in `confirmation-jmdict-v3` and `confirmation-jitendex-v3`:
plans, acquisition markers, every child log/host state/exit/report, observations,
descriptive analysis and the predeclared bootstrap results. Compact complete
attribution is in `confirmation-v3-readout.json`; the exact protocol, scripts,
reviews and analysis declaration are in `../native-child-screen-1b47-v3`.
