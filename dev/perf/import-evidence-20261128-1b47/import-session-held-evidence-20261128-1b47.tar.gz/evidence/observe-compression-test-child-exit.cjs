/* SPDX-License-Identifier: GPL-3.0-or-later */
// Diagnostic preload only: observe own child exits without changing any limit.
const childProcess = require('node:child_process');
const fs = require('node:fs');
const {syncBuiltinESMExports} = require('node:module');
const output = process.env.MANABITAN_CHILD_EXIT_LOG;
if (output) {
    const seen = new WeakSet();
    const observe = (child, api) => {
        if (!seen.has(child)) {
            seen.add(child);
            const write = (event) => fs.appendFileSync(output, `${JSON.stringify({parentPid: process.pid, childPid: child.pid, api, ...event})}\n`);
            child.once('spawn', () => write({event: 'spawn'}));
            child.once('error', (error) => write({event: 'error', code: error.code, message: error.message}));
            child.once('exit', (code, signal) => write({event: 'exit', code, signal}));
        }
        return child;
    };
    for (const api of ['fork', 'spawn']) {
        const original = childProcess[api];
        childProcess[api] = function (...args) { return observe(Reflect.apply(original, this, args), api); };
    }
    syncBuiltinESMExports();
}
