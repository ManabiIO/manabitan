import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/1b47f6463b98/manabitan')
BASE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CLANG = Path('/tmp/manabitan-native-9bb32/native-toolchain/bin/clang')
LINKER = CLANG.with_name('wasm-ld')
SOURCE = 'ext/js/dictionary/wasm/term-bank-parser.c'
LABELS = [
    'rows', 'keyFields', 'readingEqualsSkips', 'adjacentKeyReuse', 'internLookups',
    'internInputBytes', 'internOccupiedProbes', 'internHashMismatch', 'internHighByteMismatch',
    'internLengthMismatchAfterHash', 'internExactComparisons', 'internExactComparedBytes',
    'internMatches', 'internNewKeys', 'internNewBytes', 'contentLookups', 'contentEncodedBytes',
    'contentOccupiedProbes', 'contentHash1Mismatch', 'contentHash2MismatchAfterHash1',
    'contentMixedHighByteMismatch', 'contentLengthMismatchAfterHashes', 'contentExactComparisons',
    'contentExactComparedBytes', 'contentTableMatches', 'contentNewContents', 'recentContentMatches',
    'glossaryWitnessRows', 'glossaryBytes', 'glossaryTextNormalizationRows', 'compositeCalls',
    'compositeBytes', 'compositeDispatchedStringTokens', 'compositeDispatchedStringBytes',
    'compositeContentKeys', 'compositeTagKeys', 'compositeOtherKeys', 'compositeValueStrings',
    'compositeObjects', 'compositeArrays',
]
assert len(LABELS) == 40


def once(source, old, new):
    if source.count(old) != 1:
        raise RuntimeError(f'Expected one occurrence ({source.count(old)}): {old}')
    return source.replace(old, new, 1)


original = subprocess.check_output(['git', 'show', f'{BASE}:{SOURCE}'], cwd=REPO).decode()
source = once(original, 'static uint32_t crc32_table[16][256];',
              'static uint32_t parser_probe_counters[40];\nstatic uint32_t crc32_table[16][256];')
start = source.index('static int parse_composite_span_impl(')
end = source.index('\nstatic int parse_composite_span(', start)
composite = source[start:end]
composite = once(composite,
    "    if (start >= len || (src[start] != '[' && src[start] != '{')) { return 0; }",
    "    if (start >= len || (src[start] != '[' && src[start] != '{')) { return 0; }\n"
    "    ++parser_probe_counters[30];\n    ++parser_probe_counters[src[start] == '{' ? 38 : 39];")
composite = once(composite, '            if (object_key) {',
    '            ++parser_probe_counters[32];\n            parser_probe_counters[33] += s_end - i;\n'
    '            if (object_key) {\n'
    '                ++parser_probe_counters[common_key_kind == COMMON_STRUCTURED_KEY_CONTENT ? 34 :\n'
    '                    common_key_kind == COMMON_STRUCTURED_KEY_TAG ? 35 : 36];\n'
    '            } else { ++parser_probe_counters[37]; }\n            if (object_key) {')
composite = once(composite, '                        if (depth >= MAX_JSON_NESTING) { return 0; }',
    "                        ++parser_probe_counters[src[i] == '{' ? 38 : 39];\n"
    '                        if (depth >= MAX_JSON_NESTING) { return 0; }')
composite = once(composite, '                *out_end = i;\n                return 1;',
    '                parser_probe_counters[31] += i - start;\n                *out_end = i;\n                return 1;')
composite = once(composite, "        if (c == '[' || c == '{') {\n            if (depth >= MAX_JSON_NESTING)",
    "        if (c == '[' || c == '{') {\n            ++parser_probe_counters[c == '{' ? 38 : 39];\n            if (depth >= MAX_JSON_NESTING)")
source = source[:start] + composite + source[end:]

start = source.index('int32_t parse_and_encode_term_bank_token_binary_dedup(')
end = source.index('\n/* Segment compaction consumes', start)
fused = source[start:end]
fused = once(fused, ') {\n    if (', ') {\n    for (uint32_t probe = 0u; probe < 40u; ++probe) { parser_probe_counters[probe] = 0u; }\n    if (')
fused = once(fused, '        const TermRowMeta* parsed_row = &rows[row_count];',
    '        const TermRowMeta* parsed_row = &rows[row_count];\n'
    '        ++parser_probe_counters[0];\n'
    '        parser_probe_counters[27] += glossary_witness != 0xffffffffu;\n'
    '        parser_probe_counters[28] += parsed_row->glossary_length;\n'
    '        parser_probe_counters[29] += parsed_row->glossary_requires_text_normalization != 0u;')
fused = once(fused, '        for (uint32_t field = 0u; field < 2u; ++field) {',
    '        for (uint32_t field = 0u; field < 2u; ++field) {\n            ++parser_probe_counters[1];')
fused = once(fused, '            if (field == 1u && reading_equals_expression) {',
    '            if (field == 1u && reading_equals_expression) {\n                ++parser_probe_counters[2];')
fused = once(fused, '                    string_indexes[field] = field == 0u ?',
    '                    ++parser_probe_counters[3];\n                    string_indexes[field] = field == 0u ?')
fused = once(fused, '            const uint32_t string_hash = hash_content_xxh32(value_source + value_start, value_length, FNV1A_OFFSET);',
    '            ++parser_probe_counters[4];\n            parser_probe_counters[5] += value_length;\n'
    '            const uint32_t string_hash = hash_content_xxh32(value_source + value_start, value_length, FNV1A_OFFSET);')
fused = once(fused, '                if (candidate >= string_unique_count) { return -3; }',
    '                if (candidate >= string_unique_count) { return -3; }\n'
    '                ++parser_probe_counters[6];\n'
    '                parser_probe_counters[7] += string_hashes[candidate] != string_hash;\n'
    '                parser_probe_counters[8] += (string_hashes[candidate] >> 24u) != (string_hash >> 24u);\n'
    '                parser_probe_counters[9] += string_hashes[candidate] == string_hash && string_lengths[candidate] != value_length;\n'
    '                if (string_hashes[candidate] == string_hash && string_lengths[candidate] == value_length) {\n'
    '                    ++parser_probe_counters[10];\n                    parser_probe_counters[11] += value_length;\n                }')
fused = once(fused, '            if (matched_index != 0xffffffffu) {',
    '            if (matched_index != 0xffffffffu) {\n                ++parser_probe_counters[12];')
fused = once(fused, '            string_lengths[string_unique_count] = (uint16_t)value_length;',
    '            ++parser_probe_counters[13];\n            parser_probe_counters[14] += value_length;\n'
    '            string_lengths[string_unique_count] = (uint16_t)value_length;')
fused = once(fused, '        if (recent_match != 0xffffffffu) {',
    '        if (recent_match != 0xffffffffu) {\n            ++parser_probe_counters[26];')
fused = once(fused, '            const uint32_t length = cursor - start;',
    '            const uint32_t length = cursor - start;\n            ++parser_probe_counters[15];\n            parser_probe_counters[16] += length;')
fused = once(fused, '                const uint32_t candidate_offset = candidate_row * 4u;',
    '                const uint32_t candidate_offset = candidate_row * 4u;\n'
    '                ++parser_probe_counters[17];\n'
    '                parser_probe_counters[18] += row_meta[candidate_offset + 2u] != hash1;\n'
    '                parser_probe_counters[19] += row_meta[candidate_offset + 2u] == hash1 && row_meta[candidate_offset + 3u] != hash2;\n'
    '                uint32_t candidate_mixed = row_meta[candidate_offset + 2u] ^ (row_meta[candidate_offset + 3u] * 0x9e3779b1u);\n'
    '                candidate_mixed ^= candidate_mixed >> 16u;\n'
    '                parser_probe_counters[20] += (candidate_mixed >> 24u) != (mixed >> 24u);\n'
    '                if (row_meta[candidate_offset + 2u] == hash1 && row_meta[candidate_offset + 3u] == hash2) {\n'
    '                    parser_probe_counters[21] += row_meta[candidate_offset + 1u] != length;\n'
    '                    if (row_meta[candidate_offset + 1u] == length) {\n'
    '                        ++parser_probe_counters[22];\n                        parser_probe_counters[23] += length;\n                    }\n                }')
fused = once(fused, '            if (matched_row != 0xffffffffu) {',
    '            if (matched_row != 0xffffffffu) {\n                ++parser_probe_counters[24];')
fused = once(fused, '                if (hash_table[slot] != 0u || unique_count == 0xffffffffu) { return -3; }',
    '                if (hash_table[slot] != 0u || unique_count == 0xffffffffu) { return -3; }\n                ++parser_probe_counters[25];')
source = source[:start] + fused + source[end:]
source += '\n__attribute__((export_name("parser_probe_snapshot")))\nuint32_t parser_probe_snapshot(void) { return (uint32_t)(uintptr_t)parser_probe_counters; }\n'
source_path = ROOT / 'instrumented.c'
wasm_path = ROOT / 'instrumented.wasm'
source_path.write_text(source)
manifest = json.loads((REPO / 'dev/data/dictionary-wasm/manifest.json').read_text())
target = next(item for item in manifest['targets'] if item['name'] == 'term-bank-parser.wasm')
command = [str(CLANG), f'-fuse-ld={LINKER}', *target['arguments'], '-o', str(wasm_path), str(source_path),
           str(REPO / 'ext/js/dictionary/wasm/term-bank-inflate.c')]
subprocess.run(command, check=True)
report = {
    'scope': 'Instrumented exact-baseline native work census only; counters alter execution cost, so no timing claim',
    'baseline': BASE,
    'sourcePath': str(source_path),
    'sourceSha256': hashlib.sha256(source.encode()).hexdigest(),
    'wasmPath': str(wasm_path),
    'wasmSha256': hashlib.sha256(wasm_path.read_bytes()).hexdigest(),
    'wasmBytes': wasm_path.stat().st_size,
    'counterExport': 'parser_probe_snapshot',
    'counterWordCount': len(LABELS),
    'counterLabels': LABELS,
    'compiler': subprocess.check_output([str(CLANG), '--version'], text=True).strip(),
    'command': command,
}
(ROOT / 'build-manifest.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ('sourceSha256', 'wasmSha256', 'wasmBytes', 'counterLabels')}))
