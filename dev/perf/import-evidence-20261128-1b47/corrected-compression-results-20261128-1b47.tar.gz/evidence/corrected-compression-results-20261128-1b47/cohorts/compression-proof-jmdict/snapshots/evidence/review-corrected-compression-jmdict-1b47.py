"""Independent read-only bindings review of an already completed fixed artifact.

This is not the frozen qualification reader and does not acquire observations,
reclassify gates, or recompute a different confidence interval.
"""

import hashlib
import io
import json
import statistics
from pathlib import Path
from zipfile import ZipFile


ROOT = Path('/workspace/scratch/1b47f6463b98')
ARCHIVE = Path('/home/agent/manabitan-import-capture-1b47/hosted-artifacts/compression-proof-jmdict-46127578128.zip')
OUTPUT = ROOT / 'evidence/compression-proof-jmdict-independent-review-1b47.json'
FROZEN = ROOT / 'compression-proof-experiment'
PREFIX = 'jmdict/'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def changes(a, b, path=''):
    if type(a) is not type(b):
        return [path]
    if isinstance(a, dict):
        assert a.keys() == b.keys(), path
        return [p for key in a for p in changes(a[key], b[key], path + '/' + key)]
    if isinstance(a, list):
        assert len(a) == len(b), path
        return [p for i, (x, y) in enumerate(zip(a, b)) for p in changes(x, y, path + '/' + str(i))]
    return [] if a == b else [path]


def ratio_summary(records, kind):
    selected = [r for r in records if r['kind'] == kind]
    other = 'B' if kind == 'candidate' else 'C'
    pairs = []
    for index in sorted({r['pair'] for r in selected}):
        by_arm = {r['arm']: r['totalImportMs'] for r in selected if r['pair'] == index}
        assert set(by_arm) == {'A', other}
        pairs.append({'pair': index, 'A': by_arm['A'], other: by_arm[other], 'ratio': by_arm[other] / by_arm['A']})
    return {
        'pairs': pairs,
        'pairedMedianChangePercent': (statistics.median(p['ratio'] for p in pairs) - 1) * 100,
        'equalWorkChangePercent': (sum(p[other] for p in pairs) / sum(p['A'] for p in pairs) - 1) * 100,
        'slowerPairs': sum(p['ratio'] > 1 for p in pairs),
    }


assert not OUTPUT.exists(), 'Do not overwrite an independent review'
archive_bytes = ARCHIVE.read_bytes()
assert len(archive_bytes) == 35597323
assert sha(archive_bytes) == '474415f73dca6b4e34412d6b0b81c6e439d358d475b4588a17667ef6022826d3'
with ZipFile(io.BytesIO(archive_bytes)) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == 314

    def load(path):
        return json.loads(z.read(PREFIX + path))

    plan = load('registered-plan.json')
    ids = load('source-identities.json')
    assert plan['baseline'] == ids['arms']['A']['sha'] == 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16'
    assert plan['candidate'] == ids['arms']['B']['sha'] == '3256036ff8534ba6de7bc9ecd74ec74d3c705603'
    assert plan['pairs'] == 6 and plan['initialOrder'] == 'AB'
    assert plan['expectedWorkers'] == 3 and plan['flags'] == {}
    assert plan['sourceContext'] == ids['sourceContext']
    tooling = {}
    for group in ['studyToolingSha256', 'originalToolingSha256', 'previousTrialToolingSha256']:
        for path, expected in plan[group].items():
            actual = sha((FROZEN / path).read_bytes())
            assert actual == expected, path
            tooling[path] = actual
    product_sources = {}
    for path, expected in plan['frozenProductBlobs'].items():
        actual = git_blob((FROZEN / path).read_bytes())
        assert actual == expected, path
        product_sources[path] = actual

    packages, package_data = {}, {}
    for arm in 'AB':
        data = z.read(PREFIX + f'package-{arm}.zip')
        assert sha(data) == ids['arms'][arm]['packageSha256']
        with ZipFile(io.BytesIO(data)) as package:
            assert len(package.namelist()) == len(set(package.namelist()))
            members = {i.filename: package.read(i.filename) for i in package.infolist() if not i.is_dir()}
        digests = {path: sha(data) for path, data in members.items()}
        assert digests == ids['arms'][arm]['entries'], arm
        package_data[arm] = members
        packages[arm] = {'sha256': sha(data), 'memberCount': len(members), 'source': ids['arms'][arm]['sha'], 'tree': ids['arms'][arm]['tree']}
    assert package_data['A'].keys() == package_data['B'].keys()
    different = [p for p in package_data['A'] if package_data['A'][p] != package_data['B'][p]]
    assert different == ids['changedPackageEntries'] == ['js/dictionary/zstd-term-content.js']
    runtime = package_data['B'][different[0]]
    assert git_blob(runtime) == '9a63ef28bcf862108c407c5636eb492009ba815f'
    assert sha(runtime) == 'e4f3858167076d76c6ad4729afb26ba637530fe9edd6c966fe2a86f6fa856de5'
    wasm_path = 'lib/term-bank-parser.wasm'
    assert sha(package_data['A'][wasm_path]) == sha(package_data['B'][wasm_path]) == '5d216041823936521f8a70b721472fb8c42052d165d771a92b59ed967d8d2695'
    for filename, field in [('harness-original.js', 'originalSha256'), ('harness-proof.js', 'proofSha256'), ('harness-memory.js', 'memorySha256')]:
        assert sha(z.read(PREFIX + 'proof-overlay/' + filename)) == plan['proofOverlay'][field]

    observations = load('observations.json')
    assert [{k: r[k] for k in ['arm', 'id', 'kind', 'pair']} for r in observations] == plan['schedule']
    assert len(observations) == 20
    receipt_paths = sorted(n[len(PREFIX):-len('/canonical-receipt.json')] for n in z.namelist() if n.startswith(PREFIX) and n.endswith('/canonical-receipt.json'))
    expected_paths = sorted([r['id'] for r in observations] + ['exhaustive-media-A', 'exhaustive-media-B'] + ['memory/' + r['name'] for r in plan['memorySchedule']])
    assert receipt_paths == expected_paths and len(receipt_paths) == 26
    family_proof, family_receipt, family_comparison = {}, {}, {}
    decoded_anchor = None
    observation_reviews = []
    total_rows = 0
    for path in receipt_paths:
        arm = path.split('/')[-1][0] if path.startswith('memory/') else path[-1]
        family = 'B' if arm == 'B' else 'A'
        receipt = load(path + '/canonical-receipt.json')
        proof = load(path + '/compression-proof.json')
        summary = load(path + '/summary.json')
        raw = load(path + '/run-1.json')
        comparison = load(path + '/comparison-receipt.json')
        assert raw['benchmark']['compressionProof'] == proof
        assert raw['status'] == 'success' and raw['failureReason'] == ''
        validation = receipt['common']['validation']
        assert proof['schemaVersion'] == 1 and proof['domain'] == 'manabitan-compression-proof-v1'
        assert proof['dictionary'] == {k: validation[k] for k in ['title', 'revision', 'probeTerms']}
        terms = validation['probeTerms']
        assert len(terms) == len(set(terms)) == 12
        storage = validation['storage']
        content_files = [r for r in storage['files'] if r['path'] == 'manabitan-term-content.bin']
        assert len(content_files) == 1
        content_bytes = content_files[0]['bytes']
        assert storage['bytes'] == (43832881 if family == 'B' else 43520477)
        assert content_bytes == (19879084 if family == 'B' else 19566680)
        assert 'compressionLogicalProjection' not in validation
        assert 'outputDigestSha256' not in comparison['common']['validation']
        assert comparison['common']['validation']['compressionLogicalProjection']['domain'] == 'manabitan-compression-logical-projection-v1'
        for section in ['physical', 'references', 'decoded']:
            assert proof[section]['preRestart'] == proof[section]['postRestart'], (path, section)
        physical = proof['physical']['preRestart']
        data = physical['json'].encode('utf-8')
        assert len(data) == physical['utf8Bytes'] and sha(data) == physical['sha256'] == validation['outputDigestSha256']
        physical_rows = json.loads(physical['json'])
        assert len(physical_rows) == len(proof['references']['preRestart']) == 12
        row_count = 0
        for term, physical_group, ref_group in zip(terms, physical_rows, proof['references']['preRestart']):
            assert physical_group['term'] == ref_group['term'] == term
            assert len(physical_group['probes']) == len(ref_group['probes'])
            for probe, refs in zip(physical_group['probes'], ref_group['probes']):
                assert probe['term'] == refs['term'] == term
                assert probe['totalLength'] in [-1, content_bytes]
                assert probe['rowSampleCount'] == len(probe['rowSample']) == len(refs['rows']) > 0
                assert probe['outOfBoundsRowCount'] == 0
                assert probe['glossaryReadyRowCount'] == probe['readablePreviewRowCount'] == probe['rowSampleCount']
                for physical_row, ref in zip(probe['rowSample'], refs['rows']):
                    for key in ['rawEntryContentOffset', 'rawEntryContentLength', 'glossaryLength']:
                        assert physical_row[key] == ref[key]
                    assert 0 <= ref['rawEntryContentOffset'] and ref['rawEntryContentOffset'] + 20 <= content_bytes
                    assert ref['decodedContentLength'] == ref['rawEntryContentLength'] > 0
                    assert ref['rawEntryContentDictName'] == 'raw-block-v2:jmdict'
                    assert ref['dictionary'] == validation['title'] and ref['readErrorDetails'] is None
                    assert physical_row['rawContentPreview'] not in ['', '<read-null>', '<read-failed>']
                    row_count += 1
        decoded = proof['decoded']['preRestart']
        assert [r['term'] for r in decoded] == terms
        if decoded_anchor is None:
            decoded_anchor = decoded
        assert decoded == decoded_anchor
        for result in decoded:
            data = result['resultJson'].encode('utf-8')
            assert len(data) == result['utf8Bytes'] and sha(data) == result['sha256']
            result_json = json.loads(result['resultJson'])
            assert len(result_json['dictionaryEntries']) == result['results'] > 0
            assert result_json['originalTextLength'] == result['originalTextLength'] == len(result['term'].encode('utf-16-le')) // 2
            assert result['hasExactHeadwordMatch'] is True
        lookup = validation['lookup']['observations']
        assert len(lookup) == 72
        by_term = {r['term']: r for r in decoded}
        for record in lookup:
            witness = by_term[record['term']]
            for key in ['sha256', 'results', 'originalTextLength', 'hasExactHeadwordMatch']:
                assert record[key] == witness[key], (path, key)
        source = summary['source']
        expected_hashes = dict(ids['arms'][family]['sourceHashes'])
        expected_hashes[plan['proofOverlay']['path']] = plan['proofOverlay']['memorySha256' if path.startswith('memory/') else 'proofSha256']
        assert source['sha256'] == expected_hashes and source['dirty'] is True
        assert source['gitSha'] == summary['gitSha'] == ids['arms'][family]['sha']
        assert summary['runs'][0]['packageSha256'] == ids['arms'][family]['packageSha256']
        fast = [p for p in summary['runs'][0]['importDebug']['importerPhaseTimings'] if p['phase'].startswith('term-file-fast-path:')]
        assert len(fast) == 1
        details = fast[0]['details']
        assert details['parserParallelWorkerCount'] == 3
        assert details['rows'] == 528299 and details['chunkCount'] == 12 and details['parserBankSpanCount'] == 53
        receipt_without_media = {k: v for k, v in receipt.items() if k != 'media'}
        comparison_without_media = {k: v for k, v in comparison.items() if k != 'media'}
        family_proof.setdefault(family, proof)
        family_receipt.setdefault(family, receipt_without_media)
        family_comparison.setdefault(family, comparison_without_media)
        assert proof == family_proof[family]
        assert receipt_without_media == family_receipt[family]
        assert comparison_without_media == family_comparison[family]
        observation_reviews.append({'path': path, 'arm': arm, 'physicalDigest': physical['sha256'], 'sampledReferenceRows': row_count, 'decodedTerms': len(decoded), 'existingLookupDigests': len(lookup), 'totalStoredBytes': storage['bytes'], 'contentStoredBytes': content_bytes, 'sourceBindingsExact': True})
        total_rows += row_count
    assert family_comparison['A'] == family_comparison['B']
    assert family_proof['A']['physical'] != family_proof['B']['physical']
    physical_changes = changes(json.loads(family_proof['A']['physical']['preRestart']['json']), json.loads(family_proof['B']['physical']['preRestart']['json']))
    assert all(p.endswith(('/rawContentPreview', '/rawEntryContentOffset', '/totalLength')) for p in physical_changes)
    ref_changes = changes(family_proof['A']['references']['preRestart'], family_proof['B']['references']['preRestart'])
    assert all(p.endswith('/rawEntryContentOffset') for p in ref_changes)
    media_a = load('exhaustive-media-A/canonical-receipt.json')['media']
    assert media_a == load('exhaustive-media-B/canonical-receipt.json')['media']
    assert media_a['mode'] == 'all' and media_a['files'] == 0 and media_a['bytes'] == 0
    for observation in observations:
        assert observation['totalImportMs'] == load(observation['id'] + '/summary.json')['runs'][0]['totalImportMs']
    timing = ratio_summary(observations, 'candidate')
    controls = ratio_summary(observations, 'control')
    analysis = load('analysis.json')
    assert analysis['status'] == 'correctness-memory-passed' and analysis['memoryPassed'] is True
    memories = []
    for entry in plan['memorySchedule']:
        memory = load('memory/' + entry['name'] + '/memory.json')
        assert len(memory['samples']) == memory['allObservedSampleCount']
        memories.append({**entry, 'rawScans': len(memory['samples']), 'gapMs': memory['maximumCoveredSampleGapMs'], 'qualified': memory['qualifiedForWholeTreePss'], 'failures': memory['qualificationFailures'], 'maxSampledPrivateKiB': memory['maxSampledPrivateKiB'], 'maxSampledPssKiB': memory['maxSampledPssKiB']})
    assert sum(m['rawScans'] for m in memories) == 256
    assert all(m['qualified'] is True and m['failures'] == [] and m['gapMs'] <= 250 for m in memories)
    assert load('memory/semantic-failures.json') == []
    comparison = load('memory/memory-comparison.json')
    assert comparison['everyObservationQualified'] is True and comparison['passesProspectiveMemoryScreen'] is True
    memory_metrics = {}
    for metric in ['maxSampledPrivateKiB', 'maxSampledPssKiB']:
        changes = []
        for pair in [1, 2]:
            values = {m['arm']: m[metric] for m in memories if m['pair'] == pair}
            assert set(values) == {'A', 'B'} and all(v > 0 for v in values.values())
            changes.append((values['B'] / values['A'] - 1) * 100)
        memory_metrics[metric] = {'medianPairedChangePercent': statistics.median(changes), 'maximumPairedChangePercent': max(changes)}
        assert all(abs(v - comparison['metrics'][metric][k]) < 1e-10 for k, v in memory_metrics[metric].items())
        assert memory_metrics[metric]['medianPairedChangePercent'] <= 5 and memory_metrics[metric]['maximumPairedChangePercent'] <= 10
    restoration = load('overlay-restoration.json')
    assert restoration['errors'] == [] and len(restoration['observations']) == 2
    for result in restoration['observations']:
        assert result['originalHarnessSha256'] == plan['proofOverlay']['originalSha256']
        assert result['packageBytesUnchanged'] is True and result['trackedTreeClean'] is True

    result = {
        'scope': 'Independent read-only original-artifact binding and claim review; no acquisition, product/protocol edits, gate rerun, replacement observation, or new confidence interval.',
        'reviewScriptSha256': sha(Path(__file__).read_bytes()),
        'archive': {'path': str(ARCHIVE), 'sha256': sha(archive_bytes), 'bytes': len(archive_bytes), 'members': 314},
        'registeredPlanSha256': sha(z.read(PREFIX + 'registered-plan.json')),
        'frozenAuditorSha256': tooling['dev/perf/import-compression-proof-20261128-1b47/audit_artifact.py'],
        'sourceContext': ids['sourceContext'], 'toolingFilesChecked': tooling, 'frozenProductBlobsChecked': product_sources,
        'packages': packages, 'changedPackageEntries': different, 'candidateRuntimeGitBlob': git_blob(runtime), 'commonParserWasmSha256': sha(package_data['A'][wasm_path]),
        'scopeCounts': {'allReportsAndProofs': 26, 'timingWarmupControl': 20, 'measuredPairs': 6, 'identicalCodeControlPairs': 2, 'fullMediaObservations': 2, 'memoryObservations': 4, 'rawMemoryScans': 256},
        'all26RawProofSidecarBindings': True, 'all26SourceHarnessPackageBindings': True,
        'sameFamilyProofAndPhysicalReceiptsExactExceptExplicitMediaMode': True,
        'allPrePostPhysicalReferenceAndDecodedProofsExact': True,
        'allFullDecodedSampleJsonAcrossArmsExact': True,
        'all72OriginalLookupDigestBindingsPerObservationExact': True,
        'labeledCrossArmLogicalComparisonExact': True,
        'physicalCrossArmChangedPaths': physical_changes, 'referenceCrossArmChangedPaths': ref_changes,
        'exhaustiveMedia': media_a, 'observations': observation_reviews,
        'timingRecomputed': timing, 'identicalControlRecomputed': controls,
        'reportedPrimaryDescriptiveIntervalPercent': [-0.48113143011534465, 3.591868207461113],
        'descriptiveIntervalSource': 'Frozen reader/analysis; independently recomputed paired median and equal-work only, without replacing its original bootstrap.',
        'memory': memories, 'memoryMetricsRecomputed': memory_metrics, 'memoryAggregateQualified': True,
        'restoration': restoration,
        'conclusion': 'No blocker found in the recorded artifact bindings. This complete cohort passes the original sampled semantics, exact-storage, restoration and memory gates, but its primary paired median and equal-work changes are positive with five of six slower pairs. It supplies no qualifying speedup and satisfies the frozen adverse-corpus rule; no compression PR.',
        'limits': ['Decoded equality covers the twelve pinned sampled lookup terms plus their 72 original lookup observations, not every dictionary entry.', 'The physical offset is a bounded 20-byte OPFS reference address and may differ across compression representations; decoded entry length is a different quantity.', 'The old failed trial lacked these preimages. These new actual preimage differences do not retroactively identify its exact differing input.', 'Passing the two-pair sampled memory screen is not an exact peak-memory or universal non-regression claim; all raw scans and original coverage rules remain unchanged.', 'This review does not infer first-use behavior from the prior warm compression component or substitute phase times for import wall time.'],
    }
OUTPUT.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'output': str(OUTPUT), 'sha256': sha(OUTPUT.read_bytes()), 'bytes': OUTPUT.stat().st_size, 'counts': result['scopeCounts'], 'physicalChangedPathCount': len(physical_changes), 'referenceChangedPathCount': len(ref_changes), 'medianPercent': timing['pairedMedianChangePercent'], 'equalWorkPercent': timing['equalWorkChangePercent'], 'memoryQualified': True}))
