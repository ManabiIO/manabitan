# Corrected compression JMdict: independent review

The final fixed JMdict cohort passes its original correctness, exact-storage and sampled-memory gates, but **does not establish an import speedup**. Five of six candidate pairs are slower, with positive paired-median and equal-work changes. The frozen review rule therefore supports closing the compression mechanism without a product PR, consistent with the already adverse Jitendex result.

## Original artifact and source bindings

This independent read-only review uses run **46127578128**, artifact **15257700957**: 35,597,323 bytes, SHA-256 `474415f73dca6b4e34412d6b0b81c6e439d358d475b4588a17667ef6022826d3`, containing 314 members. All 26 observations are present: four warmups, six measured A/B pairs, two identical-code A/C pairs, two exhaustive-media observations and four separate memory observations. There are no replacement or reused old-trial observations.

The actual nested A/B extension ZIPs match their recorded member inventories. Their only differing member is `js/dictionary/zstd-term-content.js`, with candidate Git blob `9a63ef28bcf862108c407c5636eb492009ba815f`. Both retain the current `dcfc02a0` parser WASM. The registered common baseline is `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`; candidate head is `3256036ff8534ba6de7bc9ecd74ec74d3c705603`. All registered tooling hashes and the unchanged compression product/test blobs match their frozen sources.

Every report uses its expected package and the symmetric registered proof harness; the four memory observations use the separately registered marker composition. Source restoration records show the original harness restored, clean tracked trees and unchanged package bytes. The original import endpoint and original validation/canonical receipt structures remain unchanged; the full report receives the registered additive proof.

## Semantic and storage evidence

All 26 additive proof sidecars equal their raw report objects. Physical JSON preimages reproduce the original physical digests and match across restart. Reference rows bind positionally to those preimages, preserve decoded lengths and the required format, and remain within their independently inventoried content file using the actual **20-byte physical reference width**. Raw proofs remain exact within A/C and within B across all observation stages.

Cross-arm physical preimages contain 16 different previews and 11 different reference offsets; no `totalLength` field differs. Those are permitted representation differences in this new cohort. They do not retrospectively identify the missing preimage differences from the original failed trial.

Full decoded result JSON agrees across arms and restart for all **12 pinned sampled lookup terms**; each report's 72 existing lookup observations binds to the same results. Separately labeled logical comparison copies agree while the original physical receipts remain intact. This proves the declared sampled/restart boundary, not equality of every dictionary entry. The two exhaustive-media checks agree on the pinned JMdict archive's zero media files and zero media bytes.

All observations import 528,299 rows from 53 banks in 12 groups with three parser workers. Content bytes change from **19,566,680 to 19,879,084**, and total logical stored bytes from **43,520,477 to 43,832,881**: exactly **+312,404 bytes** in each case, or **+0.717832%** total, within the unchanged 2% allowance.

## Primary result and original memory screen

| Original primary statistic |            Candidate B/A |       Identical-code C/A |
| -------------------------- | -----------------------: | -----------------------: |
| Paired-median change       |               +2.156437% |               −1.834986% |
| Equal-work change          |               +1.748931% |               −1.834250% |
| Descriptive 95% interval   | [−0.481131%, +3.591868%] | [−1.992567%, −1.677406%] |
| Faster pairs               |                      1/6 |                      2/2 |

All six candidate changes remain: **+2.056996%, +2.904696%, +0.211864%, −1.174127%, +4.279040%, +2.255878%**. The paired median and equal-work values independently reproduce from the original observations and raw summary clocks; the interval remains the original frozen analysis, with no replacement bootstrap or control subtraction. Its interval crossing zero prevents a strong general latency-regression claim, but the prospectively fixed review rule rejects a compression PR when at least five of six pairs are slower and both primary changes are positive. That condition is met here.

All **256 raw memory scans** are retained. The four maximum covered-sample gaps are **199.915732, 213.212257, 215.730288 and 196.976755 ms**, each within 250 ms. All four observations qualify. Recomputed paired sampled-private changes are **−1.452455% median / +0.354103% maximum**; PSS changes are **−1.122900% / +0.392272%**. These meet the original ≤5% median / ≤10% maximum screen. This is a passing bounded sampled-memory comparison, not an exact peak-memory or general non-regression guarantee.

No additional phase analysis is needed to interpret this result. There is no qualifying whole-import gain in either corrected corpus, and Jitendex separately fails memory coverage. The earlier warm component saving does not override these complete-import observations.

## Review receipts

- [Independent checks and all observation records](compression-proof-jmdict-independent-review-1b47.json).
- [Read-only review helper](review-corrected-compression-jmdict-1b47.py), [derivation receipt](review-corrected-compression-jmdict-derivation-1b47.json) and [exact derivation patch](review-corrected-compression-jmdict-derivation-1b47.patch).
- Original frozen audit, summary and log: `hosted-compression-proof-jmdict-46127578128/`.

The helper was derived from the already successful Jitendex review, changing only corpus/archive/work/storage/media constants, the actual passing memory assertions and the corpus-specific result. Its first JMdict execution passed. The earlier Jitendex review-helper status-schema assumption remains preserved in that separate packet. No raw artifact, frozen reader, product source, protocol, gate or acquisition was changed.
