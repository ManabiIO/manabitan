# Corrected compression JMdict result

The single fixed corrected JMdict cohort completed all observations and passed its semantic, exact-storage, proof, restoration and sampled-memory gates. Its whole-import timing is unfavorable and does not support a compression product PR. Passing qualification is distinct from a latency gain or non-regression claim. No observation was omitted or repeated.

| Comparison | Paired median | Equal-work change | Descriptive 95% interval | Faster pairs |
| --- | ---: | ---: | --- | ---: |
| Candidate B / baseline A | +2.156437% | +1.748931% | −0.481131% to +3.591868% | 1 / 6 |
| Identical C / A | −1.834986% | −1.834250% | −1.992567% to −1.677406% | 2 / 2 |

The six candidate changes are +2.056996%, +2.904696%, +0.211864%, -1.174127%, +4.279040%, +2.255878%. Five slower pairs plus positive paired-median and equal-work changes trigger the declared adverse-other-corpus review rule. Neither this cohort nor the separate Jitendex cohort has the required useful complete-import signal. This is descriptive review triage, with no control subtraction, pooling, replacement or further variant.

All 26 original reports/receipts, additive physical/decoded lookup proofs, comparison copies, exact storage policies, sampled lookup bindings, exhaustive-media checks, per-family physical stability, source/package/timer links and final harness restoration pass the unchanged frozen reader. The only packaged change is `js/dictionary/zstd-term-content.js`. Storage is exactly 43,520,477 → 43,832,881 bytes (+312,404; +0.717832% total), including content 19,566,680 → 19,879,084 bytes. The fixed prediction and 2% budget pass without recalibration.

All 256 raw memory scans are retained and all four observations qualify. Paired sampled PSS changes have median −1.122900% and maximum +0.392272%; private-byte changes have median −1.452455% and maximum +0.354103%. These remain sampled, non-atomic import-window observations, not exact peak measurements. Maximum covered gaps range from 196.976755 to 215.730288 ms, within the unchanged 250 ms limit. There are no semantic failures.

Run `46127578128`, job `140928447987`, source `3256036ff8534ba6de7bc9ecd74ec74d3c705603`, common baseline `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`. Artifact `15257700957` has 314 members (312 non-package), 35,597,323 bytes, SHA-256 `474415f73dca6b4e34412d6b0b81c6e439d358d475b4588a17667ef6022826d3`. Frozen reader SHA-256 `7e9dd7a9992652e73c0e07417b4b5824f077944af6506b8468353a52be076121` recomputes the 6/2 statistics and all gates. Exact inputs, outputs, source context, environment and every timing observation are in `audit.json` and `result-summary.json`. Chrome 153.0.8010.12 / Node 22.22.0 ran with no import flags.

The original failed compression studies remain unchanged and separate. Both corrected fixed cohorts are complete; no compression product PR follows. All authorized performance acquisition is finished.
