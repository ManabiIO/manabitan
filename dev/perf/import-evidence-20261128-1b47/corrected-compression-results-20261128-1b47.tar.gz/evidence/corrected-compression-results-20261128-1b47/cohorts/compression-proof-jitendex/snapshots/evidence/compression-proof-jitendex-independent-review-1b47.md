# Corrected compression Jitendex: independent review

The complete fixed cohort supports **no compression PR**. The artifact bindings and sampled semantic proofs are consistent, but the original whole-import result is adverse and the separate memory comparison fails its unchanged coverage requirement. Neither failure is repaired by this review.

## Scope and source identity

This review reads the original artifact from run **46127578128**, job **140928447909**, artifact **15257054083**. The ZIP is 35,954,051 bytes, SHA-256 `0afcede0f142dcaa9565490f97fd52c742119607305954a25ddc23cf60505463`, with 314 members. It contains all 20 timing/warmup/control observations, two exhaustive-media observations and four separate memory observations. The original frozen reader completed successfully as an audit of a **failed qualification**.

Both actual nested extension packages match their recorded member inventories. Their only differing member is `js/dictionary/zstd-term-content.js`; the candidate has Git blob `9a63ef28bcf862108c407c5636eb492009ba815f`. Both include the current `dcfc02a0` parser WASM, SHA-256 `5d216041823936521f8a70b721472fb8c42052d165d771a92b59ed967d8d2695`. The A baseline is `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`; B is the fixed corrected study head `3256036ff8534ba6de7bc9ecd74ec74d3c705603`. Historical `f7980e63` identifies the unchanged compression product origin, while `9e10d3b3` supplies only the original exact storage prediction.

All 26 reports bind to their expected package, source commit and registered proof or proof-plus-memory harness hash. The original helpers and the 15 registered study/helper files match their frozen bytes. Recorded final restoration returns both trees to the original harness, clean tracked state and unchanged built packages. There is no product overlay.

## What the proof establishes

All 26 additive proof sidecars equal the corresponding raw report objects. Physical JSON preimages reproduce each original physical digest and are exact before and after restart. Reference rows bind positionally to those preimages, retain the required format and decoded lengths, and have valid 20-byte physical reference ranges within the independently inventoried content file. Each A/C family and B family retains exact physical proof across warmup, timing, media and memory observations.

The two representations have 14 differing raw previews and 10 differing physical reference offsets; no `totalLength` field differs. These permitted differences occur in the newly captured physical preimages. They do not retroactively identify the exact cause of the older trial's digest mismatch, whose preimages were absent.

The full decoded result JSON for all **12 pinned sampled terms** agrees across representations and before/after restart. Each observation's 72 original lookup digests binds to those same results. The separately labeled logical comparison copies agree, while raw physical receipts remain intact. This is strong sampled/restart evidence, **not an exhaustive comparison of every dictionary entry**. The separate exhaustive-media receipts agree for all 236 files and 4,992,155 bytes.

The exact storage predicate also passes: content bytes increase from 38,386,795 to 39,136,813, and total logical stored bytes from 67,466,332 to 68,216,350. Both deltas are **+750,018 bytes**, a **1.111692%** total increase within the original 2% allowance.

## Original result and disposition

The original six pairs give a **+4.483507% paired median** and **+6.803567% equal-work change**, with five pairs slower. The frozen descriptive interval is **[−1.152391%, +17.259416%]**; the largest retained pair is **+20.266945%**. The two identical-code controls are −0.290894% by paired median and −0.296139% by equal work. No pair is discarded, adjusted by the controls or replaced.

All 291 raw memory scans remain available. Baseline A1 has a maximum covered-sample gap of **278.445886 ms**, exceeding the fixed 250 ms limit. The other three observations qualify, but the aggregate remains unqualified and its paired memory summaries remain null. This is a coverage failure, not evidence of a measured memory regression.

The prospectively frozen adverse-other-corpus rule applies because at least five of six pairs are slower and both primary changes are positive. That and the independent failed memory gate each block a compression PR, regardless of the remaining JMdict outcome.

## Post-outcome phase context

At the parent's request **after the primary result**, a separate descriptive read examines the same six pairs and two controls. It introduces no observation, interval, endpoint or gate. Input and dedup work counters are identical across all 16 measured/control reports: 436,555 rows, 219 banks, 22 groups, three parser workers and 363,243 unique persisted content entries. Content writes remain five calls, with the exact additional 750,018 bytes; record-file writes remain one 45-byte call.

| Recorded phase aggregate      | B/A paired median | B/A equal work | Lower B pairs | C/A paired median |
| ----------------------------- | ----------------: | -------------: | ------------: | ----------------: |
| Compression owner             |            −4.17% |         −3.48% |           4/6 |            −2.41% |
| Inclusive content persistence |            −3.10% |         −3.61% |           3/6 |            −0.11% |
| Content append residual       |            −5.22% |         +1.85% |           4/6 |           +30.97% |
| Bulk term addition            |            −2.53% |         −1.78% |           3/6 |            −0.64% |
| Dedup scan                    |            +7.33% |         +4.86% |           2/6 |            −1.06% |
| Native parser work            |            +2.21% |         +1.17% |           2/6 |            −5.16% |
| Source inflation              |            +6.86% |         +6.62% |           0/6 |            +1.34% |
| Record append                 |           −19.13% |        −16.24% |           5/6 |           −26.23% |
| Bulk finalization             |            +4.23% |        +35.38% |           1/6 |            +0.38% |

Some reduction is visible in the existing compression owner, but it is not consistent across all pairs and the identical-code controls also move. The source shows that this timer spans awaited batch completion, including dispatch, readiness and worker-return effects; it is not an isolated codec CPU measurement. Content persistence includes that work and can overlap record append. The append residual excludes separately measured reference generation and is not a syscall-only storage timer. Worker parser/inflate durations have different scopes again.

The adverse endpoint coexists with higher inflation in every pair and a longer finalization tail, including pair 3's 135→364 ms and pair 4's 134→201 ms. These are retained descriptive observations, not a causal explanation. The overlapping phase values must not be added or subtracted to reconstruct import time, remove the adverse tail, or transfer the earlier warm component benefit to a complete browser import.

## Reproduction and review limits

- [Independent binding review](compression-proof-jitendex-independent-review-1b47.json) and [read-only helper](review-corrected-compression-jitendex-1b47.py).
- [Post-outcome phase records](compression-proof-jitendex-post-outcome-phase-context-1b47.json) and [descriptive helper](compression-proof-jitendex-post-outcome-phase-context-1b47.py), including all selected pair values and source timer boundaries.
- Original frozen audit, summary and log: `hosted-compression-proof-jitendex-46127578128/`.
- The independent helper's initial incorrect assumption that successful `failureReason` was null is preserved in `compression-proof-jitendex-review-helper-initial-schema-failure.json` and its before-correction source. Actual successful reports use an empty string. This was a review-helper schema failure before any review output, not a trial failure or a change to the frozen reader.

No raw report, frozen policy, source, gate or acquisition was changed by this review.
