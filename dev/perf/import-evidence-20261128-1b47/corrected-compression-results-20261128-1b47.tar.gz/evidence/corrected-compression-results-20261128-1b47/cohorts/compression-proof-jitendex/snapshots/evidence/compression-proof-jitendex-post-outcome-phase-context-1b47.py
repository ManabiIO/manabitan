"""Post-outcome descriptive phase context from an existing failed cohort.

No acquisition, confidence interval, new endpoint, gate, control subtraction,
phase arithmetic, or performance qualification is performed here.
"""

import hashlib
import io
import json
import statistics
from pathlib import Path
from zipfile import ZipFile


ROOT = Path('/workspace/scratch/1b47f6463b98')
ARCHIVE = Path('/home/agent/manabitan-import-capture-1b47/hosted-artifacts/compression-proof-jitendex-46127578128.zip')
OUTPUT = ROOT / 'evidence/compression-proof-jitendex-post-outcome-phase-context-1b47.json'
METRICS = [
    'contentCompressMs', 'contentStoreMs', 'contentOpfsAppendMs',
    'bulkAddTermsMs', 'dedupScanMs', 'parserParseBankMs',
    'parserSourceInflateMs', 'termRecordWriteMs', 'bulkFinalizationMs',
]
WORK = [
    'rows', 'chunkCount', 'parserBankSpanCount', 'parserParallelWorkerCount',
    'parserEncodedContentBytes', 'parserSourceCompressedBytes',
    'parserSourceUncompressedBytes', 'dedupUniqueCount', 'dedupPendingHitCount',
    'dedupPersistedHitCount', 'parserBorrowedContentResultCount',
    'contentInitialReservationCount', 'contentInitialReservationSavingsMissCount',
]
WRITE_WORK = ['termContentWriteCallCount', 'termContentTotalWriteBytes', 'termRecordWriteCallCount', 'termRecordTotalWriteBytes']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def stats(records, kind, metric):
    selected = [r for r in records if r['kind'] == kind]
    other = 'B' if kind == 'candidate' else 'C'
    pairs = []
    for pair in sorted({r['pair'] for r in selected}):
        values = {r['arm']: r['metricsMs'][metric] for r in selected if r['pair'] == pair}
        assert set(values) == {'A', other}
        assert values['A'] > 0 and values[other] > 0
        ratio = values[other] / values['A']
        pairs.append({'pair': pair, 'A_ms': values['A'], other + '_ms': values[other], 'changePercent': (ratio - 1) * 100})
    return {
        'pairedChangesPercent': [p['changePercent'] for p in pairs],
        'pairedMedianChangePercent': statistics.median(p['changePercent'] for p in pairs),
        'equalWorkChangePercent': (sum(p[other + '_ms'] for p in pairs) / sum(p['A_ms'] for p in pairs) - 1) * 100,
        'A_medianMs': statistics.median(p['A_ms'] for p in pairs),
        other + '_medianMs': statistics.median(p[other + '_ms'] for p in pairs),
        'lowerPairs': sum(p['changePercent'] < 0 for p in pairs),
        'pairCount': len(pairs),
    }


assert not OUTPUT.exists()
data = ARCHIVE.read_bytes()
assert sha(data) == '0afcede0f142dcaa9565490f97fd52c742119607305954a25ddc23cf60505463'
with ZipFile(io.BytesIO(data)) as z:
    observations = json.loads(z.read('jitendex/observations.json'))
    records = []
    for observation in observations:
        if observation['kind'] == 'warmup':
            continue
        assert observation['kind'] in ['candidate', 'control']
        summary_data = z.read('jitendex/' + observation['id'] + '/summary.json')
        run = json.loads(summary_data)['runs'][0]
        phases = run['importDebug']['importerPhaseTimings']
        fast = [p for p in phases if p['phase'].startswith('term-file-fast-path:')]
        final = [p for p in phases if p['phase'] == 'bulk-finalization']
        assert len(fast) == len(final) == 1
        details = fast[0]['details']
        metrics = {name: details[name] for name in METRICS if name != 'bulkFinalizationMs'}
        metrics['bulkFinalizationMs'] = final[0]['elapsedMs']
        records.append({
            **observation, 'summarySha256': sha(summary_data), 'metricsMs': metrics,
            'work': {name: details[name] for name in WORK},
            'writeWork': {name: final[0]['details'][name] for name in WRITE_WORK},
        })
    assert len(records) == 16
    assert sum(r['kind'] == 'candidate' for r in records) == 12
    assert sum(r['kind'] == 'control' for r in records) == 4
    assert all(r['work'] == records[0]['work'] for r in records)
    summaries = {metric: {kind: stats(records, kind, metric) for kind in ['candidate', 'control']} for metric in METRICS}
    write_counts = {name: {arm: sorted({r['writeWork'][name] for r in records if r['arm'] == arm}) for arm in ['A', 'B', 'C']} for name in WRITE_WORK}
    source_hashes = {}
    for arm in ['A', 'B']:
        with ZipFile(io.BytesIO(z.read('jitendex/package-' + arm + '.zip'))) as package:
            source_hashes[arm] = {path: sha(package.read(path)) for path in [
                'js/dictionary/term-content-block-store.js',
                'js/dictionary/dictionary-database.js',
                'js/dictionary/dictionary-importer.js',
                'js/dictionary/zstd-term-content.js',
            ]}
    for path in source_hashes['A']:
        if not path.endswith('/zstd-term-content.js'):
            assert source_hashes['A'][path] == source_hashes['B'][path]

result = {
    'scope': 'Post-outcome exploratory descriptive context only, requested after the completed primary result. All six original candidate pairs and both identical-code controls retained; no new acquisition, resampling, endpoint, gate, filtering, source edits or causal inference.',
    'scriptSha256': sha(Path(__file__).read_bytes()),
    'archiveSha256': sha(data), 'primaryOutcomeChanged': False,
    'primaryDisposition': 'No compression PR: primary median/equal-work are adverse with five of six slower pairs; independent A1 memory-coverage failure remains.',
    'metricSelection': 'Selected after the primary outcome, from the existing content compression/store/append owners and unchanged-source parser/dedup/record/finalization context. This is not a prospectively registered mechanism endpoint.',
    'records': records, 'summaries': summaries,
    'sameRecordedInputAndDedupWorkAcrossAll16': records[0]['work'],
    'writeWorkValuesByArm': write_counts,
    'actualPackagedSourceSha256': source_hashes,
    'sourceBoundaries': {
        'contentCompressMs': 'term-content-block-store.js _beginAppendSharedSpans lines 813-876 and _tryAppendSharedSpans lines 978-1013; _tryAppendPacked lines 1044-1091. Per-batch elapsed time spans awaited completion and validation, excluding separately measured envelope and applicable pack time. zstd-term-content.js lines 737-755 also awaits pool initialization. Includes scheduling/dispatch/copy/return/initialization effects; not isolated native codec CPU or a sum of worker CPU time.',
        'contentStoreMs': 'dictionary-database.js starts at line 8454 and records at lines 8531 or 8623. Inclusive persistence elapsed time; it can overlap record append and includes the compression owner. Cannot add it to contentCompressMs or record timing.',
        'contentOpfsAppendMs': 'term-content-block-store.js lines 934-937 measure post-compression completion tail less reference generation in the early reservation path; lines 1145-1162 measure appendBatchWithDerivedChunks elapsed time less reference generation in the serial path. This is not a syscall-only disk-write metric.',
        'metricCollection': 'dictionary-database.js _addTermContentBlockProfile lines 9551-9557 accumulates the returned owner measurements. Importer reports these sums in the single term-file-fast-path details object.',
        'unchangedSourceContext': 'Parser inflate/parse are worker-phase aggregates, while record, dedup and finalization scopes differ and can overlap. Source equality establishes code identity, not timing isolation from a changed compression schedule or shared host.',
    },
    'interpretationLimits': [
        'Do not add or subtract these overlapping metrics to decompose the import endpoint, derive unexplained residuals, or adjust the primary estimate.',
        'No post-hoc confidence interval or favorable threshold is introduced. Two identical-code control pairs provide limited attribution context.',
        'The earlier warm standalone compression replay used a different timing boundary. A lower native codec component would not guarantee a lower awaited browser owner interval.',
        'Per-pair phase movements do not prove that the compression-level change caused the host-wide or parser movements.',
    ],
}
OUTPUT.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output': str(OUTPUT), 'sha256': sha(OUTPUT.read_bytes()), 'bytes': OUTPUT.stat().st_size, 'metrics': {k: {kind: {x: v for x, v in values.items() if x != 'pairedChangesPercent'} for kind, values in bykind.items()} for k, bykind in summaries.items()}, 'writeWork': write_counts}, indent=2))
