# Corrected compression Jitendex result

The single fixed corrected Jitendex cohort completed all observations but failed final qualification. Its adverse timing pattern independently blocks a compression product PR under the frozen review rule. The separate baseline memory-coverage failure also prevents the required memory comparison. No observation was omitted or repeated.

| Comparison | Paired median | Equal-work change | Descriptive 95% interval | Faster pairs |
| --- | ---: | ---: | --- | ---: |
| Candidate B / baseline A | +4.483507% | +6.803567% | −1.152391% to +17.259416% | 1 / 6 |
| Identical C / A | −0.290894% | −0.296139% | −0.942986% to +0.361197% | 1 / 2 |

The six candidate changes are −3.238314%, +3.089059%, +20.266945%, +14.251887%, +0.933532% and +5.877954%. Five slower pairs plus positive paired-median and equal-work changes trigger the declared adverse-other-corpus rule; this is review triage, not a significance claim. No control subtraction or pooling is used.

All 26 original reports/receipts, additive physical/decoded proofs, comparison copies, exact storage policies, sampled lookup bindings, exhaustive-media checks, per-family physical stability, source/package/timer links and final harness restoration pass the frozen independent reader. The only packaged change is `js/dictionary/zstd-term-content.js`. Storage is exactly 67,466,332 → 68,216,350 bytes (+750,018; +1.111692% total), including content 38,386,795 → 39,136,813 bytes. The fixed prediction and 2% budget pass without recalibration.

All 291 raw memory scans are retained. Baseline A1 has a maximum covered gap of 278.445886 ms, above the unchanged 250 ms limit. Its maxima and both aggregate memory comparisons remain null; this is insufficient coverage, not a measured memory regression. B1, B2 and A2 individually meet coverage. There are no semantic failures.

Run `46127578128`, job `140928447909`, source `3256036ff8534ba6de7bc9ecd74ec74d3c705603`, common baseline `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`. Artifact `15257054083` has 314 members (312 non-package), 35,954,051 bytes, SHA-256 `0afcede0f142dcaa9565490f97fd52c742119607305954a25ddc23cf60505463`. Frozen reader SHA-256 `7e9dd7a9992652e73c0e07417b4b5824f077944af6506b8468353a52be076121` recomputes the 6/2 statistics and all gates. Exact inputs, outputs, source context, environment and every timing observation are in `audit.json` and `result-summary.json`. Chrome 153.0.8010.12 / Node 22.22.0 ran on a four-logical-CPU AMD EPYC 9V74 hosted runner; no import flags were applied.

The original failed compression studies remain unchanged and separate. JMdict's already registered fixed cohort remains pending; it will be retained as its own result. No new variant, replacement, extra cohort, or compression PR follows from this result.
