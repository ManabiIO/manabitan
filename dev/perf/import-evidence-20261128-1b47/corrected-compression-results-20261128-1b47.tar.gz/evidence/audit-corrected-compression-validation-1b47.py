import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/1b47f6463b98')
REPO = ROOT / 'compression-proof-experiment'
OUT = ROOT / 'evidence/hosted-compression-proof-validation-46127578128'
ARCHIVE = Path('/home/agent/manabitan-import-capture-1b47/hosted-artifacts/compression-proof-46127578128-validation.zip')
SHA = '3256036ff8534ba6de7bc9ecd74ec74d3c705603'
BASELINE = 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16'
EXPECTED_DIGEST = '6ae18a850038e4c971e84b4a034b7912bd9d0542461ccef692e76490e2a1ae6f'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

assert not (OUT / 'audit.json').exists()
data = ARCHIVE.read_bytes()
assert len(data) == 53096 and digest(data) == EXPECTED_DIGEST
expected_files = {'build.log', 'clang-version.txt', 'lint.log', 'lld-version.txt', 'native-check.log', 'original-receipt-tests.log', 'original-storage-policy-tests.log', 'proof-policy-driver-tests.log', 'source-diff-stat.txt', 'source-sha.txt', 'types-main.log', 'types-test.log', 'unit.log'}
with zipfile.ZipFile(ARCHIVE) as archive:
    assert len(archive.namelist()) == len(expected_files)
    assert set(archive.namelist()) == expected_files
    files = {name: archive.read(name) for name in archive.namelist()}
texts = {name: value.decode('utf-8') for name, value in files.items()}
assert texts['source-sha.txt'] == SHA + '\n'
commit = git('show', '--no-patch', '--format=%H%n%T%n%P', SHA).decode().splitlines()
assert commit == [SHA, '42c3ac97086544bc35aa4895c30ba72e717bd33e', BASELINE]
changed = git('diff', '--name-only', BASELINE, SHA).decode().splitlines()
assert len(changed) == 16
workflow = git('show', f'{SHA}:.github/workflows/compression-proof-screen-1b47.yml')
assert digest(workflow) == '6d2320a98083c3824d4a59008acfed99a9505cbcb68fc1c62cb3624b689d5aee'
assert '16 files changed, 3636 insertions(+), 4 deletions(-)' in texts['source-diff-stat.txt']
assert 'clang version 21.1.8' in texts['clang-version.txt']
assert texts['lld-version.txt'].strip() == 'Ubuntu LLD 21.1.8'
native = json.loads(texts['native-check.log'][texts['native-check.log'].index('{'):])
assert native['mode'] == 'check'
assert native['toolchain'] == {'compilerVersion': '21.1.8', 'linkerVersion': '21.1.8'}
for item in native['targets']:
    assert item['sha256'] == digest(git('show', f'{SHA}:dev/data/dictionary-wasm/{item["name"]}'))
assert len(native['targets']) == 2
unit = re.sub(r'\x1b\[[0-9;]*m', '', texts['unit.log'])
assert re.search(r'Test Files\s+669 passed\s+\(669\)', unit)
assert re.search(r'Tests\s+15139 passed\s+\|\s+47 skipped\s+\(15186\)', unit)
assert not re.search(r'^\s*FAIL |Test Files.*failed|Tests.*failed', unit, re.M)
fixture_counts = {'proof-policy-driver-tests.log': 45, 'original-storage-policy-tests.log': 15, 'original-receipt-tests.log': 16}
for path, count in fixture_counts.items():
    assert re.search(fr'Ran {count} tests in [0-9.]+s\s+OK\s*$', texts[path])
assert 'Restoring manifest...' in texts['build.log']
assert 'tsc --noEmit --project jsconfig.json' in texts['types-main.log']
assert 'tsc --noEmit --project test/jsconfig.typecheck.json' in texts['types-test.log']
job_log = (OUT / 'job.log').read_bytes()
assert b'node: v22.22.0' in job_log
status_path = ROOT / 'evidence/hosted-current-status-202611280912.json'
status = json.loads(status_path.read_text())
job = next(j for j in status['compression']['jobs'] if j['id'] == 140925485554)
assert job['status'] == 'completed' and job['conclusion'] == 'success'
assert all(s['status'] == 'completed' and s['conclusion'] == 'success' for s in job['steps'])
raw_dir = OUT / 'raw'
raw_dir.mkdir()
for name, value in files.items():
    (raw_dir / name).write_bytes(value)
result = {
    'schemaVersion': 1, 'auditedAt': datetime.now(timezone.utc).isoformat(),
    'scope': 'Independent read-only validation-artifact audit; no import or performance result.',
    'runId': 46127578128, 'jobId': 140925485554, 'artifactId': 15256951482,
    'source': {'head': SHA, 'tree': commit[1], 'parents': [BASELINE], 'changedFiles': changed, 'workflowSha256': digest(workflow)},
    'archive': {'path': str(ARCHIVE), 'bytes': len(data), 'sha256': digest(data)},
    'members': [{'path': name, 'bytes': len(value), 'sha256': digest(value)} for name, value in sorted(files.items())],
    'metadataSource': {'path': str(status_path), 'sha256': digest(status_path.read_bytes())},
    'jobLog': {'path': str(OUT / 'job.log'), 'bytes': len(job_log), 'sha256': digest(job_log)},
    'gates': {'native': native, 'newProofFixtures': 45, 'originalStorageFixtures': 15, 'originalReceiptFixtures': 16, 'unitSuitesPassed': 669, 'unitTestsPassed': 15139, 'unitTestsSkipped': 47, 'unitTestsTotal': 15186, 'allBuildTargets': 'passed', 'scopedLint': 'passed', 'runtimeTypes': 'passed', 'testTypes': 'passed', 'node': '22.22.0'},
    'jobSteps': job['steps'],
    'limitations': ['This workflow records the source commit and exact native-byte check, but does not emit the integration workflow\u2019s final tracked-cleanliness receipt.', '47 unit skips are reported as observed; this audit does not silently reinterpret skipped cases as executed.', 'Browser jobs were still queued in the referenced status snapshot.'],
    'passed': True
}
(OUT / 'audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': True, 'audit': str(OUT / 'audit.json'), 'members': len(files), 'unitSuitesPassed': 669, 'unitTestsPassed': 15139, 'unitTestsSkipped': 47, 'fixtureCounts': fixture_counts}, indent=2))
