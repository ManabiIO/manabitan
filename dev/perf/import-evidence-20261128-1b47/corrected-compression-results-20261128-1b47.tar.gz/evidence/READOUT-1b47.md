# Import optimization evidence readout

Updated 2026-11-28, 09:40 UTC; later results are explicit addenda to sealed earlier snapshots.
All authorized performance acquisitions are complete; no unsupported full-import improvement is claimed. Root published draft PRs [#978](https://github.com/ManabiIO/manabitan/pull/978) (indexed score validation) and [#979](https://github.com/ManabiIO/manabitan/pull/979) (CRC 8+4 tails), each with narrow component claims and immutable evidence.

## Source and measurement boundaries

The original performance experiments use ManabiIO/manabitan baseline
`9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`, tree
`d99ea4d04658f7ec1c76acdc5f3684594212a471`. Full source, native module, fixture
and runtime identities are in `input-identities-1b47.json`. The machine-readable
candidate index is `evidence-inventory-1b47.json`; it includes exact source
identities, complete and failed cohort paths, and existence checks.

Pinned full-browser baseline run 46100401987 covers all three corpora with
restart, lookup, media and persisted-storage checks. Its three individual import
times (JMdict 738.9 ms, Jitendex 1,926.3 ms, VNDB 6,602.2 ms) are orientation,
not comparative estimates. Ordinary receipts and separate traces are in
`current-baseline-{jmdict,jitendex,vndb}`. Overlapping trace phases cannot be added.
The parser source-read wall metric includes worker startup; JMdict's 53.7 ms is
not an isolated Blob I/O measurement.

Local public-sink replay includes the actual compressed source pipeline, parser,
dedup, compression workers, complete record encoder and stored bytes. Its async
filesystem boundary excludes browser synchronous handles, SQLite, publication,
UI, media and restart. Parser-only and codec-only diagnostics have narrower
boundaries. None is a substitute for a browser whole-import measurement.

## Candidates with useful component evidence

| Candidate | Concrete evidence | Current limit / disposition |
| --- | --- | --- |
| Restore indexed compact-score validation | Exact 12 real compact field buffers; 24 balanced A/B/C blocks. Approximately 1.57–1.60 ms saved per warm validation of 528,299 rows. Same-code median control +0.88457%. | Draft PR #978. Full local and exact-head hosted validation pass. JMdict browser timing is inconclusive (median −0.960%, interval crosses zero; identical-code median −3.248%) and separate memory coverage fails. Jitendex passes semantic/memory gates but has an unfavorable retained timing tail; VNDB passes gates with inconclusive timing. The much larger whole-Node apparent gain is not attributed to these two lines. |
| CRC gap tails, eight then four bytes | Two complete, opposite-order VNDB parser cohorts cover all 665 banks and 6,648,310 rows with exact output/source checks. Combined CRC phase improvement about 7.73%. | Draft PR #979. Narrow CRC mechanism supported; unrelated phase drift prevents a whole-parser/import claim. Current-head full validation passes. JMdict/Jitendex browser cohorts pass as flat inactive controls with zero actual deferred-CRC work; targeted VNDB has adverse/inconclusive primary timing and failed memory coverage. Slicing32/padding alternatives were not promoted. |
| Zstd level −2 for JMdict/Jitendex content | Every captured production frame decodes exactly, including independent libzstd verification. Jitendex retained-context compression improves about 8% / 43–47 ms; JMdict improvement is small. | Explicit storage tradeoff: exact complete-import deltas +312,404 B JMdict, +750,018 B Jitendex, zero VNDB; 2% total ceiling. Decoder timing is noisy. Fresh-context already reuses CCtx across every frame; retained adds two full-corpus warmups. Original active-corpus browser trials fail before measured pairs on a representation-sensitive digest; VNDB passes with inconclusive timing. No product PR. Both separate corrected-proof cohorts are complete and unfavorable, as reported below. |

The original clean score product head is `b15bad43acdfd54d541895cac1109c0e5ba51b2f`; clean CRC product head is `5909db31ebe859fce1cc4b38324271ddf9f3dd59`. Their product files exactly match the validated experimental heads `915268441352c3c7aa50fc0fbd44f73f5a826d79` and `3080deb631a7536fabe8ccb2f77f8f55e11ef061`. Compression experimental head is `f7980e638ea1808701ac28339987663fd8b3dc4e`. Publication source/tree maps and PR metadata are in `product-publication-1b47.json`; no experimental head changed.

Detailed readouts:

- `score-restoration-pr-review.md`, `score-checkpoint-claim-audit.md`,
  `score-validation/full-validation/summary.json`.
- `crc-tail/{independent-review.md,pr-worthiness-update.md,full-vndb-crc-comparison.json}`.
- `compression-level/{README.md,summary.json,pr-worthiness-reassessment.md}` and `compression-level-study`. Production first-import contexts see only worker subsets; retaining a context does not make the twice-warmed corpus result uniquely representative.

## Completed original browser studies

All fifteen original corpus jobs are complete, including the two compression warmup failures. Score and CRC remain narrowly scoped component drafts with their full unfavorable and incomplete browser qualifications disclosed. Pipeline and checkpoint studies are closed without PRs. Every original non-package artifact member, report and memory scan is preserved in immutable evidence packets.

One separate compression proof-policy correction is being prepared on current common baseline `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`, following the integration of #972. Its frozen source is published at3256036ff8534ba6de7bc9ecd74ec74d3c705603; fresh validation is queued in run46127578128 and no browser observations exist yet. All completed studies retain their original 9e10 source identities and results.

## Rejected or held experiments

| Experiment | Why it did not advance | Retained evidence |
| --- | --- | --- |
| Exact-tag score cache v1/v2 | Positive actual warm encoder saving retained, but all four v2 common144 upper bounds fail the prospective <+5% rule (7.394%, 9.995%, 9.384%, 9.621%). All-in-range wall changes +5.240%/+5.686% have positive intervals against both baselines. | `score-cache` and `score-cache-repeat-v2`: all actual backing/output bytes, v1/v2 complete cohorts, unstarted superseded plan, full CPU/control attribution and disposition. Stop: no PR, first-use implementation/acquisition, Jitendex capture or optional full gates. |
| Local 8 MiB index checkpoints | All three browser studies completed. Targeted JMdict whole import is flat: median −0.347%, equal-work +0.175%, interval [−1.264%, +2.173%]. Jitendex offers no useful gain; VNDB unchanged worker path is flat. JMdict/Jitendex separately fail memory scan coverage. | `checkpoint-final-disposition-1b47.{md,json}` plus all three full receipt directories. All 78 semantic receipts and 970 raw scans independently revalidated. Closed: no PR or further acquisition; flat timing rejects the hypothesis independently of memory qualification. |
| Content-persistence overlap | All three browser cohorts complete. JMdict enters the deferred route but whole import is flat: median −0.226%, equal-work +0.339%, interval [−0.989%, +2.274%], same-code −0.574%. Jitendex/VNDB inactive controls offer no useful gain. JM/Jit memory sampling coverage fails separately. | `pipeline-final-readout-1b47.{md,json}` plus all three receipt directories and independent source-signal review. Route entry is not an overlap-duration measurement. Recommend no PR or further acquisition; root owns disposition. |
| Source-cache statistics fusion | Lower isolated cache metric mostly moved work; inclusive metadata change was about 1.4 ms, whole component geometric change +11.86%. | `node-jmdict-cache-pairs`, exact source/storage verification, abandoned patch and proxy regression log. |
| CRC slicing32 and padded table stride | Packed-gap micro wins did not survive actual verifier/parser work. Second padded cohort remained inconclusive; stopped. | Full VNDB slicing32, five-arm actual verifier, opposite-order padding and combined analysis, all inputs' hashes and reconstruction recipe. |
| CRC braid lanes 4/6/8/12/16 | Four-lane apparent gain tracked identical-code eight-lane control; 12/16 slower. | `crc-braid-lanes`, all 53 JMdict bank oracles and 12 balanced blocks. |
| SIMD inflater match copies | JMdict showed no useful controlled gain. Jitendex phase signal lacked a completed full-parser qualification: both independently declared attempts were externally killed. | `inflate-match-copy`, both partial cohorts, failure notes, bank-count preparation erratum and corrected interpretation of RSS. No more acquisitions. |
| Broad key-run glossary reuse | 128,388 JMdict witnesses but no useful gain versus both controls; Jitendex no gain. | `jmdict-keyrun-candidate`, full six-block corpora, corrected controls and both earlier control-preparation failures. |
| Distance-two key-run | 96,940 expected witnesses reached, but JMdict point estimate mostly tracked control variation. Jitendex killed in warmup with no measured groups. | `jmdict-distance2-candidate`, complete JM/control data and preserved Jit failure. No retry. |
| Delayed key hint | JMdict reaches 116,812 predicted witnesses but no gain versus both controls. Favorable six-block Jitendex signal has no eliminated work; only caller code generation differs. | `jmdict-delayed-keyhint-candidate`, both complete 18-child studies, attribution and native function-body audit. No remeasure. |
| Immediate-comma guard | Both separate 24-block confirmations completed. JMdict inclusive median B/A +1.14%, B/C −0.33%; native +0.42%/−0.53%, with intervals crossing zero. Jitendex B/C geometric −3.73% tracks unchanged inflate −3.50%; B/A remains inconclusive. No control-qualified mechanism gain. | `immediate-comma/confirmation-v3-readout.{md,json}` and both `confirmation-*-v3` directories retain 72 children per corpus, every proof/observation, and frozen bootstrap analysis. Original six-block screens are retained separately. Stop: no promotion or further acquisition. |
| Zstd level −3 | Jitendex storage increase 4.637% exceeded the predeclared budget before timing. | Size/oracle census, rejected payload hash inventory and reconstruction scripts. |
| Wider SAB copies / single-block worker routing / wider inline score radius | Copy-width control did not improve; zero eligible single-block production groups; score-radius expansion has little additional reach. | Bounded probe and exact production censuses. These are not import timing results. |
| Repeated canonical-header scan | Exact source overlap with an existing held proposal; no duplicate implementation. | `canonical-header-overlap.md`. |

## Score-cache result retained despite rejection

V2's actual 528,299-row, 12-call JMdict encoder scenario completed 24 balanced
blocks with exact full outputs, private factory proofs and backing layouts.
Median A/B/C wall times were 12.018/8.337/11.248 ms; geometric B/A was −27.664%
(95% descriptive interval [−34.124%, −20.139%]) and B/C −25.438%
([−34.564%, −14.531%]). CPU also improved against both baselines. Actual Map
reads fell from 269,193 to 7,676; v1 had 6,223. This warm component benefit is
preserved, with no first-import or full-browser claim.

Each common-score scenario completed its prospectively fixed 144 balanced blocks.
Uniform-zero geometric wall changes were +2.486% versus A (interval
[−2.400%, +7.394%]) and +4.960% versus C ([+0.224%, +9.995%]). All-in-range
changes were +5.240% ([+1.159%, +9.384%]) and +5.686%
([+1.905%, +9.621%]). All four upper bounds exceed the required +5% margin.
Same-code wall controls were −2.358% and −0.423%, both with intervals crossing
zero. All-in-range paired CPU medians were also positive (+4.563%/+3.479%),
while geometric CPU intervals remained broad. Synthetic controls retain the
actual JMdict reference layout and are not actual Jitendex/VNDB measurements.

The complete report is `score-cache-repeat-v2/actual-encoder-screen-v2-common144/README.md`;
`final-study-summary.json` and `disposition.json` retain the exact result and
stop rule. Source, protocol, actual inputs and all observations remain frozen.
The original 24/24/24 v2 plan was superseded before any observations. The
conditional `score-cache-repeat-v2/first-use-design.md` is unimplemented, with
zero observations, because its prerequisite failed. No larger or replacement
cohort is planned.

## Hosted studies and failures

Final original study status is recorded in `hosted-pending-screens-status-20261128081335.json`. All five frozen experimental heads have green full validation at their original source. Checkpoint, pipeline, score and CRC have completed all three browser cohorts. Compression JMdict/Jitendex failed before timing; compression VNDB completed with passing gates and inconclusive timing. Complete raw logs/artifacts, source/package identities, reports and memory scans are retained. No original failed study is retried, replaced, or retroactively passed.

### Later score-restoration JMdict result

`hosted-score-jmdict-46106456744` revalidates all 26 semantic receipts, actual package/member bytes and 250 raw memory scans. The sole packaged change exactly matches draft PR #978. Six-pair median whole-import change is −0.960%, equal-work −0.927%, with descriptive interval [−3.508%, +1.757%]; identical-code median is −3.248%. This does not establish a whole-import speedup. Candidate B2 fails the unchanged 250 ms memory-coverage limit with a 252.093481 ms gap; its memory maxima remain null and complete browser qualification is unfulfilled. This is a sampling failure, not an import/semantic exception or demonstrated memory regression. The separate approximately 1.57–1.60 ms warm-validator component result remains distinct; no browser point estimate is attributed to it.

### Later score Jitendex and CRC controls

| Cohort | Paired median | Equal-work | Descriptive 95% interval | Same-code median | Qualification / mechanism |
| --- | ---: | ---: | --- | ---: | --- |
| Score Jitendex | +0.900% | +3.387% | [−0.546%, +9.896%] | −1.069% | All semantics/memory pass; five of six pairs slower and pair 5 +17.679% retained. No gain or regression-free conclusion. |
| CRC Jitendex | +0.445% | +0.262% | [−1.096%, +1.449%] | +0.409% | All gates pass; all 26 reports record zero deferred source-CRC work. |
| CRC JMdict | −0.162% | +0.061% | [−0.657%, +1.007%] | +0.309% | All gates pass; all 26 reports record zero deferred source-CRC work. |

Each cohort has its own independently revalidated 26 raw reports/receipts,
actual package/source/clock/schedule/status bindings and complete memory scans
(276 score Jitendex, 333 CRC Jitendex, 303 CRC JMdict). Their receipt directories
are `hosted-score-jitendex-46106456744` and
`hosted-crc-{jitendex,jmdict}-46107723369`. The CRC controls cannot establish the
targeted VNDB gain. The independent `score-jitendex-independent-pr-review-1b47.json` retains the
unresolved adverse signal. The changed validator lies inside inclusive
`termRecordWriteMs`; unchanged parallel-worker phase totals also rise in pair 5,
but overlapping totals cannot be subtracted or used to establish causality.
No observation is excluded or adjusted. The parent holds the component-only
draft and makes no browser gain or non-regression claim.

### Final score VNDB, CRC VNDB, and original compression failures

Score VNDB completes the three-corpus score review: median −1.0194%, equal-work −1.0831%, interval [−2.8956%, +0.6811%], with same-code median −1.9688%. All 26 semantic receipts and 570 memory scans qualify. This is inconclusive; the final source-backed review `score-all-corpora-pr978-browser-section-1b47.md` retains JMdict's memory-coverage failure and Jitendex's adverse pair. Draft #978 remains component-scoped, with no browser gain or non-regression claim.

CRC VNDB's six-pair primary import median is **+4.6426%**, equal-work **+6.4226%**, interval **[−0.9559%, +15.5290%]**, and worst pair **+19.3509%**. Same-code median is +1.1104%. All 26 semantic receipts pass, but 482 memory scans leave baseline A2's **295.200949 ms** coverage gap unqualified; its maxima/comparison remain null. The original job remains failed. JMdict/Jitendex are flat inactive CRC-path controls, not evidence of a VNDB import gain.

An **added secondary analysis requested at 07:50:20 UTC while the CRC VNDB cohort was already running, before result review** describes summed-worker `parserSourceCrcMs`. It is not a prospectively registered primary endpoint or acquisition amendment. All 16 original timed observations have exactly 568,284,368 scanned bytes, 3,699,708,599 reused bytes and 6,490,145 reused glossaries. Candidate median is −4.0486%, equal-work −4.0686%, interval [−5.4962%, −2.6251%], with all six pairs lower. Both identical-code phase controls also improve (−0.1508%, −4.3172%; median −2.2340%), so control drift remains material. No subtraction, adjusted effect, wall-time inference or primary-gate change is made. The declaration/helper/review and `hosted-crc-vndb-46107723369/secondary-crc-phase-analysis.json` retain this scope and all rows.

Original compression JMdict and Jitendex both fail at the first B warmup. Each has two successful individual raw imports and the exact declared content/total delta (+312,404 / +750,018 bytes), but the unchanged cross-arm matcher rejects the remaining `common.validation.outputDigestSha256` difference. Each retains zero measured pairs, no exhaustive-media or memory observations, and no primary analysis. The digest includes physical raw-content preview/offset/length data; complete preimages are not retained, so no exact differing preimage or sole semantic cause is asserted. The policy omission is source-backed, but these original trials remain failed and unchanged. Any correction would require a separately frozen protocol and entirely new observations, without warmup reuse or generic gate weakening. Partial audits are separate from the unchanged complete-cohort auditors.

Original compression VNDB retained all 26 raw/canonical/comparison/policy receipt sets and 418 memory scans. Primary paired median is −1.9367%, equal-work −0.8782%, descriptive interval [−5.5561%, +5.1878%], and same-code median +1.2360%. All source/semantic/storage/memory gates pass at exactly zero storage delta. This inactive control does not qualify the two failed active-corpus trials or establish a compression gain. `hosted-compression-vndb-46108665276` retains the full independent audit and original files.

## Separate corrected compression preparation

The original policy's representation-sensitive digest omission is addressed only in a separate, still-unacquired preparation. A symmetric additive harness retains exact physical preimages and complete decoded lookup JSON outside the unchanged import timer. A new policy first proves bounded physical references, full decoded equality and original72-lookup bindings, then uses distinctly labeled logical comparison copies; raw receipts and same-arm/A-C physical proof remain exact. The original validators/helpers and failed observations remain unchanged.

Root chose current common baseline `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16` before acquisition. The compression runtime and two expectation tests remain exact f798 blobs. Historical 9e10 +312,404/+750,018-byte predictions remain fixed fail-closed predicates with the unchanged 2% budget; they are not silently treated as current-base measurements. The earlier unacquired9e10 preparation is preserved with zero observations in `compression-proof-followup/superseded-9e10-preparation`.

This is one fixed six-pair/two-control correction each for JMdict and Jitendex, with unchanged warmup/media/memory gates and fresh full current-tree validation. No new VNDB cohort, replacement, pooling or further variant is allowed. Both active-corpus semantic/storage/memory gates must pass; at least one must have negative candidate paired median/equal-work changes and upper descriptive bound, with both point changes more favorable than the corresponding identical-code controls. The other corpus blocks a PR if its lower bound is positive or at least5/6pairs are slower with both point changes positive. Remaining ambiguity stays explicit. These are review-triage rules for a provisional draft, not statistical significance, latency non-regression or merge readiness. Source maps, reviews and focused tests are under `compression-proof-followup`; root froze and published all16files at08:48:58UTC (commit3256036f); fresh current-tree validation must pass before the two browser jobs.

| Study | Actions run |
| --- | --- |
| Pipeline | 46105215670 |
| Checkpoint | 46104738613 |
| Score restoration | 46106456744 |
| CRC 8+4 | 46107723369 |
| Compression −2 | 46108665276 |

Earlier pipeline validation failed only newly added test annotations; earlier
CRC validation failed only test formatting. Both failures remain preserved and
acquired no browser observations. Full source/WASM bytes were unchanged by their
test-only repairs. The compression local real-worker Vitest failure was observed
as external SIGKILL; the exact standalone worker sequence passes. Its full
hosted full unit gate now also passes. Score full validation retains initial
missing-fixture/toolchain prerequisite failures as well as the corrected passing
run; no product source changed between those attempts.

The queue audit in `hosted-queue-audit-20261128` shows both ubuntu-latest browser
jobs and ubuntu-26.04 validation jobs progressing with substantial waits. There
is no established alternate Linux capacity advantage and no ETA assertion.

## Durable evidence packaging

Root published compact score-restoration and CRC bundles at immutable evidence commit `3c3ba7600a8811df6b8631b72a0ac5379f8b60d1` on `perf/import-evidence-20261128-1b47`. The nine-file tree and both archives were verified; exact paths/digests are in `product-publication-1b47.json`. The separate cache and 06:32:35 session bundles are also durable; later browser addenda preserve their own cutoffs. They retain protocols, scripts, source patches/identities, complete raw observations and preserved failures, input/fixture manifests, correctness oracles and validation receipts. Small numeric score buffers are useful to make
the direct component reproducible. Full dictionary archives, media, large
temporary source captures and repeated extension packages need not be duplicated
inside these compact bundles; their exact hashes and reconstruction path remain.

For compression, preserve all raw timings, exact-frame size/oracle/decode census,
both source-bound full-sink captures, the new policy/helper/tests and all hosted
raw receipts/comparison-copy audits when available. Regenerable frame payloads
were moved with verified hashes to task-owned temporary storage; the complete
976-entry receipt is `compression-level-payload-relocation.json`. No observations,
manifests or failure logs were removed. The same rule applies to rejected
experiments: retain the decisive negative controls and failures rather than
publishing only a favorable subset.

The bounded read-only assessment of pending local-path mechanisms is `pending-study-review-20261128.md`; it proposes no new acquisitions or altered gates.

Held cache evidence is durable at immutable commit `5c980635c4a4aaf581ad8e2b16a311a47c6241aa`, including `dev/perf/import-evidence-20261128-1b47/cache-held-README.md` and the complete 4.58 MB numeric-input/cohort archive. This is evidence publication, not a cache product PR. Earlier score/CRC evidence remains at `3c3ba7600a8811df6b8631b72a0ac5379f8b60d1`. The sealed 06:32:35 session archive is unchanged; later checkpoint outcomes are explicit addenda.

Pipeline VNDB later addendum: `hosted-pipeline-vndb-46105215670` revalidates all 26 receipts and 503 raw scans. Its median −0.649% (interval [−1.296%, +1.379%]) is flat, with identical-code median −0.273%. All 11 candidate observations have zero adopted bytes/deferred persistence despite owned parser bytes, so this does not demonstrate the targeted overlap.

The sealed held-session archive through 06:32:35 is durable at immutable commit `0df239a1be2cde2fc8586665413b7da7845f9fb6`, under `dev/perf/import-evidence-20261128-1b47/session-held-README.md` and its complete archive. Its 2,365 raw members are unchanged. Later checkpoint JMdict/Jitendex and pipeline VNDB outcomes are durable in the separate 06:46:37 addendum at `28332c2fc3a291f1728cd0441a878e3d5bd335ae`, including all 78 reports/receipts and 1,052 raw scans. The expanded 06:58:33 addendum is durable at `40192ef785296f50a37afe9511b137a5744556c0`, with pipeline JMdict/Jitendex and checkpoint VNDB: another 78 reports/receipts and 1,025 raw scans, bringing the six completed cohorts to 156 reports/receipts and 2,077 scans. Every original non-package artifact member is preserved across the two archives. The later score/CRC/compression results are preserved in their own immutable packets and are excluded from both earlier sealed snapshots.

The later targeted pipeline JMdict result is `hosted-pipeline-jmdict-46105215670`. Its complete 26 receipts and 328 raw memory scans are audited. Independent source review confirms early sourceConsumed propagation through plain objects/child promises, but aggregate counters do not measure useful overlap. The whole-import result is flat independently of baseline A2 sampling coverage failure.

The independent technical assessment of why larger JMdict changes did not qualify is `jmdict-technical-assessment-1b47.md`; it distinguishes eliminated work from shifted or already-overlapped work and retains the limits of each negative result.

The standalone source-backed JMdict assessment is durable at `9b1fd740e07cf43c38edcb7cdca41b23a3227fec`, path `dev/perf/import-evidence-20261128-1b47/jmdict-technical-assessment.md`. Publication identities are retained in `browser-evidence-publication-addendum-1b47.json`; original raw archives remain immutable.

A separate read-only supplemental check, `hosted-clock-source-link-supplement-1b47.json`, explicitly binds all seven completed cohorts’ A/B source identities to their registered plans and all 140 timing observations to the corresponding original raw summaries. It also checks the exact frozen schedules, 26 distinct receipt names per cohort and final status against the already recomputed raw-memory audit. All links pass. This adds explicit verification links; it does not replace or rewrite any original artifact, audit, source, threshold or observation.

The score-JMdict-only browser addendum is immutable at `54b933253e05dfa8b9cfe0b7211cb8eac34eb500` (cutoff 07:20:18), with all 26 reports/receipts and 250 raw memory scans. Draft PR #978 now links that full result; its source/draft state is unchanged. Later completed cohorts remain separate.

The third executor outage reset task-owned home/tmp captures while workspace evidence survived. Only unpublished CRC Jitendex and newly completed artifacts were downloaded again. Its deterministic read-only audit and counter census reproduce the original bytes exactly; `hosted-crc-jitendex-46107723369/post-recovery-receipt.json` preserves that recovery proof. No browser observations were rerun and no fixtures/toolchain were restored.

Remaining score Jitendex/VNDB browser evidence is durable at `212089f2186cfd7ea0d90b082f16b1cd81c65aa5` (52 reports/receipts,846scans). All three CRC cohorts are durable at `c89af6f108eebab73dcdbc7c3a292c189a6161e6` (78 reports/receipts,1,118scans), including the accurately labeled added secondary phase analysis. Original compression evidence is durable at `128b8f8bb69c1801f52242a9907b0b8f0bc3660c` (30 reports and each receipt form,418scans); both active failures retain zero measured pairs. These packets preserve all raw non-package members and exact omitted-package hashes. No corrected follow-up observations are included.

## Current-source correctness and corrected-proof validation addendum — 09:16 UTC

The corrected compression preparation is immutable at `b444dbe138ba441038ae97a0fb608df2cd177dd4`, with 115 verified members and separate 08:48:58 source-freeze / 08:49:43 queued-metadata cutoffs. It contains no validation or browser outcome. The new fixed study is `3256036ff8534ba6de7bc9ecd74ec74d3c705603` on common baseline `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`, run 46127578128. Its validation artifact is now independently audited: 669 unit test files, 15,139 passed assertions and 47 skips; 45 new proof/driver/reader fixtures, 15 original storage-policy fixtures and 16 original receipt fixtures; pinned native reproduction, all build targets, scoped lint and both type gates passed. The validation workflow does not emit a final tracked-cleanliness receipt; the browser protocol independently requires its source/package/restoration proofs. The two browser jobs remained queued at the 09:13:39 check. No corrected performance result is available. See `hosted-compression-proof-validation-46127578128/audit.json`.

The correctness-only workflow `dc6edcc01a6b9f387fb33e80aa47833a29334d14`, run 46128395334, also completed. Independent artifact audits bind score integration `dbaa4d72a5f6b4fcffeb92cefadb521e101df7df` and CRC integration `961614e36859c529580fc034d6535ca89d119051` to their exact trees, ordered parents, changed blobs and actual source bytes. Both reproduce all native assets with Clang/LLD 21.1.8, use Node 22.22.0, pass build/lint/runtime/test-type gates, and finish with unchanged HEAD and clean tracked working/index state. Each has 669 passing test files; score has 15,139 passing assertions and CRC 15,140, with the identical 47 skipped assertions explicitly retained. The JSON reporter's 1,577 nested-suite count is distinct from the 669 file count. See `hosted-current-integration-46128395334/summary.json` and its two complete audits. These are correctness results on the current common baseline; historical import measurements remain attached to their original sources. Root controls the final draft-PR updates.

The fourth executor outage ran from 09:02:09 until root verified recovery at 09:08:42. Workspace evidence survived; temporary captures were reset. Only the newly completed validation artifacts were downloaded again. No performance observation or gate was rerun.

Root published and read back the validated current-source integrations at 09:18:55: draft #978 now points to `dbaa4d72a5f6b4fcffeb92cefadb521e101df7df`, and draft #979 to `961614e36859c529580fc034d6535ca89d119051`, each against common baseline `dcfc02a0`. Their exact one-file/four-file product deltas, open draft state, and updated bodies were verified; neither is merged. `current-develop-integrations/root-product-publication-complete.json` records publication, and `current-integration-hosted-independent-review-1b47.json` independently confirms the raw source/gate audits. Correctness on the new source combination does not transfer historical performance estimates or change either held disposition.

## Corrected Jitendex compression result — 09:25 UTC

The separate current-DC corrected cohort completed all 26 observations and its frozen independent reader audit. Physical preimages, full decoded lookup samples, original raw receipts, per-family stability, exact storage deltas, media, source/package/timer links and final restoration all pass. The policy correction is therefore exercised without treating either original failed trial as qualified.

The retained whole-import result is adverse: paired median +4.483507%, equal-work +6.803567%, descriptive interval −1.152391% to +17.259416%, with five of six pairs slower. Identical-code controls are −0.290894% median and −0.296139% equal-work. This triggers the predeclared adverse-other-corpus rule and independently blocks a compression product PR. No control subtraction or pooling is used.

Exact storage is 67,466,332 → 68,216,350 bytes (+750,018; +1.111692% total), within the unchanged 2% budget. All 291 memory scans are retained; baseline A1 has a 278.445886 ms coverage gap, exceeding 250 ms, so its maxima and aggregate comparisons remain null. This is failed memory coverage, not a measured memory regression. Semantic failures are empty.

See `hosted-compression-proof-jitendex-46127578128/{audit.json,result-summary.json,README.md}`. Artifact 15257054083 is bound by SHA-256 `0afcede0f142dcaa9565490f97fd52c742119607305954a25ddc23cf60505463`; all 26 raw report/proof/receipt sets are retained. JMdict's already registered fixed cohort remains queued at 09:25:53 and will be reported independently. No variant, retry, replacement cohort, or compression PR is authorized by this result.

The complete current-source correctness packet is immutable at `39c261d2a6a74b24aa8e94116a1402a7c0a6fc12`: 136 members including both original hosted ZIPs, all 49 raw members, full logs/source/gate audits, local prerequisite/failure history and exact product publication. Its archive is 2,814,657 bytes, SHA-256 `2d69f80b6f42289d9de64e9e583f5447a0e4ac3e3c3a3be03d60e956694c43de`. Both draft PRs link it, with heads and held performance dispositions unchanged. Corrected-compression observations are outside this correctness packet.

## Final corrected compression disposition — all acquisitions complete

Both fixed current-DC corrected cohorts are complete and independently audited with the unchanged frozen reader. JMdict passes semantic, exact-storage, physical/decoded proof, restoration and all four sampled-memory gates, but its whole-import paired median is +2.156437%, equal-work change +1.748931%, descriptive interval −0.481131% to +3.591868%, with five of six pairs slower. Identical-code controls are −1.834986% median and −1.834250% equal-work. Its exact +312,404-byte storage cost is +0.717832% of complete persisted storage. All 256 raw memory scans qualify within the fixed limits; that passing gate does not establish latency nonregression.

Jitendex retains the separately reported +4.483507% median / +6.803567% equal-work result, also with five of six pairs slower, and its failed baseline memory-coverage observation. Neither corpus supplies the required useful primary signal, and each independently triggers the predeclared adverse review rule. The compression mechanism is closed without a product PR. The favorable component observations and exact storage costs remain preserved; they do not override the whole-import decision.

The two new cohorts retain 52 complete original report/proof/receipt sets and 547 raw memory scans across 624 non-package artifact members. They are not pooled with each other or with the original failed preparation trials. `compression-proof-final-disposition-1b47.json` binds both complete audits and every primary/control statistic. All authorized performance acquisitions are now complete. Draft #978 and #979 remain the two narrow component review outputs, with current-source correctness evidence and all held browser limitations disclosed. No further variant, replacement cohort or import timing is planned.

Both corrected corpus reviews are independently complete: `compression-proof-{jmdict,jitendex}-independent-review-1b47.json` and their review manifests bind original ZIP/source/proof/storage/restoration and primary/memory verification. The separate Jitendex post-outcome phase note remains exploratory and does not change the primary rejection. No JMdict phase expansion was added.
