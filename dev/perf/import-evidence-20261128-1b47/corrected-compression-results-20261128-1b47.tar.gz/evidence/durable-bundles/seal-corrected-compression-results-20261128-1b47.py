#!/usr/bin/env python3
"""Seal complete fixed-cohort evidence; never rerun a test, reader or import."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/1b47f6463b98')
CONTROL = ROOT / 'evidence/corrected-compression-results-20261128-1b47'
STAGE = Path('/home/agent/manabitan-import-capture-1b47/corrected-compression-results-20261128-1b47-staging')
OUTPUT = Path('/home/agent/manabitan-import-capture-1b47/corrected-compression-results-20261128-1b47-output')
NAME = 'corrected-compression-results-20261128-1b47'
README_SHA = 'bd10f9429d0a14d0b571243b73925a59cab2defd45f937659515c7d37dfb6d50'
REVIEW_SHA = '73aa733310d3bcc6c6b30a98473511d031c0aa34d426389216febd927197e687'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    assert path.is_file() and all(not item.is_symlink() for item in [path, *path.parents]), str(path)


def exact(path, size, digest):
    regular(path)
    data = path.read_bytes()
    assert len(data) == size and sha(data) == digest, str(path)
    return data


assert sha((CONTROL / 'README.md').read_bytes()) == README_SHA
assert sha((CONTROL / 'wrapper-independent-review-benchmark.json').read_bytes()) == REVIEW_SHA
root_review = json.loads((CONTROL / 'root-wrapper-review-and-precision.json').read_text())
assert root_review['requestedPrecisionApplied'] and root_review['rootSealApprovalConditionalOnlyOnThisEditAndIndependentWrapperReview']
snapshot = json.loads((CONTROL / 'final-snapshot-receipt.json').read_text())
omissions = []
counts = {'originalBrowserNonPackageMembers': 0, 'rawReportsAndEachProofReceiptForm': 0, 'rawMemoryScanRows': 0}
cohort_bindings = []
for corpus in ['jmdict', 'jitendex']:
    relative = f'evidence/{NAME}/cohorts/compression-proof-{corpus}/cohort-record.json'
    record_bytes = (STAGE / relative).read_bytes()
    assert record_bytes == (CONTROL / f'{corpus}-staging-receipt.json').read_bytes()
    record = json.loads(record_bytes)
    for member in record['members']:
        exact(STAGE / member['path'], member['bytes'], member['sha256'])
    assert record['retainedOriginalMembers'] == 312
    assert record['rawReports'] == record['canonicalReceipts'] == record['rawAdditiveProofs'] == record['comparisonReceipts'] == record['proofPolicyReceipts'] == record['originalStoragePolicyReceipts'] == 26
    counts['originalBrowserNonPackageMembers'] += record['retainedOriginalMembers']
    counts['rawReportsAndEachProofReceiptForm'] += record['rawReports']
    counts['rawMemoryScanRows'] += record['rawMemoryScanRows']
    for omission in record['omittedPackages']:
        item = {key: value for key, value in omission.items() if key != 'entrySha256Inventory'}
        item['completeEntryInventoryReference'] = relative + ':omittedPackages'
        item['recordSha256'] = sha(record_bytes)
        omissions.append(item)
    omissions.append({'included': False, 'kind': 'Original outer browser ZIP container',
                      'artifactId': record['artifactId'], **record['originalArchive'],
                      'inventoryAndRecoveryReference': relative,
                      'reason': 'All non-package members retained; bulk extension packages and original outer container omitted. Exact original artifact is required to repeat container-byte checks.'})
    cohort_bindings.append({'dictionary': corpus, 'record': relative, 'recordSha256': sha(record_bytes),
                            'artifactId': record['artifactId'], 'originalArchive': record['originalArchive'],
                            'qualificationStatusAsAudited': record['qualificationStatusAsAudited']})
assert counts == {'originalBrowserNonPackageMembers': 624, 'rawReportsAndEachProofReceiptForm': 52, 'rawMemoryScanRows': 547}
validation = json.loads((CONTROL / 'validation-staging-receipt.json').read_text())
for member in validation['copiedFiles']:
    exact(STAGE / member['path'], member['bytes'], member['sha256'])
exact(STAGE / validation['originalArchive']['path'], validation['originalArchive']['bytes'], validation['originalArchive']['sha256'])
assert validation['originalMemberCount'] == 13
for member in snapshot['supportCopies']:
    exact(STAGE / member['path'], member['bytes'], member['sha256'])
shared = json.loads((CONTROL / 'shared-tooling-staging-receipt.json').read_text())
for member in shared['files']:
    exact(STAGE / member['stagedPath'], member['bytes'], member['sha256'])
preseal = {
    'preparedForSealUtc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Final preservation seal after both fixed corrected cohorts and independent reviews; no new acquisition, test, semantic audit or statistics',
    'earlierFinalSnapshotUtc': snapshot['snapshotUtc'],
    'allPreviouslyStagedBytesStillExact': True,
    'rootApprovalConditionsMet': True,
    'readmeSha256': README_SHA,
    'independentWrapperReviewSha256': REVIEW_SHA,
    'cohorts': cohort_bindings, **counts,
    'validationOriginalMembers': 13,
    'originalValidationZipIncluded': True,
    'compressionProductPr': False,
    'priorOpenStagingRecordsRemainHistorical': True,
}
preseal_path = CONTROL / 'preseal-receipt.json'
assert not preseal_path.exists()
preseal_path.write_text(json.dumps(preseal, indent=2) + '\n')
for source in sorted(CONTROL.iterdir()) + [Path(__file__).resolve()]:
    regular(source)
    target = STAGE / source.relative_to(ROOT)
    data = source.read_bytes()
    if target.exists():
        assert target.read_bytes() == data
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        assert target.read_bytes() == data
selected = sorted(path for path in STAGE.rglob('*') if path.is_file())
expected = {}
for path in selected:
    regular(path)
    expected[str(path.relative_to(STAGE))] = sha(path.read_bytes())
spec_relative = f'evidence/{NAME}/bundle-spec.json'
spec = {
    'name': NAME,
    'study': 'Complete corrected compression-level trial and final no-product-PR disposition',
    'scope': 'Both fixed current-baseline browser cohorts, all original non-package bytes and memory rows, exact validation evidence, independent reviews, explicit post-outcome Jit context and source-bound closure. Earlier trial and registration remain separate.',
    'sourceBindings': {
        'baseline': 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16',
        'candidate': '3256036ff8534ba6de7bc9ecd74ec74d3c705603',
        'compressionProductOrigin': 'f7980e638ea1808701ac28339987663fd8b3dc4e',
        'historicalStoragePredictionBaselineOnly': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2',
        'registrationEvidenceCommit': 'b444dbe138ba441038ae97a0fb608df2cd177dd4',
        'originalTrialEvidenceCommit': '128b8f8bb69c1801f52242a9907b0b8f0bc3660c',
        'runId': 46127578128,
        'cohorts': cohort_bindings,
        'validationArchive': validation['originalArchive'],
        'frozenArtifactReaderSha256': '7e9dd7a9992652e73c0e07417b4b5824f077944af6506b8468353a52be076121',
        'snapshotUtc': snapshot['snapshotUtc'],
        'preparedForSealUtc': preseal['preparedForSealUtc'],
        'readmeSha256': README_SHA,
        **counts,
    },
    'include': sorted(list(expected) + [spec_relative]),
    'expectedSha256': expected,
    'omitExternal': omissions,
}
spec_path = CONTROL / 'bundle-spec.json'
assert not spec_path.exists()
spec_path.write_text(json.dumps(spec, indent=2) + '\n')
(STAGE / spec_relative).write_bytes(spec_path.read_bytes())
result = subprocess.run(['python', str(ROOT / 'evidence/durable-bundles/package-evidence-v2.py'),
                         '--root', str(STAGE), '--spec', str(STAGE / spec_relative), '--output', str(OUTPUT)],
                        check=True, capture_output=True, text=True)
(CONTROL / 'seal.log').write_text(result.stdout + result.stderr)
print(result.stdout, end='')
