#!/usr/bin/env python3
"""Copy completed validation evidence with exact bytes; never rerun its gates."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path('/workspace/scratch/1b47f6463b98')
STAGE = Path('/home/agent/manabitan-import-capture-1b47/corrected-compression-results-20261128-1b47-staging')
CONTROL = ROOT / 'evidence/corrected-compression-results-20261128-1b47'
RECEIPTS = ROOT / 'evidence/hosted-compression-proof-validation-46127578128'
ARCHIVE = Path('/home/agent/manabitan-import-capture-1b47/hosted-artifacts/compression-proof-46127578128-validation.zip')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    assert path.is_file() and all(not item.is_symlink() for item in [path, *path.parents]), str(path)


audit_path = RECEIPTS / 'audit.json'
regular(audit_path)
audit = json.loads(audit_path.read_text())
regular(ARCHIVE)
data = ARCHIVE.read_bytes()
assert len(data) == audit['archive']['bytes'] == 53096
assert sha(data) == audit['archive']['sha256'] == '6ae18a850038e4c971e84b4a034b7912bd9d0542461ccef692e76490e2a1ae6f'
assert audit['artifactId'] == 15256951482 and audit['runId'] == 46127578128
assert audit['source']['head'] == '3256036ff8534ba6de7bc9ecd74ec74d3c705603'
inventory = {item['path']: item for item in audit['members']}
assert len(inventory) == len(audit['members']) == 13
with zipfile.ZipFile(ARCHIVE) as archive:
    assert len(archive.namelist()) == 13 and set(archive.namelist()) == set(inventory)
    for name, expected in inventory.items():
        member = archive.read(name)
        assert len(member) == expected['bytes'] and sha(member) == expected['sha256']
        raw = RECEIPTS / 'raw' / name
        regular(raw)
        assert raw.read_bytes() == member
assert {str(path.relative_to(RECEIPTS / 'raw')) for path in (RECEIPTS / 'raw').rglob('*') if path.is_file()} == set(inventory)
metadata_source = Path(audit['metadataSource']['path'])
assert metadata_source.is_relative_to(ROOT)
regular(metadata_source)
assert sha(metadata_source.read_bytes()) == audit['metadataSource']['sha256']
sources = sorted(path for path in RECEIPTS.rglob('*') if path.is_file())
sources += [ROOT / 'evidence/audit-corrected-compression-validation-1b47.py', metadata_source, Path(__file__).resolve()]
assert len(sources) == len(set(sources))
copies = []
for source in sources:
    regular(source)
    relative = source.relative_to(ROOT)
    target = STAGE / relative
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = source.read_bytes()
    target.write_bytes(payload)
    assert target.read_bytes() == source.read_bytes() == payload
    copies.append({'path': relative.as_posix(), 'bytes': len(payload), 'sha256': sha(payload)})
archive_relative = 'evidence/corrected-compression-results-20261128-1b47/validation-original-artifacts/' + ARCHIVE.name
target = STAGE / archive_relative
assert not target.exists()
target.parent.mkdir(parents=True, exist_ok=True)
target.write_bytes(data)
assert target.read_bytes() == data
record = {
    'stagedUtc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Completed corrected-study validation evidence preserved; no gate, artifact audit, source change or new import',
    'runId': 46127578128, 'artifactId': 15256951482,
    'source': audit['source']['head'],
    'originalArchive': {'path': archive_relative, 'bytes': len(data), 'sha256': sha(data)},
    'originalMemberCount': 13,
    'allOriginalMembersRetainedAndByteEqual': True,
    'auditSha256': sha(audit_path.read_bytes()),
    'originalAuditLimitationsUnchanged': audit['limitations'],
    'copiedFiles': copies,
    'enclosingResultsPacketSealed': False,
}
CONTROL.mkdir(parents=True, exist_ok=True)
receipt = CONTROL / 'validation-staging-receipt.json'
assert not receipt.exists()
receipt.write_text(json.dumps(record, indent=2) + '\n')
target = STAGE / receipt.relative_to(ROOT)
target.parent.mkdir(parents=True, exist_ok=True)
target.write_bytes(receipt.read_bytes())
assert target.read_bytes() == receipt.read_bytes()
print(json.dumps({'recordPath': str(receipt), 'recordSha256': sha(receipt.read_bytes()),
                  'originalMembers': 13, 'copiedEvidenceFiles': len(copies), 'originalArchiveIncluded': True,
                  'bundleSealed': False}))
