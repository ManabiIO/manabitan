# Indexed score-validation restoration: completed Jitendex browser screen

All frozen semantic and sampled-memory gates pass, but whole-import timing is unfavorable and inconclusive. Five of six candidate pairs are slower, including the retained pair 5 at +17.679%. This is not a regression-free qualification or an import gain. The separate approximately 1.57–1.60 ms warm JMdict validator result has a different corpus and boundary.

## Frozen source and acquisition

- Baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
- Experimental candidate: `915268441352c3c7aa50fc0fbd44f73f5a826d79`.
- Corresponding clean draft PR #978 head: `b15bad43acdfd54d541895cac1109c0e5ba51b2f`.
- [Actions run 46106456744](https://github.com/ManabiIO/manabitan/actions/runs/46106456744),
  job 140880422289; conclusion `success`.
- Artifact 15254097229: 34,968,497 bytes, SHA-256
  `5af77600a2703129f30d394a466f7b39b2cb5abbc89c506c4faac8184d0b5658`.

Actual nested package bytes and every decompressed package member match the
source identities. The changed entries are exactly the registered list:
`js/dictionary/term-record-opfs-store.js`. The actual relevant
product Git blob identities also match the clean PR; `result-summary.json`
records their bytes and SHA-256 values.

The unchanged schedule completed six AB/BA candidate pairs, two identical-code
control pairs, four excluded warmups, two exhaustive-media imports and four
separate memory imports. Timing is file-input change through post-UI completion
in fresh profiles. No import flags, product overlays, unregistered harness
changes, replacement observations or retries occurred. The memory imports use
the prospectively registered marker-only harness overlay, outside authoritative
timing and with separately validated source hashes/dirty status.

## Complete-import timing

| Estimate | B/A candidate | C/A identical code |
| --- | ---: | ---: |
| Paired median change | +0.900243% | -1.069280% |
| Equal-work change | +3.386738% | -1.068349% |
| Descriptive 95% paired-median interval | [-0.546310%, +9.895937%] | [-1.586074%, -0.552486%] |
| Faster pairs | 1 / 6 | 2 / 2 |

This is one fixed host/cohort with descriptive intervals. No control drift is
subtracted from the candidate estimate and no separate cohorts are pooled.

## Retained unfavorable timing

Every candidate pair remains in the original analysis. Their percentage changes are:

| Pair | B/A whole-import change |
| --- | ---: |
| 1 | +0.149060% |
| 2 | +2.112676% |
| 3 | +0.489479% |
| 4 | +1.311007% |
| 5 | +17.679199% |
| 6 | -1.241679% |

The +17.679% fifth pair is not removed, replaced or classified as invalid. The
candidate interval is broad; the two identical-code controls both move faster.
Those facts require review of the original phase/source evidence and do not
support either a speedup claim or a claim that a meaningful regression is ruled
out. The parent owns the draft PR disposition. Any phase explanation is a
separate read-only attribution note, not a substitute or adjusted observation.

## Semantics and sampled memory

All **26 raw reports and canonical receipts** independently pass the unchanged
source-bound semantic validator, including declared work, lookup, complete
storage-size, media/readback and restart comparisons. This is not an exhaustive
byte comparison of every persisted definition.

All **276 original raw memory scan rows** and their window markers reproduce
the original audit. All four memory observations qualify and every frozen
sampled-memory bound passes. Private-memory paired change is median
**+2.827247%**, maximum **+3.020272%**;
PSS is median **+2.041978%**, maximum **+2.269813%**.
These are maxima among non-atomic sampled process-tree readings, not exact
process peaks. Passing this gate does not turn the timing point estimate into
a performance benefit.

## Independent artifact audit and retained data

The reviewed generic v2 auditor, SHA-256
`292eea976f78c24ce93f441b468c9a3efad62ad539cd9425c74eec893ee27ca0`, verifies all original package/member bytes, all
26 receipts, the raw memory audit and exact original paired statistics. Its own
explicit guards bind A/B source SHA to the registered plan, every observation
time to the raw summary, the exact 20-record/six-pair/two-control schedule and
26 distinct receipt names, and final status to recomputed memory/semantic
outcomes. This cohort has its own guard receipt; it is not covered implicitly
by the earlier seven-cohort supplement. Original generic and earlier audit
files remain unchanged.

`job.log`, emitted JSON, `independent-artifact-audit.json`,
`result-summary.json`, original metadata and retrieval provenance are retained
beside this README. All 206 artifact members are inventoried.

- Original ZIP: `/home/agent/manabitan-import-capture-1b47/hosted-artifacts/score-validation-1b47-screen-jitendex-15254097229.zip`.
- Raw extraction: `/home/agent/manabitan-import-capture-1b47/hosted-artifacts/score-jitendex-15254097229-extracted/jitendex`.

The working extraction omits HTML views and duplicate package containers; both
remain in the original ZIP. No new browser acquisition, threshold change,
source change, observation substitution or retry follows this audit.
