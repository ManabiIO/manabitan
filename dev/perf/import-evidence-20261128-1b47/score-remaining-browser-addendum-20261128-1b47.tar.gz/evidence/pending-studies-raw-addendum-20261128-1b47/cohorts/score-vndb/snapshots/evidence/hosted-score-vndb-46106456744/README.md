# Score validation: VNDB browser result

**All frozen semantic and memory gates pass; no whole-import gain is established.**
The candidate interval includes zero and identical-code controls move more.
This result does not remove the unfavorable retained Jitendex pair or extend the
separate approximately 1.6 ms warm JMdict validator result to VNDB.

| Item | Result |
| --- | --- |
| Frozen baseline / candidate | `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` / `915268441352c3c7aa50fc0fbd44f73f5a826d79` |
| Clean draft PR #978 head | `b15bad43acdfd54d541895cac1109c0e5ba51b2f` |
| Run / job / artifact | `46106456744` / `140880422226` / `15254620204` |
| Paired median / equal-work | -1.019399% / -1.083077% |
| Descriptive 95% interval | [-2.895646%, +0.681101%] |
| Identical-code median | -1.968847% |
| Faster pairs | 4/6; every pair retained |
| Semantics / memory | All 26 reports/receipts exact; all 570 raw scan rows audited; four observations qualify |
| Sampled private median / max | +2.490014% / +4.864194% |
| Sampled PSS median / max | +2.265224% / +3.981958% |

The actual sole changed package entry, `js/dictionary/term-record-opfs-store.js`,
exactly matches PR #978 Git blob `b17f72437f196aa1fd21b282c03f147aad7d633f`. Both complete nested package ZIPs
and every member match source identities. The reviewed generic v2 auditor
(`292eea976f78c24ce93f441b468c9a3efad62ad539cd9425c74eec893ee27ca0`) also verifies this cohort’s registered source SHA,
all 20 clock-summary links, exact schedule / 26 distinct receipts, fixed paired
statistics, raw memory/markers and final status. The prospective VNDB SAH value
stays exactly 37 units; no import flags or thresholds change. All lookup,
complete-storage-size, media/readback and restart receipt checks pass. Those
semantic checks are not exhaustive persisted-definition byte equality, and
sampled memory maxima are not exact peaks.

Raw evidence is bound by `independent-artifact-audit.json`; common method and
reproduction details remain in the batch README and reviewed auditor. Original
artifact: 35,260,207 bytes, SHA256
`76fb49b5928b9b247839b744302e294bd5911f1c127ae0e70fb4f282e4711135`. ZIP: `/home/agent/manabitan-import-capture-1b47/hosted-artifacts/score-validation-1b47-screen-vndb-15254620204.zip`.
Raw extraction: `/home/agent/manabitan-import-capture-1b47/hosted-artifacts/score-vndb-15254620204-extracted/vndb`.
All 206 original members, including HTML and package containers, remain in the ZIP.
No original observation, source, protocol or gate changed, and no browser rerun
was acquired. The parent owns the all-corpus draft PR decision.
