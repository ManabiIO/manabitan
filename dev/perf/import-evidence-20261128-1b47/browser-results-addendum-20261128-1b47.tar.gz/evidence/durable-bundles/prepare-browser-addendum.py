#!/usr/bin/env python3
"""Freeze already audited browser results; acquire no new observations."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / 'evidence'
OUT = EVIDENCE / 'browser-results-addendum-20261128-1b47'
BASE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CUTOFF = '2026-11-28T06:46:37Z'
sha = lambda data: hashlib.sha256(data).hexdigest()
cohorts = [
    ('checkpoint-jmdict', 'jmdict', 'hosted-checkpoint-jmdict-46104738613', 15252595561, 250),
    ('checkpoint-jitendex', 'jitendex', 'hosted-checkpoint-jitendex-46104738613', 15252102052, 299),
    ('pipeline-vndb', 'vndb', 'hosted-pipeline-vndb-46105215670', 15252770740, 503),
]
snapshot_bindings = []
raw_bindings = []
omissions = []
study_bindings = []
expected = {}


def require_regular(path):
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current = current / part
        assert not stat.S_ISLNK(current.lstat().st_mode), f'Symlink source: {current}'
    assert stat.S_ISREG(path.lstat().st_mode), path


def put(destination, data):
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        require_regular(destination)
        assert destination.read_bytes() == data, f'Frozen destination changed: {destination}'
    else:
        with destination.open('xb') as output:
            output.write(data)
    assert sha(destination.read_bytes()) == sha(data)


def snapshot(path):
    require_regular(path)
    relative = path.relative_to(ROOT)
    data = path.read_bytes()
    destination = OUT / 'snapshots' / relative
    put(destination, data)
    member = destination.relative_to(ROOT).as_posix()
    expected[member] = sha(data)
    snapshot_bindings.append({'originalWorkspacePath': relative.as_posix(),
        'memberPath': member, 'bytes': len(data), 'sha256': sha(data)})


for label, dictionary, receipt_name, artifact_id, expected_scans in cohorts:
    receipt_root = EVIDENCE / receipt_name
    audit_path = receipt_root / 'independent-artifact-audit.json'
    audit = json.loads(audit_path.read_text())
    original = Path(audit['archive'])
    assert str(original).startswith('/home/agent/manabitan-import-capture-1b47/hosted-artifacts/')
    require_regular(original)
    with original.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert digest == audit['archiveSha256'] and original.stat().st_size == audit['archiveBytes']
    inventory = {item['path']: item for item in audit['memberInventory']}
    assert len(inventory) == audit['memberCount'] == 206
    assert audit['all26ReceiptsExact'] is True and audit['allPackageBytesMatchIdentity'] is True
    assert audit['registeredPlan']['baseline'] == BASE
    assert audit['registeredPlan']['pairs'] == 6
    assert audit['rawMemoryScanAudit']['rawScanCount'] == expected_scans
    raw_count = scan_count = report_count = canonical_count = 0
    omitted_package_count = 0
    with zipfile.ZipFile(original) as source:
        file_names = [item.filename for item in source.infolist() if not item.is_dir()]
        assert len(file_names) == len(set(file_names)) and set(file_names) == set(inventory)
        for item in source.infolist():
            if item.is_dir():
                continue
            relative = PurePosixPath(item.filename)
            assert not relative.is_absolute() and '..' not in relative.parts
            assert not stat.S_ISLNK(item.external_attr >> 16)
            record = inventory[item.filename]
            assert item.file_size == record['bytes']
            if item.filename.endswith('.zip'):
                assert item.filename in {dictionary + '/package-A.zip', dictionary + '/package-B.zip'}
                omitted_package_count += 1
                omissions.append({'kind': 'duplicate-extension-package', 'cohort': label,
                    'originalArtifactId': artifact_id, 'originalArtifactMember': item.filename,
                    'bytes': record['bytes'], 'sha256': record['sha256'], 'included': False,
                    'originalArchiveSha256': digest,
                    'verification': 'Original full artifact digest rechecked here; original independent audit verified package bytes and every package entry',
                    'reconstruction': 'Obtain the exact original Actions artifact; a later build is not asserted to reproduce ZIP container bytes'})
                continue
            data = source.read(item)
            assert len(data) == record['bytes'] and sha(data) == record['sha256']
            destination = OUT / 'raw' / label / relative
            put(destination, data)
            member = destination.relative_to(ROOT).as_posix()
            expected[member] = record['sha256']
            raw_bindings.append({'cohort': label, 'originalArtifactId': artifact_id,
                'originalArtifactMember': item.filename, 'memberPath': member,
                'bytes': len(data), 'sha256': record['sha256']})
            raw_count += 1
            if item.filename.endswith('/memory.json') and '/memory/' in item.filename:
                scan_count += len(json.loads(data)['samples'])
            if item.filename.endswith('/run-1.json'):
                report_count += 1
            if item.filename.endswith('/canonical-receipt.json'):
                canonical_count += 1
    assert raw_count == 204 and omitted_package_count == 2
    assert scan_count == expected_scans and report_count == canonical_count == 26
    for directory, dirs, files in os.walk(receipt_root, followlinks=False):
        assert all(not (Path(directory) / name).is_symlink() for name in dirs)
        for name in files:
            snapshot(Path(directory) / name)
    omissions.append({'kind': 'original-artifact-container', 'cohort': label,
        'artifactId': artifact_id, 'file': original.name, 'bytes': audit['archiveBytes'],
        'sha256': digest, 'included': False,
        'reason': 'Every original member other than the two duplicate extension ZIPs is included separately with exact original bytes and member paths'})
    study_bindings.append({'cohort': label, 'dictionary': dictionary, 'artifactId': artifact_id,
        'originalArchiveBytes': audit['archiveBytes'], 'originalArchiveSha256': digest,
        'originalMembers': 206, 'retainedMembers': raw_count, 'omittedPackageMembers': omitted_package_count,
        'rawReports': report_count, 'canonicalReceipts': canonical_count, 'rawMemoryScans': scan_count,
        'candidate': audit['registeredPlan']['candidate'], 'baseline': BASE,
        'qualificationStatus': audit['status'], 'rawMemoryAudit': audit['rawMemoryScanAudit']})

snapshot_files = [
    'READOUT-1b47.md', 'evidence-inventory-1b47.json', 'session-ledger.json',
    'checkpoint-final-disposition-1b47.json', 'checkpoint-final-disposition-1b47.md',
    'cache-evidence-publication-addendum-1b47.json', 'session-evidence-publication-addendum-1b47.json',
    'product-publication-1b47.json', 'pending-study-review-20261128.md',
    'hosted-import-screens-status-20261128064637.json',
]
for name in snapshot_files:
    snapshot(EVIDENCE / name)

validator_bindings = []
dependencies = json.loads((EVIDENCE / cohorts[0][2] / 'independent-artifact-audit.json').read_text())['validatorDependencies']
for name, digest in dependencies.items():
    path = ROOT / 'manabitan' / name
    data = path.read_bytes()
    original = subprocess.check_output(['git', '-C', str(ROOT / 'manabitan'), 'show', f'{BASE}:{name}'])
    assert data == original and sha(data) == digest
    destination = OUT / 'validators' / name
    put(destination, data)
    member = destination.relative_to(ROOT).as_posix()
    expected[member] = digest
    validator_bindings.append({'baselinePath': name, 'memberPath': member, 'bytes': len(data), 'sha256': digest})

receipt = {'cutoffUtc': CUTOFF, 'priorSnapshotCommit': '0df239a1be2cde2fc8586665413b7da7845f9fb6',
    'baseline': BASE, 'cohorts': study_bindings, 'rawMembers': raw_bindings,
    'snapshots': snapshot_bindings, 'validatorFiles': validator_bindings,
    'totalRetainedArtifactMembers': len(raw_bindings),
    'totalRawBrowserReports': sum(x['rawReports'] for x in study_bindings),
    'totalCanonicalReceipts': sum(x['canonicalReceipts'] for x in study_bindings),
    'totalRawMemoryScans': sum(x['rawMemoryScans'] for x in study_bindings),
    'omittedPackageCount': sum(x['omittedPackageMembers'] for x in study_bindings),
    'allOriginalHashesVerified': True, 'symlinksFollowed': False,
    'newObservationsAcquired': 0, 'priorArchivesModified': False}
assert receipt['totalRetainedArtifactMembers'] == 612
assert receipt['totalRawBrowserReports'] == receipt['totalCanonicalReceipts'] == 78
assert receipt['totalRawMemoryScans'] == 1052 and receipt['omittedPackageCount'] == 6
(OUT / 'staging-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

selected = set()
for directory, dirs, files in os.walk(OUT, followlinks=False):
    assert all(not (Path(directory) / name).is_symlink() for name in dirs)
    for name in files:
        path = Path(directory) / name
        require_regular(path)
        selected.add(path.relative_to(ROOT).as_posix())
for name in ['evidence/durable-bundles/package-evidence-v2.py',
             'evidence/durable-bundles/prepare-browser-addendum.py',
             'evidence/audit-hosted-import-artifact-1b47.py']:
    path = ROOT / name
    require_regular(path)
    selected.add(name)
    expected[name] = sha(path.read_bytes())
assert expected['evidence/audit-hosted-import-artifact-1b47.py'] == 'df10a6f16eb17cbcff1da3b8c5f622f6e34808587549790187f78be67f22c2c5'
spec_rel = (OUT / 'bundle-spec.json').relative_to(ROOT).as_posix()
selected.add(spec_rel)
spec = {'name': 'browser-results-addendum-20261128-1b47',
    'study': 'Three newly completed browser qualification cohorts, cutoff ' + CUTOFF,
    'scope': 'Every original artifact member except six duplicate extension ZIPs; all raw reports, canonical receipts, HTML views, memory scan rows, plans, fixed analyses and failures retained; no new acquisition',
    'sourceBindings': {'baseline': BASE, 'cutoffUtc': CUTOFF,
        'details': 'evidence/browser-results-addendum-20261128-1b47/staging-receipt.json'},
    'include': sorted(selected), 'expectedSha256': expected, 'omitExternal': omissions}
(ROOT / spec_rel).write_text(json.dumps(spec, indent=2) + '\n')
print(json.dumps({'spec': spec_rel, 'members': len(selected),
    'payloadBytes': sum((ROOT / name).stat().st_size for name in selected),
    'rawArtifactMembers': len(raw_bindings), 'reports': 78, 'memoryScanRows': 1052,
    'omittedPackages': 6, 'cutoffUtc': CUTOFF}))
