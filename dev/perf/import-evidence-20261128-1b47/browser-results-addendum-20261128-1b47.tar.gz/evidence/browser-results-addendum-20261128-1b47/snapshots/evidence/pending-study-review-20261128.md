# Remaining checkpoint and pipeline studies: bounded read-only assessment

As of 2026-11-28 06:32:35 UTC, the already registered checkpoint JMdict and
Jitendex jobs are running their unchanged qualification. Pipeline VNDB is also
running; pipeline JMdict remains queued. This note does not register a study,
change a gate, retry a job or predict an ETA.

## Checkpoint: the targeted local paths are now being measured

The candidate adds an 8 MiB periodic checkpoint to the local synchronous index
writer. The baseline local path flushes at close; it is not a 4→8 MiB threshold
change. The dedicated I/O worker retains its existing 16 MiB checkpoints.
Final header rewrite, flush, close, queue ordering and sticky failures remain.
The exact candidate source is `0efd7507eb19b0b7f15410b14aac427e80e22244`.

The source-bound baseline JMdict ordinary receipt records zero index-worker
files, 23,748,912 index bytes in five logical batches, and a 130.6 ms record-close
region inside 135.8 ms record finalization. That region includes draining and
closing index/record writes and publication state; it is not an isolated fsync
measurement. An 8 MiB threshold introduces two interim barriers for this
sidecar size, then still performs the final flush. Moving work earlier could
reduce a tail if parser/compression progress overlaps it, but it can also block
the import thread earlier or increase total I/O work. The old 130.6 ms region
does not establish a saving or a reliable upper bound on this host.

The analogous Jitendex baseline uses zero index-worker files and 23,590,812 index
bytes in six logical batches, but its record-close region is only 10.3 ms and
record finalization 16.8 ms. These are individual orientation observations from
the same frozen baseline, not comparative estimates; they make a large Jitendex
gain less strongly motivated than a JMdict tail improvement.

The completed checkpoint VNDB study is an informative control for the unchanged
path. All 26 browser reports select two index-worker files. Both packages retain
the worker's 16 MiB policy. Its six complete-import pairs show no useful speed
signal (median −0.714%, descriptive interval [−3.955%, +4.049%], identical-code
median +1.102%). All semantic and sampled-memory gates pass, independently
revalidated from the artifact. This does not resolve the local JMdict/Jitendex
mechanism. Their existing running jobs are the appropriate remaining evidence;
no additional experiment is warranted by this read-only assessment.

## Pipeline: low current confidence, and the actual target remains unmeasured

The original and source-consumed revisions retain separate complete Node sink
cohorts. Both have unfavorable point estimates (approximately +11.64% and
+10.09% geometric wall time), with wide variation in the revised cohort. The
Node asynchronous filesystem boundary differs from browser synchronous OPFS,
so those results justified at most the one already registered browser screen.
They are not affirmative evidence of a gain.

The hosted Jitendex job completed all timing, full-media and memory imports; all
26 semantic receipts match. Every one of six B/A timing pairs is slower, with
median +2.282%, equal-work +3.693% and descriptive interval [+0.699%, +8.163%].
The two identical-code control pairs range from −3.037% to +10.188%, so the
precise causal slowdown cannot be assigned from this cohort. The separate
baseline A1 memory observation has a 350.393 ms covered-scan gap exceeding the
frozen 250 ms limit, making the memory comparison unqualified. This is neither
a browser import failure nor a semantic failure; the exact failed gate remains
in the report. There is no useful gain and no basis for a pipeline PR so far.

The deferred mechanism requires an adopted owned source, among other conditions.
All 11 candidate Jitendex observations have 22 borrowed groups, zero owned
parser bytes, zero adopted source bytes and zero deferred persistence/wait,
confirmed by independent activation review. That distinction matters: unchanged-path timing cannot demonstrate
the hoped-for JMdict overlap. The already queued JMdict job remains the concrete
targeted evidence. Even a favorable point estimate would still need its exact
work, ownership, memory and identical-code controls examined before a decision.

## Evidence

- `hosted-import-screens-status-20261128063235.json`.
- `score-checkpoint-claim-audit.md`, with the historical status paragraph read
  at its original audit time, and the current source-bound ordinary receipts
  under `current-baseline-{jmdict,jitendex}/ordinary/summary.json`.
- Frozen writer source in `checkpoint-experiment/ext/js/dictionary/term-record-import-index-writer.js`
  and baseline `manabitan/ext/js/dictionary/term-record-opfs-store.js`.
- `hosted-checkpoint-vndb-46104738613/{independent-artifact-audit,mechanism-activation}.json`.
- `hosted-pipeline-jitendex-46105215670/{analysis,independent-artifact-audit}.json`.
- Both preserved Node cohorts: `node-jmdict-pairs` and
  `node-jmdict-source-consumed-pairs`.

The active action remains monitoring and auditing the existing cohorts. No
additional local acquisitions, alternate runner trials or replacement jobs are
proposed.
