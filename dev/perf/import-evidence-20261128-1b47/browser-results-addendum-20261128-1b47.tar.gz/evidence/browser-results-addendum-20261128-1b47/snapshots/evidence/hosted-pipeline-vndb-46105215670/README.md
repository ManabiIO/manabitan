# Pipeline VNDB: complete qualification; inactive-path control

Frozen candidate `05907e30c83b4cc7cc8d653e069427a6141b0e85` versus baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. Actions run 46105215670, job 140867306576 completed successfully. This is a later addendum to the unchanged 06:32:35 session-evidence snapshot.

All 20 timing/control/warmup observations, two full-media imports and four separate sampled-memory imports completed. Independent audit replays the unchanged receipt validator on all 26 raw reports and exactly reproduces canonical receipt comparisons, both actual package ZIP/member identities, timing/control statistics and all 503 raw memory scans. All frozen semantic and memory gates pass. Only the two declared JS package entries differ.

The whole-import result is flat: paired median −0.648778%, equal-work −0.207444%, descriptive 95% paired-median interval [−1.295844%, +1.378595%], five of six candidate pairs faster. Identical-code control median is −0.273195%; its interval crosses zero. No useful speed gain is established.

All 11 candidate observations have 91,670,244 owned parser bytes, but zero recent-source adopted bytes, deferred persistence count and deferred wait. Owned bytes alone do not satisfy the admission gate. Consequently this cohort does not exercise the new cross-chunk persistence mechanism and cannot demonstrate its hoped-for JMdict overlap benefit.

All four memory observations qualify. Sampled private bytes change median +1.036397%, maximum +2.939798%; PSS changes median +0.616478%, maximum +2.270618%. These non-atomic scan maxima are not exact process peaks.

Artifact 15252770740 has 206 members, 35,215,591 bytes and SHA-256 `3eaa1db3589e59d913e320861c7ec37cdf3ba3113d62a87a3ae95947a44ea74e`. Complete ZIP and non-package/non-HTML extraction remain in the task-owned `/home/agent/manabitan-import-capture-1b47/hosted-artifacts` directory. This directory retains the full job log, emitted raw JSON, artifact/member identity proof, independent audit and activation census. No new benchmark, source change, retry or substituted observation occurred during this audit.
