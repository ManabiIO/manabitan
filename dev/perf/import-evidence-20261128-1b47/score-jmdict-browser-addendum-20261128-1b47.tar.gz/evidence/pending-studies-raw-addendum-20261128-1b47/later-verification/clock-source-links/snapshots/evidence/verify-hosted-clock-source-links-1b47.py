#!/usr/bin/env python3
"""Supplemental cross-file assertions for seven already audited browser cohorts.

This does not replace or rewrite any original artifact, audit, observation, plan,
summary, validator, analysis, or threshold. It adds explicit source-plan and
observation-summary links to the proof retained by the original audits.
"""
import argparse
import hashlib
import json
import pathlib

parser = argparse.ArgumentParser()
parser.add_argument('--output', type=pathlib.Path, required=True)
args = parser.parse_args()
assert not args.output.exists(), 'Never replace an earlier supplemental result'
evidence = pathlib.Path(__file__).resolve().parent
baseline = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
sha = lambda data: hashlib.sha256(data).hexdigest()
studies = [
    ('checkpoint', 'jmdict', 46104738613, '0efd7507eb19b0b7f15410b14aac427e80e22244'),
    ('checkpoint', 'jitendex', 46104738613, '0efd7507eb19b0b7f15410b14aac427e80e22244'),
    ('checkpoint', 'vndb', 46104738613, '0efd7507eb19b0b7f15410b14aac427e80e22244'),
    ('pipeline', 'jmdict', 46105215670, '05907e30c83b4cc7cc8d653e069427a6141b0e85'),
    ('pipeline', 'jitendex', 46105215670, '05907e30c83b4cc7cc8d653e069427a6141b0e85'),
    ('pipeline', 'vndb', 46105215670, '05907e30c83b4cc7cc8d653e069427a6141b0e85'),
    ('score', 'jmdict', 46106456744, '915268441352c3c7aa50fc0fbd44f73f5a826d79'),
]
results = []
for candidate, dictionary, run_id, expected_candidate in studies:
    audit_path = evidence / f'hosted-{candidate}-{dictionary}-{run_id}' / 'independent-artifact-audit.json'
    audit_bytes = audit_path.read_bytes()
    audit = json.loads(audit_bytes)
    root = pathlib.Path(audit['extraction'])
    member_map = {item['path']: item for item in audit['memberInventory']}
    assert len(member_map) == len(audit['memberInventory'])
    checked_hashes = {}

    def read(name):
        relative = dictionary + '/' + name
        data = (root / relative).read_bytes()
        expected = member_map[relative]
        assert len(data) == expected['bytes'], relative
        assert sha(data) == expected['sha256'], relative
        checked_hashes[relative] = sha(data)
        return json.loads(data)

    plan = read('registered-plan.json')
    identities = read('source-identities.json')
    observations = read('observations.json')
    assert plan['baseline'] == baseline
    assert plan['candidate'] == expected_candidate
    assert plan['dictionary'] == dictionary
    assert identities['arms']['A']['sha'] == plan['baseline']
    assert identities['arms']['B']['sha'] == plan['candidate']
    assert audit['registeredPlan'] == plan
    assert audit['sourceIdentities'] == identities
    assert len(observations) == len(plan['schedule']) == 20
    assert len({item['id'] for item in observations}) == 20
    assert plan['initialOrder'] in ('AB', 'BA') and plan['pairs'] == 6
    first = plan['initialOrder']
    opposite = first[::-1]
    expected_schedule = []
    for pair, order in enumerate((first, opposite), 1):
        for arm in order:
            expected_schedule.append({'id': f'warmup-{pair}-{arm}', 'kind': 'warmup', 'pair': pair, 'arm': arm})
    for pair in range(1, 7):
        for arm in first if pair % 2 else opposite:
            expected_schedule.append({'id': f'pair-{pair:02d}-{arm}', 'kind': 'candidate', 'pair': pair, 'arm': arm})
        if pair % 3 == 0:
            control_pair = pair // 3
            order = 'AC' if (control_pair + (first == 'BA')) % 2 else 'CA'
            for arm in order:
                expected_schedule.append({'id': f'control-{control_pair:02d}-{arm}', 'kind': 'control', 'pair': control_pair, 'arm': arm})
    assert plan['schedule'] == expected_schedule
    receipt_names = [item['path'] for item in audit['receiptsRevalidated']]
    assert len(receipt_names) == len(set(receipt_names)) == 26
    expected_names = [item['id'] for item in plan['schedule']]
    expected_names += ['exhaustive-media-A', 'exhaustive-media-B']
    expected_names += ['memory/' + item['name'] for item in plan['memorySchedule']]
    assert receipt_names == expected_names
    memory = read('memory/memory-audit.json')
    assert memory == audit['rawMemoryScanAudit']
    assert dictionary + '/memory/memory-audit-failure.json' not in member_map
    semantic_failures = read('memory/semantic-failures.json')
    analysis = read('analysis.json')
    passed = memory['passesProspectiveMemoryScreen'] and not semantic_failures
    status = 'correctness-memory-passed' if passed else 'memory-or-semantics-failed'
    assert analysis['memoryPassed'] is passed
    assert analysis['status'] == audit['status'] == status
    assert analysis['candidateVsBaseline']['count'] == 6
    assert analysis['identicalCodeControl']['count'] == 2
    timings = []
    for planned, observed in zip(plan['schedule'], observations):
        assert all(observed[key] == value for key, value in planned.items())
        summary = read(observed['id'] + '/summary.json')
        assert len(summary['runs']) == 1
        actual = summary['runs'][0]['totalImportMs']
        assert observed['totalImportMs'] == actual, observed['id']
        # The original source-bound validator already binds this summary to
        # browser monotonic timing in the raw report. Verify those report bytes
        # remain the exact original artifact members; do not rewrite/revalidate
        # the original result under a changed rule.
        read(observed['id'] + '/run-1.json')
        timings.append({'id': observed['id'], 'arm': observed['arm'],
                        'observationTotalImportMs': observed['totalImportMs'],
                        'rawSummaryTotalImportMs': actual, 'equal': True})
    assert audit_path.read_bytes() == audit_bytes
    results.append({
        'candidate': candidate, 'dictionary': dictionary, 'runId': run_id,
        'originalAudit': str(audit_path), 'originalAuditSha256': sha(audit_bytes),
        'originalArchiveSha256': audit['archiveSha256'],
        'registeredBaseline': plan['baseline'], 'registeredCandidate': plan['candidate'],
        'sourceIdentityLinksExact': True, 'all20ObservationSummaryClockLinksExact': True,
        'frozenScheduleAnd26DistinctReceiptNamesExact': True,
        'analysisStatusBoundToRecomputedMemoryAndSemanticResult': True,
        'originalMemberHashesRechecked': checked_hashes, 'timings': timings,
    })

result = {
    'scope': 'Supplemental read-only cross-file links only; original seven audits and all raw data unchanged',
    'newExplicitAssertions': [
        'A/B source-identities SHA equal frozen registered baseline/candidate',
        'Each observations totalImportMs exactly equals its corresponding original raw summary totalImportMs',
        'Frozen 20-record schedule, six candidate pairs, two controls and 26 distinct receipts are exact',
        'Final status/memoryPassed agrees with original recomputed raw-memory audit and semantic failures',
    ],
    'existingProofRetained': 'Original validator binds summary time to browser monotonic raw report; original audit validates package bytes, receipts, schedule, memory scans and statistics',
    'scriptSha256': sha(pathlib.Path(__file__).read_bytes()),
    'cohorts': results, 'cohortCount': len(results), 'timingLinks': sum(len(x['timings']) for x in results),
    'allPassed': True, 'acquiredObservations': 0,
}
with args.output.open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps({'allPassed': True, 'cohortCount': len(results), 'timingLinks': result['timingLinks'],
                  'output': str(args.output), 'originalAuditsAndRawDataUnchanged': True}))
