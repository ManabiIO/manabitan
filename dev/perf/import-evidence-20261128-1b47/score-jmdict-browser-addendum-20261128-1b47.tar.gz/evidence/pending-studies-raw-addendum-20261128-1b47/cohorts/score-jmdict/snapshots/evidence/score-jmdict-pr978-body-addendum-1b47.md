## JMdict browser qualification update — 2026-11-28 07:08 UTC

The completed [JMdict job](https://github.com/ManabiIO/manabitan/actions/runs/46106456744/job/140880422290) does **not establish a whole-import speedup**. Its actual packaged runtime is exactly this PR's `term-record-opfs-store.js` blob, `b17f72437f196aa1fd21b282c03f147aad7d633f`; that is the only differing package entry.

All 26 browser imports and their recorded source/work, lookup, storage-size, media and restart checks passed. The six fixed candidate pairs give **−0.960% paired median** and **−0.927% equal-work** timing changes, with a descriptive paired-median interval of **[−3.508%, +1.757%]**. The two identical-code control pairs move **−3.248%** at the median. The interval crosses zero and controls move more favorably; no speedup is attributed to the candidate point estimate or calculated by subtracting control drift. Every observation remains included.

The job fails its separate memory-coverage gate: candidate **B2** has a **252.093481 ms** covered-sample gap against the predeclared **250 ms** limit. Its sampled PSS/private maxima remain null, so the complete memory comparison is unqualified. The threshold is not rounded or waived, and the surviving pair is not substituted. This is insufficient sampling coverage, not a demonstrated memory regression or semantic failure.

The previously measured **1.57–1.60 ms saving per complete warm validator corpus** remains a separate component result. This draft makes no whole-import speedup or passed browser-memory claim. At this review cutoff, Jitendex and VNDB remain separate pending qualifications. The semantic receipts do not claim exhaustive byte equality for every stored definition.

Original [source-bound artifact](https://github.com/ManabiIO/manabitan/actions/runs/46106456744/artifacts/15253012612): SHA-256 `a94ec5951f9df34bfc3ddabb1e4eeca26b0353135b18e22f036a24915d2f61a4`. All 26 receipts and all 250 original memory scans were independently audited; no retry or replacement cohort was acquired.
