# Indexed score-validation restoration: JMdict browser result

Audited 2026-11-28 07:08 UTC. This is a new addendum after the immutable 06:58:33
checkpoint/pipeline snapshot. No observation, source, protocol or threshold changed.

**The complete browser cohort does not establish a whole-import speedup.**
All 26 imports and their semantic checks succeeded, but the separate memory
coverage screen failed because candidate B2 had a 252.093481 ms covered-scan gap
against the prospectively fixed 250 ms limit. That failed gate remains intact.
The small, separately measured warm-validator benefit supporting draft PR #978
is a different result; this browser study does not convert it into an import claim.

## Exact source and acquisition

- Baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
- Frozen experimental candidate: `915268441352c3c7aa50fc0fbd44f73f5a826d79`.
- Clean product PR #978: `b15bad43acdfd54d541895cac1109c0e5ba51b2f`.
- The only differing packaged entry is `js/dictionary/term-record-opfs-store.js`.
  Its actual bytes produce Git blob `b17f72437f196aa1fd21b282c03f147aad7d633f`
  and SHA-256 `63942c3dc97eab215293bf04a138844d505605386bc61322b3f2f29e20d1d769`,
  exactly matching the previously validated two-line restoration.
- Actions [run 46106456744](https://github.com/ManabiIO/manabitan/actions/runs/46106456744),
  job 140880422290; job conclusion `failure` after complete acquisition.
- The unchanged driver completed six AB/BA candidate pairs, two identical-code
  control pairs, four excluded warmups, two exhaustive-media imports and four
  separately instrumented memory imports. There were no import flags, product
  overlays, unregistered harness changes, substituted observations or retries.
  The four memory imports use the prospectively registered marker-only harness
  overlay; their source hashes and dirty status are validated separately.

The timer covers file-input change through post-UI completion in a fresh profile.
Readback, restart and the separate memory observations are outside this timing.
The original browser executable hash/version, fixture identities, full source
and package identities, plan, observations and analysis remain in the artifact.

## Whole-import timing

| Estimate | B/A candidate | C/A identical code |
| --- | ---: | ---: |
| Paired median change | −0.959757% | −3.247853% |
| Equal-work change | −0.927278% | −3.265772% |
| Descriptive 95% paired-median interval | [−3.507763%, +1.756795%] | [−4.169633%, −2.326073%] |
| Faster pairs | 4 / 6 | 2 / 2 |

The candidate interval crosses zero and the two identical-code pairs both show
larger favorable movements. With only two control pairs, their intervals do not
provide an independent population estimate; they visibly limit attribution of
the candidate point estimate. No adjusted speedup is calculated by subtracting
control drift. Every favorable and unfavorable candidate pair is retained.

The direct validator study remains approximately 1.57–1.60 ms saved for one warm
validation of all 528,299 real rows. Its repeated component measurement and this
one-host complete-import screen have different boundaries. Neither the
−0.96% browser point estimate nor the earlier much larger Node sink estimate is
attributed to these two source lines.

## Memory and semantic qualification

The independent auditor reproduced all 250 original raw process-tree scan rows,
markers and the original memory audit. Candidate B2 has the sole qualification
failure: `covered-import-scan-gap-over-250ms`, at **252.093481 ms**.
Its maxima stay null; the complete sampled-memory comparison is unqualified.

A1, B1 and A2 individually qualify. Pair 1 sampled private memory changes
+2.350460% and sampled PSS +2.180742%; pair 2 has null candidate maxima.
A single qualified pair cannot substitute for the declared complete screen.
No missing or unqualified reading is assigned zero, and no threshold is relaxed.
This is a sampling-coverage failure, not a browser exception, semantic failure
or demonstrated product memory regression.

All **26 raw reports and canonical semantic receipts** independently revalidate
against the unchanged source-bound helpers. Lookup/work/storage-size,
media/readback/restart checks and declared schedule match across arms.
Actual original nested extension ZIP bytes and every decompressed package member
match their identities, with exactly the one expected changed entry.
These semantic receipts are not an exhaustive equality proof for every
persisted definition byte.

## Retained files and audit

`job.log` is the complete Actions job log. `analysis.json`,
`observations.json`, `registered-plan.json`, `browser-identity.json`,
`memory/`, `run-statuses.json` and `artifact-metadata.json` preserve the emitted
values. `independent-artifact-audit.json` inventories all 206 original artifact
members, actual package/member hashes, all receipt checks, raw memory audit and
exact recomputation of the original fixed paired statistics.

Original artifact:

- ID: 15253012612; size: 34,929,639 bytes.
- SHA-256: `a94ec5951f9df34bfc3ddabb1e4eeca26b0353135b18e22f036a24915d2f61a4`.
- ZIP: `/home/agent/manabitan-import-capture-1b47/hosted-artifacts/score-validation-1b47-screen-jmdict-15253012612.zip`.
- Raw JSON extraction: `/home/agent/manabitan-import-capture-1b47/hosted-artifacts/score-jmdict-15253012612-extracted/jmdict`.
- The original ZIP also retains the HTML report views and both complete extension
  packages; the working extraction omits those duplicate containers/views.

The existing read-only `audit-hosted-import-artifact-1b47.py` was used without
modification, against exact baseline validator files, into a new output and
extraction directory. It does not rerun a browser. No replacement acquisition,
workflow edit, source change or new qualification claim follows this result.
The parent owns the draft PR disposition; Jitendex/VNDB browser studies remain
separate pending results.
