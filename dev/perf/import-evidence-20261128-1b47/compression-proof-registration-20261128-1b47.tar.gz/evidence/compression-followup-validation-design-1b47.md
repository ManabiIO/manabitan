# Separate compression follow-up: validation design

**Read-only proposal; not implemented or acquired.** This design does not qualify, repair, or replace the failed original JMdict trial. It addresses a specific mismatch between an intended representation change and the frozen cross-arm comparison.

## What the existing failure proves

The original artifact `15254590844`, SHA256 `739c895cafc5213c499dc9097a27b16a4505de7767dc6ed010fbdffe82f9c9fd`, contains two successful raw warmup imports. After the policy's declared adjustments, the only differing canonical field is `.common.validation.outputDigestSha256`. The content-file and complete-storage deltas both equal the predicted **312,404 bytes**, or **0.717832%** of baseline complete storage, within the unchanged 2% budget. All 72 retained post-restart lookup result hashes agree across arms.

The frozen harness computes that output digest from diagnostic probes containing raw storage previews, raw references and a store-length field. The previews read raw OPFS bytes; separately decoded diagnostic data is not included. Consequently, the digest is not a representation-independent semantic invariant. The prospective policy accounted for the two explicit storage-size fields but missed this embedded dependency.

The exact physical-probe preimages were not saved. We can identify the differing receipt field, but cannot reconstruct which unhashed input differed or prove that one representation field was its sole cause. The original trial therefore remains failed and incomplete: **zero measured pairs, zero identical-code controls, and no later exhaustive-media or memory qualification**. Existing warmup times are not a performance estimate.

## Minimal additional evidence

Retain the original `outputDigestSha256` and its existing pre/post-restart equality check. Capture the **exact serialized input to that digest** before and after restart, rather than the entire diagnostic object. Retain its UTF-8 bytes or an exact byte-preserving encoding, byte count and digest. An independent validator must recompute the original hash and validate the expected term/probe structure. Do not replace or blank the original physical digest.

The existing 72 lookup hashes are useful: they hash complete `termsFind` results for 12 fixed terms over six post-restart passes. They do **not** provide an explicit decoded result before restart, and hashes alone do not permit independent inspection of their semantic preimages. Therefore physical-preimage capture alone is insufficient for the requested restart proof.

Add one decoded lookup pass for the **same 12 terms before restart**, outside the authoritative import timer. Retain the exact serialized decoded result for each term before restart and for the first post-restart pass. Keep the existing six post-restart passes and their numbering unchanged. Require:

1. Every retained response hash recomputes from its exact serialized bytes and satisfies the existing exact-headword/dictionary/result checks.
2. Each term's decoded result is byte-identical before and after restart, and every existing post-restart pass matches that result.
3. The complete decoded result sequence matches across A/B, A/C and repeated observations, with fixed term order and no omitted, truncated or substituted result.

This supplies the original **sampled semantic scope**, now with explicit decoded restart equality. It does not prove exhaustive equality of every dictionary definition. The earlier independent full-frame codec checks remain separate evidence; they are not relabeled as complete-browser readback.

## Comparison policy

Use a separately named and versioned comparison receipt. Preserve raw reports, raw canonical receipts, both physical preimages and their digests, decoded preimages and their digests, and an explicit transformation audit.

For **A/C and B/B**, continue requiring the original raw canonical receipts—including the physical digest—to match exactly. Within each import, keep both physical and decoded pre/post-restart checks. A physical difference within an arm or across restart is not licensed by a compression-level change.

For **A/B only**, retain the existing exact content-file and complete-storage deltas and the original total-storage budget. Compare every other original canonical field exactly. Replace the physical-digest _domain only in the labeled comparison record_ with a distinctly named decoded-proof field computed from the independently validated decoded preimages. Do not copy the reference arm's digest, erase arbitrary differences, or overwrite the raw field. The original generic matcher can still compare the resulting complete records exactly; the new policy must validate the permitted transformation first.

The physical preimages provide a further check. Predeclare cross-arm variation only for raw previews and the physical store-length field. Keep term/probe identity, logical references, sample counts and glossary/readability counts exact. A store-length value must agree with the raw storage inventory, or retain the same documented unavailable sentinel in both arms; do not assume that the actual offscreen probes expose the local store-length field. Any additional difference stops the follow-up and remains in the evidence. The allowed paths must be fixed before acquisition, not inferred afterward from whatever differs.

## Frozen acquisition and failure boundaries

If authorized, create a **new study identity** and freeze the corrected validation schema, harness bytes, policy, independent reader, product hashes and fixed schedule before any observation. Preserve the original six candidate pairs, two identical-code controls, warmups, full-media checks, separate memory observations, timing boundary and original gates. The baseline and candidate product bytes remain unchanged. There is no pooling with the failed original study, replacement of an unfavorable observation, adaptive sample expansion, or later relaxation of the allowed paths.

The added capture and pre-restart decoded checks occur after the original import endpoint. Apply the exact same validation harness to every arm and record its explicit source identity; do not describe a permitted validation overlay as an untouched baseline harness or broadly allow dirty source trees. Keep the original memory-marker boundary and its independently checked overlay separate.

Before acquisition, meaningful focused policy checks should reject changed decoded content, missing or forged preimages, mismatched pre/post-restart results, physical differences in A/C or B/B, unexpected physical-preimage paths, and wrong byte deltas or budget overruns. A correct representation-only A/B fixture should pass with identical decoded results while preserving both distinct raw physical digests. The original failed artifact must remain unqualifiable because it lacks the new mandatory evidence.

A single fixed follow-up is defensible as a correction of this concrete validation omission. It is not evidence that the product is faster, and it does not justify another revision if the corrected study fails or is unconvincing. No implementation or new acquisition is included in this proposal.
