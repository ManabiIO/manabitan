#!/usr/bin/env python3
"""Move only two closed, published evidence trees after exact member checks."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


ROOT = Path('/workspace/scratch/1b47f6463b98')
PACKAGES = ROOT / 'evidence/durable-bundles/packages'
HOME = Path('/home/agent/manabitan-import-capture-1b47')
RUN = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
DESTINATION = HOME / ('closed-staging-relocation-' + RUN)
RECEIPT = ROOT / 'evidence/durable-bundles' / ('closed-staging-relocation-' + RUN + '.json')
REMOTE_DIRECTORY = 'dev/perf/import-evidence-20261128-1b47'
TARGETS = (
    {
        'source': 'evidence/browser-results-addendum-20261128-1b47',
        'stem': 'browser-results-addendum-20261128-1b47',
        'commit': '28332c2fc3a291f1728cd0441a878e3d5bd335ae',
        'archiveSha256': '76b1ae9451052684192902916b5cdeb1e812ff806b064d0773e6d2bdf242ec98',
        'archiveGitBlob': 'ee36cf0db721263cb7a6e023132a9bd60c8a0cb1',
        'manifestSha256': '5d418c9cd6176cc22dd56cd81d3cad13eb3880bf095c0662aea5efa42f5fbe20',
        'manifestGitBlob': '5196e281a7eed8dc377b31545f9ca6ec53a24dbd',
    },
    {
        'source': 'evidence/immediate-comma',
        'stem': 'import-session-held-evidence-20261128-1b47',
        'commit': '0df239a1be2cde2fc8586665413b7da7845f9fb6',
        'archiveSha256': 'eed792a9c77ffcdc65fcffa2106157b365dc8a56369a06bcd640d1b6ba060f8b',
        'archiveGitBlob': '0d1fb944191a3bdc66ae726541117f7f543b0056',
        'manifestSha256': 'a9a78f56fb65cfffc46e38d6dcd1e9cc3d6806ff15274a9f096e253b6f0c93f5',
        'manifestGitBlob': '96ac5155fea9e36e5aa58d6970c96fe9c268a2db',
    },
)


def digest(path):
    result = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def inventory(path):
    assert path.is_dir() and not path.is_symlink(), str(path)
    result = {}
    for parent, dirs, files in os.walk(path, followlinks=False):
        for name in dirs:
            assert not (Path(parent) / name).is_symlink(), str(Path(parent) / name)
        for name in files:
            file = Path(parent) / name
            assert file.is_file() and not file.is_symlink(), str(file)
            result[str(file.relative_to(path))] = {'bytes': file.stat().st_size, 'sha256': digest(file)}
    return result


def git_blob(path):
    return subprocess.check_output(['git', 'hash-object', str(path)], cwd=ROOT / 'manabitan', text=True).strip()


def save(record):
    temporary = RECEIPT.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(record, indent=2) + '\n')
    temporary.replace(RECEIPT)


assert not DESTINATION.exists() and not RECEIPT.exists()
record = {
    'scope': 'Root-authorized capacity repair of two closed, already-published staging trees only; no source, worktree, unpublished preparation or old payload symlink followed',
    'startedUtc': datetime.now(timezone.utc).isoformat(),
    'scriptSha256': digest(Path(__file__)),
    'destinationRoot': str(DESTINATION),
    'workspaceFreeBeforeBytes': shutil.disk_usage(ROOT).free,
    'homeFreeBeforeBytes': shutil.disk_usage(HOME).free,
    'recovery': 'The home capture directory is transient. Original archive and manifest files stay in workspace. If a symlink becomes dangling, obtain the exact listed local archive or the same immutable repository archive/blob, verify both SHA-256 identities, and extract only the listed original source prefix into a new task-owned directory. Never substitute a rebuilt artifact or acquire new observations.',
    'targets': [],
}
plans = []
for target in TARGETS:
    source = ROOT / target['source']
    archive = PACKAGES / (target['stem'] + '.tar.gz')
    manifest_path = PACKAGES / (target['stem'] + '.manifest.json')
    assert digest(archive) == target['archiveSha256']
    assert git_blob(archive) == target['archiveGitBlob']
    assert digest(manifest_path) == target['manifestSha256']
    assert git_blob(manifest_path) == target['manifestGitBlob']
    manifest = json.loads(manifest_path.read_text())
    assert manifest['archive']['sha256'] == target['archiveSha256']
    prefix = target['source'] + '/'
    expected = {member['path'][len(prefix):]: {key: member[key] for key in ('bytes', 'sha256')}
                for member in manifest['members'] if member['path'].startswith(prefix)}
    before = inventory(source)
    assert before == expected and before, target['source']
    destination = DESTINATION / target['source']
    entry = {**target, 'destination': str(destination), 'files': len(before),
             'bytes': sum(value['bytes'] for value in before.values()),
             'inventorySha256': hashlib.sha256(json.dumps(before, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
             'localRecoveryArchive': str(archive), 'localRecoveryManifest': str(manifest_path),
             'immutableArchivePath': REMOTE_DIRECTORY + '/' + archive.name,
             'immutableManifestPath': REMOTE_DIRECTORY + '/' + manifest_path.name,
             'state': 'durable-member-preflight-passed'}
    record['targets'].append(entry)
    plans.append((source, destination, before, entry))
assert 80_000_000 <= sum(entry['bytes'] for entry in record['targets']) <= 150_000_000
save(record)
for source, destination, before, entry in plans:
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(source, destination, symlinks=True)
    assert inventory(destination) == before
    assert inventory(source) == before
    entry['state'] = 'complete-copy-and-source-reverified'
    save(record)
    backup = source.with_name(source.name + '.verified-relocation-old-' + RUN)
    assert not backup.exists() and not backup.is_symlink()
    source.rename(backup)
    try:
        source.symlink_to(destination, target_is_directory=True)
        assert source.is_symlink() and os.readlink(source) == str(destination)
        assert inventory(destination) == before
    except Exception:
        if source.is_symlink():
            source.unlink()
        backup.rename(source)
        raise
    # Only our verified renamed staging tree is removed, after copy and link checks.
    assert inventory(backup) == before
    shutil.rmtree(backup)
    entry['state'] = 'workspace-copy-removed-and-path-symlinked'
    entry['sourceAndDestinationMemberHashesExactBeforeRemoval'] = True
    save(record)
record['finishedUtc'] = datetime.now(timezone.utc).isoformat()
record['reclaimedPayloadBytes'] = sum(entry['bytes'] for entry in record['targets'])
record['workspaceFreeAfterBytes'] = shutil.disk_usage(ROOT).free
record['homeFreeAfterBytes'] = shutil.disk_usage(HOME).free
record['status'] = 'verified-relocation-complete'
save(record)
print(json.dumps({'receipt': str(RECEIPT), 'status': record['status'],
                  'files': sum(entry['files'] for entry in record['targets']),
                  'reclaimedPayloadBytes': record['reclaimedPayloadBytes'],
                  'workspaceFreeAfterBytes': record['workspaceFreeAfterBytes']}, indent=2))
