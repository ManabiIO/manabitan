#!/usr/bin/env python3
"""Snapshot the fixed preparation history; never acquire or rewrite results."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess


ROOT = Path('/workspace/scratch/1b47f6463b98')
CONTROL = ROOT / 'evidence/compression-proof-registration-20261128-1b47'
STAGE = Path('/home/agent/manabitan-import-capture-1b47/compression-proof-registration-20261128-1b47-staging')
PREPARATION = ROOT / 'evidence/compression-proof-followup'
SOURCE = ROOT / 'compression-proof-experiment'
FREEZE = PREPARATION / 'root-freeze-3256036.json'
FINAL_MAP = PREPARATION / 'prepared-driver-source-map-final-v2.json'
POST_FREEZE_STATUS = 'evidence/hosted-compression-proof-status-20261128084943.json'
EXCLUDED_FROM_HISTORY = {'initial-hosted-status.json'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require_regular(path):
    for item in (path, *path.parents):
        if item == ROOT.parent:
            break
        assert not item.is_symlink(), str(item)
    assert path.is_file(), str(path)


def git_blob(path):
    return subprocess.check_output(['git', 'hash-object', str(path)], cwd=ROOT / 'manabitan', text=True).strip()


assert not STAGE.exists()
CONTROL.mkdir(parents=True, exist_ok=True)
STAGE.mkdir(parents=True)
freeze = json.loads(FREEZE.read_text())
source_map = json.loads(FINAL_MAP.read_text())
assert freeze['commit'] == '3256036ff8534ba6de7bc9ecd74ec74d3c705603'
assert freeze['recordedUtc'] == '2026-11-28T08:48:58Z'
selected = []
history_paths = []
for parent, dirs, files in os.walk(PREPARATION, followlinks=False):
    for name in dirs:
        assert not (Path(parent) / name).is_symlink()
    for name in files:
        path = Path(parent) / name
        relative = str(path.relative_to(PREPARATION))
        if relative not in EXCLUDED_FROM_HISTORY:
            require_regular(path)
            history_paths.append(path)
assert len(history_paths) == 82, 'Freeze exactly the reviewed preparation set, not later status/results'
selected.extend(history_paths)
for relative, expected_blob in freeze['files'].items():
    path = SOURCE / relative
    require_regular(path)
    assert git_blob(path) == expected_blob, relative
    if relative in source_map['files']:
        expected = source_map['files'][relative]
        data = path.read_bytes()
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256']
        assert expected['gitBlob'] == expected_blob
    selected.append(path)
assert len(freeze['files']) == 16 and len(source_map['files']) == 10
selected.extend(ROOT / relative for relative in (
    'evidence/compression-followup-validation-design-1b47.md',
    'evidence/compression-jmdict-independent-failure-review-1b47.json',
    'evidence/compression-jitendex-independent-failure-review-1b47.json',
    'evidence/audit-hosted-compression-artifact-1b47.py',
    'evidence/compression-artifact-auditor-independent-review-1b47.json',
    POST_FREEZE_STATUS,
    'evidence/durable-bundles/closed-staging-relocation-20261128T084823Z.json',
    'evidence/durable-bundles/relocate-closed-evidence-20261128-1b47.py',
    'evidence/durable-bundles/package-evidence-v2.py',
    'evidence/durable-bundles/scan-evidence-archives.py',
    'evidence/durable-bundles/stage-compression-proof-preparation-20261128-1b47.py',
))
members = []
seen = set()
for path in sorted(selected):
    require_regular(path)
    relative = str(path.relative_to(ROOT))
    assert relative not in seen
    seen.add(relative)
    data = path.read_bytes()
    target = STAGE / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    assert target.read_bytes() == data and path.read_bytes() == data
    members.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
receipt = {
    'scope': 'Closed source/preparation snapshot plus explicitly later queued-registration metadata; no browser reports, performance observations, results, validation outcome or qualification claim',
    'snapshotPreparedUtc': datetime.now(timezone.utc).isoformat(),
    'sourceFreezeUtc': freeze['recordedUtc'],
    'registrationMetadataUtc': '2026-11-28T08:49:43Z',
    'studyCommit': freeze['commit'], 'studyTree': freeze['tree'], 'commonBaseline': freeze['parent'],
    'sourceFiles': 16, 'newToolingFiles': 10, 'preparationHistoryFiles': 82,
    'historicalSourceContext': {'compressionProductOrigin': 'f7980e638ea1808701ac28339987663fd8b3dc4e', 'storagePredictionBaseline': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'},
    'postFreezeStatusPath': POST_FREEZE_STATUS,
    'excludedPostFreezeDuplicate': 'evidence/compression-proof-followup/initial-hosted-status.json',
    'originalTrialEvidenceCommit': '128b8f8bb69c1801f52242a9907b0b8f0bc3660c',
    'stage': str(STAGE),
    'copyVerification': 'Every selected source was re-read and byte-equal to the complete copied member; no symlink component followed',
    'members': members,
}
receipt_path = CONTROL / 'snapshot-receipt.json'
assert not receipt_path.exists()
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
staged_receipt = STAGE / receipt_path.relative_to(ROOT)
staged_receipt.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(receipt_path, staged_receipt)
assert staged_receipt.read_bytes() == receipt_path.read_bytes()
print(json.dumps({'stage': str(STAGE), 'copiedFiles': len(members), 'copiedBytes': sum(x['bytes'] for x in members),
                  'receipt': str(receipt_path), 'receiptSha256': sha(receipt_path.read_bytes())}, indent=2))
