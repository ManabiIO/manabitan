# Corrected artifact reader reconstruction

Run the separately named reader only after a new corrected cohort has produced
an original artifact. Supply the known registered candidate commit and the
independently retrieved artifact SHA-256; do not infer either from artifact claims.

```sh
python3 dev/perf/import-compression-proof-20261128-1b47/audit_artifact.py \
  --archive /absolute/path/original-artifact.zip \
  --expected-sha256 KNOWN_ARTIFACT_SHA256 \
  --dictionary jmdict \
  --candidate-sha KNOWN_REGISTERED_CANDIDATE_COMMIT \
  --baseline-root /absolute/path/verified-study-checkout \
  --extract /absolute/path/new-extraction \
  --output /absolute/path/new-audit.json
```

Use `jitendex` for that declared corpus. The inherited `--baseline-root` option
means the verified study-source checkout containing the exact candidate tooling
and both common-baseline/candidate Git objects, plus the historical product-origin
object used for provenance. A baseline-only checkout is insufficient. The reader
refuses existing output/extraction paths and requires every raw additive proof;
the original failed trials cannot be repaired by adding sidecars or reused here.

This note is documentation only. No new artifact audit or import was executed
while preparing it, and no approved acquisition source file was changed.
