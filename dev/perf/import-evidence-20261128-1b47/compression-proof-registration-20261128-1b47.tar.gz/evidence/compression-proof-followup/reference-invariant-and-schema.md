# Compression follow-up: reference invariant and schema correction

This read-only source proof corrects the proposed reference invariant in `evidence/compression-followup-validation-design-1b47.md`; that original design and both failed original acquisitions remain unchanged. The new harness/policy are separate preparation and have no acquired observations.

## What the references mean

`rawEntryContentOffset` is **not compression-independent**. The offscreen diagnostic copies the stored record's entry offset directly. `createTermContentReferenceOffsets` in `term-content-block-store.js:1407–1423` returns `slabOffset + localIndex * 20`, the address of a compact reference record in the concatenated OPFS byte stream. The 20-byte constant is defined in `raw-term-content.js:33`.

The ordinary compressed route (`_appendCompressedBlocks`, lines 1140–1171) appends compressed frames followed by reference slabs. `TermContentOpfsStore.appendBatchWithDerivedChunks` (lines 723–755) derives their addresses from the current buffered cursor and each compressed frame's byte length. Therefore the current batch's reference positions can change with compression size.

The shared-source route (`_beginAppendSharedSpans`, lines 885–918) reserves a fixed reference prefix before its frames. `beginAppendBatchWithDerivedPrefix` (lines 795–843) derives that prefix from `_getBufferedLength()`. Although a batch's prefix does not depend on that batch's not-yet-completed frames, subsequent batches inherit preceding compressed lengths. This route does not establish globally stable offsets either. The cursor's description as “logical” refers to a concatenation of persisted and pending physical bytes, not a dictionary-content identity independent of compression.

On both compressed routes `contentLengths` is exactly `sourceLengths`, the uncompressed encoded entry size. The read path (`_readDetailed`, lines 464–498) reads a 20-byte reference at the stored address, loads/decompresses its referenced block, checks the entry length/bounds, and returns the decoded entry slice. Thus length can remain exact when compressed bytes/addresses change. The fallback routes are not admitted by the corrected proof policy.

Both JMdict and Jitendex titles resolve to the `jmdict` compression dictionary (`zstd-term-content.js:874–879`); `createRawTermContentCompactBlockDictName` emits `raw-block-v2:jmdict`. The new proof accepts only that exact tag. Unknown, raw, and legacy tags fail rather than acquire speculative comparison allowances.

## Additive proof schema

The new symmetric overlay adds `report.benchmark.compressionProof`, outside the existing `validation` object. Original reports, canonical receipts, physical digest, restart equality, lookup observations, and source validation remain present. The overlay is derived deterministically from the exact original harness and is recorded with its own hash.

The version-one object has exactly these top-level fields:

- `schemaVersion: 1`, `domain: "manabitan-compression-proof-v1"`.
- `dictionary: {title, revision, probeTerms}` with the same twelve original terms.
- `physical: {preRestart, postRestart}`; each is `{json, utf8Bytes, sha256}` containing the exact original canonical probe JSON string and its original digest.
- `references: {preRestart, postRestart}`; each is an ordered array of `{term, probes}`, with each probe `{term, rows}`. Each row has exactly `id`, `dictionary`, `matchSource`, `expression`, `reading`, `rawEntryContentOffset`, `rawEntryContentLength`, `rawEntryContentDictName`, `glossaryLength`, `decodedContentLength`, and `readErrorDetails`.
- `decoded: {preRestart, postRestart}`; each is an ordered twelve-element array of `{term, resultJson, utf8Bytes, sha256, results, originalTextLength, hasExactHeadwordMatch}`. The JSON is the full existing `termsFind` result, not an extracted definition subset.

Missing diagnostic row fields are captured explicitly as null; null is not an accepted success value except `readErrorDetails`, which must be null. Row IDs/offsets must be safe nonnegative integers; lengths and glossary counts positive safe integers. Dictionary identity, nonempty expression/match source, reading string, and exact compression tag are required. `rawEntryContentLength` must equal the successful decoded diagnostic length. `offset + 20` must fit the exact stored term-content file. No comparison uses `offset + decodedLength` as the compressed reference's physical width.

The exact physical canonical preimage is recomputed against the original physical digest. All old physical pre/post and A/C or same-arm comparisons remain exact. Cross B/A, only the physical offset, raw compressed preview, and a physical store total validated against the original inventory (or the same unavailable −1 sentinel) can differ. Every term, row identity, order, decoded length, compression tag, and existing count remains exact. No new allowed path is inferred from a later observation.

A single twelve-term pre-restart decoded pass is added after the import endpoint. The existing first post-restart lookup pass supplies the post-restart JSON; its extra capture is extracted from the returned object before assigning the original `validation.lookup`. All 72 existing post-restart lookup digests must match the corresponding full decoded proof. Pre/post JSON bytes and cross-arm JSON bytes are exact. This proves the specified decoded sample and restart stability, not exhaustive equality of every dictionary definition.

The new policy owns a separately named logical projection digest only after validating all physical and decoded evidence. It never copies a baseline digest into a candidate raw receipt or changes the old failure. The original two exact size deltas, two-percent storage budget, schedules, media/memory rules, and failure handling remain mandatory.
