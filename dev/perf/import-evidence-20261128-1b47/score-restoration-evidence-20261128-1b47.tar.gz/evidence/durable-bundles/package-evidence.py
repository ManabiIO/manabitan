#!/usr/bin/env python3
"""Create or verify source-bound evidence archives; never run a benchmark."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def safe_name(name):
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts, name
    return path.as_posix()


def verify(archive, manifest):
    expected = {item['path']: item for item in manifest['members']}
    assert len(expected) == len(manifest['members'])
    assert archive.stat().st_size == manifest['archive']['bytes']
    assert sha(archive.read_bytes()) == manifest['archive']['sha256']
    seen = set()
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            name = safe_name(member.name)
            assert member.isfile() and name not in seen and name in expected
            seen.add(name)
            data = stream.extractfile(member).read()
            assert len(data) == expected[name]['bytes'] == member.size
            assert sha(data) == expected[name]['sha256'], name
    assert seen == set(expected)
    return {'verifiedMembers': len(seen), 'allMemberBytesAndHashesMatch': True}


def build(root, spec_path, output_dir):
    spec_bytes = spec_path.read_bytes()
    spec = json.loads(spec_bytes)
    selected = {}
    for name in spec['include']:
        path = root / safe_name(name)
        assert path.exists(), name
        paths = sorted(path.rglob('*')) if path.is_dir() else [path]
        for item in paths:
            if item.is_file():
                relative = item.relative_to(root).as_posix()
                assert relative not in selected, relative
                selected[relative] = item
    omitted = []
    for item in spec.get('omitExisting', []):
        name = safe_name(item['path'])
        source = root / name
        data = source.read_bytes()
        selected.pop(name, None)
        omitted.append({**item, 'bytes': len(data), 'sha256': sha(data), 'included': False})
    omitted.extend(spec.get('omitExternal', []))
    payload = []
    members = []
    for name, path in sorted(selected.items()):
        data = path.read_bytes()
        digest = sha(data)
        expected = spec.get('expectedSha256', {}).get(name)
        if expected is not None:
            assert digest == expected, f'Frozen identity changed: {name}'
        members.append({'path': name, 'bytes': len(data), 'sha256': digest})
        payload.append((name, data))
    assert len(payload) > 0
    output_dir.mkdir(parents=True, exist_ok=True)
    archive = output_dir / (spec['name'] + '.tar.gz')
    manifest_path = output_dir / (spec['name'] + '.manifest.json')
    checksum_path = output_dir / (spec['name'] + '.sha256')
    assert not archive.exists() and not manifest_path.exists() and not checksum_path.exists()
    with archive.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=6) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as packed:
                for name, data in payload:
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ''
                    packed.addfile(info, io.BytesIO(data))
    manifest = {
        'format': 1,
        'study': spec['study'],
        'scope': spec['scope'],
        'sourceBindings': spec['sourceBindings'],
        'memberPathBase': 'Original workspace-relative path; contents are byte-for-byte unchanged',
        'archiveMetadata': 'gzip timestamp, tar ownership and file timestamps normalized; payload paths and contents preserved',
        'manifestPlacement': 'External to archive so every archive member, without a self-hash exception, has a digest',
        'spec': {'path': spec_path.relative_to(root).as_posix(), 'sha256': sha(spec_bytes)},
        'archive': {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes())},
        'totalPayloadBytes': sum(item['bytes'] for item in members),
        'members': members,
        'omissions': omitted,
    }
    manifest['verification'] = verify(archive, manifest)
    manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
    manifest_path.write_bytes(manifest_bytes)
    checksum_path.write_text(f"{manifest['archive']['sha256']}  {archive.name}\n{sha(manifest_bytes)}  {manifest_path.name}\n")
    print(json.dumps({'archive': str(archive), 'manifest': str(manifest_path), 'members': len(members),
                      'payloadBytes': manifest['totalPayloadBytes'], **manifest['archive'], **manifest['verification']}))


parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[2])
parser.add_argument('--spec', type=Path)
parser.add_argument('--output', type=Path)
parser.add_argument('--verify-manifest', type=Path)
arguments = parser.parse_args()
if arguments.verify_manifest:
    manifest = json.loads(arguments.verify_manifest.read_text())
    print(json.dumps(verify(arguments.verify_manifest.parent / manifest['archive']['file'], manifest)))
else:
    assert arguments.spec is not None and arguments.output is not None
    build(arguments.root.resolve(), arguments.spec.resolve(), arguments.output.resolve())
