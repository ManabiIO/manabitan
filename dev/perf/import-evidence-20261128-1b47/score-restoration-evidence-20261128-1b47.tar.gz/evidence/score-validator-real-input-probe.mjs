// Component diagnostic only. Products are read without modification.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import {resolve, join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {performance} from 'node:perf_hooks';

const [baselinePath, candidatePath, inputPath, outputPath] = process.argv.slice(2);
assert(baselinePath && candidatePath && inputPath && outputPath,
    'Usage: node score-validator-real-input-probe.mjs BASELINE CANDIDATE CAPTURE_DIRECTORY OUTPUT_JSON');
const baselineRoot = resolve(baselinePath);
const candidateRoot = resolve(candidatePath);
const inputRoot = resolve(inputPath);
const sourceFile = 'ext/js/dictionary/term-record-opfs-store.js';
const baselineFile = join(baselineRoot, sourceFile);
const baseline = await readFile(baselineFile, 'utf8');
const candidate = await readFile(join(candidateRoot, sourceFile), 'utf8');
const before = '    for (const scoreKey of scoreKeys) {\n        if (scoreKey >= scoreCount) {';
const after = '    for (let i = 0; i < scoreKeys.length; ++i) {\n        if (scoreKeys[i] >= scoreCount) {';
assert.equal(baseline.split(before).length, 2);
assert.equal(candidate, baseline.replace(before, after));
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const manifestBytes = await readFile(join(inputRoot, 'manifest.json'));
const manifest = JSON.parse(manifestBytes);
assert.equal(manifest.complete, true);
assert.equal(manifest.failure, null);
assert.equal(manifest.sourceCommit, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
assert.equal(manifest.fixture.sha256, '3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f');
assert.equal(manifest.rows, 528299);
assert.equal(manifest.capturedFields.length, 12);
assert.equal(manifest.sourceFiles[sourceFile], sha(baseline));
assert.equal(manifest.capturedFields.reduce((total, field) => total + field.count, 0), manifest.rows);
const inputs = [];
for (const field of manifest.capturedFields) {
    assert.equal(field.format, 2);
    const data = await readFile(join(inputRoot, field.file));
    assert.equal(data.byteLength, field.byteLength);
    assert.equal(sha(data), field.sha256);
    const bytes = new Uint8Array(data); // Ordinary exact-size aligned backing, as captured.
    inputs.push({bytes, count: field.count});
}
const moduleRoot = `${resolve(outputPath)}.modules`;
await mkdir(moduleRoot, {recursive: false});
const originalURL = pathToFileURL(baselineFile);
const generatedHashes = {};
const parse = {};
for (const arm of ['A', 'B', 'C']) {
    const source = arm === 'B' ? candidate : baseline;
    const rebased = source.replace(/(from\s+)(['"])(\.[^'"]+)\2/g,
        (_match, prefix, quote, specifier) => `${prefix}${quote}${new URL(specifier, originalURL).href}${quote}`);
    const diagnostic = `${rebased}\nexport {parseCompactRecordFields as __scoreValidator};\n`;
    generatedHashes[arm] = sha(diagnostic);
    const filename = join(moduleRoot, `${arm}.mjs`);
    await writeFile(filename, diagnostic, {flag: 'wx'});
    parse[arm] = (await import(pathToFileURL(filename))).__scoreValidator;
}
assert.equal(generatedHashes.A, generatedHashes.C);
for (const input of inputs) {
    const expected = parse.A(input.bytes, input.count);
    for (const arm of ['B', 'C']) {
        const actual = parse[arm](input.bytes, input.count);
        for (const key of ['offsets', 'lengths', 'scoreKeys', 'scores']) {
            assert.equal(actual[key].constructor, expected[key].constructor);
            assert.equal(actual[key].length, expected[key].length);
            assert.equal(Buffer.compare(
                Buffer.from(actual[key].buffer, actual[key].byteOffset, actual[key].byteLength),
                Buffer.from(expected[key].buffer, expected[key].byteOffset, expected[key].byteLength)), 0);
        }
    }
}
const repeats = 8;
let consume = 0;
function observe(arm) {
    const start = performance.now();
    for (let repeat = 0; repeat < repeats; ++repeat) {
        for (const input of inputs) {
            const result = parse[arm](input.bytes, input.count);
            consume += result.offsets.length + result.scores.length;
        }
    }
    return performance.now() - start;
}
const warmups = [];
for (const order of [['A', 'B', 'C'], ['C', 'B', 'A']]) {
    const values = {};
    for (const arm of order) { values[arm] = observe(arm); }
    warmups.push({order, values});
}
const orders = [['A', 'B', 'C'], ['B', 'C', 'A'], ['C', 'A', 'B'], ['C', 'B', 'A'], ['B', 'A', 'C'], ['A', 'C', 'B']];
const observations = [];
for (let block = 0; block < 24; ++block) {
    const order = orders[block % orders.length];
    const values = {};
    for (const arm of order) { values[arm] = observe(arm); }
    observations.push({block, order, values, baPercent: (values.B / values.A - 1) * 100,
        bcPercent: (values.B / values.C - 1) * 100, caPercent: (values.C / values.A - 1) * 100});
}
for (let index = 0; index < inputs.length; ++index) {
    assert.equal(sha(inputs[index].bytes), manifest.capturedFields[index].sha256);
}
const median = (values) => {
    const sorted = [...values].sort((a, b) => a - b);
    return (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2;
};
const summary = {
    armMedianMsPerCorpus: Object.fromEntries(['A', 'B', 'C'].map((arm) => [arm, median(observations.map((row) => row.values[arm])) / repeats])),
    medianPairedBaPercent: median(observations.map((row) => row.baPercent)),
    medianPairedBcPercent: median(observations.map((row) => row.bcPercent)),
    medianSameCodeCaPercent: median(observations.map((row) => row.caPercent)),
    bFasterA: observations.filter((row) => row.values.B < row.values.A).length,
    bFasterC: observations.filter((row) => row.values.B < row.values.C).length,
};
const report = {
    scope: 'Direct parseCompactRecordFields component only; not sidecar, storage, or browser import timing',
    complete: true, node: process.version, v8: process.versions.v8, baselineRoot, candidateRoot,
    sourceFile, sourceHashes: {baseline: sha(baseline), candidate: sha(candidate)},
    generatedHashes, captureManifestSha256: sha(manifestBytes), fixture: manifest.fixture,
    sourceDigestSha256: manifest.sourceDigestSha256, persistedFilesDigestSha256: manifest.filesDigestSha256,
    inputCount: inputs.length, rowsPerCorpus: manifest.rows, capturedFields: manifest.capturedFields,
    repeatsPerObservation: repeats, excludedWarmups: warmups, observations, summary, consume,
};
await writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'});
console.log(JSON.stringify(summary, null, 2));
