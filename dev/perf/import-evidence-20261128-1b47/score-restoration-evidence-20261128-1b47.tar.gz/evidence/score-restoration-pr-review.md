# Independent review of the score-restoration PR draft

Read-only source/evidence review on 2026-11-28. No tests, timings, GitHub writes,
or comments were performed for this review.

The draft is factually sound and appropriately limits its gain to the warm
compact-field validator. Two wording corrections are recommended before
publication:

1. The exact same-code C/A paired median is **+0.884569526%**. At two decimal
   places use **+0.88%**, or report +0.885%; the draft's +0.89% is a minor rounding
   mismatch.
2. Replace “Complete browser import qualification is recorded separately” with
   an explicit statement that it **remains pending**. The validation section
   already describes queued jobs, but the earlier sentence could imply that a
   complete qualification result exists.

The two-line restoration is proportionate to the independently reproduced
approximately 1.6 ms warm-validator gain and reasonable to submit for review
with that scope. It does not establish a complete-sidecar or whole-import gain.

## Reconciled evidence

- #944 is merged (merge `e7a0780cfe7e952d5440de5b0fdcc88d53e60203`). The exact
  runtime diff in `a35b064d5d37960429ce591c9f6f17a2df0486c5` reverses the indexed
  loop while adding the unrelated split-reference provenance helper. Remote
  develop still resolves to `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
- `score-validator-real-input-probe.mjs` has 24 balanced A/B/C blocks, eight
  complete traversals per observation and two excluded warmup triplets. It
  exposes the production helper from source-derived diagnostic modules and
  binds both product hashes, the exact capture manifest, all 12 field buffers
  and input/output view bytes. The three reported medians and paired changes
  reconcile with `score-validation/direct-validator-probe.json`.
- The 12 buffers cover 528,299 rows and 4,239,960 field bytes. The baseline
  capture binds source and complete persisted-file digests. This is a public-sink
  component capture, not a browser storage or restart proof.
- `score-validation/full-validation/summary.json` confirms the 669 local unit
  suites, 15,135 passes, 47 accounted conditional skips, all-target dry build,
  scoped lint, main types and test types. The source hash remains
  `63942c3dc97eab215293bf04a138844d505605386bc61322b3f2f29e20d1d769`.
- Hosted run **46106456744**, exact head
  `915268441352c3c7aa50fc0fbd44f73f5a826d79`, has a successful validation job
  **140860200999**. Its recorded steps include full units, all targets,
  changed-runtime lint, runtime/test types and pinned native reproduction.
  Browser jobs **140880422226**, **140880422289**, **140880422290** remained
  queued at this review. Pending jobs are not treated as passing results.
- The enclosing Node sink result remains inconclusive because unchanged phases
  moved and owning record phases were flat. The draft correctly avoids using
  that apparent whole-component gain as attribution for the two-line change.

## Current duplication check

Open-PR searches for `score`, `944`, `restore`, `iterator`, `indexed`,
`score-key`, `compact score`, and `parseCompactRecordFields` found no duplicate
restoration. Existing #962 preserves the original #944 verification; #855 is a
different score/content-run encoder proposal. Neither restores this validator
loop. This is a current targeted check, not a guarantee against later work.

The evidence placeholder still needs a durable source-bound link before the
draft is sent. No other factual correction was found.
