# Recent accepted import-hunk audit

## Scope and result

Read-only audit of the recent runtime changes accepted between the #931/#944 changes and integration batches #967–#971. The frozen checkout and freshly queried remote `develop` both identify `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. The audit compares each accepted runtime diff with later edits to the same files; it does not infer retention from PR titles or test presence alone.

**No additional current omission was found beyond the already identified #944 score traversal.** No product source was changed, no candidate was restored, and no tests or benchmarks were run for this audit. This is a bounded source-history finding, not a claim that the entire repository history is free of regressions.

## Concrete omission already under experiment

[#944](https://github.com/ManabiIO/manabitan/pull/944), accepted as `e7a0780cfe7e952d5440de5b0fdcc88d53e60203`, replaced the compact score-key `for…of` traversal with direct indexing. Integration `a35b064d5d37960429ce591c9f6f17a2df0486c5` added #897 split-reference provenance handling but also reversed those exact two loop lines in `term-record-opfs-store.js`. They are its only two deleted runtime lines and are unrelated to its new split helper. Current develop still has the old traversal. There is no stated bug-fix rationale for reversing the score traversal in that integration.

The existing two-line experiment owns this omission. Its direct captured-input proof and inconclusive owning-region/whole-import attribution remain in `score-checkpoint-claim-audit.md`; a historical omission does not itself establish useful speed.

## Retained accepted mechanisms

| Accepted work | Concrete current-source finding |
| --- | --- |
| #933 generic decoder context reuse, `060fa5c` | `dev/lib/zstd-wasm.js` is byte-identical to the integration. Later #938 initialization edits preserve the runtime's retained decoder context and nullable-dictionary routing. |
| #942 deferred resolution scratch, `1dbf8ab` | The parser still supplies empty resolution columns and marks `resolutionDeferred`; storage still calls `initializeTermContentPlanResolution` on admission. The helper file is byte-identical to its integration. Later parser edits concern media hints, compact expression IDs and media input staging. |
| #936 reservation eligibility, `cbdb8c9` | The shared-JMdict eligibility return remains before `tryBeginAppendSpans`; later database changes do not remove or move it after validation. |
| #954 ZIP batch snapshot reuse, `ec2b4c0` | `term-bank-source-pipeline.js` is byte-identical to its accepted integration. |
| #959 WebP classification, `1fb7e5d` | `media-util.js` is byte-identical to its integration. |
| #960 bounded last-definition snapshots, `fd4db0b` | Boundary retirement, last-published-span selection, original cache budget and boundary-only copy remain. Later database changes are metadata growth and SQLite index cleanup. |
| #964 metadata growth work, `9ab0f25` | Dense high-water prefix copies and the no-slot-copy rehash path remain; `term-content-metadata-arena.js` is byte-identical to its integration. The only later database runtime edit is the import-start index guard. |
| #934 compact deferred media, `52de9a1` | `hasUnmaterializedEntry` and deferred compact image handling remain; #971 replaces filename materialization with its bounded decoder without removing this admission path. |
| #909/#943 direct media index and path-reference removal | Source media packer and worker files remain byte-identical to #909. The writer still uses shared namespace/IDs rather than retaining a path array. The subsequent index-copy change is an explicit integration repair described below. |
| #897 split-reference encoding, `a35b064` | The added helper and both publication/use sites remain. Its only later runtime edit accepts owned Uint16 expression IDs. The independent score-loop reversal is the omission above. |
| #938 Zstd startup overlap, `906e225` | Runtime file is byte-identical to the accepted integration and still joins independent module/dictionary startup outcomes before publication. |
| #940/#946 import-start SQLite cleanup | The guarded cleanup remains. Later changes only consolidate comments, formatting and test coverage; they do not reintroduce disabled-index drops. |
| #969 combined native changes, `297bf9605ba9e81882d4df041f616b7aeef1f254` | C source, source-bound parser WASM and manifest are byte-identical to this accepted commit. Width-specialized validated UTF-8 copying, targeted lookup-output initialization and adjacent structured-content container entry remain. The optional native media-absence result and JS projection guard remain after later wrapper edits. |
| #939 compact expression IDs, `12051e3` | Owned Uint16 expression views remain in segmented plans; native pointer callers still require Uint32. Consumer acceptance remains. The later shape-check rewrite is the same boolean predicate, not a removed fast path. |
| #956 bounded media staging, `6df0d2b` | Parser wrapper is byte-identical to this commit. The shared backing-range copy, original 4 MiB bound and original gap ratio remain. |
| #971 bounded filename decoding, `fe65898` | All three runtime files are byte-identical to the accepted commit. |

## Temporary integration losses that are already repaired

The #934 integration `52de9a1` temporarily removed #931's default bank-query argument and first-character filter. Follow-up `cc5fe09dce9ded4f247d367719ea59d42655d835` explicitly restores both. Current `_getArchiveFiles` still skips impossible first characters for the built-in bank patterns while preserving custom patterns. Restoring it again would duplicate current code.

The #909 integration `3cf177f` temporarily replaced `restrictGenerationMediaIndex`'s lazy copy with an unconditional allocation. Follow-up `bbff513` explicitly restores reuse when every occupied slot is kept and copies only before the first drop. This repair preserves prepared-source immutability and the unchanged-index identity contract. Current source already contains the repaired path.

## Deliberate exclusions and interpretation

[#969](https://github.com/ManabiIO/manabitan/pull/969) explicitly combines #941 (including its #932 base), #952 and #902. It explicitly does not include the separate #961 compact-metadata ABI. Missing #961 behavior is therefore not an accidental integration reversion. The #970 compact-expression predicate rewrite is a validation cleanup, and its retained Uint32 native-pointer guards are required by the native ABI; removing them would not restore a dropped optimization.

Several accepted PRs claimed exact eliminated work or correctness rather than qualified complete-import latency. Their inclusion or retention should not be retroactively described as measured import wins. This audit yields no new restoration candidate beyond the score loop already being screened.
