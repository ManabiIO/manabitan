# JMdict typed-array iterator audit

Baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.

## Result

No additional large typed-array `for…of` traversal was found on the captured successful JMdict record, content, canonical-dedup or lookup path. No source change or timing experiment is proposed from this audit.

Precision correction: the score-key loop already under experiment traverses a **Uint16Array**, not a Uint32Array. The enclosing compact format also has Uint32 offsets and Int32 score values, but those are different columns.

## Source and activation evidence

The actual public-sink capture in `compression-level/jmdict-capture-report.json` completes all 528,299 rows in 12 groups. Every group is owned/shared and starts the shared reservation path; only the first group performs initial compression selection. It records 366,030 canonical scan rows, 362,032 new published spans, and zero native dedup fallbacks. All stored files and the source digest match the independent frozen baseline.

The exact-baseline ordinary browser summary independently records 12 groups, zero fused parser fallbacks, zero native dedup fallbacks, zero borrowed-content results, zero segmented lookup runs/fallbacks, and zero JS lookup-compaction source-validation passes. Record materialization, record interning, record length packing and record heap copying are all zero on this captured path. These observations support the source-based exclusions below; they are not synthetic assumptions about a generic import.

| Loop | Data and actual captured activation | Decision |
| --- | --- | --- |
| `parseCompactRecordFields`: score keys | Uint16Array; 12 captured compact field buffers, 528,299 keys / 1,056,598 bytes for one complete traversal | Already owned by the #944 restoration experiment. Its direct warm saving is approximately 1.57–1.60 ms per complete captured traversal. |
| `_tryAppendPacked`: sum of source lengths | Uint32Array, potentially 362,032 elements if this fallback were selected | The captured 12/12 shared reservations bypass this method. No current-path gain to test. |
| `shouldSelectInitialSharedBlockStorage`: frequencies | Uint32Array of 256 bins; first reservation only | Exactly 256 element visits. This is the only other active typed-array iterator identified in the audited success path, far below a large per-row traversal. |
| `_stagePendingTermEntryContentMeta` catch and `_rollbackStagedTermEntryContentMeta` | Typed staged-index arrays can be large | Failure/rollback work; absent from the successful captured import. Changing it would not improve the measured successful workload. |
| `getContentOffsetBase` | Ordinary `number[]`, constructed by the generic row encoder | The captured artifact path uses its existing indexed reference validation and encoding instead. This is neither an active typed-array loop nor a fresh generic-prepass idea. |
| `compactValidatedTermRecordPlan`: referenced keys | Ordinary JavaScript array populated with `push` | Not a typed array, and the browser capture records no JS source compaction. |
| `encodePersistedTermLookupIndex`: candidate key indexes | Ordinary `number[]` hash-collision lists in the row-oriented fallback | Native prepared lookup bytes serve the captured artifact import. Not the requested typed-array mechanism. |
| Canonical scanner metric propagation | Eleven object entries per native call, 132 entries across 12 groups | A small object/metadata loop. Canonical input/output column validation and scatter loops are already indexed. |
| Worker/source/compressed-chunk loops | Arrays, maps and sets; bounded source groups, workers or 103 produced frames | These do not iterate the hundreds of thousands of row/definition elements as typed values. |

The native/JS span validators, slab planning and gathering, record-origin/reference checks, compact record encoding, canonical metadata publication and lookup-byte readers already use indexed loops or native bulk operations. An independent read-only source review by the architecture agent found the same exclusions at lookup and canonical boundaries.

## Cost boundary

There are **zero additional activated large typed-array iterator traversals** among the audited success-path sites. Excluding the already screened score loop, the identified active typed-array `for…of` work is bounded to the 256 entropy bins for this capture. That is an exact work-count bound, not a converted elapsed-time estimate. The entropy body contains `Math.log2`, so multiplying another loop's per-element cost would not be a defensible timing bound.

The browser's 25.5 ms `termRecordValidationMs` is an inclusive region containing more than score iteration; it must not be assigned to a hypothetical second iterator. The direct real-buffer score experiment remains the relevant isolated measurement. Existing profiles provide no defensible millisecond claim for changing the 256-bin loop, and that count does not justify another benchmark campaign.

## Prior-work overlap

Current PR/history searches reconfirm #944 as the precise iterator change. #624 already removes redundant ordinary Int32 score scans; #849 and #836 cover direct resolved-column encoding and validated reference runs. #830 and #914 address broader canonical registration/publication validation, with no established whole-import benefit for those guarded paths. Generic record prepass fusion is already proposed in #191/#285, and artifact format inference is covered by #193. #854/#855 run-based record work also has retained inconclusive complete-import results. None supplies a fresh, activated large typed-array iterator omitted from this audit.

Only source/history and existing receipts were read. No benchmarks, tests, product edits, or broad loop-style rewrite were performed.
