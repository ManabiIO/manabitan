# Score-loop and local-checkpoint claim audit

Frozen comparison baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.

This is a read-only audit of existing source, captured inputs, raw reports and current hosted job metadata. No benchmark or test was run during this audit.

## Current hosted evidence boundary

At this audit, neither experiment has any completed browser timing observations.

| Experiment | Frozen candidate | Hosted run | Observed status |
| --- | --- | --- | --- |
| Indexed compact score validation | `915268441352c3c7aa50fc0fbd44f73f5a826d79` | `46106456744` | Validation job `140860200999` queued |
| Local 8 MiB index checkpoints | `0efd7507eb19b0b7f15410b14aac427e80e22244` | `46104738613` | Validation job `140854843795` passed; all three browser jobs queued |

The complete-import studies retain the unchanged qualification driver, exact source/package/workload bindings, six candidate pairs, identical-code controls, excluded warmups, complete media/restart checks and separate memory validation. No PR decision can currently cite a browser speed result from either run.

## Indexed compact score validation

The source identity is concrete. Accepted #944 changed the compact `Uint16Array` score-key traversal to direct indexing at `e7a0780cfe7e952d5440de5b0fdcc88d53e60203`. Integration `a35b064d5d37960429ce591c9f6f17a2df0486c5` restored the prior two loop lines while adding split-reference provenance handling in a separate part of the same file. Its only two deleted runtime lines are those indexed-loop lines. There is no corresponding bug-fix explanation in that integration; current frozen develop still contains the older traversal. The experiment restores exactly those two lines, retaining all existing malformed-input and ownership tests.

The direct component proof uses all 12 actual compact field buffers from a complete unchanged-baseline public-sink replay: 528,299 rows and 4,239,960 field bytes. Capture source and every persisted file match the frozen full-corpus census. The production `_encodeArtifactRecordFields` allocates a private `Uint8Array` for these compact output fields, so the direct probe's private/aligned captured representation matches this producer's relevant backing type. It does not claim to reproduce a live browser schedule.

Twenty-four balanced A/B/C blocks use eight complete input traversals per observation, two excluded warmups, and independently instantiated same-code A/C modules. The only source change in B is the two-line traversal replacement. Returned views and original input bytes match.

- Warm direct-validator medians per complete corpus: A 2.5594 ms, B 0.9852 ms, C 2.5867 ms.
- Paired median B/A −62.711%, B/C −64.021%; same-code C/A +0.885%.
- B is faster in 23/24 and 24/24 comparisons.
- The absolute reduction is about **1.57–1.60 ms for one warm validation of all captured fields**. This is not a complete-import reduction or a strict upper bound on differently warmed browser executions.

The full Node public-sink experiment reports an apparent paired geometric −9.52% elapsed change, with six of eight pairs faster and all persisted bytes equal. **Attributing that number to this loop is unsupported.** The inclusive owning-region medians are flat or worse: record validation 23.742→24.625 ms, field encoding 28.038→28.362 ms, and record write 70.163→70.456 ms. Meanwhile unchanged parser, inflation and compression measurements improve substantially. Those overlapping diagnostics cannot be added, and their pattern allows scheduling/host effects. The large pair-7 change and every other tail remain included. A descriptive bootstrap interval excluding zero does not repair this attribution problem or turn the Node filesystem replay into a browser measurement.

Acceptable current claim: a small, isolated validator improvement with exact production-input and output proof. Unsupported claims: 9.5% faster imports, 63% faster sidecar creation, or a quantified browser import saving.

Primary local evidence: `score-validation/direct-validator-probe.json`, `score-validation/fields/manifest.json`, `node-jmdict-score-validation-pairs/summary.json`, and `node-jmdict-score-validation-pairs/inclusive-metric-analysis.json`.

## Local 8 MiB index checkpoints

The candidate adds a local 8 MiB periodic flush threshold to the existing synchronous index writer. The dedicated I/O worker retains 16 MiB. It keeps the ordered queue, final header rewrite, final flush/close, sticky errors, abort behavior and unpublished-generation ownership. The two current production acquisition paths preserve their intended local/background selection. The 63 focused writer tests passed; the exact candidate's hosted validation is also green.

There is **no local timing result** for this candidate. The Node OPFS shim lacks synchronous access handles, so its timing would not exercise the changed native flush mechanism. Fake-handle tests prove ordering and thresholds, not fsync performance.

The motivating exact-baseline ordinary browser observation is one 738.9 ms JMdict import, with 149 ms bulk finalization. Its record-end close-region metric is 130.6 ms. The source of that metric matters:

- `_endImportSession` first flushes pending descriptor writes and awaits their queue, then measures `_closeAllWritables` plus dictionary-health/publication-state updates.
- `_closeAllWritables` concurrently finalizes the record file and `_flushLookupIndexFile` for each shard, then retires any index worker.
- `_flushLookupIndexFile` drains the remaining index chunks, seeks and rewrites the final header, and closes the index writer. The synchronous writer's close joins its queue, performs its final native flush, and closes the access handle.

Therefore **130.6 ms is an inclusive finalization region, not an independently measured 130.6 ms fsync call**. It is a reason to investigate the tail, not an amount this change has established it can save. The content-end metric of 135.7 ms overlaps this region; its own content-close metric is only 1.1 ms, so adding the two end times would double-count waiting/overlap.

The same baseline writes five logical index batches totaling 23,748,912 bytes, plus the 40-byte file header. The trace contains the synchronous writer's yield-channel callbacks and the baseline records zero dedicated index-worker files; this supports the local writer path for that trace. The new 8 MiB threshold can introduce two earlier native checkpoints for a sidecar of this size, followed by the still-required final flush. It **adds flush barriers** rather than removing durability work. Parser/compression overlap could hide some cost, but the import thread can also be blocked earlier, and total I/O cost may rise.

The browser decision must use the unchanged complete-import clock. A lower final close-region number alone is insufficient if bank processing rises by the same amount. Checkpoint count, helper timing, prior #813 results or the 20% finalization share cannot substitute for a measured whole-import improvement. Historical 16/32 MiB experiments are contextual non-winners, not current 8 MiB speed evidence.

Acceptable current claim: a minimal, correctness-validated attempt to move some final native flush work earlier. Unsupported claims: 130 ms saved, 20% faster JMdict, free overlap, or an established improvement before the hosted browser reports exist.

Primary local evidence: `local-index-checkpoint-tests.log`, the frozen candidate source/tests, and `current-baseline-jmdict/ordinary/summary.json` plus its paired source-bound trace. All future browser observations and failed attempts must remain attributable to their exact candidate heads.
