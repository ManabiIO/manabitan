**Review status:** Held as a small component proposal. The completed browser study establishes no import speedup; Jitendex has an unresolved adverse timing signal.

## Why

PR #944 introduced indexed score-key validation in `parseCompactRecordFields`. Integration commit `a35b064d5d37960429ce591c9f6f17a2df0486c5` subsequently restored the older iterator loop while integrating split-reference provenance handling. Both the original measured baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` and current integration baseline `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16` contain that older loop.

## Change

Restore the two indexed-loop lines from the accepted optimization. Every compact `Uint16Array` score key receives the existing bounds check, in the same order, with the same rejection error. The existing boundary and malformed-input tests remain applicable.

## Historical measured benefit

All component and browser measurements below remain bound to the original `9e10d3b3` baseline and the product version represented by clean PR commit `b15bad43acdfd54d541895cac1109c0e5ba51b2f`. The linked evidence identifies the exact executed study/checkpoint commits and their source equivalence; this does not imply that the clean PR commit itself was executed. None is a performance measurement of the new combined parser source.

The component comparison uses all 12 actual compact field buffers captured from an unchanged-baseline JMdict public-sink replay: 528,299 rows and 4,239,960 field bytes. The capture is bound to the pinned dictionary, source hashes, and complete persisted content/record/index digests.

Twenty-four balanced A/B/C blocks, with eight complete traversals per observation and two excluded warmups, give these warm validator medians:

| Arm | Time per complete captured corpus |
| --- | ---: |
| Baseline A | 2.5594 ms |
| Indexed loop B | 0.9852 ms |
| Identical baseline C | 2.5867 ms |

That is about **1.57–1.60 ms saved per complete warm validation**. Paired median changes are −62.71% against A and −64.02% against C; the identical-code C/A control is +0.885%. B is faster in 23/24 and 24/24 blocks respectively. Returned typed views and input bytes match.

The scope of this result is compact-field validation. The enclosing Node sink measurement is retained but inconclusive: unchanged parser/compression phases move substantially while the owning record phases are flat. The complete browser results below establish no whole-import gain and leave an unresolved adverse Jitendex signal.

## Current integration and correctness validation

The current head is `dbaa4d72a5f6b4fcffeb92cefadb521e101df7df`, tree `4a632857a1250fd0a716f700f8d8997f7560cb68`. It integrates current develop `dcfc02a0` (merged PR #972) while retaining exactly the same one-file, two-line indexed-loop delta. The score runtime blob remains `b17f72437f196aa1fd21b282c03f147aad7d633f`. No experimental workflow or evidence archive is added to this product diff.

Fresh correctness validation passed for this exact product commit on Node **22.22.0** and Clang/LLD **21.1.8** in [run 46128395334, score job](https://github.com/ManabiIO/manabitan/actions/runs/46128395334/job/140928007222): **669 unit files, 15,139 passing tests and 47 conditional skips**, pinned native byte reproduction, all-target build, scoped lint, and runtime/test types. The independent artifact audit checked the exact commit, tree, ordered parents, changed-file set, source bytes, and unchanged final HEAD with empty working/index diffs. The skipped assertions are the same 46 reverse-DOM cases and one Windows-only case in both integrations.

The [complete correctness artifact](https://github.com/ManabiIO/manabitan/actions/runs/46128395334/artifacts/15256363690) is 594,268 bytes, SHA-256 `f01eeef071ec4270402ad7b67bfcaa5396d8f7c431c7ea814a8260699aa4349e`. No current-base browser or performance cohort was acquired for this product integration.

The new correctness gates do not repeat or qualify the old performance cohorts on this integration. This remains a held draft.

## Historical validation

- Local Node 24.22.3: 669 full unit suites passed, 15,135 tests passed and 47 expected conditional skips; all-target build dry run, scoped ESLint, main types and test types passed.
- Hosted Node 22.22.0: validation of the identical runtime blob passed on frozen study head `915268441352c3c7aa50fc0fbd44f73f5a826d79` in [run 46106456744](https://github.com/ManabiIO/manabitan/actions/runs/46106456744), including pinned native reproduction. This PR contains that two-line product change; the study workflow stays on its experimental branch. The frozen three-dictionary browser study is complete; its qualification and timing limitations are reported below.
- The earlier local prerequisite failures and corrected complete run are preserved with source and log hashes. The product diff stayed fixed throughout validation.

## Complete browser qualification: JMdict, Jitendex and VNDB

The frozen browser study is complete for all three dictionaries. **No corpus establishes a whole-import speedup.** Each retains six AB/BA candidate pairs, two identical-code control pairs, excluded warmups, separate exhaustive-media checks and separate memory imports. No cohort is pooled, no control drift is subtracted, and every unfavorable observation remains included.

The actual packages in all three historical cohorts contain the unchanged score runtime blob, `b17f72437f196aa1fd21b282c03f147aad7d633f`, as their sole differing entry. All 26 canonical semantic receipts per corpus pass the registered source/work, lookup, storage-size, media/readback and restart checks. These receipts do not claim exhaustive byte equality for every persisted definition.

| Corpus                                                                                      | Candidate paired median / equal-work | Descriptive 95% paired-median interval | Identical-code median | Separate memory comparison                                                                                                                     |
| ------------------------------------------------------------------------------------------- | -----------------------------------: | -------------------------------------- | --------------------: | ---------------------------------------------------------------------------------------------------------------------------------------------- |
| [JMdict](https://github.com/ManabiIO/manabitan/actions/runs/46106456744/job/140880422290)   |                    −0.960% / −0.927% | [−3.508%, +1.757%]                     |               −3.248% | **Unqualified:** B2's 252.093481 ms covered-sample gap exceeds the unchanged 250 ms limit; maxima remain null. All 250 raw scans are retained. |
| [Jitendex](https://github.com/ManabiIO/manabitan/actions/runs/46106456744/job/140880422289) |                    +0.900% / +3.387% | [−0.546%, +9.896%]                     |               −1.069% | All original gates pass; 276 raw scans retained.                                                                                               |
| [VNDB](https://github.com/ManabiIO/manabitan/actions/runs/46106456744/job/140880422226)     |                    −1.019% / −1.083% | [−2.896%, +0.681%]                     |               −1.969% | All original gates pass; 570 raw scans retained.                                                                                               |

**Jitendex has an unresolved adverse signal:** five of six candidate pairs are slower, including the complete **+17.679% fifth pair**. Both identical-code controls improve. VNDB's favorable point estimate and the separate warm JMdict component saving do not cancel that evidence. JMdict's memory-coverage failure is insufficient sampling, not a demonstrated memory regression; its threshold is not rounded or waived and the surviving pair is not substituted.

The optimized `parseCompactRecordFields` loop runs through `validateRecordFields` and `_createLookupIndexChunk` inside the awaited record append, whose enclosing aggregate is `termRecordWriteMs`. The metric named `termRecordValidationMs` instead covers input/content-offset checks; no dedicated score-loop timer is available. Jitendex's fifth pair also slows in unchanged native inflation, parsing and compression. These overlapping worker/await durations supply attribution context, not a causal proof or a basis for adjusting total time. The broader record-write metric likewise cannot isolate the loop's benefit.

This remains a **held component-only draft**, not a browser non-regression or merge-readiness claim. The independently measured **1.57–1.60 ms saving per complete warm JMdict validator corpus** is the reviewable benefit. It does not establish first-import behavior or support extrapolation to another corpus. Memory measurements are non-atomic sampled process-tree maxima, not exact peaks.

Original source-bound artifacts remain separate: [JMdict](https://github.com/ManabiIO/manabitan/actions/runs/46106456744/artifacts/15253012612), [Jitendex](https://github.com/ManabiIO/manabitan/actions/runs/46106456744/artifacts/15254097229), and [VNDB](https://github.com/ManabiIO/manabitan/actions/runs/46106456744/artifacts/15254620204). No retry, replacement observation, product change, protocol change or relaxed gate was used.

Durable browser evidence remains separate by publication: [JMdict readout](https://github.com/ManabiIO/manabitan/blob/54b933253e05dfa8b9cfe0b7211cb8eac34eb500/dev/perf/import-evidence-20261128-1b47/score-jmdict-browser-addendum-README.md), [raw archive](https://github.com/ManabiIO/manabitan/blob/54b933253e05dfa8b9cfe0b7211cb8eac34eb500/dev/perf/import-evidence-20261128-1b47/score-jmdict-browser-addendum-20261128-1b47.tar.gz), and [manifest](https://github.com/ManabiIO/manabitan/blob/54b933253e05dfa8b9cfe0b7211cb8eac34eb500/dev/perf/import-evidence-20261128-1b47/score-jmdict-browser-addendum-20261128-1b47.manifest.json); [Jitendex/VNDB readout](https://github.com/ManabiIO/manabitan/blob/212089f2186cfd7ea0d90b082f16b1cd81c65aa5/dev/perf/import-evidence-20261128-1b47/score-remaining-browser-addendum-README.md), [raw archive](https://github.com/ManabiIO/manabitan/blob/212089f2186cfd7ea0d90b082f16b1cd81c65aa5/dev/perf/import-evidence-20261128-1b47/score-remaining-browser-addendum-20261128-1b47.tar.gz), and [manifest](https://github.com/ManabiIO/manabitan/blob/212089f2186cfd7ea0d90b082f16b1cd81c65aa5/dev/perf/import-evidence-20261128-1b47/score-remaining-browser-addendum-20261128-1b47.manifest.json). Together they preserve all 78 reports/receipts and 1,096 raw memory scans, including all failures and slow pairs.

## Reproduction and evidence

The [scope and reproduction README](https://github.com/ManabiIO/manabitan/blob/3c3ba7600a8811df6b8631b72a0ac5379f8b60d1/dev/perf/import-evidence-20261128-1b47/score-restoration-README.md), [complete evidence archive](https://github.com/ManabiIO/manabitan/blob/3c3ba7600a8811df6b8631b72a0ac5379f8b60d1/dev/perf/import-evidence-20261128-1b47/score-restoration-evidence-20261128-1b47.tar.gz), and [per-member hash manifest](https://github.com/ManabiIO/manabitan/blob/3c3ba7600a8811df6b8631b72a0ac5379f8b60d1/dev/perf/import-evidence-20261128-1b47/score-restoration-evidence-20261128-1b47.manifest.json) are preserved at immutable evidence commit `3c3ba7600a8811df6b8631b72a0ac5379f8b60d1`. The archive contains all 12 actual numeric buffers, frozen probe/capture scripts, complete observations, source/history bindings, failures and validation logs. Archive SHA-256: `56e214cf9107725113593c25eb290e36c390b02bf51e169e2632a3726a518841`.

Original modifications to existing project code; no third-party source was imported.

