**Held component-only draft.** The CRC-stage evidence supports reviewing this small implementation, but the active VNDB browser trial has adverse complete-import timing and fails memory-coverage qualification. No browser non-regression or merge-readiness claim is made.

## Why

The incremental source-gap CRC helper consumes full 16-byte blocks, then handles every remaining byte serially. VNDB has many short gaps between exact raw spans covered by CRC witnesses, so those dependent tail steps are a recurring cost even when most source bytes are already covered.

## Change

Use the existing slicing tables for an optional eight-byte tail and then an optional four-byte tail, leaving at most three scalar bytes. This adds 25 production C lines, with no new table or allocation and no change to witness selection, group sizing, admission, persisted formats, or CRC semantics.

The checked-in parser WASM and native manifest are regenerated with the pinned Clang/LLD 21.1.8 toolchain. The WASM grows by 284 bytes; the CRC helper is the only changed production function body. A test-only export permits an independent Node-zlib oracle over 8,160 combinations of input length, alignment and preceding CRC state.

## Historical measured benefit and limits

All component and browser measurements below remain bound to the original `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` baseline and the product version represented by clean PR commit `5909db31ebe859fce1cc4b38324271ddf9f3dd59`. The linked evidence identifies the exact executed study/checkpoint commits and source equivalence; this does not imply that the clean PR commit itself was executed. These results do not measure the new combined parser source.

This is a component optimization. It does not establish a complete-browser import speedup.

| Measurement                                                                         | Result                                                                               | Scope                                                                                                           |
| ----------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------- |
| Captured-gap replay, 120,012 spans from the first 12 VNDB banks, 24 balanced blocks | Paired CRC-only improvement of 21.21%; medians 103.97 → 82.49 ms for sixteen repeats | Exploratory selection screen; concatenates gaps into one CRC state and excludes the verifier's combination work |
| Complete sequential VNDB parser, all 665 banks / 6,648,310 rows, first order        | Summed CRC phase 62.01 ms lower, or 8.65%                                            | All compared parser outputs exact; unchanged inflation also improves                                            |
| Same complete corpus, reverse initial order                                         | Summed CRC phase 49.87 ms lower, or 6.82%                                            | Supports a CRC-stage signal, without attributing the enclosing parser change                                    |
| Selected direct production-verifier replay                                          | Geometric change −3.19%; descriptive 95% interval [−7.38%, +1.74%]                   | Inconclusive; unchanged whole-bank control's equal-work time moves +3.89%                                       |

The local full-parser cohorts use 332 groups and scan 872 MB. The browser production census uses 170 groups and scans 568 MB across three workers. These percentages must not be applied to complete-browser time or summed worker durations. Wider slicing32 was slower in the complete parser; padding was inconclusive. Their observations remain in the evidence, including failed or incomplete attempts and the limits of retained acquisition-script provenance.

## Current integration and correctness validation

The prepared current head is `961614e36859c529580fc034d6535ca89d119051`, tree `e7e454a7f019ed2201e4c66ce5db2e8b87218148`. It integrates develop `dcfc02a0` (merged PR #972) and preserves the isolated CRC helper/test changes. The native assets were regenerated from the combined C source with Clang/LLD 21.1.8; the old measured WASM was not reused. The new WASM is 69,352 bytes, 284 bytes larger than the `dcfc02a0` baseline parser (69,068 → 69,352 bytes), with SHA-256 `fbcf0f790ced310b93d2824d9d191402bb5496d8d6166be5ea1b4770a215ce81`. The product diff remains exactly the C source, generated WASM, native manifest, and CRC test.

[CURRENT_HOSTED_GATES_PENDING: fill only after exact-source results and artifact audit.]

Local current-source native reproduction, 83 focused native tests, all-target build, scoped lint, and main types passed. Both bounded full-unit attempts ended with exit 137 before completion, with no failed-suite result. The first test-type attempt exhausted its explicit 768 MiB V8 heap cap; the single 1536 MiB retry ended with exit 137. Exit 137 alone does not establish the cause. All attempts are retained; none is counted as a completed pass.

The new correctness gates do not repeat or qualify historical performance on this integration. The adverse VNDB result below remains unresolved and this stays a held draft.

## Historical validation

- Hosted validation of the original four product blobs passed on frozen study head `3080deb631a7536fabe8ccb2f77f8f55e11ef061` in [run 46107723369](https://github.com/ManabiIO/manabitan/actions/runs/46107723369): pinned native reproduction, full units, all-target build, scoped lint, and main/test types. Those measured files are preserved at the original product head; the study workflow stays on its experimental branch.
- The initial hosted run passed native reproduction, 669 unit files / 15,136 tests with 47 conditional skips, and builds, then failed test-only array formatting. The corrected original trial changed only that formatting; its runtime source and WASM bytes were unchanged. Both receipts are retained.
- The original three-corpus browser study is complete. All recorded semantic checks pass; the complete-import timings and VNDB memory-coverage failure are retained below.

## Completed browser screen: no whole-import gain

The frozen study `3080deb631a7536fabe8ccb2f77f8f55e11ef061` contains the exact four files from original product head `5909db31`; it predates the current parser integration. Both actual extension packages were audited; only the C source and generated WASM differ, with candidate WASM Git blob `dc1673cd501778a8a48e8faa4cc5c81076f2a19d`.

All 26 imports and semantic receipts per corpus pass. Negative changes are faster. These are the original six paired complete-import observations and two identical-code controls; no observations are excluded or adjusted.

| Corpus   | B/A paired median | Equal-work change | Descriptive 95% interval | Identical C/A median | Original memory gate                                                       |
| -------- | ----------------: | ----------------: | ------------------------ | -------------------: | -------------------------------------------------------------------------- |
| JMdict   |          −0.1617% |          +0.0606% | [−0.6572%, +1.0069%]     |             +0.3091% | Pass; 303 raw scans                                                        |
| Jitendex |          +0.4451% |          +0.2622% | [−1.0960%, +1.4487%]     |             +0.4088% | Pass; 333 raw scans                                                        |
| VNDB     |          +4.6426% |          +6.4226% | [−0.9559%, +15.5290%]    |             +1.1104% | Fail; A2 coverage gap 295.200949 ms exceeds 250 ms; 482 raw scans retained |

JMdict and Jitendex have zero deferred-source CRC time/scanned/reused work in every report, so they are inactive-path controls for this change. VNDB is active, but four of six complete imports are slower, including the full +19.3509% sixth pair. Its memory failure is insufficient coverage, not a demonstrated memory regression; the comparison remains unqualified, with null aggregate maxima.

An **added secondary analysis**, requested at 07:50:20 UTC while VNDB was running and before its outcome was reviewed, describes the same six pairs and two controls. It is not a registered primary endpoint or new gate. All 16 observations have exactly 568,284,368 scanned bytes, 3,699,708,599 reused bytes and 6,490,145 reused glossaries. Summed worker `parserSourceCrcMs` is lower in all six candidate pairs: median −4.0486%, equal-work −4.0686%, descriptive interval [−5.4962%, −2.6251%]. Both identical-code phase controls also improve (−0.1508% and −4.3172%), limiting attribution. This timer covers the deferred verifier, not just its gap-tail helper, and is not import wall time. No control or phase time is subtracted from the primary result.

The earlier component benefit and this secondary phase observation support only a small held implementation review. **The complete browser study establishes no import gain or broad non-regression, fails VNDB memory qualification, and does not establish merge readiness.** The adverse VNDB timing remains part of the decision.

Original run: [46107723369](https://github.com/ManabiIO/manabitan/actions/runs/46107723369). The [completed browser readout](https://github.com/ManabiIO/manabitan/blob/c89af6f108eebab73dcdbc7c3a292c189a6161e6/dev/perf/import-evidence-20261128-1b47/crc-browser-addendum-README.md), [all raw evidence](https://github.com/ManabiIO/manabitan/blob/c89af6f108eebab73dcdbc7c3a292c189a6161e6/dev/perf/import-evidence-20261128-1b47/crc-browser-addendum-20261128-1b47.tar.gz), and [member hash manifest](https://github.com/ManabiIO/manabitan/blob/c89af6f108eebab73dcdbc7c3a292c189a6161e6/dev/perf/import-evidence-20261128-1b47/crc-browser-addendum-20261128-1b47.manifest.json) are preserved at immutable commit `c89af6f108eebab73dcdbc7c3a292c189a6161e6`. Archive SHA-256: `84d5ae1f80c2a5ccfb2981c71eb335b4320d09ec19c649884fb512e5a561d8c5`.

## Reproduction and evidence

The [scope and reproduction README](https://github.com/ManabiIO/manabitan/blob/3c3ba7600a8811df6b8631b72a0ac5379f8b60d1/dev/perf/import-evidence-20261128-1b47/crc8_4-README.md), [complete evidence archive](https://github.com/ManabiIO/manabitan/blob/3c3ba7600a8811df6b8631b72a0ac5379f8b60d1/dev/perf/import-evidence-20261128-1b47/crc8_4-evidence-20261128-1b47-v2.tar.gz), and [per-member hash manifest](https://github.com/ManabiIO/manabitan/blob/3c3ba7600a8811df6b8631b72a0ac5379f8b60d1/dev/perf/import-evidence-20261128-1b47/crc8_4-evidence-20261128-1b47-v2.manifest.json) are preserved at immutable evidence commit `3c3ba7600a8811df6b8631b72a0ac5379f8b60d1`. Archive SHA-256: `4d47af5543a594dfc4083efabfd568250dfc28d48f53e9361b53722f0d3dd823`.

The compact bundle includes the measured source/native checkpoints, current test file, frozen observations, independent oracle checks, scripts, input hashes, reconstruction instructions and rejected variants. Large dictionary archives and reproducible raw source captures are omitted with explicit hashes and recipes.

Original modifications to existing project code; no third-party source was imported.
