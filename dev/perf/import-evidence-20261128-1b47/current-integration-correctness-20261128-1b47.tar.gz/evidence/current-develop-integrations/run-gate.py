#!/usr/bin/env python3
"""Retain each correctness/build gate's command, output and outcome once."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

stage, cwd, output_directory, *command = sys.argv[1:]
output = Path(output_directory)
output.mkdir(parents=True, exist_ok=True)
log = output / (stage + '.log')
receipt = output / (stage + '.json')
assert not log.exists() and not receipt.exists()
environment = os.environ.copy()
environment['MANABITAN_CLANG'] = '/tmp/manabitan-current-native-1b47/native-toolchain/bin/clang'
environment['MANABITAN_WASM_LD'] = '/tmp/manabitan-current-native-1b47/native-toolchain/bin/wasm-ld'
environment['PATH'] = '/tmp/manabitan-current-native-tools-1b47:' + environment['PATH']
environment['NODE_OPTIONS'] = environment.get('INTEGRATION_GATE_NODE_OPTIONS', '--max-old-space-size=768')
started = time.monotonic()
with log.open('x') as handle:
    process = subprocess.run(command, cwd=cwd, env=environment, stdout=handle, stderr=subprocess.STDOUT)
result = {'stage': stage, 'cwd': cwd, 'command': command,
          'exitCode': process.returncode, 'seconds': time.monotonic() - started,
          'compiler': environment['MANABITAN_CLANG'], 'linker': environment['MANABITAN_WASM_LD'],
          'nodeOptions': environment['NODE_OPTIONS'], 'scope': 'Correctness/build gate; no performance observation'}
receipt.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
raise SystemExit(process.returncode)
