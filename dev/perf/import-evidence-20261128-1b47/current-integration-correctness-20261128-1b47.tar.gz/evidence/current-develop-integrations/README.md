# Current-develop import integrations: preparation and local gates

This packet records correctness preparation for the two held import drafts after
`develop` advanced from `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` to
[`dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`](https://github.com/ManabiIO/manabitan/commit/dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16).
That merge brings PR #972's compact structured-glossary fast path and scalar-token
end reuse, with new parser source, generated native assets, lookup-screen metrics
and format-3 tests. The score-storage runtime is unchanged by that upstream merge.

No browser or component performance acquisition was made for these combinations.
Historical performance evidence remains attached to its original baseline and
study commits. This note records preparation before any fresh hosted validation
outcome was available.

## Exact product identities

Each product merge preserves the old PR head as its first parent and the common
`dcfc02a0` baseline as its second parent. Root verified the remote merge objects
and exact differences from that baseline.

| Product        | Merge commit                               | Tree                                       | First parent                               |
| -------------- | ------------------------------------------ | ------------------------------------------ | ------------------------------------------ |
| Score, PR #978 | `dbaa4d72a5f6b4fcffeb92cefadb521e101df7df` | `4a632857a1250fd0a716f700f8d8997f7560cb68` | `b15bad43acdfd54d541895cac1109c0e5ba51b2f` |
| CRC, PR #979   | `961614e36859c529580fc034d6535ca89d119051` | `e7e454a7f019ed2201e4c66ce5db2e8b87218148` | `5909db31ebe859fce1cc4b38324271ddf9f3dd59` |

The score integration changes only the original two-line indexed score-key
validation loop. Its entire runtime file remains byte-identical to the old draft.
The CRC integration applies only the original C/test hunks to the new parser and
regenerates the manifest and WASM. Copying the old CRC binary would have discarded
the upstream parser changes; the new binary therefore comes from the combined
source, using the pinned Clang/LLD 21.1.8 toolchain.

| Product | Changed path                                     | Exact Git blob                             |
| ------- | ------------------------------------------------ | ------------------------------------------ |
| Score   | `ext/js/dictionary/term-record-opfs-store.js`    | `b17f72437f196aa1fd21b282c03f147aad7d633f` |
| CRC     | `ext/js/dictionary/wasm/term-bank-parser.c`      | `8580418076e7b0229b466644340dab649911882a` |
| CRC     | `dev/data/dictionary-wasm/manifest.json`         | `0c9570aeab5f9a003cd815ce1c0a286c715f3cc2` |
| CRC     | `dev/data/dictionary-wasm/term-bank-parser.wasm` | `dcbbca0b5ed4ec2f5348901e53cb25fcd085cb96` |
| CRC     | `test/term-bank-crc.test.js`                     | `eb968742aa8279b2bff81065dea56791caad6bf4` |

The regenerated CRC parser is 69,352 bytes, SHA256
`fbcf0f790ced310b93d2824d9d191402bb5496d8d6166be5ea1b4770a215ce81`.
Full byte lengths, SHA256 values, source checkpoints and upload/readback scope are
in [local-integration-status.json](local-integration-status.json),
[the native checkpoint manifest](crc/checkpoint-after-native-build/manifest.json)
and [the blob receipt](crc/remote-product-blobs.json). Local Git checkouts remained
at `dcfc02a0` with these working-tree changes; the separately created remote merge
commits contain those exact product bytes.

## Bounded local validation

For CRC, the unchanged current baseline first reproduced all pinned native assets
exactly. The combined candidate then passed native `--write` and `--check`,
`build:libs`, **83 tests across four focused native suites**, `test:build`, scoped
ESLint for the CRC test, main TypeScript, and `git diff --check`. The generated
ordinary `ext/lib` parser matched the tracked candidate WASM exactly. The compiler
recovery and portable-launch adjustments are recorded in
[toolchain-recovery.json](toolchain-recovery.json); they did not alter optimization
flags.

Every incomplete broad attempt is retained below. Durations describe correctness
gate execution only; they are not import-performance observations.

| Attempt                               | Outcome      | Duration | Recorded limit and evidence                                                                                                                     |
| ------------------------------------- | ------------ | -------- | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| Full unit suite, two workers          | Exit **137** | 42.728 s | 768 MiB V8 cap; 34 completed suite lines, no completion JSON. [Receipt](crc/unit-full.json), [log](crc/unit-full.log).                          |
| Test TypeScript                       | Exit **134** | 11.470 s | **Explicit V8 heap-limit OOM** at the 768 MiB cap. [Receipt](crc/types-test.json), [log](crc/types-test.log).                                   |
| One larger-heap test-TypeScript retry | Exit **137** | 13.242 s | 1536 MiB cap; no type diagnostics or completed gate. [Receipt](crc/types-test-1536.json), [log](crc/types-test-1536.log).                       |
| One single-worker full-unit retry     | Exit **137** | 77.874 s | 768 MiB cap; 38 completed suite lines, no completion JSON. [Receipt](crc/unit-full-single-worker.json), [log](crc/unit-full-single-worker.log). |

The cause of each exit-137 termination is **unproven**. Only the 768 MiB
test-TypeScript attempt explicitly identifies an out-of-memory failure. Completed
suite lines do not establish a full-unit pass. No assertions were weakened, no
failed log was replaced, and local broad retries stopped after these attempts.

The score combination received local source-identity and diff checks only. Its
old validation is historical; no fresh full-validation pass is implied. The
remaining current-tree gates were moved to a separate hosted correctness workflow.

## Validation-only hosted preparation

At this preparation checkpoint, root had created and read back the unreferenced
CI commit `dc6edcc01a6b9f387fb33e80aa47833a29334d14`, tree
`0e7fb55986fd90b780991ac5a9d04f0a997237ca`. Its first parent is the CRC merge above;
its second parent is the score merge. Its sole file delta from the CRC merge is
`.github/workflows/current-import-integration-gates-1b47.yml`, blob
`470d46e336c32f517075c03085d89da60cd89f25`, SHA256
`c94be41ec1de28af2d2fd7bde82cf175b3dcfc210faf8de6581fd649ea7a28cf`.

The [workflow source](current-import-integration-gates-1b47.yml) checks out each
exact product commit independently and verifies its tree, ordered parents, exact
changed-file set and product blobs. It pins Node 22.22.0 and native toolchain
21.1.8, then runs native reproduction, the full unit suite with two workers,
`test:build`, scoped lint and main/test types. Lint and type checks use a 4096 MiB
cap. Source snapshots, logs, outcomes and final tracked differences are retained
on failure. There are no browser or performance steps. The
[draft receipt](validation-workflow-draft-receipt.json) records the earlier local
static checks; root's subsequent remote object/readback checks are described here.

Independent workflow review and CI-only branch publication were pending at this
checkpoint. The existing PR refs were still their old heads and were to advance
only after fresh hosted gates passed. Neither preparation nor a later correctness
pass transfers old performance results to the new parser combination or makes
either held draft ready to merge.
