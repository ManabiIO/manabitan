#!/usr/bin/env python3
"""Seal already reviewed correctness evidence; never execute a test or import."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/1b47f6463b98')
CONTROL = ROOT / 'evidence/current-integration-correctness-20261128-1b47'
STAGE = Path('/home/agent/manabitan-import-capture-1b47/current-integration-correctness-20261128-1b47-staging')
OUTPUT = Path('/home/agent/manabitan-import-capture-1b47/current-integration-correctness-20261128-1b47-output')
NAME = 'current-integration-correctness-20261128-1b47'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    assert all(not parent.is_symlink() for parent in path.parents), str(path)


initial = json.loads((CONTROL / 'initial-staging-receipt.json').read_text())
for record in initial['copiedFiles']:
    source = ROOT / record['path']
    target = STAGE / record['path']
    regular(source)
    regular(target)
    data = source.read_bytes()
    assert len(data) == record['bytes'] and sha(data) == record['sha256']
    assert target.read_bytes() == data
for record in initial['artifacts']:
    target = STAGE / record['retainedArchivePath']
    regular(target)
    assert target.stat().st_size == record['bytes'] and sha(target.read_bytes()) == record['sha256']
approval = json.loads((CONTROL / 'root-wrapper-review-and-final-format.json').read_text())
assert approval['rootApprovedSealVerifyScanUnreferencedUploadAfterEdits']
assert approval['finalReadmeSha256'] == sha((CONTROL / 'README.md').read_bytes())
preseal = {
    'preparedForSealUtc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Later preservation seal; no source, gate, import, performance observation or artifact audit was rerun',
    'earlierByteSnapshotUtc': initial['stagedUtc'],
    'earlierRemotePublicationVerificationEventUtc': initial['productPublicationVerificationEventUtc'],
    'all124PreviouslySnapshottedFilesStillExact': len(initial['copiedFiles']) == 124,
    'originalArchiveContainers': len(initial['artifacts']),
    'all49OriginalHostedMembersRetained': sum(x['members'] for x in initial['artifacts']) == 49,
    'readmeSha256': approval['finalReadmeSha256'],
    'rootReviewReceiptSha256': sha((CONTROL / 'root-wrapper-review-and-final-format.json').read_bytes()),
    'futureDurableLinkBodyAdditionExcluded': True,
}
preseal_path = CONTROL / 'preseal-receipt.json'
assert not preseal_path.exists()
preseal_path.write_text(json.dumps(preseal, indent=2) + '\n')
extras = sorted(CONTROL.iterdir()) + [Path(__file__).resolve()]
for source in extras:
    regular(source)
    relative = source.relative_to(ROOT)
    target = STAGE / relative
    data = source.read_bytes()
    if target.exists():
        assert target.read_bytes() == data
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        assert target.read_bytes() == data
selected = sorted(path for path in STAGE.rglob('*') if path.is_file())
expected = {}
for path in selected:
    regular(path)
    expected[str(path.relative_to(STAGE))] = sha(path.read_bytes())
spec_relative = 'evidence/current-integration-correctness-20261128-1b47/bundle-spec.json'
spec = {
    'name': NAME,
    'study': 'Current-source integrations of held score and CRC drafts: correctness and publication only',
    'scope': 'Complete original correctness artifacts and all members; historical preparation, bounded local failures, reader correction, independent reviews and published ref/body snapshots. No new import-performance acquisition.',
    'sourceBindings': {
        'commonBaseline': 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16',
        'scoreProduct': 'dbaa4d72a5f6b4fcffeb92cefadb521e101df7df',
        'crcProduct': '961614e36859c529580fc034d6535ca89d119051',
        'workflowCommit': 'dc6edcc01a6b9f387fb33e80aa47833a29334d14',
        'workflowSha256': 'c94be41ec1de28af2d2fd7bde82cf175b3dcfc210faf8de6581fd649ea7a28cf',
        'runId': 46128395334,
        'historicalPerformanceBaselineOnly': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2',
        'originalArtifacts': initial['artifacts'],
        'evidenceSnapshotUtc': initial['stagedUtc'],
        'preparedForSealUtc': preseal['preparedForSealUtc'],
        'readmeSha256': approval['finalReadmeSha256'],
    },
    'include': sorted(list(expected) + [spec_relative]),
    'expectedSha256': expected,
    'omitExternal': [{
        'included': False,
        'kind': 'Local LLVM toolchain bulk; no original hosted correctness artifact member is omitted',
        **initial['omittedToolchain'],
    }, {
        'included': False,
        'kind': 'Full Git checkouts, installed dependencies, old datasets and prior performance packets',
        'recovery': 'Exact source commits and immutable prior-evidence references are in the standalone README. No new performance observation belongs to this correctness packet.',
    }],
}
spec_path = CONTROL / 'bundle-spec.json'
assert not spec_path.exists()
spec_path.write_text(json.dumps(spec, indent=2) + '\n')
(STAGE / spec_relative).write_bytes(spec_path.read_bytes())
result = subprocess.run([
    'python', str(ROOT / 'evidence/durable-bundles/package-evidence-v2.py'),
    '--root', str(STAGE), '--spec', str(STAGE / spec_relative), '--output', str(OUTPUT),
], check=True, capture_output=True, text=True)
(CONTROL / 'seal.log').write_text(result.stdout + result.stderr)
print(result.stdout, end='')
