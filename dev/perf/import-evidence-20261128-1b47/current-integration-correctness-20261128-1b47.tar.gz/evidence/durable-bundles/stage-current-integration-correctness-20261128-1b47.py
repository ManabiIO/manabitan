#!/usr/bin/env python3
"""Preserve completed correctness evidence; never rerun a gate or benchmark."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import zipfile


ROOT = Path('/workspace/scratch/1b47f6463b98')
CONTROL = ROOT / 'evidence/current-integration-correctness-20261128-1b47'
STAGE = Path('/home/agent/manabitan-import-capture-1b47/current-integration-correctness-20261128-1b47-staging')
ARTIFACTS = Path('/home/agent/manabitan-import-capture-1b47/hosted-artifacts')
PREPARATION = ROOT / 'evidence/current-develop-integrations'
HOSTED = ROOT / 'evidence/hosted-current-integration-46128395334'
KNOWN = {
    'score': {'artifactId': 15256363690, 'bytes': 594268, 'sha256': 'f01eeef071ec4270402ad7b67bfcaa5396d8f7c431c7ea814a8260699aa4349e', 'members': 23},
    'crc': {'artifactId': 15256493531, 'bytes': 588674, 'sha256': 'd4a092506e3c6623f9f3deb490cbde998f879bfb3167037fb13dfc32e3acc2c1', 'members': 26},
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    for parent in path.parents:
        assert not parent.is_symlink(), str(parent)


def files(directory):
    assert directory.is_dir() and not directory.is_symlink()
    result = []
    for parent, dirs, names in os.walk(directory, followlinks=False):
        for name in dirs:
            assert not (Path(parent) / name).is_symlink()
        for name in names:
            path = Path(parent) / name
            regular(path)
            result.append(path)
    return sorted(result)


assert not STAGE.exists()
STAGE.mkdir(parents=True)
CONTROL.mkdir(parents=True, exist_ok=True)
preparation_files = files(PREPARATION)
later_names = {
    'crc-pr-body-current-ready.md',
    'score-pr-body-current-ready.md',
    'current-pr-bodies-prepublication.json',
    'current-ready-pr-outcome-review.json',
    'root-product-publication-complete.json',
}
later_files = [path for path in preparation_files if str(path.relative_to(PREPARATION)) in later_names]
historical_preparation_files = [path for path in preparation_files if path not in later_files]
assert {path.name for path in later_files} == later_names
assert len(historical_preparation_files) == 55 and len(preparation_files) == 60
assert sha((PREPARATION / 'README.md').read_bytes()) == '335894c86e7cac1e1e8a177fbc2a16ec3e0a288ca71a332dbc3fd89f1db1a385'
artifact_records = []
for variant, known in KNOWN.items():
    original = ARTIFACTS / f'current-integration-46128395334-{variant}.zip'
    regular(original)
    raw_zip = original.read_bytes()
    assert len(raw_zip) == known['bytes'] and sha(raw_zip) == known['sha256']
    audit = json.loads((HOSTED / variant / 'audit.json').read_text())
    assert audit['artifactId'] == known['artifactId'] and audit['variant'] == variant
    assert audit['archive']['sha256'] == known['sha256'] and audit['archive']['bytes'] == known['bytes']
    expected = {member['path']: member for member in audit['members']}
    assert len(expected) == known['members']
    seen = set()
    with zipfile.ZipFile(original) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        for member in archive.infolist():
            name = member.filename
            path = Path(name)
            assert not path.is_absolute() and '..' not in path.parts
            if member.is_dir():
                continue
            assert name in expected and name not in seen
            data = archive.read(member)
            assert len(data) == expected[name]['bytes'] and sha(data) == expected[name]['sha256']
            extracted = HOSTED / variant / 'raw' / name
            regular(extracted)
            assert extracted.read_bytes() == data
            seen.add(name)
    assert seen == set(expected)
    assert {str(path.relative_to(HOSTED / variant / 'raw')) for path in files(HOSTED / variant / 'raw')} == seen
    relative = f'evidence/current-integration-correctness-20261128-1b47/original-artifacts/{original.name}'
    target = STAGE / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw_zip)
    assert target.read_bytes() == raw_zip
    artifact_records.append({**known, 'variant': variant, 'originalPath': str(original), 'retainedArchivePath': relative,
                             'allOriginalMembersRetained': True, 'allExtractedBytesEqualOriginalMembers': True,
                             'auditPath': str((HOSTED / variant / 'audit.json').relative_to(ROOT)),
                             'auditSha256': sha((HOSTED / variant / 'audit.json').read_bytes())})
selected = preparation_files + files(HOSTED)
selected += [ROOT / relative for relative in (
    'evidence/audit-current-integration-gates-1b47.py',
    'evidence/audit-current-integration-gates-1b47.initial-pending-status.py',
    'evidence/current-integration-hosted-independent-review-1b47.json',
    'evidence/durable-bundles/package-evidence-v2.py',
    'evidence/durable-bundles/scan-evidence-archives.py',
    'evidence/durable-bundles/stage-current-integration-correctness-20261128-1b47.py',
    'evidence/durable-bundles/stage-current-integration-correctness-20261128-1b47.initial-prepublication-count.py',
    'evidence/current-integration-correctness-20261128-1b47/staging-initial-count-failure.json',
)]
copied = []
seen = set()
for source in sorted(selected):
    regular(source)
    relative = str(source.relative_to(ROOT))
    assert relative not in seen
    seen.add(relative)
    data = source.read_bytes()
    target = STAGE / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    assert target.read_bytes() == data and source.read_bytes() == data
    copied.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
record = {
    'scope': 'Initial immutable staging of current-integration correctness preparation and completed hosted artifacts; no new gate, import, performance observation or semantic audit was run',
    'stagedUtc': datetime.now(timezone.utc).isoformat(),
    'hostedAuditSnapshotUtc': '2026-11-28T09:15:43.088821Z',
    'productPublicationVerificationEventUtc': '2026-11-28T09:18:55Z',
    'timeBoundary': 'stagedUtc is the actual later byte snapshot; the hosted and product publication timestamps describe earlier events, not an assertion that every receipt byte already existed then',
    'commonBaseline': 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16',
    'workflowCommit': 'dc6edcc01a6b9f387fb33e80aa47833a29334d14',
    'runId': 46128395334,
    'historicalPreparationFiles': len(historical_preparation_files),
    'laterOutcomePublicationFiles': [str(path.relative_to(ROOT)) for path in later_files],
    'preparationReadmeUnchanged': True,
    'preparationReadmeSha256': '335894c86e7cac1e1e8a177fbc2a16ec3e0a288ca71a332dbc3fd89f1db1a385',
    'artifacts': artifact_records,
    'copiedFiles': copied,
    'stage': str(STAGE),
    'completedBeforeStaging': ['independent final source/outcome reviews', 'root product-ref and final-body publication receipts'],
    'pendingBeforeSeal': ['separate wrapper README and parent review'],
    'omittedToolchain': {'artifactId': 15245399340, 'sourceRunId': 46101416471,
                         'archiveSha256': 'a5ec0df3408e28a25cd7c986b9df371187960036cd9767f12269f3cf549cb1e6',
                         'compilerVersion': '21.1.8', 'linkerVersion': '21.1.8',
                         'sizeDescription': 'Approximately 82 MB; exact byte length is not asserted from a missing local archive',
                         'reference': 'evidence/current-develop-integrations/toolchain-recovery.json',
                         'recovery': 'Obtain the exact original Actions toolchain artifact while available and verify its SHA-256; the original archive is not embedded. The hosted workflow separately installs and asserts version 21.1.8, then requires exact native reproduction.'},
}
receipt = CONTROL / 'initial-staging-receipt.json'
assert not receipt.exists()
receipt.write_text(json.dumps(record, indent=2) + '\n')
target = STAGE / receipt.relative_to(ROOT)
target.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(receipt, target)
assert target.read_bytes() == receipt.read_bytes()
print(json.dumps({'receipt': str(receipt), 'receiptSha256': sha(receipt.read_bytes()),
                  'sourceAndEvidenceFiles': len(copied), 'originalZipFiles': len(artifact_records),
                  'hostedRawMembers': sum(x['members'] for x in artifact_records),
                  'payloadBytesBeforePublication': sum(x['bytes'] for x in copied) + sum(x['bytes'] for x in artifact_records)}, indent=2))
