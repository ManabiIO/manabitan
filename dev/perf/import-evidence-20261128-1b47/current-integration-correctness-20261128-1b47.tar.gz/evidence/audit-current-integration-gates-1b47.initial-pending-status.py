"""Read-only audit of the two registered correctness artifacts; never runs gates."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile
from collections import Counter
from datetime import datetime, timezone

ROOT = Path('/workspace/scratch/1b47f6463b98')
REPO = ROOT / 'compression-proof-experiment'
OUT = ROOT / 'evidence/hosted-current-integration-46128395334'
WORKFLOW_COMMIT = 'dc6edcc01a6b9f387fb33e80aa47833a29334d14'
BASELINE = 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16'
WORKFLOW_SHA = 'c94be41ec1de28af2d2fd7bde82cf175b3dcfc210faf8de6581fd649ea7a28cf'
FROZEN_PATH = ROOT / 'evidence/current-develop-integrations/root-unreferenced-product-commits.json'
FROZEN = json.loads(FROZEN_PATH.read_text())
CONNECTOR_PATH = OUT / 'connector-completion.json'
CONNECTOR = json.loads(CONNECTOR_PATH.read_text())
ARMS = {
    'score': {'artifactId': 15256363690, 'jobId': 140928007222, 'bytes': 594268, 'sha256': 'f01eeef071ec4270402ad7b67bfcaa5396d8f7c431c7ea814a8260699aa4349e', 'testsPassed': 15139},
    'crc': {'artifactId': 15256493531, 'jobId': 140928007473, 'bytes': 588674, 'sha256': 'd4a092506e3c6623f9f3deb490cbde998f879bfb3167037fb13dfc32e3acc2c1', 'testsPassed': 15140},
}
COMMON_FILES = {'apt-install.log', 'apt-update.log', 'build.log', 'clang-version.txt', 'final-index-diff.patch', 'final-tracked-status.txt', 'final-source-sha.txt', 'final-working-diff.patch', 'lint.log', 'lld-version.txt', 'native-check.log', 'native-toolchain.json', 'node-versions.json', 'parser-asset-sha256.txt', 'registered-workflow.yml', 'source-check.log', 'source-check.json', 'types-main.log', 'types-test.log', 'unit-results.json', 'unit.log', 'validation-status.json'}
EXPECTED_STEPS = {'checkout', 'source', 'toolchain', 'setup', 'runtime', 'native', 'unit', 'build', 'lint', 'types_main', 'types_test', 'final_source'}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def parse_json(files, name):
    return json.loads(files[name])

assert FROZEN['commonBaseline']['commit'] == BASELINE
assert CONNECTOR['workflowCommit'] == WORKFLOW_COMMIT and CONNECTOR['runId'] == 46128395334
workflow_identity = git('show', '--no-patch', '--format=%H%n%T%n%P', WORKFLOW_COMMIT).decode().splitlines()
assert workflow_identity == [WORKFLOW_COMMIT, '0e7fb55986fd90b780991ac5a9d04f0a997237ca', FROZEN['crc']['commit'] + ' ' + FROZEN['score']['commit']]
workflow_bytes = git('show', f'{WORKFLOW_COMMIT}:.github/workflows/current-import-integration-gates-1b47.yml')
assert sha(workflow_bytes) == WORKFLOW_SHA
results = {}
for arm, binding in ARMS.items():
    dest = OUT / arm
    assert not (dest / 'audit.json').exists()
    artifact = next(a for a in CONNECTOR['artifacts'] if a['id'] == binding['artifactId'])
    assert artifact['digest'] == 'sha256:' + binding['sha256']
    assert artifact['size_in_bytes'] == binding['bytes'] and artifact['workflow_run']['head_sha'] == WORKFLOW_COMMIT
    job = next(j for j in CONNECTOR['jobs'] if j['id'] == binding['jobId'])
    assert job['run_id'] == 46128395334 and job['status'] == 'completed' and job['conclusion'] == 'success'
    assert all(s['status'] == 'completed' and s['conclusion'] == 'success' for s in job['steps'])
    archive_path = Path('/home/agent/manabitan-import-capture-1b47/hosted-artifacts') / f'current-integration-46128395334-{arm}.zip'
    archive_bytes = archive_path.read_bytes()
    assert len(archive_bytes) == binding['bytes'] and sha(archive_bytes) == binding['sha256']
    expected = FROZEN[arm]
    expected_names = COMMON_FILES | {'source/' + p for p in expected['exactDeltaFromCommonBase']}
    with zipfile.ZipFile(archive_path) as archive:
        assert len(archive.namelist()) == len(expected_names)
        assert set(archive.namelist()) == expected_names
        files = {name: archive.read(name) for name in archive.namelist()}
    assert files['registered-workflow.yml'] == workflow_bytes
    commit = expected['commit']
    assert git('show', '--no-patch', '--format=%H%n%T%n%P', commit).decode().splitlines() == [commit, expected['tree'], ' '.join(expected['parents'])]
    subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', commit, WORKFLOW_COMMIT], check=True)
    actual_delta = [line.split('\t') for line in git('diff', '--name-status', BASELINE, commit).decode().splitlines()]
    assert actual_delta == [['M', p] for p in sorted(expected['exactDeltaFromCommonBase'])]
    source = parse_json(files, 'source-check.json')
    assert source['passed'] is True and source['variant'] == arm and source['baseline'] == BASELINE
    assert source['workflowCommit'] == WORKFLOW_COMMIT and source['actualCommit'] == commit
    assert source['actualTree'] == expected['tree'] and source['actualParents'] == expected['parents']
    assert source['changedFiles'] == actual_delta and source['initialTrackedStatus'] == ''
    assert source['workflowSha256'] == WORKFLOW_SHA
    source_files = {}
    for path, blob in expected['exactDeltaFromCommonBase'].items():
        data = files['source/' + path]
        assert data == git('show', f'{commit}:{path}')
        assert git_blob(data) == blob
        source_files[path] = {'gitBlob': blob, 'sha256': sha(data), 'bytes': len(data)}
    assert source['files'] == source_files
    assert source['expected'] == {'commit': commit, 'tree': expected['tree'], 'parents': expected['parents'], 'files': source_files}
    assert files['final-source-sha.txt'] == (commit + '\n').encode()
    for name in ('final-index-diff.patch', 'final-working-diff.patch', 'final-tracked-status.txt'):
        assert files[name] == b''
    status = parse_json(files, 'validation-status.json')
    assert status['variant'] == arm and status['productCommit'] == commit
    assert status['commonBaseline'] == BASELINE and status['workflowCommit'] == WORKFLOW_COMMIT
    assert set(status['steps']) == EXPECTED_STEPS
    assert all(s['outcome'] == 'success' and s['conclusion'] == 'success' for s in status['steps'].values())
    assert status['steps']['checkout']['outputs']['commit'] == commit
    assert parse_json(files, 'node-versions.json')['node'] == '22.22.0'
    toolchain = parse_json(files, 'native-toolchain.json')
    assert toolchain['clang-21'] == files['clang-version.txt'].decode()
    assert toolchain['wasm-ld-21'] == files['lld-version.txt'].decode()
    assert 'clang version 21.1.8' in toolchain['clang-21'] and toolchain['wasm-ld-21'].strip() == 'Ubuntu LLD 21.1.8'
    native_log = files['native-check.log'].decode()
    native = json.loads(native_log[native_log.index('{'):])
    assert native['mode'] == 'check' and native['toolchain'] == {'compilerVersion': '21.1.8', 'linkerVersion': '21.1.8'}
    native_names = ['term-content-canonical-scan-v1.wasm', 'term-bank-parser.wasm']
    assert [x['name'] for x in native['targets']] == native_names
    for target in native['targets']:
        assert target['sha256'] == sha(git('show', f'{commit}:dev/data/dictionary-wasm/{target["name"]}'))
    parser_sha = native['targets'][1]['sha256']
    assert files['parser-asset-sha256.txt'].decode().splitlines() == [parser_sha + '  dev/data/dictionary-wasm/term-bank-parser.wasm', parser_sha + '  ext/lib/term-bank-parser.wasm']
    unit = parse_json(files, 'unit-results.json')
    assert unit['success'] is True and unit['numFailedTestSuites'] == 0 and unit['numFailedTests'] == 0
    assert unit['numPassedTestSuites'] == unit['numTotalTestSuites'] == 1577
    assert unit['numPendingTestSuites'] == unit['numTodoTests'] == 0
    assert unit['numPassedTests'] == binding['testsPassed'] and unit['numPendingTests'] == 47
    assert unit['numTotalTests'] == binding['testsPassed'] + 47
    test_files = unit['testResults']
    assert len(test_files) == len({f['name'] for f in test_files}) == 669
    assert all(f['status'] == 'passed' for f in test_files)
    assertions = [a for f in test_files for a in f['assertionResults']]
    counts = Counter(a['status'] for a in assertions)
    assert counts == {'passed': binding['testsPassed'], 'pending': 47}
    assert all(not a['failureMessages'] for a in assertions)
    skipped = [{'file': f['name'].split('/test/', 1)[-1], 'fullName': a['fullName']} for f in test_files for a in f['assertionResults'] if a['status'] == 'pending']
    unit_log = re.sub(r'\x1b\[[0-9;]*m', '', files['unit.log'].decode())
    assert re.search(r'Test Files\s+669 passed\s+\(669\)', unit_log)
    assert re.search(fr'Tests\s+{binding["testsPassed"]} passed\s+\|\s+47 skipped', unit_log)
    assert 'Restoring manifest...' in files['build.log'].decode()
    assert 'tsc --noEmit --project jsconfig.json' in files['types-main.log'].decode()
    assert 'tsc --noEmit --project test/jsconfig.typecheck.json' in files['types-test.log'].decode()
    raw = dest / 'raw'
    raw.mkdir()
    for name, data in files.items():
        path = raw / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    job_log_path = dest / 'job.log'
    result = {'schemaVersion': 1, 'auditedAt': datetime.now(timezone.utc).isoformat(), 'scope': 'Correctness only; no import or performance observation or transfer of historical timing claims.', 'variant': arm, 'runId': 46128395334, 'jobId': binding['jobId'], 'artifactId': binding['artifactId'], 'workflow': {'commit': WORKFLOW_COMMIT, 'tree': workflow_identity[1], 'parents': workflow_identity[2].split(), 'sha256': WORKFLOW_SHA}, 'source': {'commonBaseline': BASELINE, 'commit': commit, 'tree': expected['tree'], 'parents': expected['parents'], 'changedFiles': actual_delta, 'files': source_files, 'initialTrackedClean': True, 'finalTrackedClean': True, 'finalCommitUnchanged': True}, 'archive': {'path': str(archive_path), 'bytes': len(archive_bytes), 'sha256': sha(archive_bytes)}, 'members': [{'path': n, 'bytes': len(d), 'sha256': sha(d)} for n, d in sorted(files.items())], 'gates': {'allRecordedStepsSucceeded': True, 'native': native, 'testFilesPassed': 669, 'nestedSuitesPassed': 1577, 'testsPassed': binding['testsPassed'], 'testsSkipped': 47, 'allBuildTargets': 'passed', 'scopedLint': 'passed', 'runtimeTypes': 'passed', 'testTypes': 'passed', 'node': '22.22.0'}, 'skippedAssertions': skipped, 'recordedSteps': status['steps'], 'jobSteps': job['steps'], 'completionAt': status['time'], 'dependencies': [{'path': str(p), 'sha256': sha(p.read_bytes())} for p in (FROZEN_PATH, CONNECTOR_PATH)], 'jobLog': {'path': str(job_log_path), 'bytes': job_log_path.stat().st_size, 'sha256': sha(job_log_path.read_bytes())}, 'passed': True}
    (dest / 'audit.json').write_text(json.dumps(result, indent=2) + '\n')
    results[arm] = result
assert results['score']['skippedAssertions'] == results['crc']['skippedAssertions']
summary = {'recordedAt': datetime.now(timezone.utc).isoformat(), 'scope': 'Both exact current-DC integrations passed all registered correctness gates. No performance cohort or browser result.', 'runId': 46128395334, 'workflowCommit': WORKFLOW_COMMIT, 'commonBaseline': BASELINE, 'arms': {arm: {'commit': result['source']['commit'], 'audit': str(OUT / arm / 'audit.json'), 'sha256': sha((OUT / arm / 'audit.json').read_bytes()), 'testFilesPassed': 669, 'testsPassed': result['gates']['testsPassed'], 'testsSkipped': 47, 'passed': True} for arm, result in results.items()}, 'all47SkippedAssertionsIdenticalAcrossArms': True, 'passed': True}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
