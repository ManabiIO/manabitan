# CRC 8+4 tails: completed Jitendex browser control

This frozen browser cohort **passes all correctness, semantic and sampled-memory
qualification gates, with flat whole-import timing**. It records zero deferred
source-CRC work in every report, so it is an inactive-path control for the
gap-tail change. It supplies no evidence of the targeted VNDB mechanism's gain.
This result is separate from the score-JMdict and earlier checkpoint/pipeline
evidence; no cohorts are pooled.

## Exact source and artifact

- Baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
- Experimental candidate: `3080deb631a7536fabe8ccb2f77f8f55e11ef061`.
- Corresponding clean draft PR #979 head: `5909db31ebe859fce1cc4b38324271ddf9f3dd59`.
- [Actions run 46107723369](https://github.com/ManabiIO/manabitan/actions/runs/46107723369),
  job 140885249416, conclusion `success`.
- Artifact 15253902002: 35,028,916 bytes, SHA-256
  `3adefde9346afc2d20fa80a85361813036cfd627a29dfba4e0afc94ce6ef1ae0`.

The original nested extension packages and every decompressed entry match their
source identities. The two changed packaged entries are exactly
`js/dictionary/wasm/term-bank-parser.c` and `lib/term-bank-parser.wasm`.
The actual candidate module has SHA-256
`b362d9b0106c28e9cb495d66c650463c771e165cb8ebadc4a66adda973466fd9`
and Git blob `dc1673cd501778a8a48e8faa4cc5c81076f2a19d`, matching the frozen
8+4 candidate. No product overlay, import flags, replacement observation or
workflow change was used. The four memory imports use the prospectively
registered marker-only harness overlay and are validated separately.

## Whole-import timing

The unchanged schedule completes six AB/BA candidate pairs, two identical-code
control pairs and four excluded warmups. Fresh profiles and the same complete
file-input-through-post-UI timing boundary are retained.

| Estimate | B/A candidate | C/A identical code |
| --- | ---: | ---: |
| Paired median change | +0.445066% | +0.408793% |
| Equal-work change | +0.262247% | +0.385916% |
| Descriptive 95% paired-median interval | [−1.096036%, +1.448666%] | [−1.845810%, +2.663396%] |
| Faster pairs | 1 / 6 | 1 / 2 |

The candidate and same-code point estimates are similarly small and their
intervals include zero. This is a descriptive one-host result, not a claim of
speedup or exact zero overhead. All unfavorable pairs remain.

## Actual mechanism counters

`crc-path-activation.json` reads the actual 26 hosted summaries, including all
11 candidate B imports. In **every** report these four counters are zero:

- `parserSourceCrcMs`
- `parserSourceCrcScannedBytes`
- `parserSourceCrcReusedBytes`
- `parserSourceCrcReusedGlossaryCount`

The duplicate fast-path counters agree, and each summary is bound to its
original artifact-member hash. No deferred source-CRC work is recorded.
Consequently, the timing movement cannot be attributed to faster CRC gaps.
The separate full-VNDB component finding remains narrower evidence until the
registered VNDB browser cohort finishes. JMdict is also a separate pending
browser result.

The read-only reproduction helper is
`../crc-hosted-activation-census-1b47.py`; use a new output path with the retained
artifact audit. It preserves all reports and does not select only timed B runs.

## Complete qualification

All **26 raw reports and canonical semantic receipts** revalidate using the
unchanged baseline helpers: the fixed schedule, declared work, lookup,
storage-size, exhaustive-media, readback and restart comparisons pass.
This is not exhaustive byte equality for every persisted definition.

All **333 original raw memory scan rows** and their window markers reproduce
the original memory audit. All four memory observations qualify, and all frozen
bounds pass. Sampled private-memory paired change is median **+2.275069%**,
maximum **+3.134998%**; sampled PSS is median **+1.815056%**, maximum
**+1.937215%**. These are maxima among non-atomic process-tree samples, not exact
process peaks. They are separate from authoritative timing.

## Audit and retained data

`independent-artifact-audit.json` uses independently reviewed generic auditor v2,
SHA-256 `292eea976f78c24ce93f441b468c9a3efad62ad539cd9425c74eec893ee27ca0`.
It verifies actual nested package bytes/member hashes and all raw receipts,
recomputes the original fixed statistics and raw memory audit, and explicitly
checks source SHA ↔ registered plan, every observation time ↔ raw summary,
the exact 20-record/six-pair/two-control schedule, 26 distinct receipt names,
and final status ↔ memory/semantic outcomes. These are this cohort's own
verification checks, not implicit coverage from the earlier seven-cohort
supplement. No original auditor or prior audit was rewritten.

The full log, emitted plan/browser identities/observations/analysis, memory
comparison, statuses and artifact metadata are retained beside this README.
All 206 original artifact members are inventoried.

- Original ZIP: `/home/agent/manabitan-import-capture-1b47/hosted-artifacts/crc-1b47-screen-jitendex-15253902002.zip`.
- Raw extraction: `/home/agent/manabitan-import-capture-1b47/hosted-artifacts/crc-jitendex-15253902002-extracted/jitendex`.

The working extraction omits HTML views and duplicate package containers; both
remain in the original ZIP. No new acquisition, retry, threshold adjustment,
source change or further performance claim follows this audit.
