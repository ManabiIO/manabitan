# CRC VNDB: complete timing retained; qualification failed

Run [46107723369](https://github.com/ManabiIO/manabitan/actions/runs/46107723369/job/140885249404) compares baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` with frozen study `3080deb631a7536fabe8ccb2f77f8f55e11ef061`. The actual packaged CRC WASM matches draft PR #979's frozen 8+4 implementation. The v2 raw auditor verifies both complete package member maps, source/plan identity, all 20 schedule clocks, 26 original reports/receipts, exact storage/work/lookup/restart/media comparisons and the unchanged qualification status.

| Original primary statistic       |         Candidate B/A |   Identical code C/A |
| -------------------------------- | --------------------: | -------------------: |
| Median paired import-time change |              +4.6426% |             +1.1104% |
| Equal-work change                |              +6.4226% |             +0.8501% |
| Descriptive 95% interval         | [−0.9559%, +15.5290%] | [−5.9516%, +8.1724%] |
| Faster pairs                     |                   2/6 |                  1/2 |

All unfavorable observations remain, including the worst candidate pair at **+19.3509%**. All 26 individual imports and semantic receipts pass. The separate memory screen retains **482 raw scans** but baseline A2 has a **295.200949 ms coverage gap**, exceeding its original 250 ms requirement. Its maxima and aggregate comparison stay null. This is incomplete memory coverage, not a demonstrated memory regression. The original job and qualification remain failed.

## Added secondary CRC phase description

Root requested this analysis at **07:50:20 UTC while the cohort was already running, before its result was reviewed**. It is an added secondary analysis, not a prospectively registered primary endpoint or acquisition amendment. It uses only the original six candidate and two identical-code timing pairs, with the original seed-897 paired median/bootstrap definitions. All raw and primary-analysis bytes remain unchanged.

All 16 retained timing observations perform exactly **568,284,368 scanned bytes, 3,699,708,599 reused bytes and 6,490,145 reused glossaries**. `parserSourceCrcMs` is **summed worker phase time**, not complete-import wall time. Candidate paired median is **−4.0486%**, equal-work **−4.0686%**, interval **[−5.4962%, −2.6251%]**, with all six pairs lower. The two identical-code phase controls also improve, by **−0.1508% and −4.3172%** (median **−2.2340%**). This supports an observed lower CRC phase but leaves control drift material; no control-adjusted effect, phase subtraction, primary-gate change, or whole-import speedup is asserted.

`independent-artifact-audit.json`, `activation-census.json` and `secondary-crc-phase-analysis.json` retain exact identities, every raw observation/hash, equality checks and arithmetic. The secondary declaration, final helper and independent static review are separate top-level evidence files. The original artifact SHA256 is `71282cac043798573e342653cfa992bcedd5b6932afd38343e1a37762c5548bd` (35,180,039 bytes).
