# CRC 8+4 tails: completed JMdict browser control

All frozen semantic and sampled-memory qualification gates pass, and whole-import timing is flat. Every report records zero deferred source-CRC work, so this is an inactive-path control for the gap-tail change. It does not establish the targeted VNDB mechanism’s gain.

## Frozen source and acquisition

- Baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
- Experimental candidate: `3080deb631a7536fabe8ccb2f77f8f55e11ef061`.
- Corresponding clean draft PR #979 head: `5909db31ebe859fce1cc4b38324271ddf9f3dd59`.
- [Actions run 46107723369](https://github.com/ManabiIO/manabitan/actions/runs/46107723369),
  job 140885249418; conclusion `success`.
- Artifact 15253927810: 34,981,272 bytes, SHA-256
  `1c3fd8b283a244f8c50ac4d7034af695466db409b530c953f134ecb3fe3553c8`.

Actual nested package bytes and every decompressed package member match the
source identities. The changed entries are exactly the registered list:
`js/dictionary/wasm/term-bank-parser.c`, `lib/term-bank-parser.wasm`. The actual relevant
product Git blob identities also match the clean PR; `result-summary.json`
records their bytes and SHA-256 values.

The unchanged schedule completed six AB/BA candidate pairs, two identical-code
control pairs, four excluded warmups, two exhaustive-media imports and four
separate memory imports. Timing is file-input change through post-UI completion
in fresh profiles. No import flags, product overlays, unregistered harness
changes, replacement observations or retries occurred. The memory imports use
the prospectively registered marker-only harness overlay, outside authoritative
timing and with separately validated source hashes/dirty status.

## Complete-import timing

| Estimate | B/A candidate | C/A identical code |
| --- | ---: | ---: |
| Paired median change | -0.161723% | +0.309111% |
| Equal-work change | +0.060616% | +0.295317% |
| Descriptive 95% paired-median interval | [-0.657235%, +1.006903%] | [-1.507327%, +2.125549%] |
| Faster pairs | 3 / 6 | 1 / 2 |

This is one fixed host/cohort with descriptive intervals. No control drift is
subtracted from the candidate estimate and no separate cohorts are pooled.

## Actual source-CRC path counters

`crc-path-activation.json` reads all 26 original hosted summaries, including all
11 candidate B imports. In every report, `parserSourceCrcMs`,
`parserSourceCrcScannedBytes`, `parserSourceCrcReusedBytes` and
`parserSourceCrcReusedGlossaryCount` are zero. Their duplicate fast-path counters
agree. Each summary hash matches the original artifact inventory.

Thus no deferred source-CRC work is recorded. Timing movement is not attributed
to faster CRC gaps. The actual packaged module exactly matches the frozen 8+4
candidate, SHA-256 `b362d9b0106c28e9cb495d66c650463c771e165cb8ebadc4a66adda973466fd9`.
The separate registered VNDB browser cohort is the targeted mechanism test;
no result from this control is pooled with it. The read-only counter helper is
`../crc-hosted-activation-census-1b47.py`, with a fresh output path.

## Semantics and sampled memory

All **26 raw reports and canonical receipts** independently pass the unchanged
source-bound semantic validator, including declared work, lookup, complete
storage-size, media/readback and restart comparisons. This is not an exhaustive
byte comparison of every persisted definition.

All **303 original raw memory scan rows** and their window markers reproduce
the original audit. All four memory observations qualify and every frozen
sampled-memory bound passes. Private-memory paired change is median
**+1.184772%**, maximum **+1.876245%**;
PSS is median **+0.527512%**, maximum **+1.209999%**.
These are maxima among non-atomic sampled process-tree readings, not exact
process peaks. Passing this gate does not turn the timing point estimate into
a performance benefit.

## Independent artifact audit and retained data

The reviewed generic v2 auditor, SHA-256
`292eea976f78c24ce93f441b468c9a3efad62ad539cd9425c74eec893ee27ca0`, verifies all original package/member bytes, all
26 receipts, the raw memory audit and exact original paired statistics. Its own
explicit guards bind A/B source SHA to the registered plan, every observation
time to the raw summary, the exact 20-record/six-pair/two-control schedule and
26 distinct receipt names, and final status to recomputed memory/semantic
outcomes. This cohort has its own guard receipt; it is not covered implicitly
by the earlier seven-cohort supplement. Original generic and earlier audit
files remain unchanged.

`job.log`, emitted JSON, `independent-artifact-audit.json`,
`result-summary.json`, original metadata and retrieval provenance are retained
beside this README. All 206 artifact members are inventoried.

- Original ZIP: `/home/agent/manabitan-import-capture-1b47/hosted-artifacts/crc-1b47-screen-jmdict-15253927810.zip`.
- Raw extraction: `/home/agent/manabitan-import-capture-1b47/hosted-artifacts/crc-jmdict-15253927810-extracted/jmdict`.

The working extraction omits HTML views and duplicate package containers; both
remain in the original ZIP. No new browser acquisition, threshold change,
source change, observation substitution or retry follows this audit.
