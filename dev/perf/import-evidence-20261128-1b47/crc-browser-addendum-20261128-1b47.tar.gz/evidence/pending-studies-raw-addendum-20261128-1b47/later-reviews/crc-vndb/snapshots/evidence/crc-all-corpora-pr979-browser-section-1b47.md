## Completed browser screen: no whole-import gain

The frozen study `3080deb631a7536fabe8ccb2f77f8f55e11ef061` has the exact four product files in this PR. Both actual extension packages were audited; only the C source and generated WASM differ, with candidate WASM Git blob `dc1673cd501778a8a48e8faa4cc5c81076f2a19d`.

All 26 imports and semantic receipts per corpus pass. Negative changes are faster. These are the original six paired complete-import observations and two identical-code controls; no observations are excluded or adjusted.

| Corpus   | B/A paired median | Equal-work change | Descriptive 95% interval | Identical C/A median | Original memory gate                                                       |
| -------- | ----------------: | ----------------: | ------------------------ | -------------------: | -------------------------------------------------------------------------- |
| JMdict   |          −0.1617% |          +0.0606% | [−0.6572%, +1.0069%]     |             +0.3091% | Pass; 303 raw scans                                                        |
| Jitendex |          +0.4451% |          +0.2622% | [−1.0960%, +1.4487%]     |             +0.4088% | Pass; 333 raw scans                                                        |
| VNDB     |          +4.6426% |          +6.4226% | [−0.9559%, +15.5290%]    |             +1.1104% | Fail; A2 coverage gap 295.200949 ms exceeds 250 ms; 482 raw scans retained |

JMdict and Jitendex have zero deferred-source CRC time/scanned/reused work in every report, so they are inactive-path controls for this change. VNDB is active, but four of six complete imports are slower, including the full +19.3509% sixth pair. Its memory failure is insufficient coverage, not a demonstrated memory regression; the comparison remains unqualified, with null aggregate maxima.

An **added secondary analysis**, requested at 07:50:20 UTC while VNDB was running and before its outcome was reviewed, describes the same six pairs and two controls. It is not a registered primary endpoint or new gate. All 16 observations have exactly 568,284,368 scanned bytes, 3,699,708,599 reused bytes and 6,490,145 reused glossaries. Summed worker `parserSourceCrcMs` is lower in all six candidate pairs: median −4.0486%, equal-work −4.0686%, descriptive interval [−5.4962%, −2.6251%]. Both identical-code phase controls also improve (−0.1508% and −4.3172%), limiting attribution. This timer covers the deferred verifier, not just its gap-tail helper, and is not import wall time. No control or phase time is subtracted from the primary result.

The earlier component benefit and this secondary phase observation support only a small held implementation review. **The complete browser study establishes no import gain or broad non-regression, fails VNDB memory qualification, and does not establish merge readiness.** The adverse VNDB timing remains part of the decision.

Original run: [46107723369](https://github.com/ManabiIO/manabitan/actions/runs/46107723369). Durable raw evidence should be linked here only after its separate publication; no unavailable link is implied by this prepared section.
