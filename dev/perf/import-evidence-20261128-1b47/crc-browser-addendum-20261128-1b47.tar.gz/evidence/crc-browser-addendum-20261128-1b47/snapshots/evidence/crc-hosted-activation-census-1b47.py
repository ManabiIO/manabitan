#!/usr/bin/env python3
"""Read actual CRC-path counters from a previously audited hosted artifact."""
import argparse
import hashlib
import io
import json
import math
import pathlib
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--audit', type=pathlib.Path, required=True)
parser.add_argument('--output', type=pathlib.Path, required=True)
args = parser.parse_args()
assert not args.output.exists(), 'Never overwrite an earlier census'
audit = json.loads(args.audit.read_text())
plan = audit['registeredPlan']
assert plan['candidate'] == '3080deb631a7536fabe8ccb2f77f8f55e11ef061'
dictionary = plan['dictionary']
root = pathlib.Path(audit['extraction']) / dictionary
inventory = {item['path']: item for item in audit['memberInventory']}
items = {item['id']: item['arm'] for item in plan['schedule']}
items.update({'exhaustive-media-A': 'A', 'exhaustive-media-B': 'B'})
items.update({'memory/' + item['name']: item['arm'] for item in plan['memorySchedule']})
keys = ['parserSourceCrcMs', 'parserSourceCrcScannedBytes',
        'parserSourceCrcReusedBytes', 'parserSourceCrcReusedGlossaryCount']
rows = []
for name, arm in items.items():
    data = (root / name / 'summary.json').read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert digest == inventory[dictionary + '/' + name + '/summary.json']['sha256']
    summary = json.loads(data)
    phases = summary['runs'][0]['importDebug']['importerPhaseTimings']
    details = [item['details'] for item in phases if isinstance(item.get('details'), dict)
               and 'parserSourceCrcMs' in item['details']]
    assert len(details) == 1
    metrics = {key: details[0][key] for key in keys}
    assert all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in metrics.values())
    fast = [item['details'] for item in phases if isinstance(item.get('details'), dict)
            and 'fastPathParserSourceCrcMs' in item['details']]
    assert len(fast) == 1
    assert all(fast[0]['fastPath' + key[0].upper() + key[1:]] == value for key, value in metrics.items())
    rows.append({'path': name, 'arm': arm, 'summarySha256': digest,
                 'metrics': metrics, 'fastPathDuplicateCountersAgree': True})
assert len(rows) == 26
candidate_rows = [item for item in rows if item['arm'] == 'B']
assert len(candidate_rows) == 11
archive_data = pathlib.Path(audit['archive']).read_bytes()
assert hashlib.sha256(archive_data).hexdigest() == audit['archiveSha256']
with zipfile.ZipFile(io.BytesIO(archive_data)) as outer:
    package = outer.read(dictionary + '/package-B.zip')
    assert hashlib.sha256(package).hexdigest() == audit['sourceIdentities']['arms']['B']['packageSha256']
    with zipfile.ZipFile(io.BytesIO(package)) as inner:
        wasm = inner.read('lib/term-bank-parser.wasm')
        wasm_sha = hashlib.sha256(wasm).hexdigest()
        wasm_blob = hashlib.sha1(b'blob ' + str(len(wasm)).encode() + b'\0' + wasm).hexdigest()
        assert wasm_sha == 'b362d9b0106c28e9cb495d66c650463c771e165cb8ebadc4a66adda973466fd9'
        assert wasm_blob == 'dc1673cd501778a8a48e8faa4cc5c81076f2a19d'
all_zero = all(all(value == 0 for value in item['metrics'].values()) for item in rows)
result = {
    'scope': 'Read-only actual hosted source-CRC work counters; no new observation or timing attribution',
    'candidateHead': plan['candidate'], 'packagedWasmSha256': wasm_sha,
    'packagedWasmGitBlob': wasm_blob, 'allReports': len(rows), 'candidateBReports': len(candidate_rows),
    'allFourSourceCrcCountersZero': all_zero,
    'candidateAllFourSourceCrcCountersZero': all(all(value == 0 for value in item['metrics'].values()) for item in candidate_rows),
    'observations': rows,
    'interpretation': ('No deferred source-CRC work is recorded in any report; this is an inactive-path control for gap-tail optimization, not evidence of its targeted VNDB gain.'
                       if all_zero else 'Deferred source-CRC work is recorded; counters establish route activation only, and do not establish a timing gain.'),
}
with args.output.open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps({'reports': len(rows), 'candidateReports': len(candidate_rows),
                  'allFourCountersZero': all_zero, 'output': str(args.output)}))
