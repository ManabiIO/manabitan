#!/usr/bin/env python3
"""Added descriptive worker-CRC analysis of existing frozen VNDB observations.

Chosen while the cohort was running, before its outcome review; never a primary
endpoint amendment, new qualification gate, or new observation acquisition.
"""
import argparse
import hashlib
import json
import math
import pathlib
import random
import statistics

parser = argparse.ArgumentParser()
parser.add_argument('--audit', type=pathlib.Path, required=True)
parser.add_argument('--census', type=pathlib.Path, required=True)
parser.add_argument('--output', type=pathlib.Path, required=True)
args = parser.parse_args()
assert not args.output.exists()
evidence = pathlib.Path(__file__).resolve().parent
declaration_path = evidence / 'crc-vndb-secondary-analysis-plan-1b47.json'
declaration_bytes = declaration_path.read_bytes()
sha = lambda data: hashlib.sha256(data).hexdigest()
assert sha(declaration_bytes) == 'ee55811333e864007da10d8699c097fe759fe0906fc6baaebaeff9871634a779'
declaration = json.loads(declaration_bytes)
audit_bytes = args.audit.read_bytes()
audit = json.loads(audit_bytes)
census_bytes = args.census.read_bytes()
census = json.loads(census_bytes)
plan = audit['registeredPlan']
assert plan['dictionary'] == 'vndb'
assert plan['baseline'] == declaration['baseline'] and plan['candidate'] == declaration['candidate']
assert census['candidateHead'] == plan['candidate']
assert audit['all26ReceiptsExact'] and audit['sourcePlanAndClockLinksExact'] and audit['scheduleAndStatusRecomputed']
assert len(census['observations']) == 26
root = pathlib.Path(audit['extraction']) / 'vndb'
members = {item['path']: item for item in audit['memberInventory']}
census_rows = {item['path']: item for item in census['observations']}
keys = ['parserSourceCrcMs', 'parserSourceCrcScannedBytes',
        'parserSourceCrcReusedBytes', 'parserSourceCrcReusedGlossaryCount']
work_keys = keys[1:]
rows = []
excluded_schedule = []
for item in plan['schedule']:
    if item['kind'] not in ('candidate', 'control'):
        assert item['kind'] == 'warmup'
        excluded_schedule.append(item['id'])
        continue
    relative = 'vndb/' + item['id'] + '/summary.json'
    data = (root / item['id'] / 'summary.json').read_bytes()
    assert sha(data) == members[relative]['sha256']
    summary = json.loads(data)
    phases = summary['runs'][0]['importDebug']['importerPhaseTimings']
    details = [phase['details'] for phase in phases if isinstance(phase.get('details'), dict)
               and 'parserSourceCrcMs' in phase['details']]
    assert len(details) == 1
    metrics = {key: details[0][key] for key in keys}
    assert all(type(value) in (int, float) and math.isfinite(value) and value >= 0 for value in metrics.values())
    fast = [phase['details'] for phase in phases if isinstance(phase.get('details'), dict)
            and 'fastPathParserSourceCrcMs' in phase['details']]
    assert len(fast) == 1
    assert all(fast[0]['fastPath' + key[0].upper() + key[1:]] == value for key, value in metrics.items())
    original_census = census_rows[item['id']]
    assert original_census['metrics'] == metrics and original_census['summarySha256'] == sha(data)
    assert original_census['arm'] == item['arm']
    rows.append({**item, 'summarySha256': sha(data), 'metrics': metrics})
assert len(rows) == 16 and len(excluded_schedule) == 4
assert sum(row['kind'] == 'candidate' for row in rows) == 12
assert sum(row['kind'] == 'control' for row in rows) == 4

def paired(kind, left, right, expected_count):
    pairs = {}
    for row in rows:
        if row['kind'] == kind:
            assert row['arm'] not in pairs.setdefault(row['pair'], {})
            pairs[row['pair']][row['arm']] = row['metrics']
    assert len(pairs) == expected_count and all(set(pair) == {left, right} for pair in pairs.values())
    work_checks = [{'pair': pair_id, 'leftArm': left, 'rightArm': right,
                    'left': {key: pair[left][key] for key in work_keys},
                    'right': {key: pair[right][key] for key in work_keys},
                    'equal': all(pair[left][key] == pair[right][key] for key in work_keys)}
                   for pair_id, pair in pairs.items()]
    left_times = [pair[left]['parserSourceCrcMs'] for pair in pairs.values()]
    right_times = [pair[right]['parserSourceCrcMs'] for pair in pairs.values()]
    if any(value <= 0 for value in left_times):
        return {'count': expected_count, 'statisticsComputed': False,
                'reason': 'Nonpositive denominator; no ratio or mechanism gain asserted',
                'leftDurationsMs': left_times, 'rightDurationsMs': right_times,
                'workChecks': work_checks, 'allPairsSameWork': all(row['equal'] for row in work_checks)}
    ratios = [right / left for left, right in zip(left_times, right_times)]
    rng = random.Random(897)
    resampled = sorted(statistics.median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
    return {'count': expected_count, 'statisticsComputed': True, 'ratios': ratios,
            'medianPairedChangePercent': (statistics.median(ratios) - 1) * 100,
            'equalWorkChangePercent': (sum(right_times) / sum(left_times) - 1) * 100,
            'worstPairChangePercent': (max(ratios) - 1) * 100,
            'descriptiveBootstrap95Percent': [(resampled[index] - 1) * 100 for index in (249, 9749)],
            'fasterPairs': sum(ratio < 1 for ratio in ratios),
            'leftArmMedianMs': statistics.median(left_times), 'rightArmMedianMs': statistics.median(right_times),
            'leftDurationsMs': left_times, 'rightDurationsMs': right_times,
            'workChecks': work_checks, 'allPairsSameWork': all(row['equal'] for row in work_checks)}

candidate = paired('candidate', 'A', 'B', 6)
control = paired('control', 'A', 'C', 2)
unique_work = sorted({tuple(row['metrics'][key] for key in work_keys) for row in rows})
result = {
    'scope': 'Added secondary descriptive mechanism analysis; not a primary endpoint, acquisition amendment or qualification gate',
    'declaration': declaration, 'declarationSha256': sha(declaration_bytes),
    'scriptSha256': sha(pathlib.Path(__file__).read_bytes()),
    'originalAuditSha256': sha(audit_bytes), 'activationCensusSha256': sha(census_bytes),
    'archiveSha256': audit['archiveSha256'], 'baseline': plan['baseline'], 'candidate': plan['candidate'],
    'metric': 'parserSourceCrcMs', 'metricBoundary': 'Summed worker phase time, not browser complete-import wall time',
    'selectedOriginalObservations': rows, 'excludedOriginalWarmupIds': excluded_schedule,
    'separateMediaAndMemoryObservationsExcludedFromPhaseTiming': 6,
    'candidateVsBaseline': candidate, 'identicalCodeControl': control,
    'workCounterKeys': work_keys, 'uniqueWorkCounterTuples': [list(values) for values in unique_work],
    'sameWorkAcrossAll16TimingObservations': len(unique_work) == 1,
    'originalPrimaryCandidateTiming': audit['candidateVsBaselineRecomputed'],
    'originalPrimaryIdenticalControlTiming': audit['identicalCodeControlRecomputed'],
    'originalQualificationStatus': audit['status'],
    'limits': 'No phase addition/subtraction, control adjustment, host/cohort pooling, new promotion threshold or primary-gate change. Differing work would limit comparison. All original unfavorable observations remain.',
    'newBrowserObservations': 0, 'originalRawAndPrimaryAnalysisUnchanged': True,
}
with args.output.open('x') as output:
    json.dump(result, output, indent=2)
    output.write('\n')
print(json.dumps({key: result[key] for key in ('metricBoundary', 'candidateVsBaseline',
    'identicalCodeControl', 'sameWorkAcrossAll16TimingObservations', 'uniqueWorkCounterTuples')}))
