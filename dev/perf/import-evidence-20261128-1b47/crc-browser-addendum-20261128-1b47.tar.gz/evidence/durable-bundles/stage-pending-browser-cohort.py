#!/usr/bin/env python3
"""Stage one completed, independently audited browser artifact without rerunning it.

Each cohort is written once. Raw files, original receipts and auditor sources are
immutable after staging; only the open bundle index can acquire another cohort.
This helper verifies file identities and counts, not semantic qualification.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require_regular(path):
    for part in [path, *path.parents]:
        assert not part.is_symlink(), f'Symlink input or ancestor: {part}'
    assert stat.S_ISREG(path.stat().st_mode), f'Not a regular file: {path}'


def safe_relative(name):
    path = PurePosixPath(name)
    assert not path.is_absolute() and '..' not in path.parts and path.as_posix() == name, name
    return path


parser = argparse.ArgumentParser()
parser.add_argument('--source-root', type=Path, required=True)
parser.add_argument('--staging-root', type=Path, required=True)
parser.add_argument('--label', required=True)
parser.add_argument('--receipt-directory', required=True)
parser.add_argument('--artifact-id', type=int, required=True)
parser.add_argument('--expected-sha256', required=True)
parser.add_argument('--expected-reports', type=int, required=True)
parser.add_argument('--expected-memory-scans', type=int, required=True)
parser.add_argument('--expected-candidate', required=True)
parser.add_argument('--expected-baseline', default='9e10d3b3fcf66d344ab31bc42c9b522fa5215da2')
parser.add_argument('--auditor', default='evidence/audit-hosted-import-artifact-1b47.py')
parser.add_argument('--supplement', action='append', default=[])
args = parser.parse_args()
assert re.fullmatch(r'(score|crc|compression)-(jmdict|jitendex|vndb)', args.label)
assert re.fullmatch(r'[a-f0-9]{64}', args.expected_sha256)
root = args.source_root.absolute()
stage = args.staging_root.absolute()
bundle = stage / 'evidence/pending-studies-raw-addendum-20261128-1b47'
cohort = bundle / 'cohorts' / args.label
for part in [stage, *stage.parents]:
    assert not part.is_symlink(), f'Symlink staging ancestor: {part}'
assert not cohort.exists(), 'Cohort already staged; do not overwrite or reacquire it'
receipt_root = root / safe_relative(args.receipt_directory)
audit_path = receipt_root / 'independent-artifact-audit.json'
require_regular(audit_path)
audit_bytes = audit_path.read_bytes()
audit = json.loads(audit_bytes)
plan = audit['registeredPlan']
assert plan['baseline'] == args.expected_baseline
assert plan['candidate'] == args.expected_candidate
dictionary = plan['dictionary']
assert dictionary == args.label.rsplit('-', 1)[1]
assert audit['rawMemoryScanAudit']['rawScanCount'] == args.expected_memory_scans
archive = Path(audit['archive'])
assert archive.is_absolute()
assert str(archive).startswith('/home/agent/manabitan-import-capture-1b47/hosted-artifacts/')
assert archive.name.endswith('-' + str(args.artifact_id) + '.zip')
require_regular(archive)
with archive.open('rb') as stream:
    archive_sha = hashlib.file_digest(stream, 'sha256').hexdigest()
assert archive_sha == audit['archiveSha256'] == args.expected_sha256
assert archive.stat().st_size == audit['archiveBytes']
inventory = {x['path']: x for x in audit['memberInventory']}
assert len(inventory) == len(audit['memberInventory']) == audit['memberCount']
for name in inventory:
    safe_relative(name)

payloads = []
raw_inventory = []
omissions = []
reports = canonical_receipts = memory_rows = memory_files = 0
package_names = {dictionary + '/package-A.zip', dictionary + '/package-B.zip'}
with zipfile.ZipFile(archive) as source:
    names = [x.filename for x in source.infolist() if not x.is_dir()]
    assert len(names) == len(set(names)) and set(names) == set(inventory)
    for info in source.infolist():
        if info.is_dir():
            continue
        name = info.filename
        safe_relative(name)
        assert not stat.S_ISLNK(info.external_attr >> 16)
        record = inventory[name]
        assert info.file_size == record['bytes']
        if name in package_names:
            with source.open(info) as stream:
                digest = hashlib.file_digest(stream, 'sha256').hexdigest()
            assert digest == record['sha256']
            omissions.append({'originalArtifactMember': name, 'bytes': record['bytes'],
                'sha256': digest, 'included': False,
                'reason': 'Duplicate complete extension ZIP; exact digest and full package inventories retained',
                'verification': 'Exact member digest rechecked from original verified outer artifact',
                'reconstruction': 'Exact original Actions artifact required for repeating container-byte verification; a rebuilt ZIP is not claimed byte-identical'})
            continue
        data = source.read(info)
        assert len(data) == record['bytes'] and sha(data) == record['sha256']
        relative = 'raw/' + name
        payloads.append((relative, data))
        raw_inventory.append({'originalArtifactMember': name, 'cohortRelativePath': relative,
                              'bytes': len(data), 'sha256': sha(data)})
        reports += name.endswith('/run-1.json')
        canonical_receipts += name.endswith('/canonical-receipt.json')
        if name.endswith('/memory.json') and '/memory/' in name:
            memory_files += 1
            memory_rows += len(json.loads(data)['samples'])
assert {x['originalArtifactMember'] for x in omissions} == package_names
assert len(payloads) == audit['memberCount'] - 2
assert reports == canonical_receipts == args.expected_reports
assert memory_rows == args.expected_memory_scans

snapshot_inventory = []
snapshot_paths = []
for directory, directories, files in os.walk(receipt_root, followlinks=False):
    assert all(not (Path(directory) / name).is_symlink() for name in directories)
    snapshot_paths.extend(Path(directory) / name for name in sorted(files))
snapshot_paths.extend(root / safe_relative(name) for name in args.supplement)
assert len(snapshot_paths) == len(set(snapshot_paths))
for path in snapshot_paths:
    require_regular(path)
    data = path.read_bytes()
    relative = 'snapshots/' + path.relative_to(root).as_posix()
    payloads.append((relative, data))
    snapshot_inventory.append({'originalWorkspacePath': path.relative_to(root).as_posix(),
        'cohortRelativePath': relative, 'bytes': len(data), 'sha256': sha(data)})

auditor = root / safe_relative(args.auditor)
require_regular(auditor)
auditor_bytes = auditor.read_bytes()
assert sha(auditor_bytes) == audit['auditorSha256']
payloads.append(('scripts/' + args.auditor, auditor_bytes))
validator_inventory = []
for name, digest in audit['validatorDependencies'].items():
    safe_relative(name)
    path = root / 'manabitan' / name
    require_regular(path)
    data = path.read_bytes()
    original = subprocess.check_output(['git', '-C', str(root / 'manabitan'),
                                        'show', args.expected_baseline + ':' + name])
    assert data == original and sha(data) == digest
    relative = 'validators/' + name
    payloads.append((relative, data))
    validator_inventory.append({'baselinePath': name, 'cohortRelativePath': relative,
                                'bytes': len(data), 'sha256': digest})
helper = Path(__file__).absolute()
require_regular(helper)
helper_bytes = helper.read_bytes()
payloads.append(('scripts/stage-pending-browser-cohort.py', helper_bytes))
assert len({x[0] for x in payloads}) == len(payloads)

# All original bytes and source identities have been checked before first write.
cohort.mkdir(parents=True)
members = []
for relative, data in payloads:
    destination = cohort / safe_relative(relative)
    destination.parent.mkdir(parents=True, exist_ok=True)
    for part in [destination.parent, *destination.parent.parents]:
        assert not part.is_symlink(), f'Symlink output ancestor: {part}'
    with destination.open('xb') as output:
        output.write(data)
    require_regular(destination)
    assert sha(destination.read_bytes()) == sha(data)
    members.append({'path': destination.relative_to(stage).as_posix(),
                    'bytes': len(data), 'sha256': sha(data)})
record = {
    'label': args.label, 'stagedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'state': 'immutable cohort staged; enclosing bundle remains open and unsealed',
    'baseline': plan['baseline'], 'candidate': plan['candidate'], 'artifactId': args.artifact_id,
    'originalArchive': {'file': archive.name, 'bytes': audit['archiveBytes'],
                        'sha256': archive_sha, 'members': audit['memberCount']},
    'retainedOriginalMembers': len(raw_inventory), 'rawReports': reports,
    'canonicalReceipts': canonical_receipts, 'rawMemoryFiles': memory_files,
    'rawMemoryScanRows': memory_rows, 'rawMemberInventory': raw_inventory,
    'originalReceiptSnapshots': snapshot_inventory, 'validatorSources': validator_inventory,
    'omittedPackages': omissions, 'auditSha256': sha(audit_bytes),
    'auditorSource': {'path': args.auditor, 'sha256': sha(auditor_bytes)},
    'stagingHelperSha256': sha(helper_bytes), 'qualificationStatusAsAudited': audit['status'],
    'allPackageBytesMatchIdentityAsAudited': audit['allPackageBytesMatchIdentity'],
    'all26ReceiptsExactAsAudited': audit.get('all26ReceiptsExact'),
    'qualificationScope': 'Preserved original audit; this staging helper checks bytes/counts and does not reinterpret semantic, timing, storage, or memory gates',
    'newAcquisitions': 0, 'originalBytesModified': False, 'symlinksFollowed': False,
    'members': members,
}
record_path = cohort / 'cohort-record.json'
record_path.write_text(json.dumps(record, indent=2) + '\n')
index_path = bundle / 'open-staging-index.json'
if index_path.exists():
    require_regular(index_path)
    index = json.loads(index_path.read_text())
else:
    index = {'state': 'open; do not publish as a sealed cohort set',
             'allowedStudies': ['score', 'crc', 'compression'], 'cohorts': []}
assert not any(x['label'] == args.label for x in index['cohorts'])
index['cohorts'].append({'label': args.label, 'artifactId': args.artifact_id,
    'recordPath': record_path.relative_to(stage).as_posix(), 'recordSha256': sha(record_path.read_bytes()),
    'archiveSha256': archive_sha, 'rawReports': reports, 'canonicalReceipts': canonical_receipts,
    'rawMemoryScanRows': memory_rows, 'baseline': plan['baseline'], 'candidate': plan['candidate']})
index['updatedUtc'] = record['stagedUtc']
temporary = index_path.with_suffix('.tmp')
with temporary.open('x') as output:
    output.write(json.dumps(index, indent=2) + '\n')
temporary.replace(index_path)
print(json.dumps({'label': args.label, 'originalArtifactMembers': audit['memberCount'],
    'retainedOriginalMembers': len(raw_inventory), 'rawReports': reports,
    'canonicalReceipts': canonical_receipts, 'memoryScanRows': memory_rows,
    'stagedMembers': len(members) + 1, 'payloadBytes': sum(x['bytes'] for x in members),
    'recordPath': str(record_path), 'recordSha256': sha(record_path.read_bytes()),
    'newAcquisitions': 0, 'bundleSealed': False}))
