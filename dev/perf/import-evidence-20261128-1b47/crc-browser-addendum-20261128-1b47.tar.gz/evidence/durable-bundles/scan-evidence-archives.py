#!/usr/bin/env python3
"""Bounded text scan; print only member names/counts, never matched values."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import tarfile

PATTERNS = {
    'signed-or-tokenized-url': re.compile(r'https?://[^\s"<>]+[?&](?:X-Amz-(?:Signature|Credential|Security-Token)|sig|Signature|AWSAccessKeyId|access_token|token)=[^\s"<>]+', re.I),
    'credential-shaped-token': re.compile(r'\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|sk-[A-Za-z0-9_-]{24,}|AKIA[A-Z0-9]{16})\b'),
    'private-key-header': re.compile(r'-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----'),
    'authorization-value': re.compile(r'Authorization["\s]*[:=]["\s]*(?:Bearer|Basic)\s+[A-Za-z0-9+/=_-]{12,}', re.I),
    'url-password': re.compile(r'https?://[^/@\s:]+:[^/@\s]+@'),
    'unrelated-user-home': re.compile(r'/(?:home|Users)/(?!runner(?:/|\b)|agent(?:/|\b)|oai(?:/|\b)|node(?:/|\b))[A-Za-z0-9_.-]+/'),
    'email-shaped-reference': re.compile(r'\b[A-Za-z0-9_.+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b'),
}
parser = argparse.ArgumentParser()
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('archives', nargs='+', type=Path)
args = parser.parse_args()
report = {'scan': 'Text members only; fixed patterns; matched values deliberately never reported', 'archives': []}
for archive in args.archives:
    counts = {'textMembers': 0, 'binaryMembers': 0}
    hits = []
    with tarfile.open(archive, 'r:gz') as stream:
        for item in stream:
            assert item.isfile() and item.size < 50_000_000
            data = stream.extractfile(item).read()
            if b'\0' in data:
                counts['binaryMembers'] += 1
                continue
            try:
                content = data.decode('utf-8')
            except UnicodeError:
                counts['binaryMembers'] += 1
                continue
            counts['textMembers'] += 1
            for kind, pattern in PATTERNS.items():
                count = sum(1 for _ in pattern.finditer(content))
                if count:
                    hits.append({'member': item.name, 'kind': kind, 'count': count})
    report['archives'].append({'archive': archive.name, 'bytes': archive.stat().st_size,
        'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), **counts, 'hits': hits})
args.output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
