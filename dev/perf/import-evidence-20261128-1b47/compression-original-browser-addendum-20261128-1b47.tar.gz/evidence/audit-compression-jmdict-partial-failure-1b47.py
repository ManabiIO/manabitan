#!/usr/bin/env python3
"""Reproduce the existing first-warmup policy failure, never qualify a cohort.

This reads an already acquired partial artifact. It retains all bytes and calls
the unchanged published validators/policy. Missing later observations remain
missing; no digest is normalized and no performance statistic is derived.
"""
import argparse
import hashlib
import io
import json
import pathlib
import subprocess
import sys
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--archive', type=pathlib.Path, required=True)
parser.add_argument('--extract', type=pathlib.Path, required=True)
parser.add_argument('--output', type=pathlib.Path, required=True)
args = parser.parse_args()
assert not args.extract.exists() and not args.output.exists()
evidence = pathlib.Path(__file__).resolve().parent
baseline_root = evidence.parent / 'manabitan'
baseline = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
candidate = 'f7980e638ea1808701ac28339987663fd8b3dc4e'
sha = lambda data: hashlib.sha256(data).hexdigest()
archive_bytes = args.archive.read_bytes()
assert len(archive_bytes) == 33604921
assert sha(archive_bytes) == '739c895cafc5213c499dc9097a27b16a4505de7767dc6ed010fbdffe82f9c9fd'
dependencies = {}
dependency_root = baseline_root / 'dev/perf/import-memory-20261125-a7f7'
for path in sorted(dependency_root.glob('*.py')):
    relative = str(path.relative_to(baseline_root))
    data = path.read_bytes()
    assert data == subprocess.check_output(['git', 'show', baseline + ':' + relative], cwd=baseline_root)
    dependencies[relative] = sha(data)
sys.path.insert(0, str(dependency_root))
from qualification_receipts import validate_import_summary

study_root = evidence / 'compression-level-study'
study_files = {
    'dev/perf/import-compression-level-20261128-1b47.py': ('import-compression-level-20261128-1b47.py', '7fe216453d56094cb94a2504915efcbc64e08b5a3c99be25ca206b435b094d98'),
    'dev/perf/import-compression-level-20261128-1b47/compression_receipts.py': ('compression_receipts.py', '7512dd8f4422fc01fe094eb49dcccc4a3f8a80cb9dbf8fc2e37b8b00e1f68bb8'),
    'dev/perf/import-compression-level-20261128-1b47/test_compression_receipts.py': ('test_compression_receipts.py', 'ffc48b76a565eccb100fc0fa1a9f7d5f355b087bc6c6199ad2a58639ca47789d'),
}
study_hashes = {}
for relative, (local, expected) in study_files.items():
    digest = sha((study_root / local).read_bytes())
    assert digest == expected
    study_hashes[relative] = digest
sys.path.insert(0, str(study_root))
from compression_receipts import comparison_receipt, policy_manifest, require_matching_trial_receipts

args.extract.mkdir(parents=True)
inventory = []
with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
    names = archive.namelist()
    assert len(names) == len(set(names)) == 37
    for info in archive.infolist():
        path = pathlib.PurePosixPath(info.filename)
        assert not path.is_absolute() and '..' not in path.parts and not info.is_dir()
        data = archive.read(info)
        inventory.append({'path': info.filename, 'bytes': len(data), 'sha256': sha(data)})
        if not info.filename.endswith(('.zip', '.html')):
            target = args.extract / path
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    root = args.extract / 'jmdict'
    read = lambda name: json.loads((root / name).read_text())
    plan = read('registered-plan.json')
    identities = read('source-identities.json')
    browser = read('browser-identity.json')
    assert plan['baseline'] == baseline and plan['candidate'] == candidate
    assert plan['dictionary'] == 'jmdict' and plan['initialOrder'] == 'AB'
    assert plan['pairs'] == 6 and plan['flags'] == {} and len(plan['schedule']) == 20
    assert plan['storagePolicy'] == policy_manifest('jmdict')
    assert plan['studyToolingSha256'] == study_hashes
    assert plan['expectedPackageEntries'] == ['js/dictionary/zstd-term-content.js']
    assert identities['arms']['A']['sha'] == baseline
    assert identities['arms']['B']['sha'] == candidate
    for relative, expected in plan['originalToolingSha256'].items():
        data = (baseline_root / relative).read_bytes()
        assert data == subprocess.check_output(['git', 'show', baseline + ':' + relative], cwd=baseline_root)
        assert sha(data) == expected
    entries = {}
    candidate_runtime = None
    for arm in ('A', 'B'):
        package_bytes = archive.read('jmdict/package-' + arm + '.zip')
        assert sha(package_bytes) == identities['arms'][arm]['packageSha256']
        with zipfile.ZipFile(io.BytesIO(package_bytes)) as package:
            assert len(package.namelist()) == len(set(package.namelist()))
            entries[arm] = {item.filename: sha(package.read(item)) for item in package.infolist() if not item.is_dir()}
            assert entries[arm] == identities['arms'][arm]['entries']
            if arm == 'B':
                data = package.read('js/dictionary/zstd-term-content.js')
                blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
                assert blob == '9a63ef28bcf862108c407c5636eb492009ba815f'
                candidate_runtime = {'gitBlob': blob, 'sha256': sha(data), 'bytes': len(data)}
    changed = sorted(name for name in set(entries['A']) | set(entries['B']) if entries['A'].get(name) != entries['B'].get(name))
    assert changed == plan['expectedPackageEntries'] == identities['changedPackageEntries']
    report_names = sorted(name for name in names if name.endswith('/run-1.json'))
    assert report_names == ['jmdict/warmup-1-A/run-1.json', 'jmdict/warmup-1-B/run-1.json']
    assert not any('/memory/' in name or '/pair-' in name or '/control-' in name or '/exhaustive-media-' in name for name in names)
    assert 'jmdict/analysis.json' not in names
    observations = read('observations.json')
    assert len(observations) == 1
    assert all(observations[0][key] == value for key, value in plan['schedule'][0].items())
    assert plan['schedule'][:2] == [
        {'id': 'warmup-1-A', 'kind': 'warmup', 'pair': 1, 'arm': 'A'},
        {'id': 'warmup-1-B', 'kind': 'warmup', 'pair': 1, 'arm': 'B'},
    ]
    fixture = read('warmup-1-A/summary.json')['fixture']
    raw_receipts, compared_receipts, adjustments = {}, {}, {}
    for arm in ('A', 'B'):
        name = 'warmup-1-' + arm
        identity = identities['arms'][arm]
        summary = read(name + '/summary.json')
        report = read(name + '/run-1.json')
        receipt = validate_import_summary(summary, report, dictionary='jmdict', fixture=fixture,
            source_sha=identity['sha'], package_sha256=identity['packageSha256'],
            browser_version=browser['version'], import_flags=None, source_hashes=identity['sourceHashes'],
            source_dirty=False, media_check='sample')
        assert receipt == read(name + '/canonical-receipt.json')
        copied, adjustment = comparison_receipt(receipt, dictionary='jmdict', arm=arm)
        assert copied == read(name + '/comparison-receipt.json')
        assert adjustment == read(name + '/compression-storage-policy.json')
        raw_receipts[arm], compared_receipts[arm], adjustments[arm] = receipt, copied, adjustment
        if arm == 'A':
            assert observations[0]['totalImportMs'] == summary['runs'][0]['totalImportMs']
    content_delta = adjustments['B']['rawContentBytes'] - adjustments['A']['rawContentBytes']
    total_delta = adjustments['B']['rawStorageBytes'] - adjustments['A']['rawStorageBytes']
    assert content_delta == total_delta == 312404
    assert total_delta * 100 <= adjustments['A']['rawStorageBytes'] * 2
    rejection = None
    try:
        require_matching_trial_receipts(raw_receipts['A'], raw_receipts['B'], dictionary='jmdict',
                                        reference_arm='A', candidate_arm='B')
    except ValueError as error:
        rejection = {'type': type(error).__name__, 'message': str(error)}
    assert rejection == {'type': 'ValueError', 'message': 'cross-observation common differs from the required value'}

    def differences(left, right, path=''):
        if type(left) != type(right):
            return [{'path': path, 'A': left, 'B': right}]
        if isinstance(left, dict):
            result = []
            for key in sorted(set(left) | set(right)):
                if key not in left or key not in right:
                    result.append({'path': path + '.' + key, 'A': left.get(key), 'B': right.get(key)})
                else:
                    result.extend(differences(left[key], right[key], path + '.' + key))
            return result
        if isinstance(left, list):
            if len(left) != len(right):
                return [{'path': path + '.length', 'A': len(left), 'B': len(right)}]
            return [item for index, (a, b) in enumerate(zip(left, right)) for item in differences(a, b, path + '[' + str(index) + ']')]
        return [] if left == right else [{'path': path, 'A': left, 'B': right}]

    common_diff = differences(compared_receipts['A'], compared_receipts['B'])
    assert [item['path'] for item in common_diff] == ['.common.validation.outputDigestSha256']
    result = {
        'scope': 'Separate partial-failure diagnostic; existing failed trial remains failed and incomplete',
        'scriptSha256': sha(pathlib.Path(__file__).read_bytes()),
        'archive': str(args.archive), 'archiveSha256': sha(archive_bytes), 'archiveBytes': len(archive_bytes),
        'extraction': str(args.extract), 'memberCount': len(inventory), 'memberInventory': inventory,
        'baseline': baseline, 'candidate': candidate, 'registeredPlan': plan,
        'sourceIdentities': identities, 'validatorDependencies': dependencies, 'studyToolingSha256': study_hashes,
        'allActualPackageBytesAndMembersMatch': True, 'changedPackageEntries': changed,
        'candidateRuntime': candidate_runtime, 'individualRawReportsValidated': 2,
        'rawCanonicalReceiptsExact': True, 'comparisonCopiesAndAuditsExact': True,
        'recordedScheduleObservations': 1, 'measuredCandidatePairs': 0, 'identicalCodePairs': 0,
        'exhaustiveMediaObservations': 0, 'memoryObservations': 0,
        'missingPrimaryAnalysis': True, 'completeTrialAudited': False, 'completeTrialQualified': False,
        'observedContentDelta': content_delta, 'observedCompleteStorageDelta': total_delta,
        'exactPredictedDeltasAndBudgetPass': True, 'storagePolicyAudits': adjustments,
        'unchangedMatcherRejectionReproduced': rejection, 'comparisonDifferences': common_diff,
        'rawReceiptsAndPrimaryEvidenceUnchanged': True, 'newBrowserObservations': 0,
        'interpretation': 'No measured performance result or complete browser qualification. The retained digest mismatch is not normalized away; source meaning is reviewed separately.',
    }
    with args.output.open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
    print(json.dumps({key: result[key] for key in ('memberCount', 'individualRawReportsValidated',
        'measuredCandidatePairs', 'completeTrialQualified', 'exactPredictedDeltasAndBudgetPass',
        'unchangedMatcherRejectionReproduced', 'comparisonDifferences')}))
