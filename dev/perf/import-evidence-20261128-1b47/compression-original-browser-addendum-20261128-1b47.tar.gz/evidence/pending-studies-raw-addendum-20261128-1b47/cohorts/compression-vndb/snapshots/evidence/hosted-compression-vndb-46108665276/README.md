# Original compression VNDB control: gates passed; timing inconclusive

Run [46108665276](https://github.com/ManabiIO/manabitan/actions/runs/46108665276/job/140885881812) compares baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` with frozen candidate `f7980e638ea1808701ac28339987663fd8b3dc4e`. The separately reviewed complete compression auditor verifies the original archive, actual package/member maps, frozen source/policy hashes, all 20 schedule clocks, **26 raw/canonical and comparison receipts**, and **418 memory scans**. It also recomputes all 26 original storage-policy audit records and the original qualification status.

| Original primary statistic       |        Candidate B/A |   Identical code C/A |
| -------------------------------- | -------------------: | -------------------: |
| Median paired import-time change |             −1.9367% |             +1.2360% |
| Equal-work change                |             −0.8782% |             +1.2431% |
| Descriptive 95% interval         | [−5.5561%, +5.1878%] | [−0.5522%, +3.0241%] |
| Faster pairs                     |                  4/6 |                  1/2 |

All semantic/restart/media, exact storage and separate memory gates pass. VNDB's registered storage delta is **zero**, and every comparison copy equals its unmodified raw canonical receipt. Memory paired median/maximum changes are −0.6407%/−0.3606% PSS and −0.6856%/−0.3400% private sampled maxima; these are sampled maxima, not exact peaks.

The whole-import timing interval crosses zero, with all original observations retained, including the worst candidate pair at **+7.9477%**. This is a passing zero-delta control with inconclusive timing. It does not qualify the original JMdict/Jitendex trials, which stopped before measured pairs, and it is not a compression-level import speedup claim. The original policy, driver and evidence remain unchanged; any separately corrected active-corpus study is outside this cohort.

See `independent-artifact-audit.json`, `result-summary.json` and `retrieval-manifest.json`. Original artifact SHA256: `ec6a0611b77e0c250430a8410818af1244b485d7181a98c5a2b917c246d8fbb3` (35,200,454 bytes).
