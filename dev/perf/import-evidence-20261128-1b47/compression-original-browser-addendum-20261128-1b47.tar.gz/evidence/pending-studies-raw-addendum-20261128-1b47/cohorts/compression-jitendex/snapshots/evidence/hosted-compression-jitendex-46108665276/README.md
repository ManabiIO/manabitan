# Compression Jitendex: frozen trial failed before timing

Run [46108665276](https://github.com/ManabiIO/manabitan/actions/runs/46108665276/job/140885881799) compares baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` with candidate `f7980e638ea1808701ac28339987663fd8b3dc4e`. Both actual package member maps and the sole changed runtime `js/dictionary/zstd-term-content.js` match the frozen identities.

Both first warmup imports pass their individual raw validations. Content-file and total storage each increase by exactly **750,018 bytes**, within the declared 2% total-storage budget. After the original two-number comparison adjustment, only `common.validation.outputDigestSha256` differs. The unchanged matcher rejects the first B warmup with `cross-observation common differs from the required value`.

There are **two raw reports/canonical receipts**, one recorded baseline warmup, **zero measured candidate or identical-code pairs**, no exhaustive-media imports, no memory observations, and no primary analysis. The separate partial diagnostic reproduces the exact failure and retains every original byte. It does not qualify the trial or derive performance from warmups.

The same frozen diagnostic digest includes physical raw-content diagnostics; complete preimages are absent from the retained reports. No exact differing preimage or sole semantic cause is asserted. The original policy and failed comparison remain unchanged. See `partial-failure-audit.json`, `result-summary.json`, and the retained dictionary/archive-only auditor derivation. Original artifact SHA256: `62e914561bafd64dac05adcdb28faf118cde52d791b59ac6d0228b061eab5669` (33,606,454 bytes).
