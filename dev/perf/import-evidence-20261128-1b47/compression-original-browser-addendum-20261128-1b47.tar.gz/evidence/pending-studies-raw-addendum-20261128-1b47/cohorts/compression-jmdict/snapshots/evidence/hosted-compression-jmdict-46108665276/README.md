# Compression JMdict: frozen trial failed before timing

Run [46108665276](https://github.com/ManabiIO/manabitan/actions/runs/46108665276/job/140885881806) compares baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` with candidate `f7980e638ea1808701ac28339987663fd8b3dc4e`. The actual packages differ only in `js/dictionary/zstd-term-content.js`; the original archive, all members, package bytes, source identities, and frozen policy sources were verified by the separate partial-failure diagnostic.

Both first warmup imports pass their individual raw validations, including sampled lookup/readback and restart. The observed content-file and total-storage increase is exactly **312,404 bytes**, so the original exact-delta and 2% budget policy passes. Its two-number comparison copies still differ in `common.validation.outputDigestSha256`; the unchanged matcher rejects the first candidate warmup with `cross-observation common differs from the required value`.

The artifact has **two raw reports and canonical receipts**, but only the first baseline warmup was appended to the schedule log. It has **zero measured candidate pairs, zero identical-code control pairs, no exhaustive-media imports, no memory observations, and no primary analysis**. It is an incomplete failed trial, not a complete qualification result. No warmup timing is used as performance evidence.

The digest includes physical raw-content diagnostics as well as other sampled output data. The stored reports retain digest values rather than their full preimages; this audit does not identify the exact differing preimage or assert a sole semantic cause. The original policy, raw receipts, mismatch and failure remain unchanged. Any separately proposed correction is outside this trial.

See `partial-failure-audit.json` for every original member hash, actual package proof, exact raw/comparison receipts and reproduced rejection; `result-summary.json` and `retrieval-manifest.json` give the compact identity/count record. The original ZIP SHA256 is `739c895cafc5213c499dc9097a27b16a4505de7767dc6ed010fbdffe82f9c9fd` (33,604,921 bytes).
