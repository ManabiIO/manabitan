#!/usr/bin/env python3
"""Prospectively fixed, bounded-memory paired-block analysis; no acquisition."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

root = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
plan_bytes = (root / "plan.json").read_bytes()
plan = json.loads(plan_bytes)
complete = json.loads((root / "complete.json").read_text())
sha = lambda value: hashlib.sha256(value).hexdigest()
scenario_blocks = {"actual-jmdict": 24, "synthetic-uniform-zero": 144, "synthetic-all-in-range": 144}
orders = ["ABC", "BCA", "CAB", "ACB", "CBA", "BAC"]
policy = {"metric": "wallMs", "estimator": "geometricPairedPercent",
          "upper95BoundMustBeBelowPercent": 5, "comparisons": ["B/A", "B/C"],
          "scenarios": ["synthetic-uniform-zero", "synthetic-all-in-range"],
          "additionalReview": "Process CPU and identical-code-control attribution; no claim of zero overhead"}
assert complete["complete"] is True
assert complete["planSha256"] == sha(plan_bytes)
assert plan["protocol"] == "actual-record-encoder-score-cache-repeat-20261128-1b47-v2-common144"
assert plan["repeats"] == 4
assert plan["scenarioBlocks"] == scenario_blocks
assert plan["commonPathPolicy"] == policy
assert plan["scenarios"] == list(scenario_blocks)
assert plan["scripts"]["analysis"]["sha256"] == sha(Path(__file__).read_bytes())
for scenario, count in scenario_blocks.items():
    assert plan["scenarioOrders"][scenario] == orders * (count // 6)

resamples = 100000
batch_size = 2500
report = {"scope": "Record-encoder component only; independent scenario results, no pooled estimates",
          "planSha256": sha(plan_bytes), "seed": 20261128, "generator": "NumPy PCG64",
          "numpyVersion": np.__version__, "resamples": resamples, "bootstrapBatchSize": batch_size,
          "scenarioBlocks": scenario_blocks,
          "interval": "Paired-block percentile 95%; linear quantiles; all declared blocks retained",
          "scenarios": {}}
for scenario, count in scenario_blocks.items():
    raw = json.loads((root / f"{scenario}.json").read_text())
    assert raw["complete"] is True and raw["blocks"] == count
    assert len(raw["observations"]) == count
    assert [row["block"] for row in raw["observations"]] == list(range(count))
    assert [row["order"] for row in raw["observations"]] == plan["scenarioOrders"][scenario]
    values = {metric: {arm: np.array([row["values"][arm][metric] for row in raw["observations"]])
                      for arm in "ABC"} for metric in ("wallMs", "cpuTotalMs")}
    assert all(np.all(array > 0) for metric in values.values() for array in metric.values())
    ratios = {}
    logs = {}
    boot = {}
    for metric in values:
        for numerator, denominator in (("B", "A"), ("B", "C"), ("C", "A")):
            key = (metric, f"{numerator}/{denominator}")
            ratios[key] = values[metric][numerator] / values[metric][denominator]
            logs[key] = np.log(ratios[key])
            boot[key] = {"median": np.empty(resamples), "geometric": np.empty(resamples)}
    generator = np.random.Generator(np.random.PCG64(20261128))
    index_hash = hashlib.sha256()
    for start in range(0, resamples, batch_size):
        end = min(start + batch_size, resamples)
        indices = generator.integers(0, count, size=(end - start, count))
        index_hash.update(indices.tobytes())
        for key in ratios:
            boot[key]["median"][start:end] = (np.median(ratios[key][indices], axis=1) - 1) * 100
            boot[key]["geometric"][start:end] = np.expm1(logs[key][indices].mean(axis=1)) * 100
    result = {"blocks": count, "pairedIndexMatrixSha256": index_hash.hexdigest()}
    for metric in values:
        comparisons = {}
        for numerator, denominator in (("B", "A"), ("B", "C"), ("C", "A")):
            label = f"{numerator}/{denominator}"
            key = (metric, label)
            comparisons[label] = {
                "medianPairedPercent": float((np.median(ratios[key]) - 1) * 100),
                "median95Interval": np.quantile(boot[key]["median"], [0.025, 0.975], method="linear").tolist(),
                "geometricPairedPercent": float(np.expm1(logs[key].mean()) * 100),
                "geometric95Interval": np.quantile(boot[key]["geometric"], [0.025, 0.975], method="linear").tolist(),
                "fasterBlocks": int((ratios[key] < 1).sum()),
            }
        result[metric] = {"armMedianMsPerCorpus": {arm: float(np.median(array) / 4)
                                                  for arm, array in values[metric].items()},
                          "comparisons": comparisons}
    report["scenarios"][scenario] = result

checks = []
for scenario in policy["scenarios"]:
    for comparison in policy["comparisons"]:
        upper = report["scenarios"][scenario]["wallMs"]["comparisons"][comparison]["geometric95Interval"][1]
        checks.append({"scenario": scenario, "comparison": comparison, "upper95Percent": upper,
                       "passesDeclaredWallBound": upper < policy["upper95BoundMustBeBelowPercent"]})
report["commonPathQualification"] = {"policy": policy, "checks": checks,
    "passesAllDeclaredWallBounds": all(check["passesDeclaredWallBound"] for check in checks),
    "additionalReviewRequired": "CPU and same-code controls; actual JMdict gain; not zero overhead or import non-regression"}
with output.open("x") as stream:
    json.dump(report, stream, indent=2)
    stream.write("\n")
print(json.dumps(report, indent=2))
