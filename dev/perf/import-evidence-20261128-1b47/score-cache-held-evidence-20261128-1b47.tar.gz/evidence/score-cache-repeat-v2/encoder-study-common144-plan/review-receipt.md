# Pre-acquisition review

Root, import_architecture and prior_work_audit independently approved registered
plan `f8dabb543aca5a71cdd601d1041a066bb137391d076eb3d396eaca4be1953127`
before any acquisition. The original unstarted 24-block v2 plan remains unchanged
and has an explicit supersession receipt.

Reviews checked independent 24/144/144 scenarios, complete balanced six-order
cycles, four whole corpora per observation, actual factory/backing/alias input
reconstruction, full original encoder/output-retention endpoint, all exact
outputs and input immutability, source/runtime/script identity checks, strict
no-flags policy, and first-failure retention. The deterministic bounded bootstrap
uses per-scenario counts and the same paired indices for all comparisons/metrics.
Toy preflight checks confirm exact agreement with unbatched indices/statistics.

Common-path qualification is prospectively limited to the upper descriptive
95% geometric wall-time bound being below +5% for both A/C comparisons in each
common control. CPU and same-code attribution require separate review. This is
not zero-overhead or whole-import qualification.

Frozen script SHA256 values:

- screen.mjs: `9efeb34b543b08d796c61a1e77e83060a6906fdd6d95606638558a490fc0fdbc`
- analyze.py: `d41c4885fe82314d9f413bfc9292d9cf574b63c2d27409781cd726e7460a8a17`
- protocol.md: `a562d3d9b659e6148b41914a0b980f50d093b35b90534b835af13e24629c2f66`
- review-diff.patch: `fd2bd9d5bea8f08863a222a5924e67e8b0ec748728b0b5ecae0240e71403dce8`

The CPU slot was released to benchmark_setup. No other local test/census/timing
job in this team is active. This is one fixed acquisition, with no source or
slot-size changes and no replacement cohort after its outcome.
