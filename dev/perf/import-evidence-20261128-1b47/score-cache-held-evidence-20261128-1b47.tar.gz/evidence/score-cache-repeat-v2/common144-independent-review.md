# Prospective common144 protocol review

Reviewed before any v2 observation, against registered plan SHA-256 `f8dabb543aca5a71cdd601d1041a066bb137391d076eb3d396eaca4be1953127`.

The expansion is reasonable for a component review. The two synthetic common-score scenarios had broad v1 intervals; a fixed larger cohort addresses that concrete uncertainty. At their observed approximately 4.7–5.0 ms per 528,299-row synthetic corpus, the declared +5% tolerance corresponds to approximately 0.23–0.25 ms. This is proportionate to the roughly 3 ms actual-input v1 encoder saving. It is not a claim of zero overhead or of actual VNDB/Jitendex behavior.

The amended code and registered plan agree on 24 actual-JMdict blocks and 144 blocks for each common scenario. Each six-order cycle balances all arm positions; this gives 8 and 48 appearances per position respectively. Every observation still executes four complete input corpora, with the same output retention, timers, input/output oracles and source identities. Per-corpus medians divide by four, independently of block count.

The analyzer verifies each scenario's own count, contiguous block indexes and declared order. It uses the same sampled index stream across comparisons within a scenario. Bounded resample batches retain the stream and statistic definitions; the supplied toy preflight checks both sizes. All four common comparisons require a strict geometric wall-time upper 95% bound below +5%. CPU and identical-code attribution remain an additional review; passing the wall bound alone is not promotion.

The original 24-block v2 plan remains unchanged and explicitly superseded before acquisition. At review, its directory contained only the plan and superseded receipt; the amended directory contained only the new plan. No observations or acquisition markers existed. Source/runtime refinement, input data, timing boundary and v1 observations remain frozen. No further extension or retry is recommended if this fixed cohort is inconclusive.

No correctness or arithmetic blocker found. Setup owns acquisition; this review did not execute tests or benchmark observations.
