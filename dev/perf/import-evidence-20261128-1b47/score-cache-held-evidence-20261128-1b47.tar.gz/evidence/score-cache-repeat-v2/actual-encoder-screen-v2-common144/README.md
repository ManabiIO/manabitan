# Score-cache v2: completed component study; stop without a PR

Frozen plan: `f8dabb543aca5a71cdd601d1041a066bb137391d076eb3d396eaca4be1953127`. Candidate commit `5565f279a12a6f99bc1719b9dbe9246f30624098`; runtime SHA-256 `7f4dbeb8447a0d2797b636cfcd5746a4c9c3b27df2f5b1526ff6b8fd7aa90871`. Baseline is `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.

## Decision

Stop this mechanism. The warm JMdict complete-encoder component improves versus both independently loaded identical baselines, but all four prospectively required common-path upper bounds fail. The all-in-range wall-time intervals are positive against both baselines. No first-use study, actual Jitendex capture, optional full unit/build gates, source refinement, replacement cohort or runtime PR follows this result.

## Fixed method and correctness

The original private factory inputs were captured once in an unchanged full JMdict public-sink replay: 12 calls, 528,299 rows, exact nonsequential references, all view layouts and complete backing aliases. Replays use each module’s own provenance factory. All complete returned fields, input backings and frozen identities passed. Each timed observation includes four complete encoder corpora, fresh score maps/caches, full allocation and all writes; setup, factory construction, counters and output hashing remain outside the timer. Outputs stay live until timing and process CPU stop. No altered V8 flags, NODE_OPTIONS, explicit GC, excluded observations or adaptive replacements were used.

The actual scenario has 24 balanced blocks; each independent synthetic common-score scenario has 144. Six arm orders repeat evenly. A/C use identical source in separate modules. All schedules completed. The 100,000 paired-block bootstrap uses the prospectively frozen PCG64 seed 20261128 and linear percentile intervals; the same resamples apply to wall, CPU and all comparisons within a scenario. These are descriptive component intervals, with no cross-scenario pooling.

| Scenario | Blocks | Median A/B/C ms per corpus | Geometric wall B/A [95%] | Geometric wall B/C [95%] | Identical C/A [95%] |
| --- | ---: | --- | --- | --- | --- |
| actual-jmdict | 24 | 12.018 / 8.337 / 11.248 | -27.664% [-34.124%, -20.139%] | -25.438% [-34.564%, -14.531%] | -2.986% [-13.449%, +9.209%] |
| synthetic-uniform-zero | 144 | 4.844 / 4.935 / 4.745 | +2.486% [-2.400%, +7.394%] | +4.960% [+0.224%, +9.995%] | -2.358% [-6.779%, +2.268%] |
| synthetic-all-in-range | 144 | 4.850 / 5.044 / 4.824 | +5.240% [+1.159%, +9.384%] | +5.686% [+1.905%, +9.621%] | -0.423% [-4.278%, +3.522%] |

## Prospective common-path gate

Each geometric wall-time upper 95% bound had to be strictly below +5% against both A and C in both common scenarios. This margin was fixed before any v2 observations and did not imply zero overhead.

| Scenario | Comparison | Upper 95% bound | Required | Result |
| --- | --- | ---: | --- | --- |
| synthetic-uniform-zero | B/A | +7.393928% | < +5% | FAIL |
| synthetic-uniform-zero | B/C | +9.995471% | < +5% | FAIL |
| synthetic-all-in-range | B/A | +9.384428% | < +5% | FAIL |
| synthetic-all-in-range | B/C | +9.620668% | < +5% | FAIL |

## Process CPU and identical-code attribution

| Scenario | Geometric CPU B/A [95%] | Geometric CPU B/C [95%] | Identical CPU C/A [95%] |
| --- | --- | --- | --- |
| actual-jmdict | -26.860% [-36.154%, -15.761%] | -22.270% [-33.729%, -8.673%] | -5.906% [-16.493%, +7.126%] |
| synthetic-uniform-zero | +1.484% [-5.504%, +8.900%] | +4.951% [-1.952%, +12.502%] | -3.303% [-9.548%, +3.362%] |
| synthetic-all-in-range | +4.835% [-1.621%, +11.630%] | +5.516% [-0.441%, +11.812%] | -0.645% [-6.870%, +5.999%] |

The actual JMdict saving is consistent in CPU and wall time: 22/24 and 21/24 wall comparisons favor B, with about 2.9–3.7 ms lower arm medians. Exact Map reads fall from 269,193 to 7,676; v1 used 6,223. This is a real warm encoder observation, retained even though the candidate is held.

The uniform-zero wall comparison to C is positive while its CPU intervals remain broad. For all-in-range inputs, paired CPU medians are +4.563% versus A and +3.479% versus C, with median intervals above zero; geometric CPU intervals still cross zero. Wall C/A control intervals cross zero in both common scenarios. The combined evidence does not meet the declared common-path review margin and does not justify claiming no common-score overhead. These synthetic scenarios retain JMdict’s reference layout; they are not actual Jitendex or VNDB timings.

## Preservation and unexecuted work

All original v1 results remain separate. The first v2 24/24/24 registration was superseded before acquisition and has no marker or observations; the supersession receipt binds both plan hashes. The conditional `../first-use-design.md` remains design only: no implementation and zero observations because its prerequisite failed. Correctness evidence (87 focused tests plus scoped lint and types) remains in `../frozen-manifest.json`; optional full unit/build validation was never started.

Primary files: `plan.json`, `observations.jsonl`, per-scenario raw reports and warmups, `complete.json`, `bootstrap-analysis.json`, `../encoder-study-common144-plan`, `../v2-common144-registration.json`, and `../disposition.json`. All captured actual backing and expected field bytes are shared once under `../../score-cache/actual-encoder-inputs`.
