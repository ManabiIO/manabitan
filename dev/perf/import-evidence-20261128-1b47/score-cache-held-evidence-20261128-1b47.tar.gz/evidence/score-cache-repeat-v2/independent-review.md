# Independent read-only review of repeat-admitted score caching

Reviewed the v2 runtime diff and targeted tests against frozen v1
`bf44285cd06b1a4a832921c3669a2ca1659a9a76`. No source edits, tests, builds or
measurements were performed for this review.

No correctness blocker was found. All new cache operations now stay in the
eligible outlier branch. A cache miss consults the authoritative Map and only
an existing score index can enter the cache. The original new-score insertion
block, first-use order and common-score table remain unchanged. Full Int32 tags
prevent slot collisions from producing false hits; zero still denotes an empty
Uint16 index-plus-one entry.

The largest possible cached index, 65,534, becomes 65,535 without overflow.
The existing reserved-score-count fallback remains after the scan; a new index
of 65,535 still triggers the original early legacy decision before insertion.
The added repeated-last-key fixtures at 65,534 and 65,535 distinct scores cover
these cases. The revised all-slot fixture repeats both score sets, so it still
causes actual eviction under the new admission policy. The first-use collision
case checks that one-time values do not displace a cached repeated value.

The allocation observer proxies the Int32Array constructor while preserving
its prototype and real typed storage. It therefore appears compatible with the
existing private-column guard and meaningfully distinguishes common, unique
outlier and repeated outlier inputs. Execution and TypeScript/lint validation
remain separate pending gates.

The stated bound on extra Map reads relative to v1 is defensible: after a
repeated access both policies select that score in the slot; only a subsequent
first-use value can make v1 hold a value v2 has never admitted. An additional v2
lookup can therefore occur at most once for each distinct score's first repeat.
Avoided first-use pollution may offset those reads.

Removing the per-row refill sentinel and trailing cache-write condition is a
plausible response to v1's unresolved common-score overhead. It does not prove
zero runtime regression: the compiled loop still differs from baseline, so the
registered actual-input and separate common-score controls remain necessary.
