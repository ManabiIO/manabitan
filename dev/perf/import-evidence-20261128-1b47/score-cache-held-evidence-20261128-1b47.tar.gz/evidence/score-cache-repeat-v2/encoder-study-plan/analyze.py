#!/usr/bin/env python3
"""Fixed, paired-block analysis. This never acquires new observations."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

root = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
plan_bytes = (root / "plan.json").read_bytes()
plan = json.loads(plan_bytes)
complete = json.loads((root / "complete.json").read_text())
sha = lambda value: hashlib.sha256(value).hexdigest()
assert complete["complete"] is True
assert complete["planSha256"] == sha(plan_bytes)
assert plan["blocks"] == 24 and plan["repeats"] == 4
assert plan["scripts"]["analysis"]["sha256"] == sha(Path(__file__).read_bytes())
assert plan["orders"] == ["ABC", "BCA", "CAB", "ACB", "CBA", "BAC"] * 4
indices = np.random.Generator(np.random.PCG64(20261128)).integers(0, 24, size=(100000, 24))
report = {"scope": "Record-encoder component only; independent scenario results, no pooled estimates",
          "planSha256": sha(plan_bytes), "seed": 20261128, "generator": "NumPy PCG64",
          "numpyVersion": np.__version__, "resamples": 100000, "blocks": 24,
          "interval": "Paired-block percentile 95%; linear quantiles; all blocks retained",
          "scenarios": {}}
for scenario in plan["scenarios"]:
    raw = json.loads((root / f"{scenario}.json").read_text())
    assert raw["complete"] is True and len(raw["observations"]) == 24
    assert [row["order"] for row in raw["observations"]] == plan["orders"]
    result = {}
    for metric in ("wallMs", "cpuTotalMs"):
        values = {arm: np.array([row["values"][arm][metric] for row in raw["observations"]])
                  for arm in "ABC"}
        assert all(np.all(array > 0) for array in values.values())
        comparisons = {}
        for numerator, denominator in (("B", "A"), ("B", "C"), ("C", "A")):
            ratios = values[numerator] / values[denominator]
            logs = np.log(ratios)
            sampled_ratios = ratios[indices]
            medians = (np.median(sampled_ratios, axis=1) - 1) * 100
            geometric = np.expm1(logs[indices].mean(axis=1)) * 100
            comparisons[f"{numerator}/{denominator}"] = {
                "medianPairedPercent": float((np.median(ratios) - 1) * 100),
                "median95Interval": np.quantile(medians, [0.025, 0.975], method="linear").tolist(),
                "geometricPairedPercent": float(np.expm1(logs.mean()) * 100),
                "geometric95Interval": np.quantile(geometric, [0.025, 0.975], method="linear").tolist(),
                "fasterBlocks": int((ratios < 1).sum()),
            }
        result[metric] = {"armMedianMsPerCorpus": {arm: float(np.median(array) / 4)
                                                  for arm, array in values.items()},
                          "comparisons": comparisons}
    report["scenarios"][scenario] = result
with output.open("x") as stream:
    json.dump(report, stream, indent=2)
    stream.write("\n")
print(json.dumps(report, indent=2))
