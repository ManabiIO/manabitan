# Actual record-encoder component screen

This is a separate prospective v2 component study of the frozen repeat-only score-cache candidate
`5565f279a12a6f99bc1719b9dbe9246f30624098` against baseline
`9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. It is not a browser import benchmark.
The completed comma confirmation and completed score-cache v1 study remain separate and unpooled.

## Source refinement and fixed scope

V1's actual encoder saving was accompanied by unresolved small common-score
control cost. This separate source revision removes cache-slot initialization
and the final cache-update guard from common rows. Cache admission is confined
to the outlier branch, only after an authoritative Map hit; allocation is delayed
to the first repeated outlier. The slot count and input admission gate are fixed.
An independent untimed actual-input census observes 7,676 Map reads with every
original field byte and backing unchanged. No slot-size search, altered timing
boundary or replacement of v1 observations is permitted. This is one new fixed
study; no gain or non-regression result is presumed before acquisition.

## Input and correctness boundary

One untimed unchanged-baseline public-sink replay captures every actual call to
`_encodeArtifactRecordFields` for pinned JMdict. It retains producer factory
object identity, own data descriptors, private Int32 score and resolved-reference
types, original view offsets and complete backing bytes, alias groups, fallback
columns, content offset base and returned fields. Unexpected slices, shared or
external inputs fail capture; none are silently converted into eligible inputs.
All 12 groups and 528,299 rows, canonical source digest and every persisted file
must match the prior frozen baseline. This includes the actual nonsequential
row-to-unique references, not references reconstructed from encoded fields.

Each arm recreates captured backing stores and views outside timing and uses its
own module-local production factory. The whole original encoder method is timed,
including fresh authoritative score maps, lazy caches, scratch arrays and final
field-buffer allocation/writes. There is no source instrumentation in measured
calls. Input construction, checks, hashing, report writes and counters are outside
timing. A and C use identical baseline source in independent module instances;
B changes only the frozen record-store source. All imports resolve to the same
identity-bound baseline runtime. The frozen source/runtime and all input bytes
are checked before and after acquisition.

Before timing, exact returned fields must match the capture for all arms. A
temporarily installed and immediately restored Map.get counter observes one
untimed correctness call per input/arm. Expected corpus counts are 269,193 for
A/C and 7,676 for B. Origin proof uses WeakMap; no other ordinary Map.get calls
occur in this synchronous encoder. All full input backing bytes must remain
unchanged after correctness, warmups and each measured observation.

## Fixed acquisition

Three separately reported input scenarios run in this fixed order:

1. Actual captured JMdict inputs, unchanged.
2. Synthetic uniform-zero scores on cloned actual reference layouts and row
   counts. This tests the common-score branch; it is not a VNDB measurement.
3. Synthetic all-in-range scores `(rowIndex % 512) - 256` on those layouts.

The synthetic scenarios keep actual reference layouts but explicitly change
scores. Their A/B/C output bytes must match one another and their Map.get counts
must all be zero. They are never pooled with actual JMdict.

Each scenario has two excluded warmup blocks, in ABC and CBA order, then 24
measured blocks: four cycles of ABC, BCA, CAB, ACB, CBA, BAC. Each observation runs
four complete input corpora. Every original encoder result is retained until
the observation timer and process CPU counter stop, then checked byte-for-byte.
All returned bytes and full input backings are checked outside the timer. Thus
allocation remains in the endpoint, while correctness work is excluded. No
explicit GC or altered V8 flags are used. Child/process isolation is unnecessary
for this small JS-only component; each arm has an independent source module and
private factory origin map in the same process.

Report all raw wall and process CPU observations, per-corpus arm medians, paired
median and geometric changes for B/A, B/C and same-code C/A, plus fixed-seed 95%
paired-block bootstrap intervals (100,000 resamples, NumPy PCG64 seed 20261128,
linear percentile endpoints, one shared index matrix across comparisons). All 24
blocks are retained; no outlier removal or adaptive stopping.

A source/output/admission mismatch, exception or process failure stops the
study. The exclusive acquisition marker forbids replacements. Failures and
partial observations remain. No pooled reruns or automatic promotion from a
point estimate: a useful effect must beat both baselines, exceed the same-code
noise and have no unresolved common-score regression. This measures the encoder
alone; any later full-sink/browser qualification is a new study.
