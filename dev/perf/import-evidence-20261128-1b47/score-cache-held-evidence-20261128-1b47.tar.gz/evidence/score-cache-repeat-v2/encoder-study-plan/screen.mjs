/* SPDX-License-Identifier: GPL-3.0-or-later */
// Actual complete record-encoder component. No product source modifications.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {appendFile, mkdir, readFile, writeFile} from 'node:fs/promises';
import {resolve, join, dirname} from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {identity, requireIdentity, git, BASELINE} from '../../native-child-screen-1b47-v2/protocol.mjs';

const PROTOCOL = 'actual-record-encoder-score-cache-repeat-20261128-1b47-v2';
const CANDIDATE = '5565f279a12a6f99bc1719b9dbe9246f30624098';
const SOURCE = 'ext/js/dictionary/term-record-opfs-store.js';
const CANDIDATE_SOURCE_SHA256 = '7f4dbeb8447a0d2797b636cfcd5746a4c9c3b27df2f5b1526ff6b8fd7aa90871';
const ORDERS = ['ABC', 'BCA', 'CAB', 'ACB', 'CBA', 'BAC'];
const SCENARIOS = ['actual-jmdict', 'synthetic-uniform-zero', 'synthetic-all-in-range'];
const REPEATS = 4;
const BLOCKS = 24;
const HERE = dirname(fileURLToPath(import.meta.url));
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const json = (value) => JSON.stringify(value, null, 2) + '\n';
const scripts = {
    screen: fileURLToPath(import.meta.url),
    protocol: join(HERE, 'protocol.md'),
    analysis: join(HERE, 'analyze.py'),
    capture: resolve(HERE, '../../node-score-encoder-input-capture.mjs'),
    identity: resolve(HERE, '../../native-child-screen-1b47-v2/protocol.mjs'),
};
async function scriptHashes() {
    return Object.fromEntries(await Promise.all(Object.entries(scripts).map(async ([name, path]) =>
        [name, {path, sha256: sha(await readFile(path))}])));
}
async function candidateIdentity(root) {
    assert.equal(git(root, 'rev-parse', 'HEAD'), CANDIDATE);
    assert.equal(git(root, 'diff', '--no-ext-diff', 'HEAD', '--'), '', 'Candidate tracked edits');
    assert.deepEqual(git(root, 'diff', '--name-only', BASELINE, 'HEAD').split('\n').sort(),
        [SOURCE, 'test/term-record-score-cache.test.js']);
    const bytes = await readFile(join(root, SOURCE));
    assert.equal(sha(bytes), CANDIDATE_SOURCE_SHA256);
    return {root, commit: CANDIDATE, sourceSha256: sha(bytes), sourceBytes: bytes.byteLength};
}
function checkCapture(manifest, baseline) {
    assert.equal(manifest.complete, true);
    assert.equal(manifest.failure, null);
    assert.equal(manifest.sourceCommit, BASELINE);
    assert.deepEqual(manifest.frozenBaselineIdentity, baseline);
    assert.equal(manifest.rows, 528299);
    assert.equal(manifest.inputs.length, 12);
    assert.equal(manifest.fixture.sha256, '3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f');
    assert.equal(manifest.sourceDigestSha256, 'e61445478202dbbda9c22d91a5bc51e87b6b77ce0096898a37aad149cefa0400');
    assert.equal(manifest.filesDigestSha256, 'b9200f034c262f240ab55c1598c3c8a9703122c4495c1379deac06d6c80ac5f8');
    assert.equal(manifest.totalPersistedBytes, 43315677);
    assert.equal(manifest.inputs.reduce((sum, input) => sum + input.rowCount, 0), 528299);
    assert.equal(manifest.inputs.reduce((sum, input) => sum + input.mapReads, 0), 269193);
    for (const input of manifest.inputs) {
        assert.equal(input.chunkPrototype, 'Object.prototype');
        assert.equal(input.referencesPrototype, 'Object.prototype');
        assert.equal(input.provenance.selectedResolvedPath, true);
        assert.equal(input.provenance.sameEncoderObject, true);
        assert.equal(input.provenance.sameReferencesObject, true);
        assert.equal(input.provenance.rowCount, input.rowCount);
        for (const descriptor of [input.rowCountDescriptor, input.referencesDescriptor,
            ...Object.values(input.columns).map(({descriptor}) => descriptor).filter(Boolean)]) {
            assert.equal(descriptor.present, true);
            for (const key of ['writable', 'enumerable', 'configurable']) { assert.equal(descriptor[key], true); }
        }
        for (const column of Object.values(input.columns)) {
            for (const key of ['hasOwnLength', 'hasOwnBuffer', 'hasOwnByteOffset', 'hasOwnByteLength']) {
                assert.equal(column[key], false);
            }
        }
        assert.equal(input.columns.scoreList.constructor, 'Int32Array');
        assert.equal(input.columns.uniqueIndexList.constructor, 'Uint32Array');
        assert.equal(input.columns.offsets.constructor, 'Float64Array');
        assert.equal(input.columns.lengths.constructor, 'Uint32Array');
        assert.equal(input.columns.contentOffsets.constructor, 'Float64Array');
        assert.equal(input.columns.contentLengths.constructor, 'Uint32Array');
    }
}
async function loadBytes(directory, manifest) {
    const inputs = [];
    for (const input of manifest.inputs) {
        const buffers = [];
        for (const buffer of input.buffers) {
            assert.equal(buffer.kind, 'ArrayBuffer');
            assert.equal(buffer.resizable, false);
            assert.equal(buffer.maxByteLength, buffer.byteLength);
            const bytes = await readFile(join(directory, buffer.file));
            assert.equal(bytes.byteLength, buffer.byteLength);
            assert.equal(sha(bytes), buffer.sha256);
            buffers.push(new Uint8Array(bytes));
        }
        const output = await readFile(join(directory, input.output.file));
        assert.equal(output.byteLength, input.output.byteLength);
        assert.equal(sha(output), input.output.sha256);
        inputs.push({metadata: input, buffers, output: new Uint8Array(output)});
    }
    return inputs;
}
function reconstruct(input, factory, scenario) {
    const {metadata} = input;
    const backings = input.buffers.map((bytes) => bytes.slice().buffer);
    const values = {};
    const constructors = {Int32Array, Uint32Array, Float64Array};
    for (const [name, column] of Object.entries(metadata.columns)) {
        const Constructor = constructors[column.constructor];
        assert(Constructor);
        const value = new Constructor(backings[column.bufferId], column.byteOffset, column.length);
        assert.equal(value.byteLength, column.byteLength);
        assert.equal(sha(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)), column.viewSha256);
        values[name] = value;
    }
    if (scenario === 'synthetic-uniform-zero') { values.scoreList.fill(0); }
    if (scenario === 'synthetic-all-in-range') {
        for (let row = 0; row < values.scoreList.length; ++row) { values.scoreList[row] = (row % 512) - 256; }
    }
    const seed = {rowCount: metadata.rowCount, scoreList: values.scoreList};
    for (const key of ['fixedContentOffsetBase', 'fixedContentLength']) {
        const descriptor = metadata[key];
        if (descriptor.present) {
            Object.defineProperty(seed, key, {value: descriptor.value,
                writable: descriptor.writable, enumerable: descriptor.enumerable, configurable: descriptor.configurable});
        }
    }
    const chunk = factory(seed, values.uniqueIndexList, values.offsets, values.lengths);
    assert.equal(chunk.scoreList, values.scoreList);
    assert.equal(chunk.resolvedContentReferences.uniqueIndexList, values.uniqueIndexList);
    return {chunk, contentOffsets: values.contentOffsets, contentLengths: values.contentLengths,
        contentOffsetBase: metadata.contentOffsetBase, backings,
        backingHashes: backings.map((buffer) => sha(new Uint8Array(buffer))),
        expected: scenario === 'actual-jmdict' ? input.output : null};
}
function requireUnchanged(inputs) {
    for (const input of inputs) {
        for (let index = 0; index < input.backings.length; ++index) {
            assert.equal(sha(new Uint8Array(input.backings[index])), input.backingHashes[index]);
        }
    }
}
function runEncode(encode, input) {
    return encode(input.chunk, input.contentOffsets, input.contentLengths, input.contentOffsetBase);
}
function requireEqual(actual, expected) {
    assert.equal(actual.byteLength, expected.byteLength);
    assert.equal(Buffer.compare(Buffer.from(actual.buffer, actual.byteOffset, actual.byteLength),
        Buffer.from(expected.buffer, expected.byteOffset, expected.byteLength)), 0);
}
function median(values) {
    const sorted = [...values].sort((a, b) => a - b);
    return (sorted[(sorted.length - 1) >> 1] + sorted[sorted.length >> 1]) / 2;
}
function summarize(observations) {
    const result = {};
    for (const metric of ['wallMs', 'cpuTotalMs']) {
        const arms = Object.fromEntries(['A', 'B', 'C'].map((arm) =>
            [arm, median(observations.map((row) => row.values[arm][metric])) / REPEATS]));
        const comparisons = {};
        for (const [numerator, denominator] of [['B', 'A'], ['B', 'C'], ['C', 'A']]) {
            const ratios = observations.map((row) => row.values[numerator][metric] / row.values[denominator][metric]);
            comparisons[numerator + '/' + denominator] = {
                medianPairedPercent: (median(ratios) - 1) * 100,
                geometricPairedPercent: (Math.exp(ratios.reduce((sum, ratio) => sum + Math.log(ratio), 0) / ratios.length) - 1) * 100,
                fasterBlocks: ratios.filter((ratio) => ratio < 1).length,
            };
        }
        result[metric] = {armMedianPerCorpus: arms, comparisons};
    }
    return result;
}

const [mode, ...args] = process.argv.slice(2);
if (mode === 'register') {
    assert.deepEqual(process.execArgv, [], 'No altered V8 flags are admitted');
    assert.equal(process.env.NODE_OPTIONS, undefined, 'NODE_OPTIONS must be absent');
    assert.equal(args.length, 4, 'register BASELINE CANDIDATE CAPTURE OUTPUT');
    const [baselinePath, candidatePath, capturePath, outputPath] = args.map((path) => resolve(path));
    const baseline = await identity(baselinePath, true);
    assert.equal(baseline.commit, BASELINE);
    const candidate = await candidateIdentity(candidatePath);
    const manifestBytes = await readFile(join(capturePath, 'manifest.json'));
    const manifest = JSON.parse(manifestBytes);
    checkCapture(manifest, baseline);
    await loadBytes(capturePath, manifest);
    const hashes = await scriptHashes();
    assert.equal(manifest.helperSha256, hashes.capture.sha256);
    const plan = {protocol: PROTOCOL, registeredAt: new Date().toISOString(),
        baseline, candidate, capturePath, captureManifestSha256: sha(manifestBytes), scripts: hashes,
        scenarios: SCENARIOS, repeats: REPEATS, blocks: BLOCKS,
        warmupOrders: ['ABC', 'CBA'], orders: Array.from({length: BLOCKS}, (_, index) => ORDERS[index % 6]),
        expectedActualMapReads: {A: 269193, B: 7676, C: 269193}, expectedControlMapReads: 0,
        node: process.version, versions: process.versions, execArgv: process.execArgv, nodeOptions: null,
        decision: 'Component only; retain all blocks and first failure; no retries/replacements or pooling; gain must beat both identical baselines without unresolved common-score regression.',
    };
    await mkdir(outputPath, {recursive: false});
    await writeFile(join(outputPath, 'plan.json'), json(plan), {flag: 'wx'});
    console.log(json({registered: true, outputPath, planSha256: sha(json(plan))}));
} else if (mode === 'run') {
    assert.equal(args.length, 1, 'run OUTPUT');
    const outputPath = resolve(args[0]);
    const planBytes = await readFile(join(outputPath, 'plan.json'));
    const plan = JSON.parse(planBytes);
    await writeFile(join(outputPath, 'acquisition-start.json'), json({startedAt: new Date().toISOString(),
        planSha256: sha(planBytes), pid: process.pid, node: process.version, execArgv: process.execArgv}), {flag: 'wx'});
    const scenarioReports = [];
    try {
        assert.deepEqual(process.execArgv, [], 'No altered V8 flags are admitted');
        assert.equal(process.env.NODE_OPTIONS, undefined, 'NODE_OPTIONS must be absent');
        assert.equal(plan.nodeOptions, null);
        assert.equal(plan.protocol, PROTOCOL);
        assert.equal(plan.node, process.version);
        assert.deepEqual(plan.execArgv, process.execArgv);
        assert.equal(plan.repeats, REPEATS);
        assert.equal(plan.blocks, BLOCKS);
        assert.deepEqual(plan.scenarios, SCENARIOS);
        assert.deepEqual(plan.warmupOrders, ['ABC', 'CBA']);
        assert.deepEqual(plan.orders, Array.from({length: BLOCKS}, (_, index) => ORDERS[index % 6]));
        assert.deepEqual(plan.expectedActualMapReads, {A: 269193, B: 7676, C: 269193});
        assert.equal(plan.expectedControlMapReads, 0);
        assert.deepEqual(await scriptHashes(), plan.scripts);
        await requireIdentity(plan.baseline);
        assert.equal(plan.baseline.commit, BASELINE);
        assert.deepEqual(await candidateIdentity(plan.candidate.root), plan.candidate);
        const manifestBytes = await readFile(join(plan.capturePath, 'manifest.json'));
        assert.equal(sha(manifestBytes), plan.captureManifestSha256);
        const manifest = JSON.parse(manifestBytes);
        checkCapture(manifest, plan.baseline);
        const captured = await loadBytes(plan.capturePath, manifest);
        const sourceA = await readFile(join(plan.baseline.root, SOURCE), 'utf8');
        const sourceB = await readFile(join(plan.candidate.root, SOURCE), 'utf8');
        const originalURL = pathToFileURL(join(plan.baseline.root, SOURCE));
        const moduleDirectory = join(outputPath, 'modules');
        await mkdir(moduleDirectory, {recursive: false});
        const arms = {};
        const moduleHashes = {};
        for (const arm of ['A', 'B', 'C']) {
            const source = arm === 'B' ? sourceB : sourceA;
            const rebased = source.replace(/(from\s+)(['"])(\.[^'"]+)\2/g,
                (_match, prefix, quote, specifier) => `${prefix}${quote}${new URL(specifier, originalURL).href}${quote}`);
            const path = join(moduleDirectory, arm + '.mjs');
            await writeFile(path, rebased, {flag: 'wx'});
            moduleHashes[arm] = sha(rebased);
            const module = await import(pathToFileURL(path));
            const store = new module.TermRecordOpfsStore();
            arms[arm] = {factory: module.createArtifactTermRecordChunkWithResolvedContent,
                encode: store._encodeArtifactRecordFields.bind(store)};
        }
        assert.equal(moduleHashes.A, moduleHashes.C);
        assert.notEqual(moduleHashes.A, moduleHashes.B);
        await writeFile(join(outputPath, 'module-identities.json'), json(moduleHashes), {flag: 'wx'});
        for (const scenario of SCENARIOS) {
            const inputs = Object.fromEntries(['A', 'B', 'C'].map((arm) =>
                [arm, captured.map((input) => reconstruct(input, arms[arm].factory, scenario))]));
            const mapReads = {};
            const outputHashes = [];
            for (const arm of ['A', 'B', 'C']) {
                let reads = 0;
                for (let index = 0; index < captured.length; ++index) {
                    const originalGet = Map.prototype.get;
                    let output;
                    try {
                        Map.prototype.get = function(key) { ++reads; return originalGet.call(this, key); };
                        output = runEncode(arms[arm].encode, inputs[arm][index]);
                    } finally { Map.prototype.get = originalGet; }
                    if (scenario !== 'actual-jmdict' && arm === 'A') {
                        for (const target of ['A', 'B', 'C']) { inputs[target][index].expected = new Uint8Array(output); }
                    }
                    requireEqual(output, inputs[arm][index].expected);
                    if (arm === 'A') { outputHashes.push({index, bytes: output.byteLength, sha256: sha(output)}); }
                }
                requireUnchanged(inputs[arm]);
                mapReads[arm] = reads;
                assert.equal(reads, scenario === 'actual-jmdict' ? plan.expectedActualMapReads[arm] : 0);
            }
            await appendFile(join(outputPath, 'correctness.jsonl'), JSON.stringify({scenario, mapReads, outputHashes}) + '\n');
            function observe(arm) {
                const outputs = [];
                const beforeCpu = process.cpuUsage();
                const start = performance.now();
                for (let repeat = 0; repeat < REPEATS; ++repeat) {
                    for (const input of inputs[arm]) { outputs.push(runEncode(arms[arm].encode, input)); }
                }
                const wallMs = performance.now() - start;
                const cpu = process.cpuUsage(beforeCpu);
                for (let index = 0; index < outputs.length; ++index) {
                    requireEqual(outputs[index], inputs[arm][index % inputs[arm].length].expected);
                }
                requireUnchanged(inputs[arm]);
                return {wallMs, cpuUserMs: cpu.user / 1000, cpuSystemMs: cpu.system / 1000,
                    cpuTotalMs: (cpu.user + cpu.system) / 1000, calls: outputs.length,
                    returnedBytes: outputs.reduce((sum, output) => sum + output.byteLength, 0),
                    processMemoryAfter: process.memoryUsage(), peakRssKiB: process.resourceUsage().maxRSS};
            }
            const warmups = [];
            const observations = [];
            for (let index = 0; index < plan.warmupOrders.length + BLOCKS; ++index) {
                const warmup = index < plan.warmupOrders.length;
                const block = warmup ? index : index - plan.warmupOrders.length;
                const order = warmup ? plan.warmupOrders[block] : plan.orders[block];
                const values = {};
                for (const arm of order) {
                    values[arm] = observe(arm);
                    await appendFile(join(outputPath, 'observations.jsonl'), JSON.stringify({scenario, warmup, block, order, arm, ...values[arm]}) + '\n');
                }
                (warmup ? warmups : observations).push({block, order, values});
            }
            const report = {scenario, complete: true, rowsPerCorpus: manifest.rows, inputCount: captured.length,
                repeatsPerObservation: REPEATS, mapReads, outputHashes, warmups, observations,
                summary: summarize(observations)};
            scenarioReports.push(report);
            await writeFile(join(outputPath, scenario + '.json'), json(report), {flag: 'wx'});
            console.log(json({scenario, summary: report.summary}));
        }
        await requireIdentity(plan.baseline);
        assert.deepEqual(await candidateIdentity(plan.candidate.root), plan.candidate);
        assert.deepEqual(await scriptHashes(), plan.scripts);
        assert.equal(sha(await readFile(join(plan.capturePath, 'manifest.json'))), plan.captureManifestSha256);
        await loadBytes(plan.capturePath, manifest);
        const report = {protocol: PROTOCOL, complete: true, scope: 'Complete synchronous record encoder component only, not full sink or browser import',
            planSha256: sha(planBytes), scenarios: scenarioReports.map(({scenario, summary}) => ({scenario, summary})),
            node: process.version, versions: process.versions, execArgv: process.execArgv, nodeOptions: null,
            finishedAt: new Date().toISOString(), resourceUsage: process.resourceUsage(), processMemory: process.memoryUsage()};
        await writeFile(join(outputPath, 'complete.json'), json(report), {flag: 'wx'});
    } catch (error) {
        const failure = {protocol: PROTOCOL, complete: false, planSha256: sha(planBytes),
            error: error.stack ?? String(error), completedScenarios: scenarioReports.map(({scenario}) => scenario),
            failedAt: new Date().toISOString(), resourceUsage: process.resourceUsage(), processMemory: process.memoryUsage()};
        await writeFile(join(outputPath, 'failure.json'), json(failure), {flag: 'wx'});
        process.stderr.write(failure.error + '\n');
        process.exitCode = 1;
    }
} else { throw new Error('Expected register or run'); }
