# Conditional first-use encoder study design

Recorded prospectively on 2026-11-28, before any first-use observations.
This is a read-only design note, not an acquired cohort or a performance claim.

## Prerequisite and scope

Implement this study only if the already registered warm/common144 study passes
its declared review checks. Its plan SHA-256 is
`f8dabb543aca5a71cdd601d1041a066bb137391d076eb3d396eaca4be1953127`.
Keep its observations and interpretation separate.

Compare frozen repeat-only score-cache commit
`5565f279a12a6f99bc1719b9dbe9246f30624098` with two identical baseline arms at
`9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. Candidate runtime SHA-256 is
`7f4dbeb8447a0d2797b636cfcd5746a4c9c3b27df2f5b1526ff6b8fd7aa90871`.
Use the unchanged original producer-input capture in
`evidence/score-cache/actual-encoder-inputs`, with all 12 calls / 528,299 rows in
captured order. This is the complete synchronous encoder's first-use component,
not a complete browser import, process startup, or storage benchmark.

## Fixed acquisition

- Exactly 24 blocks and 72 fresh, sequential one-arm Node children. Repeat the
  six orders ABC, BCA, CAB, ACB, CBA, BAC four times. No excluded encoder warmups,
  retries, replacements, adaptive stopping, or additional/larger cohort.
- Register exact source, runtime dependency, capture, helper, Node, and schedule
  identities before acquisition. Preserve an exclusive acquisition marker,
  every raw observation, child diagnostic and first failure. A partial cohort
  is retained as incomplete and cannot qualify the candidate.
- Require an empty `process.execArgv` and absent `NODE_OPTIONS` and
  `NODE_COMPILE_CACHE` in every child. Do not add GC, heap, optimization, preload,
  or compilation-cache flags. Record the actual Node version and environment
  guard results. Each arm has fresh process/module/JIT history.
- A and C import identical baseline bytes independently. B imports only the
  frozen changed record-store source. Resolve imports to the same frozen
  baseline dependencies, as in the reviewed warm component protocol. Bind the
  rewritten module bytes and both original sources to the registered plan.
- Before timing: import the selected production module, create one production
  store, load/hash the capture, reconstruct exact private backing buffers,
  aliases, view offsets and descriptors, and call that module's production
  factory for the input objects. These setup steps must not invoke the encoder.
- Do not perform an untimed correctness call, score-cache activation call,
  `Map.get` instrumentation, or encoder-specific warmup in the measured child.
  The separate untimed census already establishes the 269,193 baseline versus
  7,676 candidate reads and original producer admission.
- Start wall/process-CPU timing immediately before the first encoder call.
  Invoke `_encodeArtifactRecordFields` once for each of the 12 original inputs,
  in their original order, with no repetition. Include its fresh per-call maps,
  lazy cache, scratch arrays, final field allocation and writes.
- Retain all 12 returned byte arrays until both wall and CPU counters stop.
  Then compare every field byte with the original baseline capture and verify
  every full input backing buffer is unchanged. All source/identity and proof
  checks are outside the timed endpoint. An exception or mismatch fails the
  study and preserves its partial outputs.

Process startup, module loading, input reconstruction and hashing are excluded
from the endpoint. Fresh-process isolation removes earlier encoder execution;
it does not turn this into a browser cold-start measurement.

## Prospective analysis and pass/hold rule

Retain all 24 complete paired blocks. Report raw wall and process-CPU values,
arm medians, paired medians/geometric changes and faster-block counts for B/A,
B/C and identical-code C/A. Use descriptive paired-block percentile 95%
intervals with 100,000 resamples, NumPy PCG64 seed 20261128, linear quantile
endpoints, and one shared paired index stream across all comparisons/metrics.
No filtering or pooling with the warm study is permitted.

The parent fixed the decision before any first-use acquisition:

1. All 72 children must complete with exact outputs, unchanged complete input
   backings and intact source/capture identities.
2. The geometric wall-time B/A and B/C descriptive 95% upper bounds must both
   be strictly below zero.
3. Process CPU and paired directions must be consistent with the claimed gain,
   and identical-code C/A attribution must receive explicit review. The wall
   interval rule alone is not automatic promotion.

If this evidence is absent or incomplete, hold the cache PR and stop this
mechanism. Do not replace the cohort, expand it, search cache sizes, change the
source, or use a favorable warm estimate to rescue the decision. Full unit/build
validation follows only if both this study and the already registered common
controls justify review. Any later source or browser qualification remains a
separate claim and study.
