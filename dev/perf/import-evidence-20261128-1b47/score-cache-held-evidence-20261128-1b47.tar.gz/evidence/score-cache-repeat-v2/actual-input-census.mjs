/* SPDX-License-Identifier: GPL-3.0-or-later */
// Untimed activation/output census only. The measured v1 study stays unchanged.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';
import {resolve, join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {git, requireIdentity, BASELINE} from '../native-child-screen-1b47-v2/protocol.mjs';

const BASE_V1 = 'bf44285cd06b1a4a832921c3669a2ca1659a9a76';
const SOURCE = 'ext/js/dictionary/term-record-opfs-store.js';
const SOURCE_SHA256 = '7f4dbeb8447a0d2797b636cfcd5746a4c9c3b27df2f5b1526ff6b8fd7aa90871';
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const [sourcePath, outputPath] = process.argv.slice(2);
assert(sourcePath && outputPath, 'Usage: node actual-input-census.mjs SOURCE OUTPUT');
const root = resolve(sourcePath);
const output = resolve(outputPath);
const groups = [];
let bindings = null;

async function run() {
    assert.equal(git(root, 'merge-base', 'HEAD', BASE_V1), BASE_V1);
    assert.deepEqual(git(root, 'diff', '--name-only', BASE_V1, '--').split('\n').sort(),
        [SOURCE, 'test/term-record-score-cache.test.js']);
    const sourceBytes = await readFile(join(root, SOURCE));
    assert.equal(sha(sourceBytes), SOURCE_SHA256);
    const referencePlanBytes = await readFile(new URL('../score-cache/actual-encoder-screen-v1/plan.json', import.meta.url));
    const referencePlan = JSON.parse(referencePlanBytes);
    assert.equal(referencePlan.protocol, 'actual-record-encoder-score-cache-20261128-1b47-v1');
    assert.equal(referencePlan.baseline.commit, BASELINE);
    assert.equal(referencePlan.candidate.commit, BASE_V1);
    await requireIdentity(referencePlan.baseline);
    const correctness = (await readFile(new URL('../score-cache/actual-encoder-screen-v1/correctness.jsonl', import.meta.url), 'utf8'))
        .trim().split('\n').map((line) => JSON.parse(line)).find(({scenario}) => scenario === 'actual-jmdict');
    assert.deepEqual(correctness.mapReads, {A: 269193, B: 6223, C: 269193});
    const manifestPath = join(referencePlan.capturePath, 'manifest.json');
    const manifestBytes = await readFile(manifestPath);
    assert.equal(sha(manifestBytes), referencePlan.captureManifestSha256);
    const manifest = JSON.parse(manifestBytes);
    assert.equal(manifest.complete, true);
    assert.equal(manifest.sourceCommit, BASELINE);
    assert.equal(manifest.rows, 528299);
    assert.equal(manifest.inputs.length, 12);
    assert.equal(manifest.sourceDigestSha256, 'e61445478202dbbda9c22d91a5bc51e87b6b77ce0096898a37aad149cefa0400');
    assert.equal(manifest.filesDigestSha256, 'b9200f034c262f240ab55c1598c3c8a9703122c4495c1379deac06d6c80ac5f8');
    bindings = {baseV1: BASE_V1, sourceCommit: git(root, 'rev-parse', 'HEAD'), sourceSha256: sha(sourceBytes),
        testSha256: sha(await readFile(join(root, 'test/term-record-score-cache.test.js'))),
        referencePlanSha256: sha(referencePlanBytes), captureManifestSha256: sha(manifestBytes),
        helperSha256: sha(await readFile(new URL(import.meta.url))), node: process.version,
        execArgv: process.execArgv, nodeOptions: process.env.NODE_OPTIONS ?? null};
    const {TermRecordOpfsStore, createArtifactTermRecordChunkWithResolvedContent} =
        await import(pathToFileURL(join(root, SOURCE)));
    const store = new TermRecordOpfsStore();
    const constructors = {Int32Array, Uint32Array, Float64Array};
    const sourceFiles = [];
    for (const input of manifest.inputs) {
        assert.equal(input.chunkPrototype, 'Object.prototype');
        assert.equal(input.referencesPrototype, 'Object.prototype');
        assert.equal(input.provenance.selectedResolvedPath, true);
        assert.equal(input.provenance.sameEncoderObject, true);
        assert.equal(input.provenance.sameReferencesObject, true);
        assert.equal(input.provenance.rowCount, input.rowCount);
        const backings = [];
        for (const buffer of input.buffers) {
            assert.equal(buffer.id, backings.length);
            assert.equal(buffer.kind, 'ArrayBuffer');
            assert.equal(buffer.resizable, false);
            assert.equal(buffer.byteLength, buffer.maxByteLength);
            const path = join(referencePlan.capturePath, buffer.file);
            const bytes = await readFile(path);
            assert.equal(bytes.byteLength, buffer.byteLength);
            assert.equal(sha(bytes), buffer.sha256);
            sourceFiles.push({path, sha256: buffer.sha256});
            backings.push(new Uint8Array(bytes).buffer);
        }
        const values = {};
        for (const [name, column] of Object.entries(input.columns)) {
            const Constructor = constructors[column.constructor];
            assert(Constructor);
            assert.equal(column.prototype, Constructor.name + '.prototype');
            for (const key of ['hasOwnLength', 'hasOwnBuffer', 'hasOwnByteOffset', 'hasOwnByteLength']) {
                assert.equal(column[key], false);
            }
            if (column.descriptor !== null) {
                assert.equal(column.descriptor.present, true);
                for (const key of ['writable', 'enumerable', 'configurable']) {
                    assert.equal(column.descriptor[key], true);
                }
            }
            const value = new Constructor(backings[column.bufferId], column.byteOffset, column.length);
            assert.equal(value.byteLength, column.byteLength);
            assert.equal(sha(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)), column.viewSha256);
            values[name] = value;
        }
        assert(values.scoreList instanceof Int32Array);
        assert(values.uniqueIndexList instanceof Uint32Array);
        assert(values.offsets instanceof Float64Array);
        assert(values.lengths instanceof Uint32Array);
        assert(values.contentOffsets instanceof Float64Array);
        assert(values.contentLengths instanceof Uint32Array);
        for (const descriptor of [input.rowCountDescriptor, input.referencesDescriptor]) {
            assert.equal(descriptor.present, true);
            for (const key of ['writable', 'enumerable', 'configurable']) { assert.equal(descriptor[key], true); }
        }
        const seed = {rowCount: input.rowCount, scoreList: values.scoreList};
        for (const key of ['fixedContentOffsetBase', 'fixedContentLength']) {
            const descriptor = input[key];
            if (descriptor.present) {
                Object.defineProperty(seed, key, {value: descriptor.value,
                    writable: descriptor.writable, enumerable: descriptor.enumerable, configurable: descriptor.configurable});
            }
        }
        const chunk = createArtifactTermRecordChunkWithResolvedContent(seed, values.uniqueIndexList, values.offsets, values.lengths);
        const backingHashes = backings.map((buffer) => sha(new Uint8Array(buffer)));
        const outlierCounts = new Map();
        let outlierRows = 0;
        for (let i = 0; i < input.rowCount; ++i) {
            const score = values.scoreList[i];
            if (score < -256 || score > 255) {
                ++outlierRows;
                outlierCounts.set(score, (outlierCounts.get(score) ?? 0) + 1);
            }
        }
        assert.equal(outlierRows, input.mapReads);
        let mapReads = 0;
        let fields;
        const originalGet = Map.prototype.get;
        try {
            Map.prototype.get = function(key) { ++mapReads; return originalGet.call(this, key); };
            fields = store._encodeArtifactRecordFields(chunk, values.contentOffsets, values.contentLengths, input.contentOffsetBase);
        } finally { Map.prototype.get = originalGet; }
        const expectedPath = join(referencePlan.capturePath, input.output.file);
        const expected = await readFile(expectedPath);
        assert.equal(expected.byteLength, input.output.byteLength);
        assert.equal(sha(expected), input.output.sha256);
        sourceFiles.push({path: expectedPath, sha256: input.output.sha256});
        assert.equal(fields.byteLength, expected.byteLength);
        assert.equal(Buffer.compare(Buffer.from(fields.buffer, fields.byteOffset, fields.byteLength), expected), 0);
        for (let i = 0; i < backings.length; ++i) {
            assert.equal(sha(new Uint8Array(backings[i])), backingHashes[i]);
        }
        groups.push({index: input.index, rows: input.rowCount, baselineMapReads: input.mapReads,
            v2MapReads: mapReads, outlierDistinct: outlierCounts.size,
            repeatedOutlierDistinct: [...outlierCounts.values()].filter((count) => count > 1).length,
            outputSha256: sha(fields), outputBytes: fields.byteLength,
            exactOutput: true, completeBackingBytesUnchanged: true});
    }
    await requireIdentity(referencePlan.baseline);
    assert.equal(sha(await readFile(join(root, SOURCE))), SOURCE_SHA256);
    assert.equal(sha(await readFile(manifestPath)), referencePlan.captureManifestSha256);
    for (const file of sourceFiles) { assert.equal(sha(await readFile(file.path)), file.sha256); }
    const totals = {rows: 0, baselineMapReads: 0, v1MapReads: correctness.mapReads.B,
        v2MapReads: 0, outlierDistinct: 0, repeatedOutlierDistinct: 0};
    for (const group of groups) {
        for (const key of ['rows', 'baselineMapReads', 'v2MapReads', 'outlierDistinct', 'repeatedOutlierDistinct']) {
            totals[key] += group[key];
        }
    }
    assert.equal(totals.rows, 528299);
    assert.equal(totals.baselineMapReads, 269193);
    assert(totals.v2MapReads <= totals.v1MapReads + totals.repeatedOutlierDistinct,
        'Additional Map reads exceed the repeat-only admission bound');
    return {complete: true, scope: 'Untimed actual complete-encoder activation/output census; no performance measurement',
        bindings, totals, mapReadsAvoidedFraction: 1 - totals.v2MapReads / totals.baselineMapReads,
        additionalReadsVersusV1: totals.v2MapReads - totals.v1MapReads, groups};
}

try {
    const report = await run();
    await writeFile(output, JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
    console.log(JSON.stringify({complete: true, totals: report.totals,
        mapReadsAvoidedFraction: report.mapReadsAvoidedFraction, additionalReadsVersusV1: report.additionalReadsVersusV1,
        exactOutputsAndBackings: true, output}));
} catch (error) {
    await writeFile(output, JSON.stringify({complete: false, scope: 'Untimed actual encoder-input census',
        bindings, groups, error: error.stack ?? String(error)}, null, 2) + '\n', {flag: 'wx'});
    throw error;
}
