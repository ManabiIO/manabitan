#!/usr/bin/env python3
"""Prepare a complete allowlist/source checkpoint for the held cache studies."""
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT / 'manabitan'
OUT = ROOT / 'evidence/durable-bundles/cache'
BASE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
V1 = 'bf44285cd06b1a4a832921c3669a2ca1659a9a76'
V2 = '5565f279a12a6f99bc1719b9dbe9246f30624098'
SOURCE = 'ext/js/dictionary/term-record-opfs-store.js'
TEST = 'test/term-record-score-cache.test.js'
sha = lambda data: hashlib.sha256(data).hexdigest()
git = lambda *args: subprocess.check_output(['git', '-C', str(REPO), *args])


def regular_files(path):
    assert not path.is_symlink(), path
    if path.is_file():
        assert stat.S_ISREG(path.lstat().st_mode), path
        yield path
        return
    for directory, dirs, files in os.walk(path, followlinks=False):
        dirs[:] = [name for name in dirs if name != '__pycache__']
        for name in dirs:
            assert not (Path(directory) / name).is_symlink()
        for name in files:
            item = Path(directory) / name
            assert stat.S_ISREG(item.lstat().st_mode), item
            yield item


OUT.mkdir(parents=True, exist_ok=True)
assert git('rev-parse', 'HEAD').decode().strip() == BASE
bindings = []
expected = {}
for label, commit, tree in [('baseline', BASE, 'manabitan'), ('v1', V1, 'score-cache-experiment'),
                            ('v2', V2, 'score-cache-repeat-experiment')]:
    files = [SOURCE] if label == 'baseline' else [SOURCE, TEST]
    for name in files:
        original = git('show', f'{commit}:{name}')
        path = ROOT / tree / name
        assert path.read_bytes() == original, f'Frozen source changed: {path}'
        rel = path.relative_to(ROOT).as_posix()
        expected[rel] = sha(original)
        bindings.append({'revision': label, 'commit': commit, 'path': rel,
                         'bytes': len(original), 'sha256': sha(original),
                         'gitBlob': git('rev-parse', f'{commit}:{name}').decode().strip()})
for label, commit in [('v1', V1), ('v2', V2)]:
    (OUT / f'{label}-from-baseline.patch').write_bytes(git('diff', '--binary', BASE, commit, '--', SOURCE, TEST))

pack = OUT / 'cache-checkpoints.pack'
pack_bytes = subprocess.check_output(['git', '-C', str(REPO), 'pack-objects', '--stdout', '--revs'],
                                    input=f'{V1}\n{V2}\n^{BASE}\n'.encode())
pack.write_bytes(pack_bytes)
pack_id = subprocess.check_output(['git', '-C', str(REPO), 'index-pack', '--strict', str(pack)]).decode().strip()
subprocess.run(['git', '-C', str(REPO), 'verify-pack', str(pack.with_suffix('.idx'))], check=True,
               stdout=subprocess.DEVNULL)
(OUT / 'source-bindings.json').write_text(json.dumps({
    'baseline': BASE, 'v1': V1, 'v2': V2, 'files': bindings,
    'gitPack': {'file': pack.relative_to(ROOT).as_posix(), 'bytes': len(pack_bytes),
                'sha256': sha(pack_bytes), 'packId': pack_id,
                'ancestryRequired': BASE, 'refsCreated': False},
    'inputCaptureManifestSha256': '3ee5d9636b63fb1d81faa59c782ed3388f67759dfacfa52ce391010e29bda9b7',
    'disposition': 'Held after common144 failure; no first-use implementation or observations',
}, indent=2) + '\n')

capture_root = ROOT / 'evidence/score-cache/actual-encoder-inputs'
capture = json.loads((capture_root / 'manifest.json').read_text())
input_total = output_total = checked_files = 0
for item in capture['inputs']:
    for descriptor in item['buffers'] + [item['output']]:
        path = capture_root / descriptor['file']
        assert stat.S_ISREG(path.lstat().st_mode), path
        data = path.read_bytes()
        assert len(data) == descriptor['byteLength']
        assert sha(data) == descriptor['sha256']
        expected[path.relative_to(ROOT).as_posix()] = descriptor['sha256']
        checked_files += 1
    input_total += sum(value['byteLength'] for value in item['buffers'])
    output_total += item['output']['byteLength']
assert input_total == 8618752 and output_total == 4239960 and checked_files == 84
(OUT / 'numeric-input-verification.json').write_text(json.dumps({
    'inputBackingBytes': input_total, 'expectedFieldBytes': output_total,
    'filesChecked': checked_files, 'allOriginalManifestSizesAndHashesMatch': True,
    'manifestSha256': sha((capture_root / 'manifest.json').read_bytes()),
    'normalizationOrDeduplicationAcrossInputGroups': False,
}, indent=2) + '\n')

selected = set()
for name in ['evidence/score-cache', 'evidence/score-cache-repeat-v2', 'evidence/durable-bundles/cache',
             'evidence/native-child-screen-1b47-v2']:
    for path in regular_files(ROOT / name):
        if path.name != 'bundle-spec.json':
            selected.add(path.relative_to(ROOT).as_posix())
for name in [
    'evidence/durable-bundles/package-evidence-v2.py', 'evidence/durable-bundles/prepare-cache-bundle.py',
    'evidence/node-score-encoder-input-capture.mjs', 'evidence/node-sink-file-fetch.mjs',
    'evidence/node-sink-opfs.mjs', 'evidence/node-sink-worker.mjs',
    'evidence/node-sink-jmdict-baseline-verify2.json', 'evidence/input-identities-1b47.json',
    'manabitan/package.json', 'manabitan/package-lock.json', 'manabitan/dev/data/dictionary-fixtures.json',
    'manabitan/test/term-record-authoritative-encoder.test.js',
    'manabitan/test/term-record-compact-score-validation.test.js',
    'manabitan/test/term-record-direct-field-columns.test.js',
    'manabitan/test/term-record-reference-origin.test.js',
    'manabitan/test/term-record-split-reference-origin.test.js',
]:
    if not (ROOT / name).exists():
        # Fixture filename is resolved below from the baseline's tracked files.
        if name.endswith('dictionary-fixtures.json'):
            continue
        raise FileNotFoundError(name)
    selected.add(name)
selected.update(expected)
fixtures = git('ls-files', 'dev/data/*dict*', 'dev/data/*fixture*', 'dev/*lock*').decode().splitlines()
for name in fixtures:
    if (ROOT / 'manabitan' / name).is_file():
        selected.add('manabitan/' + name)
spec_rel = 'evidence/durable-bundles/cache/bundle-spec.json'
selected.add(spec_rel)
expected['evidence/score-cache/actual-encoder-inputs/manifest.json'] = '3ee5d9636b63fb1d81faa59c782ed3388f67759dfacfa52ce391010e29bda9b7'
spec = {
    'name': 'score-cache-held-evidence-20261128-1b47',
    'study': 'Exact-tag score cache v1 and repeat-only v2, held after prospective common-path gate failure',
    'scope': 'Complete actual encoder inputs/expected bytes, both frozen candidates and all complete component cohorts; no browser-import or first-use claim',
    'sourceBindings': {'baseline': BASE, 'v1': V1, 'v2': V2, 'details': 'evidence/durable-bundles/cache/source-bindings.json'},
    'include': sorted(selected), 'expectedSha256': expected,
    'omitExternal': [
        {'kind': 'dictionary-archive', 'name': 'jmdict.zip', 'included': False,
         'sha256': '3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f',
         'bytes': 15645766,
         'url': 'https://github.com/yomidevs/jmdict-yomitan/releases/download/2026-11-22/JMdict_english.zip',
         'reconstruction': 'Pinned fixture source in input-identities-1b47.json; original capture helper and recipe retained; numeric capture is included in full'},
        {'kind': 'runtime-and-storage', 'included': False,
         'items': ['node_modules', 'browser/compiler distributions', 'full OPFS database', 'extension package builds'],
         'reconstruction': 'Exact package locks/runtime inventory and complete source/file-set digests retained; install/rebuild at baseline with recorded Node version'},
    ],
}
(ROOT / spec_rel).write_text(json.dumps(spec, indent=2) + '\n')
for name in selected:
    assert stat.S_ISREG((ROOT / name).lstat().st_mode), name
print(json.dumps({'spec': spec_rel, 'members': len(selected),
                  'payloadBytes': sum((ROOT / name).stat().st_size for name in selected),
                  'inputBackingsAndExpectedFieldsIncluded': True, 'sourceBindings': len(bindings),
                  'gitPackBytes': len(pack_bytes)}))
