/* SPDX-License-Identifier: GPL-3.0-or-later */
/* eslint @stylistic/semi: ["error", "never"] */

import {describe, expect, test, vi} from 'vitest'
import {createArtifactTermRecordChunkWithResolvedContent, TermRecordOpfsStore} from '../ext/js/dictionary/term-record-opfs-store.js'

/** @typedef {ReturnType<typeof fixture>} Fixture */

/**
 * @param {number[]} scores
 * @returns {{rowCount: number, scoreList: number[]|Int32Array|Float64Array, resolvedContentReferences: {uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}}}
 */
function fixture(scores) {
    return createArtifactTermRecordChunkWithResolvedContent(
        {rowCount: scores.length, scoreList: Int32Array.from(scores)},
        Uint32Array.from({length: scores.length}, (_, i) => i % 3),
        Float64Array.of(2 ** 40, 2 ** 40 + 19, 2 ** 40 + 47),
        Uint32Array.of(19, 28, 31),
    )
}

/**
 * @param {Fixture} chunk
 * @returns {Uint8Array}
 */
function encode(chunk) {
    return new TermRecordOpfsStore()._encodeArtifactRecordFields(chunk, [], [], 2 ** 40)
}

/**
 * The external-object path retains the existing scalar range-table encoder.
 * @param {Fixture} chunk
 * @returns {Uint8Array}
 */
function expectGenericParity(chunk) {
    const expected = encode({...chunk})
    const actual = encode(chunk)
    expect(actual.byteLength).toBe(expected.byteLength)
    expect(Buffer.compare(actual, expected)).toBe(0)
    return actual
}

/**
 * Count only the synchronous record encoder's map reads, outside assertions.
 * @param {Fixture} chunk
 * @returns {{bytes: Uint8Array, reads: number}}
 */
function encodeWithMapReads(chunk) {
    const store = new TermRecordOpfsStore()
    const get = vi.spyOn(Map.prototype, 'get')
    try {
        const bytes = store._encodeArtifactRecordFields(chunk, [], [], 2 ** 40)
        return {bytes, reads: get.mock.calls.length}
    } finally {
        get.mockRestore()
    }
}

describe('exact score cache for private record columns', () => {
    test.each([
        [0, 512, -512, 0, -512, 512],
        [-1, 2147483647, -2147483648, 0, 2147483647, -1],
        [-10200, -10201, 0, -10200, 0, -10201],
        [-256, 255, 256, -257, -256, 256],
    ])('preserves exact values and first-use keys through collisions: %j', (...pattern) => {
        const chunk = fixture(Array.from({length: 192}, (_, i) => pattern[i % pattern.length]))
        const bytes = expectGenericParity(chunk)
        const firstUse = [...new Set(chunk.scoreList)]
        const header = new Uint32Array(bytes.buffer, bytes.byteOffset, 4)
        expect(header[0]).toBe(0x3246524d)
        expect(header[2]).toBe(firstUse.length)
        expect([...new Int32Array(bytes.buffer, bytes.byteOffset + 16, header[2])]).toEqual(firstUse)
    })

    test('recovers every earlier score after all 512 slots are evicted', () => {
        const first = Array.from({length: 512}, (_, i) => i + 4096)
        const collision = first.map((value) => value + 512)
        const chunk = fixture([...first, ...collision, ...first.toReversed()])
        const bytes = expectGenericParity(chunk)
        const header = new Uint32Array(bytes.buffer, bytes.byteOffset, 4)
        expect(header[2]).toBe(1024)
    })

    test('avoids map reads for repeated distant scores after their first use', () => {
        const pattern = [-10200, -10201, 0]
        const chunk = fixture(Array.from({length: 192}, (_, i) => pattern[i % pattern.length]))
        const actual = encodeWithMapReads(chunk)
        expect(actual.reads).toBe(3)
        expect(Buffer.compare(actual.bytes, encode({...chunk}))).toBe(0)
    })

    test.each([63, 64])('keeps the existing small-chunk threshold at %i rows', (count) => {
        const chunk = fixture(Array(count).fill(-10200))
        const actual = encodeWithMapReads(chunk)
        expect(actual.reads).toBe(count < 64 ? count : 1)
        expect(Buffer.compare(actual.bytes, encode({...chunk}))).toBe(0)
    })

    test('retains range-table behavior for inputs without the private-column proof', () => {
        class Scores extends Int32Array {}
        const make = () => fixture(Array(128).fill(-10200))
        const sharedScores = make()
        sharedScores.scoreList = new Int32Array(new SharedArrayBuffer(128 * 4)).fill(-10200)
        const sharedLengths = make()
        sharedLengths.resolvedContentReferences.lengths = new Uint32Array(new SharedArrayBuffer(3 * 4))
        sharedLengths.resolvedContentReferences.lengths.set([19, 28, 31])
        const subclass = make()
        subclass.scoreList = new Scores(subclass.scoreList)
        const proxyScores = make()
        proxyScores.scoreList = new Proxy(Int32Array.from(proxyScores.scoreList), {})
        const accessor = make()
        const originalScores = accessor.scoreList
        Object.defineProperty(accessor, 'scoreList', {get: () => originalScores})
        const fixed = Object.assign(make(), {fixedContentLength: 17})
        const floats = make()
        floats.scoreList = Float64Array.from(floats.scoreList)
        for (const chunk of [{...make()}, new Proxy(make(), {}), sharedScores, sharedLengths, subclass, proxyScores, accessor, fixed, floats]) {
            const actual = encodeWithMapReads(chunk)
            expect(actual.reads).toBe(chunk.rowCount)
            expect(Buffer.compare(actual.bytes, encode({...chunk}))).toBe(0)
        }
    })

    test('does not add bitwise coercions to adversarial score proxies', () => {
        const chunk = fixture(Array(128).fill(-10200))
        let conversions = 0
        const boxed = {valueOf() { ++conversions; return -10200 }}
        const scores = Int32Array.from(chunk.scoreList)
        chunk.scoreList = new Proxy(scores, {
            get(target, key) {
                return key === '0' ? boxed : Reflect.get(target, key, target)
            },
        })
        const bytes = encode(chunk)
        // Existing score+radius coercion and final Int32 score-table write only.
        expect(conversions).toBe(2)
        expect(bytes.byteLength).toBe(16 + 2 * 4 + 128 * 8)
    })

    test('resets cached indexes between invocations on mutable private inputs', () => {
        const chunk = fixture(Array(128).fill(-10200))
        const first = expectGenericParity(chunk)
        const preserved = first.slice()
        chunk.scoreList.fill(-10201)
        const second = expectGenericParity(chunk)
        expect(Buffer.compare(first, preserved)).toBe(0)
        expect(Buffer.compare(first, second)).not.toBe(0)
    })

    test.each([false, true])('preserves invalid-reference errors after cached rows, legacy=%s', (legacy) => {
        const chunk = fixture(Array(128).fill(-10200))
        if (legacy) { chunk.resolvedContentReferences.lengths[0] = 65535 }
        chunk.resolvedContentReferences.uniqueIndexList[127] = 3
        expect(() => encode(chunk)).toThrow('Invalid resolved term content reference index: 3')
        expect(() => encode({...chunk})).toThrow('Invalid resolved term content reference index: 3')
    })
})
