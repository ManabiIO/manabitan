// Untimed work-count census. These compact outputs reconstruct scores, not
// the complete inputs needed to time the production record-field encoder.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const inputDir = path.resolve(here, '../score-validation/fields');
const manifestPath = path.join(inputDir, 'manifest.json');
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const sha256 = (value) => createHash('sha256').update(value).digest('hex');
assert.equal(manifest.complete, true);
assert.equal(manifest.sourceCommit, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
const groups = [];
for (const entry of manifest.capturedFields) {
    const bytes = fs.readFileSync(path.join(inputDir, entry.file));
    assert.equal(sha256(bytes), entry.sha256);
    assert.equal(bytes.length, entry.byteLength);
    const header = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    assert.equal(header.getUint32(0, true), 0x3246524d);
    const count = header.getUint32(4, true);
    const scoreCount = header.getUint32(8, true);
    assert.equal(header.getUint32(12, true), 2);
    assert.equal(count, entry.count);
    assert.equal(bytes.length, 16 + scoreCount * 4 + count * 8);
    assert(count >= 64 && scoreCount > 0 && scoreCount < 65535);
    const values = new Int32Array(bytes.buffer, bytes.byteOffset + 16, scoreCount);
    const keys = new Uint16Array(bytes.buffer, bytes.byteOffset + 16 + scoreCount * 4 + count * 6, count);
    const scores = new Int32Array(count);
    const common = new Uint16Array(512);
    const seen = new Map();
    const firstUse = [];
    let tags = null;
    let cachedIndexes = null;
    const counters = {
        commonRows: 0,
        outlierRows: 0,
        baselineMapReads: 0,
        hybridMapReads: 0,
        cacheHits: 0,
        cacheEmptyMisses: 0,
        cacheCollisionMisses: 0,
        cacheMissPreviouslySeen: 0,
        mapInsertions: 0,
    };
    for (let i = 0; i < count; ++i) {
        assert(keys[i] < scoreCount);
        const score = values[keys[i]];
        scores[i] = score;
        const inlineScore = score + 256;
        const useInline = inlineScore >= 0 && inlineScore < 512;
        let refillSlot = -1;
        let scoreIndex;
        if (useInline) {
            ++counters.commonRows;
            scoreIndex = common[inlineScore] - 1;
        } else {
            ++counters.outlierRows;
            ++counters.baselineMapReads;
            if (tags === null) {
                tags = new Int32Array(512);
                cachedIndexes = new Uint16Array(512);
            }
            const slot = score & 511;
            const cachedKey = cachedIndexes[slot];
            if (cachedKey !== 0 && tags[slot] === score) {
                ++counters.cacheHits;
                scoreIndex = cachedKey - 1;
            } else {
                ++counters.hybridMapReads;
                if (cachedKey === 0) { ++counters.cacheEmptyMisses; }
                else { ++counters.cacheCollisionMisses; }
                scoreIndex = seen.get(score) ?? -1;
                if (scoreIndex >= 0) { ++counters.cacheMissPreviouslySeen; }
                refillSlot = slot;
            }
        }
        if (scoreIndex < 0) {
            scoreIndex = firstUse.length;
            firstUse.push(score);
            if (useInline) { common[inlineScore] = scoreIndex + 1; }
            else {
                seen.set(score, scoreIndex);
                ++counters.mapInsertions;
            }
        }
        if (refillSlot >= 0) {
            tags[refillSlot] = score;
            cachedIndexes[refillSlot] = scoreIndex + 1;
        }
        assert.equal(scoreIndex, keys[i], `first-use index changed in ${entry.file} row ${i}`);
    }
    assert.deepEqual(firstUse, [...values]);
    groups.push({
        file: entry.file,
        fieldSha256: entry.sha256,
        rowCount: count,
        scoreCount,
        scoresSha256: sha256(new Uint8Array(scores.buffer)),
        ...counters,
        additionalCacheBytes: tags === null ? 0 : tags.byteLength + cachedIndexes.byteLength,
        exactScoreTableAndKeys: true,
    });
}
const totals = {rows: 0, commonRows: 0, outlierRows: 0, baselineMapReads: 0, hybridMapReads: 0, cacheHits: 0, cacheEmptyMisses: 0, cacheCollisionMisses: 0, cacheMissPreviouslySeen: 0, mapInsertions: 0};
for (const group of groups) {
    totals.rows += group.rowCount;
    for (const key of Object.keys(totals)) {
        if (key !== 'rows') { totals[key] += group[key]; }
    }
}
assert.equal(totals.rows, manifest.rows);
assert.equal(totals.rows, 528299);
const report = {
    scope: 'Untimed work counts on reconstructed actual JMdict score sequences; not encoder inputs or a performance measurement',
    baselineCommit: manifest.sourceCommit,
    inputManifestSha256: sha256(fs.readFileSync(manifestPath)),
    helperSha256: sha256(fs.readFileSync(fileURLToPath(import.meta.url))),
    cache: {commonRadius: 256, minimumRows: 64, exactTagSlots: 512, extraBytesPerEligibleOutlierGroup: 3072, lazy: true},
    allFirstUseTablesAndRowKeysExact: true,
    totals,
    mapReadsAvoidedFraction: (totals.baselineMapReads - totals.hybridMapReads) / totals.baselineMapReads,
    groups,
};
fs.writeFileSync(path.join(here, 'work-counts.json'), JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({totals, mapReadsAvoidedFraction: report.mapReadsAvoidedFraction, exact: true}));
