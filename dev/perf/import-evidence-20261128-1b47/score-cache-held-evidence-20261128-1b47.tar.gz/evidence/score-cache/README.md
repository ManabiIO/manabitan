# Exact outlier score cache experiment

Baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
Candidate workspace: `score-cache-experiment`.

## Chosen prospective design

The existing compact record encoder uses a 512-entry Uint16 table for scores
from −256 through 255, then a Map for all other scores. The candidate preserves
that common-score path and adds a lazy, 512-slot cache only for outliers on the
existing factory-proven, private Int32/direct-reference path. Each cache entry
has a full Int32 tag and a nonzero Uint16 score-index-plus-one value. A collision
or empty slot consults the original Map, which remains authoritative for every
distinct outlier and preserves its original first-use index. Cache hits use the
exact tag, never the masked slot alone.

The additional two arrays total 3,072 bytes and are created only at the first
eligible outlier. All-in-range groups allocate neither array. The existing
64-row admission threshold, ±256 table, generic fallback, field format,
sentinels, error checks, and legacy-field selection are unchanged. The fallback
does not perform a new bitwise coercion on caller-controlled score values.

The initial replacement design is preserved in `untimed-replacement.patch`
and `untimed-replacement-test.js`. It was neither tested nor timed. Before any
observations, the design changed to this hybrid to avoid extra tag work on
259,106 common-score JMdict rows and uniform-score controls. No slot-size sweep
or second measured design is planned.

## Untimed work-count result

`census.mjs` verifies and reconstructs the exact score sequence from the 12
previously captured compact-field buffers. These buffers are outputs of the
encoder; they are **not** a substitute for its complete inputs in a timing test.
Every reconstructed first-use score table and row key matches the captured
bytes exactly.

| Count over the complete JMdict corpus | Result |
| --- | ---: |
| Rows | 528,299 |
| Existing common-score path | 259,106 |
| Outlier rows / baseline Map reads | 269,193 |
| Candidate Map reads | 6,223 |
| Exact cache hits | 262,970 |
| Empty-slot misses | 2,477 |
| Collision misses | 3,746 |
| Misses recovering an existing Map key | 3,013 |
| Distinct outlier Map insertions, unchanged | 3,210 |

This removes 97.69% of outlier Map reads in the counted sequence, while adding
tag checks. It is a work-count result, with no measured speed claim. The planned
direct experiment must capture the actual factory input columns, content offset
base, fallback arrays, and expected field bytes from the complete public-sink
replay before timing the unchanged production method on each arm.

## Validation and retained failures

The selected runtime passed 81 tests across six focused suites, including
all-slot eviction, Int32 extremes, first-use order, common-score controls,
threshold boundaries, private-origin rejection, Proxy coercion order,
mutation between calls, invalid references, and the existing 65,535/65,536-score
legacy boundaries. Independent source review and final lint/types are pending.

The first scoped ESLint attempt used a deliberately limited 384 MiB V8 heap
and exited 134 with an explicit V8 heap-limit OOM before diagnostics. The next
1,024 MiB attempt found seven test-style errors, which were fixed without a
runtime change. Both logs are preserved. Later validation results will be
recorded separately. No browser qualification, remote branch, or PR exists for
this candidate.

### Frozen validation update

The chosen hybrid is frozen at local commit
`bf44285cd06b1a4a832921c3669a2ca1659a9a76`, directly on the baseline. Only the
runtime file and new test file changed. `frozen-candidate.json` records exact
file and Git blob hashes. The final six-suite run passed all 81 tests; scoped
ESLint and scoped TypeScript both passed. Independent source review found no
correctness blocker and confirmed the existing high-cardinality fixtures enter
the admitted cache route.

The initial TypeScript run found one test-only use of `toReversed`, which exceeds
the repository's declared library target. Replacing it with a copied reverse
preserved the fixture sequence. The original diagnostic and the successful
final run are retained, alongside the ESLint attempts above. Runtime source
was unchanged during those test-only repairs. This validation is focused; it
does not claim a completed full repository or browser qualification gate.

Benchmark setup owns the single prospective actual-input capture and component
protocol. No timing observation was acquired before this source freeze.
