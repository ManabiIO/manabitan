# Exact-tag score cache: fixed component screen v1

The complete production record-field encoder is measurably faster on the
captured JMdict inputs. The component saves about 3 ms across all 528,299 rows.
A small common-score regression remains unresolved; no browser import gain or
VNDB non-regression is claimed.

## Identity and input proof

Baseline is `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`; candidate is local commit
`bf44285cd06b1a4a832921c3669a2ca1659a9a76`, runtime SHA256
`a05eb1220804d6ea79636a2e1575bd1e4378c29542b5cf09cfd138a958120f70`.
The prospective plan SHA256 is
`a6173377828ea3679c22bba6c360d296ace4def58d8f1d298e47d5c21bbe02c1`.
No source, protocol or schedule changed after registration. Root and an
independent implementation agent reviewed the capture, executable and analysis.

One unchanged-baseline public-sink capture preserves all 12 actual input groups,
including actual nonsequential row-to-unique indexes, private Int32 scores,
resolved offsets/lengths, empty fallback arrays, full backing bytes, offsets,
alias identities, descriptors and actual factory provenance. The same produced
chunk and reference objects reach the observed encoder. All 8,618,752 input
backing bytes and 4,239,960 returned field bytes are retained. Every original
view has offset zero and an exact-size private backing; no normalization was
needed. The complete capture's canonical digest and all 43,315,677 persisted
bytes match the prior baseline.

The replay reconstructs those accessed fields with each module's own production
factory, retaining the private origin proof. Unrelated dictionary/lookup chunk
properties and the surrounding store/parser stack are not part of this direct
method replay. This is a component measurement with real field inputs, not a
substitute for the public sink or browser import endpoint.

The original full encoder method runs inside wall/process CPU measurements,
including fresh authoritative maps, lazy cache allocation, scratch arrays and
every returned output write. Input construction, counters, exact output checks,
full backing hashes and filesystem writes remain outside the timer. All result
buffers remain live until the timer stops. No source instrumentation, V8 flags,
NODE_OPTIONS or explicit garbage collection is used during measured calls.

## Actual JMdict result

All three arms exactly reproduce every captured output and leave every input
backing unchanged. Untimed actual production calls observe Map.get counts of
269,193 for A/C and 6,223 for B, confirming the predicted work reduction.

| Measure | Baseline A | Candidate B | Identical baseline C |
| --- | ---: | ---: | ---: |
| Median wall ms per full input corpus | 10.844 | 7.810 | 10.761 |
| Median process CPU ms per full corpus | 11.397 | 9.230 | 11.308 |

| Paired comparison | Median wall change | Geometric wall change, 95% interval | Geometric CPU change, 95% interval |
| --- | ---: | ---: | ---: |
| B/A | −29.63% | −24.42% [−32.86%, −12.91%] | −21.01% [−31.76%, −7.52%] |
| B/C | −25.72% | −30.03% [−39.55%, −19.83%] | −26.76% [−37.19%, −15.19%] |
| C/A | +0.79% | +8.02% [−4.70%, +23.85%] | +7.85% [−5.89%, +24.60%] |

B is faster in 21/24 wall blocks versus A and 22/24 versus C. The same-code
geometric estimate is noisy, but the candidate beats both independent baselines
with intervals below zero. No outliers are excluded. These intervals describe
paired blocks on this machine and do not cover a different JS engine or the
browser's full import.

## Separate common-score controls

These controls replace scores while retaining cloned actual reference layouts
and row counts. They are explicitly synthetic, never a VNDB capture and never
pooled with actual JMdict. Every output matches across A/B/C, and every arm has
zero ordinary Map.get calls.

| Scenario | Wall medians A / B / C, ms | Paired median B/A / B/C | Interpretation |
| --- | ---: | ---: | --- |
| Uniform score zero | 4.669 / 4.975 / 5.042 | +5.45% / +2.95% | A small slowdown is possible; every paired interval includes zero. |
| All scores in −256…255 | 4.929 / 5.054 / 5.049 | +1.70% / −2.01% | No resolved effect; every paired interval includes zero. |

Uniform-zero geometric wall intervals are [−5.78%, +11.37%] for B/A and
[−17.10%, +10.17%] for B/C. All-in-range intervals are [−7.61%, +15.48%] and
[−8.80%, +14.78%]. These do not establish non-regression. A separately frozen
source refinement may address the concrete extra common-row branch, but this
completed v1 source and all observations remain unchanged.

## Acquisition and reproduction

Each scenario has two excluded warmup blocks and 24 fixed balanced A/B/C blocks,
four complete corpora per observation. `observations.jsonl` preserves every
observation; scenario JSON includes all warmups and measured values.
`correctness.jsonl` preserves output hashes and activation counts.
`bootstrap-analysis.json` uses the frozen NumPy PCG64 seed 20261128, 100,000
paired-block resamples and linear 95% percentile endpoints. All 24 blocks remain.

The run completes with peak process RSS 254,252 KiB. `complete.json` and the
post-run identity checks confirm successful completion. Scripts, the exact
prospective text and review receipt are in `../encoder-inputs-plan`; capture
manifest/binaries are in `../actual-encoder-inputs`. The exclusive acquisition
marker prevents replacing this cohort. Do not rerun into this directory or pool
with a revised candidate.
