# Independent review of the fresh-child native protocol

Reviewed before candidate registration or observation acquisition. The original
draft remains preserved separately. Final reviewed unreferenced Git blobs in
`ManabiIO/manabitan` are:

| File | Git blob |
| --- | --- |
| protocol.mjs | `3a09ee9ba2238c7505f9d10d5208606d820ed208` |
| child.mjs | `09c5157be07bc3b608f3f472fec37d9b96c2a411` |
| controller.mjs | `33f6d3a668033478146a5a3a846a3478d6ea1a94` |

## Finding corrected before approval

The first draft bound only seven source/native files. Its measured parser also
imports other baseline JavaScript modules, which could otherwise change without
tripping those guards. V2 inventories the actual baseline `ext/js`, generated
`ext/lib`, and resolved installed ZIP package, checks tracked runtime/package
cleanliness, and verifies baseline runtime identity before and after every child.
The registration restrictions are also checked again in run mode through
`requireNativePair`. The revised diff resolves this finding.

## Measurement and correctness review

- A and C use exactly the same baseline JavaScript/native bytes. B changes the
  chosen native module while using baseline JavaScript. Each observation has a
  fresh process with one persistent WASM instance and a complete excluded warmup.
- The six permutations balance arm positions. The registered schedule contains
  exactly eighteen sequential children and is checked again when run.
- Timers and phase CPU readings finish before owned-result copies or hashing.
  Source I/O, module setup and the warmup are excluded. The raw WASM source view
  is consumed for verification before the next parser reset can invalidate it.
- Both passes check every source group, row count, raw source digest and complete
  parser output against frozen baseline witnesses. Whole-corpus canonical/raw/
  output digests and fused-route invariants must also agree.
- Signals, timeouts, nonzero exits, missing reports and failed assertions stop
  the campaign. Partial group logs and child exits remain available. The
  exclusive acquisition-start marker prevents replacing a failed observation
  with another run in the same registered cohort.
- Whole-child CPU/RSS and diagnostic corpus wall time are labeled separately.
  Native phase timings overlap in places and are not additive. These results
  cannot be interpreted as worker-parallel or complete browser import gains.

No further blocker was found in the reviewed source. This approves the protocol
for a separately frozen candidate; it does not certify a future observation,
candidate correctness, performance improvement, or complete-import qualification.
No observations were executed as part of this independent review.
