"""Sample the discovered Chromium process tree without filtering child titles.

The sampling window includes startup, import, semantic readback and restart.
These are diagnostic, non-atomic observations, never authoritative timings or
complete peak-memory measurements. No privilege escalation is attempted.
"""

import errno
import json
import os
from pathlib import Path
import re
import subprocess
import time


BROWSER_NAMES = {"chrome", "chromium", "chromium-browser", "chrome-headless-shell"}
GONE_ERRORS = {errno.ENOENT, errno.ESRCH}


def read_error(error, field, pid):
    return {"pid": pid, "field": field, "error": type(error).__name__,
            "errno": getattr(error, "errno", None), "message": str(error)}


def process_inventory(proc=Path("/proc")):
    """Read identities and parentage independently of executable/title access."""
    processes = {}
    failures = []
    for directory in proc.iterdir():
        if not directory.name.isdigit():
            continue
        pid = int(directory.name)
        try:
            # comm may contain spaces and parentheses; fields begin after its
            # final closing parenthesis. Start time prevents ordinary PID reuse.
            fields = (directory / "stat").read_text(errors="replace").rsplit(")", 1)[1].split()
            process = {"pid": pid, "parentPid": int(fields[1]),
                       "startTimeTicks": int(fields[19]), "state": fields[0],
                       "executable": None, "comm": None, "argv": None,
                       "metadataReadErrors": []}
        except (OSError, ValueError, IndexError) as error:
            failures.append(read_error(error, "stat", pid))
            continue
        for field, reader in (
            ("executable", lambda: os.readlink(directory / "exe")),
            ("comm", lambda: (directory / "comm").read_text(errors="replace").rstrip("\n")),
            ("argv", lambda: [part.decode(errors="replace") for part in
                              (directory / "cmdline").read_bytes().rstrip(b"\0").split(b"\0")]),
        ):
            try:
                process[field] = reader()
            except OSError as error:
                process["metadataReadErrors"].append(read_error(error, field, pid))
        processes[pid] = process
    return {"processes": processes, "identityReadErrors": failures}


def descendants(seeds, processes):
    selected = set(seeds)
    while True:
        expanded = selected | {pid for pid, process in processes.items()
                               if process["parentPid"] in selected}
        if expanded == selected:
            return selected
        selected = expanded


def browser_identity(process):
    executable = process["executable"]
    if executable is not None:
        # Linux appends this suffix when an open executable has been removed.
        return "exe" if Path(executable.removesuffix(" (deleted)")).name in BROWSER_NAMES else None
    argv = process["argv"]
    if argv and argv[0]:
        # Chromium can rewrite argv[0] to include its arguments. This fallback
        # is only needed when /proc/PID/exe cannot be read.
        first_word = argv[0].split()[0]
        if Path(argv[0]).name in BROWSER_NAMES or Path(first_word).name in BROWSER_NAMES:
            return "argv0-fallback"
    return None


def process_role(process, is_browser_seed):
    command = " ".join(process["argv"] or [])
    match = re.search(r"(?:^|\s)--type(?:=|\s+)([^\s]+)", command)
    if match:
        return match.group(1)
    if is_browser_seed:
        return "browser"
    return "descendant-unknown"


def discover_tree(root_pid, inventory):
    processes = inventory["processes"]
    runner_descendants = descendants({root_pid}, processes)
    seeds = {pid: browser_identity(processes[pid]) for pid in runner_descendants if pid in processes}
    seeds = {pid: reason for pid, reason in seeds.items() if reason is not None}
    selected = descendants(seeds, processes)
    records = []
    for pid in sorted(selected):
        if pid not in processes:
            continue
        process = processes[pid]
        records.append({**process, "browserSeedMatch": seeds.get(pid),
                        "role": process_role(process, pid in seeds)})
    return {"processes": records, "browserSeedPids": sorted(seeds),
            "runnerDescendantPids": sorted(pid for pid in runner_descendants if pid in processes),
            "inventoryIdentityReadErrors": inventory["identityReadErrors"]}


def read_smaps(pid, proc=Path("/proc")):
    values = {}
    for line in (proc / str(pid) / "smaps_rollup").read_text().splitlines():
        key, _, value = line.partition(":")
        if key not in {"Pss", "Rss", "Private_Clean", "Private_Dirty"}:
            continue
        parts = value.split()
        if len(parts) != 2 or parts[1] != "kB":
            raise ValueError("Unexpected smaps_rollup units")
        number = int(parts[0])
        if number < 0:
            raise ValueError("Negative smaps_rollup value")
        values[key] = number
    return {"pssKiB": values["Pss"], "rssKiB": values["Rss"],
            "privateKiB": values["Private_Clean"] + values["Private_Dirty"]}


def tree_signature(tree):
    return [(p["pid"], p["startTimeTicks"], p["parentPid"], p["executable"],
             p["comm"], p["argv"], p["role"]) for p in tree["processes"]]


def sample_memory(root_pid, proc=Path("/proc")):
    started = time.time()
    before = discover_tree(root_pid, process_inventory(proc))
    values = []
    unavailable = []
    for process in before["processes"]:
        pid = process["pid"]
        try:
            values.append({**process, **read_smaps(pid, proc)})
        except (OSError, ValueError, KeyError, IndexError) as error:
            unavailable.append({**process, "smapsReadError": read_error(error, "smaps_rollup", pid)})
    after = discover_tree(root_pid, process_inventory(proc))
    stable = tree_signature(before) == tree_signature(after)
    identity_errors = before["inventoryIdentityReadErrors"] + after["inventoryIdentityReadErrors"]
    persistent_identity_errors = [item for item in identity_errors if item["errno"] not in GONE_ERRORS]
    roles = {value["role"] for value in values}
    reasons = []
    if not before["browserSeedPids"]:
        reasons.append("no-browser-seed")
    if len(values) < 2:
        reasons.append("no-multiple-process-coverage")
    if "browser" not in roles:
        reasons.append("no-readable-browser-process")
    if "renderer" not in roles:
        reasons.append("no-readable-renderer-process")
    if not stable:
        reasons.append("process-tree-changed-during-scan")
    if unavailable:
        reasons.append("unreadable-discovered-process-smaps")
    if persistent_identity_errors:
        reasons.append("incomplete-process-identity-inventory")
    return {"startedAtEpochSeconds": started, "finishedAtEpochSeconds": time.time(),
            "processes": values, "unavailableProcesses": unavailable,
            "discoveryBefore": before, "discoveryAfter": after,
            "stableObservedProcessTree": stable, "observedRoles": sorted(roles),
            "qualifiedForWholeTreePss": not reasons, "qualificationFailures": reasons,
            # These sums are explicitly partial unless qualification passes.
            "readableProcessPssKiB": sum(value["pssKiB"] for value in values),
            "readableProcessPrivateKiB": sum(value["privateKiB"] for value in values)}


def summarize_samples(samples, exit_code):
    covered = [sample for sample in samples if sample["qualifiedForWholeTreePss"]]
    failures = []
    if exit_code != 0:
        failures.append("benchmark-command-failed")
    if not covered:
        failures.append("no-stable-fully-read-browser-renderer-tree")
    # A process that exits during a scan invalidates that sample. Denied reads
    # or missing reads in an otherwise stable tree invalidate the entire run;
    # they cannot silently disappear from a reported whole-tree maximum.
    unreadable_stable = [sample for sample in samples
                         if sample["stableObservedProcessTree"] and sample["unavailableProcesses"]]
    denied = [item for sample in samples for item in sample["unavailableProcesses"]
              if item["smapsReadError"]["errno"] not in GONE_ERRORS]
    if unreadable_stable or denied:
        failures.append("process-smaps-coverage-unqualified")
    if any("incomplete-process-identity-inventory" in sample["qualificationFailures"] for sample in samples):
        failures.append("process-identity-coverage-unqualified")
    qualified = not failures
    return {
        "schemaVersion": 1,
        "scope": "Discovered Chromium process trees during startup, import, semantic readback and restart",
        "authoritativeTiming": False,
        "sampling": "Linux /proc smaps_rollup PSS; 100ms wait between scans; PID, start-time, parentage and process metadata checked before and after each scan",
        "limitations": [
            "Non-atomic sampled observations; processes and memory can change between individual reads.",
            "Short-lived processes between scans and processes reparented before discovery can be missed.",
            "Only stable fully read trees containing browser and renderer processes contribute; this is not a complete peak measurement.",
            "PSS apportions shared mappings; changing external sharers can affect it. Private bytes are reported separately.",
            "The window includes startup, readback and browser restart, not just import.",
        ],
        "benchmarkExitCode": exit_code,
        "qualifiedForWholeTreePss": qualified,
        "qualificationFailures": failures,
        "sampleCount": len(samples),
        "stableFullyReadTreeSampleCount": len(covered),
        "observedProcessCountRange": [min((len(s["processes"]) for s in covered), default=0),
                                      max((len(s["processes"]) for s in covered), default=0)],
        "samplesWithUnavailableSmaps": sum(bool(s["unavailableProcesses"]) for s in samples),
        "maxSampledPssKiB": max((s["readableProcessPssKiB"] for s in covered), default=None) if qualified else None,
        "maxSampledPrivateKiB": max((s["readableProcessPrivateKiB"] for s in covered), default=None) if qualified else None,
        "samples": samples,
    }


def run_with_sampling(args, cwd, log, receipt):
    samples = []
    with log.open("x") as stream:
        process = subprocess.Popen(args, cwd=cwd, stdout=stream, stderr=subprocess.STDOUT)
        while process.poll() is None:
            samples.append(sample_memory(process.pid))
            try:
                process.wait(timeout=0.1)
            except subprocess.TimeoutExpired:
                pass
    summary = summarize_samples(samples, process.returncode)
    with receipt.open("x") as stream:
        stream.write(json.dumps(summary, indent=2) + "\n")
    # The caller preserves all four predeclared observations, including failed
    # memory qualification. A failure is not retried or replaced.
    return {key: value for key, value in summary.items() if key != "samples"}
