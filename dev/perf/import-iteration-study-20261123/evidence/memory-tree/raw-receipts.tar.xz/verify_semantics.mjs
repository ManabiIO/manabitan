import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readdirSync, readFileSync} from 'node:fs'
import path from 'node:path'

const root = process.argv[2]
assert.ok(root)
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const digest = (value) => sha(JSON.stringify(value))
const fixtures = JSON.parse(readFileSync(path.join(root, 'source/harness/test/perf/dictionaries.lock.json'))).dictionaries
function walk(directory) {
  return readdirSync(directory, {withFileTypes: true}).flatMap((item) => {
    const filename = path.join(directory, item.name)
    assert.equal(item.isSymbolicLink(), false)
    return item.isDirectory() ? walk(filename) : [filename]
  })
}
const reports = []
const failures = []
const semanticByCorpus = new Map()
for (const filename of walk(path.join(root, 'artifacts')).filter((name) => name.endsWith('/run-1.json')).sort()) {
  const relative = path.relative(root, filename)
  const match = /(?:^|\/)(jmdict|jitendex|vndb)\/([12])\/memory-(\d\d)-([AB])\/run-1\.json$/.exec(relative)
  assert.ok(match, relative)
  const [, corpus, replication, index, arm] = match
  const bytes = readFileSync(filename)
  const report = JSON.parse(bytes)
  const row = {path: relative, sha256: sha(bytes), corpus, replication: Number(replication), index: Number(index), arm}
  try {
    assert.equal(report.status, 'success')
    assert.equal(report.skippedVerification, false)
    const validation = report.benchmark.validation
    const fixture = fixtures[corpus]
    assert.equal(validation.title, fixture.expectedTitle)
    assert.equal(validation.revision, fixture.revision)
    assert.equal(validation.termRows, fixture.termRows)
    if (fixture.mediaRows !== undefined) assert.equal(validation.mediaRows, fixture.mediaRows)
    const before = report.benchmark.readbackDiagnostics.preRestart
    const after = report.benchmark.readbackDiagnostics.postRestart
    assert.equal(digest(before.semanticProbes), before.semanticDigestSha256)
    assert.equal(digest(after.semanticProbes), after.semanticDigestSha256)
    assert.equal(digest(before.physicalProbes), before.physicalDigestSha256)
    assert.equal(digest(after.physicalProbes), after.physicalDigestSha256)
    assert.equal(JSON.stringify(before.semanticProbes), JSON.stringify(after.semanticProbes))
    assert.equal(JSON.stringify(before.physicalProbes), JSON.stringify(after.physicalProbes))
    assert.equal(JSON.stringify(before.semanticProbes), JSON.stringify(validation.semanticProbes))
    assert.equal(JSON.stringify(before.physicalProbes), JSON.stringify(validation.physicalProbes))
    assert.equal(before.semanticDigestSha256, validation.semanticDigestSha256)
    assert.equal(before.physicalDigestSha256, validation.outputDigestSha256)
    assert.equal(validation.semanticProbes.length, validation.probeCount)
    assert.ok(validation.probeCount >= 12)
    assert.deepEqual(validation.semanticProbes.map((item) => item.term), validation.probeTerms)
    const semanticBytes = JSON.stringify(before.semanticProbes)
    if (semanticByCorpus.has(corpus)) assert.equal(semanticBytes, semanticByCorpus.get(corpus))
    else semanticByCorpus.set(corpus, semanticBytes)
    let entries = 0
    for (const {result} of validation.semanticProbes) {
      assert.ok(Array.isArray(result.dictionaryEntries) && result.dictionaryEntries.length > 0)
      assert.equal(result.dictionaryAvailability?.length ?? 0, 0)
      entries += result.dictionaryEntries.length
    }
    assert.equal(entries, validation.semanticProbeEntryCount)
    Object.assign(row, {passed: true, probes: validation.probeCount, entries,
      semanticDigestSha256: before.semanticDigestSha256, physicalDigestSha256: before.physicalDigestSha256})
  } catch (error) {
    Object.assign(row, {passed: false, error: String(error)})
    failures.push({path: relative, error: String(error)})
  }
  reports.push(row)
}
if (reports.length !== 24) failures.push({error: `Expected 24 reports; found ${reports.length}`})
console.log(JSON.stringify({authoritativeTiming: false, expectedReportCount: 24,
  reportCount: reports.length, passed: failures.length === 0, reports, failures}, null, 2))
