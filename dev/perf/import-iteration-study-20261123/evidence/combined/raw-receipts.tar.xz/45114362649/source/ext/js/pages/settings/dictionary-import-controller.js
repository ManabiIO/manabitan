/*
 * Copyright (C) 2023-2025  Yomitan Authors
 * Copyright (C) 2020-2022  Yomichan Authors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import {ExtensionError} from '../../core/extension-error.js';
import {reportDiagnostics} from '../../core/diagnostics-reporter.js';
import {parseJson, readResponseJson} from '../../core/json.js';
import {log} from '../../core/log.js';
import {safePerformance} from '../../core/safe-performance.js';
import {toError} from '../../core/to-error.js';
import {querySelectorNotNull} from '../../dom/query-selector.js';
import {Mdx} from '../../comm/mdx.js';
import {createMdictImportSources, compareMddImportPaths, resolveMddImportKey} from '../../dictionary/mdict-import-sources.js';
import {appendMdictConversionWarnings} from './mdict-import-feedback.js';
import {snapshotTermBankExperiments} from '../../dictionary/term-bank-experiments.js';
import {DictionaryController} from './dictionary-controller.js';

const OPFS_REQUIRED_USER_MESSAGE = 'Manabitan requires OPFS storage support.';
const MDX_CONVERSION_PROGRESS_TOTAL = 1000;
const MDX_UPLOAD_PROGRESS_RATIO = 0.45;

/**
 * @typedef {object} ZipImportSource
 * @property {'zip'} type
 * @property {File} file
 */

/**
 * @typedef {object} MdxImportSource
 * @property {'mdx'} type
 * @property {File} mdxFile
 * @property {File[]} mddFiles
 */

/**
 * @typedef {ZipImportSource|MdxImportSource} DictionaryImportSource
 */

/**
 * @typedef {{phaseTimings?: Array<{phase: string, elapsedMs: number, details?: Record<string, string|number|boolean|null>}>|null}} ImporterDebugPayload
 */

/**
 * @typedef {{usesFallbackStorage?: boolean, openStorageDiagnostics?: unknown, useImportSession?: boolean, finalizeImportSession?: boolean, importerDebug?: ImporterDebugPayload|null}} ImportResultDebugPayload
 */

/**
 * @typedef {import('dictionary-importer').ImportResult & {debug?: ImportResultDebugPayload}} ImportResultWithDebug
 */

/**
 * Page-side work which must not be published until every worker import in the
 * shared import session has returned.
 * @typedef {object} DeferredDictionaryFinalization
 * @property {string} dictionaryTitle
 * @property {number} importStartTime
 * @property {import('dictionary-importer').ImportDetails} importDetails
 * @property {ImportResultWithDebug} importResult
 * @property {number} workerImportStartTime
 * @property {number} workerImportEndTime
 * @property {boolean} useImportSession
 * @property {boolean} finalizeImportSession
 * @property {number} importRunGeneration
 * @property {import('settings-controller').ProfilesDictionarySettings} profilesDictionarySettings
 * @property {Array<{phase: string, elapsedMs: number, startEpochMs?: number, endEpochMs?: number, details?: Record<string, string|number|boolean|null>}>} localPhaseTimings
 * @property {boolean} workerResultAlreadyRecorded
 */

/**
 * @param {string} fileName
 * @returns {string}
 */
function getLowercaseFileName(fileName) {
    return fileName.replaceAll('\\', '/').toLowerCase();
}

/**
 * @param {string} fileName
 * @returns {boolean}
 */
function isZipDictionaryFileName(fileName) {
    return getLowercaseFileName(fileName).endsWith('.zip');
}

/**
 * @param {string} fileName
 * @returns {boolean}
 */
function isMdxDictionaryFileName(fileName) {
    return getLowercaseFileName(fileName).endsWith('.mdx');
}

/**
 * @param {string} url
 * @returns {string|null}
 */
function getDictionaryFileNameFromUrl(url) {
    try {
        const parsed = new URL(url);
        const pathName = decodeURIComponent(parsed.pathname);
        const segments = pathName.split('/');
        const fileName = segments.length > 0 ? segments[segments.length - 1] : '';
        return fileName.length > 0 ? fileName : null;
    } catch (_error) {
        return null;
    }
}

/**
 * @param {number} valueMs
 * @returns {string}
 */
function formatDurationMs(valueMs) {
    return `${valueMs.toFixed(1)}ms`;
}

/**
 * @returns {{source: 'performance.memory'|'unavailable', usedJSHeapSize: number|null, totalJSHeapSize: number|null, jsHeapSizeLimit: number|null, usedHeapPercent: number|null}}
 */
function getImportMemorySnapshot() {
    const performanceValue = Reflect.get(globalThis, 'performance');
    if (!(typeof performanceValue === 'object' && performanceValue !== null)) {
        return {
            source: 'unavailable',
            usedJSHeapSize: null,
            totalJSHeapSize: null,
            jsHeapSizeLimit: null,
            usedHeapPercent: null,
        };
    }
    const memoryValue = Reflect.get(/** @type {Record<string, unknown>} */ (/** @type {unknown} */ (performanceValue)), 'memory');
    if (!(typeof memoryValue === 'object' && memoryValue !== null)) {
        return {
            source: 'unavailable',
            usedJSHeapSize: null,
            totalJSHeapSize: null,
            jsHeapSizeLimit: null,
            usedHeapPercent: null,
        };
    }
    const memoryRecord = /** @type {Record<string, unknown>} */ (memoryValue);
    const usedJSHeapSizeRaw = Reflect.get(memoryRecord, 'usedJSHeapSize');
    const totalJSHeapSizeRaw = Reflect.get(memoryRecord, 'totalJSHeapSize');
    const jsHeapSizeLimitRaw = Reflect.get(memoryRecord, 'jsHeapSizeLimit');
    const usedJSHeapSize = typeof usedJSHeapSizeRaw === 'number' && Number.isFinite(usedJSHeapSizeRaw) ? usedJSHeapSizeRaw : null;
    const totalJSHeapSize = typeof totalJSHeapSizeRaw === 'number' && Number.isFinite(totalJSHeapSizeRaw) ? totalJSHeapSizeRaw : null;
    const jsHeapSizeLimit = typeof jsHeapSizeLimitRaw === 'number' && Number.isFinite(jsHeapSizeLimitRaw) ? jsHeapSizeLimitRaw : null;
    let usedHeapPercent = null;
    if (
        usedJSHeapSize !== null &&
        totalJSHeapSize !== null &&
        totalJSHeapSize > 0
    ) {
        usedHeapPercent = (usedJSHeapSize / totalJSHeapSize) * 100;
    }
    return {
        source: 'performance.memory',
        usedJSHeapSize,
        totalJSHeapSize,
        jsHeapSizeLimit,
        usedHeapPercent,
    };
}

/**
 * @param {{source: 'performance.memory'|'unavailable', usedJSHeapSize: number|null}} start
 * @param {{source: 'performance.memory'|'unavailable', usedJSHeapSize: number|null}} end
 * @returns {number|null}
 */
function getHeapDeltaBytes(start, end) {
    if (start.source !== 'performance.memory' || end.source !== 'performance.memory') { return null; }
    if (typeof start.usedJSHeapSize !== 'number' || typeof end.usedJSHeapSize !== 'number') { return null; }
    return end.usedJSHeapSize - start.usedJSHeapSize;
}

/**
 * @param {unknown} value
 * @returns {Array<{phase: string, elapsedMs: number, startEpochMs?: number, endEpochMs?: number, details?: Record<string, string|number|boolean|null>}>}
 */
function normalizeImporterPhaseTimings(value) {
    if (!Array.isArray(value)) { return []; }
    /** @type {Array<{phase: string, elapsedMs: number, startEpochMs?: number, endEpochMs?: number, details?: Record<string, string|number|boolean|null>}>} */
    const results = [];
    for (const item of value) {
        if (!(typeof item === 'object' && item !== null && !Array.isArray(item))) {
            continue;
        }
        const phaseRaw = /** @type {unknown} */ (Reflect.get(item, 'phase'));
        const elapsedMsRaw = /** @type {unknown} */ (Reflect.get(item, 'elapsedMs'));
        const detailsRaw = /** @type {unknown} */ (Reflect.get(item, 'details'));
        const startEpochMsRaw = /** @type {unknown} */ (Reflect.get(item, 'startEpochMs'));
        const endEpochMsRaw = /** @type {unknown} */ (Reflect.get(item, 'endEpochMs'));
        if (typeof phaseRaw !== 'string' || typeof elapsedMsRaw !== 'number' || !Number.isFinite(elapsedMsRaw)) {
            continue;
        }
        if (typeof detailsRaw === 'object' && detailsRaw !== null && !Array.isArray(detailsRaw)) {
            results.push({
                phase: phaseRaw,
                elapsedMs: Math.max(0, elapsedMsRaw),
                ...(typeof startEpochMsRaw === 'number' && Number.isFinite(startEpochMsRaw) ? {startEpochMs: startEpochMsRaw} : {}),
                ...(typeof endEpochMsRaw === 'number' && Number.isFinite(endEpochMsRaw) ? {endEpochMs: endEpochMsRaw} : {}),
                details: /** @type {Record<string, string|number|boolean|null>} */ (detailsRaw),
            });
            continue;
        }
        results.push({
            phase: phaseRaw,
            elapsedMs: Math.max(0, elapsedMsRaw),
            ...(typeof startEpochMsRaw === 'number' && Number.isFinite(startEpochMsRaw) ? {startEpochMs: startEpochMsRaw} : {}),
            ...(typeof endEpochMsRaw === 'number' && Number.isFinite(endEpochMsRaw) ? {endEpochMs: endEpochMsRaw} : {}),
        });
    }
    return results;
}

/**
 * @param {string} url
 * @returns {string}
 */
function summarizeUrlForDiagnostics(url) {
    const trimmed = url.trim();
    if (trimmed.startsWith('manabitan-e2e-dict:')) { return trimmed; }
    try {
        const parsed = new URL(trimmed);
        return `${parsed.origin}${parsed.pathname}`;
    } catch (_) {
        return trimmed;
    }
}

/**
 * @param {string} message
 * @returns {boolean}
 */
function isOpfsUnavailableMessage(message) {
    return (
        message.includes('OPFS is required') ||
        message.includes('OPFS unlink API is unavailable') ||
        message.includes('OPFS importDb API is unavailable') ||
        message.includes('no such vfs: opfs') ||
        message.includes('opfs-sahpool') ||
        message.includes('DedicatedWorkerGlobalScope') ||
        message.includes('createSyncAccessHandle')
    );
}

/**
 * @param {string} message
 * @returns {string}
 */
function getOpfsUnavailableUserMessage(message) {
    const base = OPFS_REQUIRED_USER_MESSAGE;
    const userAgent = typeof navigator?.userAgent === 'string' ? navigator.userAgent : '';
    const isFirefoxRuntime = /Firefox\//i.test(userAgent);
    const storageValue = /** @type {Record<string, unknown>} */ (/** @type {unknown} */ (Reflect.get(navigator ?? {}, 'storage') ?? {}));
    const hasStorageGetDirectoryFallback = typeof Reflect.get(storageValue, 'getDirectory') === 'function';
    const hasCreateSyncAccessHandleFallback = (
        typeof Reflect.get(globalThis, 'FileSystemFileHandle') === 'function' &&
        typeof Reflect.get(
            /** @type {{prototype?: Record<string, unknown>}} */ (/** @type {unknown} */ (Reflect.get(globalThis, 'FileSystemFileHandle'))).prototype ?? {},
            'createSyncAccessHandle',
        ) === 'function'
    );
    const formatFallbackDiagnostics = () => (
        `Runtime diagnostics: storage.getDirectory=${String(hasStorageGetDirectoryFallback)}, ` +
        `createSyncAccessHandle=${String(hasCreateSyncAccessHandleFallback)}.`
    );
    const diagnosticsMatch = message.match(/diagnostics=(\{.*\})/);
    if (diagnosticsMatch === null) {
        if (isFirefoxRuntime) {
            return `${base} This Firefox extension runtime is missing the worker OPFS APIs required for SQLite + opfs-sahpool. ${formatFallbackDiagnostics()}`;
        }
        return `${base} Update to a browser/runtime which exposes worker OPFS SyncAccessHandle support and reload the extension. ${formatFallbackDiagnostics()}`;
    }
    try {
        const diagnostics = parseJson(diagnosticsMatch[1]);
        if (!(typeof diagnostics === 'object' && diagnostics !== null && !Array.isArray(diagnostics))) {
            if (isFirefoxRuntime) {
                return `${base} This Firefox extension runtime is missing the worker OPFS APIs required for SQLite + opfs-sahpool. ${formatFallbackDiagnostics()}`;
            }
            return `${base} Update to a browser/runtime which exposes worker OPFS SyncAccessHandle support and reload the extension. ${formatFallbackDiagnostics()}`;
        }
        const diagnosticsRecord = /** @type {Record<string, unknown>} */ (diagnostics);
        const runtimeContextRaw = Reflect.get(diagnosticsRecord, 'runtimeContext');
        const runtimeContext = (typeof runtimeContextRaw === 'object' && runtimeContextRaw !== null && !Array.isArray(runtimeContextRaw)) ?
            /** @type {Record<string, unknown>} */ (runtimeContextRaw) :
            {};
        const modeRaw = Reflect.get(diagnosticsRecord, 'mode');
        const mode = typeof modeRaw === 'string' ? modeRaw : 'unknown';
        const hasStorageGetDirectoryRaw = Reflect.get(runtimeContext, 'hasStorageGetDirectory');
        const hasStorageGetDirectory = typeof hasStorageGetDirectoryRaw === 'boolean' ? hasStorageGetDirectoryRaw : null;
        const hasCreateSyncAccessHandleRaw = Reflect.get(runtimeContext, 'hasCreateSyncAccessHandle');
        const hasCreateSyncAccessHandle = typeof hasCreateSyncAccessHandleRaw === 'boolean' ? hasCreateSyncAccessHandleRaw : null;
        const opfsSahpoolInstallResultRaw = Reflect.get(diagnosticsRecord, 'opfsSahpoolInstallResult');
        const opfsSahpoolInstallResult = typeof opfsSahpoolInstallResultRaw === 'string' ? opfsSahpoolInstallResultRaw : null;
        const opfsSahpoolInstallErrorRaw = Reflect.get(diagnosticsRecord, 'opfsSahpoolInstallError');
        const opfsSahpoolInstallError = typeof opfsSahpoolInstallErrorRaw === 'string' ? opfsSahpoolInstallErrorRaw : null;
        const opfsSahpoolVfsRaw = Reflect.get(diagnosticsRecord, 'hasOpfsSahpoolVfs');
        const opfsSahpoolVfs = typeof opfsSahpoolVfsRaw === 'boolean' ? opfsSahpoolVfsRaw : null;
        const attemptsRaw = Reflect.get(diagnosticsRecord, 'attempts');
        /** @type {unknown[]} */
        const attempts = Array.isArray(attemptsRaw) ? attemptsRaw : [];
        /** @type {unknown} */
        let lastSahpoolOpenAttempt = null;
        for (let i = attempts.length - 1; i >= 0; --i) {
            const attempt = attempts[i];
            if (!(typeof attempt === 'object' && attempt !== null && !Array.isArray(attempt))) { continue; }
            if (Reflect.get(attempt, 'strategy') !== 'uri-opfs-sahpool' || typeof Reflect.get(attempt, 'error') !== 'string') { continue; }
            lastSahpoolOpenAttempt = attempt;
            break;
        }
        const lastSahpoolOpenErrorRaw = /** @type {unknown} */ ((
            typeof lastSahpoolOpenAttempt === 'object' &&
            lastSahpoolOpenAttempt !== null &&
            !Array.isArray(lastSahpoolOpenAttempt)
        ) ?
            Reflect.get(lastSahpoolOpenAttempt, 'error') :
            null);
        const lastSahpoolOpenError = typeof lastSahpoolOpenErrorRaw === 'string' && lastSahpoolOpenErrorRaw.length > 0 ?
            lastSahpoolOpenErrorRaw :
            null;
        const runtimeUserAgentRaw = Reflect.get(runtimeContext, 'userAgent');
        const runtimeUserAgent = typeof runtimeUserAgentRaw === 'string' ? runtimeUserAgentRaw : '';
        const isFirefoxRuntimeFromDiagnostics = /Firefox\//i.test(runtimeUserAgent) || isFirefoxRuntime;
        let reason = 'Update to a browser/runtime which exposes worker OPFS SyncAccessHandle support and reload the extension.';
        if (isFirefoxRuntimeFromDiagnostics) {
            if (hasStorageGetDirectory !== true) {
                reason = 'This Firefox runtime does not expose navigator.storage.getDirectory() to the extension worker runtime.';
            } else if (hasCreateSyncAccessHandle !== true) {
                reason = 'This Firefox runtime does not expose createSyncAccessHandle() to the extension worker runtime.';
            } else {
                reason = 'This Firefox extension runtime still rejected opfs-sahpool even though the basic worker OPFS APIs are present.';
            }
        } else if (hasStorageGetDirectory !== true) {
            reason = 'This browser runtime does not expose navigator.storage.getDirectory() to the extension worker runtime.';
        } else if (hasCreateSyncAccessHandle !== true) {
            reason = 'This browser runtime does not expose createSyncAccessHandle() to the extension worker runtime.';
        }
        let sahpoolDetails = '';
        if (opfsSahpoolInstallResult !== null || opfsSahpoolVfs !== null || opfsSahpoolInstallError !== null || lastSahpoolOpenError !== null) {
            sahpoolDetails = ` opfs-sahpool: install=${String(opfsSahpoolInstallResult)}, vfs=${String(opfsSahpoolVfs)}, installError=${String(opfsSahpoolInstallError)}, openError=${String(lastSahpoolOpenError)}.`;
        }
        return `${base} ${reason} Runtime diagnostics: mode=${mode}, storage.getDirectory=${String(hasStorageGetDirectory)}, createSyncAccessHandle=${String(hasCreateSyncAccessHandle)}.${sahpoolDetails}`;
    } catch (_) {
        if (isFirefoxRuntime) {
            return `${base} This Firefox extension runtime is missing the worker OPFS APIs required for SQLite + opfs-sahpool. ${formatFallbackDiagnostics()}`;
        }
        return `${base} Update to a browser/runtime which exposes worker OPFS SyncAccessHandle support and reload the extension. ${formatFallbackDiagnostics()}`;
    }
}

/**
 * @returns {{name: string, version: string, id: string}|null}
 */
function getExtensionBuildStamp() {
    try {
        const manifest = chrome.runtime.getManifest();
        const id = typeof chrome.runtime.id === 'string' ? chrome.runtime.id : '';
        return {
            name: typeof manifest.name === 'string' ? manifest.name : '',
            version: typeof manifest.version === 'string' ? manifest.version : '',
            id,
        };
    } catch (_) {
        return null;
    }
}

export class DictionaryImportController {
    /**
     * @param {import('./settings-controller.js').SettingsController} settingsController
     * @param {import('./modal-controller.js').ModalController} modalController
     * @param {import('./status-footer.js').StatusFooter} statusFooter
     */
    constructor(settingsController, modalController, statusFooter) {
        /** @type {import('./settings-controller.js').SettingsController} */
        this._settingsController = settingsController;
        /** @type {import('./modal-controller.js').ModalController} */
        this._modalController = modalController;
        /** @type {import('./status-footer.js').StatusFooter} */
        this._statusFooter = statusFooter;
        /** @type {boolean} */
        this._modifying = false;
        /** @type {Mdx|null} */
        this._activeMdx = null;
        /** @type {HTMLButtonElement} */
        this._purgeButton = querySelectorNotNull(document, '#dictionary-delete-all-button');
        /** @type {HTMLButtonElement} */
        this._purgeConfirmButton = querySelectorNotNull(document, '#dictionary-confirm-delete-all-button');
        /** @type {HTMLButtonElement} */
        this._importFileInput = querySelectorNotNull(document, '#dictionary-import-file-input');
        /** @type {HTMLButtonElement} */
        this._importFileDrop = querySelectorNotNull(document, '#dictionary-drop-file-zone');
        /** @type {number} */
        this._importFileDropItemCount = 0;
        /** @type {HTMLInputElement} */
        this._importButton = querySelectorNotNull(document, '#dictionary-import-button');
        /** @type {HTMLInputElement} */
        this._importConfirmButton = querySelectorNotNull(document, '#dictionary-import-confirm-button');
        /** @type {HTMLInputElement} */
        this._importURLButton = querySelectorNotNull(document, '#dictionary-import-url-button');
        /** @type {HTMLInputElement} */
        this._importURLText = querySelectorNotNull(document, '#dictionary-import-url-text');
        /** @type {HTMLElement} */
        this._importSourceList = querySelectorNotNull(document, '#dictionary-import-source-list');
        /** @type {HTMLElement} */
        this._importSourceEmpty = querySelectorNotNull(document, '#dictionary-import-source-empty');
        /** @type {?import('./modal.js').Modal} */
        this._importModal = null;
        /** @type {?import('./modal.js').Modal} */
        this._purgeConfirmModal = null;
        /** @type {?import('./modal.js').Modal} */
        this._recommendedDictionariesModal = null;
        /** @type {HTMLElement} */
        this._errorContainer = querySelectorNotNull(document, '#dictionary-error');
        /** @type {HTMLElement|null} */
        this._recommendedDiagnosticsContainer = document.querySelector('#recommended-dictionaries-diagnostics');
        /** @type {HTMLElement|null} */
        this._recommendedErrorContainer = document.querySelector('#recommended-dictionaries-error');
        /** @type {boolean} */
        this._showRecommendedDiagnosticsInUi = (Reflect.get(globalThis, 'manabitanShowRecommendedDiagnosticsInUi') === true);
        /** @type {[originalMessage: string, newMessage: string][]} */
        this._errorToStringOverrides = [
            [
                'A mutation operation was attempted on a database that did not allow mutations.',
                'Access to IndexedDB appears to be restricted. Firefox seems to require that the history preference is set to "Remember history" before IndexedDB use of any kind is allowed.',
            ],
            [
                'The operation failed for reasons unrelated to the database itself and not covered by any other error code.',
                'Unable to access IndexedDB due to a possibly corrupt user profile. Try using the "Refresh Firefox" feature to reset your user profile.',
            ],
            [
                'OPFS is required',
                getOpfsUnavailableUserMessage('OPFS is required'),
            ],
            [
                'no such vfs: opfs',
                getOpfsUnavailableUserMessage('no such vfs: opfs'),
            ],
        ];
        /** @type {string[]} */
        this._recommendedDictionaryQueue = [];
        /** @type {boolean} */
        this._recommendedDictionaryActiveImport = false;
        /** @type {string|null} */
        this._recommendedDictionaryCurrentUrl = null;
        /** @type {boolean} */
        this._recommendedDictionariesRenderPending = false;
        /** @type {boolean} */
        this._recommendedDictionariesPrimed = false;
        /** @type {boolean} */
        this._readerInstallJitendex = false;
        /** @type {{queueLength: number, activeImport: boolean, currentUrl: string|null, lastError: string|null}} */
        this._recommendedImportDebugState = {
            queueLength: 0,
            activeImport: false,
            currentUrl: null,
            lastError: null,
        };
        /** @type {number} */
        this._activeImportRunGeneration = 0;
        /** @type {string|undefined} */
        this._activeImportOwnerId = void 0;
        /** @type {DictionaryImportSource[]} */
        this._pendingImportSources = [];
        /** @type {(event: MouseEvent) => void} */
        this._onDocumentClickCaptureBind = this._onDocumentClickCapture.bind(this);
        /** @type {(event: Event) => void} */
        this._onModalVisibilityChangedEventBind = this._onModalVisibilityChangedEvent.bind(this);
        /** @type {(details: {visible: boolean}) => void} */
        this._onRecommendedDictionariesModalVisibilityChangedBind = this._onRecommendedDictionariesModalVisibilityChanged.bind(this);
        reportDiagnostics('dictionary-import-controller-constructed', {
            href: globalThis.location?.href ?? null,
        });
    }

    /** */
    prepare() {
        reportDiagnostics('dictionary-import-controller-prepare-begin', {
            href: globalThis.location?.href ?? null,
        });
        this._importModal = this._modalController.getModal('dictionary-import');
        this._purgeConfirmModal = this._modalController.getModal('dictionary-confirm-delete-all');
        this._recommendedDictionariesModal = this._modalController.getModal('recommended-dictionaries');

        this._purgeButton.addEventListener('click', this._onPurgeButtonClick.bind(this), false);
        this._purgeConfirmButton.addEventListener('click', this._onPurgeConfirmButtonClick.bind(this), false);
        this._importButton.addEventListener('click', this._onImportButtonClick.bind(this), false);
        this._importConfirmButton.addEventListener('click', this._onImportConfirm.bind(this), false);
        this._importURLButton.addEventListener('click', this._onImportFromURL.bind(this), false);
        this._importFileInput.addEventListener('change', this._onImportFileChange.bind(this), false);

        this._importFileDrop.addEventListener('click', this._onImportFileButtonClick.bind(this), false);
        this._importFileDrop.addEventListener('dragenter', this._onFileDropEnter.bind(this), false);
        this._importFileDrop.addEventListener('dragover', this._onFileDropOver.bind(this), false);
        this._importFileDrop.addEventListener('dragleave', this._onFileDropLeave.bind(this), false);
        this._importFileDrop.addEventListener('drop', this._onFileDrop.bind(this), false);

        this._settingsController.on('importDictionaryFromUrl', this._onEventImportDictionaryFromUrl.bind(this));
        this._settingsController.on('importDictionaryFromFile', this._onEventImportDictionaryFromFile.bind(this));
        this._settingsController.on('downloadDictionaryFromUrl', this._onEventDownloadDictionaryFromUrl.bind(this));

        document.addEventListener('click', this._onDocumentClickCaptureBind, true);
        globalThis.addEventListener('manabitan:modal-visibility-changed', this._onModalVisibilityChangedEventBind, false);
        this._recommendedDictionariesModal?.on('visibilityChanged', this._onRecommendedDictionariesModalVisibilityChangedBind);
        globalThis.addEventListener('pagehide', this._onPageHide.bind(this));
        reportDiagnostics('dictionary-import-controller-prepare-complete', {
            hasRecommendedModal: this._recommendedDictionariesModal !== null,
            href: globalThis.location?.href ?? null,
        });
    }

    /** Use the normal recommended-dictionaries modal and import path. */
    openReaderJitendexSetup() {
        this._readerInstallJitendex = true;
        this._recommendedDictionariesModal?.setVisible(true);
    }

    // Private

    /**
     * @param {File} archiveContent
     * @param {import('dictionary-importer').ImportDetails} details
     * @param {?import('dictionary-worker').ImportProgressCallback} onProgress
     * @returns {Promise<ImportResultWithDebug>}
     */
    async _tryImportDictionaryOffscreen(archiveContent, details, onProgress) {
        if (!(archiveContent instanceof Blob)) {
            throw new Error('Dictionary import requires Blob-backed archive content');
        }
        return /** @type {ImportResultWithDebug} */ (
            await this._settingsController.application.api.importDictionaryOffscreen(archiveContent, details, onProgress, `${Date.now()}:${crypto.randomUUID()}`, this._activeImportOwnerId)
        );
    }

    /**
     * @param {string} url
     * @param {import('dictionary-importer').ImportDetails} details
     * @param {?import('dictionary-worker').ImportProgressCallback} onProgress
     * @returns {Promise<ImportResultWithDebug>}
     */
    async _tryImportDictionaryUrlOffscreen(url, details, onProgress) {
        return /** @type {ImportResultWithDebug} */ (
            await this._settingsController.application.api.importDictionaryUrlOffscreen(url, details, onProgress, `${Date.now()}:${crypto.randomUUID()}`, this._activeImportOwnerId)
        );
    }

    /** @param {PageTransitionEvent} event */
    _onPageHide(event) {
        // beforeunload only requests a confirmation: choosing Stay must not
        // cancel an import or consume its eventual page-departure cleanup.
        if (event.persisted && this._modifying) {
            // A cached page can run its old continuations after restoration.
            // Retire that batch and reset its UI before releasing its owner.
            this._forceRecoverHungImportSession(new Error('Dictionary import was interrupted by page navigation.'), 'pagehide');
        } else {
            this._activeImportRunGeneration += 1;
        }
        const ownerId = this._activeImportOwnerId;
        if (typeof ownerId === 'string') {
            this._activeImportOwnerId = void 0;
            void this._settingsController.application.api.setDictionaryImportMode(false, ownerId).catch(() => {});
        }
        this._activeMdx?.disconnect();
        this._activeMdx = null;
        if (event.persisted) { return; }
        document.removeEventListener('click', this._onDocumentClickCaptureBind, true);
        globalThis.removeEventListener('manabitan:modal-visibility-changed', this._onModalVisibilityChangedEventBind, false);
        this._recommendedDictionariesModal?.off('visibilityChanged', this._onRecommendedDictionariesModalVisibilityChangedBind);
    }

    /**
     * @param {{visible: boolean}} details
     */
    _onRecommendedDictionariesModalVisibilityChanged({visible}) {
        if (!visible || this._recommendedDictionariesRenderPending) { return; }
        this._recommendedDictionariesRenderPending = true;
        void this._onRecommendedDictionariesOpen();
    }

    /**
     * @param {MouseEvent} e
     */
    _onDocumentClickCapture(e) {
        const target = e.target;
        if (!(target instanceof Element)) { return; }
        const actionNode = target.closest('[data-modal-action="show,recommended-dictionaries"]');
        if (!(actionNode instanceof HTMLElement)) { return; }
        reportDiagnostics('recommended-dictionaries-click-capture', {
            pending: this._recommendedDictionariesRenderPending,
            href: globalThis.location?.href ?? null,
        });
        if (this._recommendedDictionariesRenderPending) { return; }
        this._recommendedDictionariesRenderPending = true;
        void this._onRecommendedDictionariesOpen();
    }

    /**
     * @param {Event} event
     */
    _onModalVisibilityChangedEvent(event) {
        if (!(event instanceof CustomEvent)) { return; }
        const detail = /** @type {unknown} */ (event.detail);
        if (!(typeof detail === 'object' && detail !== null)) { return; }
        if (Reflect.get(detail, 'modalId') !== 'recommended-dictionaries') { return; }
        if (Reflect.get(detail, 'visible') !== true) { return; }
        reportDiagnostics('recommended-dictionaries-modal-visibility-listener', {
            pending: this._recommendedDictionariesRenderPending,
            source: Reflect.get(detail, 'source'),
            animate: Reflect.get(detail, 'animate'),
            href: globalThis.location?.href ?? null,
        });
        if (this._recommendedDictionariesRenderPending) { return; }
        reportDiagnostics('recommended-dictionaries-modal-visible-event', {
            source: Reflect.get(detail, 'source'),
            animate: Reflect.get(detail, 'animate'),
        });
        this._recommendedDictionariesRenderPending = true;
        void this._onRecommendedDictionariesOpen();
    }

    /**
     * @param {string} source
     */
    _primeRecommendedDictionaries(source) {
        if (this._recommendedDictionariesPrimed || this._recommendedDictionariesRenderPending) { return; }
        this._recommendedDictionariesRenderPending = true;
        const startedAt = safePerformance.now();
        reportDiagnostics('recommended-dictionaries-prime-begin', {
            source,
            href: globalThis.location?.href ?? null,
        });
        void (async () => {
            try {
                await this._renderRecommendedDictionaries();
                this._recommendedDictionariesPrimed = true;
                reportDiagnostics('recommended-dictionaries-prime-complete', {
                    source,
                    elapsedMs: Math.max(0, safePerformance.now() - startedAt),
                });
            } catch (error) {
                const e = toError(error);
                reportDiagnostics('recommended-dictionaries-prime-failed', {
                    source,
                    message: e.message,
                });
                log.error(e);
            } finally {
                this._recommendedDictionariesRenderPending = false;
            }
        })();
    }

    /**
     * @param {MouseEvent} e
     */
    async _onRecommendedImportClick(e) {
        const button = (
            e.currentTarget instanceof HTMLButtonElement ?
            e.currentTarget :
            (e.target instanceof HTMLButtonElement ? e.target : null)
        );
        if (button === null) {
            reportDiagnostics('recommended-dictionaries-import-click-ignored', {
                reason: 'target-not-button',
                targetType: typeof e.target,
            });
            return;
        }

        const import_url = button.attributes.getNamedItem('data-import-url');
        if (!import_url) {
            reportDiagnostics('recommended-dictionaries-import-click-ignored', {
                reason: 'missing-data-import-url',
                buttonText: button.textContent ?? '',
            });
            return;
        }
        const importUrl = import_url.value;
        if (importUrl.length === 0) {
            reportDiagnostics('recommended-dictionaries-import-click-ignored', {
                reason: 'empty-data-import-url',
                buttonText: button.textContent ?? '',
            });
            return;
        }
        if (this._modifying && !this._recommendedDictionaryActiveImport) {
            this._setRecommendedError('A dictionary operation is in progress. Wait for it to finish, then try again.');
            return;
        }
        if (this._isRecommendedImportQueuedOrActive(importUrl)) {
            button.disabled = true;
            reportDiagnostics('recommended-dictionaries-import-click-deduplicated', {
                importUrl: summarizeUrlForDiagnostics(importUrl),
                queueLength: this._recommendedDictionaryQueue.length,
                activeImport: this._recommendedDictionaryActiveImport,
            });
            return;
        }
        this._recommendedDictionaryQueue.push(importUrl);
        this._updateRecommendedImportDebugState({
            queueLength: this._recommendedDictionaryQueue.length,
            lastError: null,
        });

        button.disabled = true;
        reportDiagnostics('recommended-dictionaries-import-clicked', {
            importUrl: summarizeUrlForDiagnostics(importUrl),
            queueLength: this._recommendedDictionaryQueue.length,
        });

        if (this._recommendedDictionaryActiveImport) { return; }

        this._recommendedDictionaryActiveImport = true;
        this._updateRecommendedImportDebugState({
            activeImport: true,
        });
        try {
            while (this._recommendedDictionaryQueue.length > 0) {
                const url = this._recommendedDictionaryQueue[0];
                if (!url) {
                    void this._recommendedDictionaryQueue.shift();
                    this._updateRecommendedImportDebugState({
                        queueLength: this._recommendedDictionaryQueue.length,
                    });
                    continue;
                }
                this._clearRecommendedError();
                this._updateRecommendedImportDebugState({
                    currentUrl: summarizeUrlForDiagnostics(url),
                    queueLength: this._recommendedDictionaryQueue.length,
                    lastError: null,
                });
                this._recommendedDictionaryCurrentUrl = url;
                reportDiagnostics('recommended-dictionaries-import-queue-item-start', {
                    importUrl: summarizeUrlForDiagnostics(url),
                    queueLength: this._recommendedDictionaryQueue.length,
                });

                try {
                    const importProgressTracker = new ImportProgressTracker(this._getUrlImportSteps(), 1);
                    let importSucceeded = false;
                    /** @type {Error[]} */
                    let importErrors = [];
                    await this._runImportWithWatchdog(
                        this._importDictionaries(
                            this._getUrlImportSources([url], importProgressTracker.onProgress.bind(importProgressTracker)),
                            null,
                            ({ok, errors}) => {
                                importSucceeded = ok;
                                importErrors = errors;
                            },
                            importProgressTracker,
                        ),
                        `Recommended dictionary import (${summarizeUrlForDiagnostics(url)})`,
                        importProgressTracker,
                    );
                    if (!importSucceeded) {
                        throw new Error(importErrors.map((error) => this._errorToString(error)).join('\n') || 'Dictionary import failed.');
                    }
                } catch (error) {
                    const e2 = toError(error);
                    log.error(e2);
                    this._showErrors([e2]);
                    this._setRecommendedError(this._errorToString(e2));
                    this._updateRecommendedImportDebugState({
                        lastError: e2.message,
                    });
                    reportDiagnostics('recommended-dictionaries-import-failed', {
                        importUrl: summarizeUrlForDiagnostics(url),
                        message: e2.message,
                    });
                    this._setRecommendedImportButtonDisabled(url, false);
                } finally {
                    void this._recommendedDictionaryQueue.shift();
                    this._recommendedDictionaryCurrentUrl = null;
                    this._updateRecommendedImportDebugState({
                        queueLength: this._recommendedDictionaryQueue.length,
                        currentUrl: this._recommendedDictionaryQueue[0] ? summarizeUrlForDiagnostics(this._recommendedDictionaryQueue[0]) : null,
                    });
                    reportDiagnostics('recommended-dictionaries-import-queue-item-finished', {
                        importUrl: summarizeUrlForDiagnostics(url),
                        queueLength: this._recommendedDictionaryQueue.length,
                    });
                }
            }
        } finally {
            this._recommendedDictionaryActiveImport = false;
            this._recommendedDictionaryCurrentUrl = null;
            this._updateRecommendedImportDebugState({
                activeImport: false,
                currentUrl: null,
                queueLength: this._recommendedDictionaryQueue.length,
            });
            reportDiagnostics('recommended-dictionaries-import-queue-idle', {
                queueLength: this._recommendedDictionaryQueue.length,
            });
        }
    }

    /**
     * @returns {Promise<void>}
     */
    async _onRecommendedDictionariesOpen() {
        const startedAt = safePerformance.now();
        log.log('[recommended-dictionaries] open requested');
        const buildStamp = getExtensionBuildStamp();
        let buildStampText = 'build=unknown';
        if (buildStamp !== null) {
            buildStampText = `build=${buildStamp.name} v${buildStamp.version} id=${buildStamp.id}`;
        }
        this._clearRecommendedError();
        this._setRecommendedDiagnostics(`${buildStampText}\nLoading recommended dictionaries...`);
        reportDiagnostics('recommended-dictionaries-open-requested', {
            buildStamp,
        });
        try {
            await this._renderRecommendedDictionaries();
            const endedAt = safePerformance.now();
            log.log(`[recommended-dictionaries] render completed in ${formatDurationMs(endedAt - startedAt)}`);
        } catch (error) {
            const e = toError(error);
            log.error(e);
            const userError = this._errorToString(e);
            this._setRecommendedError(userError);
            this._setRecommendedDiagnostics(`FAILED to render recommended dictionaries:\n${e.message}`);
            reportDiagnostics('recommended-dictionaries-open-failed', {
                message: e.message,
            });
            if (!isOpfsUnavailableMessage(e.message)) {
                this._showErrors([e]);
            }
        } finally {
            this._recommendedDictionariesRenderPending = false;
        }
    }

    /** */
    async _renderRecommendedDictionaries() {
        const url = '../../data/recommended-dictionaries.json';
        /** @type {string[]} */
        const diagnostics = [];
        diagnostics.push(`source=${url}`);
        /** @type {import('dictionary-recommended.js').RecommendedDictionaries|null} */
        let recommendedDictionaries = null;
        try {
            const response = await fetch(url, {
                method: 'GET',
                cache: 'default',
                credentials: 'omit',
                redirect: 'follow',
                referrerPolicy: 'no-referrer',
            });
            if (!response.ok) {
                throw new Error(`Failed to fetch ${url}: ${response.status}`);
            }
            recommendedDictionaries = (await readResponseJson(response));
            diagnostics.push('fetch=ok');
        } catch (error) {
            const message = toError(error).message;
            diagnostics.push(`fetch=failed:${message}`);
            throw new Error(`Failed to load recommended dictionaries feed: ${message}`);
        }
        if (!(recommendedDictionaries && typeof recommendedDictionaries === 'object' && !Array.isArray(recommendedDictionaries))) {
            throw new Error('Recommended dictionaries feed returned invalid data.');
        }
        diagnostics.push('feed=extension-data');

        /** @type {import('dictionary-recommended.js').RecommendedDictionaryElementMap[]} */
        const recommendedDictionaryCategories = [
            {property: 'terms', element: querySelectorNotNull(querySelectorNotNull(document, '#recommended-term-dictionaries'), '.recommended-dictionary-list')},
            {property: 'kanji', element: querySelectorNotNull(querySelectorNotNull(document, '#recommended-kanji-dictionaries'), '.recommended-dictionary-list')},
            {property: 'frequency', element: querySelectorNotNull(querySelectorNotNull(document, '#recommended-frequency-dictionaries'), '.recommended-dictionary-list')},
            {property: 'grammar', element: querySelectorNotNull(querySelectorNotNull(document, '#recommended-grammar-dictionaries'), '.recommended-dictionary-list')},
            {property: 'pronunciation', element: querySelectorNotNull(querySelectorNotNull(document, '#recommended-pronunciation-dictionaries'), '.recommended-dictionary-list')},
        ];

        const language = String((await this._settingsController.getOptions()).general.language || '').trim();
        const languageCandidates = [];
        if (language.length > 0) {
            languageCandidates.push(language);
            const baseLanguage = language.split('-')[0];
            if (baseLanguage.length > 0 && baseLanguage !== language) {
                languageCandidates.push(baseLanguage);
            }
        }
        const categories = ['terms', 'kanji', 'frequency', 'grammar', 'pronunciation'];
        let resolvedLanguage = languageCandidates.find((candidate) => candidate in recommendedDictionaries);
        if (typeof resolvedLanguage === 'string') {
            const languageConfig = /** @type {Record<string, unknown>} */ (recommendedDictionaries[resolvedLanguage]);
            const hasAnyRecommendedEntries = categories.some((category) => {
                const values = Reflect.get(languageConfig, category);
                return Array.isArray(values) && values.length > 0;
            });
            if (!hasAnyRecommendedEntries) {
                resolvedLanguage = void 0;
            }
        }

        if (typeof resolvedLanguage !== 'string') {
            if (this._readerInstallJitendex) {
                this._readerInstallJitendex = false;
                this._setRecommendedError('Select Japanese as the active language, then choose Jitendex.');
            }
            diagnostics.push(`requestedLanguage="${language}" resolvedLanguage=none`);
            this._setRecommendedDiagnostics(diagnostics.join('\n'));
            for (const {element} of recommendedDictionaryCategories) {
                const dictionaryCategoryParent = element.parentElement;
                if (dictionaryCategoryParent) {
                    dictionaryCategoryParent.hidden = true;
                }
            }
            return;
        }

        /** @type {import('dictionary-importer').Summary[]} */
        let installedDictionaries = [];
        try {
            installedDictionaries = await this._settingsController.getDictionaryInfo();
            diagnostics.push(`installedQuery=ok count=${String(installedDictionaries.length)}`);
        } catch (error) {
            const e = toError(error);
            if (isOpfsUnavailableMessage(e.message)) {
                diagnostics.push(`installedQuery=opfs-unavailable:${e.message}`);
                this._setRecommendedDiagnostics(diagnostics.join('\n'));
                throw new Error(getOpfsUnavailableUserMessage(e.message));
            }
            log.warn(`[recommended-dictionaries] getDictionaryInfo failed; continuing with empty installed set. ${e.message}`);
            diagnostics.push(`installedQuery=failed:${e.message}`);
        }
        /** @type {Set<string>} */
        const installedDictionaryNames = new Set();
        /** @type {Set<string>} */
        const installedDictionaryDownloadUrls = new Set();
        for (const dictionary of installedDictionaries) {
            if (!(typeof dictionary === 'object' && dictionary !== null && !Array.isArray(dictionary))) {
                continue;
            }
            const titleValue = /** @type {unknown} */ (Reflect.get(dictionary, 'title'));
            const downloadUrlValue = /** @type {unknown} */ (Reflect.get(dictionary, 'downloadUrl'));
            const title = typeof titleValue === 'string' ? titleValue : '';
            const downloadUrl = typeof downloadUrlValue === 'string' ? downloadUrlValue : '';
            if (title.length > 0) {
                installedDictionaryNames.add(title);
            }
            if (downloadUrl.length > 0) {
                installedDictionaryDownloadUrls.add(downloadUrl);
            }
        }

        /** @type {number} */
        let renderedRecommendationCount = 0;
        for (const {property, element} of recommendedDictionaryCategories) {
            const languageConfig = /** @type {Record<string, unknown>} */ (recommendedDictionaries[resolvedLanguage]);
            const values = Reflect.get(languageConfig, property);
            const dictionariesForCategory = /** @type {import('dictionary-recommended.js').RecommendedDictionary[]} */ (Array.isArray(values) ? values : []);
            renderedRecommendationCount += dictionariesForCategory.length;
            this._renderRecommendedDictionaryGroup(dictionariesForCategory, element, installedDictionaryNames, installedDictionaryDownloadUrls);
        }

        diagnostics.push(`renderedFrom=${resolvedLanguage}`);
        log.log(`[recommended-dictionaries] resolvedLanguage="${resolvedLanguage}" renderedCount=${String(renderedRecommendationCount)}`);
        diagnostics.push(
            `requestedLanguage="${language}" resolvedLanguage="${resolvedLanguage}"`,
            `renderedRecommendationCount=${String(renderedRecommendationCount)}`,
        );
        this._setRecommendedDiagnostics(diagnostics.join('\n'));
        reportDiagnostics('recommended-dictionaries-render', {
            requestedLanguage: language,
            resolvedLanguage,
            renderedRecommendationCount,
            diagnostics,
        });

        /** @type {NodeListOf<HTMLElement>} */
        const buttons = document.querySelectorAll('.action-button[data-action=import-recommended-dictionary]');
        for (const button of buttons) {
            button.addEventListener('click', this._onRecommendedImportClick.bind(this), false);
        }
        this._installReaderJitendexIfRequested();
    }

    /** Reuse the same button and progress UI as a normal Yomitan-style install. */
    _installReaderJitendexIfRequested() {
        if (!this._readerInstallJitendex) { return; }
        this._readerInstallJitendex = false;
        const row = [...document.querySelectorAll('#recommended-term-dictionaries .settings-item')]
            .find((item) => item.querySelector('.settings-item-label')?.textContent === 'Jitendex');
        const button = row?.querySelector('.action-button[data-action=import-recommended-dictionary]');
        if (button instanceof HTMLButtonElement && !button.disabled) {
            button.click();
        } else if (!(button instanceof HTMLButtonElement)) {
            this._setRecommendedError('Select Japanese as the active language, then choose Jitendex.');
        }
    }

    /**
     * @param {string} text
     */
    _setRecommendedDiagnostics(text) {
        const container = this._recommendedDiagnosticsContainer;
        if (!(container instanceof HTMLElement)) { return; }
        if (!this._showRecommendedDiagnosticsInUi) {
            container.textContent = '';
            container.hidden = true;
            return;
        }
        container.textContent = text;
        container.hidden = false;
    }

    /**
     * @param {string} text
     */
    _setRecommendedError(text) {
        const container = this._recommendedErrorContainer;
        if (!(container instanceof HTMLElement)) { return; }
        container.textContent = text;
        container.hidden = false;
    }

    /** */
    _clearRecommendedError() {
        const container = this._recommendedErrorContainer;
        if (!(container instanceof HTMLElement)) { return; }
        container.textContent = '';
        container.hidden = true;
    }

    /**
     *
     * @param {import('dictionary-recommended.js').RecommendedDictionary[]} recommendedDictionaries
     * @param {HTMLElement} dictionariesList
     * @param {Set<string>} installedDictionaryNames
     * @param {Set<string>} installedDictionaryDownloadUrls
     */
    _renderRecommendedDictionaryGroup(recommendedDictionaries, dictionariesList, installedDictionaryNames, installedDictionaryDownloadUrls) {
        const dictionariesListParent = dictionariesList.parentElement;
        dictionariesList.innerHTML = '';
        // Hide section if no dictionaries are available
        if (dictionariesListParent) {
            dictionariesListParent.hidden = recommendedDictionaries.length === 0;
        }
        for (const dictionary of recommendedDictionaries) {
            if (dictionariesList) {
                if (dictionariesListParent) {
                    dictionariesListParent.hidden = false;
                }
                const template = this._settingsController.instantiateTemplate('recommended-dictionaries-list-item');
                const label = querySelectorNotNull(template, '.settings-item-label');
                const description = querySelectorNotNull(template, '.description');
                /** @type {HTMLAnchorElement} */
                const homepage = querySelectorNotNull(template, '.homepage');
                /** @type {HTMLButtonElement} */
                const button = querySelectorNotNull(template, '.action-button[data-action=import-recommended-dictionary]');
                button.disabled = (
                    installedDictionaryNames.has(dictionary.name) ||
                    installedDictionaryDownloadUrls.has(dictionary.downloadUrl) ||
                    this._isRecommendedImportQueuedOrActive(dictionary.downloadUrl)
                );

                const urlAttribute = document.createAttribute('data-import-url');
                urlAttribute.value = dictionary.downloadUrl;
                button.attributes.setNamedItem(urlAttribute);

                label.textContent = dictionary.name;
                description.textContent = dictionary.description;
                if (dictionary.homepage) {
                    homepage.target = '_blank';
                    homepage.href = dictionary.homepage;
                } else {
                    homepage.remove();
                }

                dictionariesList.append(template);
            }
        }
    }

    /**
     * @param {string} importUrl
     * @param {boolean} disabled
     */
    _setRecommendedImportButtonDisabled(importUrl, disabled) {
        /** @type {NodeListOf<HTMLButtonElement>} */
        const buttons = document.querySelectorAll('.action-button[data-action=import-recommended-dictionary]');
        for (const button of buttons) {
            if (button.dataset.importUrl !== importUrl) { continue; }
            button.disabled = disabled;
        }
    }

    /**
     * @param {string} importUrl
     * @returns {boolean}
     */
    _isRecommendedImportQueuedOrActive(importUrl) {
        return this._recommendedDictionaryCurrentUrl === importUrl || this._recommendedDictionaryQueue.includes(importUrl);
    }

    /**
     * @param {Partial<{queueLength: number, activeImport: boolean, currentUrl: string|null, lastError: string|null}>} patch
     * @returns {void}
     */
    _updateRecommendedImportDebugState(patch) {
        this._recommendedImportDebugState = {
            ...this._recommendedImportDebugState,
            ...patch,
        };
        Reflect.set(globalThis, '__manabitanRecommendedImportState', {
            ...this._recommendedImportDebugState,
        });
    }

    /**
     * @param {import('settings-controller').EventArgument<'importDictionaryFromUrl'>} details
     */
    _onEventImportDictionaryFromUrl({url, profilesDictionarySettings, onImportDone, importDetailsOverrides}) {
        this._observeImportTask(this.importFilesFromURLs(url, profilesDictionarySettings, onImportDone, importDetailsOverrides ?? null));
    }

    /**
     * @param {import('settings-controller').EventArgument<'importDictionaryFromFile'>} details
     */
    _onEventImportDictionaryFromFile({files, profilesDictionarySettings, onImportDone, importDetailsOverrides}) {
        this._observeImportTask(this.importFiles(files, profilesDictionarySettings, onImportDone, importDetailsOverrides ?? null));
    }

    /**
     * @param {import('settings-controller').EventArgument<'downloadDictionaryFromUrl'>} details
     */
    _onEventDownloadDictionaryFromUrl({url, onDownloadDone}) {
        void (async () => {
            let file = null;
            try {
                file = await this.downloadDictionaryFileFromURL(url);
            } catch (error) {
                const e = toError(error);
                log.error(e);
                this._showErrors([e]);
            } finally {
                if (typeof onDownloadDone === 'function') {
                    try {
                        onDownloadDone(file);
                    } catch (error) {
                        const callbackError = toError(error);
                        reportDiagnostics('dictionary-import-download-callback-failed', {
                            message: callbackError.message,
                            hasFile: file instanceof File,
                        });
                        log.error(callbackError);
                    }
                }
            }
        })();
    }

    /** */
    _onImportFileButtonClick() {
        /** @type {HTMLInputElement} */ (this._importFileInput).click();
    }

    /**
     * @param {DragEvent} e
     */
    _onFileDropEnter(e) {
        e.preventDefault();
        if (!e.dataTransfer) { return; }
        for (const item of e.dataTransfer.items) {
            // Directories and files with no extension both show as ''
            if (
                item.type === '' ||
                item.type === 'application/zip' ||
                item.type === 'application/octet-stream'
            ) {
                this._importFileDrop.classList.add('drag-over');
                break;
            }
        }
    }

    /**
     * @param {DragEvent} e
     */
    _onFileDropOver(e) {
        e.preventDefault();
    }

    /**
     * @param {DragEvent} e
     */
    _onFileDropLeave(e) {
        e.preventDefault();
        this._importFileDrop.classList.remove('drag-over');
    }

    /**
     * @param {DragEvent} e
     */
    async _onFileDrop(e) {
        e.preventDefault();
        this._importFileDrop.classList.remove('drag-over');
        if (e.dataTransfer === null) { return; }
        /** @type {import('./modal.js').Modal} */ (this._importModal).setVisible(false);
        /** @type {File[]} */
        const fileArray = [];
        let fileEntries;
        try {
            fileEntries = await this._getAllFileEntries(e.dataTransfer.items);
        } catch (error) {
            const normalizedError = toError(error);
            log.error(normalizedError);
            this._showErrors([normalizedError]);
            return;
        }
        for (const fileEntry of fileEntries) {
            if (!fileEntry) { continue; }
            try {
                fileArray.push(await new Promise((resolve, reject) => { fileEntry.file(resolve, reject); }));
            } catch (error) {
                log.error(error);
            }
        }
        if (fileArray.length === 0) { return; }
        this._observeImportTask(this.importFiles(fileArray, null, null));
    }

    /**
     * @param {DataTransferItemList} dataTransferItemList
     * @returns {Promise<FileSystemFileEntry[]>}
     */
    async _getAllFileEntries(dataTransferItemList) {
        /** @type {(FileSystemFileEntry)[]} */
        const fileEntries = [];
        /** @type {(FileSystemEntry | null)[]} */
        const entries = [];
        for (let i = 0; i < dataTransferItemList.length; i++) {
            entries.push(dataTransferItemList[i].webkitGetAsEntry());
        }
        this._importFileDropItemCount = entries.length - 1;
        while (entries.length > 0) {
            this._importFileDropItemCount += 1;
            this._validateDirectoryItemCount();

            /** @type {(FileSystemEntry | null) | undefined} */
            const entry = entries.shift();
            if (!entry) { continue; }
            if (entry.isFile) {
                const extension = entry.name.substring(entry.name.lastIndexOf('.'), entry.name.length).toLowerCase();
                if (extension === '.zip' || extension === '.mdx' || extension === '.mdd') {
                    // @ts-expect-error - ts does not recognize `if (entry.isFile)` as verifying `entry` is type `FileSystemFileEntry` and instanceof does not work
                    fileEntries.push(entry);
                }
            } else if (entry.isDirectory) {
                // @ts-expect-error - ts does not recognize `if (entry.isDirectory)` as verifying `entry` is type `FileSystemDirectoryEntry` and instanceof does not work
                // eslint-disable-next-line @typescript-eslint/no-unsafe-argument
                entries.push(...await this._readAllDirectoryEntries(entry.createReader()));
            }
        }
        return fileEntries;
    }

    /**
     * @param {FileSystemDirectoryReader} directoryReader
     * @returns {Promise<(FileSystemEntry)[]>}
     */
    async _readAllDirectoryEntries(directoryReader) {
        const entries = [];
        /** @type {(FileSystemEntry)[]} */
        let readEntries = await this._readDirectoryEntries(directoryReader);
        while (readEntries.length > 0) {
            this._importFileDropItemCount += readEntries.length;
            this._validateDirectoryItemCount();

            entries.push(...readEntries);
            readEntries = await this._readDirectoryEntries(directoryReader);
        }
        return entries;
    }

    /**
     * @param {FileSystemDirectoryReader} directoryReader
     * @returns {Promise<FileSystemEntry[]>}
     */
    _readDirectoryEntries(directoryReader) {
        return new Promise((resolve, reject) => {
            try {
                directoryReader.readEntries(resolve, reject);
            } catch (error) {
                reject(error);
            }
        });
    }

    /**
     * @throws
     */
    _validateDirectoryItemCount() {
        if (this._importFileDropItemCount > 1000) {
            this._importFileDropItemCount = 0;
            const errorText = 'Directory upload item count too large';
            this._showErrors([new Error(errorText)]);
            throw new Error(errorText);
        }
    }

    /**
     * @param {MouseEvent} e
     */
    _onImportButtonClick(e) {
        e.preventDefault();
        this._renderPendingImportSources();
        /** @type {import('./modal.js').Modal} */ (this._importModal).setVisible(true);
    }

    /**
     * @param {MouseEvent} e
     */
    _onImportConfirm(e) {
        e.preventDefault();
        if (this._pendingImportSources.length === 0) { return; }
        this._importSelectedSources([...this._pendingImportSources]);
    }

    /**
     * @param {MouseEvent} e
     */
    _onPurgeButtonClick(e) {
        e.preventDefault();
        /** @type {import('./modal.js').Modal} */ (this._purgeConfirmModal).setVisible(true);
    }

    /**
     * @param {MouseEvent} e
     */
    _onPurgeConfirmButtonClick(e) {
        e.preventDefault();
        /** @type {import('./modal.js').Modal} */ (this._purgeConfirmModal).setVisible(false);
        void this._purgeDatabase();
    }

    /**
     * @param {Event} e
     */
    async _onImportFileChange(e) {
        /** @type {import('./modal.js').Modal} */ (this._importModal).setVisible(false);
        const node = /** @type {HTMLInputElement} */ (e.currentTarget);
        const {files} = node;
        if (files === null) { return; }
        const files2 = [...files];
        node.value = '';
        if (files2.length === 0) { return; }
        this._observeImportTask(this.importFiles(files2, null, null));
    }

    /**
     * @param {Event} e
     */
    async _onImportFromURL(e) {
        e.preventDefault();
        const text = this._importURLText.value.trim();
        if (!text) { return; }
        const urls = this._normalizeImportUrls(text);
        /** @type {DictionaryImportSource[]} */
        const sources = [];
        /** @type {Error[]} */
        const errors = [];
        const importProgressTracker = new ImportProgressTracker(this._getUrlImportSteps(), urls.length);
        const onProgress = importProgressTracker.onProgress.bind(importProgressTracker);
        for await (const source of this._generateFilesFromUrls(urls, onProgress, (error) => {
            errors.push(error);
        })) {
            sources.push(source);
        }
        if (sources.length === 0) {
            if (errors.length > 0) { this._showErrors(errors); }
            return;
        }
        this._importURLText.value = '';
        this._appendPendingImportSources(sources, errors);
    }

    /**
     * @param {string} text
     * @param {import('settings-controller').ProfilesDictionarySettings} profilesDictionarySettings
     * @param {import('settings-controller').ImportDictionaryDoneCallback} onImportDone
     * @param {Partial<import('dictionary-importer').ImportDetails>|null} importDetailsOverrides
     */
    async importFilesFromURLs(
        text,
        profilesDictionarySettings,
        onImportDone,
        /** @type {Partial<import('dictionary-importer').ImportDetails>|null} */ importDetailsOverrides = null,
    ) {
        const urls = this._normalizeImportUrls(text);
        if (urls.length === 0) { return; }

        const importProgressTracker = new ImportProgressTracker(this._getUrlImportSteps(), urls.length);
        const onProgress = importProgressTracker.onProgress.bind(importProgressTracker);
        await this._runImportWithWatchdog(
            this._importDictionaries(
                this._getUrlImportSources(urls, onProgress),
                profilesDictionarySettings,
                onImportDone,
                importProgressTracker,
                importDetailsOverrides,
            ),
            `URL dictionary import (${String(urls.length)})`,
            importProgressTracker,
        );
    }

    /**
     * @param {string} text
     * @returns {string[]}
     */
    _normalizeImportUrls(text) {
        /** @type {string[]} */
        const urls = [];
        /** @type {Set<string>} */
        const seen = new Set();
        for (const url of text.split('\n').map((value) => value.trim())) {
            if (url.length === 0 || seen.has(url)) { continue; }
            seen.add(url);
            urls.push(url);
        }
        return urls;
    }

    /**
     * @param {File[]} files
     * @param {import('settings-controller').ProfilesDictionarySettings} profilesDictionarySettings
     * @param {import('settings-controller').ImportDictionaryDoneCallback} onImportDone
     * @param {Partial<import('dictionary-importer').ImportDetails>|null} importDetailsOverrides
     */
    async importFiles(
        files,
        profilesDictionarySettings,
        onImportDone,
        /** @type {Partial<import('dictionary-importer').ImportDetails>|null} */ importDetailsOverrides = null,
    ) {
        if (files.length === 0) { return; }
        const {sources, errors} = this._createImportSourcesFromFiles(files);
        if (sources.length === 0) {
            if (errors.length > 0) { this._showErrors(errors); }
            return;
        }
        const importProgressTracker = new ImportProgressTracker(this._getFileImportSteps(), sources.length);
        await this._runImportWithWatchdog(
            this._importDictionaries(
                this._arrayToAsyncGenerator(sources),
                profilesDictionarySettings,
                onImportDone,
                importProgressTracker,
                importDetailsOverrides,
                errors,
            ),
            `File dictionary import (${String(sources.length)})`,
            importProgressTracker,
        );
    }

    /**
     * @param {DictionaryImportSource[]} sources
     * @param {Error[]} errors
     */
    _appendPendingImportSources(sources, errors = []) {
        this._pendingImportSources.push(...sources);
        this._renderPendingImportSources();
        this._hideErrors();
        if (errors.length > 0) {
            this._showErrors(errors);
        }
    }

    /**
     * @param {DictionaryImportSource[]} sources
     * @param {Error[]} initialErrors
     */
    _importSelectedSources(sources, initialErrors = []) {
        if (sources.length === 0) { return; }
        this._clearPendingImportSources();
        /** @type {import('./modal.js').Modal} */ (this._importModal).setVisible(false);
        const importProgressTracker = new ImportProgressTracker(this._getFileImportSteps(), sources.length);
        void this._runImportWithWatchdog(
            this._importDictionaries(
                this._arrayToAsyncGenerator(sources),
                null,
                null,
                importProgressTracker,
                null,
                initialErrors,
            ),
            `Selected dictionary import (${String(sources.length)})`,
            importProgressTracker,
        ).catch((error) => {
            log.error(error);
            this._showErrors([toError(error)]);
        });
    }

    /** */
    _clearPendingImportSources() {
        this._pendingImportSources = [];
        this._renderPendingImportSources();
    }

    /** */
    _renderPendingImportSources() {
        this._importSourceList.textContent = '';
        const hasSources = this._pendingImportSources.length > 0;
        this._importSourceEmpty.hidden = hasSources;
        this._importConfirmButton.disabled = !hasSources;
        if (!hasSources) { return; }

        const fragment = document.createDocumentFragment();
        for (const source of this._pendingImportSources) {
            const node = /** @type {HTMLElement} */ (this._settingsController.instantiateTemplate('dictionary-import-source'));
            const title = querySelectorNotNull(node, '.dictionary-import-source-title');
            const description = querySelectorNotNull(node, '.dictionary-import-source-description');
            title.textContent = this._getPendingImportSourceLabel(source);
            description.textContent = this._getPendingImportSourceDescription(source);
            fragment.appendChild(node);
        }
        this._importSourceList.appendChild(fragment);
    }

    /**
     * @param {DictionaryImportSource} source
     * @returns {string}
     */
    _getPendingImportSourceLabel(source) {
        return source.type === 'zip' ? source.file.name : source.mdxFile.name;
    }

    /**
     * @param {DictionaryImportSource} source
     * @returns {string}
     */
    _getPendingImportSourceDescription(source) {
        if (source.type === 'zip') { return 'ZIP archive'; }
        const mddCount = source.mddFiles.length;
        return mddCount > 0 ? `MDX dictionary with ${mddCount} matching MDD file${mddCount === 1 ? '' : 's'}` : 'MDX dictionary';
    }

    /**
     * Owns import promises launched from synchronous UI/event callbacks.
     * Watchdog recovery deliberately rejects after restoring UI state; observing
     * that rejection here prevents a second global unhandled-rejection signal.
     * @param {Promise<void>} promise
     */
    _observeImportTask(promise) {
        void promise.catch((error) => {
            log.error(error);
        });
    }

    /**
     * @param {Promise<void>} importPromise
     * @param {string} label
     * @param {{lastActivityTime: number, lastForwardProgressTime: number}|null} [progressTracker=null]
     * @returns {Promise<void>}
     */
    async _runImportWithWatchdog(importPromise, label, progressTracker = null) {
        const timeoutMs = 180_000;
        const absoluteTimeoutMs = 2 * 60 * 60 * 1000;
        const startedAt = safePerformance.now();
        const idleError = new Error(`${label} did not complete within ${String(timeoutMs)}ms without progress`);
        const absoluteError = new Error(`${label} did not complete within ${String(absoluteTimeoutMs)}ms`);
        /** @type {?import('core').Timeout} */
        let timer = null;
        const watchdogPromise = new Promise((_resolve, reject) => {
            const check = () => {
                const now = safePerformance.now();
                if ((now - startedAt) >= absoluteTimeoutMs) {
                    reject(absoluteError);
                    return;
                }
                const lastActivityTime = progressTracker?.lastForwardProgressTime ?? progressTracker?.lastActivityTime ?? startedAt;
                const idleMs = Math.max(0, now - lastActivityTime);
                const remainingMs = timeoutMs - idleMs;
                if (remainingMs <= 0) {
                    reject(idleError);
                    return;
                }
                timer = setTimeout(check, Math.min(1_000, remainingMs));
            };
            check();
        });
        try {
            await Promise.race([importPromise, watchdogPromise]);
        } catch (error) {
            const normalizedError = toError(error);
            if (error === idleError || error === absoluteError) {
                this._forceRecoverHungImportSession(normalizedError, label);
            }
            throw normalizedError;
        } finally {
            if (timer !== null) { clearTimeout(timer); }
        }
    }

    /**
     * @param {Error} error
     * @param {string} label
     * @returns {void}
     */
    _forceRecoverHungImportSession(error, label) {
        const ownerId = this._activeImportOwnerId;
        this._activeImportOwnerId = void 0;
        this._activeImportRunGeneration += 1;
        this._activeMdx?.disconnect();
        this._activeMdx = null;
        reportDiagnostics('dictionary-import-watchdog-recovery', {
            label,
            message: error.message,
            activeImportRunGeneration: this._activeImportRunGeneration,
        });
        log.error(error);
        this._setRecommendedError(this._errorToString(error));
        this._showErrors([error]);
        this._recommendedDictionaryQueue = [];
        this._recommendedDictionaryActiveImport = false;
        this._recommendedDictionaryCurrentUrl = null;
        this._updateRecommendedImportDebugState({
            queueLength: 0,
            activeImport: false,
            currentUrl: null,
            lastError: error.message,
        });
        for (const button of /** @type {NodeListOf<HTMLButtonElement>} */ (document.querySelectorAll('.action-button[data-action=import-recommended-dictionary]'))) {
            if (!button.dataset.importUrl) { continue; }
            button.disabled = false;
        }
        this._setModifying(false);
        const statusFooter = this._statusFooter;
        const progressSelector = '.dictionary-import-progress';
        const progressContainers = /** @type {NodeListOf<HTMLElement>} */ (document.querySelectorAll(progressSelector));
        for (const progress of progressContainers) {
            progress.hidden = true;
        }
        if (statusFooter !== null) {
            statusFooter.setTaskActive(progressSelector, false);
        }
        void this._settingsController.application.api.setDictionaryImportMode(false, ownerId).catch((importModeError) => {
            const normalizedImportModeError = toError(importModeError);
            reportDiagnostics('dictionary-import-watchdog-import-mode-exit-failed', {
                label,
                message: normalizedImportModeError.message,
            });
            log.error(normalizedImportModeError);
        });
        this._triggerStorageChanged();
    }

    /**
     * @param {number} importRunGeneration
     * @returns {boolean}
     */
    _isImportRunCurrent(importRunGeneration) {
        return this._activeImportRunGeneration === importRunGeneration;
    }

    /**
     * @param {string} url
     * @returns {Promise<File>}
     */
    async downloadDictionaryFileFromURL(url) {
        const archiveResult = await this._settingsController.application.api.downloadDictionaryArchive(url);
        const contentBase64 = typeof archiveResult?.contentBase64 === 'string' ? archiveResult.contentBase64 : '';
        if (contentBase64.length === 0) {
            throw new Error(`Failed to download dictionary from ${url}`);
        }
        const fileName = (typeof archiveResult?.fileName === 'string' && archiveResult.fileName.length > 0) ? archiveResult.fileName : 'fileFromURL.zip';
        const contentType = (typeof archiveResult?.contentType === 'string' && archiveResult.contentType.length > 0) ? archiveResult.contentType : 'application/zip';
        return new File([this._base64ToUint8Array(contentBase64)], fileName, {type: contentType});
    }

    /**
     * @param {string[]} urls
     * @param {import('dictionary-worker').ImportProgressCallback} onProgress
     * @param {(error: Error) => void} [onError]
     * @yields {Promise<DictionaryImportSource>}
     * @returns {AsyncGenerator<DictionaryImportSource, void, void>}
     */
    async *_generateFilesFromUrls(urls, onProgress, onError = void 0) {
        const downloadTimeoutMs = 120_000;
        for (const url of urls) {
            onProgress({nextStep: true, index: 0, count: 0});
            const trimmedUrl = url.trim();
            if (trimmedUrl.length === 0) { continue; }
            const downloadStartTime = safePerformance.now();
            log.log(`[ImportTiming] download started: ${trimmedUrl}`);
            reportDiagnostics('dictionary-url-download-begin', {
                url: summarizeUrlForDiagnostics(trimmedUrl),
            });

            try {
                if (trimmedUrl.startsWith('manabitan-e2e-dict:')) {
                    const inlineArchiveBase64 = this._getInlineArchiveBase64ForUrl(trimmedUrl);
                    if (typeof inlineArchiveBase64 !== 'string') {
                        throw new Error(`Missing inline archive for ${trimmedUrl}`);
                    }
                    const tokenName = trimmedUrl.slice('manabitan-e2e-dict:'.length).trim();
                    const safeName = tokenName.length > 0 ? tokenName.replaceAll(/[^a-zA-Z0-9._-]/g, '-') : 'fileFromURL';
                    const file = new File([this._base64ToUint8Array(inlineArchiveBase64)], `${safeName}.zip`, {type: 'application/zip'});
                    const downloadEndTime = safePerformance.now();
                    log.log(`[ImportTiming] download completed in ${formatDurationMs(downloadEndTime - downloadStartTime)}: ${trimmedUrl} (inline archive)`);
                    reportDiagnostics('dictionary-url-download-complete', {
                        url: summarizeUrlForDiagnostics(trimmedUrl),
                        inline: true,
                        elapsedMs: Math.max(0, downloadEndTime - downloadStartTime),
                        sizeBytes: file.size,
                    });
                    yield {type: 'zip', file};
                    continue;
                }

                const abortController = new AbortController();
                const timeoutId = globalThis.setTimeout(() => {
                    abortController.abort(new Error(`Timed out fetching URL after ${String(downloadTimeoutMs)}ms: ${trimmedUrl}`));
                }, downloadTimeoutMs);
                try {
                    const source = await this._createImportSourceFromUrl(trimmedUrl, downloadTimeoutMs, onProgress, abortController.signal);
                    const downloadEndTime = safePerformance.now();
                    log.log(`[ImportTiming] download completed in ${formatDurationMs(downloadEndTime - downloadStartTime)}: ${trimmedUrl}`);
                    reportDiagnostics('dictionary-url-download-complete', {
                        url: summarizeUrlForDiagnostics(trimmedUrl),
                        inline: false,
                        elapsedMs: Math.max(0, downloadEndTime - downloadStartTime),
                        sizeBytes: this._getImportSourceSize(source),
                        sourceType: source.type,
                    });
                    // The download is complete; importing the yielded file may
                    // take longer than the network timeout. Retire that timer now.
                    globalThis.clearTimeout(timeoutId);
                    yield source;
                } catch (error) {
                    const abortReason = /** @type {unknown} */ (abortController.signal.reason);
                    if (abortController.signal.aborted && abortReason instanceof Error) {
                        throw abortReason;
                    }
                    throw toError(error);
                } finally {
                    globalThis.clearTimeout(timeoutId);
                }
            } catch (error) {
                const downloadEndTime = safePerformance.now();
                log.log(`[ImportTiming] download failed after ${formatDurationMs(downloadEndTime - downloadStartTime)}: ${trimmedUrl}`);
                reportDiagnostics('dictionary-url-download-failed', {
                    url: summarizeUrlForDiagnostics(trimmedUrl),
                    elapsedMs: Math.max(0, downloadEndTime - downloadStartTime),
                    message: toError(error).message,
                });
                if (typeof onError === 'function') {
                    log.error(error);
                    onError(toError(error));
                    continue;
                }
                throw toError(error);
            }
        }
    }

    /**
     * @param {string[]} urls
     * @param {import('dictionary-worker').ImportProgressCallback} onProgress
     * @returns {AsyncGenerator<DictionaryImportSource|{downloadUrl: string}, void, void>}
     */
    _getUrlImportSources(urls, onProgress) {
        return ('serviceWorker' in navigator) ?
            this._generateFilesFromUrls(urls, onProgress) :
            this._generateImportSourcesFromUrls(urls);
    }

    /**
     * @param {string} url
     * @param {number} timeoutMs
     * @param {import('dictionary-worker').ImportProgressCallback} onProgress
     * @param {AbortSignal} abortSignal
     * @returns {Promise<File>}
     */
    async _downloadDictionaryFileViaXhr(url, timeoutMs, onProgress, abortSignal) {
        return await new Promise((resolve, reject) => {
            const request = new XMLHttpRequest();
            const cleanup = () => {
                request.onload = null;
                request.onerror = null;
                request.onabort = null;
                request.ontimeout = null;
                request.onprogress = null;
                abortSignal.removeEventListener('abort', onAbortSignal);
            };
            /** @param {unknown} error */
            const fail = (error) => {
                cleanup();
                reject(toError(error));
            };
            const getAbortError = () => {
                const abortReason = /** @type {unknown} */ (abortSignal.reason);
                return abortReason instanceof Error ? abortReason : new Error(`Aborted fetching dictionary archive: ${url}`);
            };
            const onAbortSignal = () => {
                // Cancellation owns settlement even if XHR cannot emit an abort event.
                fail(getAbortError());
                try {
                    request.abort();
                } catch (_) {
                    // NOP
                }
            };
            request.open('GET', url, true);
            request.responseType = 'arraybuffer';
            request.timeout = timeoutMs;
            request.onload = () => {
                if (!(request.status >= 200 && request.status < 300)) {
                    fail(new Error(`Failed to fetch dictionary archive: ${url} (status=${String(request.status)})`));
                    return;
                }
                const response = /** @type {unknown} */ (request.response);
                const contentBytes = response instanceof ArrayBuffer ? new Uint8Array(response) : new Uint8Array(0);
                if (contentBytes.byteLength === 0) {
                    fail(new Error(`Fetched dictionary archive had no content: ${url}`));
                    return;
                }
                const fileName = getDictionaryFileNameFromUrl(url) ?? 'fileFromURL.zip';
                const contentType = request.getResponseHeader('Content-Type') || 'application/zip';
                cleanup();
                resolve(new File([contentBytes], fileName, {type: contentType}));
            };
            request.onerror = () => {
                fail(new Error(`Failed to fetch dictionary archive: ${url}`));
            };
            request.onabort = () => {
                fail(getAbortError());
            };
            request.ontimeout = () => {
                fail(new Error(`Timed out fetching URL after ${String(timeoutMs)}ms: ${url}`));
            };
            request.onprogress = (event) => {
                if (!event.lengthComputable) { return; }
                onProgress({nextStep: false, index: event.loaded, count: event.total});
            };
            if (abortSignal.aborted) {
                fail(getAbortError());
                return;
            }
            abortSignal.addEventListener('abort', onAbortSignal, {once: true});
            try {
                request.send();
            } catch (error) {
                fail(error);
            }
        });
    }

    /**
     * @param {string} url
     * @param {number} timeoutMs
     * @param {import('dictionary-worker').ImportProgressCallback} onProgress
     * @param {AbortSignal} abortSignal
     * @returns {Promise<DictionaryImportSource>}
     */
    async _createImportSourceFromUrl(url, timeoutMs, onProgress, abortSignal) {
        const directFileName = getDictionaryFileNameFromUrl(url);
        if (directFileName !== null && isZipDictionaryFileName(directFileName)) {
            return {type: 'zip', file: await this._downloadDictionaryFileViaXhr(url, timeoutMs, onProgress, abortSignal)};
        }
        if (directFileName !== null && isMdxDictionaryFileName(directFileName)) {
            return await this._downloadMdxImportSourceFromUrl(url, timeoutMs, onProgress, abortSignal, directFileName);
        }

        const response = await fetch(url, {signal: abortSignal});
        if (!response.ok) {
            void response.body?.cancel().catch(() => {});
            throw new Error(`Failed to fetch dictionary archive: ${url} (status=${String(response.status)})`);
        }
        const contentType = response.headers.get('content-type') || '';
        if (/text\/html|application\/xhtml\+xml/i.test(contentType)) {
            const listing = this._parseMdxListingDocument(response.url || url, await response.text(), null);
            if (listing === null) {
                throw new Error(`URL did not point to a supported dictionary file or MDX directory listing: ${url}`);
            }
            return await this._downloadMdxImportSourceFromListing(listing, timeoutMs, onProgress, abortSignal);
        }

        const content = await response.arrayBuffer();
        if (content.byteLength === 0) {
            throw new Error(`Fetched dictionary archive had no content: ${url}`);
        }
        const fileName = directFileName ?? 'fileFromURL.zip';
        if (isMdxDictionaryFileName(fileName)) {
            const mdxFile = new File([content], fileName, {type: contentType || 'application/octet-stream'});
            return {type: 'mdx', mdxFile, mddFiles: []};
        }
        return {type: 'zip', file: new File([content], fileName, {type: contentType || 'application/zip'})};
    }

    /**
     * @param {string} url
     * @param {number} timeoutMs
     * @param {import('dictionary-worker').ImportProgressCallback} onProgress
     * @param {AbortSignal} abortSignal
     * @param {string} mdxFileName
     * @returns {Promise<MdxImportSource>}
     */
    async _downloadMdxImportSourceFromUrl(url, timeoutMs, onProgress, abortSignal, mdxFileName) {
        const downloadedFile = await this._downloadDictionaryFileViaXhr(url, timeoutMs, onProgress, abortSignal);
        const mdxFile = downloadedFile.name === mdxFileName ? downloadedFile : new File([downloadedFile], mdxFileName, {type: downloadedFile.type});
        const listing = await this._getMdxListingForUrl(url, mdxFileName, abortSignal);
        if (listing === null) {
            return {type: 'mdx', mdxFile, mddFiles: []};
        }
        const mddFiles = await this._downloadListingFiles(listing.mddLinks, timeoutMs, onProgress, abortSignal);
        return {type: 'mdx', mdxFile, mddFiles};
    }

    /**
     * @param {{mdxLink: {url: string, fileName: string}, mddLinks: Array<{url: string, fileName: string}>}} listing
     * @param {number} timeoutMs
     * @param {import('dictionary-worker').ImportProgressCallback} onProgress
     * @param {AbortSignal} abortSignal
     * @returns {Promise<MdxImportSource>}
     */
    async _downloadMdxImportSourceFromListing(listing, timeoutMs, onProgress, abortSignal) {
        const downloadedFile = await this._downloadDictionaryFileViaXhr(listing.mdxLink.url, timeoutMs, onProgress, abortSignal);
        const mdxFile = downloadedFile.name === listing.mdxLink.fileName ? downloadedFile : new File([downloadedFile], listing.mdxLink.fileName, {type: downloadedFile.type});
        const mddFiles = await this._downloadListingFiles(listing.mddLinks, timeoutMs, onProgress, abortSignal);
        return {type: 'mdx', mdxFile, mddFiles};
    }

    /**
     * @param {string} url
     * @param {string} mdxFileName
     * @param {AbortSignal} abortSignal
     * @returns {Promise<{mdxLink: {url: string, fileName: string}, mddLinks: Array<{url: string, fileName: string}>}|null>}
     */
    async _getMdxListingForUrl(url, mdxFileName, abortSignal) {
        const parentUrl = new URL('.', url).href;
        let listingUrl = parentUrl;
        let html;
        try {
            const response = await fetch(parentUrl, {signal: abortSignal});
            const contentType = response.headers.get('content-type') || '';
            if (!response.ok || !/text\/html|application\/xhtml\+xml/i.test(contentType)) {
                void response.body?.cancel().catch(() => {});
                return null;
            }
            listingUrl = response.url || parentUrl;
            html = await response.text();
        } catch (error) {
            if (abortSignal.aborted) { throw error; }
            return null;
        }
        return this._parseMdxListingDocument(listingUrl, html, mdxFileName);
    }

    /**
     * @param {Array<{url: string, fileName: string}>} listingFiles
     * @param {number} timeoutMs
     * @param {import('dictionary-worker').ImportProgressCallback} onProgress
     * @param {AbortSignal} abortSignal
     * @returns {Promise<File[]>}
     */
    async _downloadListingFiles(listingFiles, timeoutMs, onProgress, abortSignal) {
        /** @type {File[]} */
        const files = [];
        for (const {url, fileName} of listingFiles) {
            files.push(await this._downloadDictionaryFileViaXhr(url, timeoutMs, onProgress, abortSignal));
            if (files[files.length - 1].name !== fileName) {
                files[files.length - 1] = new File([files[files.length - 1]], fileName, {type: files[files.length - 1].type});
            }
        }
        // listingFiles already has validated, exact-stem-aware volume order.
        // Re-sorting by the last numeric suffix moves Book.2024.mdd behind its volumes.
        return files;
    }

    /**
     * @param {string} baseUrl
     * @param {string} html
     * @param {string|null} mdxFileName
     * @returns {{mdxLink: {url: string, fileName: string}, mddLinks: Array<{url: string, fileName: string}>}|null}
     * @throws {Error} If matching MDD links are ambiguous.
     */
    _parseMdxListingDocument(baseUrl, html, mdxFileName) {
        if (typeof DOMParser === 'undefined') { return null; }
        const document = new DOMParser().parseFromString(html, 'text/html');
        /** @type {Array<{url: string, fileName: string}>} */
        const fileLinks = [];
        const directoryUrl = new URL('.', baseUrl).href;
        const seenUrls = new Set();
        for (const anchor of document.querySelectorAll('a[href]')) {
            const href = anchor.getAttribute('href') || '';
            let resolvedUrl;
            try {
                resolvedUrl = new URL(href, baseUrl).href;
            } catch (_error) {
                continue;
            }
            const parsedUrl = new URL(resolvedUrl);
            if (
                (parsedUrl.protocol !== 'https:' && parsedUrl.protocol !== 'http:') ||
                new URL('.', parsedUrl).href !== directoryUrl
            ) { continue; }
            parsedUrl.hash = '';
            resolvedUrl = parsedUrl.href;
            if (seenUrls.has(resolvedUrl)) { continue; }
            seenUrls.add(resolvedUrl);
            const fileName = getDictionaryFileNameFromUrl(resolvedUrl);
            if (fileName === null) { continue; }
            fileLinks.push({url: resolvedUrl, fileName});
        }

        let mdxLink = null;
        if (typeof mdxFileName === 'string' && mdxFileName.length > 0) {
            const matchingMdx = fileLinks.filter(({fileName}) => getLowercaseFileName(fileName) === getLowercaseFileName(mdxFileName) && isMdxDictionaryFileName(fileName));
            if (matchingMdx.length !== 1) { return null; }
            [mdxLink] = matchingMdx;
        } else {
            const mdxLinks = fileLinks.filter(({fileName}) => isMdxDictionaryFileName(fileName));
            if (mdxLinks.length !== 1) { return null; }
            [mdxLink] = mdxLinks;
        }
        if (mdxLink === null) { return null; }

        const mdxKey = getLowercaseFileName(mdxLink.fileName).slice(0, -4);
        const mdxKeys = new Set(fileLinks
            .filter(({fileName}) => isMdxDictionaryFileName(fileName))
            .map(({fileName}) => getLowercaseFileName(fileName).slice(0, -4)));
        const mddLinks = fileLinks
            .filter(({fileName}) => resolveMddImportKey(fileName, mdxKeys) === mdxKey)
            .sort((a, b) => compareMddImportPaths(a.fileName, b.fileName, mdxKey));
        const resourceNames = new Set();
        for (const {fileName} of mddLinks) {
            const key = getLowercaseFileName(fileName);
            if (resourceNames.has(key)) {
                throw new Error(`Ambiguous MDD resource in directory listing: ${fileName}. Download one complete dictionary set and select its files together.`);
            }
            resourceNames.add(key);
        }
        return {mdxLink, mddLinks};
    }

    /**
     * @param {string[]} urls
     * @yields {Promise<DictionaryImportSource|{downloadUrl: string}>}
     * @returns {AsyncGenerator<DictionaryImportSource|{downloadUrl: string}, void, void>}
     */
    async *_generateImportSourcesFromUrls(urls) {
        for (const url of urls) {
            const trimmedUrl = url.trim();
            if (trimmedUrl.length === 0) { continue; }
            if (trimmedUrl.startsWith('manabitan-e2e-dict:')) {
                const inlineArchiveBase64 = this._getInlineArchiveBase64ForUrl(trimmedUrl);
                if (typeof inlineArchiveBase64 !== 'string') {
                    throw new Error(`Missing inline archive for ${trimmedUrl}`);
                }
                const tokenName = trimmedUrl.slice('manabitan-e2e-dict:'.length).trim();
                const safeName = tokenName.length > 0 ? tokenName.replaceAll(/[^a-zA-Z0-9._-]/g, '-') : 'fileFromURL';
                yield {type: 'zip', file: new File([this._base64ToUint8Array(inlineArchiveBase64)], `${safeName}.zip`, {type: 'application/zip'})};
                continue;
            }
            yield {downloadUrl: trimmedUrl};
        }
    }

    /**
     * @param {string} url
     * @returns {string|null}
     */
    _getInlineArchiveBase64ForUrl(url) {
        if (!url.startsWith('manabitan-e2e-dict:')) { return null; }
        const source = globalThis.localStorage?.getItem('manabitanE2eArchiveMap') || '';
        if (source.length === 0) { return null; }
        /** @type {unknown} */
        let value;
        try {
            value = parseJson(source);
        } catch (_error) {
            return null;
        }
        if (!(value && typeof value === 'object' && !Array.isArray(value))) { return null; }
        const content = /** @type {unknown} */ (Reflect.get(value, url));
        return (typeof content === 'string' && content.length > 0) ? content : null;
    }

    /**
     * @param {string} base64
     * @returns {Uint8Array}
     */
    _base64ToUint8Array(base64) {
        const binary = atob(base64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; ++i) {
            bytes[i] = binary.charCodeAt(i);
        }
        return bytes;
    }

    /**
     * @param {File[]} files
     * @returns {{sources: DictionaryImportSource[], errors: Error[]}}
     */
    _createImportSourcesFromFiles(files) {
        return createMdictImportSources(files);
    }

    /**
     * @param {DictionaryImportSource} source
     * @returns {number}
     */
    _getImportSourceSize(source) {
        if (source.type === 'zip') {
            return source.file.size;
        }
        return source.mdxFile.size + source.mddFiles.reduce((sum, file) => sum + file.size, 0);
    }

    /**
     * @param {import('dictionary-worker').ImportProgressCallback} onProgress
     * @param {{stage: 'upload'|'convert'|'download', completed: number, total: number}} details
     */
    _reportMdxConversionProgress(onProgress, details) {
        const {stage, completed, total} = details;
        let progress = 0;
        switch (stage) {
            case 'upload':
                progress = (total > 0 ? completed / total : 0) * MDX_UPLOAD_PROGRESS_RATIO;
                break;
            case 'convert':
                progress = MDX_UPLOAD_PROGRESS_RATIO + ((total > 0 ? completed / total : 1) * (1 - MDX_UPLOAD_PROGRESS_RATIO));
                break;
            case 'download':
                progress = 1;
                break;
        }
        onProgress({
            nextStep: false,
            index: Math.round(Math.max(0, Math.min(1, progress)) * MDX_CONVERSION_PROGRESS_TOTAL),
            count: MDX_CONVERSION_PROGRESS_TOTAL,
        });
    }

    /** */
    async _purgeDatabase() {
        if (this._modifying) { return; }

        const prevention = this._preventPageExit();

        try {
            this._setModifying(true);
            this._hideErrors();

            await this._settingsController.application.api.purgeDatabase();
            const errors = await this._clearDictionarySettings();

            if (errors.length > 0) {
                this._showErrors(errors);
            }
        } catch (error) {
            this._showErrors([toError(error)]);
        } finally {
            prevention.end();
            this._setModifying(false);
            this._triggerStorageChanged();
        }
    }

    /**
     * @param {AsyncGenerator<File|DictionaryImportSource|{downloadUrl: string}, void, void>} dictionaries
     * @param {import('settings-controller').ProfilesDictionarySettings} profilesDictionarySettings
     * @param {import('settings-controller').ImportDictionaryDoneCallback} onImportDone
     * @param {ImportProgressTracker} importProgressTracker
     * @param {Partial<import('dictionary-importer').ImportDetails>|null} importDetailsOverrides
     * @param {Error[]} initialErrors
     */
    async _importDictionaries(
        dictionaries,
        profilesDictionarySettings,
        onImportDone,
        importProgressTracker,
        /** @type {Partial<import('dictionary-importer').ImportDetails>|null} */ importDetailsOverrides = null,
        /** @type {Error[]} */ initialErrors = [],
    ) {
        if (this._modifying) { return; }
        const importRunGeneration = ++this._activeImportRunGeneration;
        const importOwnerId = crypto.randomUUID();
        this._activeImportOwnerId = importOwnerId;
        const assertCurrentRun = () => {
            if (!this._isImportRunCurrent(importRunGeneration)) {
                throw new Error('Ignored stale dictionary import run');
            }
        };
        importProgressTracker.setImportRunCheck(() => this._isImportRunCurrent(importRunGeneration));

        const statusFooter = this._statusFooter;
        const progressSelector = '.dictionary-import-progress';
        const progressContainers = /** @type {NodeListOf<HTMLElement>} */ (document.querySelectorAll(`#dictionaries-modal ${progressSelector}`));
        const recommendedProgressContainers = /** @type {NodeListOf<HTMLElement>} */ (document.querySelectorAll(`#recommended-dictionaries-modal ${progressSelector}`));

        const prevention = this._preventPageExit();

        const onProgress = importProgressTracker.onProgress.bind(importProgressTracker);
        Reflect.set(globalThis, '__manabitanImportStepTimingHistory', []);
        for (const root of document.querySelectorAll('.mdict-import-warnings')) {
            root.textContent = '';
            /** @type {HTMLElement} */ (root).hidden = true;
        }

        /** @type {Error[]} */
        let errors = [...initialErrors];
        /** @type {string[]} */
        const importedTitles = [];
        const useImportSession = this._getUseImportSession();
        /** @type {DeferredDictionaryFinalization[]|null} */
        const deferredFinalizations = useImportSession ? [] : null;
        log.log(`[ImportTiming] import session reuse enabled=${String(useImportSession)} (globalOverride=${String(this._getUseImportSession())})`);
        reportDiagnostics('dictionary-import-session-begin', {
            dictionaryCount: importProgressTracker.dictionaryCount,
            useImportSession,
            hasProfilesDictionarySettings: profilesDictionarySettings !== null,
            importRunGeneration,
        });
        let importModeEnabled = false;
        const importStartTime = safePerformance.now();
        try {
            this._setModifying(true);
            this._hideErrors();
            importModeEnabled = true;
            await this._settingsController.application.api.setDictionaryImportMode(true, importOwnerId);
            assertCurrentRun();

            for (const progress of [...progressContainers, ...recommendedProgressContainers]) { progress.hidden = false; }

            const optionsFull = await this._settingsController.getOptionsFull();
            assertCurrentRun();
            const {
                skipImageMetadata,
                skipMediaImport,
                mediaResolutionConcurrency,
                debugImportLogging,
                enableTermEntryContentDedup,
                termContentStorageMode,
                zipMaxWorkers,
                zipChunkSize,
                zipUseWebWorkers,
                artifactFixedPackMinTotalRows,
                wasmPreallocateChunkRows,
                termContentBlockTargetBytes,
                termBankExperiments,
            } = this._getImportPerformanceFlags();
            const importDetails = {
                prefixWildcardsSupported: optionsFull.global.database.prefixWildcardsSupported,
                yomitanVersion: chrome.runtime.getManifest().version,
                skipImageMetadata,
                skipMediaImport,
                mediaResolutionConcurrency,
                debugImportLogging,
                enableTermEntryContentDedup,
                termContentStorageMode,
                zipMaxWorkers,
                zipChunkSize,
                zipUseWebWorkers,
                artifactFixedPackMinTotalRows,
                wasmPreallocateChunkRows,
                termContentBlockTargetBytes,
                ...termBankExperiments,
                ...(importDetailsOverrides && typeof importDetailsOverrides === 'object' && !Array.isArray(importDetailsOverrides) ? importDetailsOverrides : {}),
            };

            for (let i = 0; i < importProgressTracker.dictionaryCount; ++i) {
                assertCurrentRun();
                importProgressTracker.onNextDictionary();
                if (statusFooter !== null) { statusFooter.setTaskActive(progressSelector, true); }
                const dictionaryLoopStartTime = safePerformance.now();
                const finalizeImportSession = useImportSession && i >= (importProgressTracker.dictionaryCount - 1);
                reportDiagnostics('dictionary-import-item-begin', {
                    index: i + 1,
                    dictionaryCount: importProgressTracker.dictionaryCount,
                    finalizeImportSession,
                });
                const nextDictionary = await dictionaries.next();
                assertCurrentRun();
                const source = nextDictionary.done ? null : nextDictionary.value;
                /** @type {string|null} */
                let downloadUrl = null;
                /** @type {DictionaryImportSource|null} */
                let importSource = null;
                if (source instanceof File) {
                    importSource = {type: 'zip', file: source};
                } else if (
                    source &&
                    typeof source === 'object' &&
                    !Array.isArray(source) &&
                    Reflect.get(source, 'type') === 'zip' &&
                    Reflect.get(source, 'file') instanceof File
                ) {
                    importSource = /** @type {ZipImportSource} */ (source);
                } else if (
                    source &&
                    typeof source === 'object' &&
                    !Array.isArray(source) &&
                    Reflect.get(source, 'type') === 'mdx' &&
                    Reflect.get(source, 'mdxFile') instanceof File &&
                    Array.isArray(Reflect.get(source, 'mddFiles'))
                ) {
                    importSource = /** @type {MdxImportSource} */ (source);
                } else if (
                    source &&
                    typeof source === 'object' &&
                    !Array.isArray(source) &&
                    typeof Reflect.get(source, 'downloadUrl') === 'string'
                ) {
                    downloadUrl = /** @type {string} */ (Reflect.get(source, 'downloadUrl')).trim();
                } else {
                    errors.push(new Error(`Failed to read file ${i + 1} of ${importProgressTracker.dictionaryCount} (value-type=${typeof source}).`));
                    reportDiagnostics('dictionary-import-item-invalid-file', {
                        index: i + 1,
                        dictionaryCount: importProgressTracker.dictionaryCount,
                        valueType: typeof source,
                    });
                    continue;
                }
                let importItemResult;
                if (downloadUrl !== null && downloadUrl.length > 0) {
                    importItemResult = await this._importDictionaryFromUrl(
                        downloadUrl,
                        profilesDictionarySettings,
                        importDetails,
                        useImportSession,
                        finalizeImportSession,
                        importRunGeneration,
                        onProgress,
                        deferredFinalizations,
                    );
                } else if (importSource?.type === 'mdx') {
                    importItemResult = await this._importDictionaryFromMdx(
                        importSource,
                        profilesDictionarySettings,
                        importDetails,
                        useImportSession,
                        finalizeImportSession,
                        importRunGeneration,
                        onProgress,
                        deferredFinalizations,
                    );
                } else if (importSource?.type === 'zip') {
                    importItemResult = await this._importDictionaryFromZip(
                        importSource.file,
                        profilesDictionarySettings,
                        importDetails,
                        useImportSession,
                        finalizeImportSession,
                        importRunGeneration,
                        onProgress,
                        deferredFinalizations,
                    );
                } else {
                    errors.push(new Error(`Unsupported dictionary import source at item ${i + 1}.`));
                    continue;
                }
                assertCurrentRun();
                errors = [...errors, ...importItemResult.errors];
                if (typeof importItemResult.importedTitle === 'string' && importItemResult.importedTitle.length > 0) {
                    importedTitles.push(importItemResult.importedTitle);
                }
                const dictionaryLoopEndTime = safePerformance.now();
                log.log(`[ImportTiming] dictionary ${i + 1}/${importProgressTracker.dictionaryCount} total ${formatDurationMs(dictionaryLoopEndTime - dictionaryLoopStartTime)}`);
                reportDiagnostics('dictionary-import-item-complete', {
                    index: i + 1,
                    dictionaryCount: importProgressTracker.dictionaryCount,
                    elapsedMs: Math.max(0, dictionaryLoopEndTime - dictionaryLoopStartTime),
                    cumulativeErrorCount: errors.length,
                    fileName: importSource?.type === 'mdx' ? importSource.mdxFile.name : (importSource?.type === 'zip' ? importSource.file.name : null),
                    sourceType: importSource?.type ?? (downloadUrl !== null ? 'url' : null),
                    memory: getImportMemorySnapshot(),
                });
            }
        } catch (error) {
            errors.push(toError(error));
            reportDiagnostics('dictionary-import-session-error', {
                message: toError(error).message,
            });
        } finally {
            try {
                await dictionaries.return();
            } catch (error) {
                errors.push(toError(error));
                reportDiagnostics('dictionary-import-source-close-failed', {
                    message: toError(error).message,
                    importRunGeneration,
                });
            }
            if (
                deferredFinalizations !== null &&
                deferredFinalizations.length > 0 &&
                this._isImportRunCurrent(importRunGeneration)
            ) {
                try {
                    const deferredResult = await this._finalizeDeferredImportedDictionaries(deferredFinalizations, importRunGeneration);
                    errors = [...errors, ...deferredResult.errors];
                    importedTitles.push(...deferredResult.importedTitles);
                } catch (error) {
                    const finalizationError = toError(error);
                    errors.push(finalizationError);
                    reportDiagnostics('dictionary-import-deferred-finalization-failed', {
                        message: finalizationError.message,
                        importRunGeneration,
                    });
                }
            }
            if (this._isImportRunCurrent(importRunGeneration)) {
                try {
                    importProgressTracker.onImportComplete(errors.length);
                } catch (error) {
                    const normalizedError = toError(error);
                    errors.push(normalizedError);
                    reportDiagnostics('dictionary-import-progress-finalization-failed', {
                        message: normalizedError.message,
                        importRunGeneration,
                    });
                }
                Reflect.set(globalThis, '__manabitanImportStepTimingHistory', importProgressTracker.getStepTimingHistory());
            }
            const importEndTime = safePerformance.now();
            log.log(`[ImportTiming] import session complete in ${formatDurationMs(importEndTime - importStartTime)} (errors=${errors.length})`);
            reportDiagnostics('dictionary-import-session-complete', {
                dictionaryCount: importProgressTracker.dictionaryCount,
                elapsedMs: Math.max(0, importEndTime - importStartTime),
                errorCount: errors.length,
                memory: getImportMemorySnapshot(),
                importRunGeneration,
                importRunCurrent: this._isImportRunCurrent(importRunGeneration),
            });
            prevention.end();
            // Keep mutation ownership until backend cleanup settles, then
            // recheck ownership before touching a possibly newer import UI.
            if (importModeEnabled) {
                try {
                    await this._settingsController.application.api.setDictionaryImportMode(false, importOwnerId);
                } catch (error) {
                    const importModeExitError = toError(error);
                    errors.push(importModeExitError);
                    reportDiagnostics('dictionary-import-session-import-mode-exit-failed', {
                        message: importModeExitError.message,
                        importRunGeneration,
                        activeImportRunGeneration: this._activeImportRunGeneration,
                    });
                }
            }
            if (this._activeImportOwnerId === importOwnerId) { this._activeImportOwnerId = void 0; }
            if (this._isImportRunCurrent(importRunGeneration)) {
                for (const progress of [...progressContainers, ...recommendedProgressContainers]) { progress.hidden = true; }
                if (statusFooter !== null) { statusFooter.setTaskActive(progressSelector, false); }
                this._setModifying(false);
                this._showErrors(errors);
                this._triggerStorageChanged();
                if (onImportDone) {
                    try {
                        onImportDone({
                            ok: errors.length === 0,
                            errors,
                            importedTitles: [...new Set(importedTitles)],
                        });
                    } catch (error) {
                        const callbackError = toError(error);
                        reportDiagnostics('dictionary-import-session-callback-failed', {
                            message: callbackError.message,
                            importRunGeneration,
                        });
                        log.error(callbackError);
                    }
                }
            } else {
                reportDiagnostics('dictionary-import-session-complete-stale', {
                    dictionaryCount: importProgressTracker.dictionaryCount,
                    errorCount: errors.length,
                    importRunGeneration,
                    activeImportRunGeneration: this._activeImportRunGeneration,
                });
            }
            this._signalImportSessionCompletion({
                importRunGeneration,
                importRunCurrent: this._isImportRunCurrent(importRunGeneration),
                errorCount: errors.length,
                importedTitles: [...new Set(importedTitles)],
            });
        }
    }

    /**
     * @returns {import('dictionary-importer').ImportSteps}
     */
    _getFileImportSteps() {
        return [
            {label: ''}, // Dictionary import is uninitialized
            {label: 'Initializing import'}, // Dictionary import is uninitialized
            {label: 'Loading dictionary'}, // Load dictionary archive and read index
            {label: 'Importing data'}, // Parse archive banks and import data
            {label: 'Finalizing import'}, // Update dictionary descriptor
        ];
    }

    /**
     * @returns {import('dictionary-importer').ImportSteps}
     */
    _getUrlImportSteps() {
        const urlImportSteps = this._getFileImportSteps();
        urlImportSteps.splice(2, 0, {label: 'Downloading dictionary'});
        return urlImportSteps;
    }

    /**
     * @returns {{skipImageMetadata: boolean, skipMediaImport: boolean, mediaResolutionConcurrency: number, debugImportLogging: boolean, enableTermEntryContentDedup: boolean|null, termContentStorageMode: 'baseline'|'raw-bytes', preserveCompressedMedia: boolean, zipMaxWorkers: number|null, zipChunkSize: number|null, zipUseWebWorkers: boolean|null, artifactFixedPackMinTotalRows: number|null, wasmPreallocateChunkRows: boolean, termContentBlockTargetBytes: number|null, termBankExperiments: ReturnType<typeof snapshotTermBankExperiments>}}
     */
    _getImportPerformanceFlags() {
        const flags = /** @type {unknown} */ (Reflect.get(globalThis, 'manabitanImportPerformanceFlags'));
        if (typeof flags !== 'object' || flags === null || Array.isArray(flags)) {
            return {
                skipImageMetadata: true,
                skipMediaImport: false,
                mediaResolutionConcurrency: 16,
                debugImportLogging: false,
                enableTermEntryContentDedup: null,
                termContentStorageMode: 'raw-bytes',
                preserveCompressedMedia: false,
                zipMaxWorkers: null,
                zipChunkSize: null,
                zipUseWebWorkers: null,
                artifactFixedPackMinTotalRows: null,
                wasmPreallocateChunkRows: true,
                termContentBlockTargetBytes: null,
                termBankExperiments: snapshotTermBankExperiments(),
            };
        }
        const flagsRecord = /** @type {Record<string, unknown>} */ (flags);
        const mediaResolutionConcurrency = Number.isFinite(flagsRecord.mediaResolutionConcurrency) ? Math.trunc(/** @type {number} */ (flagsRecord.mediaResolutionConcurrency)) : 16;
        const zipMaxWorkers = Number.isFinite(flagsRecord.zipMaxWorkers) ? Math.trunc(/** @type {number} */ (flagsRecord.zipMaxWorkers)) : null;
        const zipChunkSize = Number.isFinite(flagsRecord.zipChunkSize) ? Math.trunc(/** @type {number} */ (flagsRecord.zipChunkSize)) : null;
        const artifactFixedPackMinTotalRows = Number.isFinite(flagsRecord.artifactFixedPackMinTotalRows) ? Math.trunc(/** @type {number} */ (flagsRecord.artifactFixedPackMinTotalRows)) : null;
        const termContentBlockTargetBytes = Number.isFinite(flagsRecord.termContentBlockTargetBytes) ? Math.trunc(/** @type {number} */ (flagsRecord.termContentBlockTargetBytes)) : null;
        const termContentStorageModeRaw = flagsRecord.termContentStorageMode;
        const termContentStorageMode = (termContentStorageModeRaw === 'raw-bytes') ?
            termContentStorageModeRaw :
            'raw-bytes';
        return {
            termBankExperiments: snapshotTermBankExperiments(/** @type {import('dictionary-importer').ImportExperiments} */ (flagsRecord)),
            skipImageMetadata: flagsRecord.skipImageMetadata !== false,
            skipMediaImport: flagsRecord.skipMediaImport === true,
            mediaResolutionConcurrency: Math.max(1, Math.min(32, mediaResolutionConcurrency)),
            debugImportLogging: flagsRecord.debugImportLogging === true,
            enableTermEntryContentDedup: typeof flagsRecord.enableTermEntryContentDedup === 'boolean' ? flagsRecord.enableTermEntryContentDedup : null,
            termContentStorageMode,
            preserveCompressedMedia: flagsRecord.preserveCompressedMedia === true,
            zipMaxWorkers: zipMaxWorkers === null ? null : Math.max(1, Math.min(32, zipMaxWorkers)),
            zipChunkSize: zipChunkSize === null ? null : Math.max(16 * 1024, Math.min(8 * 1024 * 1024, zipChunkSize)),
            zipUseWebWorkers: typeof flagsRecord.zipUseWebWorkers === 'boolean' ? flagsRecord.zipUseWebWorkers : null,
            artifactFixedPackMinTotalRows: artifactFixedPackMinTotalRows === null ? null : Math.max(0, Math.min(4_000_000, artifactFixedPackMinTotalRows)),
            wasmPreallocateChunkRows: flagsRecord.wasmPreallocateChunkRows !== false,
            termContentBlockTargetBytes: termContentBlockTargetBytes === null ? null : Math.max(64 * 1024, Math.min(16 * 1024 * 1024, termContentBlockTargetBytes)),
        };
    }

    /**
     * @returns {boolean}
     */
    _getUseImportSession() {
        return Reflect.get(globalThis, 'manabitanImportUseSession') !== false;
    }

    /**
     * @param {string} dictionaryTitle
     * @param {boolean} requireEnabledForActiveProfile
     * @param {import('settings').Options|null} [optionsFullOverride]
     * @param {string|null} [activeProfileIdOverride]
     * @returns {Promise<void>}
     */
    async _verifyImportedDictionaryVisible(dictionaryTitle, requireEnabledForActiveProfile, optionsFullOverride = null, activeProfileIdOverride = null) {
        const normalizedTitle = typeof dictionaryTitle === 'string' ? dictionaryTitle : '';
        if (normalizedTitle.length === 0) {
            throw new Error('Cannot verify imported dictionary visibility without a title');
        }
        const activeProfileId = activeProfileIdOverride ?? this._settingsController.getOptionsContext?.()?.profileId;
        if (typeof activeProfileId !== 'string' || activeProfileId.length === 0) {
            throw new Error('Cannot verify imported dictionary visibility without an active profile ID');
        }
        let optionsFull = optionsFullOverride;
        if (optionsFull === null) {
            try {
                optionsFull = await this._settingsController.getOptionsFull();
            } catch (error) {
                reportDiagnostics('dictionary-import-visibility-options-fetch-failed', {
                    dictionaryTitle: normalizedTitle,
                    activeProfileId,
                    message: toError(error).message,
                });
                throw error;
            }
        }
        const profiles = Array.isArray(optionsFull?.profiles) ? optionsFull.profiles : [];
        const activeProfileIndex = profiles.findIndex((profile) => profile?.id === activeProfileId);
        if (activeProfileIndex < 0) {
            throw new Error(`Active profile ${activeProfileId} was not found while verifying imported dictionary ${normalizedTitle}`);
        }
        const activeProfile = profiles[activeProfileIndex];
        const activeProfileDictionaries = Array.isArray(activeProfile?.options?.dictionaries) ? activeProfile.options.dictionaries : [];
        const activeProfileEnabled = !requireEnabledForActiveProfile || activeProfileDictionaries.some((dictionary) => (
            dictionary.name === normalizedTitle &&
            dictionary.enabled === true
        ));
        this._emitImportedDictionaryProfileEnablementDiagnostics(normalizedTitle, profiles, activeProfileIndex);
        if (!activeProfileEnabled) {
            reportDiagnostics('dictionary-import-active-profile-disabled', {
                dictionaryTitle: normalizedTitle,
                activeProfileId,
                activeProfileIndex,
            });
            throw new Error(`Imported dictionary ${normalizedTitle} was not enabled for the active profile`);
        }
        reportDiagnostics('dictionary-import-visibility-verified', {
            dictionaryTitle: normalizedTitle,
            requireEnabledForActiveProfile,
            activeProfileId,
            activeProfileEnabled,
            backendLookupVerificationSkipped: true,
        });
    }

    /**
     * @param {string} dictionaryTitle
     * @param {Array<{id: string, options: {dictionaries: Array<{name: string, enabled: boolean}>}}>} profiles
     * @param {number} activeProfileIndex
     * @returns {void}
     */
    _emitImportedDictionaryProfileEnablementDiagnostics(dictionaryTitle, profiles, activeProfileIndex) {
        /** @type {string[]} */
        const enabledProfileIds = [];
        /** @type {string[]} */
        const disabledProfileIds = [];
        for (const profile of profiles) {
            const dictionaries = Array.isArray(profile?.options?.dictionaries) ? profile.options.dictionaries : [];
            const dictionarySetting = dictionaries.find((dictionary) => dictionary.name === dictionaryTitle);
            if (dictionarySetting?.enabled === true) {
                enabledProfileIds.push(profile.id);
            } else {
                disabledProfileIds.push(profile.id);
            }
        }
        reportDiagnostics('dictionary-import-profile-enablement', {
            dictionaryTitle,
            activeProfileIndex,
            enabledProfileIds,
            disabledProfileIds,
        });
    }

    /**
     * @param {Record<string, unknown>} snapshot
     */
    _recordImportDebugSnapshot(snapshot) {
        Reflect.set(globalThis, '__manabitanLastImportDebug', snapshot);
        const historyRaw = /** @type {unknown} */ (Reflect.get(globalThis, '__manabitanImportDebugHistory'));
        /** @type {Record<string, unknown>[]} */
        const history = [];
        if (Array.isArray(historyRaw)) {
            for (const entry of /** @type {unknown[]} */ (historyRaw)) {
                if (typeof entry === 'object' && entry !== null && !Array.isArray(entry)) {
                    history.push(/** @type {Record<string, unknown>} */ (entry));
                }
            }
        }
        history.push(snapshot);
        if (history.length > 20) {
            history.splice(0, history.length - 20);
        }
        Reflect.set(globalThis, '__manabitanImportDebugHistory', history);
    }

    /**
     * Exposes an exact post-UI completion boundary to development harnesses.
     * @param {{importRunGeneration: number, importRunCurrent: boolean, errorCount: number, importedTitles: string[]}} details
     */
    _signalImportSessionCompletion(details) {
        if (Reflect.get(globalThis, '__manabitanImportCompletionSignalEnabled') !== true) { return; }
        const previousSequence = /** @type {unknown} */ (Reflect.get(globalThis, '__manabitanImportCompletionSequence'));
        const sequence = typeof previousSequence === 'number' && Number.isSafeInteger(previousSequence) && previousSequence >= 0 ?
            previousSequence + 1 :
            1;
        const completion = {...details, sequence, completedAtEpochMs: Date.now(), completedAtMonotonicMs: safePerformance.now()};
        Reflect.set(globalThis, '__manabitanImportCompletionSequence', sequence);
        Reflect.set(globalThis, '__manabitanLastImportCompletion', completion);
        globalThis.dispatchEvent(new CustomEvent('manabitan:dictionary-import-complete', {detail: completion}));
    }

    /**
     * @template T
     * @param {T[]} arr
     * @yields {Promise<T>}
     * @returns {AsyncGenerator<T, void, void>}
     */
    async *_arrayToAsyncGenerator(arr) {
        for (const item of arr) {
            yield item;
        }
    }

    /**
     * @param {string} dictionaryTitle
     * @param {Array<{phase: string, elapsedMs: number, startEpochMs?: number, endEpochMs?: number, details?: Record<string, string|number|boolean|null>}>} localPhaseTimings
     * @param {string} phase
     * @param {number} startTime
     * @param {number} endTime
     * @param {Record<string, string|number|boolean|null>} [details]
     * @returns {void}
     */
    _recordImportLocalPhase(dictionaryTitle, localPhaseTimings, phase, startTime, endTime, details = {}) {
        const elapsedMs = Math.max(0, endTime - startTime);
        const endEpochMs = Date.now();
        const startEpochMs = endEpochMs - elapsedMs;
        localPhaseTimings.push({phase, elapsedMs, startEpochMs, endEpochMs, details});
        log.log(`[ImportTiming] [${dictionaryTitle}] phase ${phase} ${formatDurationMs(elapsedMs)} details=${JSON.stringify(details)}`);
    }

    /**
     * @param {MdxImportSource} source
     * @param {import('settings-controller').ProfilesDictionarySettings} profilesDictionarySettings
     * @param {import('dictionary-importer').ImportDetails} importDetails
     * @param {boolean} useImportSession
     * @param {boolean} finalizeImportSession
     * @param {number} importRunGeneration
     * @param {import('dictionary-worker').ImportProgressCallback} onProgress
     * @param {DeferredDictionaryFinalization[]|null} [deferredFinalizations]
     * @returns {Promise<{errors: Error[], importedTitle: string|null}>}
     */
    async _importDictionaryFromMdx(source, profilesDictionarySettings, importDetails, useImportSession, finalizeImportSession, importRunGeneration, onProgress, deferredFinalizations = null) {
        if (typeof importRunGeneration === 'function' && typeof onProgress === 'undefined') {
            onProgress = importRunGeneration;
            importRunGeneration = this._activeImportRunGeneration;
        }
        const dictionaryTitle = source.mdxFile.name || 'unknown-dictionary.mdx';
        const importStartTime = safePerformance.now();
        /** @type {Array<{phase: string, elapsedMs: number, details?: Record<string, string|number|boolean|null>}>} */
        const localPhaseTimings = [];
        const recordLocalPhase = this._recordImportLocalPhase.bind(this, dictionaryTitle, localPhaseTimings);
        log.log(`[ImportTiming] [${dictionaryTitle}] starting MDX import`);
        reportDiagnostics('dictionary-import-mdx-begin', {
            dictionaryTitle,
            mddCount: source.mddFiles.length,
            sizeBytes: source.mdxFile.size + source.mddFiles.reduce((sum, file) => sum + file.size, 0),
            useImportSession,
            finalizeImportSession,
        });

        const mdx = new Mdx();
        if (this._activeMdx !== null) {
            throw new Error('An MDX conversion is already active');
        }
        this._activeMdx = mdx;
        /** @type {File|null} */
        let archiveFile = null;
        const prepareStartTime = safePerformance.now();
        try {
            const archive = await mdx.convertDictionary(
                {
                    mdxFile: source.mdxFile,
                    mddFiles: source.mddFiles,
                    enableAudio: false,
                    includeAssets: true,
                },
                (details) => this._reportMdxConversionProgress(onProgress, details),
            );
            if (!this._isImportRunCurrent(importRunGeneration)) {
                throw new Error(`Ignored stale MDX conversion for ${dictionaryTitle}`);
            }
            localPhaseTimings.push(...archive.phaseTimings);
            for (const root of document.querySelectorAll('.mdict-import-warnings')) {
                appendMdictConversionWarnings(/** @type {HTMLElement} */ (root), dictionaryTitle, archive.phaseTimings);
            }
            archiveFile = new File([archive.archiveContent], archive.archiveFileName, {type: 'application/zip'});
        } finally {
            mdx.disconnect();
            if (this._activeMdx === mdx) {
                this._activeMdx = null;
            }
        }
        if (archiveFile === null) {
            throw new Error(`MDX conversion did not return an archive for ${dictionaryTitle}`);
        }
        const prepareEndTime = safePerformance.now();
        recordLocalPhase('prepare-mdx-archive', prepareStartTime, prepareEndTime, {
            mddCount: source.mddFiles.length,
            sourceSizeBytes: source.mdxFile.size + source.mddFiles.reduce((sum, file) => sum + file.size, 0),
            archiveSizeBytes: archiveFile.size,
        });

        const workerImportStartTime = safePerformance.now();
        const detailsAttempt = {
            ...importDetails,
            ...(useImportSession ? {useImportSession: true, finalizeImportSession} : {}),
        };
        const importResult = /** @type {ImportResultWithDebug} */ (
            await this._tryImportDictionaryOffscreen(archiveFile, detailsAttempt, onProgress)
        );
        const workerImportEndTime = safePerformance.now();
        recordLocalPhase('worker-import-dictionary', workerImportStartTime, workerImportEndTime, {
            useImportSession,
            finalizeImportSession,
            source: 'mdx-converted-archive',
        });

        return await this._finalizeImportedDictionaryResult({
            dictionaryTitle,
            importStartTime,
            importDetails,
            importResult,
            workerImportStartTime,
            workerImportEndTime,
            useImportSession,
            finalizeImportSession,
            importRunGeneration,
            profilesDictionarySettings,
            localPhaseTimings,
            deferredFinalizations,
        });
    }

    /**
     * @param {File} file
     * @param {import('settings-controller').ProfilesDictionarySettings} profilesDictionarySettings
     * @param {import('dictionary-importer').ImportDetails} importDetails
     * @param {boolean} useImportSession
     * @param {boolean} finalizeImportSession
     * @param {number} importRunGeneration
     * @param {import('dictionary-worker').ImportProgressCallback} onProgress
     * @param {DeferredDictionaryFinalization[]|null} [deferredFinalizations]
     * @returns {Promise<{errors: Error[], importedTitle: string|null}>}
     */
    async _importDictionaryFromZip(file, profilesDictionarySettings, importDetails, useImportSession, finalizeImportSession, importRunGeneration, onProgress, deferredFinalizations = null) {
        if (typeof importRunGeneration === 'function' && typeof onProgress === 'undefined') {
            onProgress = importRunGeneration;
            importRunGeneration = this._activeImportRunGeneration;
        }
        const dictionaryTitle = file.name || 'unknown-dictionary';
        const importStartTime = safePerformance.now();
        /** @type {Array<{phase: string, elapsedMs: number, details?: Record<string, string|number|boolean|null>}>} */
        const localPhaseTimings = [];
        const recordLocalPhase = this._recordImportLocalPhase.bind(this, dictionaryTitle, localPhaseTimings);
        log.log(`[ImportTiming] [${dictionaryTitle}] starting import`);
        reportDiagnostics('dictionary-import-zip-begin', {
            dictionaryTitle,
            sizeBytes: file.size,
            useImportSession,
            finalizeImportSession,
        });

        const readStartTime = safePerformance.now();
        const archiveContent = file;
        const readEndTime = safePerformance.now();
        log.log(`[ImportTiming] [${dictionaryTitle}] prepared archive handle ${formatDurationMs(readEndTime - readStartTime)}`);
        recordLocalPhase('read-archive', readStartTime, readEndTime, {
            sizeBytes: file.size,
            source: 'file-handle',
        });

        const workerImportStartTime = safePerformance.now();
        const detailsAttempt = {
            ...importDetails,
            ...(useImportSession ? {useImportSession: true, finalizeImportSession} : {}),
        };
        const importResult = /** @type {ImportResultWithDebug} */ (
            await this._tryImportDictionaryOffscreen(archiveContent, detailsAttempt, onProgress)
        );
        const workerImportEndTime = safePerformance.now();
        log.log(`[ImportTiming] [${dictionaryTitle}] worker importDictionary ${formatDurationMs(workerImportEndTime - workerImportStartTime)}`);
        recordLocalPhase('worker-import-dictionary', workerImportStartTime, workerImportEndTime, {
            useImportSession,
            finalizeImportSession,
        });

        return await this._finalizeImportedDictionaryResult({
            dictionaryTitle,
            importStartTime,
            importDetails,
            importResult,
            workerImportStartTime,
            workerImportEndTime,
            useImportSession,
            finalizeImportSession,
            importRunGeneration,
            profilesDictionarySettings,
            localPhaseTimings,
            deferredFinalizations,
        });
    }

    /**
     * @param {string} downloadUrl
     * @param {import('settings-controller').ProfilesDictionarySettings} profilesDictionarySettings
     * @param {import('dictionary-importer').ImportDetails} importDetails
     * @param {boolean} useImportSession
     * @param {boolean} finalizeImportSession
     * @param {number} importRunGeneration
     * @param {import('dictionary-worker').ImportProgressCallback} onProgress
     * @param {DeferredDictionaryFinalization[]|null} [deferredFinalizations]
     * @returns {Promise<{errors: Error[], importedTitle: string|null}>}
     */
    async _importDictionaryFromUrl(downloadUrl, profilesDictionarySettings, importDetails, useImportSession, finalizeImportSession, importRunGeneration, onProgress, deferredFinalizations = null) {
        if (typeof importRunGeneration === 'function' && typeof onProgress === 'undefined') {
            onProgress = importRunGeneration;
            importRunGeneration = this._activeImportRunGeneration;
        }
        const dictionaryTitle = downloadUrl;
        const importStartTime = safePerformance.now();
        /** @type {Array<{phase: string, elapsedMs: number, details?: Record<string, string|number|boolean|null>}>} */
        const localPhaseTimings = [];
        const recordLocalPhase = this._recordImportLocalPhase.bind(this, dictionaryTitle, localPhaseTimings);
        log.log(`[ImportTiming] [${dictionaryTitle}] starting import from URL`);
        reportDiagnostics('dictionary-import-url-begin', {
            downloadUrl: summarizeUrlForDiagnostics(downloadUrl),
            useImportSession,
            finalizeImportSession,
        });
        const workerImportStartTime = safePerformance.now();
        const detailsAttempt = {
            ...importDetails,
            ...(useImportSession ? {useImportSession: true, finalizeImportSession} : {}),
        };
        const importResult = await this._tryImportDictionaryUrlOffscreen(downloadUrl, detailsAttempt, onProgress);
        const workerImportEndTime = safePerformance.now();
        recordLocalPhase('worker-import-dictionary-url', workerImportStartTime, workerImportEndTime, {
            useImportSession,
            finalizeImportSession,
            downloadUrl: summarizeUrlForDiagnostics(downloadUrl),
        });
        return await this._finalizeImportedDictionaryResult({
            dictionaryTitle,
            importStartTime,
            importDetails,
            importResult,
            workerImportStartTime,
            workerImportEndTime,
            useImportSession,
            finalizeImportSession,
            importRunGeneration,
            profilesDictionarySettings,
            localPhaseTimings,
            deferredFinalizations,
        });
    }

    /**
     * @param {{
     *   dictionaryTitle: string,
     *   importStartTime: number,
     *   importDetails: import('dictionary-importer').ImportDetails,
     *   importResult: import('dictionary-importer').ImportResult & {debug?: {usesFallbackStorage?: boolean, openStorageDiagnostics?: unknown, useImportSession?: boolean, finalizeImportSession?: boolean, importerDebug?: {phaseTimings?: Array<{phase: string, elapsedMs: number, details?: Record<string, string|number|boolean|null>}>|null}|null}},
     *   workerImportStartTime: number,
     *   workerImportEndTime: number,
     *   useImportSession: boolean,
     *   finalizeImportSession: boolean,
     *   importRunGeneration: number,
     *   profilesDictionarySettings: import('settings-controller').ProfilesDictionarySettings,
     *   localPhaseTimings: Array<{phase: string, elapsedMs: number, startEpochMs?: number, endEpochMs?: number, details?: Record<string, string|number|boolean|null>}>,
     *   deferredFinalizations?: DeferredDictionaryFinalization[]|null,
     *   workerResultAlreadyRecorded?: boolean,
     *   notifyDatabaseUpdated?: boolean|null,
     *   showErrors?: boolean,
     * }} context
     * @returns {Promise<{errors: Error[], importedTitle: string|null}>}
     */
    async _finalizeImportedDictionaryResult({
        dictionaryTitle,
        importStartTime,
        importDetails,
        importResult,
        workerImportStartTime,
        workerImportEndTime,
        useImportSession,
        finalizeImportSession,
        importRunGeneration,
        profilesDictionarySettings,
        localPhaseTimings,
        deferredFinalizations = null,
        workerResultAlreadyRecorded = false,
        notifyDatabaseUpdated = null,
        showErrors = true,
    }) {
        const recordLocalPhase = this._recordImportLocalPhase.bind(this, dictionaryTitle, localPhaseTimings);
        /**
         * @param {string} phase
         * @returns {{errors: Error[], importedTitle: string|null}|null}
         */
        const getStaleImportResult = (phase) => {
            if (this._isImportRunCurrent(importRunGeneration)) { return null; }
            reportDiagnostics('dictionary-import-stale-completion-ignored', {
                dictionaryTitle,
                resultTitle: result?.title || null,
                importRunGeneration,
                activeImportRunGeneration: this._activeImportRunGeneration,
                phase,
            });
            return {
                errors: [...errors, new Error(`Ignored stale import completion for ${dictionaryTitle}`)],
                importedTitle: null,
            };
        };

        const {result, errors, debug} = importResult;
        const importerPhaseTimings = normalizeImporterPhaseTimings(debug?.importerDebug?.phaseTimings ?? null);
        if (!workerResultAlreadyRecorded) {
            reportDiagnostics('dictionary-import-worker-phase-summary', {
                dictionaryTitle,
                elapsedMs: Math.max(0, workerImportEndTime - workerImportStartTime),
                importerPhaseTimings,
                localPhaseTimings,
                memory: getImportMemorySnapshot(),
            });
            for (const phase of importerPhaseTimings) {
                log.log(
                    `[ImportTiming] [${dictionaryTitle}] worker phase "${phase.phase}" ${formatDurationMs(phase.elapsedMs)}` +
                    `${phase.details ? ` details=${JSON.stringify(phase.details)}` : ''}`,
                );
            }
        }
        if (!result) {
            reportDiagnostics('dictionary-import-zip-no-result', {
                dictionaryTitle,
                errorCount: Array.isArray(errors) ? errors.length : -1,
                usesFallbackStorage: debug?.usesFallbackStorage ?? null,
                importerPhaseTimings,
                localPhaseTimings,
            });
            this._recordImportDebugSnapshot({
                dictionaryTitle,
                hasResult: false,
                resultTitle: null,
                errorCount: Array.isArray(errors) ? errors.length : -1,
                addSettingsErrorCount: null,
                fallbackDatabaseContentBase64Length: null,
                usesFallbackStorage: debug?.usesFallbackStorage ?? null,
                openStorageDiagnostics: debug?.openStorageDiagnostics ?? null,
                useImportSession: debug?.useImportSession ?? null,
                finalizeImportSession: debug?.finalizeImportSession ?? null,
                importerPhaseTimings,
                localPhaseTimings,
            });
            return {errors, importedTitle: null};
        }

        if (debug?.usesFallbackStorage === true) {
            const fallbackError = new Error(`OPFS is required for import but fallback storage was detected. diagnostics=${JSON.stringify(debug.openStorageDiagnostics ?? null)}`);
            const errorsWithOpfsRequirement = [...errors, fallbackError];
            reportDiagnostics('dictionary-import-zip-opfs-fallback-detected', {
                dictionaryTitle,
                errorCount: errorsWithOpfsRequirement.length,
            });
            this._recordImportDebugSnapshot({
                dictionaryTitle,
                hasResult: false,
                resultTitle: result.title || null,
                errorCount: errorsWithOpfsRequirement.length,
                addSettingsErrorCount: null,
                fallbackDatabaseContentBase64Length: null,
                usesFallbackStorage: debug.usesFallbackStorage,
                openStorageDiagnostics: debug.openStorageDiagnostics ?? null,
                useImportSession: debug.useImportSession ?? null,
                finalizeImportSession: debug.finalizeImportSession ?? null,
                importerPhaseTimings,
                localPhaseTimings,
            });
            return {errors: errorsWithOpfsRequirement, importedTitle: null};
        }

        const staleImportResult = getStaleImportResult('before-page-side-finalization');
        if (staleImportResult !== null) { return staleImportResult; }

        if (deferredFinalizations !== null) {
            deferredFinalizations.push({
                dictionaryTitle,
                importStartTime,
                importDetails,
                importResult,
                workerImportStartTime,
                workerImportEndTime,
                useImportSession,
                finalizeImportSession,
                importRunGeneration,
                profilesDictionarySettings,
                localPhaseTimings,
                workerResultAlreadyRecorded: true,
            });
            localPhaseTimings.push({
                phase: 'page-side-finalization-queued',
                elapsedMs: 0,
                details: {deferred: true},
            });
            reportDiagnostics('dictionary-import-page-finalization-deferred', {
                dictionaryTitle,
                resultTitle: result.title || null,
                finalizeImportSession,
                queuedCount: deferredFinalizations.length,
            });
            return {errors: [], importedTitle: null};
        }

        const replacementDictionaryTitle = (
            typeof importDetails.replacementDictionaryTitle === 'string' &&
            importDetails.replacementDictionaryTitle.length > 0
        ) ?
            importDetails.replacementDictionaryTitle :
            null;
        const sourceDictionaryTitle = (
            typeof result.sourceTitle === 'string' &&
            result.sourceTitle.length > 0
        ) ?
            result.sourceTitle :
            String(result.title || '');
        if (
            replacementDictionaryTitle !== null &&
            sourceDictionaryTitle.length > 0 &&
            result.title !== sourceDictionaryTitle
        ) {
            const replacementStartTime = safePerformance.now();
            const replacementSummary = {
                ...result,
                title: sourceDictionaryTitle,
                updateSessionToken: (
                    typeof importDetails.updateSessionToken === 'string' &&
                    importDetails.updateSessionToken.trim().length > 0
                ) ?
                    importDetails.updateSessionToken.trim() :
                    null,
            };
            await this._settingsController.application.api.replaceDictionaryTitle({
                fromDictionaryTitle: result.title,
                toDictionaryTitle: sourceDictionaryTitle,
                replacedDictionaryTitle: replacementDictionaryTitle,
                summary: replacementSummary,
            });
            result.title = sourceDictionaryTitle;
            result.sourceTitle = sourceDictionaryTitle;
            const replacementEndTime = safePerformance.now();
            recordLocalPhase('replace-imported-dictionary-title', replacementStartTime, replacementEndTime, {
                replacedDictionaryTitle: replacementDictionaryTitle,
                sourceDictionaryTitle,
            });
        } else if (replacementDictionaryTitle !== null && sourceDictionaryTitle.length > 0) {
            localPhaseTimings.push({
                phase: 'replace-imported-dictionary-title',
                elapsedMs: 0,
                details: {
                    skipped: true,
                    alreadyAppliedInWorker: true,
                    replacedDictionaryTitle: replacementDictionaryTitle,
                    sourceDictionaryTitle,
                },
            });
        }
        const staleAfterReplaceResult = getStaleImportResult('before-add-dictionary-settings');
        if (staleAfterReplaceResult !== null) { return staleAfterReplaceResult; }

        const shouldAddDictionarySettings = (
            replacementDictionaryTitle === null ||
            sourceDictionaryTitle !== replacementDictionaryTitle
        );
        const addSettingsStartTime = safePerformance.now();
        const errors2 = shouldAddDictionarySettings ? await this._addDictionarySettings(result, profilesDictionarySettings) : [];
        const addSettingsEndTime = safePerformance.now();
        log.log(`[ImportTiming] [${dictionaryTitle}] add dictionary settings ${formatDurationMs(addSettingsEndTime - addSettingsStartTime)}`);
        recordLocalPhase('add-dictionary-settings', addSettingsStartTime, addSettingsEndTime, {
            settingsErrorCount: errors2.length,
            skipped: !shouldAddDictionarySettings,
        });
        const staleBeforeCleanupResult = getStaleImportResult('before-remove-replaced-dictionary-settings');
        if (staleBeforeCleanupResult !== null) { return staleBeforeCleanupResult; }
        if (replacementDictionaryTitle !== null && shouldAddDictionarySettings && errors2.length === 0) {
            // A failed migration still owns the old preference rows. Never
            // turn a recoverable settings error into their explicit deletion.
            const removeOldSettingsStartTime = safePerformance.now();
            const cleanupErrors = await this._removeDictionarySettingsByName(replacementDictionaryTitle);
            if (Array.isArray(cleanupErrors)) { errors2.push(...cleanupErrors); }
            const removeOldSettingsEndTime = safePerformance.now();
            recordLocalPhase('remove-replaced-dictionary-settings', removeOldSettingsStartTime, removeOldSettingsEndTime, {
                removedDictionaryTitle: replacementDictionaryTitle,
            });
        }
        const staleAfterSettingsResult = getStaleImportResult('before-trigger-database-updated');
        if (staleAfterSettingsResult !== null) { return staleAfterSettingsResult; }
        this._recordImportDebugSnapshot({
            dictionaryTitle,
            hasResult: true,
            resultTitle: result.title || null,
            sourceTitle: sourceDictionaryTitle || null,
            errorCount: Array.isArray(errors) ? errors.length : -1,
            addSettingsErrorCount: errors2.length,
            fallbackDatabaseContentBase64Length: null,
            usesFallbackStorage: debug?.usesFallbackStorage ?? null,
            openStorageDiagnostics: debug?.openStorageDiagnostics ?? null,
            useImportSession: debug?.useImportSession ?? null,
            finalizeImportSession: debug?.finalizeImportSession ?? null,
            importerPhaseTimings,
            localPhaseTimings,
        });

        const shouldNotifyDatabaseUpdated = notifyDatabaseUpdated ?? !(useImportSession && !finalizeImportSession);
        if (shouldNotifyDatabaseUpdated) {
            const triggerDatabaseUpdatedStartTime = safePerformance.now();
            await this._settingsController.application.api.triggerDatabaseUpdated('dictionary', 'import');
            const triggerDatabaseUpdatedEndTime = safePerformance.now();
            log.log(`[ImportTiming] [${dictionaryTitle}] triggerDatabaseUpdated ${formatDurationMs(triggerDatabaseUpdatedEndTime - triggerDatabaseUpdatedStartTime)}`);
            recordLocalPhase('trigger-database-updated', triggerDatabaseUpdatedStartTime, triggerDatabaseUpdatedEndTime);
            const verifyImportedDictionaryVisibleStartTime = safePerformance.now();
            await this._verifyImportedDictionaryVisible(
                result.title || sourceDictionaryTitle || dictionaryTitle,
                shouldAddDictionarySettings && profilesDictionarySettings === null,
            );
            const verifyImportedDictionaryVisibleEndTime = safePerformance.now();
            recordLocalPhase(
                'verify-imported-dictionary-visible',
                verifyImportedDictionaryVisibleStartTime,
                verifyImportedDictionaryVisibleEndTime,
                {
                    dictionaryTitle: result.title || sourceDictionaryTitle || dictionaryTitle,
                    requireEnabledForActiveProfile: shouldAddDictionarySettings && profilesDictionarySettings === null,
                },
            );
        } else {
            log.log(`[ImportTiming] [${dictionaryTitle}] triggerDatabaseUpdated deferred until import session finalize`);
            localPhaseTimings.push({
                phase: 'trigger-database-updated',
                elapsedMs: 0,
                details: {deferred: true},
            });
        }

        if (profilesDictionarySettings !== null && shouldAddDictionarySettings) {
            const staleBeforeRefreshResult = getStaleImportResult('before-refresh-profile-dictionary-references');
            if (staleBeforeRefreshResult !== null) { return staleBeforeRefreshResult; }
            const refreshStartTime = safePerformance.now();
            // This tab suppresses its own optionsUpdated messages. Refresh
            // live forms after the queued marker migration without replacing
            // any settings from a page-side snapshot.
            await this._settingsController.refresh();
            recordLocalPhase('refresh-profile-dictionary-references', refreshStartTime, safePerformance.now());
        }

        const importEndTime = safePerformance.now();
        log.log(`[ImportTiming] [${dictionaryTitle}] total import path ${formatDurationMs(importEndTime - importStartTime)} (errors=${errors.length + errors2.length})`);
        reportDiagnostics('dictionary-import-zip-complete', {
            dictionaryTitle,
            elapsedMs: Math.max(0, importEndTime - importStartTime),
            importErrors: errors.length,
            settingsErrors: errors2.length,
            resultTitle: result.title || null,
            importerPhaseTimings,
            localPhaseTimings,
            memory: getImportMemorySnapshot(),
        });

        if (showErrors && errors.length > 0) {
            errors.push(new Error(`Dictionary may not have been imported properly: ${errors.length} error${errors.length === 1 ? '' : 's'} reported.`));
            this._showErrors([...errors, ...errors2]);
        } else if (showErrors && errors2.length > 0) {
            this._showErrors(errors2);
        } else if (errors.length > 0) {
            errors.push(new Error(`Dictionary may not have been imported properly: ${errors.length} error${errors.length === 1 ? '' : 's'} reported.`));
        }
        return {
            errors: [...errors, ...errors2],
            importedTitle: errors.length === 0 && errors2.length === 0 ? (result.title || sourceDictionaryTitle || dictionaryTitle) : null,
        };
    }

    /**
     * @param {DeferredDictionaryFinalization[]} deferredFinalizations
     * @param {number} importRunGeneration
     * @returns {Promise<{errors: Error[], importedTitles: string[]}>}
     */
    async _finalizeDeferredImportedDictionaries(deferredFinalizations, importRunGeneration) {
        const pending = deferredFinalizations.splice(0, deferredFinalizations.length);
        /** @type {Error[]} */
        const errors = [];
        /** @type {string[]} */
        const importedTitles = [];
        /** @type {Array<{context: DeferredDictionaryFinalization, importedTitle: string}>} */
        const successfulFinalizations = [];
        for (const context of pending) {
            if (!this._isImportRunCurrent(importRunGeneration)) {
                errors.push(new Error(`Ignored stale deferred finalization for ${context.dictionaryTitle}`));
                continue;
            }
            try {
                const result = await this._finalizeImportedDictionaryResult({
                    ...context,
                    deferredFinalizations: null,
                    notifyDatabaseUpdated: false,
                    showErrors: false,
                });
                errors.push(...result.errors);
                if (result.importedTitle !== null) {
                    importedTitles.push(result.importedTitle);
                    successfulFinalizations.push({context, importedTitle: result.importedTitle});
                }
            } catch (error) {
                const finalizationError = toError(error);
                errors.push(new Error(`Failed to finalize imported dictionary ${context.dictionaryTitle}: ${finalizationError.message}`, {cause: finalizationError}));
                reportDiagnostics('dictionary-import-item-deferred-finalization-failed', {
                    dictionaryTitle: context.dictionaryTitle,
                    message: finalizationError.message,
                    importRunGeneration,
                });
            }
        }
        if (pending.length > 0 && this._isImportRunCurrent(importRunGeneration)) {
            const triggerStartTime = safePerformance.now();
            try {
                await this._settingsController.application.api.triggerDatabaseUpdated('dictionary', 'import');
                const triggerEndTime = safePerformance.now();
                reportDiagnostics('dictionary-import-batch-database-updated', {
                    dictionaryCount: pending.length,
                    importedTitleCount: importedTitles.length,
                    elapsedMs: Math.max(0, triggerEndTime - triggerStartTime),
                    importRunGeneration,
                });
            } catch (error) {
                const triggerError = toError(error);
                errors.push(triggerError);
                reportDiagnostics('dictionary-import-batch-database-update-failed', {
                    dictionaryCount: pending.length,
                    message: triggerError.message,
                    importRunGeneration,
                });
            }
        }
        let verificationOptionsFull = null;
        let verificationActiveProfileId = null;
        let verificationOptionsReadStartTime = null;
        let verificationOptionsReadEndTime = null;
        if (successfulFinalizations.length > 0) {
            const activeProfileContext = this._settingsController.getOptionsContext?.();
            verificationActiveProfileId = typeof activeProfileContext?.profileId === 'string' ? activeProfileContext.profileId : '';
            verificationOptionsReadStartTime = safePerformance.now();
            try {
                verificationOptionsFull = await this._settingsController.getOptionsFull();
            } catch (error) {
                reportDiagnostics('dictionary-import-batch-visibility-options-fetch-failed', {
                    message: toError(error).message,
                    importRunGeneration,
                });
            } finally {
                verificationOptionsReadEndTime = safePerformance.now();
            }
        }
        for (const {context, importedTitle} of successfulFinalizations) {
            const verifyStartTime = safePerformance.now();
            if (verificationOptionsReadStartTime !== null && verificationOptionsReadEndTime !== null) {
                this._recordImportLocalPhase(
                    context.dictionaryTitle,
                    context.localPhaseTimings,
                    'verify-imported-dictionary-options-batch-read',
                    verificationOptionsReadStartTime,
                    verificationOptionsReadEndTime,
                    {dictionaryCount: successfulFinalizations.length, batchFinalization: true},
                );
            }
            try {
                await this._verifyImportedDictionaryVisible(
                    importedTitle,
                    context.profilesDictionarySettings === null,
                    verificationOptionsFull,
                    verificationActiveProfileId,
                );
                const verifyEndTime = safePerformance.now();
                this._recordImportLocalPhase(
                    context.dictionaryTitle,
                    context.localPhaseTimings,
                    'verify-imported-dictionary-visible',
                    verifyStartTime,
                    verifyEndTime,
                    {
                        dictionaryTitle: importedTitle,
                        requireEnabledForActiveProfile: context.profilesDictionarySettings === null,
                        batchFinalization: true,
                    },
                );
            } catch (error) {
                const verifyError = toError(error);
                errors.push(verifyError);
                const importedTitleIndex = importedTitles.indexOf(importedTitle);
                if (importedTitleIndex >= 0) {
                    importedTitles.splice(importedTitleIndex, 1);
                }
                reportDiagnostics('dictionary-import-batch-visibility-verification-failed', {
                    dictionaryTitle: importedTitle,
                    message: verifyError.message,
                    importRunGeneration,
                });
            }
        }
        return {errors, importedTitles};
    }

    /**
     * @param {import('dictionary-importer').Summary} summary
     * @param {import('settings-controller').ProfilesDictionarySettings} profilesDictionarySettings
     * @returns {Promise<Error[]>}
     */
    async _addDictionarySettings(summary, profilesDictionarySettings) {
        const {title, sequenced, styles} = summary;
        const sourceTitle = (
            typeof summary.sourceTitle === 'string' &&
            summary.sourceTitle.length > 0
        ) ?
            summary.sourceTitle :
            null;
        const replacedTitle = (
            typeof summary.replacedDictionaryTitle === 'string' &&
            summary.replacedDictionaryTitle.length > 0
        ) ?
            summary.replacedDictionaryTitle :
            null;
        const selectorSourceTitle = sourceTitle ?? replacedTitle;
        let optionsFull;
        // Workaround Firefox bug sometimes causing getOptionsFull to fail
        for (let i = 0, success = false; (i < 10) && (success === false); i++) {
            try {
                optionsFull = await this._settingsController.getOptionsFull();
                success = true;
            } catch (error) {
                log.error(error);
            }
        }
        if (!optionsFull) {
            const readError = new Error('Failed to automatically set dictionary settings. A page refresh and manual enabling of the dictionary may be required.');
            if (profilesDictionarySettings !== null) {
                /** @type {import('settings-modifications').Modification[]} */
                const targets = [];
                for (const [profileId, profileDictionarySettings] of Object.entries(profilesDictionarySettings)) {
                    if (!Array.isArray(profileDictionarySettings) || profileDictionarySettings.length === 0) { continue; }
                    const sourceName = profileDictionarySettings[0].name;
                    if (typeof sourceName !== 'string' || sourceName.length === 0 || sourceName === title) { continue; }
                    targets.push(
                        {
                            action: 'replaceDictionaryName',
                            profileId,
                            sourceName,
                            name: title,
                            styles,
                            fallbackSettings: profileDictionarySettings.map(({index, ...item}) => ({index, item})),
                        },
                        {action: 'setDictionarySelector', profileId, selector: 'mainDictionary', expectedValue: sourceName, value: title},
                        {action: 'setDictionarySelector', profileId, selector: 'sortFrequencyDictionary', expectedValue: sourceName, value: title},
                        {action: 'setDictionarySelector', profileId, selector: 'popupBlurByFrequencyDictionary', expectedValue: sourceName, value: title},
                    );
                }
                if (targets.length > 0) { return await this._modifyGlobalSettings(targets); }
            }
            return [readError];
        }

        const selectedProfileId = this._settingsController.getOptionsContext?.().profileId;
        if (typeof selectedProfileId !== 'string' || selectedProfileId.length === 0 || optionsFull.profiles.filter(({id}) => id === selectedProfileId).length !== 1) {
            return [new Error('Unable to identify the active profile; dictionary settings were not changed.')];
        }
        /** @type {import('settings-modifications').Modification[]} */
        const targets = [];
        const profileCount = optionsFull.profiles.length;
        for (let i = 0; i < profileCount; ++i) {
            const {options, id: profileId} = optionsFull.profiles[i];
            const enabled = profileId === selectedProfileId;
            const defaultSettings = DictionaryController.createDefaultDictionarySettings(title, enabled, styles);

            const profileDictionarySettings = profilesDictionarySettings?.[profileId];
            if (!Array.isArray(profileDictionarySettings) || profileDictionarySettings.length === 0) {
                const existingIndex = options.dictionaries.findIndex((dictionary) => dictionary.name === title);
                if (existingIndex < 0) {
                    targets.push({action: 'ensureDictionary', profileId, item: defaultSettings});
                    if (enabled) {
                        // A databaseUpdated refresh may have queued a disabled
                        // default row after this snapshot. Apply the selected
                        // import's enable intent after ensureDictionary so the
                        // existing row is enabled without replacing its prefs.
                        targets.push({action: 'setDictionaryEnabled', profileId, name: title, alias: title, value: true});
                    }
                } else if (profilesDictionarySettings === null && enabled && !options.dictionaries.some((dictionary) => dictionary.name === title && dictionary.enabled)) {
                    // A databaseUpdated refresh can auto-create this entry with
                    // enabled=false before the import finishes. Enable it in
                    // place rather than inserting another entry with the same name.
                    targets.push({
                        action: 'setDictionaryEnabled',
                        profileId,
                        name: title,
                        alias: options.dictionaries[existingIndex].alias,
                        value: true,
                    });
                }
                if (selectorSourceTitle !== null && options.general.mainDictionary === selectorSourceTitle) {
                    targets.push({action: 'setDictionarySelector', profileId, selector: 'mainDictionary', expectedValue: selectorSourceTitle, value: title});
                } else if (sequenced && options.general.mainDictionary === '') {
                    targets.push({action: 'setDictionarySelector', profileId, selector: 'mainDictionary', expectedValue: '', value: title});
                }
                for (const selector of /** @type {const} */ (['sortFrequencyDictionary', 'popupBlurByFrequencyDictionary'])) {
                    if (selectorSourceTitle !== null && options.general[selector] === selectorSourceTitle) {
                        targets.push({action: 'setDictionarySelector', profileId, selector, expectedValue: selectorSourceTitle, value: title});
                    }
                }
            } else {
                const {name} = profileDictionarySettings[0];
                targets.push({
                    action: 'replaceDictionaryName',
                    profileId,
                    sourceName: name,
                    name: title,
                    styles,
                    fallbackSettings: profileDictionarySettings.map(({index, ...item}) => ({index, item})),
                });
                if (
                    options.general.mainDictionary === name ||
                    (selectorSourceTitle !== null && options.general.mainDictionary === selectorSourceTitle) ||
                    (sequenced && options.general.mainDictionary === '')
                ) {
                    targets.push({action: 'setDictionarySelector', profileId, selector: 'mainDictionary', expectedValue: options.general.mainDictionary, value: title});
                }
                for (const selector of /** @type {const} */ (['sortFrequencyDictionary', 'popupBlurByFrequencyDictionary'])) {
                    if (
                        options.general[selector] === name ||
                        (selectorSourceTitle !== null && options.general[selector] === selectorSourceTitle)
                    ) {
                        targets.push({action: 'setDictionarySelector', profileId, selector, expectedValue: options.general[selector], value: title});
                    }
                }
            }
        }
        return await this._modifyGlobalSettings(targets);
    }

    /**
     * @param {string} dictionaryTitle
     * @returns {Promise<Error[]>}
     */
    async _removeDictionarySettingsByName(dictionaryTitle) {
        const optionsFull = await this._settingsController.getOptionsFull();
        const {profiles} = optionsFull;
        /** @type {import('settings-modifications').Modification[]} */
        const targets = [];
        for (let i = 0, ii = profiles.length; i < ii; ++i) {
            const {options, id: profileId} = profiles[i];
            const {dictionaries, general} = options;
            if (dictionaries.some(({name}) => name === dictionaryTitle)) { targets.push({action: 'removeDictionaryByName', profileId, name: dictionaryTitle}); }
            if (general.mainDictionary === dictionaryTitle) {
                targets.push({action: 'setDictionarySelector', profileId, selector: 'mainDictionary', expectedValue: dictionaryTitle, value: '', requireDictionaryUninstalled: dictionaryTitle});
            }
            for (const selector of /** @type {const} */ (['sortFrequencyDictionary', 'popupBlurByFrequencyDictionary'])) {
                if (general[selector] === dictionaryTitle) {
                    targets.push({action: 'setDictionarySelector', profileId, selector, expectedValue: dictionaryTitle, value: null, requireDictionaryUninstalled: dictionaryTitle});
                }
            }
        }
        return targets.length > 0 ? await this._modifyGlobalSettings(targets) : [];
    }

    /**
     * @returns {Promise<Error[]>}
     */
    async _clearDictionarySettings() {
        const optionsFull = await this._settingsController.getOptionsFull();
        /** @type {import('settings-modifications').Modification[]} */
        const targets = [];
        for (const {id: profileId, options: {dictionaries, general}} of optionsFull.profiles) {
            // Resolve profile identity and installed state inside the options
            // queue. A purge snapshot must not erase a later import or a new
            // profile which now occupies the same array index.
            for (const dictionaryName of new Set(dictionaries.map(({name}) => name))) {
                targets.push({action: 'removeDictionaryByName', profileId, name: dictionaryName});
            }
            if (general.mainDictionary !== '') {
                targets.push({action: 'setDictionarySelector', profileId, selector: 'mainDictionary', expectedValue: general.mainDictionary, value: '', requireDictionaryUninstalled: general.mainDictionary});
            }
            for (const selector of /** @type {const} */ (['sortFrequencyDictionary', 'popupBlurByFrequencyDictionary'])) {
                if (typeof general[selector] === 'string') {
                    targets.push({action: 'setDictionarySelector', profileId, selector, expectedValue: general[selector], value: null, requireDictionaryUninstalled: general[selector]});
                }
            }
        }
        return targets.length > 0 ? await this._modifyGlobalSettings(targets) : [];
    }

    /**
     * @returns {import('settings-controller').PageExitPrevention}
     */
    _preventPageExit() {
        return this._settingsController.preventPageExit();
    }

    /**
     * @param {Error[]} errors
     */
    _showErrors(errors) {
        if (errors.length === 0) {
            this._hideErrors();
            return;
        }
        reportDiagnostics('dictionary-import-errors-shown', {
            errorCount: errors.length,
            messages: errors.slice(0, 5).map((error) => this._errorToString(error)),
        });
        /** @type {Map<string, number>} */
        const uniqueErrors = new Map();
        for (const error of errors) {
            log.error(error);
            const errorString = this._errorToString(error);
            let count = uniqueErrors.get(errorString);
            if (typeof count === 'undefined') {
                count = 0;
            }
            uniqueErrors.set(errorString, count + 1);
        }

        const fragment = document.createDocumentFragment();
        for (const [e, count] of uniqueErrors.entries()) {
            const div = document.createElement('p');
            if (count > 1) {
                div.textContent = `${e} `;
                const em = document.createElement('em');
                em.textContent = `(${count})`;
                div.appendChild(em);
            } else {
                div.textContent = `${e}`;
            }
            fragment.appendChild(div);
        }

        const errorContainer = /** @type {HTMLElement} */ (this._errorContainer);
        errorContainer.textContent = '';
        errorContainer.appendChild(fragment);
        errorContainer.hidden = false;
    }

    /** */
    _hideErrors() {
        const errorContainer = /** @type {HTMLElement} */ (this._errorContainer);
        errorContainer.textContent = '';
        errorContainer.hidden = true;
    }

    /**
     * @param {File} file
     * @returns {Promise<ArrayBuffer>}
     */
    _readFile(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(/** @type {ArrayBuffer} */ (reader.result));
            reader.onerror = () => reject(reader.error);
            reader.readAsArrayBuffer(file);
        });
    }

    /**
     * @param {Error} error
     * @returns {string}
     */
    _errorToString(error) {
        const errorMessage = error.toString();

        if (isOpfsUnavailableMessage(errorMessage)) {
            return getOpfsUnavailableUserMessage(errorMessage);
        }

        for (const [match, newErrorString] of this._errorToStringOverrides) {
            if (errorMessage.includes(match)) {
                return newErrorString;
            }
        }

        return errorMessage;
    }

    /**
     * @param {boolean} value
     */
    _setModifying(value) {
        this._modifying = value;
        this._setButtonsEnabled(!value);
    }

    /**
     * @param {boolean} value
     */
    _setButtonsEnabled(value) {
        value = !value;
        for (const node of /** @type {NodeListOf<HTMLInputElement>} */ (document.querySelectorAll('.dictionary-database-mutating-input'))) {
            node.disabled = value;
        }
    }

    /**
     * @param {import('settings-modifications').Modification[]} targets
     * @returns {Promise<Error[]>}
     */
    async _modifyGlobalSettings(targets) {
        const results = await this._settingsController.modifyGlobalSettings(targets);
        const errors = [];
        for (const {error} of results) {
            if (typeof error !== 'undefined') {
                errors.push(ExtensionError.deserialize(error));
            }
        }
        return errors;
    }

    /** */
    _triggerStorageChanged() {
        this._settingsController.application.triggerStorageChanged();
    }
}

export class ImportProgressTracker {
    /**
     * @param {import('dictionary-importer').ImportSteps} steps
     * @param {number} dictionaryCount
     */
    constructor(steps, dictionaryCount) {
        /** @type {(() => boolean)|null} */
        this._isImportRunCurrent = null;
        /** @type {import('dictionary-importer').ImportSteps} */
        this._steps = steps;
        /** @type {number} */
        this._dictionaryCount = dictionaryCount;

        /** @type {number} */
        this._stepIndex = 0;
        /** @type {number} */
        this._dictionaryIndex = 0;
        /** @type {number} */
        this._importStartTime = safePerformance.now();
        /** @type {number} */
        this._dictionaryStartTime = this._importStartTime;
        /** @type {number} */
        this._stepStartTime = this._importStartTime;
        /** @type {number} */
        this._stepChangeCount = 0;
        /** @type {Array<Record<string, unknown>>} */
        this._stepTimingHistory = [];
        /** @type {ReturnType<typeof getImportMemorySnapshot>} */
        this._stepStartMemory = getImportMemorySnapshot();
        /** @type {ReturnType<typeof getImportMemorySnapshot>} */
        this._dictionaryStartMemory = this._stepStartMemory;

        const progressSelector = '.dictionary-import-progress';
        /** @type {NodeListOf<HTMLElement>} */
        this._progressBars = (document.querySelectorAll(`${progressSelector} .progress-bar`));
        /** @type {NodeListOf<HTMLElement>} */
        this._infoLabels = (document.querySelectorAll(`${progressSelector} .progress-info`));
        /** @type {NodeListOf<HTMLElement>} */
        this._statusLabels = (document.querySelectorAll(`${progressSelector} .progress-status`));
        /** @type {string} */
        this._lastInfoLabelText = '';
        /** @type {string} */
        this._lastStatusText = '';
        /** @type {number} */
        this._lastPercent = -1;
        /** @type {number} */
        this._lastActivityTime = this._importStartTime;
        /** @type {number} */
        this._lastForwardProgressTime = this._importStartTime;
        /** @type {string} */
        this._lastProgressSignature = '';

        this.onProgress({nextStep: false, index: 0, count: 0});
    }

    /** @type {string} */
    get statusPrefix() {
        return `Importing dictionary${this._dictionaryCount > 1 ? ` (${this._dictionaryIndex} of ${this._dictionaryCount})` : ''}`;
    }

    /** @type {import('dictionary-importer').ImportStep} */
    get currentStep() {
        return this._steps[this._stepIndex];
    }

    /** @type {number} */
    get stepCount() {
        return this._steps.length;
    }

    /** @type {number} */
    get dictionaryCount() {
        return this._dictionaryCount;
    }

    /** @type {number} */
    get lastActivityTime() {
        return this._lastActivityTime;
    }

    /** @type {number} */
    get lastForwardProgressTime() {
        return this._lastForwardProgressTime;
    }

    /**
     * @returns {Array<Record<string, unknown>>}
     */
    getStepTimingHistory() {
        return this._stepTimingHistory.map((item) => ({...item}));
    }

    /** @param {() => boolean} check */
    setImportRunCheck(check) {
        this._isImportRunCurrent = check;
    }

    /** @type {import('dictionary-worker').ImportProgressCallback} */
    onProgress(data) {
        if (this._isImportRunCurrent !== null && !this._isImportRunCurrent()) { return; }
        const now = safePerformance.now();
        this._lastActivityTime = now;
        const {nextStep, index, count} = data;
        const previousStepIndex = this._stepIndex;
        if (nextStep && this._steps.length > 0) {
            this._stepIndex = Math.min(this._stepIndex + 1, this._steps.length - 1);
        }
        const progressSignature = `${this._dictionaryIndex}:${this._stepIndex}:${index}:${count}`;
        if (progressSignature !== this._lastProgressSignature) {
            this._lastProgressSignature = progressSignature;
            this._lastForwardProgressTime = now;
        }
        const currentStep = this.currentStep;
        const currentLabel = currentStep?.label ?? 'Working';
        const currentStepDisplay = `Step ${this._stepIndex + 1} of ${this.stepCount}`;
        const labelText = `${this.statusPrefix} - ${currentStepDisplay}: ${currentLabel}...`;
        if (labelText !== this._lastInfoLabelText) {
            this._lastInfoLabelText = labelText;
            for (const label of this._infoLabels) { label.textContent = labelText; }
        }

        const hasFiniteCount = Number.isFinite(count) && count > 0;
        let percentRaw = hasFiniteCount ? (index / count * 100) : 0;
        // Avoid showing a misleading 100% while a non-final step is still open.
        if (!nextStep && hasFiniteCount && this._stepIndex < (this.stepCount - 1) && index >= count) {
            percentRaw = 99.99;
        }
        const percent = Math.max(0, Math.min(100, percentRaw));
        if (this._lastPercent < 0 || Math.abs(percent - this._lastPercent) >= 0.1) {
            this._lastPercent = percent;
            const cssString = `${percent.toFixed(2)}%`;
            for (const progressBar of this._progressBars) { progressBar.style.width = cssString; }
        }
        const statusString = `${Math.floor(percent).toFixed(0)}%`;
        if (statusString !== this._lastStatusText) {
            this._lastStatusText = statusString;
            for (const label of this._statusLabels) { label.textContent = statusString; }
        }

        if (currentStep && typeof currentStep.callback === 'function') {
            currentStep.callback();
        }

        if (nextStep && this._steps.length > 0 && this._stepIndex !== previousStepIndex) {
            const completedStep = this._steps[previousStepIndex];
            const completedLabel = (typeof completedStep?.label === 'string' && completedStep.label.length > 0) ? completedStep.label : 'Starting import state';
            const stepDuration = now - this._stepStartTime;
            const stepEndMemory = getImportMemorySnapshot();
            const stepHeapDeltaBytes = getHeapDeltaBytes(this._stepStartMemory, stepEndMemory);
            log.log(`[ImportTiming] ${this.statusPrefix} completed Step ${previousStepIndex + 1} of ${this.stepCount} "${completedLabel}" in ${formatDurationMs(stepDuration)}`);
            const stepTiming = {
                dictionaryIndex: this._dictionaryIndex,
                dictionaryCount: this._dictionaryCount,
                stepIndex: previousStepIndex + 1,
                stepCount: this.stepCount,
                stepDisplay: `Step ${previousStepIndex + 1} of ${this.stepCount}`,
                label: completedLabel,
                uiLabelText: `${this.statusPrefix} - Step ${previousStepIndex + 1} of ${this.stepCount}: ${completedLabel}...`,
                nextUiLabelText: labelText,
                elapsedMs: Math.max(0, stepDuration),
                dictionaryElapsedMs: Math.max(0, now - this._dictionaryStartTime),
                totalElapsedMs: Math.max(0, now - this._importStartTime),
                memoryStart: this._stepStartMemory,
                memoryEnd: stepEndMemory,
                heapDeltaBytes: stepHeapDeltaBytes,
            };
            this._stepTimingHistory.push(stepTiming);
            if (this._stepTimingHistory.length > 256) {
                this._stepTimingHistory.splice(0, this._stepTimingHistory.length - 256);
            }
            reportDiagnostics('dictionary-import-step-complete', stepTiming);
            this._stepStartTime = now;
            this._stepStartMemory = stepEndMemory;
            this._stepChangeCount += 1;
        }
    }

    /** */
    onNextDictionary() {
        const now = safePerformance.now();
        if (this._dictionaryIndex > 0) {
            const previousDictionaryDuration = now - this._dictionaryStartTime;
            log.log(`[ImportTiming] dictionary ${this._dictionaryIndex}/${this._dictionaryCount} total progress phase time ${formatDurationMs(previousDictionaryDuration)}`);
        }
        this._dictionaryIndex += 1;
        this._stepIndex = 0;
        this._dictionaryStartTime = now;
        this._stepStartTime = now;
        this._dictionaryStartMemory = getImportMemorySnapshot();
        this._stepStartMemory = this._dictionaryStartMemory;
        log.log(`[ImportTiming] dictionary ${this._dictionaryIndex}/${this._dictionaryCount} started`);
        reportDiagnostics('dictionary-import-dictionary-start', {
            dictionaryIndex: this._dictionaryIndex,
            dictionaryCount: this._dictionaryCount,
            stepDisplay: `Step 1 of ${this.stepCount}`,
            totalElapsedMs: Math.max(0, now - this._importStartTime),
            memoryStart: this._dictionaryStartMemory,
        });
        this.onProgress({
            nextStep: true,
            index: 0,
            count: 0,
        });
    }

    /**
     * @param {number} errorCount
     */
    onImportComplete(errorCount) {
        const now = safePerformance.now();
        const currentStepLabel = this.currentStep?.label ?? `Step ${this._stepIndex + 1}`;
        const currentStepDuration = now - this._stepStartTime;
        const currentDictionaryDuration = now - this._dictionaryStartTime;
        const totalDuration = now - this._importStartTime;
        const memoryEnd = getImportMemorySnapshot();
        log.log(`[ImportTiming] ${this.statusPrefix} current step "${currentStepLabel}" open for ${formatDurationMs(currentStepDuration)}`);
        log.log(`[ImportTiming] dictionary ${this._dictionaryIndex}/${this._dictionaryCount} total progress phase time ${formatDurationMs(currentDictionaryDuration)}`);
        log.log(`[ImportTiming] all dictionaries progress phases complete in ${formatDurationMs(totalDuration)} (step-transitions=${this._stepChangeCount}, errors=${errorCount})`);
        const finalStepTiming = {
            dictionaryIndex: this._dictionaryIndex,
            dictionaryCount: this._dictionaryCount,
            stepIndex: this._stepIndex + 1,
            stepCount: this.stepCount,
            stepDisplay: `Step ${this._stepIndex + 1} of ${this.stepCount}`,
            label: currentStepLabel,
            elapsedMs: Math.max(0, currentStepDuration),
            dictionaryElapsedMs: Math.max(0, currentDictionaryDuration),
            totalElapsedMs: Math.max(0, totalDuration),
            memoryStart: this._stepStartMemory,
            memoryEnd,
            heapDeltaBytes: getHeapDeltaBytes(this._stepStartMemory, memoryEnd),
            finalOpenStep: true,
        };
        this._stepTimingHistory.push(finalStepTiming);
        if (this._stepTimingHistory.length > 256) {
            this._stepTimingHistory.splice(0, this._stepTimingHistory.length - 256);
        }
        reportDiagnostics('dictionary-import-step-final', finalStepTiming);
        reportDiagnostics('dictionary-import-progress-summary', {
            dictionaryIndex: this._dictionaryIndex,
            dictionaryCount: this._dictionaryCount,
            currentStepIndex: this._stepIndex + 1,
            currentStepDisplay: `Step ${this._stepIndex + 1} of ${this.stepCount}`,
            currentStepLabel,
            currentStepElapsedMs: Math.max(0, currentStepDuration),
            currentDictionaryElapsedMs: Math.max(0, currentDictionaryDuration),
            totalElapsedMs: Math.max(0, totalDuration),
            stepTransitions: this._stepChangeCount,
            errorCount,
            memoryStart: this._dictionaryStartMemory,
            memoryEnd,
            dictionaryHeapDeltaBytes: getHeapDeltaBytes(this._dictionaryStartMemory, memoryEnd),
            currentStepHeapDeltaBytes: getHeapDeltaBytes(this._stepStartMemory, memoryEnd),
        });
    }
}
