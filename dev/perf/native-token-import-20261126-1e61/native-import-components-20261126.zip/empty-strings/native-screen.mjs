import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {openAsBlob} from 'node:fs'
import {readFile, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {performance} from 'node:perf_hooks'
import {fileURLToPath} from 'node:url'
import {BlobReader, Uint8ArrayWriter, ZipReader} from '@zip.js/zip.js'

const [repo, baselineWasm, candidateWasm, fixture, output] = process.argv.slice(2)
assert(repo && baselineWasm && candidateWasm && fixture && output)
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const wasmBytes = {A: await readFile(baselineWasm), B: await readFile(candidateWasm)}
wasmBytes.C = wasmBytes.A
const fixtureBytes = await readFile(fixture)
const lock = JSON.parse(await readFile(path.resolve(repo, 'test/perf/dictionaries.lock.json'))).dictionaries.jitendex
assert.equal(hash(fixtureBytes), lock.sha256)
const zip = new ZipReader(new BlobReader(await openAsBlob(fixture)), {useWebWorkers: false})
const entries = (await zip.getEntries()).filter((e) => /^term_bank_\d+\.json$/.test(e.filename))
    .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
const selected = Array.from({length: 8}, (_, i) => entries[Math.floor(i * (entries.length - 1) / 7)])
const banks = []
for (const entry of selected) banks.push(await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}))
await zip.close()
const encoder = new TextEncoder()
const synthetic = encoder.encode(JSON.stringify(Array.from({length: 4096}, (_, i) => [
    `expression-${i}`, `reading-${i}`, 'noun', 'rule', i % 100,
    [{type: 'structured-content', content: {tag: 'span', data: {class: 'definition'}, content: `Meaning number ${i}: a nonempty definition.`}}], i, 'common',
])))
const decoder = new TextDecoder()
const workloads = [{name: 'jitendex-eight-spread-banks', banks, iterations: 64, files: selected.map((e) => e.filename)}, {name: 'no-empty-string-structured-rows', banks: [synthetic], iterations: 512}]
for (const workload of workloads) workload.rowCounts = workload.banks.map((bank) => JSON.parse(decoder.decode(bank)).length)
const permutations = ['ABC', 'BCA', 'CAB', 'ACB', 'CBA', 'BAC']
const threadCpu = typeof process.threadCpuUsage === 'function' ? process.threadCpuUsage.bind(process) : null
const report = {complete: false, runnerSha256: hash(await readFile(fileURLToPath(import.meta.url))), boundary: 'Only strict native parse_term_bank calls over resident validated source banks and preallocated output arenas. No allocation, JSON decoding, hashing, worker transfer, content encoding, lookup construction, compression, storage, or UI within measured intervals.', node: process.version, hasThreadCpuUsage: threadCpu !== null, fixtureSha256: lock.sha256, moduleSha256: Object.fromEntries(Object.entries(wasmBytes).map(([arm, bytes])=>[arm,hash(bytes)])), protocol: {warmupOrders:['ABC','CBA'], timedOrders:permutations, guardBytes:32, metadataBytesPerRow:68}, workloads:workloads.map(({name, files, iterations, banks:inputs, rowCounts})=>({name,files,iterations,rowCounts,inputSha256:inputs.map(hash),inputBytes:inputs.reduce((sum, bytes)=>sum+bytes.byteLength,0)})), observations: []}
const save = () => writeFile(output, JSON.stringify(report, null, 2)+'\n')
await writeFile(output, JSON.stringify(report, null, 2)+'\n', {flag:'wx'})
const arms = {}
for (const arm of ['A','B','C']) arms[arm] = (await WebAssembly.instantiate(await WebAssembly.compile(wasmBytes[arm]))).exports
function prepare(wasm, workload) {
    wasm.wasm_reset_heap()
    return workload.banks.map((bytes, index)=>{
        const rows = workload.rowCounts[index]
        const inputAllocation = wasm.wasm_alloc(bytes.length+64)
        const outputAllocation = wasm.wasm_alloc(rows*68+64)
        const input = inputAllocation+32
        const output = outputAllocation+32
        assert(inputAllocation && outputAllocation)
        const heap = new Uint8Array(wasm.memory.buffer)
        heap.fill(0x22,inputAllocation,inputAllocation+bytes.length+64)
        heap.set(bytes,input)
        heap.fill(0xa7,outputAllocation,outputAllocation+rows*68+64)
        return {rows,input,output,inputAllocation,outputAllocation,inputLength:bytes.length,inputSha256:hash(bytes)}
    })
}
function check(wasm, prepared) {
    const heap = new Uint8Array(wasm.memory.buffer)
    const digest = createHash('sha256')
    for(const source of prepared) {
        assert(heap.subarray(source.inputAllocation,source.input).every((b)=>b===0x22))
        assert(heap.subarray(source.input+source.inputLength,source.input+source.inputLength+32).every((b)=>b===0x22))
        assert.equal(hash(heap.subarray(source.input,source.input+source.inputLength)),source.inputSha256)
        assert(heap.subarray(source.outputAllocation,source.output).every((b)=>b===0xa7))
        assert(heap.subarray(source.output+source.rows*68,source.output+source.rows*68+32).every((b)=>b===0xa7))
        digest.update(heap.subarray(source.output,source.output+source.rows*68))
    }
    return digest.digest('hex')
}
for (const workload of workloads) {
    const prepared = Object.fromEntries(Object.entries(arms).map(([arm,wasm])=>[arm,prepare(wasm,workload)]))
    let expected
    for (const [phase,schedule] of [['warmup',['ABC','CBA']],['timed',permutations]]) {
        for(const [block,order] of schedule.entries()) {
            for(const arm of order) {
                const wasm = arms[arm]
                const sources = prepared[arm]
                const parse = wasm.parse_term_bank
                const previousThread = threadCpu?.()
                const previousCpu = process.cpuUsage()
                const started = performance.now()
                for(let repeat=0;repeat<workload.iterations;++repeat) {
                    for(let index=0;index<sources.length;++index) {
                        const source = sources[index]
                        const rows = parse(source.input,source.inputLength,source.output,source.rows,0,0,1)
                        if(rows!==source.rows) throw new Error(`Unexpected native row count ${rows}`)
                    }
                }
                const elapsedMs = performance.now()-started
                const usedThread = threadCpu?.(previousThread)
                const usedCpu = process.cpuUsage(previousCpu)
                const digest = check(wasm,sources)
                expected ??= digest
                assert.equal(digest,expected)
                const observation = {workload:workload.name,phase,block,arm,iterations:workload.iterations,elapsedMs,processCpuMs:(usedCpu.user+usedCpu.system)/1000,threadCpuMs:usedThread ? (usedThread.user+usedThread.system)/1000 : null,metadataDigest:digest,nativeMemoryBytes:wasm.memory.buffer.byteLength}
                report.observations.push(observation)
                await save()
                console.log(JSON.stringify(observation))
            }
        }
    }
}
report.complete = true
await save()
