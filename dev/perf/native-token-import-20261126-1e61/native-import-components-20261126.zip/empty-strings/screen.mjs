import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, writeFile} from 'node:fs/promises'
import {openAsBlob} from 'node:fs'
import {BlobReader, Uint8ArrayWriter, ZipReader} from '@zip.js/zip.js'
import path from 'node:path'
import {performance} from 'node:perf_hooks'
import {fileURLToPath, pathToFileURL} from 'node:url'

const [repo, baselineWasm, candidateWasm, fixture, output] = process.argv.slice(2)
assert(repo && baselineWasm && candidateWasm && fixture && output)
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const moduleBytes = {A: await readFile(baselineWasm), B: await readFile(candidateWasm)}
moduleBytes.C = moduleBytes.A
const parsers = {}
for (const arm of ['A', 'B', 'C']) {
    const url = pathToFileURL(path.resolve(repo, 'ext/js/dictionary/term-bank-wasm-parser.js'))
    url.searchParams.set('empty-string-arm', arm)
    parsers[arm] = await import(url.href)
    parsers[arm].setTermBankWasmModule(await WebAssembly.compile(moduleBytes[arm]))
}
const fixtureBytes = await readFile(fixture)
const lock = JSON.parse(await readFile(path.resolve(repo, 'test/perf/dictionaries.lock.json'))).dictionaries.jitendex
assert.equal(hash(fixtureBytes), lock.sha256)
const archive = await openAsBlob(fixture)
const reader = new ZipReader(new BlobReader(archive), {useWebWorkers: false})
const entries = (await reader.getEntries()).filter((e) => /^term_bank_\d+\.json$/.test(e.filename))
    .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
const selected = Array.from({length: 8}, (_, i) => entries[Math.floor(i * (entries.length - 1) / 7)])
const banks = []
for (const entry of selected) banks.push(await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}))
await reader.close()
const encoder = new TextEncoder()
const synthetic = encoder.encode(JSON.stringify(Array.from({length: 4096}, (_, i) => [
    `expression-${i}`, `reading-${i}`, 'noun', 'rule', i % 100,
    [{type: 'structured-content', content: {tag: 'span', data: {class: 'definition'}, content: `Meaning number ${i}: a nonempty definition.`}}], i, 'common',
])))
const workloads = [{name: 'jitendex-eight-spread-banks', banks, files: selected.map((e) => e.filename)}, {name: 'no-empty-string-structured-rows', banks: [synthetic], rows: 4096}]
const permutations = ['ABC', 'BCA', 'CAB', 'ACB', 'CBA', 'BAC']
const sourceHash = async (file) => hash(await readFile(path.resolve(repo, file)))
const report = {complete: false, runnerSha256: hash(await readFile(fileURLToPath(import.meta.url))), parserJsSha256: await sourceHash('ext/js/dictionary/term-bank-wasm-parser.js'), candidateCsha256: await sourceHash('ext/js/dictionary/wasm/term-bank-parser.c'), workloads: workloads.map(({name, files, banks: inputs}) => ({name, files, inputSha256: inputs.map(hash), inputBytes: inputs.reduce((sum, bytes) => sum+bytes.byteLength, 0)})), boundary: 'Resident decoded source bytes through first complete native column chunk with prepared lookup indexes; excludes ZIP decode, worker transfer, compression, persistence and browser/UI time.', node: process.version, fixtureSha256: lock.sha256, moduleSha256: Object.fromEntries(Object.entries(moduleBytes).map(([a,b])=>[a,hash(b)])), observations: []}
const save = () => writeFile(output, JSON.stringify(report, null, 2)+'\n')
await writeFile(output, JSON.stringify(report, null, 2)+'\n', {flag:'wx'})
function digestChunk(chunk) {
    const digest = createHash('sha256')
    const bytes = (view) => { if (ArrayBuffer.isView(view)) { digest.update(Buffer.from(view.buffer, view.byteOffset, view.byteLength)) } }
    for (const key of ['readingEqualsExpressionList','scoreList','sequenceList','contentMetaList','contentUniqueIndexList']) bytes(chunk[key])
    for (const value of Object.values(chunk.termRecordPreinternedPlan)) bytes(value)
    digest.update(chunk.contentBytesBuffer.subarray(chunk.contentBytesBaseOffset, chunk.contentBytesBaseOffset+chunk.contentBytesLength))
    for (const [key, prepared] of chunk.preparedLookupIndexes ?? []) { digest.update(key); bytes(prepared.bytes); for(const value of Object.values(prepared.preinternedPlan)) bytes(value) }
    digest.update(JSON.stringify(chunk.mediaRows))
    return digest.digest('hex')
}
for (const workload of workloads) {
    let expected
    for (const [phase, schedule] of [['warmup',['ABC','CBA']],['timed',permutations]]) {
        for (const [block, permutation] of schedule.entries()) {
            for (const arm of permutation) {
                const parser = parsers[arm]
                let observation
                const cpu = process.cpuUsage()
                const started = performance.now()
                await parser.parseTermBankWithWasmColumnChunks(workload.banks, 3, (chunk) => {
                    const elapsedMs = performance.now()-started
                    const used = process.cpuUsage(cpu)
                    assert.equal(observation, undefined)
                    observation = {workload: workload.name, phase, block, arm, elapsedMs, processCpuMs:(used.user+used.system)/1000, rows:chunk.rowCount, digest:digestChunk(chunk)}
                }, 2048, {singleChunk: true, emitTermByteLists: false, computeContentHashes: true, emitContentSlab: true, emitTokenBinaryContent: true, mediaHintFastScan: false, validateGlossaryTypes: true, prepareLookupIndexes: true})
                assert(observation)
                expected ??= observation.digest
                assert.equal(observation.digest,expected)
                const profile = parser.consumeLastTermBankWasmParseProfile()
                observation.experiments = profile.experiments
                observation.maxWasmHeapBytes = profile.maxWasmHeapBytes
                observation.fusedParseFallbacks = profile.fusedParseFallbacks
                report.observations.push(observation)
                await save()
                console.log(JSON.stringify(observation))
            }
        }
    }
}
report.complete = true
await save()
