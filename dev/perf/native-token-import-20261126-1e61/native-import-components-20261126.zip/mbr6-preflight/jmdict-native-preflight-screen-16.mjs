import fs from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {performance} from 'node:perf_hooks'
import {ZipReader, Uint8ArrayReader, Uint8ArrayWriter} from './jmdict/node_modules/@zip.js/zip.js/index.js'

const directory = '/workspace/scratch/1e61bf8c01fe'
const archivePath = '/workspace/scratch/4344255ab4f9/fixtures/JMdict.zip'
const baselinePath = '/workspace/scratch/b4b304adc609/manabitan/dev/data/dictionary-wasm/term-bank-parser.wasm'
const candidatePath = directory + '/jmdict/dev/data/dictionary-wasm/term-bank-parser.wasm'
const outputPath = directory + '/jmdict-native-preflight-screen-16.json'
const iterationsPerObservation = 16
const warmupsPerArmBank = 16
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const archive = await fs.readFile(archivePath)
const lock = JSON.parse(await fs.readFile(directory + '/jmdict/test/perf/dictionaries.lock.json', 'utf8')).dictionaries.jmdict
if (hash(archive) !== lock.sha256) throw new Error('Fixture identity mismatch')
const baseline = await fs.readFile(baselinePath)
const candidate = await fs.readFile(candidatePath)
const instances = await Promise.all([baseline, candidate, baseline].map(async (bytes) => (await WebAssembly.instantiate(bytes)).instance.exports))
const report = {iterationsPerObservation, warmupsPerArmBank, schedule: 'for successive banks first order ABC, BCA, CAB; second order reverses first; each bank has two timed triplets', boundary: 'preparsed native MBR6 encoder only, all source rows before canonical deduplication; excludes parsing, inflation, interning, workers, compression, storage and UI', baselineSha256: hash(baseline), candidateSha256: hash(candidate), archiveSha256: hash(archive), node: process.version, complete: false, rows: 0, literalRows: 0, outputBytes: 0, banks: []}
report.runnerSha256 = hash(await fs.readFile(new URL(import.meta.url)))
report.baselineSourceSha256 = hash(await fs.readFile('/workspace/scratch/b4b304adc609/manabitan/ext/js/dictionary/wasm/term-bank-parser.c'))
report.candidateSourceSha256 = hash(await fs.readFile(directory + '/jmdict/ext/js/dictionary/wasm/term-bank-parser.c'))
report.baselineManifestSha256 = hash(await fs.readFile('/workspace/scratch/b4b304adc609/manabitan/dev/data/dictionary-wasm/manifest.json'))
report.candidateManifestSha256 = hash(await fs.readFile(directory + '/jmdict/dev/data/dictionary-wasm/manifest.json'))
const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)))
function prepare(wasm, bytes, rows) {
    wasm.wasm_reset_heap()
    const input = wasm.wasm_alloc(bytes.length)
    const metas = wasm.wasm_alloc(rows * 68)
    const outputMetas = wasm.wasm_alloc(rows * 16)
    const capacity = bytes.length + rows * 32
    const output = wasm.wasm_alloc(capacity)
    new Uint8Array(wasm.memory.buffer, input, bytes.length).set(bytes)
    if (wasm.parse_term_bank_with_media_hints(input, bytes.length, metas, rows) !== rows) throw new Error('Parse failed')
    return {input, metas, outputMetas, capacity, output}
}
function encode(wasm, setup, rows) {
    const {input, metas, outputMetas, capacity, output} = setup
    const n = wasm.encode_term_content_token_binary(input, metas, rows, output, capacity, outputMetas)
    if (n < 0) throw new Error('Encode failed: ' + n)
    return n
}
try {
    const entries = (await reader.getEntries()).filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
    for (let index = 0; index < entries.length; ++index) {
        const entry = entries[index]
        const bytes = await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true})
        const rows = JSON.parse(new TextDecoder().decode(bytes)).length
        const setups = instances.map((wasm) => prepare(wasm, bytes, rows))
        const rowMetas = new Uint32Array(instances[0].memory.buffer, setups[0].metas, rows * 17)
        for (let i = 0; i < rows; ++i) if (rowMetas[i * 17 + 16] === 0) ++report.literalRows
        const firstOrder = [[0, 1, 2], [1, 2, 0], [2, 0, 1]][index % 3]
        for (let warmup = 0; warmup < warmupsPerArmBank; ++warmup) {
            for (const arm of firstOrder) encode(instances[arm], setups[arm], rows)
        }
        const observations = []
        for (let pass = 0; pass < 2; ++pass) {
            const order = pass === 0 ? firstOrder : [...firstOrder].reverse()
            for (const arm of order) {
                const cpu = process.cpuUsage()
                const start = performance.now()
                let n = 0
                for (let iteration = 0; iteration < iterationsPerObservation; ++iteration) {
                    n = encode(instances[arm], setups[arm], rows)
                }
                const elapsedMs = performance.now() - start
                const cpuUs = process.cpuUsage(cpu)
                const {output, outputMetas} = setups[arm]
                const resultHash = createHash('sha256').update(new Uint8Array(instances[arm].memory.buffer, output, n)).update(new Uint8Array(instances[arm].memory.buffer, outputMetas, rows * 16)).digest('hex')
                observations.push({arm: 'ABC'[arm], pass, elapsedMs, cpuUs: cpuUs.user + cpuUs.system, outputBytes: n, digest: resultHash})
            }
        }
        if (observations.some((x) => x.digest !== observations[0].digest)) throw new Error('Output mismatch at bank ' + entry.filename)
        report.rows += rows
        report.outputBytes += observations[0].outputBytes
        report.banks.push({file: entry.filename, rows, observations})
        if (index % 10 === 0) console.log('bank ' + (index + 1) + '/' + entries.length)
        await fs.writeFile(outputPath, JSON.stringify(report, null, 2))
    }
    if (report.rows !== lock.termRows) throw new Error('Row count mismatch')
    report.complete = true
} catch (error) {
    report.error = String(error)
    throw error
} finally {
    await reader.close()
    await fs.writeFile(outputPath, JSON.stringify(report, null, 2))
}
console.log(JSON.stringify({complete: report.complete, rows: report.rows, literalRows: report.literalRows, outputBytes: report.outputBytes}))
