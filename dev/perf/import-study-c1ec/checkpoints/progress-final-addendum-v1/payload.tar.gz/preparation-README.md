# Import optimization evidence: final addendum preparation

**This is a draft additive checkpoint, not a completed archive or a performance qualification.** The remaining Chrome group-burst study is queued; its independent reader is frozen. No PR has been created from these results.

## Immutable prior checkpoint

The earlier source variants, correctness gates, adverse and inconclusive results, and both broader UTF-8 cohorts remain in [the published checkpoint](https://github.com/ManabiIO/manabitan/tree/0ab2ff5050dba9b528eefdeffcb4f0eb8c6357b0/dev/perf/import-study-c1ec).

- Commit: `0ab2ff5050dba9b528eefdeffcb4f0eb8c6357b0`
- Tree: `168d5d2e44ec3d030798c56ac07c4b8a4710503d`
- Reassembled archive SHA-256: `cedf25a9fd678588195f2e28b158a5df9339deb37d6ea0a2bc22e2ce0e8c19c5` (13,833,588 bytes)
- Manifest SHA-256: `47b2510e060fce8810f518acc470e39519b4cd715dad19310bd9737c92d75e59`

This addendum references that archive rather than embedding it again. Byte-identical selected files already listed in its manifest can also be referenced by their prior archive member and digest. Newly required bytes are stored once by SHA-256. The manifest retains every original evidence path and its storage location.

## Outcomes available now

| Work | Observed result | Decision and scope |
| --- | --- | --- |
| Direct native-writer Chrome diagnostic, run `46118417081` | Exact runtime/test lint, main/test types, 46 focused cases, and the actual-Chrome integrity canary passed. Production-planner preflight then failed before any admission or timing observation. | **No speed result.** The old run, frozen reader, partial artifact and failure remain intact. |
| Planner metadata diagnosis | The serialized adapter omitted both `getData` presence and ZIP entry offsets. Restoring only `getData` was insufficient; actual entries and a faithful adapter were admitted. No data reads, decompression, parser, worker, browser or timing occurred in this smoke. | A harness defect was identified. This does not retroactively complete the failed run or establish a grouping/performance result. |
| Paired-CJK native-export diagnostic | All 3 preflights and 36 timed children completed: 183 full passes and 2,196 original calls, with source and semantic equality. The identical-code control exceeded its frozen 3% limit. | **Mechanism line stopped.** No replacement observations, different timers, browser promotion or PR. Earlier broader cohorts remain held. |
| Explicit 16-byte SIMD string scanner | PR #19 already contains the exact v128 quote/backslash/control-byte mask, bitmask and `ctz` scanner. | Retired without a new implementation. Its historical C change also included `memmove`; adverse high-load timings are not an isolated SIMD ablation. |
| Native group-burst source | Local `e88cf52a` and published `9e14b530` have the same tree `e9a70a78`. All 52 focused cases and changed-test lint passed; runtime and canary static reviews found no concrete blocker. | Functional evidence only. Runtime/types/actual-Chrome/performance results for the new study remain separate gates. Earlier setup failures are preserved. |
| New group-burst Chrome study | Plan `fd39b31b…`, canary `16241ce8…`, reader `8ac89a09…` with 47 synthetic guards, and reader freeze `95017c90…` are recorded. Wrapper `18661492…` / tree `361e102f…` is published and verified; run `46126332612`, job `140921633790`, is queued. | **Result pending.** No completed observation or qualification is asserted. |

### Native-export result

The primary is the **complete captured original fused WASM export plus the identical call/clock boundary**, including any memory growth inside it. It is neither complete parser CPU nor isolated `copy_valid_utf8` cost. One observation is the mean of three measured pass totals after two excluded full warmups in a fresh process.

| Comparison | Median native CPU change | Equal-work change | Faster blocks | Descriptive 95% interval |
| --- | ---: | ---: | ---: | ---: |
| B / A | +9.447% | +5.101% | 5/12 | −9.294% to +22.302% |
| B / C | −2.319% | +0.735% | 7/12 | −8.888% to +14.072% |
| Identical C / A | +4.904% | +4.334% | 5/12 | −8.020% to +16.360% |

The independent audit verified all child identities, 183 passes, 2,196 calls, source/output equality, pass totals, means and all 15 bootstrap comparisons/distributions. The failed control and failed candidate gates remain decisive. No cause of the variability is established.

## Qualification boundary after develop advanced

Every study above remains frozen on baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. Root subsequently observed develop at `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`, merging PR #972. The separate API receipt and scope notice preserve the four intervening commits and affected paths. Runtime JavaScript, source pipeline and dependencies were unchanged in that comparison, while C/WASM/manifest/tests/screen files changed.

These results are evidence about the exact old baseline. Any worthwhile native signal would require rebasing and verifying on current develop before a PR. This work takes no credit for #972, and none of the frozen plans or observations are rewritten to use the newer base.

## What the addendum retains

`checkpoint-plan.json` is the bounded inclusion list. It includes the failed writer artifact's extracted reports, immutable artifact ID/hash and context; frozen old reader and failure diagnosis; the complete native-export cohort/harness/gates/reviews; exact SIMD prior art; group-burst source, tests, lint failures and passes, reviews and publication; and the new Chrome plan, canary and eventual frozen reader/result. Generated caches and reproducible arm symlinks are recorded as exclusions and are never followed. Dependencies and dictionary ZIPs are not copied.

Historical receipts retain their original wording, including statements that a review or publication was pending at their timestamp. Later receipts are separate; the draft does not alter old files to make their status appear current.

## Finalization after the Chrome outcome is available

Preparation is read-only with respect to the original evidence:

```sh
python3 build_addendum.py inventory --output inventory-draft-v1.json
```

When root has the terminal run context, verified artifact extraction, final independent audit, reader freeze and wrapper publication receipt, copy `terminal-spec.example.json` to a new file and replace every pending value with the exact verified paths/IDs/hashes. A failed terminal run can be archived honestly; it must not be relabeled a complete successful acquisition.

```sh
python3 build_addendum.py finalize --terminal-spec terminal-observed.json --output snapshot-01
python3 restore_addendum.py snapshot-01/payload.tar.gz --expected-payload-sha256 SHA_FROM_FINAL_RECEIPT --prior-payload /path/to/prior-payload.tar.gz --output restored-addendum
```

The finalizer refuses pending terminal specifications, missing receipts, source/hash drift and oversized unexpected inputs. It writes only a new output directory, never changes the original evidence, never runs a parser/browser/benchmark, and never publishes or creates a PR. It verifies the completed tar member identities before writing its receipt. Final archive completeness means that the declared terminal evidence is preserved; it does not mean that a performance or product gate passed.

The restore helper verifies the addendum and required prior objects before reconstructing regular files. It creates no symlinks and executes no restored content. The stopped diagnostic remains stopped after restoration.
