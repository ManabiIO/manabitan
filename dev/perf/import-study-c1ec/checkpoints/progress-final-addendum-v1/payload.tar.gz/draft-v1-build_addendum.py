#!/usr/bin/env python3
"""Inventory or finalize additive evidence. Never run experiments or publish."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import tarfile
import zipfile

HERE = Path(__file__).resolve().parent
CONFIG = HERE / 'checkpoint-plan.json'
IGNORED_DIRECTORIES = {'__pycache__', 'node_modules', '.git'}


def fail(message):
    raise RuntimeError(message)


def check(condition, message):
    if not condition:
        fail(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def inside(root, value):
    path = Path(value)
    if not path.is_absolute():
        path = root / path
    path = path.absolute()
    check(path.is_relative_to(root), f'Path escapes workspace: {value}')
    check('..' not in path.relative_to(root).parts, f'Parent path segment: {value}')
    return path


def read_stable(path, limit):
    check(path.is_file() and not path.is_symlink(), f'Not a regular evidence file: {path}')
    before = path.stat()
    check(before.st_size <= limit, f'Unexpectedly large file; do not truncate: {path}')
    data = path.read_bytes()
    after = path.stat()
    check((before.st_size, before.st_mtime_ns, before.st_ino) ==
          (after.st_size, after.st_mtime_ns, after.st_ino), f'File changed during read: {path}')
    return data, stat.S_IMODE(before.st_mode) & 0o777


def receipt_json(root, item, limit):
    path = inside(root, item['path'])
    data, _ = read_stable(path, limit)
    check(sha(data) == item['sha256'], f'Receipt identity differs: {path}')
    return json.loads(data)


def select_files(root, selections):
    selected, excluded = {}, []
    for selection in selections:
        base = inside(root, selection['path'])
        check(base.exists(), f'Missing selected evidence: {base}')
        if base.is_symlink():
            fail(f'Selection root is a symlink: {base}')
        if base.is_file():
            candidates = [base]
        else:
            candidates = []
            for directory, dirs, names in os.walk(base, followlinks=False):
                parent = Path(directory)
                kept = []
                for name in sorted(dirs):
                    item = parent / name
                    if name in IGNORED_DIRECTORIES or item.is_symlink():
                        excluded.append({'path': str(item.relative_to(root)),
                            'reason': 'Generated dependency/cache directory or reproducible symlink; never followed',
                            'linkTarget': os.readlink(item) if item.is_symlink() else None})
                    else:
                        kept.append(name)
                dirs[:] = kept
                candidates.extend(parent / name for name in sorted(names))
        for path in candidates:
            relative = str(path.relative_to(root))
            if path.is_symlink() or path.suffix == '.pyc':
                excluded.append({'path': relative, 'reason': 'Derived cache or reproducible symlink; never followed',
                    'linkTarget': os.readlink(path) if path.is_symlink() else None})
                continue
            check(path.is_file(), f'Unexpected non-file evidence: {path}')
            selected.setdefault(relative, set()).add(selection['group'])
    return selected, excluded


def git_bytes(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], timeout=30,
        env={**os.environ, 'GIT_NO_LAZY_FETCH': '1', 'GIT_TERMINAL_PROMPT': '0', 'GIT_OPTIONAL_LOCKS': '0'})


def terminal_evidence(root, config, path):
    spec_bytes, _ = read_stable(path, config['bounds']['singleFileBytes'])
    spec = json.loads(spec_bytes)
    check(spec.get('state') == 'terminal-observed', 'Chrome outcome is still pending; no final archive may be created')
    limit = config['bounds']['singleFileBytes']
    publication = receipt_json(root, spec['publicationReceipt'], limit)
    freeze = receipt_json(root, spec['readerFreeze'], limit)
    context = receipt_json(root, spec['context'], limit)
    audit = receipt_json(root, spec['audit'], limit)
    run = context['run']
    check(run['id'] == spec['runId'] == config['chrome']['runId'] and run['status'] == 'completed',
          'Run is not the declared terminal acquisition')
    check(publication.get('refVerified') is True, 'Wrapper publication is not verified')
    check(publication['commit'] == run['head_sha'] == config['chrome']['wrapperCommit'], 'Run does not use the published wrapper')
    check(spec['publicationReceipt']['sha256'] == config['chrome']['publicationReceiptSha256'], 'Unexpected publication receipt')
    check(spec['readerFreeze']['sha256'] == config['chrome']['readerFreezeSha256'], 'Unexpected reader freeze')
    check(publication['tree'] == config['chrome']['wrapperTree'], 'Unexpected wrapper tree')
    check(audit['wrapperSha'] == run['head_sha'], 'Audit wrapper identity differs')
    check(audit['planSha256'] == config['chrome']['planSha256'], 'Audit plan differs')
    freeze_text = json.dumps(freeze)
    check(config['chrome']['readerSha256'] in freeze_text and config['chrome']['planSha256'] in freeze_text,
          'Reader freeze does not bind the declared reader and plan')
    artifact = spec['artifact']
    artifact_path = inside(root, artifact['path'])
    artifact_bytes, _ = read_stable(artifact_path, config['bounds']['artifactBytes'])
    check(sha(artifact_bytes) == artifact['sha256'], 'Artifact ZIP hash differs')
    check(audit['artifactSha256'] == artifact['sha256'] and audit['artifactId'] == artifact['id'],
          'Audit and terminal artifact identity differ')
    extracted = inside(root, artifact['extractedPath'])
    member_receipts = []
    with zipfile.ZipFile(io.BytesIO(artifact_bytes)) as archive:
        seen = set()
        for member in archive.infolist():
            logical = PurePosixPath(member.filename)
            check(not logical.is_absolute() and '..' not in logical.parts, 'Unsafe artifact member')
            check(member.filename not in seen, 'Duplicate artifact member')
            seen.add(member.filename)
            if member.is_dir():
                continue
            check(member.file_size <= config['bounds']['singleFileBytes'], 'Oversized artifact member; do not omit it')
            original = archive.read(member)
            actual, _ = read_stable(extracted / member.filename, config['bounds']['singleFileBytes'])
            check(actual == original, f'Extracted artifact member changed: {member.filename}')
            member_receipts.append({'name': member.filename, 'bytes': len(original), 'sha256': sha(original)})
    check(isinstance(audit.get('status'), str) and isinstance(spec.get('outcomeSummary'), str), 'Missing terminal interpretation')
    selections = [{'path': str(extracted.relative_to(root)), 'group': 'terminal-chrome-artifact'}]
    selections += [{'path': spec[key]['path'], 'group': 'terminal-chrome-binding'}
                   for key in ['publicationReceipt', 'readerFreeze', 'context', 'audit']]
    selections += [{'path': value, 'group': 'terminal-chrome-additional-evidence'}
                   for value in spec.get('additionalEvidencePaths', [])]
    selections.append({'path': str(path.relative_to(root)), 'group': 'terminal-chrome-specification'})
    observation_data = audit.get('observations', [])
    terminal = {'state': 'terminal-observed', 'runId': run['id'], 'wrapperCommit': run['head_sha'],
        'ciConclusion': run['conclusion'], 'auditStatus': audit['status'],
        'auditedObservationCount': len(observation_data) if isinstance(observation_data, list) else None,
        'summary': spec['outcomeSummary'], 'specSha256': sha(spec_bytes),
        'artifact': {'id': artifact['id'], 'sha256': artifact['sha256'], 'bytes': len(artifact_bytes),
            'payloadIncluded': False, 'allExtractedMembersVerified': member_receipts},
        'productPrQualified': False, 'baseline': config['baseline'],
        'qualificationBoundary': 'Exact9e component evidence only; current-develop rebase/reverification and full-import gates remain separate.'}
    return terminal, selections


def collect(config, extra):
    root = Path(config['workspaceRoot']).resolve()
    prior = receipt_json(root, config['prior']['manifest'], config['bounds']['singleFileBytes'])
    publication = receipt_json(root, config['prior']['publicationReceipt'], config['bounds']['singleFileBytes'])
    check(publication['commit'] == config['prior']['commit'] and publication['refVerified'], 'Prior publication differs')
    check(publication['archiveSha256'] == config['prior']['payloadSha256'], 'Prior payload identity differs')
    prior_by_hash = {}
    for item in prior['files']:
        prior_by_hash.setdefault((item['sha256'], item['bytes']), []).append(item['archivePath'])
    for relative, expected in config['fixedFiles'].items():
        data, _ = read_stable(inside(root, relative), config['bounds']['singleFileBytes'])
        check(sha(data) == expected, f'Frozen source/harness/receipt changed: {relative}')
    selected, excluded = select_files(root, config['selections'] + extra)
    objects, records, total = {}, [], 0

    def add(logical, data, mode, groups, source):
        nonlocal total
        digest = sha(data)
        check(digest != config['prior']['payloadSha256'], 'The prior payload must never be duplicated')
        total += len(data)
        check(total <= config['bounds']['totalSelectedBytes'], 'Unexpectedly large selection; do not truncate it')
        record = {'path': logical, 'source': source, 'bytes': len(data), 'sha256': digest,
            'mode': mode, 'groups': sorted(groups)}
        matches = prior_by_hash.get((digest, len(data)))
        if matches:
            record['storage'] = {'kind': 'prior-checkpoint', 'archivePath': sorted(matches)[0]}
        else:
            objects.setdefault(digest, data)
            record['storage'] = {'kind': 'addendum-object', 'archivePath': 'objects/' + digest}
        records.append(record)

    for relative, groups in sorted(selected.items()):
        data, mode = read_stable(inside(root, relative), config['bounds']['singleFileBytes'])
        if relative in config['fixedFiles']:
            check(sha(data) == config['fixedFiles'][relative], f'Frozen bytes changed before capture: {relative}')
        add('workspace/' + relative, data, mode, groups, relative)
    commit_receipts = []
    prior_commits = {item['commit'] for item in prior['sourceCommitPatches']}
    for item in config['newLocalSourceCommits']:
        repository = inside(root, item['repository'])
        commit, parent, tree = item['commit'], item['parent'], item['tree']
        check(parent in prior_commits, 'New source parent is absent from prior checkpoint')
        check(git_bytes(repository, 'rev-parse', commit + '^').decode().strip() == parent, 'Source parent differs')
        check(git_bytes(repository, 'rev-parse', commit + '^{tree}').decode().strip() == tree, 'Source tree differs')
        raw = git_bytes(repository, 'cat-file', 'commit', commit)
        check(hashlib.sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == commit, 'Raw commit identity differs')
        patch = git_bytes(repository, 'diff', '--binary', '--full-index', '--no-ext-diff', '--no-textconv',
            '--src-prefix=a/', '--dst-prefix=b/', parent, commit)
        add('source-objects/' + commit + '.raw', raw, 0o644, ['new-source-commit'], None)
        add('source-patches/' + commit + '.patch', patch, 0o644, ['new-source-patch'], None)
        commit_receipts.append({**item, 'rawCommitSha256': sha(raw), 'patchSha256': sha(patch),
            'parentStorage': 'immutable-prior-checkpoint',
            'scope': 'Exact local commit and patch. Hosted tree equivalence is recorded separately in its original publication receipt.'})
    check(len({record['path'] for record in records}) == len(records), 'Duplicate logical evidence path')
    return {'createdAt': datetime.now(timezone.utc).isoformat(), 'prior': config['prior'],
        'files': records, 'excluded': excluded, 'newLocalSourceCommits': commit_receipts,
        'counts': {'selectedFiles': len(records), 'selectedBytesBeforeDeduplication': total,
            'priorReferencedFiles': sum(record['storage']['kind'] == 'prior-checkpoint' for record in records),
            'newUniqueObjects': len(objects), 'newUniqueBytes': sum(map(len, objects.values()))}}, objects


def add_member(archive, name, data):
    info = tarfile.TarInfo(name)
    info.size, info.mode, info.mtime = len(data), 0o644, 0
    info.uid = info.gid = 0
    archive.addfile(info, io.BytesIO(data))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['inventory', 'finalize'])
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--terminal-spec', type=Path)
    args = parser.parse_args()
    config_bytes = CONFIG.read_bytes()
    config = json.loads(config_bytes)
    check(not args.output.exists(), 'Never overwrite an inventory or checkpoint')
    root = Path(config['workspaceRoot']).resolve()
    terminal, extra, terminal_path = None, [], None
    if args.mode == 'finalize':
        check(args.terminal_spec is not None, 'Finalization requires a verified terminal specification')
        terminal_path = inside(root, args.terminal_spec.resolve())
        terminal, extra = terminal_evidence(root, config, terminal_path)
    inventory, objects = collect(config, extra)
    inventory.update({'schemaVersion': 1, 'configurationSha256': sha(config_bytes),
        'state': 'draft-inventory-no-archive' if terminal is None else 'terminal-evidence-snapshot',
        'chrome': terminal or {'state': 'pending', 'planSha256': config['chrome']['planSha256'],
            'scope': 'Reader/source preparation is not an acquisition or result.'}})
    if args.mode == 'inventory':
        args.output.write_bytes(encoded(inventory))
        print(json.dumps({'status': inventory['state'], 'path': str(args.output), 'sha256': sha(encoded(inventory)), **inventory['counts']}))
        return
    args.output.mkdir(parents=False)
    outcomes = json.loads((HERE / 'outcomes.json').read_bytes())
    outcomes['chrome'] = terminal
    outcomes['archiveState'] = 'terminal-evidence-snapshot-performance-qualification-separate'
    historical = (HERE / 'README.md').read_text()
    final_readme = ('# Final additive evidence checkpoint\n\n'
        + f"Terminal Chrome run: `{terminal['runId']}`; CI `{terminal['ciConclusion']}`; independent audit `{terminal['auditStatus']}`.\n\n"
        + terminal['summary'] + '\n\nNo product PR or current-develop qualification is asserted. All prior negative and inconclusive decisions remain intact.\n\n'
        + '## Historical preparation snapshot\n\n' + historical)
    controls = {'README.md': final_readme.encode(), 'outcomes.json': encoded(outcomes),
        'checkpoint-plan.json': config_bytes, 'terminal-spec.json': terminal_path.read_bytes(),
        'build_addendum.py': Path(__file__).read_bytes(), 'restore_addendum.py': (HERE / 'restore_addendum.py').read_bytes()}
    inventory['controls'] = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in controls.items()}
    manifest = encoded(inventory)
    payload = args.output / 'payload.tar.gz'
    with payload.open('xb') as output, gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted({**controls, 'manifest.json': manifest}.items()):
                add_member(archive, name, data)
            for digest, data in sorted(objects.items()):
                add_member(archive, 'objects/' + digest, data)
    expected = {name: sha(data) for name, data in {**controls, 'manifest.json': manifest}.items()}
    expected.update({'objects/' + digest: digest for digest in objects})
    with tarfile.open(payload, 'r:gz') as archive:
        seen = set()
        for member in archive:
            check(member.isfile() and member.name in expected and member.name not in seen, 'Unexpected archive member')
            seen.add(member.name)
            check(sha(archive.extractfile(member).read()) == expected[member.name], f'Archive member mismatch: {member.name}')
        check(seen == set(expected), 'Archive member set is incomplete')
    (args.output / 'manifest.json').write_bytes(manifest)
    (args.output / 'README.md').write_bytes(controls['README.md'])
    (args.output / 'outcomes.json').write_bytes(controls['outcomes.json'])
    receipt = {'schemaVersion': 1, 'status': 'verified-additive-evidence-checkpoint',
        'payloadBytes': payload.stat().st_size, 'payloadSha256': sha(payload.read_bytes()),
        'manifestSha256': sha(manifest), 'counts': inventory['counts'],
        'priorPayloadEmbedded': False, 'terminalChromeState': terminal,
        'sourceExperimentsExecuted': False, 'published': False, 'productPrQualified': False}
    (args.output / 'receipt.json').write_bytes(encoded(receipt))
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
