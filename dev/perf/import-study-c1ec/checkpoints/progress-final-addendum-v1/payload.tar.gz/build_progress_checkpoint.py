#!/usr/bin/env python3
"""Package completed evidence while the exact Chrome result is still pending.

This separate builder never calls or relaxes the terminal finalizer. It performs
file/Git reads, hashing, compression and archive verification only.
"""
import argparse
from datetime import datetime, timezone
import gzip
import json
from pathlib import Path
import sys
import tarfile

sys.dont_write_bytecode = True
import build_addendum as evidence

HERE = Path(__file__).resolve().parent


def progress_binding(config, spec):
    root = Path(config['workspaceRoot']).resolve()
    evidence.check(spec['state'] == 'progress-pending-chrome', 'Not a pending progress specification')
    evidence.check(spec['configurationSha256'] == evidence.sha(evidence.CONFIG.read_bytes()), 'Progress configuration changed')
    chrome = config['chrome']
    limit = config['bounds']['singleFileBytes']
    publication = evidence.receipt_json(root, spec['publicationReceipt'], limit)
    freeze = evidence.receipt_json(root, spec['readerFreeze'], limit)
    binding = evidence.receipt_json(root, spec['acquisitionBinding'], limit)
    for key, expected in [('publicationReceipt', chrome['publicationReceiptSha256']),
                          ('readerFreeze', chrome['readerFreezeSha256']),
                          ('acquisitionBinding', chrome['acquisitionBindingSha256'])]:
        evidence.check(spec[key]['sha256'] == expected, f'Unexpected {key}')
    evidence.check(publication['refVerified'] is True, 'Wrapper publication is not verified')
    evidence.check(publication['wrapperSha'] == publication['commit']['sha'] == binding['wrapperSha'] == chrome['wrapperCommit'],
                   'Unexpected wrapper commit')
    evidence.check(publication['wrapperTree'] == publication['commit']['tree']['sha'] == binding['wrapperTree'] == chrome['wrapperTree'],
                   'Unexpected wrapper tree')
    evidence.check([parent['sha'] for parent in publication['commit']['parents']] == [config['baseline']],
                   'Unexpected wrapper parent')
    evidence.check(binding['parentSha'] == config['baseline'], 'Binding parent differs')
    evidence.check(binding['runId'] == spec['runId'] == chrome['runId'] and
                   binding['jobId'] == spec['jobId'] == chrome['jobId'], 'Unexpected pending run or job')
    evidence.check(binding['publicationReceiptSha256'] == spec['publicationReceipt']['sha256'] and
                   binding['readerFreezeSha256'] == spec['readerFreeze']['sha256'], 'Acquisition receipt binding differs')
    evidence.check(freeze['readerSha256'] == chrome['readerSha256'] and
                   freeze['planSha256'] == binding['planSha256'] == chrome['planSha256'], 'Reader or plan differs')
    evidence.check(spec['terminalResultIncluded'] is False and spec['observationsIncluded'] == 0,
                   'Progress snapshot must not claim Chrome observations or completion')
    evidence.check(spec['productPrQualified'] is False, 'Progress snapshot cannot qualify a product PR')
    return {'state': 'pending-result-not-included', 'runId': chrome['runId'], 'jobId': chrome['jobId'],
        'wrapperCommit': chrome['wrapperCommit'], 'wrapperTree': chrome['wrapperTree'],
        'planSha256': chrome['planSha256'], 'readerSha256': chrome['readerSha256'],
        'statusAtImmutableBinding': binding['statusAtBinding'], 'bindingRecordedAt': binding['recordedAt'],
        'observationsIncluded': 0, 'terminalResultIncluded': False, 'productPrQualified': False,
        'scope': 'A preservation checkpoint of completed earlier evidence and frozen prospective inputs; no Chrome result is inferred.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--spec', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    evidence.check(not args.output.exists(), 'Never overwrite a progress checkpoint')
    config_bytes = evidence.CONFIG.read_bytes()
    config = json.loads(config_bytes)
    spec_bytes = args.spec.read_bytes()
    spec = json.loads(spec_bytes)
    chrome = progress_binding(config, spec)
    inventory, objects = evidence.collect(config, [])
    inventory.update({'schemaVersion': 1, 'configurationSha256': evidence.sha(config_bytes),
        'state': 'progress-evidence-snapshot-chrome-pending', 'chrome': chrome,
        'progressSpecificationSha256': evidence.sha(spec_bytes),
        'terminalFinalizerRelaxed': False, 'performanceQualificationClaimed': False})
    outcomes = json.loads((HERE / 'outcomes.json').read_bytes())
    outcomes['chrome'] = chrome
    outcomes['archiveState'] = 'verified-progress-checkpoint-terminal-Chrome-evidence-absent'
    readme = ('# Progress evidence checkpoint — Chrome result pending\n\n'
        + f"Created: {datetime.now(timezone.utc).isoformat()}.\n\n"
        + f"Pending acquisition: run `{chrome['runId']}`, job `{chrome['jobId']}`; wrapper `{chrome['wrapperCommit']}`. "
        + f"The immutable binding recorded `{chrome['statusAtImmutableBinding']}` at `{chrome['bindingRecordedAt']}`. "
        + 'This archive includes no result from that acquisition.\n\n'
        + 'Completed evidence includes the failed writer diagnostic and its metadata diagnosis, all 39 native-export children '
        + '(183 full passes) and their held/control-failed decision, exact SIMD prior art, group-burst source/correctness/reviews, '
        + 'and the frozen prospective Chrome plan, policy canary, reader and publication binding. No new benchmark or test was run to make this archive.\n\n'
        + 'No native gain, completed Chrome study, current-develop qualification or product PR is claimed. '
        + 'A later final addendum must pass the unchanged terminal-run finalizer.\n\n'
        + '## Dependency and restoration\n\n'
        + f"The prior immutable checkpoint is `{config['prior']['commit']}`, payload SHA-256 `{config['prior']['payloadSha256']}`. "
        + 'It is referenced for byte-identical members and is not embedded.\n\n'
        + 'Verify and restore using the supplied verifier and the externally recorded payload hash:\n\n'
        + '```sh\npython3 restore_addendum.py payload.tar.gz --expected-payload-sha256 PAYLOAD_SHA256 '
        + '--prior-payload PRIOR_PAYLOAD_TAR_GZ --output NEW_RESTORATION_DIRECTORY\n```\n\n'
        + 'Restoration creates regular evidence files only; it executes no source, tests or benchmarks. '
        + 'The detailed outcome and preparation narrative is retained in `preparation-README.md`.\n')
    controls = {'README.md': readme.encode(), 'outcomes.json': evidence.encoded(outcomes),
        'checkpoint-plan.json': config_bytes, 'progress-specification.json': spec_bytes,
        'build_progress_checkpoint.py': Path(__file__).read_bytes(),
        'build_addendum.py': evidence.CONFIG.with_name('build_addendum.py').read_bytes(),
        'restore_addendum.py': (HERE / 'restore_addendum.py').read_bytes(),
        'preparation-README.md': (HERE / 'README.md').read_bytes(),
        'terminal-spec.example.json': (HERE / 'terminal-spec.example.json').read_bytes(),
        'scaffold-revision.json': (HERE / 'scaffold-revision.json').read_bytes(),
        'preparation-checks.json': (HERE / 'preparation-checks.json').read_bytes(),
        'progress-preparation-checks.json': (HERE / 'progress-preparation-checks.json').read_bytes(),
        'inventory-draft-v1.json': (HERE / 'inventory-draft-v1.json').read_bytes(),
        'draft-v1-build_addendum.py': (HERE / 'draft-v1/build_addendum.py').read_bytes()}
    inventory['controls'] = {name: {'bytes': len(data), 'sha256': evidence.sha(data)} for name, data in controls.items()}
    evidence.screen_archive_controls(inventory, controls)
    manifest = evidence.encoded(inventory)
    args.output.mkdir(parents=False)
    payload = args.output / 'payload.tar.gz'
    all_members = {**controls, 'manifest.json': manifest,
                   **{'objects/' + digest: data for digest, data in objects.items()}}
    with payload.open('xb') as output, gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, data in sorted(all_members.items()):
                evidence.add_member(archive, name, data)
    with tarfile.open(payload, 'r:gz') as archive:
        seen = set()
        for member in archive:
            evidence.check(member.isfile() and member.name in all_members and member.name not in seen,
                           'Unexpected progress archive member')
            seen.add(member.name)
            evidence.check(archive.extractfile(member).read() == all_members[member.name], 'Progress archive bytes differ')
        evidence.check(seen == set(all_members), 'Progress archive member set is incomplete')
    for name in ['README.md', 'outcomes.json', 'restore_addendum.py']:
        (args.output / name).write_bytes(controls[name])
    (args.output / 'manifest.json').write_bytes(manifest)
    receipt = {'schemaVersion': 1, 'status': 'verified-progress-checkpoint-chrome-pending',
        'payloadBytes': payload.stat().st_size, 'payloadSha256': evidence.sha(payload.read_bytes()),
        'manifestSha256': evidence.sha(manifest), 'counts': inventory['counts'],
        'publicationPatternScreen': inventory['publicationPatternScreen'],
        'priorPayloadEmbedded': False, 'chrome': chrome, 'terminalFinalizerRelaxed': False,
        'sourceExperimentsExecuted': False, 'published': False, 'productPrQualified': False}
    (args.output / 'receipt.json').write_bytes(evidence.encoded(receipt))
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
