	.file	"term-bank-parser.c"
	.globaltype	__stack_pointer, i32
	.functype	memset (i32, i32, i32) -> (i32)
	.functype	memcpy (i32, i32, i32) -> (i32)
	.functype	inflate_and_join_term_banks (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	term_bank_inflate (i32, i32, i32, i32) -> (i32)
	.functype	crc32_bytes (i32, i32) -> (i32)
	.functype	inflate_zip_media_batch (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	verify_term_bank_source_crcs (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	crc32_update_gap (i32, i32, i32) -> (i32)
	.functype	wasm_reset_heap () -> ()
	.functype	wasm_alloc (i32) -> (i32)
	.functype	wasm_get_last_parse_capacity () -> (i32)
	.functype	wasm_get_last_content_capacity () -> (i32)
	.functype	parse_term_bank (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_term_bank_impl (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_term_bank_with_media_hints (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content (i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_impl (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_no_hash (i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_token_binary (i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_token_binary_row (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	build_term_string_plan (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	content_bytes_equal (i32, i32, i32, i32) -> (i32)
	.functype	decode_escaped_key (i32, i32, i32, i32) -> (i32)
	.functype	hash_content_xxh32 (i32, i32, i32) -> (i32)
	.functype	copy_valid_utf8 (i32, i32, i32) -> (i32)
	.functype	encode_term_lookup_index (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_token_binary_dedup (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_and_encode_term_bank_token_binary_dedup (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	next_term_bank (i32) -> (i32)
	.functype	parse_row_single_pass (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	scan_scalar_span (i32, i32, i32, i32) -> (i32)
	.functype	parse_int32_token (i32, i32, i32, i32, i32) -> (i32)
	.functype	raw_term_content_hash (i32, i32) -> (i32)
	.functype	raw_term_content_tokens_equal (i32, i32, i32, i32) -> (i32)
	.functype	raw_term_content_quick_signature (i32, i32) -> (i32)
	.functype	next_term_row (i32, i32) -> (i32)
	.functype	compact_term_lookup_keys (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	write_normalized_glossary_value (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	hash_content_xxh32_pair (i32, i32, i32, i32) -> ()
	.functype	parse_value_span (i32, i32, i32, i32) -> (i32)
	.functype	parse_scalar_span (i32, i32, i32, i32) -> (i32)
	.functype	parse_composite_span_impl (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	json_string_matches_ascii_escaped (i32, i32, i32, i32, i32) -> (i32)
	.functype	key_hex4 (i32) -> (i32)
	.functype	is_valid_json_number (i32, i32, i32) -> (i32)
	.functype	reuse_validated_glossary (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_value_span_with_glossary_hints (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	next_format3_field (i32, i32, i32) -> (i32)
	.section	.text.memset,"",@
	.hidden	memset                          # -- Begin function memset
	.globl	memset
	.type	memset,@function
memset:                                 # @memset
	.functype	memset (i32, i32, i32) -> (i32)
# %bb.0:
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label0
# %bb.1:
	local.get	0
	local.get	1
	local.get	2
	memory.fill	0
.LBB0_2:
	end_block                               # label0:
	local.get	0
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.memcpy,"",@
	.hidden	memcpy                          # -- Begin function memcpy
	.globl	memcpy
	.type	memcpy,@function
memcpy:                                 # @memcpy
	.functype	memcpy (i32, i32, i32) -> (i32)
# %bb.0:
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label1
# %bb.1:
	local.get	0
	local.get	1
	local.get	2
	memory.copy	0, 0
.LBB1_2:
	end_block                               # label1:
	local.get	0
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.inflate_and_join_term_banks,"",@
	.globl	inflate_and_join_term_banks     # -- Begin function inflate_and_join_term_banks
	.type	inflate_and_join_term_banks,@function
inflate_and_join_term_banks:            # @inflate_and_join_term_banks
	.functype	inflate_and_join_term_banks (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-1
	local.set	12
	block   	
	local.get	7
	i32.eqz
	br_if   	0                               # 0: down to label2
# %bb.1:
	local.get	9
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label2
# %bb.2:
	block   	
	local.get	10
	br_if   	0                               # 0: down to label3
# %bb.3:
	local.get	11
	br_if   	1                               # 1: down to label2
.LBB2_4:
	end_block                               # label3:
	block   	
	local.get	10
	br_if   	0                               # 0: down to label4
# %bb.5:
	local.get	8
	i32.const	91
	i32.store8	0
.LBB2_6:
	end_block                               # label4:
	local.get	10
	i32.eqz
	local.set	13
	local.get	8
	i32.const	1
	i32.add 
	local.set	14
	i32.const	0
	local.set	15
	i32.const	0
	local.set	16
.LBB2_7:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB2_21 Depth 2
                                        #     Child Loop BB2_28 Depth 2
                                        #     Child Loop BB2_38 Depth 2
                                        #     Child Loop BB2_43 Depth 2
	loop    	                                # label5:
	i32.const	-1
	local.set	12
	local.get	1
	local.get	2
	local.get	16
	i32.const	2
	i32.shl 
	local.tee	17
	i32.add 
	i32.load	0
	local.tee	18
	i32.lt_u
	br_if   	1                               # 1: down to label2
# %bb.8:                                #   in Loop: Header=BB2_7 Depth=1
	local.get	3
	local.get	17
	i32.add 
	i32.load	0
	local.tee	19
	local.get	1
	local.get	18
	i32.sub 
	i32.gt_u
	br_if   	1                               # 1: down to label2
# %bb.9:                                #   in Loop: Header=BB2_7 Depth=1
	local.get	4
	local.get	17
	i32.add 
	i32.load	0
	local.tee	20
	local.get	9
	local.get	13
	i32.sub 
	i32.gt_u
	br_if   	1                               # 1: down to label2
# %bb.10:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	8
	local.get	13
	i32.add 
	local.set	21
	i32.const	-1
	local.set	12
	block   	
	block   	
	block   	
	local.get	5
	local.get	17
	i32.add 
	i32.load	0
	br_table 	{0, 4, 4, 4, 4, 4, 4, 4, 1, 4} # 4: down to label2
                                        # 1: down to label7
.LBB2_11:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label8:
	block   	
	local.get	19
	local.get	20
	i32.eq  
	br_if   	0                               # 0: down to label9
# %bb.12:
	i32.const	-3
	return
.LBB2_13:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label9:
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label6
# %bb.14:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	21
	local.get	0
	local.get	18
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label6
.LBB2_15:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label7:
	local.get	0
	local.get	18
	i32.add 
	local.get	19
	local.get	21
	local.get	20
	call	term_bank_inflate
	local.tee	12
	br_if   	2                               # 2: down to label2
.LBB2_16:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label6:
	block   	
	local.get	11
	br_if   	0                               # 0: down to label10
# %bb.17:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	21
	local.get	20
	call	crc32_bytes
	local.get	6
	local.get	17
	i32.add 
	i32.load	0
	i32.eq  
	br_if   	0                               # 0: down to label10
# %bb.18:
	i32.const	-4
	return
.LBB2_19:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label10:
	local.get	20
	local.set	17
	local.get	20
	local.set	18
	block   	
	local.get	20
	i32.eqz
	br_if   	0                               # 0: down to label11
# %bb.20:                               #   in Loop: Header=BB2_7 Depth=1
	i32.const	0
	local.set	17
.LBB2_21:                               #   Parent Loop BB2_7 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label13:
	local.get	21
	local.get	17
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label12
# %bb.22:                               #   in Loop: Header=BB2_21 Depth=2
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label12
# %bb.23:                               #   in Loop: Header=BB2_21 Depth=2
	local.get	20
	local.get	17
	i32.const	1
	i32.add 
	local.tee	17
	i32.ne  
	br_if   	0                               # 0: up to label13
# %bb.24:                               #   in Loop: Header=BB2_7 Depth=1
	end_loop
	local.get	20
	local.set	17
	local.get	20
	local.set	18
	br      	1                               # 1: down to label11
.LBB2_25:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label12:
	block   	
	local.get	20
	local.get	17
	i32.gt_u
	br_if   	0                               # 0: down to label14
# %bb.26:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	20
	local.set	18
	br      	1                               # 1: down to label11
.LBB2_27:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label14:
	local.get	21
	i32.const	-1
	i32.add 
	local.set	19
	local.get	20
	local.set	18
.LBB2_28:                               #   Parent Loop BB2_7 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label15:
	local.get	19
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	12
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label11
# %bb.29:                               #   in Loop: Header=BB2_28 Depth=2
	i32.const	1
	local.get	12
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label11
# %bb.30:                               #   in Loop: Header=BB2_28 Depth=2
	local.get	18
	i32.const	-1
	i32.add 
	local.tee	18
	local.get	17
	i32.gt_u
	br_if   	0                               # 0: up to label15
# %bb.31:                               #   in Loop: Header=BB2_7 Depth=1
	end_loop
	local.get	17
	local.set	18
.LBB2_32:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label11:
	i32.const	-5
	local.set	12
	local.get	18
	local.get	17
	i32.sub 
	i32.const	2
	i32.lt_u
	br_if   	1                               # 1: down to label2
# %bb.33:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	21
	local.get	17
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	1                               # 1: down to label2
# %bb.34:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	21
	local.get	18
	i32.add 
	i32.const	-1
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	1                               # 1: down to label2
# %bb.35:                               #   in Loop: Header=BB2_7 Depth=1
	block   	
	local.get	10
	br_if   	0                               # 0: down to label16
# %bb.36:                               #   in Loop: Header=BB2_7 Depth=1
	block   	
	block   	
	local.get	17
	i32.const	1
	i32.add 
	local.tee	12
	local.get	18
	i32.const	-1
	i32.add 
	local.tee	20
	i32.ge_u
	br_if   	0                               # 0: down to label18
# %bb.37:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	14
	local.get	13
	i32.add 
	local.set	12
	local.get	18
	i32.const	-2
	i32.add 
	local.set	19
.LBB2_38:                               #   Parent Loop BB2_7 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label20:
	local.get	12
	local.get	17
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label19
# %bb.39:                               #   in Loop: Header=BB2_38 Depth=2
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label19
# %bb.40:                               #   in Loop: Header=BB2_38 Depth=2
	local.get	19
	local.get	17
	i32.const	1
	i32.add 
	local.tee	17
	i32.eq  
	br_if   	3                               # 3: down to label17
	br      	0                               # 0: up to label20
.LBB2_41:                               #   in Loop: Header=BB2_7 Depth=1
	end_loop
	end_block                               # label19:
	local.get	17
	i32.const	1
	i32.add 
	local.set	12
.LBB2_42:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label18:
	block   	
	local.get	20
	local.get	12
	i32.le_u
	br_if   	0                               # 0: down to label21
.LBB2_43:                               #   Parent Loop BB2_7 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label22:
	local.get	21
	local.get	20
	i32.add 
	i32.const	-1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	17
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label21
# %bb.44:                               #   in Loop: Header=BB2_43 Depth=2
	i32.const	1
	local.get	17
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label21
# %bb.45:                               #   in Loop: Header=BB2_43 Depth=2
	local.get	20
	i32.const	-1
	i32.add 
	local.tee	20
	local.get	12
	i32.gt_u
	br_if   	0                               # 0: up to label22
	br      	2                               # 2: down to label17
.LBB2_46:                               #   in Loop: Header=BB2_7 Depth=1
	end_loop
	end_block                               # label21:
	local.get	20
	local.get	12
	i32.eq  
	br_if   	0                               # 0: down to label17
# %bb.47:                               #   in Loop: Header=BB2_7 Depth=1
	block   	
	local.get	15
	i32.eqz
	br_if   	0                               # 0: down to label23
# %bb.48:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	21
	i32.const	44
	i32.store8	0
	local.get	13
	i32.const	1
	i32.add 
	local.set	13
.LBB2_49:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label23:
	local.get	20
	local.get	12
	i32.sub 
	local.set	17
	block   	
	local.get	8
	local.get	13
	i32.add 
	local.tee	18
	local.get	21
	local.get	12
	i32.add 
	local.tee	20
	i32.eq  
	br_if   	0                               # 0: down to label24
# %bb.50:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	17
	i32.eqz
	br_if   	0                               # 0: down to label24
# %bb.51:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	18
	local.get	20
	local.get	17
	memory.copy	0, 0
.LBB2_52:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label24:
	local.get	15
	i32.const	1
	i32.add 
	local.set	15
	local.get	13
	local.get	17
	i32.add 
	local.set	13
.LBB2_53:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label17:
	local.get	16
	i32.const	1
	i32.add 
	local.tee	16
	local.get	7
	i32.ne  
	br_if   	1                               # 1: up to label5
# %bb.54:
	i32.const	-1
	local.set	12
	local.get	13
	local.get	9
	i32.ge_u
	br_if   	2                               # 2: down to label2
# %bb.55:
	local.get	8
	local.get	13
	i32.add 
	i32.const	93
	i32.store8	0
	local.get	13
	i32.const	1
	i32.add 
	local.set	12
	br      	2                               # 2: down to label2
.LBB2_56:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label16:
	local.get	10
	local.get	16
	i32.const	3
	i32.shl 
	i32.add 
	local.tee	17
	local.get	20
	i32.store	4
	local.get	17
	local.get	13
	i32.store	0
	local.get	20
	local.get	13
	i32.add 
	local.tee	13
	local.set	12
	local.get	16
	i32.const	1
	i32.add 
	local.tee	16
	local.get	7
	i32.ne  
	br_if   	0                               # 0: up to label5
.LBB2_57:
	end_loop
	end_block                               # label2:
	local.get	12
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.crc32_bytes,"",@
	.type	crc32_bytes,@function           # -- Begin function crc32_bytes
crc32_bytes:                            # @crc32_bytes
	.functype	crc32_bytes (i32, i32) -> (i32)
	.local  	v128, i32, v128, v128, v128, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64
# %bb.0:
	block   	
	i32.const	0
	i32.load8_u	crc32_table_initialized
	br_if   	0                               # 0: down to label25
# %bb.1:
	v128.const	0, 1, 2, 3
	local.set	2
	i32.const	-1024
	local.set	3
.LBB3_2:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label26:
	local.get	3
	i32.const	crc32_table+1024
	i32.add 
	local.get	2
	v128.const	2, 2, 2, 2
	v128.and
	v128.const	0, 0, 0, 0
	local.tee	4
	i32x4.ne
	v128.const	-306674912, -306674912, -306674912, -306674912
	local.tee	5
	v128.and
	local.get	2
	v128.const	1, 1, 1, 1
	v128.and
	local.get	4
	i32x4.ne
	local.get	5
	v128.and
	local.get	2
	i32.const	1
	i32x4.shr_u
	v128.xor
	local.tee	6
	i32.const	1
	i32x4.shr_u
	v128.xor
	local.tee	7
	v128.const	32, 32, 32, 32
	local.tee	8
	v128.and
	local.get	4
	i32x4.ne
	local.get	5
	v128.and
	local.get	6
	local.get	8
	v128.and
	local.get	4
	i32x4.ne
	v128.const	1994146192, 1994146192, 1994146192, 1994146192
	v128.and
	local.get	2
	local.get	8
	v128.and
	local.get	4
	i32x4.ne
	v128.const	997073096, 997073096, 997073096, 997073096
	v128.and
	local.get	2
	v128.const	16, 16, 16, 16
	v128.and
	local.get	4
	i32x4.ne
	v128.const	498536548, 498536548, 498536548, 498536548
	v128.and
	local.get	2
	v128.const	8, 8, 8, 8
	v128.and
	local.get	4
	i32x4.ne
	v128.const	249268274, 249268274, 249268274, 249268274
	v128.and
	local.get	2
	v128.const	4, 4, 4, 4
	local.tee	5
	v128.and
	local.get	4
	i32x4.ne
	v128.const	124634137, 124634137, 124634137, 124634137
	v128.and
	local.get	7
	i32.const	6
	i32x4.shr_u
	v128.xor
	v128.xor
	v128.xor
	v128.xor
	v128.xor
	v128.xor
	v128.store	0
	local.get	2
	local.get	5
	i32x4.add
	local.set	2
	local.get	3
	i32.const	16
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label26
# %bb.3:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_4:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label27:
	local.get	3
	i32.const	crc32_table+2048
	i32.add 
	local.get	3
	i32.const	crc32_table+1024
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+2052
	i32.add 
	local.get	3
	i32.const	crc32_table+1028
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label27
# %bb.5:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_6:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label28:
	local.get	3
	i32.const	crc32_table+3072
	i32.add 
	local.get	3
	i32.const	crc32_table+2048
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+3076
	i32.add 
	local.get	3
	i32.const	crc32_table+2052
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label28
# %bb.7:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_8:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label29:
	local.get	3
	i32.const	crc32_table+4096
	i32.add 
	local.get	3
	i32.const	crc32_table+3072
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+4100
	i32.add 
	local.get	3
	i32.const	crc32_table+3076
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label29
# %bb.9:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_10:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label30:
	local.get	3
	i32.const	crc32_table+5120
	i32.add 
	local.get	3
	i32.const	crc32_table+4096
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+5124
	i32.add 
	local.get	3
	i32.const	crc32_table+4100
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label30
# %bb.11:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_12:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label31:
	local.get	3
	i32.const	crc32_table+6144
	i32.add 
	local.get	3
	i32.const	crc32_table+5120
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+6148
	i32.add 
	local.get	3
	i32.const	crc32_table+5124
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label31
# %bb.13:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_14:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label32:
	local.get	3
	i32.const	crc32_table+7168
	i32.add 
	local.get	3
	i32.const	crc32_table+6144
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+7172
	i32.add 
	local.get	3
	i32.const	crc32_table+6148
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label32
# %bb.15:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_16:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label33:
	local.get	3
	i32.const	crc32_table+8192
	i32.add 
	local.get	3
	i32.const	crc32_table+7168
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+8196
	i32.add 
	local.get	3
	i32.const	crc32_table+7172
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label33
# %bb.17:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_18:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label34:
	local.get	3
	i32.const	crc32_table+9216
	i32.add 
	local.get	3
	i32.const	crc32_table+8192
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+9220
	i32.add 
	local.get	3
	i32.const	crc32_table+8196
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label34
# %bb.19:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_20:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label35:
	local.get	3
	i32.const	crc32_table+10240
	i32.add 
	local.get	3
	i32.const	crc32_table+9216
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+10244
	i32.add 
	local.get	3
	i32.const	crc32_table+9220
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label35
# %bb.21:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_22:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label36:
	local.get	3
	i32.const	crc32_table+11264
	i32.add 
	local.get	3
	i32.const	crc32_table+10240
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+11268
	i32.add 
	local.get	3
	i32.const	crc32_table+10244
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label36
# %bb.23:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_24:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label37:
	local.get	3
	i32.const	crc32_table+12288
	i32.add 
	local.get	3
	i32.const	crc32_table+11264
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+12292
	i32.add 
	local.get	3
	i32.const	crc32_table+11268
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label37
# %bb.25:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_26:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label38:
	local.get	3
	i32.const	crc32_table+13312
	i32.add 
	local.get	3
	i32.const	crc32_table+12288
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+13316
	i32.add 
	local.get	3
	i32.const	crc32_table+12292
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label38
# %bb.27:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_28:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label39:
	local.get	3
	i32.const	crc32_table+14336
	i32.add 
	local.get	3
	i32.const	crc32_table+13312
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+14340
	i32.add 
	local.get	3
	i32.const	crc32_table+13316
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label39
# %bb.29:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_30:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label40:
	local.get	3
	i32.const	crc32_table+15360
	i32.add 
	local.get	3
	i32.const	crc32_table+14336
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+15364
	i32.add 
	local.get	3
	i32.const	crc32_table+14340
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label40
# %bb.31:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_32:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label41:
	local.get	3
	i32.const	crc32_table+16384
	i32.add 
	local.get	3
	i32.const	crc32_table+15360
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+16388
	i32.add 
	local.get	3
	i32.const	crc32_table+15364
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label41
# %bb.33:
	end_loop
	i32.const	0
	i32.const	1
	i32.store8	crc32_table_initialized
.LBB3_34:
	end_block                               # label25:
	block   	
	block   	
	block   	
	block   	
	local.get	1
	i32.const	262143
	i32.gt_u
	br_if   	0                               # 0: down to label45
# %bb.35:
	block   	
	local.get	1
	i32.const	16
	i32.ge_u
	br_if   	0                               # 0: down to label46
# %bb.36:
	i32.const	0
	local.set	9
	i32.const	-1
	local.set	3
	br      	3                               # 3: down to label43
.LBB3_37:
	end_block                               # label46:
	i32.const	-1
	local.set	3
	local.get	1
	local.set	10
	local.get	0
	local.set	9
.LBB3_38:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label47:
	local.get	9
	i32.load	0:p2align=0
	local.get	3
	i32.xor 
	local.tee	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+14336
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+15360
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+13312
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+12288
	i32.xor 
	local.get	9
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+11264
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+10240
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+9216
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+8192
	i32.xor 
	local.get	9
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	9
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.set	3
	local.get	9
	i32.const	16
	i32.add 
	local.set	9
	local.get	10
	i32.const	-16
	i32.add 
	local.tee	10
	i32.const	15
	i32.gt_u
	br_if   	0                               # 0: up to label47
	br      	2                               # 2: down to label44
.LBB3_39:
	end_loop
	end_block                               # label45:
	i32.const	0
	local.set	10
	block   	
	i32.const	0
	i32.load8_u	crc32_braid_initialized
	br_if   	0                               # 0: down to label48
# %bb.40:
.LBB3_41:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_42 Depth 2
	loop    	                                # label49:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table
	local.set	3
	i32.const	56
	local.set	9
.LBB3_42:                               #   Parent Loop BB3_41 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label50:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label50
# %bb.43:                               #   in Loop: Header=BB3_41 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label49
# %bb.44:
	end_loop
	i32.const	0
	local.set	10
.LBB3_45:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_46 Depth 2
	loop    	                                # label51:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+1024
	local.set	3
	i32.const	56
	local.set	9
.LBB3_46:                               #   Parent Loop BB3_45 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label52:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label52
# %bb.47:                               #   in Loop: Header=BB3_45 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+1024
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label51
# %bb.48:
	end_loop
	i32.const	0
	local.set	10
.LBB3_49:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_50 Depth 2
	loop    	                                # label53:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+2048
	local.set	3
	i32.const	56
	local.set	9
.LBB3_50:                               #   Parent Loop BB3_49 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label54:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label54
# %bb.51:                               #   in Loop: Header=BB3_49 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+2048
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label53
# %bb.52:
	end_loop
	i32.const	0
	local.set	10
.LBB3_53:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_54 Depth 2
	loop    	                                # label55:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+3072
	local.set	3
	i32.const	56
	local.set	9
.LBB3_54:                               #   Parent Loop BB3_53 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label56:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label56
# %bb.55:                               #   in Loop: Header=BB3_53 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+3072
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label55
# %bb.56:
	end_loop
	i32.const	0
	local.set	10
.LBB3_57:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_58 Depth 2
	loop    	                                # label57:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+4096
	local.set	3
	i32.const	56
	local.set	9
.LBB3_58:                               #   Parent Loop BB3_57 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label58:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label58
# %bb.59:                               #   in Loop: Header=BB3_57 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+4096
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label57
# %bb.60:
	end_loop
	i32.const	0
	local.set	10
.LBB3_61:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_62 Depth 2
	loop    	                                # label59:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+5120
	local.set	3
	i32.const	56
	local.set	9
.LBB3_62:                               #   Parent Loop BB3_61 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label60:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label60
# %bb.63:                               #   in Loop: Header=BB3_61 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+5120
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label59
# %bb.64:
	end_loop
	i32.const	0
	local.set	10
.LBB3_65:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_66 Depth 2
	loop    	                                # label61:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+6144
	local.set	3
	i32.const	56
	local.set	9
.LBB3_66:                               #   Parent Loop BB3_65 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label62:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label62
# %bb.67:                               #   in Loop: Header=BB3_65 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+6144
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label61
# %bb.68:
	end_loop
	i32.const	0
	local.set	10
.LBB3_69:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_70 Depth 2
	loop    	                                # label63:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+7168
	local.set	3
	i32.const	56
	local.set	9
.LBB3_70:                               #   Parent Loop BB3_69 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label64:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label64
# %bb.71:                               #   in Loop: Header=BB3_69 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+7168
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label63
# %bb.72:
	end_loop
	i32.const	0
	i32.const	1
	i32.store8	crc32_braid_initialized
.LBB3_73:
	end_block                               # label48:
	local.get	1
	i32.const	-64
	i32.and 
	local.tee	12
	i32.const	-64
	i32.add 
	local.set	13
	i32.const	-1
	local.set	11
	i32.const	0
	local.set	14
	i32.const	0
	local.set	15
	i32.const	0
	local.set	16
	i32.const	0
	local.set	17
	i32.const	0
	local.set	18
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
	i32.const	0
	local.set	10
.LBB3_74:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label65:
	local.get	11
	local.get	0
	local.get	10
	i32.add 
	local.tee	3
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	11
	local.get	14
	local.get	3
	i32.const	56
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	14
	local.get	15
	local.get	3
	i32.const	48
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	15
	local.get	16
	local.get	3
	i32.const	40
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	16
	local.get	17
	local.get	3
	i32.const	32
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	17
	local.get	18
	local.get	3
	i32.const	24
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	18
	local.get	19
	local.get	3
	i32.const	16
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	19
	local.get	20
	local.get	3
	i32.const	8
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	20
	local.get	10
	i32.const	64
	i32.add 
	local.tee	10
	local.get	13
	i32.lt_u
	br_if   	0                               # 0: up to label65
# %bb.75:
	end_loop
	local.get	11
	local.get	0
	local.get	13
	i32.add 
	local.tee	3
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	8:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	20
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	16:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	19
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	24:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	18
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	32:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	17
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	40:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	16
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	48:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	15
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	56:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	14
	i32.xor 
	local.tee	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.set	3
	local.get	12
	local.get	1
	i32.eq  
	br_if   	2                               # 2: down to label42
# %bb.76:
.LBB3_77:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label66:
	local.get	0
	local.get	12
	i32.add 
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	12
	i32.const	1
	i32.add 
	local.tee	12
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: up to label66
	br      	3                               # 3: down to label42
.LBB3_78:
	end_loop
	end_block                               # label44:
	local.get	1
	i32.const	262128
	i32.and 
	local.set	9
.LBB3_79:
	end_block                               # label43:
	local.get	9
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label42
# %bb.80:
	local.get	9
	i32.const	1
	i32.or  
	local.set	10
	block   	
	local.get	1
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label67
# %bb.81:
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	10
	local.set	9
.LBB3_82:
	end_block                               # label67:
	local.get	1
	local.get	10
	i32.eq  
	br_if   	0                               # 0: down to label42
# %bb.83:
	local.get	1
	local.get	9
	i32.sub 
	local.set	10
	local.get	0
	local.get	9
	i32.add 
	local.set	9
.LBB3_84:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label68:
	local.get	9
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.get	9
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	2
	i32.add 
	local.set	9
	local.get	10
	i32.const	-2
	i32.add 
	local.tee	10
	br_if   	0                               # 0: up to label68
.LBB3_85:
	end_loop
	end_block                               # label42:
	local.get	3
	i32.const	-1
	i32.xor 
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.inflate_zip_media_batch,"",@
	.globl	inflate_zip_media_batch         # -- Begin function inflate_zip_media_batch
	.type	inflate_zip_media_batch,@function
inflate_zip_media_batch:                # @inflate_zip_media_batch
	.functype	inflate_zip_media_batch (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	block   	
	local.get	7
	br_if   	0                               # 0: down to label69
# %bb.1:
	i32.const	-1
	return
.LBB4_2:
	end_block                               # label69:
	i32.const	0
	local.set	11
	local.get	10
	local.set	12
.LBB4_3:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label70:
	block   	
	local.get	1
	local.get	2
	i32.load	0
	local.tee	13
	i32.ge_u
	br_if   	0                               # 0: down to label71
# %bb.4:
	i32.const	-1
	return
.LBB4_5:                                #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label71:
	block   	
	local.get	3
	i32.load	0
	local.tee	14
	local.get	1
	local.get	13
	i32.sub 
	i32.le_u
	br_if   	0                               # 0: down to label72
# %bb.6:
	i32.const	-1
	return
.LBB4_7:                                #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label72:
	block   	
	local.get	4
	i32.load	0
	local.tee	15
	local.get	11
	i32.const	2147483647
	i32.xor 
	i32.le_u
	br_if   	0                               # 0: down to label73
# %bb.8:
	i32.const	-1
	return
.LBB4_9:                                #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label73:
	block   	
	block   	
	local.get	10
	br_if   	0                               # 0: down to label75
# %bb.10:                               #   in Loop: Header=BB4_3 Depth=1
	i32.const	0
	local.set	16
	br      	1                               # 1: down to label74
.LBB4_11:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label75:
	block   	
	local.get	9
	local.get	11
	i32.ge_u
	br_if   	0                               # 0: down to label76
# %bb.12:
	i32.const	-1
	return
.LBB4_13:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label76:
	block   	
	local.get	15
	local.get	9
	local.get	11
	i32.sub 
	i32.le_u
	br_if   	0                               # 0: down to label77
# %bb.14:
	i32.const	-1
	return
.LBB4_15:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label77:
	local.get	12
	local.get	11
	i32.store	0
	local.get	11
	local.set	16
.LBB4_16:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label74:
	local.get	0
	local.get	13
	i32.add 
	local.set	17
	local.get	8
	local.get	16
	i32.add 
	local.set	13
	i32.const	-1
	local.set	16
	block   	
	block   	
	block   	
	block   	
	local.get	5
	i32.load	0
	br_table 	{0, 3, 3, 3, 3, 3, 3, 3, 1, 3} # 3: down to label78
                                        # 1: down to label80
.LBB4_17:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label81:
	block   	
	local.get	14
	local.get	15
	i32.eq  
	br_if   	0                               # 0: down to label82
# %bb.18:
	i32.const	-3
	return
.LBB4_19:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label82:
	block   	
	local.get	10
	br_if   	0                               # 0: down to label83
# %bb.20:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	17
	local.set	13
	br      	2                               # 2: down to label79
.LBB4_21:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label83:
	local.get	14
	i32.eqz
	br_if   	1                               # 1: down to label79
# %bb.22:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	13
	local.get	17
	local.get	14
	memory.copy	0, 0
	br      	1                               # 1: down to label79
.LBB4_23:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label80:
	block   	
	local.get	10
	br_if   	0                               # 0: down to label84
# %bb.24:                               #   in Loop: Header=BB4_3 Depth=1
	block   	
	local.get	14
	i32.const	5
	i32.lt_u
	br_if   	0                               # 0: down to label85
# %bb.25:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	14
	i32.const	-5
	i32.add 
	local.get	15
	i32.ne  
	br_if   	0                               # 0: down to label85
# %bb.26:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	15
	i32.const	65535
	i32.gt_u
	br_if   	0                               # 0: down to label85
# %bb.27:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	17
	i32.load8_u	0
	i32.const	7
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label85
# %bb.28:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	17
	i32.load16_u	1:p2align=0
	local.get	15
	i32.ne  
	br_if   	0                               # 0: down to label85
# %bb.29:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	17
	i32.load16_u	3:p2align=0
	local.get	15
	i32.xor 
	i32.const	65535
	i32.ne  
	br_if   	0                               # 0: down to label85
# %bb.30:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	17
	i32.const	5
	i32.add 
	local.set	13
	br      	2                               # 2: down to label79
.LBB4_31:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label85:
	local.get	15
	local.get	9
	i32.le_u
	br_if   	0                               # 0: down to label84
# %bb.32:
	i32.const	-1
	return
.LBB4_33:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label84:
	local.get	17
	local.get	14
	local.get	13
	local.get	15
	call	term_bank_inflate
	local.tee	16
	br_if   	1                               # 1: down to label78
.LBB4_34:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label79:
	block   	
	local.get	13
	local.get	15
	call	crc32_bytes
	local.get	6
	i32.load	0
	i32.eq  
	br_if   	0                               # 0: down to label86
# %bb.35:
	i32.const	-4
	return
.LBB4_36:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label86:
	local.get	2
	i32.const	4
	i32.add 
	local.set	2
	local.get	3
	i32.const	4
	i32.add 
	local.set	3
	local.get	4
	i32.const	4
	i32.add 
	local.set	4
	local.get	12
	i32.const	4
	i32.add 
	local.set	12
	local.get	5
	i32.const	4
	i32.add 
	local.set	5
	local.get	6
	i32.const	4
	i32.add 
	local.set	6
	local.get	15
	local.get	11
	i32.add 
	local.tee	11
	local.set	16
	local.get	7
	i32.const	-1
	i32.add 
	local.tee	7
	br_if   	1                               # 1: up to label70
.LBB4_37:
	end_block                               # label78:
	end_loop
	local.get	16
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.verify_term_bank_source_crcs,"",@
	.globl	verify_term_bank_source_crcs    # -- Begin function verify_term_bank_source_crcs
	.type	verify_term_bank_source_crcs,@function
verify_term_bank_source_crcs:           # @verify_term_bank_source_crcs
	.functype	verify_term_bank_source_crcs (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	528
	i32.sub 
	local.tee	9
	global.set	__stack_pointer
	i32.const	-1
	local.set	10
	block   	
	local.get	0
	i32.eqz
	br_if   	0                               # 0: down to label87
# %bb.1:
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label87
# %bb.2:
	local.get	3
	i32.eqz
	br_if   	0                               # 0: down to label87
# %bb.3:
	local.get	4
	i32.eqz
	br_if   	0                               # 0: down to label87
# %bb.4:
	block   	
	block   	
	block   	
	block   	
	local.get	6
	i32.eqz
	br_if   	0                               # 0: down to label91
# %bb.5:
	local.get	5
	i32.eqz
	br_if   	4                               # 4: down to label87
# %bb.6:
	local.get	7
	i32.eqz
	br_if   	4                               # 4: down to label87
# %bb.7:
	i32.const	-1
	local.set	10
	local.get	9
	i32.const	-1
	i32.store	12
	local.get	0
	i32.const	0
	call	crc32_bytes
	drop
	local.get	9
	i32.const	464
	i32.add 
	local.set	11
	local.get	9
	i32.const	400
	i32.add 
	local.set	12
	local.get	9
	i32.const	336
	i32.add 
	local.set	13
	local.get	9
	i32.const	272
	i32.add 
	local.set	14
	local.get	9
	i32.const	208
	i32.add 
	local.set	15
	local.get	9
	i32.const	144
	i32.add 
	local.set	16
	local.get	9
	i32.const	12
	i32.add 
	i32.const	68
	i32.add 
	local.set	17
	local.get	9
	i32.const	16
	i32.add 
	local.set	18
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
	i32.const	0
	local.set	21
	i32.const	0
	local.set	22
	i32.const	0
	local.set	23
	i32.const	-1
	local.set	24
	br      	1                               # 1: down to label90
.LBB5_8:
	end_block                               # label91:
	i32.const	-1
	local.set	10
	local.get	9
	i32.const	-1
	i32.store	12
	i32.const	0
	local.set	25
	local.get	0
	i32.const	0
	call	crc32_bytes
	drop
.LBB5_9:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label92:
	local.get	2
	i32.load	0
	local.tee	20
	local.get	25
	i32.ne  
	br_if   	4                               # 4: down to label87
# %bb.10:                               #   in Loop: Header=BB5_9 Depth=1
	local.get	1
	local.get	20
	i32.lt_u
	br_if   	4                               # 4: down to label87
# %bb.11:                               #   in Loop: Header=BB5_9 Depth=1
	local.get	2
	i32.const	4
	i32.add 
	i32.load	0
	local.tee	26
	local.get	1
	local.get	20
	i32.sub 
	i32.gt_u
	br_if   	4                               # 4: down to label87
# %bb.12:                               #   in Loop: Header=BB5_9 Depth=1
	local.get	0
	local.get	25
	i32.add 
	local.get	26
	call	crc32_bytes
	local.get	4
	i32.load	0
	i32.ne  
	br_if   	2                               # 2: down to label89
# %bb.13:                               #   in Loop: Header=BB5_9 Depth=1
	local.get	2
	i32.const	8
	i32.add 
	local.set	2
	local.get	4
	i32.const	4
	i32.add 
	local.set	4
	local.get	26
	local.get	25
	i32.add 
	local.set	25
	local.get	3
	i32.const	-1
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label92
# %bb.14:
	end_loop
	i32.const	0
	local.set	22
	i32.const	0
	local.set	21
	i32.const	0
	local.set	19
	br      	2                               # 2: down to label88
.LBB5_15:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB5_20 Depth 2
                                        #       Child Loop BB5_31 Depth 3
                                        #         Child Loop BB5_34 Depth 4
                                        #         Child Loop BB5_36 Depth 4
	end_block                               # label90:
	loop    	                                # label93:
	local.get	2
	local.get	23
	i32.const	3
	i32.shl 
	i32.add 
	local.tee	27
	i32.load	0
	local.tee	26
	local.get	20
	i32.ne  
	br_if   	3                               # 3: down to label87
# %bb.16:                               #   in Loop: Header=BB5_15 Depth=1
	local.get	1
	local.get	26
	i32.lt_u
	br_if   	3                               # 3: down to label87
# %bb.17:                               #   in Loop: Header=BB5_15 Depth=1
	local.get	27
	i32.load	4
	local.tee	27
	local.get	1
	local.get	26
	i32.sub 
	i32.gt_u
	br_if   	3                               # 3: down to label87
# %bb.18:                               #   in Loop: Header=BB5_15 Depth=1
	local.get	27
	local.get	20
	i32.add 
	local.set	25
	i32.const	0
	local.set	26
	block   	
	local.get	19
	local.get	6
	i32.ge_u
	br_if   	0                               # 0: down to label94
# %bb.19:                               #   in Loop: Header=BB5_15 Depth=1
	i32.const	0
	local.set	26
.LBB5_20:                               #   Parent Loop BB5_15 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB5_31 Depth 3
                                        #         Child Loop BB5_34 Depth 4
                                        #         Child Loop BB5_36 Depth 4
	loop    	                                # label95:
	local.get	25
	local.get	5
	local.get	19
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	27
	i32.load	36
	local.tee	28
	i32.le_u
	br_if   	1                               # 1: down to label94
# %bb.21:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	28
	local.get	20
	i32.lt_u
	br_if   	5                               # 5: down to label87
# %bb.22:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	27
	i32.load	40
	local.tee	29
	i32.eqz
	br_if   	5                               # 5: down to label87
# %bb.23:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	29
	local.get	25
	local.get	28
	i32.sub 
	i32.gt_u
	br_if   	5                               # 5: down to label87
# %bb.24:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	26
	local.get	0
	local.get	20
	i32.add 
	local.get	28
	local.get	20
	i32.sub 
	call	crc32_update_gap
	local.set	30
	block   	
	block   	
	local.get	7
	local.get	19
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	26
	i32.load	0
	local.tee	20
	i32.const	-1
	i32.ne  
	br_if   	0                               # 0: down to label97
# %bb.25:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	0
	local.get	28
	i32.add 
	local.get	29
	call	crc32_bytes
	local.set	31
	br      	1                               # 1: down to label96
.LBB5_26:                               #   in Loop: Header=BB5_20 Depth=2
	end_block                               # label97:
	local.get	20
	local.get	19
	i32.ge_u
	br_if   	6                               # 6: down to label87
# %bb.27:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	5
	local.get	20
	i32.const	68
	i32.mul 
	i32.add 
	i32.load	40
	local.get	29
	i32.ne  
	br_if   	6                               # 6: down to label87
# %bb.28:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	22
	i32.const	1
	i32.add 
	local.set	22
	local.get	29
	local.get	21
	i32.add 
	local.set	21
	local.get	7
	local.get	20
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.set	31
.LBB5_29:                               #   in Loop: Header=BB5_20 Depth=2
	end_block                               # label96:
	local.get	26
	local.get	31
	i32.store	0
	block   	
	local.get	24
	local.get	29
	i32.eq  
	br_if   	0                               # 0: down to label98
# %bb.30:                               #   in Loop: Header=BB5_20 Depth=2
	i32.const	-2147483648
	local.set	24
	i32.const	8388608
	local.set	27
	local.get	29
	local.set	32
.LBB5_31:                               #   Parent Loop BB5_15 Depth=1
                                        #     Parent Loop BB5_20 Depth=2
                                        # =>    This Loop Header: Depth=3
                                        #         Child Loop BB5_34 Depth 4
                                        #         Child Loop BB5_36 Depth 4
	loop    	                                # label99:
	block   	
	block   	
	local.get	32
	i32.const	1
	i32.and 
	br_if   	0                               # 0: down to label101
# %bb.32:                               #   in Loop: Header=BB5_31 Depth=3
	local.get	24
	local.set	33
	br      	1                               # 1: down to label100
.LBB5_33:                               #   in Loop: Header=BB5_31 Depth=3
	end_block                               # label101:
	i32.const	0
	local.set	33
	i32.const	-2147483648
	local.set	20
	local.get	27
	local.set	26
.LBB5_34:                               #   Parent Loop BB5_15 Depth=1
                                        #     Parent Loop BB5_20 Depth=2
                                        #       Parent Loop BB5_31 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	loop    	                                # label102:
	i32.const	0
	local.get	26
	i32.const	1
	i32.and 
	i32.sub 
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.const	0
	local.get	20
	i32.const	1
	i32.shr_u
	local.get	24
	i32.and 
	i32.select
	local.get	26
	i32.const	0
	local.get	20
	local.get	24
	i32.and 
	i32.select
	local.get	33
	i32.xor 
	i32.xor 
	local.set	33
	local.get	20
	i32.const	3
	i32.gt_u
	local.set	35
	local.get	20
	i32.const	2
	i32.shr_u
	local.set	20
	local.get	26
	i32.const	30
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.set	26
	local.get	35
	br_if   	0                               # 0: up to label102
.LBB5_35:                               #   in Loop: Header=BB5_31 Depth=3
	end_loop
	end_block                               # label100:
	i32.const	0
	local.set	24
	i32.const	-2147483648
	local.set	20
	local.get	27
	local.set	26
.LBB5_36:                               #   Parent Loop BB5_15 Depth=1
                                        #     Parent Loop BB5_20 Depth=2
                                        #       Parent Loop BB5_31 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	loop    	                                # label103:
	i32.const	0
	local.get	26
	i32.const	1
	i32.and 
	i32.sub 
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.const	0
	local.get	20
	i32.const	1
	i32.shr_u
	local.get	27
	i32.and 
	i32.select
	local.get	26
	i32.const	0
	local.get	20
	local.get	27
	i32.and 
	i32.select
	local.get	24
	i32.xor 
	i32.xor 
	local.set	24
	local.get	20
	i32.const	3
	i32.gt_u
	local.set	35
	local.get	20
	i32.const	2
	i32.shr_u
	local.set	20
	local.get	26
	i32.const	30
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.set	26
	local.get	35
	br_if   	0                               # 0: up to label103
# %bb.37:                               #   in Loop: Header=BB5_31 Depth=3
	end_loop
	local.get	32
	i32.const	2
	i32.lt_u
	local.set	20
	local.get	24
	local.set	27
	local.get	33
	local.set	24
	local.get	32
	i32.const	1
	i32.shr_u
	local.set	32
	local.get	20
	i32.eqz
	br_if   	0                               # 0: up to label99
# %bb.38:                               #   in Loop: Header=BB5_20 Depth=2
	end_loop
	local.get	9
	i32.const	0
	i32.store	464
	local.get	9
	i32.const	0
	i32.store	400
	local.get	9
	i32.const	0
	i32.store	336
	local.get	9
	i32.const	0
	i32.store	272
	local.get	9
	i32.const	0
	i32.store	208
	local.get	9
	i32.const	0
	i32.store	144
	local.get	9
	i32.const	0
	i32.store	80
	local.get	9
	i32.const	0
	i32.store	16
	local.get	9
	local.get	33
	i32.store	496
	local.get	9
	i32.const	0
	local.get	33
	i32.const	1
	i32.and 
	i32.sub 
	i32.const	-306674912
	i32.and 
	local.get	33
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	26
	i32.store	480
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	local.tee	24
	i32.store	512
	local.get	9
	local.get	33
	i32.const	30
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	27
	i32.store	472
	local.get	9
	local.get	24
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	520
	local.get	9
	local.get	33
	i32.const	29
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	27
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	20
	i32.store	468
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	524
	local.get	9
	local.get	24
	local.get	20
	i32.xor 
	i32.store	516
	local.get	9
	local.get	33
	local.get	27
	i32.xor 
	local.tee	24
	i32.store	504
	local.get	9
	local.get	24
	local.get	20
	i32.xor 
	i32.store	508
	local.get	9
	local.get	33
	local.get	20
	i32.xor 
	i32.store	500
	local.get	9
	local.get	26
	local.get	27
	i32.xor 
	local.tee	24
	i32.store	488
	local.get	9
	local.get	24
	local.get	20
	i32.xor 
	i32.store	492
	local.get	9
	local.get	26
	local.get	20
	i32.xor 
	i32.store	484
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	476
	local.get	9
	local.get	33
	i32.const	28
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	20
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.store	432
	local.get	9
	local.get	33
	i32.const	27
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	35
	i32.store	416
	local.get	9
	local.get	34
	local.get	35
	i32.xor 
	local.tee	32
	i32.store	448
	local.get	9
	local.get	33
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	35
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	24
	i32.store	408
	local.get	9
	local.get	32
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	456
	local.get	9
	local.get	26
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	24
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	26
	i32.store	404
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	460
	local.get	9
	local.get	32
	local.get	26
	i32.xor 
	i32.store	452
	local.get	9
	local.get	34
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	440
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	444
	local.get	9
	local.get	34
	local.get	26
	i32.xor 
	i32.store	436
	local.get	9
	local.get	35
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	424
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	428
	local.get	9
	local.get	35
	local.get	26
	i32.xor 
	i32.store	420
	local.get	9
	local.get	24
	local.get	26
	i32.xor 
	i32.store	412
	local.get	9
	local.get	27
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	33
	i32.store	368
	local.get	9
	local.get	20
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	33
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	32
	i32.store	352
	local.get	9
	local.get	33
	local.get	32
	i32.xor 
	local.tee	36
	i32.store	384
	local.get	9
	local.get	34
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	32
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	27
	i32.store	344
	local.get	9
	local.get	36
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	392
	local.get	9
	local.get	35
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	27
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	20
	i32.store	340
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	396
	local.get	9
	local.get	36
	local.get	20
	i32.xor 
	i32.store	388
	local.get	9
	local.get	33
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	376
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	380
	local.get	9
	local.get	33
	local.get	20
	i32.xor 
	i32.store	372
	local.get	9
	local.get	32
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	360
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	364
	local.get	9
	local.get	32
	local.get	20
	i32.xor 
	i32.store	356
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	348
	local.get	9
	local.get	24
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	20
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.store	304
	local.get	9
	local.get	26
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	35
	i32.store	288
	local.get	9
	local.get	34
	local.get	35
	i32.xor 
	local.tee	36
	i32.store	320
	local.get	9
	local.get	33
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	35
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	24
	i32.store	280
	local.get	9
	local.get	36
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	328
	local.get	9
	local.get	32
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	24
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	26
	i32.store	276
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	332
	local.get	9
	local.get	36
	local.get	26
	i32.xor 
	i32.store	324
	local.get	9
	local.get	34
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	312
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	316
	local.get	9
	local.get	34
	local.get	26
	i32.xor 
	i32.store	308
	local.get	9
	local.get	35
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	296
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	300
	local.get	9
	local.get	35
	local.get	26
	i32.xor 
	i32.store	292
	local.get	9
	local.get	24
	local.get	26
	i32.xor 
	i32.store	284
	local.get	9
	local.get	27
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	33
	i32.store	240
	local.get	9
	local.get	20
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	33
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	32
	i32.store	224
	local.get	9
	local.get	33
	local.get	32
	i32.xor 
	local.tee	36
	i32.store	256
	local.get	9
	local.get	34
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	32
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	27
	i32.store	216
	local.get	9
	local.get	36
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	264
	local.get	9
	local.get	35
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	27
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	20
	i32.store	212
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	268
	local.get	9
	local.get	36
	local.get	20
	i32.xor 
	i32.store	260
	local.get	9
	local.get	33
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	248
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	252
	local.get	9
	local.get	33
	local.get	20
	i32.xor 
	i32.store	244
	local.get	9
	local.get	32
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	232
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	236
	local.get	9
	local.get	32
	local.get	20
	i32.xor 
	i32.store	228
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	220
	local.get	9
	local.get	24
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	20
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.store	176
	local.get	9
	local.get	26
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	35
	i32.store	160
	local.get	9
	local.get	34
	local.get	35
	i32.xor 
	local.tee	36
	i32.store	192
	local.get	9
	local.get	33
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	35
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	24
	i32.store	152
	local.get	9
	local.get	36
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	200
	local.get	9
	local.get	32
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	24
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	26
	i32.store	148
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	204
	local.get	9
	local.get	36
	local.get	26
	i32.xor 
	i32.store	196
	local.get	9
	local.get	34
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	184
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	188
	local.get	9
	local.get	34
	local.get	26
	i32.xor 
	i32.store	180
	local.get	9
	local.get	35
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	168
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	172
	local.get	9
	local.get	35
	local.get	26
	i32.xor 
	i32.store	164
	local.get	9
	local.get	24
	local.get	26
	i32.xor 
	i32.store	156
	local.get	9
	local.get	27
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	27
	i32.store	112
	local.get	9
	local.get	20
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	27
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	33
	i32.store	96
	local.get	9
	local.get	27
	local.get	33
	i32.xor 
	local.tee	32
	i32.store	128
	local.get	9
	local.get	34
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	33
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.store	88
	local.get	9
	local.get	32
	local.get	34
	i32.xor 
	local.tee	36
	i32.store	136
	local.get	9
	local.get	35
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	20
	i32.store	84
	local.get	9
	local.get	36
	local.get	20
	i32.xor 
	i32.store	140
	local.get	9
	local.get	32
	local.get	20
	i32.xor 
	i32.store	132
	local.get	9
	local.get	27
	local.get	34
	i32.xor 
	local.tee	35
	i32.store	120
	local.get	9
	local.get	35
	local.get	20
	i32.xor 
	i32.store	124
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	116
	local.get	9
	local.get	33
	local.get	34
	i32.xor 
	local.tee	35
	i32.store	104
	local.get	9
	local.get	35
	local.get	20
	i32.xor 
	i32.store	108
	local.get	9
	local.get	33
	local.get	20
	i32.xor 
	i32.store	100
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	92
	local.get	9
	local.get	24
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	20
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	24
	i32.store	48
	local.get	9
	local.get	26
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	24
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.store	32
	local.get	9
	local.get	24
	local.get	34
	i32.xor 
	local.tee	35
	i32.store	64
	local.get	9
	local.get	27
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	26
	i32.store	24
	local.get	9
	local.get	35
	local.get	26
	i32.xor 
	local.tee	27
	i32.store	72
	local.get	9
	local.get	33
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	20
	i32.store	20
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	76
	local.get	9
	local.get	35
	local.get	20
	i32.xor 
	i32.store	68
	local.get	9
	local.get	24
	local.get	26
	i32.xor 
	local.tee	27
	i32.store	56
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	60
	local.get	9
	local.get	24
	local.get	20
	i32.xor 
	i32.store	52
	local.get	9
	local.get	34
	local.get	26
	i32.xor 
	local.tee	27
	i32.store	40
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	44
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	36
	local.get	9
	local.get	26
	local.get	20
	i32.xor 
	i32.store	28
	local.get	9
	local.get	29
	i32.store	12
	local.get	29
	local.set	24
.LBB5_39:                               #   in Loop: Header=BB5_20 Depth=2
	end_block                               # label98:
	local.get	18
	local.get	30
	i32.const	15
	i32.and 
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.get	17
	local.get	30
	i32.const	2
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	16
	local.get	30
	i32.const	6
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	15
	local.get	30
	i32.const	10
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	14
	local.get	30
	i32.const	14
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	13
	local.get	30
	i32.const	18
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	12
	local.get	30
	i32.const	22
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	11
	local.get	30
	i32.const	26
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	31
	i32.xor 
	local.set	26
	local.get	29
	local.get	28
	i32.add 
	local.set	20
	local.get	19
	i32.const	1
	i32.add 
	local.tee	19
	local.get	6
	i32.ne  
	br_if   	0                               # 0: up to label95
# %bb.40:                               #   in Loop: Header=BB5_15 Depth=1
	end_loop
	local.get	6
	local.set	19
.LBB5_41:                               #   in Loop: Header=BB5_15 Depth=1
	end_block                               # label94:
	local.get	26
	local.get	0
	local.get	20
	i32.add 
	local.get	25
	local.get	20
	i32.sub 
	call	crc32_update_gap
	local.get	4
	local.get	23
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.ne  
	br_if   	1                               # 1: down to label89
# %bb.42:                               #   in Loop: Header=BB5_15 Depth=1
	local.get	25
	local.set	20
	local.get	23
	i32.const	1
	i32.add 
	local.tee	23
	local.get	3
	i32.eq  
	br_if   	2                               # 2: down to label88
	br      	0                               # 0: up to label93
.LBB5_43:
	end_loop
	end_block                               # label89:
	i32.const	-4
	local.set	10
	br      	1                               # 1: down to label87
.LBB5_44:
	end_block                               # label88:
	i32.const	-1
	local.set	10
	local.get	25
	local.get	1
	i32.ne  
	br_if   	0                               # 0: down to label87
# %bb.45:
	local.get	19
	local.get	6
	i32.ne  
	br_if   	0                               # 0: down to label87
# %bb.46:
	i32.const	0
	local.set	10
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label87
# %bb.47:
	local.get	8
	local.get	22
	i32.store	8
	local.get	8
	local.get	21
	i32.store	4
	local.get	8
	local.get	1
	local.get	21
	i32.sub 
	i32.store	0
.LBB5_48:
	end_block                               # label87:
	local.get	9
	i32.const	528
	i32.add 
	global.set	__stack_pointer
	local.get	10
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.crc32_update_gap,"",@
	.type	crc32_update_gap,@function      # -- Begin function crc32_update_gap
crc32_update_gap:                       # @crc32_update_gap
	.functype	crc32_update_gap (i32, i32, i32) -> (i32)
	.local  	i32, i32
# %bb.0:
	local.get	0
	i32.const	-1
	i32.xor 
	local.set	3
	i32.const	0
	local.set	0
	block   	
	local.get	2
	i32.const	16
	i32.lt_u
	br_if   	0                               # 0: down to label104
# %bb.1:
	local.get	2
	local.set	4
	local.get	1
	local.set	0
.LBB6_2:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label105:
	local.get	0
	i32.load	0:p2align=0
	local.get	3
	i32.xor 
	local.tee	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+14336
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+15360
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+13312
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+12288
	i32.xor 
	local.get	0
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+11264
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+10240
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+9216
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+8192
	i32.xor 
	local.get	0
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	0
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.set	3
	local.get	0
	i32.const	16
	i32.add 
	local.set	0
	local.get	4
	i32.const	-16
	i32.add 
	local.tee	4
	i32.const	15
	i32.gt_u
	br_if   	0                               # 0: up to label105
# %bb.3:
	end_loop
	local.get	2
	i32.const	-16
	i32.and 
	local.set	0
.LBB6_4:
	end_block                               # label104:
	block   	
	local.get	0
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label106
# %bb.5:
	local.get	0
	i32.const	1
	i32.or  
	local.set	4
	block   	
	local.get	2
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label107
# %bb.6:
	local.get	1
	local.get	0
	i32.add 
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	4
	local.set	0
.LBB6_7:
	end_block                               # label107:
	local.get	2
	local.get	4
	i32.eq  
	br_if   	0                               # 0: down to label106
# %bb.8:
	local.get	2
	local.get	0
	i32.sub 
	local.set	4
	local.get	1
	local.get	0
	i32.add 
	local.set	0
.LBB6_9:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label108:
	local.get	0
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.get	0
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	0
	i32.const	2
	i32.add 
	local.set	0
	local.get	4
	i32.const	-2
	i32.add 
	local.tee	4
	br_if   	0                               # 0: up to label108
.LBB6_10:
	end_loop
	end_block                               # label106:
	local.get	3
	i32.const	-1
	i32.xor 
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.wasm_reset_heap,"",@
	.globl	wasm_reset_heap                 # -- Begin function wasm_reset_heap
	.type	wasm_reset_heap,@function
wasm_reset_heap:                        # @wasm_reset_heap
	.functype	wasm_reset_heap () -> ()
# %bb.0:
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.wasm_alloc,"",@
	.globl	wasm_alloc                      # -- Begin function wasm_alloc
	.type	wasm_alloc,@function
wasm_alloc:                             # @wasm_alloc
	.functype	wasm_alloc (i32) -> (i32)
	.local  	i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	1
	block   	
	i32.const	0
	i32.load	heap_ptr
	local.tee	2
	br_if   	0                               # 0: down to label109
# %bb.1:
	i32.const	__heap_base
	local.set	2
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB8_2:
	end_block                               # label109:
	block   	
	local.get	0
	i32.const	-8
	i32.gt_u
	br_if   	0                               # 0: down to label110
# %bb.3:
	local.get	2
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	2
	local.get	0
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	0
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	0                               # 0: down to label110
# %bb.4:
	i32.const	0
	local.set	1
	block   	
	local.get	2
	local.get	0
	i32.add 
	local.tee	0
	i32.const	16
	i32.shr_u
	local.get	0
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	3
	memory.size	0
	local.tee	4
	i32.le_u
	br_if   	0                               # 0: down to label111
# %bb.5:
	local.get	3
	local.get	4
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	1                               # 1: down to label110
.LBB8_6:
	end_block                               # label111:
	i32.const	0
	local.get	0
	i32.store	heap_ptr
	local.get	2
	local.set	1
.LBB8_7:
	end_block                               # label110:
	local.get	1
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.wasm_get_last_parse_capacity,"",@
	.globl	wasm_get_last_parse_capacity    # -- Begin function wasm_get_last_parse_capacity
	.type	wasm_get_last_parse_capacity,@function
wasm_get_last_parse_capacity:           # @wasm_get_last_parse_capacity
	.functype	wasm_get_last_parse_capacity () -> (i32)
# %bb.0:
	i32.const	0
	i32.load	last_parse_capacity
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.wasm_get_last_content_capacity,"",@
	.globl	wasm_get_last_content_capacity  # -- Begin function wasm_get_last_content_capacity
	.type	wasm_get_last_content_capacity,@function
wasm_get_last_content_capacity:         # @wasm_get_last_content_capacity
	.functype	wasm_get_last_content_capacity () -> (i32)
# %bb.0:
	i32.const	0
	i32.load	last_content_capacity
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_term_bank,"",@
	.globl	parse_term_bank                 # -- Begin function parse_term_bank
	.type	parse_term_bank,@function
parse_term_bank:                        # @parse_term_bank
	.functype	parse_term_bank (i32, i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	i32.const	0
	local.get	4
	local.get	5
	local.get	6
	i32.const	0
	i32.ne  
	call	parse_term_bank_impl
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_term_bank_impl,"",@
	.type	parse_term_bank_impl,@function  # -- Begin function parse_term_bank_impl
parse_term_bank_impl:                   # @parse_term_bank_impl
	.functype	parse_term_bank_impl (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	32
	i32.sub 
	local.tee	8
	global.set	__stack_pointer
	block   	
	block   	
	block   	
	local.get	5
	br_if   	0                               # 0: down to label114
# %bb.1:
	i32.const	-1
	local.set	9
	local.get	6
	br_if   	2                               # 2: down to label112
# %bb.2:
	local.get	0
	i32.eqz
	br_if   	2                               # 2: down to label112
# %bb.3:
	local.get	1
	i32.eqz
	br_if   	2                               # 2: down to label112
# %bb.4:
	local.get	2
	i32.eqz
	br_if   	2                               # 2: down to label112
# %bb.5:
	local.get	3
	i32.eqz
	br_if   	2                               # 2: down to label112
# %bb.6:
	i32.const	0
	local.set	10
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
.LBB12_7:                               # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label116:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	6
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label115
# %bb.8:                                #   in Loop: Header=BB12_7 Depth=1
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label115
# %bb.9:                                #   in Loop: Header=BB12_7 Depth=1
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label116
	br      	4                               # 4: down to label112
.LBB12_10:
	end_loop
	end_block                               # label115:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label112
# %bb.11:
	local.get	6
	i32.const	91
	i32.ne  
	br_if   	2                               # 2: down to label112
# %bb.12:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label117
# %bb.13:
.LBB12_14:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label118:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label117
# %bb.15:                               #   in Loop: Header=BB12_14 Depth=1
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label117
# %bb.16:                               #   in Loop: Header=BB12_14 Depth=1
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label118
# %bb.17:
	end_loop
	local.get	1
	local.set	10
	br      	2                               # 2: down to label113
.LBB12_18:
	end_block                               # label117:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label113
# %bb.19:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	1                               # 1: down to label113
# %bb.20:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label119
# %bb.21:
.LBB12_22:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label120:
	local.get	0
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label119
# %bb.23:                               #   in Loop: Header=BB12_22 Depth=1
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label119
# %bb.24:                               #   in Loop: Header=BB12_22 Depth=1
	local.get	1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	i32.ne  
	br_if   	0                               # 0: up to label120
# %bb.25:
	end_loop
	local.get	1
	local.set	3
.LBB12_26:
	end_block                               # label119:
	i32.const	-1
	i32.const	0
	local.get	3
	local.get	1
	i32.ne  
	i32.select
	local.set	9
	br      	2                               # 2: down to label112
.LBB12_27:
	end_block                               # label114:
	i32.const	-1
	local.set	9
	local.get	0
	i32.eqz
	br_if   	1                               # 1: down to label112
# %bb.28:
	local.get	1
	i32.eqz
	br_if   	1                               # 1: down to label112
# %bb.29:
	local.get	2
	i32.eqz
	br_if   	1                               # 1: down to label112
# %bb.30:
	local.get	3
	i32.eqz
	br_if   	1                               # 1: down to label112
# %bb.31:
	local.get	6
	i32.eqz
	br_if   	1                               # 1: down to label112
# %bb.32:
	i32.const	0
	local.set	10
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
	local.get	8
	i32.const	0
	i32.store	28
	local.get	8
	i64.const	0
	i64.store	20:p2align=2
	local.get	8
	local.get	6
	i32.store	16
	local.get	8
	local.get	1
	i32.store	12
	local.get	8
	local.get	5
	i32.store	8
	local.get	8
	local.get	0
	i32.store	4
	block   	
	local.get	8
	i32.const	4
	i32.add 
	call	next_term_bank
	local.tee	5
	i32.const	1
	i32.lt_s
	br_if   	0                               # 0: down to label121
# %bb.33:
	local.get	2
	local.set	1
	i32.const	0
	local.set	10
.LBB12_34:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label122:
	block   	
	local.get	10
	local.get	3
	i32.lt_u
	br_if   	0                               # 0: down to label123
# %bb.35:                               #   in Loop: Header=BB12_34 Depth=1
	i32.const	-2
	local.set	9
	local.get	3
	i32.const	63161282
	i32.gt_u
	br_if   	4                               # 4: down to label112
# %bb.36:                               #   in Loop: Header=BB12_34 Depth=1
	local.get	2
	local.get	3
	i32.const	68
	i32.mul 
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	6
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label112
# %bb.37:                               #   in Loop: Header=BB12_34 Depth=1
	i32.const	0
	i32.load	heap_ptr
	local.get	6
	local.get	2
	i32.add 
	local.tee	5
	i32.ne  
	br_if   	4                               # 4: down to label112
# %bb.38:                               #   in Loop: Header=BB12_34 Depth=1
	i32.const	63161283
	local.get	3
	i32.const	1
	i32.shr_u
	local.tee	11
	i32.const	8192
	local.get	11
	i32.const	8192
	i32.gt_u
	i32.select
	local.tee	11
	local.get	3
	i32.add 
	local.get	3
	i32.const	63161283
	local.get	11
	i32.sub 
	i32.gt_u
	i32.select
	local.tee	3
	i32.const	68
	i32.mul 
	local.get	6
	i32.sub 
	i32.const	7
	i32.add 
	local.set	11
	local.get	5
	local.set	6
	block   	
	local.get	5
	br_if   	0                               # 0: down to label124
# %bb.39:                               #   in Loop: Header=BB12_34 Depth=1
	i32.const	__heap_base
	local.set	6
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB12_40:                              #   in Loop: Header=BB12_34 Depth=1
	end_block                               # label124:
	local.get	6
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	6
	local.get	11
	i32.const	-8
	i32.and 
	local.tee	11
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label112
# %bb.41:                               #   in Loop: Header=BB12_34 Depth=1
	block   	
	local.get	6
	local.get	11
	i32.add 
	local.tee	11
	i32.const	16
	i32.shr_u
	local.get	11
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	12
	memory.size	0
	local.tee	13
	i32.le_u
	br_if   	0                               # 0: down to label125
# %bb.42:                               #   in Loop: Header=BB12_34 Depth=1
	local.get	12
	local.get	13
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	5                               # 5: down to label112
.LBB12_43:                              #   in Loop: Header=BB12_34 Depth=1
	end_block                               # label125:
	i32.const	0
	local.get	11
	i32.store	heap_ptr
	local.get	6
	i32.eqz
	br_if   	4                               # 4: down to label112
# %bb.44:                               #   in Loop: Header=BB12_34 Depth=1
	local.get	6
	local.get	5
	i32.ne  
	br_if   	4                               # 4: down to label112
# %bb.45:                               #   in Loop: Header=BB12_34 Depth=1
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
.LBB12_46:                              #   in Loop: Header=BB12_34 Depth=1
	end_block                               # label123:
	local.get	8
	i32.const	0
	i32.store	0
	block   	
	local.get	0
	local.get	8
	i32.load	24
	local.get	8
	i32.load	28
	local.get	1
	local.get	4
	local.get	8
	i32.const	0
	i32.const	0
	i32.const	0
	i32.const	0
	local.get	7
	i32.const	0
	call	parse_row_single_pass
	br_if   	0                               # 0: down to label126
# %bb.47:
	i32.const	-1
	local.set	9
	br      	4                               # 4: down to label112
.LBB12_48:                              #   in Loop: Header=BB12_34 Depth=1
	end_block                               # label126:
	local.get	1
	i32.const	68
	i32.add 
	local.set	1
	local.get	10
	i32.const	1
	i32.add 
	local.set	10
	local.get	8
	i32.const	4
	i32.add 
	local.get	8
	i32.load	0
	call	next_term_row
	local.tee	5
	i32.const	0
	i32.gt_s
	br_if   	0                               # 0: up to label122
.LBB12_49:
	end_loop
	end_block                               # label121:
	i32.const	-1
	local.get	10
	local.get	5
	i32.select
	local.set	9
	br      	1                               # 1: down to label112
.LBB12_50:
	end_block                               # label113:
	i32.const	0
	local.set	6
.LBB12_51:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB12_67 Depth 2
                                        #     Child Loop BB12_81 Depth 2
	loop    	                                # label127:
	block   	
	local.get	10
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label128
# %bb.52:
	i32.const	-1
	local.set	9
	br      	2                               # 2: down to label112
.LBB12_53:                              #   in Loop: Header=BB12_51 Depth=1
	end_block                               # label128:
	block   	
	local.get	6
	local.get	3
	i32.lt_u
	br_if   	0                               # 0: down to label129
# %bb.54:                               #   in Loop: Header=BB12_51 Depth=1
	i32.const	-2
	local.set	9
	local.get	3
	i32.const	63161282
	i32.gt_u
	br_if   	2                               # 2: down to label112
# %bb.55:                               #   in Loop: Header=BB12_51 Depth=1
	local.get	2
	local.get	3
	i32.const	68
	i32.mul 
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	11
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	2                               # 2: down to label112
# %bb.56:                               #   in Loop: Header=BB12_51 Depth=1
	i32.const	0
	i32.load	heap_ptr
	local.get	11
	local.get	2
	i32.add 
	local.tee	5
	i32.ne  
	br_if   	2                               # 2: down to label112
# %bb.57:                               #   in Loop: Header=BB12_51 Depth=1
	i32.const	63161283
	local.get	3
	i32.const	1
	i32.shr_u
	local.tee	12
	i32.const	8192
	local.get	12
	i32.const	8192
	i32.gt_u
	i32.select
	local.tee	12
	local.get	3
	i32.add 
	local.get	3
	i32.const	63161283
	local.get	12
	i32.sub 
	i32.gt_u
	i32.select
	local.tee	3
	i32.const	68
	i32.mul 
	local.get	11
	i32.sub 
	i32.const	7
	i32.add 
	local.set	12
	local.get	5
	local.set	11
	block   	
	local.get	5
	br_if   	0                               # 0: down to label130
# %bb.58:                               #   in Loop: Header=BB12_51 Depth=1
	i32.const	__heap_base
	local.set	11
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB12_59:                              #   in Loop: Header=BB12_51 Depth=1
	end_block                               # label130:
	local.get	11
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	11
	local.get	12
	i32.const	-8
	i32.and 
	local.tee	12
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	2                               # 2: down to label112
# %bb.60:                               #   in Loop: Header=BB12_51 Depth=1
	block   	
	local.get	11
	local.get	12
	i32.add 
	local.tee	12
	i32.const	16
	i32.shr_u
	local.get	12
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	13
	memory.size	0
	local.tee	14
	i32.le_u
	br_if   	0                               # 0: down to label131
# %bb.61:                               #   in Loop: Header=BB12_51 Depth=1
	local.get	13
	local.get	14
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	3                               # 3: down to label112
.LBB12_62:                              #   in Loop: Header=BB12_51 Depth=1
	end_block                               # label131:
	i32.const	0
	local.get	12
	i32.store	heap_ptr
	local.get	11
	i32.eqz
	br_if   	2                               # 2: down to label112
# %bb.63:                               #   in Loop: Header=BB12_51 Depth=1
	local.get	11
	local.get	5
	i32.ne  
	br_if   	2                               # 2: down to label112
# %bb.64:                               #   in Loop: Header=BB12_51 Depth=1
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
.LBB12_65:                              #   in Loop: Header=BB12_51 Depth=1
	end_block                               # label129:
	local.get	8
	i32.const	0
	i32.store	4
	i32.const	-1
	local.set	9
	local.get	0
	local.get	1
	local.get	10
	local.get	2
	local.get	6
	i32.const	68
	i32.mul 
	i32.add 
	local.get	4
	local.get	8
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	i32.const	0
	i32.const	0
	local.get	7
	i32.const	0
	call	parse_row_single_pass
	i32.eqz
	br_if   	1                               # 1: down to label112
# %bb.66:                               #   in Loop: Header=BB12_51 Depth=1
	block   	
	local.get	8
	i32.load	4
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label132
.LBB12_67:                              #   Parent Loop BB12_51 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label133:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label132
# %bb.68:                               #   in Loop: Header=BB12_67 Depth=2
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label132
# %bb.69:                               #   in Loop: Header=BB12_67 Depth=2
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label133
	br      	3                               # 3: down to label112
.LBB12_70:                              #   in Loop: Header=BB12_51 Depth=1
	end_loop
	end_block                               # label132:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label112
# %bb.71:                               #   in Loop: Header=BB12_51 Depth=1
	local.get	6
	i32.const	1
	i32.add 
	local.set	6
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	5
	i32.const	44
	i32.eq  
	br_if   	0                               # 0: down to label134
# %bb.72:
	local.get	5
	i32.const	93
	i32.ne  
	br_if   	2                               # 2: down to label112
# %bb.73:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label135
# %bb.74:
.LBB12_75:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label136:
	local.get	0
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label135
# %bb.76:                               #   in Loop: Header=BB12_75 Depth=1
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label135
# %bb.77:                               #   in Loop: Header=BB12_75 Depth=1
	local.get	1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	i32.ne  
	br_if   	0                               # 0: up to label136
# %bb.78:
	end_loop
	local.get	1
	local.set	3
.LBB12_79:
	end_block                               # label135:
	local.get	6
	i32.const	-1
	local.get	3
	local.get	1
	i32.eq  
	i32.select
	local.set	9
	br      	2                               # 2: down to label112
.LBB12_80:                              #   in Loop: Header=BB12_51 Depth=1
	end_block                               # label134:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label137
.LBB12_81:                              #   Parent Loop BB12_51 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label138:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label137
# %bb.82:                               #   in Loop: Header=BB12_81 Depth=2
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label137
# %bb.83:                               #   in Loop: Header=BB12_81 Depth=2
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label138
	br      	3                               # 3: down to label112
.LBB12_84:                              #   in Loop: Header=BB12_51 Depth=1
	end_loop
	end_block                               # label137:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label112
# %bb.85:                               #   in Loop: Header=BB12_51 Depth=1
	i32.const	-1
	local.set	9
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: up to label127
.LBB12_86:
	end_loop
	end_block                               # label112:
	local.get	8
	i32.const	32
	i32.add 
	global.set	__stack_pointer
	local.get	9
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_term_bank_with_media_hints,"",@
	.globl	parse_term_bank_with_media_hints # -- Begin function parse_term_bank_with_media_hints
	.type	parse_term_bank_with_media_hints,@function
parse_term_bank_with_media_hints:       # @parse_term_bank_with_media_hints
	.functype	parse_term_bank_with_media_hints (i32, i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	i32.const	1
	local.get	4
	local.get	5
	local.get	6
	i32.const	0
	i32.ne  
	call	parse_term_bank_impl
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content,"",@
	.globl	encode_term_content             # -- Begin function encode_term_content
	.type	encode_term_content,@function
encode_term_content:                    # @encode_term_content
	.functype	encode_term_content (i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	local.get	4
	local.get	5
	i32.const	1
	call	encode_term_content_impl
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_impl,"",@
	.type	encode_term_content_impl,@function # -- Begin function encode_term_content_impl
encode_term_content_impl:               # @encode_term_content_impl
	.functype	encode_term_content_impl (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	7
	global.set	__stack_pointer
	i32.const	-1
	local.set	8
	block   	
	local.get	0
	i32.eqz
	br_if   	0                               # 0: down to label139
# %bb.1:
	local.get	1
	i32.eqz
	br_if   	0                               # 0: down to label139
# %bb.2:
	local.get	3
	i32.eqz
	br_if   	0                               # 0: down to label139
# %bb.3:
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label139
# %bb.4:
	i32.const	0
	local.set	8
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label139
# %bb.5:
	i32.const	0
	local.set	8
	i32.const	0
	local.set	9
.LBB15_6:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB15_7 Depth 2
	loop    	                                # label140:
	local.get	8
	local.tee	10
	i32.const	11
	i32.add 
	local.set	11
	local.get	3
	local.get	10
	i32.const	9
	i32.add 
	local.tee	12
	i32.add 
	local.set	13
	local.get	1
	local.get	9
	i32.const	68
	i32.mul 
	i32.add 
	local.set	14
	local.get	10
	i32.const	-10
	i32.gt_u
	local.set	15
	local.get	3
	local.get	10
	i32.add 
	local.tee	16
	i32.const	8
	i32.add 
	local.set	17
	local.get	12
	i32.const	-3
	i32.gt_u
	local.set	18
.LBB15_7:                               #   Parent Loop BB15_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	loop    	                                # label143:
	local.get	7
	i32.const	0
	i32.store	12
	local.get	7
	i32.const	0
	i32.store	8
	block   	
	local.get	15
	br_if   	0                               # 0: down to label144
# %bb.8:                                #   in Loop: Header=BB15_7 Depth=2
	local.get	12
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label144
# %bb.9:                                #   in Loop: Header=BB15_7 Depth=2
	local.get	17
	i32.const	0
	i32.load8_u	encode_term_content_row.PREFIX_RULES+8
	i32.store8	0
	local.get	16
	i32.const	0
	i64.load	encode_term_content_row.PREFIX_RULES:p2align=0
	i64.store	0:p2align=0
	block   	
	block   	
	local.get	14
	i32.load	28
	local.tee	19
	i32.eqz
	br_if   	0                               # 0: down to label146
# %bb.10:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	14
	i32.load	24
	local.set	20
	block   	
	local.get	19
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label147
# %bb.11:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	0
	local.get	20
	i32.add 
	local.tee	21
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label147
# %bb.12:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label147
# %bb.13:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label147
# %bb.14:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label146
.LBB15_15:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label147:
	local.get	19
	local.get	12
	i32.add 
	local.tee	21
	local.get	19
	i32.lt_u
	br_if   	2                               # 2: down to label144
# %bb.16:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	local.get	4
	i32.gt_u
	br_if   	2                               # 2: down to label144
# %bb.17:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label145
# %bb.18:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	13
	local.get	0
	local.get	20
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label145
.LBB15_19:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label146:
	local.get	18
	br_if   	1                               # 1: down to label144
# %bb.20:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	11
	local.get	4
	i32.gt_u
	br_if   	1                               # 1: down to label144
# %bb.21:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	13
	i32.const	8738
	i32.store16	0:p2align=0
	local.get	11
	local.set	21
.LBB15_22:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label145:
	local.get	21
	i32.const	-19
	i32.gt_u
	br_if   	0                               # 0: down to label144
# %bb.23:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	i32.const	18
	i32.add 
	local.tee	20
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label144
# %bb.24:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	3
	local.get	21
	i32.add 
	local.tee	19
	i32.const	0
	v128.load	encode_term_content_row.PREFIX_DEFINITION_TAGS
	v128.store	0:p2align=0
	local.get	19
	i32.const	16
	i32.add 
	i32.const	0
	i32.load16_u	encode_term_content_row.PREFIX_DEFINITION_TAGS+16
	i32.store16	0:p2align=0
	block   	
	block   	
	local.get	14
	i32.load	20
	local.tee	19
	i32.eqz
	br_if   	0                               # 0: down to label149
# %bb.25:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	14
	i32.load	16
	local.set	8
	block   	
	local.get	19
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label150
# %bb.26:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	0
	local.get	8
	i32.add 
	local.tee	22
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label150
# %bb.27:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	22
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label150
# %bb.28:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	22
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label150
# %bb.29:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	22
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label149
.LBB15_30:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label150:
	local.get	19
	local.get	20
	i32.add 
	local.tee	21
	local.get	19
	i32.lt_u
	br_if   	2                               # 2: down to label144
# %bb.31:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	local.get	4
	i32.gt_u
	br_if   	2                               # 2: down to label144
# %bb.32:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label148
# %bb.33:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	3
	local.get	20
	i32.add 
	local.get	0
	local.get	8
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label148
.LBB15_34:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label149:
	local.get	20
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label144
# %bb.35:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	i32.const	20
	i32.add 
	local.tee	21
	local.get	4
	i32.gt_u
	br_if   	1                               # 1: down to label144
# %bb.36:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	3
	local.get	20
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB15_37:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label148:
	local.get	21
	i32.const	-13
	i32.gt_u
	br_if   	0                               # 0: down to label144
# %bb.38:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	i32.const	12
	i32.add 
	local.tee	20
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label144
# %bb.39:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	3
	local.get	21
	i32.add 
	local.tee	19
	i32.const	0
	i64.load	encode_term_content_row.PREFIX_TERM_TAGS:p2align=0
	i64.store	0:p2align=0
	local.get	19
	i32.const	8
	i32.add 
	i32.const	0
	i32.load	encode_term_content_row.PREFIX_TERM_TAGS+8:p2align=0
	i32.store	0:p2align=0
	block   	
	block   	
	local.get	14
	i32.load	52
	local.tee	19
	i32.eqz
	br_if   	0                               # 0: down to label152
# %bb.40:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	14
	i32.load	48
	local.set	8
	block   	
	local.get	19
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label153
# %bb.41:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	0
	local.get	8
	i32.add 
	local.tee	22
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label153
# %bb.42:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	22
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label153
# %bb.43:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	22
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label153
# %bb.44:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	22
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label152
.LBB15_45:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label153:
	local.get	19
	local.get	20
	i32.add 
	local.tee	21
	local.get	19
	i32.lt_u
	br_if   	2                               # 2: down to label144
# %bb.46:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	local.get	4
	i32.gt_u
	br_if   	2                               # 2: down to label144
# %bb.47:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label151
# %bb.48:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	3
	local.get	20
	i32.add 
	local.get	0
	local.get	8
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label151
.LBB15_49:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label152:
	local.get	20
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label144
# %bb.50:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	i32.const	14
	i32.add 
	local.tee	21
	local.get	4
	i32.gt_u
	br_if   	1                               # 1: down to label144
# %bb.51:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	3
	local.get	20
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB15_52:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label151:
	local.get	21
	i32.const	-13
	i32.gt_u
	br_if   	0                               # 0: down to label144
# %bb.53:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	i32.const	12
	i32.add 
	local.tee	19
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label144
# %bb.54:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	3
	local.get	21
	i32.add 
	local.tee	20
	i32.const	0
	i64.load	encode_term_content_row.PREFIX_GLOSSARY:p2align=0
	i64.store	0:p2align=0
	local.get	20
	i32.const	8
	i32.add 
	i32.const	0
	i32.load	encode_term_content_row.PREFIX_GLOSSARY+8:p2align=0
	i32.store	0:p2align=0
	local.get	7
	local.get	19
	i32.store	4
	block   	
	block   	
	local.get	14
	i32.load	40
	local.tee	20
	i32.eqz
	br_if   	0                               # 0: down to label155
# %bb.55:                               #   in Loop: Header=BB15_7 Depth=2
	block   	
	local.get	14
	i32.load	60
	br_if   	0                               # 0: down to label156
# %bb.56:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	20
	local.get	19
	i32.add 
	local.tee	21
	local.get	20
	i32.lt_u
	br_if   	3                               # 3: down to label144
# %bb.57:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	local.get	4
	i32.gt_u
	br_if   	3                               # 3: down to label144
# %bb.58:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	20
	i32.eqz
	br_if   	2                               # 2: down to label154
# %bb.59:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	3
	local.get	19
	i32.add 
	local.get	0
	local.get	14
	i32.load	36
	i32.add 
	local.get	20
	memory.copy	0, 0
	br      	2                               # 2: down to label154
.LBB15_60:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label156:
	local.get	0
	local.get	14
	i32.load	36
	local.tee	19
	local.get	20
	i32.add 
	local.tee	21
	local.get	19
	local.get	21
	local.get	3
	local.get	4
	local.get	7
	i32.const	4
	i32.add 
	call	write_normalized_glossary_value
	i32.eqz
	br_if   	2                               # 2: down to label144
# %bb.61:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	7
	i32.load	4
	local.set	21
	br      	1                               # 1: down to label154
.LBB15_62:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label155:
	local.get	19
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label144
# %bb.63:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	i32.const	14
	i32.add 
	local.tee	21
	local.get	4
	i32.gt_u
	br_if   	1                               # 1: down to label144
# %bb.64:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	3
	local.get	19
	i32.add 
	i32.const	23899
	i32.store16	0:p2align=0
.LBB15_65:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label154:
	local.get	21
	local.get	4
	i32.ge_u
	br_if   	0                               # 0: down to label144
# %bb.66:                               #   in Loop: Header=BB15_6 Depth=1
	local.get	3
	local.get	21
	i32.add 
	i32.const	125
	i32.store8	0
	local.get	7
	local.get	21
	i32.const	1
	i32.add 
	local.tee	8
	i32.store	4
	local.get	8
	local.get	10
	i32.sub 
	local.set	21
	local.get	6
	br_if   	2                               # 2: down to label142
# %bb.67:                               #   in Loop: Header=BB15_6 Depth=1
	i32.const	0
	local.set	20
	i32.const	0
	local.set	12
	br      	3                               # 3: down to label141
.LBB15_68:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label144:
	local.get	7
	local.get	10
	i32.store	4
	i32.const	-2
	local.set	8
	local.get	4
	i32.const	2147483646
	i32.gt_u
	br_if   	4                               # 4: down to label139
# %bb.69:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	3
	local.get	4
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	21
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label139
# %bb.70:                               #   in Loop: Header=BB15_7 Depth=2
	i32.const	0
	i32.load	heap_ptr
	local.get	21
	local.get	3
	i32.add 
	local.tee	19
	i32.ne  
	br_if   	4                               # 4: down to label139
# %bb.71:                               #   in Loop: Header=BB15_7 Depth=2
	i32.const	2147483647
	local.get	4
	i32.const	1
	i32.shr_u
	local.tee	20
	i32.const	1048576
	local.get	20
	i32.const	1048576
	i32.gt_u
	i32.select
	local.tee	20
	local.get	4
	i32.add 
	local.get	4
	local.get	20
	i32.const	2147483647
	i32.xor 
	i32.gt_u
	i32.select
	local.tee	4
	local.get	21
	i32.sub 
	i32.const	7
	i32.add 
	local.set	20
	local.get	19
	local.set	21
	block   	
	local.get	19
	br_if   	0                               # 0: down to label157
# %bb.72:                               #   in Loop: Header=BB15_7 Depth=2
	i32.const	__heap_base
	local.set	21
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB15_73:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label157:
	local.get	21
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	21
	local.get	20
	i32.const	-8
	i32.and 
	local.tee	20
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label139
# %bb.74:                               #   in Loop: Header=BB15_7 Depth=2
	block   	
	local.get	21
	local.get	20
	i32.add 
	local.tee	20
	i32.const	16
	i32.shr_u
	local.get	20
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	22
	memory.size	0
	local.tee	23
	i32.le_u
	br_if   	0                               # 0: down to label158
# %bb.75:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	22
	local.get	23
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	5                               # 5: down to label139
.LBB15_76:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label158:
	i32.const	0
	local.get	20
	i32.store	heap_ptr
	local.get	21
	i32.eqz
	br_if   	4                               # 4: down to label139
# %bb.77:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	21
	local.get	19
	i32.ne  
	br_if   	4                               # 4: down to label139
# %bb.78:                               #   in Loop: Header=BB15_7 Depth=2
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	br      	0                               # 0: up to label143
.LBB15_79:                              #   in Loop: Header=BB15_6 Depth=1
	end_loop
	end_block                               # label142:
	local.get	16
	local.get	21
	local.get	7
	i32.const	12
	i32.add 
	local.get	7
	i32.const	8
	i32.add 
	call	hash_content_xxh32_pair
	local.get	7
	i32.load	12
	local.tee	19
	i32.const	1
	local.get	19
	local.get	7
	i32.load	8
	local.tee	12
	i32.or  
	i32.select
	local.set	20
.LBB15_80:                              #   in Loop: Header=BB15_6 Depth=1
	end_block                               # label141:
	local.get	5
	local.get	9
	i32.const	4
	i32.shl 
	i32.add 
	local.tee	19
	local.get	12
	i32.store	12
	local.get	19
	local.get	20
	i32.store	8
	local.get	19
	local.get	21
	i32.store	4
	local.get	19
	local.get	10
	i32.store	0
	local.get	9
	i32.const	1
	i32.add 
	local.tee	9
	local.get	2
	i32.ne  
	br_if   	0                               # 0: up to label140
.LBB15_81:
	end_loop
	end_block                               # label139:
	local.get	7
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	8
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_no_hash,"",@
	.globl	encode_term_content_no_hash     # -- Begin function encode_term_content_no_hash
	.type	encode_term_content_no_hash,@function
encode_term_content_no_hash:            # @encode_term_content_no_hash
	.functype	encode_term_content_no_hash (i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	local.get	4
	local.get	5
	i32.const	0
	call	encode_term_content_impl
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_token_binary,"",@
	.globl	encode_term_content_token_binary # -- Begin function encode_term_content_token_binary
	.type	encode_term_content_token_binary,@function
encode_term_content_token_binary:       # @encode_term_content_token_binary
	.functype	encode_term_content_token_binary (i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	6
	global.set	__stack_pointer
	i32.const	-1
	local.set	7
	block   	
	local.get	0
	i32.eqz
	br_if   	0                               # 0: down to label159
# %bb.1:
	local.get	1
	i32.eqz
	br_if   	0                               # 0: down to label159
# %bb.2:
	local.get	3
	i32.eqz
	br_if   	0                               # 0: down to label159
# %bb.3:
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label159
# %bb.4:
	i32.const	0
	local.set	7
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	6
	i32.const	0
	i32.store	12
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label159
# %bb.5:
	i32.const	0
	local.set	8
	i32.const	0
	local.set	9
.LBB17_6:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB17_7 Depth 2
	loop    	                                # label160:
	local.get	6
	i32.const	0
	i32.store	8
	local.get	6
	i32.const	0
	i32.store	4
	block   	
	local.get	0
	local.get	1
	local.get	9
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	10
	local.get	3
	local.get	4
	local.get	6
	i32.const	12
	i32.add 
	local.get	6
	i32.const	8
	i32.add 
	local.get	6
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	call	encode_term_content_token_binary_row
	br_if   	0                               # 0: down to label161
.LBB17_7:                               #   Parent Loop BB17_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label162:
	local.get	6
	local.get	8
	i32.store	12
	block   	
	block   	
	local.get	4
	i32.const	2147483646
	i32.gt_u
	br_if   	0                               # 0: down to label164
# %bb.8:                                #   in Loop: Header=BB17_7 Depth=2
	local.get	3
	local.get	4
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	11
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	0                               # 0: down to label164
# %bb.9:                                #   in Loop: Header=BB17_7 Depth=2
	i32.const	0
	i32.load	heap_ptr
	local.get	11
	local.get	3
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: down to label164
# %bb.10:                               #   in Loop: Header=BB17_7 Depth=2
	i32.const	2147483647
	local.get	4
	i32.const	1
	i32.shr_u
	local.tee	12
	i32.const	1048576
	local.get	12
	i32.const	1048576
	i32.gt_u
	i32.select
	local.tee	12
	local.get	4
	i32.add 
	local.get	4
	local.get	12
	i32.const	2147483647
	i32.xor 
	i32.gt_u
	i32.select
	local.tee	4
	local.get	11
	i32.sub 
	i32.const	7
	i32.add 
	local.set	12
	local.get	7
	local.set	11
	block   	
	local.get	7
	br_if   	0                               # 0: down to label165
# %bb.11:                               #   in Loop: Header=BB17_7 Depth=2
	i32.const	__heap_base
	local.set	11
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB17_12:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label165:
	local.get	11
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	11
	local.get	12
	i32.const	-8
	i32.and 
	local.tee	12
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	0                               # 0: down to label164
# %bb.13:                               #   in Loop: Header=BB17_7 Depth=2
	block   	
	local.get	11
	local.get	12
	i32.add 
	local.tee	12
	i32.const	16
	i32.shr_u
	local.get	12
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	13
	memory.size	0
	local.tee	14
	i32.le_u
	br_if   	0                               # 0: down to label166
# %bb.14:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	13
	local.get	14
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	1                               # 1: down to label164
.LBB17_15:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label166:
	i32.const	0
	local.get	12
	i32.store	heap_ptr
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label164
# %bb.16:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	11
	local.get	7
	i32.eq  
	br_if   	1                               # 1: down to label163
.LBB17_17:
	end_block                               # label164:
	i32.const	-2
	local.set	7
	br      	4                               # 4: down to label159
.LBB17_18:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label163:
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	0
	local.get	10
	local.get	3
	local.get	4
	local.get	6
	i32.const	12
	i32.add 
	local.get	6
	i32.const	8
	i32.add 
	local.get	6
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	call	encode_term_content_token_binary_row
	i32.eqz
	br_if   	0                               # 0: up to label162
.LBB17_19:                              #   in Loop: Header=BB17_6 Depth=1
	end_loop
	end_block                               # label161:
	local.get	5
	local.get	9
	i32.const	4
	i32.shl 
	i32.add 
	local.tee	11
	local.get	8
	i32.store	0
	local.get	11
	local.get	6
	i32.load	12
	local.tee	7
	local.get	8
	i32.sub 
	i32.store	4
	local.get	11
	local.get	6
	i32.load	8
	i32.store	8
	local.get	11
	local.get	6
	i32.load	4
	i32.store	12
	local.get	7
	local.set	8
	local.get	9
	i32.const	1
	i32.add 
	local.tee	9
	local.get	2
	i32.ne  
	br_if   	0                               # 0: up to label160
.LBB17_20:
	end_loop
	end_block                               # label159:
	local.get	6
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	7
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_token_binary_row,"",@
	.type	encode_term_content_token_binary_row,@function # -- Begin function encode_term_content_token_binary_row
encode_term_content_token_binary_row:   # @encode_term_content_token_binary_row
	.functype	encode_term_content_token_binary_row (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	9
	global.set	__stack_pointer
	i32.const	0
	local.set	10
	block   	
	local.get	4
	i32.load	0
	local.tee	11
	i32.const	-5
	i32.gt_u
	br_if   	0                               # 0: down to label167
# %bb.1:
	local.get	11
	i32.const	4
	i32.add 
	local.tee	12
	local.get	3
	i32.gt_u
	br_if   	0                               # 0: down to label167
# %bb.2:
	local.get	2
	local.get	11
	i32.add 
	local.tee	13
	i32.const	911360589
	i32.store	0:p2align=0
	local.get	4
	local.get	12
	i32.store	0
	local.get	1
	i32.load	52
	local.set	14
	local.get	1
	i32.load	20
	local.set	15
	local.get	1
	i32.load	48
	local.set	16
	local.get	1
	i32.load	16
	local.set	17
	local.get	1
	i32.load	24
	local.set	18
	block   	
	block   	
	block   	
	block   	
	local.get	1
	i32.load	28
	local.tee	19
	br_table 	{2, 1, 1, 1, 0, 1}      # 1: down to label170
                                        # 0: down to label171
.LBB18_3:
	end_block                               # label171:
	local.get	0
	local.get	18
	i32.add 
	local.tee	20
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label170
# %bb.4:
	local.get	20
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label170
# %bb.5:
	local.get	20
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label170
# %bb.6:
	local.get	20
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label169
.LBB18_7:
	end_block                               # label170:
	local.get	12
	local.get	19
	i32.add 
	local.tee	20
	local.get	12
	i32.lt_u
	br_if   	2                               # 2: down to label167
# %bb.8:
	local.get	20
	local.get	3
	i32.gt_u
	br_if   	2                               # 2: down to label167
# %bb.9:
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label168
# %bb.10:
	local.get	2
	local.get	12
	i32.add 
	local.get	0
	local.get	18
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label168
.LBB18_11:
	end_block                               # label169:
	local.get	12
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label167
# %bb.12:
	local.get	11
	i32.const	6
	i32.add 
	local.tee	20
	local.get	3
	i32.gt_u
	br_if   	1                               # 1: down to label167
# %bb.13:
	local.get	2
	local.get	12
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB18_14:
	end_block                               # label168:
	local.get	4
	local.get	20
	i32.store	0
	local.get	20
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label167
# %bb.15:
	i32.const	0
	local.set	10
	local.get	2
	local.get	20
	i32.add 
	i32.const	0
	i32.store8	0
	local.get	4
	local.get	4
	i32.load	0
	local.tee	20
	i32.const	1
	i32.add 
	local.tee	12
	i32.store	0
	block   	
	block   	
	block   	
	block   	
	local.get	15
	br_table 	{2, 1, 1, 1, 0, 1}      # 1: down to label174
                                        # 0: down to label175
.LBB18_16:
	end_block                               # label175:
	local.get	0
	local.get	17
	i32.add 
	local.tee	19
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label174
# %bb.17:
	local.get	19
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label174
# %bb.18:
	local.get	19
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label174
# %bb.19:
	local.get	19
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label173
.LBB18_20:
	end_block                               # label174:
	local.get	12
	local.get	15
	i32.add 
	local.tee	20
	local.get	12
	i32.lt_u
	br_if   	2                               # 2: down to label167
# %bb.21:
	local.get	20
	local.get	3
	i32.gt_u
	br_if   	2                               # 2: down to label167
# %bb.22:
	local.get	15
	i32.eqz
	br_if   	1                               # 1: down to label172
# %bb.23:
	local.get	2
	local.get	12
	i32.add 
	local.get	0
	local.get	17
	i32.add 
	local.get	15
	memory.copy	0, 0
	br      	1                               # 1: down to label172
.LBB18_24:
	end_block                               # label173:
	local.get	12
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label167
# %bb.25:
	local.get	20
	i32.const	3
	i32.add 
	local.tee	20
	local.get	3
	i32.gt_u
	br_if   	1                               # 1: down to label167
# %bb.26:
	local.get	2
	local.get	12
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB18_27:
	end_block                               # label172:
	local.get	4
	local.get	20
	i32.store	0
	local.get	20
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label167
# %bb.28:
	i32.const	0
	local.set	10
	local.get	2
	local.get	20
	i32.add 
	i32.const	0
	i32.store8	0
	local.get	4
	local.get	4
	i32.load	0
	local.tee	20
	i32.const	1
	i32.add 
	local.tee	12
	i32.store	0
	block   	
	block   	
	block   	
	block   	
	local.get	14
	br_table 	{2, 1, 1, 1, 0, 1}      # 1: down to label178
                                        # 0: down to label179
.LBB18_29:
	end_block                               # label179:
	local.get	0
	local.get	16
	i32.add 
	local.tee	19
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label178
# %bb.30:
	local.get	19
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label178
# %bb.31:
	local.get	19
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label178
# %bb.32:
	local.get	19
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label177
.LBB18_33:
	end_block                               # label178:
	local.get	12
	local.get	14
	i32.add 
	local.tee	20
	local.get	12
	i32.lt_u
	br_if   	2                               # 2: down to label167
# %bb.34:
	local.get	20
	local.get	3
	i32.gt_u
	br_if   	2                               # 2: down to label167
# %bb.35:
	local.get	14
	i32.eqz
	br_if   	1                               # 1: down to label176
# %bb.36:
	local.get	2
	local.get	12
	i32.add 
	local.get	0
	local.get	16
	i32.add 
	local.get	14
	memory.copy	0, 0
	br      	1                               # 1: down to label176
.LBB18_37:
	end_block                               # label177:
	local.get	12
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label167
# %bb.38:
	local.get	20
	i32.const	3
	i32.add 
	local.tee	20
	local.get	3
	i32.gt_u
	br_if   	1                               # 1: down to label167
# %bb.39:
	local.get	2
	local.get	12
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB18_40:
	end_block                               # label176:
	local.get	4
	local.get	20
	i32.store	0
	local.get	20
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label167
# %bb.41:
	i32.const	0
	local.set	10
	local.get	2
	local.get	20
	i32.add 
	i32.const	0
	i32.store8	0
	local.get	4
	local.get	4
	i32.load	0
	local.tee	19
	i32.const	1
	i32.add 
	local.tee	12
	i32.store	0
	block   	
	block   	
	local.get	1
	i32.load	40
	local.tee	20
	i32.eqz
	br_if   	0                               # 0: down to label181
# %bb.42:
	block   	
	local.get	1
	i32.load	64
	br_if   	0                               # 0: down to label182
# %bb.43:
	i32.const	0
	local.set	10
	local.get	12
	local.get	20
	i32.add 
	local.tee	8
	local.get	12
	i32.lt_u
	br_if   	3                               # 3: down to label167
# %bb.44:
	local.get	8
	local.get	3
	i32.gt_u
	br_if   	3                               # 3: down to label167
# %bb.45:
	block   	
	local.get	20
	i32.eqz
	br_if   	0                               # 0: down to label183
# %bb.46:
	local.get	2
	local.get	12
	i32.add 
	local.get	0
	local.get	1
	i32.load	36
	i32.add 
	local.get	20
	memory.copy	0, 0
.LBB18_47:
	end_block                               # label183:
	local.get	4
	local.get	8
	i32.store	0
	br      	2                               # 2: down to label180
.LBB18_48:
	end_block                               # label182:
	block   	
	local.get	7
	i32.const	16
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label184
# %bb.49:
	i32.const	1
	local.set	19
	block   	
	local.get	1
	i32.load	36
	local.tee	10
	local.get	10
	local.get	20
	i32.add 
	local.tee	20
	i32.ge_u
	br_if   	0                               # 0: down to label185
# %bb.50:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label185
# %bb.51:
	i32.const	1
	local.set	19
	block   	
	local.get	12
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label186
# %bb.52:
	local.get	2
	local.get	12
	i32.add 
	i32.const	91
	i32.store8	0
	i32.const	1
	local.set	19
	local.get	4
	local.get	4
	i32.load	0
	i32.const	1
	i32.add 
	local.tee	18
	i32.store	0
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label186
# %bb.53:
	local.get	0
	i32.const	1
	i32.add 
	local.set	21
	local.get	0
	i32.const	2
	i32.add 
	local.set	22
	local.get	0
	i32.const	5
	i32.add 
	local.set	23
	local.get	0
	i32.const	4
	i32.add 
	local.set	24
	local.get	0
	i32.const	3
	i32.add 
	local.set	25
	i32.const	0
	local.set	17
.LBB18_54:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB18_55 Depth 2
                                        #     Child Loop BB18_64 Depth 2
                                        #     Child Loop BB18_69 Depth 2
                                        #       Child Loop BB18_70 Depth 3
                                        #       Child Loop BB18_84 Depth 3
                                        #       Child Loop BB18_137 Depth 3
                                        #       Child Loop BB18_143 Depth 3
                                        #       Child Loop BB18_172 Depth 3
                                        #     Child Loop BB18_195 Depth 2
	loop    	                                # label187:
	block   	
	local.get	10
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label188
.LBB18_55:                              #   Parent Loop BB18_54 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label189:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	19
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label188
# %bb.56:                               #   in Loop: Header=BB18_55 Depth=2
	i32.const	1
	local.get	19
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label188
# %bb.57:                               #   in Loop: Header=BB18_55 Depth=2
	i32.const	1
	local.set	19
	local.get	20
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label189
	br      	3                               # 3: down to label186
.LBB18_58:                              #   in Loop: Header=BB18_54 Depth=1
	end_loop
	end_block                               # label188:
	i32.const	1
	local.set	19
	local.get	10
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label186
# %bb.59:                               #   in Loop: Header=BB18_54 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	local.tee	16
	i32.load8_u	0
	local.tee	7
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: down to label190
# %bb.60:
	local.get	18
	local.get	3
	i32.ge_u
	br_if   	2                               # 2: down to label186
# %bb.61:
	local.get	2
	local.get	18
	i32.add 
	i32.const	93
	i32.store8	0
	local.get	4
	i32.load	0
	i32.const	1
	i32.add 
	local.set	12
	i32.const	0
	local.set	19
	br      	2                               # 2: down to label186
.LBB18_62:                              #   in Loop: Header=BB18_54 Depth=1
	end_block                               # label190:
	local.get	9
	i32.const	0
	i32.store	8
	block   	
	block   	
	block   	
	local.get	7
	i32.const	123
	i32.ne  
	br_if   	0                               # 0: down to label193
# %bb.63:                               #   in Loop: Header=BB18_54 Depth=1
	block   	
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label195
.LBB18_64:                              #   Parent Loop BB18_54 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label196:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label195
# %bb.65:                               #   in Loop: Header=BB18_64 Depth=2
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label195
# %bb.66:                               #   in Loop: Header=BB18_64 Depth=2
	local.get	20
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label196
	br      	2                               # 2: down to label194
.LBB18_67:                              #   in Loop: Header=BB18_54 Depth=1
	end_loop
	end_block                               # label195:
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label194
# %bb.68:                               #   in Loop: Header=BB18_54 Depth=1
	i32.const	0
	local.set	26
	i32.const	0
	local.set	27
	i32.const	0
	local.set	14
	i32.const	0
	local.set	28
	i32.const	0
	local.set	29
.LBB18_69:                              #   Parent Loop BB18_54 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB18_70 Depth 3
                                        #       Child Loop BB18_84 Depth 3
                                        #       Child Loop BB18_137 Depth 3
                                        #       Child Loop BB18_143 Depth 3
                                        #       Child Loop BB18_172 Depth 3
	loop    	                                # label197:
	block   	
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label198
.LBB18_70:                              #   Parent Loop BB18_54 Depth=1
                                        #     Parent Loop BB18_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label199:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label198
# %bb.71:                               #   in Loop: Header=BB18_70 Depth=3
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label198
# %bb.72:                               #   in Loop: Header=BB18_70 Depth=3
	local.get	20
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label199
	br      	3                               # 3: down to label194
.LBB18_73:                              #   in Loop: Header=BB18_69 Depth=2
	end_loop
	end_block                               # label198:
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label194
# %bb.74:                               #   in Loop: Header=BB18_69 Depth=2
	block   	
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	local.tee	18
	i32.const	125
	i32.ne  
	br_if   	0                               # 0: down to label200
# %bb.75:                               #   in Loop: Header=BB18_54 Depth=1
	local.get	27
	i32.const	2
	i32.ne  
	br_if   	2                               # 2: down to label194
# %bb.76:                               #   in Loop: Header=BB18_54 Depth=1
	local.get	26
	i32.eqz
	br_if   	2                               # 2: down to label194
# %bb.77:                               #   in Loop: Header=BB18_54 Depth=1
	local.get	29
	i32.eqz
	br_if   	2                               # 2: down to label194
# %bb.78:                               #   in Loop: Header=BB18_54 Depth=1
	local.get	16
	i32.load8_u	0
	i32.const	91
	i32.eq  
	br_if   	7                               # 7: down to label186
# %bb.79:                               #   in Loop: Header=BB18_54 Depth=1
	i32.const	1
	local.set	18
	local.get	7
	i32.const	1
	i32.add 
	local.set	7
	br      	5                               # 5: down to label191
.LBB18_80:                              #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label200:
	local.get	27
	i32.const	1
	i32.gt_u
	br_if   	1                               # 1: down to label194
# %bb.81:                               #   in Loop: Header=BB18_69 Depth=2
	local.get	18
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label194
# %bb.82:                               #   in Loop: Header=BB18_69 Depth=2
	local.get	7
	i32.const	1
	i32.add 
	local.tee	30
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label194
# %bb.83:                               #   in Loop: Header=BB18_69 Depth=2
	local.get	30
	local.set	15
.LBB18_84:                              #   Parent Loop BB18_54 Depth=1
                                        #     Parent Loop BB18_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label201:
	block   	
	local.get	15
	local.tee	18
	i32.const	8
	i32.add 
	local.tee	15
	local.get	20
	i32.gt_u
	br_if   	0                               # 0: down to label202
# %bb.85:                               #   in Loop: Header=BB18_84 Depth=3
	local.get	0
	local.get	18
	i32.add 
	i64.load	0:p2align=0
	local.tee	31
	i64.const	-1
	i64.xor 
	local.get	31
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	31
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	31
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	31
	i64.eqz
	br_if   	1                               # 1: up to label201
# %bb.86:                               #   in Loop: Header=BB18_84 Depth=3
	local.get	31
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	18
	i32.add 
	local.set	18
.LBB18_87:                              #   in Loop: Header=BB18_84 Depth=3
	end_block                               # label202:
	local.get	18
	local.get	20
	i32.ge_u
	br_if   	2                               # 2: down to label194
# %bb.88:                               #   in Loop: Header=BB18_84 Depth=3
	block   	
	block   	
	block   	
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label205
# %bb.89:                               #   in Loop: Header=BB18_84 Depth=3
	local.get	18
	i32.const	1
	i32.add 
	local.tee	15
	local.get	20
	i32.ge_u
	br_if   	5                               # 5: down to label194
# %bb.90:                               #   in Loop: Header=BB18_84 Depth=3
	block   	
	block   	
	local.get	0
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 1, 0, 7} # 7: down to label194
                                        # 1: down to label206
                                        # 0: down to label207
.LBB18_91:                              #   in Loop: Header=BB18_84 Depth=3
	end_block                               # label207:
	local.get	18
	i32.const	6
	i32.add 
	local.tee	15
	local.get	20
	i32.gt_u
	br_if   	6                               # 6: down to label194
# %bb.92:                               #   in Loop: Header=BB18_84 Depth=3
	local.get	18
	i32.const	2
	i32.add 
	local.tee	32
	local.get	15
	i32.ge_u
	br_if   	2                               # 2: down to label204
# %bb.93:                               #   in Loop: Header=BB18_84 Depth=3
	block   	
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label208
# %bb.94:                               #   in Loop: Header=BB18_84 Depth=3
	local.get	32
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label194
.LBB18_95:                              #   in Loop: Header=BB18_84 Depth=3
	end_block                               # label208:
	block   	
	local.get	25
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label209
# %bb.96:                               #   in Loop: Header=BB18_84 Depth=3
	local.get	32
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label194
.LBB18_97:                              #   in Loop: Header=BB18_84 Depth=3
	end_block                               # label209:
	block   	
	local.get	24
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label210
# %bb.98:                               #   in Loop: Header=BB18_84 Depth=3
	local.get	32
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label194
.LBB18_99:                              #   in Loop: Header=BB18_84 Depth=3
	end_block                               # label210:
	local.get	23
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	18
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label204
# %bb.100:                              #   in Loop: Header=BB18_84 Depth=3
	local.get	18
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label204
	br      	6                               # 6: down to label194
.LBB18_101:                             #   in Loop: Header=BB18_84 Depth=3
	end_block                               # label206:
	local.get	18
	i32.const	2
	i32.add 
	local.set	15
	br      	1                               # 1: down to label204
.LBB18_102:                             #   in Loop: Header=BB18_84 Depth=3
	end_block                               # label205:
	local.get	32
	i32.const	32
	i32.lt_u
	br_if   	4                               # 4: down to label194
# %bb.103:                              #   in Loop: Header=BB18_84 Depth=3
	local.get	18
	i32.const	1
	i32.add 
	local.set	15
	local.get	32
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label203
.LBB18_104:                             #   in Loop: Header=BB18_84 Depth=3
	end_block                               # label204:
	local.get	15
	local.get	20
	i32.lt_u
	br_if   	1                               # 1: up to label201
	br      	3                               # 3: down to label194
.LBB18_105:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label203:
	end_loop
	i32.const	0
	local.set	32
	i32.const	0
	local.set	33
	block   	
	local.get	18
	local.get	7
	i32.lt_u
	br_if   	0                               # 0: down to label211
# %bb.106:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	7
	i32.const	5
	i32.add 
	local.set	34
	i32.const	0
	local.set	33
	i32.const	0
	local.set	32
	block   	
	local.get	18
	local.get	7
	i32.eq  
	br_if   	0                               # 0: down to label212
# %bb.107:                              #   in Loop: Header=BB18_69 Depth=2
	block   	
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label213
# %bb.108:                              #   in Loop: Header=BB18_69 Depth=2
	i32.const	0
	local.set	32
	local.get	18
	local.get	7
	i32.sub 
	local.tee	36
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label212
# %bb.109:                              #   in Loop: Header=BB18_69 Depth=2
	i32.const	0
	local.set	32
	local.get	35
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label212
# %bb.110:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	22
	local.get	7
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label213
# %bb.111:                              #   in Loop: Header=BB18_69 Depth=2
	i32.const	0
	local.set	32
	local.get	35
	i32.const	121
	i32.ne  
	br_if   	1                               # 1: down to label212
# %bb.112:                              #   in Loop: Header=BB18_69 Depth=2
	i32.const	0
	local.set	32
	local.get	36
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label212
# %bb.113:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	25
	local.get	7
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label213
# %bb.114:                              #   in Loop: Header=BB18_69 Depth=2
	i32.const	0
	local.set	32
	local.get	35
	i32.const	112
	i32.ne  
	br_if   	1                               # 1: down to label212
# %bb.115:                              #   in Loop: Header=BB18_69 Depth=2
	i32.const	0
	local.set	32
	local.get	36
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label212
# %bb.116:                              #   in Loop: Header=BB18_69 Depth=2
	i32.const	0
	local.set	32
	block   	
	local.get	24
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label212
                                        # 0: down to label214
.LBB18_117:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label214:
	i32.const	0
	local.set	32
	local.get	34
	local.get	18
	i32.gt_u
	br_if   	1                               # 1: down to label212
# %bb.118:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	0
	local.get	34
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	32
	br      	1                               # 1: down to label212
.LBB18_119:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label213:
	local.get	0
	local.get	7
	local.get	15
	i32.const	.L.str
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	32
.LBB18_120:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label212:
	local.get	18
	local.get	7
	i32.le_u
	br_if   	0                               # 0: down to label211
# %bb.121:                              #   in Loop: Header=BB18_69 Depth=2
	block   	
	block   	
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	local.tee	30
	i32.const	116
	i32.ne  
	br_if   	0                               # 0: down to label216
# %bb.122:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	7
	i32.const	2
	i32.add 
	local.tee	30
	local.get	18
	i32.gt_u
	br_if   	2                               # 2: down to label211
# %bb.123:                              #   in Loop: Header=BB18_69 Depth=2
	block   	
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{2, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label211
                                        # 0: down to label217
.LBB18_124:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label217:
	local.get	7
	i32.const	3
	i32.add 
	local.tee	30
	local.get	18
	i32.gt_u
	br_if   	2                               # 2: down to label211
# %bb.125:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	local.tee	30
	i32.const	92
	i32.eq  
	br_if   	1                               # 1: down to label215
# %bb.126:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	30
	i32.const	120
	i32.ne  
	br_if   	2                               # 2: down to label211
# %bb.127:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	7
	i32.const	4
	i32.add 
	local.tee	30
	local.get	18
	i32.gt_u
	br_if   	2                               # 2: down to label211
# %bb.128:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	local.tee	30
	i32.const	92
	i32.eq  
	br_if   	1                               # 1: down to label215
# %bb.129:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	30
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label211
# %bb.130:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	34
	local.get	18
	i32.gt_u
	br_if   	2                               # 2: down to label211
# %bb.131:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	0
	local.get	34
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	33
	br      	2                               # 2: down to label211
.LBB18_132:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label216:
	local.get	30
	i32.const	92
	i32.ne  
	br_if   	1                               # 1: down to label211
.LBB18_133:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label215:
	local.get	0
	local.get	7
	local.get	15
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	33
.LBB18_134:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label211:
	block   	
	local.get	32
	br_if   	0                               # 0: down to label218
# %bb.135:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	33
	i32.eqz
	br_if   	2                               # 2: down to label194
.LBB18_136:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label218:
	block   	
	local.get	15
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label219
.LBB18_137:                             #   Parent Loop BB18_54 Depth=1
                                        #     Parent Loop BB18_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label220:
	local.get	0
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	7
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label219
# %bb.138:                              #   in Loop: Header=BB18_137 Depth=3
	i32.const	1
	local.get	7
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label219
# %bb.139:                              #   in Loop: Header=BB18_137 Depth=3
	local.get	20
	local.get	15
	i32.const	1
	i32.add 
	local.tee	15
	i32.ne  
	br_if   	0                               # 0: up to label220
	br      	3                               # 3: down to label194
.LBB18_140:                             #   in Loop: Header=BB18_69 Depth=2
	end_loop
	end_block                               # label219:
	local.get	15
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label194
# %bb.141:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	0
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	1                               # 1: down to label194
# %bb.142:                              #   in Loop: Header=BB18_69 Depth=2
	block   	
	local.get	15
	i32.const	1
	i32.add 
	local.tee	18
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label221
.LBB18_143:                             #   Parent Loop BB18_54 Depth=1
                                        #     Parent Loop BB18_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label222:
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	7
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label221
# %bb.144:                              #   in Loop: Header=BB18_143 Depth=3
	i32.const	1
	local.get	7
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label221
# %bb.145:                              #   in Loop: Header=BB18_143 Depth=3
	local.get	20
	local.get	18
	i32.const	1
	i32.add 
	local.tee	18
	i32.ne  
	br_if   	0                               # 0: up to label222
# %bb.146:                              #   in Loop: Header=BB18_69 Depth=2
	end_loop
	local.get	20
	local.set	18
.LBB18_147:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label221:
	local.get	9
	i32.const	0
	i32.store	12
	local.get	0
	local.get	20
	local.get	18
	local.get	9
	i32.const	12
	i32.add 
	call	parse_value_span
	i32.eqz
	br_if   	1                               # 1: down to label194
# %bb.148:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	9
	i32.load	12
	local.tee	7
	local.get	20
	i32.gt_u
	br_if   	1                               # 1: down to label194
# %bb.149:                              #   in Loop: Header=BB18_69 Depth=2
	block   	
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label224
# %bb.150:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	7
	local.get	18
	i32.le_u
	br_if   	3                               # 3: down to label194
# %bb.151:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	3                               # 3: down to label194
# %bb.152:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	7
	local.get	18
	i32.const	-1
	i32.xor 
	i32.add 
	local.tee	15
	i32.eqz
	br_if   	3                               # 3: down to label194
# %bb.153:                              #   in Loop: Header=BB18_69 Depth=2
	block   	
	local.get	21
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label225
# %bb.154:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	15
	i32.const	1
	i32.eq  
	br_if   	4                               # 4: down to label194
# %bb.155:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	32
	i32.const	116
	i32.ne  
	br_if   	4                               # 4: down to label194
# %bb.156:                              #   in Loop: Header=BB18_69 Depth=2
	block   	
	local.get	22
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 5, 5, 5, 5, 5, 5, 5, 5, 0, 5} # 5: down to label194
                                        # 0: down to label226
.LBB18_157:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label226:
	local.get	15
	i32.const	2
	i32.eq  
	br_if   	4                               # 4: down to label194
# %bb.158:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	25
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label225
# %bb.159:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	32
	i32.const	120
	i32.ne  
	br_if   	4                               # 4: down to label194
# %bb.160:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	15
	i32.const	3
	i32.eq  
	br_if   	4                               # 4: down to label194
# %bb.161:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	24
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	15
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label225
# %bb.162:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	15
	i32.const	116
	i32.ne  
	br_if   	4                               # 4: down to label194
# %bb.163:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	18
	i32.const	5
	i32.add 
	local.tee	18
	local.get	7
	i32.ge_u
	br_if   	4                               # 4: down to label194
# %bb.164:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	4                               # 4: down to label194
# %bb.165:                              #   in Loop: Header=BB18_69 Depth=2
	i32.const	1
	local.set	26
	br      	2                               # 2: down to label223
.LBB18_166:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label225:
	local.get	0
	local.get	18
	local.get	7
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	3                               # 3: down to label194
# %bb.167:                              #   in Loop: Header=BB18_69 Depth=2
	i32.const	1
	local.set	26
	br      	1                               # 1: down to label223
.LBB18_168:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label224:
	local.get	7
	local.get	18
	i32.le_u
	br_if   	2                               # 2: down to label194
# %bb.169:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	2                               # 2: down to label194
# %bb.170:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	7
	local.get	18
	i32.sub 
	local.set	14
	i32.const	1
	local.set	29
	local.get	18
	local.set	28
.LBB18_171:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label223:
	block   	
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label227
.LBB18_172:                             #   Parent Loop BB18_54 Depth=1
                                        #     Parent Loop BB18_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label228:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label227
# %bb.173:                              #   in Loop: Header=BB18_172 Depth=3
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label227
# %bb.174:                              #   in Loop: Header=BB18_172 Depth=3
	local.get	20
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label228
	br      	3                               # 3: down to label194
.LBB18_175:                             #   in Loop: Header=BB18_69 Depth=2
	end_loop
	end_block                               # label227:
	block   	
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label229
# %bb.176:                              #   in Loop: Header=BB18_69 Depth=2
	local.get	7
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.eq  
	i32.add 
	local.set	7
.LBB18_177:                             #   in Loop: Header=BB18_69 Depth=2
	end_block                               # label229:
	local.get	27
	i32.const	1
	i32.add 
	local.set	27
	local.get	7
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: up to label197
.LBB18_178:                             #   in Loop: Header=BB18_54 Depth=1
	end_loop
	end_block                               # label194:
	local.get	16
	i32.load8_u	0
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	1                               # 1: down to label192
	br      	4                               # 4: down to label186
.LBB18_179:                             #   in Loop: Header=BB18_54 Depth=1
	end_block                               # label193:
	local.get	7
	i32.const	223
	i32.and 
	i32.const	91
	i32.eq  
	br_if   	3                               # 3: down to label186
.LBB18_180:                             #   in Loop: Header=BB18_54 Depth=1
	end_block                               # label192:
	local.get	0
	local.get	20
	local.get	10
	local.get	9
	i32.const	8
	i32.add 
	call	parse_value_span
	i32.eqz
	br_if   	2                               # 2: down to label186
# %bb.181:                              #   in Loop: Header=BB18_54 Depth=1
	i32.const	0
	local.set	28
	i32.const	0
	local.set	14
	i32.const	0
	local.set	18
	local.get	9
	i32.load	8
	local.tee	7
	local.get	20
	i32.gt_u
	br_if   	2                               # 2: down to label186
.LBB18_182:                             #   in Loop: Header=BB18_54 Depth=1
	end_block                               # label191:
	block   	
	local.get	17
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label230
# %bb.183:                              #   in Loop: Header=BB18_54 Depth=1
	local.get	4
	i32.load	0
	local.tee	15
	local.get	3
	i32.ge_u
	br_if   	2                               # 2: down to label186
# %bb.184:                              #   in Loop: Header=BB18_54 Depth=1
	local.get	2
	local.get	15
	i32.add 
	i32.const	44
	i32.store8	0
	local.get	4
	local.get	4
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
.LBB18_185:                             #   in Loop: Header=BB18_54 Depth=1
	end_block                               # label230:
	block   	
	block   	
	local.get	18
	i32.eqz
	br_if   	0                               # 0: down to label232
# %bb.186:                              #   in Loop: Header=BB18_54 Depth=1
	local.get	4
	i32.load	0
	local.tee	10
	local.get	14
	i32.add 
	local.tee	18
	local.get	10
	i32.lt_u
	br_if   	3                               # 3: down to label186
# %bb.187:                              #   in Loop: Header=BB18_54 Depth=1
	local.get	18
	local.get	3
	i32.gt_u
	br_if   	3                               # 3: down to label186
# %bb.188:                              #   in Loop: Header=BB18_54 Depth=1
	local.get	14
	i32.eqz
	br_if   	1                               # 1: down to label231
# %bb.189:                              #   in Loop: Header=BB18_54 Depth=1
	local.get	2
	local.get	10
	i32.add 
	local.get	0
	local.get	28
	i32.add 
	local.get	14
	memory.copy	0, 0
	br      	1                               # 1: down to label231
.LBB18_190:                             #   in Loop: Header=BB18_54 Depth=1
	end_block                               # label232:
	local.get	4
	i32.load	0
	local.tee	15
	local.get	7
	local.get	10
	i32.sub 
	local.tee	10
	i32.add 
	local.tee	18
	local.get	15
	i32.lt_u
	br_if   	2                               # 2: down to label186
# %bb.191:                              #   in Loop: Header=BB18_54 Depth=1
	local.get	18
	local.get	3
	i32.gt_u
	br_if   	2                               # 2: down to label186
# %bb.192:                              #   in Loop: Header=BB18_54 Depth=1
	local.get	10
	i32.eqz
	br_if   	0                               # 0: down to label231
# %bb.193:                              #   in Loop: Header=BB18_54 Depth=1
	local.get	2
	local.get	15
	i32.add 
	local.get	16
	local.get	10
	memory.copy	0, 0
.LBB18_194:                             #   in Loop: Header=BB18_54 Depth=1
	end_block                               # label231:
	local.get	4
	local.get	18
	i32.store	0
	block   	
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label233
.LBB18_195:                             #   Parent Loop BB18_54 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label234:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label233
# %bb.196:                              #   in Loop: Header=BB18_195 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label233
# %bb.197:                              #   in Loop: Header=BB18_195 Depth=2
	local.get	20
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label234
	br      	3                               # 3: down to label186
.LBB18_198:                             #   in Loop: Header=BB18_54 Depth=1
	end_loop
	end_block                               # label233:
	block   	
	block   	
	local.get	7
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: down to label236
# %bb.199:                              #   in Loop: Header=BB18_54 Depth=1
	local.get	7
	local.set	10
	br      	1                               # 1: down to label235
.LBB18_200:                             #   in Loop: Header=BB18_54 Depth=1
	end_block                               # label236:
	local.get	7
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.eq  
	i32.add 
	local.set	10
.LBB18_201:                             #   in Loop: Header=BB18_54 Depth=1
	end_block                               # label235:
	i32.const	1
	local.set	17
	local.get	10
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: up to label187
# %bb.202:
	end_loop
	i32.const	1
	local.set	19
.LBB18_203:
	end_block                               # label186:
	local.get	4
	local.get	12
	i32.store	0
.LBB18_204:
	end_block                               # label185:
	block   	
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label237
# %bb.205:
	block   	
	local.get	19
	br_if   	0                               # 0: down to label238
# %bb.206:
	local.get	8
	local.get	8
	i32.load	12
	i32.const	1
	i32.add 
	i32.store	12
	br      	4                               # 4: down to label180
.LBB18_207:
	end_block                               # label238:
	local.get	8
	local.get	8
	i32.load	16
	i32.const	1
	i32.add 
	i32.store	16
	br      	1                               # 1: down to label184
.LBB18_208:
	end_block                               # label237:
	local.get	19
	i32.eqz
	br_if   	2                               # 2: down to label180
.LBB18_209:
	end_block                               # label184:
	local.get	0
	local.get	1
	i32.load	40
	local.get	1
	i32.load	36
	local.tee	1
	i32.add 
	local.tee	12
	local.get	1
	local.get	12
	local.get	2
	local.get	3
	local.get	4
	call	write_normalized_glossary_value
	br_if   	1                               # 1: down to label180
# %bb.210:
	i32.const	0
	local.set	10
	br      	2                               # 2: down to label167
.LBB18_211:
	end_block                               # label181:
	local.get	12
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label167
# %bb.212:
	local.get	19
	i32.const	3
	i32.add 
	local.tee	1
	local.get	3
	i32.gt_u
	br_if   	1                               # 1: down to label167
# %bb.213:
	local.get	2
	local.get	12
	i32.add 
	i32.const	23899
	i32.store16	0:p2align=0
	local.get	4
	local.get	1
	i32.store	0
.LBB18_214:
	end_block                               # label180:
	local.get	4
	i32.load	0
	local.set	1
	local.get	9
	i32.const	0
	i32.store	12
	local.get	9
	i32.const	0
	i32.store	8
	local.get	13
	local.get	1
	local.get	11
	i32.sub 
	local.get	9
	i32.const	12
	i32.add 
	local.get	9
	i32.const	8
	i32.add 
	call	hash_content_xxh32_pair
	i32.const	1
	local.set	10
	local.get	5
	local.get	9
	i32.load	12
	local.tee	1
	i32.const	1
	local.get	1
	local.get	9
	i32.load	8
	local.tee	4
	i32.or  
	i32.select
	i32.store	0
	local.get	6
	local.get	4
	i32.store	0
.LBB18_215:
	end_block                               # label167:
	local.get	9
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	10
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.build_term_string_plan,"",@
	.globl	build_term_string_plan          # -- Begin function build_term_string_plan
	.type	build_term_string_plan,@function
build_term_string_plan:                 # @build_term_string_plan
	.functype	build_term_string_plan (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	32
	i32.sub 
	local.tee	14
	global.set	__stack_pointer
	i32.const	-1
	local.set	15
	block   	
	local.get	0
	i32x4.splat
	local.get	1
	i32x4.replace_lane	1
	local.get	4
	i32x4.replace_lane	2
	local.get	6
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	16
	i32x4.eq
	v128.const	65535, 65535, 65535, 65535
	local.tee	17
	v128.and
	local.get	7
	i32x4.splat
	local.get	8
	i32x4.replace_lane	1
	local.get	9
	i32x4.replace_lane	2
	local.get	10
	i32x4.replace_lane	3
	local.get	16
	i32x4.eq
	local.get	17
	v128.and
	i16x8.narrow_i32x4_u
	v128.any_true
	br_if   	0                               # 0: down to label239
# %bb.1:
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label239
# %bb.2:
	local.get	13
	i32.eqz
	br_if   	0                               # 0: down to label239
# %bb.3:
	local.get	12
	i32.eqz
	br_if   	0                               # 0: down to label239
# %bb.4:
	i32.const	-1
	local.set	15
	local.get	12
	local.get	12
	i32.const	-1
	i32.add 
	local.tee	18
	i32.and 
	br_if   	0                               # 0: down to label239
# %bb.5:
	block   	
	block   	
	local.get	3
	br_if   	0                               # 0: down to label241
# %bb.6:
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
	br      	1                               # 1: down to label240
.LBB19_7:
	end_block                               # label241:
	local.get	3
	i32.const	1
	i32.shl 
	local.set	21
	local.get	1
	local.get	2
	i32.const	68
	i32.mul 
	i32.add 
	local.set	22
	i32.const	0
	local.set	20
	i32.const	0
	local.set	19
	i32.const	0
	local.set	23
.LBB19_8:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB19_14 Depth 2
                                        #     Child Loop BB19_19 Depth 2
                                        #     Child Loop BB19_22 Depth 2
                                        #       Child Loop BB19_28 Depth 3
                                        #       Child Loop BB19_35 Depth 3
                                        #         Child Loop BB19_41 Depth 4
                                        #         Child Loop BB19_43 Depth 4
                                        #         Child Loop BB19_46 Depth 4
                                        #       Child Loop BB19_56 Depth 3
	loop    	                                # label242:
	local.get	14
	local.get	22
	local.get	23
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	15
	i32.load	0
	local.tee	1
	i32.store	28
	local.get	14
	local.get	15
	i32.load	8
	local.tee	2
	i32.store	24
	local.get	14
	local.get	15
	i32.load	4
	local.tee	24
	i32.store	20
	local.get	14
	local.get	15
	i32.load	12
	local.tee	15
	i32.store	16
	local.get	14
	i32.const	0
	i32.store	8
	local.get	14
	i32.const	0
	i32.store	4
	i32.const	0
	local.set	25
	block   	
	local.get	15
	i32.const	2
	i32.ne  
	br_if   	0                               # 0: down to label243
# %bb.9:                                #   in Loop: Header=BB19_8 Depth=1
	i32.const	0
	local.set	25
	local.get	0
	local.get	2
	i32.add 
	local.tee	26
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label243
# %bb.10:                               #   in Loop: Header=BB19_8 Depth=1
	local.get	26
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	25
.LBB19_11:                              #   in Loop: Header=BB19_8 Depth=1
	end_block                               # label243:
	block   	
	local.get	25
	br_if   	0                               # 0: down to label244
# %bb.12:                               #   in Loop: Header=BB19_8 Depth=1
	local.get	24
	local.get	15
	i32.ne  
	br_if   	0                               # 0: down to label244
# %bb.13:                               #   in Loop: Header=BB19_8 Depth=1
	local.get	24
	i32.const	-1
	i32.add 
	local.set	26
	i32.const	0
	local.set	15
	local.get	0
	local.get	1
	i32.add 
	local.tee	27
	local.set	1
	local.get	0
	local.get	2
	i32.add 
	local.tee	28
	local.set	2
.LBB19_14:                              #   Parent Loop BB19_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label246:
	block   	
	local.get	15
	i32.const	8
	i32.add 
	local.tee	29
	local.get	24
	i32.le_u
	br_if   	0                               # 0: down to label247
# %bb.15:                               #   in Loop: Header=BB19_8 Depth=1
	local.get	15
	local.get	24
	i32.lt_u
	br_if   	2                               # 2: down to label245
# %bb.16:                               #   in Loop: Header=BB19_8 Depth=1
	i32.const	1
	local.set	25
	br      	3                               # 3: down to label244
.LBB19_17:                              #   in Loop: Header=BB19_14 Depth=2
	end_block                               # label247:
	local.get	28
	local.get	15
	i32.add 
	local.set	30
	local.get	27
	local.get	15
	i32.add 
	local.set	31
	local.get	1
	i32.const	8
	i32.add 
	local.set	1
	local.get	2
	i32.const	8
	i32.add 
	local.set	2
	local.get	26
	i32.const	-8
	i32.add 
	local.set	26
	local.get	29
	local.set	15
	local.get	31
	i64.load	0:p2align=0
	local.get	30
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label246
# %bb.18:                               #   in Loop: Header=BB19_8 Depth=1
	end_loop
	i32.const	0
	local.set	25
	br      	1                               # 1: down to label244
.LBB19_19:                              #   Parent Loop BB19_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	end_block                               # label245:
	loop    	                                # label248:
	local.get	1
	i32.load8_u	0
	local.tee	15
	local.get	2
	i32.load8_u	0
	local.tee	29
	i32.eq  
	local.set	25
	local.get	15
	local.get	29
	i32.ne  
	br_if   	1                               # 1: down to label244
# %bb.20:                               #   in Loop: Header=BB19_19 Depth=2
	local.get	26
	i32.const	0
	i32.ne  
	local.set	15
	local.get	1
	i32.const	1
	i32.add 
	local.set	1
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	local.get	26
	i32.const	-1
	i32.add 
	local.set	26
	local.get	15
	br_if   	0                               # 0: up to label248
.LBB19_21:                              #   in Loop: Header=BB19_8 Depth=1
	end_loop
	end_block                               # label244:
	local.get	14
	i32.const	28
	i32.add 
	local.set	1
	local.get	14
	i32.const	20
	i32.add 
	local.set	26
	local.get	14
	i32.const	8
	i32.add 
	local.set	32
	i32.const	1
	local.set	33
	i32.const	0
	local.set	15
.LBB19_22:                              #   Parent Loop BB19_8 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB19_28 Depth 3
                                        #       Child Loop BB19_35 Depth 3
                                        #         Child Loop BB19_41 Depth 4
                                        #         Child Loop BB19_43 Depth 4
                                        #         Child Loop BB19_46 Depth 4
                                        #       Child Loop BB19_56 Depth 3
	block   	
	loop    	                                # label250:
	block   	
	local.get	25
	local.get	15
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label251
# %bb.23:                               #   in Loop: Header=BB19_8 Depth=1
	local.get	14
	local.get	14
	i32.load	8
	i32.store	4
	br      	2                               # 2: down to label249
.LBB19_24:                              #   in Loop: Header=BB19_22 Depth=2
	end_block                               # label251:
	local.get	1
	i32.load	0
	local.set	2
	block   	
	block   	
	block   	
	local.get	26
	i32.load	0
	local.tee	26
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label254
# %bb.25:                               #   in Loop: Header=BB19_22 Depth=2
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label254
# %bb.26:                               #   in Loop: Header=BB19_22 Depth=2
	local.get	0
	local.get	2
	local.get	26
	i32.add 
	i32.const	-1
	i32.add 
	local.tee	29
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label254
# %bb.27:                               #   in Loop: Header=BB19_22 Depth=2
	local.get	26
	i32.const	-2
	i32.add 
	local.set	30
	local.get	2
	i32.const	1
	i32.add 
	local.set	31
	local.get	2
	i32.const	1
	i32.add 
	local.set	15
.LBB19_28:                              #   Parent Loop BB19_8 Depth=1
                                        #     Parent Loop BB19_22 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label255:
	local.get	15
	local.get	29
	i32.ge_u
	br_if   	2                               # 2: down to label253
# %bb.29:                               #   in Loop: Header=BB19_28 Depth=3
	local.get	0
	local.get	15
	i32.add 
	local.set	1
	local.get	15
	i32.const	1
	i32.add 
	local.set	15
	local.get	1
	i32.load8_u	0
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: up to label255
.LBB19_30:                              #   in Loop: Header=BB19_22 Depth=2
	end_loop
	end_block                               # label254:
	local.get	19
	local.set	31
	local.get	4
	local.set	34
	local.get	0
	local.get	2
	i32.add 
	local.get	26
	local.get	4
	local.get	19
	i32.add 
	local.get	5
	local.get	19
	i32.sub 
	call	decode_escaped_key
	local.tee	30
	i32.const	65536
	i32.lt_u
	br_if   	1                               # 1: down to label252
# %bb.31:
	i32.const	-4
	local.set	15
	br      	6                               # 6: down to label239
.LBB19_32:                              #   in Loop: Header=BB19_22 Depth=2
	end_block                               # label253:
	local.get	0
	local.set	34
	local.get	30
	i32.const	65535
	i32.le_u
	br_if   	0                               # 0: down to label252
# %bb.33:
	i32.const	-5
	local.set	15
	br      	5                               # 5: down to label239
.LBB19_34:                              #   in Loop: Header=BB19_22 Depth=2
	end_block                               # label252:
	local.get	34
	local.get	31
	i32.add 
	local.tee	35
	local.get	30
	i32.const	-2128831035
	call	hash_content_xxh32
	local.tee	36
	local.get	30
	i32.const	-2048144789
	i32.mul 
	i32.xor 
	local.tee	15
	i32.const	16
	i32.shr_u
	local.get	15
	i32.xor 
	local.get	18
	i32.and 
	local.set	27
	i32.const	0
	local.set	37
.LBB19_35:                              #   Parent Loop BB19_8 Depth=1
                                        #     Parent Loop BB19_22 Depth=2
                                        # =>    This Loop Header: Depth=3
                                        #         Child Loop BB19_41 Depth 4
                                        #         Child Loop BB19_43 Depth 4
                                        #         Child Loop BB19_46 Depth 4
	block   	
	block   	
	loop    	                                # label258:
	local.get	11
	local.get	27
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	15
	i32.eqz
	br_if   	1                               # 1: down to label257
# %bb.36:                               #   in Loop: Header=BB19_35 Depth=3
	block   	
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	28
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: down to label259
# %bb.37:
	i32.const	-3
	local.set	15
	br      	8                               # 8: down to label239
.LBB19_38:                              #   in Loop: Header=BB19_35 Depth=3
	end_block                               # label259:
	block   	
	local.get	8
	local.get	28
	i32.const	2
	i32.shl 
	local.tee	15
	i32.add 
	i32.load	0
	local.get	36
	i32.ne  
	br_if   	0                               # 0: down to label260
# %bb.39:                               #   in Loop: Header=BB19_35 Depth=3
	local.get	30
	local.get	6
	local.get	28
	i32.const	1
	i32.shl 
	i32.add 
	i32.load16_u	0
	i32.ne  
	br_if   	0                               # 0: down to label260
# %bb.40:                               #   in Loop: Header=BB19_35 Depth=3
	i32.const	0
	local.set	2
	local.get	4
	local.get	7
	local.get	15
	i32.add 
	i32.load	0
	i32.add 
	local.tee	38
	local.set	15
	local.get	35
	local.set	1
.LBB19_41:                              #   Parent Loop BB19_8 Depth=1
                                        #     Parent Loop BB19_22 Depth=2
                                        #       Parent Loop BB19_35 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	loop    	                                # label261:
	block   	
	local.get	30
	local.get	2
	i32.add 
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label262
# %bb.42:                               #   in Loop: Header=BB19_35 Depth=3
	i32.const	0
	local.set	26
	local.get	30
	local.set	29
.LBB19_43:                              #   Parent Loop BB19_8 Depth=1
                                        #     Parent Loop BB19_22 Depth=2
                                        #       Parent Loop BB19_35 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	block   	
	loop    	                                # label264:
	block   	
	local.get	2
	local.get	29
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label265
# %bb.44:                               #   in Loop: Header=BB19_35 Depth=3
	local.get	26
	local.get	2
	i32.sub 
	local.tee	15
	local.get	30
	i32.lt_u
	br_if   	2                               # 2: down to label263
	br      	8                               # 8: down to label256
.LBB19_45:                              #   in Loop: Header=BB19_43 Depth=4
	end_block                               # label265:
	local.get	1
	local.get	26
	i32.add 
	local.set	31
	local.get	15
	local.get	26
	i32.add 
	local.set	24
	local.get	29
	i32.const	-8
	i32.add 
	local.set	29
	local.get	26
	i32.const	8
	i32.add 
	local.set	26
	local.get	24
	i64.load	0:p2align=0
	local.get	31
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label264
	br      	4                               # 4: down to label260
.LBB19_46:                              #   Parent Loop BB19_8 Depth=1
                                        #     Parent Loop BB19_22 Depth=2
                                        #       Parent Loop BB19_35 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	end_loop
	end_block                               # label263:
	loop    	                                # label266:
	local.get	38
	local.get	15
	i32.add 
	i32.load8_u	0
	local.get	35
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	3                               # 3: down to label260
# %bb.47:                               #   in Loop: Header=BB19_46 Depth=4
	local.get	15
	i32.const	1
	i32.add 
	local.tee	15
	local.get	30
	i32.ge_u
	br_if   	6                               # 6: down to label256
	br      	0                               # 0: up to label266
.LBB19_48:                              #   in Loop: Header=BB19_41 Depth=4
	end_loop
	end_block                               # label262:
	local.get	15
	i32.const	16
	i32.add 
	local.set	26
	local.get	1
	i32.const	16
	i32.add 
	local.set	29
	local.get	15
	v128.load	0:p2align=0
	local.set	16
	local.get	1
	v128.load	0:p2align=0
	local.set	17
	local.get	15
	i32.const	32
	i32.add 
	local.set	15
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	2
	i32.const	-32
	i32.add 
	local.set	2
	local.get	29
	v128.load	0:p2align=0
	local.get	26
	v128.load	0:p2align=0
	v128.xor
	local.get	17
	local.get	16
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label261
.LBB19_49:                              #   in Loop: Header=BB19_35 Depth=3
	end_loop
	end_block                               # label260:
	local.get	27
	i32.const	1
	i32.add 
	local.get	18
	i32.and 
	local.set	27
	local.get	37
	i32.const	1
	i32.add 
	local.tee	37
	local.get	12
	i32.ne  
	br_if   	0                               # 0: up to label258
.LBB19_50:                              #   in Loop: Header=BB19_22 Depth=2
	end_loop
	end_block                               # label257:
	i32.const	-2
	local.set	15
	local.get	20
	local.get	21
	i32.ge_u
	br_if   	5                               # 5: down to label239
# %bb.51:                               #   in Loop: Header=BB19_22 Depth=2
	local.get	11
	local.get	27
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	38
	i32.load	0
	br_if   	5                               # 5: down to label239
# %bb.52:                               #   in Loop: Header=BB19_22 Depth=2
	local.get	30
	local.get	19
	i32.add 
	local.tee	39
	local.get	5
	i32.gt_u
	br_if   	5                               # 5: down to label239
# %bb.53:                               #   in Loop: Header=BB19_22 Depth=2
	block   	
	local.get	34
	local.get	4
	i32.eq  
	br_if   	0                               # 0: down to label267
# %bb.54:                               #   in Loop: Header=BB19_22 Depth=2
	local.get	30
	i32.eqz
	br_if   	0                               # 0: down to label267
# %bb.55:                               #   in Loop: Header=BB19_22 Depth=2
	local.get	4
	local.get	19
	i32.add 
	local.set	29
	i32.const	0
	local.set	1
.LBB19_56:                              #   Parent Loop BB19_8 Depth=1
                                        #     Parent Loop BB19_22 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label268:
	local.get	29
	local.get	1
	i32.add 
	local.get	35
	local.get	1
	i32.add 
	i32.load8_s	0
	local.tee	2
	i32.store8	0
	local.get	1
	i32.const	1
	i32.add 
	local.set	26
	block   	
	block   	
	local.get	2
	i32.const	-1
	i32.le_s
	br_if   	0                               # 0: down to label270
# %bb.57:                               #   in Loop: Header=BB19_56 Depth=3
	local.get	26
	local.set	1
	br      	1                               # 1: down to label269
.LBB19_58:                              #   in Loop: Header=BB19_56 Depth=3
	end_block                               # label270:
	i32.const	0
	local.set	37
	block   	
	block   	
	local.get	2
	i32.const	62
	i32.add 
	i32.const	255
	i32.and 
	i32.const	30
	i32.lt_u
	local.tee	27
	i32.eqz
	br_if   	0                               # 0: down to label272
# %bb.59:                               #   in Loop: Header=BB19_56 Depth=3
	i32.const	1
	local.set	24
	br      	1                               # 1: down to label271
.LBB19_60:                              #   in Loop: Header=BB19_56 Depth=3
	end_block                               # label272:
	block   	
	local.get	2
	i32.const	-16
	i32.and 
	i32.const	-32
	i32.ne  
	br_if   	0                               # 0: down to label273
# %bb.61:                               #   in Loop: Header=BB19_56 Depth=3
	i32.const	2
	local.set	24
	i32.const	1
	local.set	37
	br      	1                               # 1: down to label271
.LBB19_62:                              #   in Loop: Header=BB19_56 Depth=3
	end_block                               # label273:
	block   	
	local.get	2
	i32.const	16
	i32.add 
	i32.const	255
	i32.and 
	i32.const	4
	i32.le_u
	br_if   	0                               # 0: down to label274
# %bb.63:
	i32.const	-4
	local.set	15
	br      	10                              # 10: down to label239
.LBB19_64:                              #   in Loop: Header=BB19_56 Depth=3
	end_block                               # label274:
	i32.const	3
	local.set	24
.LBB19_65:                              #   in Loop: Header=BB19_56 Depth=3
	end_block                               # label271:
	i32.const	-4
	local.set	15
	local.get	24
	local.get	30
	local.get	26
	i32.sub 
	i32.gt_u
	br_if   	8                               # 8: down to label239
# %bb.66:                               #   in Loop: Header=BB19_56 Depth=3
	local.get	35
	local.get	26
	i32.add 
	local.tee	28
	i32.load8_u	0
	local.set	31
	block   	
	local.get	2
	i32.const	-32
	i32.ne  
	br_if   	0                               # 0: down to label275
# %bb.67:                               #   in Loop: Header=BB19_56 Depth=3
	local.get	31
	i32.const	255
	i32.and 
	i32.const	160
	i32.lt_u
	br_if   	9                               # 9: down to label239
.LBB19_68:                              #   in Loop: Header=BB19_56 Depth=3
	end_block                               # label275:
	block   	
	local.get	2
	i32.const	-19
	i32.ne  
	br_if   	0                               # 0: down to label276
# %bb.69:                               #   in Loop: Header=BB19_56 Depth=3
	local.get	31
	i32.const	255
	i32.and 
	i32.const	159
	i32.gt_u
	br_if   	9                               # 9: down to label239
.LBB19_70:                              #   in Loop: Header=BB19_56 Depth=3
	end_block                               # label276:
	block   	
	local.get	2
	i32.const	-16
	i32.ne  
	br_if   	0                               # 0: down to label277
# %bb.71:                               #   in Loop: Header=BB19_56 Depth=3
	local.get	31
	i32.const	255
	i32.and 
	i32.const	144
	i32.lt_u
	br_if   	9                               # 9: down to label239
.LBB19_72:                              #   in Loop: Header=BB19_56 Depth=3
	end_block                               # label277:
	block   	
	local.get	2
	i32.const	-12
	i32.ne  
	br_if   	0                               # 0: down to label278
# %bb.73:                               #   in Loop: Header=BB19_56 Depth=3
	local.get	31
	i32.const	255
	i32.and 
	i32.const	143
	i32.gt_u
	br_if   	9                               # 9: down to label239
.LBB19_74:                              #   in Loop: Header=BB19_56 Depth=3
	end_block                               # label278:
	local.get	28
	i32.load8_s	0
	local.tee	2
	i32.const	-65
	i32.gt_s
	br_if   	8                               # 8: down to label239
# %bb.75:                               #   in Loop: Header=BB19_56 Depth=3
	local.get	29
	local.get	26
	i32.add 
	local.get	2
	i32.store8	0
	block   	
	local.get	27
	br_if   	0                               # 0: down to label279
# %bb.76:                               #   in Loop: Header=BB19_56 Depth=3
	local.get	35
	local.get	1
	i32.const	2
	i32.add 
	local.tee	2
	i32.add 
	i32.load8_s	0
	local.tee	31
	i32.const	-65
	i32.gt_s
	br_if   	9                               # 9: down to label239
# %bb.77:                               #   in Loop: Header=BB19_56 Depth=3
	local.get	29
	local.get	2
	i32.add 
	local.get	31
	i32.store8	0
	local.get	37
	br_if   	0                               # 0: down to label279
# %bb.78:                               #   in Loop: Header=BB19_56 Depth=3
	local.get	35
	local.get	1
	i32.const	3
	i32.add 
	local.tee	1
	i32.add 
	i32.load8_s	0
	local.tee	2
	i32.const	-65
	i32.gt_s
	br_if   	9                               # 9: down to label239
# %bb.79:                               #   in Loop: Header=BB19_56 Depth=3
	local.get	29
	local.get	1
	i32.add 
	local.get	2
	i32.store8	0
.LBB19_80:                              #   in Loop: Header=BB19_56 Depth=3
	end_block                               # label279:
	local.get	24
	local.get	26
	i32.add 
	local.set	1
.LBB19_81:                              #   in Loop: Header=BB19_56 Depth=3
	end_block                               # label269:
	local.get	1
	local.get	30
	i32.lt_u
	br_if   	0                               # 0: up to label268
.LBB19_82:                              #   in Loop: Header=BB19_22 Depth=2
	end_loop
	end_block                               # label267:
	local.get	7
	local.get	20
	i32.const	2
	i32.shl 
	local.tee	15
	i32.add 
	local.get	19
	i32.store	0
	local.get	8
	local.get	15
	i32.add 
	local.get	36
	i32.store	0
	local.get	6
	local.get	20
	i32.const	1
	i32.shl 
	i32.add 
	local.get	30
	i32.store16	0
	local.get	38
	local.get	20
	i32.const	1
	i32.add 
	local.tee	15
	i32.store	0
	local.get	20
	local.set	28
	local.get	39
	local.set	19
	local.get	15
	local.set	20
.LBB19_83:                              #   in Loop: Header=BB19_22 Depth=2
	end_block                               # label256:
	local.get	32
	local.get	28
	i32.store	0
	i32.const	1
	local.set	15
	local.get	33
	i32.const	1
	i32.and 
	local.set	2
	local.get	14
	i32.const	24
	i32.add 
	local.set	1
	local.get	14
	i32.const	16
	i32.add 
	local.set	26
	local.get	14
	i32.const	4
	i32.add 
	local.set	32
	i32.const	0
	local.set	33
	local.get	2
	br_if   	0                               # 0: up to label250
.LBB19_84:                              #   in Loop: Header=BB19_8 Depth=1
	end_loop
	end_block                               # label249:
	local.get	9
	local.get	23
	i32.const	2
	i32.shl 
	local.tee	15
	i32.add 
	local.get	14
	i32.load	8
	i32.store	0
	local.get	10
	local.get	15
	i32.add 
	local.get	14
	i32.load	4
	i32.store	0
	local.get	23
	i32.const	1
	i32.add 
	local.tee	23
	local.get	3
	i32.ne  
	br_if   	0                               # 0: up to label242
.LBB19_85:
	end_loop
	end_block                               # label240:
	local.get	13
	local.get	20
	i32.store	0
	local.get	19
	local.set	15
.LBB19_86:
	end_block                               # label239:
	local.get	14
	i32.const	32
	i32.add 
	global.set	__stack_pointer
	local.get	15
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.content_bytes_equal,"",@
	.type	content_bytes_equal,@function   # -- Begin function content_bytes_equal
content_bytes_equal:                    # @content_bytes_equal
	.functype	content_bytes_equal (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32
# %bb.0:
	local.get	0
	local.get	2
	i32.add 
	local.set	4
	local.get	0
	local.get	1
	i32.add 
	local.set	5
	i32.const	0
	local.set	0
.LBB20_1:                               # =>This Inner Loop Header: Depth=1
	block   	
	block   	
	block   	
	loop    	                                # label283:
	block   	
	local.get	0
	i32.const	8
	i32.add 
	local.tee	2
	local.get	3
	i32.le_u
	br_if   	0                               # 0: down to label284
# %bb.2:
	block   	
	local.get	3
	local.get	0
	i32.gt_u
	br_if   	0                               # 0: down to label285
# %bb.3:
	i32.const	1
	return
.LBB20_4:
	end_block                               # label285:
	local.get	3
	local.get	0
	i32.sub 
	local.set	1
	local.get	5
	local.get	0
	i32.add 
	local.set	2
	local.get	4
	local.get	0
	i32.add 
	local.set	0
	br      	2                               # 2: down to label282
.LBB20_5:                               #   in Loop: Header=BB20_1 Depth=1
	end_block                               # label284:
	local.get	4
	local.get	0
	i32.add 
	local.set	1
	local.get	5
	local.get	0
	i32.add 
	local.set	6
	local.get	2
	local.set	0
	local.get	6
	i64.load	0:p2align=0
	local.get	1
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label283
	br      	2                               # 2: down to label281
.LBB20_6:                               # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label282:
	loop    	                                # label286:
	local.get	2
	i32.load8_u	0
	local.get	0
	i32.load8_u	0
	i32.ne  
	br_if   	1                               # 1: down to label281
# %bb.7:                                #   in Loop: Header=BB20_6 Depth=1
	i32.const	1
	local.set	6
	local.get	0
	i32.const	1
	i32.add 
	local.set	0
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	local.get	1
	i32.const	-1
	i32.add 
	local.tee	1
	i32.eqz
	br_if   	2                               # 2: down to label280
	br      	0                               # 0: up to label286
.LBB20_8:
	end_loop
	end_block                               # label281:
	i32.const	0
	local.set	6
.LBB20_9:
	end_block                               # label280:
	local.get	6
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.decode_escaped_key,"",@
	.type	decode_escaped_key,@function    # -- Begin function decode_escaped_key
decode_escaped_key:                     # @decode_escaped_key
	.functype	decode_escaped_key (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-1
	local.set	4
	block   	
	local.get	1
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label287
# %bb.1:
	local.get	0
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label287
# %bb.2:
	i32.const	-1
	local.set	4
	local.get	0
	local.get	1
	i32.const	-1
	i32.add 
	local.tee	5
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label287
# %bb.3:
	i32.const	0
	local.set	4
	local.get	5
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label287
# %bb.4:
	local.get	3
	i32.const	65535
	local.get	3
	i32.const	65535
	i32.lt_u
	i32.select
	local.set	6
	local.get	0
	i32.const	3
	i32.add 
	local.set	7
	local.get	0
	i32.const	2
	i32.add 
	local.set	8
	local.get	2
	i32.const	1
	i32.add 
	local.set	9
	i32.const	0
	local.set	4
	i32.const	1
	local.set	1
.LBB21_5:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB21_86 Depth 2
	loop    	                                # label288:
	local.get	4
	local.set	10
	local.get	1
	i32.const	1
	i32.add 
	local.set	11
	block   	
	block   	
	local.get	0
	local.get	1
	i32.add 
	local.tee	12
	i32.load8_u	0
	local.tee	3
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label290
# %bb.6:                                #   in Loop: Header=BB21_5 Depth=1
	i32.const	-1
	local.set	4
	local.get	3
	i32.const	32
	i32.lt_u
	br_if   	3                               # 3: down to label287
# %bb.7:                                #   in Loop: Header=BB21_5 Depth=1
	local.get	3
	i32.const	34
	i32.eq  
	br_if   	3                               # 3: down to label287
# %bb.8:                                #   in Loop: Header=BB21_5 Depth=1
	block   	
	block   	
	block   	
	local.get	3
	i32.extend8_s
	i32.const	-1
	i32.gt_s
	br_if   	0                               # 0: down to label293
# %bb.9:                                #   in Loop: Header=BB21_5 Depth=1
	i32.const	0
	local.set	13
	block   	
	block   	
	local.get	3
	i32.const	62
	i32.add 
	i32.const	255
	i32.and 
	i32.const	30
	i32.lt_u
	local.tee	14
	i32.eqz
	br_if   	0                               # 0: down to label295
# %bb.10:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	2
	local.set	15
	br      	1                               # 1: down to label294
.LBB21_11:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label295:
	block   	
	local.get	3
	i32.const	240
	i32.and 
	i32.const	224
	i32.ne  
	br_if   	0                               # 0: down to label296
# %bb.12:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	3
	local.set	15
	i32.const	1
	local.set	13
	br      	1                               # 1: down to label294
.LBB21_13:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label296:
	i32.const	4
	local.set	15
	local.get	3
	i32.const	16
	i32.add 
	i32.const	255
	i32.and 
	i32.const	4
	i32.gt_u
	br_if   	7                               # 7: down to label287
.LBB21_14:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label294:
	i32.const	-1
	local.set	4
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	12
	local.get	5
	local.get	11
	i32.sub 
	i32.gt_u
	br_if   	6                               # 6: down to label287
# %bb.15:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	0
	local.get	11
	i32.add 
	local.tee	11
	i32.load8_u	0
	local.set	16
	block   	
	local.get	3
	i32.const	224
	i32.ne  
	br_if   	0                               # 0: down to label297
# %bb.16:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	16
	i32.const	255
	i32.and 
	i32.const	160
	i32.lt_u
	br_if   	7                               # 7: down to label287
.LBB21_17:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label297:
	block   	
	local.get	3
	i32.const	237
	i32.ne  
	br_if   	0                               # 0: down to label298
# %bb.18:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	16
	i32.const	255
	i32.and 
	i32.const	159
	i32.gt_u
	br_if   	7                               # 7: down to label287
.LBB21_19:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label298:
	block   	
	local.get	3
	i32.const	240
	i32.ne  
	br_if   	0                               # 0: down to label299
# %bb.20:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	16
	i32.const	255
	i32.and 
	i32.const	144
	i32.lt_u
	br_if   	7                               # 7: down to label287
.LBB21_21:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label299:
	block   	
	local.get	3
	i32.const	244
	i32.ne  
	br_if   	0                               # 0: down to label300
# %bb.22:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	16
	i32.const	255
	i32.and 
	i32.const	143
	i32.gt_u
	br_if   	7                               # 7: down to label287
.LBB21_23:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label300:
	local.get	11
	i32.load8_s	0
	i32.const	-64
	i32.ge_s
	br_if   	6                               # 6: down to label287
# %bb.24:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	12
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label292
# %bb.25:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	11
	i32.const	1
	i32.add 
	i32.load8_s	0
	i32.const	-65
	i32.gt_s
	br_if   	6                               # 6: down to label287
# %bb.26:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	12
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label292
# %bb.27:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	11
	i32.const	2
	i32.add 
	i32.load8_s	0
	i32.const	-65
	i32.gt_s
	br_if   	6                               # 6: down to label287
# %bb.28:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	15
	local.get	6
	local.get	10
	i32.sub 
	i32.le_u
	br_if   	2                               # 2: down to label291
	br      	6                               # 6: down to label287
.LBB21_29:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label293:
	local.get	6
	local.get	10
	i32.eq  
	br_if   	5                               # 5: down to label287
# %bb.30:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	2
	local.get	10
	i32.add 
	local.get	3
	i32.store8	0
	local.get	10
	i32.const	1
	i32.add 
	local.set	4
	local.get	11
	local.set	1
	br      	3                               # 3: down to label289
.LBB21_31:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label292:
	local.get	15
	local.get	6
	local.get	10
	i32.sub 
	i32.gt_u
	br_if   	4                               # 4: down to label287
.LBB21_32:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label291:
	local.get	2
	local.get	10
	i32.add 
	local.get	3
	i32.store8	0
	local.get	9
	local.get	10
	i32.add 
	local.get	11
	i32.load8_u	0
	i32.store8	0
	local.get	10
	i32.const	2
	i32.add 
	local.set	4
	local.get	15
	local.get	1
	i32.add 
	local.set	3
	block   	
	local.get	14
	i32.eqz
	br_if   	0                               # 0: down to label301
# %bb.33:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	3
	local.set	1
	br      	2                               # 2: down to label289
.LBB21_34:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label301:
	local.get	2
	local.get	4
	i32.add 
	local.get	8
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.store8	0
	local.get	10
	i32.const	3
	i32.add 
	local.set	4
	block   	
	local.get	13
	i32.eqz
	br_if   	0                               # 0: down to label302
# %bb.35:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	3
	local.set	1
	br      	2                               # 2: down to label289
.LBB21_36:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label302:
	local.get	2
	local.get	4
	i32.add 
	local.get	7
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.store8	0
	local.get	10
	i32.const	4
	i32.add 
	local.set	4
	local.get	3
	local.set	1
	br      	1                               # 1: down to label289
.LBB21_37:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label290:
	i32.const	-1
	local.set	4
	local.get	5
	local.get	11
	i32.le_u
	br_if   	2                               # 2: down to label287
# %bb.38:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	1
	i32.const	2
	i32.add 
	local.set	16
	i32.const	1
	local.set	15
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	-34
	i32.add 
	br_table 	{6, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 6, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 6, 9, 9, 9, 9, 9, 0, 9, 9, 9, 1, 9, 9, 9, 9, 9, 9, 9, 2, 9, 9, 9, 3, 9, 4, 5, 9} # 9: down to label287
                                        # 6: down to label303
                                        # 0: down to label309
                                        # 1: down to label308
                                        # 2: down to label307
                                        # 3: down to label306
                                        # 4: down to label305
                                        # 5: down to label304
.LBB21_39:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label309:
	i32.const	8
	local.set	11
	br      	5                               # 5: down to label303
.LBB21_40:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label308:
	i32.const	12
	local.set	11
	br      	4                               # 4: down to label303
.LBB21_41:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label307:
	i32.const	10
	local.set	11
	br      	3                               # 3: down to label303
.LBB21_42:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label306:
	i32.const	13
	local.set	11
	br      	2                               # 2: down to label303
.LBB21_43:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label305:
	i32.const	9
	local.set	11
	br      	1                               # 1: down to label303
.LBB21_44:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label304:
	local.get	5
	local.get	16
	i32.sub 
	i32.const	4
	i32.lt_u
	br_if   	3                               # 3: down to label287
# %bb.45:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	-48
	local.set	17
	i32.const	-48
	local.set	13
	block   	
	local.get	0
	local.get	16
	i32.add 
	local.tee	3
	i32.load8_u	0
	local.tee	11
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label310
# %bb.46:                               #   in Loop: Header=BB21_5 Depth=1
	block   	
	local.get	11
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label311
# %bb.47:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	-87
	local.set	13
	br      	1                               # 1: down to label310
.LBB21_48:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label311:
	local.get	11
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.gt_u
	br_if   	4                               # 4: down to label287
# %bb.49:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	-55
	local.set	13
.LBB21_50:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label310:
	block   	
	local.get	3
	i32.load8_u	1
	local.tee	16
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label312
# %bb.51:                               #   in Loop: Header=BB21_5 Depth=1
	block   	
	local.get	16
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label313
# %bb.52:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	-87
	local.set	17
	br      	1                               # 1: down to label312
.LBB21_53:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label313:
	local.get	16
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.gt_u
	br_if   	4                               # 4: down to label287
# %bb.54:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	-55
	local.set	17
.LBB21_55:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label312:
	i32.const	-48
	local.set	18
	i32.const	-48
	local.set	19
	block   	
	local.get	3
	i32.load8_u	2
	local.tee	14
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label314
# %bb.56:                               #   in Loop: Header=BB21_5 Depth=1
	block   	
	local.get	14
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label315
# %bb.57:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	-87
	local.set	19
	br      	1                               # 1: down to label314
.LBB21_58:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label315:
	local.get	14
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.gt_u
	br_if   	4                               # 4: down to label287
# %bb.59:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	-55
	local.set	19
.LBB21_60:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label314:
	block   	
	local.get	3
	i32.load8_u	3
	local.tee	3
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label316
# %bb.61:                               #   in Loop: Header=BB21_5 Depth=1
	block   	
	local.get	3
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label317
# %bb.62:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	-87
	local.set	18
	br      	1                               # 1: down to label316
.LBB21_63:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label317:
	local.get	3
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.gt_u
	br_if   	4                               # 4: down to label287
# %bb.64:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	-55
	local.set	18
.LBB21_65:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label316:
	i32.const	-1
	local.set	4
	local.get	18
	local.get	3
	i32.add 
	local.get	17
	local.get	16
	i32.add 
	i32.const	4
	i32.shl 
	local.get	13
	local.get	11
	i32.add 
	i32.const	8
	i32.shl 
	i32.or  
	local.get	19
	local.get	14
	i32.add 
	i32.or  
	i32.const	4
	i32.shl 
	i32.or  
	local.tee	3
	i32.const	-1
	i32.eq  
	br_if   	3                               # 3: down to label287
# %bb.66:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	1
	i32.const	6
	i32.add 
	local.set	16
	i32.const	65533
	local.set	11
	block   	
	local.get	3
	i32.const	-1024
	i32.and 
	local.tee	4
	i32.const	56320
	i32.ne  
	br_if   	0                               # 0: down to label318
# %bb.67:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	3
	local.set	15
	br      	1                               # 1: down to label303
.LBB21_68:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label318:
	block   	
	local.get	4
	i32.const	55296
	i32.ne  
	br_if   	0                               # 0: down to label319
# %bb.69:                               #   in Loop: Header=BB21_5 Depth=1
	block   	
	local.get	5
	local.get	16
	i32.sub 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label320
# %bb.70:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	3
	local.set	15
	br      	2                               # 2: down to label303
.LBB21_71:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label320:
	block   	
	local.get	0
	local.get	16
	i32.add 
	local.tee	4
	i32.load8_u	0
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label321
# %bb.72:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	3
	local.set	15
	br      	2                               # 2: down to label303
.LBB21_73:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label321:
	block   	
	local.get	12
	i32.const	7
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.eq  
	br_if   	0                               # 0: down to label322
# %bb.74:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	3
	local.set	15
	br      	2                               # 2: down to label303
.LBB21_75:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label322:
	i32.const	3
	local.set	15
	local.get	4
	i32.const	2
	i32.add 
	call	key_hex4
	local.tee	4
	i32.const	-1024
	i32.and 
	i32.const	56320
	i32.ne  
	br_if   	1                               # 1: down to label303
# %bb.76:                               #   in Loop: Header=BB21_5 Depth=1
	local.get	1
	i32.const	12
	i32.add 
	local.set	16
	local.get	3
	i32.const	10
	i32.shl 
	local.get	4
	i32.add 
	i32.const	-56613888
	i32.add 
	local.set	11
	i32.const	4
	local.set	15
	br      	1                               # 1: down to label303
.LBB21_77:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label319:
	block   	
	local.get	3
	i32.const	128
	i32.lt_u
	br_if   	0                               # 0: down to label323
# %bb.78:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	2
	local.set	15
	local.get	3
	i32.const	2048
	i32.lt_u
	br_if   	0                               # 0: down to label323
# %bb.79:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	3
	i32.const	4
	local.get	3
	i32.const	65536
	i32.lt_u
	i32.select
	local.set	15
.LBB21_80:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label323:
	local.get	3
	local.set	11
.LBB21_81:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label303:
	i32.const	-1
	local.set	4
	local.get	15
	local.get	6
	local.get	10
	i32.sub 
	i32.gt_u
	br_if   	2                               # 2: down to label287
# %bb.82:                               #   in Loop: Header=BB21_5 Depth=1
	i32.const	192
	local.set	4
	block   	
	block   	
	block   	
	block   	
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	3
	br_table 	{0, 2, 1}               # 2: down to label325
                                        # 1: down to label326
.LBB21_83:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label327:
	local.get	2
	local.get	10
	i32.add 
	local.get	11
	i32.store8	0
	local.get	10
	i32.const	1
	i32.add 
	local.set	4
	br      	2                               # 2: down to label324
.LBB21_84:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label326:
	i32.const	224
	i32.const	240
	local.get	15
	i32.const	3
	i32.eq  
	i32.select
	local.set	4
.LBB21_85:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label325:
	local.get	2
	local.get	10
	i32.add 
	local.get	4
	local.get	11
	local.get	15
	i32.const	6
	i32.mul 
	local.tee	1
	i32.const	-6
	i32.add 
	i32.shr_u
	i32.or  
	i32.store8	0
	local.get	10
	i32.const	1
	i32.add 
	local.set	4
	local.get	1
	i32.const	-12
	i32.add 
	local.set	1
.LBB21_86:                              #   Parent Loop BB21_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label328:
	local.get	2
	local.get	4
	i32.add 
	local.get	11
	local.get	1
	i32.shr_u
	i32.const	63
	i32.and 
	i32.const	128
	i32.or  
	i32.store8	0
	local.get	1
	i32.const	-6
	i32.add 
	local.set	1
	local.get	4
	i32.const	1
	i32.add 
	local.set	4
	local.get	3
	i32.const	-1
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label328
.LBB21_87:                              #   in Loop: Header=BB21_5 Depth=1
	end_loop
	end_block                               # label324:
	local.get	16
	local.set	1
.LBB21_88:                              #   in Loop: Header=BB21_5 Depth=1
	end_block                               # label289:
	local.get	1
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: up to label288
.LBB21_89:
	end_loop
	end_block                               # label287:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.hash_content_xxh32,"",@
	.type	hash_content_xxh32,@function    # -- Begin function hash_content_xxh32
hash_content_xxh32:                     # @hash_content_xxh32
	.functype	hash_content_xxh32 (i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32
# %bb.0:
	local.get	0
	local.get	1
	i32.add 
	local.set	3
	block   	
	block   	
	local.get	1
	i32.const	16
	i32.lt_u
	br_if   	0                               # 0: down to label330
# %bb.1:
	local.get	2
	i32.const	1640531535
	i32.add 
	local.set	4
	local.get	2
	i32.const	-2048144777
	i32.add 
	local.set	5
	local.get	2
	i32.const	606290984
	i32.add 
	local.set	6
	local.get	3
	i32.const	-16
	i32.add 
	local.set	7
.LBB22_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label331:
	local.get	0
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.get	6
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	6
	local.get	0
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.get	4
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	4
	local.get	0
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.get	2
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	2
	local.get	0
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.get	5
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	5
	local.get	0
	i32.const	16
	i32.add 
	local.tee	0
	local.get	7
	i32.le_u
	br_if   	0                               # 0: up to label331
# %bb.3:
	end_loop
	local.get	5
	i32.const	7
	i32.rotl
	local.get	6
	i32.const	1
	i32.rotl
	i32.add 
	local.get	2
	i32.const	12
	i32.rotl
	i32.add 
	local.get	4
	i32.const	18
	i32.rotl
	i32.add 
	local.set	2
	br      	1                               # 1: down to label329
.LBB22_4:
	end_block                               # label330:
	local.get	2
	i32.const	374761393
	i32.add 
	local.set	2
.LBB22_5:
	end_block                               # label329:
	local.get	2
	local.get	1
	i32.add 
	local.set	2
	block   	
	block   	
	local.get	0
	i32.const	4
	i32.add 
	local.get	3
	i32.le_u
	br_if   	0                               # 0: down to label333
# %bb.6:
	local.get	0
	local.set	4
	br      	1                               # 1: down to label332
.LBB22_7:
	end_block                               # label333:
.LBB22_8:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label334:
	local.get	0
	i32.load	0:p2align=0
	i32.const	-1028477379
	i32.mul 
	local.get	2
	i32.add 
	i32.const	17
	i32.rotl
	i32.const	668265263
	i32.mul 
	local.set	2
	local.get	0
	i32.const	8
	i32.add 
	local.set	5
	local.get	0
	i32.const	4
	i32.add 
	local.tee	4
	local.set	0
	local.get	5
	local.get	3
	i32.le_u
	br_if   	0                               # 0: up to label334
.LBB22_9:
	end_loop
	end_block                               # label332:
	block   	
	local.get	4
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label335
# %bb.10:
	local.get	4
	i32.const	1
	i32.add 
	local.set	0
	block   	
	local.get	3
	local.get	4
	i32.sub 
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label336
# %bb.11:
	local.get	4
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.get	2
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	2
	local.get	0
	local.set	4
.LBB22_12:
	end_block                               # label336:
	local.get	3
	local.get	0
	i32.eq  
	br_if   	0                               # 0: down to label335
# %bb.13:
.LBB22_14:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label337:
	local.get	4
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.get	4
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.get	2
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	2
	local.get	4
	i32.const	2
	i32.add 
	local.tee	4
	local.get	3
	i32.ne  
	br_if   	0                               # 0: up to label337
.LBB22_15:
	end_loop
	end_block                               # label335:
	local.get	2
	i32.const	15
	i32.shr_u
	local.get	2
	i32.xor 
	i32.const	-2048144777
	i32.mul 
	local.tee	0
	i32.const	13
	i32.shr_u
	local.get	0
	i32.xor 
	i32.const	-1028477379
	i32.mul 
	local.tee	0
	i32.const	16
	i32.shr_u
	local.get	0
	i32.xor 
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.copy_valid_utf8,"",@
	.type	copy_valid_utf8,@function       # -- Begin function copy_valid_utf8
copy_valid_utf8:                        # @copy_valid_utf8
	.functype	copy_valid_utf8 (i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	block   	
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label339
# %bb.1:
	i32.const	0
	local.set	3
.LBB23_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label340:
	local.get	0
	local.get	3
	i32.add 
	local.get	1
	local.get	3
	i32.add 
	i32.load8_s	0
	local.tee	4
	i32.store8	0
	local.get	3
	i32.const	1
	i32.add 
	local.set	5
	block   	
	block   	
	local.get	4
	i32.const	-1
	i32.le_s
	br_if   	0                               # 0: down to label342
# %bb.3:                                #   in Loop: Header=BB23_2 Depth=1
	local.get	5
	local.set	3
	br      	1                               # 1: down to label341
.LBB23_4:                               #   in Loop: Header=BB23_2 Depth=1
	end_block                               # label342:
	i32.const	0
	local.set	6
	block   	
	block   	
	local.get	4
	i32.const	62
	i32.add 
	i32.const	255
	i32.and 
	i32.const	30
	i32.lt_u
	local.tee	7
	i32.eqz
	br_if   	0                               # 0: down to label344
# %bb.5:                                #   in Loop: Header=BB23_2 Depth=1
	i32.const	1
	local.set	8
	i32.const	0
	local.set	9
	br      	1                               # 1: down to label343
.LBB23_6:                               #   in Loop: Header=BB23_2 Depth=1
	end_block                               # label344:
	block   	
	local.get	4
	i32.const	-16
	i32.and 
	i32.const	-32
	i32.ne  
	br_if   	0                               # 0: down to label345
# %bb.7:                                #   in Loop: Header=BB23_2 Depth=1
	i32.const	2
	local.set	8
	i32.const	1
	local.set	9
	br      	1                               # 1: down to label343
.LBB23_8:                               #   in Loop: Header=BB23_2 Depth=1
	end_block                               # label345:
	i32.const	0
	local.set	9
	block   	
	local.get	4
	i32.const	16
	i32.add 
	i32.const	255
	i32.and 
	i32.const	4
	i32.le_u
	br_if   	0                               # 0: down to label346
# %bb.9:
	i32.const	0
	return
.LBB23_10:                              #   in Loop: Header=BB23_2 Depth=1
	end_block                               # label346:
	i32.const	3
	local.set	8
.LBB23_11:                              #   in Loop: Header=BB23_2 Depth=1
	end_block                               # label343:
	local.get	8
	local.get	2
	local.get	5
	i32.sub 
	i32.gt_u
	br_if   	3                               # 3: down to label338
# %bb.12:                               #   in Loop: Header=BB23_2 Depth=1
	local.get	1
	local.get	5
	i32.add 
	local.tee	10
	i32.load8_u	0
	local.set	11
	block   	
	local.get	4
	i32.const	-32
	i32.ne  
	br_if   	0                               # 0: down to label347
# %bb.13:                               #   in Loop: Header=BB23_2 Depth=1
	local.get	11
	i32.const	255
	i32.and 
	i32.const	160
	i32.lt_u
	br_if   	4                               # 4: down to label338
.LBB23_14:                              #   in Loop: Header=BB23_2 Depth=1
	end_block                               # label347:
	block   	
	local.get	4
	i32.const	-19
	i32.ne  
	br_if   	0                               # 0: down to label348
# %bb.15:                               #   in Loop: Header=BB23_2 Depth=1
	local.get	11
	i32.const	255
	i32.and 
	i32.const	159
	i32.gt_u
	br_if   	4                               # 4: down to label338
.LBB23_16:                              #   in Loop: Header=BB23_2 Depth=1
	end_block                               # label348:
	block   	
	local.get	4
	i32.const	-16
	i32.ne  
	br_if   	0                               # 0: down to label349
# %bb.17:                               #   in Loop: Header=BB23_2 Depth=1
	local.get	11
	i32.const	255
	i32.and 
	i32.const	144
	i32.lt_u
	br_if   	4                               # 4: down to label338
.LBB23_18:                              #   in Loop: Header=BB23_2 Depth=1
	end_block                               # label349:
	block   	
	local.get	4
	i32.const	-12
	i32.ne  
	br_if   	0                               # 0: down to label350
# %bb.19:                               #   in Loop: Header=BB23_2 Depth=1
	local.get	11
	i32.const	255
	i32.and 
	i32.const	143
	i32.gt_u
	br_if   	4                               # 4: down to label338
.LBB23_20:                              #   in Loop: Header=BB23_2 Depth=1
	end_block                               # label350:
	local.get	10
	i32.load8_s	0
	local.tee	4
	i32.const	-65
	i32.gt_s
	br_if   	3                               # 3: down to label338
# %bb.21:                               #   in Loop: Header=BB23_2 Depth=1
	local.get	0
	local.get	5
	i32.add 
	local.get	4
	i32.store8	0
	block   	
	local.get	7
	br_if   	0                               # 0: down to label351
# %bb.22:                               #   in Loop: Header=BB23_2 Depth=1
	local.get	1
	local.get	3
	i32.const	2
	i32.add 
	local.tee	4
	i32.add 
	i32.load8_s	0
	local.tee	11
	i32.const	-65
	i32.gt_s
	br_if   	4                               # 4: down to label338
# %bb.23:                               #   in Loop: Header=BB23_2 Depth=1
	local.get	0
	local.get	4
	i32.add 
	local.get	11
	i32.store8	0
	local.get	9
	br_if   	0                               # 0: down to label351
# %bb.24:                               #   in Loop: Header=BB23_2 Depth=1
	local.get	1
	local.get	3
	i32.const	3
	i32.add 
	local.tee	3
	i32.add 
	i32.load8_s	0
	local.tee	4
	i32.const	-65
	i32.gt_s
	br_if   	4                               # 4: down to label338
# %bb.25:                               #   in Loop: Header=BB23_2 Depth=1
	local.get	0
	local.get	3
	i32.add 
	local.get	4
	i32.store8	0
.LBB23_26:                              #   in Loop: Header=BB23_2 Depth=1
	end_block                               # label351:
	local.get	8
	local.get	5
	i32.add 
	local.set	3
.LBB23_27:                              #   in Loop: Header=BB23_2 Depth=1
	end_block                               # label341:
	local.get	3
	local.get	2
	i32.lt_u
	br_if   	0                               # 0: up to label340
.LBB23_28:
	end_loop
	end_block                               # label339:
	i32.const	1
	local.set	6
.LBB23_29:
	end_block                               # label338:
	local.get	6
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_lookup_index,"",@
	.globl	encode_term_lookup_index        # -- Begin function encode_term_lookup_index
	.type	encode_term_lookup_index,@function
encode_term_lookup_index:               # @encode_term_lookup_index
	.functype	encode_term_lookup_index (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i64, i64, i32, i32, i32, i64, i32, i32, i32, i64, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-1
	local.set	17
	block   	
	local.get	0
	i32x4.splat
	local.get	2
	i32x4.replace_lane	1
	local.get	3
	i32x4.replace_lane	2
	local.get	4
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	18
	i32x4.eq
	local.get	6
	i32x4.splat
	local.get	7
	i32x4.replace_lane	1
	local.get	8
	i32x4.replace_lane	2
	local.get	9
	i32x4.replace_lane	3
	local.get	18
	i32x4.eq
	i8x16.shuffle	0, 1, 4, 5, 8, 9, 12, 13, 16, 17, 20, 21, 24, 25, 28, 29
	local.tee	19
	local.get	11
	i32x4.splat
	local.get	13
	i32x4.replace_lane	1
	local.get	14
	i32x4.replace_lane	2
	local.get	15
	i32x4.replace_lane	3
	local.get	18
	i32x4.eq
	local.get	18
	i8x16.shuffle	0, 1, 4, 5, 8, 9, 12, 13, 0, 1, 0, 1, 0, 1, 0, 1
	v128.or
	local.get	19
	i8x16.shuffle	0, 1, 2, 3, 4, 5, 6, 7, 24, 25, 26, 27, 28, 29, 30, 31
	v128.any_true
	br_if   	0                               # 0: down to label352
# %bb.1:
	local.get	10
	i32.const	-65535
	i32.add 
	i32.const	-65534
	i32.lt_u
	br_if   	0                               # 0: down to label352
# %bb.2:
	local.get	5
	i32.const	-65535
	i32.add 
	i32.const	-65534
	i32.lt_u
	br_if   	0                               # 0: down to label352
# %bb.3:
	local.get	16
	local.get	10
	i32.lt_u
	br_if   	0                               # 0: down to label352
# %bb.4:
	i32.const	-1
	local.set	17
	local.get	16
	local.get	16
	i32.const	-1
	i32.add 
	local.tee	20
	i32.and 
	br_if   	0                               # 0: down to label352
# %bb.5:
	i32.const	0
	local.set	21
	block   	
	local.get	16
	i32.const	1
	i32.shl 
	local.tee	16
	i32.eqz
	br_if   	0                               # 0: down to label353
# %bb.6:
	local.get	15
	i32.const	0
	local.get	16
	memory.fill	0
.LBB24_7:
	end_block                               # label353:
	i32.const	0
	local.set	22
	i32.const	0
	local.set	23
	i32.const	-1
	local.set	24
	i32.const	0
	local.set	16
	i32.const	0
	local.set	25
.LBB24_8:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB24_16 Depth 2
	loop    	                                # label354:
	local.get	23
	local.set	26
	i32.const	-2
	local.set	17
	local.get	6
	local.get	25
	i32.const	2
	i32.shl 
	local.tee	23
	i32.add 
	i32.load	0
	local.get	5
	i32.ge_u
	br_if   	1                               # 1: down to label352
# %bb.9:                                #   in Loop: Header=BB24_8 Depth=1
	local.get	8
	local.get	25
	i32.add 
	i32.load8_u	0
	local.tee	27
	i32.const	1
	i32.gt_u
	br_if   	1                               # 1: down to label352
# %bb.10:                               #   in Loop: Header=BB24_8 Depth=1
	block   	
	local.get	27
	br_if   	0                               # 0: down to label355
# %bb.11:                               #   in Loop: Header=BB24_8 Depth=1
	local.get	7
	local.get	23
	i32.add 
	i32.load	0
	local.get	5
	i32.ge_u
	br_if   	2                               # 2: down to label352
.LBB24_12:                              #   in Loop: Header=BB24_8 Depth=1
	end_block                               # label355:
	block   	
	block   	
	local.get	9
	local.get	23
	i32.add 
	i32.load	0
	local.tee	23
	i32.const	-1
	i32.gt_s
	br_if   	0                               # 0: down to label357
# %bb.13:                               #   in Loop: Header=BB24_8 Depth=1
	local.get	14
	local.get	25
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	65535
	i32.store16	0
	br      	1                               # 1: down to label356
.LBB24_14:                              #   in Loop: Header=BB24_8 Depth=1
	end_block                               # label357:
	block   	
	local.get	23
	local.get	24
	i32.eq  
	br_if   	0                               # 0: down to label358
# %bb.15:                               #   in Loop: Header=BB24_8 Depth=1
	local.get	15
	local.get	23
	i32.const	255
	i32.and 
	i32.const	-2128831035
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	23
	i32.const	8
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	23
	i32.const	16
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	23
	i32.const	24
	i32.shr_u
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	20
	i32.and 
	local.tee	24
	i32.const	1
	i32.shl 
	i32.add 
	local.set	16
.LBB24_16:                              #   Parent Loop BB24_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label359:
	block   	
	local.get	16
	i32.load16_u	0
	local.tee	17
	br_if   	0                               # 0: down to label360
# %bb.17:                               #   in Loop: Header=BB24_8 Depth=1
	block   	
	local.get	21
	i32.const	65534
	i32.le_u
	br_if   	0                               # 0: down to label361
# %bb.18:
	i32.const	-3
	return
.LBB24_19:                              #   in Loop: Header=BB24_8 Depth=1
	end_block                               # label361:
	local.get	16
	local.get	21
	i32.const	1
	i32.add 
	local.tee	17
	i32.store16	0
	local.get	13
	local.get	21
	i32.const	2
	i32.shl 
	i32.add 
	local.get	23
	i32.store	0
	local.get	21
	local.set	16
	local.get	23
	local.set	24
	local.get	17
	local.set	21
	br      	2                               # 2: down to label358
.LBB24_20:                              #   in Loop: Header=BB24_16 Depth=2
	end_block                               # label360:
	block   	
	local.get	13
	local.get	17
	i32.const	65535
	i32.and 
	i32.const	-1
	i32.add 
	local.tee	16
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.get	23
	i32.eq  
	br_if   	0                               # 0: down to label362
# %bb.21:                               #   in Loop: Header=BB24_16 Depth=2
	local.get	15
	local.get	24
	i32.const	1
	i32.add 
	local.get	20
	i32.and 
	local.tee	24
	i32.const	1
	i32.shl 
	i32.add 
	local.set	16
	br      	1                               # 1: up to label359
.LBB24_22:                              #   in Loop: Header=BB24_8 Depth=1
	end_block                               # label362:
	end_loop
	local.get	23
	local.set	24
.LBB24_23:                              #   in Loop: Header=BB24_8 Depth=1
	end_block                               # label358:
	local.get	14
	local.get	25
	i32.const	1
	i32.shl 
	i32.add 
	local.get	16
	i32.store16	0
	local.get	22
	i32.const	1
	i32.add 
	local.set	22
.LBB24_24:                              #   in Loop: Header=BB24_8 Depth=1
	end_block                               # label356:
	local.get	26
	local.get	27
	i32.const	1
	i32.xor 
	local.tee	27
	i32.add 
	local.set	23
	local.get	25
	i32.const	1
	i32.add 
	local.tee	25
	local.get	10
	i32.ne  
	br_if   	0                               # 0: up to label354
# %bb.25:
	end_loop
	local.get	5
	i32.const	3
	i32.add 
	i32.const	2
	i32.shr_u
	local.set	17
	i32.const	1
	local.set	25
.LBB24_26:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label363:
	local.get	25
	local.tee	16
	i32.const	1
	i32.shl 
	local.set	25
	local.get	16
	local.get	17
	i32.lt_u
	br_if   	0                               # 0: up to label363
# %bb.27:
	end_loop
	local.get	21
	i32.const	3
	i32.add 
	i32.const	2
	i32.shr_u
	local.set	17
	i32.const	1
	local.set	15
.LBB24_28:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label364:
	local.get	15
	local.tee	24
	i32.const	1
	i32.shl 
	local.set	15
	local.get	24
	local.get	17
	i32.lt_u
	br_if   	0                               # 0: up to label364
# %bb.29:
	end_loop
	i32.const	-4
	local.set	17
	local.get	1
	i64.extend_i32_u
	i64.const	3
	i64.add 
	local.tee	28
	i64.const	8589934588
	i64.and 
	local.tee	29
	local.get	10
	i32.const	3
	i32.mul 
	local.get	5
	i32.add 
	i32.const	1
	i32.shl 
	i32.const	3
	i32.add 
	local.tee	30
	i32.const	2147483644
	i32.and 
	local.tee	31
	i64.extend_i32_u
	i64.add 
	local.get	21
	i32.const	2
	i32.shl 
	local.tee	32
	i64.extend_i32_u
	i64.add 
	i64.const	32
	i64.add 
	local.tee	33
	local.get	5
	i32.const	1
	i32.add 
	local.tee	34
	i32.const	1
	i32.shl 
	local.tee	35
	local.get	5
	i32.add 
	local.get	10
	i32.add 
	local.get	23
	i32.add 
	local.get	22
	i32.add 
	local.get	21
	i32.add 
	local.get	21
	i32.const	1
	i32.add 
	local.tee	36
	i32.add 
	local.get	16
	i32.add 
	local.get	24
	i32.add 
	i32.const	1
	i32.shl 
	i32.const	3
	i32.add 
	i32.const	-4
	i32.and 
	i32.const	32
	i32.add 
	local.tee	9
	i64.extend_i32_u
	i64.add 
	i64.const	16
	i64.add 
	local.tee	37
	local.get	12
	i64.extend_i32_u
	i64.gt_u
	br_if   	0                               # 0: down to label352
# %bb.30:
	local.get	37
	i64.const	2147483647
	i64.gt_u
	br_if   	0                               # 0: down to label352
# %bb.31:
	i32.const	0
	local.set	20
	block   	
	local.get	37
	i32.wrap_i64
	local.tee	38
	i32.eqz
	br_if   	0                               # 0: down to label365
# %bb.32:
	local.get	11
	i32.const	0
	local.get	38
	memory.fill	0
.LBB24_33:
	end_block                               # label365:
	local.get	11
	local.get	23
	i32.store	36
	local.get	11
	local.get	21
	i32.store	32
	local.get	11
	i32.const	7
	i32.store	28
	local.get	11
	local.get	1
	i32.store	24
	local.get	11
	local.get	5
	i32.store	20
	local.get	11
	local.get	10
	i32.store	16
	local.get	11
	local.get	9
	i32.store	12
	local.get	11
	local.get	33
	i32.wrap_i64
	local.tee	39
	i32.store	8
	local.get	11
	i64.const	30992321613
	i64.store	0:p2align=2
	block   	
	local.get	1
	i32.eqz
	br_if   	0                               # 0: down to label366
# %bb.34:
	local.get	11
	i32.const	48
	i32.add 
	local.get	0
	local.get	1
	memory.copy	0, 0
.LBB24_35:
	end_block                               # label366:
	local.get	10
	i32.const	1
	i32.shl 
	local.tee	40
	local.get	29
	i32.wrap_i64
	local.tee	41
	i32.const	32
	i32.add 
	local.tee	9
	local.get	5
	i32.const	1
	i32.shl 
	local.tee	42
	i32.add 
	i32.add 
	local.tee	12
	local.get	40
	i32.add 
	local.set	17
	local.get	11
	i32.const	16
	i32.add 
	local.set	43
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label367
# %bb.36:
	local.get	43
	local.get	40
	local.get	17
	i32.add 
	i32.const	3
	i32.add 
	i32.const	-4
	i32.and 
	i32.add 
	local.get	13
	local.get	32
	memory.copy	0, 0
.LBB24_37:
	end_block                               # label367:
	local.get	43
	local.get	9
	i32.add 
	local.set	0
	local.get	43
	local.get	12
	i32.add 
	local.set	44
	local.get	43
	local.get	17
	i32.add 
	local.set	45
	local.get	5
	local.set	12
.LBB24_38:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label368:
	i32.const	-5
	local.set	17
	local.get	3
	i32.load	0
	local.get	20
	i32.ne  
	br_if   	1                               # 1: down to label352
# %bb.39:                               #   in Loop: Header=BB24_38 Depth=1
	local.get	2
	i32.load16_u	0
	local.tee	9
	i32.const	1
	i32.add 
	i32.const	65535
	i32.and 
	i32.const	2
	i32.lt_u
	br_if   	1                               # 1: down to label352
# %bb.40:                               #   in Loop: Header=BB24_38 Depth=1
	local.get	1
	local.get	20
	i32.lt_u
	br_if   	1                               # 1: down to label352
# %bb.41:                               #   in Loop: Header=BB24_38 Depth=1
	local.get	1
	local.get	20
	i32.sub 
	local.get	9
	i32.lt_u
	br_if   	1                               # 1: down to label352
# %bb.42:                               #   in Loop: Header=BB24_38 Depth=1
	local.get	0
	local.get	9
	i32.store16	0
	local.get	3
	i32.const	4
	i32.add 
	local.set	3
	local.get	2
	i32.const	2
	i32.add 
	local.set	2
	local.get	0
	i32.const	2
	i32.add 
	local.set	0
	local.get	20
	local.get	9
	i32.add 
	local.set	20
	local.get	12
	i32.const	-1
	i32.add 
	local.tee	12
	br_if   	0                               # 0: up to label368
# %bb.43:
	end_loop
	local.get	20
	local.get	1
	i32.ne  
	br_if   	0                               # 0: down to label352
# %bb.44:
	local.get	43
	local.get	39
	i32.add 
	local.tee	1
	i32.const	7
	i32.store	28
	local.get	1
	local.get	22
	i32.store	24
	local.get	1
	local.get	21
	i32.store	20
	local.get	1
	local.get	23
	i32.store	16
	local.get	1
	local.get	24
	i32.store	12
	local.get	1
	local.get	16
	i32.store	8
	local.get	1
	local.get	5
	i32.store	4
	local.get	1
	local.get	10
	i32.store	0
	local.get	1
	i32.const	32
	i32.add 
	local.set	9
	block   	
	local.get	25
	i32.eqz
	br_if   	0                               # 0: down to label369
# %bb.45:
	local.get	9
	i32.const	255
	local.get	25
	memory.fill	0
.LBB24_46:
	end_block                               # label369:
	local.get	1
	local.get	25
	i32.const	32
	i32.add 
	local.tee	17
	i32.add 
	local.set	43
	block   	
	local.get	42
	i32.eqz
	br_if   	0                               # 0: down to label370
# %bb.47:
	local.get	43
	i32.const	255
	local.get	42
	memory.fill	0
.LBB24_48:
	end_block                               # label370:
	local.get	1
	local.get	17
	local.get	42
	i32.add 
	local.tee	39
	local.get	35
	i32.add 
	local.tee	46
	local.get	40
	i32.add 
	local.tee	47
	local.get	35
	i32.add 
	local.tee	48
	local.get	23
	i32.const	1
	i32.shl 
	i32.add 
	i32.add 
	local.set	22
	block   	
	local.get	15
	i32.eqz
	br_if   	0                               # 0: down to label371
# %bb.49:
	local.get	22
	i32.const	255
	local.get	15
	memory.fill	0
.LBB24_50:
	end_block                               # label371:
	local.get	22
	local.get	15
	i32.add 
	local.set	20
	block   	
	local.get	21
	i32.const	1
	i32.shl 
	local.tee	12
	i32.eqz
	br_if   	0                               # 0: down to label372
# %bb.51:
	local.get	20
	i32.const	255
	local.get	12
	memory.fill	0
.LBB24_52:
	end_block                               # label372:
	local.get	5
	i32.const	1
	i32.and 
	local.set	35
	local.get	16
	i32.const	-1
	i32.add 
	local.set	3
	i32.const	0
	local.set	17
	block   	
	local.get	5
	i32.const	1
	i32.eq  
	br_if   	0                               # 0: down to label373
# %bb.53:
	local.get	31
	local.get	41
	i32.add 
	local.get	11
	i32.add 
	local.get	32
	i32.add 
	local.get	16
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	82
	i32.add 
	local.set	25
	i32.const	0
	local.get	5
	i32.const	65534
	i32.and 
	i32.sub 
	local.set	0
	i32.const	1
	local.set	17
	local.get	4
	local.set	15
.LBB24_54:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label374:
	local.get	25
	i32.const	-2
	i32.add 
	local.get	9
	local.get	15
	i32.load	0
	local.get	3
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	2
	i32.load16_u	0
	i32.store16	0
	local.get	2
	local.get	17
	i32.const	-1
	i32.add 
	i32.store16	0
	local.get	25
	local.get	9
	local.get	15
	i32.const	4
	i32.add 
	i32.load	0
	local.get	3
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	2
	i32.load16_u	0
	i32.store16	0
	local.get	2
	local.get	17
	i32.store16	0
	local.get	25
	i32.const	4
	i32.add 
	local.set	25
	local.get	15
	i32.const	8
	i32.add 
	local.set	15
	local.get	0
	local.get	17
	i32.const	2
	i32.add 
	local.tee	17
	i32.add 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: up to label374
# %bb.55:
	end_loop
	local.get	17
	i32.const	-1
	i32.add 
	local.set	17
.LBB24_56:
	end_block                               # label373:
	block   	
	local.get	35
	i32.eqz
	br_if   	0                               # 0: down to label375
# %bb.57:
	local.get	43
	local.get	17
	i32.const	1
	i32.shl 
	i32.add 
	local.get	9
	local.get	4
	local.get	17
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.get	3
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	25
	i32.load16_u	0
	i32.store16	0
	local.get	25
	local.get	17
	i32.store16	0
.LBB24_58:
	end_block                               # label375:
	local.get	20
	local.get	12
	i32.add 
	local.set	0
	local.get	36
	i32.const	1
	i32.shl 
	local.set	9
	local.get	1
	local.get	39
	i32.add 
	local.set	43
	local.get	1
	local.get	47
	i32.add 
	local.set	35
	block   	
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label376
# %bb.59:
	local.get	24
	i32.const	-1
	i32.add 
	local.set	15
	i32.const	0
	local.set	25
.LBB24_60:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label377:
	local.get	20
	local.get	22
	local.get	13
	i32.load	0
	local.tee	17
	i32.const	255
	i32.and 
	i32.const	-2128831035
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	17
	i32.const	8
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	17
	i32.const	16
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	17
	i32.const	24
	i32.shr_u
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	15
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	17
	i32.load16_u	0
	i32.store16	0
	local.get	17
	local.get	25
	i32.store16	0
	local.get	20
	i32.const	2
	i32.add 
	local.set	20
	local.get	13
	i32.const	4
	i32.add 
	local.set	13
	local.get	21
	local.get	25
	i32.const	1
	i32.add 
	local.tee	25
	i32.ne  
	br_if   	0                               # 0: up to label377
.LBB24_61:
	end_loop
	end_block                               # label376:
	local.get	1
	local.get	46
	i32.add 
	local.set	2
	local.get	1
	local.get	48
	i32.add 
	local.set	4
	local.get	0
	local.get	9
	i32.add 
	local.set	1
	local.get	0
	i32.const	2
	i32.add 
	local.set	12
	local.get	35
	i32.const	2
	i32.add 
	local.set	3
	local.get	43
	i32.const	2
	i32.add 
	local.set	13
	local.get	11
	local.get	41
	local.get	42
	i32.add 
	i32.add 
	local.set	22
	i32.const	0
	local.set	17
	local.get	10
	local.set	15
.LBB24_62:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label378:
	local.get	22
	local.get	17
	i32.add 
	i32.const	48
	i32.add 
	local.tee	20
	local.get	6
	i32.load	0
	i32.store16	0
	i32.const	65535
	local.set	25
	block   	
	local.get	8
	i32.load8_u	0
	br_if   	0                               # 0: down to label379
# %bb.63:                               #   in Loop: Header=BB24_62 Depth=1
	local.get	7
	i32.load	0
	local.set	25
.LBB24_64:                              #   in Loop: Header=BB24_62 Depth=1
	end_block                               # label379:
	local.get	44
	local.get	17
	i32.add 
	local.tee	9
	local.get	25
	i32.store16	0
	local.get	45
	local.get	17
	i32.add 
	local.get	14
	local.get	17
	i32.add 
	i32.load16_u	0
	local.tee	25
	i32.store16	0
	local.get	13
	local.get	20
	i32.load16_u	0
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	20
	local.get	20
	i32.load16_u	0
	i32.const	1
	i32.add 
	i32.store16	0
	block   	
	local.get	9
	i32.load16_u	0
	local.tee	20
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label380
# %bb.65:                               #   in Loop: Header=BB24_62 Depth=1
	local.get	3
	local.get	20
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	20
	local.get	20
	i32.load16_u	0
	i32.const	1
	i32.add 
	i32.store16	0
.LBB24_66:                              #   in Loop: Header=BB24_62 Depth=1
	end_block                               # label380:
	block   	
	local.get	25
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label381
# %bb.67:                               #   in Loop: Header=BB24_62 Depth=1
	local.get	12
	local.get	25
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	25
	local.get	25
	i32.load16_u	0
	i32.const	1
	i32.add 
	i32.store16	0
.LBB24_68:                              #   in Loop: Header=BB24_62 Depth=1
	end_block                               # label381:
	local.get	6
	i32.const	4
	i32.add 
	local.set	6
	local.get	8
	i32.const	1
	i32.add 
	local.set	8
	local.get	7
	i32.const	4
	i32.add 
	local.set	7
	local.get	17
	i32.const	2
	i32.add 
	local.set	17
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	15
	br_if   	0                               # 0: up to label378
# %bb.69:
	end_loop
	i32.const	1
	local.set	17
	local.get	34
	i32.const	2
	local.get	34
	i32.const	2
	i32.gt_u
	i32.select
	i32.const	-1
	i32.add 
	local.tee	25
	i32.const	1
	i32.and 
	local.set	22
	block   	
	local.get	5
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label382
# %bb.70:
	local.get	11
	local.get	31
	local.get	41
	i32.add 
	i32.add 
	local.get	32
	i32.add 
	local.get	16
	i32.const	1
	i32.shl 
	i32.add 
	local.set	17
	local.get	25
	i32.const	-2
	i32.and 
	local.set	9
	local.get	5
	i32.const	2
	i32.shl 
	local.get	40
	i32.add 
	local.set	7
	i32.const	0
	local.set	8
.LBB24_71:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label383:
	local.get	17
	local.get	42
	i32.add 
	local.tee	25
	i32.const	82
	i32.add 
	local.tee	15
	local.get	25
	i32.const	80
	i32.add 
	i32.load16_u	0
	local.get	15
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	17
	local.get	7
	i32.add 
	local.tee	20
	i32.const	84
	i32.add 
	local.tee	6
	local.get	20
	i32.const	82
	i32.add 
	i32.load16_u	0
	local.get	6
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	25
	i32.const	84
	i32.add 
	local.tee	25
	local.get	15
	i32.load16_u	0
	local.get	25
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	20
	i32.const	86
	i32.add 
	local.tee	25
	local.get	6
	i32.load16_u	0
	local.get	25
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	17
	i32.const	4
	i32.add 
	local.set	17
	local.get	9
	local.get	8
	i32.const	2
	i32.add 
	local.tee	8
	i32.ne  
	br_if   	0                               # 0: up to label383
# %bb.72:
	end_loop
	local.get	8
	i32.const	1
	i32.add 
	local.set	17
.LBB24_73:
	end_block                               # label382:
	block   	
	local.get	22
	i32.eqz
	br_if   	0                               # 0: down to label384
# %bb.74:
	local.get	43
	local.get	17
	i32.const	1
	i32.shl 
	local.tee	17
	i32.add 
	local.tee	25
	local.get	43
	local.get	17
	i32.const	-2
	i32.add 
	local.tee	15
	i32.add 
	i32.load16_u	0
	local.get	25
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	35
	local.get	17
	i32.add 
	local.tee	17
	local.get	35
	local.get	15
	i32.add 
	i32.load16_u	0
	local.get	17
	i32.load16_u	0
	i32.add 
	i32.store16	0
.LBB24_75:
	end_block                               # label384:
	block   	
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label385
# %bb.76:
	i32.const	1
	local.set	17
	local.get	11
	local.get	30
	i32.const	2147483644
	i32.and 
	local.get	28
	i32.wrap_i64
	local.tee	9
	i32.add 
	i32.const	-4
	i32.and 
	i32.add 
	local.get	5
	local.get	21
	i32.add 
	local.tee	22
	i32.const	6
	i32.mul 
	local.tee	6
	i32.add 
	local.get	10
	local.get	26
	i32.add 
	local.get	27
	i32.add 
	local.get	16
	i32.add 
	local.get	24
	i32.add 
	local.tee	7
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	84
	i32.add 
	i32.load16_u	0
	local.set	25
	local.get	36
	i32.const	2
	local.get	36
	i32.const	2
	i32.gt_u
	i32.select
	local.tee	20
	i32.const	-1
	i32.add 
	local.tee	8
	i32.const	3
	i32.and 
	local.set	15
	block   	
	local.get	20
	i32.const	-2
	i32.add 
	i32.const	3
	i32.lt_u
	br_if   	0                               # 0: down to label386
# %bb.77:
	local.get	11
	local.get	30
	i32.const	2
	i32.shr_u
	local.get	9
	i32.const	2
	i32.shr_u
	i32.add 
	i32.const	2
	i32.shl 
	i32.add 
	local.get	6
	i32.add 
	local.get	7
	i32.const	1
	i32.shl 
	i32.add 
	local.set	17
	local.get	8
	i32.const	-4
	i32.and 
	local.set	8
	i32.const	0
	local.set	20
.LBB24_78:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label387:
	local.get	17
	i32.const	86
	i32.add 
	local.tee	6
	local.get	25
	local.get	6
	i32.load16_u	0
	i32.add 
	local.tee	25
	i32.store16	0
	local.get	17
	i32.const	88
	i32.add 
	local.tee	6
	local.get	25
	local.get	6
	i32.load16_u	0
	i32.add 
	local.tee	25
	i32.store16	0
	local.get	17
	i32.const	90
	i32.add 
	local.tee	6
	local.get	25
	local.get	6
	i32.load16_u	0
	i32.add 
	local.tee	25
	i32.store16	0
	local.get	17
	i32.const	92
	i32.add 
	local.tee	6
	local.get	25
	local.get	6
	i32.load16_u	0
	i32.add 
	local.tee	25
	i32.store16	0
	local.get	17
	i32.const	8
	i32.add 
	local.set	17
	local.get	8
	local.get	20
	i32.const	4
	i32.add 
	local.tee	20
	i32.ne  
	br_if   	0                               # 0: up to label387
# %bb.79:
	end_loop
	local.get	20
	i32.const	1
	i32.add 
	local.set	17
.LBB24_80:
	end_block                               # label386:
	local.get	15
	i32.eqz
	br_if   	0                               # 0: down to label385
# %bb.81:
	local.get	30
	i32.const	2
	i32.shr_u
	local.get	9
	i32.const	2
	i32.shr_u
	i32.add 
	i32.const	2
	i32.shl 
	local.get	17
	i32.const	1
	i32.shl 
	i32.add 
	local.get	11
	i32.add 
	local.get	22
	i32.const	6
	i32.mul 
	i32.add 
	local.get	7
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	84
	i32.add 
	local.set	17
.LBB24_82:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label388:
	local.get	17
	local.get	25
	local.get	17
	i32.load16_u	0
	i32.add 
	local.tee	25
	i32.store16	0
	local.get	17
	i32.const	2
	i32.add 
	local.set	17
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	15
	br_if   	0                               # 0: up to label388
.LBB24_83:
	end_loop
	end_block                               # label385:
	local.get	10
	i32.const	-1
	i32.add 
	local.set	25
	local.get	40
	local.get	14
	i32.add 
	i32.const	-2
	i32.add 
	local.set	20
	local.get	41
	local.get	40
	i32.add 
	local.get	42
	i32.add 
	local.get	11
	i32.add 
	i32.const	46
	i32.add 
	local.set	6
	local.get	10
	i32.const	2
	i32.shl 
	local.get	41
	i32.add 
	local.get	42
	i32.add 
	local.get	11
	i32.add 
	i32.const	46
	i32.add 
	local.set	8
	i32.const	0
	local.set	17
.LBB24_84:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label389:
	local.get	13
	local.get	6
	local.get	17
	i32.add 
	i32.load16_u	0
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	15
	local.get	15
	i32.load16_u	0
	i32.const	-1
	i32.add 
	local.tee	15
	i32.store16	0
	local.get	2
	local.get	15
	i32.const	65535
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.get	25
	i32.store16	0
	block   	
	local.get	8
	local.get	17
	i32.add 
	i32.load16_u	0
	local.tee	15
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label390
# %bb.85:                               #   in Loop: Header=BB24_84 Depth=1
	local.get	3
	local.get	15
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	15
	local.get	15
	i32.load16_u	0
	i32.const	-1
	i32.add 
	local.tee	15
	i32.store16	0
	local.get	4
	local.get	15
	i32.const	65535
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.get	25
	i32.store16	0
.LBB24_86:                              #   in Loop: Header=BB24_84 Depth=1
	end_block                               # label390:
	block   	
	local.get	20
	local.get	17
	i32.add 
	i32.load16_u	0
	local.tee	15
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label391
# %bb.87:                               #   in Loop: Header=BB24_84 Depth=1
	local.get	0
	local.get	15
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	15
	local.get	15
	i32.load16_u	0
	local.tee	15
	i32.const	1
	i32.add 
	i32.store16	0
	local.get	1
	local.get	15
	i32.const	1
	i32.shl 
	i32.add 
	local.get	25
	i32.store16	0
.LBB24_88:                              #   in Loop: Header=BB24_84 Depth=1
	end_block                               # label391:
	local.get	17
	i32.const	-2
	i32.add 
	local.set	17
	local.get	25
	i32.const	-1
	i32.add 
	local.tee	25
	i32.const	-1
	i32.ne  
	br_if   	0                               # 0: up to label389
# %bb.89:
	end_loop
	block   	
	local.get	5
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label392
# %bb.90:
	i32.const	1
	local.set	6
	block   	
	local.get	5
	i32.const	17
	i32.lt_u
	br_if   	0                               # 0: down to label393
# %bb.91:
	i32.const	1
	local.set	6
	local.get	10
	local.get	5
	i32.add 
	i32.const	8
	i32.lt_u
	br_if   	0                               # 0: down to label393
# %bb.92:
	local.get	11
	local.get	31
	local.get	28
	i32.wrap_i64
	i32.const	-4
	i32.and 
	i32.add 
	local.tee	25
	local.get	5
	i32.const	2
	i32.shl 
	i32.add 
	local.get	40
	i32.add 
	i32.add 
	local.get	32
	i32.add 
	local.set	17
	local.get	16
	i32.const	1
	i32.shl 
	local.set	13
	local.get	5
	i32.const	-1
	i32.add 
	local.tee	14
	i32.const	-8
	i32.and 
	local.tee	8
	i32.const	1
	i32.or  
	local.set	6
	local.get	11
	local.get	25
	local.get	42
	i32.add 
	i32.add 
	local.get	32
	i32.add 
	local.set	25
	local.get	8
	local.set	15
.LBB24_93:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label394:
	local.get	25
	local.get	13
	i32.add 
	local.tee	20
	i32.const	82
	i32.add 
	local.get	20
	i32.const	84
	i32.add 
	v128.load	0:p2align=1
	v128.store	0:p2align=1
	local.get	17
	local.get	13
	i32.add 
	local.tee	20
	i32.const	84
	i32.add 
	local.get	20
	i32.const	86
	i32.add 
	v128.load	0:p2align=1
	v128.store	0:p2align=1
	local.get	25
	i32.const	16
	i32.add 
	local.set	25
	local.get	17
	i32.const	16
	i32.add 
	local.set	17
	local.get	15
	i32.const	-8
	i32.add 
	local.tee	15
	br_if   	0                               # 0: up to label394
# %bb.94:
	end_loop
	local.get	14
	local.get	8
	i32.eq  
	br_if   	1                               # 1: down to label392
.LBB24_95:
	end_block                               # label393:
	local.get	6
	i32.const	1
	i32.add 
	local.set	17
	block   	
	local.get	5
	i32.const	1
	i32.and 
	br_if   	0                               # 0: down to label395
# %bb.96:
	local.get	43
	local.get	6
	i32.const	1
	i32.shl 
	local.tee	25
	i32.add 
	local.get	43
	local.get	6
	i32.const	1
	i32.add 
	local.tee	6
	i32.const	1
	i32.shl 
	local.tee	13
	i32.add 
	i32.load16_u	0
	i32.store16	0
	local.get	35
	local.get	25
	i32.add 
	local.get	35
	local.get	13
	i32.add 
	i32.load16_u	0
	i32.store16	0
.LBB24_97:
	end_block                               # label395:
	local.get	5
	local.get	17
	i32.eq  
	br_if   	0                               # 0: down to label392
# %bb.98:
	local.get	11
	local.get	31
	local.get	28
	i32.wrap_i64
	i32.const	-4
	i32.and 
	i32.add 
	local.tee	25
	local.get	42
	i32.add 
	i32.add 
	local.get	32
	i32.add 
	local.get	16
	i32.const	1
	i32.shl 
	local.tee	13
	i32.add 
	local.set	17
	local.get	11
	local.get	25
	local.get	5
	i32.const	2
	i32.shl 
	i32.add 
	local.get	40
	i32.add 
	i32.add 
	local.get	32
	i32.add 
	local.get	13
	i32.add 
	local.set	25
	local.get	6
	i32.const	1
	i32.shl 
	local.set	20
	local.get	5
	local.get	6
	i32.sub 
	local.set	6
.LBB24_99:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label396:
	local.get	17
	local.get	20
	i32.add 
	local.tee	13
	i32.const	80
	i32.add 
	local.get	13
	i32.const	82
	i32.add 
	local.tee	8
	i32.load16_u	0
	i32.store16	0
	local.get	25
	local.get	20
	i32.add 
	local.tee	15
	i32.const	82
	i32.add 
	local.get	15
	i32.const	84
	i32.add 
	local.tee	14
	i32.load16_u	0
	i32.store16	0
	local.get	8
	local.get	13
	i32.const	84
	i32.add 
	i32.load16_u	0
	i32.store16	0
	local.get	14
	local.get	15
	i32.const	86
	i32.add 
	i32.load16_u	0
	i32.store16	0
	local.get	17
	i32.const	4
	i32.add 
	local.set	17
	local.get	25
	i32.const	4
	i32.add 
	local.set	25
	local.get	6
	i32.const	-2
	i32.add 
	local.tee	6
	br_if   	0                               # 0: up to label396
.LBB24_100:
	end_loop
	end_block                               # label392:
	local.get	43
	local.get	5
	i32.const	1
	i32.shl 
	local.tee	17
	i32.add 
	local.get	10
	i32.store16	0
	local.get	35
	local.get	17
	i32.add 
	local.get	23
	i32.store16	0
	block   	
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label397
# %bb.101:
	local.get	21
	local.set	23
	block   	
	local.get	21
	i32.const	8
	i32.lt_u
	br_if   	0                               # 0: down to label398
# %bb.102:
	local.get	5
	i32.const	6
	i32.mul 
	local.get	30
	i32.const	2
	i32.shr_u
	local.get	28
	i32.wrap_i64
	i32.const	2
	i32.shr_u
	i32.add 
	i32.const	2
	i32.shl 
	i32.add 
	local.get	11
	i32.add 
	local.get	21
	i32.const	3
	i32.shl 
	i32.add 
	local.get	10
	local.get	26
	i32.add 
	local.get	27
	i32.add 
	local.get	16
	i32.add 
	local.get	24
	i32.add 
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	70
	i32.add 
	local.set	17
	local.get	21
	i32.const	7
	i32.and 
	local.set	23
	local.get	21
	i32.const	-8
	i32.and 
	local.tee	13
	local.set	25
.LBB24_103:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label399:
	local.get	17
	local.get	17
	i32.const	-2
	i32.add 
	v128.load	0:p2align=1
	v128.store	0:p2align=1
	local.get	17
	i32.const	-16
	i32.add 
	local.set	17
	local.get	25
	i32.const	-8
	i32.add 
	local.tee	25
	br_if   	0                               # 0: up to label399
# %bb.104:
	end_loop
	local.get	21
	local.get	13
	i32.eq  
	br_if   	1                               # 1: down to label397
.LBB24_105:
	end_block                               # label398:
	local.get	30
	i32.const	2
	i32.shr_u
	local.get	28
	i32.wrap_i64
	i32.const	2
	i32.shr_u
	i32.add 
	i32.const	2
	i32.shl 
	local.get	23
	i32.const	1
	i32.shl 
	i32.add 
	local.get	11
	i32.add 
	local.get	5
	local.get	21
	i32.add 
	i32.const	6
	i32.mul 
	i32.add 
	local.get	10
	local.get	26
	i32.add 
	local.get	27
	i32.add 
	local.get	16
	i32.add 
	local.get	24
	i32.add 
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	84
	i32.add 
	local.set	16
.LBB24_106:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label400:
	local.get	16
	local.get	16
	i32.const	-2
	i32.add 
	local.tee	17
	i32.load16_u	0
	i32.store16	0
	local.get	17
	local.set	16
	local.get	23
	i32.const	-1
	i32.add 
	local.tee	23
	br_if   	0                               # 0: up to label400
.LBB24_107:
	end_loop
	end_block                               # label397:
	local.get	0
	i32.const	0
	i32.store16	0
	local.get	38
	local.set	17
.LBB24_108:
	end_block                               # label352:
	local.get	17
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_token_binary_dedup,"",@
	.globl	encode_term_content_token_binary_dedup # -- Begin function encode_term_content_token_binary_dedup
	.type	encode_term_content_token_binary_dedup,@function
encode_term_content_token_binary_dedup: # @encode_term_content_token_binary_dedup
	.functype	encode_term_content_token_binary_dedup (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	10
	global.set	__stack_pointer
	i32.const	-1
	local.set	11
	block   	
	local.get	0
	i32x4.splat
	local.get	1
	i32x4.replace_lane	1
	local.get	3
	i32x4.replace_lane	2
	local.get	5
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	12
	i32x4.eq
	v128.const	65535, 65535, 65535, 65535
	local.tee	13
	v128.and
	local.get	6
	i32x4.splat
	local.get	8
	i32x4.replace_lane	1
	local.get	9
	i32x4.replace_lane	2
	local.get	7
	i32x4.replace_lane	3
	local.get	12
	i32x4.eq
	local.get	13
	v128.and
	i16x8.narrow_i32x4_u
	v128.any_true
	br_if   	0                               # 0: down to label401
# %bb.1:
	i32.const	-1
	local.set	11
	local.get	7
	local.get	7
	i32.const	-1
	i32.add 
	local.tee	14
	i32.and 
	br_if   	0                               # 0: down to label401
# %bb.2:
	i32.const	0
	local.set	15
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	10
	i32.const	0
	i32.store	12
	i32.const	0
	local.set	16
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label402
# %bb.3:
	i32.const	0
	local.set	15
	i32.const	0
	local.set	16
	i32.const	0
	local.set	17
.LBB25_4:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB25_5 Depth 2
                                        #     Child Loop BB25_17 Depth 2
                                        #       Child Loop BB25_24 Depth 3
                                        #       Child Loop BB25_27 Depth 3
	loop    	                                # label403:
	local.get	10
	i32.const	0
	i32.store	8
	local.get	10
	i32.const	0
	i32.store	4
	block   	
	local.get	0
	local.get	1
	local.get	17
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	18
	local.get	3
	local.get	4
	local.get	10
	i32.const	12
	i32.add 
	local.get	10
	i32.const	8
	i32.add 
	local.get	10
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	call	encode_term_content_token_binary_row
	br_if   	0                               # 0: down to label404
.LBB25_5:                               #   Parent Loop BB25_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label405:
	local.get	10
	local.get	15
	i32.store	12
	i32.const	-2
	local.set	11
	local.get	4
	i32.const	2147483646
	i32.gt_u
	br_if   	4                               # 4: down to label401
# %bb.6:                                #   in Loop: Header=BB25_5 Depth=2
	local.get	3
	local.get	4
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	19
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label401
# %bb.7:                                #   in Loop: Header=BB25_5 Depth=2
	i32.const	0
	i32.load	heap_ptr
	local.get	19
	local.get	3
	i32.add 
	local.tee	20
	i32.ne  
	br_if   	4                               # 4: down to label401
# %bb.8:                                #   in Loop: Header=BB25_5 Depth=2
	i32.const	2147483647
	local.get	4
	i32.const	1
	i32.shr_u
	local.tee	21
	i32.const	1048576
	local.get	21
	i32.const	1048576
	i32.gt_u
	i32.select
	local.tee	21
	local.get	4
	i32.add 
	local.get	4
	local.get	21
	i32.const	2147483647
	i32.xor 
	i32.gt_u
	i32.select
	local.tee	4
	local.get	19
	i32.sub 
	i32.const	7
	i32.add 
	local.set	21
	local.get	20
	local.set	19
	block   	
	local.get	20
	br_if   	0                               # 0: down to label406
# %bb.9:                                #   in Loop: Header=BB25_5 Depth=2
	i32.const	__heap_base
	local.set	19
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB25_10:                              #   in Loop: Header=BB25_5 Depth=2
	end_block                               # label406:
	local.get	19
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	19
	local.get	21
	i32.const	-8
	i32.and 
	local.tee	21
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label401
# %bb.11:                               #   in Loop: Header=BB25_5 Depth=2
	block   	
	local.get	19
	local.get	21
	i32.add 
	local.tee	21
	i32.const	16
	i32.shr_u
	local.get	21
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	22
	memory.size	0
	local.tee	23
	i32.le_u
	br_if   	0                               # 0: down to label407
# %bb.12:                               #   in Loop: Header=BB25_5 Depth=2
	local.get	22
	local.get	23
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	5                               # 5: down to label401
.LBB25_13:                              #   in Loop: Header=BB25_5 Depth=2
	end_block                               # label407:
	i32.const	0
	local.get	21
	i32.store	heap_ptr
	local.get	19
	i32.eqz
	br_if   	4                               # 4: down to label401
# %bb.14:                               #   in Loop: Header=BB25_5 Depth=2
	local.get	19
	local.get	20
	i32.ne  
	br_if   	4                               # 4: down to label401
# %bb.15:                               #   in Loop: Header=BB25_5 Depth=2
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	0
	local.get	18
	local.get	3
	local.get	4
	local.get	10
	i32.const	12
	i32.add 
	local.get	10
	i32.const	8
	i32.add 
	local.get	10
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	call	encode_term_content_token_binary_row
	i32.eqz
	br_if   	0                               # 0: up to label405
.LBB25_16:                              #   in Loop: Header=BB25_4 Depth=1
	end_loop
	end_block                               # label404:
	local.get	17
	i32.const	2
	i32.shl 
	local.set	24
	local.get	10
	i32.load	4
	local.tee	25
	i32.const	-1640531535
	i32.mul 
	local.get	10
	i32.load	8
	local.tee	26
	i32.xor 
	local.tee	11
	i32.const	16
	i32.shr_u
	local.get	11
	i32.xor 
	local.get	14
	i32.and 
	local.set	27
	local.get	3
	local.get	15
	i32.add 
	local.set	28
	local.get	10
	i32.load	12
	local.tee	29
	local.get	15
	i32.sub 
	local.set	30
	i32.const	0
	local.set	31
.LBB25_17:                              #   Parent Loop BB25_4 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB25_24 Depth 3
                                        #       Child Loop BB25_27 Depth 3
	block   	
	block   	
	block   	
	loop    	                                # label411:
	local.get	6
	local.get	27
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	11
	i32.eqz
	br_if   	1                               # 1: down to label410
# %bb.18:                               #   in Loop: Header=BB25_17 Depth=2
	block   	
	local.get	11
	i32.const	-1
	i32.add 
	local.tee	32
	local.get	17
	i32.lt_u
	br_if   	0                               # 0: down to label412
# %bb.19:
	i32.const	-3
	local.set	11
	br      	7                               # 7: down to label401
.LBB25_20:                              #   in Loop: Header=BB25_17 Depth=2
	end_block                               # label412:
	block   	
	local.get	5
	local.get	32
	i32.const	4
	i32.shl 
	i32.add 
	local.tee	20
	i32.load	8
	local.get	26
	i32.ne  
	br_if   	0                               # 0: down to label413
# %bb.21:                               #   in Loop: Header=BB25_17 Depth=2
	local.get	20
	i32.load	12
	local.get	25
	i32.ne  
	br_if   	0                               # 0: down to label413
# %bb.22:                               #   in Loop: Header=BB25_17 Depth=2
	local.get	20
	i32.load	4
	local.get	30
	i32.ne  
	br_if   	0                               # 0: down to label413
# %bb.23:                               #   in Loop: Header=BB25_17 Depth=2
	i32.const	0
	local.set	11
	local.get	3
	local.get	20
	i32.load	0
	local.tee	33
	i32.add 
	local.tee	34
	local.set	20
	local.get	28
	local.set	19
	local.get	30
	local.set	21
.LBB25_24:                              #   Parent Loop BB25_4 Depth=1
                                        #     Parent Loop BB25_17 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	block   	
	loop    	                                # label415:
	block   	
	local.get	11
	i32.const	8
	i32.add 
	local.tee	18
	local.get	30
	i32.le_u
	br_if   	0                               # 0: down to label416
# %bb.25:                               #   in Loop: Header=BB25_17 Depth=2
	local.get	11
	local.get	30
	i32.lt_u
	br_if   	2                               # 2: down to label414
	br      	6                               # 6: down to label409
.LBB25_26:                              #   in Loop: Header=BB25_24 Depth=3
	end_block                               # label416:
	local.get	28
	local.get	11
	i32.add 
	local.set	22
	local.get	34
	local.get	11
	i32.add 
	local.set	23
	local.get	20
	i32.const	8
	i32.add 
	local.set	20
	local.get	19
	i32.const	8
	i32.add 
	local.set	19
	local.get	21
	i32.const	-8
	i32.add 
	local.set	21
	local.get	18
	local.set	11
	local.get	23
	i64.load	0:p2align=0
	local.get	22
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label415
	br      	2                               # 2: down to label413
.LBB25_27:                              #   Parent Loop BB25_4 Depth=1
                                        #     Parent Loop BB25_17 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	end_loop
	end_block                               # label414:
	loop    	                                # label417:
	local.get	20
	i32.load8_u	0
	local.get	19
	i32.load8_u	0
	i32.ne  
	br_if   	1                               # 1: down to label413
# %bb.28:                               #   in Loop: Header=BB25_27 Depth=3
	local.get	20
	i32.const	1
	i32.add 
	local.set	20
	local.get	19
	i32.const	1
	i32.add 
	local.set	19
	local.get	21
	i32.const	-1
	i32.add 
	local.tee	21
	i32.eqz
	br_if   	4                               # 4: down to label409
	br      	0                               # 0: up to label417
.LBB25_29:                              #   in Loop: Header=BB25_17 Depth=2
	end_loop
	end_block                               # label413:
	local.get	27
	i32.const	1
	i32.add 
	local.get	14
	i32.and 
	local.set	27
	local.get	31
	i32.const	1
	i32.add 
	local.tee	31
	local.get	7
	i32.ne  
	br_if   	0                               # 0: up to label411
.LBB25_30:                              #   in Loop: Header=BB25_4 Depth=1
	end_loop
	end_block                               # label410:
	i32.const	-3
	local.set	11
	local.get	6
	local.get	27
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	20
	i32.load	0
	br_if   	4                               # 4: down to label401
# %bb.31:                               #   in Loop: Header=BB25_4 Depth=1
	local.get	16
	i32.const	-1
	i32.eq  
	br_if   	4                               # 4: down to label401
# %bb.32:                               #   in Loop: Header=BB25_4 Depth=1
	local.get	5
	local.get	24
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	11
	local.get	25
	i32.store	12
	local.get	11
	local.get	26
	i32.store	8
	local.get	11
	local.get	30
	i32.store	4
	local.get	11
	local.get	15
	i32.store	0
	local.get	8
	local.get	24
	i32.add 
	local.get	16
	i32.store	0
	local.get	20
	local.get	17
	i32.const	1
	i32.add 
	local.tee	17
	i32.store	0
	local.get	16
	i32.const	1
	i32.add 
	local.set	16
	local.get	29
	local.set	15
	br      	1                               # 1: down to label408
.LBB25_33:                              #   in Loop: Header=BB25_4 Depth=1
	end_block                               # label409:
	local.get	5
	local.get	24
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	11
	local.get	25
	i32.store	12
	local.get	11
	local.get	26
	i32.store	8
	local.get	11
	local.get	30
	i32.store	4
	local.get	11
	local.get	33
	i32.store	0
	local.get	8
	local.get	24
	i32.add 
	local.get	8
	local.get	32
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.store	0
	local.get	10
	local.get	15
	i32.store	12
	local.get	17
	i32.const	1
	i32.add 
	local.set	17
.LBB25_34:                              #   in Loop: Header=BB25_4 Depth=1
	end_block                               # label408:
	local.get	17
	local.get	2
	i32.ne  
	br_if   	0                               # 0: up to label403
.LBB25_35:
	end_loop
	end_block                               # label402:
	local.get	9
	local.get	16
	i32.store	0
	local.get	15
	local.set	11
.LBB25_36:
	end_block                               # label401:
	local.get	10
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	11
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_and_encode_term_bank_token_binary_dedup,"",@
	.globl	parse_and_encode_term_bank_token_binary_dedup # -- Begin function parse_and_encode_term_bank_token_binary_dedup
	.type	parse_and_encode_term_bank_token_binary_dedup,@function
parse_and_encode_term_bank_token_binary_dedup: # @parse_and_encode_term_bank_token_binary_dedup
	.functype	parse_and_encode_term_bank_token_binary_dedup (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	112
	i32.sub 
	local.tee	38
	global.set	__stack_pointer
	i32.const	-1
	local.set	39
	block   	
	local.get	0
	i32x4.splat
	local.get	1
	i32x4.replace_lane	1
	local.get	2
	i32x4.replace_lane	2
	local.get	3
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	40
	i32x4.eq
	local.get	4
	i32x4.splat
	local.get	6
	i32x4.replace_lane	1
	local.get	7
	i32x4.replace_lane	2
	local.get	9
	i32x4.replace_lane	3
	local.get	40
	i32x4.eq
	i8x16.shuffle	0, 4, 8, 12, 16, 20, 24, 28, 0, 0, 0, 0, 0, 0, 0, 0
	local.get	10
	i32x4.splat
	local.get	11
	i32x4.replace_lane	1
	local.get	12
	i32x4.replace_lane	2
	local.get	13
	i32x4.replace_lane	3
	local.get	40
	i32x4.eq
	local.tee	41
	i32x4.extract_lane	0
	i8x16.replace_lane	8
	local.get	41
	i32x4.extract_lane	1
	i8x16.replace_lane	9
	local.get	41
	i32x4.extract_lane	2
	i8x16.replace_lane	10
	local.get	41
	i32x4.extract_lane	3
	i8x16.replace_lane	11
	local.get	15
	i32x4.splat
	local.get	16
	i32x4.replace_lane	1
	local.get	17
	i32x4.replace_lane	2
	local.get	18
	i32x4.replace_lane	3
	local.get	40
	i32x4.eq
	local.tee	41
	i32x4.extract_lane	0
	i8x16.replace_lane	12
	local.get	41
	i32x4.extract_lane	1
	i8x16.replace_lane	13
	local.get	41
	i32x4.extract_lane	2
	i8x16.replace_lane	14
	local.get	41
	i32x4.extract_lane	3
	i8x16.replace_lane	15
	local.tee	41
	local.get	19
	i32x4.splat
	local.get	20
	i32x4.replace_lane	1
	local.get	22
	i32x4.replace_lane	2
	local.get	23
	i32x4.replace_lane	3
	local.get	40
	i32x4.eq
	local.get	24
	i32x4.splat
	local.get	25
	i32x4.replace_lane	1
	local.get	26
	i32x4.replace_lane	2
	local.get	27
	i32x4.replace_lane	3
	local.get	40
	i32x4.eq
	i8x16.shuffle	0, 4, 8, 12, 16, 20, 24, 28, 0, 0, 0, 0, 0, 0, 0, 0
	v128.or
	local.get	41
	i8x16.shuffle	0, 1, 2, 3, 4, 5, 6, 7, 24, 25, 26, 27, 28, 29, 30, 31
	v128.any_true
	br_if   	0                               # 0: down to label418
# %bb.1:
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label418
# %bb.2:
	i32.const	-1
	local.set	39
	local.get	8
	local.get	8
	i32.const	-1
	i32.add 
	local.tee	42
	i32.and 
	br_if   	0                               # 0: down to label418
# %bb.3:
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label418
# %bb.4:
	i32.const	-1
	local.set	39
	local.get	21
	local.get	21
	i32.const	-1
	i32.add 
	local.tee	43
	i32.and 
	br_if   	0                               # 0: down to label418
# %bb.5:
	local.get	30
	i32.const	0
	i32.ne  
	local.get	31
	i32.eqz
	i32.eq  
	br_if   	0                               # 0: down to label418
# %bb.6:
	block   	
	local.get	29
	i32.const	1
	i32.and 
	br_if   	0                               # 0: down to label419
# %bb.7:
	local.get	31
	br_if   	1                               # 1: down to label418
.LBB26_8:
	end_block                               # label419:
	block   	
	local.get	29
	i32.const	8
	i32.and 
	local.tee	44
	i32.eqz
	br_if   	0                               # 0: down to label420
# %bb.9:
	local.get	34
	i32.eqz
	br_if   	1                               # 1: down to label418
# %bb.10:
	local.get	33
	i32.eqz
	br_if   	1                               # 1: down to label418
# %bb.11:
	local.get	35
	i32.eqz
	br_if   	1                               # 1: down to label418
# %bb.12:
	local.get	34
	i32.popcnt
	i32.const	1
	i32.gt_u
	br_if   	1                               # 1: down to label418
.LBB26_13:
	end_block                               # label420:
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label421
# %bb.14:
	local.get	32
	v128.const	0, 0
	v128.store	0:p2align=2
	local.get	32
	i32.const	16
	i32.add 
	i32.const	0
	i32.store	0
.LBB26_15:
	end_block                               # label421:
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
	i32.const	0
	local.get	5
	i32.store	last_content_capacity
	local.get	38
	i32.const	0
	i32.store	108
	local.get	38
	i32.const	0
	i32.store	76
	local.get	38
	i64.const	0
	i64.store	68:p2align=2
	local.get	38
	local.get	31
	i32.const	1
	local.get	31
	i32.const	1
	i32.gt_u
	i32.select
	i32.store	64
	local.get	38
	local.get	1
	i32.store	60
	local.get	38
	local.get	30
	i32.store	56
	local.get	38
	local.get	0
	i32.store	52
	i32.const	0
	local.set	45
	i32.const	0
	local.set	46
	i32.const	0
	local.set	47
	i32.const	0
	local.set	48
	i32.const	0
	local.set	49
	i32.const	0
	local.set	50
	block   	
	local.get	38
	i32.const	52
	i32.add 
	call	next_term_bank
	local.tee	1
	i32.const	1
	i32.lt_s
	br_if   	0                               # 0: down to label422
# %bb.16:
	i32.const	0
	local.get	34
	i32.const	-1
	i32.add 
	local.tee	39
	local.get	39
	local.get	34
	i32.gt_u
	i32.select
	local.set	51
	local.get	2
	i32.const	-28
	i32.add 
	local.set	52
	local.get	29
	i32.const	4
	i32.and 
	local.set	53
	local.get	2
	i32.const	-68
	i32.add 
	local.set	54
	local.get	3
	i32.const	1
	i32.shl 
	local.set	55
	local.get	29
	i32.const	2
	i32.and 
	local.set	56
	local.get	0
	i32.const	1
	i32.add 
	local.set	57
	local.get	36
	i32.const	0
	i32.ne  
	local.set	58
	local.get	28
	i32.const	0
	i32.ne  
	local.set	59
	i32.const	-1
	local.set	60
	i32.const	0
	local.set	45
	i32.const	0
	local.set	50
	i32.const	0
	local.set	49
	i32.const	0
	local.set	48
	i32.const	0
	local.set	47
	i32.const	0
	local.set	46
	i32.const	0
	local.set	31
	i32.const	0
	local.set	61
.LBB26_17:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB26_40 Depth 2
                                        #     Child Loop BB26_42 Depth 2
                                        #     Child Loop BB26_47 Depth 2
                                        #     Child Loop BB26_52 Depth 2
                                        #       Child Loop BB26_58 Depth 3
                                        #       Child Loop BB26_60 Depth 3
                                        #       Child Loop BB26_63 Depth 3
                                        #       Child Loop BB26_76 Depth 3
                                        #         Child Loop BB26_82 Depth 4
                                        #         Child Loop BB26_84 Depth 4
                                        #         Child Loop BB26_87 Depth 4
                                        #     Child Loop BB26_101 Depth 2
                                        #     Child Loop BB26_120 Depth 2
                                        #     Child Loop BB26_133 Depth 2
                                        #     Child Loop BB26_147 Depth 2
                                        #     Child Loop BB26_158 Depth 2
                                        #     Child Loop BB26_170 Depth 2
                                        #     Child Loop BB26_183 Depth 2
                                        #     Child Loop BB26_189 Depth 2
                                        #     Child Loop BB26_194 Depth 2
	loop    	                                # label423:
	block   	
	local.get	47
	local.get	3
	i32.ne  
	br_if   	0                               # 0: down to label424
# %bb.18:
	local.get	12
	local.get	3
	i32.store	0
	i32.const	-4
	local.set	39
	br      	3                               # 3: down to label418
.LBB26_19:                              #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label424:
	i32.const	0
	local.set	39
	local.get	38
	i32.const	0
	i32.store	48
	local.get	38
	i32.const	-1
	i32.store	44
	i32.const	0
	local.set	1
	block   	
	local.get	53
	i32.const	0
	i32.ne  
	local.get	47
	i32.const	0
	i32.ne  
	i32.and 
	local.tee	30
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label425
# %bb.20:                               #   in Loop: Header=BB26_17 Depth=1
	block   	
	local.get	31
	i32.eqz
	br_if   	0                               # 0: down to label426
# %bb.21:                               #   in Loop: Header=BB26_17 Depth=1
	i32.const	4
	local.set	1
	local.get	38
	i32.const	44
	i32.add 
	local.set	39
	br      	1                               # 1: down to label425
.LBB26_22:                              #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label426:
	local.get	38
	i32.const	44
	i32.add 
	i32.const	0
	local.get	52
	local.get	47
	i32.const	68
	i32.mul 
	i32.add 
	i32.load	0
	i32.const	511
	i32.gt_u
	local.tee	1
	i32.select
	local.set	39
.LBB26_23:                              #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label425:
	block   	
	local.get	0
	local.get	38
	i32.load	72
	local.tee	62
	local.get	38
	i32.load	76
	local.get	2
	local.get	47
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	63
	local.get	59
	local.get	38
	i32.const	48
	i32.add 
	local.get	2
	local.get	47
	local.get	39
	local.get	1
	local.get	58
	local.get	38
	i32.const	40
	i32.add 
	call	parse_row_single_pass
	br_if   	0                               # 0: down to label427
# %bb.24:
	i32.const	-1
	local.set	39
	br      	3                               # 3: down to label418
.LBB26_25:                              #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label427:
	local.get	38
	i32.load	44
	local.set	64
	block   	
	local.get	37
	i32.eqz
	br_if   	0                               # 0: down to label428
# %bb.26:                               #   in Loop: Header=BB26_17 Depth=1
	local.get	37
	local.get	47
	i32.const	2
	i32.shl 
	i32.add 
	local.get	64
	i32.store	0
.LBB26_27:                              #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label428:
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label429
# %bb.28:                               #   in Loop: Header=BB26_17 Depth=1
	local.get	64
	i32.const	-1
	i32.eq  
	br_if   	0                               # 0: down to label429
# %bb.29:                               #   in Loop: Header=BB26_17 Depth=1
	local.get	32
	local.get	32
	i32.load	4
	i32.const	1
	i32.add 
	i32.store	4
.LBB26_30:                              #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label429:
	block   	
	block   	
	local.get	30
	br_if   	0                               # 0: down to label431
# %bb.31:                               #   in Loop: Header=BB26_17 Depth=1
	local.get	31
	local.set	65
	br      	1                               # 1: down to label430
.LBB26_32:                              #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label431:
	i32.const	4
	local.set	65
	local.get	64
	i32.const	-1
	i32.ne  
	br_if   	0                               # 0: down to label430
# %bb.33:                               #   in Loop: Header=BB26_17 Depth=1
	i32.const	0
	local.get	31
	i32.const	-1
	i32.add 
	local.tee	39
	local.get	39
	local.get	31
	i32.gt_u
	i32.select
	local.set	65
.LBB26_34:                              #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label430:
	local.get	38
	local.get	63
	i32.load	0
	local.tee	30
	i32.store	36
	local.get	38
	local.get	63
	i32.load	8
	local.tee	1
	i32.store	32
	local.get	38
	local.get	63
	i32.load	4
	local.tee	28
	i32.store	28
	local.get	38
	local.get	63
	i32.load	12
	local.tee	39
	i32.store	24
	i32.const	0
	local.set	66
	local.get	38
	i32.const	0
	i32.store	16
	local.get	38
	i32.const	0
	i32.store	12
	block   	
	local.get	39
	i32.const	2
	i32.ne  
	br_if   	0                               # 0: down to label432
# %bb.35:                               #   in Loop: Header=BB26_17 Depth=1
	local.get	0
	local.get	1
	i32.add 
	local.tee	31
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label432
# %bb.36:                               #   in Loop: Header=BB26_17 Depth=1
	local.get	31
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	66
.LBB26_37:                              #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label432:
	block   	
	local.get	66
	br_if   	0                               # 0: down to label433
# %bb.38:                               #   in Loop: Header=BB26_17 Depth=1
	local.get	28
	local.get	39
	i32.ne  
	br_if   	0                               # 0: down to label433
# %bb.39:                               #   in Loop: Header=BB26_17 Depth=1
	i32.const	0
	local.set	31
	local.get	0
	local.get	30
	i32.add 
	local.tee	67
	local.set	39
	local.get	0
	local.get	1
	i32.add 
	local.tee	68
	local.set	1
.LBB26_40:                              #   Parent Loop BB26_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label434:
	block   	
	local.get	28
	local.get	31
	i32.add 
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label435
# %bb.41:                               #   in Loop: Header=BB26_17 Depth=1
	i32.const	0
	local.set	30
	local.get	28
	local.set	36
.LBB26_42:                              #   Parent Loop BB26_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label437:
	block   	
	local.get	31
	local.get	36
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label438
# %bb.43:                               #   in Loop: Header=BB26_17 Depth=1
	local.get	30
	local.get	31
	i32.sub 
	local.tee	39
	local.get	28
	i32.lt_u
	br_if   	2                               # 2: down to label436
# %bb.44:                               #   in Loop: Header=BB26_17 Depth=1
	i32.const	1
	local.set	66
	br      	5                               # 5: down to label433
.LBB26_45:                              #   in Loop: Header=BB26_42 Depth=2
	end_block                               # label438:
	local.get	1
	local.get	30
	i32.add 
	local.set	69
	local.get	39
	local.get	30
	i32.add 
	local.set	70
	local.get	36
	i32.const	-8
	i32.add 
	local.set	36
	local.get	30
	i32.const	8
	i32.add 
	local.set	30
	local.get	70
	i64.load	0:p2align=0
	local.get	69
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label437
# %bb.46:                               #   in Loop: Header=BB26_17 Depth=1
	end_loop
	i32.const	0
	local.set	66
	br      	3                               # 3: down to label433
.LBB26_47:                              #   Parent Loop BB26_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	end_block                               # label436:
	loop    	                                # label439:
	local.get	67
	local.get	39
	i32.add 
	i32.load8_u	0
	local.tee	1
	local.get	68
	local.get	39
	i32.add 
	i32.load8_u	0
	local.tee	31
	i32.eq  
	local.set	66
	local.get	1
	local.get	31
	i32.ne  
	br_if   	3                               # 3: down to label433
# %bb.48:                               #   in Loop: Header=BB26_47 Depth=2
	local.get	39
	i32.const	1
	i32.add 
	local.tee	39
	local.get	28
	i32.lt_u
	br_if   	0                               # 0: up to label439
	br      	3                               # 3: down to label433
.LBB26_49:                              #   in Loop: Header=BB26_40 Depth=2
	end_loop
	end_block                               # label435:
	local.get	39
	i32.const	16
	i32.add 
	local.set	30
	local.get	1
	i32.const	16
	i32.add 
	local.set	36
	local.get	39
	v128.load	0:p2align=0
	local.set	40
	local.get	1
	v128.load	0:p2align=0
	local.set	41
	local.get	39
	i32.const	32
	i32.add 
	local.set	39
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	31
	i32.const	-32
	i32.add 
	local.set	31
	local.get	36
	v128.load	0:p2align=0
	local.get	30
	v128.load	0:p2align=0
	v128.xor
	local.get	41
	local.get	40
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label434
# %bb.50:                               #   in Loop: Header=BB26_17 Depth=1
	end_loop
	i32.const	0
	local.set	66
.LBB26_51:                              #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label433:
	local.get	2
	local.get	47
	i32.const	-1
	i32.add 
	local.tee	71
	i32.const	68
	i32.mul 
	i32.add 
	local.set	72
	i32.const	0
	local.set	70
	local.get	38
	i32.const	36
	i32.add 
	local.set	39
	local.get	38
	i32.const	28
	i32.add 
	local.set	1
	local.get	38
	i32.const	16
	i32.add 
	local.set	73
	i32.const	1
	local.set	74
	local.get	38
	i32.load	40
	local.set	75
.LBB26_52:                              #   Parent Loop BB26_17 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB26_58 Depth 3
                                        #       Child Loop BB26_60 Depth 3
                                        #       Child Loop BB26_63 Depth 3
                                        #       Child Loop BB26_76 Depth 3
                                        #         Child Loop BB26_82 Depth 4
                                        #         Child Loop BB26_84 Depth 4
                                        #         Child Loop BB26_87 Depth 4
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	loop    	                                # label447:
	block   	
	local.get	66
	local.get	70
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label448
# %bb.53:                               #   in Loop: Header=BB26_17 Depth=1
	local.get	38
	local.get	38
	i32.load	16
	i32.store	12
	br      	2                               # 2: down to label446
.LBB26_54:                              #   in Loop: Header=BB26_52 Depth=2
	end_block                               # label448:
	local.get	1
	i32.load	0
	local.tee	76
	i32.const	-2
	i32.add 
	local.set	28
	local.get	39
	i32.load	0
	local.set	77
	block   	
	block   	
	block   	
	block   	
	local.get	47
	i32.eqz
	br_if   	0                               # 0: down to label452
# %bb.55:                               #   in Loop: Header=BB26_52 Depth=2
	local.get	28
	i32.const	32
	i32.gt_u
	br_if   	0                               # 0: down to label452
# %bb.56:                               #   in Loop: Header=BB26_52 Depth=2
	local.get	76
	local.get	72
	i32.const	4
	i32.const	12
	local.get	74
	i32.const	1
	i32.and 
	local.tee	78
	i32.select
	i32.add 
	i32.load	0
	i32.ne  
	br_if   	1                               # 1: down to label451
# %bb.57:                               #   in Loop: Header=BB26_52 Depth=2
	local.get	0
	local.get	77
	i32.add 
	local.set	36
	local.get	57
	local.get	77
	i32.add 
	local.set	67
	local.get	0
	local.get	72
	i32.const	0
	i32.const	8
	local.get	78
	i32.select
	i32.add 
	i32.load	0
	local.tee	39
	i32.add 
	local.set	69
	local.get	57
	local.get	39
	i32.add 
	local.set	68
	i32.const	17
	local.set	1
	local.get	28
	local.set	39
.LBB26_58:                              #   Parent Loop BB26_17 Depth=1
                                        #     Parent Loop BB26_52 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label453:
	block   	
	local.get	39
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label454
# %bb.59:                               #   in Loop: Header=BB26_52 Depth=2
	local.get	1
	i32.const	-17
	i32.add 
	local.set	1
.LBB26_60:                              #   Parent Loop BB26_17 Depth=1
                                        #     Parent Loop BB26_52 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	block   	
	loop    	                                # label456:
	block   	
	local.get	39
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label457
# %bb.61:                               #   in Loop: Header=BB26_52 Depth=2
	local.get	1
	local.get	28
	i32.lt_u
	br_if   	2                               # 2: down to label455
	br      	7                               # 7: down to label450
.LBB26_62:                              #   in Loop: Header=BB26_60 Depth=3
	end_block                               # label457:
	local.get	68
	local.get	1
	i32.add 
	local.set	31
	local.get	67
	local.get	1
	i32.add 
	local.set	30
	local.get	39
	i32.const	-8
	i32.add 
	local.set	39
	local.get	1
	i32.const	8
	i32.add 
	local.set	1
	local.get	30
	i64.load	0:p2align=0
	local.get	31
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label456
	br      	4                               # 4: down to label452
.LBB26_63:                              #   Parent Loop BB26_17 Depth=1
                                        #     Parent Loop BB26_52 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	end_loop
	end_block                               # label455:
	loop    	                                # label458:
	local.get	67
	local.get	1
	i32.add 
	i32.load8_u	0
	local.get	68
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	3                               # 3: down to label452
# %bb.64:                               #   in Loop: Header=BB26_63 Depth=3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	local.get	28
	i32.ge_u
	br_if   	5                               # 5: down to label450
	br      	0                               # 0: up to label458
.LBB26_65:                              #   in Loop: Header=BB26_58 Depth=3
	end_loop
	end_block                               # label454:
	local.get	36
	local.get	1
	i32.add 
	local.set	31
	local.get	69
	local.get	1
	i32.add 
	local.set	30
	local.get	39
	i32.const	-32
	i32.add 
	local.set	39
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	30
	v128.load	0:p2align=0
	local.get	31
	v128.load	0:p2align=0
	v128.xor
	local.get	30
	i32.const	-16
	i32.add 
	v128.load	0:p2align=0
	local.get	31
	i32.const	-16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label453
.LBB26_66:                              #   in Loop: Header=BB26_52 Depth=2
	end_loop
	end_block                               # label452:
	local.get	76
	i32.const	2
	i32.lt_u
	br_if   	5                               # 5: down to label445
.LBB26_67:                              #   in Loop: Header=BB26_52 Depth=2
	end_block                               # label451:
	block   	
	block   	
	local.get	75
	local.get	70
	i32.shr_u
	i32.const	1
	i32.and 
	br_if   	0                               # 0: down to label460
# %bb.68:                               #   in Loop: Header=BB26_52 Depth=2
	local.get	77
	i32.const	1
	i32.add 
	local.set	39
	local.get	0
	local.set	79
	br      	1                               # 1: down to label459
.LBB26_69:                              #   in Loop: Header=BB26_52 Depth=2
	end_block                               # label460:
	local.get	56
	i32.eqz
	br_if   	5                               # 5: down to label445
# %bb.70:                               #   in Loop: Header=BB26_52 Depth=2
	local.get	0
	local.get	77
	i32.add 
	local.get	76
	local.get	13
	local.get	48
	i32.add 
	local.get	14
	local.get	48
	i32.sub 
	call	decode_escaped_key
	local.tee	28
	i32.const	0
	i32.lt_s
	br_if   	5                               # 5: down to label445
# %bb.71:                               #   in Loop: Header=BB26_52 Depth=2
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label461
# %bb.72:                               #   in Loop: Header=BB26_52 Depth=2
	local.get	32
	local.get	32
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
.LBB26_73:                              #   in Loop: Header=BB26_52 Depth=2
	end_block                               # label461:
	local.get	48
	local.set	39
	local.get	13
	local.set	79
.LBB26_74:                              #   in Loop: Header=BB26_52 Depth=2
	end_block                               # label459:
	local.get	28
	i32.const	65535
	i32.gt_u
	br_if   	4                               # 4: down to label445
# %bb.75:                               #   in Loop: Header=BB26_52 Depth=2
	local.get	79
	local.get	39
	i32.add 
	local.tee	77
	local.get	28
	i32.const	-2128831035
	call	hash_content_xxh32
	local.tee	80
	local.get	28
	i32.const	-2048144789
	i32.mul 
	i32.xor 
	local.tee	39
	i32.const	16
	i32.shr_u
	local.get	39
	i32.xor 
	local.get	43
	i32.and 
	local.set	67
	i32.const	0
	local.set	76
.LBB26_76:                              #   Parent Loop BB26_17 Depth=1
                                        #     Parent Loop BB26_52 Depth=2
                                        # =>    This Loop Header: Depth=3
                                        #         Child Loop BB26_82 Depth 4
                                        #         Child Loop BB26_84 Depth 4
                                        #         Child Loop BB26_87 Depth 4
	block   	
	loop    	                                # label463:
	local.get	20
	local.get	67
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	39
	i32.eqz
	br_if   	1                               # 1: down to label462
# %bb.77:                               #   in Loop: Header=BB26_76 Depth=3
	block   	
	local.get	39
	i32.const	-1
	i32.add 
	local.tee	68
	local.get	49
	i32.lt_u
	br_if   	0                               # 0: down to label464
# %bb.78:
	i32.const	-3
	local.set	39
	br      	15                              # 15: down to label418
.LBB26_79:                              #   in Loop: Header=BB26_76 Depth=3
	end_block                               # label464:
	block   	
	local.get	17
	local.get	68
	i32.const	2
	i32.shl 
	local.tee	39
	i32.add 
	i32.load	0
	local.get	80
	i32.ne  
	br_if   	0                               # 0: down to label465
# %bb.80:                               #   in Loop: Header=BB26_76 Depth=3
	local.get	28
	local.get	15
	local.get	68
	i32.const	1
	i32.shl 
	i32.add 
	i32.load16_u	0
	i32.ne  
	br_if   	0                               # 0: down to label465
# %bb.81:                               #   in Loop: Header=BB26_76 Depth=3
	i32.const	0
	local.set	31
	local.get	13
	local.get	16
	local.get	39
	i32.add 
	i32.load	0
	i32.add 
	local.tee	78
	local.set	39
	local.get	77
	local.set	1
.LBB26_82:                              #   Parent Loop BB26_17 Depth=1
                                        #     Parent Loop BB26_52 Depth=2
                                        #       Parent Loop BB26_76 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	loop    	                                # label466:
	block   	
	local.get	28
	local.get	31
	i32.add 
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label467
# %bb.83:                               #   in Loop: Header=BB26_76 Depth=3
	i32.const	0
	local.set	30
	local.get	28
	local.set	36
.LBB26_84:                              #   Parent Loop BB26_17 Depth=1
                                        #     Parent Loop BB26_52 Depth=2
                                        #       Parent Loop BB26_76 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	block   	
	loop    	                                # label469:
	block   	
	local.get	31
	local.get	36
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label470
# %bb.85:                               #   in Loop: Header=BB26_76 Depth=3
	local.get	30
	local.get	31
	i32.sub 
	local.tee	39
	local.get	28
	i32.lt_u
	br_if   	2                               # 2: down to label468
	br      	9                               # 9: down to label449
.LBB26_86:                              #   in Loop: Header=BB26_84 Depth=4
	end_block                               # label470:
	local.get	1
	local.get	30
	i32.add 
	local.set	69
	local.get	39
	local.get	30
	i32.add 
	local.set	70
	local.get	36
	i32.const	-8
	i32.add 
	local.set	36
	local.get	30
	i32.const	8
	i32.add 
	local.set	30
	local.get	70
	i64.load	0:p2align=0
	local.get	69
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label469
	br      	4                               # 4: down to label465
.LBB26_87:                              #   Parent Loop BB26_17 Depth=1
                                        #     Parent Loop BB26_52 Depth=2
                                        #       Parent Loop BB26_76 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	end_loop
	end_block                               # label468:
	loop    	                                # label471:
	local.get	78
	local.get	39
	i32.add 
	i32.load8_u	0
	local.get	77
	local.get	39
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	3                               # 3: down to label465
# %bb.88:                               #   in Loop: Header=BB26_87 Depth=4
	local.get	39
	i32.const	1
	i32.add 
	local.tee	39
	local.get	28
	i32.ge_u
	br_if   	7                               # 7: down to label449
	br      	0                               # 0: up to label471
.LBB26_89:                              #   in Loop: Header=BB26_82 Depth=4
	end_loop
	end_block                               # label467:
	local.get	39
	i32.const	16
	i32.add 
	local.set	30
	local.get	1
	i32.const	16
	i32.add 
	local.set	36
	local.get	39
	v128.load	0:p2align=0
	local.set	40
	local.get	1
	v128.load	0:p2align=0
	local.set	41
	local.get	39
	i32.const	32
	i32.add 
	local.set	39
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	31
	i32.const	-32
	i32.add 
	local.set	31
	local.get	36
	v128.load	0:p2align=0
	local.get	30
	v128.load	0:p2align=0
	v128.xor
	local.get	41
	local.get	40
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label466
.LBB26_90:                              #   in Loop: Header=BB26_76 Depth=3
	end_loop
	end_block                               # label465:
	local.get	67
	i32.const	1
	i32.add 
	local.get	43
	i32.and 
	local.set	67
	local.get	76
	i32.const	1
	i32.add 
	local.tee	76
	local.get	21
	i32.ne  
	br_if   	0                               # 0: up to label463
.LBB26_91:                              #   in Loop: Header=BB26_52 Depth=2
	end_loop
	end_block                               # label462:
	local.get	49
	local.get	55
	i32.ge_u
	br_if   	4                               # 4: down to label445
# %bb.92:                               #   in Loop: Header=BB26_52 Depth=2
	local.get	20
	local.get	67
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	39
	i32.load	0
	br_if   	4                               # 4: down to label445
# %bb.93:                               #   in Loop: Header=BB26_52 Depth=2
	local.get	28
	local.get	48
	i32.add 
	local.tee	1
	local.get	14
	i32.gt_u
	br_if   	4                               # 4: down to label445
# %bb.94:                               #   in Loop: Header=BB26_52 Depth=2
	block   	
	local.get	79
	local.get	13
	i32.eq  
	br_if   	0                               # 0: down to label472
# %bb.95:                               #   in Loop: Header=BB26_52 Depth=2
	local.get	13
	local.get	48
	i32.add 
	local.get	77
	local.get	28
	call	copy_valid_utf8
	i32.eqz
	br_if   	5                               # 5: down to label445
.LBB26_96:                              #   in Loop: Header=BB26_52 Depth=2
	end_block                               # label472:
	local.get	16
	local.get	49
	i32.const	2
	i32.shl 
	local.tee	31
	i32.add 
	local.get	48
	i32.store	0
	local.get	17
	local.get	31
	i32.add 
	local.get	80
	i32.store	0
	local.get	15
	local.get	49
	i32.const	1
	i32.shl 
	i32.add 
	local.get	28
	i32.store16	0
	local.get	39
	local.get	49
	i32.const	1
	i32.add 
	local.tee	31
	i32.store	0
	local.get	49
	local.set	68
	local.get	1
	local.set	48
	local.get	31
	local.set	49
	br      	1                               # 1: down to label449
.LBB26_97:                              #   in Loop: Header=BB26_52 Depth=2
	end_block                               # label450:
	local.get	18
	local.get	19
	local.get	78
	i32.select
	local.get	71
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.set	68
.LBB26_98:                              #   in Loop: Header=BB26_52 Depth=2
	end_block                               # label449:
	local.get	73
	local.get	68
	i32.store	0
	i32.const	1
	local.set	70
	local.get	74
	i32.const	1
	i32.and 
	local.set	31
	local.get	38
	i32.const	32
	i32.add 
	local.set	39
	local.get	38
	i32.const	24
	i32.add 
	local.set	1
	local.get	38
	i32.const	12
	i32.add 
	local.set	73
	i32.const	0
	local.set	74
	local.get	31
	br_if   	0                               # 0: up to label447
.LBB26_99:                              #   in Loop: Header=BB26_17 Depth=1
	end_loop
	end_block                               # label446:
	local.get	18
	local.get	47
	i32.const	2
	i32.shl 
	local.tee	69
	i32.add 
	local.get	38
	i32.load	16
	i32.store	0
	local.get	19
	local.get	69
	i32.add 
	local.get	38
	i32.load	12
	i32.store	0
	local.get	24
	local.get	47
	i32.add 
	local.get	66
	i32.store8	0
	local.get	63
	i32.load	32
	local.tee	28
	local.get	62
	i32.ge_u
	br_if   	0                               # 0: down to label445
# %bb.100:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	28
	local.set	31
.LBB26_101:                             #   Parent Loop BB26_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label474:
	block   	
	local.get	62
	local.get	31
	local.tee	39
	i32.ne  
	br_if   	0                               # 0: down to label475
# %bb.102:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	62
	local.set	39
	br      	2                               # 2: down to label473
.LBB26_103:                             #   in Loop: Header=BB26_101 Depth=2
	end_block                               # label475:
	block   	
	block   	
	local.get	0
	local.get	39
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	-10
	i32.add 
	br_table 	{3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0} # 1: down to label476
                                        # 3: down to label473
                                        # 0: down to label477
.LBB26_104:                             #   in Loop: Header=BB26_101 Depth=2
	end_block                               # label477:
	local.get	1
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label473
# %bb.105:                              #   in Loop: Header=BB26_101 Depth=2
	local.get	1
	i32.const	125
	i32.eq  
	br_if   	2                               # 2: down to label473
.LBB26_106:                             #   in Loop: Header=BB26_101 Depth=2
	end_block                               # label476:
	local.get	39
	i32.const	1
	i32.add 
	local.set	31
	local.get	1
	i32.const	9
	i32.ne  
	br_if   	0                               # 0: up to label474
.LBB26_107:                             #   in Loop: Header=BB26_17 Depth=1
	end_loop
	end_block                               # label473:
	local.get	39
	local.get	28
	i32.eq  
	br_if   	0                               # 0: down to label445
# %bb.108:                              #   in Loop: Header=BB26_17 Depth=1
	block   	
	block   	
	block   	
	local.get	39
	local.get	28
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label480
# %bb.109:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	0
	local.get	28
	i32.add 
	local.tee	1
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label480
# %bb.110:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	1
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label480
# %bb.111:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	1
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label480
# %bb.112:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	1
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label479
.LBB26_113:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label480:
	i32.const	1
	local.set	70
	local.get	28
	local.set	31
	block   	
	local.get	39
	local.get	28
	i32.le_u
	br_if   	0                               # 0: down to label481
# %bb.114:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	0
	local.get	28
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	45
	i32.ne  
	local.set	70
	local.get	28
	local.get	1
	i32.const	45
	i32.eq  
	i32.add 
	local.set	31
.LBB26_115:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label481:
	local.get	39
	local.get	31
	i32.le_u
	br_if   	2                               # 2: down to label445
# %bb.116:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	0
	local.get	31
	i32.add 
	local.tee	1
	i32.load8_u	0
	local.tee	30
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	246
	i32.lt_u
	br_if   	2                               # 2: down to label445
# %bb.117:                              #   in Loop: Header=BB26_17 Depth=1
	block   	
	local.get	31
	i32.const	1
	i32.add 
	local.get	39
	i32.ge_u
	br_if   	0                               # 0: down to label482
# %bb.118:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	30
	i32.const	255
	i32.and 
	i32.const	48
	i32.eq  
	br_if   	3                               # 3: down to label445
.LBB26_119:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label482:
	i32.const	2147483647
	i32.const	-2147483648
	local.get	70
	i32.select
	local.set	36
	local.get	39
	local.get	31
	i32.sub 
	local.set	30
	i32.const	0
	local.set	39
.LBB26_120:                             #   Parent Loop BB26_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label483:
	local.get	1
	i32.load8_u	0
	local.tee	31
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	246
	i32.lt_u
	br_if   	3                               # 3: down to label445
# %bb.121:                              #   in Loop: Header=BB26_120 Depth=2
	local.get	39
	local.get	36
	local.get	31
	i32.const	-48
	i32.add 
	local.tee	31
	i32.sub 
	i32.const	10
	i32.div_u
	i32.gt_u
	br_if   	3                               # 3: down to label445
# %bb.122:                              #   in Loop: Header=BB26_120 Depth=2
	local.get	1
	i32.const	1
	i32.add 
	local.set	1
	local.get	31
	local.get	39
	i32.const	10
	i32.mul 
	i32.add 
	local.set	39
	local.get	30
	i32.const	-1
	i32.add 
	local.tee	30
	br_if   	0                               # 0: up to label483
# %bb.123:                              #   in Loop: Header=BB26_17 Depth=1
	end_loop
	local.get	39
	i32.const	0
	local.get	39
	i32.sub 
	local.get	70
	i32.select
	local.tee	39
	br_if   	1                               # 1: down to label478
# %bb.124:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	0
	local.get	28
	i32.add 
	i32.load8_u	0
	i32.const	45
	i32.eq  
	br_if   	2                               # 2: down to label445
.LBB26_125:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label479:
	i32.const	0
	local.set	39
.LBB26_126:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label478:
	local.get	25
	local.get	69
	i32.add 
	local.get	39
	i32.store	0
	i32.const	-1
	local.set	39
	local.get	38
	i32.const	-1
	i32.store	8
	block   	
	local.get	63
	i32.load	44
	local.tee	1
	i32.const	-1
	i32.eq  
	br_if   	0                               # 0: down to label484
# %bb.127:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	38
	i32.const	0
	i32.store	4
	local.get	0
	local.get	62
	local.get	1
	local.get	38
	i32.const	4
	i32.add 
	call	scan_scalar_span
	i32.eqz
	br_if   	1                               # 1: down to label445
# %bb.128:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	0
	local.get	1
	local.get	38
	i32.load	4
	i32.const	-1
	local.get	38
	i32.const	8
	i32.add 
	call	parse_int32_token
	i32.eqz
	br_if   	1                               # 1: down to label445
# %bb.129:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	38
	i32.load	8
	local.set	39
.LBB26_130:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label484:
	local.get	26
	local.get	69
	i32.add 
	local.get	39
	i32.store	0
	local.get	44
	i32.eqz
	br_if   	1                               # 1: down to label444
# %bb.131:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	35
	local.get	69
	i32.add 
	local.get	0
	local.get	63
	call	raw_term_content_hash
	local.tee	30
	i32.store	0
	local.get	34
	i32.eqz
	br_if   	4                               # 4: down to label441
# %bb.132:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	34
	local.set	1
	local.get	30
	local.set	39
.LBB26_133:                             #   Parent Loop BB26_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label485:
	block   	
	local.get	33
	local.get	39
	local.get	51
	i32.and 
	local.tee	31
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	36
	i32.load	0
	local.tee	39
	br_if   	0                               # 0: down to label486
# %bb.134:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	36
	local.get	47
	i32.const	1
	i32.add 
	i32.store	0
	br      	6                               # 6: down to label441
.LBB26_135:                             #   in Loop: Header=BB26_133 Depth=2
	end_block                               # label486:
	block   	
	local.get	39
	i32.const	-1
	i32.add 
	local.tee	39
	local.get	47
	i32.lt_u
	br_if   	0                               # 0: down to label487
# %bb.136:
	i32.const	-3
	local.set	39
	br      	10                              # 10: down to label418
.LBB26_137:                             #   in Loop: Header=BB26_133 Depth=2
	end_block                               # label487:
	block   	
	local.get	35
	local.get	39
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.get	30
	i32.ne  
	br_if   	0                               # 0: down to label488
# %bb.138:                              #   in Loop: Header=BB26_133 Depth=2
	local.get	0
	local.get	63
	local.get	2
	local.get	39
	i32.const	68
	i32.mul 
	i32.add 
	local.get	39
	local.get	64
	i32.eq  
	call	raw_term_content_tokens_equal
	i32.eqz
	br_if   	0                               # 0: down to label488
# %bb.139:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	32
	i32.eqz
	br_if   	4                               # 4: down to label443
# %bb.140:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	32
	local.get	32
	i32.load	8
	i32.const	1
	i32.add 
	i32.store	8
	br      	4                               # 4: down to label443
.LBB26_141:                             #   in Loop: Header=BB26_133 Depth=2
	end_block                               # label488:
	local.get	31
	i32.const	1
	i32.add 
	local.set	39
	local.get	1
	i32.const	-1
	i32.add 
	local.tee	1
	br_if   	0                               # 0: up to label485
	br      	5                               # 5: down to label441
.LBB26_142:
	end_loop
	end_block                               # label445:
	local.get	12
	local.get	47
	i32.store	0
	i32.const	-5
	local.set	39
	br      	7                               # 7: down to label418
.LBB26_143:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label444:
	block   	
	local.get	64
	i32.const	-1
	i32.eq  
	br_if   	0                               # 0: down to label489
# %bb.144:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	0
	local.get	63
	local.get	2
	local.get	64
	i32.const	68
	i32.mul 
	i32.add 
	i32.const	1
	call	raw_term_content_tokens_equal
	i32.eqz
	br_if   	0                               # 0: down to label489
# %bb.145:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	38
	i32.const	80
	i32.add 
	local.get	47
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	local.get	38
	i32.const	80
	i32.add 
	local.get	64
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	i32.load	0
	i32.store	0
	local.get	64
	local.set	39
	br      	1                               # 1: down to label443
.LBB26_146:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label489:
	local.get	0
	local.get	63
	call	raw_term_content_quick_signature
	local.set	30
	local.get	54
	local.set	1
	local.get	60
	local.set	39
	local.get	47
	i32.const	0
	local.get	47
	i32.const	-4
	i32.add 
	local.tee	31
	local.get	31
	local.get	47
	i32.gt_u
	i32.select
	local.tee	36
	i32.le_u
	br_if   	1                               # 1: down to label442
.LBB26_147:                             #   Parent Loop BB26_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label491:
	block   	
	local.get	38
	i32.const	80
	i32.add 
	local.get	39
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	i32.load	0
	local.get	30
	i32.ne  
	br_if   	0                               # 0: down to label492
# %bb.148:                              #   in Loop: Header=BB26_147 Depth=2
	local.get	0
	local.get	63
	local.get	1
	local.get	64
	local.get	39
	i32.eq  
	call	raw_term_content_tokens_equal
	br_if   	2                               # 2: down to label490
.LBB26_149:                             #   in Loop: Header=BB26_147 Depth=2
	end_block                               # label492:
	local.get	1
	i32.const	-68
	i32.add 
	local.set	1
	local.get	39
	local.get	36
	i32.gt_u
	local.set	31
	local.get	39
	i32.const	-1
	i32.add 
	local.set	39
	local.get	31
	i32.eqz
	br_if   	3                               # 3: down to label442
	br      	0                               # 0: up to label491
.LBB26_150:                             #   in Loop: Header=BB26_17 Depth=1
	end_loop
	end_block                               # label490:
	local.get	38
	i32.const	80
	i32.add 
	local.get	47
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	local.get	30
	i32.store	0
.LBB26_151:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label443:
	block   	
	block   	
	local.get	53
	br_if   	0                               # 0: down to label494
# %bb.152:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	65
	local.set	31
	br      	1                               # 1: down to label493
.LBB26_153:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label494:
	i32.const	4
	local.set	31
	local.get	61
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label493
# %bb.154:                              #   in Loop: Header=BB26_17 Depth=1
	i32.const	4
	local.get	65
	local.get	61
	i32.const	3
	i32.eq  
	i32.select
	local.set	31
	local.get	61
	i32.const	1
	i32.add 
	local.set	61
.LBB26_155:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label493:
	local.get	6
	local.get	69
	i32.const	2
	i32.shl 
	i32.add 
	local.get	6
	local.get	39
	i32.const	4
	i32.shl 
	i32.add 
	v128.load	0:p2align=2
	v128.store	0:p2align=2
	local.get	9
	local.get	69
	i32.add 
	local.get	9
	local.get	39
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.store	0
	local.get	46
	i32.const	1
	i32.add 
	local.set	46
	br      	2                               # 2: down to label440
.LBB26_156:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label442:
	local.get	38
	i32.const	80
	i32.add 
	local.get	47
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	local.get	30
	i32.store	0
.LBB26_157:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label441:
	local.get	38
	i32.const	0
	i32.store	4
	local.get	38
	i32.const	0
	i32.store	0
	block   	
	local.get	0
	local.get	63
	local.get	4
	local.get	5
	local.get	38
	i32.const	108
	i32.add 
	local.get	38
	i32.const	4
	i32.add 
	local.get	38
	local.get	29
	local.get	32
	call	encode_term_content_token_binary_row
	br_if   	0                               # 0: down to label495
.LBB26_158:                             #   Parent Loop BB26_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label496:
	local.get	38
	local.get	45
	i32.store	108
	i32.const	-2
	local.set	39
	local.get	5
	i32.const	2147483646
	i32.gt_u
	br_if   	5                               # 5: down to label418
# %bb.159:                              #   in Loop: Header=BB26_158 Depth=2
	local.get	4
	local.get	5
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	31
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	5                               # 5: down to label418
# %bb.160:                              #   in Loop: Header=BB26_158 Depth=2
	i32.const	0
	i32.load	heap_ptr
	local.get	31
	local.get	4
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	5                               # 5: down to label418
# %bb.161:                              #   in Loop: Header=BB26_158 Depth=2
	i32.const	2147483647
	local.get	5
	i32.const	1
	i32.shr_u
	local.tee	30
	i32.const	1048576
	local.get	30
	i32.const	1048576
	i32.gt_u
	i32.select
	local.tee	30
	local.get	5
	i32.add 
	local.get	5
	local.get	30
	i32.const	2147483647
	i32.xor 
	i32.gt_u
	i32.select
	local.tee	5
	local.get	31
	i32.sub 
	i32.const	7
	i32.add 
	local.set	30
	local.get	1
	local.set	31
	block   	
	local.get	1
	br_if   	0                               # 0: down to label497
# %bb.162:                              #   in Loop: Header=BB26_158 Depth=2
	i32.const	__heap_base
	local.set	31
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB26_163:                             #   in Loop: Header=BB26_158 Depth=2
	end_block                               # label497:
	local.get	31
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	31
	local.get	30
	i32.const	-8
	i32.and 
	local.tee	30
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	5                               # 5: down to label418
# %bb.164:                              #   in Loop: Header=BB26_158 Depth=2
	block   	
	local.get	31
	local.get	30
	i32.add 
	local.tee	30
	i32.const	16
	i32.shr_u
	local.get	30
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	36
	memory.size	0
	local.tee	28
	i32.le_u
	br_if   	0                               # 0: down to label498
# %bb.165:                              #   in Loop: Header=BB26_158 Depth=2
	local.get	36
	local.get	28
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	6                               # 6: down to label418
.LBB26_166:                             #   in Loop: Header=BB26_158 Depth=2
	end_block                               # label498:
	i32.const	0
	local.get	30
	i32.store	heap_ptr
	local.get	31
	i32.eqz
	br_if   	5                               # 5: down to label418
# %bb.167:                              #   in Loop: Header=BB26_158 Depth=2
	local.get	31
	local.get	1
	i32.ne  
	br_if   	5                               # 5: down to label418
# %bb.168:                              #   in Loop: Header=BB26_158 Depth=2
	i32.const	0
	local.get	5
	i32.store	last_content_capacity
	local.get	0
	local.get	63
	local.get	4
	local.get	5
	local.get	38
	i32.const	108
	i32.add 
	local.get	38
	i32.const	4
	i32.add 
	local.get	38
	local.get	29
	local.get	32
	call	encode_term_content_token_binary_row
	i32.eqz
	br_if   	0                               # 0: up to label496
.LBB26_169:                             #   in Loop: Header=BB26_17 Depth=1
	end_loop
	end_block                               # label495:
	local.get	38
	i32.load	0
	local.tee	70
	i32.const	-1640531535
	i32.mul 
	local.get	38
	i32.load	4
	local.tee	36
	i32.xor 
	local.tee	39
	i32.const	16
	i32.shr_u
	local.get	39
	i32.xor 
	local.get	42
	i32.and 
	local.set	1
	local.get	38
	i32.load	108
	local.tee	67
	local.get	45
	i32.sub 
	local.set	28
	local.get	8
	local.set	31
.LBB26_170:                             #   Parent Loop BB26_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	block   	
	block   	
	block   	
	loop    	                                # label504:
	local.get	7
	local.get	1
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	39
	i32.eqz
	br_if   	1                               # 1: down to label503
# %bb.171:                              #   in Loop: Header=BB26_170 Depth=2
	block   	
	local.get	39
	i32.const	-1
	i32.add 
	local.tee	39
	local.get	47
	i32.lt_u
	br_if   	0                               # 0: down to label505
# %bb.172:
	i32.const	-3
	local.set	39
	br      	10                              # 10: down to label418
.LBB26_173:                             #   in Loop: Header=BB26_170 Depth=2
	end_block                               # label505:
	block   	
	local.get	6
	local.get	39
	i32.const	4
	i32.shl 
	i32.add 
	local.tee	30
	i32.load	8
	local.get	36
	i32.ne  
	br_if   	0                               # 0: down to label506
# %bb.174:                              #   in Loop: Header=BB26_170 Depth=2
	local.get	30
	i32.load	12
	local.get	70
	i32.ne  
	br_if   	0                               # 0: down to label506
# %bb.175:                              #   in Loop: Header=BB26_170 Depth=2
	local.get	30
	i32.load	4
	local.get	28
	i32.ne  
	br_if   	0                               # 0: down to label506
# %bb.176:                              #   in Loop: Header=BB26_170 Depth=2
	local.get	4
	local.get	30
	i32.load	0
	local.tee	30
	local.get	45
	local.get	28
	call	content_bytes_equal
	br_if   	3                               # 3: down to label502
.LBB26_177:                             #   in Loop: Header=BB26_170 Depth=2
	end_block                               # label506:
	local.get	1
	i32.const	1
	i32.add 
	local.get	42
	i32.and 
	local.set	1
	local.get	31
	i32.const	-1
	i32.add 
	local.tee	31
	br_if   	0                               # 0: up to label504
.LBB26_178:                             #   in Loop: Header=BB26_17 Depth=1
	end_loop
	end_block                               # label503:
	i32.const	-3
	local.set	39
	local.get	7
	local.get	1
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	76
	i32.load	0
	br_if   	7                               # 7: down to label418
# %bb.179:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	50
	i32.const	-1
	i32.eq  
	br_if   	7                               # 7: down to label418
# %bb.180:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	6
	local.get	69
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	39
	local.get	70
	i32.store	12
	local.get	39
	local.get	36
	i32.store	8
	local.get	39
	local.get	28
	i32.store	4
	local.get	39
	local.get	45
	i32.store	0
	local.get	9
	local.get	69
	i32.add 
	local.get	50
	i32.store	0
	i32.const	0
	local.set	31
	i32.const	0
	local.get	28
	i32.const	-4
	i32.add 
	local.tee	39
	local.get	39
	local.get	28
	i32.gt_u
	i32.select
	local.set	69
	local.get	4
	local.get	45
	i32.add 
	local.set	68
	i32.const	0
	local.set	30
	local.get	67
	local.get	45
	i32.eq  
	br_if   	2                               # 2: down to label500
# %bb.181:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	28
	i32.const	3
	i32.gt_u
	br_if   	1                               # 1: down to label501
# %bb.182:                              #   in Loop: Header=BB26_17 Depth=1
	i32.const	0
	local.set	39
	local.get	68
	local.set	1
	local.get	28
	local.set	36
	i32.const	0
	local.set	30
.LBB26_183:                             #   Parent Loop BB26_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label507:
	local.get	1
	i32.load8_u	0
	local.get	39
	i32.shl 
	local.get	30
	i32.or  
	local.set	30
	local.get	1
	i32.const	1
	i32.add 
	local.set	1
	local.get	39
	i32.const	8
	i32.add 
	local.set	39
	local.get	36
	i32.const	-1
	i32.add 
	local.tee	36
	br_if   	0                               # 0: up to label507
	br      	3                               # 3: down to label500
.LBB26_184:                             #   in Loop: Header=BB26_17 Depth=1
	end_loop
	end_block                               # label502:
	local.get	6
	local.get	69
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	1
	local.get	70
	i32.store	12
	local.get	1
	local.get	36
	i32.store	8
	local.get	1
	local.get	28
	i32.store	4
	local.get	1
	local.get	30
	i32.store	0
	local.get	9
	local.get	69
	i32.add 
	local.get	9
	local.get	39
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.store	0
	local.get	38
	local.get	45
	i32.store	108
	i32.const	0
	local.set	61
	br      	2                               # 2: down to label499
.LBB26_185:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label501:
	local.get	68
	i32.load	0:p2align=0
	local.set	30
.LBB26_186:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label500:
	local.get	11
	local.get	50
	i32.const	12
	i32.mul 
	i32.add 
	local.tee	70
	local.get	30
	i32.store	0
	block   	
	local.get	28
	local.get	69
	i32.const	1
	i32.shr_u
	local.tee	1
	i32.le_u
	br_if   	0                               # 0: down to label508
# %bb.187:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	68
	local.get	1
	i32.add 
	local.set	39
	block   	
	local.get	28
	local.get	1
	i32.sub 
	local.tee	30
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label509
# %bb.188:                              #   in Loop: Header=BB26_17 Depth=1
	i32.const	0
	local.set	1
	i32.const	0
	local.set	31
.LBB26_189:                             #   Parent Loop BB26_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label510:
	local.get	39
	i32.load8_u	0
	local.get	1
	i32.shl 
	local.get	31
	i32.or  
	local.set	31
	local.get	39
	i32.const	1
	i32.add 
	local.set	39
	local.get	1
	i32.const	8
	i32.add 
	local.set	1
	local.get	30
	i32.const	-1
	i32.add 
	local.tee	30
	br_if   	0                               # 0: up to label510
	br      	2                               # 2: down to label508
.LBB26_190:                             #   in Loop: Header=BB26_17 Depth=1
	end_loop
	end_block                               # label509:
	local.get	39
	i32.load	0:p2align=0
	local.set	31
.LBB26_191:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label508:
	local.get	70
	i32.const	4
	i32.add 
	local.get	31
	i32.store	0
	i32.const	0
	local.set	61
	i32.const	0
	local.set	31
	block   	
	local.get	28
	local.get	69
	i32.le_u
	br_if   	0                               # 0: down to label511
# %bb.192:                              #   in Loop: Header=BB26_17 Depth=1
	block   	
	local.get	28
	local.get	69
	i32.sub 
	local.tee	1
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label512
# %bb.193:                              #   in Loop: Header=BB26_17 Depth=1
	local.get	4
	local.get	67
	i32.add 
	local.set	36
	i32.const	0
	local.set	39
	i32.const	0
	local.get	1
	i32.sub 
	local.set	1
	i32.const	0
	local.set	31
.LBB26_194:                             #   Parent Loop BB26_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label513:
	local.get	36
	local.get	1
	i32.add 
	i32.load8_u	0
	local.get	39
	i32.shl 
	local.get	31
	i32.or  
	local.set	31
	local.get	39
	i32.const	8
	i32.add 
	local.set	39
	local.get	1
	i32.const	1
	i32.add 
	local.tee	30
	local.set	1
	local.get	30
	br_if   	0                               # 0: up to label513
	br      	2                               # 2: down to label511
.LBB26_195:                             #   in Loop: Header=BB26_17 Depth=1
	end_loop
	end_block                               # label512:
	local.get	68
	local.get	69
	i32.add 
	i32.load	0:p2align=0
	local.set	31
.LBB26_196:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label511:
	local.get	70
	i32.const	8
	i32.add 
	local.get	31
	i32.store	0
	local.get	76
	local.get	47
	i32.const	1
	i32.add 
	i32.store	0
	local.get	50
	i32.const	1
	i32.add 
	local.set	50
	local.get	67
	local.set	45
.LBB26_197:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label499:
	local.get	65
	local.set	31
.LBB26_198:                             #   in Loop: Header=BB26_17 Depth=1
	end_block                               # label440:
	local.get	54
	i32.const	68
	i32.add 
	local.set	54
	local.get	60
	i32.const	1
	i32.add 
	local.set	60
	local.get	47
	i32.const	1
	i32.add 
	local.set	47
	local.get	38
	i32.const	52
	i32.add 
	local.get	38
	i32.load	48
	call	next_term_row
	local.tee	1
	i32.const	0
	i32.gt_s
	br_if   	0                               # 0: up to label423
.LBB26_199:
	end_loop
	end_block                               # label422:
	i32.const	-1
	local.set	39
	local.get	1
	i32.const	0
	i32.lt_s
	br_if   	0                               # 0: down to label418
# %bb.200:
	local.get	10
	local.get	50
	i32.store	0
	local.get	12
	local.get	47
	i32.store	0
	local.get	22
	local.get	49
	i32.store	0
	local.get	23
	local.get	48
	i32.store	0
	local.get	27
	local.get	46
	i32.store	0
	local.get	45
	local.set	39
.LBB26_201:
	end_block                               # label418:
	local.get	38
	i32.const	112
	i32.add 
	global.set	__stack_pointer
	local.get	39
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.next_term_bank,"",@
	.type	next_term_bank,@function        # -- Begin function next_term_bank
next_term_bank:                         # @next_term_bank
	.functype	next_term_bank (i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	1
	block   	
	local.get	0
	i32.load	16
	local.tee	2
	local.get	0
	i32.load	12
	local.tee	3
	i32.ge_u
	br_if   	0                               # 0: down to label514
# %bb.1:
	local.get	0
	i32.const	8
	i32.add 
	local.set	4
	local.get	0
	i32.load	4
	local.tee	5
	i32.const	4
	i32.add 
	local.set	6
	local.get	0
	i32.load	20
	local.set	7
.LBB27_2:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB27_12 Depth 2
                                        #     Child Loop BB27_20 Depth 2
                                        #     Child Loop BB27_29 Depth 2
	loop    	                                # label515:
	local.get	0
	local.get	2
	i32.const	1
	i32.add 
	local.tee	8
	i32.store	16
	local.get	2
	i32.const	3
	i32.shl 
	local.set	9
	block   	
	block   	
	local.get	5
	br_if   	0                               # 0: down to label517
# %bb.3:                                #   in Loop: Header=BB27_2 Depth=1
	i32.const	0
	local.set	2
	br      	1                               # 1: down to label516
.LBB27_4:                               #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label517:
	local.get	5
	local.get	9
	i32.add 
	i32.load	0
	local.set	2
.LBB27_5:                               #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label516:
	block   	
	local.get	2
	local.get	7
	i32.ge_u
	br_if   	0                               # 0: down to label518
# %bb.6:
	i32.const	-1
	return
.LBB27_7:                               #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label518:
	block   	
	local.get	4
	i32.load	0
	local.tee	10
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label519
# %bb.8:
	i32.const	-1
	return
.LBB27_9:                               #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label519:
	block   	
	local.get	6
	local.get	9
	i32.add 
	local.get	4
	local.get	5
	i32.select
	i32.load	0
	local.tee	9
	local.get	10
	local.get	2
	i32.sub 
	i32.le_u
	br_if   	0                               # 0: down to label520
# %bb.10:
	i32.const	-1
	return
.LBB27_11:                              #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label520:
	local.get	0
	local.get	9
	local.get	2
	i32.add 
	local.tee	7
	i32.store	20
	local.get	0
	i32.load	0
	local.set	10
	block   	
	local.get	2
	local.get	7
	i32.ge_u
	br_if   	0                               # 0: down to label521
.LBB27_12:                              #   Parent Loop BB27_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label522:
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	1
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label521
# %bb.13:                               #   in Loop: Header=BB27_12 Depth=2
	i32.const	1
	local.get	1
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label521
# %bb.14:                               #   in Loop: Header=BB27_12 Depth=2
	i32.const	-1
	local.set	1
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	local.get	9
	i32.const	-1
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label522
	br      	3                               # 3: down to label514
.LBB27_15:                              #   in Loop: Header=BB27_2 Depth=1
	end_loop
	end_block                               # label521:
	block   	
	local.get	2
	local.get	7
	i32.lt_u
	br_if   	0                               # 0: down to label523
# %bb.16:
	i32.const	-1
	return
.LBB27_17:                              #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label523:
	block   	
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.eq  
	br_if   	0                               # 0: down to label524
# %bb.18:
	i32.const	-1
	return
.LBB27_19:                              #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label524:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	local.get	7
	i32.ge_u
	br_if   	0                               # 0: down to label525
.LBB27_20:                              #   Parent Loop BB27_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label526:
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	9
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label525
# %bb.21:                               #   in Loop: Header=BB27_20 Depth=2
	i32.const	1
	local.get	9
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label525
# %bb.22:                               #   in Loop: Header=BB27_20 Depth=2
	local.get	7
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label526
# %bb.23:
	end_loop
	i32.const	-1
	return
.LBB27_24:                              #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label525:
	block   	
	local.get	2
	local.get	7
	i32.lt_u
	br_if   	0                               # 0: down to label527
# %bb.25:
	i32.const	-1
	return
.LBB27_26:                              #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label527:
	block   	
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.eq  
	br_if   	0                               # 0: down to label528
# %bb.27:
	local.get	0
	local.get	2
	i32.store	24
	i32.const	1
	return
.LBB27_28:                              #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label528:
	block   	
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	local.get	7
	i32.ge_u
	br_if   	0                               # 0: down to label530
.LBB27_29:                              #   Parent Loop BB27_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label531:
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	9
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label530
# %bb.30:                               #   in Loop: Header=BB27_29 Depth=2
	i32.const	1
	local.get	9
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label530
# %bb.31:                               #   in Loop: Header=BB27_29 Depth=2
	local.get	7
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label531
	br      	2                               # 2: down to label529
.LBB27_32:                              #   in Loop: Header=BB27_2 Depth=1
	end_loop
	end_block                               # label530:
	i32.const	-1
	local.set	1
	local.get	2
	local.get	7
	i32.ne  
	br_if   	2                               # 2: down to label514
.LBB27_33:                              #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label529:
	i32.const	0
	local.set	1
	local.get	8
	local.set	2
	local.get	8
	local.get	3
	i32.ne  
	br_if   	0                               # 0: up to label515
.LBB27_34:
	end_loop
	end_block                               # label514:
	local.get	1
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_row_single_pass,"",@
	.type	parse_row_single_pass,@function # -- Begin function parse_row_single_pass
parse_row_single_pass:                  # @parse_row_single_pass
	.functype	parse_row_single_pass (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, v128, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	12
	global.set	__stack_pointer
	block   	
	block   	
	block   	
	local.get	10
	i32.eqz
	br_if   	0                               # 0: down to label534
# %bb.1:
	i32.const	0
	local.set	13
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label532
# %bb.2:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	2                               # 2: down to label532
# %bb.3:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	14
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label535
# %bb.4:
.LBB28_5:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label536:
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label535
# %bb.6:                                #   in Loop: Header=BB28_5 Depth=1
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label535
# %bb.7:                                #   in Loop: Header=BB28_5 Depth=1
	local.get	1
	local.get	14
	i32.const	1
	i32.add 
	local.tee	14
	i32.ne  
	br_if   	0                               # 0: up to label536
# %bb.8:
	end_loop
	i32.const	0
	local.set	13
	br      	3                               # 3: down to label532
.LBB28_9:
	end_block                               # label535:
	i32.const	0
	local.set	13
	local.get	14
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label532
# %bb.10:
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	2                               # 2: down to label532
# %bb.11:
	local.get	14
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label532
# %bb.12:
	local.get	0
	i32.const	5
	i32.add 
	local.set	15
	local.get	0
	i32.const	4
	i32.add 
	local.set	16
	local.get	0
	i32.const	3
	i32.add 
	local.set	17
	i32.const	0
	local.set	18
.LBB28_13:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label537:
	block   	
	block   	
	local.get	2
	i32.const	8
	i32.add 
	local.tee	10
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label539
# %bb.14:                               #   in Loop: Header=BB28_13 Depth=1
	local.get	2
	local.set	10
	br      	1                               # 1: down to label538
.LBB28_15:                              #   in Loop: Header=BB28_13 Depth=1
	end_block                               # label539:
	local.get	0
	local.get	2
	i32.add 
	local.set	13
	local.get	10
	local.set	2
	local.get	13
	i64.load	0:p2align=0
	local.tee	19
	i64.const	-1
	i64.xor 
	local.get	19
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	19
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	19
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	19
	i64.eqz
	br_if   	1                               # 1: up to label537
# %bb.16:                               #   in Loop: Header=BB28_13 Depth=1
	local.get	19
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	10
	i32.add 
	i32.const	-8
	i32.add 
	local.set	10
.LBB28_17:                              #   in Loop: Header=BB28_13 Depth=1
	end_block                               # label538:
	i32.const	0
	local.set	13
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	3                               # 3: down to label532
# %bb.18:                               #   in Loop: Header=BB28_13 Depth=1
	block   	
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label542
# %bb.19:                               #   in Loop: Header=BB28_13 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	6                               # 6: down to label532
# %bb.20:                               #   in Loop: Header=BB28_13 Depth=1
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 8, 8, 1, 8, 8, 8, 1, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 1, 8, 1, 0, 8} # 8: down to label532
                                        # 1: down to label543
                                        # 0: down to label544
.LBB28_21:                              #   in Loop: Header=BB28_13 Depth=1
	end_block                               # label544:
	local.get	10
	i32.const	6
	i32.add 
	local.tee	2
	local.get	1
	i32.gt_u
	br_if   	7                               # 7: down to label532
# %bb.22:                               #   in Loop: Header=BB28_13 Depth=1
	i32.const	1
	local.set	18
	local.get	10
	i32.const	2
	i32.add 
	local.tee	20
	local.get	2
	i32.ge_u
	br_if   	2                               # 2: down to label541
# %bb.23:                               #   in Loop: Header=BB28_13 Depth=1
	block   	
	local.get	0
	local.get	20
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label545
# %bb.24:                               #   in Loop: Header=BB28_13 Depth=1
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	8                               # 8: down to label532
.LBB28_25:                              #   in Loop: Header=BB28_13 Depth=1
	end_block                               # label545:
	block   	
	local.get	17
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label546
# %bb.26:                               #   in Loop: Header=BB28_13 Depth=1
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	8                               # 8: down to label532
.LBB28_27:                              #   in Loop: Header=BB28_13 Depth=1
	end_block                               # label546:
	block   	
	local.get	16
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label547
# %bb.28:                               #   in Loop: Header=BB28_13 Depth=1
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	8                               # 8: down to label532
.LBB28_29:                              #   in Loop: Header=BB28_13 Depth=1
	end_block                               # label547:
	local.get	15
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label541
# %bb.30:                               #   in Loop: Header=BB28_13 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label541
	br      	7                               # 7: down to label532
.LBB28_31:                              #   in Loop: Header=BB28_13 Depth=1
	end_block                               # label543:
	local.get	10
	i32.const	2
	i32.add 
	local.set	2
	i32.const	1
	local.set	18
	br      	1                               # 1: down to label541
.LBB28_32:                              #   in Loop: Header=BB28_13 Depth=1
	end_block                               # label542:
	local.get	20
	i32.const	32
	i32.lt_u
	br_if   	5                               # 5: down to label532
# %bb.33:                               #   in Loop: Header=BB28_13 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.set	2
	local.get	20
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label540
.LBB28_34:                              #   in Loop: Header=BB28_13 Depth=1
	end_block                               # label541:
	local.get	2
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label537
	br      	4                               # 4: down to label532
.LBB28_35:
	end_block                               # label540:
	end_loop
	local.get	3
	local.get	14
	i32.store	0
	local.get	3
	local.get	2
	local.get	14
	i32.sub 
	i32.store	4
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label548
# %bb.36:
.LBB28_37:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label549:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label548
# %bb.38:                               #   in Loop: Header=BB28_37 Depth=1
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label548
# %bb.39:                               #   in Loop: Header=BB28_37 Depth=1
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label549
	br      	4                               # 4: down to label532
.LBB28_40:
	end_loop
	end_block                               # label548:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label532
# %bb.41:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	2                               # 2: down to label532
# %bb.42:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	14
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label550
# %bb.43:
.LBB28_44:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label551:
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label550
# %bb.45:                               #   in Loop: Header=BB28_44 Depth=1
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label550
# %bb.46:                               #   in Loop: Header=BB28_44 Depth=1
	local.get	1
	local.get	14
	i32.const	1
	i32.add 
	local.tee	14
	i32.ne  
	br_if   	0                               # 0: up to label551
	br      	4                               # 4: down to label532
.LBB28_47:
	end_loop
	end_block                               # label550:
	local.get	14
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label532
# %bb.48:
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	2                               # 2: down to label532
# %bb.49:
	local.get	14
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label532
# %bb.50:
	i32.const	0
	local.set	21
.LBB28_51:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label552:
	block   	
	block   	
	local.get	2
	i32.const	8
	i32.add 
	local.tee	10
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label554
# %bb.52:                               #   in Loop: Header=BB28_51 Depth=1
	local.get	2
	local.set	10
	br      	1                               # 1: down to label553
.LBB28_53:                              #   in Loop: Header=BB28_51 Depth=1
	end_block                               # label554:
	local.get	0
	local.get	2
	i32.add 
	local.set	13
	local.get	10
	local.set	2
	local.get	13
	i64.load	0:p2align=0
	local.tee	19
	i64.const	-1
	i64.xor 
	local.get	19
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	19
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	19
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	19
	i64.eqz
	br_if   	1                               # 1: up to label552
# %bb.54:                               #   in Loop: Header=BB28_51 Depth=1
	local.get	19
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	10
	i32.add 
	i32.const	-8
	i32.add 
	local.set	10
.LBB28_55:                              #   in Loop: Header=BB28_51 Depth=1
	end_block                               # label553:
	i32.const	0
	local.set	13
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	3                               # 3: down to label532
# %bb.56:                               #   in Loop: Header=BB28_51 Depth=1
	block   	
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label557
# %bb.57:                               #   in Loop: Header=BB28_51 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	6                               # 6: down to label532
# %bb.58:                               #   in Loop: Header=BB28_51 Depth=1
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 8, 8, 1, 8, 8, 8, 1, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 1, 8, 1, 0, 8} # 8: down to label532
                                        # 1: down to label558
                                        # 0: down to label559
.LBB28_59:                              #   in Loop: Header=BB28_51 Depth=1
	end_block                               # label559:
	local.get	10
	i32.const	6
	i32.add 
	local.tee	2
	local.get	1
	i32.gt_u
	br_if   	7                               # 7: down to label532
# %bb.60:                               #   in Loop: Header=BB28_51 Depth=1
	i32.const	1
	local.set	21
	local.get	10
	i32.const	2
	i32.add 
	local.tee	20
	local.get	2
	i32.ge_u
	br_if   	2                               # 2: down to label556
# %bb.61:                               #   in Loop: Header=BB28_51 Depth=1
	block   	
	local.get	0
	local.get	20
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label560
# %bb.62:                               #   in Loop: Header=BB28_51 Depth=1
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	8                               # 8: down to label532
.LBB28_63:                              #   in Loop: Header=BB28_51 Depth=1
	end_block                               # label560:
	block   	
	local.get	17
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label561
# %bb.64:                               #   in Loop: Header=BB28_51 Depth=1
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	8                               # 8: down to label532
.LBB28_65:                              #   in Loop: Header=BB28_51 Depth=1
	end_block                               # label561:
	block   	
	local.get	16
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label562
# %bb.66:                               #   in Loop: Header=BB28_51 Depth=1
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	8                               # 8: down to label532
.LBB28_67:                              #   in Loop: Header=BB28_51 Depth=1
	end_block                               # label562:
	local.get	15
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label556
# %bb.68:                               #   in Loop: Header=BB28_51 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label556
	br      	7                               # 7: down to label532
.LBB28_69:                              #   in Loop: Header=BB28_51 Depth=1
	end_block                               # label558:
	local.get	10
	i32.const	2
	i32.add 
	local.set	2
	i32.const	1
	local.set	21
	br      	1                               # 1: down to label556
.LBB28_70:                              #   in Loop: Header=BB28_51 Depth=1
	end_block                               # label557:
	local.get	20
	i32.const	32
	i32.lt_u
	br_if   	5                               # 5: down to label532
# %bb.71:                               #   in Loop: Header=BB28_51 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.set	2
	local.get	20
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label555
.LBB28_72:                              #   in Loop: Header=BB28_51 Depth=1
	end_block                               # label556:
	local.get	2
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label552
	br      	4                               # 4: down to label532
.LBB28_73:
	end_block                               # label555:
	end_loop
	local.get	3
	local.get	14
	i32.store	8
	local.get	3
	local.get	2
	local.get	14
	i32.sub 
	i32.store	12
	block   	
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label563
# %bb.74:
	local.get	11
	local.get	21
	i32.const	1
	i32.shl 
	local.get	18
	i32.or  
	i32.store	0
.LBB28_75:
	end_block                               # label563:
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label564
# %bb.76:
.LBB28_77:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label565:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label564
# %bb.78:                               #   in Loop: Header=BB28_77 Depth=1
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label564
# %bb.79:                               #   in Loop: Header=BB28_77 Depth=1
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label565
	br      	4                               # 4: down to label532
.LBB28_80:
	end_loop
	end_block                               # label564:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label532
# %bb.81:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	2                               # 2: down to label532
# %bb.82:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label566
# %bb.83:
.LBB28_84:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label567:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label566
# %bb.85:                               #   in Loop: Header=BB28_84 Depth=1
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label566
# %bb.86:                               #   in Loop: Header=BB28_84 Depth=1
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label567
	br      	4                               # 4: down to label532
.LBB28_87:
	end_loop
	end_block                               # label566:
	local.get	1
	local.get	2
	i32.le_u
	br_if   	2                               # 2: down to label532
# %bb.88:
	block   	
	local.get	0
	local.get	2
	i32.add 
	local.tee	14
	i32.load8_u	0
	local.tee	10
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label568
# %bb.89:
	local.get	1
	local.get	2
	i32.sub 
	i32.const	4
	i32.lt_u
	br_if   	3                               # 3: down to label532
# %bb.90:
	local.get	14
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	3                               # 3: down to label532
# %bb.91:
	local.get	14
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	3                               # 3: down to label532
# %bb.92:
	local.get	14
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	3                               # 3: down to label532
# %bb.93:
	local.get	2
	i32.const	4
	i32.add 
	local.set	14
	br      	2                               # 2: down to label533
.LBB28_94:
	end_block                               # label568:
	local.get	10
	i32.const	34
	i32.ne  
	br_if   	2                               # 2: down to label532
# %bb.95:
	local.get	2
	i32.const	1
	i32.add 
	local.tee	14
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label532
# %bb.96:
.LBB28_97:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label569:
	block   	
	local.get	14
	local.tee	10
	i32.const	8
	i32.add 
	local.tee	14
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label570
# %bb.98:                               #   in Loop: Header=BB28_97 Depth=1
	local.get	0
	local.get	10
	i32.add 
	i64.load	0:p2align=0
	local.tee	19
	i64.const	-1
	i64.xor 
	local.get	19
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	19
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	19
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	19
	i64.eqz
	br_if   	1                               # 1: up to label569
# %bb.99:                               #   in Loop: Header=BB28_97 Depth=1
	local.get	19
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	10
	i32.add 
	local.set	10
.LBB28_100:                             #   in Loop: Header=BB28_97 Depth=1
	end_block                               # label570:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	3                               # 3: down to label532
# %bb.101:                              #   in Loop: Header=BB28_97 Depth=1
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label572
# %bb.102:                              #   in Loop: Header=BB28_97 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	14
	local.get	1
	i32.ge_u
	br_if   	5                               # 5: down to label532
# %bb.103:                              #   in Loop: Header=BB28_97 Depth=1
	block   	
	block   	
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 1, 0, 7} # 7: down to label532
                                        # 1: down to label573
                                        # 0: down to label574
.LBB28_104:                             #   in Loop: Header=BB28_97 Depth=1
	end_block                               # label574:
	local.get	10
	i32.const	6
	i32.add 
	local.tee	14
	local.get	1
	i32.gt_u
	br_if   	6                               # 6: down to label532
# %bb.105:                              #   in Loop: Header=BB28_97 Depth=1
	local.get	10
	i32.const	2
	i32.add 
	local.tee	11
	local.get	14
	i32.ge_u
	br_if   	2                               # 2: down to label571
# %bb.106:                              #   in Loop: Header=BB28_97 Depth=1
	block   	
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label575
# %bb.107:                              #   in Loop: Header=BB28_97 Depth=1
	local.get	11
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label532
.LBB28_108:                             #   in Loop: Header=BB28_97 Depth=1
	end_block                               # label575:
	block   	
	local.get	17
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label576
# %bb.109:                              #   in Loop: Header=BB28_97 Depth=1
	local.get	11
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label532
.LBB28_110:                             #   in Loop: Header=BB28_97 Depth=1
	end_block                               # label576:
	block   	
	local.get	16
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label577
# %bb.111:                              #   in Loop: Header=BB28_97 Depth=1
	local.get	11
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label532
.LBB28_112:                             #   in Loop: Header=BB28_97 Depth=1
	end_block                               # label577:
	local.get	15
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label571
# %bb.113:                              #   in Loop: Header=BB28_97 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label571
	br      	6                               # 6: down to label532
.LBB28_114:                             #   in Loop: Header=BB28_97 Depth=1
	end_block                               # label573:
	local.get	10
	i32.const	2
	i32.add 
	local.set	14
	br      	1                               # 1: down to label571
.LBB28_115:                             #   in Loop: Header=BB28_97 Depth=1
	end_block                               # label572:
	local.get	11
	i32.const	32
	i32.lt_u
	br_if   	4                               # 4: down to label532
# %bb.116:                              #   in Loop: Header=BB28_97 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.set	14
	local.get	11
	i32.const	34
	i32.eq  
	br_if   	3                               # 3: down to label533
.LBB28_117:                             #   in Loop: Header=BB28_97 Depth=1
	end_block                               # label571:
	local.get	14
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: up to label569
	br      	3                               # 3: down to label532
.LBB28_118:
	end_loop
	end_block                               # label534:
	i32.const	0
	local.set	13
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label532
# %bb.119:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	1                               # 1: down to label532
# %bb.120:
	local.get	3
	v128.const	0, 0
	local.tee	22
	v128.store	0:p2align=2
	local.get	3
	local.get	22
	v128.store	48:p2align=2
	local.get	3
	i32.const	32
	i32.add 
	i64.const	0
	i64.store	0:p2align=2
	local.get	3
	i32.const	16
	i32.add 
	local.get	22
	v128.store	0:p2align=2
	local.get	3
	i32.const	40
	i32.add 
	i64.const	-4294967296
	i64.store	0:p2align=2
	local.get	3
	i32.const	64
	i32.add 
	local.tee	23
	i32.const	0
	i32.store	0
	block   	
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label578
# %bb.121:
	local.get	11
	i32.const	3
	i32.store	0
.LBB28_122:
	end_block                               # label578:
	local.get	3
	i32.const	48
	i32.add 
	local.set	24
	local.get	3
	i32.const	56
	i32.add 
	i32.const	0
	local.get	4
	i32.select
	local.set	25
	local.get	0
	i32.const	5
	i32.add 
	local.set	15
	local.get	0
	i32.const	4
	i32.add 
	local.set	16
	local.get	0
	i32.const	3
	i32.add 
	local.set	17
	local.get	3
	i32.const	60
	i32.add 
	local.set	26
	local.get	0
	i32.const	-1
	i32.add 
	local.set	21
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	i32.const	0
	local.set	18
.LBB28_123:                             # =>This Loop Header: Depth=1
                                        #     Child Loop BB28_124 Depth 2
                                        #     Child Loop BB28_161 Depth 2
                                        #     Child Loop BB28_135 Depth 2
                                        #     Child Loop BB28_221 Depth 2
                                        #     Child Loop BB28_230 Depth 2
	loop    	                                # label579:
	i32.const	0
	local.set	13
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label532
.LBB28_124:                             #   Parent Loop BB28_123 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label581:
	local.get	0
	local.get	2
	i32.add 
	local.tee	4
	i32.load8_u	0
	local.tee	14
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label580
# %bb.125:                              #   in Loop: Header=BB28_124 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label580
# %bb.126:                              #   in Loop: Header=BB28_124 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label581
	br      	4                               # 4: down to label532
.LBB28_127:                             #   in Loop: Header=BB28_123 Depth=1
	end_loop
	end_block                               # label580:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label532
# %bb.128:                              #   in Loop: Header=BB28_123 Depth=1
	block   	
	local.get	14
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: down to label582
# %bb.129:
	local.get	5
	local.get	2
	i32.const	1
	i32.add 
	i32.store	0
	local.get	3
	i32.load	4
	i32.const	0
	i32.ne  
	local.set	13
	br      	3                               # 3: down to label532
.LBB28_130:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label582:
	local.get	12
	i32.const	0
	i32.store	4
	block   	
	block   	
	block   	
	block   	
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label586
# %bb.131:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	18
	i32.const	1
	i32.gt_u
	br_if   	0                               # 0: down to label586
# %bb.132:                              #   in Loop: Header=BB28_123 Depth=1
	i32.const	0
	local.set	13
	local.get	14
	i32.const	34
	i32.ne  
	br_if   	6                               # 6: down to label532
# %bb.133:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	6                               # 6: down to label532
# %bb.134:                              #   in Loop: Header=BB28_123 Depth=1
	i32.const	0
	local.set	27
.LBB28_135:                             #   Parent Loop BB28_123 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label587:
	block   	
	block   	
	local.get	10
	i32.const	8
	i32.add 
	local.tee	13
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label589
# %bb.136:                              #   in Loop: Header=BB28_135 Depth=2
	local.get	10
	local.set	14
	br      	1                               # 1: down to label588
.LBB28_137:                             #   in Loop: Header=BB28_135 Depth=2
	end_block                               # label589:
	local.get	0
	local.get	10
	i32.add 
	local.set	14
	local.get	13
	local.set	10
	local.get	14
	i64.load	0:p2align=0
	local.tee	19
	i64.const	-1
	i64.xor 
	local.get	19
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	19
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	local.get	19
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	19
	i64.eqz
	br_if   	1                               # 1: up to label587
# %bb.138:                              #   in Loop: Header=BB28_135 Depth=2
	local.get	19
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	13
	i32.add 
	i32.const	-8
	i32.add 
	local.set	14
.LBB28_139:                             #   in Loop: Header=BB28_135 Depth=2
	end_block                               # label588:
	i32.const	0
	local.set	13
	local.get	14
	local.get	1
	i32.ge_u
	br_if   	7                               # 7: down to label532
# %bb.140:                              #   in Loop: Header=BB28_135 Depth=2
	block   	
	block   	
	block   	
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label592
# %bb.141:                              #   in Loop: Header=BB28_135 Depth=2
	local.get	14
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	10                              # 10: down to label532
# %bb.142:                              #   in Loop: Header=BB28_135 Depth=2
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 1, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 1, 12, 12, 12, 12, 12, 1, 12, 12, 12, 1, 12, 12, 12, 12, 12, 12, 12, 1, 12, 12, 12, 1, 12, 1, 0, 12} # 12: down to label532
                                        # 1: down to label593
                                        # 0: down to label594
.LBB28_143:                             #   in Loop: Header=BB28_135 Depth=2
	end_block                               # label594:
	local.get	14
	i32.const	6
	i32.add 
	local.tee	10
	local.get	1
	i32.gt_u
	br_if   	11                              # 11: down to label532
# %bb.144:                              #   in Loop: Header=BB28_135 Depth=2
	i32.const	1
	local.set	27
	local.get	14
	i32.const	2
	i32.add 
	local.tee	20
	local.get	10
	i32.ge_u
	br_if   	2                               # 2: down to label591
# %bb.145:                              #   in Loop: Header=BB28_135 Depth=2
	block   	
	local.get	0
	local.get	20
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label595
# %bb.146:                              #   in Loop: Header=BB28_135 Depth=2
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	12                              # 12: down to label532
.LBB28_147:                             #   in Loop: Header=BB28_135 Depth=2
	end_block                               # label595:
	block   	
	local.get	17
	local.get	14
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label596
# %bb.148:                              #   in Loop: Header=BB28_135 Depth=2
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	12                              # 12: down to label532
.LBB28_149:                             #   in Loop: Header=BB28_135 Depth=2
	end_block                               # label596:
	block   	
	local.get	16
	local.get	14
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label597
# %bb.150:                              #   in Loop: Header=BB28_135 Depth=2
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	12                              # 12: down to label532
.LBB28_151:                             #   in Loop: Header=BB28_135 Depth=2
	end_block                               # label597:
	local.get	15
	local.get	14
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label591
# %bb.152:                              #   in Loop: Header=BB28_135 Depth=2
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label591
	br      	11                              # 11: down to label532
.LBB28_153:                             #   in Loop: Header=BB28_135 Depth=2
	end_block                               # label593:
	local.get	14
	i32.const	2
	i32.add 
	local.set	10
	i32.const	1
	local.set	27
	br      	1                               # 1: down to label591
.LBB28_154:                             #   in Loop: Header=BB28_135 Depth=2
	end_block                               # label592:
	local.get	20
	i32.const	32
	i32.lt_u
	br_if   	9                               # 9: down to label532
# %bb.155:                              #   in Loop: Header=BB28_135 Depth=2
	local.get	14
	i32.const	1
	i32.add 
	local.set	10
	local.get	20
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label590
.LBB28_156:                             #   in Loop: Header=BB28_135 Depth=2
	end_block                               # label591:
	local.get	10
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label587
	br      	8                               # 8: down to label532
.LBB28_157:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label590:
	end_loop
	local.get	12
	local.get	10
	i32.store	4
	local.get	27
	br_if   	1                               # 1: down to label585
# %bb.158:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	11
	local.get	11
	i32.load	0
	i32.const	-2
	local.get	18
	i32.rotl
	i32.and 
	i32.store	0
	br      	1                               # 1: down to label585
.LBB28_159:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label586:
	block   	
	block   	
	local.get	18
	i32.const	-3
	i32.and 
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label599
# %bb.160:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	2
	local.set	14
.LBB28_161:                             #   Parent Loop BB28_123 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label601:
	block   	
	local.get	1
	local.get	14
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: down to label602
# %bb.162:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	1
	local.set	10
	br      	2                               # 2: down to label600
.LBB28_163:                             #   in Loop: Header=BB28_161 Depth=2
	end_block                               # label602:
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	13
	i32.const	-10
	i32.add 
	br_table 	{3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0} # 1: down to label603
                                        # 3: down to label600
                                        # 0: down to label604
.LBB28_164:                             #   in Loop: Header=BB28_161 Depth=2
	end_block                               # label604:
	local.get	13
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label600
# %bb.165:                              #   in Loop: Header=BB28_161 Depth=2
	local.get	13
	i32.const	125
	i32.eq  
	br_if   	2                               # 2: down to label600
.LBB28_166:                             #   in Loop: Header=BB28_161 Depth=2
	end_block                               # label603:
	local.get	10
	i32.const	1
	i32.add 
	local.set	14
	local.get	13
	i32.const	9
	i32.ne  
	br_if   	0                               # 0: up to label601
.LBB28_167:                             #   in Loop: Header=BB28_123 Depth=1
	end_loop
	end_block                               # label600:
	local.get	10
	local.get	2
	i32.ne  
	br_if   	1                               # 1: down to label598
# %bb.168:
	i32.const	0
	local.set	13
	br      	7                               # 7: down to label532
.LBB28_169:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label599:
	block   	
	local.get	18
	i32.const	5
	i32.ne  
	br_if   	0                               # 0: down to label605
# %bb.170:                              #   in Loop: Header=BB28_123 Depth=1
	block   	
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label606
# %bb.171:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	0
	local.get	1
	local.get	2
	local.get	6
	local.get	7
	local.get	3
	local.get	12
	i32.const	4
	i32.add 
	local.get	8
	local.get	9
	call	reuse_validated_glossary
	br_if   	4                               # 4: down to label584
# %bb.172:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	4
	i32.load8_u	0
	local.set	14
.LBB28_173:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label606:
	block   	
	block   	
	local.get	14
	i32.const	223
	i32.and 
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label608
# %bb.174:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	0
	local.get	1
	local.get	2
	local.get	12
	i32.const	4
	i32.add 
	local.get	25
	local.get	26
	local.get	23
	i32.const	0
	call	parse_composite_span_impl
	local.set	10
	br      	1                               # 1: down to label607
.LBB28_175:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label608:
	local.get	0
	local.get	1
	local.get	2
	local.get	12
	i32.const	4
	i32.add 
	call	parse_value_span
	local.set	10
.LBB28_176:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label607:
	local.get	10
	br_if   	3                               # 3: down to label584
# %bb.177:
	i32.const	0
	local.set	13
	br      	7                               # 7: down to label532
.LBB28_178:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label605:
	local.get	0
	local.get	1
	local.get	2
	local.get	12
	i32.const	4
	i32.add 
	call	parse_value_span
	br_if   	1                               # 1: down to label585
# %bb.179:
	i32.const	0
	local.set	13
	br      	6                               # 6: down to label532
.LBB28_180:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label598:
	local.get	12
	local.get	10
	i32.store	4
.LBB28_181:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label585:
	local.get	18
	i32.const	8
	i32.lt_u
	br_if   	0                               # 0: down to label584
# %bb.182:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	12
	i32.load	4
	local.set	10
	br      	1                               # 1: down to label583
.LBB28_183:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label584:
	i32.const	0
	local.set	20
	block   	
	i32.const	0
	local.get	12
	i32.load	4
	local.tee	10
	local.get	2
	i32.sub 
	local.tee	13
	local.get	13
	local.get	10
	i32.gt_u
	i32.select
	local.tee	14
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label609
# %bb.184:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	4
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label609
# %bb.185:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	21
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	20
.LBB28_186:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label609:
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	18
	br_table 	{0, 1, 2, 3, 4, 5, 6, 7, 0} # 1: down to label617
                                        # 2: down to label616
                                        # 3: down to label615
                                        # 4: down to label614
                                        # 5: down to label613
                                        # 6: down to label612
                                        # 7: down to label611
                                        # 0: down to label618
.LBB28_187:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label618:
	block   	
	local.get	20
	br_if   	0                               # 0: down to label619
# %bb.188:
	i32.const	0
	local.set	13
	br      	12                              # 12: down to label532
.LBB28_189:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label619:
	local.get	3
	local.get	2
	i32.store	0
	i32.const	4
	local.set	13
	br      	7                               # 7: down to label610
.LBB28_190:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label617:
	block   	
	local.get	20
	br_if   	0                               # 0: down to label620
# %bb.191:
	i32.const	0
	local.set	13
	br      	11                              # 11: down to label532
.LBB28_192:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label620:
	local.get	3
	local.get	2
	i32.store	8
	i32.const	12
	local.set	13
	br      	6                               # 6: down to label610
.LBB28_193:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label616:
	block   	
	local.get	20
	br_if   	0                               # 0: down to label621
# %bb.194:                              #   in Loop: Header=BB28_123 Depth=1
	i32.const	0
	local.set	13
	local.get	14
	i32.const	4
	i32.ne  
	br_if   	10                              # 10: down to label532
# %bb.195:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	4
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	10                              # 10: down to label532
# %bb.196:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	4
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	10                              # 10: down to label532
# %bb.197:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	4
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	10                              # 10: down to label532
# %bb.198:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	4
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	10                              # 10: down to label532
.LBB28_199:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label621:
	local.get	3
	local.get	2
	i32.store	16
	i32.const	20
	local.set	13
	br      	5                               # 5: down to label610
.LBB28_200:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label615:
	block   	
	local.get	20
	br_if   	0                               # 0: down to label622
# %bb.201:
	i32.const	0
	local.set	13
	br      	9                               # 9: down to label532
.LBB28_202:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label622:
	local.get	3
	local.get	2
	i32.store	24
	i32.const	28
	local.set	13
	br      	4                               # 4: down to label610
.LBB28_203:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label614:
	block   	
	local.get	0
	local.get	2
	local.get	10
	call	is_valid_json_number
	i32.eqz
	br_if   	0                               # 0: down to label623
# %bb.204:                              #   in Loop: Header=BB28_123 Depth=1
	i32.const	32
	local.set	13
	local.get	2
	local.set	14
	br      	4                               # 4: down to label610
.LBB28_205:
	end_block                               # label623:
	i32.const	0
	local.set	13
	br      	7                               # 7: down to label532
.LBB28_206:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label613:
	local.get	3
	local.get	2
	i32.store	36
	i32.const	40
	local.set	13
	br      	2                               # 2: down to label610
.LBB28_207:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label612:
	block   	
	local.get	14
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label624
# %bb.208:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	4
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label624
# %bb.209:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	4
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label624
# %bb.210:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	4
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label624
# %bb.211:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	4
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label624
# %bb.212:                              #   in Loop: Header=BB28_123 Depth=1
	i32.const	-1
	local.set	14
	i32.const	44
	local.set	13
	br      	2                               # 2: down to label610
.LBB28_213:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label624:
	block   	
	local.get	0
	local.get	2
	local.get	10
	call	is_valid_json_number
	i32.eqz
	br_if   	0                               # 0: down to label625
# %bb.214:                              #   in Loop: Header=BB28_123 Depth=1
	i32.const	44
	local.set	13
	local.get	2
	local.set	14
	br      	2                               # 2: down to label610
.LBB28_215:
	end_block                               # label625:
	i32.const	0
	local.set	13
	br      	5                               # 5: down to label532
.LBB28_216:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label611:
	block   	
	local.get	20
	br_if   	0                               # 0: down to label626
# %bb.217:
	i32.const	0
	local.set	13
	br      	5                               # 5: down to label532
.LBB28_218:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label626:
	local.get	24
	local.get	2
	i32.store	0
	i32.const	52
	local.set	13
.LBB28_219:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label610:
	local.get	3
	local.get	13
	i32.add 
	local.get	14
	i32.store	0
.LBB28_220:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label583:
	block   	
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label627
.LBB28_221:                             #   Parent Loop BB28_123 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label628:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label627
# %bb.222:                              #   in Loop: Header=BB28_221 Depth=2
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label627
# %bb.223:                              #   in Loop: Header=BB28_221 Depth=2
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label628
# %bb.224:
	end_loop
	i32.const	0
	local.set	13
	br      	3                               # 3: down to label532
.LBB28_225:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label627:
	i32.const	0
	local.set	13
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label532
# %bb.226:                              #   in Loop: Header=BB28_123 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	44
	i32.eq  
	br_if   	0                               # 0: down to label629
# %bb.227:
	local.get	2
	i32.const	93
	i32.ne  
	br_if   	3                               # 3: down to label532
# %bb.228:
	local.get	5
	local.get	10
	i32.const	1
	i32.add 
	i32.store	0
	local.get	3
	i32.load	4
	i32.const	0
	i32.ne  
	local.set	13
	br      	3                               # 3: down to label532
.LBB28_229:                             #   in Loop: Header=BB28_123 Depth=1
	end_block                               # label629:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label630
.LBB28_230:                             #   Parent Loop BB28_123 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label631:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label630
# %bb.231:                              #   in Loop: Header=BB28_230 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label630
# %bb.232:                              #   in Loop: Header=BB28_230 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label631
	br      	4                               # 4: down to label532
.LBB28_233:                             #   in Loop: Header=BB28_123 Depth=1
	end_loop
	end_block                               # label630:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label532
# %bb.234:                              #   in Loop: Header=BB28_123 Depth=1
	local.get	18
	i32.const	1
	i32.add 
	local.set	18
	i32.const	0
	local.set	13
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: up to label579
	br      	2                               # 2: down to label532
.LBB28_235:
	end_loop
	end_block                               # label533:
	local.get	3
	local.get	2
	i32.store	16
	local.get	12
	local.get	14
	i32.store	12
	local.get	3
	local.get	14
	local.get	2
	i32.sub 
	i32.store	20
	local.get	0
	local.get	1
	local.get	12
	i32.const	12
	i32.add 
	call	next_format3_field
	i32.eqz
	br_if   	0                               # 0: down to label532
# %bb.236:
	local.get	12
	i32.load	12
	local.tee	11
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label532
# %bb.237:
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label532
# %bb.238:
	local.get	11
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label532
# %bb.239:
.LBB28_240:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label632:
	block   	
	local.get	10
	local.tee	2
	i32.const	8
	i32.add 
	local.tee	10
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label633
# %bb.241:                              #   in Loop: Header=BB28_240 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i64.load	0:p2align=0
	local.tee	19
	i64.const	-1
	i64.xor 
	local.get	19
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	19
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	19
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	19
	i64.eqz
	br_if   	1                               # 1: up to label632
# %bb.242:                              #   in Loop: Header=BB28_240 Depth=1
	local.get	19
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	2
	i32.add 
	local.set	2
.LBB28_243:                             #   in Loop: Header=BB28_240 Depth=1
	end_block                               # label633:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label532
# %bb.244:                              #   in Loop: Header=BB28_240 Depth=1
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label636
# %bb.245:                              #   in Loop: Header=BB28_240 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	4                               # 4: down to label532
# %bb.246:                              #   in Loop: Header=BB28_240 Depth=1
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 1, 6, 6, 6, 6, 6, 1, 6, 6, 6, 1, 6, 6, 6, 6, 6, 6, 6, 1, 6, 6, 6, 1, 6, 1, 0, 6} # 6: down to label532
                                        # 1: down to label637
                                        # 0: down to label638
.LBB28_247:                             #   in Loop: Header=BB28_240 Depth=1
	end_block                               # label638:
	local.get	2
	i32.const	6
	i32.add 
	local.tee	10
	local.get	1
	i32.gt_u
	br_if   	5                               # 5: down to label532
# %bb.248:                              #   in Loop: Header=BB28_240 Depth=1
	local.get	2
	i32.const	2
	i32.add 
	local.tee	14
	local.get	10
	i32.ge_u
	br_if   	2                               # 2: down to label635
# %bb.249:                              #   in Loop: Header=BB28_240 Depth=1
	block   	
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label639
# %bb.250:                              #   in Loop: Header=BB28_240 Depth=1
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label532
.LBB28_251:                             #   in Loop: Header=BB28_240 Depth=1
	end_block                               # label639:
	block   	
	local.get	17
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label640
# %bb.252:                              #   in Loop: Header=BB28_240 Depth=1
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label532
.LBB28_253:                             #   in Loop: Header=BB28_240 Depth=1
	end_block                               # label640:
	block   	
	local.get	16
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label641
# %bb.254:                              #   in Loop: Header=BB28_240 Depth=1
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label532
.LBB28_255:                             #   in Loop: Header=BB28_240 Depth=1
	end_block                               # label641:
	local.get	15
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label635
# %bb.256:                              #   in Loop: Header=BB28_240 Depth=1
	local.get	2
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label635
	br      	5                               # 5: down to label532
.LBB28_257:                             #   in Loop: Header=BB28_240 Depth=1
	end_block                               # label637:
	local.get	2
	i32.const	2
	i32.add 
	local.set	10
	br      	1                               # 1: down to label635
.LBB28_258:                             #   in Loop: Header=BB28_240 Depth=1
	end_block                               # label636:
	local.get	14
	i32.const	32
	i32.lt_u
	br_if   	3                               # 3: down to label532
# %bb.259:                              #   in Loop: Header=BB28_240 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.set	10
	local.get	14
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label634
.LBB28_260:                             #   in Loop: Header=BB28_240 Depth=1
	end_block                               # label635:
	local.get	10
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label632
	br      	2                               # 2: down to label532
.LBB28_261:
	end_block                               # label634:
	end_loop
	local.get	3
	local.get	11
	i32.store	24
	local.get	3
	local.get	10
	local.get	11
	i32.sub 
	i32.store	28
	local.get	12
	local.get	10
	i32.store	8
	local.get	12
	local.get	10
	i32.store	12
	local.get	0
	local.get	1
	local.get	12
	i32.const	12
	i32.add 
	call	next_format3_field
	i32.eqz
	br_if   	0                               # 0: down to label532
# %bb.262:
	local.get	0
	local.get	1
	local.get	12
	i32.load	12
	local.tee	2
	local.get	12
	i32.const	8
	i32.add 
	call	scan_scalar_span
	i32.eqz
	br_if   	0                               # 0: down to label532
# %bb.263:
	local.get	0
	local.get	2
	local.get	12
	i32.load	8
	local.tee	10
	call	is_valid_json_number
	i32.eqz
	br_if   	0                               # 0: down to label532
# %bb.264:
	local.get	3
	local.get	2
	i32.store	32
	local.get	12
	local.get	10
	i32.store	12
	local.get	0
	local.get	1
	local.get	12
	i32.const	12
	i32.add 
	call	next_format3_field
	i32.eqz
	br_if   	0                               # 0: down to label532
# %bb.265:
	local.get	0
	local.get	12
	i32.load	12
	local.tee	2
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label532
# %bb.266:
	i32.const	0
	local.set	13
	local.get	3
	i32.const	0
	i32.store	64
	local.get	3
	i64.const	0
	i64.store	56:p2align=2
	block   	
	block   	
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label643
# %bb.267:
	local.get	0
	local.get	1
	local.get	2
	local.get	6
	local.get	7
	local.get	3
	local.get	12
	i32.const	8
	i32.add 
	local.get	8
	local.get	9
	call	reuse_validated_glossary
	br_if   	1                               # 1: down to label642
.LBB28_268:
	end_block                               # label643:
	local.get	0
	local.get	1
	local.get	2
	local.get	12
	i32.const	8
	i32.add 
	local.get	3
	i32.const	56
	i32.add 
	i32.const	0
	local.get	4
	i32.select
	local.get	3
	i32.const	60
	i32.add 
	local.get	3
	i32.const	64
	i32.add 
	i32.const	1
	call	parse_value_span_with_glossary_hints
	i32.eqz
	br_if   	1                               # 1: down to label532
.LBB28_269:
	end_block                               # label642:
	local.get	3
	local.get	2
	i32.store	36
	local.get	3
	local.get	12
	i32.load	8
	local.tee	10
	local.get	2
	i32.sub 
	i32.store	40
	local.get	12
	local.get	10
	i32.store	12
	i32.const	0
	local.set	13
	local.get	0
	local.get	1
	local.get	12
	i32.const	12
	i32.add 
	call	next_format3_field
	i32.eqz
	br_if   	0                               # 0: down to label532
# %bb.270:
	local.get	0
	local.get	1
	local.get	12
	i32.load	12
	local.tee	2
	local.get	12
	i32.const	8
	i32.add 
	call	scan_scalar_span
	i32.eqz
	br_if   	0                               # 0: down to label532
# %bb.271:
	block   	
	block   	
	local.get	12
	i32.load	8
	local.tee	10
	local.get	2
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label645
# %bb.272:
	local.get	0
	local.get	2
	i32.add 
	local.tee	4
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label645
# %bb.273:
	local.get	4
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label645
# %bb.274:
	local.get	4
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label645
# %bb.275:
	i32.const	-1
	local.set	14
	local.get	4
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label644
.LBB28_276:
	end_block                               # label645:
	local.get	2
	local.set	14
	local.get	0
	local.get	2
	local.get	10
	call	is_valid_json_number
	i32.eqz
	br_if   	1                               # 1: down to label532
.LBB28_277:
	end_block                               # label644:
	local.get	3
	local.get	14
	i32.store	44
	local.get	12
	local.get	10
	i32.store	12
	local.get	0
	local.get	1
	local.get	12
	i32.const	12
	i32.add 
	call	next_format3_field
	i32.eqz
	br_if   	0                               # 0: down to label532
# %bb.278:
	local.get	12
	i32.load	12
	local.tee	4
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label532
# %bb.279:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label532
# %bb.280:
	local.get	4
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label532
# %bb.281:
.LBB28_282:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label646:
	block   	
	local.get	10
	local.tee	2
	i32.const	8
	i32.add 
	local.tee	10
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label647
# %bb.283:                              #   in Loop: Header=BB28_282 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i64.load	0:p2align=0
	local.tee	19
	i64.const	-1
	i64.xor 
	local.get	19
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	19
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	19
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	19
	i64.eqz
	br_if   	1                               # 1: up to label646
# %bb.284:                              #   in Loop: Header=BB28_282 Depth=1
	local.get	19
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	2
	i32.add 
	local.set	2
.LBB28_285:                             #   in Loop: Header=BB28_282 Depth=1
	end_block                               # label647:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label532
# %bb.286:                              #   in Loop: Header=BB28_282 Depth=1
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label650
# %bb.287:                              #   in Loop: Header=BB28_282 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	4                               # 4: down to label532
# %bb.288:                              #   in Loop: Header=BB28_282 Depth=1
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 1, 6, 6, 6, 6, 6, 1, 6, 6, 6, 1, 6, 6, 6, 6, 6, 6, 6, 1, 6, 6, 6, 1, 6, 1, 0, 6} # 6: down to label532
                                        # 1: down to label651
                                        # 0: down to label652
.LBB28_289:                             #   in Loop: Header=BB28_282 Depth=1
	end_block                               # label652:
	local.get	2
	i32.const	6
	i32.add 
	local.tee	10
	local.get	1
	i32.gt_u
	br_if   	5                               # 5: down to label532
# %bb.290:                              #   in Loop: Header=BB28_282 Depth=1
	local.get	2
	i32.const	2
	i32.add 
	local.tee	14
	local.get	10
	i32.ge_u
	br_if   	2                               # 2: down to label649
# %bb.291:                              #   in Loop: Header=BB28_282 Depth=1
	block   	
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label653
# %bb.292:                              #   in Loop: Header=BB28_282 Depth=1
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label532
.LBB28_293:                             #   in Loop: Header=BB28_282 Depth=1
	end_block                               # label653:
	block   	
	local.get	17
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label654
# %bb.294:                              #   in Loop: Header=BB28_282 Depth=1
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label532
.LBB28_295:                             #   in Loop: Header=BB28_282 Depth=1
	end_block                               # label654:
	block   	
	local.get	16
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label655
# %bb.296:                              #   in Loop: Header=BB28_282 Depth=1
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label532
.LBB28_297:                             #   in Loop: Header=BB28_282 Depth=1
	end_block                               # label655:
	local.get	15
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label649
# %bb.298:                              #   in Loop: Header=BB28_282 Depth=1
	local.get	2
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label649
	br      	5                               # 5: down to label532
.LBB28_299:                             #   in Loop: Header=BB28_282 Depth=1
	end_block                               # label651:
	local.get	2
	i32.const	2
	i32.add 
	local.set	10
	br      	1                               # 1: down to label649
.LBB28_300:                             #   in Loop: Header=BB28_282 Depth=1
	end_block                               # label650:
	local.get	14
	i32.const	32
	i32.lt_u
	br_if   	3                               # 3: down to label532
# %bb.301:                              #   in Loop: Header=BB28_282 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.set	10
	local.get	14
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label648
.LBB28_302:                             #   in Loop: Header=BB28_282 Depth=1
	end_block                               # label649:
	local.get	10
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label646
	br      	2                               # 2: down to label532
.LBB28_303:
	end_block                               # label648:
	end_loop
	local.get	3
	local.get	4
	i32.store	48
	local.get	3
	local.get	10
	local.get	4
	i32.sub 
	i32.store	52
	block   	
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label656
# %bb.304:
.LBB28_305:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label657:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label656
# %bb.306:                              #   in Loop: Header=BB28_305 Depth=1
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label656
# %bb.307:                              #   in Loop: Header=BB28_305 Depth=1
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label657
	br      	2                               # 2: down to label532
.LBB28_308:
	end_loop
	end_block                               # label656:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label532
# %bb.309:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: down to label532
# %bb.310:
	i32.const	1
	local.set	13
	local.get	5
	local.get	10
	i32.const	1
	i32.add 
	i32.store	0
.LBB28_311:
	end_block                               # label532:
	local.get	12
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	13
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.scan_scalar_span,"",@
	.type	scan_scalar_span,@function      # -- Begin function scan_scalar_span
scan_scalar_span:                       # @scan_scalar_span
	.functype	scan_scalar_span (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	4
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label658
# %bb.1:
	local.get	2
	local.set	5
.LBB29_2:                               # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label660:
	block   	
	local.get	1
	local.get	5
	local.tee	6
	i32.ne  
	br_if   	0                               # 0: down to label661
# %bb.3:
	local.get	1
	local.set	6
	br      	2                               # 2: down to label659
.LBB29_4:                               #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label661:
	block   	
	block   	
	local.get	0
	local.get	6
	i32.add 
	i32.load8_u	0
	local.tee	7
	i32.const	-10
	i32.add 
	br_table 	{3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0} # 1: down to label662
                                        # 3: down to label659
                                        # 0: down to label663
.LBB29_5:                               #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label663:
	local.get	7
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label659
# %bb.6:                                #   in Loop: Header=BB29_2 Depth=1
	local.get	7
	i32.const	125
	i32.eq  
	br_if   	2                               # 2: down to label659
.LBB29_7:                               #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label662:
	local.get	6
	i32.const	1
	i32.add 
	local.set	5
	local.get	7
	i32.const	9
	i32.ne  
	br_if   	0                               # 0: up to label660
.LBB29_8:
	end_loop
	end_block                               # label659:
	local.get	6
	local.get	2
	i32.eq  
	br_if   	0                               # 0: down to label658
# %bb.9:
	local.get	3
	local.get	6
	i32.store	0
	i32.const	1
	local.set	4
.LBB29_10:
	end_block                               # label658:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_int32_token,"",@
	.type	parse_int32_token,@function     # -- Begin function parse_int32_token
parse_int32_token:                      # @parse_int32_token
	.functype	parse_int32_token (i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32
# %bb.0:
	block   	
	block   	
	block   	
	local.get	2
	local.get	1
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label666
# %bb.1:
	local.get	0
	local.get	1
	i32.add 
	local.tee	5
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label666
# %bb.2:
	local.get	5
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label666
# %bb.3:
	local.get	5
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label666
# %bb.4:
	local.get	5
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label665
.LBB30_5:
	end_block                               # label666:
	i32.const	1
	local.set	6
	block   	
	local.get	2
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label667
# %bb.6:
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	3
	i32.const	45
	i32.ne  
	local.set	6
	local.get	1
	local.get	3
	i32.const	45
	i32.eq  
	i32.add 
	local.set	1
.LBB30_7:
	end_block                               # label667:
	i32.const	0
	local.set	5
	local.get	2
	local.get	1
	i32.le_u
	br_if   	1                               # 1: down to label664
# %bb.8:
	local.get	0
	local.get	1
	i32.add 
	local.tee	0
	i32.load8_u	0
	local.tee	3
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	246
	i32.lt_u
	br_if   	1                               # 1: down to label664
# %bb.9:
	block   	
	local.get	1
	i32.const	1
	i32.add 
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label668
# %bb.10:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	48
	i32.eq  
	br_if   	2                               # 2: down to label664
.LBB30_11:
	end_block                               # label668:
	i32.const	2147483647
	i32.const	-2147483648
	local.get	6
	i32.select
	local.set	7
	local.get	2
	local.get	1
	i32.sub 
	local.set	3
	i32.const	0
	local.set	5
	i32.const	0
	local.set	1
.LBB30_12:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label669:
	local.get	0
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	246
	i32.lt_u
	br_if   	2                               # 2: down to label664
# %bb.13:                               #   in Loop: Header=BB30_12 Depth=1
	local.get	1
	local.get	7
	local.get	2
	i32.const	-48
	i32.add 
	local.tee	2
	i32.sub 
	i32.const	10
	i32.div_u
	i32.gt_u
	br_if   	2                               # 2: down to label664
# %bb.14:                               #   in Loop: Header=BB30_12 Depth=1
	local.get	0
	i32.const	1
	i32.add 
	local.set	0
	local.get	2
	local.get	1
	i32.const	10
	i32.mul 
	i32.add 
	local.set	1
	local.get	3
	i32.const	-1
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label669
# %bb.15:
	end_loop
	local.get	1
	i32.const	0
	local.get	1
	i32.sub 
	local.get	6
	i32.select
	local.set	3
.LBB30_16:
	end_block                               # label665:
	local.get	4
	local.get	3
	i32.store	0
	i32.const	1
	local.set	5
.LBB30_17:
	end_block                               # label664:
	local.get	5
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.raw_term_content_hash,"",@
	.type	raw_term_content_hash,@function # -- Begin function raw_term_content_hash
raw_term_content_hash:                  # @raw_term_content_hash
	.functype	raw_term_content_hash (i32, i32) -> (i32)
	.local  	i32, i32, i32
# %bb.0:
	local.get	0
	local.get	1
	i32.load	36
	i32.add 
	local.get	1
	i32.load	40
	i32.const	-2128831035
	call	hash_content_xxh32
	local.set	2
	local.get	0
	local.get	1
	i32.load	24
	i32.add 
	local.get	1
	i32.load	28
	i32.const	-1640531527
	call	hash_content_xxh32
	local.set	3
	local.get	0
	local.get	1
	i32.load	16
	i32.add 
	local.get	1
	i32.load	20
	i32.const	-2048144789
	call	hash_content_xxh32
	local.set	4
	i32.const	1
	local.get	0
	local.get	1
	i32.load	48
	i32.add 
	local.get	1
	i32.load	52
	i32.const	-1028477387
	call	hash_content_xxh32
	i32.const	17
	i32.rotl
	local.tee	1
	local.get	2
	local.get	3
	i32.const	5
	i32.rotl
	i32.xor 
	local.get	4
	i32.const	11
	i32.rotl
	i32.xor 
	local.tee	0
	i32.xor 
	local.tee	2
	i32.const	16
	i32.shr_u
	local.get	2
	i32.xor 
	local.get	0
	local.get	1
	i32.eq  
	i32.select
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.raw_term_content_tokens_equal,"",@
	.type	raw_term_content_tokens_equal,@function # -- Begin function raw_term_content_tokens_equal
raw_term_content_tokens_equal:          # @raw_term_content_tokens_equal
	.functype	raw_term_content_tokens_equal (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i64, i64, i32
# %bb.0:
	i32.const	0
	local.set	4
	block   	
	local.get	1
	i32.load	40
	local.tee	5
	local.get	2
	i32.load	40
	i32.ne  
	br_if   	0                               # 0: down to label670
# %bb.1:
	block   	
	block   	
	local.get	3
	br_if   	0                               # 0: down to label672
# %bb.2:
	local.get	0
	local.get	2
	i32.load	36
	i32.add 
	local.set	6
	local.get	0
	local.get	1
	i32.load	36
	i32.add 
	local.set	7
	i32.const	0
	local.set	3
	local.get	5
	local.set	8
.LBB32_3:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label673:
	block   	
	local.get	8
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label674
# %bb.4:
	i32.const	0
	local.get	3
	i32.sub 
	local.set	8
	local.get	6
	local.get	3
	i32.add 
	local.set	9
	local.get	7
	local.get	3
	i32.add 
	local.set	3
.LBB32_5:                               # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label676:
	block   	
	local.get	5
	local.get	8
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label677
# %bb.6:
	i32.const	0
	local.get	8
	i32.sub 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	5                               # 5: down to label672
# %bb.7:
	br      	2                               # 2: down to label675
.LBB32_8:                               #   in Loop: Header=BB32_5 Depth=1
	end_block                               # label677:
	local.get	8
	i32.const	-8
	i32.add 
	local.set	8
	local.get	9
	i64.load	0:p2align=0
	local.set	10
	local.get	3
	i64.load	0:p2align=0
	local.set	11
	local.get	3
	i32.const	8
	i32.add 
	local.set	3
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	local.get	10
	i64.eq  
	br_if   	0                               # 0: up to label676
	br      	5                               # 5: down to label671
.LBB32_9:                               # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label675:
	loop    	                                # label678:
	local.get	7
	local.get	3
	i32.add 
	i32.load8_u	0
	local.get	6
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	4                               # 4: down to label671
# %bb.10:                               #   in Loop: Header=BB32_9 Depth=1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label672
	br      	0                               # 0: up to label678
.LBB32_11:                              #   in Loop: Header=BB32_3 Depth=1
	end_loop
	end_block                               # label674:
	local.get	7
	local.get	3
	i32.add 
	local.set	9
	local.get	6
	local.get	3
	i32.add 
	local.set	12
	local.get	8
	i32.const	-32
	i32.add 
	local.set	8
	local.get	3
	i32.const	32
	i32.add 
	local.set	3
	local.get	12
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	9
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	12
	v128.load	0:p2align=0
	local.get	9
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label673
	br      	2                               # 2: down to label671
.LBB32_12:
	end_loop
	end_block                               # label672:
	local.get	1
	i32.load	28
	local.tee	5
	local.get	2
	i32.load	28
	i32.ne  
	br_if   	1                               # 1: down to label670
# %bb.13:
	local.get	0
	local.get	2
	i32.load	24
	i32.add 
	local.set	6
	local.get	0
	local.get	1
	i32.load	24
	i32.add 
	local.set	7
	i32.const	0
	local.set	3
	local.get	5
	local.set	8
.LBB32_14:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label679:
	block   	
	local.get	8
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label680
# %bb.15:
	i32.const	0
	local.get	3
	i32.sub 
	local.set	8
	local.get	6
	local.get	3
	i32.add 
	local.set	9
	local.get	7
	local.get	3
	i32.add 
	local.set	3
.LBB32_16:                              # =>This Inner Loop Header: Depth=1
	block   	
	block   	
	loop    	                                # label683:
	block   	
	local.get	5
	local.get	8
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label684
# %bb.17:
	i32.const	0
	local.set	4
	i32.const	0
	local.get	8
	i32.sub 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label681
# %bb.18:
	br      	2                               # 2: down to label682
.LBB32_19:                              #   in Loop: Header=BB32_16 Depth=1
	end_block                               # label684:
	local.get	8
	i32.const	-8
	i32.add 
	local.set	8
	local.get	9
	i64.load	0:p2align=0
	local.set	10
	local.get	3
	i64.load	0:p2align=0
	local.set	11
	local.get	3
	i32.const	8
	i32.add 
	local.set	3
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	local.get	10
	i64.eq  
	br_if   	0                               # 0: up to label683
	br      	5                               # 5: down to label671
.LBB32_20:                              # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label682:
	loop    	                                # label685:
	local.get	7
	local.get	3
	i32.add 
	i32.load8_u	0
	local.get	6
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	5                               # 5: down to label670
# %bb.21:                               #   in Loop: Header=BB32_20 Depth=1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: up to label685
.LBB32_22:
	end_loop
	end_block                               # label681:
	local.get	1
	i32.load	20
	local.tee	5
	local.get	2
	i32.load	20
	i32.ne  
	br_if   	3                               # 3: down to label670
# %bb.23:
	local.get	0
	local.get	2
	i32.load	16
	i32.add 
	local.set	6
	local.get	0
	local.get	1
	i32.load	16
	i32.add 
	local.set	7
	i32.const	0
	local.set	3
	local.get	5
	local.set	8
.LBB32_24:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label686:
	block   	
	local.get	8
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label687
# %bb.25:
	i32.const	0
	local.get	3
	i32.sub 
	local.set	8
	local.get	6
	local.get	3
	i32.add 
	local.set	9
	local.get	7
	local.get	3
	i32.add 
	local.set	3
.LBB32_26:                              # =>This Inner Loop Header: Depth=1
	block   	
	block   	
	loop    	                                # label690:
	block   	
	local.get	5
	local.get	8
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label691
# %bb.27:
	i32.const	0
	local.set	4
	i32.const	0
	local.get	8
	i32.sub 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label688
# %bb.28:
	br      	2                               # 2: down to label689
.LBB32_29:                              #   in Loop: Header=BB32_26 Depth=1
	end_block                               # label691:
	local.get	8
	i32.const	-8
	i32.add 
	local.set	8
	local.get	9
	i64.load	0:p2align=0
	local.set	10
	local.get	3
	i64.load	0:p2align=0
	local.set	11
	i32.const	0
	local.set	4
	local.get	3
	i32.const	8
	i32.add 
	local.set	3
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	local.get	10
	i64.eq  
	br_if   	0                               # 0: up to label690
	br      	8                               # 8: down to label670
.LBB32_30:                              # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label689:
	loop    	                                # label692:
	local.get	7
	local.get	3
	i32.add 
	i32.load8_u	0
	local.get	6
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	7                               # 7: down to label670
# %bb.31:                               #   in Loop: Header=BB32_30 Depth=1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: up to label692
.LBB32_32:
	end_loop
	end_block                               # label688:
	local.get	1
	i32.load	52
	local.tee	5
	local.get	2
	i32.load	52
	i32.ne  
	br_if   	5                               # 5: down to label670
# %bb.33:
	local.get	0
	local.get	2
	i32.load	48
	i32.add 
	local.set	6
	local.get	0
	local.get	1
	i32.load	48
	i32.add 
	local.set	7
	i32.const	0
	local.set	3
	local.get	5
	local.set	8
.LBB32_34:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label693:
	block   	
	local.get	8
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label694
# %bb.35:
	i32.const	0
	local.get	3
	i32.sub 
	local.set	8
	local.get	6
	local.get	3
	i32.add 
	local.set	9
	local.get	7
	local.get	3
	i32.add 
	local.set	3
.LBB32_36:                              # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label696:
	block   	
	local.get	5
	local.get	8
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label697
# %bb.37:
	i32.const	0
	local.get	8
	i32.sub 
	local.tee	3
	local.get	5
	i32.lt_u
	br_if   	2                               # 2: down to label695
# %bb.38:
	i32.const	1
	return
.LBB32_39:                              #   in Loop: Header=BB32_36 Depth=1
	end_block                               # label697:
	local.get	8
	i32.const	-8
	i32.add 
	local.set	8
	local.get	9
	i64.load	0:p2align=0
	local.set	10
	local.get	3
	i64.load	0:p2align=0
	local.set	11
	i32.const	0
	local.set	4
	local.get	3
	i32.const	8
	i32.add 
	local.set	3
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	local.get	10
	i64.eq  
	br_if   	0                               # 0: up to label696
	br      	9                               # 9: down to label670
.LBB32_40:                              # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label695:
	loop    	                                # label698:
	local.get	7
	local.get	3
	i32.add 
	i32.load8_u	0
	local.get	6
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	7                               # 7: down to label671
# %bb.41:                               #   in Loop: Header=BB32_40 Depth=1
	i32.const	1
	local.set	4
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	8                               # 8: down to label670
	br      	0                               # 0: up to label698
.LBB32_42:                              #   in Loop: Header=BB32_34 Depth=1
	end_loop
	end_block                               # label694:
	local.get	7
	local.get	3
	i32.add 
	local.set	9
	local.get	6
	local.get	3
	i32.add 
	local.set	12
	local.get	8
	i32.const	-32
	i32.add 
	local.set	8
	local.get	3
	i32.const	32
	i32.add 
	local.set	3
	i32.const	0
	local.set	4
	local.get	12
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	9
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	12
	v128.load	0:p2align=0
	local.get	9
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label693
	br      	6                               # 6: down to label670
.LBB32_43:                              #   in Loop: Header=BB32_24 Depth=1
	end_loop
	end_block                               # label687:
	local.get	7
	local.get	3
	i32.add 
	local.set	9
	local.get	6
	local.get	3
	i32.add 
	local.set	12
	local.get	8
	i32.const	-32
	i32.add 
	local.set	8
	local.get	3
	i32.const	32
	i32.add 
	local.set	3
	i32.const	0
	local.set	4
	local.get	12
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	9
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	12
	v128.load	0:p2align=0
	local.get	9
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label686
	br      	4                               # 4: down to label670
.LBB32_44:                              #   in Loop: Header=BB32_14 Depth=1
	end_loop
	end_block                               # label680:
	local.get	7
	local.get	3
	i32.add 
	local.set	9
	local.get	6
	local.get	3
	i32.add 
	local.set	12
	local.get	8
	i32.const	-32
	i32.add 
	local.set	8
	local.get	3
	i32.const	32
	i32.add 
	local.set	3
	local.get	12
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	9
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	12
	v128.load	0:p2align=0
	local.get	9
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label679
.LBB32_45:
	end_loop
	end_block                               # label671:
	i32.const	0
	local.set	4
.LBB32_46:
	end_block                               # label670:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.raw_term_content_quick_signature,"",@
	.type	raw_term_content_quick_signature,@function # -- Begin function raw_term_content_quick_signature
raw_term_content_quick_signature:       # @raw_term_content_quick_signature
	.functype	raw_term_content_quick_signature (i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	2
	block   	
	block   	
	local.get	1
	i32.load	40
	local.tee	3
	br_if   	0                               # 0: down to label700
# %bb.1:
	i32.const	0
	local.set	4
	i32.const	0
	local.set	5
	br      	1                               # 1: down to label699
.LBB33_2:
	end_block                               # label700:
	local.get	0
	local.get	1
	i32.load	36
	local.tee	6
	i32.add 
	local.set	7
	block   	
	block   	
	local.get	3
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label702
# %bb.3:
	local.get	7
	i32.load8_u	0
	local.set	2
	local.get	3
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label701
# %bb.4:
	local.get	7
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	8
	i32.shl 
	local.get	2
	i32.or  
	local.set	2
	local.get	3
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label701
# %bb.5:
	local.get	7
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	16
	i32.shl 
	local.get	2
	i32.or  
	local.set	2
	br      	1                               # 1: down to label701
.LBB33_6:
	end_block                               # label702:
	local.get	7
	i32.load	0:p2align=0
	local.set	4
	block   	
	local.get	3
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label703
# %bb.7:
	local.get	4
	local.set	2
	local.get	4
	local.set	5
	br      	2                               # 2: down to label699
.LBB33_8:
	end_block                               # label703:
	i32.const	0
	local.get	3
	i32.const	-4
	i32.add 
	local.tee	2
	local.get	2
	local.get	3
	i32.gt_u
	i32.select
	local.set	8
	i32.const	0
	local.set	5
	i32.const	0
	local.set	2
	block   	
	local.get	3
	local.get	8
	i32.const	1
	i32.shr_u
	local.tee	9
	i32.le_u
	br_if   	0                               # 0: down to label704
# %bb.9:
	local.get	7
	local.get	9
	i32.add 
	local.set	10
	block   	
	local.get	3
	local.get	9
	i32.sub 
	local.tee	11
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label705
# %bb.10:
	i32.const	0
	local.set	9
	i32.const	0
	local.set	2
.LBB33_11:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label706:
	local.get	10
	i32.load8_u	0
	local.get	9
	i32.shl 
	local.get	2
	i32.or  
	local.set	2
	local.get	10
	i32.const	1
	i32.add 
	local.set	10
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	i32.const	-1
	i32.add 
	local.tee	11
	br_if   	0                               # 0: up to label706
	br      	2                               # 2: down to label704
.LBB33_12:
	end_loop
	end_block                               # label705:
	local.get	10
	i32.load	0:p2align=0
	local.set	2
.LBB33_13:
	end_block                               # label704:
	local.get	3
	local.get	8
	i32.le_u
	br_if   	1                               # 1: down to label699
# %bb.14:
	block   	
	local.get	3
	local.get	8
	i32.sub 
	local.tee	5
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label707
# %bb.15:
	i32.const	0
	local.set	10
	i32.const	0
	local.get	5
	i32.sub 
	local.set	9
	local.get	0
	local.get	3
	local.get	6
	i32.add 
	i32.add 
	local.set	0
	i32.const	0
	local.set	5
.LBB33_16:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label708:
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.get	10
	i32.shl 
	local.get	5
	i32.or  
	local.set	5
	local.get	10
	i32.const	8
	i32.add 
	local.set	10
	local.get	9
	i32.const	1
	i32.add 
	local.tee	11
	local.set	9
	local.get	11
	br_if   	0                               # 0: up to label708
	br      	3                               # 3: down to label699
.LBB33_17:
	end_loop
	end_block                               # label707:
	local.get	7
	local.get	8
	i32.add 
	i32.load	0:p2align=0
	local.set	5
	br      	1                               # 1: down to label699
.LBB33_18:
	end_block                               # label701:
	local.get	2
	local.set	4
	local.get	2
	local.set	5
.LBB33_19:
	end_block                               # label699:
	local.get	4
	local.get	3
	i32.const	-1640531535
	i32.mul 
	i32.xor 
	local.get	1
	i32.load	28
	i32.const	-2048144789
	i32.mul 
	i32.xor 
	local.get	1
	i32.load	20
	i32.const	-1028477387
	i32.mul 
	i32.xor 
	local.get	1
	i32.load	52
	i32.const	668265263
	i32.mul 
	i32.xor 
	i32.const	13
	i32.rotl
	local.get	2
	i32.const	374761393
	i32.mul 
	i32.xor 
	i32.const	11
	i32.rotl
	local.get	5
	i32.xor 
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.next_term_row,"",@
	.type	next_term_row,@function         # -- Begin function next_term_row
next_term_row:                          # @next_term_row
	.functype	next_term_row (i32, i32) -> (i32)
	.local  	i32, i32, i32, i32
# %bb.0:
	local.get	0
	i32.load	0
	local.set	2
	block   	
	local.get	1
	local.get	0
	i32.load	20
	local.tee	3
	i32.ge_u
	br_if   	0                               # 0: down to label709
# %bb.1:
.LBB34_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label710:
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label709
# %bb.3:                                #   in Loop: Header=BB34_2 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label709
# %bb.4:                                #   in Loop: Header=BB34_2 Depth=1
	local.get	3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	0                               # 0: up to label710
# %bb.5:
	end_loop
	i32.const	-1
	return
.LBB34_6:
	end_block                               # label709:
	i32.const	-1
	local.set	5
	block   	
	local.get	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label711
# %bb.7:
	block   	
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	4
	i32.const	44
	i32.eq  
	br_if   	0                               # 0: down to label712
# %bb.8:
	local.get	4
	i32.const	93
	i32.ne  
	br_if   	1                               # 1: down to label711
# %bb.9:
	block   	
	block   	
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label714
# %bb.10:
.LBB34_11:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label715:
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label714
# %bb.12:                               #   in Loop: Header=BB34_11 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label714
# %bb.13:                               #   in Loop: Header=BB34_11 Depth=1
	local.get	3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	0                               # 0: up to label715
	br      	2                               # 2: down to label713
.LBB34_14:
	end_loop
	end_block                               # label714:
	local.get	1
	local.get	3
	i32.ne  
	br_if   	2                               # 2: down to label711
.LBB34_15:
	end_block                               # label713:
	local.get	0
	call	next_term_bank
	return
.LBB34_16:
	end_block                               # label712:
	block   	
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label716
# %bb.17:
.LBB34_18:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label717:
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label716
# %bb.19:                               #   in Loop: Header=BB34_18 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label716
# %bb.20:                               #   in Loop: Header=BB34_18 Depth=1
	local.get	3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	0                               # 0: up to label717
	br      	2                               # 2: down to label711
.LBB34_21:
	end_loop
	end_block                               # label716:
	local.get	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label711
# %bb.22:
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.eq  
	br_if   	0                               # 0: down to label711
# %bb.23:
	local.get	0
	local.get	1
	i32.store	24
	i32.const	1
	local.set	5
.LBB34_24:
	end_block                               # label711:
	local.get	5
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.compact_term_lookup_keys,"",@
	.globl	compact_term_lookup_keys        # -- Begin function compact_term_lookup_keys
	.type	compact_term_lookup_keys,@function
compact_term_lookup_keys:               # @compact_term_lookup_keys
	.functype	compact_term_lookup_keys (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, v128, v128, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-1
	local.set	20
	block   	
	local.get	5
	i32x4.splat
	local.get	0
	i32x4.replace_lane	1
	local.get	2
	i32x4.replace_lane	2
	local.get	3
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	21
	i32x4.eq
	v128.const	255, 255, 255, 255
	local.tee	22
	v128.and
	local.get	4
	i32x4.splat
	local.get	6
	i32x4.replace_lane	1
	local.get	7
	i32x4.replace_lane	2
	local.get	8
	i32x4.replace_lane	3
	local.get	21
	i32x4.eq
	local.get	22
	v128.and
	i16x8.narrow_i32x4_u
	local.get	10
	i32x4.splat
	local.get	19
	i32x4.replace_lane	1
	local.get	11
	i32x4.replace_lane	2
	local.get	12
	i32x4.replace_lane	3
	local.get	21
	i32x4.eq
	local.get	22
	v128.and
	local.get	13
	i32x4.splat
	local.get	14
	i32x4.replace_lane	1
	local.get	15
	i32x4.replace_lane	2
	local.get	16
	i32x4.replace_lane	3
	local.get	21
	i32x4.eq
	local.get	22
	v128.and
	i16x8.narrow_i32x4_u
	i8x16.narrow_i16x8_u
	v128.any_true
	br_if   	0                               # 0: down to label718
# %bb.1:
	local.get	18
	i32.const	65534
	i32.gt_u
	br_if   	0                               # 0: down to label718
# %bb.2:
	local.get	5
	i32.const	1073741823
	i32.gt_u
	br_if   	0                               # 0: down to label718
# %bb.3:
	local.get	9
	i32.const	-65535
	i32.add 
	i32.const	-65534
	i32.lt_u
	br_if   	0                               # 0: down to label718
# %bb.4:
	i32.const	0
	local.set	23
	local.get	3
	local.set	24
	local.get	2
	local.set	25
	local.get	5
	local.set	26
.LBB35_5:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label719:
	i32.const	-2
	local.set	20
	local.get	1
	local.get	23
	i32.lt_u
	br_if   	1                               # 1: down to label718
# %bb.6:                                #   in Loop: Header=BB35_5 Depth=1
	local.get	24
	i32.load	0
	local.get	23
	i32.ne  
	br_if   	1                               # 1: down to label718
# %bb.7:                                #   in Loop: Header=BB35_5 Depth=1
	local.get	1
	local.get	23
	i32.sub 
	local.get	25
	i32.load16_u	0
	local.tee	27
	i32.lt_u
	br_if   	1                               # 1: down to label718
# %bb.8:                                #   in Loop: Header=BB35_5 Depth=1
	local.get	24
	i32.const	4
	i32.add 
	local.set	24
	local.get	25
	i32.const	2
	i32.add 
	local.set	25
	local.get	23
	local.get	27
	i32.add 
	local.set	23
	local.get	26
	i32.const	-1
	i32.add 
	local.tee	26
	br_if   	0                               # 0: up to label719
# %bb.9:
	end_loop
	local.get	23
	local.get	1
	i32.ne  
	br_if   	0                               # 0: down to label718
# %bb.10:
	i32.const	0
	local.set	23
	block   	
	local.get	5
	i32.const	2
	i32.shl 
	local.tee	24
	i32.eqz
	br_if   	0                               # 0: down to label720
# %bb.11:
	local.get	10
	i32.const	0
	local.get	24
	memory.fill	0
.LBB35_12:
	end_block                               # label720:
	i32.const	0
	local.set	25
	block   	
	local.get	9
	i32.eqz
	br_if   	0                               # 0: down to label721
# %bb.13:
	i32.const	0
	local.set	25
	i32.const	0
	local.set	23
.LBB35_14:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label722:
	block   	
	local.get	8
	i32.load8_u	0
	local.tee	24
	i32.const	1
	i32.le_u
	br_if   	0                               # 0: down to label723
# %bb.15:
	i32.const	-3
	return
.LBB35_16:                              #   in Loop: Header=BB35_14 Depth=1
	end_block                               # label723:
	block   	
	local.get	6
	i32.load	0
	local.tee	1
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: down to label724
# %bb.17:
	i32.const	-3
	return
.LBB35_18:                              #   in Loop: Header=BB35_14 Depth=1
	end_block                               # label724:
	block   	
	local.get	2
	local.get	1
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	27
	i32.load16_u	0
	local.tee	26
	br_if   	0                               # 0: down to label725
# %bb.19:
	i32.const	-3
	return
.LBB35_20:                              #   in Loop: Header=BB35_14 Depth=1
	end_block                               # label725:
	local.get	6
	local.get	7
	local.get	24
	i32.select
	i32.load	0
	local.set	24
	block   	
	local.get	10
	local.get	1
	i32.const	2
	i32.shl 
	local.tee	28
	i32.add 
	local.tee	29
	i32.load	0
	local.tee	1
	br_if   	0                               # 0: down to label726
# %bb.21:                               #   in Loop: Header=BB35_14 Depth=1
	i32.const	-4
	local.set	20
	local.get	23
	local.get	18
	i32.ge_u
	br_if   	3                               # 3: down to label718
# %bb.22:                               #   in Loop: Header=BB35_14 Depth=1
	local.get	17
	local.get	25
	i32.sub 
	local.get	26
	i32.lt_u
	br_if   	3                               # 3: down to label718
# %bb.23:                               #   in Loop: Header=BB35_14 Depth=1
	local.get	12
	local.get	23
	i32.const	2
	i32.shl 
	local.tee	1
	i32.add 
	local.get	25
	i32.store	0
	local.get	13
	local.get	1
	i32.add 
	local.get	4
	local.get	28
	i32.add 
	i32.load	0
	i32.store	0
	local.get	11
	local.get	23
	i32.const	1
	i32.shl 
	i32.add 
	local.get	26
	i32.store16	0
	block   	
	local.get	27
	i32.load16_u	0
	local.tee	1
	i32.eqz
	br_if   	0                               # 0: down to label727
# %bb.24:                               #   in Loop: Header=BB35_14 Depth=1
	local.get	16
	local.get	25
	i32.add 
	local.get	0
	local.get	3
	local.get	28
	i32.add 
	i32.load	0
	i32.add 
	local.get	1
	memory.copy	0, 0
.LBB35_25:                              #   in Loop: Header=BB35_14 Depth=1
	end_block                               # label727:
	local.get	29
	local.get	23
	i32.const	1
	i32.add 
	local.tee	23
	i32.store	0
	local.get	25
	local.get	27
	i32.load16_u	0
	i32.add 
	local.set	25
	local.get	23
	local.set	1
.LBB35_26:                              #   in Loop: Header=BB35_14 Depth=1
	end_block                               # label726:
	local.get	14
	local.get	1
	i32.const	-1
	i32.add 
	i32.store	0
	block   	
	local.get	24
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: down to label728
# %bb.27:
	i32.const	-3
	return
.LBB35_28:                              #   in Loop: Header=BB35_14 Depth=1
	end_block                               # label728:
	i32.const	-3
	local.set	20
	local.get	2
	local.get	24
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	26
	i32.load16_u	0
	local.tee	1
	i32.eqz
	br_if   	2                               # 2: down to label718
# %bb.29:                               #   in Loop: Header=BB35_14 Depth=1
	block   	
	local.get	10
	local.get	24
	i32.const	2
	i32.shl 
	local.tee	27
	i32.add 
	local.tee	28
	i32.load	0
	local.tee	24
	br_if   	0                               # 0: down to label729
# %bb.30:                               #   in Loop: Header=BB35_14 Depth=1
	i32.const	-4
	local.set	20
	local.get	23
	local.get	18
	i32.ge_u
	br_if   	3                               # 3: down to label718
# %bb.31:                               #   in Loop: Header=BB35_14 Depth=1
	local.get	17
	local.get	25
	i32.sub 
	local.get	1
	i32.lt_u
	br_if   	3                               # 3: down to label718
# %bb.32:                               #   in Loop: Header=BB35_14 Depth=1
	local.get	12
	local.get	23
	i32.const	2
	i32.shl 
	local.tee	24
	i32.add 
	local.get	25
	i32.store	0
	local.get	13
	local.get	24
	i32.add 
	local.get	4
	local.get	27
	i32.add 
	i32.load	0
	i32.store	0
	local.get	11
	local.get	23
	i32.const	1
	i32.shl 
	i32.add 
	local.get	1
	i32.store16	0
	block   	
	local.get	26
	i32.load16_u	0
	local.tee	24
	i32.eqz
	br_if   	0                               # 0: down to label730
# %bb.33:                               #   in Loop: Header=BB35_14 Depth=1
	local.get	16
	local.get	25
	i32.add 
	local.get	0
	local.get	3
	local.get	27
	i32.add 
	i32.load	0
	i32.add 
	local.get	24
	memory.copy	0, 0
.LBB35_34:                              #   in Loop: Header=BB35_14 Depth=1
	end_block                               # label730:
	local.get	28
	local.get	23
	i32.const	1
	i32.add 
	local.tee	23
	i32.store	0
	local.get	25
	local.get	26
	i32.load16_u	0
	i32.add 
	local.set	25
	local.get	23
	local.set	24
.LBB35_35:                              #   in Loop: Header=BB35_14 Depth=1
	end_block                               # label729:
	local.get	15
	local.get	24
	i32.const	-1
	i32.add 
	i32.store	0
	local.get	8
	i32.const	1
	i32.add 
	local.set	8
	local.get	6
	i32.const	4
	i32.add 
	local.set	6
	local.get	14
	i32.const	4
	i32.add 
	local.set	14
	local.get	15
	i32.const	4
	i32.add 
	local.set	15
	local.get	7
	i32.const	4
	i32.add 
	local.set	7
	local.get	9
	i32.const	-1
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label722
.LBB35_36:
	end_loop
	end_block                               # label721:
	local.get	19
	local.get	25
	i32.store	0
	local.get	23
	local.set	20
.LBB35_37:
	end_block                               # label718:
	local.get	20
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.write_normalized_glossary_value,"",@
	.type	write_normalized_glossary_value,@function # -- Begin function write_normalized_glossary_value
write_normalized_glossary_value:        # @write_normalized_glossary_value
	.functype	write_normalized_glossary_value (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	7
	global.set	__stack_pointer
	i32.const	0
	local.set	8
	block   	
	local.get	3
	local.get	2
	i32.le_u
	br_if   	0                               # 0: down to label731
# %bb.1:
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	local.tee	9
	i32.load8_u	0
	local.tee	10
	i32.const	123
	i32.eq  
	br_if   	0                               # 0: down to label734
# %bb.2:
	local.get	10
	i32.const	91
	i32.ne  
	br_if   	1                               # 1: down to label733
# %bb.3:
	local.get	6
	i32.load	0
	local.tee	10
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label731
# %bb.4:
	local.get	4
	local.get	10
	i32.add 
	i32.const	91
	i32.store8	0
	local.get	6
	local.get	6
	i32.load	0
	i32.const	1
	i32.add 
	local.tee	11
	i32.store	0
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label735
# %bb.5:
	i32.const	0
	local.set	11
.LBB36_6:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB36_7 Depth 2
                                        #     Child Loop BB36_19 Depth 2
	loop    	                                # label736:
	block   	
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label737
.LBB36_7:                               #   Parent Loop BB36_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label738:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label737
# %bb.8:                                #   in Loop: Header=BB36_7 Depth=2
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label737
# %bb.9:                                #   in Loop: Header=BB36_7 Depth=2
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label738
# %bb.10:                               #   in Loop: Header=BB36_6 Depth=1
	end_loop
	local.get	1
	local.set	10
.LBB36_11:                              #   in Loop: Header=BB36_6 Depth=1
	end_block                               # label737:
	i32.const	0
	local.set	8
	local.get	10
	local.get	3
	i32.ge_u
	br_if   	5                               # 5: down to label731
# %bb.12:                               #   in Loop: Header=BB36_6 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.eq  
	br_if   	0                               # 0: down to label739
# %bb.13:                               #   in Loop: Header=BB36_6 Depth=1
	local.get	7
	i32.const	0
	i32.store	8
	local.get	0
	local.get	1
	local.get	10
	local.get	7
	i32.const	8
	i32.add 
	call	parse_value_span
	i32.eqz
	br_if   	6                               # 6: down to label731
# %bb.14:                               #   in Loop: Header=BB36_6 Depth=1
	block   	
	local.get	11
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label740
# %bb.15:                               #   in Loop: Header=BB36_6 Depth=1
	local.get	6
	i32.load	0
	local.tee	2
	local.get	5
	i32.ge_u
	br_if   	7                               # 7: down to label731
# %bb.16:                               #   in Loop: Header=BB36_6 Depth=1
	local.get	4
	local.get	2
	i32.add 
	i32.const	44
	i32.store8	0
	local.get	6
	local.get	6
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
.LBB36_17:                              #   in Loop: Header=BB36_6 Depth=1
	end_block                               # label740:
	local.get	0
	local.get	1
	local.get	10
	local.get	7
	i32.load	8
	local.tee	2
	local.get	4
	local.get	5
	local.get	6
	call	write_normalized_glossary_value
	i32.eqz
	br_if   	6                               # 6: down to label731
# %bb.18:                               #   in Loop: Header=BB36_6 Depth=1
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label741
.LBB36_19:                              #   Parent Loop BB36_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label742:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label741
# %bb.20:                               #   in Loop: Header=BB36_19 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label741
# %bb.21:                               #   in Loop: Header=BB36_19 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label742
# %bb.22:                               #   in Loop: Header=BB36_6 Depth=1
	end_loop
	local.get	1
	local.set	2
.LBB36_23:                              #   in Loop: Header=BB36_6 Depth=1
	end_block                               # label741:
	block   	
	block   	
	local.get	2
	local.get	3
	i32.lt_u
	br_if   	0                               # 0: down to label744
# %bb.24:                               #   in Loop: Header=BB36_6 Depth=1
	local.get	2
	local.set	10
	br      	1                               # 1: down to label743
.LBB36_25:                              #   in Loop: Header=BB36_6 Depth=1
	end_block                               # label744:
	local.get	2
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.eq  
	i32.add 
	local.set	10
.LBB36_26:                              #   in Loop: Header=BB36_6 Depth=1
	end_block                               # label743:
	i32.const	1
	local.set	11
	local.get	10
	local.get	3
	i32.lt_u
	br_if   	1                               # 1: up to label736
.LBB36_27:
	end_block                               # label739:
	end_loop
	local.get	6
	i32.load	0
	local.set	11
.LBB36_28:
	end_block                               # label735:
	i32.const	0
	local.set	8
	local.get	11
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label731
# %bb.29:
	local.get	4
	local.get	11
	i32.add 
	i32.const	93
	i32.store8	0
	i32.const	1
	local.set	8
	local.get	6
	local.get	6
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
	br      	3                               # 3: down to label731
.LBB36_30:
	end_block                               # label734:
	local.get	3
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label733
# %bb.31:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label745
# %bb.32:
.LBB36_33:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label746:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	1
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label745
# %bb.34:                               #   in Loop: Header=BB36_33 Depth=1
	i32.const	1
	local.get	1
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label745
# %bb.35:                               #   in Loop: Header=BB36_33 Depth=1
	local.get	3
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label746
	br      	2                               # 2: down to label733
.LBB36_36:
	end_loop
	end_block                               # label745:
	local.get	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label733
# %bb.37:
	local.get	0
	i32.const	1
	i32.add 
	local.set	12
	local.get	0
	i32.const	2
	i32.add 
	local.set	13
	local.get	0
	i32.const	5
	i32.add 
	local.set	14
	local.get	0
	i32.const	4
	i32.add 
	local.set	15
	local.get	0
	i32.const	3
	i32.add 
	local.set	16
	i32.const	0
	local.set	17
	i32.const	0
	local.set	18
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
.LBB36_38:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB36_49 Depth 2
                                        #     Child Loop BB36_102 Depth 2
                                        #     Child Loop BB36_108 Depth 2
                                        #     Child Loop BB36_134 Depth 2
                                        #     Child Loop BB36_141 Depth 2
	loop    	                                # label747:
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	34
	i32.eq  
	br_if   	0                               # 0: down to label748
# %bb.39:
	local.get	1
	i32.const	125
	i32.ne  
	br_if   	2                               # 2: down to label733
# %bb.40:
	local.get	20
	i32.eqz
	br_if   	2                               # 2: down to label733
# %bb.41:
	local.get	19
	i32.eqz
	br_if   	2                               # 2: down to label733
# %bb.42:
	i32.const	0
	local.set	8
	local.get	6
	i32.load	0
	local.tee	10
	local.get	17
	i32.add 
	local.tee	2
	local.get	10
	i32.lt_u
	br_if   	4                               # 4: down to label731
# %bb.43:
	local.get	2
	local.get	5
	i32.gt_u
	br_if   	4                               # 4: down to label731
# %bb.44:
	block   	
	local.get	17
	i32.eqz
	br_if   	0                               # 0: down to label749
# %bb.45:
	local.get	4
	local.get	10
	i32.add 
	local.get	0
	local.get	18
	i32.add 
	local.get	17
	memory.copy	0, 0
.LBB36_46:
	end_block                               # label749:
	local.get	6
	local.get	2
	i32.store	0
	br      	3                               # 3: down to label732
.LBB36_47:                              #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label748:
	local.get	10
	i32.const	1
	i32.add 
	local.tee	21
	local.get	3
	i32.ge_u
	br_if   	1                               # 1: down to label733
# %bb.48:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	21
	local.set	11
.LBB36_49:                              #   Parent Loop BB36_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label750:
	block   	
	local.get	11
	local.tee	1
	i32.const	8
	i32.add 
	local.tee	11
	local.get	3
	i32.gt_u
	br_if   	0                               # 0: down to label751
# %bb.50:                               #   in Loop: Header=BB36_49 Depth=2
	local.get	0
	local.get	1
	i32.add 
	i64.load	0:p2align=0
	local.tee	22
	i64.const	-1
	i64.xor 
	local.get	22
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	22
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	22
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	22
	i64.eqz
	br_if   	1                               # 1: up to label750
# %bb.51:                               #   in Loop: Header=BB36_49 Depth=2
	local.get	22
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	1
	i32.add 
	local.set	1
.LBB36_52:                              #   in Loop: Header=BB36_49 Depth=2
	end_block                               # label751:
	local.get	1
	local.get	3
	i32.ge_u
	br_if   	2                               # 2: down to label733
# %bb.53:                               #   in Loop: Header=BB36_49 Depth=2
	block   	
	block   	
	block   	
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label754
# %bb.54:                               #   in Loop: Header=BB36_49 Depth=2
	local.get	1
	i32.const	1
	i32.add 
	local.tee	11
	local.get	3
	i32.ge_u
	br_if   	5                               # 5: down to label733
# %bb.55:                               #   in Loop: Header=BB36_49 Depth=2
	block   	
	block   	
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 1, 0, 7} # 7: down to label733
                                        # 1: down to label755
                                        # 0: down to label756
.LBB36_56:                              #   in Loop: Header=BB36_49 Depth=2
	end_block                               # label756:
	local.get	1
	i32.const	6
	i32.add 
	local.tee	11
	local.get	3
	i32.gt_u
	br_if   	6                               # 6: down to label733
# %bb.57:                               #   in Loop: Header=BB36_49 Depth=2
	local.get	1
	i32.const	2
	i32.add 
	local.tee	23
	local.get	11
	i32.ge_u
	br_if   	2                               # 2: down to label753
# %bb.58:                               #   in Loop: Header=BB36_49 Depth=2
	block   	
	local.get	0
	local.get	23
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label757
# %bb.59:                               #   in Loop: Header=BB36_49 Depth=2
	local.get	23
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label733
.LBB36_60:                              #   in Loop: Header=BB36_49 Depth=2
	end_block                               # label757:
	block   	
	local.get	16
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label758
# %bb.61:                               #   in Loop: Header=BB36_49 Depth=2
	local.get	23
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label733
.LBB36_62:                              #   in Loop: Header=BB36_49 Depth=2
	end_block                               # label758:
	block   	
	local.get	15
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label759
# %bb.63:                               #   in Loop: Header=BB36_49 Depth=2
	local.get	23
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label733
.LBB36_64:                              #   in Loop: Header=BB36_49 Depth=2
	end_block                               # label759:
	local.get	14
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label753
# %bb.65:                               #   in Loop: Header=BB36_49 Depth=2
	local.get	1
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label753
	br      	6                               # 6: down to label733
.LBB36_66:                              #   in Loop: Header=BB36_49 Depth=2
	end_block                               # label755:
	local.get	1
	i32.const	2
	i32.add 
	local.set	11
	br      	1                               # 1: down to label753
.LBB36_67:                              #   in Loop: Header=BB36_49 Depth=2
	end_block                               # label754:
	local.get	23
	i32.const	32
	i32.lt_u
	br_if   	4                               # 4: down to label733
# %bb.68:                               #   in Loop: Header=BB36_49 Depth=2
	local.get	1
	i32.const	1
	i32.add 
	local.set	11
	local.get	23
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label752
.LBB36_69:                              #   in Loop: Header=BB36_49 Depth=2
	end_block                               # label753:
	local.get	11
	local.get	3
	i32.lt_u
	br_if   	1                               # 1: up to label750
	br      	3                               # 3: down to label733
.LBB36_70:                              #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label752:
	end_loop
	i32.const	0
	local.set	23
	i32.const	0
	local.set	24
	block   	
	local.get	1
	local.get	10
	i32.lt_u
	br_if   	0                               # 0: down to label760
# %bb.71:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	10
	i32.const	5
	i32.add 
	local.set	25
	i32.const	0
	local.set	24
	i32.const	0
	local.set	23
	block   	
	local.get	1
	local.get	10
	i32.eq  
	br_if   	0                               # 0: down to label761
# %bb.72:                               #   in Loop: Header=BB36_38 Depth=1
	block   	
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	local.tee	26
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label762
# %bb.73:                               #   in Loop: Header=BB36_38 Depth=1
	i32.const	0
	local.set	23
	local.get	1
	local.get	10
	i32.sub 
	local.tee	27
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label761
# %bb.74:                               #   in Loop: Header=BB36_38 Depth=1
	i32.const	0
	local.set	23
	local.get	26
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label761
# %bb.75:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	13
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	26
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label762
# %bb.76:                               #   in Loop: Header=BB36_38 Depth=1
	i32.const	0
	local.set	23
	local.get	26
	i32.const	121
	i32.ne  
	br_if   	1                               # 1: down to label761
# %bb.77:                               #   in Loop: Header=BB36_38 Depth=1
	i32.const	0
	local.set	23
	local.get	27
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label761
# %bb.78:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	16
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	26
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label762
# %bb.79:                               #   in Loop: Header=BB36_38 Depth=1
	i32.const	0
	local.set	23
	local.get	26
	i32.const	112
	i32.ne  
	br_if   	1                               # 1: down to label761
# %bb.80:                               #   in Loop: Header=BB36_38 Depth=1
	i32.const	0
	local.set	23
	local.get	27
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label761
# %bb.81:                               #   in Loop: Header=BB36_38 Depth=1
	i32.const	0
	local.set	23
	block   	
	local.get	15
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label761
                                        # 0: down to label763
.LBB36_82:                              #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label763:
	i32.const	0
	local.set	23
	local.get	25
	local.get	1
	i32.gt_u
	br_if   	1                               # 1: down to label761
# %bb.83:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	0
	local.get	25
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	23
	br      	1                               # 1: down to label761
.LBB36_84:                              #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label762:
	local.get	0
	local.get	10
	local.get	11
	i32.const	.L.str
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	23
.LBB36_85:                              #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label761:
	local.get	1
	local.get	10
	i32.le_u
	br_if   	0                               # 0: down to label760
# %bb.86:                               #   in Loop: Header=BB36_38 Depth=1
	block   	
	block   	
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	local.tee	21
	i32.const	116
	i32.ne  
	br_if   	0                               # 0: down to label765
# %bb.87:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	10
	i32.const	2
	i32.add 
	local.tee	21
	local.get	1
	i32.gt_u
	br_if   	2                               # 2: down to label760
# %bb.88:                               #   in Loop: Header=BB36_38 Depth=1
	block   	
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{2, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label760
                                        # 0: down to label766
.LBB36_89:                              #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label766:
	local.get	10
	i32.const	3
	i32.add 
	local.tee	21
	local.get	1
	i32.gt_u
	br_if   	2                               # 2: down to label760
# %bb.90:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	local.tee	21
	i32.const	92
	i32.eq  
	br_if   	1                               # 1: down to label764
# %bb.91:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	21
	i32.const	120
	i32.ne  
	br_if   	2                               # 2: down to label760
# %bb.92:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	10
	i32.const	4
	i32.add 
	local.tee	21
	local.get	1
	i32.gt_u
	br_if   	2                               # 2: down to label760
# %bb.93:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	local.tee	21
	i32.const	92
	i32.eq  
	br_if   	1                               # 1: down to label764
# %bb.94:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	21
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label760
# %bb.95:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	25
	local.get	1
	i32.gt_u
	br_if   	2                               # 2: down to label760
# %bb.96:                               #   in Loop: Header=BB36_38 Depth=1
	local.get	0
	local.get	25
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	24
	br      	2                               # 2: down to label760
.LBB36_97:                              #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label765:
	local.get	21
	i32.const	92
	i32.ne  
	br_if   	1                               # 1: down to label760
.LBB36_98:                              #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label764:
	local.get	0
	local.get	10
	local.get	11
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	24
.LBB36_99:                              #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label760:
	block   	
	local.get	23
	br_if   	0                               # 0: down to label767
# %bb.100:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	24
	i32.eqz
	br_if   	2                               # 2: down to label733
.LBB36_101:                             #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label767:
	block   	
	local.get	11
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label768
.LBB36_102:                             #   Parent Loop BB36_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label769:
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label768
# %bb.103:                              #   in Loop: Header=BB36_102 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label768
# %bb.104:                              #   in Loop: Header=BB36_102 Depth=2
	local.get	3
	local.get	11
	i32.const	1
	i32.add 
	local.tee	11
	i32.ne  
	br_if   	0                               # 0: up to label769
	br      	3                               # 3: down to label733
.LBB36_105:                             #   in Loop: Header=BB36_38 Depth=1
	end_loop
	end_block                               # label768:
	local.get	11
	local.get	3
	i32.ge_u
	br_if   	1                               # 1: down to label733
# %bb.106:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	1                               # 1: down to label733
# %bb.107:                              #   in Loop: Header=BB36_38 Depth=1
	block   	
	local.get	11
	i32.const	1
	i32.add 
	local.tee	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label770
.LBB36_108:                             #   Parent Loop BB36_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label771:
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label770
# %bb.109:                              #   in Loop: Header=BB36_108 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label770
# %bb.110:                              #   in Loop: Header=BB36_108 Depth=2
	local.get	3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	0                               # 0: up to label771
# %bb.111:                              #   in Loop: Header=BB36_38 Depth=1
	end_loop
	local.get	3
	local.set	1
.LBB36_112:                             #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label770:
	local.get	7
	i32.const	0
	i32.store	12
	local.get	0
	local.get	3
	local.get	1
	local.get	7
	i32.const	12
	i32.add 
	call	parse_value_span
	i32.eqz
	br_if   	1                               # 1: down to label733
# %bb.113:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	7
	i32.load	12
	local.set	10
	block   	
	block   	
	block   	
	block   	
	local.get	23
	i32.eqz
	br_if   	0                               # 0: down to label775
# %bb.114:                              #   in Loop: Header=BB36_38 Depth=1
	i32.const	0
	local.set	20
	local.get	10
	local.get	1
	i32.le_u
	br_if   	3                               # 3: down to label772
# %bb.115:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	3                               # 3: down to label772
# %bb.116:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	10
	local.get	1
	i32.const	-1
	i32.xor 
	i32.add 
	local.tee	11
	i32.eqz
	br_if   	3                               # 3: down to label772
# %bb.117:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	12
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	92
	i32.eq  
	br_if   	2                               # 2: down to label773
# %bb.118:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	11
	i32.const	1
	i32.eq  
	br_if   	3                               # 3: down to label772
# %bb.119:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	23
	i32.const	116
	i32.ne  
	br_if   	3                               # 3: down to label772
# %bb.120:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	13
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{2, 3, 3, 3, 3, 3, 3, 3, 3, 1, 3} # 3: down to label772
                                        # 1: down to label774
.LBB36_121:                             #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label775:
	i32.const	0
	local.set	19
	block   	
	local.get	10
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label776
# %bb.122:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	19
.LBB36_123:                             #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label776:
	local.get	10
	local.get	1
	i32.sub 
	local.set	17
	local.get	1
	local.set	18
	br      	2                               # 2: down to label772
.LBB36_124:                             #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label774:
	local.get	11
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label772
# %bb.125:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	16
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label773
# %bb.126:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	23
	i32.const	120
	i32.ne  
	br_if   	1                               # 1: down to label772
# %bb.127:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	11
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label772
# %bb.128:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	15
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label773
# %bb.129:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	11
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label772
# %bb.130:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	1
	i32.const	5
	i32.add 
	local.tee	1
	local.get	10
	i32.ge_u
	br_if   	1                               # 1: down to label772
# %bb.131:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	20
	br      	1                               # 1: down to label772
.LBB36_132:                             #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label773:
	local.get	0
	local.get	1
	local.get	10
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	20
.LBB36_133:                             #   in Loop: Header=BB36_38 Depth=1
	end_block                               # label772:
	block   	
	local.get	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label777
.LBB36_134:                             #   Parent Loop BB36_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label778:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	1
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label777
# %bb.135:                              #   in Loop: Header=BB36_134 Depth=2
	i32.const	1
	local.get	1
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label777
# %bb.136:                              #   in Loop: Header=BB36_134 Depth=2
	local.get	3
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label778
	br      	3                               # 3: down to label733
.LBB36_137:                             #   in Loop: Header=BB36_38 Depth=1
	end_loop
	end_block                               # label777:
	local.get	10
	local.get	3
	i32.ge_u
	br_if   	1                               # 1: down to label733
# %bb.138:                              #   in Loop: Header=BB36_38 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	125
	i32.eq  
	br_if   	0                               # 0: down to label779
# %bb.139:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	1
	i32.const	44
	i32.ne  
	br_if   	2                               # 2: down to label733
# %bb.140:                              #   in Loop: Header=BB36_38 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label779
.LBB36_141:                             #   Parent Loop BB36_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label780:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	1
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label779
# %bb.142:                              #   in Loop: Header=BB36_141 Depth=2
	i32.const	1
	local.get	1
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label779
# %bb.143:                              #   in Loop: Header=BB36_141 Depth=2
	local.get	3
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label780
	br      	3                               # 3: down to label733
.LBB36_144:                             #   in Loop: Header=BB36_38 Depth=1
	end_loop
	end_block                               # label779:
	local.get	10
	local.get	3
	i32.lt_u
	br_if   	0                               # 0: up to label747
.LBB36_145:
	end_loop
	end_block                               # label733:
	local.get	6
	i32.load	0
	local.tee	10
	local.get	3
	local.get	2
	i32.sub 
	local.tee	2
	i32.add 
	local.tee	0
	local.get	10
	i32.lt_u
	br_if   	1                               # 1: down to label731
# %bb.146:
	local.get	0
	local.get	5
	i32.gt_u
	br_if   	1                               # 1: down to label731
# %bb.147:
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label781
# %bb.148:
	local.get	4
	local.get	10
	i32.add 
	local.get	9
	local.get	2
	memory.copy	0, 0
.LBB36_149:
	end_block                               # label781:
	local.get	6
	local.get	0
	i32.store	0
.LBB36_150:
	end_block                               # label732:
	i32.const	1
	local.set	8
.LBB36_151:
	end_block                               # label731:
	local.get	7
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	8
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.hash_content_xxh32_pair,"",@
	.type	hash_content_xxh32_pair,@function # -- Begin function hash_content_xxh32_pair
hash_content_xxh32_pair:                # @hash_content_xxh32_pair
	.functype	hash_content_xxh32_pair (i32, i32, i32, i32) -> ()
	.local  	i32, i32, v128, v128, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	local.get	0
	local.get	1
	i32.add 
	local.set	4
	block   	
	block   	
	local.get	1
	i32.const	-64
	i32.add 
	i32.const	448
	i32.gt_u
	br_if   	0                               # 0: down to label783
# %bb.1:
	local.get	4
	i32.const	-16
	i32.add 
	local.set	5
	v128.const	-1522540051, 117991484, -2128831035, -488299500
	local.set	6
	v128.const	-1034240543, 606290992, -1640531527, 8
	local.set	7
.LBB37_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label784:
	local.get	0
	v128.load	0:p2align=0
	v128.const	-2048144777, -2048144777, -2048144777, -2048144777
	i32x4.mul
	local.tee	8
	local.get	7
	i32x4.add
	local.tee	7
	i32.const	13
	i32x4.shl
	local.get	7
	i32.const	19
	i32x4.shr_u
	v128.or
	v128.const	-1640531535, -1640531535, -1640531535, -1640531535
	local.tee	9
	i32x4.mul
	local.set	7
	local.get	8
	local.get	6
	i32x4.add
	local.tee	6
	i32.const	13
	i32x4.shl
	local.get	6
	i32.const	19
	i32x4.shr_u
	v128.or
	local.get	9
	i32x4.mul
	local.set	6
	local.get	0
	i32.const	16
	i32.add 
	local.tee	0
	local.get	5
	i32.le_u
	br_if   	0                               # 0: up to label784
# %bb.3:
	end_loop
	local.get	7
	i32x4.extract_lane	0
	i32.const	1
	i32.rotl
	local.get	7
	i32x4.extract_lane	1
	i32.const	7
	i32.rotl
	i32.add 
	local.get	7
	i32x4.extract_lane	2
	i32.const	12
	i32.rotl
	i32.add 
	local.get	7
	i32x4.extract_lane	3
	i32.const	18
	i32.rotl
	i32.add 
	local.set	5
	local.get	6
	i32x4.extract_lane	0
	i32.const	1
	i32.rotl
	local.get	6
	i32x4.extract_lane	1
	i32.const	7
	i32.rotl
	i32.add 
	local.get	6
	i32x4.extract_lane	2
	i32.const	12
	i32.rotl
	i32.add 
	local.get	6
	i32x4.extract_lane	3
	i32.const	18
	i32.rotl
	i32.add 
	local.set	10
	br      	1                               # 1: down to label782
.LBB37_4:
	end_block                               # label783:
	block   	
	local.get	1
	i32.const	16
	i32.ge_u
	br_if   	0                               # 0: down to label785
# %bb.5:
	i32.const	-1754069642
	local.set	10
	i32.const	-1265770134
	local.set	5
	br      	1                               # 1: down to label782
.LBB37_6:
	end_block                               # label785:
	local.get	4
	i32.const	-16
	i32.add 
	local.set	11
	i32.const	-1640531527
	local.set	5
	i32.const	606290992
	local.set	10
	i32.const	-1034240543
	local.set	12
	i32.const	-488299500
	local.set	13
	i32.const	-2128831035
	local.set	14
	i32.const	117991484
	local.set	15
	i32.const	-1522540051
	local.set	16
	i32.const	8
	local.set	17
.LBB37_7:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label786:
	local.get	0
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.tee	18
	local.get	12
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	12
	local.get	18
	local.get	16
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	16
	local.get	0
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.tee	18
	local.get	17
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	17
	local.get	18
	local.get	13
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	13
	local.get	0
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.tee	18
	local.get	5
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	5
	local.get	18
	local.get	14
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	14
	local.get	0
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.tee	18
	local.get	10
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	10
	local.get	18
	local.get	15
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	15
	local.get	0
	i32.const	16
	i32.add 
	local.tee	0
	local.get	11
	i32.le_u
	br_if   	0                               # 0: up to label786
# %bb.8:
	end_loop
	local.get	10
	i32.const	7
	i32.rotl
	local.get	12
	i32.const	1
	i32.rotl
	i32.add 
	local.get	5
	i32.const	12
	i32.rotl
	i32.add 
	local.get	17
	i32.const	18
	i32.rotl
	i32.add 
	local.set	5
	local.get	15
	i32.const	7
	i32.rotl
	local.get	16
	i32.const	1
	i32.rotl
	i32.add 
	local.get	14
	i32.const	12
	i32.rotl
	i32.add 
	local.get	13
	i32.const	18
	i32.rotl
	i32.add 
	local.set	10
.LBB37_9:
	end_block                               # label782:
	local.get	5
	local.get	1
	i32.add 
	local.set	5
	local.get	10
	local.get	1
	i32.add 
	local.set	10
	block   	
	block   	
	local.get	0
	i32.const	4
	i32.add 
	local.get	4
	i32.le_u
	br_if   	0                               # 0: down to label788
# %bb.10:
	local.get	0
	local.set	12
	br      	1                               # 1: down to label787
.LBB37_11:
	end_block                               # label788:
.LBB37_12:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label789:
	local.get	0
	i32.load	0:p2align=0
	i32.const	-1028477379
	i32.mul 
	local.tee	12
	local.get	5
	i32.add 
	i32.const	17
	i32.rotl
	i32.const	668265263
	i32.mul 
	local.set	5
	local.get	12
	local.get	10
	i32.add 
	i32.const	17
	i32.rotl
	i32.const	668265263
	i32.mul 
	local.set	10
	local.get	0
	i32.const	8
	i32.add 
	local.set	13
	local.get	0
	i32.const	4
	i32.add 
	local.tee	12
	local.set	0
	local.get	13
	local.get	4
	i32.le_u
	br_if   	0                               # 0: up to label789
.LBB37_13:
	end_loop
	end_block                               # label787:
	block   	
	local.get	12
	local.get	4
	i32.ge_u
	br_if   	0                               # 0: down to label790
# %bb.14:
	local.get	12
	i32.const	1
	i32.add 
	local.set	0
	block   	
	local.get	4
	local.get	12
	i32.sub 
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label791
# %bb.15:
	local.get	12
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.tee	12
	local.get	5
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	5
	local.get	12
	local.get	10
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	10
	local.get	0
	local.set	12
.LBB37_16:
	end_block                               # label791:
	local.get	4
	local.get	0
	i32.eq  
	br_if   	0                               # 0: down to label790
# %bb.17:
.LBB37_18:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label792:
	local.get	12
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.tee	0
	local.get	12
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.tee	13
	local.get	5
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	5
	local.get	0
	local.get	13
	local.get	10
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	10
	local.get	12
	i32.const	2
	i32.add 
	local.tee	12
	local.get	4
	i32.ne  
	br_if   	0                               # 0: up to label792
.LBB37_19:
	end_loop
	end_block                               # label790:
	local.get	2
	local.get	10
	i32.const	15
	i32.shr_u
	local.get	10
	i32.xor 
	i32.const	-2048144777
	i32.mul 
	local.tee	0
	i32.const	13
	i32.shr_u
	local.get	0
	i32.xor 
	i32.const	-1028477379
	i32.mul 
	local.tee	0
	i32.const	16
	i32.shr_u
	local.get	0
	i32.xor 
	i32.store	0
	local.get	3
	local.get	5
	i32.const	15
	i32.shr_u
	local.get	5
	i32.xor 
	i32.const	-2048144777
	i32.mul 
	local.tee	0
	i32.const	13
	i32.shr_u
	local.get	0
	i32.xor 
	i32.const	-1028477379
	i32.mul 
	local.tee	0
	i32.const	16
	i32.shr_u
	local.get	0
	i32.xor 
	i32.store	0
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_value_span,"",@
	.type	parse_value_span,@function      # -- Begin function parse_value_span
parse_value_span:                       # @parse_value_span
	.functype	parse_value_span (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i64, i32
# %bb.0:
	i32.const	0
	local.set	4
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label793
# %bb.1:
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	5
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label794
# %bb.2:
	local.get	2
	i32.const	1
	i32.add 
	local.tee	5
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label793
# %bb.3:
	local.get	0
	i32.const	5
	i32.add 
	local.set	6
	local.get	0
	i32.const	4
	i32.add 
	local.set	7
	local.get	0
	i32.const	3
	i32.add 
	local.set	8
.LBB38_4:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label795:
	block   	
	local.get	5
	local.tee	2
	i32.const	8
	i32.add 
	local.tee	5
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label796
# %bb.5:                                #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i64.load	0:p2align=0
	local.tee	9
	i64.const	-1
	i64.xor 
	local.get	9
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	9
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	local.get	9
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	9
	i64.eqz
	br_if   	1                               # 1: up to label795
# %bb.6:                                #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	2
	i32.add 
	local.set	2
.LBB38_7:                               #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label796:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label793
# %bb.8:                                #   in Loop: Header=BB38_4 Depth=1
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label799
# %bb.9:                                #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	5
	local.get	1
	i32.ge_u
	br_if   	5                               # 5: down to label793
# %bb.10:                               #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	5
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{2, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 2, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 2, 6, 6, 6, 6, 6, 2, 6, 6, 6, 2, 6, 6, 6, 6, 6, 6, 6, 2, 6, 6, 6, 2, 6, 2, 0, 6} # 6: down to label793
                                        # 2: down to label798
                                        # 0: down to label800
.LBB38_11:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label800:
	local.get	2
	i32.const	6
	i32.add 
	local.tee	5
	local.get	1
	i32.gt_u
	br_if   	5                               # 5: down to label793
# %bb.12:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	i32.const	2
	i32.add 
	local.tee	10
	local.get	5
	i32.ge_u
	br_if   	2                               # 2: down to label797
# %bb.13:                               #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label801
# %bb.14:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label793
.LBB38_15:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label801:
	block   	
	local.get	8
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label802
# %bb.16:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label793
.LBB38_17:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label802:
	block   	
	local.get	7
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label803
# %bb.18:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label793
.LBB38_19:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label803:
	local.get	6
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label797
# %bb.20:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label797
	br      	5                               # 5: down to label793
.LBB38_21:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label799:
	local.get	10
	i32.const	32
	i32.lt_u
	br_if   	4                               # 4: down to label793
# %bb.22:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.set	5
	local.get	10
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label797
# %bb.23:
	local.get	3
	local.get	5
	i32.store	0
	i32.const	1
	return
.LBB38_24:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label798:
	local.get	2
	i32.const	2
	i32.add 
	local.set	5
.LBB38_25:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label797:
	local.get	5
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: up to label795
	br      	2                               # 2: down to label793
.LBB38_26:
	end_loop
	end_block                               # label794:
	block   	
	local.get	5
	i32.const	223
	i32.and 
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label804
# %bb.27:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	i32.const	0
	i32.const	0
	i32.const	0
	i32.const	0
	call	parse_composite_span_impl
	return
.LBB38_28:
	end_block                               # label804:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	call	parse_scalar_span
	local.set	4
.LBB38_29:
	end_block                               # label793:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_scalar_span,"",@
	.type	parse_scalar_span,@function     # -- Begin function parse_scalar_span
parse_scalar_span:                      # @parse_scalar_span
	.functype	parse_scalar_span (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	4
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label805
# %bb.1:
	local.get	2
	local.set	5
.LBB39_2:                               # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label807:
	block   	
	local.get	1
	local.get	5
	local.tee	6
	i32.ne  
	br_if   	0                               # 0: down to label808
# %bb.3:
	local.get	1
	local.set	6
	br      	2                               # 2: down to label806
.LBB39_4:                               #   in Loop: Header=BB39_2 Depth=1
	end_block                               # label808:
	block   	
	block   	
	local.get	0
	local.get	6
	i32.add 
	i32.load8_u	0
	local.tee	7
	i32.const	-10
	i32.add 
	br_table 	{3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0} # 1: down to label809
                                        # 3: down to label806
                                        # 0: down to label810
.LBB39_5:                               #   in Loop: Header=BB39_2 Depth=1
	end_block                               # label810:
	local.get	7
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label806
# %bb.6:                                #   in Loop: Header=BB39_2 Depth=1
	local.get	7
	i32.const	125
	i32.eq  
	br_if   	2                               # 2: down to label806
.LBB39_7:                               #   in Loop: Header=BB39_2 Depth=1
	end_block                               # label809:
	local.get	6
	i32.const	1
	i32.add 
	local.set	5
	local.get	7
	i32.const	9
	i32.ne  
	br_if   	0                               # 0: up to label807
.LBB39_8:
	end_loop
	end_block                               # label806:
	local.get	6
	local.get	2
	i32.eq  
	br_if   	0                               # 0: down to label805
# %bb.9:
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	local.tee	7
	i32.load8_u	0
	i32.const	-102
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 2, 3, 3, 3, 3, 3, 0, 3} # 3: down to label812
                                        # 2: down to label813
                                        # 0: down to label815
.LBB39_10:
	end_block                               # label815:
	local.get	6
	local.get	2
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	4                               # 4: down to label805
# %bb.11:
	local.get	7
	i32.load8_u	0
	i32.const	116
	i32.ne  
	br_if   	4                               # 4: down to label805
# %bb.12:
	local.get	7
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	114
	i32.ne  
	br_if   	4                               # 4: down to label805
# %bb.13:
	local.get	7
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	4                               # 4: down to label805
# %bb.14:
	local.get	7
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	101
	i32.eq  
	br_if   	3                               # 3: down to label811
	br      	4                               # 4: down to label805
.LBB39_15:
	end_block                               # label814:
	local.get	6
	local.get	2
	i32.sub 
	i32.const	5
	i32.ne  
	br_if   	3                               # 3: down to label805
# %bb.16:
	local.get	7
	i32.load8_u	0
	i32.const	102
	i32.ne  
	br_if   	3                               # 3: down to label805
# %bb.17:
	local.get	7
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	97
	i32.ne  
	br_if   	3                               # 3: down to label805
# %bb.18:
	local.get	7
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	3                               # 3: down to label805
# %bb.19:
	local.get	7
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	115
	i32.ne  
	br_if   	3                               # 3: down to label805
# %bb.20:
	local.get	7
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	101
	i32.eq  
	br_if   	2                               # 2: down to label811
	br      	3                               # 3: down to label805
.LBB39_21:
	end_block                               # label813:
	local.get	6
	local.get	2
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	2                               # 2: down to label805
# %bb.22:
	local.get	7
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	2                               # 2: down to label805
# %bb.23:
	local.get	7
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	2                               # 2: down to label805
# %bb.24:
	local.get	7
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	2                               # 2: down to label805
# %bb.25:
	local.get	7
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label811
	br      	2                               # 2: down to label805
.LBB39_26:
	end_block                               # label812:
	local.get	0
	local.get	2
	local.get	6
	call	is_valid_json_number
	i32.eqz
	br_if   	1                               # 1: down to label805
.LBB39_27:
	end_block                               # label811:
	local.get	3
	local.get	6
	i32.store	0
	i32.const	1
	local.set	4
.LBB39_28:
	end_block                               # label805:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_composite_span_impl,"",@
	.type	parse_composite_span_impl,@function # -- Begin function parse_composite_span_impl
parse_composite_span_impl:              # @parse_composite_span_impl
	.functype	parse_composite_span_impl (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	272
	i32.sub 
	local.tee	8
	global.set	__stack_pointer
	i32.const	0
	local.set	9
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label816
# %bb.1:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	0                               # 0: down to label816
# %bb.2:
	i32.const	0
	local.set	9
	local.get	2
	i32.const	1
	i32.add 
	local.tee	11
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label816
# %bb.3:
	local.get	7
	i32.const	0
	i32.ne  
	local.get	10
	i32.const	91
	i32.eq  
	local.tee	2
	i32.and 
	local.set	12
	local.get	0
	i32.const	1
	i32.add 
	local.set	13
	i32.const	0
	i32.const	3
	local.get	2
	i32.select
	local.set	14
	local.get	0
	i32.const	19
	i32.add 
	local.set	15
	local.get	0
	i32.const	17
	i32.add 
	local.set	16
	local.get	0
	i32.const	16
	i32.add 
	local.set	17
	local.get	0
	i32.const	15
	i32.add 
	local.set	18
	local.get	0
	i32.const	14
	i32.add 
	local.set	19
	local.get	0
	i32.const	13
	i32.add 
	local.set	20
	local.get	0
	i32.const	12
	i32.add 
	local.set	21
	local.get	0
	i32.const	11
	i32.add 
	local.set	22
	local.get	0
	i32.const	10
	i32.add 
	local.set	23
	local.get	0
	i32.const	9
	i32.add 
	local.set	24
	local.get	0
	i32.const	8
	i32.add 
	local.set	25
	local.get	0
	i32.const	7
	i32.add 
	local.set	26
	local.get	0
	i32.const	3
	i32.add 
	local.set	27
	local.get	0
	i32.const	2
	i32.add 
	local.set	28
	local.get	0
	i32.const	4
	i32.add 
	local.set	29
	local.get	0
	i32.const	5
	i32.add 
	local.set	30
	i32.const	1
	local.set	31
	i32.const	0
	local.set	32
	i32.const	0
	local.set	33
	i32.const	0
	local.set	34
.LBB40_4:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB40_103 Depth 2
                                        #     Child Loop BB40_342 Depth 2
                                        #     Child Loop BB40_348 Depth 2
	block   	
	loop    	                                # label818:
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	0
	local.get	11
	i32.add 
	local.tee	35
	i32.load8_u	0
	local.tee	2
	i32.const	-9
	i32.add 
	br_table 	{1, 1, 8, 8, 1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 8, 2, 8, 8, 8, 8, 8, 8, 8, 8, 8, 6, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 7, 0} # 1: down to label831
                                        # 8: down to label824
                                        # 2: down to label830
                                        # 6: down to label826
                                        # 7: down to label825
                                        # 0: down to label832
.LBB40_5:                               #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label832:
	local.get	2
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label829
# %bb.6:                                #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	i32.const	125
	i32.ne  
	br_if   	7                               # 7: down to label824
# %bb.7:                                #   in Loop: Header=BB40_4 Depth=1
	i32.const	0
	local.set	9
	local.get	14
	i32.const	255
	i32.and 
	i32.const	-3
	i32.add 
	br_table 	{3, 15, 15, 3, 15}      # 15: down to label816
                                        # 3: down to label828
.LBB40_8:                               #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label831:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label833
# %bb.9:                                #   in Loop: Header=BB40_4 Depth=1
	local.get	5
	i32.load	0
	br_if   	0                               # 0: down to label833
# %bb.10:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB40_11:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label833:
	local.get	11
	i32.const	1
	i32.add 
	local.set	11
	br      	11                              # 11: down to label819
.LBB40_12:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label830:
	local.get	14
	i32.const	251
	i32.and 
	local.tee	36
	i32.const	3
	i32.ne  
	local.tee	37
	br_if   	7                               # 7: down to label822
# %bb.13:                               #   in Loop: Header=BB40_4 Depth=1
	block   	
	block   	
	block   	
	block   	
	local.get	1
	local.get	11
	i32.sub 
	local.tee	2
	i32.const	9
	i32.lt_u
	br_if   	0                               # 0: down to label837
# %bb.14:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i64.load	0:p2align=0
	local.tee	38
	i64.const	8389754706581218082
	i64.eq  
	br_if   	2                               # 2: down to label835
# %bb.15:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	38
	i32.wrap_i64
	local.set	2
	br      	1                               # 1: down to label836
.LBB40_16:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label837:
	local.get	2
	i32.const	5
	i32.lt_u
	br_if   	10                              # 10: down to label822
# %bb.17:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.load	0:p2align=0
	local.set	2
.LBB40_18:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label836:
	local.get	2
	i32.const	1734439970
	i32.ne  
	br_if   	9                               # 9: down to label822
# %bb.19:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label834
	br      	9                               # 9: down to label822
.LBB40_20:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label835:
	local.get	35
	i32.const	8
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	8                               # 8: down to label822
# %bb.21:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	9
	i32.add 
	local.set	7
	i32.const	4
	local.set	2
	br      	7                               # 7: down to label823
.LBB40_22:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label834:
	i32.const	0
	local.set	2
	local.get	11
	i32.const	5
	i32.add 
	local.tee	7
	local.get	1
	i32.ge_u
	br_if   	6                               # 6: down to label823
# %bb.23:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	6                               # 6: down to label823
# %bb.24:                               #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	11
	i32.const	6
	i32.add 
	local.tee	9
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label838
# %bb.25:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	7
	i32.add 
	local.get	9
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.eq  
	i32.select
	local.set	9
.LBB40_26:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label838:
	local.get	1
	local.get	9
	i32.sub 
	local.tee	10
	i32.const	4
	i32.lt_u
	br_if   	6                               # 6: down to label823
# %bb.27:                               #   in Loop: Header=BB40_4 Depth=1
	block   	
	block   	
	local.get	0
	local.get	9
	i32.add 
	local.tee	14
	i32.load	0:p2align=0
	local.tee	11
	i32.const	740450593
	i32.gt_s
	br_if   	0                               # 0: down to label840
# %bb.28:                               #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	11
	i32.const	577334306
	i32.eq  
	br_if   	0                               # 0: down to label841
# %bb.29:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	577533218
	i32.eq  
	br_if   	0                               # 0: down to label841
# %bb.30:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	578056738
	i32.ne  
	br_if   	9                               # 9: down to label823
.LBB40_31:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label841:
	local.get	10
	i32.const	4
	i32.eq  
	br_if   	8                               # 8: down to label823
# %bb.32:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	14
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	8                               # 8: down to label823
# %bb.33:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	5
	i32.add 
	local.set	11
	br      	1                               # 1: down to label839
.LBB40_34:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label840:
	block   	
	block   	
	local.get	11
	i32.const	1651864097
	i32.gt_s
	br_if   	0                               # 0: down to label843
# %bb.35:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	740450594
	i32.eq  
	br_if   	1                               # 1: down to label842
# %bb.36:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	1634759458
	i32.ne  
	br_if   	9                               # 9: down to label823
# %bb.37:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	7
	i32.lt_u
	br_if   	9                               # 9: down to label823
# %bb.38:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	14
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	9                               # 9: down to label823
# %bb.39:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	14
	i32.const	5
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	9                               # 9: down to label823
# %bb.40:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	14
	i32.const	6
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	9                               # 9: down to label823
# %bb.41:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	7
	i32.add 
	local.set	11
	br      	2                               # 2: down to label839
.LBB40_42:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label843:
	block   	
	local.get	11
	i32.const	1651864098
	i32.eq  
	br_if   	0                               # 0: down to label844
# %bb.43:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	1986618402
	i32.ne  
	br_if   	9                               # 9: down to label823
# %bb.44:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	6
	i32.lt_u
	br_if   	9                               # 9: down to label823
# %bb.45:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	14
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	9                               # 9: down to label823
# %bb.46:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	14
	i32.const	5
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	9                               # 9: down to label823
# %bb.47:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	6
	i32.add 
	local.set	11
	br      	2                               # 2: down to label839
.LBB40_48:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label844:
	local.get	10
	i32.const	7
	i32.lt_u
	br_if   	8                               # 8: down to label823
# %bb.49:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	14
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	121
	i32.ne  
	br_if   	8                               # 8: down to label823
# %bb.50:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	14
	i32.const	5
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	8                               # 8: down to label823
# %bb.51:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	14
	i32.const	6
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	8                               # 8: down to label823
# %bb.52:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	7
	i32.add 
	local.set	11
	br      	1                               # 1: down to label839
.LBB40_53:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label842:
	local.get	9
	i32.const	4
	i32.add 
	local.set	11
.LBB40_54:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label839:
	local.get	11
	i32.eqz
	br_if   	6                               # 6: down to label823
# %bb.55:                               #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label845
# %bb.56:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	13
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	0                               # 0: down to label845
# %bb.57:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB40_58:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label845:
	i32.const	0
	local.get	32
	local.get	31
	i32.const	2
	i32.eq  
	i32.select
	local.get	32
	local.get	12
	i32.select
	local.set	32
	i32.const	7
	local.set	14
	local.get	11
	local.get	1
	i32.ge_u
	br_if   	10                              # 10: down to label819
# %bb.59:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	10                              # 10: down to label819
# %bb.60:                               #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label846
# %bb.61:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB40_62:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label846:
	local.get	11
	i32.const	1
	i32.add 
	local.set	11
	br      	10                              # 10: down to label819
.LBB40_63:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label829:
	local.get	14
	i32.const	255
	i32.and 
	i32.const	1
	i32.le_u
	br_if   	1                               # 1: down to label827
	br      	11                              # 11: down to label817
.LBB40_64:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label828:
	local.get	12
	local.get	31
	i32.const	2
	i32.eq  
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label827
# %bb.65:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	33
	local.get	34
	i32.and 
	i32.eqz
	br_if   	11                              # 11: down to label816
.LBB40_66:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label827:
	local.get	11
	i32.const	1
	i32.add 
	local.set	11
	block   	
	local.get	31
	i32.const	-1
	i32.add 
	local.tee	2
	br_if   	0                               # 0: down to label847
# %bb.67:
	local.get	3
	local.get	11
	i32.store	0
	i32.const	1
	local.set	9
	br      	11                              # 11: down to label816
.LBB40_68:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label847:
	local.get	31
	local.get	8
	i32.const	16
	i32.add 
	i32.add 
	i32.const	-2
	i32.add 
	i32.load8_u	0
	local.set	14
	local.get	2
	local.set	31
	br      	7                               # 7: down to label819
.LBB40_69:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label826:
	local.get	14
	i32.const	255
	i32.and 
	local.set	2
	i32.const	2
	local.set	14
	i32.const	0
	local.set	9
	block   	
	block   	
	local.get	2
	i32.const	-1
	i32.add 
	br_table 	{1, 11, 11, 11, 11, 0, 11} # 11: down to label816
                                        # 0: down to label849
.LBB40_70:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label849:
	i32.const	7
	local.set	14
.LBB40_71:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label848:
	block   	
	local.get	11
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label850
# %bb.72:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	local.set	11
	br      	7                               # 7: down to label819
.LBB40_73:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label850:
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.eq  
	br_if   	0                               # 0: down to label851
# %bb.74:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	local.set	11
	br      	7                               # 7: down to label819
.LBB40_75:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label851:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label852
# %bb.76:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB40_77:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label852:
	local.get	11
	i32.const	2
	i32.add 
	local.set	11
	br      	6                               # 6: down to label819
.LBB40_78:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label825:
	local.get	14
	i32.const	255
	i32.and 
	i32.const	4
	i32.ne  
	br_if   	7                               # 7: down to label817
# %bb.79:                               #   in Loop: Header=BB40_4 Depth=1
	i32.const	5
	local.set	14
	block   	
	local.get	11
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label853
# %bb.80:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	local.set	11
	br      	6                               # 6: down to label819
.LBB40_81:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label853:
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.eq  
	br_if   	0                               # 0: down to label854
# %bb.82:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	local.set	11
	br      	6                               # 6: down to label819
.LBB40_83:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label854:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label855
# %bb.84:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB40_85:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label855:
	local.get	11
	i32.const	2
	i32.add 
	local.set	11
	br      	5                               # 5: down to label819
.LBB40_86:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label824:
	block   	
	block   	
	block   	
	local.get	14
	i32.const	253
	i32.and 
	br_if   	0                               # 0: down to label858
# %bb.87:                               #   in Loop: Header=BB40_4 Depth=1
	i32.const	1
	local.set	14
	br      	1                               # 1: down to label857
.LBB40_88:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label858:
	local.get	14
	i32.const	255
	i32.and 
	i32.const	5
	i32.ne  
	br_if   	8                               # 8: down to label817
# %bb.89:                               #   in Loop: Header=BB40_4 Depth=1
	i32.const	6
	local.set	14
	local.get	12
	local.get	31
	i32.const	2
	i32.eq  
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label857
# %bb.90:                               #   in Loop: Header=BB40_4 Depth=1
	i32.const	0
	local.set	7
	block   	
	block   	
	local.get	32
	i32.const	-4
	i32.add 
	br_table 	{0, 1, 1, 1, 3, 1}      # 1: down to label859
                                        # 3: down to label856
.LBB40_91:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label860:
	local.get	2
	i32.const	223
	i32.and 
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label859
# %bb.92:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	34
	i32.const	4
	i32.or  
	local.set	34
	br      	1                               # 1: down to label857
.LBB40_93:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label859:
	local.get	34
	local.get	32
	i32.const	-1
	i32.xor 
	i32.and 
	local.set	34
.LBB40_94:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label857:
	local.get	33
	local.set	7
.LBB40_95:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label856:
	block   	
	local.get	2
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	0                               # 0: down to label861
# %bb.96:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	31
	i32.const	255
	i32.gt_u
	br_if   	7                               # 7: down to label817
# %bb.97:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	31
	local.get	8
	i32.const	16
	i32.add 
	i32.add 
	i32.const	-1
	i32.add 
	local.get	14
	i32.store8	0
	i32.const	0
	local.get	32
	local.get	12
	local.get	31
	i32.const	1
	i32.eq  
	i32.and 
	local.get	2
	i32.const	123
	i32.eq  
	i32.and 
	local.tee	9
	i32.select
	local.set	32
	i32.const	0
	local.get	7
	local.get	9
	i32.select
	local.set	33
	i32.const	0
	local.get	34
	local.get	9
	i32.select
	local.set	34
	i32.const	0
	i32.const	3
	local.get	2
	i32.const	91
	i32.eq  
	i32.select
	local.set	14
	local.get	11
	i32.const	1
	i32.add 
	local.set	11
	local.get	31
	i32.const	1
	i32.add 
	local.set	31
	br      	5                               # 5: down to label819
.LBB40_98:                              #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label861:
	local.get	8
	i32.const	0
	i32.store	12
	local.get	0
	local.get	1
	local.get	11
	local.get	8
	i32.const	12
	i32.add 
	call	parse_scalar_span
	i32.eqz
	br_if   	6                               # 6: down to label817
# %bb.99:                               #   in Loop: Header=BB40_4 Depth=1
	local.get	8
	i32.load	12
	local.set	11
	local.get	7
	local.set	33
	br      	4                               # 4: down to label819
.LBB40_100:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label823:
	local.get	2
	local.get	32
	local.get	31
	i32.const	2
	i32.eq  
	i32.select
	local.get	32
	local.get	12
	i32.select
	local.set	32
	br      	1                               # 1: down to label821
.LBB40_101:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label822:
	i32.const	0
	local.set	9
	local.get	11
	i32.const	1
	i32.add 
	local.tee	39
	local.get	1
	i32.ge_u
	br_if   	5                               # 5: down to label816
# %bb.102:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	39
	local.set	7
.LBB40_103:                             #   Parent Loop BB40_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label862:
	block   	
	local.get	7
	local.tee	2
	i32.const	8
	i32.add 
	local.tee	7
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label863
# %bb.104:                              #   in Loop: Header=BB40_103 Depth=2
	local.get	0
	local.get	2
	i32.add 
	i64.load	0:p2align=0
	local.tee	38
	i64.const	-1
	i64.xor 
	local.get	38
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	38
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	local.get	38
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	38
	i64.eqz
	br_if   	1                               # 1: up to label862
# %bb.105:                              #   in Loop: Header=BB40_103 Depth=2
	local.get	38
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	2
	i32.add 
	local.set	2
.LBB40_106:                             #   in Loop: Header=BB40_103 Depth=2
	end_block                               # label863:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	6                               # 6: down to label816
# %bb.107:                              #   in Loop: Header=BB40_103 Depth=2
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label866
# %bb.108:                              #   in Loop: Header=BB40_103 Depth=2
	local.get	2
	i32.const	1
	i32.add 
	local.tee	7
	local.get	1
	i32.ge_u
	br_if   	9                               # 9: down to label816
# %bb.109:                              #   in Loop: Header=BB40_103 Depth=2
	block   	
	block   	
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 1, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 1, 11, 11, 11, 11, 11, 1, 11, 11, 11, 1, 11, 11, 11, 11, 11, 11, 11, 1, 11, 11, 11, 1, 11, 1, 0, 11} # 11: down to label816
                                        # 1: down to label867
                                        # 0: down to label868
.LBB40_110:                             #   in Loop: Header=BB40_103 Depth=2
	end_block                               # label868:
	local.get	2
	i32.const	6
	i32.add 
	local.tee	7
	local.get	1
	i32.gt_u
	br_if   	10                              # 10: down to label816
# %bb.111:                              #   in Loop: Header=BB40_103 Depth=2
	local.get	2
	i32.const	2
	i32.add 
	local.tee	10
	local.get	7
	i32.ge_u
	br_if   	2                               # 2: down to label865
# %bb.112:                              #   in Loop: Header=BB40_103 Depth=2
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label869
# %bb.113:                              #   in Loop: Header=BB40_103 Depth=2
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	11                              # 11: down to label816
.LBB40_114:                             #   in Loop: Header=BB40_103 Depth=2
	end_block                               # label869:
	block   	
	local.get	27
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label870
# %bb.115:                              #   in Loop: Header=BB40_103 Depth=2
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	11                              # 11: down to label816
.LBB40_116:                             #   in Loop: Header=BB40_103 Depth=2
	end_block                               # label870:
	block   	
	local.get	29
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label871
# %bb.117:                              #   in Loop: Header=BB40_103 Depth=2
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	11                              # 11: down to label816
.LBB40_118:                             #   in Loop: Header=BB40_103 Depth=2
	end_block                               # label871:
	local.get	30
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label865
# %bb.119:                              #   in Loop: Header=BB40_103 Depth=2
	local.get	2
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label865
	br      	10                              # 10: down to label816
.LBB40_120:                             #   in Loop: Header=BB40_103 Depth=2
	end_block                               # label867:
	local.get	2
	i32.const	2
	i32.add 
	local.set	7
	br      	1                               # 1: down to label865
.LBB40_121:                             #   in Loop: Header=BB40_103 Depth=2
	end_block                               # label866:
	local.get	10
	i32.const	32
	i32.lt_u
	br_if   	8                               # 8: down to label816
# %bb.122:                              #   in Loop: Header=BB40_103 Depth=2
	local.get	2
	i32.const	1
	i32.add 
	local.set	7
	local.get	10
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label864
.LBB40_123:                             #   in Loop: Header=BB40_103 Depth=2
	end_block                               # label865:
	local.get	7
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label862
	br      	7                               # 7: down to label816
.LBB40_124:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label864:
	end_loop
	local.get	35
	i32.const	1
	i32.add 
	local.set	10
	block   	
	local.get	4
	i32.eqz
	br_if   	0                               # 0: down to label872
# %bb.125:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.load8_u	0
	local.tee	40
	i32.const	105
	i32.eq  
	local.get	40
	i32.const	92
	i32.eq  
	local.tee	41
	i32.or  
	i32.eqz
	br_if   	0                               # 0: down to label872
# %bb.126:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	local.get	11
	i32.lt_u
	br_if   	0                               # 0: down to label872
# %bb.127:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	4
	i32.load	0
	br_if   	0                               # 0: down to label872
# %bb.128:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	4
	i32.add 
	local.set	42
	block   	
	block   	
	local.get	2
	local.get	11
	i32.eq  
	br_if   	0                               # 0: down to label874
# %bb.129:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	41
	br_if   	0                               # 0: down to label875
# %bb.130:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	local.get	11
	i32.sub 
	local.tee	41
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label874
# %bb.131:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	40
	i32.const	105
	i32.ne  
	br_if   	1                               # 1: down to label874
# %bb.132:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	35
	i32.load8_u	2
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label874
                                        # 0: down to label876
.LBB40_133:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label876:
	local.get	41
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label874
# %bb.134:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	35
	i32.load8_u	3
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label874
                                        # 0: down to label877
.LBB40_135:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label877:
	local.get	42
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label874
# %bb.136:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	42
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label874
	br      	2                               # 2: down to label873
.LBB40_137:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label875:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.6
	i32.const	3
	call	json_string_matches_ascii_escaped
	br_if   	1                               # 1: down to label873
.LBB40_138:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label874:
	local.get	2
	local.get	11
	i32.le_u
	br_if   	1                               # 1: down to label872
# %bb.139:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	block   	
	local.get	40
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label872
                                        # 0: down to label879
.LBB40_140:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label879:
	local.get	11
	i32.const	2
	i32.add 
	local.tee	40
	local.get	2
	i32.gt_u
	br_if   	2                               # 2: down to label872
# %bb.141:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	40
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label872
                                        # 0: down to label880
.LBB40_142:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label880:
	local.get	11
	i32.const	3
	i32.add 
	local.tee	40
	local.get	2
	i32.gt_u
	br_if   	2                               # 2: down to label872
# %bb.143:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	40
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 0, 3}   # 3: down to label872
                                        # 0: down to label881
.LBB40_144:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label881:
	local.get	42
	local.get	2
	i32.gt_u
	br_if   	2                               # 2: down to label872
# %bb.145:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	42
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label872
                                        # 0: down to label882
.LBB40_146:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label882:
	local.get	11
	i32.const	5
	i32.add 
	local.tee	40
	local.get	2
	i32.gt_u
	br_if   	2                               # 2: down to label872
# %bb.147:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	40
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label872
                                        # 0: down to label883
.LBB40_148:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label883:
	local.get	11
	i32.const	6
	i32.add 
	local.tee	40
	local.get	2
	i32.gt_u
	br_if   	2                               # 2: down to label872
# %bb.149:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	40
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label873
	br      	2                               # 2: down to label872
.LBB40_150:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label878:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.4
	i32.const	5
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	1                               # 1: down to label872
.LBB40_151:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label873:
	local.get	4
	i32.const	1
	i32.store	0
.LBB40_152:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label872:
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	37
	br_if   	0                               # 0: down to label888
# %bb.153:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	12
	local.get	31
	i32.const	2
	i32.eq  
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	4                               # 4: down to label884
# %bb.154:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	local.get	11
	i32.lt_u
	br_if   	3                               # 3: down to label885
# %bb.155:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	3                               # 3: down to label885
# %bb.156:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	5
	i32.add 
	local.set	14
	local.get	2
	local.get	11
	i32.eq  
	br_if   	2                               # 2: down to label886
# %bb.157:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	block   	
	local.get	13
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	9
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label890
# %bb.158:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	116
	i32.ne  
	br_if   	4                               # 4: down to label886
# %bb.159:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	local.get	11
	i32.sub 
	local.tee	9
	i32.const	1
	i32.eq  
	br_if   	4                               # 4: down to label886
# %bb.160:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	28
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label890
# %bb.161:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	32
	i32.const	121
	i32.ne  
	br_if   	4                               # 4: down to label886
# %bb.162:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	2
	i32.eq  
	br_if   	4                               # 4: down to label886
# %bb.163:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	27
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label890
# %bb.164:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	32
	i32.const	112
	i32.ne  
	br_if   	4                               # 4: down to label886
# %bb.165:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	3
	i32.eq  
	br_if   	4                               # 4: down to label886
# %bb.166:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	29
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{0, 4, 4, 4, 4, 4, 4, 4, 4, 1, 4} # 4: down to label886
                                        # 1: down to label889
.LBB40_167:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label890:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	3                               # 3: down to label886
# %bb.168:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	8
	local.set	32
	br      	5                               # 5: down to label884
.LBB40_169:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label889:
	local.get	14
	local.get	2
	i32.le_u
	br_if   	1                               # 1: down to label887
	br      	2                               # 2: down to label886
.LBB40_170:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label888:
	block   	
	block   	
	block   	
	local.get	14
	i32.const	255
	i32.and 
	i32.const	5
	i32.ne  
	br_if   	0                               # 0: down to label893
# %bb.171:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	6
	local.set	9
	i32.const	7
	local.set	14
	local.get	12
	local.get	31
	i32.const	2
	i32.eq  
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	8                               # 8: down to label820
# %bb.172:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	32
	i32.const	8
	i32.ne  
	br_if   	0                               # 0: down to label894
# %bb.173:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	8
	local.set	32
	i32.const	0
	local.set	33
	local.get	2
	local.get	11
	i32.lt_u
	br_if   	9                               # 9: down to label820
# %bb.174:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	9                               # 9: down to label820
# %bb.175:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	local.get	11
	i32.sub 
	local.set	10
	local.get	11
	i32.const	4
	i32.add 
	local.set	35
	local.get	11
	i32.const	5
	i32.add 
	local.set	37
	block   	
	local.get	2
	local.get	11
	i32.eq  
	br_if   	0                               # 0: down to label895
# %bb.176:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	39
	i32.add 
	i32.load8_u	0
	local.tee	33
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label896
# %bb.177:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	33
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label895
# %bb.178:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label895
# %bb.179:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	28
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label895
                                        # 0: down to label897
.LBB40_180:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label897:
	local.get	10
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label895
# %bb.181:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	27
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	33
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label896
# %bb.182:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	33
	i32.const	120
	i32.ne  
	br_if   	1                               # 1: down to label895
# %bb.183:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label895
# %bb.184:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	35
	i32.add 
	i32.load8_u	0
	local.tee	33
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label896
# %bb.185:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	33
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label895
# %bb.186:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	local.get	2
	i32.ge_u
	br_if   	1                               # 1: down to label895
# %bb.187:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	37
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label895
# %bb.188:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	1
	local.set	33
	br      	11                              # 11: down to label820
.LBB40_189:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label896:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	0                               # 0: down to label895
# %bb.190:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	1
	local.set	33
	br      	10                              # 10: down to label820
.LBB40_191:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label895:
	i32.const	0
	local.set	33
	i32.const	6
	local.set	9
	local.get	2
	local.get	11
	i32.le_u
	br_if   	9                               # 9: down to label820
# %bb.192:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	0
	local.get	10
	local.get	10
	local.get	2
	i32.gt_u
	i32.select
	local.set	10
	local.get	11
	i32.const	6
	i32.add 
	local.set	41
	block   	
	block   	
	local.get	0
	local.get	39
	i32.add 
	local.tee	39
	i32.load8_u	0
	local.tee	40
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label899
# %bb.193:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	40
	i32.const	105
	i32.ne  
	br_if   	5                               # 5: down to label891
# %bb.194:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	1
	i32.eq  
	br_if   	5                               # 5: down to label891
# %bb.195:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	28
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 6} # 6: down to label891
                                        # 0: down to label900
.LBB40_196:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label900:
	local.get	10
	i32.const	2
	i32.eq  
	br_if   	5                               # 5: down to label891
# %bb.197:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	27
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 6, 6, 6, 6, 0, 6}   # 6: down to label891
                                        # 0: down to label901
.LBB40_198:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label901:
	local.get	10
	i32.const	3
	i32.eq  
	br_if   	5                               # 5: down to label891
# %bb.199:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	35
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 6} # 6: down to label891
                                        # 0: down to label902
.LBB40_200:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label902:
	local.get	10
	i32.const	4
	i32.eq  
	br_if   	5                               # 5: down to label891
# %bb.201:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	37
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{0, 5, 5, 5, 5, 5, 5, 5, 5, 1, 5} # 5: down to label891
                                        # 1: down to label898
.LBB40_202:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label899:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.4
	i32.const	5
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	4                               # 4: down to label891
# %bb.203:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	2
	local.set	33
	br      	10                              # 10: down to label820
.LBB40_204:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label898:
	local.get	37
	local.get	2
	i32.lt_u
	br_if   	2                               # 2: down to label892
	br      	3                               # 3: down to label891
.LBB40_205:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label894:
	local.get	32
	local.get	34
	i32.or  
	local.set	34
	br      	8                               # 8: down to label820
.LBB40_206:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label893:
	local.get	14
	i32.const	253
	i32.and 
	br_if   	11                              # 11: down to label816
# %bb.207:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	1
	local.set	9
	i32.const	2
	local.set	14
	br      	7                               # 7: down to label820
.LBB40_208:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label892:
	local.get	0
	local.get	41
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label891
# %bb.209:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	2
	local.set	33
	br      	6                               # 6: down to label820
.LBB40_210:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label891:
	i32.const	1
	local.set	40
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	39
	i32.load8_u	0
	local.tee	39
	i32.const	115
	i32.eq  
	br_if   	0                               # 0: down to label907
# %bb.211:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	39
	i32.const	92
	i32.ne  
	br_if   	2                               # 2: down to label905
	br      	1                               # 1: down to label906
.LBB40_212:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label907:
	local.get	10
	i32.const	1
	i32.eq  
	br_if   	9                               # 9: down to label820
# %bb.213:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	28
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	39
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label906
# %bb.214:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	39
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label905
# %bb.215:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	2
	i32.eq  
	br_if   	9                               # 9: down to label820
# %bb.216:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	27
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	39
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label906
# %bb.217:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	39
	i32.const	114
	i32.ne  
	br_if   	1                               # 1: down to label905
# %bb.218:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	3
	i32.eq  
	br_if   	9                               # 9: down to label820
# %bb.219:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	35
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label906
# %bb.220:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.const	117
	i32.ne  
	br_if   	1                               # 1: down to label905
# %bb.221:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	4
	i32.eq  
	br_if   	9                               # 9: down to label820
# %bb.222:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	37
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label905
                                        # 0: down to label908
.LBB40_223:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label908:
	local.get	10
	i32.const	5
	i32.eq  
	br_if   	9                               # 9: down to label820
# %bb.224:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	41
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label906
# %bb.225:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label905
# %bb.226:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	10
	i32.const	6
	i32.ne  
	br_if   	0                               # 0: down to label909
# %bb.227:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	6
	local.set	9
	br      	10                              # 10: down to label820
.LBB40_228:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label909:
	local.get	26
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label906
# %bb.229:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.const	117
	i32.ne  
	br_if   	1                               # 1: down to label905
# %bb.230:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	7
	i32.eq  
	br_if   	3                               # 3: down to label903
# %bb.231:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	25
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label906
# %bb.232:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.const	114
	i32.ne  
	br_if   	1                               # 1: down to label905
# %bb.233:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	8
	i32.eq  
	br_if   	2                               # 2: down to label904
# %bb.234:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	24
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label905
                                        # 0: down to label910
.LBB40_235:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label910:
	local.get	10
	i32.const	9
	i32.eq  
	br_if   	2                               # 2: down to label904
# %bb.236:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	23
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label905
                                        # 0: down to label911
.LBB40_237:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label911:
	local.get	10
	i32.const	10
	i32.eq  
	br_if   	2                               # 2: down to label904
# %bb.238:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	22
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label906
# %bb.239:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.const	45
	i32.ne  
	br_if   	1                               # 1: down to label905
# %bb.240:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	11
	i32.eq  
	br_if   	2                               # 2: down to label904
# %bb.241:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	21
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label905
                                        # 0: down to label912
.LBB40_242:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label912:
	local.get	10
	i32.const	12
	i32.eq  
	br_if   	2                               # 2: down to label904
# %bb.243:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	20
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label905
                                        # 0: down to label913
.LBB40_244:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label913:
	local.get	10
	i32.const	13
	i32.eq  
	br_if   	2                               # 2: down to label904
# %bb.245:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	19
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label905
                                        # 0: down to label914
.LBB40_246:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label914:
	local.get	10
	i32.const	14
	i32.eq  
	br_if   	2                               # 2: down to label904
# %bb.247:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	18
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label906
# %bb.248:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label905
# %bb.249:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	15
	i32.eq  
	br_if   	2                               # 2: down to label904
# %bb.250:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	17
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label905
                                        # 0: down to label915
.LBB40_251:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label915:
	local.get	10
	i32.const	16
	i32.eq  
	br_if   	2                               # 2: down to label904
# %bb.252:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	16
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label905
                                        # 0: down to label916
.LBB40_253:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label916:
	local.get	10
	i32.const	17
	i32.eq  
	br_if   	2                               # 2: down to label904
# %bb.254:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	11
	i32.const	18
	i32.add 
	local.tee	10
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label906
# %bb.255:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label905
# %bb.256:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	local.get	2
	i32.ge_u
	br_if   	2                               # 2: down to label904
# %bb.257:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	15
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	local.set	40
	br      	1                               # 1: down to label905
.LBB40_258:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label906:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.5
	i32.const	18
	call	json_string_matches_ascii_escaped
	i32.eqz
	local.set	40
.LBB40_259:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label905:
	i32.const	0
	i32.const	4
	local.get	40
	i32.const	1
	i32.and 
	i32.select
	local.set	33
	br      	7                               # 7: down to label820
.LBB40_260:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label904:
	i32.const	8
	local.set	32
.LBB40_261:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label903:
	i32.const	7
	local.set	14
	i32.const	6
	local.set	9
	br      	5                               # 5: down to label820
.LBB40_262:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label887:
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label886
# %bb.263:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	8
	local.set	32
	br      	2                               # 2: down to label884
.LBB40_264:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label886:
	block   	
	local.get	2
	local.get	11
	i32.gt_u
	local.tee	9
	i32.eqz
	br_if   	0                               # 0: down to label917
# %bb.265:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	13
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label918
# %bb.266:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	32
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label917
# %bb.267:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	2
	i32.add 
	local.tee	32
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label917
# %bb.268:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label917
                                        # 0: down to label919
.LBB40_269:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label919:
	local.get	11
	i32.const	3
	i32.add 
	local.tee	32
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label917
# %bb.270:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label918
# %bb.271:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	32
	i32.const	120
	i32.ne  
	br_if   	1                               # 1: down to label917
# %bb.272:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	4
	i32.add 
	local.tee	32
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label917
# %bb.273:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label918
# %bb.274:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	32
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label917
# %bb.275:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	14
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label917
# %bb.276:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label917
# %bb.277:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	1
	local.set	32
	br      	3                               # 3: down to label884
.LBB40_278:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label918:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	0                               # 0: down to label917
# %bb.279:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	1
	local.set	32
	br      	2                               # 2: down to label884
.LBB40_280:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label917:
	block   	
	local.get	9
	i32.eqz
	br_if   	0                               # 0: down to label920
# %bb.281:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	13
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label921
# %bb.282:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	32
	i32.const	112
	i32.ne  
	br_if   	1                               # 1: down to label920
# %bb.283:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	2
	i32.add 
	local.tee	32
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label920
# %bb.284:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 0, 2}   # 2: down to label920
                                        # 0: down to label922
.LBB40_285:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label922:
	local.get	11
	i32.const	3
	i32.add 
	local.tee	32
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label920
# %bb.286:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label921
# %bb.287:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	32
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label920
# %bb.288:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	4
	i32.add 
	local.tee	32
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label920
# %bb.289:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label920
                                        # 0: down to label923
.LBB40_290:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label923:
	local.get	14
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label920
# %bb.291:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label920
# %bb.292:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	2
	local.set	32
	br      	3                               # 3: down to label884
.LBB40_293:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label921:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.2
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	0                               # 0: down to label920
# %bb.294:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	2
	local.set	32
	br      	2                               # 2: down to label884
.LBB40_295:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label920:
	local.get	9
	i32.eqz
	br_if   	0                               # 0: down to label885
# %bb.296:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	block   	
	local.get	13
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label885
                                        # 0: down to label925
.LBB40_297:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label925:
	local.get	11
	i32.const	2
	i32.add 
	local.tee	9
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label885
# %bb.298:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label885
                                        # 0: down to label926
.LBB40_299:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label926:
	local.get	11
	i32.const	3
	i32.add 
	local.tee	9
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label885
# %bb.300:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label885
                                        # 0: down to label927
.LBB40_301:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label927:
	local.get	11
	i32.const	4
	i32.add 
	local.tee	9
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label885
# %bb.302:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.tee	9
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label924
# %bb.303:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label885
# %bb.304:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	14
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label885
# %bb.305:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label885
                                        # 0: down to label928
.LBB40_306:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label928:
	local.get	11
	i32.const	6
	i32.add 
	local.tee	9
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label885
# %bb.307:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label885
                                        # 0: down to label929
.LBB40_308:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label929:
	local.get	11
	i32.const	7
	i32.add 
	local.tee	9
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label885
# %bb.309:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.tee	9
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label924
# %bb.310:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label885
# %bb.311:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	8
	i32.add 
	local.tee	9
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label885
# %bb.312:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label885
# %bb.313:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	4
	local.set	32
	br      	2                               # 2: down to label884
.LBB40_314:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label924:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.3
	i32.const	7
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	0                               # 0: down to label885
# %bb.315:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	4
	local.set	32
	br      	1                               # 1: down to label884
.LBB40_316:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label885:
	i32.const	0
	local.set	32
.LBB40_317:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label884:
	block   	
	local.get	10
	i32.load8_u	0
	local.tee	9
	i32.const	116
	i32.eq  
	br_if   	0                               # 0: down to label930
# %bb.318:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	92
	i32.ne  
	br_if   	1                               # 1: down to label821
.LBB40_319:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label930:
	block   	
	block   	
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label933
# %bb.320:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	5
	i32.load	0
	i32.eqz
	br_if   	1                               # 1: down to label932
.LBB40_321:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label933:
	local.get	6
	i32.eqz
	br_if   	2                               # 2: down to label821
# %bb.322:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	6
	i32.load	0
	br_if   	2                               # 2: down to label821
# %bb.323:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	local.get	11
	i32.ge_u
	br_if   	1                               # 1: down to label931
	br      	2                               # 2: down to label821
.LBB40_324:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label932:
	local.get	2
	local.get	11
	i32.lt_u
	br_if   	1                               # 1: down to label821
.LBB40_325:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label931:
	local.get	35
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label821
# %bb.326:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	local.get	11
	i32.eq  
	br_if   	0                               # 0: down to label821
# %bb.327:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	block   	
	local.get	9
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label935
# %bb.328:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	local.get	11
	i32.sub 
	local.tee	10
	i32.const	1
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.329:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label821
# %bb.330:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.load8_u	2
	local.tee	9
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label935
# %bb.331:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	121
	i32.ne  
	br_if   	2                               # 2: down to label821
# %bb.332:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	2
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.333:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	35
	i32.load8_u	3
	local.tee	9
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label935
# %bb.334:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	112
	i32.ne  
	br_if   	2                               # 2: down to label821
# %bb.335:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	3
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.336:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	35
	i32.load8_u	4
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label821
                                        # 0: down to label936
.LBB40_337:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label936:
	local.get	11
	i32.const	5
	i32.add 
	local.tee	11
	local.get	2
	i32.gt_u
	br_if   	2                               # 2: down to label821
# %bb.338:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label934
	br      	2                               # 2: down to label821
.LBB40_339:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label935:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	1                               # 1: down to label821
.LBB40_340:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label934:
	local.get	7
	local.set	2
	block   	
	local.get	7
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label937
# %bb.341:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	7
	local.set	2
.LBB40_342:                             #   Parent Loop BB40_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label938:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	11
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label937
# %bb.343:                              #   in Loop: Header=BB40_342 Depth=2
	i32.const	1
	local.get	11
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label937
# %bb.344:                              #   in Loop: Header=BB40_342 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label938
	br      	2                               # 2: down to label821
.LBB40_345:                             #   in Loop: Header=BB40_4 Depth=1
	end_loop
	end_block                               # label937:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label821
# %bb.346:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	0                               # 0: down to label821
# %bb.347:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label939
.LBB40_348:                             #   Parent Loop BB40_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label940:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	11
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label939
# %bb.349:                              #   in Loop: Header=BB40_348 Depth=2
	i32.const	1
	local.get	11
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label939
# %bb.350:                              #   in Loop: Header=BB40_348 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label940
	br      	2                               # 2: down to label821
.LBB40_351:                             #   in Loop: Header=BB40_4 Depth=1
	end_loop
	end_block                               # label939:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label821
# %bb.352:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	2
	i32.add 
	local.tee	11
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label821
# %bb.353:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	1
	local.get	2
	i32.const	-1
	i32.xor 
	i32.add 
	local.tee	9
	i32.eqz
	br_if   	0                               # 0: down to label821
# %bb.354:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	block   	
	local.get	11
	i32.load8_u	1
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label942
# %bb.355:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	1
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.356:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label821
# %bb.357:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	11
	i32.load8_u	2
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label821
                                        # 0: down to label943
.LBB40_358:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label943:
	local.get	9
	i32.const	2
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.359:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.load8_u	3
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label942
# %bb.360:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	10
	i32.const	120
	i32.ne  
	br_if   	2                               # 2: down to label821
# %bb.361:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	9
	i32.const	3
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.362:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.load8_u	4
	local.tee	11
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label942
# %bb.363:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	11
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label821
# %bb.364:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	2
	i32.const	5
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label821
# %bb.365:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label941
	br      	2                               # 2: down to label821
.LBB40_366:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label942:
	local.get	0
	local.get	2
	local.get	1
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	1                               # 1: down to label821
.LBB40_367:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label941:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label944
# %bb.368:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB40_369:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label944:
	local.get	6
	i32.eqz
	br_if   	0                               # 0: down to label821
# %bb.370:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	6
	i32.const	1
	i32.store	0
.LBB40_371:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label821:
	i32.const	4
	local.set	9
	i32.const	2
	local.set	14
	local.get	7
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label820
# %bb.372:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	0                               # 0: down to label820
# %bb.373:                              #   in Loop: Header=BB40_4 Depth=1
	i32.const	5
	local.set	14
	local.get	7
	i32.const	1
	i32.add 
	local.tee	11
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label819
# %bb.374:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	1                               # 1: down to label819
# %bb.375:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label945
# %bb.376:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB40_377:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label945:
	local.get	7
	i32.const	2
	i32.add 
	local.set	11
	br      	1                               # 1: down to label819
.LBB40_378:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label820:
	block   	
	local.get	36
	i32.const	3
	i32.eq  
	br_if   	0                               # 0: down to label946
# %bb.379:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	7
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label946
# %bb.380:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	0                               # 0: down to label946
# %bb.381:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	7
	i32.const	1
	i32.add 
	local.tee	11
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label819
# %bb.382:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	1                               # 1: down to label819
# %bb.383:                              #   in Loop: Header=BB40_4 Depth=1
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label947
# %bb.384:                              #   in Loop: Header=BB40_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB40_385:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label947:
	local.get	7
	i32.const	2
	i32.add 
	local.set	11
	br      	1                               # 1: down to label819
.LBB40_386:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label946:
	local.get	9
	local.set	14
	local.get	7
	local.set	11
.LBB40_387:                             #   in Loop: Header=BB40_4 Depth=1
	end_block                               # label819:
	local.get	11
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: up to label818
.LBB40_388:
	end_loop
	end_block                               # label817:
	i32.const	0
	local.set	9
.LBB40_389:
	end_block                               # label816:
	local.get	8
	i32.const	272
	i32.add 
	global.set	__stack_pointer
	local.get	9
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.json_string_matches_ascii_escaped,"",@
	.type	json_string_matches_ascii_escaped,@function # -- Begin function json_string_matches_ascii_escaped
json_string_matches_ascii_escaped:      # @json_string_matches_ascii_escaped
	.functype	json_string_matches_ascii_escaped (i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	5
	block   	
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label948
# %bb.1:
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label948
# %bb.2:
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label948
# %bb.3:
	i32.const	0
	local.set	6
.LBB41_4:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label949:
	local.get	1
	i32.const	1
	i32.add 
	local.set	7
	block   	
	block   	
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label951
# %bb.5:                                #   in Loop: Header=BB41_4 Depth=1
	local.get	7
	local.set	1
	br      	1                               # 1: down to label950
.LBB41_6:                               #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label951:
	i32.const	0
	local.set	5
	local.get	2
	local.get	7
	i32.sub 
	i32.const	5
	i32.lt_u
	br_if   	2                               # 2: down to label948
# %bb.7:                                #   in Loop: Header=BB41_4 Depth=1
	local.get	0
	local.get	7
	i32.add 
	local.tee	7
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	2                               # 2: down to label948
# %bb.8:                                #   in Loop: Header=BB41_4 Depth=1
	i32.const	-48
	local.set	9
	i32.const	-48
	local.set	10
	block   	
	block   	
	local.get	7
	i32.load8_u	1
	local.tee	8
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label953
# %bb.9:                                #   in Loop: Header=BB41_4 Depth=1
	block   	
	local.get	8
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label954
# %bb.10:                               #   in Loop: Header=BB41_4 Depth=1
	i32.const	-87
	local.set	10
	br      	1                               # 1: down to label953
.LBB41_11:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label954:
	block   	
	local.get	8
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label955
# %bb.12:                               #   in Loop: Header=BB41_4 Depth=1
	i32.const	-1
	local.set	8
	br      	2                               # 2: down to label952
.LBB41_13:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label955:
	i32.const	-55
	local.set	10
.LBB41_14:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label953:
	block   	
	local.get	7
	i32.load8_u	2
	local.tee	5
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label956
# %bb.15:                               #   in Loop: Header=BB41_4 Depth=1
	block   	
	local.get	5
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label957
# %bb.16:                               #   in Loop: Header=BB41_4 Depth=1
	i32.const	-87
	local.set	9
	br      	1                               # 1: down to label956
.LBB41_17:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label957:
	block   	
	local.get	5
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label958
# %bb.18:                               #   in Loop: Header=BB41_4 Depth=1
	i32.const	-1
	local.set	8
	br      	2                               # 2: down to label952
.LBB41_19:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label958:
	i32.const	-55
	local.set	9
.LBB41_20:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label956:
	i32.const	-48
	local.set	11
	i32.const	-48
	local.set	12
	block   	
	local.get	7
	i32.load8_u	3
	local.tee	13
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label959
# %bb.21:                               #   in Loop: Header=BB41_4 Depth=1
	block   	
	local.get	13
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label960
# %bb.22:                               #   in Loop: Header=BB41_4 Depth=1
	i32.const	-87
	local.set	12
	br      	1                               # 1: down to label959
.LBB41_23:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label960:
	block   	
	local.get	13
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label961
# %bb.24:                               #   in Loop: Header=BB41_4 Depth=1
	i32.const	-1
	local.set	8
	br      	2                               # 2: down to label952
.LBB41_25:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label961:
	i32.const	-55
	local.set	12
.LBB41_26:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label959:
	block   	
	local.get	7
	i32.load8_u	4
	local.tee	7
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label962
# %bb.27:                               #   in Loop: Header=BB41_4 Depth=1
	block   	
	local.get	7
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label963
# %bb.28:                               #   in Loop: Header=BB41_4 Depth=1
	i32.const	-87
	local.set	11
	br      	1                               # 1: down to label962
.LBB41_29:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label963:
	block   	
	local.get	7
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label964
# %bb.30:                               #   in Loop: Header=BB41_4 Depth=1
	i32.const	-1
	local.set	8
	br      	2                               # 2: down to label952
.LBB41_31:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label964:
	i32.const	-55
	local.set	11
.LBB41_32:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label962:
	local.get	11
	local.get	7
	i32.add 
	local.get	9
	local.get	5
	i32.add 
	i32.const	4
	i32.shl 
	local.get	10
	local.get	8
	i32.add 
	i32.const	8
	i32.shl 
	i32.or  
	local.get	12
	local.get	13
	i32.add 
	i32.or  
	i32.const	4
	i32.shl 
	i32.or  
	local.set	8
.LBB41_33:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label952:
	local.get	1
	i32.const	6
	i32.add 
	local.set	1
.LBB41_34:                              #   in Loop: Header=BB41_4 Depth=1
	end_block                               # label950:
	i32.const	0
	local.set	5
	local.get	8
	local.get	3
	local.get	6
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	1                               # 1: down to label948
# %bb.35:                               #   in Loop: Header=BB41_4 Depth=1
	block   	
	local.get	6
	i32.const	1
	i32.add 
	local.tee	6
	local.get	4
	i32.ge_u
	br_if   	0                               # 0: down to label965
# %bb.36:                               #   in Loop: Header=BB41_4 Depth=1
	local.get	1
	local.get	2
	i32.lt_u
	br_if   	1                               # 1: up to label949
.LBB41_37:
	end_block                               # label965:
	end_loop
	local.get	6
	local.get	4
	i32.lt_u
	br_if   	0                               # 0: down to label948
# %bb.38:
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label948
# %bb.39:
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	5
.LBB41_40:
	end_block                               # label948:
	local.get	5
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.key_hex4,"",@
	.type	key_hex4,@function              # -- Begin function key_hex4
key_hex4:                               # @key_hex4
	.functype	key_hex4 (i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-48
	local.set	1
	i32.const	-48
	local.set	2
	block   	
	local.get	0
	i32.load8_u	0
	local.tee	3
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label966
# %bb.1:
	block   	
	local.get	3
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label967
# %bb.2:
	i32.const	-87
	local.set	2
	br      	1                               # 1: down to label966
.LBB42_3:
	end_block                               # label967:
	block   	
	local.get	3
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label968
# %bb.4:
	i32.const	-1
	return
.LBB42_5:
	end_block                               # label968:
	i32.const	-55
	local.set	2
.LBB42_6:
	end_block                               # label966:
	block   	
	local.get	0
	i32.load8_u	1
	local.tee	4
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label969
# %bb.7:
	block   	
	local.get	4
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label970
# %bb.8:
	i32.const	-87
	local.set	1
	br      	1                               # 1: down to label969
.LBB42_9:
	end_block                               # label970:
	block   	
	local.get	4
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label971
# %bb.10:
	i32.const	-1
	return
.LBB42_11:
	end_block                               # label971:
	i32.const	-55
	local.set	1
.LBB42_12:
	end_block                               # label969:
	i32.const	-48
	local.set	5
	i32.const	-48
	local.set	6
	block   	
	local.get	0
	i32.load8_u	2
	local.tee	7
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label972
# %bb.13:
	block   	
	local.get	7
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label973
# %bb.14:
	i32.const	-87
	local.set	6
	br      	1                               # 1: down to label972
.LBB42_15:
	end_block                               # label973:
	block   	
	local.get	7
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label974
# %bb.16:
	i32.const	-1
	return
.LBB42_17:
	end_block                               # label974:
	i32.const	-55
	local.set	6
.LBB42_18:
	end_block                               # label972:
	block   	
	local.get	0
	i32.load8_u	3
	local.tee	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label975
# %bb.19:
	block   	
	local.get	0
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label976
# %bb.20:
	i32.const	-87
	local.set	5
	br      	1                               # 1: down to label975
.LBB42_21:
	end_block                               # label976:
	block   	
	local.get	0
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label977
# %bb.22:
	i32.const	-1
	return
.LBB42_23:
	end_block                               # label977:
	i32.const	-55
	local.set	5
.LBB42_24:
	end_block                               # label975:
	local.get	5
	local.get	0
	i32.add 
	local.get	6
	local.get	7
	i32.add 
	local.get	2
	local.get	3
	i32.add 
	i32.const	8
	i32.shl 
	local.get	1
	local.get	4
	i32.add 
	i32.const	4
	i32.shl 
	i32.or  
	i32.or  
	i32.const	4
	i32.shl 
	i32.or  
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.is_valid_json_number,"",@
	.type	is_valid_json_number,@function  # -- Begin function is_valid_json_number
is_valid_json_number:                   # @is_valid_json_number
	.functype	is_valid_json_number (i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32
# %bb.0:
	block   	
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label978
# %bb.1:
	local.get	1
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	45
	i32.eq  
	i32.add 
	local.set	1
.LBB43_2:
	end_block                               # label978:
	i32.const	0
	local.set	3
	block   	
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label979
# %bb.3:
	block   	
	block   	
	block   	
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	4
	i32.const	48
	i32.ne  
	br_if   	0                               # 0: down to label982
# %bb.4:
	local.get	1
	i32.const	1
	i32.add 
	local.tee	4
	local.get	2
	i32.ge_u
	br_if   	1                               # 1: down to label981
# %bb.5:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.ge_u
	br_if   	1                               # 1: down to label981
	br      	3                               # 3: down to label979
.LBB43_6:
	end_block                               # label982:
	local.get	4
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	247
	i32.lt_u
	br_if   	2                               # 2: down to label979
# %bb.7:
	local.get	0
	i32.const	1
	i32.add 
	local.set	5
	local.get	2
	i32.const	-1
	i32.add 
	local.set	6
.LBB43_8:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label983:
	block   	
	local.get	6
	local.get	1
	i32.ne  
	br_if   	0                               # 0: down to label984
# %bb.9:
	local.get	2
	local.set	4
	br      	3                               # 3: down to label980
.LBB43_10:                              #   in Loop: Header=BB43_8 Depth=1
	end_block                               # label984:
	local.get	5
	local.get	1
	i32.add 
	local.set	7
	local.get	1
	i32.const	1
	i32.add 
	local.tee	4
	local.set	1
	local.get	7
	i32.load8_u	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: up to label983
.LBB43_11:
	end_loop
	end_block                               # label981:
	block   	
	local.get	4
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label985
# %bb.12:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	46
	i32.ne  
	br_if   	0                               # 0: down to label985
# %bb.13:
	local.get	4
	i32.const	1
	i32.add 
	local.tee	1
	local.get	2
	i32.ge_u
	br_if   	2                               # 2: down to label979
# %bb.14:
	local.get	1
	local.set	4
.LBB43_15:                              # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label987:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	9
	i32.gt_u
	br_if   	1                               # 1: down to label986
# %bb.16:                               #   in Loop: Header=BB43_15 Depth=1
	local.get	2
	local.get	4
	i32.const	1
	i32.add 
	local.tee	4
	i32.ne  
	br_if   	0                               # 0: up to label987
# %bb.17:
	end_loop
	local.get	2
	local.set	4
.LBB43_18:
	end_block                               # label986:
	local.get	4
	local.get	1
	i32.eq  
	br_if   	2                               # 2: down to label979
.LBB43_19:
	end_block                               # label985:
	local.get	4
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label980
# %bb.20:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.or  
	i32.const	101
	i32.ne  
	br_if   	0                               # 0: down to label980
# %bb.21:
	block   	
	local.get	4
	i32.const	1
	i32.add 
	local.tee	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label988
# %bb.22:
	block   	
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-43
	i32.add 
	br_table 	{0, 1, 0, 1}            # 1: down to label988
                                        # 0: down to label989
.LBB43_23:
	end_block                               # label989:
	local.get	4
	i32.const	2
	i32.add 
	local.set	1
.LBB43_24:
	end_block                               # label988:
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	1                               # 1: down to label979
# %bb.25:
	local.get	1
	local.set	4
.LBB43_26:                              # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label991:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	9
	i32.gt_u
	br_if   	1                               # 1: down to label990
# %bb.27:                               #   in Loop: Header=BB43_26 Depth=1
	local.get	2
	local.get	4
	i32.const	1
	i32.add 
	local.tee	4
	i32.ne  
	br_if   	0                               # 0: up to label991
# %bb.28:
	end_loop
	local.get	2
	local.set	4
.LBB43_29:
	end_block                               # label990:
	local.get	4
	local.get	1
	i32.eq  
	br_if   	1                               # 1: down to label979
.LBB43_30:
	end_block                               # label980:
	local.get	4
	local.get	2
	i32.eq  
	local.set	3
.LBB43_31:
	end_block                               # label979:
	local.get	3
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.reuse_validated_glossary,"",@
	.type	reuse_validated_glossary,@function # -- Begin function reuse_validated_glossary
reuse_validated_glossary:               # @reuse_validated_glossary
	.functype	reuse_validated_glossary (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, v128, v128
# %bb.0:
	i32.const	0
	local.set	9
	block   	
	local.get	1
	local.get	2
	i32.le_u
	br_if   	0                               # 0: down to label992
# %bb.1:
	local.get	0
	local.get	2
	i32.add 
	local.tee	10
	i32.load8_u	0
	local.tee	11
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	0                               # 0: down to label992
# %bb.2:
	i32.const	0
	local.set	9
	local.get	4
	i32.const	0
	local.get	4
	local.get	8
	i32.sub 
	local.tee	8
	local.get	8
	local.get	4
	i32.gt_u
	i32.select
	local.tee	12
	i32.le_u
	br_if   	0                               # 0: down to label992
# %bb.3:
	local.get	0
	local.get	2
	i32.add 
	local.set	13
	local.get	1
	local.get	2
	i32.sub 
	local.set	14
.LBB44_4:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB44_10 Depth 2
                                        #     Child Loop BB44_16 Depth 2
                                        #     Child Loop BB44_19 Depth 2
                                        #     Child Loop BB44_21 Depth 2
                                        #     Child Loop BB44_24 Depth 2
	loop    	                                # label993:
	block   	
	local.get	3
	local.get	4
	i32.const	-1
	i32.add 
	local.tee	4
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	15
	i32.load	40
	local.tee	16
	i32.const	-1
	i32.add 
	local.get	14
	i32.ge_u
	br_if   	0                               # 0: down to label994
# %bb.5:                                #   in Loop: Header=BB44_4 Depth=1
	local.get	11
	local.get	0
	local.get	15
	i32.load	36
	local.tee	17
	i32.add 
	local.tee	1
	i32.load8_u	0
	i32.ne  
	br_if   	0                               # 0: down to label994
# %bb.6:                                #   in Loop: Header=BB44_4 Depth=1
	local.get	16
	i32.const	8
	local.get	16
	i32.const	8
	i32.lt_u
	i32.select
	local.set	18
	local.get	17
	local.get	16
	i32.add 
	local.set	19
	local.get	16
	local.get	2
	i32.add 
	local.set	20
	block   	
	local.get	16
	i32.const	7
	i32.gt_u
	local.tee	21
	i32.eqz
	br_if   	0                               # 0: down to label995
# %bb.7:                                #   in Loop: Header=BB44_4 Depth=1
	local.get	0
	local.get	20
	local.get	18
	i32.sub 
	i32.add 
	i64.load	0:p2align=0
	local.get	0
	local.get	19
	local.get	18
	i32.sub 
	i32.add 
	i64.load	0:p2align=0
	i64.ne  
	br_if   	1                               # 1: down to label994
.LBB44_8:                               #   in Loop: Header=BB44_4 Depth=1
	end_block                               # label995:
	block   	
	local.get	18
	i32.const	8
	i32.and 
	local.tee	22
	local.get	18
	i32.eq  
	local.tee	23
	br_if   	0                               # 0: down to label996
# %bb.9:                                #   in Loop: Header=BB44_4 Depth=1
	local.get	13
	local.get	16
	i32.add 
	local.set	24
	local.get	22
	local.get	18
	i32.sub 
	local.set	8
	local.get	0
	local.get	19
	i32.add 
	local.set	19
.LBB44_10:                              #   Parent Loop BB44_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label997:
	local.get	24
	local.get	8
	i32.add 
	i32.load8_u	0
	local.get	19
	local.get	8
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	2                               # 2: down to label994
# %bb.11:                               #   in Loop: Header=BB44_10 Depth=2
	local.get	8
	i32.const	1
	i32.add 
	local.tee	8
	br_if   	0                               # 0: up to label997
.LBB44_12:                              #   in Loop: Header=BB44_4 Depth=1
	end_loop
	end_block                               # label996:
	local.get	16
	local.get	18
	i32.sub 
	i32.const	1
	i32.shr_u
	local.set	8
	block   	
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label998
# %bb.13:                               #   in Loop: Header=BB44_4 Depth=1
	local.get	10
	local.get	8
	i32.add 
	i64.load	0:p2align=0
	local.get	1
	local.get	8
	i32.add 
	i64.load	0:p2align=0
	i64.ne  
	br_if   	1                               # 1: down to label994
.LBB44_14:                              #   in Loop: Header=BB44_4 Depth=1
	end_block                               # label998:
	block   	
	local.get	23
	br_if   	0                               # 0: down to label999
# %bb.15:                               #   in Loop: Header=BB44_4 Depth=1
	local.get	18
	local.get	22
	i32.sub 
	local.set	19
	local.get	13
	local.get	8
	local.get	22
	i32.add 
	local.tee	24
	i32.add 
	local.set	8
	local.get	0
	local.get	24
	local.get	17
	i32.add 
	i32.add 
	local.set	24
.LBB44_16:                              #   Parent Loop BB44_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label1000:
	local.get	8
	i32.load8_u	0
	local.get	24
	i32.load8_u	0
	i32.ne  
	br_if   	2                               # 2: down to label994
# %bb.17:                               #   in Loop: Header=BB44_16 Depth=2
	local.get	8
	i32.const	1
	i32.add 
	local.set	8
	local.get	24
	i32.const	1
	i32.add 
	local.set	24
	local.get	19
	i32.const	-1
	i32.add 
	local.tee	19
	br_if   	0                               # 0: up to label1000
.LBB44_18:                              #   in Loop: Header=BB44_4 Depth=1
	end_loop
	end_block                               # label999:
	i32.const	0
	local.set	24
	local.get	16
	local.set	19
	local.get	10
	local.set	8
.LBB44_19:                              #   Parent Loop BB44_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label1002:
	block   	
	local.get	16
	local.get	24
	i32.add 
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label1003
# %bb.20:                               #   in Loop: Header=BB44_4 Depth=1
	i32.const	0
	local.set	18
	local.get	8
	local.set	17
	local.get	1
	local.set	21
	local.get	16
	local.set	22
.LBB44_21:                              #   Parent Loop BB44_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label1005:
	block   	
	local.get	24
	local.get	22
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label1006
# %bb.22:                               #   in Loop: Header=BB44_4 Depth=1
	local.get	18
	local.get	24
	i32.sub 
	local.get	16
	i32.lt_u
	br_if   	2                               # 2: down to label1004
	br      	5                               # 5: down to label1001
.LBB44_23:                              #   in Loop: Header=BB44_21 Depth=2
	end_block                               # label1006:
	local.get	1
	local.get	18
	i32.add 
	local.set	23
	local.get	8
	local.get	18
	i32.add 
	local.set	25
	local.get	17
	i32.const	8
	i32.add 
	local.set	17
	local.get	21
	i32.const	8
	i32.add 
	local.set	21
	local.get	19
	i32.const	-8
	i32.add 
	local.set	19
	local.get	22
	i32.const	-8
	i32.add 
	local.set	22
	local.get	18
	i32.const	8
	i32.add 
	local.set	18
	local.get	25
	i64.load	0:p2align=0
	local.get	23
	i64.load	0:p2align=0
	i64.ne  
	br_if   	5                               # 5: down to label994
	br      	0                               # 0: up to label1005
.LBB44_24:                              #   Parent Loop BB44_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	end_loop
	end_block                               # label1004:
	loop    	                                # label1007:
	local.get	17
	i32.load8_u	0
	local.get	21
	i32.load8_u	0
	i32.ne  
	br_if   	4                               # 4: down to label994
# %bb.25:                               #   in Loop: Header=BB44_24 Depth=2
	local.get	17
	i32.const	1
	i32.add 
	local.set	17
	local.get	21
	i32.const	1
	i32.add 
	local.set	21
	local.get	19
	i32.const	-1
	i32.add 
	local.tee	19
	i32.eqz
	br_if   	3                               # 3: down to label1001
	br      	0                               # 0: up to label1007
.LBB44_26:                              #   in Loop: Header=BB44_19 Depth=2
	end_loop
	end_block                               # label1003:
	local.get	8
	i32.const	16
	i32.add 
	local.set	18
	local.get	1
	i32.const	16
	i32.add 
	local.set	17
	local.get	8
	v128.load	0:p2align=0
	local.set	26
	local.get	1
	v128.load	0:p2align=0
	local.set	27
	local.get	19
	i32.const	-32
	i32.add 
	local.set	19
	local.get	8
	i32.const	32
	i32.add 
	local.set	8
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	24
	i32.const	-32
	i32.add 
	local.set	24
	local.get	17
	v128.load	0:p2align=0
	local.get	18
	v128.load	0:p2align=0
	v128.xor
	local.get	27
	local.get	26
	v128.xor
	v128.or
	v128.any_true
	br_if   	2                               # 2: down to label994
	br      	0                               # 0: up to label1002
.LBB44_27:
	end_loop
	end_block                               # label1001:
	local.get	5
	local.get	15
	i64.load	56:p2align=2
	i64.store	56:p2align=2
	local.get	5
	local.get	15
	i32.load	64
	i32.store	64
	local.get	6
	local.get	20
	i32.store	0
	local.get	7
	local.get	4
	i32.store	0
	i32.const	1
	local.set	9
	br      	2                               # 2: down to label992
.LBB44_28:                              #   in Loop: Header=BB44_4 Depth=1
	end_block                               # label994:
	local.get	4
	local.get	12
	i32.gt_u
	br_if   	0                               # 0: up to label993
.LBB44_29:
	end_loop
	end_block                               # label992:
	local.get	9
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_value_span_with_glossary_hints,"",@
	.type	parse_value_span_with_glossary_hints,@function # -- Begin function parse_value_span_with_glossary_hints
parse_value_span_with_glossary_hints:   # @parse_value_span_with_glossary_hints
	.functype	parse_value_span_with_glossary_hints (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32
# %bb.0:
	i32.const	0
	local.set	8
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label1008
# %bb.1:
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	223
	i32.and 
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label1009
# %bb.2:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	local.get	4
	local.get	5
	local.get	6
	local.get	7
	call	parse_composite_span_impl
	return
.LBB45_3:
	end_block                               # label1009:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	call	parse_value_span
	local.set	8
.LBB45_4:
	end_block                               # label1008:
	local.get	8
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.next_format3_field,"",@
	.type	next_format3_field,@function    # -- Begin function next_format3_field
next_format3_field:                     # @next_format3_field
	.functype	next_format3_field (i32, i32, i32) -> (i32)
	.local  	i32, i32, i32
# %bb.0:
	block   	
	local.get	2
	i32.load	0
	local.tee	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label1010
# %bb.1:
.LBB46_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label1011:
	local.get	0
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label1010
# %bb.3:                                #   in Loop: Header=BB46_2 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label1010
# %bb.4:                                #   in Loop: Header=BB46_2 Depth=1
	local.get	1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	i32.ne  
	br_if   	0                               # 0: up to label1011
# %bb.5:
	end_loop
	i32.const	0
	return
.LBB46_6:
	end_block                               # label1010:
	i32.const	0
	local.set	5
	block   	
	local.get	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label1012
# %bb.7:
	local.get	0
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	0                               # 0: down to label1012
# %bb.8:
	block   	
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label1013
# %bb.9:
.LBB46_10:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label1014:
	local.get	0
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label1013
# %bb.11:                               #   in Loop: Header=BB46_10 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label1013
# %bb.12:                               #   in Loop: Header=BB46_10 Depth=1
	local.get	1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	i32.ne  
	br_if   	0                               # 0: up to label1014
	br      	2                               # 2: down to label1012
.LBB46_13:
	end_loop
	end_block                               # label1013:
	local.get	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label1012
# %bb.14:
	local.get	2
	local.get	3
	i32.store	0
	i32.const	1
	local.set	5
.LBB46_15:
	end_block                               # label1012:
	local.get	5
                                        # fallthrough-return
	end_function
                                        # -- End function
	.type	heap_ptr,@object                # @heap_ptr
	.section	.bss.heap_ptr,"",@
	.p2align	2, 0x0
heap_ptr:
	.int32	0                               # 0x0
	.size	heap_ptr, 4

	.type	last_parse_capacity,@object     # @last_parse_capacity
	.section	.bss.last_parse_capacity,"",@
	.p2align	2, 0x0
last_parse_capacity:
	.int32	0                               # 0x0
	.size	last_parse_capacity, 4

	.type	last_content_capacity,@object   # @last_content_capacity
	.section	.bss.last_content_capacity,"",@
	.p2align	2, 0x0
last_content_capacity:
	.int32	0                               # 0x0
	.size	last_content_capacity, 4

	.type	crc32_table_initialized,@object # @crc32_table_initialized
	.section	.bss.crc32_table_initialized,"",@
	.p2align	2, 0x0
crc32_table_initialized:
	.int8	0                               # 0x0
	.size	crc32_table_initialized, 1

	.type	crc32_table,@object             # @crc32_table
	.section	.bss.crc32_table,"",@
	.p2align	4, 0x0
crc32_table:
	.skip	16384
	.size	crc32_table, 16384

	.type	crc32_braid_initialized,@object # @crc32_braid_initialized
	.section	.bss.crc32_braid_initialized,"",@
	.p2align	2, 0x0
crc32_braid_initialized:
	.int8	0                               # 0x0
	.size	crc32_braid_initialized, 1

	.type	crc32_braid_table,@object       # @crc32_braid_table
	.section	.bss.crc32_braid_table,"",@
	.p2align	4, 0x0
crc32_braid_table:
	.skip	8192
	.size	crc32_braid_table, 8192

	.type	encode_term_content_row.PREFIX_RULES,@object # @encode_term_content_row.PREFIX_RULES
	.section	.rodata.encode_term_content_row.PREFIX_RULES,"S",@
encode_term_content_row.PREFIX_RULES:
	.asciz	"{\"rules\":"
	.size	encode_term_content_row.PREFIX_RULES, 10

	.type	encode_term_content_row.PREFIX_DEFINITION_TAGS,@object # @encode_term_content_row.PREFIX_DEFINITION_TAGS
	.section	.rodata.encode_term_content_row.PREFIX_DEFINITION_TAGS,"S",@
	.p2align	4, 0x0
encode_term_content_row.PREFIX_DEFINITION_TAGS:
	.asciz	",\"definitionTags\":"
	.size	encode_term_content_row.PREFIX_DEFINITION_TAGS, 19

	.type	encode_term_content_row.PREFIX_TERM_TAGS,@object # @encode_term_content_row.PREFIX_TERM_TAGS
	.section	.rodata.encode_term_content_row.PREFIX_TERM_TAGS,"S",@
encode_term_content_row.PREFIX_TERM_TAGS:
	.asciz	",\"termTags\":"
	.size	encode_term_content_row.PREFIX_TERM_TAGS, 13

	.type	encode_term_content_row.PREFIX_GLOSSARY,@object # @encode_term_content_row.PREFIX_GLOSSARY
	.section	.rodata.encode_term_content_row.PREFIX_GLOSSARY,"S",@
encode_term_content_row.PREFIX_GLOSSARY:
	.asciz	",\"glossary\":"
	.size	encode_term_content_row.PREFIX_GLOSSARY, 13

	.type	.L.str,@object                  # @.str
	.section	.rodata..L.str,"S",@
.L.str:
	.asciz	"type"
	.size	.L.str, 5

	.type	.L.str.1,@object                # @.str.1
	.section	.rodata..L.str.1,"S",@
.L.str.1:
	.asciz	"text"
	.size	.L.str.1, 5

	.type	.L.str.2,@object                # @.str.2
	.section	.rodata..L.str.2,"S",@
.L.str.2:
	.asciz	"path"
	.size	.L.str.2, 5

	.type	.L.str.3,@object                # @.str.3
	.section	.rodata..L.str.3,"S",@
.L.str.3:
	.asciz	"content"
	.size	.L.str.3, 8

	.type	.L.str.4,@object                # @.str.4
	.section	.rodata..L.str.4,"S",@
.L.str.4:
	.asciz	"image"
	.size	.L.str.4, 6

	.type	.L.str.5,@object                # @.str.5
	.section	.rodata..L.str.5,"S",@
.L.str.5:
	.asciz	"structured-content"
	.size	.L.str.5, 19

	.type	.L.str.6,@object                # @.str.6
	.section	.rodata..L.str.6,"S",@
.L.str.6:
	.asciz	"img"
	.size	.L.str.6, 4

	.ident	"Debian clang version 21.1.8 (++20251221032947+2078da43e25a-1~exp1~20251221153113.67)"
	.size	__heap_base, 1
	.section	.custom_section.producers,"",@
	.int8	1
	.int8	12
	.ascii	"processed-by"
	.int8	1
	.int8	12
	.ascii	"Debian clang"
	.int8	63
	.ascii	"21.1.8 (++20251221032947+2078da43e25a-1~exp1~20251221153113.67)"
	.section	.rodata..L.str.6,"S",@
	.section	.custom_section.target_features,"",@
	.int8	10
	.int8	43
	.int8	7
	.ascii	"atomics"
	.int8	43
	.int8	11
	.ascii	"bulk-memory"
	.int8	43
	.int8	15
	.ascii	"bulk-memory-opt"
	.int8	43
	.int8	22
	.ascii	"call-indirect-overlong"
	.int8	43
	.int8	10
	.ascii	"multivalue"
	.int8	43
	.int8	15
	.ascii	"mutable-globals"
	.int8	43
	.int8	19
	.ascii	"nontrapping-fptoint"
	.int8	43
	.int8	15
	.ascii	"reference-types"
	.int8	43
	.int8	8
	.ascii	"sign-ext"
	.int8	43
	.int8	7
	.ascii	"simd128"
	.section	.rodata..L.str.6,"S",@
