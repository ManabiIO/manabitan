from pathlib import Path
import json,re,hashlib,shutil
root=Path('/tmp/cpu-original-audit-46153880495-attempt1-zs5uf_xj')
sealed=Path('/tmp/manabitan-whole-import-screen-seal-candidate-20261128-1c413')
def read(p):return json.loads(p.read_bytes())
def identity(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlobIdentity':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
run=read(root/'metadata/final-run.json');jobs=read(root/'metadata/final-jobs.json');artifacts=read(root/'metadata/final-artifacts.json');producer=read(root/'metadata/initial-producer.json')
freeze_bytes=(root/'metadata/initial-freeze.json').read_bytes();freeze=json.loads(freeze_bytes)
assert identity(freeze_bytes)['gitBlobIdentity']=='c68479339d2cd3930d1aeaf2184152cb6eedb1c1'
planbytes=(sealed/'plan.json').read_bytes();plan=json.loads(planbytes)
assert identity(planbytes)['sha256']=='1faa5618f7f5b3f537d41c9fa0f4c78870b7a8418685baf2639e01b09d598d4d'
assert run['id']==46153880495 and run['run_attempt']==1 and run['status']=='completed' and run['conclusion']=='failure'
assert run['head_sha']==producer['sha']==freeze['producer']['commit']=='3ca60b3f80733e0a07e26a6141a9cad6febfdb55'
assert producer['tree']['sha']==freeze['producer']['tree']=='ab4af038a8e9da0bb6080b493166b6dd6e735eab'
assert [x['sha'] for x in producer['parents']]==['01eb863506012136e417167f445b2708d9136293']
assert run['head_branch']=='test/native-whole-import-cpu-screen-20261128-1c413'
assert artifacts=={'total_count':0,'artifacts':[]}
assert jobs['total_count']==2
expected_jobs={'R1':141006157502,'R2':141006157198}
results={}
for repl,jobid in expected_jobs.items():
 job=next(x for x in jobs['jobs'] if x['id']==jobid)
 assert job['run_id']==run['id'] and job['run_attempt']==1 and job['head_sha']==run['head_sha']
 assert job['status']=='completed' and job['conclusion']=='failure'
 acquisition=next(x for x in job['steps'] if x['name']=='Run the original fixed six warmups and 36 measured entries')
 upload=next(x for x in job['steps'] if x['name']=='Retain every original raw sink, field buffer, receipt, source and failure')
 assert acquisition['conclusion']=='success' and upload['conclusion']=='failure'
 b=(root/'logs'/f'{repl}-job-{jobid}.log').read_bytes();lines=b.decode().splitlines()
 decoded=[re.sub(r'^\ufeff?\d{4}-\d\d-\d\dT[\d:.]+Z ?', '',x) for x in lines]
 parsed=[]
 for i,line in enumerate(decoded):
  try:v=json.loads(line)
  except (ValueError,TypeError):continue
  parsed.append({'logLine':i+1,'value':v})
 assert len(parsed)==42
 config=next(x for x in plan['replications'] if x['id']==repl)
 expected=[]
 for phase,key in [('warmup','warmups'),('measured','blocks')]:
  for block in config[key]:
   for arm in block:expected.append({'replication':repl,'index':len(expected),'phase':phase,'arm':arm})
 assert [x['value'] for x in parsed]==expected
 assert all(set(x['value'])=={'replication','index','phase','arm'} for x in parsed)
 errors=[{'logLine':i+1,'text':x} for i,x in enumerate(lines) if '##[error]' in x]
 assert len(errors)==1 and 'Vertical bar |' in errors[0]['text']
 assert f'/study-results/{repl}/observations/000-warmup-'+expected[0]['arm']+'/disk/root/manabitan-term-records/dict-25|JMdict%20%5B2026-11-22%5Draw-block-v2%3Ajmdict.mbtr' in errors[0]['text']
 assert any('there will be 1662 files uploaded' in x for x in lines)
 assert any('node: v22.22.0' in x for x in lines)
 assert any('sha256='+plan['fixture']['sha256'] in x for x in lines)
 results[repl]={'jobId':jobid,'jobConclusion':job['conclusion'],'runnerId':job['runner_id'],'runnerName':job['runner_name'],'runnerLabels':job['labels'],'acquisitionStep':acquisition,'uploadStep':upload,'fullDecodedLog':identity(b),'fullDecodedLogLines':len(lines),'singleLineJsonProgressCount':len(parsed),'completeLaunchScheduleMatchesFrozenPlan':True,'progressEmittedBeforeEachChild':True,'scheduleProgress':parsed,'rawClockReceiptPresent':False,'acquisitionJsonPresent':False,'summaryJsonPresent':False,'retainedArtifactCount':0,'plannedUploadFileCountReported':1662,'error':errors[0],'nodeVersionLogged':'v22.22.0','fixtureHashLogged':plan['fixture']['sha256'],'independentObservationChecksPossible':False}
assert len({x['runnerId'] for x in results.values()})==2
sourcefiles=['plan.json','screen.mjs','workflow/native-whole-import-cpu-screen-1c413.yml','final-file-manifest.json','corpus/receipt-adapter.mjs']
source_evidence={}
for path in sourcefiles:
 data=(sealed/path).read_bytes();ref=next(x for x in freeze['files'] if x['name']==path)
 assert identity(data)=={'bytes':ref['bytes'],'sha256':ref['sha256'],'gitBlobIdentity':ref['gitBlob']}
 dest=root/'frozen-source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 source_evidence[path]=identity(data)
result={'schema':1,'kind':'complete-original-accessible-evidence-audit-with-terminal-preservation-failure','integrityAuditDisposition':'FAILED_UNREVIEWABLE','cohortDispositionPermanent':True,'observedComparativeValuesExposedInAccessibleEvidence':0,'laterStudyMayBeCombinedOrSubstituted':False,'performanceDisposition':'NO_AUDITABLE_NUMERIC_RESULT_OR_NOMINATION','runId':run['id'],'attempt':1,'runConclusion':'failure','producer':freeze['producer'],'branch':run['head_branch'],'planSha256':identity(planbytes)['sha256'],'preAcquisitionFreezeBlob':'c68479339d2cd3930d1aeaf2184152cb6eedb1c1','finalArtifactCount':0,'replications':results,'sourceEvidence':source_evidence,'cause':'actions/upload-artifact rejected the vertical bar in an unchanged production raw term-record filename before any artifact was created','sourceControlFlowFindings':{'perObservationStdoutStderrRedirectedToFiles':True,'jobStdoutContainsScheduleProgressOnly':True,'acquisitionAndRawClocksWrittenOnlyToFiles':True,'summaryWrittenOnlyToFile':True,'successfulAcquisitionExitDoesNotRequireNominationGatePassed':True,'nominationBooleanUnavailable':True},'unavailableOriginalEvidence':['acquisition.json','summary.json','per-observation report.json and validation receipts','per-observation raw clock start/end receipts','per-observation source-before/source-after and host/affinity receipts','per-observation worker/owner/field/work/activation/lifecycle receipts','per-observation complete raw disk sinks and field buffers','per-observation stdout/stderr and any failure originals','prepared-runtime/capacity receipts and original Node22 pure-check result files'],'limit':'Not a local capacity or stream-extraction limit: original run artifact total_count is zero; the frozen uploader rejected a filename. No artifact ID or signed download URL exists to acquire.','scope':'All available completed full job logs and original run/job/artifact/producer/freeze metadata preserved and checked. Source assertions reporting successful acquisition are not substituted for independent raw artifact audits. Job log timestamps are not CPU samples.','productImportsExecutedByAuditor':0,'newTimingAcquisitions':0,'retries':0,'cancellations':0,'refsCreated':0,'prsCreated':0,'artifactDownloadsAttempted':0}
(root/'original-evidence-audit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'disposition':result['integrityAuditDisposition'],'runId':run['id'],'attempt':1,'artifactCount':0,'replications':{k:{'jobId':v['jobId'],'progressEntries':v['singleLineJsonProgressCount'],'scheduleMatches':True,'logSha256':v['fullDecodedLog']['sha256'],'error':v['error']['text']} for k,v in results.items()}},indent=2))
