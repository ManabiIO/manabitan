from pathlib import Path
import tarfile,gzip,hashlib,json,io
root=Path('/tmp/cpu-original-audit-46153880495-attempt1-zs5uf_xj')
archive=root/'cpu-original-accessible-evidence-46153880495-attempt1.tar.gz'
ledger=root/'evidence-ledger.json'
readback=root/'archive-readback.json'
def identity(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlobIdentity':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
entries={}
for path in sorted(root.rglob('*')):
 if path in [archive,ledger,readback]:continue
 assert not path.is_symlink()
 if not path.is_file():continue
 name=path.relative_to(root).as_posix()
 assert not name.startswith('/') and '..' not in Path(name).parts
 kind='original-provider-evidence' if name.startswith(('logs/','metadata/')) else 'exact-frozen-source' if name.startswith('frozen-source/') else 'auditor-created'
 entries[name]={'type':'regular', 'kind':kind, **identity(path.read_bytes())}
ledger.write_text(json.dumps({'schema':1,'runId':46153880495,'attempt':1,'producer':'3ca60b3f80733e0a07e26a6141a9cad6febfdb55','artifactCount':0,'scope':'All available completed original decoded job logs and metadata; missing raw artifacts are not represented as retained','entries':entries},sort_keys=True,indent=2)+'\n')
all_entries={**entries,'evidence-ledger.json':{'type':'regular','kind':'auditor-ledger',**identity(ledger.read_bytes())}}
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as gz:
  with tarfile.open(fileobj=gz,mode='w|',format=tarfile.PAX_FORMAT) as tar:
   for name in sorted(all_entries):
    b=(root/name).read_bytes();info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    tar.addfile(info,io.BytesIO(b))
verified={}
with tarfile.open(archive,'r:gz') as tar:
 for member in tar:
  assert member.isfile() and not member.islnk() and not member.issym()
  assert member.name in all_entries and member.name not in verified
  actual=identity(tar.extractfile(member).read())
  assert actual=={k:all_entries[member.name][k] for k in actual}
  verified[member.name]={'type':'regular',**actual}
assert set(verified)==set(all_entries)
result={'schema':1,'passed':True,'scope':'Complete deterministic archive readback of available originals; zero original raw run artifacts available','runId':46153880495,'attempt':1,'archive':identity(archive.read_bytes()),'originalProviderEvidenceFiles':sum(x['kind']=='original-provider-evidence' for x in entries.values()),'payloadCount':len(entries),'memberCount':len(verified),'allRegularNoLinks':True,'completeMembers':verified,'remotePublicationPerformed':False}
readback.write_text(json.dumps(result,sort_keys=True,indent=2)+'\n')
for path in [archive,ledger,readback,root/'REVIEW.md',root/'original-evidence-audit.json']:
 print(json.dumps({'path':str(path),**identity(path.read_bytes())}))
