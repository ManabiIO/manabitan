import gzip
import hashlib
import json
import pathlib
import stat
import tarfile

root = pathlib.Path('/tmp/manabitan-native-fields-fusion-evidence-1c413-20261128')
archive = root.with_suffix('.tar.gz')
receipt = root.with_suffix('.archive.json')
if archive.exists() or receipt.exists():
    raise FileExistsError('Archive originals already exist')
members = []
for path in sorted(root.rglob('*')):
    info = path.lstat()
    if stat.S_ISDIR(info.st_mode):
        continue
    if not stat.S_ISREG(info.st_mode):
        raise ValueError('Unexpected nonregular evidence member: ' + str(path))
    data = path.read_bytes()
    members.append({'path': str(path.relative_to(root)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with archive.open('xb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0, compresslevel=6) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as output:
            for member in members:
                path = root / member['path']
                info = tarfile.TarInfo(member['path'])
                info.size = member['bytes']
                info.mode = 0o644
                info.mtime = 0
                with path.open('rb') as source:
                    output.addfile(info, source)
with tarfile.open(archive, 'r:gz') as check:
    actual = check.getmembers()
    if len(actual) != len(members):
        raise ValueError('Member count mismatch')
    for item, expected in zip(actual, members, strict=True):
        if not item.isfile() or item.name != expected['path'] or item.size != expected['bytes']:
            raise ValueError('Member identity mismatch')
        source = check.extractfile(item)
        if source is None or hashlib.sha256(source.read()).hexdigest() != expected['sha256']:
            raise ValueError('Member payload mismatch')
value = {'kind': 'complete-unmeasured-fusion-evidence-archive', 'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'memberCount': len(members), 'allMemberTypesSizesHashesVerified': True, 'members': members, 'candidate': 'd6fc24acaa19cfbb907cbc42d8ef72235588d5b3', 'control': '0ac6b01e6055fd1f3494252dea482910da3e6c77', 'performanceAcquired': False, 'nothingRemoved': True}
receipt.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps({k: v for k, v in value.items() if k != 'members'}))

