import hashlib
import json
import os
import pathlib
import signal
import subprocess
import sys

root = pathlib.Path('/tmp/manabitan-native-fields-fusion-1c413-20261128')
evidence = pathlib.Path(__file__).parent
name, timeout, *command = sys.argv[1:]
if not name or '/' in name or not command:
    raise ValueError('Expected gate name, timeout and command')
log = evidence / (name + '.log')
receipt = evidence / (name + '.json')
if log.exists() or receipt.exists():
    raise FileExistsError('Original gate evidence already exists')
env = os.environ.copy()
env['MANABITAN_CLANG'] = '/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr/lib/llvm-21/bin/clang'
env['MANABITAN_WASM_LD'] = '/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr/lib/llvm-21/bin/wasm-ld'
env['LD_LIBRARY_PATH'] = '/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr/lib/x86_64-linux-gnu'
env['PATH'] = '/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr/bin' + os.pathsep + env.get('PATH', '')
env['NODE_OPTIONS'] = '--max-old-space-size=1536'
env['MANABITAN_CODSPEED'] = '0'
env['NODE_DISABLE_COMPILE_CACHE'] = '1'
before = subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=root)
with log.open('xb') as output:
    process = subprocess.Popen(command, cwd=root, env=env, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        code = process.wait(timeout=int(timeout))
        timed_out = False
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        code = None
        timed_out = True
after = subprocess.check_output(['git', 'diff', '--cached', '--binary'], cwd=root)
data = log.read_bytes()
value = {
    'name': name,
    'kind': 'correctness-build-validation-only',
    'command': command,
    'cwd': str(root),
    'baseline': '663df294f40e1832ad3e3349d0e061681fed77cb',
    'node': subprocess.check_output(['node', '--version'], text=True).strip(),
    'dependencyRealpath': str((root / 'node_modules').resolve()),
    'nodeOptions': env['NODE_OPTIONS'],
    'pinnedCompilerLibraryPath': env['LD_LIBRARY_PATH'],
    'pinnedToolchainPathPrefix': '/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr/bin',
    'exitCode': code,
    'timedOut': timed_out,
    'logBytes': len(data),
    'logSha256': hashlib.sha256(data).hexdigest(),
    'indexPatchSha256Before': hashlib.sha256(before).hexdigest(),
    'indexPatchSha256After': hashlib.sha256(after).hexdigest(),
    'sourceIndexUnchanged': before == after,
    'performanceMeasurement': False,
}
receipt.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(value), flush=True)
sys.exit(0 if code == 0 and before == after else 1)
