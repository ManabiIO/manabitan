from pathlib import Path
import json,hashlib
r=Path(__file__).parent
a=json.loads((r/'independent-receipt-audit.json').read_text())
v=json.loads((r/'independent-validation-audit.json').read_text())
s=a['source']
lines=[
'# Independent audit of original whole-record fusion correctness run',
'',
'**Verdict: PASS for the declared correctness boundary. No performance or PR qualification is claimed.**',
'',
'This review uses only original completed GitHub metadata, both complete original artifacts, full decoded job logs, exact source/fixture-lock blobs, and retained receipts. The reviewer ran no product modules, imports, benchmarks, replacement observations, workflow reruns, source changes, refs, or PR operations.',
'',
'## Immutable provenance',
'',
'- Repository: ManabiIO/manabitan.',
'- Original run: [46149981540](https://github.com/ManabiIO/manabitan/actions/runs/46149981540), attempt **1**; both jobs and the run are terminal success.',
'- Producer head: a9debd150d65c8d11884dadcdf162e7898dea309.',
'- Producer tree: 56af9b6152630c9e7b11c30652e21fb88e69aa34.',
'- Sole parent / product B: 01eb863506012136e417167f445b2708d9136293.',
'- Exact A: a300da36d00df8e353c5679b1528b50a1299b75f; tree 5fe9ee5a3e2c27ce4e099cb3d6a598077027eac4.',
'- Branch: test/native-record-fields-fusion-20261128-1c413.',
'- Workflow blob: 0544c5cab2a62ff4dde4e95b51805451ce822097.',
'- Source manifest blob: 75c7b527113a83126acb0b1e935d85427f89d2ce.',
'- Source manifest SHA-256: 28b0894c47adaadae564e50ef89a391fc6b323d6de5db4b4d6c0d9bdbd0be86b.',
'- Aggregate source digest: 2b6ea2c90f870ced276c6bf49a67b6d1b1aead8fe144956b321d6af37ee0c132.',
'',
'All 36 bound files (16 product plus 20 workflow/kit files), plus source.json itself, match their Git identities and complete original validation payload bytes. Every corpus artifact overlap matches the validation payload byte-for-byte. The exact A→producer change set is those 37 paths. The protected baseline sources and fixture lock were independently verified against Git. The dictionary fixture lock is blob eb72e9afb9feb0be1e7ebf9b807344cf6c9333e2, 3,047 bytes, SHA-256 60aa981791f3b60ca17588212aea5bd3536fb8f59288855e5accd019c6e4cf89.',
'',
'| Job | Original artifact | ZIP bytes | Original ZIP SHA-256 |',
'|---|---:|---:|---|'
]
for jid,j in v['jobs'].items():
    art=j['artifact']
    lines.append(f"| {jid} — {j['jobName']} | {art['id']} | {art['size_in_bytes']:,} | {art['digest'][7:]} |")
lines+=['','Both ZIP digests equal GitHub metadata and their completed uploader logs. Full decoded UTF-8 logs are retained:','']
for jid,j in v['jobs'].items():
    log=j['fullDecodedLog']
    lines.append(f"- Job {jid}: {log['bytes']:,} bytes; SHA-256 {log['sha256']}.")
lines+=['',
'The corpus ZIP contains the original PAX tar and full member receipt. The tar is 1,167,889 bytes, SHA-256 4ceb96fc3026c39bce4df6a8a21360a77a2a8188830d86d5a35a814e0ba8276b. All 233 members were independently traversed and verified: 205 complete regular-file payloads (5,296,768 bytes), 26 directories, and two smoke symlink metadata entries retained inert. No symlink was followed or materialized; no requested evidence root is missing. The validation ZIP contains 50 complete regular files. Every member was fully read and CRC-checked.',
'',
'## Terminal validation',
'',
'All 12 mandatory step outcomes and conclusions are success: source, setup, generated assets, toolchain, native reproduction, lint, ordinary units, options units, main types, development types, test types, and all-target dry builds. The workflow binds attempt 1 and uses pipefail; its final outcome check examines underlying outcomes so artifact upload cannot hide a failed gate.',
'',
'- Ordinary suite: **701 files passed; 16,035 tests passed; 47 skipped**, 16,082 total.',
'- Options: **32 tests passed** in one file.',
'- Relevant original test files passed: fusion 35, native fields 110, import fields 20, dictionary WASM build 20, release-package native assets 24.',
'- All three type projects passed.',
'- Changed-source lint passed; its original pako vendor CommonJS warning is retained.',
'- Clang/lld **21.1.8** reproduced all three checked-in native targets exactly.',
'- All seven dry builds passed: chrome, chrome-dev, chrome-playwright, firefox, firefox-dev, firefox-android, edge.',
'- Corpus prerequisites passed: 27 pure comparator cases, 14 pure owner cases, nine archive cases, and 11 actual-I/O/worker/media-adapter smoke cases in each original arm.',
'',
'Native reproduction hashes:','']
for target in v['validation']['native']['targets']:
    lines.append(f"- {target['name']}: {target['sha256']}.")
lines+=['',
'## Original imports and native coverage',
'',
'The serial sequence was JMdict A→B, Jitendex A→B, VNDB A→B. All six were fresh Node v22.22.0 processes; every original process exited 0 with an exact full-log digest. Source-before equals source-after in each arm. The bound producer enforces fixture-before/after equality; retained fixture receipts match the exact lock. Every cleanup receipt has completed=true and no cleanup error.',
'',
'| Corpus | Fixture archive bytes | Terms | Banks | Parser groups | Whole calls / rows / attempts | Ordinary native calls / rows | Owners / fields |',
'|---|---:|---:|---:|---:|---|---|---|']
for corpus,x in a['corpora'].items():
    f=s['fixtures'][corpus];n=x['nativeMetrics']
    lines.append(f"| {corpus} | {f['sizeBytes']:,} | {x['rows']:,} | {x['banks']} | {x['parserGroups']} | {n['wholeNativeCalls']} / {n['wholeNativeRows']:,} / {n['wholeNativeAttempts']} | {x['ordinaryNativeCalls']} / {x['ordinaryNativeRows']:,} | {x['owners']} / {x['fields']} |")
lines+=['',
'**Total: 7,613,164 term rows per arm.** Candidate JavaScript field calls and readiness fallbacks are zero in every corpus. All three decline maps are empty; overlapping whole/ordinary decline maps are never blindly added. Baseline native metrics are null and it never fetches the candidate asset. Candidate fetches it once through actual lifecycle initialization without an optional readiness wait.',
'',
'VNDB ordinary-native work is 175 rows in ten raw-v6 owners plus 319,825 rows in 17 raw-block-v2 owners producing 20 fields. Whole-native work is one raw-v6 owner of 40,000 rows plus 161 raw-block-v2 owners of 6,288,310 rows. These are observed ordinary paths with no whole attempt, not readiness fallbacks or native declines.',
'',
'## Enclosing-owner and byte accounting',
'',
'Every owner is settled and error-free; contiguous owner partitions match A/B. Candidate metrics chain continuously from zero cumulative work to final store/publication metrics. Whole fusion occurs before the ordinary field hook: this audit recomputed whole work at owner boundaries, and ordinary work at field boundaries. It did not infer whole work from field-hook differences.',
'',
'Input copies equal rows×8 + unique references×12 for each attempt. Table allocation matches the exact power-of-two slot formula. Successful whole output copies contain all field bytes **plus eight bytes for the scalar base**. A successful whole field hook does not repeat native work or output copies. No native work escapes the recorded owners.',
'',
'| Corpus | Input copies | Field bytes per arm | Whole scalar output bytes | Native output copies | Table bytes | Memory growth | Maximum linear / scratch bytes |',
'|---|---:|---:|---:|---:|---:|---:|---|']
for corpus,x in a['corpora'].items():
    n=x['nativeMetrics']
    lines.append(f"| {corpus} | {n['inputCopiedBytes']:,} | {x['fieldBytes']:,} | {n['wholeNativeCalls']*8:,} | {n['outputCopiedBytes']:,} | {n['tableBytesRequested']:,} | {n['memoryGrowthBytes']:,} | {n['maximumLinearMemoryBytes']:,} / {n['maximumScratchBytes']:,} |")
lines+=['',
'Every field ordinal, owner ordinal, row/unique count, byte length, complete SHA-256, scalar numeric base, and little-endian Float64 base bits matches A/B. Explicit bits preserve signed zero independently of JSON numeric zero. No negative-zero base was observed in these three corpora; signed-zero test coverage is not misrepresented as a corpus observation.',
'',
'Complete canonical field-output witnesses (algorithm retained in independent-receipt-audit.py):','']
for corpus,x in a['corpora'].items():
    lines.append(f"- {corpus}: {x['fieldOutputWitnessSha256']}; owner partition {x['ownerPartitionSha256']}.")
lines+=['',
'## Complete finalized term output',
'',
'All finalized term-content/record/index paths, lengths, normalization declarations, and complete normalized SHA-256 values match. Only documented generation bytes are normalized: MBTRD16X offset 8, length 16; MBTIDX11 offset 24, length 16. Content is never normalized. The source oracle includes legacy numbered term-content segments and fails closed on unknown online/arena layouts; the actual runs used epoch-zero legacy roots with no numbered segment.',
'',
'| Corpus / file role | Bytes per arm | Matching normalized SHA-256 |',
'|---|---:|---|']
for corpus,x in a['corpora'].items():
    for path,n,h,norm in x['completeTermFiles']:
        role='content' if path=='manabitan-term-content.bin' else path.split('%20by%20Bee')[-1] if corpus=='vndb' else ('index' if path.endswith('.mbti') else 'record descriptor')
        lines.append(f"| {corpus} / {role} | {n:,} | {h} |")
lines+=['',
'Finalized term sink totals per arm: **43,315,677 JMdict; 61,977,692 Jitendex; 409,433,345 VNDB bytes**. Complete paths/raw hashes/normalized hashes remain in original files.json and independent-receipt-audit.json.',
'',
'The producer retired only successful paired sinks after a second full raw hash matched files.json and staging was empty. Every retired-disk.json binds its complete original inventory. This reviewer independently reconciled both retained inventories; it cannot rehash absent raw sinks. **Hashes are not retained raw files.** No failed original was removed or replaced.',
'',
'For disabled CPU-screen storage planning, 42 JMdict sinks require **1,819,258,434 bytes**, excluding auxiliary files and the mandatory four-GiB free-space admission floor. Each arm emits 4,239,960 field bytes plus 12 scalar-base witnesses (96 bytes). These fixed byte counts do not establish future host capacity.',
'',
'## Source, worker, parser and lifecycle checks',
'',
'Each arm used three actual Node production-parser worker threads, four compression workers, and VNDB additionally one production index worker. Every asset matches the bound runtime inventory. Each worker became ready once with no failure event. Explicit termination is recorded, explaining final Node termination exit code 1. Every parser request ID has one result; every source bank occurs once. Complete bank group, CRC signature, source byte metadata, and returned-row identities match A/B independently of worker assignment.',
'',
'| Corpus | Compressed / transferred bytes | Uncompressed bytes | CRC scanned bytes | CRC reused bytes / glossary count | Pipeline groups/worker | Compression requests/results/consumed |',
'|---|---:|---:|---:|---|---:|---:|']
for corpus,x in a['corpora'].items():
    p=x['parserWorkCounts'];w=x['workerTotals']['zstd-term-content-compression-worker.js']
    lines.append(f"| {corpus} | {p['fastPathParserSourceCompressedBytes']:,} | {p['fastPathParserSourceUncompressedBytes']:,} | {p['fastPathParserSourceCrcScannedBytes']:,} | {p['fastPathParserSourceCrcReusedBytes']:,} / {p['fastPathParserSourceCrcReusedGlossaryCount']:,} | {p['fastPathParserParallelPipelineGroupsPerWorker']} | {w['compressionRequests']} / {w['compressionResults']} / {w['sourceConsumed']} |")
lines+=['',
'Fused parser attempts are 12/22/170 and fallbacks zero. Compact-content-metadata groups are 0/0/170. Parser/source work counters match except the scheduling-dependent JMdict queued-byte peak below. VNDB index-worker actions match: open 2, writeChunks 87, seek 2, close 2; 93 sent/94 received messages.',
'',
'All initial states have epoch 0/high-water 0; final epoch is 0. Final logical high waters are 19,566,680, 38,386,795, and 7,533,449. SQLite is a real nonpersistent memory database. The exact inner admission helper is rebound only for external host/diagnostic dependencies and schema 12. The outer _openConnection body, schema/root/purge/recovery decisions remain unchanged. usesFallbackStorage=false selects the documented adapter route; this is not persistent SQLite or browser OPFS.',
'',
'Complete generated runtimes contain A582/B586 files, unchanged from preflight through all imports, with exactly the seven declared runtime differences. Both independent npm installations use package-lock SHA-256 01e065503317a90b43a5bc60cd9f874238762c75a13c8115a9c484a626960a96 (333,801 bytes), package.json SHA-256 d23b58a7e5aab32183d4f09e38067d7bacd6b67229c14b18e1e8aa3a0a6c22f9 (9,595 bytes). Generated license bytes equal the committed document and match A/B; the permitted tracked exception was unused.',
'',
'## Every observed A/B difference',
'',
'The full structural diff of every shared arm JSON receipt is preserved in all-receipt-differences.json. Its differences have these explicit categories:',
'',
'1. Arm/source/producer-tree identity; seven declared runtime source differences; added candidate helper/asset; candidate native metrics and route witnesses. Unchanged source, fixture lock, flags, semantics, scalar/field output, SQLite adapter, cleanup, initial state and final state match.',
'2. Record/index raw hashes differ within documented generation-header normalization; complete normalized hashes match. Each second raw inventory equals its own first inventory.',
'3. Parser groups move among workers in JMdict and VNDB while canonical source groups and result rows match. JMdict keeps4/4/4 requests; VNDB A56/57/57 versus B55/57/58, with corresponding per-worker sent/received changes and equal totals. Jitendex keeps identical8/7/7 assignment.',
'4. Asset completion order differs in compression-worker receipts: JMdict indices0/1/3, Jitendex index0, VNDB index2. Complete asset multisets/hashes match.',
'5. These are all scheduling/coalescing product-counter changes (JMdict only):',
'',
'| Counter | A | B |',
'|---|---:|---:|',
'| parserParallelPeakQueuedOwnedContentBytes | 58,114,957 | 45,111,679 |',
'| fastPathParserParallelPeakQueuedOwnedContentBytes | 58,114,957 | 45,111,679 |',
'| termContentWriteCallCount | 2 | 3 |',
'| termContentMergedWriteCount | 2 | 3 |',
'| termContentFlushFinalGroupCount | 2 | 3 |',
'| termContentMaxMergedGroupChunkCount | 85 | 56 |',
'| termContentMaxWriteBytes | 14,617,938 | 9,507,564 |',
'',
'Those seven values plus added native metrics are every product-work-count difference. Jitendex/VNDB differ only by added native metrics. Coalescing and occupancy remain diagnostics, not semantic equal-work identity or performance evidence.',
'',
'6. Host free bytes differ after A retains a sink: JMdict90,237,554,688→90,193,702,912; Jitendex90,236,346,368→90,173,759,488; VNDB90,234,859,520→89,624,903,680. Both satisfy the original admission floor. These are not timing observations.',
'7. **VNDB non-term media differs outside the declared term-byte oracle.** Its generated paths have UUIDs f7622bb8-bc17-4290-ba66-818cdbd67f96 (A) and62e32300-88d8-4fbb-93e2-49b6e14e9ba6 (B). Both files contain199,220,580bytes. SHA-256 A:e844ea5ee183a7da95553fd0de6b6e2a6edd48880664eb7caa80d7a86e53702c; B:e81a121f0bca858180cb50565756c7a5b77b03310361f8fe358a2b0f05f09295. No media bytes are normalized; no exact cause or equality is inferred from absent raw sinks. Media remains explicitly unqualified. JMdict and Jitendex have no non-term disk payload in these receipts.',
'',
'## Scope and durable evidence',
'',
'This passes the fresh original Node correctness gate: actual worker threads, memory SQLite plus disk OPFS adapter, complete term-output equality and successful native accounting. It does not qualify browser/persistent SQLite operation, restart, image decoding, full media, or comparative performance. No historical/old-source receipt or work count was substituted. The separate CPU study is outside this audit.',
'',
'git-blob-ledger.json records exact Git blob, SHA-256, length, and original path for every complete original artifact/member/log/result/metadata item and this review plus independent audit outputs. These are unreferenced blobs for the parent to anchor; this reviewer created no ref.',
'',
'Independent outputs: independent-source-audit.json; corpus-independent-archive-verification.json; independent-validation-audit.json; independent-receipt-audit.json; all-receipt-differences.json. The pure receipt-audit source is independent-receipt-audit.py and never invokes product imports.',
''
]
(r/'REVIEW.md').write_text('\n'.join(lines))
print(json.dumps({'reviewBytes':(r/'REVIEW.md').stat().st_size,'reviewSha256':hashlib.sha256((r/'REVIEW.md').read_bytes()).hexdigest(),'verdict':'PASS within explicit boundary'}))
