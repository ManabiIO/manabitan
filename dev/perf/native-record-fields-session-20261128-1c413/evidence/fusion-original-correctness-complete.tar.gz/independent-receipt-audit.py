from pathlib import Path
import collections, hashlib, json, math, re, struct

R = Path(__file__).parent
C = R / 'corpus-full/builds/perf/native-record-fields-fusion-correctness-corpus/acquisition'
V = R / 'validation'
K = 'dev/perf/whole-record-fusion-correctness-20261128-1c413'
BASE = 'a300da36d00df8e353c5679b1528b50a1299b75f'
HEAD = 'a9debd150d65c8d11884dadcdf162e7898dea309'
EXPECTED = { 'jmdict': (528299,53,12), 'jitendex': (436555,219,22), 'vndb': (6648310,665,170) }
WORK = ['nativeCalls','nativeRows','nativeAttempts','wholeNativeCalls','wholeNativeRows','wholeNativeAttempts','inputCopiedBytes','outputCopiedBytes','tableBytesRequested','memoryGrowthBytes']
DELTA = ['js/dictionary/dictionary-database.js','js/dictionary/term-bank-wasm-parser.js','js/dictionary/term-record-fields.js','js/dictionary/term-record-opfs-store.js','js/dictionary/term-record-prepared-fields.js','js/dictionary/wasm/term-record-fields.c','lib/term-record-fields.wasm']
def pairs(values):
    d = {}
    for k,v in values:
        assert k not in d, ('duplicate JSON key',k)
        d[k] = v
    return d
def bad(value): raise AssertionError(('nonfinite JSON',value))
def load(p): return json.loads(p.read_text(), object_pairs_hook=pairs, parse_constant=bad)
def sha(b): return hashlib.sha256(b).hexdigest()
def identity(p):
    b = p.read_bytes()
    return {'bytes':len(b),'sha256':sha(b)}
def canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False)
def delta(a,b,key): return ((b.get('native') or {}).get(key,0) - (a.get('native') or {}).get(key,0))
def table(n):
    slots=2
    while slots < min(n,65535)*2: slots*=2
    return slots*4
def difference(a,b,p=''):
    if type(a)!=type(b): return [{'path':p,'A':a,'B':b}]
    if isinstance(a,dict):
        return [d for k in sorted(set(a)|set(b)) for d in
                ([{'path':p+'/'+k,'A':a.get(k),'B':b.get(k),'missing':'A' if k not in a else 'B'}] if k not in a or k not in b else difference(a[k],b[k],p+'/'+k))]
    if isinstance(a,list):
        if len(a)!=len(b): return [{'path':p,'A':a,'B':b}]
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in difference(x,y,p+'/'+str(i))]
    return [] if a==b else [{'path':p,'A':a,'B':b}]
for parent in [R/'corpus-full',V]:
    for p in parent.rglob('*.json'): load(p)
manifest=load(V/K/'source.json')
for p,x in manifest['files'].items():
    b=(V/p).read_bytes()
    assert identity(V/p)=={'bytes':x['bytes'],'sha256':x['sha256']}
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['gitBlob']
    if (R/'corpus-full'/p).exists(): assert (R/'corpus-full'/p).read_bytes()==b
lock=load(R/'verified-dictionaries.lock.json')
prepared={arm:load(C/('prepared-source-'+arm+'.json')) for arm in ['A','B']}
assert prepared['A']['packageLock']==prepared['B']['packageLock']
assert prepared['A']['packageJson']==prepared['B']['packageJson']
for arm in ['A','B']:
    assert prepared[arm]['independentNodeModulesDirectory'] is True
protected=load(C.parent/'source-after-setup.json')['protected']
for arm in ['A','B']:
    assert prepared[arm]['packageLock']=={k:protected['package-lock.json'][k] for k in ['bytes','sha256']}
    assert prepared[arm]['packageJson']=={k:protected['package.json'][k] for k in ['bytes','sha256']}
# Dependency lock receipts bind package-lock.json; dictionary fixture lock is separately bound below.
plan=load(C/'plan.json')
assert plan['baseline']==BASE and plan['candidate']==HEAD and plan['armOrder']==['A','B']
assert plan['dictionaryOrder']==list(EXPECTED) and plan['freshProcessPerArm']
assert not plan['performanceMeasurements'] and not plan['optionalReadinessWait'] and not plan['replacementObservations']
assert plan['source']=={p.name:identity(p) for p in (C/'harness-source').iterdir() if p.is_file()}
for p in (C/'harness-source').iterdir(): assert p.read_bytes()==(V/K/'corpus'/p.name).read_bytes()
global_report=load(C/'report.json')
assert global_report['passed'] and not global_report['performanceMeasurements'] and global_report['plan']==plan
summaries={}; all_diffs={}
for corpus,(rows,bank_count,group_count) in EXPECTED.items():
    cell=C/corpus
    fixture=lock['dictionaries'][corpus]
    assert fixture['termRows']==rows
    reports={}; fields={}; owners={}; files={}; worker_summaries={}; groups={}; product={}
    comparison=load(cell/'comparison.json')
    assert comparison==next(x for x in global_report['comparisons'] if x['dictionary']==corpus)
    all_diffs[corpus]={p.name:difference(load(p),load(cell/'B'/p.name)) for p in (cell/'A').glob('*.json')}
    for arm,commit in [('A',BASE),('B',HEAD)]:
        p=cell/arm
        report=reports[arm]=load(p/'report.json')
        f=fields[arm]=load(p/'field-calls.json')
        odata=load(p/'owner-calls.json'); o=owners[arm]=odata['owners']
        ff=files[arm]=load(p/'files.json')
        assert report['passed'] and report['newReconstructedDriver'] and not report['performanceMeasurements']
        assert (report['arm'],report['dictionary'],report['source']['commit'])==(arm,corpus,commit)
        assert report['source']==load(p/'source-before.json')==load(p/'source-after.json')
        assert report['source']['runtimeFiles']==prepared[arm]['runtimeFiles']
        assert report['source']['kit']==plan['source']
        assert report['source']['sources']['test/perf/dictionaries.lock.json']==identity(R/'verified-dictionaries.lock.json')
        host=load(p/'fixture-and-host.json')
        assert host['fixture']==fixture and host['fixtureBefore']==report['fixture']=={'bytes':fixture['sizeBytes'],'sha256':fixture['sha256']}
        assert host['node']=='v22.22.0' and host['coldProcess'] and not host['performanceMeasurements']
        assert int(host['freeBytes'])>=4*1024**3 and host['filesystemType']!='16914836'
        process=load(cell/(arm+'.process.json'))
        assert process['exitCode']==0 and process['log']==identity(cell/(arm+'.log'))
        assert process['argv'][-2:]==[arm,commit] and process['argv'][3]==corpus
        assert load(p/'cleanup.json')=={'completed':True,'cleanupErrors':[]}
        assert odata['schema']==1 and odata['observerErrors']==[] and odata['accounting']==report['ownerAccounting']
        assert report['fieldRows']==rows==sum(x['rowCount'] for x in f)
        assert report['fieldCalls']==len(f) and report['ownerCalls']==len(o)
        assert report['parserWorkers']==3 and report['parserGroups']==group_count
        initial=load(p/'initial-content-state.json'); final=load(p/'final-content-state.json')
        assert initial['epoch']==initial['logicalHighWater']==final['epoch']==0
        assert report['semantic']==load(p/'semantic.json') and report['flags']==load(p/'import-flags.json')
        assert report['semantic']['title']==fixture['expectedTitle'] and report['semantic']['revision']==fixture['revision']
        assert report['semantic']['sample']['outOfBoundsRecordCount']==0 and report['semantic']['sample']['sampledRecordCount']>0
        adapter=load(p/'sqlite-adapter.json')
        assert not adapter['persistentSqlite'] and not adapter['usesFallbackStorageOverride']
        assert adapter['originalBodiesByteIdentical'] and adapter['outerMethodUnmodified'] and adapter['schemaConstant']==12
        for prop,name in [('originalOpenConnectionSha256','baseline-open-connection.txt'),('originalSupportedConnectionSha256','baseline-open-supported-connection.txt'),('schemaConstantSha256','baseline-storage-schema-version.txt')]:
            assert adapter[prop]==sha((V/K/'corpus'/name).read_text().strip().encode())
        assets=load(p/'assets.json')
        for asset in assets:
            assert {k:v for k,v in asset.items() if k!='path'}==report['source']['runtimeFiles'][asset['path'][4:]]
        assert report['optionalAssets']==[x for x in assets if x['path'].endswith('/term-record-fields.wasm')]
        assert len(report['optionalAssets'])==(1 if arm=='B' else 0)
        assert report['termFiles']==[x for x in ff if x['termPayload']]
        assert report['otherFiles']==[x for x in ff if not x['termPayload']]
        assert len({x['path'] for x in ff})==len(ff)
        for x in ff:
            path=x['path']; norm=x['normalization']
            if norm:
                assert (path.endswith('.mbtr') and norm=={'offset':8,'bytes':16,'format':'MBTRD16X'}) or (path.endswith('.mbti') and norm=={'offset':24,'bytes':16,'format':'MBTIDX11'})
            else: assert x['sha256']==x['normalizedSha256']
            if path.startswith(('manabitan-term-content','manabitan-online-content')):
                assert x['termPayload'] and re.fullmatch(r'manabitan-term-content(?:\^[1-9]\d*)?\.bin',path)
            assert x['termPayload'] or path.startswith('manabitan-dictionary-media-v1/')
        retired=load(p/'retired-disk.json')
        assert retired['retired'] and retired['everyRawByteRehashed'] and not retired['rawFilesRetained']
        assert retired['originalFinalizedInventory']==identity(p/'files.json')
        assert retired['files']=={x['path']:{'bytes':x['bytes'],'sha256':x['sha256']} for x in ff}
        assert not (p/'disk').exists()
        assert set(comparison['receipts'][arm])=={x.name for x in p.glob('*.json')} - {'retired-disk.json'}
        for name,expected in comparison['receipts'][arm].items(): assert identity(p/name)==expected
        cursor=0
        for i,owner in enumerate(o):
            assert owner['ordinal']==i and owner['settled'] and owner['error'] is None
            assert owner['fieldStart']==cursor and owner['fieldEnd']>cursor
            selected=f[cursor:owner['fieldEnd']]
            assert sum(x['rowCount'] for x in selected)==owner['rowCount'] and all(x['ownerOrdinal']==i for x in selected)
            cursor=owner['fieldEnd']
            if arm=='A':
                assert owner['before'] is None and owner['after'] is None
                assert all(x['before'] is None and x['after'] is None and x['wholeAttempt'] is None for x in selected)
        assert cursor==len(f)
        for i,x in enumerate(f):
            assert x['ordinal']==i and re.fullmatch('[0-9a-f]{64}',x['sha256'])
            base=x['contentOffsetBase']; bits=x['contentOffsetBaseBits']
            assert re.fullmatch('[0-9a-f]{16}',bits)
            assert struct.unpack('<d',bytes.fromhex(bits))[0]==base and math.isfinite(base)
            if base!=0: assert struct.pack('<d',base).hex()==bits
        workers=load(p/'workers.json')
        totals=collections.defaultdict(collections.Counter); groups[arm]=[]
        for w in workers:
            assert w['ready']==1 and not w['failures'] and w['terminated'] and w['exitCode']==1
            for asset in w['assets']:
                assert {k:v for k,v in asset.items() if k!='path'}==report['source']['runtimeFiles'][asset['path'][4:]]
            t=totals[w['entry']]
            for key in ['ready','sent','received','compressionRequests','compressionResults','sourceConsumed']: t[key]+=w[key]
            t['workers']+=1
            if w['entry']=='term-bank-wasm-parser-worker.js':
                req=w['parseRequests']; res=w['parseResults']; ids={x['id']:x['rowCount'] for x in res}
                assert len(ids)==len(res)==len(req) and set(ids)=={x['id'] for x in req}
                assert w['sent']==len(req)+1 and w['received']==len(res)+1
                for x in req:
                    assert x['sourceByteLengths']==[b['compressedSize'] for b in x['banks']]
                    assert x['banks'] and all(type(b['signature']) is int and 0<=b['signature']<2**32 for b in x['banks'])
                    groups[arm].append({'banks':x['banks'],'sourceByteLengths':x['sourceByteLengths'],'rows':ids[x['id']]})
                t['parserGroups']+=len(req);t['parserRows']+=sum(ids.values())
            elif w['entry']=='zstd-term-content-compression-worker.js':
                assert w['sent']==w['compressionRequests']==w['compressionResults']==w['sourceConsumed']
                assert w['received']==2*w['sent']+1
            elif w['entry']=='term-record-import-index-worker.js':
                assert w['sent']==sum(w['indexActions'].values()) and w['received']==w['sent']+1
                for key,value in w['indexActions'].items(): t['action:'+key]+=value
            else: raise AssertionError(w['entry'])
        worker_summaries[arm]={k:dict(v) for k,v in totals.items()}
        assert totals['term-bank-wasm-parser-worker.js']['workers']==3
        assert totals['term-bank-wasm-parser-worker.js']['parserGroups']==group_count
        assert totals['term-bank-wasm-parser-worker.js']['parserRows']==rows
        assert totals['zstd-term-content-compression-worker.js']['workers']==4
        banks=[b for x in groups[arm] for b in x['banks']]
        assert sorted(int(b['filename'][10:-5]) for b in banks)==list(range(1,bank_count+1))
        product[arm]=load(p/'product-work-counts.json')
        pc=next(x['details'] for x in product[arm] if x['phase']=='import-data-banks')
        assert pc['fastPathParserFusedAttempts']==group_count and pc['fastPathParserFusedFallbacks']==0
        assert pc['fastPathParserSourceCompressedBytes']==sum(b['compressedSize'] for b in banks)==pc['fastPathParserSourceTransferredBytes']
        assert pc['fastPathParserSourceUncompressedBytes']==sum(b['uncompressedSize'] for b in banks)
        assert all(type(pc[k]) is int and pc[k]>=0 for k in ['fastPathParserSourceCrcScannedBytes','fastPathParserSourceCrcReusedBytes','fastPathParserSourceCrcReusedGlossaryCount'])
        assert pc['fastPathParserParallelWorkerCount']==3 and pc['fastPathParserParallelPipelineGroupsPerWorker'] in [3,4]
        assert {k:pc[k] for k in comparison['parserWorkCounts']}==comparison['parserWorkCounts']
        assert pc['fastPathParserParallelGroupCount']==group_count and pc['fastPathParserParallelSkipReason'] is None
    assert reports['A']['fieldMetrics'] is None
    assert reports['A']['semantic']==reports['B']['semantic'] and reports['A']['flags']==reports['B']['flags']
    assert worker_summaries['A']==worker_summaries['B']
    assert sorted(groups['A'],key=canon)==sorted(groups['B'],key=canon)
    plans=lambda arm:[{k:v for k,v in x.items() if k not in ['before','after','settled','error']} for x in owners[arm]]
    assert plans('A')==plans('B')
    output=lambda arm:[{k:x[k] for k in ['ordinal','ownerOrdinal','rowCount','uniqueCount','contentOffsetBase','contentOffsetBaseBits','bytes','sha256']} for x in fields[arm]]
    assert output('A')==output('B')
    term=lambda arm:sorted([[x['path'],x['bytes'],x['normalizedSha256'],x['normalization']] for x in files[arm] if x['termPayload']])
    assert term('A')==term('B')==comparison['completeTermFiles']
    ar=reports['A']['source']['runtimeFiles'];br=reports['B']['source']['runtimeFiles']
    assert sorted(k for k in set(ar)|set(br) if ar.get(k)!=br.get(k))==DELTA
    f=fields['B'];o=owners['B'];metrics=reports['B']['fieldMetrics'];native=metrics['native']
    sums=collections.Counter();routes=collections.defaultdict(collections.Counter)
    for i,owner in enumerate(o):
        before=owner['before'];after=owner['after']
        if i: assert before==o[i-1]['after']
        ds={k:delta(before,after,k) for k in WORK}
        assert all(type(v) is int and v>=0 for v in ds.values())
        selected=f[owner['fieldStart']:owner['fieldEnd']]
        wa=ds['wholeNativeAttempts'];assert wa in [0,1]
        whole=[x for x in selected if x['wholeAttempt'] and x['wholeAttempt']['succeeded']]
        assert len(whole)==wa and (not whole or len(selected)==1)
        ni=wa*(owner['rowCount']*8+owner['uniqueCount']*12);nt=wa*table(owner['rowCount']);no=0;oc=orr=0
        for x in selected:
            ordinary=delta(x['before'],x['after'],'nativeCalls')
            attempts=delta(x['before'],x['after'],'nativeAttempts')
            w=int(bool(x['wholeAttempt'] and x['wholeAttempt']['succeeded']))
            assert ordinary in [0,1] and attempts==ordinary and ordinary+w==1
            assert delta(x['before'],x['after'],'wholeNativeCalls')==delta(x['before'],x['after'],'wholeNativeAttempts')==0
            assert x['after']['calls']==x['before']['calls']+1 and x['after']['javascriptCalls']==x['before']['javascriptCalls']==0
            assert delta(x['before'],x['after'],'nativeRows')==ordinary*x['rowCount']
            assert delta(x['before'],x['after'],'outputCopiedBytes')==ordinary*x['bytes']
            if w:
                assert x['wholeAttempt']['copied'] and x['wholeAttempt']['contentOffsetBaseBits']==x['contentOffsetBaseBits']
                assert x['wholeAttempt']['contentOffsetBase']==x['contentOffsetBase']
            ni+=attempts*(x['rowCount']*8+x['uniqueCount']*12)
            nt+=attempts*table(x['rowCount']);no+=(ordinary+w)*x['bytes']+8*w
            oc+=ordinary;orr+=ordinary*x['rowCount']
        assert ds['inputCopiedBytes']==ni and ds['tableBytesRequested']==nt and ds['outputCopiedBytes']==no
        assert ds['wholeNativeCalls']==len(whole) and ds['wholeNativeRows']==sum(x['rowCount'] for x in whole)
        assert ds['nativeCalls']==len(whole)+oc and ds['nativeAttempts']==wa+oc and ds['nativeRows']==ds['wholeNativeRows']+orr
        assert after['calls']-before['calls']==len(selected)
        sums.update(ds)
        route=routes[owner['contentDictName']+' / '+('whole' if whole else 'ordinary')]
        route.update(owners=1,fields=len(selected),rows=owner['rowCount'])
    assert o[-1]['after']==metrics
    assert metrics['javascriptCalls']==0 and metrics['calls']==len(f)==native['nativeCalls']
    assert all(sums[k]==native[k] for k in WORK)
    assert all(native[k]=={} for k in ['declines','wholeAdmissionDeclines','wholeCopiedDeclines'])
    assert native['maximumLinearMemoryBytes']==131072+native['memoryGrowthBytes']<=67108864
    assert native['memoryGrowthBytes']%65536==0 and native['maximumScratchBytes']<=native['maximumLinearMemoryBytes']
    assert native['outputCopiedBytes']==sum(x['bytes'] for x in f)+8*native['wholeNativeCalls']
    assert reports['B']['ownerAccounting']=={'passed':True,'ownerCalls':len(o),'fieldCalls':len(f),'nativeActivated':True,'wholeNativeCalls':native['wholeNativeCalls'],'wholeNativeRows':native['wholeNativeRows'],'ordinaryNativeCalls':native['nativeCalls']-native['wholeNativeCalls'],'ordinaryNativeRows':native['nativeRows']-native['wholeNativeRows'],'readinessJavascriptCalls':0,'committedWholeAttemptDeclines':0,'inputCopiedBytes':native['inputCopiedBytes'],'outputCopiedBytes':native['outputCopiedBytes'],'tableBytesRequested':native['tableBytesRequested']}
    assert load(cell/'B/final-store-counts.json')['recordFields']==metrics
    assert next(x['details'] for x in product['B'] if x['phase']=='bulk-finalization')['termRecordFields']==metrics
    workdiff=difference(product['A'],product['B'])
    assert all(x['path'] in ['/1/details/parserParallelPeakQueuedOwnedContentBytes','/2/details/fastPathParserParallelPeakQueuedOwnedContentBytes','/4/details/termContentFlushFinalGroupCount','/4/details/termContentMaxMergedGroupChunkCount','/4/details/termContentMaxWriteBytes','/4/details/termContentMergedWriteCount','/4/details/termContentWriteCallCount','/4/details/termRecordFields'] for x in workdiff)
    summaries[corpus]={'passed':True,'rows':rows,'banks':bank_count,'parserGroups':group_count,'owners':len(o),'fields':len(f),'nativeMetrics':native,'ordinaryNativeCalls':native['nativeCalls']-native['wholeNativeCalls'],'ordinaryNativeRows':native['nativeRows']-native['wholeNativeRows'],'javascriptCalls':0,'readinessFallbacks':0,'routes':{k:dict(v) for k,v in routes.items()},'fieldBytes':sum(x['bytes'] for x in f),'scalarBaseBytes':len(f)*8,'negativeZeroBasesObserved':sum(x['contentOffsetBaseBits']=='0000000000000080' for x in f),'fieldOutputWitnessSha256':sha(canon(output('A')).encode()),'ownerPartitionSha256':sha(canon(plans('A')).encode()),'completeTermFiles':term('A'),'termFileBytesPerArm':sum(x[1] for x in term('A')),'workerTotals':worker_summaries['A'],'parserWorkCounts':comparison['parserWorkCounts'],'sourceGroupsIncludingRowsSha256':sha(canon(sorted(groups['A'],key=canon)).encode()),'allProductCounterDifferences':workdiff,'fullReceiptDifferencesFile':'all-receipt-differences.json'}
(R/'all-receipt-differences.json').write_text(json.dumps(all_diffs,indent=2,ensure_ascii=False)+'\n')
result={'passed':True,'runId':46149981540,'attempt':1,'head':HEAD,'baseline':BASE,'source':load(R/'independent-source-audit.json'),'totalRows':sum(x['rows'] for x in summaries.values()),'corpora':summaries,'scope':'Original receipts and complete artifact bytes only; no product execution, import, timing, or replacement observation','rawSinkLimitation':'Successful raw sinks were retired by the producer after a second full raw hash. This audit verifies both original complete file inventories and their retirement receipts; raw term sinks are not retained in artifacts.'}
(R/'independent-receipt-audit.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'passed':True,'totalRows':result['totalRows'],'corpora':{k:{x:v[x] for x in ['rows','banks','parserGroups','owners','fields','ordinaryNativeCalls','ordinaryNativeRows','fieldBytes','scalarBaseBytes','termFileBytesPerArm','workerTotals','fieldOutputWitnessSha256','ownerPartitionSha256']} for k,v in summaries.items()}},indent=2))
