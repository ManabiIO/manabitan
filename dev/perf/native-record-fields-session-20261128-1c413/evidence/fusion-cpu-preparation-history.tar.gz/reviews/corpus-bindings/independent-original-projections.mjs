import {readFile, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import assert from 'node:assert/strict'
const out = '/tmp/cpu-original-binding-audit-b4ejkhlw'
const original = '/tmp/fusion-original-audit-46149981540-attempt1-hm6zdivl/corpus-full/builds/perf/native-record-fields-fusion-correctness-corpus/acquisition'
const read = async (name) => JSON.parse(await readFile(original + '/' + name, 'utf8'))
const normalize = (v) => Array.isArray(v) ? v.map(normalize) :
    v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map((k) => [k, normalize(v[k])])) : v
const canon = (v) => JSON.stringify(normalize(v))
const hash = (v) => createHash('sha256').update(canon(v)).digest('hex')
const select = (v, keys) => Object.fromEntries(keys.map((k) => [k, v[k]]))
const parserKeys = ['fastPathParserFusedAttempts', 'fastPathParserFusedFallbacks',
    'fastPathParserSourceTransferredBytes', 'fastPathParserSourceCrcScannedBytes',
    'fastPathParserSourceCrcReusedBytes', 'fastPathParserSourceCrcReusedGlossaryCount',
    'fastPathParserSourceCompressedBytes', 'fastPathParserSourceUncompressedBytes',
    'fastPathParserCompactContentMetadataGroups', 'fastPathParserParallelWorkerCount',
    'fastPathParserParallelPipelineGroupsPerWorker', 'fastPathParserParallelGroupCount',
    'fastPathParserParallelSkipReason']
const reference = {schema: 1, kind: 'independent-offline-original-receipt-projection',
    importsExecuted: 0, clockReads: 0, productModulesImported: 0,
    originalRun: 46149981540, originalAttempt: 1,
    originalProducer: 'a9debd150d65c8d11884dadcdf162e7898dea309',
    sourceArchiveBlob: '777b53f1d1cad5eaeeb22965af7e327124d59524',
    sourceArchiveSha256: '52cc6c09c352696ba526eddaa2898b372a985a54b18970a2fe4e832a16ffc96c',
    work: {}, output: {}, workDigests: {}, outputDigests: {}}
for (const arm of ['A', 'B']) {
    const root = 'jmdict/' + arm + '/'
    const [report, ownerReceipt, fields, workers, phases, files] = await Promise.all(
        ['report', 'owner-calls', 'field-calls', 'workers', 'product-work-counts', 'files'].map((name) => read(root + name + '.json')))
    const owners = ownerReceipt.owners
    assert.equal(report.passed, true)
    assert.equal(report.fieldRows, 528299)
    const phase = phases.filter((x) => x.phase === 'import-data-banks')
    assert.equal(phase.length, 1)
    const groups = []
    const workerTotals = {}
    for (const worker of workers) {
        assert.deepEqual(worker.failures, [])
        let total = workerTotals[worker.entry]
        if (!total) total = workerTotals[worker.entry] = {workers: 0, ready: 0, sent: 0, received: 0,
            sourceConsumed: 0, compressionRequests: 0, compressionResults: 0, indexActions: {}, assets: []}
        total.workers += 1
        for (const key of ['ready', 'sent', 'received', 'sourceConsumed', 'compressionRequests', 'compressionResults']) total[key] += worker[key]
        for (const [key, count] of Object.entries(worker.indexActions)) total.indexActions[key] = (total.indexActions[key] || 0) + count
        total.assets.push(...worker.assets.map((asset) => select(asset, ['path', 'bytes'])))
        if (worker.entry !== 'term-bank-wasm-parser-worker.js') continue
        assert.equal(worker.ready, 1)
        const byId = new Map(worker.parseResults.map((x) => [x.id, x.rowCount]))
        assert.equal(byId.size, worker.parseRequests.length)
        assert.equal(byId.size, worker.parseResults.length)
        for (const request of worker.parseRequests) {
            assert.ok(byId.has(request.id))
            groups.push({banks: request.banks, sourceByteLengths: request.sourceByteLengths, rowCount: byId.get(request.id)})
        }
    }
    const order = (x, y) => canon(x).localeCompare(canon(y))
    groups.sort(order)
    for (const row of Object.values(workerTotals)) row.assets.sort(order)
    reference.work[arm] = {
        fieldRows: report.fieldRows, fieldCalls: fields.length, ownerCalls: owners.length,
        parser: select(phase[0].details, parserKeys), groups, workers: workerTotals,
        fieldMetrics: report.fieldMetrics, ownerAccounting: report.ownerAccounting,
        owners: owners.map((x) => select(x, ['ordinal', 'rowCount', 'uniqueCount', 'firstId', 'contentDictName', 'fieldStart', 'fieldEnd', 'before', 'after'])),
        fieldWork: fields.map((x) => ({...select(x, ['ordinal', 'ownerOrdinal', 'rowCount', 'uniqueCount', 'before', 'after']),
            wholeAttempt: x.wholeAttempt === null ? null : select(x.wholeAttempt, ['copied', 'succeeded', 'contentOffsetBaseBits'])}))
    }
    assert.equal(files.length, 3)
    assert.ok(files.every((x) => x.termPayload))
    reference.output[arm] = {
        semantic: report.semantic, flags: report.flags,
        fields: fields.map((x) => select(x, ['ordinal', 'rowCount', 'contentOffsetBase', 'contentOffsetBaseBits', 'bytes', 'sha256'])),
        termFiles: files.map((x) => select(x, ['path', 'bytes', 'normalizedSha256', 'normalization'])).sort((x, y) => x.path.localeCompare(y.path))
    }
    reference.workDigests[arm] = hash(reference.work[arm])
    reference.outputDigests[arm] = hash(reference.output[arm])
}
assert.deepEqual(reference.output.A, reference.output.B)
assert.deepEqual(reference.work.A.parser, reference.work.B.parser)
assert.deepEqual(reference.work.A.groups, reference.work.B.groups)
assert.deepEqual(reference.work.A.workers, reference.work.B.workers)
reference.work.C = structuredClone(reference.work.A)
reference.workDigests.C = hash(reference.work.C)
reference.output.C = structuredClone(reference.output.A)
reference.outputDigests.C = hash(reference.output.C)
reference.CDerivation = 'Exact A reference only; Git-backed control source proof has four unused runtime additions, unchanged stock callers and no baseline references. This is not an observed C import.'
await writeFile(out + '/independent-original-projections.json', JSON.stringify(reference, null, 2) + '\n')
process.stdout.write(JSON.stringify({passed: true, workDigests: reference.workDigests, outputDigests: reference.outputDigests}, null, 2) + '\n')
