from pathlib import Path
import hashlib,json,subprocess,sys,tarfile
root=Path(sys.argv[1])
label=sys.argv[2]
audit=Path('/tmp/fusion-original-audit-46149981540-attempt1-hm6zdivl')
work=Path('/tmp/cpu-original-binding-audit-b4ejkhlw')
repo=Path('/workspace/scratch/1c4137568bc6/manabitan')
base='corpus-full/builds/perf/native-record-fields-fusion-correctness-corpus/acquisition/'
def read(path):return json.loads(path.read_bytes())
def identity(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'gitBlob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()}
def simple(b):return {k:v for k,v in identity(b).items() if k!='gitBlob'}
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def digest(v):return hashlib.sha256(canon(v)).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def gitid(commit,path):return simple(git('show',commit+':'+path))
plan=read(root/'plan.json')
projection=read(root/'references/projection.json')
prep=read(root/'references/preparation.json')
reference_work=read(root/'references/work.json')
reference_output=read(root/'references/output.json')
independent=read(work/'independent-original-projections.json')
control=read(work/'independent-control-source-proof.json')
ledgerbytes=(audit/'git-blob-ledger.json').read_bytes()
assert identity(ledgerbytes)['gitBlob']=='fb018d784e7e5722606f3cb42c3230de2792d550'
ledger=json.loads(ledgerbytes)
assert plan['expectedWork']==reference_work==independent['work']
assert reference_output==independent['output']['A']==independent['output']['B']==independent['output']['C']
assert plan['expectedOutputDigest']==projection['outputDigest']==independent['outputDigests']['A']
assert projection['workDigests']==independent['workDigests']
assert projection['runtimeDigests']==control['preparedRuntimeDigests']
assert projection['originalRun']=='46149981540' and projection['attempt']==1
assert projection['observedProducer']==independent['originalProducer']
assert projection['originalActionsArtifact']=={'id':'15265171488','sha256':'c3923ee6d8a1ddfc06a136ee33f2da18ef64420b9f95498212e3148964218559'}
assert projection['publishedLedgerGitBlob']==identity(ledgerbytes)['gitBlob']
archive=audit/'fusion-original-evidence-46149981540-attempt1.tar.gz'
assert identity(archive.read_bytes())==projection['publishedArchive']
member_checks={}
with tarfile.open(archive,'r:gz') as tar:
 for path,entry in projection['usedOriginalMembers'].items():
  assert entry==ledger['entries'][path]
  b=(audit/path).read_bytes()
  assert identity(b)=={k:entry[k] for k in ['bytes','sha256','gitBlob']}
  member=tar.getmember(path)
  assert member.isfile() and not member.issym() and not member.islnk()
  assert tar.extractfile(member).read()==b
  member_checks[path]=identity(b)
assert len(member_checks)==23
assert prep['reference']==projection
assert prep['nodeVersion']==plan['nodeVersion']=='v22.22.0'
assert prep['fixture']=={'bytes':plan['fixture']['bytes'],'sha256':plan['fixture']['sha256']}
assert prep['workflowBinding']==plan['workflowBinding']
assert prep['runtimePolicy']==plan['runtimePolicy']
assert prep['commonDriverFilesDigest']==digest(plan['commonDriver']['files'])
assert plan['preparationReceipt']['relativePath']=='screen-kit/references/preparation.json'
assert plan['preparationReceipt']['sha256']==identity((root/'references/preparation.json').read_bytes())['sha256']
common_checks={}
for row in plan['commonDriver']['files']:
 assert row['path'].startswith('screen-kit/')
 path=row['path'].removeprefix('screen-kit/')
 assert simple((root/path).read_bytes())=={k:row[k] for k in ['bytes','sha256']}
 common_checks[path]=identity((root/path).read_bytes())
assert identity((root/'workflow/native-whole-import-cpu-screen-1c413.yml').read_bytes())['sha256']==plan['workflowBinding']['sha256']
arm_checks={}
original={}
for arm in ['A','B','C']:
 source_arm='A' if arm=='C' else arm
 observed=read(audit/(base+'prepared-source-'+source_arm+'.json'))
 before=read(audit/(base+'jmdict/'+source_arm+'/source-before.json'))
 after=read(audit/(base+'jmdict/'+source_arm+'/source-after.json'))
 assert before==after
 commit=plan['arms'][arm]['commit']
 tree=git('rev-parse',commit+'^{tree}').decode().strip()
 assert tree==plan['arms'][arm]['tree']
 expected_runtime=read(work/'independent-control-runtime.json') if arm=='C' else observed['runtimeFiles']
 expected={k:observed[k] for k in ['packageJson','packageLock','setupGeneratedLicense']}
 expected.update(commit=commit,tree=tree,runtimeFiles=expected_runtime,preparedRuntimeDigest=digest(expected_runtime),fixtureLock=gitid(commit,'test/perf/dictionaries.lock.json'),nativeManifest=gitid(commit,'dev/data/dictionary-wasm/manifest.json'))
 assert prep['arms'][arm]==expected
 assert expected['preparedRuntimeDigest']==plan['arms'][arm]['preparedRuntimeDigest']==projection['runtimeDigests'][arm]
 for path,key in [('package.json','packageJson'),('package-lock.json','packageLock')]:assert gitid(commit,path)==expected[key]
 assert gitid(commit,'ext/legal-npm.html')==expected['setupGeneratedLicense']['committed']==expected['setupGeneratedLicense']['generated']
 host=read(audit/(base+'jmdict/'+source_arm+'/fixture-and-host.json'))
 assert host['node']==plan['nodeVersion'] and host['fixtureBefore']==prep['fixture']
 assert host['fixture']['termRows']==plan['fixture']['rows']==528299
 assert host['deviceMemoryExposed']==plan['runtimePolicy']['deviceMemoryExposed']==8
 assert host['hardwareConcurrencyExposed']==plan['runtimePolicy']['hardwareConcurrencyExposed']==4
 arm_checks[arm]={'commit':commit,'tree':tree,'runtimeFiles':len(expected_runtime),'preparedRuntimeDigest':expected['preparedRuntimeDigest'],'completePreparedReferenceEqual':True,'originalObservedArm':None if arm=='C' else arm,'derivedFromA':arm=='C'}
A=plan['arms']['A']['commit'];B=plan['arms']['B']['commit'];C=plan['arms']['C']['commit'];P=projection['observedProducer']
assert git('rev-parse',B+':ext')==git('rev-parse',P+':ext')
for p in ['package.json','package-lock.json','test/perf/dictionaries.lock.json','dev/data/dictionary-wasm/manifest.json']:assert gitid(B,p)==gitid(P,p)
assert git('rev-list','--parents','-n','1',C).decode().split()==[C,A]
changed=git('diff','--name-only',A,C).decode().splitlines()
assert sorted(changed)==sorted(projection['C']['completeChangedPaths']) and len(changed)==10
for p in changed:assert gitid(C,p)==gitid(B,p)
for p in projection['C']['stockCallerPaths']:assert git('rev-parse',A+':'+p)==git('rev-parse',C+':'+p)
assert sorted(git('diff','--name-status',A,C,'--','ext').decode().splitlines())==sorted('A\text/'+p for p in projection['C']['unusedRuntime'] if not p.startswith('lib/'))
assert subprocess.run(['git','grep','-n','-e','term-record-fields','-e','term-record-prepared-fields',A,'--','ext'],cwd=repo,capture_output=True).returncode==1
assert projection['C']['observed'] is False and projection['C']['expectedWorkFrom']=='A'
fields=reference_output['fields'];files=reference_output['termFiles']
assert len(fields)==12 and len(files)==3
assert sum(x['rowCount'] for x in fields)==528299
field_bytes=sum(x['bytes'] for x in fields);sink_bytes=sum(x['bytes'] for x in files)
assert field_bytes==4239960 and sink_bytes==43315677
assert plan['storagePolicy']['fieldBufferBytesPerObservation']==field_bytes
assert plan['storagePolicy']['finalSinkBytesPerObservation']==sink_bytes
assert plan['storagePolicy']['observationsPerReplication']==42
assert (field_bytes+sink_bytes)*42==1997336754
assert reference_work['B']['fieldMetrics']['native']['outputCopiedBytes']==field_bytes+8*12
for key in ['parser','groups','workers']:assert reference_work['A'][key]==reference_work['B'][key]
assert sum(g['rowCount'] for g in reference_work['A']['groups'])==528299
assert sum(len(g['banks']) for g in reference_work['A']['groups'])==53
assert len(reference_work['A']['groups'])==12
assert reference_work['B']['ownerAccounting']['ordinaryNativeCalls']==0
assert reference_work['B']['ownerAccounting']['readinessJavascriptCalls']==0
artifacts={p:identity((root/p).read_bytes()) for p in ['plan.json','project-reference.mjs','references/work.json','references/output.json','references/projection.json','references/preparation.json','workflow/native-whole-import-cpu-screen-1c413.yml']}
result={'schema':1,'passed':True,'scope':'Independent offline original JMdict work/output/preparation binding audit; no product import, clock read, sample, dispatch, ref or PR', 'sourceRoot':str(root),'planStatus':plan['status'],'planAcquisitionAuthorized':plan['acquisitionAuthorized'],'originalRun':46149981540,'originalAttempt':1,'originalProducer':P,'artifacts':artifacts,'completeWorkObjectEqualToIndependentProjection':True,'completeOutputObjectEqualToIndependentProjection':True,'workDigests':projection['workDigests'],'outputDigest':projection['outputDigest'],'arms':arm_checks,'BProducerRelabelSourceProof':True,'CExactStockAPlusUnusedBAdditionsProof':True,'CObserved':False,'originalArchive':identity(archive.read_bytes()),'originalLedger':identity(ledgerbytes),'usedOriginalMemberChecks':member_checks,'completeCommonFileChecks':common_checks,'fixture':prep['fixture'],'rows':528299,'banks':53,'groups':12,'fieldBufferBytesPerArm':field_bytes,'completeFinalSinkBytesPerArm':sink_bytes,'retained42ObservationsBytes':(field_bytes+sink_bytes)*42,'copyAccountingFieldBytesPlusEightPerScalarBase':True,'timingObservations':0,'productImports':0,'clockReads':0}
output=work/(label+'-reference-binding-verification.json')
output.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'passed':True,'report':str(output),'identity':identity(output.read_bytes()),'usedOriginalMembers':len(member_checks),'commonFiles':len(common_checks),'workDigests':result['workDigests'],'outputDigest':result['outputDigest'],'planStatus':result['planStatus'],'planAcquisitionAuthorized':result['planAcquisitionAuthorized']},indent=2))
