#!/usr/bin/env python3
"""Independently read every archive payload; never extract links or execute files."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import os
import stat
import sys
import tarfile


def identities(data):
    digest = hashlib.sha256()
    digest.update(data)
    git = hashlib.sha1()
    git.update(("blob " + str(len(data)) + "\0").encode())
    git.update(data)
    return {"bytes": len(data), "sha256": digest.hexdigest(), "gitBlob": git.hexdigest()}


archive_path = Path(sys.argv[1]).resolve()
ledger_path = Path(sys.argv[2]).resolve()
output_path = Path(sys.argv[3]).resolve()
ledger_bytes = ledger_path.read_bytes()
ledger = json.loads(ledger_bytes)
raw_archive = archive_path.read_bytes()
assert identities(raw_archive) == {key: ledger["archive"][key] for key in ("bytes", "sha256", "gitBlob")}
assert raw_archive[:3] == b"\x1f\x8b\x08" and raw_archive[4:8] == b"\0\0\0\0"
verified = {}
manifest = None
with tarfile.open(archive_path, mode="r:gz") as archive:
    for member in archive:
        name = member.name.rstrip("/")
        path = PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts and "." not in path.parts and "\0" not in name
        assert name not in verified and name in ledger["members"]
        expected = ledger["members"][name]
        assert member.uid == member.gid == member.mtime == 0
        assert member.uname == member.gname == ""
        assert member.mode == expected["archiveMode"]
        assert not member.issym() and not member.islnk() and not member.isdev() and not member.isfifo()
        if expected["kind"] == "directory":
            assert member.isdir() and member.size == 0
            verified[name] = {"kind": "directory", "passed": True}
            continue
        assert member.isfile()
        extracted = archive.extractfile(member)
        assert extracted is not None
        data = extracted.read()
        assert len(data) == member.size
        assert identities(data) == {key: expected[key] for key in ("bytes", "sha256", "gitBlob")}
        if name == "ARCHIVE-MEMBERS.json":
            manifest = json.loads(data)
        elif expected["kind"] == "inert-symlink-metadata":
            assert stat.S_ISLNK(Path(expected["source"]).lstat().st_mode)
            assert os.readlink(expected["source"]) == expected["originalTarget"]
            assert json.loads(data)["originalTarget"] == expected["originalTarget"]
        else:
            source = Path(expected["source"])
            assert stat.S_ISREG(source.lstat().st_mode)
            # A fresh source read, independent of the producer's cached bytes.
            assert source.read_bytes() == data
        verified[name] = {"kind": expected["kind"], "passed": True, **identities(data)}
assert set(verified) == set(ledger["members"])
assert manifest is not None
assert manifest["members"] == {name: entry for name, entry in ledger["members"].items() if name != "ARCHIVE-MEMBERS.json"}
for root in manifest["sourceRoots"]:
    source = Path(root["path"])
    expected_sources = {entry["source"] for entry in manifest["members"].values()
                        if entry["source"] is not None and
                        (entry["source"] == str(source) or entry["source"].startswith(str(source) + "/"))}
    actual_sources = {str(source)}
    if stat.S_ISDIR(source.lstat().st_mode):
        for directory, directories, files in os.walk(source, followlinks=False):
            actual_sources.update(str(Path(directory) / item) for item in directories + files)
    assert expected_sources == actual_sources
report = {"schema": 1, "passed": True, "scope": "Independent complete archive-member and current-source readback",
          "archive": ledger["archive"], "memberLedger": identities(ledger_bytes),
          "memberCount": len(verified), "regularMemberCount": sum(item["kind"] != "directory" for item in verified.values()),
          "everyMemberRead": True, "everyOriginalSourceReRead": True, "operationalLinks": 0,
          "frozenSealedCandidateReadOrModified": False, "newDictionaryImports": 0, "clockReaders": 0,
          "performanceExecution": False, "members": verified}
with output_path.open("x") as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write("\n")
print(json.dumps({key: report[key] for key in ("passed", "archive", "memberCount", "regularMemberCount", "everyMemberRead")}, indent=2))
