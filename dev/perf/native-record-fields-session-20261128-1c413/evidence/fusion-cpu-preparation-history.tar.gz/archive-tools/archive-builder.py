#!/usr/bin/env python3
"""Archive existing preparation/review evidence only; no clocks or product work."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import os
import stat
import sys
import tarfile

ROOT = Path(__file__).resolve().parent
SOURCES = (
    ("disabled-draft", Path("/tmp/manabitan-whole-import-screen-draft-20261128-1c413")),
    ("reviews/corpus-bindings", Path("/tmp/cpu-original-binding-audit-b4ejkhlw")),
    ("reviews/harness/final-review.json", Path("/tmp/manabitan-fusion-harness-review-20261128-1c413/final-review.json")),
    ("archive-tools/archive-builder.py", ROOT / "archive-builder.py"),
    ("archive-tools/archive-readback.py", ROOT / "archive-readback.py"),
)


def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "gitBlob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def safe_name(name):
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or any(part in ("", ".", "..") for part in path.parts) or "\0" in name:
        raise ValueError("Unsafe archive member: " + name)
    return path.as_posix()


def collect():
    entries = {}
    payloads = {}

    def add(path, name):
        name = safe_name(name)
        details = path.lstat()
        if stat.S_ISDIR(details.st_mode):
            entries[name] = {"kind": "directory", "archiveMode": 0o755, "source": str(path)}
            for child in sorted(path.iterdir(), key=lambda item: item.name):
                add(child, name + "/" + child.name)
        elif stat.S_ISREG(details.st_mode):
            data = path.read_bytes()
            if len(data) != details.st_size:
                raise ValueError("Source changed while reading: " + str(path))
            entries[name] = {"kind": "regular-file", "archiveMode": 0o644, "source": str(path), **identity(data)}
            payloads[name] = data
        elif stat.S_ISLNK(details.st_mode):
            # Never put an operational link into the archive and never follow it.
            target = os.readlink(path)
            inert_name = safe_name("inert-links/" + name + ".json")
            data = (json.dumps({"originalPath": name, "originalTarget": target,
                                "representation": "inert metadata only; no link created"},
                               indent=2, sort_keys=True) + "\n").encode()
            entries[inert_name] = {"kind": "inert-symlink-metadata", "archiveMode": 0o644,
                                   "source": str(path), "originalTarget": target, **identity(data)}
            payloads[inert_name] = data
        else:
            raise ValueError("Unsupported special file: " + str(path))

    for prefix, path in SOURCES:
        add(path, prefix)
    for name in list(entries):
        for parent in PurePosixPath(name).parents:
            if parent.as_posix() != ".":
                entries.setdefault(parent.as_posix(), {"kind": "directory", "archiveMode": 0o755, "source": None})
    return dict(sorted(entries.items())), payloads


def build(destination):
    entries, payloads = collect()
    manifest = {"schema": 1, "scope": "Entire disabled draft, historical receipts, final harness review, final corpus-binding reviews/proofs, and archive tools",
                "sourceRoots": [{"prefix": prefix, "path": str(path)} for prefix, path in SOURCES],
                "frozenSealedCandidateIncluded": False, "sourceFilesModified": False,
                "operationalLinks": 0, "headerPolicy": {"mtime": 0, "uid": 0, "gid": 0, "uname": "", "gname": "", "gzipMtime": 0},
                "members": entries}
    manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + "\n").encode()
    payloads["ARCHIVE-MEMBERS.json"] = manifest_bytes
    entries_with_manifest = {**entries, "ARCHIVE-MEMBERS.json": {"kind": "regular-file", "archiveMode": 0o644,
                                                                   "source": None, **identity(manifest_bytes)}}
    with destination.open("xb") as stream:
        with gzip.GzipFile(filename="", mode="wb", fileobj=stream, mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name, entry in sorted(entries_with_manifest.items()):
                    header = tarfile.TarInfo(safe_name(name))
                    header.uid = header.gid = header.mtime = 0
                    header.uname = header.gname = ""
                    header.mode = entry["archiveMode"]
                    if entry["kind"] == "directory":
                        header.type = tarfile.DIRTYPE
                        archive.addfile(header)
                    else:
                        data = payloads[name]
                        header.type = tarfile.REGTYPE
                        header.size = len(data)
                        archive.addfile(header, io.BytesIO(data))
    reread, _ = collect()
    if reread != entries:
        raise ValueError("An input changed during archive creation")
    ledger = {"schema": 1, "archive": {"file": destination.name, **identity(destination.read_bytes())},
              "memberCount": len(entries_with_manifest),
              "regularMemberCount": sum(entry["kind"] != "directory" for entry in entries_with_manifest.values()),
              "members": dict(sorted(entries_with_manifest.items())),
              "scope": manifest["scope"], "operationalLinks": 0, "frozenSealedCandidateIncluded": False,
              "newDictionaryImports": 0, "clockReaders": 0, "performanceExecution": False}
    return ledger


if __name__ == "__main__":
    destination = ROOT / sys.argv[1]
    ledger = build(destination)
    ledger_path = ROOT / (sys.argv[1] + ".members.json")
    with ledger_path.open("x") as stream:
        json.dump(ledger, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"archive": ledger["archive"], "memberCount": ledger["memberCount"],
                      "regularMemberCount": ledger["regularMemberCount"], "ledger": ledger_path.name}, indent=2))
