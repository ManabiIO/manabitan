from pathlib import Path
import datetime, gzip, hashlib, json, re, zipfile
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
metadata=json.loads((HERE/'github-metadata.json').read_bytes())
assert metadata['run']['id']==46111017640 and metadata['run']['conclusion']=='success'
assert metadata['run']['run_attempt']==1
assert metadata['run']['head_sha']=='7c4049e37035a20c51822361ef3bfc25f667b366'
assert sha(HERE/'artifact.zip')=='9d075f92fd94b7b5fc7af462bcef783aba342c85380afde349f32f493cba119f'
artifact=metadata['artifacts']['artifacts'][0]
assert artifact['id']==15252561775 and artifact['digest']=='sha256:'+sha(HERE/'artifact.zip')
job=metadata['jobs']['jobs'][0]
assert job['id']==140874338644 and job['conclusion']=='success'
assert all(step['conclusion']=='success' for step in job['steps'])
result=HERE/'artifact/result';m=json.loads((result/'manifest.json').read_bytes())
assert sha(result/'manifest.json')=='b6c209428c2e706cb5da75e9d14ae702b7ac8023c5d1fc1d58b642136c4ae6fd'
assert m['complete'] and m['failures']==[] and m['node']=='v22.22.0'
assert m['baseCommit']=='9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
assert m['candidateCommit']==metadata['run']['head_sha']
pkg=ROOT/'path-copy-hosted';expected=json.loads((pkg/'reference-manifest.json').read_bytes())
assert sha(pkg/'reference-manifest.json')==m['fixtureManifestSha256']=='810c067eabf70271a5440775751420ce065e3bfc1ce2a47bfd2cb61c4876a8a2'
assert sha(pkg/'package-manifest.json')=='5ce3106ea36c0d42ce7c68ada002dc9ff8e39ce7026a6d84dfb9640f09459956'
package=json.loads((pkg/'package-manifest.json').read_bytes())
for f in package['files']:assert sha(pkg/f['path'])==f['sha256']
assert (HERE/'workflow.yml').read_bytes()==(pkg/'workflow.yml').read_bytes()
assert 'node-version: 22.22.0' in (HERE/'workflow.yml').read_text()
logs=gzip.decompress((HERE/'job.log.gz').read_bytes()).decode()
assert 'node: v22.22.0' in logs and 'Image: ubuntu-26.04' in logs
assert 'node --max-old-space-size=1024 dev/perf/path-copy-oracle-7c02/oracle.mjs' in logs
required_hashes={
 'baselineParser':'31854cfb3d20ba60b701ec31cf19de26bd55cc745cc4f998cb33f0554ec83cca',
 'baselineWorker':'47f1d827d94f4c5aac639bf2dceff33f483e969447ca77bd1ae24c1eb014eef1',
 'candidateParser':'69f6f44bb25b1ade2e77ad51a5c830ac359ec3d44f364a3c0ed6131728f54518',
 'candidateWorker':'b368f85dc737f4cd2567fa1723e69f3276f6f8c0441085af3b94ac80ed2a0057',
 'parserWasm':'8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee',
 'fixtureLock':'60aa981791f3b60ca17588212aea5bd3536fb8f59288855e5accd019c6e4cf89'}
assert {k['sha256'] for k in m['sourceInputs']}.issuperset(required_hashes.values())
for f in m['sourceInputs']:
 if '/dev/perf/path-copy-oracle-7c02/' in f['path']:
  local=pkg/Path(f['path']).name;assert sha(local)==f['sha256'] and local.stat().st_size==f['bytes']
assert m['fixture']==expected['fixture']
assert m['fixture']['sha256']=='da5baed5332761513dcef8d0b07ad0d9201cdd7f37831dea37e7162994ec3792'
assert m['fixture']['sizeBytes']==291705969
assert m['rows']==6648310 and m['mediaRows']==146725 and m['fallbackReads']==0
assert len(m['groups'])==len(m['sourceGroups'])==len(expected['groups'])==170
bykey={g['groupKey']:g for g in expected['groups']};assert len(bykey)==170
seen=set();allbanks=[]
for g in m['groups']:
 assert g['groupKey'] not in seen;seen.add(g['groupKey'])
 raw=(result/g['receiptFile']).read_bytes();assert hashlib.sha256(raw).hexdigest()==g['receiptSha256']
 parsed=json.loads(raw);assert parsed=={k:v for k,v in g.items() if k not in ('receiptFile','receiptSha256')}
 ref=bykey[g['groupKey']]
 assert g['files']==ref['files'] and g['sourceRows']==ref['sourceRows']
 assert g['mediaRows']==ref['counts']['mediaRows'] and g['copiedOutputSha256']==ref['copiedOutputSha256']
 assert g['preparedIndexes']==g['preparedRoutes']==1
 for flag in ['complete','projectImagePaths','prepareLookupRoute','sourceShared','sameModulePublicCopyFullAliasParity','frozenBaselineFullValueByteParity','exactFullObjectParity','exactRawSourceAndColumnsUnchanged','nativeHeapAndBufferUnchanged']:assert g[flag] is True,(g['groupKey'],flag)
 assert g['aliasNormalization'] is False and g['shareContentBytes'] is False
 allbanks.extend(g['files'])
assert seen==set(bykey)
assert set(p.name for p in result.glob('group-*.json'))=={g['receiptFile'] for g in m['groups']}
assert len(allbanks)==len(set(allbanks))==665
assert {int(re.fullmatch(r'term_bank_(\d+)\.json',n)[1]) for n in allbanks}==set(range(1,666))
key=lambda g:int(re.search(r'\d+',g['files'][0])[0])
normalize=lambda groups:sorted([{'files':g['files'],'bytes':g['bytes']} for g in groups],key=key)
assert normalize(m['sourceGroups'])==normalize(expected['sourceGroups'])
assert sum(g['sourceRows'] for g in m['groups'])==m['rows']
assert sum(g['mediaRows'] for g in m['groups'])==m['mediaRows']
assert sum(g['rawSourceBytes'] for g in m['groups'])==m['routeAdmission']['rawTermBankSourceBytes']==4267992967
assert m['preparedIndexes']==m['preparedRoutes']==170
assert m['shareContentGroups']==0 and m['privateContentGroups']==170
assert m['exactPlannerGroupsMatch'] and m['sameModulePublicFalseBranchAliasComparison'] and m['independentFrozenBaselineFullValueByteComparison'] and not m['aliasNormalization']
line=next(x for x in (HERE/'artifact/oracle.log').read_text().splitlines() if x.startswith('PATH_COPY_ORACLE_RECEIPT '))
logged=json.loads(line.removeprefix('PATH_COPY_ORACLE_RECEIPT '));assert logged['manifestSha256']==sha(result/'manifest.json')
for k in ['complete','failures','rows','mediaRows','preparedIndexes','preparedRoutes','shareContentGroups','privateContentGroups','baseCommit','candidateCommit','fixtureManifestSha256']:assert logged[k]==m[k]
receipt={'status':'independent-complete-correctness-audit-passed','auditedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'runId':46111017640,'jobId':140874338644,'artifactId':15252561775,'runAttempt':1,'runUrl':metadata['run']['html_url'],
'artifactZipSha256':sha(HERE/'artifact.zip'),'oracleManifestSha256':sha(result/'manifest.json'),'workflowSha256':sha(HERE/'workflow.yml'),
'node':m['node'],'nodeFlags':['--max-old-space-size=1024'],'runnerImage':'ubuntu-26.04/20261122.9','nodeExecutableDigestRecorded':False,
'baseCommit':m['baseCommit'],'candidateResearchCommit':m['candidateCommit'],'runtimeSourceHashes':required_hashes,
'packageManifestSha256':sha(pkg/'package-manifest.json'),'referenceManifestSha256':m['fixtureManifestSha256'],
'counts':{'groups':170,'sourceBanks':665,'rows':m['rows'],'projectedMediaRows':m['mediaRows'],'uniqueMediaPathsInExactReference':expected['uniqueMediaPaths'],'rawTermBankBytes':4267992967,'preparedIndexes':170,'preparedRoutes':170,'fallbackReads':0,'sharedRawWasmGroups':170,'privateCopiedContentGroups':170},
'checks':['GitHub artifact digest and completed first-attempt job verified.','All170 standalone group receipt hashes and contents match aggregate.','All665 source banks covered exactly once; group boundaries and byte sizes equal frozen reference.','Every group projected-path output digest equals original independent capture.','Same-module full object/view/backing alias parity and frozen-baseline full value/byte parity passed without alias normalization.','Every group preserves raw JSON bytes, semantic columns, native heap pointer and memory buffer identity/length.','Exactly one prepared index and production-admitted route per group,170 aggregate.','Reviewed source checks all pinned input/package identities and unchanged baseline/candidate runtime scope before and after completion.'],
'failures':m['failures'],'memory':{'reportedMaxRssKiB':m['maxRssKiB'],'reportedMaxRssMiB':m['maxRssKiB']/1024,'meaning':'process.resourceUsage().maxRSS of this instrumented Node process using persistent worker_threads; includes its process-resident memory. Diagnostic only; no baseline/candidate memory comparison, browser peak or memory improvement claim. The1024MiB V8 old-space setting is not a bound on whole-process RSS or WASM/external memory.'},
'claimLimit':'Complete hosted Node22 correctness evidence for this actual VNDB workload. No timing, full browser import, storage persistence or performance claim. All observed copied content groups used the private-content branch; raw native sources were shared.',
'localPreservation':'Original177505-byte ZIP, exact174 extracted files, compressed full job log, published workflow and metadata. No benchmark or workflow mutation executed.'}
(HERE/'independent-audit.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'auditSha256':sha(HERE/'independent-audit.json'),'groups':170,'rows':m['rows'],'rssMiB':m['maxRssKiB']/1024,'totalLocalBytes':sum(f.stat().st_size for f in HERE.rglob('*') if f.is_file())}))
