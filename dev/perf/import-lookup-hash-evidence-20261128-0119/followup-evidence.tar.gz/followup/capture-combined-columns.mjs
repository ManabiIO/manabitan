import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFile, writeFile} from 'node:fs/promises';
import {resolve, join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {deserialize, serialize} from 'node:v8';
import {replayParserCorpus} from './parser-replay.mjs';

const [rootInput, referenceInput, outputInput] = process.argv.slice(2);
assert(rootInput && referenceInput && outputInput);
const root = resolve(rootInput);
const output = resolve(outputInput);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const localImport = (relative) => import(pathToFileURL(join(root, relative)));
const productCommit = execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim();
assert.equal(productCommit, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
const sourcePaths = ['ext/js/dictionary/dictionary-database.js', 'ext/js/dictionary/term-record-opfs-store.js', 'ext/js/dictionary/term-lookup-index.js', 'ext/js/dictionary/raw-term-content.js'];
const sourceHashes = Object.fromEntries(await Promise.all(sourcePaths.map(async (name) => [name, sha(await readFile(join(root, name)))])));
const referenceBytes = await readFile(referenceInput);
assert.equal(sha(referenceBytes), '2fde77cf160f1d2d45edcc55dc4b728ff92d6df1622e3081df5cbc94f1515712');
const reference = deserialize(referenceBytes);
const {DictionaryDatabase} = await localImport('ext/js/dictionary/dictionary-database.js');
const {RAW_TERM_CONTENT_TOKEN_DICT_NAME} = await localImport('ext/js/dictionary/raw-term-content.js');
const {TermRecordOpfsStore} = await localImport('ext/js/dictionary/term-record-opfs-store.js');
const database = new DictionaryDatabase();
const store = new TermRecordOpfsStore();
database._bulkImportTransactionOpen = true;
database._deferTermsVirtualTableSync = true;
database._termContentStorageMode = 'raw-bytes';
database._tryBeginPersistArtifactTermContent = () => null;
const stored = new Map();
const frames = [];
const dedupMetrics = [];
let nextOffset = 0;
let nextId = 1;
let appendCount = 0;
database._readTermEntryContentBytesDetailedBatch = async (requests) => requests.map(({contentOffset, contentLength}) => {
    const bytes = stored.get(contentOffset);
    assert(bytes && bytes.length === contentLength);
    return {status: 'ok', bytes};
});
database._readTermEntryContentBytesDetailed = async (contentOffset, contentLength) => {
    const bytes = stored.get(contentOffset);
    assert(bytes && bytes.length === contentLength);
    return {status: 'ok', bytes};
};
database._persistArtifactTermContent = async (_title, contents, _names, uniform, spans) => {
    const count = spans === null ? contents.length : spans.lengths.length;
    const pendingOffsets = new Float64Array(count);
    const pendingLengths = new Uint32Array(count);
    for (let i = 0; i < count; ++i) {
        const bytes = spans === null ? contents[i] : spans.buffer.subarray(spans.offsets[i], spans.offsets[i] + spans.lengths[i]);
        const owned = Buffer.from(bytes);
        pendingOffsets[i] = nextOffset;
        pendingLengths[i] = owned.length;
        stored.set(nextOffset, owned);
        nextOffset += Math.max(1, owned.length);
    }
    return {pendingOffsets, pendingLengths, pendingResolvedDictNames: uniform || RAW_TERM_CONTENT_TOKEN_DICT_NAME};
};
store._appendEncodedChunk = async (_state, firstId, count, contentDictName, contentOffsetBase, payload, recordFields, recordFieldsFormat) => {
    const expected = reference.payloads[appendCount];
    assert(expected);
    assert.deepEqual({firstId, count, contentDictName, contentOffsetBase, recordFieldsFormat},
        Object.fromEntries(['firstId', 'count', 'contentDictName', 'contentOffsetBase', 'recordFieldsFormat'].map((key) => [key, expected[key]])));
    assert.equal(Buffer.compare(Buffer.from(payload), expected.payload), 0);
    assert.equal(Buffer.compare(Buffer.from(recordFields), expected.recordFields), 0);
    const encoded = store._createLookupIndexChunk(firstId, count, contentOffsetBase, payload, recordFields, recordFieldsFormat);
    assert.equal(sha(encoded), expected.encodedSha256);
    const frame = frames[appendCount];
    assert.equal(frame.rowCount, count);
    Object.assign(frame, {firstId, contentDictName, contentOffsetBase, recordFieldsFormat,
        payloadSha256: sha(payload), recordFieldsSha256: sha(recordFields), encodedSha256: sha(encoded)});
    ++appendCount;
};
const shape = (value) => ({constructor: value.constructor.name,
    prototypeIsBuiltin: Object.getPrototypeOf(value) === value.constructor.prototype,
    bufferIsPrivate: value.buffer instanceof ArrayBuffer, length: value.length,
    ownsLength: Object.hasOwn(value, 'length'), ownsBuffer: Object.hasOwn(value, 'buffer')});
database._appendResolvedArtifactTermRecords = async (chunk, contentOffsets, contentLengths, resolvedNames) => {
    assert.equal(typeof resolvedNames, 'string');
    const references = chunk.resolvedContentReferences;
    assert(references);
    assert.equal(Object.getPrototypeOf(chunk.scoreList), Int32Array.prototype);
    const frame = {dictionary: chunk.dictionary, rowCount: chunk.rowCount,
        scoreList: Int32Array.from(chunk.scoreList),
        uniqueIndexList: Uint32Array.from(references.uniqueIndexList),
        offsets: Float64Array.from(references.offsets), lengths: Uint32Array.from(references.lengths),
        liveShape: {score: shape(chunk.scoreList),
            references: Object.fromEntries(Object.entries(references).map(([key, value]) => [key, shape(value)]))}};
    frames.push(frame);
    await store._encodeAndAppendArtifactChunkForState({}, chunk, nextId, contentOffsets, contentLengths,
        chunk.termRecordPreinternedPlan, resolvedNames, chunk.preparedLookupIndexes);
    assert.equal(appendCount, frames.length, 'Expected exactly one prepared lookup segment per parser group');
    nextId += chunk.rowCount;
};
const receipt = await replayParserCorpus({root, cacheDir: join(root, 'builds/e2e-dictionary-cache'), dictionary: 'jmdict',
    onChunk: async (chunk, _progress, {fixture}) => {
        chunk.dictionary = fixture.expectedTitle;
        chunk.dictionaryTotalRows = fixture.termRows;
        chunk.uniformContentDictName ??= RAW_TERM_CONTENT_TOKEN_DICT_NAME;
        await database._bulkAddArtifactTermsChunkWithContentDedup(chunk);
        dedupMetrics.push({...database._lastBulkAddTermsMetrics});
    }});
assert.equal(frames.length, reference.payloads.length);
assert.equal(frames.reduce((sum, frame) => sum + frame.rowCount, 0), receipt.rows);
assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim(), productCommit);
for (const [name, expected] of Object.entries(sourceHashes)) { assert.equal(sha(await readFile(join(root, name))), expected); }
const pendingContentCount = dedupMetrics.reduce((sum, metric) => sum + metric.dedupUniqueCount, 0);
const persistedHitCount = dedupMetrics.reduce((sum, metric) => sum + metric.dedupPersistedHitCount, 0);
assert.equal(pendingContentCount, 362032);
assert.equal(persistedHitCount, 3998);
const scope = 'Original live parser score and DB-resolved reference columns copied at the actual resolved-record append hook. Raw-v6 in-memory raw-byte persistence gives sequential synthetic logical offsets, not compressed OPFS offsets. Every full encoded envelope matches the corrected frozen-baseline capture. Private factory origin must be reacquired through each measured source module after deserialization.';
const capture = {scope, productCommit, sourceHashes, referenceSha256: sha(referenceBytes), receipt,
    pendingContentCount, persistedHitCount, decodedContentBytes: nextOffset, dedupMetrics, frames};
const bytes = serialize(capture);
await writeFile(output, bytes, {flag: 'wx'});
const columnNames = ['scoreList', 'uniqueIndexList', 'offsets', 'lengths'];
const summary = {...capture, captureSha256: sha(bytes), captureBytes: bytes.length,
    frames: frames.map((frame) => ({...Object.fromEntries(Object.entries(frame).filter(([key]) => !columnNames.includes(key))),
        columns: Object.fromEntries(columnNames.map((key) => [key, {type: frame[key].constructor.name,
            length: frame[key].length, byteLength: frame[key].byteLength,
            sha256: sha(new Uint8Array(frame[key].buffer, frame[key].byteOffset, frame[key].byteLength))}]))}))};
await writeFile(`${output}.json`, `${JSON.stringify(summary, null, 2)}\n`, {flag: 'wx'});
console.log(JSON.stringify({output, captureBytes: bytes.length, captureSha256: sha(bytes), frames: frames.length,
    rows: receipt.rows, pendingContentCount, persistedHitCount}));
