import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {deserialize} from 'node:v8';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import {performance} from 'node:perf_hooks';
import {setImmediate, setTimeout} from 'node:timers/promises';

const [sourceRoot, input, arm, spacing] = process.argv.slice(2);
assert(['none', 'immediate', '20ms'].includes(spacing));
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const inputBytes = fs.readFileSync(input);
const corpus = deserialize(inputBytes);
const frames = corpus.payloads.map((frame) => ({...frame,
    payload: Uint8Array.from(frame.payload), recordFields: Uint8Array.from(frame.recordFields)}));
const wasm = fs.readFileSync(path.join(sourceRoot, 'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm'));
let fetchCount = 0;
globalThis.fetch = async (url) => {
    assert.match(String(url), /term-content-canonical-scan-v1\.wasm$/);
    ++fetchCount;
    return new Response(wasm, {status: 200});
};
const {TermRecordOpfsStore} = await import(pathToFileURL(path.join(sourceRoot, 'ext/js/dictionary/term-record-opfs-store.js')).href);
const store = new TermRecordOpfsStore();
const started = performance.now();
await store.beginImportSession();
await Reflect.get(store, '_importLookupIndexHasherPromise');
const initialized = performance.now();
const nativeActive = Reflect.get(store, '_importLookupIndexHasher') != null;
assert.equal(nativeActive, arm === 'native');
const outputs = [];
const observations = [];
const waits = [];
for (let i = 0; i < frames.length; ++i) {
    if (i > 0 && spacing !== 'none') {
        const beforeWait = performance.now();
        if (spacing === 'immediate') { await setImmediate(); }
        else { await setTimeout(20); }
        waits.push({beforeFrame: i + 1, actualWaitMs: performance.now() - beforeWait});
    }
    const frame = frames[i];
    const before = performance.now();
    const output = store._createLookupIndexChunk(frame.firstId, frame.count, frame.contentOffsetBase,
        frame.payload, frame.recordFields, frame.recordFieldsFormat);
    const ms = performance.now() - before;
    observations.push({firstId: frame.firstId, rows: frame.count, bytes: output.byteLength, ms});
    outputs.push(output);
}
const encoded = performance.now();
await store.endImportSession();
const completed = performance.now();
assert.equal(Reflect.get(store, '_importLookupIndexHasher') ?? null, null);
for (let i = 0; i < frames.length; ++i) { assert.equal(sha(outputs[i]), frames[i].encodedSha256); }
const setupMs = initialized - started;
const encodeWorkMs = observations.reduce((sum, item) => sum + item.ms, 0);
const finishMs = completed - encoded;
console.log(JSON.stringify({arm, spacing, sourceRoot, node: process.version, v8: process.versions.v8,
    fetchCount, nativeActive, rows: corpus.receipt.rows, frames: frames.length,
    exactCapturedEnvelopeSha256Match: true, sourceSha256: sha(fs.readFileSync(path.join(sourceRoot, 'ext/js/dictionary/term-record-opfs-store.js'))),
    nativeHasherSha256: arm === 'native' ? sha(fs.readFileSync(path.join(sourceRoot, 'ext/js/dictionary/term-lookup-index-hasher.js'))) : null,
    wasmSha256: sha(wasm), inputSha256: sha(inputBytes), setupMs, encodeWorkMs, finishMs,
    totalWorkMs: setupMs + encodeWorkMs + finishMs, totalWallMs: completed - started,
    actualWaitMs: waits.reduce((sum, wait) => sum + wait.actualWaitMs, 0), observations, waits}));
