import json
import os
import sys
import time

name, *command = sys.argv[1:]
started = time.monotonic()
with open(f"builds/research-native-hash/{name}.log", "w") as output:
    child = os.fork()
    if child == 0:
        os.dup2(output.fileno(), 1)
        os.dup2(output.fileno(), 2)
        os.execvp(command[0], command)
    _, status, usage = os.wait4(child, 0)
return_code = os.waitstatus_to_exitcode(status)
metrics = {"command": command, "exitCode": return_code, "wallSeconds": time.monotonic() - started,
           "maxChildRssKiB": usage.ru_maxrss, "userSeconds": usage.ru_utime, "systemSeconds": usage.ru_stime,
           "resourceMethod": "wait4 for this command; no inherited child aggregate"}
with open(f"builds/research-native-hash/{name}.metrics.json", "w") as output:
    json.dump(metrics, output, indent=2)
    output.write("\n")
print(json.dumps(metrics), flush=True)
sys.exit(return_code if return_code >= 0 else 128 - return_code)
