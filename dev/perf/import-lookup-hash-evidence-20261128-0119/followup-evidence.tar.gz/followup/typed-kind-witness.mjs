import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {createImportLookupIndexHasher} from '../../ext/js/dictionary/term-lookup-index-hasher.js';
import {hashTermKeyBytes} from '../../ext/js/dictionary/term-key-hash.js';

const module = await WebAssembly.compile(new Uint8Array(fs.readFileSync(new URL('../../dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm', import.meta.url))));
const hasher = await createImportLookupIndexHasher(async () => module);
const witnesses = [];
for (const [Constructor, length] of [[Uint16Array, 513], [Int8Array, 1025]]) {
    const bytes = Constructor.from({length}, (_, i) => (i * 29 + 173) & 255);
    Object.setPrototypeOf(bytes, Uint8Array.prototype);
    Object.defineProperty(bytes, Symbol.toStringTag, {value: 'Uint8Array'});
    const javascript = hashTermKeyBytes(bytes);
    const native = hasher.hash(bytes);
    witnesses.push({internalKind: Constructor.name, length, byteLength: bytes.byteLength,
        shadowedTag: Object.prototype.toString.call(bytes), javascript, native, equal: javascript === native});
}
console.log(JSON.stringify({node: process.version,
    hasherSourceSha256: createHash('sha256').update(fs.readFileSync(new URL('../../ext/js/dictionary/term-lookup-index-hasher.js', import.meta.url))).digest('hex'),
    witnesses}, null, 2));
