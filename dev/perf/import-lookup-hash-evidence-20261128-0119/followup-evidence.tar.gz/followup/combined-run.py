import hashlib
import json
import pathlib
import statistics
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
node, baseline, score, native, combined, payload_path, columns_path, output_path = sys.argv[1:]
arms = ['baseline', 'score', 'native', 'combined', 'control']
source = {'baseline': baseline, 'score': score, 'native': native, 'combined': combined, 'control': baseline}
expected_hashes = {}


def invoke(arm, mode='timing'):
    command = [node, '--max-old-space-size=384', str(root / 'combined-one.mjs'),
               source[arm], payload_path, columns_path, arm, mode]
    completed = subprocess.run(command, capture_output=True, text=True, check=True)
    result = json.loads(completed.stdout)
    hashes = {key: result[key] for key in ['sourceSha256', 'nativeHasherSha256', 'wasmSha256', 'inputSha256', 'columnsSha256']}
    if arm in expected_hashes:
        assert hashes == expected_hashes[arm], f'Source/input changed during the cohort: {arm}'
    else:
        expected_hashes[arm] = hashes
    result['stderr'] = completed.stderr
    return result


# Diagnostics use separate processes; instrumentation never enters timed runs.
routes = {arm: invoke(arm, 'route') for arm in arms[:-1]}
observations = []
partial_path = pathlib.Path(output_path + '.partial.json')
for block in range(10):
    # Each arm occupies every position twice, in both traversal directions.
    order = arms[block % 5:] + arms[:block % 5]
    if block >= 5:
        order.reverse()
    values = {arm: invoke(arm) for arm in order}
    observations.append({'block': block + 1, 'order': order, 'values': values})
    partial_path.write_text(json.dumps({'routes': routes, 'observations': observations}, indent=2) + '\n')
    print(json.dumps({'completedBlock': block + 1,
                      'coldTotalMs': {arm: values[arm]['cold']['totalMs'] for arm in arms}}), flush=True)


def phase_values(phase):
    return [{arm: o['values'][arm]['cold']['totalMs'] if phase == 'cold' else
             statistics.median(x['totalMs'] for x in o['values'][arm]['warm']) for arm in arms}
            for o in observations]


summaries = {}
for phase in ['cold', 'warm']:
    values = phase_values(phase)
    summaries[phase] = {arm: {
        'medianMs': statistics.median(v[arm] for v in values),
        'pairedMedianPercent': statistics.median(100 * (v[arm] / v['baseline'] - 1) for v in values),
        'equalWorkPercent': 100 * (sum(v[arm] for v in values) / sum(v['baseline'] for v in values) - 1),
        'wins': sum(v[arm] < v['baseline'] for v in values),
    } for arm in arms}
    summaries[phase]['combinedVsSeparate'] = {arm: {
        'pairedMedianPercent': statistics.median(100 * (v['combined'] / v[arm] - 1) for v in values),
        'equalWorkPercent': 100 * (sum(v['combined'] for v in values) / sum(v[arm] for v in values) - 1),
        'wins': sum(v['combined'] < v[arm] for v in values),
    } for arm in ['score', 'native']}

report = {
    'scope': 'Actual production factory -> _encodeArtifactChunkRecords -> _createLookupIndexChunk. Original score and resolved-reference columns; actual prepared lookup bytes and validated matching contentOffsetBase. Includes field encoding/format selection and envelope field validation/hash/allocation/copy, plus begin/end lifecycle. Excludes the outer DB/offset-validation loop, lookup preparation, parser, compression, physical OPFS, restart and browser.',
    'inputScope': 'Corrected raw-v6 full pinned JMdict, live parser/DB capture, sequential synthetic raw logical offsets. All emitted envelopes equal the corrected baseline SHA256 values. Private reference origin is reacquired through each arm\'s own production factory, and separate precise-coverage diagnostics prove all12 score-cache calls for eligible arms.',
    'startupPolicy': 'Fresh Node22 process for every arm, no pre-cold synthetic warmup. Native async initialization is fully awaited and charged, despite production overlap. Every process retains6 warmup cycles and4 warm samples.10 balanced blocks, all outliers and stderr retained; baseline control is identical frozen source.',
    'sourceRoots': source,
    'inputs': {name: {'path': p, 'sha256': hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()}
               for name, p in [('payloads', payload_path), ('columns', columns_path)]},
    'runnerSha256': hashlib.sha256((root / 'combined-one.mjs').read_bytes()).hexdigest(),
    'routes': routes,
    'observations': observations,
    'summaries': summaries,
}
pathlib.Path(output_path).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'output': output_path, 'summaries': summaries}, indent=2))
