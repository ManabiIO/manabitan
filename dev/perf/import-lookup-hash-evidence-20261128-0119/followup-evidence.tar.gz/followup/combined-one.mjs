import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {Session} from 'node:inspector';
import {deserialize} from 'node:v8';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import {performance} from 'node:perf_hooks';

const [sourceRoot, input, columnInput, arm, mode = 'timing'] = process.argv.slice(2);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const inputBytes = fs.readFileSync(input);
const columnBytes = fs.readFileSync(columnInput);
const corpus = deserialize(inputBytes);
const captured = deserialize(columnBytes);
assert.equal(sha(inputBytes), captured.referenceSha256);
assert.equal(captured.pendingContentCount, 362032);
assert.equal(captured.persistedHitCount, 3998);
const frames = corpus.payloads.map((frame, i) => {
    const columns = captured.frames[i];
    assert.equal(columns.firstId, frame.firstId);
    assert.equal(columns.rowCount, frame.count);
    assert.equal(columns.contentOffsetBase, frame.contentOffsetBase);
    assert.equal(columns.encodedSha256, frame.encodedSha256);
    return {...frame, payload: Uint8Array.from(frame.payload), dictionary: columns.dictionary,
        scoreList: Int32Array.from(columns.scoreList), uniqueIndexList: Uint32Array.from(columns.uniqueIndexList),
        offsets: Float64Array.from(columns.offsets), lengths: Uint32Array.from(columns.lengths)};
});
assert.equal(frames.length, 12);
const wasm = fs.readFileSync(path.join(sourceRoot, 'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm'));
let fetchCount = 0;
globalThis.fetch = async (url) => {
    assert.match(String(url), /term-content-canonical-scan-v1\.wasm$/);
    ++fetchCount;
    return new Response(wasm, {status: 200});
};
let session;
const post = (method, params = {}) => new Promise((resolve, reject) => session.post(method, params,
    (error, result) => error ? reject(error) : resolve(result)));
if (mode === 'route') {
    session = new Session();
    session.connect();
    await post('Profiler.enable');
    await post('Profiler.startPreciseCoverage', {callCount: true, detailed: true});
}
const moduleUrl = pathToFileURL(path.join(sourceRoot, 'ext/js/dictionary/term-record-opfs-store.js')).href;
const {TermRecordOpfsStore, createArtifactTermRecordChunkWithResolvedContent} = await import(moduleUrl);
const store = new TermRecordOpfsStore();
const emptyOffsets = new Float64Array(0);
const emptyLengths = new Uint32Array(0);
async function once() {
    const started = performance.now();
    await store.beginImportSession();
    // Charge all native startup; the browser can overlap it with parsing.
    await Reflect.get(store, '_importLookupIndexHasherPromise');
    const initialized = performance.now();
    const nativeActive = Reflect.get(store, '_importLookupIndexHasher') != null;
    assert.equal(nativeActive, arm === 'native' || arm === 'combined');
    const outputs = [];
    const observations = [];
    for (const frame of frames) {
        const before = performance.now();
        // The same source module owns both this factory's private origin and
        // the encoder. Deserialization alone never establishes that proof.
        const chunk = createArtifactTermRecordChunkWithResolvedContent(
            {dictionary: frame.dictionary, rowCount: frame.count, scoreList: frame.scoreList},
            frame.uniqueIndexList, frame.offsets, frame.lengths,
        );
        // The original outer DB/record run already validated this exact base.
        // Lookup preparation is excluded; the actual captured bytes enter the
        // enclosing encoder directly, as in a whole prepared production run.
        const encoded = await store._encodeArtifactChunkRecords(chunk, emptyOffsets, emptyLengths,
            null, frame.payload, frame.contentOffsetBase);
        const fieldsCompleted = performance.now();
        const output = store._createLookupIndexChunk(frame.firstId, frame.count, encoded.contentOffsetBase,
            encoded.lookupIndexBytes, encoded.recordFields, encoded.recordFieldsFormat);
        const completed = performance.now();
        observations.push({firstId: frame.firstId, rows: frame.count, bytes: output.byteLength,
            fieldBytes: encoded.recordFields.byteLength, recordFieldsFormat: encoded.recordFieldsFormat,
            factoryAndEncodeMs: fieldsCompleted - before, envelopeMs: completed - fieldsCompleted,
            totalMs: completed - before, internalValidationMs: encoded.validationMs,
            internalRecordFieldEncodeMs: encoded.recordFieldEncodeMs});
        outputs.push(output);
    }
    const encoded = performance.now();
    await store.endImportSession();
    const completed = performance.now();
    assert.equal(Reflect.get(store, '_importLookupIndexHasher') ?? null, null);
    for (let i = 0; i < frames.length; ++i) {
        assert.equal(sha(outputs[i]), frames[i].encodedSha256);
        assert.equal(observations[i].recordFieldsFormat, frames[i].recordFieldsFormat);
    }
    return {setupMs: initialized - started, encodeMs: encoded - initialized,
        finishMs: completed - encoded, totalMs: completed - started, nativeActive, observations};
}
const cold = await once();
const warmups = [];
const warm = [];
let route = null;
if (mode === 'route') {
    const coverage = await post('Profiler.takePreciseCoverage');
    const found = coverage.result.find((script) => script.url === moduleUrl);
    assert(found);
    const names = ['getSynchronousRecordFieldReferences', 'shouldCacheCompactRecordScores',
        'encodeCachedCompactRecordScores', '_encodeArtifactRecordFields', '_createLookupIndexChunk'];
    const functions = found.functions.filter((fn) => names.includes(fn.functionName));
    const counts = Object.fromEntries(functions.map((fn) => [fn.functionName, fn.ranges[0].count]));
    assert.equal(counts._encodeArtifactRecordFields, 12);
    assert.equal(counts.getSynchronousRecordFieldReferences, 12);
    assert.equal(counts._createLookupIndexChunk, 12);
    if (arm === 'score' || arm === 'combined') {
        assert.equal(counts.shouldCacheCompactRecordScores, 12);
        assert.equal(counts.encodeCachedCompactRecordScores, 12);
    } else {
        assert.equal(counts.encodeCachedCompactRecordScores, undefined);
    }
    route = {counts, functions, scope: 'Separate instrumented diagnostic process; never included in timing cohort.'};
    await post('Profiler.stopPreciseCoverage');
    session.disconnect();
} else {
    for (let i = 0; i < 6; ++i) { warmups.push(await once()); }
    for (let i = 0; i < 4; ++i) { warm.push(await once()); }
}
console.log(JSON.stringify({arm, mode, sourceRoot, node: process.version, v8: process.versions.v8,
    productCommit: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: sourceRoot, encoding: 'utf8'}).trim(),
    fetchCount, rows: corpus.receipt.rows, frames: frames.length, exactCapturedEnvelopeSha256Match: true,
    sourceSha256: sha(fs.readFileSync(path.join(sourceRoot, 'ext/js/dictionary/term-record-opfs-store.js'))),
    nativeHasherSha256: arm === 'native' || arm === 'combined' ? sha(fs.readFileSync(path.join(sourceRoot, 'ext/js/dictionary/term-lookup-index-hasher.js'))) : null,
    wasmSha256: sha(wasm), inputSha256: sha(inputBytes), columnsSha256: sha(columnBytes),
    cold, warmups, warm, route}));
