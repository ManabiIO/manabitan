# Remaining lookup-envelope work review

This is a read-only work-count review of frozen develop `9e10d3b3`, after the native checksum and score-cache interaction screens. It proposes no additional product patch.

## Existing work and overlap

The actual JMdict capture has 12 prepared lookup envelopes and 528,299 rows. The writer hashes 23,748,240 bytes: 12,368,656 base bytes, 7,139,624 derived bytes, and 4,239,960 record-field bytes. Payload wrappers add another 192 bytes to the concatenated payloads. This is production-derived component input with synthetic raw logical offsets, not physical OPFS output.

| Possible removal | Actual remaining work | Decision |
| --- | --- | --- |
| Duplicate compact-field header parsing | `_createLookupIndexChunk` checks field dimensions, then `validateRecordFields` / `parseCompactRecordFields` checks them again. Removing the duplicate would save 12 small fixed-size header parses per full JMdict import, not a row pass. | Too little demonstrated work to justify another candidate. Preserve validation/error order. |
| Score-key bounds validation | One current-key bounds check per compact row remains before publication. | Exact indexed-loop replacement was already reviewed in [#944](https://github.com/ManabiIO/manabitan/pull/944). Its merge contains the indexed loop, while the frozen current file again has the iterator loop. This is prior work, not a new optimization. |
| Repeated safe-offset validation in the envelope | `validateRecordFields` already returns before scanning offsets when the base is at most `MAX_SAFE_INTEGER - MAX_CONTENT_OFFSET_DELTA`. All captured JMdict bases take that path. | There is no second full offset scan to remove for these inputs. Unusual large bases still need the existing validation. |
| Current-byte integrity hashes | Three existing XXH32 hashes cover the actual bytes immediately before the envelope is assembled. The current JS large-buffer path already uses DataView word reads from [#627](https://github.com/ManabiIO/manabitan/pull/627). | The active native experiment covers this opportunity. Warm scalar/SIMD regressions and the richer-boundary regressions remain material. [#770](https://github.com/ManabiIO/manabitan/pull/770) is also prior checksum work. |
| Envelope concatenation | One allocation and two `set` operations per frame copy the payload and fields into an owned contiguous buffer, about 23.75 MB across JMdict. | The synchronous lookup writer already receives these complete chunks directly; the descriptor `_mergeChunks` path is not another lookup-sidecar copy. Avoid claiming a nonexistent extra merge. Replacing contiguous owned chunks with retained input segments would require a different asynchronous ownership/transfer/write protocol, with no demonstrated benefit here. |
| Cache previously validated fields | Record encoding is followed by awaited calls, including `_appendEncodedChunk`'s shard-format validation, before the current-byte envelope is created. | A stale proof across those awaits would weaken the existing contract. Do not add a WeakMap validation bypass or trust a precomputed worker checksum. |

The previously held [#817](https://github.com/ManabiIO/manabitan/pull/817) is the braided source-CRC i64-to-i32 rewrite, not an envelope change. Its static instruction reduction did not establish a repeatable material complete-import gain.

## Upper bound and stopping decision

The only clearly redundant, unclaimed work found here is a fixed 12 extra header parses. All larger row/byte passes are either already covered by prior/current experiments or establish current data integrity and ownership. The warm JS checksum kernel itself processes the full captured hash input in about 4.46 ms; the broader writer measurements cannot be converted into a clean additive wall-time budget, as the combined experiment shows. No new material work-removal opportunity is established, so no further envelope implementation or benchmark is proposed.

The source-history query used to locate the overwritten #944 loop triggered a partial-clone promisor fetch and failed with disk exhaustion. It remained pending during the first paced diagnostic. That activity and its unknown per-observation impact are retained in `history-fetch-failure.txt`; no observation is discarded and the paced results qualify neither direction. The combined component cohort completed before that history query.
