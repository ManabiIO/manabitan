/* Copyright (C) 2026 Manabitan authors; SPDX-License-Identifier: GPL-3.0-or-later */
// Reconstructed after the executor reset. Persistent research harness, not product code.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream, openAsBlob} from 'node:fs';
import {readFile, writeFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {pathToFileURL, fileURLToPath} from 'node:url';
import {Worker as ThreadWorker} from 'node:worker_threads';

const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
const localImport = (root, relative) => import(pathToFileURL(join(root, relative)));
const sourcePaths = [
    'ext/js/dictionary/dictionary-importer.js',
    'ext/js/dictionary/dense-zip-directory.js',
    'ext/js/dictionary/dense-zip-file-map.js',
    'ext/js/dictionary/term-bank-wasm-parser.js',
    'ext/js/dictionary/term-bank-wasm-parser-worker.js',
    'ext/js/dictionary/term-bank-experiments.js',
    'ext/js/dictionary/term-bank-source-pipeline.js',
    'ext/js/dictionary/term-content-ownership.js',
    'ext/js/dictionary/term-lookup-index-preparation.js',
    'ext/js/dictionary/term-lookup-index.js',
    'ext/js/dictionary/term-record-preinterned-plan.js',
    'ext/js/dictionary/wasm/term-bank-parser.c',
    'ext/js/dictionary/wasm/term-bank-inflate.c',
    'ext/lib/term-bank-parser.wasm',
    'dev/data/dictionary-wasm/manifest.json',
    'test/fixtures/parser-settlement/worker-node.mjs',
];

// Explicit owned serialization is the caller's responsibility inside onChunk.
// Native/worker leases end when the awaited callback returns.
export async function replayParserCorpus({
    root, cacheDir, dictionary = 'jmdict', hardwareConcurrency = 4,
    deviceMemory = 8, onChunk = () => {}, experiments = {},
}) {
    root = resolve(root);
    cacheDir = resolve(cacheDir);
    const parser = await localImport(root, 'ext/js/dictionary/term-bank-wasm-parser.js');
    const {DictionaryImporter} = await localImport(root, 'ext/js/dictionary/dictionary-importer.js');
    const {RawZipPayloadReader, TermBankSourcePipeline} = await localImport(root, 'ext/js/dictionary/term-bank-source-pipeline.js');
    const {snapshotTermBankExperiments} = await localImport(root, 'ext/js/dictionary/term-bank-experiments.js');
    const {MIN_EXACT_LOOKUP_SOURCE_BYTES} = await localImport(root, 'ext/js/dictionary/term-lookup-route.js');
    const {loadDictionaryWasm} = await localImport(root, 'dev/dictionary-wasm.js');
    const {getHostEnvironment} = await localImport(root, 'dev/perf/host-environment.js');
    const {Uint8ArrayWriter} = await localImport(root, 'node_modules/@zip.js/zip.js/index.js');
    const lockBytes = await readFile(join(root, 'test/perf/dictionaries.lock.json'));
    const fixture = JSON.parse(lockBytes).dictionaries[dictionary];
    assert(fixture, `Missing fixture: ${dictionary}`);
    const archivePath = join(cacheDir, fixture.cacheFile);
    const archiveDigest = createHash('sha256');
    for await (const bytes of createReadStream(archivePath)) { archiveDigest.update(bytes); }
    assert.equal(archiveDigest.digest('hex'), fixture.sha256);
    const archive = await openAsBlob(archivePath);
    assert.equal(archive.size, fixture.sizeBytes);
    const native = loadDictionaryWasm(root).get('term-bank-parser.wasm');
    assert(native);
    assert.deepEqual(native, await readFile(join(root, 'ext/lib/term-bank-parser.wasm')));
    parser.setTermBankWasmModule(await WebAssembly.compile(native));
    const sourceHashes = Object.fromEntries(await Promise.all(sourcePaths.map(async (name) => [name, sha256(await readFile(join(root, name)))])));
    const runnerSha256 = sha256(await readFile(fileURLToPath(import.meta.url)));
    const oldWorker = Object.getOwnPropertyDescriptor(globalThis, 'Worker');
    const oldNavigator = Object.getOwnPropertyDescriptor(globalThis, 'navigator');
    const terminations = [];
    const sourceGroups = [];
    let workersCreated = 0;
    class BrowserWorker extends EventTarget {
        constructor(url) {
            super();
            this.index = workersCreated++;
            this.worker = new ThreadWorker(pathToFileURL(join(root, 'test/fixtures/parser-settlement/worker-node.mjs')), {workerData: {url: url.href}});
            this.worker.on('message', (data) => this.dispatchEvent(new MessageEvent('message', {data})));
            this.worker.on('error', (error) => {
                const event = new Event('error');
                Object.defineProperty(event, 'message', {value: error.message});
                this.dispatchEvent(event);
            });
            this.worker.on('messageerror', () => this.dispatchEvent(new MessageEvent('messageerror')));
        }
        postMessage(data, transfer) {
            if (data.type === 'parse') {
                sourceGroups.push({worker: this.index, id: data.id,
                    files: data.sourceMetadata?.map(({filename}) => filename) ?? null,
                    compressedBytes: data.sourceBuffers.reduce((sum, buffer) => sum + buffer.byteLength, 0)});
            }
            this.worker.postMessage(data, transfer);
        }
        terminate() { terminations.push(this.worker.terminate()); }
    }
    Object.defineProperty(globalThis, 'Worker', {configurable: true, value: BrowserWorker});
    Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency, deviceMemory}});
    let zipReader;
    let sourcePipeline;
    const groups = [];
    const profiles = [];
    const plans = [];
    let rows = 0;
    let callbackMs = 0;
    try {
        // Use the production catalog, including its lazy getData closure for
        // DenseZipFileMap. Metadata-only readDenseZipDirectory lacks getData
        // and cannot be used as a TermBankSourcePipeline input for VNDB.
        const importer = new DictionaryImporter(null);
        const catalog = await importer._getFilesFromArchive(archive);
        zipReader = catalog.zipReader;
        const termFiles = [...catalog.fileMap.keys()]
            .filter((name) => /^term_bank_\d+\.json$/.test(name))
            .sort((a, b) => Number(a.slice(10, -5)) - Number(b.slice(10, -5)))
            .map((name) => catalog.fileMap.get(name));
        assert(termFiles.length > 0);
        const sourceBytes = termFiles.reduce((sum, file) => sum + file.uncompressedSize, 0);
        const rawReader = new RawZipPayloadReader(archive);
        sourcePipeline = new TermBankSourcePipeline({
            termFiles, enabled: true,
            read: async (file, signal) => await file.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true, signal}),
            readCompressed: async (file, signal) => await rawReader.read(file, signal),
        });
        const media = fixture.mediaFiles > 0;
        const options = {
            ...snapshotTermBankExperiments(experiments),
            copyContentBytes: false, includeContentMetadata: true,
            initialContentBytesPerRow: 48, minimalDecode: true,
            reuseExpressionForReadingDecode: true, preallocateChunkRows: true,
            skipTagRuleDecode: media, lazyGlossaryDecode: true,
            mediaHintFastScan: media,
            projectImagePaths: media && sourceBytes >= 1024 * 1024 * 1024,
            validateGlossaryTypes: true, computeContentHashes: true,
            emitContentSlab: true, emitTokenBinaryContent: true,
            emitTermByteLists: false, prepareLookupIndexes: true,
            prepareLookupRoute: sourceBytes >= MIN_EXACT_LOOKUP_SOURCE_BYTES,
            maxPendingChunks: 2,
        };
        await parser.prewarmParallelTermBankParser(options);
        const hostBefore = getHostEnvironment();
        const started = performance.now();
        const consume = async (chunk, progress) => {
            const groupIndex = groups.length;
            groups.push({rowCount: chunk.rowCount, contentBytesLength: chunk.contentBytesLength ?? 0,
                uniqueCount: chunk.contentDedupPlan?.uniqueCount ?? null,
                lookupSegments: chunk.preparedLookupIndexes?.size ?? 0, mediaRows: chunk.mediaRows?.length ?? 0});
            const callbackStart = performance.now();
            await onChunk(chunk, progress, {fixture, groupIndex, options});
            callbackMs += performance.now() - callbackStart;
            rows += chunk.rowCount;
        };
        for (let start = 0; start < termFiles.length;) {
            const compressed = sourcePipeline.createCompressedImportRunPlan(start);
            const uncompressed = compressed === null ? sourcePipeline.createImportRunPlan(start) : null;
            const plan = compressed ?? uncompressed;
            let files;
            if (plan !== null) {
                files = plan.files;
                const parse = compressed !== null ? parser.parseTermBankWithWasmColumnChunksParallelCompressedLazy : parser.parseTermBankWithWasmColumnChunksParallelLazy;
                assert.equal(await parse(plan.loaders, plan.estimatedByteLengths, 3, consume, options), true);
                plans.push({kind: compressed !== null ? 'compressed-lazy' : 'uncompressed-lazy', files: files.length});
            } else {
                files = sourcePipeline.getBatch(start);
                let batch = await sourcePipeline.readBatch(files);
                if (batch === null) {
                    files = [termFiles[start]];
                    batch = await sourcePipeline.read(files[0]);
                }
                sourcePipeline.prefetchNext(start + files.length);
                let parallel = false;
                let bytes = batch;
                if (batch?.promises) {
                    parallel = await parser.parseTermBankWithWasmColumnChunksParallelDeferred(batch.promises, batch.estimatedByteLengths, 3, consume, options);
                    if (!parallel) { bytes = await batch.readAll(); }
                } else if (Array.isArray(batch)) {
                    parallel = await parser.parseTermBankWithWasmColumnChunksParallel(batch, 3, consume, options);
                }
                const overlap = !parallel && !media && Array.isArray(bytes) ?
                    await parser.parseTermBankWithWasmColumnChunksOverlapped(bytes, 3, consume, options) : false;
                if (!parallel && !overlap) {
                    await parser.parseTermBankWithWasmColumnChunks(bytes, 3, consume, files.length > 1 ? 262144 : 12000, options);
                }
                plans.push({kind: parallel ? 'batch-parallel' : overlap ? 'batch-overlapped' : 'batch-serial', files: files.length});
            }
            profiles.push(parser.consumeLastTermBankWasmParseProfile());
            sourcePipeline.releaseBatch(files);
            start += files.length;
        }
        const componentWallMs = performance.now() - started;
        const hostAfter = getHostEnvironment();
        assert.equal(rows, fixture.termRows);
        for (const [name, expected] of Object.entries(sourceHashes)) { assert.equal(sha256(await readFile(join(root, name))), expected, `Changed during replay: ${name}`); }
        return {complete: true, harnessRevision: 'reconstructed-v2-production-catalog', dictionary, fixture, root,
            node: process.version, v8: process.versions.v8, authoritativeWholeImportTiming: false,
            boundary: 'Actual production catalog, source planner and native worker pipeline after prewarm through leased chunk callbacks. File-backed Blob reads; no browser UI, compression, OPFS or restart unless supplied by callback.',
            hardwareConcurrency, deviceMemory, options, workersCreated, rows, sourceBytes,
            sourceBanks: termFiles.length, catalog: catalog.catalog, componentWallMs, callbackMs,
            plans, profiles, groups, sourceGroups, sourceHashes, runnerSha256,
            lockSha256: sha256(lockBytes), hostBefore, hostAfter};
    } finally {
        await sourcePipeline?.dispose();
        await parser.disposeParallelTermBankParser();
        await Promise.all(terminations);
        await zipReader?.close();
        if (oldWorker) { Object.defineProperty(globalThis, 'Worker', oldWorker); } else { delete globalThis.Worker; }
        if (oldNavigator) { Object.defineProperty(globalThis, 'navigator', oldNavigator); } else { delete globalThis.navigator; }
    }
}

export function digestParserChunk(hash, chunk) {
    for (const name of ['scoreList', 'sequenceList', 'readingEqualsExpressionList', 'contentHash1List', 'contentHash2List', 'contentMetaList', 'contentUniqueIndexList']) {
        const value = chunk[name];
        hash.update(`${name}\0`);
        if (ArrayBuffer.isView(value)) { hash.update(Buffer.from(value.buffer, value.byteOffset, value.byteLength)); }
    }
    if (chunk.contentBytesBuffer) {
        const start = chunk.contentBytesBaseOffset ?? 0;
        const length = chunk.contentBytesLength ?? chunk.contentBytesBuffer.byteLength;
        hash.update(chunk.contentBytesBuffer.subarray(start, start + length));
    }
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
    const [root, cacheDir, dictionary, output, mode = 'timing', cpus = '4', memory = '8'] = process.argv.slice(2);
    assert(root && cacheDir && dictionary && output);
    assert(['timing', 'verify'].includes(mode), 'Reconstructed runner supports timing/verify; earlier CPU profiles remain retained');
    const hash = createHash('sha256');
    const report = await replayParserCorpus({root, cacheDir, dictionary, hardwareConcurrency: Number(cpus), deviceMemory: Number(memory), onChunk: mode === 'verify' ? (chunk) => digestParserChunk(hash, chunk) : undefined});
    report.mode = mode;
    if (mode === 'verify') { report.chunkDigestSha256 = hash.digest('hex'); }
    await writeFile(output, `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'});
    console.log(JSON.stringify({output, complete: report.complete, rows: report.rows, componentWallMs: report.componentWallMs, workers: report.workersCreated, catalog: report.catalog}));
}
