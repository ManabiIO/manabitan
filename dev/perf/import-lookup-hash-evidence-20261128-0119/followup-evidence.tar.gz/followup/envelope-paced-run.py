import hashlib
import json
import pathlib
import statistics
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
node, baseline, native, input_path, output_path = sys.argv[1:]
arms = ['baseline', 'native', 'control']
spacings = ['none', 'immediate', '20ms']
expected_hashes = {}
observations = []
for block in range(12):
    spacing_order = spacings[block % 3:] + spacings[:block % 3]
    if (block // 3) % 2:
        spacing_order.reverse()
    arm_order = arms[block % 3:] + arms[:block % 3]
    if (block // 3) % 2:
        arm_order.reverse()
    by_spacing = {}
    for spacing in spacing_order:
        values = {}
        for arm in arm_order:
            command = [node, '--max-old-space-size=384', str(root / 'envelope-paced-one.mjs'),
                       native if arm == 'native' else baseline, input_path, arm, spacing]
            completed = subprocess.run(command, capture_output=True, text=True, check=True)
            value = json.loads(completed.stdout)
            value['stderr'] = completed.stderr
            hashes = {key: value[key] for key in ['sourceSha256', 'nativeHasherSha256', 'wasmSha256', 'inputSha256']}
            if arm in expected_hashes:
                assert hashes == expected_hashes[arm]
            else:
                expected_hashes[arm] = hashes
            values[arm] = value
        by_spacing[spacing] = {'order': arm_order, 'values': values}
    observations.append({'block': block + 1, 'spacingOrder': spacing_order, 'bySpacing': by_spacing})
    pathlib.Path(output_path + '.partial.json').write_text(json.dumps(observations, indent=2) + '\n')
    print(json.dumps({'completedBlock': block + 1, 'workMs': {spacing: {arm: by_spacing[spacing]['values'][arm]['totalWorkMs'] for arm in arms} for spacing in spacings}}), flush=True)
summaries = {}
for spacing in spacings:
    summaries[spacing] = {}
    for field in ['totalWorkMs', 'encodeWorkMs', 'setupMs', 'totalWallMs', 'actualWaitMs']:
        values = [{arm: o['bySpacing'][spacing]['values'][arm][field] for arm in arms} for o in observations]
        summaries[spacing][field] = {arm: {
            'medianMs': statistics.median(v[arm] for v in values),
            'pairedMedianPercent': statistics.median(100 * (v[arm] / v['baseline'] - 1) for v in values) if sum(v['baseline'] for v in values) else None,
            'equalWorkPercent': 100 * (sum(v[arm] for v in values) / sum(v['baseline'] for v in values) - 1) if sum(v['baseline'] for v in values) else None,
            'wins': sum(v[arm] < v['baseline'] for v in values),
        } for arm in arms}
report = {
    'scope': 'Fresh-process spacing sensitivity diagnostic of the actual enclosing lookup writer only. Already encoded actual record fields enter _createLookupIndexChunk. This is not a score-cache screen or browser qualification.',
    'spacingPolicy': 'Prospectively fixed no-yield, one setImmediate, or20ms timer between successive frames; first frame follows setup immediately. Timing sums synchronous envelope work plus begin/native-setup/end; all actual waits and total wall time are separately retained and excluded from work. Native setup is fully charged; no synthetic pre-cold warmup or warm observations.',
    'inputScope': 'Corrected raw-v6 full JMdict capture; synthetic raw logical offsets. Every envelope exactly matches the baseline reference SHA256.12 balanced blocks per spacing, fresh Node22 process per arm, identical baseline controls, no omitted observations.',
    'input': {'path': input_path, 'sha256': hashlib.sha256(pathlib.Path(input_path).read_bytes()).hexdigest()},
    'baseline': baseline, 'native': native,
    'runnerSha256': hashlib.sha256((root / 'envelope-paced-one.mjs').read_bytes()).hexdigest(),
    'observations': observations, 'summaries': summaries,
}
pathlib.Path(output_path).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'output': output_path, 'summaries': {spacing: summaries[spacing]['totalWorkMs'] for spacing in spacings}}, indent=2))
