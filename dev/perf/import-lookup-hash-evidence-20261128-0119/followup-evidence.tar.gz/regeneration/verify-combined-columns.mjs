import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {deserialize} from 'node:v8';

const [captureInput, manifestInput] = process.argv.slice(2);
const capture = deserialize(await readFile(captureInput));
const expected = JSON.parse(await readFile(manifestInput, 'utf8'));
assert.equal(capture.productCommit, expected.productCommit);
assert.deepEqual(capture.sourceHashes, expected.sourceHashes);
assert.equal(capture.pendingContentCount, 362032);
assert.equal(capture.persistedHitCount, 3998);
assert.equal(capture.receipt.rows, expected.receipt.rows);
assert.equal(capture.frames.length, expected.frames.length);
for (let i = 0; i < capture.frames.length; ++i) {
    const frame = capture.frames[i];
    const reference = expected.frames[i];
    for (const key of ['dictionary', 'rowCount', 'firstId', 'contentDictName', 'contentOffsetBase',
        'recordFieldsFormat', 'payloadSha256', 'recordFieldsSha256', 'encodedSha256']) {
        assert.equal(frame[key], reference[key], `Frame${i + 1} ${key}`);
    }
    for (const [name, column] of Object.entries(reference.columns)) {
        const view = frame[name];
        assert.equal(view.constructor.name, column.type);
        assert.equal(view.length, column.length);
        assert.equal(view.byteLength, column.byteLength);
        const bytes = new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
        assert.equal(createHash('sha256').update(bytes).digest('hex'), column.sha256,
            `Frame${i + 1} ${name} byte digest`);
    }
}
console.log(JSON.stringify({verifiedFrames: capture.frames.length, verifiedRows: capture.receipt.rows,
    note: 'All acquired column and envelope digests match; container metadata is allowed to differ.'}));
