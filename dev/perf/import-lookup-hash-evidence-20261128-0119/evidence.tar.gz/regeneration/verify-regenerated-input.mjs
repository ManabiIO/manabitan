import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {deserialize} from 'node:v8';

const [input, receiptPath] = process.argv.slice(2);
const capture = deserialize(fs.readFileSync(input));
const receipt = JSON.parse(fs.readFileSync(receiptPath, 'utf8'));
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
assert.equal(capture.receipt.rows, receipt.receipt.rows);
assert.equal(capture.receipt.fixture.sha256, receipt.receipt.fixture.sha256);
assert.equal(capture.pendingContentCount, receipt.pendingContentCount);
assert.equal(capture.persistedHitCount, receipt.persistedHitCount);
assert.equal(capture.payloads.length, receipt.frames.length);
for (let i = 0; i < capture.payloads.length; ++i) {
    const frame = capture.payloads[i], expected = receipt.frames[i];
    for (const key of ['firstId', 'count', 'contentOffsetBase', 'recordFieldsFormat', 'baseBytes', 'derivedBytes', 'encodedByteLength', 'encodedSha256']) {
        assert.equal(frame[key], expected[key], `frame ${i} ${key}`);
    }
    assert.deepEqual(frame.checksums, expected.checksums);
    assert.equal(sha256(frame.payload), expected.payloadSha256);
    assert.equal(sha256(frame.recordFields), expected.recordFieldsSha256);
}
console.log(JSON.stringify({verified: true, frames: capture.payloads.length, rows: capture.receipt.rows,
    note: 'Every acquired lookup/record/envelope byte digest matches; whole V8 container metadata can differ across regeneration.'}));
