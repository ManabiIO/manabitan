#include <stdint.h>
#ifdef HASH_USE_SIMD
#include <wasm_simd128.h>
#endif

#define DATA_OFFSET 131072u
#define STATE_OFFSET (DATA_OFFSET - 32u)
#define SEED 0x811c9dc5u
#define PRIME1 0x9e3779b1u
#define PRIME2 0x85ebca77u
#define PRIME3 0xc2b2ae3du
#define PRIME4 0x27d4eb2fu
#define PRIME5 0x165667b1u

static uint32_t read_u32(const uint8_t *p) {
    return (uint32_t)p[0] | (uint32_t)p[1] << 8u |
           (uint32_t)p[2] << 16u | (uint32_t)p[3] << 24u;
}

static uint32_t rotate(uint32_t value, uint32_t amount) {
    return (value << amount) | (value >> (32u - amount));
}

static uint32_t round_word(uint32_t accumulator, uint32_t value) {
    return rotate(accumulator + value * PRIME2, 13u) * PRIME1;
}

#ifdef HASH_USE_SIMD
static v128_t simd_stripes(const uint8_t *source, uint32_t length, v128_t accumulator) {
    const v128_t p1 = wasm_i32x4_splat(PRIME1), p2 = wasm_i32x4_splat(PRIME2);
    for (uint32_t cursor = 0; cursor < length; cursor += 16u) {
        accumulator = wasm_i32x4_add(accumulator, wasm_i32x4_mul(wasm_v128_load(source + cursor), p2));
        accumulator = wasm_v128_or(wasm_i32x4_shl(accumulator, 13u), wasm_u32x4_shr(accumulator, 19u));
        accumulator = wasm_i32x4_mul(accumulator, p1);
    }
    return accumulator;
}
#endif

static void require_source(uint32_t length) {
    const uint64_t end = (uint64_t)DATA_OFFSET + length;
    if (end > (uint64_t)__builtin_wasm_memory_size(0) * 65536u) {
        __builtin_trap();
    }
}

static uint32_t avalanche(uint32_t hash) {
    hash ^= hash >> 15u;
    hash *= PRIME2;
    hash ^= hash >> 13u;
    hash *= PRIME3;
    hash ^= hash >> 16u;
    return hash;
}

static uint32_t tail(uint32_t hash, const uint8_t *source, uint32_t length) {
    uint32_t cursor = 0;
    while (cursor + 4u <= length) {
        hash = rotate(hash + read_u32(source + cursor) * PRIME3, 17u) * PRIME4;
        cursor += 4u;
    }
    while (cursor < length) {
        hash = rotate(hash + source[cursor] * PRIME5, 11u) * PRIME1;
        ++cursor;
    }
    return avalanche(hash);
}

__attribute__((export_name("hash_lookup_bytes")))
uint32_t hash_lookup_bytes(uint32_t length) {
    require_source(length);
    const uint8_t *source = (const uint8_t *)(uintptr_t)DATA_OFFSET;
    uint32_t cursor = 0, hash;
    if (length >= 16u) {
        uint32_t v1 = SEED + PRIME1 + PRIME2;
        uint32_t v2 = SEED + PRIME2;
        uint32_t v3 = SEED;
        uint32_t v4 = SEED - PRIME1;
#ifdef HASH_USE_SIMD
        cursor = length & ~15u;
        const v128_t accumulators = simd_stripes(source, cursor, wasm_i32x4_make(v1, v2, v3, v4));
        v1 = wasm_u32x4_extract_lane(accumulators, 0);
        v2 = wasm_u32x4_extract_lane(accumulators, 1);
        v3 = wasm_u32x4_extract_lane(accumulators, 2);
        v4 = wasm_u32x4_extract_lane(accumulators, 3);
#else
        do {
            v1 = round_word(v1, read_u32(source + cursor));
            v2 = round_word(v2, read_u32(source + cursor + 4u));
            v3 = round_word(v3, read_u32(source + cursor + 8u));
            v4 = round_word(v4, read_u32(source + cursor + 12u));
            cursor += 16u;
        } while (cursor <= length - 16u);
#endif
        hash = rotate(v1, 1u) + rotate(v2, 7u) + rotate(v3, 12u) + rotate(v4, 18u);
    } else {
        hash = SEED + PRIME5;
    }
    return tail(hash + length, source + cursor, length - cursor);
}

__attribute__((export_name("hash_lookup_begin")))
void hash_lookup_begin(uint32_t total) {
    require_source(0);
    uint32_t *state = (uint32_t *)(uintptr_t)STATE_OFFSET;
    state[0] = SEED + PRIME1 + PRIME2;
    state[1] = SEED + PRIME2;
    state[2] = SEED;
    state[3] = SEED - PRIME1;
    state[4] = total;
    state[5] = 0;
}

__attribute__((export_name("hash_lookup_update")))
void hash_lookup_update(uint32_t length) {
    require_source(length);
    uint32_t *state = (uint32_t *)(uintptr_t)STATE_OFFSET;
    if ((length & 15u) != 0 || state[5] > state[4] || length > state[4] - state[5]) {
        __builtin_trap();
    }
    const uint8_t *source = (const uint8_t *)(uintptr_t)DATA_OFFSET;
    uint32_t v1 = state[0], v2 = state[1], v3 = state[2], v4 = state[3];
#ifdef HASH_USE_SIMD
    const v128_t accumulators = simd_stripes(source, length, wasm_i32x4_make(v1, v2, v3, v4));
    v1 = wasm_u32x4_extract_lane(accumulators, 0);
    v2 = wasm_u32x4_extract_lane(accumulators, 1);
    v3 = wasm_u32x4_extract_lane(accumulators, 2);
    v4 = wasm_u32x4_extract_lane(accumulators, 3);
#else
    for (uint32_t cursor = 0; cursor < length; cursor += 16u) {
        v1 = round_word(v1, read_u32(source + cursor));
        v2 = round_word(v2, read_u32(source + cursor + 4u));
        v3 = round_word(v3, read_u32(source + cursor + 8u));
        v4 = round_word(v4, read_u32(source + cursor + 12u));
    }
#endif
    state[0] = v1; state[1] = v2; state[2] = v3; state[3] = v4;
    state[5] += length;
}

__attribute__((export_name("hash_lookup_finish")))
uint32_t hash_lookup_finish(uint32_t length) {
    require_source(length);
    uint32_t *state = (uint32_t *)(uintptr_t)STATE_OFFSET;
    if (state[5] > state[4] || length != state[4] - state[5]) { __builtin_trap(); }
    const uint32_t full = length & ~15u;
    hash_lookup_update(full);
    const uint32_t hash = state[4] >= 16u ?
        rotate(state[0], 1u) + rotate(state[1], 7u) + rotate(state[2], 12u) + rotate(state[3], 18u) :
        SEED + PRIME5;
    const uint8_t *source = (const uint8_t *)(uintptr_t)DATA_OFFSET;
    return tail(hash + state[4], source + full, length - full);
}
