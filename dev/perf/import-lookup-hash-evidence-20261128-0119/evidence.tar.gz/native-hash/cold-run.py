import hashlib
import json
import pathlib
import statistics
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
node, input_path, output_path = sys.argv[1:]
arms = ['js', 'onceCanonical', 'streamCanonical', 'jsControl', 'streamTiny']
observations = []
for block in range(10):
    order = arms[block % len(arms):] + arms[:block % len(arms)]
    if block >= len(arms):
        order.reverse()
    results = {}
    for arm in order:
        module = root / ('hash-prototype.wasm' if arm == 'streamTiny' else 'canonical-with-scalar-hash.wasm')
        process = subprocess.run([node, str(root / 'cold-one.mjs'), input_path, arm, str(module)],
                                 capture_output=True, text=True, check=True)
        results[arm] = json.loads(process.stdout)
        results[arm]['stderr'] = process.stderr
    observations.append({'block': block + 1, 'order': order, 'results': results})
summaries = {}
for arm in arms:
    values = [o['results'][arm] for o in observations]
    summaries[arm] = {field: statistics.median(v[field] for v in values)
                      for field in ['compileMs', 'initMs', 'loopMs', 'completeOperationMs']}
    summaries[arm]['pairedMedianPercent'] = statistics.median(
        100 * (o['results'][arm]['completeOperationMs'] / o['results']['js']['completeOperationMs'] - 1)
        for o in observations)
    summaries[arm]['wins'] = sum(o['results'][arm]['completeOperationMs'] < o['results']['js']['completeOperationMs']
                               for o in observations)
result = {
    'scope': 'Fresh Node process per observation; no synthetic hash warmup and all actual JMdict checksum spans in production order. Native times include compile, instance/memory initialization, all source copies and hashes. Source fixture read/deserialization/alignment restoration and WASM file reading are outside timers. This is a checksum component, not browser complete-import latency.',
    'canonicalCostQualification': 'Canonical arms compile an unchanged frozen canonical C scanner linked with the experimental scalar checksum C source. Neither scanner initialization nor production integration is changed. In actual imports the canonical module may already be compiled; tiny arms explicitly show the standalone prototype cost rather than disguising it as the full module.',
    'input': input_path,
    'inputSha256': hashlib.sha256(pathlib.Path(input_path).read_bytes()).hexdigest(),
    'files': {name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in [
        'cold-one.mjs', 'cold-run.py', 'hash-prototype-scalar.c', 'hash-prototype.wasm', 'canonical-with-scalar-hash.wasm']},
    'observations': observations,
    'summaries': summaries,
}
pathlib.Path(output_path).write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output': output_path, 'summaries': summaries}, indent=2))
