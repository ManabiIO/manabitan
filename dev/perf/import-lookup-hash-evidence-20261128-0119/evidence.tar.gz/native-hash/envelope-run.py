import hashlib
import json
import pathlib
import statistics
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parent
node, baseline, candidate, input_path, output_path = sys.argv[1:]
arms = ['baseline', 'native', 'control']
observations = []
for block in range(12):
    order = arms[block % len(arms):] + arms[:block % len(arms)]
    if (block // len(arms)) % 2:
        order.reverse()
    values = {}
    for arm in order:
        command = [node, '--max-old-space-size=384', str(root / 'envelope-one.mjs'),
                   candidate if arm == 'native' else baseline, input_path, arm]
        completed = subprocess.run(command, capture_output=True, text=True, check=True)
        values[arm] = json.loads(completed.stdout)
        values[arm]['stderr'] = completed.stderr
    observations.append({'block': block + 1, 'order': order, 'values': values})
summaries = {}
for phase in ['cold', 'warm']:
    phase_values = [{arm: o['values'][arm]['cold']['totalMs'] if phase == 'cold' else
                     statistics.median(x['totalMs'] for x in o['values'][arm]['warm']) for arm in arms}
                    for o in observations]
    summaries[phase] = {arm: {
        'medianMs': statistics.median(v[arm] for v in phase_values),
        'pairedMedianPercent': statistics.median(100 * (v[arm] / v['baseline'] - 1) for v in phase_values),
        'equalWorkPercent': 100 * (sum(v[arm] for v in phase_values) / sum(v['baseline'] for v in phase_values) - 1),
        'wins': sum(v[arm] < v['baseline'] for v in phase_values),
    } for arm in arms}
report = {
    'scope': 'Actual enclosing TermRecordOpfsStore._createLookupIndexChunk including field validation, all three current-byte hashes, output allocation and payload/field copies; begin/end import lifecycle charged too. Fresh Node22 process per arm/observation. Every output SHA256 equals captured reference. Component only; excludes browser, parser, compression, physical OPFS and restart.',
    'inputScope': 'Corrected production raw-v6 codec and complete pinned corpus; synthetic sequential raw logical content offsets in explicit in-memory persistence adapter. This is representative production-derived input, not exact compressed physical OPFS output.',
    'startupPolicy': 'No synthetic hash warmup before cold observation. Native initialization starts in real beginImportSession and its pending promise is conservatively awaited before envelope work. Six preserved full enclosing-operation warmup cycles precede four preserved warm samples per process.',
    'input': input_path,
    'inputSha256': hashlib.sha256(pathlib.Path(input_path).read_bytes()).hexdigest(),
    'baseline': baseline,
    'candidate': candidate,
    'runnerSha256': hashlib.sha256((root / 'envelope-one.mjs').read_bytes()).hexdigest(),
    'observations': observations,
    'summaries': summaries,
}
pathlib.Path(output_path).write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'output': output_path, 'summaries': summaries}, indent=2))
