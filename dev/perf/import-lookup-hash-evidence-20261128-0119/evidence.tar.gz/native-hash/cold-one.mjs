import fs from 'node:fs';
import assert from 'node:assert/strict';
import {deserialize} from 'node:v8';
import {performance} from 'node:perf_hooks';
import {hashTermKeyBytes} from '../../ext/js/dictionary/term-key-hash.js';
import {splitPersistedTermLookupIndex} from '../../ext/js/dictionary/term-lookup-index.js';

const [input, arm, wasmPath] = process.argv.slice(2);
const corpus = deserialize(fs.readFileSync(input));
const sources = corpus.payloads.flatMap((frame) => {
    const {base, derived} = splitPersistedTermLookupIndex(Uint8Array.from(frame.payload));
    return [
        {bytes: base, expected: frame.checksums.base, kind: 'base'},
        {bytes: derived, expected: frame.checksums.derived, kind: 'derived'},
        {bytes: Uint8Array.from(frame.recordFields), expected: frame.checksums.recordFields, kind: 'recordFields'},
    ];
});
let compileMs = 0, initMs = 0;
let hash = hashTermKeyBytes;
let moduleBytes = 0;
if (arm !== 'js' && arm !== 'jsControl') {
    const bytes = fs.readFileSync(wasmPath);
    moduleBytes = bytes.byteLength;
    const compileStart = performance.now();
    const module = await WebAssembly.compile(bytes);
    const compileEnd = performance.now();
    compileMs = compileEnd - compileStart;
    const streaming = arm.startsWith('stream');
    const pages = streaming ? 3 : 34;
    const limit = streaming ? 65536 : 2 * 1024 * 1024;
    const memory = new WebAssembly.Memory({initial: pages, maximum: pages});
    const {exports} = new WebAssembly.Instance(module, {env: {memory}});
    const scratch = new Uint8Array(memory.buffer, 131072, limit);
    hash = streaming ? (source) => {
        const length = source.byteLength;
        if (length < 1024) { return hashTermKeyBytes(source); }
        if (length <= limit) {
            scratch.set(source);
            return exports.hash_lookup_bytes(length) >>> 0;
        }
        exports.hash_lookup_begin(length);
        let cursor = 0;
        while (length - cursor > limit) {
            scratch.set(source.subarray(cursor, cursor + limit));
            exports.hash_lookup_update(limit);
            cursor += limit;
        }
        scratch.set(source.subarray(cursor));
        return exports.hash_lookup_finish(length - cursor) >>> 0;
    } : (source) => {
        if (source.byteLength < 1024 || source.byteLength > limit) { return hashTermKeyBytes(source); }
        scratch.set(source);
        return exports.hash_lookup_bytes(source.byteLength) >>> 0;
    };
    initMs = performance.now() - compileEnd;
}
const observations = [];
const loopStart = performance.now();
for (const {bytes, kind} of sources) {
    const started = performance.now();
    const result = hash(bytes);
    observations.push({kind, length: bytes.byteLength, hash: result, ms: performance.now() - started});
}
const loopMs = performance.now() - loopStart;
for (let i = 0; i < sources.length; ++i) { assert.equal(observations[i].hash, sources[i].expected); }
console.log(JSON.stringify({arm, node: process.version, v8: process.versions.v8,
    compileMs, initMs, loopMs, completeOperationMs: compileMs + initMs + loopMs,
    moduleBytes, memoryBytes: arm === 'js' || arm === 'jsControl' ? 0 : (arm.startsWith('stream') ? 3 : 34) * 65536,
    rows: corpus.receipt.rows, checkedSpans: sources.length, observations}));
