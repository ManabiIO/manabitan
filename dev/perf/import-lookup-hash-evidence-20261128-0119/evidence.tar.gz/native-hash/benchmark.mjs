import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {deserialize} from 'node:v8';
import {performance} from 'node:perf_hooks';
import {hashTermKeyBytes} from '../../ext/js/dictionary/term-key-hash.js';
import {splitPersistedTermLookupIndex} from '../../ext/js/dictionary/term-lookup-index.js';

const input = process.argv[2];
const output = process.argv[3];
const inputBytes = fs.readFileSync(input);
const corpus = deserialize(inputBytes);
const wasmPath = process.argv[4] ?? new URL('./hash-prototype.wasm', import.meta.url);
const wasmBytes = fs.readFileSync(wasmPath);
const compiled = await WebAssembly.compile(wasmBytes);
const OFFSET = 131072;
const ONCE_LIMIT = 2 * 1024 * 1024;
const STREAM_LIMIT = 64 * 1024;
function oneShot() {
    const memory = new WebAssembly.Memory({initial: 34, maximum: 34});
    const {exports} = new WebAssembly.Instance(compiled, {env: {memory}});
    const scratch = new Uint8Array(memory.buffer, OFFSET, ONCE_LIMIT);
    return (bytes) => {
        if (bytes.byteLength < 1024 || bytes.byteLength > ONCE_LIMIT) { return hashTermKeyBytes(bytes); }
        scratch.set(bytes);
        return exports.hash_lookup_bytes(bytes.byteLength) >>> 0;
    };
}
function streaming() {
    const memory = new WebAssembly.Memory({initial: 3, maximum: 3});
    const {exports} = new WebAssembly.Instance(compiled, {env: {memory}});
    const scratch = new Uint8Array(memory.buffer, OFFSET, STREAM_LIMIT);
    return (bytes) => {
        const length = bytes.byteLength;
        if (length < 1024) { return hashTermKeyBytes(bytes); }
        if (length <= STREAM_LIMIT) {
            scratch.set(bytes);
            return exports.hash_lookup_bytes(length) >>> 0;
        }
        exports.hash_lookup_begin(length);
        let cursor = 0;
        while (length - cursor > STREAM_LIMIT) {
            scratch.set(bytes.subarray(cursor, cursor + STREAM_LIMIT));
            exports.hash_lookup_update(STREAM_LIMIT);
            cursor += STREAM_LIMIT;
        }
        scratch.set(bytes.subarray(cursor));
        return exports.hash_lookup_finish(length - cursor) >>> 0;
    };
}
const once = oneShot(), stream = streaming();
const sources = corpus.payloads.flatMap((frame) => {
    // V8's serialized Buffer can be unaligned within its deserializer arena.
    // Restore ordinary owned, aligned production views before timed work.
    const payload = Uint8Array.from(frame.payload);
    const recordFields = Uint8Array.from(frame.recordFields);
    const {base, derived} = splitPersistedTermLookupIndex(payload);
    assert.equal(base.byteLength, frame.baseBytes);
    assert.equal(derived.byteLength, frame.derivedBytes);
    return [{bytes: base, expected: frame.checksums.base, kind: 'base'},
        {bytes: derived, expected: frame.checksums.derived, kind: 'derived'},
        {bytes: recordFields, expected: frame.checksums.recordFields, kind: 'recordFields'}];
});
for (const {bytes, expected} of sources) {
    assert.equal(hashTermKeyBytes(bytes), expected);
    assert.equal(once(bytes), expected);
    assert.equal(stream(bytes), expected);
}
const boundaries = [...Array.from({length: 65}, (_, i) => i), 255, 256, 1023, 1024, 1025,
    65519, 65520, 65521, 65535, 65536, 65537, 131071, 131072, 131073,
    ONCE_LIMIT - 1, ONCE_LIMIT, ONCE_LIMIT + 1, ONCE_LIMIT + 17];
let value = 0x9e3779b9;
for (const length of boundaries) {
    const allocation = new Uint8Array(length + 39);
    for (let i = 0; i < allocation.length; ++i) {
        value ^= value << 13; value ^= value >>> 17; value ^= value << 5;
        allocation[i] = value;
    }
    for (const offset of [0, 1, 3, 16, 31]) {
        const bytes = allocation.subarray(offset, offset + length);
        const expected = hashTermKeyBytes(bytes);
        assert.equal(once(bytes), expected, `one-shot boundary ${length}/${offset}`);
        assert.equal(stream(bytes), expected, `stream boundary ${length}/${offset}`);
    }
}
const functions = {js: hashTermKeyBytes, jsControl: hashTermKeyBytes, once, stream};
let checksumSink = 0;
function invoke(name) {
    const hash = functions[name];
    const begin = performance.now();
    for (const {bytes} of sources) { checksumSink = (checksumSink + hash(bytes)) >>> 0; }
    return performance.now() - begin;
}
const names = Object.keys(functions);
const warmups = [];
for (let i = 0; i < 6; ++i) { for (const name of names) { warmups.push({name, ms: invoke(name)}); } }
const observations = [];
for (let i = 0; i < 24; ++i) {
    const order = names.slice(i % 4).concat(names.slice(0, i % 4));
    if ((i >> 2) % 2) { order.reverse(); }
    const values = {};
    for (const name of order) { values[name] = invoke(name); }
    observations.push({block: i + 1, order, values});
}
function median(values) {
    const sorted = [...values].sort((a, b) => a - b);
    return (sorted[Math.floor((sorted.length - 1) / 2)] + sorted[Math.floor(sorted.length / 2)]) / 2;
}
const summaries = {};
for (const name of names) {
    summaries[name] = {medianMs: median(observations.map((o) => o.values[name])),
        pairedMedianPercent: median(observations.map((o) => 100 * (o.values[name] / o.values.js - 1))),
        wins: observations.filter((o) => o.values[name] < o.values.js).length};
}
const startup = [];
for (let i = 0; i < 12; ++i) {
    for (const [name, make] of [['once', oneShot], ['stream', streaming]]) {
        const begin = performance.now();
        const hash = make();
        const afterInit = performance.now();
        assert.equal(hash(sources[0].bytes), sources[0].expected);
        startup.push({name, initMs: afterInit - begin, initAndFirstHashMs: performance.now() - begin});
    }
}
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
const report = {
    scope: 'Checksum component only; full real JMdict lookup/base/derived/record byte spans. Includes copying source bytes to private native scratch on every invocation. No browser or complete-import latency claim.',
    node: process.version, v8: process.versions.v8, sourceScope: corpus.scope,
    input, inputSha256: sha256(inputBytes), wasmPath: String(wasmPath), wasmSha256: sha256(wasmBytes),
    prototypeSourceSha256: sha256(fs.readFileSync(new URL('./hash-prototype.c', import.meta.url))),
    baselineSourceSha256: sha256(fs.readFileSync(new URL('../../ext/js/dictionary/term-key-hash.js', import.meta.url))),
    corpus: {frames: corpus.payloads.length, rows: corpus.receipt.rows,
        totalHashedBytes: sources.reduce((sum, source) => sum + source.bytes.byteLength, 0),
        sourceLengths: sources.map(({bytes, kind}) => ({kind, length: bytes.byteLength})),
        sourceStoreSha256: corpus.sourceStoreSha256 ?? corpus.storeSha256 ?? null},
    privateMemoryBytes: {once: 34 * 65536, stream: 3 * 65536},
    boundaryChecks: boundaries.length * 5, allCorpusChecksumsEqual: true,
    warmups, observations, summaries, startup, checksumSink,
};
fs.writeFileSync(output, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({output, node: report.node, v8: report.v8, corpus: report.corpus, summaries}, null, 2));
