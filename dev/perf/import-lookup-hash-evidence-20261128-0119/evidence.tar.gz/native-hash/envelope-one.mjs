import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {deserialize} from 'node:v8';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import {performance} from 'node:perf_hooks';

const [sourceRoot, input, arm] = process.argv.slice(2);
const corpus = deserialize(fs.readFileSync(input));
const frames = corpus.payloads.map((frame) => ({...frame,
    payload: Uint8Array.from(frame.payload), recordFields: Uint8Array.from(frame.recordFields)}));
const wasm = fs.readFileSync(path.join(sourceRoot, 'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm'));
let fetchCount = 0;
globalThis.fetch = async (url) => {
    assert.match(String(url), /term-content-canonical-scan-v1\.wasm$/);
    ++fetchCount;
    return new Response(wasm, {status: 200});
};
const {TermRecordOpfsStore} = await import(pathToFileURL(path.join(sourceRoot, 'ext/js/dictionary/term-record-opfs-store.js')).href);
const store = new TermRecordOpfsStore();
async function once() {
    const started = performance.now();
    await store.beginImportSession();
    // Production overlaps this optional initialization with parser work. This
    // component conservatively waits and charges all of it to the native arm.
    await Reflect.get(store, '_importLookupIndexHasherPromise');
    const initialized = performance.now();
    const nativeActive = Reflect.get(store, '_importLookupIndexHasher') != null;
    assert.equal(nativeActive, arm === 'native');
    const outputs = [];
    const observations = [];
    for (const frame of frames) {
        const before = performance.now();
        const output = store._createLookupIndexChunk(frame.firstId, frame.count, frame.contentOffsetBase,
            frame.payload, frame.recordFields, frame.recordFieldsFormat);
        observations.push({firstId: frame.firstId, rows: frame.count, bytes: output.byteLength, ms: performance.now() - before});
        outputs.push(output);
    }
    const encoded = performance.now();
    await store.endImportSession();
    const completed = performance.now();
    assert.equal(Reflect.get(store, '_importLookupIndexHasher') ?? null, null);
    for (let i = 0; i < frames.length; ++i) {
        assert.equal(createHash('sha256').update(outputs[i]).digest('hex'), frames[i].encodedSha256);
    }
    return {setupMs: initialized - started, encodeMs: encoded - initialized,
        finishMs: completed - encoded, totalMs: completed - started, nativeActive, observations};
}
const cold = await once();
const warmups = [];
for (let i = 0; i < 6; ++i) { warmups.push(await once()); }
const warm = [];
for (let i = 0; i < 4; ++i) { warm.push(await once()); }
console.log(JSON.stringify({arm, sourceRoot, node: process.version, v8: process.versions.v8, fetchCount,
    rows: corpus.receipt.rows, frames: frames.length, exactCapturedEnvelopeSha256Match: true,
    sourceSha256: createHash('sha256').update(fs.readFileSync(path.join(sourceRoot, 'ext/js/dictionary/term-record-opfs-store.js'))).digest('hex'),
    wasmSha256: createHash('sha256').update(wasm).digest('hex'), cold, warmups, warm}));
