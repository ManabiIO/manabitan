import pathlib,json,hashlib,base64,io,tarfile,subprocess,sys,os
out=pathlib.Path('/home/agent/manabitan-suffix-portable-review-profile-isolation-5a86');out.mkdir(exist_ok=True)
source=pathlib.Path('/home/agent/manabitan-suffix-browser-audit-5a86')
old=source/'review-history/verify-before-import-isolation.py'
new=source/'verify-suffix-cohort.py'
oldhash='baeb8b8cb2f5dd8a2016f898e74e1d7836e015ffb8838cbe2fabfdbcc08ff399'
newhash='6cbf0035c62485ea4e5074a1d00d7665292f3a8003e414e552181f23e7c65bab'
assert hashlib.sha256(old.read_bytes()).hexdigest()==oldhash
assert hashlib.sha256(new.read_bytes()).hexdigest()==newhash
oldcopy=out/'historical-verifier-baeb.py';oldcopy.write_bytes(old.read_bytes())
newcopy=out/'reviewed-verifier-6cbf.py';newcopy.write_bytes(new.read_bytes())
proof=source/'source-proof/source-proof.json.txt'
evidence=pathlib.Path('/home/agent/manabitan-suffix-jitendex-ab-audit-5a86/durable/hosted-jitendex-AB.json.txt')
original=evidence.parent.parent/'artifact.zip'
wrapper=json.loads(evidence.read_bytes());raw=base64.b64decode(wrapper['archive'],validate=True)
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:xz') as t:
    originals={x.name:t.extractfile(x).read() for x in t.getmembers()}
def mutate(label,name):
    data=dict(originals);marker=out/(label+'-marker.txt');assert not marker.exists()
    data[name]=(f"open({str(marker)!r}, 'w').write('Harmless isolation-review marker\\n')\nraise RuntimeError('review marker stops before further work')\n").encode()
    j=json.loads(evidence.read_bytes());j['manifest']['members'][name]={'bytes':len(data[name]),'sha256':hashlib.sha256(data[name]).hexdigest()}
    b=io.BytesIO()
    with tarfile.open(fileobj=b,mode='w:xz') as t:
        for key,payload in sorted(data.items()):
            info=tarfile.TarInfo(key);info.size=len(payload);info.mode=0o644;info.uid=info.gid=info.mtime=0;info.uname=info.gname='';t.addfile(info,io.BytesIO(payload))
    r=b.getvalue();j['archive']=base64.b64encode(r).decode()
    j['manifest']['archive'].update(bytes=len(r),sha256=hashlib.sha256(r).hexdigest(),members=len(data),uncompressedBytes=sum(map(len,data.values())))
    path=out/(label+'.json.txt');path.write_text(json.dumps(j,indent=2)+'\n')
    return path,marker
cases=[('helper-copy',*mutate('helper-copy','frozen-source/dev/perf/import-memory-20261125-a7f7/copy.py')),('adjacent-pathlib',*mutate('adjacent-pathlib','pathlib.py'))]
env=dict(os.environ,TMPDIR=str(out))
receipts=[]
def run(label,checker,inp,extra=(),optimized=False):
    cmd=[sys.executable,*(['-O'] if optimized else []),str(checker),'--evidence',str(inp),'--source-proof',str(proof),*extra]
    with (out/(label+'.stdout')).open('wb') as stdout,(out/(label+'.stderr')).open('wb') as stderr:
        r=subprocess.run(cmd,stdout=stdout,stderr=stderr,env=env)
    result={'label':label,'exitCode':r.returncode,'command':cmd,'stdoutSha256':hashlib.sha256((out/(label+'.stdout')).read_bytes()).hexdigest(),'stderrSha256':hashlib.sha256((out/(label+'.stderr')).read_bytes()).hexdigest()}
    receipts.append(result)
    (out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    return r
assert run('new-compact',newcopy,evidence).returncode==0
assert run('new-full',newcopy,evidence,['--original-artifact',str(original)]).returncode==0
baseline=json.loads((out/'new-compact.stdout').read_bytes())
full=json.loads((out/'new-full.stdout').read_bytes())
assert baseline['semanticReceipts']==42 and baseline['rawMemoryScans']==274
assert baseline['originalProductZipBytesRechecked'] is False and full['originalProductZipBytesRechecked'] is True
full['originalProductZipBytesRechecked']=False
assert baseline==full
for label,inp,marker in cases:
    assert run('historical-'+label,oldcopy,inp).returncode!=0
    assert marker.exists(),label
    before=(marker.read_bytes(),marker.stat().st_mtime_ns)
    assert run('new-'+label,newcopy,inp).returncode==0
    assert before==(marker.read_bytes(),marker.stat().st_mtime_ns)
    result=json.loads((out/('new-'+label+'.stdout')).read_bytes())
    result['cohortArchiveSha256']=baseline['cohortArchiveSha256']
    assert result==baseline
    receipts[-1]['markerUnchanged']=True
assert run('new-optimized-python',newcopy,evidence,optimized=True).returncode!=0
assert 'Do not use optimized Python' in (out/'new-optimized-python.stderr').read_text()
(out/'receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps({'status':'PASS','checks':len(receipts),'semanticReceipts':baseline['semanticReceipts'],'rawMemoryScans':baseline['rawMemoryScans'],'newVerifierSha256':newhash,'historicalVerifierSha256':oldhash,'noNewAcquisition':True,'results':[{'label':x['label'],'exitCode':x['exitCode'],'markerUnchanged':x.get('markerUnchanged')} for x in receipts]}))
