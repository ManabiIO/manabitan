#!/usr/bin/env python3
"""Collect the six already audited cohorts; never acquire an observation."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).parent
BASE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CAND = '38031a752b26c9b630e5f2f1d45e780786656c74'
sha = lambda b: hashlib.sha256(b).hexdigest()
cells = []
for dictionary in ('jmdict', 'jitendex', 'vndb'):
    for order in ('AB', 'BA'):
        root = Path('/home/agent/manabitan-suffix-' + dictionary + '-' + order.lower() + '-audit-5a86')
        audit_bytes = (root / 'independent-audit.json').read_bytes()
        audit = json.loads(audit_bytes)
        wrapper_path = root / 'durable' / ('hosted-' + dictionary + '-' + order + '.json.txt')
        wrapper_bytes = wrapper_path.read_bytes()
        manifest = json.loads(wrapper_bytes)['manifest']
        comparison = json.loads((root / (dictionary + '-' + order) / 'memory/memory-comparison.json').read_bytes())
        assert audit['status'] == 'PASS' and audit['semanticReceiptCount'] == 42
        assert manifest['baseline'] == BASE and manifest['candidate'] == CAND
        assert manifest['dictionary'] == dictionary and manifest['order'] == order
        assert manifest['originalAuditSha256'] == sha(audit_bytes)
        assert audit['artifactMetadata'] == manifest['originalArtifact']
        assert audit['artifactMetadata']['workflow_run']['id'] == 46104813593
        assert audit['artifactMetadata']['workflow_run']['head_sha'] == CAND
        assert sum(name.startswith('original/') for name in manifest['members']) == 313
        cells.append({
            'dictionary': dictionary, 'order': order,
            'artifact': audit['artifactMetadata'],
            'independentOriginalAuditSha256': sha(audit_bytes),
            'imports': audit['semanticReceiptCount'],
            'rawMemoryScans': audit['memoryRawAudit']['rawScanCount'],
            'analysis': audit['analysisRecomputed'],
            'memoryAudit': audit['memoryRawAudit'],
            'memoryComparison': comparison,
            'preservedArchive': manifest['archive'],
            'wrapper': {'file': dictionary + '-' + order + '.json.txt',
                        'bytes': len(wrapper_bytes), 'sha256': sha(wrapper_bytes),
                        'gitBlob': hashlib.sha1(b'blob ' + str(len(wrapper_bytes)).encode() + b'\0' + wrapper_bytes).hexdigest()},
            'packageLimitation': manifest['packageLimitation'],
        })

for dictionary in ('jmdict', 'jitendex', 'vndb'):
    pair = [cell for cell in cells if cell['dictionary'] == dictionary]
    assert len(pair) == 2
    # Each dictionary has an unfavorable complete cohort. Do not pool hosts,
    # remove a slow pair, or subtract same-code-control drift to claim a gain.
    assert any(cell['analysis']['candidateVsBaseline']['medianPairedChangePercent'] >= 0 or
               cell['analysis']['candidateVsBaseline']['equalWorkChangePercent'] >= 0 for cell in pair)

report = {
    'schemaVersion': 1, 'status': 'CLOSED_NO_REVIEW_WORTHY_IMPORT_GAIN',
    'baseline': BASE, 'candidate': CAND,
    'candidateTree': 'a05ece005d9fb4931cb1fc24f0cb67ceb109a7f5',
    'runId': 46104813593, 'runUrl': 'https://github.com/ManabiIO/manabitan/actions/runs/46104813593',
    'allSixOriginalArtifactAuditsPassed': True,
    'allMemoryCellsPassed': all(cell['analysis']['memoryPassed'] for cell in cells),
    'auditedCompleteImports': sum(cell['imports'] for cell in cells),
    'auditedRawMemoryScans': sum(cell['rawMemoryScans'] for cell in cells),
    'timingBoundary': 'File input change through post-UI import completion; fresh browser profile per observation, not physical paint.',
    'statistics': 'Twelve adjacent alternating pairs per host. Separate AB/BA hosts and same-code controls. All timing tails retained; no pooling, trimming, control subtraction, or selected rerun.',
    'originalArtifactPolicy': 'Every original ZIP was checked in full before compact preservation. Each compact cohort retains 313 of 315 original members; only the two product ZIP payloads are omitted, with all member identities and exact changed native source retained. Optional original-artifact verification repeats full package-byte checks.',
    'sourceProof': {'file': 'source-proof.json.txt', 'gitObjects': 52, 'exactPaths': 36,
                    'archiveSha256': '5f7a16757ad01bbb7c744d62acec11140fea3dade7b3d613e047f1bd0de611c7',
                    'scope': 'Partial exact Git object closure for the frozen commits, bound source paths and native module bytes; unrelated objects and parent histories are intentionally absent.'},
    'portableVerifier': {'file': 'dev/perf/verify-suffix-window-hosted-5a86.py',
                         'sha256': '6cbf0035c62485ea4e5074a1d00d7665292f3a8003e414e552181f23e7c65bab',
                         'originalAuditorSha256': 'd5857d4f14b27941ef657c1f0c2c1c89425caf3491e6f2d4101a4d859667f86d',
                         'originalReviewSha256': '94ba5eef8525e121e6274309d93f2fad6123150095e7bb4a4c799d6517863b21',
                         'importIsolationAddendumSha256': '7f5529ce60fe7039555c1217b70fa6663fc4fb33240e2e033182c4bf1195c1b9',
                         'preparationCorrections': ['Trusted package-retention disclosure', 'Git source-specification validation', 'Fresh selective verified-helper directory and isolated Python child imports'],
                         'historyPolicy': 'Historical checker versions, harmless reproducers, positive and negative receipts, and the separate final import-isolation addendum are retained losslessly.'},
    'noNewAcquisition': True, 'noPullRequest': True, 'cohorts': cells,
}
(ROOT / 'results.json.txt').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'imports': report['auditedCompleteImports'],
                  'scans': report['auditedRawMemoryScans'], 'allMemoryCellsPassed': report['allMemoryCellsPassed']}))
