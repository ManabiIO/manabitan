#!/usr/bin/env python3
"""Add the completed suffix result to the existing single handoff."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).parent
original = (root / 'handoff-original.md').read_text()
report = json.loads((root / 'results.json.txt').read_bytes())
assert report['auditedCompleteImports'] == 252
assert report['auditedRawMemoryScans'] == 2153
assert not report['allMemoryCellsPassed']
names = {'jmdict': 'JMdict', 'jitendex': 'Jitendex', 'vndb': 'VNDB'}
rows = []
for cell in report['cohorts']:
    a = cell['analysis']['candidateVsBaseline']
    lo, hi = a['descriptiveBootstrap95Percent']
    rows.append('| ' + ' | '.join([
        names[cell['dictionary']] + ' ' + cell['order'],
        f"{a['medianPairedChangePercent']:+.4f}%",
        f"{a['equalWorkChangePercent']:+.4f}%",
        f"{a['fasterPairs']}/12", f'[{lo:+.4f}%, {hi:+.4f}%]',
        f"{cell['analysis']['identicalCodeControl']['medianPairedChangePercent']:+.4f}%",
        'pass' if cell['analysis']['memoryPassed'] else 'coverage failure',
    ]) + ' |')

section = '''### Completed hosted suffix qualification

**Decision: stop without a performance PR.** The original proposal and
prospective plan above remain as the historical record. All six registered
cohorts are now complete: 252 imports and 2,153 raw sampled-memory scans were
independently audited against the original artifacts. The frozen acquisition
remains `38031a752b26c9b630e5f2f1d45e780786656c74`; this follow-up changes only
evidence and this handoff, and does not acquire any new observations.

Negative changes mean faster. Each row is its own twelve-pair host; the
descriptive bootstrap interval is for its paired median. Total time compares
the sums for equal work. Identical-code control results remain separate.

| Cohort | Median change | Total-time change | Faster pairs | Descriptive 95% interval | Control median | Memory screen |
| --- | ---: | ---: | ---: | --- | ---: | --- |
''' + '\n'.join(rows) + '''

JMdict's opposite-order results do not establish a repeatable gain. Its AB
cohort retains the +116.9095% slow pair; that observation is part of the
+9.4844% total-time result. Jitendex retains its +27.8094% BA pair, and both
Jitendex total-time comparisons are slower. VNDB's mildly favorable AB result
does not replicate in BA. No host pooling, tail removal, control subtraction,
selected rerun or revised acceptance criterion is used.

Both VNDB memory screens fail the original 250 ms coverage bound. The baseline
A1 gaps are 254.012525 ms on AB and 356.501319 ms on BA. The other three
observations on each host qualify, but the whole-cohort aggregate PSS/private
effects remain null. Memory effects are unqualified for these two cohorts;
the failed observations and exact raw scans are retained. All six original
artifact audits verify source and package identities, canonical receipts,
storage byte totals, lookups after restart, and every media file. The two
failed acquisition jobs remain unqualified.

The separate [complete-corpus proof](https://github.com/ManabiIO/manabitan/commit/05a829b3fa88bac31cb4956104356fd393e0facc)
covers 7,613,164 rows in 937 banks and 204 production parser groups per arm.
Production JMdict reuse increases from 54,641 to 161,292 rows; this is a work
counter, not a latency estimate. The source model above and these execution
counters have different grouping/admission boundaries. JMdict and Jitendex
continue to perform immediate CRC, so suffix reuse saves no CRC work for
either fixture. The proof compares complete live output ranges through
digests and has the limitations recorded in its own report; browser content
probes remain sampled.

The [hosted result index](suffix-window-5a86/hosted/results.json.txt) preserves
each cohort's full paired statistics, memory result, artifact identity and
audit binding. Its six compact archives retain all 1,878 non-package original
members. The original ZIP containers and their twelve product ZIP payloads
are omitted from these compact files. Every original product ZIP was checked
in full first; all 554 member identities per arm, exact changed native bytes,
raw observations and original audits remain retained. Full omitted package
bytes can be checked again when the matching original artifact is supplied.

The portable checker uses an exact partial closure of 52 Git objects for 36
source paths. It validates frozen source and observer identities before
running the original observation logic, copies only the nine verified files
into a fresh helper tree, and launches the derived auditor with isolated
Python imports. Its output must reproduce the original full-artifact audit
byte for byte. Review history retains the initial provenance-text and Git
argument corrections, historical checker versions, harmless import-shadowing
reproducers, and the separate final isolation review. These are verifier
preparation corrections; product source, protocol and observations are
unchanged.

For example, with Python and Git installed:

```sh
python3 -I -B dev/perf/verify-suffix-window-hosted-5a86.py \\
  --evidence dev/perf/suffix-window-5a86/hosted/jmdict-AB.json.txt \\
  --source-proof dev/perf/suffix-window-5a86/hosted/source-proof.json.txt
```

Add `--original-artifact /path/to/the-matching-artifact.zip` to repeat the
omitted full-package checks. Both modes state explicitly whether those ZIP
bytes were rechecked. They run no imports. The minimum documentation-only
Prettier check could not complete because the package is absent following the
executor reset; the exact failed attempt is retained with these preparation
receipts. The completed frozen product-source gate above is unchanged.

'''

heading = '## November 27, 2026: complete format-3 suffix reuse study\n\n'
assert original.count(heading) == 1
start = original.index(heading) + len(heading)
end = original.index('\n## ', start)
lead = ('**Final hosted decision: stop without a performance PR.** All six original\n'
        'cohorts are complete; no consistent import gain was found. The complete\n'
        'results and preserved evidence are in the hosted supplement below.\n\n')
updated = original[:start] + lead + original[start:end] + '\n\n' + section + original[end:]
(root / 'hosted-supplement.md').write_text(section)
(root / 'handoff-proposed.md').write_text(updated)
assert updated.replace(lead, '', 1).replace('\n\n' + section, '', 1) == original
print(json.dumps({'handoffBytes': len(updated.encode()), 'handoffSha256': hashlib.sha256(updated.encode()).hexdigest(),
                  'supplementBytes': len(section.encode()), 'originalTextUnchanged': True}))
