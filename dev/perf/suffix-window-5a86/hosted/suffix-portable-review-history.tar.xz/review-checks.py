from pathlib import Path
import base64,copy,hashlib,io,json,lzma,subprocess,tarfile,time,zlib
out=Path('/home/agent/manabitan-suffix-portable-review-profile-5a86');out.mkdir(exist_ok=True)
source=Path('/home/agent/manabitan-suffix-browser-audit-5a86/verify-suffix-cohort.py')
verifier=out/'reviewed-verifier-baeb.py'; raw=source.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='baeb8b8cb2f5dd8a2016f898e74e1d7836e015ffb8838cbe2fabfdbcc08ff399'
verifier.write_bytes(raw)
proof=Path('/home/agent/manabitan-suffix-browser-audit-5a86/source-proof/source-proof.json.txt')
evidence=Path('/home/agent/manabitan-suffix-jitendex-ab-audit-5a86/durable/hosted-jitendex-AB.json.txt')
original=Path('/home/agent/manabitan-suffix-jitendex-ab-audit-5a86/artifact.zip')
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(evidence.read_bytes())=='d8b3f59f955a70699b468ef3265a15fad587b6fd1e15ed8ce257f9755e568134'
assert sha(proof.read_bytes())=='c94196506f56273c8da6b2155ea42fd01964bf18400ad950d110cc59c4b025e2'
runs=[]
def run(name,ev=evidence,pf=proof,extra=(),optimized=False,success=False):
 args=['python3']+(['-O'] if optimized else [])+['-B',str(verifier),'--evidence',str(ev),'--source-proof',str(pf)]+list(extra)
 start=time.time();r=subprocess.run(args,capture_output=True)
 (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 d={'name':name,'command':args,'exitCode':r.returncode if r.returncode>=0 else None,'signal':-r.returncode if r.returncode<0 else None,'auditOnlyElapsedSeconds':time.time()-start,'expectedSuccess':success,'stdout':{'bytes':len(r.stdout),'sha256':sha(r.stdout)},'stderr':{'bytes':len(r.stderr),'sha256':sha(r.stderr)}}
 runs.append(d);(out/'final-receipts.json').write_text(json.dumps(runs,indent=2)+'\n')
 assert (r.returncode==0)==success,(name,r.stderr)
 print(json.dumps({'name':name,'exitCode':r.returncode,'expectedSuccess':success,'stderr':r.stderr.decode()}),flush=True)
 return json.loads(r.stdout) if success else None
compact=run('final-compact',success=True)
full=run('final-full',extra=['--original-artifact',str(original)],success=True)
assert compact['originalProductZipBytesRechecked'] is False and full['originalProductZipBytesRechecked'] is True
c=copy.deepcopy(compact);f=copy.deepcopy(full);c.pop('originalProductZipBytesRechecked');f.pop('originalProductZipBytesRechecked');assert c==f
run('final-false-package-completeness',ev=out/'false-package-completeness.json.txt')
run('final-optimized-python',optimized=True)
w=json.loads(proof.read_text());marker=out/'final-unexpected-git-output.txt';assert not marker.exists()
w['manifest']['files']['--output='+str(marker)]={'bytes':0,'sha256':sha(b''),'blob':hashlib.sha1(b'blob 0\0').hexdigest()}
bad=out/'final-git-option-path.json.txt';bad.write_text(json.dumps(w));run('final-git-option-path',pf=bad);assert not marker.exists()
def rewrite_wrapper(input_path,output_path,mutator):
 w=json.loads(input_path.read_text()); payloads={}
 with tarfile.open(fileobj=io.BytesIO(base64.b64decode(w['archive'])),mode='r:xz') as tf:
  for info in tf:payloads[info.name]=tf.extractfile(info).read()
 mutator(w,payloads)
 data=io.BytesIO()
 with tarfile.open(fileobj=data,mode='w:xz',format=tarfile.PAX_FORMAT) as tf:
  for name,payload in sorted(payloads.items()):
   info=tarfile.TarInfo(name);info.size=len(payload);info.mode=0o644;info.uid=info.gid=info.mtime=0;info.uname=info.gname='';tf.addfile(info,io.BytesIO(payload))
 raw=data.getvalue();m=w['manifest'];m['archive']['bytes']=len(raw);m['archive']['sha256']=sha(raw);m['archive']['members']=len(payloads)
 if 'uncompressedBytes' in m['archive']:m['archive']['uncompressedBytes']=sum(map(len,payloads.values()))
 m['members']={name:{'bytes':len(payload),'sha256':sha(payload)} for name,payload in sorted(payloads.items())}
 w['archive']=base64.b64encode(raw).decode();output_path.write_text(json.dumps(w))
def false_both(w,p):
 text='All original product ZIP payloads are retained and independently reverified by this compact audit.'
 w['manifest']['packageLimitation']=text
 obj=json.loads(p['original-artifact-proof.json']);obj['limitation']=text;p['original-artifact-proof.json']=(json.dumps(obj,indent=2)+'\n').encode()
both=out/'false-package-manifest-and-proof.json.txt';rewrite_wrapper(evidence,both,false_both);run('final-false-package-both',ev=both)
def changed_object(w,p):
 name='objects/da/90749e2f22d0f6696f96935baabfdf4089659a'
 raw=bytearray(zlib.decompress(p[name]));raw[-1]^=1;p[name]=zlib.compress(raw)
changed=out/'changed-git-object.json.txt';rewrite_wrapper(proof,changed,changed_object);run('final-changed-git-object',pf=changed)
# Independent raw Git decoder: no Git process or verifier implementation used.
w=json.loads(proof.read_text());m=w['manifest'];entries={}
with tarfile.open(fileobj=io.BytesIO(base64.b64decode(w['archive'])),mode='r:xz') as tf:
 for item in tf:entries[item.name]=tf.extractfile(item).read()
objects={}
for oid,identity in m['objects'].items():
 b=zlib.decompress(entries['objects/'+oid[:2]+'/'+oid[2:]]);header,payload=b.split(b'\0',1);kind,length=header.decode().split()
 assert kind==identity['type'] and int(length)==len(payload)==identity['rawBytes'] and hashlib.sha1(b).hexdigest()==oid
 objects[oid]=(kind,payload)
trees={}
for revision,tree in m['trees'].items():
 kind,b=objects[revision];assert kind=='commit' and b.split(b'\n',1)[0]==b'tree '+tree.encode();trees[revision]=tree
def tree_entries(oid):
 kind,data=objects[oid];assert kind=='tree';r={};i=0
 while i<len(data):
  end=data.index(0,i);mode_name=data[i:end];mode,name=mode_name.split(b' ',1);child=data[end+1:end+21].hex();assert len(data[end+1:end+21])==20
  assert name.decode() not in r;r[name.decode()]=(mode.decode(),child);i=end+21
 assert i==len(data);return r
for spec,identity in m['files'].items():
 revision,path=spec.split(':',1);oid=trees[revision]
 for part in path.split('/'):mode,oid=tree_entries(oid)[part]
 kind,b=objects[oid];assert kind=='blob' and mode in ('100644','100755') and oid==identity['blob'] and len(b)==identity['bytes'] and sha(b)==identity['sha256']
assert len(objects)==52 and len(m['files'])==36
# Adaptation preserves the original receipt/statistical/memory tail verbatim.
import importlib.util
spec=importlib.util.spec_from_file_location('reviewed_suffix_verifier',verifier);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
cohort=out/'adaptation-source-only';cohort.mkdir(exist_ok=True)
mod.unpack(evidence,'suffix-cohort-evidence-v1',cohort)
adapted=mod.adapted_auditor(cohort).read_text();original_source=(cohort/'review/audit-hosted.py').read_text()
anchor="    fixture=read(frozen/'test/perf/dictionaries.lock.json')"
assert adapted[adapted.index(anchor):]==original_source[original_source.index(anchor):]
checks={'status':'PASS','noNewAcquisition':True,'independentGitObjects':len(objects),'independentGitPaths':len(m['files']),'retainedRoutineTailSha256':sha(original_source[original_source.index(anchor):].encode()),'tailBytes':len(original_source[original_source.index(anchor):].encode()),'finalVerifierSha256':sha(raw),'sourceProofSha256':sha(proof.read_bytes()),'cohortWrapperSha256':sha(evidence.read_bytes()),'compactEqualsFullExceptPackageBytesRecheckedFlag':True,'semanticReceipts':compact['semanticReceipts'],'rawMemoryScans':compact['rawMemoryScans'],'finalCaseCount':len(runs),'unexpectedFinalGitOutputCreated':marker.exists()}
# raw was shadowed only inside helper local scopes; verifier identity is bound explicitly.
checks['finalVerifierSha256']=sha(verifier.read_bytes())
(out/'independent-mechanical-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks),flush=True)
