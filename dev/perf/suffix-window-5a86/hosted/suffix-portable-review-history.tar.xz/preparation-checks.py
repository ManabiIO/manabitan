from pathlib import Path
import json,subprocess,hashlib,time
out=Path('/home/agent/manabitan-suffix-portable-review-profile-5a86');out.mkdir(exist_ok=True)
script=Path('/home/agent/manabitan-suffix-browser-audit-5a86/verify-suffix-cohort.py')
proof=Path('/home/agent/manabitan-suffix-browser-audit-5a86/source-proof/source-proof.json.txt')
evidence=Path('/home/agent/manabitan-suffix-jitendex-ab-audit-5a86/durable/hosted-jitendex-AB.json.txt')
original=Path('/home/agent/manabitan-suffix-jitendex-ab-audit-5a86/artifact.zip')
expected='e4a13672188f33800bfef8badb7434076bc0ca26eb34439b2dfbbb02da294c1c'
assert hashlib.sha256(script.read_bytes()).hexdigest()==expected
runs=[]
def run(name,args):
 start=time.time()
 with (out/(name+'.stdout')).open('wb') as so,(out/(name+'.stderr')).open('wb') as se:
  r=subprocess.run(args,stdout=so,stderr=se)
 d={'name':name,'command':list(map(str,args)),'exitCode':r.returncode if r.returncode>=0 else None,'signal':-r.returncode if r.returncode<0 else None,'elapsedSeconds':time.time()-start}
 for k in ['stdout','stderr']:
  b=(out/(name+'.'+k)).read_bytes();d[k]={'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
 runs.append(d);(out/'receipts.json').write_text(json.dumps(runs,indent=2)+'\n')
 print(json.dumps(d),flush=True)
 return r.returncode
common=['python3','-B',str(script),'--evidence',str(evidence),'--source-proof',str(proof)]
assert run('compact',common)==0
assert run('full',common+['--original-artifact',str(original)])==0
bad=json.loads(evidence.read_text());bad['manifest']['packageLimitation']='All original product ZIP payloads are retained and independently reverified by this compact audit.'
badpath=out/'false-package-completeness.json.txt';badpath.write_text(json.dumps(bad))
run('false-package-completeness',['python3','-B',str(script),'--evidence',str(badpath),'--source-proof',str(proof)])
assert run('optimized-python',['python3','-O','-B',str(script),'--evidence',str(evidence),'--source-proof',str(proof)])!=0
print('CHECKS_COMPLETE',flush=True)
