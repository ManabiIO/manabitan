#!/usr/bin/env python3
"""Bounded consolidation review of retained observations; never run imports."""
from pathlib import Path
import base64
import difflib
import hashlib
import io
import json
import math
import random
import statistics
import subprocess
import tarfile

ROOT = Path('/home/agent/manabitan-suffix-final-evidence-5a86')
OUT = Path(__file__).parent
REPO = Path('/workspace/scratch/5a86d1e7822a/manabitan')
BASE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CAND = '38031a752b26c9b630e5f2f1d45e780786656c74'
EXPECTED = {
    'results.json.txt': 'f04c20823e23e0cc857187002355de7589e7baa6f024225b9b17a4f03bbe3097',
    'handoff-proposed.md': '7a6c70bc452c17c12d03844d5d50ec133cf2a03e42efc5154fe85f04b47e3acf',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def same(actual, expected):
    if isinstance(expected, dict):
        assert isinstance(actual, dict) and set(actual) == set(expected)
        for key in expected:
            same(actual[key], expected[key])
    elif isinstance(expected, list):
        assert isinstance(actual, list) and len(actual) == len(expected)
        for left, right in zip(actual, expected):
            same(left, right)
    elif isinstance(expected, float):
        assert math.isclose(actual, expected, rel_tol=0, abs_tol=1e-11), (actual, expected)
    else:
        assert actual == expected, (actual, expected)


def paired(observations, kind, right, expected_count):
    pairs = {}
    for item in observations:
        if item['kind'] != kind:
            continue
        record = pairs.setdefault(item['pair'], {})
        assert item['arm'] not in record
        assert item['totalImportMs'] > 0 and math.isfinite(item['totalImportMs'])
        record[item['arm']] = item['totalImportMs']
    assert sorted(pairs) == list(range(1, expected_count + 1))
    values = [pairs[index] for index in sorted(pairs)]
    assert all(set(item) == {'A', right} for item in values)
    ratios = [item[right] / item['A'] for item in values]
    rng = random.Random(897)
    bootstrap = sorted(statistics.median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
    return {
        'count': len(ratios), 'ratios': ratios,
        'medianPairedChangePercent': 100 * (statistics.median(ratios) - 1),
        'equalWorkChangePercent': 100 * (sum(item[right] for item in values) / sum(item['A'] for item in values) - 1),
        'worstPairChangePercent': 100 * (max(ratios) - 1),
        'descriptiveBootstrap95Percent': [100 * (bootstrap[index] - 1) for index in (249, 9749)],
        'fasterPairs': sum(ratio < 1 for ratio in ratios),
    }


def main():
    assert __debug__
    for name, digest in EXPECTED.items():
        assert sha((ROOT / name).read_bytes()) == digest
    report = read(ROOT / 'results.json.txt')
    assert report['baseline'] == BASE and report['candidate'] == CAND
    assert report['candidateTree'] == 'a05ece005d9fb4931cb1fc24f0cb67ceb109a7f5'
    assert report['runId'] == 46104813593
    assert report['status'] == 'CLOSED_NO_REVIEW_WORTHY_IMPORT_GAIN'
    assert report['noNewAcquisition'] and report['noPullRequest']
    assert [(cell['dictionary'], cell['order']) for cell in report['cohorts']] == [
        (dictionary, order) for dictionary in ('jmdict', 'jitendex', 'vndb') for order in ('AB', 'BA')
    ]
    checked = []
    retained_originals = 0
    for cell in report['cohorts']:
        dictionary, order = cell['dictionary'], cell['order']
        root = Path(f'/home/agent/manabitan-suffix-{dictionary}-{order.lower()}-audit-5a86')
        prefix = f'{dictionary}-{order}'
        raw_audit = (root / 'independent-audit.json').read_bytes()
        audit = json.loads(raw_audit)
        assert cell['independentOriginalAuditSha256'] == sha(raw_audit)
        assert audit['status'] == 'PASS' and audit['semanticReceiptCount'] == 42
        assert audit['prescribedObservationsVerified'] == 42 and len(audit['bindings']) == 42
        assert audit['packageEntriesChecked'] == {'A': 554, 'B': 554}
        assert audit['source']['A']['sha'] == BASE and audit['source']['B']['sha'] == CAND
        assert audit['packageChangedEntries'] == ['js/dictionary/wasm/term-bank-parser.c', 'lib/term-bank-parser.wasm']
        assert cell['artifact'] == audit['artifactMetadata']
        assert cell['artifact']['workflow_run']['id'] == 46104813593
        assert cell['artifact']['workflow_run']['head_sha'] == CAND
        assert cell['artifact']['name'] == f'suffix-window-{prefix}-5a86'
        assert cell['imports'] == 42 and cell['rawMemoryScans'] == audit['memoryRawAudit']['rawScanCount']
        assert cell['analysis'] == audit['analysisRecomputed'] and cell['memoryAudit'] == audit['memoryRawAudit']
        observations = read(root / prefix / 'observations.json')
        assert len(observations) == 36
        assert sum(item['kind'] == 'warmup' for item in observations) == 4
        candidate = paired(observations, 'candidate', 'B', 12)
        control = paired(observations, 'control', 'C', 4)
        same(cell['analysis']['candidateVsBaseline'], candidate)
        same(cell['analysis']['identicalCodeControl'], control)
        assert candidate['descriptiveBootstrap95Percent'][0] < 0 < candidate['descriptiveBootstrap95Percent'][1]
        comparison = read(root / prefix / 'memory/memory-comparison.json')
        assert cell['memoryComparison'] == comparison
        memory_obs = read(root / prefix / 'memory/observations.json')
        assert comparison['observations'] == memory_obs and len(memory_obs) == 4
        passed = dictionary != 'vndb'
        assert cell['analysis']['memoryPassed'] is passed
        assert cell['memoryAudit']['passesProspectiveMemoryScreen'] is passed
        assert comparison['passesProspectiveMemoryScreen'] is passed
        failed = [item for item in memory_obs if not item['qualifiedForWholeTreePss']]
        if passed:
            assert not failed
            for metrics in comparison['metrics'].values():
                assert metrics['medianPairedChangePercent'] <= 5
                assert metrics['maximumPairedChangePercent'] <= 10
        else:
            assert len(failed) == 1 and failed[0]['name'] == 'A1'
            assert failed[0]['maximumCoveredSampleGapMs'] == (254.012525 if order == 'AB' else 356.501319)
            assert failed[0]['qualificationFailures'] == ['covered-import-scan-gap-over-250ms']
            assert all(value is None for metrics in comparison['metrics'].values() for value in metrics.values())
            assert all(value is None for metrics in cell['memoryAudit']['metrics'].values() for value in metrics.values())
        wrapper_path = root / 'durable' / f'hosted-{prefix}.json.txt'
        raw_wrapper = wrapper_path.read_bytes()
        assert cell['wrapper'] == {
            'file': prefix + '.json.txt', 'bytes': len(raw_wrapper), 'sha256': sha(raw_wrapper),
            'gitBlob': hashlib.sha1(b'blob ' + str(len(raw_wrapper)).encode() + b'\0' + raw_wrapper).hexdigest(),
        }
        wrapper = json.loads(raw_wrapper)
        assert wrapper['format'] == 'suffix-cohort-evidence-v1' and wrapper['encoding'] == 'base64'
        manifest = wrapper['manifest']
        assert manifest['originalAuditSha256'] == sha(raw_audit)
        assert manifest['originalArtifact'] == cell['artifact']
        assert manifest['archive'] == cell['preservedArchive']
        assert manifest['packageLimitation'] == cell['packageLimitation']
        raw_archive = base64.b64decode(wrapper['archive'], validate=True)
        assert len(raw_archive) == manifest['archive']['bytes'] and sha(raw_archive) == manifest['archive']['sha256']
        with tarfile.open(fileobj=io.BytesIO(raw_archive), mode='r:xz') as archive:
            proof = json.loads(archive.extractfile('original-artifact-proof.json').read())
            assert len(proof['originalMembers']) == 315
            omitted = [item['path'] for item in proof['originalMembers'] if not item['retained']]
            assert set(omitted) == {prefix + '/package-A.zip', prefix + '/package-B.zip'}
            assert all(len(proof['packages'][arm]['entries']) == 554 for arm in ('A', 'B'))
            assert sum(name.startswith('original/') for name in manifest['members']) == 313
            assert archive.extractfile('review/independent-audit.json').read() == raw_audit
        retained_originals += 313
        checked.append({
            'dictionary': dictionary, 'order': order, 'artifactId': cell['artifact']['id'],
            'auditSha256': sha(raw_audit), 'wrapperSha256': sha(raw_wrapper),
            'imports': 42, 'rawMemoryScans': cell['rawMemoryScans'],
            'medianPairedChangePercent': candidate['medianPairedChangePercent'],
            'equalWorkChangePercent': candidate['equalWorkChangePercent'],
            'fasterPairs': candidate['fasterPairs'], 'interval': candidate['descriptiveBootstrap95Percent'],
            'controlMedianPercent': control['medianPairedChangePercent'],
            'memoryPassed': passed,
            'failedMemoryObservation': None if not failed else {
                'name': failed[0]['name'], 'maximumCoveredSampleGapMs': failed[0]['maximumCoveredSampleGapMs'],
            },
        })
    assert sum(item['imports'] for item in checked) == report['auditedCompleteImports'] == 252
    assert sum(item['rawMemoryScans'] for item in checked) == report['auditedRawMemoryScans'] == 2153
    assert sum(item['memoryPassed'] for item in checked) == 4
    assert not report['allMemoryCellsPassed'] and report['allSixOriginalArtifactAuditsPassed']
    assert retained_originals == 1878
    original = (ROOT / 'handoff-original.md').read_bytes()
    from_git = subprocess.check_output(['git', 'show', 'a8c890c81b755e56d66468fc809e6c90f6f660f1:dev/perf/import-experiments-20260914.md'], cwd=REPO)
    assert original == from_git
    updated = (ROOT / 'handoff-proposed.md').read_bytes()
    old_lines, new_lines = original.splitlines(keepends=True), updated.splitlines(keepends=True)
    operations = difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_opcodes()
    changes = [item for item in operations if item[0] != 'equal']
    assert len(changes) == 2 and all(item[0] == 'insert' for item in changes)
    text = updated.decode()
    supplement = (ROOT / 'hosted-supplement.md').read_text()
    assert supplement in text
    names = {'jmdict': 'JMdict', 'jitendex': 'Jitendex', 'vndb': 'VNDB'}
    for item in checked:
        low, high = item['interval']
        row = '| ' + ' | '.join([
            names[item['dictionary']] + ' ' + item['order'],
            f"{item['medianPairedChangePercent']:+.4f}%", f"{item['equalWorkChangePercent']:+.4f}%",
            f"{item['fasterPairs']}/12", f'[{low:+.4f}%, {high:+.4f}%]',
            f"{item['controlMedianPercent']:+.4f}%", 'pass' if item['memoryPassed'] else 'coverage failure',
        ]) + ' |'
        assert row in supplement
    for expected in ('+116.9095%', '+9.4844%', '+27.8094%', '254.012525 ms', '356.501319 ms',
                     '1,878 non-package original', 'all 554 member identities per arm',
                     'browser content\nprobes remain sampled', 'stop without a performance PR',
                     'package is absent', 'suffix-window-5a86/hosted/results.json.txt',
                     'dev/perf/suffix-window-5a86/hosted/jmdict-AB.json.txt',
                     'dev/perf/suffix-window-5a86/hosted/source-proof.json.txt'):
        assert expected in supplement, expected
    proof = read(Path('/home/agent/manabitan-suffix-browser-audit-5a86/source-proof/manifest.json'))
    assert len(proof['objects']) == report['sourceProof']['gitObjects'] == 52
    assert len(proof['files']) == report['sourceProof']['exactPaths'] == 36
    assert proof['archive']['sha256'] == report['sourceProof']['archiveSha256']
    verifier = Path('/home/agent/manabitan-suffix-browser-audit-5a86/verify-suffix-cohort.py')
    assert sha(verifier.read_bytes()) == report['portableVerifier']['sha256'] == '6cbf0035c62485ea4e5074a1d00d7665292f3a8003e414e552181f23e7c65bab'
    formatter = read(ROOT / 'documentation-format-attempt.json')
    assert formatter['exitCode'] == 1 and 'missing packages' in formatter['stderr']
    assert formatter['command'] == ['npx', '--no-install', '--offline', 'prettier', 'AGENTS.md', '--check']
    result = {
        'schemaVersion': 1, 'status': 'PASS', 'kind': 'Independent bounded suffix consolidation review',
        'inputs': {name: {'bytes': (ROOT / name).stat().st_size, 'sha256': digest} for name, digest in EXPECTED.items()},
        'source': {'baseline': BASE, 'candidate': CAND, 'candidateTree': report['candidateTree'], 'runId': report['runId']},
        'checks': {
            'allSixAuditAndArchiveBindings': True, 'allCandidateAndControlStatisticsRecomputedFromRetainedObservations': True,
            'allTailsRetained': True, 'fourPassingAndTwoCoverageFailedMemoryCellsPreserved': True,
            'failedWholeCohortAggregateMetricsRemainNull': True, 'originalHandoffMatchesEvidenceParentGitBlob': True,
            'originalHandoffPreservedWithTwoInsertionsOnly': True, 'tableMatchesExactCohortStatistics': True,
            'proposedRelativePathsConsistent': True, 'originalPackageOmissionsExplicitAndExact': True,
            'sourceProofAndUnchangedVerifierIdentitiesMatch': True, 'noGainNoPullRequestDecisionSupported': True,
            'formattingFailureAccuratelyDisclosed': True,
        },
        'totals': {'imports': 252, 'rawMemoryScans': 2153, 'retainedNonPackageOriginalMembers': 1878,
                   'omittedOriginalProductZipPayloads': 12, 'memoryPassingCells': 4, 'memoryCoverageFailedCells': 2},
        'cells': checked,
        'limitations': [
            'This review recomputes consolidation statistics from retained observations and compares existing original-artifact audits. It does not rerun imports, corpus proof, memory acquisition, adversarial verifier probes or product tests.',
            'Every timing interval spans zero; opposite-order hosts remain separate. No pooling, trimming or control subtraction is introduced.',
            'Memory coverage failures are unqualified memory evidence, not measured memory regressions. Sampled PSS/private maxima are not exact peaks.',
            'Complete-corpus scope was already independently reviewed: live output digests, not direct retained-after-reuse arrays. Browser content checks remain sampled and exhaustive-media diagnostics are separate imports.',
            'Compact wrappers omit original ZIP containers and twelve product ZIP payloads. Original full-package audits remain bound; repeating omitted-byte verification requires the matching originals.',
            'The original documentation-only formatter attempt failed because Prettier was unavailable. This review does not claim a formatting pass or change frozen product validation.',
        ],
        'newImportAcquisition': False, 'productMutations': False, 'publicationOwner': '/root',
    }
    destination = OUT / 'review.json'
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': 'PASS', 'review': str(destination), 'bytes': destination.stat().st_size,
                      'sha256': sha(destination.read_bytes()), 'imports': 252, 'scans': 2153}))


if __name__ == '__main__':
    main()
