// Diagnostic style/JSDoc subset only; not the repository ESLint gate.
import fs from 'node:fs';
import vm from 'node:vm';
import {parse} from 'espree';
import stylistic from '@stylistic/eslint-plugin';
import jsdoc from 'eslint-plugin-jsdoc';
const source = fs.readFileSync(new URL('../../eslint.config.js', import.meta.url), 'utf8');
const tree = parse(source, {ecmaVersion: 'latest', sourceType: 'module', range: true});
const rules = {};
let found = false;
function visit(node) {
    if (!node || typeof node !== 'object') { return; }
    if (!found && node.type === 'Property' && node.key?.name === 'rules' && node.value?.type === 'ObjectExpression' && node.value.properties.length > 100) {
        found = true;
        for (const property of node.value.properties) {
            const name = property.key.value;
            if (typeof name === 'string' && (name.startsWith('@stylistic/') || name.startsWith('jsdoc/'))) {
                rules[name] = vm.runInNewContext('(' + source.slice(...property.value.range) + ')');
            }
        }
    }
    for (const child of Object.values(node)) {
        if (Array.isArray(child)) { for (const item of child) { visit(item); } }
        else if (child && typeof child === 'object') { visit(child); }
    }
}
visit(tree);
if (!found) { throw new Error('Base lint rules were not found'); }
for (const name of ['@stylistic/eol-last', '@stylistic/padding-line-between-statements', '@stylistic/quote-props', 'jsdoc/no-undefined-types', 'jsdoc/require-jsdoc', 'jsdoc/require-returns-check', 'jsdoc/require-throws']) { rules[name] = 'off'; }
export default [{files: ['test/**/*.js'], plugins: {'@stylistic': stylistic, jsdoc}, languageOptions: {ecmaVersion: 2022, sourceType: 'module'}, rules}];
