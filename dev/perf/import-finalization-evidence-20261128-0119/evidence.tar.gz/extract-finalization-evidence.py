#!/usr/bin/env python3
"""Extract existing baseline phases; this does not acquire new timing samples."""

import argparse
import hashlib
import json
import pathlib
import statistics

BASELINE = "9e10d3b3fcf66d344ab31bc42c9b522fa5215da2"
SOURCE_FILES = [
    "ext/js/dictionary/term-record-opfs-store.js",
    "ext/js/dictionary/term-record-import-index-writer.js",
    "ext/js/dictionary/term-content-opfs-store.js",
    "ext/js/dictionary/dictionary-database.js",
    "ext/js/dictionary/dictionary-importer.js",
    "ext/js/dictionary/term-lookup-index.js",
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def find_phases(value):
    if isinstance(value, dict):
        if isinstance(value.get("importerPhaseTimings"), list):
            return value["importerPhaseTimings"]
        children = value.values()
    elif isinstance(value, list):
        children = value
    else:
        return None
    for child in children:
        result = find_phases(child)
        if result is not None:
            return result
    return None


def extract(path, root):
    document = json.loads(path.read_text())
    phases = find_phases(document)
    assert phases is not None
    by_name = {phase["phase"]: phase for phase in phases}
    fast = next(phase for phase in phases if phase["phase"].startswith("term-file-fast-path:"))
    banks = by_name["import-data-banks"]
    final = by_name["bulk-finalization"]
    return {
        "path": str(path.relative_to(root)),
        "sha256": digest(path),
        "reportedSource": document.get("source"),
        "fixture": document.get("fixture"),
        "fastPathEndEpochMs": fast["endEpochMs"],
        "fastPathChunkCount": fast["details"]["chunkCount"],
        "postTermBankTailMs": banks["endEpochMs"] - fast["endEpochMs"],
        "bankEndToFinalizationMs": final["startEpochMs"] - banks["endEpochMs"],
        "bulkElapsedMs": final["elapsedMs"],
        "finalizationStartEpochMs": final["startEpochMs"],
        "finalizationEndEpochMs": final["endEpochMs"],
        "finalizationDetails": final["details"],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--evidence-root", type=pathlib.Path, required=True)
    parser.add_argument("--source-root", type=pathlib.Path, required=True)
    parser.add_argument("--output", type=pathlib.Path, required=True)
    args = parser.parse_args()
    sources = {name: digest(args.source_root / name) for name in SOURCE_FILES}
    output = {
        "source": BASELINE,
        "sourceHashes": sources,
        "scope": "Read-only extraction of all twelve ordinary baseline A observations from run 46101323881, kept by host. No candidate timings, controls, warmups, memory imports, exclusions, or new experiments. Phase waits overlap other work; they do not predict a whole-import gain.",
        "hosts": {},
    }
    for host in ("AB", "BA"):
        folder = args.evidence_root / "batching-run-46101323881" / host
        identity_path = folder / "source-identities.json"
        identity = json.loads(identity_path.read_text())
        packaged = identity["arms"]["A"]["entries"]
        for name, expected in sources.items():
            assert packaged[name.removeprefix("ext/")] == expected, (host, name)
        observations = []
        for pair in range(1, 7):
            path = folder / f"pair-{pair:02d}-A" / "summary.json"
            document = json.loads(path.read_text())
            assert document["gitSha"] == BASELINE
            assert document["source"]["gitSha"] == BASELINE and document["source"]["dirty"] is False
            assert document["authoritativeTiming"] is True and document["traceEnabled"] is False
            observations.append(extract(path, args.evidence_root))
        keys = [key for key, value in observations[0]["finalizationDetails"].items() if key.endswith("Ms") and isinstance(value, (int, float))]
        statistics_by_key = {}
        for key in ["bulkElapsedMs", "postTermBankTailMs", *keys]:
            values = [row[key] if key in row else row["finalizationDetails"][key] for row in observations]
            statistics_by_key[key] = {"min": min(values), "median": statistics.median(values), "max": max(values)}
        output["hosts"][host] = {
            "sourceIdentityPath": str(identity_path.relative_to(args.evidence_root)),
            "sourceIdentitySha256": digest(identity_path),
            "observations": observations,
            "statistics": statistics_by_key,
        }
    diagnostic = args.evidence_root / "jmdict-profile-9e10d3b3" / "run-1.json"
    output["diagnosticOnly"] = extract(diagnostic, args.evidence_root)
    output["diagnosticOnly"]["scope"] = "Instrumented separate host; its 118.4 ms close region is not an ordinary baseline median or a candidate opportunity estimate."
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"output": str(args.output), "sha256": digest(args.output), "ordinaryObservations": 12}))


if __name__ == "__main__":
    main()
