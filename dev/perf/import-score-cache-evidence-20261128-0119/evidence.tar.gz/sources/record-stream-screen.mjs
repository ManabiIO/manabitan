import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {replayParserCorpus} from '/tmp/manabitan-research-0119/parser-replay.mjs';
import * as candidate from '../../ext/js/dictionary/term-record-opfs-store.js';

const [dictionary='jitendex',baselinePath='/tmp/manabitan-baseline-0119',label='hybrid',expectedCandidate='6de0feba161110df77a467dd6d477bdd674604ba7796bf42195f45a0883512ad']=process.argv.slice(2);
const root=process.cwd();
const baselineRoot=resolve(baselinePath);
const baselineSourcePath=join(baselineRoot,'ext/js/dictionary/term-record-opfs-store.js');
const sourceHash=async(path)=>createHash('sha256').update(await readFile(path)).digest('hex');
const baselineRecordSourceSha256=await sourceHash(baselineSourcePath);
const candidateRecordSourceSha256=await sourceHash('ext/js/dictionary/term-record-opfs-store.js');
assert.equal(baselineRecordSourceSha256,'7325a63fa3d054a3c8b426c87880671ca57f5956dce842d9daef4acd4d617594');
assert.equal(candidateRecordSourceSha256,expectedCandidate);
const baseline=await import(pathToFileURL(baselineSourcePath));
const stores={baseline:new baseline.TermRecordOpfsStore(),candidate:new candidate.TermRecordOpfsStore()};
const fieldsHash=createHash('sha256');
const groups=[];
let base=2**40;
const emptyOffsets=new Float64Array(0),emptyLengths=new Uint32Array(0);
const repetitions=3,pairsPerGroup=4,warmupsPerArm=2;

function encode(arm,input){return stores[arm]._encodeArtifactRecordFields(input,emptyOffsets,emptyLengths,base);}
function measure(arm,input){let bytes=0;const start=performance.now();for(let i=0;i<repetitions;i++){bytes+=encode(arm,input).byteLength;}return {ms:performance.now()-start,bytes};}
const parserReport=await replayParserCorpus({root,cacheDir:'../manabitan/builds/e2e-dictionary-cache',dictionary,onChunk:(chunk,_progress,{groupIndex,fixture})=>{
    const plan=chunk.contentDedupPlan;
    assert(plan&&chunk.contentUniqueIndexList&&chunk.contentMetaList);
    assert(chunk.scoreList instanceof Int32Array);
    const offsets=new Float64Array(plan.uniqueCount),lengths=new Uint32Array(plan.uniqueCount);
    for(let i=0;i<plan.uniqueCount;i++){const meta=(chunk.contentMetaByUniqueIndex?i:plan.uniqueRowIndexes[i])*4;offsets[i]=base+chunk.contentMetaList[meta];lengths[i]=chunk.contentMetaList[meta+1];}
    const inputs={};
    for(const [arm,mod] of [['baseline',baseline],['candidate',candidate]]){
        inputs[arm]=mod.createArtifactTermRecordChunkWithResolvedContent({rowCount:chunk.rowCount,scoreList:chunk.scoreList},chunk.contentUniqueIndexList,offsets,lengths);
    }
    const expected=encode('baseline',inputs.baseline),actual=encode('candidate',inputs.candidate);
    assert.deepEqual(actual,expected);
    fieldsHash.update(actual);
    const compact=actual.byteLength<chunk.rowCount*12;
    const prefixCacheEligible=chunk.rowCount>=64&&chunk.scoreList.subarray(0,Math.min(32,chunk.rowCount)).some(score=>score< -256||score>=256);
    const values=new Int32Array(512),seen=new Uint8Array(512),unique=new Set();
    let hits=0,collisions=0,inlineScores=0,adjacent=0,lengthFallbackRow=null;
    for(let i=0;i<chunk.rowCount;i++){
        const score=chunk.scoreList[i],slot=score&511;
        if(seen[slot]&&values[slot]===score){hits++;}else{if(seen[slot])collisions++;seen[slot]=1;values[slot]=score;}
        unique.add(score);
        if(score>=-256&&score<256)inlineScores++;
        if(i>0&&score===chunk.scoreList[i-1])adjacent++;
        if(lengthFallbackRow===null&&lengths[chunk.contentUniqueIndexList[i]]>=65535)lengthFallbackRow=i;
    }
    for(let n=0;n<warmupsPerArm;n++)for(const arm of groupIndex%2?['candidate','baseline']:['baseline','candidate'])encode(arm,inputs[arm]);
    const pairs=[];
    for(let pair=0;pair<pairsPerGroup;pair++){
        const order=(groupIndex+pair)%2?['candidate','baseline']:['baseline','candidate'];
        const result={order};
        for(const arm of order)result[arm]=measure(arm,inputs[arm]);
        assert.equal(result.baseline.bytes,result.candidate.bytes);
        result.change=result.candidate.ms/result.baseline.ms-1;
        pairs.push(result);
    }
    groups.push({groupIndex,rows:chunk.rowCount,compact,prefixCacheEligible,fieldBytes:actual.byteLength,hits,misses:chunk.rowCount-hits,collisions,distinctScores:unique.size,inlineScores,adjacent,lengthFallbackRow,pairs});
    base+=chunk.contentBytesLength??chunk.contentBytesBuffer.byteLength;
    if(groups.length%20===0)process.stderr.write(`${dictionary}: ${groups.reduce((sum,g)=>sum+g.rows,0)}/${fixture.termRows} rows\n`);
}});
const sum=(get)=>groups.reduce((total,group)=>total+get(group),0);
const raw=groups.flatMap((group)=>group.pairs);
const median=(input)=>{const x=[...input].sort((a,b)=>a-b);return x.length%2?x[(x.length-1)/2]:(x[x.length/2-1]+x[x.length/2])/2;};
const rows=sum((g)=>g.rows),baselineTotalMs=raw.reduce((s,p)=>s+p.baseline.ms,0),candidateTotalMs=raw.reduce((s,p)=>s+p.candidate.ms,0);
const report={...parserReport,scope:'Streaming _encodeArtifactRecordFields only on actual production parser groups with deterministic resolved native spans. Native workers may overlap callback timings. Excludes parsing, source reads, compression, storage and restart from timed samples; no whole-import latency claim.',baselineRoot,baselineRecordSourceSha256,candidateRecordSourceSha256,repetitions,pairsPerGroup,warmupsPerArm,summary:{rows,groups:groups.length,pairs:raw.length,compactRows:sum(g=>g.compact?g.rows:0),legacyRows:sum(g=>g.compact?0:g.rows),hits:sum(g=>g.hits),hitRate:sum(g=>g.hits)/rows,collisions:sum(g=>g.collisions),inlineScoreCoverage:sum(g=>g.inlineScores)/rows,adjacentScoreRate:sum(g=>g.adjacent)/rows,baselineTotalMs,candidateTotalMs,equalWorkChange:candidateTotalMs/baselineTotalMs-1,pairedMedianChange:median(raw.map(p=>p.change)),fasterPairs:raw.filter(p=>p.change<0).length,fieldByteSha256:fieldsHash.digest('hex')},fieldGroups:groups};
report.summary.prefixCacheEligibleGroups=groups.filter(g=>g.prefixCacheEligible).length;report.summary.prefixCacheEligibleRows=sum(g=>g.prefixCacheEligible?g.rows:0);
await writeFile(`builds/research-0119/${dictionary}-record-stream-screen-${label}-node24.json`,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({dictionary,node:process.version,...report.summary}));
