import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {deserialize} from 'node:v8';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import * as candidate from '../../ext/js/dictionary/term-record-opfs-store.js';
const [name='jmdict',out='record-screen.json',repetitions='10',baselinePath='/tmp/manabitan-baseline-0119',expectedCandidate='6de0feba161110df77a467dd6d477bdd674604ba7796bf42195f45a0883512ad'] = process.argv.slice(2);
const baselineSourcePath=join(resolve(baselinePath),'ext/js/dictionary/term-record-opfs-store.js');
const baselineSourceSha256=createHash('sha256').update(await readFile(baselineSourcePath)).digest('hex');
assert.equal(baselineSourceSha256,'7325a63fa3d054a3c8b426c87880671ca57f5956dce842d9daef4acd4d617594');
assert.equal(createHash('sha256').update(await readFile('ext/js/dictionary/term-record-opfs-store.js')).digest('hex'),expectedCandidate);
const baseline=await import(pathToFileURL(baselineSourcePath));
const captures=deserialize(await readFile(`builds/research-0119/${name}-capture.json.fields`));
function prepare(mod) { const store = new mod.TermRecordOpfsStore(); return {store,groups:captures.map(({rowCount,scoreList,references,offsets,lengths,base})=>({chunk:mod.createArtifactTermRecordChunkWithResolvedContent({rowCount,scoreList},references.uniqueIndexList,references.offsets,references.lengths),offsets,lengths,base}))}; }
const a=prepare(baseline),b=prepare(candidate);
const digest=createHash('sha256');
for(let i=0;i<captures.length;i++) { const x=a.groups[i],y=b.groups[i];const left=a.store._encodeArtifactRecordFields(x.chunk,x.offsets,x.lengths,x.base),right=b.store._encodeArtifactRecordFields(y.chunk,y.offsets,y.lengths,y.base);assert.deepEqual(left,right);digest.update(left); }
function run({store,groups},reps) {let bytes=0;const start=performance.now();for(let n=0;n<reps;n++)for(const {chunk,offsets,lengths,base} of groups){ const out=store._encodeArtifactRecordFields(chunk,offsets,lengths,base);bytes+=out.byteLength;}return {ms:performance.now()-start,bytes};}
for(let i=0;i<5;i++){run(a,2);run(b,2);}
const results=[];
for(let n=0;n<20;n++) { const order=n%2?['b','a']:['a','b'];const pair={order};for(const k of order)pair[k]=run(k==='a'?a:b,Number(repetitions));pair.ratio=pair.b.ms/pair.a.ms-1;results.push(pair);}
const median=(input)=>{const x=[...input].sort((a,b)=>a-b);return x.length%2?x[(x.length-1)/2]:(x[x.length/2-1]+x[x.length/2])/2;};
const report={name,node:process.version,rows:captures.reduce((s,c)=>s+c.rowCount,0),groups:captures.length,component:'_encodeArtifactRecordFields only; actual production native parser groups, deterministic native spans, persisted-byte parity',repetitions:Number(repetitions),sourceSha256:createHash('sha256').update(await readFile('ext/js/dictionary/term-record-opfs-store.js')).digest('hex'),digest:digest.digest('hex'),pairedMedian:median(results.map(x=>x.ratio)),baselineMedianMs:median(results.map(x=>x.a.ms)),candidateMedianMs:median(results.map(x=>x.b.ms)),equalWorkRatio:results.reduce((s,x)=>s+x.b.ms,0)/results.reduce((s,x)=>s+x.a.ms,0)-1,results};
report.baselineRoot=resolve(baselinePath);report.baselineSourceSha256=baselineSourceSha256;assert.equal(report.sourceSha256,expectedCandidate);
await writeFile(`builds/research-0119/${out}`,JSON.stringify(report,null,2));console.log(JSON.stringify({...report,results:undefined}));
