import json
import resource
import subprocess
import sys
import time

name, *command = sys.argv[1:]
started = time.monotonic()
with open(f"builds/research-0119/{name}.log", "w") as output:
    result = subprocess.run(command, stdout=output, stderr=subprocess.STDOUT)
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
metrics = {"command": command, "exitCode": result.returncode, "wallSeconds": time.monotonic() - started,
           "maxChildRssKiB": usage.ru_maxrss, "userSeconds": usage.ru_utime, "systemSeconds": usage.ru_stime}
with open(f"builds/research-0119/{name}.metrics.json", "w") as output:
    json.dump(metrics, output, indent=2)
    output.write("\n")
print(json.dumps(metrics), flush=True)
sys.exit(result.returncode if result.returncode >= 0 else 128 - result.returncode)
