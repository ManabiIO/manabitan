import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
const [output='jmdict-cold-hybrid-node24.json',pairs='24',baselinePath='/tmp/manabitan-baseline-0119',expectedCandidate='6de0feba161110df77a467dd6d477bdd674604ba7796bf42195f45a0883512ad']=process.argv.slice(2);
const raw=[];
for(let pair=0;pair<Number(pairs);pair++){
    const order=pair%2?['candidate','baseline']:['baseline','candidate'];
    const result={order};
    for(const arm of order){
        const child=spawnSync(process.execPath,['builds/research-0119/record-cold.mjs',arm,'jmdict',baselinePath,expectedCandidate],{encoding:'utf8'});
        assert.equal(child.status,0,child.stderr);
        result[arm]=JSON.parse(child.stdout);
    }
    assert.equal(result.baseline.digest,result.candidate.digest);
    result.change=result.candidate.ms/result.baseline.ms-1;
    result.cpuChange=result.candidate.cpuMs/result.baseline.cpuMs-1;
    raw.push(result);
}
const median=(input)=>{const x=[...input].sort((a,b)=>a-b);return x.length%2?x[(x.length-1)/2]:(x[x.length/2-1]+x[x.length/2])/2;};
const report={scope:'cold process record-field component only; actual full JMdict parser columns; no whole-import time',node:process.version,v8:process.versions.v8,pairs:Number(pairs),sourceSha256:createHash('sha256').update(await readFile('ext/js/dictionary/term-record-opfs-store.js')).digest('hex'),medianBaselineMs:median(raw.map(x=>x.baseline.ms)),medianCandidateMs:median(raw.map(x=>x.candidate.ms)),medianChange:median(raw.map(x=>x.change)),equalWorkChange:raw.reduce((s,x)=>s+x.candidate.ms,0)/raw.reduce((s,x)=>s+x.baseline.ms,0)-1,medianCpuChange:median(raw.map(x=>x.cpuChange)),equalWorkCpuChange:raw.reduce((s,x)=>s+x.candidate.cpuMs,0)/raw.reduce((s,x)=>s+x.baseline.cpuMs,0)-1,fasterPairs:raw.filter(x=>x.change<0).length,raw};
report.baselineRoot=baselinePath;assert.equal(report.sourceSha256,expectedCandidate);
await writeFile('builds/research-0119/'+output,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({...report,raw:undefined}));
