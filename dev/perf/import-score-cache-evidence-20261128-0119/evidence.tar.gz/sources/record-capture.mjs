/*
 * Copyright (C) 2026 Manabitan authors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
/* eslint @stylistic/semi: ["error", "never"] */

import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {createReadStream, openAsBlob} from 'node:fs'
import {readFile, writeFile} from 'node:fs/promises'
import {join, resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
import {Worker as ThreadWorker} from 'node:worker_threads'
import {serialize} from 'node:v8'
import {BlobReader, Uint8ArrayWriter, ZipReader} from '@zip.js/zip.js'

// Replay the actual source planner and parser workers. Only persistence is
// intercepted. Resolved spans use native content lengths at deterministic
// offsets; this checks record bytes, not compression or whole-database parity.
const [parentPath, candidatePath, cachePath, outputPath, dictionary = 'jmdict', cpus = '4', memory = '8'] = process.argv.slice(2)
assert(parentPath && candidatePath && cachePath && outputPath)
const parentRoot = resolve(parentPath)
const candidateRoot = resolve(candidatePath)
// The CLI explicitly selects the two local source trees to compare.
// eslint-disable-next-line no-unsanitized/method
const localImport = (root, filename) => import(pathToFileURL(join(root, filename)))
const parser = await localImport(candidateRoot, 'ext/js/dictionary/term-bank-wasm-parser.js')
const pipelineModule = await localImport(candidateRoot, 'ext/js/dictionary/term-bank-source-pipeline.js')
const parents = await localImport(parentRoot, 'ext/js/dictionary/term-record-opfs-store.js')
const candidates = await localImport(candidateRoot, 'ext/js/dictionary/term-record-opfs-store.js')
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const lockBytes = await readFile(join(candidateRoot, 'test/perf/dictionaries.lock.json'))
assert.deepEqual(lockBytes, await readFile(join(parentRoot, 'test/perf/dictionaries.lock.json')))
const fixture = JSON.parse(lockBytes).dictionaries[dictionary]
assert(fixture)
const archivePath = join(cachePath, fixture.cacheFile)
const archiveHash = createHash('sha256')
for await (const bytes of createReadStream(archivePath)) { archiveHash.update(bytes) }
assert.equal(archiveHash.digest('hex'), fixture.sha256)
const archive = await openAsBlob(archivePath)
assert.equal(archive.size, fixture.sizeBytes)
const wasm = await readFile(join(candidateRoot, 'ext/lib/term-bank-parser.wasm'))
assert.deepEqual(wasm, await readFile(join(parentRoot, 'ext/lib/term-bank-parser.wasm')))
parser.setTermBankWasmModule(await WebAssembly.compile(wasm))

const terminations = []
const sourceGroups = []
class BrowserWorker extends EventTarget {
    constructor(url) {
        super()
        this.worker = new ThreadWorker(pathToFileURL(join(candidateRoot, 'test/fixtures/parser-settlement/worker-node.mjs')), {workerData: {url: url.href}})
        this.worker.on('message', (data) => this.dispatchEvent(new MessageEvent('message', {data})))
        this.worker.on('error', (error) => {
            const event = new Event('error')
            Object.defineProperty(event, 'message', {value: error.message})
            this.dispatchEvent(event)
        })
        this.worker.on('messageerror', () => this.dispatchEvent(new MessageEvent('messageerror')))
    }

    postMessage(data, transfer) {
        if (data.type === 'parse') {
            sourceGroups.push({id: data.id, files: data.sourceMetadata?.map(({filename}) => filename) ?? null, bytes: data.sourceBuffers.map((buffer) => buffer.byteLength)})
        }
        this.worker.postMessage(data, transfer)
    }

    terminate() { terminations.push(this.worker.terminate()) }
}
globalThis.Worker = BrowserWorker
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: Number(cpus), deviceMemory: Number(memory)}})

const reader = new ZipReader(new BlobReader(archive))
const entries = await reader.getEntries()
const termFiles = entries.filter(({filename}) => /^term_bank_\d+\.json$/.test(filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
const rawReader = new pipelineModule.RawZipPayloadReader(archive)
const sourcePipeline = new pipelineModule.TermBankSourcePipeline({
    termFiles,
    enabled: true,
    read: async (file) => await file.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}),
    readCompressed: async (file, signal) => await rawReader.read(file, signal),
})
const groups = []
const profiles = []
const fullDigest = createHash('sha256')
const capturedFields = []
let rowCount = 0
let contentBase = 2 ** 40

async function encode(module, chunk, offsets, lengths) {
    const store = new module.TermRecordOpfsStore()
    const writes = []
    const copies = {u32: 0, u16: 0}
    const fields = store._encodeArtifactRecordFields.bind(store)
    store._encodeArtifactRecordFields = (...args) => {
        if (module === candidates) {
            const [chunk, offsets, lengths, base] = args
            const references = chunk.resolvedContentReferences
            capturedFields.push({rowCount: chunk.rowCount, scoreList: Int32Array.from(chunk.scoreList), references: {uniqueIndexList: Uint32Array.from(references.uniqueIndexList), offsets: Float64Array.from(references.offsets), lengths: Uint32Array.from(references.lengths)}, offsets: Float64Array.from(offsets), lengths: Uint32Array.from(lengths), base})
        }
        const set32 = Uint32Array.prototype.set
        const set16 = Uint16Array.prototype.set
        // Observe only synchronous field encoding, restoring both builtins even
        // if an encoder throws. No parser or persistence work runs in this scope.
        /* eslint-disable no-extend-native */
        Uint32Array.prototype.set = function count32(source, offset) {
            copies.u32 += source.length * 4
            return set32.call(this, source, offset)
        }
        Uint16Array.prototype.set = function count16(source, offset) {
            copies.u16 += source.length * 2
            return set16.call(this, source, offset)
        }
        try { return fields(...args) } finally {
            Uint32Array.prototype.set = set32
            Uint16Array.prototype.set = set16
        }
        /* eslint-enable no-extend-native */
    }
    store._appendEncodedChunk = async (...args) => { writes.push(args) }
    const recordChunk = module.createArtifactTermRecordChunkWithResolvedContent(
        {...chunk, dictionary: fixture.expectedTitle},
        chunk.contentUniqueIndexList,
        offsets,
        lengths,
        chunk.preparedLookupIndexes,
    )
    await store._encodeAndAppendArtifactChunkForState({}, recordChunk, rowCount + 1, new Float64Array(0), new Uint32Array(0), chunk.termRecordPreinternedPlan, 'raw', chunk.preparedLookupIndexes)
    return {writes, copies}
}

async function consume(chunk) {
    const plan = chunk.contentDedupPlan
    assert(plan && chunk.contentUniqueIndexList && chunk.contentMetaList)
    const offsets = new Float64Array(plan.uniqueCount)
    const lengths = new Uint32Array(plan.uniqueCount)
    for (let i = 0; i < plan.uniqueCount; ++i) {
        const meta = (chunk.contentMetaByUniqueIndex ? i : plan.uniqueRowIndexes[i]) * 4
        offsets[i] = contentBase + chunk.contentMetaList[meta]
        lengths[i] = chunk.contentMetaList[meta + 1]
    }
    const before = await encode(parents, chunk, offsets, lengths)
    const after = await encode(candidates, chunk, offsets, lengths)
    assert.deepEqual(after.writes, before.writes)
    for (const args of after.writes) {
        fullDigest.update(args[5])
        fullDigest.update(args[6])
    }
    groups.push({rows: chunk.rowCount, prepared: [...chunk.preparedLookupIndexes.keys()], runRows: after.writes.map((args) => args[2]), parentCopies: before.copies, candidateCopies: after.copies})
    rowCount += chunk.rowCount
    contentBase += chunk.contentBytesLength ?? chunk.contentBytesBuffer.byteLength
    process.stderr.write(`${dictionary}: ${rowCount}/${fixture.termRows} rows\n`)
}

const media = fixture.mediaFiles > 0
const options = {
    emitTermByteLists: false,
    computeContentHashes: true,
    emitContentSlab: true,
    emitTokenBinaryContent: true,
    mediaHintFastScan: media,
    projectImagePaths: media,
    validateGlossaryTypes: true,
    prepareLookupIndexes: true,
    maxPendingChunks: 2,
}
let complete = false
let error = null
try {
    for (let start = 0; start < termFiles.length;) {
        const compressedPlan = sourcePipeline.createCompressedImportRunPlan(start)
        if (compressedPlan !== null) {
            assert.equal(await parser.parseTermBankWithWasmColumnChunksParallelCompressedLazy(compressedPlan.loaders, compressedPlan.estimatedByteLengths, 3, consume, options), true)
            profiles.push(parser.consumeLastTermBankWasmParseProfile())
            sourcePipeline.releaseBatch(compressedPlan.files)
            start += compressedPlan.files.length
        } else {
            const files = sourcePipeline.getBatch(start)
            const batch = await sourcePipeline.readBatch(files)
            if (batch?.promises) {
                assert.equal(await parser.parseTermBankWithWasmColumnChunksParallelDeferred(batch.promises, batch.estimatedByteLengths, 3, consume, options), true)
            } else {
                await parser.parseTermBankWithWasmColumnChunks(batch, 3, consume, 2048, {...options, singleChunk: true})
            }
            profiles.push(parser.consumeLastTermBankWasmParseProfile())
            sourcePipeline.releaseBatch(files)
            start += files.length
        }
    }
    assert.equal(rowCount, fixture.termRows)
    complete = true
} catch (failure) {
    error = String(failure)
    throw failure
} finally {
    await sourcePipeline.dispose()
    await parser.disposeParallelTermBankParser()
    await Promise.all(terminations)
    await reader.close()
    const summary = {rows: 0, runs: 0, parentCopyBytes: 0, candidateCopyBytes: 0}
    for (const group of groups) {
        summary.rows += group.rows
        summary.runs += group.runRows.length
        summary.parentCopyBytes += group.parentCopies.u32 + group.parentCopies.u16
        summary.candidateCopyBytes += group.candidateCopies.u32 + group.candidateCopies.u16
    }
    summary.copyBytesAvoided = summary.parentCopyBytes - summary.candidateCopyBytes
    const report = {
        complete,
        error,
        node: process.version,
        dictionary,
        hardwareConcurrency: Number(cpus),
        deviceMemory: Number(memory),
        fixture,
        lockSha256: sha(lockBytes),
        parserWasmSha256: sha(wasm),
        parentSourceSha256: sha(await readFile(join(parentRoot, 'ext/js/dictionary/term-record-opfs-store.js'))),
        candidateSourceSha256: sha(await readFile(join(candidateRoot, 'ext/js/dictionary/term-record-opfs-store.js'))),
        scope: 'Actual source planner and native worker output through record encoders, with deterministic native-content spans and intercepted persistence. No elapsed-time or full-database parity claim.',
        summary,
        encodedByteSha256: fullDigest.digest('hex'),
        groups,
        sourceGroups,
        profiles,
    }
    await writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'})
    await writeFile(`${outputPath}.fields`, serialize(capturedFields))
    console.log(JSON.stringify({complete, error, ...summary}))
}
