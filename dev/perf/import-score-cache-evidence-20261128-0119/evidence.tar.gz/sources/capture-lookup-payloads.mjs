/* Copyright (C) 2026 Manabitan authors; SPDX-License-Identifier: GPL-3.0-or-later */
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFile, writeFile} from 'node:fs/promises';
import {resolve, join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {serialize} from 'node:v8';
import {replayParserCorpus} from './parser-replay.mjs';

const [rootInput, dictionary = 'jmdict', outputInput] = process.argv.slice(2);
assert(rootInput && outputInput);
const root = resolve(rootInput);
const output = resolve(outputInput);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const localImport = (relative) => import(pathToFileURL(join(root, relative)));
const productCommit = execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim();
const sourcePaths = ['ext/js/dictionary/dictionary-database.js', 'ext/js/dictionary/term-record-opfs-store.js', 'ext/js/dictionary/term-lookup-index.js', 'ext/js/dictionary/raw-term-content.js'];
const sourceHashes = Object.fromEntries(await Promise.all(sourcePaths.map(async (name) => [name, sha(await readFile(join(root, name)))])));
const {DictionaryDatabase} = await localImport('ext/js/dictionary/dictionary-database.js');
const {RAW_TERM_CONTENT_TOKEN_DICT_NAME} = await localImport('ext/js/dictionary/raw-term-content.js');
const {TermRecordOpfsStore} = await localImport('ext/js/dictionary/term-record-opfs-store.js');
const {splitPersistedTermLookupIndex} = await localImport('ext/js/dictionary/term-lookup-index.js');
const database = new DictionaryDatabase();
const store = new TermRecordOpfsStore();
database._bulkImportTransactionOpen = true;
database._deferTermsVirtualTableSync = true;
database._termContentStorageMode = 'raw-bytes';
database._tryBeginPersistArtifactTermContent = () => null;
const stored = new Map();
const payloads = [];
const dedupMetrics = [];
const resolvedReferenceShapes = [];
let nextOffset = 0;
let nextId = 1;
let contentGroups = 0;
database._readTermEntryContentBytesDetailedBatch = async (requests) => requests.map(({contentOffset, contentLength}) => {
    const bytes = stored.get(contentOffset);
    assert(bytes && bytes.length === contentLength);
    return {status: 'ok', bytes};
});
database._readTermEntryContentBytesDetailed = async (contentOffset, contentLength) => {
    const bytes = stored.get(contentOffset);
    assert(bytes && bytes.length === contentLength);
    return {status: 'ok', bytes};
};
database._persistArtifactTermContent = async (_title, contents, _names, uniform, spans) => {
    const count = spans === null ? contents.length : spans.lengths.length;
    const pendingOffsets = new Float64Array(count);
    const pendingLengths = new Uint32Array(count);
    for (let i = 0; i < count; i++) {
        const bytes = spans === null ? contents[i] : spans.buffer.subarray(spans.offsets[i], spans.offsets[i] + spans.lengths[i]);
        const owned = Buffer.from(bytes);
        pendingOffsets[i] = nextOffset;
        pendingLengths[i] = owned.length;
        stored.set(nextOffset, owned);
        nextOffset += Math.max(1, owned.length);
    }
    ++contentGroups;
    return {pendingOffsets, pendingLengths, pendingResolvedDictNames: uniform || RAW_TERM_CONTENT_TOKEN_DICT_NAME};
};
store._appendEncodedChunk = async (_state, firstId, count, contentDictName, contentOffsetBase, payload, recordFields, recordFieldsFormat) => {
    const {base, derived} = splitPersistedTermLookupIndex(payload);
    // Invoke the original encoder to capture its exact existing checksum values
    // and validate the record fields before making owned benchmark inputs.
    const encoded = store._createLookupIndexChunk(firstId, count, contentOffsetBase, payload, recordFields, recordFieldsFormat);
    const view = new DataView(encoded.buffer, encoded.byteOffset, encoded.byteLength);
    payloads.push({firstId, count, contentDictName, contentOffsetBase, recordFieldsFormat,
        payload: Buffer.from(payload), recordFields: Buffer.from(recordFields),
        baseBytes: base.length, derivedBytes: derived.length,
        checksums: {base: view.getUint32(24, true), derived: view.getUint32(28, true), recordFields: view.getUint32(32, true)},
        encodedByteLength: encoded.length, encodedSha256: sha(encoded)});
};
database._appendResolvedArtifactTermRecords = async (chunk, contentOffsets, contentLengths, resolvedNames) => {
    assert.equal(typeof resolvedNames, 'string');
    const references = chunk.resolvedContentReferences;
    const shape = (value) => ({constructor: value?.constructor?.name, prototypeIsBuiltin: Object.getPrototypeOf(value) === value.constructor.prototype, bufferIsPrivate: value.buffer instanceof ArrayBuffer, length: value.length, ownsLength: Object.hasOwn(value, 'length'), ownsBuffer: Object.hasOwn(value, 'buffer')});
    resolvedReferenceShapes.push({rowCount: chunk.rowCount, resolvedReferences: references !== undefined, score: shape(chunk.scoreList), scorePrefix: Array.from(chunk.scoreList.subarray(0, 64)), references: references ? Object.fromEntries(Object.entries(references).map(([key, value]) => [key, shape(value)])) : null});
    await store._encodeAndAppendArtifactChunkForState({}, chunk, nextId, contentOffsets, contentLengths,
        chunk.termRecordPreinternedPlan, resolvedNames, chunk.preparedLookupIndexes);
    nextId += chunk.rowCount;
};
const receipt = await replayParserCorpus({root, cacheDir: join(root, 'builds/e2e-dictionary-cache'), dictionary,
    onChunk: async (chunk, _progress, {fixture}) => {
        chunk.dictionary = fixture.expectedTitle;
        chunk.dictionaryTotalRows = fixture.termRows;
        chunk.uniformContentDictName ??= RAW_TERM_CONTENT_TOKEN_DICT_NAME;
        await database._bulkAddArtifactTermsChunkWithContentDedup(chunk);
        dedupMetrics.push({...database._lastBulkAddTermsMetrics});
    }});
assert.equal(payloads.reduce((sum, frame) => sum + frame.count, 0), receipt.rows);
assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim(), productCommit);
for (const [name, expected] of Object.entries(sourceHashes)) { assert.equal(sha(await readFile(join(root, name))), expected, `Source changed during capture: ${name}`); }
const harnessRevision = 'v2-imported-raw-content-dict-name';
const pendingContentCount = dedupMetrics.reduce((sum, metric) => sum + metric.dedupUniqueCount, 0);
const persistedHitCount = dedupMetrics.reduce((sum, metric) => sum + metric.dedupPersistedHitCount, 0);
if (dictionary === 'jmdict') { assert.equal(pendingContentCount, 362032); assert.equal(persistedHitCount, 3998); }
const scope = 'Full pinned corpus through actual production parser, lookup preparation, DB content deduplication/resolved-reference factory, record encoder and lookup chunk encoder. Persistence uses an explicit in-memory raw-byte adapter with sequential logical content offsets; this is checksum component input, not physical OPFS or complete-browser output parity.';
const capture = serialize({scope, harnessRevision, productCommit, sourceHashes, receipt, contentGroups, pendingContentCount, persistedHitCount, dedupMetrics, resolvedReferenceShapes, decodedContentBytes: nextOffset, payloads});
await writeFile(output, capture, {flag: 'wx'});
const summary = {scope, harnessRevision, productCommit, sourceHashes, receipt, contentGroups, pendingContentCount, persistedHitCount, dedupMetrics, resolvedReferenceShapes, decodedContentBytes: nextOffset, captureSha256: sha(capture),
    frames: payloads.map(({payload, recordFields, ...frame}) => ({...frame, payloadBytes: payload.length, recordFieldBytes: recordFields.length, payloadSha256: sha(payload), recordFieldsSha256: sha(recordFields)}))};
await writeFile(`${output}.json`, `${JSON.stringify(summary, null, 2)}\n`, {flag: 'wx'});
console.log(JSON.stringify({output, rows: receipt.rows, frames: payloads.length, payloadBytes: payloads.reduce((sum, f) => sum + f.payload.length, 0), recordFieldBytes: payloads.reduce((sum, f) => sum + f.recordFields.length, 0), captureSha256: summary.captureSha256}));
