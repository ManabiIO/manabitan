import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {deserialize} from 'node:v8';
import {createHash} from 'node:crypto';

const [baselinePath,candidatePath,outputPath]=process.argv.slice(2);
assert(baselinePath&&candidatePath&&outputPath);
const baseline=deserialize(await readFile(baselinePath));
const candidate=deserialize(await readFile(candidatePath));
assert.equal(baseline.payloads.length,candidate.payloads.length);
const digest=createHash('sha256');
for(let i=0;i<baseline.payloads.length;i++){
    assert.deepEqual(candidate.payloads[i],baseline.payloads[i]);
    digest.update(candidate.payloads[i].payload);
    digest.update(candidate.payloads[i].recordFields);
}
const result={scope:'Actual live parser columns and DB dedup/resolved-reference factory with corrected raw-v6 in-memory persistence. Sequential logical raw offsets, not physical compressed OPFS or complete-browser output parity.',baselineCommit:baseline.productCommit,candidateCommit:candidate.productCommit,rows:candidate.receipt.rows,frames:candidate.payloads.length,pendingContentCount:candidate.pendingContentCount,persistedHitCount:candidate.persistedHitCount,combinedPayloadAndFieldSha256:digest.digest('hex'),passed:true};
await writeFile(outputPath,JSON.stringify(result,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify(result));
