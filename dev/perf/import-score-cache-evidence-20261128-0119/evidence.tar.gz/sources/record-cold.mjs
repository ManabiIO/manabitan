import {createHash} from 'node:crypto';
import {readFile} from 'node:fs/promises';
import {deserialize} from 'node:v8';
import assert from 'node:assert/strict';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const [arm='candidate',name='jmdict',baselinePath='/tmp/manabitan-baseline-0119',expectedCandidate='6de0feba161110df77a467dd6d477bdd674604ba7796bf42195f45a0883512ad'] = process.argv.slice(2);
const sourcePath=arm==='baseline'?join(resolve(baselinePath),'ext/js/dictionary/term-record-opfs-store.js'):resolve('ext/js/dictionary/term-record-opfs-store.js');
const sourceSha256=createHash('sha256').update(await readFile(sourcePath)).digest('hex');
assert.equal(sourceSha256,arm==='baseline'?'7325a63fa3d054a3c8b426c87880671ca57f5956dce842d9daef4acd4d617594':expectedCandidate);
const mod=await import(pathToFileURL(sourcePath));
const captures=deserialize(await readFile(`builds/research-0119/${name}-capture.json.fields`));
const store=new mod.TermRecordOpfsStore();
const groups=captures.map(({rowCount,scoreList,references,offsets,lengths,base})=>({chunk:mod.createArtifactTermRecordChunkWithResolvedContent({rowCount,scoreList},references.uniqueIndexList,references.offsets,references.lengths),offsets,lengths,base}));
const out=[];const times=[];const startCpu=process.cpuUsage();const start=performance.now();
for(const {chunk,offsets,lengths,base} of groups){const t=performance.now();out.push(store._encodeArtifactRecordFields(chunk,offsets,lengths,base));times.push(performance.now()-t);}
const total=performance.now()-start;const cpu=process.cpuUsage(startCpu);const digest=createHash('sha256');for(const bytes of out)digest.update(bytes);
console.log(JSON.stringify({arm,name,node:process.version,v8:process.versions.v8,sourceSha256,ms:total,cpuMs:(cpu.user+cpu.system)/1000,times,digest:digest.digest('hex')}));
