import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {replayParserCorpus} from '/tmp/manabitan-research-0119/parser-replay.mjs';
import * as candidate from '../../ext/js/dictionary/term-record-opfs-store.js';
const [dictionary='jmdict',baselinePath='/tmp/manabitan-baseline-0119',label='hybrid',expectedCandidate='6de0feba161110df77a467dd6d477bdd674604ba7796bf42195f45a0883512ad'] = process.argv.slice(2);
const root=process.cwd();
const baselineRoot=resolve(baselinePath);
const baselineSourcePath=join(baselineRoot,'ext/js/dictionary/term-record-opfs-store.js');
const baselineRecordSourceSha256=createHash('sha256').update(await readFile(baselineSourcePath)).digest('hex');
const candidateRecordSourceSha256=createHash('sha256').update(await readFile('ext/js/dictionary/term-record-opfs-store.js')).digest('hex');
assert.equal(baselineRecordSourceSha256,'7325a63fa3d054a3c8b426c87880671ca57f5956dce842d9daef4acd4d617594','Frozen baseline record encoder differs from 9e10d3b3');
assert.equal(candidateRecordSourceSha256,expectedCandidate,'Candidate record encoder differs from selected source hash');
const baseline=await import(pathToFileURL(baselineSourcePath));
const groups=[];const digest=createHash('sha256');let base=2**40;let records=0;
async function encode(mod, chunk, offsets, lengths, dictionaryTitle) {
 const store=new mod.TermRecordOpfsStore();
 const writes=[];const fields=[];
 const fieldEncode=store._encodeArtifactRecordFields.bind(store);
 store._encodeArtifactRecordFields=(...args)=>{const bytes=fieldEncode(...args);fields.push({rows:args[0].rowCount,bytes:bytes.byteLength,scoreType:args[0].scoreList.constructor.name,hasReferences:!!args[0].resolvedContentReferences});return bytes;};
 store._appendEncodedChunk=async(...args)=>writes.push(args);
 const input=mod.createArtifactTermRecordChunkWithResolvedContent({...chunk,dictionary:dictionaryTitle},chunk.contentUniqueIndexList,offsets,lengths,chunk.preparedLookupIndexes);
 await store._encodeAndAppendArtifactChunkForState({},input,records+1,new Float64Array(0),new Uint32Array(0),chunk.termRecordPreinternedPlan,'raw',chunk.preparedLookupIndexes);
 return {writes,fields};
}
const report=await replayParserCorpus({root,cacheDir:'../manabitan/builds/e2e-dictionary-cache',dictionary,onChunk:async(chunk,_progress,{fixture})=>{
 const plan=chunk.contentDedupPlan;assert(plan&&chunk.contentUniqueIndexList&&chunk.contentMetaList);
 const offsets=new Float64Array(plan.uniqueCount),lengths=new Uint32Array(plan.uniqueCount);
 for(let i=0;i<plan.uniqueCount;i++){const meta=(chunk.contentMetaByUniqueIndex?i:plan.uniqueRowIndexes[i])*4;offsets[i]=base+chunk.contentMetaList[meta];lengths[i]=chunk.contentMetaList[meta+1];}
 const left=await encode(baseline,chunk,offsets,lengths,fixture.expectedTitle),right=await encode(candidate,chunk,offsets,lengths,fixture.expectedTitle);
 assert.deepEqual(left.writes,right.writes);assert.deepEqual(left.fields,right.fields);
 for(const args of right.writes){digest.update(args[5]);digest.update(args[6]);}
 groups.push({rows:chunk.rowCount,fields:right.fields});records+=chunk.rowCount;base+=chunk.contentBytesLength??chunk.contentBytesBuffer.byteLength;
 if(groups.length%10===0)process.stderr.write(`${dictionary}: ${records}/${fixture.termRows} rows\n`);
}});
const result={...report,recordScope:'Full production source planner/parser columns, real record/index encoders, deterministic native-content offsets, intercepted storage; no browser or whole-import latency claim.',baselineRoot,recordGroups:groups,recordRows:records,encodedByteSha256:digest.digest('hex'),baselineRecordSourceSha256,candidateRecordSourceSha256};
await writeFile(`builds/research-0119/${dictionary}-record-corpus-${label}.json`,JSON.stringify(result,null,2));
console.log(JSON.stringify({complete:result.complete,dictionary,recordRows:records,groups:groups.length,runs:groups.reduce((s,g)=>s+g.fields.length,0),encodedByteSha256:result.encodedByteSha256}));
