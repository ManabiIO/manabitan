import assert from 'node:assert/strict';
import {Session} from 'node:inspector';
import {createHash} from 'node:crypto';
import {readFile,writeFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {pathToFileURL} from 'node:url';

const [rootInput,outputInput]=process.argv.slice(2);
assert(rootInput&&outputInput);
const root=resolve(rootInput),output=resolve(outputInput);
const script=resolve('../manabitan/builds/research-0119/capture-lookup-payloads.mjs');
const session=new Session();session.connect();
const post=(method,params={})=>new Promise((resolve,reject)=>session.post(method,params,(error,result)=>error?reject(error):resolve(result)));
await post('Profiler.enable');
await post('Profiler.startPreciseCoverage',{callCount:true,detailed:true});
try {
    process.argv=[process.execPath,script,root,'jmdict',output];
    await import(pathToFileURL(script));
    const coverage=await post('Profiler.takePreciseCoverage');
    const url=pathToFileURL(join(root,'ext/js/dictionary/term-record-opfs-store.js')).href;
    const found=coverage.result.find(script=>script.url===url);
    assert(found,'Candidate record encoder did not execute');
    const names=['getSynchronousRecordFieldReferences','shouldCacheCompactRecordScores','encodeCachedCompactRecordScores','_encodeArtifactRecordFields'];
    const functions=found.functions.filter(fn=>names.includes(fn.functionName));
    const receipt=JSON.parse(await readFile(output+'.json'));
    const count=(name)=>functions.find(fn=>fn.functionName===name)?.ranges[0]?.count;
    assert.equal(count('encodeCachedCompactRecordScores'),12,'Live original parser columns did not select cache in every JMdict group');
    assert.equal(count('shouldCacheCompactRecordScores'),12);
    assert.equal(receipt.resolvedReferenceShapes.length,12);
    for(const shape of receipt.resolvedReferenceShapes){
        assert.equal(shape.score.constructor,'Int32Array');assert.equal(shape.score.prototypeIsBuiltin,true);assert.equal(shape.score.bufferIsPrivate,true);
        assert.equal(shape.score.ownsLength,false);assert.equal(shape.score.ownsBuffer,false);
        assert.equal(shape.resolvedReferences,true);
        assert(shape.scorePrefix.slice(0,32).some(score=>score< -256||score>=256));
    }
    const sourceSha256=createHash('sha256').update(await readFile(join(root,'ext/js/dictionary/term-record-opfs-store.js'))).digest('hex');
    assert.equal(sourceSha256,'65e3bc1c98b45175d350d79a282b6445225339fafbb9024a7f02f0379222f3c9');
    const result={scope:'Unmodified product V3 module under diagnostic Node precise coverage, with original live parser columns passed through actual DictionaryDatabase deduplication/resolved-reference factory before capture serialization. Raw-byte in-memory persistence adapter; not browser or physical OPFS output parity.',productCommit:receipt.productCommit,sourceSha256,node:process.version,rows:receipt.receipt.rows,pendingContentCount:receipt.pendingContentCount,persistedHitCount:receipt.persistedHitCount,cacheHelperCalls:count('encodeCachedCompactRecordScores'),prefixProbeCalls:count('shouldCacheCompactRecordScores'),fieldEncoderCalls:count('_encodeArtifactRecordFields'),resolvedReferenceShapes:receipt.resolvedReferenceShapes,functions};
    await writeFile(output+'.route.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
    console.log(JSON.stringify({...result,resolvedReferenceShapes:undefined,functions:undefined}));
} finally {
    await post('Profiler.stopPreciseCoverage');session.disconnect();
}
