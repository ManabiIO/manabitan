#!/usr/bin/env python3
# Copyright (C) 2026 Manabitan authors
# SPDX-License-Identifier: GPL-3.0-or-later
"""Run the fixed production-reader cohort, retaining failures without retries."""

import hashlib
import json
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parent
workspace = root.parent
node = workspace / "runtime/node_modules/node/bin/node"
script = root / "reader-production-study.mjs"
script_hash = "1704e484fe6851ace904e4764a528d00c279a6850ab30ce2a1c35d9a0998c81d"
sources = {
    "baseline": workspace / "manabitan-control-current",
    "candidate": workspace / "manabitan",
}
heads = {
    "baseline": "99787e4c8bcaea1f508b18326e3f1d74cfc094b3",
    "candidate": "d8d18d9a7a9b56e8d05be851b5ae0c769a36a384",
}
output = root / "reader-production-20261120"
output.mkdir(exist_ok=False)

def revision(source):
    return subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip()

for orientation in ["forward", "reverse"]:
    assert hashlib.sha256(script.read_bytes()).hexdigest() == script_hash
    for name, source in sources.items():
        assert revision(source) == heads[name]
    command = [str(node), "--expose-gc", "--max-old-space-size=1400", str(script),
        "--baseline", str(sources["baseline"]), "--candidate", str(sources["candidate"]),
        "--corpus", "/workspace/scratch/f34c9c9fae89/manabitan/builds/perf/checksum-corpus-regenerated/real-fixture",
        "--raw-corpus", str(root), "--output", str(output / orientation), "--order", orientation, "--blocks", "12"]
    receipt = {"command": command, "timeoutSeconds": 180, "sourceHeadsBefore": {name: revision(source) for name, source in sources.items()}, "scriptSha256": script_hash}
    started = time.monotonic()
    with (output / f"{orientation}.log").open("x") as log:
        try:
            result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=180)
            receipt["exitCode"] = result.returncode
        except subprocess.TimeoutExpired:
            receipt["exitCode"] = None
            receipt["error"] = "Fixed 180-second timeout exceeded"
    receipt["elapsedSeconds"] = time.monotonic() - started
    receipt["sourceHeadsAfter"] = {name: revision(source) for name, source in sources.items()}
    with (output / f"{orientation}-exit.json").open("x") as stream:
        json.dump(receipt, stream, indent=2)
        stream.write("\n")
    print(json.dumps({"orientation": orientation, **receipt}), flush=True)
    assert receipt["exitCode"] == 0, f"Failed orientation: {orientation}; inspect retained failure/log"
    assert receipt["sourceHeadsBefore"] == receipt["sourceHeadsAfter"] == heads
    assert hashlib.sha256(script.read_bytes()).hexdigest() == script_hash

