/*
 * Copyright (C) 2026 Manabitan authors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {lstat, mkdir, readFile, readdir, realpath, writeFile, appendFile} from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import {fileURLToPath, pathToFileURL} from 'node:url'
import {parseArgs} from 'node:util'

const {values} = parseArgs({options: {
    baseline: {type: 'string'},
    candidate: {type: 'string'},
    corpus: {type: 'string'},
    'raw-corpus': {type: 'string'},
    output: {type: 'string'},
    order: {type: 'string', default: 'forward'},
    blocks: {type: 'string', default: '12'},
}})
for (const name of ['baseline', 'candidate', 'corpus', 'raw-corpus', 'output']) assert.ok(values[name], `Missing --${name}`)
assert.ok(['forward', 'reverse'].includes(values.order))
const measuredBlocks = Number(values.blocks)
assert.ok(Number.isSafeInteger(measuredBlocks) && measuredBlocks > 0 && measuredBlocks % 4 === 0)
assert.equal(typeof globalThis.gc, 'function', 'Run with --expose-gc')
assert.deepEqual(process.execArgv, ['--expose-gc', '--max-old-space-size=1400'])
for (const name of ['NODE_OPTIONS', 'NODE_V8_COVERAGE']) assert.ok(!process.env[name], `Inherited instrumentation: ${name}`)
const output = path.resolve(values.output)
await mkdir(output, {recursive: false})
const baseline = await realpath(values.baseline)
const candidate = await realpath(values.candidate)
const corpusRoot = await realpath(values.corpus)
const rawRoot = await realpath(values['raw-corpus'])
const script = fileURLToPath(import.meta.url)
const sha256 = (value) => createHash('sha256').update(value).digest('hex')
const writeJson = async (name, value) => await writeFile(path.join(output, name), `${JSON.stringify(value, null, 2)}\n`, {flag: 'wx'})
const runtimeRoots = ['ext/js', 'ext/lib', 'dev/lib', 'dev/data/dictionary-wasm']
const sourceFiles = ['package.json', 'package-lock.json', 'dev/dictionary-wasm.js']

async function sourceIdentity(root) {
    const files = []
    async function visit(name) {
        const filename = path.join(root, name)
        const stat = await lstat(filename)
        assert.ok(!stat.isSymbolicLink(), `Source symlink: ${filename}`)
        assert.equal(await realpath(filename), filename)
        if (stat.isDirectory()) {
            for (const child of await readdir(filename)) await visit(path.join(name, child))
        } else {
            assert.ok(stat.isFile(), `Nonregular source: ${filename}`)
            const bytes = await readFile(filename)
            files.push({name, bytes: bytes.length, sha256: sha256(bytes)})
        }
    }
    for (const name of [...runtimeRoots, ...sourceFiles]) await visit(name)
    files.sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0)
    const canonical = files.map(({name, bytes, sha256: digest}) => JSON.stringify([name, bytes, digest])).join('\n') + '\n'
    return {root, commit: execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim(),
        trackedDiffSha256: sha256(execFileSync('git', ['-C', root, 'diff', 'HEAD', '--binary'], {maxBuffer: 32 * 1024 * 1024})),
        runtimeTree: {roots: runtimeRoots, sourceFiles, files: files.length, bytes: files.reduce((n, file) => n + file.bytes, 0), sha256: sha256(canonical)}, files}
}

const inputs = {}
async function input(filename) {
    const bytes = await readFile(filename)
    inputs[filename] = {bytes: bytes.length, sha256: sha256(bytes)}
    return bytes
}
const scriptSha256 = sha256(await input(script))
const manifest = JSON.parse(await input(path.join(corpusRoot, 'manifest.json')))
const corpus = JSON.parse(await input(path.join(rawRoot, 'corpus.json')))
const stored = await input(path.join(corpusRoot, 'store.bin'))
const raw = await input(path.join(rawRoot, 'raw.bin'))
assert.equal(manifest.archiveSha256, '7681ee09f9edfef48a5e50773565da237424eb750bdb0e1e59660784ecd53e8a')
assert.equal(corpus.fixtureSha256, manifest.archiveSha256)
assert.equal(manifest.storeSha256, '4cee541ed8c6869e9ad8ec4c400f9fb61fcbf00f6e995a0a5df6d274fcd586f0')
assert.equal(corpus.rawSha256, '01759437d0a25cc0f8c82df5ec5bb71db3c2615351b1a1a85fb2e6d13ea925ce')
assert.equal(sha256(stored), manifest.storeSha256)
assert.equal(sha256(stored), corpus.storeSha256)
assert.equal(sha256(raw), corpus.rawSha256)
assert.equal(raw.length, 100671677)
assert.equal(manifest.blocks.length, 28)
assert.equal(corpus.blocks.length, manifest.blocks.length)
const blocks = manifest.blocks.map((block, index) => {
    const rawBlock = corpus.blocks[index]
    assert.equal(block.uncompressedLength, rawBlock.rawLength)
    const compressed = stored.subarray(block.offset, block.offset + block.length)
    const reference = raw.subarray(rawBlock.rawOffset, rawBlock.rawOffset + rawBlock.rawLength)
    assert.equal(sha256(compressed), block.sha256)
    assert.equal(sha256(reference), block.uncompressedSha256)
    assert.equal(sha256(reference), rawBlock.rawSha256)
    return {...block, reference}
})
assert.equal(blocks.reduce((n, block) => n + block.uncompressedLength, 0), raw.length)
const identities = {baseline: await sourceIdentity(baseline), candidate: await sourceIdentity(candidate)}
await writeJson('baseline-source-manifest.json', identities.baseline)
await writeJson('candidate-source-manifest.json', identities.candidate)

const originalFetch = globalThis.fetch
globalThis.fetch = async (resource, init) => {
    const url = resource instanceof Request ? new URL(resource.url) : new URL(String(resource))
    assert.equal(url.protocol, 'file:', 'Reader study cannot fetch network resources')
    const filename = await realpath(fileURLToPath(url))
    assert.ok([baseline, candidate].some((root) => filename.startsWith(`${root}${path.sep}`)), 'Asset escaped selected sources')
    init?.signal?.throwIfAborted()
    return new Response(await readFile(filename), {headers: {'Content-Type': filename.endsWith('.wasm') ? 'application/wasm' : 'application/octet-stream'}})
}

async function loadImplementation(root) {
    const load = async (name) => await import(pathToFileURL(path.join(root, name)).href)
    const zstd = await load('ext/js/dictionary/zstd-term-content.js')
    await zstd.initializeTermContentZstd()
    const {TermContentBlockStore} = await load('ext/js/dictionary/term-content-block-store.js')
    const {encodeRawTermContentCompactBlockReference, createRawTermContentCompactBlockDictName} = await load('ext/js/dictionary/raw-term-content.js')
    const {writeCompressedTermContentBlockEnvelope} = await load('ext/js/dictionary/term-content-block-envelope.js')
    const dictionary = await readFile(path.join(root, 'ext/lib/zstd-dicts/jmdict.zdict'))
    assert.equal(sha256(dictionary), corpus.dictionarySha256)
    return {TermContentBlockStore, encodeRawTermContentCompactBlockReference, contentDictName: createRawTermContentCompactBlockDictName('jmdict'), writeCompressedTermContentBlockEnvelope}
}

class MemoryContentStore {
    constructor(bytes) { this.bytes = bytes; this.reads = [] }
    async readSlice(offset, length) {
        assert.ok(Number.isSafeInteger(offset) && Number.isSafeInteger(length) && offset >= 0 && length >= 0 && offset + length <= this.bytes.length)
        const bytes = Uint8Array.from(this.bytes.subarray(offset, offset + length))
        this.reads.push({offset, length, bytes})
        return bytes
    }
    verifyReads() {
        for (const {offset, length, bytes} of this.reads) assert.equal(Buffer.compare(bytes, this.bytes.subarray(offset, offset + length)), 0, 'A production reader changed its input')
    }
}

const implementations = {baseline: await loadImplementation(baseline), candidate: await loadImplementation(candidate)}
const references = blocks.map((block) => implementations.baseline.encodeRawTermContentCompactBlockReference(block.offset, block.length, block.uncompressedLength, 0))
for (let i = 0; i < blocks.length; ++i) {
    const block = blocks[i]
    assert.deepEqual(implementations.candidate.encodeRawTermContentCompactBlockReference(block.offset, block.length, block.uncompressedLength, 0), references[i])
}
assert.equal(implementations.candidate.contentDictName, implementations.baseline.contentDictName)
const image = Buffer.concat([stored, ...references])
const imageSha256 = sha256(image)
const arms = Object.fromEntries(['A', 'B', 'C', 'D'].map((arm) => {
    const source = arm === 'A' || arm === 'C' ? 'baseline' : 'candidate'
    const implementation = implementations[source]
    const adapter = new MemoryContentStore(image)
    return [arm, {source, implementation, adapter, reader: new implementation.TermContentBlockStore(adapter, {cacheMaxBytes: 0})}]
}))
let orders = ['ABDC', 'BCAD', 'CDBA', 'DACB']
if (values.order === 'reverse') orders = orders.map((order) => [...order].reverse().join(''))
const protocol = {schemaVersion: 1, generatedAt: new Date().toISOString(), scriptSha256, node: process.version, execArgv: process.execArgv, nodeBinarySha256: sha256(await readFile(process.execPath)),
    runtime: {platform: process.platform, arch: process.arch, cpuModel: os.cpus()[0]?.model, logicalCpus: os.cpus().length, totalMemory: os.totalmem()},
    sources: {A: baseline, B: candidate, C: baseline, D: candidate}, sourceIdentities: Object.fromEntries(Object.entries(identities).map(([name, identity]) => [name, {commit: identity.commit, trackedDiffSha256: identity.trackedDiffSha256, runtimeTree: identity.runtimeTree}])),
    inputs, corpus: {scope: corpus.scope, representativeness: 'Historical JMdict-derived 4 MiB packer corpus. The current dictionary-import target is 1 MiB, so this is not a timing result for its current block distribution.', blocks: blocks.length, decodedBytes: raw.length, storedBytes: stored.length, compressedEnvelopeBytes: blocks.reduce((n, b) => n + b.length, 0), fixtureSha256: corpus.fixtureSha256},
    boundary: 'Public production TermContentBlockStore.readDetailed, cold block cache, owned-byte in-memory reference/payload reads, envelope integrity, native decode, generation fences, and owned result; no copied codec implementation, patched exports, real OPFS, browser, or whole-import timing',
    measurement: 'One process per orientation; A/C share one baseline production module instance and codec context, B/D share one candidate instance. Each arm has a separate block store with zero decoded-cache budget. Module compilation, initialization, explicit GC, and full-byte/input-ownership checks are outside timing.',
    blocks: measuredBlocks, warmupsPerArm: 2, order: values.order, orders, gcBeforeEveryArm: true,
    timingPolicy: 'Fixed balanced four-arm blocks; all observations retained; no retries, outlier removal, extension, or control subtraction', controls: ['C/A', 'D/B'], comparisons: ['B/A', 'D/A']}
await writeJson('protocol.json', protocol)
const report = {status: 'running', protocol, correctness: [], warmups: [], observations: []}

async function corruptionChecks() {
    const first = blocks[0]
    const original = stored.subarray(first.offset, first.offset + first.length)
    const make = (mutate) => { const bytes = Uint8Array.from(original); return mutate(bytes) ?? bytes }
    const malformed = make((bytes) => { bytes[12] ^= 255 })
    implementations.baseline.writeCompressedTermContentBlockEnvelope(malformed)
    const checksumReason = 'Term content block checksum does not match its stored payload'
    const envelopeReason = 'Term content block checksum envelope is invalid'
    const cases = [
        {name: 'bad-magic', bytes: make((b) => { b[0] ^= 1 }), reason: envelopeReason},
        {name: 'bad-first-checksum', bytes: make((b) => { b[4] ^= 1 }), reason: checksumReason},
        {name: 'bad-second-checksum', bytes: make((b) => { b[8] ^= 1 }), reason: checksumReason},
        {name: 'bad-payload', bytes: make((b) => { b[b.length - 1] ^= 1 }), reason: checksumReason},
        {name: 'truncated-payload', bytes: make((b) => b.subarray(0, b.length - 1)), reason: checksumReason},
        {name: 'header-only', bytes: make((b) => b.subarray(0, 12)), reason: envelopeReason},
        {name: 'valid-checksum-malformed-frame', bytes: malformed, reason: 'Term content block decompression failed'},
        {name: 'decoded-limit-too-small', bytes: original, decodedLength: first.uncompressedLength - 1, reason: 'Term content block decompression failed'},
        {name: 'decoded-length-too-large', bytes: original, decodedLength: first.uncompressedLength + 1, reason: 'Term content block decoded length does not match its reference'},
        {name: 'invalid-entry-bounds', bytes: original, entryOffset: 1, reason: 'Term content block reference is invalid'},
    ]
    for (const testCase of cases) {
        const outcomes = []
        for (const [source, implementation] of Object.entries(implementations)) {
            const decodedLength = testCase.decodedLength ?? first.uncompressedLength
            const reference = implementation.encodeRawTermContentCompactBlockReference(0, testCase.bytes.length, decodedLength, testCase.entryOffset ?? 0)
            const bytes = Buffer.concat([testCase.bytes, reference])
            const before = sha256(bytes)
            const adapter = new MemoryContentStore(bytes)
            const reader = new implementation.TermContentBlockStore(adapter, {cacheMaxBytes: 0})
            const result = await reader.readDetailed(testCase.bytes.length, decodedLength, implementation.contentDictName)
            assert.deepEqual(result, {status: 'corrupt', reason: testCase.reason}, `${source}: ${testCase.name}`)
            adapter.verifyReads()
            assert.equal(sha256(bytes), before)
            outcomes.push(result)
            report.correctness.push({name: testCase.name, source, result, inputUnchanged: true})
        }
        assert.deepEqual(outcomes[0], outcomes[1])
    }
    for (const [source, implementation] of Object.entries(implementations)) {
        const corrupt = make((bytes) => { bytes[4] ^= 1 })
        const reference = implementation.encodeRawTermContentCompactBlockReference(0, corrupt.length, first.uncompressedLength, 0)
        const adapter = new MemoryContentStore(Buffer.concat([corrupt, reference]))
        const reader = new implementation.TermContentBlockStore(adapter, {cacheMaxBytes: 0})
        let startRead
        let releaseRead
        const started = new Promise((resolve) => { startRead = resolve })
        const release = new Promise((resolve) => { releaseRead = resolve })
        const readSlice = adapter.readSlice.bind(adapter)
        adapter.readSlice = async (offset, length) => {
            if (offset === 0) { startRead(); await release }
            return await readSlice(offset, length)
        }
        const pending = reader.readDetailed(corrupt.length, first.uncompressedLength, implementation.contentDictName)
        await started
        reader.clearCache()
        releaseRead()
        const result = await pending
        assert.deepEqual(result, {status: 'temporarilyUnavailable', reason: 'Term content changed during read'})
        adapter.verifyReads()
        report.correctness.push({name: 'generation-invalidated-before-corruption', source, result, inputUnchanged: true})
    }
}

async function observe(arm, block) {
    const {reader, adapter, implementation} = arms[arm]
    adapter.reads = []
    globalThis.gc()
    const cpuStart = process.cpuUsage()
    const started = performance.now()
    const results = []
    for (let i = 0; i < blocks.length; ++i) results.push(await reader.readDetailed(stored.length + i * 20, blocks[i].uncompressedLength, implementation.contentDictName))
    const wallMs = performance.now() - started
    const cpu = process.cpuUsage(cpuStart)
    let decodedBytes = 0
    for (let i = 0; i < blocks.length; ++i) {
        assert.equal(results[i].status, 'ok', `Failed corpus block ${i}`)
        assert.equal(Buffer.compare(results[i].bytes, blocks[i].reference), 0, `Decoded corpus mismatch ${i}`)
        decodedBytes += results[i].bytes.length
    }
    adapter.verifyReads()
    assert.equal(adapter.reads.length, blocks.length * 2, 'Every block must miss the decoded cache')
    assert.equal(adapter.reads.reduce((n, read) => n + read.length, 0), protocol.corpus.compressedEnvelopeBytes + 20 * blocks.length)
    assert.equal(decodedBytes, raw.length)
    return {arm, block, wallMs, cpuMs: (cpu.user + cpu.system) / 1000, decodedBytes, fullByteOracle: true, ownedInputsUnchanged: true, referenceReads: blocks.length, compressedReads: blocks.length}
}

function summary(observations) {
    const median = (values) => { const sorted = [...values].sort((a, b) => a - b); return (sorted[(sorted.length - 1) >> 1] + sorted[sorted.length >> 1]) / 2 }
    const summarize = (values) => ({count: values.length, median: median(values), min: Math.min(...values), max: Math.max(...values)})
    const result = {arms: {}, comparisons: {}}
    for (const arm of 'ABCD') result.arms[arm] = Object.fromEntries(['wallMs', 'cpuMs'].map((metric) => [metric, summarize(observations.filter((row) => row.arm === arm).map((row) => row[metric]))]))
    for (const [numerator, denominator] of [['C', 'A'], ['D', 'B'], ['B', 'A'], ['D', 'A']]) {
        result.comparisons[`${numerator}/${denominator}`] = {}
        for (const metric of ['wallMs', 'cpuMs']) {
            const pairs = Array.from({length: measuredBlocks}, (_, block) => [denominator, numerator].map((arm) => observations.find((row) => row.block === block + 1 && row.arm === arm)[metric]))
            const changes = pairs.map(([before, after]) => 100 * (after / before - 1))
            result.comparisons[`${numerator}/${denominator}`][metric] = {...summarize(changes), fasterBlocks: changes.filter((change) => change < 0).length, equalWorkChangePercent: 100 * (pairs.reduce((n, pair) => n + pair[1], 0) / pairs.reduce((n, pair) => n + pair[0], 0) - 1), pairedChangesPercent: changes}
        }
    }
    return result
}

try {
    await corruptionChecks()
    await writeJson('correctness.json', report.correctness)
    for (let block = 0; block < 2; ++block) {
        for (const arm of orders[block]) report.warmups.push(await observe(arm, 0))
    }
    await writeJson('warmups.json', report.warmups)
    for (let block = 1; block <= measuredBlocks; ++block) {
        for (const arm of orders[(block - 1) % orders.length]) {
            const observation = await observe(arm, block)
            report.observations.push(observation)
            await appendFile(path.join(output, 'observations.jsonl'), `${JSON.stringify(observation)}\n`)
        }
    }
    assert.equal(sha256(image), imageSha256)
    for (const [filename, identity] of Object.entries(inputs)) assert.equal(sha256(await readFile(filename)), identity.sha256, `Input changed: ${filename}`)
    for (const [name, identity] of Object.entries(identities)) assert.deepEqual(await sourceIdentity(identity.root), identity, `Source changed: ${name}`)
    report.status = 'complete'
    report.maxRssKiB = process.resourceUsage().maxRSS
    report.summary = summary(report.observations)
    await writeJson('summary.json', report)
    process.stdout.write(`${JSON.stringify({status: report.status, output, correctnessChecks: report.correctness.length, warmups: report.warmups.length, observations: report.observations.length, summary: report.summary}, null, 2)}\n`)
} catch (error) {
    report.status = 'failed'
    report.error = {name: error.name, message: error.message, stack: error.stack}
    await writeJson('failure.json', report)
    throw error
} finally {
    globalThis.fetch = originalFetch
}
