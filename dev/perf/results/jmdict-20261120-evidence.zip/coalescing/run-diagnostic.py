from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/workspace/scratch/ee3ecb87c795/manabitan-coalesced-spans')
parent=root.parent/'manabitan'
out=root/'builds/perf/coalesced-spans-20261120'
preload=out/'wasm-phase-preload.mjs'
command=[str(root.parent/'runtime/node_modules/node/bin/node'),'--max-old-space-size=1400','--import',str(preload),str(parent/'dev/perf/jmdict-component-benchmark.js'),'--source',str(root),'--fixture',str(parent/'builds/e2e-dictionary-cache/JMdict.zip'),'--output',str(out/'worker-diagnostic.json'),'--node-workers','--hardware-concurrency','4','--device-memory','8']
env=os.environ.copy()
env['MANABITAN_ZSTD_SOURCE_ROOT']=str(root)
env['MANABITAN_ZSTD_PROFILE_DIR']=str(out/'wasm-phases')
start=time.monotonic()
with (out/'worker-diagnostic.log').open('x') as log:
    result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
receipt={'command':command,'environment':{key:env[key] for key in ['MANABITAN_ZSTD_SOURCE_ROOT','MANABITAN_ZSTD_PROFILE_DIR']},'elapsedSeconds':time.monotonic()-start,'exitCode':result.returncode,'preloadSha256':hashlib.sha256(preload.read_bytes()).hexdigest()}
(out/'worker-diagnostic-exit.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert result.returncode==0,receipt
report=json.loads((out/'worker-diagnostic.json').read_text())
assert report['rows']==526942
assert report['storedFilesCanonicalSha256']=='2f559a8b0d90ed063d01b9650aee46cbbe52f469bc2ffd6ebbd74dd265e3e34c'
assert report['verification']['sha256']=='8926122e434123d9823d867845ed8480734e0ada8381204e1857f88b216d8974'
records=[]
for path in sorted((out/'wasm-phases').glob('worker-*.jsonl')):
    records.extend(json.loads(line) for line in path.read_text().splitlines())
jobs=[row for row in records if row['type']=='compression']
spans=sum(row['spans']['spans'] for row in jobs)
runs=sum(row['spans']['runCount'] for row in jobs)
assert len(jobs)==102,len(jobs)
assert spans==runs==3950,(spans,runs)
summary={'diagnosticOnly':True,'rows':report['rows'],'groups':report['policy']['groupCount'],'verification':report['verification'],'storedFilesCanonicalSha256':report['storedFilesCanonicalSha256'],'workerTransport':report['workerTransport'],'jobs':len(jobs),'originalSpanCount':360859,'compressionSpanCount':spans,'contiguousRunCount':runs,'originalMetadataBytes':360859*8,'coalescedMetadataBytes':spans*8,'metadataBytesReduction':(360859-spans)*8,'metadataReductionPercent':(1-spans/360859)*100,'warning':'Structural work reduction; instrumented timings are not performance evidence'}
(out/'worker-diagnostic-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
