import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {appendFileSync, mkdirSync, readFileSync, readdirSync, realpathSync, writeFileSync} from 'node:fs'
import {registerHooks} from 'node:module'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import {isMainThread, threadId} from 'node:worker_threads'

const sourceRoot = realpathSync(process.env.MANABITAN_ZSTD_SOURCE_ROOT)
const outputRoot = path.resolve(process.env.MANABITAN_ZSTD_PROFILE_DIR)
const target = realpathSync(path.join(sourceRoot, 'ext/lib/zstd-wasm.js'))
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const preloadSha256 = hash(readFileSync(fileURLToPath(import.meta.url)))
const wrapperSha256 = hash(readFileSync(target))
const hookName = 'manabitan.perf.zstd.phases'
const hookSymbol = Symbol.for(hookName)
const preparedRecords = new WeakMap()
const moduleRecords = new WeakMap()
let loaded = 0
let observations = 0
mkdirSync(outputRoot, {recursive: true})
const journal = path.join(outputRoot, `worker-${process.pid}-${threadId}.jsonl`)
writeFileSync(journal, JSON.stringify({type: 'identity', pid: process.pid, threadId, isMainThread,
    sourceRoot, target, preloadSha256, wrapperSha256, node: process.version}) + '\n', {flag: 'wx'})


const marker = {name: 'Production Wasm compression phase attribution', diagnosticOnly: true,
    preloadSha256, wrapperSha256, scope: 'Nested synchronous phase wall times; no speedup claim; journal writes are outside phase timers'}
Reflect.set(globalThis, Symbol.for('manabitan.perf.instrumentation'), marker)

function hookModule(module) {
    let record = moduleRecords.get(module)
    if (record) return record
    record = {active: null}
    moduleRecords.set(module, record)
    for (const [name, phase] of [['_ZSTD_compress_usingDict', 'nativeCompressionMs'], ['_manabitan_write_block_envelope', 'envelopeMs']]) {
        const original = module[name]
        assert.equal(typeof original, 'function')
        module[name] = function (...args) {
            const started = performance.now()
            try {
                return Reflect.apply(original, module, args)
            } finally {
                const elapsed = performance.now() - started
                if (record.active !== null) {
                    record.active[phase] += elapsed
                    ++record.active[`${phase}Calls`]
                }
            }
        }
    }
    return record
}

function spanStats(source, offsets, lengths, pointer, heap) {
    let runCount = 0
    let alignedSharedRunBytes = 0
    let privateShiftBytes = 0
    let outputOffset = 0
    let longestRun = 0
    let previousEnd = null
    let positiveGapBytes = 0
    let largestGapBytes = 0
    let negativeGapCount = 0
    let zeroLengthSpans = 0
    const shared = source.buffer instanceof SharedArrayBuffer
    const align = shared && !(heap.buffer instanceof SharedArrayBuffer)
    for (let i = 0; i < offsets.length;) {
        const begin = offsets[i]
        if (previousEnd !== null) {
            const gap = begin - previousEnd
            if (gap >= 0) {
                positiveGapBytes += gap
                largestGapBytes = Math.max(largestGapBytes, gap)
            } else {
                ++negativeGapCount
            }
        }
        let end = begin
        let count = 0
        let length = 0
        while (i < offsets.length && (count === 0 || offsets[i] === end)) {
            if (lengths[i] === 0) ++zeroLengthSpans
            length += lengths[i]
            end = offsets[i] + lengths[i]
            ++count
            ++i
        }
        ++runCount
        longestRun = Math.max(longestRun, length)
        if (align && length >= 1024) {
            alignedSharedRunBytes += length
            const prefix = (heap.byteOffset + pointer + outputOffset - source.byteOffset - begin) & 7
            if (prefix !== 0) privateShiftBytes += length - prefix
        }
        outputOffset += length
        previousEnd = end
    }
    return {shared, sourceByteOffset: source.byteOffset, sourceByteLength: source.byteLength,
        sourceBackingBytes: source.buffer.byteLength, spans: offsets.length, runCount,
        longestRun, alignedSharedRunBytes, privateShiftBytes, outputOffset,
        positiveGapBytes, largestGapBytes, negativeGapCount, zeroLengthSpans,
        coveredWindowBytes: offsets.length > 0 ? previousEnd - offsets[0] : 0}
}

Reflect.set(globalThis, hookSymbol, {
    prepare(original, args, module) {
        hookModule(module)
        const started = performance.now()
        const prepared = Reflect.apply(original, undefined, args)
        const prepareMs = performance.now() - started
        const [context, source, offsets, lengths, contentBytes, dictionary, prefixBytes, level, writeBlockEnvelope] = args
        const record = {type: 'compression', threadId, isMainThread, ordinal: observations++, 
            context, contentBytes, dictionaryBytes: dictionary.byteLength, prefixBytes, level, writeBlockEnvelope,
            prepareMs, nativeCompressionMs: 0, envelopeMs: 0,
            nativeCompressionMsCalls: 0, envelopeMsCalls: 0,
            spans: spanStats(source, offsets, lengths, prepared.sourcePointer, module.HEAPU8)}
        assert.equal(record.spans.outputOffset, contentBytes)
        preparedRecords.set(prepared, record)
        return prepared
    },
    finish(original, prepared, module) {
        const record = preparedRecords.get(prepared)
        assert.ok(record, 'Finish has no matching prepare')
        const instrumentation = hookModule(module)
        assert.equal(instrumentation.active, null)
        instrumentation.active = record
        const started = performance.now()
        let output
        try {
            output = Reflect.apply(original, undefined, [prepared])
        } finally {
            record.finishMs = performance.now() - started
            instrumentation.active = null
            preparedRecords.delete(prepared)
        }
        assert.equal(record.nativeCompressionMsCalls, 1)
        assert.equal(record.envelopeMsCalls, record.writeBlockEnvelope ? 1 : 0)
        record.finishRemainderMs = record.finishMs - record.nativeCompressionMs - record.envelopeMs
        record.outputBytes = output.byteLength
        record.outputSha256 = hash(output)
        appendFileSync(journal, JSON.stringify(record) + '\n')
        return output
    },
})

registerHooks({
    load(url, context, nextLoad) {
        const result = nextLoad(url, context)
        if (!url.startsWith('file:') || fileURLToPath(url) !== target) return result
        assert.equal(++loaded, 1, 'Wrapper loaded more than once in the same realm')
        let code = typeof result.source === 'string' ? result.source : Buffer.from(result.source).toString('utf8')
        assert.equal(hash(code), wrapperSha256, 'Unexpected loaded Zstd wrapper bytes')
        for (const name of ['prepareSpanCompression', 'finishPreparedSpanCompression']) {
            const needle = `function ${name}(`
            assert.equal(code.split(needle).length, 2, `Ambiguous export ${name}`)
            code = code.replace(needle, `function ${name}Original(`)
        }
        code += `\nfunction prepareSpanCompression(...args) { return globalThis[Symbol.for('${hookName}')].prepare(prepareSpanCompressionOriginal, args, getModule()) }\n`
        code += `function finishPreparedSpanCompression(prepared) { return globalThis[Symbol.for('${hookName}')].finish(finishPreparedSpanCompressionOriginal, prepared, getModule()) }\n`
        appendFileSync(journal, JSON.stringify({type: 'loaded', loadedSourceSha256: hash(code)}) + '\n')
        return {...result, source: code}
    },
})

if (isMainThread) {
    Reflect.set(globalThis, Symbol.for('manabitan.perf.finalize'), async (report) => {
        assert.equal(report.rows, 526942)
        assert.ok(report.workerTransport && report.workerTransport.compressionJobs > 0)
        const names = readdirSync(outputRoot).filter((name) => name.startsWith(`worker-${process.pid}-`) && name.endsWith('.jsonl'))
        const records = names.flatMap((name) => readFileSync(path.join(outputRoot, name), 'utf8').trim().split('\n').map((line) => JSON.parse(line)))
        const jobs = records.filter((row) => row.type === 'compression')
        assert.equal(jobs.length, report.workerTransport.compressionJobs)
        assert.equal(jobs.reduce((sum, row) => sum + row.contentBytes, 0), report.workerTransport.compressionInputBytes)
        assert.equal(jobs.reduce((sum, row) => sum + row.outputBytes, 0), report.workerTransport.compressionOutputBytes)
        assert.ok(jobs.every((row) => !row.isMainThread && row.spans.shared))
        assert.equal(new Set(jobs.map((row) => `${row.threadId}:${row.ordinal}`)).size, jobs.length)
        const byThread = {}
        for (const job of jobs) {
            const totals = byThread[job.threadId] ??= {jobs: 0, contentBytes: 0, prepareMs: 0, nativeCompressionMs: 0, envelopeMs: 0, finishRemainderMs: 0}
            ++totals.jobs
            for (const key of ['contentBytes', 'prepareMs', 'nativeCompressionMs', 'envelopeMs', 'finishRemainderMs']) totals[key] += job[key]
        }
        assert.equal(hash(readFileSync(target)), wrapperSha256)
        assert.equal(hash(readFileSync(fileURLToPath(import.meta.url))), preloadSha256)
        return {name: marker.name, diagnosticOnly: true, jobs: jobs.length, byThread,
            warning: 'Per-thread cumulative synchronous phase work is not elapsed import time. Worker phases overlap. Journaling and span statistics run outside these timers but perturb scheduling.',
            journals: names.map((name) => ({name, sha256: hash(readFileSync(path.join(outputRoot, name)))}))}
    })
}
