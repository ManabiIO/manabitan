import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {readFile, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {fileURLToPath, pathToFileURL} from 'node:url'

const source = path.resolve(process.env.PUBLICATION_SCREEN_SOURCE)
const output = path.resolve(process.env.PUBLICATION_SCREEN_OUTPUT)
const script = fileURLToPath(import.meta.url)
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const ns = () => process.hrtime.bigint()
const elapsed = (start) => Number(ns() - start) / 1e6
const sourcePath = path.join(source, 'ext/js/dictionary/dictionary-database.js')
const currentSource = await readFile(sourcePath, 'utf8')
const sourceHash = hash(currentSource)
const baselineCommit = 'a4be72046'
const baselineSource = execFileSync('git', ['show', `${baselineCommit}:ext/js/dictionary/dictionary-database.js`], {cwd: source, encoding: 'utf8'})
const scalarBody = (text) => {
    const method = text.indexOf('    _publishArtifactTermContentMetadata(state) {')
    const start = text.indexOf('            const dictName = uniformPendingDictName ?? pendingResolvedDictNames[i];', method)
    const end = text.indexOf('        const recentSourceCacheStart', start)
    assert.ok(method >= 0 && start > method && end > start)
    return text.slice(start, end)
}
assert.equal(scalarBody(currentSource), scalarBody(baselineSource), 'The complete scalar publication loop must be unchanged from the baseline')
const {DictionaryDatabase} = await import(pathToFileURL(sourcePath).href)
const prototype = DictionaryDatabase.prototype
const original = prototype._publishArtifactTermContentMetadata
const originalFast = prototype._tryPublishContiguousArtifactTermContentMetadata
assert.equal(typeof originalFast, 'function')
const blocks = 12
const orders = [['A', 'B', 'C', 'D'], ['B', 'D', 'A', 'C'], ['C', 'A', 'D', 'B'], ['D', 'C', 'B', 'A']]
const reverse = process.env.PUBLICATION_SCREEN_REVERSE === '1'
const fields = ['_termEntryContentMetaIdTable', '_termEntryContentMetaOffsetTable', '_termEntryContentMetaDictNameIdTable', '_termEntryContentMetaStateTable']
const countFields = ['_termEntryContentMetaHashPairPendingCount', '_termEntryContentMetaHashPairCount']
const specimens = []
const excluded = []

globalThis[Symbol.for('manabitan.perf.instrumentation')] = {diagnosticOnly: true, kind: 'live-publication-range-replay', sourceHash, scriptSha256: hash(await readFile(script))}

prototype._publishArtifactTermContentMetadata = function replay(state) {
    const staged = state.stagedContentMetadata
    const count = state.pendingOffsets.length
    if (!staged || count === 0 || typeof state.pendingResolvedDictNames !== 'string') {
        excluded.push({count, reason: 'unsupported shape'})
        return original.call(this, state)
    }
    const first = staged.indexes[0]
    if (first < 0 || [...staged.indexes].some((value, index) => value !== first + index)) {
        excluded.push({count, reason: 'noncontiguous reservations'})
        return original.call(this, state)
    }
    const end = first + count
    const oldTables = Object.fromEntries(fields.map((name) => [name, this[name].slice(first, end)]))
    const oldCounts = Object.fromEntries(countFields.map((name) => [name, this[name]]))
    const oldNames = [...this._termEntryContentMetaDictNames]
    const oldNameIds = new Map(this._termEntryContentMetaDictNameIdByValue)
    const oldOffsets = state.contentOffsets.slice()
    const oldLengths = state.contentLengths.slice()
    const oldMetrics = state.importMetrics
    const oldFastDescriptor = Object.getOwnPropertyDescriptor(this, '_tryPublishContiguousArtifactTermContentMetadata')
    const oldCacheDescriptor = Object.getOwnPropertyDescriptor(this, '_cacheRecentPublishedTermContentSources')
    let expected = null
    let acceptedCalls = 0
    let cacheCalls = 0
    const restore = () => {
        for (const name of fields) this[name].set(oldTables[name], first)
        Object.assign(this, oldCounts)
        this._termEntryContentMetaDictNames = [...oldNames]
        this._termEntryContentMetaDictNameIdByValue = new Map(oldNameIds)
        state.contentOffsets.set(oldOffsets)
        state.contentLengths.set(oldLengths)
        state.importMetrics = void 0
    }
    const restoreProperty = (name, descriptor) => {
        if (descriptor) Object.defineProperty(this, name, descriptor)
        else delete this[name]
    }
    const snapshot = (result) => ({
        result,
        tables: Object.fromEntries(fields.map((name) => [name, this[name].slice(first, end)])),
        counts: Object.fromEntries(countFields.map((name) => [name, this[name]])),
        dictNames: [...this._termEntryContentMetaDictNames],
        dictNameIds: [...this._termEntryContentMetaDictNameIdByValue],
        offsets: state.contentOffsets.slice(),
        lengths: state.contentLengths.slice(),
    })
    const run = (arm) => {
        restore()
        this._cacheRecentPublishedTermContentSources = () => { ++cacheCalls; return 0 }
        this._tryPublishContiguousArtifactTermContentMetadata = arm === 'B' || arm === 'D' ? function checked(...args) {
            const accepted = originalFast.apply(this, args)
            assert.ok(accepted, 'A real source group did not execute the candidate')
            ++acceptedCalls
            return accepted
        } : () => false
        const cpu = process.cpuUsage()
        const started = ns()
        const result = original.call(this, state)
        const wallMs = elapsed(started)
        const used = process.cpuUsage(cpu)
        const actual = snapshot(result)
        if (expected === null) expected = actual
        else assert.deepEqual(actual, expected)
        return {arm, wallMs, cpuUserMs: used.user / 1000, cpuSystemMs: used.system / 1000}
    }
    const warmups = []
    const observations = []
    try {
        for (let i = 0; i < 2; ++i) for (const arm of orders[i]) warmups.push(run(arm))
        for (let block = 0; block < blocks; ++block) {
            const order = orders[(block + specimens.length) % 4]
            for (const arm of reverse ? [...order].reverse() : order) observations.push({block, ...run(arm)})
        }
    } finally {
        restore()
        state.importMetrics = oldMetrics
        restoreProperty('_tryPublishContiguousArtifactTermContentMetadata', oldFastDescriptor)
        restoreProperty('_cacheRecentPublishedTermContentSources', oldCacheDescriptor)
    }
    assert.equal(acceptedCalls, 2 * blocks + 4)
    assert.equal(cacheCalls, state.isFinalTermChunk ? 0 : 4 * blocks + 8)
    specimens.push({count, rows: state.count, firstIndex: first, metadataValidated: state.metadataValidated === true, isFinalTermChunk: state.isFinalTermChunk === true,
        acceptedCalls, cacheCalls, warmups, observations})
    return original.call(this, state)
}

const median = (values) => {
    const sorted = [...values].sort((a, b) => a - b)
    return sorted.length % 2 ? sorted[(sorted.length - 1) / 2] : (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2
}

globalThis[Symbol.for('manabitan.perf.finalize')] = async (report) => {
    prototype._publishArtifactTermContentMetadata = original
    assert.equal(report.rows, 526942)
    assert.equal(report.fixture.sha256, '7681ee09f9edfef48a5e50773565da237424eb750bdb0e1e59660784ecd53e8a')
    assert.ok(specimens.length > 1)
    assert.deepEqual(excluded, [])
    assert.equal(specimens.reduce((n, entry) => n + entry.rows, 0), report.rows)
    const observations = []
    for (let block = 0; block < blocks; ++block) for (const arm of ['A', 'B', 'C', 'D']) {
        const parts = specimens.map((entry) => entry.observations.find((run) => run.block === block && run.arm === arm))
        observations.push({block, arm, wallMs: parts.reduce((n, value) => n + value.wallMs, 0),
            cpuUserMs: parts.reduce((n, value) => n + value.cpuUserMs, 0), cpuSystemMs: parts.reduce((n, value) => n + value.cpuSystemMs, 0)})
    }
    const comparisons = {}
    for (const [from, to] of [['A', 'B'], ['A', 'C'], ['A', 'D'], ['B', 'D']]) {
        const changes = Array.from({length: blocks}, (_, block) => {
            const a = observations.find((entry) => entry.block === block && entry.arm === from)
            const b = observations.find((entry) => entry.block === block && entry.arm === to)
            return {block, wallChangePercent: 100 * (b.wallMs - a.wallMs) / a.wallMs,
                cpuChangePercent: 100 * ((b.cpuUserMs + b.cpuSystemMs) - (a.cpuUserMs + a.cpuSystemMs)) / (a.cpuUserMs + a.cpuSystemMs)}
        })
        comparisons[`${to}/${from}`] = {medianWallChangePercent: median(changes.map((entry) => entry.wallChangePercent)),
            medianCpuChangePercent: median(changes.map((entry) => entry.cpuChangePercent)), fasterBlocks: changes.filter((entry) => entry.wallChangePercent < 0).length, changes}
    }
    assert.equal(hash(await readFile(sourcePath)), sourceHash)
    const result = {schemaVersion: 1, boundary: 'Production publication method replayed synchronously at each original callback with exact pending metadata restored between arms. Baseline A/C force the unchanged scalar loop, B/D require the checked bulk range. Cache copy is replaced by an equal zero-work sink and metrics disabled in every arm; setup, restoration, snapshots and exact state/output verification are outside timers. Per-group times are summed by balanced block; no complete-import claim.',
        source: report.source, fixture: report.fixture, sourceHash, baselineCommit, baselineSourceSha256: hash(baselineSource), unchangedScalarLoopSha256: hash(scalarBody(baselineSource)), scriptSha256: hash(await readFile(script)), runtime: {node: process.version, v8: process.versions.v8},
        rows: report.rows, blocks, reverse, specimens, excluded, observations, comparisons,
        armMedians: Object.fromEntries(['A', 'B', 'C', 'D'].map((arm) => [arm, median(observations.filter((entry) => entry.arm === arm).map((entry) => entry.wallMs))])),
        storedFilesCanonicalSha256: report.storedFilesCanonicalSha256, verification: report.verification,
    }
    await writeFile(output, `${JSON.stringify(result, null, 2)}\n`, {flag: 'wx'})
    return {output, comparisons}
}
