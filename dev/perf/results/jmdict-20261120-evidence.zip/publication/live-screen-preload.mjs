import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {fileURLToPath, pathToFileURL} from 'node:url'

const source = path.resolve(process.env.CACHE_SCREEN_SOURCE)
const output = path.resolve(process.env.CACHE_SCREEN_OUTPUT)
const blocks = 12
const script = fileURLToPath(import.meta.url)
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const ns = () => process.hrtime.bigint()
const elapsed = (start) => Number(ns() - start) / 1e6
const modulePath = path.join(source, 'ext/js/dictionary/dictionary-database.js')
const sourceBytes = await readFile(modulePath)
const {DictionaryDatabase} = await import(pathToFileURL(modulePath).href)
const original = DictionaryDatabase.prototype._cacheRecentPublishedTermContentSources
const originalSet = Uint8Array.prototype.set
const specimens = []
const order = [['A', 'B', 'C', 'D'], ['B', 'D', 'A', 'C'], ['C', 'A', 'D', 'B'], ['D', 'C', 'B', 'A']]
const reverse = process.env.CACHE_SCREEN_REVERSE === '1'

function copyWords(destination, input) {
    let cursor = 0
    const leading = Math.min(input.length, (4 - (input.byteOffset & 3)) & 3)
    for (; cursor < leading; ++cursor) destination[cursor] = input[cursor]
    const words = Math.floor((input.length - cursor) / 4)
    if (words > 0) {
        new Uint32Array(destination.buffer, destination.byteOffset + cursor, words).set(
            new Uint32Array(input.buffer, input.byteOffset + cursor, words),
        )
        cursor += words * 4
    }
    for (; cursor < input.length; ++cursor) destination[cursor] = input[cursor]
}

globalThis[Symbol.for('manabitan.perf.instrumentation')] = {
    diagnosticOnly: true,
    kind: 'cache-copy-on-actual-live-wasm-view',
    scriptSha256: hash(await readFile(script)),
    sourceSha256: hash(sourceBytes),
}

DictionaryDatabase.prototype._cacheRecentPublishedTermContentSources = function capture(staged, spans) {
    if (staged === null || spans === null || !(spans.buffer.buffer instanceof SharedArrayBuffer)) {
        return original.call(this, staged, spans)
    }
    let copyMs = 0
    let calls = 0
    let input = null
    let owned = null
    Uint8Array.prototype.set = function observeSet(value, offset = 0) {
        if (value instanceof Uint8Array && value.buffer instanceof SharedArrayBuffer) {
            const started = ns()
            const result = originalSet.call(this, value, offset)
            copyMs += elapsed(started)
            ++calls
            input = value
            owned = this
            return result
        }
        return originalSet.call(this, value, offset)
    }
    const started = ns()
    let copiedBytes
    let methodMs
    try {
        copiedBytes = original.call(this, staged, spans)
        methodMs = elapsed(started)
    } finally {
        Uint8Array.prototype.set = originalSet
    }
    if (copiedBytes === 0) return copiedBytes
    assert.equal(calls, 1)
    assert.ok(input && owned)
    assert.equal(input.buffer, spans.buffer.buffer)
    assert.equal(input.length, copiedBytes)
    assert.equal(owned.length, copiedBytes)
    const expected = owned.slice()
    const inputHash = hash(input)
    const buffers = Object.fromEntries(['A', 'B', 'C', 'D'].map((arm) => [arm, new Uint8Array(owned.buffer.byteLength).subarray(owned.byteOffset)]))
    const run = (arm) => {
        const destination = buffers[arm]
        destination.fill(0)
        const cpu = process.cpuUsage()
        const started = ns()
        if (arm === 'B' || arm === 'D') copyWords(destination, input)
        else destination.set(input)
        const wallMs = elapsed(started)
        const used = process.cpuUsage(cpu)
        assert.deepEqual(destination, expected)
        return {arm, wallMs, cpuUserMs: used.user / 1000, cpuSystemMs: used.system / 1000}
    }
    const warmups = []
    for (let i = 0; i < 2; ++i) for (const arm of order[i]) warmups.push(run(arm))
    const observations = []
    for (let block = 0; block < blocks; ++block) {
        const baseOrder = order[(block + specimens.length) % 4]
        const arms = reverse ? [...baseOrder].reverse() : baseOrder
        for (const arm of arms) observations.push({block, ...run(arm)})
    }
    assert.equal(hash(input), inputHash)
    assert.deepEqual(owned, expected)
    specimens.push({methodMs, copyMs, otherMethodMs: methodMs - copyMs, calls, copiedBytes,
        actualSourceViewByteOffset: input.byteOffset, sourceBackingBytes: input.buffer.byteLength,
        expectedSha256: inputHash, ownedPaddingBytes: owned.byteOffset,
        warmups, observations})
    return copiedBytes
}

const median = (values) => {
    const sorted = [...values].sort((a, b) => a - b)
    return sorted.length % 2 ? sorted[(sorted.length - 1) / 2] : (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2
}

globalThis[Symbol.for('manabitan.perf.finalize')] = async (report) => {
    DictionaryDatabase.prototype._cacheRecentPublishedTermContentSources = original
    assert.equal(report.rows, 526942)
    assert.equal(report.fixture.sha256, '7681ee09f9edfef48a5e50773565da237424eb750bdb0e1e59660784ecd53e8a')
    assert.equal(report.harnessSemanticsVersion, 4)
    assert.ok(specimens.length > 1)
    const attribution = specimens.reduce((result, entry) => {
        for (const key of ['methodMs', 'copyMs', 'otherMethodMs', 'calls', 'copiedBytes']) result[key] = (result[key] ?? 0) + entry[key]
        return result
    }, {})
    const observations = []
    for (let block = 0; block < blocks; ++block) for (const arm of ['A', 'B', 'C', 'D']) {
        const parts = specimens.map((entry) => entry.observations.find((run) => run.block === block && run.arm === arm))
        observations.push({block, arm, wallMs: parts.reduce((n, value) => n + value.wallMs, 0),
            cpuUserMs: parts.reduce((n, value) => n + value.cpuUserMs, 0), cpuSystemMs: parts.reduce((n, value) => n + value.cpuSystemMs, 0)})
    }
    const comparisons = {}
    for (const [from, to] of [['A', 'B'], ['A', 'C'], ['A', 'D'], ['B', 'D']]) {
        const changes = Array.from({length: blocks}, (_, block) => {
            const a = observations.find((entry) => entry.block === block && entry.arm === from)
            const b = observations.find((entry) => entry.block === block && entry.arm === to)
            return {block, wallChangePercent: 100 * (b.wallMs - a.wallMs) / a.wallMs,
                cpuChangePercent: 100 * ((b.cpuUserMs + b.cpuSystemMs) - (a.cpuUserMs + a.cpuSystemMs)) / (a.cpuUserMs + a.cpuSystemMs)}
        })
        comparisons[`${to}/${from}`] = {medianWallChangePercent: median(changes.map((entry) => entry.wallChangePercent)),
            medianCpuChangePercent: median(changes.map((entry) => entry.cpuChangePercent)), fasterBlocks: changes.filter((entry) => entry.wallChangePercent < 0).length, changes}
    }
    assert.equal(hash(await readFile(modulePath)), hash(sourceBytes))
    const result = {schemaVersion: 1, boundary: 'Isolated preallocated copies inside each real synchronous cache callback, against the original live borrowed parser WebAssembly memory view. No reconstructed source buffer or source retention beyond the parser lease. Timers exclude output preparation and exact byte checks. Group times are summed by balanced block; each source is measured before parser reuse. The instrumented import timing is not performance evidence.',
        runtime: {node: process.version, v8: process.versions.v8}, source: report.source, fixture: report.fixture,
        scriptSha256: hash(await readFile(script)), policy: report.policy, rows: report.rows,
        groups: report.groupResults.map(({banks, rows, isFinalTermChunk, parser}) => ({banks, rows, isFinalTermChunk, borrowedContentResultCount: parser.borrowedContentResultCount})),
        attribution, blocks, reverse, specimens, observations, comparisons,
        armMedians: Object.fromEntries(['A', 'B', 'C', 'D'].map((arm) => [arm, median(observations.filter((entry) => entry.arm === arm).map((entry) => entry.wallMs))]))}
    await writeFile(output, `${JSON.stringify(result, null, 2)}\n`, {flag: 'wx'})
    return {output, attribution, comparisons}
}
