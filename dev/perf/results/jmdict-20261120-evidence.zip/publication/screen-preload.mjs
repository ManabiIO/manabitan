import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {fileURLToPath, pathToFileURL} from 'node:url'

const source = path.resolve(process.env.CACHE_SCREEN_SOURCE)
const output = path.resolve(process.env.CACHE_SCREEN_OUTPUT)
const repetitions = Number(process.env.CACHE_SCREEN_BLOCKS ?? 12)
assert.ok(Number.isSafeInteger(repetitions) && repetitions > 0)
const script = fileURLToPath(import.meta.url)
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const ns = () => process.hrtime.bigint()
const elapsed = (start) => Number(ns() - start) / 1e6
const modulePath = path.join(source, 'ext/js/dictionary/dictionary-database.js')
const sourceBytes = await readFile(modulePath)
const {DictionaryDatabase} = await import(pathToFileURL(modulePath).href)
const original = DictionaryDatabase.prototype._cacheRecentPublishedTermContentSources
const originalSet = Uint8Array.prototype.set
const originalSource = original.toString()
const specimens = []
const diagnostics = []

// The source is owned by the parser lease for this entire synchronous copy.
// Destination alignment is the production cache's existing eight-byte padding.
function copyWords(destination, input) {
    let cursor = 0
    const leading = Math.min(input.length, (4 - (input.byteOffset & 3)) & 3)
    for (; cursor < leading; ++cursor) destination[cursor] = input[cursor]
    const words = Math.floor((input.length - cursor) / 4)
    if (words > 0) {
        new Uint32Array(destination.buffer, destination.byteOffset + cursor, words).set(
            new Uint32Array(input.buffer, input.byteOffset + cursor, words),
        )
        cursor += words * 4
    }
    for (; cursor < input.length; ++cursor) destination[cursor] = input[cursor]
}

const marker = 'owned.set(source.subarray(minimumOffset, maximumEnd));'
assert.equal(originalSource.split(marker).length, 2)
const candidateSource = originalSource.replace(marker, 'copyWords(owned, source.subarray(minimumOffset, maximumEnd));')
const constants = ['TERM_CONTENT_META_SLOT_PUBLISHED', 'TERM_CONTENT_RECENT_SOURCE_CACHE_MAX_AVERAGE_BYTES', 'TERM_CONTENT_RECENT_SOURCE_CACHE_AVERAGE_SAMPLE_COUNT']
const values = constants.map((name) => {
    const match = sourceBytes.toString().match(new RegExp(`const ${name} = (\\d+);`))
    assert.ok(match, name)
    return Number(match[1])
})
const candidate = new Function('copyWords', ...constants, `return function ${candidateSource}`)(copyWords, ...values)

globalThis[Symbol.for('manabitan.perf.instrumentation')] = {
    diagnosticOnly: true,
    kind: 'cache-shared-copy-attribution-and-isolated-replay',
    scriptSha256: hash(await readFile(script)),
    sourceSha256: hash(sourceBytes),
}

DictionaryDatabase.prototype._cacheRecentPublishedTermContentSources = function capture(staged, spans) {
    if (staged === null || spans === null || !(spans.buffer.buffer instanceof SharedArrayBuffer)) {
        return original.call(this, staged, spans)
    }
    const before = {
        _recentTermContentSourceBatches: new Map(this._recentTermContentSourceBatches),
        _recentTermContentSourceBatchBytes: this._recentTermContentSourceBatchBytes,
        _recentTermContentSourceCacheMaxBytes: this._recentTermContentSourceCacheMaxBytes,
        _nextRecentTermContentSourceBatchId: this._nextRecentTermContentSourceBatchId,
    }
    const indexedStates = Uint8Array.from(staged.indexes, (index) => this._termEntryContentMetaStateTable[index] ?? 0)
    let copyMs = 0
    let calls = 0
    let copyInput = null
    let copyOutput = null
    Uint8Array.prototype.set = function observeSet(input, offset = 0) {
        if (input instanceof Uint8Array && input.buffer instanceof SharedArrayBuffer) {
            const started = ns()
            const result = originalSet.call(this, input, offset)
            copyMs += elapsed(started)
            ++calls
            copyInput = input
            copyOutput = this
            return result
        }
        return originalSet.call(this, input, offset)
    }
    const started = ns()
    let copiedBytes
    let methodMs
    try {
        copiedBytes = original.call(this, staged, spans)
        methodMs = elapsed(started)
    } finally {
        Uint8Array.prototype.set = originalSet
    }
    diagnostics.push({methodMs, copyMs, otherMethodMs: methodMs - copyMs, calls, copiedBytes})
    if (copiedBytes === 0) return copiedBytes
    assert.equal(calls, 1)
    assert.ok(copyInput && copyOutput)
    assert.equal(copyInput.length, copiedBytes)
    assert.equal(copyOutput.length, copiedBytes)
    const stableBuffer = new Uint8Array(new SharedArrayBuffer(spans.buffer.byteLength + (spans.buffer.byteOffset & 7)), spans.buffer.byteOffset & 7, spans.buffer.byteLength)
    stableBuffer.set(spans.buffer)
    const minimumOffset = copyInput.byteOffset - spans.buffer.byteOffset
    specimens.push({
        spans: {buffer: stableBuffer, offsets: new Uint32Array(spans.offsets), lengths: new Uint32Array(spans.lengths)},
        staged: {indexes: new Int32Array(staged.indexes), active: staged.active},
        indexedStates,
        stateLength: this._termEntryContentMetaStateTable.length,
        batchIdLength: this._termEntryContentMetaRecentSourceBatchIdTable.length,
        offsetLength: this._termEntryContentMetaRecentSourceOffsetTable.length,
        before,
        minimumOffset,
        copiedBytes,
        padding: copyOutput.byteOffset,
        backingBytes: copyOutput.buffer.byteLength,
        expected: copyOutput.slice(),
        expectedBatchId: this._nextRecentTermContentSourceBatchId - 1,
        expectedResidentBytes: this._recentTermContentSourceBatchBytes,
        expectedIds: [...this._recentTermContentSourceBatches.keys()],
    })
    return copiedBytes
}

const median = (values) => {
    const sorted = [...values].sort((a, b) => a - b)
    return sorted.length % 2 ? sorted[(sorted.length - 1) / 2] : (sorted[sorted.length / 2 - 1] + sorted[sorted.length / 2]) / 2
}
const order = [['A', 'B', 'C', 'D'], ['B', 'D', 'A', 'C'], ['C', 'A', 'D', 'B'], ['D', 'C', 'B', 'A']]
const reverse = process.env.CACHE_SCREEN_REVERSE === '1'

function measure(kind) {
    const maxStateLength = Math.max(...specimens.map((entry) => entry.stateLength))
    const owner = {
        _termEntryContentMetaStateTable: new Uint8Array(maxStateLength),
        _termEntryContentMetaRecentSourceBatchIdTable: new Uint32Array(maxStateLength),
        _termEntryContentMetaRecentSourceOffsetTable: new Uint32Array(maxStateLength),
    }
    const outputs = specimens.map((entry) => new Uint8Array(entry.backingBytes).subarray(entry.padding))
    const inputs = specimens.map((entry) => entry.spans.buffer.subarray(entry.minimumOffset, entry.minimumOffset + entry.copiedBytes))
    const run = (arm) => {
        const optimized = arm === 'B' || arm === 'D'
        let wallMs = 0
        let cpuUserUs = 0
        let cpuSystemUs = 0
        for (let i = 0; i < specimens.length; ++i) {
            const entry = specimens[i]
            if (kind === 'copy-into-preallocated') {
                outputs[i].fill(0)
            } else {
                Object.assign(owner, entry.before)
                owner._recentTermContentSourceBatches = new Map(entry.before._recentTermContentSourceBatches)
                owner._termEntryContentMetaStateTable.fill(0)
                owner._termEntryContentMetaRecentSourceBatchIdTable.fill(0)
                owner._termEntryContentMetaRecentSourceOffsetTable.fill(0)
                for (let j = 0; j < entry.staged.indexes.length; ++j) {
                    owner._termEntryContentMetaStateTable[entry.staged.indexes[j]] = entry.indexedStates[j]
                }
            }
            const cpu = process.cpuUsage()
            const started = ns()
            let copied
            if (kind === 'copy-into-preallocated') {
                if (optimized) copyWords(outputs[i], inputs[i])
                else outputs[i].set(inputs[i])
            } else copied = (optimized ? candidate : original).call(owner, entry.staged, entry.spans)
            wallMs += elapsed(started)
            const used = process.cpuUsage(cpu)
            cpuUserUs += used.user
            cpuSystemUs += used.system
            // Every copied byte and relevant publication result is checked outside timing.
            if (kind === 'copy-into-preallocated') assert.deepEqual(outputs[i], entry.expected)
            else {
                assert.equal(copied, entry.copiedBytes)
                assert.equal(owner._recentTermContentSourceBatchBytes, entry.expectedResidentBytes)
                assert.deepEqual([...owner._recentTermContentSourceBatches.keys()], entry.expectedIds)
                const actual = owner._recentTermContentSourceBatches.get(entry.expectedBatchId)
                assert.equal(actual.byteOffset, entry.padding)
                assert.equal(actual.buffer.byteLength, entry.backingBytes)
                assert.deepEqual(actual, entry.expected)
                for (let j = 0; j < entry.staged.indexes.length; ++j) {
                    const index = entry.staged.indexes[j]
                    if (index < 0 || entry.indexedStates[j] !== values[0]) continue
                    assert.equal(owner._termEntryContentMetaRecentSourceBatchIdTable[index], entry.expectedBatchId)
                    assert.equal(owner._termEntryContentMetaRecentSourceOffsetTable[index], entry.spans.offsets[j] - entry.minimumOffset)
                }
            }
        }
        return {arm, wallMs, cpuUserMs: cpuUserUs / 1000, cpuSystemMs: cpuSystemUs / 1000}
    }
    const warmups = []
    for (let i = 0; i < 2; ++i) for (const arm of order[i]) warmups.push(run(arm))
    const observations = []
    for (let block = 0; block < repetitions; ++block) {
        const arms = reverse ? [...order[block % 4]].reverse() : order[block % 4]
        for (const arm of arms) observations.push({block, ...run(arm)})
    }
    const comparisons = {}
    for (const [from, to] of [['A', 'B'], ['A', 'C'], ['A', 'D'], ['B', 'D']]) {
        const changes = Array.from({length: repetitions}, (_, block) => {
            const a = observations.find((entry) => entry.block === block && entry.arm === from)
            const b = observations.find((entry) => entry.block === block && entry.arm === to)
            return {block, wallChangePercent: 100 * (b.wallMs - a.wallMs) / a.wallMs,
                cpuChangePercent: 100 * ((b.cpuUserMs + b.cpuSystemMs) - (a.cpuUserMs + a.cpuSystemMs)) / (a.cpuUserMs + a.cpuSystemMs)}
        })
        comparisons[`${to}/${from}`] = {medianWallChangePercent: median(changes.map((entry) => entry.wallChangePercent)),
            medianCpuChangePercent: median(changes.map((entry) => entry.cpuChangePercent)), fasterBlocks: changes.filter((entry) => entry.wallChangePercent < 0).length, changes}
    }
    return {kind, warmups, observations, comparisons, armMedians: Object.fromEntries(['A', 'B', 'C', 'D'].map((arm) => [arm, median(observations.filter((entry) => entry.arm === arm).map((entry) => entry.wallMs))]))}
}

globalThis[Symbol.for('manabitan.perf.finalize')] = async (report) => {
    DictionaryDatabase.prototype._cacheRecentPublishedTermContentSources = original
    assert.equal(report.rows, 526942)
    assert.equal(report.fixture.sha256, '7681ee09f9edfef48a5e50773565da237424eb750bdb0e1e59660784ecd53e8a')
    assert.equal(report.harnessSemanticsVersion, 4)
    assert.ok(specimens.length > 1)
    const beforeIdentities = specimens.map((entry) => hash(entry.spans.buffer))
    const attribution = diagnostics.reduce((result, entry) => {
        for (const key of ['methodMs', 'copyMs', 'otherMethodMs', 'calls', 'copiedBytes']) result[key] = (result[key] ?? 0) + entry[key]
        return result
    }, {})
    process.stderr.write(`Captured ${specimens.length} real shared source spans; ${attribution.copiedBytes} bytes; copy ${attribution.copyMs.toFixed(1)} / method ${attribution.methodMs.toFixed(1)} ms\n`)
    const copy = measure('copy-into-preallocated')
    const method = measure('whole-cache-method')
    assert.deepEqual(specimens.map((entry) => hash(entry.spans.buffer)), beforeIdentities)
    assert.equal(hash(await readFile(modulePath)), hash(sourceBytes))
    const result = {
        schemaVersion: 1, boundary: 'Node isolated source-cache copy and complete synchronous cache-publication method. Real production parser SAB spans and publication states captured during the full fixture; reconstructed owners retain prior cache maps. Setup, owner reset, hash and byte/state verification are outside each timer. Full import timings with this instrumentation are diagnostic only. No browser or complete-import speedup claim.',
        runtime: {node: process.version, v8: process.versions.v8}, source: report.source, fixture: report.fixture,
        scriptSha256: hash(await readFile(script)), originalMethodSha256: hash(originalSource), candidateMethodSha256: hash(candidateSource),
        policy: report.policy, corpusRows: report.rows, groups: report.groupResults.map(({banks, rows, isFinalTermChunk}) => ({banks, rows, isFinalTermChunk})),
        specimenCount: specimens.length, byteIdentities: beforeIdentities, specimenBytes: specimens.map((entry) => ({copied: entry.copiedBytes, backing: entry.backingBytes, padding: entry.padding})),
        diagnostics, attribution, repetitions, reverse, copy, method,
    }
    await writeFile(output, `${JSON.stringify(result, null, 2)}\n`, {flag: 'wx'})
    return {output, attribution, copy: copy.comparisons, method: method.comparisons}
}
