#!/usr/bin/env python3
# Copyright (C) 2026 Manabitan authors
# SPDX-License-Identifier: GPL-3.0-or-later
"""Reconcile fixed worker-study evidence without rerunning any measurement."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics

ROWS = 526942
CANONICAL = "2f559a8b0d90ed063d01b9650aee46cbbe52f469bc2ffd6ebbd74dd265e3e34c"
SEMANTIC = "8926122e434123d9823d867845ed8480734e0ada8381204e1857f88b216d8974"
FIXTURE = "7681ee09f9edfef48a5e50773565da237424eb750bdb0e1e59660784ecd53e8a"
HEADS = {"baseline": "99787e4c8bcaea1f508b18326e3f1d74cfc094b3", "candidate": "d8d18d9a7a9b56e8d05be851b5ae0c769a36a384"}
WORK = {"completedCompressionJobs": 102, "compressionInputBytes": 99878881, "compressionJobs": 102,
        "compressionOutputBytes": 12265565, "compressionSpanJobs": 102, "compressionWorkers": 4,
        "parserWorkers": 3, "sourceConsumedMessages": 102}
IDENTITY_KEYS = ["commit", "trackedDiffSha256", "runtimeTree"]


def digest(value):
    return hashlib.sha256(value).hexdigest()


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"))


def reconcile(actual, expected, label="value"):
    if isinstance(expected, dict):
        assert actual.keys() == expected.keys(), label
        for key in expected:
            reconcile(actual[key], expected[key], f"{label}.{key}")
    elif isinstance(expected, list):
        assert len(actual) == len(expected), label
        for index, value in enumerate(expected):
            reconcile(actual[index], value, f"{label}[{index}]")
    elif isinstance(expected, (int, float)) and not isinstance(expected, bool):
        assert math.isfinite(actual) and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-9), (label, actual, expected)
    else:
        assert actual == expected, (label, actual, expected)


def statistics_for(values):
    ordered = sorted(values)
    return {"count": len(values), "median": statistics.median(values), "min": ordered[0],
            "max": ordered[-1], "p95": ordered[math.ceil(len(values) * 0.95) - 1]}


def metrics(report):
    timing = report["timing"]
    return {"wallMs": timing["componentMs"], "cpuMs": timing["cpuUserMs"] + timing["cpuSystemMs"],
            "finalizationMs": timing["finalizationMs"], "maxRssKiB": report["runtime"]["maxRssKiB"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--check-live-inputs", action="store_true", help="Also hash current runtime files, fixture, harness inputs, and Node binary")
    args = parser.parse_args()
    base = args.directory.resolve()
    evidence = {}
    live_inputs = {}

    def read(name):
        filename = base / name
        data = filename.read_bytes()
        evidence[name] = {"bytes": len(data), "sha256": digest(data)}
        return data

    def load(name):
        return json.loads(read(name))

    def live(filename, expected_sha, expected_bytes=None):
        if not args.check_live_inputs:
            return
        filename = str(filename)
        if filename not in live_inputs:
            path = Path(filename)
            assert path.resolve(strict=True) == path and not path.is_symlink()
            data = path.read_bytes()
            live_inputs[filename] = {"bytes": len(data), "sha256": digest(data)}
        assert live_inputs[filename]["sha256"] == expected_sha, filename
        if expected_bytes is not None:
            assert live_inputs[filename]["bytes"] == expected_bytes, filename

    all_results = {}
    first_protocol = None
    first_manifests = None
    canonical_files = None

    def validate_report(report, source_key, protocol, manifests, verified):
        nonlocal canonical_files
        assert report["rows"] == ROWS
        assert report["schemaVersion"] == 1 and report["harnessSemanticsVersion"] == 5
        assert report["boundary"]["kind"] == "node-parallel-import-components"
        assert report["instrumentation"] is None
        assert report["timing"]["profiled"] is False and report["timing"]["instrumentedDiagnostic"] is False
        assert report["runtime"]["node"] == protocol["nodeVersion"] == "v22.22.0"
        assert report["runtime"]["execArgv"] == protocol["nodeArguments"] == ["--max-old-space-size=1400"]
        assert report["fixture"]["sha256"] == FIXTURE
        assert report["workerTransport"] == {**WORK, "errors": []}
        assert report["workerLookupFallbackGroups"] is None
        for key in IDENTITY_KEYS:
            assert report["source"][key] == protocol["sourceIdentities"][source_key][key]
        assert report["source"]["dirtyFiles"] == []
        manifest_by_name = {file["name"]: file for file in manifests[source_key]["files"]}
        for file in report["source"]["files"]:
            assert file == manifest_by_name[file["name"]]
        for report_key, suffix in [("harnessSha256", "/dev/perf/jmdict-component-benchmark.js"),
                                   ("adapterSha256", "/test/fixtures/opfs-continuation/node-opfs-adapter.mjs"),
                                   ("workerTransportSha256", "/dev/perf/node-import-workers.js")]:
            matches = [sha for filename, sha in protocol["lockedFiles"].items() if filename.endswith(suffix)]
            assert len(matches) == 1 and report[report_key] == matches[0]
        policy = report["policy"]
        assert policy["nodeWorkers"] is True and policy["verify"] is verified
        assert policy["deviceMemory"] == 8 and policy["hardwareConcurrency"] == 4
        assert policy["groupCount"] == policy["requestedGroupCount"] == 12
        assert policy["groups"] == policy["limitBanks"] == 0
        assert policy["sourceRun"] == {"startIndex": 0, "fileCount": 53, "totalFileCount": 53}
        assert policy["sourceRunExhaustsTermFiles"] is True
        groups = report["groupResults"]
        assert len(groups) == 12 and sum(group["rows"] for group in groups) == ROWS
        assert sum(group["sourceBytes"] for group in groups) == policy["sourceUncompressedBytes"] == 171092992
        assert [bank for group in groups for bank in group["banks"]] == [f"term_bank_{i}.json" for i in range(1, 54)]
        rows = 0
        for index, group in enumerate(groups, 1):
            rows += group["rows"]
            assert group["processedRows"] == rows
            assert group["pipelineProgress"]["chunkIndex"] == index
            assert group["pipelineProgress"]["chunkCount"] == 12
            assert group["isFinalTermChunk"] == (index == 12)
        assert groups[-1]["dictionaryTotalRows"] == ROWS
        assert report["parserTotals"]["parallelGroupCount"] == 12
        files = report["storedFiles"]
        by_name = {file["name"]: file for file in files}
        assert len(by_name) == len(files)
        for file in files:
            normalization = file["normalization"]
            if normalization is None:
                assert file["sha256"] == file["canonicalSha256"]
                assert not file["name"].endswith((".mbtr", ".mbti"))
            else:
                paired = by_name[normalization["pairedFile"]]["normalization"]
                assert paired["pairedFile"] == file["name"] and paired["generationId"] == normalization["generationId"]
                assert len(bytes.fromhex(normalization["generationId"])) == 16
                expected_mask = {"offset": 8 if file["name"].endswith(".mbtr") else 24, "length": 16}
                assert normalization["mask"] == expected_mask
                assert normalization["format"] == ("MBTRD16X" if file["name"].endswith(".mbtr") else "MBTIDX11")
        normalized = [{"name": file["name"], "bytes": file["bytes"], "sha256": file["canonicalSha256"]} for file in files]
        raw_manifest = [{key: file[key] for key in ["name", "bytes", "sha256"]} for file in files]
        assert digest(compact(raw_manifest).encode()) == report["storedFilesSha256"]
        assert digest(compact(normalized).encode()) == report["storedFilesCanonicalSha256"] == CANONICAL
        if canonical_files is None:
            canonical_files = normalized
        assert normalized == canonical_files
        if verified:
            assert report["verification"]["rows"] == ROWS
            assert report["verification"]["sha256"] == SEMANTIC
        else:
            assert report["verification"] is None

    for orientation in ["forward", "reverse"]:
        folder = f"worker-{orientation}"
        protocol = load(f"{folder}/protocol.json")
        summary = load(f"{folder}/summary.json")
        assert not (base / folder / "failure.json").exists()
        assert summary["status"] == "complete" and summary["protocol"] == protocol
        assert protocol["blocks"] == 12 and protocol["order"] == orientation
        assert protocol["sourceHeads"] == HEADS
        assert protocol["expectedCanonicalSha256"] == CANONICAL
        assert protocol["sources"]["A"] == protocol["sources"]["C"] != protocol["sources"]["B"] == protocol["sources"]["D"]
        assert protocol["inheritedInstrumentation"] == {"NODE_OPTIONS": None, "NODE_V8_COVERAGE": None}
        orders = ["ABDC", "BCAD", "CDBA", "DACB"]
        if orientation == "reverse":
            orders = [order[::-1] for order in orders]
        schedule = [{"name": f"warmup-{arm}", "block": None, "arm": arm} for arm in orders[0]]
        schedule += [{"name": f"block-{block:02d}-{arm}", "block": block, "arm": arm} for block in range(1, 13) for arm in orders[(block - 1) % 4]]
        assert protocol["schedule"] == schedule
        manifests = {}
        for key in HEADS:
            name = f"{folder}/{key}-source-manifest.json"
            manifest = manifests[key] = load(name)
            assert evidence[name]["sha256"] == protocol["sourceManifests"][key]["sha256"]
            assert manifest["commit"] == HEADS[key] and manifest["trackedDiffSha256"] == digest(b"")
            assert {key: manifest[key] for key in IDENTITY_KEYS} == protocol["sourceIdentities"][key]
            files = manifest["files"]
            assert len({file["name"] for file in files}) == len(files) == 381
            assert files == sorted(files, key=lambda file: file["name"])
            canonical = "".join(compact([file["name"], file["bytes"], file["sha256"]]) + "\n" for file in files)
            assert digest(canonical.encode()) == manifest["runtimeTree"]["sha256"]
            assert sum(file["bytes"] for file in files) == manifest["runtimeTree"]["bytes"]
            for file in files:
                live(Path(manifest["path"]) / file["name"], file["sha256"], file["bytes"])
        for filename, sha in protocol["lockedFiles"].items():
            live(filename, sha)
        live(protocol["node"], protocol["nodeBinarySha256"])
        if first_protocol is None:
            first_protocol, first_manifests = protocol, manifests
        else:
            for key in ["sourceIdentities", "lockedFiles", "nodeBinarySha256", "nodeVersion", "nodeArguments", "sources"]:
                assert protocol[key] == first_protocol[key]
            assert manifests == first_manifests
        observations = [json.loads(line) for line in read(f"{folder}/observations.jsonl").decode().splitlines()]
        assert len(observations) == summary["observations"] == 52
        for ordinal, (observation, planned) in enumerate(zip(observations, schedule), 1):
            assert {key: observation[key] for key in planned} == planned and observation["ordinal"] == ordinal
            name = planned["name"]
            raw = load(f"{folder}/{name}.json")
            receipt = load(f"{folder}/{name}-exit.json")
            read(f"{folder}/{name}.log")
            assert receipt == {key: value for key, value in observation.items() if key not in ["metrics", "reportSha256"]}
            assert receipt["exitCode"] == 0
            assert evidence[f"{folder}/{name}.json"]["sha256"] == observation["reportSha256"]
            source_key = "baseline" if planned["arm"] in "AC" else "candidate"
            validate_report(raw, source_key, protocol, manifests, False)
            command = receipt["command"]
            assert command[:2] == [protocol["node"], *protocol["nodeArguments"]]
            assert command[command.index("--source") + 1] == protocol["sources"][planned["arm"]] == raw["source"]["path"]
            assert command[command.index("--output") + 1] == str(Path(protocol["sourceManifests"]["baseline"]["path"]).parent / f"{name}.json")
            assert "--no-verify" in command and "--node-workers" in command
            reconcile(observation["metrics"], metrics(raw), f"{folder}/{name}.metrics")
        measured = [row for row in observations if row["block"] is not None]
        by_block = {(row["block"], row["arm"]): row["metrics"] for row in measured}
        assert len(measured) == len(by_block) == 48
        expected_arms = {arm: {metric: statistics_for([row["metrics"][metric] for row in measured if row["arm"] == arm]) for metric in ["wallMs", "cpuMs", "maxRssKiB"]} for arm in "ABCD"}
        expected_comparisons = {}
        for numerator, denominator in [("C", "A"), ("D", "B"), ("B", "A"), ("D", "A")]:
            comparisons = expected_comparisons[f"{numerator}/{denominator}"] = {}
            for metric in ["wallMs", "cpuMs", "maxRssKiB"]:
                pairs = [(by_block[(block, denominator)][metric], by_block[(block, numerator)][metric]) for block in range(1, 13)]
                changes = [100 * (after / before - 1) for before, after in pairs]
                comparisons[metric] = {**statistics_for(changes), "equalWorkChangePercent": 100 * (sum(after for before, after in pairs) / sum(before for before, after in pairs) - 1), "fasterPairs": sum(after < before for before, after in pairs), "pairedChangesPercent": changes}
        reconcile(summary["arms"], expected_arms, f"{folder}.arms")
        reconcile(summary["comparisons"], expected_comparisons, f"{folder}.comparisons")
        assert summary["executedWork"] == WORK
        all_results[orientation] = {"rawReports": len(observations), "timed": len(measured), "warmups": 4,
            "armMedians": {arm: {metric: stats["median"] for metric, stats in data.items()} for arm, data in expected_arms.items()},
            "comparisons": {pair: {metric: {key: data[key] for key in ["median", "equalWorkChangePercent", "fasterPairs", "min", "max"]} for metric, data in metrics.items()} for pair, metrics in expected_comparisons.items()}}

    parity = load("final-oracles/parity-summary.json")
    assert parity == {"status": "passed", "rows": ROWS, "canonicalSha256": CANONICAL, "sourceRowSemanticSha256": SEMANTIC}
    for name, key in [("control-source-rows", "baseline"), ("candidate-source-rows", "candidate")]:
        raw = load(f"final-oracles/{name}.json")
        receipt = load(f"final-oracles/{name}-exit.json")
        read(f"final-oracles/{name}.log")
        assert receipt["exitCode"] == 0
        validate_report(raw, key, first_protocol, first_manifests, True)
        assert "--no-verify" not in receipt["command"]
    proof = [{"name": name, **identity} for name, identity in sorted(evidence.items())]
    audit = {"status": "passed", "verifierSha256": digest(Path(__file__).read_bytes()),
        "evidenceFiles": len(proof), "evidenceBytes": sum(file["bytes"] for file in proof), "evidenceManifestSha256": digest(compact(proof).encode()),
        "liveInputFilesChecked": len(live_inputs), "liveInputBytesChecked": sum(value["bytes"] for value in live_inputs.values()),
        "sourceHeads": HEADS, "rawWorkerReports": 104, "timedWorkerReports": 96, "excludedWarmups": 8,
        "separateFullRowOracles": 2, "rowsPerReport": ROWS, "canonicalArtifactSha256": CANONICAL,
        "sourceRowSemanticSha256": SEMANTIC, "executedWorkPerReport": WORK,
        "verified": ["Exact schedules and unique observation inventory", "Every raw-report hash and matching successful exit receipt", "Every report's source, runtime, harness, adapter, and worker identity", "Complete source-manifest canonical digests", "All artifact-manifest hashes and normalized per-file identities", "All row, group, bank, byte, worker, completion, and acknowledgement counts", "Both exhaustive reopened-row prerequisites", "Every arm statistic, paired change, faster-pair count, equal-work aggregate, and reported percentile"],
        "limits": ["Artifact hashes are recomputed from retained per-file digest manifests; temporary persisted files are not rerendered or reread by this audit.", "CPU time is process CPU work across worker threads, not elapsed latency.", "Max RSS includes post-timer artifact hashing and is not peak import-only memory."],
        "interpretation": "Correctness and evidence integrity pass. Candidate CPU point estimates favor both candidate arms in both orientations, but same-code CPU controls also drift. Wall estimates disagree between duplicate candidate arms and have very large same-code tails; reverse D/A median is slower despite a faster aggregate. Neither a stable whole-worker latency percentage nor browser import speedup is established. Do not pool, trim, subtract controls, or rerun for a favorable result.",
        "cohorts": all_results}
    target = args.output or base / "worker-study-audit.json"
    with target.open("x") as stream:
        json.dump(audit, stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"status": "passed", "receipt": str(target), "sha256": digest(target.read_bytes()), "evidenceFiles": len(proof), "liveInputFilesChecked": len(live_inputs)}, indent=2))


if __name__ == "__main__":
    main()
