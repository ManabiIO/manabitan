#!/usr/bin/env python3
"""Finish source-scoped lint, repository unit/build gates, and package comparison."""
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[3]
output = Path(__file__).resolve().parent
node = root.parent / 'runtime/node_modules/node/bin/node'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
assert head == 'd8d18d9a7a9b56e8d05be851b5ae0c769a36a384'
def run(name, command, timeout):
    print(json.dumps({'gate': name, 'status': 'started'}), flush=True)
    receipt = {'command': command, 'sourceCommit': head}
    before = time.monotonic()
    environment = dict(os.environ)
    environment['NODE_OPTIONS'] = '--max-old-space-size=2048'
    with (output / (name + '-launch.log')).open('x') as log:
        try:
            result = subprocess.run(command, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
            receipt['exitCode'] = result.returncode
        except subprocess.TimeoutExpired:
            receipt['exitCode'] = None
            receipt['error'] = 'Timed out'
    receipt['elapsedSeconds'] = time.monotonic() - before
    with (output / (name + '-launch-exit.json')).open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'gate': name, **receipt}), flush=True)
    assert receipt['exitCode'] == 0, name
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == head

changed = subprocess.check_output(['git', 'diff', '--name-only', 'd733d0efe53398bfc2b45985aa709ade54f5710a', 'HEAD'], cwd=root, text=True).splitlines()
javascript = [name for name in changed if name.endswith(('.js', '.mjs'))]
run('all-changed-javascript-lint', [str(node), 'node_modules/eslint/bin/eslint.js', '--no-warn-ignored', *javascript], 300)
run('repository-unit-build', ['python3', str(output / 'run-qualification.py'), '--skip-types'], 4200)
run('package-comparison', ['python3', str(output / 'compare-packages.py')], 400)
