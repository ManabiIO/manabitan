#!/usr/bin/env python3
"""Compare full persisted artifacts and reopened rows across supported fixtures."""
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[3]
output = Path(__file__).resolve().parent / 'compatibility'
output.mkdir(exist_ok=False)
node = root.parent / 'runtime/node_modules/node/bin/node'
cases = [
    {'name': 'jmnedict-workers', 'dictionary': 'jmnedict', 'fixture': 'JMnedict.zip', 'rows': 667942, 'workers': True, 'memory': 8, 'verify': True},
    {'name': 'jitendex-sequential', 'dictionary': 'jitendex', 'fixture': 'jitendex-yomitan.zip', 'rows': 435448, 'workers': False, 'memory': 8, 'verify': False},
    {'name': 'jmdict-low-memory-sequential', 'dictionary': 'jmdict', 'fixture': 'JMdict.zip', 'rows': 526942, 'workers': False, 'memory': 4, 'verify': True},
]
summary = []
for case in cases:
    reports = []
    for arm, source in [('control', root.parent / 'manabitan-control-current'), ('candidate', root)]:
        name = case['name'] + '-' + arm
        command = [str(node), '--max-old-space-size=1400', str(root / 'dev/perf/jmdict-component-benchmark.js'), '--source', str(source), '--fixture', str(root / 'builds/e2e-dictionary-cache' / case['fixture']), '--dictionary', case['dictionary'], '--output', str(output / (name + '.json')), '--device-memory', str(case['memory']), '--hardware-concurrency', '4']
        if case['workers']:
            command.append('--node-workers')
        if not case['verify']:
            command.append('--no-verify')
        start = time.monotonic()
        receipt = {'command': command, 'case': case, 'arm': arm}
        with (output / (name + '.log')).open('x') as log:
            try:
                result = subprocess.run(command, cwd=root, env=dict(os.environ), stdout=log, stderr=subprocess.STDOUT, timeout=300)
                receipt['exitCode'] = result.returncode
            except subprocess.TimeoutExpired:
                receipt['exitCode'] = None
                receipt['error'] = 'Timed out'
        receipt['elapsedSeconds'] = time.monotonic() - start
        with (output / (name + '-exit.json')).open('x') as stream:
            json.dump(receipt, stream, indent=2)
            stream.write('\n')
        assert receipt['exitCode'] == 0, name
        report = json.loads((output / (name + '.json')).read_text())
        assert report['rows'] == case['rows'], name
        if case['verify']:
            assert report['verification']['rows'] == case['rows']
        reports.append(report)
        print(json.dumps({'case': case['name'], 'arm': arm, 'rows': report['rows'], 'elapsedSeconds': receipt['elapsedSeconds']}), flush=True)
    assert reports[0]['storedFilesCanonicalSha256'] == reports[1]['storedFilesCanonicalSha256'], case['name']
    if case['verify']:
        assert reports[0]['verification']['sha256'] == reports[1]['verification']['sha256']
    summary.append({**case, 'status': 'passed', 'canonicalSha256': reports[0]['storedFilesCanonicalSha256'], 'sourceRowSemanticSha256': reports[0]['verification']['sha256'] if case['verify'] else None, 'groupCount': reports[0]['policy']['groupCount']})
with (output / 'summary.json').open('x') as stream:
    json.dump({'status': 'passed', 'cases': summary, 'jitendexOracleNote': 'Artifact parity only. Its raw-source media normalization mismatch was reproduced on pristine baseline in the preceding experiment; no source-JSON oracle is claimed.'}, stream, indent=2)
    stream.write('\n')
