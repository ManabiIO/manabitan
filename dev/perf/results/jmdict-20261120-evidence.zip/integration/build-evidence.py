#!/usr/bin/env python3
"""Build a deterministic, checksum-verified evidence archive after qualification."""
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[3]
work = root.parent
evidence = Path(__file__).resolve().parent
target = root / 'dev/perf/results/jmdict-20261120-evidence.zip'
payloads = {}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def add(source, archive, expected=None):
    source = Path(source)
    assert source.is_file() and not source.is_symlink(), source
    assert not archive.startswith('/') and '..' not in Path(archive).parts
    data = source.read_bytes()
    identity = {'source': str(source), 'archive': archive, 'bytes': len(data), 'sha256': digest(data)}
    if expected is not None:
        assert identity['bytes'] == expected['bytes'] and identity['sha256'] == expected['sha256'], source
    assert archive not in payloads, archive
    payloads[archive] = (data, identity)

plans = [work / 'evidence-packaging-plan.json', work / 'compression-screen/reader-production-packaging-plan.json']
for plan_path in plans:
    plan = json.loads(plan_path.read_text())
    for item in plan['files']:
        add(item['source'], item['archive'], item)
    add(plan_path, 'audit/' + plan_path.name)

add(work / 'evidence-audit/reader-production-verification.json', 'audit/reader-production-verification.json')

for source in sorted(evidence.rglob('*')):
    if not source.is_file() or '__pycache__' in source.parts:
        continue
    if source.name in ['report-established-sections.md', 'pr-body.md', 'archive-receipt.json']:
        continue
    add(source, 'integration/' + source.relative_to(evidence).as_posix())

manifest = {
    'schemaVersion': 1,
    'scope': 'JMdict round-two component experiments, fixed production-worker cohorts, full-fixture parity, required checks, rejected candidates, and source history',
    'qualifiedSourceCommit': 'd8d18d9a7a9b56e8d05be851b5ae0c769a36a384',
    'controlSourceCommit': '99787e4c8bcaea1f508b18326e3f1d74cfc094b3',
    'upstreamCommit': 'd733d0efe53398bfc2b45985aa709ade54f5710a',
    'files': [payloads[name][1] for name in sorted(payloads)],
    'count': len(payloads),
    'uncompressedBytes': sum(len(data) for data, identity in payloads.values()),
    'excluded': ['Pinned dictionary ZIPs', '100 MB decoded reader corpus', 'Upstream Zstd checkout and compiled libraries', 'Duplicate downloaded historical workflow ZIPs', 'Release package ZIPs'],
    'limits': ['Node components are not browser import latency', 'The historical phase-v3 diagnostic lacks its exact runner and transport snapshots; it is exploratory only', 'Reader timing uses the retained 4 MiB corpus, not the current 1 MiB import distribution'],
}
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in sorted(payloads):
        info = zipfile.ZipInfo(name, (2026, 11, 20, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, payloads[name][0], compresslevel=9)
    info = zipfile.ZipInfo('manifest.json', (2026, 11, 20, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    archive.writestr(info, json.dumps(manifest, indent=2, sort_keys=True) + '\n', compresslevel=9)

with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
    verified = json.loads(archive.read('manifest.json'))
    assert len(archive.namelist()) == verified['count'] + 1
    for item in verified['files']:
        data = archive.read(item['archive'])
        assert len(data) == item['bytes'] and digest(data) == item['sha256']
receipt = {'archive': str(target), 'bytes': target.stat().st_size, 'sha256': digest(target.read_bytes()), 'payloadFiles': manifest['count'], 'uncompressedBytes': manifest['uncompressedBytes'], 'verified': True}
with (evidence / 'archive-receipt.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps(receipt, indent=2))
