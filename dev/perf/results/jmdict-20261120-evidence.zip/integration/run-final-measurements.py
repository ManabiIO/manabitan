#!/usr/bin/env python3
"""Run frozen-source validation and two prespecified worker timing cohorts."""
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[3]
output = Path(__file__).resolve().parent
node = root.parent / 'runtime/node_modules/node/bin/node'
control = root.parent / 'manabitan-control-current'
def head(source):
    return subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
heads = {'control': head(control), 'candidate': head(root)}
assert heads == {'control': '99787e4c8bcaea1f508b18326e3f1d74cfc094b3', 'candidate': 'd8d18d9a7a9b56e8d05be851b5ae0c769a36a384'}
def run(name, command, timeout):
    assert {'control': head(control), 'candidate': head(root)} == heads
    receipt = {'command': command, 'sourceHeads': heads}
    before = time.monotonic()
    print(json.dumps({'stage': name, 'status': 'started'}), flush=True)
    with (output / (name + '-launch.log')).open('x') as log:
        try:
            result = subprocess.run(command, cwd=root, env=dict(os.environ), stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
            receipt['exitCode'] = result.returncode
        except subprocess.TimeoutExpired:
            receipt['exitCode'] = None
            receipt['error'] = 'Timed out'
    receipt['elapsedSeconds'] = time.monotonic() - before
    with (output / (name + '-launch-exit.json')).open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'stage': name, **receipt}), flush=True)
    assert receipt['exitCode'] == 0, name
    assert {'control': head(control), 'candidate': head(root)} == heads

run('types-bench-final', [str(node), '--max-old-space-size=2048', 'node_modules/typescript/bin/tsc', '--noEmit', '--project', 'benches/jsconfig.json'], 180)
run('final-oracles', ['python3', str(output / 'run-worker-oracles.py')], 400)
canonical = json.loads((output / 'final-oracles/parity-summary.json').read_text())['canonicalSha256']
for order in ['forward', 'reverse']:
    run('worker-study-' + order, [
        'python3', str(root / 'dev/perf/jmdict-worker-study.py'), '--node', str(node),
        '--baseline', str(control), '--candidate', str(root),
        '--fixture', str(root / 'builds/e2e-dictionary-cache/JMdict.zip'),
        '--output', str(output / ('worker-' + order)), '--blocks', '12', '--order', order,
        '--device-memory', '8', '--hardware-concurrency', '4',
        '--expected-canonical-sha256', canonical,
    ], 1200)
run('compatibility', ['python3', str(output / 'run-compatibility.py')], 1900)
