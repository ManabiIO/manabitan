import assert from 'node:assert/strict'
import {readFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {pathToFileURL, fileURLToPath} from 'node:url'
import path from 'node:path'
import {isMainThread} from 'node:worker_threads'

if (isMainThread) {
    const source = path.resolve(process.env.MANABITAN_LEASE_SOURCE ?? '/workspace/scratch/ee3ecb87c795/manabitan-baseline')
    const {DictionaryDatabase} = await import(pathToFileURL(path.join(source, 'ext/js/dictionary/dictionary-database.js')).href)
    const {TermContentBlockStore} = await import(pathToFileURL(path.join(source, 'ext/js/dictionary/term-content-block-store.js')).href)
    // _beginAppendSharedSpans belongs to the internal per-dictionary builder.
    // Locate that constructor through the actual import session's builder map
    // only when its public tryBeginAppendSpans creates it.
    const groups = []
    let active = null
    const observers = []
    const restorers = []
    const now = () => performance.now()
    function wrap(prototype, key, make) {
        const original = prototype[key]
        assert.equal(typeof original, 'function', key)
        prototype[key] = make(original)
        restorers.push(() => { prototype[key] = original })
    }
    const track = (promise, success, failure) => {
        const observer = promise.then(success, failure)
        observers.push(observer)
        void observer.catch(() => {})
    }
    const scriptPath = fileURLToPath(import.meta.url)
    const scriptSha256 = createHash('sha256').update(await readFile(scriptPath)).digest('hex')
    Reflect.set(globalThis, Symbol.for('manabitan.perf.instrumentation'), {
        name: 'lease-gap-observer', source, scriptSha256, diagnosticOnly: true,
        boundary: 'Observer callbacks on original storage, sourceConsumed, completion and release promises; no protocol or product return value changed. Cache coverage scan adds untimed diagnostic work and all timings remain diagnostic only.',
    })

    wrap(DictionaryDatabase.prototype, '_bulkAddArtifactTermsChunkWithContentDedup', original => function (chunk) {
        assert.equal(active, null, 'Expected ordered sink')
        const record = {group: groups.length + 1, rows: chunk.rowCount, isFinal: chunk.isFinalTermChunk === true, start: now(), releaseCalls: 0, operations: [], cache: null}
        groups.push(record)
        active = record
        const release = chunk.releaseBorrowedContent
        if (typeof release === 'function') {
            chunk.releaseBorrowedContent = function (...args) {
                ++record.releaseCalls
                record.releasedAt ??= now()
                return Reflect.apply(release, this, args)
            }
        }
        let operation
        try { operation = Reflect.apply(original, this, [chunk]) } catch (error) { active = null; throw error }
        track(operation, () => { record.end = now(); active = null }, error => { record.error = String(error); record.end = now(); active = null })
        return operation
    })
    wrap(DictionaryDatabase.prototype, '_tryBeginPersistArtifactTermContent', original => function (...args) {
        const operation = Reflect.apply(original, this, args)
        if (operation !== null && active) {
            active.storageWrapperReturned = now()
            track(operation.storage, () => { active && (active.storageResolvedAt = now()) }, () => {})
        }
        return operation
    })
    wrap(DictionaryDatabase.prototype, '_publishArtifactTermContentMetadata', original => function (...args) {
        const record = active
        if (record) record.publicationStart = now()
        const result = Reflect.apply(original, this, args)
        if (record) record.publicationEnd = now()
        return result
    })
    wrap(DictionaryDatabase.prototype, '_cacheRecentPublishedTermContentSources', original => function (staged, spans) {
        const record = active
        const started = now()
        const result = Reflect.apply(original, this, [staged, spans])
        const finished = now()
        if (record) {
            const batchId = this._nextRecentTermContentSourceBatchId - 1
            const buffer = this._recentTermContentSourceBatches.get(batchId)
            const auditStart = now()
            let covers = result > 0 && buffer instanceof Uint8Array && buffer.buffer instanceof ArrayBuffer && staged && spans && staged.indexes.length === spans.offsets.length && staged.indexes.length === spans.lengths.length
            const firstIndex = covers ? staged.indexes[0] : -1
            const shift = firstIndex >= 0 ? spans.offsets[0] - this._termEntryContentMetaRecentSourceOffsetTable[firstIndex] : null
            if (covers) {
                for (let i = 0; i < staged.indexes.length; i++) {
                    const index = staged.indexes[i]
                    const offset = spans.offsets[i] - shift
                    if (index < 0 || this._termEntryContentMetaRecentSourceBatchIdTable[index] !== batchId || this._termEntryContentMetaRecentSourceOffsetTable[index] !== offset || offset < 0 || spans.lengths[i] > buffer.length - offset) { covers = false; break }
                }
            }
            record.cache = {started, finished, bytes: result, fullCoverage: Boolean(covers), shift, witnessAuditMs: now() - auditStart}
        }
        return result
    })

    const originalBeginSession = TermContentBlockStore.prototype.beginImportSession
    wrap(TermContentBlockStore.prototype, 'beginImportSession', original => function (...args) {
        const session = Reflect.apply(original, this, args)
        const originalTry = session.tryBeginAppendSpans
        session.tryBeginAppendSpans = function (...input) {
            const record = active
            const started = now()
            const operation = Reflect.apply(originalTry, this, input)
            if (operation !== null && record) {
                const measurement = {started}
                record.operations.push(measurement)
                track(operation.storage, () => { measurement.storageAt = now() }, error => { measurement.storageError = String(error) })
                track(operation.sourceConsumed, () => { measurement.consumedAt = now() }, error => { measurement.consumedError = String(error) })
                track(operation.completion, () => { measurement.completedAt = now() }, error => { measurement.completionError = String(error) })
            }
            return operation
        }
        return session
    })
    assert.equal(typeof originalBeginSession, 'function')
    Reflect.set(globalThis, Symbol.for('manabitan.perf.finalize'), async report => {
        try {
            await Promise.all(observers)
            assert.equal(report.rows, 526942)
            assert.equal(report.verification?.rows, report.rows)
            assert.equal(report.workerTransport.parserWorkers, 3)
            assert.equal(report.workerTransport.compressionWorkers, 4)
            assert.equal(groups.length, 12)
            for (const record of groups) {
                assert.equal(record.operations.length, 1)
                assert.equal(record.releaseCalls, 1)
                const operation = record.operations[0]
                assert.equal(record.error, undefined)
                assert.equal(operation.consumedError, undefined)
                assert.equal(operation.completionError, undefined)
                assert.equal(operation.storageError, undefined)
                assert(Number.isFinite(operation.consumedAt))
                assert(Number.isFinite(operation.completedAt))
                record.sourceToCompletionGapMs = operation.completedAt - operation.consumedAt
                record.retargetedReleaseGate = Math.max(operation.consumedAt, record.publicationEnd)
                record.potentialReleaseAdvanceMs = record.cache?.fullCoverage ? Math.max(0, record.releasedAt - record.retargetedReleaseGate) : 0
            }
            return {groups, source, scriptSha256, diagnosticOnly: true, warning: 'Potential release advance is a per-group ownership interval, not additive pipeline or whole-import savings. Original completion/error drains remain authoritative. Coverage audit loops add diagnostic work.', totals: {
                eligibleGroups: groups.filter(x => x.cache?.fullCoverage).length,
                potentialReleaseAdvanceMs: groups.reduce((s, x) => s + x.potentialReleaseAdvanceMs, 0),
                witnessAuditMs: groups.reduce((s, x) => s + (x.cache?.witnessAuditMs ?? 0), 0),
            }}
        } finally { for (const restore of restorers.reverse()) restore() }
    })
}
