#!/usr/bin/env python3
"""Run required repository unit/build/type gates sequentially and retain receipts."""
import argparse
import collections
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[3]
node = root.parent / 'runtime/node_modules/node/bin/node'
output = Path(__file__).resolve().parent / 'qualification'
llvm = Path('/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr')
parser = argparse.ArgumentParser()
parser.add_argument('--types-only', action='store_true')
parser.add_argument('--skip-types', action='store_true')
args = parser.parse_args()
output.mkdir(exist_ok=True)
environment = dict(os.environ)
environment.update({
    'MANABITAN_CLANG': str(llvm / 'bin/clang-21'),
    'CLANG': str(llvm / 'bin/clang-21'),
    'MANABITAN_WASM_LD': str(llvm / 'bin/wasm-ld-21'),
    'LD_LIBRARY_PATH': str(llvm / 'lib/x86_64-linux-gnu') + (':' + environment['LD_LIBRARY_PATH'] if environment.get('LD_LIBRARY_PATH') else ''),
    'PATH': str(node.parent) + ':' + str(llvm / 'bin') + ':' + str(llvm / 'lib/llvm-21/bin') + ':' + environment['PATH'],
    'NODE_OPTIONS': '--max-old-space-size=2048',
})
def revision():
    return subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
def run(name, command, timeout=900):
    receipt = {'command': command, 'sourceCommitBefore': revision(), 'node': str(node), 'environmentOverrides': {k:environment[k] for k in ['MANABITAN_CLANG','MANABITAN_WASM_LD','NODE_OPTIONS']}}
    start = time.monotonic()
    with (output / (name + '.log')).open('x') as log:
        try:
            result = subprocess.run(command, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
            receipt['exitCode'] = result.returncode
        except subprocess.TimeoutExpired:
            receipt['exitCode'] = None
            receipt['error'] = 'Timed out'
    receipt.update(elapsedSeconds=time.monotonic()-start, sourceCommitAfter=revision())
    with (output / (name + '-exit.json')).open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'gate':name,'exitCode':receipt['exitCode'],'elapsedSeconds':receipt['elapsedSeconds']}), flush=True)
    assert receipt['sourceCommitBefore'] == receipt['sourceCommitAfter'], 'Source commit changed during gate'
    assert receipt['exitCode'] == 0, name

assert not (args.types_only and args.skip_types)
if not args.skip_types:
    for name, project in [('main','jsconfig.json'),('dev','dev/jsconfig.json'),('test','test/jsconfig.typecheck.json'),('bench','benches/jsconfig.json')]:
        run('types-' + name, [str(node), 'node_modules/typescript/bin/tsc', '--noEmit', '--project', project])
if args.types_only:
    raise SystemExit(0)
inventory_path = output/'unit-inventory.json'
assert not inventory_path.exists()
run('unit-inventory', [str(node), 'node_modules/vitest/vitest.mjs', 'list', '--filesOnly', '--json=' + str(inventory_path)])
inventory = json.loads(inventory_path.read_text())
expected = {item['file'] for item in inventory}
actual = []
counts = collections.Counter()
for shard in range(1,5):
    report = output/f'unit-shard-{shard}.json'
    run(f'unit-shard-{shard}', [str(node), 'node_modules/vitest/vitest.mjs', 'run', '--maxWorkers=1', '--testTimeout=60000', f'--shard={shard}/4', '--reporter=json', '--outputFile=' + str(report)])
    results = json.loads(report.read_text())
    for suite in results['testResults']:
        assert suite['status'] == 'passed', suite['name']
        actual.append(suite['name'])
        counts.update(item['status'] for item in suite['assertionResults'])
assert len(actual) == len(set(actual)), 'Duplicate files in shards'
assert set(actual) == expected, {'missing':sorted(expected-set(actual)),'unexpected':sorted(set(actual)-expected)}
run('build-dry-run', [str(node), 'dev/bin/build.js', '--dryRun', '--all'])
with (output/'summary.json').open('x') as stream:
    json.dump({'status':'passed','sourceCommit':revision(),'expectedFiles':len(expected),'uniqueExecutedFiles':len(actual),'assertions':dict(counts),'missingFiles':[],'duplicateFiles':[]}, stream, indent=2)
    stream.write('\n')
