#!/usr/bin/env python3
"""Build the same release target twice and compare every packaged entry."""
import hashlib
import json
from pathlib import Path
import subprocess
import time
import zipfile

root = Path(__file__).resolve().parents[3]
output = Path(__file__).resolve().parent / 'packages'
output.mkdir(exist_ok=False)
node = root.parent / 'runtime/node_modules/node/bin/node'
sources = {'control': root.parent / 'manabitan-control-current', 'candidate': root}
packages = {}
for arm, source in sources.items():
    command = [str(node), 'dev/bin/build.js', '--target', 'chrome']
    start = time.monotonic()
    with (output / (arm + '.log')).open('x') as stream:
        result = subprocess.run(command, cwd=source, stdout=stream, stderr=subprocess.STDOUT, timeout=180)
    receipt = {'command': command, 'cwd': str(source), 'exitCode': result.returncode, 'elapsedSeconds': time.monotonic() - start, 'sourceCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip()}
    with (output / (arm + '-exit.json')).open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    assert result.returncode == 0, arm
    package = source / 'builds/manabitan-chrome.zip'
    with zipfile.ZipFile(package) as archive:
        assert archive.testzip() is None
        entries = {name: {'bytes': len(archive.read(name)), 'sha256': hashlib.sha256(archive.read(name)).hexdigest()} for name in sorted(archive.namelist()) if not name.endswith('/')}
    packages[arm] = {'path': str(package), 'bytes': package.stat().st_size, 'sha256': hashlib.sha256(package.read_bytes()).hexdigest(), 'entries': entries}
assert packages['control']['entries'].keys() == packages['candidate']['entries'].keys()
changed = [name for name in packages['control']['entries'] if packages['control']['entries'][name] != packages['candidate']['entries'][name]]
wasm = [name for name in packages['control']['entries'] if name.endswith('.wasm')]
assert all(packages['control']['entries'][name] == packages['candidate']['entries'][name] for name in wasm)
summary = {'status': 'passed', 'target': 'chrome', 'packages': packages, 'changedEntries': changed, 'identicalWasmEntries': wasm, 'zipSizeChangeBytes': packages['candidate']['bytes'] - packages['control']['bytes']}
with (output / 'summary.json').open('x') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
print(json.dumps({key:value for key,value in summary.items() if key != 'packages'}, indent=2))
