#!/usr/bin/env python3
"""Full source-row and canonical-artifact qualification with production workers."""
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[3]
output = Path(__file__).resolve().parent / 'final-oracles'
output.mkdir(exist_ok=False)
node = root.parent / 'runtime/node_modules/node/bin/node'
fixture = root / 'builds/e2e-dictionary-cache/JMdict.zip'
canonical = None
semantic = '8926122e434123d9823d867845ed8480734e0ada8381204e1857f88b216d8974'
for name, source in [('control-source-rows', root.parent / 'manabitan-control-current'), ('candidate-source-rows', root)]:
    command = [str(node), '--max-old-space-size=1400', str(root / 'dev/perf/jmdict-component-benchmark.js'), '--source', str(source), '--fixture', str(fixture), '--output', str(output / f'{name}.json'), '--node-workers', '--hardware-concurrency', '4']
    environment = dict(os.environ)
    before = time.monotonic()
    receipt = {'command': command, 'boundary': 'Uninstrumented production-worker components plus exhaustive reopened source-row verification'}
    with (output / f'{name}.log').open('x') as log:
        result = subprocess.run(command, cwd=root, env=environment, stdout=log, stderr=subprocess.STDOUT, timeout=180)
    receipt.update(exitCode=result.returncode, elapsedSeconds=time.monotonic()-before)
    with (output / f'{name}-exit.json').open('x') as stream:
        json.dump(receipt, stream, indent=2)
        stream.write('\n')
    assert result.returncode == 0, name
    report = json.loads((output / f'{name}.json').read_text())
    assert report['rows'] == report['verification']['rows'] == 526942
    assert report['verification']['sha256'] == semantic
    if canonical is None:
        canonical = report['storedFilesCanonicalSha256']
    assert report['storedFilesCanonicalSha256'] == canonical
    print(json.dumps({'name': name, 'rows': report['rows'], 'canonical': canonical, 'semantic': report['verification']['sha256']}), flush=True)
with (output / 'parity-summary.json').open('x') as stream:
    json.dump({'status': 'passed', 'rows': 526942, 'canonicalSha256': canonical, 'sourceRowSemanticSha256': semantic}, stream, indent=2)
    stream.write('\n')
