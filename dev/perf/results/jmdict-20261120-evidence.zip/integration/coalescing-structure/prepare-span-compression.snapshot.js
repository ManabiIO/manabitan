function prepareSpanCompression(context, source, sourceOffsets, sourceLengths, contentBytes, dictionary, prefixBytes, level = 3, writeBlockEnvelope = false) {
  if (sourceOffsets.length !== sourceLengths.length) {
    throw new RangeError("Zstd source span offsets and lengths must have equal sizes");
  }
  if (!Number.isSafeInteger(contentBytes) || contentBytes < 0) {
    throw new RangeError("Zstd gathered content size must be a non-negative safe integer");
  }
  if (!Number.isSafeInteger(prefixBytes) || prefixBytes < 0) {
    throw new RangeError("Zstd output prefix must be a non-negative safe integer");
  }
  if (writeBlockEnvelope && prefixBytes !== TERM_CONTENT_BLOCK_ENVELOPE_BYTES) {
    throw new RangeError("Zstd block integrity envelope requires a 12-byte prefix");
  }
  const module = getModule();
  const bound = module._ZSTD_compressBound(contentBytes);
  const destinationSize = bound + prefixBytes;
  if (!Number.isSafeInteger(destinationSize)) {
    throw new RangeError("Zstd output buffer size exceeds the safe integer range");
  }
  const useAlignedSharedCopy = contentBytes >= 1024 && sourceOffsets.length > 0 && typeof SharedArrayBuffer !== "undefined" && source.buffer instanceof SharedArrayBuffer && !(module.HEAPU8.buffer instanceof SharedArrayBuffer);
  const sourceSize = contentBytes + (useAlignedSharedCopy ? 7 : 0);
  if (sourceSize > 4294967295) {
    throw new RangeError("Zstd source allocation exceeds the WASM address range");
  }
  const buffers = ensureContextBuffers(context, sourceSize, destinationSize, dictionary.byteLength);
  const heap = module.HEAPU8;
  const sourcePointer = buffers.source + (useAlignedSharedCopy ? source.byteOffset + sourceOffsets[0] - heap.byteOffset - buffers.source & 7 : 0);
  let outputOffset = 0;
  for (let i = 0; i < sourceOffsets.length; ) {
    const runOffset = sourceOffsets[i];
    let runLength = 0;
    let runSpanCount = 0;
    let runEnd = runOffset;
    do {
      const sourceOffset = sourceOffsets[i];
      const sourceLength = sourceLengths[i];
      if (sourceOffset > source.byteLength || sourceLength > source.byteLength - sourceOffset) {
        throw new RangeError(`Zstd source span ${i} is out of bounds`);
      }
      if (sourceLength > contentBytes - outputOffset - runLength) {
        throw new RangeError(`Zstd source span ${i} exceeds the gathered content size`);
      }
      if (runSpanCount > 0 && sourceOffset !== runEnd) {
        break;
      }
      runLength += sourceLength;
      runEnd = sourceOffset + sourceLength;
      ++runSpanCount;
      ++i;
    } while (i < sourceOffsets.length);
    const destinationOffset = sourcePointer + outputOffset;
    const prefix = useAlignedSharedCopy && runLength >= 1024 ? heap.byteOffset + destinationOffset - source.byteOffset - runOffset & 7 : 0;
    if (prefix === 0) {
      heap.set(source.subarray(runOffset, runOffset + runLength), destinationOffset);
    } else {
      heap.set(source.subarray(runOffset + prefix, runOffset + runLength), destinationOffset);
      heap.copyWithin(destinationOffset + prefix, destinationOffset, destinationOffset + runLength - prefix);
      heap.set(source.subarray(runOffset, runOffset + prefix), destinationOffset);
    }
    outputOffset += runLength;
  }
  if (outputOffset !== contentBytes) {
    throw new RangeError(`Zstd gathered ${outputOffset} bytes; expected ${contentBytes}`);
  }
  module.HEAPU8.set(dictionary, buffers.dictionary);
  if (prefixBytes > 0) {
    module.HEAPU8.fill(0, buffers.destination, buffers.destination + prefixBytes);
  }
  const prepared = { context, buffers, sourcePointer, contentBytes, dictionaryBytes: dictionary.byteLength, prefixBytes, level, writeBlockEnvelope };
  buffers.prepared = prepared;
  return prepared;
}
