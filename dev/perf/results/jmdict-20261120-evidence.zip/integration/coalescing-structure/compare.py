#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later
"""Compare previously captured compression work; never executes a benchmark."""

import argparse
import hashlib
import json
from pathlib import Path


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def identity(path):
    data = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": sha256(data)}


def prepare_function(path):
    source = path.read_text()
    start = "function prepareSpanCompression("
    end = "function finishPreparedSpanCompression("
    assert source.count(start) == source.count(end) == 1
    section = source[source.index(start):source.index(end)].strip() + "\n"
    assert section.endswith("return prepared;\n}\n")
    return section


def load_capture(directory, report_path, wrapper_path):
    paths = sorted(directory.glob("worker-*.jsonl"))
    assert paths, directory
    records = [json.loads(line) for path in paths for line in path.read_text().splitlines()]
    witnesses = [row for row in records if row["type"] == "identity"]
    jobs = [row for row in records if row["type"] == "compression"]
    wrapper = identity(wrapper_path)
    assert all(row["wrapperSha256"] == wrapper["sha256"] for row in witnesses)
    assert len({row["preloadSha256"] for row in witnesses}) == 1
    assert len({row["node"] for row in witnesses}) == 1
    report = json.loads(report_path.read_text())
    transport = report["workerTransport"]
    assert report["rows"] == 526942 and report["policy"]["groupCount"] == 12
    assert transport["errors"] == []
    assert len(jobs) == transport["compressionJobs"] == transport["completedCompressionJobs"] == transport["sourceConsumedMessages"] == 102
    assert sum(row["contentBytes"] for row in jobs) == transport["compressionInputBytes"]
    assert sum(row["outputBytes"] for row in jobs) == transport["compressionOutputBytes"]
    assert all(not row["isMainThread"] and row["spans"]["shared"] for row in jobs)
    assert len({row["outputSha256"] for row in jobs}) == len(jobs)
    return {
        "inputs": {"journals": [identity(path) for path in paths], "report": identity(report_path), "wrapper": wrapper},
        "recordedPreloadSha256": witnesses[0]["preloadSha256"],
        "node": witnesses[0]["node"],
        "report": report,
        "jobs": {row["outputSha256"]: row for row in jobs},
        "prepareFunction": prepare_function(wrapper_path),
    }


def totals(jobs):
    values = list(jobs.values())
    return {
        "jobs": len(values),
        "spanDescriptors": sum(row["spans"]["spans"] for row in values),
        "spanColumnBytes": 8 * sum(row["spans"]["spans"] for row in values),
        "contiguousRuns": sum(row["spans"]["runCount"] for row in values),
        "sourceBytesCopied": sum(row["contentBytes"] for row in values),
        "compressedOutputBytes": sum(row["outputBytes"] for row in values),
        "alignedRunBytes": sum(row["spans"]["alignedSharedRunBytes"] for row in values),
        "privateShiftBytes": sum(row["spans"]["privateShiftBytes"] for row in values),
        "derivedPreparationLoopVisits": sum(row["spans"]["spans"] + row["spans"]["runCount"] - 1 for row in values),
        "jobsWithSevenByteSourceAllowance": sum(row["contentBytes"] >= 1024 and row["spans"]["spans"] > 0 for row in values),
    }


def main():
    workspace = Path(__file__).resolve().parents[5]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline-journals", type=Path, default=workspace / "compression-screen/wasm-phases-v3")
    parser.add_argument("--baseline-report", type=Path, default=workspace / "compression-screen/wasm-phases-component-v3.json")
    parser.add_argument("--baseline-wrapper", type=Path, default=workspace / "manabitan-baseline/ext/lib/zstd-wasm.js")
    candidate = workspace / "manabitan-coalesced-spans/builds/perf/coalesced-spans-20261120"
    parser.add_argument("--candidate-journals", type=Path, default=candidate / "wasm-phases")
    parser.add_argument("--candidate-report", type=Path, default=candidate / "worker-diagnostic.json")
    parser.add_argument("--candidate-wrapper", type=Path, default=workspace / "manabitan-coalesced-spans/ext/lib/zstd-wasm.js")
    parser.add_argument("--current-wrapper", type=Path, default=workspace / "manabitan/ext/lib/zstd-wasm.js")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    baseline = load_capture(args.baseline_journals, args.baseline_report, args.baseline_wrapper)
    candidate = load_capture(args.candidate_journals, args.candidate_report, args.candidate_wrapper)
    function = prepare_function(args.current_wrapper)
    assert baseline["prepareFunction"] == candidate["prepareFunction"] == function
    assert baseline["jobs"].keys() == candidate["jobs"].keys()
    canonical = baseline["report"]["storedFilesCanonicalSha256"]
    assert canonical == candidate["report"]["storedFilesCanonicalSha256"] == "2f559a8b0d90ed063d01b9650aee46cbbe52f469bc2ffd6ebbd74dd265e3e34c"
    fields = ["contentBytes", "outputBytes", "dictionaryBytes", "prefixBytes", "level", "writeBlockEnvelope"]
    span_fields = ["shared", "sourceByteOffset", "sourceByteLength", "sourceBackingBytes", "outputOffset", "runCount", "longestRun", "alignedSharedRunBytes", "privateShiftBytes"]
    pairs = []
    for frame_hash in sorted(baseline["jobs"]):
        old = baseline["jobs"][frame_hash]
        new = candidate["jobs"][frame_hash]
        for field in fields:
            assert old[field] == new[field], (frame_hash, field)
        for field in span_fields:
            assert old["spans"][field] == new["spans"][field], (frame_hash, field)
        assert new["spans"]["spans"] == new["spans"]["runCount"]
        assert old["spans"]["runCount"] >= 1
        pairs.append({"frameSha256": frame_hash, "contentBytes": old["contentBytes"], "baselineSpans": old["spans"]["spans"], "coalescedSpans": new["spans"]["spans"], "runs": old["spans"]["runCount"], "privateShiftBytes": old["spans"]["privateShiftBytes"], "copyIdentityEqual": True})
    old = totals(baseline["jobs"])
    new = totals(candidate["jobs"])
    assert old["privateShiftBytes"] == new["privateShiftBytes"] == 76465125
    result = {
        "schemaVersion": 1,
        "scope": "Read-only structural comparison of saved instrumented diagnostics. No new import, replay or timing measurement.",
        "script": identity(Path(__file__)),
        "baseline": {"inputs": baseline["inputs"], "recordedPreloadSha256": baseline["recordedPreloadSha256"], "node": baseline["node"], "totals": old},
        "coalesced": {"inputs": candidate["inputs"], "recordedPreloadSha256": candidate["recordedPreloadSha256"], "node": candidate["node"], "totals": new},
        "currentWrapper": identity(args.current_wrapper),
        "prepareFunction": {"sha256": sha256(function.encode()), "bytes": len(function.encode()), "equalInAllThreeWrappers": True, "extraction": "Unique function prepareSpanCompression declaration through the next function finishPreparedSpanCompression declaration; strip surrounding whitespace and append one newline"},
        "canonicalStoredFilesSha256": canonical,
        "matchedJobs": pairs,
        "reduction": {"spanDescriptors": old["spanDescriptors"] - new["spanDescriptors"], "spanColumnBytes": old["spanColumnBytes"] - new["spanColumnBytes"], "derivedPreparationLoopVisits": old["derivedPreparationLoopVisits"] - new["derivedPreparationLoopVisits"], "privateShiftBytes": 0},
        "derivation": {
            "preparationLoopVisitsPerJob": "spanDescriptors + contiguousRuns - 1",
            "reason": "For valid spans, the inner do-loop validates every descriptor once; at every noncontiguous boundary it validates the next descriptor before breaking, then validates that descriptor again in the next outer iteration.",
            "checksPerVisit": "The source-range and remaining-output-range checks in prepareSpanCompression are both retained. This is a source-derived JS loop count, not a runtime instruction counter.",
        },
        "limitations": [
            "The coalesced and original wrappers already discover the same contiguous byte runs. Coalescing removes descriptor traversal, not gather copies.",
            "All 76,465,125 private shifted bytes remain; all 99,878,881 source bytes are still copied and all 102 jobs retain the aligned-copy seven-byte source-size allowance. Retained allocation capacity is not measured by summing allowances.",
            "The synchronous main-thread validation still scans every original span. Coalescing adds offset reads and run bookkeeping to the existing block-planning pass; this report does not price that work.",
            "Span-column bytes are summed allocation/copy work over the import, not peak memory or uniquely resident source bytes.",
            "Preloads differ: the later diagnostic adds gap statistics outside timers. Only shared structural fields are compared; diagnostic timings are deliberately excluded.",
            "Full original span arrays and borrowed source slabs were not saved. Existing 28-block raw reader corpus has different grouping and cannot reproduce this exact 102-job metadata comparison without new capture.",
            "Neither structural counts nor instrumented phase times establish elapsed worker-pipeline or browser import speedup.",
        ],
    }
    encoded = json.dumps(result, indent=2) + "\n"
    if args.output:
        with args.output.open("x") as stream:
            stream.write(encoded)
    else:
        print(encoded, end="")


if __name__ == "__main__":
    main()
