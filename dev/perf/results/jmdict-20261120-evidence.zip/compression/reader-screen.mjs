import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {fileURLToPath, pathToFileURL} from 'node:url'

const root = path.dirname(fileURLToPath(import.meta.url))
const sourceRoot = process.env.MANABITAN_READER_SOURCE ?? '/workspace/scratch/ee3ecb87c795/manabitan-baseline'
const corpusRoot = '/workspace/scratch/f34c9c9fae89/manabitan/builds/perf/checksum-corpus-regenerated/real-fixture'
const output = process.argv[2]
const reverse = process.argv.includes('--reverse')
assert.ok(output)
const hash = (value) => createHash('sha256').update(value).digest('hex')
const wrapper = await readFile(path.join(sourceRoot, 'ext/lib/zstd-wasm.js'), 'utf8')
assert.equal(wrapper.split('function getModule()').length, 2)
const diagnosticCodec = path.join(root, 'reader-codec.mjs')
const diagnosticSource = `${wrapper}\nexport {getModule as diagnosticGetModule}\n`
try {
    await writeFile(diagnosticCodec, diagnosticSource, {flag: 'wx'})
} catch (error) {
    assert.equal(error.code, 'EEXIST')
    assert.equal(await readFile(diagnosticCodec, 'utf8'), diagnosticSource)
}
const originalFetch = globalThis.fetch
globalThis.fetch = async (resource, options) => {
    const url = new URL(String(resource))
    if (url.protocol !== 'file:') return originalFetch(resource, options)
    return new Response(await readFile(url), {headers: {'Content-Type': 'application/wasm'}})
}
const api = await import(pathToFileURL(diagnosticCodec))
await api.init(pathToFileURL(path.join(sourceRoot, 'ext/lib/zstd.wasm')).href)
const module = api.diagnosticGetModule()
const {hashTermEntryContentBytesPair} = await import(pathToFileURL(path.join(sourceRoot, 'ext/js/dictionary/term-entry-content-hash.js')))
const dictionary = new Uint8Array(await readFile(path.join(sourceRoot, 'dev/data/zstd-dicts/jmdict.zdict')))
const manifest = JSON.parse(await readFile(path.join(corpusRoot, 'manifest.json'), 'utf8'))
const store = await readFile(path.join(corpusRoot, 'store.bin'))
const raw = await readFile(path.join(root, 'raw.bin'))
const corpus = JSON.parse(await readFile(path.join(root, 'corpus.json'), 'utf8'))
assert.equal(hash(store), manifest.storeSha256)
assert.equal(hash(raw), corpus.rawSha256)
const blocks = manifest.blocks.map((block, index) => {
    const bytes = store.subarray(block.offset, block.offset + block.length)
    assert.equal(hash(bytes), block.sha256)
    const reference = raw.subarray(corpus.blocks[index].rawOffset, corpus.blocks[index].rawOffset + block.uncompressedLength)
    assert.equal(hash(reference), block.uncompressedSha256)
    return {bytes, reference, expectedLength: block.uncompressedLength}
})

function header(bytes) {
    if (bytes.byteLength <= 12 || bytes[0] !== 77 || bytes[1] !== 66 || bytes[2] !== 67 || bytes[3] !== 50) {
        throw new Error('bad-envelope')
    }
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
    return [view.getUint32(4, true), view.getUint32(8, true)]
}

function verifyJs(bytes, expected) {
    const actual = hashTermEntryContentBytesPair(bytes.subarray(12))
    if (actual[0] !== expected[0] || actual[1] !== expected[1]) throw new Error('bad-checksum')
}

function baseline(context, bytes, expectedLength) {
    verifyJs(bytes, header(bytes))
    const result = api.decompressUsingDict(context, bytes.subarray(12), dictionary,
        {defaultHeapSize: expectedLength, maxOutputSize: expectedLength})
    if (result.byteLength !== expectedLength) throw new Error('bad-decoded-length')
    return result
}

function candidate(context, bytes, expectedLength) {
    const expected = header(bytes)
    const source = module._malloc(bytes.byteLength)
    if (source === 0) {
        verifyJs(bytes, expected)
        throw new Error('Failed to allocate Zstd input buffer')
    }
    try {
        module.HEAPU8.set(bytes, source)
        if (module._manabitan_write_block_envelope(source, bytes.byteLength) !== 1) throw new Error('bad-envelope')
        const view = new DataView(module.HEAPU8.buffer, source, 12)
        if (view.getUint32(4, true) !== expected[0] || view.getUint32(8, true) !== expected[1]) throw new Error('bad-checksum')
        const frame = source + 12
        const frameLength = bytes.byteLength - 12
        const frameSizeValue = module._ZSTD_getFrameContentSize(frame, frameLength)
        const frameSize = typeof frameSizeValue === 'bigint' ? Number(frameSizeValue) : frameSizeValue
        const outputSize = frameSize < 0 ? expectedLength : frameSize
        if (!Number.isSafeInteger(outputSize) || outputSize <= 0) throw new Error(`Invalid Zstd frame content size: ${frameSizeValue}`)
        if (!Number.isSafeInteger(expectedLength) || expectedLength <= 0) throw new RangeError(`Invalid Zstd output limit: ${expectedLength}`)
        if (outputSize > expectedLength) throw new RangeError(`Zstd frame output size ${outputSize} exceeds configured output limit ${expectedLength}`)
        const destination = module._malloc(outputSize)
        if (destination === 0) throw new Error('Failed to allocate Zstd destination buffer')
        let dictionaryPointer = 0
        try {
            dictionaryPointer = module._malloc(dictionary.byteLength)
            if (dictionaryPointer === 0) throw new Error('Failed to allocate Zstd dictionary buffer')
            module.HEAPU8.set(dictionary, dictionaryPointer)
            const size = module._ZSTD_decompress_usingDict(context, destination, outputSize,
                frame, frameLength, dictionaryPointer, dictionary.byteLength)
            if (module._ZSTD_isError(size) !== 0) throw new Error(`Zstd operation failed with code ${size}`)
            const result = module.HEAPU8.slice(destination, destination + size)
            if (result.byteLength !== expectedLength) throw new Error('bad-decoded-length')
            return result
        } finally {
            if (dictionaryPointer !== 0) module._free(dictionaryPointer)
            module._free(destination)
        }
    } finally {
        module._free(source)
    }
}

const contexts = Array.from({length: 4}, () => api.createDCtx())
const implementations = [baseline, candidate, baseline, candidate]
const orders = [[0, 1, 3, 2], [1, 2, 0, 3], [2, 3, 1, 0], [3, 0, 2, 1]]
if (reverse) orders.reverse().forEach((order) => order.reverse())
const report = {status: 'running', scope: 'Real-block checksum+WASM input copy+decompression+owned output component; no OPFS, reference reads, caches, or browser import timing',
    sourceRoot, wrapperSha256: hash(wrapper), diagnosticCodecSha256: hash(diagnosticSource), scriptSha256: hash(await readFile(fileURLToPath(import.meta.url))),
    dictionarySha256: hash(dictionary), wasmSha256: hash(await readFile(path.join(sourceRoot, 'ext/lib/zstd.wasm'))),
    corpusManifestSha256: hash(await readFile(path.join(corpusRoot, 'manifest.json'))), storeSha256: hash(store), rawSha256: hash(raw),
    node: process.version, protocol: {blocks: 24, warmupsPerArm: 2, gcBeforeArm: typeof globalThis.gc === 'function', reverse, orders},
    corruptionTests: [], warmups: [], observations: []}
await writeFile(output, `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'})

function checkCorruption() {
    const original = module._ZSTD_decompress_usingDict
    let decoderCalls = 0
    module._ZSTD_decompress_usingDict = (...args) => { ++decoderCalls; return original(...args) }
    const originalMalloc = module._malloc
    try {
        const cases = [
            ['bad-magic', (b) => { b[0] ^= 1; return b }, 'bad-envelope'],
            ['bad-checksum-word', (b) => { b[4] ^= 1; return b }, 'bad-checksum'],
            ['bad-second-checksum-word', (b) => { b[8] ^= 1; return b }, 'bad-checksum'],
            ['bad-payload', (b) => { b[b.length - 1] ^= 1; return b }, 'bad-checksum'],
            ['truncated-payload', (b) => b.subarray(0, b.length - 1), 'bad-checksum'],
            ['header-only', (b) => b.subarray(0, 12), 'bad-envelope'],
        ]
        for (const [name, mutate, expected] of cases) {
            const bytes = mutate(Uint8Array.from(blocks[0].bytes))
            const before = hash(bytes)
            for (const [label, implementation] of [['baseline', baseline], ['candidate', candidate]]) {
                const prior = decoderCalls
                assert.throws(() => implementation(contexts[0], bytes, blocks[0].expectedLength), new RegExp(expected))
                assert.equal(decoderCalls, prior)
                assert.equal(hash(bytes), before)
                report.corruptionTests.push({name, arm: label, rejectedBeforeDecoder: true, inputUnchanged: true})
            }
        }
        const malformed = Uint8Array.from(blocks[0].bytes)
        malformed[12] ^= 255
        const validHashes = hashTermEntryContentBytesPair(malformed.subarray(12))
        const malformedView = new DataView(malformed.buffer)
        malformedView.setUint32(4, validHashes[0], true)
        malformedView.setUint32(8, validHashes[1], true)
        const limitCases = [blocks[0].expectedLength - 1, blocks[0].expectedLength + 1, 0, -1, NaN, Infinity, 0.5]
        for (const [name, bytes, expectedLength] of [
            ['valid-checksum-malformed-frame', malformed, blocks[0].expectedLength],
            ...limitCases.map((length) => [`expected-length-${String(length)}`, blocks[0].bytes, length]),
        ]) {
            const before = hash(bytes)
            const outcomes = []
            for (const [label, implementation] of [['baseline', baseline], ['candidate', candidate]]) {
                const prior = decoderCalls
                let failure
                try { implementation(contexts[0], bytes, expectedLength) } catch (error) { failure = error }
                assert.ok(failure instanceof Error, name)
                assert.equal(hash(bytes), before)
                outcomes.push({name: failure.name, message: failure.message, decoderCalls: decoderCalls - prior})
                report.corruptionTests.push({name, arm: label, failure: outcomes.at(-1), inputUnchanged: true})
            }
            assert.deepEqual(outcomes[1], outcomes[0], name)
        }
        module._malloc = () => 0
        for (const [label, implementation] of [['baseline', baseline], ['candidate', candidate]]) {
            const bad = Uint8Array.from(blocks[0].bytes)
            bad[4] ^= 1
            const before = decoderCalls
            assert.throws(() => implementation(contexts[0], bad, blocks[0].expectedLength), /bad-checksum/)
            assert.throws(() => implementation(contexts[0], blocks[0].bytes, blocks[0].expectedLength), /Failed to allocate Zstd input buffer/)
            assert.equal(decoderCalls, before)
            report.corruptionTests.push({name: 'allocation-failure-order', arm: label, corruptStillRejectedAsChecksum: true, validReportsResourceFailure: true})
        }
    } finally {
        module._ZSTD_decompress_usingDict = original
        module._malloc = originalMalloc
    }
}

function observe(arm, block) {
    globalThis.gc?.()
    const cpuStart = process.cpuUsage()
    const started = performance.now()
    const results = blocks.map(({bytes, expectedLength}) => implementations[arm](contexts[arm], bytes, expectedLength))
    const wallMs = performance.now() - started
    const cpu = process.cpuUsage(cpuStart)
    let decodedBytes = 0
    for (let i = 0; i < blocks.length; ++i) {
        assert.equal(Buffer.compare(results[i], blocks[i].reference), 0)
        decodedBytes += results[i].byteLength
    }
    return {arm, block, wallMs, cpuMs: (cpu.user + cpu.system) / 1000, decodedBytes}
}

try {
    checkCorruption()
    for (let block = 0; block < 2; ++block) for (const arm of orders[block]) report.warmups.push(observe(arm, block))
    for (let block = 0; block < 24; ++block) {
        for (const arm of orders[block % orders.length]) report.observations.push(observe(arm, block))
    }
    assert.equal(hash(store), manifest.storeSha256, 'Stored corpus changed')
    assert.equal(hash(raw), corpus.rawSha256, 'Decoded oracle changed')
    const median = (values) => { values.sort((a, b) => a - b); return (values[(values.length - 1) >> 1] + values[values.length >> 1]) / 2 }
    report.summary = {}
    for (const arm of [1, 2, 3]) {
        const pairs = Array.from({length: 24}, (_, block) => report.observations.filter((row) => row.block === block))
        report.summary[arm] = {}
        for (const key of ['wallMs', 'cpuMs']) {
            const differences = pairs.map((rows) => 100 * (rows.find((r) => r.arm === arm)[key] / rows.find((r) => r.arm === 0)[key] - 1))
            report.summary[arm][key] = {pairedChangePercent: median(differences), fasterBlocks: differences.filter((n) => n < 0).length,
                baselineMedian: median(pairs.map((rows) => rows.find((r) => r.arm === 0)[key])),
                armMedian: median(pairs.map((rows) => rows.find((r) => r.arm === arm)[key]))}
        }
    }
    report.status = 'complete'
} catch (error) {
    report.status = 'failed'
    report.error = {name: error.name, message: error.message, stack: error.stack}
    throw error
} finally {
    report.maxRssKiB = process.resourceUsage().maxRSS
    await writeFile(output, `${JSON.stringify(report, null, 2)}\n`)
    for (const context of contexts) api.freeDCtx(context)
}
process.stdout.write(`${JSON.stringify({status: report.status, summary: report.summary, corruptionTests: report.corruptionTests.length})}\n`)
