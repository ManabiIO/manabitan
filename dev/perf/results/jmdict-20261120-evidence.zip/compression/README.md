# JMdict native compression setup screen — November 20, 2026

**Decision: do not add prepared compression state.** On the exact pinned Zstd source, dictionary setup is approximately 0.3% of total native compression work for this real-block corpus. Prepared state saves less than half a millisecond across the corpus, adds retained memory, and establishes no full-compression gain. These are native component measurements, not browser or whole-import measurements.

## Inputs and scope

- Zstd commit: `82d322c4973d9e2968d94047a40892bc6d9a9bdf`, matching Manabitan’s vendored source provenance.
- Current application checkout: `31d92b012298db2839233f4ce4c388d08d31006c`. The JMdict dictionary is byte-identical to the older corpus generator’s dictionary.
- Existing component corpus: 28 real production-packed blocks, 100,671,677 decoded bytes, from all 526,942 locked JMdict rows. It uses seven-bank parser groups and within-group content deduplication, not the browser’s source plan or cross-group deduplication. Its source revision is `bde55dfbee1451edc32051f8bf51e8a870d5c72c`.
- Every original envelope/frame hash and every full decoded-byte hash matched the corpus manifest before measurement. `corpus.json` pins every block and all input identities.
- GCC 14.2.0, `-O3 -DNDEBUG -fPIC -shared`, Linux x86-64. The native build has no JavaScript/WASM copying, workers, OPFS, UI, or import scheduler.

## Fixed protocol

Each of two independent processes used two excluded warmups per arm and 24 balanced four-arm blocks. The second process reverses the order schedule. Arms are the production raw dictionary API, a second raw API context as a same-code control, advanced CDict reuse with the exact production-selected parameters, and `ZSTD_copyCCtx` from a raw-initialized template. Each observation compresses every block once. The caller retains source and output buffers outside timing.

After every observation, all output frames are decompressed and compared byte-for-byte against all original uncompressed bytes. The raw arms and copied context must also match every original WASM frame byte exactly. Output hashes remain identical across warmups, observations, and profiling diagnostics within each arm.

Separate setup diagnostics wrap the exact native begin routine, then finish compression to preserve the real context state transition. Setup timers include their own clock overhead. They are not subtracted from the uninstrumented cohort. All 192 measured arm observations, 16 warmups, and 32 setup diagnostics are retained.

## Results

Positive changes mean slower. The controls vary; no control correction or significance claim is made.

| Comparison with raw API | Forward paired wall change | Reverse paired wall change |
| --- | ---: | ---: |
| Same-code raw context | +3.84% | +0.12% |
| Advanced CDict | +5.66% | +1.22% |
| Copied raw context | +0.59% | approximately 0.00% |

| Setup work across all 28 blocks | Forward median | Reverse median |
| --- | ---: | ---: |
| Raw dictionary API | 0.464 ms | 0.363 ms |
| Advanced CDict | 0.123 ms | 0.107 ms |
| Copied raw context | 0.095 ms | 0.077 ms |

Raw full-compression medians in the uninstrumented cohorts are approximately 139 and 163 ms. The largest median setup saving here is approximately 0.37 ms. This does not justify rebuilding or integrating the WASM API.

One parameter class covers all blocks: window log 19, chain log 12, hash log 13, search log 1, minimum match 6, target length 1, fast strategy. Each active context reports 549,912 bytes. CDict adds 47,680 retained bytes per realm; the template approach adds 549,912 bytes per realm. These native context-size values exclude JS objects, output buffers, allocator overhead, and browser peak memory.

The copied context retains all 28 original frames exactly. Advanced CDict changes all 28 frames, and all decoded bytes still match; total compressed payload size falls from 12,256,060 to 12,252,645 bytes, only 3,415 bytes (0.028%). That is not a meaningful storage payoff for this added mechanism.

## Evidence and reproduction

`native-forward.json` and `native-reverse.json` retain every observation, configuration, control, setup diagnostic, identity, and complete-output hash. Their `.jsonl` journals retain the measured observations as written during execution. `screen.c` is the complete native screen; `run-screen.py` verifies the corpus and drives it through ctypes. `source-provenance.json` hashes all 658 exact upstream source files; `compile-v2-receipt.json` pins compiler command and resulting library.

The initial compile failed because the amalgamated upstream source requires `_GNU_SOURCE` for `qsort_r` on this libc. `compile.log` and `compile-receipt.json` retain that failure. Adding the feature-test macro produced the successful second build before any measurement; no failed performance observation was retried or discarded.

The recorded commands were:

```sh
cc -O3 -DNDEBUG -fPIC -shared screen.c -o libscreen.so
python3 run-screen.py --prepare
python3 run-screen.py --output native-forward.json
python3 run-screen.py --output native-reverse.json --reverse
```

The screen intentionally remains outside production. Reproduction needs the exact pinned upstream tree, the existing component corpus, and the locked dictionary; the recorded source paths are declared at the top of `run-screen.py`. Keep the original measured script unchanged when interpreting these receipts. A new host, compiler, input plan, script, or configuration is a new experiment.
