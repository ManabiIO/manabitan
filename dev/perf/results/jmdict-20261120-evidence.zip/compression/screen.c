#define _GNU_SOURCE
#define _POSIX_C_SOURCE 200809L
#define ZSTD_DISABLE_DEPRECATE_WARNINGS
#include <time.h>
#include <stdint.h>
#include <stdio.h>
#include "zstd/build/single_file_libs/zstd.c"

/* Exploratory native component screen. No Manabitan runtime is modified. */
typedef struct {
    const unsigned char* source;
    size_t length;
    const unsigned char* expected;
    size_t expectedLength;
    unsigned char* output;
    size_t capacity;
    size_t outputLength;
    size_t config;
} ScreenBlock;

typedef struct {
    ZSTD_parameters params;
    ZSTD_CDict* cdict;
    ZSTD_CCtx* template;
    size_t firstSourceLength;
    double cdictWall;
    double templateWall;
} ScreenConfig;

typedef struct {
    const void* dictionary;
    size_t dictionaryLength;
    ScreenBlock* blocks;
    size_t blockCount;
    ScreenConfig* configs;
    size_t configCount;
    ZSTD_CCtx* contexts[4];
    ZSTD_DCtx* decoder;
    void* decoded;
    size_t decodedCapacity;
    char error[256];
} Screen;

typedef struct {
    double wallMs;
    double cpuMs;
    double setupWallMs;
    double setupCpuMs;
    size_t outputBytes;
    size_t contextBytes;
    size_t framesEqual;
    size_t decodedBytes;
} Observation;

static double now_ms(clockid_t id) {
    struct timespec t;
    if (clock_gettime(id, &t) != 0) abort();
    return t.tv_sec * 1000.0 + t.tv_nsec / 1000000.0;
}

static int params_equal(ZSTD_compressionParameters a, ZSTD_compressionParameters b) {
    return a.windowLog == b.windowLog && a.chainLog == b.chainLog &&
        a.hashLog == b.hashLog && a.searchLog == b.searchLog &&
        a.minMatch == b.minMatch && a.targetLength == b.targetLength &&
        a.strategy == b.strategy;
}

static size_t raw_begin(ZSTD_CCtx* context, const void* dictionary,
                        size_t dictionaryLength, size_t sourceLength) {
    ZSTD_parameters const params = ZSTD_getParams_internal(-1, sourceLength,
        dictionaryLength, ZSTD_cpm_noAttachDict);
    ZSTD_CCtxParams_init_internal(&context->simpleApiParams, &params, -1);
    return ZSTD_compressBegin_internal(context, dictionary, dictionaryLength,
        ZSTD_dct_auto, ZSTD_dtlm_fast, NULL, &context->simpleApiParams,
        sourceLength, ZSTDb_not_buffered);
}

static int checked(Screen* screen, size_t result, const char* operation) {
    if (!ZSTD_isError(result)) return 1;
    snprintf(screen->error, sizeof(screen->error), "%s: %s", operation, ZSTD_getErrorName(result));
    return 0;
}

Screen* screen_create(const void* dictionary, size_t dictionaryLength,
        const unsigned char* raw, const size_t* offsets, const size_t* lengths,
        const unsigned char* frames, const size_t* frameOffsets,
        const size_t* frameLengths, size_t blockCount) {
    Screen* s = calloc(1, sizeof(*s));
    if (!s) return NULL;
    s->dictionary = dictionary;
    s->dictionaryLength = dictionaryLength;
    s->blockCount = blockCount;
    s->blocks = calloc(blockCount, sizeof(*s->blocks));
    s->configs = calloc(blockCount, sizeof(*s->configs));
    s->decoder = ZSTD_createDCtx();
    if (!s->blocks || !s->configs || !s->decoder) abort();
    for (size_t i = 0; i < 4; ++i) {
        s->contexts[i] = ZSTD_createCCtx();
        if (!s->contexts[i]) abort();
    }
    for (size_t i = 0; i < blockCount; ++i) {
        ScreenBlock* b = &s->blocks[i];
        b->source = raw + offsets[i];
        b->length = lengths[i];
        b->expected = frames + frameOffsets[i];
        b->expectedLength = frameLengths[i];
        b->capacity = ZSTD_compressBound(b->length);
        b->output = malloc(b->capacity);
        if (!b->output) abort();
        if (b->length > s->decodedCapacity) s->decodedCapacity = b->length;
        ZSTD_parameters p = ZSTD_getParams_internal(-1, b->length,
            dictionaryLength, ZSTD_cpm_noAttachDict);
        size_t index = 0;
        for (; index < s->configCount; ++index) {
            if (params_equal(p.cParams, s->configs[index].params.cParams)) break;
        }
        b->config = index;
        if (index == s->configCount) {
            ScreenConfig* c = &s->configs[index];
            c->params = p;
            c->firstSourceLength = b->length;
            double start = now_ms(CLOCK_MONOTONIC);
            c->cdict = ZSTD_createCDict_advanced(dictionary, dictionaryLength,
                ZSTD_dlm_byRef, ZSTD_dct_auto, p.cParams, ZSTD_defaultCMem);
            c->cdictWall = now_ms(CLOCK_MONOTONIC) - start;
            start = now_ms(CLOCK_MONOTONIC);
            c->template = ZSTD_createCCtx();
            if (!c->cdict || !c->template) abort();
            if (!checked(s, raw_begin(c->template, dictionary, dictionaryLength,
                                     b->length), "template begin")) return s;
            c->templateWall = now_ms(CLOCK_MONOTONIC) - start;
            ++s->configCount;
        }
    }
    s->decoded = malloc(s->decodedCapacity);
    if (!s->decoded) abort();
    return s;
}

const char* screen_error(Screen* s) { return s->error; }

static size_t begin_arm(Screen* s, int arm, ScreenBlock* b) {
    ZSTD_CCtx* ctx = s->contexts[arm];
    if (arm < 2) return raw_begin(ctx, s->dictionary, s->dictionaryLength, b->length);
    if (arm == 2) return ZSTD_compressBegin_usingCDict_internal(ctx,
        s->configs[b->config].cdict, (ZSTD_frameParameters){1, 0, 0}, b->length);
    return ZSTD_copyCCtx(ctx, s->configs[b->config].template, b->length);
}

int screen_run(Screen* s, int arm, int repetitions, int profileSetup, Observation* result) {
    if (arm < 0 || arm > 3 || repetitions < 1 || s->error[0]) return 0;
    memset(result, 0, sizeof(*result));
    const double cpuStart = now_ms(CLOCK_PROCESS_CPUTIME_ID);
    const double wallStart = now_ms(CLOCK_MONOTONIC);
    for (int repeat = 0; repeat < repetitions; ++repeat) {
        for (size_t i = 0; i < s->blockCount; ++i) {
            ScreenBlock* b = &s->blocks[i];
            size_t size;
            if (profileSetup) {
                const double setupCpuStart = now_ms(CLOCK_PROCESS_CPUTIME_ID);
                const double setupWallStart = now_ms(CLOCK_MONOTONIC);
                size = begin_arm(s, arm, b);
                result->setupWallMs += now_ms(CLOCK_MONOTONIC) - setupWallStart;
                result->setupCpuMs += now_ms(CLOCK_PROCESS_CPUTIME_ID) - setupCpuStart;
                if (!checked(s, size, "begin")) return 0;
                size = ZSTD_compressEnd_public(s->contexts[arm], b->output,
                    b->capacity, b->source, b->length);
            } else if (arm < 2) {
                size = ZSTD_compress_usingDict(s->contexts[arm], b->output,
                    b->capacity, b->source, b->length, s->dictionary,
                    s->dictionaryLength, -1);
            } else if (arm == 2) {
                size = ZSTD_compress_usingCDict(s->contexts[arm], b->output,
                    b->capacity, b->source, b->length, s->configs[b->config].cdict);
            } else {
                size = begin_arm(s, arm, b);
                if (!checked(s, size, "copy begin")) return 0;
                size = ZSTD_compressEnd_public(s->contexts[arm], b->output,
                    b->capacity, b->source, b->length);
            }
            if (!checked(s, size, "compress")) return 0;
            b->outputLength = size;
        }
    }
    result->wallMs = now_ms(CLOCK_MONOTONIC) - wallStart;
    result->cpuMs = now_ms(CLOCK_PROCESS_CPUTIME_ID) - cpuStart;
    result->contextBytes = ZSTD_sizeof_CCtx(s->contexts[arm]);
    for (size_t i = 0; i < s->blockCount; ++i) result->outputBytes += s->blocks[i].outputLength;
    return 1;
}

int screen_validate(Screen* s, Observation* result) {
    result->framesEqual = 0;
    result->decodedBytes = 0;
    for (size_t i = 0; i < s->blockCount; ++i) {
        ScreenBlock* b = &s->blocks[i];
        if (b->outputLength == b->expectedLength &&
            memcmp(b->output, b->expected, b->outputLength) == 0) ++result->framesEqual;
        size_t n = ZSTD_decompress_usingDict(s->decoder, s->decoded,
            s->decodedCapacity, b->output, b->outputLength, s->dictionary, s->dictionaryLength);
        if (!checked(s, n, "decompress")) return 0;
        if (n != b->length || memcmp(s->decoded, b->source, n) != 0) {
            snprintf(s->error, sizeof(s->error), "decompressed mismatch block %zu", i);
            return 0;
        }
        result->decodedBytes += n;
    }
    return 1;
}

size_t screen_config_count(Screen* s) { return s->configCount; }

void screen_config_info(Screen* s, size_t i, size_t* params, double* times) {
    ScreenConfig* c = &s->configs[i];
    ZSTD_compressionParameters p = c->params.cParams;
    params[0] = p.windowLog; params[1] = p.chainLog; params[2] = p.hashLog;
    params[3] = p.searchLog; params[4] = p.minMatch; params[5] = p.targetLength;
    params[6] = p.strategy; params[7] = ZSTD_sizeof_CDict(c->cdict);
    params[8] = ZSTD_sizeof_CCtx(c->template); params[9] = c->firstSourceLength;
    times[0] = c->cdictWall; times[1] = c->templateWall;
}

const void* screen_output(Screen* s, size_t i, size_t* length) {
    *length = s->blocks[i].outputLength;
    return s->blocks[i].output;
}

void screen_destroy(Screen* s) {
    if (!s) return;
    for (size_t i = 0; i < s->blockCount; ++i) free(s->blocks[i].output);
    for (size_t i = 0; i < s->configCount; ++i) {
        ZSTD_freeCDict(s->configs[i].cdict);
        ZSTD_freeCCtx(s->configs[i].template);
    }
    for (size_t i = 0; i < 4; ++i) ZSTD_freeCCtx(s->contexts[i]);
    ZSTD_freeDCtx(s->decoder);
    free(s->decoded); free(s->blocks); free(s->configs); free(s);
}
