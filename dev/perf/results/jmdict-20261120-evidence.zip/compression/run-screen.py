#!/usr/bin/env python3
"""Pinned native Zstd mechanism screen; deliberately not a browser benchmark."""
import argparse
import ctypes as C
import hashlib
import json
import mmap
import os
from pathlib import Path
import platform
import resource
import statistics
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CORPUS = Path('/workspace/scratch/f34c9c9fae89/manabitan/builds/perf/checksum-corpus-regenerated/real-fixture')
BASELINE = Path('/workspace/scratch/ee3ecb87c795/manabitan-baseline')
DICT = BASELINE / 'dev/data/zstd-dicts/jmdict.zdict'
SIZE = C.c_size_t
PTR = C.c_void_p


def sha(value):
    return hashlib.sha256(value).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


class Observation(C.Structure):
    _fields_ = [('wallMs', C.c_double), ('cpuMs', C.c_double),
                ('setupWallMs', C.c_double), ('setupCpuMs', C.c_double),
                ('outputBytes', SIZE), ('contextBytes', SIZE),
                ('framesEqual', SIZE), ('decodedBytes', SIZE)]


def load_library():
    lib = C.CDLL(str(ROOT / 'libscreen.so'))
    lib.ZSTD_createDCtx.restype = PTR
    lib.ZSTD_freeDCtx.argtypes = [PTR]
    lib.ZSTD_decompress_usingDict.argtypes = [PTR, PTR, SIZE, PTR, SIZE, PTR, SIZE]
    lib.ZSTD_decompress_usingDict.restype = SIZE
    lib.ZSTD_isError.argtypes = [SIZE]
    lib.ZSTD_isError.restype = C.c_uint
    lib.screen_create.argtypes = [PTR, SIZE, PTR, PTR, PTR, PTR, PTR, PTR, SIZE]
    lib.screen_create.restype = PTR
    lib.screen_error.argtypes = [PTR]
    lib.screen_error.restype = C.c_char_p
    lib.screen_run.argtypes = [PTR, C.c_int, C.c_int, C.c_int, C.POINTER(Observation)]
    lib.screen_run.restype = C.c_int
    lib.screen_validate.argtypes = [PTR, C.POINTER(Observation)]
    lib.screen_validate.restype = C.c_int
    lib.screen_config_count.argtypes = [PTR]
    lib.screen_config_count.restype = SIZE
    lib.screen_config_info.argtypes = [PTR, SIZE, PTR, PTR]
    lib.screen_output.argtypes = [PTR, SIZE, C.POINTER(SIZE)]
    lib.screen_output.restype = PTR
    lib.screen_destroy.argtypes = [PTR]
    return lib


def prepare():
    manifest = json.loads((CORPUS / 'manifest.json').read_text())
    store = (CORPUS / 'store.bin').read_bytes()
    dictionary = DICT.read_bytes()
    assert len(store) == manifest['storeBytes']
    assert sha(store) == manifest['storeSha256']
    assert dictionary == (Path(manifest['sourceRoot']) / 'dev/data/zstd-dicts/jmdict.zdict').read_bytes()
    lib = load_library()
    dictionary_buffer = C.create_string_buffer(dictionary)
    ctx = lib.ZSTD_createDCtx()
    assert ctx
    rows = []
    raw_offset = 0
    frame_offset = 0
    try:
        with (ROOT / 'raw.bin').open('xb') as raw_stream, (ROOT / 'frames.bin').open('xb') as frame_stream:
            for i, block in enumerate(manifest['blocks']):
                envelope = store[block['offset']:block['offset'] + block['length']]
                assert sha(envelope) == block['sha256'], i
                frame = envelope[12:]
                assert sha(frame) == block['payloadSha256'], i
                target = C.create_string_buffer(block['uncompressedLength'])
                frame_buffer = C.create_string_buffer(frame)
                size = lib.ZSTD_decompress_usingDict(ctx, target, len(target),
                    frame_buffer, len(frame), dictionary_buffer, len(dictionary))
                assert not lib.ZSTD_isError(size), (i, size)
                assert size == block['uncompressedLength'], i
                decoded = target.raw
                assert sha(decoded) == block['uncompressedSha256'], i
                raw_stream.write(decoded)
                frame_stream.write(frame)
                rows.append({'index': i, 'rawOffset': raw_offset, 'rawLength': len(decoded),
                             'rawSha256': sha(decoded), 'frameOffset': frame_offset,
                             'frameLength': len(frame), 'frameSha256': sha(frame)})
                raw_offset += len(decoded)
                frame_offset += len(frame)
    finally:
        lib.ZSTD_freeDCtx(ctx)
    receipt = {'schema': 1, 'scope': manifest['scope'], 'sourceCommit': manifest['sourceCommit'],
               'fixtureSha256': manifest['archiveSha256'], 'sourceManifestSha256': file_sha(CORPUS / 'manifest.json'),
               'storeSha256': sha(store), 'dictionarySha256': sha(dictionary),
               'rawSha256': file_sha(ROOT / 'raw.bin'), 'rawBytes': raw_offset,
               'framesSha256': file_sha(ROOT / 'frames.bin'), 'frameBytes': frame_offset,
               'blocks': rows, 'nativeBuild': json.loads((ROOT / 'compile-v2-receipt.json').read_text()),
               'currentBaseline': subprocess.check_output(['git', '-C', str(BASELINE), 'rev-parse', 'HEAD'], text=True).strip(),
               'verification': 'Every original envelope/frame hash and full decoded-byte SHA256 matches source manifest'}
    (ROOT / 'corpus.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ('rawBytes', 'frameBytes', 'rawSha256', 'framesSha256')}))


def percentile_median(rows, key, arm, denominator=0):
    groups = {}
    for row in rows:
        groups.setdefault(row['block'], {})[row['arm']] = row
    paired = [100.0 * (g[arm][key] / g[denominator][key] - 1.0) for g in groups.values()]
    return {'medianPairedChangePercent': statistics.median(paired),
            'fasterBlocks': sum(p < 0 for p in paired), 'blocks': len(paired),
            'medianArmMs': statistics.median(g[arm][key] for g in groups.values()),
            'medianBaselineMs': statistics.median(g[denominator][key] for g in groups.values()),
            'equalWorkChangePercent': 100.0 * (sum(g[arm][key] for g in groups.values()) /
                                      sum(g[denominator][key] for g in groups.values()) - 1.0)}


def run(args):
    output = Path(args.output).resolve()
    assert not output.exists(), output
    corpus = json.loads((ROOT / 'corpus.json').read_text())
    assert file_sha(ROOT / 'raw.bin') == corpus['rawSha256']
    assert file_sha(ROOT / 'frames.bin') == corpus['framesSha256']
    dictionary = DICT.read_bytes()
    assert sha(dictionary) == corpus['dictionarySha256']
    source_paths = ['screen.c', 'run-screen.py', 'libscreen.so', 'corpus.json',
                    'source-provenance.json', 'compile-v2-receipt.json',
                    'zstd/build/single_file_libs/zstd.c']
    source_hashes = {name: file_sha(ROOT / name) for name in source_paths}
    assert source_hashes['libscreen.so'] == corpus['nativeBuild']['sha256']
    lib = load_library()
    handles = []
    mappings = []
    retained = []
    for name in ['raw.bin', 'frames.bin']:
        handle = (ROOT / name).open('rb')
        mapping = mmap.mmap(handle.fileno(), 0, access=mmap.ACCESS_COPY)
        buffer = (C.c_char * len(mapping)).from_buffer(mapping)
        handles.append(handle)
        mappings.append(mapping)
        retained.append(buffer)
    dictionary_buffer = C.create_string_buffer(dictionary)
    blocks = corpus['blocks']
    n = len(blocks)
    offsets = (SIZE * n)(*[b['rawOffset'] for b in blocks])
    lengths = (SIZE * n)(*[b['rawLength'] for b in blocks])
    frame_offsets = (SIZE * n)(*[b['frameOffset'] for b in blocks])
    frame_lengths = (SIZE * n)(*[b['frameLength'] for b in blocks])
    screen = lib.screen_create(dictionary_buffer, len(dictionary), retained[0], offsets,
        lengths, retained[1], frame_offsets, frame_lengths, n)
    assert screen and not lib.screen_error(screen), lib.screen_error(screen)
    configs = []
    for index in range(lib.screen_config_count(screen)):
        params = (SIZE * 10)()
        times = (C.c_double * 2)()
        lib.screen_config_info(screen, index, params, times)
        configs.append(dict(zip(['windowLog', 'chainLog', 'hashLog', 'searchLog', 'minMatch',
            'targetLength', 'strategy', 'preparedDictionaryBytes', 'templateContextBytes', 'firstSourceLength'], params)))
        configs[-1].update(cdictCreationWallMs=times[0], templateCreationWallMs=times[1])
    orders = [[0, 1, 3, 2], [1, 2, 0, 3], [2, 3, 1, 0], [3, 0, 2, 1]]
    if args.reverse:
        orders = [list(reversed(order)) for order in reversed(orders)]
    report = {'schema': 1, 'status': 'running', 'startedUtc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
              'scope': 'Native exact-pinned Zstd mechanism/component screen; no WASM, JavaScript copies, workers, storage, or complete import timing',
              'arms': {'0': 'raw production API', '1': 'raw production API independent context control',
                       '2': 'advanced CDict using production-selected parameters',
                       '3': 'copyCCtx from raw initialized template'},
              'sourceHashes': source_hashes, 'host': {'platform': platform.platform(),
              'machine': platform.machine(), 'cpuCount': os.cpu_count()}, 'corpus': corpus,
              'configurations': configs, 'protocol': {'blocks': args.blocks,
              'repetitionsPerObservation': args.repetitions, 'warmupsPerArm': 2,
              'orders': orders, 'reverse': args.reverse}, 'warmups': [], 'observations': [], 'setupDiagnostics': []}
    with output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    def observation(arm, block, repetitions, profile=False):
        obs = Observation()
        assert lib.screen_run(screen, arm, repetitions, int(profile), C.byref(obs)), lib.screen_error(screen)
        assert lib.screen_validate(screen, C.byref(obs)), lib.screen_error(screen)
        assert obs.decodedBytes == corpus['rawBytes']
        if arm < 2 or arm == 3:
            assert obs.framesEqual == n, (arm, obs.framesEqual, n)
        digest = hashlib.sha256()
        frame_digests = []
        for i in range(n):
            size = SIZE()
            pointer = lib.screen_output(screen, i, C.byref(size))
            frame = C.string_at(pointer, size.value)
            digest.update(frame)
            frame_digests.append(sha(frame))
        result = {name: getattr(obs, name) for name, _ in Observation._fields_}
        result.update(arm=arm, block=block, repetitions=repetitions, profileSetup=profile,
                      outputSha256=digest.hexdigest(), frameSha256=frame_digests)
        return result
    try:
        for warmup in range(2):
            for arm in orders[warmup]:
                report['warmups'].append(observation(arm, warmup, args.repetitions))
        with output.with_suffix('.jsonl').open('x') as journal:
            for block in range(args.blocks):
                for arm in orders[block % len(orders)]:
                    row = observation(arm, block, args.repetitions)
                    report['observations'].append(row)
                    journal.write(json.dumps(row) + '\n')
                    journal.flush()
            for block in range(4):
                for arm in orders[block]:
                    report['setupDiagnostics'].append(observation(arm, block, 1, True))
        for arm in range(4):
            samples = [r for r in report['warmups'] + report['observations'] + report['setupDiagnostics'] if r['arm'] == arm]
            assert len({r['outputSha256'] for r in samples}) == 1, arm
        assert source_hashes == {name: file_sha(ROOT / name) for name in source_paths}
        report['summary'] = {str(arm): {key: percentile_median(report['observations'], key, arm)
                            for key in ('wallMs', 'cpuMs')} for arm in (1, 2, 3)}
        report['setupSummary'] = {str(arm): {key: statistics.median(row[key] for row in report['setupDiagnostics'] if row['arm'] == arm)
                               for key in ('setupWallMs', 'setupCpuMs', 'wallMs', 'cpuMs', 'contextBytes', 'outputBytes', 'framesEqual')}
                               for arm in range(4)}
        report['status'] = 'complete'
    except BaseException as error:
        report['status'] = 'failed'
        report['error'] = repr(error)
        raise
    finally:
        report['maxResidentSetKiB'] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        report['endedUtc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
        output.write_text(json.dumps(report, indent=2) + '\n')
        lib.screen_destroy(screen)
    print(json.dumps({'status': report['status'], 'summary': report.get('summary'),
                      'setupSummary': report.get('setupSummary'), 'configurations': configs}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--output')
    parser.add_argument('--blocks', type=int, default=24)
    parser.add_argument('--repetitions', type=int, default=1)
    parser.add_argument('--reverse', action='store_true')
    args = parser.parse_args()
    if args.prepare:
        prepare()
    else:
        assert args.output
        assert args.blocks > 0 and args.blocks % 4 == 0
        assert args.repetitions > 0
        run(args)
