#!/usr/bin/env python3
"""Build an independently checked packaging manifest without running benchmarks."""
from pathlib import Path
import hashlib
import json
import math
import statistics

ROOT = Path('/workspace/scratch/ee3ecb87c795')
CACHE = ROOT / 'manabitan-cache/builds/perf/20261120-cache-copy'
COMP = ROOT / 'compression-screen'
READER = ROOT / 'manabitan-reader/builds/perf/reader'
HISTORY = ROOT / 'manabitan-early-lease/builds/perf/historical-source-handoff'
COALESCING = ROOT / 'manabitan-coalesced-spans/builds/perf/coalesced-spans-20261120'
CORPUS = Path('/workspace/scratch/f34c9c9fae89/manabitan/builds/perf/checksum-corpus-regenerated')

def read(path):
    return json.loads(Path(path).read_text())

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

checked = []
files = {}

def verify(path, expected, size=None, origin=None):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), str(path)
    actual = digest(path)
    assert actual == expected, (str(path), actual, expected)
    if size is not None:
        assert path.stat().st_size == size, str(path)
    checked.append({'source': str(path), 'sha256': actual, 'receipt': origin})

def add(path, archive):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(), str(path)
    assert archive not in files, archive
    files[archive] = {'source': str(path), 'archive': archive,
                      'bytes': path.stat().st_size, 'sha256': digest(path)}

def near(a, b):
    assert math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-9), (a, b)

publication = read(CACHE / 'publication-evidence-manifest.json')
for x in publication['artifacts']:
    verify(x['path'], x['sha256'], x['bytes'], 'publication-evidence-manifest.json')
for key in ['productionSource', 'testSource']:
    x = publication[key]
    verify(x['path'], x['sha256'], origin='publication-evidence-manifest.json')
for path in sorted(CACHE.iterdir()):
    if path.is_file():
        add(path, 'publication/' + path.name)
for key, archive in [('productionSource', 'dictionary-database.js'),
                     ('testSource', 'dictionary-content-publication-range.test.js')]:
    add(publication[key]['path'], 'publication/measured-source/' + archive)

pub_metrics = {}
for orientation in ['forward', 'reverse']:
    d = read(CACHE / f'publication-{orientation}.json')
    assert len(d['observations']) == 48
    assert len(d['specimens']) == 12
    assert sum(x['count'] for x in d['specimens']) == 360859
    assert sum(x['rows'] for x in d['specimens']) == 526942
    verify(CACHE / 'publication-preload.mjs', d['scriptSha256'], origin=f'publication-{orientation}.json')
    by = {(x['block'], x['arm']): x for x in d['observations']}
    for comparison, result in d['comparisons'].items():
        b, a = comparison.split('/')
        values = [(by[i, b]['wallMs'] / by[i, a]['wallMs'] - 1) * 100 for i in range(12)]
        near(statistics.median(values), result['medianWallChangePercent'])
        assert sum(x < 0 for x in values) == result['fasterBlocks']
    for arm, value in d['armMedians'].items():
        near(statistics.median(x['wallMs'] for x in d['observations'] if x['arm'] == arm), value)
    pub_metrics[orientation] = {'armMediansMs': d['armMedians'],
        'comparisons': {k: {a: b for a, b in v.items() if a != 'changes'} for k, v in d['comparisons'].items()}}

corpus = read(COMP / 'corpus.json')
verify(COMP / 'raw.bin', corpus['rawSha256'], corpus['rawBytes'], 'corpus.json')
verify(COMP / 'frames.bin', corpus['framesSha256'], corpus['frameBytes'], 'corpus.json')
verify(CORPUS / 'real-fixture/manifest.json', corpus['sourceManifestSha256'], origin='corpus.json')
verify(CORPUS / 'real-fixture/store.bin', corpus['storeSha256'], origin='corpus.json')

native_metrics = {}
reader_metrics = {}
for orientation in ['forward', 'reverse']:
    n = read(COMP / f'native-{orientation}.json')
    for name, expected in n['sourceHashes'].items():
        verify(COMP / name, expected, origin=f'native-{orientation}.json')
    assert len(n['observations']) == 96 and len(n['warmups']) == 8
    by = {(x['block'], x['arm']): x for x in n['observations']}
    for arm, result in n['summary'].items():
        for metric in ['wallMs', 'cpuMs']:
            values = [(by[i, int(arm)][metric] / by[i, 0][metric] - 1) * 100 for i in range(24)]
            near(statistics.median(values), result[metric]['medianPairedChangePercent'])
    native_metrics[orientation] = {'summary': n['summary'], 'setupSummary': n['setupSummary'], 'configurations': n['configurations']}

    d = read(COMP / f'reader-{orientation}.json')
    expected_paths = {
        'wrapperSha256': Path(d['sourceRoot']) / 'ext/lib/zstd-wasm.js',
        'diagnosticCodecSha256': COMP / 'reader-codec.mjs',
        'scriptSha256': COMP / 'reader-screen.mjs',
        'dictionarySha256': Path(d['sourceRoot']) / 'dev/data/zstd-dicts/jmdict.zdict',
        'wasmSha256': Path(d['sourceRoot']) / 'ext/lib/zstd.wasm',
        'corpusManifestSha256': CORPUS / 'real-fixture/manifest.json',
        'storeSha256': CORPUS / 'real-fixture/store.bin',
        'rawSha256': COMP / 'raw.bin'
    }
    for key, path in expected_paths.items():
        verify(path, d[key], origin=f'reader-{orientation}.json')
    assert len(d['observations']) == 96 and len(d['warmups']) == 8
    assert len(d['corruptionTests']) == 30
    assert all(x['decodedBytes'] == 100671677 for x in d['observations'] + d['warmups'])
    by = {(x['block'], x['arm']): x for x in d['observations']}
    for arm, result in d['summary'].items():
        for metric in ['wallMs', 'cpuMs']:
            values = [(by[i, int(arm)][metric] / by[i, 0][metric] - 1) * 100 for i in range(24)]
            near(statistics.median(values), result[metric]['pairedChangePercent'])
            assert sum(x < 0 for x in values) == result[metric]['fasterBlocks']
    reader_metrics[orientation] = d['summary']

upstream = read(COMP / 'source-provenance.json')
for name, expected in upstream['files'].items():
    verify(COMP / 'zstd' / name, expected, origin='source-provenance.json')

for path in sorted(COMP.iterdir()):
    if path.is_file() and path.name not in ['raw.bin', 'frames.bin', 'libscreen.so']:
        add(path, 'compression/' + path.name)
for name in ['wasm-phases-v1', 'wasm-phases-v2', 'wasm-phases-v3']:
    for path in sorted((COMP / name).iterdir()):
        if path.is_file():
            add(path, 'compression/' + name + '/' + path.name)
for path in sorted(READER.iterdir()):
    if path.is_file():
        add(path, 'reader-validation/' + path.name)
for name in ['regeneration-receipt.json', 'make-real-fixture.relocated.mjs',
             'generator.stdout.log', 'generator.stderr.log', 'real-fixture/manifest.json']:
    add(CORPUS / name, 'compression/corpus-regeneration/' + name)
regeneration = read(CORPUS / 'regeneration-receipt.json')
verify(CORPUS / 'make-real-fixture.relocated.mjs', regeneration['relocatedGeneratorSha256'], origin='regeneration-receipt.json')

v3 = read(COMP / 'wasm-phases-component-v3.json')
verify(COMP / 'wasm-phase-preload-v3.mjs', v3['instrumentation']['preloadSha256'], origin='wasm-phases-component-v3.json')
phase_records = []
for path in (COMP / 'wasm-phases-v3').glob('*.jsonl'):
    records = [json.loads(x) for x in path.read_text().splitlines()]
    assert records[0]['preloadSha256'] == v3['instrumentation']['preloadSha256']
    phase_records.extend(x for x in records if x['type'] == 'compression')
assert len(phase_records) == 102
phase = read(COMP / 'wasm-phase-summary.json')
for key in ['prepareMs', 'nativeCompressionMs', 'envelopeMs', 'finishRemainderMs', 'finishMs', 'contentBytes', 'outputBytes']:
    near(sum(x[key] for x in phase_records), phase['workSum'][key])
for key in ['spans', 'runCount', 'alignedSharedRunBytes', 'privateShiftBytes']:
    assert sum(x['spans'][key] for x in phase_records) == phase['copies'][key]

subset = read(HISTORY / 'evidence-subset-manifest.json')
assert len(subset['files']) == 117
assert sum(x['bytes'] for x in subset['files']) == 8449102
for x in subset['files']:
    verify(HISTORY / x['path'], x['sha256'], x['bytes'], 'evidence-subset-manifest.json')
    add(HISTORY / x['path'], 'historical-source-handoff/' + x['path'])
add(HISTORY / 'evidence-subset-manifest.json', 'historical-source-handoff/evidence-subset-manifest.json')
receipt = read(HISTORY / 'evidence-receipt.json')
for x in receipt['files'].values():
    verify(x['path'], x['sha256'], x['bytes'], 'evidence-receipt.json')

historical_metrics = {}
for dictionary in ['jmdict', 'jitendex']:
    d = read(HISTORY / f'{dictionary}-computed-summary.json')
    changes = []
    a_values = []
    b_values = []
    for pair in d['pairs']:
        times = {}
        for arm in ['A', 'B']:
            report = read(HISTORY / f'historical-source-handoff-{dictionary}/{arm}{pair["index"]}/run-1.json')
            assert report['status'] == 'success'
            assert report['skippedVerification'] is False
            validation = report['benchmark']['validation']
            assert validation['probeCount'] == 12
            assert validation['restart']['termRows'] == validation['termRows']
            timed = [x['data']['browserTiming'] for x in report['phases']
                     if x.get('data') and x['data'].get('kind') == 'dictionary-import']
            assert len(timed) == 1
            times[arm] = timed[0]['completedAtMs'] - timed[0]['startedAtMs']
            near(times[arm], pair[arm])
        changes.append((times['B'] / times['A'] - 1) * 100)
        a_values.append(times['A'])
        b_values.append(times['B'])
    near(statistics.median(changes), d['medianPairChangePct'])
    near((sum(b_values) / sum(a_values) - 1) * 100, d['equalWorkChangePct'])
    assert sum(x < 0 for x in changes) == d['wins']
    historical_metrics[dictionary] = {k: d[k] for k in ['medianPairChangePct', 'wins', 'armMedianA', 'armMedianB', 'equalWorkChangePct', 'controls', 'controlMedianAbsPct']}

coalescing_manifest = read(COALESCING / 'evidence-manifest.json')
assert len(coalescing_manifest['files']) == 24
assert sum(x['bytes'] for x in coalescing_manifest['files']) == coalescing_manifest['totalBytes']
for x in coalescing_manifest['files']:
    verify(COALESCING / x['path'], x['sha256'], x['bytes'], 'coalescing/evidence-manifest.json')
    add(COALESCING / x['path'], 'coalescing/' + x['path'])
add(COALESCING / 'evidence-manifest.json', 'coalescing/evidence-manifest.json')
coalescing = read(COALESCING / 'worker-diagnostic-summary.json')
coalescing_report = read(COALESCING / 'worker-diagnostic.json')
verify(coalescing['baselineReport']['path'], coalescing['baselineReport']['sha256'], origin='worker-diagnostic-summary.json')
verify(COALESCING / 'wasm-phase-preload.mjs', coalescing_report['instrumentation']['preloadSha256'], origin='worker-diagnostic.json')
assert coalescing['rows'] == 526942 and coalescing['groupCount'] == 12
assert coalescing['verification']['sha256'] == '8926122e434123d9823d867845ed8480734e0ada8381204e1857f88b216d8974'
assert coalescing['storedFilesCanonicalSha256'] == '2f559a8b0d90ed063d01b9650aee46cbbe52f469bc2ffd6ebbd74dd265e3e34c'
coalesced_records = []
for path in (COALESCING / 'wasm-phases').glob('*.jsonl'):
    records = [json.loads(x) for x in path.read_text().splitlines()]
    assert records[0]['preloadSha256'] == coalescing_report['instrumentation']['preloadSha256']
    coalesced_records.extend(x for x in records if x['type'] == 'compression')
assert len(coalesced_records) == 102
assert sum(x['spans']['spans'] for x in coalesced_records) == coalescing['compressionSpanCount'] == 3950
assert sum(x['spans']['runCount'] for x in coalesced_records) == coalescing['contiguousRunCount']
assert coalescing['originalSpanCount'] == phase['copies']['spans'] == 360859
assert coalescing['originalMetadataBytes'] == coalescing['originalSpanCount'] * 8
assert coalescing['coalescedMetadataBytes'] == coalescing['compressionSpanCount'] * 8
near((1 - coalescing['coalescedMetadataBytes'] / coalescing['originalMetadataBytes']) * 100, coalescing['metadataReductionPercent'])
q = read(COALESCING / 'qualification-receipt.json')
for name, info in q['files'].items():
    source = ROOT / 'manabitan-coalesced-spans' / name
    verify(source, info['sha256'], info['bytes'], 'coalescing/qualification-receipt.json')
    add(source, 'coalescing/measured-source/' + name)
snapshot_root = ROOT / 'evidence-audit/snapshots'
snapshot_root.mkdir(exist_ok=True)
worker_source = ROOT / 'manabitan/dev/perf/node-import-workers.js'
verify(worker_source, coalescing_report['workerTransportSha256'], origin='coalescing/worker-diagnostic.json')
worker_snapshot = snapshot_root / (coalescing_report['workerTransportSha256'] + '-node-import-workers.js')
worker_snapshot.write_bytes(worker_source.read_bytes())
add(worker_snapshot, 'harness-snapshots/' + worker_snapshot.name)
coalescing_harness = snapshot_root / (coalescing_report['harnessSha256'] + '-jmdict-component-benchmark.js')
verify(coalescing_harness, coalescing_report['harnessSha256'], origin='coalescing/worker-diagnostic.json')
add(coalescing_harness, 'harness-snapshots/' + coalescing_harness.name)
add(ROOT / 'evidence-audit/coalescing-harness-recovery.json', 'audit/coalescing-harness-recovery.json')

for path in sorted((ROOT / 'manabitan/builds/perf/jmdict-20261120/harness-snapshots').iterdir()):
    if path.is_file():
        add(path, 'harness-snapshots/' + path.name)
add(ROOT / 'evidence-audit/build_plan.py', 'audit/build_plan.py')
audit_receipt = ROOT / 'evidence-audit/checksum-verification.json'
audit_receipt.write_text(json.dumps({'status': 'passed', 'checks': checked}, indent=2) + '\n')
add(audit_receipt, 'audit/checksum-verification.json')

warnings = [
    'Bulk publication measurements are synchronous production-method replays collected by the v4 sequential harness. Cache work and metrics are disabled equally; they are not full production-worker or browser timings.',
    'Reader timing measures the native-checksum mechanism in reader-screen.mjs with the pinned baseline wrapper and existing native export, not the final integrated production API directly. The final integration has separate focused test results.',
    'Reader/native corpus is 28 blocks and 100671677 decoded bytes from the 4 MiB seven-bank packer; the current full importer uses a different 1 MiB plan. Do not extrapolate reader timing to all imports or cache-hit paths.',
    'The phase-v3 diagnostic preserves its exact preload but not the historical root harness (de9b27ef48101d8b0d06d94ea2cbd0ca5408189963659ddc28ef2ebd1d832508) or worker transport (81dfdc6c31dee66c3e5c5a084861de7b12865509f3c906998c59bc37e0b86913) snapshot. Its raw observations and hashes remain available, but byte-exact diagnostic replay is incomplete.',
    'compression/wasm-phase-preload.mjs is a later version used for the coalescing diagnostic. Use the exact wasm-phase-preload-v3.mjs for interpreting the retained earlier v3 diagnostic.',
    'The coalescing diagnostic preserves the exact measured harness and worker transport. Its harness was reconstructed by reversing four subsequent help/formatting changes and requiring an exact match to the recorded SHA256; the recovery receipt records every replacement.',
    'Phase shares are summed nested synchronous wall work across four workers from one instrumented observation, with a strong thread outlier. They are not elapsed import time or stable critical-path shares.',
    'Historical browser evidence is from the November 19 early-lease candidate and older baseline. It supports rejecting that mechanism only; it does not qualify new changes. Validation was 12 source-derived probes plus restart checks, not a full persisted-byte oracle.',
    'The archive plan intentionally excludes raw corpus, compressed frames, upstream source tree, compiled native library, and original GitHub ZIPs. Corpus regeneration source, upstream revision plus file hashes, native build receipt, and original artifact ZIP hashes are retained.',
    'Required consolidated final lint, types, all unit tests, build, full-fixture oracles, and final-head browser evidence are outside this delegated evidence audit.'
]
plan = {
    'schemaVersion': 1,
    'scope': 'Read-only independent audit and deterministic evidence packaging plan; no benchmarks rerun',
    'root': str(ROOT),
    'files': [files[k] for k in sorted(files)],
    'totals': {'files': len(files), 'uncompressedBytes': sum(x['bytes'] for x in files.values()),
               'historicalSubsetFiles': 117, 'historicalSubsetBytes': 8449102,
               'sha256ReceiptChecks': len(checked), 'upstreamSourceFilesChecked': len(upstream['files'])},
    'metrics': {'publication': pub_metrics, 'reader': reader_metrics, 'nativeRejected': native_metrics,
                'phaseDiagnostic': phase, 'historicalRejectedLease': historical_metrics,
                'coalescingStructuralDiagnostic': coalescing},
    'warnings': warnings,
    'checksumChecksReceipt': str(audit_receipt)
}
output = ROOT / 'evidence-packaging-plan.json'
output.write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps({'output': str(output), 'sha256': digest(output), 'totals': plan['totals'], 'warnings': warnings}, indent=2))
