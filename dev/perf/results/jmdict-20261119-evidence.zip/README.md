# JMdict experiment evidence, 2026-11-19

Read dev/perf/jmdict-import-experiments-20261119.md in the accompanying repository
for findings, boundaries, controls, qualification, and portable reproduction commands.

- reports/: unchanged measurement reports, controls, qualification receipts, and
  earlier attempts. A file's presence is not a claim that its run passed.
- logs/: original execution output supporting those receipts.
- harness-snapshots/: exact measured scripts selected by SHA-256, plus final tools.
  Restore a historical script to its original dev/perf filename before running it.
- experiments/: source-history.bundle preserves local commit identities, including
  the rejected native experiment. The binary patch provides another way to inspect
  that experiment. The bundle requires baseline d829f5b6e6a75ee8859d38d537d224ec33c4930e.
- qualification-scripts/: host-specific sequential check drivers and the audited
  persisted-reader coverage preload. Portable commands are in the report.
- fixtures/: pinned archive identities; dictionary ZIP payloads are not included.

All manifest paths are relative to this archive; every payload has a SHA-256 and
byte length. The manifest does not recursively hash itself.

Important exclusions and resolutions:
- cached-exact-ab.json ended without a completed report/exit receipt and is excluded.
- baseline-components.json used an early row-capacity hint and is exploratory only.
- cached-match-full-parity-* preceded audited generation-ID normalization; their
  timings and raw random-generation file hashes are not final parity evidence.
- The concurrent monolithic unit run and first v4 baseline proof did not complete;
  completed serialized qualification supersedes them.
- unit-shard-1.json had a native compiler/linker discovery setup failure. Only that
  failed file was rerun successfully in unit-crc-qualified.json. The consolidated
  unit-qualified-summary.json verifies all 616 expected files with no shard overlap.
- Earlier type/lint failures are retained. Final successful receipts and the
  qualification summary identify the resolved gates; no failed result is hidden.
- qualified-jitendex-parity failed on pristine baseline at an image normalization
  difference from raw source JSON. qualified-jitendex-artifacts compares every
  persisted byte after validated generation-ID normalization without claiming the
  unsupported source-JSON oracle. Record packing separately has complete byte parity.
- Final corpus runs are correctness qualification. Their individual component
  timers are not replicated performance evidence or complete browser import timing.
