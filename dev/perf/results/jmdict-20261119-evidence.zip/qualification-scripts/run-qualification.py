import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path.cwd()
output = root / 'builds/perf/jmdict-20261119'
name, *command = sys.argv[1:]
assert name and command and '/' not in name
log_path = output / (name + '.log')
receipt_path = output / (name + '-exit.json')
assert not log_path.exists() and not receipt_path.exists()
env = os.environ.copy()
env['PATH'] = str(root.parent / 'runtime/node_modules/node/bin') + ':' + env['PATH']
env['NODE_OPTIONS'] = '--max-old-space-size=2048'
llvm = root.parent / 'toolchains/llvm-21.1.8/usr'
env['PATH'] = str(llvm / 'bin') + ':' + str(llvm / 'lib/llvm-21/bin') + ':' + env['PATH']
env['MANABITAN_CLANG'] = str(llvm / 'bin/clang-21')
env['MANABITAN_WASM_LD'] = str(llvm / 'bin/wasm-ld-21')
env['LD_LIBRARY_PATH'] = str(llvm / 'lib/x86_64-linux-gnu')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
start = time.time()
with log_path.open('x') as log:
    result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT)
receipt = {
    'command': command,
    'exitCode': result.returncode,
    'elapsedSeconds': time.time() - start,
    'sourceCommitBefore': head,
    'sourceCommitAfter': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'nativeToolchain': 'Clang/LLD 21.1.8 via MANABITAN_CLANG, MANABITAN_WASM_LD and LD_LIBRARY_PATH',
    'nodeHeapLimitMiB': 2048,
    'log': str(log_path),
}
with receipt_path.open('x') as handle:
    json.dump(receipt, handle, indent=2)
    handle.write('\n')
print(json.dumps(receipt))
sys.exit(result.returncode)
