import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, realpath} from 'node:fs/promises'
import path from 'node:path'
import {fileURLToPath, pathToFileURL} from 'node:url'

const script = fileURLToPath(import.meta.url)
const digest = bytes => createHash('sha256').update(bytes).digest('hex')
const scriptSha256 = digest(await readFile(script))
const index = process.argv.indexOf('--source')
assert.ok(index >= 0 && process.argv[index + 1], 'Coverage requires a single selected checkout')
const source = await realpath(path.resolve(process.argv[index + 1]))
const {DictionaryDatabase} = await import(pathToFileURL(path.join(source, 'ext/js/dictionary/dictionary-database.js')).href)
const prototype = DictionaryDatabase.prototype
const originalBulk = prototype._bulkAddArtifactTermsChunkWithContentDedup
const originalReadBatch = prototype._readTermEntryContentBytesDetailedBatch
const active = new WeakSet()
let calls = 0
let requests = 0
let positiveLengthRequests = 0
prototype._bulkAddArtifactTermsChunkWithContentDedup = async function (...args) {
  assert.ok(!active.has(this), 'Unexpected overlapping component sink call')
  active.add(this)
  try {
    return await originalBulk.apply(this, args)
  } finally {
    active.delete(this)
  }
}
prototype._readTermEntryContentBytesDetailedBatch = function (...args) {
  if (active.has(this)) {
    assert.ok(Array.isArray(args[0]))
    ++calls
    requests += args[0].length
    positiveLengthRequests += args[0].filter(value => value.contentLength > 0).length
  }
  return originalReadBatch.apply(this, args)
}
const instrumentation = Symbol.for('manabitan.perf.instrumentation')
const finalizer = Symbol.for('manabitan.perf.finalize')
assert.equal(Reflect.get(globalThis, instrumentation), undefined)
assert.equal(Reflect.get(globalThis, finalizer), undefined)
Reflect.set(globalThis, instrumentation, {kind: 'persisted-content-reader-coverage', diagnosticOnly: true, source: script, sha256: scriptSha256})
Reflect.set(globalThis, finalizer, async (report, context) => {
  try {
    assert.equal(context.source, source)
    assert.equal(report.harnessSemanticsVersion, 4)
    assert.equal(report.policy.limitBanks, 0)
    assert.equal(report.policy.deviceMemory, 4)
    assert.equal(report.rows, report.fixture.termRows)
    assert.equal(report.verification?.rows, report.rows)
    assert.ok(report.sinkTotals.dedupRecentSourceHitCount > 0)
    assert.ok(report.sinkTotals.dedupRecentSourceHitCount < report.sinkTotals.dedupPersistedHitCount)
    assert.ok(calls > 0 && requests > 0 && positiveLengthRequests > 0)
    assert.equal(digest(await readFile(script)), scriptSha256)
    return {
      calls, requests, positiveLengthRequests,
      scope: 'Calls into the persisted-content batch reader during an active import sink only; reopened validation excluded',
      limit: 'The reader may use its decoded-block cache. These are not physical OPFS read or decompression counts. Instrumented timing is not performance evidence.',
      semanticSha256: report.verification.sha256,
      canonicalSha256: report.storedFilesCanonicalSha256,
      scriptSha256
    }
  } finally {
    prototype._bulkAddArtifactTermsChunkWithContentDedup = originalBulk
    prototype._readTermEntryContentBytesDetailedBatch = originalReadBatch
  }
})
