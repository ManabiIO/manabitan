import subprocess
import sys
from pathlib import Path
root=Path.cwd()
runner=root/'builds/perf/jmdict-20261119/run-qualification.py'
node=['node','--max-old-space-size=1400']
common=['dev/perf/jmdict-component-benchmark.js','--fixture','builds/e2e-dictionary-cache/JMdict.zip','--device-memory','4']
checks=[]
for arm,checkout in [('baseline',root.parent/'manabitan-baseline'),('candidate',root)]:
    name=f'qualified-jmdict-low-memory-{arm}'
    checks.append([name,*node,'--import','./builds/perf/jmdict-20261119/persisted-read-coverage-preload.mjs',*common,'--source',str(checkout),'--output',f'builds/perf/jmdict-20261119/{name}.json'])
checks.extend([
    ['final-lint-production',*node,'node_modules/eslint/bin/eslint.js','--parser-options','{"project":["./jsconfig.json"]}','ext/js/dictionary/dictionary-database.js','ext/js/dictionary/dictionary-importer.js','ext/js/dictionary/term-record-opfs-store.js'],
    ['final-lint-tests',*node,'node_modules/eslint/bin/eslint.js','--parser-options','{"project":["./test/jsconfig.json"]}','test/dictionary-database-content-dedup.test.js','test/dictionary-importer-source-row-contract.test.js','test/term-record-opfs-store.test.js'],
    ['final-lint-dev',*node,'node_modules/eslint/bin/eslint.js','--parser-options','{"project":["./dev/jsconfig.json"]}','dev/perf/cached-content-comparison-preload.js','dev/perf/jmdict-component-benchmark.js','dev/perf/jmdict-compression-level-preload.js','dev/perf/jmdict-source-cache-trace-preload.js','dev/perf/term-bank-parser-component-benchmark.js','dev/perf/term-record-fields-benchmark.js'],
    ['final-build-dry','npm','run','test:build'],
    ['final-build-chrome','npm','run','build','--','--target','chrome'],
])
if len(sys.argv) > 1:
    checks = checks[next(i for i, check in enumerate(checks) if check[0] == sys.argv[1]):]
for check in checks:
    print('Starting '+check[0],flush=True)
    result=subprocess.run([sys.executable,str(runner),*check])
    if result.returncode:
        print('Stopped at '+check[0],flush=True)
        sys.exit(result.returncode)
print('Final plan completed',flush=True)
