# Import optimization: final combined validation

This bundle preserves validation records for the combined JMdict, Jitendex and VNDB changes. It contains unchanged logs, exact source identities, a source-only reconstruction patch and reproduction commands. It does not contain dictionary archives, installed runtimes, native binaries, XPI packages or browser profiles.

## Source identity

| Role | Commit | Tree |
| --- | --- | --- |
| Baseline develop | `7d1643e6147a10cb2165e9744cf0e63b59e46632` | `99d23f16e973c7ae9feba77ca3643d1c27dfb93d` |
| Validated local combination | `65aad0026e4bb278f2d51e02ac991ebe9a1101ad` | `31f3c93c37a67a5554308a19b0c4ab8b5258f608` |
| Public equivalent combination | `3ef542838499e874324ac5d0e6f92c3b12ede637` | `31f3c93c37a67a5554308a19b0c4ab8b5258f608` |

The public source is [commit 3ef54283](https://github.com/ManabiIO/manabitan/commit/3ef542838499e874324ac5d0e6f92c3b12ede637) on `evidence/imports-20261125-7b5a`. Its complete tree was independently checked against the validated local tree. The auxiliary evidence publication does not update the three implementation PR branches.

The implementation PR heads at collection were:

- [#894](https://github.com/ManabiIO/manabitan/pull/894): `7ee8f0cde0845af3906e77b8adad11e3aaefc371`
- [#895](https://github.com/ManabiIO/manabitan/pull/895): `36fd7a27b7aa631fc8aa20bd70a9f125850499cb`
- [#915](https://github.com/ManabiIO/manabitan/pull/915): `376611ce52022a0f12b08d1a856e29294c3002fe`

### Subsequent documentation-only correction

After code validation, #915 advanced by a non-forced fast-forward to `41f17da88a30b10c38ecabddf6820dd2dbe35e13`, equivalent to local commit `bed834e36a6e2aa01a26e5b816a008040b958d66`, with standalone PR tree `9dd0b48c795904e9bc4ac2d9f0ff3da607fdbd21`. Only four table lines in `test/perf/dense-zip-catalog-20261125/README.md` changed to satisfy Prettier. Product source and tests did not change.

[CI run 45646247904](https://github.com/ManabiIO/manabitan/actions/runs/45646247904) on the preceding VNDB code head had 13 successful jobs, one Markdown formatting failure, one Chromium E2E cancellation after the new push, and four optional skips. Its successful unit job recorded 647 files, 14,571 passing tests and 47 skips; JavaScript, all four TypeScript jobs and Firefox E2E also passed. These are results for that standalone PR head, not the combined source or the newer documentation head.

`logs/vndb-ci-markdown-failure.log` preserves the original failure, and `logs/vndb-markdown-fixed.log` records the successful local formatting check after correction. The validated combined commit/tree and public source commit above remain unchanged. The manifest records both the code-validation PR heads and the current PR heads. Its source reconstruction patch and source hashes intentionally continue to identify the tested combined tree.

`manifest.json` records hashes for every changed text file, 18 runtime/source files, the dependency lock and the dictionary lock. The combined parser WASM SHA-256 is `f3bb4ab538cce77a8f9681b853aba10bcfd62cd0b6ec63cb40429bf05d561d83`.

## Results and retained failures

| Check | Recorded outcome | Raw record |
| --- | --- | --- |
| TypeScript main, dev, test and bench | All four commands exited 0 | `logs/combined-types-*.log` |
| Full unit invocation | Exit 1; 646 files passed, 14,578 tests passed, 68 skipped; two suites failed during compiler discovery | `logs/combined-unit.log` |
| Compiler-dependent suite rerun | Exit 0; two files and 21 tests passed after loading the pinned LLVM environment | `logs/combined-compiler-suites.log` |
| Pinned WASM rebuild/check | Exit 0 with Clang/LLD 21.1.8; both checked-in target hashes matched | `logs/combined-wasm-check.log` |
| All-target dry build | Exit 0 for seven targets | `logs/combined-build.log` |
| Initial combined lint attempt | Exit 134 from heap exhaustion with a 512 MiB limit | `logs/combined-lint.log` |
| Expanded-heap combined lint | Exit 1 with 43 style/JSDoc findings before the final correction | `logs/combined-lint-1536.log` |
| Intermediate VNDB scoped autofix | Exit 1 with three remaining formatting findings | `logs/vndb/scoped-lint-fix.log` |
| Final VNDB scoped lint | Exit 0 over the eight listed files; all eight match the final combined tree byte-for-byte | `logs/vndb/scoped-lint-final.log` |

The two failed unit suites were `test/term-bank-crc.test.js` and `test/term-bank-memory-page.test.js`. Their setup could not discover a supported WASM compiler. The targeted rerun loaded the pinned LLVM environment; no product/source change was made between the full unit run and this rerun.

Across those two executions, the result is **648 passing files, 14,599 passing tests and 47 intentional skips**: 646 + 2 files, 14,578 + 21 passing tests, and 68 - 21 skips. This is an aggregate across an unchanged-source full run and its targeted environment-corrected rerun. The original full invocation still exited 1 and remains preserved as such.

The seven dry-build targets were Chrome, Chrome development, Chrome Playwright, Firefox, Firefox development, Firefox Android and Edge. A dry build is not browser functionality verification.

Empty TypeScript logs are retained unchanged. Successful exits are recorded in the manifest from the coordinator's command receipts; the dev/test/bench receipts also appear in `logs/combined-validation-progress.json`. The exact historical file list for the two earlier combined lint attempts was not retained locally. This bundle does not describe those as successful full-repository lint runs. The final scoped lint command and its exact file list are recorded.

### Browser results

Completed Firefox functional records are under `browser/firefox-functional/`, with an exact curated file manifest and `qualification-summary.json`. They use Firefox Developer Edition 161.0b5, geckodriver 0.37.1, the final combined source, pinned dictionaries and the built Firefox development package. External harness compatibility changes are recorded separately; product source remained unchanged.

The focused Jitendex/JMdict UI-import suite passed all 30 phases with exit 0 and no runtime skips. Its scope includes OPFS readiness, imports, installed/enabled dictionaries and lookup continuity during the second import.

The successful VNDB attempt imported the pinned dictionary, checked persisted summary/API counts of 6,648,310 terms and 146,570 media records, restarted Firefox on the same generated test profile, and compared every referenced image against the pinned ZIP: **146,570 images and 188,131,284 bytes**, with digest `ea94d392bc833baf0bee7b3d6becc3d3517eee84ee314a44986438ac6d5217cb`. Twelve term lookups and 29 strictly decoded OPFS rows matched before/after restart. These term probes sample content; the summary counts are not exhaustive physical-record enumeration.

All four VNDB attempts are retained with exact harness snapshots: diagnostic-schema failure (exit 1), verifier heap exhaustion (exit 134), eager-verifier termination under host pressure (exit 137), and the final bounded-verifier success. The final attempt's report, completion provenance and final log marker establish success; its terminal exit status was not separately saved, so `processExitCode` remains null.

The bounded generic Zip.js oracle was qualified before use by exact full Jitendex result equality with the original oracle: 236 referenced images, 4,992,155 bytes and matching digest, plus rejection of changed bytes, missing entries, duplicate paths and wrong-dictionary responses. Its qualification covers ALL mode. It does not use the candidate dense catalog as its source oracle. See `browser/README.md` for replay constraints and responder generation.

The earlier all-corpus native output replay and VNDB catalog measurements remain separate evidence with separate boundaries. Unit, type, build and browser correctness checks do not establish a complete-import speedup or process-memory improvement.

## Reproduce the source

Use Node 22.22.0 and Clang/LLD 21.1.8. Configure the pinned compiler and linker explicitly if they are not available as `clang-21` and `wasm-ld-21` on `PATH`. The native unit-test compiler probe also requires the compiler's default WASM linker and shared libraries to resolve correctly.

```sh
git clone https://github.com/ManabiIO/manabitan.git combined
cd combined
git fetch origin 3ef542838499e874324ac5d0e6f92c3b12ede637
git checkout --detach 3ef542838499e874324ac5d0e6f92c3b12ede637
test "$(git rev-parse HEAD^{tree})" = 31f3c93c37a67a5554308a19b0c4ab8b5258f608
npm ci

# Set these to the installed pinned tools, and configure their library PATH
# when the installation requires it.
export MANABITAN_CLANG=/absolute/path/to/clang-21
export CLANG="$MANABITAN_CLANG"
export MANABITAN_WASM_LD=/absolute/path/to/wasm-ld-21

node --max-old-space-size=1536 dev/bin/build-dictionary-wasm.js --check
node dev/bin/build-libs.js
python3 /absolute/path/to/final-validation-evidence/verify-source.py .
```

Alternatively, start at baseline `7d1643e6`, apply `baseline-to-combined-source.patch`, then run the pinned builder with `--write` and build the libraries:

```sh
git checkout --detach 7d1643e6147a10cb2165e9744cf0e63b59e46632
git apply /absolute/path/to/final-validation-evidence/baseline-to-combined-source.patch
node --max-old-space-size=1536 dev/bin/build-dictionary-wasm.js --write
node dev/bin/build-libs.js
python3 /absolute/path/to/final-validation-evidence/verify-source.py .
```

The patch includes all 17 changed text files. It omits the generated parser WASM and two archived measurement ZIPs; rebuilding recreates the native binary. Therefore the patch route reproduces the checked source/runtime hashes but does not produce the identical complete Git tree until the deliberately omitted measurement archives are restored. The public-commit route provides the exact complete tree.

## Reproduce validation

The following commands correspond to the successful check configuration. Run them sequentially from the combined source checkout with Node 22.22.0 and the pinned compiler environment already active. Compiler setup before the full unit invocation avoids the setup failures preserved in the original run.

```sh
node --max-old-space-size=1536 node_modules/typescript/bin/tsc --noEmit --project jsconfig.json
node --max-old-space-size=1536 node_modules/typescript/bin/tsc --noEmit --project dev/jsconfig.json
node --max-old-space-size=1536 node_modules/typescript/bin/tsc --noEmit --project test/jsconfig.typecheck.json
node --max-old-space-size=1536 node_modules/typescript/bin/tsc --noEmit --project benches/jsconfig.json
node --max-old-space-size=1536 node_modules/vitest/vitest.mjs run --maxWorkers=1 --testTimeout=60000
node --max-old-space-size=1536 node_modules/vitest/vitest.mjs run test/term-bank-crc.test.js test/term-bank-memory-page.test.js --maxWorkers=1 --testTimeout=60000
node --max-old-space-size=1536 dev/bin/build-dictionary-wasm.js --check
node --max-old-space-size=1536 dev/bin/build.js --dryRun --all
node --max-old-space-size=1536 node_modules/eslint/bin/eslint.js ext/js/dictionary/dense-zip-directory.js ext/js/dictionary/dense-zip-file-map.js ext/js/dictionary/dictionary-importer.js test/dense-zip-directory.test.js test/dense-zip-file-map.test.js test/dictionary-importer-bank-order.test.js test/perf/dense-zip-catalog-20261125/screen.mjs test/perf/dense-zip-catalog-20261125/worker.mjs
```

The targeted compiler rerun above is shown to reproduce the retained receipt; after a successful compiler-enabled full invocation it is redundant. Packaging this evidence bundle did not execute any project tests or change any PR.

## Add completed browser evidence

1. Copy only completed report JSON, bounded text logs, command/environment provenance and necessary harness scripts into distinct subdirectories under `browser/`. Preserve every attempt under its own name. Do not copy dictionary fixtures, profiles, XPI files, runtime binaries or whole working directories.
2. Review every copied file for signed URLs, credentials and private profile content. Keep raw files byte-for-byte unchanged. If a raw file is unsafe to publish, omit it and explicitly identify any sanitized derivative and its limitations.
3. Update `manifest.json` → `browser` with the exact source commit/tree, command, runtime, flags, fixture identity, exit code, result/skip status and report paths for each attempt. Update this browser summary without changing historical records.
4. Run `python3 freeze-evidence.py` from this bundle directory. It verifies retained raw-file hashes, scans for prohibited material, refreshes artifact hashes and `SHA256SUMS`, then writes `../final-validation-evidence.zip`.
5. Run `sha256sum -c SHA256SUMS`. Publish the ZIP on the auxiliary evidence branch and link its immutable commit from the implementation PR descriptions.

The archive hash is printed by the packaging script. `SHA256SUMS` covers every packaged file except itself; `manifest.json` additionally describes the raw evidence artifacts and source identities.
