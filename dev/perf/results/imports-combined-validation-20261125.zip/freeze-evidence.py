#!/usr/bin/env python3
"""Check and package evidence. This script never builds or runs project tests."""

import datetime
import hashlib
import json
from pathlib import Path
import re
import zipfile


root = Path(__file__).resolve().parent
manifest_path = root / "manifest.json"
manifest = json.loads(manifest_path.read_text())
allowed_suffixes = {".md", ".json", ".log", ".patch", ".py", ".sh", ".js", ".mjs", ".txt", ".html"}
forbidden_parts = {"node_modules", "profiles", "profile", "browser-profile", "runtime", "fixtures"}
secret_patterns = {
    "private-key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "github-token": re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,})\b"),
    "aws-access-key": re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
    "bearer-credential": re.compile(r"\bBearer\s+[A-Za-z0-9_.~+/-]{24,}=*"),
    "url-userinfo": re.compile(r"https?://[^\s/@]+:[^\s/@]+@"),
    "signed-url": re.compile(r"https?://[^\s\"'<>]*(?:[?&](?:X-Amz-Signature|X-Goog-Signature|sig|signature|access_token|token)=)[^\s\"'<>]+", re.I),
    "credential-value": re.compile(r"(?:\"?(?:authorization|password|client_secret|api_key)\"?\s*[:=]\s*)[\"'][A-Za-z0-9_./+=-]{24,}[\"']", re.I),
}
previous_raw = {
    record["path"]: record["sha256"]
    for record in manifest.get("artifacts", [])
    if record.get("kind") == "raw-evidence"
}
files = []
problems = []
for file in sorted(root.rglob("*")):
    if file.is_symlink():
        problems.append(file.relative_to(root).as_posix() + ": symlink")
        continue
    if not file.is_file() or file.name == "SHA256SUMS":
        continue
    relative = file.relative_to(root)
    name = relative.as_posix()
    if any(part.lower() in forbidden_parts for part in relative.parts):
        problems.append(name + ": excluded directory")
    if file.suffix.lower() not in allowed_suffixes:
        problems.append(name + ": excluded file type")
    data = file.read_bytes()
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        problems.append(name + ": non-UTF-8 binary content")
        continue
    for label, pattern in secret_patterns.items():
        match = pattern.search(text)
        if match:
            line = text.count("\n", 0, match.start()) + 1
            problems.append(f"{name}:{line}: {label}")
    digest = hashlib.sha256(data).hexdigest()
    if name in previous_raw and previous_raw[name] != digest:
        problems.append(name + ": previously frozen raw evidence changed")
    origin = manifest.get("logOrigins", {}).get(name)
    if origin and Path(origin).exists() and Path(origin).read_bytes() != data:
        problems.append(name + ": differs from original raw file")
    files.append((file, name, data, digest))
current_paths = {name for _, name, _, _ in files}
for missing in sorted(previous_raw.keys() - current_paths):
    problems.append(missing + ": previously frozen raw evidence is missing")
if problems:
    raise SystemExit("Evidence checks failed (values withheld):\n" + "\n".join(problems))

artifacts = []
for _, name, data, digest in files:
    if name.startswith("logs/") or (name.startswith("browser/") and not name.endswith("README.md")) or name.endswith(".patch"):
        artifacts.append({
            "path": name,
            "bytes": len(data),
            "sha256": digest,
            "kind": "source-patch" if name.endswith(".patch") else "raw-evidence",
        })
manifest["artifacts"] = artifacts
manifest["privacyReview"] = {
    "status": "completed",
    "checkedUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "scope": "All packaged UTF-8 files; explicit extension/directory allowlist, secret/signed-URL scan, and original raw-file comparison where originals remain available",
    "excludedMaterial": ["dictionary fixture archives", "runtime binaries", "native WASM binaries", "XPI packages", "browser profiles", "signed download URLs", "credentials"],
}
manifest_path.write_text(json.dumps(manifest, indent=2) + "\n")
packaged = [(file, file.relative_to(root).as_posix()) for file in sorted(root.rglob("*")) if file.is_file() and file.name != "SHA256SUMS"]
lines = [hashlib.sha256(file.read_bytes()).hexdigest() + "  " + name for file, name in packaged]
(root / "SHA256SUMS").write_text("\n".join(lines) + "\n")
packaged.append((root / "SHA256SUMS", "SHA256SUMS"))
output = root.with_name(root.name + ".zip")
with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for file, name in sorted(packaged, key=lambda item: item[1]):
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 25, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, file.read_bytes(), compresslevel=9)
with zipfile.ZipFile(output) as archive:
    failure = archive.testzip()
    if failure is not None:
        raise SystemExit("ZIP CRC check failed: " + failure)
print(f"Packaged {len(packaged)} files; {len(artifacts)} raw evidence/source artifacts")
print(output)
print(hashlib.sha256(output.read_bytes()).hexdigest())
