# Completed Firefox functional evidence

`firefox-functional/curated-browser-files.json` records the frozen source-relative names, sizes and SHA-256 values. `qualification-summary.json` contains the exact commands, flags, source/runtime/package/fixture identities, scopes and attempt classifications.

The focused Jitendex/JMdict run passed 30 phases with exit 0 and no skips. VNDB attempt 4 completed exact comparison of all 146,570 referenced images (188,131,284 bytes) after a real Firefox restart on its generated test profile. Its report/provenance/log establish success; no separate terminal exit-code artifact was saved, so the recorded process exit code remains null. Attempts 1–3 retain their failures, reports where available, logs and exact runner snapshots.

## Replay constraints

The frozen scripts use the historical absolute workspace `/workspace/scratch/7b5a4ac440c8`. In an isolated replay environment, recreate that layout or create a separate path-only harness overlay with new hashes and provenance. Keep these evidence snapshots unchanged.

The source checkout belongs in `combined/`; the external harness belongs in sibling `firefox-functional/`, with access to the checkout's Node dependencies. Copy the selected `vndb-attempt-N/run-vndb.mjs` back to `firefox-functional/run-vndb.mjs` before invocation: its relative imports assume that original location. For attempt 4, retain the bounded `streaming-media-validation.mjs`. Reinstall the exact Node, Firefox and geckodriver versions and hashes recorded in the summary. The required `runtime/firefox-bundle/runtime.json` can be recreated from the summary's `runtime` object. Build the recorded Firefox development package and prepare the pinned archives using the repository's fixture tool; generated profiles, packages, fixtures and runtime binaries are intentionally excluded here.

The oracle script reads Jitendex from `manabitan/builds/e2e-dictionary-cache/`, while browser wrappers read `combined/builds/e2e-dictionary-cache/`; both must resolve to the same locked archive. `validate-streaming-oracle.mjs` expects the excluded `jitendex-media-responder.json` beside itself. Recreate that file locally by using Python's standard-library `zipfile` to read every image member of the locked Jitendex archive, checking its CRC during decoding, and writing a JSON object mapping each exact archive pathname to its base64-encoded decoded bytes. The source archive has 249 image members; both oracles independently exclude the 13 lock-declared unused images and verify 236 referenced members. Do not publish the generated responder payload.

The historical invocation and helper/overlay provenance are part of the records. A path-rebound replay produces new invocation/provenance hashes; it must still verify the recorded product/runtime/fixture identities. These are functional qualification records, not baseline-versus-candidate timing measurements.
