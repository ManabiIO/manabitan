import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {execFileSync, spawn} from 'node:child_process'
import {createReadStream} from 'node:fs'
import {copyFile, readFile, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {verifyPackage} from './verify-package.mjs'

const workspace = '/workspace/scratch/7b5a4ac440c8'
const root = path.join(workspace, 'combined')
const directory = path.join(workspace, 'firefox-functional')
const runtimeRoot = path.join(workspace, 'runtime/firefox-bundle')
const node = path.join(workspace, 'runtime/node-v22.22.0-linux-x64/bin/node')
const reportPath = path.join(directory, 'two-dictionary.html')
const packagePath = path.join(directory, 'combined-firefox-dev.zip')
const harnessPath = path.join(directory, 'two-dictionary-loopback.mjs')
const provenancePath = path.join(directory, 'two-dictionary-provenance.json')
const hashFile = async (file) => {
    const hash = createHash('sha256')
    for await (const chunk of createReadStream(file)) { hash.update(chunk) }
    return hash.digest('hex')
}
const json = async (file) => JSON.parse(await readFile(file, 'utf8'))
const git = (...args) => execFileSync('git', args, {cwd: root, encoding: 'utf8'}).trim()
assert.equal(process.version, 'v22.22.0')
const runtime = await json(path.join(runtimeRoot, 'runtime.json'))
assert.equal(await hashFile(path.join(runtimeRoot, 'firefox/firefox')), runtime.binarySha256)
assert.equal(await hashFile(path.join(runtimeRoot, 'firefox/application.ini')), runtime.applicationIniSha256)
assert.equal(await hashFile(path.join(runtimeRoot, 'firefox/libxul.so')), runtime.libxulSha256)
assert.equal(await hashFile(path.join(runtimeRoot, 'geckodriver')), runtime.geckodriver.binarySha256)
const overlay = await json(path.join(directory, 'overlay-provenance.json'))
assert.equal(await hashFile(overlay.source), overlay.sourceSha256)
assert.equal(await hashFile(harnessPath), overlay.overlaySha256)
const lockPath = path.join(root, 'test/perf/dictionaries.lock.json')
const fixtures = (await json(lockPath)).dictionaries
const archives = {}
for (const id of ['jmdict', 'jitendex', 'jmnedict']) {
    const fixture = fixtures[id]
    const file = path.join(root, 'builds/e2e-dictionary-cache', fixture.cacheFile)
    const digest = await hashFile(file)
    assert.equal(digest, fixture.sha256, `${id} pinned archive`)
    archives[id] = {file, sha256: digest, expectedTitle: fixture.expectedTitle, revision: fixture.revision, termRows: fixture.termRows}
}
await copyFile(path.join(root, 'builds/manabitan-firefox-dev.zip'), packagePath)
const sourceHashes = {}
for (const relative of ['ext/js/dictionary/wasm/term-bank-parser.c', 'ext/js/dictionary/term-bank-wasm-parser.js', 'ext/js/dictionary/dense-zip-directory.js', 'ext/js/dictionary/dense-zip-file-map.js', 'ext/js/dictionary/dictionary-importer.js', 'ext/lib/term-bank-parser.wasm', 'dev/data/dictionary-wasm/manifest.json', 'package-lock.json', 'dev/bin/build.js', 'dev/data/manifest-variants.json', 'test/firefox/extension-two-dictionary-import.e2e.js']) {
    sourceHashes[relative] = await hashFile(path.join(root, relative))
}
const packagedSources = await verifyPackage(packagePath, sourceHashes)
const environment = {
    MANABITAN_FIREFOX_BINARY: path.join(runtimeRoot, 'firefox/firefox'),
    MANABITAN_FIREFOX_XPI: packagePath,
    MANABITAN_FIREFOX_E2E_REPORT: reportPath,
    MANABITAN_E2E_STRICT_RUNTIME: '1',
    MANABITAN_FIREFOX_FOCUSED_BASELINE_ONLY: '1',
    MANABITAN_FIREFOX_RECOMMENDED_SECONDARY: 'JMdict',
    MANABITAN_FIREFOX_HEADLESS: '1',
    MANABITAN_FIREFOX_PROFILE_DIR: '',
    MANABITAN_FIREFOX_EXISTING_PROFILE_ONLY: '0',
    MANABITAN_FIREFOX_PROFILE_CYCLE: '0',
}
const provenance = {
    kind: 'Firefox functional qualification only; no performance claim',
    startedAt: new Date().toISOString(),
    node: {version: process.version, executable: node, sha256: await hashFile(node)},
    source: {root, head: git('rev-parse', 'HEAD'), tree: git('rev-parse', 'HEAD^{tree}'), status: git('status', '--porcelain'), hashes: sourceHashes},
    runtime,
    overlay,
    archiveLockSha256: await hashFile(lockPath),
    archives,
    package: {path: packagePath, sha256: await hashFile(packagePath), ...packagedSources},
    command: {executable: node, args: ['--max-old-space-size=512', harnessPath], environment},
    complete: false,
}
const save = () => writeFile(provenancePath, JSON.stringify(provenance, null, 2) + '\n')
await save()
const child = spawn(node, provenance.command.args, {cwd: root, env: {...process.env, ...environment}, stdio: 'inherit'})
const result = await new Promise((resolve, reject) => {
    child.on('error', reject)
    child.on('exit', (code, signal) => resolve({code, signal}))
})
provenance.result = result
provenance.finishedAt = new Date().toISOString()
await save()
assert.equal(await hashFile(packagePath), provenance.package.sha256, 'Installed package identity changed')
assert.equal(await hashFile(harnessPath), overlay.overlaySha256, 'Harness identity changed')
for (const [relative, digest] of Object.entries(sourceHashes)) {
    assert.equal(await hashFile(path.join(root, relative)), digest, `Source identity changed: ${relative}`)
}
assert.equal(result.code, 0, 'Functional harness failed')
const report = await json(reportPath.replace(/\.html$/, '.json'))
provenance.report = {path: reportPath.replace(/\.html$/, '.json'), sha256: await hashFile(reportPath.replace(/\.html$/, '.json')), status: report.status, skippedVerification: report.skippedVerification, phaseCount: report.phaseCount}
await save()
assert.equal(report.status, 'success')
assert.equal(report.skippedVerification, false)
provenance.complete = true
await save()
console.log(`Verified strict functional result and provenance: ${provenancePath}`)
