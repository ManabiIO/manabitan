import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import {closeSync, createReadStream, openSync} from 'node:fs'
import {copyFile, mkdir, mkdtemp, readFile, realpath, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {createServer} from 'node:net'
import {Builder, Browser, By} from 'selenium-webdriver'
import * as firefox from 'selenium-webdriver/firefox.js'
import {waitForExtensionBaseUrl} from '../combined/test/e2e/firefox-extension-base-url.js'
import {verifyBenchmarkMediaStreaming as verifyBenchmarkMedia} from './streaming-media-validation.mjs'
import {getRawTermContentBlockCompressionDictName, RAW_TERM_CONTENT_BLOCK_REFERENCE_BYTES, RAW_TERM_CONTENT_COMPACT_BLOCK_REFERENCE_BYTES, RAW_TERM_CONTENT_DIRECT_BLOCK_DICT_NAME_PREFIX} from '../combined/ext/js/dictionary/raw-term-content.js'
import * as helper from './firefox-helpers.mjs'
import {verifyPackage} from './verify-package.mjs'

const workspace = '/workspace/scratch/7b5a4ac440c8'
const root = path.join(workspace, 'combined')
const directory = path.join(workspace, 'firefox-functional')
const runtimeRoot = path.join(workspace, 'runtime/firefox-bundle')
const packagePath = path.join(directory, 'vndb-firefox-dev.zip')
const reportPath = path.join(directory, 'vndb-functional.json')
const provenancePath = path.join(directory, 'vndb-provenance.json')
const hashFile = async (file) => {
    const hash = createHash('sha256')
    for await (const chunk of createReadStream(file)) { hash.update(chunk) }
    return hash.digest('hex')
}
const readJson = async (file) => JSON.parse(await readFile(file, 'utf8'))
assert.equal(process.version, 'v22.22.0')
await mkdir(directory, {recursive: true})
const runtime = await readJson(path.join(runtimeRoot, 'runtime.json'))
assert.equal(await hashFile(path.join(runtimeRoot, 'firefox/firefox')), runtime.binarySha256)
assert.equal(await hashFile(path.join(runtimeRoot, 'firefox/application.ini')), runtime.applicationIniSha256)
assert.equal(await hashFile(path.join(runtimeRoot, 'firefox/libxul.so')), runtime.libxulSha256)
assert.equal(await hashFile(path.join(runtimeRoot, 'geckodriver')), runtime.geckodriver.binarySha256)
const fixture = (await readJson(path.join(root, 'test/perf/dictionaries.lock.json'))).dictionaries.vndb
const archivePath = path.join(root, 'builds/e2e-dictionary-cache', fixture.cacheFile)
assert.equal(await hashFile(archivePath), fixture.sha256)
await copyFile(path.join(root, 'builds/manabitan-firefox-dev.zip'), packagePath)
const profilePath = await mkdtemp(path.join(directory, 'vndb-profile-'))
const helperProvenance = await readJson(path.join(directory, 'helper-provenance.json'))
assert.equal(await hashFile(helperProvenance.helper), helperProvenance.helperSha256)
const sourceHashes = {}
for (const relative of ['ext/js/dictionary/wasm/term-bank-parser.c', 'ext/js/dictionary/term-bank-wasm-parser.js', 'ext/js/dictionary/dense-zip-directory.js', 'ext/js/dictionary/dense-zip-file-map.js', 'ext/js/dictionary/dictionary-importer.js', 'ext/js/dictionary/raw-term-content.js', 'ext/lib/term-bank-parser.wasm', 'dev/data/dictionary-wasm/manifest.json', 'package-lock.json', 'dev/bin/build.js', 'dev/data/manifest-variants.json']) {
    sourceHashes[relative] = await hashFile(path.join(root, relative))
}
const packagedSources = await verifyPackage(packagePath, sourceHashes)
const provenance = {
    kind: 'Firefox functional import/restart/media qualification only; no performance claim',
    startedAt: new Date().toISOString(),
    node: process.version,
    command: {executable: process.execPath, args: [...process.execArgv, process.argv[1]], cwd: process.cwd(), environment: {MANABITAN_E2E_STRICT_RUNTIME: process.env.MANABITAN_E2E_STRICT_RUNTIME}},
    source: {head: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim(), tree: execFileSync('git', ['rev-parse', 'HEAD^{tree}'], {cwd: root, encoding: 'utf8'}).trim(), hashes: sourceHashes},
    runtime,
    package: {path: packagePath, sha256: await hashFile(packagePath), ...packagedSources},
    archive: {path: archivePath, ...fixture},
    harnessSha256: await hashFile(new URL(import.meta.url)),
    helperProvenance,
    mediaValidatorSha256: await hashFile(path.join(root, 'dev/perf/import-media-validation.js')),
    streamingMediaValidator: {path: path.join(directory, 'streaming-media-validation.mjs'), sha256: await hashFile(path.join(directory, 'streaming-media-validation.mjs')), method: 'Two-pass generic Zip.js generator; unchanged exact byte checks and canonical sorted digest; at most256 live entries/8MiB payload batches, with the original single-oversized-member exception'},
    profilePath,
    launches: [],
    complete: false,
}
const saveProvenance = () => writeFile(provenancePath, JSON.stringify(provenance, null, 2) + '\n')
await saveProvenance()
const report = helper.createReport()
report.kind = provenance.kind
const checkpoint = (stage) => writeFile(path.join(directory, 'vndb-checkpoint.json'), JSON.stringify({stage, source: provenance.source, package: provenance.package, launches: provenance.launches, beforeRestart: report.beforeRestart, afterRestart: report.afterRestart, beforeProbes: report.beforeProbes, afterProbes: report.afterProbes}, null, 2) + '\n')
const heartbeat = helper.startHeartbeat(report, path.join(directory, 'vndb-functional-live.json'))
let driver = null
const logDescriptors = []
const unusedLoopbackPort = async () => {
    const server = createServer()
    await new Promise((resolve, reject) => {
        server.once('error', reject)
        server.listen(0, '127.0.0.1', resolve)
    })
    const port = server.address().port
    await new Promise((resolve, reject) => server.close((error) => error ? reject(error) : resolve()))
    return port
}
const launch = async () => {
    const options = new firefox.Options().setBinary(path.join(runtimeRoot, 'firefox/firefox'))
    options.addArguments('-headless', '-profile', profilePath)
    for (const [key, value] of Object.entries({
        'xpinstall.signatures.required': false,
        'extensions.manifestV3.enabled': true,
        'extensions.backgroundServiceWorker.enabled': true,
        'extensions.webextensions.uuids': JSON.stringify({'{accbebce-862b-48a9-bb9a-1da9ad1f8702}': '6d1d0bf0-9b57-4ff8-9d93-64e13ae0f5da'}),
        'javascript.options.shared_memory': true,
        'dom.postMessage.sharedArrayBuffer.withCOOP_COEP': true,
        'dom.postMessage.sharedArrayBuffer.bypassCOOP_COEP.insecure.enabled': true,
    })) { options.setPreference(key, value) }
    const service = new firefox.ServiceBuilder(path.join(runtimeRoot, 'geckodriver')).setHostname('127.0.0.1')
    // Mozilla documents an explicit Marionette port for in-place custom profiles.
    const marionettePort = await unusedLoopbackPort()
    service.addArguments('--allow-system-access', '--marionette-port', String(marionettePort))
    service.addArguments('--log', 'info')
    const logDescriptor = openSync(path.join(directory, `vndb-geckodriver-${provenance.launches.length + 1}.log`), 'a')
    logDescriptors.push(logDescriptor)
    service.setStdio(['ignore', logDescriptor, logDescriptor])
    const value = await new Builder().forBrowser(Browser.FIREFOX).setFirefoxOptions(options).setFirefoxService(service).build()
    try {
        await value.manage().setTimeouts({script: 120000, pageLoad: 30000, implicit: 0})
        const caps = await value.getCapabilities()
        assert.equal(await realpath(caps.get('moz:profile')), await realpath(profilePath), 'Firefox must reuse the explicit profile rather than a clone')
        provenance.launches.push({browserVersion: caps.get('browserVersion'), profile: caps.get('moz:profile'), processId: caps.get('moz:processID'), marionettePort})
        await saveProvenance()
        return value
    } catch (error) {
        await value.quit().catch((quitError) => console.error(quitError))
        throw error
    }
}
const send = async (action, params) => {
    const response = await driver.executeAsyncScript((messageAction, messageParams, done) => {
        const runtime = window.chrome?.runtime ?? window.browser?.runtime
        runtime.sendMessage({action: messageAction, params: messageParams}, (result) => {
            const error = runtime.lastError
            if (error) { done({error: error.message || String(error)}); return }
            if (result && typeof result === 'object' && 'error' in result) { done({error: result.error}); return }
            done({value: result && typeof result === 'object' && 'result' in result ? result.result : result})
        })
    }, action, params)
    assert(!response.error, JSON.stringify(response.error))
    return response.value
}
const dictionaryState = async () => {
    const info = await send('getDictionaryInfo')
    assert.equal(info.length, 1)
    assert.equal(info[0].title, fixture.expectedTitle)
    assert.equal(info[0].revision, fixture.revision)
    assert.equal(info[0].storageHealth, 'available')
    const counts = await send('getDictionaryCounts', {dictionaryNames: [fixture.expectedTitle], getTotal: false})
    assert.equal(counts.counts[0].terms, fixture.termRows)
    assert.equal(counts.counts[0].media, fixture.mediaFiles)
    const storage = await send('debugDictionaryStorageState')
    assert.equal(storage.usesFallbackStorage, false)
    return {info, counts: counts.counts, countBoundary: 'Persisted summary counts returned by the public API; not a physical-record enumeration', storage}
}
const probe = async (terms) => {
    const results = []
    for (const term of terms) {
        const integrity = await helper.waitForBackendDictionaryContentIntegrity(driver, [fixture.expectedTitle], [term], 15000)
        assert.equal(integrity.ok, true, `Unreadable VNDB content for ${term}`)
        report.activeProbe = {term, probes: integrity.probes}
        const checkedSamples = integrity.probes.map((item) => {
            const debug = item.diagnostics?.debugLookupState
            const owner = debug?.offscreenState ? 'offscreenState' : debug?.workerState ? 'workerState' : debug?.localState ? 'localState' : 'direct'
            const state = owner === 'direct' ? debug : debug[owner]
            assert.equal(state?.ok, true, `Unavailable storage-owner content diagnostics for ${term}`)
            const store = state.termContentDiagnostics?.opfsStore ?? state.termContentStoreDebugState
            const totalLength = store?.totalLength
            assert(Number.isSafeInteger(totalLength) && totalLength > 0, `Missing content-store length for ${term}`)
            assert.equal(store.hasFileHandle, true, `Missing OPFS file handle for ${term}`)
            assert.equal(store.loadedForRead, true, `OPFS store not loaded for ${term}`)
            assert.equal(store.queuedWriteBytes, 0, `Unflushed content bytes for ${term}`)
            assert.equal(store.importReadOverlayBytes, 0, `Import memory overlay still active for ${term}`)
            assert(Array.isArray(state.rowSample) && state.rowSample.length > 0, `No persisted content samples for ${term}`)
            const rows = state.rowSample.filter((row) => row.dictionary === fixture.expectedTitle)
            assert(rows.length > 0, `No VNDB content samples for ${term}`)
            const checkedRows = []
            for (const row of rows) {
                const offset = row.rawEntryContentOffset
                const length = row.rawEntryContentLength
                const format = row.rawEntryContentDictName
                assert.equal(typeof format, 'string')
                const block = typeof getRawTermContentBlockCompressionDictName(format) !== 'undefined'
                const compact = format === RAW_TERM_CONTENT_DIRECT_BLOCK_DICT_NAME_PREFIX || format.startsWith(`${RAW_TERM_CONTENT_DIRECT_BLOCK_DICT_NAME_PREFIX}:`)
                const physicalLength = block ? (compact ? RAW_TERM_CONTENT_COMPACT_BLOCK_REFERENCE_BYTES : RAW_TERM_CONTENT_BLOCK_REFERENCE_BYTES) : length
                assert(Number.isSafeInteger(offset) && offset >= 0 && Number.isSafeInteger(length) && length > 0 && offset <= totalLength && physicalLength <= totalLength - offset, `Out-of-bounds physical content/reference for ${term}`)
                const decoded = row.decodedContentDebug
                assert.equal(decoded?.length, length, `Decoded content length mismatch for ${term}`)
                assert(Array.isArray(decoded.prefixBytes) && decoded.prefixBytes.length > 0, `Missing decoded content bytes for ${term}`)
                assert(typeof decoded.textPrefix === 'string' && decoded.textPrefix.length > 0 && !['<read-null>', '<read-failed>'].includes(decoded.textPrefix), `Unreadable decoded content for ${term}`)
                assert(Number.isSafeInteger(row.glossaryLength) && row.glossaryLength > 0, `Missing decoded glossary for ${term}`)
                checkedRows.push({dictionary: row.dictionary, format, offset, physicalLength, decodedLength: length, glossaryLength: row.glossaryLength, decoded})
            }
            return {owner, totalLength, rowSampleCount: rows.length, inBoundsRowCount: rows.length, outOfBoundsRowCount: 0, readableDecodedRowCount: checkedRows.length, rows: checkedRows}
        })
        assert(checkedSamples.length > 0, `No strict content probes for ${term}`)
        const lookup = await send('termsFind', {text: term, details: {primaryReading: '', matchType: 'exact', deinflect: false}, optionsContext: {index: 0}})
        assert.equal(lookup.originalTextLength, term.length)
        assert(lookup.dictionaryEntries.some((entry) => entry.definitions?.some((definition) => definition.dictionary === fixture.expectedTitle) && entry.headwords?.some((headword) => headword.term === term || headword.reading === term)), `Missing exact VNDB result: ${term}`)
        results.push({term, probes: integrity.probes, checkedSamples, resultCount: lookup.dictionaryEntries.length})
    }
    const canonical = results.map(({term, checkedSamples, resultCount}) => ({term, resultCount, checkedSamples}))
    return {results, sha256: createHash('sha256').update(JSON.stringify(canonical)).digest('hex')}
}
try {
    heartbeat.setActiveOperation('launch and install dedicated VNDB test profile')
    driver = await launch()
    const addonId = await driver.installAddon(packagePath, false)
    const extensionBaseUrl = await waitForExtensionBaseUrl(driver, addonId)
    await helper.navigateToExtensionPage(driver, `${extensionBaseUrl}/settings.html`, By.css('#dictionary-import-file-input'))
    assert.equal((await helper.purgeBackendDatabase(driver)).ok, true)
    heartbeat.setActiveOperation('real VNDB file input import')
    await helper.importDictionariesViaFileInput(driver, [archivePath])
    await helper.waitForImportWithPhaseScreenshots(driver, report, 'VNDB', '1 installed, 1 enabled', 900000)
    const debug = await helper.getLastImportDebug(driver)
    assert(debug && debug.hasResult === true)
    assert.equal(debug.errorCount, 0)
    assert.equal(debug.addSettingsErrorCount, 0)
    assert.equal(debug.usesFallbackStorage, false)
    report.importDebug = debug
    report.beforeRestart = await dictionaryState()
    await checkpoint('import and summary/storage checks passed')
    const terms = await helper.loadBenchmarkProbeTerms(archivePath)
    assert.equal(terms.length, 12)
    heartbeat.setActiveOperation('twelve content and exact lookup probes before restart')
    report.beforeProbes = await probe(terms)
    await checkpoint('strict pre-restart content and exact lookup probes passed')
    heartbeat.setActiveOperation('orderly Firefox shutdown and profile restart')
    await driver.quit()
    driver = null
    driver = await launch()
    assert.notEqual(provenance.launches[0].processId, provenance.launches[1].processId, 'Restart must create a new Firefox process')
    await helper.navigateToExtensionPage(driver, `${extensionBaseUrl}/settings.html`, By.css('#dictionary-import-file-input'))
    assert.equal(await driver.executeScript('return window.chrome?.runtime?.id ?? window.browser?.runtime?.id'), addonId)
    report.afterRestart = await dictionaryState()
    await checkpoint('post-restart summary/storage checks passed')
    heartbeat.setActiveOperation('twelve content and exact lookup probes after restart')
    report.afterProbes = await probe(terms)
    assert.equal(report.afterProbes.sha256, report.beforeProbes.sha256, 'Persisted VNDB content changed across browser restart')
    await checkpoint('strict post-restart content/exact lookup probes and matching digest passed; all-media verification follows')
    heartbeat.setActiveOperation('verify every persisted VNDB image against the pinned ZIP')
    let mediaBatches = 0
    report.media = await verifyBenchmarkMedia(archivePath, fixture, async (paths) => {
        const result = await send('getMedia', {targets: paths.map((mediaPath) => ({dictionary: fixture.expectedTitle, path: mediaPath}))})
        if (++mediaBatches % 32 === 0) { console.log(`[firefox-vndb] media batches read: ${mediaBatches}`) }
        return result
    }, 'all')
    assert.equal(await hashFile(packagePath), provenance.package.sha256)
    assert.equal(await hashFile(helperProvenance.helper), helperProvenance.helperSha256)
    assert.equal(await hashFile(provenance.streamingMediaValidator.path), provenance.streamingMediaValidator.sha256)
    for (const [relative, digest] of Object.entries(sourceHashes)) {
        assert.equal(await hashFile(path.join(root, relative)), digest, `Source identity changed: ${relative}`)
    }
    report.status = 'success'
    provenance.complete = true
} catch (error) {
    report.status = 'failure'
    report.failureReason = String(error?.stack || error)
    process.exitCode = 1
    console.error(error)
} finally {
    if (driver !== null) { await driver.quit().catch((error) => console.error(error)) }
    for (const descriptor of logDescriptors) { closeSync(descriptor) }
    await heartbeat.stop('finished')
    await writeFile(reportPath, JSON.stringify(report, null, 2) + '\n')
    await writeFile(path.join(directory, 'vndb-functional.html'), helper.renderReportHtml(report))
    provenance.finishedAt = new Date().toISOString()
    provenance.status = report.status
    provenance.reportSha256 = await hashFile(reportPath)
    await saveProvenance()
    console.log(`VNDB strict functional result: ${report.status}; ${reportPath}`)
}
