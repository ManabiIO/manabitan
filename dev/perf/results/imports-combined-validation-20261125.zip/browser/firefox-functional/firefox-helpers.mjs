/*
 * Copyright (C) 2023-2025  Yomitan Authors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-nocheck

import {createServer} from 'node:http';
import {execFile} from 'node:child_process';
import {openSync, closeSync} from 'node:fs';
import {access, mkdir, readFile, stat, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {promisify} from 'node:util';
import {fileURLToPath} from 'node:url';
import {Builder, Browser, By, Key, until} from 'selenium-webdriver';
import * as firefox from 'selenium-webdriver/firefox.js';
import {parseJson} from '/workspace/scratch/7b5a4ac440c8/combined/ext/js/core/json.js';
import {safePerformance} from '/workspace/scratch/7b5a4ac440c8/combined/ext/js/core/safe-performance.js';
import {writeCombinedTabbedReport} from '/workspace/scratch/7b5a4ac440c8/combined/test/e2e/report-tabs.js';
import {waitForExtensionBaseUrl} from '/workspace/scratch/7b5a4ac440c8/combined/test/e2e/firefox-extension-base-url.js';
import {getUnsupportedRuntimeSkipReason} from '/workspace/scratch/7b5a4ac440c8/combined/test/firefox/unsupported-runtime-classifier.js';

const dirname = path.dirname(fileURLToPath(import.meta.url));
const root = '/workspace/scratch/7b5a4ac440c8/combined';
const dictionaryCacheDir = path.join(root, 'builds', 'e2e-dictionary-cache');
const wagahaiHtmlPath = path.join(root, 'test', 'firefox', 'data', 'wagahai-neko.html');
const fallbackJmdictUrl = 'https://github.com/yomidevs/jmdict-yomitan/releases/latest/download/JMdict_english.zip';
const execFileAsync = promisify(execFile);
const expectedLookupDictionaries = ['Jitendex', 'JMdict'];
const extendedLookupDictionaries = ['Jitendex', 'JMdict', 'JMnedict'];
const lookupWords = ['暗記', '食う', '名前', '日本', '学生', '食べる', '見る', '言う', '行く', '水', '猫'];
const jmdictProbeTerms = ['打', '日本', '食べる', '見る', '水', '猫', '名前'];
const firefoxDevGeckoId = '{accbebce-862b-48a9-bb9a-1da9ad1f8702}';
const firefoxDevExtensionUuid = '6d1d0bf0-9b57-4ff8-9d93-64e13ae0f5da';
const focusedSecondaryDictionary = String(process.env.MANABITAN_FIREFOX_RECOMMENDED_SECONDARY || '').trim();
const focusedBaselineOnly = /^(1|true|yes)$/i.test(String(process.env.MANABITAN_FIREFOX_FOCUSED_BASELINE_ONLY || ''));
const existingProfileOnly = /^(1|true|yes)$/i.test(String(process.env.MANABITAN_FIREFOX_EXISTING_PROFILE_ONLY || ''));
const profileCycle = /^(1|true|yes)$/i.test(String(process.env.MANABITAN_FIREFOX_PROFILE_CYCLE || ''));
const firefoxHeadless = !/^(0|false|no)$/i.test(String(process.env.MANABITAN_FIREFOX_HEADLESS ?? '1'));
const scriptedHoverEnv = String(process.env.MANABITAN_FIREFOX_SCRIPTED_HOVER || '').trim();
const useScriptedHoverMotion = scriptedHoverEnv.length > 0 ?
    /^(1|true|yes)$/i.test(scriptedHoverEnv) :
    process.platform === 'darwin' && firefoxHeadless;

/**
 * @param {'JMdict'|'JMnedict'} name
 * @param {{baseUrl: string}} localServer
 * @returns {{name: string, description: string, homepage: string, downloadUrl: string}}
 */
function createFocusedRecommendedTermsDictionary(name, localServer) {
    switch (name) {
        case 'JMnedict':
            return {
                name: 'JMnedict',
                description: 'Real JMnedict from recommended dictionaries',
                homepage: '',
                downloadUrl: `${localServer.baseUrl}/dictionaries/jmnedict.zip`,
            };
        default:
            return {
                name: 'JMdict',
                description: 'Real JMdict from recommended dictionaries',
                homepage: '',
                downloadUrl: `${localServer.baseUrl}/dictionaries/jmdict-slow.zip`,
            };
    }
}

/**
 * @param {string} observedName
 * @param {string} expectedName
 * @returns {boolean}
 */
function matchesDictionaryName(observedName, expectedName) {
    const observed = String(observedName || '').trim();
    const expected = String(expectedName || '').trim();
    if (observed.length === 0 || expected.length === 0) { return false; }
    if (observed === expected) { return true; }
    if (observed.startsWith(`${expected} `) || observed.startsWith(`${expected}.`)) { return true; }
    return observed.includes(expected);
}

/**
 * @param {number} value
 * @returns {string}
 */
function formatMemoryMb(value) {
    return `${value.toFixed(1)} MB`;
}

/**
 * @param {{sampleCount: number, avgCpuPercent: number|null, peakCpuPercent: number|null, avgRssMb: number|null, peakRssMb: number|null}} resource
 * @returns {string}
 */
function formatResourceSummary(resource) {
    if (resource.sampleCount <= 0) {
        return 'resource-samples=unavailable';
    }
    return `resource-samples=${String(resource.sampleCount)} avgCpu=${resource.avgCpuPercent?.toFixed(1) ?? 'n/a'}% peakCpu=${resource.peakCpuPercent?.toFixed(1) ?? 'n/a'}% avgRss=${resource.avgRssMb !== null ? formatMemoryMb(resource.avgRssMb) : 'n/a'} peakRss=${resource.peakRssMb !== null ? formatMemoryMb(resource.peakRssMb) : 'n/a'}`;
}

/**
 * @param {number|null} firefoxPid
 * @returns {{stop: () => Promise<{sampleCount: number, avgCpuPercent: number|null, peakCpuPercent: number|null, avgRssMb: number|null, peakRssMb: number|null}>}}
 */
function startFirefoxResourceSampler(firefoxPid) {
    if (!(typeof firefoxPid === 'number' && Number.isFinite(firefoxPid) && firefoxPid > 0)) {
        return {
            stop: async () => ({
                sampleCount: 0,
                avgCpuPercent: null,
                peakCpuPercent: null,
                avgRssMb: null,
                peakRssMb: null,
            }),
        };
    }
    /** @type {Array<{cpuPercent: number, rssMb: number}>} */
    const samples = [];
    let running = false;
    const sampleOnce = async () => {
        if (running) { return; }
        running = true;
        try {
            const {stdout} = await execFileAsync('ps', ['-p', String(firefoxPid), '-o', '%cpu=,rss=']);
            const line = stdout.trim().split('\n').find((current) => current.trim().length > 0) || '';
            const [cpuRaw, rssRaw] = line.trim().split(/\s+/);
            const cpuPercent = Number(cpuRaw);
            const rssKb = Number(rssRaw);
            if (Number.isFinite(cpuPercent) && Number.isFinite(rssKb)) {
                samples.push({cpuPercent, rssMb: rssKb / 1024});
            }
        } catch (_) {
            // Process sampling is best-effort; ignore intermittent failures.
        } finally {
            running = false;
        }
    };
    const interval = setInterval(() => {
        void sampleOnce();
    }, 500);
    void sampleOnce();
    return {
        stop: async () => {
            clearInterval(interval);
            await sampleOnce();
            if (samples.length === 0) {
                return {
                    sampleCount: 0,
                    avgCpuPercent: null,
                    peakCpuPercent: null,
                    avgRssMb: null,
                    peakRssMb: null,
                };
            }
            const cpuValues = samples.map((sample) => sample.cpuPercent);
            const rssValues = samples.map((sample) => sample.rssMb);
            const avgCpuPercent = cpuValues.reduce((sum, value) => sum + value, 0) / cpuValues.length;
            const avgRssMb = rssValues.reduce((sum, value) => sum + value, 0) / rssValues.length;
            return {
                sampleCount: samples.length,
                avgCpuPercent,
                peakCpuPercent: Math.max(...cpuValues),
                avgRssMb,
                peakRssMb: Math.max(...rssValues),
            };
        },
    };
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} pageUrl
 * @param {By} readyLocator
 * @param {{attempts?: number, pageLoadTimeoutMs?: number, readyTimeoutMs?: number}|undefined} [options]
 * @returns {Promise<void>}
 */
async function navigateToExtensionPage(driver, pageUrl, readyLocator, options) {
    const attempts = Math.max(1, Number(options?.attempts ?? 3));
    const pageLoadTimeoutMs = Math.max(1_000, Number(options?.pageLoadTimeoutMs ?? 15_000));
    const readyTimeoutMs = Math.max(1_000, Number(options?.readyTimeoutMs ?? 30_000));
    const targetLocation = new URL(pageUrl);
    let lastError = null;
    const originalTimeouts = await driver.manage().getTimeouts();
    try {
        await driver.manage().setTimeouts({...originalTimeouts, pageLoad: pageLoadTimeoutMs});
        await driver.switchTo().defaultContent();
        if (/^(moz|chrome)-extension:$/.test(targetLocation.protocol)) {
            const originalWindowHandle = await driver.getWindowHandle();
            for (const windowHandle of await driver.getAllWindowHandles()) {
                try {
                    await driver.switchTo().window(windowHandle);
                    const candidateLocation = new URL(await driver.getCurrentUrl());
                    if (
                        candidateLocation.protocol === targetLocation.protocol &&
                        candidateLocation.host === targetLocation.host
                    ) {
                        break;
                    }
                } catch (_) {
                    // Try the next live window.
                }
            }
            try {
                const activeLocation = new URL(await driver.getCurrentUrl());
                if (
                    activeLocation.protocol !== targetLocation.protocol ||
                    activeLocation.host !== targetLocation.host
                ) {
                    await driver.switchTo().window(originalWindowHandle);
                }
            } catch (_) {
                await driver.switchTo().window(originalWindowHandle);
            }
        }
        for (let attempt = 1; attempt <= attempts; ++attempt) {
            if (!pageUrl.startsWith('moz-extension://')) {
                try {
                    await driver.get('about:blank');
                } catch (_) {
                    // Best-effort reset before the real navigation.
                }
            }
            try {
                await driver.get(pageUrl);
            } catch (error) {
                lastError = error;
                try {
                    const currentUrl = String(await driver.getCurrentUrl());
                    const currentLocation = new URL(currentUrl);
                    const targetLocation = new URL(pageUrl);
                    if (
                        currentLocation.protocol === 'moz-extension:' &&
                        currentLocation.protocol === targetLocation.protocol &&
                        currentLocation.host === targetLocation.host
                    ) {
                        await driver.executeScript('window.location.assign(arguments[0]);', pageUrl);
                    }
                } catch (_) {
                    // Preserve the original navigation error for the final failure.
                }
            }
            try {
                await driver.wait(async () => {
                    try {
                        const currentLocation = new URL(await driver.getCurrentUrl());
                        if (
                            currentLocation.protocol !== targetLocation.protocol ||
                            currentLocation.host !== targetLocation.host ||
                            currentLocation.pathname !== targetLocation.pathname
                        ) {
                            return false;
                        }
                        for (const [key, value] of targetLocation.searchParams) {
                            if (currentLocation.searchParams.get(key) !== value) {
                                return false;
                            }
                        }
                        return true;
                    } catch (_) {
                        return false;
                    }
                }, pageLoadTimeoutMs);
                await driver.wait(until.elementLocated(readyLocator), readyTimeoutMs);
                return;
            } catch (error) {
                lastError = error;
            }
        }
    } finally {
        await driver.manage().setTimeouts(originalTimeouts);
    }
    throw lastError ?? new Error(`Failed to navigate to extension page: ${pageUrl}`);
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<number|null>}
 */
async function getFirefoxProcessId(driver) {
    try {
        const capabilities = await driver.getCapabilities();

        const rawPid = capabilities.get('moz:processID');
        const processId = Number(rawPid);
        if (Number.isFinite(processId) && processId > 0) {
            return processId;
        }
    } catch (_) {
        // Fallback below.
    }
    try {
        const {stdout} = await execFileAsync('pgrep', ['-n', 'firefox']);
        const processId = Number(stdout.trim());
        if (Number.isFinite(processId) && processId > 0) {
            return processId;
        }
    } catch (_) {
        // No PID fallback available.
    }
    return null;
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<void>}
 */
async function ensurePageProfiler(driver) {
    await driver.executeScript(`
        window.manabitanPerformanceInstrumentationEnabled = true;
        if (!window.__manabitanE2EPageProfiler) {
            const state = {
                longTasks: [],
                phaseLongTaskStart: 0,
                phaseMeasureStart: 0,
            };
            try {
                const observer = new PerformanceObserver((list) => {
                    for (const entry of list.getEntries()) {
                        state.longTasks.push({
                            name: String(entry.name || 'longtask'),
                            duration: Number(entry.duration || 0),
                            startTime: Number(entry.startTime || 0),
                        });
                    }
                });
                observer.observe({entryTypes: ['longtask']});
                state.observer = observer;
            } catch (_) {
                // LongTask observer is best-effort.
            }
            window.__manabitanE2EPageProfiler = state;
        }
    `);
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<void>}
 */
async function beginPageProfilePhase(driver) {
    await driver.executeScript(`
        const state = window.__manabitanE2EPageProfiler;
        if (!state || typeof state !== 'object') { return; }
        state.phaseLongTaskStart = Array.isArray(state.longTasks) ? state.longTasks.length : 0;
        try {
            state.phaseMeasureStart = performance.getEntriesByType('measure').length;
        } catch (_) {
            state.phaseMeasureStart = 0;
        }
    `);
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<{longTaskCount: number, longTaskTotalMs: number, longTaskPeakMs: number, topMeasures: Array<{name: string, totalMs: number}>, topLongTasks: Array<{name: string, duration: number}>}>}
 */
async function endPageProfilePhase(driver) {
    // Selenium executeScript return value is untyped (`any`).

    const summary = await driver.executeScript(`
        const state = window.__manabitanE2EPageProfiler;
        if (!state || typeof state !== 'object') {
            return {longTaskCount: 0, longTaskTotalMs: 0, longTaskPeakMs: 0, topMeasures: [], topLongTasks: []};
        }
        const longTaskStart = Number(state.phaseLongTaskStart || 0);
        const phaseLongTasks = Array.isArray(state.longTasks) ? state.longTasks.slice(longTaskStart) : [];
        const longTaskCount = phaseLongTasks.length;
        const longTaskTotalMs = phaseLongTasks.reduce((sum, entry) => sum + Number(entry.duration || 0), 0);
        const longTaskPeakMs = phaseLongTasks.reduce((max, entry) => Math.max(max, Number(entry.duration || 0)), 0);
        const topLongTasks = phaseLongTasks
            .slice()
            .sort((a, b) => Number(b.duration || 0) - Number(a.duration || 0))
            .slice(0, 5)
            .map((entry) => ({name: String(entry.name || 'longtask'), duration: Number(entry.duration || 0)}));
        let topMeasures = [];
        try {
            const measureStart = Number(state.phaseMeasureStart || 0);
            const measures = performance.getEntriesByType('measure').slice(measureStart);
            const totals = new Map();
            for (const entry of measures) {
                const name = String(entry.name || 'measure');
                totals.set(name, (totals.get(name) || 0) + Number(entry.duration || 0));
            }
            topMeasures = [...totals.entries()]
                .sort((a, b) => Number(b[1]) - Number(a[1]))
                .slice(0, 5)
                .map(([name, totalMs]) => ({name: String(name), totalMs: Number(totalMs)}));
        } catch (_) {
            topMeasures = [];
        }
        return {longTaskCount, longTaskTotalMs, longTaskPeakMs, topMeasures, topLongTasks};
    `);
    if (typeof summary === 'object' && summary !== null && !Array.isArray(summary)) {
        const normalized = /** @type {Record<string, unknown>} */ (summary);
        const normalizeTopMeasureEntries = (entries) => {
            if (!Array.isArray(entries)) { return []; }
            return entries.map((entry) => {
                const record = (typeof entry === 'object' && entry !== null && !Array.isArray(entry)) ? /** @type {Record<string, unknown>} */ (entry) : {};
                const rawName = record.name;
                const name = (typeof rawName === 'string') ? rawName : '';
                return {
                    name,
                    totalMs: Number(record.totalMs || 0),
                };
            });
        };
        const normalizeTopLongTaskEntries = (entries) => {
            if (!Array.isArray(entries)) { return []; }
            return entries.map((entry) => {
                const record = (typeof entry === 'object' && entry !== null && !Array.isArray(entry)) ? /** @type {Record<string, unknown>} */ (entry) : {};
                const rawName = record.name;
                const name = (typeof rawName === 'string') ? rawName : '';
                return {
                    name,
                    duration: Number(record.duration || 0),
                };
            });
        };
        return {
            longTaskCount: Number(normalized.longTaskCount || 0),
            longTaskTotalMs: Number(normalized.longTaskTotalMs || 0),
            longTaskPeakMs: Number(normalized.longTaskPeakMs || 0),
            topMeasures: normalizeTopMeasureEntries(normalized.topMeasures),
            topLongTasks: normalizeTopLongTaskEntries(normalized.topLongTasks),
        };
    }
    return {longTaskCount: 0, longTaskTotalMs: 0, longTaskPeakMs: 0, topMeasures: [], topLongTasks: []};
}

/**
 * @returns {Promise<{jitendexUrl: string, jmnedictUrl: string, jmdictUrl: string}>}
 */
async function loadRecommendedDictionaryUrls() {
    const recommendedPath = path.join(root, 'ext', 'data', 'recommended-dictionaries.json');
    const raw = await readFile(recommendedPath, 'utf8');
    const recommended = /** @type {Record<string, unknown>} */ (parseJson(raw));
    const ja = /** @type {Record<string, unknown>|undefined} */ (recommended.ja);
    const terms = Array.isArray(ja?.terms) ? ja.terms : [];
    const findDownloadUrl = (name) => {
        for (const item of terms) {
            if (!(item && typeof item === 'object')) { continue; }
            const dictionaryName = String(item.name || '');
            if (dictionaryName !== name) { continue; }
            const url = String(item.downloadUrl || '');
            if (url.length > 0) { return url; }
        }
        return '';
    };
    const jitendexUrl = findDownloadUrl('Jitendex');
    const jmnedictUrl = findDownloadUrl('JMnedict');
    const jmdictUrl = findDownloadUrl('JMdict') || fallbackJmdictUrl;
    if (jitendexUrl.length === 0 || jmnedictUrl.length === 0 || jmdictUrl.length === 0) {
        fail(`Unable to resolve recommended dictionary URLs from ext/data/recommended-dictionaries.json (jitendex="${jitendexUrl}", jmnedict="${jmnedictUrl}", jmdict="${jmdictUrl}")`);
    }
    return {jitendexUrl, jmnedictUrl, jmdictUrl};
}

/**
 * @param {string} url
 * @param {string} outputPath
 * @returns {Promise<void>}
 */
async function ensureCachedDownload(url, outputPath) {
    try {
        await access(outputPath);
        return;
    } catch (_) {
        // Download below when cache file is missing.
    }
    const response = await fetch(url);
    if (!response.ok) {
        fail(`Failed to download dictionary ${url}: ${String(response.status)} ${response.statusText}`);
    }
    const bytes = Buffer.from(await response.arrayBuffer());
    if (bytes.byteLength === 0) {
        fail(`Downloaded empty dictionary archive from ${url}`);
    }
    await writeFile(outputPath, bytes);
}

/**
 * @returns {Promise<{jitendexPath: string, jmnedictPath: string, jmdictPath: string, jitendexUrl: string, jmnedictUrl: string, jmdictUrl: string}>}
 */
async function ensureRealDictionaryCache() {
    await mkdir(dictionaryCacheDir, {recursive: true});
    const {jitendexUrl, jmnedictUrl, jmdictUrl} = await loadRecommendedDictionaryUrls();
    const jitendexPath = path.join(dictionaryCacheDir, 'jitendex-yomitan.zip');
    const jmnedictPath = path.join(dictionaryCacheDir, 'JMnedict.zip');
    const jmdictPath = path.join(dictionaryCacheDir, 'JMdict.zip');
    await ensureCachedDownload(jitendexUrl, jitendexPath);
    await ensureCachedDownload(jmnedictUrl, jmnedictPath);
    await ensureCachedDownload(jmdictUrl, jmdictPath);
    return {jitendexPath, jmnedictPath, jmdictPath, jitendexUrl, jmnedictUrl, jmdictUrl};
}

/**
 * @param {string} zipPath
 * @param {number} maxTerms
 * @returns {Promise<string[]>}
 */
async function loadDictionaryProbeTermsFromArchive(zipPath, maxTerms = 80) {
    const maxTermsSafe = Number.isFinite(maxTerms) ? Math.max(8, Math.trunc(maxTerms)) : 80;
    /** @type {string[]} */
    const terms = [];
    const seen = new Set();
    const hasJapanese = (value) => /[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]/u.test(value);
    for (let bankIndex = 1; bankIndex <= 12 && terms.length < maxTermsSafe; ++bankIndex) {
        let stdout = '';
        try {
            ({stdout} = await execFileAsync('unzip', ['-p', zipPath, `term_bank_${String(bankIndex)}.json`], {
                maxBuffer: 32 * 1024 * 1024,
            }));
        } catch (_) {
            continue;
        }
        let rows;
        try {
            rows = parseJson(stdout);
        } catch (_) {
            continue;
        }
        if (!Array.isArray(rows)) {
            continue;
        }
        for (const row of rows) {
            const term = String(Array.isArray(row) ? row[0] : '').trim();
            if (term.length === 0 || term.length > 20 || !hasJapanese(term) || seen.has(term)) {
                continue;
            }
            seen.add(term);
            terms.push(term);
            if (terms.length >= maxTermsSafe) {
                break;
            }
        }
    }
    return terms;
}

/**
 * @param {{jitendexPath: string, jmnedictPath: string, jmdictPath: string}} paths
 * @returns {Promise<{baseUrl: string, close: () => Promise<void>}>}
 */
async function startE2ELocalServer(paths) {
    const wagahaiHtml = await readFile(wagahaiHtmlPath);
    const jitendexZip = await readFile(paths.jitendexPath);
    const jmnedictZip = await readFile(paths.jmnedictPath);
    const jmdictZip = await readFile(paths.jmdictPath);
    /**
     * @param {import('node:http').ServerResponse} response
     * @param {Buffer} body
     * @returns {Promise<void>}
     */
    const writeSlowZipResponse = async (response, body) => {
        const chunkCount = 6;
        const chunkSize = Math.max(1, Math.ceil(body.byteLength / chunkCount));
        for (let offset = 0; offset < body.byteLength; offset += chunkSize) {
            response.write(body.subarray(offset, Math.min(body.byteLength, offset + chunkSize)));
            await new Promise((resolve) => {
                setTimeout(resolve, 350);
            });
        }
        response.end();
    };
    const server = createServer((request, response) => {
        const requestUrl = request.url || '/';
        const headers = {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, OPTIONS',
        };
        if (request.method === 'OPTIONS') {
            response.writeHead(204, headers);
            response.end();
            return;
        }
        if (requestUrl === '/dictionaries/jitendex.zip') {
            response.writeHead(200, {
                ...headers,
                'Content-Type': 'application/zip',
                'Content-Length': String(jitendexZip.byteLength),
            });
            response.end(jitendexZip);
            return;
        }
        if (requestUrl === '/dictionaries/jitendex-slow.zip') {
            response.writeHead(200, {
                ...headers,
                'Content-Type': 'application/zip',
                'Content-Length': String(jitendexZip.byteLength),
            });
            void writeSlowZipResponse(response, jitendexZip);
            return;
        }
        if (requestUrl === '/dictionaries/jmdict.zip') {
            response.writeHead(200, {
                ...headers,
                'Content-Type': 'application/zip',
                'Content-Length': String(jmdictZip.byteLength),
            });
            response.end(jmdictZip);
            return;
        }
        if (requestUrl === '/dictionaries/jmnedict.zip') {
            response.writeHead(200, {
                ...headers,
                'Content-Type': 'application/zip',
                'Content-Length': String(jmnedictZip.byteLength),
            });
            response.end(jmnedictZip);
            return;
        }
        if (requestUrl === '/dictionaries/jmdict-slow.zip') {
            response.writeHead(200, {
                ...headers,
                'Content-Type': 'application/zip',
                'Content-Length': String(jmdictZip.byteLength),
            });
            void writeSlowZipResponse(response, jmdictZip);
            return;
        }
        if (requestUrl === '/wagahai-neko.html') {
            response.writeHead(200, {
                ...headers,
                'Content-Type': 'text/html; charset=utf-8',
                'Content-Length': String(wagahaiHtml.byteLength),
            });
            response.end(wagahaiHtml);
            return;
        }
        response.writeHead(404, {
            ...headers,
            'Content-Type': 'text/plain; charset=utf-8',
        });
        response.end('Not found');
    });
    const address = /** @type {import('node:net').AddressInfo|string|null} */ (await new Promise((resolve, reject) => {
        server.once('error', reject);
        server.listen(0, '127.0.0.1', () => resolve(/** @type {import('node:net').AddressInfo|string|null} */ (server.address())));
    }));
    if (!(address && typeof address === 'object' && typeof address.port === 'number')) {
        fail('Failed to bind local E2E HTTP server');
    }
    return {
        baseUrl: `http://127.0.0.1:${String(address.port)}`,
        close: async () => {
            await new Promise((resolve, reject) => {
                server.close((error) => {
                    if (error) {
                        reject(error);
                        return;
                    }
                    resolve();
                });
            });
        },
    };
}

/**
 * @param {string} message
 * @throws {Error}
 */
function fail(message) {
    throw new Error(`[firefox-e2e] ${message}`);
}

/**
 * @param {unknown} value
 * @returns {string}
 */
function errorMessage(value) {
    return value instanceof Error ? value.message : String(value);
}

/**
 * @param {unknown} value
 * @returns {boolean}
 */
function isDiscardedBrowsingContextError(value) {
    const message = errorMessage(value);
    return (
        message.includes('Browsing context has been discarded') ||
        message.includes('Failed to decode response from marionette') ||
        message.includes('Tried to run command without establishing a connection')
    );
}

/**
 * @param {unknown} value
 * @returns {boolean}
 */
function isIgnorableDriverQuitError(value) {
    const message = errorMessage(value);
    return (
        message.includes('Tried to run command without establishing a connection') ||
        message.includes('Failed to decode response from marionette')
    );
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} extensionBaseUrl
 * @param {string} [query]
 * @returns {Promise<void>}
 */
async function recoverExtensionSearchContext(driver, extensionBaseUrl, query = '暗記') {
    await navigateToExtensionPage(
        driver,
        `${extensionBaseUrl}/search.html?query=${encodeURIComponent(query)}&type=terms&wildcards=off`,
        By.css('#search-textbox'),
    );
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} extensionBaseUrl
 * @returns {Promise<void>}
 */
async function reloadExtensionRuntime(driver, extensionBaseUrl) {
    try {
        await driver.executeScript(`
            try {
                chrome.runtime.reload();
            } catch (_) {
                // Ignore runtime access failures; page context may already be tearing down.
            }
        `);
    } catch (_) {
        // Expected when the current extension context is discarded during reload.
    }
    await driver.sleep(2_000);
    await waitForExtensionBaseUrl(driver, firefoxDevExtensionUuid);
    await navigateToExtensionPage(
        driver,
        `${extensionBaseUrl}/settings.html`,
        By.css('#dictionary-import-file-input'),
        {attempts: 3, pageLoadTimeoutMs: 15_000, readyTimeoutMs: 30_000},
    );
}

/**
 * @param {string | undefined} value
 * @param {boolean} defaultValue
 * @returns {boolean}
 */
function parseBooleanEnv(value, defaultValue) {
    if (typeof value !== 'string') {
        return defaultValue;
    }
    const normalized = value.trim().toLowerCase();
    if (normalized === '1' || normalized === 'true' || normalized === 'yes' || normalized === 'on') {
        return true;
    }
    if (normalized === '0' || normalized === 'false' || normalized === 'no' || normalized === 'off') {
        return false;
    }
    return defaultValue;
}

const strictUnsupportedRuntime = parseBooleanEnv(
    process.env.MANABITAN_E2E_STRICT_RUNTIME,
    parseBooleanEnv(process.env.CI, false),
);


/**
 * @param {unknown} runtimeDiagnostics
 * @returns {boolean}
 */
function isOpfsRuntimeAvailable(runtimeDiagnostics) {
    if (!(runtimeDiagnostics && typeof runtimeDiagnostics === 'object')) {
        return false;
    }
    const hasStorageDir = runtimeDiagnostics.hasStorageGetDirectory === true;
    const workerRuntimeContext = (
        runtimeDiagnostics.openStorageDiagnostics &&
        typeof runtimeDiagnostics.openStorageDiagnostics === 'object' &&
        !Array.isArray(runtimeDiagnostics.openStorageDiagnostics) &&
        runtimeDiagnostics.openStorageDiagnostics.runtimeContext &&
        typeof runtimeDiagnostics.openStorageDiagnostics.runtimeContext === 'object' &&
        !Array.isArray(runtimeDiagnostics.openStorageDiagnostics.runtimeContext)
    ) ?
runtimeDiagnostics.openStorageDiagnostics.runtimeContext :
null;
    const hasSyncAccessHandle = (
        runtimeDiagnostics.hasCreateSyncAccessHandle === true ||
        workerRuntimeContext?.hasCreateSyncAccessHandle === true
    );
    const hasSahpoolVfs = runtimeDiagnostics.hasOpfsSahpoolVfs === true;
    const installResult = typeof runtimeDiagnostics.opfsSahpoolInstallResult === 'string' ? runtimeDiagnostics.opfsSahpoolInstallResult : null;
    const mode = typeof runtimeDiagnostics.openStorageMode === 'string' ? runtimeDiagnostics.openStorageMode : null;
    return hasStorageDir && hasSyncAccessHandle && hasSahpoolVfs && installResult !== 'failed' && mode === 'opfs-sahpool';
}

/**
 * @param {unknown} value
 * @returns {Record<string, unknown>|null}
 */
function asRecordOrNull(value) {
    return (
        typeof value === 'object' &&
        value !== null &&
        !Array.isArray(value)
    ) ?
        /** @type {Record<string, unknown>} */ (value) :
        null;
}

/**
 * @param {string} value
 * @returns {string}
 */
function escapeHtml(value) {
    return value
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
}

/**
 * @param {number} valueMs
 * @returns {string}
 */
function formatDuration(valueMs) {
    return `${valueMs.toFixed(1)} ms`;
}

/**
 * @typedef {{
 *   name: string,
 *   details: string,
 *   startMs: number,
 *   endMs: number,
 *   durationMs: number,
 *   screenshotBase64: string,
 *   screenshotMimeType: string
 * }} ReportPhase
 */

/**
 * @typedef {{
 *   startedAtIso: string,
 *   status: 'running'|'success'|'success-with-skips'|'failure',
 *   failureReason: string,
 *   skippedVerification: boolean,
 *   skipReason: string,
 *   runtimeDiagnostics: Record<string, unknown>|null,
 *   artifacts: Record<string, string>|null,
 *   phases: ReportPhase[]
 * }} E2EReport
 */

/**
 * @returns {E2EReport}
 */
function createReport() {
    return {
        startedAtIso: new Date().toISOString(),
        status: 'running',
        failureReason: '',
        skippedVerification: false,
        skipReason: '',
        runtimeDiagnostics: null,
        artifacts: null,
        phases: [],
    };
}

/**
 * @param {E2EReport} report
 * @param {Record<string, unknown>} [extra]
 * @returns {{startedAtIso: string, status: E2EReport['status'], failureReason: string, skippedVerification: boolean, skipReason: string, runtimeDiagnostics: Record<string, unknown>|null, artifacts: Record<string, string>|null, phaseCount: number, phases: Array<{name: string, details: string, durationMs: number}>} & Record<string, unknown>}
 */
function createReportJsonSummary(report, extra = {}) {
    return {
        startedAtIso: report.startedAtIso,
        status: report.status,
        failureReason: report.failureReason,
        skippedVerification: report.skippedVerification,
        skipReason: report.skipReason,
        runtimeDiagnostics: report.runtimeDiagnostics,
        artifacts: report.artifacts,
        phaseCount: Array.isArray(report.phases) ? report.phases.length : 0,
        phases: (Array.isArray(report.phases) ? report.phases : []).map((phase) => ({
            name: phase.name,
            details: phase.details,
            durationMs: phase.durationMs,
        })),
        ...extra,
    };
}

/**
 * @param {string} reportJsonPath
 * @returns {{heartbeatJsonPath: string, geckodriverLogPath: string, crashDumpDir: string}}
 */
function createDiagnosticsArtifactPaths(reportJsonPath) {
    return {
        heartbeatJsonPath: reportJsonPath.replace(/\.json$/i, '-live.json'),
        geckodriverLogPath: reportJsonPath.replace(/\.json$/i, '-geckodriver.log'),
        crashDumpDir: reportJsonPath.replace(/\.json$/i, '-crash'),
    };
}

/**
 * @param {E2EReport} report
 * @param {string} snapshotPath
 * @param {Record<string, unknown>} [extra]
 * @returns {Promise<void>}
 */
async function writeReportSnapshot(report, snapshotPath, extra = {}) {
    await mkdir(path.dirname(snapshotPath), {recursive: true});
    await writeFile(snapshotPath, JSON.stringify(createReportJsonSummary(report, extra), null, 2), 'utf8');
}

/**
 * @param {E2EReport} report
 * @param {string} heartbeatJsonPath
 * @returns {{setActiveOperation: (value: string) => void, flush: (reason?: string) => Promise<void>, stop: (reason?: string) => Promise<void>}}
 */
function startHeartbeat(report, heartbeatJsonPath) {
    let activeOperation = 'initializing';
    let writeInFlight = false;
    const startedAtEpochMs = Number.isFinite(Date.parse(report.startedAtIso)) ? Date.parse(report.startedAtIso) : Date.now();
    const flush = async (reason = 'heartbeat') => {
        if (writeInFlight) { return; }
        writeInFlight = true;
        try {
            const lastPhase = report.phases.at(-1) ?? null;
            const nowEpochMs = Date.now();
            const nowMonotonicMs = safePerformance.now();
            const lastPhaseAgeMs = lastPhase ? Math.max(0, nowMonotonicMs - lastPhase.endMs) : null;
            const lastPhaseEndIso = lastPhase ? new Date(startedAtEpochMs + lastPhase.endMs).toISOString() : null;
            console.log(`[firefox-e2e] heartbeat: status=${report.status} phases=${String(report.phases.length)} active=${activeOperation} lastPhase=${lastPhase ? lastPhase.name : 'none'} lastPhaseAgeMs=${lastPhaseAgeMs !== null ? String(lastPhaseAgeMs) : 'n/a'} reason=${reason}`);
            await writeReportSnapshot(report, heartbeatJsonPath, {
                heartbeatReason: reason,
                heartbeatAtIso: new Date(nowEpochMs).toISOString(),
                activeOperation,
                lastPhaseName: lastPhase ? lastPhase.name : null,
                lastPhaseEndIso,
                lastPhaseAgeMs,
            });
        } catch (e) {
            console.error(`[firefox-e2e] Failed to write heartbeat snapshot: ${errorMessage(e)}`);
        } finally {
            writeInFlight = false;
        }
    };
    const interval = setInterval(() => {
        void flush('interval');
    }, 10_000);
    void flush('start');
    return {
        setActiveOperation(value) {
            activeOperation = value;
        },
        async flush(reason = 'manual') {
            await flush(reason);
        },
        async stop(reason = 'stop') {
            clearInterval(interval);
            await flush(reason);
        },
    };
}

/**
 * @param {E2EReport} report
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} name
 * @param {string} details
 * @param {number} startMs
 * @param {number} endMs
 * @returns {Promise<void>}
 */
async function addReportPhase(report, driver, name, details, startMs, endMs) {
    console.log(`[firefox-e2e] phase: ${name} (${formatDuration(Math.max(0, endMs - startMs))})`);
    let screenshotBase64 = '';
    try {
        screenshotBase64 = String(await driver.takeScreenshot());
    } catch (error) {
        if (!isDiscardedBrowsingContextError(error)) {
            throw error;
        }
    }
    report.phases.push({
        name,
        details,
        startMs,
        endMs,
        durationMs: Math.max(0, endMs - startMs),
        screenshotBase64,
        screenshotMimeType: 'image/png',
    });
}

/**
 * @param {E2EReport} report
 * @returns {string}
 */
function renderReportHtml(report) {
    const isFailure = report.status === 'failure';
    const isWarning = report.status === 'success-with-skips';
    let failureBanner = '';
    let warningBanner = '';
    if (isFailure) {
        failureBanner = `
  <div class="failure-banner">
    <div class="failure-banner-title">FAILED</div>
    <div class="failure-banner-reason">${escapeHtml(report.failureReason || 'Unknown failure')}</div>
  </div>`;
    }
    if (isWarning) {
        warningBanner = `
  <div class="warning-banner">
    <div class="warning-banner-title">SKIPPED</div>
    <div class="warning-banner-reason">${escapeHtml(report.skipReason || 'Verification skipped in unsupported local runtime')}</div>
  </div>`;
    }
    const rows = report.phases.map((phase, index) => {
        const imageUrl = `data:${phase.screenshotMimeType};base64,${phase.screenshotBase64}`;
        return `
            <section class="phase">
                <h2>Phase ${index + 1}: ${escapeHtml(phase.name)}</h2>
                <p><strong>Duration:</strong> ${escapeHtml(formatDuration(phase.durationMs))}</p>
                <p><strong>Details:</strong> ${escapeHtml(phase.details)}</p>
                <img src="${imageUrl}" alt="${escapeHtml(phase.name)} screenshot">
            </section>
        `;
    }).join('\n');

    return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Manabitan Firefox E2E Import Report</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, Segoe UI, sans-serif; margin: 24px; color: #1d1d1f; }
    h1 { margin-bottom: 8px; }
    .meta { margin-bottom: 24px; padding: 12px 14px; border-radius: 8px; background: #f5f7fa; }
    .failure-banner { margin: 0 0 18px; padding: 14px 16px; border-radius: 10px; border: 2px solid #ef4444; background: #fee2e2; color: #991b1b; }
    .failure-banner-title { font-size: 26px; font-weight: 800; letter-spacing: 0.3px; margin-bottom: 4px; }
    .failure-banner-reason { font-size: 14px; font-weight: 600; white-space: pre-wrap; }
    .warning-banner { margin: 0 0 18px; padding: 14px 16px; border-radius: 10px; border: 2px solid #f59e0b; background: #fef3c7; color: #92400e; }
    .warning-banner-title { font-size: 26px; font-weight: 800; letter-spacing: 0.3px; margin-bottom: 4px; }
    .warning-banner-reason { font-size: 14px; font-weight: 600; white-space: pre-wrap; }
    .phase { margin: 0 0 28px; padding: 14px; border: 1px solid #d8dee4; border-radius: 10px; }
    .phase h2 { margin: 0 0 8px; font-size: 18px; }
    .phase p { margin: 6px 0; }
    img { margin-top: 10px; max-width: 100%; border: 1px solid #d8dee4; border-radius: 8px; }
  </style>
</head>
<body>
  <h1>Manabitan Firefox E2E Import Report</h1>
  ${failureBanner}
  ${warningBanner}
  <div class="meta">
    <div><strong>Started:</strong> ${escapeHtml(report.startedAtIso)}</div>
    <div><strong>Status:</strong> ${escapeHtml(report.status)}</div>
    <div><strong>Failure reason:</strong> ${escapeHtml(report.failureReason || 'none')}</div>
    <div><strong>Skip reason:</strong> ${escapeHtml(report.skipReason || 'none')}</div>
    <div><strong>Recorded phases:</strong> ${report.phases.length}</div>
    <div><strong>Artifacts:</strong> ${escapeHtml(report.artifacts ? JSON.stringify(report.artifacts) : 'none')}</div>
  </div>
  ${rows}
</body>
</html>`;
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<string>}
 */
async function getImportProgressLabel(driver) {
    // Selenium executeScript return value is untyped (`any`).

    const value = await driver.executeScript(`
        const selectors = [
            '#recommended-dictionaries-modal .dictionary-import-progress',
            '#dictionaries-modal .dictionary-import-progress'
        ];
        for (const selector of selectors) {
            const container = document.querySelector(selector);
            if (
                !(container instanceof HTMLElement) ||
                container.hidden ||
                container.closest('[hidden]') !== null
            ) { continue; }
            const label = container.querySelector('.progress-info');
            if (!(label instanceof HTMLElement)) { continue; }
            const text = (label.textContent || '').trim();
            if (text.length > 0) { return text; }
        }
        return '';
    `);
    return typeof value === 'string' ? value : '';
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<string>}
 */
async function getDictionaryCountsText(driver) {
    const installCount = String(await (await driver.findElement(By.css('#dictionary-install-count'))).getText());
    const enabledCount = String(await (await driver.findElement(By.css('#dictionary-enabled-count'))).getText());
    return `${installCount} installed, ${enabledCount} enabled`;
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<string>}
 */
async function getDictionaryErrorText(driver) {
    // Selenium executeScript return value is untyped (`any`).

    const value = await driver.executeScript(`
        const node = document.querySelector('#dictionary-error');
        if (!(node instanceof HTMLElement) || node.hidden) { return ''; }
        return (node.textContent || '').trim();
    `);
    return typeof value === 'string' ? value : '';
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<Record<string, unknown>|null>}
 */
async function getLastImportDebug(driver) {
    // Selenium executeScript return value is untyped (`any`).

    const value = await driver.executeScript('return window.__manabitanLastImportDebug ?? null;');
    if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
        return /** @type {Record<string, unknown>} */ (value);
    }
    return null;
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<string[]>}
 */
async function getMockSeenUrls(driver) {
    // Selenium executeScript return value is untyped (`any`).

    const value = await driver.executeScript('return Array.isArray(window.__manabitanMockSeenUrls) ? window.__manabitanMockSeenUrls.slice(-8) : [];');
    return Array.isArray(value) ? value.map(String) : [];
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {E2EReport} report
 * @param {string} dictionaryName
 * @param {string} expectedCounts
 * @param {number} timeoutMs
 * @param {Record<string, unknown>|null} [previousImportDebug]
 * @returns {Promise<void>}
 */
async function waitForImportWithPhaseScreenshots(driver, report, dictionaryName, expectedCounts, timeoutMs, previousImportDebug = null) {
    const importStartTime = safePerformance.now();
    let previousLabel = '';
    let previousLabelStart = importStartTime;
    const deadline = importStartTime + timeoutMs;
    let sawStepText = false;
    let clearedAfterStep = false;
    let emptySince = null;
    // A fresh import-debug snapshot is authoritative completion evidence. Keep
    // only a short UI-settle window so report totals do not include a fixed 2s.
    const emptyStabilityMs = 250;
    let lastCountsText = '';
    const previousImportDebugJson = previousImportDebug === null ? null : JSON.stringify(previousImportDebug);

    const getCompletedImportDebug = async () => {
        const importDebug = await getLastImportDebug(driver);
        if (previousImportDebugJson !== null && JSON.stringify(importDebug) === previousImportDebugJson) {
            return {importDebug, completed: false};
        }
        return {importDebug, completed: importDebug !== null};
    };

    while (safePerformance.now() < deadline) {
        const now = safePerformance.now();
        const immediateError = await getDictionaryErrorText(driver);
        if (immediateError.length > 0) {
            fail(`${dictionaryName} import reported error before completion: ${immediateError}`);
        }
        const currentLabel = await getImportProgressLabel(driver);
        lastCountsText = await getDictionaryCountsText(driver);
        if (currentLabel.includes('Step ')) {
            sawStepText = true;
            emptySince = null;
        }
        if (currentLabel.length > 0 && currentLabel !== previousLabel) {
            if (previousLabel.length > 0) {
                await addReportPhase(
                    report,
                    driver,
                    `${dictionaryName}: ${previousLabel}`,
                    `${dictionaryName} import progress phase`,
                    previousLabelStart,
                    now,
                );
            }
            previousLabel = currentLabel;
            previousLabelStart = now;
        }

        if (sawStepText && currentLabel.length === 0) {
            emptySince ??= now;
            if ((now - emptySince) >= emptyStabilityMs) {
                clearedAfterStep = true;
                const {importDebug, completed} = await getCompletedImportDebug();
                if (!completed) {
                    const storageDiagnostics = await getBackendStorageDiagnostics(driver);
                    fail(
                        `${dictionaryName} progress cleared without a new completed import snapshot. ` +
                        `counts=${lastCountsText} dictionary-error="${await getDictionaryErrorText(driver)}" ` +
                        `import-debug=${JSON.stringify(importDebug)} storage=${summarizeBackendStorageDiagnostics(storageDiagnostics)}`,
                    );
                }
                if (previousLabel.length > 0) {
                    await addReportPhase(
                        report,
                        driver,
                        `${dictionaryName}: ${previousLabel}`,
                        `${dictionaryName} import progress phase`,
                        previousLabelStart,
                        now,
                    );
                }
                await addReportPhase(
                    report,
                    driver,
                    `${dictionaryName}: total import`,
                    `Progress text stayed empty for ${String(emptyStabilityMs)}ms after Step text appeared. Expected counts target for this phase: ${expectedCounts}. Current counts=${await getDictionaryCountsText(driver)} dictionary-error="${await getDictionaryErrorText(driver)}" import-debug=${JSON.stringify(await getLastImportDebug(driver))} mock-urls=${JSON.stringify(await getMockSeenUrls(driver))}`,
                    importStartTime,
                    now,
                );
                const importErrorText = await getDictionaryErrorText(driver);
                if (importErrorText.length > 0) {
                    fail(`${dictionaryName} import reported error: ${importErrorText}`);
                }
                return;
            }
        } else if (currentLabel.length > 0) {
            emptySince = null;
        }

        if (currentLabel.length === 0 && lastCountsText === expectedCounts) {
            emptySince ??= now;
            if ((now - emptySince) >= emptyStabilityMs) {
                const {importDebug, completed} = await getCompletedImportDebug();
                if (!completed) {
                    await driver.sleep(250);
                    continue;
                }
                if (previousLabel.length > 0) {
                    await addReportPhase(
                        report,
                        driver,
                        `${dictionaryName}: ${previousLabel}`,
                        `${dictionaryName} import progress phase`,
                        previousLabelStart,
                        now,
                    );
                }
                await addReportPhase(
                    report,
                    driver,
                    `${dictionaryName}: total import`,
                    `Accepted settled end state after counts reached expected target with empty progress text. Expected counts target for this phase: ${expectedCounts}. Current counts=${lastCountsText} dictionary-error="${await getDictionaryErrorText(driver)}" import-debug=${JSON.stringify(await getLastImportDebug(driver))} mock-urls=${JSON.stringify(await getMockSeenUrls(driver))}`,
                    importStartTime,
                    now,
                );
                return;
            }
        }

        await driver.sleep(250);
    }

    const countsText = lastCountsText || await getDictionaryCountsText(driver);
    const errorText = await getDictionaryErrorText(driver);
    if (errorText.length === 0 && countsText === expectedCounts) {
        const {importDebug, completed} = await getCompletedImportDebug();
        if (!completed) {
            fail(
                `Timed out waiting for a new ${dictionaryName} import snapshot despite settled counts. ` +
                `counts=${countsText} import-debug=${JSON.stringify(importDebug)}`,
            );
        }
        const now = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            `${dictionaryName}: total import`,
            `Accepted settled end state without observed progress-text lifecycle. Expected counts target for this phase: ${expectedCounts}. Current counts=${countsText} dictionary-error="${errorText}" import-debug=${JSON.stringify(await getLastImportDebug(driver))} mock-urls=${JSON.stringify(await getMockSeenUrls(driver))}`,
            importStartTime,
            now,
        );
        return;
    }
    fail(`Timed out waiting for ${dictionaryName} completion. sawStepText=${String(sawStepText)} clearedAfterStep=${String(clearedAfterStep)}. Last label="${previousLabel}" counts=${countsText} dictionary-error="${errorText}"`);
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {RegExp|string} pattern
 * @param {number} [timeoutMs]
 * @returns {Promise<{ok: boolean, label: string, error: string|null}>}
 */
async function waitForImportProgressPhase(driver, pattern, timeoutMs = 30_000) {
    const regex = pattern instanceof RegExp ? pattern : new RegExp(String(pattern));
    const deadline = safePerformance.now() + timeoutMs;
    let lastLabel = '';
    while (safePerformance.now() < deadline) {
        lastLabel = await getImportProgressLabel(driver);
        if (regex.test(lastLabel)) {
            return {ok: true, label: lastLabel, error: null};
        }
        const errorText = await getDictionaryErrorText(driver);
        if (errorText.length > 0) {
            return {ok: false, label: lastLabel, error: errorText};
        }
        await driver.sleep(200);
    }
    return {ok: false, label: lastLabel, error: `Timed out waiting for import progress phase ${String(regex)}`};
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} settingsWindowHandle
 * @param {string} lookupWindowHandle
 * @param {RegExp|string} phasePattern
 * @param {string} term
 * @param {string[]} expectedDictionaryNames
 * @param {number} [iterationCount]
 * @param {((operation: string) => void)|null} [setActiveOperation]
 * @returns {Promise<{phaseState: {ok: boolean, label: string, error: string|null}, iterations: Array<Record<string, unknown>>}>}
 */
async function verifyLookupRemainsResponsiveDuringImportPhase(driver, settingsWindowHandle, lookupWindowHandle, phasePattern, term, expectedDictionaryNames, iterationCount = 3, setActiveOperation = null) {
    if (typeof setActiveOperation === 'function') {
        setActiveOperation(`wait for import phase gate: ${String(phasePattern)}`);
    }
    await driver.switchTo().window(settingsWindowHandle);
    let phaseState = await waitForImportProgressPhase(driver, phasePattern, 20_000);
    if (phaseState.ok !== true && typeof phaseState.error === 'string' && phaseState.error.length > 0 && !phaseState.error.startsWith('Timed out waiting for import progress phase')) {
        throw new Error(`Import phase gate did not reach ${String(phasePattern)}: ${JSON.stringify(phaseState)}`);
    }
    if (phaseState.ok !== true) {
        phaseState = {
            ok: false,
            label: phaseState.label,
            error: null,
        };
    }
    /** @type {Array<Record<string, unknown>>} */
    const iterations = [];
    for (let i = 0; i < iterationCount; ++i) {
        if (typeof setActiveOperation === 'function') {
            setActiveOperation(`lookup during import phase iteration ${String(i + 1)}/${String(iterationCount)}`);
        }
        await driver.switchTo().window(lookupWindowHandle);
        const iterationStart = safePerformance.now();
        const counts = await searchTermAndGetDictionaryHitCounts(driver, term, expectedDictionaryNames, 20_000);
        const iterationEnd = safePerformance.now();
        iterations.push({
            iteration: i + 1,
            label: phaseState.label,
            durationMs: Math.max(0, iterationEnd - iterationStart),
            counts,
        });
        for (const dictionaryName of expectedDictionaryNames) {
            if ((counts[dictionaryName] ?? 0) < 1) {
                throw new Error(`Lookup dropped dictionary ${dictionaryName} during active import phase: ${JSON.stringify({phaseState, iterations})}`);
            }
        }
        if (i + 1 < iterationCount) {
            await driver.sleep(400);
        }
    }
    if (typeof setActiveOperation === 'function') {
        setActiveOperation('return to settings after import phase lookup verification');
    }
    await driver.switchTo().window(settingsWindowHandle);
    return {phaseState, iterations};
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} selector
 * @returns {Promise<void>}
 */
async function clickWithScroll(driver, selector) {
    // Selenium's JS-only API surfaces `any` for located elements.

    const element = await driver.findElement(By.css(selector));
    await driver.executeScript(`
        const element = arguments[0];
        if (!(element instanceof HTMLElement)) {
            throw new Error('Expected an HTMLElement');
        }
        element.scrollIntoView({block: 'center', inline: 'nearest'});
        element.click();
    `, element);
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} dictionaryName
 * @returns {Promise<string>}
 */
async function installRecommendedDictionary(driver, dictionaryName) {
    await clickWithScroll(driver, '.settings-item[data-modal-action="show,recommended-dictionaries"]');
    await driver.wait(until.elementLocated(By.css('#recommended-dictionaries-modal')), 30_000);
    await driver.wait(async () => {
        // Selenium's executeScript return value is untyped (`any`).

        const names = await driver.executeScript(`
            return Array.from(document.querySelectorAll('#recommended-dictionaries-modal .settings-item-label'))
                .map((node) => (node.textContent || '').trim());
        `);
        return Array.isArray(names) && names.includes(dictionaryName);
    }, 30_000, `Expected recommended dictionary to render: ${dictionaryName}`);
    // Selenium executeScript return value is untyped (`any`).

    const importUrl = await driver.executeScript(`
        const dictionaryName = arguments[0];
        const items = Array.from(document.querySelectorAll('#recommended-dictionaries-modal .settings-item'));
        const item = items.find((currentItem) => {
            const labelNode = currentItem.querySelector('.settings-item-label');
            return (labelNode && (labelNode.textContent || '').trim() === dictionaryName);
        });
        if (!(item instanceof HTMLElement)) {
            throw new Error(\`Recommended dictionary not found: \${dictionaryName}\`);
        }
        const button = item.querySelector('button[data-action="import-recommended-dictionary"]');
        if (!(button instanceof HTMLButtonElement)) {
            throw new Error(\`Recommended dictionary button not found: \${dictionaryName}\`);
        }
        const importUrl = button.getAttribute('data-import-url') || '';
        button.scrollIntoView({block: 'center', inline: 'nearest'});
        button.click();
        return importUrl;
    `, dictionaryName);
    const normalizedImportUrl = typeof importUrl === 'string' ? importUrl : '';
    console.log(`[firefox-e2e] recommended ${dictionaryName} import-url: ${normalizedImportUrl}`);
    return normalizedImportUrl;
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} modalSelector
 * @returns {Promise<void>}
 */
async function closeModalIfOpen(driver, modalSelector) {
    await driver.executeScript(`
        const modal = document.querySelector(arguments[0]);
        if (!(modal instanceof HTMLElement) || modal.hidden) { return; }
        const closeButton = modal.querySelector('[data-modal-action="hide"]');
        if (closeButton instanceof HTMLElement) {
            closeButton.click();
        }
    `, modalSelector);
    await driver.wait(async () => {
        // Selenium executeScript return value is untyped (`any`).

        const hidden = await driver.executeScript(`
            const modal = document.querySelector(arguments[0]);
            return (modal instanceof HTMLElement) ? modal.hidden : true;
        `, modalSelector);
        return hidden === true;
    }, 15_000, `Expected modal to be hidden: ${modalSelector}`);
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<string>}
 */
async function openInstalledDictionariesModal(driver) {
    // Selenium executeScript return value is untyped (`any`).

    const triggerDescription = await driver.executeScript(`
        const isHidden = (element) => {
            if (!(element instanceof HTMLElement)) { return true; }
            if (element.hidden) { return true; }
            const style = getComputedStyle(element);
            return style.display === 'none' || style.visibility === 'hidden';
        };
        const clickElement = (element) => {
            if (!(element instanceof HTMLElement)) { return false; }
            element.scrollIntoView({block: 'center', inline: 'nearest'});
            element.click();
            return true;
        };

        const settingsTrigger = Array.from(document.querySelectorAll('.settings-item[data-modal-action="show,dictionaries"]')).find((item) => {
            if (!(item instanceof HTMLElement)) { return false; }
            if (isHidden(item)) { return false; }
            const label = item.querySelector('.settings-item-label');
            const text = (label?.textContent || '').trim();
            return text.includes('Configure installed and enabled dictionaries');
        });
        if (settingsTrigger && clickElement(settingsTrigger)) {
            return 'settings-item:Configure installed and enabled dictionaries';
        }

        throw new Error('Unable to find installed dictionaries modal trigger');
    `);
    await driver.wait(async () => {
        // Selenium executeScript return value is untyped (`any`).

        const open = await driver.executeScript(`
            const dictionariesModal = document.querySelector('#dictionaries-modal');
            const recommendedModal = document.querySelector('#recommended-dictionaries-modal');
            const dictionariesOpen = dictionariesModal instanceof HTMLElement && !dictionariesModal.hidden;
            const recommendedClosed = !(recommendedModal instanceof HTMLElement) || recommendedModal.hidden;
            let hasCheckForUpdatesButton = false;
            if (dictionariesOpen) {
                const footerButtons = Array.from(dictionariesModal.querySelectorAll('.modal-footer button'));
                hasCheckForUpdatesButton = footerButtons.some((button) => {
                    const text = (button.textContent || '').trim();
                    return text === 'Check for Updates';
                });
            }
            return dictionariesOpen && recommendedClosed && hasCheckForUpdatesButton;
        `);
        return open === true;
    }, 30_000, 'Expected installed dictionaries modal to open with Check for Updates button');
    return typeof triggerDescription === 'string' ? triggerDescription : 'unknown-trigger';
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} extensionBaseUrl
 * @returns {Promise<void>}
 */
async function openSearchPageViaActionPopup(driver, extensionBaseUrl) {
    await navigateToExtensionPage(
        driver,
        `${extensionBaseUrl}/action-popup.html`,
        By.css('.action-open-search'),
    );
    await driver.wait(async () => {
        // Selenium executeScript return value is untyped (`any`).

        const loaded = await driver.executeScript('return document.body?.dataset?.loaded === "true";');
        return loaded === true;
    }, 30_000, 'Expected action popup to finish loading');
    await driver.wait(until.elementLocated(By.css('.action-open-search')), 30_000);
    await driver.executeScript(`
        const button = document.querySelector('.action-open-search');
        if (!(button instanceof HTMLElement)) {
            throw new Error('Search button not found in action popup');
        }
        button.scrollIntoView({block: 'center', inline: 'nearest'});
        button.dispatchEvent(new MouseEvent('click', {
            bubbles: true,
            cancelable: true,
            composed: true,
            button: 0,
            shiftKey: true,
        }));
    `);
    await driver.wait(async () => {
        const url = String(await driver.getCurrentUrl());
        return /\/search\.html(?:\?|$)/.test(url);
    }, 30_000, 'Expected search page to open from action popup magnifier');
    await driver.wait(until.elementLocated(By.css('#search-textbox')), 30_000);
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} extensionBaseUrl
 * @returns {Promise<string>}
 */
async function openSearchPageInNewTab(driver, extensionBaseUrl) {
    const existingHandles = new Set((await driver.getAllWindowHandles()).map(String));
    await driver.executeScript('window.open(arguments[0], "_blank");', `${extensionBaseUrl}/search.html`);
    const newHandle = await driver.wait(async () => {
        const handles = (await driver.getAllWindowHandles()).map(String);
        return handles.find((handle) => !existingHandles.has(handle)) ?? false;
    }, 30_000, 'Expected extension search tab to open');
    await driver.switchTo().window(String(newHandle));
    await driver.wait(until.elementLocated(By.css('#search-textbox')), 30_000);
    return String(newHandle);
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string[]} filePaths
 * @returns {Promise<void>}
 */
async function importDictionariesViaFileInput(driver, filePaths) {
    const normalizedPaths = (Array.isArray(filePaths) ? filePaths : [])
        .map((value) => String(value || '').trim())
        .filter((value) => value.length > 0);
    if (normalizedPaths.length === 0) {
        throw new Error('No dictionary file paths were provided for multi-file import');
    }
    const fileInput = await driver.findElement(By.css('#dictionary-import-file-input'));
    await driver.executeScript(`
        const input = arguments[0];
        if (!(input instanceof HTMLElement)) {
            throw new Error('Dictionary import input not found');
        }
        input.scrollIntoView({block: 'center', inline: 'nearest'});
    `, fileInput);
    await fileInput.sendKeys(normalizedPaths.join('\n'));
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} term
 * @param {string[]} expectedDictionaryNames
 * @param {number} [timeoutMs]
 * @param {'enter'|'button'} [submitMode]
 * @returns {Promise<Record<string, number>>}
 */
async function searchTermAndGetDictionaryHitCounts(driver, term, expectedDictionaryNames, timeoutMs = 60_000, submitMode = 'enter') {
    await driver.wait(async () => {
        // Selenium executeScript return value is untyped (`any`).

        const ready = await driver.executeScript(`
            const debugState = window.__manabitanSearchDebug;
            return document.documentElement.dataset.loaded === 'true' &&
                debugState &&
                typeof debugState === 'object' &&
                debugState.controllerPrepared === true;
        `);
        return ready === true;
    }, 30_000, 'Expected search page controller to finish initialization');
    await driver.wait(async () => {
        // Selenium executeScript return value is untyped (`any`).

        const submitted = await driver.executeScript(`
            const textbox = document.querySelector('#search-textbox');
            const searchButton = document.querySelector('#search-button');
            const submitMode = String(arguments[1] || 'enter');
            if (!(textbox instanceof HTMLTextAreaElement)) { return false; }
            textbox.value = '';
            textbox.dispatchEvent(new Event('input', {bubbles: true, cancelable: true}));
            textbox.value = String(arguments[0] || '');
            textbox.dispatchEvent(new Event('input', {bubbles: true, cancelable: true}));
            if (submitMode === 'button') {
                if (!(searchButton instanceof HTMLElement)) { return false; }
                searchButton.dispatchEvent(new MouseEvent('click', {
                    bubbles: true,
                    cancelable: true,
                    composed: true,
                    button: 0,
                }));
            } else if (submitMode === 'enter') {
                textbox.dispatchEvent(new KeyboardEvent('keydown', {
                    bubbles: true,
                    cancelable: true,
                    key: 'Enter',
                    code: 'Enter',
                }));
            } else {
                return false;
            }
            return true;
        `, term, submitMode);
        return submitted === true;
    }, 30_000, 'Expected search textbox and button to be available on search page');

    const deadline = safePerformance.now() + timeoutMs;
    /** @type {Record<string, number>} */
    let lastCounts = Object.fromEntries(expectedDictionaryNames.map((name) => [name, 0]));
    while (safePerformance.now() < deadline) {
        // Selenium executeScript return value is untyped (`any`).

        const counts = await driver.executeScript(`
            const dictionaryEntries = document.querySelector('#dictionary-entries');
            if (!(dictionaryEntries instanceof HTMLElement)) {
                return {};
            }
            const countMap = Object.create(null);
            const dictionaryNodes = dictionaryEntries.querySelectorAll('.definition-item[data-dictionary], .entry [data-dictionary]');
            for (const node of dictionaryNodes) {
                const dictionary = node instanceof HTMLElement ? (node.dataset.dictionary || '').trim() : '';
                if (dictionary.length === 0) { continue; }
                countMap[dictionary] = (countMap[dictionary] || 0) + 1;
            }
            // Fallback: if selectors differ, infer by visible dictionary labels in result text.
            const text = (dictionaryEntries.textContent || '');
            for (const name of arguments[0]) {
                if (countMap[name]) { continue; }
                const matchCount = text.length > 0 && name.length > 0 ? Math.max(0, text.split(name).length - 1) : 0;
                if (matchCount > 0) {
                    countMap[name] = matchCount;
                }
            }
            return countMap;
        `, expectedDictionaryNames);
        if (typeof counts === 'object' && counts !== null) {
            // Selenium executeScript return value is untyped (`any`).

            const countRecord = /** @type {Record<string, unknown>} */ (counts);
            const normalizedCounts = /** @type {Record<string, number>} */ ({});
            for (const [key, value] of Object.entries(countRecord)) {
                normalizedCounts[String(key)] = Number(value);
            }
            lastCounts = Object.fromEntries(expectedDictionaryNames.map((name) => [name, normalizedCounts[name] ?? 0]));
            if (expectedDictionaryNames.every((name) => (lastCounts[name] ?? 0) >= 1)) {
                return lastCounts;
            }
        }
        await driver.sleep(250);
    }

    // Firefox search-page DOM labeling can lag or differ from Chromium even when
    // the page-backed runtime can already resolve the lookup through the backend.
    try {
        // Selenium executeAsyncScript return value is untyped (`any`).

        const backendCounts = await driver.executeAsyncScript(`
            const done = arguments[arguments.length - 1];
            const term = arguments[0];
            const expectedNames = Array.isArray(arguments[1]) ? arguments[1] : [];
            const send = (action, params) => new Promise((resolve, reject) => {
                try {
                    chrome.runtime.sendMessage({action, params}, (response) => {
                        const runtimeError = chrome.runtime.lastError;
                        if (runtimeError) {
                            reject(new Error(runtimeError.message || String(runtimeError)));
                            return;
                        }
                        if (response && typeof response === 'object' && 'error' in response) {
                            reject(new Error(JSON.stringify(response.error)));
                            return;
                        }
                        resolve(response && typeof response === 'object' ? response.result : response);
                    });
                } catch (e) {
                    reject(e);
                }
            });
            (async () => {
                const termsFind = await send('termsFind', {
                    text: term,
                    details: {primaryReading: ''},
                    optionsContext: {},
                });
                const countMap = Object.create(null);
                if (Array.isArray(termsFind?.dictionaryEntries)) {
                    for (const entry of termsFind.dictionaryEntries) {
                        if (!(entry && typeof entry === 'object')) { continue; }
                        const dictionaries = new Set();
                        const dictionary = typeof entry.dictionary === 'string' ? entry.dictionary.trim() : '';
                        if (dictionary.length > 0) {
                            dictionaries.add(dictionary);
                        }
                        if (Array.isArray(entry.definitions)) {
                            for (const definition of entry.definitions) {
                                const name = typeof definition?.dictionary === 'string' ? definition.dictionary.trim() : '';
                                if (name.length > 0) {
                                    dictionaries.add(name);
                                }
                            }
                        }
                        for (const name of dictionaries) {
                            countMap[name] = (countMap[name] || 0) + 1;
                        }
                    }
                }
                for (const expectedName of expectedNames) {
                    if (countMap[expectedName]) { continue; }
                    for (const [observedName, count] of Object.entries(countMap)) {
                        const observed = String(observedName || '').trim();
                        const expected = String(expectedName || '').trim();
                        if (
                            observed.length > 0 &&
                            expected.length > 0 &&
                            (
                                observed === expected ||
                                observed.startsWith(expected + ' ') ||
                                observed.startsWith(expected + '.') ||
                                observed.includes(expected)
                            )
                        ) {
                            countMap[expected] = Number(count);
                            break;
                        }
                    }
                }
                done(countMap);
            })().catch((e) => {
                done({__error: String(e && e.message ? e.message : e)});
            });
        `, term, expectedDictionaryNames);
        if (typeof backendCounts === 'object' && backendCounts !== null && !Array.isArray(backendCounts)) {
            const backendError = '__error' in backendCounts && typeof backendCounts.__error === 'string' ? backendCounts.__error : '';
            if (backendError.length > 0) {
                throw new Error(`Backend termsFind failed during search fallback: ${backendError}`);
            }
            const normalizedCounts = /** @type {Record<string, number>} */ ({});
            for (const [key, value] of Object.entries(/** @type {Record<string, unknown>} */ (backendCounts))) {
                if (key === '__error') { continue; }
                normalizedCounts[String(key)] = Number(value);
            }
            const projectedCounts = Object.fromEntries(expectedDictionaryNames.map((name) => [name, normalizedCounts[name] ?? 0]));
            if (expectedDictionaryNames.some((name) => (projectedCounts[name] ?? 0) > 0)) {
                return projectedCounts;
            }
        }
    } catch (error) {
        throw new Error(
            `Backend termsFind diagnostic failed after DOM search returned ${JSON.stringify(lastCounts)}: ${error instanceof Error ? error.message : String(error)}`,
            {cause: error},
        );
    }

    return lastCounts;
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string[]} expectedDictionaryNames
 * @param {string[]} candidates
 * @param {number} [timeoutMs]
 * @returns {Promise<{ok: boolean, term: string, probes: Array<{term: string, counts: Record<string, number>}>}>}
 */
async function findLookupProbeTerm(driver, expectedDictionaryNames, candidates, timeoutMs = 12_000) {
    const normalizedCandidates = [...new Set(
        (Array.isArray(candidates) ? candidates : [])
            .map((value) => String(value || '').trim())
            .filter((value) => value.length > 0),
    )];
    /** @type {Array<{term: string, counts: Record<string, number>}>} */
    const probes = [];
    for (const term of normalizedCandidates) {
        const counts = await searchTermAndGetDictionaryHitCounts(driver, term, expectedDictionaryNames, timeoutMs);
        probes.push({term, counts});
        if (expectedDictionaryNames.every((name) => Number(counts[name] || 0) >= 1)) {
            return {ok: true, term, probes};
        }
    }
    return {
        ok: false,
        term: normalizedCandidates[0] ?? '東京',
        probes,
    };
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<Record<string, unknown>>}
 */
async function getSearchPageDiagnostics(driver) {
    // Selenium executeScript return value is untyped (`any`).

    const diagnostics = await driver.executeScript(`
        const noResults = document.querySelector('#no-results');
        const noDictionaries = document.querySelector('#no-dictionaries');
        const entries = document.querySelector('#dictionary-entries');
        const valueOrEmpty = (element) => (element instanceof HTMLElement ? (element.textContent || '').trim() : '');
        return {
            url: location.href,
            searchTextboxValue: (() => {
                const input = document.querySelector('#search-textbox');
                return input instanceof HTMLTextAreaElement ? input.value : null;
            })(),
            noResultsVisible: noResults instanceof HTMLElement ? !noResults.hidden : null,
            noDictionariesVisible: noDictionaries instanceof HTMLElement ? !noDictionaries.hidden : null,
            entriesTextPreview: valueOrEmpty(entries).slice(0, 300),
        };
    `);
    if (typeof diagnostics === 'object' && diagnostics !== null && !Array.isArray(diagnostics)) {
        return /** @type {Record<string, unknown>} */ (diagnostics);
    }
    return {error: `Unexpected diagnostics payload: ${String(diagnostics)}`};
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<Record<string, string>>}
 */
async function getPageFrontendDebugState(driver) {
    // Selenium executeScript return value is untyped (`any`).

    const state = await driver.executeScript(`
        return Object.fromEntries(
            Object.entries(document.documentElement?.dataset ?? {})
                .filter(([key]) => key.startsWith('manabitan')),
        );
    `);
    return typeof state === 'object' && state !== null && !Array.isArray(state) ?
        /** @type {Record<string, string>} */ (state) :
        {};
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {number} [timeoutMs]
 * @returns {Promise<Record<string, string>>}
 */
async function waitForPageFrontendHoverReady(driver, timeoutMs = 15_000) {
    /** @type {Record<string, string>} */
    let state = {};
    await driver.wait(async () => {
        state = await getPageFrontendDebugState(driver);
        return (
            state.manabitanContentScriptLoaded === 'true' &&
            state.manabitanContentScriptPrepared === 'true'
        );
    }, timeoutMs, () => `Frontend did not become hover-ready: ${JSON.stringify(state)}`);
    return state;
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} pageUrl
 * @param {string} targetSelector
 * @param {string[]} expectedDictionaryNames
 * @param {{label?: string, moveAwayOffsetX?: number, moveToOffsetX?: number, moveToOffsetY?: number, pauseAfterMoveMs?: number, popupTimeoutMs?: number}|null} [motionProfile]
 * @returns {Promise<{popupText: string, hasDictionaryEntries: boolean, noResultsVisible: boolean, noDictionariesVisible: boolean, entriesTextPreview: string, usedModifier: string|null}>}
 */
async function hoverLookupOnPage(driver, pageUrl, targetSelector, expectedDictionaryNames, motionProfile = null) {
    const currentUrl = String(await driver.getCurrentUrl());
    if (currentUrl !== pageUrl) {
        await driver.get(pageUrl);
    }
    await waitForPageFrontendHoverReady(driver);
    // Match Chromium's repeated-hover contract: dismiss the prior popup so it
    // cannot occlude the next fixture target or satisfy the next visibility wait.
    const previousFrames = await driver.findElements(By.css('iframe.yomitan-popup'));
    for (const frame of previousFrames.reverse()) {
        if (!await frame.isDisplayed()) { continue; }
        try {
            await driver.switchTo().frame(frame);
            const closeButtons = await driver.findElements(By.css('#close-button'));
            await (closeButtons.length > 0 && await closeButtons[0].isDisplayed() ?
                closeButtons[0].click() :
                (await driver.findElement(By.css('#content-scroll-focus'))).sendKeys(Key.ESCAPE));
        } finally {
            await driver.switchTo().defaultContent();
        }
    }
    // Closing the popup leaves the native pointer on its former close button.
    // That coordinate can expose an underlying word and immediately reopen the
    // popup over the next fixture target. Park in the page corner first.
    await driver.actions({async: true})
        .move({x: 1, y: 1})
        .pause(50)
        .perform();
    await driver.wait(async () => {
        for (const frame of await driver.findElements(By.css('iframe.yomitan-popup'))) {
            if (await frame.isDisplayed()) { return false; }
        }
        return true;
    }, 2500, 'Expected previous hover popup to dismiss before the next target');

    const targetElement = /** @type {import('selenium-webdriver').WebElement} */ (await driver.wait(until.elementLocated(By.css(targetSelector)), 30_000));
    await driver.executeScript(`
        const target = arguments[0];
        if (target instanceof HTMLElement) {
            target.scrollIntoView({block: 'center', inline: 'center'});
        }
    `, targetElement);
    // Anchor the motion to the first glyph, not the element's center plus an
    // offset that can land beyond a one-character span or inside the next word.
    const geometry = await driver.executeScript(`
        const target = arguments[0];
        const text = target.textContent.trim();
        const walker = document.createTreeWalker(target, NodeFilter.SHOW_TEXT);
        let node;
        while ((node = walker.nextNode()) !== null && !node.textContent.trim()) {}
        if (node === null) { throw new Error('Hover fixture has no text'); }
        const start = node.textContent.search(/\\S/);
        const length = String.fromCodePoint(node.textContent.codePointAt(start)).length;
        const range = document.createRange();
        range.setStart(node, start);
        range.setEnd(node, start + length);
        const glyph = range.getBoundingClientRect();
        const element = target.getBoundingClientRect();
        const x = glyph.left + glyph.width / 2;
        const y = glyph.top + glyph.height / 2;
        const hit = document.elementFromPoint(x, y);
        return {text, x, y, viewportWidth: window.innerWidth, viewportHeight: window.innerHeight,
            hitTarget: hit === target || target.contains(hit),
            hitTag: hit instanceof Element ? hit.tagName : '',
            hitText: String(hit?.textContent || '').trim().slice(0, 80),
            offsetX: glyph.left + glyph.width / 2 - (element.left + element.width / 2),
            offsetY: glyph.top + glyph.height / 2 - (element.top + element.height / 2),
            width: glyph.width, height: glyph.height};
    `, targetElement);
    if (geometry.hitTarget !== true) {
        fail(`Firefox hover target is not topmost at its first glyph before pointer motion: ${JSON.stringify({targetSelector, geometry})}`);
    }
    const moveAwayOffsetX = Number.isFinite(Number(motionProfile?.moveAwayOffsetX)) ? Number(motionProfile?.moveAwayOffsetX) : -12;
    const moveToOffsetX = Number.isFinite(Number(motionProfile?.moveToOffsetX)) ? Number(motionProfile?.moveToOffsetX) : 10;
    const moveToOffsetY = Number.isFinite(Number(motionProfile?.moveToOffsetY)) ? Number(motionProfile?.moveToOffsetY) : 2;
    const pauseAfterMoveMs = Number.isFinite(Number(motionProfile?.pauseAfterMoveMs)) ? Math.max(0, Number(motionProfile?.pauseAfterMoveMs)) : 0;
    const popupTimeoutMs = Number.isFinite(Number(motionProfile?.popupTimeoutMs)) ? Math.max(1200, Number(motionProfile?.popupTimeoutMs)) : 5000;
    /** @type {Array<string|null>} */
    const modifierCandidates = [Key.SHIFT, Key.ALT, Key.CONTROL, null];
    let popupVisible = false;
    let usedModifier = null;
    /** @type {Record<string, unknown>|null} */
    let pageHoverState = null;
    for (const modifier of modifierCandidates) {
        if (modifier !== null && !useScriptedHoverMotion) {
            await driver.actions({async: true}).keyDown(modifier).perform();
        }
        try {
            await (useScriptedHoverMotion ?
driver.executeScript(`
                    const [target, awayX, toX, toY, shiftKey, altKey, ctrlKey] = arguments;
                    const glyph = arguments[7];
                    const emit = (type, x, y) => target.dispatchEvent(new PointerEvent(type, {
                        bubbles: true,
                        cancelable: true,
                        view: window,
                        pointerId: 1,
                        pointerType: 'mouse',
                        isPrimary: true,
                        clientX: glyph.x + Math.max(-glyph.width / 4, Math.min(glyph.width / 4, x)),
                        clientY: glyph.y + Math.max(-glyph.height / 4, Math.min(glyph.height / 4, y)),
                        shiftKey,
                        altKey,
                        ctrlKey,
                    }));
                    target.dispatchEvent(new PointerEvent('pointermove', {bubbles: true, pointerId: 1, pointerType: 'mouse', isPrimary: true, clientX: glyph.x + awayX - glyph.width, clientY: glyph.y - glyph.height, shiftKey, altKey, ctrlKey}));
                    emit('pointermove', 2, 2);
                    emit('pointermove', toX, toY);
                `, targetElement, moveAwayOffsetX, moveToOffsetX, moveToOffsetY, modifier === Key.SHIFT, modifier === Key.ALT, modifier === Key.CONTROL, geometry) :
driver.actions({async: true})
    // Teleport to a neutral point, then approach from just above this glyph.
    // A long animated path across the fixture can hover an intervening word,
    // opening a new popup over the intended target before the pointer arrives.
    .move({x: 1, y: 1, duration: 0})
    .move({x: Math.round(geometry.x), y: Math.max(1, Math.round(geometry.y - geometry.height)), duration: 0})
    .pause(50)
    .move({x: Math.round(geometry.x + Math.max(-geometry.width / 4, Math.min(geometry.width / 4, moveToOffsetX))),
        y: Math.round(geometry.y + Math.max(-geometry.height / 4, Math.min(geometry.height / 4, moveToOffsetY))),
        duration: 220})
    .perform());
            pageHoverState = await driver.executeScript(`
                const target = document.querySelector(arguments[0]);
                if (!(target instanceof HTMLElement)) { return {found: false}; }
                const point = document.elementFromPoint(arguments[1], arguments[2]);
                return {found: true, targetHovered: target.matches(':hover'), hitTarget: point === target || target.contains(point),
                    hitTag: point instanceof Element ? point.tagName : '',
                    hitText: String(point?.textContent || '').trim().slice(0, 80),
                    targetRect: (() => { const r = target.getBoundingClientRect(); return {x:r.x,y:r.y,width:r.width,height:r.height}; })()};
            `, targetSelector, Math.round(geometry.x), Math.round(geometry.y));
            if (pauseAfterMoveMs > 0) {
                await driver.sleep(pauseAfterMoveMs);
            }

            const visibleWithModifier = await driver.wait(async () => {
                const frames = /** @type {import('selenium-webdriver').WebElement[]} */ (await driver.findElements(By.css('iframe.yomitan-popup')));
                for (const frame of frames) {
                    if (await frame.isDisplayed()) { return true; }
                }
                return false;
            }, popupTimeoutMs).then(() => true, () => false);
            popupVisible = Boolean(visibleWithModifier);
            if (popupVisible) {
                usedModifier = modifier;
                break;
            }
        } finally {
            if (modifier !== null && !useScriptedHoverMotion) {
                await driver.actions({async: true}).keyUp(modifier).perform();
            }
        }
    }
    if (!popupVisible) {
        fail('Expected yomitan popup iframe to appear after hover scan');
    }
    try {
        const frames = /** @type {import('selenium-webdriver').WebElement[]} */ (await driver.findElements(By.css('iframe.yomitan-popup')));
        let popupFrame = null;
        for (const frame of frames) {
            if (await frame.isDisplayed()) {
                popupFrame = frame;
                break;
            }
        }
        if (popupFrame === null) {
            fail('No visible yomitan popup iframe found');
        }
        await driver.switchTo().frame(popupFrame);
        // A visible iframe and its permanent scaffold can belong to the last
        // request. Require this target's query and rendered dictionaries before
        // taking a snapshot; retain the existing per-popup deadline.
        /** @type {Record<string, unknown>|null} */
        let hoverSnapshot = null;
        await driver.wait(async () => {
            hoverSnapshot = await driver.executeScript(`
            const [expectedText, names, selector, pageState] = arguments;
            const query = new URL(location.href).searchParams.get('query') || '';
            const entries = document.querySelector('#dictionary-entries');
            const text = entries instanceof HTMLElement ? entries.innerText : '';
            return {ready: query.startsWith(expectedText) && names.every((name) => text.includes(name)),
                targetSelector: selector,
                pageHoverState: pageState,
                query, expectedText, entries: text.slice(0, 300), location: location.href,
                body: document.body.innerText.slice(0, 300), sentence: history.state?.state?.sentence};
        `, geometry.text, expectedDictionaryNames, targetSelector, pageHoverState);
            return hoverSnapshot?.ready === true;
        }, popupTimeoutMs, () => `Expected the current hover target and rendered dictionary results: ${JSON.stringify(hoverSnapshot)}`);
        const popupText = String(await (await driver.findElement(By.css('body'))).getText());
        // Selenium executeScript return value is untyped (`any`).

        const popupState = await driver.executeScript(`
            const dictionaryEntries = document.querySelector('#dictionary-entries');
            const noResults = document.querySelector('#no-results');
            const noDictionaries = document.querySelector('#no-dictionaries');
            const entriesText = dictionaryEntries instanceof HTMLElement ? (dictionaryEntries.textContent || '').replaceAll(/\\s+/g, ' ').trim() : '';
            return {
                hasDictionaryEntries: dictionaryEntries instanceof HTMLElement && entriesText.length > 0,
                noResultsVisible: noResults instanceof HTMLElement ? !noResults.hidden : false,
                noDictionariesVisible: noDictionaries instanceof HTMLElement ? !noDictionaries.hidden : false,
                entriesTextPreview: entriesText.slice(0, 200),
            };
        `);
        await driver.switchTo().defaultContent();
        if (!expectedDictionaryNames.every((name) => popupText.includes(name))) {
            fail(`Expected hover popup to include dictionaries ${JSON.stringify(expectedDictionaryNames)}, saw: "${popupText.slice(0, 420)}"`);
        }
        return {
            popupText,
            hasDictionaryEntries: popupState?.hasDictionaryEntries === true,
            noResultsVisible: popupState?.noResultsVisible === true,
            noDictionariesVisible: popupState?.noDictionariesVisible === true,
            entriesTextPreview: String(popupState?.entriesTextPreview || ''),
            usedModifier,
        };
    } finally {
        await driver.switchTo().defaultContent();
    }
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} term
 * @returns {Promise<Record<string, unknown>>}
 */
async function getBackendLookupDiagnostics(driver, term) {
    const originalWindowHandle = await driver.getWindowHandle();
    let activeExtensionWindowHandle = originalWindowHandle;
    let shouldRestoreWindowHandle = false;
    try {
        const currentUrl = String(await driver.getCurrentUrl());
        if (!/^(moz|chrome)-extension:\/\//.test(currentUrl)) {
            const windowHandles = await driver.getAllWindowHandles();
            for (const windowHandle of windowHandles) {
                await driver.switchTo().window(windowHandle);
                const url = String(await driver.getCurrentUrl());
                if (/^(moz|chrome)-extension:\/\//.test(url)) {
                    activeExtensionWindowHandle = windowHandle;
                    shouldRestoreWindowHandle = windowHandle !== originalWindowHandle;
                    break;
                }
            }
        }
    } catch (e) {
        try {
            await driver.switchTo().window(originalWindowHandle);
        } catch (_) {
            // Ignore restore failures here; the async script call below will report the real problem.
        }
        return {error: String(e && e.message ? e.message : e)};
    }
    // Selenium executeAsyncScript return value is untyped (`any`).

    try {
        const diagnostics = await driver.executeAsyncScript(`
            const done = arguments[arguments.length - 1];
            const send = (action, params) => new Promise((resolve, reject) => {
                try {
                    chrome.runtime.sendMessage({action, params}, (response) => {
                        const runtimeError = chrome.runtime.lastError;
                        if (runtimeError) {
                            reject(new Error(runtimeError.message || String(runtimeError)));
                            return;
                        }
                        if (response && typeof response === 'object' && 'error' in response) {
                            reject(new Error(JSON.stringify(response.error)));
                            return;
                        }
                        resolve(response && typeof response === 'object' ? response.result : response);
                    });
                } catch (e) {
                    reject(e);
                }
            });
            (async () => {
                const term = arguments[0];
                const dictionaryInfo = await send('getDictionaryInfo', undefined);
                const installedTitles = (Array.isArray(dictionaryInfo) ? dictionaryInfo : [])
                    .map((row) => String(row?.title || '').trim())
                    .filter((value) => value.length > 0);
                const termsFind = await send('termsFind', {
                    text: term,
                    details: {primaryReading: ''},
                    optionsContext: {},
                });
                const termDictionaryNamesSet = new Set();
                if (Array.isArray(termsFind?.dictionaryEntries)) {
                    for (const entry of termsFind.dictionaryEntries) {
                        if (!(entry && typeof entry === 'object')) { continue; }
                        const dictionary = typeof entry.dictionary === 'string' ? entry.dictionary : null;
                        if (dictionary) {
                            termDictionaryNamesSet.add(dictionary);
                        }
                        if (Array.isArray(entry.definitions)) {
                            for (const definition of entry.definitions) {
                                if (!(definition && typeof definition === 'object')) { continue; }
                                const name = typeof definition.dictionary === 'string' ? definition.dictionary : null;
                                if (name) {
                                    termDictionaryNamesSet.add(name);
                                }
                            }
                        }
                    }
                }
                const optionsFull = await send('optionsGetFull', undefined);
                const profileDictionaries = Array.isArray(optionsFull?.profiles) ?
                    optionsFull.profiles.map((profile) => ({
                        id: profile?.id ?? null,
                        dictionaries: Array.isArray(profile?.options?.dictionaries) ?
                            profile.options.dictionaries.map((dictionary) => String(dictionary?.name || '')) :
                            [],
                    })) :
                    null;
                const enabledInstalledExactMatches = Array.isArray(optionsFull?.profiles?.[0]?.options?.dictionaries) ?
                    optionsFull.profiles[0].options.dictionaries
                        .filter((dictionary) => dictionary?.enabled === true)
                        .map((dictionary) => String(dictionary?.name || '').trim())
                        .filter((name) => name.length > 0 && installedTitles.includes(name)) :
                    [];
                let debugLookupState = null;
                try {
                    debugLookupState = await send('debugDictionaryLookupState', {
                        text: term,
                        dictionaryNames: [...new Set(enabledInstalledExactMatches)],
                    });
                } catch (e) {
                    debugLookupState = {
                        ok: false,
                        reason: 'debug lookup unavailable',
                        text: term,
                        error: String(e && e.message ? e.message : e),
                    };
                }
                done({
                    dictionaryInfo,
                    installedTitles,
                    debugLookupState,
                    termResultCount: Array.isArray(termsFind?.dictionaryEntries) ? termsFind.dictionaryEntries.length : null,
                    termDictionaryNames: [...termDictionaryNamesSet],
                    profileDictionaries,
                });
            })().catch((e) => {
                done({error: String(e && e.message ? e.message : e)});
            });
        `, term);
        if (typeof diagnostics === 'object' && diagnostics !== null && !Array.isArray(diagnostics)) {
            return /** @type {Record<string, unknown>} */ (diagnostics);
        }
        return {error: `Unexpected diagnostics payload: ${String(diagnostics)}`};
    } finally {
        if (shouldRestoreWindowHandle && activeExtensionWindowHandle !== originalWindowHandle) {
            try {
                await driver.switchTo().window(originalWindowHandle);
            } catch (_) {
                // Ignore restoration failures; callers handle discarded contexts separately.
            }
        }
    }
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string[]} dictionaryNames
 * @param {string[]} candidates
 * @param {number} timeoutMs
 * @returns {Promise<{ok: boolean, reason?: string, probes: Array<Record<string, unknown>>}>}
 */
async function waitForBackendDictionaryContentIntegrity(driver, dictionaryNames, candidates, timeoutMs = 15_000) {
    const deadline = safePerformance.now() + timeoutMs;
    /** @type {Array<Record<string, unknown>>} */
    let lastProbes = [];
    while (safePerformance.now() < deadline) {
        /** @type {string[]} */
        let installedTitles = [];
        /** @type {string[]} */
        let targetDictionaryNames = dictionaryNames;
        /** @type {Array<Record<string, unknown>>} */
        const probes = [];
        for (const term of candidates) {
            const diagnostics = await getBackendLookupDiagnostics(driver, term);
            const diagnosticsInstalledTitles = Array.isArray(diagnostics.installedTitles) ?
                diagnostics.installedTitles.map((value) => String(value || '').trim()).filter((value) => value.length > 0) :
                [];
            if (diagnosticsInstalledTitles.length > 0) {
                installedTitles = diagnosticsInstalledTitles;
                const resolvedNames = dictionaryNames.flatMap((expectedName) => (
                    installedTitles.filter((title) => matchesDictionaryName(title, expectedName))
                ));
                targetDictionaryNames = [...new Set(resolvedNames.length > 0 ? resolvedNames : dictionaryNames)];
            }
            const debugLookupState = diagnostics.debugLookupState;
            const store = (debugLookupState && typeof debugLookupState === 'object' && !Array.isArray(debugLookupState)) ?
                debugLookupState.termContentStoreDebugState :
                null;
            const totalLength = Number(store?.totalLength ?? -1);
            const rowSample = Array.isArray(debugLookupState?.rowSample) ? debugLookupState.rowSample : [];
            let inBoundsRowCount = 0;
            let outOfBoundsRowCount = 0;
            let glossaryReadyRowCount = 0;
            let readablePreviewRowCount = 0;
            for (const row of rowSample) {
                const rowDictionary = String(row?.dictionary || '').trim();
                if (
                    targetDictionaryNames.length > 0 &&
                    rowDictionary.length > 0 &&
                    !targetDictionaryNames.some((name) => matchesDictionaryName(rowDictionary, name))
                ) {
                    continue;
                }
                const offset = Number(row?.rawEntryContentOffset ?? -1);
                const length = Number(row?.rawEntryContentLength ?? -1);
                const glossaryLength = Number(row?.glossaryLength ?? 0);
                const preview = String(row?.rawContentPreview ?? '');
                if (Number.isFinite(offset) && Number.isFinite(length) && offset >= 0 && length > 0 && Number.isFinite(totalLength) && totalLength > 0) {
                    if ((offset + length) <= totalLength) {
                        ++inBoundsRowCount;
                    } else {
                        ++outOfBoundsRowCount;
                    }
                }
                if (glossaryLength > 0) {
                    ++glossaryReadyRowCount;
                }
                if (preview.length > 0 && preview !== '<read-null>' && preview !== '<read-failed>') {
                    ++readablePreviewRowCount;
                }
            }
            probes.push({
                term,
                dictionaryNames: targetDictionaryNames,
                requestedDictionaryNames: dictionaryNames,
                totalLength: Number.isFinite(totalLength) ? totalLength : null,
                rowSampleCount: rowSample.length,
                inBoundsRowCount,
                outOfBoundsRowCount,
                glossaryReadyRowCount,
                readablePreviewRowCount,
                diagnostics,
            });
            if (outOfBoundsRowCount > 0) {
                return {ok: false, reason: 'out-of-bounds-entry-content-offsets', probes};
            }
            const termResultCount = Number(diagnostics.termResultCount ?? 0);
            const termDictionaryNames = Array.isArray(diagnostics.termDictionaryNames) ?
                diagnostics.termDictionaryNames.map((value) => String(value || '').trim()).filter((value) => value.length > 0) :
                [];
            const hasMatchingLookupResults = (
                termResultCount > 0 &&
                (
                    targetDictionaryNames.length === 0 ||
                    targetDictionaryNames.some((name) => termDictionaryNames.some((termName) => matchesDictionaryName(termName, name)))
                )
            );
            if (glossaryReadyRowCount > 0 || readablePreviewRowCount > 0) {
                return {ok: true, probes};
            }
            if (hasMatchingLookupResults) {
                return {ok: true, reason: 'lookup-results-visible-without-debug-row-sample', probes};
            }
        }
        lastProbes = probes;
        await driver.sleep(500);
    }
    return {ok: false, reason: 'no-readable-entry-content', probes: lastProbes};
}

/**
 * @param {Record<string, unknown>} diagnostics
 * @returns {Array<Record<string, unknown>>}
 */
function getDictionaryInfoEntries(diagnostics) {
    const raw = diagnostics.dictionaryInfo;
    if (!Array.isArray(raw)) { return []; }
    return raw.filter((item) => typeof item === 'object' && item !== null && !Array.isArray(item));
}

/**
 * @param {Array<Record<string, unknown>>} dictionaryInfoEntries
 * @returns {{titles: string[], importFailures: string[], zeroTermDictionaries: string[]}}
 */
function summarizeDictionaryInfoHealth(dictionaryInfoEntries) {
    /** @type {string[]} */
    const titles = [];
    /** @type {string[]} */
    const importFailures = [];
    /** @type {string[]} */
    const zeroTermDictionaries = [];
    for (const entry of dictionaryInfoEntries) {
        const title = typeof entry.title === 'string' && entry.title.length > 0 ? entry.title : '(unknown-title)';
        titles.push(title);
        if (entry.importSuccess !== true) {
            importFailures.push(title);
        }
        const counts = entry.counts;
        let termsTotal = 0;
        if (
            typeof counts === 'object' &&
            counts !== null &&
            !Array.isArray(counts) &&
            typeof Reflect.get(counts, 'terms') === 'object' &&
            Reflect.get(counts, 'terms') !== null &&
            !Array.isArray(Reflect.get(counts, 'terms')) &&
            Number.isFinite(Number(Reflect.get(Reflect.get(counts, 'terms'), 'total')))
        ) {
            termsTotal = Number(Reflect.get(Reflect.get(counts, 'terms'), 'total'));
        }
        if (termsTotal <= 0) {
            zeroTermDictionaries.push(title);
        }
    }
    return {titles, importFailures, zeroTermDictionaries};
}

/**
 * @param {Record<string, unknown>} diagnostics
 * @param {string[]} expectedDictionaryNames
 * @returns {boolean}
 */
function diagnosticsShowExpectedDictionaryCoverage(diagnostics, expectedDictionaryNames) {
    const termDictionaryNames = Array.isArray(diagnostics.termDictionaryNames) ?
        diagnostics.termDictionaryNames.map((value) => String(value || '').trim()).filter((value) => value.length > 0) :
        [];
    return expectedDictionaryNames.every((expectedName) => (
        termDictionaryNames.some((title) => matchesDictionaryName(title, expectedName))
    ));
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} term
 * @param {string[]} expectedDictionaryNames
 * @param {number} [timeoutMs]
 * @returns {Promise<{ok: boolean, diagnostics: Record<string, unknown>}>}
 */
async function waitForBackendDictionaryLookupCoverage(driver, term, expectedDictionaryNames, timeoutMs = 15_000) {
    const deadline = safePerformance.now() + timeoutMs;
    /** @type {Record<string, unknown>} */
    let diagnostics = {};
    while (safePerformance.now() < deadline) {
        diagnostics = await getBackendLookupDiagnostics(driver, term);
        if (diagnosticsShowExpectedDictionaryCoverage(diagnostics, expectedDictionaryNames)) {
            return {ok: true, diagnostics};
        }
        await driver.sleep(250);
    }
    return {ok: false, diagnostics};
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {Record<string, unknown>} recommendedDictionaries
 * @returns {Promise<void>}
 */
async function installRecommendedDictionariesMock(driver, recommendedDictionaries) {
    await driver.executeScript(`
        const data = structuredClone(arguments[0]);
        // Force per-dictionary imports for Firefox E2E to avoid session-final export failures
        // that can leave settings populated while term data is missing.
        window.manabitanImportUseSession = false;

        const originalFetch = window.fetch.bind(window);
        window.__manabitanMockSeenUrls = [];
        window.fetch = async (input, init) => {
            const url = String(typeof input === 'string' ? input : input?.url || '');
            if (Array.isArray(window.__manabitanMockSeenUrls)) {
                window.__manabitanMockSeenUrls.push(url);
                if (window.__manabitanMockSeenUrls.length > 64) {
                    window.__manabitanMockSeenUrls.splice(0, window.__manabitanMockSeenUrls.length - 64);
                }
            }
            if (url.includes('recommended-dictionaries.json')) {
                return new Response(JSON.stringify(data), {
                    status: 200,
                    headers: {'Content-Type': 'application/json'},
                });
            }
            return originalFetch(input, init);
        };
    `, recommendedDictionaries);
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<{ok: boolean, dictionaryCount: number|null, error: string|null}>}
 */
async function checkBackendApiAvailability(driver) {
    // Selenium executeAsyncScript return value is untyped (`any`).

    const result = await driver.executeAsyncScript(`
        const done = arguments[arguments.length - 1];
        const send = (action, params) => new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({action, params}, (response) => {
                const runtimeError = chrome.runtime.lastError;
                if (runtimeError) {
                    reject(new Error(runtimeError.message || String(runtimeError)));
                    return;
                }
                if (response && typeof response === 'object' && 'error' in response) {
                    reject(new Error(JSON.stringify(response.error)));
                    return;
                }
                resolve(response && typeof response === 'object' ? response.result : response);
            });
        });
        (async () => {
            const dictionaryInfo = await send('getDictionaryInfo', undefined);
            done({
                ok: true,
                dictionaryCount: Array.isArray(dictionaryInfo) ? dictionaryInfo.length : null,
                error: null,
            });
        })().catch((e) => {
            done({
                ok: false,
                dictionaryCount: null,
                error: String(e && e.message ? e.message : e),
            });
        });
    `);
    if (!(typeof result === 'object' && result !== null && !Array.isArray(result))) {
        return {ok: false, dictionaryCount: null, error: `Unexpected backend preflight payload: ${String(result)}`};
    }
    // Selenium executeAsyncScript return value is untyped (`any`).

    const resultRecord = /** @type {Record<string, unknown>} */ (result);
    const dictionaryCountValue = resultRecord.dictionaryCount;
    const errorValue = resultRecord.error;
    return {
        ok: resultRecord.ok === true,
        dictionaryCount: Number.isFinite(Number(dictionaryCountValue)) ? Number(dictionaryCountValue) : null,
        error: typeof errorValue === 'string' ? errorValue : null,
    };
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<{ok: boolean, error: string|null}>}
 */
async function purgeBackendDatabase(driver) {
    // Selenium executeAsyncScript return value is untyped (`any`).

    const result = await driver.executeAsyncScript(`
        const done = arguments[arguments.length - 1];
        const send = (action, params) => new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({action, params}, (response) => {
                const runtimeError = chrome.runtime.lastError;
                if (runtimeError) {
                    reject(new Error(runtimeError.message || String(runtimeError)));
                    return;
                }
                if (response && typeof response === 'object' && 'error' in response) {
                    reject(new Error(JSON.stringify(response.error)));
                    return;
                }
                resolve(response && typeof response === 'object' ? response.result : response);
            });
        });
        (async () => {
            await send('purgeDatabase', undefined);
            const optionsFull = await send('optionsGetFull', undefined);
            const nextOptions = structuredClone(optionsFull);
            for (const profile of nextOptions.profiles || []) {
                if (!profile?.options) { continue; }
                profile.options.dictionaries = [];
            }
            await send('setAllSettings', {value: nextOptions, source: 'firefox-e2e-purge'});
            done({ok: true, error: null});
        })().catch((e) => {
            done({
                ok: false,
                error: String(e && e.message ? e.message : e),
            });
        });
    `);
    if (!(typeof result === 'object' && result !== null && !Array.isArray(result))) {
        return {ok: false, error: `Unexpected purge payload: ${String(result)}`};
    }
    const record = /** @type {Record<string, unknown>} */ (result);
    return {
        ok: record.ok === true,
        error: typeof record.error === 'string' ? record.error : null,
    };
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<Record<string, unknown>|null>}
 */
async function getBackendStorageDiagnostics(driver) {
    // Selenium executeAsyncScript return value is untyped (`any`).

    const result = await driver.executeAsyncScript(`
        const done = arguments[arguments.length - 1];
        const runtime = window.chrome?.runtime ?? window.browser?.runtime;
        if (!(runtime && typeof runtime.sendMessage === 'function')) {
            done({ok: false, error: 'Extension runtime API unavailable in current page'});
            return;
        }
        runtime.sendMessage({action: 'debugDictionaryStorageState', params: undefined}, (response) => {
            const runtimeError = runtime.lastError;
            if (runtimeError) {
                done({ok: false, error: runtimeError.message || String(runtimeError)});
                return;
            }
            if (!(response && typeof response === 'object')) {
                done({ok: false, error: 'Unexpected storage diagnostics payload'});
                return;
            }
            if ('error' in response) {
                done({ok: false, error: JSON.stringify(response.error)});
                return;
            }
            done({ok: true, result: response.result});
        });
    `);
    if (!(typeof result === 'object' && result !== null && !Array.isArray(result))) {
        return null;
    }
    const record = /** @type {Record<string, unknown>} */ (result);
    if (record.ok !== true) { return null; }
    const payload = record.result;
    return (typeof payload === 'object' && payload !== null && !Array.isArray(payload)) ? /** @type {Record<string, unknown>} */ (payload) : null;
}

/**
 * @param {Record<string, unknown>|null} diagnostics
 * @returns {string}
 */
function summarizeBackendStorageDiagnostics(diagnostics) {
    if (diagnostics === null) { return 'storage=null'; }
    const dictionaryRows = Array.isArray(diagnostics.dictionaryRows) ? diagnostics.dictionaryRows : [];
    const offscreenDictionaryRows = Array.isArray(diagnostics.offscreenDictionaryRows) ? diagnostics.offscreenDictionaryRows : [];
    const dictionaryRowTitles = dictionaryRows
        .map((row) => (typeof row?.title === 'string' ? row.title : null))
        .filter((value) => typeof value === 'string' && value.length > 0);
    const offscreenDictionaryRowTitles = offscreenDictionaryRows
        .map((row) => (typeof row?.title === 'string' ? row.title : null))
        .filter((value) => typeof value === 'string' && value.length > 0);
    const lastDictionaryUrlImportDebug = diagnostics.lastDictionaryUrlImportDebug;
    const lastDictionaryUrlImportStage = (typeof lastDictionaryUrlImportDebug === 'object' && lastDictionaryUrlImportDebug !== null && !Array.isArray(lastDictionaryUrlImportDebug) && typeof lastDictionaryUrlImportDebug.stage === 'string') ?
        lastDictionaryUrlImportDebug.stage :
        null;
    return JSON.stringify({
        usesFallbackStorage: diagnostics.usesFallbackStorage ?? null,
        dictionaryRowsCount: dictionaryRows.length,
        dictionaryRowTitles,
        offscreenDictionaryRowsCount: offscreenDictionaryRows.length,
        offscreenDictionaryRowTitles,
        lastDictionaryUrlImportStage,
        startupCleanupIncompleteImportsSummary: diagnostics.offscreenStartupCleanupIncompleteImportsSummary ?? null,
        startupCleanupMissingTermRecordShardsSummary: diagnostics.offscreenStartupCleanupMissingTermRecordShardsSummary ?? null,
        offscreenTermRecordShardFileNames: Array.isArray(diagnostics.offscreenTermRecordShardFileNames) ? diagnostics.offscreenTermRecordShardFileNames : [],
    });
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} dictionaryTitle
 * @returns {Promise<{ok: boolean, error: string|null}>}
 */
async function deleteBackendDictionaryByTitle(driver, dictionaryTitle) {
    // Selenium executeAsyncScript return value is untyped (`any`).

    const result = await driver.executeAsyncScript(`
        const done = arguments[arguments.length - 1];
        const title = String(arguments[0] || '');
        const send = (action, params) => new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({action, params}, (response) => {
                const runtimeError = chrome.runtime.lastError;
                if (runtimeError) {
                    reject(new Error(runtimeError.message || String(runtimeError)));
                    return;
                }
                if (response && typeof response === 'object' && 'error' in response) {
                    reject(new Error(JSON.stringify(response.error)));
                    return;
                }
                resolve(response && typeof response === 'object' ? response.result : response);
            });
        });
        (async () => {
            await send('deleteDictionaryByTitle', {dictionaryTitle: title});
            done({ok: true, error: null});
        })().catch((e) => {
            done({
                ok: false,
                error: String(e && e.message ? e.message : e),
            });
        });
    `, dictionaryTitle);
    if (!(typeof result === 'object' && result !== null && !Array.isArray(result))) {
        return {ok: false, error: `Unexpected delete payload: ${String(result)}`};
    }
    const record = /** @type {Record<string, unknown>} */ (result);
    return {
        ok: record.ok === true,
        error: typeof record.error === 'string' ? record.error : null,
    };
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @param {string} expectedDictionaryName
 * @returns {Promise<{ok: boolean, error: string|null, deletedTitle: string|null}>}
 */
async function deleteBackendDictionaryByExpectedName(driver, expectedDictionaryName) {
    const diagnostics = await getBackendLookupDiagnostics(driver, '日本');
    const dictionaryInfoEntries = getDictionaryInfoEntries(diagnostics);
    const installedTitle = dictionaryInfoEntries
        .map((entry) => (typeof entry.title === 'string' ? entry.title.trim() : ''))
        .find((title) => matchesDictionaryName(title, expectedDictionaryName)) || null;
    if (installedTitle === null) {
        return {ok: false, error: `Unable to resolve installed dictionary title for ${expectedDictionaryName}`, deletedTitle: null};
    }
    const result = await deleteBackendDictionaryByTitle(driver, installedTitle);
    return {
        ok: result.ok,
        error: result.error,
        deletedTitle: installedTitle,
    };
}

/**
 * @param {import('selenium-webdriver').ThenableWebDriver} driver
 * @returns {Promise<Record<string, unknown>>}
 */
async function configureHoverTestOptions(driver) {
    // Selenium executeAsyncScript return value is untyped (`any`).

    const result = await driver.executeAsyncScript(`
        const done = arguments[arguments.length - 1];
        const send = (action, params) => new Promise((resolve, reject) => {
            chrome.runtime.sendMessage({action, params}, (response) => {
                const runtimeError = chrome.runtime.lastError;
                if (runtimeError) {
                    reject(new Error(runtimeError.message || String(runtimeError)));
                    return;
                }
                if (response && typeof response === 'object' && 'error' in response) {
                    reject(new Error(JSON.stringify(response.error)));
                    return;
                }
                resolve(response && typeof response === 'object' ? response.result : response);
            });
        });
        (async () => {
            const optionsFull = await send('optionsGetFull', undefined);
            const nextOptions = structuredClone(optionsFull);
            for (const profile of nextOptions.profiles || []) {
                if (!(profile && profile.options)) { continue; }
                if (profile.options.general && typeof profile.options.general === 'object') {
                    profile.options.general.enable = true;
                    profile.options.general.usePopupShadowDom = false;
                }
                if (profile.options.scanning && typeof profile.options.scanning === 'object') {
                    profile.options.scanning.delay = 0;
                    profile.options.scanning.hidePopupOnCursorExit = false;
                    profile.options.scanning.hidePopupOnCursorExitDelay = 0;
                    profile.options.scanning.scanWithoutMousemove = true;
                }
            }
            await send('setAllSettings', {value: nextOptions, source: 'firefox-e2e-hover-config'});
            const updatedOptions = await send('optionsGetFull', undefined);
            done({
                ok: true,
                profileGeneralEnable: (updatedOptions?.profiles || []).map((profile) => Boolean(profile?.options?.general?.enable)),
                profileUsePopupShadowDom: (updatedOptions?.profiles || []).map((profile) => Boolean(profile?.options?.general?.usePopupShadowDom)),
                profileScanningDelay: (updatedOptions?.profiles || []).map((profile) => Number(profile?.options?.scanning?.delay ?? -1)),
                profileScanWithoutMousemove: (updatedOptions?.profiles || []).map((profile) => Boolean(profile?.options?.scanning?.scanWithoutMousemove)),
            });
        })().catch((e) => {
            done({
                ok: false,
                error: String(e && e.message ? e.message : e),
            });
        });
    `);
    if (!(typeof result === 'object' && result !== null && !Array.isArray(result))) {
        return {ok: false, error: `Unexpected hover config payload: ${String(result)}`};
    }
    return /** @type {Record<string, unknown>} */ (result);
}

/**
 * @returns {Promise<void>}
 * @throws {Error}
 */
async function main() {
    const defaultFirefoxXpiPath = path.join(root, 'builds', 'manabitan-firefox-dev.xpi');
    const defaultFirefoxZipPath = path.join(root, 'builds', 'manabitan-firefox-dev.zip');
    let xpiPath = process.env.MANABITAN_FIREFOX_XPI ?? defaultFirefoxXpiPath;
    const configuredFirefoxProfileDir = String(process.env.MANABITAN_FIREFOX_PROFILE_DIR || '').trim();
    const reportPath = process.env.MANABITAN_FIREFOX_E2E_REPORT ?? path.join(root, 'builds', 'firefox-e2e-import-report.html');
    const reportJsonPath = reportPath.replace(/\.html$/i, '.json');
    const diagnosticsArtifactPaths = createDiagnosticsArtifactPaths(reportJsonPath);
    const chromiumReportPath = path.join(root, 'builds', 'chromium-e2e-import-report.html');
    const edgeReportPath = path.join(root, 'builds', 'edge-e2e-import-report.html');
    const combinedReportPath = path.join(root, 'builds', 'extension-e2e-report.html');
    const report = createReport();
    report.artifacts = {
        geckodriverLogPath: diagnosticsArtifactPaths.geckodriverLogPath,
        heartbeatJsonPath: diagnosticsArtifactPaths.heartbeatJsonPath,
        crashDumpDir: diagnosticsArtifactPaths.crashDumpDir,
    };
    const heartbeat = startHeartbeat(report, diagnosticsArtifactPaths.heartbeatJsonPath);
    let geckodriverLogFd = null;
    /** @type {Error | undefined} */
    let runError;
    if (process.env.MANABITAN_FIREFOX_XPI) {
        try {
            await access(xpiPath);
        } catch (_) {
            fail(`Extension package not found at: ${xpiPath}`);
        }
    } else {
        /** @type {Array<{path: string, mtimeMs: number}>} */
        const candidates = [];
        for (const candidatePath of [defaultFirefoxZipPath, defaultFirefoxXpiPath]) {
            try {
                const stats = await stat(candidatePath);
                candidates.push({
                    path: candidatePath,
                    mtimeMs: Number(stats.mtimeMs || 0),
                });
            } catch (_) {
                // Ignore missing candidate.
            }
        }
        if (candidates.length === 0) {
            fail(`Extension package not found at: ${defaultFirefoxZipPath} or ${defaultFirefoxXpiPath}`);
        }
        candidates.sort((a, b) => b.mtimeMs - a.mtimeMs);
        xpiPath = candidates[0].path;
    }
    const extensionPackageStats = await stat(xpiPath);
    const firefoxOptions = new firefox.Options();
    const headlessEnv = (process.env.MANABITAN_FIREFOX_HEADLESS ?? '1').trim().toLowerCase();
    const headless = !(headlessEnv === '0' || headlessEnv === 'false' || headlessEnv === 'no');
    if (headless) {
        firefoxOptions.addArguments('-headless');
    }
    firefoxOptions.setPreference('xpinstall.signatures.required', false);
    firefoxOptions.setPreference('extensions.manifestV3.enabled', true);
    firefoxOptions.setPreference('extensions.backgroundServiceWorker.enabled', true);
    firefoxOptions.setPreference(
        'extensions.webextensions.uuids',
        JSON.stringify({[firefoxDevGeckoId]: firefoxDevExtensionUuid}),
    );
    // Selenium Firefox profiles can start with stricter defaults that keep
    // SharedArrayBuffer unavailable even when extension pages set COOP/COEP.
    // Ensure test runtime exposes the required shared-memory primitives for OPFS.
    firefoxOptions.setPreference('javascript.options.shared_memory', true);
    firefoxOptions.setPreference('dom.postMessage.sharedArrayBuffer.withCOOP_COEP', true);
    firefoxOptions.setPreference('dom.postMessage.sharedArrayBuffer.bypassCOOP_COEP.insecure.enabled', true);
    const configuredFirefoxBinary = String(process.env.MANABITAN_FIREFOX_BINARY || '').trim();
    let selectedFirefoxBinary = configuredFirefoxBinary;
    if (configuredFirefoxBinary.length > 0) {
        try {
            await access(configuredFirefoxBinary);
        } catch (_) {
            fail(`Configured Firefox binary not found: ${configuredFirefoxBinary}`);
        }
        firefoxOptions.setBinary(configuredFirefoxBinary);
    } else {
        const firefoxStablePath = '/Applications/Firefox.app/Contents/MacOS/firefox';
        const firefoxDeveloperEditionPath = '/Applications/Firefox Developer Edition.app/Contents/MacOS/firefox';
        for (const candidatePath of [firefoxStablePath, firefoxDeveloperEditionPath]) {
            try {
                await access(candidatePath);
                firefoxOptions.setBinary(candidatePath);
                selectedFirefoxBinary = candidatePath;
                break;
            } catch (_) {
                // Try the next known macOS installation, then Selenium's default.
            }
        }
    }
    if (configuredFirefoxProfileDir.length > 0) {
        await mkdir(configuredFirefoxProfileDir, {recursive: true});
        firefoxOptions.setProfile(configuredFirefoxProfileDir);
    }
    console.log(`[firefox-e2e] addon package: path=${xpiPath} sizeBytes=${String(extensionPackageStats.size)} installMode=webdriver-addon headless=${String(headless)} binary=${selectedFirefoxBinary || 'default'} profileDir=${configuredFirefoxProfileDir || 'temporary'}`);
    await mkdir(diagnosticsArtifactPaths.crashDumpDir, {recursive: true});
    geckodriverLogFd = openSync(diagnosticsArtifactPaths.geckodriverLogPath, 'a');
    const firefoxService = new firefox.ServiceBuilder('/workspace/scratch/7b5a4ac440c8/runtime/firefox-bundle/geckodriver').setHostname('127.0.0.1');
    // Firefox 138+ requires explicit access for scripts in moz-extension pages.
    // Only the isolated WebDriver test process receives this privilege.
    firefoxService.addArguments('--allow-system-access');
    firefoxService.enableVerboseLogging(true);
    firefoxService.setEnvironment({
        ...process.env,
        MINIDUMP_SAVE_PATH: diagnosticsArtifactPaths.crashDumpDir,
        MOZ_CRASHREPORTER: '1',
        MOZ_CRASHREPORTER_SHUTDOWN: '1',
        MOZ_CRASHREPORTER_NO_REPORT: '1',
    });
    firefoxService.setStdio(['ignore', geckodriverLogFd, geckodriverLogFd]);
    /** @type {import('selenium-webdriver/firefox.js').Driver|null} */
    let driver = null;
    try {
        driver = /** @type {import('selenium-webdriver/firefox.js').Driver} */ (
            await new Builder()
                .forBrowser(Browser.FIREFOX)
                .setFirefoxOptions(firefoxOptions)
                .setFirefoxService(firefoxService)
                .build()
        );
        await driver.getWindowHandle();
    } catch (e) {
        const failureReason = errorMessage(e);
        const skipReason = strictUnsupportedRuntime ? '' : getUnsupportedRuntimeSkipReason(failureReason);
        if (skipReason.length === 0) {
            throw e;
        }
        report.status = 'success-with-skips';
        report.skippedVerification = true;
        report.skipReason = skipReason;
        console.warn(`[firefox-e2e] warning: ${skipReason}`);
        if (geckodriverLogFd !== null) {
            closeSync(geckodriverLogFd);
        }
        // Selenium may still have a rejected startup command queued after the
        // Marionette port failure. Exit immediately after classifying the local
        // unsupported runtime so the queued rejection does not fail non-strict runs.
        process.exit(0);
    }
    /** @type {null|{close: () => Promise<void>, baseUrl: string}} */
    let localServer = null;
    /** @type {string} */
    let installedAddonId = '';
    try {
        heartbeat.setActiveOperation('cache warmup');
        const cacheWarmupStart = safePerformance.now();
        const cachedDictionaries = await ensureRealDictionaryCache();
        const jitendexArchiveProbeTerms = await loadDictionaryProbeTermsFromArchive(cachedDictionaries.jitendexPath, 80);
        const jmdictArchiveProbeTerms = await loadDictionaryProbeTermsFromArchive(cachedDictionaries.jmdictPath, 80);
        const jmnedictArchiveProbeTerms = await loadDictionaryProbeTermsFromArchive(cachedDictionaries.jmnedictPath, 80);
        const jitendexLookupProbeCandidates = [...new Set([...lookupWords, ...jitendexArchiveProbeTerms])];
        const extendedLookupProbeCandidates = [...new Set([...lookupWords, ...jitendexArchiveProbeTerms, ...jmdictProbeTerms, ...jmdictArchiveProbeTerms, ...jmnedictArchiveProbeTerms])];
        localServer = await startE2ELocalServer({
            jitendexPath: cachedDictionaries.jitendexPath,
            jmnedictPath: cachedDictionaries.jmnedictPath,
            jmdictPath: cachedDictionaries.jmdictPath,
        });
        const cacheWarmupEnd = safePerformance.now();
        const firefoxPid = await getFirefoxProcessId(driver);

        const baseUrlStart = safePerformance.now();
        heartbeat.setActiveOperation('wait for extension base URL');
        installedAddonId = await driver.installAddon(xpiPath, true);
        const extensionBaseUrl = await waitForExtensionBaseUrl(driver, installedAddonId);
        const baseUrlEnd = safePerformance.now();
        await addReportPhase(report, driver, 'Install extension and discover base URL', `Extension installed via webdriver addon API and moz-extension base URL discovered; addonId=${installedAddonId}`, baseUrlStart, baseUrlEnd);
        const firefoxPidStart = safePerformance.now();
        const firefoxPidEnd = safePerformance.now();
        await addReportPhase(report, driver, 'Firefox process detection', `Detected Firefox browser PID for profiling: ${firefoxPid !== null ? String(firefoxPid) : 'unavailable'}`, firefoxPidStart, firefoxPidEnd);

        const settingsOpenStart = safePerformance.now();
        heartbeat.setActiveOperation('open settings page');
        await navigateToExtensionPage(
            driver,
            `${extensionBaseUrl}/settings.html`,
            By.css('#dictionary-import-file-input'),
            {attempts: 3, pageLoadTimeoutMs: 15_000, readyTimeoutMs: 30_000},
        );
        await ensurePageProfiler(driver);
        const grantedPermissions = await driver.executeAsyncScript(`
            const done = arguments[arguments.length - 1];
            browser.permissions.getAll().then(done, (error) => done({error: String(error)}));
        `);
        console.log(`[firefox-e2e] granted permissions: ${JSON.stringify(grantedPermissions)}`);
        const settingsOpenEnd = safePerformance.now();
        await addReportPhase(report, driver, 'Open settings page', 'Settings loaded and dictionary import controls visible', settingsOpenStart, settingsOpenEnd);
        if (!existingProfileOnly) {
            const resetStateStart = safePerformance.now();
            heartbeat.setActiveOperation('purge backend database');
            const resetState = await purgeBackendDatabase(driver);
            const resetStateEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Reset dictionary settings',
                resetState.ok ?
                    'Purged backend dictionary database and cleared profile dictionary enablement state before import' :
                    `Backend purge failed: ${String(resetState.error || 'unknown error')}`,
                resetStateStart,
                resetStateEnd,
            );
            if (!resetState.ok) {
                fail(`Backend purge failed before Firefox import flow: ${String(resetState.error || 'unknown error')}`);
            }
        } else {
            await addReportPhase(
                report,
                driver,
                'Preserve existing dictionary settings',
                'Skipped backend purge so the current Firefox profile state can be validated across build transitions.',
                settingsOpenEnd,
                settingsOpenEnd,
            );
        }
        // Selenium executeScript return value is untyped (`any`).

        const runtimeDiagnostics = await driver.executeAsyncScript(`
            const done = arguments[0];
            (async () => {
                let startupDiagnosticsSnapshot = null;
                try {
                    startupDiagnosticsSnapshot = await new Promise((resolve) => {
                        chrome.storage.local.get(['manabitanStartupDiagnostics'], (value) => {
                            const runtimeError = chrome.runtime.lastError;
                            if (runtimeError) {
                                resolve({error: runtimeError.message || String(runtimeError)});
                                return;
                            }
                            const snapshot = value && typeof value === 'object' ? value.manabitanStartupDiagnostics : null;
                            resolve(snapshot ?? null);
                        });
                    });
                } catch (_) {
                    startupDiagnosticsSnapshot = null;
                }
                const startupOpenStorageDiagnostics = (
                    startupDiagnosticsSnapshot &&
                    typeof startupDiagnosticsSnapshot === 'object' &&
                    !Array.isArray(startupDiagnosticsSnapshot) &&
                    typeof startupDiagnosticsSnapshot.dictionaryOpenStorageDiagnostics === 'object' &&
                    startupDiagnosticsSnapshot.dictionaryOpenStorageDiagnostics !== null
                ) ? startupDiagnosticsSnapshot.dictionaryOpenStorageDiagnostics : null;
                done({
                    hasStorageGetDirectory: !!(navigator.storage && typeof navigator.storage.getDirectory === 'function'),
                    hasCreateSyncAccessHandle: !!(
                        window.FileSystemFileHandle &&
                        window.FileSystemFileHandle.prototype &&
                        typeof window.FileSystemFileHandle.prototype.createSyncAccessHandle === 'function'
                    ),
                    hasOpfsSahpoolVfs: (
                        startupOpenStorageDiagnostics &&
                        typeof startupOpenStorageDiagnostics.hasOpfsSahpoolVfs === 'boolean'
                    ) ? startupOpenStorageDiagnostics.hasOpfsSahpoolVfs : false,
                    opfsSahpoolInstallResult: (
                        startupOpenStorageDiagnostics &&
                        typeof startupOpenStorageDiagnostics.opfsSahpoolInstallResult === 'string'
                    ) ? startupOpenStorageDiagnostics.opfsSahpoolInstallResult : null,
                    openStorageMode: (
                        startupOpenStorageDiagnostics &&
                        typeof startupOpenStorageDiagnostics.mode === 'string'
                    ) ? startupOpenStorageDiagnostics.mode : null,
                    openStorageDiagnostics: startupOpenStorageDiagnostics,
                    startupDiagnosticsSnapshot,
                });
            })();
        `);
        report.runtimeDiagnostics = asRecordOrNull(runtimeDiagnostics);
        const diagnosticsStart = safePerformance.now();
        const diagnosticsEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Runtime diagnostics',
            `Firefox sahpool diagnostics: ${JSON.stringify(runtimeDiagnostics)}`,
            diagnosticsStart,
            diagnosticsEnd,
        );
        if (!isOpfsRuntimeAvailable(runtimeDiagnostics)) {
            fail(`Firefox runtime does not satisfy opfs-sahpool prerequisites: ${JSON.stringify(runtimeDiagnostics)}`);
        }
        const backendPreflightStart = safePerformance.now();
        heartbeat.setActiveOperation('backend API preflight');
        const backendPreflight = await checkBackendApiAvailability(driver);
        const backendPreflightEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Backend API preflight',
            backendPreflight.ok ?
                `Runtime message API reachable; dictionaryInfo count=${String(backendPreflight.dictionaryCount)}` :
                `Runtime message API failed: ${String(backendPreflight.error || 'unknown error')}`,
            backendPreflightStart,
            backendPreflightEnd,
        );
        if (!backendPreflight.ok) {
            fail(`Backend preflight failed: ${String(backendPreflight.error || 'unknown error')}`);
        }

        if (existingProfileOnly && focusedBaselineOnly && focusedSecondaryDictionary === 'JMnedict') {
            const existingSearchTabOpenStart = safePerformance.now();
            await openSearchPageInNewTab(driver, extensionBaseUrl);
            const existingSearchTabOpenEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Open dedicated search tab from existing profile',
                'Opened search.html using the persisted Firefox profile without reimporting dictionaries.',
                existingSearchTabOpenStart,
                existingSearchTabOpenEnd,
            );
            const existingKuuSearchStart = safePerformance.now();
            const existingKuuSearchCounts = await searchTermAndGetDictionaryHitCounts(driver, '食う', ['Jitendex'], 20_000);
            const existingKuuSearchEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Verify Jitendex 食う lookup from existing profile',
                `Dedicated search tab returned counts for 食う from the persisted profile: ${JSON.stringify(existingKuuSearchCounts)}`,
                existingKuuSearchStart,
                existingKuuSearchEnd,
            );
            if ((existingKuuSearchCounts.Jitendex ?? 0) < 1) {
                const backendDiagnostics = await getBackendLookupDiagnostics(driver, '食う');
                const searchDiagnostics = await getSearchPageDiagnostics(driver);
                fail(`Expected Jitendex lookup for 食う from the persisted profile; saw ${JSON.stringify(existingKuuSearchCounts)} backend=${JSON.stringify(backendDiagnostics)} diagnostics=${JSON.stringify(searchDiagnostics)}`);
            }
            const existingNameSearchStart = safePerformance.now();
            const existingNameSearchCounts = await searchTermAndGetDictionaryHitCounts(driver, 'はじめ', ['JMnedict'], 20_000);
            const existingNameSearchEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Verify JMnedict はじめ lookup from existing profile',
                `Dedicated search tab returned counts for はじめ from the persisted profile: ${JSON.stringify(existingNameSearchCounts)}`,
                existingNameSearchStart,
                existingNameSearchEnd,
            );
            if ((existingNameSearchCounts.JMnedict ?? 0) < 1) {
                const backendDiagnostics = await getBackendLookupDiagnostics(driver, 'はじめ');
                const searchDiagnostics = await getSearchPageDiagnostics(driver);
                fail(`Expected JMnedict lookup for はじめ from the persisted profile; saw ${JSON.stringify(existingNameSearchCounts)} backend=${JSON.stringify(backendDiagnostics)} diagnostics=${JSON.stringify(searchDiagnostics)}`);
            }
            if (profileCycle) {
                await driver.switchTo().window(settingsWindowHandle);
                const deleteJitendexStart = safePerformance.now();
                const deleteJitendexResult = await deleteBackendDictionaryByExpectedName(driver, 'Jitendex');
                const deleteJitendexEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Delete Jitendex from persisted profile',
                    `Deleted Jitendex from the persisted Firefox profile: ${JSON.stringify(deleteJitendexResult)}`,
                    deleteJitendexStart,
                    deleteJitendexEnd,
                );
                if (!deleteJitendexResult.ok) {
                    fail(`Failed to delete Jitendex from persisted profile: ${JSON.stringify(deleteJitendexResult)}`);
                }
                await driver.sleep(1_000);
                const reinstallFeedStart = safePerformance.now();
                await installRecommendedDictionariesMock(driver, {
                    ja: {
                        terms: [
                            {
                                name: 'Jitendex',
                                description: 'Real Jitendex from recommended dictionaries',
                                homepage: '',
                                downloadUrl: `${localServer.baseUrl}/dictionaries/jitendex.zip`,
                            },
                            createFocusedRecommendedTermsDictionary('JMnedict', localServer),
                        ],
                        kanji: [],
                        frequency: [],
                        grammar: [],
                        pronunciation: [],
                    },
                });
                const reinstallFeedEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Reinstall mocked recommended dictionary feed',
                    'Reinstalled the mocked recommended feed after deleting Jitendex from the persisted profile.',
                    reinstallFeedStart,
                    reinstallFeedEnd,
                );
                const reinstallJitendexClickStart = safePerformance.now();
                const reinstallJitendexImportUrl = await installRecommendedDictionary(driver, 'Jitendex');
                const reinstallJitendexClickEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Click Jitendex download after delete',
                    `Triggered recommended Jitendex import via URL after delete: ${reinstallJitendexImportUrl}`,
                    reinstallJitendexClickStart,
                    reinstallJitendexClickEnd,
                );
                const reinstallJitendexProfileStart = safePerformance.now();
                await beginPageProfilePhase(driver);
                const reinstallJitendexSampler = startFirefoxResourceSampler(firefoxPid);
                await waitForImportWithPhaseScreenshots(driver, report, 'Jitendex', '2 installed, 2 enabled', 300_000);
                const reinstallJitendexResourceSummary = await reinstallJitendexSampler.stop();
                const reinstallJitendexPageSummary = await endPageProfilePhase(driver);
                const reinstallJitendexProfileEnd = safePerformance.now();
                const reinstallJitendexImportDebug = await getLastImportDebug(driver);
                await addReportPhase(
                    report,
                    driver,
                    'Jitendex reimport resource profile',
                    `${formatResourceSummary(reinstallJitendexResourceSummary)} longTasks={count:${String(reinstallJitendexPageSummary.longTaskCount)},totalMs:${reinstallJitendexPageSummary.longTaskTotalMs.toFixed(1)},peakMs:${reinstallJitendexPageSummary.longTaskPeakMs.toFixed(1)}} importDebug=${JSON.stringify(reinstallJitendexImportDebug)}`,
                    reinstallJitendexProfileStart,
                    reinstallJitendexProfileEnd,
                );
                await driver.switchTo().window(searchWindowHandle);
                const postCycleSearchTabStart = safePerformance.now();
                const postCycleSearchWindowHandle = /** @type {string} */ (await openSearchPageInNewTab(driver, extensionBaseUrl));
                const postCycleSearchTabEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Open dedicated search tab after delete and reinstall',
                    'Opened a fresh search.html tab after Jitendex was deleted and reinstalled, instead of reusing the pre-delete tab.',
                    postCycleSearchTabStart,
                    postCycleSearchTabEnd,
                );
                await driver.switchTo().window(postCycleSearchWindowHandle);
                const postCycleKuuSearchStart = safePerformance.now();
                const postCycleKuuSearchCounts = await searchTermAndGetDictionaryHitCounts(driver, '食う', ['Jitendex'], 20_000);
                const postCycleKuuSearchEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Verify Jitendex 食う lookup after delete and reinstall',
                    `Dedicated search tab returned counts for 食う after delete/reinstall: ${JSON.stringify(postCycleKuuSearchCounts)}`,
                    postCycleKuuSearchStart,
                    postCycleKuuSearchEnd,
                );
                if ((postCycleKuuSearchCounts.Jitendex ?? 0) < 1) {
                    const backendDiagnostics = await getBackendLookupDiagnostics(driver, '食う');
                    const searchDiagnostics = await getSearchPageDiagnostics(driver);
                    fail(`Expected Jitendex lookup for 食う after delete/reinstall; saw ${JSON.stringify(postCycleKuuSearchCounts)} backend=${JSON.stringify(backendDiagnostics)} diagnostics=${JSON.stringify(searchDiagnostics)}`);
                }
                await addReportPhase(
                    report,
                    driver,
                    'Focused profile-cycle verification complete',
                    'Reimported Jitendex after deletion and verified its lookup in the persisted Firefox profile.',
                    postCycleKuuSearchEnd,
                    postCycleKuuSearchEnd,
                );
                report.status = 'success';
                console.log('[firefox-e2e] PASS: Focused dictionary delete + reimport completed.');
                return;
            }
            await addReportPhase(
                report,
                driver,
                'Focused existing-profile verification complete',
                'Verified Jitendex + JMnedict lookups from a persisted Firefox profile without reimporting dictionaries.',
                existingNameSearchEnd,
                existingNameSearchEnd,
            );
            return;
        }

        await addReportPhase(
            report,
            driver,
            'Warmup real dictionary cache',
            `Resolved and cached Jitendex/JMdict archives from recommended feed, then served locally at ${localServer.baseUrl}`,
            cacheWarmupStart,
            cacheWarmupEnd,
        );

        const mockRecommendedDictionaries = {
            ja: {
                terms: [
                    {
                        name: 'Jitendex',
                        description: 'Real Jitendex from recommended dictionaries',
                        homepage: '',
                        downloadUrl: `${localServer.baseUrl}/dictionaries/jitendex.zip`,
                    },
                    createFocusedRecommendedTermsDictionary(
                        (focusedSecondaryDictionary === 'JMnedict') ? 'JMnedict' : 'JMdict',
                        localServer,
                    ),
                ],
                kanji: [],
                frequency: [],
                grammar: [],
                pronunciation: [],
            },
        };
        const mockInstallStart = safePerformance.now();
        await installRecommendedDictionariesMock(driver, mockRecommendedDictionaries);
        const mockInstallEnd = safePerformance.now();
        await addReportPhase(report, driver, 'Install mocked recommended dictionary feed', 'recommended-dictionaries.json overridden to use local server URLs for real Jitendex and JMdict archives', mockInstallStart, mockInstallEnd);

        const jitendexClickStart = safePerformance.now();
        const jitendexImportUrl = await installRecommendedDictionary(driver, 'Jitendex');
        const jitendexClickEnd = safePerformance.now();
        await addReportPhase(report, driver, 'Click Jitendex download', `Triggered recommended Jitendex import via URL: ${jitendexImportUrl}`, jitendexClickStart, jitendexClickEnd);
        const jitendexProfileStart = safePerformance.now();
        await beginPageProfilePhase(driver);
        const jitendexSampler = startFirefoxResourceSampler(firefoxPid);
        await waitForImportWithPhaseScreenshots(driver, report, 'Jitendex', '1 installed, 1 enabled', 300_000);
        const jitendexResourceSummary = await jitendexSampler.stop();
        const jitendexPageSummary = await endPageProfilePhase(driver);
        const jitendexProfileEnd = safePerformance.now();
        const jitendexImportDebug = await getLastImportDebug(driver);
        const jitendexUsesFallbackStorage = jitendexImportDebug?.usesFallbackStorage === true;
        if (
            jitendexImportDebug !== null &&
            (
                Number(jitendexImportDebug.errorCount || 0) > 0 ||
                jitendexUsesFallbackStorage
            )
        ) {
            fail(`Jitendex import debug indicates OPFS was not used: ${JSON.stringify(jitendexImportDebug)}`);
        }
        await addReportPhase(
            report,
            driver,
            'Jitendex import resource profile',
            `${formatResourceSummary(jitendexResourceSummary)} longTasks={count:${String(jitendexPageSummary.longTaskCount)},totalMs:${jitendexPageSummary.longTaskTotalMs.toFixed(1)},peakMs:${jitendexPageSummary.longTaskPeakMs.toFixed(1)}} topMeasures=${JSON.stringify(jitendexPageSummary.topMeasures)} topLongTasks=${JSON.stringify(jitendexPageSummary.topLongTasks)} importDebug=${JSON.stringify(jitendexImportDebug)}`,
            jitendexProfileStart,
            jitendexProfileEnd,
        );
        const verifyJitendexContentStart = safePerformance.now();
        const verifyJitendexContentProfile = await waitForBackendDictionaryContentIntegrity(
            driver,
            ['Jitendex'],
            jitendexLookupProbeCandidates,
            15_000,
        );
        const verifyJitendexContentEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Verify Jitendex backend content integrity after import',
            `Checked that imported Jitendex term-content spans are readable and in bounds before opening the concurrent search tab: ${JSON.stringify(verifyJitendexContentProfile)}`,
            verifyJitendexContentStart,
            verifyJitendexContentEnd,
        );
        if (verifyJitendexContentProfile.ok !== true) {
            fail(`Jitendex backend content integrity failed after import. diagnostics=${JSON.stringify(verifyJitendexContentProfile)}`);
        }
        const jitendexSettleStart = safePerformance.now();
        await driver.sleep(2_000);
        const jitendexSettleEnd = safePerformance.now();
        await addReportPhase(report, driver, 'Jitendex: settle after progress clear', 'Waited 2000ms after progress text cleared before starting next import', jitendexSettleStart, jitendexSettleEnd);

        if (focusedBaselineOnly && focusedSecondaryDictionary === 'JMnedict') {
            const jmnedictClickStart = safePerformance.now();
            const jmnedictImportUrl = await installRecommendedDictionary(driver, 'JMnedict');
            const jmnedictClickEnd = safePerformance.now();
            await addReportPhase(report, driver, 'Click JMnedict download', `Triggered recommended JMnedict import via URL: ${jmnedictImportUrl}`, jmnedictClickStart, jmnedictClickEnd);
            const jmnedictProfileStart = safePerformance.now();
            await beginPageProfilePhase(driver);
            const jmnedictSampler = startFirefoxResourceSampler(firefoxPid);
            await waitForImportWithPhaseScreenshots(driver, report, 'JMnedict', '2 installed, 2 enabled', 300_000);
            const jmnedictResourceSummary = await jmnedictSampler.stop();
            const jmnedictPageSummary = await endPageProfilePhase(driver);
            const jmnedictProfileEnd = safePerformance.now();
            const jmnedictImportDebug = await getLastImportDebug(driver);
            await addReportPhase(
                report,
                driver,
                'JMnedict import resource profile',
                `${formatResourceSummary(jmnedictResourceSummary)} longTasks={count:${String(jmnedictPageSummary.longTaskCount)},totalMs:${jmnedictPageSummary.longTaskTotalMs.toFixed(1)},peakMs:${jmnedictPageSummary.longTaskPeakMs.toFixed(1)}} topMeasures=${JSON.stringify(jmnedictPageSummary.topMeasures)} topLongTasks=${JSON.stringify(jmnedictPageSummary.topLongTasks)} importDebug=${JSON.stringify(jmnedictImportDebug)}`,
                jmnedictProfileStart,
                jmnedictProfileEnd,
            );
            const verifyJmnedictContentStart = safePerformance.now();
            const verifyJmnedictContentProfile = await waitForBackendDictionaryContentIntegrity(
                driver,
                ['JMnedict'],
                extendedLookupProbeCandidates,
                15_000,
            );
            const verifyJmnedictContentEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Verify JMnedict backend content integrity after import',
                `Checked that imported JMnedict term-content spans are readable and in bounds before focused baseline search checks: ${JSON.stringify(verifyJmnedictContentProfile)}`,
                verifyJmnedictContentStart,
                verifyJmnedictContentEnd,
            );
            if (verifyJmnedictContentProfile.ok !== true) {
                fail(`JMnedict backend content integrity failed after import. diagnostics=${JSON.stringify(verifyJmnedictContentProfile)}`);
            }
        }

        // Selenium return values are untyped (`any`).

        const settingsWindowHandle = /** @type {string} */ (await driver.getWindowHandle());
        const searchTabOpenStart = safePerformance.now();
        const searchWindowHandle = /** @type {string} */ (await openSearchPageInNewTab(driver, extensionBaseUrl));
        const searchTabOpenEnd = safePerformance.now();
        await addReportPhase(report, driver, 'Open dedicated search tab', 'Opened search.html in a second tab so search can be exercised while settings keeps importing', searchTabOpenStart, searchTabOpenEnd);

        const initialSearchWhileIdleStart = safePerformance.now();
        const initialSearchWhileIdleCounts = await searchTermAndGetDictionaryHitCounts(driver, '暗記', ['Jitendex'], 20_000);
        const initialSearchWhileIdleEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Verify baseline Jitendex search before concurrent import',
            `Dedicated search tab returned counts: ${JSON.stringify(initialSearchWhileIdleCounts)}`,
            initialSearchWhileIdleStart,
            initialSearchWhileIdleEnd,
        );
        if ((initialSearchWhileIdleCounts.Jitendex ?? 0) < 1) {
            fail(`Expected baseline Jitendex lookup to work before concurrent import; saw ${JSON.stringify(initialSearchWhileIdleCounts)}`);
        }

        const baselineKuuSearchStart = safePerformance.now();
        const baselineKuuSearchCounts = await searchTermAndGetDictionaryHitCounts(driver, '食う', ['Jitendex'], 20_000);
        const baselineKuuSearchEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Verify baseline Jitendex 食う lookup after import',
            `Dedicated search tab returned counts for 食う: ${JSON.stringify(baselineKuuSearchCounts)}`,
            baselineKuuSearchStart,
            baselineKuuSearchEnd,
        );
        if ((baselineKuuSearchCounts.Jitendex ?? 0) < 1) {
            const backendDiagnostics = await getBackendLookupDiagnostics(driver, '食う');
            const searchDiagnostics = await getSearchPageDiagnostics(driver);
            fail(`Expected baseline Jitendex lookup for 食う after import; saw ${JSON.stringify(baselineKuuSearchCounts)} backend=${JSON.stringify(backendDiagnostics)} diagnostics=${JSON.stringify(searchDiagnostics)}`);
        }

        if (focusedBaselineOnly && focusedSecondaryDictionary === 'JMnedict') {
            const baselineNameSearchStart = safePerformance.now();
            const baselineNameSearchCounts = await searchTermAndGetDictionaryHitCounts(driver, 'はじめ', ['JMnedict'], 20_000);
            const baselineNameSearchEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Verify baseline JMnedict はじめ lookup after import',
                `Dedicated search tab returned counts for はじめ: ${JSON.stringify(baselineNameSearchCounts)}`,
                baselineNameSearchStart,
                baselineNameSearchEnd,
            );
            if ((baselineNameSearchCounts.JMnedict ?? 0) < 1) {
                const backendDiagnostics = await getBackendLookupDiagnostics(driver, 'はじめ');
                const searchDiagnostics = await getSearchPageDiagnostics(driver);
                fail(`Expected baseline JMnedict lookup for はじめ after import; saw ${JSON.stringify(baselineNameSearchCounts)} backend=${JSON.stringify(backendDiagnostics)} diagnostics=${JSON.stringify(searchDiagnostics)}`);
            }
            if (profileCycle) {
                await driver.switchTo().window(settingsWindowHandle);
                const preUninstallStorageDiagnostics = await getBackendStorageDiagnostics(driver);
                const preUninstallStorageTime = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Capture storage state before extension removal',
                    `Storage before add-on removal: ${summarizeBackendStorageDiagnostics(preUninstallStorageDiagnostics)}`,
                    preUninstallStorageTime,
                    preUninstallStorageTime,
                );
                const preUninstallWindowHandles = new Set((await driver.getAllWindowHandles()).map(String));
                await driver.executeScript('window.open("about:blank", "_blank");');
                const uninstallWindowHandle = await driver.wait(async () => {
                    const windowHandles = (await driver.getAllWindowHandles()).map(String);
                    return windowHandles.find((windowHandle) => !preUninstallWindowHandles.has(windowHandle)) ?? false;
                }, 30_000, 'Expected a normal blank tab to remain available after extension removal');
                await driver.switchTo().window(String(uninstallWindowHandle));
                await driver.get('about:blank');
                const uninstallExtensionStart = safePerformance.now();
                await driver.uninstallAddon(installedAddonId);
                const uninstallExtensionEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Remove extension before reinstalling',
                    'Uninstalled the Firefox add-on from the active profile before loading a fresh copy.',
                    uninstallExtensionStart,
                    uninstallExtensionEnd,
                );
                await driver.sleep(1_000);
                const reinstallExtensionStart = safePerformance.now();
                const reinstalledAddonId = await driver.installAddon(xpiPath, true);
                const reinstalledExtensionBaseUrl = await waitForExtensionBaseUrl(driver, reinstalledAddonId);
                const reinstallExtensionEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Reinstall extension after removal',
                    `Reinstalled the Firefox add-on and discovered base URL ${reinstalledExtensionBaseUrl} using addonId=${String(reinstalledAddonId)}`,
                    reinstallExtensionStart,
                    reinstallExtensionEnd,
                );
                const reopenSettingsStart = safePerformance.now();
                await navigateToExtensionPage(
                    driver,
                    `${reinstalledExtensionBaseUrl}/settings.html`,
                    By.css('#dictionary-import-file-input'),
                    {attempts: 3, pageLoadTimeoutMs: 15_000, readyTimeoutMs: 30_000},
                );
                await ensurePageProfiler(driver);
                const reopenSettingsEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Reopen settings page after reinstall',
                    'Opened a fresh settings.html page after extension removal and reinstall.',
                    reopenSettingsStart,
                    reopenSettingsEnd,
                );
                const reinstallStorageDiagnostics = await getBackendStorageDiagnostics(driver);
                await addReportPhase(
                    report,
                    driver,
                    'Capture storage state after extension reinstall',
                    `Storage after add-on reinstall before reimport: ${summarizeBackendStorageDiagnostics(reinstallStorageDiagnostics)}`,
                    reopenSettingsEnd,
                    reopenSettingsEnd,
                );
                const reinstallFeedStart = safePerformance.now();
                await installRecommendedDictionariesMock(driver, {
                    ja: {
                        terms: [
                            {
                                name: 'Jitendex',
                                description: 'Real Jitendex from recommended dictionaries',
                                homepage: '',
                                downloadUrl: `${localServer.baseUrl}/dictionaries/jitendex.zip`,
                            },
                            createFocusedRecommendedTermsDictionary('JMnedict', localServer),
                        ],
                        kanji: [],
                        frequency: [],
                        grammar: [],
                        pronunciation: [],
                    },
                });
                const reinstallFeedEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Reload mocked recommended dictionary feed after reinstall',
                    'Reloaded the mocked recommended feed after reinstalling the extension.',
                    reinstallFeedStart,
                    reinstallFeedEnd,
                );
                const reinstallJitendexClickStart = safePerformance.now();
                const reinstallJitendexImportUrl = await installRecommendedDictionary(driver, 'Jitendex');
                const reinstallJitendexClickEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Click Jitendex download after reinstall',
                    `Triggered recommended Jitendex import via URL after reinstall: ${reinstallJitendexImportUrl}`,
                    reinstallJitendexClickStart,
                    reinstallJitendexClickEnd,
                );
                const reinstallJitendexProfileStart = safePerformance.now();
                await beginPageProfilePhase(driver);
                const reinstallJitendexSampler = startFirefoxResourceSampler(firefoxPid);
                await waitForImportWithPhaseScreenshots(driver, report, 'Jitendex', '1 installed, 1 enabled', 300_000);
                const reinstallJitendexResourceSummary = await reinstallJitendexSampler.stop();
                const reinstallJitendexPageSummary = await endPageProfilePhase(driver);
                const reinstallJitendexProfileEnd = safePerformance.now();
                const reinstallJitendexImportDebug = await getLastImportDebug(driver);
                await addReportPhase(
                    report,
                    driver,
                    'Jitendex reinstall resource profile',
                    `${formatResourceSummary(reinstallJitendexResourceSummary)} longTasks={count:${String(reinstallJitendexPageSummary.longTaskCount)},totalMs:${reinstallJitendexPageSummary.longTaskTotalMs.toFixed(1)},peakMs:${reinstallJitendexPageSummary.longTaskPeakMs.toFixed(1)}} importDebug=${JSON.stringify(reinstallJitendexImportDebug)}`,
                    reinstallJitendexProfileStart,
                    reinstallJitendexProfileEnd,
                );
                const postJitendexStorageDiagnostics = await getBackendStorageDiagnostics(driver);
                await addReportPhase(
                    report,
                    driver,
                    'Capture storage state after Jitendex reinstall import',
                    `Storage after Jitendex import: ${summarizeBackendStorageDiagnostics(postJitendexStorageDiagnostics)}`,
                    reinstallJitendexProfileEnd,
                    reinstallJitendexProfileEnd,
                );
                const reinstallJmnedictClickStart = safePerformance.now();
                const reinstallJmnedictImportUrl = await installRecommendedDictionary(driver, 'JMnedict');
                const reinstallJmnedictClickEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Click JMnedict download after reinstall',
                    `Triggered recommended JMnedict import via URL after reinstall: ${reinstallJmnedictImportUrl}`,
                    reinstallJmnedictClickStart,
                    reinstallJmnedictClickEnd,
                );
                const reinstallJmnedictProfileStart = safePerformance.now();
                await beginPageProfilePhase(driver);
                const reinstallJmnedictSampler = startFirefoxResourceSampler(firefoxPid);
                await waitForImportWithPhaseScreenshots(driver, report, 'JMnedict', '2 installed, 2 enabled', 300_000);
                const reinstallJmnedictResourceSummary = await reinstallJmnedictSampler.stop();
                const reinstallJmnedictPageSummary = await endPageProfilePhase(driver);
                const reinstallJmnedictProfileEnd = safePerformance.now();
                const reinstallJmnedictImportDebug = await getLastImportDebug(driver);
                await addReportPhase(
                    report,
                    driver,
                    'JMnedict reinstall resource profile',
                    `${formatResourceSummary(reinstallJmnedictResourceSummary)} longTasks={count:${String(reinstallJmnedictPageSummary.longTaskCount)},totalMs:${reinstallJmnedictPageSummary.longTaskTotalMs.toFixed(1)},peakMs:${reinstallJmnedictPageSummary.longTaskPeakMs.toFixed(1)}} importDebug=${JSON.stringify(reinstallJmnedictImportDebug)}`,
                    reinstallJmnedictProfileStart,
                    reinstallJmnedictProfileEnd,
                );
                const postJmnedictStorageDiagnostics = await getBackendStorageDiagnostics(driver);
                await addReportPhase(
                    report,
                    driver,
                    'Capture storage state after JMnedict reinstall import',
                    `Storage after JMnedict import: ${summarizeBackendStorageDiagnostics(postJmnedictStorageDiagnostics)}`,
                    reinstallJmnedictProfileEnd,
                    reinstallJmnedictProfileEnd,
                );
                const postCycleSearchTabStart = safePerformance.now();
                const postCycleSearchWindowHandle = /** @type {string} */ (await openSearchPageInNewTab(driver, reinstalledExtensionBaseUrl));
                const postCycleSearchTabEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Open dedicated search tab after extension reinstall',
                    'Opened a fresh search.html tab after the add-on was removed and reinstalled, instead of reusing the pre-removal tab.',
                    postCycleSearchTabStart,
                    postCycleSearchTabEnd,
                );
                await driver.switchTo().window(postCycleSearchWindowHandle);
                const postCycleKuuSearchStart = safePerformance.now();
                const postCycleKuuSearchCounts = await searchTermAndGetDictionaryHitCounts(driver, '食う', ['Jitendex'], 20_000);
                const postCycleKuuSearchEnd = safePerformance.now();
                await addReportPhase(
                    report,
                    driver,
                    'Verify Jitendex 食う lookup after extension reinstall',
                    `Dedicated search tab returned counts for 食う after add-on removal/reinstall: ${JSON.stringify(postCycleKuuSearchCounts)}`,
                    postCycleKuuSearchStart,
                    postCycleKuuSearchEnd,
                );
                if ((postCycleKuuSearchCounts.Jitendex ?? 0) < 1) {
                    const backendDiagnostics = await getBackendLookupDiagnostics(driver, '食う');
                    const searchDiagnostics = await getSearchPageDiagnostics(driver);
                    const storageDiagnostics = await getBackendStorageDiagnostics(driver);
                    fail(`Expected Jitendex lookup for 食う after extension reinstall; saw ${JSON.stringify(postCycleKuuSearchCounts)} backend=${JSON.stringify(backendDiagnostics)} storage=${summarizeBackendStorageDiagnostics(storageDiagnostics)} diagnostics=${JSON.stringify(searchDiagnostics)}`);
                }
                await addReportPhase(
                    report,
                    driver,
                    'Focused extension-cycle verification complete',
                    'Reimported Jitendex + JMnedict after extension removal and reinstall, then verified lookups in the active Firefox session.',
                    postCycleKuuSearchEnd,
                    postCycleKuuSearchEnd,
                );
                report.status = 'success';
                console.log('[firefox-e2e] PASS: Focused extension reinstall + reimport completed.');
                return;
            }
            await driver.switchTo().window(settingsWindowHandle);
            const reloadExtensionStart = safePerformance.now();
            await reloadExtensionRuntime(driver, extensionBaseUrl);
            const reloadExtensionEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Reload extension runtime with persisted dictionaries',
                'Reloaded the installed Firefox extension in-place after Jitendex + JMnedict import to verify startup/runtime state recovery.',
                reloadExtensionStart,
                reloadExtensionEnd,
            );
            const postReloadSearchTabStart = safePerformance.now();
            await openSearchPageInNewTab(driver, extensionBaseUrl);
            const postReloadSearchTabEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Open dedicated search tab after extension reload',
                'Opened a fresh search tab after extension reload instead of reusing potentially discarded pre-reload contexts.',
                postReloadSearchTabStart,
                postReloadSearchTabEnd,
            );
            const postReloadKuuSearchStart = safePerformance.now();
            const postReloadKuuSearchCounts = await searchTermAndGetDictionaryHitCounts(driver, '食う', ['Jitendex'], 20_000);
            const postReloadKuuSearchEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Verify Jitendex 食う lookup after extension reload',
                `Dedicated search tab returned counts for 食う after extension reload: ${JSON.stringify(postReloadKuuSearchCounts)}`,
                postReloadKuuSearchStart,
                postReloadKuuSearchEnd,
            );
            if ((postReloadKuuSearchCounts.Jitendex ?? 0) < 1) {
                const backendDiagnostics = await getBackendLookupDiagnostics(driver, '食う');
                const searchDiagnostics = await getSearchPageDiagnostics(driver);
                fail(`Expected Jitendex lookup for 食う to survive extension reload; saw ${JSON.stringify(postReloadKuuSearchCounts)} backend=${JSON.stringify(backendDiagnostics)} diagnostics=${JSON.stringify(searchDiagnostics)}`);
            }
            await addReportPhase(
                report,
                driver,
                'Focused baseline complete',
                'Focused Firefox baseline for Jitendex + JMnedict completed, including extension reload verification; skipping the longer JMdict/update/multi-import path.',
                postReloadKuuSearchEnd,
                postReloadKuuSearchEnd,
            );
            report.status = 'success';
            console.log('[firefox-e2e] PASS: Focused Jitendex + JMnedict baseline completed.');
            return;
        }

        await driver.switchTo().window(settingsWindowHandle);

        const jmdictClickStart = safePerformance.now();
        const jmdictImportUrl = await installRecommendedDictionary(driver, 'JMdict');
        const jmdictClickEnd = safePerformance.now();
        await addReportPhase(report, driver, 'Click JMdict download', `Triggered recommended JMdict import via URL: ${jmdictImportUrl}`, jmdictClickStart, jmdictClickEnd);

        await driver.sleep(700);
        await driver.switchTo().window(searchWindowHandle);
        const searchDuringImportStart = safePerformance.now();
        const searchDuringImportCounts = await searchTermAndGetDictionaryHitCounts(driver, '暗記', ['Jitendex'], 20_000);
        const searchDuringImportEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Verify Jitendex search during JMdict import',
            `While slow JMdict import was in progress, dedicated search tab returned counts: ${JSON.stringify(searchDuringImportCounts)}`,
            searchDuringImportStart,
            searchDuringImportEnd,
        );
        if ((searchDuringImportCounts.Jitendex ?? 0) < 1) {
            const importDiagnostics = await getSearchPageDiagnostics(driver);
            fail(`Expected Jitendex search to remain available during JMdict import; saw ${JSON.stringify(searchDuringImportCounts)} diagnostics=${JSON.stringify(importDiagnostics)}`);
        }

        await driver.switchTo().window(settingsWindowHandle);
        const jmdictProfileStart = safePerformance.now();
        await beginPageProfilePhase(driver);
        const jmdictSampler = startFirefoxResourceSampler(firefoxPid);
        await waitForImportWithPhaseScreenshots(driver, report, 'JMdict', '2 installed, 2 enabled', 300_000);
        const jmdictResourceSummary = await jmdictSampler.stop();
        const jmdictPageSummary = await endPageProfilePhase(driver);
        const jmdictProfileEnd = safePerformance.now();
        const jmdictImportDebug = await getLastImportDebug(driver);
        const jmdictUsesFallbackStorage = jmdictImportDebug?.usesFallbackStorage === true;
        if (
            jmdictImportDebug !== null &&
            (
                Number(jmdictImportDebug.errorCount || 0) > 0 ||
                jmdictUsesFallbackStorage
            )
        ) {
            fail(`JMdict import debug indicates OPFS was not used: ${JSON.stringify(jmdictImportDebug)}`);
        }
        await addReportPhase(
            report,
            driver,
            'JMdict import resource profile',
            `${formatResourceSummary(jmdictResourceSummary)} longTasks={count:${String(jmdictPageSummary.longTaskCount)},totalMs:${jmdictPageSummary.longTaskTotalMs.toFixed(1)},peakMs:${jmdictPageSummary.longTaskPeakMs.toFixed(1)}} topMeasures=${JSON.stringify(jmdictPageSummary.topMeasures)} topLongTasks=${JSON.stringify(jmdictPageSummary.topLongTasks)} importDebug=${JSON.stringify(jmdictImportDebug)}`,
            jmdictProfileStart,
            jmdictProfileEnd,
        );
        const jmdictSettleStart = safePerformance.now();
        await driver.sleep(2_000);
        const jmdictSettleEnd = safePerformance.now();
        await addReportPhase(report, driver, 'JMdict: settle after progress clear', 'Waited 2000ms after progress text cleared before final verification', jmdictSettleStart, jmdictSettleEnd);
        const postImportDiagnosticsStart = safePerformance.now();
        const postImportDiagnostics = await getBackendLookupDiagnostics(driver, '打');
        const postImportDiagnosticsEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Post-import backend diagnostics',
            `After both imports, backend diagnostics: ${JSON.stringify(postImportDiagnostics)}`,
            postImportDiagnosticsStart,
            postImportDiagnosticsEnd,
        );
        const verifyJmdictContentStart = safePerformance.now();
        const verifyJmdictContentProfile = await waitForBackendDictionaryContentIntegrity(
            driver,
            ['JMdict'],
            [...jmdictProbeTerms, ...lookupWords],
            15_000,
        );
        const verifyJmdictContentEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Verify JMdict backend content integrity after import',
            `Checked that imported JMdict term-content spans are readable and in bounds before later UI verification: ${JSON.stringify(verifyJmdictContentProfile)}`,
            verifyJmdictContentStart,
            verifyJmdictContentEnd,
        );
        if (verifyJmdictContentProfile.ok !== true) {
            fail(`JMdict backend content integrity failed after import. diagnostics=${JSON.stringify(verifyJmdictContentProfile)}`);
        }
        const dictionaryInfoEntries = getDictionaryInfoEntries(postImportDiagnostics);
        const dictionaryInfoHealth = summarizeDictionaryInfoHealth(dictionaryInfoEntries);
        const termResultCount = Number(postImportDiagnostics.termResultCount || 0);
        if (dictionaryInfoEntries.length < 2) {
            const dictionaryErrorText = await getDictionaryErrorText(driver);
            fail(`Expected backend dictionaryInfo for two imports, got ${dictionaryInfoEntries.length}. dictionary-error="${dictionaryErrorText}" diagnostics=${JSON.stringify(postImportDiagnostics)}`);
        }
        if (dictionaryInfoHealth.importFailures.length > 0 || dictionaryInfoHealth.zeroTermDictionaries.length > 0 || termResultCount < 1) {
            const dictionaryErrorText = await getDictionaryErrorText(driver);
            fail(
                'Import completed in UI but backend data is not queryable. ' +
                `importFailures=${JSON.stringify(dictionaryInfoHealth.importFailures)} ` +
                `zeroTermDictionaries=${JSON.stringify(dictionaryInfoHealth.zeroTermDictionaries)} ` +
                `termResultCount=${String(termResultCount)} dictionary-error="${dictionaryErrorText}" ` +
                `jitendexUsesFallbackStorage=${String(jitendexUsesFallbackStorage)} ` +
                `jmdictUsesFallbackStorage=${String(jmdictUsesFallbackStorage)} ` +
                `diagnostics=${JSON.stringify(postImportDiagnostics)}`,
            );
        }
        const profileHasBothDictionaries = (() => {
            const profileDictionaries = /** @type {unknown} */ (postImportDiagnostics.profileDictionaries);
            if (!Array.isArray(profileDictionaries)) { return false; }
            /** @type {Set<string>} */
            const names = new Set();
            for (const profile of profileDictionaries) {
                if (!(profile && typeof profile === 'object')) { continue; }
                const dictionaries = /** @type {unknown} */ (profile.dictionaries);
                if (!Array.isArray(dictionaries)) { continue; }
                for (const name of dictionaries) {
                    if (typeof name === 'string' && name.length > 0) {
                        names.add(name);
                    }
                }
            }
            return names.has('Jitendex') && names.has('JMdict');
        })();

        const verifyStart = safePerformance.now();
        await closeModalIfOpen(driver, '#recommended-dictionaries-modal');
        const dictionariesModalTrigger = await openInstalledDictionariesModal(driver);
        const verifyDeadline = safePerformance.now() + 60_000;
        let lastModalText = '';
        while (safePerformance.now() < verifyDeadline) {
            // Selenium's executeScript return value is untyped (`any`).

            const modalText = await driver.executeScript(`
                const dictionariesModal = document.querySelector('#dictionaries-modal');
                const recommendedModal = document.querySelector('#recommended-dictionaries-modal');
                if (!(dictionariesModal instanceof HTMLElement) || dictionariesModal.hidden) { return ''; }
                if (recommendedModal instanceof HTMLElement && !recommendedModal.hidden) { return ''; }
                const dictionaryList = dictionariesModal.querySelector('#dictionary-list');
                if (!(dictionaryList instanceof HTMLElement)) { return ''; }
                return (dictionaryList.textContent || '').trim();
            `);
            if (typeof modalText === 'string') {
                lastModalText = modalText;
                if (lastModalText.includes('Jitendex') && lastModalText.includes('JMdict')) {
                    break;
                }
            }
            await driver.sleep(250);
        }
        if (!(lastModalText.includes('Jitendex') && lastModalText.includes('JMdict'))) {
            const dictionaryErrorText = await getDictionaryErrorText(driver);
            fail(
                'Expected installed dictionary modal text to contain Jitendex and JMdict; ' +
                `saw "${lastModalText.slice(0, 240)}"; dictionary-error="${dictionaryErrorText}" ` +
                `profileHasBothDictionaries=${String(profileHasBothDictionaries)}`,
            );
        }
        const verifyEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Verify installed dictionaries list',
            (
                `Opened dictionaries modal via ${dictionariesModalTrigger} and confirmed dictionary list text includes Jitendex + JMdict`
            ),
            verifyStart,
            verifyEnd,
        );

        if (focusedBaselineOnly) {
            await addReportPhase(
                report,
                driver,
                'Focused baseline complete',
                'Focused Firefox baseline for Jitendex + JMdict completed, including concurrent lookup and content-integrity verification; skipping update, batch-import, and hover stress paths.',
                verifyEnd,
                verifyEnd,
            );
            report.status = 'success';
            console.log('[firefox-e2e] PASS: Focused Jitendex + JMdict baseline completed.');
            return;
        }

        const updateTriggerStart = safePerformance.now();
        await driver.executeScript(`
            const modal = document.querySelector('#dictionary-confirm-update-modal');
            const button = document.querySelector('#dictionary-confirm-update-button');
            if (!(modal instanceof HTMLElement) || !(button instanceof HTMLElement)) {
                throw new Error('Update modal/button missing');
            }
            modal.dataset.dictionaryTitle = 'Jitendex';
            modal.dataset.downloadUrl = arguments[0];
            button.click();
        `, `${localServer.baseUrl}/dictionaries/jitendex-slow.zip`);
        const updateTriggerEnd = safePerformance.now();
        await addReportPhase(report, driver, 'Trigger slow Jitendex update', 'Queued a Jitendex update against a throttled local ZIP endpoint', updateTriggerStart, updateTriggerEnd);

        await driver.sleep(700);
        await driver.switchTo().window(searchWindowHandle);
        const searchDuringUpdateStart = safePerformance.now();
        const searchDuringUpdateCounts = await searchTermAndGetDictionaryHitCounts(driver, '暗記', ['Jitendex', 'JMdict'], 20_000);
        const searchDuringUpdateEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Verify search during Jitendex update download',
            `While slow Jitendex update was in progress, dedicated search tab returned counts: ${JSON.stringify(searchDuringUpdateCounts)}`,
            searchDuringUpdateStart,
            searchDuringUpdateEnd,
        );
        if ((searchDuringUpdateCounts.Jitendex ?? 0) < 1 || (searchDuringUpdateCounts.JMdict ?? 0) < 1) {
            const updateDiagnostics = await getSearchPageDiagnostics(driver);
            fail(`Expected installed dictionaries to remain searchable during Jitendex update; saw ${JSON.stringify(searchDuringUpdateCounts)} diagnostics=${JSON.stringify(updateDiagnostics)}`);
        }

        const searchDuringActiveUpdateImportStart = safePerformance.now();
        const searchDuringActiveUpdateImportResult = await verifyLookupRemainsResponsiveDuringImportPhase(
            driver,
            settingsWindowHandle,
            searchWindowHandle,
            /Step \d+ of \d+: Importing data/i,
            '暗記',
            ['Jitendex', 'JMdict'],
            4,
            heartbeat.setActiveOperation,
        );
        const searchDuringActiveUpdateImportEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Verify search during active Jitendex update import step',
            `While the update UI was in Step 4 import processing, dedicated search tab kept returning Jitendex + JMdict results: ${JSON.stringify(searchDuringActiveUpdateImportResult)}`,
            searchDuringActiveUpdateImportStart,
            searchDuringActiveUpdateImportEnd,
        );

        await driver.switchTo().window(settingsWindowHandle);
        const updateProfileStart = safePerformance.now();
        heartbeat.setActiveOperation('wait for updated Jitendex import completion');
        await beginPageProfilePhase(driver);
        const updateSampler = startFirefoxResourceSampler(firefoxPid);
        await waitForImportWithPhaseScreenshots(
            driver,
            report,
            'Jitendex',
            '2 installed, 2 enabled',
            300_000,
            jmdictImportDebug,
        );
        const updateResourceSummary = await updateSampler.stop();
        const updatePageSummary = await endPageProfilePhase(driver);
        const updateProfileEnd = safePerformance.now();
        const updateImportDebug = await getLastImportDebug(driver);
        await addReportPhase(
            report,
            driver,
            'Jitendex update resource profile',
            `${formatResourceSummary(updateResourceSummary)} longTasks={count:${String(updatePageSummary.longTaskCount)},totalMs:${updatePageSummary.longTaskTotalMs.toFixed(1)},peakMs:${updatePageSummary.longTaskPeakMs.toFixed(1)}} topMeasures=${JSON.stringify(updatePageSummary.topMeasures)} topLongTasks=${JSON.stringify(updatePageSummary.topLongTasks)} importDebug=${JSON.stringify(updateImportDebug)}`,
            updateProfileStart,
            updateProfileEnd,
        );
        const verifyUpdatedJitendexContentStart = safePerformance.now();
        heartbeat.setActiveOperation('verify updated Jitendex backend content integrity');
        const verifyUpdatedJitendexContentProfile = await waitForBackendDictionaryContentIntegrity(
            driver,
            ['Jitendex'],
            jitendexLookupProbeCandidates,
            15_000,
        );
        const verifyUpdatedJitendexContentEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Verify Jitendex backend content integrity after update',
            `Checked that Jitendex term-content spans remain readable and in bounds after the slow update path: ${JSON.stringify(verifyUpdatedJitendexContentProfile)}`,
            verifyUpdatedJitendexContentStart,
            verifyUpdatedJitendexContentEnd,
        );
        if (verifyUpdatedJitendexContentProfile.ok !== true) {
            fail(`Jitendex backend content integrity failed after update. diagnostics=${JSON.stringify(verifyUpdatedJitendexContentProfile)}`);
        }

        const searchOpenStart = safePerformance.now();
        heartbeat.setActiveOperation('open search page from action popup');
        await closeModalIfOpen(driver, '#dictionaries-modal');
        await openSearchPageViaActionPopup(driver, extensionBaseUrl);
        await ensurePageProfiler(driver);
        const searchOpenEnd = safePerformance.now();
        await addReportPhase(report, driver, 'Open search page from action popup', 'Closed dictionaries modal, opened action popup, and clicked magnifying-glass search button', searchOpenStart, searchOpenEnd);
        const backendDiagnosticsStart = safePerformance.now();
        const backendDiagnostics = await getBackendLookupDiagnostics(driver, '打');
        const backendDiagnosticsEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Backend lookup diagnostics',
            `Database/termsFind diagnostics before UI search: ${JSON.stringify(backendDiagnostics)}`,
            backendDiagnosticsStart,
            backendDiagnosticsEnd,
        );

        const searchVerifyStart = safePerformance.now();
        heartbeat.setActiveOperation('verify search results include both dictionaries');
        const searchTerm = '暗記';
        let dictionaryHitCounts = await searchTermAndGetDictionaryHitCounts(driver, searchTerm, expectedLookupDictionaries, 20_000);
        if ((dictionaryHitCounts.Jitendex ?? 0) < 1 || (dictionaryHitCounts.JMdict ?? 0) < 1) {
            // Retry once after a hard refresh: Firefox extension search page can be flaky in CI.
            await driver.navigate().refresh();
            await driver.wait(until.elementLocated(By.css('#search-textbox')), 30_000);
            dictionaryHitCounts = await searchTermAndGetDictionaryHitCounts(driver, searchTerm, expectedLookupDictionaries, 20_000);
        }
        if ((dictionaryHitCounts.Jitendex ?? 0) < 1 || (dictionaryHitCounts.JMdict ?? 0) < 1) {
            const searchDiagnostics = await getSearchPageDiagnostics(driver);
            const searchVerifyEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Verify search results include both dictionaries (failed)',
                `UI search returned incomplete results. Counts=${JSON.stringify(dictionaryHitCounts)} backend=${JSON.stringify(backendDiagnostics)} diagnostics=${JSON.stringify(searchDiagnostics)}`,
                searchVerifyStart,
                searchVerifyEnd,
            );
            fail(`Expected search results for ${searchTerm} to include both Jitendex and JMdict; saw counts ${JSON.stringify(dictionaryHitCounts)} diagnostics=${JSON.stringify(searchDiagnostics)} backend=${JSON.stringify(backendDiagnostics)}`);
        } else {
            const searchVerifyEnd = safePerformance.now();
            await addReportPhase(report, driver, 'Verify search results include both dictionaries', `Searched ${searchTerm} and observed dictionary hit counts: ${JSON.stringify(dictionaryHitCounts)}`, searchVerifyStart, searchVerifyEnd);
        }

        const lookupChars = lookupWords.map((word) => String([...word][0] || '').trim()).filter((value) => value.length > 0);
        /** @type {Array<Record<string, unknown>>} */
        const lookupProfiles = [];
        for (const lookupChar of lookupChars) {
            const lookupStart = safePerformance.now();
            heartbeat.setActiveOperation(`profile lookup: ${lookupChar}`);
            await beginPageProfilePhase(driver);
            const sampler = startFirefoxResourceSampler(firefoxPid);
            const lookupCounts = await searchTermAndGetDictionaryHitCounts(driver, lookupChar, expectedLookupDictionaries, 4_000);
            const lookupDiagnostics = await getSearchPageDiagnostics(driver);
            const resourceSummary = await sampler.stop();
            const pageSummary = await endPageProfilePhase(driver);
            const lookupEnd = safePerformance.now();
            lookupProfiles.push({
                lookupChar,
                durationMs: Math.max(0, lookupEnd - lookupStart),
                counts: lookupCounts,
                resourceSummary,
                pageSummary,
            });
            await addReportPhase(
                report,
                driver,
                `Profile lookup: ${lookupChar}`,
                `lookupChar=${lookupChar} counts=${JSON.stringify(lookupCounts)} ${formatResourceSummary(resourceSummary)} longTasks={count:${String(pageSummary.longTaskCount)},totalMs:${pageSummary.longTaskTotalMs.toFixed(1)},peakMs:${pageSummary.longTaskPeakMs.toFixed(1)}} topMeasures=${JSON.stringify(pageSummary.topMeasures)} topLongTasks=${JSON.stringify(pageSummary.topLongTasks)} diagnostics=${JSON.stringify(lookupDiagnostics)}`,
                lookupStart,
                lookupEnd,
            );
        }
        const hottestCpuLookup = lookupProfiles
            .filter((profile) => {
                const resourceSummary = /** @type {Record<string, unknown>} */ (profile.resourceSummary || {});
                return Number.isFinite(Number(resourceSummary.peakCpuPercent));
            })
            .sort((a, b) => Number((/** @type {Record<string, unknown>} */ (b.resourceSummary || {})).peakCpuPercent || 0) - Number((/** @type {Record<string, unknown>} */ (a.resourceSummary || {})).peakCpuPercent || 0))[0] || null;
        const hottestLongTaskLookup = lookupProfiles
            .sort((a, b) => Number((/** @type {Record<string, unknown>} */ (b.pageSummary || {})).longTaskTotalMs || 0) - Number((/** @type {Record<string, unknown>} */ (a.pageSummary || {})).longTaskTotalMs || 0))[0] || null;
        const drillDownStart = safePerformance.now();
        const drillDownEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'CPU/memory drilldown summary',
            `lookups=${JSON.stringify(lookupChars)} hottestCpuLookup=${JSON.stringify(hottestCpuLookup)} hottestLongTaskLookup=${JSON.stringify(hottestLongTaskLookup)}`,
            drillDownStart,
            drillDownEnd,
        );

        const multiImportOpenStart = safePerformance.now();
        heartbeat.setActiveOperation('return to settings for multi-file import');
        await navigateToExtensionPage(
            driver,
            `${extensionBaseUrl}/settings.html?popup-preview=false`,
            By.css('#dictionary-import-file-input'),
            {attempts: 3, pageLoadTimeoutMs: 15_000, readyTimeoutMs: 30_000},
        );
        await driver.wait(until.elementLocated(By.css('#dictionary-import-file-input')), 30_000);
        const multiImportOpenEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Return to settings for multi-file import stress',
            'Returned to settings and located the hidden multi-file import input for batch import stress.',
            multiImportOpenStart,
            multiImportOpenEnd,
        );
        const deleteJmdictBeforeBatchStart = safePerformance.now();
        const deleteJmdictBeforeBatchResult = await deleteBackendDictionaryByExpectedName(driver, 'JMdict');
        const deleteJmdictBeforeBatchEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Delete JMdict before batch import',
            deleteJmdictBeforeBatchResult.ok ?
                `Removed ${String(deleteJmdictBeforeBatchResult.deletedTitle || 'JMdict')} before the batch-import stress so the multi-file path covers reimport + new dictionary instead of duplicate-import rejection.` :
                `Failed to remove JMdict before batch import: ${String(deleteJmdictBeforeBatchResult.error || 'unknown error')}`,
            deleteJmdictBeforeBatchStart,
            deleteJmdictBeforeBatchEnd,
        );
        if (!deleteJmdictBeforeBatchResult.ok) {
            fail(`Failed to delete JMdict before batch import: ${String(deleteJmdictBeforeBatchResult.error || 'unknown error')}`);
        }
        const multiImportTriggerStart = safePerformance.now();
        heartbeat.setActiveOperation('trigger multi-file import');
        await importDictionariesViaFileInput(driver, [cachedDictionaries.jmdictPath, cachedDictionaries.jmnedictPath]);
        const multiImportTriggerEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Trigger multi-file dictionary import stress',
            `Triggered a single multi-file import selection with ${JSON.stringify([cachedDictionaries.jmdictPath, cachedDictionaries.jmnedictPath])} to stress update + new-dictionary import handling in one batch.`,
            multiImportTriggerStart,
            multiImportTriggerEnd,
        );
        const multiImportProfileStart = safePerformance.now();
        heartbeat.setActiveOperation('wait for JMdict + JMnedict batch import completion');
        await beginPageProfilePhase(driver);
        const multiImportSampler = startFirefoxResourceSampler(firefoxPid);
        await waitForImportWithPhaseScreenshots(driver, report, 'JMdict + JMnedict batch import', '3 installed, 3 enabled', 300_000);
        const multiImportResourceSummary = await multiImportSampler.stop();
        const multiImportPageSummary = await endPageProfilePhase(driver);
        const multiImportProfileEnd = safePerformance.now();
        const multiImportDebug = await getLastImportDebug(driver);
        await addReportPhase(
            report,
            driver,
            'Multi-file import resource profile',
            `${formatResourceSummary(multiImportResourceSummary)} longTasks={count:${String(multiImportPageSummary.longTaskCount)},totalMs:${multiImportPageSummary.longTaskTotalMs.toFixed(1)},peakMs:${multiImportPageSummary.longTaskPeakMs.toFixed(1)}} topMeasures=${JSON.stringify(multiImportPageSummary.topMeasures)} topLongTasks=${JSON.stringify(multiImportPageSummary.topLongTasks)} importDebug=${JSON.stringify(multiImportDebug)}`,
            multiImportProfileStart,
            multiImportProfileEnd,
        );
        const verifyBatchContentStart = safePerformance.now();
        const verifyBatchJmdictContent = await waitForBackendDictionaryContentIntegrity(
            driver,
            ['JMdict'],
            extendedLookupProbeCandidates,
            15_000,
        );
        const verifyBatchJmnedictContent = await waitForBackendDictionaryContentIntegrity(
            driver,
            ['JMnedict'],
            extendedLookupProbeCandidates,
            15_000,
        );
        const verifyBatchContentEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Verify backend content integrity after multi-file import',
            `Checked that JMdict and JMnedict term-content spans are readable and in bounds after batch import. jmdict=${JSON.stringify(verifyBatchJmdictContent)} jmnedict=${JSON.stringify(verifyBatchJmnedictContent)}`,
            verifyBatchContentStart,
            verifyBatchContentEnd,
        );
        if (verifyBatchJmdictContent.ok !== true) {
            fail(`JMdict backend content integrity failed after multi-file import. diagnostics=${JSON.stringify(verifyBatchJmdictContent)}`);
        }
        if (verifyBatchJmnedictContent.ok !== true) {
            fail(`JMnedict backend content integrity failed after multi-file import. diagnostics=${JSON.stringify(verifyBatchJmnedictContent)}`);
        }
        const verifyUnaffectedLookupStart = safePerformance.now();
        const verifyUnaffectedLookup = await waitForBackendDictionaryLookupCoverage(
            driver,
            '暗記',
            expectedLookupDictionaries,
            15_000,
        );
        const verifyUnaffectedLookupEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Verify existing dictionary lookup continuity after multi-file import',
            `Required live ${expectedLookupDictionaries.join(' + ')} lookup results immediately after importing JMdict + JMnedict. diagnostics=${JSON.stringify(verifyUnaffectedLookup.diagnostics)}`,
            verifyUnaffectedLookupStart,
            verifyUnaffectedLookupEnd,
        );
        if (!verifyUnaffectedLookup.ok) {
            fail(`Existing dictionary lookup coverage was lost after multi-file import. diagnostics=${JSON.stringify(verifyUnaffectedLookup.diagnostics)}`);
        }

        const verifyTripleStart = safePerformance.now();
        await closeModalIfOpen(driver, '#recommended-dictionaries-modal');
        const tripleModalTrigger = await openInstalledDictionariesModal(driver);
        const tripleVerifyDeadline = safePerformance.now() + 60_000;
        let tripleModalText = '';
        while (safePerformance.now() < tripleVerifyDeadline) {
            // Selenium executeScript return value is untyped (`any`).

            const modalText = await driver.executeScript(`
                const dictionariesModal = document.querySelector('#dictionaries-modal');
                const recommendedModal = document.querySelector('#recommended-dictionaries-modal');
                if (!(dictionariesModal instanceof HTMLElement) || dictionariesModal.hidden) { return ''; }
                if (recommendedModal instanceof HTMLElement && !recommendedModal.hidden) { return ''; }
                const dictionaryList = dictionariesModal.querySelector('#dictionary-list');
                if (!(dictionaryList instanceof HTMLElement)) { return ''; }
                return (dictionaryList.textContent || '').trim();
            `);
            if (typeof modalText === 'string') {
                tripleModalText = modalText;
                if (extendedLookupDictionaries.every((name) => tripleModalText.includes(name))) {
                    break;
                }
            }
            await driver.sleep(250);
        }
        if (!extendedLookupDictionaries.every((name) => tripleModalText.includes(name))) {
            fail(`Expected installed dictionary modal text to contain ${extendedLookupDictionaries.join(', ')} after multi-file import; saw "${tripleModalText.slice(0, 300)}"`);
        }
        const verifyTripleEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Verify installed dictionaries after multi-file import',
            `Opened dictionaries modal via ${tripleModalTrigger} and confirmed dictionary list text includes ${extendedLookupDictionaries.join(' + ')} after multi-file import.`,
            verifyTripleStart,
            verifyTripleEnd,
        );

        const hoverConfigStart = safePerformance.now();
        const hoverConfigResult = await configureHoverTestOptions(driver);
        const hoverConfigEnd = safePerformance.now();
        await addReportPhase(
            report,
            driver,
            'Enable text scanning for hover stress',
            `Configured hover test profile options before Wagahai verification: ${JSON.stringify(hoverConfigResult)}`,
            hoverConfigStart,
            hoverConfigEnd,
        );
        if (hoverConfigResult.ok !== true) {
            fail(`Failed to configure hover test options: ${JSON.stringify(hoverConfigResult)}`);
        }

        const hoverSpeedStressStart = safePerformance.now();
        heartbeat.setActiveOperation(`hover speed stress (${useScriptedHoverMotion ? 'scripted' : 'native'} motion)`);
        await closeModalIfOpen(driver, '#dictionaries-modal');
        await beginPageProfilePhase(driver);
        const hoverSpeedSampler = startFirefoxResourceSampler(firefoxPid);
        const hoverSpeedTargets = ['#target-word', '#target-cat', '#target-name', '#target-kotoba', '#target-born', '#target-mitou'];
        const motionProfiles = [
            {label: 'slow', moveAwayOffsetX: -18, moveToOffsetX: 12, moveToOffsetY: 2, pauseAfterMoveMs: 80, popupTimeoutMs: 5400},
            {label: 'medium', moveAwayOffsetX: -12, moveToOffsetX: 10, moveToOffsetY: 2, pauseAfterMoveMs: 20, popupTimeoutMs: 5000},
            {label: 'fast', moveAwayOffsetX: -6, moveToOffsetX: 8, moveToOffsetY: 1, pauseAfterMoveMs: 0, popupTimeoutMs: 4400},
        ];
        /** @type {Array<Record<string, unknown>>} */
        const hoverSpeedIterations = [];
        let hoverSpeedStressError = '';
        try {
            for (let i = 0; i < 18; ++i) {
                const selector = hoverSpeedTargets[i % hoverSpeedTargets.length];
                const motionProfile = motionProfiles[i % motionProfiles.length];
                const iterationStart = safePerformance.now();
                const hoverResult = await hoverLookupOnPage(
                    driver,
                    `${localServer.baseUrl}/wagahai-neko.html`,
                    selector,
                    expectedLookupDictionaries,
                    motionProfile,
                );
                const iterationEnd = safePerformance.now();
                const hasDictionaryResult = hoverResult.hasDictionaryEntries === true && /jmdict|jitendex/i.test(hoverResult.popupText);
                hoverSpeedIterations.push({
                    iteration: i + 1,
                    selector,
                    speed: motionProfile.label,
                    usedModifier: hoverResult.usedModifier,
                    durationMs: Math.max(0, iterationEnd - iterationStart),
                    hasDictionaryEntries: hoverResult.hasDictionaryEntries,
                    noResultsVisible: hoverResult.noResultsVisible,
                    noDictionariesVisible: hoverResult.noDictionariesVisible,
                    hasDictionaryResult,
                    entriesTextPreview: hoverResult.entriesTextPreview,
                });
                if (!hasDictionaryResult) {
                    throw new Error(
                        `Hover iteration ${String(i + 1)} (${selector}, ${motionProfile.label}) did not show dictionary results. ` +
                        `entries=${JSON.stringify(hoverResult.entriesTextPreview)} popup=${JSON.stringify(hoverResult.popupText.slice(0, 200))} ` +
                        `noResults=${String(hoverResult.noResultsVisible)} noDictionaries=${String(hoverResult.noDictionariesVisible)}`,
                    );
                }
            }
        } catch (e) {
            hoverSpeedStressError = errorMessage(e);
            const hoverDiagnostics = await getBackendLookupDiagnostics(driver, '暗記');
            fail(`Hover-speed stress after multi-file import failed: ${hoverSpeedStressError}; backend=${JSON.stringify(hoverDiagnostics)}`);
        } finally {
            const hoverSpeedResourceSummary = await hoverSpeedSampler.stop();
            const hoverSpeedPageSummary = await endPageProfilePhase(driver);
            const hoverSpeedStressEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Verify hover lookup responsiveness at varying speeds',
                hoverSpeedStressError.length > 0 ?
                    `Hover-speed stress failed: ${hoverSpeedStressError}` :
                    `${formatResourceSummary(hoverSpeedResourceSummary)} longTasks={count:${String(hoverSpeedPageSummary.longTaskCount)},totalMs:${hoverSpeedPageSummary.longTaskTotalMs.toFixed(1)},peakMs:${hoverSpeedPageSummary.longTaskPeakMs.toFixed(1)}} topMeasures=${JSON.stringify(hoverSpeedPageSummary.topMeasures)} topLongTasks=${JSON.stringify(hoverSpeedPageSummary.topLongTasks)} iterations=${JSON.stringify(hoverSpeedIterations)}`,
                hoverSpeedStressStart,
                hoverSpeedStressEnd,
            );
        }

        const hoverLookupStart = safePerformance.now();
        heartbeat.setActiveOperation(`repeated hover stress (${useScriptedHoverMotion ? 'scripted' : 'native'} motion)`);
        const hoverTargets = ['#target-word', '#target-cat', '#target-name', '#target-kotoba', '#target-born', '#target-mitou'];
        /** @type {Array<{iteration: number, selector: string, popupTextPreview: string}>} */
        const hoverIterationSummaries = [];
        try {
            for (let i = 0; i < 12; ++i) {
                const selector = hoverTargets[i % hoverTargets.length];
                const hoverResult = await hoverLookupOnPage(
                    driver,
                    `${localServer.baseUrl}/wagahai-neko.html`,
                    selector,
                    ['Jitendex', 'JMdict'],
                );
                hoverIterationSummaries.push({
                    iteration: i + 1,
                    selector,
                    popupTextPreview: String(hoverResult.popupText || '').slice(0, 140),
                });
            }
            const hoverLookupEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Verify repeated hover lookup on Wagahai page',
                `Ran 12 hover-scan iterations across selectors ${JSON.stringify(hoverTargets)} and confirmed popup includes both dictionaries each time. iterations=${JSON.stringify(hoverIterationSummaries)}`,
                hoverLookupStart,
                hoverLookupEnd,
            );
        } catch (hoverError) {
            let hoverDiagnostics;
            try {
                hoverDiagnostics = await getBackendLookupDiagnostics(driver, '暗記');
            } catch (hoverDiagnosticsError) {
                if (!isDiscardedBrowsingContextError(hoverError) && !isDiscardedBrowsingContextError(hoverDiagnosticsError)) {
                    throw hoverDiagnosticsError;
                }
                await recoverExtensionSearchContext(driver, extensionBaseUrl, '暗記');
                hoverDiagnostics = await getBackendLookupDiagnostics(driver, '暗記');
            }
            const hoverLookupEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Verify repeated hover lookup on Wagahai page (failed)',
                `Hover popup verification failed during repeated run. backend=${JSON.stringify(hoverDiagnostics)} error=${errorMessage(hoverError)} completedIterations=${JSON.stringify(hoverIterationSummaries)}`,
                hoverLookupStart,
                hoverLookupEnd,
            );
            fail(`Expected repeated hover popup lookups to include both dictionaries. backend=${JSON.stringify(hoverDiagnostics)} error=${errorMessage(hoverError)} completedIterations=${JSON.stringify(hoverIterationSummaries)}`);
        }

        const postHoverSearchStart = safePerformance.now();
        const postHoverSearchTerm = '暗記';
        let postHoverHitCounts = /** @type {Record<string, number>} */ ({});
        let postHoverSearchError = '';
        try {
            await navigateToExtensionPage(
                driver,
                `${extensionBaseUrl}/search.html?query=${encodeURIComponent(postHoverSearchTerm)}&type=terms&wildcards=off`,
                By.css('#search-textbox'),
            );
            postHoverHitCounts = await searchTermAndGetDictionaryHitCounts(driver, postHoverSearchTerm, expectedLookupDictionaries, 20_000, 'button');
            if ((postHoverHitCounts.Jitendex ?? 0) < 1 || (postHoverHitCounts.JMdict ?? 0) < 1) {
                const searchDiagnostics = await getSearchPageDiagnostics(driver);
                throw new Error(`Counts=${JSON.stringify(postHoverHitCounts)} diagnostics=${JSON.stringify(searchDiagnostics)}`);
            }
        } catch (postHoverError) {
            postHoverSearchError = errorMessage(postHoverError);
            fail(`Expected search button flow to include both dictionaries after hover stress. ${postHoverSearchError}`);
        } finally {
            const postHoverSearchEnd = safePerformance.now();
            await addReportPhase(
                report,
                driver,
                'Verify search remains responsive after hover stress',
                postHoverSearchError.length > 0 ?
                    `Search button verification failed after hover stress: ${postHoverSearchError}` :
                    `Search button verification after hover stress succeeded for ${postHoverSearchTerm}. counts=${JSON.stringify(postHoverHitCounts)}`,
                postHoverSearchStart,
                postHoverSearchEnd,
            );
        }

        report.status = 'success';
        console.log('[firefox-e2e] PASS: Recommended dictionary imports installed Jitendex and JMdict.');
    } catch (e) {
        let failureReason = errorMessage(e);
        try {
            const backendStorageDiagnostics = await getBackendStorageDiagnostics(driver);
            if (backendStorageDiagnostics !== null) {
                const runtimeDiagnostics = asRecordOrNull(report.runtimeDiagnostics) ?? {};
                report.runtimeDiagnostics = {
                    ...runtimeDiagnostics,
                    backendStorageDiagnostics,
                };
                failureReason += ` backendStorageDiagnostics=${JSON.stringify(backendStorageDiagnostics)}`;
            }
        } catch (diagnosticsError) {
            failureReason += ` backendStorageDiagnosticsError=${errorMessage(diagnosticsError)}`;
        }
        const skipReason = strictUnsupportedRuntime ? '' : getUnsupportedRuntimeSkipReason(failureReason);
        if (skipReason.length > 0) {
            report.status = 'success-with-skips';
            report.failureReason = '';
            report.skippedVerification = true;
            report.skipReason = skipReason;
            console.warn(`[firefox-e2e] warning: ${skipReason}`);
        } else {
            report.status = 'failure';
            report.failureReason = failureReason;
            runError = new Error(`[firefox-e2e] ${failureReason}`);
        }
    } finally {
        try {
            await heartbeat.stop('finalize');
            await mkdir(path.dirname(reportPath), {recursive: true});
            const reportHtml = renderReportHtml(report);
            await writeFile(reportPath, reportHtml);
            await writeFile(reportJsonPath, JSON.stringify(createReportJsonSummary(report), null, 2), 'utf8');
            console.log(`[firefox-e2e] Wrote report: ${reportPath}`);
            console.log(`[firefox-e2e] Wrote report json: ${reportJsonPath}`);
            await writeCombinedTabbedReport({
                chromiumReportPath,
                edgeReportPath,
                firefoxReportPath: reportPath,
                outputPath: combinedReportPath,
            });
            console.log(`[firefox-e2e] Wrote combined report: ${combinedReportPath}`);
        } catch (reportError) {
            console.error(`[firefox-e2e] Failed to write report: ${errorMessage(reportError)}`);
        }

        if (localServer !== null) {
            try {
                await localServer.close();
            } catch (serverCloseError) {
                console.error(`[firefox-e2e] Failed to close local server: ${errorMessage(serverCloseError)}`);
            }
        }
        if (driver !== null) {
            try {
                await driver.quit();
            } catch (driverQuitError) {
                if (!isIgnorableDriverQuitError(driverQuitError)) {
                    console.error(`[firefox-e2e] Failed to quit driver: ${errorMessage(driverQuitError)}`);
                    runError ??= new Error(`Failed to quit Firefox driver: ${errorMessage(driverQuitError)}`, {cause: driverQuitError});
                }
            }
        }
        if (geckodriverLogFd !== null) {
            try {
                closeSync(geckodriverLogFd);
            } catch (streamError) {
                console.error(`[firefox-e2e] Failed to close geckodriver log fd: ${errorMessage(streamError)}`);
            }
        }
    }

    if (runError) {
        throw runError;
    }
}

export {navigateToExtensionPage, purgeBackendDatabase, getLastImportDebug, waitForImportWithPhaseScreenshots, importDictionariesViaFileInput, getBackendLookupDiagnostics, waitForBackendDictionaryContentIntegrity, createReport, startHeartbeat, writeReportSnapshot, renderReportHtml, addReportPhase, loadBenchmarkProbeTerms};

async function loadBenchmarkProbeTerms(zipPath) {
    const {stdout: listing} = await execFileAsync('unzip', ['-Z1', zipPath], {maxBuffer: 8 * 1024 * 1024});
    const banks = listing.split('\n').filter((name) => /^term_bank_\d+\.json$/.test(name));
    banks.sort((a, b) => Number(a.match(/\d+/)[0]) - Number(b.match(/\d+/)[0]));
    if (banks.length < 3) { fail('Benchmark fixture needs at least three term banks'); }
    const bankIndices = [0, Math.floor(banks.length / 2), banks.length - 1];
    const terms = new Set();
    for (const bankIndex of bankIndices) {
        const {stdout} = await execFileAsync('unzip', ['-p', zipPath, banks[bankIndex]], {maxBuffer: 32 * 1024 * 1024});
        const rows = parseJson(stdout);
        for (let sample = 0; sample < 4; ++sample) {
            const start = Math.floor((rows.length - 1) * sample / 3);
            for (let offset = 0; offset < rows.length; ++offset) {
                const term = String(rows[(start + offset) % rows.length]?.[0] || '').trim();
                if (term.length === 0 || term.length > 40 || terms.has(term)) { continue; }
                terms.add(term);
                break;
            }
        }
    }
    if (terms.size !== 12) { fail('Could not select twelve distinct benchmark content probes'); }
    return [...terms];
}

