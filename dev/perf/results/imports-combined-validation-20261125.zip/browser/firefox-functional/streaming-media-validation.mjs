/*
 * Copyright (C) 2026 Manabitan authors
 * GNU General Public License, version 3 or later.
 * External validation adaptation of dev/perf/import-media-validation.js.
 * Only inventory retention and extraction order change; complete byte checks
 * and the sorted JSON-lines digest retain the original oracle's contract.
 */
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {openAsBlob} from 'node:fs'
import {BlobReader, Uint8ArrayWriter, ZipReader} from '@zip.js/zip.js'
import {getImageMediaTypeFromFileName} from '../combined/ext/js/media/media-util.js'

const maxBatchFiles = 256
const maxBatchBytes = 8 * 1024 * 1024
const compareNames = (a, b) => a === b ? 0 : a < b ? -1 : 1
const isImage = (entry) => !entry.directory && getImageMediaTypeFromFileName(entry.filename) !== null
const openReader = async (archivePath) => new ZipReader(new BlobReader(await openAsBlob(archivePath)), {useWebWorkers: false})

async function readInventory(archivePath) {
    const reader = await openReader(archivePath)
    const inventory = new Map()
    try {
        for await (const entry of reader.getEntriesGenerator()) {
            if (!isImage(entry)) { continue }
            assert(!inventory.has(entry.filename), 'Duplicate archive media paths')
            // Retain primitive metadata, never an Entry or its getData closure.
            inventory.set(entry.filename, entry.uncompressedSize)
        }
        return inventory
    } finally { await reader.close() }
}

export async function verifyBenchmarkMediaStreaming(archivePath, fixture, readMedia, mode = 'all') {
    assert.equal(mode, 'all', 'Streaming qualification requires complete media verification')
    assert(Number.isSafeInteger(fixture.mediaFiles) && Number(fixture.mediaFiles) >= 0, 'Missing expected media count')
    assert(Number.isSafeInteger(fixture.mediaBytes) && Number(fixture.mediaBytes) >= 0, 'Missing expected media bytes')
    const unreferencedPaths = typeof fixture.unreferencedMediaPaths === 'undefined' ? [] : fixture.unreferencedMediaPaths
    assert(Array.isArray(unreferencedPaths) && unreferencedPaths.every((name) => typeof name === 'string' && name.length > 0), 'Invalid unreferenced media paths')
    const unreferenced = new Set(unreferencedPaths)
    assert.equal(unreferenced.size, unreferencedPaths.length, 'Duplicate unreferenced media paths')
    const inventory = await readInventory(archivePath)
    for (const name of unreferenced) { assert(inventory.has(name), `Unreferenced image is absent from archive: ${name}`) }
    assert.equal(inventory.size, Number(fixture.mediaFiles) + unreferenced.size, 'Archive image count differs from lock')
    const names = [...inventory.keys()].filter((name) => !unreferenced.has(name))
    assert.equal(names.reduce((sum, name) => sum + inventory.get(name), 0), fixture.mediaBytes, 'Referenced image bytes differ from lock')
    const seen = new Set()
    const records = []
    let bytes = 0
    const verifyBatch = async (batch) => {
        const actual = await readMedia(batch.map((entry) => entry.filename))
        assert.equal(actual.length, batch.length, 'Persisted media response count differs from archive')
        const byPath = new Map(actual.map((item) => [item.path, item]))
        assert.equal(byPath.size, actual.length, 'Persisted media response contains duplicate paths')
        for (const entry of batch) {
            const item = byPath.get(entry.filename)
            assert(item, `Missing persisted media: ${entry.filename}`)
            assert.equal(item.dictionary, fixture.expectedTitle, `Wrong media dictionary: ${entry.filename}`)
            assert.equal(typeof item.content, 'string', `Missing media bytes: ${entry.filename}`)
            assert(typeof entry.getData === 'function', `Unreadable archive media: ${entry.filename}`)
            const expected = await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true})
            const actualBytes = Buffer.from(item.content, 'base64')
            assert.equal(actualBytes.byteLength, entry.uncompressedSize, `Persisted media length mismatch: ${entry.filename}`)
            assert(actualBytes.equals(expected), `Persisted media bytes differ from source: ${entry.filename}`)
            bytes += actualBytes.byteLength
            records.push([entry.filename, actualBytes.byteLength, createHash('sha256').update(actualBytes).digest('hex')])
        }
    }
    const reader = await openReader(archivePath)
    try {
        let batch = []
        let batchBytes = 0
        for await (const entry of reader.getEntriesGenerator()) {
            if (!isImage(entry) || unreferenced.has(entry.filename)) { continue }
            assert(inventory.has(entry.filename), `Archive image changed between passes: ${entry.filename}`)
            assert.equal(entry.uncompressedSize, inventory.get(entry.filename), `Archive image size changed between passes: ${entry.filename}`)
            assert(!seen.has(entry.filename), `Duplicate archive image on extraction pass: ${entry.filename}`)
            seen.add(entry.filename)
            if (batch.length > 0 && batchBytes + entry.uncompressedSize > maxBatchBytes) {
                await verifyBatch(batch)
                batch = []
                batchBytes = 0
            }
            // As in the original oracle, one oversized member is allowed alone.
            batch.push(entry)
            batchBytes += entry.uncompressedSize
            // Flush before requesting another generator value: at most 256 live Entries.
            if (batch.length === maxBatchFiles) {
                await verifyBatch(batch)
                batch = []
                batchBytes = 0
            }
        }
        if (batch.length > 0) { await verifyBatch(batch) }
    } finally { await reader.close() }
    assert.equal(seen.size, names.length, 'Archive image inventory changed between passes')
    assert.equal(records.length, names.length, 'Not every referenced image was verified')
    assert.equal(bytes, fixture.mediaBytes)
    records.sort((a, b) => compareNames(a[0], b[0]))
    const digest = createHash('sha256')
    for (const record of records) { digest.update(JSON.stringify(record) + '\n') }
    return {mode, totalFiles: names.length, totalBytes: Number(fixture.mediaBytes), files: records.length, bytes, sha256: digest.digest('hex')}
}
