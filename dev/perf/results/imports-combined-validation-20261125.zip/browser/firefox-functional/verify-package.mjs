import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {openAsBlob} from 'node:fs'
import {BlobReader, Uint8ArrayWriter, ZipReader} from '@zip.js/zip.js'

export async function verifyPackage(packagePath, sourceHashes) {
    assert.equal(sourceHashes['ext/lib/term-bank-parser.wasm'], 'f3bb4ab538cce77a8f9681b853aba10bcfd62cd0b6ec63cb40429bf05d561d83', 'Combined native module changed since corpus qualification')
    const reader = new ZipReader(new BlobReader(await openAsBlob(packagePath)), {useWebWorkers: false})
    try {
        const entries = new Map((await reader.getEntries()).map((entry) => [entry.filename, entry]))
        const checked = {}
        for (const [sourcePath, expectedHash] of Object.entries(sourceHashes)) {
            if (!sourcePath.startsWith('ext/') || !(sourcePath.endsWith('.js') || sourcePath.endsWith('.wasm'))) { continue }
            const packagePath = sourcePath.slice(4)
            const entry = entries.get(packagePath)
            assert(entry, `Missing shipped file: ${packagePath}`)
            const bytes = await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true})
            const digest = createHash('sha256').update(bytes).digest('hex')
            assert.equal(digest, expectedHash, `Stale packaged source: ${packagePath}`)
            checked[packagePath] = digest
        }
        const manifestBytes = await entries.get('manifest.json').getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true})
        const manifest = JSON.parse(new TextDecoder().decode(manifestBytes))
        assert.equal(manifest.browser_specific_settings?.gecko?.id ?? manifest.applications?.gecko?.id, '{accbebce-862b-48a9-bb9a-1da9ad1f8702}')
        return {checked, manifestSha256: createHash('sha256').update(manifestBytes).digest('hex'), manifestVersion: manifest.manifest_version, version: manifest.version, name: manifest.name}
    } finally { await reader.close() }
}
