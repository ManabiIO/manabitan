import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, writeFile} from 'node:fs/promises'
import {verifyBenchmarkMedia} from '../combined/dev/perf/import-media-validation.js'
import {verifyBenchmarkMediaStreaming} from './streaming-media-validation.mjs'

const root = '/workspace/scratch/7b5a4ac440c8'
const fixture = JSON.parse(await readFile(`${root}/combined/test/perf/dictionaries.lock.json`, 'utf8')).dictionaries.jitendex
const archive = `${root}/manabitan/builds/e2e-dictionary-cache/${fixture.cacheFile}`
const independentMedia = JSON.parse(await readFile(new URL('./jitendex-media-responder.json', import.meta.url), 'utf8'))
const responder = async (paths) => paths.map((path) => ({dictionary: fixture.expectedTitle, path, content: independentMedia[path]}))
const original = await verifyBenchmarkMedia(archive, fixture, responder, 'all')
const streamed = await verifyBenchmarkMediaStreaming(archive, fixture, responder, 'all')
assert.deepEqual(streamed, original)
const rejections = []
for (const mutation of ['changed_bytes', 'missing_entry', 'duplicate_path', 'wrong_dictionary']) {
    await assert.rejects(() => verifyBenchmarkMediaStreaming(archive, fixture, async (paths) => {
        const rows = await responder(paths)
        switch (mutation) {
            case 'changed_bytes': {
                const changed = Buffer.from(rows[0].content, 'base64')
                changed[0] ^= 1
                rows[0].content = changed.toString('base64')
                break
            }
            case 'missing_entry': rows.pop(); break
            case 'duplicate_path': rows[1].path = rows[0].path; break
            case 'wrong_dictionary': rows[0].dictionary = 'wrong'; break
        }
        return rows
    }, 'all'))
    rejections.push(mutation)
}
const digest = async (file) => createHash('sha256').update(await readFile(file)).digest('hex')
const report = {
    kind: 'Independent full Jitendex oracle equivalence and negative response checks',
    node: process.version,
    archiveSha256: await digest(archive),
    responder: 'Python standard-library zipfile independently decoded all249 archive image members; source CRC checked by zipfile; thirteen lock-declared unused images excluded by both oracles',
    originalOracleSha256: await digest(new URL('../combined/dev/perf/import-media-validation.js', import.meta.url)),
    streamingOracleSha256: await digest(new URL('./streaming-media-validation.mjs', import.meta.url)),
    validationScriptSha256: await digest(new URL(import.meta.url)),
    original,
    streamed,
    rejections,
    complete: true,
}
assert.equal(report.archiveSha256, fixture.sha256)
await writeFile(new URL('./streaming-oracle-validation.json', import.meta.url), JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report, null, 2))
