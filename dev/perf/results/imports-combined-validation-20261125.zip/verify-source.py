#!/usr/bin/env python3
"""Verify the reconstructed runtime and changed text sources without running tests."""

import hashlib
import json
from pathlib import Path
import sys


bundle = Path(__file__).resolve().parent
manifest = json.loads((bundle / "manifest.json").read_text())
root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
expected = {}
for record in manifest["runtimeHashes"] + manifest["changedTextHashes"]:
    expected[record["path"]] = record["combinedSha256"]
expected["package-lock.json"] = manifest["environment"]["dependencyLockSha256"]
expected["test/perf/dictionaries.lock.json"] = manifest["environment"]["dictionaryLockSha256"]
failures = []
for name, digest in sorted(expected.items()):
    file = root / name
    if not file.is_file():
        failures.append(name + ": missing")
    elif hashlib.sha256(file.read_bytes()).hexdigest() != digest:
        failures.append(name + ": SHA-256 mismatch")
if failures:
    raise SystemExit("\n".join(failures))
print(f"Verified {len(expected)} source/runtime and lock identities in {root}")
