#!/usr/bin/env python3
"""Package all component observations while manifesting reproducible corpus bytes."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import sys

root = Path(sys.argv[1]).resolve()
destination = Path(sys.argv[2]).resolve()
assert not destination.exists(), 'Never replace a retained proof archive'
assert root not in destination.parents, 'Keep generated archives outside the proof input tree'
excluded = json.loads((root / 'excluded-corpus-manifest.json').read_text())
excluded_names = {entry['path'] for entry in excluded['files']}
entries = []
for path in sorted(root.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(root).as_posix()
    if relative in excluded_names or relative == 'proof-manifest.json':
        continue
    assert not relative.endswith(('.raw', '.zstd-envelope'))
    data = path.read_bytes()
    entries.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
proof = {
    'scope': 'All original component observations, failures, identities and reproduction; derived corpus bytes excluded with complete manifest',
    'files': entries,
    'excludedCorpusFiles': len(excluded['files']),
    'excludedCorpusBytes': excluded['totalBytes'],
    'manifestExcludesSelf': True,
}
(root / 'proof-manifest.json').write_text(json.dumps(proof, indent=4) + '\n')
names = sorted([entry['path'] for entry in entries] + ['proof-manifest.json'])
with destination.open('xb') as output:
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, compresslevel=9, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name in names:
                data = (root / name).read_bytes()
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))
with tarfile.open(destination, 'r:gz') as archive:
    assert archive.getnames() == names
    for member in archive:
        assert member.isfile()
        assert archive.extractfile(member).read() == (root / member.name).read_bytes()
receipt = {
    'archive': destination.name,
    'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
    'bytes': destination.stat().st_size,
    'members': len(names),
    'uncompressedBytes': sum((root / name).stat().st_size for name in names),
    'excludedCorpusFiles': len(excluded['files']),
    'excludedCorpusBytes': excluded['totalBytes'],
    'actualArchiveMemberSetAndBytesVerified': True,
    'determinism': 'Sorted USTAR members; zero timestamps/uid/gid; fixed mode; empty owner/group names; gzip filename empty and mtime zero',
}
destination.with_name(destination.name + '.json').write_text(json.dumps(receipt, indent=4) + '\n')
print(json.dumps(receipt, indent=2))
