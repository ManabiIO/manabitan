/* Copyright (C) 2026 Manabitan authors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {openAsBlob} from 'node:fs'
import {mkdir, readFile, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import {BlobReader, Uint8ArrayWriter, ZipReader} from '@zip.js/zip.js'
import {DictionaryDatabase} from '../../../ext/js/dictionary/dictionary-database.js'
import {parseTermBankWithWasmColumnChunks, setTermBankWasmModule} from '../../../ext/js/dictionary/term-bank-wasm-parser.js'
import {initializeTermContentZstd, decompressTermContentZstd} from '../../../ext/js/dictionary/zstd-term-content.js'
import {RAW_TERM_CONTENT_TOKEN_DICT_NAME} from '../../../ext/js/dictionary/raw-term-content.js'

const [cache, destination, ...requested] = process.argv.slice(2)
assert(cache && destination, 'Usage: capture.mjs CACHE OUTPUT [jmdict jitendex]')
const root = fileURLToPath(new URL('../../../', import.meta.url))
const fixtures = JSON.parse(await readFile(path.join(root, 'test/perf/dictionaries.lock.json'), 'utf8')).dictionaries
const digest = (bytes) => createHash('sha256').update(bytes).digest('hex')
const originalFetch = globalThis.fetch
globalThis.fetch = async (input, options) => {
    const url = new URL(typeof input === 'string' ? input : input instanceof URL ? input.href : input.url)
    if (url.protocol !== 'file:') { return await originalFetch(input, options) }
    const filename = fileURLToPath(url)
    assert(filename.startsWith(path.join(root, 'ext/lib/')), 'Only packaged local assets may use the file adapter')
    const bytes = await readFile(filename)
    return new Response(bytes, {headers: {'Content-Type': filename.endsWith('.wasm') ? 'application/wasm' : 'application/octet-stream'}})
}
await initializeTermContentZstd()
setTermBankWasmModule(await WebAssembly.compile(await readFile(path.join(root, 'dev/data/dictionary-wasm/term-bank-parser.wasm'))))

// The file adapter preserves physical offsets and the production block reader,
// reference/checksum format, decoder, global exact matching and cache policy.
class MemoryContentFile {
    constructor() {
        this.parts = []
        this.length = 0
        this.primaryBytes = 0
        this.derivedBytes = 0
    }
    append(chunks) {
        const offsets = []
        const lengths = []
        for (const chunk of chunks) {
            const bytes = Uint8Array.from(chunk)
            offsets.push(this.length)
            lengths.push(bytes.length)
            this.parts.push({offset: this.length, bytes})
            this.length += bytes.length
        }
        return {offsets, lengths}
    }
    async appendBatchWithDerivedChunks(chunks, createDerived) {
        const primary = this.append(chunks)
        const derived = this.append(createDerived(primary.offsets, primary.lengths))
        this.primaryBytes += primary.lengths.reduce((a, b) => a + b, 0)
        this.derivedBytes += derived.lengths.reduce((a, b) => a + b, 0)
        return {primaryOffsets: primary.offsets, primaryLengths: primary.lengths, derivedOffsets: derived.offsets, derivedLengths: derived.lengths}
    }
    async readSlice(offset, length) {
        assert(Number.isSafeInteger(offset) && Number.isSafeInteger(length) && offset >= 0 && length >= 0)
        const part = this.parts.findLast((candidate) => candidate.offset <= offset)
        assert(part && offset + length <= part.offset + part.bytes.length, `Read outside captured file at ${offset}+${length}`)
        return part.bytes.subarray(offset - part.offset, offset - part.offset + length)
    }
    async readSlicesDetailed(requests) {
        return await Promise.all(requests.map(async ({offset, length}) => ({status: 'ok', bytes: await this.readSlice(offset, length)})))
    }
}

function partition(entries, totalBytes, requestedCount) {
    const count = Math.min(entries.length, requestedCount)
    const groups = []
    let start = 0
    let consumed = 0
    for (let index = 0; index < count - 1; ++index) {
        const target = (totalBytes - consumed) / (count - index)
        let end = start + 1
        let bytes = entries[start].uncompressedSize
        const maxEnd = entries.length - (count - index - 1)
        while (end < maxEnd) {
            const next = bytes + entries[end].uncompressedSize
            if (Math.abs(next - target) > Math.abs(bytes - target)) { break }
            bytes = next
            ++end
        }
        groups.push(entries.slice(start, end))
        start = end
        consumed += bytes
    }
    groups.push(entries.slice(start))
    return groups
}

const expected = {
    jmdict: {unique: 362032, pendingHits: 162269, persistedHits: 3998, encodedBytes: 101143985, contentFileBytes: 19566680},
    jitendex: {unique: 363243, pendingHits: 73278, persistedHits: 34, encodedBytes: 389707807, contentFileBytes: 38386795},
}
const reports = []
await mkdir(destination, {recursive: true})
for (const id of requested.length ? requested : ['jmdict', 'jitendex']) {
    const fixture = fixtures[id]
    assert(fixture && expected[id])
    const archive = path.join(cache, fixture.cacheFile)
    const archiveBytes = await readFile(archive)
    assert.equal(archiveBytes.length, fixture.sizeBytes)
    assert.equal(digest(archiveBytes), fixture.sha256)
    const reader = new ZipReader(new BlobReader(await openAsBlob(archive)), {useWebWorkers: false})
    const directory = path.join(destination, id)
    await mkdir(path.join(directory, 'blocks'), {recursive: true})
    try {
        const allEntries = await reader.getEntries()
        const indexEntry = allEntries.find((entry) => entry.filename === 'index.json')
        const index = JSON.parse(new TextDecoder().decode(await indexEntry.getData(new Uint8ArrayWriter(), {checkSignature: true})))
        assert.equal(index.title, fixture.expectedTitle)
        assert.equal(index.revision, fixture.revision)
        const entries = allEntries.filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename))
            .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
        const sourceBytes = entries.reduce((sum, entry) => sum + entry.uncompressedSize, 0)
        const groups = partition(entries, sourceBytes, Math.max(id === 'jmdict' ? 12 : 9, Math.ceil(sourceBytes / (24 * 1024 * 1024))))
        const database = new DictionaryDatabase()
        const file = new MemoryContentFile()
        const store = database._termContentBlockStore
        store._contentStore = file
        database._termContentStore = file
        database._termContentZstdInitialized = true
        database._bulkImportTransactionOpen = true
        database._termContentBlockImportSession = store.beginImportSession()
        // Disable only reservation scheduling; this is untimed block capture.
        // The exact dedup selection, block planner, compressor and format run.
        database._tryBeginPersistArtifactTermContent = () => null
        database._appendResolvedArtifactTermRecords = async () => {}
        let activeSpans = null
        const originalShared = store._tryAppendSharedSpans.bind(store)
        store._tryAppendSharedSpans = async (...args) => {
            assert.equal(activeSpans, null)
            activeSpans = {source: args[0], offsets: args[1], lengths: args[2]}
            try { return await originalShared(...args) } finally { activeSpans = null }
        }
        const report = {id, fixture, groups: groups.length, banks: entries.length, rows: 0, encodedBytes: 0, unique: 0, pendingHits: 0, persistedHits: 0, blockTargetBytes: store._blockTargetBytes, sourceBytes, blocks: [], groupReports: []}
        let groupIndex = 0
        const originalAppend = store._appendCompressedBlocks.bind(store)
        store._appendCompressedBlocks = async (...args) => {
            const [packed, blockLengths, sourceLengths, dictName, , compressedChunks] = args
            assert(activeSpans !== null, 'Expected the production shared-span path')
            assert.equal(dictName, 'jmdict')
            assert.equal(compressedChunks.length, blockLengths.length)
            for (let blockIndex = 0; blockIndex < compressedChunks.length; ++blockIndex) {
                const compressed = compressedChunks[blockIndex]
                const raw = Uint8Array.from(decompressTermContentZstd(compressed.subarray(12), dictName, {maxOutputSize: blockLengths[blockIndex]}))
                assert.equal(raw.length, blockLengths[blockIndex])
                let offset = 0
                for (let row = packed.blockStartIndexes[blockIndex]; row < packed.blockStartIndexes[blockIndex + 1]; ++row) {
                    const original = activeSpans.source.subarray(activeSpans.offsets[row], activeSpans.offsets[row] + sourceLengths[row])
                    assert.deepEqual(raw.subarray(offset, offset + original.length), original)
                    offset += original.length
                }
                assert.equal(offset, raw.length)
                const number = report.blocks.length
                const filename = `blocks/${String(number).padStart(4, '0')}.raw`
                const compressedFilename = `blocks/${String(number).padStart(4, '0')}.level-1.zstd-envelope`
                await writeFile(path.join(directory, filename), raw)
                await writeFile(path.join(directory, compressedFilename), compressed)
                report.blocks.push({number, groupIndex, blockIndex, contentStartIndex: packed.blockStartIndexes[blockIndex], contentEndIndex: packed.blockStartIndexes[blockIndex + 1], bytes: raw.length, sha256: digest(raw), filename, compressedBytes: compressed.length, compressedSha256: digest(compressed), compressedFilename})
            }
            const result = await originalAppend(...args)
            assert(result !== null, 'All captured groups must actually select production compressed storage')
            return result
        }
        for (groupIndex = 0; groupIndex < groups.length; ++groupIndex) {
            const sources = []
            for (const entry of groups[groupIndex]) {
                sources.push(await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}))
            }
            await parseTermBankWithWasmColumnChunks(sources, 3, async (chunk) => {
                report.rows += chunk.rowCount
                report.encodedBytes += chunk.contentBytesLength
                await database._bulkAddArtifactTermsChunkWithContentDedup({...chunk, dictionary: fixture.expectedTitle, dictionaryTotalRows: fixture.termRows, contentDictNameList: null, uniformContentDictName: RAW_TERM_CONTENT_TOKEN_DICT_NAME})
                const metrics = database._lastBulkAddTermsMetrics
                report.unique += metrics.dedupUniqueCount
                report.pendingHits += metrics.dedupPendingHitCount
                report.persistedHits += metrics.dedupPersistedHitCount
                report.groupReports.push({groupIndex, rows: chunk.rowCount, metrics})
            }, 2048, {singleChunk: true, emitTermByteLists: false, emitContentSlab: true, emitTokenBinaryContent: true, mediaHintFastScan: true, prepareLookupIndexes: true, validateGlossaryTypes: true, compactContentMetadata: true, experimentalNativeEscapedKeys: sourceBytes >= 512 * 1024 * 1024})
            process.stdout.write(JSON.stringify({id, completedGroups: groupIndex + 1, groups: groups.length, rows: report.rows, unique: report.unique, blocks: report.blocks.length}) + '\n')
        }
        database._termContentBlockImportSession.close()
        report.compressedBytes = file.primaryBytes
        report.referenceBytes = file.derivedBytes
        report.contentFileBytes = file.length
        report.contentFileChunks = file.parts.length
        report.nativeCanonical = database._nativeCanonicalScanner.stats
        report.productionInventoryExpected = expected[id]
        report.productionInventoryMatch = Object.entries(expected[id]).every(([key, value]) => report[key] === value)
        assert.equal(report.rows, fixture.termRows)
        await writeFile(path.join(directory, 'capture.json'), JSON.stringify(report, null, 4) + '\n')
        reports.push(report)
        await writeFile(path.join(destination, 'capture.json'), JSON.stringify({scope: 'Untimed production parser/global-dedup/block planner replay with memory-backed physical content persistence and reservation scheduling disabled', reports}, null, 4) + '\n')
        process.stdout.write(JSON.stringify({id, complete: true, rows: report.rows, unique: report.unique, pendingHits: report.pendingHits, persistedHits: report.persistedHits, encodedBytes: report.encodedBytes, blocks: report.blocks.length, compressedBytes: report.compressedBytes, contentFileBytes: report.contentFileBytes, productionInventoryMatch: report.productionInventoryMatch}) + '\n')
    } finally { await reader.close() }
}
