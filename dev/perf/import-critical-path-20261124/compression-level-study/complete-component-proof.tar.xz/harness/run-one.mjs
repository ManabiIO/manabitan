/* Copyright (C) 2026 Manabitan authors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {mkdir, readFile, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import {performance} from 'node:perf_hooks'
import {init, createCCtx, createDCtx, freeCCtx, freeDCtx, compressUsingDictWithPrefix, decompressUsingDict} from '../../../ext/lib/zstd-wasm.js'
import {wrapCompressedTermContentBlock} from '../../../ext/js/dictionary/term-content-block-envelope.js'

const [planFile, corpus, arm, blockText, destination] = process.argv.slice(2)
assert(planFile && corpus && arm && blockText && destination)
const plan = JSON.parse(await readFile(planFile, 'utf8'))
assert(Object.hasOwn(plan.arms, arm))
const level = plan.arms[arm]
const root = fileURLToPath(new URL('../../../', import.meta.url))
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
for (const [relative, expected] of Object.entries(plan.productSha256)) {
    assert.equal(sha(await readFile(path.join(root, relative))), expected, relative)
}
assert.equal(sha(await readFile(fileURLToPath(import.meta.url))), plan.runnerSha256)
const corpusDirectory = path.join(plan.captureDirectory, corpus)
const captureFile = path.join(corpusDirectory, 'capture.json')
assert.equal(sha(await readFile(captureFile)), plan.captures[corpus].sha256)
const capture = JSON.parse(await readFile(captureFile, 'utf8'))
const blocks = []
for (const entry of capture.blocks) {
    const bytes = new Uint8Array(await readFile(path.join(corpusDirectory, entry.filename)))
    assert.equal(bytes.length, entry.bytes)
    assert.equal(sha(bytes), entry.sha256)
    blocks.push(bytes)
}
const dictionary = new Uint8Array(await readFile(path.join(root, 'ext/lib/zstd-dicts/jmdict.zdict')))
const originalFetch = globalThis.fetch
globalThis.fetch = async (input, options) => {
    const url = new URL(typeof input === 'string' ? input : input instanceof URL ? input.href : input.url)
    if (url.protocol !== 'file:') { return await originalFetch(input, options) }
    assert.equal(url.href, new URL('../../../ext/lib/zstd.wasm', import.meta.url).href)
    return new Response(await readFile(fileURLToPath(url)), {headers: {'Content-Type': 'application/wasm'}})
}
await init(new URL('../../../ext/lib/zstd.wasm', import.meta.url).href)
const cctx = createCCtx()
const dctx = createDCtx()
assert(cctx && dctx)
const report = {corpus, arm, level, block: Number(blockText), planSha256: sha(await readFile(planFile)), sourceBlockCount: blocks.length, rawBytes: blocks.reduce((n, bytes) => n + bytes.length, 0), observations: [], status: 'running'}
await mkdir(destination, {recursive: true})
const referenceDirectory = path.join(plan.outputDirectory, 'compressed-reference', corpus, `level${level}`)
await mkdir(referenceDirectory, {recursive: true})
try {
    let hashes = null
    let compressedSizes = null
    for (let pass = 0; pass <= plan.excludedWarmupPasses; ++pass) {
        globalThis.gc()
        const outputs = new Array(blocks.length)
        const blockMs = new Float64Array(blocks.length)
        const started = performance.now()
        for (let index = 0; index < blocks.length; ++index) {
            const before = performance.now()
            outputs[index] = compressUsingDictWithPrefix(cctx, blocks[index], dictionary, 12, level, true)
            blockMs[index] = performance.now() - before
        }
        const loopMs = performance.now() - started
        // Every byte is verified after all timed calls; no hashing, decoding,
        // file I/O, process setup or GC is included in compression durations.
        const nextHashes = []
        const nextSizes = []
        for (let index = 0; index < outputs.length; ++index) {
            const output = outputs[index]
            assert.deepEqual(output, wrapCompressedTermContentBlock(output.subarray(12)))
            const decoded = decompressUsingDict(dctx, output.subarray(12), dictionary, {defaultHeapSize: blocks[index].length, maxOutputSize: blocks[index].length})
            assert.deepEqual(decoded, blocks[index])
            const outputSha = sha(output)
            if (level === -1) { assert.equal(outputSha, capture.blocks[index].compressedSha256, `Original production frame differs at block ${index}`) }
            nextHashes.push(outputSha)
            nextSizes.push(output.length)
        }
        if (hashes !== null) {
            assert.deepEqual(nextHashes, hashes)
            assert.deepEqual(nextSizes, compressedSizes)
        }
        hashes = nextHashes
        compressedSizes = nextSizes
        const observation = {pass, warmup: pass < plan.excludedWarmupPasses, loopMs, wrapperCallsMs: blockMs.reduce((a, b) => a + b, 0), blockMs: Array.from(blockMs), compressedSizes: nextSizes, compressedSha256: nextHashes, compressedBytes: nextSizes.reduce((a, b) => a + b, 0), exactDecompression: true, validEnvelope: true}
        report.observations.push(observation)
        if (!observation.warmup) {
            for (let index = 0; index < outputs.length; ++index) {
                const filename = path.join(referenceDirectory, `${String(index).padStart(4, '0')}.zstd-envelope`)
                try {
                    const existing = await readFile(filename)
                    assert.deepEqual(new Uint8Array(existing), outputs[index], 'Independent observation changed compressed output')
                } catch (error) {
                    if (error.code !== 'ENOENT') { throw error }
                    await writeFile(filename, outputs[index], {flag: 'wx'})
                }
            }
        }
    }
    report.status = 'passed'
} catch (error) {
    report.status = 'failed'
    report.error = {message: String(error), stack: error.stack}
    throw error
} finally {
    freeCCtx(cctx)
    freeDCtx(dctx)
    await writeFile(path.join(destination, 'observation.json'), JSON.stringify(report, null, 4) + '\n')
}
const measured = report.observations.at(-1)
process.stdout.write(JSON.stringify({corpus, arm, level, block: report.block, loopMs: measured.loopMs, wrapperCallsMs: measured.wrapperCallsMs, compressedBytes: measured.compressedBytes, status: report.status}) + '\n')
