#!/usr/bin/env python3
"""Recompute the fixed compression component cohort; no new measurements."""
import hashlib
import json
from pathlib import Path
import statistics
import sys

root = Path(sys.argv[1])
destination = Path(sys.argv[2])
assert not destination.exists(), 'Choose a new output path; preserve prior analysis'
plan_bytes = (root / 'plan.json').read_bytes()
plan = json.loads(plan_bytes)
plan_sha = hashlib.sha256(plan_bytes).hexdigest()
commands = json.loads((root / 'commands.json').read_text())
assert len(commands) == plan['plannedMeasuredObservations'] == 64
assert all(command['exitCode'] == 0 for command in commands)
expected = [(corpus, block, arm) for corpus in plan['corpora'] for block, order in enumerate(plan['orders']) for arm in order]
assert [(command['corpus'], command['block'], command['arm']) for command in commands] == expected
results = {}
capture_directory = root.parent / Path(plan['captureDirectory']).name
for corpus in plan['corpora']:
    capture_file = capture_directory / corpus / 'capture.json'
    assert hashlib.sha256(capture_file.read_bytes()).hexdigest() == plan['captures'][corpus]['sha256']
    capture = json.loads(capture_file.read_text())
    arms = {arm: [] for arm in plan['arms']}
    hashes_by_level = {}
    for block, order in enumerate(plan['orders']):
        for arm in order:
            report = json.loads((root / 'observations' / f'{corpus}-{block:02}-{arm}' / 'observation.json').read_text())
            assert report['status'] == 'passed' and report['planSha256'] == plan_sha
            assert report['arm'] == arm and report['level'] == plan['arms'][arm]
            assert len(report['observations']) == plan['excludedWarmupPasses'] + 1 == 3
            for index, observation in enumerate(report['observations']):
                assert observation['warmup'] == (index < 2)
                assert observation['exactDecompression'] and observation['validEnvelope']
                assert len(observation['blockMs']) == len(capture['blocks'])
                assert all(value >= 0 for value in observation['blockMs'])
                level = report['level']
                if level in hashes_by_level:
                    assert hashes_by_level[level] == observation['compressedSha256']
                else:
                    hashes_by_level[level] = observation['compressedSha256']
                if level == -1:
                    assert observation['compressedSha256'] == [entry['compressedSha256'] for entry in capture['blocks']]
            arms[arm].append(report['observations'][-1])
    comparisons = {}
    for candidate, control in [('B', 'A'), ('B', 'D'), ('C', 'A'), ('C', 'D'), ('D', 'A')]:
        candidate_times = [observation['wrapperCallsMs'] for observation in arms[candidate]]
        control_times = [observation['wrapperCallsMs'] for observation in arms[control]]
        paired = [100 * (a / b - 1) for a, b in zip(candidate_times, control_times)]
        comparisons[f'{candidate}/{control}'] = {
            'pairedMedianPercent': statistics.median(paired),
            'equalWorkPercent': 100 * (sum(candidate_times) / sum(control_times) - 1),
            'fasterPairs': sum(value < 0 for value in paired),
            'pairs': len(paired),
            'pairedPercent': paired,
        }
    baseline = arms['A'][0]['compressedBytes']
    assert baseline == capture['compressedBytes']
    levels = {}
    for arm, level in plan['arms'].items():
        sizes = {observation['compressedBytes'] for observation in arms[arm]}
        assert len(sizes) == 1
        compressed = sizes.pop()
        content_file_bytes = compressed + capture['referenceBytes']
        levels[str(level)] = {
            'compressedBytes': compressed,
            'compressedDeltaBytes': compressed - baseline,
            'compressedDeltaPercent': 100 * (compressed / baseline - 1),
            'contentFileBytes': content_file_bytes,
            'contentFileDeltaBytes': content_file_bytes - capture['contentFileBytes'],
            'contentFileDeltaPercent': 100 * (content_file_bytes / capture['contentFileBytes'] - 1),
            'meetsOnePercentContentFileBudget': content_file_bytes <= 1.01 * capture['contentFileBytes'],
            'meetsTwoPercentContentFileBudget': content_file_bytes <= 1.02 * capture['contentFileBytes'],
            'meetsFivePercentContentFileBudget': content_file_bytes <= 1.05 * capture['contentFileBytes'],
        }
    results[corpus] = {
        'sourceBlocks': len(capture['blocks']),
        'rawBytes': sum(entry['bytes'] for entry in capture['blocks']),
        'captureProductionInventoryMatch': capture['productionInventoryMatch'],
        'medianWrapperCallsMs': {arm: statistics.median(observation['wrapperCallsMs'] for observation in values) for arm, values in arms.items()},
        'medianLoopMs': {arm: statistics.median(observation['loopMs'] for observation in values) for arm, values in arms.items()},
        'comparisons': comparisons,
        'levels': levels,
    }
analysis = {
    'scope': 'Complete fixed Node compression component cohort; not whole-import timing',
    'planSha256': plan_sha,
    'measuredObservations': 64,
    'excludedWarmupPasses': 128,
    'allParityChecksPassed': True,
    'corpora': results,
}
destination.write_text(json.dumps(analysis, indent=4) + '\n')
print(json.dumps({'destination': str(destination), 'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}))
