/* Copyright (C) 2026 Manabitan authors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
import assert from 'node:assert/strict'
import {spawnSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {mkdirSync, readFileSync, writeFileSync} from 'node:fs'
import path from 'node:path'
import {fileURLToPath} from 'node:url'

const [planFile] = process.argv.slice(2)
assert(planFile)
const planBytes = readFileSync(planFile)
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const plan = JSON.parse(planBytes)
assert.equal(sha(readFileSync(fileURLToPath(import.meta.url))), plan.driverSha256)
const runner = fileURLToPath(new URL('./run-one.mjs', import.meta.url))
const commands = []
mkdirSync(path.join(plan.outputDirectory, 'observations'), {recursive: false})
for (const corpus of plan.corpora) {
    for (let block = 0; block < plan.orders.length; ++block) {
        for (const arm of plan.orders[block]) {
            const directory = path.join(plan.outputDirectory, 'observations', `${corpus}-${String(block).padStart(2, '0')}-${arm}`)
            mkdirSync(directory)
            assert.equal(sha(readFileSync(planFile)), sha(planBytes))
            const args = ['--expose-gc', runner, planFile, corpus, arm, String(block), directory]
            const result = spawnSync(process.execPath, args, {encoding: 'utf8', maxBuffer: 8 * 1024 * 1024})
            writeFileSync(path.join(directory, 'stdout.log'), result.stdout ?? '')
            writeFileSync(path.join(directory, 'stderr.log'), result.stderr ?? '')
            commands.push({corpus, block, arm, command: [process.execPath, ...args], exitCode: result.status, signal: result.signal, error: result.error ? String(result.error) : null, stdoutSha256: sha(result.stdout ?? ''), stderrSha256: sha(result.stderr ?? '')})
            writeFileSync(path.join(plan.outputDirectory, 'commands.json'), JSON.stringify(commands, null, 4) + '\n')
            process.stdout.write(result.stdout ?? '')
            assert.equal(result.status, 0, `Component observation failed: ${directory}`)
        }
    }
}
process.stdout.write(JSON.stringify({complete: true, observations: commands.length, planSha256: sha(planBytes)}) + '\n')
