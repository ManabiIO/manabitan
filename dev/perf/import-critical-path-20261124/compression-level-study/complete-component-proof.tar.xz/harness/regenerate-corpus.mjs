/* Copyright (C) 2026 Manabitan authors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {mkdir, readFile, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import {init, createCCtx, createDCtx, freeCCtx, freeDCtx, compressUsingDictWithPrefix, decompressUsingDict} from '../../../ext/lib/zstd-wasm.js'

const [planFile, excludedManifestFile, captureDirectory, outputDirectory] = process.argv.slice(2)
assert(planFile && excludedManifestFile && captureDirectory && outputDirectory,
    'Usage: regenerate-corpus.mjs PLAN EXCLUDED-MANIFEST CAPTURE-DIRECTORY OUTPUT-DIRECTORY-OR--verify-only')
const plan = JSON.parse(await readFile(planFile, 'utf8'))
const manifest = JSON.parse(await readFile(excludedManifestFile, 'utf8'))
const expected = new Map(manifest.files.map((entry) => [entry.path, entry]))
const root = fileURLToPath(new URL('../../../', import.meta.url))
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
for (const [relative, expectedHash] of Object.entries(plan.productSha256)) {
    assert.equal(sha(await readFile(path.join(root, relative))), expectedHash, relative)
}
const originalFetch = globalThis.fetch
globalThis.fetch = async (input, options) => {
    const url = new URL(typeof input === 'string' ? input : input instanceof URL ? input.href : input.url)
    if (url.protocol !== 'file:') { return await originalFetch(input, options) }
    assert.equal(url.href, new URL('../../../ext/lib/zstd.wasm', import.meta.url).href)
    return new Response(await readFile(fileURLToPath(url)), {headers: {'Content-Type': 'application/wasm'}})
}
await init(new URL('../../../ext/lib/zstd.wasm', import.meta.url).href)
const dictionary = new Uint8Array(await readFile(path.join(root, 'ext/lib/zstd-dicts/jmdict.zdict')))
const dctx = createDCtx()
let frames = 0
try {
    for (const corpus of plan.corpora) {
        const capture = JSON.parse(await readFile(path.join(captureDirectory, corpus, 'capture.json'), 'utf8'))
        for (const level of [-1, -2, -3]) {
            const cctx = createCCtx()
            assert(cctx)
            try {
                for (const entry of capture.blocks) {
                    const raw = new Uint8Array(await readFile(path.join(captureDirectory, corpus, entry.filename)))
                    const rawExpected = expected.get(`capture-attempt-2/${corpus}/${entry.filename}`)
                    assert(rawExpected)
                    assert.equal(raw.length, rawExpected.bytes)
                    assert.equal(sha(raw), rawExpected.sha256)
                    const output = compressUsingDictWithPrefix(cctx, raw, dictionary, 12, level, true)
                    const relative = `compressed-reference/${corpus}/level${level}/${String(entry.number).padStart(4, '0')}.zstd-envelope`
                    const outputExpected = expected.get(`cohort-1/${relative}`)
                    assert(outputExpected)
                    assert.equal(output.length, outputExpected.bytes)
                    assert.equal(sha(output), outputExpected.sha256)
                    assert.deepEqual(decompressUsingDict(dctx, output.subarray(12), dictionary, {defaultHeapSize: raw.length, maxOutputSize: raw.length}), raw)
                    if (outputDirectory !== '--verify-only') {
                        const destination = path.join(outputDirectory, relative)
                        await mkdir(path.dirname(destination), {recursive: true})
                        await writeFile(destination, output, {flag: 'wx'})
                    }
                    ++frames
                }
            } finally { freeCCtx(cctx) }
        }
    }
} finally { freeDCtx(dctx) }
process.stdout.write(JSON.stringify({frames, complete: true, exactRegeneration: true, performanceMeasurement: false}) + '\n')
