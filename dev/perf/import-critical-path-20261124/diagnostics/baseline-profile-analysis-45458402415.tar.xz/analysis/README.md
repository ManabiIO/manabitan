# Frozen import diagnostics, 2026-11-24

These are diagnostic profiles of product baseline `698d685c21618a8e8dbdab7a49a8dcf0d30680eb`, collected by study commit `b64229bd743000c854762d109c7db3e8156e85a2` in [Actions run 45458402415](https://github.com/ManabiIO/manabitan/actions/runs/45458402415). All three jobs succeeded. The study source guard permits only its workflow file to differ from the baseline. Node 22.22.0, Chromium 153.0.8010.12, locked archives, production defaults, and the repository's unchanged complete-import benchmark were used.

Each dictionary has one traced observation. Tracing is explicitly nonauthoritative; these values identify work to investigate and cannot establish a latency improvement. The runs retain twelve source-derived lookup probes, seventy-two lookup observations, restart validation, and sampled media verification. JMdict retained 528,299 terms / 0 media; Jitendex 436,555 terms / 236 media; VNDB 6,648,310 terms / 146,570 media. This diagnostic run did not exhaustively hash every media file.

## Findings

VNDB's worker result-copy path is a material target: the anonymous glossary conversion callback at term-bank-wasm-parser.js:4048 has 7,280 self samples, the JSON parser 3,592, and copyWasmBackedColumnChunk 13,974 inclusive samples. The aggregate result-copy phase reports 4,714 ms. These support evaluating semantic path extraction directly from validated native glossary spans while preserving the existing JSON collector for fallback.

VNDB sidecar construction has 3,005 inclusive samples; its XXH32 hash wrapper 971. The existing index writer is mostly idle, so relocating unchanged checksums is a smaller scheduling candidate. The reported termLookupIndexEncode 1,278.5 ms includes 969.1 ms of prepared parser-worker encode time; the two must not be added.

JMdict's content compression reports 604 ms and recent-source cache 154.5 ms. Jitendex reports 483 ms packing and 685 ms compression; packContentSpanBlock has 1,473 self samples. Compression worker message dispatch dominates postMessage/setTimeout samples in both small dictionaries. Cache source adoption was subsequently changed by merged #824, so that opportunity must be assessed on the newer baseline before implementation.

| Diagnostic counter (ms) | JMdict | Jitendex | VNDB |
| --- | ---: | ---: | ---: |
| Worker import |1723.7|2882.9|11126.9|
| Parser parse, summed workers |2034|2441|15377|
| Parser result copy |218.3|640.2|4714.3|
| Content append |919.8|1679.3|1563.7|
| Content packing |9.8|482.9|146.5|
| Content compression |604.1|684.7|395.4|
| Record encode |83.9|51.6|1081.3|
| Record write |127.4|123.3|1163.8|

These intervals overlap and have different ownership boundaries. Summing the rows would be invalid.

## Trace interpretation

`analyze_traces.py` groups profiles by process and profile ID. ProfileChunk events run on profiler threads, so it takes the original thread from the initial Profile event. Signed sample deltas can be negative because Chrome emits some samples out of chronological order; the script reconstructs cumulative timestamps and sorts samples before computing interval weights. Counts and negative-delta diagnostics are retained.

Sampling weights include scheduling delay and blocking waits. They are not CPU milliseconds. The SQLite proxy's near-continuous wait frame is therefore excluded from hotspot interpretation. Inclusive stacks overlap by construction. Complete per-profile self/inclusive tables and phase reports are retained in the analysis bundle.

## Provenance and retained failure

Original GitHub ZIP digests are verified before deterministic tar.xz packaging, and every retained raw member is compared byte-for-byte with its original ZIP. The three diagnostic bundles contain each source.json, summary.json, run-1.json, and raw Chrome trace. HTML is redundant and remains in the downloaded original ZIP.

The public Playwright runtime artifact 14952330785 is excluded from these compact bundles because it is 291,622,356 bytes. Its GitHub ZIP digest is `5f07a8a2bfd6b83abdc160b65375afe0b26712185bc05bb907d7790957127c9d`; the inner tar digest is `ac65f03c0eeb88d7853423f0f58ae229e5b9b3ffeec6bcad2af3f4569193825b`. Its verification receipt is included.

A separate local sidecar screen failed during baseline warmup before any import: Chromium could not create its process-singleton AF_UNIX socket (EPERM). It produced zero observations. All fifteen local failure files, including logs and raw report, are bundled unchanged. Its source baseline 698d685 and candidate 8b8b45d differ from the later hosted sidecar cohort; they must not be combined.

The first diagnostic study's actionlint run failed on shellcheck SC2016 caused by an intentional JavaScript template expression in a single-quoted shell argument. Profiling itself succeeded. The subsequent hosted support revision replaced that expression and actionlint passed.

