"""Summarize Chrome V8 sampling stacks; these are diagnostic weights, not CPU seconds.

ProfileChunk events are emitted on V8 profiler event threads. Profile identity is
(pid, id), and the initial Profile event supplies the original sampled thread.
Time deltas measure sample spacing and can include waits/host descheduling.
"""
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUN = '45458402415'


def frame_key(frame):
    url = frame.get('url', '')
    if url.startswith('chrome-extension://'):
        url = '/'.join(url.split('/')[3:])
    return (frame.get('functionName', '(anonymous)'), url, frame.get('lineNumber', -1))


def rank(weights, counts, limit=None):
    ordered = sorted(weights.items(), key=lambda item: item[1], reverse=True)
    if limit is not None:
        ordered = ordered[:limit]
    return [{'function': k[0], 'url': k[1], 'line': k[2] + 1,
             'sampleWeightMs': round(v / 1000, 3), 'samples': counts[k]} for k, v in ordered]


def analyze(dictionary):
    path = ROOT / f'critical-path-{dictionary}-{RUN}'
    trace_path = path / 'run-1.trace.json'
    events = json.loads(trace_path.read_text())['traceEvents']
    names = {(e['pid'], e['tid']): e['args']['name'] for e in events if e.get('name') == 'thread_name'}
    profiles = {}
    for e in events:
        if e.get('name') not in ('Profile', 'ProfileChunk'):
            continue
        key = (e['pid'], e['id'])
        p = profiles.setdefault(key, {'nodes': {}, 'samples': [], 'deltas': [], 'chunkTids': set()})
        data = e.get('args', {}).get('data', {})
        if e['name'] == 'Profile':
            p['tid'] = e['tid']
            p['startTime'] = data.get('startTime')
        else:
            p['chunkTids'].add(e['tid'])
            cpu = data.get('cpuProfile', {})
            for n in cpu.get('nodes', []):
                assert n['id'] not in p['nodes'], (dictionary, key, n['id'])
                p['nodes'][n['id']] = n
            samples, deltas = cpu.get('samples', []), data.get('timeDeltas', [])
            assert len(samples) == len(deltas), (dictionary, key, len(samples), len(deltas))
            p['samples'].extend(samples)
            p['deltas'].extend(deltas)

    total_self, total_counts = collections.Counter(), collections.Counter()
    total_inclusive, total_inc_counts = collections.Counter(), collections.Counter()
    profile_results = []
    for (pid, profile_id), p in profiles.items():
        self_weights, self_counts = collections.Counter(), collections.Counter()
        inclusive, inc_counts = collections.Counter(), collections.Counter()
        # Chrome can insert samples out of chronological order. Reconstruct the
        # cumulative timestamps from signed deltas, then sort; do not turn
        # negative deltas into additional sampled time by clamping them.
        timestamp = p['startTime']
        points = []
        for node_id, delta in zip(p['samples'], p['deltas']):
            timestamp += delta
            points.append((timestamp, node_id))
        points.sort(key=lambda point: point[0])
        for index, (timestamp, node_id) in enumerate(points):
            delta = points[index + 1][0] - timestamp if index + 1 < len(points) else 0
            frame = frame_key(p['nodes'][node_id]['callFrame'])
            self_weights[frame] += delta
            self_counts[frame] += 1
            chain = set()
            visited = set()
            while node_id in p['nodes']:
                assert node_id not in visited
                visited.add(node_id)
                node = p['nodes'][node_id]
                chain.add(frame_key(node['callFrame']))
                node_id = node.get('parent')
            for frame in chain:
                inclusive[frame] += delta
                inc_counts[frame] += 1
        total_self.update(self_weights)
        total_counts.update(self_counts)
        total_inclusive.update(inclusive)
        total_inc_counts.update(inc_counts)
        tid = p.get('tid')
        profile_results.append({'pid': pid, 'profileId': profile_id, 'tid': tid,
                                'threadName': names.get((pid, tid)),
                                'chunkEmitterTids': sorted(p['chunkTids']),
                                'nodeCount': len(p['nodes']), 'sampleCount': len(p['samples']),
                                'sampleSpanMs': (points[-1][0] - points[0][0]) / 1000 if points else 0,
                                'negativeRawDeltaCount': sum(delta < 0 for delta in p['deltas']),
                                'negativeRawDeltaMagnitudeMs': -sum(delta for delta in p['deltas'] if delta < 0) / 1000,
                                'self': rank(self_weights, self_counts),
                                'inclusive': rank(inclusive, inc_counts)})
    summary = json.loads((path / 'summary.json').read_text())
    run = summary['runs'][0]
    report = json.loads((path / 'run-1.json').read_text())
    source = json.loads((path / 'source.json').read_text())
    assert source['base'] == '698d685c21618a8e8dbdab7a49a8dcf0d30680eb'
    assert source['commit'] == 'b64229bd743000c854762d109c7db3e8156e85a2'
    assert report['status'] == 'success'
    assert summary['authoritativeTiming'] is False and summary['traceEnabled'] is True
    assert report['skippedVerification'] is False
    result = {'dictionary': dictionary, 'run': RUN, 'source': source,
              'traceSha256': hashlib.sha256(trace_path.read_bytes()).hexdigest(),
              'note': 'Diagnostic sampling weights include descheduling and blocking waits; tracing perturbs timings. Inclusive weights and reported phase intervals overlap. No performance comparison.',
              'browserVersion': summary['browserVersion'], 'hostEnvironment': summary['hostEnvironment'],
              'reportedTotalImportMs': run['totalImportMs'], 'reportedWorkerImportMs': run['workerImportMs'],
              'step4Breakdown': run['step4Breakdown'], 'importDebug': run['importDebug'],
              'self': rank(total_self, total_counts),
              'inclusive': rank(total_inclusive, total_inc_counts),
              'profiles': profile_results}
    (ROOT / f'{dictionary}-profile-analysis.json').write_text(json.dumps(result, indent=2) + '\n')
    interesting = [x for x in result['self'] if x['function'] not in ('(root)', '(idle)', '(program)') and 'sqlite3-opfs-async-proxy' not in x['url']]
    print(json.dumps({'dictionary': dictionary, 'profiles': len(profiles), 'topSelf': interesting[:18]}))


for dictionary in ('jmdict', 'jitendex', 'vndb'):
    analyze(dictionary)
