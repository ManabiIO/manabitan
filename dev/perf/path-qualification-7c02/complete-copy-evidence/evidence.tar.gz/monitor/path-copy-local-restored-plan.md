# One restored-environment complete-copy correctness acquisition

Root authorized one new untimed acquisition after the material executor reset and completion of the other local heavy checks. This is a separate correctness run with the reviewed hosted oracle, original successful 170-group reference manifest, ordinary persistent workers, and exact candidate runtime. No previous partial receipt is reused or combined.

## Fixed identities and scope

- Baseline checkout: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` at the existing root repository.
- Candidate checkout: `e90c4c04172b691985858609094887f9541541dd` at `/tmp/manabitan-path-validation-7c02`.
- Revised hosted driver: SHA-256 `578a6ab02734d031a806c38d8f5148dfb6cd9ed9f98719be94ae79f8dc84b660`.
- Revised hosted helper: SHA-256 `88153533e411e480e566b241797f4ec7f456756422769731c46468ffbb451401`.
- Original reference manifest: SHA-256 `810c067eabf70271a5440775751420ce065e3bfc1ce2a47bfd2cb61c4876a8a2`.
- Hosted package manifest: SHA-256 `5ce3106ea36c0d42ce7c68ada002dc9ff8e39ce7026a6d84dfb9640f09459956`.
- Node 24.22.3 with `--max-old-space-size=1024`, matching the hosted command's heap option while explicitly retaining the local Node-version distinction.
- Locked VNDB archive: 291,705,969 bytes, SHA-256 `da5baed5332761513dcef8d0b07ad0d9201cdd7f37831dea37e7162994ec3792`; the unchanged driver verifies the whole archive before parsing.

The exact ordinary production planner and original group identities remain in force. Each group requires strict same-candidate-module public/batched value, byte and alias equality; independent frozen-baseline values/bytes; unchanged raw source and columns/native heap and buffer; exact reference path digest; one prepared lookup index and route. The complete result requires all 170 groups, 6,648,310 rows, 146,725 group-local media rows, and 170 prepared indexes/routes. Failure remains incomplete. This supplies no latency, scheduling, memory-performance, or pinned-Node22 browser qualification claim.

## External resource monitor frozen before launch

The monitor samples the whole Node process RSS and system MemAvailable once per second. It terminates only this child process when two consecutive samples satisfy either `RSS > 2 GiB` or `MemAvailable < 1 GiB`. It sends SIGTERM, waits up to five seconds, and sends SIGKILL only if the child has not exited. The two consecutive samples use the combined OR condition. A monitoring error also ends this one acquisition and preserves it as failed. No automatic retry is permitted.

Resource samples are diagnostic guard records, not performance observations. The monitor records initial available memory, its exact command and source hashes before process creation, every sample, stdout/stderr, the child exit code and final or partial group counts. It rechecks frozen source identities afterward. The harness's original manifest remains untouched; the external receipt separately records whether a resource abort prevented acceptance.

Output goes only to the new `path-copy-local-restored-20261128/` directory, with the oracle in its `oracle/` subdirectory. The script refuses to reuse an existing acquisition directory. All original cross-module, ordinary-worker and fresh-worker partial attempts remain unchanged in `path-component/`.
