#!/usr/bin/env python3
"""Single untimed original-reference oracle with a prospective resource guard."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import traceback

study = Path(__file__).resolve().parent
repository = study.parent / 'manabitan'
candidate = Path('/tmp/manabitan-path-validation-7c02')
package = study / 'path-copy-hosted'
output = study / 'path-copy-local-restored-20261128'
oracle_output = output / 'oracle'
candidate_commit = 'e90c4c04172b691985858609094887f9541541dd'
base_commit = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
rss_limit = 2 * 1024**3
available_floor = 1024**3
sha = lambda data: hashlib.sha256(data).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
output.mkdir(exist_ok=False)


def available_bytes():
    lines = Path('/proc/meminfo').read_text().splitlines()
    return int(next(line for line in lines if line.startswith('MemAvailable:')).split()[1]) * 1024


def rss_bytes(pid):
    lines = Path(f'/proc/{pid}/status').read_text().splitlines()
    return int(next(line for line in lines if line.startswith('VmRSS:')).split()[1]) * 1024


def save(name, value):
    (output / name).write_text(json.dumps(value, indent=2) + '\n')


command = ['node', '--max-old-space-size=1024', str(package / 'oracle.mjs'),
           str(repository), str(candidate), str(oracle_output)]
receipt = {'complete': False, 'status': 'not-started', 'startedAt': now(),
           'scope': 'One newly authorized untimed original-reference complete-copy oracle after the material environment reset. Node24 correctness only; no latency, scheduling or memory-performance claim. Previous partial attempts remain separate.',
           'command': command, 'resourcePolicy': {'sampleSeconds': 1, 'rssLimitBytes': rss_limit,
             'minimumMemAvailableBytes': available_floor, 'consecutivePressureSamplesBeforeAbort': 2,
             'pressureCondition': 'RSS > 2 GiB OR MemAvailable < 1 GiB',
             'scope': 'Whole Node process RSS includes its worker threads; observations are an external resource guard only.'},
           'resourceAbort': None, 'failures': [], 'priorPartialGroupsReused': 0}
process = None
inputs = []
try:
    expected = {
        package / 'oracle.mjs': '578a6ab02734d031a806c38d8f5148dfb6cd9ed9f98719be94ae79f8dc84b660',
        package / 'worker.mjs': '88153533e411e480e566b241797f4ec7f456756422769731c46468ffbb451401',
        package / 'reference-manifest.json': '810c067eabf70271a5440775751420ce065e3bfc1ce2a47bfd2cb61c4876a8a2',
        package / 'package-manifest.json': '5ce3106ea36c0d42ce7c68ada002dc9ff8e39ce7026a6d84dfb9640f09459956',
        repository / 'ext/js/dictionary/term-bank-wasm-parser.js': '31854cfb3d20ba60b701ec31cf19de26bd55cc745cc4f998cb33f0554ec83cca',
        candidate / 'ext/js/dictionary/term-bank-wasm-parser.js': '69f6f44bb25b1ade2e77ad51a5c830ac359ec3d44f364a3c0ed6131728f54518',
    }
    for path, digest in expected.items():
        data = path.read_bytes()
        assert sha(data) == digest, str(path)
        inputs.append({'path': str(path), 'bytes': len(data), 'sha256': digest})
    for path in [Path(__file__), study / 'path-copy-local-restored-plan.md']:
        data = path.read_bytes()
        inputs.append({'path': str(path), 'bytes': len(data), 'sha256': sha(data)})
    for path, commit in [(repository, base_commit), (candidate, candidate_commit)]:
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=path, text=True).strip() == commit
    receipt['node'] = subprocess.check_output(['node', '--version'], text=True).strip()
    assert receipt['node'] == 'v24.22.3'
    receipt['initialMemAvailableBytes'] = available_bytes()
    receipt['sourceInputs'] = inputs
    save('frozen-inputs.json', {'frozenBeforeExecution': True, 'sources': inputs,
        'baseCommit': base_commit, 'candidateCommit': candidate_commit,
        'command': command, 'node': receipt['node'], 'resourcePolicy': receipt['resourcePolicy'],
        'initialMemAvailableBytes': receipt['initialMemAvailableBytes']})
    save('monitor-receipt.json', receipt)
    env = dict(os.environ, CANDIDATE_SOURCE_COMMIT=candidate_commit)
    with (output / 'stdout.log').open('wb') as stdout, (output / 'stderr.log').open('wb') as stderr, (output / 'resource-samples.jsonl').open('w') as samples:
        process = subprocess.Popen(command, cwd=repository, env=env, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
        receipt['pid'] = process.pid
        receipt['status'] = 'running'
        save('monitor-receipt.json', receipt)
        pressure_streak = 0
        sample_count = 0
        maximum_rss = 0
        minimum_available = receipt['initialMemAvailableBytes']
        while process.poll() is None:
            try:
                rss = rss_bytes(process.pid)
                available = available_bytes()
            except (FileNotFoundError, StopIteration):
                if process.poll() is not None:
                    break
                raise
            pressure = rss > rss_limit or available < available_floor
            pressure_streak = pressure_streak + 1 if pressure else 0
            maximum_rss = max(maximum_rss, rss)
            minimum_available = min(minimum_available, available)
            sample = {'sample': sample_count, 'observedAt': now(), 'rssBytes': rss,
                      'memAvailableBytes': available, 'pressure': pressure,
                      'consecutivePressureSamples': pressure_streak}
            samples.write(json.dumps(sample) + '\n')
            samples.flush()
            sample_count += 1
            if pressure_streak >= 2:
                receipt['resourceAbort'] = sample
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                break
            # Never catch up missed intervals with back-to-back samples.
            time.sleep(1)
        receipt['exitCode'] = process.wait()
        receipt['guardDiagnostics'] = {'samples': sample_count, 'maximumSampledRssBytes': maximum_rss,
                                      'minimumSampledMemAvailableBytes': minimum_available,
                                      'interpretation': 'Resource guard diagnostics only; not a memory-performance result.'}
    for item in inputs:
        assert sha(Path(item['path']).read_bytes()) == item['sha256'], item['path']
    receipt['postSourceIdentityExact'] = True
    manifest_path = oracle_output / 'manifest.json'
    if manifest_path.exists():
        data = manifest_path.read_bytes()
        result = json.loads(data)
        receipt['oracleManifestSha256'] = sha(data)
        receipt['oracleReportedComplete'] = result['complete']
        receipt['oracleFailures'] = result['failures']
    else:
        result = {'complete': False, 'failures': []}
    group_files = sorted(oracle_output.glob('group-*.json'))
    groups = [json.loads(path.read_bytes()) for path in group_files]
    receipt['groups'] = len(groups)
    receipt['rowsChecked'] = sum(group['sourceRows'] for group in groups)
    receipt['mediaRowsChecked'] = sum(group['mediaRows'] for group in groups)
    receipt['preparedIndexes'] = sum(group['preparedIndexes'] for group in groups)
    receipt['preparedRoutes'] = sum(group['preparedRoutes'] for group in groups)
    if receipt['exitCode'] == 0 and receipt['resourceAbort'] is None and result['complete'] and not result['failures']:
        assert receipt['groups'] == 170
        assert receipt['rowsChecked'] == 6648310
        assert receipt['mediaRowsChecked'] == 146725
        assert receipt['preparedIndexes'] == receipt['preparedRoutes'] == 170
        assert all(group['complete'] and group['sameModulePublicCopyFullAliasParity'] and
                   group['frozenBaselineFullValueByteParity'] and group['exactRawSourceAndColumnsUnchanged'] and
                   group['nativeHeapAndBufferUnchanged'] and not group['aliasNormalization'] for group in groups)
        receipt['complete'] = True
        receipt['status'] = 'passed'
    else:
        receipt['status'] = 'incomplete'
except Exception as error:
    receipt['status'] = 'failed'
    receipt['failures'].append({'error': str(error), 'traceback': traceback.format_exc()})
    if process is not None and process.poll() is None:
        process.terminate()
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
finally:
    receipt['finishedAt'] = now()
    save('monitor-receipt.json', receipt)
    print(json.dumps({key: receipt.get(key) for key in ['status', 'complete', 'exitCode',
        'resourceAbort', 'groups', 'rowsChecked', 'mediaRowsChecked', 'preparedIndexes',
        'preparedRoutes', 'oracleManifestSha256', 'guardDiagnostics', 'failures']}), flush=True)
raise SystemExit(0 if receipt['complete'] else 1)
