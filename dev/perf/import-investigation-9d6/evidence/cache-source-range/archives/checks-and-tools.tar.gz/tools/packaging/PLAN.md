# Cache full-import evidence packaging plan

The six-host record will live under `dev/perf/import-investigation-9d6/evidence/cache-source-range/`. This is a prepared layout only. No full-import archive has been created; packaging waits for root to confirm the remaining cell audits.

## Frozen source binding

- Baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
- Product: `dfd2523b514f291dc57f39a9f256bbc0759efd5b`.
- Workflow/tooling: `5b5389ac69e07c95d11c4ff04230dbb8e0761995`.
- Run: `46107460816`, attempt `1`.
- Exact changed package entry: `js/dictionary/dictionary-database.js`.

## Archive layout

Create one archive per cell: `jmdict-AB.tar.gz`, `jmdict-BA.tar.gz`, `jitendex-AB.tar.gz`, `jitendex-BA.tar.gz`, `vndb-AB.tar.gz`, and `vndb-BA.tar.gz`. Each contains:

| Prefix | Contents |
| --- | --- |
| `raw/` | Every original extracted artifact file, unchanged, except the two release ZIP payloads. Preserve reports, HTML, plans, canonical receipts, observations, controls, tails, host snapshots, raw memory scans, markers, original and instrumented harnesses, and all logs. Use no extension-based filter. |
| `audit/` | All existing completed independent/root audit JSON and logs, unchanged. |
| `exploratory/` | All host phase diagnostic JSON and logs, unchanged and explicitly exploratory; they do not replace endpoint timing. |
| `identity/` | Original download receipt, full outer artifact member map, and both release ZIP/member maps with exact hashes and sizes. |

The only payload omissions are `package-A.zip` and `package-B.zip`. Before omission, verify each entire ZIP hash and every inner entry against `source-identities.json`; retain that original file and full package maps. Also verify the original outer artifact digest and every extracted byte. Every other artifact member is retained.

Create `checks-and-tools.tar.gz` for the complete checks artifact, its live API binding and independent review, the exact reviewed offline auditor, the reviewed phase-diagnostic source, and baseline Python observer/audit helpers. Phase diagnostic JSONs belong in a clearly labelled exploratory subsection. They do not adjust or replace endpoint timing, remove tails, or establish promotion criteria.

## Publication documents

Preserve the exact six-host endpoint/control results in a new README and machine-readable summary once all audits are complete. Include every original artifact ID, run/attempt/head, original ZIP size/digest, package identity, and the final deterministic archive hashes. `inventory.json` lists all retained member paths, sizes and hashes. `publication-receipt.json` binds the archive materializer source and records verification coverage. Keep the existing completed-study archives unchanged.

The layout deliberately separates hosts rather than combining all raw memory and report data into one large blob. It does not treat a correctness pass or a memory-screen pass as a demonstrated latency gain.
