# Independent review of the SIMD match-count range guard

## Decision

The frozen unguarded count16 candidate is ineligible for promotion. Its existing corpus parity and timing receipts describe that exact source and must remain attached to it. A corrected source needs new identities and direct boundary checks before further qualification.

The minimal correction is an early `if (pIn > pInLimit) return 0;` inside the wasm SIMD specialization, before any cast of `pInLimit - pIn` to `size_t`. Both non-WASM and no-SIMD branches retain the exact upstream scalar body. Equality already produces zero without a load; the added check only handles reversed limits.

## Independently inspected source

Upstream Zstd commit: `82d322c4973d9e2968d94047a40892bc6d9a9bdf`.

| File | SHA-256 |
| --- | --- |
| `lib/compress/zstd_compress_internal.h` | `e99de778a2a733bde856172057fe380256c379f082bd3513cac600b005ac2b98` |
| `lib/compress/zstd_lazy.c` | `b4dea3610e13638b196b5bca31f8e1018e42e7a34b3a03e099d858f52c447eb0` |
| `lib/compress/zstd_opt.c` | `055ad00d91027e077410fcabcaff02753e3ac52551e5dbbade4c308df5713d3f` |

The original `ZSTD_count` at header line 854 bounds its main and tail reads with pointer comparisons. When the input pointer is above its limit, none of those conditions permit a load and the function returns zero. The frozen specialization at `compression-experiments/dev/perf/wasm-word-width-v2/patch-zstd.py` instead tests `(size_t)(pInLimit - pIn) >= 16`. A negative difference wraps to a large unsigned wasm32 value and admits the vector load. Its subsequent 8/4/2-byte tests have the same problem. The older count8/count8ctz/count8unroll branches also lack this guard; their old receipts are not qualification evidence for corrected sources.

## Why the segmented caller matters

The original two-segment helper at header lines880–891 uses:

```c
vEnd = MIN(ip + (mEnd - match), iEnd);
matchLength = ZSTD_count(ip, match, vEnd);
```

For a match still inside the first segment, this caps both input and match reads. It continues from `iStart` only when the first match reaches `mEnd` exactly. This is why a large load must respect the virtual input limit, rather than only the real input buffer end.

The dictionary tree searches at `zstd_lazy.c:203` and `zstd_opt.c:786` advance both pointers by their cached common length before invoking this helper. The cached length describes the conceptual dictionary-plus-prefix sequence; those call sites do not assert that the advanced match remains below the dictionary end.

A concrete address construction is:

- Original input 4096, original dictionary match 8190, dictionary end 8192.
- Cached common length 4 gives advanced input 4100 and match 8194.
- With the real input end above 4100, the helper calculates `vEnd = 4100 + (8192 - 8194) = 4098`.
- The original scalar function returns 0. The unguarded specialization sees unsigned remaining length 4294967294 and attempts a load.

This construction explains the missing precondition; it is not a claim that a particular pinned dictionary exercised it. Preserving the upstream helper's existing reversed-limit behavior avoids depending on an unproved restriction in those dictionary searches.

Normal direct same-segment calls use earlier matches, so bounding the input width also bounds the match width. Normal dictionary calls use the segmented cap. After the added check, the specialization's vector loop and 8/4/2/1-byte remainder checks keep those existing bounds: every admitted width is no greater than the current nonnegative remaining input length, and both pointers advance by that width. Nonzero-only trailing-zero calls and the exact original tail order must remain unchanged.

This review does not extend the upstream C contract to arbitrary unrelated or invalid pointers. Direct numerical WASM boundary cases are useful specifically to prove that the new early return executes before a load.

## Focused regression coverage

Use a probe that extracts the exact original, frozen unguarded, and corrected count bodies from their hashed headers. Preserve the original two-segment helper with function-name substitution only. Bind the probe to its source hashes and compiler flags.

1. Empty and reversed limits: place either pointer exactly at the end of linear memory, and use reversed distances 1,2,3,4,7,8,15,16,17. The original and corrected functions must return0 without trapping. Retain the old candidate's trap or wrong-result receipt.
2. Normal bounds: lengths 0–65 and every input/match alignment modulo 16, with each readable span ending exactly at linear-memory end in separate cases. Compare against both the original function and a byte oracle.
3. Mismatch positions: exercise every byte within the 16-byte vector and 8/4/2/1 tails, including differences in each bit, so trailing-zero and tail behavior are independently checked.
4. Two segments: dictionary remnants 0–33, exact end continuation, shorter input limits, and a first mismatch before/at/after the segment boundary. Place input or dictionary end at linear-memory end.
5. Cached common lengths already beyond the dictionary end: construct the reversed virtual limit through the original two-segment helper, rather than only calling the count function with a synthetic limit.
6. Preserve overlap cases and a separate no-SIMD fallback check. Complete production-wrapper compressed-byte/error-status parity still follows direct bounds proof; the probe does not establish codec or import performance.

The codec agent owns the corrected source and executable probe. This independent review performed source inspection only and did not rebuild, retime, or mutate either frozen candidate.

## Independent audit of corrected-source verification

The new correctness run at `/home/agent/manabitan-compression-toolchain/guarded-verification-01` completed successfully. This review separately read the complete guarded patch, actual-header probe builder, C wrapper, byte oracle and verification entry point, then checked the retained source and result identities without rerunning their work.

| Identity | SHA-256 |
| --- | --- |
| Frozen manifest | `54c3eac45c178bd0a6b4d7cd40c0a282b7339d55bff2754bb2cf5739e07ea068` |
| Product patch | `9bd9847abd7b0fec06ebe6f13d372e9796faeb363865671baf1ec10ed65fd816` |
| Guarded complete header | `a4121756c5735ca90241d46f7054b0d1345538e854f1fc721a6656c3046b6ba9` |
| Guarded production WASM | `13890c7e75e7a2ff5fa00bd65f1e518e15f545da85154719be6a2eaa2a773a22` |
| Verification receipt | `dbb78c0baeb8c646f2ea6e98b2b63618da01bb5e45bc8a29c81958bfea7c8595` |
| Executed verification entry point | `3b8ffa3459cb00be720a6f3edb988aac56b732bdc2149dab34a689e6501b410c` |

The retained native build tree is still pinned to upstream and differs only by the 34-line header addition. Removing exactly the one-line guard reproduces the superseded header hash `2e0f8383beeef1ecf4fb63ccaa12fb825e1bf87a3e63a11731e3380f223f5829`. An independent byte comparison confirms that the fallback body is exactly upstream. No separate no-SIMD executable result is claimed.

All four result hashes and all three probe module hashes agree with the verification receipt. The probe compiles the complete production header and calls its original two-segment helper, rather than duplicating a handwritten substitute. The 885,455 cases cover normal and overlapping spans, all input/match alignments, every short mismatch byte, exact heap-end tails, empty/reversed spans, two-segment boundaries and cached common lengths beyond the dictionary end. Both original and guarded code pass; the preserved unguarded code records 768 traps and one interior wrong result. Normal mismatch cases use a one-bit byte difference, so this is not a claim of exhaustive byte-value enumeration.

Production bytes match 651 raw corpus/fuzz cases and 1,110 destination-capacity/canary comparisons, with no status differences. All 103 actual JMdict planner blocks match through the production wrapper. Their independently summed input and output lengths are 100,300,626 and 12,326,040 bytes; the capture report, baseline database, planner, dictionary and wrapper identities all match the frozen manifest. The guarded artifact is 433,757 bytes, 126 bytes larger than baseline, with identical JS glue.

The entry point was subsequently changed only to locate frozen parity tooling outside the product checkout; this review keeps the executed entry-point hash above and the archived source separate from that portability edit. The archived copy under `compression-probe/count16-guarded/verified-package-01` matches the executed hash. The final entry point is `10157fb2340fd535b2e10b47075807fa07f91e4336ca1736c58b45a0e66a3f82`; an independent diff confirms just the three disclosed path changes. All 19 entries in final publication manifest `8f8f3bf50be4244cd9b4b3b7b8322c1712889ebb7414a7a0c8ae7cad33528969` match byte lengths, SHA-256 and available Git blob identities. Final manifest `ca6855cc6caa91523a8bda915223dc427126dda5e3f1a4ec4f6b568ed8b99bb9` only adds final entry-point/README/provenance hashes to the earlier manifest. Detailed audit receipt: `count16-guarded-proof-audit.json`.

No performance result for the corrected source was produced by these checks. They clear the source/correctness question for a new whole-import qualification, not a PR performance claim.

## Concurrent implementation status

At 2026-11-28 04:49 UTC the external count128 branch remained at `ede7e7a6b92e2c752ac631a503231a5a8aa62d3e`. It contained only four compiler-experiment files, with build run `46105057110` queued, and no count128 PR was returned by repository PR search. Its repeated-distance vector loop and no-SIMD count64 fallback differ from this candidate's initial-vector/loop-limit structure and unchanged scalar fallback; both target the same match-counting mechanism. The complete read-only API snapshot is retained in `count128-overlap-status.json`. A future endpoint/PR decision still needs to avoid duplicating a qualified equivalent implementation.
