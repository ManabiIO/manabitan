# Codec width experiment, first hosted arm

This is the frozen AB host from run 46104781415, attempt 1, source commit `03aaef1730788c59ecdb5d8bb45f3c87fe90cb40`. The independent BA host is still running. No candidate is promoted from this interim result.

The exact 486,970-byte artifact 15248416986 has SHA256 `5a927ef6115ba8cf5dcce90fdf43f46d185fcc0e5f5603fb0435f2790c7d9187`. The independent audit verifies frozen script hashes, rebuilt module hashes, all capture inputs, every prescribed observation, fixed arm schedules, output bytes, and buffer capacities. The captured workload contains 103 production 1 MiB blocks and 100,300,626 canonical input bytes from 528,299 JMdict rows. It reproduces the codec boundary in Node 24.22.3, not workers, browser imports, or process memory.

## Results

Positive saved values favor the candidate. Intervals below are descriptive bootstrap summaries of fixed blocks, not a prospective qualification gate.

| Candidate | Warm saved | Warm faster blocks | Cold wrapper saved | Cold faster groups | Cold saved interval | WASM size change |
|---|---:|---:|---:|---:|---:|---:|
| count16 | 4.818 ms / 3.15% | 8/8 | 4.559 ms / 2.46% | 4/6 | -1.78% to 6.41% | -2,753 bytes |
| cstream64 | 3.230 ms / 2.10% | 8/8 | 6.891 ms / 3.76% | 4/6 | -2.08% to 6.90% | +96 bytes |

## Identical-code controls

The following values are differences in the later arm relative to its identical-code comparison; positive values are slower. All raw observations remain in the audit JSON.

| Candidate | Warm C minus A | Warm D minus B | Cold C minus A |
|---|---:|---:|---:|
| count16 | 0.657 ms | 0.172 ms | 0.931 ms |
| cstream64 | 0.400 ms | 0.287 ms | 0.451 ms |

## Correctness and limitations

- All 651 raw cases and 103 production wrapper blocks retain exact compressed bytes and cross-decoder output.
- count16 has 1,110 tight-capacity comparisons with intact canaries and no success/error differences.
- CStream64 has 1,110 comparisons with intact canaries but 72 success/error differences: the baseline succeeds while the wider accumulator reports insufficient destination capacity. Its compressBound allocations match exactly, but the changed API behavior remains a release blocker.
- Warm retained source, destination, and dictionary buffer capacities match across all four arms. This does not measure whole-process memory.
- Both cold intervals cross zero. Warmed gains are only 3.15% and 2.10% at the isolated codec boundary. Actual import latency has not been measured for these candidates.
- Host CPU: Intel(R) Xeon(R) 6975P-C.

The first host supports a small steady-state component effect, not a proven cold or whole-import improvement. Await the already-prescribed BA host, retaining all observations without an unchanged rerun.
