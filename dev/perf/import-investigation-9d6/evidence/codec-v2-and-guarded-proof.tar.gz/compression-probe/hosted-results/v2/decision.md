# Codec width experiment: complete two-host cohort

**Eligibility correction (2026-11-28): the frozen count16 binary below is ineligible for promotion.** Subsequent source review found that its unsigned remaining-length check omitted the upstream no-read behavior for reversed virtual limits. Direct tests retained 768 traps and one wrong result from that old specialization. All original timing and parity receipts remain unchanged and are exploratory only. A new guarded source, built to WASM SHA256 `13890c7e75e7a2ff5fa00bd65f1e518e15f545da85154719be6a2eaa2a773a22`, passed direct-boundary and full existing parity/canary checks; its performance requires the separate prospective full-import run 46109596112. The earlier smaller-module claim also does not carry over: the guarded module is 433,757 bytes, 126 bytes above baseline.

## Recommendation

Preserve count16 as the sole possible browser qualification candidate. It reduces warmed codec time by about 3% on both isolated hosts and produces a 2,753-byte smaller module. Its cold result is positive in median on both hosts, but the AB host interval crosses zero. This is a small component improvement, not a demonstrated import-latency improvement. A PR is not justified by these measurements alone.

Close CStream64 without promotion or a more complicated tail writer. Its warmed gain is only 2.1–2.5%, cold intervals cross zero on both hosts, and 72 tight-destination success/error differences remain a release blocker. Do not combine it with count16.

No unchanged codec rerun or additional count-width variant is proposed.

## Source and workload identity

- Product baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
- Experiment head: `03aaef1730788c59ecdb5d8bb45f3c87fe90cb40`; workflow run 46104781415, attempt 1.
- The independent audit verifies every frozen script, exact rebuilt baseline and candidate module hashes, exact capture files, prescribed arm schedules, all 32 warmed observations and 18 cold child processes per candidate/host, and output bytes.
- Original capture artifact 15245899188, report SHA256 `6c897506cdc81a7c24520e861415c0523f24437f8c20ff684bdc60ce4702ac76`. Both hosts use the same 12 source groups and 103 production 1 MiB record-aligned blocks: 100,300,626 canonical input bytes, 12,326,040 wrapped compressed bytes.
- Node 24.22.3; both independent hosts report Intel Xeon 6975P-C. Cold processes include wrapper/module initialization separately from the one corpus pass. Warm observations use four independently initialized arms with fixed two-pass warmup and eight balanced rounds.

| Host | Artifact ID | ZIP bytes | ZIP SHA256 |
|---|---:|---:|---|
| AB | 15248416986 | 486,970 | `5a927ef6115ba8cf5dcce90fdf43f46d185fcc0e5f5603fb0435f2790c7d9187` |
| BA | 15248447120 | 487,072 | `87411bd3734071d0857ec38ae5e3924921c65d4337f08a5fcfbe786818cbe9dc` |

## Fixed observations

Positive saved values favor the candidate. Cold and warmed observations remain separate. Intervals are descriptive bootstrap summaries over the prescribed fixed blocks; they are not a new acceptance gate. Each raw observation and negative identical-code control remains in the linked audit JSON.

| Candidate | Host | Warm saved | Warm faster | Cold wrapper saved | Cold faster | Cold saved interval | Initialization + cold saved |
|---|---|---:|---:|---:|---:|---:|---:|
| count16 | AB | 4.818 ms / 3.15% | 8/8 | 4.559 ms / 2.46% | 4/6 | -1.78% to +6.41% | 5.560 ms / 2.38% |
| count16 | BA | 4.382 ms / 2.85% | 8/8 | 9.040 ms / 4.94% | 6/6 | +1.66% to +5.81% | 9.249 ms / 3.99% |
| cstream64 | AB | 3.230 ms / 2.10% | 8/8 | 6.891 ms / 3.76% | 4/6 | -2.08% to +6.90% | 5.086 ms / 2.19% |
| cstream64 | BA | 3.788 ms / 2.45% | 8/8 | 6.459 ms / 3.49% | 4/6 | -3.11% to +5.77% | 7.315 ms / 3.12% |

## Arm medians and controls

A and C use the baseline; B and D use the candidate. Cold processes use A/B/C only. The final three columns are median paired arm differences, so they need not equal differences between the arm medians. Positive control differences mean the second arm was slower.

| Candidate | Host | Warm A | Warm B | Warm C | Warm D | Cold A | Cold B | Cold C | Warm C−A | Warm D−B | Cold C−A |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| count16 | AB | 152.767 | 147.832 | 153.117 | 148.414 | 181.861 | 177.985 | 182.213 | 0.657 | 0.172 | 0.931 |
| count16 | BA | 153.471 | 149.720 | 154.236 | 149.305 | 187.041 | 175.829 | 184.766 | 0.150 | -0.576 | -2.577 |
| cstream64 | AB | 153.364 | 150.001 | 153.744 | 150.229 | 183.400 | 176.580 | 184.090 | 0.400 | 0.287 | 0.451 |
| cstream64 | BA | 154.080 | 150.264 | 154.892 | 150.862 | 187.231 | 178.445 | 181.194 | 0.210 | 0.730 | -4.284 |

All arm/control times above are milliseconds. The warm count16 effect exceeds its measured identical-code median drift on both hosts. Cold observations have materially greater variance, particularly on AB.

## Correctness, size, and limits

| Candidate | WASM bytes | Change | Raw exact cases | Wrapper exact blocks | Destination comparisons | Status differences |
|---|---:|---:|---:|---:|---:|---:|
| count16 | 430,878 | -2,753 | 651 | 103 | 1,110 | 0 |
| cstream64 | 433,727 | +96 | 651 | 103 | 1,110 | 72 |

- Both hosts reproduce exact compressed bytes, cross-decoder round trips, and intact destination canaries. The baseline module is 433,631 bytes.
- CStream64 differences are baseline success versus candidate insufficient-destination errors at tight capacities. compressBound-allocated frames remain exact, but that does not excuse the API regression.
- All four arms retain source capacity 1,048,578, destination capacity 1,052,678, and dictionary capacity 16,384 bytes. These are scratch-buffer capacities, not whole-process or browser memory measurements.
- This workload is a single-context codec replay of captured JMdict pending spans. It does not include production four-worker scheduling, database writes, parser work, or import completion. Compression overlaps other work in the real importer, so the absolute component saving need not translate to latency.
- No current-source Jitendex or VNDB codec replay has been measured here. Both JMdict and Jitendex use the JMdict trained dictionary in production; generic level 1 must not be substituted for Jitendex in a follow-up.
- Both hosted machines are x86. The SIMD bitmask instruction can have different costs on ARM; these results are not a cross-architecture performance claim.

## Retained evidence

- `analysis-AB.json` and `analysis-BA.json`: independent identity/schedule/parity audits, every observation and control, per-file SHA256 receipts.
- `artifact-15248416986.zip` and `artifact-15248447120.zip`, corresponding extraction receipts, and all 59 files per host.
- Frozen portable implementation in `compression-experiments/dev/perf/wasm-word-width-v2/`, plus `.github/workflows/import-codec-width-v2-9d6.yml`.
