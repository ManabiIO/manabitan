#!/usr/bin/env python3
"""Independently audit one frozen codec artifact and retain every arm/control."""
import argparse, hashlib, json, math, pathlib, random, statistics
p=argparse.ArgumentParser()
p.add_argument('artifact',type=pathlib.Path)
p.add_argument('scripts',type=pathlib.Path)
p.add_argument('output',type=pathlib.Path)
a=p.parse_args()

def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def median(v):return statistics.median(v)
def statistics_(saved, ratios):
    rng=random.Random(20261128)
    draws=sorted(median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
    return {'count':len(saved),'medianSavedMs':median(saved),'medianSavedPercent':100*(1-median(ratios)),'fasterCount':sum(x>0 for x in saved),'savedMs':saved,'candidateOverBaselineRatios':ratios,'descriptiveSavedPercent95':[100*(1-draws[9749]),100*(1-draws[249])]}
def compare(rows,left,right,field='wallMs'):
    pairs=[(r[left][field],r[right][field]) for r in rows]
    return statistics_([l-r for l,r in pairs],[r/l for l,r in pairs])
def verify_number(value):assert isinstance(value,(int,float)) and math.isfinite(value) and value>=0,value

provenance_paths=list(a.artifact.rglob('provenance.json'))
assert len(provenance_paths)==1,provenance_paths
root=provenance_paths[0].parent
provenance=read(root/'provenance.json'); manifest=read(a.scripts/'manifest.json')
assert provenance['node']=='v24.22.3',provenance['node']
assert provenance['order'] in ['AB','BA']
for name,digest in provenance['scripts'].items():assert sha(a.scripts/name)==digest,name
build=read(root/'build.json')
assert build['manifest']==manifest
assert set(x['mode'] for x in build['builds'])==set(['baseline',*manifest['candidates']])
for b in build['builds']:
    assert b['artifacts']==manifest['expected'][b['mode']]
    for suffix,key in [('js','jsSha256'),('wasm','wasmSha256')]:
        file=root/f"wasm-{b['mode']}"/f'zstd-simd-module.{suffix}'
        if file.exists():assert sha(file)==b['artifacts'][key],file
order=provenance['order']; complete=read(root/f'summary-{order}.json')
assert complete['provenance']==provenance
assert set(x['candidate'] for x in complete['summaries'])==set(manifest['candidates'])
results=[]; all_inputs=None; all_blocks=None
for candidate in manifest['candidates']:
    raw=read(root/f'{candidate}-raw-parity.json')
    parity=read(root/f'{candidate}-wrapper-parity.json')
    warm=read(root/f'{candidate}-warm-{order}.json')
    summary=read(root/f'{candidate}-summary-{order}.json')
    assert summary==next(x for x in complete['summaries'] if x['candidate']==candidate)
    assert raw['parity']['mismatches']==0
    assert raw['parity']['cases']==(651 if 'patch-cstream64.py' in provenance['scripts'] else 507)
    assert raw['parity']['actualPlanBlocks']==103
    assert raw['parity']['actualPlanBytes']==100300626
    assert raw['parity']['actualPlanCompressedBytesWithEnvelopes']==12326040
    assert raw['parity']['allCompressedBytesExact'] is True
    assert raw['parity']['crossDecoderRoundTrip'] is True
    assert parity['parity']['blocks']==103
    assert parity['parity']['inputBytes']==100300626
    assert parity['parity']['compressedBytes']==12326040
    assert parity['parity']['wrappedBytesExact'] is True
    assert len(parity['parity']['blockDigests'])==103
    for r in [raw,parity,warm]:
        assert r['node']==provenance['node']
        assert r['captureReportSha256']==provenance['captureReportSha256']
        assert r['blockTargetBytes']==1048576
    for kind in ['baseline',candidate]:
        assert raw['modules'][kind]==manifest['expected'][kind]
    if all_inputs is None:all_inputs=parity['captureInputs'];all_blocks=parity['parity']['blockDigests']
    else:assert all_inputs==parity['captureInputs'] and all_blocks==parity['parity']['blockDigests']
    assert len(all_inputs)==12
    assert len(warm['measurements'])==32
    schedules=[[0,1,3,2],[1,2,0,3],[2,3,1,0],[3,0,2,1]]
    expected=[('ABCD'[i if order=='AB' else i^1],r) for r in range(8) for i in schedules[r%4]]
    assert [(r['arm'],r['round']) for r in warm['measurements']]==expected
    rows=[]
    for r in range(8):
        group={x['arm']:x for x in warm['measurements'] if x['round']==r}
        assert set(group)==set('ABCD')
        for label,x in group.items():
            assert x['kind']==('baseline' if label in 'AC' else candidate)
            assert x['bytes']==12326040
            for metric in ['gatherMs','finishMs','wallMs']:verify_number(x[metric])
        rows.append(group)
    for label in 'ABCD':
        expected_arm={'kind':'baseline' if label in 'AC' else candidate,**{f'median{metric[0].upper()+metric[1:]}':median(g[label][metric] for g in rows) for metric in ['gatherMs','finishMs','wallMs']}}
        assert warm['summary'][label]==expected_arm
    assert len({json.dumps(v,sort_keys=True) for v in warm['retainedBufferCapacities'].values()})==1
    grouped=[]
    for group in rows:
        grouped.append({'baseline':{field:(group['A'][field]+group['C'][field])/2 for field in ['wallMs','finishMs','gatherMs']},'candidate':{field:(group['B'][field]+group['D'][field])/2 for field in ['wallMs','finishMs','gatherMs']}})
    cold_rows=[]
    cold_schedules=[list(x) for x in ['ABC','ACB','BAC','BCA','CAB','CBA']]
    if order=='BA':cold_schedules.reverse()
    assert len(summary['coldPairs'])==6
    for i,pair in enumerate(summary['coldPairs']):
        assert pair['pair']==i and pair['order']==cold_schedules[i]
        assert set(pair['arms'])==set('ABC')
        group=pair['arms']
        for label in 'ABC':
            kind=candidate if label=='B' else 'baseline'
            child=read(root/f'{candidate}-cold-{order}-{i}-{label}-{kind}.json')
            assert child['candidate']==kind and child['mode']=='cold' and len(child['measurements'])==1
            assert child['captureReportSha256']==provenance['captureReportSha256']
            assert child['captureInputs']==all_inputs
            assert group[label]=={**child['measurements'][0],'arm':label,'initializationMs':child['initialization'][0]['initializationMs']}
            for metric in ['gatherMs','finishMs','wallMs','initializationMs']:verify_number(group[label][metric])
        cold_rows.append(group)
    cold_grouped=[]
    for group in cold_rows:
        cold_grouped.append({'baseline':{'wallMs':(group['A']['wallMs']+group['C']['wallMs'])/2,'totalMs':sum(group[x]['wallMs']+group[x]['initializationMs'] for x in 'AC')/2},'candidate':{'wallMs':group['B']['wallMs'],'totalMs':group['B']['wallMs']+group['B']['initializationMs']}})
    results.append({'candidate':candidate,'artifactBytes':manifest['expected'][candidate]['wasmBytes'],'artifactBytesAdded':manifest['expected'][candidate]['wasmBytes']-manifest['expected']['baseline']['wasmBytes'],'rawCases':raw['parity']['cases'],'destinationChecks':raw.get('destinationChecks'),'destinationCanariesIntact':raw.get('destinationCanariesIntact'),'destinationStatusDifferenceCount':len(raw['destinationStatusDifferences']) if 'destinationStatusDifferences' in raw else None,'warmArmMedians':warm['summary'],'warmEffects':{field:compare(grouped,'baseline','candidate',field) for field in ['wallMs','finishMs','gatherMs']},'warmPairwise':{f'{r}/{l}':compare(rows,l,r) for l,r in [('A','B'),('C','B'),('A','D'),('C','D'),('A','C'),('B','D')]},'retainedBufferCapacities':warm['retainedBufferCapacities'],'coldArmMedians':{label:{field:median(x[label][field] for x in cold_rows) for field in ['wallMs','finishMs','gatherMs','initializationMs']} for label in 'ABC'},'coldEffects':{'wrapper':compare(cold_grouped,'baseline','candidate'),'initializationAndWrapper':compare(cold_grouped,'baseline','candidate','totalMs')},'coldPairwise':{f'{r}/{l}':compare(cold_rows,l,r) for l,r in [('A','B'),('C','B'),('A','C')]},'knownLimitations':summary.get('knownLimitations')})
receipt={'complete':True,'auditScriptSha256':sha(pathlib.Path(__file__)),'scope':'Verified hosted JMdict codec component only. Warm and fresh-process cold observations remain separate; no worker concurrency, browser, whole-import, or whole-process memory claim. Bootstrap intervals are descriptive over fixed blocks, not a new qualification gate.','order':order,'provenance':provenance,'captureInputs':all_inputs,'blockDigestsSha256':hashlib.sha256(json.dumps(all_blocks,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'results':results,'files':{str(x.relative_to(root)):sha(x) for x in sorted(root.rglob('*.json'))}}
a.output.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'output':str(a.output),'order':order,'candidates':[{'candidate':r['candidate'],'warm':r['warmEffects']['wallMs'],'cold':r['coldEffects']['wrapper'],'capacityDifferences':r['destinationStatusDifferenceCount']} for r in results]},indent=2))
