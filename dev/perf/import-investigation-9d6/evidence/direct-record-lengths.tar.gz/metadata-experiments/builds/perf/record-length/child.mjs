import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, writeFile} from 'node:fs/promises'
import {join, resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
import {deserialize} from 'node:v8'
import {gunzipSync} from 'node:zlib'

const [sourceArgument, captureArgument, dictionary, mode, outputPath] = process.argv.slice(2)
assert(sourceArgument && captureArgument && dictionary && outputPath)
assert(mode === 'cold' || mode === 'warm')
assert.equal(typeof globalThis.gc, 'function')
const sourceRoot = resolve(sourceArgument)
const captureRoot = resolve(captureArgument)
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const report = JSON.parse(await readFile(join(captureRoot, `${dictionary}.json`), 'utf8'))
assert(report.complete && report.dictionary === dictionary)
const compressed = await readFile(join(captureRoot, `${dictionary}.bin.gz`))
assert.equal(hash(compressed), report.compressedSha256)
const serialized = gunzipSync(compressed)
assert.equal(hash(serialized), report.serializedSha256)
const sourcePath = join(sourceRoot, 'ext/js/dictionary/term-record-opfs-store.js')
const sourceSha256 = hash(await readFile(sourcePath))
const {TermRecordOpfsStore, createArtifactTermRecordChunkWithResolvedContent} = await import(pathToFileURL(sourcePath))
const inputs = deserialize(serialized).map((input) => ({
    chunk: createArtifactTermRecordChunkWithResolvedContent(
        {rowCount: input.rowCount, scoreList: new input.scoreList.constructor(input.scoreList)},
        new Uint32Array(input.uniqueIndexList), new Float64Array(input.offsets), new Uint32Array(input.lengths),
    ),
    contentOffsetBase: input.contentOffsetBase,
    outputSha256: input.outputSha256,
    outputByteLength: input.outputByteLength,
}))
assert.equal(inputs.reduce((total, input) => total + input.chunk.rowCount, 0), report.rows)
const store = new TermRecordOpfsStore()
function execute() {
    const groups = []
    const digest = createHash('sha256')
    let milliseconds = 0
    for (const input of inputs) {
        const start = performance.now()
        const output = store._encodeArtifactRecordFields(input.chunk, [], [], input.contentOffsetBase)
        const elapsed = performance.now() - start
        milliseconds += elapsed
        groups.push(elapsed)
        assert.equal(output.byteLength, input.outputByteLength)
        assert.equal(hash(output), input.outputSha256)
        digest.update(output)
    }
    assert.equal(digest.digest('hex'), report.outputSha256)
    return {milliseconds, groups}
}
globalThis.gc()
if (mode === 'warm') {
    for (let i = 0; i < 4; i++) { execute() }
}
globalThis.gc()
const memoryBefore = process.memoryUsage()
const passes = []
for (let i = 0; i < (mode === 'cold' ? 1 : 4); i++) { passes.push(execute()) }
const memoryAfter = process.memoryUsage()
const sorted = passes.map((pass) => pass.milliseconds).sort((a, b) => a - b)
const middle = sorted.length >> 1
const milliseconds = sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2
await writeFile(outputPath, `${JSON.stringify({
    dictionary, mode, rows: report.rows, runs: inputs.length, milliseconds, passes,
    node: process.version, v8: process.versions.v8, sourceRoot, sourceSha256,
    captureSha256: report.compressedSha256, outputSha256: report.outputSha256,
    memoryBefore, memoryAfter, maxRssKiB: process.resourceUsage().maxRSS,
    scope: 'Record-field encoder only; input creation, deserialization, explicit GC and byte hashing excluded. In-call allocation/GC included. Fresh Node process for each arm; cold mode has zero prior encoder calls. No whole-import or Chrome claim.',
}, null, 2)}\n`, {flag: 'wx'})
