import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {createReadStream, openAsBlob} from 'node:fs'
import {mkdir, readFile, writeFile} from 'node:fs/promises'
import {join, resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
import {serialize} from 'node:v8'
import {gzipSync} from 'node:zlib'
import {Worker as ThreadWorker} from 'node:worker_threads'
import {BlobReader, Uint8ArrayWriter, ZipReader} from '@zip.js/zip.js'

const [sourceArgument, cacheArgument, outputArgument, selection = 'jmdict,jitendex,vndb'] = process.argv.slice(2)
assert(sourceArgument && cacheArgument && outputArgument)
const root = resolve(sourceArgument)
const outputRoot = resolve(outputArgument)
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const localImport = (name) => import(pathToFileURL(join(root, name)))
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: 4, deviceMemory: 8}})
const parser = await localImport('ext/js/dictionary/term-bank-wasm-parser.js')
const {RawZipPayloadReader, TermBankSourcePipeline} = await localImport('ext/js/dictionary/term-bank-source-pipeline.js')
const {TermRecordOpfsStore, createArtifactTermRecordChunkWithResolvedContent} = await localImport('ext/js/dictionary/term-record-opfs-store.js')
const {snapshotTermBankExperiments} = await localImport('ext/js/dictionary/term-bank-experiments.js')
const {MIN_EXACT_LOOKUP_SOURCE_BYTES} = await localImport('ext/js/dictionary/term-lookup-route.js')
const wasm = await readFile(join(root, 'ext/lib/term-bank-parser.wasm'))
parser.setTermBankWasmModule(await WebAssembly.compile(wasm))
const lockBytes = await readFile(join(root, 'test/perf/dictionaries.lock.json'))
const fixtures = JSON.parse(lockBytes).dictionaries
const terminations = []
class BrowserWorker extends EventTarget {
    constructor(url) {
        super()
        this.worker = new ThreadWorker(pathToFileURL(join(root, 'test/fixtures/parser-settlement/worker-node.mjs')), {workerData: {url: url.href}})
        this.worker.on('message', (data) => this.dispatchEvent(new MessageEvent('message', {data})))
        this.worker.on('error', (error) => {
            const event = new Event('error')
            Object.defineProperty(event, 'message', {value: error.message})
            this.dispatchEvent(event)
        })
        this.worker.on('messageerror', () => this.dispatchEvent(new MessageEvent('messageerror')))
    }
    postMessage(data, transfer) { this.worker.postMessage(data, transfer) }
    terminate() { terminations.push(this.worker.terminate()) }
}
globalThis.Worker = BrowserWorker
await mkdir(outputRoot, {recursive: true})
for (const dictionary of selection.split(',')) {
    const fixture = fixtures[dictionary]
    assert(fixture)
    const fixturePath = join(resolve(cacheArgument), fixture.cacheFile)
    const fixtureHash = createHash('sha256')
    for await (const bytes of createReadStream(fixturePath)) { fixtureHash.update(bytes) }
    assert.equal(fixtureHash.digest('hex'), fixture.sha256)
    const archive = await openAsBlob(fixturePath)
    assert.equal(archive.size, fixture.sizeBytes)
    const reader = new ZipReader(new BlobReader(archive))
    const entries = await reader.getEntries()
    const termFiles = entries.filter(({filename}) => /^term_bank_\d+\.json$/.test(filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
    const rawSourceBytes = termFiles.reduce((total, entry) => total + entry.uncompressedSize, 0)
    const rawReader = new RawZipPayloadReader(archive)
    const sourcePipeline = new TermBankSourcePipeline({
        termFiles, enabled: true,
        read: async (file) => await file.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}),
        readCompressed: async (file, signal) => await rawReader.read(file, signal),
    })
    const media = fixture.mediaFiles > 0
    const options = {
        ...snapshotTermBankExperiments(),
        copyContentBytes: false, includeContentMetadata: true,
        initialContentBytesPerRow: 48, minimalDecode: true,
        reuseExpressionForReadingDecode: true, preallocateChunkRows: true,
        skipTagRuleDecode: media, lazyGlossaryDecode: true,
        mediaHintFastScan: media, projectImagePaths: media && rawSourceBytes >= 1024 ** 3,
        validateGlossaryTypes: true, computeContentHashes: true,
        emitContentSlab: true, emitTokenBinaryContent: true, emitTermByteLists: false,
        prepareLookupIndexes: true, prepareLookupRoute: rawSourceBytes >= MIN_EXACT_LOOKUP_SOURCE_BYTES,
        maxPendingChunks: 2,
    }
    const store = new TermRecordOpfsStore()
    // Capture the real encoder's input runs without writing a database. The
    // source resolver's compressed offsets do not affect the length-read path.
    store._appendEncodedChunk = async () => {}
    const encode = store._encodeArtifactRecordFields.bind(store)
    const groups = []
    const inputs = []
    let rows = 0
    let virtualOffset = 2 ** 40
    const outputDigest = createHash('sha256')
    store._encodeArtifactRecordFields = (chunk, offsets, lengths, contentOffsetBase) => {
        assert(chunk.resolvedContentReferences)
        const references = chunk.resolvedContentReferences
        const bytes = encode(chunk, offsets, lengths, contentOffsetBase)
        outputDigest.update(bytes)
        inputs.push({
            rowCount: chunk.rowCount,
            scoreList: new chunk.scoreList.constructor(chunk.scoreList),
            uniqueIndexList: new Uint32Array(references.uniqueIndexList),
            offsets: new Float64Array(references.offsets),
            lengths: new Uint32Array(references.lengths),
            contentOffsetBase,
            outputSha256: hash(bytes),
            outputByteLength: bytes.byteLength,
        })
        return bytes
    }
    const consume = async (parsed) => {
        assert(parsed.contentDedupPlan && parsed.contentUniqueIndexList instanceof Uint32Array)
        const plan = parsed.contentDedupPlan
        const uniqueRows = plan.uniqueRowIndexes
        const lengths = Uint32Array.from(uniqueRows, (row, unique) => parsed.contentMetaList[(parsed.contentMetaByUniqueIndex ? unique : row) * 4 + 1])
        const offsets = new Float64Array(lengths.length)
        for (let i = 0; i < lengths.length; i++) {
            offsets[i] = virtualOffset
            virtualOffset += Math.max(1, lengths[i])
        }
        const chunk = createArtifactTermRecordChunkWithResolvedContent(
            {...parsed, dictionary: fixture.expectedTitle, dictionaryTotalRows: fixture.termRows},
            parsed.contentUniqueIndexList, offsets, lengths,
            parsed.preparedLookupIndexes ?? null,
        )
        const inputStart = inputs.length
        await store._encodeAndAppendArtifactChunkForState({}, chunk, rows + 1, [], [], chunk.termRecordPreinternedPlan, 'raw', chunk.preparedLookupIndexes)
        groups.push({rows: parsed.rowCount, unique: uniqueRows.length, inputStart, inputCount: inputs.length - inputStart})
        rows += parsed.rowCount
        parsed.releaseBorrowedContent?.()
    }
    let complete = false
    try {
        for (let start = 0; start < termFiles.length;) {
            const plan = sourcePipeline.createCompressedImportRunPlan(start)
            assert(plan, 'Expected the pinned fixtures to admit the compressed source planner')
            assert(await parser.parseTermBankWithWasmColumnChunksParallelCompressedLazy(plan.loaders, plan.estimatedByteLengths, 3, consume, options))
            sourcePipeline.releaseBatch(plan.files)
            start += plan.files.length
        }
        assert.equal(rows, fixture.termRows)
        complete = true
    } finally {
        await sourcePipeline.dispose()
        await parser.disposeParallelTermBankParser()
        await Promise.all(terminations)
        await reader.close()
    }
    const serialized = serialize(inputs)
    const compressed = gzipSync(serialized)
    await writeFile(join(outputRoot, `${dictionary}.bin.gz`), compressed, {flag: 'wx'})
    const report = {
        complete, dictionary, fixture, rows, groups, runs: inputs.length, options,
        scope: 'Actual native parser/source planner and record run splitter; native scores, aliases, lengths; virtual monotonic resolved offsets. No compression, persistence, media collector or whole-import timing. Component timings must be collected separately.',
        node: process.version, v8: process.versions.v8,
        fixturePath, sourceRoot: root,
        lockSha256: hash(lockBytes), parserWasmSha256: hash(wasm),
        sourceSha256: hash(await readFile(join(root, 'ext/js/dictionary/term-record-opfs-store.js'))),
        serializedBytes: serialized.byteLength, compressedBytes: compressed.byteLength,
        serializedSha256: hash(serialized), compressedSha256: hash(compressed),
        outputSha256: outputDigest.digest('hex'),
        outputBytes: inputs.reduce((total, input) => total + input.outputByteLength, 0),
    }
    await writeFile(join(outputRoot, `${dictionary}.json`), `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'})
    process.stdout.write(`${dictionary}: ${rows} rows, ${groups.length} parser groups, ${inputs.length} encoder runs, ${compressed.byteLength} captured bytes\n`)
}
