import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {mkdir, readFile, writeFile} from 'node:fs/promises'
import {join, resolve} from 'node:path'
import {fileURLToPath} from 'node:url'
import {spawnSync} from 'node:child_process'
import os from 'node:os'

const [baselineArgument, candidateArgument, captureArgument, outputArgument, selection = 'jmdict,jitendex,vndb'] = process.argv.slice(2)
assert(baselineArgument && candidateArgument && captureArgument && outputArgument)
const baseline = resolve(baselineArgument)
const candidate = resolve(candidateArgument)
const capture = resolve(captureArgument)
const output = resolve(outputArgument)
await mkdir(output, {recursive: true})
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const orders = ['ABC', 'ACB', 'BAC', 'BCA', 'CAB', 'CBA']
const schedule = selection.split(',').flatMap((dictionary) => ['cold', 'warm'].flatMap((mode) => orders.map((order, round) => ({dictionary, mode, order, round}))))
const childPath = join(fileURLToPath(new URL('.', import.meta.url)), 'child.mjs')
const results = []
const med = (values) => {
    const sorted = [...values].sort((a, b) => a - b)
    const middle = sorted.length >> 1
    return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2
}
const summary = []
const receipt = {
    node: process.version, v8: process.versions.v8, baseline, candidate, capture,
    cpu: os.cpus()[0]?.model, parallelism: os.availableParallelism(),
    startLoad: os.loadavg(), startFreeMemory: os.freemem(),
    baselineSourceSha256: hash(await readFile(join(baseline, 'ext/js/dictionary/term-record-opfs-store.js'))),
    candidateSourceSha256: hash(await readFile(join(candidate, 'ext/js/dictionary/term-record-opfs-store.js'))),
    scriptSha256: hash(await readFile(fileURLToPath(import.meta.url))),
    childSha256: hash(await readFile(childPath)),
    schedule, scheduleSha256: hash(JSON.stringify(schedule)), complete: false, results, summary,
}
try {
    for (const item of schedule) {
        const arms = {}
        for (const arm of item.order) {
            const path = join(output, `${item.dictionary}-${item.mode}-${item.round}-${arm}.json`)
            const result = spawnSync(process.execPath, ['--expose-gc', childPath, arm === 'B' ? candidate : baseline, capture, item.dictionary, item.mode, path], {encoding: 'utf8'})
            if (result.status !== 0) {
                receipt.failure = {item, arm, status: result.status, signal: result.signal, stdout: result.stdout, stderr: result.stderr, error: String(result.error ?? '')}
                throw new Error(`Child failed: ${item.dictionary}/${item.mode}/${item.round}/${arm}`)
            }
            const value = JSON.parse(await readFile(path, 'utf8'))
            assert.equal(value.sourceSha256, arm === 'B' ? receipt.candidateSourceSha256 : receipt.baselineSourceSha256)
            assert.equal(value.node, process.version)
            assert.equal(value.v8, process.versions.v8)
            arms[arm] = value.milliseconds
        }
        results.push({...item, arms, bMinusA: arms.B - arms.A, bMinusC: arms.B - arms.C, cMinusA: arms.C - arms.A,
            bOverA: arms.B / arms.A, bOverC: arms.B / arms.C, cOverA: arms.C / arms.A})
        process.stdout.write(`${item.dictionary} ${item.mode} ${item.order}: A=${arms.A.toFixed(3)} B=${arms.B.toFixed(3)} C=${arms.C.toFixed(3)} ms\n`)
    }
    for (const dictionary of selection.split(',')) {
        for (const mode of ['cold', 'warm']) {
            const cohort = results.filter((row) => row.dictionary === dictionary && row.mode === mode)
            const values = {dictionary, mode, rounds: cohort.length}
            for (const arm of ['A', 'B', 'C']) { values[arm] = med(cohort.map((row) => row.arms[arm])) }
            for (const key of ['bMinusA', 'bMinusC', 'cMinusA', 'bOverA', 'bOverC', 'cOverA']) { values[key] = med(cohort.map((row) => row[key])) }
            summary.push(values)
        }
    }
    receipt.complete = true
} finally {
    receipt.endLoad = os.loadavg()
    receipt.endFreeMemory = os.freemem()
    await writeFile(join(output, 'report.json'), `${JSON.stringify(receipt, null, 2)}\n`, {flag: 'wx'})
}
process.stdout.write(`${JSON.stringify(summary, null, 2)}\n`)
