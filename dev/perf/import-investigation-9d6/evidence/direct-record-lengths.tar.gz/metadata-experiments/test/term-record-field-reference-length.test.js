/*
 * Copyright (C) 2026 Manabitan authors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
/* eslint @stylistic/semi: ["error", "never"] */

import {describe, expect, test} from 'vitest'
import {
    createArtifactTermRecordChunkWithResolvedContent,
    TermRecordOpfsStore,
} from '../ext/js/dictionary/term-record-opfs-store.js'

/**
 * @param {number[]} lengths
 * @returns {{chunk: {rowCount: number, scoreList: Int32Array, resolvedContentReferences: {uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}}, base: number}}
 */
function fixture(lengths = [0, 7, 65534]) {
    const base = 2 ** 40
    const rowCount = 32
    const chunk = createArtifactTermRecordChunkWithResolvedContent(
        {rowCount, scoreList: Int32Array.from({length: rowCount}, (_, i) => [50, 75, 100][i % 3])},
        Uint32Array.from({length: rowCount}, (_, i) => Math.floor(i / 3) % lengths.length),
        Float64Array.from(lengths, (_, i) => base + i * 70000),
        Uint32Array.from(lengths),
    )
    return {chunk, base}
}

/**
 * @param {ReturnType<typeof fixture>['chunk']} chunk
 * @param {number} base
 * @returns {Uint8Array}
 */
function encode(chunk, base) {
    return new TermRecordOpfsStore()._encodeArtifactRecordFields(chunk, [], [], base)
}

describe('record field lengths from synchronous resolved references', () => {
    test.each([
        [0, 7, 65534],
        [0, 7, 65535],
        [0, 0xffffffff, 9],
    ])('matches generic encoding for length bounds %i, %i, %i', (...lengths) => {
        const {chunk, base} = fixture(lengths)
        const actual = encode(chunk, base)
        expect(actual).toEqual(encode({...chunk}, base))
        const compact = lengths.every((length) => length < 65535)
        expect(actual.byteLength).toBe(compact ? 16 + 3 * 4 + chunk.rowCount * 8 : chunk.rowCount * 12)
    })

    test.each([0, 15, 31])('rejects an out-of-range unique index at row %i', (row) => {
        const {chunk, base} = fixture()
        chunk.resolvedContentReferences.uniqueIndexList[row] = 3
        const message = 'Invalid resolved term content reference index: 3'
        expect(() => encode(chunk, base)).toThrow(new RangeError(message))
        expect(() => encode({...chunk}, base)).toThrow(new RangeError(message))
    })

    test('checks a replacement length column and current values on each call', () => {
        const {chunk, base} = fixture()
        const first = encode(chunk, base)
        chunk.resolvedContentReferences.lengths[0] = 65535
        const second = encode(chunk, base)
        expect(second).toEqual(encode({...chunk}, base))
        expect(second.byteLength).toBe(chunk.rowCount * 12)
        chunk.resolvedContentReferences.lengths = Uint32Array.of(3, 5, 7)
        const third = encode(chunk, base)
        expect(third).toEqual(encode({...chunk}, base))
        expect(third).not.toEqual(first)
    })

    test('preserves accessor-backed length reads and mutation order', () => {
        /**
         * @param {boolean} branded
         * @returns {{bytes: Uint8Array, reads: number[]}}
         */
        const run = (branded) => {
            const {chunk, base} = fixture()
            const references = chunk.resolvedContentReferences
            const lengths = references.lengths
            /** @type {number[]} */
            const reads = []
            Object.defineProperty(references, 'lengths', {
                get() {
                    reads.push(reads.length)
                    lengths[0] = reads.length
                    return lengths
                },
            })
            return {bytes: encode(branded ? chunk : {...chunk}, base), reads}
        }
        expect(run(true)).toEqual(run(false))
    })

    test('keeps shared and shifted columns on an equivalent path', () => {
        const {chunk, base} = fixture()
        const shared = new Uint32Array(new SharedArrayBuffer(20), 4, 3)
        shared.set([2, 3, 5])
        chunk.resolvedContentReferences.lengths = shared
        expect(encode(chunk, base)).toEqual(encode({...chunk}, base))
    })
})
