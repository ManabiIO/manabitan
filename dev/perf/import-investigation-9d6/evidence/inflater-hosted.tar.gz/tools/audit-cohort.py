#!/usr/bin/env python3
"""Independently audit retained inflater receipts without running a benchmark."""
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys

folder = Path(sys.argv[1]).resolve()
destination = Path(sys.argv[2]).resolve()
cohort = folder / 'cohort' if (folder / 'cohort').is_dir() else folder
frozen = Path(__file__).resolve().parents[3] / 'dev/perf/inflater-copy-9d6'
identity = json.loads((frozen / 'candidate.json').read_text())
capture_identity = json.loads((frozen / 'capture.json').read_text())
load = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
close = lambda a, b: math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-8)
result = load(cohort / 'result.json')
protocol = load(cohort / 'protocol.json')
observations = load(cohort / 'observations.json')
assert result['complete'] is True and result['failure'] is None
assert result['protocol'] == protocol and result['observations'] == observations
assert protocol['baselineCommit'] == identity['baselineCommit']
assert protocol['node'] == 'v24.22.3'
assert protocol['v8'] == '13.6.233.17-node.63'
schedule = ['ABC', 'ACB', 'BAC', 'BCA', 'CAB', 'CBA']
assert protocol['initialOrder'] in ('AB', 'BA')
if protocol['initialOrder'] == 'BA':
    schedule = [order.translate(str.maketrans('AB', 'BA')) for order in schedule]
assert protocol['schedule'] == schedule
hashes = {'A': identity['baselineTestWasmSha256'], 'B': identity['candidateTestWasmSha256'], 'C': identity['baselineTestWasmSha256']}
assert protocol['wasmHashes'] == hashes
frozen_paths = protocol['frozen']
assert len(frozen_paths) == 5
find_hash = lambda ending: next(value for path, value in frozen_paths.items() if path.endswith(ending))
assert find_hash('/screen.mjs') == identity['screenSha256']
assert find_hash('/screen-child.mjs') == identity['childSha256']
assert find_hash('/baseline/parser.wasm') == identity['baselineTestWasmSha256']
assert find_hash('/candidate/parser.wasm') == identity['candidateTestWasmSha256']
input_hash = find_hash('/jmdict-groups.json')
if cohort != folder:
    status = load(folder / 'status.json')
    assert status['complete'] is True and status['failure'] is None
    assert status['identity'] == identity
    assert all(command['status'] == 0 and command['signal'] is None and command['error'] is None for command in status['commands'])
    build = load(folder / 'build-receipt.json')
    assert build['identity'] == identity
    assert 'clang version 21.1.8' in build['compilerVersion'] and 'LLD 21.1.8' in build['linkerVersion']
    assert all(section['equal'] is True for section in build['sectionProof'] if section['id'] != 7)
    assert load(folder / 'capture-identity.json') == capture_identity
    for arm in ('baseline', 'candidate'):
        assert sha(folder / 'measurement' / arm / 'parser.wasm') == identity[f'{arm}TestWasmSha256']
    assert sha(folder / 'measurement/jmdict-groups.json') == input_hash
    actual_input = load(folder / 'measurement/jmdict-groups.json')
    measured_input = load(Path(__file__).resolve().with_name('jmdict-groups.json'))
    for key in ('dictionary', 'fixture', 'lockSha256', 'entries', 'groups'):
        assert actual_input[key] == measured_input[key]
    assert actual_input['groups'] == load(frozen / 'source-groups.json')

expected_order = [(mode, block, arm) for mode in ('cold', 'warm') for block, order in enumerate(schedule) for arm in order]
assert [(row['mode'], row['block'], row['arm']) for row in observations] == expected_order
assert len(observations) == 36
digest = '343a73cf768e5feaa5a1e557de40b3742a3de404524d164884c4787c668c6be8'
fixture_hash = '3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f'
geometry = None
source_group_evidence = None
recorded = []
pass_count = 0
for row in observations:
    path = cohort / row['resultFile']
    child = load(path)
    command = load(path.with_name(path.stem + '.command.json'))
    assert command['status'] == 0 and command['signal'] is None and command['error'] is None
    assert '--expose-gc' in command['args'] and '--max-old-space-size=512' in command['args']
    assert child['complete'] is True and child['mode'] == row['mode']
    assert child['node'] == protocol['node'] and child['v8'] == protocol['v8']
    assert child['wasmSha256'] == hashes[row['arm']]
    assert child['scriptSha256'] == identity['childSha256']
    assert child['inputSha256'] == input_hash and child['fixtureSha256'] == fixture_hash
    assert child['outputDigest'] == digest and child['groupCount'] == 12 and child['bankCount'] == 53
    expected_warmups, expected_observations = (0, 1) if row['mode'] == 'cold' else (4, 10)
    assert len(child['warmups']) == expected_warmups and len(child['observations']) == expected_observations
    if source_group_evidence is None:
        source_group_evidence = child['sourceGroupEvidence']
    assert child['sourceGroupEvidence'] == source_group_evidence
    assert source_group_evidence['captureScriptSha256'] == '62dd1c7d8757c1f41d0bd27af8f9ed37b2aa14deed4f38141cabb9a7bfd11e8c'
    assert source_group_evidence['parserWasmSha256'] == identity['baselineProductionWasmSha256']
    assert source_group_evidence['baselineCommit'] == identity['baselineCommit']
    if cohort != folder:
        assert source_group_evidence['captureReportSha256'] == '6c897506cdc81a7c24520e861415c0523f24437f8c20ff684bdc60ce4702ac76'
    for item in child['warmups'] + child['observations']:
        assert item['outputDigest'] == digest
        groups = item['groups']
        assert len(groups) == 12 and sum(group['bankCount'] for group in groups) == 53
        assert sum(group['uncompressedBytes'] for group in groups) == 171617523
        assert sum(group['compressedBytes'] for group in groups) == 15632849
        current = [{key: group[key] for key in ('inputPtr', 'outputPtr', 'uncompressedBytes')} for group in groups]
        if geometry is None:
            geometry = current
        assert current == geometry == result['geometry']
        assert all(math.isfinite(group['elapsedMs']) and group['elapsedMs'] > 0 for group in groups)
        assert close(sum(group['elapsedMs'] for group in groups), item['elapsedMs'])
        pass_count += 1
    mean = statistics.mean(item['elapsedMs'] for item in child['observations'])
    assert close(mean, child['meanMs']) and close(mean, row['meanMs'])
    recorded.append({**row, 'resultSha256': sha(path), 'commandSha256': sha(path.with_name(path.stem + '.command.json'))})

comparisons = {}
for mode in ('cold', 'warm'):
    comparisons[mode] = {}
    for left, right in (('B', 'A'), ('B', 'C'), ('C', 'A')):
        pairs = []
        for block in range(6):
            times = {row['arm']: row['meanMs'] for row in observations if row['mode'] == mode and row['block'] == block}
            pairs.append({'block': block, 'percent': 100 * (times[left] / times[right] - 1), 'ms': times[left] - times[right]})
        summary = {'pairs': pairs, 'medianPercent': statistics.median(pair['percent'] for pair in pairs), 'medianMs': statistics.median(pair['ms'] for pair in pairs), 'faster': sum(pair['ms'] < 0 for pair in pairs)}
        original = result['comparisons'][mode][f'{left}/{right}']
        assert close(summary['medianPercent'], original['medianPercent']) and close(summary['medianMs'], original['medianMs']) and summary['faster'] == original['faster']
        comparisons[mode][f'{left}/{right}'] = summary
audit = {'complete': True, 'scope': 'Independent retained JSON/native hash audit only; no benchmark rerun', 'cohort': str(cohort), 'order': protocol['initialOrder'], 'observations': len(observations), 'verifiedCorpusPasses': pass_count, 'outputDigest': digest, 'inputSha256': input_hash, 'sourceGroupEvidence': source_group_evidence, 'node': protocol['node'], 'v8': protocol['v8'], 'host': protocol['hostBefore'], 'comparisons': comparisons, 'rawReceipts': recorded, 'failurePolicy': 'No observation or tail removed; identical-code controls remain separate'}
destination.write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps({key: audit[key] for key in ('complete', 'order', 'observations', 'verifiedCorpusPasses', 'comparisons')}, indent=2))
