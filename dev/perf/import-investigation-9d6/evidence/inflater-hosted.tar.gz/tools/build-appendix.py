"""Package the two completed inflater hosts without altering prior evidence."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import re
import statistics
import tarfile
import zipfile

root = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(Path(path).read_text())
api = read(root / 'workflow-api.json')
assert api['run'] == 46106878218 and api['attempt'] == 1
assert api['head'] == 'bc22226a2299b58ddb26b23d928b1b99c28422eb'
assert len(api['jobs']) == 2 and all(job['status'] == 'completed' and job['conclusion'] == 'success' for job in api['jobs'])
assert all(step['conclusion'] in ['success', 'skipped'] for job in api['jobs'] for step in job['steps'])
selected = {}
artifacts = []
hosts = {}
files = []
for order, artifact_id in [('AB', 15250090313), ('BA', 15249129886)]:
    artifact = next(item for item in api['artifacts'] if item['id'] == artifact_id)
    assert artifact['name'] == f'import-inflater-copy-{order}-9d6-46106878218-1'
    assert artifact['workflow_run']['head_sha'] == api['head']
    assert artifact['workflow_run']['id'] == api['run']
    archive = root / f'artifact-{artifact_id}.zip'
    extracted = root / f'artifact-{artifact_id}'
    data = archive.read_bytes()
    assert len(data) == artifact['size_in_bytes']
    assert sha(data) == artifact['digest'].removeprefix('sha256:')
    member_hashes = []
    with zipfile.ZipFile(io.BytesIO(data)) as zipped:
        members = [item for item in zipped.infolist() if not item.is_dir()]
        assert len({item.filename for item in members}) == len(members)
        for item in members:
            name = Path(item.filename)
            assert not name.is_absolute() and '..' not in name.parts
            content = zipped.read(item)
            assert content == (extracted / name).read_bytes()
            member_hashes.append({'path': item.filename, 'bytes': len(content), 'sha256': sha(content)})
            if name.suffix in {'.json', '.log'}:
                selected[f'{order}/{item.filename}'] = extracted / name
    artifacts.append({'artifactId': artifact_id, 'name': artifact['name'], 'runId': api['run'], 'runAttempt': 1, 'headSha': api['head'], 'zipBytes': len(data), 'zipSha256': sha(data), 'originalMembers': member_hashes})
    audit = read(root / f'audit-{order}.json')
    assert audit['complete'] and audit['order'] == order
    assert audit['observations'] == 36 and audit['verifiedCorpusPasses'] == 270
    observations = read(extracted / 'cohort/observations.json')
    assert len(observations) == 36
    assert len(list((extracted / 'cohort').glob('*.command.json'))) == 36
    assert len(list((extracted / 'cohort').glob('*.log'))) == 36
    hosts[order] = {'artifactId': artifact_id, 'host': audit['host'], 'node': audit['node'], 'v8': audit['v8'], 'observations': 36, 'verifiedCorpusPasses': 270, 'comparisons': audit['comparisons'], 'armMediansMs': {mode: {arm: statistics.median(row['meanMs'] for row in observations if row['mode'] == mode and row['arm'] == arm) for arm in 'ABC'} for mode in ['cold', 'warm']}, 'auditSha256': sha((root / f'audit-{order}.json').read_bytes())}
    selected[f'analysis/audit-{order}.json'] = root / f'audit-{order}.json'
    selected[f'identity/artifact-{artifact_id}-receipt.json'] = root / f'artifact-{artifact_id}-receipt.json'

test_log = (root / 'artifact-15250090313/focused-tests.log').read_text()
test_log = re.sub(r'\x1b\[[0-9;]*m', '', test_log)
assert '96 passed (96)' in test_log and '2 passed (2)' in test_log
local_path = root.parent / 'inflater-simd/local-cohort-audit.json'
local = read(local_path)
assert local['complete'] and local['observations'] == 36
local_evidence = {'commit': 'd602e1b003811b0ebac63e9ef2c8019f430aea21', 'path': 'dev/perf/import-investigation-9d6/evidence/inflater-local.tar.gz', 'archiveSha256': 'b7312cb75461cfa89afee5522e5074e93a82302b2be4e1efea34799db0a7522c', 'auditSha256': sha(local_path.read_bytes()), 'comparisons': local['comparisons'], 'note': 'Original noisy local cohort remains unchanged in the previously published archive; no local rerun or observation replacement.'}
decision = {'complete': True, 'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'Closed without promotion', 'decision': 'No product branch, whole-import cohort, or PR. Warm gains are only about one millisecond for the full sequential corpus, and the cold gain does not replicate on BA. The retained local cohort also has cold losses and substantial control drift.', 'baselineCommit': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2', 'experimentCommit': api['head'], 'runId': api['run'], 'runAttempt': 1, 'candidate': '18 native lines: bounded 16+16+8-byte copies in the existing 40-byte libdeflate fast match loop, for distances >=16 only; same maximum overwrite allowance.', 'workload': {'dictionary': 'jmdict', 'groups': 12, 'banks': 53, 'uncompressedBytes': 171617523, 'compressedSourceBytes': 15632849, 'outputDigest': local['outputDigest'], 'scope': 'Sequential native inflate plus immediate CRC in one WASM instance; excludes parser, worker scheduling/transport, storage and UI. Cold and warm remain separate.'}, 'protocol': {'hosts': 2, 'childrenPerHost': 36, 'totalChildren': 72, 'verifiedCorpusPasses': 540, 'cold': 'Six A/B/C permutations, one timed corpus per fresh child, no warmup', 'warm': 'Six A/B/C permutations, four excluded warmups and ten measured corpus passes per fresh child', 'controls': 'A/C identical baseline; B candidate. Every observation, warmup, tail, command receipt and log retained.'}, 'correctness': {'byteAndCrcDigestsEqual': True, 'nativeModuleHashesExact': True, 'frozenSourceAndInputIdentitiesExact': True, 'focusedTestsOnAB': 96, 'testFilesOnAB': 2, 'limitations': 'Correctness evidence does not establish an import-latency improvement.'}, 'hosts': hosts, 'localEvidence': local_evidence, 'originalArtifacts': [{key: value for key, value in row.items() if key != 'originalMembers'} for row in artifacts]}
decision_path = root / 'disposition.json'
with decision_path.open('x') as target:
    json.dump(decision, target, indent=2)
    target.write('\n')
selected['analysis/disposition.json'] = decision_path
selected['identity/workflow-api.json'] = root / 'workflow-api.json'
selected['analysis/local-cohort-audit.json'] = local_path
selected['tools/audit-cohort.py'] = root.parent / 'inflater-simd/audit-cohort.py'
selected['tools/build-appendix.py'] = Path(__file__)

buffer = io.BytesIO()
with gzip.GzipFile(fileobj=buffer, mode='wb', compresslevel=6, mtime=0, filename='') as compressed:
    with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, source in sorted(selected.items()):
            data = source.read_bytes()
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o444
            archive.addfile(info, io.BytesIO(data))
            files.append({'archivePath': name, 'sourcePath': str(source), 'bytes': len(data), 'sha256': sha(data)})
archive_data = buffer.getvalue()
appendix_path = root / 'inflater-hosted.tar.gz'
with appendix_path.open('xb') as target:
    target.write(archive_data)
with tarfile.open(appendix_path, 'r:gz') as archive:
    members = archive.getmembers()
    assert len(members) == len(files)
    for item, row in zip(members, files):
        assert item.isfile() and item.name == row['archivePath'] and item.size == row['bytes']
        assert sha(archive.extractfile(item).read()) == row['sha256']

inventory = {'complete': True, 'scope': 'Separate completed hosted appendix; does not alter or supersede original local evidence.', 'archive': {'bytes': len(archive_data), 'sha256': sha(archive_data), 'files': len(files), 'uncompressedBytes': sum(row['bytes'] for row in files)}, 'files': files, 'originalArtifacts': artifacts, 'auditorSha256': sha((root.parent / 'inflater-simd/audit-cohort.py').read_bytes()), 'packagerSha256': sha(Path(__file__).read_bytes()), 'verification': 'Original ZIP sizes/digests, every original extracted byte, all selected source hashes and every newly saved tar member verified. Two exact candidate native modules and their source/build/input receipts verified by the independent audit. No new timing.', 'excluded': 'Original ZIPs and the generated timing WASM duplicates only; their exact identities remain recorded.'}
inventory_path = root / 'appendix-inventory.json'
with inventory_path.open('x') as target:
    json.dump(inventory, target, indent=2)
    target.write('\n')

lines = ['# Inflater match-copy experiment: closed without promotion', '', '**No product branch, complete-import cohort or PR is justified.** The fixed two-host study is complete. Warmed savings are only about one millisecond across the full sequential JMdict corpus, and the cold gain on AB does not replicate on BA. The earlier local cold losses and large control drift remain preserved.', '', f"Run **{api['run']}**, attempt **1**, experiment head `{api['head']}`; product baseline `{decision['baselineCommit']}`. Both hosts completed successfully. Every one of the **72 child observations**, command receipts and logs is retained, including all 540 warmup/measured corpus passes. The independent audit verifies exact native builds, source and fixture/capture identities, schedules, pointer geometry, output bytes/CRC digests, and paired arithmetic. All **96 focused tests** pass in the AB validation job.", '', '## Results', '', 'Values are paired median candidate changes; negative favors the candidate. A/C are identical baseline code. Cold and warm observations are separate; no tails or controls were discarded.', '', '| Cohort | Mode | B/A change | B/C change | C/A control drift | Candidate wins vs A / C |', '| --- | --- | ---: | ---: | ---: | --- |']
for label, data in [('Original local', local), ('Hosted AB', hosts['AB']), ('Hosted BA', hosts['BA'])]:
    for mode in ['cold', 'warm']:
        values = data['comparisons'][mode]
        cell = lambda name: f"{values[name]['medianMs']:+.3f} ms ({values[name]['medianPercent']:+.2f}%)"
        lines.append(f"| {label} | {mode} | {cell('B/A')} | {cell('B/C')} | {cell('C/A')} | {values['B/A']['faster']}/6 / {values['B/C']['faster']}/6 |")
lines += ['', f"Hosted AB CPU: {hosts['AB']['host']['cpuModel']}. Hosted BA CPU: {hosts['BA']['host']['cpuModel']}. Both use Node {hosts['AB']['node']} / V8 {hosts['AB']['v8']}.", '', 'The timed endpoint processes the same 53 banks / 12 production groups in one WASM instance: 171,617,523 output bytes and 15,632,849 compressed input bytes. It measures inflate plus immediate CRC, excluding parser work, worker scheduling/transport, storage and UI. It is component evidence, not a real browser import result. The change adds 18 native lines, preserves the existing maximum-overwrite bound, and changes only one function body in the exact timing module; correctness and small code size do not overcome the weak performance case.', '', '## Preserved evidence', '', f"`inflater-hosted.tar.gz`: **{len(archive_data):,} bytes**, SHA256 `{sha(archive_data)}`, **{len(files)} files**. `inflater-hosted-inventory.json` lists every member and both original ZIP member maps. `inflater-hosted.json` contains the complete disposition, host context and every paired comparison. The archive includes both independent audits and the exact auditor/packager source.", '', '| Original artifact | Order | ZIP bytes | Original ZIP SHA256 |', '| ---: | --- | ---: | --- |']
for order, row in zip(['AB', 'BA'], artifacts):
    lines.append(f"| {row['artifactId']} | {order} | {row['zipBytes']:,} | `{row['zipSha256']}` |")
lines += ['', 'Original ZIP identities and every extracted member were verified before packaging. Generated timing WASM duplicates and original ZIPs are omitted from the compact appendix; their exact hashes and build/source receipts remain. Neither source fixtures nor captured source bytes are duplicated.', '', f"The original local evidence remains unchanged in [`inflater-local.tar.gz`](https://github.com/ManabiIO/manabitan/blob/{local_evidence['commit']}/{local_evidence['path']}), SHA256 `{local_evidence['archiveSha256']}`. This appendix adds both prescribed hosted outcomes and closes the experiment; it does not replace the local cohort or launch any further timing.", '']
readme_path = root / 'README.md'
with readme_path.open('x') as target:
    target.write('\n'.join(lines))

publication = []
for source, destination, encoding in [(appendix_path, 'inflater-hosted.tar.gz', 'base64'), (inventory_path, 'inflater-hosted-inventory.json', 'utf-8'), (decision_path, 'inflater-hosted.json', 'utf-8'), (readme_path, 'inflater-hosted.md', 'utf-8')]:
    data = source.read_bytes()
    publication.append({'path': 'dev/perf/import-investigation-9d6/evidence/' + destination, 'localPath': str(source), 'encoding': encoding, 'bytes': len(data), 'sha256': sha(data), 'gitBlobSha1': hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()})
manifest_path = root / 'publication-manifest.json'
with manifest_path.open('x') as target:
    json.dump({'status': 'Frozen evidence-only appendix ready for root publication; no product promotion or external publication by this agent.', 'files': publication}, target, indent=2)
    target.write('\n')
print(json.dumps({'complete': True, 'manifest': str(manifest_path), 'manifestSha256': sha(manifest_path.read_bytes()), 'archiveBytes': len(archive_data), 'archiveSha256': sha(archive_data), 'files': len(files), 'hosts': {order: {'cpu': data['host']['cpuModel'], 'coldMedianMsBA': data['comparisons']['cold']['B/A']['medianMs'], 'warmMedianMsBA': data['comparisons']['warm']['B/A']['medianMs']} for order, data in hosts.items()}}, indent=2))
