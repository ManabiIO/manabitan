# Metadata/cache experiment, 2026-11-28

## Decision

Do not propose a PR. Fusing source-span validation/extent calculation into the existing contiguous metadata-publication loop passes the 187 existing focused tests and an exact table/cache-byte component oracle, but its warmed component saving is roughly half a millisecond for all 528,299 JMdict rows. The change adds 96 lines and does not justify full import qualification or runtime promotion. No browser speedup is claimed.

## Sources and distinction

Baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. Isolated local worktree `metadata-experiments`, branch `perf/metadata-source-cache-20261128`. The runtime prototype is retained in `cache-scan-fusion.patch` and remains uncommitted in the worktree. Only dictionary-database.js is changed.

Prior PR #876, cdb23a11d991a72f860e400d0d81bb0747a5b4f9, reused immediate contiguous index/state checks but retained the separate bounds/minimum/maximum/total-byte scan. That closed candidate showed no material complete-import gain. This prototype additionally fuses that entire span scan, with synchronous proof consumption, conservative alias rejection, unchanged ownership, cache budget, eviction and large-definition sampled boundary policy. No proof crosses an await.

## Actual corpus capture

`capture.mjs` uses actual current source planning, parser workers, canonical resolver and publication with deterministic virtual persisted offsets. Full per-row equality checked all 528,299 rows, 12 groups, 362,032 pending/cache entries; no parsing-only or synthetic-corpus timing claim. All 12 staged ranges are contiguous and published. Three groups have nonzero source origins (49, 289, 366), covering 89,237 entries. All groups adopt immutable transferred shared sources; no extra allocation is avoided by this experiment.

Captures are v8.serialize payloads compressed afterward with gzip level1. Read via `deserialize(gunzipSync(bytes))`. v1 complete capture has lengths/offsets/source/state/index data. v3 complete capture also has actual published hash/offset arrays and length columns. Persisted offsets are deterministic virtual addresses, not OPFS offsets. Restore SharedArrayBuffer source storage and alias `pendingLengths` to span lengths when modeling the production shared reservation path. sourceGroups and original parser profiles are preserved in report.json.

## Component protocol and results

A/C are unchanged baseline; B/D are identical candidate. Four warmups per arm; eight fixed balanced blocks ABCD, BDAC, CADB, DCBA repeated twice. Ten full-dictionary target-phase replays per observation. Explicit GC, owner reset and input preparation are outside timing. All output metadata and retained cache bytes match. Source parsing, canonical resolution, compression, worker scheduling, OPFS and UI are excluded. Metadata owner columns are separate arrays, unlike the native production arena. Sources, fixtures, capture hashes, host context, observations and process memory are retained. No discarded tails or appended successful samples.

The original runner used the upper middle observation for even-count median display. Correct ordinary medians are reported below (raw observations unchanged).

| Comparison | Paired median change | Faster blocks |
|---|---:|---:|
| B/A | -12.221% | 6/8 |
| D/A | -10.450% | 6/8 |
| C/A | 3.984% | 2/8 |
| D/B | 4.420% | 2/8 |

Arm mean-replay medians (ms): {"A": 5.449723649999873, "B": 4.7836539000000355, "C": 5.437380300000006, "D": 4.924491500000158}.

Complete output SHA256: `600ac782c46ca533a209fe3e9c6bdd014d84654292b4d8545d835cd27138ce9f`.

## Failures and corrections

- Initial focused tests failed to load generated resvg-wasm.js in the fresh worktree. Ordinary build:libs supplied the missing generated assets, then all 187 tests in three targeted suites passed. Logs retained.
- Capture v2 was killed with exit137 after seven groups. Its compact complete successor v3 passed all rows. Partial reproducible v2 binaries were deleted to relieve full workspace; original failure log and member-size note remain.
- The first eight-block/four-owner screen was killed with exit137 after four blocks. It did not write a completed report or retain raw elapsed observations; no performance conclusion or samples are taken from it. Failure record/log retained.
- Corrected screen detaches retained small typed-array views from decompression buffers, reuses one owner per source (A/C and B/D still identical-source controls), explicitly collects GC outside timing, limits old-space to384MiB, and streams every observation. It is a fresh complete cohort. Executor unavailable/recovery occurred before this corrected cohort started.

## Reproduction

From this worktree, with baseline and generated libraries available:

```sh
node --expose-gc --max-old-space-size=384 builds/perf/metadata-cache/replay.mjs ../manabitan . builds/perf/metadata-cache/jmdict-capture-v3 /path/to/new-result.json 8 10
```

Do not overwrite prior results. Reproduction requires gzip captures plus the current script and exact source versions. Tests: dictionary-content-publication-range, dictionary-database-boundary-cache, dictionary-database-content-dedup.
