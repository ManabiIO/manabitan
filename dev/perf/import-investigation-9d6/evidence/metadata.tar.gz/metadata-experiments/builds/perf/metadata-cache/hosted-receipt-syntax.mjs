import assert from 'node:assert/strict'
import {readFile, writeFile} from 'node:fs/promises'
import {join} from 'node:path'
const output = process.env.COMPONENT_OUTPUT
const expected = JSON.parse(await readFile('scripts/dev/perf/metadata-cache-9d6/capture.json', 'utf8'))
const run = JSON.parse(await readFile(join(output, 'capture-run.json'), 'utf8'))
assert.equal(run.id, Number(process.env.CAPTURE_RUN_ID))
assert.equal(run.head_sha, process.env.CAPTURE_HEAD_SHA)
const listing = JSON.parse(await readFile(join(output, 'capture-artifacts.json'), 'utf8'))
const artifacts = listing.artifacts.filter(({name}) => name === process.env.CAPTURE_ARTIFACT_NAME)
assert.equal(artifacts.length, 1, 'The prescribed capture must exist before this workflow starts')
const artifact = artifacts[0]
assert.equal(artifact.expired, false)
assert.equal(artifact.workflow_run.id, run.id)
assert.equal(artifact.workflow_run.head_sha, run.head_sha)
assert.match(artifact.digest, /^sha256:[a-f0-9]{64}$/)
const identity = {runId: run.id, runAttempt: run.run_attempt, headSha: run.head_sha, artifactId: artifact.id, artifactName: artifact.name, artifactDigest: artifact.digest, artifactSize: artifact.size_in_bytes}
assert.deepEqual(identity, expected)
await writeFile(join(output, 'capture-identity.json'), JSON.stringify(identity, null, 2) + '\n', {flag: 'wx'})
