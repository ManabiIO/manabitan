/* eslint @stylistic/semi: ["error", "never"] */
import assert from 'node:assert/strict'
import {readFile, writeFile, appendFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {gunzipSync} from 'node:zlib'
import {deserialize} from 'node:v8'
import {resolve, join} from 'node:path'
import {pathToFileURL} from 'node:url'
import os from 'node:os'
const [baselinePath, candidatePath, capturePath, outputPath, blockArg = '8', repeatArg = '10'] = process.argv.slice(2)
assert(baselinePath && candidatePath && capturePath && outputPath)
const roots = [resolve(baselinePath), resolve(candidatePath)]
const load = (root, file) => import(pathToFileURL(join(root, file)))
const modules = await Promise.all(roots.map((root) => load(root, 'ext/js/dictionary/dictionary-database.js')))
const ownership = await Promise.all(roots.map((root) => load(root, 'ext/js/dictionary/term-content-ownership.js')))
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const report = JSON.parse(await readFile(join(capturePath, 'report.json')))
assert(report.complete && report.summary.cacheRows === 362032 && report.groups.length === 12)
const fixtures = await Promise.all(report.groups.map(async (group) => {
    const compressed = await readFile(join(capturePath, group.cacheFile))
    const value = deserialize(gunzipSync(compressed))
    const source = new Uint8Array(value.shared ? new SharedArrayBuffer(value.source.byteLength) : new ArrayBuffer(value.source.byteLength))
    source.set(value.source)
    const lengths = Uint32Array.from(value.lengths)
    return {...value, source, states: Uint8Array.from(value.states), indexes: Int32Array.from(value.indexes), offsets: Uint32Array.from(value.offsets), lengths,
        hash1s: Uint32Array.from(value.hash1s), hash2s: Uint32Array.from(value.hash2s),
        persistedOffsets: Float64Array.from(value.persistedOffsets), persistedLengths: lengths,
        captureSha256: sha(compressed)}
}))
const capacity = Math.max(...fixtures.map((fixture) => fixture.stateCapacity))
const count = report.summary.cacheRows
function makeOwner(variant) {
    const owner = Object.create(modules[variant].DictionaryDatabase.prototype)
    Object.assign(owner, {
        _termEntryContentMetaStateTable: new Uint8Array(capacity),
        _termEntryContentMetaHash1Table: new Uint32Array(capacity),
        _termEntryContentMetaHash2Table: new Uint32Array(capacity),
        _termEntryContentMetaLengthTable: new Uint32Array(capacity),
        _termEntryContentMetaIdTable: new Float64Array(capacity),
        _termEntryContentMetaOffsetTable: new Float64Array(capacity),
        _termEntryContentMetaDictNameIdTable: new Uint32Array(capacity),
        _termEntryContentMetaRecentSourceBatchIdTable: new Uint32Array(capacity),
        _termEntryContentMetaRecentSourceOffsetTable: new Uint32Array(capacity),
        _recentTermContentSourceCacheMaxBytes: 96 * 1024 * 1024,
        _recentTermContentSourceBatches: new Map(),
        _recentTermContentBoundaryBatchId: 0,
        _recentTermContentSourceBatchBytes: 0,
        _nextRecentTermContentSourceBatchId: 1,
        _termEntryContentMetaHashPairCount: 0,
        _termEntryContentMetaHashPairPendingCount: count,
    })
    for (const fixture of fixtures) {
        owner._termEntryContentMetaHash1Table.set(fixture.hash1s, fixture.first)
        owner._termEntryContentMetaHash2Table.set(fixture.hash2s, fixture.first)
        owner._termEntryContentMetaLengthTable.set(fixture.lengths, fixture.first)
    }
    return {variant, owner}
}
const baselineArm = makeOwner(0)
const candidateArm = makeOwner(1)
const arms = {A: baselineArm, B: candidateArm, C: baselineArm, D: candidateArm}
const inputs = fixtures.map((fixture) => ({
    staged: {indexes: fixture.indexes, active: true},
    spans: {buffer: fixture.source, offsets: fixture.offsets, lengths: fixture.lengths},
    fixture,
}))
function reset(arm) {
    const {owner, variant} = arm
    owner._termEntryContentMetaStateTable.fill(2, 0, count)
    owner._termEntryContentMetaRecentSourceBatchIdTable.fill(0)
    owner._termEntryContentMetaRecentSourceOffsetTable.fill(0)
    owner._recentTermContentSourceBatches.clear()
    owner._recentTermContentBoundaryBatchId = 0
    owner._recentTermContentSourceBatchBytes = 0
    owner._nextRecentTermContentSourceBatchId = 1
    owner._termEntryContentMetaHashPairCount = 0
    owner._termEntryContentMetaHashPairPendingCount = count
    for (const fixture of fixtures) { assert(ownership[variant].registerOwnedTermContent(fixture.source)) }
}
function execute(arm) {
    const {owner} = arm
    reset(arm)
    let elapsedMs = 0
    let reused = 0
    const times = []
    for (const {fixture, staged, spans} of inputs) {
        const cacheRange = {staged, spans, valid: false, minimumOffset: Infinity, maximumEnd: 0, contentBytes: 0}
        const start = performance.now()
        const published = owner._tryPublishContiguousArtifactTermContentMetadata(staged, fixture.hash1s, fixture.hash2s,
            fixture.persistedOffsets, fixture.persistedLengths, 0, true, cacheRange)
        const retained = owner._cacheRecentPublishedTermContentSources(staged, spans, null, cacheRange)
        const duration = performance.now() - start
        times.push(duration)
        elapsedMs += duration
        if (cacheRange.valid) { ++reused }
        assert(published)
        assert.equal(retained, fixture.retainedBytes)
    }
    assert.equal(owner._termEntryContentMetaHashPairPendingCount, 0)
    assert.equal(owner._termEntryContentMetaHashPairCount, count)
    return {elapsedMs, reused, times}
}
function digest(arm) {
    const {owner} = arm
    const hash = createHash('sha256')
    for (const key of Object.keys(owner).sort()) {
        const value = owner[key]
        if (ArrayBuffer.isView(value)) { hash.update(key).update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)) }
        else if (typeof value === 'number') { hash.update(key).update(String(value)) }
    }
    for (const [key, bytes] of owner._recentTermContentSourceBatches) { hash.update(String(key)).update(bytes) }
    return hash.digest('hex')
}
const sourceHashes = await Promise.all(roots.map(async (root) => sha(await readFile(join(root, 'ext/js/dictionary/dictionary-database.js')))))
const blocks = Number(blockArg)
const repeats = Number(repeatArg)
assert(Number.isSafeInteger(blocks) && blocks > 0 && Number.isSafeInteger(repeats) && repeats > 0)
const warmupCount = 0
const observations = []
const warmups = []
globalThis.gc?.()
const hostBefore = {load: os.loadavg(), memory: process.memoryUsage(), cpus: os.availableParallelism(), node: process.version, cpuModel: os.cpus()[0].model}
process.stderr.write(`${JSON.stringify({hostBefore})}\n`)
for (let i = 0; i < warmupCount; ++i) {
    for (const arm of 'ACBD') { warmups.push({iteration: i, arm, ...execute(arms[arm])}) }
}
let expected = null

for (const arm of ['A', 'B']) { for (const [batch, source] of arms[arm].owner._recentTermContentSourceBatches) { assert.equal(source.buffer, fixtures[batch-1].source.buffer, 'Source must be adopted, not copied') } }
for (let block = 0; block < blocks; ++block) {
    const order = ['ABCD', 'BDAC', 'CADB', 'DCBA'][block % 4]
    for (const arm of order) {
        globalThis.gc?.()
        const values = []
        for (let replay = 0; replay < repeats; ++replay) { values.push(execute(arms[arm])) }
        const observation = {block, arm, order, meanMs: values.reduce((n, x) => n + x.elapsedMs, 0) / repeats, values, memory: process.memoryUsage()}
        if (expected === null) { expected = digest(arms[arm]) }
        assert.equal(digest(arms[arm]), expected)
        observations.push(observation)
        await appendFile(`${outputPath}.jsonl`, `${JSON.stringify(observation)}\n`)
        process.stderr.write(`${arm} block${block + 1} RSS${Math.round(observation.memory.rss / 1048576)}MB external${Math.round(observation.memory.external / 1048576)}MB\n`)
    }
    process.stderr.write(`block ${block + 1}/${blocks}\n`)
}
for (const arm of ['A', 'B', 'C', 'D']) { assert.equal(digest(arms[arm]), expected) }
const hostAfter = {load: os.loadavg(), memory: process.memoryUsage()}
const median = (values) => [...values].sort((a,b) => a-b)[Math.floor(values.length/2)]
const comparisons = {}
for (const [left, right] of [['B', 'A'], ['D', 'A'], ['C', 'A'], ['D', 'B']]) {
    const deltas = []
    for (let block = 0; block < blocks; ++block) {
        const a = observations.find((x) => x.block === block && x.arm === left).meanMs
        const b = observations.find((x) => x.block === block && x.arm === right).meanMs
        deltas.push((a / b - 1) * 100)
    }
    comparisons[`${left}/${right}`] = {medianPercent: median(deltas), deltas}
}
const result = {complete:true, scope:'Cold Node V8 tiering diagnostic only; all four labels use the identical baseline module; no candidate performance conclusion. Zero warmups. Metadata columns use separate allocations unlike production native arena. Chrome uses a different V8.',
    sourceRoots: roots, sourceHashes, captureSource: report.databaseSourceSha256, fixture: report.fixture,
    captureHashes: fixtures.map((x) => x.captureSha256), rows: count, groups: fixtures.length, warmupCount, blocks, repeats,
    controls:'A/C identical baseline; B/D identical candidate; no control correction or tail removal',
    hostBefore, hostAfter, outputDigest:expected, comparisons, warmups, observations}
await writeFile(outputPath, `${JSON.stringify(result,null,2)}\n`, {flag:'wx'})
console.log(JSON.stringify({complete:true, outputDigest:expected, comparisons, armMedians:Object.fromEntries(Object.keys(arms).map((arm) => [arm, median(observations.filter((x) => x.arm === arm).map((x) => x.meanMs))]))},null,2))
