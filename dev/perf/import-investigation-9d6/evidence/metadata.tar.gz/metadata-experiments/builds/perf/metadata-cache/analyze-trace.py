import collections
import hashlib
import json
import pathlib
import sys

source = pathlib.Path(sys.argv[1])
destination = pathlib.Path(sys.argv[2])
raw = source.read_bytes()
document = json.loads(raw)
events = document['traceEvents']
worker_names = {}
profiles = {}
for event in events:
    name = event.get('name')
    data = event.get('args', {}).get('data', {})
    if name == 'TracingSessionIdForWorker':
        worker_names[(event['pid'], data['workerThreadId'])] = data['url']
    if name == 'Profile':
        profiles[(event['pid'], event['id'])] = {'thread': event['tid'], 'start': data['startTime'], 'chunks': []}
for event in events:
    if event.get('name') == 'ProfileChunk':
        key = (event['pid'], event['id'])
        assert key in profiles
        profiles[key]['chunks'].append(event)

summary = []
for key, profile in profiles.items():
    nodes = {}
    samples = []
    timestamp = profile['start']
    for chunk in sorted(profile['chunks'], key=lambda value: value['ts']):
        data = chunk['args']['data']
        cpu = data.get('cpuProfile', {})
        nodes.update((node['id'], node) for node in cpu.get('nodes', []))
        ids = cpu.get('samples', [])
        deltas = data.get('timeDeltas', [])
        lines = data.get('lines', [None] * len(ids))
        assert len(ids) == len(deltas) == len(lines)
        for node_id, delta, line in zip(ids, deltas, lines):
            previous = timestamp
            timestamp += delta
            samples.append((node_id, delta, previous, timestamp, line))
    self_time = collections.Counter()
    inclusive_time = collections.Counter()
    hits = collections.Counter()
    sampled_lines = collections.defaultdict(collections.Counter)
    intervals = collections.defaultdict(list)
    def label(node_id):
        frame = nodes[node_id]['callFrame']
        return (frame.get('functionName', ''), frame.get('url', ''), frame.get('lineNumber', -1))
    for node_id, delta, start, end, line in samples:
        frame = label(node_id)
        self_time[frame] += delta
        hits[frame] += 1
        sampled_lines[frame][line] += delta
        intervals[frame].append([start, end])
        seen = set()
        while node_id in nodes:
            current = label(node_id)
            if current not in seen:
                inclusive_time[current] += delta
                seen.add(current)
            node_id = nodes[node_id].get('parent')
    thread = profile['thread']
    functions = []
    for frame, value in self_time.most_common():
        function, url, line = frame
        functions.append({'function': function, 'url': url, 'line': line + 1, 'selfMs': value / 1000, 'inclusiveMs': inclusive_time[frame] / 1000, 'samples': hits[frame], 'topSampleLines': [{'line': line, 'ms': micros / 1000} for line, micros in sampled_lines[frame].most_common(8)]})
    tasks = [event for event in events if event.get('name') == 'RunTask' and event.get('pid') == key[0] and event.get('tid') == thread and event.get('ph') == 'X']
    summary.append({'pid': key[0], 'profileId': key[1], 'thread': thread, 'url': worker_names.get((key[0], thread), ''), 'startUs': profile['start'], 'endUs': timestamp, 'wallMs': (timestamp - profile['start']) / 1000, 'samples': len(samples), 'taskCount': len(tasks), 'taskWallMs': sum(task.get('dur', 0) for task in tasks) / 1000, 'taskThreadMs': sum(task.get('tdur', 0) for task in tasks) / 1000, 'functions': functions})

result = {'traceSha256': hashlib.sha256(raw).hexdigest(), 'source': str(source), 'scope': 'Diagnostic trace. Profile time deltas include waiting and descheduling; they are sampled wall attribution, not pure CPU time or an import timing comparison.', 'profiles': summary}
destination.write_text(json.dumps(result, indent=2) + '\n')
for profile in summary:
    print('THREAD', profile['thread'], profile['url'], 'tasks ms', round(profile['taskWallMs'], 3), 'thread ms', round(profile['taskThreadMs'], 3))
    for function in profile['functions'][:22]:
        print(' ', round(function['selfMs'], 3), round(function['inclusiveMs'], 3), function['function'], function['url'].split('/')[-1], function['line'])
