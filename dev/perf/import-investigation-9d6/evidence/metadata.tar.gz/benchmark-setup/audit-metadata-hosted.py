import hashlib
import json
import math
import re
import statistics
import zipfile
from pathlib import Path

root = Path('/workspace/scratch/9d6dcf05cf8f')
package = root / 'metadata-experiments/dev/perf/metadata-cache-9d6'
api = json.loads((root / 'benchmark-setup/metadata-hosted-api.json').read_text())
identity = json.loads((package / 'candidate.json').read_text())
capture_identity = json.loads((package / 'capture.json').read_text())
sha = lambda value: hashlib.sha256(value).hexdigest()
read = lambda path: json.loads(path.read_text())
close = lambda a, b: math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-9)
expected_digest = 'bd373ab9ea4a98b7c38832f2aa9d16ccbea5cca65f6ed7268d0bdf70ea57c6d9'
report_sha = '6c897506cdc81a7c24520e861415c0523f24437f8c20ff684bdc60ce4702ac76'
capture_path = root / 'compression-probe/hosted-results/capture/artifact-15245899188/report.json'
capture = read(capture_path)
assert sha(capture_path.read_bytes()) == report_sha
assert capture['complete'] and capture['error'] is None
expected_capture_hashes = [group['cacheSha256'] for group in capture['groups']]
assert sha((package / 'candidate.patch').read_bytes()) == identity['patchSha256']
assert sha((root / 'manabitan/ext/js/dictionary/dictionary-database.js').read_bytes()) == identity['baselineSourceSha256']
assert sha((root / 'metadata-experiments/ext/js/dictionary/dictionary-database.js').read_bytes()) == identity['candidateSourceSha256']
assert sha((root / 'metadata-experiments' / identity['testPath']).read_bytes()) == identity['candidateTestSha256']

audit = {'scope': 'Independent arithmetic, raw receipt, and artifact audit; no new timing or browser qualification.', 'hosts': {}}
capture_hashes = None
for host in ['AB', 'BA']:
    path = root / 'metadata-results' / host
    download = read(path / 'download-receipt.json')
    artifact = next(value for value in api['artifacts'] if value['id'] == download['id'])
    assert artifact['workflow_run']['id'] == 46104605338
    assert artifact['workflow_run']['head_sha'] == '8ce17bb15c5593889a528e91c753684b641a1afe'
    zipped = (path / 'artifact.zip').read_bytes()
    assert len(zipped) == artifact['size_in_bytes'] == download['size']
    assert sha(zipped) == artifact['digest'].removeprefix('sha256:') == download['sha']
    with zipfile.ZipFile(path / 'artifact.zip') as archive:
        files = [entry for entry in archive.infolist() if not entry.is_dir()]
        assert len({entry.filename for entry in files}) == len(files)
        for entry in files:
            assert not Path(entry.filename).is_absolute() and '..' not in Path(entry.filename).parts
            assert archive.read(entry) == (path / entry.filename).read_bytes()
    job = next(value for value in api['jobs'] if value['name'].endswith('/ ' + host))
    assert job['status'] == 'completed' and job['conclusion'] == 'success'
    assert all(step['conclusion'] in ['success', 'skipped'] for step in job['steps'])
    protocol = read(path / 'protocol.json')
    result = read(path / 'result.json')
    observations = read(path / 'observations.json')
    assert result['complete'] and result['failure'] is None
    assert result['protocol'] == protocol and result['observations'] == observations
    assert protocol['identity'] == identity
    assert protocol['captureReportSha256'] == report_sha
    assert protocol['runnerSha256'] == sha((package / 'run.mjs').read_bytes())
    assert protocol['childSha256'] == sha((package / 'child.mjs').read_bytes())
    assert read(path / 'capture-identity.json') == capture_identity
    assert protocol['node'] == 'v24.22.3' and protocol['v8'] == '13.6.233.17-node.63'
    assert protocol['initialOrder'] == host
    schedule = ['ABC', 'ACB', 'BAC', 'BCA', 'CAB', 'CBA']
    if host == 'BA':
        schedule = [value.translate(str.maketrans('AB', 'BA')) for value in schedule]
    assert protocol['schedule'] == schedule
    assert len(observations) == len(list(path.glob('*-*.command.json'))) == 36
    expected_order = [(mode, block, order, arm) for mode in ['cold', 'warm'] for block, order in enumerate(schedule) for arm in order]
    assert [(value['mode'], value['block'], value['order'], value['arm']) for value in observations] == expected_order
    for value in observations:
        stem = value['resultFile'].removesuffix('.json')
        child = read(path / value['resultFile'])
        command = read(path / (stem + '.command.json'))
        assert command['status'] == 0 and command['signal'] is None and command['error'] is None
        assert command['arguments'][-1] == value['mode']
        assert child['sourceRoot'] == protocol['sourceRoots']['candidate' if value['arm'] == 'B' else 'baseline']
        assert child['sourceRoot'] == command['arguments'][3]
        assert child['complete'] and child['outputDigest'] == value['outputDigest'] == expected_digest
        assert child['sourceSha256'] == identity['candidateSourceSha256' if value['arm'] == 'B' else 'baselineSourceSha256']
        assert child['inputRows'] == 528299 and child['publishedRows'] == 362032
        assert child['callsPerCorpus'] == 12 and child['arenaBytes'] == 26214400
        assert child['node'] == protocol['node'] and child['v8'] == protocol['v8']
        for key in ['fixtureSha256', 'fixtureLockSha256']:
            assert child[key] == protocol[key]
        assert child['parserWasmSha256'] == '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee'
        if capture_hashes is None:
            capture_hashes = child['captureHashes']
        assert child['captureHashes'] == capture_hashes == expected_capture_hashes and len(capture_hashes) == 12
        assert len(child['warmups']) == (0 if value['mode'] == 'cold' else 4)
        assert len(child['observations']) == (1 if value['mode'] == 'cold' else 10)
        for corpus in child['warmups'] + child['observations']:
            assert len(corpus['groups']) == 12
            for key in ['publicationMs', 'cacheMs']:
                assert all(math.isfinite(group[key]) and group[key] >= 0 for group in corpus['groups'])
                assert close(corpus[key], sum(group[key] for group in corpus['groups']))
            assert close(corpus['elapsedMs'], corpus['publicationMs'] + corpus['cacheMs'])
        for key, measure in [('meanMs', 'elapsedMs'), ('meanPublicationMs', 'publicationMs'), ('meanCacheMs', 'cacheMs')]:
            assert close(value[key], child[key])
            assert close(child[key], statistics.fmean(corpus[measure] for corpus in child['observations']))
        log = read(path / (stem + '.log'))
        assert log['complete'] and log['sourceSha256'] == child['sourceSha256']
    assert not (path / 'run.stderr.log').read_text().strip()
    assert result['expectedDigest'] == expected_digest
    summaries = {}
    for mode in ['cold', 'warm']:
        rows = [value for value in observations if value['mode'] == mode]
        summaries[mode] = {'armMedians': {arm: {key: statistics.median(value[key] for value in rows if value['arm'] == arm) for key in ['meanMs', 'meanPublicationMs', 'meanCacheMs']} for arm in 'ABC'}, 'comparisons': {}}
        for left, right in [('B', 'A'), ('B', 'C'), ('C', 'A')]:
            name = left + '/' + right
            pairs = []
            for block in range(6):
                a = next(value for value in rows if value['block'] == block and value['arm'] == left)
                b = next(value for value in rows if value['block'] == block and value['arm'] == right)
                pairs.append({'block': block, 'percent': (a['meanMs'] / b['meanMs'] - 1) * 100, 'ms': a['meanMs'] - b['meanMs'], 'cachePercent': (a['meanCacheMs'] / b['meanCacheMs'] - 1) * 100, 'cacheMs': a['meanCacheMs'] - b['meanCacheMs']})
            stored = result['comparisons'][mode][name]
            assert pairs == stored['pairs']
            for key, measure in [('medianPercent', 'percent'), ('medianMs', 'ms'), ('medianCachePercent', 'cachePercent'), ('medianCacheMs', 'cacheMs')]:
                assert close(stored[key], statistics.median(pair[measure] for pair in pairs))
            assert stored['faster'] == sum(pair['percent'] < 0 for pair in pairs)
            summaries[mode]['comparisons'][name] = {key: val for key, val in stored.items() if key != 'pairs'} | {'cacheFaster': sum(pair['cacheMs'] < 0 for pair in pairs)}
    if host == 'AB':
        tests = re.sub(r'\x1b\[[0-9;]*m', '', (path / 'focused-tests.log').read_text())
        assert 'Tests  187 passed (187)' in tests and 'Test Files  3 passed (3)' in tests
        lint = (path / 'scoped-eslint.log').read_text()
        assert '[WARNING]' in lint and 'pako-inflate.js' in lint
    audit['hosts'][host] = {'artifactId': artifact['id'], 'artifactSha256': sha(zipped), 'verifiedZipFiles': len(files), 'verifiedChildren': len(observations), 'cpuModel': protocol['hostBefore']['cpuModel'], 'checks': 'Passed artifact, exact source/capture/runner receipts, fixed schedules, every command and corpus subtotal, output digests, and independent paired arithmetic.', 'summaries': summaries}
audit['captureHashes'] = capture_hashes
audit['captureReportSha256'] = report_sha
audit['captureReportVerifiedAgainstActualHostedArtifact'] = True
audit['complete'] = True
(root / 'benchmark-setup/metadata-hosted-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
for host, data in audit['hosts'].items():
    print(host, data['cpuModel'], '36 child receipts verified')
    for mode, summary in data['summaries'].items():
        for name, values in summary['comparisons'].items():
            print(mode, name, json.dumps(values))
