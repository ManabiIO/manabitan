import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, writeFile} from 'node:fs/promises'
import {dirname, join, resolve} from 'node:path'
import {fileURLToPath} from 'node:url'
import {crc32, inflateRawSync} from 'node:zlib'

const [inputArgument, outputArgument] = process.argv.slice(2)
assert(inputArgument && outputArgument)
const directory = dirname(fileURLToPath(import.meta.url))
const inputPath = resolve(inputArgument)
const input = JSON.parse(await readFile(inputPath, 'utf8'))
const archive = await readFile(input.archivePath)
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
assert.equal(hash(archive), input.fixture.sha256)
assert.equal(archive.byteLength, input.fixture.sizeBytes)
const modules = {}
for (const kind of ['baseline', 'diagnostic', 'candidate']) {
    const bytes = await readFile(join(directory, kind, 'parser.wasm'))
    const {instance} = await WebAssembly.instantiate(bytes)
    modules[kind] = {wasm: instance.exports, sha256: hash(bytes)}
}
modules.diagnostic.wasm.manabitan_reset_match_counts()
const rows = []
const allOutput = createHash('sha256')
for (const entry of input.entries) {
    const compressed = archive.subarray(entry.offset, entry.offset + entry.compressedBytes)
    const expected = inflateRawSync(compressed)
    assert.equal(expected.byteLength, entry.uncompressedBytes)
    assert.equal(crc32(expected), entry.crc32)
    for (const {wasm} of Object.values(modules)) {
        wasm.wasm_reset_heap()
        const inputPtr = wasm.wasm_alloc(compressed.byteLength)
        const guardedPtr = wasm.wasm_alloc(expected.byteLength + 32)
        const outputPtr = guardedPtr + 16
        const heap = new Uint8Array(wasm.memory.buffer)
        heap.set(compressed, inputPtr)
        heap.fill(0xa5, guardedPtr, outputPtr + expected.byteLength + 16)
        const status = wasm.term_bank_inflate(inputPtr, compressed.byteLength, outputPtr, expected.byteLength)
        assert.equal(status, 0)
        assert.equal(Buffer.compare(heap.subarray(outputPtr, outputPtr + expected.byteLength), expected), 0)
        assert(heap.subarray(guardedPtr, outputPtr).every((byte) => byte === 0xa5))
        assert(heap.subarray(outputPtr + expected.byteLength, outputPtr + expected.byteLength + 16).every((byte) => byte === 0xa5))
    }
    allOutput.update(expected)
    rows.push({name: entry.name, compressedBytes: compressed.byteLength, uncompressedBytes: expected.byteLength, sha256: hash(expected)})
}
const wasm = modules.diagnostic.wasm
const counts = new BigUint64Array(wasm.memory.buffer, wasm.manabitan_get_match_counts(), 2 * 4 * 7 * 2)
const distanceBuckets = ['1..7', '8..15', '16..31', '32+']
const lengthBuckets = ['3..7', '8..15', '16..31', '32..39', '40..63', '64..127', '128..258']
const histogram = []
let matches = 0
let matchBytes = 0
let eligibleMatches = 0
let eligibleMatchBytes = 0
for (let generic = 0; generic < 2; ++generic) {
    for (let distance = 0; distance < 4; ++distance) {
        for (let length = 0; length < 7; ++length) {
            const index = ((generic * 4 + distance) * 7 + length) * 2
            const count = Number(counts[index])
            const bytes = Number(counts[index + 1])
            assert(Number.isSafeInteger(count) && Number.isSafeInteger(bytes))
            matches += count
            matchBytes += bytes
            if (generic === 0 && distance >= 2) { eligibleMatches += count; eligibleMatchBytes += bytes }
            if (count !== 0) { histogram.push({loop: generic === 0 ? 'fast' : 'generic', distance: distanceBuckets[distance], length: lengthBuckets[length], count, bytes}) }
        }
    }
}
const result = {
    complete: true,
    scope: 'Untimed production DEFLATE input reach diagnostic. A counter-instrumented native decoder and unchanged native decoder both exactly match Node zlib for every locked term bank, with output canaries. No timing inference.',
    dictionary: input.dictionary,
    node: process.version,
    v8: process.versions.v8,
    fixtureSha256: input.fixture.sha256,
    inputReceiptSha256: hash(await readFile(inputPath)),
    scriptSha256: hash(await readFile(fileURLToPath(import.meta.url))),
    wasmSha256: Object.fromEntries(Object.entries(modules).map(([kind, {sha256}]) => [kind, sha256])),
    outputSha256: allOutput.digest('hex'),
    bankCount: rows.length,
    sourceBytes: rows.reduce((sum, row) => sum + row.uncompressedBytes, 0),
    matches, matchBytes, eligibleMatches, eligibleMatchBytes,
    eligibleMatchPercent: eligibleMatches / matches * 100,
    eligibleBytePercent: eligibleMatchBytes / matchBytes * 100,
    histogram, rows,
}
await writeFile(resolve(outputArgument), JSON.stringify(result, null, 2) + '\n', {flag: 'wx'})
console.log(JSON.stringify({...result, histogram: undefined, rows: undefined}))
