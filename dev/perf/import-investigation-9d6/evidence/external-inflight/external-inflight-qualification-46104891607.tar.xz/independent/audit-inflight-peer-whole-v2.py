"""Read verified artifact ZIPs; independently bind inputs and reproduce results."""
import hashlib
import io
import json
from pathlib import Path
import random
import statistics
import subprocess
import sys
import tempfile
import zipfile

ROOT = Path('/workspace/scratch/9d6dcf05cf8f')
REPO = ROOT / 'manabitan'
HELPERS = REPO / 'dev/perf/import-memory-20261125-a7f7'
sys.path.insert(0, str(HELPERS))
from qualification_receipts import validate_import_summary, canonicalize_validation, require_matching_receipts
from audit_memory import audit_cell

BASE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CANDIDATE = 'b4d0f54e23f8d4065df33bd40f5ea299bad57c6b'
TOOLING = '154c06d0784c2d9b6d06fb0c22921d59acc95710'
ORDERS = ['ABC', 'BCA', 'CAB', 'ACB', 'BAC', 'CBA', 'CBA', 'BAC', 'ACB', 'CAB', 'BCA', 'ABC']
HARNESS = 'test/chromium/extension-two-dictionary-import.e2e.js'
sha = lambda b: hashlib.sha256(b).hexdigest()
git_cache = {}


def git_bytes(commit, path):
    key = (commit, path)
    if key not in git_cache:
        git_cache[key] = subprocess.check_output(['git', '-C', REPO, 'show', f'{commit}:{path}'])
    return git_cache[key]


def statistics_for(rows, numerator, denominator):
    ratios = [r[numerator] / r[denominator] for r in rows]
    random_source = random.Random(20261127)
    boot = sorted(statistics.median(random_source.choices(ratios, k=12)) for _ in range(10000))
    return {
        'pairs': 12,
        'pairedChangePercent': [(r - 1) * 100 for r in ratios],
        'medianPairedChangePercent': (statistics.median(ratios) - 1) * 100,
        'equalWorkChangePercent': (sum(r[numerator] for r in rows) / sum(r[denominator] for r in rows) - 1) * 100,
        'descriptiveBootstrap95Percent': [(boot[i] - 1) * 100 for i in [249, 9749]],
        'fasterPairs': sum(r < 1 for r in ratios),
    }


def audit(directory):
    directory = Path(directory)
    download = json.loads((directory / 'download-receipt.json').read_text())
    artifact = download['artifact']
    archive = Path(download['localZip'])
    with archive.open('rb') as f:
        assert hashlib.file_digest(f, 'sha256').hexdigest() == artifact['digest'].split(':')[1]
    assert archive.stat().st_size == artifact['size_in_bytes']
    assert artifact['workflow_run']['id'] == 46104891607
    assert artifact['workflow_run']['head_sha'] == TOOLING
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        assert len(names) == len(set(names))
        assert all(not n.startswith('/') and '..' not in Path(n).parts for n in names)
        read = lambda name: json.loads(z.read(name))
        plan = read('registered-plan.json')
        protocol = read('tooling/protocol.json')
        identity = read('tooling-identity.json')
        source = read('source-identities.json')
        observations = read('observations.json')
        analysis = read('analysis.json')
        commands = read('commands.json')
        assert identity['sha'] == TOOLING
        assert sha(z.read('tooling/run.py')) == identity['driverSha256']
        assert sha(z.read('tooling/protocol.json')) == identity['protocolSha256']
        for file in names:
            if file.startswith('tooling/') and not file.endswith('/'):
                relative = 'dev/perf/import-inflight-study-20261128-4990/' + file.split('/', 1)[1]
                assert z.read(file) == git_bytes(TOOLING, relative), file
            if file.startswith('receipt-memory-helpers/') and not file.endswith('/'):
                relative = 'dev/perf/import-memory-20261125-a7f7/' + file.split('/', 1)[1]
                assert z.read(file) == git_bytes(TOOLING, relative), file
                if file.endswith('.py'):
                    assert z.read(file) == (REPO / relative).read_bytes(), file
        assert z.read('workflow.yml') == git_bytes(TOOLING, '.github/workflows/import-inflight-study-4990.yml')
        assert all(c.get('returnCode') == 0 and 'error' not in c for c in commands)
        qualification_failure = read('failure.json') if 'failure.json' in names else None
        assert analysis['acquisitionComplete'] and analysis['memoryErrors'] == []
        if qualification_failure is not None:
            assert qualification_failure['message'] == 'All timing retained; separate memory qualification did not pass'
            assert qualification_failure['type'] == 'RuntimeError'
            assert qualification_failure['completedObservations'] == 39
            assert qualification_failure['retried'] is False
            assert qualification_failure['stage'] == 'profile'
            assert analysis['memoryPassed'] is False
        else:
            assert analysis['memoryPassed'] is True
        assert read('memory/semantic-failures.json') == []
        assert protocol['baseline'] == plan['baseline'] == BASE
        assert protocol['candidate'] == plan['candidate'] == CANDIDATE
        assert protocol['candidateTree'] == source['arms']['B']['tree'] == '9d096d8cb88d081d3ceaa85c94c97003f459819e'
        dictionary, replication = plan['dictionary'], plan['replication']
        assert replication in (1, 2)
        fixture_data = git_bytes(BASE, 'test/perf/dictionaries.lock.json')
        assert sha(fixture_data) == plan['fixtureLockSha256']
        fixture = json.loads(fixture_data)['dictionaries'][dictionary]
        packages = {}
        for arm, commit in [('A', BASE), ('B', CANDIDATE)]:
            product = z.read(f'package-{arm}.zip')
            arm_source = source['arms'][arm]
            assert arm_source['sha'] == commit
            assert sha(product) == arm_source['packageSha256']
            with zipfile.ZipFile(io.BytesIO(product)) as product_zip:
                assert len(product_zip.namelist()) == len(set(product_zip.namelist()))
                entries = {i.filename: sha(product_zip.read(i)) for i in product_zip.infolist() if not i.is_dir()}
                assert entries == arm_source['entries']
                assert product_zip.read('js/dictionary/dictionary-database.js') == git_bytes(commit, 'ext/js/dictionary/dictionary-database.js')
            packages[arm] = entries
            for relative, digest in arm_source['sourceHashes'].items():
                if relative.startswith('builds/'):
                    assert digest == arm_source['packageSha256']
                else:
                    assert sha(git_bytes(commit, relative)) == digest
        assert packages['A'].keys() == packages['B'].keys()
        changes = [k for k in packages['A'] if packages['A'][k] != packages['B'][k]]
        assert changes == ['js/dictionary/dictionary-database.js']
        assert source['arms']['A']['nativeManifest'] == source['arms']['B']['nativeManifest']
        orders = ORDERS if replication == 1 else [order[::-1] for order in ORDERS]
        expected = [{'id': 'warmup-' + arm, 'kind': 'warmup', 'block': 0, 'arm': arm} for arm in ('ABC' if replication == 1 else 'CBA')]
        expected += [{'id': f'block-{i:02d}-{arm}', 'kind': 'timing', 'block': i, 'arm': arm} for i, order in enumerate(orders, 1) for arm in order]
        assert plan['schedule'] == expected and len(observations) == 39
        assert [{k: row[k] for k in ['id', 'kind', 'block', 'arm']} for row in observations] == expected
        reference = None
        full_reference = None
        validated = []
        durations = {i: {} for i in range(1, 13)}
        first_lookup = {i: {} for i in range(1, 13)}
        warm_lookup = {i: {} for i in range(1, 13)}
        cases = [(row['id'], 'B' if row['arm'] == 'B' else 'A', 'sample', False, row) for row in observations]
        cases += [(f'exhaustive-media-{arm}', arm, 'all', False, None) for arm in 'AB']
        memory_plan = read('memory/plan.json')
        assert memory_plan['schedule'] == plan['memorySchedule']
        cases += [('memory/' + row['name'], row['arm'], 'sample', True, None) for row in memory_plan['schedule']]
        overlay = z.read('memory/harness-instrumented.js')
        assert sha(overlay) == memory_plan['overlaySha256']
        assert z.read('memory/harness-original.js') == git_bytes(BASE, HARNESS)
        for path, arm, media, dirty, observation in cases:
            summary, report = read(path + '/summary.json'), read(path + '/run-1.json')
            source_hashes = dict(source['arms'][arm]['sourceHashes'])
            if dirty:
                source_hashes[HARNESS] = sha(overlay)
            receipt = validate_import_summary(summary, report, dictionary=dictionary, fixture=fixture,
                source_sha=source['arms'][arm]['sha'], package_sha256=source['arms'][arm]['packageSha256'],
                browser_version='153.0.8010.12', source_hashes=source_hashes, source_dirty=dirty,
                media_check=media, vndb_sah_allocation_units=plan['vndbSahAllocationUnits'])
            assert receipt == read(path + '/canonical-receipt.json')
            if reference is None:
                reference = receipt
            require_matching_receipts(reference, receipt, compare_media=media == 'sample')
            if media == 'all':
                if full_reference is None:
                    full_reference = receipt
                require_matching_receipts(full_reference, receipt)
            if observation is not None:
                total = summary['runs'][0]['totalImportMs']
                assert total == observation['totalImportMs']
                if observation['kind'] == 'timing':
                    block, label = observation['block'], observation['arm']
                    durations[block][label] = total
                    lookups = report['benchmark']['validation']['lookup']['observations']
                    first_lookup[block][label] = sum(row['elapsedMs'] for row in lookups if row['pass'] == 0)
                    warm_lookup[block][label] = sum(row['elapsedMs'] for row in lookups if row['pass'] > 0) / 5
            validated.append(path)
        for arm in 'AB':
            path = 'trace-' + arm
            summary, report = read(path + '/summary.json'), read(path + '/run-1.json')
            assert report['status'] == 'success' and report['skippedVerification'] is False
            assert summary['traceEnabled'] and not summary['authoritativeTiming']
            assert summary['gitSha'] == source['arms'][arm]['sha']
            assert report['packageSha256'] == source['arms'][arm]['packageSha256']
            assert report['benchmark']['validation'] == summary['runs'][0]['validation']
            validation = canonicalize_validation(report['benchmark']['validation'], dictionary=dictionary,
                fixture=fixture, media_check='sample', vndb_sah_allocation_units=plan['vndbSahAllocationUnits'])
            media = validation.pop('media')
            assert validation == reference['common']['validation'] and media == reference['media']
            validated.append(path)
        assert len(validated) == 47
        assert sorted(path + '/run-1.json' for path in validated) == sorted(n for n in names if n.endswith('/run-1.json'))
        metrics = {}
        for key in ['B/A', 'B/C', 'C/A']:
            stats = statistics_for([durations[i] for i in range(1, 13)], key[0], key[2])
            assert stats == analysis[key], key
            metrics[key] = stats
        with tempfile.TemporaryDirectory(prefix='audit-memory-', dir=archive.parent) as temporary:
            tmp = Path(temporary)
            for file in names:
                if file.startswith('memory/') and (file.endswith('.json') or file.endswith('.jsonl')):
                    target = tmp / file.removeprefix('memory/')
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_bytes(z.read(file))
            memory = audit_cell(tmp)
            assert memory == read('memory/memory-audit.json')
        assert memory['passesProspectiveMemoryScreen'] == analysis['memoryPassed']
        contents = {i.filename: {'bytes': i.file_size, 'sha256': sha(z.read(i))} for i in z.infolist() if not i.is_dir()}
        (directory / 'artifact-files.json').write_text(json.dumps(contents, indent=2) + '\n')
        result = {
            'complete': True, 'qualificationPassed': analysis['memoryPassed'],
            'auditor': {'path': Path(__file__).name, 'sha256': sha(Path(__file__).read_bytes())},
            'artifactId': artifact['id'], 'dictionary': dictionary, 'replication': replication,
            'scope': 'Independent artifact identity/complete package/source binding, fixed schedule and all semantic receipts; paired statistics reproduced from raw summaries; memory recomputed from original scans using the unchanged source-bound auditor. No new performance measurements.',
            'source': {'baseline': BASE, 'candidate': CANDIDATE, 'tooling': TOOLING, 'candidateDatabaseSha256': packages['B']['js/dictionary/dictionary-database.js'], 'changedPackageEntries': changes},
            'commands': len(commands), 'commandFailures': 0, 'validatedReports': len(validated),
            'authoritativeTimingReports': 36, 'warmups': 3, 'exhaustiveMediaReports': 2, 'memoryReports': 4, 'diagnosticTraces': 2,
            'metrics': metrics, 'memory': memory,
            'memoryObservationCoverage': [{key: row[key] for key in ['name', 'arm', 'pair', 'qualifiedForWholeTreePss', 'qualificationFailures', 'maximumCoveredSampleGapMs', 'maxSampledPssKiB', 'maxSampledPrivateKiB', 'allObservedSampleCount']} for row in read('memory/observations.json')],
            'semanticDigestSha256': reference['common']['validation']['outputDigestSha256'],
            'storageBytes': reference['common']['validation']['storage']['bytes'],
            'exhaustiveMedia': full_reference['media'],
            'lookupDiagnostics': {kind: {key: statistics_for([values[i] for i in range(1, 13)], key[0], key[2]) for key in ['B/A', 'B/C', 'C/A']} for kind, values in [('firstPassSum', first_lookup), ('meanWarmPassSum', warm_lookup)]},
            'timingRows': [durations[i] for i in range(1, 13)],
            'host': read('block-01-A/summary.json')['hostEnvironment'],
            'correctnessJob': 'Separate full unit/type/build/lint job is not inferred from this artifact; its completion must be checked independently.',
            'failures': [] if qualification_failure is None else [qualification_failure],
        }
        (directory / 'independent-audit.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({k: result[k] for k in ['artifactId', 'dictionary', 'replication', 'commands', 'validatedReports', 'metrics', 'memory']}, indent=2))


for argument in sys.argv[1:]:
    audit(argument)
