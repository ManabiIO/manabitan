#!/usr/bin/env python3
"""Fetch a temporary artifact URL without logging it, then verify before extraction."""
import hashlib
import json
import pathlib
import stat
import sys
import urllib.request
import zipfile

url, metadata_json, output_root = sys.argv[1:4]
selected_file = sys.argv[4] if len(sys.argv) > 4 else None
metadata = json.loads(metadata_json)
root = pathlib.Path(output_root)
root.mkdir(parents=True, exist_ok=True)
archive = root / f"artifact-{metadata['id']}.zip"
output = root / f"artifact-{metadata['id']}"
assert not archive.exists() and not output.exists()
assert metadata['expired'] is False
assert metadata['digest'].startswith('sha256:')
digest = hashlib.sha256()
count = 0
try:
    with urllib.request.urlopen(url, timeout=60) as response, archive.open('xb') as target:
        while True:
            block = response.read(1048576)
            if not block:
                break
            count += len(block)
            assert count <= metadata['size_in_bytes']
            digest.update(block)
            target.write(block)
except Exception as error:
    print(type(error).__name__ + ': artifact download failed; temporary URL omitted')
    raise SystemExit(1)
assert count == metadata['size_in_bytes'], (count, metadata['size_in_bytes'])
assert digest.hexdigest() == metadata['digest'].removeprefix('sha256:'), digest.hexdigest()
with zipfile.ZipFile(archive) as zipped:
    entries = zipped.infolist()
    assert len(entries) < 1000
    assert sum(entry.file_size for entry in entries) < 50 * 1024 * 1024
    names = set()
    for entry in entries:
        path = pathlib.PurePosixPath(entry.filename)
        assert entry.filename not in names
        names.add(entry.filename)
        assert not path.is_absolute() and '..' not in path.parts and '\\' not in entry.filename
        assert not stat.S_ISLNK(entry.external_attr >> 16)
    assert zipped.testzip() is None
    output.mkdir()
    if selected_file is None:
        zipped.extractall(output)
    else:
        assert selected_file in names
        zipped.extract(selected_file, output)
receipt = {
    'artifact': metadata,
    'downloadedBytes': count,
    'downloadSha256': digest.hexdigest(),
    'selectedFile': selected_file,
    'files': {str(file.relative_to(output)): hashlib.sha256(file.read_bytes()).hexdigest()
              for file in sorted(output.rglob('*')) if file.is_file()},
}
(root / f"artifact-{metadata['id']}-receipt.json").write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'artifactId': metadata['id'], 'bytes': count, 'sha256': digest.hexdigest(),
                  'members': len(names), 'output': str(output)}, indent=2))
