"""Review recovered packaging inputs without materializing or measuring anything."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import tarfile
import zipfile

ROOT = Path('/home/agent/manabitan-guarded-hosted-9d6')
PACKAGE = ROOT / 'recovery-packaging'
WORKSPACE = Path('/workspace/scratch/9d6dcf05cf8f')
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_bytes())
expected = {
    'materialize.py': '840aef67289b10d77cbafedd6112666504c7bb3ae7e86a12e1d7490f73380aaf',
    'layout.json': 'efb74076b76ef7c0f57de2a13795215dd5b7fdf8d4afe4132a1661fa40ad57a8',
    'PLAN.md': '9e92c0f2e855ddb5319aa43ad86291b72da536ace25fc60e797e16c498969540',
}
for name, digest in expected.items():
    assert sha((PACKAGE / name).read_bytes()) == digest
ns = {'__name__': 'review_only', '__file__': str(PACKAGE / 'materialize.py')}
exec(compile((PACKAGE / 'materialize.py').read_bytes(), ns['__file__'], 'exec'), ns)
layout = read(PACKAGE / 'layout.json')
ready = read(PACKAGE / 'ready-inputs.json')
assert ready['materializerSha256'] == expected['materialize.py'] and ready['layoutSha256'] == expected['layout.json'] and ready['planSha256'] == expected['PLAN.md']
manifest_path = ROOT / 'original-recovery-manifest.json'
assert sha(manifest_path.read_bytes()) == '2670b80fc7944cd3f1b6d973cc2ddc8770e97f6a0a52cf9a9a7501175e57a578'
manifest = read(manifest_path)
assert (layout['runId'], layout['attempt'], layout['baselineCommit'], layout['productCommit'], layout['toolingCommit']) == (ns['RUN'], ns['ATTEMPT'], ns['BASELINE'], ns['CANDIDATE'], ns['TOOLING'])
assert (manifest['run'], manifest['attempt'], manifest['baseline'], manifest['candidate'], manifest['tooling']) == (ns['RUN'], ns['ATTEMPT'], ns['BASELINE'], ns['CANDIDATE'], ns['TOOLING'])
assert layout['packageEntry'] == ns['PACKAGE_ENTRY'] == 'lib/zstd.wasm'
assert layout['productSourcePath'] == ns['PRODUCT_SOURCE'] == 'dev/data/zstd-simd.wasm'
assert len(layout['cells']) == 6 and {(r['dictionary'], r['order']) for r in layout['cells']} == {(d, o) for d in ('jmdict', 'jitendex', 'vndb') for o in ('AB', 'BA')}
found = ns['discover'](layout)
assert len(found) == len(manifest['artifacts']) == len(manifest['originalArtifactMetadata']) == 8
original = {r['id']: r for r in manifest['originalArtifactMetadata']}
artifacts = {r['id']: r for r in manifest['artifacts']}
assert set(original) == set(artifacts) == {int(path.name) for path in found.values()}

support = ns['Selection']()
helpers = {}
for name in ns['HELPERS']:
    path = ns['HELPER_DIR'] + '/' + name
    data = ns['git_bytes'](ns['BASELINE'], path)
    assert (ns['REPOSITORY'] / path).read_bytes() == data
    helpers[name] = sha(data)
for row in layout['supportRecords']:
    support.source(row['archivePath'], Path(row['sourcePath']), row)
assert len(layout['supportRecords']) == 26
for row in layout['gitSupport']:
    data = ns['git_bytes'](row['commit'], row['path'])
    assert len(data) == row['bytes'] and sha(data) == row['sha256'] and ns['git_blob'](data) == row['gitBlobSha1']
    support.generated(row['archivePath'], data, row['commit'] + ':' + row['path'])
assert len(layout['gitSupport']) == 14
assert ns['file_identity'](Path(layout['auditor']['sourcePath']))['sha256'] == ns['AUDITOR_SHA'] == '8f5dcacc42616d2198d3f1d6ab4b7ec84e560c7b12052458381b459b5783bd8e'
assert sha((WORKSPACE / 'benchmark-setup/diagnose-complete-import-phases.py').read_bytes()) == '718c5d424db9e349dbd7301139570dd06e0ca80bf646f0579314fadbf9b30154'
native = ns['check_support_audit'](layout, found)
assert native['reviewerSourceSha256'] == sha((ROOT / 'recovered-native-checks/review.py').read_bytes()) == 'e9be7849aa31b252d7ed80758f794456cb965e736c4f7cf1828da60dfdd0f7cc'
assert native['priorAudit']['bytesRecovered'] is False and native['discrepancies'] == []

restoration = read(PACKAGE / 'proof-restoration.json')
proof_archive = WORKSPACE / 'metadata-experiments/builds/perf/evidence-inventory-9d6/archives/codec-v2-and-guarded-proof.tar.gz'
assert len(proof_archive.read_bytes()) == restoration['archiveBytes'] == 247023
assert sha(proof_archive.read_bytes()) == restoration['archiveSha256'] == '19daffeaa033adef237c3a24d96998b3d0595510934137e0bfe2fb949470293d'
with tarfile.open(proof_archive, 'r:gz') as archive:
    for row in restoration['files']:
        data = archive.extractfile(row['archiveMember']).read()
        assert data == Path(row['restoredPath']).read_bytes()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
assert len(restoration['files']) == 5

outer_maps = []
for name, directory in found.items():
    identifier = int(directory.name)
    host = artifacts[identifier]['kind'] == 'complete-import'
    selection = ns['Selection']()
    outer = ns['verify_outer'](directory, name, selection, omit=ns['OMIT'] if host else ())
    assert outer['artifact'] == original[identifier]
    assert outer['zipSha256'] == artifacts[identifier]['digest'][7:] and outer['zipBytes'] == artifacts[identifier]['size_in_bytes']
    omitted = [r['path'] for r in outer['members'] if r['retainedAs'].startswith('payload omitted')]
    assert set(omitted) == ({'package-A.zip', 'package-B.zip'} if host else set())
    outer_maps.append({'id': identifier, 'name': name, 'bytes': outer['zipBytes'], 'sha256': outer['zipSha256'], 'members': len(outer['members']), 'selectionEntries': len(selection.entries)})

ready_by_cell = {(r['dictionary'], r['order']): r for r in ready['cells']}
cells = []
for cell in layout['cells']:
    instruction = ready_by_cell[cell['dictionary'], cell['order']]
    directory = found[cell['expectedArtifactName']]
    assert int(directory.name) == cell['currentlyKnownArtifactId'] == instruction['artifactId']
    assert cell['primaryAudit'] == instruction['audit'] == 'root-audit.json'
    audit_path = directory / instruction['audit']
    assert sha(audit_path.read_bytes()) == instruction['auditSha256']
    audit = ns['check_audit'](audit_path, cell, helpers)
    identities = read(directory / 'files/source-identities.json')
    assert identities['changedPackageEntries'] == ['lib/zstd.wasm']
    assert set(identities['arms']['A']['entries']) == set(identities['arms']['B']['entries'])
    assert [name for name in sorted(identities['arms']['A']['entries']) if identities['arms']['A']['entries'][name] != identities['arms']['B']['entries'][name]] == ['lib/zstd.wasm']
    for arm, commit in [('A', ns['BASELINE']), ('B', ns['CANDIDATE'])]:
        assert identities['arms'][arm]['sha'] == commit
        data = ns['git_bytes'](commit, 'dev/data/zstd-simd.wasm')
        with zipfile.ZipFile(directory / f'files/package-{arm}.zip') as archive:
            assert archive.read('lib/zstd.wasm') == data
        assert identities['arms'][arm]['entries']['lib/zstd.wasm'] == sha(data)
    sidecars = ns['Selection']()
    for path in sorted(directory.iterdir()):
        if path.name in ('artifact.zip', 'download-receipt.json', 'files'):
            continue
        section = 'exploratory' if 'phase' in path.name else 'audit'
        sidecars.source(section + '/' + path.name, path)
    assert {name.split('/', 1)[1] for name in sidecars.entries if name.startswith('exploratory/')} == set(instruction['phaseFiles'])
    observations = read(directory / 'files/memory/observations.json')
    assert len(observations) == 4
    failures = [r for r in observations if not r['qualifiedForWholeTreePss']]
    for row in failures:
        assert row['qualificationFailures'] == ['covered-import-scan-gap-over-250ms']
        assert row['maxSampledPssKiB'] is None and row['maxSampledPrivateKiB'] is None
    semantic_failures = read(directory / 'files/memory/semantic-failures.json')
    assert semantic_failures == []
    cells.append({'dictionary': cell['dictionary'], 'order': cell['order'], 'artifactId': int(directory.name), 'auditSha256': instruction['auditSha256'],
                  'observationsValidated': audit['observationsValidated'], 'rawMemoryScans': audit['memory']['rawScanCount'], 'memoryPassed': audit['memory']['passesProspectiveMemoryScreen'],
                  'unqualifiedMemory': [{'name': r['name'], 'gapMs': r['maximumCoveredSampleGapMs'], 'qualifiedPss': r['maxSampledPssKiB'], 'qualifiedPrivate': r['maxSampledPrivateKiB']} for r in failures],
                  'semanticFailures': semantic_failures, 'sidecars': sidecars.rows()})

failed_jobs = []
jobs = {r['id']: r for r in manifest['jobs']}
for identifier, job_id in [(15251679069, 140869936640), (15252367104, 140869936618), (15252558708, 140869936656)]:
    directory = ROOT / str(identifier)
    receipt_path = directory / f'failed-job-{job_id}.receipt.json'
    receipt = read(receipt_path)
    data = (directory / receipt['logFile']).read_bytes()
    assert (receipt['runId'], receipt['runAttempt'], receipt['toolingHead'], receipt['productCandidate'], receipt['artifactId'], receipt['jobId']) == (ns['RUN'], 1, ns['TOOLING'], ns['CANDIDATE'], identifier, job_id)
    assert receipt['jobMetadata'] == jobs[job_id] and jobs[job_id]['conclusion'] == 'failure'
    assert len(data) == receipt['decodedUtf8Bytes'] and sha(data) == receipt['sha256'] and len(data.decode('utf-8')) == receipt['decodedCharacters']
    assert 'failures/' + receipt['logFile'] in support.entries and 'failures/' + receipt_path.name in support.entries
    failed_jobs.append({'id': job_id, 'artifactId': identifier, 'bytes': len(data), 'sha256': sha(data), 'receiptSha256': sha(receipt_path.read_bytes())})
readiness = ns['readiness'](layout, found)
assert readiness['ready'] is True
for name, digest in expected.items():
    assert sha((PACKAGE / name).read_bytes()) == digest
context = read(PACKAGE / 'recovery-context.json')
assert context['materializer']['exactOriginalBytesRecovered'] is True
assert all(r['bytesRecovered'] is False for r in context['unavailablePriorRecords'])
assert not (PACKAGE / 'completed').exists()
jm_review_path = ROOT / 'jmdict-review.json'
assert sha(jm_review_path.read_bytes()) == '56b0d018a7cb28c423b025bbdcd037c0856a47d47c0e68678be41fc6f3cb23c3'

result = {'complete': True, 'reviewedAtUtc': datetime.now(timezone.utc).isoformat(),
          'scope': 'Independent read-only recovery input review. No materialization, benchmark, import, build or native proof execution.',
          'sourceIdentities': expected, 'materializerApproval': 'Exact previously reviewed bytes; input layout newly reviewed.',
          'run': ns['RUN'], 'attempt': 1, 'baseline': ns['BASELINE'], 'candidate': ns['CANDIDATE'], 'tooling': ns['TOOLING'],
          'recoveryManifestSha256': sha(manifest_path.read_bytes()), 'readiness': readiness,
          'originalArtifactsVerified': outer_maps, 'cells': cells, 'failedJobsRetained': failed_jobs,
          'nativeChecksAuditSha256': layout['support']['independentAudit']['sha256'],
          'pinnedSupportRecordsVerified': 26, 'gitSupportSourcesVerified': 14, 'baselineHelpers': helpers,
          'publishedCorrectnessReceiptsRecoveredExactly': 5, 'canonicalReceipts': sum(c['observationsValidated'] for c in cells),
          'authoritativeTimedImports': 192, 'excludedOrdinaryWarmups': 24, 'exhaustiveMediaImports': 12, 'separateMemoryImports': 24,
          'rawMemoryScans': sum(c['rawMemoryScans'] for c in cells), 'unqualifiedMemoryObservations': sum(len(c['unqualifiedMemory']) for c in cells),
          'reviewFindings': [
              'All eight original outer ZIP sizes, hashes, CRC/member maps and extracted bytes verify against frozen original metadata.',
              'All six fresh root audits bind exact original raw statistics, status, memory result and baseline helper hashes; raw observations are unchanged.',
              'All twelve release WASM entries match their Git source and the recorded sole package difference; full inner maps remain enforced by the unchanged materializer.',
              'All three complete failed-job logs and original job identities are mandatory pinned support and retained host sidecars.',
              'All six phase diagnostics and logs remain exploratory sidecars; they never alter endpoint summaries.',
              'Every native/checks payload remains included; recovered native proof reference bytes match the published archive exactly.',
              'Lost private notes are declared unavailable; fresh recovery receipts are not represented as original byte-identical notes.',
              'Original source/layout release gates, no-credential scan, deterministic XZ and immutable-output verification remain unchanged.'
          ],
          'additionalReleaseSupport': {'jmdictReview': {'path': str(jm_review_path), 'bytes': jm_review_path.stat().st_size, 'sha256': sha(jm_review_path.read_bytes())}},
          'decision': 'No input or source blocker. Ready for root release with final no-PR disposition; this review does not create archives or promote the product.',
          'reviewerSourceSha256': sha(Path(__file__).read_bytes())}
output = Path(__file__).with_suffix('.json')
with output.open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps({'complete': True, 'receipt': str(output), 'sha256': sha(output.read_bytes()), 'artifacts': len(outer_maps), 'cells': len(cells), 'rawMemoryScans': result['rawMemoryScans'], 'archivesCreated': False}, indent=2))
