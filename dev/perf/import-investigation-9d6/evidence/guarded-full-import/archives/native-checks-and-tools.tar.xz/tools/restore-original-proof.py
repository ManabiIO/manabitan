"""Recover existing correctness receipts from a published archive; execute no proof."""
from pathlib import Path
import hashlib
import json
import tarfile

ROOT = Path('/home/agent/manabitan-guarded-hosted-9d6')
ARCHIVE = Path('/workspace/scratch/9d6dcf05cf8f/metadata-experiments/builds/perf/evidence-inventory-9d6/archives/codec-v2-and-guarded-proof.tar.gz')
EXPECTED = '19daffeaa033adef237c3a24d96998b3d0595510934137e0bfe2fb949470293d'
MANIFEST = Path('/workspace/scratch/9d6dcf05cf8f/compression-probe/count16-guarded/publication-manifest.json')
sha = lambda data: hashlib.sha256(data).hexdigest()
assert ARCHIVE.stat().st_size == 247023 and sha(ARCHIVE.read_bytes()) == EXPECTED
assert sha(MANIFEST.read_bytes()) == '8f8f3bf50be4244cd9b4b3b7b8322c1712889ebb7414a7a0c8ae7cad33528969'
manifest = json.loads(MANIFEST.read_bytes())
output = ROOT / 'restored-local-proof'
output.mkdir()
records = []
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    for row in manifest['receipts']:
        name = row['path'].split('/guarded-verification-01/')[1]
        member = archive.getmember('guarded-verification-01/' + name)
        assert member.isfile()
        data = archive.extractfile(member).read()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        target = output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream: stream.write(data)
        records.append({'archiveMember': member.name, 'restoredPath': str(target), 'bytes': len(data), 'sha256': sha(data)})
receipt = {'complete': True, 'scope': 'Restore exact preexisting native correctness receipts only; no build, proof, import or timing executed.',
           'archiveCommit': 'd602e1b003811b0ebac63e9ef2c8019f430aea21', 'archiveSha256': EXPECTED,
           'archiveBytes': 247023, 'publicationManifestSha256': sha(MANIFEST.read_bytes()), 'files': records,
           'restorerSourceSha256': sha(Path(__file__).read_bytes())}
(ROOT/'recovery-packaging/proof-restoration.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({'complete':True,'receiptsRestored':len(records)},indent=2))
