"""Describe existing ordinary phase timers without rerunning or adjusting imports."""

import argparse
import hashlib
import json
from pathlib import Path
import statistics


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('evidence', type=Path)
parser.add_argument('output', type=Path)
args = parser.parse_args()
root = args.evidence.resolve()
observations = json.loads((root / 'observations.json').read_text())
metrics = [
    'dedupRecentSourceCacheMs', 'contentMetadataPublishMs', 'contentMetadataIndexPublishMs',
    'dedupCanonicalScanMs', 'contentCompressMs', 'contentOpfsAppendMs',
    'termRecordValidationMs', 'parserParallelWorkerWallMs',
]
rows = []
source_hashes = {}
for observation in observations:
    path = root / observation['id'] / 'summary.json'
    data = path.read_bytes()
    source_hashes[observation['id']] = hashlib.sha256(data).hexdigest()
    summary = json.loads(data)
    assert summary['authoritativeTiming'] is True and summary['traceEnabled'] is False
    run = summary['runs'][0]
    phases = [phase for phase in run['importDebug']['importerPhaseTimings']
              if phase['phase'].startswith('term-file-fast-path:')]
    assert len(phases) == 1, 'This diagnostic expects one complete native term-file phase'
    values = {key: phases[0]['details'][key] for key in metrics}
    for label, key in [('Step 4 of 5', 'step4Ms'), ('Step 5 of 5', 'finalizingMs')]:
        matches = [step for step in run['stepTimingSummary']['aggregateByStep'] if step['stepDisplay'] == label]
        assert len(matches) == 1
        values[key] = matches[0]['totalElapsedMs']
    rows.append({**observation, 'metrics': values})

comparisons = {}
for kind, right in [('candidate', 'B'), ('control', 'C')]:
    chosen = [row for row in rows if row['kind'] == kind]
    pairs = []
    for pair in sorted({row['pair'] for row in chosen}):
        entries = [row for row in chosen if row['pair'] == pair]
        assert len(entries) == 2 and {entry['arm'] for entry in entries} == {'A', right}
        values = {entry['arm']: entry['metrics'] for entry in entries}
        pairs.append({key: {'A': values['A'][key], right: values[right][key]}
                      for key in chosen[0]['metrics']})
    comparisons[kind] = {
        key: {
            'medianBaselineMs': statistics.median(pair[key]['A'] for pair in pairs),
            'medianComparisonMs': statistics.median(pair[key][right] for pair in pairs),
            'medianSavedMs': statistics.median(pair[key]['A'] - pair[key][right] for pair in pairs),
            'fasterPairs': sum(pair[key][right] < pair[key]['A'] for pair in pairs),
        }
        for key in pairs[0]
    }

result = {
    'scope': 'Exploratory existing unprofiled phase timers. Aggregates can overlap; these are not '
             'additional performance cohorts, CPU measurements, or adjusted import timings. '
             'No observation is excluded.',
    'scriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'summarySha256': source_hashes,
    'rows': rows,
    'summary': comparisons,
}
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'observations': len(rows), 'summary': comparisons}, indent=2))
