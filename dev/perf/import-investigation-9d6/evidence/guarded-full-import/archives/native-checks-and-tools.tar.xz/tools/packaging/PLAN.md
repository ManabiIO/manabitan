# Guarded hosted qualification: recovered evidence inputs

The packager source is an exact reconstruction of the previously reviewed 38,570-byte implementation: SHA256 `840aef67289b10d77cbafedd6112666504c7bb3ae7e86a12e1d7490f73380aaf`. It was reconstructed from the published cache materializer and the recorded guarded port, then independently rehashed. This layout and plan are new recovery records; they do not claim the lost `8128c7f9...` layout or `fb57eae5...` plan bytes were restored.

## Frozen study

The source study remains run `46109596112`, attempt `1`, baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`, product `20e4af5897013ee76dfd4bed1ee6c383d71ba8e4`, and tooling `8936a15e8a8a2cf53cb10849181a6268c656a7bf`. The sole runtime package difference is `lib/zstd.wasm`, verified against Git source `dev/data/zstd-simd.wasm`. The corrected asset remains SHA256 `13890c7e75e7a2ff5fa00bd65f1e518e15f545da85154719be6a2eaa2a773a22`.

All eight original artifacts are reacquired using their frozen IDs, names, sizes, hashes and source/run bindings. New download receipts and offline audits identify recovery explicitly. The original import observations, memory scans and native/checks results are unchanged. No import, benchmark, native proof, build, profiling or timing is rerun. The proposed cloud recovery workflow was cancelled before any draft commit, branch movement or activation.

The original local native correctness receipts were recovered exactly from the already-published proof archive at commit `d602e1b003811b0ebac63e9ef2c8019f430aea21`. The prior private native/checks audit JSON was lost; its known hash is retained as provenance only. A new source-bound offline audit verifies the same original 23 native/checks files and exact Git-bound production/probe identities. The separately published inconclusive local codec timing appendix remains unchanged and separate.

## Complete preservation

Six deterministic per-host XZ archives retain every original extracted file except the two release ZIP payloads. Each whole ZIP, every member and every source/package identity is verified before those payloads are omitted. Full outer and inner member maps remain. All raw report formats, controls, warmups, tails, plans, canonical receipts, host snapshots, harnesses, memory scans and markers are retained without filtering.

All regenerated `root-audit.json` files and logs remain host sidecars. Every phase diagnostic is labelled exploratory; it does not replace or adjust endpoint timing. All three failed-job logs and full identity receipts remain both host sidecars and mandatory hash-bound support inputs. The duplication makes their complete preservation explicit. Sampler-coverage failures, semantic failure arrays and null qualified maxima remain exactly recorded; missing qualified measurements are not presented as measured memory growth.

Each host retains 42 canonical receipts: 36 ordinary observations, two exhaustive-media imports and four separate memory imports. The ordinary observations include four excluded warmups and 32 authoritative timed imports. Across six hosts this is 252 receipts, 192 timed imports, 24 warmups, 12 media imports and 24 memory imports.

The separate `native-checks-and-tools.tar.xz` archive retains every native/checks artifact file, all rebuilt assets and three boundary probes, the new offline audit/source/log, exact published correctness reference receipts, and the old unguarded implementation's 768 traps and one wrong result. Fourteen source files are bound to exact product/tooling Git objects. The frozen full-import auditor and its four baseline Git-bound helpers remain included.

## Gate and encoding

The default `python3 materialize.py` invocation only checks readiness. Archive creation requires `--materialize --release PATH`, a fresh output directory under `/home/agent`, all six completed audits, the native/checks audit, and root's final disposition. Root's release pins the exact materializer and new layout hashes, each artifact/audit hash, and one fixed finalization timestamp. The recovered input layout receives independent review before this gate is opened.

Every source file is hashed before selection and immediately before inclusion. ZIP CRCs and full member identities are checked. A bounded credential-pattern scan applies to retained bytes. Each saved archive member is read back and verified. Archives use lexical PAX tar order, mode0444, mtime0, uid/gid0, empty owner names, XZ/LZMA2 preset6 and CRC64. This storage encoding changes no benchmark setting or qualification threshold.

The final publication prefix is `dev/perf/import-investigation-9d6/evidence/guarded-full-import/`. No earlier completed-study archive is overwritten. Small frozen source, layout and review records are also checkpointed under the surviving workspace; large original artifacts and archive outputs remain under `/home/agent` until publication.
