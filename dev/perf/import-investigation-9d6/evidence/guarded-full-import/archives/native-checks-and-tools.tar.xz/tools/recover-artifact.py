"""Recover one immutable original artifact; never run imports or benchmarks."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import stat
import sys
import urllib.request
import zipfile

artifact_id, url, parent = sys.argv[1:4]
parent = Path(parent)
manifest_bytes = (parent / 'frozen-recovery-manifest.json').read_bytes()
manifest_sha = '2670b80fc7944cd3f1b6d973cc2ddc8770e97f6a0a52cf9a9a7501175e57a578'
assert hashlib.sha256(manifest_bytes).hexdigest() == manifest_sha
manifest = json.loads(manifest_bytes)
assert manifest['run'] == 46109596112 and manifest['attempt'] == 1
assert manifest['tooling'] == '8936a15e8a8a2cf53cb10849181a6268c656a7bf'
assert manifest['candidate'] == '20e4af5897013ee76dfd4bed1ee6c383d71ba8e4'
artifact_id = int(artifact_id)
metadata = next(item for item in manifest['originalArtifactMetadata'] if item['id'] == artifact_id)
binding = next(item for item in manifest['artifactBindings'] if item['artifactId'] == artifact_id)
assert metadata['name'] == binding['name'] and metadata['size_in_bytes'] == binding['bytes']
assert metadata['digest'] == 'sha256:' + binding['sha256']
assert metadata['workflow_run']['id'] == manifest['run']
assert metadata['workflow_run']['head_sha'] == manifest['tooling']
assert metadata['expired'] is False and metadata['name'].endswith('-46109596112-1')
assert url.startswith('https://') and 0 < metadata['size_in_bytes'] < 128 * 1024 * 1024
root = parent / str(artifact_id)
root.mkdir(parents=True, exist_ok=False)
archive = root / 'artifact.zip'
digest = hashlib.sha256()
count = 0
try:
    with urllib.request.urlopen(url, timeout=60) as response, archive.open('xb') as output:
        while block := response.read(1024 * 1024):
            count += len(block)
            assert count <= metadata['size_in_bytes']
            digest.update(block)
            output.write(block)
except Exception as error:
    print(type(error).__name__ + ': artifact download failed; temporary URL omitted')
    raise SystemExit(1)
assert count == metadata['size_in_bytes'] and digest.hexdigest() == binding['sha256']
destination = root / 'files'
with zipfile.ZipFile(archive) as zipped:
    members = zipped.infolist()
    assert len(members) <= 5000
    assert sum(item.file_size for item in members) <= 1024 * 1024 * 1024
    assert len({item.filename for item in members}) == len(members)
    assert len({PurePosixPath(item.filename).as_posix() for item in members}) == len(members)
    for item in members:
        name = PurePosixPath(item.filename)
        assert name.parts and not name.is_absolute() and '..' not in name.parts and '\\' not in item.filename
        assert not stat.S_ISLNK(item.external_attr >> 16)
    assert zipped.testzip() is None
    destination.mkdir()
    zipped.extractall(destination)
files = []
for path in sorted(destination.rglob('*')):
    if path.is_file():
        with path.open('rb') as stream:
            file_digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        files.append({'path': str(path.relative_to(destination)), 'bytes': path.stat().st_size,
                      'sha256': file_digest})
receipt = {'artifact': metadata, 'verifiedBytes': count, 'verifiedSha256': digest.hexdigest(),
           'members': len(members), 'extraction': str(destination), 'files': files,
           'recoveryManifestSha256': manifest_sha,
           'scope': 'Immutable original data recovery after executor reset; no benchmark executed'}
temporary = root / 'download-receipt.tmp'
temporary.write_text(json.dumps(receipt, indent=2) + '\n')
temporary.rename(root / 'download-receipt.json')
print(json.dumps({'artifactId': artifact_id, 'bytes': count, 'sha256': digest.hexdigest(),
                  'members': len(members), 'receipt': str(root / 'download-receipt.json')}))
