"""Re-audit original hosted correctness artifacts after temporary-directory loss.

Only existing bytes, Git objects, receipts and job metadata are read. No build,
proof, benchmark, import or timing is executed. This is a new recovery receipt.
"""
from pathlib import Path
from datetime import datetime, timezone
import copy
import hashlib
import json
import re
import runpy
import subprocess

ROOT = Path('/home/agent/manabitan-guarded-hosted-9d6')
REPO = Path('/workspace/scratch/9d6dcf05cf8f/manabitan')
BASELINE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
PRODUCT = '20e4af5897013ee76dfd4bed1ee6c383d71ba8e4'
TOOLING = '8936a15e8a8a2cf53cb10849181a6268c656a7bf'
RUN = 46109596112
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_bytes())
git_bytes = lambda commit, name: subprocess.check_output(['git','-C',str(REPO),'show',commit+':'+name])
source = ROOT / 'recovery-packaging/materialize.py'
assert sha(source.read_bytes()) == '840aef67289b10d77cbafedd6112666504c7bb3ae7e86a12e1d7490f73380aaf'
packager = runpy.run_path(str(source), run_name='read_only_recovery_helpers')
metadata_path = ROOT / 'original-recovery-manifest.json'
assert sha(metadata_path.read_bytes()) == '2670b80fc7944cd3f1b6d973cc2ddc8770e97f6a0a52cf9a9a7501175e57a578'
metadata = read(metadata_path)
assert (metadata['run'],metadata['attempt'],metadata['baseline'],metadata['candidate'],metadata['tooling']) == (RUN,1,BASELINE,PRODUCT,TOOLING)
workflow = git_bytes(TOOLING,'.github/workflows/import-count16-9d6.yml')
assert sha(workflow) == '26a44aa2682906173c0447ca185b1771f3fdbe2ef3c21bd11d7061a6813b130c'
jobs = {row['id']:row for row in metadata['jobs']}
required_steps = {
    140869936638:['Verify and reuse the frozen source capture','Reproduce exact product bytes and verify native boundaries','Retain native receipts and any failure'],
    140869936474:['Full unit suite','All target build tests','Main runtime type check','Development tool type check','Changed runtime lint','Retain exact candidate validation evidence'],
}
for identifier, steps in required_steps.items():
    job = jobs[identifier]
    assert (job['run_id'],job['run_attempt'],job['head_sha'],job['status'],job['conclusion']) == (RUN,1,TOOLING,'completed','success')
    for name in steps:
        selected=[s for s in job['steps'] if s['name']==name]
        assert len(selected)==1 and selected[0]['status']=='completed' and selected[0]['conclusion']=='success'

artifacts=[]
for identifier,count in [(15251383941,18),(15251866511,5)]:
    pinned=next(row for row in metadata['artifacts'] if row['id']==identifier)
    directory=ROOT/str(identifier)
    selected=packager['Selection']()
    outer=packager['verify_outer'](directory,pinned['name'],selected)
    assert outer['zipBytes']==pinned['size_in_bytes'] and outer['zipSha256']==pinned['digest'][7:]
    assert len(outer['members'])==count and all(row['kind']=='file' for row in outer['members'])
    original=next(row for row in metadata['originalArtifactMetadata'] if row['id']==identifier)
    assert outer['artifact']==original
    receipt=read(directory/'download-receipt.json')
    artifacts.append({'artifact':original,'verifiedBytes':outer['zipBytes'],'verifiedSha256':outer['zipSha256'],
                      'filesVerified':count,'downloadReceiptSha256':sha((directory/'download-receipt.json').read_bytes()),'files':receipt['files']})

native=ROOT/'15251383941/files'
verification=read(native/'verification/verification.json')
manifest_bytes=git_bytes(TOOLING,'dev/perf/zstd-count16-guarded/manifest.json')
assert sha(manifest_bytes)=='ca6855cc6caa91523a8bda915223dc427126dda5e3f1a4ec4f6b568ed8b99bb9'
manifest=json.loads(manifest_bytes)
assert verification['complete'] is True and verification['candidateCommit']==PRODUCT
assert verification['candidateTrackedChanges']==[] and verification['sdkOverride'] is False
assert verification['manifest']==manifest and verification['node']=='v24.22.3'
assert verification['verificationEntryPointSha256']=='10157fb2340fd535b2e10b47075807fa07f91e4336ca1736c58b45a0e66a3f82'
for name,digest in manifest['unchangedFiles'].items():
    assert sha(git_bytes(BASELINE,name))==sha(git_bytes(PRODUCT,name))==digest
for name,digest in manifest['productSources'].items(): assert sha(git_bytes(PRODUCT,name))==digest
for name,digest in manifest['verificationSources'].items(): assert sha(git_bytes(TOOLING,'dev/perf/zstd-count16-guarded/'+name))==digest
for name,digest in manifest['parityHarnesses'].items(): assert sha(git_bytes(TOOLING,name))==digest
changed=subprocess.check_output(['git','-C',str(REPO),'diff-tree','--no-commit-id','--name-only','-r',PRODUCT],text=True).splitlines()
assert set(changed)==set(manifest['productSources'])|{'dev/data/zstd-simd.wasm'}
for label,commit in [('baseline',BASELINE),('count16guarded',PRODUCT)]:
    folder=native/('verification/wasm-'+label)
    wasm=(folder/'zstd-simd-module.wasm').read_bytes()
    glue=(folder/'zstd-simd-module.js').read_bytes()
    assert wasm==git_bytes(commit,'dev/data/zstd-simd.wasm') and glue==git_bytes(commit,'dev/lib/zstd-simd-module.js')
    assert sha(wasm)==manifest['expected'][label]['wasmSha256'] and len(wasm)==manifest['expected'][label]['wasmBytes']
    assert sha(glue)==manifest['expected'][label]['jsSha256']
for name,digest in verification['receipts'].items(): assert sha((native/'verification'/name).read_bytes())==digest

restoration=read(ROOT/'recovery-packaging/proof-restoration.json')
assert restoration['archiveSha256']=='19daffeaa033adef237c3a24d96998b3d0595510934137e0bfe2fb949470293d'
for row in restoration['files']:
    data=Path(row['restoredPath']).read_bytes()
    assert len(data)==row['bytes'] and sha(data)==row['sha256']
local=ROOT/'restored-local-proof'
local_verification=read(local/'verification.json')
reconstructed=copy.deepcopy(local_verification['manifest'])
reconstructed['productSources']['dev/data/zstd-wasm.PROVENANCE.md']=manifest['productSources']['dev/data/zstd-wasm.PROVENANCE.md']
for name in ['verify.py','README.md']: reconstructed['verificationSources'][name]=manifest['verificationSources'][name]
assert reconstructed==manifest
for name in ['boundary-result.json','raw-parity.json']:
    assert (native/'verification'/name).read_bytes()==(local/name).read_bytes()
boundary=read(native/'verification/boundary-result.json')
assert boundary['complete'] is True and boundary['totalCases']==sum(boundary['counts'].values())==verification['boundaryCases']==885455
assert boundary['guardedMismatches']==0
assert boundary['supersededFailures']['traps']==768 and boundary['supersededFailures']['wrongResults']==1
assert boundary['harnessSha256']==manifest['verificationSources']['boundaries.mjs']
build=read(native/'verification/boundaries/build.json')
local_build=read(local/'boundaries/build.json')
assert {k:v for k,v in build.items() if k!='records'}=={k:v for k,v in local_build.items() if k!='records'}
assert build['compilerVersion']==verification['compilerVersion']
assert len(build['records'])==len(local_build['records'])==3
for actual,original in zip(build['records'],local_build['records']):
    assert {k:v for k,v in actual.items() if k!='command'}=={k:v for k,v in original.items() if k!='command'}
    command=actual['command']
    assert command[0].endswith('/emcc') and command[1].endswith('/count-boundaries.c')
    assert command[2]=='-I' and command[3].endswith('/zstd/lib/compress')
    assert command[4:-1]==original['command'][4:-1] and command[-1].endswith('/'+actual['name']+'.wasm')
    data=(native/('verification/boundaries/'+actual['name']+'.wasm')).read_bytes()
    assert sha(data)==actual['wasmSha256']==boundary['modules'][actual['name']]['sha256']
    assert len(data)==boundary['modules'][actual['name']]['bytes']

raw=read(native/'verification/raw-parity.json')
wrapped=read(native/'verification/wrapper-parity.json')
local_wrapped=read(local/'wrapper-parity.json')
assert {k:v for k,v in wrapped.items() if k!='initialization'}=={k:v for k,v in local_wrapped.items() if k!='initialization'}
assert len(wrapped['initialization'])==len(local_wrapped['initialization'])==2
for actual,old in zip(wrapped['initialization'],local_wrapped['initialization']):
    assert {k:v for k,v in actual.items() if k!='initializationMs'}=={k:v for k,v in old.items() if k!='initializationMs'}
assert raw['parity']['cases']==verification['rawCases']==651
assert raw['destinationChecks']==verification['destinationChecks']==1110 and raw['destinationCanariesIntact'] is True
assert raw['destinationStatusDifferences']==[] and verification['destinationStatusDifferences']==0
assert raw['measurements']==wrapped['measurements']==[]
assert wrapped['parity']['wrappedBytesExact'] is True
assert len(raw['blocks'])==len(wrapped['parity']['blockDigests'])==verification['wrappedBlocks']==103
assert wrapped['parity']['inputBytes']==sum(row['inputBytes'] for row in wrapped['parity']['blockDigests'])==100300626
assert wrapped['parity']['compressedBytes']==sum(row['compressedBytes'] for row in wrapped['parity']['blockDigests'])==12326040
capture=read(native/'capture-download-receipt.json')
capture_spec=git_bytes(TOOLING,'dev/perf/wasm-word-width-v2/capture-artifact.json')
assert capture['spec']==json.loads(capture_spec) and capture['specificationSha256']==sha(capture_spec)
assert capture['fetchScriptSha256']==sha(git_bytes(TOOLING,'dev/perf/wasm-word-width-v2/fetch-capture.mjs'))
assert capture['currentWorkflowHeadSha']==TOOLING
assert capture['sourceRun']=={'id':46103338197,'attempt':1,'headSha':'d4470d35a684a8c37628123d7740ec2fa3375f4b'}
assert capture['downloadedArchive']=={'bytes':16506090,'sha256':'c3ab42f8714af1c21053e258c5caa7b8fa3c98a6f2eace8cf3c29f69da9f0ffe'}
assert capture['captureReportSha256']==manifest['captureReportSha256']==wrapped['captureReportSha256']==raw['captureReportSha256']

checks=ROOT/'15251866511/files'
unit=re.sub(r'\x1b\[[0-9;]*m','',(checks/'unit.log').read_text())
assert re.search(r'Test Files\s+669 passed\s+\(669\)',unit)
assert re.search(r'Tests\s+15135 passed\s+\|\s+47 skipped\s+\(15182\)',unit)
targets=['chrome','chrome-dev','chrome-playwright','firefox','firefox-dev','firefox-android','edge']
assert re.findall(r'^Building ([^.]+)\.\.\.$',(checks/'build.log').read_text(),re.M)==targets
assert 'tsc --noEmit --project jsconfig.json' in (checks/'types.log').read_text()
assert 'tsc --noEmit --project dev/jsconfig.json' in (checks/'dev-types.log').read_text()
assert '[WARNING]' in (checks/'lint.log').read_text() and 'pako-inflate.js' in (checks/'lint.log').read_text()
receipt={
 'complete':True,'reviewedAtUtc':datetime.now(timezone.utc).isoformat(),
 'scope':'New offline recovery audit of exact original hosted artifacts; no acquisition, build, proof or benchmark in this auditor.',
 'run':RUN,'attempt':1,'baseline':BASELINE,'candidate':PRODUCT,'tooling':TOOLING,
 'recoveryManifestSha256':sha(metadata_path.read_bytes()),'workflowSha256':sha(workflow),
 'jobs':{str(k):{'id':k,'conclusion':jobs[k]['conclusion'],'verifiedSteps':v} for k,v in required_steps.items()},
 'artifacts':artifacts,
 'native':{'candidateTrackedChanges':[],'sdkOverride':False,'entryPointSha256':verification['verificationEntryPointSha256'],
   'manifestSha256':sha(manifest_bytes),'rebuiltAssets':manifest['expected'],'directBoundaryCases':885455,'guardedMismatches':0,
   'supersededFailuresRetained':{'traps':768,'wrongResults':1},'rawCases':651,'destinationChecks':1110,
   'destinationStatusDifferences':0,'wrapperBlocks':103,'wrapperInputBytes':100300626,'wrapperCompressedBytes':12326040,
   'captureArtifactId':15245899188,'captureReportSha256':capture['captureReportSha256'],
   'boundaryProbeIdentities':boundary['modules'],
   'initializationObservationsRetainedWithoutPerformanceInterpretation':{'local':local_wrapped['initialization'],'hosted':wrapped['initialization']},
   'expectedReceiptDifferences':['Hosted boundary commands use runner-specific absolute paths; every compiler flag and probe/source identity matches.',
     'Wrapper parity differs from original local correctness receipt only in initializationMs.',
     'Hosted clean product and final Git-bound helper replace the already-documented prepublication dirty local proof context.']},
 'checks':{'unitFilesPassed':669,'unitTestsPassed':15135,'unitTestsSkipped':47,'buildTargets':targets,
   'mainTypes':'passed','developmentTypes':'passed','scopedLint':'passed; original vendored pako warning retained'},
 'priorAudit':{'sha256':'976f58872b0ee912eb9b22a0f1891a11b7ad30b054813b2d42234ed0a04c6298',
   'bytesRecovered':False,'note':'Prior JSON and source were lost with temporary storage; this is a new audit of the same original artifacts.'},
 'discrepancies':[],'performanceConclusion':None,'reviewerSourceSha256':sha(Path(__file__).read_bytes())}
out=Path(__file__).parent/'review.json'
with out.open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
print(json.dumps({'complete':True,'review':str(out),'sha256':sha(out.read_bytes()),'originalFilesVerified':23,'nativeCases':885455,'unitTests':15135},indent=2))
