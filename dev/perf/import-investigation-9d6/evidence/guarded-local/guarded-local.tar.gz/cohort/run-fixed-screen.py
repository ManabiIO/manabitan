"""Run the once-authorized guarded codec screen; no builds or result-based retries."""

from datetime import datetime, timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parent
PLAN_SHA = '4dab9c657ec2ca96ea92f239d50f1bbc30995842dd3e4b3e8fc46f09f05985fc'
SCREEN_SHA = '5f93fd0ed084b2f499192e64dbcafa16823c37a883c311c3a5313298a30ad1d4'
NODE_SHA = 'acbe4b8d9153b841ed0697cbfc4f93e767386620edb745ab9358306c0a6f31aa'
GUARDED_SHA = '13890c7e75e7a2ff5fa00bd65f1e518e15f545da85154719be6a2eaa2a773a22'
BASELINE_SHA = 'ad3a18c197d72167262d01fd202976325f57a6697bca627f4527c96d4dbbcfcc'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def now():
    return datetime.now(timezone.utc).isoformat()


def host():
    memory = {}
    for line in Path('/proc/meminfo').read_text().splitlines():
        key, value = line.split(':', 1)
        if key in ('MemTotal', 'MemAvailable', 'Shmem', 'SwapTotal', 'SwapFree'):
            memory[key + 'KiB'] = int(value.split()[0])
    return {'capturedAtUtc': now(), 'loadAverage': os.getloadavg(), 'cpuCount': os.cpu_count(),
            'visibleAffinityCount': len(os.sched_getaffinity(0)), 'memory': memory,
            'limitation': 'Shared host; namespaced process visibility and cooperative flock do not prove isolation.'}


def main():
    plan_path = ROOT / 'proposed-plan.json'
    require(sha(plan_path) == PLAN_SHA, 'Frozen plan changed')
    plan = read(plan_path)
    release = read(ROOT / 'root-release.json')
    review = read(ROOT / 'orchestration-review.json')
    require(release['planSha256'] == PLAN_SHA and release['candidateWasmSha256'] == GUARDED_SHA, 'Root release mismatch')
    require(review['complete'] and review['approved'] and review['planSha256'] == PLAN_SHA and review['wrapperSha256'] == sha(Path(__file__)), 'Independent orchestration review is missing or stale')
    out = Path(plan['outputDirectory'])
    require(out == ROOT / 'cohort-01' and not out.exists(), 'Output must be a new planned cohort directory')
    out.mkdir()
    for name in ('proposed-plan.json', 'root-release.json', 'orchestration-review.json', 'run-fixed-screen.py'):
        (out / name).write_bytes((ROOT / name).read_bytes())
    records = []
    execution = {'scope': release['scope'], 'planSha256': PLAN_SHA, 'wrapperSha256': sha(Path(__file__)),
                 'startedAtUtc': now(), 'status': 'preflight', 'complete': False, 'plannedChildren': 19,
                 'children': records, 'lockPath': '/tmp/manabitan-benchmark.lock', 'hostBeforeLock': host()}
    write(out / 'execution.json', execution)
    lock = None
    acquired = False
    try:
        lock = open('/tmp/manabitan-benchmark.lock', 'r+')  # Existing inode only; never create/truncate/remove it.
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            acquired = True
        except BlockingIOError:
            execution.update(status='blocked', completedAtUtc=now(), startedChildren=0)
            write(out / 'execution.json', execution)
            print(json.dumps({'status': 'blocked', 'children': 0, 'output': str(out)}))
            return 75
        execution['lockAcquiredAtUtc'] = now()
        expected = [plan['screen'], plan['manifest'], plan['parityReceipt'], plan['captureReport']]
        for files in plan['modules'].values():
            expected.extend(files.values())
        expected.append({'path': plan['runtime']['executable'], 'sha256': NODE_SHA})
        manifest = read(Path(plan['manifest']['path']))
        require(manifest['baselineCommit'] == plan['baselineCommit'] and manifest['node'] == plan['runtime']['node'] == 'v24.22.3', 'Baseline/runtime identity mismatch')
        for filename, digest in manifest['unchangedFiles'].items():
            expected.append({'path': str(Path(plan['baselineRoot']) / filename), 'sha256': digest})
        for row in plan['capture']['inputs']:
            expected.append({'path': str(Path(plan['captureDirectory']) / row['name']), 'sha256': row['sha256']})
        require(plan['screen']['sha256'] == SCREEN_SHA, 'Measurement child changed')
        require(plan['modules']['baseline']['zstd-simd-module.wasm']['sha256'] == BASELINE_SHA, 'Wrong baseline binary')
        require(plan['modules']['count16guarded']['zstd-simd-module.wasm']['sha256'] == GUARDED_SHA, 'Wrong corrected binary')
        verified = []
        for row in expected:
            path = Path(row['path'])
            require(sha(path) == row['sha256'], f'Input identity mismatch: {path}')
            require('bytes' not in row or path.stat().st_size == row['bytes'], f'Input size mismatch: {path}')
            verified.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': row['sha256']})
        parity = read(Path(plan['parityReceipt']['path']))
        require(parity['candidate'] == 'count16guarded' and parity['mode'] == 'parity' and parity['measurements'] == [], 'Wrong corrected parity receipt')
        require(parity['parity']['blocks'] == 103 and parity['parity']['wrappedBytesExact'] is True, '103-block byte parity is missing')
        require(parity['captureReportSha256'] == plan['captureReport']['sha256'] and parity['captureInputs'] == plan['capture']['inputs'], 'Parity/capture identity mismatch')
        write(out / 'input-identities.json', {'verified': verified, 'rootReleaseSha256': sha(ROOT / 'root-release.json'),
                                             'reviewSha256': sha(ROOT / 'orchestration-review.json'), 'parityReceiptSha256': plan['parityReceipt']['sha256']})
        permutations = [['A', 'B', 'C'], ['A', 'C', 'B'], ['B', 'A', 'C'], ['B', 'C', 'A'], ['C', 'A', 'B'], ['C', 'B', 'A']]
        warm_rounds = [['A', 'B', 'D', 'C'], ['B', 'C', 'A', 'D'], ['C', 'D', 'B', 'A'], ['D', 'A', 'C', 'B']] * 2
        require(plan['fixedProtocol']['measurementChildren'] == 19 and plan['fixedProtocol']['cold']['permutations'] == permutations, 'Cold schedule differs from frozen plan')
        require(plan['fixedProtocol']['warm']['roundSchedules'] == warm_rounds and plan['fixedProtocol']['order'] == 'AB', 'Warm schedule differs from frozen plan')
        schedule = [{'mode': 'warm', 'kind': 'count16guarded', 'name': 'count16guarded-warm-AB', 'arm': None, 'pair': None}]
        for pair, labels in enumerate(permutations):
            for label in labels:
                kind = 'count16guarded' if label == 'B' else 'baseline'
                schedule.append({'mode': 'cold', 'kind': kind, 'name': f'count16guarded-cold-AB-{pair}-{label}-{kind}', 'arm': label, 'pair': pair})
        for item in schedule:
            item['output'] = str(out / (item['name'] + '.json'))
            item['log'] = str(out / (item['name'] + '.log'))
            item['argv'] = [plan['runtime']['executable'], '--expose-gc', plan['screen']['path'], plan['baselineRoot'],
                            plan['captureDirectory'], plan['moduleRoot'], item['output'], item['kind'], 'AB', item['mode'], plan['parityReceipt']['path']]
        require(len(schedule) == 19, 'Wrong number of measurement children')
        write(out / 'commands.json', schedule)
        execution['status'] = 'running'
        start = time.monotonic()
        for ordinal, item in enumerate(schedule):
            record = {'ordinal': ordinal, **item, 'startedAtUtc': now(), 'hostBefore': host(), 'status': 'running'}
            records.append(record)
            write(out / 'execution.json', execution)
            with Path(item['log']).open('xb') as log:
                result = subprocess.run(item['argv'], cwd=plan['baselineRoot'], stdout=log, stderr=subprocess.STDOUT)
            record.update(exitCode=result.returncode, completedAtUtc=now(), hostAfter=host(), logSha256=sha(Path(item['log'])))
            write(out / 'execution.json', execution)
            require(result.returncode == 0, f'Measurement child {ordinal} failed; no retry')
            child_path = Path(item['output'])
            child = read(child_path)
            require(child['node'] == 'v24.22.3' and child['candidate'] == item['kind'] and child['mode'] == item['mode'] and child['order'] == 'AB', 'Child runtime/mode mismatch')
            for key in ('captureReportSha256', 'wrapperSha256', 'databaseSourceSha256', 'plannerSourceSha256', 'blockTargetBytes', 'level', 'dictionarySha256', 'captureInputs'):
                require(child[key] == parity[key], f'Child input mismatch: {key}')
            for key in ('blocks', 'inputBytes', 'compressedBytes'):
                require(child['parity'][key] == parity['parity'][key], f'Child corpus mismatch: {key}')
            measured = child['measurements']
            if item['mode'] == 'warm':
                require([(row['round'], row['arm']) for row in measured] == [(i, arm) for i, arms in enumerate(warm_rounds) for arm in arms], 'Measured warm schedule mismatch')
                require(len(child['initialization']) == 4, 'Wrong warm context count')
            else:
                require(len(measured) == 1 and measured[0]['round'] == 0 and measured[0]['arm'] == 'K', 'Wrong fresh-process cold observation')
                require(len(child['initialization']) == 1, 'Wrong cold context count')
            require(all(row['bytes'] == parity['parity']['compressedBytes'] for row in measured), 'Compressed byte count changed')
            record.update(status='complete', resultSha256=sha(child_path), measuredPasses=len(measured))
            write(out / 'execution.json', execution)
        for row in verified:
            require(sha(Path(row['path'])) == row['sha256'], 'Pinned input changed during cohort')
        require(len(records) == 19 and sum(record['measuredPasses'] for record in records) == 50, 'Incomplete fixed cohort')
        execution.update(status='complete', complete=True, completedAtUtc=now(), orchestrationWallSeconds=time.monotonic() - start,
                         completedChildren=19, measuredCorpusPasses=50, excludedWarmupCorpusPasses=8, hostAfter=host())
        write(out / 'execution.json', execution)
        print(json.dumps({'status': 'complete', 'children': 19, 'measuredPasses': 50,
                          'orchestrationWallSeconds': execution['orchestrationWallSeconds'], 'output': str(out)}))
        return 0
    except BaseException as error:
        execution.update(status='incomplete', complete=False, completedAtUtc=now(), errorType=type(error).__name__,
                         error=str(error), traceback=traceback.format_exc(), hostAfter=host())
        write(out / 'execution.json', execution)
        print(json.dumps({'status': 'incomplete', 'startedChildren': len(records), 'errorType': type(error).__name__, 'output': str(out)}))
        return 1
    finally:
        if acquired:
            fcntl.flock(lock, fcntl.LOCK_UN)
        if lock is not None:
            lock.close()


if __name__ == '__main__':
    sys.exit(main())
