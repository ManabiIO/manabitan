#define _POSIX_C_SOURCE 200809L
#define ZSTD_STATIC_LINKING_ONLY
#define ZSTD_DISABLE_DEPRECATE_WARNINGS
#include "zstd.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct { unsigned char *data; size_t size; const char *name; } Data;
static Data read_data(const char *name) {
    FILE *f = fopen(name, "rb");
    if (!f) { perror(name); exit(2); }
    if (fseek(f, 0, SEEK_END)) exit(2);
    long n = ftell(f);
    if (n < 0 || fseek(f, 0, SEEK_SET)) exit(2);
    unsigned char *data = malloc(n ? (size_t)n : 1);
    if (!data || fread(data, 1, (size_t)n, f) != (size_t)n) exit(2);
    fclose(f);
    return (Data){data, (size_t)n, name};
}
static double now(void) {
    struct timespec t;
    if (clock_gettime(CLOCK_MONOTONIC, &t)) exit(2);
    return t.tv_sec * 1000.0 + t.tv_nsec / 1000000.0;
}
static size_t check(size_t value, const char *where) {
    if (ZSTD_isError(value)) { fprintf(stderr, "%s: %s\n", where, ZSTD_getErrorName(value)); exit(3); }
    return value;
}
static int eq_params(ZSTD_compressionParameters a, ZSTD_compressionParameters b) {
    return a.windowLog == b.windowLog && a.chainLog == b.chainLog && a.hashLog == b.hashLog &&
        a.searchLog == b.searchLog && a.minMatch == b.minMatch && a.targetLength == b.targetLength && a.strategy == b.strategy;
}
int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "Usage: probe DICT BLOCK...\n"); return 2; }
    Data dict = read_data(argv[1]);
    size_t count = (size_t)argc - 2;
    Data *blocks = calloc(count, sizeof(*blocks));
    ZSTD_CCtx *a = ZSTD_createCCtx(), *b = ZSTD_createCCtx(), *prepared = ZSTD_createCCtx();
    if (!blocks || !a || !b || !prepared) return 2;
    size_t max_bound = 0;
    for (size_t i = 0; i < count; ++i) { blocks[i] = read_data(argv[i + 2]); size_t bound = ZSTD_compressBound(blocks[i].size); if (bound > max_bound) max_bound = bound; }
    void *out_a = malloc(max_bound), *out_b = malloc(max_bound), *decoded = malloc(max_bound);
    if (!out_a || !out_b || !decoded) return 2;
    ZSTD_parameters last = {0};
    int has_prepared = 0;
    size_t total_a = 0, total_b = 0, mismatch = 0, preparations = 0;
    double init_a = 0, init_b = 0, end_a = 0, end_b = 0;
    for (size_t i = 0; i < count; ++i) {
        Data in = blocks[i];
        ZSTD_parameters params = ZSTD_getParams(-1, in.size, dict.size);
        if (!has_prepared || !eq_params(last.cParams, params.cParams)) {
            check(ZSTD_compressBegin_advanced(prepared, dict.data, dict.size, params, in.size), "prepare");
            last = params; has_prepared = 1; ++preparations;
        }
        size_t na = check(ZSTD_compress_usingDict(a, out_a, max_bound, in.data, in.size, dict.data, dict.size, -1), "baseline");
        check(ZSTD_copyCCtx(b, prepared, in.size), "copy");
        size_t nb = check(ZSTD_compressEnd(b, out_b, max_bound, in.data, in.size), "finish");
        total_a += na; total_b += nb;
        if (na != nb || memcmp(out_a, out_b, na)) { ++mismatch; fprintf(stderr, "Mismatch %zu: %zu/%zu bytes\n", i, na, nb); }
        ZSTD_DCtx *d = ZSTD_createDCtx();
        size_t nd = check(ZSTD_decompress_usingDict(d, decoded, max_bound, out_b, nb, dict.data, dict.size), "decode");
        if (nd != in.size || memcmp(decoded, in.data, nd)) return 4;
        ZSTD_freeDCtx(d);
        for (int k = 0; k < 5; ++k) {
            double t = now();
            check(ZSTD_compressBegin_advanced(a, dict.data, dict.size, params, in.size), "begin");
            double t1 = now();
            check(ZSTD_compressEnd(a, out_a, max_bound, in.data, in.size), "baseline finish");
            double t2 = now();
            check(ZSTD_copyCCtx(b, prepared, in.size), "copy timed");
            double t3 = now();
            check(ZSTD_compressEnd(b, out_b, max_bound, in.data, in.size), "snapshot finish");
            double t4 = now();
            init_a += t1 - t; end_a += t2 - t1; init_b += t3 - t2; end_b += t4 - t3;
        }
    }
    printf("{\"blocks\":%zu,\"mismatches\":%zu,\"preparations\":%zu,\"originalBytes\":%zu,\"snapshotBytes\":%zu,\"snapshotContextBytes\":%zu,\"baselineInitMs\":%.6f,\"snapshotInitMs\":%.6f,\"baselineEndMs\":%.6f,\"snapshotEndMs\":%.6f}\n", count, mismatch, preparations, total_a, total_b, ZSTD_sizeof_CCtx(prepared), init_a, init_b, end_a, end_b);
    ZSTD_freeCCtx(a); ZSTD_freeCCtx(b); ZSTD_freeCCtx(prepared);
    free(out_a); free(out_b); free(decoded); free(dict.data);
    for (size_t i = 0; i < count; ++i) free(blocks[i].data);
    free(blocks);
    return mismatch ? 1 : 0;
}
