# Frozen scalar Zstd word-width cohort: closed without promotion

Both immutable hosted cohorts completed and passed the independent artifact audit. The two scalar candidates show small warm component gains, but neither establishes a repeatable fresh-process cold benefit. No whole-import claim or PR is justified, and no unchanged rerun is planned.

## Warm observations

Positive savings compare the mean of baseline A/C against the mean of candidate B/D within each fixed block. Every cohort retains all eight blocks.

| Variant | Host order | A median (ms) | B median (ms) | C median (ms) | D median (ms) | Paired saved (ms) | Paired saved (%) | C−A control (ms) | D−B control (ms) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| count8ctz | AB | 155.665 | 151.907 | 154.840 | 152.738 | 2.942 | 1.898 | -0.715 | 0.951 |
| count8unroll | AB | 154.252 | 150.531 | 153.987 | 151.643 | 2.715 | 1.762 | -0.198 | 0.769 |
| count8ctz | BA | 152.433 | 150.412 | 154.391 | 150.663 | 2.831 | 1.846 | 2.134 | 0.218 |
| count8unroll | BA | 153.344 | 149.313 | 153.411 | 149.918 | 3.934 | 2.559 | 0.084 | 0.492 |

## Separate fresh-process observations

All six A/B/C permutations are retained. Each child creates one codec context and processes all 103 blocks. Production uses four compressor workers, so this remains directional component evidence rather than a real browser startup measurement.

| Variant | Host order | A median (ms) | B median (ms) | C median (ms) | Paired saved (ms) | Paired saved (%) | C−A control (ms) | Startup plus work saved (ms) |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| count8ctz | AB | 182.062 | 179.367 | 185.151 | 2.605 | 1.422 | 3.339 | 2.163 |
| count8unroll | AB | 183.624 | 183.809 | 185.123 | 1.070 | 0.591 | 2.777 | 0.306 |
| count8ctz | BA | 183.732 | 184.977 | 182.932 | -1.760 | -0.953 | -2.567 | -1.399 |
| count8unroll | BA | 180.552 | 183.124 | 181.757 | -1.787 | -0.976 | 0.323 | -2.278 |

All cold descriptive intervals cross zero. Warm code adds 4,843 bytes for count8ctz and 10,364 bytes for count8unroll. Both hosts report Intel Xeon 6975P-C and Node 24.22.3.

## Identity and scope

Run 46103338197, attempt 1, immutable experiment head d4470d35a684a8c37628123d7740ec2fa3375f4b; product baseline 9e10d3b3fcf66d344ab31bc42c9b522fa5215da2. All builds reproduce the pinned baseline and declared candidate hashes. All 507 raw parity cases and all 103 actual 1 MiB wrapper blocks match, with cross-decoder equality. The packed input is 100,300,626 bytes; compressed frames plus envelopes total 12,326,040 bytes. No destination-capacity stress test was part of v1.

The audit covers every frozen script hash, exact build hash, capture hash, workload schedule, per-child result and duplicate control. Identical retained wrapper buffer capacities are recorded; whole-process peak memory was not measured. Parser, worker messages/scheduling, compression concurrency, storage, and visible import completion are excluded.

Artifact 15247901694 (AB): 485,041 bytes; SHA256 ef3dac09d8049e329fecf616f1a43cf4d5d93282b5fca4d8aeddf484c03474d3.

Artifact 15247313223 (BA): 484,951 bytes; SHA256 a114993a0dd3f9cbc4e001a57168835ca8036e1a75597d8edad979eb7ebc62ea.

Raw ZIPs, exact download/extraction receipts, full observations, and independently recomputed analyses remain alongside this decision.
