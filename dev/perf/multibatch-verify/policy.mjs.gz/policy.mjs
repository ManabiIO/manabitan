import {createServer} from 'node:http';
import {writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
const [root, output] = process.argv.slice(2);
const {chromium} = await import(pathToFileURL(path.resolve(root, 'node_modules/playwright/index.mjs')));
const server = createServer((req, res) => res.end('<!doctype html><title>Native policy</title>'));
await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
const browser = await chromium.launch({executablePath: chromium.executablePath(), headless: true});
try {
    const page = await browser.newPage();
    await page.goto(`http://127.0.0.1:${server.address().port}`);
    const policy = await page.evaluate(async () => {
        const url = URL.createObjectURL(new Blob(['postMessage({deviceMemory: navigator.deviceMemory, hardwareConcurrency: navigator.hardwareConcurrency})'], {type:'text/javascript'}));
        const worker = new Worker(url);
        const value = await new Promise((resolve, reject) => { worker.onmessage = event => resolve(event.data); worker.onerror = reject; });
        worker.terminate(); URL.revokeObjectURL(url);
        return {page: {deviceMemory: navigator.deviceMemory, hardwareConcurrency: navigator.hardwareConcurrency}, worker: value};
    });
    await writeFile(output, JSON.stringify({browserVersion: browser.version(), ...policy}, null, 2)+'\n');
    if (policy.page.deviceMemory !== policy.worker.deviceMemory) { throw new Error('Inconsistent native memory classification'); }
    console.log(JSON.stringify(policy));
} finally { await browser.close(); server.close(); }
