"""Fixed, immutable full-import comparison. No retries, splicing, or timing filters."""
import argparse
import hashlib
import json
import math
import re
import statistics
import subprocess
import zipfile
from pathlib import Path

BASE = 'da8f7436d34e510441d30692c8d698806b70e13f'
CANDIDATE_TREE = '4035249c23197b72d8be9d4cca7ebd6476771ef1'
SHARED_FILES = ['package-lock.json', 'test/perf/dictionaries.lock.json', 'dev/perf/import-benchmark.js', 'dev/perf/benchmark-support.js', 'test/chromium/extension-two-dictionary-import.e2e.js', 'test/e2e/import-timing.js']


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2) + '\n')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(root, *args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def stats(pairs):
    changes = [100 * (b / a - 1) for a, b in pairs]
    return dict(pairsMs=pairs, changesPercent=changes, pairedMedianPercent=statistics.median(changes),
                equalWorkPercent=100 * (sum(b for a, b in pairs) / sum(a for a, b in pairs) - 1),
                fasterPairs=sum(b < a for a, b in pairs), worstPairPercent=max(changes))


def banks_for(root, dictionary):
    fixture = read(root / 'test/perf/dictionaries.lock.json')['dictionaries'][dictionary]
    path = root / 'builds/e2e-dictionary-cache' / fixture['cacheFile']
    assert sha(path) == fixture['sha256'] and path.stat().st_size == fixture['sizeBytes']
    with zipfile.ZipFile(path) as archive:
        banks = [i for i in archive.infolist() if re.fullmatch(r'term_bank_\d+\.json', i.filename)]
    banks.sort(key=lambda i: int(re.search(r'\d+', i.filename).group()))
    assert len({i.filename for i in banks}) == len(banks) > 0
    return fixture, banks


def groups_for(banks, low):
    if not low:
        return [banks]
    groups = []
    group = []
    size = 0
    for bank in banks:
        if group and (len(group) == 80 or size + bank.file_size > 64 * 1024 * 1024):
            groups.append(group)
            group = []
            size = 0
        group.append(bank)
        size += bank.file_size
    if group:
        groups.append(group)
    return groups


def audit(root, dictionary, target, arm, identity, policy):
    summary = read(target / 'summary.json')
    raw = read(target / 'run-1.json')
    assert summary['schemaVersion'] == 3 and raw['status'] == 'success' and raw['skippedVerification'] is False
    benchmark = raw['benchmark']
    assert benchmark['dictionary'] == dictionary and benchmark['pinnedDictionaries'] is True
    assert benchmark['productionImportDefaults'] is True and benchmark['authoritativeTiming'] is True
    assert benchmark['importFlags'] is None
    assert all(benchmark[k] is False for k in ['traceEnabled', 'phaseProfiling', 'phaseScreenshots', 'processSampling'])
    assert summary['authoritativeTiming'] is True and summary['traceEnabled'] is False
    assert len(summary['runs']) == 1
    source = summary['source']
    assert source['dirty'] is False and source['gitSha'] == identity['commit']
    assert source['sha256']['builds/manabitan-chrome-dev.zip'] == identity['package']
    for name in SHARED_FILES:
        assert source['sha256'][name] == identity['shared'][name]
    run = summary['runs'][0]
    fixture, banks = banks_for(root, dictionary)
    validation = run['validation']
    assert (validation['title'], validation['revision'], validation['termRows']) == (fixture['expectedTitle'], fixture['revision'], fixture['termRows'])
    assert validation['contentReadable'] is True and validation['probeCount'] >= 12
    debug = run['importDebug']
    assert debug['hasResult'] is True and debug['errorCount'] == 0 and debug['addSettingsErrorCount'] == 0
    assert debug['usesFallbackStorage'] is False
    ms = run['totalImportMs']
    assert isinstance(ms, (int, float)) and math.isfinite(ms) and ms > 0
    browser_events = [p['data']['browserTiming'] for p in raw['phases'] if (p.get('data') or {}).get('kind') == 'dictionary-import']
    assert len(browser_events) == 1
    event = browser_events[0]
    assert event['trigger'] == 'file-input-change' and event['errorCount'] == 0
    assert event['sequence'] > event['sequenceBefore']
    assert abs(ms - (event['completedAtMs'] - event['startedAtMs'])) < 0.001
    assert run['browserVersion'] == summary['browserVersion'] == policy['browserVersion']
    memory = policy['page']['deviceMemory']
    assert memory == policy['worker']['deviceMemory']
    low = math.isfinite(memory) and memory <= 4
    groups = groups_for(banks, low)
    phases = [p for p in debug['importerPhaseTimings'] if p['phase'].startswith('term-file-fast-path:')]
    assert len(phases) == len(groups), [p['phase'] for p in phases]
    rows = 0
    transferred = 0
    for p, group in zip(phases, groups):
        details = p['details']
        name = group[0].filename if len(group) == 1 else group[0].filename + '..' + group[-1].filename
        assert p['phase'] == 'term-file-fast-path:' + name
        assert details['batchedFileCount'] == len(group)
        assert details['sourceBatchMaxBytes'] == (64 if low else 192) * 1024 * 1024
        assert details['parserParallelSkipReason'] is None
        rows += details['rows']
        decoded = sum(i.file_size for i in group)
        compressed = sum(i.compress_size for i in group)
        use_compressed = not low or (arm == 'B' and len(groups) > 1)
        assert len(group) >= 4  # The pinned fixtures exercise eligible groups.
        assert details['parserSourceCompressedBytes'] == (compressed if use_compressed else 0)
        assert details['parserSourceUncompressedBytes'] == (decoded if use_compressed else 0)
        assert details['parserSourceTransferredBytes'] == (compressed if use_compressed else decoded)
        if low:
            assert decoded <= 64 * 1024 * 1024 and len(group) <= 80
            if use_compressed:
                assert compressed <= 64 * 1024 * 1024
        transferred += details['parserSourceTransferredBytes']
    assert rows == fixture['termRows']
    accounting = {key: sum(p['details'][key] for p in phases) for key in ['dedupPendingHitCount', 'dedupPersistedHitCount', 'dedupUniqueCount']}
    return dict(ms=ms, accounting=accounting, validation=validation, groups=len(groups), sourceBytesTransferred=transferred)


def make_plan(dictionaries, pairs, reverse):
    plan = []
    def add(dictionary, kind, pair, order):
        plan.extend(dict(dictionary=dictionary, kind=kind, pair=pair, arm=arm) for arm in order)
    for dictionary in dictionaries:
        add(dictionary, 'warmup', -1, 'BA' if reverse else 'AB')
    for pair in range(pairs):
        rotation = pair % len(dictionaries)
        for dictionary in dictionaries[rotation:] + dictionaries[:rotation]:
            order = 'AB' if (pair + dictionaries.index(dictionary) + int(reverse)) % 2 == 0 else 'BA'
            add(dictionary, 'AB', pair, order)
            if pair == 0:
                add(dictionary, 'control', pair, 'AA')
            if pair == pairs - 2:
                add(dictionary, 'control', pair, 'BB')
    return plan


def main():
    parser = argparse.ArgumentParser()
    for name in ['baseline', 'candidate', 'output', 'policy']:
        parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--pairs', type=int, default=4)
    parser.add_argument('--dictionaries', nargs='+', default=['jmnedict', 'jmdict', 'jitendex'])
    parser.add_argument('--reverse', action='store_true')
    parser.add_argument('--tier', choices=['low', 'high'], default='low')
    args = parser.parse_args()
    assert args.pairs >= 4 and len(set(args.dictionaries)) == len(args.dictionaries)
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    roots = {'A': args.baseline.resolve(), 'B': args.candidate.resolve()}
    policy = read(args.policy)
    save(out / 'native-policy.json', policy)
    memory = policy['page']['deviceMemory']
    assert policy['worker']['deviceMemory'] == memory
    assert (memory <= 4) == (args.tier == 'low'), policy
    ids = {}
    for arm, root in roots.items():
        assert not git(root, 'status', '--porcelain')
        ids[arm] = dict(commit=git(root, 'rev-parse', 'HEAD'), tree=git(root, 'rev-parse', 'HEAD^{tree}'),
                        package=sha(root / 'builds/manabitan-chrome-dev.zip'), shared={name: sha(root / name) for name in SHARED_FILES})
    assert ids['A']['commit'] == BASE and ids['B']['tree'] == CANDIDATE_TREE
    assert ids['A']['shared'] == ids['B']['shared']
    with zipfile.ZipFile(roots['A'] / 'builds/manabitan-chrome-dev.zip') as a, zipfile.ZipFile(roots['B'] / 'builds/manabitan-chrome-dev.zip') as b:
        assert set(a.namelist()) == set(b.namelist())
        changed = sorted(n for n in a.namelist() if a.read(n) != b.read(n))
        assert changed == ['js/dictionary/dictionary-importer.js', 'js/dictionary/term-bank-source-pipeline.js'], changed
    save(out / 'identity.json', ids)
    plan = make_plan(args.dictionaries, args.pairs, args.reverse)
    save(out / 'plan.json', plan)
    observations = []
    try:
        for index, item in enumerate(plan):
            root = roots[item['arm']]
            target = out / f'{index:03d}-{item["dictionary"]}-{item["kind"]}-{item["arm"]}'
            with (out / f'{index:03d}.log').open('w') as log:
                completed = subprocess.run(['node', 'dev/perf/import-benchmark.js', item['dictionary'], '--runs', '1', '--no-build', '--output', str(target)], cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=180, check=False)
            observation = dict(item, output=str(target), returncode=completed.returncode)
            observations.append(observation)
            save(out / 'observations.json', observations)
            assert completed.returncode == 0, observation
            observation.update(audit(root, item['dictionary'], target, item['arm'], ids[item['arm']], policy))
            save(out / 'observations.json', observations)
            assert sha(root / 'builds/manabitan-chrome-dev.zip') == ids[item['arm']]['package']
            assert not git(root, 'status', '--porcelain')
            print(index, item['dictionary'], item['kind'], item['arm'], round(observation['ms'], 2), flush=True)
        results = {}
        for dictionary in args.dictionaries:
            pairs = []
            for pair in range(args.pairs):
                values = {v['arm']: v for v in observations if v['dictionary'] == dictionary and v['kind'] == 'AB' and v['pair'] == pair}
                assert values['A']['accounting'] == values['B']['accounting']
                pairs.append([values['A']['ms'], values['B']['ms']])
            controls = {arm: stats([[v['ms'] for v in observations if v['dictionary'] == dictionary and v['kind'] == 'control' and v['arm'] == arm]]) for arm in 'AB'}
            results[dictionary] = dict(comparison=stats(pairs), controls=controls)
        save(out / 'RESULTS.json', dict(status='complete', results=results))
        print(json.dumps(results, indent=2), flush=True)
    except BaseException as error:
        save(out / 'FAILURE.json', dict(status='incomplete', error=repr(error), observations=len(observations), effectEstimate=None))
        raise


if __name__ == '__main__':
    main()
