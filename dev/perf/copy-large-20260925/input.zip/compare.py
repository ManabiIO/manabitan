#!/usr/bin/env python3
"""Fixed-plan complete imports; identities, controls and all observations retained."""
from pathlib import Path
import hashlib
import json
import os
import statistics
import subprocess
import time
import zipfile

BASE = '76362775484661b3cd8b9d2c84b228802c023a76'
a = Path(os.environ['BASE_ROOT'])
b = Path(os.environ['CANDIDATE_ROOT'])
out = Path(os.environ['EVIDENCE_ROOT'])
kind = os.environ['CANDIDATE']
source = {'cache-align': 'ext/js/dictionary/dictionary-database.js',
          'decoded-owned': 'ext/js/dictionary/term-content-block-store.js'}[kind]
package = 'builds/manabitan-chrome-dev.zip'

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

def identity(root):
    files = [source, package, 'ext/lib/term-bank-parser.wasm', 'ext/lib/zstd.wasm',
             'test/perf/dictionaries.lock.json', 'test/chromium/extension-two-dictionary-import.e2e.js']
    return {'commit': git(root, 'rev-parse', 'HEAD'), 'tree': git(root, 'rev-parse', 'HEAD^{tree}'),
            'status': git(root, 'status', '--porcelain'), 'hashes': {f: digest(root / f) for f in files}}

assert git(a, 'rev-parse', 'HEAD') == BASE
assert git(b, 'rev-parse', 'HEAD^') == BASE
assert git(b, 'diff', '--name-only', 'HEAD^', 'HEAD').splitlines() == sorted([source, 'test/' + {
    'cache-align': 'term-content-recent-source-copy.test.js',
    'decoded-owned': 'term-content-decoded-ownership.test.js'}[kind]])
ids = {'A': identity(a), 'B': identity(b)}
assert all(not i['status'] for i in ids.values()), ids
for f in ids['A']['hashes']:
    if f not in (source, package):
        assert ids['A']['hashes'][f] == ids['B']['hashes'][f], f
with zipfile.ZipFile(a / package) as za, zipfile.ZipFile(b / package) as zb:
    assert sorted(za.namelist()) == sorted(zb.namelist())
    changed = [f for f in za.namelist() if za.read(f) != zb.read(f)]
    assert changed == [source.removeprefix('ext/')], changed

plan = []
for dictionary, initial in [('jmdict', 'AB'), ('jmnedict', 'BA'), ('jitendex', 'BA')]:
    plan.extend({'dictionary': dictionary, 'kind': 'warmup', 'pair': 0, 'arm': arm, 'binary': arm} for arm in initial)
    for pair in range(1, 9):
        order = initial if pair % 2 else initial[::-1]
        plan.extend({'dictionary': dictionary, 'kind': 'measured', 'pair': pair, 'arm': arm, 'binary': arm} for arm in order)
        if pair % 2 == 0:
            plan.extend({'dictionary': dictionary, 'kind': 'aa', 'pair': pair // 2, 'arm': arm, 'binary': 'A'} for arm in ('AB' if pair % 4 else 'BA'))
(out / 'plan.json').write_text(json.dumps({'base': BASE, 'candidate': kind, 'identities': ids, 'plan': plan,
    'flags': {}, 'noRetries': True, 'noOutlierRemoval': True,
    'boundary': 'file-input change to post-UI completion', 'node': subprocess.check_output(['node', '--version'], text=True).strip()}, indent=2))
observations = []
for ordinal, item in enumerate(plan, 1):
    root = a if item['binary'] == 'A' else b
    assert identity(root) == ids[item['binary']]
    destination = out / f"{ordinal:02}-{item['dictionary']}-{item['kind']}-{item['pair']}-{item['arm']}"
    start = time.monotonic()
    with Path(str(destination) + '.log').open('w') as log:
        result = subprocess.run(['node', 'dev/perf/import-benchmark.js', item['dictionary'], '--runs', '1',
             '--no-build', '--flags', '{}', '--output', str(destination)], cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=240)
    assert result.returncode == 0, f'Observation {ordinal} failed; retained without retry'
    summary = json.loads((destination / 'summary.json').read_text())
    report = json.loads((destination / 'run-1.json').read_text())
    assert report['status'] == 'success' and report['skippedVerification'] is False
    assert summary['source']['dirty'] is False
    assert summary['source']['sha256'][package] == ids[item['binary']]['hashes'][package]
    run = summary['runs'][0]
    observations.append({**item, 'ordinal': ordinal, 'ms': run['totalImportMs'], 'workerMs': run['workerImportMs'],
                         'validation': run.get('validation'), 'browser': summary['browserVersion'], 'wallSeconds': time.monotonic() - start})
    (out / 'observations.json').write_text(json.dumps(observations, indent=2))
    print(json.dumps(observations[-1]), flush=True)

comparisons = []
for dictionary in ['jmdict', 'jmnedict', 'jitendex']:
    comparison = {'dictionary': dictionary}
    for lane in ['measured', 'aa']:
        selected = [x for x in observations if x['dictionary'] == dictionary and x['kind'] == lane]
        pairs = []
        for pair in sorted({x['pair'] for x in selected}):
            group = {x['arm']: x for x in selected if x['pair'] == pair}
            av, bv = group['A']['ms'], group['B']['ms']
            pairs.append({'pair': pair, 'aMs': av, 'bMs': bv, 'changePct': 100 * (bv / av - 1)})
        comparison[lane] = {'aMedianMs': statistics.median(x['aMs'] for x in pairs),
            'bMedianMs': statistics.median(x['bMs'] for x in pairs),
            'pairedMedianPct': statistics.median(x['changePct'] for x in pairs),
            'fasterPairs': sum(x['changePct'] < 0 for x in pairs), 'pairs': pairs}
    comparisons.append(comparison)
(out / 'comparison.json').write_text(json.dumps(comparisons, indent=2))
(out / 'complete.json').write_text(json.dumps({'planned': len(plan), 'completed': len(observations)}))
print(json.dumps(comparisons, indent=2))
