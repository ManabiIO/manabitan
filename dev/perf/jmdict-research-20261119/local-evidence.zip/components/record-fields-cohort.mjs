import {readFile, writeFile, mkdir} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {spawn} from 'node:child_process'
import path from 'node:path'

const root = '/workspace/scratch/cb98f2e06b71'
const runner = path.join(root, 'record-fields-screen.mjs')
const directory = path.join(root, 'record-fields-cohort')
await mkdir(directory, {recursive: true})
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const runnerSha256 = sha256(await readFile(runner))
const roots = {A: path.join(root, 'manabitan'), B: path.join(root, 'manabitan-storage')}
const schedule = []
for (let pair = 0; pair < 8; ++pair) {
    const cohorts = pair % 2 === 0 ? ['AB', 'AA', 'BB'] : ['AB']
    for (const cohort of cohorts) {
        const arms = cohort === 'AB' ? [{label: 'A', source: 'A'}, {label: 'B', source: 'B'}] :
            [{label: `${cohort[0]}1`, source: cohort[0]}, {label: `${cohort[0]}2`, source: cohort[0]}]
        const reverse = cohort === 'AB' ? pair % 2 === 1 : (pair / 2) % 2 === 1
        if (reverse) { arms.reverse() }
        schedule.push({pair, cohort, arms})
    }
}
await writeFile(path.join(directory, 'schedule.json'), JSON.stringify({runnerSha256, schedule}))
const results = []
let expectedDigest = null
let expectedInputDigest = null
let ordinal = 0
for (const {pair, cohort, arms} of schedule) {
    const observations = []
    for (const arm of arms) {
        if (sha256(await readFile(runner)) !== runnerSha256) { throw new Error('Frozen runner changed') }
        const child = spawn(process.execPath, [
            '--expose-gc', runner,
            '--source-root', roots[arm.source],
            '--fixture-root', roots.A,
            '--dictionary', 'jmdict',
            '--passes', '8',
        ], {cwd: roots[arm.source], stdio: ['ignore', 'pipe', 'pipe']})
        let stdout = ''
        let stderr = ''
        child.stdout.setEncoding('utf8').on('data', (text) => { stdout += text })
        child.stderr.setEncoding('utf8').on('data', (text) => { stderr += text })
        const status = await new Promise((resolve, reject) => {
            child.once('error', reject)
            child.once('close', (code, signal) => resolve({code, signal}))
        })
        const stem = `${String(ordinal++).padStart(2, '0')}-${cohort}-${pair}-${arm.label}`
        await writeFile(path.join(directory, `${stem}.stdout.json`), stdout)
        await writeFile(path.join(directory, `${stem}.stderr.log`), stderr)
        if (status.code !== 0) { throw new Error(`Component child failed ${stem}: ${JSON.stringify(status)} ${stderr}`) }
        const result = JSON.parse(stdout)
        if (result.runnerSha256 !== runnerSha256 || result.rows !== 526942 || result.groups !== 12) { throw new Error('Child identity or corpus differs') }
        if (expectedDigest !== null && result.outputDigest !== expectedDigest) { throw new Error('Baseline/candidate output bytes differ') }
        if (expectedInputDigest !== null && result.inputDigest !== expectedInputDigest) { throw new Error('Baseline/candidate fixture input differs') }
        expectedDigest = result.outputDigest
        expectedInputDigest = result.inputDigest
        observations.push({...arm, result})
        process.stderr.write(`Verified child ${ordinal}/32: ${stem}\n`)
    }
    results.push({pair, cohort, observations})
    await writeFile(path.join(directory, 'checkpoint.json'), JSON.stringify({runnerSha256, results}))
}
console.log(JSON.stringify({
    boundary: 'Complete real-corpus validation, record-field layout and encoding with prepared lookup indexes; each isolated child has two excluded warmups and eight measured complete passes',
    schedule: 'Eight alternating AB/BA pairs plus four alternating AA and four BB control pairs; fixed before observations',
    runnerSha256,
    inputDigest: expectedInputDigest,
    outputDigest: expectedDigest,
    results,
}))
