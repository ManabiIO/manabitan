import {readFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import {parseArgs} from 'node:util'
import {fileURLToPath, pathToFileURL} from 'node:url'
import path from 'node:path'
import os from 'node:os'
import {copySharedWords4, copySharedWords8} from './uint32-copy-prototype.mjs'

const {values} = parseArgs({options: {
    'baseline-root': {type: 'string'},
    'candidate-root': {type: 'string'},
    dictionary: {type: 'string', default: 'jmdict'},
    passes: {type: 'string', default: '8'},
}})
const baselineRoot = path.resolve(values['baseline-root'])
const candidateRoot = path.resolve(values['candidate-root'])
const passes = Number(values.passes)
if (!Number.isInteger(passes) || passes < 2 || passes > 100) { throw new Error('Invalid pass count') }
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const load = async (relative) => await import(pathToFileURL(path.join(baselineRoot, relative)))
const sourceFiles = [
    [candidateRoot, 'ext/js/dictionary/dictionary-database.js'],
    [baselineRoot, 'ext/js/dictionary/dictionary-database.js'],
    [baselineRoot, 'ext/js/dictionary/term-bank-wasm-parser.js'],
    [baselineRoot, 'ext/js/dictionary/term-bank-experiments.js'],
    ['/workspace/scratch/cb98f2e06b71', 'uint32-copy-prototype.mjs'],
]
const snapshots = await Promise.all(sourceFiles.map(async ([root, file]) => ({root, file, bytes: await readFile(path.join(root, file))})))
const sourceHashes = snapshots.map(({root, file, bytes}) => ({root, file, sha256: sha256(bytes)}))
const candidateSource = snapshots[0].bytes.toString()
const parserSource = snapshots[2].bytes.toString()
const extract = (source, name) => {
    const match = source.match(new RegExp(`^function ${name}\\([^]*?^}`, 'm'))
    if (!match) { throw new Error(`Missing exact source function ${name}`) }
    return match[0]
}
const helperSource = extract(candidateSource, 'copyRecentTermContentSource')
const candidateCopy = new Function(`${helperSource}\nreturn copyRecentTermContentSource`)()
const partitionSource = extract(parserSource, 'partitionSourceBanks')
const partitionLengthSource = extract(parserSource, 'getPartitionSourceByteLength')
const partition = new Function(`${partitionSource}\n${partitionLengthSource}\nreturn partitionSourceBanks`)()
const {ZipReader, Uint8ArrayReader, Uint8ArrayWriter} = await load('node_modules/@zip.js/zip.js/index.js')
const parser = await load('ext/js/dictionary/term-bank-wasm-parser.js')
const {snapshotTermBankExperiments} = await load('ext/js/dictionary/term-bank-experiments.js')
const lockBytes = await readFile(path.join(baselineRoot, 'test/perf/dictionaries.lock.json'))
const spec = JSON.parse(lockBytes).dictionaries[values.dictionary]
if (!spec) { throw new Error('Unknown locked dictionary') }
const archive = await readFile(path.join(baselineRoot, 'builds/e2e-dictionary-cache', spec.cacheFile))
if (sha256(archive) !== spec.sha256) { throw new Error('Dictionary SHA-256 differs from lock') }
const wasmBytes = await readFile(path.join(baselineRoot, 'ext/lib/term-bank-parser.wasm'))
parser.setTermBankWasmModule(await WebAssembly.compile(wasmBytes))
const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)))
const sources = []
try {
    const entries = (await reader.getEntries()).filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename))
        .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
    for (const entry of entries) {
        sources.push(await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}))
    }
} finally { await reader.close() }
const options = {
    ...snapshotTermBankExperiments(),
    singleChunk: true,
    emitTermByteLists: false,
    computeContentHashes: true,
    emitContentSlab: true,
    emitTokenBinaryContent: true,
    mediaHintFastScan: true,
    validateGlossaryTypes: true,
    prepareLookupIndexes: true,
}
if (!options.experimentalParserWorkers3) { throw new Error('Production parser worker count assumption changed') }
const totalSourceBytes = sources.reduce((total, source) => total + source.byteLength, 0)
const requestedGroupCount = Math.max(3 * 4, Math.ceil(totalSourceBytes / (24 * 1024 * 1024)))
const groups = partition(sources, totalSourceBytes, requestedGroupCount)
const fixtures = []
let rows = 0
for (const group of groups) {
    await parser.parseTermBankWithWasmColumnChunks(group, 3, (chunk) => {
        const source = chunk.contentBytesBuffer
        const start = chunk.contentBytesBaseOffset
        const length = chunk.contentBytesLength
        if (!(source instanceof Uint8Array) || !Number.isSafeInteger(start) || !Number.isSafeInteger(length) || start < 0 || length < 0 || length > source.byteLength - start) {
            throw new Error('Invalid complete native content slab')
        }
        const bytes = new Uint8Array(length)
        bytes.set(source.subarray(start, start + length))
        fixtures.push({
            bytes,
            rows: chunk.rowCount,
            banks: group.length,
            nativeShared: !(source.buffer instanceof ArrayBuffer),
            nativeAbsoluteStart: source.byteOffset + start,
            nativeByteLength: source.byteLength,
            sha256: sha256(bytes),
        })
        rows += chunk.rowCount
    }, 2048, options)
}
if (rows !== spec.termRows || fixtures.length !== groups.length) { throw new Error('Incomplete locked corpus') }
sources.length = 0
groups.length = 0
const digestOutputs = (outputs) => {
    const hash = createHash('sha256')
    for (const output of outputs) {
        hash.update(`${output.byteLength}:`)
        hash.update(output)
    }
    return hash.digest('hex')
}
const expectedDigest = digestOutputs(fixtures.map(({bytes}) => bytes))
const methods = {
    slice: (source, start, end) => source.slice(start, end),
    set: (source, start, end) => {
        const owned = new Uint8Array(end - start)
        owned.set(source.subarray(start, end))
        return owned
    },
    aligned: candidateCopy,
    words4: copySharedWords4,
    words8: copySharedWords8,
}
const hostBefore = {loadavg: os.loadavg(), uptimeSeconds: os.uptime()}
const results = []
for (const alignment of Array.from({length: 8}, (_, i) => i)) {
    const spans = fixtures.map(({bytes}) => {
        const viewOffset = 11
        const start = ((alignment - viewOffset) & 7) + 8
        const buffer = new Uint8Array(new SharedArrayBuffer(viewOffset + start + bytes.byteLength), viewOffset)
        buffer.set(bytes, start)
        return {buffer, start, end: start + bytes.byteLength}
    })
    const run = (method) => {
        const outputs = []
        const before = performance.now()
        for (const {buffer, start, end} of spans) { outputs.push(method(buffer, start, end)) }
        const elapsedMs = performance.now() - before
        for (let i = 0; i < outputs.length; ++i) {
            if (!(outputs[i].buffer instanceof ArrayBuffer) || outputs[i].byteOffset !== 0 || outputs[i].buffer.byteLength !== fixtures[i].bytes.byteLength) {
                throw new Error('Output ownership or allocation size differs')
            }
        }
        const digest = digestOutputs(outputs)
        if (digest !== expectedDigest) { throw new Error('Copied bytes differ') }
        return {elapsedMs, digest}
    }
    for (let warmup = 0; warmup < 2; ++warmup) {
        for (const method of Object.values(methods)) {
            globalThis.gc?.()
            run(method)
        }
    }
    const observations = []
    const names = Object.keys(methods)
    for (let pass = 0; pass < passes; ++pass) {
        const order = names.slice(pass % names.length).concat(names.slice(0, pass % names.length))
        if (pass % 2 === 1) { order.reverse() }
        for (const name of order) {
            globalThis.gc?.()
            observations.push({pass, arm: name, ...run(methods[name])})
        }
    }
    for (let i = 0; i < spans.length; ++i) {
        const {buffer, start, end} = spans[i]
        if (sha256(buffer.subarray(start, end)) !== fixtures[i].sha256) { throw new Error('Source bytes mutated') }
    }
    results.push({alignment, sourceViewOffset: 11, sourceStartOffset: spans[0].start, observations})
    process.stderr.write(`Verified alignment ${alignment}: ${observations.length} measurements\n`)
}
for (const {root, file, sha256: expected} of sourceHashes) {
    if (sha256(await readFile(path.join(root, file))) !== expected) { throw new Error('Source changed during cohort') }
}
console.log(JSON.stringify({
    boundary: 'One exact-size owned copy of every complete canonical content slab from the locked full corpus; parser, ZIP I/O, GC and output verification are excluded from timing',
    layout: 'Real canonical slab bytes and production byte-balanced group sizes, repacked into shared buffers at all eight absolute alignments with nonzero view and start offsets; not an exact replay of browser published-span selection',
    dictionary: values.dictionary,
    rows,
    bytesPerArm: fixtures.reduce((total, fixture) => total + fixture.bytes.byteLength, 0),
    groups: fixtures.map(({bytes, ...fixture}) => ({...fixture, byteLength: bytes.byteLength})),
    requestedGroupCount,
    options,
    baselineCommit: execFileSync('git', ['-C', baselineRoot, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim(),
    candidateCommit: execFileSync('git', ['-C', candidateRoot, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim(),
    sourceHashes,
    helperSha256: sha256(helperSource),
    archiveSha256: spec.sha256,
    lockSha256: sha256(lockBytes),
    wasmSha256: sha256(wasmBytes),
    runnerSha256: sha256(await readFile(fileURLToPath(import.meta.url))),
    originalRunnerSha256: sha256(await readFile(new URL('./cache-copy-screen.mjs', import.meta.url))),
    prototypeNote: 'Exploratory Uint32 copy candidates, four/eight-word unrolling; raw integers preserve all bit patterns; private sources retain slice; exact-size allocation and private ownership unchanged',
    outputDigest: expectedDigest,
    node: process.version,
    v8: process.versions.v8,
    cpuCount: os.cpus().length,
    hostBefore,
    hostAfter: {loadavg: os.loadavg(), uptimeSeconds: os.uptime()},
    results,
    lifetimeMaxRssKiB: process.resourceUsage().maxRSS,
    afterVerificationMemory: process.memoryUsage(),
}))
