import assert from 'node:assert/strict'
import {readFile, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {fileURLToPath} from 'node:url'
import {copySharedWords4, copySharedWords8} from './uint32-copy-prototype.mjs'

const output = process.argv[2]
assert(output, 'Pass a new output JSON file')
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const methods = {words4: copySharedWords4, words8: copySharedWords8}
const Shared = globalThis.SharedArrayBuffer
assert.equal(typeof Shared, 'function')
const initialSeed = 0x4521ac39
let seed = initialSeed
const random = () => {
    seed ^= seed << 13
    seed ^= seed >>> 17
    seed ^= seed << 5
    return seed >>> 0
}
let cases = 0
let methodCalls = 0
const digest = createHash('sha256')

function check(length, viewOffset, start, shared, endAtBufferBoundary, hiddenConstructor = false) {
    const size = viewOffset + start + length + (endAtBufferBoundary ? 0 : 19)
    const backing = shared ? new Shared(size) : new ArrayBuffer(size)
    const all = new Uint8Array(backing)
    for (let i = 0; i < all.length; ++i) all[i] = random() & 255
    // Include bit patterns that would be unsafe to reinterpret as Float64.
    const patterns = [0xffffffff, 0x7ff00000, 0x7ff80000, 0xfff00000, 0x00000001, 0x80000000, 0x00000000, 0x7fffffff]
    const patternBytes = new Uint8Array(new Uint32Array(patterns).buffer)
    for (let i = 0; i < Math.min(length, patternBytes.length); ++i) all[viewOffset + start + i] = patternBytes[i]
    const source = new Uint8Array(backing, viewOffset)
    const original = new Uint8Array(all)
    const expected = new Uint8Array(length)
    for (let i = 0; i < length; ++i) expected[i] = all[viewOffset + start + i]
    if (hiddenConstructor) globalThis.SharedArrayBuffer = undefined
    try {
        for (const [name, method] of Object.entries(methods)) {
            all.set(original)
            const owned = method(source, start, start + length)
            assert(owned instanceof Uint8Array, name)
            assert(owned.buffer instanceof ArrayBuffer, name)
            assert.notEqual(owned.buffer, source.buffer, name)
            assert.equal(owned.byteOffset, 0, name)
            assert.equal(owned.byteLength, length, name)
            assert.equal(owned.buffer.byteLength, length, name)
            assert.equal(Buffer.compare(owned, expected), 0, JSON.stringify({name, length, viewOffset, start, shared, endAtBufferBoundary, hiddenConstructor}))
            assert.equal(Buffer.compare(all, original), 0, 'Source including guards changed')
            source.fill(0x5a, start, start + length)
            assert.equal(Buffer.compare(owned, expected), 0, 'Owned copy changed after source reuse')
            owned.fill(0xa5)
            assert(source.subarray(start, start + length).every((x) => x === 0x5a), 'Result aliases source')
            ++methodCalls
        }
    } finally {
        if (hiddenConstructor) globalThis.SharedArrayBuffer = Shared
    }
    digest.update(expected)
    ++cases
}

try {
    for (const shared of [false, true]) {
        for (let viewOffset = 0; viewOffset < 16; ++viewOffset) {
            for (let start = 0; start < 16; ++start) {
                for (let length = 0; length <= 80; ++length) {
                    check(length, viewOffset, start, shared, (length & 1) === 0)
                }
            }
        }
    }
    const sizes = [127, 128, 129, 255, 256, 257, 511, 512, 513, 1023, 1024, 1025, 4095, 4096, 4097, 65533, 65534, 65535, 65536, 65537, 65538, 65539, 1048573, 1048574, 1048575, 1048576, 1048577, 1048578, 1048579]
    for (const shared of [false, true]) {
        for (let alignment = 0; alignment < 16; ++alignment) {
            for (const length of sizes) {
                check(length, 11, ((alignment - 11) & 15) + 16, shared, true)
            }
        }
    }
    for (let alignment = 0; alignment < 16; ++alignment) {
        for (const length of [0, 1, 2, 3, 4, 15, 16, 17, 63, 64, 65, 4097]) {
            check(length, 7, ((alignment - 7) & 15) + 16, true, true, true)
        }
    }
    const report = {
        complete: true, timing: false, node: process.version, v8: process.versions.v8,
        cases, methodCalls, seed: initialSeed, outputDigest: digest.digest('hex'),
        sourceSha256: sha256(await readFile(new URL('./uint32-copy-prototype.mjs', import.meta.url))),
        runnerSha256: sha256(await readFile(fileURLToPath(import.meta.url))),
        coverage: 'Private and shared buffers; all view/start residues modulo16; lengths0..80; word/unroll/page/MiB tails; physical source EOF; arbitrary bytes including floating-point special-value bit patterns; hidden SharedArrayBuffer constructor; exact-size private ownership after source reuse; source and guards untouched during copy',
    }
    await writeFile(output, `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'})
    process.stdout.write(`${JSON.stringify(report, null, 2)}\n`)
} catch (error) {
    await writeFile(output, `${JSON.stringify({complete: false, cases, methodCalls, seed: initialSeed, error: String(error), stack: error.stack}, null, 2)}\n`, {flag: 'wx'})
    throw error
}
