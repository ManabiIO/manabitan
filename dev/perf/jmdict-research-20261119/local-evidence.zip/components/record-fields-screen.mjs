import {readFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import {parseArgs} from 'node:util'
import {fileURLToPath, pathToFileURL} from 'node:url'
import path from 'node:path'
import os from 'node:os'

const {values} = parseArgs({options: {
    'source-root': {type: 'string'},
    'fixture-root': {type: 'string'},
    dictionary: {type: 'string', default: 'jmdict'},
    'cache-dir': {type: 'string'},
    passes: {type: 'string', default: '8'},
}})
const sourceRoot = path.resolve(values['source-root'])
const fixtureRoot = path.resolve(values['fixture-root'] ?? sourceRoot)
const cacheDir = path.resolve(values['cache-dir'] ?? path.join(fixtureRoot, 'builds/e2e-dictionary-cache'))
const passes = Number(values.passes)
if (!Number.isInteger(passes) || passes < 1 || passes > 100) { throw new Error('Invalid pass count') }
if (values.dictionary !== 'jmdict') { throw new Error('This frozen component fixture is for JMdict') }
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const load = async (relative) => await import(pathToFileURL(path.join(fixtureRoot, relative)))
const {ZipReader, Uint8ArrayReader, Uint8ArrayWriter} = await load('node_modules/@zip.js/zip.js/index.js')
const parser = await load('ext/js/dictionary/term-bank-wasm-parser.js')
const prep = await load('ext/js/dictionary/term-lookup-index-preparation.js')
const {snapshotTermBankExperiments} = await load('ext/js/dictionary/term-bank-experiments.js')
const {RAW_TERM_CONTENT_COMPACT_BLOCK_REFERENCE_BYTES} = await load('ext/js/dictionary/raw-term-content.js')
const {TermRecordOpfsStore} = await import(pathToFileURL(path.join(sourceRoot, 'ext/js/dictionary/term-record-opfs-store.js')))
const sourceFiles = [
    'ext/js/dictionary/term-record-opfs-store.js',
    'ext/js/dictionary/term-lookup-index-preparation.js',
    'ext/js/dictionary/term-lookup-index.js',
    'ext/js/dictionary/term-record-preinterned-plan.js',
    'ext/js/dictionary/term-key-hash.js',
]
const sourceHashes = Object.fromEntries(await Promise.all(sourceFiles.map(async (file) => [file, sha256(await readFile(path.join(sourceRoot, file)))])))
const fixtureFiles = [
    'ext/js/dictionary/term-bank-wasm-parser.js',
    'ext/js/dictionary/term-bank-experiments.js',
    'ext/js/dictionary/term-lookup-index-preparation.js',
    'ext/js/dictionary/term-lookup-index.js',
    'ext/js/dictionary/term-record-preinterned-plan.js',
    'ext/js/dictionary/raw-term-content.js',
]
const fixtureHashes = Object.fromEntries(await Promise.all(fixtureFiles.map(async (file) => [file, sha256(await readFile(path.join(fixtureRoot, file)))])))
const lockBytes = await readFile(path.join(fixtureRoot, 'test/perf/dictionaries.lock.json'))
const spec = JSON.parse(lockBytes).dictionaries[values.dictionary]
const archive = await readFile(path.join(cacheDir, spec.cacheFile))
if (sha256(archive) !== spec.sha256) { throw new Error('Archive hash differs from lock') }
const wasmBytes = await readFile(path.join(fixtureRoot, 'ext/lib/term-bank-parser.wasm'))
parser.setTermBankWasmModule(await WebAssembly.compile(wasmBytes))
const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)))
const sources = []
try {
    const entries = (await reader.getEntries()).filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename))
        .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
    for (const entry of entries) {
        sources.push(await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}))
    }
} finally { await reader.close() }
const options = {
    ...snapshotTermBankExperiments(),
    singleChunk: true,
    emitTermByteLists: false,
    computeContentHashes: true,
    emitContentSlab: true,
    emitTokenBinaryContent: true,
    mediaHintFastScan: true,
    validateGlossaryTypes: true,
    prepareLookupIndexes: true,
}
const parserSource = await readFile(path.join(fixtureRoot, 'ext/js/dictionary/term-bank-wasm-parser.js'), 'utf8')
const extract = (name) => {
    const match = parserSource.match(new RegExp(`^function ${name}\\([^]*?^}`, 'm'))
    if (!match) { throw new Error(`Missing production grouping function ${name}`) }
    return match[0]
}
const partition = new Function(`${extract('partitionSourceBanks')}\n${extract('getPartitionSourceByteLength')}\nreturn partitionSourceBanks`)()
if (!options.experimentalParserWorkers3) { throw new Error('Production parser worker count assumption changed') }
const totalSourceBytes = sources.reduce((total, source) => total + source.byteLength, 0)
const requestedGroupCount = Math.max(3 * 4, Math.ceil(totalSourceBytes / (24 * 1024 * 1024)))
const groups = partition(sources, totalSourceBytes, requestedGroupCount)
const assertOwnedViews = (value, seen = new Set()) => {
    if (typeof value !== 'object' || value === null || seen.has(value)) { return }
    seen.add(value)
    if (ArrayBuffer.isView(value)) {
        if (!(value.buffer instanceof ArrayBuffer)) { throw new Error('Record fixture retained borrowed shared memory') }
        return
    }
    for (const entry of value instanceof Map ? value.values() : Object.values(value)) { assertOwnedViews(entry, seen) }
}
const fixtures = []
let totalRows = 0
let referenceOffset = 0
const inputDigest = createHash('sha256')
const updateView = (hash, view) => hash.update(new Uint8Array(view.buffer, view.byteOffset, view.byteLength))
for (const group of groups) {
    await parser.parseTermBankWithWasmColumnChunks(group, 3, (nativeChunk) => {
        const chunk = parser.copyWasmBackedColumnChunk(nativeChunk)
        let indexes = chunk.preparedLookupIndexes
        if (!indexes) { indexes = prep.prepareTermLookupIndexesFromPreinternedPlan(chunk, null, options)?.indexes }
        if (!prep.hasCompletePreparedTermLookupIndexes(indexes, chunk.rowCount)) { throw new Error('Incomplete prepared lookup indexes') }
        if (!(chunk.contentMetaList instanceof Uint32Array)) { throw new Error('Missing real content lengths') }
        const uniqueIndexList = chunk.contentUniqueIndexList?.slice() ?? Uint32Array.from({length: chunk.rowCount}, (_, i) => i)
        let uniqueCount = 0
        for (const unique of uniqueIndexList) { uniqueCount = Math.max(uniqueCount, unique + 1) }
        const offsets = new Float64Array(uniqueCount)
        const lengths = new Uint32Array(uniqueCount)
        const seen = new Uint8Array(uniqueCount)
        for (let row = 0; row < chunk.rowCount; ++row) {
            const unique = uniqueIndexList[row]
            const length = chunk.contentMetaList[row * 4 + 1]
            if (seen[unique] === 0) {
                offsets[unique] = referenceOffset
                lengths[unique] = length
                referenceOffset += RAW_TERM_CONTENT_COMPACT_BLOCK_REFERENCE_BYTES
                seen[unique] = 1
            } else if (lengths[unique] !== length) { throw new Error('Inconsistent duplicate content length') }
        }
        const fixture = {
            dictionary: spec.expectedTitle,
            rowCount: chunk.rowCount,
            expressionBytesList: [],
            readingBytesList: [],
            readingEqualsExpressionList: chunk.readingEqualsExpressionList.slice(),
            scoreList: chunk.scoreList.slice(),
            sequenceList: chunk.sequenceList.slice(),
            termRecordPreinternedPlan: chunk.termRecordPreinternedPlan,
            preparedLookupIndexes: indexes,
            resolvedContentReferences: {uniqueIndexList, offsets, lengths},
        }
        assertOwnedViews(fixture)
        for (const view of [fixture.scoreList, fixture.sequenceList, fixture.readingEqualsExpressionList, uniqueIndexList, offsets, lengths]) {
            updateView(inputDigest, view)
        }
        for (const [key, index] of fixture.preparedLookupIndexes) {
            inputDigest.update(key)
            inputDigest.update(index.bytes)
        }
        fixtures.push(fixture)
        totalRows += chunk.rowCount
    }, 2048, options)
}
if (totalRows !== spec.termRows) { throw new Error(`Incomplete corpus: ${totalRows}`) }
// Preparation retains only row columns and lookup indexes. Parsing, ZIP I/O,
// canonicalization, content compression, OPFS and UI are outside this boundary.
sources.length = 0
groups.length = 0
const store = new TermRecordOpfsStore()
let outputs = []
store._appendEncodedChunk = async (_state, firstId, count, _name, base, lookup, fields, format) => {
    outputs.push({firstId, count, base, lookup, fields, format})
}
const emptyOffsets = new Float64Array(0)
const emptyLengths = new Uint32Array(0)
const execute = async () => {
    outputs = []
    let firstId = 1
    const totals = {validationMs: 0, recordFieldEncodeMs: 0, lookupIndexEncodeMs: 0}
    const before = performance.now()
    for (const chunk of fixtures) {
        const metrics = await store._encodeAndAppendArtifactChunkForState(
            {}, chunk, firstId, emptyOffsets, emptyLengths,
            chunk.termRecordPreinternedPlan, 'raw', chunk.preparedLookupIndexes,
        )
        for (const name of Object.keys(totals)) { totals[name] += metrics[name] }
        firstId += chunk.rowCount
    }
    const elapsedMs = performance.now() - before
    return {elapsedMs, ...totals}
}
for (let warmup = 0; warmup < 2; ++warmup) { await execute() }
const observations = []
let expectedDigest = null
let encodedBytes = 0
const hostBefore = {loadavg: os.loadavg(), uptimeSeconds: os.uptime()}
for (let pass = 0; pass < passes; ++pass) {
    globalThis.gc?.()
    const observation = await execute()
    // Full output verification is outside the timing boundary.
    const hash = createHash('sha256')
    let rows = 0
    let bytes = 0
    for (const output of outputs) {
        hash.update(JSON.stringify([output.firstId, output.count, output.base, output.format]))
        hash.update(output.lookup)
        hash.update(output.fields)
        rows += output.count
        bytes += output.fields.byteLength
    }
    if (rows !== totalRows) { throw new Error('Missing encoded rows') }
    const digest = hash.digest('hex')
    if (expectedDigest !== null && expectedDigest !== digest) { throw new Error('Output changed between passes') }
    expectedDigest = digest
    encodedBytes = bytes
    observations.push({...observation, digest, rows})
}
for (const file of sourceFiles) {
    if (sha256(await readFile(path.join(sourceRoot, file))) !== sourceHashes[file]) { throw new Error('Source changed during cohort') }
}
for (const file of fixtureFiles) {
    if (sha256(await readFile(path.join(fixtureRoot, file))) !== fixtureHashes[file]) { throw new Error('Fixture source changed during cohort') }
}
console.log(JSON.stringify({
    boundary: 'Real locked-corpus row validation, record-field layout and encoding with prepared lookup indexes; no persistence or UI',
    contentOffsets: `Deterministic ${RAW_TERM_CONTENT_COMPACT_BLOCK_REFERENCE_BYTES}-byte reference slots; real canonical lengths and per-parser-group unique references; no global dedup or actual OPFS allocation`,
    dictionary: values.dictionary,
    sourceRoot,
    fixtureRoot,
    commit: execFileSync('git', ['-C', sourceRoot, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim(),
    sourceHashes,
    fixtureHashes,
    archiveSha256: spec.sha256,
    lockSha256: sha256(lockBytes),
    wasmSha256: sha256(wasmBytes),
    runnerSha256: sha256(await readFile(fileURLToPath(import.meta.url))),
    inputDigest: inputDigest.digest('hex'),
    outputDigest: expectedDigest,
    encodedBytes,
    rows: totalRows,
    groups: fixtures.length,
    requestedGroupCount,
    grouping: 'Production byte-balanced plain-dictionary planner with 3 workers and 4 groups per worker',
    options,
    node: process.version,
    cpuCount: os.cpus().length,
    hostBefore,
    hostAfter: {loadavg: os.loadavg(), uptimeSeconds: os.uptime()},
    observations,
    equalWorkMeanMs: observations.reduce((total, observation) => total + observation.elapsedMs, 0) / observations.length,
    lifetimeMaxRssKiB: process.resourceUsage().maxRSS,
    afterVerificationMemory: process.memoryUsage(),
}))
