import {readFile, mkdir, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import {parseArgs} from 'node:util'
import {fileURLToPath, pathToFileURL} from 'node:url'
import path from 'node:path'
import os from 'node:os'

const {values} = parseArgs({options: {
    'baseline-root': {type: 'string'},
    'candidate-root': {type: 'string'},
    dictionary: {type: 'string', default: 'jmdict'},
    'snapshot-dir': {type: 'string'},
    'capture-only': {type: 'boolean', default: false},
}})
const baselineRoot = path.resolve(values['baseline-root'])
const candidateRoot = path.resolve(values['candidate-root'])
const snapshotDirectory = path.resolve(values['snapshot-dir'])
await mkdir(snapshotDirectory, {recursive: true})
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const load = async (relative) => await import(pathToFileURL(path.join(baselineRoot, relative)))
const trackedFiles = [
    [baselineRoot, 'ext/js/dictionary/dictionary-database.js'],
    [baselineRoot, 'ext/js/dictionary/term-bank-wasm-parser.js'],
    [baselineRoot, 'ext/js/dictionary/term-bank-experiments.js'],
    [baselineRoot, 'ext/js/dictionary/term-content-canonical-scan.js'],
    [baselineRoot, 'ext/js/dictionary/term-content-canonical-layout.js'],
    [baselineRoot, 'ext/js/dictionary/term-content-metadata-arena.js'],
    [baselineRoot, 'ext/js/dictionary/wasm/term-content-canonical-scan-v1.c'],
    [candidateRoot, 'ext/js/dictionary/wasm/term-content-canonical-scan-v1.c'],
    [baselineRoot, 'dev/data/dictionary-wasm/manifest.json'],
    [candidateRoot, 'dev/data/dictionary-wasm/manifest.json'],
    [baselineRoot, 'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm'],
    [candidateRoot, 'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm'],
]
const sourceFiles = await Promise.all(trackedFiles.map(async ([root, file]) => ({root, file, bytes: await readFile(path.join(root, file))})))
const sourceHashes = sourceFiles.map(({root, file, bytes}) => ({root, file, sha256: sha256(bytes)}))
const getSource = (root, file) => sourceFiles.find((entry) => entry.root === root && entry.file === file).bytes
const modules = {}
const moduleHashes = {}
for (const [arm, root] of [['A', baselineRoot], ['B', candidateRoot]]) {
    const binary = getSource(root, 'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm')
    const manifest = JSON.parse(getSource(root, 'dev/data/dictionary-wasm/manifest.json'))
    const target = manifest.targets.find(({name}) => name === 'term-content-canonical-scan-v1.wasm')
    moduleHashes[arm] = sha256(binary)
    if (moduleHashes[arm] !== target.sha256) { throw new Error('Native module differs from its pinned manifest') }
    modules[arm] = await WebAssembly.compile(binary)
}
const parserSource = getSource(baselineRoot, 'ext/js/dictionary/term-bank-wasm-parser.js').toString()
const extract = (source, name) => {
    const match = source.match(new RegExp(`^function ${name}\\([^]*?^}`, 'm'))
    if (!match) { throw new Error(`Missing exact source function ${name}`) }
    return match[0]
}
const partitionSource = extract(parserSource, 'partitionSourceBanks')
const partitionLengthSource = extract(parserSource, 'getPartitionSourceByteLength')
const partition = new Function(`${partitionSource}\n${partitionLengthSource}\nreturn partitionSourceBanks`)()
const {ZipReader, Uint8ArrayReader, Uint8ArrayWriter} = await load('node_modules/@zip.js/zip.js/index.js')
const parser = await load('ext/js/dictionary/term-bank-wasm-parser.js')
const {snapshotTermBankExperiments} = await load('ext/js/dictionary/term-bank-experiments.js')
const {DictionaryDatabase} = await load('ext/js/dictionary/dictionary-database.js')
const {NativeCanonicalScanner} = await load('ext/js/dictionary/term-content-canonical-scan.js')
const {CANONICAL_SCAN_LAYOUT: layout, CANONICAL_SCAN_EXACT_BATCH_SIZE: exactBatchSize} = await load('ext/js/dictionary/term-content-canonical-layout.js')
const lockBytes = await readFile(path.join(baselineRoot, 'test/perf/dictionaries.lock.json'))
const spec = JSON.parse(lockBytes).dictionaries[values.dictionary]
if (!spec) { throw new Error('Unknown locked dictionary') }
const archive = await readFile(path.join(baselineRoot, 'builds/e2e-dictionary-cache', spec.cacheFile))
if (sha256(archive) !== spec.sha256) { throw new Error('Dictionary SHA-256 differs from lock') }
const parserWasmBytes = await readFile(path.join(baselineRoot, 'dev/data/dictionary-wasm/term-bank-parser.wasm'))
parser.setTermBankWasmModule(await WebAssembly.compile(parserWasmBytes))
const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)))
const sources = []
try {
    const entries = (await reader.getEntries()).filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename))
        .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
    for (const entry of entries) {
        sources.push(await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}))
    }
} finally { await reader.close() }
const options = {
    ...snapshotTermBankExperiments(),
    singleChunk: true,
    emitTermByteLists: false,
    computeContentHashes: true,
    emitContentSlab: true,
    emitTokenBinaryContent: true,
    mediaHintFastScan: true,
    validateGlossaryTypes: true,
    prepareLookupIndexes: true,
}
if (!options.experimentalParserWorkers3) { throw new Error('Production parser worker count assumption changed') }
const totalSourceBytes = sources.reduce((total, source) => total + source.byteLength, 0)
const requestedGroupCount = Math.max(3 * 4, Math.ceil(totalSourceBytes / (24 * 1024 * 1024)))
const groups = partition(sources, totalSourceBytes, requestedGroupCount)
const database = new DictionaryDatabase()
const persistedBytes = []
const groupReports = []
const fixtures = []
let activeFixture = null
let currentGroup = 0
let totalRows = 0
let simulatedReadCount = 0
let nextStorageOffset = 1

// Keep the ordinary exact matcher and publisher; only durable storage is
// simulated by synthetic offsets into retained, real canonical content bytes.
database._readTermEntryContentBytesDetailed = async (offset, length, dictName) => {
    const bytes = persistedBytes[offset]
    if (!bytes || bytes.byteLength !== length || dictName !== 'raw-v6') { throw new Error('Invalid simulated content read') }
    ++simulatedReadCount
    return {status: 'ok', bytes}
}
const hashOutput = (buffer) => {
    const header = new Uint32Array(buffer, 1024, 7)
    const hash = createHash('sha256')
    hash.update(new Uint8Array(header.buffer, header.byteOffset, header.byteLength))
    for (let column = 0; column < 6; ++column) {
        hash.update(new Uint8Array(buffer, layout.OUT + column * layout.MAX * 4, header[2] * 4))
    }
    hash.update(new Uint8Array(buffer, layout.JOURNAL, header[0] * 12))
    hash.update(new Uint8Array(buffer, layout.EXACT, header[3] * 8))
    return hash.digest('hex')
}
const scanner = new NativeCanonicalScanner({
    loadModule: async () => modules.A,
    hooks: {
        beforeNative({a, beforeDense, beforePending}) {
            if (activeFixture !== null) { throw new Error('Previous native capture did not complete') }
            const before = new Uint8Array(a.memory.buffer).slice()
            const config = new Uint32Array(before.buffer, 1088, 22)
            activeFixture = {
                index: fixtures.length,
                group: currentGroup,
                before,
                beforeSha256: sha256(before),
                beforeDense,
                beforePending,
                publishedCount: database._termEntryContentMetaHashPairCount,
                memoryBytes: before.byteLength,
                denseCapacity: a.state.length,
                slotCapacity: a.slots.length,
                config: [...config],
            }
        },
        beforeAdopt() {
            if (activeFixture === null) { throw new Error('Native output has no input capture') }
            const {buffer} = database._termContentMetadataArena.memory
            const header = [...new Uint32Array(buffer, 1024, 7)]
            activeFixture.header = header
            activeFixture.status = header[3] === exactBatchSize ? 1 : 0
            activeFixture.afterSha256 = sha256(new Uint8Array(buffer))
            activeFixture.outputSha256 = hashOutput(buffer)
            fixtures.push(activeFixture)
            activeFixture = null
        },
    },
})
database._nativeCanonicalScanner = scanner
for (const group of groups) {
    const callsBefore = fixtures.length
    await parser.parseTermBankWithWasmColumnChunks(group, 3, async (nativeChunk) => {
        const chunk = parser.copyWasmBackedColumnChunk(nativeChunk, true)
        // The actual worker transport rebases the content view to its slab.
        // Own that slab here so in-memory published storage survives parser reuse.
        chunk.contentBytesBuffer = Uint8Array.from(chunk.contentBytesBuffer)
        chunk.dictionary = spec.expectedTitle
        chunk.dictionaryTotalRows = spec.termRows
        chunk.uniformContentDictName = 'raw-v6'
        chunk.contentDictNameList = null
        const inputHash = createHash('sha256')
        for (const view of [chunk.contentMetaList, chunk.contentUniqueIndexList, chunk.contentDedupPlan.uniqueRowIndexes, chunk.contentDedupPlan.uniqueSignatures]) {
            inputHash.update(new Uint8Array(view.buffer, view.byteOffset, view.byteLength))
        }
        const result = await database._resolveArtifactTermContentDedup(chunk, true)
        if (scanner.stats.fallbacks !== 0) { throw new Error('Fixture used a JavaScript fallback') }
        const pendingOffsets = new Float64Array(result.pendingContentCount)
        const pendingLengths = result.pendingContentSpans.lengths.slice()
        const plan = result.contentDedupPlan
        for (let i = 0; i < result.pendingContentCount; ++i) {
            const offset = result.pendingContentSpans.offsets[i]
            const length = pendingLengths[i]
            const storageOffset = nextStorageOffset++
            pendingOffsets[i] = storageOffset
            persistedBytes[storageOffset] = chunk.contentBytesBuffer.subarray(offset, offset + length)
            const unique = result.pendingPlanUniqueStart === null ? result.pendingPlanUniqueIndexes[i] : result.pendingPlanUniqueStart + i
            plan.resolvedOffsets[unique] = storageOffset
            plan.resolvedLengths[unique] = length
            plan.resolvedFlags[unique] = 1
            if (Array.isArray(plan.resolvedDictNames)) {
                plan.resolvedDictNames[unique] = 'raw-v6'
            } else {
                plan.resolvedUniformDictName = 'raw-v6'
            }
        }
        if (result.pendingContentCount > 0) {
            database._publishArtifactTermContentMetadata({
                ...result,
                count: chunk.rowCount,
                pendingOffsets,
                pendingLengths,
                pendingResolvedDictNames: 'raw-v6',
                contentUniqueIndexList: chunk.contentUniqueIndexList,
                useResolvedContentReferences: chunk.useResolvedContentReferences,
            })
        }
        if (database._termEntryContentMetaHashPairPendingCount !== 0) { throw new Error('Pending metadata survived simulated publication') }
        groupReports.push({
            group: currentGroup,
            banks: group.length,
            rows: chunk.rowCount,
            uniqueRows: plan.uniqueRowIndexes.length,
            pendingRows: result.pendingContentCount,
            persistedHitCount: result.persistedHitCount,
            exactFallbackCount: result.exactFallbackCount,
            nativeCalls: fixtures.length - callsBefore,
            nativeMetrics: result.nativeScanMetrics,
            inputSha256: inputHash.digest('hex'),
            contentSha256: sha256(chunk.contentBytesBuffer),
            contentByteLength: chunk.contentBytesBuffer.byteLength,
            publishedCount: database._termEntryContentMetaHashPairCount,
        })
        totalRows += chunk.rowCount
    }, 2048, options)
    process.stderr.write(`Captured group ${currentGroup}: ${fixtures.length - callsBefore} native calls\n`)
    ++currentGroup
}
if (totalRows !== spec.termRows || groupReports.length !== requestedGroupCount || activeFixture !== null) { throw new Error('Incomplete full-corpus capture') }
const nativeRows = fixtures.reduce((total, fixture) => total + fixture.header[1] - fixture.config[15], 0)
if (nativeRows !== groupReports.reduce((total, group) => total + group.uniqueRows, 0) || nativeRows !== scanner.stats.rows) {
    throw new Error('Native replay does not cover all canonical rows')
}
for (const fixture of fixtures) {
    await writeFile(path.join(snapshotDirectory, `call-${String(fixture.index).padStart(3, '0')}.before.bin`), fixture.before)
}
const fixtureManifest = {
    boundary: 'Native scan_canonical only; full frozen arena restored before every call. Restoration, parsing, allocation, JS adoption, exact matching, simulated publication, hashing and storage are excluded from native timing',
    simulation: 'Production resolver, capacity sizing/rehash, signatures, exact byte matcher and metadata publication; persistence uses synthetic offsets into retained real canonical content. Capture does not perform OPFS, compression or worker scheduling',
    limitation: 'Full-memory restoration warms the input and metadata arena immediately before native entry; this is a diagnostic component replay, not an end-to-end speed or memory claim. Production failure/trap tests remain separate',
    dictionary: values.dictionary,
    rows: totalRows,
    nativeRows,
    requestedGroupCount,
    groups: groupReports,
    calls: fixtures.map(({before, ...fixture}) => fixture),
    snapshotBytes: fixtures.reduce((total, fixture) => total + fixture.memoryBytes, 0),
    simulatedReadCount,
    sourceHashes,
    moduleHashes,
    baselineCommit: execFileSync('git', ['-C', baselineRoot, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim(),
    candidateCommit: execFileSync('git', ['-C', candidateRoot, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim(),
    archiveSha256: spec.sha256,
    lockSha256: sha256(lockBytes),
    parserWasmSha256: sha256(parserWasmBytes),
    runnerSha256: sha256(await readFile(fileURLToPath(import.meta.url))),
    options,
}
await writeFile(path.join(snapshotDirectory, 'manifest.json'), JSON.stringify(fixtureManifest))
if (values['capture-only']) {
    console.log(JSON.stringify(fixtureManifest))
    process.exit(0)
}
const contexts = new Map()
for (const fixture of fixtures) {
    if (contexts.has(fixture.memoryBytes)) { continue }
    const pages = fixture.memoryBytes / 65536
    const memory = new WebAssembly.Memory({initial: pages, maximum: pages})
    const functions = {}
    for (const arm of ['A', 'B']) {
        const exports = new WebAssembly.Instance(modules[arm], {env: {memory}}).exports
        if (exports.canonical_abi_version() !== 1 || exports.canonical_layout_end() !== layout.usedBytes || exports.canonical_prefix_bytes() !== layout.PREFIX || exports.canonical_max_rows() !== layout.MAX) {
            throw new Error('Native replay ABI mismatch')
        }
        functions[arm] = exports.scan_canonical
    }
    contexts.set(fixture.memoryBytes, {memory, bytes: new Uint8Array(memory.buffer), functions})
}
const run = (arm) => {
    let elapsedMs = 0
    const callTimings = []
    const digest = createHash('sha256')
    for (const fixture of fixtures) {
        const context = contexts.get(fixture.memoryBytes)
        context.bytes.set(fixture.before)
        const scan = context.functions[arm]
        const before = performance.now()
        const status = scan()
        const nativeMs = performance.now() - before
        elapsedMs += nativeMs
        const memorySha256 = sha256(context.bytes)
        const outputSha256 = hashOutput(context.memory.buffer)
        const header = [...new Uint32Array(context.memory.buffer, 1024, 7)]
        if (status !== fixture.status || memorySha256 !== fixture.afterSha256 || outputSha256 !== fixture.outputSha256 || JSON.stringify(header) !== JSON.stringify(fixture.header)) {
            throw new Error(`Native output differs for arm ${arm}, call ${fixture.index}: ${JSON.stringify({status, expectedStatus: fixture.status, memorySha256, expectedMemorySha256: fixture.afterSha256, outputSha256, expectedOutputSha256: fixture.outputSha256, header, expectedHeader: fixture.header})}`)
        }
        digest.update(`${fixture.index}:${status}:${memorySha256}:${outputSha256};`)
        callTimings.push(nativeMs)
    }
    return {elapsedMs, callTimings, outputDigest: digest.digest('hex')}
}
for (let warmup = 0; warmup < 2; ++warmup) {
    for (const arm of ['A', 'B']) {
        globalThis.gc?.()
        run(arm)
    }
}
const hostBefore = {loadavg: os.loadavg(), uptimeSeconds: os.uptime()}
const pairs = []
const cohortNames = ['AB', 'AA', 'BB']
for (let pair = 0; pair < 8; ++pair) {
    const cohorts = cohortNames.slice(pair % 3).concat(cohortNames.slice(0, pair % 3))
    for (const cohort of cohorts) {
        const arms = cohort === 'AB' ? [{label: 'A', module: 'A'}, {label: 'B', module: 'B'}] :
            [{label: `${cohort[0]}1`, module: cohort[0]}, {label: `${cohort[0]}2`, module: cohort[0]}]
        if (pair % 2 === 1) { arms.reverse() }
        const observations = []
        for (const arm of arms) {
            globalThis.gc?.()
            observations.push({...arm, ...run(arm.module)})
        }
        pairs.push({pair, cohort, observations})
    }
    process.stderr.write(`Verified pair ${pair + 1}/8 for AB, AA and BB\n`)
}
for (const fixture of fixtures) {
    if (sha256(fixture.before) !== fixture.beforeSha256) { throw new Error('Frozen replay input mutated') }
}
for (const {root, file, sha256: expected} of sourceHashes) {
    if (sha256(await readFile(path.join(root, file))) !== expected) { throw new Error('Source changed during cohort') }
}
console.log(JSON.stringify({
    ...fixtureManifest,
    fixtureManifestSha256: sha256(await readFile(path.join(snapshotDirectory, 'manifest.json'))),
    pairs,
    node: process.version,
    v8: process.versions.v8,
    cpuCount: os.cpus().length,
    hostBefore,
    hostAfter: {loadavg: os.loadavg(), uptimeSeconds: os.uptime()},
    lifetimeMaxRssKiB: process.resourceUsage().maxRSS,
    afterVerificationMemory: process.memoryUsage(),
}))
