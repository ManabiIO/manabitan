// Research-only candidates. The caller owns a validated immutable source span.
// Every result has exactly the requested private allocation, with no padding.

export function copySharedWords4(source, start, end) {
    if (source.buffer instanceof ArrayBuffer) return source.slice(start, end)
    const byteLength = end - start
    const owned = new Uint8Array(byteLength)
    const prefix = (-source.byteOffset - start) & 3
    if (byteLength <= prefix) {
        for (let i = 0; i < byteLength; ++i) owned[i] = source[start + i]
        return owned
    }
    const remaining = byteLength - prefix
    const wordCount = Math.floor(remaining / 4)
    const sourceWords = new Uint32Array(source.buffer, source.byteOffset + start + prefix, wordCount)
    const ownedWords = new Uint32Array(owned.buffer, 0, wordCount)
    let word = 0
    for (; word + 4 <= wordCount; word += 4) {
        ownedWords[word] = sourceWords[word]
        ownedWords[word + 1] = sourceWords[word + 1]
        ownedWords[word + 2] = sourceWords[word + 2]
        ownedWords[word + 3] = sourceWords[word + 3]
    }
    for (; word < wordCount; ++word) ownedWords[word] = sourceWords[word]
    for (let i = wordCount * 4; i < remaining; ++i) owned[i] = source[start + prefix + i]
    if (prefix !== 0) owned.copyWithin(prefix, 0, remaining)
    for (let i = 0; i < prefix; ++i) owned[i] = source[start + i]
    return owned
}

export function copySharedWords8(source, start, end) {
    if (source.buffer instanceof ArrayBuffer) return source.slice(start, end)
    const byteLength = end - start
    const owned = new Uint8Array(byteLength)
    const prefix = (-source.byteOffset - start) & 3
    if (byteLength <= prefix) {
        for (let i = 0; i < byteLength; ++i) owned[i] = source[start + i]
        return owned
    }
    const remaining = byteLength - prefix
    const wordCount = Math.floor(remaining / 4)
    const sourceWords = new Uint32Array(source.buffer, source.byteOffset + start + prefix, wordCount)
    const ownedWords = new Uint32Array(owned.buffer, 0, wordCount)
    let word = 0
    for (; word + 8 <= wordCount; word += 8) {
        ownedWords[word] = sourceWords[word]
        ownedWords[word + 1] = sourceWords[word + 1]
        ownedWords[word + 2] = sourceWords[word + 2]
        ownedWords[word + 3] = sourceWords[word + 3]
        ownedWords[word + 4] = sourceWords[word + 4]
        ownedWords[word + 5] = sourceWords[word + 5]
        ownedWords[word + 6] = sourceWords[word + 6]
        ownedWords[word + 7] = sourceWords[word + 7]
    }
    for (; word < wordCount; ++word) ownedWords[word] = sourceWords[word]
    for (let i = wordCount * 4; i < remaining; ++i) owned[i] = source[start + prefix + i]
    if (prefix !== 0) owned.copyWithin(prefix, 0, remaining)
    for (let i = 0; i < prefix; ++i) owned[i] = source[start + i]
    return owned
}
