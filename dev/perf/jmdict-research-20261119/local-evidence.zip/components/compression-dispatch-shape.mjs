import assert from 'node:assert/strict'
import {readFile, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import path from 'node:path'
import {fileURLToPath, pathToFileURL} from 'node:url'

const workspace = '/workspace/scratch/cb98f2e06b71'
const root = path.join(workspace, 'manabitan')
const fixtureRoot = path.join(workspace, 'canonical-scan-snapshots')
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const manifestBytes = await readFile(path.join(fixtureRoot, 'manifest.json'))
const manifest = JSON.parse(manifestBytes)
const blockSource = await readFile(path.join(root, 'ext/js/dictionary/term-content-block-store.js'), 'utf8')
const databaseSource = await readFile(path.join(root, 'ext/js/dictionary/dictionary-database.js'), 'utf8')
const planSource = blockSource.match(/^function planContentSpansIntoSlabs\([^]*?^}/m)?.[0]
assert(planSource)
const plan = new Function(`${planSource}\nreturn planContentSpansIntoSlabs`)()
const targetExpression = databaseSource.match(/^const TERM_CONTENT_BLOCK_TARGET_BYTES = ([0-9 *]+);$/m)?.[1]
assert(targetExpression)
const targetBytes = new Function(`return ${targetExpression}`)()
const {CANONICAL_SCAN_LAYOUT: layout} = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-content-canonical-layout.js')))
const {snapshotTermBankExperiments} = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-bank-experiments.js')))
const options = snapshotTermBankExperiments()
const compactOptions = {experimentalGenericSpanCompression: options.experimentalGenericSpanCompression}
const wasm = await readFile(path.join(root, 'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm'))
assert.equal(sha256(wasm), manifest.moduleHashes.A)
const module = await WebAssembly.compile(wasm)
const contexts = new Map()
const groups = []
for (const fixture of manifest.calls) {
    let context = contexts.get(fixture.memoryBytes)
    if (!context) {
        const pages = fixture.memoryBytes / 65536
        const memory = new WebAssembly.Memory({initial: pages, maximum: pages})
        const instance = new WebAssembly.Instance(module, {env: {memory}})
        context = {memory, instance}
        contexts.set(fixture.memoryBytes, context)
    }
    const before = await readFile(path.join(fixtureRoot, `call-${String(fixture.index).padStart(3, '0')}.before.bin`))
    assert.equal(sha256(before), fixture.beforeSha256)
    const heap = new Uint8Array(context.memory.buffer)
    heap.set(before)
    const status = context.instance.exports.scan_canonical()
    assert.equal(status, fixture.status)
    assert.equal(sha256(heap), fixture.afterSha256)
    const header = new Uint32Array(context.memory.buffer, 1024, 7)
    const capturedGroup = manifest.groups.find(({group}) => group === fixture.group)
    assert.equal(header[2], capturedGroup.pendingRows)
    const lengths = new Uint32Array(context.memory.buffer, layout.OUT + layout.MAX * 4, header[2])
    const packed = plan(lengths, targetBytes)
    const blocks = [...packed.packedChunkLengths]
    const workerJobs = [0, 0, 0, 0]
    for (let i = 0; i < blocks.length; ++i) ++workerJobs[i % 4]
    groups.push({
        group: fixture.group,
        pendingRows: header[2],
        pendingContentBytes: lengths.reduce((sum, value) => sum + value, 0),
        sourceLengthSha256: sha256(new Uint8Array(lengths.buffer, lengths.byteOffset, lengths.byteLength)),
        blockCount: blocks.length,
        blockBytes: blocks,
        workerJobs,
    })
}
const dispatches = groups.reduce((sum, group) => sum + group.blockCount, 0)
const optionJsonBytes = Buffer.byteLength(JSON.stringify(options))
const compactOptionJsonBytes = Buffer.byteLength(JSON.stringify(compactOptions))
const result = {
    timing: false,
    boundary: 'Exact production block plan from frozen real JMdict pending rows, using the validated native replay snapshots; simulated published storage and no worker execution',
    baselineCommit: manifest.baselineCommit,
    fixtureManifestSha256: sha256(manifestBytes),
    nativeWasmSha256: sha256(wasm),
    driverSha256: sha256(await readFile(fileURLToPath(import.meta.url))),
    blockPlannerSha256: sha256(planSource),
    targetBytes,
    groups,
    dispatches,
    perWorkerBatchDispatches: groups.reduce((sum, group) => sum + group.workerJobs.filter((count) => count > 0).length, 0),
    optionKeys: Object.keys(options),
    optionJsonBytes,
    compactOptionKeys: Object.keys(compactOptions),
    compactOptionJsonBytes,
    totalOptionJsonBytes: optionJsonBytes * dispatches,
    totalCompactOptionJsonBytes: compactOptionJsonBytes * dispatches,
    payloadCaveat: 'JSON byte lengths describe the object payload only. They are not measurements of structured-clone wire bytes or CPU time.',
}
await writeFile(path.join(workspace, 'compression-dispatch-shape.json'), `${JSON.stringify(result, null, 2)}\n`)
console.log(JSON.stringify(result))
