import {readFile, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {pathToFileURL} from 'node:url'
import path from 'node:path'

const root = '/workspace/scratch/cb98f2e06b71'
const baselineRoot = path.join(root, 'manabitan')
const candidateRoot = path.join(root, 'manabitan-publication')
const fixtureRoot = path.join(root, 'canonical-scan-snapshots')
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const relativeSource = 'ext/js/dictionary/dictionary-database.js'
const sourceHashes = await Promise.all([baselineRoot, candidateRoot].map(async (repo) => ({repo, sha256: sha256(await readFile(path.join(repo, relativeSource)))})))
const classes = await Promise.all([baselineRoot, candidateRoot].map(async (repo) => (await import(pathToFileURL(path.join(repo, relativeSource)))).DictionaryDatabase))
const manifestBytes = await readFile(path.join(fixtureRoot, 'manifest.json'))
const manifest = JSON.parse(manifestBytes)
const moduleBytes = await readFile(path.join(baselineRoot, 'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm'))
if (sha256(moduleBytes) !== manifest.moduleHashes.A) { throw new Error('Wrong baseline native module') }
const module = await WebAssembly.compile(moduleBytes)
const {CANONICAL_SCAN_LAYOUT: layout} = await import(pathToFileURL(path.join(baselineRoot, 'ext/js/dictionary/term-content-canonical-layout.js')))
const tableNames = [
    'HashPair', 'Hash1', 'Hash2', 'State', 'Length', 'Id', 'Offset', 'DictNameId',
    'SignaturePresent', 'Signature1', 'Signature2', 'Signature3', 'RecentSourceBatchId', 'RecentSourceOffset',
].map((name) => `_termEntryContentMeta${name}Table`)
const digest = (db, state) => {
    const hash = createHash('sha256')
    for (const name of tableNames) {
        const value = db[name]
        hash.update(name + ':' + value.byteLength + ':')
        hash.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength))
    }
    for (const value of [state.contentOffsets, state.contentLengths]) {
        hash.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength))
    }
    hash.update(JSON.stringify({
        dense: db._termEntryContentMetaDenseCount,
        pending: db._termEntryContentMetaHashPairPendingCount,
        published: db._termEntryContentMetaHashPairCount,
        free: db._termEntryContentMetaFreeIndexes,
        dictNames: db._termEntryContentMetaDictNames,
        collisions: [...db._termEntryContentMetaCollisionsByHashPair],
    }))
    return hash.digest('hex')
}
const groups = []
for (const fixture of manifest.calls) {
    const before = await readFile(path.join(fixtureRoot, `call-${String(fixture.index).padStart(3, '0')}.before.bin`))
    if (sha256(before) !== fixture.beforeSha256) { throw new Error(`Input snapshot mismatch ${fixture.index}`) }
    const memory = new WebAssembly.Memory({initial: before.length / 65536, maximum: before.length / 65536})
    new Uint8Array(memory.buffer).set(before)
    const native = new WebAssembly.Instance(module, {env: {memory}})
    if (native.exports.scan_canonical() !== fixture.status || sha256(new Uint8Array(memory.buffer)) !== fixture.afterSha256) {
        throw new Error(`Native output snapshot mismatch ${fixture.index}`)
    }
    const buffer = memory.buffer
    const header = new Uint32Array(buffer, 1024, 7)
    const config = new Uint32Array(buffer, 1088, 22)
    const count = header[2]
    const columns = Array.from({length: 6}, (_, i) => new Uint32Array(buffer, layout.OUT + i * layout.MAX * 4, count))
    const tables = {
        HashPair: new Uint32Array(buffer, config[0], config[1]),
        Hash1: new Uint32Array(buffer, config[2], config[10]),
        Hash2: new Uint32Array(buffer, config[3], config[10]),
        State: new Uint8Array(buffer, config[4], config[10]),
        Length: new Uint32Array(buffer, config[5], config[10]),
        SignaturePresent: new Uint8Array(buffer, config[6], config[10]),
        Signature1: new Uint32Array(buffer, config[7], config[10]),
        Signature2: new Uint32Array(buffer, config[8], config[10]),
        Signature3: new Uint32Array(buffer, config[9], config[10]),
    }
    const results = []
    for (let arm = 0; arm < classes.length; ++arm) {
        const db = new classes[arm]()
        db._resizeTermContentMetadataArena(config[10], config[1])
        for (const [name, source] of Object.entries(tables)) { db[`_termEntryContentMeta${name}Table`].set(source) }
        db._termEntryContentMetaDenseCount = header[5]
        db._termEntryContentMetaHashPairPendingCount = fixture.beforePending + header[0]
        db._termEntryContentMetaHashPairCount = fixture.publishedCount
        // Earlier published storage fields are not part of the native captures.
        // Equal sentinels prove publication leaves those rows untouched.
        db._termEntryContentMetaIdTable.fill(17)
        db._termEntryContentMetaOffsetTable.fill(2 ** 40 + 17)
        db._termEntryContentMetaDictNameIdTable.fill(0)
        db._internTermEntryContentMetaDictName('prior-sentinel')
        const state = {
            count,
            contentOffsets: new Float64Array(count),
            contentLengths: new Uint32Array(count),
            resolvedContentDictNames: 'raw-v6',
            pendingRowToUniqueIndex: Int32Array.from({length: count}, (_, i) => i),
            pendingContentBytes: [],
            pendingContentHash1s: Uint32Array.from(columns[2]),
            pendingContentHash2s: Uint32Array.from(columns[3]),
            pendingOffsets: Float64Array.from({length: count}, (_, i) => 2 ** 40 + fixture.beforeDense + i * 3),
            pendingLengths: Uint32Array.from(columns[1]),
            pendingResolvedDictNames: 'raw-v6',
            pendingContentSpans: null,
            stagedContentMetadata: {indexes: Int32Array.from(columns[5]), active: true},
            metadataValidated: true,
        }
        let admitted = null
        if (arm === 1) {
            const helper = db._tryPublishContiguousArtifactTermContentMetadata
            db._tryPublishContiguousArtifactTermContentMetadata = function (...args) {
                admitted = helper.apply(this, args)
                return admitted
            }
        }
        const beforePublication = digest(db, state)
        const result = db._publishArtifactTermContentMetadata(state)
        const afterPublication = digest(db, state)
        if (db._termEntryContentMetaHashPairPendingCount !== fixture.beforePending || db._termEntryContentMetaHashPairCount !== fixture.publishedCount + count) {
            throw new Error(`Incorrect publication counters ${fixture.group}/${arm}`)
        }
        db._rollbackStagedArtifactTermContentMetadata(state.stagedContentMetadata)
        const afterRollback = digest(db, state)
        results.push({arm, admitted, result, beforePublication, afterPublication, afterRollback})
    }
    if (results[1].admitted !== true || results[0].result !== results[1].result) { throw new Error(`Candidate did not admit actual pending columns ${fixture.group}`) }
    for (const key of ['beforePublication', 'afterPublication', 'afterRollback']) {
        if (results[0][key] !== results[1][key]) { throw new Error(`Publication parity mismatch ${fixture.group}/${key}`) }
    }
    groups.push({group: fixture.group, pendingRows: count, ...results[1]})
}
for (const source of sourceHashes) {
    if (sha256(await readFile(path.join(source.repo, relativeSource))) !== source.sha256) { throw new Error('Source changed during check') }
}
const report = {
    purpose: 'Timing-free original baseline versus actual candidate publisher/rollback parity on all saved full-corpus native pending outputs',
    limitation: 'Native snapshots and pending hashes/lengths/indexes are actual captured JMdict outputs. Persisted offsets are valid synthetic Float64 values above 2^40, the dictionary is uniform raw-v6, metadataValidated is true, and earlier storage columns use equal sentinels. Cache source spans are omitted. This verifies table/counter/projection/rollback parity, not browser scheduling, compression or OPFS.',
    baselineCommit: manifest.baselineCommit,
    archiveSha256: manifest.archiveSha256,
    captureManifestSha256: sha256(manifestBytes),
    nativeModuleSha256: sha256(moduleBytes),
    sourceHashes,
    groups,
    admittedGroups: groups.length,
    admittedPendingRows: groups.reduce((n, group) => n + group.pendingRows, 0),
    sourceRows: manifest.rows,
    runnerSha256: sha256(await readFile(new URL(import.meta.url))),
}
await writeFile(path.join(root, 'metadata-publication-parity.json'), JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify({admittedGroups: report.admittedGroups, admittedPendingRows: report.admittedPendingRows, exactTablesCountersProjectionsRollback: true, sourceHashes}))
