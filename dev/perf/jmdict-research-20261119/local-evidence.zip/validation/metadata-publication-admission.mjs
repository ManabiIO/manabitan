import {readFile, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {pathToFileURL} from 'node:url'
import path from 'node:path'

const root = '/workspace/scratch/cb98f2e06b71'
const repo = path.join(root, 'manabitan')
const fixtureRoot = path.join(root, 'canonical-scan-snapshots')
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const manifestBytes = await readFile(path.join(fixtureRoot, 'manifest.json'))
const manifest = JSON.parse(manifestBytes)
const moduleBytes = await readFile(path.join(repo, 'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm'))
if (sha256(moduleBytes) !== manifest.moduleHashes.A) { throw new Error('Wrong baseline module') }
const module = await WebAssembly.compile(moduleBytes)
const {CANONICAL_SCAN_LAYOUT: layout} = await import(pathToFileURL(path.join(repo, 'ext/js/dictionary/term-content-canonical-layout.js')))
const groups = []
for (const fixture of manifest.calls) {
    const before = await readFile(path.join(fixtureRoot, `call-${String(fixture.index).padStart(3, '0')}.before.bin`))
    if (sha256(before) !== fixture.beforeSha256) { throw new Error(`Input snapshot mismatch ${fixture.index}`) }
    const memory = new WebAssembly.Memory({initial: before.length / 65536, maximum: before.length / 65536})
    new Uint8Array(memory.buffer).set(before)
    const native = new WebAssembly.Instance(module, {env: {memory}})
    const status = native.exports.scan_canonical()
    if (status !== fixture.status || sha256(new Uint8Array(memory.buffer)) !== fixture.afterSha256) {
        throw new Error(`Full output snapshot mismatch ${fixture.index}`)
    }
    const buffer = memory.buffer
    const header = new Uint32Array(buffer, 1024, 7)
    const config = new Uint32Array(buffer, 1088, 22)
    const count = header[2]
    const columns = Array.from({length: 6}, (_, i) => new Uint32Array(buffer, layout.OUT + i * layout.MAX * 4, count))
    const hash1Table = new Uint32Array(buffer, config[2], config[10])
    const hash2Table = new Uint32Array(buffer, config[3], config[10])
    const stateTable = new Uint8Array(buffer, config[4], config[10])
    const lengthTable = new Uint32Array(buffer, config[5], config[10])
    let contiguous = true
    let witnesses = true
    for (let i = 0; i < count; ++i) {
        const index = columns[5][i]
        if (index !== fixture.beforeDense + i) { contiguous = false }
        if (stateTable[index] !== 2 || hash1Table[index] !== columns[2][i] || hash2Table[index] !== columns[3][i] || lengthTable[index] !== columns[1][i]) {
            witnesses = false
        }
    }
    const group = manifest.groups[fixture.group]
    const allPendingRowsRepresented = count === group.pendingRows
    if (!contiguous || !witnesses || !allPendingRowsRepresented) { throw new Error(`Admission failed for ${fixture.group}`) }
    groups.push({group: fixture.group, count, firstIndex: fixture.beforeDense, endIndex: fixture.beforeDense + count, contiguous, witnesses, allPendingRowsRepresented, exactPersistedHits: group.persistedHitCount})
}
const result = {
    purpose: 'Read-only admission audit, no timing; exact baseline native replay of all saved full-corpus snapshots',
    baselineCommit: manifest.baselineCommit,
    archiveSha256: manifest.archiveSha256,
    captureManifestSha256: sha256(manifestBytes),
    nativeModuleSha256: sha256(moduleBytes),
    groups,
    eligibleGroups: groups.length,
    eligiblePendingRows: groups.reduce((n, group) => n + group.count, 0),
    canonicalRows: manifest.nativeRows,
    sourceRows: manifest.rows,
    storageAdmission: 'Replay capture constructs Float64Array pendingOffsets, Uint32Array pendingLengths and uniform raw-v6 dictionary names. metadataValidated is not set by simulated persistence; real block persistence marks the validated symbol after producing these typed columns. No browser publication ordering is inferred from this deterministic source-order replay.',
    runnerSha256: sha256(await readFile(new URL(import.meta.url))),
}
await writeFile(path.join(root, 'metadata-publication-admission.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify(result, null, 2))
