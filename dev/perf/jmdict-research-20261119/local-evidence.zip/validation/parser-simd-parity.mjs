import assert from 'node:assert/strict'
import {readFile, mkdir, writeFile, appendFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {createRequire} from 'node:module'
import {execFileSync} from 'node:child_process'
import path from 'node:path'
import {fileURLToPath} from 'node:url'

const workspace = '/workspace/scratch/cb98f2e06b71'
const baselineRoot = path.join(workspace, 'manabitan')
const candidateRoot = path.join(workspace, 'manabitan-simd')
const output = process.argv[2]
assert(output, 'Pass a new evidence directory')
await mkdir(path.dirname(output), {recursive: true})
await mkdir(output, {recursive: false})
const require = createRequire(path.join(baselineRoot, 'package.json'))
const {ZipReader, Uint8ArrayReader, Uint8ArrayWriter} = require('@zip.js/zip.js')
const encoder = new TextEncoder()
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
const log = async (value) => {
    await appendFile(path.join(output, 'events.jsonl'), `${JSON.stringify(value)}\n`)
    process.stdout.write(`${JSON.stringify(value)}\n`)
}
const wasmPath = 'dev/data/dictionary-wasm/term-bank-parser.wasm'
const cPath = 'ext/js/dictionary/wasm/term-bank-parser.c'
const identities = []
const parsers = []
for (const root of [baselineRoot, candidateRoot]) {
    const wasm = await readFile(path.join(root, wasmPath))
    const generated = await readFile(path.join(root, 'ext/lib/term-bank-parser.wasm'))
    assert.equal(sha256(wasm), sha256(generated))
    identities.push({
        root,
        commit: execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim(),
        status: execFileSync('git', ['-C', root, 'status', '--porcelain'], {encoding: 'utf8'}).trim(),
        wasmSha256: sha256(wasm),
        sourceSha256: sha256(await readFile(path.join(root, cPath))),
    })
    const module = await WebAssembly.compile(wasm)
    assert.deepEqual(WebAssembly.Module.imports(module), [])
    parsers.push(new WebAssembly.Instance(module).exports)
}
const lockBytes = await readFile(path.join(baselineRoot, 'test/perf/dictionaries.lock.json'))
const lock = JSON.parse(lockBytes).dictionaries
const manifest = {
    startedAt: new Date().toISOString(), node: process.version, identities,
    scriptSha256: sha256(await readFile(fileURLToPath(import.meta.url))),
    lockSha256: sha256(lockBytes),
    timing: false,
    boundary: 'Native strict parser metadata and acceptance parity; no whole-import timing claim',
}
await writeFile(path.join(output, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`)

function parse(parser, bytes, capacity, strict, hints, alignment = 0, physicalEnd = false) {
    parser.wasm_reset_heap()
    const guard = parser.wasm_alloc(capacity * 68 + 32)
    const outputPointer = guard + 16
    const allocation = parser.wasm_alloc(bytes.byteLength + (physicalEnd ? 65536 : 32))
    const heap = new Uint8Array(parser.memory.buffer)
    const input = physicalEnd ? heap.byteLength - bytes.byteLength : allocation + alignment
    heap.fill(0xa5, guard, outputPointer + capacity * 68 + 16)
    heap.set(bytes, input)
    const parseFunction = hints ? parser.parse_term_bank_with_media_hints : parser.parse_term_bank
    const count = parseFunction(input, bytes.byteLength, outputPointer, capacity, 0, 0, strict ? 1 : 0)
    assert(heap.subarray(guard, outputPointer).every((x) => x === 0xa5), 'Leading output guard')
    assert(heap.subarray(outputPointer + capacity * 68, outputPointer + capacity * 68 + 16).every((x) => x === 0xa5), 'Trailing output guard')
    const length = count >= 0 ? count * 68 : capacity * 68
    return {count, metadata: Buffer.from(heap.subarray(outputPointer, outputPointer + length))}
}

let comparisons = 0
let malformedOracleCases = 0
function compare(source, label, modes, alignment = 0, physicalEnd = false) {
    const text = `[["entry","","","",0,${source},1,""]]`
    let jsonValid = true
    try { JSON.parse(text) } catch { jsonValid = false }
    if (!jsonValid) ++malformedOracleCases
    const bytes = encoder.encode(text)
    for (const [strict, hints] of modes) {
        const a = parse(parsers[0], bytes, 1, strict, hints, alignment, physicalEnd)
        const b = parse(parsers[1], bytes, 1, strict, hints, alignment, physicalEnd)
        assert.equal(b.count, a.count, `${label}: status ${JSON.stringify({strict, hints, alignment, physicalEnd, source})}`)
        assert.equal(Buffer.compare(a.metadata, b.metadata), 0, `${label}: metadata ${JSON.stringify({strict, hints, alignment, physicalEnd, source})}`)
        if (!jsonValid) assert(a.count < 0, `${label}: native accepted invalid JSON ${source}`)
        ++comparisons
    }
}

try {
    const modes = [[false, false], [false, true], [true, false], [true, true]]
    const seeds = [
        '[]', '[[],{},"image"]', '{"a":[],"b":{},"c":[[],{}]}',
        '[{"type":"structured-content","content":{"a":[],"b":{},"c":[{},[],"image"]}},"last"]',
        '[{"type":"structured-content","content":[[],{}]},{"type":"text","text":"last"}]',
        '[ { "content": [ [], {} ], "type": "structured-content" }, "last" ]',
        '[{"type":"structured-content","content":[],"content":null}]',
        '[{"type":"image","path":"first","content":{},"type":"unknown"}]',
        '[{"\\u0074ype":"structured-content","content":{"a":[],"b":{"tag":"\\u0069mg"}}}]',
        '[{"type":"structured-content","content":["brackets[]{}:,",[],{"x":"\\u1234\\n\\t\\\\\\\""}]}]',
        '[[],true,{},false,[],null,{},-1.25e+3]',
        '[{"type":"structured-content","content":{"a":[],"b":{"type":"text","text":"value"},"c":{}}}]',
    ]
    const tokens = ['[', ']', '{', '}', ':', ',', '"', '\\', ' ', '\n', '0', 't']
    const cases = new Set()
    for (const source of seeds) {
        cases.add(source)
        for (let i = 0; i <= source.length; ++i) {
            cases.add(source.slice(0, i))
            cases.add(source.slice(0, i) + source.slice(i + 1))
            for (const token of tokens) {
                cases.add(source.slice(0, i) + token + source.slice(i))
                if (i < source.length) cases.add(source.slice(0, i) + token + source.slice(i + 1))
            }
        }
    }
    let sequence = 0
    for (const source of cases) compare(source, `mutation-${++sequence}`, modes)
    await log({phase: 'malformed-differential', cases: cases.size, comparisons, malformedOracleCases})
    const boundarySources = [...seeds]
    for (const depth of [254, 255, 256, 257]) {
        let nested = '0'
        for (let i = 0; i < depth; ++i) nested = i % 2 ? `{"k":${nested}}` : `[${nested}]`
        boundarySources.push(`[${nested},"image"]`, `[${nested},]`, `[${nested},,{}]`)
    }
    for (const source of boundarySources) {
        for (const alignment of [0, 1, 7, 8, 15]) compare(source, 'alignment-boundary', modes, alignment)
        compare(source, 'physical-memory-end', modes, 0, true)
    }
    await log({phase: 'boundaries', cases: boundarySources.length, comparisons, malformedOracleCases})
    let stringBoundaryCases = 0
    for (let position = 0; position < 64; ++position) {
        const prefix = 'x'.repeat(position)
        for (const ending of ['\\', '\\u', '\\u0', '\\u00', '\\u000', '\\u00xz', '\\q', '\u001f', '\\"tail']) {
            compare(`["${prefix}${ending}"]`, `string-boundary-${position}`, modes, position & 15, true)
            ++stringBoundaryCases
        }
    }
    let rawByteCases = 0
    for (let position = 0; position < 16; ++position) {
        const prefix = encoder.encode(`[["${'x'.repeat(16 + position)}`)
        const suffix = encoder.encode('tail","","","",0,["definition"],1,""]]')
        const bytes = new Uint8Array(prefix.length + 1 + suffix.length)
        bytes.set(prefix)
        bytes.set(suffix, prefix.length + 1)
        for (let byte = 0; byte < 256; ++byte) {
            bytes[prefix.length] = byte
            for (const physicalEnd of [false, true]) {
                for (const [strict, hints] of modes) {
                    const a = parse(parsers[0], bytes, 1, strict, hints, position, physicalEnd)
                    const b = parse(parsers[1], bytes, 1, strict, hints, position, physicalEnd)
                    const label = JSON.stringify({position, byte, strict, hints, physicalEnd})
                    assert.equal(b.count, a.count, `Raw string byte status ${label}`)
                    assert.equal(Buffer.compare(a.metadata, b.metadata), 0, `Raw string byte metadata ${label}`)
                    ++comparisons
                    ++rawByteCases
                }
            }
        }
    }
    await log({phase: 'string-simd-boundaries', stringBoundaryCases, rawByteCases, comparisons, malformedOracleCases})
    const fixtureResults = []
    for (const [dictionary, spec] of Object.entries(lock)) {
        const archive = await readFile(path.join(baselineRoot, 'builds/e2e-dictionary-cache', spec.cacheFile))
        assert.equal(archive.byteLength, spec.sizeBytes)
        assert.equal(sha256(archive), spec.sha256)
        const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)))
        const digest = createHash('sha256')
        const banks = []
        let rows = 0
        let sourceBytes = 0
        try {
            const entries = (await reader.getEntries()).filter((e) => /^term_bank_\d+\.json$/.test(e.filename))
                .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
            for (const entry of entries) {
                const bytes = await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true})
                const expectedRows = JSON.parse(new TextDecoder().decode(bytes)).length
                const a = parse(parsers[0], bytes, expectedRows, true, true)
                const b = parse(parsers[1], bytes, expectedRows, true, true)
                assert.equal(a.count, expectedRows, `${dictionary}/${entry.filename}: baseline rows`)
                assert.equal(b.count, expectedRows, `${dictionary}/${entry.filename}: candidate rows`)
                assert.equal(Buffer.compare(a.metadata, b.metadata), 0, `${dictionary}/${entry.filename}: metadata`)
                digest.update(entry.filename)
                digest.update(a.metadata)
                banks.push({name: entry.filename, rows: expectedRows, sourceBytes: bytes.byteLength, sourceSha256: sha256(bytes), metadataSha256: sha256(a.metadata)})
                rows += expectedRows
                sourceBytes += bytes.byteLength
                ++comparisons
            }
        } finally { await reader.close() }
        assert.equal(rows, spec.termRows)
        const result = {dictionary, rows, sourceBytes, banks, metadataDigest: digest.digest('hex'), archiveSha256: spec.sha256}
        fixtureResults.push(result)
        await writeFile(path.join(output, `${dictionary}.json`), `${JSON.stringify(result, null, 2)}\n`)
        await log({phase: 'full-corpus', dictionary, rows, sourceBytes, banks: banks.length, metadataDigest: result.metadataDigest})
    }
    for (const identity of identities) {
        assert.equal(sha256(await readFile(path.join(identity.root, wasmPath))), identity.wasmSha256)
        assert.equal(sha256(await readFile(path.join(identity.root, cPath))), identity.sourceSha256)
    }
    const result = {complete: true, finishedAt: new Date().toISOString(), comparisons, malformedOracleCases, fixtureResults}
    await writeFile(path.join(output, 'result.json'), `${JSON.stringify(result, null, 2)}\n`)
    await log({complete: true, comparisons, malformedOracleCases, dictionaries: fixtureResults.length})
} catch (error) {
    await writeFile(path.join(output, 'failure.json'), `${JSON.stringify({complete: false, comparisons, malformedOracleCases, error: String(error), stack: error.stack}, null, 2)}\n`)
    throw error
}
