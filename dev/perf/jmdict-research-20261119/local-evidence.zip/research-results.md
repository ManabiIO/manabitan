# JMdict import qualification — 19 November 2026

## Decision

No completed screen yet establishes a production browser win. The aligned recent-content cache copy has favorable cache-phase direction in 16 of 18 pairs across two independent cohorts, with noisy effect magnitude and no established whole-import gain. [Draft PR #758](https://github.com/ManabiIO/manabitan/pull/758) presents this narrower claim for review and has not been merged. SIMD string scanning reduces aggregate parser work and part of the critical path in its first screen, but total browser time worsens; its independent twelve-pair replication is neutral and does not reproduce the target effect, so no SIMD product PR is proposed. Reject canonical counter caching for production: it slows its targeted phase in five of six browser pairs. Parser escape specialization, worker prewarming and the close-comma shortcut do not establish browser gains. Contiguous metadata publication has favorable exclusive-phase direction in 16 of 18 pairs, but both cohorts fail to improve integrated browser time; it remains unqualified with no product PR. Compression dispatch coalescing reduces measured post counts and native sample counts, but its small favorable browser direction remains inside noise in both cohorts and compression timing is inconsistent. It remains unqualified with no product PR. All thirteen planned browser cohorts are complete. Direct record-field access and manual Uint32 copying are rejected after local component screens. Both baseline traces attribute the approximately 112 ms finalization tail to a blocking native durability flush; changing cooperative yields does not address that measured cause.

## Fixed measurement and correctness protocol

Research branch `perf/jmdict-qualification-20261119` uses the unchanged release build and import harness, fixed baseline `d829f5b6e6a75ee8859d38d537d224ec33c4930e`, and pinned JMdict archive. Each initial Ubuntu screen builds both arms before measurements and executes the predetermined order: one excluded AB warmup, one AA control pair, six adjacent AB/BA alternating pairs, one BB control pair, then separate A/B CPU traces. The independent cache, SIMD, metadata and dispatch replications freeze twelve alternating pairs beginning BA, with their warmups also beginning BA. Only the research wrapper's validated pair-count/order options change; the product, import measurement harness, flags and baseline remain unchanged. No observation, tail, or control is discarded. Traces are diagnostic and excluded from speed estimates.

All completed initial screens passed 18 ordinary observations plus both diagnostic runs; each cache, SIMD, metadata and dispatch replication passed 30 ordinary observations plus both diagnostics. Across nine initial/calibration cohorts and four independent replications, all 308 reports validate: 282 ordinary observations and 26 separate traces. Traces, warmups and same-code controls remain excluded from paired speed estimates. Validation checks title/revision, 526,942 term rows, 12 content probes, their output digest, and the same receipt after a browser restart. Every ordinary observation has effective worker flags and package/source identity receipts. Corpus/output digest equality is necessary correctness evidence, not exhaustive browser-output equivalence; the component correctness suite complements these probes.

The remote environment is Ubuntu x64 with 4 available CPUs, Node 22.22.0, and the locked Playwright Chromium 153.0.8010.12. The control, parser-escape, initial SIMD and cache-replication cohorts used AMD EPYC 9V74 hosts; prewarming, initial cache-copy, canonical-counter, close-comma and both metadata-publication cohorts used AMD EPYC 7763 hosts. The independent SIMD replication used an Intel Xeon Platinum 8573C host; both dispatch cohorts used AMD EPYC 9V45 hosts. Production defaults select three parser workers, twelve groups and four groups per worker. Compare arms within a job, not absolute times across hosts. This does not establish Safari, Firefox, low-memory-device, or whole-browser memory performance.

## Browser screening results

Positive percentages mean the candidate took longer. Equal-work change compares the sum of all measured candidate observations with the sum of all measured baseline observations in the same cohort.

| Cohort | Median paired change | Equal-work change | Faster pairs | Same-code pre/post controls |
| --- | ---: | ---: | ---: | --- |
| Identical-product control | +4.58% | +7.35% | 1/6 | −11.78%, −11.28% |
| Parser escape specialization | −2.15% | −0.87% | 5/6 | +6.43%, +13.29% |
| Parser-worker prewarming | +0.79% | +3.26% | 3/6 | +42.01%, −7.19% |
| Aligned recent-content cache copy | −1.13% | +1.44% | 4/6 | −5.18%, −7.62% |
| Canonical counter caching | −0.91% | −2.02% | 5/6 | −1.80%, +8.56% |
| Cache copy, independent 12-pair BA replication | −1.02% | −2.22% | 8/12 | −15.80%, +1.94% |
| Parser close-comma shortcut | +0.78% | +0.88% | 3/6 | +10.48%, −1.59% |
| SIMD string scanning | +3.20% | +4.92% | 3/6 | −1.18%, −2.35% |
| SIMD, independent 12-pair BA replication | −0.02% | +0.39% | 6/12 | +1.24%, −1.30% |
| Contiguous metadata publication | +0.91% | +1.23% | 3/6 | +0.12%, +0.47% |
| Metadata, independent 12-pair BA replication | +0.88% | +0.55% | 5/12 | −0.61%, −14.50% |
| Compression dispatch coalescing | −1.97% | −1.40% | 4/6 | +21.28%, −4.06% |
| Dispatch, independent 12-pair BA replication | −0.84% | −0.43% | 7/12 | −0.87%, +8.35% |

| Pair | Identical-product A/B (ms) | Parser specialization A/B (ms) |
| --- | ---: | ---: |
| 1 | 917.7 / 938.6 | 969.3 / 937.0 |
| 2 | 1032.3 / 935.5 | 931.8 / 915.3 |
| 3 | 922.2 / 1168.0 | 932.2 / 908.6 |
| 4 | 921.6 / 1085.1 | 947.3 / 933.6 |
| 5 | 906.3 / 941.9 | 931.9 / 894.6 |
| 6 | 1103.5 / 1161.2 | 954.8 / 1028.7 |

The control manifest confirms identical product entries. The parser cohort changes only `js/dictionary/wasm/term-bank-parser.c` and `lib/term-bank-parser.wasm`. All completed cohorts return probe digest `86a9f92e48d74220b4d0240f95703860825c00c5d98baff6218230b6ca3afe36`.

The parser cohort's median paired browser difference is −20.05 ms. Bulk finalization moves by −16.5 ms, although the candidate does not change finalization. Import-data-bank wall time changes by only −0.46%; the nested term fast path by −1.63%; aggregate parser work by +1.11%. Pair 6B spends 148.5 ms on source reads versus 58.7 ms in 6A. This observation remains in the results. The current screen does not isolate a causal browser speedup.

Prewarming changes only `dictionary-importer.js` in the release package. Its pairs are 1057.2/1049.7, 1054.7/1209.4, 1051.4/1030.0, 1040.6/1033.0, 1023.4/1046.8, and 1024.9/1086.9 ms. Source-read wall time improves by a median paired 21.95 ms and the nested fast path by 15.5 ms, but import-data-bank wall time increases by 10 ms and sink work by 43.5 ms. Its total browser result does not support promotion. The baseline finalization median on this host is 21 ms, versus 139 ms in the first cohort, illustrating why cross-job absolute comparisons would be misleading.

The cache-copy candidate changes only `dictionary-database.js` in the release package. Its initial pairs are 1063.9/1212.5, 1069.2/1039.2, 1056.3/1043.8, 1031.9/1040.6, 1001.4/988.0, and 1041.3/1030.1 ms. Cache time improves in all six pairs, by a median paired 8.1 ms (6.20%); cache-byte totals remain exactly 100,724,405. Import-data-bank wall time improves by a median paired 15.5 ms. The first candidate observation remains in the aggregate despite its 13.97% browser slowdown.

The independent twelve-pair cache replication improves cache time in ten of twelve pairs: median paired −19.15 ms (−16.57%), with baseline/candidate cache medians 110.00/96.75 ms. Import-data-bank wall time improves by only 8.5 ms, and finalization is unchanged. Browser median paired change is −1.02%, close to the initial −1.13% screen, but it remains small relative to controls. This is favorable repeated evidence for the cache-phase direction across two hosts, with noisy magnitude; it does not establish a precise or reliable whole-import speedup. The twelve paired browser changes are −5.54%, +0.24%, −10.87%, −0.05%, −2.21%, −5.41%, +1.53%, −1.86%, +0.56%, −0.85%, +0.76%, and −1.20%.


Cache-phase controls also move materially, so the 6.20% and 16.57% point estimates are not precise expected improvements. The identical-product cohort alone shows a −8.22% median paired cache change (−9.40 ms) with four of six pairs faster despite identical product bytes. The candidate's 16 of 18 favorable pairs across two independent cohorts support reviewing the mechanism and repeated direction; the controls limit the effect-size claim. See [phase controls recalculated from every report](cohort-phase-controls.json).

| Cache-phase cohort | Median paired change | Faster pairs | Cache-phase pre/post controls |
| --- | ---: | ---: | --- |
| Identical product | −8.22% | 4/6 | +6.96%, +9.25% |
| Initial aligned copy | −6.20% | 6/6 | +9.89%, −1.10% |
| Independent aligned-copy replication | −16.57% | 10/12 | −14.02%, +9.64% |

Canonical counter caching changes only its C source and WASM binary in the release package. Its pairs are 1083.1/1070.8, 1085.9/1078.4, 1089.8/1086.4, 1121.6/1044.1, 1144.2/1079.6, and 1077.0/1108.7 ms. Despite slightly favorable browser totals, the targeted canonical-scan phase worsens in five of six pairs: baseline/candidate medians 79.25/85.20 ms, median paired difference +9.80 ms (+13.26%). Native calls remain twelve, fallbacks zero, input-copy bytes 16,741,613 and output-copy bytes 32,080. The observed browser change coincides with a 40.5 ms median paired reduction elsewhere in content append, not the targeted scan improvement. Single traced native intervals of 96.09/90.90 ms do not override the ordinary measurement cohort. A separate warm Node native-only replay restores preallocated arena snapshots and exercises a different runtime and timing boundary; its directional gain does not override this fresh-browser phase regression. Retain the prototype and replay as negative evidence; reject this version for production.

The close-comma parser candidate also changes only parser C/WASM package entries. Browser pairs are 1080.5/1120.0, 1088.4/1066.6, 1051.2/1073.5, 1059.3/1053.4, 1068.7/1123.0, and 1117.7/1086.3 ms. Aggregate parser work improves by a median paired 22 ms (2.21%), but the nested fast path slows 1.53%, parser-worker wall time 1.23%, and import-data-bank wall time 0.62%. Diagnostic composite-parser samples remain substantial, without a clear reduction. Warm local component results therefore do not establish a production browser benefit for this version.

The SIMD string scanner changes only parser C/WASM package entries. Its six browser pairs are 941.2/888.7, 908.4/976.0, 922.8/1126.0, 886.0/878.8, 949.5/1011.7 and 913.4/912.0 ms. Aggregate parser work improves in five of six pairs, by a median paired 48 ms (6.64%). Parser-worker wall time improves 14.1 ms (2.03%), the nested fast path 14 ms (1.93%), and import-data-bank wall time 11 ms (1.45%). Browser time nevertheless worsens by a median paired 3.20%; candidate finalization includes 176 and 192 ms tails, and all observations remain in the estimate. Diagnostic composite-parser samples total approximately 268/228 ms across workers, consistent with the targeted mechanism but not a wall-time estimate. The small critical-path change motivated an independently reversed twelve-pair replication; the initial cohort does not qualify an overall import win. See [all initial SIMD observations](cohorts/parser-simd.json).

The [independent SIMD replication](cohorts/parser-simd-replication.json) is neutral: browser median paired −0.023%, equal-work +0.387%, six of twelve pairs faster, with same-code controls +1.240% and −1.301%. The targeted aggregate parser-work change shrinks to −7 ms (−0.702%), with six of twelve pairs faster. Parser-worker wall time worsens 4.1 ms (0.445%); the nested fast path improves 3 ms (0.306%) and import-data-bank wall time 2 ms (0.203%). Baseline and candidate package-entry maps exactly match the first SIMD screen. All 32 ordinary/diagnostic reports pass the same validation. The host differs from the first screen, but hardware sensitivity is a hypothesis, not an established cause. This version remains unqualified and has no product PR.

The [contiguous metadata publication screen](cohorts/metadata-publication.json) improves the exclusive index-publication phase in all six pairs. Its baseline/candidate medians are 33.65/16.95 ms, median paired difference −15.25 ms (−47.39%), and equal-work change −44.83%. Exclusive publication is computed as index publication minus nested recent-source cache time within each observation. Its same-code controls are +33.86% and −54.55%, so the effect magnitude remains noisy. The unchanged cache phase moves +2.90%; inclusive index publication improves 3.81%. Browser time worsens by a median paired 0.91% and equal-work 1.23%, with three of six pairs faster. Import-data-bank wall time increases 6.5 ms (0.64%) and the fast path 4.5 ms (0.46%); parser-worker wall time improves only 2.35 ms (0.26%). All 20 reports pass validation, and only `dictionary-database.js` differs in the release package. The target direction motivated independent replication; this first screen does not establish a whole-import win.


The [independent metadata replication](cohorts/metadata-publication-replication.json) retains favorable exclusive-publication direction in ten of twelve pairs: median paired −6.8 ms (−19.12%), equal-work −25.13%, with baseline/candidate medians 33.60/25.15 ms. Its target-phase controls are −13.83% and −28.57%, reinforcing the uncertain magnitude. The unchanged cache phase moves +9.21%, inclusive index publication +0.85%, and aggregate metadata work −0.34%. Browser time worsens 0.88% by median paired change and 0.55% by equal work, with five of twelve pairs faster; controls are −0.61% and −14.50%. Import-data-bank wall time worsens 9.5 ms (1.00%), the fast path 10 ms (1.08%), and parser-worker wall time 4 ms (0.45%). Package maps match the first screen exactly and all 32 reports validate. Both jobs use EPYC 7763 hosts. The combined 16 of 18 favorable target pairs do not translate into an integrated gain in either cohort. This version remains unqualified with no product PR.

The [compression dispatch screen](cohorts/compression-dispatch.json) has a browser median paired change of −1.97% and equal-work change of −1.40%, with four of six pairs faster. Same-code browser controls are +21.28% and −4.06%. Import-data-bank wall time improves 9.5 ms (1.50%), the fast path 8 ms (1.31%), and parser-worker wall time 10.45 ms (1.83%). The measured compression phase is neutral: paired +0.25 ms (+0.086%), three of six pairs faster, with its own controls +7.36% and −4.32%. Content append increases 2.33% and importer sink time 2.79%. These overlapping metrics do not establish a causal whole-import benefit. All 20 reports validate; only the two expected Zstd JavaScript files differ, matching frozen source commit `8af2ed9d7bd6eb51b4cacd89e684c3a3904c539a`. The native dispatch attribution below motivated an independent twelve-pair replication; this first screen alone does not support a product PR.


The [independent dispatch replication](cohorts/compression-dispatch-replication.json) retains only a small favorable browser direction: median paired −0.84%, equal-work −0.43%, seven of twelve pairs faster, with controls −0.87% and +8.35%. Compression time changes −2.9 ms (−1.24%), but only six of twelve pairs improve and its own controls are −5.57% and +19.03%. Import-data-bank wall time changes −8 ms (−1.31%), with eight of twelve pairs faster, but its equal-work change is only −0.16%. The fast path and parser-worker wall time each improve by a median paired 9 ms (1.56% and 1.63%). Both jobs use EPYC 9V45 hosts; source/package-entry maps match exactly and all 32 replication reports validate. The combined eleven of eighteen favorable browser pairs and nine of eighteen favorable compression pairs do not establish a reliable integrated gain. This version remains unqualified with no product PR.

## Critical path and trace evidence

Across the identical-product cohort's twelve measured observations, median browser import time is 940.25 ms and worker RPC time 914.75 ms. The principal sequential importer phases are archive/index 8.5 ms, import-data-banks 752 ms and bulk-finalization 139 ms. The nested term fast path is 722 ms. Worker totals, sink time and detailed subphases overlap and must not be summed as independent wall-time contributions.

### Recent-content cache copy

In the two baseline traces, `_cacheRecentPublishedTermContentSources` contributes 537/553 self samples. Its `spans.buffer.slice(minimumOffset, maximumEnd)` line accounts for 434/439 of these samples and 100.95/130.86 ms of sampled intervals. Other loop lines each account for approximately 1–5 ms. Ordinary reports record 100,724,405 cache-copy bytes in every run and approximately 117.5 ms median cache time. A private owned copy must remain because parser shared-memory storage can subsequently be reused.

Official V8 sources corroborate the alignment hypothesis: both same-type typed-array `slice` and `set` take a relaxed shared-memory move path. For nonoverlapping copies, the implementation aligns the destination and uses machine-word operations only when source and destination are both aligned; otherwise it falls back to byte operations. Plain `set` is therefore not automatically a solution for misaligned sources. These source references explain the mechanism but are not an exact revision match to the Chromium binary:

- <https://chromium.googlesource.com/v8/v8.git/+/refs/heads/main/src/base/atomicops.h>
- <https://chromium.googlesource.com/v8/v8/+/dc5908fd731c73e02c329b9336af6940ca70ae3d/src/builtins/typed-array-slice.tq>
- <https://chromium.googlesource.com/v8/v8/+/dc5908fd731c73e02c329b9336af6940ca70ae3d/src/builtins/typed-array-set.tq>

The cache candidate's diagnostic trace explains why the improvement is smaller than an all-misalignment component screen might suggest. Of its 130.93 ms sampled in `copyRecentTermContentSource`, the already-aligned/plain-`set` branch accounts for 100.58 ms (319 samples), the adjusted-source bulk copy 25.83 ms (87 samples), and private `copyWithin` 0.87 ms (3 samples). This establishes where sampled copy time goes, not exact byte or group shares. The local screen's full native slabs contain 100,725,122 bytes, whereas actual cache admission selects 100,724,405; native base alignment alone does not establish each selected minimum offset. The change retains an exact-size private owned buffer and the same cache byte budget.

### Finalization: flush, not a chain of timer waits

| Baseline trace | Final writer timer delay | Final task wall time | Task thread CPU time | Native flush sampled interval |
| --- | ---: | ---: | ---: | ---: |
| A | 0.033 ms | 111.344 ms | 2.368 ms | 110.686 ms |
| B | 0.028 ms | 114.220 ms | 2.318 ms | 113.479 ms |

The native flush sample's parent is the `SyncImportIndexWriter._finish` callback, call site line 188 (`this._access.flush()`). There is no timer chain inside that final task. Earlier delayed writer yields overlap active ingestion work. The trace attributes the final tail to synchronous storage flush wait; it does not justify weakening durability or changing yield policy.

### Remaining CPU and ownership leads

After cache copying, importer-worker self samples concentrate in canonical deduplication scanning (64/75 ms), garbage collection (56/45 ms), compression-worker `postMessage` dispatch (27/28 ms), in-flight source validation (24/29 ms), metadata publication itself (20/33 ms), record-field encoding (23/30 ms), lookup chunk assembly (28/19 ms), and reference-slab construction (21/17 ms). These are sampled intervals, not benchmarked component costs.

The metadata candidate's trace confirms its new contiguous helper runs: 68 self samples in the helper and zero in the staged-index resolver, compared with eight resolver samples in the baseline. The wrapper's self interval falls from 31.59 to 12.32 ms, but the new helper contributes 36.95 ms; ignoring that transferred work would misattribute a gain. The diagnostic exclusive publication phase is 54.6/40.3 ms, with substantial trace overhead. Those two diagnostic runs remain excluded from qualification.

The in-flight source registration retains borrowed buffers and validates bounds/aliases; it does not copy their payload. Compression dispatch already snapshots offset/length columns once into shared storage and sends views, so there is no whole-metadata clone per dispatch. `contentMetadataIndexPublishMs` includes recent-source caching and must not be added to cache time. Possible later work is allocation reduction in record-field/lookup assembly or dispatch batching, subject to exact ownership and cancellation checks; neither is currently a proven win.

The parser's largest sampled native functions are composite-span scanning, the fused parser, libdeflate, CRC32 and row parsing. Function IDs 37/31/41/2/11 were mapped using same-recipe named WASM builds with byte-identical non-custom sections. IDs match in the baseline, escape, close-comma and SIMD candidates. The [SIMD function map and section-identity receipt](validation/simd-function-map.json) are retained. This mapping does not turn parallel sample totals into critical-path wall time. Explicit `copy_valid_utf8` samples (function 28) account for only about 4–10 ms per baseline parser worker. The fused production path calls that function directly, so this cost is not substantially hidden in function 31; it is a lower-priority target than the dominant scans and cache copy.

For the separate canonical-deduplication module, `scan_canonical` is native function 4. Its 260/252 importer-worker samples account for 63.964/74.612 ms directly in the export. The JavaScript `_scan` wrapper contributes only 23/20 self samples and 6.341/8.487 ms; setup closures contribute 1.907/3.813 ms. Pending-column adoption adds 6.266/5.285 ms and exact byte comparisons 3.436/6.784 ms. Thus the canonical native loop itself, rather than an arena allocation or JavaScript copy, is a defensible target for a separately qualified change preserving the mutation journal and rollback barriers.



### Compression dispatch attribution

Native `postMessage` frames must be attributed to their JavaScript parent call site. In the first dispatch screen, importer-worker samples with parent `zstd-term-content.js` total 140 samples with 42.419 ms of signed raw sample-delta weight for the baseline and 63 samples with 28.319 ms for the candidate. The baseline caller is the dispatch closure at line 335; the candidate caller is `_postQueuedCompressionJobs` at line 334. These are diagnostic sample weights, not message counts, CPU-time estimates, or a measured 14.1 ms synchronous saving. The original identical-product traces attributed 26.966/28.377 ms to that same baseline native call.

JavaScript self samples alone at those call sites total only 0.313/0.109 ms and omit the native frames. An initial self-only reading was corrected before the qualification decision; those figures do not establish near-zero dispatch cost or a hardware-specific mechanism. The durable analyzer and exports now include `nativePostMessageByCaller`, so the native work remains auditable. Independent `SchedulePostMessage` events confirm the intended 102-to-48 compression-post reduction. The native sample count also falls. Exact duration attribution is sensitive to negative source deltas and how gaps are assigned: positive-only raw weights are 45.077/28.729 ms, while a following-gap interpolation gives 39.411/39.102 ms. Every selected native sample and positive raw interval lies inside an importer task, but none of these interpolation alternatives is a full DevTools duration model. The [independent audit](validation/dispatch-trace-independent-audit.json) preserves all 203 selected native samples, 150 compression-post events, source/trace hashes and duration conventions. These conventions do not justify an exact CPU-saving claim. Compression-phase wall time in the first screen remains neutral and browser controls are noisy. The independent replication again has fewer native samples (118/67), while signed raw weights reverse direction to 21.296/37.804 ms. That further limits any exact time-saving interpretation of sampled weights.

## Rejected local components

### Direct record-field access

Candidate `1abf32cb49a8fdce289909c97737a91071457cc6` removes some field access overhead but increases the full validation/layout/encoding boundary. The fixed component design uses 32 isolated Node children: eight alternating A/B pairs plus four AA and four BB control pairs. Each child runs two excluded warmups and eight measured full-corpus passes over the production twelve groups. Every input and output digest matches for all 526,942 rows and 4,229,084 encoded field bytes.

The candidate is slower in six of eight A/B pairs. Median paired change is +25.42%, and equal-work change is +8.51%. Median validation time across child means rises from 7.915 to 13.397 ms; field encoding falls from 11.982 to 10.328 ms. Measuring encoding alone would therefore select the wrong result. Same-code labeled control medians are −3.37% (AA) and +12.73% (BB), so the precise regression magnitude is uncertain. The unfavorable complete boundary supports rejection. See [every child observation](components/record-fields-cohort.json), the [recomputed summary](components/summary.json), and the archived component runner/driver and [exact rejected patch](components/record-fields-candidate.patch) beside them. This component excludes persistence and UI work and uses synthetic content references; it is not a browser speed estimate.

### Manual Uint32 copies

Both four-word and eight-word unrolled copy prototypes are rejected. The fixed Node 24 screen covers all eight byte alignments, five arms, two excluded warmups and eight rotating-order measured passes, for 320 measured outputs. All output hashes match. Separate parity covers 42,592 cases and 85,184 method calls. Relative to the aligned typed-array helper, median paired regressions range from 38.0% to 93.0% for the four-word loop and 16.4% to 69.1% for the eight-word loop across alignments. Large outliers remain in the record; aggregate means do not establish a precise effect size.

The screen uses full 100,725,122-byte native canonical slabs, distinct from the browser's 100,724,405-byte admitted cache selections. No product source was changed for these prototypes. See the [copy-screen summary](components/uint32-copy-screen-summary.json), [all measurements](components/uint32-copy-screen.json), [identity manifest](components/uint32-copy-screen-manifest.json), and [parity receipt](components/uint32-copy-parity.json).

### Canonical native replay

The [canonical replay](components/canonical-scan-replay.json) restores twelve full 25 MiB pre-call arena snapshots and verifies complete post-call memory, header and output hashes across 48 observations. Both modules match in every observation. Its warm native-only A/B timing appears favorable, but same-code ranges and extreme outliers are large. That result cannot override the fresh-browser target regression documented above. The replay remains useful as a correctness fixture for future native changes.

## Validation and review status

The [baseline validation receipt](validation/baseline-validation.json) records the initial full run honestly: 610 of 616 suites passed, six failed; 13,642 tests passed, four failed and 67 were skipped in 565.19 seconds. Four tests hit the default five-second timeout under local load, and two native suites lacked the supported compiler. A serial focused rerun of all six failing suites with pinned Clang/LLD 21.1.8 and a 30-second timeout passed 335 tests in 58.08 seconds. That recheck is not a second full-suite run. Both original and focused logs are retained alongside the receipt.

The [metadata admission audit](validation/metadata-publication-admission.json) finds all twelve native snapshot groups and 360,859 pending rows eligible for contiguous publication. The [actual baseline/candidate publisher parity](validation/metadata-publication-parity.json) preserves full table, counter, projection and rollback hashes. This replay uses synthetic valid offsets and omits cache source spans; it verifies those state transitions, not browser scheduling or OPFS. The [gate results](validation/metadata-publication-gates/results.json) retain 156 focused test passes, main/test type checks and the initial lint process kill; [bounded retries](validation/metadata-publication-gates/retry-results.json) pass lint and package checks. Original logs remain alongside them.

The [SIMD review](validation/simd-review-note.md), [native differential manifest/results](validation/parser-simd-parity-results/result.json) and [scalar-build comparison](validation/simd-scalar-parity/result.json) retain strict source/module identities and correctness boundaries. The differential covers 104,186 exact comparisons; all 338 term-bank files and 1,630,332 rows match baseline strict metadata. SIMD-disabled builds are byte-identical, while the production pinned recipe already enables SIMD. These are correctness and compiler evidence, not timing qualification.

The [dispatch review](validation/dispatch-review-note.md) records per-block ownership, cancellation and failure-drain invariants. Its focused suite covers 64 tests across seven suites, including actual multi-block Zstd frame-byte parity. The [gate chronology](validation/dispatch-validation-chronology.md) distinguishes each successful file lint, focused/test-type/package retry and retained earlier failure. The main type check passed before the final receiver-boundary annotation; no exact-final-head main-type rerun is claimed.

SIMD complete-output correctness matches across all three pinned corpora with strict glossary validation. This runner uses fixed 7/9/10-bank groups rather than the browser planner, and its incidental timings are excluded from qualification.

| Corpus | Rows | Lookup bytes | Complete-output digest |
| --- | ---: | ---: | --- |
| JMdict | 526,942 | 19,446,728 | `430a59f035c1e6bb66352f50b3d722b8bf853b394d56d5816f0576594e1ebb57` |
| JMnedict | 667,942 | 26,292,164 | `4ef00ce3bfda6a4a705800e459c7f0b54a82cb5fb76d149d8f119e416157dd5f` |
| Jitendex | 435,448 | 20,031,116 | `b618d21aa8c89a3f2f21613fa15c9fa8689bdd9efb991c9475e78e8ac057e805` |

The original Jitendex candidate child was killed with signal 9 during concurrent local validation and emitted no diagnostics. Its empty output and original stderr are retained; only the failed candidate child was retried alone with a bounded Node heap, then matched the baseline. See [JMdict receipt](validation/simd-full-output-parity/result.json), [cross-corpus receipt and failed-attempt record](validation/simd-full-output-parity/cross-corpus/result.json), [retry plan](validation/simd-full-output-parity/cross-corpus/jitendex-retry-plan.json), and [file hashes](validation/simd-full-output-files.json).

[Cache draft PR #758](https://github.com/ManabiIO/manabitan/pull/758) remains unmerged. Head `720764f57be826f093c3afbfc0f9591ce5d5091f` completed 25 successful checks and four expected skips with no failures, including main unit tests, JSON/JavaScript/TypeScript checks, full Chromium/Firefox E2E and restart recovery. A subsequent documentation-only head, `85fb1682d9c4e077ef091db2d333dd24c3020e07`, adds the phase-control caveat and refreshes evidence hashes; it completed 26 successful checks and four expected skips, with no failures and product/test bytes unchanged. Its earlier JSON-registration failure and narrow correction are retained in the [CI audit](ci/cache-pr-758.json); qualified product bytes remain unchanged.

## Next steps

Contiguous metadata publication completed both cohorts with favorable exclusive-phase direction but no whole-import gain. Further work would need to explain surrounding cache and pipeline costs before reconsidering this version. Its target is the exclusive publication loop: subtract `dedupRecentSourceCacheMs` from `contentMetadataIndexPublishMs` in each observation before pairing, because caching is nested inside publication. Existing baseline observations put the exclusive loop around 19–34 ms. Repeated staged-index witness checks contribute approximately 5–10 ms of direct self intervals in several traces, without native calls or table probes. Preserve witnesses, transaction boundaries and rollback behavior while checking any reduced per-row work.

Compression transport coalescing completed both cohorts without establishing an integrated performance gain. Exact untimed reconstruction of all twelve native snapshots finds 102 blocks/posts with group counts 9, 9, 9, 9, 9, 9, 7, 8, 8, 8, 8 and 9, using the database's 1 MiB target. Grouping requests per worker could reduce outgoing posts to 48 while preserving each block's compression, ordering, source-consumed receipt and error-drain behavior. The current thirteen-Boolean experiment object is only 516 JSON bytes; reducing flags alone would save approximately 48 KiB across the import, so batching calls is the more substantial hypothesis. These are workload-shape facts, not timing evidence. See [validated dispatch shape](components/compression-dispatch-shape.json).

Both metadata publication and dispatch remain unqualified for production changes. A future combined cache/publication experiment must measure their interaction rather than adding isolated phase point estimates: the unchanged cache phase became slower during the metadata cohorts, and the exclusive publication improvement did not translate into faster imports. Further allocation work in lookup assembly is possible, but the rejected record-fields boundary shows why an isolated subphase improvement must be checked against surrounding validation and fresh-browser behavior. Whole-browser memory remains unmeasured; use the separate diagnostic below before claiming a memory gain.

## Memory interpretation

Existing telemetry reports a maximum individual parser WASM heap of 38,928,384 bytes, 36,040,000 metadata allocation bytes and 29,885,576 reused lookup-scratch bytes. It does not report peak whole-process or whole-browser memory. Current normal observations disable process sampling; the harness's optional sampler covers one browser PID rather than the browser process tree. No total-memory improvement is claimed. The [cache/gather ownership assessment](validation/cache-gather-reuse-assessment.md) identifies no existing independently owned raw JavaScript slab to adopt on the measured route: Zstd gather storage belongs to reusable worker-local WASM memory, while parser content is borrowed shared storage. Removing the copy would require a new ownership/publication protocol and separate validation.

A separate timing-free diagnostic could sample `/proc` descendants, recording PID/start-time/role and process-tree proportional-set-size (PSS) where readable. Summing RSS overcounts shared pages, including shared WASM memory. Keep this diagnostic separate from the authoritative cohort and retain the production worker/group policy and source lifetimes.

## Raw evidence and reproducibility

| Cohort | Actions run | Research head | ZIP SHA-256 |
| --- | --- | --- | --- |
| Identical product | [44590947375](https://github.com/ManabiIO/manabitan/actions/runs/44590947375) | `75b0d9040af86f2d0a733a1393e19a271ec190e9` | `0cf9c2813463b6a4114d532d5d4bf956d7c03acd279d8c8754edd7f4eb7887f4` |
| Parser only | [44592329353](https://github.com/ManabiIO/manabitan/actions/runs/44592329353) | `0fbb4c4fb1780da0a34bf6955a47a001b5fcf784` | `61b88ad47415ceb241adc2aa08c32959fdf9e9ae6727919ea82d94527554db19` |
| Prewarm only | [44593573521](https://github.com/ManabiIO/manabitan/actions/runs/44593573521) | `94e4fd272af49a815b28bcd3a124d6345684a1cf` | `6d898d8ae56743c3fe0fbd15bb0adceb5902221adef8865c67019e214a1461f6` |
| Cache copy only | [44595604912](https://github.com/ManabiIO/manabitan/actions/runs/44595604912) | `a0a1627bdc4249ae6e5aa5d28984b2bae237e3fc` | `1b7342cd6533d71fdc7330bd3b45871a954c4f56e1bc9856d5ae0430930dfcdb` |
| Canonical counters only | [44596235029](https://github.com/ManabiIO/manabitan/actions/runs/44596235029) | `a0ab82c90edfeddc35940584da8853dbb88d6797` | `f681fa6b775df9734141213c533f5bcaf01f8da3283c5b1b9d814d0d7b4ba705` |
| Cache copy, 12-pair replication | [44597108115](https://github.com/ManabiIO/manabitan/actions/runs/44597108115) | `b8d38e4704efd3130cb6168e389df8a20b031bf4` | `e33ef5d7a855630711bfccdfdf6a4482acb2d5eb5cc4caa39c16e44a591679ce` |
| Close-comma parser only | [44597496939](https://github.com/ManabiIO/manabitan/actions/runs/44597496939) | `d022d186e6a6bffa8a2ef91eb029de4dcb4bf21d` | `ddb0b2548bbd8e77f373fcf5a11f121336f5d21d8cdc97683277a121a4f36d69` |
| SIMD parser only | [44600978325](https://github.com/ManabiIO/manabitan/actions/runs/44600978325) | `707d5b535fc49e5f349a076327b8e74eac2c7197` | `6801fa418dc3f07a8f96a09ee250e268e37df2f241902f92750bffc7627a2512` |
| SIMD, 12-pair replication | [44602502775](https://github.com/ManabiIO/manabitan/actions/runs/44602502775) | `4bf34506e8fd7784abd341703f7ee0204c0fcbd5` | `3f334fcae1c9bb14d968f0dfad9cbe4f5637428f04f379d6f76f04b4b2c32b96` |
| Contiguous metadata publication | [44603962953](https://github.com/ManabiIO/manabitan/actions/runs/44603962953) | `b69dec5deebb176044da269cd79ebb7dd74177c3` | `c626b0a4bc7644a15ae2bca4c25c19af53ecef596941073fc26246fcd667c4a3` |
| Metadata, 12-pair replication | [44605501145](https://github.com/ManabiIO/manabitan/actions/runs/44605501145) | `20739d29f2d1344ad280e0a6255fec5673130309` | `e75f51c49726e2d756a585f17eb465d1530f9a6d377654ed65695e91a6d98b6f` |
| Compression dispatch coalescing | [44605359044](https://github.com/ManabiIO/manabitan/actions/runs/44605359044) | `7172b9e47d7ca566ccd63cb126b07fa5b9485f75` | `c1b1fe10feec5dcaa6c6021debb1578bfd192b380183d27f5ba519bd5c403414` |
| Dispatch, 12-pair replication | [44606580704](https://github.com/ManabiIO/manabitan/actions/runs/44606580704) | `b1463296cfd15cc268ad7ebc24102a564ae02bcf` | `1d3f187497cc485cf935c62e0f06ce65bd5f83609de9e563e65407da70902372` |

The [cohort directory](cohorts/) retains compact JSON for calibration, parser escape, prewarming, initial cache copy, canonical counters, cache replication, close-comma parsing, SIMD scanning, the independent SIMD replication, both contiguous metadata cohorts and both compression-dispatch cohorts. Each initial screen contains all twenty observations; each completed twelve-pair replication contains all thirty-two. These files preserve every relevant importer phase and local timing metric, controls, outcome/failure fields, restart and worker receipts, per-observation host data, source/package/fixture/harness identities, run/artifact URLs, trace hashes and derived attribution. They keep the reported numbers available after Actions artifacts expire. Full package-entry maps are represented by a canonical SHA-256 digest plus changed entries and their hashes, avoiding repeated large maps. No speed estimate depends only on an expiring log.

The dedicated cache evidence packet is checked into [draft PR #758](https://github.com/ManabiIO/manabitan/pull/758), at `dev/perf/jmdict-cache-copy-20261119/`. It contains only the calibration, initial cache screen and independent cache replication, with the provisional cache-phase claim and whole-import limitation.

The [analyzer](analyze-qualification-evidence.py) reads an extracted evidence ZIP and writes `analysis.json`; it does not rerun the benchmark. The [packer](pack-qualification-evidence.py) exports these durable receipts from an extracted archive. The [phase/control summarizer](summarize-phase-controls.py) recalculates paired effects and same-code controls from the compact files without reading traces or rerunning timings. For example:

```sh
python analyze-qualification-evidence.py /path/to/extracted-evidence
python pack-qualification-evidence.py /path/to/extracted-evidence RUN_ID ARTIFACT_ID cohorts/result.json
```

Trace decoding groups `ProfileChunk` by `(pid, profile id)` and uses the corresponding `Profile.tid`, because chunks are emitted from a sampler thread. The SQLite proxy's `Atomics.wait` loop is blocking wait, not a CPU bottleneck. Sparse long samples and profiling overhead are not taken as evidence of production CPU cost.
