# JMdict cache locality, native execution and overlap evidence

Date: 2026-11-28. This follow-up preserves three read-only investigations. It contains no product patch, new browser run, or whole-import performance claim. The earlier `profile-metadata-evidence-0119.tar.gz` contains the original three profile analyses, compression attribution, and rejected metadata-loop screen; its SHA-256 is `0bc192e15efdc5ae4b2e9e354855d677b24abf40df8cf11272a1600d1f9e4621`.

## Conclusions

1. **Compressed backing is not a promising JMdict latency candidate.** The current recent-source cache adopts the parser's owned shared buffers: it makes no additional content-payload copy in the measured route. All 3,998 persisted comparisons consume only 843,359 raw bytes, but touch 93 blocks containing 90,794,154 decoded bytes—every block before the last group. The existing content import overlay already retains compressed frames by reference. Redirecting those comparisons to compressed backing introduces decoding and a large decoded working set; removing the parser's original owned-buffer copy is a different lifetime and scheduling change.

2. **Native lookup hashing executes in the actual browser import.** The initial native diagnostic at source `f3fd2373de6e74f6243008ff3f1f68703d688973` has 30 leaf samples in the exact `lookup_hash_update` export and one leaf sample in `lookup_hash_finish`. Package hashes, export indices, function-body offsets and the sampled module URL bind those samples to the retained WASM. This source precedes the intrinsic typed-array-kind admission fix; no timing is attributed to the final fixed candidate.

3. **Compression and record work can overlap, but the traces do not explain away the whole-import results.** Exact message joins confirm record-field and checksum samples during compression and also after compression results have been sent but before the import worker handles the last reply. These are diagnostic sample locations, not additive CPU times or measured savings. They do not prove that most of the paired score-v3 field-counter reduction was hidden. Current-group deduplication precedes dispatch; content and record completion jointly gate the ordered sink. Owned JMdict parser buffers permit independent producer progress.

## Cache census and feasibility review

`metadata/capture-cache-locality.mjs` and `metadata/jmdict-cache-locality.json` retain the full census, pinned fixture receipt, native-route counts, exact planner source, hashes and every comparison. `metadata/cache-architecture-review.md` and its source manifest describe ownership, import overlay, cache generation, fallback equality, rollback and relevant prior work.

| Quantity | Value |
| --- | ---: |
| Full JMdict rows / ordered groups | 528,299 / 12 |
| Native canonical calls / fallback calls | 12 / 0 |
| New unique content / persisted exact matches | 362,032 / 3,998 |
| Parser owned content bytes | 101,143,985 |
| Adopted recent-cache view bytes | 101,143,281 |
| Recent-cache payload bytes copied | 0 |
| Peak charged raw-cache backing | 92,657,003 bytes |
| Actual exact-comparison payload | 843,359 bytes |
| Distinct touched / total blocks | 93 / 103 |
| Once-only decoding for those touched blocks | 90,794,154 bytes |
| Largest comparison wave's decoded block set | 89,444,328 bytes |
| Existing 48 MiB LRU scenarios | 182 loads, 89 repeated loads, 179,138,967 decoded bytes |

The replay uses frozen source `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`, system Node 24.22.3, the actual parser/native canonical scanner, early metadata publication, source-cache adoption, and exact byte comparisons. A validated raw logical persistence adapter replaces compression, OPFS and record writing. It retains no source payloads itself. The imported production `RAW_TERM_CONTENT_TOKEN_DICT_NAME` preserves cross-group exact matching; the older literal-name adapter problem is documented in `capture-fidelity-correction.json`.

The LRU observations use byte-length tokens and the unchanged production 48 MiB policy. Both explicit completion-order scenarios give the same result; they are not mathematical bounds on every possible completion order. They assume recent-cache hits need compressed fallback. Concurrent in-flight raw availability could avoid some modeled loads. No decoder timing, browser PSS reduction or storage gain is claimed.

Reproduction, from the research directory:

```sh
node metadata/capture-cache-locality.mjs /tmp/manabitan-baseline-0119 metadata/jmdict-cache-locality-reproduced.json
```

That command requires the complete checkout, its locked dependencies and the pinned archive. Do not substitute a later candidate checkout. Its runtime counters are diagnostic and are not qualification timings.

## Initial native diagnostic identity

- Workflow run: https://github.com/ManabiIO/manabitan/actions/runs/46104742882
- Artifact: `15248211922`, 17,320,664 bytes, SHA-256 `3ed90f74bee97278220d8f0070190e86e5eed3c726c394e82d64b51e83bed4a8`.
- Clean source: `f3fd2373de6e74f6243008ff3f1f68703d688973`, before the typed-array-kind admission guard correction.
- Release ZIP SHA-256: `8e87b5894b1c004e5b6f13f9c5372c822c5523a80fdd930459272a80e39cfdbe`.
- Runtime: Node 22.22.0, Chromium 153.0.8010.12, four logical CPUs, Intel Xeon Platinum 8573C.
- Native module SHA-256: `60237c98d16196db00161af3a896aae4d2f8104f63401d5617d17f895e752b94`.
- Semantic digest: `e88726c0d84ad9f6e9b7cf4455783fee169a41bf0cbfe3252386cec59791117d`; retained storage 43,520,477 bytes, equal to the diagnostic baseline.

`native-initial-candidate-profile/` contains the raw trace/report, package entry receipt, exact four changed package files, export mapping, route samples, identity and findings. `verify-native-profile-binding.py` independently decodes exports and code-body starts from the packaged module and checks the corresponding trace call-frame offsets. It needs no compiler or network.

| Export index | Name | Code body offset |
| --- | --- | ---: |
| 4 | `scan_canonical` | 306 |
| 7 | `lookup_hash_update` | 1,829 |
| 8 | `lookup_hash_finish` | 2,158 |

The sampled callee URL is `wasm://wasm/ec14035e`. A JS-to-WASM bridge is attributed by Chrome to another URL; that bridge URL is not used to identify the native callee. The normal native algorithm's C/WASM/store bytes matched the later locally fixed worktree at the time of review; its hasher JS differs because of the admission guard. This does not authorize a final-head timing claim.

## Dependency and trace reconstruction

`import-overlap-findings.md` explains the complete source-confirmed lifetime and join path. `analyze-import-overlap.py` and `import-overlap-analysis.json` preserve all event joins and selected sample points for four independently instrumented imports:

| Directory | Source / scope |
| --- | --- |
| `jmdict-profile-9e10d3b3` | Frozen baseline, first diagnostic |
| `v3-cohort-baseline-profile` | Same frozen baseline, later qualification's diagnostic job |
| `score-v3-candidate-profile` | Score-v3 diagnostic, runtime source identical to its qualification candidate |
| `native-initial-candidate-profile` | Initial native candidate, before guard correction |

The retained raw traces/reports and identities are included for all four. `profile-package-entry-receipts.json` binds the original three packages; the native directory has its own complete package-entry receipt. Source snapshots under `sources/followup-baseline/` are copied byte-for-byte from the clean frozen checkout and hashed in the archive manifest.

Each trace has 103 exact compressor dispatch events. Trace IDs join dispatch, worker handler, source-consumed send, compressed-result send, and both receiver handlers. The actual production group block counts are 9, 9, 9, 9, 9, 9, 7, 8, 8, 8, 8, 10. The analysis asserts round-robin worker assignment and every group's final response preceding the next group's dispatch. Signed CPU-profile intervals are preserved, and all selected sample points are independently checked against import-worker task intervals.

There is no exact per-group trace marker for reservation settlement, metadata publication, record completion or the database's terminal promise join. No missing timestamp is invented. Worker `tdur` values remain raw and are not summed into import latency. The separately audited score-v3 paired field counters (13.15 ms AB and 7.90 ms BA reductions) are qualification evidence, distinct from these traces.

Reproduce the static analyses without starting a browser:

```sh
python3 verify-native-profile-binding.py
python3 analyze-import-overlap.py
```

## Integrity and retained limitations

`cache-native-overlap-evidence-manifest.json` records every bundled file's length and SHA-256. The bundle receipt records archive length/hash and full readback verification. The earlier evidence bundle is unchanged. No observation was excluded from these analyses. The locality census is one complete diagnostic replay, not a timing cohort. All hosted profile counters remain in the raw reports, even when a phase looks anomalous or differs substantially across hosts.

The first standalone native-binding verifier rejected the module because it incorrectly treated a nonempty import section as imported functions. The module imports memory, not functions. The corrected verifier explicitly parses those memory limits, asserts zero imported functions, and then verifies the same export/body-offset/sample bindings. This was a static script assertion failure before any receipt was written; no browser observation or timing was discarded. `native-binding-verification-history.json` retains that correction.
