# Prepared Zstd state: read-only decision

This investigation binds the frozen Manabitan baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` and Zstd commit `82d322c4973d9e2968d94047a40892bc6d9a9bdf`. It ran no compression, native build, benchmark, or compressed-byte comparison and changed no product files. It does not establish an import gain.

## Decision

An ordinary `createCDict(-1)` substitution does not eliminate dictionary preparation on the nominal 1 MiB JMdict frames. The exact pinned implementation reloads the raw dictionary for known sources at or above 128 KiB (and six dictionary lengths). This explains why the earlier feasibility probe could show identical larger-frame output without demonstrating prepared-state reuse.

Matching advanced-CDict parameters to the current source size is insufficient to establish exact output. The advanced route can force reuse, but its initial search tables differ from the current raw-dictionary route. No safe admission based only on source length or an equal compression-parameter tuple follows from that design.

Preparing and copying a **raw CCtx** is a distinct, unimplemented possibility. It could preserve the existing fast-load tables, unlike CDict. However, its benefit is unmeasured, it retains another full context, it uses deprecated APIs, and the pinned copy implementation does not propagate one reset-allocation error. The exact Emscripten build is also not recoverable from recorded provenance alone. Do not start a production rebuild from the larger-prefix equality result.

## What #771 actually did

[PR #771](https://github.com/ManabiIO/manabitan/pull/771), head `aa09b85cbc43c8c9c05a3e7f1d1b7c53f41712a4`, was a native configuration study with a separate **read-only** compression audit. Its many browser observations concern the native configuration candidate, not CDict. The compression audit explicitly reports no compression, byte-parity experiment, native build, or timing cohort.

The audit classified 28 previously frozen blocks, 638,051–4,194,300 decoded bytes each. All take the ordinary-CDict reload branch. It identified the advanced full/tagged-table difference and mentioned a custom cache of the exact initial raw state as future work. It did not implement or test source-size-matched advanced CDict or raw CCtx copying. Its seven-bank / 4 MiB fixture must not be treated as the current twelve-group / 1 MiB import plan.

The exact source and report are retained in that PR's `builds/perf/20261120-native-config-study-v2/native-evidence.tar.xz`, member `compression-audit/compression-audit.md`. Reading the existing Git blob verifies 3,117,032 bytes and SHA256 `1f9c3822d610c96c83b9d1e3136e6e859db1f491a89efeb3c368bef7cbeabafe`.

The separate later Jitendex feasibility report records raw/CDict output differences at 1,024, 16,384 and 65,536 bytes, and equality at 131,072 bytes and larger tested prefixes. It reports 47,680 retained CDict bytes and 549,912 context bytes at the larger sizes. The JSON does not bind an executable toolchain, so these sizing numbers are historical probe observations, not verified WASM process-memory costs. [Retained feasibility](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/dev/perf/import-qualification-evidence-20261125-a7f7/jitendex-investigation/cdict-feasibility.json.txt).

## Exact branch and table mechanics

For a nonempty CDict with ordinary stored level -1 and default attachment preference, native prepared-state reuse requires source size below 128 KiB, below six dictionary lengths, or unknown. The private packaged dictionary is 16,384 bytes, so the six-times bound is 98,304 bytes. Known 1 MiB input satisfies none of these conditions. The fallback resets the CCtx and inserts the raw dictionary again. Advanced creation sets the stored level to zero, which overrides the size predicate and can actually select reuse. [Pinned branch](https://github.com/facebook/zstd/blob/82d322c4973d9e2968d94047a40892bc6d9a9bdf/lib/compress/zstd_compress.c#L5256-L5305).

Raw `compress_usingDict` derives its parameters from the actual source length with `ZSTD_cpm_noAttachDict`, then inserts the dictionary with `ZSTD_dtlm_fast` and CCtx table purpose. CDict initialization always uses `ZSTD_dtlm_full` and CDict table purpose. For the fast strategy, the current CCtx load writes every third position into a plain-index table. CDict uses tagged indices and additionally fills empty buckets from intervening positions. Copying a CDict table back strips the tags but retains those extra positions. Equal parameter tuples do not restore equal initial match tables. [Fast/full fills](https://github.com/facebook/zstd/blob/82d322c4973d9e2968d94047a40892bc6d9a9bdf/lib/compress/zstd_fast.c#L15-L96), [CDict copy](https://github.com/facebook/zstd/blob/82d322c4973d9e2968d94047a40892bc6d9a9bdf/lib/compress/zstd_compress.c#L2409-L2529), [CDict initialization](https://github.com/facebook/zstd/blob/82d322c4973d9e2968d94047a40892bc6d9a9bdf/lib/compress/zstd_compress.c#L5586-L5621).

At nominal 1 MiB and level -1, the source-derived compression tuple is windowLog 19, chainLog 12, hashLog 13, searchLog 1, minMatch 6, targetLength 1, fast strategy. This uses a 32 KiB hash table and no allocated chain table. These values are derived from the pinned tables and adjustment code, not measured from a new build. [Parameter selection](https://github.com/facebook/zstd/blob/82d322c4973d9e2968d94047a40892bc6d9a9bdf/lib/compress/zstd_compress.c#L8261-L8343), [level table](https://github.com/facebook/zstd/blob/82d322c4973d9e2968d94047a40892bc6d9a9bdf/lib/compress/clevels.h#L23-L32).

## Distinct possible experiment: raw CCtx cloning

A prepared source context could be initialized with `ZSTD_getParams(-1, actualSourceSize, dictSize)` plus `ZSTD_compressBegin_advanced`, left in its initialized stage, and copied to a working context with `ZSTD_copyCCtx` before `ZSTD_compressEnd`. Known nonzero sizes in public `getParams` use the same size treatment as the current no-attachment path. The copy API copies the initialized hash tables, entropy block state, dictionary references and offsets rather than constructing CDict tables. This is a hypothesis, not a demonstrated transparent replacement. [Copy implementation](https://github.com/facebook/zstd/blob/82d322c4973d9e2968d94047a40892bc6d9a9bdf/lib/compress/zstd_compress.c#L2530-L2628), [raw begin](https://github.com/facebook/zstd/blob/82d322c4973d9e2968d94047a40892bc6d9a9bdf/lib/compress/zstd_compress.c#L5308-L5361).

A production admission would compare the full derived parameter/frame state with the prepared state's state, and require a privately owned immutable dictionary and compatible destination context. It should fall back for any mismatch, including smaller-frame parameter classes, zero-size public-API special handling, generic empty-dictionary compression, and unsupported context settings. This derives selection from actual compression behavior rather than a dictionary-name-specific byte threshold. It still needs exact byte qualification over all source-size boundaries and sequential reuse; a matching tuple alone is not a completed proof.

Important additional problems:

- The header deprecates `copyCCtx`, says its utility is limited, and anticipates removal. A pinned internal helper would avoid an unstable public contract only by owning more upstream-internal implementation.
- `ZSTD_copyCCtx_internal` invokes `ZSTD_resetCCtx_internal` without testing its returned error before accessing destination tables. A direct public-API substitution therefore needs careful allocation/resize failure handling. This is source inspection, not a reproduced allocation failure.
- Dictionary references retained by a prepared context must point to stable native bytes. Existing per-context dictionary staging buffers are mutable and can be reused by generic/public wrapper calls. Pointer identity or JS object identity cannot authorize caching a mutable dictionary.
- The source context must remain initialized and unused for compression. Both contexts and any dedicated dictionary storage need symmetric cleanup. Prepared-span one-shot consumption, cancellation and error ordering must remain intact.

## Value and toolchain limits

For each nominal 1 MiB frame, raw CCtx copying would replace dictionary entropy reconstruction and at most 5,459 fast hash iterations (a conservative bound ignoring the dictionary's entropy header) with a 32 KiB hash-table copy plus entropy-state copying. It still performs destination reset and the actual source matchfinding/compression. It would retain another full prepared context in each participating worker. The previous 549,912-byte context observation suggests that this is substantially larger than the 47,680-byte CDict, but it is not a WASM memory measurement.

The fresh browser traces do not isolate dictionary preparation. The independently export-bound compression attribution is in `../compression-attribution.json`: it can identify the whole `compress_usingDict` subtree and the envelope helper, but the dominant internal functions have anonymous indexes. Do not label those indexes as entropy setup or matchfinding without a proven symbol map. No setup-time saving, import-speed prediction, or memory-gate claim is supported here.

The packaged WASM is 433,631 bytes, SHA256 `ad3a18c197d72167262d01fd202976325f57a6697bca627f4527c96d4dbbcfcc`, with **no custom sections**, so it contains neither a function-name map nor compiler-producers metadata. The builder pins upstream commit `82d322c...` and `-O3 -flto -msimd128`, but runs `emcc` from PATH. Provenance records only `5.0.1-git`, without an exact Emscripten compiler commit. No emcc/emsdk executable was found locally. Existing LLVM 21 used by the dictionary parser is a different build path. Any future compressor rebuild must first reproduce the current JS/WASM bytes, or qualify the toolchain change separately before attributing a gain to prepared-state reuse.

The old `compression/jmdict-capture.json` still records the invented `raw-token-v6` metadata name. It is not the corrected raw-v6 deduplication capture and was not used to claim current frame coverage here.

## Reproduction and retained evidence

`read-only-audit.json` binds eleven frozen product inputs, six upstream files, the dictionary, WASM custom sections and source-derived threshold/parameter arithmetic. The upstream checkout was clean at the exact pin. Local Git reads disable lazy fetching. `pr771-metadata.json` preserves PR metadata and its scope statement.

```sh
python3 builds/research-0119/cdict-investigation/read-only-audit.py \
  --repo /workspace/scratch/0119d2336c5c/manabitan \
  --zstd /tmp/manabitan-a7c4-zstd-source \
  --output builds/research-0119/cdict-investigation/read-only-audit.json
```

No large source/toolchain downloads, native compiler invocation, or runtime change was made.
