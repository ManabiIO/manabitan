#!/usr/bin/env python3
"""Bind source-only prepared-dictionary findings; do not build or execute Zstd."""
import argparse
import hashlib
import json
import os
import pathlib
import subprocess


def git(root, *args):
    env = dict(os.environ, GIT_NO_LAZY_FETCH='1')
    return subprocess.check_output(['git', '-C', str(root), *args], env=env)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def binding(root, relative, commit=None):
    data = git(root, 'show', f'{commit}:{relative}') if commit else (root / relative).read_bytes()
    return {'path': relative, 'bytes': len(data), 'sha256': digest(data),
            'gitBlob': hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()}


def custom_sections(data):
    def leb(position):
        result = shift = 0
        while True:
            byte = data[position]
            position += 1
            result |= (byte & 127) << shift
            if byte < 128:
                return result, position
            shift += 7
    assert data[:8] == b'\0asm\x01\0\0\0'
    result = []
    position = 8
    while position < len(data):
        section = data[position]
        length, start = leb(position + 1)
        position = start + length
        assert position <= len(data)
        if section == 0:
            name_length, name_start = leb(start)
            result.append(data[name_start:name_start + name_length].decode())
    assert position == len(data)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=pathlib.Path, required=True)
    parser.add_argument('--zstd', type=pathlib.Path, required=True)
    parser.add_argument('--output', type=pathlib.Path, required=True)
    args = parser.parse_args()
    baseline = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
    upstream = '82d322c4973d9e2968d94047a40892bc6d9a9bdf'
    assert git(args.zstd, 'rev-parse', 'HEAD').decode().strip() == upstream
    assert git(args.zstd, 'status', '--porcelain') == b''
    source = (args.zstd / 'lib/compress/zstd_compress.c').read_text()
    fast = (args.zstd / 'lib/compress/zstd_fast.c').read_text()
    levels = (args.zstd / 'lib/compress/clevels.h').read_text()
    assert '#define ZSTD_USE_CDICT_PARAMS_SRCSIZE_CUTOFF (128 KB)' in source
    assert '#define ZSTD_USE_CDICT_PARAMS_DICTSIZE_MULTIPLIER (6ULL)' in source
    assert 'ZSTD_dtlm_full, ZSTD_tfp_forCDict' in source
    assert 'assert(dtlm == ZSTD_dtlm_fast);' in fast
    assert '{ 19, 12, 13,  1,  6,  1, ZSTD_fast' in levels
    dictionary = git(args.repo, 'show', f'{baseline}:dev/data/zstd-dicts/jmdict.zdict')
    wasm = git(args.repo, 'show', f'{baseline}:dev/data/zstd-simd.wasm')
    assert len(dictionary) == 16384
    assert dictionary[:4] == bytes.fromhex('37a430ec')
    product_paths = [
        'dev/bin/build-zstd-wasm.js', 'dev/data/zstd-wasm.PROVENANCE.md',
        'dev/data/zstd-simd.wasm', 'dev/data/zstd-dicts/jmdict.zdict',
        'dev/lib/zstd-simd-module.js', 'dev/lib/zstd-simd-module.d.ts',
        'dev/lib/zstd-wasm.js', 'ext/js/dictionary/zstd-term-content.js',
        'ext/js/dictionary/zstd-term-content-compression-worker.js',
        'ext/js/dictionary/dictionary-database.js',
        'dev/perf/import-qualification-evidence-20261125-a7f7/jitendex-investigation/cdict-feasibility.json.txt',
    ]
    upstream_paths = [
        'lib/compress/zstd_compress.c', 'lib/compress/zstd_compress_internal.h',
        'lib/compress/zstd_fast.c', 'lib/compress/clevels.h', 'lib/zstd.h',
        'build/single_file_libs/create_single_file_library.sh',
    ]
    cases = []
    for size in [100, 1024, 16384, 65536, 98303, 98304, 131071, 131072, 262144, 1048576]:
        cases.append({'sourceBytes': size,
                      'ordinaryCDictPreparedStateSelected': size < 128 * 1024 or size < len(dictionary) * 6,
                      'assumptions': 'known size, ordinary createCDict(-1), nonempty dictionary, default attachment preference'})
    result = {
        'scope': 'Read-only source audit and arithmetic. No compressor execution, native build, benchmark, or compressed-byte oracle.',
        'productBaseline': baseline, 'observedRepoHead': git(args.repo, 'rev-parse', 'HEAD').decode().strip(),
        'zstdCommit': upstream, 'zstdTree': git(args.zstd, 'rev-parse', 'HEAD^{tree}').decode().strip(),
        'productInputs': [binding(args.repo, path, baseline) for path in product_paths],
        'upstreamInputs': [binding(args.zstd, path) for path in upstream_paths],
        'packagedWasmCustomSections': custom_sections(wasm),
        'dictionary': {'bytes': len(dictionary), 'sha256': digest(dictionary),
                       'magic': hex(int.from_bytes(dictionary[:4], 'little')),
                       'id': int.from_bytes(dictionary[4:8], 'little')},
        'ordinaryCDictCases': cases,
        'nominalOneMiBLevelMinusOneSourceDerivedParameters': {
            'windowLog': 19, 'chainLog': 12, 'hashLog': 13, 'searchLog': 1,
            'minMatch': 6, 'targetLength': 1, 'strategy': 'ZSTD_fast',
            'hashTableBytesToCopy': (1 << 13) * 4, 'allocatedChainTableBytes': 0,
            'dictionaryHashIterationUpperBoundIgnoringEntropyHeader': (len(dictionary) - 10) // 3 + 1,
            'qualification': 'Parameters derived by reading the pinned default table and adjustment code; not observed via runtime.'},
        'priorAudit': {'pr': 771, 'head': 'aa09b85cbc43c8c9c05a3e7f1d1b7c53f41712a4',
                       'implementedCDictExperiment': False, 'compressedBytesOrTimingMeasured': False},
        'toolchain': {'recorded': 'Emscripten 5.0.1-git, -O3 -flto -msimd128',
                      'exactCompilerCommitRecorded': False, 'reproducibilityExecutedInThisAudit': False},
        'scriptSha256': digest(pathlib.Path(__file__).read_bytes()),
    }
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'output': str(args.output), 'scope': result['scope'],
                      'inputs': len(product_paths) + len(upstream_paths), 'customSections': custom_sections(wasm)}))


if __name__ == '__main__':
    main()
