// Research-only baseline screen. Every measured first use is a fresh process.
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFileSync, writeFileSync} from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const directory = path.dirname(fileURLToPath(import.meta.url));
const [root, output] = process.argv.slice(2);
const source = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2';
assert.equal(execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8',
    env: {...process.env, GIT_NO_LAZY_FETCH: '1'}}).trim(), source);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const host = () => ({capturedAt: new Date().toISOString(), node: process.version, v8: process.versions.v8,
    cpu: os.cpus()[0].model, logicalCpuCount: os.cpus().length, availableParallelism: os.availableParallelism(),
    loadAverage: os.loadavg(), freeMemoryBytes: os.freemem()});
const median = (values) => {
    const ordered = [...values].sort((a, b) => a - b);
    const index = Math.floor(ordered.length / 2);
    return ordered.length % 2 ? ordered[index] : (ordered[index - 1] + ordered[index]) / 2;
};
const hostBefore = host();
const observations = [];
for (let block = 1; block <= 6; ++block) {
    const kinds = block % 2 ? ['base', 'braid'] : ['braid', 'base'];
    const arms = block % 2 ? ['A', 'C'] : ['C', 'A'];
    for (const kind of kinds) {
        for (const arm of arms) {
            const child = execFileSync(process.execPath, [path.join(directory, 'first-use.mjs'), root, kind],
                {encoding: 'utf8', timeout: 30000});
            observations.push({block, arm, ...JSON.parse(child)});
        }
    }
}
const summary = {};
for (const kind of ['base', 'braid']) {
    const selected = observations.filter((row) => row.kind === kind);
    summary[kind] = {count: selected.length,
        firstCrcMs: {minimum: Math.min(...selected.map((row) => row.firstCrcMs)),
            median: median(selected.map((row) => row.firstCrcMs)), maximum: Math.max(...selected.map((row) => row.firstCrcMs))},
        compileMsMedian: median(selected.map((row) => row.compileMs)),
        instantiateMsMedian: median(selected.map((row) => row.instantiateMs)),
        compileInstantiateFirstCrcMsMedian: median(selected.map((row) => row.compileInstantiateFirstCrcMs)),
        subsequentCallMsMedian: median(selected.flatMap((row) => row.subsequentMs)),
        identicalCodeControlRatios: Array.from({length: 6}, (_, index) => {
            const pair = selected.filter((row) => row.block === index + 1);
            return pair.find((row) => row.arm === 'C').firstCrcMs / pair.find((row) => row.arm === 'A').firstCrcMs;
        })};
}
const result = {complete: true, source, root, scope: 'Baseline-only fresh-process upper-bound screen using the unmodified production CRC-verification export. No candidate, compiler invocation, dictionary corpus, browser or complete-import timing.',
    protocol: 'Six blocks; two identical-code fresh-process controls per input kind; block order and arm labels alternate. No warmup before first call, no discarded observations. Allocation, byte copy and Node zlib oracle occur outside the recorded compile/instantiate/call durations.',
    interpretation: 'The first 256 KiB CRC call includes all lazy table setup plus CRC work and first-call runtime overhead. Subsequent calls and control ratios are diagnostics, not an isolated initialization measurement or speedup estimate.',
    prospectiveStopRule: 'If the entire first 256 KiB CRC call remains below one millisecond in this bounded screen, stop before implementing constant tables or running corpus/hosted work.',
    staticCost: {baseTableBytes: 16 * 256 * 4, braidTableBytes: 8 * 256 * 4,
        addedConstantDataBytesBeforeCompilerChanges: 24 * 256 * 4, braidSetupByteSteps: 8 * 256 * 56},
    firstUseScriptSha256: sha(readFileSync(path.join(directory, 'first-use.mjs'))),
    runnerSha256: sha(readFileSync(fileURLToPath(import.meta.url))),
    manifestSha256: sha(readFileSync(path.join(root, 'dev/data/dictionary-wasm/manifest.json'))),
    parserSourceSha256: sha(readFileSync(path.join(root, 'ext/js/dictionary/wasm/term-bank-parser.c'))),
    hostBefore, hostAfter: host(), observations, summary};
writeFileSync(output, JSON.stringify(result, null, 2) + '\n', {flag: 'wx'});
process.stdout.write(JSON.stringify({output, summary}, null, 2) + '\n');
