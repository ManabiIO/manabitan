// Research-only first-use upper bound; no product source or WASM changes.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFileSync} from 'node:fs';
import path from 'node:path';
import {performance} from 'node:perf_hooks';
import {crc32} from 'node:zlib';

const [root, kind] = process.argv.slice(2);
assert(kind === 'base' || kind === 'braid');
const binaryPath = path.join(root, 'dev/data/dictionary-wasm/term-bank-parser.wasm');
const binary = readFileSync(binaryPath);
const binarySha256 = createHash('sha256').update(binary).digest('hex');
assert.equal(binarySha256, '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee');
const sourceLength = kind === 'base' ? 0 : 262144;
const source = new Uint8Array(sourceLength);
let seed = 0x4d595df4;
for (let index = 0; index < sourceLength; ++index) {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    source[index] = seed >>> 24;
}
const expectedCrc = crc32(source) >>> 0;
let start = performance.now();
const module = await WebAssembly.compile(binary);
const compileMs = performance.now() - start;
assert.deepEqual(WebAssembly.Module.imports(module), []);
start = performance.now();
const instance = await WebAssembly.instantiate(module);
const instantiateMs = performance.now() - start;
const wasm = instance.exports;
wasm.wasm_reset_heap();
const input = wasm.wasm_alloc(Math.max(sourceLength, 8));
const spans = wasm.wasm_alloc(8);
const signatures = wasm.wasm_alloc(4);
assert(input !== 0 && spans !== 0 && signatures !== 0);
new Uint8Array(wasm.memory.buffer, input, sourceLength).set(source);
new Uint32Array(wasm.memory.buffer, spans, 2).set([0, sourceLength]);
new Uint32Array(wasm.memory.buffer, signatures, 1)[0] = expectedCrc;
const invoke = () => wasm.verify_term_bank_source_crcs(input, sourceLength, spans, 1, signatures, 0, 0, 0, 0);
start = performance.now();
const firstStatus = invoke();
const firstCrcMs = performance.now() - start;
assert.equal(firstStatus, 0, 'Production CRC export must match Node zlib');
const subsequentMs = [];
for (let index = 0; index < 8; ++index) {
    start = performance.now();
    const status = invoke();
    subsequentMs.push(performance.now() - start);
    assert.equal(status, 0);
}
process.stdout.write(JSON.stringify({kind, sourceLength, expectedCrc, binaryBytes: binary.length,
    binarySha256, compileMs, instantiateMs, firstCrcMs, compileInstantiateFirstCrcMs: compileMs + instantiateMs + firstCrcMs,
    subsequentMs, firstStatus, node: process.version, v8: process.versions.v8}) + '\n');
