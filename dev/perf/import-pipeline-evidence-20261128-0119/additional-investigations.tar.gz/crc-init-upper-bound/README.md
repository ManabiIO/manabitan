# CRC lazy initialization: bounded first-use screen

Stop before implementing precomputed tables. In this bounded Node 22.22.0 screen, all twelve first 256 KiB CRC-verification calls finished below one millisecond. Each call includes both lazy table initializations, the actual CRC work and first-call runtime overhead. This leaves little demonstrated opportunity relative to adding 24 KiB of constant data to the parser module. No compiler or candidate implementation was used.

## Identity and protocol

The source is frozen baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. The unchanged checked-in parser WASM has SHA256 `8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee`. Its manifest records LLVM/LLD 21.1.8 and the production flags. The script verifies the binary hash and source checkout identity before measuring; this screen did not perform a compiler reproducibility check.

Twenty-four fresh Node processes execute six alternating blocks. Each block has two identical-code controls for an empty source and two for a 256 KiB deterministic source. The script measures module compilation, instantiation and the first call separately. Allocation, byte copy and the independent Node zlib checksum occur outside those recorded durations. There is no warmup before the first call. Eight subsequent calls per process are retained only as diagnostics. All calls must return successful verification against the zlib signature.

The actual production export `verify_term_bank_source_crcs` is used with one contiguous source span, no parsed rows and no glossary witnesses. Empty input initializes only the base slicing tables. A 262,144-byte input takes the braided path, including base and braid table initialization. No test-only export or reduced C implementation substitutes for the packaged module.

## Observations

| Scope | Observations | First-call minimum | First-call median | First-call maximum | Compile + instantiate + first-call median |
| --- | ---: | ---: | ---: | ---: | ---: |
| Empty source / base table | 12 | 0.1818 ms | 0.2260 ms | 1.2122 ms | 1.0751 ms |
| 256 KiB / base + braid | 12 | 0.4775 ms | 0.5522 ms | 0.7502 ms | 1.5532 ms |

The 1.2122 ms empty-input outlier is retained. Identical-code first-call ratios are noisy; no ratio is interpreted as a candidate speedup. The first 256 KiB call's cost includes substantially more than table setup, so it is a useful local opportunity screen, not an isolated initialization measurement. It is not a strict cross-device bound and is not a measurement of three-worker wall-time savings.

The base arrays occupy 16 × 256 × 4 = 16,384 bytes; the braid arrays occupy 8 × 256 × 4 = 8,192 bytes. Braid initialization performs 8 × 256 × 56 = 114,688 byte-advance steps. Constants would carry 24,576 bytes of raw table data before accounting for removed initialization code, compiler layout or release ZIP compression. No exact candidate package-growth number is claimed.

All 24 first calls and 192 subsequent calls passed their zlib-derived verification. The inherited runtime emitted experimental EnvHttpProxyAgent startup warnings; no process failed. No observation was discarded or rerun. No companion, full-corpus replay, product edit or hosted experiment followed this screen.

## Reproduction

`fresh-process-node22.json` retains every observation, identical-code control ratio, host/runtime metadata and source/script hashes. Run with a supported Node 22 executable and a clean checkout of the bound baseline:

```sh
node builds/research-0119/crc-init-upper-bound/run.mjs \
  /tmp/manabitan-baseline-0119 \
  builds/research-0119/crc-init-upper-bound/new-observations.json
```

The runner refuses to overwrite an existing result. This remains a local first-use component screen, not an import-latency claim.
