#!/usr/bin/env python3
"""Keep source-bound pipeline research and rejected experiments reviewable."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
DEST = ROOT.parents[1] / 'dev/perf/import-pipeline-evidence-20261128-0119'
DEST.mkdir(parents=True, exist_ok=True)
original = ROOT / 'profile-metadata-evidence-0119.tar.gz'
assert hashlib.sha256(original.read_bytes()).hexdigest() == '0bc192e15efdc5ae4b2e9e354855d677b24abf40df8cf11272a1600d1f9e4621'
omitted = []
members = []
subset = DEST / 'profile-metadata-review-subset.tar.gz'
with tarfile.open(original, 'r:gz') as old, subset.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w|') as new:
            for item in old.getmembers():
                assert item.isfile(), item.name
                data = old.extractfile(item).read()
                info = {'path': item.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                if item.name == 'metadata/jmdict-publication.v8':
                    omitted.append(info)
                    continue
                out = tarfile.TarInfo(item.name)
                out.size, out.mode, out.mtime = len(data), 0o644, 0
                new.addfile(out, io.BytesIO(data))
                members.append(info)
assert len(omitted) == 1 and len(members) == 48
with tarfile.open(subset, 'r:gz') as archive:
    actual = {m.name: hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in archive.getmembers()}
assert actual == {m['path']: m['sha256'] for m in members}
followup = ROOT / 'cache-native-overlap-evidence-0119.tar.gz'
assert hashlib.sha256(followup.read_bytes()).hexdigest() == '4187906d86a72d5a9bdd7ef0cda94c5e97541e573bced03c03c57f98038827f9'
shutil.copyfile(followup, DEST / followup.name)
files = ['package-pipeline-evidence.py', 'cache-native-overlap-evidence-0119.json', 'cache-native-overlap-evidence-index.md', 'profile-metadata-evidence-0119.json']
for folder in ['cdict-investigation', 'crc-init-upper-bound']:
    files.extend(str(p.relative_to(ROOT)) for p in (ROOT / folder).rglob('*') if p.is_file())
extra_members = []
with (DEST / 'additional-investigations.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w|') as tar:
            for relative in sorted(files):
                data = (ROOT / relative).read_bytes()
                item = tarfile.TarInfo(relative)
                item.size, item.mode, item.mtime = len(data), 0o644, 0
                tar.addfile(item, io.BytesIO(data))
                extra_members.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with tarfile.open(DEST / 'additional-investigations.tar.gz', 'r:gz') as tar:
    actual = {m.name: hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers()}
assert actual == {m['path']: m['sha256'] for m in extra_members}
readme = '''# JMdict pipeline investigation: retained evidence

These investigations do not establish a new whole-import speedup. They preserve the current browser-route evidence, the dependencies between compression and record writing, and several experiments stopped before product promotion. The frozen source is `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`; candidate identities are explicitly separated below. No runtime change is introduced by this evidence directory.

## Findings that constrain the next optimization

| Investigation | Evidence | Decision |
| --- | --- | --- |
| Score encoder | Both independently scheduled JMdict cohorts lower field-encoding counters but do not improve complete imports. | No score-cache PR; full results and raw observations are in the adjacent `import-score-hosted-evidence-20261128-0119` directory. |
| Compression and record overlap | Exact joins for 103 block messages in each of four browser traces show permitted overlap and delayed delivery of completed compression results. | Do not treat receiver-side compression counters as codec CPU time, add overlapping counters, or claim that most field savings were hidden. |
| Recent-source cache | Current JMdict adopts 101,143,281 view bytes with zero additional cache payload copies. Its 3,998 exact comparisons read 843,359 bytes but touch 93 of 103 blocks. | No redundant cache copy exists to remove; reject a second compressed cache and premature raw-cache retirement. |
| Metadata statistics fusion | Complete current-source publication census; an optimistic fused component screen saves roughly half a millisecond warm before admission costs, with noisy controls. | No product prototype or hosted candidate. |
| Prepared compression dictionary | Exact pinned upstream audit shows ordinary CDict reload for the production large-block regime. Advanced/raw-context alternatives need separate byte-equality and reproducible-toolchain evidence. | Do not infer reusable-dictionary gains from existing byte parity. No new compressor build or timing cohort. |
| CRC table constants | The existing production module's first 256 KiB verification call, including both table initializations and CRC work, has a 0.5522 ms median across twelve fresh-process observations, range 0.4775–0.7502 ms. | Stop before a candidate rebuild. Constants would add about 24 KiB of table data before removed code to the roughly 68 KiB parser module. This host result is not a universal bound. |

## What overlap does and does not establish

Current-group deduplication precedes compression dispatch. Logical reference reservation then permits metadata publication and record encoding while compression continues. Content and record owners are joined with `Promise.allSettled` before the ordered sink advances. Parser-produced independent shared buffers permit producer progress without lending the parser's live heap to the sink.

The worker's `source-consumed` message marks input gathering, before compression output exists. The database wrapper exposes reservation and terminal completion; borrowed-source retirement remains tied to terminal completion. Removing that lifetime boundary would be a separate scheduling change.

The analysis joins dispatch, worker handling, source-consumed sends, compressed-result sends and both receiver handlers by exact `traceId`. Many record-field and checksum samples occur after workers sent all outputs but before the import worker handled the final result. There are no exact markers for per-group metadata publication, record completion or the final promise join. No such timestamps are inferred. Sample counts are not milliseconds, negative profile intervals are retained, and diagnostic jobs are not substituted for the unprofiled paired cohorts.

The raw-cache locality model redirects the observed raw comparisons into 90,794,154 decoded bytes even with one decode per touched block. Two explicit existing-48-MiB-LRU completion scenarios produce 182 loads and 179,138,967 decoded bytes. These are untimed accounting scenarios, not browser decode measurements or exhaustive ordering bounds. In-flight raw sources could avoid some fallback loads. The existing content import overlay already owns compressed frames by reference.

## Native checksum route proof

The initial candidate diagnostic in [run 46104742882](https://github.com/ManabiIO/manabitan/actions/runs/46104742882), source `f3fd2373de6e74f6243008ff3f1f68703d688973`, contains 30 leaf samples in `lookup_hash_update` and one in `lookup_hash_finish`, under the expected hasher/envelope ancestry. Exact packaged WASM export indices and function-body offsets bind the sampled functions to the candidate. The module SHA256 is `60237c98d16196db00161af3a896aae4d2f8104f63401d5617d17f895e752b94`.

This source precedes the intrinsic typed-array-kind admission correction. It establishes execution of the native algorithm on ordinary input; it is not final-head performance qualification. Subsequent native cohort outcomes must be assessed separately, including source validation, raw timing, controls and memory coverage.

## Archive contents and reproduction limits

- `cache-native-overlap-evidence-0119.tar.gz` is the unchanged 58-member follow-up bundle. It retains all four raw browser traces/reports, source/package identities, exact message joins, native export binding, locality census, ownership review and reproduction scripts.
- `profile-metadata-review-subset.tar.gz` retains 48 of the earlier 49 members byte-for-byte: the original profile analyses, compression attribution, full rejected metadata-screen observations, capture script and source snapshots. The sole omitted member is the 14,876,086-byte generated V8 metadata input capture. Its exact hash and regeneration recipe remain retained; no timed observation was omitted. The subset is explicitly distinct from the original archive, whose hash remains recorded.
- `additional-investigations.tar.gz` retains the complete CDict source audit, CRC first-use scripts and every observation/control, original bundle receipts, index and this packager. The CRC screen uses Node 22.22.0 and the unchanged production verifier; all first/subsequent results match independent Node zlib. Its empty-input base-initialization screen includes the retained 1.2122 ms outlier. No candidate timing, all-corpus CRC parity or browser gain is claimed from that diagnostic.

Every included archive was read back and hashed before publication. `files.sha256.json.txt` records outer hashes, review members, the omitted regenerable capture and original archive identity. Unpack each bundle into a separate directory initially; shared profile paths deliberately preserve the same original evidence. Follow each included index for complete replay requirements, including the locked fixtures and exact source checkout. Failed acquisition, earlier adapter-fidelity limitations, script preflight corrections and noisy observations remain disclosed in the retained reports.
'''
(DEST / 'README.md').write_text(readme)
subprocess.run([str(ROOT.parents[1] / 'node_modules/.bin/prettier'), '--write', str(DEST / 'README.md')], check=True, capture_output=True)
outputs = []
for path in sorted(DEST.iterdir()):
    if path.is_file() and path.name != 'files.sha256.json.txt':
        data = path.read_bytes()
        outputs.append({'path': path.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
manifest = {'originalProfileArchive': {'path': original.name, 'bytes': original.stat().st_size, 'sha256': hashlib.sha256(original.read_bytes()).hexdigest()}, 'outputs': outputs, 'profileReviewMembers': members, 'omittedRegenerableInputs': omitted, 'additionalInvestigationMembers': extra_members}
(DEST / 'files.sha256.json.txt').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'destination': str(DEST), 'outputs': outputs, 'omittedRegenerableInputs': omitted}, indent=2))
