import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFile, writeFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {serialize} from 'node:v8';
import {replayParserCorpus} from '../parser-replay.mjs';

const [rootInput, outputInput] = process.argv.slice(2);
assert(rootInput && outputInput);
const root = resolve(rootInput);
const output = resolve(outputInput);
const source = execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim();
assert.equal(source, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
const sha = (x) => createHash('sha256').update(x).digest('hex');
const load = (path) => import(pathToFileURL(join(root, path)));
const sourcePaths = ['ext/js/dictionary/dictionary-database.js', 'ext/js/dictionary/term-content-canonical-scan.js',
    'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm', 'ext/js/dictionary/term-content-block-store.js'];
const sourceHashes = Object.fromEntries(await Promise.all(sourcePaths.map(async (name) => [name, sha(await readFile(join(root, name)))])));
const databaseSource = await readFile(join(root, sourcePaths[0]), 'utf8');
const publishedState = Number(databaseSource.match(/const TERM_CONTENT_META_SLOT_PUBLISHED = (\d+);/)[1]);
const pendingState = Number(databaseSource.match(/const TERM_CONTENT_META_SLOT_PENDING = (\d+);/)[1]);
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: 4, deviceMemory: 8}});
const {DictionaryDatabase} = await load('ext/js/dictionary/dictionary-database.js');
const {NativeCanonicalScanner} = await load('ext/js/dictionary/term-content-canonical-scan.js');
const {RAW_TERM_CONTENT_TOKEN_DICT_NAME} = await load('ext/js/dictionary/raw-term-content.js');
const module = await WebAssembly.compile(await readFile(join(root, sourcePaths[2])));
const database = new DictionaryDatabase();
assert.equal(database._recentTermContentSourceCacheMaxBytes, 96 * 1024 * 1024);
database._nativeCanonicalScanner = new NativeCanonicalScanner({loadModule: async () => module});
database._bulkImportTransactionOpen = true;
database._deferTermsVirtualTableSync = true;
database._termContentStorageMode = 'raw-bytes';
database._termContentZstdInitialized = true;
database._appendResolvedArtifactTermRecords = async () => {};
let nextOffset = 0;
const stored = new Map();
const zeroProfile = {packMs: 0, compressMs: 0, envelopeMs: 0, referenceMs: 0, opfsAppendMs: 0, initialSelectionSavingsMiss: false};
// Keep the production early-reservation/publication call chain. This external
// storage adapter validates every source span but uses raw logical addresses;
// compression and physical OPFS are deliberately outside the census.
database._termContentBlockImportSession = {
    tryBeginAppendSpans(_dictionary, bytes, offsets, lengths) {
        assert(bytes instanceof Uint8Array && offsets instanceof Uint32Array && lengths instanceof Uint32Array);
        assert.equal(offsets.length, lengths.length);
        const contentOffsets = new Float64Array(lengths.length);
        for (let i = 0; i < lengths.length; ++i) {
            assert(offsets[i] <= bytes.length && lengths[i] <= bytes.length - offsets[i]);
            contentOffsets[i] = nextOffset;
            stored.set(nextOffset, bytes.subarray(offsets[i], offsets[i] + lengths[i]));
            nextOffset += Math.max(1, lengths[i]);
        }
        const result = {contentOffsets, contentLengths: lengths, contentDictName: RAW_TERM_CONTENT_TOKEN_DICT_NAME, ...zeroProfile};
        return {storage: Promise.resolve(result), completion: Promise.resolve(result), initialSelection: false};
    },
};
database._persistArtifactTermContent = async () => { throw new Error('Unexpected ordinary persistence fallback'); };
database._readTermEntryContentBytesDetailedBatch = async (requests) => requests.map(({contentOffset, contentLength}) => {
    const bytes = stored.get(contentOffset);
    assert(bytes && bytes.length === contentLength);
    return {status: 'ok', bytes};
});
const frames = [];
const metrics = [];
let current = null;
const originalPublish = database._publishArtifactTermContentMetadata;
const originalTry = database._tryPublishContiguousArtifactTermContentMetadata;
const originalCache = database._cacheRecentPublishedTermContentSources;
database._publishArtifactTermContentMetadata = function (state) {
    current = state;
    try { return originalPublish.call(this, state); } finally { current = null; }
};
database._tryPublishContiguousArtifactTermContentMetadata = function (staged, hash1s, hash2s, offsets, lengths, dictNameId, metadataValidated) {
    const spans = current.pendingContentSpans;
    const firstIndex = staged.indexes[0];
    const endIndex = firstIndex + offsets.length;
    const frame = {count: offsets.length, firstIndex, dictNameId, metadataValidated,
        sameSourceLengths: spans.lengths === lengths,
        sourceShared: spans.buffer.buffer instanceof SharedArrayBuffer,
        sourceByteLength: spans.buffer.byteLength,
        indexes: staged.indexes.slice(), hash1s: hash1s.slice(), hash2s: hash2s.slice(),
        offsets: offsets.slice(), lengths: lengths.slice(), sourceOffsets: spans.offsets.slice(),
        stateTable: this._termEntryContentMetaStateTable.slice(firstIndex, endIndex),
        hash1Table: this._termEntryContentMetaHash1Table.slice(firstIndex, endIndex),
        hash2Table: this._termEntryContentMetaHash2Table.slice(firstIndex, endIndex),
        lengthTable: this._termEntryContentMetaLengthTable.slice(firstIndex, endIndex)};
    const result = originalTry.call(this, staged, hash1s, hash2s, offsets, lengths, dictNameId, metadataValidated);
    frame.publishedContiguous = result;
    frames.push(frame);
    return result;
};
database._cacheRecentPublishedTermContentSources = function (staged, spans, importMetrics) {
    const frame = frames.at(-1);
    let minimum = Infinity, maximum = 0, total = 0, published = 0, contiguous = true;
    for (let i = 0; i < staged.indexes.length; ++i) {
        const index = staged.indexes[i];
        if (index < 0 || this._termEntryContentMetaStateTable[index] !== publishedState) { continue; }
        ++published;
        minimum = Math.min(minimum, spans.offsets[i]);
        maximum = Math.max(maximum, spans.offsets[i] + spans.lengths[i]);
        total += spans.lengths[i];
        contiguous &&= index === staged.indexes[0] + i;
    }
    frame.sourceStats = {minimum, maximum, total, published, contiguous};
    frame.retainedBytes = originalCache.call(this, staged, spans, importMetrics);
    return frame.retainedBytes;
};
const receipt = await replayParserCorpus({root, cacheDir: join(root, 'builds/e2e-dictionary-cache'), dictionary: 'jmdict',
    onChunk: async (chunk, _progress, {fixture}) => {
        chunk.dictionary = fixture.expectedTitle;
        chunk.dictionaryTotalRows = fixture.termRows;
        chunk.uniformContentDictName = RAW_TERM_CONTENT_TOKEN_DICT_NAME;
        await database._bulkAddArtifactTermsChunkWithContentDedup(chunk);
        metrics.push({...database._lastBulkAddTermsMetrics});
    }});
const totals = Object.fromEntries(['dedupNativeCallCount', 'dedupNativeScannedRows', 'dedupNativeFallbackCount', 'dedupUniqueCount',
    'dedupPersistedHitCount', 'dedupRecentSourceHitCount'].map((name) => [name, metrics.reduce((n, m) => n + m[name], 0)]));
assert.equal(totals.dedupNativeCallCount, 12);
assert.equal(totals.dedupNativeFallbackCount, 0);
assert.equal(totals.dedupUniqueCount, 362032);
assert.equal(totals.dedupPersistedHitCount, 3998);
assert.equal(totals.dedupRecentSourceHitCount, 3998);
for (const [name, expected] of Object.entries(sourceHashes)) { assert.equal(sha(await readFile(join(root, name))), expected); }
const capture = {source, sourceHashes, publishedState, pendingState, node: process.version, receipt, totals, metrics, frames,
    scope: 'Full pinned JMdict actual production parser/native canonical scanner/early reservation/publication/cache call chain, with explicit raw logical persistence adapter and no record or physical OPFS writes. Instrumented census; timings are not evidence. Frame metadata is copied immediately before synchronous publication for bounded loop component experiments.'};
const data = serialize(capture);
await writeFile(output, data, {flag: 'wx'});
const summary = {...capture, frames: frames.map((f) => Object.fromEntries(Object.entries(f).filter(([,v]) => !ArrayBuffer.isView(v)))), captureSha256: sha(data)};
await writeFile(`${output}.json`, `${JSON.stringify(summary, null, 2)}\n`, {flag: 'wx'});
console.log(JSON.stringify({output, bytes: data.length, totals, frames: summary.frames}));
