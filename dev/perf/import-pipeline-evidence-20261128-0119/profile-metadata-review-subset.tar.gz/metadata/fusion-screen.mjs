import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import {deserialize} from 'node:v8';
import {fileURLToPath} from 'node:url';
import {resolve} from 'node:path';

const [captureInput, outputInput, childArm] = process.argv.slice(2);
assert(captureInput && outputInput);
const capturePath = resolve(captureInput);
const captureBytes = await readFile(capturePath);
const capture = deserialize(captureBytes);
assert.equal(capture.source, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
assert.equal(capture.totals.dedupNativeFallbackCount, 0);
const {frames, pendingState, publishedState} = capture;
const totalRows = frames.reduce((n, f) => n + f.count, 0);
assert.equal(frames.length, 12);
assert.equal(totalRows, 362032);
for (const f of frames) {
    assert(f.metadataValidated && f.sameSourceLengths && f.publishedContiguous);
    assert.equal(f.sourceStats.published, f.count);
    assert.equal(f.sourceStats.contiguous, true);
    assert(f.sourceStats.total < f.count * 512);
}

function createTables() {
    const t = {state: new Uint8Array(totalRows), hash1: new Uint32Array(totalRows),
        hash2: new Uint32Array(totalRows), length: new Uint32Array(totalRows),
        id: new Float64Array(totalRows), offset: new Float64Array(totalRows), dict: new Uint32Array(totalRows)};
    for (const f of frames) {
        t.state.set(f.stateTable, f.firstIndex);
        t.hash1.set(f.hash1Table, f.firstIndex);
        t.hash2.set(f.hash2Table, f.firstIndex);
        t.length.set(f.lengthTable, f.firstIndex);
    }
    return t;
}

// Deliberately optimistic valid-input kernel: eligibility, alias/ownership
// proof, sampling, map retirement and final cache writes remain outside scope.
function validateMetadata(f, t) {
    const {count, firstIndex, indexes, hash1s, hash2s, offsets, lengths, metadataValidated} = f;
    const {state, hash1, hash2, length: lengthTable} = t;
    for (let i = 0; i < count; ++i) {
        const index = firstIndex + i;
        const offset = offsets[i];
        const length = lengths[i];
        if (indexes[i] !== index || state[index] !== pendingState ||
            hash1[index] !== hash1s[i] || hash2[index] !== hash2s[i] || lengthTable[index] !== length ||
            (!metadataValidated && (!Number.isSafeInteger(offset) || offset < 0 || length >= 0xffffffff))) {
            throw new Error('Invalid metadata');
        }
    }
}
function publish(f, t) {
    const {firstIndex, count, offsets, dictNameId} = f;
    const endIndex = firstIndex + count;
    t.id.fill(0, firstIndex, endIndex);
    t.offset.set(offsets, firstIndex);
    t.dict.fill(dictNameId, firstIndex, endIndex);
    t.state.fill(publishedState, firstIndex, endIndex);
}
function scanStatistics(f, t) {
    const {count, indexes, lengths, sourceOffsets, sourceByteLength} = f;
    let minimum = Infinity, maximum = 0, published = 0, total = 0, last = -1;
    for (let i = 0; i < count; ++i) {
        const index = indexes[i];
        if (index < 0 || t.state[index] !== publishedState) { continue; }
        const offset = sourceOffsets[i], length = lengths[i];
        if (offset > sourceByteLength || length > sourceByteLength - offset) { throw new Error('Invalid source'); }
        minimum = Math.min(minimum, offset);
        maximum = Math.max(maximum, offset + length);
        ++published;
        total += length;
        last = i;
    }
    return {minimum, maximum, published, total, last};
}
function scanStatisticsWithPriorWitness(f) {
    const {count, lengths, sourceOffsets, sourceByteLength} = f;
    let minimum = Infinity, maximum = 0, published = 0, total = 0, last = -1;
    for (let i = 0; i < count; ++i) {
        const offset = sourceOffsets[i], length = lengths[i];
        if (offset > sourceByteLength || length > sourceByteLength - offset) { throw new Error('Invalid source'); }
        minimum = Math.min(minimum, offset);
        maximum = Math.max(maximum, offset + length);
        ++published;
        total += length;
        last = i;
    }
    return {minimum, maximum, published, total, last};
}
function baseline(f, t) { validateMetadata(f, t); publish(f, t); return scanStatistics(f, t); }
function priorWitness(f, t) { validateMetadata(f, t); publish(f, t); return scanStatisticsWithPriorWitness(f); }
function fused(f, t) {
    const {count, firstIndex, indexes, hash1s, hash2s, offsets, lengths, metadataValidated,
        sourceOffsets, sourceByteLength} = f;
    const {state, hash1, hash2, length: lengthTable} = t;
    let minimum = Infinity, maximum = 0, total = 0;
    for (let i = 0; i < count; ++i) {
        const index = firstIndex + i;
        const offset = offsets[i];
        const length = lengths[i];
        if (indexes[i] !== index || state[index] !== pendingState ||
            hash1[index] !== hash1s[i] || hash2[index] !== hash2s[i] || lengthTable[index] !== length ||
            (!metadataValidated && (!Number.isSafeInteger(offset) || offset < 0 || length >= 0xffffffff))) {
            throw new Error('Invalid metadata');
        }
        const sourceOffset = sourceOffsets[i];
        if (sourceOffset > sourceByteLength || length > sourceByteLength - sourceOffset) { throw new Error('Invalid source'); }
        minimum = Math.min(minimum, sourceOffset);
        maximum = Math.max(maximum, sourceOffset + length);
        total += length;
    }
    publish(f, t);
    return {minimum, maximum, published: count, total, last: count - 1};
}

const functions = {A: baseline, B: fused, C: baseline, W: priorWitness};
const expected = frames.map((f) => ({minimum: f.sourceStats.minimum, maximum: f.sourceStats.maximum,
    published: f.count, total: f.sourceStats.total, last: f.count - 1}));
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
function tableHash(t) {
    const h = createHash('sha256');
    for (const v of Object.values(t)) { h.update(new Uint8Array(v.buffer, v.byteOffset, v.byteLength)); }
    return h.digest('hex');
}
function run(arm, t) {
    t.state.fill(pendingState); // reset excluded from timing
    const fn = functions[arm], statistics = [], groupMs = [];
    const start = performance.now();
    for (const f of frames) {
        const groupStart = performance.now();
        statistics.push(fn(f, t));
        groupMs.push(performance.now() - groupStart);
    }
    const elapsedMs = performance.now() - start;
    assert.deepEqual(statistics, expected); // checks excluded from timing
    return {arm, elapsedMs, groupMs};
}

if (childArm) {
    assert(Object.hasOwn(functions, childArm));
    const t = createTables();
    console.log(JSON.stringify({...run(childArm, t), tableHash: tableHash(t)}));
} else {
    const tables = Object.fromEntries(Object.keys(functions).map((arm) => [arm, createTables()]));
    const correctness = Object.keys(functions).map((arm) => ({...run(arm, tables[arm]), tableHash: tableHash(tables[arm])}));
    assert.equal(new Set(correctness.map((r) => r.tableHash)).size, 1);
    const orders = [['A', 'B', 'W', 'C'], ['B', 'C', 'A', 'W'], ['C', 'W', 'B', 'A'], ['W', 'A', 'C', 'B']];
    const warmup = [], warm = [], cold = [];
    for (let round = 0; round < 8; ++round) {
        for (const arm of orders[round % 4]) { warmup.push({round, ...run(arm, tables[arm])}); }
    }
    for (let round = 0; round < 24; ++round) {
        for (const [position, arm] of orders[round % 4].entries()) { warm.push({round, position, ...run(arm, tables[arm])}); }
    }
    for (let round = 0; round < 12; ++round) {
        for (const [position, arm] of orders[round % 4].entries()) {
            const child = spawnSync(process.execPath, [fileURLToPath(import.meta.url), capturePath, '-', arm],
                {encoding: 'utf8', maxBuffer: 1024 * 1024});
            assert.equal(child.status, 0, child.stderr);
            const result = JSON.parse(child.stdout);
            assert.equal(result.tableHash, correctness[0].tableHash);
            cold.push({round, position, ...result});
        }
    }
    const median = (xs) => {
        const x = [...xs].sort((a, b) => a - b);
        return (x[Math.floor((x.length - 1) / 2)] + x[Math.floor(x.length / 2)]) / 2;
    };
    const sum = (xs) => xs.reduce((n, x) => n + x, 0);
    const analyze = (rows, baselineArm, candidateArm) => {
        const base = rows.filter((r) => r.arm === baselineArm), candidate = rows.filter((r) => r.arm === candidateArm);
        const deltas = candidate.map((r, i) => r.elapsedMs - base[i].elapsedMs);
        return {baselineArm, candidateArm, pairs: base.length,
            baselineMedianMs: median(base.map((r) => r.elapsedMs)), candidateMedianMs: median(candidate.map((r) => r.elapsedMs)),
            pairedMedianDeltaMs: median(deltas),
            pairedMedianPercent: median(candidate.map((r, i) => (r.elapsedMs / base[i].elapsedMs - 1) * 100)),
            aggregatePercent: (sum(candidate.map((r) => r.elapsedMs)) / sum(base.map((r) => r.elapsedMs)) - 1) * 100,
            fasterPairs: deltas.filter((x) => x < 0).length};
    };
    const report = {source: capture.source, sourceHashes: capture.sourceHashes, node: process.version, v8: process.versions.v8,
        captureSha256: sha(captureBytes), scriptSha256: sha(await readFile(fileURLToPath(import.meta.url))),
        totalRows, groups: frames.length, correctness, warmup, warm, cold,
        summary: Object.fromEntries([['warm', warm], ['cold', cold]].map(([name, rows]) => [name,
            [['A', 'B'], ['A', 'C'], ['A', 'W'], ['W', 'B']].map(([a, b]) => analyze(rows, a, b))])),
        scope: 'Optimistic valid-input component bound: metadata validation + bulk metadata writes + complete source statistics on 362,032 actual newly published JMdict rows. A/C identical code; W models the prior #876 state witness; B fuses source statistics into validation. Actual native-scanner census, raw logical persistence adapter, copied metadata. Separate global table allocations of correct element types. Fresh-process cold 12-group kernels; warm kernels after 8 corpus warmups. Excludes parser, compression, OPFS, eligibility/alias/ownership proof, sampling, map retirement, cache-table writes and pipeline overlap. No product change, full-import claim or invalid-input/mutation-order proof.'};
    await writeFile(resolve(outputInput), `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'});
    console.log(JSON.stringify(report.summary));
}
