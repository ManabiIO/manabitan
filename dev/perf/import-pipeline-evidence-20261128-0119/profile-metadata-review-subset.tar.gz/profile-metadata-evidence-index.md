# JMdict browser diagnostics and rejected metadata experiment

This bundle records diagnostic execution evidence and one rejected component hypothesis. It does not establish a whole-import speedup. No product change was made for the metadata hypothesis.

## Browser source and package identity

| Diagnostic | Workflow run | Source | Release package SHA-256 |
| --- | --- | --- | --- |
| Frozen baseline | 46102526376 | `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` | `d635eca801f1403d64399cf7535b70005e763bf5b94a6b04ec8e9af10a943f40` |
| Frozen baseline from v3 qualification | 46103360828 | `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` | `d8de11016534b855dbb6990d3d37d445627756739673b5b3d9737d18ffa7ae39` |
| Score-cache v3 candidate | 46103981495 | `9f62612a9c1997b850e40abcdf9390ee565badf5` | `47f561c4498580e07686ffb675885d77eaed1f2cf9136773de404233f2f8b981` |

The two baseline ZIP containers differ, but every packaged entry is identical. The candidate's only changed packaged entry is `js/dictionary/term-record-opfs-store.js`, SHA-256 `65e3bc1c98b45175d350d79a282b6445225339fafbb9024a7f02f0379222f3c9`. Its product bytes match qualification source `02bfdeefe6d032a8598a68c196a5ccd949c5ae5d`; the later commit adds only the isolated diagnostic workflow. `profile-package-entry-receipts.json` preserves every entry's size and digest. Each diagnostic directory preserves artifact identity, the original report and summary, the full trace, and derived hotspots.

All three reports use Node 22.22.0, pinned Chromium 153.0.8010.12, the release target, production import defaults, and the complete pinned JMdict archive. They report three parser workers, twelve groups and 528,299 lexical rows. Sampled term/restart validation agrees on digest `e88726c0d84ad9f6e9b7cf4455783fee169a41bf0cbfe3252386cec59791117d`; logical OPFS storage is 43,520,477 bytes. This is sampled content and complete inventory/storage verification, not exhaustive equality of every stored definition.

### Actual optimized-route evidence

The candidate browser trace contains **58 leaf samples in `encodeCachedCompactRecordScores`** on the actual dictionary import worker. This positively proves that the optimized helper executes in the browser. Sampling does not establish its call count or that every group chose the helper. Separate precise Node coverage of the actual DB factory's live columns is outside this bundle's browser claim.

Diagnostic record-field counters are 35.2 ms in the first baseline, 36.0 ms in the second baseline, and 45.0 ms in the candidate. These are separate instrumented imports on different jobs, not a paired timing experiment. They must not be used to claim a regression or improvement. Qualification cohorts provide the performance evidence separately.

The apparent 285-leaf-sample candidate hotspot in `_publishResolvedArtifactTermContentPlan` is a short-interval burst: median recorded interval 8 microseconds, with 15.554 ms of positive interval weight. Sample counts do not have a uniform time scale. All original negative intervals and outliers remain in the traces and derived reports. Recorded intervals can include descheduling and waiting; they are not CPU time. Parser and compression counters overlap across threads and cannot be summed into import latency.

## Rejected metadata statistics fusion

### Hypothesis and exact production path census

After successful dense metadata publication, `_cacheRecentPublishedTermContentSources` scans all newly published source offsets and lengths to validate bounds and compute minimum, maximum and byte total. The hypothesis was to accumulate these statistics in the preceding metadata validation pass and avoid revisiting every row.

`metadata/capture-publication.mjs` runs the complete pinned JMdict parser pipeline at frozen source `9e10d3b3`, with the actual native canonical scanner and actual early-reservation/publication/cache call chain. Navigator concurrency and memory are set before DB construction, giving three parser workers and the actual 96 MiB source cache. External persistence deliberately uses validated raw logical addresses and `RAW_TERM_CONTENT_TOKEN_DICT_NAME` (`raw-v6`); compression, physical OPFS and record writes are excluded. The adapter returns the original source-length array, as production does. All counts are asserted; source files are hashed before and after.

The census succeeded:

- 12 native scanner calls and zero native fallbacks.
- 366,030 scanned unique representatives; 362,032 newly published definitions.
- 3,998 persisted exact matches, all served by the recent-source cache.
- All 12 groups have dense publication, original source-length identity and shared parser source slabs.
- Three groups have nonzero minimum source offsets (49, 289 and 366); the other nine begin at zero.

The captured 14,876,086-byte metadata corpus has SHA-256 `3dbb2d74160290d359119149ab5f026132e3848cf010505cb01a840e6c0cf765`. It preserves all original metadata values used by the component experiment. Its JSON receipt includes source hashes, parser options, full census and per-group details. Instrumentation timings in the census are not performance evidence.

### Screen and result

`metadata/fusion-screen.mjs` is an **optimistic valid-input kernel**, not a product implementation. It compares:

- A: metadata validation, bulk publication, then the full source-statistics scan.
- B: statistics accumulated in the metadata validation loop, then bulk publication.
- C: identical A code as a noise control.
- W: the earlier synchronous state-witness idea, still retaining the full statistics pass. This distinguishes the proposed fusion from the already unsuccessful #876 approach.

The screen uses all 362,032 captured rows in twelve groups, correct table element types, and equal output/statistics checks. Table allocation/reset and verification are outside timing. Eight warm corpus rounds precede 24 balanced warm rounds. Twelve further balanced blocks use a fresh Node process for every arm. Every raw corpus and group observation is retained, including outliers. Runtime: Node 24.22.3 / V8 13.6.233.17-node.63.

| Comparison | Paired median difference | Equal-work difference | Interpretation |
| --- | ---: | ---: | --- |
| Warm B versus A | −0.495 ms (−13.56%) | +9.91% | Small absolute median benefit; outliers reverse aggregate direction |
| Warm C versus A, identical code | −0.127 ms (−3.82%) | −1.43% | Nonzero control variation |
| Warm B versus W | −0.450 ms (−12.91%) | −6.26% | Small incremental benefit beyond the prior witness |
| Cold B versus A | −2.508 ms (−17.90%) | −28.53% | Apparent benefit is not robust against control noise |
| Cold C versus A, identical code | +3.343 ms (+20.24%) | +71.15% | Control variation exceeds the proposed cold improvement |

The warm baseline median is 3.403 ms for this deliberately narrow kernel. This screen excludes the cost of safe eligibility, input/write overlap checks, ownership proof, callbacks, source-cache retirement, sampling and cache-table insertion. It does not prove original invalid-input, mutation or partial-error behavior. Carrying the new statistics across those operations would require additional admission or refactoring. The bounded experiment therefore does not justify that complexity: **the metadata idea is closed without a product patch or hosted cohort**.

There was no failed timed import or excluded measured observation. One script write initially failed because the workspace was nearly full; it occurred before syntax checking or execution. After removing only owned duplicate downloads, the complete script was written, syntax-checked and executed once. Raw timing noise and the unfavorable aggregate result are retained rather than filtered.

## Compression attribution supported by exact symbols

`analyze-compression-attribution.py` independently verifies the three release ZIP hashes and exact packaged Zstd module/glue bytes, decodes the module export section, and maps exported names through the generated JS bindings. Zstd WASM SHA-256 is `ad3a18c197d72167262d01fd202976325f57a6697bca627f4527c96d4dbbcfcc`. The module contains **no custom sections**, so internal native function names cannot be recovered from it.

The verified bindings include function 185 (`ZSTD_compress_usingDict`) and 179 (the block-envelope writer). Four compression-worker profiles are present in each trace.

| Sample subtree / leaf | Baseline | Second baseline | Candidate |
| --- | ---: | ---: | ---: |
| Native `compress_usingDict` subtree | 939 | 1,067 | 879 |
| JS source-span validation, gather and dictionary-byte copy | 163 | 149 | 121 |
| Native block-envelope subtree | 15 | 24 | 24 |
| JS finish/output-copy leaf | 49 | 56 | 43 |
| Worker result `postMessage` leaf | 276 | 272 | 306 |

These are diagnostic sample counts, not milliseconds or a comparison of candidate performance. Envelope writing is a small portion of sampled native work. Internal native functions 101, 149 and 106 dominate compression samples, but this evidence does **not** bind them to dictionary preparation or matchfinding. Both occur inside the same exported compression operation. The JS `prepareSpanCompression` function validates/gathers source spans and copies dictionary bytes; it does not build native dictionary tables. These traces cannot separately quantify the proposed prepared raw-context opportunity. `compression-attribution.json` preserves all categories, per-worker counts, known bindings, interval distributions and anonymous native leaves.

## Contents and reproduction

`evidence-manifest.json` lists every bundled input with byte size and SHA-256. The bundle includes all three original traces and reports, diagnostic identities and analyses, package-entry receipts, the metadata capture and complete timing observations, research scripts, and a small frozen source snapshot. The release ZIP containers remain identified by their remote artifact hashes and complete entry manifests; they are not duplicated in this compact archive.

From a checkout of frozen source `9e10d3b3` with the pinned dependency lock and verified fixture cache, the census can be reproduced by pointing `capture-publication.mjs` at that checkout and an unused output path. The kernel accepts the captured `.v8` file and an unused JSON output path. Its safety and timing exclusions remain part of the result. The browser diagnostic workflows and exact source/artifact identities above provide the browser reproduction path.
