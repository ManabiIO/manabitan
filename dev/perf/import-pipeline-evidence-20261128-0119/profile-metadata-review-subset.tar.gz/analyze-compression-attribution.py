#!/usr/bin/env python3
"""Attribute only symbol-bound compression work in retained diagnostic traces."""
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
import json
import re
import statistics
import zipfile

ROOT = Path(__file__).resolve().parent
BASELINE = Path('/tmp/manabitan-baseline-0119')
PACKAGES = {
    'jmdict-profile-9e10d3b3': Path('/tmp/manabitan-research-0119/current-baseline-profile/manabitan-chrome.zip'),
    'v3-cohort-baseline-profile': Path('/tmp/manabitan-research-0119/v3-cohort-baseline-profile/manabitan-chrome.zip'),
    'score-v3-candidate-profile': Path('/tmp/manabitan-research-0119/score-v3-candidate-profile/manabitan-chrome.zip'),
}
sha = lambda x: hashlib.sha256(x).hexdigest()
wasm = (BASELINE / 'ext/lib/zstd.wasm').read_bytes()
glue = (BASELINE / 'ext/lib/zstd-wasm.js').read_bytes()
assert sha(wasm) == 'ad3a18c197d72167262d01fd202976325f57a6697bca627f4527c96d4dbbcfcc'

def leb(data, pos):
    result = shift = 0
    while True:
        byte = data[pos]
        pos += 1
        result |= (byte & 127) << shift
        if not byte & 128:
            return result, pos
        shift += 7

bindings = {v: k for k, v in re.findall(r'Module\["([^"]+)"\] = wasmExports2\["([^"]+)"\]', glue.decode())}
exports = {}
custom = []
pos = 8
while pos < len(wasm):
    kind = wasm[pos]
    size, start = leb(wasm, pos + 1)
    end = start + size
    if kind == 7:
        count, cursor = leb(wasm, start)
        for _ in range(count):
            length, cursor = leb(wasm, cursor)
            name = wasm[cursor:cursor + length].decode()
            cursor += length
            export_kind = wasm[cursor]
            index, cursor = leb(wasm, cursor + 1)
            if export_kind == 0 and name in bindings:
                exports[index] = bindings[name]
    elif kind == 0:
        length, cursor = leb(wasm, start)
        custom.append(wasm[cursor:cursor + length].decode())
    pos = end
assert not custom
assert exports[185] == '_ZSTD_compress_usingDict'
assert exports[179] == '_manabitan_write_block_envelope'

def frame(node):
    f = node.get('callFrame', {})
    return f.get('functionName', ''), re.sub(r'^chrome-extension://[^/]+/', 'extension:/', f.get('url', ''))

def native_index(f):
    match = re.fullmatch(r'wasm-function\[(\d+)\]', f[0])
    return int(match[1]) if match and f[1] == 'extension:/lib/zstd.wasm' else None

def category(stack):
    leaf = stack[0]
    indexes = {native_index(f) for f in stack}
    if leaf[0] == '(idle)': return 'idle'
    if leaf[0] == '(program)': return 'program-unattributed'
    if leaf[0] == '(garbage collector)': return 'garbage-collector'
    if 179 in indexes: return 'native-block-envelope-subtree'
    if 170 in indexes: return 'native-context-creation-subtree'
    if 185 in indexes: return 'native-compress-using-dict-subtree-unsplit'
    if native_index(leaf) is not None: return 'native-unbound-internal'
    if leaf[0] == 'prepareSpanCompression': return 'js-span-validation-gather-and-dictionary-copy'
    if leaf[0] == 'finishPreparedSpanCompression': return 'js-compress-finish-and-output-copy'
    if leaf[0] == 'postMessage': return 'worker-result-postMessage'
    return 'other-js-or-runtime'

reports = {}
package_receipts = {}
for name, package in PACKAGES.items():
    identity = json.loads((ROOT / name / 'identity.json').read_text())
    assert sha(package.read_bytes()) == identity['packageSha256']
    with zipfile.ZipFile(package) as z:
        assert z.read('lib/zstd.wasm') == wasm
        assert z.read('lib/zstd-wasm.js') == glue
        package_receipts[name] = {'packageSha256': identity['packageSha256'], 'entries': {
            n: {'bytes': z.getinfo(n).file_size, 'sha256': sha(z.read(n))}
            for n in sorted(z.namelist()) if not n.endswith('/')
        }}
    raw = (ROOT / name / 'run-1.trace.json').read_bytes()
    trace = json.loads(raw)
    events = trace['traceEvents'] if isinstance(trace, dict) else trace
    profiles = {}
    for event in events:
        if event.get('name') not in ('Profile', 'ProfileChunk'): continue
        key = (event.get('pid'), event.get('id'))
        p = profiles.setdefault(key, {'nodes': {}, 'samples': [], 'deltas': [], 'tid': None})
        data = event.get('args', {}).get('data', {})
        if event['name'] == 'Profile': p['tid'] = event.get('tid')
        cpu = data.get('cpuProfile', {})
        for node in cpu.get('nodes', []): p['nodes'][node['id']] = node
        p['samples'].extend(cpu.get('samples', []))
        p['deltas'].extend(data.get('timeDeltas', []))
    counters = Counter()
    intervals = defaultdict(list)
    native_leaves = Counter()
    compressor_children = Counter()
    threads = []
    for (pid, profile_id), p in profiles.items():
        if not any(frame(n)[1] == 'extension:/js/dictionary/zstd-term-content-compression-worker.js' for n in p['nodes'].values()):
            continue
        assert len(p['samples']) == len(p['deltas'])
        local = Counter()
        for node_id, delta in zip(p['samples'], p['deltas']):
            node = p['nodes'][node_id]
            stack = []
            while node is not None:
                stack.append(frame(node))
                node = p['nodes'].get(node.get('parent'))
            label = category(stack)
            counters[label] += 1
            local[label] += 1
            intervals[label].append(delta)
            index = native_index(stack[0])
            if index is not None: native_leaves[index] += 1
            for i, f in enumerate(stack):
                if native_index(f) == 185:
                    child = stack[i - 1] if i > 0 else f
                    compressor_children[child] += 1
                    break
        threads.append({'pid': pid, 'profileId': profile_id, 'tid': p['tid'],
            'samples': len(p['samples']), 'negativeIntervals': sum(x < 0 for x in p['deltas']), 'categories': local})
    assert len(threads) == 4
    reports[name] = {'traceSha256': sha(raw), 'workers': threads,
        'categories': [{'name': k, 'samples': v, 'nonnegativeIntervalWeightMs': sum(max(0, x) for x in intervals[k]) / 1000,
            'medianRecordedIntervalUs': statistics.median(intervals[k]), 'maximumRecordedIntervalUs': max(intervals[k]),
            'negativeIntervals': sum(x < 0 for x in intervals[k])} for k, v in counters.most_common()],
        'nativeLeafSamples': [{'index': k, 'samples': v, 'verifiedExportName': exports.get(k)} for k, v in native_leaves.most_common()],
        'compressUsingDictDirectChildSamples': [{'function': k[0], 'source': k[1], 'samples': v,
            'verifiedExportName': exports.get(native_index(k))} for k, v in compressor_children.most_common()]}

result = {'scope': 'Diagnostic sample attribution, not CPU time or whole-import timing. Counts retain every sample; weights retain max(0, recorded delta), including descheduling waits. Four actual compression-worker profiles per trace. Internal native symbols remain unnamed. Preparation of native dictionary tables and matchfinding both occur within compress_usingDict and cannot be split from these stripped modules. JS prepareSpanCompression is source-span validation/gather plus copying dictionary bytes, not native dictionary-table preparation.',
    'binding': {'wasmSha256': sha(wasm), 'generatedGlueSha256': sha(glue), 'customSections': custom,
        'method': 'Decode exact packaged WASM export section, then map export names through exact packaged generated JS bindings. All three release ZIPs hash-verified and both module/glue bytes equal.',
        'verifiedFunctionNames': exports},
    'profiles': reports}
(ROOT / 'compression-attribution.json').write_text(json.dumps(result, indent=2) + '\n')
(ROOT / 'profile-package-entry-receipts.json').write_text(json.dumps(package_receipts, indent=2) + '\n')
print(json.dumps({'binding': result['binding'], 'profiles': {k: {'categories': v['categories'],
    'nativeLeafSamples': v['nativeLeafSamples'][:5]} for k, v in reports.items()}}, indent=2))
