#!/usr/bin/env python3
"""Build names only and prove executable sections identical to pinned parser."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
toolchain = Path('/tmp/manabitan-c27-llvm/root')
compiler = toolchain / 'usr/lib/llvm-21/bin/clang'
linker = toolchain / 'usr/lib/llvm-21/bin/wasm-ld'
environment = {**os.environ, 'LD_LIBRARY_PATH': str(toolchain / 'usr/lib/x86_64-linux-gnu')}
manifest = json.loads((root / 'dev/data/dictionary-wasm/manifest.json').read_text())
target = next(t for t in manifest['targets'] if t['name'] == 'term-bank-parser.wasm')
named_path = out / 'term-bank-parser-names.wasm'
command = [str(compiler), f'-fuse-ld={linker}', *[a for a in target['arguments'] if a != '-Wl,--strip-all'],
           *[str(root / source) for source in target['sources']], '-o', str(named_path)]
subprocess.run(command, env=environment, check=True)
original = (root / 'dev/data/dictionary-wasm/term-bank-parser.wasm').read_bytes()
named = named_path.read_bytes()

def leb(data, offset):
    value = 0
    shift = 0
    while True:
        byte = data[offset]
        offset += 1
        value |= (byte & 127) << shift
        if not byte & 128:
            return value, offset
        shift += 7
        assert shift <= 35

def sections(data):
    assert data[:8] == b'\0asm\x01\0\0\0'
    result = []
    offset = 8
    while offset < len(data):
        kind = data[offset]
        length, start = leb(data, offset + 1)
        result.append((kind, data[start:start + length]))
        offset = start + length
    assert offset == len(data)
    return result

original_sections = sections(original)
named_sections = sections(named)
assert [s for s in named_sections if s[0] != 0] == [s for s in original_sections if s[0] != 0]
names = {}
for kind, content in named_sections:
    if kind != 0:
        continue
    length, offset = leb(content, 0)
    title = content[offset:offset + length]
    offset += length
    if title != b'name':
        continue
    while offset < len(content):
        subsection = content[offset]
        length, start = leb(content, offset + 1)
        end = start + length
        if subsection == 1:
            count, position = leb(content, start)
            for _ in range(count):
                index, position = leb(content, position)
                size, position = leb(content, position)
                names[str(index)] = content[position:position + size].decode()
                position += size
            assert position == end
        offset = end
assert names
digest = lambda data: hashlib.sha256(data).hexdigest()
assert digest(original) == target['sha256']
receipt = {'compiler': subprocess.check_output([str(compiler), '--version'], env=environment, text=True),
           'command': command, 'originalSha256': digest(original), 'namedSha256': digest(named),
           'allNonCustomSectionsByteIdentical': True, 'names': names}
(out / 'wasm-function-names.json').write_text(json.dumps(receipt, indent=2) + '\n')
hotspot_path = out / 'parser-jmdict-hotspots.json'
hotspots = json.loads(hotspot_path.read_text())
for item in hotspots:
    function = item['function']
    if function.startswith('wasm-function[') and item['source'] == 'wasm://wasm/0004212e':
        item['nativeSymbol'] = names.get(function[14:-1])
(out / 'parser-jmdict-named-hotspots.json').write_text(json.dumps(hotspots, indent=2) + '\n')
print(json.dumps({'names': len(names), 'allNonCustomSectionsByteIdentical': True, 'originalSha256': digest(original)}))
