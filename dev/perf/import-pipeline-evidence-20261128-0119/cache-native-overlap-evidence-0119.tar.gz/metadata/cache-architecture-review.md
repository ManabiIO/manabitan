# Compressed backing for recent source comparisons: read-only review

Date: 2026-11-28. Source: frozen `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.

## Decision

Do not implement this candidate for the present import-latency study. The proposed main-worker raw snapshot copy does not occur on the current pinned JMdict path. The recent cache adopts the independent immutable buffer already produced in the parser worker. Compressed output is also already retained by reference in the content store's import read overlay. A second compressed cache would duplicate an existing capability.

Reducing raw retention could change memory usage, but it redirects cheap exact comparisons to block verification and decoding. The complete locality census makes that tradeoff unattractive for a latency optimization: matches touch almost every previously written block. Removing the parser worker's independent source allocation instead is a different scheduling and ownership change, which can restore the producer stalls that merged ownership work removed. No product code, storage format, compression setting, cache capacity, or worker count changed in this review.

## Measured census and modeled cost

The adjacent `jmdict-cache-locality.json` and `capture-cache-locality.mjs` preserve the complete current-source census, source identities, production block planner, every exact comparison, and the accounting model. It used the complete pinned JMdict archive, actual parser and native canonical scanner, actual metadata publication/recent cache/exact-byte matching, and a validated raw logical persistence adapter. It did not run compression, OPFS, or record writes.

| Quantity | Result | Interpretation |
| --- | ---: | --- |
| Parser groups / native scans | 12 / 12 | No canonical fallback |
| Persisted matches / recent-source hits | 3,998 / 3,998 | Every persisted comparison used recent source bytes |
| Adopted recent-cache view bytes | 101,143,281 | Cumulative logical bytes, not peak memory |
| Main-worker recent-cache copied payload bytes | 0 | Excludes parser slab creation and compression gathering |
| Peak charged raw-cache backing | 92,657,003 bytes | Census accounting, not browser PSS |
| Exact comparison payload | 843,359 bytes | Actual compared spans |
| Distinct blocks touched | 93 of 103 | Every block before the final parser group |
| Once-only decoded payload for touched blocks | 90,794,154 bytes | Optimistic amount if every recent hit needs compressed fallback |
| Largest comparison-wave block set | 89,444,328 bytes | Potential concurrent decoded working set |
| Existing 48 MiB LRU model | 182 loads; 89 repeat loads; 179,138,967 decoded bytes | Same result for the two explicit completion orders tested |

The two LRU completion orders are scenarios, not rigorous lower/upper bounds on real completion order. Compressed readiness and concurrent in-flight raw availability were not measured. An available in-flight raw source could avoid some modeled loads. No codec time, total-import change, process-memory reduction, or capacity-tuned result is claimed.

Fresh browser observations independently report the same 101,143,281 adopted/cache bytes and 3,998 recent hits. The census therefore addresses the actual zero-copy adoption route, rather than assuming an unowned raw adapter buffer describes browser ownership.

## Ownership and scheduling

`term-bank-wasm-parser-worker.js` creates a fresh independent `SharedArrayBuffer` for eligible cacheable compact content and copies the result bytes into it once. The returned view is immutable after publication. `ownsContentBytes` does not mean private `ArrayBuffer`: shared owned storage is intentional. `term-content-ownership.js` records a one-time capability on the complete backing allocation; compression does not consume that capability.

`dictionary-database.js::_cacheRecentPublishedTermContentSources` consumes the capability with `takeOwnedTermContent`. A retained subrange can keep the owned backing allocation, and the cache charges the complete allocation against its unchanged byte budget. FIFO eviction and rollback release that charge. Current JMdict takes this adoption route for all retained bytes.

The independent shared allocation allows the parser to reuse its WASM heap while ordered storage consumes the result. A result that still borrows the parser heap instead creates a consumed promise, and that parser worker awaits it before starting another group. The ordered sink also awaits the complete `onChunk` operation. Thus eliminating the worker allocation cannot be treated as removing an isolated main-worker copy: it changes when parser work can overlap the sink.

## Compression and publication order

The ordinary shared JMdict path can reserve stable reference offsets before compressed bytes exist. `_tryBeginPersistArtifactTermContent` returns storage reservation and terminal completion promises. The database awaits the reservation, registers raw in-flight sources, publishes dedup metadata and recent-cache entries, then overlaps record append with content completion.

The compression worker's `source-consumed` signal follows gathering the source into codec memory and precedes finishing compression. It is not a compressed-ready signal. The database wrapper currently exposes reservation and terminal completion; it does not expose the underlying consumed signal.

At terminal content completion, all compression, storage, and reference owners have settled. Database cleanup unregisters raw in-flight sources and releases any borrowed parser content. Errors drain both content and record work before metadata rollback. The underlying block-store operation also drains every source owner on error. A source-consumed success followed by later compression failure deliberately does not repack from potentially released source bytes.

Replacing raw exact-match backing at early metadata publication would therefore require either retaining raw bytes until the compressed object is ready, or making exact comparison explicitly await a lifetime-safe compressed promise. Releasing borrowed parser memory at input-consumed time while raw comparison views remain registered would be incorrect. Waiting for finished compression before publishing every group would remove the existing overlap. Registering compressed backing only at the existing terminal point avoids an extra group barrier, but that capability already exists through the import overlay.

## Compressed output already has an owner

`zstd-term-content-compression-worker.js` transfers a complete owned compressed `ArrayBuffer` to the import worker. The sender is detached; the received main-worker buffer remains owned. Shared input is not transferred. Private packed-input jobs transfer their separate packing allocations and preserve the source required for fallback.

`TermContentOpfsStore::_appendBatchInternal` retains each compressed block and reference slab in `_importReadOverlayChunks` while the import is active. These are references to the same appended bytes, not additional compressed copies. `_readSliceFromImportOverlay` returns a subarray when a request falls within one chunk; only a cross-chunk request allocates a concatenation. The append/write path does not transfer these buffers onward. Queued OPFS writes and the overlay can hold them concurrently.

The overlay remains until import completion, rollback, reset, or another lifecycle clear. It is a read-your-writes mechanism while persisted file state may lag logical append completion. A separate compressed pending-cache registry would add ownership and invalidation complexity without eliminating a current allocation.

## Exact equality, decoded cache, and failure behavior

Persisted dedup candidates first consult the synchronous recent raw cache, then registered raw in-flight sources. If neither is present, existing detailed reads resolve the compact block reference. Batched reads group requests by block, share in-flight block loads, and retain request/collision-candidate order.

`TermContentBlockStore::_loadBlock` reads current bytes (including the import overlay), validates the compressed envelope and both checksum words, decodes with the bounded expected output size, checks exact decoded length, and retains the already-owned output in the existing 48 MiB LRU. `clearCache` advances a generation and clears the cache/in-flight map; old async operations cannot publish into a later generation. Hash/signature filters do not replace final byte-for-byte equality.

Metadata rollback clears dense IDs and recent-source entries, releases charged allocations, and restores staged metadata. Storage rollback drains writers and restores checkpoints; overlay clearing and decoded-cache generation changes prevent stale logical offsets from being reused as live content. Any alternative backing must preserve those conditions, error classes, collision ordering, and exact comparison. The current compressed fallback already supplies this behavior.

## Relevant prior work

| Change | Current review relevance |
| --- | --- |
| [#784](https://github.com/ManabiIO/manabitan/pull/784), merged, measured head `a0f8e8e00d30823b8451248b3e6bab20b4640eb8` | Introduced independent immutable shared buffers for compact groups and ownership adoption; explicitly retained shared compression reservation. Its report states that copying moved to parser workers to improve overlap. |
| [#824](https://github.com/ManabiIO/manabitan/pull/824), merged, head `af42881464a2afef5346a5ac22a088a532a5f3f1` | Extended adoption to subranges while charging full backing allocations. The pinned JMdict report already records 101,143,281 adopted bytes and 3,998 hits, eliminating 24,660,336 prior copied bytes. Standalone whole-import improvement was not established against both controls. |
| [#766](https://github.com/ManabiIO/manabitan/pull/766), merged | Reduced the fallback shared-buffer copy cost before complete adoption; total-import medians were effectively flat. It does not imply that current owned groups still copy. |
| [#619](https://github.com/ManabiIO/manabitan/pull/619), merged | Retains already-owned decoder output directly in the block cache. A further decoded-output copy is not available to remove. |
| [#810](https://github.com/ManabiIO/manabitan/pull/810), open draft | Broader shared ownership reduced Jitendex packing but incurred material sampled memory increases. JMdict gain was not established. |
| [#839](https://github.com/ManabiIO/manabitan/pull/839), closed unmerged | Combined broader shared ownership with consumed-source reference release; measured Jitendex memory regression remained. |
| [#869](https://github.com/ManabiIO/manabitan/pull/869), closed unmerged | Added bounded admission to broader shared ownership. Frozen full-import criteria and separate Jitendex memory limits still failed. |
| [#960](https://github.com/ManabiIO/manabitan/pull/960), closed unmerged | A small boundary-definition snapshot for groups rejected by ordinary admission; targeted VNDB cross-group aliases. Its component replay left JMdict ordinary-cache behavior unchanged. Distinct from compressed backing. |

GitHub REST issue-search queries for recent-cache and compressed-cache prior work were reviewed. No directly matching compressed-backed recent-source proposal was found in that scoped search; this is not a claim that every historical branch was examined. No implicit Git fetch or missing-object download was used for this review.

## Reproduction and scope

The neighboring `cache-architecture-source-manifest.json` binds reviewed source files and locality evidence by SHA-256. Review focused on these baseline functions:

- Parser worker ownership creation and parser `borrowsWorkerMemory`/`consume` handoff.
- Database recent/in-flight exact-match lookup, cache adoption, early publication, and metadata rollback.
- Block-store reservation, `sourceConsumed`, terminal drains, decoded-cache generation, and bounded block reads.
- Compression-worker transfer and input-consumed acknowledgment.
- OPFS append overlay, queued writes, read-through behavior, and lifecycle clearing.

This is a feasibility rejection based on eliminated work, locality, and ownership. It is not a failed measured latency candidate, and it does not qualify a hypothetical memory-only redesign.
