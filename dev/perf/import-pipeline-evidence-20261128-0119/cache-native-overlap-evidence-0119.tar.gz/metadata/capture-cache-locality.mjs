import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFile, writeFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {replayParserCorpus} from '../parser-replay.mjs';

const [rootInput, outputInput] = process.argv.slice(2);
assert(rootInput && outputInput);
const root = resolve(rootInput), output = resolve(outputInput);
const source = execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim();
assert.equal(source, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
const sha = (x) => createHash('sha256').update(x).digest('hex');
const load = (path) => import(pathToFileURL(join(root, path)));
const sourcePaths = ['ext/js/dictionary/dictionary-database.js', 'ext/js/dictionary/term-content-canonical-scan.js',
    'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm', 'ext/js/dictionary/term-content-block-store.js',
    'ext/js/dictionary/term-content-ownership.js', 'ext/js/dictionary/term-bank-wasm-parser-worker.js'];
const sourceHashes = Object.fromEntries(await Promise.all(sourcePaths.map(async (name) => [name, sha(await readFile(join(root, name)))])));
const blockSource = await readFile(join(root, 'ext/js/dictionary/term-content-block-store.js'), 'utf8');
const planStart = blockSource.indexOf('function planContentSpansIntoSlabs(');
assert(planStart >= 0);
const planSource = blockSource.slice(planStart, blockSource.indexOf('\n}\n', planStart) + 2);
const planContentSpansIntoSlabs = Function(`return (${planSource});`)();
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: 4, deviceMemory: 8}});
const {DictionaryDatabase} = await load('ext/js/dictionary/dictionary-database.js');
const {NativeCanonicalScanner} = await load('ext/js/dictionary/term-content-canonical-scan.js');
const {ByteBoundedLruCache} = await load('ext/js/dictionary/term-content-block-store.js');
const {RAW_TERM_CONTENT_TOKEN_DICT_NAME} = await load('ext/js/dictionary/raw-term-content.js');
const module = await WebAssembly.compile(await readFile(join(root, sourcePaths[2])));
const database = new DictionaryDatabase();
assert.equal(database._recentTermContentSourceCacheMaxBytes, 96 * 1024 * 1024);
const targetBytes = database._termContentBlockStore._blockTargetBytes;
const decodedCacheMaxBytes = database._termContentBlockStore._cacheMaxBytes;
assert.equal(targetBytes, 1024 * 1024);
assert.equal(decodedCacheMaxBytes, 48 * 1024 * 1024);
database._nativeCanonicalScanner = new NativeCanonicalScanner({loadModule: async () => module});
database._bulkImportTransactionOpen = true;
database._deferTermsVirtualTableSync = true;
database._termContentStorageMode = 'raw-bytes';
database._termContentZstdInitialized = true;
database._appendResolvedArtifactTermRecords = async () => {};
const groups = [], queries = [], comparisons = [], waves = [], metrics = [];
const backingGroups = new WeakMap();
let currentGroup = 0, currentWave = null, pendingComparison = null, nextOffset = 0, nextBlock = 0;
const zeroProfile = {packMs: 0, compressMs: 0, envelopeMs: 0, referenceMs: 0, opfsAppendMs: 0, initialSelectionSavingsMiss: false};
database._termContentBlockImportSession = {
    tryBeginAppendSpans(_dictionary, bytes, offsets, lengths) {
        assert.equal(groups.length, currentGroup - 1);
        assert(bytes instanceof Uint8Array && offsets instanceof Uint32Array && lengths instanceof Uint32Array);
        assert.equal(offsets.length, lengths.length);
        const contentOffsets = new Float64Array(lengths.length);
        for (let i = 0; i < lengths.length; ++i) {
            assert(offsets[i] <= bytes.length && lengths[i] <= bytes.length - offsets[i]);
            contentOffsets[i] = nextOffset;
            nextOffset += Math.max(1, lengths[i]);
        }
        const plan = planContentSpansIntoSlabs(lengths, targetBytes);
        const blocks = [...plan.packedChunkLengths].map((decodedBytes, i) => ({id: nextBlock++, decodedBytes,
            start: plan.blockStartIndexes[i], end: plan.blockStartIndexes[i + 1]}));
        groups.push({group: currentGroup, newlyPublished: lengths.length, sourceBytes: bytes.byteLength,
            sourceBackingBytes: bytes.buffer.byteLength, sourceShared: bytes.buffer instanceof SharedArrayBuffer,
            packedBytes: blocks.reduce((n, b) => n + b.decodedBytes, 0), blocks});
        backingGroups.set(bytes.buffer, currentGroup);
        const result = {contentOffsets, contentLengths: lengths, contentDictName: RAW_TERM_CONTENT_TOKEN_DICT_NAME, ...zeroProfile};
        return {storage: Promise.resolve(result), completion: Promise.resolve(result), initialSelection: false};
    },
};
database._persistArtifactTermContent = async () => { throw new Error('Unexpected ordinary persistence fallback'); };
database._readTermEntryContentBytesDetailedBatch = async () => { throw new Error('Unexpected non-recent exact read'); };
database._readTermEntryContentBytesDetailed = async () => { throw new Error('Unexpected non-recent scalar exact read'); };
const originalCache = database._cacheRecentPublishedTermContentSources;
database._cacheRecentPublishedTermContentSources = function (staged, spans, importMetrics) {
    const group = groups.at(-1);
    assert.equal(group.group, currentGroup);
    group.firstMetadataIndex = staged.indexes[0];
    const beforeAdopted = importMetrics.dedupRecentSourceAdoptedBytes ?? 0;
    const nextBatchId = this._nextRecentTermContentSourceBatchId;
    const retainedBytes = originalCache.call(this, staged, spans, importMetrics);
    const retained = this._recentTermContentSourceBatches.get(nextBatchId);
    assert(retained instanceof Uint8Array);
    group.retainedViewBytes = retainedBytes;
    group.retainedBackingBytes = retained.buffer.byteLength;
    group.adoptedBytes = (importMetrics.dedupRecentSourceAdoptedBytes ?? 0) - beforeAdopted;
    group.copiedPayloadBytes = retained.buffer === spans.buffer.buffer ? 0 : retained.byteLength;
    backingGroups.set(retained.buffer, currentGroup);
    group.cacheBytesAfter = this._recentTermContentSourceBatchBytes;
    group.cachedGroupsAfter = [...this._recentTermContentSourceBatches.values()].map((b) => backingGroups.get(b.buffer));
    return retainedBytes;
};
const originalBatch = database._findMatchingPersistedTermEntryContentMetaBatch;
database._findMatchingPersistedTermEntryContentMetaBatch = async function (descriptors) {
    assert.equal(currentWave, null);
    const wave = {id: waves.length, queryGroup: currentGroup, descriptors: descriptors.length, queryStart: queries.length};
    currentWave = wave.id;
    try { return await originalBatch.call(this, descriptors); }
    finally { wave.queryEnd = queries.length; waves.push(wave); currentWave = null; }
};
const originalRecent = database._findRecentTermContentSource;
database._findRecentTermContentSource = function (meta) {
    const result = originalRecent.call(this, meta);
    if (typeof result === 'undefined') {
        queries.push({queryGroup: currentGroup, wave: currentWave, found: false, contentLength: meta.length});
        return result;
    }
    const sourceGroup = backingGroups.get(result.buffer.buffer);
    assert(sourceGroup >= 1 && sourceGroup < currentGroup);
    const group = groups[sourceGroup - 1];
    const entry = meta.tableIndex - group.firstMetadataIndex;
    assert(entry >= 0 && entry < group.newlyPublished);
    const block = group.blocks.find((b) => entry >= b.start && entry < b.end);
    assert(block);
    const query = {queryGroup: currentGroup, wave: currentWave, found: true, sourceGroup,
        block: block.id, blockDecodedBytes: block.decodedBytes, entry, contentLength: meta.length,
        retainedViewOffset: result.offset, groupsSinceSource: currentGroup - sourceGroup};
    queries.push(query);
    assert.equal(pendingComparison, null);
    pendingComparison = {query, buffer: result.buffer, offset: result.offset, length: result.length};
    return result;
};
const comparedBytes = createHash('sha256');
const originalEqual = database._termContentBytesEqualSpan;
database._termContentBytesEqualSpan = function (bytes, buffer, offset, length) {
    const match = originalEqual.call(this, bytes, buffer, offset, length);
    if (pendingComparison !== null) {
        assert.equal(buffer, pendingComparison.buffer);
        assert.equal(offset, pendingComparison.offset);
        assert.equal(length, pendingComparison.length);
        comparedBytes.update(buffer.subarray(offset, offset + length));
        comparisons.push({...pendingComparison.query, equal: match});
        pendingComparison = null;
    }
    return match;
};
const receipt = await replayParserCorpus({root, cacheDir: join(root, 'builds/e2e-dictionary-cache'), dictionary: 'jmdict',
    onChunk: async (chunk, _progress, {fixture}) => {
        ++currentGroup;
        chunk.dictionary = fixture.expectedTitle;
        chunk.dictionaryTotalRows = fixture.termRows;
        chunk.uniformContentDictName = RAW_TERM_CONTENT_TOKEN_DICT_NAME;
        await database._bulkAddArtifactTermsChunkWithContentDedup(chunk);
        metrics.push({...database._lastBulkAddTermsMetrics});
    }});
const counters = Object.fromEntries(['dedupNativeCallCount', 'dedupNativeScannedRows', 'dedupNativeFallbackCount',
    'dedupUniqueCount', 'dedupPersistedHitCount', 'dedupRecentSourceHitCount'].map((key) => [key, metrics.reduce((n, m) => n + m[key], 0)]));
assert.equal(counters.dedupNativeCallCount, 12);
assert.equal(counters.dedupNativeFallbackCount, 0);
assert.equal(counters.dedupUniqueCount, 362032);
assert.equal(counters.dedupPersistedHitCount, 3998);
assert.equal(counters.dedupRecentSourceHitCount, 3998);
assert.equal(comparisons.length, 3998);
assert(comparisons.every((c) => c.equal));
assert.equal(pendingComparison, null);
const blocks = groups.flatMap((g) => g.blocks.map((b) => ({...b, sourceGroup: g.group})));
const uniqueBlocks = new Set(comparisons.map((c) => c.block));
const sourceGroupCounts = {};
const groupDistanceCounts = {};
for (const c of comparisons) {
    sourceGroupCounts[c.sourceGroup] = (sourceGroupCounts[c.sourceGroup] ?? 0) + 1;
    groupDistanceCounts[c.groupsSinceSource] = (groupDistanceCounts[c.groupsSinceSource] ?? 0) + 1;
}
for (const wave of waves) {
    const unique = [...new Set(queries.slice(wave.queryStart, wave.queryEnd).filter((q) => q.found).map((q) => q.block))];
    wave.blocks = unique;
    wave.distinctDecodedBytes = unique.reduce((n, id) => n + blocks[id].decodedBytes, 0);
}
function modelBatchReadCache(reverseCompletion) {
    // Execute the unmodified production LRU policy on byte-length tokens. This
    // models existing batched get-before-await behavior, not real decoding or
    // completion timing. Capacity is the existing 48 MiB, never tuned.
    const cache = new ByteBoundedLruCache(decodedCacheMaxBytes);
    const decoded = new Set();
    let misses = 0, repeatDecodes = 0, decodedBytes = 0, peakCacheBytes = 0;
    const observations = [];
    for (const wave of waves) {
        const missing = wave.blocks.filter((id) => typeof cache.get(String(id)) === 'undefined');
        const beforeMisses = misses;
        for (const id of reverseCompletion ? [...missing].reverse() : missing) {
            ++misses;
            repeatDecodes += decoded.has(id) ? 1 : 0;
            decoded.add(id);
            decodedBytes += blocks[id].decodedBytes;
            cache.set(String(id), {byteLength: blocks[id].decodedBytes});
            peakCacheBytes = Math.max(peakCacheBytes, cache.bytes);
        }
        observations.push({wave: wave.id, misses: misses - beforeMisses, cacheBytes: cache.bytes});
    }
    return {completionOrder: reverseCompletion ? 'reverse first occurrence' : 'first occurrence', misses,
        repeatDecodes, decodedBytes, peakCacheBytes, observations};
}
for (const [name, hash] of Object.entries(sourceHashes)) { assert.equal(sha(await readFile(join(root, name))), hash); }
const totals = {sourceSlabBytes: groups.reduce((n, g) => n + g.sourceBytes, 0),
    newlyPublishedPackedBytes: groups.reduce((n, g) => n + g.packedBytes, 0),
    adoptedViewBytes: groups.reduce((n, g) => n + g.adoptedBytes, 0),
    copiedCachePayloadBytes: groups.reduce((n, g) => n + g.copiedPayloadBytes, 0),
    peakRawCacheBackingBytes: Math.max(...groups.map((g) => g.cacheBytesAfter)),
    exactComparisonBytes: comparisons.reduce((n, c) => n + c.contentLength, 0),
    allBlocks: blocks.length, distinctHitBlocks: uniqueBlocks.size,
    minimumDecodedBytesIfEachHitBlockDecodedOnce: [...uniqueBlocks].reduce((n, id) => n + blocks[id].decodedBytes, 0),
    decodedBytesWithoutCrossWaveReuse: waves.reduce((n, w) => n + w.distinctDecodedBytes, 0),
    maximumSingleWaveDecodedBytes: Math.max(...waves.map((w) => w.distinctDecodedBytes)),
    comparedByteStreamSha256: comparedBytes.digest('hex')};
const report = {source, sourceHashes, node: process.version, targetBytes, decodedCacheMaxBytes,
    sourceCacheMaxBytes: database._recentTermContentSourceCacheMaxBytes, planSource, planSourceSha256: sha(planSource),
    counters, totals, sourceGroupCounts, groupDistanceCounts, groups, waves, queries, comparisons,
    cachePolicyModels: [modelBatchReadCache(false), modelBatchReadCache(true)], receipt,
    scope: 'Diagnostic locality census only. Full pinned JMdict actual parser/native canonical scanner/early metadata publication/recent cache/exact byte matcher; validated raw logical persistence adapter, no compression/OPFS/record writes. Source payloads are not retained by the adapter. Maps each actual exact comparison to the verbatim production 1 MiB block planner. Cache copied bytes exclude parser owned-slab creation and compressor gathering. Compressed availability and in-flight overlap are not measured. Decoded-cache scenarios use the actual 48 MiB policy with byte-length tokens and two explicit completion orders; they are neither timed decoding nor rigorous completion-order bounds, and assume every recent-cache hit instead needs a compressed-block lookup.'};
await writeFile(output, `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'});
console.log(JSON.stringify({output, counters, totals, sourceGroupCounts, groupDistanceCounts,
    cachePolicyModels: report.cachePolicyModels.map(({observations, ...rest}) => rest)}));
