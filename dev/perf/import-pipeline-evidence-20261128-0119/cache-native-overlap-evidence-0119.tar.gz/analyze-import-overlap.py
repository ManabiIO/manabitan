#!/usr/bin/env python3
"""Reconcile exact message events with sampled record work, without timing claims."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
locality = json.loads((ROOT / 'metadata/jmdict-cache-locality.json').read_text())
block_counts = [len(g['blocks']) for g in locality['groups']]
assert sum(block_counts) == 103 and len(block_counts) == 12

def normalized(url):
    return re.sub(r'^chrome-extension://[^/]+/', 'extension:/', url)

def top_frame(event):
    frames = event.get('args', {}).get('data', {}).get('stackTrace', [])
    return frames[0] if frames else {}

outputs = {}
for name in ['jmdict-profile-9e10d3b3', 'v3-cohort-baseline-profile', 'score-v3-candidate-profile', 'native-initial-candidate-profile']:
    raw = (ROOT / name / 'run-1.trace.json').read_bytes()
    events = json.loads(raw)['traceEvents']
    profiles = {}
    for e in events:
        if e.get('name') not in ('Profile', 'ProfileChunk'): continue
        p = profiles.setdefault((e['pid'], e.get('id')), {'nodes': {}, 'samples': [], 'deltas': [], 'tid': None, 'start': None})
        d = e.get('args', {}).get('data', {})
        if e['name'] == 'Profile': p['tid'], p['start'] = e['tid'], d['startTime']
        cpu = d.get('cpuProfile', {})
        for node in cpu.get('nodes', []): p['nodes'][node['id']] = node
        p['samples'].extend(cpu.get('samples', []))
        p['deltas'].extend(d.get('timeDeltas', []))
    imports = [(key, p) for key, p in profiles.items() if any(
        normalized(n.get('callFrame', {}).get('url', '')) == 'extension:/js/background/offscreen-dictionary-worker.js'
        for n in p['nodes'].values())]
    assert len(imports) == 1
    (pid, profile_id), profile = imports[0]
    tid = profile['tid']
    handles = {e['args']['data']['traceId']: e for e in events
        if e.get('name') == 'HandlePostMessage' and e.get('ph') == 'X' and e.get('pid') == pid}
    scheduled = [e for e in events if e.get('name') == 'SchedulePostMessage' and e.get('ph') == 'I' and e.get('pid') == pid]
    dispatch = sorted([e for e in scheduled if e['tid'] == tid and
        normalized(top_frame(e).get('url', '')) == 'extension:/js/dictionary/zstd-term-content.js' and
        top_frame(e).get('lineNumber') == 386], key=lambda e: e['ts'])
    assert len(dispatch) == 103, (name, len(dispatch))
    jobs = []
    for e in dispatch:
        trace_id = e['args']['data']['traceId']
        handle = handles[trace_id]
        replies = [r for r in scheduled if r['tid'] == handle['tid'] and
            handle['ts'] <= r['ts'] <= handle['ts'] + handle['dur'] and
            normalized(top_frame(r).get('url', '')) == 'extension:/js/dictionary/zstd-term-content-compression-worker.js']
        consumed = [r for r in replies if top_frame(r).get('lineNumber') == 68]
        results = [r for r in replies if top_frame(r).get('lineNumber') == 86]
        assert len(consumed) == len(results) == 1, (name, trace_id, len(consumed), len(results))
        consumed, result = consumed[0], results[0]
        consumed_handle = handles[consumed['args']['data']['traceId']]
        result_handle = handles[result['args']['data']['traceId']]
        assert consumed_handle['tid'] == result_handle['tid'] == tid
        jobs.append({'dispatchTraceId': trace_id, 'workerTid': handle['tid'], 'dispatchUs': e['ts'],
            'workerHandleStartUs': handle['ts'], 'workerHandleEndUs': handle['ts'] + handle['dur'],
            'workerHandleTdurUs': handle.get('tdur'),
            'sourceConsumedSendUs': consumed['ts'], 'sourceConsumedHandleStartUs': consumed_handle['ts'],
            'resultSendUs': result['ts'], 'resultHandleStartUs': result_handle['ts']})
    groups = []
    cursor = 0
    worker_order = [j['workerTid'] for j in jobs[:4]]
    assert len(set(worker_order)) == 4
    for group_number, count in enumerate(block_counts, 1):
        block_jobs = jobs[cursor:cursor + count]
        assert all(j['workerTid'] == worker_order[i % 4] for i, j in enumerate(block_jobs))
        group = {'group': group_number, 'blocks': count, 'jobs': block_jobs,
            'firstDispatchUs': block_jobs[0]['dispatchUs'], 'lastDispatchUs': block_jobs[-1]['dispatchUs'],
            'allSourceConsumedSentUs': max(j['sourceConsumedSendUs'] for j in block_jobs),
            'allSourceConsumedHandledUs': max(j['sourceConsumedHandleStartUs'] for j in block_jobs),
            'lastResultSentUs': max(j['resultSendUs'] for j in block_jobs),
            'lastResultHandledUs': max(j['resultHandleStartUs'] for j in block_jobs)}
        groups.append(group)
        cursor += count
    for i, g in enumerate(groups):
        g['nextDispatchUs'] = groups[i + 1]['firstDispatchUs'] if i + 1 < len(groups) else None
        assert g['nextDispatchUs'] is None or g['lastResultHandledUs'] <= g['nextDispatchUs']
    selected = []
    timestamp = profile['start']
    for node_id, delta in zip(profile['samples'], profile['deltas']):
        timestamp += delta
        node = profile['nodes'][node_id]
        stack = []
        while node is not None:
            f = node.get('callFrame', {})
            stack.append((f.get('functionName', ''), normalized(f.get('url', ''))))
            node = profile['nodes'].get(node.get('parent'))
        field = any(fn == '_encodeArtifactRecordFields' and url.endswith('/term-record-opfs-store.js') for fn, url in stack)
        lookup = any(fn == '_createLookupIndexChunk' and url.endswith('/term-record-opfs-store.js') for fn, url in stack)
        hashing = lookup and any(url.endswith('/term-key-hash.js') or
            (url.endswith('/term-lookup-index-hasher.js') and fn == 'hash') for fn, url in stack)
        if not field and not hashing: continue
        group = next((g for g in reversed(groups) if timestamp >= g['firstDispatchUs']), None)
        entry = {'kind': 'record-fields' if field else 'lookup-checksum', 'timestampUs': timestamp,
            'recordedDeltaUs': delta, 'leaf': stack[0], 'group': None if group is None else group['group']}
        if group is not None:
            entry.update({'beforeLastWorkerResultSend': timestamp < group['lastResultSentUs'],
                'beforeLastResultHandleStart': timestamp < group['lastResultHandledUs'],
                'insideSomeWorkerCompressFinishInterval': any(j['sourceConsumedSendUs'] <= timestamp <= j['resultSendUs'] for j in group['jobs'])})
        selected.append(entry)
    import_tasks = [(e['ts'], e['ts'] + e['dur']) for e in events if e.get('pid') == pid and
        e.get('tid') == tid and e.get('name') == 'RunTask' and e.get('ph') == 'X']
    assert all(any(start <= sample['timestampUs'] <= end for start, end in import_tasks) for sample in selected)
    def summarize(samples):
        return {'samples': len(samples), 'negativeRecordedDeltas': sum(s['recordedDeltaUs'] < 0 for s in samples),
            'unassigned': sum(s['group'] is None for s in samples),
            'beforeLastWorkerResultSend': sum(s.get('beforeLastWorkerResultSend', False) for s in samples),
            'beforeLastResultHandleStart': sum(s.get('beforeLastResultHandleStart', False) for s in samples),
            'insideSomeWorkerCompressFinishInterval': sum(s.get('insideSomeWorkerCompressFinishInterval', False) for s in samples)}
    for group in groups:
        group['recordSamples'] = {kind: summarize([s for s in selected if s['kind'] == kind and s['group'] == group['group']])
            for kind in ['record-fields', 'lookup-checksum']}
    outputs[name] = {'traceSha256': hashlib.sha256(raw).hexdigest(), 'pid': pid, 'importWorkerTid': tid,
        'profileId': profile_id, 'originUs': groups[0]['firstDispatchUs'], 'groups': groups, 'selectedSamples': selected,
        'allSelectedSamplePointsInsideImportWorkerRunTask': True,
        'summary': {kind: summarize([s for s in selected if s['kind'] == kind]) for kind in ['record-fields', 'lookup-checksum']}}

result = {'scope': 'Exact trace SchedulePostMessage/HandlePostMessage traceId pairs identify 103 compression jobs, source-consumed sends and compressed-result sends. Source lines are verified against unchanged packaged worker scripts. Group labels are reconstructed from the exact production planner block counts and synchronous ordered dispatch; round-robin worker pattern and response-before-next-dispatch invariants are asserted. CPU-profile sample points use startTime plus all signed recorded deltas; negative deltas remain included and counted. Every selected point is independently verified to fall inside an import-worker RunTask. A sample preceding the last result-send event means the group compression branch had not emitted every result at that instant. It does not quantify saved time, prove a critical-path duration, or establish causal performance effects. Worker handle intervals include gather/compress/wrapping/message work and scheduling; tdur is retained verbatim without interpreting it as wall latency. Promise resolution, storage reservation, metadata publication, record completion and finalization have no direct per-group trace marker here.',
    'blockCounts': block_counts, 'profiles': outputs}
(ROOT / 'import-overlap-analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({name: {'summary': x['summary'], 'lastCompressionResultSentUs': x['groups'][-1]['lastResultSentUs'],
    'lastCompressionResultHandledUs': x['groups'][-1]['lastResultHandledUs']} for name, x in outputs.items()}, indent=2))
