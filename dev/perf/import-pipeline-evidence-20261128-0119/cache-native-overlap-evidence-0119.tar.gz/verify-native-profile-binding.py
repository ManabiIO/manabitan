#!/usr/bin/env python3
"""Bind sampled native functions to the exact retained package without symbols."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROFILE = ROOT / 'native-initial-candidate-profile'
module = (PROFILE / 'packaged/lib/term-content-canonical-scan-v1.wasm').read_bytes()
assert hashlib.sha256(module).hexdigest() == '60237c98d16196db00161af3a896aae4d2f8104f63401d5617d17f895e752b94'
assert module[:8] == b'\0asm\x01\0\0\0'

def leb(offset):
    value, shift = 0, 0
    while True:
        byte = module[offset]
        offset += 1
        value |= (byte & 127) << shift
        if not byte & 128:
            return value, offset
        shift += 7
        assert shift <= 35

names, offsets, customs, imports = {}, {}, [], []
imported_functions = 0
cursor = 8
while cursor < len(module):
    kind = module[cursor]
    length, start = leb(cursor + 1)
    end = start + length
    assert end <= len(module)
    if kind == 0:
        size, position = leb(start)
        customs.append(module[position:position + size].decode())
    elif kind == 2:
        count, position = leb(start)
        for _ in range(count):
            labels = []
            for _ in range(2):
                size, position = leb(position)
                labels.append(module[position:position + size].decode())
                position += size
            import_kind = module[position]
            position += 1
            if import_kind == 0:
                type_index, position = leb(position)
                imported_functions += 1
                detail = {'functionTypeIndex': type_index}
            elif import_kind == 2:
                flags, position = leb(position)
                assert flags in (0, 1, 2, 3), 'Only wasm32 memory limits occur in this exact module.'
                minimum, position = leb(position)
                maximum = None
                if flags & 1:
                    maximum, position = leb(position)
                detail = {'memoryFlags': flags, 'minimumPages': minimum, 'maximumPages': maximum}
            else:
                raise AssertionError(f'Unexpected import kind {import_kind} in this exact module')
            imports.append({'module': labels[0], 'name': labels[1], 'kind': import_kind, **detail})
        assert position == end
    elif kind == 7:
        count, position = leb(start)
        for _ in range(count):
            size, position = leb(position)
            name = module[position:position + size].decode()
            position += size
            export_kind = module[position]
            index, position = leb(position + 1)
            if export_kind == 0:
                names[index] = name
        assert position == end
    elif kind == 10:
        count, position = leb(start)
        for index in range(count):
            size, body = leb(position)
            offsets[index] = body
            position = body + size
        assert position == end
    cursor = end
assert cursor == len(module)
assert imported_functions == 0, 'Do not infer index offsets for a module with function imports.'
assert names[4] == 'scan_canonical'
assert names[7] == 'lookup_hash_update'
assert names[8] == 'lookup_hash_finish'
assert {index: offsets[index] for index in (4, 7, 8)} == {4: 306, 7: 1829, 8: 2158}

events = json.loads((PROFILE / 'run-1.trace.json').read_text())['traceEvents']
frames = {}
for event in events:
    if event.get('name') != 'ProfileChunk':
        continue
    for node in event.get('args', {}).get('data', {}).get('cpuProfile', {}).get('nodes', []):
        frame = node.get('callFrame', {})
        if frame.get('url') == 'wasm://wasm/ec14035e':
            name = frame.get('functionName', '')
            if name.startswith('wasm-function['):
                index = int(name[14:-1])
                if index in (4, 7, 8):
                    assert frame['columnNumber'] == offsets[index]
                    frames[index] = frame
assert set(frames) == {4, 7, 8}
receipt = {
    'scope': 'Exact export index and function-body-offset binding; sample presence is execution evidence, not a timing comparison.',
    'wasmSha256': hashlib.sha256(module).hexdigest(),
    'traceSha256': hashlib.sha256((PROFILE / 'run-1.trace.json').read_bytes()).hexdigest(),
    'sampledModuleUrl': 'wasm://wasm/ec14035e',
    'customSections': customs,
    'imports': imports,
    'verifiedFunctions': {index: {'name': names[index], 'bodyOffset': offsets[index], 'callFrame': frames[index]}
                          for index in (4, 7, 8)},
}
(PROFILE / 'verified-native-binding.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'verified': True, 'functionNames': [names[index] for index in (4, 7, 8)]}))
