# JMdict reservation, record work and compression overlap

The source permits record encoding/checksums to overlap compression, but the retained traces **do not establish that most saved record-field time was hidden**. In the baseline diagnostics, many field and checksum samples occur after compression workers have already sent every result for the current group, while the import worker has not handled the final result yet. The receiver-side compression counter therefore includes scheduling effects and is not an independent measure of native codec work.

The separately audited score-v3 qualification cohorts report paired median field-counter reductions of 13.15 ms and 7.90 ms. Those paired observations are distinct from the instrumented imports analyzed here. This document does not derive a causal explanation for the lack of a whole-import improvement from separate diagnostic jobs, phase sums, or host comparisons.

## Source-confirmed dependency path

All baseline functions below refer to source `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. The score candidate changes only the field encoder helper; the native candidate changes the checksum provider and its module. The scheduling functions discussed here are otherwise identical in the checked packages.

```mermaid
flowchart TD
    D["Resolve current-group deduplication"] --> S["Start shared compression and reserve references"]
    S --> W["Workers gather, signal consumption, then compress"]
    S --> P["Publish reserved metadata and raw-source cache"]
    P --> R["Validate and encode fields, hash sidecar, queue records"]
    W --> C["Receive results, build references and append content"]
    R --> J["Join content and record completion"]
    C --> J
    J --> N["Advance ordered sink"]
```

1. **Current-group deduplication precedes compression dispatch.** `DictionaryDatabase._bulkAddArtifactTermsChunkWithContentDedup` awaits `_resolveArtifactTermContentDedup` before calling `_tryBeginPersistArtifactTermContent`. Native canonical scanning and exact matching are therefore upstream of this group's compression work. They can overlap independent parser workers, but cannot overlap compression that has not yet been dispatched.

2. **Reservation makes logical references available early.** `TermContentBlockStore._beginAppendSharedSpans` plans the blocks and starts compression. Concurrently, `TermContentOpfsStore.beginAppendBatchWithDerivedPrefix` enters its mutation queue, reserves the known reference-prefix lengths and resolves `reserved` before awaiting compressed block bytes. The block store's `storage` promise projects those reserved offsets. It does not certify that compressed data or references are already appended.

3. **Metadata and record work proceed using those reserved references.** The DB awaits `earlyContentPersistence.storage`, publishes resolved reference columns, registers in-flight raw content, publishes dedup metadata and retains the recent source view. It then starts `_appendResolvedArtifactTermRecords`. In `TermRecordOpfsStore._encodeAndAppendArtifactChunkForState`, the synchronous validation/field encoding occurs before `_appendEncodedChunk`; that method creates the checksummed sidecar in `_createLookupIndexChunk` and queues it for the existing writer.

4. **The consumed signal is weaker than completion.** The compression worker calls `prepareWrappedTermContentZstdSpans`, posts `source-consumed`, then synchronously performs `finishWrappedTermContentZstdSpans` and posts the compressed result. The pool's source-consumed barrier drains every job, including failures. `_tryBeginPersistArtifactTermContent` exposes `storage` and terminal `completion` to the DB, not `sourceConsumed`. The DB releases in-flight sources and any borrowed-content callback when terminal content completion settles. It does not release a borrowed parser heap merely because compressor input copying finished.

5. **Both terminal branches gate the next ordered sink group.** After starting the record append, the DB immediately joins it with measured content completion using `Promise.allSettled`. Compression completion includes receipt/validation of all worker results, reference-slab creation, content append finalization and terminal error draining. A failed branch does not permit the source owner to escape before the other branch settles. The DB's `contentCompletedAt` is set in a promise continuation on the import worker, so busy main-thread JS or queued message handling can move that timestamp after the workers finished their compression tasks.

6. **Append completion is not always physical write completion.** During import, content `_flushPendingWrites` can enqueue writeback and return unless its existing byte budget requires waiting. Record `_flushPendingLookupIndexChunks` similarly chains writes and waits only when requested or when its queue budget is exceeded. Final import-session methods drain and close the outstanding writers. The separate finalization audit owns that tail; no sum of field, compression and append counters represents it.

Sources: [dictionary-database.js](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/dictionary-database.js), [term-content-block-store.js](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/term-content-block-store.js), [term-content-opfs-store.js](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/term-content-opfs-store.js), [term-record-opfs-store.js](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/term-record-opfs-store.js), [zstd-term-content.js](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/zstd-term-content.js), [compression worker](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/zstd-term-content-compression-worker.js).

## Parser release is a separate dependency

JMdict's cacheable content is copied by the parser into a fresh independent shared buffer and registered as owned. The recent-source cache later adopts it without another payload copy. The actual browser reports zero borrowed-content results and 101,143,985 owned content bytes.

`ParallelTermBankPipelineRun._runWorkerLoop` waits on a consumer promise only for borrowed parser memory. Owned JMdict results do not create that lease, so the parser worker can advance independently of the ordered sink. The maximum lead is three workers times four groups, or twelve groups—equal to this complete JMdict workload. There is no smaller lead window blocking later groups in this corpus. The sink still awaits `_onChunk` for each group before processing the next one. Both parser result delivery and the next parser-job dispatch pass through the import worker, so busy import-worker JS can still delay dispatch even without a borrowed-memory lease.

For borrowed inputs, the DB's release callback may wake that parser after content completion while record completion is still outstanding; the pipeline's finalizer also releases it idempotently. The current owned JMdict route avoids that dependency entirely.

Sources: [parser worker](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/term-bank-wasm-parser-worker.js), [parallel parser pipeline](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/term-bank-wasm-parser.js), [ownership capability](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/term-content-ownership.js).

## What the existing traces support

`analyze-import-overlap.py` reconstructs actual message events rather than inferring boundaries from phase totals:

- Every trace has 103 `SchedulePostMessage` instant events from the compressor dispatch call at `zstd-term-content.js` line 386.
- Each dispatch `traceId` matches its worker `HandlePostMessage` event. Inside that handler, line 68 posts `source-consumed` and line 86 posts the compressed result; both IDs match their import-worker handlers.
- Group labels follow the exact production block plan: 9, 9, 9, 9, 9, 9, 7, 8, 8, 8, 8 and 10 blocks. The four-worker round-robin pattern and every response preceding the next group's dispatch are independently asserted.
- Record-field and checksum sample points use the profile start time plus every signed recorded interval. No negative interval or outlier is removed. Every selected point is independently checked to fall inside an import-worker `RunTask`.

The following are **sample counts, not durations or invocation counts**. “Before send” means the last compression result for that group had not yet been emitted by its worker. “Before handling” means the import worker had not yet begun handling that last result.

| Diagnostic | Field samples | Field before send | Field before handling | Checksum samples | Checksum before send | Checksum before handling |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Frozen baseline, first job | 145 | 33 | 145 | 151 | 22 | 151 |
| Frozen baseline, v3 qualification job | 115 | 54 | 93 | 149 | 69 | 124 |
| Score v3 candidate | 135 | 86 | 116 | 195 | 87 | 165 |
| Initial native candidate, before guard fix | 203 | 107 | 166 | 37 | 3 | 25 |

These observations confirm some overlap and a substantial difference between producer completion and receiver handling. They do not consistently place most field/checksum samples before compressor completion. Nor can their counts tell us how many milliseconds of the paired score-cache savings were hidden, exposed, or offset elsewhere.

The traces have no direct per-group marker for reservation settlement, metadata publication, field completion, terminal record completion or the `Promise.allSettled` join. The event reconstruction retains actual send/receive times and sample locations; it does not invent those missing timestamps. Worker handler durations and raw `tdur` values are retained without turning their sum into import latency.

## Implication for further optimization

The narrow, source-confirmed serial edges are current-group deduplication before dispatch and reference creation/content completion after worker results. These are plausible places to inspect when a later record helper improvement does not move total import time. This analysis establishes their dependency positions, not their measured critical-path dominance or the value of a particular implementation change. The paired qualification results remain the deciding evidence; no additional browser run or product patch was made for this analysis.
