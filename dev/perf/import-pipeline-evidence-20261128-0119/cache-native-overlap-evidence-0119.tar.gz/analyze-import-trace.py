#!/usr/bin/env python3
"""Summarize retained Chromium CPU samples; never treat trace time as a benchmark."""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path
import re

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('trace', type=Path)
parser.add_argument('output', type=Path)
parser.add_argument('--report', type=Path)
parser.add_argument('--parser-symbols', type=Path)
parser.add_argument('--parser-url', default='wasm://wasm/0004212e')
args = parser.parse_args()
raw = args.trace.read_bytes()
trace = json.loads(raw)
events = trace['traceEvents'] if isinstance(trace, dict) else trace
symbols = json.loads(args.parser_symbols.read_text()) if args.parser_symbols else None
profiles = {}
thread_names = {}
for event in events:
    pid, tid = event.get('pid'), event.get('tid')
    if event.get('name') == 'thread_name':
        thread_names[(pid, tid)] = event.get('args', {}).get('name')
    if event.get('name') not in ('Profile', 'ProfileChunk'):
        continue
    # ProfileChunk is emitted by Chrome's profiler thread; its tid is not the
    # sampled target tid carried by Profile. The process-scoped profile id is
    # the association key documented by the trace shape.
    key = (pid, event.get('id'))
    profile = profiles.setdefault(key, {'nodes': {}, 'samples': [], 'deltas': [], 'start': None, 'tid': None, 'chunkTids': set()})
    data = event.get('args', {}).get('data', {})
    if event.get('name') == 'Profile':
        profile['start'] = data.get('startTime')
        profile['tid'] = tid
    else:
        profile['chunkTids'].add(tid)
    cpu = data.get('cpuProfile', {})
    for node in cpu.get('nodes', []):
        assert node['id'] not in profile['nodes'] or profile['nodes'][node['id']] == node
        profile['nodes'][node['id']] = node
    profile['samples'].extend(cpu.get('samples', []))
    profile['deltas'].extend(data.get('timeDeltas', []))

def identity(node):
    frame = node.get('callFrame', {})
    name = frame.get('functionName', '(unnamed)')
    url = re.sub(r'^chrome-extension://[^/]+/', 'extension:/', frame.get('url', ''))
    line = frame.get('lineNumber', -1)
    if symbols and frame.get('url') == args.parser_url:
        match = re.fullmatch(r'wasm-function\[(\d+)\]', name)
        if match and match[1] in symbols['names']:
            name += ' ' + symbols['names'][match[1]]
    return name, url, line, frame.get('codeType')

def rows(counter, samples, limit=40):
    return [{'nonnegativeIntervalWeightMs': round(value / 1000, 3), 'samples': samples[key],
             'function': key[0], 'source': key[1], 'line': key[2], 'codeType': key[3]}
            for key, value in counter.most_common(limit)]

def rows_by_samples(counter, samples, limit=100):
    # Prefer counts for hotspot ranking: individual recorded intervals can
    # include long descheduling waits, including a single >100ms sample.
    return [{'samples': count, 'nonnegativeIntervalWeightMs': round(counter[key] / 1000, 3),
             'function': key[0], 'source': key[1], 'line': key[2], 'codeType': key[3]}
            for key, count in samples.most_common(limit)]

leaf = Counter()
inclusive = Counter()
leaf_samples = Counter()
inclusive_samples = Counter()
by_thread = []
unknown_samples = 0
negative_deltas = []
for (pid, profile_id), profile in profiles.items():
    tid = profile['tid']
    assert len(profile['samples']) == len(profile['deltas'])
    local = Counter()
    local_samples = Counter()
    for node_id, delta in zip(profile['samples'], profile['deltas']):
        if delta < 0:
            negative_deltas.append({'pid': pid, 'profileId': profile_id, 'nodeId': node_id, 'deltaUs': delta})
        # Chrome can emit negative recorded intervals. Keep all samples, retain
        # each negative raw value, and label the positive-only weight explicitly.
        delta = max(0, delta)
        node = profile['nodes'].get(node_id)
        if node is None:
            unknown_samples += 1
            continue
        key = identity(node)
        leaf[key] += delta
        leaf_samples[key] += 1
        local[key] += delta
        local_samples[key] += 1
        ancestors = set()
        visited = set()
        while node is not None:
            assert node['id'] not in visited
            visited.add(node['id'])
            ancestors.add(identity(node))
            node = profile['nodes'].get(node.get('parent'))
        for ancestor in ancestors:
            inclusive[ancestor] += delta
            inclusive_samples[ancestor] += 1
    urls = sorted({identity(node)[1] for node in profile['nodes'].values() if identity(node)[1]})
    by_thread.append({'pid': pid, 'tid': tid, 'profileId': profile_id,
                      'threadName': thread_names.get((pid, tid)), 'startTimeUs': profile['start'],
                      'profilerChunkThreadIds': sorted(profile['chunkTids']),
                      'signedIntervalSumMs': sum(profile['deltas']) / 1000,
                      'negativeIntervals': sum(delta < 0 for delta in profile['deltas']),
                      'sampleCount': len(profile['samples']), 'sources': urls,
                      'leafHotspots': rows(local, local_samples),
                      'leafSampleHotspots': rows_by_samples(local, local_samples)})
result = {'scope': 'Diagnostic V8 samples from instrumented browser import. Interval weights use max(0, recorded timeDelta); all negative raw deltas are retained separately and sample counts include every observation. These weights include scheduling delays/waiting/startup, overlap across threads, and are not CPU time or authoritative whole-import latency.',
          'traceSha256': hashlib.sha256(raw).hexdigest(), 'events': len(events),
          'profileCount': len(profiles), 'unknownSamples': unknown_samples,
          'negativeDeltas': negative_deltas,
          'parserSymbolBinding': symbols if symbols else None,
          'leafHotspots': rows(leaf, leaf_samples, 100),
          'inclusiveHotspots': rows(inclusive, inclusive_samples, 100),
          'leafSampleHotspots': rows_by_samples(leaf, leaf_samples),
          'inclusiveSampleHotspots': rows_by_samples(inclusive, inclusive_samples),
          'threads': by_thread}
if args.report:
    report = json.loads(args.report.read_text())
    result['reportIdentity'] = {key: report.get(key) for key in ['status', 'buildTarget', 'packageSha256', 'browserVersion']}
    result['benchmark'] = report.get('benchmark')
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output': str(args.output), 'profiles': len(profiles), 'unknownSamples': unknown_samples,
                  'topProductLeaves': [row for row in result['leafHotspots'] if row['source']][:15]}))
