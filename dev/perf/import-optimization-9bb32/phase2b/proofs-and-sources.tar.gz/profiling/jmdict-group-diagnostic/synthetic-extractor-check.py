"""Synthetic diagnostic-ledger checks only; no product modules or imports executed."""
import copy,hashlib,importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
root=Path('/workspace/scratch/9bb32f82fa3b');w=root/'jm-group-diagnostic';out=root/'profiling/jmdict-group-diagnostic'
p=w/'dev/perf/import-group-stages-extract-9bb32.py'
ms=importlib.util.spec_from_file_location('diagnostic_extract',p);mod=importlib.util.module_from_spec(ms);ms.loader.exec_module(mod)
base_summary=json.loads((root/'profiling/hosted-baseline-jmdict/ordinary/summary.json').read_text())
base_report=json.loads((root/'profiling/hosted-baseline-jmdict/ordinary/run-1.json').read_text())
plan=json.loads((w/'dev/perf/import-group-stages-9bb32.json').read_text())
plan.update(overlaySourceCommit='1'*40,packageAuditPassed=True,expectedPackageSha256=base_report['packageSha256'],expectedBrowserVersion=base_report['browserVersion'])
E=mod.EVENTS

def build(multi_db=False,late_ready=False):
 events=[];ops=[]
 def event(name,group,op,t,v=0): events.append([E[name],group,op,t,v])
 def operation(kind,group,parent): ops.append([kind,group,parent]);return len(ops)
 event('pipelineStart',-1,0,0,3)
 rows=[44025]*11+[44024];pending=[30169]*11+[30173]
 for g,row in enumerate(rows):event('groupReady',g,0,1+g/100 if not late_ready else 20+g*30,row)
 for g,row in enumerate(rows):
  t=25+g*30 if late_ready else 3+g*30
  event('sinkEnter',g,0,t,row)
  parts=2 if multi_db and g==0 else 1
  remaining_rows=row;remaining_pending=pending[g]
  for part in range(parts):
   rr=remaining_rows//(parts-part);pp=remaining_pending//(parts-part);remaining_rows-=rr;remaining_pending-=pp
   dt=t+1+part*3;db=operation(1,g,0)
   event('dbBegin',g,db,dt,rr);event('dedupBegin',g,db,dt+.1);event('dedupEnd',g,db,dt+.2,pp)
   children=[]
   for i,span in enumerate([pp//2,pp-pp//2]):
    c=operation(2,g,db);children.append(c)
    event('contentBegin',g,c,dt+.3+i*.02,span);event('compressionStart',g,c,dt+.31+i*.02,2)
   event('contentDispatch',g,db,dt+.5,1);event('storageReady',g,db,dt+.6);event('metadataPublished',g,db,dt+.7)
   for i,rrr in enumerate([rr//2,rr-rr//2]):
    r=operation(3,g,db);event('recordBegin',g,r,dt+.8+i*.02,rrr);event('recordDone',g,r,dt+1+i*.1)
   event('joinBegin',g,db,dt+.9)
   for i,c in enumerate(children):
    event('compressionDone',g,c,dt+1.2+i*.1);event('contentDone',g,c,dt+1.4+i*.1)
   event('contentObserved',g,db,dt+1.6);event('joinSettled',g,db,dt+1.7,1);event('dbDone',g,db,dt+1.8)
  event('sinkRelease',g,0,t+8)
 event('pipelineEnd',-1,0,max(e[3] for e in events)+1,1)
 events.sort(key=lambda x:x[3])
 dbcounts=[0]*12;cc=[0]*len(ops);rc=[0]*len(ops)
 for kind,g,parent in ops:
  if kind==1:dbcounts[g]+=1
  elif kind==2:cc[parent-1]+=1
  else:rc[parent-1]+=1
 return {'schemaVersion':1,'complete':True,'flags':0,'generation':1,'pipelineCount':1,'workerCount':3,'groupCount':12,'eventNames':E,'operationKinds':{'db':1,'content':2,'record':3},'limits':{'events':4096,'groups':64,'operations':1024},'eventCount':len(events),'operationCount':len(ops),'operations':dict(zip(['kind','group','parent'],[list(x) for x in zip(*ops)])),'operationCounts':{'dbByGroup':dbcounts,'contentByOperation':cc,'recordByOperation':rc},'events':dict(zip(['code','group','operation','atMs','value'],[list(x) for x in zip(*events)]))}

def run_case(name,payload,expected,multi=False,mutate=None):
 s=copy.deepcopy(base_summary);r=copy.deepcopy(base_report);p=copy.deepcopy(plan)
 s['gitSha']=s['source']['gitSha']=p['overlaySourceCommit'];s['mediaCheck']='all';s['runs'][0]['validation']['media']['mode']='all'
 phase={'phase':mod.PHASE,'elapsedMs':0,'details':{'payload':json.dumps(payload,separators=(',',':'))}}
 s['runs'][0]['importDebug']['importerPhaseTimings'].append(copy.deepcopy(phase))
 raw=next(x for x in r['phases'] if (x.get('data') or {}).get('kind')=='dictionary-import')
 raw['data']['importDebug']['importerPhaseTimings'].append(copy.deepcopy(phase))
 if multi:
  p['expectedNativeCounters']['dedupNativeCallCount']=13
  next(x for x in raw['data']['importDebug']['importerPhaseTimings'] if x['phase'].startswith('term-file-fast-path:'))['details']['dedupNativeCallCount']=13
 if mutate:mutate(r,s,p)
 result=mod.audit(r,s,p)
 ok=result['eligibleForDependencyAnalysis']==expected
 receipt={'case':name,'expectedConclusive':expected,'actualConclusive':result['eligibleForDependencyAnalysis'],'passed':ok,'checkCount':len(result['checks']),'failures':[x['name'] for x in result['checks'] if not x['passed']],'inconclusiveReason':result.get('inconclusiveReason')}
 if name in ('valid-multiple-content-and-record-children','valid-multiple-dbs'):
  receipt['retainedOperationCount']=len(result.get('operations',[]));receipt['retainedGroupCount']=len(result.get('groups',[]))
  receipt['positivePreCompressionSegments']=sum(x['allRemainingObservedContentObligationsPreCompression'] for g in result.get('groups',[]) for x in g.get('segments',[]))
  (out/(name+'.synthetic-audit.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 return receipt

cases=[]
p=build();cases.append(run_case('valid-multiple-content-and-record-children',p,True))
cases.append(run_case('valid-multiple-dbs',build(multi_db=True),True,multi=True))
cases.append(run_case('valid-late-next-ready-nonpositive-windows',build(late_ready=True),True))
for name,edit in [
 ('overflow-flag',lambda q:q.update(flags=1,complete=False)),
 ('missing-terminal',lambda q:q['events']['code'].__setitem__(q['events']['code'].index(E['compressionDone']),E['unsupportedRoute'])),
 ('duplicate-record-done',lambda q:q['events']['code'].__setitem__(q['events']['code'].index(E['contentDone']),E['recordDone'])),
 ('wrong-parent',lambda q:q['operations']['parent'].__setitem__(1,0)),
 ('clock-reversal',lambda q:q['events']['atMs'].__setitem__(20,0)),
 ('inexact-child-count',lambda q:q['operationCounts']['contentByOperation'].__setitem__(0,1)),
 ('boolean-native-like-event',lambda q:q['events']['value'].__setitem__(0,True)),
 ('unexpected-worker-count',lambda q:q.update(workerCount=2)),
 ('incomplete-capture',lambda q:q.update(complete=False)),
]:
 q=copy.deepcopy(p);edit(q);cases.append(run_case(name,q,False))
cases.append(run_case('null-import-debug',p,False,mutate=lambda r,s,p:next(x for x in r['phases'] if (x.get('data') or {}).get('kind')=='dictionary-import')['data'].__setitem__('importDebug',None)))
cases.append(run_case('raw-summary-payload-mismatch',p,False,mutate=lambda r,s,p:s['runs'][0]['importDebug']['importerPhaseTimings'][-1]['details'].__setitem__('payload','{}')))
cases.append(run_case('unfrozen-source-pin',p,False,mutate=lambda r,s,p:p.__setitem__('overlaySourceCommit',None)))
receipt={'scope':'Synthetic raw-ledger tests only. No product source, worker, browser, fixture import or timing executed. Base raw report/summary supply schema scaffolding; injected events are fabricated and not performance evidence.','extractorSha256':hashlib.sha256(Path(mod.__file__).read_bytes()).hexdigest(),'generatorSha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'passed':all(c['passed'] for c in cases),'cases':cases}
(out/'synthetic-extractor-check.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'passed':receipt['passed'],'cases':len(cases),'unexpectedFailures':[c for c in cases if not c['passed']]}))
raise SystemExit(0 if receipt['passed'] else 1)
