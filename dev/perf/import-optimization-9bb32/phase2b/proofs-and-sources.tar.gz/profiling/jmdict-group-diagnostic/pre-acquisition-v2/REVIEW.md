# JMdict coordinator diagnostic: source review package

This is a diagnostic overlay on `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`, not an optimization or a product PR. No product import, product test, native rebuild, browser acquisition, or timing experiment has been run locally. The first proposed acquisition consists of exactly three predetermined, sequential JMdict slots on a hosted runner. Each uses the unchanged fresh-profile import benchmark, the locked fixture, production defaults and the observed three-worker route. A baseline package is built only to establish the exact observer package delta; it is never imported.

## Source scope

The four existing runtime files contain 39 added instrumentation statements/imports/declarations, plus two explanatory comment lines. No existing runtime line is removed. The fifth runtime file is a collector with fixed scalar columns: 4,096 event slots, 64 groups and 1,024 operation slots (95,488 raw bytes before the post-finalization export). No row, content buffer, chunk, promise or storage owner is retained by the collector. Worker code, native assets, formats, settings, admission limits, concurrency, callback topology and existing await/promise chains are unchanged.

The collector records authoritative parser group indices and separate DB, content and record operation IDs. Group and operation callbacks carry numeric generation tokens captured before their existing awaits. Content-operation parentage is established only during the existing synchronous `_tryBeginPersistArtifactTermContent` dispatch. Record parentage is consumed at the existing async helper's synchronous entry. Multiple children and multiple DB operations remain explicit in the event ledger and count arrays; they are never silently treated as one operation per group.

A synchronous throw during content dispatch can leave the diagnostic scope open. That does not alter the original throw, drain, rollback or cleanup. The failed capture is inconclusive. An unexported session prevents a later import from becoming valid; an exported session can reset, but late callbacks carrying its old generation invalidate the new capture instead of being attached to a new operation. Missing terminal events, duplicate events, missing exports, overflow, fallback, failed joins, unexpected worker/route/context or invalid clock values are all inconclusive.

## Verified raw capture path

`DictionaryImporter` adds the diagnostic phase only after its existing bulk-finalization block. A dedicated emitter catches the entire allocation/serialization/phase insertion. It avoids `recordPhaseTiming`, whose logging/stringification could throw after publication. The phase detail is one JSON string, so no large object must survive a type-specific normalizer.

The existing path preserves that string: dictionary worker handler forwards `importPayload.debug` as `importerDebug`; settings controller `normalizeImporterPhaseTimings` retains `details` without truncation; `_recordImportDebugSnapshot` stores the phase array in the page's last-import debug object; the unchanged E2E harness reads it after its import completion boundary and writes `phases[].data.importDebug`; the benchmark summary retains the same `importDebug`. The extractor checks raw/summary payload identity. An earlier throw or finalization exception may prevent any payload; that remains a failed or inconclusive acquisition, never a zero-length gap.

## What the timestamps mean

Every event uses the coordinator's `safePerformance.now` clock. `groupReady` is coordinator-observed validated result readiness, potentially delayed by message dispatch. `compressionDone` observes completion of the existing compression/envelope/output-validation path, potentially delayed by promise continuation. It is not worker compute finish or pure codec CPU. `recordDone` observes the existing record helper's successful return boundary, not a final disk flush. `contentDone` and the later DB `contentObserved` continuation remain separate. None is a physical disk-completion or CPU-idleness measurement.

The extractor first validates every event/operation identity, exact event multiplicity, parent-child count, route, chronological relationship, row/span totals, native work, sampled persisted lookup receipt, restart and empty JMdict media receipt. Only a wholly valid ledger is segmented. It preserves every group and negative/nonpositive signed remainder. The segments enumerate outstanding compression/envelope IDs, post-compression content IDs and continuation-only DB IDs. They may establish an observed dependency ordering while a next group is already available; they do not predict a saving or prove unused coordinator CPU.

Instrumentation overhead is not measured. Scalar writes, clock reads, import-start allocation and post-finalization serialization can change scheduling. All incidental times from the unchanged harness are retained, including its historical `authoritativeTiming=true` field, but the diagnostic plan explicitly excludes those times from optimization claims or comparisons with uninstrumented cohorts.

## Hosted plan and retention

The read-only workflow checks out its immutable `github.sha` with credentials disabled. The driver refuses local execution and workflow run attempts other than one. It requires clean source, exact baseline/observer source hashes, unchanged harness dependencies and both unchanged native binaries. It builds baseline and observer packages and requires exactly four changed JS entries plus the one added collector; it retains both ZIPs and complete member maps.

Before any import, the driver records the actual workflow commit/tree, package audit/hash, browser binary/version, locked fixture and all three slots in `registered-plan.json`. It never changes flags or emulates another worker policy to obtain the desired route. Each slot starts a separate unchanged benchmark process, which creates a fresh profile. The launch request is recorded as attempted before the child starts, so an external kill cannot silently relabel a started slot as unattempted. Any identity/preflight failure or nonzero acquisition exit stops and preserves remaining slots as unattempted, including nested child signals normalized to exit 1. An acquisition that exits 0 but has an inconclusive semantic or diagnostic review may continue the remaining predeclared slots unchanged. No failed observation is retried or replaced. Every raw JSON/HTML/log, failure, identity, canonical receipt, full scalar payload and derived audit is retained, with a complete retention manifest.

The existing canonical receipt verifier is reused unchanged. Its persisted semantic scope is 72 sampled lookup observations (12 terms across one cold and five warm passes), orderly restart, counts and all referenced JMdict media (the empty set). It is not exhaustive persisted-term verification and is separate from the complete diagnostic event ledger. No memory qualification is claimed by this diagnostic.

## Checks performed locally

`static-checks.json` records five bounded Node syntax-only checks, Python AST parsing, YAML/permission/checkout checks, source hash bindings and an additive-diff check. They passed. The local syntax runtime was Node 24.20.0; the proposed hosted acquisition is explicitly Node 22.22.0.

`synthetic-extractor-check.json` records 15 synthetic ledger checks, including multiple content/record children, multiple DB IDs, late readiness, missing and duplicate terminals, wrong parents/counts, overflow, clock reversal, boolean-valued malformed input, wrong worker count, incomplete/null payloads, raw/summary mismatch and missing source pins. The events are fabricated and are not acquired performance evidence. Their generator, complete positive-case audits and earlier draft source are retained. No product module was executed by these checks.

Independent review by the architecture agent covers the actual hook topology, parent/token identity, raw capture path, extractor order/multiplicity checks and the hosted protocol. Publication and acquisition remain the parent's separate decision after all reviewers have bound the final file hashes.

The initial pre-acquisition driver/spec and their review/check receipts remain under `pre-acquisition-v1/`. Before any acquisition, parent/profiler review hardened launch-attempt recording and fail-stop behavior; no overlay, extractor, native asset or acquisition result changed.
