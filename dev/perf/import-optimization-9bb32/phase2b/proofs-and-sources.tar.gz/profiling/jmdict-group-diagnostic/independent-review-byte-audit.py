"""Read-only source identity audit; never imports product modules or runs tests."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/workspace/scratch/9bb32f82fa3b')
WORK = ROOT / 'jm-group-diagnostic'
BASE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
FILES = [
    'ext/js/dictionary/dictionary-database.js',
    'ext/js/dictionary/dictionary-importer.js',
    'ext/js/dictionary/term-bank-wasm-parser.js',
    'ext/js/dictionary/term-content-block-store.js',
    'ext/js/dictionary/import-group-stage-diagnostic.js',
    'dev/perf/import-group-stages-9bb32.py',
    'dev/perf/import-group-stages-9bb32.json',
    'dev/perf/import-group-stages-extract-9bb32.py',
    '.github/workflows/import-group-stages-9bb32.yml',
]


def identity(data):
    return {
        'sizeBytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest(),
        'gitBlobSha1': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
    }


def git_bytes(path):
    return subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=WORK)


spec = json.loads((WORK / FILES[6]).read_text())
checks = []
for section in ['overlaySourceSha256', 'unchangedHarnessSha256', 'diagnosticToolSha256', 'nativeAssetSha256']:
    for name, expected in spec[section].items():
        path = WORK / name
        # ext/lib files are generated copies. The pinned setup action runs
        # build:libs before the hosted driver; no build is run by this review.
        tracked_name = 'dev/data/dictionary-wasm/' + Path(name).name if section == 'nativeAssetSha256' else name
        if path.is_file():
            data, origin = path.read_bytes(), 'live worktree file'
        else:
            assert section in ['unchangedHarnessSha256', 'nativeAssetSha256']
            data, origin = git_bytes(tracked_name), 'baseline Git object ' + tracked_name + '; absent sparse/generated worktree input'
        actual = hashlib.sha256(data).hexdigest()
        checks.append({'name': section + ': ' + name, 'passed': actual == expected, 'expected': expected, 'actual': actual, 'origin': origin})
        if section in ['unchangedHarnessSha256', 'nativeAssetSha256']:
            checks.append({'name': 'baseline unchanged: ' + name, 'passed': hashlib.sha256(git_bytes(tracked_name)).hexdigest() == actual, 'trackedPath': tracked_name})
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORK, text=True).strip()
tracked = subprocess.check_output(['git', 'diff', '--name-only'], cwd=WORK, text=True).splitlines()
checks.append({'name': 'prospective baseline HEAD', 'passed': head == BASE, 'actual': head, 'expected': BASE})
checks.append({'name': 'four existing JS files only', 'passed': set(tracked) == set(FILES[:4]), 'actual': tracked})
report = {
    'schemaVersion': 1,
    'scope': 'Independent read-only source review and identity audit. No product execution, import, build, timing or publication by this reviewer.',
    'baselineCommit': BASE,
    'reviewBinding': 'Exact nine file hashes below; prospective uncommitted tree. A later commit must retain these bytes or be re-reviewed.',
    'files': [{'path': p, **identity((WORK / p).read_bytes())} for p in FILES],
    'byteChecks': checks,
    'allByteChecksPassed': all(c['passed'] for c in checks),
    'initialReviewSetupFailure': {
        'preserved': True,
        'exception': "FileNotFoundError: [Errno 2] No such file or directory: '/workspace/scratch/9bb32f82fa3b/jm-group-diagnostic/package-lock.json'",
        'effect': 'The first read-only identity pass stopped before writing a receipt because the worktree is sparse. No source, import, timing or product test ran. This pass explicitly resolves absent unchanged inputs from immutable baseline Git objects instead of implying they are present on disk.',
        'secondSetupFailure': "CalledProcessError: git show 9e10d3b3fcf66d344ab31bc42c9b522fa5215da2:ext/lib/term-bank-parser.wasm returned 128 because ext/lib is generated, not tracked.",
        'secondCorrection': 'The retained initial script is independent-review-byte-audit.initial.py. The final script resolves native inputs from dev/data/dictionary-wasm and records that origin. The pinned setup action builds ext/lib copies before the hosted driver; the driver was not defective and no local build was run.',
    },
    'manualFindings': [
        {'name': 'Product promise topology', 'passed': True, 'detail': 'Existing runtime files add imports, scalar marks and synchronous scope handoffs only. No await, promise, then callback, worker policy or storage owner is replaced or added.'},
        {'name': 'Generation and operation ownership', 'passed': True, 'detail': 'Pipeline, DB, content and record tokens are captured before existing awaits. Late callbacks use captured generation-bound tokens; multiple children and DB operations remain distinct.'},
        {'name': 'Export boundary and failure', 'passed': True, 'detail': 'The importer appends the payload after existing bulk finalization. Allocation, serialization and phase insertion are caught. Missing, stale, duplicate, overflow, failure and unsupported captures are inconclusive.'},
        {'name': 'Transport', 'passed': True, 'detail': 'Existing worker result, controller phase normalization, importDebug snapshot and raw E2E report preserve the scalar string. The extractor requires exactly one raw and summarized phase with identical strings.'},
        {'name': 'Event ledger', 'passed': True, 'detail': 'Exact operation multisets, global and group markers, cardinalities, parents, monotonic clock and explicit counts are validated before segments are derived.'},
        {'name': 'Ordering', 'passed': True, 'detail': 'Child contentBegin/compressionStart precede dispatch-end. contentDone and later contentObserved remain distinct. Record and content continuations execute after joinBegin registration under the existing topology.'},
        {'name': 'Fail-closed raw shape', 'passed': True, 'detail': 'Null/malformed raw input is inconclusive. The exception path catches AttributeError and resets eligibility. The driver retains outer exceptions separately as slot failures.'},
        {'name': 'Window interpretation', 'passed': True, 'detail': 'Start waits for next observed ready, all storage/metadata, records and joins. Nonpositive signed windows remain visible. Labels describe observed obligations, not CPU work, removable time or relative speed.'},
        {'name': 'Acquisition identity', 'passed': True, 'detail': 'Hosted-only driver requires repository and clean HEAD equal GITHUB_SHA, validates source/harness/native bytes, and checks actual baseline/diagnostic packages for exactly four modified plus one added member before importing.'},
        {'name': 'Schedule and retention', 'passed': True, 'detail': 'Three fixed sequential slots use the unchanged harness, default flags, one fresh-process run and all-media mode. There are no replacements. Killed/timed-out acquisition stops later slots; failures and unattempted slots remain explicit and upload uses always().' },
        {'name': 'Correctness receipts', 'passed': True, 'detail': 'Existing canonical persisted validator is retained. Extractor separately checks fixture/source/package/browser, native counters, sampled semantic identity and empty-JMdict all-media receipt.'},
    ],
    'limitations': [
        'No hosted diagnostic observation exists yet; this source review is not a performance claim.',
        'Completion marks include coordinator envelope/output validation and promise scheduling. They are not worker CPU or physical I/O completion.',
        'The observer adds diagnostic overhead and allocations, so its ordinary timestamps must not enter candidate speed comparisons.',
        'Persisted lookup validation is sampled, not exhaustive equality of all stored rows.',
        'A synchronous dispatch throw may leave its scope active. Failure/incomplete/stale state makes the capture inconclusive; absence is never zero delay.',
        'Hosted driver execution, package audit and observation gates remain outstanding.',
    ],
    'blockingFindings': [],
    'rawGitStatus': subprocess.check_output(['git', 'status', '--short'], cwd=WORK, text=True),
}
assert report['allByteChecksPassed']
out = ROOT / 'profiling/jmdict-group-diagnostic/independent-source-review.json'
with out.open('x') as stream:
    json.dump(report, stream, ensure_ascii=False, indent=2)
    stream.write('\n')
print(json.dumps({'path': str(out), **identity(out.read_bytes()), 'byteChecks': len(checks), 'manualChecks': len(report['manualFindings']), 'passed': True}))
