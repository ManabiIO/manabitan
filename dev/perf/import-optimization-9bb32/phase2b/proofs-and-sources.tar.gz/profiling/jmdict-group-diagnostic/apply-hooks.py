from pathlib import Path
root=Path('/workspace/scratch/9bb32f82fa3b/jm-group-diagnostic')
imp="import {GROUP_STAGE, groupStageDiagnostic} from './import-group-stage-diagnostic.js';\n"
def replace(text,old,new):
    assert text.count(old)==1,(old[:100],text.count(old))
    return text.replace(old,new)
def scoped(text,start,end,edits):
    a=text.index(start); b=text.index(end,a)
    piece=text[a:b]
    for old,new in edits: piece=replace(piece,old,new)
    return text[:a]+piece+text[b:]
p=root/'ext/js/dictionary/term-bank-wasm-parser.js';s=p.read_text()
s=replace(s,"import {buildTermLookupFilter} from './term-lookup-route.js';",imp+"import {buildTermLookupFilter} from './term-lookup-route.js';")
s=scoped(s,'class ParallelTermBankPipelineRun {','    /** Creates one ordered result slot',[
("        this._groups = groups;","        this._groups = groups;\n        /** @type {number} Generation-bound coordinator diagnostic identity. */\n        this._diagnosticPipeline = groupStageDiagnostic.beginPipeline(groups.length);"),
("            await this._poolLease.release(this._keepWorkers);","            await this._poolLease.release(this._keepWorkers);\n            groupStageDiagnostic.endPipeline(this._diagnosticPipeline, this._keepWorkers);"),
("    async _runPipeline(workers) {\n        this._createSlots();","    async _runPipeline(workers) {\n        groupStageDiagnostic.startPipeline(this._diagnosticPipeline, workers.length);\n        this._createSlots();"),
("                if (chunk !== null) {\n                    try {","                groupStageDiagnostic.group(this._diagnosticPipeline, i, GROUP_STAGE.sinkEnter, result.rowCount);\n                if (chunk !== null) {\n                    try {"),
("                this._nextSinkGroupIndex = i + 1;","                groupStageDiagnostic.group(this._diagnosticPipeline, i, GROUP_STAGE.sinkRelease);\n                this._nextSinkGroupIndex = i + 1;"),
])
s=replace(s,"                this._resultSlots[groupIndex].resolve({...result, sourceBytes, ownedContentBytes, consume});","                // Coordinator-observed validated result readiness, not worker CPU completion.\n                groupStageDiagnostic.group(this._diagnosticPipeline, groupIndex, GROUP_STAGE.groupReady, result.rowCount);\n                this._resultSlots[groupIndex].resolve({...result, sourceBytes, ownedContentBytes, consume});")
p.write_text(s)
p=root/'ext/js/dictionary/dictionary-database.js';s=p.read_text()
anchor=s[s.index('import '):s.index('\n',s.index('import '))+1];s=replace(s,anchor,imp+anchor)
s=scoped(s,'    async _bulkAddArtifactTermsChunkWithContentDedup(chunk) {','    /**\n     * @param {number} tableSize',[
("        const useLocalTransaction = !this._bulkImportTransactionOpen;","        const diagnosticDb = groupStageDiagnostic.beginDb(chunk.rowCount);\n        const useLocalTransaction = !this._bulkImportTransactionOpen;"),
("            const dedup = await this._resolveArtifactTermContentDedup(chunk, true);","            groupStageDiagnostic.mark(diagnosticDb, GROUP_STAGE.dedupBegin);\n            const dedup = await this._resolveArtifactTermContentDedup(chunk, true);\n            groupStageDiagnostic.mark(diagnosticDb, GROUP_STAGE.dedupEnd, dedup.pendingContentCount);"),
("                const earlyContentPersistence = useLocalTransaction ?","                groupStageDiagnostic.startContentDispatch(diagnosticDb);\n                const earlyContentPersistence = useLocalTransaction ?"),
("                if (earlyContentPersistence?.initialSelection === true) {","                groupStageDiagnostic.endContentDispatch(diagnosticDb, earlyContentPersistence !== null);\n                if (earlyContentPersistence?.initialSelection === true) {"),
("                    const {\n                        pendingOffsets,","                    groupStageDiagnostic.mark(diagnosticDb, GROUP_STAGE.storageReady);\n                    const {\n                        pendingOffsets,"),
("                    const contentMetadataPublishMs = safePerformance.now() - tContentMetadataStart;","                    groupStageDiagnostic.mark(diagnosticDb, GROUP_STAGE.metadataPublished);\n                    const contentMetadataPublishMs = safePerformance.now() - tContentMetadataStart;"),
("                        pendingRecordAppend = this._appendResolvedArtifactTermRecords(","                        groupStageDiagnostic.expectRecord(diagnosticDb);\n                        pendingRecordAppend = this._appendResolvedArtifactTermRecords("),
("                                contentCompletedAt = safePerformance.now();","                                contentCompletedAt = safePerformance.now();\n                                groupStageDiagnostic.mark(diagnosticDb, GROUP_STAGE.contentObserved, 0, contentCompletedAt);"),
("                        const concurrentResults = await Promise.allSettled([","                        groupStageDiagnostic.mark(diagnosticDb, GROUP_STAGE.joinBegin);\n                        const concurrentResults = await Promise.allSettled(["),
("                        const concurrentErrors = concurrentResults","                        groupStageDiagnostic.mark(diagnosticDb, GROUP_STAGE.joinSettled, concurrentResults.every((result) => result.status === 'fulfilled') ? 1 : 0);\n                        const concurrentErrors = concurrentResults"),
("                await this._appendResolvedArtifactTermRecords(","                groupStageDiagnostic.mark(diagnosticDb, GROUP_STAGE.unsupportedRoute);\n                groupStageDiagnostic.expectRecord(diagnosticDb);\n                await this._appendResolvedArtifactTermRecords("),
("            this._lastBulkAddTermsMetrics = importMetrics;","            this._lastBulkAddTermsMetrics = importMetrics;\n            groupStageDiagnostic.mark(diagnosticDb, GROUP_STAGE.dbDone);"),
("        } catch (e) {\n            this._rollbackStagedArtifactTermContentMetadata", "        } catch (e) {\n            groupStageDiagnostic.mark(diagnosticDb, GROUP_STAGE.operationFailed);\n            this._rollbackStagedArtifactTermContentMetadata"),
])
s=scoped(s,'    async _appendResolvedArtifactTermRecords(chunk, contentOffsets, contentLengths, resolvedContentDictNames, importMetrics) {','    /** */\n    _pruneOrphanTermEntryContent',[
("        const metrics = await this._termRecordStore.appendBatchFromArtifactChunkResolvedContent(","        const diagnosticRecord = groupStageDiagnostic.beginRecord(chunk.rowCount);\n        const metrics = await this._termRecordStore.appendBatchFromArtifactChunkResolvedContent("),
("            this._termsVirtualTableDirty = true;\n            return;","            this._termsVirtualTableDirty = true;\n            groupStageDiagnostic.mark(diagnosticRecord, GROUP_STAGE.recordDone);\n            return;"),
("        importMetrics.termsVtabInsertMs += safePerformance.now() - tTermsVtabInsertStart;","        importMetrics.termsVtabInsertMs += safePerformance.now() - tTermsVtabInsertStart;\n        groupStageDiagnostic.mark(diagnosticRecord, GROUP_STAGE.recordDone);"),
])
p.write_text(s)
p=root/'ext/js/dictionary/term-content-block-store.js';s=p.read_text()
s=replace(s,"import {snapshotTermBankExperiments} from './term-bank-experiments.js';",imp+"import {snapshotTermBankExperiments} from './term-bank-experiments.js';")
s=scoped(s,'    _beginAppendSharedSpans(sourceBytes, sourceOffsets, sourceLengths, compressionDictName, uncompressedBytes, initialSelection) {','        return {storage, sourceConsumed, completion};',[
("        const compressionExperiments = this._compressionExperiments;","        const diagnosticContent = groupStageDiagnostic.beginContent(sourceLengths.length);\n        const compressionExperiments = this._compressionExperiments;"),
("            let compressionStart = safePerformance.now();","            let compressionStart = safePerformance.now();\n            groupStageDiagnostic.mark(diagnosticContent, GROUP_STAGE.compressionStart, packed.packedChunkLengths.length, compressionStart);"),
("            } catch (error) {\n                if (sourceWasConsumed) {","            } catch (error) {\n                groupStageDiagnostic.mark(diagnosticContent, GROUP_STAGE.unsupportedRoute);\n                if (sourceWasConsumed) {"),
("            const completedAt = safePerformance.now();","            const completedAt = safePerformance.now();\n            groupStageDiagnostic.mark(diagnosticContent, GROUP_STAGE.compressionDone, 0, completedAt);"),
("                await Promise.allSettled(pending);\n                throw error;","                await Promise.allSettled(pending);\n                groupStageDiagnostic.mark(diagnosticContent, GROUP_STAGE.operationFailed);\n                throw error;"),
("            return {\n                ...storageResult,","            groupStageDiagnostic.mark(diagnosticContent, GROUP_STAGE.contentDone);\n            return {\n                ...storageResult,"),
])
p.write_text(s)
p=root/'ext/js/dictionary/dictionary-importer.js';s=p.read_text()
anchor=s[s.index('import '):s.index('\n',s.index('import '))+1];s=replace(s,anchor,"import {groupStageDiagnostic} from './import-group-stage-diagnostic.js';\n"+anchor)
s=replace(s,"        const phaseTimings = [];","        const phaseTimings = [];\n        groupStageDiagnostic.beginImport();")
s=replace(s,"        // Cancellation is checked before finalization above.","        groupStageDiagnostic.appendPhase(phaseTimings, !importSession.failed);\n\n        // Cancellation is checked before finalization above.")
p.write_text(s)
print('Applied coordinator-only hooks to four baseline files; no product execution.')
