# JMdict: remaining opportunity synthesis

**Decision: the current evidence does not justify another implementation candidate.** Finish the frozen wide-keyword correctness and import comparisons first. This review identifies one possible scheduling question for a future diagnostic, but does not establish a removable critical-path wait or recommend changing concurrency.

This is a bounded, read-only synthesis at baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. No product source, tests, imports, compiler processes, thresholds, or qualification schedules were changed.

## What the completed results establish

The canonical fingerprint candidate reduced an exact kind of hash-probe work, and its JMdict canonical stage improved in both full-browser orders. Complete imports did not show a replicated gain:

| Candidate / JMdict cohort | Median paired import change | Equal-work change | Faster pairs |
| --- | ---: | ---: | ---: |
| Fingerprint AB | +1.168% | +1.504% | 3/12 |
| Fingerprint BA | −1.219% | +0.969% | 7/12 |
| Minsize AB | −1.423% | −2.067% | 9/12 |
| Minsize BA | +1.685% | +1.669% | 2/12 |

These are separate hosts/cohorts, with their original controls, tails and descriptive intervals retained. They must not be pooled or control-adjusted into a gain. Minsize's AB interval crosses zero; BA's interval is positive. This synthesis is limited to the completed JMdict cells and does not declare all-corpus minsize qualification complete.

Sources: [fingerprint AB](hosted-qualification/fingerprint/jmdict-AB/audit-and-stage-analysis.json), [fingerprint BA](hosted-qualification/fingerprint/jmdict-BA/audit-and-stage-analysis.json), [minsize AB](hosted-qualification/minsize/jmdict-AB/audit-and-stage-analysis.json), [minsize BA](hosted-qualification/minsize/jmdict-BA/audit-and-stage-analysis.json). Each has a separate independent semantic/memory receipt in the same directory.

The single baseline diagnostic reports a 591 ms term pipeline, 402 ms sink sum, 495.7 ms parallel parser wall region, and 216.3 ms content compression sum. These regions overlap. They do not demonstrate that 90.8 ms canonical work, 79.5 ms publication work, or 216.3 ms compression can independently be subtracted from the 788.1 ms full import. [Baseline report](hosted-baseline-summary.json).

## One scheduling question, held without implementation

After metadata publication, `_bulkAddArtifactTermsChunkWithContentDedup` starts record append and joins it with content persistence before returning. The ordered parser sink cannot begin the next group's database work until that promise settles. An exact future question is whether a **bounded preparation step for the next already-admitted group** could overlap its canonical/exact dedup work with the preceding group's compression completion, while keeping record writes/publication ordered.

Source: [`dictionary-database.js` at the frozen baseline](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/dictionary-database.js), `_bulkAddArtifactTermsChunkWithContentDedup` (8375), publication (8555), and the persistence/record join (8600s).

The bounded ownership search found no exact cross-group preparation proposal. Related work already owns same-group overlap ([#874](https://github.com/ManabiIO/manabitan/pull/874)), earlier borrowed-source release while preserving the ordered sink ([#955](https://github.com/ManabiIO/manabitan/pull/955)), and lead-budget changes ([#828](https://github.com/ManabiIO/manabitan/pull/828), [#829](https://github.com/ManabiIO/manabitan/pull/829)). This is a limited search result, not proof that no abandoned variant exists. [Retained targeted search](jmdict-remaining-opportunities-ownership.json).

**Why it is not a candidate now:** existing aggregate timers do not isolate a late-group compression-only gap with an available next group. Native resolution mutates staged metadata, exact matching can await persisted bytes, and publication reserves references before durability. Starting another preparation task therefore adds failure-drain, rollback and reservation dependencies; simply moving an `await` would be insufficient. [#656](https://github.com/ManabiIO/manabitan/pull/656) documents the existing requirement to drain active sinks before rollback. Earlier shared-content/overlap work also demonstrates that additional retained buffers can create a material memory tradeoff ([#810](https://github.com/ManabiIO/manabitan/pull/810), [#869](https://github.com/ManabiIO/manabitan/pull/869)). No new timing or memory benefit is inferred here.

Only a future already-authorized detailed trace showing a repeated, substantial, non-overlapped completion gap would justify designing this route. This note does not authorize or request that acquisition.

## Why the other visible regions do not supply a fresh narrow patch

- **Final index close:** the retained JMdict trace puts 102.760 ms inside `flush`, within a 103.521 ms task using only 1.915 ms thread CPU. Completed cohort baseline close medians vary from 8.8–9.4 ms to 109.95–112.2 ms. This is blocking/descheduling evidence, not a missing JavaScript loop or a quantified disk-service time. The current writer already closes after its flush; broad worker offload/checkpoint variants overlap prior work, including [#821](https://github.com/ManabiIO/manabitan/pull/821). [Detailed tail evidence](finalization-tail-analysis.json); [writer source](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/term-record-import-index-writer.js).
- **Publication and source-cache scans:** `_registerInFlightTermContentSources` validates references and duplicate reservations; `_cacheRecentPublishedTermContentSources` bounds and charges retained allocations, already adopts eligible owned slabs, and already bulk-fills contiguous metadata. Removing repeated checks requires a private ownership proof across current boundaries, not just a faster loop. Previous native preflight [#914](https://github.com/ManabiIO/manabitan/pull/914) regressed JMdict and found no justified admission correction. No additional unowned operation removal was demonstrated in this review.
- **Record-field revalidation:** the immediate producer-proof idea was already shelved because the existing call chain has two promise boundaries and a caller-visible mutable output. The same validator loop has an existing owner, [#944](https://github.com/ManabiIO/manabitan/pull/944). [Exact boundary review](record-field-proof-review.json).
- **Parser instruction count:** broad `minsize` changed loop strategy and did not replicate a JMdict gain. The pending wide-keyword candidate is the current narrow, source-backed response: bounded literal comparisons with the original escaped fallback. For JMdict, the rationale is principally the changed compiled hot-loop shape; this review does not establish that the long-keyword match is common. Smaller static code and fewer locals/load sites are neither CPU-time measurements nor speed gains. Its pending results should determine whether that specific change matters before another compiler/parser variant is selected. [Contract and ownership review](wide-literal-ownership-contract-review.json).

The useful next action is to audit the queued complete evidence and make a promotion or shelf decision under the frozen gates. No second fresh implementation is recommended by this synthesis.
