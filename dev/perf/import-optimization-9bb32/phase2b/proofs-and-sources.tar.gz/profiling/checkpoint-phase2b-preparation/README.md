# Phase2B preparation — not sealed

This directory contains a discovery snapshot and proposed layout only. It does
not contain a publication archive. Re-running the preparation script refreshes
these draft manifests from the files that actually exist; it never imports a
dictionary, executes a test, regenerates a result summary, copies a raw archive,
or changes existing evidence.

The plan is twelve unchanged per-cell raw archives (six minsize, six wide), plus
one small deterministic proof archive for new outcomes, raw QA/parity evidence,
workflow/retention/audit records, root's summary script and outputs, and the three
remaining-opportunity synthesis files. Original phase1/phase2A archive payloads
will not be duplicated. Identical existing proof members are referenced by their
published archive/member identities instead. Current source/path hashes are
discovery metadata; every final input must be re-read and rehashed at freezing.

`READINESS.json` distinguishes missing outcomes from observed files and from
failed qualification. A successful independent audit can correctly reproduce a
failed memory-coverage gate. Such a failure must be retained, not screened out,
retried, or relabeled as a memory regression. No constant success assumption or
fixed completed-import count is used by this preparation tool.

Wide QA/actionlint log retrieval remains the priority. The future parity result
directory and wide cohort directories were confirmed by their owner, but are
explicitly marked pending until actual files arrive. Final parity-container
retention cannot be selected until the original artifact/receipt is inspected.

There is intentionally no sealing command here yet. After all existing cohorts
finish and their owners freeze independent audits, the final assembler should
consume this layout, verify every original/retained binding, preserve all failed
attempts, and use the already reviewed deterministic packing rules. An independent
byte/content audit remains required before root publishes anything. Phase1 and
phase2A are immutable.
