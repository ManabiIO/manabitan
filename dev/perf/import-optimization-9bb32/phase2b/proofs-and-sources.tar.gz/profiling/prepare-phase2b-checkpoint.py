#!/usr/bin/env python3
"""Prepare a failure-aware evidence layout; never seal, copy archives, or publish.

Only this script's preparation directory is written. Existing evidence and
summary outputs are read without regeneration. Missing paths are requirements,
not invented observations. The final assembler must wait for owners to freeze
all results, then re-read/hash them and run a new independent byte audit.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


PROF = Path(__file__).resolve().parent
OUT = PROF / "checkpoint-phase2b-preparation"
BASE = "9e10d3b3fcf66d344ab31bc42c9b522fa5215da2"
CANDIDATES = {
    "minsize": {"commit": "2907ba1bad0958c22fe363f88d7cceb4d4bc604e", "run": 46104898097},
    "wide": {"commit": "ebf4278afc59d83f191692bd587f0e1f7e8682b3", "run": 46112384728},
}
CELLS = [f"{dictionary}-{order}" for dictionary in ("jmdict", "jitendex", "vndb") for order in ("AB", "BA")]
REQUIRED_CELL_FILES = ["raw-evidence.tar.gz", "retention-manifest.json", "github-artifact.json",
                       "audit-and-stage-analysis.json", "independent-semantics-memory-audit.json"]


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
            "gitBlobSha1": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def read_json(relative):
    path = PROF / relative
    if not path.is_file() or path.is_symlink():
        return None
    return json.loads(path.read_bytes())


def main():
    observed_at = datetime.now(timezone.utc).isoformat()
    prior_index = read_json("checkpoint-phase2a/PROOF-INVENTORY.json")
    prior_members = {item["path"]: item for item in prior_index["files"]}
    phase2a_publication = read_json("checkpoint-phase2a-publication-receipt.json")
    prior_phase1 = read_json("checkpoint-phase2a/PHASE1-DEPENDENCIES.json")
    proof_sources = {}
    prior_references = {}
    missing = []

    def select(path, required=False):
        relative = path.relative_to(PROF).as_posix()
        if not path.is_file() or path.is_symlink():
            if required:
                missing.append({"path": "profiling/" + relative, "reason": "Required outcome/source file not yet present"})
            return
        data = path.read_bytes()
        record = {"path": "profiling/" + relative, "localPath": str(path), **identity(data),
                  "identityScope": "Observed during unsealed preparation; re-read and rehash at final freeze"}
        previous = prior_members.get(record["path"])
        if previous and previous["sha256"] == record["sha256"] and previous["bytes"] == record["bytes"]:
            prior_references[record["path"]] = {
                **record, "priorCommit": phase2a_publication["commit"],
                "priorArchive": "dev/perf/import-optimization-9bb32/phase2a/proofs-and-sources.tar.gz",
                "archiveSha256": "c00ef090f0e0177361f78306b29b3beb4824b766c9d787fbaea83079a9c8ffc1",
                "archiveGitBlobSha1": "e3246934cf6bd8c21f2fd32b7d259cea31544f4c",
                "member": record["path"], "copyPayloadIntoNextCheckpoint": False,
            }
        else:
            if previous:
                record["previousPhase2aMember"] = {key: previous[key] for key in ("path", "bytes", "sha256")}
            proof_sources[record["path"]] = record

    cell_records = []
    for candidate, metadata in CANDIDATES.items():
        for cell in CELLS:
            relative = Path("hosted-qualification") / candidate / cell
            folder = PROF / relative
            present = folder.is_dir()
            missing_names = [name for name in REQUIRED_CELL_FILES if not (folder / name).is_file()]
            for name in missing_names:
                missing.append({"path": "profiling/" + (relative / name).as_posix(),
                                "reason": "Required cohort retention/audit input pending"})
            retention = read_json((relative / "retention-manifest.json").as_posix())
            stage = read_json((relative / "audit-and-stage-analysis.json").as_posix())
            independent = read_json((relative / "independent-semantics-memory-audit.json").as_posix())
            job = read_json((relative / "job-completion-summary.json").as_posix())
            issues = []
            if stage:
                plan = stage["plan"]
                if ((plan["baseline"], plan["candidate"], stage["artifact"]["runId"])
                        != (BASE, metadata["commit"], metadata["run"])):
                    issues.append("Retained stage analysis has unexpected source/run pins")
            if independent:
                if independent["sourcePins"] != {"A": BASE, "B": metadata["commit"]}:
                    issues.append("Independent audit has unexpected source pins")
                if independent["sourceArtifact"]["runId"] != metadata["run"]:
                    issues.append("Independent audit has unexpected run identity")
                if independent.get("passed") is not True:
                    issues.append("Independent receipt has not established reproducible evidence; retain failure and resolve before seal")
            record = {
                "candidate": candidate, "cell": cell, "expectedSource": metadata["commit"],
                "expectedRun": metadata["run"], "directory": "profiling/" + relative.as_posix(),
                "directoryExists": present, "missingRequiredFiles": missing_names,
                "proposedArchiveName": f"{candidate}-{cell}.raw-evidence.tar.gz",
                "archivePolicy": "Copy existing raw archive byte-for-byte after final rehash; never repack or replace observations",
                "rawArchiveExists": (folder / "raw-evidence.tar.gz").is_file(),
                "retentionManifestArchiveIdentity": retention.get("retainedArchive") if retention else None,
                "rawArchiveHashRecomputedDuringPreparation": False,
                "sourceArtifact": retention.get("sourceArtifact") if retention else None,
                "retainedImportCount": stage.get("allImportCount") if stage else None,
                "frozenHarnessStatus": stage.get("frozenHarnessAnalysis", {}).get("status") if stage else None,
                "reportedJobConclusion": job.get("jobConclusion") if job else None,
                "independentAuditCompletedAndReproduced": independent.get("passed") if independent else None,
                "semanticReceiptsAgree": independent.get("semanticSummary", {}).get("allNormalizedCommonSemanticsEqual") if independent else None,
                "memoryCoverageQualified": independent.get("memorySummary", {}).get("everyObservationQualified") if independent else None,
                "memoryScreenPassed": independent.get("memorySummary", {}).get("passesProspectiveMemoryScreen") if independent else None,
                "issues": issues,
            }
            if retention and record["rawArchiveExists"]:
                record["observedArchiveBytes"] = (folder / "raw-evidence.tar.gz").stat().st_size
                if record["observedArchiveBytes"] != retention["retainedArchive"]["bytes"]:
                    issues.append("Raw archive size does not match its retention manifest")
            cell_records.append(record)
            if present:
                for path in sorted(folder.rglob("*")):
                    if path.is_file() and path.name != "raw-evidence.tar.gz" and "__pycache__" not in path.parts:
                        select(path)

    # Current paths are verified on disk; no pending outcomes are fabricated.
    for relative in [
        "prepare-phase2b-checkpoint.py", "summarize-import-experiments.py", "import-experiment-summary/RESULTS.json",
        "import-experiment-summary/RESULTS.md", "import-experiment-summary/DECISIONS.json",
        "jmdict-remaining-opportunities-synthesis.md", "jmdict-remaining-opportunities-synthesis.json",
        "jmdict-remaining-opportunities-ownership.json", "jmdict-cross-group-trace-review.json",
        "wide-hosted-qa.log", "wide-hosted-qa.json",
        "hosted-plans/wide-keyword-qualification-publication.json",
        "hosted-plans/wide-keyword-parallel-scheduling.json", "wide-qualification-prospective-review.json",
        "hosted-plans/wide-keyword-qualification.yml", "hosted-plans/minsize-qualification.yml",
        "hosted-plans/wide-keyword-source-qa.yml", "hosted-wide-parity-spec/publication.json",
        "hosted-wide-parity-spec/independent-review.json", "minsize-hosted-qa.json", "minsize-hosted-qa.log",
        "checkpoint-phase2a-publication-receipt.json", "archive-hosted-artifact.py", "analyze-hosted-cell.py",
        "audit-hosted-cell-semantics-memory.py", "audit-hosted-cell-semantics-memory-v2.py",
    ]:
        select(PROF / relative, required=True)
    for pattern in ["wide-hosted-qa.*", "wide-hosted-qa-log-writer.js", "audit-minsize-*", "audit-wide-*",
                    "jmdict-cross-group*"]:
        for path in sorted(PROF.glob(pattern)):
            if path.is_file() and path.suffix != ".pyc":
                select(path)

    # The diagnostic source was frozen after the first draft. Retain its
    # reviewed source/spec/policy history now; observations are a separate
    # pending owner scope and are not discovered or acquired by this script.
    diagnostic = read_json("jmdict-group-diagnostic/remote-publication.json")
    diagnostic_manifest = read_json("jmdict-group-diagnostic/publication-files.final.json")
    diagnostic_binding_issues = []
    diagnostic_source_records = []
    if diagnostic and diagnostic_manifest:
        directory = PROF / "jmdict-group-diagnostic"
        for path in sorted(directory.rglob("*")):
            in_policy_history = any(part.startswith("pre-acquisition-v") for part in path.relative_to(directory).parts[:-1])
            if (path.is_file() and not path.is_symlink() and "__pycache__" not in path.parts
                    and (path.parent == directory or in_policy_history)
                    and path.suffix in {".py", ".json", ".md", ".diff", ".patch", ".log"}):
                select(path)
        remote_blobs = {item["path"]: item["sha"] for item in diagnostic["files"]}
        for item in diagnostic_manifest["files"]:
            source = Path(item["localPath"])
            if not source.is_file() or source.is_symlink():
                missing.append({"path": str(source), "reason": "Frozen diagnostic source missing; recover by exact published commit/blob before seal"})
                continue
            actual = identity(source.read_bytes())
            if ((actual["bytes"], actual["sha256"], actual["gitBlobSha1"])
                    != (item["sizeBytes"], item["sha256"], item["gitBlob"])
                    or remote_blobs.get(item["path"]) != actual["gitBlobSha1"]):
                diagnostic_binding_issues.append({"path": item["path"], "reason": "Frozen source differs from prospective/remote publication identities"})
            member = "frozen-diagnostic-source/" + item["path"]
            record = {"path": member, "localPath": str(source), **actual,
                      "identityScope": "Exact published diagnostic source; re-read and rehash at checkpoint freeze",
                      "sourceCommit": diagnostic["publishedCommit"], "sourceTree": diagnostic["tree"],
                      "repositoryPath": item["path"], "performanceCandidate": False}
            proof_sources[member] = record
            diagnostic_source_records.append(record)

    summary_binding_issues = []
    summary = read_json("import-experiment-summary/RESULTS.json")
    if summary:
        for candidate in summary["candidates"].values():
            for cell in candidate["cells"]:
                for binding in cell.get("sourceBindings", []):
                    source = PROF / binding["path"]
                    select(source, required=True)
                    if source.is_file():
                        actual = identity(source.read_bytes())
                        if actual["bytes"] != binding["bytes"] or actual["sha256"] != binding["sha256"]:
                            summary_binding_issues.append({"path": binding["path"],
                                                           "reason": "Root-owned summary is not bound to the current input revision; do not regenerate it here"})

    parity = PROF / "hosted-wide-parity-result"
    parity_records = []
    if parity.is_dir():
        for path in sorted(parity.rglob("*")):
            if path.is_file() and not path.is_symlink() and "__pycache__" not in path.parts:
                data = path.read_bytes()
                parity_records.append({"path": "profiling/" + path.relative_to(PROF).as_posix(), **identity(data)})
                # Exact artifact/container decisions require the observed owner
                # receipt. Never classify a future ZIP as redundant by suffix.
                if path.suffix not in {".zip", ".gz", ".xz"}:
                    select(path)
    else:
        missing.append({"path": "profiling/hosted-wide-parity-result/",
                        "reason": "Confirmed future owner destination; no completed parity artifact/receipt yet exists"})

    layout = {
        "schemaVersion": 1, "preparedAtUtc": observed_at, "stage": "PREPARATION ONLY; NOT SEALED",
        "baseCommit": BASE, "proposedRepositoryDirectory": "dev/perf/import-optimization-9bb32/phase2b",
        "currentEvidenceBranchHead": phase2a_publication["commit"],
        "writeScope": "Only checkpoint-phase2b-preparation scaffolding; no archive copy, no outcome regeneration, no publication",
        "binaryPublicationPlan": {
            "cohortArchives": "Twelve unchanged raw archives, six minsize and six wide, as separate items",
            "proofArchive": "One small deterministic archive of new QA/parity outcomes, audits, metadata, scripts and synthesis; preserve empty/failure logs",
            "parityContainerDecision": "Pending inspection of actual original artifact and retention receipt; retain all raw evidence and any necessary original container",
        },
        "cells": cell_records,
        "newProofSourcesObserved": list(proof_sources.values()),
        "unchangedPriorMemberReferences": list(prior_references.values()),
        "parityResult": {"directory": "profiling/hosted-wide-parity-result", "exists": parity.is_dir(), "observedFiles": parity_records},
        "diagnosticSourceAndHistory": {
            "publication": diagnostic, "frozenSourceFiles": diagnostic_source_records,
            "acquisitionPayloadsIncluded": False,
            "scope": "Reviewed source/spec/policy history only. Three coordinator observations remain a separate pending scope and provide no relative-speed evidence.",
        },
        "priorCheckpoints": {
            "phase1": {"commit": prior_phase1["commit"], "repositoryDirectory": prior_phase1["repositoryDirectory"],
                       "archiveIdentity": prior_phase1["archive"], "archivePayloadCopied": False},
            "phase2a": {"commit": phase2a_publication["commit"], "tree": phase2a_publication["tree"],
                        "repositoryDirectory": "dev/perf/import-optimization-9bb32/phase2a",
                        "source": "profiling/checkpoint-phase2a-publication-receipt.json", "archivePayloadsCopied": False},
        },
        "finalAssemblyRequirements": [
            "Wait for every existing cohort job to finish or fail and retain every prescribed completed/failed observation without a retry or replacement",
            "Wait for explicit owners' frozen receipts and independent evidence audits; a reproduced failure is valid archival evidence",
            "Do not require memory qualification to pass for retention: preserve minsize VNDB AB's failed sampling coverage and null comparison metrics unchanged",
            "Wait for actual wide source-QA/actionlint and untimed parity results; failures must remain failures and do not authorize source or job fixes",
            "Resolve and verify all final original artifact identities, retained member maps, package omission records and source/run/fixture pins",
            "Rehash all final inputs and unchanged archive copies, generate byte/size/Git-blob inventories and deterministic proof metadata",
            "Use unpooled complete per-cell results from the root-owned summary; never infer a PR decision from an audit or correctness pass",
            "Independently audit the complete sealed file set before root publication; leave phase1 and phase2A unchanged",
        ],
    }
    readiness = {
        "preparedAtUtc": observed_at, "sealed": False, "readyToSeal": False,
        "reason": "Preparation requested only; pending outcomes and authoritative freeze confirmations remain",
        "expectedCohortArchives": 12,
        "observedCohortArchives": sum(c["rawArchiveExists"] for c in cell_records),
        "cohortsWithRequiredFilesPresent": sum(not c["missingRequiredFiles"] for c in cell_records),
        "cohortsWithReproducedIndependentAudit": sum(c["independentAuditCompletedAndReproduced"] is True for c in cell_records),
        "missingRequiredInputs": missing,
        "pinOrRetentionIssues": [{"candidate": c["candidate"], "cell": c["cell"], "issues": c["issues"]} for c in cell_records if c["issues"]],
        "summaryBindingIssues": summary_binding_issues,
        "diagnosticSourceBindingIssues": diagnostic_binding_issues,
        "observedMemoryQualificationFailures": [{"candidate": c["candidate"], "cell": c["cell"],
                                                  "memoryCoverageQualified": c["memoryCoverageQualified"],
                                                  "memoryScreenPassed": c["memoryScreenPassed"]}
                                                 for c in cell_records if c["memoryScreenPassed"] is False],
        "observedNewProofFiles": len(proof_sources), "priorMemberReferences": len(prior_references),
        "summariesWereNotRegenerated": True, "largeExistingArchivePayloadsCopied": False,
    }
    readme = """# Phase2B preparation — not sealed

This directory contains a discovery snapshot and proposed layout only. It does
not contain a publication archive. Re-running the preparation script refreshes
these draft manifests from the files that actually exist; it never imports a
dictionary, executes a test, regenerates a result summary, copies a raw archive,
or changes existing evidence.

The plan is twelve unchanged per-cell raw archives (six minsize, six wide), plus
one small deterministic proof archive for new outcomes, raw QA/parity evidence,
workflow/retention/audit records, root's summary script and outputs, and the three
remaining-opportunity synthesis files. Original phase1/phase2A archive payloads
will not be duplicated. Identical existing proof members are referenced by their
published archive/member identities instead. Current source/path hashes are
discovery metadata; every final input must be re-read and rehashed at freezing.

`READINESS.json` distinguishes missing outcomes from observed files and from
failed qualification. A successful independent audit can correctly reproduce a
failed memory-coverage gate. Such a failure must be retained, not screened out,
retried, or relabeled as a memory regression. No constant success assumption or
fixed completed-import count is used by this preparation tool.

Wide QA/actionlint log retrieval remains the priority. The future parity result
directory and wide cohort directories were confirmed by their owner, but are
explicitly marked pending until actual files arrive. Final parity-container
retention cannot be selected until the original artifact/receipt is inspected.

There is intentionally no sealing command here yet. After all existing cohorts
finish and their owners freeze independent audits, the final assembler should
consume this layout, verify every original/retained binding, preserve all failed
attempts, and use the already reviewed deterministic packing rules. An independent
byte/content audit remains required before root publishes anything. Phase1 and
phase2A are immutable.
"""
    OUT.mkdir(exist_ok=True)
    (OUT / "LAYOUT.json").write_bytes(encoded(layout))
    (OUT / "READINESS.json").write_bytes(encoded(readiness))
    (OUT / "README.md").write_text(readme)
    print(json.dumps({"directory": str(OUT), "sealed": False,
                      "observedCohortArchives": readiness["observedCohortArchives"],
                      "auditedCohorts": readiness["cohortsWithReproducedIndependentAudit"],
                      "missingInputs": len(missing), "pinIssues": len(readiness["pinOrRetentionIssues"]),
                      "newProofFiles": len(proof_sources), "priorReferences": len(prior_references)}, indent=2))


if __name__ == "__main__":
    main()
