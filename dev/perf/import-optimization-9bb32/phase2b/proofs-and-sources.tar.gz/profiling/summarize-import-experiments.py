#!/usr/bin/env python3
"""Project retained audit results into a small, non-pooled experiment summary.

This script does not acquire observations, rerun imports, change qualification
gates, remove outliers, or decide whether a candidate merits a pull request.
"""

from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BASE = "9e10d3b3fcf66d344ab31bc42c9b522fa5215da2"
REPOSITORY = "https://github.com/ManabiIO/manabitan"
CANDIDATES = {
    "fingerprint": {
        "label": "Canonical slot fingerprints",
        "commit": "178ee43328141693e88b90b4b518d483c87b2fac",
        "run": 46104243724,
    },
    "minsize": {
        "label": "Composite parser minsize",
        "commit": "2907ba1bad0958c22fe363f88d7cceb4d4bc604e",
        "run": 46104898097,
    },
    "wide": {
        "label": "Bounded wide keyword comparisons",
        "commit": "ebf4278afc59d83f191692bd587f0e1f7e8682b3",
        "run": 46112384728,
    },
}
CELLS = [f"{dictionary}-{order}" for dictionary in ("jmdict", "jitendex", "vndb") for order in ("AB", "BA")]


def bound_json(path):
    data = path.read_bytes()
    return json.loads(data), {
        "path": str(path.relative_to(ROOT)),
        "bytes": len(data),
        "sha256": sha256(data).hexdigest(),
    }


def summarize_cell(candidate, cell):
    directory = ROOT / "hosted-qualification" / candidate / cell
    analysis_path = directory / "audit-and-stage-analysis.json"
    if not analysis_path.exists():
        return {"cell": cell, "state": "no-retained-completed-cohort"}
    analysis, binding = bound_json(analysis_path)
    plan = analysis["plan"]
    assert plan["baseline"] == BASE
    assert plan["candidate"] == CANDIDATES[candidate]["commit"]
    assert f"{plan['dictionary']}-{plan['initialOrder']}" == cell
    assert analysis["artifact"]["runId"] == CANDIDATES[candidate]["run"]
    frozen = analysis["frozenHarnessAnalysis"]
    timing = frozen["candidateVsBaseline"]
    control = frozen["identicalCodeControl"]
    result = {
        "cell": cell,
        "state": "retained-completed-cohort",
        "sourceBindings": [binding],
        "jobUrl": f"{REPOSITORY}/actions/runs/{analysis['artifact']['runId']}/job/{analysis['artifact']['jobId']}",
        "allImportCount": analysis["allImportCount"],
        "candidatePairs": timing["count"],
        "medianPairedChangePercent": timing["medianPairedChangePercent"],
        "descriptiveBootstrap95Percent": timing["descriptiveBootstrap95Percent"],
        "equalWorkChangePercent": timing["equalWorkChangePercent"],
        "fasterPairs": timing["fasterPairs"],
        "controlMedianPairedChangePercent": control["medianPairedChangePercent"],
        "controlEqualWorkChangePercent": control["equalWorkChangePercent"],
        "frozenHarnessStatus": frozen["status"],
        "memoryPassed": frozen["memoryPassed"],
        "sourcePackageStageAuditReproduced": analysis["checksPassed"],
    }
    semantic_path = directory / "independent-semantics-memory-audit.json"
    if semantic_path.exists():
        semantic, binding = bound_json(semantic_path)
        assert semantic["sourcePins"] == {"A": BASE, "B": CANDIDATES[candidate]["commit"]}
        assert semantic["sourceArtifact"]["runId"] == CANDIDATES[candidate]["run"]
        assert semantic["sourceArtifact"]["jobId"] == analysis["artifact"]["jobId"]
        result["sourceBindings"].append(binding)
        result["independentAuditReproduced"] = semantic["passed"]
        result["semanticReceiptsEqual"] = semantic["semanticSummary"]["allNormalizedCommonSemanticsEqual"]
        result["memoryCoverageQualified"] = semantic["memorySummary"]["everyObservationQualified"]
        result["independentMemoryScreenPassed"] = semantic["memorySummary"]["passesProspectiveMemoryScreen"]
        result["rawMemoryScans"] = semantic["memorySummary"]["rawScanCount"]
        result["memoryCoverageFailures"] = [
            {key: slot[key] for key in ("name", "arm", "qualificationFailures", "maximumCoveredSampleGapMs")}
            for slot in semantic["memorySlots"] if not slot["qualifiedForWholeTreePss"]
        ]
    else:
        result["independentAuditReproduced"] = None
    return result


def percent(value):
    return f"{value:+.3f}%"


def main():
    result = {
        "asOfUtc": datetime.now(timezone.utc).isoformat(),
        "baselineCommit": BASE,
        "scope": "Projection of existing retained evidence only. Negative timing changes mean faster; positive changes mean slower. Cells remain independent; no host pooling, observation removal or new statistics.",
        "limitations": [
            "A reproduced audit or a correctness/memory pass does not establish a performance gain.",
            "Intervals are descriptive 95% paired bootstrap intervals from the frozen acquisition harness, not a new significance or promotion test.",
            "Browser semantic receipts cover counts, normalized storage, restart, twelve fixed lookup terms across six passes, and separate all-referenced-media checks; they are not exhaustive persisted-row equality.",
            "A failure of the frozen 250 ms memory-sampling coverage bound leaves memory comparison fields unqualified; it is not proof of increased memory use.",
            "Internal stage elapsed timers overlap and do not isolate CPU cost or prove the cause of a full-import difference.",
            "Wide candidate source QA and separate full-parser corpus parity are mandatory additional acceptance gates, outside this timing projection.",
        ],
        "candidates": {},
    }
    lines = [
        "# Manabitan import experiment results",
        "",
        f"Evidence projection as of `{result['asOfUtc']}`.",
        "",
        "Each row is a separate hosted cohort. Negative changes mean faster; positive changes mean slower. The paired median, interval, and equal-work total are copied from the frozen harness; hosts are not pooled. An audit pass is not a speedup claim.",
        "",
    ]
    for key, metadata in CANDIDATES.items():
        cells = [summarize_cell(key, cell) for cell in CELLS]
        result["candidates"][key] = {**metadata, "cells": cells}
        lines += [
            f"## {metadata['label']}",
            "",
            f"[Candidate source]({REPOSITORY}/commit/{metadata['commit']}) · [Complete workflow]({REPOSITORY}/actions/runs/{metadata['run']})",
            "",
            "| Dictionary / order | Paired median | Descriptive 95% interval | Equal-work total | Faster pairs | Identical-code control | Memory screen |",
            "|---|---:|---|---:|---:|---:|---|",
        ]
        for cell in cells:
            if cell["state"] != "retained-completed-cohort":
                lines.append(f"| {cell['cell']} | Pending retained cohort | — | — | — | — | — |")
                continue
            low, high = cell["descriptiveBootstrap95Percent"]
            memory = "Passed" if cell["memoryPassed"] else "Failed qualification"
            if cell.get("memoryCoverageQualified") is False:
                memory = "Sampling coverage failed"
            lines.append(
                f"| [{cell['cell']}]({cell['jobUrl']}) | {percent(cell['medianPairedChangePercent'])} | "
                f"{percent(low)} to {percent(high)} | {percent(cell['equalWorkChangePercent'])} | "
                f"{cell['fasterPairs']}/{cell['candidatePairs']} | {percent(cell['controlMedianPairedChangePercent'])} | {memory} |"
            )
        lines.append("")
    lines += ["## Evidence limits", ""] + [f"- {limit}" for limit in result["limitations"]]
    lines += [
        "",
        "This file is a mechanical projection, not a pull-request decision. The JSON companion binds every source report by path, byte length and SHA-256. Raw observations, failures and audit scripts are retained separately.",
        "",
    ]
    destination = ROOT / "import-experiment-summary"
    destination.mkdir(exist_ok=True)
    (destination / "RESULTS.json").write_text(json.dumps(result, indent=2) + "\n")
    (destination / "RESULTS.md").write_text("\n".join(lines))
    print(json.dumps({"directory": str(destination), "completedCells": sum(cell["state"] == "retained-completed-cohort" for value in result["candidates"].values() for cell in value["cells"]), "expectedCells": len(CANDIDATES) * len(CELLS)}, indent=2))


if __name__ == "__main__":
    main()
