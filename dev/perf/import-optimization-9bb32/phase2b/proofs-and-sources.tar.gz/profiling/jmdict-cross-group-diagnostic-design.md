# Design only: bind the existing ordered sink on one clock

**A small diagnostic overlay could resolve the missing logical identities without restructuring the pipeline.** It would not itself establish an optimization or measure saved CPU time. No implementation, acquisition, import, test, or publication is authorized by this note.

The [retained-trace review](jmdict-cross-group-trace-review.json) establishes that all twelve JMdict parser results reach the coordinator before later dedup and compression activity. It lacks application group IDs and promise-settlement evidence, so it cannot isolate a compression-only wait. This design addresses those missing observations on the exact baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.

## Minimal source scope

Use a diagnostic-only, coordinator-local collector and observation statements at existing boundaries in three files. Do not change a worker, message payload, queue, buffer owner, compression policy, promise dependency, or stored format. The frozen product candidates remain untouched. Any later diagnostic source must have its own exact source/package/overlay identity and must never be used as an ordinary performance arm.

| Event | Existing boundary | Meaning |
| --- | --- | --- |
| `group-ready` | `ParallelTermBankParserRun._runWorkerLoop`, immediately before resolving `_resultSlots[groupIndex]` | The coordinator has validated and accepted this exact group's result. |
| `sink-enter` | `_runPipeline`, immediately before the existing awaited `_onChunk` call | This exact group enters the ordered sink. |
| `dedup-begin`, `dedup-end` | Around the existing awaited `_resolveArtifactTermContentDedup` call | Brackets current resolution, including any actual async exact-match work. |
| `storage-ready`, `metadata-published` | After the existing reservation await and synchronous publication | Distinguishes available references/publication from durable content completion. |
| `record-start`, `record-done` | Before `_appendResolvedArtifactTermRecords` and at its successful bulk-import return after the existing record append await | Records the obligation joined by the sink, not a claimed disk flush or durable finalization. |
| `join-enter`, `join-settled` | Immediately around the existing `Promise.allSettled` join | Makes the current group's gate explicit without introducing a new promise. |
| `compression-done` | `_beginAppendSharedSpans` at the existing `completedAt` timestamp, after output validation and any existing fallback | Separates compression/envelope completion from content append. Reuse this timestamp. |
| `content-done` | Existing `measuredContentCompletion.then` callback | The current content persistence operation has fulfilled; this includes more than compression. |
| `sink-release` | After the existing callback cleanup and before advancing/waking the next lead window | The existing group lifetime ends and the ordered sink advances. |

Sources: [parser coordinator](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/term-bank-wasm-parser.js) (`_runPipeline` at2968; `_runWorkerLoop` at3076); [database](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/dictionary-database.js) (`_bulkAddArtifactTermsChunkWithContentDedup` at8375; `_appendResolvedArtifactTermRecords` at10131); [content block store](https://github.com/ManabiIO/manabitan/blob/9e10d3b3fcf66d344ab31bc42c9b522fa5215da2/ext/js/dictionary/term-content-block-store.js) (`_beginAppendSharedSpans`, compression body around795–880).

## Identity and observation mechanics

All events use the **coordinator's existing `safePerformance.now()` clock** and a monotonically increasing event sequence. Do not subtract worker clocks, `Date.now()`, or trace transport timestamps.

The parser already has authoritative `groupIndex`. At `sink-enter`, a diagnostic context records that scalar ID; current production permits only one ordered callback at a time. Database entry and the synchronously started block operation capture that ID locally before their first await. Later completion observations use the captured scalar, never the then-current global context. This avoids propagating a field through the importer's copied column payload, or retaining a chunk/buffer in the collector. Any nested sink, missing token, mismatched run generation, or unexpected second database admission makes the diagnostic inconclusive.

Use non-throwing observation statements and a fixed, preallocated scalar event buffer, sized prospectively from the twelve-group plan with an explicit small event ceiling. Store sequence, group ID, event code, time, and status; no per-row events, payload references, live stack capture, or console output. An overflow flag makes the diagnostic incomplete; never overwrite earlier events. Export the complete buffer only after the import's existing completion boundary. Record errors/cancellation as terminal status and retain incomplete output without treating absent events as success.

Observation statements belong in existing callbacks or immediately around existing awaits. Do not attach additional `.then` chains to measure completion, introduce new awaits, change exception handling, or move the current join. The successful JMdict shared-prefix route is the design's scope; another route or fallback must be labeled explicitly, not inferred equivalent.

## What the result could answer

For each group `i` before the last, inspect all events and require the same ordered, successful group lineage. A logical preparation opportunity exists only if group `i+1` is already `group-ready`, group `i` has completed metadata publication and record append, the current join is still active, and its compression has not yet completed. Its observed start is the latest of those readiness/publication/record/join events; its observed end is compression completion. Report every group, including zero or reversed intervals.

Also report the separate interval from compression completion to content completion, and the interval from both joined obligations completing to sink release. This prevents append work, callback scheduling, or importer cleanup from being labeled compression.

These are **coordinator-observed dependency intervals**. Callback timestamps are not the instant a worker finished; main-thread work, scheduling and garbage collection may delay observation. An interval is not free CPU capacity, disk-service time, a performance lower bound, or time an implementation would save. A retained native trace could annotate coordinator activity within the same intervals, but cannot replace the explicit logical events.

## Prospective stop conditions

Missing/duplicate identities, overflow, non-admitted routes, errors, or incomplete groups make the diagnostic inconclusive. If all groups lack the stated interval, this trace does not support the held overlap hypothesis. If repeated intervals exist, the result supports only a separate design review of bounded next-group preparation; reservation lifetime, rollback/drain behavior, retained memory and full-import qualification remain unresolved. Do not tune group bounds, thresholds, worker counts, or candidate selection within the diagnostic.

This design is narrow enough to be considered separately, but **no new runtime acquisition or broad pipeline candidate is recommended or started here**. The completed-evidence audits remain the priority.
