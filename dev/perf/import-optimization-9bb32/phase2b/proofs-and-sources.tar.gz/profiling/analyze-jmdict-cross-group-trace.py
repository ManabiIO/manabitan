#!/usr/bin/env python3
"""Read existing trace ordering only; never run product or infer saved latency."""
from pathlib import Path
import collections
import hashlib
import json

ROOT = Path('/workspace/scratch/9bb32f82fa3b')
TRACE = ROOT / 'profiling/hosted-baseline-jmdict/trace/run-1.trace.json'
OUTPUT = ROOT / 'profiling/jmdict-cross-group-trace-review.json'
if OUTPUT.exists():
    raise SystemExit('Refusing to overwrite retained trace review')
raw = TRACE.read_bytes()
events = json.loads(raw)['traceEvents']
ORIGIN = 193784952
COORDINATOR = 3450
PROFILE = (3427, '0x4')


def identity(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def key(event):
    return (event['pid'], event.get('id', str(event.get('id2'))))


handles = {}
for event in events:
    data = event.get('args', {}).get('data', {})
    if event.get('name') == 'HandlePostMessage' and event.get('ph') == 'X' and 'traceId' in data:
        assert data['traceId'] not in handles
        handles[data['traceId']] = event

roles = {
    ('term-bank-wasm-parser.js', 3635): 'parser-initialize-request',
    ('term-bank-wasm-parser.js', 3797): 'parser-parse-request',
    ('term-bank-wasm-parser-worker.js', 65): 'parser-ready-response',
    ('term-bank-wasm-parser-worker.js', 230): 'parser-result-response',
    ('zstd-term-content.js', 386): 'compression-request',
    ('zstd-term-content-compression-worker.js', 68): 'compression-source-consumed-response',
    ('zstd-term-content-compression-worker.js', 86): 'compression-result-response',
}
messages = []
unmatched = []
schemas = collections.Counter()
for event in sorted(events, key=lambda e: e['ts']):
    if event.get('name') != 'SchedulePostMessage' or event.get('ph') != 'I':
        continue
    data = event.get('args', {}).get('data', {})
    schemas[tuple(sorted(data))] += 1
    stack = data.get('stackTrace', [])
    if not stack:
        continue
    frame = stack[0]
    role = roles.get((frame.get('url', '').split('/')[-1], frame.get('lineNumber')))
    if role is None:
        continue
    handle = handles.get(data.get('traceId'))
    if handle is None:
        unmatched.append(data.get('traceId'))
        continue
    messages.append({'role': role, 'traceId': data['traceId'], 'sourceTid': event['tid'],
                     'destinationTid': handle['tid'], 'sourceTsUs': event['ts'],
                     'handleStartTsUs': handle['ts'], 'handleEndTsUs': handle['ts'] + handle['dur'],
                     'sourceMsFromInputChange': (event['ts'] - ORIGIN) / 1000,
                     'handleMsFromInputChange': (handle['ts'] - ORIGIN) / 1000,
                     'stackFrame': frame})

counts = collections.Counter(m['role'] for m in messages)
assert counts['parser-parse-request'] == counts['parser-result-response'] == 12
assert counts['parser-initialize-request'] == counts['parser-ready-response'] == 3
assert counts['compression-request'] == counts['compression-source-consumed-response'] == counts['compression-result-response'] == 103
assert not unmatched
parser_results = [m for m in messages if m['role'] == 'parser-result-response']
assert {m['destinationTid'] for m in parser_results} == {COORDINATOR}
last_result = max(m['handleEndTsUs'] for m in parser_results)

# ProfileChunk.tid is the profiler-emission thread, not the sampled thread.
# Map through Profile(pid,id), preserving signed deltas and their jitter.
profile_threads, cursors, nodes = {}, {}, {}
for event in events:
    if event.get('name') == 'Profile':
        profile_threads[key(event)] = event['tid']
        cursors[key(event)] = event['args']['data']['startTime']
assert profile_threads[PROFILE] == COORDINATOR
samples = []
negative_deltas = 0
for event in sorted(events, key=lambda e: e['ts']):
    if event.get('name') != 'ProfileChunk':
        continue
    profile_key = key(event)
    data = event.get('args', {}).get('data', {})
    profile = data.get('cpuProfile', {})
    for node in profile.get('nodes', []):
        nodes[(profile_key, node['id'])] = node
    assert len(profile.get('samples', [])) == len(data.get('timeDeltas', []))
    for node_id, delta in zip(profile.get('samples', []), data.get('timeDeltas', [])):
        previous = cursors[profile_key]
        cursors[profile_key] += delta
        if profile_key != PROFILE:
            continue
        negative_deltas += delta < 0
        stack = []
        seen = set()
        while (profile_key, node_id) in nodes:
            assert node_id not in seen
            seen.add(node_id)
            node = nodes[(profile_key, node_id)]
            stack.append(node.get('callFrame', {}))
            node_id = node.get('parent')
        samples.append({'previousTsUs': previous, 'sampleTsUs': cursors[profile_key],
                        'signedDeltaUs': delta, 'stack': stack})

canonical = [s for s in samples if any(f.get('functionName') == '_scan' and f.get('url', '').endswith('/term-content-canonical-scan.js') for f in s['stack'])]
late_canonical = [s for s in canonical if last_result < s['sampleTsUs'] < ORIGIN + 1082700]
assert late_canonical
late_compression = [m for m in messages if m['role'] == 'compression-result-response' and m['handleStartTsUs'] > last_result]
assert late_compression

source_paths = [
    'ext/js/dictionary/term-bank-wasm-parser.js',
    'ext/js/dictionary/term-bank-wasm-parser-worker.js',
    'ext/js/dictionary/zstd-term-content.js',
    'ext/js/dictionary/zstd-term-content-compression-worker.js',
    'ext/js/dictionary/dictionary-database.js',
    'ext/js/dictionary/term-content-canonical-scan.js',
]
result = {
    'scope': 'Bounded read-only analysis of retained JMdict trace; no acquisition, imports, tests, compiler or product mutation.',
    'baselineCommit': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2',
    'trace': identity(TRACE), 'script': identity(Path(__file__)),
    'report': identity(ROOT / 'profiling/hosted-baseline-jmdict/trace/run-1.json'),
    'sourceFiles': [identity(ROOT / 'baseline' / p) for p in source_paths],
    'eventCount': len(events),
    'inputChangeEventTsUs': ORIGIN,
    'inputChangeEventPresent': any(e.get('name') == 'EventDispatch' and e['ts'] == ORIGIN and e.get('args', {}).get('data', {}).get('type') == 'change' for e in events),
    'windowCaution': 'The report duration1082.7ms only bounds selection approximately from the input-change event. It is not a critical-path measurement.',
    'profileMapping': {'pid': PROFILE[0], 'profileId': PROFILE[1], 'sampledTid': COORDINATOR, 'negativeCoordinatorSampleDeltas': negative_deltas},
    'messageCountsByRole': dict(counts),
    'roleEvidence': 'Exact frozen-source postMessage stack locations distinguish parser request/result, ready, and compression source-consumed/result messages. Pairing uses traceId to the corresponding HandlePostMessage X event. No payload IDs are recorded.',
    'parserMessages': [m for m in messages if m['role'].startswith('parser-')],
    'lastParserResultHandlerEndTsUs': last_result,
    'lastParserResultHandlerEndMsFromInputChange': (last_result - ORIGIN) / 1000,
    'laterCanonicalEvidence': {'samples': len(late_canonical),
        'firstSampleTsUs': min(s['sampleTsUs'] for s in late_canonical),
        'lastSampleTsUs': max(s['sampleTsUs'] for s in late_canonical),
        'firstSampleStack': late_canonical[0]['stack'],
        'interpretation': 'All12 successful parser-result handlers have run before these later canonical-scan samples. This establishes a late parsed-result backlog under the successful source protocol, not the identity or timing of each remaining group.'},
    'laterCompressionEvidence': {'resultMessages': len(late_compression),
        'firstHandleTsUs': min(m['handleStartTsUs'] for m in late_compression),
        'lastHandleTsUs': max(m['handleStartTsUs'] for m in late_compression),
        'interpretation': 'Compression results continue after all parser results arrive. This does not establish that record persistence has settled or that the coordinator is blocked only on compression.'},
    'negativeMessageTimestampOffsets': [{'role': m['role'], 'traceId': m['traceId'], 'handleMinusSourceUs': m['handleStartTsUs'] - m['sourceTsUs']} for m in messages if m['handleStartTsUs'] < m['sourceTsUs']],
    'recordedScheduleDataSchemas': [{'keys': list(k), 'count': v} for k, v in schemas.items()],
    'missingIdentity': ['application groupIndex / parser request id in trace payload', 'compression block id and group ownership in trace payload', 'ordered onChunk begin/end spans', 'record-append promise settlement', 'content persistence promise settlement'],
    'sourceJoin': {'path': source_paths[4], 'function': '_bulkAddArtifactTermsChunkWithContentDedup', 'behavior': 'Promise.allSettled joins measuredContentCompletion and pendingRecordAppend before the ordered sink advances.'},
    'conclusion': 'The retained trace supports late ready parser results coexisting with later compression and database work. It neither establishes nor rules out a bounded interval waiting solely for compression. No removable duration or new runtime candidate is justified.',
    'compressionOnlyGapEstablished': False,
    'compressionOnlyGapRuledOut': False,
    'criticalPathDurationClaimMs': None,
    'newRuntimeRecommended': False,
    'limitations': ['Source-labelled messages identify roles and paired transport events, not JavaScript promise dependencies.', 'Source loading awaits occur before parser dispatch, so global dispatch ordinal must not be substituted for actual groupIndex.', 'Per-worker FIFO is compatible with the source but does not recover missing cross-worker group IDs.', 'Profile samples show activity; idle samples do not identify the pending promise or prove an exclusively compression-bound wait.', 'Signed sample deltas and several cross-thread send/handle timestamp inversions remain unchanged; no fine timing is manufactured by clamping or reordering them.'],
    'setupNotes': ['An initial exploratory event count assumed every HandlePostMessage had args.data and stopped at KeyError:data; flow-only s/f events have no such payload. The saved script explicitly selects complete X handlers and leaves the original trace untouched.', 'Exploratory stack listing was reduced to compact role/order evidence here; no product process or acquisition was run.'],
}
assert result['inputChangeEventPresent']
OUTPUT.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['eventCount', 'messageCountsByRole', 'lastParserResultHandlerEndMsFromInputChange', 'laterCompressionEvidence', 'compressionOnlyGapEstablished', 'compressionOnlyGapRuledOut', 'criticalPathDurationClaimMs']}, indent=2))
print('later canonical samples', len(late_canonical), 'first/last relative ms',
      (min(s['sampleTsUs'] for s in late_canonical) - ORIGIN) / 1000,
      (max(s['sampleTsUs'] for s in late_canonical) - ORIGIN) / 1000)
