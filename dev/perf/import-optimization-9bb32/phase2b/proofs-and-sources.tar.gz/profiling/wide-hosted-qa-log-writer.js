// Code-mode orchestration helper. Define this function in functions.exec and pass the raw connector string.
// Does not run on its own. No product test/build/import is executed; only bounded byte I/O.
async function writeConnectorRawLog(log, path, tools) {
  if (typeof log !== "string" || !path.startsWith("/workspace/scratch/9bb32f82fa3b/profiling/wide-hosted-qa.")) {
    throw new Error("Unexpected raw log input or destination");
  }
  const quote = (s) => "'" + s.replace(/'/g, "'\\''") + "'";
  const utf8Bytes = (s) => {
    let n=0;
    for (const c of s) {const p=c.codePointAt(0);n+=p<0x80?1:p<0x800?2:p<0x10000?3:4;}
    return n;
  };
  const pyChunk = [
    "import json,sys",
    "from pathlib import Path",
    "p=Path(sys.argv[1]); chunk=json.loads(sys.argv[2]); start=int(sys.argv[3]); mode=sys.argv[4]",
    "data=chunk.encode('utf-8')",
    "assert not p.is_symlink()",
    "assert mode=='xb' or (p.is_file() and p.stat().st_size==start)",
    "with p.open(mode) as f:",
    "    written=f.write(data); assert written==len(data)",
    "with p.open('rb') as f:",
    "    f.seek(start); reread=f.read(len(data)); tail=f.read(1)",
    "assert reread==data and tail==b'' and p.stat().st_size==start+len(data)",
    "print(json.dumps({'text':reread.decode('utf-8'),'bytes':len(data),'start':start,'totalBytes':p.stat().st_size},ensure_ascii=False))"
  ].join("\n");
  let at=0, offset=0;
  const chunks=[];
  do {
    let end=Math.min(at+16384,log.length);
    let payload;
    for (;;) {
      if (end>at && end<log.length && log.charCodeAt(end-1)>=0xd800 && log.charCodeAt(end-1)<=0xdbff) --end;
      payload=JSON.stringify(log.slice(at,end));
      if (utf8Bytes(payload)<=16000) break;
      end=at+Math.floor((end-at)/2);
    }
    const chunk=log.slice(at,end);
    const command=["python3","-c",quote(pyChunk),quote(path),quote(payload),String(offset),quote(chunks.length===0?"xb":"ab")].join(" ");
    const result=await tools.exec_command({cmd:command,workdir:"/workspace/scratch/9bb32f82fa3b",max_output_tokens:20000,yield_time_ms:1000});
    if(result.exit_code!==0 || result.session_id) throw new Error("Raw log chunk process failed: "+JSON.stringify({index:chunks.length,result}));
    const received=JSON.parse(result.output);
    if(received.text!==chunk || received.start!==offset || received.bytes!==utf8Bytes(chunk) || received.totalBytes!==offset+received.bytes) {
      throw new Error("Raw log chunk readback mismatch at "+at);
    }
    chunks.push({index:chunks.length,startUtf16:at,endUtf16:end,startByte:offset,bytes:received.bytes,readbackEqual:true});
    at=end;offset=received.totalBytes;
  } while(at<log.length);
  const pyFinal=[
    "from pathlib import Path",
    "import json,sys,hashlib",
    "p=Path(sys.argv[1]); b=p.read_bytes(); s=b.decode('utf-8')",
    "print(json.dumps({'path':str(p),'bytes':len(b),'characters':len(s),'newlines':s.count(chr(10)),'sha256':hashlib.sha256(b).hexdigest(),'gitBlobSha1':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\\0'+b).hexdigest()}))"
  ].join("\n");
  const final=await tools.exec_command({cmd:["python3","-c",quote(pyFinal),quote(path)].join(" "),workdir:"/workspace/scratch/9bb32f82fa3b",max_output_tokens:1000});
  if(final.exit_code!==0) throw new Error("Final raw log verification failed");
  const result=JSON.parse(final.output);
  let characters=0,newlines=0;
  for(const c of log){++characters;if(c==="\n")++newlines;}
  if(result.bytes!==offset || result.bytes!==utf8Bytes(log) || result.characters!==characters || result.newlines!==newlines) throw new Error("Final raw log totals differ");
  return {...result,allChunksReadbackEqual:true,chunkCount:chunks.length,chunks,normalization:"none; decoded connector string preserved exactly as UTF-8, including NUL/CR/LF",exclusiveFirstWrite:true,surrogateBoundariesPreserved:true};
}

