#!/usr/bin/env python3
"""Pin the completed minsize VNDB BA cell and use the unchanged v2 auditor."""
from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parent.parent
BASELINE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CANDIDATE = '2907ba1bad0958c22fe363f88d7cceb4d4bc604e'
WORKFLOW = '0c2a8a75cd0322cc13348b977a7e915b555d5a88'
RUN = 46104898097
BASELINE_PARSER = '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee'
CANDIDATE_PARSER = '363136045b400ea9bab953cb7b52febaedd23b4d1e3b666cde3d4df859b72ff0'
PACKAGE_ENTRIES = ['js/dictionary/wasm/term-bank-parser.c', 'lib/term-bank-parser.wasm']
AUDITOR = ROOT / 'profiling/audit-hosted-cell-semantics-memory-v2.py'
AUDITOR_SHA = '6b2d688e79c4f97c3f04729fed534c4abf731c6489f5fad098bd4ed37ba0101a'
ARCHIVE_SHA = '9f94a4d05c04f2d0e3827ce4bd7bb84b98e8b371ec90abecddcd798d3d0abe0e'
cell = Path(sys.argv[1]).resolve()
checks = {}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def require(name, condition):
    checks[name] = bool(condition)
    if not condition:
        raise RuntimeError(name)

require('fixed_completed_cohort', cell == ROOT / 'profiling/hosted-qualification/minsize/vndb-BA')
gate_path = cell / 'independent-identity-preflight.json'
audit_path = cell / 'independent-semantics-memory-audit.json'
log_path = cell / 'independent-audit-run.log'
require('no_previous_audit_overwrite', not any(p.exists() for p in [gate_path, audit_path, log_path]))
report = {
    'scope': 'Fixed source/artifact identity gate for completed minsize VNDB BA plus unchanged v2 semantic and raw-memory audit. Cell gate success does not qualify another cell or promote the candidate. No acquisition, imports, timing, product edits, policy changes or retries.',
    'auditReproducedCorrectly': None, 'cellCorrectnessMemoryQualified': None,
    'status': 'started', 'cell': str(cell.relative_to(ROOT)),
    'pins': {'baseline': BASELINE, 'candidate': CANDIDATE, 'workflow': WORKFLOW, 'run': RUN,
             'baselineParserSha256': BASELINE_PARSER, 'candidateParserSha256': CANDIDATE_PARSER,
             'expectedPackageEntries': PACKAGE_ENTRIES},
    'wrapperSha256': sha(Path(__file__).read_bytes()),
    'auditor': {'path': str(AUDITOR.relative_to(ROOT)), 'sha256': AUDITOR_SHA, 'modified': False},
    'checks': checks,
}

def write_report():
    gate_path.write_text(json.dumps(report, indent=2) + '\n')

try:
    require('auditor_bytes_frozen', sha(AUDITOR.read_bytes()) == AUDITOR_SHA)
    retention_path = cell / 'retention-manifest.json'
    metadata_path = cell / 'github-artifact.json'
    retention = json.loads(retention_path.read_text())
    metadata = json.loads(metadata_path.read_text())
    archive_path = cell / 'raw-evidence.tar.gz'
    archive_sha = sha(archive_path.read_bytes())
    require('archive_identity', archive_sha == retention['retainedArchive']['sha256'] == ARCHIVE_SHA and archive_path.stat().st_size == retention['retainedArchive']['bytes'])
    report['inputs'] = {'archiveSha256': archive_sha, 'retentionSha256': sha(retention_path.read_bytes()), 'githubMetadataSha256': sha(metadata_path.read_bytes())}
    original = retention['sourceArtifact']
    require('fixed_run', original['runId'] == metadata['workflow_run']['id'] == RUN)
    require('fixed_artifact_and_job', original['id'] == 15251027300 and original['jobId'] == 140855328461)
    require('fixed_workflow', metadata['workflow_run']['head_sha'] == WORKFLOW)
    require('artifact_metadata_binding', original['id'] == metadata['id'] and original['bytes'] == metadata['size_in_bytes'] and metadata['digest'] == 'sha256:' + original['sha256'])
    selected = {}
    with tarfile.open(archive_path, 'r:gz') as archive:
        for name in ['registered-plan.json', 'source-identities.json', 'derived-package-audit.json', 'analysis.json']:
            member = archive.getmember(name)
            data = archive.extractfile(member).read()
            bound = {**retention['included'], **retention['derived']}[name]
            require('member_binding:' + name, member.isfile() and len(data) == bound['bytes'] and sha(data) == bound['sha256'])
            selected[name] = json.loads(data)
    plan = selected['registered-plan.json']
    identities = selected['source-identities.json']
    packages = selected['derived-package-audit.json']
    require('dictionary_scope', plan['dictionary'] == 'vndb')
    require('fixed_sah_policy', plan['vndbSahAllocationPolicy'] == {'origin': 'explicit', 'rangeUnits': [37, 37], 'unitBytes': 4096})
    require('fixed_empty_flags', plan['flags'] == {})
    require('cell_name', cell.name == plan['dictionary'] + '-' + plan['initialOrder'] and plan['initialOrder'] in ['AB', 'BA'])
    require('fixed_plan_sources', plan['baseline'] == BASELINE and plan['candidate'] == CANDIDATE)
    require('fixed_arm_sources', identities['arms']['A']['sha'] == BASELINE and identities['arms']['B']['sha'] == CANDIDATE)
    require('fixed_prospective_package_changes', sorted(plan['expectedPackageEntries']) == PACKAGE_ENTRIES)
    require('fixed_actual_package_changes', sorted(identities['changedPackageEntries']) == PACKAGE_ENTRIES == sorted(packages['changedPackageEntries']))
    require('retained_package_byte_audit_passed', packages['passes'] is True)
    for arm, source, parser in [('A', BASELINE, BASELINE_PARSER), ('B', CANDIDATE, CANDIDATE_PARSER)]:
        require('fixed_parser_member:' + arm, identities['arms'][arm]['entries']['lib/term-bank-parser.wasm'] == parser)
        require('fixed_derived_source:' + arm, packages['arms'][arm]['sourceSha'] == source)
        require('derived_package_identity:' + arm, packages['arms'][arm]['entries'] == identities['arms'][arm]['entries'] and packages['arms'][arm]['packageSha256'] == identities['arms'][arm]['packageSha256'])
    require('retained_passing_outcome', selected['analysis.json']['status'] == 'correctness-memory-passed' and selected['analysis.json']['memoryPassed'] is True)
    report['status'] = 'identity-passed-running-unchanged-auditor'
    report['command'] = [sys.executable, str(AUDITOR), str(cell)]
    write_report()
    with log_path.open('wb') as log:
        completed = subprocess.run(report['command'], cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    report['auditorExitCode'] = completed.returncode
    require('audit_process_success', completed.returncode == 0)
    audited = json.loads(audit_path.read_text())
    require('semantic_and_memory_audit_passed', audited['passed'] is True and not audited['failedChecks'])
    require('audit_binds_fixed_sources', audited['sourcePins'] == {'A': BASELINE, 'B': CANDIDATE})
    require('audit_binds_archive_and_auditor', audited['archiveSha256'] == archive_sha and audited['auditScriptSha256'] == AUDITOR_SHA)
    require('audit_binds_package_set', audited['packageSummary']['exactChangedEntries'] == PACKAGE_ENTRIES)
    require('auditor_remains_frozen', sha(AUDITOR.read_bytes()) == AUDITOR_SHA)
    memory = audited['memorySummary']
    require('memory_coverage_and_screen_pass', memory['everyObservationQualified'] is True and memory['passesProspectiveMemoryScreen'] is True and memory['rawScanCount'] == 598)
    require('four_qualified_slots', len(audited['memorySlots']) == 4 and all(s['benchmarkExitCode'] == 0 and s['qualifiedForWholeTreePss'] is True and not s['qualificationFailures'] and s['maximumCoveredSampleGapMs'] <= 250 for s in audited['memorySlots']))
    require('all_semantic_receipts_agree', audited['semanticSummary']['observations'] == 42 and audited['semanticSummary']['allNormalizedCommonSemanticsEqual'] is True and audited['semanticSummary']['allMediaArmCount'] == 2)
    report['auditReproducedCorrectly'] = True
    report['cellCorrectnessMemoryQualified'] = True
    report['semanticMemoryReceiptSha256'] = sha(audit_path.read_bytes())
    report['auditLogSha256'] = sha(log_path.read_bytes())
    report['status'] = 'passed'
    report['checkCount'] = len(checks)
    write_report()
    print(json.dumps({'cell': report['cell'], 'status': report['status'], 'checks': len(checks), 'semanticMemoryReceiptSha256': report['semanticMemoryReceiptSha256'], 'identityReceiptSha256': sha(gate_path.read_bytes()), 'auditReproducedCorrectly': True, 'cellCorrectnessMemoryQualified': True}))
except Exception as error:
    report['status'] = 'audit-failed-no-retry'
    report['auditReproducedCorrectly'] = False
    report['failure'] = {'type': type(error).__name__, 'message': str(error)}
    report['checkCount'] = len(checks)
    write_report()
    raise
