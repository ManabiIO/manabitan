"""Read-only binary and assembly comparison of the single scratch variant."""
from collections import Counter
from pathlib import Path
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained_wasm_reader', ROOT / 'profiling/minsize-causal-phase2/analyze.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)


def sections(path):
    data = path.read_bytes()
    pos = 8
    result = {}
    while pos < len(data):
        section = data[pos]
        size, pos = reader.leb(data, pos + 1)
        result[section] = data[pos:pos + size]
        pos += size
    assert pos == len(data)
    return result


def bodies(sections_):
    data = sections_[10]
    count, pos = reader.leb(data, 0)
    result = []
    for _ in range(count):
        size, pos = reader.leb(data, pos)
        result.append(data[pos:pos + size])
        pos += size
    assert pos == len(data)
    return result


def assembly_metrics(path, name, body):
    lines = path.read_text().splitlines()
    start = next(i for i, line in enumerate(lines) if line.startswith(name + ':'))
    end = next(i for i in range(start + 1, len(lines)) if lines[i].strip() == 'end_function')
    entries = []
    for i in range(start, end + 1):
        line = lines[i].strip()
        if line and not line.startswith(('#', '.', name + ':')):
            opcode = line.split()[0]
            entries.append({'line': i + 1, 'asmOpcode': opcode, 'opcode': 'end' if opcode.startswith('end_') else 'select' if opcode == 'i32.select' else opcode})
    locals_, declaration_bytes, decoded = reader.decode(body)
    assert len(entries) == len(decoded)
    for entry, decoded_entry in zip(entries, decoded):
        assert entry['opcode'] == decoded_entry['opcode'], (entry, decoded_entry)
        entry.update(decoded_entry)
    before_loop = entries[:next(i for i, entry in enumerate(entries) if entry['opcode'] == 'loop')]
    bases = []
    for i in range(len(before_loop) - 3):
        part = before_loop[i:i + 4]
        if [v['opcode'] for v in part] == ['local.get', 'i32.const', 'i32.add', 'local.set'] and part[0]['args'] == [0]:
            bases.append({'line': part[0]['line'], 'srcOffset': part[1]['args'][0], 'local': part[3]['args'][0]})
    return {
        'asmLines': [start + 1, end + 1], 'bodyBytes': len(body),
        'bodySha256': hashlib.sha256(body).hexdigest(),
        'locals': dict(locals_), 'localsTotal': sum(locals_.values()),
        'localDeclarationBytes': declaration_bytes,
        'assemblyOpcodeSequenceMatchesWasm': True,
        'instructionCount': len(entries),
        'opcodeCounts': dict(sorted(Counter(v['asmOpcode'] for v in entries).items())),
        'prologueSourceBases': bases,
        'branchTables': [{'line': v['line'], 'bytes': v['bytes'], 'targetsIncludingDefault': len(v['args'])} for v in entries if v['opcode'] == 'br_table'],
    }


baseline_wasm = ROOT / 'manabitan/dev/data/dictionary-wasm/term-bank-parser.wasm'
candidate_wasm = OUT / 'term-bank-parser-wide.wasm'
baseline_asm = ROOT / 'profiling/parser-symbol-map/baseline.s'
candidate_asm = OUT / 'term-bank-parser.s'
old_sections, new_sections = sections(baseline_wasm), sections(candidate_wasm)
old_bodies, new_bodies = bodies(old_sections), bodies(new_sections)
names = json.loads((ROOT / 'profiling/parser-symbol-map/symbol-map.json').read_text())['functionNames']
assert len(old_bodies) == len(new_bodies)
changed = [i for i, (old, new) in enumerate(zip(old_bodies, new_bodies)) if old != new]
assert changed == [11, 13], changed
assert all(old_sections.get(i) == new_sections.get(i) for i in old_sections.keys() | new_sections.keys() if i != 10)
result = {
    'method': 'No runtime execution or timing. Compare every retained Wasm section/body; align each assembly opcode to decoded body11/body13. Source and first failed driver command remain unchanged.',
    'inputs': [reader.identity(path) for path in (baseline_wasm, candidate_wasm, baseline_asm, candidate_asm, OUT / 'term-bank-parser.c', OUT / 'candidate.patch')],
    'onlyCodeSectionChanges': True, 'unchangedFunctions': len(old_bodies) - len(changed),
    'sections': [{'id': i, 'identical': old_sections.get(i) == new_sections.get(i), 'baselineBytes': len(old_sections.get(i, b'')), 'candidateBytes': len(new_sections.get(i, b''))} for i in sorted(old_sections.keys() | new_sections.keys())],
    'functions': [
        {'index': i, 'name': names[str(i)], 'baseline': assembly_metrics(baseline_asm, names[str(i)], old_bodies[i]), 'candidate': assembly_metrics(candidate_asm, names[str(i)], new_bodies[i])}
        for i in changed
    ],
    'compiledBounds': {
        'project_glossary_image_value': {'initialLogicalLengthCheckAsmLines': [7613, 7619], 'firstByteCheckAsmLines': [7622, 7635], 'fullLiteralLengthCheckAsmLines': [7637, 7642], 'closingQuoteCheckAsmLines': [7644, 7650], 'wideLoadsAsmLines': [7654, 7663, 7671], 'escapedFallbackCallAsmLine': 7687},
        'parse_composite_span_impl': {'initialLogicalLengthCheckAsmLines': [28261, 28267], 'firstByteCheckAsmLines': [28270, 28280], 'fullLiteralLengthCheckAsmLines': [28282, 28287], 'closingQuoteCheckAsmLines': [28289, 28295], 'wideLoadsAsmLines': [28299, 28308, 28316], 'escapedFallbackCallAsmLine': 28334},
        'interpretation': 'The end-start<2 guard dominates the initial source-byte read. The end-start-2<18 test and quote-at-start+19 check dominate the two unaligned i64 loads at start+1/start+9 and unaligned16-bit load at start+17. Either a leading escape or any length/quote/word mismatch takes the original escaped decoder. No function signature, scratch allocation, export, data section, or global layout changed.',
    },
}
(OUT / 'static-comparison.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'onlyCodeSectionChanges': True, 'unchangedFunctions': result['unchangedFunctions'], 'functions': [{'index': f['index'], 'name': f['name'], 'bodyBytes': [f['baseline']['bodyBytes'], f['candidate']['bodyBytes']], 'locals': [f['baseline']['localsTotal'], f['candidate']['localsTotal']], 'loops': [f['baseline']['opcodeCounts']['loop'], f['candidate']['opcodeCounts']['loop']]} for f in result['functions']]}, indent=2))
