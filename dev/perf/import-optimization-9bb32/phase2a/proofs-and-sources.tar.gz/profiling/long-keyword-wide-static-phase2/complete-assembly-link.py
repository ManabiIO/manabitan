"""Complete the retained first C compilation after the relocated -cc1as wrapper failure."""
from pathlib import Path
import hashlib
import json
import shlex
import subprocess

OUT = Path(__file__).resolve().parent
toolchain = Path('/tmp/manabitan-native-9bb32/native-toolchain')
attempt = json.loads((OUT / 'compile-attempt.json').read_text())
receipt_path = OUT / 'assembly-link-completion.json'
if receipt_path.exists():
    raise SystemExit('Completion already recorded; no automatic retries.')
plan_command = attempt['arguments'] + ['-###']
plan = subprocess.run(plan_command, cwd=OUT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(OUT / 'completion-driver-plan.stdout.log').write_bytes(plan.stdout)
(OUT / 'completion-driver-plan.stderr.log').write_bytes(plan.stderr)
assert plan.returncode == 0, 'Driver plan failed'
commands = []
for line in plan.stderr.decode().splitlines():
    if not line.lstrip().startswith('"'):
        continue
    args = shlex.split(line)
    if len(args) > 1 and args[1] == '-cc1as':
        commands.append([str(toolchain / 'lib/ld-linux-x86-64.so.2'), '--argv0', str(toolchain / 'bin/clang'), '--library-path', str(toolchain / 'lib'), str(toolchain / 'bin/clang-real'), *args[1:]])
    elif Path(args[0]).name == 'wasm-ld':
        commands.append(args)
assert len(commands) == 3 and all('-cc1as' in args for args in commands[:2]) and Path(commands[-1][0]).name == 'wasm-ld'
receipt = {
    'authorization': 'Root authorized assembly/link completion of the already optimized retained outputs, without source or optimization changes.',
    'originalFailedCompilePreserved': str(OUT / 'compile-attempt.json'),
    'mode': 'No second C compilation; execute only the original driver-plan assembler and linker commands.',
    'driverPlanCommand': plan_command, 'driverPlanExitCode': plan.returncode,
    'commands': [], 'status': 'attempting', 'sourceChanged': False, 'runtimeExecution': False,
}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
for i, command in enumerate(commands, 1):
    result = subprocess.run(command, cwd=OUT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (OUT / f'completion-{i}.stdout.log').write_bytes(result.stdout)
    (OUT / f'completion-{i}.stderr.log').write_bytes(result.stderr)
    receipt['commands'].append({'arguments': command, 'exitCode': result.returncode})
    if result.returncode:
        receipt['status'] = 'failed-no-retry'
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
        print(result.stderr.decode())
        raise SystemExit(result.returncode)
receipt['status'] = 'completed'
receipt['files'] = []
for path in sorted(OUT.iterdir()):
    if path.is_file() and path != receipt_path:
        data = path.read_bytes()
        receipt['files'].append({'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
wasm = OUT / 'term-bank-parser-wide.wasm'
print(json.dumps({'status': 'completed', 'wasmBytes': wasm.stat().st_size, 'sha256': hashlib.sha256(wasm.read_bytes()).hexdigest()}))
