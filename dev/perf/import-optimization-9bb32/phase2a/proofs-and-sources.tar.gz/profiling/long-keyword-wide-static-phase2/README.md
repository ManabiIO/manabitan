# Long-keyword wide equality: one static variant

**Status: static isolation is promising; no runtime tests, import timing, product branch, or PR.** This is separate from the frozen minsize and canonical-fingerprint candidates. The product source, manifest, and checked-in artifacts remain unchanged.

The one scratch source adds 41 lines to the existing always-inline `json_string_matches_ascii` helper. Constant keyword lengths below 8 retain the entire old scalar path. Long literals first retain the opening-quote and cheap first-byte checks, then require a complete quoted literal within the logical end before comparing unaligned 8/4/2/1-byte chunks through builtin memcpy. Every long literal miss, including leading or later escapes, uses the unchanged bounded escaped decoder. The only current long keyword is `structured-content` (18 bytes), at two callers: composite glossary validation and single-image projection. Current compiled chunks are 8/8/2; generic 4/1 tails have no current long-keyword caller.

## Exact bindings

| Item | SHA256 |
|---|---|
| Baseline parser, commit `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` | `8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee` |
| Scratch source | `02fb89b447e8c5520092ae85c4c6194ed5e32e03fecaad2602bbf12545360797` |
| Prototype patch | `d988798a3d4258ad43a06795fea45eeaf887a2113c14e3bfd68cb9e72e85383a` |
| Scratch parser WASM | `6962928b4810ac489048b6a686e3a6cdbcd7fe3116328a13fa458bd02634024c` |

`prepare.py` reproduces the exact source and patch. The independent source reviewer checked 12 contract points, including overflow, logical bounds, unaligned access, escape identity, larger bank-end acceptance, and both callers. Removing the added branch reproduces the whole baseline source byte-for-byte. See `independent-source-review.json`; this is source review, not executable qualification.

## One compiler attempt and preserved infrastructure failure

The production Clang/wasm-ld 21.1.8 target, O3, target features, exports, and linker arguments were preserved. Diagnostic `-save-temps=obj` and linker-map flags retained assembly and provenance. The first C optimization compile succeeded through assembly generation, but the relocated compiler wrapper mishandled its `-cc1as` subprocess by inserting driver-only flags. That failure and both raw logs remain in `compile-attempt.json`, `compile.stderr.log`, and `compile.stdout.log`.

Root then authorized completing only assembly and link from the already optimized retained outputs. `complete-assembly-link.py` captures the original driver's dry command plan, invokes the pinned underlying executable for its two exact assembler commands, and invokes the pinned linker. It does not compile or optimize the C a second time. `assembly-link-completion.json` records those successful commands. The source and retained assembly were unchanged. This was a tool-wrapper repair, not a second variant, benchmark retry, or discarded observation.

## Static result

All non-Code sections are byte-identical, including types, function signatures, exports, globals, memory, and data. Exactly two of 51 function bodies change; the other 49 are byte-identical. `compare.py` additionally aligns every assembly opcode to the decoded body for both changed functions before counting instructions and loads. `static-comparison.json` binds these inputs.

| Measure | Baseline | Wide literal |
|---|---:|---:|
| Whole module bytes | 67,659 | 66,398 |
| Code section bytes | 65,241 | 63,980 |
| Function13, composite parser bytes | 6,069 | 5,413 |
| Function13 Wasm locals | 35 | 24 |
| Function13 loop / call sites | 4 / 12 | 4 / 12 |
| Function13 byte-load sites | 110 | 93 |
| Function13 i64-load /16-bit-load sites | 2 / 0 | 4 / 1 |
| Function11, image projection bytes | 4,209 | 3,604 |
| Function11 Wasm locals | 22 | 22 |
| Function11 loop / call sites | 11 / 12 | 11 / 12 |
| Function11 byte-load sites | 77 | 60 |
| Function11 i64-load /16-bit-load sites | 3 / 0 | 5 / 1 |

The composite parser's hoisted source bases fall 17→6: offsets 7 through17 and 19 disappear, while a short-key `src+6` base appears. This removes 11 net preparations from its entry bytecode. Wasm locals are not measurements of physical JIT register allocation. The ordinary string scanner and Unicode validation retain the baseline's loop structure, unlike function-wide minsize.

Compiled bounds are visible in the retained `term-bank-parser.s`. Composite lines 28261–28295 and image projection 7613–7650 establish `end-start>=2`, the first-byte check, the full `end-start-2>=18` extent, and the quote at `start+19` before wide reads. Composite lines28299,28308,28316 and projection 7654,7663,7671 then read two unaligned 64-bit words at `start+1`/`start+9` and one 16-bit tail at `start+17`. All miss branches converge on the original escaped decoder. The immediate comparison constants encode `structur`, `ed-conte`, and `nt`; no keyword bytes need runtime memory loads on the successful literal path.

The successful long-literal comparison has five source load instructions (first byte, quote, two words, tail) instead of 19 byte loads in the former chain. It reads one duplicated first byte, so this is an instruction/control-flow reduction, not a reduction in logical bytes examined. Same-first-byte nonmatches can do extra fallback work; static output cannot establish their cost or the net import benefit.

## Proposed next gate, not run

The independent reviewer proposes four narrow groups through both real native callers: exact literal at all 8 source alignments; Unicode escaping at each of 18 character positions plus mixed/all-escaped spellings; near matches around the 8/16-byte boundaries and final tail; and every truncation with physically adjacent valid-looking bytes beyond the logical bank end. Compare parsed content/hashes and native projection to the existing independent JSON/media oracles and preserve input/guard bytes.

Retain the existing native-hotpaths, glossary-semantics, media-projection, media-presence, and parser suites. An isolated regenerated artifact must first reproduce the scratch bytes through the ordinary recipe. No generic-only 8/4/2/1 test export or dictionary-specific routing is proposed. Full real-corpus parity and full browser comparisons for all three dictionaries remain required before a PR decision. Historical rejected literal work #83 is a retained caveat; #948 owns a separate grammar-dispatch specialization, not this helper change.
