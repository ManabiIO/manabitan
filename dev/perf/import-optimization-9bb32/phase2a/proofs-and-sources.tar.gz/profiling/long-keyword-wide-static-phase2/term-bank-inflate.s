	.file	"term-bank-inflate.c"
	.tabletype	__indirect_function_table, funcref
	.globaltype	__stack_pointer, i32
	.functype	libdeflate_deflate_decompress_ex (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	libdeflate_deflate_decompress (i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	libdeflate_alloc_decompressor_ex (i32) -> (i32)
	.functype	libdeflate_alloc_decompressor () -> (i32)
	.functype	libdeflate_free_decompressor (i32) -> ()
	.functype	term_bank_inflate (i32, i32, i32, i32) -> (i32)
	.functype	build_decode_table (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.section	.text.libdeflate_deflate_decompress_ex,"",@
	.globl	libdeflate_deflate_decompress_ex # -- Begin function libdeflate_deflate_decompress_ex
	.type	libdeflate_deflate_decompress_ex,@function
libdeflate_deflate_decompress_ex:       # @libdeflate_deflate_decompress_ex
	.functype	libdeflate_deflate_decompress_ex (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, i64, i32, i64, i32, i32, i32, i32, i32, i64, i64, i64
# %bb.0:
	local.get	1
	local.get	2
	i32.add 
	local.tee	7
	local.get	2
	i32.const	25
	local.get	2
	i32.const	25
	i32.lt_u
	i32.select
	i32.sub 
	local.set	8
	local.get	3
	local.get	4
	i32.add 
	local.tee	9
	local.get	4
	i32.const	299
	local.get	4
	i32.const	299
	i32.lt_u
	i32.select
	i32.sub 
	local.set	10
	local.get	0
	i32.const	256
	i32.add 
	local.set	11
	local.get	0
	i32.const	144
	i32.add 
	local.set	12
	local.get	0
	i32.const	11556
	i32.add 
	local.set	13
	local.get	0
	i32.const	9368
	i32.add 
	local.set	14
	local.get	0
	i32.const	10976
	i32.add 
	local.set	15
	local.get	0
	i32.const	460
	i32.add 
	local.set	16
	local.get	0
	i32.const	280
	i32.add 
	local.set	17
	local.get	0
	i32.const	288
	i32.add 
	local.tee	18
	i32.const	24
	i32.add 
	local.set	19
	i32.const	0
	local.set	20
	i32.const	0
	local.set	21
	i64.const	0
	local.set	22
	local.get	1
	local.set	23
	local.get	3
	local.set	24
.LBB0_1:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB0_3 Depth 2
                                        #     Child Loop BB0_11 Depth 2
                                        #     Child Loop BB0_36 Depth 2
                                        #     Child Loop BB0_41 Depth 2
                                        #     Child Loop BB0_45 Depth 2
                                        #       Child Loop BB0_49 Depth 3
                                        #     Child Loop BB0_75 Depth 2
                                        #       Child Loop BB0_108 Depth 3
                                        #       Child Loop BB0_106 Depth 3
                                        #       Child Loop BB0_103 Depth 3
                                        #     Child Loop BB0_113 Depth 2
                                        #       Child Loop BB0_115 Depth 3
                                        #       Child Loop BB0_140 Depth 3
                                        #       Child Loop BB0_142 Depth 3
	block   	
	block   	
	loop    	                                # label2:
	block   	
	block   	
	local.get	7
	local.get	23
	i32.sub 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label4
# %bb.2:                                # %.preheader915.i
                                        #   in Loop: Header=BB0_1 Depth=1
	local.get	22
	local.set	25
	local.get	21
	i32.const	255
	i32.and 
	local.tee	2
	i32.const	55
	i32.gt_u
	br_if   	1                               # 1: down to label3
.LBB0_3:                                # %.lr.ph.i
                                        #   Parent Loop BB0_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label5:
	block   	
	block   	
	local.get	23
	local.get	7
	i32.eq  
	br_if   	0                               # 0: down to label7
# %bb.4:                                #   in Loop: Header=BB0_3 Depth=2
	local.get	23
	i64.load8_u	0
	local.get	2
	i64.extend_i32_u
	i64.shl 
	local.get	25
	i64.or  
	local.set	25
	local.get	23
	i32.const	1
	i32.add 
	local.set	23
	br      	1                               # 1: down to label6
.LBB0_5:                                #   in Loop: Header=BB0_3 Depth=2
	end_block                               # label7:
	i32.const	1
	local.set	26
	local.get	20
	i32.const	1
	i32.add 
	local.tee	20
	i32.const	8
	i32.gt_u
	br_if   	5                               # 5: down to label1
.LBB0_6:                                #   in Loop: Header=BB0_3 Depth=2
	end_block                               # label6:
	local.get	21
	i32.const	8
	i32.add 
	local.tee	21
	i32.const	255
	i32.and 
	local.tee	2
	i32.const	56
	i32.lt_u
	br_if   	0                               # 0: up to label5
	br      	2                               # 2: down to label3
.LBB0_7:                                #   in Loop: Header=BB0_1 Depth=1
	end_loop
	end_block                               # label4:
	local.get	21
	i32.const	3
	i32.shr_u
	local.set	2
	local.get	23
	i64.load	0:p2align=0
	local.get	21
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shl 
	local.get	22
	i64.or  
	local.set	25
	local.get	21
	i32.const	56
	i32.or  
	local.set	21
	local.get	23
	local.get	2
	i32.const	7
	i32.and 
	i32.sub 
	i32.const	7
	i32.add 
	local.set	23
.LBB0_8:                                # %.loopexit916.i
                                        #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label3:
	i32.const	1
	local.set	26
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	25
	i32.wrap_i64
	local.tee	2
	i32.const	1
	i32.shr_u
	i32.const	3
	i32.and 
	br_table 	{1, 2, 0, 9, 1}         # 2: down to label13
                                        # 0: down to label15
                                        # 9: down to label1
                                        # 1: down to label14
.LBB0_9:                                #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label15:
	local.get	0
	i32.const	0
	i32.store8	11552
	local.get	0
	local.get	2
	i32.const	17
	i32.shr_u
	i32.const	7
	i32.and 
	i32.store8	16
	local.get	21
	i32.const	-20
	i32.add 
	local.set	21
	local.get	25
	i64.const	20
	i64.shr_u
	local.set	27
	local.get	7
	local.get	23
	i32.sub 
	i32.const	7
	i32.gt_u
	br_if   	2                               # 2: down to label12
# %bb.10:                               # %.preheader908.i
                                        #   in Loop: Header=BB0_1 Depth=1
	local.get	21
	i32.const	255
	i32.and 
	local.tee	4
	i32.const	55
	i32.gt_u
	br_if   	3                               # 3: down to label11
.LBB0_11:                               # %.lr.ph973.i
                                        #   Parent Loop BB0_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label16:
	block   	
	block   	
	local.get	23
	local.get	7
	i32.eq  
	br_if   	0                               # 0: down to label18
# %bb.12:                               #   in Loop: Header=BB0_11 Depth=2
	local.get	23
	i64.load8_u	0
	local.get	4
	i64.extend_i32_u
	i64.shl 
	local.get	27
	i64.or  
	local.set	27
	local.get	23
	i32.const	1
	i32.add 
	local.set	23
	br      	1                               # 1: down to label17
.LBB0_13:                               #   in Loop: Header=BB0_11 Depth=2
	end_block                               # label18:
	i32.const	1
	local.set	26
	local.get	20
	i32.const	1
	i32.add 
	local.tee	20
	i32.const	8
	i32.gt_u
	br_if   	10                              # 10: down to label1
.LBB0_14:                               #   in Loop: Header=BB0_11 Depth=2
	end_block                               # label17:
	local.get	21
	i32.const	8
	i32.add 
	local.tee	21
	i32.const	255
	i32.and 
	local.tee	4
	i32.const	56
	i32.lt_u
	br_if   	0                               # 0: up to label16
	br      	4                               # 4: down to label11
.LBB0_15:                               #   in Loop: Header=BB0_1 Depth=1
	end_loop
	end_block                               # label14:
	block   	
	local.get	20
	local.get	21
	i32.const	253
	i32.add 
	i32.const	3
	i32.shr_u
	i32.const	31
	i32.and 
	local.tee	2
	i32.le_u
	br_if   	0                               # 0: down to label19
# %bb.16:
	i32.const	1
	return
.LBB0_17:                               #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label19:
	block   	
	local.get	7
	local.get	23
	local.get	20
	local.get	2
	i32.sub 
	i32.add 
	local.tee	4
	i32.sub 
	i32.const	4
	i32.ge_s
	br_if   	0                               # 0: down to label20
# %bb.18:
	i32.const	1
	return
.LBB0_19:                               #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label20:
	block   	
	local.get	4
	i32.load16_u	2:p2align=0
	local.get	4
	i32.load16_u	0:p2align=0
	local.tee	2
	i32.xor 
	i32.const	65535
	i32.and 
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label21
# %bb.20:
	i32.const	1
	return
.LBB0_21:                               #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label21:
	block   	
	local.get	9
	local.get	24
	i32.sub 
	local.get	2
	i32.ge_s
	br_if   	0                               # 0: down to label22
# %bb.22:
	i32.const	3
	return
.LBB0_23:                               #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label22:
	block   	
	local.get	7
	local.get	4
	i32.const	4
	i32.add 
	local.tee	4
	i32.sub 
	local.get	2
	i32.ge_s
	br_if   	0                               # 0: down to label23
# %bb.24:
	i32.const	1
	return
.LBB0_25:                               #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label23:
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label24
# %bb.26:                               #   in Loop: Header=BB0_1 Depth=1
	local.get	24
	local.get	4
	local.get	2
	memory.copy	0, 0
.LBB0_27:                               #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label24:
	local.get	24
	local.get	2
	i32.add 
	local.set	24
	local.get	4
	local.get	2
	i32.add 
	local.set	23
	i64.const	0
	local.set	22
	i32.const	0
	local.set	20
	i32.const	0
	local.set	21
	br      	5                               # 5: down to label8
.LBB0_28:                               #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label13:
	local.get	21
	i32.const	-3
	i32.add 
	local.set	2
	local.get	25
	i64.const	3
	i64.shr_u
	local.set	27
	local.get	0
	i32.load8_u	11552
	br_if   	3                               # 3: down to label9
# %bb.29:                               # %.lr.ph968.preheader.i
                                        #   in Loop: Header=BB0_1 Depth=1
	local.get	0
	i32.const	1
	i32.store8	11552
	block   	
	i32.const	144
	i32.eqz
	br_if   	0                               # 0: down to label25
# %bb.30:                               # %.lr.ph968.preheader.i
                                        #   in Loop: Header=BB0_1 Depth=1
	local.get	0
	i32.const	8
	i32.const	144
	memory.fill	0
.LBB0_31:                               # %.lr.ph968.preheader.i
                                        #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label25:
	block   	
	i32.const	112
	i32.eqz
	br_if   	0                               # 0: down to label26
# %bb.32:                               # %.lr.ph968.preheader.i
                                        #   in Loop: Header=BB0_1 Depth=1
	local.get	12
	i32.const	9
	i32.const	112
	memory.fill	0
.LBB0_33:                               # %.lr.ph968.preheader.i
                                        #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label26:
	local.get	11
	i32.const	16
	i32.add 
	i64.const	506381209866536711
	i64.store	0:p2align=0
	local.get	11
	i32.const	8
	i32.add 
	i64.const	506381209866536711
	i64.store	0:p2align=0
	local.get	11
	i64.const	506381209866536711
	i64.store	0:p2align=0
	local.get	17
	i64.const	578721382704613384
	i64.store	0:p2align=0
	local.get	18
	i64.const	361700864190383365
	i64.store	0:p2align=0
	local.get	18
	i32.const	8
	i32.add 
	i64.const	361700864190383365
	i64.store	0:p2align=0
	local.get	18
	i32.const	16
	i32.add 
	i64.const	361700864190383365
	i64.store	0:p2align=0
	local.get	19
	i64.const	361700864190383365
	i64.store	0:p2align=0
	i32.const	32
	local.set	28
	i32.const	288
	local.set	29
	br      	2                               # 2: down to label10
.LBB0_34:                               #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label12:
	local.get	21
	i32.const	3
	i32.shr_u
	local.set	4
	local.get	23
	i64.load	0:p2align=0
	local.get	21
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shl 
	local.get	27
	i64.or  
	local.set	27
	local.get	21
	i32.const	56
	i32.or  
	local.set	21
	local.get	23
	local.get	4
	i32.const	7
	i32.and 
	i32.sub 
	i32.const	7
	i32.add 
	local.set	23
.LBB0_35:                               # %.loopexit909.i
                                        #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label11:
	local.get	2
	i32.const	8
	i32.shr_u
	i32.const	31
	i32.and 
	i32.const	1
	i32.add 
	local.set	28
	local.get	2
	i32.const	3
	i32.shr_u
	i32.const	31
	i32.and 
	i32.const	257
	i32.add 
	local.set	29
	local.get	2
	i32.const	13
	i32.shr_u
	i32.const	15
	i32.and 
	local.tee	30
	i32.const	3
	i32.add 
	local.tee	26
	i32.const	30
	i32.and 
	local.set	31
	local.get	26
	i32.const	1
	i32.and 
	local.set	32
	i32.const	0
	local.set	2
.LBB0_36:                               #   Parent Loop BB0_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label27:
	local.get	0
	local.get	2
	i32.const	deflate_decompress_default.deflate_precode_lens_permutation+1
	i32.add 
	i32.load8_u	0
	i32.add 
	local.get	27
	i32.wrap_i64
	local.tee	4
	i32.const	7
	i32.and 
	i32.store8	0
	local.get	0
	local.get	2
	i32.const	deflate_decompress_default.deflate_precode_lens_permutation+2
	i32.add 
	i32.load8_u	0
	i32.add 
	local.get	4
	i32.const	3
	i32.shr_u
	i32.const	7
	i32.and 
	i32.store8	0
	local.get	27
	i64.const	6
	i64.shr_u
	local.set	27
	local.get	31
	local.get	2
	i32.const	2
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label27
# %bb.37:                               # %.preheader907.i.unr-lcssa
                                        #   in Loop: Header=BB0_1 Depth=1
	end_loop
	block   	
	block   	
	local.get	32
	br_if   	0                               # 0: down to label29
# %bb.38:                               #   in Loop: Header=BB0_1 Depth=1
	local.get	2
	local.set	4
	br      	1                               # 1: down to label28
.LBB0_39:                               # %.preheader907.i.epilog-lcssa
                                        #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label29:
	local.get	2
	i32.const	1
	i32.add 
	local.set	4
	local.get	0
	local.get	2
	i32.const	deflate_decompress_default.deflate_precode_lens_permutation+1
	i32.add 
	i32.load8_u	0
	i32.add 
	local.get	27
	i32.wrap_i64
	i32.const	7
	i32.and 
	i32.store8	0
	local.get	27
	i64.const	3
	i64.shr_u
	local.set	27
.LBB0_40:                               # %.preheader907.i
                                        #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label28:
	block   	
	local.get	4
	i32.const	17
	i32.gt_u
	br_if   	0                               # 0: down to label30
.LBB0_41:                               # %.lr.ph979.i
                                        #   Parent Loop BB0_1 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label31:
	local.get	0
	local.get	26
	i32.const	deflate_decompress_default.deflate_precode_lens_permutation+1
	i32.add 
	i32.load8_u	0
	i32.add 
	i32.const	0
	i32.store8	0
	local.get	26
	i32.const	1
	i32.add 
	local.tee	26
	i32.const	18
	i32.lt_u
	br_if   	0                               # 0: up to label31
.LBB0_42:                               # %._crit_edge.i
                                        #   in Loop: Header=BB0_1 Depth=1
	end_loop
	end_block                               # label30:
	block   	
	local.get	16
	local.get	0
	i32.const	19
	i32.const	precode_decode_results
	i32.const	7
	i32.const	7
	local.get	15
	i32.const	0
	call	build_decode_table
	br_if   	0                               # 0: down to label32
# %bb.43:
	i32.const	1
	return
.LBB0_44:                               # %.preheader905.i
                                        #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label32:
	local.get	30
	i32.const	-3
	i32.mul 
	local.get	21
	i32.add 
	i32.const	-9
	i32.add 
	local.set	2
	local.get	29
	local.get	28
	i32.add 
	local.set	32
	i32.const	0
	local.set	4
.LBB0_45:                               #   Parent Loop BB0_1 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB0_49 Depth 3
	loop    	                                # label33:
	block   	
	block   	
	local.get	2
	i32.const	255
	i32.and 
	local.tee	26
	i32.const	13
	i32.le_u
	br_if   	0                               # 0: down to label35
# %bb.46:                               #   in Loop: Header=BB0_45 Depth=2
	local.get	2
	local.set	31
	br      	1                               # 1: down to label34
.LBB0_47:                               #   in Loop: Header=BB0_45 Depth=2
	end_block                               # label35:
	block   	
	local.get	7
	local.get	23
	i32.sub 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label36
# %bb.48:                               #   in Loop: Header=BB0_45 Depth=2
	local.get	2
	local.set	31
.LBB0_49:                               # %.lr.ph984.i
                                        #   Parent Loop BB0_1 Depth=1
                                        #     Parent Loop BB0_45 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label37:
	block   	
	block   	
	local.get	23
	local.get	7
	i32.eq  
	br_if   	0                               # 0: down to label39
# %bb.50:                               #   in Loop: Header=BB0_49 Depth=3
	local.get	23
	i64.load8_u	0
	local.get	26
	i64.extend_i32_u
	i64.shl 
	local.get	27
	i64.or  
	local.set	27
	local.get	23
	i32.const	1
	i32.add 
	local.set	23
	br      	1                               # 1: down to label38
.LBB0_51:                               #   in Loop: Header=BB0_49 Depth=3
	end_block                               # label39:
	i32.const	1
	local.set	26
	local.get	20
	i32.const	1
	i32.add 
	local.tee	20
	i32.const	8
	i32.gt_u
	br_if   	9                               # 9: down to label1
.LBB0_52:                               #   in Loop: Header=BB0_49 Depth=3
	end_block                               # label38:
	local.get	31
	i32.const	8
	i32.add 
	local.tee	31
	i32.const	255
	i32.and 
	local.tee	26
	i32.const	56
	i32.lt_u
	br_if   	0                               # 0: up to label37
	br      	2                               # 2: down to label34
.LBB0_53:                               #   in Loop: Header=BB0_45 Depth=2
	end_loop
	end_block                               # label36:
	local.get	2
	i32.const	56
	i32.or  
	local.set	31
	local.get	23
	i64.load	0:p2align=0
	local.get	26
	i64.extend_i32_u
	i64.shl 
	local.get	27
	i64.or  
	local.set	27
	local.get	23
	local.get	2
	i32.const	3
	i32.shr_u
	i32.const	7
	i32.and 
	i32.sub 
	i32.const	7
	i32.add 
	local.set	23
.LBB0_54:                               # %.loopexit899.i
                                        #   in Loop: Header=BB0_45 Depth=2
	end_block                               # label34:
	local.get	16
	local.get	27
	i32.wrap_i64
	i32.const	127
	i32.and 
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	26
	i32.const	16
	i32.shr_u
	local.set	21
	local.get	31
	local.get	26
	i32.sub 
	local.set	2
	local.get	27
	local.get	26
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shr_u
	local.set	27
	block   	
	block   	
	local.get	26
	i32.const	1048575
	i32.gt_u
	br_if   	0                               # 0: down to label41
# %bb.55:                               #   in Loop: Header=BB0_45 Depth=2
	local.get	0
	local.get	4
	i32.add 
	local.get	21
	i32.store8	0
	local.get	4
	i32.const	1
	i32.add 
	local.set	4
	br      	1                               # 1: down to label40
.LBB0_56:                               #   in Loop: Header=BB0_45 Depth=2
	end_block                               # label41:
	block   	
	block   	
	block   	
	block   	
	local.get	21
	i32.const	-16
	i32.add 
	br_table 	{0, 1, 2}               # 1: down to label44
                                        # 2: down to label43
.LBB0_57:                               #   in Loop: Header=BB0_45 Depth=2
	end_block                               # label45:
	block   	
	local.get	4
	br_if   	0                               # 0: down to label46
# %bb.58:
	i32.const	1
	return
.LBB0_59:                               #   in Loop: Header=BB0_45 Depth=2
	end_block                               # label46:
	local.get	0
	local.get	4
	i32.add 
	local.tee	26
	local.get	26
	i32.const	-1
	i32.add 
	i32.load8_u	0
	local.tee	31
	i32.store8	5
	local.get	26
	local.get	31
	i32.store8	4
	local.get	26
	local.get	31
	i32.store8	3
	local.get	26
	local.get	31
	i32.store8	2
	local.get	26
	local.get	31
	i32.store8	1
	local.get	26
	local.get	31
	i32.store8	0
	local.get	2
	i32.const	-2
	i32.add 
	local.set	2
	local.get	27
	i32.wrap_i64
	i32.const	3
	i32.and 
	i32.const	3
	i32.add 
	local.set	26
	local.get	27
	i64.const	2
	i64.shr_u
	local.set	27
	br      	2                               # 2: down to label42
.LBB0_60:                               #   in Loop: Header=BB0_45 Depth=2
	end_block                               # label44:
	local.get	0
	local.get	4
	i32.add 
	local.tee	26
	i32.const	0
	i32.store16	8:p2align=0
	local.get	26
	i64.const	0
	i64.store	0:p2align=0
	local.get	2
	i32.const	-3
	i32.add 
	local.set	2
	local.get	27
	i32.wrap_i64
	i32.const	7
	i32.and 
	i32.const	3
	i32.add 
	local.set	26
	local.get	27
	i64.const	3
	i64.shr_u
	local.set	27
	br      	1                               # 1: down to label42
.LBB0_61:                               #   in Loop: Header=BB0_45 Depth=2
	end_block                               # label43:
	block   	
	local.get	27
	i32.wrap_i64
	i32.const	127
	i32.and 
	i32.const	11
	i32.add 
	local.tee	26
	i32.eqz
	br_if   	0                               # 0: down to label47
# %bb.62:                               #   in Loop: Header=BB0_45 Depth=2
	local.get	0
	local.get	4
	i32.add 
	i32.const	0
	local.get	26
	memory.fill	0
.LBB0_63:                               #   in Loop: Header=BB0_45 Depth=2
	end_block                               # label47:
	local.get	2
	i32.const	-7
	i32.add 
	local.set	2
	local.get	27
	i64.const	7
	i64.shr_u
	local.set	27
.LBB0_64:                               #   in Loop: Header=BB0_45 Depth=2
	end_block                               # label42:
	local.get	26
	local.get	4
	i32.add 
	local.set	4
.LBB0_65:                               #   in Loop: Header=BB0_45 Depth=2
	end_block                               # label40:
	local.get	4
	local.get	32
	i32.lt_u
	br_if   	0                               # 0: up to label33
# %bb.66:                               #   in Loop: Header=BB0_1 Depth=1
	end_loop
	local.get	4
	local.get	32
	i32.eq  
	br_if   	0                               # 0: down to label10
# %bb.67:
	i32.const	1
	return
.LBB0_68:                               # %.thread843.i
                                        #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label10:
	block   	
	local.get	14
	local.get	0
	local.get	29
	i32.add 
	local.get	28
	i32.const	offset_decode_results
	i32.const	8
	i32.const	15
	local.get	15
	i32.const	0
	call	build_decode_table
	br_if   	0                               # 0: down to label48
# %bb.69:
	i32.const	1
	return
.LBB0_70:                               #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label48:
	local.get	0
	local.get	0
	local.get	29
	i32.const	litlen_decode_results
	i32.const	11
	i32.const	15
	local.get	15
	local.get	13
	call	build_decode_table
	br_if   	0                               # 0: down to label9
# %bb.71:
	i32.const	1
	return
.LBB0_72:                               #   in Loop: Header=BB0_1 Depth=1
	end_block                               # label9:
	i64.const	-1
	local.get	13
	i64.load32_u	0
	i64.shl 
	i64.const	-1
	i64.xor 
	local.set	33
	block   	
	block   	
	local.get	23
	local.get	8
	i32.ge_u
	br_if   	0                               # 0: down to label50
# %bb.73:                               #   in Loop: Header=BB0_1 Depth=1
	local.get	24
	local.get	10
	i32.ge_u
	br_if   	0                               # 0: down to label50
# %bb.74:                               #   in Loop: Header=BB0_1 Depth=1
	local.get	2
	i32.const	56
	i32.or  
	local.set	21
	local.get	23
	local.get	2
	i32.const	3
	i32.shr_u
	i32.const	7
	i32.and 
	i32.sub 
	i32.const	7
	i32.add 
	local.set	32
	local.get	0
	local.get	23
	i64.load	0:p2align=0
	local.get	2
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shl 
	local.get	27
	i64.or  
	local.tee	27
	local.get	33
	i64.and 
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.set	31
.LBB0_75:                               #   Parent Loop BB0_1 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB0_108 Depth 3
                                        #       Child Loop BB0_106 Depth 3
                                        #       Child Loop BB0_103 Depth 3
	loop    	                                # label51:
	local.get	21
	local.get	31
	i32.sub 
	local.set	21
	local.get	27
	local.get	31
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shr_u
	local.set	34
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	31
	i32.const	-1
	i32.le_s
	br_if   	0                               # 0: down to label56
# %bb.76:                               #   in Loop: Header=BB0_75 Depth=2
	local.get	34
	local.set	22
	br      	1                               # 1: down to label55
.LBB0_77:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label56:
	local.get	24
	local.get	31
	i32.const	16
	i32.shr_u
	i32.store8	0
	local.get	21
	local.get	0
	local.get	34
	local.get	33
	i64.and 
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	31
	i32.sub 
	local.set	21
	local.get	34
	local.get	31
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shr_u
	local.set	22
	block   	
	local.get	31
	i32.const	-1
	i32.le_s
	br_if   	0                               # 0: down to label57
# %bb.78:                               #   in Loop: Header=BB0_75 Depth=2
	local.get	24
	i32.const	1
	i32.add 
	local.set	24
	local.get	34
	local.set	27
	br      	1                               # 1: down to label55
.LBB0_79:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label57:
	local.get	24
	local.get	31
	i32.const	16
	i32.shr_u
	i32.store8	1
	local.get	21
	local.get	0
	local.get	22
	local.get	33
	i64.and 
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	31
	i32.sub 
	local.set	21
	local.get	22
	local.get	31
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shr_u
	local.set	34
	local.get	31
	i32.const	-1
	i32.le_s
	br_if   	1                               # 1: down to label54
# %bb.80:                               #   in Loop: Header=BB0_75 Depth=2
	local.get	24
	i32.const	2
	i32.add 
	local.set	24
	local.get	22
	local.set	27
	local.get	34
	local.set	22
.LBB0_81:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label55:
	block   	
	local.get	31
	i32.const	32768
	i32.and 
	br_if   	0                               # 0: down to label58
# %bb.82:                               # %._crit_edge1044.i
                                        #   in Loop: Header=BB0_75 Depth=2
	local.get	31
	i32.const	255
	i32.and 
	i64.extend_i32_u
	local.set	35
	local.get	22
	local.set	34
	br      	2                               # 2: down to label53
.LBB0_83:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label58:
	block   	
	local.get	31
	i32.const	8192
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label59
# %bb.84:                               #   in Loop: Header=BB0_1 Depth=1
	local.get	32
	local.set	23
	br      	7                               # 7: down to label8
.LBB0_85:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label59:
	local.get	21
	local.get	0
	local.get	31
	i32.const	16
	i32.shr_u
	local.get	22
	i64.const	-1
	local.get	31
	i32.const	8
	i32.shr_u
	i32.const	31
	i32.and 
	i64.extend_i32_u
	i64.shl 
	i64.const	-1
	i64.xor 
	i64.and 
	i32.wrap_i64
	i32.add 
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	31
	i32.sub 
	local.set	21
	local.get	22
	local.get	31
	i32.const	255
	i32.and 
	i64.extend_i32_u
	local.tee	35
	i64.shr_u
	local.set	34
	block   	
	local.get	31
	i32.const	-1
	i32.gt_s
	br_if   	0                               # 0: down to label60
# %bb.86:                               #   in Loop: Header=BB0_75 Depth=2
	local.get	24
	local.get	31
	i32.const	16
	i32.shr_u
	i32.store8	0
	local.get	24
	i32.const	1
	i32.add 
	local.set	24
	local.get	32
	i64.load	0:p2align=0
	local.get	21
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shl 
	local.get	34
	i64.or  
	local.set	27
	local.get	0
	local.get	34
	local.get	33
	i64.and 
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.set	31
	local.get	32
	local.get	21
	i32.const	3
	i32.shr_u
	i32.const	7
	i32.and 
	i32.sub 
	i32.const	7
	i32.add 
	local.set	32
	br      	3                               # 3: down to label52
.LBB0_87:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label60:
	local.get	22
	local.set	27
	local.get	31
	i32.const	8192
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label53
# %bb.88:                               #   in Loop: Header=BB0_1 Depth=1
	local.get	34
	local.set	22
	local.get	32
	local.set	23
	br      	6                               # 6: down to label8
.LBB0_89:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label54:
	local.get	24
	local.get	31
	i32.const	16
	i32.shr_u
	i32.store8	2
	local.get	24
	i32.const	3
	i32.add 
	local.set	24
	local.get	32
	i64.load	0:p2align=0
	local.get	21
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shl 
	local.get	34
	i64.or  
	local.set	27
	local.get	0
	local.get	34
	local.get	33
	i64.and 
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.set	31
	local.get	32
	local.get	21
	i32.const	3
	i32.shr_u
	i32.const	7
	i32.and 
	i32.sub 
	i32.const	7
	i32.add 
	local.set	32
	br      	1                               # 1: down to label52
.LBB0_90:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label53:
	local.get	21
	i32.const	255
	i32.and 
	local.set	2
	block   	
	block   	
	local.get	14
	local.get	34
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	4
	i32.const	32768
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label62
# %bb.91:                               #   in Loop: Header=BB0_75 Depth=2
	block   	
	block   	
	local.get	2
	i32.const	37
	i32.le_u
	br_if   	0                               # 0: down to label64
# %bb.92:                               #   in Loop: Header=BB0_75 Depth=2
	local.get	21
	local.set	26
	br      	1                               # 1: down to label63
.LBB0_93:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label64:
	local.get	21
	i32.const	56
	i32.or  
	local.set	26
	local.get	32
	i64.load	0:p2align=0
	local.get	2
	i64.extend_i32_u
	i64.shl 
	local.get	34
	i64.or  
	local.set	34
	local.get	32
	local.get	21
	i32.const	3
	i32.shr_u
	i32.const	7
	i32.and 
	i32.sub 
	i32.const	7
	i32.add 
	local.set	32
.LBB0_94:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label63:
	local.get	14
	local.get	4
	i32.const	16
	i32.shr_u
	local.get	34
	i64.const	8
	i64.shr_u
	local.tee	34
	i64.const	-1
	local.get	4
	i32.const	8
	i32.shr_u
	i32.const	63
	i32.and 
	i64.extend_i32_u
	i64.shl 
	i64.const	-1
	i64.xor 
	i64.and 
	i32.wrap_i64
	i32.add 
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.set	4
	local.get	26
	i32.const	-8
	i32.add 
	local.set	26
	br      	1                               # 1: down to label61
.LBB0_95:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label62:
	block   	
	local.get	2
	i32.const	30
	i32.le_u
	br_if   	0                               # 0: down to label65
# %bb.96:                               #   in Loop: Header=BB0_75 Depth=2
	local.get	21
	local.set	26
	br      	1                               # 1: down to label61
.LBB0_97:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label65:
	local.get	21
	i32.const	56
	i32.or  
	local.set	26
	local.get	32
	i64.load	0:p2align=0
	local.get	2
	i64.extend_i32_u
	i64.shl 
	local.get	34
	i64.or  
	local.set	34
	local.get	32
	local.get	21
	i32.const	3
	i32.shr_u
	i32.const	7
	i32.and 
	i32.sub 
	i32.const	7
	i32.add 
	local.set	32
.LBB0_98:                               #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label61:
	block   	
	local.get	4
	i32.const	16
	i32.shr_u
	local.tee	23
	local.get	34
	i64.const	-1
	local.get	4
	i32.const	255
	i32.and 
	i64.extend_i32_u
	local.tee	22
	i64.shl 
	i64.const	-1
	i64.xor 
	i64.and 
	local.get	4
	i32.const	8
	i32.shr_u
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shr_u
	i32.wrap_i64
	local.tee	29
	i32.add 
	local.tee	2
	local.get	24
	local.get	3
	i32.sub 
	i32.le_u
	br_if   	0                               # 0: down to label66
# %bb.99:
	i32.const	1
	return
.LBB0_100:                              #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label66:
	local.get	27
	i64.const	-1
	local.get	35
	i64.shl 
	i64.const	-1
	i64.xor 
	i64.and 
	local.set	35
	local.get	32
	i64.load	0:p2align=0
	local.get	26
	local.get	4
	i32.sub 
	local.tee	21
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shl 
	local.get	34
	local.get	22
	i64.shr_u
	local.tee	34
	i64.or  
	local.set	27
	local.get	24
	local.get	2
	i32.sub 
	local.set	26
	local.get	24
	local.get	31
	i32.const	16
	i32.shr_u
	i32.add 
	local.get	35
	local.get	31
	i32.const	8
	i32.shr_u
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shr_u
	i32.wrap_i64
	i32.add 
	local.set	4
	local.get	32
	local.get	21
	i32.const	3
	i32.shr_u
	i32.const	7
	i32.and 
	i32.sub 
	i32.const	7
	i32.add 
	local.set	32
	local.get	0
	local.get	34
	local.get	33
	i64.and 
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.set	31
	block   	
	block   	
	local.get	2
	i32.const	8
	i32.lt_u
	br_if   	0                               # 0: down to label68
# %bb.101:                              #   in Loop: Header=BB0_75 Depth=2
	local.get	24
	local.get	26
	i64.load	0:p2align=0
	i64.store	0:p2align=0
	local.get	24
	local.get	26
	i64.load	8:p2align=0
	i64.store	8:p2align=0
	local.get	24
	local.get	26
	i64.load	16:p2align=0
	i64.store	16:p2align=0
	local.get	24
	local.get	26
	i64.load	24:p2align=0
	i64.store	24:p2align=0
	local.get	24
	local.get	26
	i64.load	32:p2align=0
	i64.store	32:p2align=0
	local.get	24
	i32.const	40
	i32.add 
	local.get	4
	i32.ge_u
	br_if   	1                               # 1: down to label67
# %bb.102:                              # %.lr.ph999.i.preheader
                                        #   in Loop: Header=BB0_75 Depth=2
	i32.const	0
	local.get	2
	i32.sub 
	local.set	23
.LBB0_103:                              # %.lr.ph999.i
                                        #   Parent Loop BB0_1 Depth=1
                                        #     Parent Loop BB0_75 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label69:
	local.get	24
	i32.const	40
	i32.add 
	local.tee	26
	local.get	24
	local.get	23
	i32.add 
	local.tee	2
	i32.const	40
	i32.add 
	i64.load	0:p2align=0
	i64.store	0:p2align=0
	local.get	24
	i32.const	48
	i32.add 
	local.get	2
	i32.const	48
	i32.add 
	i64.load	0:p2align=0
	i64.store	0:p2align=0
	local.get	24
	i32.const	56
	i32.add 
	local.get	2
	i32.const	56
	i32.add 
	i64.load	0:p2align=0
	i64.store	0:p2align=0
	local.get	24
	i32.const	64
	i32.add 
	local.get	2
	i32.const	64
	i32.add 
	i64.load	0:p2align=0
	i64.store	0:p2align=0
	local.get	24
	i32.const	72
	i32.add 
	local.get	2
	i32.const	72
	i32.add 
	i64.load	0:p2align=0
	i64.store	0:p2align=0
	local.get	24
	i32.const	80
	i32.add 
	local.set	2
	local.get	26
	local.set	24
	local.get	2
	local.get	4
	i32.lt_u
	br_if   	0                               # 0: up to label69
	br      	2                               # 2: down to label67
.LBB0_104:                              #   in Loop: Header=BB0_75 Depth=2
	end_loop
	end_block                               # label68:
	block   	
	local.get	2
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label70
# %bb.105:                              #   in Loop: Header=BB0_75 Depth=2
	local.get	24
	local.get	26
	i64.load8_u	0
	i64.const	72340172838076673
	i64.mul 
	local.tee	34
	i64.store	24:p2align=0
	local.get	24
	local.get	34
	i64.store	16:p2align=0
	local.get	24
	local.get	34
	i64.store	8:p2align=0
	local.get	24
	local.get	34
	i64.store	0:p2align=0
	local.get	24
	i32.const	32
	i32.add 
	local.tee	2
	local.get	4
	i32.ge_u
	br_if   	1                               # 1: down to label67
.LBB0_106:                              # %.lr.ph993.i
                                        #   Parent Loop BB0_1 Depth=1
                                        #     Parent Loop BB0_75 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label71:
	local.get	2
	local.get	34
	i64.store	0:p2align=0
	local.get	2
	i32.const	24
	i32.add 
	local.get	34
	i64.store	0:p2align=0
	local.get	2
	i32.const	16
	i32.add 
	local.get	34
	i64.store	0:p2align=0
	local.get	2
	i32.const	8
	i32.add 
	local.get	34
	i64.store	0:p2align=0
	local.get	2
	i32.const	32
	i32.add 
	local.tee	2
	local.get	4
	i32.lt_u
	br_if   	0                               # 0: up to label71
	br      	2                               # 2: down to label67
.LBB0_107:                              #   in Loop: Header=BB0_75 Depth=2
	end_loop
	end_block                               # label70:
	local.get	24
	local.get	26
	i64.load	0:p2align=0
	local.tee	34
	i64.store	0:p2align=0
	local.get	24
	local.get	2
	i32.add 
	local.get	34
	i64.store	0:p2align=0
	local.get	23
	i32.const	1
	i32.shl 
	local.get	29
	i32.const	1
	i32.shl 
	i32.add 
	local.set	26
	local.get	2
	i32.const	3
	i32.mul 
	local.set	29
.LBB0_108:                              #   Parent Loop BB0_1 Depth=1
                                        #     Parent Loop BB0_75 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label72:
	local.get	24
	local.get	26
	i32.add 
	local.get	24
	local.get	2
	i32.add 
	local.tee	23
	i64.load	0:p2align=0
	local.tee	34
	i64.store	0:p2align=0
	local.get	24
	local.get	29
	i32.add 
	local.get	34
	i64.store	0:p2align=0
	local.get	23
	local.get	2
	i32.add 
	local.tee	24
	local.get	26
	i32.add 
	local.get	4
	i32.lt_u
	br_if   	0                               # 0: up to label72
.LBB0_109:                              #   in Loop: Header=BB0_75 Depth=2
	end_loop
	end_block                               # label67:
	local.get	4
	local.set	24
.LBB0_110:                              # %.loopexit895.i
                                        #   in Loop: Header=BB0_75 Depth=2
	end_block                               # label52:
	local.get	21
	i32.const	56
	i32.or  
	local.set	21
	local.get	32
	local.get	8
	i32.ge_u
	br_if   	2                               # 2: down to label49
# %bb.111:                              # %.loopexit895.i
                                        #   in Loop: Header=BB0_75 Depth=2
	local.get	24
	local.get	10
	i32.lt_u
	br_if   	0                               # 0: up to label51
	br      	2                               # 2: down to label49
.LBB0_112:                              #   in Loop: Header=BB0_1 Depth=1
	end_loop
	end_block                               # label50:
	local.get	2
	local.set	21
	local.get	23
	local.set	32
.LBB0_113:                              # %.loopexit904.i
                                        #   Parent Loop BB0_1 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB0_115 Depth 3
                                        #       Child Loop BB0_140 Depth 3
                                        #       Child Loop BB0_142 Depth 3
	end_block                               # label49:
	loop    	                                # label73:
	block   	
	block   	
	local.get	7
	local.get	32
	i32.sub 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label75
# %bb.114:                              # %.preheader.i
                                        #   in Loop: Header=BB0_113 Depth=2
	local.get	21
	i32.const	255
	i32.and 
	local.tee	2
	i32.const	55
	i32.gt_u
	br_if   	1                               # 1: down to label74
.LBB0_115:                              # %.lr.ph1004.i
                                        #   Parent Loop BB0_1 Depth=1
                                        #     Parent Loop BB0_113 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label76:
	block   	
	block   	
	local.get	32
	local.get	7
	i32.eq  
	br_if   	0                               # 0: down to label78
# %bb.116:                              #   in Loop: Header=BB0_115 Depth=3
	local.get	32
	i64.load8_u	0
	local.get	2
	i64.extend_i32_u
	i64.shl 
	local.get	27
	i64.or  
	local.set	27
	local.get	32
	i32.const	1
	i32.add 
	local.set	32
	br      	1                               # 1: down to label77
.LBB0_117:                              #   in Loop: Header=BB0_115 Depth=3
	end_block                               # label78:
	i32.const	1
	local.set	26
	local.get	20
	i32.const	1
	i32.add 
	local.tee	20
	i32.const	8
	i32.gt_u
	br_if   	7                               # 7: down to label1
.LBB0_118:                              #   in Loop: Header=BB0_115 Depth=3
	end_block                               # label77:
	local.get	21
	i32.const	8
	i32.add 
	local.tee	21
	i32.const	255
	i32.and 
	local.tee	2
	i32.const	56
	i32.lt_u
	br_if   	0                               # 0: up to label76
	br      	2                               # 2: down to label74
.LBB0_119:                              #   in Loop: Header=BB0_113 Depth=2
	end_loop
	end_block                               # label75:
	local.get	21
	i32.const	3
	i32.shr_u
	local.set	2
	local.get	32
	i64.load	0:p2align=0
	local.get	21
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shl 
	local.get	27
	i64.or  
	local.set	27
	local.get	21
	i32.const	56
	i32.or  
	local.set	21
	local.get	32
	local.get	2
	i32.const	7
	i32.and 
	i32.sub 
	i32.const	7
	i32.add 
	local.set	32
.LBB0_120:                              # %.loopexit894.i
                                        #   in Loop: Header=BB0_113 Depth=2
	end_block                               # label74:
	local.get	21
	local.get	0
	local.get	27
	local.get	33
	i64.and 
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	2
	i32.sub 
	local.set	21
	local.get	27
	local.get	2
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shr_u
	local.set	34
	block   	
	block   	
	local.get	2
	i32.const	16384
	i32.and 
	br_if   	0                               # 0: down to label80
# %bb.121:                              #   in Loop: Header=BB0_113 Depth=2
	local.get	27
	local.set	22
	local.get	34
	local.set	27
	br      	1                               # 1: down to label79
.LBB0_122:                              #   in Loop: Header=BB0_113 Depth=2
	end_block                               # label80:
	local.get	21
	local.get	0
	local.get	2
	i32.const	16
	i32.shr_u
	local.get	34
	i64.const	-1
	local.get	2
	i32.const	8
	i32.shr_u
	i32.const	63
	i32.and 
	i64.extend_i32_u
	i64.shl 
	i64.const	-1
	i64.xor 
	i64.and 
	i32.wrap_i64
	i32.add 
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	2
	i32.sub 
	local.set	21
	local.get	34
	local.get	2
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shr_u
	local.set	27
	local.get	34
	local.set	22
.LBB0_123:                              #   in Loop: Header=BB0_113 Depth=2
	end_block                               # label79:
	local.get	2
	i32.const	16
	i32.shr_u
	local.set	4
	block   	
	local.get	2
	i32.const	-1
	i32.gt_s
	br_if   	0                               # 0: down to label81
# %bb.124:                              #   in Loop: Header=BB0_113 Depth=2
	block   	
	local.get	24
	local.get	9
	i32.ne  
	br_if   	0                               # 0: down to label82
# %bb.125:
	i32.const	3
	return
.LBB0_126:                              #   in Loop: Header=BB0_113 Depth=2
	end_block                               # label82:
	local.get	24
	local.get	4
	i32.store8	0
	local.get	24
	i32.const	1
	i32.add 
	local.set	24
	br      	1                               # 1: up to label73
.LBB0_127:                              #   in Loop: Header=BB0_113 Depth=2
	end_block                               # label81:
	block   	
	local.get	2
	i32.const	8192
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label83
# %bb.128:                              #   in Loop: Header=BB0_1 Depth=1
	local.get	27
	local.set	22
	local.get	32
	local.set	23
	br      	2                               # 2: down to label8
.LBB0_129:                              #   in Loop: Header=BB0_113 Depth=2
	end_block                               # label83:
	block   	
	local.get	4
	local.get	22
	i64.const	-1
	local.get	2
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shl 
	i64.const	-1
	i64.xor 
	i64.and 
	local.get	2
	i32.const	8
	i32.shr_u
	i32.const	223
	i32.and 
	i64.extend_i32_u
	i64.shr_u
	i32.wrap_i64
	local.tee	26
	i32.add 
	local.tee	31
	local.get	9
	local.get	24
	i32.sub 
	i32.le_u
	br_if   	0                               # 0: down to label84
# %bb.130:
	i32.const	3
	return
.LBB0_131:                              #   in Loop: Header=BB0_113 Depth=2
	end_block                               # label84:
	block   	
	local.get	14
	local.get	27
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	2
	i32.const	32768
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label85
# %bb.132:                              #   in Loop: Header=BB0_113 Depth=2
	local.get	14
	local.get	2
	i32.const	16
	i32.shr_u
	local.get	27
	i64.const	8
	i64.shr_u
	local.tee	27
	i64.const	-1
	local.get	2
	i32.const	8
	i32.shr_u
	i32.const	63
	i32.and 
	i64.extend_i32_u
	i64.shl 
	i64.const	-1
	i64.xor 
	i64.and 
	i32.wrap_i64
	i32.add 
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.set	2
	local.get	21
	i32.const	-8
	i32.add 
	local.set	21
.LBB0_133:                              #   in Loop: Header=BB0_113 Depth=2
	end_block                               # label85:
	block   	
	local.get	2
	i32.const	16
	i32.shr_u
	local.get	27
	i64.const	-1
	local.get	2
	i32.const	255
	i32.and 
	i64.extend_i32_u
	local.tee	34
	i64.shl 
	i64.const	-1
	i64.xor 
	i64.and 
	local.get	2
	i32.const	8
	i32.shr_u
	i32.const	255
	i32.and 
	i64.extend_i32_u
	i64.shr_u
	i32.wrap_i64
	i32.add 
	local.tee	23
	local.get	24
	local.get	3
	i32.sub 
	i32.le_u
	br_if   	0                               # 0: down to label86
# %bb.134:
	i32.const	1
	return
.LBB0_135:                              #   in Loop: Header=BB0_113 Depth=2
	end_block                               # label86:
	local.get	21
	local.get	2
	i32.sub 
	local.set	21
	local.get	27
	local.get	34
	i64.shr_u
	local.set	27
	local.get	24
	local.get	24
	local.get	23
	i32.sub 
	local.tee	2
	i32.load8_u	0
	i32.store8	0
	local.get	24
	local.get	2
	i32.load8_u	1
	i32.store8	1
	local.get	4
	local.get	24
	i32.add 
	local.get	26
	i32.add 
	local.tee	4
	local.get	24
	i32.const	3
	i32.add 
	local.tee	26
	local.get	4
	local.get	26
	i32.gt_u
	i32.select
	local.get	24
	i32.sub 
	local.set	4
	local.get	24
	i32.const	2
	i32.add 
	local.set	26
	local.get	24
	local.get	31
	i32.add 
	local.set	24
	local.get	2
	i32.const	2
	i32.add 
	local.set	2
	block   	
	block   	
	local.get	4
	i32.const	-2
	i32.add 
	local.tee	29
	i32.const	16
	i32.ge_u
	br_if   	0                               # 0: down to label88
# %bb.136:                              #   in Loop: Header=BB0_113 Depth=2
	local.get	26
	local.set	4
	br      	1                               # 1: down to label87
.LBB0_137:                              #   in Loop: Header=BB0_113 Depth=2
	end_block                               # label88:
	block   	
	local.get	23
	i32.const	16
	i32.ge_u
	br_if   	0                               # 0: down to label89
# %bb.138:                              #   in Loop: Header=BB0_113 Depth=2
	local.get	26
	local.set	4
	br      	1                               # 1: down to label87
.LBB0_139:                              # %vector.ph
                                        #   in Loop: Header=BB0_113 Depth=2
	end_block                               # label89:
	i32.const	0
	local.get	23
	i32.sub 
	local.set	31
	local.get	26
	local.get	29
	i32.const	-16
	i32.and 
	local.tee	28
	i32.add 
	local.set	4
	local.get	2
	local.get	28
	i32.add 
	local.set	2
	local.get	28
	local.set	23
.LBB0_140:                              # %vector.body
                                        #   Parent Loop BB0_1 Depth=1
                                        #     Parent Loop BB0_113 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label90:
	local.get	26
	local.get	26
	local.get	31
	i32.add 
	v128.load	0:p2align=0
	v128.store	0:p2align=0
	local.get	26
	i32.const	16
	i32.add 
	local.set	26
	local.get	23
	i32.const	-16
	i32.add 
	local.tee	23
	br_if   	0                               # 0: up to label90
# %bb.141:                              # %middle.block
                                        #   in Loop: Header=BB0_113 Depth=2
	end_loop
	local.get	29
	local.get	28
	i32.eq  
	br_if   	1                               # 1: up to label73
.LBB0_142:                              # %scalar.ph
                                        #   Parent Loop BB0_1 Depth=1
                                        #     Parent Loop BB0_113 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	end_block                               # label87:
	loop    	                                # label91:
	local.get	4
	local.get	2
	i32.load8_u	0
	i32.store8	0
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	local.get	4
	i32.const	1
	i32.add 
	local.tee	4
	local.get	24
	i32.lt_u
	br_if   	0                               # 0: up to label91
	br      	1                               # 1: up to label73
.LBB0_143:                              # %.thread869.i
                                        #   in Loop: Header=BB0_1 Depth=1
	end_loop
	end_loop
	end_block                               # label8:
	local.get	25
	i64.const	1
	i64.and 
	i64.eqz
	br_if   	0                               # 0: up to label2
# %bb.144:
	end_loop
	i32.const	1
	local.set	26
	local.get	20
	local.get	21
	i32.const	3
	i32.shr_u
	i32.const	31
	i32.and 
	local.tee	2
	i32.gt_u
	br_if   	0                               # 0: down to label1
# %bb.145:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label92
# %bb.146:
	local.get	5
	local.get	23
	local.get	20
	local.get	2
	i32.sub 
	i32.add 
	local.get	1
	i32.sub 
	i32.store	0
.LBB0_147:
	end_block                               # label92:
	block   	
	local.get	6
	i32.eqz
	br_if   	0                               # 0: down to label93
# %bb.148:
	local.get	6
	local.get	24
	local.get	3
	i32.sub 
	i32.store	0
	br      	2                               # 2: down to label0
.LBB0_149:
	end_block                               # label93:
	local.get	24
	local.get	9
	i32.eq  
	br_if   	1                               # 1: down to label0
# %bb.150:
	i32.const	2
	local.set	26
.LBB0_151:                              # %deflate_decompress_default.exit
	end_block                               # label1:
	local.get	26
	return
.LBB0_152:
	end_block                               # label0:
	i32.const	0
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.libdeflate_deflate_decompress,"",@
	.globl	libdeflate_deflate_decompress   # -- Begin function libdeflate_deflate_decompress
	.type	libdeflate_deflate_decompress,@function
libdeflate_deflate_decompress:          # @libdeflate_deflate_decompress
	.functype	libdeflate_deflate_decompress (i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	local.get	4
	i32.const	0
	local.get	5
	call	libdeflate_deflate_decompress_ex
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.libdeflate_alloc_decompressor_ex,"",@
	.globl	libdeflate_alloc_decompressor_ex # -- Begin function libdeflate_alloc_decompressor_ex
	.type	libdeflate_alloc_decompressor_ex,@function
libdeflate_alloc_decompressor_ex:       # @libdeflate_alloc_decompressor_ex
	.functype	libdeflate_alloc_decompressor_ex (i32) -> (i32)
	.local  	i32, i32
# %bb.0:
	i32.const	0
	local.set	1
	block   	
	local.get	0
	i32.load	0
	i32.const	12
	i32.ne  
	br_if   	0                               # 0: down to label94
# %bb.1:
	i32.const	0
	local.set	1
	i32.const	11564
	local.get	0
	i32.load	4
	local.tee	2
	i32.const	0
	i32.load	libdeflate_default_malloc_func
	local.get	2
	i32.select
	call_indirect	 __indirect_function_table, (i32) -> (i32)
	local.tee	2
	i32.eqz
	br_if   	0                               # 0: down to label94
# %bb.2:
	block   	
	i32.const	11564
	i32.eqz
	br_if   	0                               # 0: down to label95
# %bb.3:
	local.get	2
	i32.const	0
	i32.const	11564
	memory.fill	0
.LBB2_4:
	end_block                               # label95:
	local.get	2
	local.get	0
	i32.load	8
	local.tee	0
	i32.const	0
	i32.load	libdeflate_default_free_func
	local.get	0
	i32.select
	i32.store	11560
	local.get	2
	local.set	1
.LBB2_5:
	end_block                               # label94:
	local.get	1
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.libdeflate_alloc_decompressor,"",@
	.globl	libdeflate_alloc_decompressor   # -- Begin function libdeflate_alloc_decompressor
	.type	libdeflate_alloc_decompressor,@function
libdeflate_alloc_decompressor:          # @libdeflate_alloc_decompressor
	.functype	libdeflate_alloc_decompressor () -> (i32)
	.local  	i32
# %bb.0:
	block   	
	i32.const	11564
	i32.const	0
	i32.load	libdeflate_default_malloc_func
	call_indirect	 __indirect_function_table, (i32) -> (i32)
	local.tee	0
	i32.eqz
	br_if   	0                               # 0: down to label96
# %bb.1:
	block   	
	i32.const	11564
	i32.eqz
	br_if   	0                               # 0: down to label97
# %bb.2:
	local.get	0
	i32.const	0
	i32.const	11564
	memory.fill	0
.LBB3_3:
	end_block                               # label97:
	local.get	0
	i32.const	0
	i32.load	libdeflate_default_free_func
	i32.store	11560
.LBB3_4:                                # %libdeflate_alloc_decompressor_ex.exit
	end_block                               # label96:
	local.get	0
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.libdeflate_free_decompressor,"",@
	.globl	libdeflate_free_decompressor    # -- Begin function libdeflate_free_decompressor
	.type	libdeflate_free_decompressor,@function
libdeflate_free_decompressor:           # @libdeflate_free_decompressor
	.functype	libdeflate_free_decompressor (i32) -> ()
# %bb.0:
	block   	
	local.get	0
	i32.eqz
	br_if   	0                               # 0: down to label98
# %bb.1:
	local.get	0
	local.get	0
	i32.load	11560
	call_indirect	 __indirect_function_table, (i32) -> ()
.LBB4_2:
	end_block                               # label98:
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.term_bank_inflate,"",@
	.hidden	term_bank_inflate               # -- Begin function term_bank_inflate
	.globl	term_bank_inflate
	.type	term_bank_inflate,@function
term_bank_inflate:                      # @term_bank_inflate
	.functype	term_bank_inflate (i32, i32, i32, i32) -> (i32)
	.local  	i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	4
	global.set	__stack_pointer
	local.get	4
	i32.const	0
	i32.store	12
	local.get	4
	i32.const	0
	i32.store	8
	block   	
	block   	
	i32.const	term_bank_decompressor
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	local.get	4
	i32.const	12
	i32.add 
	local.get	4
	i32.const	8
	i32.add 
	call	libdeflate_deflate_decompress_ex
	i32.eqz
	br_if   	0                               # 0: down to label100
# %bb.1:
	i32.const	-2
	local.set	3
	br      	1                               # 1: down to label99
.LBB5_2:
	end_block                               # label100:
	block   	
	local.get	4
	i32.load	8
	local.get	3
	i32.eq  
	br_if   	0                               # 0: down to label101
# %bb.3:
	i32.const	-3
	local.set	3
	br      	1                               # 1: down to label99
.LBB5_4:
	end_block                               # label101:
	i32.const	0
	i32.const	-6
	local.get	4
	i32.load	12
	local.get	1
	i32.eq  
	i32.select
	local.set	3
.LBB5_5:
	end_block                               # label99:
	local.get	4
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	3
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.build_decode_table,"",@
	.type	build_decode_table,@function    # -- Begin function build_decode_table
build_decode_table:                     # @build_decode_table
	.functype	build_decode_table (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:                                # %.preheader222
	global.get	__stack_pointer
	i32.const	128
	i32.sub 
	local.set	8
	block   	
	local.get	5
	i32.const	2
	i32.shl 
	i32.const	4
	i32.add 
	local.tee	9
	i32.eqz
	br_if   	0                               # 0: down to label102
# %bb.1:                                # %.preheader222
	local.get	8
	i32.const	64
	i32.add 
	i32.const	0
	local.get	9
	memory.fill	0
.LBB6_2:                                # %.preheader222
	end_block                               # label102:
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label103
# %bb.3:                                # %.lr.ph.preheader
	local.get	2
	i32.const	3
	i32.and 
	local.set	10
	i32.const	0
	local.set	11
	block   	
	local.get	2
	i32.const	4
	i32.lt_u
	br_if   	0                               # 0: down to label104
# %bb.4:                                # %.lr.ph.preheader.new
	local.get	2
	i32.const	-4
	i32.and 
	local.set	12
	i32.const	0
	local.set	11
.LBB6_5:                                # %.lr.ph
                                        # =>This Inner Loop Header: Depth=1
	loop    	                                # label105:
	local.get	8
	i32.const	64
	i32.add 
	local.get	1
	local.get	11
	i32.add 
	local.tee	9
	i32.load8_u	0
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	13
	local.get	13
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
	local.get	8
	i32.const	64
	i32.add 
	local.get	9
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	13
	local.get	13
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
	local.get	8
	i32.const	64
	i32.add 
	local.get	9
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	13
	local.get	13
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
	local.get	8
	i32.const	64
	i32.add 
	local.get	9
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	9
	local.get	9
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
	local.get	12
	local.get	11
	i32.const	4
	i32.add 
	local.tee	11
	i32.ne  
	br_if   	0                               # 0: up to label105
.LBB6_6:                                # %.preheader221.preheader.loopexit.unr-lcssa
	end_loop
	end_block                               # label104:
	local.get	10
	i32.eqz
	br_if   	0                               # 0: down to label103
# %bb.7:                                # %.lr.ph.epil.preheader
	local.get	1
	local.get	11
	i32.add 
	local.set	9
.LBB6_8:                                # %.lr.ph.epil
                                        # =>This Inner Loop Header: Depth=1
	loop    	                                # label106:
	local.get	8
	i32.const	64
	i32.add 
	local.get	9
	i32.load8_u	0
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	11
	local.get	11
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
	local.get	9
	i32.const	1
	i32.add 
	local.set	9
	local.get	10
	i32.const	-1
	i32.add 
	local.tee	10
	br_if   	0                               # 0: up to label106
.LBB6_9:                                # %.preheader221.preheader
	end_loop
	end_block                               # label103:
	local.get	8
	i32.const	64
	i32.add 
	local.get	5
	i32.const	2
	i32.shl 
	i32.add 
	local.set	9
.LBB6_10:                               # %.preheader221
                                        # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label108:
	block   	
	local.get	9
	i32.load	0
	i32.eqz
	br_if   	0                               # 0: down to label109
# %bb.11:
	local.get	5
	local.set	11
	br      	2                               # 2: down to label107
.LBB6_12:                               #   in Loop: Header=BB6_10 Depth=1
	end_block                               # label109:
	local.get	9
	i32.const	-4
	i32.add 
	local.set	9
	i32.const	1
	local.set	11
	local.get	5
	i32.const	-1
	i32.add 
	local.tee	5
	i32.const	1
	i32.gt_u
	br_if   	0                               # 0: up to label108
.LBB6_13:                               # %.critedge
	end_loop
	end_block                               # label107:
	block   	
	local.get	7
	i32.eqz
	br_if   	0                               # 0: down to label110
# %bb.14:
	local.get	7
	local.get	4
	local.get	11
	local.get	4
	local.get	11
	i32.lt_u
	i32.select
	local.tee	4
	i32.store	0
.LBB6_15:
	end_block                               # label110:
	i32.const	0
	local.set	14
	local.get	8
	i32.const	0
	i32.store	0
	local.get	8
	local.get	8
	i32.load	64
	local.tee	13
	i32.store	4
	i32.const	0
	local.set	9
	block   	
	local.get	11
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label111
# %bb.16:                               # %.lr.ph239.preheader
	i32.const	1
	local.set	9
	local.get	11
	i32.const	-1
	i32.add 
	local.tee	5
	i32.const	1
	i32.and 
	local.set	15
	block   	
	block   	
	local.get	11
	i32.const	2
	i32.ne  
	br_if   	0                               # 0: down to label113
# %bb.17:
	i32.const	0
	local.set	5
	br      	1                               # 1: down to label112
.LBB6_18:                               # %.lr.ph239.preheader.new
	end_block                               # label113:
	local.get	5
	i32.const	-2
	i32.and 
	local.set	16
	local.get	8
	i32.const	64
	i32.add 
	i32.const	8
	i32.or  
	local.set	9
	local.get	8
	i32.const	12
	i32.or  
	local.set	5
	i32.const	0
	local.set	10
	i32.const	0
	local.set	12
.LBB6_19:                               # %.lr.ph239
                                        # =>This Inner Loop Header: Depth=1
	loop    	                                # label114:
	local.get	5
	i32.const	-4
	i32.add 
	local.get	9
	i32.const	-4
	i32.add 
	i32.load	0
	local.tee	7
	local.get	13
	i32.add 
	local.tee	13
	i32.store	0
	local.get	5
	local.get	9
	i32.load	0
	local.tee	17
	local.get	13
	i32.add 
	local.tee	13
	i32.store	0
	local.get	17
	local.get	10
	i32.const	2
	i32.shl 
	local.get	7
	i32.const	1
	i32.shl 
	i32.add 
	i32.add 
	local.set	10
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	5
	i32.const	8
	i32.add 
	local.set	5
	local.get	16
	local.get	12
	i32.const	2
	i32.add 
	local.tee	12
	i32.ne  
	br_if   	0                               # 0: up to label114
# %bb.20:                               # %._crit_edge.loopexit.unr-lcssa.loopexit
	end_loop
	local.get	12
	i32.const	1
	i32.add 
	local.set	9
	local.get	10
	i32.const	1
	i32.shl 
	local.set	5
.LBB6_21:                               # %._crit_edge.loopexit.unr-lcssa
	end_block                               # label112:
	block   	
	local.get	15
	i32.eqz
	br_if   	0                               # 0: down to label115
# %bb.22:                               # %.lr.ph239.epil
	local.get	9
	i32.const	2
	i32.shl 
	local.tee	9
	local.get	8
	i32.add 
	i32.const	4
	i32.add 
	local.get	8
	i32.const	64
	i32.add 
	local.get	9
	i32.add 
	i32.load	0
	local.tee	9
	local.get	13
	i32.add 
	i32.store	0
	local.get	9
	local.get	5
	i32.add 
	local.set	10
.LBB6_23:                               # %._crit_edge.loopexit
	end_block                               # label115:
	local.get	10
	i32.const	1
	i32.shl 
	local.set	9
.LBB6_24:                               # %._crit_edge
	end_block                               # label111:
	local.get	8
	i32.const	64
	i32.add 
	local.get	11
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.get	9
	i32.add 
	local.set	17
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label116
# %bb.25:                               # %.lr.ph243.preheader
	local.get	2
	i32.const	1
	i32.and 
	local.set	7
	i32.const	0
	local.set	9
	block   	
	local.get	2
	i32.const	1
	i32.eq  
	br_if   	0                               # 0: down to label117
# %bb.26:                               # %.lr.ph243.preheader.new
	local.get	2
	i32.const	-2
	i32.and 
	local.set	12
	i32.const	0
	local.set	9
.LBB6_27:                               # %.lr.ph243
                                        # =>This Inner Loop Header: Depth=1
	loop    	                                # label118:
	local.get	6
	local.get	8
	local.get	1
	local.get	9
	i32.add 
	local.tee	5
	i32.load8_u	0
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	10
	i32.load	0
	local.tee	13
	i32.const	1
	i32.shl 
	i32.add 
	local.get	9
	i32.store16	0
	local.get	10
	local.get	13
	i32.const	1
	i32.add 
	i32.store	0
	local.get	8
	local.get	5
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	5
	local.get	5
	i32.load	0
	local.tee	5
	i32.const	1
	i32.add 
	i32.store	0
	local.get	6
	local.get	5
	i32.const	1
	i32.shl 
	i32.add 
	local.get	9
	i32.const	1
	i32.add 
	i32.store16	0
	local.get	12
	local.get	9
	i32.const	2
	i32.add 
	local.tee	9
	i32.ne  
	br_if   	0                               # 0: up to label118
.LBB6_28:                               # %._crit_edge244.loopexit.unr-lcssa
	end_loop
	end_block                               # label117:
	block   	
	local.get	7
	i32.eqz
	br_if   	0                               # 0: down to label119
# %bb.29:                               # %.lr.ph243.epil
	local.get	8
	local.get	1
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	5
	local.get	5
	i32.load	0
	local.tee	5
	i32.const	1
	i32.add 
	i32.store	0
	local.get	6
	local.get	5
	i32.const	1
	i32.shl 
	i32.add 
	local.get	9
	i32.store16	0
.LBB6_30:                               # %._crit_edge244.loopexit
	end_block                               # label119:
	local.get	8
	i32.load	0
	local.set	14
.LBB6_31:                               # %._crit_edge244
	end_block                               # label116:
	block   	
	block   	
	local.get	17
	i32.const	1
	local.get	11
	i32.shl 
	local.tee	9
	i32.le_u
	br_if   	0                               # 0: down to label121
# %bb.32:
	i32.const	0
	local.set	10
	br      	1                               # 1: down to label120
.LBB6_33:
	end_block                               # label121:
	local.get	6
	local.get	14
	i32.const	1
	i32.shl 
	i32.add 
	local.set	7
	block   	
	block   	
	block   	
	local.get	17
	local.get	9
	i32.lt_u
	br_if   	0                               # 0: down to label124
# %bb.34:                               # %.preheader220.preheader
	local.get	8
	i32.const	64
	i32.add 
	i32.const	4
	i32.or  
	local.set	9
	i32.const	0
	local.set	12
.LBB6_35:                               # %.preheader220
                                        # =>This Inner Loop Header: Depth=1
	loop    	                                # label125:
	local.get	12
	i32.const	1
	i32.add 
	local.set	12
	local.get	9
	i32.load	0
	local.set	1
	local.get	9
	i32.const	4
	i32.add 
	local.set	9
	local.get	1
	i32.eqz
	br_if   	0                               # 0: up to label125
# %bb.36:
	end_loop
	i32.const	0
	local.set	15
	local.get	12
	local.get	4
	i32.le_u
	br_if   	1                               # 1: down to label123
# %bb.37:
	i32.const	0
	local.set	13
	br      	2                               # 2: down to label122
.LBB6_38:
	end_block                               # label124:
	block   	
	block   	
	local.get	17
	br_if   	0                               # 0: down to label127
# %bb.39:
	i32.const	0
	local.set	9
	br      	1                               # 1: down to label126
.LBB6_40:
	end_block                               # label127:
	i32.const	0
	local.set	10
	local.get	17
	i32.const	1
	local.get	11
	i32.const	-1
	i32.add 
	i32.shl 
	i32.ne  
	br_if   	3                               # 3: down to label120
# %bb.41:
	local.get	8
	i32.load	68
	i32.const	1
	i32.ne  
	br_if   	3                               # 3: down to label120
# %bb.42:
	local.get	7
	i32.load16_u	0
	local.set	9
.LBB6_43:
	end_block                               # label126:
	local.get	3
	local.get	9
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.const	257
	i32.add 
	local.set	5
	i32.const	1
	local.set	10
	i32.const	1
	local.set	9
.LBB6_44:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label128:
	local.get	0
	local.get	5
	i32.store	0
	local.get	0
	i32.const	4
	i32.add 
	local.set	0
	local.get	9
	local.get	4
	i32.shr_u
	local.set	8
	local.get	9
	i32.const	1
	i32.add 
	local.set	9
	local.get	8
	i32.eqz
	br_if   	0                               # 0: up to label128
	br      	3                               # 3: down to label120
.LBB6_45:                               # %.preheader219.preheader
	end_loop
	end_block                               # label123:
	i32.const	1
	local.get	12
	i32.shl 
	local.set	5
	local.get	8
	i32.const	64
	i32.add 
	i32.const	4
	i32.or  
	local.set	6
	i32.const	0
	local.set	13
.LBB6_46:                               # %.preheader219
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB6_47 Depth 2
                                        #     Child Loop BB6_62 Depth 2
	loop    	                                # label129:
	local.get	5
	i32.const	-1
	i32.add 
	local.set	9
	local.get	12
	i32.const	257
	i32.mul 
	local.set	10
.LBB6_47:                               #   Parent Loop BB6_46 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label130:
	local.get	0
	local.get	13
	i32.const	2
	i32.shl 
	i32.add 
	local.get	10
	local.get	3
	local.get	7
	i32.load16_u	0
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.add 
	i32.store	0
	block   	
	local.get	13
	local.get	9
	i32.ne  
	br_if   	0                               # 0: down to label131
# %bb.48:                               # %.preheader
	i32.const	1
	local.set	10
	local.get	4
	local.get	12
	i32.le_u
	br_if   	4                               # 4: down to label120
# %bb.49:                               # %.lr.ph258.preheader
	local.get	12
	i32.const	1
	i32.add 
	local.set	9
	block   	
	local.get	4
	local.get	12
	i32.sub 
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label132
# %bb.50:                               # %.lr.ph258.prol
	block   	
	local.get	5
	i32.const	2
	i32.shl 
	local.tee	8
	i32.eqz
	br_if   	0                               # 0: down to label133
# %bb.51:                               # %.lr.ph258.prol
	local.get	0
	local.get	8
	i32.add 
	local.get	0
	local.get	8
	memory.copy	0, 0
.LBB6_52:                               # %.lr.ph258.prol
	end_block                               # label133:
	local.get	12
	i32.const	1
	i32.add 
	local.set	12
	local.get	5
	i32.const	1
	i32.shl 
	local.set	5
.LBB6_53:                               # %.lr.ph258.prol.loopexit
	end_block                               # label132:
	local.get	4
	local.get	9
	i32.eq  
	br_if   	4                               # 4: down to label120
# %bb.54:                               # %.lr.ph258.preheader386
	local.get	4
	local.get	12
	i32.sub 
	local.set	8
.LBB6_55:                               # %.lr.ph258
                                        # =>This Inner Loop Header: Depth=1
	loop    	                                # label134:
	block   	
	local.get	5
	i32.const	2
	i32.shl 
	local.tee	9
	i32.eqz
	br_if   	0                               # 0: down to label135
# %bb.56:                               # %.lr.ph258
                                        #   in Loop: Header=BB6_55 Depth=1
	local.get	0
	local.get	9
	i32.add 
	local.get	0
	local.get	9
	memory.copy	0, 0
.LBB6_57:                               # %.lr.ph258
                                        #   in Loop: Header=BB6_55 Depth=1
	end_block                               # label135:
	block   	
	local.get	5
	i32.const	3
	i32.shl 
	local.tee	5
	i32.eqz
	br_if   	0                               # 0: down to label136
# %bb.58:                               # %.lr.ph258
                                        #   in Loop: Header=BB6_55 Depth=1
	local.get	0
	local.get	5
	i32.add 
	local.get	0
	local.get	5
	memory.copy	0, 0
.LBB6_59:                               # %.lr.ph258
                                        #   in Loop: Header=BB6_55 Depth=1
	end_block                               # label136:
	local.get	9
	local.set	5
	local.get	8
	i32.const	-2
	i32.add 
	local.tee	8
	i32.eqz
	br_if   	5                               # 5: down to label120
	br      	0                               # 0: up to label134
.LBB6_60:                               # %.thread
                                        #   in Loop: Header=BB6_47 Depth=2
	end_loop
	end_block                               # label131:
	i32.const	1
	local.get	13
	local.get	9
	i32.xor 
	i32.clz 
	i32.const	31
	i32.xor 
	i32.shl 
	local.tee	11
	i32.const	-1
	i32.add 
	local.get	13
	i32.and 
	local.get	11
	i32.or  
	local.set	13
	local.get	7
	i32.const	2
	i32.add 
	local.set	7
	local.get	1
	i32.const	-1
	i32.add 
	local.tee	1
	br_if   	0                               # 0: up to label130
# %bb.61:                               # %.preheader218.preheader
                                        #   in Loop: Header=BB6_46 Depth=1
	end_loop
	local.get	6
	local.get	12
	i32.const	2
	i32.shl 
	i32.add 
	local.set	9
.LBB6_62:                               # %.preheader218
                                        #   Parent Loop BB6_46 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label137:
	block   	
	local.get	12
	i32.const	1
	i32.add 
	local.tee	12
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label138
# %bb.63:                               #   in Loop: Header=BB6_62 Depth=2
	block   	
	local.get	5
	i32.const	2
	i32.shl 
	local.tee	11
	i32.eqz
	br_if   	0                               # 0: down to label139
# %bb.64:                               #   in Loop: Header=BB6_62 Depth=2
	local.get	0
	local.get	11
	i32.add 
	local.get	0
	local.get	11
	memory.copy	0, 0
.LBB6_65:                               #   in Loop: Header=BB6_62 Depth=2
	end_block                               # label139:
	local.get	5
	i32.const	1
	i32.shl 
	local.set	5
.LBB6_66:                               #   in Loop: Header=BB6_62 Depth=2
	end_block                               # label138:
	local.get	9
	i32.load	0
	local.set	1
	local.get	9
	i32.const	4
	i32.add 
	local.set	9
	local.get	1
	i32.eqz
	br_if   	0                               # 0: up to label137
# %bb.67:                               #   in Loop: Header=BB6_46 Depth=1
	end_loop
	local.get	12
	local.get	4
	i32.le_u
	br_if   	0                               # 0: up to label129
.LBB6_68:                               # %._crit_edge251
	end_loop
	end_block                               # label122:
	local.get	4
	i32.const	49152
	i32.or  
	local.set	18
	i32.const	1
	local.get	4
	i32.shl 
	local.tee	16
	i32.const	-1
	i32.add 
	local.set	19
	local.get	8
	i32.const	64
	i32.add 
	i32.const	4
	i32.or  
	local.set	20
	i32.const	-1
	local.set	9
.LBB6_69:                               # %.loopexit.outer
                                        # =>This Loop Header: Depth=1
                                        #     Child Loop BB6_70 Depth 2
                                        #       Child Loop BB6_74 Depth 3
                                        #       Child Loop BB6_77 Depth 3
                                        #     Child Loop BB6_81 Depth 2
	loop    	                                # label140:
	local.get	20
	local.get	12
	i32.const	2
	i32.shl 
	i32.add 
	local.set	17
	i32.const	-1
	local.get	12
	i32.shl 
	i32.const	-1
	i32.xor 
	local.set	14
	local.get	12
	local.get	4
	i32.sub 
	local.tee	21
	i32.const	257
	i32.mul 
	local.set	22
	i32.const	1
	local.get	21
	i32.shl 
	local.tee	11
	i32.const	2
	i32.shl 
	local.set	6
.LBB6_70:                               # %.loopexit
                                        #   Parent Loop BB6_69 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB6_74 Depth 3
                                        #       Child Loop BB6_77 Depth 3
	loop    	                                # label141:
	block   	
	block   	
	local.get	13
	local.get	19
	i32.and 
	local.tee	2
	local.get	9
	i32.ne  
	br_if   	0                               # 0: down to label143
# %bb.71:                               #   in Loop: Header=BB6_70 Depth=2
	local.get	16
	local.set	5
	local.get	9
	local.set	2
	br      	1                               # 1: down to label142
.LBB6_72:                               #   in Loop: Header=BB6_70 Depth=2
	end_block                               # label143:
	local.get	21
	local.set	8
	local.get	11
	local.set	10
	block   	
	local.get	1
	local.get	11
	i32.ge_u
	br_if   	0                               # 0: down to label144
# %bb.73:                               # %.lr.ph262.preheader
                                        #   in Loop: Header=BB6_70 Depth=2
	local.get	17
	local.set	9
	local.get	21
	local.set	8
	local.get	1
	local.set	5
.LBB6_74:                               # %.lr.ph262
                                        #   Parent Loop BB6_69 Depth=1
                                        #     Parent Loop BB6_70 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label145:
	local.get	9
	i32.load	0
	local.set	10
	local.get	9
	i32.const	4
	i32.add 
	local.set	9
	local.get	10
	local.get	5
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	5
	i32.const	1
	local.get	8
	i32.const	1
	i32.add 
	local.tee	8
	i32.shl 
	local.tee	10
	i32.lt_u
	br_if   	0                               # 0: up to label145
.LBB6_75:                               # %._crit_edge263
                                        #   in Loop: Header=BB6_70 Depth=2
	end_loop
	end_block                               # label144:
	local.get	0
	local.get	2
	i32.const	2
	i32.shl 
	i32.add 
	local.get	16
	i32.const	16
	i32.shl 
	local.get	8
	i32.const	8
	i32.shl 
	i32.or  
	local.get	18
	i32.or  
	i32.store	0
	local.get	10
	local.get	16
	i32.add 
	local.set	5
	local.get	16
	local.set	15
.LBB6_76:                               # %._crit_edge292
                                        #   in Loop: Header=BB6_70 Depth=2
	end_block                               # label142:
	local.get	0
	local.get	15
	local.get	13
	local.get	4
	i32.shr_u
	i32.add 
	local.tee	8
	i32.const	2
	i32.shl 
	i32.add 
	local.set	9
	local.get	22
	local.get	3
	local.get	7
	i32.load16_u	0
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.add 
	local.set	10
.LBB6_77:                               #   Parent Loop BB6_69 Depth=1
                                        #     Parent Loop BB6_70 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label146:
	local.get	9
	local.get	10
	i32.store	0
	local.get	9
	local.get	6
	i32.add 
	local.set	9
	local.get	8
	local.get	11
	i32.add 
	local.tee	8
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: up to label146
# %bb.78:                               #   in Loop: Header=BB6_70 Depth=2
	end_loop
	block   	
	local.get	13
	local.get	14
	i32.ne  
	br_if   	0                               # 0: down to label147
# %bb.79:
	i32.const	1
	return
.LBB6_80:                               #   in Loop: Header=BB6_70 Depth=2
	end_block                               # label147:
	i32.const	1
	local.get	13
	local.get	14
	i32.xor 
	i32.clz 
	i32.const	31
	i32.xor 
	i32.shl 
	local.tee	9
	i32.const	-1
	i32.add 
	local.get	13
	i32.and 
	local.get	9
	i32.or  
	local.set	13
	local.get	7
	i32.const	2
	i32.add 
	local.set	7
	local.get	5
	local.set	16
	local.get	2
	local.set	9
	local.get	1
	i32.const	-1
	i32.add 
	local.tee	1
	br_if   	0                               # 0: up to label141
.LBB6_81:                               # %.lr.ph268
                                        #   Parent Loop BB6_69 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	end_loop
	loop    	                                # label148:
	local.get	12
	i32.const	1
	i32.add 
	local.set	12
	local.get	17
	i32.load	0
	local.set	1
	local.get	17
	i32.const	4
	i32.add 
	local.set	17
	local.get	1
	i32.eqz
	br_if   	0                               # 0: up to label148
# %bb.82:                               #   in Loop: Header=BB6_69 Depth=1
	end_loop
	local.get	5
	local.set	16
	local.get	2
	local.set	9
	br      	0                               # 0: up to label140
.LBB6_83:                               # %.thread212
	end_loop
	end_block                               # label120:
	local.get	10
                                        # fallthrough-return
	end_function
                                        # -- End function
	.type	term_bank_decompressor,@object  # @term_bank_decompressor
	.section	.bss.term_bank_decompressor,"",@
	.p2align	2, 0x0
term_bank_decompressor:
	.skip	11564
	.size	term_bank_decompressor, 11564

	.type	deflate_decompress_default.deflate_precode_lens_permutation,@object # @deflate_decompress_default.deflate_precode_lens_permutation
	.section	.rodata.deflate_decompress_default.deflate_precode_lens_permutation,"",@
	.p2align	4, 0x0
deflate_decompress_default.deflate_precode_lens_permutation:
	.ascii	"\020\021\022\000\b\007\t\006\n\005\013\004\f\003\r\002\016\001\017"
	.size	deflate_decompress_default.deflate_precode_lens_permutation, 19

	.type	precode_decode_results,@object  # @precode_decode_results
	.section	.rodata.precode_decode_results,"",@
	.p2align	4, 0x0
precode_decode_results:
	.int32	0                               # 0x0
	.int32	65536                           # 0x10000
	.int32	131072                          # 0x20000
	.int32	196608                          # 0x30000
	.int32	262144                          # 0x40000
	.int32	327680                          # 0x50000
	.int32	393216                          # 0x60000
	.int32	458752                          # 0x70000
	.int32	524288                          # 0x80000
	.int32	589824                          # 0x90000
	.int32	655360                          # 0xa0000
	.int32	720896                          # 0xb0000
	.int32	786432                          # 0xc0000
	.int32	851968                          # 0xd0000
	.int32	917504                          # 0xe0000
	.int32	983040                          # 0xf0000
	.int32	1048576                         # 0x100000
	.int32	1114112                         # 0x110000
	.int32	1179648                         # 0x120000
	.size	precode_decode_results, 76

	.type	offset_decode_results,@object   # @offset_decode_results
	.section	.rodata.offset_decode_results,"",@
	.p2align	4, 0x0
offset_decode_results:
	.int32	65536                           # 0x10000
	.int32	131072                          # 0x20000
	.int32	196608                          # 0x30000
	.int32	262144                          # 0x40000
	.int32	327681                          # 0x50001
	.int32	458753                          # 0x70001
	.int32	589826                          # 0x90002
	.int32	851970                          # 0xd0002
	.int32	1114115                         # 0x110003
	.int32	1638403                         # 0x190003
	.int32	2162692                         # 0x210004
	.int32	3211268                         # 0x310004
	.int32	4259845                         # 0x410005
	.int32	6356997                         # 0x610005
	.int32	8454150                         # 0x810006
	.int32	12648454                        # 0xc10006
	.int32	16842759                        # 0x1010007
	.int32	25231367                        # 0x1810007
	.int32	33619976                        # 0x2010008
	.int32	50397192                        # 0x3010008
	.int32	67174409                        # 0x4010009
	.int32	100728841                       # 0x6010009
	.int32	134283274                       # 0x801000a
	.int32	201392138                       # 0xc01000a
	.int32	268501003                       # 0x1001000b
	.int32	402718731                       # 0x1801000b
	.int32	536936460                       # 0x2001000c
	.int32	805371916                       # 0x3001000c
	.int32	1073807373                      # 0x4001000d
	.int32	1610678285                      # 0x6001000d
	.int32	1610678285                      # 0x6001000d
	.int32	1610678285                      # 0x6001000d
	.size	offset_decode_results, 128

	.type	litlen_decode_results,@object   # @litlen_decode_results
	.section	.rodata.litlen_decode_results,"",@
	.p2align	4, 0x0
litlen_decode_results:
	.int32	2147483648                      # 0x80000000
	.int32	2147549184                      # 0x80010000
	.int32	2147614720                      # 0x80020000
	.int32	2147680256                      # 0x80030000
	.int32	2147745792                      # 0x80040000
	.int32	2147811328                      # 0x80050000
	.int32	2147876864                      # 0x80060000
	.int32	2147942400                      # 0x80070000
	.int32	2148007936                      # 0x80080000
	.int32	2148073472                      # 0x80090000
	.int32	2148139008                      # 0x800a0000
	.int32	2148204544                      # 0x800b0000
	.int32	2148270080                      # 0x800c0000
	.int32	2148335616                      # 0x800d0000
	.int32	2148401152                      # 0x800e0000
	.int32	2148466688                      # 0x800f0000
	.int32	2148532224                      # 0x80100000
	.int32	2148597760                      # 0x80110000
	.int32	2148663296                      # 0x80120000
	.int32	2148728832                      # 0x80130000
	.int32	2148794368                      # 0x80140000
	.int32	2148859904                      # 0x80150000
	.int32	2148925440                      # 0x80160000
	.int32	2148990976                      # 0x80170000
	.int32	2149056512                      # 0x80180000
	.int32	2149122048                      # 0x80190000
	.int32	2149187584                      # 0x801a0000
	.int32	2149253120                      # 0x801b0000
	.int32	2149318656                      # 0x801c0000
	.int32	2149384192                      # 0x801d0000
	.int32	2149449728                      # 0x801e0000
	.int32	2149515264                      # 0x801f0000
	.int32	2149580800                      # 0x80200000
	.int32	2149646336                      # 0x80210000
	.int32	2149711872                      # 0x80220000
	.int32	2149777408                      # 0x80230000
	.int32	2149842944                      # 0x80240000
	.int32	2149908480                      # 0x80250000
	.int32	2149974016                      # 0x80260000
	.int32	2150039552                      # 0x80270000
	.int32	2150105088                      # 0x80280000
	.int32	2150170624                      # 0x80290000
	.int32	2150236160                      # 0x802a0000
	.int32	2150301696                      # 0x802b0000
	.int32	2150367232                      # 0x802c0000
	.int32	2150432768                      # 0x802d0000
	.int32	2150498304                      # 0x802e0000
	.int32	2150563840                      # 0x802f0000
	.int32	2150629376                      # 0x80300000
	.int32	2150694912                      # 0x80310000
	.int32	2150760448                      # 0x80320000
	.int32	2150825984                      # 0x80330000
	.int32	2150891520                      # 0x80340000
	.int32	2150957056                      # 0x80350000
	.int32	2151022592                      # 0x80360000
	.int32	2151088128                      # 0x80370000
	.int32	2151153664                      # 0x80380000
	.int32	2151219200                      # 0x80390000
	.int32	2151284736                      # 0x803a0000
	.int32	2151350272                      # 0x803b0000
	.int32	2151415808                      # 0x803c0000
	.int32	2151481344                      # 0x803d0000
	.int32	2151546880                      # 0x803e0000
	.int32	2151612416                      # 0x803f0000
	.int32	2151677952                      # 0x80400000
	.int32	2151743488                      # 0x80410000
	.int32	2151809024                      # 0x80420000
	.int32	2151874560                      # 0x80430000
	.int32	2151940096                      # 0x80440000
	.int32	2152005632                      # 0x80450000
	.int32	2152071168                      # 0x80460000
	.int32	2152136704                      # 0x80470000
	.int32	2152202240                      # 0x80480000
	.int32	2152267776                      # 0x80490000
	.int32	2152333312                      # 0x804a0000
	.int32	2152398848                      # 0x804b0000
	.int32	2152464384                      # 0x804c0000
	.int32	2152529920                      # 0x804d0000
	.int32	2152595456                      # 0x804e0000
	.int32	2152660992                      # 0x804f0000
	.int32	2152726528                      # 0x80500000
	.int32	2152792064                      # 0x80510000
	.int32	2152857600                      # 0x80520000
	.int32	2152923136                      # 0x80530000
	.int32	2152988672                      # 0x80540000
	.int32	2153054208                      # 0x80550000
	.int32	2153119744                      # 0x80560000
	.int32	2153185280                      # 0x80570000
	.int32	2153250816                      # 0x80580000
	.int32	2153316352                      # 0x80590000
	.int32	2153381888                      # 0x805a0000
	.int32	2153447424                      # 0x805b0000
	.int32	2153512960                      # 0x805c0000
	.int32	2153578496                      # 0x805d0000
	.int32	2153644032                      # 0x805e0000
	.int32	2153709568                      # 0x805f0000
	.int32	2153775104                      # 0x80600000
	.int32	2153840640                      # 0x80610000
	.int32	2153906176                      # 0x80620000
	.int32	2153971712                      # 0x80630000
	.int32	2154037248                      # 0x80640000
	.int32	2154102784                      # 0x80650000
	.int32	2154168320                      # 0x80660000
	.int32	2154233856                      # 0x80670000
	.int32	2154299392                      # 0x80680000
	.int32	2154364928                      # 0x80690000
	.int32	2154430464                      # 0x806a0000
	.int32	2154496000                      # 0x806b0000
	.int32	2154561536                      # 0x806c0000
	.int32	2154627072                      # 0x806d0000
	.int32	2154692608                      # 0x806e0000
	.int32	2154758144                      # 0x806f0000
	.int32	2154823680                      # 0x80700000
	.int32	2154889216                      # 0x80710000
	.int32	2154954752                      # 0x80720000
	.int32	2155020288                      # 0x80730000
	.int32	2155085824                      # 0x80740000
	.int32	2155151360                      # 0x80750000
	.int32	2155216896                      # 0x80760000
	.int32	2155282432                      # 0x80770000
	.int32	2155347968                      # 0x80780000
	.int32	2155413504                      # 0x80790000
	.int32	2155479040                      # 0x807a0000
	.int32	2155544576                      # 0x807b0000
	.int32	2155610112                      # 0x807c0000
	.int32	2155675648                      # 0x807d0000
	.int32	2155741184                      # 0x807e0000
	.int32	2155806720                      # 0x807f0000
	.int32	2155872256                      # 0x80800000
	.int32	2155937792                      # 0x80810000
	.int32	2156003328                      # 0x80820000
	.int32	2156068864                      # 0x80830000
	.int32	2156134400                      # 0x80840000
	.int32	2156199936                      # 0x80850000
	.int32	2156265472                      # 0x80860000
	.int32	2156331008                      # 0x80870000
	.int32	2156396544                      # 0x80880000
	.int32	2156462080                      # 0x80890000
	.int32	2156527616                      # 0x808a0000
	.int32	2156593152                      # 0x808b0000
	.int32	2156658688                      # 0x808c0000
	.int32	2156724224                      # 0x808d0000
	.int32	2156789760                      # 0x808e0000
	.int32	2156855296                      # 0x808f0000
	.int32	2156920832                      # 0x80900000
	.int32	2156986368                      # 0x80910000
	.int32	2157051904                      # 0x80920000
	.int32	2157117440                      # 0x80930000
	.int32	2157182976                      # 0x80940000
	.int32	2157248512                      # 0x80950000
	.int32	2157314048                      # 0x80960000
	.int32	2157379584                      # 0x80970000
	.int32	2157445120                      # 0x80980000
	.int32	2157510656                      # 0x80990000
	.int32	2157576192                      # 0x809a0000
	.int32	2157641728                      # 0x809b0000
	.int32	2157707264                      # 0x809c0000
	.int32	2157772800                      # 0x809d0000
	.int32	2157838336                      # 0x809e0000
	.int32	2157903872                      # 0x809f0000
	.int32	2157969408                      # 0x80a00000
	.int32	2158034944                      # 0x80a10000
	.int32	2158100480                      # 0x80a20000
	.int32	2158166016                      # 0x80a30000
	.int32	2158231552                      # 0x80a40000
	.int32	2158297088                      # 0x80a50000
	.int32	2158362624                      # 0x80a60000
	.int32	2158428160                      # 0x80a70000
	.int32	2158493696                      # 0x80a80000
	.int32	2158559232                      # 0x80a90000
	.int32	2158624768                      # 0x80aa0000
	.int32	2158690304                      # 0x80ab0000
	.int32	2158755840                      # 0x80ac0000
	.int32	2158821376                      # 0x80ad0000
	.int32	2158886912                      # 0x80ae0000
	.int32	2158952448                      # 0x80af0000
	.int32	2159017984                      # 0x80b00000
	.int32	2159083520                      # 0x80b10000
	.int32	2159149056                      # 0x80b20000
	.int32	2159214592                      # 0x80b30000
	.int32	2159280128                      # 0x80b40000
	.int32	2159345664                      # 0x80b50000
	.int32	2159411200                      # 0x80b60000
	.int32	2159476736                      # 0x80b70000
	.int32	2159542272                      # 0x80b80000
	.int32	2159607808                      # 0x80b90000
	.int32	2159673344                      # 0x80ba0000
	.int32	2159738880                      # 0x80bb0000
	.int32	2159804416                      # 0x80bc0000
	.int32	2159869952                      # 0x80bd0000
	.int32	2159935488                      # 0x80be0000
	.int32	2160001024                      # 0x80bf0000
	.int32	2160066560                      # 0x80c00000
	.int32	2160132096                      # 0x80c10000
	.int32	2160197632                      # 0x80c20000
	.int32	2160263168                      # 0x80c30000
	.int32	2160328704                      # 0x80c40000
	.int32	2160394240                      # 0x80c50000
	.int32	2160459776                      # 0x80c60000
	.int32	2160525312                      # 0x80c70000
	.int32	2160590848                      # 0x80c80000
	.int32	2160656384                      # 0x80c90000
	.int32	2160721920                      # 0x80ca0000
	.int32	2160787456                      # 0x80cb0000
	.int32	2160852992                      # 0x80cc0000
	.int32	2160918528                      # 0x80cd0000
	.int32	2160984064                      # 0x80ce0000
	.int32	2161049600                      # 0x80cf0000
	.int32	2161115136                      # 0x80d00000
	.int32	2161180672                      # 0x80d10000
	.int32	2161246208                      # 0x80d20000
	.int32	2161311744                      # 0x80d30000
	.int32	2161377280                      # 0x80d40000
	.int32	2161442816                      # 0x80d50000
	.int32	2161508352                      # 0x80d60000
	.int32	2161573888                      # 0x80d70000
	.int32	2161639424                      # 0x80d80000
	.int32	2161704960                      # 0x80d90000
	.int32	2161770496                      # 0x80da0000
	.int32	2161836032                      # 0x80db0000
	.int32	2161901568                      # 0x80dc0000
	.int32	2161967104                      # 0x80dd0000
	.int32	2162032640                      # 0x80de0000
	.int32	2162098176                      # 0x80df0000
	.int32	2162163712                      # 0x80e00000
	.int32	2162229248                      # 0x80e10000
	.int32	2162294784                      # 0x80e20000
	.int32	2162360320                      # 0x80e30000
	.int32	2162425856                      # 0x80e40000
	.int32	2162491392                      # 0x80e50000
	.int32	2162556928                      # 0x80e60000
	.int32	2162622464                      # 0x80e70000
	.int32	2162688000                      # 0x80e80000
	.int32	2162753536                      # 0x80e90000
	.int32	2162819072                      # 0x80ea0000
	.int32	2162884608                      # 0x80eb0000
	.int32	2162950144                      # 0x80ec0000
	.int32	2163015680                      # 0x80ed0000
	.int32	2163081216                      # 0x80ee0000
	.int32	2163146752                      # 0x80ef0000
	.int32	2163212288                      # 0x80f00000
	.int32	2163277824                      # 0x80f10000
	.int32	2163343360                      # 0x80f20000
	.int32	2163408896                      # 0x80f30000
	.int32	2163474432                      # 0x80f40000
	.int32	2163539968                      # 0x80f50000
	.int32	2163605504                      # 0x80f60000
	.int32	2163671040                      # 0x80f70000
	.int32	2163736576                      # 0x80f80000
	.int32	2163802112                      # 0x80f90000
	.int32	2163867648                      # 0x80fa0000
	.int32	2163933184                      # 0x80fb0000
	.int32	2163998720                      # 0x80fc0000
	.int32	2164064256                      # 0x80fd0000
	.int32	2164129792                      # 0x80fe0000
	.int32	2164195328                      # 0x80ff0000
	.int32	40960                           # 0xa000
	.int32	196608                          # 0x30000
	.int32	262144                          # 0x40000
	.int32	327680                          # 0x50000
	.int32	393216                          # 0x60000
	.int32	458752                          # 0x70000
	.int32	524288                          # 0x80000
	.int32	589824                          # 0x90000
	.int32	655360                          # 0xa0000
	.int32	720897                          # 0xb0001
	.int32	851969                          # 0xd0001
	.int32	983041                          # 0xf0001
	.int32	1114113                         # 0x110001
	.int32	1245186                         # 0x130002
	.int32	1507330                         # 0x170002
	.int32	1769474                         # 0x1b0002
	.int32	2031618                         # 0x1f0002
	.int32	2293763                         # 0x230003
	.int32	2818051                         # 0x2b0003
	.int32	3342339                         # 0x330003
	.int32	3866627                         # 0x3b0003
	.int32	4390916                         # 0x430004
	.int32	5439492                         # 0x530004
	.int32	6488068                         # 0x630004
	.int32	7536644                         # 0x730004
	.int32	8585221                         # 0x830005
	.int32	10682373                        # 0xa30005
	.int32	12779525                        # 0xc30005
	.int32	14876677                        # 0xe30005
	.int32	16908288                        # 0x1020000
	.int32	16908288                        # 0x1020000
	.int32	16908288                        # 0x1020000
	.size	litlen_decode_results, 1152

	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.size	libdeflate_default_malloc_func, 4
	.size	libdeflate_default_free_func, 4
	.section	.custom_section.producers,"",@
	.int8	1
	.int8	12
	.ascii	"processed-by"
	.int8	1
	.int8	12
	.ascii	"Ubuntu clang"
	.int8	17
	.ascii	"21.1.8 (6ubuntu1)"
	.section	.rodata.litlen_decode_results,"",@
	.section	.custom_section.target_features,"",@
	.int8	10
	.int8	43
	.int8	7
	.ascii	"atomics"
	.int8	43
	.int8	11
	.ascii	"bulk-memory"
	.int8	43
	.int8	15
	.ascii	"bulk-memory-opt"
	.int8	43
	.int8	22
	.ascii	"call-indirect-overlong"
	.int8	43
	.int8	10
	.ascii	"multivalue"
	.int8	43
	.int8	15
	.ascii	"mutable-globals"
	.int8	43
	.int8	19
	.ascii	"nontrapping-fptoint"
	.int8	43
	.int8	15
	.ascii	"reference-types"
	.int8	43
	.int8	8
	.ascii	"sign-ext"
	.int8	43
	.int8	7
	.ascii	"simd128"
	.section	.rodata.litlen_decode_results,"",@
