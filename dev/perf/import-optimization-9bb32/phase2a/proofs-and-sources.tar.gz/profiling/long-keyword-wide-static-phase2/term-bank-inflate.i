# 1 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/term-bank-inflate.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 374 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/term-bank-inflate.c" 2
# 12 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/term-bank-inflate.c"
# 1 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c" 1
# 45 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
# 1 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/lib_common.h" 1
# 40 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/lib_common.h"
# 1 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h" 1
# 31 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
# 1 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h" 1







# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 1 3
# 84 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 3
# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_header_macro.h" 1 3
# 85 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 2 3



# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_ptrdiff_t.h" 1 3
# 18 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_ptrdiff_t.h" 3
typedef long int ptrdiff_t;
# 89 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 2 3




# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_size_t.h" 1 3
# 18 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_size_t.h" 3
typedef long unsigned int size_t;
# 94 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 2 3
# 103 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 3
# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_wchar_t.h" 1 3
# 24 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_wchar_t.h" 3
typedef int wchar_t;
# 104 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 2 3




# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_null.h" 1 3
# 109 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 2 3
# 123 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 3
# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_max_align_t.h" 1 3
# 19 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_max_align_t.h" 3
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;
# 124 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 2 3




# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_offsetof.h" 1 3
# 129 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 2 3
# 9 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h" 2
# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stdint.h" 1 3
# 100 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stdint.h" 3
typedef long long int int64_t;

typedef long long unsigned int uint64_t;
# 122 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stdint.h" 3
typedef int64_t int_least64_t;
typedef uint64_t uint_least64_t;
typedef int64_t int_fast64_t;
typedef uint64_t uint_fast64_t;
# 197 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stdint.h" 3
typedef int int32_t;




typedef unsigned int uint32_t;
# 220 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stdint.h" 3
typedef int32_t int_least32_t;
typedef uint32_t uint_least32_t;
typedef int32_t int_fast32_t;
typedef uint32_t uint_fast32_t;
# 245 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stdint.h" 3
typedef short int16_t;

typedef unsigned short uint16_t;
# 259 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stdint.h" 3
typedef int16_t int_least16_t;
typedef uint16_t uint_least16_t;
typedef int16_t int_fast16_t;
typedef uint16_t uint_fast16_t;





typedef signed char int8_t;

typedef unsigned char uint8_t;







typedef int8_t int_least8_t;
typedef uint8_t uint_least8_t;
typedef int8_t int_fast8_t;
typedef uint8_t uint_fast8_t;
# 295 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stdint.h" 3
typedef long int intptr_t;






typedef long unsigned int uintptr_t;





typedef long long int intmax_t;
typedef long long unsigned int uintmax_t;
# 10 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h" 2
# 37 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
struct libdeflate_compressor;
struct libdeflate_options;
# 59 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
__attribute__((visibility("default"))) struct libdeflate_compressor *
libdeflate_alloc_compressor(int compression_level);




__attribute__((visibility("default"))) struct libdeflate_compressor *
libdeflate_alloc_compressor_ex(int compression_level,
          const struct libdeflate_options *options);
# 85 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
__attribute__((visibility("default"))) size_t
libdeflate_deflate_compress(struct libdeflate_compressor *compressor,
       const void *in, size_t in_nbytes,
       void *out, size_t out_nbytes_avail);
# 114 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
__attribute__((visibility("default"))) size_t
libdeflate_deflate_compress_bound(struct libdeflate_compressor *compressor,
      size_t in_nbytes);





__attribute__((visibility("default"))) size_t
libdeflate_zlib_compress(struct libdeflate_compressor *compressor,
    const void *in, size_t in_nbytes,
    void *out, size_t out_nbytes_avail);






__attribute__((visibility("default"))) size_t
libdeflate_zlib_compress_bound(struct libdeflate_compressor *compressor,
          size_t in_nbytes);





__attribute__((visibility("default"))) size_t
libdeflate_gzip_compress(struct libdeflate_compressor *compressor,
    const void *in, size_t in_nbytes,
    void *out, size_t out_nbytes_avail);






__attribute__((visibility("default"))) size_t
libdeflate_gzip_compress_bound(struct libdeflate_compressor *compressor,
          size_t in_nbytes);






__attribute__((visibility("default"))) void
libdeflate_free_compressor(struct libdeflate_compressor *compressor);





struct libdeflate_decompressor;
struct libdeflate_options;
# 181 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
__attribute__((visibility("default"))) struct libdeflate_decompressor *
libdeflate_alloc_decompressor(void);




__attribute__((visibility("default"))) struct libdeflate_decompressor *
libdeflate_alloc_decompressor_ex(const struct libdeflate_options *options);





enum libdeflate_result {

 LIBDEFLATE_SUCCESS = 0,



 LIBDEFLATE_BAD_DATA = 1,



 LIBDEFLATE_SHORT_OUTPUT = 2,



 LIBDEFLATE_INSUFFICIENT_SPACE = 3,
};
# 242 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
__attribute__((visibility("default"))) enum libdeflate_result
libdeflate_deflate_decompress(struct libdeflate_decompressor *decompressor,
         const void *in, size_t in_nbytes,
         void *out, size_t out_nbytes_avail,
         size_t *actual_out_nbytes_ret);







__attribute__((visibility("default"))) enum libdeflate_result
libdeflate_deflate_decompress_ex(struct libdeflate_decompressor *decompressor,
     const void *in, size_t in_nbytes,
     void *out, size_t out_nbytes_avail,
     size_t *actual_in_nbytes_ret,
     size_t *actual_out_nbytes_ret);
# 269 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
__attribute__((visibility("default"))) enum libdeflate_result
libdeflate_zlib_decompress(struct libdeflate_decompressor *decompressor,
      const void *in, size_t in_nbytes,
      void *out, size_t out_nbytes_avail,
      size_t *actual_out_nbytes_ret);
# 282 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
__attribute__((visibility("default"))) enum libdeflate_result
libdeflate_zlib_decompress_ex(struct libdeflate_decompressor *decompressor,
         const void *in, size_t in_nbytes,
         void *out, size_t out_nbytes_avail,
         size_t *actual_in_nbytes_ret,
         size_t *actual_out_nbytes_ret);
# 297 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
__attribute__((visibility("default"))) enum libdeflate_result
libdeflate_gzip_decompress(struct libdeflate_decompressor *decompressor,
      const void *in, size_t in_nbytes,
      void *out, size_t out_nbytes_avail,
      size_t *actual_out_nbytes_ret);
# 310 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
__attribute__((visibility("default"))) enum libdeflate_result
libdeflate_gzip_decompress_ex(struct libdeflate_decompressor *decompressor,
         const void *in, size_t in_nbytes,
         void *out, size_t out_nbytes_avail,
         size_t *actual_in_nbytes_ret,
         size_t *actual_out_nbytes_ret);






__attribute__((visibility("default"))) void
libdeflate_free_decompressor(struct libdeflate_decompressor *decompressor);
# 335 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
__attribute__((visibility("default"))) uint32_t
libdeflate_adler32(uint32_t adler, const void *buffer, size_t len);
# 345 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
__attribute__((visibility("default"))) uint32_t
libdeflate_crc32(uint32_t crc, const void *buffer, size_t len);
# 363 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
__attribute__((visibility("default"))) void
libdeflate_set_memory_allocator(void *(*malloc_func)(size_t),
    void (*free_func)(void *));
# 379 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
struct libdeflate_options {






 size_t sizeof_options;
# 404 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../libdeflate.h"
 void *(*malloc_func)(size_t);
 void (*free_func)(void *);
};
# 32 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h" 2

# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stdbool.h" 1 3
# 34 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h" 2
# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 1 3
# 88 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 3
# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_ptrdiff_t.h" 1 3
# 89 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 2 3




# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_size_t.h" 1 3
# 94 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 2 3
# 103 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 3
# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_wchar_t.h" 1 3
# 104 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 2 3
# 128 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 3
# 1 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/__stddef_offsetof.h" 1 3
# 129 "/tmp/manabitan-native-9bb32/native-toolchain/lib/clang/21/include/stddef.h" 2 3
# 35 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h" 2
# 99 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
typedef int8_t s8;
typedef int16_t s16;
typedef int32_t s32;
typedef int64_t s64;
# 125 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
typedef uint64_t machine_word_t;
# 335 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
static inline __attribute__((always_inline)) u16 bswap16(u16 v)
{

 return __builtin_bswap16(v);





}


static inline __attribute__((always_inline)) u32 bswap32(u32 v)
{

 return __builtin_bswap32(v);
# 359 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
}


static inline __attribute__((always_inline)) u64 bswap64(u64 v)
{

 return __builtin_bswap64(v);
# 378 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
}
# 456 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
static inline __attribute__((always_inline)) u16 load_u16_unaligned(const void *p) { u16 v; __builtin_memcpy(&v, p, sizeof(v)); return v; } static inline __attribute__((always_inline)) void store_u16_unaligned(u16 v, void *p) { __builtin_memcpy(p, &v, sizeof(v)); }
static inline __attribute__((always_inline)) u32 load_u32_unaligned(const void *p) { u32 v; __builtin_memcpy(&v, p, sizeof(v)); return v; } static inline __attribute__((always_inline)) void store_u32_unaligned(u32 v, void *p) { __builtin_memcpy(p, &v, sizeof(v)); }
static inline __attribute__((always_inline)) u64 load_u64_unaligned(const void *p) { u64 v; __builtin_memcpy(&v, p, sizeof(v)); return v; } static inline __attribute__((always_inline)) void store_u64_unaligned(u64 v, void *p) { __builtin_memcpy(p, &v, sizeof(v)); }
static inline __attribute__((always_inline)) machine_word_t load_machine_word_t_unaligned(const void *p) { machine_word_t v; __builtin_memcpy(&v, p, sizeof(v)); return v; } static inline __attribute__((always_inline)) void store_machine_word_t_unaligned(machine_word_t v, void *p) { __builtin_memcpy(p, &v, sizeof(v)); }
# 468 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
static inline __attribute__((always_inline)) u16
get_unaligned_le16(const u8 *p)
{
 if (1)
  return ((1234 == 1234) ? (load_u16_unaligned(p)) : bswap16(load_u16_unaligned(p)));
 else
  return ((u16)p[1] << 8) | p[0];
}

static inline __attribute__((always_inline)) u16
get_unaligned_be16(const u8 *p)
{
 if (1)
  return ((1234 == 1234) ? bswap16(load_u16_unaligned(p)) : (load_u16_unaligned(p)));
 else
  return ((u16)p[0] << 8) | p[1];
}

static inline __attribute__((always_inline)) u32
get_unaligned_le32(const u8 *p)
{
 if (1)
  return ((1234 == 1234) ? (load_u32_unaligned(p)) : bswap32(load_u32_unaligned(p)));
 else
  return ((u32)p[3] << 24) | ((u32)p[2] << 16) |
   ((u32)p[1] << 8) | p[0];
}

static inline __attribute__((always_inline)) u32
get_unaligned_be32(const u8 *p)
{
 if (1)
  return ((1234 == 1234) ? bswap32(load_u32_unaligned(p)) : (load_u32_unaligned(p)));
 else
  return ((u32)p[0] << 24) | ((u32)p[1] << 16) |
   ((u32)p[2] << 8) | p[3];
}

static inline __attribute__((always_inline)) u64
get_unaligned_le64(const u8 *p)
{
 if (1)
  return ((1234 == 1234) ? (load_u64_unaligned(p)) : bswap64(load_u64_unaligned(p)));
 else
  return ((u64)p[7] << 56) | ((u64)p[6] << 48) |
   ((u64)p[5] << 40) | ((u64)p[4] << 32) |
   ((u64)p[3] << 24) | ((u64)p[2] << 16) |
   ((u64)p[1] << 8) | p[0];
}

static inline __attribute__((always_inline)) machine_word_t
get_unaligned_leword(const u8 *p)
{
 ((void)sizeof(char[1 - 2 * !((8 * ((int)sizeof(machine_word_t))) == 32 || (8 * ((int)sizeof(machine_word_t))) == 64)]));
 if ((8 * ((int)sizeof(machine_word_t))) == 32)
  return get_unaligned_le32(p);
 else
  return get_unaligned_le64(p);
}



static inline __attribute__((always_inline)) void
put_unaligned_le16(u16 v, u8 *p)
{
 if (1) {
  store_u16_unaligned(((1234 == 1234) ? (v) : bswap16(v)), p);
 } else {
  p[0] = (u8)(v >> 0);
  p[1] = (u8)(v >> 8);
 }
}

static inline __attribute__((always_inline)) void
put_unaligned_be16(u16 v, u8 *p)
{
 if (1) {
  store_u16_unaligned(((1234 == 1234) ? bswap16(v) : (v)), p);
 } else {
  p[0] = (u8)(v >> 8);
  p[1] = (u8)(v >> 0);
 }
}

static inline __attribute__((always_inline)) void
put_unaligned_le32(u32 v, u8 *p)
{
 if (1) {
  store_u32_unaligned(((1234 == 1234) ? (v) : bswap32(v)), p);
 } else {
  p[0] = (u8)(v >> 0);
  p[1] = (u8)(v >> 8);
  p[2] = (u8)(v >> 16);
  p[3] = (u8)(v >> 24);
 }
}

static inline __attribute__((always_inline)) void
put_unaligned_be32(u32 v, u8 *p)
{
 if (1) {
  store_u32_unaligned(((1234 == 1234) ? bswap32(v) : (v)), p);
 } else {
  p[0] = (u8)(v >> 24);
  p[1] = (u8)(v >> 16);
  p[2] = (u8)(v >> 8);
  p[3] = (u8)(v >> 0);
 }
}

static inline __attribute__((always_inline)) void
put_unaligned_le64(u64 v, u8 *p)
{
 if (1) {
  store_u64_unaligned(((1234 == 1234) ? (v) : bswap64(v)), p);
 } else {
  p[0] = (u8)(v >> 0);
  p[1] = (u8)(v >> 8);
  p[2] = (u8)(v >> 16);
  p[3] = (u8)(v >> 24);
  p[4] = (u8)(v >> 32);
  p[5] = (u8)(v >> 40);
  p[6] = (u8)(v >> 48);
  p[7] = (u8)(v >> 56);
 }
}

static inline __attribute__((always_inline)) void
put_unaligned_leword(machine_word_t v, u8 *p)
{
 ((void)sizeof(char[1 - 2 * !((8 * ((int)sizeof(machine_word_t))) == 32 || (8 * ((int)sizeof(machine_word_t))) == 64)]));
 if ((8 * ((int)sizeof(machine_word_t))) == 32)
  put_unaligned_le32(v, p);
 else
  put_unaligned_le64(v, p);
}
# 615 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
static inline __attribute__((always_inline)) unsigned
bsr32(u32 v)
{

 return 31 - __builtin_clz(v);
# 632 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
}

static inline __attribute__((always_inline)) unsigned
bsr64(u64 v)
{

 return 63 - __builtin_clzll(v);
# 651 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
}

static inline __attribute__((always_inline)) unsigned
bsrw(machine_word_t v)
{
 ((void)sizeof(char[1 - 2 * !((8 * ((int)sizeof(machine_word_t))) == 32 || (8 * ((int)sizeof(machine_word_t))) == 64)]));
 if ((8 * ((int)sizeof(machine_word_t))) == 32)
  return bsr32(v);
 else
  return bsr64(v);
}







static inline __attribute__((always_inline)) unsigned
bsf32(u32 v)
{

 return __builtin_ctz(v);
# 686 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
}

static inline __attribute__((always_inline)) unsigned
bsf64(u64 v)
{

 return __builtin_ctzll(v);
# 705 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/../common_defs.h"
}

static inline __attribute__((always_inline)) unsigned
bsfw(machine_word_t v)
{
 ((void)sizeof(char[1 - 2 * !((8 * ((int)sizeof(machine_word_t))) == 32 || (8 * ((int)sizeof(machine_word_t))) == 64)]));
 if ((8 * ((int)sizeof(machine_word_t))) == 32)
  return bsf32(v);
 else
  return bsf64(v);
}
# 41 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/lib_common.h" 2

typedef void *(*malloc_func_t)(size_t);
typedef void (*free_func_t)(void *);

extern malloc_func_t libdeflate_default_malloc_func;
extern free_func_t libdeflate_default_free_func;

void *libdeflate_aligned_malloc(malloc_func_t malloc_func,
    size_t alignment, size_t size);
void libdeflate_aligned_free(free_func_t free_func, void *ptr);
# 65 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/lib_common.h"
void *memset(void *s, int c, size_t n);


void *memcpy(void *dest, const void *src, size_t n);


void *memmove(void *dest, const void *src, size_t n);


int memcmp(const void *s1, const void *s2, size_t n);
# 46 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c" 2
# 1 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_constants.h" 1
# 47 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c" 2
# 105 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
typedef machine_word_t bitbuf_t;
# 387 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
static inline __attribute__((always_inline)) u32
make_decode_table_entry(const u32 decode_results[], u32 sym, u32 len)
{
 return decode_results[sym] + (len << 8) + len;
}
# 407 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
static const u32 precode_decode_results[] = {

 ((u32)0 << 16) , ((u32)1 << 16) , ((u32)2 << 16) , ((u32)3 << 16) ,
 ((u32)4 << 16) , ((u32)5 << 16) , ((u32)6 << 16) , ((u32)7 << 16) ,
 ((u32)8 << 16) , ((u32)9 << 16) , ((u32)10 << 16) , ((u32)11 << 16) ,
 ((u32)12 << 16) , ((u32)13 << 16) , ((u32)14 << 16) , ((u32)15 << 16) ,
 ((u32)16 << 16) , ((u32)17 << 16) , ((u32)18 << 16) ,

};
# 504 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
static const u32 litlen_decode_results[] = {



 (0x80000000 | ((u32)0 << 16)) , (0x80000000 | ((u32)1 << 16)) , (0x80000000 | ((u32)2 << 16)) , (0x80000000 | ((u32)3 << 16)) ,
 (0x80000000 | ((u32)4 << 16)) , (0x80000000 | ((u32)5 << 16)) , (0x80000000 | ((u32)6 << 16)) , (0x80000000 | ((u32)7 << 16)) ,
 (0x80000000 | ((u32)8 << 16)) , (0x80000000 | ((u32)9 << 16)) , (0x80000000 | ((u32)10 << 16)) , (0x80000000 | ((u32)11 << 16)) ,
 (0x80000000 | ((u32)12 << 16)) , (0x80000000 | ((u32)13 << 16)) , (0x80000000 | ((u32)14 << 16)) , (0x80000000 | ((u32)15 << 16)) ,
 (0x80000000 | ((u32)16 << 16)) , (0x80000000 | ((u32)17 << 16)) , (0x80000000 | ((u32)18 << 16)) , (0x80000000 | ((u32)19 << 16)) ,
 (0x80000000 | ((u32)20 << 16)) , (0x80000000 | ((u32)21 << 16)) , (0x80000000 | ((u32)22 << 16)) , (0x80000000 | ((u32)23 << 16)) ,
 (0x80000000 | ((u32)24 << 16)) , (0x80000000 | ((u32)25 << 16)) , (0x80000000 | ((u32)26 << 16)) , (0x80000000 | ((u32)27 << 16)) ,
 (0x80000000 | ((u32)28 << 16)) , (0x80000000 | ((u32)29 << 16)) , (0x80000000 | ((u32)30 << 16)) , (0x80000000 | ((u32)31 << 16)) ,
 (0x80000000 | ((u32)32 << 16)) , (0x80000000 | ((u32)33 << 16)) , (0x80000000 | ((u32)34 << 16)) , (0x80000000 | ((u32)35 << 16)) ,
 (0x80000000 | ((u32)36 << 16)) , (0x80000000 | ((u32)37 << 16)) , (0x80000000 | ((u32)38 << 16)) , (0x80000000 | ((u32)39 << 16)) ,
 (0x80000000 | ((u32)40 << 16)) , (0x80000000 | ((u32)41 << 16)) , (0x80000000 | ((u32)42 << 16)) , (0x80000000 | ((u32)43 << 16)) ,
 (0x80000000 | ((u32)44 << 16)) , (0x80000000 | ((u32)45 << 16)) , (0x80000000 | ((u32)46 << 16)) , (0x80000000 | ((u32)47 << 16)) ,
 (0x80000000 | ((u32)48 << 16)) , (0x80000000 | ((u32)49 << 16)) , (0x80000000 | ((u32)50 << 16)) , (0x80000000 | ((u32)51 << 16)) ,
 (0x80000000 | ((u32)52 << 16)) , (0x80000000 | ((u32)53 << 16)) , (0x80000000 | ((u32)54 << 16)) , (0x80000000 | ((u32)55 << 16)) ,
 (0x80000000 | ((u32)56 << 16)) , (0x80000000 | ((u32)57 << 16)) , (0x80000000 | ((u32)58 << 16)) , (0x80000000 | ((u32)59 << 16)) ,
 (0x80000000 | ((u32)60 << 16)) , (0x80000000 | ((u32)61 << 16)) , (0x80000000 | ((u32)62 << 16)) , (0x80000000 | ((u32)63 << 16)) ,
 (0x80000000 | ((u32)64 << 16)) , (0x80000000 | ((u32)65 << 16)) , (0x80000000 | ((u32)66 << 16)) , (0x80000000 | ((u32)67 << 16)) ,
 (0x80000000 | ((u32)68 << 16)) , (0x80000000 | ((u32)69 << 16)) , (0x80000000 | ((u32)70 << 16)) , (0x80000000 | ((u32)71 << 16)) ,
 (0x80000000 | ((u32)72 << 16)) , (0x80000000 | ((u32)73 << 16)) , (0x80000000 | ((u32)74 << 16)) , (0x80000000 | ((u32)75 << 16)) ,
 (0x80000000 | ((u32)76 << 16)) , (0x80000000 | ((u32)77 << 16)) , (0x80000000 | ((u32)78 << 16)) , (0x80000000 | ((u32)79 << 16)) ,
 (0x80000000 | ((u32)80 << 16)) , (0x80000000 | ((u32)81 << 16)) , (0x80000000 | ((u32)82 << 16)) , (0x80000000 | ((u32)83 << 16)) ,
 (0x80000000 | ((u32)84 << 16)) , (0x80000000 | ((u32)85 << 16)) , (0x80000000 | ((u32)86 << 16)) , (0x80000000 | ((u32)87 << 16)) ,
 (0x80000000 | ((u32)88 << 16)) , (0x80000000 | ((u32)89 << 16)) , (0x80000000 | ((u32)90 << 16)) , (0x80000000 | ((u32)91 << 16)) ,
 (0x80000000 | ((u32)92 << 16)) , (0x80000000 | ((u32)93 << 16)) , (0x80000000 | ((u32)94 << 16)) , (0x80000000 | ((u32)95 << 16)) ,
 (0x80000000 | ((u32)96 << 16)) , (0x80000000 | ((u32)97 << 16)) , (0x80000000 | ((u32)98 << 16)) , (0x80000000 | ((u32)99 << 16)) ,
 (0x80000000 | ((u32)100 << 16)) , (0x80000000 | ((u32)101 << 16)) , (0x80000000 | ((u32)102 << 16)) , (0x80000000 | ((u32)103 << 16)) ,
 (0x80000000 | ((u32)104 << 16)) , (0x80000000 | ((u32)105 << 16)) , (0x80000000 | ((u32)106 << 16)) , (0x80000000 | ((u32)107 << 16)) ,
 (0x80000000 | ((u32)108 << 16)) , (0x80000000 | ((u32)109 << 16)) , (0x80000000 | ((u32)110 << 16)) , (0x80000000 | ((u32)111 << 16)) ,
 (0x80000000 | ((u32)112 << 16)) , (0x80000000 | ((u32)113 << 16)) , (0x80000000 | ((u32)114 << 16)) , (0x80000000 | ((u32)115 << 16)) ,
 (0x80000000 | ((u32)116 << 16)) , (0x80000000 | ((u32)117 << 16)) , (0x80000000 | ((u32)118 << 16)) , (0x80000000 | ((u32)119 << 16)) ,
 (0x80000000 | ((u32)120 << 16)) , (0x80000000 | ((u32)121 << 16)) , (0x80000000 | ((u32)122 << 16)) , (0x80000000 | ((u32)123 << 16)) ,
 (0x80000000 | ((u32)124 << 16)) , (0x80000000 | ((u32)125 << 16)) , (0x80000000 | ((u32)126 << 16)) , (0x80000000 | ((u32)127 << 16)) ,
 (0x80000000 | ((u32)128 << 16)) , (0x80000000 | ((u32)129 << 16)) , (0x80000000 | ((u32)130 << 16)) , (0x80000000 | ((u32)131 << 16)) ,
 (0x80000000 | ((u32)132 << 16)) , (0x80000000 | ((u32)133 << 16)) , (0x80000000 | ((u32)134 << 16)) , (0x80000000 | ((u32)135 << 16)) ,
 (0x80000000 | ((u32)136 << 16)) , (0x80000000 | ((u32)137 << 16)) , (0x80000000 | ((u32)138 << 16)) , (0x80000000 | ((u32)139 << 16)) ,
 (0x80000000 | ((u32)140 << 16)) , (0x80000000 | ((u32)141 << 16)) , (0x80000000 | ((u32)142 << 16)) , (0x80000000 | ((u32)143 << 16)) ,
 (0x80000000 | ((u32)144 << 16)) , (0x80000000 | ((u32)145 << 16)) , (0x80000000 | ((u32)146 << 16)) , (0x80000000 | ((u32)147 << 16)) ,
 (0x80000000 | ((u32)148 << 16)) , (0x80000000 | ((u32)149 << 16)) , (0x80000000 | ((u32)150 << 16)) , (0x80000000 | ((u32)151 << 16)) ,
 (0x80000000 | ((u32)152 << 16)) , (0x80000000 | ((u32)153 << 16)) , (0x80000000 | ((u32)154 << 16)) , (0x80000000 | ((u32)155 << 16)) ,
 (0x80000000 | ((u32)156 << 16)) , (0x80000000 | ((u32)157 << 16)) , (0x80000000 | ((u32)158 << 16)) , (0x80000000 | ((u32)159 << 16)) ,
 (0x80000000 | ((u32)160 << 16)) , (0x80000000 | ((u32)161 << 16)) , (0x80000000 | ((u32)162 << 16)) , (0x80000000 | ((u32)163 << 16)) ,
 (0x80000000 | ((u32)164 << 16)) , (0x80000000 | ((u32)165 << 16)) , (0x80000000 | ((u32)166 << 16)) , (0x80000000 | ((u32)167 << 16)) ,
 (0x80000000 | ((u32)168 << 16)) , (0x80000000 | ((u32)169 << 16)) , (0x80000000 | ((u32)170 << 16)) , (0x80000000 | ((u32)171 << 16)) ,
 (0x80000000 | ((u32)172 << 16)) , (0x80000000 | ((u32)173 << 16)) , (0x80000000 | ((u32)174 << 16)) , (0x80000000 | ((u32)175 << 16)) ,
 (0x80000000 | ((u32)176 << 16)) , (0x80000000 | ((u32)177 << 16)) , (0x80000000 | ((u32)178 << 16)) , (0x80000000 | ((u32)179 << 16)) ,
 (0x80000000 | ((u32)180 << 16)) , (0x80000000 | ((u32)181 << 16)) , (0x80000000 | ((u32)182 << 16)) , (0x80000000 | ((u32)183 << 16)) ,
 (0x80000000 | ((u32)184 << 16)) , (0x80000000 | ((u32)185 << 16)) , (0x80000000 | ((u32)186 << 16)) , (0x80000000 | ((u32)187 << 16)) ,
 (0x80000000 | ((u32)188 << 16)) , (0x80000000 | ((u32)189 << 16)) , (0x80000000 | ((u32)190 << 16)) , (0x80000000 | ((u32)191 << 16)) ,
 (0x80000000 | ((u32)192 << 16)) , (0x80000000 | ((u32)193 << 16)) , (0x80000000 | ((u32)194 << 16)) , (0x80000000 | ((u32)195 << 16)) ,
 (0x80000000 | ((u32)196 << 16)) , (0x80000000 | ((u32)197 << 16)) , (0x80000000 | ((u32)198 << 16)) , (0x80000000 | ((u32)199 << 16)) ,
 (0x80000000 | ((u32)200 << 16)) , (0x80000000 | ((u32)201 << 16)) , (0x80000000 | ((u32)202 << 16)) , (0x80000000 | ((u32)203 << 16)) ,
 (0x80000000 | ((u32)204 << 16)) , (0x80000000 | ((u32)205 << 16)) , (0x80000000 | ((u32)206 << 16)) , (0x80000000 | ((u32)207 << 16)) ,
 (0x80000000 | ((u32)208 << 16)) , (0x80000000 | ((u32)209 << 16)) , (0x80000000 | ((u32)210 << 16)) , (0x80000000 | ((u32)211 << 16)) ,
 (0x80000000 | ((u32)212 << 16)) , (0x80000000 | ((u32)213 << 16)) , (0x80000000 | ((u32)214 << 16)) , (0x80000000 | ((u32)215 << 16)) ,
 (0x80000000 | ((u32)216 << 16)) , (0x80000000 | ((u32)217 << 16)) , (0x80000000 | ((u32)218 << 16)) , (0x80000000 | ((u32)219 << 16)) ,
 (0x80000000 | ((u32)220 << 16)) , (0x80000000 | ((u32)221 << 16)) , (0x80000000 | ((u32)222 << 16)) , (0x80000000 | ((u32)223 << 16)) ,
 (0x80000000 | ((u32)224 << 16)) , (0x80000000 | ((u32)225 << 16)) , (0x80000000 | ((u32)226 << 16)) , (0x80000000 | ((u32)227 << 16)) ,
 (0x80000000 | ((u32)228 << 16)) , (0x80000000 | ((u32)229 << 16)) , (0x80000000 | ((u32)230 << 16)) , (0x80000000 | ((u32)231 << 16)) ,
 (0x80000000 | ((u32)232 << 16)) , (0x80000000 | ((u32)233 << 16)) , (0x80000000 | ((u32)234 << 16)) , (0x80000000 | ((u32)235 << 16)) ,
 (0x80000000 | ((u32)236 << 16)) , (0x80000000 | ((u32)237 << 16)) , (0x80000000 | ((u32)238 << 16)) , (0x80000000 | ((u32)239 << 16)) ,
 (0x80000000 | ((u32)240 << 16)) , (0x80000000 | ((u32)241 << 16)) , (0x80000000 | ((u32)242 << 16)) , (0x80000000 | ((u32)243 << 16)) ,
 (0x80000000 | ((u32)244 << 16)) , (0x80000000 | ((u32)245 << 16)) , (0x80000000 | ((u32)246 << 16)) , (0x80000000 | ((u32)247 << 16)) ,
 (0x80000000 | ((u32)248 << 16)) , (0x80000000 | ((u32)249 << 16)) , (0x80000000 | ((u32)250 << 16)) , (0x80000000 | ((u32)251 << 16)) ,
 (0x80000000 | ((u32)252 << 16)) , (0x80000000 | ((u32)253 << 16)) , (0x80000000 | ((u32)254 << 16)) , (0x80000000 | ((u32)255 << 16)) ,



 0x00008000 | 0x00002000,




 (((u32)(3) << 16) | (0)) , (((u32)(4) << 16) | (0)) , (((u32)(5) << 16) | (0)) , (((u32)(6) << 16) | (0)),
 (((u32)(7) << 16) | (0)) , (((u32)(8) << 16) | (0)) , (((u32)(9) << 16) | (0)) , (((u32)(10) << 16) | (0)),
 (((u32)(11) << 16) | (1)) , (((u32)(13) << 16) | (1)) , (((u32)(15) << 16) | (1)) , (((u32)(17) << 16) | (1)),
 (((u32)(19) << 16) | (2)) , (((u32)(23) << 16) | (2)) , (((u32)(27) << 16) | (2)) , (((u32)(31) << 16) | (2)),
 (((u32)(35) << 16) | (3)) , (((u32)(43) << 16) | (3)) , (((u32)(51) << 16) | (3)) , (((u32)(59) << 16) | (3)),
 (((u32)(67) << 16) | (4)) , (((u32)(83) << 16) | (4)) , (((u32)(99) << 16) | (4)) , (((u32)(115) << 16) | (4)),
 (((u32)(131) << 16) | (5)) , (((u32)(163) << 16) | (5)) , (((u32)(195) << 16) | (5)) , (((u32)(227) << 16) | (5)),
 (((u32)(258) << 16) | (0)) , (((u32)(258) << 16) | (0)) , (((u32)(258) << 16) | (0)) ,

};
# 617 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
static const u32 offset_decode_results[] = {


 (((u32)(1) << 16) | (0)) , (((u32)(2) << 16) | (0)) , (((u32)(3) << 16) | (0)) , (((u32)(4) << 16) | (0)) ,
 (((u32)(5) << 16) | (1)) , (((u32)(7) << 16) | (1)) , (((u32)(9) << 16) | (2)) , (((u32)(13) << 16) | (2)) ,
 (((u32)(17) << 16) | (3)) , (((u32)(25) << 16) | (3)) , (((u32)(33) << 16) | (4)) , (((u32)(49) << 16) | (4)) ,
 (((u32)(65) << 16) | (5)) , (((u32)(97) << 16) | (5)) , (((u32)(129) << 16) | (6)) , (((u32)(193) << 16) | (6)) ,
 (((u32)(257) << 16) | (7)) , (((u32)(385) << 16) | (7)) , (((u32)(513) << 16) | (8)) , (((u32)(769) << 16) | (8)) ,
 (((u32)(1025) << 16) | (9)) , (((u32)(1537) << 16) | (9)) , (((u32)(2049) << 16) | (10)) , (((u32)(3073) << 16) | (10)) ,
 (((u32)(4097) << 16) | (11)) , (((u32)(6145) << 16) | (11)) , (((u32)(8193) << 16) | (12)) , (((u32)(12289) << 16) | (12)) ,
 (((u32)(16385) << 16) | (13)) , (((u32)(24577) << 16) | (13)) , (((u32)(24577) << 16) | (13)) , (((u32)(24577) << 16) | (13)) ,

};
# 642 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
struct libdeflate_decompressor {
# 653 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
 union {
  u8 precode_lens[19];

  struct {
   u8 lens[288 +
    32 +
    137];

   u32 precode_decode_table[128];
  } l;

  u32 litlen_decode_table[2342];
 } u;

 u32 offset_decode_table[402];


 u16 sorted_syms[288];

 _Bool static_codes_loaded;
 unsigned litlen_tablebits;


 free_func_t free_func;
};
# 721 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
static _Bool
build_decode_table(u32 decode_table[],
     const u8 lens[],
     const unsigned num_syms,
     const u32 decode_results[],
     unsigned table_bits,
     unsigned max_codeword_len,
     u16 *sorted_syms,
     unsigned *table_bits_ret)
{
 unsigned len_counts[15 + 1];
 unsigned offsets[15 + 1];
 unsigned sym;
 unsigned codeword;
 unsigned len;
 unsigned count;
 u32 codespace_used;
 unsigned cur_table_end;
 unsigned subtable_prefix;
 unsigned subtable_start;
 unsigned subtable_bits;


 for (len = 0; len <= max_codeword_len; len++)
  len_counts[len] = 0;
 for (sym = 0; sym < num_syms; sym++)
  len_counts[lens[sym]]++;





 while (max_codeword_len > 1 && len_counts[max_codeword_len] == 0)
  max_codeword_len--;
 if (table_bits_ret != ((void*)0)) {
  table_bits = ((table_bits) <= (max_codeword_len) ? (table_bits) : (max_codeword_len));
  *table_bits_ret = table_bits;
 }
# 770 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
 ((void)sizeof(char[1 - 2 * !(sizeof(codespace_used) == 4)]));
 ((void)sizeof(char[1 - 2 * !(4294967295U / (1U << (15 - 1)) >= 288)]));


 offsets[0] = 0;
 offsets[1] = len_counts[0];
 codespace_used = 0;
 for (len = 1; len < max_codeword_len; len++) {
  offsets[len + 1] = offsets[len] + len_counts[len];
  codespace_used = (codespace_used << 1) + len_counts[len];
 }
 codespace_used = (codespace_used << 1) + len_counts[len];

 for (sym = 0; sym < num_syms; sym++)
  sorted_syms[offsets[lens[sym]]++] = sym;

 sorted_syms += offsets[0];
# 800 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
 if (__builtin_expect(!!(codespace_used > (1U << max_codeword_len)), 0))
  return 0;


 if (__builtin_expect(!!(codespace_used < (1U << max_codeword_len)), 0)) {
  u32 entry;
  unsigned i;
# 841 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
  if (codespace_used == 0) {
   sym = 0;
  } else {
   if (codespace_used != (1U << (max_codeword_len - 1)) ||
       len_counts[1] != 1)
    return 0;
   sym = sorted_syms[0];
  }
  entry = make_decode_table_entry(decode_results, sym, 1);
  for (i = 0; i < (1U << table_bits); i++)
   decode_table[i] = entry;
  return 1;
 }
# 879 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
 codeword = 0;
 len = 1;
 while ((count = len_counts[len]) == 0)
  len++;
 cur_table_end = 1U << len;
 while (len <= table_bits) {

  do {
   unsigned bit;


   decode_table[codeword] =
    make_decode_table_entry(decode_results,
       *sorted_syms++, len);

   if (codeword == cur_table_end - 1) {

    for (; len < table_bits; len++) {
     __builtin_memcpy((&decode_table[cur_table_end]), (decode_table), (cur_table_end * sizeof(decode_table[0])));



     cur_table_end <<= 1;
    }
    return 1;
   }
# 920 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
   bit = 1U << bsr32(codeword ^ (cur_table_end - 1));
   codeword &= bit - 1;
   codeword |= bit;
  } while (--count);


  do {
   if (++len <= table_bits) {
    __builtin_memcpy((&decode_table[cur_table_end]), (decode_table), (cur_table_end * sizeof(decode_table[0])));


    cur_table_end <<= 1;
   }
  } while ((count = len_counts[len]) == 0);
 }


 cur_table_end = 1U << table_bits;
 subtable_prefix = -1;
 subtable_start = 0;
 for (;;) {
  u32 entry;
  unsigned i;
  unsigned stride;
  unsigned bit;





  if ((codeword & ((1U << table_bits) - 1)) != subtable_prefix) {
   subtable_prefix = (codeword & ((1U << table_bits) - 1));
   subtable_start = cur_table_end;
# 964 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
   subtable_bits = len - table_bits;
   codespace_used = count;
   while (codespace_used < (1U << subtable_bits)) {
    subtable_bits++;
    codespace_used = (codespace_used << 1) +
     len_counts[table_bits + subtable_bits];
   }
   cur_table_end = subtable_start + (1U << subtable_bits);





   decode_table[subtable_prefix] =
    ((u32)subtable_start << 16) |
    0x00008000 |
    0x00004000 |
    (subtable_bits << 8) | table_bits;
  }


  entry = make_decode_table_entry(decode_results, *sorted_syms++,
      len - table_bits);
  i = subtable_start + (codeword >> table_bits);
  stride = 1U << (len - table_bits);
  do {
   decode_table[i] = entry;
   i += stride;
  } while (i < cur_table_end);


  if (codeword == (1U << len) - 1)
   return 1;
  bit = 1U << bsr32(codeword ^ ((1U << len) - 1));
  codeword &= bit - 1;
  codeword |= bit;
  count--;
  while (count == 0)
   count = len_counts[++len];
 }
}


static _Bool
build_precode_decode_table(struct libdeflate_decompressor *d)
{

 ((void)sizeof(char[1 - 2 * !(7 == 7 && 128 == 128)]));

 ((void)sizeof(char[1 - 2 * !((sizeof(precode_decode_results) / sizeof((precode_decode_results)[0])) == 19)]));


 return build_decode_table(d->u.l.precode_decode_table,
      d->u.precode_lens,
      19,
      precode_decode_results,
      7,
      7,
      d->sorted_syms,
      ((void*)0));
}


static _Bool
build_litlen_decode_table(struct libdeflate_decompressor *d,
     unsigned num_litlen_syms, unsigned num_offset_syms)
{

 ((void)sizeof(char[1 - 2 * !(11 == 11 && 2342 == 2342)]));

 ((void)sizeof(char[1 - 2 * !((sizeof(litlen_decode_results) / sizeof((litlen_decode_results)[0])) == 288)]));


 return build_decode_table(d->u.litlen_decode_table,
      d->u.l.lens,
      num_litlen_syms,
      litlen_decode_results,
      11,
      15,
      d->sorted_syms,
      &d->litlen_tablebits);
}


static _Bool
build_offset_decode_table(struct libdeflate_decompressor *d,
     unsigned num_litlen_syms, unsigned num_offset_syms)
{

 ((void)sizeof(char[1 - 2 * !(8 == 8 && 402 == 402)]));

 ((void)sizeof(char[1 - 2 * !((sizeof(offset_decode_results) / sizeof((offset_decode_results)[0])) == 32)]));


 return build_decode_table(d->offset_decode_table,
      d->u.l.lens + num_litlen_syms,
      num_offset_syms,
      offset_decode_results,
      8,
      15,
      d->sorted_syms,
      ((void*)0));
}





typedef enum libdeflate_result (*decompress_func_t)
 (struct libdeflate_decompressor * restrict d,
  const void * restrict in, size_t in_nbytes,
  void * restrict out, size_t out_nbytes_avail,
  size_t *actual_in_nbytes_ret, size_t *actual_out_nbytes_ret);





# 1 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h" 1
# 44 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
static __attribute__((unused)) enum libdeflate_result
deflate_decompress_default(struct libdeflate_decompressor * restrict d,
  const void * restrict in, size_t in_nbytes,
  void * restrict out, size_t out_nbytes_avail,
  size_t *actual_in_nbytes_ret, size_t *actual_out_nbytes_ret)
{
 u8 *out_next = out;
 u8 * const out_end = out_next + out_nbytes_avail;
 u8 * const out_fastloop_end =
  out_end - ((out_nbytes_avail) <= ((2 + 258 + (5 * ((int)sizeof(machine_word_t))) - 1)) ? (out_nbytes_avail) : ((2 + 258 + (5 * ((int)sizeof(machine_word_t))) - 1)));


 const u8 *in_next = in;
 const u8 * const in_end = in_next + in_nbytes;
 const u8 * const in_fastloop_end =
  in_end - ((in_nbytes) <= ((((((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) + (2 * 11) + (15 + 5) + (15 + 13)) + (8) - 1) / (8)) + sizeof(bitbuf_t))) ? (in_nbytes) : ((((((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) + (2 * 11) + (15 + 5) + (15 + 13)) + (8) - 1) / (8)) + sizeof(bitbuf_t))));
 bitbuf_t bitbuf = 0;
 bitbuf_t saved_bitbuf;
 u32 bitsleft = 0;
 size_t overread_count = 0;

 _Bool is_final_block;
 unsigned block_type;
 unsigned num_litlen_syms;
 unsigned num_offset_syms;
 bitbuf_t litlen_tablemask;
 u32 entry;

next_block:

 ;

 ((void)sizeof(char[1 - 2 * !((((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= (1 + 2 + 5 + 5 + 4 + 3)))]));
 do { if (1 && __builtin_expect(!!(in_end - in_next >= sizeof(bitbuf_t)), 1)) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { if (__builtin_expect(!!(in_next != in_end), 1)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; } else { overread_count++; if (__builtin_expect(!!(!(overread_count <= sizeof(bitbuf_t))), 0)) return LIBDEFLATE_BAD_DATA; } bitsleft += 8; } } } while (0);


 is_final_block = bitbuf & (((bitbuf_t)1 << (1)) - 1);


 block_type = (bitbuf >> 1) & (((bitbuf_t)1 << (2)) - 1);

 if (block_type == 2) {




  static const u8 deflate_precode_lens_permutation[19] = {
   16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15
  };

  unsigned num_explicit_precode_lens;
  unsigned i;



  ((void)sizeof(char[1 - 2 * !(288 == 257 + (((bitbuf_t)1 << (5)) - 1))]));
  num_litlen_syms = 257 + ((bitbuf >> 3) & (((bitbuf_t)1 << (5)) - 1));

  ((void)sizeof(char[1 - 2 * !(32 == 1 + (((bitbuf_t)1 << (5)) - 1))]));
  num_offset_syms = 1 + ((bitbuf >> 8) & (((bitbuf_t)1 << (5)) - 1));

  ((void)sizeof(char[1 - 2 * !(19 == 4 + (((bitbuf_t)1 << (4)) - 1))]));
  num_explicit_precode_lens = 4 + ((bitbuf >> 13) & (((bitbuf_t)1 << (4)) - 1));

  d->static_codes_loaded = 0;
# 117 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
  ((void)sizeof(char[1 - 2 * !(7 == (1 << 3) - 1)]));
  if ((((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= (3 * (19 - 1)))) {
   d->u.precode_lens[deflate_precode_lens_permutation[0]] =
    (bitbuf >> 17) & (((bitbuf_t)1 << (3)) - 1);
   bitbuf >>= 20;
   bitsleft -= 20;
   do { if (1 && __builtin_expect(!!(in_end - in_next >= sizeof(bitbuf_t)), 1)) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { if (__builtin_expect(!!(in_next != in_end), 1)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; } else { overread_count++; if (__builtin_expect(!!(!(overread_count <= sizeof(bitbuf_t))), 0)) return LIBDEFLATE_BAD_DATA; } bitsleft += 8; } } } while (0);
   i = 1;
   do {
    d->u.precode_lens[deflate_precode_lens_permutation[i]] =
     bitbuf & (((bitbuf_t)1 << (3)) - 1);
    bitbuf >>= 3;
    bitsleft -= 3;
   } while (++i < num_explicit_precode_lens);
  } else {
   bitbuf >>= 17;
   bitsleft -= 17;
   i = 0;
   do {
    if ((u8)bitsleft < 3)
     do { if (1 && __builtin_expect(!!(in_end - in_next >= sizeof(bitbuf_t)), 1)) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { if (__builtin_expect(!!(in_next != in_end), 1)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; } else { overread_count++; if (__builtin_expect(!!(!(overread_count <= sizeof(bitbuf_t))), 0)) return LIBDEFLATE_BAD_DATA; } bitsleft += 8; } } } while (0);
    d->u.precode_lens[deflate_precode_lens_permutation[i]] =
     bitbuf & (((bitbuf_t)1 << (3)) - 1);
    bitbuf >>= 3;
    bitsleft -= 3;
   } while (++i < num_explicit_precode_lens);
  }
  for (; i < 19; i++)
   d->u.precode_lens[deflate_precode_lens_permutation[i]] = 0;


  if (__builtin_expect(!!(!(build_precode_decode_table(d))), 0)) return LIBDEFLATE_BAD_DATA;


  i = 0;
  do {
   unsigned presym;
   u8 rep_val;
   unsigned rep_count;

   if ((u8)bitsleft < 7 + 7)
    do { if (1 && __builtin_expect(!!(in_end - in_next >= sizeof(bitbuf_t)), 1)) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { if (__builtin_expect(!!(in_next != in_end), 1)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; } else { overread_count++; if (__builtin_expect(!!(!(overread_count <= sizeof(bitbuf_t))), 0)) return LIBDEFLATE_BAD_DATA; } bitsleft += 8; } } } while (0);





   ((void)sizeof(char[1 - 2 * !(7 == 7)]));


   entry = d->u.l.precode_decode_table[
    bitbuf & (((bitbuf_t)1 << (7)) - 1)];
   bitbuf >>= (u8)entry;
   bitsleft -= entry;
   presym = entry >> 16;

   if (presym < 16) {

    d->u.l.lens[i++] = presym;
    continue;
   }
# 198 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
   ((void)sizeof(char[1 - 2 * !(137 == 138 - 1)]));

   if (presym == 16) {

    if (__builtin_expect(!!(!(i != 0)), 0)) return LIBDEFLATE_BAD_DATA;
    rep_val = d->u.l.lens[i - 1];
    ((void)sizeof(char[1 - 2 * !(3 + (((bitbuf_t)1 << (2)) - 1) == 6)]));
    rep_count = 3 + (bitbuf & (((bitbuf_t)1 << (2)) - 1));
    bitbuf >>= 2;
    bitsleft -= 2;
    d->u.l.lens[i + 0] = rep_val;
    d->u.l.lens[i + 1] = rep_val;
    d->u.l.lens[i + 2] = rep_val;
    d->u.l.lens[i + 3] = rep_val;
    d->u.l.lens[i + 4] = rep_val;
    d->u.l.lens[i + 5] = rep_val;
    i += rep_count;
   } else if (presym == 17) {

    ((void)sizeof(char[1 - 2 * !(3 + (((bitbuf_t)1 << (3)) - 1) == 10)]));
    rep_count = 3 + (bitbuf & (((bitbuf_t)1 << (3)) - 1));
    bitbuf >>= 3;
    bitsleft -= 3;
    d->u.l.lens[i + 0] = 0;
    d->u.l.lens[i + 1] = 0;
    d->u.l.lens[i + 2] = 0;
    d->u.l.lens[i + 3] = 0;
    d->u.l.lens[i + 4] = 0;
    d->u.l.lens[i + 5] = 0;
    d->u.l.lens[i + 6] = 0;
    d->u.l.lens[i + 7] = 0;
    d->u.l.lens[i + 8] = 0;
    d->u.l.lens[i + 9] = 0;
    i += rep_count;
   } else {

    ((void)sizeof(char[1 - 2 * !(11 + (((bitbuf_t)1 << (7)) - 1) == 138)]));
    rep_count = 11 + (bitbuf & (((bitbuf_t)1 << (7)) - 1));
    bitbuf >>= 7;
    bitsleft -= 7;
    __builtin_memset((&d->u.l.lens[i]), (0), (rep_count * sizeof(d->u.l.lens[i])));

    i += rep_count;
   }
  } while (i < num_litlen_syms + num_offset_syms);


  if (__builtin_expect(!!(!(i == num_litlen_syms + num_offset_syms)), 0)) return LIBDEFLATE_BAD_DATA;

 } else if (block_type == 0) {
  u16 len, nlen;






  bitsleft -= 3;
# 264 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
  bitsleft = (u8)bitsleft;
  if (__builtin_expect(!!(!(overread_count <= (bitsleft >> 3))), 0)) return LIBDEFLATE_BAD_DATA;
  in_next -= (bitsleft >> 3) - overread_count;
  overread_count = 0;
  bitbuf = 0;
  bitsleft = 0;

  if (__builtin_expect(!!(!(in_end - in_next >= 4)), 0)) return LIBDEFLATE_BAD_DATA;
  len = get_unaligned_le16(in_next);
  nlen = get_unaligned_le16(in_next + 2);
  in_next += 4;

  if (__builtin_expect(!!(!(len == (u16)~nlen)), 0)) return LIBDEFLATE_BAD_DATA;
  if (__builtin_expect(!!(len > out_end - out_next), 0))
   return LIBDEFLATE_INSUFFICIENT_SPACE;
  if (__builtin_expect(!!(!(len <= in_end - in_next)), 0)) return LIBDEFLATE_BAD_DATA;

  __builtin_memcpy((out_next), (in_next), (len));
  in_next += len;
  out_next += len;

  goto block_done;

 } else {
  unsigned i;

  if (__builtin_expect(!!(!(block_type == 1)), 0)) return LIBDEFLATE_BAD_DATA;
# 302 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
  bitbuf >>= 3;
  bitsleft -= 3;

  if (d->static_codes_loaded)
   goto have_decode_tables;

  d->static_codes_loaded = 1;

  ((void)sizeof(char[1 - 2 * !(288 == 288)]));
  ((void)sizeof(char[1 - 2 * !(32 == 32)]));

  for (i = 0; i < 144; i++)
   d->u.l.lens[i] = 8;
  for (; i < 256; i++)
   d->u.l.lens[i] = 9;
  for (; i < 280; i++)
   d->u.l.lens[i] = 7;
  for (; i < 288; i++)
   d->u.l.lens[i] = 8;

  for (; i < 288 + 32; i++)
   d->u.l.lens[i] = 5;

  num_litlen_syms = 288;
  num_offset_syms = 32;
 }



 if (__builtin_expect(!!(!(build_offset_decode_table(d, num_litlen_syms, num_offset_syms))), 0)) return LIBDEFLATE_BAD_DATA;
 if (__builtin_expect(!!(!(build_litlen_decode_table(d, num_litlen_syms, num_offset_syms))), 0)) return LIBDEFLATE_BAD_DATA;
have_decode_tables:
 litlen_tablemask = (((bitbuf_t)1 << (d->litlen_tablebits)) - 1);
# 344 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
 if (in_next >= in_fastloop_end || out_next >= out_fastloop_end)
  goto generic_loop;
 do { ((void)sizeof(char[1 - 2 * !(1 || (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) == ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7))])); if (1) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; bitsleft += 8; } } } while (0);
 entry = d->u.litlen_decode_table[bitbuf & litlen_tablemask];
 do {
  u32 length, offset, lit;
  const u8 *src;
  u8 *dst;






  saved_bitbuf = bitbuf;
  bitbuf >>= (u8)entry;
  bitsleft -= entry;





  if (entry & 0x80000000) {
# 381 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
   if (
       (((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= (2 * 11 + (15 + 5)) && (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) >= (2 * 11 + (15 + 5)) + (8)) &&



       (((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= (2 * 11 + 15) && (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) >= (2 * 11 + 15) + (11))) {



    lit = entry >> 16;
    entry = d->u.litlen_decode_table[bitbuf & litlen_tablemask];
    saved_bitbuf = bitbuf;
    bitbuf >>= (u8)entry;
    bitsleft -= entry;
    *out_next++ = lit;
    if (entry & 0x80000000) {

     lit = entry >> 16;
     entry = d->u.litlen_decode_table[bitbuf & litlen_tablemask];
     saved_bitbuf = bitbuf;
     bitbuf >>= (u8)entry;
     bitsleft -= entry;
     *out_next++ = lit;
     if (entry & 0x80000000) {






      lit = entry >> 16;
      entry = d->u.litlen_decode_table[bitbuf & litlen_tablemask];
      do { ((void)sizeof(char[1 - 2 * !(1 || (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) == ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7))])); if (1) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; bitsleft += 8; } } } while (0);
      *out_next++ = lit;
      continue;
     }
    }
   } else {
# 427 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
    ((void)sizeof(char[1 - 2 * !((((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= (11) && (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) >= (11) + (11)))]));

    lit = entry >> 16;
    entry = d->u.litlen_decode_table[bitbuf & litlen_tablemask];
    do { ((void)sizeof(char[1 - 2 * !(1 || (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) == ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7))])); if (1) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; bitsleft += 8; } } } while (0);
    *out_next++ = lit;
    continue;
   }
  }






  if (__builtin_expect(!!(entry & 0x00008000), 0)) {


   if (__builtin_expect(!!(entry & 0x00002000), 0))
    goto block_done;






   entry = d->u.litlen_decode_table[(entry >> 16) +
    ((bitbuf) & (((bitbuf_t)1 << ((entry >> 8) & 0x3F)) - 1))];
   saved_bitbuf = bitbuf;
   bitbuf >>= (u8)entry;
   bitsleft -= entry;
# 467 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
   if (!(((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= (15) && (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) >= (15) + (11)) ||

       !(((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= ((15 + 5)) && (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) >= ((15 + 5)) + (8)))

    do { ((void)sizeof(char[1 - 2 * !(1 || (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) == ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7))])); if (1) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; bitsleft += 8; } } } while (0);
   if (entry & 0x80000000) {

    lit = entry >> 16;
    entry = d->u.litlen_decode_table[bitbuf & litlen_tablemask];
    do { ((void)sizeof(char[1 - 2 * !(1 || (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) == ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7))])); if (1) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; bitsleft += 8; } } } while (0);
    *out_next++ = lit;
    continue;
   }
   if (__builtin_expect(!!(entry & 0x00002000), 0))
    goto block_done;

  }
# 495 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
  length = entry >> 16;
  length += ((saved_bitbuf) & (((bitbuf_t)1 << ((u8)(entry))) - 1)) >> (u8)(entry >> 8);






  ((void)sizeof(char[1 - 2 * !((((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= ((11 + 5)) && (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) >= ((11 + 5)) + (8)))]));

  entry = d->offset_decode_table[bitbuf & (((bitbuf_t)1 << (8)) - 1)];
  if ((((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= ((15 + 13)) && (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) >= ((15 + 13)) + (11))) {






   if (__builtin_expect(!!(entry & 0x00008000), 0)) {

    if (__builtin_expect(!!((u8)bitsleft < (15 + 13) + 11 - ((0) >= ((1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) - (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t)))) ? (0) : ((1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) - (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t)))))), 0))

     do { ((void)sizeof(char[1 - 2 * !(1 || (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) == ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7))])); if (1) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; bitsleft += 8; } } } while (0);
    bitbuf >>= 8;
    bitsleft -= 8;
    entry = d->offset_decode_table[(entry >> 16) +
     ((bitbuf) & (((bitbuf_t)1 << ((entry >> 8) & 0x3F)) - 1))];
   } else if (__builtin_expect(!!((u8)bitsleft < (8 + 13) + 11 - ((0) >= ((1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) - (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t)))) ? (0) : ((1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) - (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t)))))), 0))

    do { ((void)sizeof(char[1 - 2 * !(1 || (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) == ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7))])); if (1) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; bitsleft += 8; } } } while (0);
  } else {

   do { ((void)sizeof(char[1 - 2 * !(1 || (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) == ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7))])); if (1) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; bitsleft += 8; } } } while (0);
   if (__builtin_expect(!!(entry & 0x00008000), 0)) {

    bitbuf >>= 8;
    bitsleft -= 8;
    entry = d->offset_decode_table[(entry >> 16) +
     ((bitbuf) & (((bitbuf_t)1 << ((entry >> 8) & 0x3F)) - 1))];
    do { ((void)sizeof(char[1 - 2 * !(1 || (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) == ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7))])); if (1) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; bitsleft += 8; } } } while (0);

    ((void)sizeof(char[1 - 2 * !((((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= ((15 + 13) - 8)))]));

   } else {

    ((void)sizeof(char[1 - 2 * !((((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= ((8 + 13))))]));
   }
  }
  saved_bitbuf = bitbuf;
  bitbuf >>= (u8)entry;
  bitsleft -= entry;
  offset = entry >> 16;
  offset += ((saved_bitbuf) & (((bitbuf_t)1 << ((u8)(entry))) - 1)) >> (u8)(entry >> 8);


  if (__builtin_expect(!!(!(offset <= out_next - (const u8 *)out)), 0)) return LIBDEFLATE_BAD_DATA;
  src = out_next - offset;
  dst = out_next;
  out_next += length;
# 565 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
  if (!(((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= ((((15 + 13) - 8) >= ((8 + 13)) ? ((15 + 13) - 8) : ((8 + 13)))) && (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) >= ((((15 + 13) - 8) >= ((8 + 13)) ? ((15 + 13) - 8) : ((8 + 13)))) + (11)) &&



      __builtin_expect(!!((u8)bitsleft < 11 - ((0) >= ((1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) - (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t)))) ? (0) : ((1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) - (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t)))))), 0))
   do { ((void)sizeof(char[1 - 2 * !(1 || (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) == ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7))])); if (1) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; bitsleft += 8; } } } while (0);
  entry = d->u.litlen_decode_table[bitbuf & litlen_tablemask];
  do { ((void)sizeof(char[1 - 2 * !(1 || (1 ? (8 * (int)sizeof(bitbuf_t)) : ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) == ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7))])); if (1) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; bitsleft += 8; } } } while (0);
# 590 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
  if (1 && offset >= ((int)sizeof(machine_word_t))) {
   store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
   src += ((int)sizeof(machine_word_t));
   dst += ((int)sizeof(machine_word_t));
   store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
   src += ((int)sizeof(machine_word_t));
   dst += ((int)sizeof(machine_word_t));
   store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
   src += ((int)sizeof(machine_word_t));
   dst += ((int)sizeof(machine_word_t));
   store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
   src += ((int)sizeof(machine_word_t));
   dst += ((int)sizeof(machine_word_t));
   store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
   src += ((int)sizeof(machine_word_t));
   dst += ((int)sizeof(machine_word_t));
   while (dst < out_next) {
    store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
    src += ((int)sizeof(machine_word_t));
    dst += ((int)sizeof(machine_word_t));
    store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
    src += ((int)sizeof(machine_word_t));
    dst += ((int)sizeof(machine_word_t));
    store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
    src += ((int)sizeof(machine_word_t));
    dst += ((int)sizeof(machine_word_t));
    store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
    src += ((int)sizeof(machine_word_t));
    dst += ((int)sizeof(machine_word_t));
    store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
    src += ((int)sizeof(machine_word_t));
    dst += ((int)sizeof(machine_word_t));
   }
  } else if (1 && offset == 1) {
   machine_word_t v;





   v = (machine_word_t)0x0101010101010101 * src[0];
   store_machine_word_t_unaligned(v, dst);
   dst += ((int)sizeof(machine_word_t));
   store_machine_word_t_unaligned(v, dst);
   dst += ((int)sizeof(machine_word_t));
   store_machine_word_t_unaligned(v, dst);
   dst += ((int)sizeof(machine_word_t));
   store_machine_word_t_unaligned(v, dst);
   dst += ((int)sizeof(machine_word_t));
   while (dst < out_next) {
    store_machine_word_t_unaligned(v, dst);
    dst += ((int)sizeof(machine_word_t));
    store_machine_word_t_unaligned(v, dst);
    dst += ((int)sizeof(machine_word_t));
    store_machine_word_t_unaligned(v, dst);
    dst += ((int)sizeof(machine_word_t));
    store_machine_word_t_unaligned(v, dst);
    dst += ((int)sizeof(machine_word_t));
   }
  } else if (1) {
   store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
   src += offset;
   dst += offset;
   store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
   src += offset;
   dst += offset;
   do {
    store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
    src += offset;
    dst += offset;
    store_machine_word_t_unaligned(load_machine_word_t_unaligned(src), dst);
    src += offset;
    dst += offset;
   } while (dst < out_next);
  } else {
   *dst++ = *src++;
   *dst++ = *src++;
   do {
    *dst++ = *src++;
   } while (dst < out_next);
  }
 } while (in_next < in_fastloop_end && out_next < out_fastloop_end);
# 680 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h"
generic_loop:
 for (;;) {
  u32 length, offset;
  const u8 *src;
  u8 *dst;

  do { if (1 && __builtin_expect(!!(in_end - in_next >= sizeof(bitbuf_t)), 1)) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { if (__builtin_expect(!!(in_next != in_end), 1)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; } else { overread_count++; if (__builtin_expect(!!(!(overread_count <= sizeof(bitbuf_t))), 0)) return LIBDEFLATE_BAD_DATA; } bitsleft += 8; } } } while (0);
  entry = d->u.litlen_decode_table[bitbuf & litlen_tablemask];
  saved_bitbuf = bitbuf;
  bitbuf >>= (u8)entry;
  bitsleft -= entry;
  if (__builtin_expect(!!(entry & 0x00004000), 0)) {
   entry = d->u.litlen_decode_table[(entry >> 16) +
     ((bitbuf) & (((bitbuf_t)1 << ((entry >> 8) & 0x3F)) - 1))];
   saved_bitbuf = bitbuf;
   bitbuf >>= (u8)entry;
   bitsleft -= entry;
  }
  length = entry >> 16;
  if (entry & 0x80000000) {
   if (__builtin_expect(!!(out_next == out_end), 0))
    return LIBDEFLATE_INSUFFICIENT_SPACE;
   *out_next++ = length;
   continue;
  }
  if (__builtin_expect(!!(entry & 0x00002000), 0))
   goto block_done;
  length += ((saved_bitbuf) & (((bitbuf_t)1 << ((u8)(entry))) - 1)) >> (u8)(entry >> 8);
  if (__builtin_expect(!!(length > out_end - out_next), 0))
   return LIBDEFLATE_INSUFFICIENT_SPACE;

  if (!(((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= ((15 + 5) + (15 + 13))))
   do { if (1 && __builtin_expect(!!(in_end - in_next >= sizeof(bitbuf_t)), 1)) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { if (__builtin_expect(!!(in_next != in_end), 1)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; } else { overread_count++; if (__builtin_expect(!!(!(overread_count <= sizeof(bitbuf_t))), 0)) return LIBDEFLATE_BAD_DATA; } bitsleft += 8; } } } while (0);
  entry = d->offset_decode_table[bitbuf & (((bitbuf_t)1 << (8)) - 1)];
  if (__builtin_expect(!!(entry & 0x00008000), 0)) {
   bitbuf >>= 8;
   bitsleft -= 8;
   entry = d->offset_decode_table[(entry >> 16) +
     ((bitbuf) & (((bitbuf_t)1 << ((entry >> 8) & 0x3F)) - 1))];
   if (!(((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7) >= ((15 + 13))))
    do { if (1 && __builtin_expect(!!(in_end - in_next >= sizeof(bitbuf_t)), 1)) { do { bitbuf |= get_unaligned_leword(in_next) << (u8)bitsleft; in_next += sizeof(bitbuf_t) - 1; in_next -= (bitsleft >> 3) & 0x7; bitsleft |= (1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) & ~7; } while (0); } else { while ((u8)bitsleft < ((1 ? (8 * (int)sizeof(bitbuf_t)) - 1 : (8 * (int)sizeof(bitbuf_t))) - 7)) { if (__builtin_expect(!!(in_next != in_end), 1)) { bitbuf |= (bitbuf_t)*in_next++ << (u8)bitsleft; } else { overread_count++; if (__builtin_expect(!!(!(overread_count <= sizeof(bitbuf_t))), 0)) return LIBDEFLATE_BAD_DATA; } bitsleft += 8; } } } while (0);
  }
  offset = entry >> 16;
  offset += ((bitbuf) & (((bitbuf_t)1 << ((u8)(entry))) - 1)) >> (u8)(entry >> 8);
  bitbuf >>= (u8)entry;
  bitsleft -= entry;

  if (__builtin_expect(!!(!(offset <= out_next - (const u8 *)out)), 0)) return LIBDEFLATE_BAD_DATA;
  src = out_next - offset;
  dst = out_next;
  out_next += length;

  ((void)sizeof(char[1 - 2 * !(3 == 3)]));
  *dst++ = *src++;
  *dst++ = *src++;
  do {
   *dst++ = *src++;
  } while (dst < out_next);
 }

block_done:


 if (!is_final_block)
  goto next_block;



 bitsleft = (u8)bitsleft;





 if (__builtin_expect(!!(!(overread_count <= (bitsleft >> 3))), 0)) return LIBDEFLATE_BAD_DATA;


 if (actual_in_nbytes_ret) {

  in_next -= (bitsleft >> 3) - overread_count;

  *actual_in_nbytes_ret = in_next - (u8 *)in;
 }


 if (actual_out_nbytes_ret) {
  *actual_out_nbytes_ret = out_next - (u8 *)out;
 } else {
  if (out_next != out_end)
   return LIBDEFLATE_SHORT_OUTPUT;
 }
 return LIBDEFLATE_SUCCESS;
}
# 1083 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c" 2
# 1133 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
__attribute__((visibility("default"))) enum libdeflate_result
libdeflate_deflate_decompress_ex(struct libdeflate_decompressor *d,
     const void *in, size_t in_nbytes,
     void *out, size_t out_nbytes_avail,
     size_t *actual_in_nbytes_ret,
     size_t *actual_out_nbytes_ret)
{
 return deflate_decompress_default(d, in, in_nbytes, out, out_nbytes_avail,
          actual_in_nbytes_ret, actual_out_nbytes_ret);
}

__attribute__((visibility("default"))) enum libdeflate_result
libdeflate_deflate_decompress(struct libdeflate_decompressor *d,
         const void *in, size_t in_nbytes,
         void *out, size_t out_nbytes_avail,
         size_t *actual_out_nbytes_ret)
{
 return libdeflate_deflate_decompress_ex(d, in, in_nbytes,
      out, out_nbytes_avail,
      ((void*)0), actual_out_nbytes_ret);
}

__attribute__((visibility("default"))) struct libdeflate_decompressor *
libdeflate_alloc_decompressor_ex(const struct libdeflate_options *options)
{
 struct libdeflate_decompressor *d;





 if (options->sizeof_options != sizeof(*options))
  return ((void*)0);

 d = (options->malloc_func ? options->malloc_func :
      libdeflate_default_malloc_func)(sizeof(*d));
 if (d == ((void*)0))
  return ((void*)0);
# 1188 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/vendor/libdeflate/lib/deflate_decompress.c"
 __builtin_memset((d), (0), (sizeof(*d)));
 d->free_func = options->free_func ?
         options->free_func : libdeflate_default_free_func;
 return d;
}

__attribute__((visibility("default"))) struct libdeflate_decompressor *
libdeflate_alloc_decompressor(void)
{
 static const struct libdeflate_options defaults = {
  .sizeof_options = sizeof(defaults),
 };
 return libdeflate_alloc_decompressor_ex(&defaults);
}

__attribute__((visibility("default"))) void
libdeflate_free_decompressor(struct libdeflate_decompressor *d)
{
 if (d)
  d->free_func(d);
}
# 13 "/workspace/scratch/9bb32f82fa3b/manabitan/ext/js/dictionary/wasm/term-bank-inflate.c" 2



static struct libdeflate_decompressor term_bank_decompressor;

int32_t term_bank_inflate(
    const uint8_t* input,
    uint32_t input_length,
    uint8_t* output,
    uint32_t output_length
) {
    size_t consumed = 0;
    size_t produced = 0;
    const enum libdeflate_result result = libdeflate_deflate_decompress_ex(
        &term_bank_decompressor, input, input_length, output, output_length,
        &consumed, &produced
    );
    if (result != LIBDEFLATE_SUCCESS) { return -2; }
    if (produced != output_length) { return -3; }
    if (consumed != input_length) { return -6; }
    return 0;
}
