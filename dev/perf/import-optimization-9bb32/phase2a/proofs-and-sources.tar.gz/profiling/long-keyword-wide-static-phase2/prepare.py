"""Create one scratch source variant; no product files or build manifests change."""
from pathlib import Path
import difflib
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
source = ROOT / 'manabitan/ext/js/dictionary/wasm/term-bank-parser.c'
original = source.read_text()
start = original.index('static __attribute__((always_inline)) inline int json_string_matches_ascii(')
position = original.index('    uint32_t i = start + 1u;', start)
addition = '''    if (keyword_length >= 8u) {
        if (end - start < 2u) { return 0; }
        const uint8_t first = src[start + 1u];
        if (first == '\\\\') { goto long_literal_miss; }
        if (first != (uint8_t)keyword[0]) { return 0; }
        // Wide reads require a complete quoted literal within the logical end.
        // Other spellings retain the same bounded escaped-keyword decoder.
        if (keyword_length > end - start - 2u || src[start + keyword_length + 1u] != '"') {
            goto long_literal_miss;
        }
        const uint8_t* literal = src + start + 1u;
        uint32_t k = 0u;
        for (; keyword_length - k >= 8u; k += 8u) {
            uint64_t actual;
            uint64_t expected;
            __builtin_memcpy(&actual, literal + k, sizeof(actual));
            __builtin_memcpy(&expected, keyword + k, sizeof(expected));
            if (actual != expected) { goto long_literal_miss; }
        }
        if (keyword_length - k >= 4u) {
            uint32_t actual;
            uint32_t expected;
            __builtin_memcpy(&actual, literal + k, sizeof(actual));
            __builtin_memcpy(&expected, keyword + k, sizeof(expected));
            if (actual != expected) { goto long_literal_miss; }
            k += 4u;
        }
        if (keyword_length - k >= 2u) {
            uint16_t actual;
            uint16_t expected;
            __builtin_memcpy(&actual, literal + k, sizeof(actual));
            __builtin_memcpy(&expected, keyword + k, sizeof(expected));
            if (actual != expected) { goto long_literal_miss; }
            k += 2u;
        }
        if (k < keyword_length && literal[k] != (uint8_t)keyword[k]) { goto long_literal_miss; }
        return 1;

long_literal_miss:
        return json_string_matches_ascii_escaped(src, start, end, keyword, keyword_length);
    }
'''
candidate = original[:position] + addition + original[position:]
destination = OUT / 'term-bank-parser.c'
destination.write_text(candidate)
patch = ''.join(difflib.unified_diff(original.splitlines(True), candidate.splitlines(True), fromfile='a/ext/js/dictionary/wasm/term-bank-parser.c', tofile='b/ext/js/dictionary/wasm/term-bank-parser.c'))
(OUT / 'candidate.patch').write_text(patch)
def binding(path):
    content = path.read_bytes()
    return {'path': str(path), 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
(OUT / 'source-identity.json').write_text(json.dumps({'baselineCommit': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2', 'mode': 'scratch-only; first source variant; no timing or runtime execution', 'files': [binding(source), binding(destination), binding(OUT / 'candidate.patch')]}, indent=2) + '\n')
print(patch)
