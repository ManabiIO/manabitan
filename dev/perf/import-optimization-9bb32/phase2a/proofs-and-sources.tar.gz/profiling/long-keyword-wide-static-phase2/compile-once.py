"""One authorized scratch compile; retain its exact command, logs, and intermediates."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
REPO = ROOT / 'manabitan'
compiler = Path('/tmp/manabitan-native-9bb32/native-toolchain/bin/clang')
linker = Path('/tmp/manabitan-native-9bb32/native-toolchain/bin/wasm-ld')
manifest_path = REPO / 'dev/data/dictionary-wasm/manifest.json'
manifest = json.loads(manifest_path.read_text())
target = next(target for target in manifest['targets'] if target['name'] == 'term-bank-parser.wasm')
receipt_path = OUT / 'compile-attempt.json'
if receipt_path.exists():
    raise SystemExit('The one compile attempt is already recorded; do not retry without authorization.')
compiler_version = subprocess.check_output([str(compiler), '--version'], text=True)
linker_version = subprocess.check_output([str(linker), '--version'], text=True)
assert manifest['toolchain']['compilerVersion'] in compiler_version
assert manifest['toolchain']['linkerVersion'] in linker_version
arguments = [str(compiler), '-fuse-ld=' + str(linker), *target['arguments'], '-save-temps=obj', '-Wl,-Map=' + str(OUT / 'link.map'), '-o', str(OUT / 'term-bank-parser-wide.wasm'), str(OUT / 'term-bank-parser.c'), str(REPO / target['sources'][1])]
receipt = {
    'status': 'attempting', 'attempt': 1, 'arguments': arguments,
    'compilerVersion': compiler_version, 'linkerVersion': linker_version,
    'productionArgumentsPreserved': target['arguments'],
    'diagnosticFlags': ['-save-temps=obj', '-Wl,-Map=...'],
    'diagnosticFlagsPurpose': 'Retain assembly/intermediates and linker symbol mapping; no code-generation optimization changes.',
    'runtimeExecution': False, 'timingExperiment': False,
}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
result = subprocess.run(arguments, cwd=OUT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(OUT / 'compile.stdout.log').write_bytes(result.stdout)
(OUT / 'compile.stderr.log').write_bytes(result.stderr)
receipt['exitCode'] = result.returncode
receipt['status'] = 'completed' if result.returncode == 0 else 'failed-no-retry'
receipt['files'] = []
for path in sorted(OUT.iterdir()):
    if path.is_file() and path != receipt_path:
        data = path.read_bytes()
        receipt['files'].append({'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': receipt['status'], 'exitCode': result.returncode, 'files': len(receipt['files'])}))
if result.stderr:
    print(result.stderr.decode())
raise SystemExit(result.returncode)
