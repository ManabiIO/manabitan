#!/usr/bin/env python3
"""Static review only: never execute the proposed parity helper or imports."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
FOLDER = Path(__file__).resolve().parent
checks = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(('blob ' + str(len(data)) + '\0').encode() + data).hexdigest()

def check(name, value, reason):
    checks.append({'name': name, 'passed': bool(value), 'reason': reason})
    assert value, name

helper = (FOLDER / 'reviewed-helper-final.py.txt').read_bytes()
old = (FOLDER / 'reviewed-helper-v1.py.txt').read_bytes()
workflow = (FOLDER / 'reviewed-workflow-final.yml.txt').read_bytes()
check('helper_blob', blob(helper) == '785a7f9a2452dca38c5ed89709ce9bff63eda5c3', 'Exact connector-fetched final helper.')
check('workflow_blob', blob(workflow) == 'dcebc683f6e7c1aa74d66634dc6a3df9b96f5ce9', 'Exact connector-fetched final workflow.')
check('superseded_helper', blob(old) == 'ca3f799dbc53380054d9081345a5a0a1599c0cc2', 'Original staged helper retained unchanged.')
check('minimal_attribution_fix', helper == old.replace(b'    for name in DICTIONARIES:\n', b'    for name in DICTIONARIES:\n        current = None\n'), 'Only clears previous attempt before a later preflight; no comparison or acquisition change.')
values = {}

def constant(node):
    if isinstance(node, ast.Name):
        return values[node.id]
    if isinstance(node, ast.Dict):
        return {constant(k): constant(v) for k, v in zip(node.keys, node.values)}
    if isinstance(node, ast.Tuple):
        return tuple(constant(x) for x in node.elts)
    if isinstance(node, ast.List):
        return [constant(x) for x in node.elts]
    if isinstance(node, ast.Set):
        return {constant(x) for x in node.elts}
    return ast.literal_eval(node)

for node in ast.parse(helper.decode()).body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        try:
            values[node.targets[0].id] = constant(node.value)
        except (ValueError, TypeError, KeyError):
            pass

archive_path = ROOT / 'profiling/checkpoint-phase1/checkpoint-phase1.tar.gz'
check('checkpoint_hash', sha(archive_path.read_bytes()) == values['ARCHIVE_SHA'], 'Binds previously audited and published phase-one archive.')
baselines = {}
members = []
with tarfile.open(archive_path, 'r:gz') as archive:
    for destination, (name, expected_hash, expected_size) in values['MEMBERS'].items():
        member = archive.getmember(name)
        data = archive.extractfile(member).read()
        check('selected_member:' + name, member.isfile() and len(data) == expected_size and sha(data) == expected_hash, 'Exact selected member hash and size.')
        members.append({'destination': destination, 'member': name, 'sha256': expected_hash, 'bytes': expected_size})
        if destination.startswith('baseline-'):
            baselines[destination[9:-5]] = json.loads(data)

for name, baseline in baselines.items():
    observation = baseline['observations'][0]
    check('baseline_receipt:' + name, baseline['complete'] is True and baseline['node'] == values['NODE'] and baseline['gitIdentity']['sha'] == values['BASE'] and len(baseline['observations']) == 1 and observation['phase'] == 'verify' and observation['iteration'] == 0 and observation['digest'] == values['DIGESTS'][name], 'Complete frozen baseline, one verify observation, exact Node/source/full digest.')
    check('baseline_runner:' + name, baseline['runnerSha256'] == values['MEMBERS']['pipeline-replay.mjs'][1], 'Identical immutable replay harness in all baselines.')
    expected = {**baseline['source'], **values['CHANGED_RUNTIME']}
    for path, expected_hash in expected.items():
        check('candidate_runtime:' + name + ':' + path, sha((ROOT / 'wide-keyword' / path).read_bytes()) == expected_hash, 'Only declared native source/artifact/manifest substitutions.')

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT / 'wide-keyword'), *args], text=True).strip()

check('candidate_tree', git('rev-parse', 'HEAD^{tree}') == values['TREE'], 'Local frozen tree matches independently fetched published ebf4278a tree611b6e15.')
changed = set(git('diff', '--name-only', values['BASE'], 'HEAD').splitlines())
check('five_file_scope', changed == {
    '.github/workflows/import-wide-keyword-9bb32.yml',
    'ext/js/dictionary/wasm/term-bank-parser.c',
    'dev/data/dictionary-wasm/manifest.json',
    'dev/data/dictionary-wasm/term-bank-parser.wasm',
    'test/term-bank-wide-keyword.test.js',
}, 'All production JavaScript, worker transport and dependency lock remain unchanged.')
check('workflow_refs', b'ref: ${{ github.sha }}' in workflow and values['CANDIDATE'].encode() in workflow and b'workflow_dispatch' not in workflow, 'Exact pushed helper commit and frozen product commit; no manual repeat trigger.')
check('workflow_permissions', b'permissions:\n  contents: read\n' in workflow and workflow.count(b'persist-credentials: false') == 2, 'Read-only repository permissions and no retained checkout credentials.')
check('current_spec_bytes', (FOLDER / 'import-wide-keyword-parity-9bb32.py').read_bytes() == helper and (FOLDER / 'import-wide-keyword-parity-9bb32.yml').read_bytes() == workflow, 'Immutable reviewed copies equal current final staged files.')

report = {
    'status': 'clean-independent-static-review',
    'helper': {'gitBlob': blob(helper), 'sha256': sha(helper), 'bytes': len(helper)},
    'workflow': {'gitBlob': blob(workflow), 'sha256': sha(workflow), 'bytes': len(workflow)},
    'supersededHelperBlob': blob(old),
    'candidateCommit': values['CANDIDATE'], 'candidateTree': values['TREE'],
    'baselineCommit': values['BASE'], 'nodeVersion': values['NODE'],
    'checkpointSha256': values['ARCHIVE_SHA'], 'selectedMembers': members,
    'checkCount': len(checks), 'allChecksPassed': all(x['passed'] for x in checks), 'checks': checks,
    'baselineShapes': {name: {'rows': value['observations'][0]['rows'], 'groups': len(value['observations'][0]['chunks']), 'workers': len(value['observations'][0]['workers']), 'fullOutputDigest': value['observations'][0]['digest']} for name, value in baselines.items()},
    'excludedProfileKeys': {name: sorted(key for key in value['observations'][0]['profiles'][0] if key.endswith('Ms') or key in values['RESOURCE_FIELDS']) for name, value in baselines.items()},
    'manualReview': {
        'outputCompleteness': 'The unchanged verify harness hashes logical parser columns, complete native content, content metadata/dedup plan, key/record plan, prepared indexes and media rows with group ordering/progress. Full fixture row counts are asserted. Lifecycle callbacks, physical slab placement and incidental timings are outside logical data scope.',
        'comparison': 'Requires complete:true, exactly one verify observation/iteration0, full known digest, exact group shapes/options/source bytes, fixture/lock/source/runtime identity, and every nonexcluded native profile value.',
        'exclusions': 'Only profile fields ending Ms plus maxWasmHeapBytes and parallelPeakQueuedOwnedContentBytes are excluded. In the frozen schemas these are durations/resource high-water values; native counts, byte counts, flags, grouping and fallback counters remain compared. Raw reports retain excluded values.',
        'dependenciesAndPaths': 'The extracted replay imports its pinned canonical-corpus sibling, which imports only Node builtins. Product modules and worker transport resolve from the absolute pinned candidate root. The setup action supports explicit Node24.20, npm ci and library preparation. Dictionary CLI arguments match source; replay independently verifies full archive SHA and size.',
        'shellAndPermissions': 'Runner/workspace paths are quoted, Git revision arguments are immutable, actions are pinned, contents permission is read-only and both checkouts disable persisted credentials. GitHub metadata independently confirms this repository is public, so the unauthenticated checkpoint fetch remains valid.',
        'failureHandling': 'A nonzero process exit, timeout, incomplete report or parity mismatch stops subsequent dictionaries and raises. Logs, partial output and status remain; always-upload does not mask the preceding failed step. The one-line current reset preserves earlier passed entries when later preflight fails. No retry loop exists.',
        'claimLimits': 'Full logical worker-output comparison against a retained baseline; no fresh A/B timing cohort, whole browser import, persisted database readback, exhaustive media readback or peak-memory proof.',
    },
    'resolvedFinding': 'Later preflight failure could relabel a previous passed attempt; final helper only adds current=None at the dictionary-loop start.',
    'reviewSetupNote': 'An earlier static extractor stopped at KeyError: CHANGED_RUNTIME because ast.literal_eval cannot resolve the PARSER_SHA alias. No helper or import executed. This saved auditor resolves only literal AST nodes and previously collected names.',
    'execution': {'pythonAstParsed': True, 'helperExecuted': False, 'importsOrCorrectnessProcessesRun': False, 'benchmarksRun': False, 'publicationOrJobsStarted': False},
}
output = FOLDER / 'independent-review.json'
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'receipt': str(output), 'sha256': sha(output.read_bytes()), 'checks': len(checks), 'passed': report['allChecksPassed']}))
