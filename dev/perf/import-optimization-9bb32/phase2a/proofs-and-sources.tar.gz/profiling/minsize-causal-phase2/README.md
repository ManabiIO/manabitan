# Function13 minsize causal read — phase2

This is a static diagnostic of the already frozen compiler outputs, not a new runtime candidate or performance result. No compiler, WebAssembly execution, import, benchmark, or product mutation was run for this analysis. The hosted full-import comparisons remain the decision gate. Source QA for the minsize candidate has passed separately; it does not establish a speed benefit.

## Binding and method

Baseline source is `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. The screened minsize runtime is `483586aee547c1c568aac17e2faf413f71bc0477`; workflow-only follow-up head is `2907ba1bad0958c22fe363f88d7cceb4d4bc604e`. Its parser SHA256 is `363136045b400ea9bab953cb7b52febaedd23b4d1e3b666cde3d4df859b72ff0` versus baseline `8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee`.

`analyze.py` reads the retained named WASMs, compiler assembly, optimized LLVM IR, and baseline C. It decodes function13 and verifies that every assembly opcode matches the binary opcode sequence before assigning byte counts to assembly spans. It derives IR natural loops from dominators and CFG backedges. `static-counts.json` binds all inputs by size and SHA256. Rerun only with the retained inputs; this script does not build or execute either arm.

The inputs were already preserved in the phase1 archive, SHA256 `050a01b9994034c0e070d66e17d1f879b20d724772e8c187af354a879936d161`, on diagnostic evidence commit `35069bdeb7a904fb9a39c919717b61021af9e78b`. Phase1's status remains frozen; this note is a later analysis.

## What changed

Only `parse_composite_span_impl` differs in the two parser Code sections. Its body shrank 6069→4381 bytes, a reduction of 1688 bytes (27.8%). Assembly opcode count fell 2887→2263. Declared Wasm locals fell 35→22 (34→21 i32 locals, with one i64 local in both); the eight function parameters and explicit 272-byte C stack allocation stayed the same. These are **Wasm locals**, not measurements of physical JIT registers or native stack-frame size.

The 13 candidate loops versus 4 baseline loops have an exact source mapping:

| Source path | Baseline | Minsize | Candidate IR / assembly loop lines |
|---|---|---|---|
| Composite grammar `while`, C943 | 1 loop | 1 loop | IR13878; asm26118 |
| String scanner, C718–733 | 1 flattened loop containing the 8-byte scan and escape handling | Outer string loop plus inner 8-byte loop | IR13964,13969; asm26945,26954 |
| Four hex digits after `\\u`, C742 | Four copies of the hex test | 1 loop | IR14038; asm27101 |
| Top-level object keys `type`, `text`, `path`, `content`, C980–983 | Four fully unrolled comparisons | 4 loops | IR14417,14460,14503,14546; asm27448,27519,27591,27667 |
| Type values `text`, `image`, `structured-content`, C1023–1025 | Three fully unrolled comparisons | 3 loops | IR14927,14970,15013; asm27803,27884,27957 |
| Whitespace in `type_text_pair_at`, C821,823 | 2 loops | 2 loops | IR14694,14726; asm28248,28302 |

The media-marker comparisons (`img`/`image`, C815–816) and `type_text_pair_at`'s `type`/`text` comparisons (C820,824) remain unrolled. Calls stay 12 in both bodies: 11 escaped-keyword fallbacks and one scalar-parser call. Thus minsize changes several independent hot paths; it is not just a long-keyword transformation.

## The long-keyword contribution

The literal `structured-content` comparison in the baseline is 18 byte-specific source loads and immediate character comparisons, plus a closing-quote load. The minsize version uses a short loop that loads both a source byte and a keyword byte each iteration. For a complete unescaped match, this implies 19 source-byte loads in both forms and 18 additional constant-keyword loads in the loop form, before any JIT optimization. Early mismatch and escaped paths do different work.

The layout-specific contiguous lowering span is 694 bytes / 305 instructions in baseline assembly28030–28391 (body offsets3634–4328), versus 127 bytes / 63 instructions in minsize assembly27947–28017 (body offsets3233–3360). This 567-byte reduction is 33.6% of the whole 1688-byte body reduction. These spans include dispatch and exit instructions whose placement differs; they are descriptive byte accounting, not independent kernels or a proof of an isolated 567-byte transformation.

The corresponding optimized IR is baseline15250–15482, including the long comparison's first-byte block at15458, versus candidate15009–15055. The baseline chain retains 17 intermediate length checks before later characters, then a final quote-bound check. The candidate loop has its own iteration-limit, input-bound, escape, and character-match branches. This is a credible execution-work tradeoff when the keyword actually matches, despite its much smaller static size.

Across the whole function, `br_table` count falls 36→5 and encoded table bytes 641→40. This 601-byte reduction overlaps the long-keyword span and other shrinking regions; it must not be added to 567 as independent attribution. Escape dispatch itself changes from one 85-way table to smaller tables and comparisons, so a per-keyword explanation cannot account for every byte or path change.

## Entry work and possible corpus tradeoff

The baseline assembly computes 17 distinct `src + constant` bases before the outer loop (119 encoded bytes); minsize computes 3 (21 bytes). In the baseline IR, the11 bases for offsets7 through17 are used only in the long `structured-content` comparison. Its `src+19` closing-quote base remains in the minsize prologue. The rest of the17→3 net reduction also involves short-key and hex-test bases, and minsize introduces `src+6`; a long-keyword-only change must not be credited automatically with all 14 net removed additions.

This creates a plausible distinction between many plain glossary arrays and frequent validated structured objects. Plain arrays can enter this function repeatedly while never taking the top-level object-key/type comparison paths, yet the baseline Wasm prologue still contains those hoisted preparations. A matching structured object executes the comparisons, where minsize adds loop control and keyword loads. However, text length alone does not classify the tradeoff: the 8-byte scanner topology, number of top-level objects, escape density, early mismatches, and JIT tier also matter. Native optimization may fold, reposition, or eliminate Wasm local/address operations. The existing samples identify function13 but not individual instructions; they cannot settle these hypotheses.

## Narrow follow-up boundary

A blanket unroll pragma in `json_string_matches_ascii` changes all its inline call sites. A pragma on the outer composite grammar loop would target the wrong source loop. Function-wide minsize also changes the string and Unicode loops. Those are poor isolation choices if the goal is specifically to separate the 18-byte keyword's code size from its matching-path work.

A bounded wide-literal comparison for compile-time keyword lengths at least one 8-byte word could be a more focused diagnostic, subject to the separate contract/ownership audit. The only current long keyword is `structured-content`, at **two** call sites: composite validation C1025 and image-projection selector C1253. Short-key paths, ordinary string scanning, and Unicode checks should remain unchanged. The generic helper accepts a logical end that may be a token or bank boundary; any wide loads require a checked span including opening and closing quotes, and escaped spellings still need the exact existing decoder behavior. Cheap first-byte rejection remains relevant because most strings are not the keyword.

The prior constant-NULL media-hint clone is not an isolated substitute: its saved static probe changed the hint-capable kernel and grew the module, while the long type-validation comparison is still needed when media hints are disabled. No new source is authorized or recommended for shipment by this note. A future experiment would need code-isolation proof, semantic checks, and full three-dictionary browser comparisons before any PR decision.
