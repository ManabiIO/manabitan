"""Read retained compiler output only; do not compile, instantiate, or time code."""
from collections import Counter
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
TMP = Path('/tmp/manabitan-profiling-9bb32')


def identity(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def leb(data, pos, signed=False):
    value = shift = 0
    while True:
        byte = data[pos]
        pos += 1
        value |= (byte & 127) << shift
        shift += 7
        if byte < 128:
            if signed and byte & 64:
                value -= 1 << shift
            return value, pos


def function_body(path, index=13):
    data = path.read_bytes()
    pos = 8
    while pos < len(data):
        section = data[pos]
        size, pos = leb(data, pos + 1)
        end = pos + size
        if section == 10:
            count, pos = leb(data, pos)
            assert index < count
            for current in range(count):
                size, pos = leb(data, pos)
                if current == index:
                    return data[pos:pos + size]
                pos += size
            raise AssertionError('function not found')
        pos = end
    raise AssertionError('Code section missing')


OPS = {
    0x02: 'block', 0x03: 'loop', 0x0b: 'end', 0x0c: 'br', 0x0d: 'br_if',
    0x0e: 'br_table', 0x10: 'call', 0x1b: 'select', 0x20: 'local.get',
    0x21: 'local.set', 0x22: 'local.tee', 0x23: 'global.get', 0x24: 'global.set',
    0x28: 'i32.load', 0x29: 'i64.load', 0x2d: 'i32.load8_u', 0x2f: 'i32.load16_u',
    0x36: 'i32.store', 0x37: 'i64.store', 0x3a: 'i32.store8', 0x41: 'i32.const', 0x42: 'i64.const', 0x45: 'i32.eqz',
    0x46: 'i32.eq', 0x47: 'i32.ne', 0x49: 'i32.lt_u', 0x4a: 'i32.gt_s',
    0x4b: 'i32.gt_u', 0x4d: 'i32.le_u', 0x4f: 'i32.ge_u', 0x50: 'i64.eqz',
    0x51: 'i64.eq', 0x52: 'i64.ne', 0x6a: 'i32.add', 0x6b: 'i32.sub', 0x71: 'i32.and',
    0x72: 'i32.or', 0x73: 'i32.xor', 0x74: 'i32.shl', 0x76: 'i32.shr_u',
    0x7a: 'i64.ctz', 0x7c: 'i64.add', 0x83: 'i64.and', 0x84: 'i64.or',
    0x85: 'i64.xor', 0xa7: 'i32.wrap_i64',
}


def decode(body):
    groups, pos = leb(body, 0)
    locals_ = Counter()
    for _ in range(groups):
        count, pos = leb(body, pos)
        locals_[{0x7f: 'i32', 0x7e: 'i64'}[body[pos]]] += count
        pos += 1
    declaration_bytes = pos
    instructions = []
    while pos < len(body):
        start = pos
        opcode = body[pos]
        name = OPS[opcode]
        pos += 1
        args = []
        if opcode in (0x02, 0x03, 0x41, 0x42):
            value, pos = leb(body, pos, signed=True)
            args.append(value)
        elif opcode in (0x0c, 0x0d, 0x10, 0x20, 0x21, 0x22, 0x23, 0x24):
            value, pos = leb(body, pos)
            args.append(value)
        elif opcode == 0x0e:
            count, pos = leb(body, pos)
            for _ in range(count + 1):
                value, pos = leb(body, pos)
                args.append(value)
        elif opcode in (0x28, 0x29, 0x2d, 0x2f, 0x36, 0x37, 0x3a):
            for _ in range(2):
                value, pos = leb(body, pos)
                args.append(value)
        instructions.append({'opcode': name, 'offset': start, 'bytes': pos - start, 'args': args})
    return locals_, declaration_bytes, instructions


def ir_summary(path):
    lines = path.read_text().splitlines()
    start = next(i for i, line in enumerate(lines) if line.startswith('define ') and '@parse_composite_span_impl(' in line)
    end = next(i for i in range(start + 1, len(lines)) if lines[i] == '}')
    globals_ = {m[1]: m[2] for line in lines if (m := re.search(r'(@[^ ]+) = .*constant \[[0-9]+ x i8\] c"(.*?)"', line))}
    blocks = {'ENTRY': {'line': start + 1, 'lines': []}}
    current = 'ENTRY'
    for i in range(start + 1, end):
        line = lines[i]
        if m := re.match(r'^(\d+):', line):
            current = m[1]
            blocks[current] = {'line': i + 1, 'lines': []}
        blocks[current]['lines'].append(line)
    edges = {key: set(re.findall(r'label %(\d+)', '\n'.join(block['lines']))) for key, block in blocks.items()}
    predecessors = {key: set() for key in blocks}
    for key, targets in edges.items():
        for target in targets:
            predecessors[target].add(key)
    reachable = set()
    stack = ['ENTRY']
    while stack:
        key = stack.pop()
        if key not in reachable:
            reachable.add(key)
            stack.extend(edges[key])
    dominators = {key: ({'ENTRY'} if key == 'ENTRY' else set(reachable)) for key in reachable}
    changed = True
    while changed:
        changed = False
        for key in reachable - {'ENTRY'}:
            parents = predecessors[key] & reachable
            updated = {key} | set.intersection(*(dominators[p] for p in parents)) if parents else {key}
            if updated != dominators[key]:
                dominators[key] = updated
                changed = True
    loops = {}
    for tail, targets in edges.items():
        for head in targets:
            if head not in dominators[tail]:
                continue
            members = {head, tail}
            stack = [tail] if tail != head else []
            while stack:
                node = stack.pop()
                for parent in predecessors[node]:
                    if parent not in members:
                        members.add(parent)
                        stack.append(parent)
            loops.setdefault(head, set()).update(members)
    loop_receipts = []
    for head, members in sorted(loops.items(), key=lambda item: blocks[item[0]]['line']):
        text = '\n'.join('\n'.join(blocks[key]['lines']) for key in members)
        constants = sorted({globals_[g] for g in re.findall(r'@[^ ,()]+', text) if g in globals_}) if len(members) < 30 else []
        loop_receipts.append({'header': head, 'line': blocks[head]['line'], 'blocks': len(members), 'constants': constants})
    first_loop = min(item['line'] for item in loop_receipts)
    bases = []
    for i in range(start, first_loop - 1):
        m = re.match(r'\s*(%\d+) = getelementptr(?: inbounds)?(?: nuw)? i8, ptr %0, i32 (\d+)', lines[i])
        if m:
            uses = [j + 1 for j in range(i + 1, end) if re.search(re.escape(m[1]) + r'(?!\d)', lines[j])]
            bases.append({'line': i + 1, 'value': m[1], 'srcOffset': int(m[2]), 'useLines': uses})
    return {'functionLines': [start + 1, end + 1], 'blocks': len(blocks), 'naturalLoops': loop_receipts, 'hoistedSourceBases': bases}


def analyze(arm, asm_stem, wasm_name):
    asm = ROOT / 'profiling/parser-symbol-map' / (asm_stem + '.s')
    wasm = ROOT / 'profiling/parser-symbol-map' / wasm_name
    ir = TMP / ('composite-minsize-' + arm + '.ll')
    lines = asm.read_text().splitlines()
    start = next(i for i, line in enumerate(lines) if line.startswith('parse_composite_span_impl:'))
    end = next(i for i in range(start + 1, len(lines)) if lines[i].strip() == 'end_function')
    entries = []
    current_label = None
    for i in range(start, end + 1):
        line = lines[i].strip()
        if line.startswith('.LBB41_'):
            current_label = line.split(':')[0]
        if line and not line.startswith(('#', '.', 'parse_')):
            opcode = line.split()[0]
            normalized = 'end' if opcode.startswith('end_') else 'select' if opcode == 'i32.select' else opcode
            entries.append({'line': i + 1, 'asmOpcode': opcode, 'opcode': normalized, 'text': line, 'label': current_label})
    body = function_body(wasm)
    locals_, decl_bytes, decoded = decode(body)
    assert len(entries) == len(decoded), (arm, len(entries), len(decoded))
    for entry, decoded_entry in zip(entries, decoded):
        assert entry['opcode'] == decoded_entry['opcode'], (arm, entry, decoded_entry)
        entry.update(decoded_entry)
    opcode_counts = Counter(entry['asmOpcode'] for entry in entries)
    opcode_bytes = Counter()
    for entry in entries:
        opcode_bytes[entry['asmOpcode']] += entry['bytes']
    before_loop = entries[:next(i for i, entry in enumerate(entries) if entry['opcode'] == 'loop')]
    bases = []
    for i in range(len(before_loop) - 3):
        part = before_loop[i:i + 4]
        if [v['opcode'] for v in part] == ['local.get', 'i32.const', 'i32.add', 'local.set'] and part[0]['args'] == [0]:
            bases.append({'line': part[0]['line'], 'srcOffset': part[1]['args'][0], 'local': part[3]['args'][0], 'bytes': sum(v['bytes'] for v in part)})
    long_range = (28030, 28391) if arm == 'baseline' else (27947, 28017)
    long_entries = [entry for entry in entries if long_range[0] <= entry['line'] <= long_range[1]]
    table_entries = [entry for entry in entries if entry['opcode'] == 'br_table']
    long_opcode_bytes = Counter()
    for entry in long_entries:
        long_opcode_bytes[entry['asmOpcode']] += entry['bytes']
    receipt = {
        'inputs': [identity(path) for path in (asm, wasm, ir)],
        'functionIndex': 13, 'functionName': 'parse_composite_span_impl', 'functionAsmLines': [start + 1, end + 1],
        'bodyBytes': len(body), 'bodySha256': hashlib.sha256(body).hexdigest(),
        'localDeclarationBytes': decl_bytes, 'locals': dict(locals_), 'localsTotal': sum(locals_.values()),
        'instructionCount': len(entries), 'opcodeCounts': dict(sorted(opcode_counts.items())),
        'opcodeEncodedBytes': dict(sorted(opcode_bytes.items())),
        'assemblyOpcodeSequenceMatchesRetainedWasm': True,
        'loopLabels': [{'line': v['line'], 'label': v['label']} for v in entries if v['opcode'] == 'loop'],
        'prologueSourceBases': bases,
        'branchTables': {'instructions': len(table_entries), 'encodedBytes': sum(v['bytes'] for v in table_entries), 'targetsIncludingDefaults': sum(len(v['args']) for v in table_entries), 'entries': [{'line': v['line'], 'bytes': v['bytes'], 'targetsIncludingDefault': len(v['args'])} for v in table_entries]},
        'longKeywordLoweringSpan': {'asmLines': list(long_range), 'bodyOffsets': [long_entries[0]['offset'], long_entries[-1]['offset'] + long_entries[-1]['bytes']], 'encodedBytes': sum(v['bytes'] for v in long_entries), 'instructions': len(long_entries), 'opcodeCounts': dict(sorted(Counter(v['asmOpcode'] for v in long_entries).items())), 'opcodeEncodedBytes': dict(sorted(long_opcode_bytes.items())), 'scopeCaution': 'Layout-specific contiguous lowering span including dispatch/exit instructions; not an independently timed or semantically isolated kernel.'},
        'ir': ir_summary(ir),
    }
    return receipt


if __name__ == '__main__':
    report = {
        'method': 'Read existing optimized LLVM IR, compiler WebAssembly assembly, and retained WebAssembly body13. Match every assembly opcode in order to decoded binary opcodes before assigning encoded byte counts. Derive natural loops by CFG dominators/backedges. No compilation, execution, or timing.',
        'source': identity(ROOT / 'manabitan/ext/js/dictionary/wasm/term-bank-parser.c'),
        'baseline': analyze('baseline', 'baseline', 'term-bank-parser-named.wasm'),
        'candidate': analyze('candidate', 'composite-minsize', 'term-bank-parser-composite-minsize.wasm'),
    }
    (OUT / 'static-counts.json').write_text(json.dumps(report, indent=2) + '\n')
    for arm in ('baseline', 'candidate'):
        data = report[arm]
        print(arm, json.dumps({key: data[key] for key in ('bodyBytes', 'localsTotal', 'instructionCount', 'branchTables', 'longKeywordLoweringSpan')}))
