#!/usr/bin/env python3
"""Read retained full-import evidence; preserve every scheduled observation.

Internal stage timers overlap and are wall durations, not isolated CPU costs.
Only uninstrumented candidate/control slots enter the timing comparisons.
"""
import argparse
import hashlib
import json
import math
import pathlib
import statistics
import tarfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('directory', type=pathlib.Path)
args = p.parse_args()
root = args.directory
archive = root / 'raw-evidence.tar.gz'
manifest = json.loads((root / 'retention-manifest.json').read_text())
assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest['retainedArchive']['sha256']
checks = {}
observed = {}
with tarfile.open(archive, 'r:gz') as tar:
    def load(name):
        return json.load(tar.extractfile(name))
    plan = load('registered-plan.json')
    identity = load('source-identities.json')
    browser = load('browser-identity.json')
    observations = load('observations.json')
    analysis = load('analysis.json')
    overlay_hash = hashlib.sha256(tar.extractfile('memory/harness-instrumented.js').read()).hexdigest()
    checks['exact_schedule'] = [{k: x[k] for k in ('id', 'kind', 'pair', 'arm')} for x in observations] == plan['schedule']
    for member in tar.getmembers():
        if not member.name.endswith('/summary.json'):
            continue
        name = member.name.removesuffix('/summary.json')
        summary = load(member.name)
        report = load(name + '/run-1.json')
        run = summary['runs'][0]
        arm = name[-1] if name[-1] in 'ABC' else name.split('/')[-1][0]
        actual_arm = 'B' if arm == 'B' else 'A'
        source = identity['arms'][actual_arm]
        is_memory = name.startswith('memory/')
        expected_hashes = source['sourceHashes'].copy()
        if is_memory:
            expected_hashes['test/chromium/extension-two-dictionary-import.e2e.js'] = overlay_hash
        raw_imports = [x['data'] for x in report['phases'] if isinstance(x.get('data'), dict) and 'importDebug' in x['data']]
        assert len(raw_imports) == 1
        raw_import = raw_imports[0]
        checks[name + ':raw_success'] = report['status'] == 'success'
        checks[name + ':source_sha'] = summary['gitSha'] == summary['source']['gitSha'] == source['sha']
        checks[name + ':source_dirty'] = summary['source']['dirty'] is is_memory
        checks[name + ':source_hashes'] = summary['source']['sha256'] == expected_hashes
        checks[name + ':package_sha'] = run['packageSha256'] == report['packageSha256'] == source['packageSha256']
        checks[name + ':browser_version'] = summary['browserVersion'] == report['browserVersion'] == browser['version']
        checks[name + ':raw_stage_agreement'] = raw_import['importDebug'] == run['importDebug']
        checks[name + ':production_flags'] = summary['importFlags'] is None and report['benchmark']['productionImportDefaults'] is True
        checks[name + ':no_trace_or_phase_profiler'] = not summary['traceEnabled'] and not report['benchmark']['phaseProfiling']
        if not is_memory:
            checks[name + ':authoritative_timing'] = summary['authoritativeTiming'] is True and report['benchmark']['authoritativeTiming'] is True and not report['benchmark']['processSampling']
        phases = run['importDebug']['importerPhaseTimings']
        terms = [x for x in phases if x['phase'].startswith('term-file-fast-path:')]
        assert len(terms) == 1
        details = terms[0]['details']
        checks[name + ':three_workers'] = details['parserParallelWorkerCount'] == plan['expectedWorkers'] == 3
        checks[name + ':no_native_fallback'] = details['parserFusedFallbacks'] == details['dedupNativeFallbackCount'] == 0
        checks[name + ':native_calls_equal_groups'] = details['dedupNativeCallCount'] == details['chunkCount'] == details['parserParallelGroupCount']
        metrics = {k: v for k, v in details.items() if k.endswith('Ms') and isinstance(v, (int, float))}
        metrics.update({'totalImportMs': run['totalImportMs'], 'workerImportMs': run['workerImportMs'], 'termFastPathWallMs': terms[0]['elapsedMs']})
        for phase in phases:
            if not phase['phase'].startswith('term-file-fast-path:'):
                metrics['phase:' + phase['phase']] = phase['elapsedMs']
            if phase['phase'] == 'bulk-finalization':
                metrics.update({'finalization:' + k: v for k, v in phase['details'].items() if k.endswith('Ms') and isinstance(v, (int, float))})
        counters = {k: v for k, v in details.items() if (k.startswith('dedupNative') or k in {
            'rows', 'chunkCount', 'parserFusedAttempts', 'parserFusedFallbacks', 'parserBankSpanCount',
            'parserBorrowedContentResultCount', 'parserParallelWorkerCount', 'parserParallelPipelineGroupsPerWorker',
            'parserParallelGroupCount', 'parserSourceCompressedBytes', 'parserSourceUncompressedBytes',
            'parserSourceCrcScannedBytes', 'parserSourceCrcReusedBytes', 'parserEncodedContentBytes',
            'dedupUniqueCount', 'dedupExactFallbackCount', 'dedupRecentSourceHitCount',
        }) and not k.endswith('Ms')}
        observed[name] = {'arm': arm, 'isMemory': is_memory, 'metrics': metrics, 'counters': counters}
    for item in observations:
        checks[item['id'] + ':observation_duration'] = observed[item['id']]['metrics']['totalImportMs'] == item['totalImportMs']

def summarize(kind, left, right):
    items = [x for x in observations if x['kind'] == kind]
    pairs = sorted({x['pair'] for x in items})
    output = {}
    for key in observed[items[0]['id']]['metrics']:
        values = []
        for pair in pairs:
            a = next(x for x in items if x['pair'] == pair and x['arm'] == left)
            b = next(x for x in items if x['pair'] == pair and x['arm'] == right)
            values.append({'pair': pair, 'baseline': observed[a['id']]['metrics'][key], 'candidate': observed[b['id']]['metrics'][key]})
        ratios = [x['candidate'] / x['baseline'] for x in values] if all(x['baseline'] > 0 for x in values) else None
        output[key] = {
            'baselineMedian': statistics.median(x['baseline'] for x in values),
            'candidateMedian': statistics.median(x['candidate'] for x in values),
            'medianPairedDifference': statistics.median(x['candidate'] - x['baseline'] for x in values),
            'medianPairedChangePercent': (statistics.median(ratios) - 1) * 100 if ratios else None,
            'equalWorkChangePercent': (sum(x['candidate'] for x in values) / sum(x['baseline'] for x in values) - 1) * 100 if sum(x['baseline'] for x in values) > 0 else None,
            'fasterPairs': sum(x['candidate'] < x['baseline'] for x in values),
            'pairs': values,
        }
    return output

candidate = summarize('candidate', 'A', 'B')
control = summarize('control', 'A', 'C')
for derived, original in ((candidate['totalImportMs'], analysis['candidateVsBaseline']), (control['totalImportMs'], analysis['identicalCodeControl'])):
    for key in ('medianPairedChangePercent', 'equalWorkChangePercent', 'fasterPairs'):
        checks['recomputed:' + str(original['count']) + ':' + key] = math.isclose(derived[key], original[key], abs_tol=1e-10)
counter_values = {key: sorted({json.dumps(x['counters'][key], sort_keys=True) for x in observed.values()}) for key in next(iter(observed.values()))['counters']}
counter_values = {key: [json.loads(x) for x in values] for key, values in counter_values.items()}
result = {
    'scope': 'Complete retained cohort; no removed observations. Internal wall stage timers overlap, are not isolated CPU measurements, and do not establish causality for outliers.',
    'artifact': manifest['sourceArtifact'], 'retainedArchive': manifest['retainedArchive'],
    'plan': {k: plan[k] for k in ('baseline', 'candidate', 'dictionary', 'initialOrder', 'pairs', 'expectedWorkers', 'expectedPackageEntries')},
    'checksPassed': all(checks.values()), 'checkCount': len(checks), 'failedChecks': [k for k, v in checks.items() if not v],
    'observationCount': len(observations), 'allImportCount': len(observed),
    'rawNativeCounterValuesAcrossAllImports': counter_values,
    'candidateStageComparisons': candidate, 'controlStageComparisons': control,
    'rawPerImportMetrics': observed,
    'frozenHarnessAnalysis': analysis,
}
(root / 'audit-and-stage-analysis.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
selected = ['totalImportMs', 'workerImportMs', 'termFastPathWallMs', 'dedupScanMs', 'dedupCanonicalScanMs', 'dedupExactCompareMs', 'contentMetadataPublishMs', 'contentCompressMs', 'parserParseBankMs', 'parserSourceInflateMs', 'parserResultCopyMs', 'phase:bulk-finalization', 'finalization:termRecordEndImportSessionCloseWritableMs']
print(json.dumps({'checksPassed': result['checksPassed'], 'checkCount': result['checkCount'], 'failedChecks': result['failedChecks'], 'nativeCounters': counter_values, 'stageSummary': {k: {field: value for field, value in candidate[k].items() if field != 'pairs'} for k in selected}}, indent=2))
assert result['checksPassed']
