#!/usr/bin/env python3
"""Verify one hosted artifact and retain its complete raw textual evidence.

Nested product packages and generated HTML are omitted only after their hashes
are recorded and both packages' actual members match source-identities.json.
This does not run, retry, select, alter, or reinterpret any observation.
"""
import argparse
import gzip
import hashlib
import io
import json
import pathlib
import shutil
import tarfile
import zipfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--zip', type=pathlib.Path, required=True)
p.add_argument('--output', type=pathlib.Path, required=True)
p.add_argument('--expected-sha256', required=True)
p.add_argument('--artifact-id', type=int, required=True)
p.add_argument('--run-id', type=int, required=True)
p.add_argument('--job-id', type=int, required=True)
args = p.parse_args()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def file_digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

assert file_digest(args.zip) == args.expected_sha256
assert not args.output.exists(), args.output
temporary = args.zip.with_suffix('.evidence.tar.gz')
assert not temporary.exists(), temporary
manifest = {
    'schemaVersion': 1,
    'scope': 'Lossless retention of all raw JSON, JSONL, log, and protocol JS evidence; no observation exclusions or retries.',
    'sourceArtifact': {'id': args.artifact_id, 'runId': args.run_id, 'jobId': args.job_id, 'sha256': args.expected_sha256, 'bytes': args.zip.stat().st_size},
    'included': {}, 'omittedRedundant': {}, 'derived': {},
}
with zipfile.ZipFile(args.zip) as z:
    members = z.infolist()
    names = [i.filename for i in members]
    assert len(names) == len(set(names)), 'Duplicate outer ZIP member'
    assert all(not pathlib.PurePosixPath(n).is_absolute() and '..' not in pathlib.PurePosixPath(n).parts for n in names)
    identity = json.loads(z.read('source-identities.json'))
    plan = json.loads(z.read('registered-plan.json'))
    assert identity['arms']['A']['sha'] == plan['baseline']
    assert identity['arms']['B']['sha'] == plan['candidate']
    package_audit = {'scope': 'Actual nested package bytes and every member independently rehashed from the downloaded GitHub artifact.', 'arms': {}}
    package_hashes = {}
    for arm in ('A', 'B'):
        name = f'package-{arm}.zip'
        data = z.read(name)
        package_hashes[name] = digest(data)
        assert package_hashes[name] == identity['arms'][arm]['packageSha256']
        with zipfile.ZipFile(io.BytesIO(data)) as package:
            files = package.infolist()
            assert len(files) == len({i.filename for i in files}), 'Duplicate nested package member'
            entries = {i.filename: digest(package.read(i)) for i in files if not i.is_dir()}
        assert entries == identity['arms'][arm]['entries'], f'Package member mismatch for {arm}'
        package_audit['arms'][arm] = {'sourceSha': identity['arms'][arm]['sha'], 'packageSha256': package_hashes[name], 'entryCount': len(entries), 'entries': entries}
        del data
    assert package_audit['arms']['A']['entries'].keys() == package_audit['arms']['B']['entries'].keys()
    changed = sorted(n for n, h in package_audit['arms']['A']['entries'].items() if h != package_audit['arms']['B']['entries'][n])
    assert changed == sorted(plan['expectedPackageEntries']) == sorted(identity['changedPackageEntries'])
    package_audit['changedPackageEntries'] = changed
    package_audit['passes'] = True
    audit_bytes = (json.dumps(package_audit, indent=2, sort_keys=True) + '\n').encode()
    manifest['derived']['derived-package-audit.json'] = {'bytes': len(audit_bytes), 'sha256': digest(audit_bytes)}
    retained_bytes = sum(i.file_size for i in members if pathlib.PurePosixPath(i.filename).suffix in {'.json', '.jsonl', '.log', '.js'})
    assert shutil.disk_usage(temporary.parent).free > retained_bytes + 16 * 1024 * 1024
    with temporary.open('xb') as out, gzip.GzipFile(fileobj=out, mode='wb', compresslevel=9, mtime=0, filename='') as compressed, tarfile.open(fileobj=compressed, mode='w|') as tar:
        def add(name, data):
            item = tarfile.TarInfo(name)
            item.size = len(data)
            item.mode = 0o644
            item.mtime = 0
            tar.addfile(item, io.BytesIO(data))
        for member in sorted(members, key=lambda i: i.filename):
            if member.is_dir():
                continue
            data = z.read(member)
            entry = {'bytes': len(data), 'sha256': digest(data)}
            if pathlib.PurePosixPath(member.filename).suffix in {'.json', '.jsonl', '.log', '.js'}:
                manifest['included'][member.filename] = entry
                add(member.filename, data)
            else:
                assert pathlib.PurePosixPath(member.filename).suffix in {'.html', '.zip'}, member.filename
                manifest['omittedRedundant'][member.filename] = entry
        add('derived-package-audit.json', audit_bytes)

expected = {**manifest['included'], **manifest['derived']}
with tarfile.open(temporary, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(expected)
    assert {m.name for m in members} == expected.keys()
    for member in members:
        data = tar.extractfile(member).read()
        assert len(data) == expected[member.name]['bytes']
        assert digest(data) == expected[member.name]['sha256']

manifest['retainedArchive'] = {'name': 'raw-evidence.tar.gz', 'bytes': temporary.stat().st_size, 'sha256': file_digest(temporary), 'verifiedFileCount': len(expected)}
manifest_bytes = (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()
args.output.parent.mkdir(parents=True, exist_ok=True)
assert shutil.disk_usage(args.output.parent).free > temporary.stat().st_size + len(manifest_bytes) + 16 * 1024 * 1024
args.output.mkdir()
destination = args.output / 'raw-evidence.tar.gz'
with temporary.open('rb') as source, destination.open('xb') as out:
    shutil.copyfileobj(source, out, 1024 * 1024)
assert file_digest(destination) == manifest['retainedArchive']['sha256']
(args.output / 'retention-manifest.json').write_bytes(manifest_bytes)
temporary.unlink()
args.zip.unlink()
print(json.dumps({'retained': str(args.output), 'packageAuditPassed': True, 'changedPackageEntries': changed, 'includedOriginalFiles': len(manifest['included']), 'omittedRedundantFiles': len(manifest['omittedRedundant']), 'archive': manifest['retainedArchive'], 'deletedOnlyVerifiedOwnDownload': str(args.zip)}, indent=2))
