"""Losslessly retain an owned immutable capture before reclaiming its raw files."""
import gzip
import hashlib
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path

root = Path(__file__).resolve().parent
source = root / 'canonical-capture-jmdict.json.groups'
archive = root / 'canonical-jmdict-capture.tar.gz'
receipt = root / 'canonical-jmdict-capture-archive-receipt.json'


def digest(stream):
    value = hashlib.sha256()
    while data := stream.read(1024 * 1024):
        value.update(data)
    return value.hexdigest()


assert source.is_dir() and not source.is_symlink()
assert not archive.exists() and not receipt.exists()
paths = sorted(source.iterdir())
assert len(paths) == 24
assert all(p.is_file() and not p.is_symlink() for p in paths)
expected = {f'group-{index:04d}.{suffix}' for index in range(12) for suffix in ('bin', 'json')}
assert {p.name for p in paths} == expected
members = []
for path in paths:
    with path.open('rb') as stream:
        members.append({'name': path.relative_to(root).as_posix(), 'bytes': path.stat().st_size,
                        'sha256': digest(stream)})
with archive.open('xb') as output, gzip.GzipFile(filename='', mode='wb', fileobj=output,
                                               mtime=0, compresslevel=6) as compressed:
    with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
        for path, member in zip(paths, members, strict=True):
            info = tarfile.TarInfo(member['name'])
            info.size = member['bytes']
            info.mode = 0o644
            with path.open('rb') as stream:
                tar.addfile(info, stream)
verified = []
with tarfile.open(archive, 'r:gz') as tar:
    for info, member in zip(tar, members, strict=True):
        assert info.isfile() and info.name == member['name'] and info.size == member['bytes']
        assert digest(tar.extractfile(info)) == member['sha256']
        verified.append(info.name)
assert len(verified) == 24
for path, member in zip(paths, members, strict=True):
    with path.open('rb') as stream:
        assert digest(stream) == member['sha256']
with archive.open('rb') as stream:
    archive_sha = digest(stream)
result = {'asOfUtc': datetime.now(timezone.utc).isoformat(), 'kind': 'lossless-owned-capture-archival',
          'archive': str(archive), 'archiveSha256': archive_sha, 'archiveBytes': archive.stat().st_size,
          'rawBytes': sum(m['bytes'] for m in members), 'members': members,
          'allMemberBytesIndependentlyReadBack': True, 'originalsRecheckedBeforeRemoval': True,
          'originalGroupFilesRemoved': False,
          'scope': 'Only this task-owned capture directory. Parent JSON, locked dictionaries, raw observations, and other work remain.'}
receipt.write_text(json.dumps(result, indent=2) + '\n')
for path in paths:
    path.unlink()
source.rmdir()
result['originalGroupFilesRemoved'] = True
receipt.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'members'}, indent=2))
