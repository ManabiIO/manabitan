#!/usr/bin/env python3
"""Audit retained hosted receipts and memory scans without running imports."""
import hashlib
import importlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parent.parent
CELL = Path(sys.argv[1]).resolve()
ARCHIVE = CELL/'raw-evidence.tar.gz'
checks = {}
details = {}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check(name, condition):
    checks[name] = bool(condition)

def git_bytes(ref,path):
    return subprocess.check_output(['git','-C',str(ROOT/'manabitan'),'show',ref+':'+path])

retention=json.loads((CELL/'retention-manifest.json').read_text())
check('retained_archive_hash',sha(ARCHIVE.read_bytes())==retention['retainedArchive']['sha256'])
check('retained_archive_size',ARCHIVE.stat().st_size==retention['retainedArchive']['bytes'])
files={}
with tarfile.open(ARCHIVE,'r:gz') as archive:
    for member in archive:
        check('safe_unique_regular_member:'+member.name,member.isfile() and member.name not in files and not member.name.startswith('/') and '..' not in Path(member.name).parts)
        files[member.name]=archive.extractfile(member).read()
expected={**retention['included'],**retention['derived']}
check('retention_inventory_exact',set(files)==set(expected))
check('retention_member_count',len(files)==retention['retainedArchive']['verifiedFileCount'])
for name,item in expected.items():
    check('retention_hash_size:'+name,len(files[name])==item['bytes'] and sha(files[name])==item['sha256'])

def js(name):
    return json.loads(files[name])

plan=js('registered-plan.json')
identities=js('source-identities.json')
browser=js('browser-identity.json')
dictionary=plan['dictionary']
base=plan['baseline']
candidate=plan['candidate']
fixture_lock=git_bytes(base,'test/perf/dictionaries.lock.json')
fixture=json.loads(fixture_lock)['dictionaries'][dictionary]
frozen_dir=ROOT/'baseline/dev/perf/import-memory-20261125-a7f7'
sys.path.insert(0,str(frozen_dir))
module_hashes={}
for name in ['qualification_receipts.py','chromium_memory.py','audit_memory.py','protocol.py']:
    path='dev/perf/import-memory-20261125-a7f7/'+name
    data=(frozen_dir/name).read_bytes()
    check('frozen_audit_module:'+name,data==git_bytes(base,path))
    module_hashes[name]=sha(data)
receipts=importlib.import_module('qualification_receipts')
audit_memory=importlib.import_module('audit_memory')
protocol=importlib.import_module('protocol')

check('frozen_arms',identities['arms']['A']['sha']==base and identities['arms']['B']['sha']==candidate)
check('fixture_lock_both_arms',all(x['fixtureLockSha256']==sha(fixture_lock) for x in identities['arms'].values()))
check('browser_version_shape',re.fullmatch(r'\d+(?:\.\d+){3}',browser['version']) is not None)
check('browser_executable_hash_shape',re.fullmatch('[0-9a-f]{64}',browser['sha256']) is not None)
for arm,data in identities['arms'].items():
    check('commit_tree:'+arm,subprocess.check_output(['git','-C',str(ROOT/'manabitan'),'rev-parse',data['sha']+'^{tree}'],text=True).strip()==data['tree'])
    for name,digest in data['sourceHashes'].items():
        if name.startswith('builds/'):
            continue
        check('source_hash:'+arm+':'+name,sha(git_bytes(data['sha'],name))==digest)

packages=js('derived-package-audit.json')
check('retainer_package_audit_pass',packages['passes'] is True)
entry_diffs=sorted(k for k in identities['arms']['A']['entries'].keys()|identities['arms']['B']['entries'].keys()
                   if identities['arms']['A']['entries'].get(k)!=identities['arms']['B']['entries'].get(k))
check('package_entry_sets_equal',identities['arms']['A']['entries'].keys()==identities['arms']['B']['entries'].keys())
check('exact_prospective_package_differences',entry_diffs==sorted(plan['expectedPackageEntries'])==sorted(packages['changedPackageEntries'])==sorted(identities['changedPackageEntries']))
for arm,data in identities['arms'].items():
    derived=packages['arms'][arm]
    check('package_audit_binding:'+arm,derived['entries']==data['entries'] and derived['entryCount']==len(data['entries']) and derived['packageSha256']==data['packageSha256'] and derived['sourceSha']==data['sha'])
    for name in entry_diffs:
        source='dev/data/dictionary-wasm/'+Path(name).name if name.startswith('lib/') else 'ext/'+name
        check('changed_package_entry_matches_source:'+arm+':'+name,sha(git_bytes(data['sha'],source))==data['entries'][name])

memory_plan=js('memory/plan.json')
check('memory_schedule_fixed',memory_plan['schedule']==protocol.schedule(memory_plan['replication'])==plan['memorySchedule'])
original=files['memory/harness-original.js'].decode()
instrumented=files['memory/harness-instrumented.js'].decode()
harness_path='test/chromium/extension-two-dictionary-import.e2e.js'
check('memory_original_harness_frozen',original.encode()==git_bytes(base,harness_path)==git_bytes(candidate,harness_path))
check('memory_exact_marker_overlay',protocol.memory_overlay(original)==instrumented)
check('memory_overlay_hash',sha(instrumented.encode())==memory_plan['overlaySha256'])
for arm,identity in identities['arms'].items():
    check('memory_plan_retains_original_identity:'+arm,identity==memory_plan['sourceHashes'][arm])

observations=[]
for row in plan['schedule']:
    observations.append({'location':row['id'],'arm':'A' if row['arm']=='C' else row['arm'],'kind':row['kind'],'media':'sample','memory':False})
for arm in ['A','B']:
    observations.append({'location':'exhaustive-media-'+arm,'arm':arm,'kind':'exhaustive-media','media':'all','memory':False})
for row in memory_plan['schedule']:
    observations.append({'location':'memory/'+row['name'],'arm':row['arm'],'kind':'memory','media':'sample','memory':True})
check('all_prescribed_42_observations',len(observations)==42 and len({x['location'] for x in observations})==42)
actual_receipt_dirs={str(Path(name).parent) for name in files if name.endswith('/canonical-receipt.json')}
check('receipt_directories_exact',actual_receipt_dirs=={x['location'] for x in observations})
canonical=[]
observed_scope=[]
for item in observations:
    location=item['location']
    summary=js(location+'/summary.json')
    report=js(location+'/run-1.json')
    identity=(memory_plan['sourceHashes'] if item['memory'] else identities['arms'])[item['arm']]
    expected_source_hashes=dict(identity['sourceHashes'])
    if item['memory']:
        expected_source_hashes[harness_path]=sha(instrumented.encode())
    computed=receipts.validate_import_summary(
        summary,report,dictionary=dictionary,fixture=fixture,
        source_sha=identity['sha'],package_sha256=identity['packageSha256'],
        browser_version=browser['version'],import_flags=plan['flags'] if plan['flags'] else None,source_hashes=expected_source_hashes,
        source_dirty=item['memory'],media_check=item['media'],
        vndb_sah_allocation_units=plan.get('vndbSahAllocationPolicy'),
    )
    retained=js(location+'/canonical-receipt.json')
    check('normalized_receipt_regenerated:'+location,computed==retained)
    validation=computed['common']['validation']
    lookup=validation['lookup']['observations']
    check('72_complete_cold_warm_lookups:'+location,len(lookup)==72 and {(x['pass'],x['term']) for x in lookup}=={(p,t) for p in range(6) for t in validation['probeTerms']})
    check('restart_readable_and_counts:'+location,validation['restart']['contentReadable'] is True and validation['restart']['termRows']==fixture['termRows'] and validation['restart']['mediaFiles']==fixture['mediaFiles'])
    check('all_exact_headword_matches:'+location,all(x['hasExactHeadwordMatch'] and x['results']>0 for x in lookup))
    canonical.append((item,computed))
    observed_scope.append({'location':location,'kind':item['kind'],'arm':item['arm'],'lookupObservations':len(lookup),'outputDigestSha256':validation['outputDigestSha256'],'media':computed['media'],'storageBytes':validation['storage']['bytes']})
reference=canonical[0][1]
for item,receipt in canonical:
    receipts.require_matching_receipts(reference,receipt,compare_media=item['media']=='sample')
    check('common_semantics_equal:'+item['location'],receipt['common']==reference['common'])
full_media=[r for item,r in canonical if item['media']=='all']
receipts.require_matching_receipts(full_media[0],full_media[1])
check('exhaustive_media_equality',full_media[0]['media']==full_media[1]['media'] and full_media[0]['media']['files']==fixture['mediaFiles'] and full_media[0]['media']['bytes']==fixture['mediaBytes'])

temp_parent=Path('/tmp/manabitan-profiling-9bb32')
temp_parent.mkdir(exist_ok=True)
temporary=Path(tempfile.mkdtemp(prefix='independent-jitendex-ab-',dir=temp_parent))
try:
    for name,data in files.items():
        if not name.startswith('memory/'):
            continue
        destination=temporary/name
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_bytes(data)
    recomputed_memory=audit_memory.audit_cell(temporary/'memory')
    check('all_raw_memory_scans_recomputed',recomputed_memory==js('memory/memory-audit.json'))
    rebuilt_comparison=protocol.memory_comparison(js('memory/observations.json'),dictionary,memory_plan['replication'],protocol.schedule)
    check('independent_memory_comparison',rebuilt_comparison==js('memory/memory-comparison.json'))
    memory_slots=[]
    for row in memory_plan['schedule']:
        memory=js('memory/'+row['name']+'/memory.json')
        memory_slots.append({**row,**{k:memory[k] for k in ['benchmarkExitCode','qualifiedForWholeTreePss','qualificationFailures','allObservedSampleCount','fullyContainedImportSampleCount','stableFullyReadImportSampleCount','maximumCoveredSampleGapMs','preImportBracketGapMs','postImportBracketGapMs','maxSampledPssKiB','maxSampledPrivateKiB']}})
finally:
    shutil.rmtree(temporary)
check('own_temporary_extraction_removed',not temporary.exists())
check('raw_archive_unchanged',sha(ARCHIVE.read_bytes())==retention['retainedArchive']['sha256'])

result={
 'scope':'Independent retained-artifact semantic/restart/media and raw sampled-memory audit; no imports, benchmarks, product edits or publication.',
 'cell':str(CELL.relative_to(ROOT)),'passed':all(checks.values()),'checkCount':len(checks),'failedChecks':[k for k,v in checks.items() if not v],
 'archiveSha256':retention['retainedArchive']['sha256'],'archiveMembers':len(files),'sourceArtifact':retention['sourceArtifact'],
 'retentionManifestSha256':sha((CELL/'retention-manifest.json').read_bytes()),'auditScriptSha256':sha(Path(__file__).read_bytes()),
 'frozenAuditModuleHashes':module_hashes,'sourcePins':{'A':base,'B':candidate},'browserIdentity':browser,
 'semanticSummary':{'observations':len(observations),'lookupsPerObservation':72,'distinctProbeTerms':12,'lookupPasses':6,'allNormalizedCommonSemanticsEqual':True,'restartTermRows':fixture['termRows'],'fullMedia':full_media[0]['media'],'allMediaArmCount':2,'outputDigestSha256':reference['common']['validation']['outputDigestSha256'],'storageBytes':reference['common']['validation']['storage']['bytes']},
 'memorySummary':recomputed_memory,'memorySlots':memory_slots,
 'packageSummary':{'entriesPerArm':{a:len(x['entries']) for a,x in identities['arms'].items()},'exactChangedEntries':entry_diffs,'nestedPackagesRehashedByRetainer':True,'nestedPackagesRehashedByThisAudit':False},
 'limits':[
  'Persisted lookup checks cover twelve fixed terms over one cold and five warm passes, not exhaustive persisted-row equality. Per-response digests cover the acquisition harness canonical responses; their original payload bodies are not retained for rehashing here.',
  'Two separate media receipts report every referenced file/byte and match across arms. Original media payload bytes are not retained in this cell archive; this audit validates bound receipt generation and agreement, not a fresh media read.',
  'Memory uses non-atomic Linux process-tree smaps_rollup samples. Qualified coverage brackets the import with the frozen 250 ms bound; short-lived processes and between-scan peaks can be missed. It is sampled PSS/private memory, not a guaranteed absolute process peak.',
  'Actual package ZIPs were independently rehashed by the retaining agent before omission. This audit checks the bound member maps, exact prospective differences, changed source/native bytes and source/browser report identities; it does not repeat absent ZIP or browser-executable byte hashes.',
  'This is one host/order cell. Semantic and memory gate passes do not establish an import-speed gain or qualification of another cell.',
 ],
 'observations':observed_scope,'checks':checks,
}
output=CELL/'independent-semantics-memory-audit.json'
output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','observations','limits','frozenAuditModuleHashes']}))
