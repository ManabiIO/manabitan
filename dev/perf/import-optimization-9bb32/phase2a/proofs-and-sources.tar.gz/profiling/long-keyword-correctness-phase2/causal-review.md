# Wide keyword comparison: causal review

This review binds published commit `ebf4278afc59d83f191692bd587f0e1f7e8682b3`, tree `611b6e1591ffbbc9c978c33dee9af72a7b618536`. The original local commit `1ec7369996d8b4e24802854b0524709aa54aadb3` has the same complete tree. The source and parser hashes remain `02fb89b447e8c5520092ae85c4c6194ed5e32e03fecaad2602bbf12545360797` and `6962928b4810ac489048b6a686e3a6cdbcd7fe3116328a13fa458bd02634024c`.

**These are mechanisms worth testing, not a measured import improvement.** No timing was run for this candidate. The 56 new native cases passed; local lint and the existing focused-suite process were killed without verdicts. Hosted complete correctness, full-output parity, and then frozen full-import comparisons remain necessary.

## What the static evidence establishes

The change is confined to long literals in `json_string_matches_ascii`; current long calls compare the 18-byte `structured-content` keyword in composite glossary validation and native image projection. Short-keyword source, escape decoding, ordinary string scanning, and grammar policy remain unchanged. See the [published C source](https://github.com/ManabiIO/manabitan/blob/ebf4278afc59d83f191692bd587f0e1f7e8682b3/ext/js/dictionary/wasm/term-bank-parser.c) and `../long-keyword-wide-static-phase2/independent-source-review.json`.

Only two Wasm bodies differ. Function 13, `parse_composite_span_impl`, shrinks from 6069 to 5413 bytes; function 11, `project_glossary_image_value`, shrinks from 4209 to 3604. All 49 other bodies and every non-Code section are byte-identical. Function 13 retains 4 loops and 12 call sites, while its Wasm locals fall 35→24 and its hoisted source-base preparations fall 17→6. The successful long literal uses five source loads—first byte, closing quote, two 64-bit words, and a 16-bit tail—instead of 19 byte loads in the old chain. The full logical span and closing quote are checked before wide loads. These counts are bound to decoded binary opcodes in `../long-keyword-wide-static-phase2/static-comparison.json`.

## How the dictionary paths could differ

| Dictionary path | Mechanism to evaluate | Evidence and limit |
|---|---|---|
| JMdict | Fewer entry preparations can help even when a glossary is a plain array and never reaches the long-keyword comparison. That is a fixed-per-composite-call hypothesis. | Function 13 is a hotspot in the retained fresh trace. Corrected fixture options disable media hints and native image projection. No corpus-wide plain/structured count was retained, so this review assigns no frequency or saved time to either shape. |
| Jitendex | A matching structured type can use the shorter wide comparison as well as the smaller entry. | Corrected fixture options enable media hints but disable native image projection; function 13 is the relevant shared path. How frequently it compares the long type is unmeasured. Long nested text alone does not imply more long-keyword comparisons. |
| VNDB | The shared composite change applies, and the native image-projection caller can also benefit when it compares a structured type. | Corrected fixture options enable native projection. Its long-type frequency is unmeasured; the function 11 reduction cannot be credited to every image or row. |

The route evidence is in the retained baseline verification receipts `../composite-minsize-screen-1/jmdict-verify-A.json`, `jitendex-verify-A.json`, and `../composite-minsize-vndb-parity-1/A.json`. `../pipeline-replay.mjs` derives these options from the existing importer gates. Earlier mismatched options are explicitly invalidated by `../exploratory-observation-status.json`. No dictionary-specific policy is introduced.

Unlike function-wide minsize, this variant does not roll seven keyword comparisons or the Unicode-escape loop, and it retains the original four-loop composite shape. That isolates a narrower tradeoff, but it does not establish that any observed minsize regression would disappear. The relevant comparison is against the frozen baseline, using this candidate's exact bytes.

## Limits on the causal claim

Wasm locals and address operations are not measured native register counts or CPU costs. A browser JIT may fold or reposition them. The saved samples identify function 13, not its prologue or individual comparisons, and are summed across workers rather than import critical-path time (`../parser-symbol-map/symbol-map.json`). The parser module is already shared with workers, so compile effects must not be multiplied by worker count.

Same-first-byte nonmatches can do extra work before entering the original escaped decoder. Unrelated first bytes still reject cheaply, and a leading escape goes directly to that decoder. The wide path also rereads the first byte inside its first word: fewer load instructions do not mean fewer logical source bytes examined. No worker count, threshold, allocation policy, API, persisted format, compression, CRC, or storage-finalization behavior changes. Gains in parser work may be hidden by another stage of a full import.

## Historical ownership caveat

The targeted history audit found no current implementation of this same generic helper change. #306 owns the existing small literal/escaped split, which is retained. #948 already uses wide literal comparisons inside a separate grammar/type-dispatch specialization; the related technique is acknowledged. The rejected literal shortcut in #83 remains an unresolved caveat because its variant source was not preserved. The current bounds review and native regressions do not replace full qualification. The previously rejected SIMD scanner direction in #44 is also excluded; this variant changes no scanner source. See `../wide-literal-ownership-contract-review.json` and `../scanner-simd-prior-review-phase2.json`.
