"""One bounded correctness run; no benchmark or retry logic."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
WORKTREE = ROOT / 'wide-keyword'
node = ROOT / 'profiling/runtime/node/bin/node'
receipt_path = OUT / 'focused-existing-run.json'
if receipt_path.exists():
    raise SystemExit('Run already recorded; do not automatically retry.')
files = [
    'test/term-bank-native-hotpaths.test.js',
    'test/term-bank-media-projection.test.js',
    'test/term-bank-media-presence.test.js',
    'test/term-bank-composite-state.test.js',
    'test/term-bank-adjacent-delimiters.test.js',
    'test/term-bank-common-colon.test.js',
    'test/term-bank-content-container-open.test.js',
    'test/term-bank-glossary-semantics.test.js',
    'test/term-bank-format3-row.test.js',
    'test/term-bank-wasm-parser.test.js',
    'test/term-bank-wasm-differential.fuzz.test.js',
]
command = [str(node), '--max-old-space-size=384', 'node_modules/vitest/vitest.mjs', 'run', *files, '--maxWorkers=1', '--reporter=default', '--reporter=json', '--outputFile=' + str(OUT / 'focused-existing-tests.json')]
def identities():
    result = {}
    for relative in ['ext/js/dictionary/wasm/term-bank-parser.c', 'dev/data/dictionary-wasm/manifest.json', 'dev/data/dictionary-wasm/term-bank-parser.wasm', 'ext/lib/term-bank-parser.wasm', 'test/term-bank-wide-keyword.test.js']:
        data = (WORKTREE / relative).read_bytes()
        result[relative] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    return result
receipt = {'status': 'attempting', 'command': command, 'worktree': str(WORKTREE), 'nodeVersion': subprocess.check_output([str(node), '--version'], text=True).strip(), 'purpose': 'Correctness only; new 56-case file already passed separately.', 'timingExperiment': False, 'before': identities()}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
with (OUT / 'focused-existing.stdout.log').open('wb') as stdout, (OUT / 'focused-existing.stderr.log').open('wb') as stderr:
    result = subprocess.run(command, cwd=WORKTREE, stdout=stdout, stderr=stderr)
receipt['exitCode'] = result.returncode
receipt['status'] = 'completed' if result.returncode == 0 else 'failed-no-retry'
receipt['after'] = identities()
receipt['sourceAndArtifactUnchanged'] = receipt['after'] == receipt['before']
report = OUT / 'focused-existing-tests.json'
if report.exists():
    tests = json.loads(report.read_text())
    receipt['summary'] = {key: tests.get(key) for key in ['success', 'numTotalTestSuites', 'numPassedTestSuites', 'numFailedTestSuites', 'numTotalTests', 'numPassedTests', 'numFailedTests', 'numPendingTests']}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt[key] for key in ['status', 'exitCode', 'sourceAndArtifactUnchanged']} | {'summary': receipt.get('summary')}, indent=2))
raise SystemExit(result.returncode)
