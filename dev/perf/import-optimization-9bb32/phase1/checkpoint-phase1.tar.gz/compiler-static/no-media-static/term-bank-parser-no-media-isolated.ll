; ModuleID = '/tmp/manabitan-profiling-9bb32/no-media-static/term-bank-parser-no-media-isolated.c'
source_filename = "/tmp/manabitan-profiling-9bb32/no-media-static/term-bank-parser-no-media-isolated.c"
target datalayout = "e-m:e-p:32:32-p10:8:8-p20:8:8-i64:64-i128:128-n32:64-S128-ni:1:10:20"
target triple = "wasm32-freestanding"

%struct.Crc32Shift = type { i32, [8 x [16 x i32]] }
%struct.TermRowMeta = type { i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32 }
%struct.GlossaryImagePath = type { i32, i32, i32 }
%struct.TermBankCursor = type { ptr, ptr, i32, i32, i32, i32, i32 }

@__heap_base = external global i8, align 1
@heap_ptr = internal unnamed_addr global i32 0, align 4
@last_parse_capacity = internal unnamed_addr global i32 0, align 4
@last_content_capacity = internal unnamed_addr global i32 0, align 4
@crc32_table_initialized = internal unnamed_addr global i1 false, align 4
@crc32_table = internal unnamed_addr global [16 x [256 x i32]] zeroinitializer, align 16
@crc32_braid_initialized = internal unnamed_addr global i1 false, align 4
@crc32_braid_table = internal unnamed_addr global [8 x [256 x i32]] zeroinitializer, align 16
@.str = private unnamed_addr constant [8 x i8] c"content\00", align 1
@.str.1 = private unnamed_addr constant [5 x i8] c"path\00", align 1
@.str.2 = private unnamed_addr constant [5 x i8] c"type\00", align 1
@.str.3 = private unnamed_addr constant [4 x i8] c"tag\00", align 1
@.str.4 = private unnamed_addr constant [6 x i8] c"image\00", align 1
@.str.5 = private unnamed_addr constant [19 x i8] c"structured-content\00", align 1
@.str.6 = private unnamed_addr constant [4 x i8] c"img\00", align 1
@.str.10 = private unnamed_addr constant [5 x i8] c"text\00", align 1
@encode_term_content_row.PREFIX_RULES = internal unnamed_addr constant [10 x i8] c"{\22rules\22:\00", align 1
@encode_term_content_row.PREFIX_DEFINITION_TAGS = internal unnamed_addr constant [19 x i8] c",\22definitionTags\22:\00", align 16
@encode_term_content_row.PREFIX_TERM_TAGS = internal unnamed_addr constant [13 x i8] c",\22termTags\22:\00", align 1
@encode_term_content_row.PREFIX_GLOSSARY = internal unnamed_addr constant [13 x i8] c",\22glossary\22:\00", align 1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write)
define hidden noundef ptr @memset(ptr noundef returned writeonly captures(ret: address, provenance) %0, i32 noundef %1, i32 noundef %2) local_unnamed_addr #0 {
  %4 = trunc i32 %1 to i8
  tail call void @llvm.memset.p0.i32(ptr align 1 %0, i8 %4, i32 %2, i1 false)
  ret ptr %0
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i32(ptr writeonly captures(none), i8, i32, i1 immarg) #1

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite)
define hidden noundef ptr @memcpy(ptr noundef returned writeonly captures(ret: address, provenance) %0, ptr noundef readonly captures(none) %1, i32 noundef %2) local_unnamed_addr #2 {
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %0, ptr align 1 %1, i32 %2, i1 false)
  ret ptr %0
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i32(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i32, i1 immarg) #3

; Function Attrs: nounwind
define i32 @inflate_and_join_term_banks(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef %6, i32 noundef %7, i32 noundef %8, i32 noundef %9, i32 noundef %10, i32 noundef %11) local_unnamed_addr #4 {
  %13 = icmp eq i32 %7, 0
  %14 = icmp ult i32 %9, 2
  %15 = or i1 %13, %14
  br i1 %15, label %163, label %16

16:                                               ; preds = %12
  %17 = icmp ne i32 %11, 0
  %18 = icmp eq i32 %10, 0
  %19 = and i1 %18, %17
  br i1 %19, label %163, label %20

20:                                               ; preds = %16
  %21 = inttoptr i32 %0 to ptr
  %22 = inttoptr i32 %2 to ptr
  %23 = inttoptr i32 %3 to ptr
  %24 = inttoptr i32 %4 to ptr
  %25 = inttoptr i32 %5 to ptr
  %26 = inttoptr i32 %6 to ptr
  %27 = inttoptr i32 %8 to ptr
  %28 = inttoptr i32 %10 to ptr
  %29 = zext i1 %18 to i32
  br i1 %18, label %30, label %31

30:                                               ; preds = %20
  store i8 91, ptr %27, align 1, !tbaa !2
  br label %31

31:                                               ; preds = %20, %30
  %32 = icmp eq i32 %11, 0
  br label %33

33:                                               ; preds = %146, %31
  %34 = phi i32 [ %148, %146 ], [ %29, %31 ]
  %35 = phi i32 [ %147, %146 ], [ 0, %31 ]
  %36 = phi i32 [ %149, %146 ], [ 0, %31 ]
  br label %37

37:                                               ; preds = %33, %151
  %38 = phi i32 [ %155, %151 ], [ %34, %33 ]
  %39 = phi i32 [ %156, %151 ], [ %36, %33 ]
  %40 = getelementptr inbounds nuw i32, ptr %22, i32 %39
  %41 = load i32, ptr %40, align 4, !tbaa !5
  %42 = getelementptr inbounds nuw i32, ptr %23, i32 %39
  %43 = load i32, ptr %42, align 4, !tbaa !5
  %44 = getelementptr inbounds nuw i32, ptr %24, i32 %39
  %45 = load i32, ptr %44, align 4, !tbaa !5
  %46 = icmp ugt i32 %41, %1
  %47 = sub nuw i32 %1, %41
  %48 = icmp ugt i32 %43, %47
  %49 = select i1 %46, i1 true, i1 %48
  %50 = sub i32 %9, %38
  %51 = icmp ugt i32 %45, %50
  %52 = select i1 %49, i1 true, i1 %51
  br i1 %52, label %163, label %53

53:                                               ; preds = %37
  %54 = getelementptr inbounds nuw i8, ptr %27, i32 %38
  %55 = getelementptr inbounds nuw i32, ptr %25, i32 %39
  %56 = load i32, ptr %55, align 4, !tbaa !5
  switch i32 %56, label %163 [
    i32 0, label %57
    i32 8, label %61
  ]

57:                                               ; preds = %53
  %58 = icmp eq i32 %43, %45
  br i1 %58, label %59, label %163

59:                                               ; preds = %57
  %60 = getelementptr inbounds nuw i8, ptr %21, i32 %41
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %54, ptr align 1 %60, i32 %43, i1 false)
  br label %65

61:                                               ; preds = %53
  %62 = getelementptr inbounds nuw i8, ptr %21, i32 %41
  %63 = tail call i32 @term_bank_inflate(ptr noundef %62, i32 noundef %43, ptr noundef %54, i32 noundef %45) #28
  %64 = icmp eq i32 %63, 0
  br i1 %64, label %65, label %163

65:                                               ; preds = %61, %59
  br i1 %32, label %66, label %71

66:                                               ; preds = %65
  %67 = tail call fastcc i32 @crc32_bytes(ptr noundef %54, i32 noundef %45)
  %68 = getelementptr inbounds nuw i32, ptr %26, i32 %39
  %69 = load i32, ptr %68, align 4, !tbaa !5
  %70 = icmp eq i32 %67, %69
  br i1 %70, label %71, label %163

71:                                               ; preds = %66, %65
  %72 = icmp eq i32 %45, 0
  br i1 %72, label %90, label %73

73:                                               ; preds = %71, %77
  %74 = phi i32 [ %78, %77 ], [ 0, %71 ]
  %75 = getelementptr inbounds nuw i8, ptr %54, i32 %74
  %76 = load i8, ptr %75, align 1, !tbaa !2
  switch i8 %76, label %80 [
    i8 32, label %77
    i8 10, label %77
    i8 9, label %77
    i8 13, label %77
  ]

77:                                               ; preds = %73, %73, %73, %73
  %78 = add nuw i32 %74, 1
  %79 = icmp eq i32 %78, %45
  br i1 %79, label %90, label %73, !llvm.loop !7

80:                                               ; preds = %73
  %81 = getelementptr i8, ptr %54, i32 -1
  %82 = icmp ugt i32 %45, %74
  br i1 %82, label %83, label %90

83:                                               ; preds = %80, %87
  %84 = phi i32 [ %88, %87 ], [ %45, %80 ]
  %85 = getelementptr i8, ptr %81, i32 %84
  %86 = load i8, ptr %85, align 1, !tbaa !2
  switch i8 %86, label %90 [
    i8 32, label %87
    i8 10, label %87
    i8 9, label %87
    i8 13, label %87
  ]

87:                                               ; preds = %83, %83, %83, %83
  %88 = add i32 %84, -1
  %89 = icmp ugt i32 %88, %74
  br i1 %89, label %83, label %90, !llvm.loop !9

90:                                               ; preds = %77, %87, %83, %71, %80
  %91 = phi i32 [ %74, %80 ], [ %45, %71 ], [ %74, %83 ], [ %74, %87 ], [ %45, %77 ]
  %92 = phi i32 [ %45, %80 ], [ %45, %71 ], [ %74, %87 ], [ %84, %83 ], [ %45, %77 ]
  %93 = sub i32 %92, %91
  %94 = icmp ult i32 %93, 2
  br i1 %94, label %163, label %95

95:                                               ; preds = %90
  %96 = getelementptr inbounds nuw i8, ptr %54, i32 %91
  %97 = load i8, ptr %96, align 1, !tbaa !2
  %98 = icmp eq i8 %97, 91
  br i1 %98, label %99, label %163

99:                                               ; preds = %95
  %100 = getelementptr i8, ptr %54, i32 %92
  %101 = getelementptr i8, ptr %100, i32 -1
  %102 = load i8, ptr %101, align 1, !tbaa !2
  %103 = icmp eq i8 %102, 93
  br i1 %103, label %104, label %163

104:                                              ; preds = %99
  br i1 %18, label %105, label %151

105:                                              ; preds = %104
  %106 = add i32 %92, -1
  %107 = add i32 %91, 1
  %108 = icmp ult i32 %107, %106
  br i1 %108, label %112, label %117

109:                                              ; preds = %112, %112, %112, %112
  %110 = add nuw i32 %113, 1
  %111 = icmp eq i32 %110, %106
  br i1 %111, label %146, label %112

112:                                              ; preds = %105, %109
  %113 = phi i32 [ %110, %109 ], [ %107, %105 ]
  %114 = getelementptr inbounds nuw i8, ptr %54, i32 %113
  %115 = load i8, ptr %114, align 1, !tbaa !2
  switch i8 %115, label %116 [
    i8 32, label %109
    i8 10, label %109
    i8 9, label %109
    i8 13, label %109
  ], !llvm.loop !10

116:                                              ; preds = %112
  br label %117, !llvm.loop !10

117:                                              ; preds = %116, %105
  %118 = phi i32 [ %113, %116 ], [ %107, %105 ]
  %119 = icmp ugt i32 %106, %118
  br i1 %119, label %120, label %129

120:                                              ; preds = %117
  %121 = getelementptr i8, ptr %54, i32 -1
  br label %122

122:                                              ; preds = %120, %126
  %123 = phi i32 [ %127, %126 ], [ %106, %120 ]
  %124 = getelementptr i8, ptr %121, i32 %123
  %125 = load i8, ptr %124, align 1, !tbaa !2
  switch i8 %125, label %129 [
    i8 32, label %126
    i8 10, label %126
    i8 9, label %126
    i8 13, label %126
  ]

126:                                              ; preds = %122, %122, %122, %122
  %127 = add i32 %123, -1
  %128 = icmp ugt i32 %127, %118
  br i1 %128, label %122, label %146, !llvm.loop !11

129:                                              ; preds = %122, %117
  %130 = phi i32 [ %106, %117 ], [ %123, %122 ]
  %131 = sub i32 %130, %118
  %132 = icmp eq i32 %130, %118
  br i1 %132, label %146, label %133

133:                                              ; preds = %129
  %134 = icmp eq i32 %35, 0
  br i1 %134, label %137, label %135

135:                                              ; preds = %133
  %136 = add i32 %38, 1
  store i8 44, ptr %54, align 1, !tbaa !2
  br label %137

137:                                              ; preds = %135, %133
  %138 = phi i32 [ %136, %135 ], [ %38, %133 ]
  %139 = getelementptr inbounds nuw i8, ptr %27, i32 %138
  %140 = getelementptr inbounds nuw i8, ptr %54, i32 %118
  %141 = icmp eq ptr %139, %140
  br i1 %141, label %143, label %142

142:                                              ; preds = %137
  tail call void @llvm.memmove.p0.p0.i32(ptr align 1 %139, ptr align 1 %140, i32 %131, i1 false)
  br label %143

143:                                              ; preds = %142, %137
  %144 = add i32 %138, %131
  %145 = add i32 %35, 1
  br label %146

146:                                              ; preds = %109, %126, %129, %143
  %147 = phi i32 [ %145, %143 ], [ %35, %129 ], [ %35, %126 ], [ %35, %109 ]
  %148 = phi i32 [ %144, %143 ], [ %38, %129 ], [ %38, %126 ], [ %38, %109 ]
  %149 = add nuw i32 %39, 1
  %150 = icmp eq i32 %149, %7
  br i1 %150, label %158, label %33, !llvm.loop !12

151:                                              ; preds = %104
  %152 = shl i32 %39, 3
  %153 = getelementptr inbounds nuw i8, ptr %28, i32 %152
  store i32 %38, ptr %153, align 4, !tbaa !5
  %154 = getelementptr inbounds nuw i8, ptr %153, i32 4
  store i32 %45, ptr %154, align 4, !tbaa !5
  %155 = add i32 %45, %38
  %156 = add nuw i32 %39, 1
  %157 = icmp eq i32 %156, %7
  br i1 %157, label %163, label %37, !llvm.loop !12

158:                                              ; preds = %146
  %159 = icmp ult i32 %148, %9
  br i1 %159, label %160, label %163

160:                                              ; preds = %158
  %161 = add nuw i32 %148, 1
  %162 = getelementptr inbounds nuw i8, ptr %27, i32 %148
  store i8 93, ptr %162, align 1, !tbaa !2
  br label %163

163:                                              ; preds = %151, %90, %95, %99, %66, %53, %57, %61, %37, %160, %158, %12, %16
  %164 = phi i32 [ -1, %16 ], [ -1, %12 ], [ %161, %160 ], [ -1, %158 ], [ %155, %151 ], [ -5, %90 ], [ -5, %95 ], [ -5, %99 ], [ -4, %66 ], [ -1, %53 ], [ -3, %57 ], [ %63, %61 ], [ -1, %37 ]
  ret i32 %164
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr captures(none)) #5

declare i32 @term_bank_inflate(ptr noundef, i32 noundef, ptr noundef, i32 noundef) local_unnamed_addr #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr captures(none)) #5

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, argmem: read, inaccessiblemem: none)
define internal fastcc i32 @crc32_bytes(ptr noundef readonly captures(none) %0, i32 noundef %1) unnamed_addr #7 {
  %3 = load i1, ptr @crc32_table_initialized, align 4
  br i1 %3, label %362, label %4

4:                                                ; preds = %2, %4
  %5 = phi i32 [ %43, %4 ], [ 0, %2 ]
  %6 = phi <4 x i32> [ %44, %4 ], [ <i32 0, i32 1, i32 2, i32 3>, %2 ]
  %7 = lshr <4 x i32> %6, splat (i32 1)
  %8 = and <4 x i32> %6, splat (i32 1)
  %9 = icmp eq <4 x i32> %8, zeroinitializer
  %10 = select <4 x i1> %9, <4 x i32> zeroinitializer, <4 x i32> splat (i32 -306674912)
  %11 = xor <4 x i32> %10, %7
  %12 = lshr <4 x i32> %11, splat (i32 1)
  %13 = and <4 x i32> %6, splat (i32 2)
  %14 = icmp eq <4 x i32> %13, zeroinitializer
  %15 = select <4 x i1> %14, <4 x i32> zeroinitializer, <4 x i32> splat (i32 -306674912)
  %16 = xor <4 x i32> %15, %12
  %17 = lshr <4 x i32> %16, splat (i32 6)
  %18 = and <4 x i32> %6, splat (i32 4)
  %19 = icmp eq <4 x i32> %18, zeroinitializer
  %20 = select <4 x i1> %19, <4 x i32> zeroinitializer, <4 x i32> splat (i32 124634137)
  %21 = xor <4 x i32> %20, %17
  %22 = and <4 x i32> %6, splat (i32 8)
  %23 = icmp eq <4 x i32> %22, zeroinitializer
  %24 = select <4 x i1> %23, <4 x i32> zeroinitializer, <4 x i32> splat (i32 249268274)
  %25 = xor <4 x i32> %24, %21
  %26 = and <4 x i32> %6, splat (i32 16)
  %27 = icmp eq <4 x i32> %26, zeroinitializer
  %28 = select <4 x i1> %27, <4 x i32> zeroinitializer, <4 x i32> splat (i32 498536548)
  %29 = xor <4 x i32> %28, %25
  %30 = and <4 x i32> %6, splat (i32 32)
  %31 = icmp eq <4 x i32> %30, zeroinitializer
  %32 = select <4 x i1> %31, <4 x i32> zeroinitializer, <4 x i32> splat (i32 997073096)
  %33 = xor <4 x i32> %32, %29
  %34 = and <4 x i32> %11, splat (i32 32)
  %35 = icmp eq <4 x i32> %34, zeroinitializer
  %36 = select <4 x i1> %35, <4 x i32> zeroinitializer, <4 x i32> splat (i32 1994146192)
  %37 = xor <4 x i32> %36, %33
  %38 = and <4 x i32> %16, splat (i32 32)
  %39 = icmp eq <4 x i32> %38, zeroinitializer
  %40 = select <4 x i1> %39, <4 x i32> zeroinitializer, <4 x i32> splat (i32 -306674912)
  %41 = xor <4 x i32> %40, %37
  %42 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %5
  store <4 x i32> %41, ptr %42, align 16, !tbaa !5
  %43 = add nuw i32 %5, 4
  %44 = add <4 x i32> %6, splat (i32 4)
  %45 = icmp eq i32 %43, 256
  br i1 %45, label %341, label %4, !llvm.loop !13

46:                                               ; preds = %341, %46
  %47 = phi i32 [ %65, %46 ], [ 0, %341 ]
  %48 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 1, i32 %47
  %49 = load i32, ptr %48, align 8, !tbaa !5
  %50 = lshr i32 %49, 8
  %51 = and i32 %49, 255
  %52 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %51
  %53 = load i32, ptr %52, align 4, !tbaa !5
  %54 = xor i32 %50, %53
  %55 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 2, i32 %47
  store i32 %54, ptr %55, align 8, !tbaa !5
  %56 = or disjoint i32 %47, 1
  %57 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 1, i32 %56
  %58 = load i32, ptr %57, align 4, !tbaa !5
  %59 = lshr i32 %58, 8
  %60 = and i32 %58, 255
  %61 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %60
  %62 = load i32, ptr %61, align 4, !tbaa !5
  %63 = xor i32 %59, %62
  %64 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 2, i32 %56
  store i32 %63, ptr %64, align 4, !tbaa !5
  %65 = add nuw nsw i32 %47, 2
  %66 = icmp eq i32 %65, 256
  br i1 %66, label %67, label %46, !llvm.loop !16

67:                                               ; preds = %46, %67
  %68 = phi i32 [ %86, %67 ], [ 0, %46 ]
  %69 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 2, i32 %68
  %70 = load i32, ptr %69, align 8, !tbaa !5
  %71 = lshr i32 %70, 8
  %72 = and i32 %70, 255
  %73 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %72
  %74 = load i32, ptr %73, align 4, !tbaa !5
  %75 = xor i32 %71, %74
  %76 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 3, i32 %68
  store i32 %75, ptr %76, align 8, !tbaa !5
  %77 = or disjoint i32 %68, 1
  %78 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 2, i32 %77
  %79 = load i32, ptr %78, align 4, !tbaa !5
  %80 = lshr i32 %79, 8
  %81 = and i32 %79, 255
  %82 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %81
  %83 = load i32, ptr %82, align 4, !tbaa !5
  %84 = xor i32 %80, %83
  %85 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 3, i32 %77
  store i32 %84, ptr %85, align 4, !tbaa !5
  %86 = add nuw nsw i32 %68, 2
  %87 = icmp eq i32 %86, 256
  br i1 %87, label %88, label %67, !llvm.loop !16

88:                                               ; preds = %67, %88
  %89 = phi i32 [ %107, %88 ], [ 0, %67 ]
  %90 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 3, i32 %89
  %91 = load i32, ptr %90, align 8, !tbaa !5
  %92 = lshr i32 %91, 8
  %93 = and i32 %91, 255
  %94 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %93
  %95 = load i32, ptr %94, align 4, !tbaa !5
  %96 = xor i32 %92, %95
  %97 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 4, i32 %89
  store i32 %96, ptr %97, align 8, !tbaa !5
  %98 = or disjoint i32 %89, 1
  %99 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 3, i32 %98
  %100 = load i32, ptr %99, align 4, !tbaa !5
  %101 = lshr i32 %100, 8
  %102 = and i32 %100, 255
  %103 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %102
  %104 = load i32, ptr %103, align 4, !tbaa !5
  %105 = xor i32 %101, %104
  %106 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 4, i32 %98
  store i32 %105, ptr %106, align 4, !tbaa !5
  %107 = add nuw nsw i32 %89, 2
  %108 = icmp eq i32 %107, 256
  br i1 %108, label %109, label %88, !llvm.loop !16

109:                                              ; preds = %88, %109
  %110 = phi i32 [ %128, %109 ], [ 0, %88 ]
  %111 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 4, i32 %110
  %112 = load i32, ptr %111, align 8, !tbaa !5
  %113 = lshr i32 %112, 8
  %114 = and i32 %112, 255
  %115 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %114
  %116 = load i32, ptr %115, align 4, !tbaa !5
  %117 = xor i32 %113, %116
  %118 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 5, i32 %110
  store i32 %117, ptr %118, align 8, !tbaa !5
  %119 = or disjoint i32 %110, 1
  %120 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 4, i32 %119
  %121 = load i32, ptr %120, align 4, !tbaa !5
  %122 = lshr i32 %121, 8
  %123 = and i32 %121, 255
  %124 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %123
  %125 = load i32, ptr %124, align 4, !tbaa !5
  %126 = xor i32 %122, %125
  %127 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 5, i32 %119
  store i32 %126, ptr %127, align 4, !tbaa !5
  %128 = add nuw nsw i32 %110, 2
  %129 = icmp eq i32 %128, 256
  br i1 %129, label %130, label %109, !llvm.loop !16

130:                                              ; preds = %109, %130
  %131 = phi i32 [ %149, %130 ], [ 0, %109 ]
  %132 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 5, i32 %131
  %133 = load i32, ptr %132, align 8, !tbaa !5
  %134 = lshr i32 %133, 8
  %135 = and i32 %133, 255
  %136 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %135
  %137 = load i32, ptr %136, align 4, !tbaa !5
  %138 = xor i32 %134, %137
  %139 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 6, i32 %131
  store i32 %138, ptr %139, align 8, !tbaa !5
  %140 = or disjoint i32 %131, 1
  %141 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 5, i32 %140
  %142 = load i32, ptr %141, align 4, !tbaa !5
  %143 = lshr i32 %142, 8
  %144 = and i32 %142, 255
  %145 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %144
  %146 = load i32, ptr %145, align 4, !tbaa !5
  %147 = xor i32 %143, %146
  %148 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 6, i32 %140
  store i32 %147, ptr %148, align 4, !tbaa !5
  %149 = add nuw nsw i32 %131, 2
  %150 = icmp eq i32 %149, 256
  br i1 %150, label %151, label %130, !llvm.loop !16

151:                                              ; preds = %130, %151
  %152 = phi i32 [ %170, %151 ], [ 0, %130 ]
  %153 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 6, i32 %152
  %154 = load i32, ptr %153, align 8, !tbaa !5
  %155 = lshr i32 %154, 8
  %156 = and i32 %154, 255
  %157 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %156
  %158 = load i32, ptr %157, align 4, !tbaa !5
  %159 = xor i32 %155, %158
  %160 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 7, i32 %152
  store i32 %159, ptr %160, align 8, !tbaa !5
  %161 = or disjoint i32 %152, 1
  %162 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 6, i32 %161
  %163 = load i32, ptr %162, align 4, !tbaa !5
  %164 = lshr i32 %163, 8
  %165 = and i32 %163, 255
  %166 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %165
  %167 = load i32, ptr %166, align 4, !tbaa !5
  %168 = xor i32 %164, %167
  %169 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 7, i32 %161
  store i32 %168, ptr %169, align 4, !tbaa !5
  %170 = add nuw nsw i32 %152, 2
  %171 = icmp eq i32 %170, 256
  br i1 %171, label %172, label %151, !llvm.loop !16

172:                                              ; preds = %151, %172
  %173 = phi i32 [ %191, %172 ], [ 0, %151 ]
  %174 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 7, i32 %173
  %175 = load i32, ptr %174, align 8, !tbaa !5
  %176 = lshr i32 %175, 8
  %177 = and i32 %175, 255
  %178 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %177
  %179 = load i32, ptr %178, align 4, !tbaa !5
  %180 = xor i32 %176, %179
  %181 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 8, i32 %173
  store i32 %180, ptr %181, align 8, !tbaa !5
  %182 = or disjoint i32 %173, 1
  %183 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 7, i32 %182
  %184 = load i32, ptr %183, align 4, !tbaa !5
  %185 = lshr i32 %184, 8
  %186 = and i32 %184, 255
  %187 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %186
  %188 = load i32, ptr %187, align 4, !tbaa !5
  %189 = xor i32 %185, %188
  %190 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 8, i32 %182
  store i32 %189, ptr %190, align 4, !tbaa !5
  %191 = add nuw nsw i32 %173, 2
  %192 = icmp eq i32 %191, 256
  br i1 %192, label %193, label %172, !llvm.loop !16

193:                                              ; preds = %172, %193
  %194 = phi i32 [ %212, %193 ], [ 0, %172 ]
  %195 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 8, i32 %194
  %196 = load i32, ptr %195, align 8, !tbaa !5
  %197 = lshr i32 %196, 8
  %198 = and i32 %196, 255
  %199 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %198
  %200 = load i32, ptr %199, align 4, !tbaa !5
  %201 = xor i32 %197, %200
  %202 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 9, i32 %194
  store i32 %201, ptr %202, align 8, !tbaa !5
  %203 = or disjoint i32 %194, 1
  %204 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 8, i32 %203
  %205 = load i32, ptr %204, align 4, !tbaa !5
  %206 = lshr i32 %205, 8
  %207 = and i32 %205, 255
  %208 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %207
  %209 = load i32, ptr %208, align 4, !tbaa !5
  %210 = xor i32 %206, %209
  %211 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 9, i32 %203
  store i32 %210, ptr %211, align 4, !tbaa !5
  %212 = add nuw nsw i32 %194, 2
  %213 = icmp eq i32 %212, 256
  br i1 %213, label %214, label %193, !llvm.loop !16

214:                                              ; preds = %193, %214
  %215 = phi i32 [ %233, %214 ], [ 0, %193 ]
  %216 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 9, i32 %215
  %217 = load i32, ptr %216, align 8, !tbaa !5
  %218 = lshr i32 %217, 8
  %219 = and i32 %217, 255
  %220 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %219
  %221 = load i32, ptr %220, align 4, !tbaa !5
  %222 = xor i32 %218, %221
  %223 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 10, i32 %215
  store i32 %222, ptr %223, align 8, !tbaa !5
  %224 = or disjoint i32 %215, 1
  %225 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 9, i32 %224
  %226 = load i32, ptr %225, align 4, !tbaa !5
  %227 = lshr i32 %226, 8
  %228 = and i32 %226, 255
  %229 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %228
  %230 = load i32, ptr %229, align 4, !tbaa !5
  %231 = xor i32 %227, %230
  %232 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 10, i32 %224
  store i32 %231, ptr %232, align 4, !tbaa !5
  %233 = add nuw nsw i32 %215, 2
  %234 = icmp eq i32 %233, 256
  br i1 %234, label %235, label %214, !llvm.loop !16

235:                                              ; preds = %214, %235
  %236 = phi i32 [ %254, %235 ], [ 0, %214 ]
  %237 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 10, i32 %236
  %238 = load i32, ptr %237, align 8, !tbaa !5
  %239 = lshr i32 %238, 8
  %240 = and i32 %238, 255
  %241 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %240
  %242 = load i32, ptr %241, align 4, !tbaa !5
  %243 = xor i32 %239, %242
  %244 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 11, i32 %236
  store i32 %243, ptr %244, align 8, !tbaa !5
  %245 = or disjoint i32 %236, 1
  %246 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 10, i32 %245
  %247 = load i32, ptr %246, align 4, !tbaa !5
  %248 = lshr i32 %247, 8
  %249 = and i32 %247, 255
  %250 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %249
  %251 = load i32, ptr %250, align 4, !tbaa !5
  %252 = xor i32 %248, %251
  %253 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 11, i32 %245
  store i32 %252, ptr %253, align 4, !tbaa !5
  %254 = add nuw nsw i32 %236, 2
  %255 = icmp eq i32 %254, 256
  br i1 %255, label %256, label %235, !llvm.loop !16

256:                                              ; preds = %235, %256
  %257 = phi i32 [ %275, %256 ], [ 0, %235 ]
  %258 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 11, i32 %257
  %259 = load i32, ptr %258, align 8, !tbaa !5
  %260 = lshr i32 %259, 8
  %261 = and i32 %259, 255
  %262 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %261
  %263 = load i32, ptr %262, align 4, !tbaa !5
  %264 = xor i32 %260, %263
  %265 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 12, i32 %257
  store i32 %264, ptr %265, align 8, !tbaa !5
  %266 = or disjoint i32 %257, 1
  %267 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 11, i32 %266
  %268 = load i32, ptr %267, align 4, !tbaa !5
  %269 = lshr i32 %268, 8
  %270 = and i32 %268, 255
  %271 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %270
  %272 = load i32, ptr %271, align 4, !tbaa !5
  %273 = xor i32 %269, %272
  %274 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 12, i32 %266
  store i32 %273, ptr %274, align 4, !tbaa !5
  %275 = add nuw nsw i32 %257, 2
  %276 = icmp eq i32 %275, 256
  br i1 %276, label %277, label %256, !llvm.loop !16

277:                                              ; preds = %256, %277
  %278 = phi i32 [ %296, %277 ], [ 0, %256 ]
  %279 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 12, i32 %278
  %280 = load i32, ptr %279, align 8, !tbaa !5
  %281 = lshr i32 %280, 8
  %282 = and i32 %280, 255
  %283 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %282
  %284 = load i32, ptr %283, align 4, !tbaa !5
  %285 = xor i32 %281, %284
  %286 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 13, i32 %278
  store i32 %285, ptr %286, align 8, !tbaa !5
  %287 = or disjoint i32 %278, 1
  %288 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 12, i32 %287
  %289 = load i32, ptr %288, align 4, !tbaa !5
  %290 = lshr i32 %289, 8
  %291 = and i32 %289, 255
  %292 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %291
  %293 = load i32, ptr %292, align 4, !tbaa !5
  %294 = xor i32 %290, %293
  %295 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 13, i32 %287
  store i32 %294, ptr %295, align 4, !tbaa !5
  %296 = add nuw nsw i32 %278, 2
  %297 = icmp eq i32 %296, 256
  br i1 %297, label %298, label %277, !llvm.loop !16

298:                                              ; preds = %277, %298
  %299 = phi i32 [ %317, %298 ], [ 0, %277 ]
  %300 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 13, i32 %299
  %301 = load i32, ptr %300, align 8, !tbaa !5
  %302 = lshr i32 %301, 8
  %303 = and i32 %301, 255
  %304 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %303
  %305 = load i32, ptr %304, align 4, !tbaa !5
  %306 = xor i32 %302, %305
  %307 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 14, i32 %299
  store i32 %306, ptr %307, align 8, !tbaa !5
  %308 = or disjoint i32 %299, 1
  %309 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 13, i32 %308
  %310 = load i32, ptr %309, align 4, !tbaa !5
  %311 = lshr i32 %310, 8
  %312 = and i32 %310, 255
  %313 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %312
  %314 = load i32, ptr %313, align 4, !tbaa !5
  %315 = xor i32 %311, %314
  %316 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 14, i32 %308
  store i32 %315, ptr %316, align 4, !tbaa !5
  %317 = add nuw nsw i32 %299, 2
  %318 = icmp eq i32 %317, 256
  br i1 %318, label %319, label %298, !llvm.loop !16

319:                                              ; preds = %298, %319
  %320 = phi i32 [ %338, %319 ], [ 0, %298 ]
  %321 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 14, i32 %320
  %322 = load i32, ptr %321, align 8, !tbaa !5
  %323 = lshr i32 %322, 8
  %324 = and i32 %322, 255
  %325 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %324
  %326 = load i32, ptr %325, align 4, !tbaa !5
  %327 = xor i32 %323, %326
  %328 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 15, i32 %320
  store i32 %327, ptr %328, align 8, !tbaa !5
  %329 = or disjoint i32 %320, 1
  %330 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 14, i32 %329
  %331 = load i32, ptr %330, align 4, !tbaa !5
  %332 = lshr i32 %331, 8
  %333 = and i32 %331, 255
  %334 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %333
  %335 = load i32, ptr %334, align 4, !tbaa !5
  %336 = xor i32 %332, %335
  %337 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 15, i32 %329
  store i32 %336, ptr %337, align 4, !tbaa !5
  %338 = add nuw nsw i32 %320, 2
  %339 = icmp eq i32 %338, 256
  br i1 %339, label %340, label %319, !llvm.loop !16

340:                                              ; preds = %319
  store i1 true, ptr @crc32_table_initialized, align 4
  br label %362

341:                                              ; preds = %4, %341
  %342 = phi i32 [ %360, %341 ], [ 0, %4 ]
  %343 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 0, i32 %342
  %344 = load i32, ptr %343, align 8, !tbaa !5
  %345 = lshr i32 %344, 8
  %346 = and i32 %344, 255
  %347 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %346
  %348 = load i32, ptr %347, align 4, !tbaa !5
  %349 = xor i32 %345, %348
  %350 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 1, i32 %342
  store i32 %349, ptr %350, align 8, !tbaa !5
  %351 = or disjoint i32 %342, 1
  %352 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 0, i32 %351
  %353 = load i32, ptr %352, align 4, !tbaa !5
  %354 = lshr i32 %353, 8
  %355 = and i32 %353, 255
  %356 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %355
  %357 = load i32, ptr %356, align 4, !tbaa !5
  %358 = xor i32 %354, %357
  %359 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 1, i32 %351
  store i32 %358, ptr %359, align 4, !tbaa !5
  %360 = add nuw nsw i32 %342, 2
  %361 = icmp eq i32 %360, 256
  br i1 %361, label %46, label %341, !llvm.loop !16

362:                                              ; preds = %340, %2
  %363 = icmp ult i32 %1, 262144
  br i1 %363, label %364, label %503

364:                                              ; preds = %362
  %365 = icmp samesign ugt i32 %1, 15
  br i1 %365, label %394, label %368

366:                                              ; preds = %394
  %367 = and i32 %1, 262128
  br label %368

368:                                              ; preds = %366, %364
  %369 = phi i32 [ -1, %364 ], [ %476, %366 ]
  %370 = phi i32 [ 0, %364 ], [ %367, %366 ]
  %371 = icmp samesign ult i32 %370, %1
  br i1 %371, label %372, label %1512

372:                                              ; preds = %368
  %373 = or disjoint i32 %370, 1
  %374 = and i32 %1, 1
  %375 = icmp eq i32 %374, 0
  br i1 %375, label %387, label %376

376:                                              ; preds = %372
  %377 = lshr i32 %369, 8
  %378 = or disjoint i32 %370, 1
  %379 = getelementptr inbounds nuw i8, ptr %0, i32 %370
  %380 = load i8, ptr %379, align 1, !tbaa !2
  %381 = trunc i32 %369 to i8
  %382 = xor i8 %380, %381
  %383 = zext i8 %382 to i32
  %384 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %383
  %385 = load i32, ptr %384, align 4, !tbaa !5
  %386 = xor i32 %385, %377
  br label %387

387:                                              ; preds = %376, %372
  %388 = phi i32 [ poison, %372 ], [ %386, %376 ]
  %389 = phi i32 [ %370, %372 ], [ %378, %376 ]
  %390 = phi i32 [ %369, %372 ], [ %386, %376 ]
  %391 = icmp eq i32 %1, %373
  br i1 %391, label %1512, label %392

392:                                              ; preds = %387
  %393 = getelementptr i8, ptr %0, i32 1
  br label %480

394:                                              ; preds = %364, %394
  %395 = phi i32 [ %477, %394 ], [ 0, %364 ]
  %396 = phi i32 [ %476, %394 ], [ -1, %364 ]
  %397 = getelementptr inbounds nuw i8, ptr %0, i32 %395
  %398 = load i32, ptr %397, align 1
  %399 = getelementptr inbounds nuw i8, ptr %397, i32 4
  %400 = load i32, ptr %399, align 1
  %401 = getelementptr inbounds nuw i8, ptr %397, i32 8
  %402 = load i32, ptr %401, align 1
  %403 = getelementptr inbounds nuw i8, ptr %397, i32 12
  %404 = load i32, ptr %403, align 1
  %405 = xor i32 %398, %396
  %406 = and i32 %405, 255
  %407 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 15360), i32 0, i32 %406
  %408 = load i32, ptr %407, align 4, !tbaa !5
  %409 = lshr i32 %405, 8
  %410 = and i32 %409, 255
  %411 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 14336), i32 0, i32 %410
  %412 = load i32, ptr %411, align 4, !tbaa !5
  %413 = xor i32 %412, %408
  %414 = lshr i32 %405, 16
  %415 = and i32 %414, 255
  %416 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 13312), i32 0, i32 %415
  %417 = load i32, ptr %416, align 4, !tbaa !5
  %418 = xor i32 %413, %417
  %419 = lshr i32 %405, 24
  %420 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 12288), i32 0, i32 %419
  %421 = load i32, ptr %420, align 4, !tbaa !5
  %422 = xor i32 %418, %421
  %423 = and i32 %400, 255
  %424 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 11264), i32 0, i32 %423
  %425 = load i32, ptr %424, align 4, !tbaa !5
  %426 = xor i32 %422, %425
  %427 = lshr i32 %400, 8
  %428 = and i32 %427, 255
  %429 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 10240), i32 0, i32 %428
  %430 = load i32, ptr %429, align 4, !tbaa !5
  %431 = xor i32 %426, %430
  %432 = lshr i32 %400, 16
  %433 = and i32 %432, 255
  %434 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 9216), i32 0, i32 %433
  %435 = load i32, ptr %434, align 4, !tbaa !5
  %436 = xor i32 %431, %435
  %437 = lshr i32 %400, 24
  %438 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 8192), i32 0, i32 %437
  %439 = load i32, ptr %438, align 4, !tbaa !5
  %440 = xor i32 %436, %439
  %441 = and i32 %402, 255
  %442 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 7168), i32 0, i32 %441
  %443 = load i32, ptr %442, align 4, !tbaa !5
  %444 = xor i32 %440, %443
  %445 = lshr i32 %402, 8
  %446 = and i32 %445, 255
  %447 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 6144), i32 0, i32 %446
  %448 = load i32, ptr %447, align 4, !tbaa !5
  %449 = xor i32 %444, %448
  %450 = lshr i32 %402, 16
  %451 = and i32 %450, 255
  %452 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 5120), i32 0, i32 %451
  %453 = load i32, ptr %452, align 4, !tbaa !5
  %454 = xor i32 %449, %453
  %455 = lshr i32 %402, 24
  %456 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 4096), i32 0, i32 %455
  %457 = load i32, ptr %456, align 4, !tbaa !5
  %458 = xor i32 %454, %457
  %459 = and i32 %404, 255
  %460 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 3072), i32 0, i32 %459
  %461 = load i32, ptr %460, align 4, !tbaa !5
  %462 = xor i32 %458, %461
  %463 = lshr i32 %404, 8
  %464 = and i32 %463, 255
  %465 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 2048), i32 0, i32 %464
  %466 = load i32, ptr %465, align 4, !tbaa !5
  %467 = xor i32 %462, %466
  %468 = lshr i32 %404, 16
  %469 = and i32 %468, 255
  %470 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 1024), i32 0, i32 %469
  %471 = load i32, ptr %470, align 4, !tbaa !5
  %472 = xor i32 %467, %471
  %473 = lshr i32 %404, 24
  %474 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %473
  %475 = load i32, ptr %474, align 4, !tbaa !5
  %476 = xor i32 %472, %475
  %477 = add i32 %395, 16
  %478 = sub i32 %1, %477
  %479 = icmp ugt i32 %478, 15
  br i1 %479, label %394, label %366, !llvm.loop !17

480:                                              ; preds = %480, %392
  %481 = phi i32 [ %389, %392 ], [ %493, %480 ]
  %482 = phi i32 [ %390, %392 ], [ %501, %480 ]
  %483 = lshr i32 %482, 8
  %484 = getelementptr inbounds nuw i8, ptr %0, i32 %481
  %485 = load i8, ptr %484, align 1, !tbaa !2
  %486 = trunc i32 %482 to i8
  %487 = xor i8 %485, %486
  %488 = zext i8 %487 to i32
  %489 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %488
  %490 = load i32, ptr %489, align 4, !tbaa !5
  %491 = xor i32 %490, %483
  %492 = lshr i32 %491, 8
  %493 = add nuw nsw i32 %481, 2
  %494 = getelementptr i8, ptr %393, i32 %481
  %495 = load i8, ptr %494, align 1, !tbaa !2
  %496 = trunc i32 %491 to i8
  %497 = xor i8 %495, %496
  %498 = zext i8 %497 to i32
  %499 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %498
  %500 = load i32, ptr %499, align 4, !tbaa !5
  %501 = xor i32 %500, %492
  %502 = icmp eq i32 %493, %1
  br i1 %502, label %1512, label %480, !llvm.loop !18

503:                                              ; preds = %362
  %504 = load i1, ptr @crc32_braid_initialized, align 4
  br i1 %504, label %770, label %737

505:                                              ; preds = %741, %534
  %506 = phi i32 [ %536, %534 ], [ 0, %741 ]
  %507 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 1, i32 %506
  %508 = load i32, ptr %507, align 4, !tbaa !5
  br label %509

509:                                              ; preds = %509, %505
  %510 = phi i32 [ 8, %505 ], [ %532, %509 ]
  %511 = phi i32 [ %508, %505 ], [ %531, %509 ]
  %512 = lshr i32 %511, 8
  %513 = and i32 %511, 255
  %514 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %513
  %515 = load i32, ptr %514, align 4, !tbaa !5
  %516 = xor i32 %515, %512
  %517 = lshr i32 %516, 8
  %518 = and i32 %516, 255
  %519 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %518
  %520 = load i32, ptr %519, align 4, !tbaa !5
  %521 = xor i32 %520, %517
  %522 = lshr i32 %521, 8
  %523 = and i32 %521, 255
  %524 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %523
  %525 = load i32, ptr %524, align 4, !tbaa !5
  %526 = xor i32 %525, %522
  %527 = lshr i32 %526, 8
  %528 = and i32 %526, 255
  %529 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %528
  %530 = load i32, ptr %529, align 4, !tbaa !5
  %531 = xor i32 %530, %527
  %532 = add nuw nsw i32 %510, 4
  %533 = icmp eq i32 %532, 64
  br i1 %533, label %534, label %509, !llvm.loop !19

534:                                              ; preds = %509
  %535 = getelementptr inbounds nuw [8 x [256 x i32]], ptr @crc32_braid_table, i32 0, i32 1, i32 %506
  store i32 %531, ptr %535, align 4, !tbaa !5
  %536 = add nuw nsw i32 %506, 1
  %537 = icmp eq i32 %536, 256
  br i1 %537, label %538, label %505, !llvm.loop !20

538:                                              ; preds = %534, %567
  %539 = phi i32 [ %569, %567 ], [ 0, %534 ]
  %540 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 2, i32 %539
  %541 = load i32, ptr %540, align 4, !tbaa !5
  br label %542

542:                                              ; preds = %542, %538
  %543 = phi i32 [ 8, %538 ], [ %565, %542 ]
  %544 = phi i32 [ %541, %538 ], [ %564, %542 ]
  %545 = lshr i32 %544, 8
  %546 = and i32 %544, 255
  %547 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %546
  %548 = load i32, ptr %547, align 4, !tbaa !5
  %549 = xor i32 %548, %545
  %550 = lshr i32 %549, 8
  %551 = and i32 %549, 255
  %552 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %551
  %553 = load i32, ptr %552, align 4, !tbaa !5
  %554 = xor i32 %553, %550
  %555 = lshr i32 %554, 8
  %556 = and i32 %554, 255
  %557 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %556
  %558 = load i32, ptr %557, align 4, !tbaa !5
  %559 = xor i32 %558, %555
  %560 = lshr i32 %559, 8
  %561 = and i32 %559, 255
  %562 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %561
  %563 = load i32, ptr %562, align 4, !tbaa !5
  %564 = xor i32 %563, %560
  %565 = add nuw nsw i32 %543, 4
  %566 = icmp eq i32 %565, 64
  br i1 %566, label %567, label %542, !llvm.loop !19

567:                                              ; preds = %542
  %568 = getelementptr inbounds nuw [8 x [256 x i32]], ptr @crc32_braid_table, i32 0, i32 2, i32 %539
  store i32 %564, ptr %568, align 4, !tbaa !5
  %569 = add nuw nsw i32 %539, 1
  %570 = icmp eq i32 %569, 256
  br i1 %570, label %571, label %538, !llvm.loop !20

571:                                              ; preds = %567, %600
  %572 = phi i32 [ %602, %600 ], [ 0, %567 ]
  %573 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 3, i32 %572
  %574 = load i32, ptr %573, align 4, !tbaa !5
  br label %575

575:                                              ; preds = %575, %571
  %576 = phi i32 [ 8, %571 ], [ %598, %575 ]
  %577 = phi i32 [ %574, %571 ], [ %597, %575 ]
  %578 = lshr i32 %577, 8
  %579 = and i32 %577, 255
  %580 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %579
  %581 = load i32, ptr %580, align 4, !tbaa !5
  %582 = xor i32 %581, %578
  %583 = lshr i32 %582, 8
  %584 = and i32 %582, 255
  %585 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %584
  %586 = load i32, ptr %585, align 4, !tbaa !5
  %587 = xor i32 %586, %583
  %588 = lshr i32 %587, 8
  %589 = and i32 %587, 255
  %590 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %589
  %591 = load i32, ptr %590, align 4, !tbaa !5
  %592 = xor i32 %591, %588
  %593 = lshr i32 %592, 8
  %594 = and i32 %592, 255
  %595 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %594
  %596 = load i32, ptr %595, align 4, !tbaa !5
  %597 = xor i32 %596, %593
  %598 = add nuw nsw i32 %576, 4
  %599 = icmp eq i32 %598, 64
  br i1 %599, label %600, label %575, !llvm.loop !19

600:                                              ; preds = %575
  %601 = getelementptr inbounds nuw [8 x [256 x i32]], ptr @crc32_braid_table, i32 0, i32 3, i32 %572
  store i32 %597, ptr %601, align 4, !tbaa !5
  %602 = add nuw nsw i32 %572, 1
  %603 = icmp eq i32 %602, 256
  br i1 %603, label %604, label %571, !llvm.loop !20

604:                                              ; preds = %600, %633
  %605 = phi i32 [ %635, %633 ], [ 0, %600 ]
  %606 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 4, i32 %605
  %607 = load i32, ptr %606, align 4, !tbaa !5
  br label %608

608:                                              ; preds = %608, %604
  %609 = phi i32 [ 8, %604 ], [ %631, %608 ]
  %610 = phi i32 [ %607, %604 ], [ %630, %608 ]
  %611 = lshr i32 %610, 8
  %612 = and i32 %610, 255
  %613 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %612
  %614 = load i32, ptr %613, align 4, !tbaa !5
  %615 = xor i32 %614, %611
  %616 = lshr i32 %615, 8
  %617 = and i32 %615, 255
  %618 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %617
  %619 = load i32, ptr %618, align 4, !tbaa !5
  %620 = xor i32 %619, %616
  %621 = lshr i32 %620, 8
  %622 = and i32 %620, 255
  %623 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %622
  %624 = load i32, ptr %623, align 4, !tbaa !5
  %625 = xor i32 %624, %621
  %626 = lshr i32 %625, 8
  %627 = and i32 %625, 255
  %628 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %627
  %629 = load i32, ptr %628, align 4, !tbaa !5
  %630 = xor i32 %629, %626
  %631 = add nuw nsw i32 %609, 4
  %632 = icmp eq i32 %631, 64
  br i1 %632, label %633, label %608, !llvm.loop !19

633:                                              ; preds = %608
  %634 = getelementptr inbounds nuw [8 x [256 x i32]], ptr @crc32_braid_table, i32 0, i32 4, i32 %605
  store i32 %630, ptr %634, align 4, !tbaa !5
  %635 = add nuw nsw i32 %605, 1
  %636 = icmp eq i32 %635, 256
  br i1 %636, label %637, label %604, !llvm.loop !20

637:                                              ; preds = %633, %666
  %638 = phi i32 [ %668, %666 ], [ 0, %633 ]
  %639 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 5, i32 %638
  %640 = load i32, ptr %639, align 4, !tbaa !5
  br label %641

641:                                              ; preds = %641, %637
  %642 = phi i32 [ 8, %637 ], [ %664, %641 ]
  %643 = phi i32 [ %640, %637 ], [ %663, %641 ]
  %644 = lshr i32 %643, 8
  %645 = and i32 %643, 255
  %646 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %645
  %647 = load i32, ptr %646, align 4, !tbaa !5
  %648 = xor i32 %647, %644
  %649 = lshr i32 %648, 8
  %650 = and i32 %648, 255
  %651 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %650
  %652 = load i32, ptr %651, align 4, !tbaa !5
  %653 = xor i32 %652, %649
  %654 = lshr i32 %653, 8
  %655 = and i32 %653, 255
  %656 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %655
  %657 = load i32, ptr %656, align 4, !tbaa !5
  %658 = xor i32 %657, %654
  %659 = lshr i32 %658, 8
  %660 = and i32 %658, 255
  %661 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %660
  %662 = load i32, ptr %661, align 4, !tbaa !5
  %663 = xor i32 %662, %659
  %664 = add nuw nsw i32 %642, 4
  %665 = icmp eq i32 %664, 64
  br i1 %665, label %666, label %641, !llvm.loop !19

666:                                              ; preds = %641
  %667 = getelementptr inbounds nuw [8 x [256 x i32]], ptr @crc32_braid_table, i32 0, i32 5, i32 %638
  store i32 %663, ptr %667, align 4, !tbaa !5
  %668 = add nuw nsw i32 %638, 1
  %669 = icmp eq i32 %668, 256
  br i1 %669, label %670, label %637, !llvm.loop !20

670:                                              ; preds = %666, %699
  %671 = phi i32 [ %701, %699 ], [ 0, %666 ]
  %672 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 6, i32 %671
  %673 = load i32, ptr %672, align 4, !tbaa !5
  br label %674

674:                                              ; preds = %674, %670
  %675 = phi i32 [ 8, %670 ], [ %697, %674 ]
  %676 = phi i32 [ %673, %670 ], [ %696, %674 ]
  %677 = lshr i32 %676, 8
  %678 = and i32 %676, 255
  %679 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %678
  %680 = load i32, ptr %679, align 4, !tbaa !5
  %681 = xor i32 %680, %677
  %682 = lshr i32 %681, 8
  %683 = and i32 %681, 255
  %684 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %683
  %685 = load i32, ptr %684, align 4, !tbaa !5
  %686 = xor i32 %685, %682
  %687 = lshr i32 %686, 8
  %688 = and i32 %686, 255
  %689 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %688
  %690 = load i32, ptr %689, align 4, !tbaa !5
  %691 = xor i32 %690, %687
  %692 = lshr i32 %691, 8
  %693 = and i32 %691, 255
  %694 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %693
  %695 = load i32, ptr %694, align 4, !tbaa !5
  %696 = xor i32 %695, %692
  %697 = add nuw nsw i32 %675, 4
  %698 = icmp eq i32 %697, 64
  br i1 %698, label %699, label %674, !llvm.loop !19

699:                                              ; preds = %674
  %700 = getelementptr inbounds nuw [8 x [256 x i32]], ptr @crc32_braid_table, i32 0, i32 6, i32 %671
  store i32 %696, ptr %700, align 4, !tbaa !5
  %701 = add nuw nsw i32 %671, 1
  %702 = icmp eq i32 %701, 256
  br i1 %702, label %703, label %670, !llvm.loop !20

703:                                              ; preds = %699, %732
  %704 = phi i32 [ %734, %732 ], [ 0, %699 ]
  %705 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 7, i32 %704
  %706 = load i32, ptr %705, align 4, !tbaa !5
  br label %707

707:                                              ; preds = %707, %703
  %708 = phi i32 [ 8, %703 ], [ %730, %707 ]
  %709 = phi i32 [ %706, %703 ], [ %729, %707 ]
  %710 = lshr i32 %709, 8
  %711 = and i32 %709, 255
  %712 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %711
  %713 = load i32, ptr %712, align 4, !tbaa !5
  %714 = xor i32 %713, %710
  %715 = lshr i32 %714, 8
  %716 = and i32 %714, 255
  %717 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %716
  %718 = load i32, ptr %717, align 4, !tbaa !5
  %719 = xor i32 %718, %715
  %720 = lshr i32 %719, 8
  %721 = and i32 %719, 255
  %722 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %721
  %723 = load i32, ptr %722, align 4, !tbaa !5
  %724 = xor i32 %723, %720
  %725 = lshr i32 %724, 8
  %726 = and i32 %724, 255
  %727 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %726
  %728 = load i32, ptr %727, align 4, !tbaa !5
  %729 = xor i32 %728, %725
  %730 = add nuw nsw i32 %708, 4
  %731 = icmp eq i32 %730, 64
  br i1 %731, label %732, label %707, !llvm.loop !19

732:                                              ; preds = %707
  %733 = getelementptr inbounds nuw [8 x [256 x i32]], ptr @crc32_braid_table, i32 0, i32 7, i32 %704
  store i32 %729, ptr %733, align 4, !tbaa !5
  %734 = add nuw nsw i32 %704, 1
  %735 = icmp eq i32 %734, 256
  br i1 %735, label %736, label %703, !llvm.loop !20

736:                                              ; preds = %732
  store i1 true, ptr @crc32_braid_initialized, align 4
  br label %770

737:                                              ; preds = %503, %741
  %738 = phi i32 [ %743, %741 ], [ 0, %503 ]
  %739 = getelementptr inbounds nuw [16 x [256 x i32]], ptr @crc32_table, i32 0, i32 0, i32 %738
  %740 = load i32, ptr %739, align 4, !tbaa !5
  br label %745

741:                                              ; preds = %745
  %742 = getelementptr inbounds nuw [8 x [256 x i32]], ptr @crc32_braid_table, i32 0, i32 0, i32 %738
  store i32 %767, ptr %742, align 4, !tbaa !5
  %743 = add nuw nsw i32 %738, 1
  %744 = icmp eq i32 %743, 256
  br i1 %744, label %505, label %737, !llvm.loop !20

745:                                              ; preds = %745, %737
  %746 = phi i32 [ 8, %737 ], [ %768, %745 ]
  %747 = phi i32 [ %740, %737 ], [ %767, %745 ]
  %748 = lshr i32 %747, 8
  %749 = and i32 %747, 255
  %750 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %749
  %751 = load i32, ptr %750, align 4, !tbaa !5
  %752 = xor i32 %751, %748
  %753 = lshr i32 %752, 8
  %754 = and i32 %752, 255
  %755 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %754
  %756 = load i32, ptr %755, align 4, !tbaa !5
  %757 = xor i32 %756, %753
  %758 = lshr i32 %757, 8
  %759 = and i32 %757, 255
  %760 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %759
  %761 = load i32, ptr %760, align 4, !tbaa !5
  %762 = xor i32 %761, %758
  %763 = lshr i32 %762, 8
  %764 = and i32 %762, 255
  %765 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %764
  %766 = load i32, ptr %765, align 4, !tbaa !5
  %767 = xor i32 %766, %763
  %768 = add nuw nsw i32 %746, 4
  %769 = icmp eq i32 %768, 64
  br i1 %769, label %741, label %745, !llvm.loop !19

770:                                              ; preds = %736, %503
  %771 = and i32 %1, -64
  %772 = add i32 %771, -64
  br label %773

773:                                              ; preds = %773, %770
  %774 = phi i32 [ 0, %770 ], [ %1134, %773 ]
  %775 = phi i32 [ 0, %770 ], [ %1090, %773 ]
  %776 = phi i32 [ 0, %770 ], [ %1046, %773 ]
  %777 = phi i32 [ 0, %770 ], [ %1002, %773 ]
  %778 = phi i32 [ 0, %770 ], [ %958, %773 ]
  %779 = phi i32 [ 0, %770 ], [ %914, %773 ]
  %780 = phi i32 [ 0, %770 ], [ %870, %773 ]
  %781 = phi i32 [ -1, %770 ], [ %826, %773 ]
  %782 = phi i32 [ 0, %770 ], [ %1135, %773 ]
  %783 = getelementptr inbounds nuw i8, ptr %0, i32 %782
  %784 = load i64, ptr %783, align 1
  %785 = trunc i64 %784 to i32
  %786 = xor i32 %781, %785
  %787 = and i32 %786, 255
  %788 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 7168), i32 0, i32 %787
  %789 = load i32, ptr %788, align 4, !tbaa !5
  %790 = lshr i32 %786, 8
  %791 = and i32 %790, 255
  %792 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 6144), i32 0, i32 %791
  %793 = load i32, ptr %792, align 4, !tbaa !5
  %794 = xor i32 %793, %789
  %795 = lshr i32 %786, 16
  %796 = and i32 %795, 255
  %797 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 5120), i32 0, i32 %796
  %798 = load i32, ptr %797, align 4, !tbaa !5
  %799 = xor i32 %794, %798
  %800 = lshr i32 %786, 24
  %801 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 4096), i32 0, i32 %800
  %802 = load i32, ptr %801, align 4, !tbaa !5
  %803 = xor i32 %799, %802
  %804 = lshr i64 %784, 32
  %805 = trunc nuw i64 %804 to i32
  %806 = and i32 %805, 255
  %807 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 3072), i32 0, i32 %806
  %808 = load i32, ptr %807, align 4, !tbaa !5
  %809 = xor i32 %803, %808
  %810 = lshr i64 %784, 40
  %811 = trunc nuw nsw i64 %810 to i32
  %812 = and i32 %811, 255
  %813 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 2048), i32 0, i32 %812
  %814 = load i32, ptr %813, align 4, !tbaa !5
  %815 = xor i32 %809, %814
  %816 = lshr i64 %784, 48
  %817 = trunc nuw nsw i64 %816 to i32
  %818 = and i32 %817, 255
  %819 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 1024), i32 0, i32 %818
  %820 = load i32, ptr %819, align 4, !tbaa !5
  %821 = xor i32 %815, %820
  %822 = lshr i64 %784, 56
  %823 = trunc nuw nsw i64 %822 to i32
  %824 = getelementptr inbounds nuw [256 x i32], ptr @crc32_braid_table, i32 0, i32 %823
  %825 = load i32, ptr %824, align 4, !tbaa !5
  %826 = xor i32 %821, %825
  %827 = getelementptr inbounds nuw i8, ptr %783, i32 8
  %828 = load i64, ptr %827, align 1
  %829 = trunc i64 %828 to i32
  %830 = xor i32 %780, %829
  %831 = and i32 %830, 255
  %832 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 7168), i32 0, i32 %831
  %833 = load i32, ptr %832, align 4, !tbaa !5
  %834 = lshr i32 %830, 8
  %835 = and i32 %834, 255
  %836 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 6144), i32 0, i32 %835
  %837 = load i32, ptr %836, align 4, !tbaa !5
  %838 = xor i32 %837, %833
  %839 = lshr i32 %830, 16
  %840 = and i32 %839, 255
  %841 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 5120), i32 0, i32 %840
  %842 = load i32, ptr %841, align 4, !tbaa !5
  %843 = xor i32 %838, %842
  %844 = lshr i32 %830, 24
  %845 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 4096), i32 0, i32 %844
  %846 = load i32, ptr %845, align 4, !tbaa !5
  %847 = xor i32 %843, %846
  %848 = lshr i64 %828, 32
  %849 = trunc nuw i64 %848 to i32
  %850 = and i32 %849, 255
  %851 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 3072), i32 0, i32 %850
  %852 = load i32, ptr %851, align 4, !tbaa !5
  %853 = xor i32 %847, %852
  %854 = lshr i64 %828, 40
  %855 = trunc nuw nsw i64 %854 to i32
  %856 = and i32 %855, 255
  %857 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 2048), i32 0, i32 %856
  %858 = load i32, ptr %857, align 4, !tbaa !5
  %859 = xor i32 %853, %858
  %860 = lshr i64 %828, 48
  %861 = trunc nuw nsw i64 %860 to i32
  %862 = and i32 %861, 255
  %863 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 1024), i32 0, i32 %862
  %864 = load i32, ptr %863, align 4, !tbaa !5
  %865 = xor i32 %859, %864
  %866 = lshr i64 %828, 56
  %867 = trunc nuw nsw i64 %866 to i32
  %868 = getelementptr inbounds nuw [256 x i32], ptr @crc32_braid_table, i32 0, i32 %867
  %869 = load i32, ptr %868, align 4, !tbaa !5
  %870 = xor i32 %865, %869
  %871 = getelementptr inbounds nuw i8, ptr %783, i32 16
  %872 = load i64, ptr %871, align 1
  %873 = trunc i64 %872 to i32
  %874 = xor i32 %779, %873
  %875 = and i32 %874, 255
  %876 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 7168), i32 0, i32 %875
  %877 = load i32, ptr %876, align 4, !tbaa !5
  %878 = lshr i32 %874, 8
  %879 = and i32 %878, 255
  %880 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 6144), i32 0, i32 %879
  %881 = load i32, ptr %880, align 4, !tbaa !5
  %882 = xor i32 %881, %877
  %883 = lshr i32 %874, 16
  %884 = and i32 %883, 255
  %885 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 5120), i32 0, i32 %884
  %886 = load i32, ptr %885, align 4, !tbaa !5
  %887 = xor i32 %882, %886
  %888 = lshr i32 %874, 24
  %889 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 4096), i32 0, i32 %888
  %890 = load i32, ptr %889, align 4, !tbaa !5
  %891 = xor i32 %887, %890
  %892 = lshr i64 %872, 32
  %893 = trunc nuw i64 %892 to i32
  %894 = and i32 %893, 255
  %895 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 3072), i32 0, i32 %894
  %896 = load i32, ptr %895, align 4, !tbaa !5
  %897 = xor i32 %891, %896
  %898 = lshr i64 %872, 40
  %899 = trunc nuw nsw i64 %898 to i32
  %900 = and i32 %899, 255
  %901 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 2048), i32 0, i32 %900
  %902 = load i32, ptr %901, align 4, !tbaa !5
  %903 = xor i32 %897, %902
  %904 = lshr i64 %872, 48
  %905 = trunc nuw nsw i64 %904 to i32
  %906 = and i32 %905, 255
  %907 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 1024), i32 0, i32 %906
  %908 = load i32, ptr %907, align 4, !tbaa !5
  %909 = xor i32 %903, %908
  %910 = lshr i64 %872, 56
  %911 = trunc nuw nsw i64 %910 to i32
  %912 = getelementptr inbounds nuw [256 x i32], ptr @crc32_braid_table, i32 0, i32 %911
  %913 = load i32, ptr %912, align 4, !tbaa !5
  %914 = xor i32 %909, %913
  %915 = getelementptr inbounds nuw i8, ptr %783, i32 24
  %916 = load i64, ptr %915, align 1
  %917 = trunc i64 %916 to i32
  %918 = xor i32 %778, %917
  %919 = and i32 %918, 255
  %920 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 7168), i32 0, i32 %919
  %921 = load i32, ptr %920, align 4, !tbaa !5
  %922 = lshr i32 %918, 8
  %923 = and i32 %922, 255
  %924 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 6144), i32 0, i32 %923
  %925 = load i32, ptr %924, align 4, !tbaa !5
  %926 = xor i32 %925, %921
  %927 = lshr i32 %918, 16
  %928 = and i32 %927, 255
  %929 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 5120), i32 0, i32 %928
  %930 = load i32, ptr %929, align 4, !tbaa !5
  %931 = xor i32 %926, %930
  %932 = lshr i32 %918, 24
  %933 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 4096), i32 0, i32 %932
  %934 = load i32, ptr %933, align 4, !tbaa !5
  %935 = xor i32 %931, %934
  %936 = lshr i64 %916, 32
  %937 = trunc nuw i64 %936 to i32
  %938 = and i32 %937, 255
  %939 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 3072), i32 0, i32 %938
  %940 = load i32, ptr %939, align 4, !tbaa !5
  %941 = xor i32 %935, %940
  %942 = lshr i64 %916, 40
  %943 = trunc nuw nsw i64 %942 to i32
  %944 = and i32 %943, 255
  %945 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 2048), i32 0, i32 %944
  %946 = load i32, ptr %945, align 4, !tbaa !5
  %947 = xor i32 %941, %946
  %948 = lshr i64 %916, 48
  %949 = trunc nuw nsw i64 %948 to i32
  %950 = and i32 %949, 255
  %951 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 1024), i32 0, i32 %950
  %952 = load i32, ptr %951, align 4, !tbaa !5
  %953 = xor i32 %947, %952
  %954 = lshr i64 %916, 56
  %955 = trunc nuw nsw i64 %954 to i32
  %956 = getelementptr inbounds nuw [256 x i32], ptr @crc32_braid_table, i32 0, i32 %955
  %957 = load i32, ptr %956, align 4, !tbaa !5
  %958 = xor i32 %953, %957
  %959 = getelementptr inbounds nuw i8, ptr %783, i32 32
  %960 = load i64, ptr %959, align 1
  %961 = trunc i64 %960 to i32
  %962 = xor i32 %777, %961
  %963 = and i32 %962, 255
  %964 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 7168), i32 0, i32 %963
  %965 = load i32, ptr %964, align 4, !tbaa !5
  %966 = lshr i32 %962, 8
  %967 = and i32 %966, 255
  %968 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 6144), i32 0, i32 %967
  %969 = load i32, ptr %968, align 4, !tbaa !5
  %970 = xor i32 %969, %965
  %971 = lshr i32 %962, 16
  %972 = and i32 %971, 255
  %973 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 5120), i32 0, i32 %972
  %974 = load i32, ptr %973, align 4, !tbaa !5
  %975 = xor i32 %970, %974
  %976 = lshr i32 %962, 24
  %977 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 4096), i32 0, i32 %976
  %978 = load i32, ptr %977, align 4, !tbaa !5
  %979 = xor i32 %975, %978
  %980 = lshr i64 %960, 32
  %981 = trunc nuw i64 %980 to i32
  %982 = and i32 %981, 255
  %983 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 3072), i32 0, i32 %982
  %984 = load i32, ptr %983, align 4, !tbaa !5
  %985 = xor i32 %979, %984
  %986 = lshr i64 %960, 40
  %987 = trunc nuw nsw i64 %986 to i32
  %988 = and i32 %987, 255
  %989 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 2048), i32 0, i32 %988
  %990 = load i32, ptr %989, align 4, !tbaa !5
  %991 = xor i32 %985, %990
  %992 = lshr i64 %960, 48
  %993 = trunc nuw nsw i64 %992 to i32
  %994 = and i32 %993, 255
  %995 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 1024), i32 0, i32 %994
  %996 = load i32, ptr %995, align 4, !tbaa !5
  %997 = xor i32 %991, %996
  %998 = lshr i64 %960, 56
  %999 = trunc nuw nsw i64 %998 to i32
  %1000 = getelementptr inbounds nuw [256 x i32], ptr @crc32_braid_table, i32 0, i32 %999
  %1001 = load i32, ptr %1000, align 4, !tbaa !5
  %1002 = xor i32 %997, %1001
  %1003 = getelementptr inbounds nuw i8, ptr %783, i32 40
  %1004 = load i64, ptr %1003, align 1
  %1005 = trunc i64 %1004 to i32
  %1006 = xor i32 %776, %1005
  %1007 = and i32 %1006, 255
  %1008 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 7168), i32 0, i32 %1007
  %1009 = load i32, ptr %1008, align 4, !tbaa !5
  %1010 = lshr i32 %1006, 8
  %1011 = and i32 %1010, 255
  %1012 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 6144), i32 0, i32 %1011
  %1013 = load i32, ptr %1012, align 4, !tbaa !5
  %1014 = xor i32 %1013, %1009
  %1015 = lshr i32 %1006, 16
  %1016 = and i32 %1015, 255
  %1017 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 5120), i32 0, i32 %1016
  %1018 = load i32, ptr %1017, align 4, !tbaa !5
  %1019 = xor i32 %1014, %1018
  %1020 = lshr i32 %1006, 24
  %1021 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 4096), i32 0, i32 %1020
  %1022 = load i32, ptr %1021, align 4, !tbaa !5
  %1023 = xor i32 %1019, %1022
  %1024 = lshr i64 %1004, 32
  %1025 = trunc nuw i64 %1024 to i32
  %1026 = and i32 %1025, 255
  %1027 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 3072), i32 0, i32 %1026
  %1028 = load i32, ptr %1027, align 4, !tbaa !5
  %1029 = xor i32 %1023, %1028
  %1030 = lshr i64 %1004, 40
  %1031 = trunc nuw nsw i64 %1030 to i32
  %1032 = and i32 %1031, 255
  %1033 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 2048), i32 0, i32 %1032
  %1034 = load i32, ptr %1033, align 4, !tbaa !5
  %1035 = xor i32 %1029, %1034
  %1036 = lshr i64 %1004, 48
  %1037 = trunc nuw nsw i64 %1036 to i32
  %1038 = and i32 %1037, 255
  %1039 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 1024), i32 0, i32 %1038
  %1040 = load i32, ptr %1039, align 4, !tbaa !5
  %1041 = xor i32 %1035, %1040
  %1042 = lshr i64 %1004, 56
  %1043 = trunc nuw nsw i64 %1042 to i32
  %1044 = getelementptr inbounds nuw [256 x i32], ptr @crc32_braid_table, i32 0, i32 %1043
  %1045 = load i32, ptr %1044, align 4, !tbaa !5
  %1046 = xor i32 %1041, %1045
  %1047 = getelementptr inbounds nuw i8, ptr %783, i32 48
  %1048 = load i64, ptr %1047, align 1
  %1049 = trunc i64 %1048 to i32
  %1050 = xor i32 %775, %1049
  %1051 = and i32 %1050, 255
  %1052 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 7168), i32 0, i32 %1051
  %1053 = load i32, ptr %1052, align 4, !tbaa !5
  %1054 = lshr i32 %1050, 8
  %1055 = and i32 %1054, 255
  %1056 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 6144), i32 0, i32 %1055
  %1057 = load i32, ptr %1056, align 4, !tbaa !5
  %1058 = xor i32 %1057, %1053
  %1059 = lshr i32 %1050, 16
  %1060 = and i32 %1059, 255
  %1061 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 5120), i32 0, i32 %1060
  %1062 = load i32, ptr %1061, align 4, !tbaa !5
  %1063 = xor i32 %1058, %1062
  %1064 = lshr i32 %1050, 24
  %1065 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 4096), i32 0, i32 %1064
  %1066 = load i32, ptr %1065, align 4, !tbaa !5
  %1067 = xor i32 %1063, %1066
  %1068 = lshr i64 %1048, 32
  %1069 = trunc nuw i64 %1068 to i32
  %1070 = and i32 %1069, 255
  %1071 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 3072), i32 0, i32 %1070
  %1072 = load i32, ptr %1071, align 4, !tbaa !5
  %1073 = xor i32 %1067, %1072
  %1074 = lshr i64 %1048, 40
  %1075 = trunc nuw nsw i64 %1074 to i32
  %1076 = and i32 %1075, 255
  %1077 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 2048), i32 0, i32 %1076
  %1078 = load i32, ptr %1077, align 4, !tbaa !5
  %1079 = xor i32 %1073, %1078
  %1080 = lshr i64 %1048, 48
  %1081 = trunc nuw nsw i64 %1080 to i32
  %1082 = and i32 %1081, 255
  %1083 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 1024), i32 0, i32 %1082
  %1084 = load i32, ptr %1083, align 4, !tbaa !5
  %1085 = xor i32 %1079, %1084
  %1086 = lshr i64 %1048, 56
  %1087 = trunc nuw nsw i64 %1086 to i32
  %1088 = getelementptr inbounds nuw [256 x i32], ptr @crc32_braid_table, i32 0, i32 %1087
  %1089 = load i32, ptr %1088, align 4, !tbaa !5
  %1090 = xor i32 %1085, %1089
  %1091 = getelementptr inbounds nuw i8, ptr %783, i32 56
  %1092 = load i64, ptr %1091, align 1
  %1093 = trunc i64 %1092 to i32
  %1094 = xor i32 %774, %1093
  %1095 = and i32 %1094, 255
  %1096 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 7168), i32 0, i32 %1095
  %1097 = load i32, ptr %1096, align 4, !tbaa !5
  %1098 = lshr i32 %1094, 8
  %1099 = and i32 %1098, 255
  %1100 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 6144), i32 0, i32 %1099
  %1101 = load i32, ptr %1100, align 4, !tbaa !5
  %1102 = xor i32 %1101, %1097
  %1103 = lshr i32 %1094, 16
  %1104 = and i32 %1103, 255
  %1105 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 5120), i32 0, i32 %1104
  %1106 = load i32, ptr %1105, align 4, !tbaa !5
  %1107 = xor i32 %1102, %1106
  %1108 = lshr i32 %1094, 24
  %1109 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 4096), i32 0, i32 %1108
  %1110 = load i32, ptr %1109, align 4, !tbaa !5
  %1111 = xor i32 %1107, %1110
  %1112 = lshr i64 %1092, 32
  %1113 = trunc nuw i64 %1112 to i32
  %1114 = and i32 %1113, 255
  %1115 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 3072), i32 0, i32 %1114
  %1116 = load i32, ptr %1115, align 4, !tbaa !5
  %1117 = xor i32 %1111, %1116
  %1118 = lshr i64 %1092, 40
  %1119 = trunc nuw nsw i64 %1118 to i32
  %1120 = and i32 %1119, 255
  %1121 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 2048), i32 0, i32 %1120
  %1122 = load i32, ptr %1121, align 4, !tbaa !5
  %1123 = xor i32 %1117, %1122
  %1124 = lshr i64 %1092, 48
  %1125 = trunc nuw nsw i64 %1124 to i32
  %1126 = and i32 %1125, 255
  %1127 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_braid_table, i32 1024), i32 0, i32 %1126
  %1128 = load i32, ptr %1127, align 4, !tbaa !5
  %1129 = xor i32 %1123, %1128
  %1130 = lshr i64 %1092, 56
  %1131 = trunc nuw nsw i64 %1130 to i32
  %1132 = getelementptr inbounds nuw [256 x i32], ptr @crc32_braid_table, i32 0, i32 %1131
  %1133 = load i32, ptr %1132, align 4, !tbaa !5
  %1134 = xor i32 %1129, %1133
  %1135 = add nuw i32 %782, 64
  %1136 = icmp ult i32 %1135, %772
  br i1 %1136, label %773, label %1137, !llvm.loop !21

1137:                                             ; preds = %773
  %1138 = getelementptr inbounds nuw i8, ptr %0, i32 %772
  %1139 = load i64, ptr %1138, align 1
  %1140 = trunc i64 %1139 to i32
  %1141 = xor i32 %826, %1140
  %1142 = and i32 %1141, 255
  %1143 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 7168), i32 0, i32 %1142
  %1144 = load i32, ptr %1143, align 4, !tbaa !5
  %1145 = lshr i32 %1141, 8
  %1146 = and i32 %1145, 255
  %1147 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 6144), i32 0, i32 %1146
  %1148 = load i32, ptr %1147, align 4, !tbaa !5
  %1149 = lshr i32 %1141, 16
  %1150 = and i32 %1149, 255
  %1151 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 5120), i32 0, i32 %1150
  %1152 = load i32, ptr %1151, align 4, !tbaa !5
  %1153 = lshr i32 %1141, 24
  %1154 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 4096), i32 0, i32 %1153
  %1155 = load i32, ptr %1154, align 4, !tbaa !5
  %1156 = lshr i64 %1139, 32
  %1157 = trunc nuw i64 %1156 to i32
  %1158 = and i32 %1157, 255
  %1159 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 3072), i32 0, i32 %1158
  %1160 = load i32, ptr %1159, align 4, !tbaa !5
  %1161 = lshr i64 %1139, 40
  %1162 = trunc nuw nsw i64 %1161 to i32
  %1163 = and i32 %1162, 255
  %1164 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 2048), i32 0, i32 %1163
  %1165 = load i32, ptr %1164, align 4, !tbaa !5
  %1166 = lshr i64 %1139, 48
  %1167 = trunc nuw nsw i64 %1166 to i32
  %1168 = and i32 %1167, 255
  %1169 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 1024), i32 0, i32 %1168
  %1170 = load i32, ptr %1169, align 4, !tbaa !5
  %1171 = lshr i64 %1139, 56
  %1172 = trunc nuw nsw i64 %1171 to i32
  %1173 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %1172
  %1174 = load i32, ptr %1173, align 4, !tbaa !5
  %1175 = getelementptr inbounds nuw i8, ptr %1138, i32 8
  %1176 = load i64, ptr %1175, align 1
  %1177 = trunc i64 %1176 to i32
  %1178 = xor i32 %1144, %1148
  %1179 = xor i32 %1178, %1152
  %1180 = xor i32 %1179, %1155
  %1181 = xor i32 %1180, %1160
  %1182 = xor i32 %1181, %1165
  %1183 = xor i32 %1182, %1170
  %1184 = xor i32 %1183, %1174
  %1185 = xor i32 %1184, %1177
  %1186 = xor i32 %1185, %870
  %1187 = and i32 %1186, 255
  %1188 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 7168), i32 0, i32 %1187
  %1189 = load i32, ptr %1188, align 4, !tbaa !5
  %1190 = lshr i32 %1186, 8
  %1191 = and i32 %1190, 255
  %1192 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 6144), i32 0, i32 %1191
  %1193 = load i32, ptr %1192, align 4, !tbaa !5
  %1194 = lshr i32 %1186, 16
  %1195 = and i32 %1194, 255
  %1196 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 5120), i32 0, i32 %1195
  %1197 = load i32, ptr %1196, align 4, !tbaa !5
  %1198 = lshr i32 %1186, 24
  %1199 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 4096), i32 0, i32 %1198
  %1200 = load i32, ptr %1199, align 4, !tbaa !5
  %1201 = lshr i64 %1176, 32
  %1202 = trunc nuw i64 %1201 to i32
  %1203 = and i32 %1202, 255
  %1204 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 3072), i32 0, i32 %1203
  %1205 = load i32, ptr %1204, align 4, !tbaa !5
  %1206 = lshr i64 %1176, 40
  %1207 = trunc nuw nsw i64 %1206 to i32
  %1208 = and i32 %1207, 255
  %1209 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 2048), i32 0, i32 %1208
  %1210 = load i32, ptr %1209, align 4, !tbaa !5
  %1211 = lshr i64 %1176, 48
  %1212 = trunc nuw nsw i64 %1211 to i32
  %1213 = and i32 %1212, 255
  %1214 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 1024), i32 0, i32 %1213
  %1215 = load i32, ptr %1214, align 4, !tbaa !5
  %1216 = lshr i64 %1176, 56
  %1217 = trunc nuw nsw i64 %1216 to i32
  %1218 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %1217
  %1219 = load i32, ptr %1218, align 4, !tbaa !5
  %1220 = getelementptr inbounds nuw i8, ptr %1138, i32 16
  %1221 = load i64, ptr %1220, align 1
  %1222 = trunc i64 %1221 to i32
  %1223 = xor i32 %1189, %1193
  %1224 = xor i32 %1223, %1197
  %1225 = xor i32 %1224, %1200
  %1226 = xor i32 %1225, %1205
  %1227 = xor i32 %1226, %1210
  %1228 = xor i32 %1227, %1215
  %1229 = xor i32 %1228, %1219
  %1230 = xor i32 %1229, %1222
  %1231 = xor i32 %1230, %914
  %1232 = and i32 %1231, 255
  %1233 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 7168), i32 0, i32 %1232
  %1234 = load i32, ptr %1233, align 4, !tbaa !5
  %1235 = lshr i32 %1231, 8
  %1236 = and i32 %1235, 255
  %1237 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 6144), i32 0, i32 %1236
  %1238 = load i32, ptr %1237, align 4, !tbaa !5
  %1239 = lshr i32 %1231, 16
  %1240 = and i32 %1239, 255
  %1241 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 5120), i32 0, i32 %1240
  %1242 = load i32, ptr %1241, align 4, !tbaa !5
  %1243 = lshr i32 %1231, 24
  %1244 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 4096), i32 0, i32 %1243
  %1245 = load i32, ptr %1244, align 4, !tbaa !5
  %1246 = lshr i64 %1221, 32
  %1247 = trunc nuw i64 %1246 to i32
  %1248 = and i32 %1247, 255
  %1249 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 3072), i32 0, i32 %1248
  %1250 = load i32, ptr %1249, align 4, !tbaa !5
  %1251 = lshr i64 %1221, 40
  %1252 = trunc nuw nsw i64 %1251 to i32
  %1253 = and i32 %1252, 255
  %1254 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 2048), i32 0, i32 %1253
  %1255 = load i32, ptr %1254, align 4, !tbaa !5
  %1256 = lshr i64 %1221, 48
  %1257 = trunc nuw nsw i64 %1256 to i32
  %1258 = and i32 %1257, 255
  %1259 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 1024), i32 0, i32 %1258
  %1260 = load i32, ptr %1259, align 4, !tbaa !5
  %1261 = lshr i64 %1221, 56
  %1262 = trunc nuw nsw i64 %1261 to i32
  %1263 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %1262
  %1264 = load i32, ptr %1263, align 4, !tbaa !5
  %1265 = getelementptr inbounds nuw i8, ptr %1138, i32 24
  %1266 = load i64, ptr %1265, align 1
  %1267 = trunc i64 %1266 to i32
  %1268 = xor i32 %1234, %1238
  %1269 = xor i32 %1268, %1242
  %1270 = xor i32 %1269, %1245
  %1271 = xor i32 %1270, %1250
  %1272 = xor i32 %1271, %1255
  %1273 = xor i32 %1272, %1260
  %1274 = xor i32 %1273, %1264
  %1275 = xor i32 %1274, %1267
  %1276 = xor i32 %1275, %958
  %1277 = and i32 %1276, 255
  %1278 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 7168), i32 0, i32 %1277
  %1279 = load i32, ptr %1278, align 4, !tbaa !5
  %1280 = lshr i32 %1276, 8
  %1281 = and i32 %1280, 255
  %1282 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 6144), i32 0, i32 %1281
  %1283 = load i32, ptr %1282, align 4, !tbaa !5
  %1284 = lshr i32 %1276, 16
  %1285 = and i32 %1284, 255
  %1286 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 5120), i32 0, i32 %1285
  %1287 = load i32, ptr %1286, align 4, !tbaa !5
  %1288 = lshr i32 %1276, 24
  %1289 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 4096), i32 0, i32 %1288
  %1290 = load i32, ptr %1289, align 4, !tbaa !5
  %1291 = lshr i64 %1266, 32
  %1292 = trunc nuw i64 %1291 to i32
  %1293 = and i32 %1292, 255
  %1294 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 3072), i32 0, i32 %1293
  %1295 = load i32, ptr %1294, align 4, !tbaa !5
  %1296 = lshr i64 %1266, 40
  %1297 = trunc nuw nsw i64 %1296 to i32
  %1298 = and i32 %1297, 255
  %1299 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 2048), i32 0, i32 %1298
  %1300 = load i32, ptr %1299, align 4, !tbaa !5
  %1301 = lshr i64 %1266, 48
  %1302 = trunc nuw nsw i64 %1301 to i32
  %1303 = and i32 %1302, 255
  %1304 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 1024), i32 0, i32 %1303
  %1305 = load i32, ptr %1304, align 4, !tbaa !5
  %1306 = lshr i64 %1266, 56
  %1307 = trunc nuw nsw i64 %1306 to i32
  %1308 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %1307
  %1309 = load i32, ptr %1308, align 4, !tbaa !5
  %1310 = getelementptr inbounds nuw i8, ptr %1138, i32 32
  %1311 = load i64, ptr %1310, align 1
  %1312 = trunc i64 %1311 to i32
  %1313 = xor i32 %1279, %1283
  %1314 = xor i32 %1313, %1287
  %1315 = xor i32 %1314, %1290
  %1316 = xor i32 %1315, %1295
  %1317 = xor i32 %1316, %1300
  %1318 = xor i32 %1317, %1305
  %1319 = xor i32 %1318, %1309
  %1320 = xor i32 %1319, %1312
  %1321 = xor i32 %1320, %1002
  %1322 = and i32 %1321, 255
  %1323 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 7168), i32 0, i32 %1322
  %1324 = load i32, ptr %1323, align 4, !tbaa !5
  %1325 = lshr i32 %1321, 8
  %1326 = and i32 %1325, 255
  %1327 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 6144), i32 0, i32 %1326
  %1328 = load i32, ptr %1327, align 4, !tbaa !5
  %1329 = lshr i32 %1321, 16
  %1330 = and i32 %1329, 255
  %1331 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 5120), i32 0, i32 %1330
  %1332 = load i32, ptr %1331, align 4, !tbaa !5
  %1333 = lshr i32 %1321, 24
  %1334 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 4096), i32 0, i32 %1333
  %1335 = load i32, ptr %1334, align 4, !tbaa !5
  %1336 = lshr i64 %1311, 32
  %1337 = trunc nuw i64 %1336 to i32
  %1338 = and i32 %1337, 255
  %1339 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 3072), i32 0, i32 %1338
  %1340 = load i32, ptr %1339, align 4, !tbaa !5
  %1341 = lshr i64 %1311, 40
  %1342 = trunc nuw nsw i64 %1341 to i32
  %1343 = and i32 %1342, 255
  %1344 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 2048), i32 0, i32 %1343
  %1345 = load i32, ptr %1344, align 4, !tbaa !5
  %1346 = lshr i64 %1311, 48
  %1347 = trunc nuw nsw i64 %1346 to i32
  %1348 = and i32 %1347, 255
  %1349 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 1024), i32 0, i32 %1348
  %1350 = load i32, ptr %1349, align 4, !tbaa !5
  %1351 = lshr i64 %1311, 56
  %1352 = trunc nuw nsw i64 %1351 to i32
  %1353 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %1352
  %1354 = load i32, ptr %1353, align 4, !tbaa !5
  %1355 = getelementptr inbounds nuw i8, ptr %1138, i32 40
  %1356 = load i64, ptr %1355, align 1
  %1357 = trunc i64 %1356 to i32
  %1358 = xor i32 %1324, %1328
  %1359 = xor i32 %1358, %1332
  %1360 = xor i32 %1359, %1335
  %1361 = xor i32 %1360, %1340
  %1362 = xor i32 %1361, %1345
  %1363 = xor i32 %1362, %1350
  %1364 = xor i32 %1363, %1354
  %1365 = xor i32 %1364, %1357
  %1366 = xor i32 %1365, %1046
  %1367 = and i32 %1366, 255
  %1368 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 7168), i32 0, i32 %1367
  %1369 = load i32, ptr %1368, align 4, !tbaa !5
  %1370 = lshr i32 %1366, 8
  %1371 = and i32 %1370, 255
  %1372 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 6144), i32 0, i32 %1371
  %1373 = load i32, ptr %1372, align 4, !tbaa !5
  %1374 = lshr i32 %1366, 16
  %1375 = and i32 %1374, 255
  %1376 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 5120), i32 0, i32 %1375
  %1377 = load i32, ptr %1376, align 4, !tbaa !5
  %1378 = lshr i32 %1366, 24
  %1379 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 4096), i32 0, i32 %1378
  %1380 = load i32, ptr %1379, align 4, !tbaa !5
  %1381 = lshr i64 %1356, 32
  %1382 = trunc nuw i64 %1381 to i32
  %1383 = and i32 %1382, 255
  %1384 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 3072), i32 0, i32 %1383
  %1385 = load i32, ptr %1384, align 4, !tbaa !5
  %1386 = lshr i64 %1356, 40
  %1387 = trunc nuw nsw i64 %1386 to i32
  %1388 = and i32 %1387, 255
  %1389 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 2048), i32 0, i32 %1388
  %1390 = load i32, ptr %1389, align 4, !tbaa !5
  %1391 = lshr i64 %1356, 48
  %1392 = trunc nuw nsw i64 %1391 to i32
  %1393 = and i32 %1392, 255
  %1394 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 1024), i32 0, i32 %1393
  %1395 = load i32, ptr %1394, align 4, !tbaa !5
  %1396 = lshr i64 %1356, 56
  %1397 = trunc nuw nsw i64 %1396 to i32
  %1398 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %1397
  %1399 = load i32, ptr %1398, align 4, !tbaa !5
  %1400 = getelementptr inbounds nuw i8, ptr %1138, i32 48
  %1401 = load i64, ptr %1400, align 1
  %1402 = trunc i64 %1401 to i32
  %1403 = xor i32 %1369, %1373
  %1404 = xor i32 %1403, %1377
  %1405 = xor i32 %1404, %1380
  %1406 = xor i32 %1405, %1385
  %1407 = xor i32 %1406, %1390
  %1408 = xor i32 %1407, %1395
  %1409 = xor i32 %1408, %1399
  %1410 = xor i32 %1409, %1402
  %1411 = xor i32 %1410, %1090
  %1412 = and i32 %1411, 255
  %1413 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 7168), i32 0, i32 %1412
  %1414 = load i32, ptr %1413, align 4, !tbaa !5
  %1415 = lshr i32 %1411, 8
  %1416 = and i32 %1415, 255
  %1417 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 6144), i32 0, i32 %1416
  %1418 = load i32, ptr %1417, align 4, !tbaa !5
  %1419 = lshr i32 %1411, 16
  %1420 = and i32 %1419, 255
  %1421 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 5120), i32 0, i32 %1420
  %1422 = load i32, ptr %1421, align 4, !tbaa !5
  %1423 = lshr i32 %1411, 24
  %1424 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 4096), i32 0, i32 %1423
  %1425 = load i32, ptr %1424, align 4, !tbaa !5
  %1426 = lshr i64 %1401, 32
  %1427 = trunc nuw i64 %1426 to i32
  %1428 = and i32 %1427, 255
  %1429 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 3072), i32 0, i32 %1428
  %1430 = load i32, ptr %1429, align 4, !tbaa !5
  %1431 = lshr i64 %1401, 40
  %1432 = trunc nuw nsw i64 %1431 to i32
  %1433 = and i32 %1432, 255
  %1434 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 2048), i32 0, i32 %1433
  %1435 = load i32, ptr %1434, align 4, !tbaa !5
  %1436 = lshr i64 %1401, 48
  %1437 = trunc nuw nsw i64 %1436 to i32
  %1438 = and i32 %1437, 255
  %1439 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 1024), i32 0, i32 %1438
  %1440 = load i32, ptr %1439, align 4, !tbaa !5
  %1441 = lshr i64 %1401, 56
  %1442 = trunc nuw nsw i64 %1441 to i32
  %1443 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %1442
  %1444 = load i32, ptr %1443, align 4, !tbaa !5
  %1445 = getelementptr inbounds nuw i8, ptr %1138, i32 56
  %1446 = load i64, ptr %1445, align 1
  %1447 = trunc i64 %1446 to i32
  %1448 = xor i32 %1414, %1418
  %1449 = xor i32 %1448, %1422
  %1450 = xor i32 %1449, %1425
  %1451 = xor i32 %1450, %1430
  %1452 = xor i32 %1451, %1435
  %1453 = xor i32 %1452, %1440
  %1454 = xor i32 %1453, %1444
  %1455 = xor i32 %1454, %1447
  %1456 = xor i32 %1455, %1134
  %1457 = and i32 %1456, 255
  %1458 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 7168), i32 0, i32 %1457
  %1459 = load i32, ptr %1458, align 4, !tbaa !5
  %1460 = lshr i32 %1456, 8
  %1461 = and i32 %1460, 255
  %1462 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 6144), i32 0, i32 %1461
  %1463 = load i32, ptr %1462, align 4, !tbaa !5
  %1464 = xor i32 %1463, %1459
  %1465 = lshr i32 %1456, 16
  %1466 = and i32 %1465, 255
  %1467 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 5120), i32 0, i32 %1466
  %1468 = load i32, ptr %1467, align 4, !tbaa !5
  %1469 = xor i32 %1464, %1468
  %1470 = lshr i32 %1456, 24
  %1471 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 4096), i32 0, i32 %1470
  %1472 = load i32, ptr %1471, align 4, !tbaa !5
  %1473 = xor i32 %1469, %1472
  %1474 = lshr i64 %1446, 32
  %1475 = trunc nuw i64 %1474 to i32
  %1476 = and i32 %1475, 255
  %1477 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 3072), i32 0, i32 %1476
  %1478 = load i32, ptr %1477, align 4, !tbaa !5
  %1479 = xor i32 %1473, %1478
  %1480 = lshr i64 %1446, 40
  %1481 = trunc nuw nsw i64 %1480 to i32
  %1482 = and i32 %1481, 255
  %1483 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 2048), i32 0, i32 %1482
  %1484 = load i32, ptr %1483, align 4, !tbaa !5
  %1485 = xor i32 %1479, %1484
  %1486 = lshr i64 %1446, 48
  %1487 = trunc nuw nsw i64 %1486 to i32
  %1488 = and i32 %1487, 255
  %1489 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 1024), i32 0, i32 %1488
  %1490 = load i32, ptr %1489, align 4, !tbaa !5
  %1491 = xor i32 %1485, %1490
  %1492 = lshr i64 %1446, 56
  %1493 = trunc nuw nsw i64 %1492 to i32
  %1494 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %1493
  %1495 = load i32, ptr %1494, align 4, !tbaa !5
  %1496 = xor i32 %1491, %1495
  %1497 = icmp eq i32 %771, %1
  br i1 %1497, label %1512, label %1498

1498:                                             ; preds = %1137, %1498
  %1499 = phi i32 [ %1510, %1498 ], [ %771, %1137 ]
  %1500 = phi i32 [ %1509, %1498 ], [ %1496, %1137 ]
  %1501 = lshr i32 %1500, 8
  %1502 = getelementptr inbounds nuw i8, ptr %0, i32 %1499
  %1503 = load i8, ptr %1502, align 1, !tbaa !2
  %1504 = trunc i32 %1500 to i8
  %1505 = xor i8 %1503, %1504
  %1506 = zext i8 %1505 to i32
  %1507 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %1506
  %1508 = load i32, ptr %1507, align 4, !tbaa !5
  %1509 = xor i32 %1508, %1501
  %1510 = add nuw i32 %1499, 1
  %1511 = icmp ult i32 %1510, %1
  br i1 %1511, label %1498, label %1512, !llvm.loop !22

1512:                                             ; preds = %1498, %387, %480, %368, %1137
  %1513 = phi i32 [ %1496, %1137 ], [ %369, %368 ], [ %388, %387 ], [ %501, %480 ], [ %1509, %1498 ]
  %1514 = xor i32 %1513, -1
  ret i32 %1514
}

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i32(ptr writeonly captures(none), ptr readonly captures(none), i32, i1 immarg) #3

; Function Attrs: nounwind
define i32 @inflate_zip_media_batch(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef %6, i32 noundef %7, i32 noundef %8, i32 noundef %9, i32 noundef %10) local_unnamed_addr #4 {
  %12 = icmp eq i32 %7, 0
  br i1 %12, label %106, label %13

13:                                               ; preds = %11
  %14 = inttoptr i32 %0 to ptr
  %15 = inttoptr i32 %2 to ptr
  %16 = inttoptr i32 %3 to ptr
  %17 = inttoptr i32 %4 to ptr
  %18 = inttoptr i32 %5 to ptr
  %19 = inttoptr i32 %6 to ptr
  %20 = inttoptr i32 %8 to ptr
  %21 = inttoptr i32 %10 to ptr
  %22 = icmp eq i32 %10, 0
  br label %23

23:                                               ; preds = %13, %102
  %24 = phi i32 [ 0, %13 ], [ %103, %102 ]
  %25 = phi i32 [ 0, %13 ], [ %104, %102 ]
  %26 = getelementptr inbounds nuw i32, ptr %15, i32 %25
  %27 = load i32, ptr %26, align 4, !tbaa !5
  %28 = getelementptr inbounds nuw i32, ptr %16, i32 %25
  %29 = load i32, ptr %28, align 4, !tbaa !5
  %30 = getelementptr inbounds nuw i32, ptr %17, i32 %25
  %31 = load i32, ptr %30, align 4, !tbaa !5
  %32 = icmp ugt i32 %27, %1
  %33 = sub nuw i32 %1, %27
  %34 = icmp ugt i32 %29, %33
  %35 = select i1 %32, i1 true, i1 %34
  %36 = sub i32 2147483647, %24
  %37 = icmp ugt i32 %31, %36
  %38 = select i1 %35, i1 true, i1 %37
  br i1 %38, label %106, label %39

39:                                               ; preds = %23
  br i1 %22, label %47, label %40

40:                                               ; preds = %39
  %41 = icmp ugt i32 %24, %9
  %42 = sub nuw i32 %9, %24
  %43 = icmp ugt i32 %31, %42
  %44 = select i1 %41, i1 true, i1 %43
  br i1 %44, label %106, label %45

45:                                               ; preds = %40
  %46 = getelementptr inbounds nuw i32, ptr %21, i32 %25
  store i32 %24, ptr %46, align 4, !tbaa !5
  br label %47

47:                                               ; preds = %39, %45
  %48 = phi i32 [ %24, %45 ], [ 0, %39 ]
  %49 = getelementptr inbounds nuw i8, ptr %20, i32 %48
  %50 = getelementptr inbounds nuw i8, ptr %14, i32 %27
  %51 = getelementptr inbounds nuw i32, ptr %18, i32 %25
  %52 = load i32, ptr %51, align 4, !tbaa !5
  switch i32 %52, label %106 [
    i32 0, label %53
    i32 8, label %57
  ]

53:                                               ; preds = %47
  %54 = icmp eq i32 %29, %31
  br i1 %54, label %55, label %106

55:                                               ; preds = %53
  br i1 %22, label %96, label %56

56:                                               ; preds = %55
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %49, ptr align 1 %50, i32 %29, i1 false)
  br label %96

57:                                               ; preds = %47
  br i1 %22, label %58, label %93

58:                                               ; preds = %57
  %59 = icmp ult i32 %29, 5
  br i1 %59, label %91, label %60

60:                                               ; preds = %58
  %61 = add i32 %29, -5
  %62 = icmp ne i32 %61, %31
  %63 = icmp ugt i32 %31, 65535
  %64 = or i1 %62, %63
  br i1 %64, label %91, label %65

65:                                               ; preds = %60
  %66 = load i8, ptr %50, align 1, !tbaa !2
  %67 = and i8 %66, 7
  %68 = icmp eq i8 %67, 1
  br i1 %68, label %69, label %91

69:                                               ; preds = %65
  %70 = getelementptr inbounds nuw i8, ptr %50, i32 1
  %71 = load i8, ptr %70, align 1, !tbaa !2
  %72 = zext i8 %71 to i32
  %73 = getelementptr inbounds nuw i8, ptr %50, i32 2
  %74 = load i8, ptr %73, align 1, !tbaa !2
  %75 = zext i8 %74 to i32
  %76 = shl nuw nsw i32 %75, 8
  %77 = or disjoint i32 %76, %72
  %78 = icmp eq i32 %77, %31
  br i1 %78, label %79, label %91

79:                                               ; preds = %69
  %80 = getelementptr inbounds nuw i8, ptr %50, i32 3
  %81 = load i8, ptr %80, align 1, !tbaa !2
  %82 = zext i8 %81 to i32
  %83 = getelementptr inbounds nuw i8, ptr %50, i32 4
  %84 = load i8, ptr %83, align 1, !tbaa !2
  %85 = zext i8 %84 to i32
  %86 = shl nuw nsw i32 %85, 8
  %87 = or disjoint i32 %86, %82
  %88 = xor i32 %87, %31
  %89 = icmp eq i32 %88, 65535
  %90 = getelementptr inbounds nuw i8, ptr %50, i32 5
  br i1 %89, label %96, label %91

91:                                               ; preds = %65, %60, %58, %69, %79
  %92 = icmp ugt i32 %31, %9
  br i1 %92, label %106, label %93

93:                                               ; preds = %57, %91
  %94 = tail call i32 @term_bank_inflate(ptr noundef %50, i32 noundef %29, ptr noundef %49, i32 noundef %31) #28
  %95 = icmp eq i32 %94, 0
  br i1 %95, label %96, label %106

96:                                               ; preds = %79, %93, %55, %56
  %97 = phi ptr [ %49, %56 ], [ %50, %55 ], [ %49, %93 ], [ %90, %79 ]
  %98 = tail call fastcc i32 @crc32_bytes(ptr noundef %97, i32 noundef %31)
  %99 = getelementptr inbounds nuw i32, ptr %19, i32 %25
  %100 = load i32, ptr %99, align 4, !tbaa !5
  %101 = icmp eq i32 %98, %100
  br i1 %101, label %102, label %106

102:                                              ; preds = %96
  %103 = add i32 %31, %24
  %104 = add nuw i32 %25, 1
  %105 = icmp eq i32 %104, %7
  br i1 %105, label %106, label %23, !llvm.loop !23

106:                                              ; preds = %102, %40, %23, %93, %53, %47, %96, %91, %11
  %107 = phi i32 [ -1, %11 ], [ -1, %91 ], [ -1, %40 ], [ -1, %23 ], [ %94, %93 ], [ -3, %53 ], [ -1, %47 ], [ -4, %96 ], [ %103, %102 ]
  ret i32 %107
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define range(i32 -4, 1) i32 @verify_term_bank_source_crcs(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef %6, i32 noundef %7, i32 noundef %8) local_unnamed_addr #8 {
  %10 = alloca %struct.Crc32Shift, align 4
  %11 = icmp eq i32 %0, 0
  %12 = icmp eq i32 %2, 0
  %13 = or i1 %11, %12
  %14 = icmp eq i32 %3, 0
  %15 = or i1 %13, %14
  %16 = icmp eq i32 %4, 0
  %17 = or i1 %15, %16
  br i1 %17, label %636, label %18

18:                                               ; preds = %9
  %19 = icmp eq i32 %6, 0
  br i1 %19, label %159, label %20

20:                                               ; preds = %18
  %21 = icmp eq i32 %5, 0
  %22 = icmp eq i32 %7, 0
  %23 = or i1 %21, %22
  br i1 %23, label %636, label %24

24:                                               ; preds = %20
  %25 = inttoptr i32 %0 to ptr
  %26 = inttoptr i32 %2 to ptr
  %27 = inttoptr i32 %4 to ptr
  %28 = inttoptr i32 %5 to ptr
  %29 = inttoptr i32 %7 to ptr
  call void @llvm.lifetime.start.p0(i64 516, ptr nonnull %10) #28
  store i32 -1, ptr %10, align 4, !tbaa !24
  %30 = tail call fastcc i32 @crc32_bytes(ptr noundef %25, i32 noundef 0)
  %31 = getelementptr inbounds nuw i8, ptr %10, i32 4
  %32 = getelementptr inbounds nuw i8, ptr %10, i32 8
  %33 = getelementptr inbounds nuw i8, ptr %10, i32 12
  %34 = getelementptr inbounds nuw i8, ptr %10, i32 16
  %35 = getelementptr inbounds nuw i8, ptr %10, i32 20
  %36 = getelementptr inbounds nuw i8, ptr %10, i32 24
  %37 = getelementptr inbounds nuw i8, ptr %10, i32 28
  %38 = getelementptr inbounds nuw i8, ptr %10, i32 32
  %39 = getelementptr inbounds nuw i8, ptr %10, i32 36
  %40 = getelementptr inbounds nuw i8, ptr %10, i32 40
  %41 = getelementptr inbounds nuw i8, ptr %10, i32 44
  %42 = getelementptr inbounds nuw i8, ptr %10, i32 48
  %43 = getelementptr inbounds nuw i8, ptr %10, i32 52
  %44 = getelementptr inbounds nuw i8, ptr %10, i32 56
  %45 = getelementptr inbounds nuw i8, ptr %10, i32 60
  %46 = getelementptr inbounds nuw i8, ptr %10, i32 64
  %47 = getelementptr inbounds nuw i8, ptr %10, i32 68
  %48 = getelementptr inbounds nuw i8, ptr %10, i32 72
  %49 = getelementptr inbounds nuw i8, ptr %10, i32 76
  %50 = getelementptr inbounds nuw i8, ptr %10, i32 80
  %51 = getelementptr inbounds nuw i8, ptr %10, i32 84
  %52 = getelementptr inbounds nuw i8, ptr %10, i32 88
  %53 = getelementptr inbounds nuw i8, ptr %10, i32 92
  %54 = getelementptr inbounds nuw i8, ptr %10, i32 96
  %55 = getelementptr inbounds nuw i8, ptr %10, i32 100
  %56 = getelementptr inbounds nuw i8, ptr %10, i32 104
  %57 = getelementptr inbounds nuw i8, ptr %10, i32 108
  %58 = getelementptr inbounds nuw i8, ptr %10, i32 112
  %59 = getelementptr inbounds nuw i8, ptr %10, i32 116
  %60 = getelementptr inbounds nuw i8, ptr %10, i32 120
  %61 = getelementptr inbounds nuw i8, ptr %10, i32 124
  %62 = getelementptr inbounds nuw i8, ptr %10, i32 128
  %63 = getelementptr inbounds nuw i8, ptr %10, i32 132
  %64 = getelementptr inbounds nuw i8, ptr %10, i32 136
  %65 = getelementptr inbounds nuw i8, ptr %10, i32 140
  %66 = getelementptr inbounds nuw i8, ptr %10, i32 144
  %67 = getelementptr inbounds nuw i8, ptr %10, i32 148
  %68 = getelementptr inbounds nuw i8, ptr %10, i32 152
  %69 = getelementptr inbounds nuw i8, ptr %10, i32 156
  %70 = getelementptr inbounds nuw i8, ptr %10, i32 160
  %71 = getelementptr inbounds nuw i8, ptr %10, i32 164
  %72 = getelementptr inbounds nuw i8, ptr %10, i32 168
  %73 = getelementptr inbounds nuw i8, ptr %10, i32 172
  %74 = getelementptr inbounds nuw i8, ptr %10, i32 176
  %75 = getelementptr inbounds nuw i8, ptr %10, i32 180
  %76 = getelementptr inbounds nuw i8, ptr %10, i32 184
  %77 = getelementptr inbounds nuw i8, ptr %10, i32 188
  %78 = getelementptr inbounds nuw i8, ptr %10, i32 192
  %79 = getelementptr inbounds nuw i8, ptr %10, i32 196
  %80 = getelementptr inbounds nuw i8, ptr %10, i32 200
  %81 = getelementptr inbounds nuw i8, ptr %10, i32 204
  %82 = getelementptr inbounds nuw i8, ptr %10, i32 208
  %83 = getelementptr inbounds nuw i8, ptr %10, i32 212
  %84 = getelementptr inbounds nuw i8, ptr %10, i32 216
  %85 = getelementptr inbounds nuw i8, ptr %10, i32 220
  %86 = getelementptr inbounds nuw i8, ptr %10, i32 224
  %87 = getelementptr inbounds nuw i8, ptr %10, i32 228
  %88 = getelementptr inbounds nuw i8, ptr %10, i32 232
  %89 = getelementptr inbounds nuw i8, ptr %10, i32 236
  %90 = getelementptr inbounds nuw i8, ptr %10, i32 240
  %91 = getelementptr inbounds nuw i8, ptr %10, i32 244
  %92 = getelementptr inbounds nuw i8, ptr %10, i32 248
  %93 = getelementptr inbounds nuw i8, ptr %10, i32 252
  %94 = getelementptr inbounds nuw i8, ptr %10, i32 256
  %95 = getelementptr inbounds nuw i8, ptr %10, i32 260
  %96 = getelementptr inbounds nuw i8, ptr %10, i32 264
  %97 = getelementptr inbounds nuw i8, ptr %10, i32 268
  %98 = getelementptr inbounds nuw i8, ptr %10, i32 272
  %99 = getelementptr inbounds nuw i8, ptr %10, i32 276
  %100 = getelementptr inbounds nuw i8, ptr %10, i32 280
  %101 = getelementptr inbounds nuw i8, ptr %10, i32 284
  %102 = getelementptr inbounds nuw i8, ptr %10, i32 288
  %103 = getelementptr inbounds nuw i8, ptr %10, i32 292
  %104 = getelementptr inbounds nuw i8, ptr %10, i32 296
  %105 = getelementptr inbounds nuw i8, ptr %10, i32 300
  %106 = getelementptr inbounds nuw i8, ptr %10, i32 304
  %107 = getelementptr inbounds nuw i8, ptr %10, i32 308
  %108 = getelementptr inbounds nuw i8, ptr %10, i32 312
  %109 = getelementptr inbounds nuw i8, ptr %10, i32 316
  %110 = getelementptr inbounds nuw i8, ptr %10, i32 320
  %111 = getelementptr inbounds nuw i8, ptr %10, i32 324
  %112 = getelementptr inbounds nuw i8, ptr %10, i32 328
  %113 = getelementptr inbounds nuw i8, ptr %10, i32 332
  %114 = getelementptr inbounds nuw i8, ptr %10, i32 336
  %115 = getelementptr inbounds nuw i8, ptr %10, i32 340
  %116 = getelementptr inbounds nuw i8, ptr %10, i32 344
  %117 = getelementptr inbounds nuw i8, ptr %10, i32 348
  %118 = getelementptr inbounds nuw i8, ptr %10, i32 352
  %119 = getelementptr inbounds nuw i8, ptr %10, i32 356
  %120 = getelementptr inbounds nuw i8, ptr %10, i32 360
  %121 = getelementptr inbounds nuw i8, ptr %10, i32 364
  %122 = getelementptr inbounds nuw i8, ptr %10, i32 368
  %123 = getelementptr inbounds nuw i8, ptr %10, i32 372
  %124 = getelementptr inbounds nuw i8, ptr %10, i32 376
  %125 = getelementptr inbounds nuw i8, ptr %10, i32 380
  %126 = getelementptr inbounds nuw i8, ptr %10, i32 384
  %127 = getelementptr inbounds nuw i8, ptr %10, i32 388
  %128 = getelementptr inbounds nuw i8, ptr %10, i32 392
  %129 = getelementptr inbounds nuw i8, ptr %10, i32 396
  %130 = getelementptr inbounds nuw i8, ptr %10, i32 400
  %131 = getelementptr inbounds nuw i8, ptr %10, i32 404
  %132 = getelementptr inbounds nuw i8, ptr %10, i32 408
  %133 = getelementptr inbounds nuw i8, ptr %10, i32 412
  %134 = getelementptr inbounds nuw i8, ptr %10, i32 416
  %135 = getelementptr inbounds nuw i8, ptr %10, i32 420
  %136 = getelementptr inbounds nuw i8, ptr %10, i32 424
  %137 = getelementptr inbounds nuw i8, ptr %10, i32 428
  %138 = getelementptr inbounds nuw i8, ptr %10, i32 432
  %139 = getelementptr inbounds nuw i8, ptr %10, i32 436
  %140 = getelementptr inbounds nuw i8, ptr %10, i32 440
  %141 = getelementptr inbounds nuw i8, ptr %10, i32 444
  %142 = getelementptr inbounds nuw i8, ptr %10, i32 448
  %143 = getelementptr inbounds nuw i8, ptr %10, i32 452
  %144 = getelementptr inbounds nuw i8, ptr %10, i32 456
  %145 = getelementptr inbounds nuw i8, ptr %10, i32 460
  %146 = getelementptr inbounds nuw i8, ptr %10, i32 464
  %147 = getelementptr inbounds nuw i8, ptr %10, i32 468
  %148 = getelementptr inbounds nuw i8, ptr %10, i32 472
  %149 = getelementptr inbounds nuw i8, ptr %10, i32 476
  %150 = getelementptr inbounds nuw i8, ptr %10, i32 480
  %151 = getelementptr inbounds nuw i8, ptr %10, i32 484
  %152 = getelementptr inbounds nuw i8, ptr %10, i32 488
  %153 = getelementptr inbounds nuw i8, ptr %10, i32 492
  %154 = getelementptr inbounds nuw i8, ptr %10, i32 496
  %155 = getelementptr inbounds nuw i8, ptr %10, i32 500
  %156 = getelementptr inbounds nuw i8, ptr %10, i32 504
  %157 = getelementptr inbounds nuw i8, ptr %10, i32 508
  %158 = getelementptr inbounds nuw i8, ptr %10, i32 512
  br label %191

159:                                              ; preds = %18
  %160 = inttoptr i32 %0 to ptr
  %161 = inttoptr i32 %2 to ptr
  %162 = inttoptr i32 %4 to ptr
  call void @llvm.lifetime.start.p0(i64 516, ptr nonnull %10) #28
  store i32 -1, ptr %10, align 4, !tbaa !24
  %163 = tail call fastcc i32 @crc32_bytes(ptr noundef %160, i32 noundef 0)
  br label %164

164:                                              ; preds = %159, %178
  %165 = phi i32 [ %180, %178 ], [ 0, %159 ]
  %166 = phi i32 [ %179, %178 ], [ 0, %159 ]
  %167 = shl i32 %166, 3
  %168 = getelementptr inbounds nuw i8, ptr %161, i32 %167
  %169 = load i32, ptr %168, align 4, !tbaa !5
  %170 = getelementptr inbounds nuw i8, ptr %168, i32 4
  %171 = load i32, ptr %170, align 4, !tbaa !5
  %172 = icmp ne i32 %169, %165
  %173 = icmp ugt i32 %169, %1
  %174 = or i1 %172, %173
  %175 = sub nuw i32 %1, %169
  %176 = icmp ugt i32 %171, %175
  %177 = select i1 %174, i1 true, i1 %176
  br i1 %177, label %634, label %182

178:                                              ; preds = %182
  %179 = add nuw i32 %166, 1
  %180 = add i32 %171, %165
  %181 = icmp eq i32 %179, %3
  br i1 %181, label %619, label %164, !llvm.loop !26

182:                                              ; preds = %164
  %183 = getelementptr inbounds nuw i8, ptr %160, i32 %165
  %184 = tail call fastcc i32 @crc32_bytes(ptr noundef %183, i32 noundef %171)
  %185 = getelementptr inbounds nuw i32, ptr %162, i32 %166
  %186 = load i32, ptr %185, align 4, !tbaa !5
  %187 = icmp eq i32 %184, %186
  br i1 %187, label %178, label %634

188:                                              ; preds = %606
  %189 = add nuw i32 %196, 1
  %190 = icmp eq i32 %189, %3
  br i1 %190, label %619, label %191, !llvm.loop !26

191:                                              ; preds = %24, %188
  %192 = phi i32 [ %612, %188 ], [ 0, %24 ]
  %193 = phi i32 [ %210, %188 ], [ 0, %24 ]
  %194 = phi i32 [ %609, %188 ], [ 0, %24 ]
  %195 = phi i32 [ %608, %188 ], [ 0, %24 ]
  %196 = phi i32 [ %189, %188 ], [ 0, %24 ]
  %197 = phi i32 [ %607, %188 ], [ -1, %24 ]
  %198 = shl i32 %196, 3
  %199 = getelementptr inbounds nuw i8, ptr %26, i32 %198
  %200 = load i32, ptr %199, align 4, !tbaa !5
  %201 = getelementptr inbounds nuw i8, ptr %199, i32 4
  %202 = load i32, ptr %201, align 4, !tbaa !5
  %203 = icmp ne i32 %200, %193
  %204 = icmp ugt i32 %200, %1
  %205 = or i1 %203, %204
  %206 = sub nuw i32 %1, %200
  %207 = icmp ugt i32 %202, %206
  %208 = select i1 %205, i1 true, i1 %207
  br i1 %208, label %634, label %209

209:                                              ; preds = %191
  %210 = add i32 %202, %193
  %211 = icmp ult i32 %192, %6
  br i1 %211, label %212, label %606

212:                                              ; preds = %209, %563
  %213 = phi i32 [ %604, %563 ], [ %192, %209 ]
  %214 = phi i32 [ %603, %563 ], [ %193, %209 ]
  %215 = phi i32 [ %602, %563 ], [ 0, %209 ]
  %216 = phi i32 [ %255, %563 ], [ %194, %209 ]
  %217 = phi i32 [ %254, %563 ], [ %195, %209 ]
  %218 = phi i32 [ %564, %563 ], [ %197, %209 ]
  %219 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %28, i32 %213
  %220 = getelementptr inbounds nuw i8, ptr %219, i32 36
  %221 = load i32, ptr %220, align 4, !tbaa !27
  %222 = icmp ult i32 %221, %210
  br i1 %222, label %223, label %606

223:                                              ; preds = %212
  %224 = getelementptr inbounds nuw i8, ptr %219, i32 40
  %225 = load i32, ptr %224, align 4, !tbaa !29
  %226 = icmp ult i32 %221, %214
  %227 = icmp eq i32 %225, 0
  %228 = select i1 %226, i1 true, i1 %227
  %229 = sub nuw i32 %210, %221
  %230 = icmp ugt i32 %225, %229
  %231 = select i1 %228, i1 true, i1 %230
  br i1 %231, label %634, label %232

232:                                              ; preds = %223
  %233 = getelementptr inbounds nuw i8, ptr %25, i32 %214
  %234 = sub nuw i32 %221, %214
  %235 = tail call fastcc i32 @crc32_update_gap(i32 noundef %215, ptr noundef %233, i32 noundef %234)
  %236 = getelementptr inbounds nuw i32, ptr %29, i32 %213
  %237 = load i32, ptr %236, align 4, !tbaa !5
  %238 = icmp eq i32 %237, -1
  br i1 %238, label %239, label %242

239:                                              ; preds = %232
  %240 = getelementptr inbounds nuw i8, ptr %25, i32 %221
  %241 = tail call fastcc i32 @crc32_bytes(ptr noundef %240, i32 noundef %225)
  br label %253

242:                                              ; preds = %232
  %243 = icmp ult i32 %237, %213
  br i1 %243, label %244, label %634

244:                                              ; preds = %242
  %245 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %28, i32 %237, i32 10
  %246 = load i32, ptr %245, align 4, !tbaa !29
  %247 = icmp eq i32 %246, %225
  br i1 %247, label %248, label %634

248:                                              ; preds = %244
  %249 = getelementptr inbounds nuw i32, ptr %29, i32 %237
  %250 = load i32, ptr %249, align 4, !tbaa !5
  %251 = add i32 %225, %216
  %252 = add i32 %217, 1
  br label %253

253:                                              ; preds = %248, %239
  %254 = phi i32 [ %217, %239 ], [ %252, %248 ]
  %255 = phi i32 [ %216, %239 ], [ %251, %248 ]
  %256 = phi i32 [ %241, %239 ], [ %250, %248 ]
  store i32 %256, ptr %236, align 4, !tbaa !5
  %257 = icmp eq i32 %218, %225
  br i1 %257, label %563, label %502

258:                                              ; preds = %560
  %259 = lshr i32 %534, 1
  %260 = and i32 %534, 1
  %261 = icmp eq i32 %260, 0
  %262 = select i1 %261, i32 0, i32 -306674912
  %263 = xor i32 %262, %259
  %264 = lshr i32 %263, 1
  %265 = and i32 %534, 2
  %266 = icmp eq i32 %265, 0
  %267 = select i1 %266, i32 0, i32 -306674912
  %268 = xor i32 %267, %264
  %269 = lshr i32 %268, 1
  %270 = and i32 %534, 4
  %271 = icmp eq i32 %270, 0
  %272 = select i1 %271, i32 0, i32 -306674912
  %273 = xor i32 %272, %269
  %274 = lshr i32 %273, 1
  %275 = and i32 %534, 8
  %276 = icmp eq i32 %275, 0
  %277 = select i1 %276, i32 0, i32 -306674912
  %278 = xor i32 %277, %274
  %279 = lshr i32 %278, 1
  %280 = and i32 %534, 16
  %281 = icmp eq i32 %280, 0
  %282 = select i1 %281, i32 0, i32 -306674912
  %283 = xor i32 %282, %279
  %284 = lshr i32 %283, 1
  %285 = and i32 %534, 32
  %286 = icmp eq i32 %285, 0
  %287 = select i1 %286, i32 0, i32 -306674912
  %288 = xor i32 %287, %284
  %289 = lshr i32 %288, 1
  %290 = and i32 %263, 32
  %291 = icmp eq i32 %290, 0
  %292 = select i1 %291, i32 0, i32 -306674912
  %293 = xor i32 %292, %289
  %294 = lshr i32 %293, 1
  %295 = and i32 %268, 32
  %296 = icmp eq i32 %295, 0
  %297 = select i1 %296, i32 0, i32 -306674912
  %298 = xor i32 %297, %294
  %299 = lshr i32 %298, 1
  %300 = and i32 %273, 32
  %301 = icmp eq i32 %300, 0
  %302 = select i1 %301, i32 0, i32 -306674912
  %303 = xor i32 %302, %299
  %304 = lshr i32 %303, 1
  %305 = and i32 %278, 32
  %306 = icmp eq i32 %305, 0
  %307 = select i1 %306, i32 0, i32 -306674912
  %308 = xor i32 %307, %304
  %309 = lshr i32 %308, 1
  %310 = and i32 %283, 32
  %311 = icmp eq i32 %310, 0
  %312 = select i1 %311, i32 0, i32 -306674912
  %313 = xor i32 %312, %309
  %314 = lshr i32 %313, 1
  %315 = and i32 %288, 32
  %316 = icmp eq i32 %315, 0
  %317 = select i1 %316, i32 0, i32 -306674912
  %318 = xor i32 %317, %314
  %319 = lshr i32 %318, 1
  %320 = and i32 %293, 32
  %321 = icmp eq i32 %320, 0
  %322 = select i1 %321, i32 0, i32 -306674912
  %323 = xor i32 %322, %319
  %324 = lshr i32 %323, 1
  %325 = and i32 %298, 32
  %326 = icmp eq i32 %325, 0
  %327 = select i1 %326, i32 0, i32 -306674912
  %328 = xor i32 %327, %324
  %329 = lshr i32 %328, 1
  %330 = and i32 %303, 32
  %331 = icmp eq i32 %330, 0
  %332 = select i1 %331, i32 0, i32 -306674912
  %333 = xor i32 %332, %329
  %334 = lshr i32 %333, 1
  %335 = and i32 %308, 32
  %336 = icmp eq i32 %335, 0
  %337 = select i1 %336, i32 0, i32 -306674912
  %338 = xor i32 %337, %334
  %339 = lshr i32 %338, 1
  %340 = and i32 %313, 32
  %341 = icmp eq i32 %340, 0
  %342 = select i1 %341, i32 0, i32 -306674912
  %343 = xor i32 %342, %339
  %344 = lshr i32 %343, 1
  %345 = and i32 %318, 32
  %346 = icmp eq i32 %345, 0
  %347 = select i1 %346, i32 0, i32 -306674912
  %348 = xor i32 %347, %344
  %349 = lshr i32 %348, 1
  %350 = and i32 %323, 32
  %351 = icmp eq i32 %350, 0
  %352 = select i1 %351, i32 0, i32 -306674912
  %353 = xor i32 %352, %349
  %354 = lshr i32 %353, 1
  %355 = and i32 %328, 32
  %356 = icmp eq i32 %355, 0
  %357 = select i1 %356, i32 0, i32 -306674912
  %358 = xor i32 %357, %354
  %359 = lshr i32 %358, 1
  %360 = and i32 %333, 32
  %361 = icmp eq i32 %360, 0
  %362 = select i1 %361, i32 0, i32 -306674912
  %363 = xor i32 %362, %359
  %364 = lshr i32 %363, 1
  %365 = and i32 %338, 32
  %366 = icmp eq i32 %365, 0
  %367 = select i1 %366, i32 0, i32 -306674912
  %368 = xor i32 %367, %364
  %369 = lshr i32 %368, 1
  %370 = and i32 %343, 32
  %371 = icmp eq i32 %370, 0
  %372 = select i1 %371, i32 0, i32 -306674912
  %373 = xor i32 %372, %369
  %374 = lshr i32 %373, 1
  %375 = and i32 %348, 32
  %376 = icmp eq i32 %375, 0
  %377 = select i1 %376, i32 0, i32 -306674912
  %378 = xor i32 %377, %374
  %379 = lshr i32 %378, 1
  %380 = and i32 %353, 32
  %381 = icmp eq i32 %380, 0
  %382 = select i1 %381, i32 0, i32 -306674912
  %383 = xor i32 %382, %379
  %384 = lshr i32 %383, 1
  %385 = and i32 %358, 32
  %386 = icmp eq i32 %385, 0
  %387 = select i1 %386, i32 0, i32 -306674912
  %388 = xor i32 %387, %384
  %389 = lshr i32 %388, 1
  %390 = and i32 %363, 32
  %391 = icmp eq i32 %390, 0
  %392 = select i1 %391, i32 0, i32 -306674912
  %393 = xor i32 %392, %389
  %394 = lshr i32 %393, 1
  %395 = and i32 %368, 32
  %396 = icmp eq i32 %395, 0
  %397 = select i1 %396, i32 0, i32 -306674912
  %398 = xor i32 %397, %394
  %399 = lshr i32 %398, 1
  %400 = and i32 %373, 32
  %401 = icmp eq i32 %400, 0
  %402 = select i1 %401, i32 0, i32 -306674912
  %403 = xor i32 %402, %399
  %404 = lshr i32 %403, 1
  %405 = and i32 %378, 32
  %406 = icmp eq i32 %405, 0
  %407 = select i1 %406, i32 0, i32 -306674912
  %408 = xor i32 %407, %404
  %409 = lshr i32 %408, 1
  %410 = and i32 %383, 32
  %411 = icmp eq i32 %410, 0
  %412 = select i1 %411, i32 0, i32 -306674912
  %413 = xor i32 %412, %409
  store i32 0, ptr %31, align 4, !tbaa !5
  store i32 %413, ptr %32, align 4, !tbaa !5
  store i32 %408, ptr %33, align 4, !tbaa !5
  %414 = xor i32 %408, %413
  store i32 %414, ptr %34, align 4, !tbaa !5
  store i32 %403, ptr %35, align 4, !tbaa !5
  %415 = xor i32 %403, %413
  store i32 %415, ptr %36, align 4, !tbaa !5
  %416 = xor i32 %403, %408
  store i32 %416, ptr %37, align 4, !tbaa !5
  %417 = xor i32 %416, %413
  store i32 %417, ptr %38, align 4, !tbaa !5
  store i32 %398, ptr %39, align 4, !tbaa !5
  %418 = xor i32 %398, %413
  store i32 %418, ptr %40, align 4, !tbaa !5
  %419 = xor i32 %398, %408
  store i32 %419, ptr %41, align 4, !tbaa !5
  %420 = xor i32 %419, %413
  store i32 %420, ptr %42, align 4, !tbaa !5
  %421 = xor i32 %398, %403
  store i32 %421, ptr %43, align 4, !tbaa !5
  %422 = xor i32 %421, %413
  store i32 %422, ptr %44, align 4, !tbaa !5
  %423 = xor i32 %421, %408
  store i32 %423, ptr %45, align 4, !tbaa !5
  %424 = xor i32 %423, %413
  store i32 %424, ptr %46, align 4, !tbaa !5
  store i32 0, ptr %47, align 4, !tbaa !5
  store i32 %393, ptr %48, align 4, !tbaa !5
  store i32 %388, ptr %49, align 4, !tbaa !5
  %425 = xor i32 %388, %393
  store i32 %425, ptr %50, align 4, !tbaa !5
  store i32 %383, ptr %51, align 4, !tbaa !5
  %426 = xor i32 %383, %393
  store i32 %426, ptr %52, align 4, !tbaa !5
  %427 = xor i32 %383, %388
  store i32 %427, ptr %53, align 4, !tbaa !5
  %428 = xor i32 %427, %393
  store i32 %428, ptr %54, align 4, !tbaa !5
  store i32 %378, ptr %55, align 4, !tbaa !5
  %429 = xor i32 %378, %393
  store i32 %429, ptr %56, align 4, !tbaa !5
  %430 = xor i32 %378, %388
  store i32 %430, ptr %57, align 4, !tbaa !5
  %431 = xor i32 %430, %393
  store i32 %431, ptr %58, align 4, !tbaa !5
  %432 = xor i32 %378, %383
  store i32 %432, ptr %59, align 4, !tbaa !5
  %433 = xor i32 %432, %393
  store i32 %433, ptr %60, align 4, !tbaa !5
  %434 = xor i32 %432, %388
  store i32 %434, ptr %61, align 4, !tbaa !5
  %435 = xor i32 %434, %393
  store i32 %435, ptr %62, align 4, !tbaa !5
  store i32 0, ptr %63, align 4, !tbaa !5
  store i32 %373, ptr %64, align 4, !tbaa !5
  store i32 %368, ptr %65, align 4, !tbaa !5
  %436 = xor i32 %368, %373
  store i32 %436, ptr %66, align 4, !tbaa !5
  store i32 %363, ptr %67, align 4, !tbaa !5
  %437 = xor i32 %363, %373
  store i32 %437, ptr %68, align 4, !tbaa !5
  %438 = xor i32 %363, %368
  store i32 %438, ptr %69, align 4, !tbaa !5
  %439 = xor i32 %438, %373
  store i32 %439, ptr %70, align 4, !tbaa !5
  store i32 %358, ptr %71, align 4, !tbaa !5
  %440 = xor i32 %358, %373
  store i32 %440, ptr %72, align 4, !tbaa !5
  %441 = xor i32 %358, %368
  store i32 %441, ptr %73, align 4, !tbaa !5
  %442 = xor i32 %441, %373
  store i32 %442, ptr %74, align 4, !tbaa !5
  %443 = xor i32 %358, %363
  store i32 %443, ptr %75, align 4, !tbaa !5
  %444 = xor i32 %443, %373
  store i32 %444, ptr %76, align 4, !tbaa !5
  %445 = xor i32 %443, %368
  store i32 %445, ptr %77, align 4, !tbaa !5
  %446 = xor i32 %445, %373
  store i32 %446, ptr %78, align 4, !tbaa !5
  store i32 0, ptr %79, align 4, !tbaa !5
  store i32 %353, ptr %80, align 4, !tbaa !5
  store i32 %348, ptr %81, align 4, !tbaa !5
  %447 = xor i32 %348, %353
  store i32 %447, ptr %82, align 4, !tbaa !5
  store i32 %343, ptr %83, align 4, !tbaa !5
  %448 = xor i32 %343, %353
  store i32 %448, ptr %84, align 4, !tbaa !5
  %449 = xor i32 %343, %348
  store i32 %449, ptr %85, align 4, !tbaa !5
  %450 = xor i32 %449, %353
  store i32 %450, ptr %86, align 4, !tbaa !5
  store i32 %338, ptr %87, align 4, !tbaa !5
  %451 = xor i32 %338, %353
  store i32 %451, ptr %88, align 4, !tbaa !5
  %452 = xor i32 %338, %348
  store i32 %452, ptr %89, align 4, !tbaa !5
  %453 = xor i32 %452, %353
  store i32 %453, ptr %90, align 4, !tbaa !5
  %454 = xor i32 %338, %343
  store i32 %454, ptr %91, align 4, !tbaa !5
  %455 = xor i32 %454, %353
  store i32 %455, ptr %92, align 4, !tbaa !5
  %456 = xor i32 %454, %348
  store i32 %456, ptr %93, align 4, !tbaa !5
  %457 = xor i32 %456, %353
  store i32 %457, ptr %94, align 4, !tbaa !5
  store i32 0, ptr %95, align 4, !tbaa !5
  store i32 %333, ptr %96, align 4, !tbaa !5
  store i32 %328, ptr %97, align 4, !tbaa !5
  %458 = xor i32 %328, %333
  store i32 %458, ptr %98, align 4, !tbaa !5
  store i32 %323, ptr %99, align 4, !tbaa !5
  %459 = xor i32 %323, %333
  store i32 %459, ptr %100, align 4, !tbaa !5
  %460 = xor i32 %323, %328
  store i32 %460, ptr %101, align 4, !tbaa !5
  %461 = xor i32 %460, %333
  store i32 %461, ptr %102, align 4, !tbaa !5
  store i32 %318, ptr %103, align 4, !tbaa !5
  %462 = xor i32 %318, %333
  store i32 %462, ptr %104, align 4, !tbaa !5
  %463 = xor i32 %318, %328
  store i32 %463, ptr %105, align 4, !tbaa !5
  %464 = xor i32 %463, %333
  store i32 %464, ptr %106, align 4, !tbaa !5
  %465 = xor i32 %318, %323
  store i32 %465, ptr %107, align 4, !tbaa !5
  %466 = xor i32 %465, %333
  store i32 %466, ptr %108, align 4, !tbaa !5
  %467 = xor i32 %465, %328
  store i32 %467, ptr %109, align 4, !tbaa !5
  %468 = xor i32 %467, %333
  store i32 %468, ptr %110, align 4, !tbaa !5
  store i32 0, ptr %111, align 4, !tbaa !5
  store i32 %313, ptr %112, align 4, !tbaa !5
  store i32 %308, ptr %113, align 4, !tbaa !5
  %469 = xor i32 %308, %313
  store i32 %469, ptr %114, align 4, !tbaa !5
  store i32 %303, ptr %115, align 4, !tbaa !5
  %470 = xor i32 %303, %313
  store i32 %470, ptr %116, align 4, !tbaa !5
  %471 = xor i32 %303, %308
  store i32 %471, ptr %117, align 4, !tbaa !5
  %472 = xor i32 %471, %313
  store i32 %472, ptr %118, align 4, !tbaa !5
  store i32 %298, ptr %119, align 4, !tbaa !5
  %473 = xor i32 %298, %313
  store i32 %473, ptr %120, align 4, !tbaa !5
  %474 = xor i32 %298, %308
  store i32 %474, ptr %121, align 4, !tbaa !5
  %475 = xor i32 %474, %313
  store i32 %475, ptr %122, align 4, !tbaa !5
  %476 = xor i32 %298, %303
  store i32 %476, ptr %123, align 4, !tbaa !5
  %477 = xor i32 %476, %313
  store i32 %477, ptr %124, align 4, !tbaa !5
  %478 = xor i32 %476, %308
  store i32 %478, ptr %125, align 4, !tbaa !5
  %479 = xor i32 %478, %313
  store i32 %479, ptr %126, align 4, !tbaa !5
  store i32 0, ptr %127, align 4, !tbaa !5
  store i32 %293, ptr %128, align 4, !tbaa !5
  store i32 %288, ptr %129, align 4, !tbaa !5
  %480 = xor i32 %288, %293
  store i32 %480, ptr %130, align 4, !tbaa !5
  store i32 %283, ptr %131, align 4, !tbaa !5
  %481 = xor i32 %283, %293
  store i32 %481, ptr %132, align 4, !tbaa !5
  %482 = xor i32 %283, %288
  store i32 %482, ptr %133, align 4, !tbaa !5
  %483 = xor i32 %482, %293
  store i32 %483, ptr %134, align 4, !tbaa !5
  store i32 %278, ptr %135, align 4, !tbaa !5
  %484 = xor i32 %278, %293
  store i32 %484, ptr %136, align 4, !tbaa !5
  %485 = xor i32 %278, %288
  store i32 %485, ptr %137, align 4, !tbaa !5
  %486 = xor i32 %485, %293
  store i32 %486, ptr %138, align 4, !tbaa !5
  %487 = xor i32 %278, %283
  store i32 %487, ptr %139, align 4, !tbaa !5
  %488 = xor i32 %487, %293
  store i32 %488, ptr %140, align 4, !tbaa !5
  %489 = xor i32 %487, %288
  store i32 %489, ptr %141, align 4, !tbaa !5
  %490 = xor i32 %489, %293
  store i32 %490, ptr %142, align 4, !tbaa !5
  store i32 0, ptr %143, align 4, !tbaa !5
  store i32 %273, ptr %144, align 4, !tbaa !5
  store i32 %268, ptr %145, align 4, !tbaa !5
  %491 = xor i32 %268, %273
  store i32 %491, ptr %146, align 4, !tbaa !5
  store i32 %263, ptr %147, align 4, !tbaa !5
  %492 = xor i32 %263, %273
  store i32 %492, ptr %148, align 4, !tbaa !5
  %493 = xor i32 %263, %268
  store i32 %493, ptr %149, align 4, !tbaa !5
  %494 = xor i32 %493, %273
  store i32 %494, ptr %150, align 4, !tbaa !5
  store i32 %534, ptr %151, align 4, !tbaa !5
  %495 = xor i32 %534, %273
  store i32 %495, ptr %152, align 4, !tbaa !5
  %496 = xor i32 %534, %268
  store i32 %496, ptr %153, align 4, !tbaa !5
  %497 = xor i32 %496, %273
  store i32 %497, ptr %154, align 4, !tbaa !5
  %498 = xor i32 %534, %263
  store i32 %498, ptr %155, align 4, !tbaa !5
  %499 = xor i32 %498, %273
  store i32 %499, ptr %156, align 4, !tbaa !5
  %500 = xor i32 %498, %268
  store i32 %500, ptr %157, align 4, !tbaa !5
  %501 = xor i32 %500, %273
  store i32 %501, ptr %158, align 4, !tbaa !5
  store i32 %225, ptr %10, align 4, !tbaa !24
  br label %563

502:                                              ; preds = %253, %560
  %503 = phi i32 [ %552, %560 ], [ 8388608, %253 ]
  %504 = phi i32 [ %534, %560 ], [ -2147483648, %253 ]
  %505 = phi i32 [ %561, %560 ], [ %225, %253 ]
  %506 = and i32 %505, 1
  %507 = icmp eq i32 %506, 0
  br i1 %507, label %533, label %508

508:                                              ; preds = %502, %508
  %509 = phi i32 [ %531, %508 ], [ -2147483648, %502 ]
  %510 = phi i32 [ %525, %508 ], [ 0, %502 ]
  %511 = phi i32 [ %530, %508 ], [ %503, %502 ]
  %512 = and i32 %509, %504
  %513 = icmp eq i32 %512, 0
  %514 = select i1 %513, i32 0, i32 %511
  %515 = xor i32 %514, %510
  %516 = lshr i32 %511, 1
  %517 = and i32 %511, 1
  %518 = icmp eq i32 %517, 0
  %519 = select i1 %518, i32 0, i32 -306674912
  %520 = xor i32 %519, %516
  %521 = lshr i32 %509, 1
  %522 = and i32 %521, %504
  %523 = icmp eq i32 %522, 0
  %524 = select i1 %523, i32 0, i32 %520
  %525 = xor i32 %524, %515
  %526 = lshr i32 %520, 1
  %527 = and i32 %511, 2
  %528 = icmp eq i32 %527, 0
  %529 = select i1 %528, i32 0, i32 -306674912
  %530 = xor i32 %529, %526
  %531 = lshr i32 %509, 2
  %532 = icmp ult i32 %509, 4
  br i1 %532, label %533, label %508, !llvm.loop !30

533:                                              ; preds = %508, %502
  %534 = phi i32 [ %504, %502 ], [ %525, %508 ]
  br label %535

535:                                              ; preds = %535, %533
  %536 = phi i32 [ -2147483648, %533 ], [ %558, %535 ]
  %537 = phi i32 [ 0, %533 ], [ %552, %535 ]
  %538 = phi i32 [ %503, %533 ], [ %557, %535 ]
  %539 = and i32 %536, %503
  %540 = icmp eq i32 %539, 0
  %541 = select i1 %540, i32 0, i32 %538
  %542 = xor i32 %541, %537
  %543 = lshr i32 %538, 1
  %544 = and i32 %538, 1
  %545 = icmp eq i32 %544, 0
  %546 = select i1 %545, i32 0, i32 -306674912
  %547 = xor i32 %546, %543
  %548 = lshr i32 %536, 1
  %549 = and i32 %548, %503
  %550 = icmp eq i32 %549, 0
  %551 = select i1 %550, i32 0, i32 %547
  %552 = xor i32 %551, %542
  %553 = lshr i32 %547, 1
  %554 = and i32 %538, 2
  %555 = icmp eq i32 %554, 0
  %556 = select i1 %555, i32 0, i32 -306674912
  %557 = xor i32 %556, %553
  %558 = lshr i32 %536, 2
  %559 = icmp ult i32 %536, 4
  br i1 %559, label %560, label %535, !llvm.loop !30

560:                                              ; preds = %535
  %561 = lshr i32 %505, 1
  %562 = icmp ult i32 %505, 2
  br i1 %562, label %258, label %502, !llvm.loop !31

563:                                              ; preds = %253, %258
  %564 = phi i32 [ %225, %258 ], [ %218, %253 ]
  %565 = and i32 %235, 15
  %566 = getelementptr inbounds nuw [16 x i32], ptr %31, i32 0, i32 %565
  %567 = load i32, ptr %566, align 4, !tbaa !5
  %568 = lshr i32 %235, 4
  %569 = and i32 %568, 15
  %570 = getelementptr inbounds nuw [16 x i32], ptr %47, i32 0, i32 %569
  %571 = load i32, ptr %570, align 4, !tbaa !5
  %572 = lshr i32 %235, 8
  %573 = and i32 %572, 15
  %574 = getelementptr inbounds nuw [16 x i32], ptr %63, i32 0, i32 %573
  %575 = load i32, ptr %574, align 4, !tbaa !5
  %576 = lshr i32 %235, 12
  %577 = and i32 %576, 15
  %578 = getelementptr inbounds nuw [16 x i32], ptr %79, i32 0, i32 %577
  %579 = load i32, ptr %578, align 4, !tbaa !5
  %580 = lshr i32 %235, 16
  %581 = and i32 %580, 15
  %582 = getelementptr inbounds nuw [16 x i32], ptr %95, i32 0, i32 %581
  %583 = load i32, ptr %582, align 4, !tbaa !5
  %584 = lshr i32 %235, 20
  %585 = and i32 %584, 15
  %586 = getelementptr inbounds nuw [16 x i32], ptr %111, i32 0, i32 %585
  %587 = load i32, ptr %586, align 4, !tbaa !5
  %588 = lshr i32 %235, 24
  %589 = and i32 %588, 15
  %590 = getelementptr inbounds nuw [16 x i32], ptr %127, i32 0, i32 %589
  %591 = load i32, ptr %590, align 4, !tbaa !5
  %592 = lshr i32 %235, 28
  %593 = getelementptr inbounds nuw [16 x i32], ptr %143, i32 0, i32 %592
  %594 = load i32, ptr %593, align 4, !tbaa !5
  %595 = xor i32 %567, %571
  %596 = xor i32 %595, %575
  %597 = xor i32 %596, %579
  %598 = xor i32 %597, %583
  %599 = xor i32 %598, %587
  %600 = xor i32 %599, %591
  %601 = xor i32 %600, %594
  %602 = xor i32 %601, %256
  %603 = add i32 %225, %221
  %604 = add i32 %213, 1
  %605 = icmp eq i32 %604, %6
  br i1 %605, label %606, label %212, !llvm.loop !32

606:                                              ; preds = %563, %212, %209
  %607 = phi i32 [ %197, %209 ], [ %218, %212 ], [ %564, %563 ]
  %608 = phi i32 [ %195, %209 ], [ %217, %212 ], [ %254, %563 ]
  %609 = phi i32 [ %194, %209 ], [ %216, %212 ], [ %255, %563 ]
  %610 = phi i32 [ 0, %209 ], [ %215, %212 ], [ %602, %563 ]
  %611 = phi i32 [ %193, %209 ], [ %214, %212 ], [ %603, %563 ]
  %612 = phi i32 [ %192, %209 ], [ %213, %212 ], [ %6, %563 ]
  %613 = getelementptr inbounds nuw i8, ptr %25, i32 %611
  %614 = sub i32 %210, %611
  %615 = tail call fastcc i32 @crc32_update_gap(i32 noundef %610, ptr noundef %613, i32 noundef %614)
  %616 = getelementptr inbounds nuw i32, ptr %27, i32 %196
  %617 = load i32, ptr %616, align 4, !tbaa !5
  %618 = icmp eq i32 %615, %617
  br i1 %618, label %188, label %634

619:                                              ; preds = %188, %178
  %620 = phi i32 [ 0, %178 ], [ %608, %188 ]
  %621 = phi i32 [ 0, %178 ], [ %609, %188 ]
  %622 = phi i32 [ %180, %178 ], [ %210, %188 ]
  %623 = phi i32 [ 0, %178 ], [ %612, %188 ]
  %624 = inttoptr i32 %8 to ptr
  %625 = icmp eq i32 %622, %1
  %626 = icmp eq i32 %623, %6
  %627 = select i1 %625, i1 %626, i1 false
  br i1 %627, label %628, label %634

628:                                              ; preds = %619
  %629 = icmp eq i32 %8, 0
  br i1 %629, label %634, label %630

630:                                              ; preds = %628
  %631 = sub i32 %1, %621
  store i32 %631, ptr %624, align 4, !tbaa !5
  %632 = getelementptr inbounds nuw i8, ptr %624, i32 4
  store i32 %621, ptr %632, align 4, !tbaa !5
  %633 = getelementptr inbounds nuw i8, ptr %624, i32 8
  store i32 %620, ptr %633, align 4, !tbaa !5
  br label %634

634:                                              ; preds = %191, %606, %223, %244, %242, %182, %164, %628, %630, %619
  %635 = phi i32 [ -1, %619 ], [ 0, %630 ], [ 0, %628 ], [ -4, %182 ], [ -1, %164 ], [ -1, %242 ], [ -1, %244 ], [ -1, %223 ], [ -4, %606 ], [ -1, %191 ]
  call void @llvm.lifetime.end.p0(i64 516, ptr nonnull %10) #28
  br label %636

636:                                              ; preds = %9, %20, %634
  %637 = phi i32 [ %635, %634 ], [ -1, %20 ], [ -1, %9 ]
  ret i32 %637
}

; Function Attrs: nofree norecurse nosync nounwind memory(read, inaccessiblemem: none)
define internal fastcc i32 @crc32_update_gap(i32 noundef %0, ptr noundef readonly captures(none) %1, i32 noundef %2) unnamed_addr #9 {
  %4 = xor i32 %0, -1
  %5 = icmp ugt i32 %2, 15
  br i1 %5, label %34, label %8

6:                                                ; preds = %34
  %7 = and i32 %2, -16
  br label %8

8:                                                ; preds = %6, %3
  %9 = phi i32 [ %4, %3 ], [ %116, %6 ]
  %10 = phi i32 [ 0, %3 ], [ %7, %6 ]
  %11 = icmp ult i32 %10, %2
  br i1 %11, label %12, label %143

12:                                               ; preds = %8
  %13 = or disjoint i32 %10, 1
  %14 = and i32 %2, 1
  %15 = icmp eq i32 %14, 0
  br i1 %15, label %27, label %16

16:                                               ; preds = %12
  %17 = lshr i32 %9, 8
  %18 = or disjoint i32 %10, 1
  %19 = getelementptr inbounds nuw i8, ptr %1, i32 %10
  %20 = load i8, ptr %19, align 1, !tbaa !2
  %21 = trunc i32 %9 to i8
  %22 = xor i8 %20, %21
  %23 = zext i8 %22 to i32
  %24 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %23
  %25 = load i32, ptr %24, align 4, !tbaa !5
  %26 = xor i32 %25, %17
  br label %27

27:                                               ; preds = %16, %12
  %28 = phi i32 [ poison, %12 ], [ %26, %16 ]
  %29 = phi i32 [ %10, %12 ], [ %18, %16 ]
  %30 = phi i32 [ %9, %12 ], [ %26, %16 ]
  %31 = icmp eq i32 %2, %13
  br i1 %31, label %143, label %32

32:                                               ; preds = %27
  %33 = getelementptr i8, ptr %1, i32 1
  br label %120

34:                                               ; preds = %3, %34
  %35 = phi i32 [ %117, %34 ], [ 0, %3 ]
  %36 = phi i32 [ %116, %34 ], [ %4, %3 ]
  %37 = getelementptr inbounds nuw i8, ptr %1, i32 %35
  %38 = load i32, ptr %37, align 1
  %39 = getelementptr inbounds nuw i8, ptr %37, i32 4
  %40 = load i32, ptr %39, align 1
  %41 = getelementptr inbounds nuw i8, ptr %37, i32 8
  %42 = load i32, ptr %41, align 1
  %43 = getelementptr inbounds nuw i8, ptr %37, i32 12
  %44 = load i32, ptr %43, align 1
  %45 = xor i32 %38, %36
  %46 = and i32 %45, 255
  %47 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 15360), i32 0, i32 %46
  %48 = load i32, ptr %47, align 4, !tbaa !5
  %49 = lshr i32 %45, 8
  %50 = and i32 %49, 255
  %51 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 14336), i32 0, i32 %50
  %52 = load i32, ptr %51, align 4, !tbaa !5
  %53 = xor i32 %52, %48
  %54 = lshr i32 %45, 16
  %55 = and i32 %54, 255
  %56 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 13312), i32 0, i32 %55
  %57 = load i32, ptr %56, align 4, !tbaa !5
  %58 = xor i32 %53, %57
  %59 = lshr i32 %45, 24
  %60 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 12288), i32 0, i32 %59
  %61 = load i32, ptr %60, align 4, !tbaa !5
  %62 = xor i32 %58, %61
  %63 = and i32 %40, 255
  %64 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 11264), i32 0, i32 %63
  %65 = load i32, ptr %64, align 4, !tbaa !5
  %66 = xor i32 %62, %65
  %67 = lshr i32 %40, 8
  %68 = and i32 %67, 255
  %69 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 10240), i32 0, i32 %68
  %70 = load i32, ptr %69, align 4, !tbaa !5
  %71 = xor i32 %66, %70
  %72 = lshr i32 %40, 16
  %73 = and i32 %72, 255
  %74 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 9216), i32 0, i32 %73
  %75 = load i32, ptr %74, align 4, !tbaa !5
  %76 = xor i32 %71, %75
  %77 = lshr i32 %40, 24
  %78 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 8192), i32 0, i32 %77
  %79 = load i32, ptr %78, align 4, !tbaa !5
  %80 = xor i32 %76, %79
  %81 = and i32 %42, 255
  %82 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 7168), i32 0, i32 %81
  %83 = load i32, ptr %82, align 4, !tbaa !5
  %84 = xor i32 %80, %83
  %85 = lshr i32 %42, 8
  %86 = and i32 %85, 255
  %87 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 6144), i32 0, i32 %86
  %88 = load i32, ptr %87, align 4, !tbaa !5
  %89 = xor i32 %84, %88
  %90 = lshr i32 %42, 16
  %91 = and i32 %90, 255
  %92 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 5120), i32 0, i32 %91
  %93 = load i32, ptr %92, align 4, !tbaa !5
  %94 = xor i32 %89, %93
  %95 = lshr i32 %42, 24
  %96 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 4096), i32 0, i32 %95
  %97 = load i32, ptr %96, align 4, !tbaa !5
  %98 = xor i32 %94, %97
  %99 = and i32 %44, 255
  %100 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 3072), i32 0, i32 %99
  %101 = load i32, ptr %100, align 4, !tbaa !5
  %102 = xor i32 %98, %101
  %103 = lshr i32 %44, 8
  %104 = and i32 %103, 255
  %105 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 2048), i32 0, i32 %104
  %106 = load i32, ptr %105, align 4, !tbaa !5
  %107 = xor i32 %102, %106
  %108 = lshr i32 %44, 16
  %109 = and i32 %108, 255
  %110 = getelementptr inbounds nuw [256 x i32], ptr getelementptr inbounds nuw (i8, ptr @crc32_table, i32 1024), i32 0, i32 %109
  %111 = load i32, ptr %110, align 4, !tbaa !5
  %112 = xor i32 %107, %111
  %113 = lshr i32 %44, 24
  %114 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %113
  %115 = load i32, ptr %114, align 4, !tbaa !5
  %116 = xor i32 %112, %115
  %117 = add i32 %35, 16
  %118 = sub i32 %2, %117
  %119 = icmp ugt i32 %118, 15
  br i1 %119, label %34, label %6, !llvm.loop !33

120:                                              ; preds = %120, %32
  %121 = phi i32 [ %29, %32 ], [ %133, %120 ]
  %122 = phi i32 [ %30, %32 ], [ %141, %120 ]
  %123 = lshr i32 %122, 8
  %124 = getelementptr inbounds nuw i8, ptr %1, i32 %121
  %125 = load i8, ptr %124, align 1, !tbaa !2
  %126 = trunc i32 %122 to i8
  %127 = xor i8 %125, %126
  %128 = zext i8 %127 to i32
  %129 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %128
  %130 = load i32, ptr %129, align 4, !tbaa !5
  %131 = xor i32 %130, %123
  %132 = lshr i32 %131, 8
  %133 = add nuw i32 %121, 2
  %134 = getelementptr i8, ptr %33, i32 %121
  %135 = load i8, ptr %134, align 1, !tbaa !2
  %136 = trunc i32 %131 to i8
  %137 = xor i8 %135, %136
  %138 = zext i8 %137 to i32
  %139 = getelementptr inbounds nuw [256 x i32], ptr @crc32_table, i32 0, i32 %138
  %140 = load i32, ptr %139, align 4, !tbaa !5
  %141 = xor i32 %140, %132
  %142 = icmp eq i32 %133, %2
  br i1 %142, label %143, label %120, !llvm.loop !34

143:                                              ; preds = %27, %120, %8
  %144 = phi i32 [ %9, %8 ], [ %28, %27 ], [ %141, %120 ]
  %145 = xor i32 %144, -1
  ret i32 %145
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none)
define void @wasm_reset_heap() local_unnamed_addr #10 {
  store i32 ptrtoint (ptr @__heap_base to i32), ptr @heap_ptr, align 4, !tbaa !5
  ret void
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn
define range(i32 0, -7) i32 @wasm_alloc(i32 noundef %0) local_unnamed_addr #11 {
  %2 = load i32, ptr @heap_ptr, align 4, !tbaa !5
  %3 = icmp eq i32 %2, 0
  br i1 %3, label %4, label %5

4:                                                ; preds = %1
  store i32 ptrtoint (ptr @__heap_base to i32), ptr @heap_ptr, align 4, !tbaa !5
  br label %5

5:                                                ; preds = %4, %1
  %6 = phi i32 [ ptrtoint (ptr @__heap_base to i32), %4 ], [ %2, %1 ]
  %7 = icmp ugt i32 %0, -8
  br i1 %7, label %29, label %8

8:                                                ; preds = %5
  %9 = add nuw i32 %0, 7
  %10 = and i32 %9, -8
  %11 = add i32 %6, 7
  %12 = and i32 %11, -8
  %13 = xor i32 %10, -1
  %14 = icmp ugt i32 %12, %13
  br i1 %14, label %29, label %15

15:                                               ; preds = %8
  %16 = add i32 %12, %10
  %17 = tail call i32 @llvm.wasm.memory.size.i32(i32 0)
  %18 = lshr i32 %16, 16
  %19 = and i32 %16, 65528
  %20 = icmp ne i32 %19, 0
  %21 = zext i1 %20 to i32
  %22 = add nuw nsw i32 %18, %21
  %23 = icmp ugt i32 %22, %17
  br i1 %23, label %24, label %28

24:                                               ; preds = %15
  %25 = sub nuw nsw i32 %22, %17
  %26 = tail call i32 @llvm.wasm.memory.grow.i32(i32 0, i32 %25)
  %27 = icmp slt i32 %26, 0
  br i1 %27, label %29, label %28

28:                                               ; preds = %15, %24
  store i32 %16, ptr @heap_ptr, align 4, !tbaa !5
  br label %29

29:                                               ; preds = %8, %24, %28, %5
  %30 = phi i32 [ 0, %5 ], [ 0, %8 ], [ %12, %28 ], [ 0, %24 ]
  ret i32 %30
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none)
define i32 @wasm_get_last_parse_capacity() local_unnamed_addr #12 {
  %1 = load i32, ptr @last_parse_capacity, align 4, !tbaa !5
  ret i32 %1
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none)
define i32 @wasm_get_last_content_capacity() local_unnamed_addr #12 {
  %1 = load i32, ptr @last_content_capacity, align 4, !tbaa !5
  ret i32 %1
}

; Function Attrs: nofree nosync nounwind memory(readwrite, inaccessiblemem: read)
define i64 @project_single_glossary_image_path(i32 noundef %0, i32 noundef %1) local_unnamed_addr #13 {
  %3 = alloca %struct.GlossaryImagePath, align 4
  %4 = alloca i32, align 4
  %5 = tail call i32 @llvm.wasm.memory.size.i32(i32 0)
  %6 = zext i32 %5 to i64
  %7 = shl nuw nsw i64 %6, 16
  %8 = zext i32 %0 to i64
  %9 = zext i32 %1 to i64
  %10 = add nuw nsw i64 %9, %8
  %11 = icmp samesign ugt i64 %10, %7
  br i1 %11, label %59, label %12

12:                                               ; preds = %2
  %13 = inttoptr i32 %0 to ptr
  %14 = icmp eq i32 %1, 0
  br i1 %14, label %22, label %15

15:                                               ; preds = %12, %19
  %16 = phi i32 [ %20, %19 ], [ 0, %12 ]
  %17 = getelementptr inbounds nuw i8, ptr %13, i32 %16
  %18 = load i8, ptr %17, align 1, !tbaa !2
  switch i8 %18, label %22 [
    i8 32, label %19
    i8 13, label %19
    i8 10, label %19
    i8 9, label %19
  ]

19:                                               ; preds = %15, %15, %15, %15
  %20 = add nuw i32 %16, 1
  %21 = icmp eq i32 %20, %1
  br i1 %21, label %59, label %15, !llvm.loop !35

22:                                               ; preds = %15, %12
  %23 = phi i32 [ 0, %12 ], [ %16, %15 ]
  %24 = icmp ult i32 %23, %1
  br i1 %24, label %25, label %59

25:                                               ; preds = %22
  %26 = getelementptr inbounds nuw i8, ptr %13, i32 %23
  %27 = load i8, ptr %26, align 1, !tbaa !2
  %28 = icmp eq i8 %27, 91
  br i1 %28, label %29, label %59

29:                                               ; preds = %25
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %3) #28
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %4) #28
  %30 = call fastcc i32 @project_glossary_image_value(ptr noundef nonnull %13, i32 noundef %1, i32 noundef %23, i32 noundef 0, i32 noundef 0, ptr noundef %4, ptr noundef %3)
  %31 = icmp eq i32 %30, 0
  br i1 %31, label %57, label %32

32:                                               ; preds = %29
  %33 = load i32, ptr %4, align 4, !tbaa !5
  %34 = icmp ult i32 %33, %1
  br i1 %34, label %35, label %42

35:                                               ; preds = %32, %39
  %36 = phi i32 [ %40, %39 ], [ %33, %32 ]
  %37 = getelementptr inbounds nuw i8, ptr %13, i32 %36
  %38 = load i8, ptr %37, align 1, !tbaa !2
  switch i8 %38, label %42 [
    i8 32, label %39
    i8 13, label %39
    i8 10, label %39
    i8 9, label %39
  ]

39:                                               ; preds = %35, %35, %35, %35
  %40 = add i32 %36, 1
  %41 = icmp eq i32 %40, %1
  br i1 %41, label %42, label %35, !llvm.loop !35

42:                                               ; preds = %35, %39, %32
  %43 = phi i32 [ %33, %32 ], [ %1, %39 ], [ %36, %35 ]
  %44 = icmp ne i32 %43, %1
  %45 = load i32, ptr %3, align 4
  %46 = icmp ne i32 %45, 1
  %47 = select i1 %44, i1 true, i1 %46
  br i1 %47, label %57, label %48

48:                                               ; preds = %42
  %49 = getelementptr inbounds nuw i8, ptr %3, i32 4
  %50 = load i32, ptr %49, align 4, !tbaa !36
  %51 = zext i32 %50 to i64
  %52 = shl nuw i64 %51, 32
  %53 = getelementptr inbounds nuw i8, ptr %3, i32 8
  %54 = load i32, ptr %53, align 4, !tbaa !38
  %55 = zext i32 %54 to i64
  %56 = or disjoint i64 %52, %55
  br label %57

57:                                               ; preds = %29, %42, %48
  %58 = phi i64 [ %56, %48 ], [ 0, %42 ], [ 0, %29 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %4) #28
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %3) #28
  br label %59

59:                                               ; preds = %19, %57, %25, %22, %2
  %60 = phi i64 [ 0, %2 ], [ %58, %57 ], [ 0, %25 ], [ 0, %22 ], [ 0, %19 ]
  ret i64 %60
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(read)
declare i32 @llvm.wasm.memory.size.i32(i32) #14

; Function Attrs: nofree nosync nounwind memory(readwrite, inaccessiblemem: none)
define internal fastcc range(i32 0, 2) i32 @project_glossary_image_value(ptr noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef range(i32 0, 3) %3, i32 noundef %4, ptr noundef nonnull writeonly captures(none) %5, ptr noundef nonnull captures(none) initializes((0, 12)) %6) unnamed_addr #15 {
  %8 = alloca i32, align 4
  %9 = alloca %struct.GlossaryImagePath, align 4
  %10 = alloca %struct.GlossaryImagePath, align 4
  %11 = alloca i32, align 4
  store i32 0, ptr %6, align 4, !tbaa !5
  %12 = getelementptr inbounds nuw i8, ptr %6, i32 4
  store i32 0, ptr %12, align 4, !tbaa !5
  %13 = getelementptr inbounds nuw i8, ptr %6, i32 8
  store i32 0, ptr %13, align 4, !tbaa !5
  %14 = icmp ult i32 %2, %1
  br i1 %14, label %15, label %714

15:                                               ; preds = %7
  %16 = getelementptr inbounds nuw i8, ptr %0, i32 %2
  %17 = load i8, ptr %16, align 1, !tbaa !2
  %18 = and i8 %17, -33
  %19 = icmp eq i8 %18, 91
  br i1 %19, label %22, label %20

20:                                               ; preds = %15
  %21 = tail call fastcc i32 @parse_value_span(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %2, ptr noundef %5)
  br label %714

22:                                               ; preds = %15
  %23 = icmp ugt i32 %4, 255
  br i1 %23, label %714, label %24

24:                                               ; preds = %22
  %25 = icmp eq i8 %17, 91
  br i1 %25, label %26, label %105

26:                                               ; preds = %24
  %27 = icmp eq i32 %3, 1
  br i1 %27, label %28, label %30

28:                                               ; preds = %26
  %29 = tail call fastcc range(i32 0, 2) i32 @parse_composite_span_impl(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %2, ptr noundef nonnull %5, ptr noundef null, ptr noundef null, ptr noundef null, i32 noundef 0)
  br label %714

30:                                               ; preds = %26
  %31 = add nuw i32 %2, 1
  %32 = icmp ult i32 %31, %1
  br i1 %32, label %33, label %40

33:                                               ; preds = %30, %37
  %34 = phi i32 [ %38, %37 ], [ %31, %30 ]
  %35 = getelementptr inbounds nuw i8, ptr %0, i32 %34
  %36 = load i8, ptr %35, align 1, !tbaa !2
  switch i8 %36, label %40 [
    i8 32, label %37
    i8 13, label %37
    i8 10, label %37
    i8 9, label %37
  ]

37:                                               ; preds = %33, %33, %33, %33
  %38 = add i32 %34, 1
  %39 = icmp eq i32 %38, %1
  br i1 %39, label %49, label %33, !llvm.loop !35

40:                                               ; preds = %33, %30
  %41 = phi i32 [ %31, %30 ], [ %34, %33 ]
  %42 = icmp ult i32 %41, %1
  br i1 %42, label %43, label %49

43:                                               ; preds = %40
  %44 = getelementptr inbounds nuw i8, ptr %0, i32 %41
  %45 = load i8, ptr %44, align 1, !tbaa !2
  %46 = icmp eq i8 %45, 93
  br i1 %46, label %47, label %49

47:                                               ; preds = %43
  %48 = add nuw i32 %41, 1
  store i32 %48, ptr %5, align 4, !tbaa !5
  br label %714

49:                                               ; preds = %37, %43, %40
  %50 = phi i32 [ %41, %43 ], [ %41, %40 ], [ %1, %37 ]
  %51 = icmp eq i32 %3, 0
  %52 = select i1 %51, i32 1, i32 2
  %53 = add nuw nsw i32 %4, 1
  br label %54

54:                                               ; preds = %101, %49
  %55 = phi i32 [ %50, %49 ], [ %97, %101 ]
  %56 = icmp ult i32 %55, %1
  br i1 %56, label %57, label %714

57:                                               ; preds = %54
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %8) #28
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %9) #28
  %58 = call fastcc i32 @project_glossary_image_value(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %55, i32 noundef %52, i32 noundef %53, ptr noundef %8, ptr noundef %9)
  %59 = icmp eq i32 %58, 0
  br i1 %59, label %99, label %60

60:                                               ; preds = %57
  %61 = load i32, ptr %9, align 4, !tbaa !39
  %62 = icmp eq i32 %61, 0
  br i1 %62, label %68, label %63

63:                                               ; preds = %60
  %64 = load i32, ptr %6, align 4, !tbaa !39
  %65 = icmp eq i32 %64, 0
  br i1 %65, label %66, label %67

66:                                               ; preds = %63
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(12) %6, ptr noundef nonnull align 4 dereferenceable(12) %9, i32 12, i1 false), !tbaa.struct !40
  br label %68

67:                                               ; preds = %63
  store i32 2, ptr %6, align 4, !tbaa !39
  br label %68

68:                                               ; preds = %66, %67, %60
  %69 = load i32, ptr %8, align 4, !tbaa !5
  %70 = icmp ult i32 %69, %1
  br i1 %70, label %71, label %78

71:                                               ; preds = %68, %75
  %72 = phi i32 [ %76, %75 ], [ %69, %68 ]
  %73 = getelementptr inbounds nuw i8, ptr %0, i32 %72
  %74 = load i8, ptr %73, align 1, !tbaa !2
  switch i8 %74, label %78 [
    i8 32, label %75
    i8 13, label %75
    i8 10, label %75
    i8 9, label %75
  ]

75:                                               ; preds = %71, %71, %71, %71
  %76 = add i32 %72, 1
  %77 = icmp eq i32 %76, %1
  br i1 %77, label %99, label %71, !llvm.loop !35

78:                                               ; preds = %71, %68
  %79 = phi i32 [ %69, %68 ], [ %72, %71 ]
  %80 = icmp ult i32 %79, %1
  br i1 %80, label %81, label %99

81:                                               ; preds = %78
  %82 = getelementptr inbounds nuw i8, ptr %0, i32 %79
  %83 = load i8, ptr %82, align 1, !tbaa !2
  switch i8 %83, label %99 [
    i8 93, label %84
    i8 44, label %86
  ]

84:                                               ; preds = %81
  %85 = add nuw i32 %79, 1
  store i32 %85, ptr %5, align 4, !tbaa !5
  br label %99

86:                                               ; preds = %81
  %87 = add nuw i32 %79, 1
  %88 = icmp ult i32 %87, %1
  br i1 %88, label %89, label %96

89:                                               ; preds = %86, %93
  %90 = phi i32 [ %94, %93 ], [ %87, %86 ]
  %91 = getelementptr inbounds nuw i8, ptr %0, i32 %90
  %92 = load i8, ptr %91, align 1, !tbaa !2
  switch i8 %92, label %96 [
    i8 32, label %93
    i8 13, label %93
    i8 10, label %93
    i8 9, label %93
  ]

93:                                               ; preds = %89, %89, %89, %89
  %94 = add i32 %90, 1
  %95 = icmp eq i32 %94, %1
  br i1 %95, label %99, label %89, !llvm.loop !35

96:                                               ; preds = %89, %86
  %97 = phi i32 [ %87, %86 ], [ %90, %89 ]
  %98 = icmp ult i32 %97, %1
  br i1 %98, label %101, label %99

99:                                               ; preds = %57, %78, %81, %96, %75, %93, %84
  %100 = phi i32 [ 1, %84 ], [ 0, %93 ], [ 0, %75 ], [ 0, %96 ], [ 0, %81 ], [ 0, %78 ], [ 0, %57 ]
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %9) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %8) #28
  br label %714

101:                                              ; preds = %96
  %102 = getelementptr inbounds nuw i8, ptr %0, i32 %97
  %103 = load i8, ptr %102, align 1, !tbaa !2
  %104 = icmp eq i8 %103, 93
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %9) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %8) #28
  br i1 %104, label %714, label %54, !llvm.loop !41

105:                                              ; preds = %24
  %106 = icmp eq i32 %3, 0
  br i1 %106, label %714, label %107

107:                                              ; preds = %105
  call void @llvm.lifetime.start.p0(i64 12, ptr nonnull %10) #28
  call void @llvm.memset.p0.i32(ptr noundef nonnull align 4 dereferenceable(12) %10, i8 0, i32 12, i1 false)
  %108 = add nuw i32 %2, 1
  %109 = icmp ult i32 %108, %1
  br i1 %109, label %110, label %117

110:                                              ; preds = %107, %114
  %111 = phi i32 [ %115, %114 ], [ %108, %107 ]
  %112 = getelementptr inbounds nuw i8, ptr %0, i32 %111
  %113 = load i8, ptr %112, align 1, !tbaa !2
  switch i8 %113, label %117 [
    i8 32, label %114
    i8 13, label %114
    i8 10, label %114
    i8 9, label %114
  ]

114:                                              ; preds = %110, %110, %110, %110
  %115 = add i32 %111, 1
  %116 = icmp eq i32 %115, %1
  br i1 %116, label %126, label %110, !llvm.loop !35

117:                                              ; preds = %110, %107
  %118 = phi i32 [ %108, %107 ], [ %111, %110 ]
  %119 = icmp ult i32 %118, %1
  br i1 %119, label %120, label %126

120:                                              ; preds = %117
  %121 = getelementptr inbounds nuw i8, ptr %0, i32 %118
  %122 = load i8, ptr %121, align 1, !tbaa !2
  %123 = icmp eq i8 %122, 125
  br i1 %123, label %124, label %126

124:                                              ; preds = %120
  %125 = add nuw i32 %118, 1
  store i32 %125, ptr %5, align 4, !tbaa !5
  br label %712

126:                                              ; preds = %114, %120, %117
  %127 = phi i32 [ %118, %120 ], [ %118, %117 ], [ %1, %114 ]
  %128 = icmp eq i32 %3, 1
  %129 = add nuw nsw i32 %4, 1
  %130 = getelementptr i8, ptr %0, i32 3
  %131 = getelementptr i8, ptr %0, i32 4
  %132 = getelementptr i8, ptr %0, i32 5
  %133 = getelementptr i8, ptr %0, i32 2
  %134 = getelementptr i8, ptr %0, i32 3
  %135 = getelementptr i8, ptr %0, i32 4
  %136 = getelementptr i8, ptr %0, i32 5
  %137 = getelementptr i8, ptr %0, i32 6
  %138 = getelementptr i8, ptr %0, i32 8
  %139 = getelementptr i8, ptr %0, i32 2
  %140 = getelementptr i8, ptr %0, i32 3
  %141 = getelementptr i8, ptr %0, i32 5
  %142 = getelementptr i8, ptr %0, i32 2
  %143 = getelementptr i8, ptr %0, i32 4
  %144 = getelementptr i8, ptr %0, i32 2
  %145 = getelementptr i8, ptr %0, i32 3
  %146 = getelementptr i8, ptr %0, i32 5
  %147 = getelementptr i8, ptr %0, i32 1
  %148 = getelementptr i8, ptr %0, i32 2
  %149 = getelementptr i8, ptr %0, i32 3
  %150 = getelementptr i8, ptr %0, i32 1
  %151 = getelementptr i8, ptr %0, i32 2
  %152 = getelementptr i8, ptr %0, i32 3
  %153 = getelementptr i8, ptr %0, i32 4
  %154 = getelementptr i8, ptr %0, i32 5
  br label %155

155:                                              ; preds = %708, %126
  %156 = phi i32 [ %127, %126 ], [ %704, %708 ]
  %157 = phi i32 [ 0, %126 ], [ %455, %708 ]
  %158 = phi i32 [ 0, %126 ], [ %456, %708 ]
  %159 = phi i32 [ 0, %126 ], [ %457, %708 ]
  %160 = phi i32 [ 0, %126 ], [ %667, %708 ]
  %161 = icmp ult i32 %156, %1
  br i1 %161, label %162, label %712

162:                                              ; preds = %155
  %163 = getelementptr inbounds nuw i8, ptr %0, i32 %156
  %164 = load i8, ptr %163, align 1, !tbaa !2
  %165 = icmp eq i8 %164, 34
  %166 = add nuw i32 %156, 1
  %167 = icmp ult i32 %166, %1
  %168 = select i1 %165, i1 %167, i1 false
  br i1 %168, label %169, label %712

169:                                              ; preds = %162, %187
  %170 = phi i32 [ %188, %187 ], [ %166, %162 ]
  %171 = add i32 %170, 8
  %172 = icmp ugt i32 %171, %1
  br i1 %172, label %194, label %173

173:                                              ; preds = %169
  %174 = getelementptr inbounds nuw i8, ptr %0, i32 %170
  %175 = load i64, ptr %174, align 1
  %176 = xor i64 %175, 2459565876494606882
  %177 = add i64 %176, -72340172838076673
  %178 = and i64 %175, -9187201950435737472
  %179 = xor i64 %178, -9187201950435737472
  %180 = xor i64 %175, 6655295901103053916
  %181 = add i64 %180, -72340172838076673
  %182 = or i64 %177, %181
  %183 = add i64 %175, -2314885530818453536
  %184 = or i64 %182, %183
  %185 = and i64 %179, %184
  %186 = icmp eq i64 %185, 0
  br i1 %186, label %187, label %189

187:                                              ; preds = %173, %256
  %188 = phi i32 [ %171, %173 ], [ %257, %256 ]
  br label %169

189:                                              ; preds = %173
  %190 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %185, i1 true)
  %191 = trunc nuw nsw i64 %190 to i32
  %192 = lshr i32 %191, 3
  %193 = add i32 %192, %170
  br label %194

194:                                              ; preds = %169, %189
  %195 = phi i32 [ %193, %189 ], [ %170, %169 ]
  %196 = icmp ult i32 %195, %1
  br i1 %196, label %197, label %712

197:                                              ; preds = %194
  %198 = getelementptr inbounds nuw i8, ptr %0, i32 %195
  %199 = load i8, ptr %198, align 1, !tbaa !2
  %200 = icmp eq i8 %199, 92
  br i1 %200, label %201, label %251

201:                                              ; preds = %197
  %202 = add nuw i32 %195, 1
  %203 = icmp ult i32 %202, %1
  br i1 %203, label %204, label %712

204:                                              ; preds = %201
  %205 = getelementptr inbounds nuw i8, ptr %0, i32 %202
  %206 = load i8, ptr %205, align 1, !tbaa !2
  switch i8 %206, label %712 [
    i8 117, label %207
    i8 116, label %249
    i8 114, label %249
    i8 110, label %249
    i8 102, label %249
    i8 98, label %249
    i8 92, label %249
    i8 47, label %249
    i8 34, label %249
  ]

207:                                              ; preds = %204
  %208 = add i32 %195, 6
  %209 = icmp ugt i32 %208, %1
  br i1 %209, label %712, label %210

210:                                              ; preds = %207
  %211 = add nuw i32 %195, 2
  %212 = icmp ult i32 %211, %208
  br i1 %212, label %213, label %256

213:                                              ; preds = %210
  %214 = getelementptr inbounds nuw i8, ptr %0, i32 %211
  %215 = load i8, ptr %214, align 1, !tbaa !2
  %216 = add i8 %215, -58
  %217 = icmp ult i8 %216, -10
  %218 = and i8 %215, -33
  %219 = add i8 %218, -71
  %220 = icmp ult i8 %219, -6
  %221 = and i1 %217, %220
  br i1 %221, label %712, label %222

222:                                              ; preds = %213
  %223 = getelementptr i8, ptr %130, i32 %195
  %224 = load i8, ptr %223, align 1, !tbaa !2
  %225 = add i8 %224, -58
  %226 = icmp ult i8 %225, -10
  %227 = and i8 %224, -33
  %228 = add i8 %227, -71
  %229 = icmp ult i8 %228, -6
  %230 = and i1 %226, %229
  br i1 %230, label %712, label %231

231:                                              ; preds = %222
  %232 = getelementptr i8, ptr %131, i32 %195
  %233 = load i8, ptr %232, align 1, !tbaa !2
  %234 = add i8 %233, -58
  %235 = icmp ult i8 %234, -10
  %236 = and i8 %233, -33
  %237 = add i8 %236, -71
  %238 = icmp ult i8 %237, -6
  %239 = and i1 %235, %238
  br i1 %239, label %712, label %240

240:                                              ; preds = %231
  %241 = getelementptr i8, ptr %132, i32 %195
  %242 = load i8, ptr %241, align 1, !tbaa !2
  %243 = add i8 %242, -58
  %244 = icmp ult i8 %243, -10
  %245 = and i8 %242, -33
  %246 = add i8 %245, -71
  %247 = icmp ult i8 %246, -6
  %248 = and i1 %244, %247
  br i1 %248, label %712, label %256

249:                                              ; preds = %204, %204, %204, %204, %204, %204, %204, %204
  %250 = add nuw i32 %195, 2
  br label %256, !llvm.loop !42

251:                                              ; preds = %197
  %252 = icmp ult i8 %199, 32
  br i1 %252, label %712, label %253

253:                                              ; preds = %251
  %254 = icmp eq i8 %199, 34
  %255 = add nuw i32 %195, 1
  br i1 %254, label %259, label %256

256:                                              ; preds = %253, %240, %210, %249
  %257 = phi i32 [ %250, %249 ], [ %208, %210 ], [ %208, %240 ], [ %255, %253 ]
  %258 = icmp ult i32 %257, %1
  br i1 %258, label %187, label %712

259:                                              ; preds = %253
  %260 = icmp ugt i32 %156, %195
  br i1 %260, label %408, label %261

261:                                              ; preds = %259
  %262 = add i32 %156, 7
  %263 = sub nuw i32 %195, %156
  %264 = icmp eq i32 %195, %156
  br i1 %264, label %310, label %295

265:                                              ; preds = %301
  %266 = getelementptr i8, ptr %133, i32 %156
  %267 = load i8, ptr %266, align 1, !tbaa !2
  switch i8 %267, label %310 [
    i8 92, label %299
    i8 111, label %268
  ]

268:                                              ; preds = %265
  %269 = icmp eq i32 %263, 2
  br i1 %269, label %310, label %270

270:                                              ; preds = %268
  %271 = getelementptr i8, ptr %134, i32 %156
  %272 = load i8, ptr %271, align 1, !tbaa !2
  switch i8 %272, label %310 [
    i8 92, label %299
    i8 110, label %273
  ]

273:                                              ; preds = %270
  %274 = icmp eq i32 %263, 3
  br i1 %274, label %310, label %275

275:                                              ; preds = %273
  %276 = getelementptr i8, ptr %135, i32 %156
  %277 = load i8, ptr %276, align 1, !tbaa !2
  switch i8 %277, label %310 [
    i8 92, label %299
    i8 116, label %278
  ]

278:                                              ; preds = %275
  %279 = icmp eq i32 %263, 4
  br i1 %279, label %310, label %280

280:                                              ; preds = %278
  %281 = getelementptr i8, ptr %136, i32 %156
  %282 = load i8, ptr %281, align 1, !tbaa !2
  switch i8 %282, label %310 [
    i8 92, label %299
    i8 101, label %283
  ]

283:                                              ; preds = %280
  %284 = icmp eq i32 %263, 5
  br i1 %284, label %310, label %285

285:                                              ; preds = %283
  %286 = getelementptr i8, ptr %137, i32 %156
  %287 = load i8, ptr %286, align 1, !tbaa !2
  switch i8 %287, label %310 [
    i8 92, label %299
    i8 110, label %288
  ]

288:                                              ; preds = %285
  %289 = icmp eq i32 %263, 6
  br i1 %289, label %310, label %290

290:                                              ; preds = %288
  %291 = getelementptr inbounds nuw i8, ptr %0, i32 %262
  %292 = load i8, ptr %291, align 1, !tbaa !2
  switch i8 %292, label %310 [
    i8 92, label %299
    i8 116, label %293
  ]

293:                                              ; preds = %290
  %294 = icmp ult i32 %262, %195
  br i1 %294, label %305, label %310

295:                                              ; preds = %261
  %296 = getelementptr inbounds nuw i8, ptr %0, i32 %166
  %297 = load i8, ptr %296, align 1, !tbaa !2
  %298 = icmp eq i8 %297, 92
  br i1 %298, label %299, label %301

299:                                              ; preds = %290, %285, %280, %275, %270, %265, %295
  %300 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %156, i32 noundef %255, ptr noundef nonnull @.str, i32 noundef 7)
  br label %310

301:                                              ; preds = %295
  %302 = icmp ne i8 %297, 99
  %303 = icmp eq i32 %263, 1
  %304 = or i1 %302, %303
  br i1 %304, label %310, label %265

305:                                              ; preds = %293
  %306 = getelementptr i8, ptr %138, i32 %156
  %307 = load i8, ptr %306, align 1, !tbaa !2
  %308 = icmp eq i8 %307, 34
  %309 = zext i1 %308 to i32
  br label %310

310:                                              ; preds = %290, %285, %280, %275, %270, %265, %299, %293, %305, %288, %283, %278, %273, %268, %261, %301
  %311 = phi i32 [ 0, %293 ], [ %309, %305 ], [ %300, %299 ], [ 0, %288 ], [ 0, %283 ], [ 0, %278 ], [ 0, %273 ], [ 0, %268 ], [ 0, %261 ], [ 0, %301 ], [ 0, %265 ], [ 0, %270 ], [ 0, %275 ], [ 0, %280 ], [ 0, %285 ], [ 0, %290 ]
  %312 = add i32 %156, 4
  %313 = tail call i32 @llvm.usub.sat.i32(i32 %195, i32 %156)
  %314 = icmp ugt i32 %195, %156
  br i1 %314, label %330, label %345

315:                                              ; preds = %337
  %316 = getelementptr i8, ptr %139, i32 %156
  %317 = load i8, ptr %316, align 1, !tbaa !2
  switch i8 %317, label %345 [
    i8 92, label %334
    i8 97, label %318
  ]

318:                                              ; preds = %315
  %319 = icmp eq i32 %313, 2
  br i1 %319, label %345, label %320

320:                                              ; preds = %318
  %321 = getelementptr i8, ptr %140, i32 %156
  %322 = load i8, ptr %321, align 1, !tbaa !2
  switch i8 %322, label %345 [
    i8 92, label %334
    i8 116, label %323
  ]

323:                                              ; preds = %320
  %324 = icmp eq i32 %313, 3
  br i1 %324, label %345, label %325

325:                                              ; preds = %323
  %326 = getelementptr inbounds nuw i8, ptr %0, i32 %312
  %327 = load i8, ptr %326, align 1, !tbaa !2
  switch i8 %327, label %345 [
    i8 92, label %334
    i8 104, label %328
  ]

328:                                              ; preds = %325
  %329 = icmp ult i32 %312, %195
  br i1 %329, label %341, label %345

330:                                              ; preds = %310
  %331 = getelementptr inbounds nuw i8, ptr %0, i32 %166
  %332 = load i8, ptr %331, align 1, !tbaa !2
  %333 = icmp eq i8 %332, 92
  br i1 %333, label %334, label %337

334:                                              ; preds = %325, %320, %315, %330
  %335 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %156, i32 noundef %255, ptr noundef nonnull @.str.1, i32 noundef 4)
  %336 = icmp eq i32 %335, 0
  br label %345

337:                                              ; preds = %330
  %338 = icmp ne i8 %332, 112
  %339 = icmp eq i32 %313, 1
  %340 = or i1 %338, %339
  br i1 %340, label %345, label %315

341:                                              ; preds = %328
  %342 = getelementptr i8, ptr %141, i32 %156
  %343 = load i8, ptr %342, align 1, !tbaa !2
  %344 = icmp ne i8 %343, 34
  br label %345

345:                                              ; preds = %325, %320, %315, %310, %337, %318, %323, %334, %328, %341
  %346 = phi i1 [ true, %328 ], [ %344, %341 ], [ %336, %334 ], [ true, %323 ], [ true, %318 ], [ true, %337 ], [ true, %310 ], [ true, %315 ], [ true, %320 ], [ true, %325 ]
  %347 = tail call i32 @llvm.usub.sat.i32(i32 %195, i32 %156)
  %348 = icmp ugt i32 %195, %156
  br i1 %128, label %349, label %381

349:                                              ; preds = %345
  %350 = add i32 %156, 4
  br i1 %348, label %366, label %408

351:                                              ; preds = %372
  %352 = getelementptr i8, ptr %144, i32 %156
  %353 = load i8, ptr %352, align 1, !tbaa !2
  switch i8 %353, label %408 [
    i8 92, label %370
    i8 121, label %354
  ]

354:                                              ; preds = %351
  %355 = icmp eq i32 %347, 2
  br i1 %355, label %408, label %356

356:                                              ; preds = %354
  %357 = getelementptr i8, ptr %145, i32 %156
  %358 = load i8, ptr %357, align 1, !tbaa !2
  switch i8 %358, label %408 [
    i8 92, label %370
    i8 112, label %359
  ]

359:                                              ; preds = %356
  %360 = icmp eq i32 %347, 3
  br i1 %360, label %408, label %361

361:                                              ; preds = %359
  %362 = getelementptr inbounds nuw i8, ptr %0, i32 %350
  %363 = load i8, ptr %362, align 1, !tbaa !2
  switch i8 %363, label %408 [
    i8 92, label %370
    i8 101, label %364
  ]

364:                                              ; preds = %361
  %365 = icmp ult i32 %350, %195
  br i1 %365, label %376, label %408

366:                                              ; preds = %349
  %367 = getelementptr inbounds nuw i8, ptr %0, i32 %166
  %368 = load i8, ptr %367, align 1, !tbaa !2
  %369 = icmp eq i8 %368, 92
  br i1 %369, label %370, label %372

370:                                              ; preds = %361, %356, %351, %366
  %371 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %156, i32 noundef %255, ptr noundef nonnull @.str.2, i32 noundef 4)
  br label %408

372:                                              ; preds = %366
  %373 = icmp ne i8 %368, 116
  %374 = icmp eq i32 %347, 1
  %375 = or i1 %373, %374
  br i1 %375, label %408, label %351

376:                                              ; preds = %364
  %377 = getelementptr i8, ptr %146, i32 %156
  %378 = load i8, ptr %377, align 1, !tbaa !2
  %379 = icmp eq i8 %378, 34
  %380 = zext i1 %379 to i32
  br label %408

381:                                              ; preds = %345
  %382 = add i32 %156, 3
  br i1 %348, label %393, label %408

383:                                              ; preds = %399
  %384 = getelementptr i8, ptr %142, i32 %156
  %385 = load i8, ptr %384, align 1, !tbaa !2
  switch i8 %385, label %408 [
    i8 92, label %397
    i8 97, label %386
  ]

386:                                              ; preds = %383
  %387 = icmp eq i32 %347, 2
  br i1 %387, label %408, label %388

388:                                              ; preds = %386
  %389 = getelementptr inbounds nuw i8, ptr %0, i32 %382
  %390 = load i8, ptr %389, align 1, !tbaa !2
  switch i8 %390, label %408 [
    i8 92, label %397
    i8 103, label %391
  ]

391:                                              ; preds = %388
  %392 = icmp ult i32 %382, %195
  br i1 %392, label %403, label %408

393:                                              ; preds = %381
  %394 = getelementptr inbounds nuw i8, ptr %0, i32 %166
  %395 = load i8, ptr %394, align 1, !tbaa !2
  %396 = icmp eq i8 %395, 92
  br i1 %396, label %397, label %399

397:                                              ; preds = %388, %383, %393
  %398 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %156, i32 noundef %255, ptr noundef nonnull @.str.3, i32 noundef 3)
  br label %408

399:                                              ; preds = %393
  %400 = icmp ne i8 %395, 116
  %401 = icmp eq i32 %347, 1
  %402 = or i1 %400, %401
  br i1 %402, label %408, label %383

403:                                              ; preds = %391
  %404 = getelementptr i8, ptr %143, i32 %156
  %405 = load i8, ptr %404, align 1, !tbaa !2
  %406 = icmp eq i8 %405, 34
  %407 = zext i1 %406 to i32
  br label %408

408:                                              ; preds = %388, %383, %361, %356, %351, %259, %381, %399, %386, %349, %372, %354, %359, %397, %370, %403, %391, %376, %364
  %409 = phi i1 [ %346, %364 ], [ %346, %376 ], [ %346, %391 ], [ %346, %403 ], [ %346, %370 ], [ %346, %397 ], [ %346, %359 ], [ %346, %354 ], [ %346, %372 ], [ %346, %349 ], [ %346, %386 ], [ %346, %399 ], [ %346, %381 ], [ true, %259 ], [ %346, %351 ], [ %346, %356 ], [ %346, %361 ], [ %346, %383 ], [ %346, %388 ]
  %410 = phi i32 [ %311, %364 ], [ %311, %376 ], [ %311, %391 ], [ %311, %403 ], [ %311, %370 ], [ %311, %397 ], [ %311, %359 ], [ %311, %354 ], [ %311, %372 ], [ %311, %349 ], [ %311, %386 ], [ %311, %399 ], [ %311, %381 ], [ 0, %259 ], [ %311, %351 ], [ %311, %356 ], [ %311, %361 ], [ %311, %383 ], [ %311, %388 ]
  %411 = phi i32 [ 0, %364 ], [ %380, %376 ], [ 0, %391 ], [ %407, %403 ], [ %371, %370 ], [ %398, %397 ], [ 0, %359 ], [ 0, %354 ], [ 0, %372 ], [ 0, %349 ], [ 0, %386 ], [ 0, %399 ], [ 0, %381 ], [ 0, %259 ], [ 0, %351 ], [ 0, %356 ], [ 0, %361 ], [ 0, %383 ], [ 0, %388 ]
  %412 = icmp ult i32 %255, %1
  br i1 %412, label %413, label %420

413:                                              ; preds = %408, %417
  %414 = phi i32 [ %418, %417 ], [ %255, %408 ]
  %415 = getelementptr inbounds nuw i8, ptr %0, i32 %414
  %416 = load i8, ptr %415, align 1, !tbaa !2
  switch i8 %416, label %420 [
    i8 32, label %417
    i8 13, label %417
    i8 10, label %417
    i8 9, label %417
  ]

417:                                              ; preds = %413, %413, %413, %413
  %418 = add i32 %414, 1
  %419 = icmp eq i32 %418, %1
  br i1 %419, label %712, label %413, !llvm.loop !35

420:                                              ; preds = %413, %408
  %421 = phi i32 [ %255, %408 ], [ %414, %413 ]
  %422 = icmp ult i32 %421, %1
  br i1 %422, label %423, label %712

423:                                              ; preds = %420
  %424 = getelementptr inbounds nuw i8, ptr %0, i32 %421
  %425 = load i8, ptr %424, align 1, !tbaa !2
  %426 = icmp eq i8 %425, 58
  br i1 %426, label %427, label %712

427:                                              ; preds = %423
  %428 = add nuw i32 %421, 1
  %429 = icmp ult i32 %428, %1
  br i1 %429, label %430, label %437

430:                                              ; preds = %427, %434
  %431 = phi i32 [ %435, %434 ], [ %428, %427 ]
  %432 = getelementptr inbounds nuw i8, ptr %0, i32 %431
  %433 = load i8, ptr %432, align 1, !tbaa !2
  switch i8 %433, label %437 [
    i8 32, label %434
    i8 13, label %434
    i8 10, label %434
    i8 9, label %434
  ]

434:                                              ; preds = %430, %430, %430, %430
  %435 = add i32 %431, 1
  %436 = icmp eq i32 %435, %1
  br i1 %436, label %437, label %430, !llvm.loop !35

437:                                              ; preds = %430, %434, %427
  %438 = phi i32 [ %428, %427 ], [ %1, %434 ], [ %431, %430 ]
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %11) #28
  %439 = icmp eq i32 %410, 0
  br i1 %439, label %443, label %440

440:                                              ; preds = %437
  %441 = call fastcc i32 @project_glossary_image_value(ptr noundef %0, i32 noundef %1, i32 noundef %438, i32 noundef 2, i32 noundef %129, ptr noundef %11, ptr noundef %10)
  %442 = icmp eq i32 %441, 0
  br i1 %442, label %706, label %446

443:                                              ; preds = %437
  %444 = call fastcc i32 @parse_value_span(ptr noundef %0, i32 noundef %1, i32 noundef %438, ptr noundef %11)
  %445 = icmp eq i32 %444, 0
  br i1 %445, label %706, label %446

446:                                              ; preds = %443, %440
  br i1 %409, label %454, label %447

447:                                              ; preds = %446
  %448 = getelementptr inbounds nuw i8, ptr %0, i32 %438
  %449 = load i8, ptr %448, align 1, !tbaa !2
  %450 = icmp eq i8 %449, 34
  br i1 %450, label %451, label %454

451:                                              ; preds = %447
  %452 = load i32, ptr %11, align 4, !tbaa !5
  %453 = sub i32 %452, %438
  br label %454

454:                                              ; preds = %447, %451, %446
  %455 = phi i32 [ %453, %451 ], [ %157, %446 ], [ 0, %447 ]
  %456 = phi i32 [ %438, %451 ], [ %158, %446 ], [ 0, %447 ]
  %457 = phi i32 [ 1, %451 ], [ %159, %446 ], [ 0, %447 ]
  %458 = icmp eq i32 %411, 0
  %459 = load i32, ptr %11, align 4, !tbaa !5
  br i1 %458, label %666, label %460

460:                                              ; preds = %454
  %461 = icmp ult i32 %438, %459
  br i1 %128, label %462, label %628

462:                                              ; preds = %460
  br i1 %461, label %463, label %627

463:                                              ; preds = %462
  %464 = getelementptr inbounds nuw i8, ptr %0, i32 %438
  %465 = load i8, ptr %464, align 1, !tbaa !2
  %466 = icmp eq i8 %465, 34
  br i1 %466, label %467, label %627

467:                                              ; preds = %463
  %468 = add i32 %438, 6
  %469 = xor i32 %438, -1
  %470 = add i32 %459, %469
  %471 = icmp eq i32 %470, 0
  br i1 %471, label %507, label %492

472:                                              ; preds = %496
  %473 = getelementptr i8, ptr %151, i32 %438
  %474 = load i8, ptr %473, align 1, !tbaa !2
  switch i8 %474, label %507 [
    i8 92, label %504
    i8 109, label %475
  ]

475:                                              ; preds = %472
  %476 = icmp eq i32 %470, 2
  br i1 %476, label %507, label %477

477:                                              ; preds = %475
  %478 = getelementptr i8, ptr %152, i32 %438
  %479 = load i8, ptr %478, align 1, !tbaa !2
  switch i8 %479, label %507 [
    i8 92, label %504
    i8 97, label %480
  ]

480:                                              ; preds = %477
  %481 = icmp eq i32 %470, 3
  br i1 %481, label %507, label %482

482:                                              ; preds = %480
  %483 = getelementptr i8, ptr %153, i32 %438
  %484 = load i8, ptr %483, align 1, !tbaa !2
  switch i8 %484, label %507 [
    i8 92, label %504
    i8 103, label %485
  ]

485:                                              ; preds = %482
  %486 = icmp eq i32 %470, 4
  br i1 %486, label %507, label %487

487:                                              ; preds = %485
  %488 = getelementptr i8, ptr %154, i32 %438
  %489 = load i8, ptr %488, align 1, !tbaa !2
  switch i8 %489, label %507 [
    i8 92, label %504
    i8 101, label %490
  ]

490:                                              ; preds = %487
  %491 = icmp ult i32 %468, %459
  br i1 %491, label %500, label %507

492:                                              ; preds = %467
  %493 = getelementptr i8, ptr %150, i32 %438
  %494 = load i8, ptr %493, align 1, !tbaa !2
  %495 = icmp eq i8 %494, 92
  br i1 %495, label %504, label %496

496:                                              ; preds = %492
  %497 = icmp ne i8 %494, 105
  %498 = icmp eq i32 %470, 1
  %499 = or i1 %497, %498
  br i1 %499, label %507, label %472

500:                                              ; preds = %490
  %501 = getelementptr inbounds nuw i8, ptr %0, i32 %468
  %502 = load i8, ptr %501, align 1, !tbaa !2
  %503 = icmp eq i8 %502, 34
  br i1 %503, label %666, label %507

504:                                              ; preds = %487, %482, %477, %472, %492
  %505 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %438, i32 noundef %459, ptr noundef nonnull @.str.4, i32 noundef 5)
  %506 = icmp eq i32 %505, 0
  br i1 %506, label %507, label %666

507:                                              ; preds = %487, %482, %477, %472, %496, %467, %475, %480, %485, %500, %504, %490
  %508 = add nuw i32 %438, 1
  %509 = add i32 %438, 19
  %510 = icmp ult i32 %508, %459
  br i1 %510, label %615, label %627

511:                                              ; preds = %615
  %512 = add nuw i32 %438, 2
  %513 = icmp ult i32 %512, %459
  br i1 %513, label %514, label %627

514:                                              ; preds = %511
  %515 = getelementptr inbounds nuw i8, ptr %0, i32 %512
  %516 = load i8, ptr %515, align 1, !tbaa !2
  switch i8 %516, label %627 [
    i8 92, label %623
    i8 116, label %517
  ]

517:                                              ; preds = %514
  %518 = add nuw i32 %438, 3
  %519 = icmp ult i32 %518, %459
  br i1 %519, label %520, label %627

520:                                              ; preds = %517
  %521 = getelementptr inbounds nuw i8, ptr %0, i32 %518
  %522 = load i8, ptr %521, align 1, !tbaa !2
  switch i8 %522, label %627 [
    i8 92, label %623
    i8 114, label %523
  ]

523:                                              ; preds = %520
  %524 = add nuw i32 %438, 4
  %525 = icmp ult i32 %524, %459
  br i1 %525, label %526, label %627

526:                                              ; preds = %523
  %527 = getelementptr inbounds nuw i8, ptr %0, i32 %524
  %528 = load i8, ptr %527, align 1, !tbaa !2
  switch i8 %528, label %627 [
    i8 92, label %623
    i8 117, label %529
  ]

529:                                              ; preds = %526
  %530 = add nuw i32 %438, 5
  %531 = icmp ult i32 %530, %459
  br i1 %531, label %532, label %627

532:                                              ; preds = %529
  %533 = getelementptr inbounds nuw i8, ptr %0, i32 %530
  %534 = load i8, ptr %533, align 1, !tbaa !2
  switch i8 %534, label %627 [
    i8 92, label %623
    i8 99, label %535
  ]

535:                                              ; preds = %532
  %536 = add nuw i32 %438, 6
  %537 = icmp ult i32 %536, %459
  br i1 %537, label %538, label %627

538:                                              ; preds = %535
  %539 = getelementptr inbounds nuw i8, ptr %0, i32 %536
  %540 = load i8, ptr %539, align 1, !tbaa !2
  switch i8 %540, label %627 [
    i8 92, label %623
    i8 116, label %541
  ]

541:                                              ; preds = %538
  %542 = add nuw i32 %438, 7
  %543 = icmp ult i32 %542, %459
  br i1 %543, label %544, label %627

544:                                              ; preds = %541
  %545 = getelementptr inbounds nuw i8, ptr %0, i32 %542
  %546 = load i8, ptr %545, align 1, !tbaa !2
  switch i8 %546, label %627 [
    i8 92, label %623
    i8 117, label %547
  ]

547:                                              ; preds = %544
  %548 = add nuw i32 %438, 8
  %549 = icmp ult i32 %548, %459
  br i1 %549, label %550, label %627

550:                                              ; preds = %547
  %551 = getelementptr inbounds nuw i8, ptr %0, i32 %548
  %552 = load i8, ptr %551, align 1, !tbaa !2
  switch i8 %552, label %627 [
    i8 92, label %623
    i8 114, label %553
  ]

553:                                              ; preds = %550
  %554 = add nuw i32 %438, 9
  %555 = icmp ult i32 %554, %459
  br i1 %555, label %556, label %627

556:                                              ; preds = %553
  %557 = getelementptr inbounds nuw i8, ptr %0, i32 %554
  %558 = load i8, ptr %557, align 1, !tbaa !2
  switch i8 %558, label %627 [
    i8 92, label %623
    i8 101, label %559
  ]

559:                                              ; preds = %556
  %560 = add nuw i32 %438, 10
  %561 = icmp ult i32 %560, %459
  br i1 %561, label %562, label %627

562:                                              ; preds = %559
  %563 = getelementptr inbounds nuw i8, ptr %0, i32 %560
  %564 = load i8, ptr %563, align 1, !tbaa !2
  switch i8 %564, label %627 [
    i8 92, label %623
    i8 100, label %565
  ]

565:                                              ; preds = %562
  %566 = add nuw i32 %438, 11
  %567 = icmp ult i32 %566, %459
  br i1 %567, label %568, label %627

568:                                              ; preds = %565
  %569 = getelementptr inbounds nuw i8, ptr %0, i32 %566
  %570 = load i8, ptr %569, align 1, !tbaa !2
  switch i8 %570, label %627 [
    i8 92, label %623
    i8 45, label %571
  ]

571:                                              ; preds = %568
  %572 = add nuw i32 %438, 12
  %573 = icmp ult i32 %572, %459
  br i1 %573, label %574, label %627

574:                                              ; preds = %571
  %575 = getelementptr inbounds nuw i8, ptr %0, i32 %572
  %576 = load i8, ptr %575, align 1, !tbaa !2
  switch i8 %576, label %627 [
    i8 92, label %623
    i8 99, label %577
  ]

577:                                              ; preds = %574
  %578 = add nuw i32 %438, 13
  %579 = icmp ult i32 %578, %459
  br i1 %579, label %580, label %627

580:                                              ; preds = %577
  %581 = getelementptr inbounds nuw i8, ptr %0, i32 %578
  %582 = load i8, ptr %581, align 1, !tbaa !2
  switch i8 %582, label %627 [
    i8 92, label %623
    i8 111, label %583
  ]

583:                                              ; preds = %580
  %584 = add nuw i32 %438, 14
  %585 = icmp ult i32 %584, %459
  br i1 %585, label %586, label %627

586:                                              ; preds = %583
  %587 = getelementptr inbounds nuw i8, ptr %0, i32 %584
  %588 = load i8, ptr %587, align 1, !tbaa !2
  switch i8 %588, label %627 [
    i8 92, label %623
    i8 110, label %589
  ]

589:                                              ; preds = %586
  %590 = add nuw i32 %438, 15
  %591 = icmp ult i32 %590, %459
  br i1 %591, label %592, label %627

592:                                              ; preds = %589
  %593 = getelementptr inbounds nuw i8, ptr %0, i32 %590
  %594 = load i8, ptr %593, align 1, !tbaa !2
  switch i8 %594, label %627 [
    i8 92, label %623
    i8 116, label %595
  ]

595:                                              ; preds = %592
  %596 = add nuw i32 %438, 16
  %597 = icmp ult i32 %596, %459
  br i1 %597, label %598, label %627

598:                                              ; preds = %595
  %599 = getelementptr inbounds nuw i8, ptr %0, i32 %596
  %600 = load i8, ptr %599, align 1, !tbaa !2
  switch i8 %600, label %627 [
    i8 92, label %623
    i8 101, label %601
  ]

601:                                              ; preds = %598
  %602 = add nuw i32 %438, 17
  %603 = icmp ult i32 %602, %459
  br i1 %603, label %604, label %627

604:                                              ; preds = %601
  %605 = getelementptr inbounds nuw i8, ptr %0, i32 %602
  %606 = load i8, ptr %605, align 1, !tbaa !2
  switch i8 %606, label %627 [
    i8 92, label %623
    i8 110, label %607
  ]

607:                                              ; preds = %604
  %608 = add nuw i32 %438, 18
  %609 = icmp ult i32 %608, %459
  br i1 %609, label %610, label %627

610:                                              ; preds = %607
  %611 = getelementptr inbounds nuw i8, ptr %0, i32 %608
  %612 = load i8, ptr %611, align 1, !tbaa !2
  switch i8 %612, label %627 [
    i8 92, label %623
    i8 116, label %613
  ]

613:                                              ; preds = %610
  %614 = icmp ult i32 %509, %459
  br i1 %614, label %618, label %627

615:                                              ; preds = %507
  %616 = getelementptr inbounds nuw i8, ptr %0, i32 %508
  %617 = load i8, ptr %616, align 1, !tbaa !2
  switch i8 %617, label %627 [
    i8 92, label %623
    i8 115, label %511
  ]

618:                                              ; preds = %613
  %619 = getelementptr inbounds nuw i8, ptr %0, i32 %509
  %620 = load i8, ptr %619, align 1, !tbaa !2
  %621 = freeze i8 %620
  %622 = icmp eq i8 %621, 34
  br i1 %622, label %666, label %627

623:                                              ; preds = %615, %610, %604, %598, %592, %586, %580, %574, %568, %562, %556, %550, %544, %538, %532, %526, %520, %514
  %624 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %438, i32 noundef %459, ptr noundef nonnull @.str.5, i32 noundef 18)
  %625 = freeze i32 %624
  %626 = icmp eq i32 %625, 0
  br i1 %626, label %627, label %666

627:                                              ; preds = %615, %610, %604, %598, %592, %586, %580, %574, %568, %562, %556, %550, %544, %538, %532, %526, %520, %514, %507, %511, %517, %523, %529, %535, %541, %547, %553, %559, %565, %571, %577, %583, %589, %595, %601, %607, %618, %463, %462, %613, %623
  br label %666

628:                                              ; preds = %460
  br i1 %461, label %629, label %663

629:                                              ; preds = %628
  %630 = getelementptr inbounds nuw i8, ptr %0, i32 %438
  %631 = load i8, ptr %630, align 1, !tbaa !2
  %632 = icmp eq i8 %631, 34
  br i1 %632, label %633, label %663

633:                                              ; preds = %629
  %634 = add i32 %438, 4
  %635 = xor i32 %438, -1
  %636 = add i32 %459, %635
  %637 = icmp eq i32 %636, 0
  br i1 %637, label %663, label %648

638:                                              ; preds = %655
  %639 = getelementptr i8, ptr %148, i32 %438
  %640 = load i8, ptr %639, align 1, !tbaa !2
  switch i8 %640, label %663 [
    i8 92, label %652
    i8 109, label %641
  ]

641:                                              ; preds = %638
  %642 = icmp eq i32 %636, 2
  br i1 %642, label %663, label %643

643:                                              ; preds = %641
  %644 = getelementptr i8, ptr %149, i32 %438
  %645 = load i8, ptr %644, align 1, !tbaa !2
  switch i8 %645, label %663 [
    i8 92, label %652
    i8 103, label %646
  ]

646:                                              ; preds = %643
  %647 = icmp ult i32 %634, %459
  br i1 %647, label %659, label %663

648:                                              ; preds = %633
  %649 = getelementptr i8, ptr %147, i32 %438
  %650 = load i8, ptr %649, align 1, !tbaa !2
  %651 = icmp eq i8 %650, 92
  br i1 %651, label %652, label %655

652:                                              ; preds = %643, %638, %648
  %653 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %438, i32 noundef %459, ptr noundef nonnull @.str.6, i32 noundef 3)
  %654 = icmp ne i32 %653, 0
  br label %663

655:                                              ; preds = %648
  %656 = icmp ne i8 %650, 105
  %657 = icmp eq i32 %636, 1
  %658 = or i1 %656, %657
  br i1 %658, label %663, label %638

659:                                              ; preds = %646
  %660 = getelementptr inbounds nuw i8, ptr %0, i32 %634
  %661 = load i8, ptr %660, align 1, !tbaa !2
  %662 = icmp eq i8 %661, 34
  br label %663

663:                                              ; preds = %643, %638, %633, %655, %641, %652, %628, %629, %646, %659
  %664 = phi i1 [ false, %629 ], [ false, %628 ], [ false, %646 ], [ %662, %659 ], [ %654, %652 ], [ false, %641 ], [ false, %655 ], [ false, %633 ], [ false, %638 ], [ false, %643 ]
  %665 = zext i1 %664 to i32
  br label %666

666:                                              ; preds = %454, %618, %500, %627, %623, %504, %663
  %667 = phi i32 [ %665, %663 ], [ 1, %504 ], [ 0, %627 ], [ 2, %623 ], [ 1, %500 ], [ 2, %618 ], [ %160, %454 ]
  %668 = icmp ult i32 %459, %1
  br i1 %668, label %669, label %676

669:                                              ; preds = %666, %673
  %670 = phi i32 [ %674, %673 ], [ %459, %666 ]
  %671 = getelementptr inbounds nuw i8, ptr %0, i32 %670
  %672 = load i8, ptr %671, align 1, !tbaa !2
  switch i8 %672, label %676 [
    i8 32, label %673
    i8 13, label %673
    i8 10, label %673
    i8 9, label %673
  ]

673:                                              ; preds = %669, %669, %669, %669
  %674 = add i32 %670, 1
  %675 = icmp eq i32 %674, %1
  br i1 %675, label %706, label %669, !llvm.loop !35

676:                                              ; preds = %669, %666
  %677 = phi i32 [ %459, %666 ], [ %670, %669 ]
  %678 = icmp ult i32 %677, %1
  br i1 %678, label %679, label %706

679:                                              ; preds = %676
  %680 = getelementptr inbounds nuw i8, ptr %0, i32 %677
  %681 = load i8, ptr %680, align 1, !tbaa !2
  switch i8 %681, label %706 [
    i8 125, label %682
    i8 44, label %693
  ]

682:                                              ; preds = %679
  %683 = icmp eq i32 %667, 1
  br i1 %683, label %684, label %685

684:                                              ; preds = %682
  store i32 %457, ptr %6, align 4, !tbaa !5
  store i32 %456, ptr %12, align 4, !tbaa !5
  store i32 %455, ptr %13, align 4, !tbaa !5
  br label %691

685:                                              ; preds = %682
  %686 = icmp eq i32 %3, 2
  %687 = icmp eq i32 %667, 2
  %688 = select i1 %686, i1 true, i1 %687
  br i1 %688, label %689, label %690

689:                                              ; preds = %685
  call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 4 dereferenceable(12) %6, ptr noundef nonnull align 4 dereferenceable(12) %10, i32 12, i1 false), !tbaa.struct !40
  br label %691

690:                                              ; preds = %685
  store i32 0, ptr %6, align 4, !tbaa !5
  store i32 0, ptr %12, align 4, !tbaa !5
  store i32 0, ptr %13, align 4, !tbaa !5
  br label %691

691:                                              ; preds = %689, %690, %684
  %692 = add nuw i32 %677, 1
  store i32 %692, ptr %5, align 4, !tbaa !5
  br label %706

693:                                              ; preds = %679
  %694 = add nuw i32 %677, 1
  %695 = icmp ult i32 %694, %1
  br i1 %695, label %696, label %703

696:                                              ; preds = %693, %700
  %697 = phi i32 [ %701, %700 ], [ %694, %693 ]
  %698 = getelementptr inbounds nuw i8, ptr %0, i32 %697
  %699 = load i8, ptr %698, align 1, !tbaa !2
  switch i8 %699, label %703 [
    i8 32, label %700
    i8 13, label %700
    i8 10, label %700
    i8 9, label %700
  ]

700:                                              ; preds = %696, %696, %696, %696
  %701 = add i32 %697, 1
  %702 = icmp eq i32 %701, %1
  br i1 %702, label %706, label %696, !llvm.loop !35

703:                                              ; preds = %696, %693
  %704 = phi i32 [ %694, %693 ], [ %697, %696 ]
  %705 = icmp ult i32 %704, %1
  br i1 %705, label %708, label %706

706:                                              ; preds = %440, %443, %676, %679, %703, %673, %700, %691
  %707 = phi i32 [ 1, %691 ], [ 0, %700 ], [ 0, %673 ], [ 0, %703 ], [ 0, %679 ], [ 0, %676 ], [ 0, %443 ], [ 0, %440 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %11) #28
  br label %712

708:                                              ; preds = %703
  %709 = getelementptr inbounds nuw i8, ptr %0, i32 %704
  %710 = load i8, ptr %709, align 1, !tbaa !2
  %711 = icmp eq i8 %710, 125
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %11) #28
  br i1 %711, label %712, label %155, !llvm.loop !43

712:                                              ; preds = %162, %420, %423, %155, %708, %194, %256, %204, %251, %207, %201, %213, %222, %231, %240, %417, %706, %124
  %713 = phi i32 [ 1, %124 ], [ %707, %706 ], [ 0, %417 ], [ 0, %240 ], [ 0, %231 ], [ 0, %222 ], [ 0, %213 ], [ 0, %201 ], [ 0, %207 ], [ 0, %251 ], [ 0, %204 ], [ 0, %256 ], [ 0, %194 ], [ 0, %708 ], [ 0, %155 ], [ 0, %423 ], [ 0, %420 ], [ 0, %162 ]
  call void @llvm.lifetime.end.p0(i64 12, ptr nonnull %10) #28
  br label %714

714:                                              ; preds = %54, %101, %99, %20, %28, %712, %22, %47, %105, %7
  %715 = phi i32 [ 0, %7 ], [ %21, %20 ], [ %29, %28 ], [ %713, %712 ], [ 0, %22 ], [ 1, %47 ], [ 0, %105 ], [ %100, %99 ], [ 0, %101 ], [ 0, %54 ]
  ret i32 %715
}

; Function Attrs: nofree norecurse nosync nounwind
define i32 @parse_term_bank(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef %6) local_unnamed_addr #16 {
  %8 = icmp ne i32 %6, 0
  %9 = zext i1 %8 to i32
  %10 = tail call fastcc i32 @parse_term_bank_impl(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef 0, i32 noundef %4, i32 noundef %5, i32 noundef %9)
  ret i32 %10
}

; Function Attrs: nofree norecurse nosync nounwind
define internal fastcc i32 @parse_term_bank_impl(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef range(i32 0, 2) %4, i32 noundef %5, i32 noundef %6, i32 noundef range(i32 0, 2) %7) unnamed_addr #16 {
  %9 = alloca i32, align 4
  %10 = alloca %struct.TermBankCursor, align 4
  %11 = alloca i32, align 4
  %12 = icmp eq i32 %5, 0
  br i1 %12, label %13, label %181

13:                                               ; preds = %8
  %14 = icmp eq i32 %6, 0
  br i1 %14, label %15, label %276

15:                                               ; preds = %13
  %16 = icmp eq i32 %0, 0
  %17 = icmp eq i32 %1, 0
  %18 = or i1 %16, %17
  %19 = icmp eq i32 %2, 0
  %20 = or i1 %18, %19
  %21 = icmp eq i32 %3, 0
  %22 = or i1 %20, %21
  br i1 %22, label %276, label %23

23:                                               ; preds = %15
  %24 = inttoptr i32 %0 to ptr
  %25 = inttoptr i32 %2 to ptr
  store i32 %3, ptr @last_parse_capacity, align 4, !tbaa !5
  br label %26

26:                                               ; preds = %30, %23
  %27 = phi i32 [ %31, %30 ], [ 0, %23 ]
  %28 = getelementptr inbounds nuw i8, ptr %24, i32 %27
  %29 = load i8, ptr %28, align 1, !tbaa !2
  switch i8 %29, label %33 [
    i8 32, label %30
    i8 13, label %30
    i8 10, label %30
    i8 9, label %30
  ]

30:                                               ; preds = %26, %26, %26, %26
  %31 = add nuw i32 %27, 1
  %32 = icmp eq i32 %31, %1
  br i1 %32, label %276, label %26, !llvm.loop !35

33:                                               ; preds = %26
  %34 = icmp ult i32 %27, %1
  %35 = icmp eq i8 %29, 91
  %36 = and i1 %34, %35
  br i1 %36, label %37, label %276

37:                                               ; preds = %33
  %38 = add nuw i32 %27, 1
  %39 = icmp ult i32 %38, %1
  br i1 %39, label %40, label %47

40:                                               ; preds = %37, %44
  %41 = phi i32 [ %45, %44 ], [ %38, %37 ]
  %42 = getelementptr inbounds nuw i8, ptr %24, i32 %41
  %43 = load i8, ptr %42, align 1, !tbaa !2
  switch i8 %43, label %47 [
    i8 32, label %44
    i8 13, label %44
    i8 10, label %44
    i8 9, label %44
  ]

44:                                               ; preds = %40, %40, %40, %40
  %45 = add i32 %41, 1
  %46 = icmp eq i32 %45, %1
  br i1 %46, label %50, label %40, !llvm.loop !35

47:                                               ; preds = %40, %37
  %48 = phi i32 [ %38, %37 ], [ %41, %40 ]
  %49 = icmp ult i32 %48, %1
  br i1 %49, label %52, label %50

50:                                               ; preds = %44, %52, %47
  %51 = phi i32 [ %48, %47 ], [ %48, %52 ], [ %1, %44 ]
  br label %70

52:                                               ; preds = %47
  %53 = getelementptr inbounds nuw i8, ptr %24, i32 %48
  %54 = load i8, ptr %53, align 1, !tbaa !2
  %55 = icmp eq i8 %54, 93
  br i1 %55, label %56, label %50

56:                                               ; preds = %52
  %57 = add nuw i32 %48, 1
  %58 = icmp ult i32 %57, %1
  br i1 %58, label %59, label %66

59:                                               ; preds = %56, %63
  %60 = phi i32 [ %64, %63 ], [ %57, %56 ]
  %61 = getelementptr inbounds nuw i8, ptr %24, i32 %60
  %62 = load i8, ptr %61, align 1, !tbaa !2
  switch i8 %62, label %66 [
    i8 32, label %63
    i8 13, label %63
    i8 10, label %63
    i8 9, label %63
  ]

63:                                               ; preds = %59, %59, %59, %59
  %64 = add i32 %60, 1
  %65 = icmp eq i32 %64, %1
  br i1 %65, label %66, label %59, !llvm.loop !35

66:                                               ; preds = %63, %59, %56
  %67 = phi i32 [ %57, %56 ], [ %60, %59 ], [ %1, %63 ]
  %68 = icmp ne i32 %67, %1
  %69 = sext i1 %68 to i32
  br label %276

70:                                               ; preds = %50, %177
  %71 = phi i32 [ %127, %177 ], [ %3, %50 ]
  %72 = phi i32 [ %173, %177 ], [ %51, %50 ]
  %73 = phi i32 [ %132, %177 ], [ 0, %50 ]
  %74 = icmp ult i32 %72, %1
  br i1 %74, label %75, label %276

75:                                               ; preds = %70
  %76 = icmp ult i32 %73, %71
  br i1 %76, label %126, label %77

77:                                               ; preds = %75
  %78 = icmp ugt i32 %71, 63161282
  br i1 %78, label %276, label %79

79:                                               ; preds = %77
  %80 = lshr i32 %71, 1
  %81 = tail call i32 @llvm.umax.i32(i32 %80, i32 8192)
  %82 = sub nuw nsw i32 63161283, %81
  %83 = icmp samesign ugt i32 %71, %82
  %84 = add nuw nsw i32 %81, %71
  %85 = select i1 %83, i32 63161283, i32 %84
  %86 = mul nuw i32 %71, 68
  %87 = add nuw i32 %86, 7
  %88 = and i32 %87, -8
  %89 = mul i32 %85, 68
  %90 = xor i32 %88, -1
  %91 = icmp ugt i32 %2, %90
  br i1 %91, label %276, label %92

92:                                               ; preds = %79
  %93 = add i32 %88, %2
  %94 = load i32, ptr @heap_ptr, align 4, !tbaa !5
  %95 = icmp eq i32 %94, %93
  br i1 %95, label %96, label %276

96:                                               ; preds = %92
  %97 = sub i32 %89, %88
  %98 = add i32 %97, 7
  %99 = icmp eq i32 %93, 0
  br i1 %99, label %100, label %101

100:                                              ; preds = %96
  store i32 ptrtoint (ptr @__heap_base to i32), ptr @heap_ptr, align 4, !tbaa !5
  br label %101

101:                                              ; preds = %100, %96
  %102 = phi i32 [ ptrtoint (ptr @__heap_base to i32), %100 ], [ %93, %96 ]
  %103 = and i32 %98, -8
  %104 = add i32 %102, 7
  %105 = and i32 %104, -8
  %106 = xor i32 %103, -1
  %107 = icmp ugt i32 %105, %106
  br i1 %107, label %276, label %108

108:                                              ; preds = %101
  %109 = add i32 %105, %103
  %110 = tail call i32 @llvm.wasm.memory.size.i32(i32 0)
  %111 = lshr i32 %109, 16
  %112 = and i32 %109, 65528
  %113 = icmp ne i32 %112, 0
  %114 = zext i1 %113 to i32
  %115 = add nuw nsw i32 %111, %114
  %116 = icmp ugt i32 %115, %110
  br i1 %116, label %117, label %121

117:                                              ; preds = %108
  %118 = sub nuw nsw i32 %115, %110
  %119 = tail call i32 @llvm.wasm.memory.grow.i32(i32 0, i32 %118)
  %120 = icmp slt i32 %119, 0
  br i1 %120, label %276, label %121

121:                                              ; preds = %117, %108
  store i32 %109, ptr @heap_ptr, align 4, !tbaa !5
  %122 = icmp ne i32 %105, 0
  %123 = icmp eq i32 %105, %93
  %124 = and i1 %122, %123
  br i1 %124, label %125, label %276

125:                                              ; preds = %121
  store i32 %85, ptr @last_parse_capacity, align 4, !tbaa !5
  br label %126

126:                                              ; preds = %125, %75
  %127 = phi i32 [ %71, %75 ], [ %85, %125 ]
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9) #28
  store i32 0, ptr %9, align 4, !tbaa !5
  %128 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %25, i32 %73
  %129 = call fastcc i32 @parse_row_single_pass(ptr noundef nonnull %24, i32 noundef %1, i32 noundef %72, ptr noundef %128, i32 noundef range(i32 0, 2) %4, ptr noundef %9, ptr noundef null, i32 noundef 0, ptr noundef null, i32 noundef 0, i32 noundef range(i32 0, 2) %7, ptr noundef null)
  %130 = icmp eq i32 %129, 0
  br i1 %130, label %175, label %131

131:                                              ; preds = %126
  %132 = add i32 %73, 1
  %133 = load i32, ptr %9, align 4, !tbaa !5
  %134 = icmp ult i32 %133, %1
  br i1 %134, label %135, label %142

135:                                              ; preds = %131, %139
  %136 = phi i32 [ %140, %139 ], [ %133, %131 ]
  %137 = getelementptr inbounds nuw i8, ptr %24, i32 %136
  %138 = load i8, ptr %137, align 1, !tbaa !2
  switch i8 %138, label %142 [
    i8 32, label %139
    i8 13, label %139
    i8 10, label %139
    i8 9, label %139
  ]

139:                                              ; preds = %135, %135, %135, %135
  %140 = add i32 %136, 1
  %141 = icmp eq i32 %140, %1
  br i1 %141, label %175, label %135, !llvm.loop !35

142:                                              ; preds = %135, %131
  %143 = phi i32 [ %133, %131 ], [ %136, %135 ]
  %144 = icmp ult i32 %143, %1
  br i1 %144, label %145, label %175

145:                                              ; preds = %142
  %146 = getelementptr inbounds nuw i8, ptr %24, i32 %143
  %147 = load i8, ptr %146, align 1, !tbaa !2
  switch i8 %147, label %175 [
    i8 93, label %148
    i8 44, label %162
  ]

148:                                              ; preds = %145
  %149 = add nuw i32 %143, 1
  %150 = icmp ult i32 %149, %1
  br i1 %150, label %151, label %158

151:                                              ; preds = %148, %155
  %152 = phi i32 [ %156, %155 ], [ %149, %148 ]
  %153 = getelementptr inbounds nuw i8, ptr %24, i32 %152
  %154 = load i8, ptr %153, align 1, !tbaa !2
  switch i8 %154, label %158 [
    i8 32, label %155
    i8 13, label %155
    i8 10, label %155
    i8 9, label %155
  ]

155:                                              ; preds = %151, %151, %151, %151
  %156 = add i32 %152, 1
  %157 = icmp eq i32 %156, %1
  br i1 %157, label %158, label %151, !llvm.loop !35

158:                                              ; preds = %155, %151, %148
  %159 = phi i32 [ %149, %148 ], [ %152, %151 ], [ %1, %155 ]
  %160 = icmp eq i32 %159, %1
  %161 = select i1 %160, i32 %132, i32 -1
  br label %175

162:                                              ; preds = %145
  %163 = add nuw i32 %143, 1
  %164 = icmp ult i32 %163, %1
  br i1 %164, label %165, label %172

165:                                              ; preds = %162, %169
  %166 = phi i32 [ %170, %169 ], [ %163, %162 ]
  %167 = getelementptr inbounds nuw i8, ptr %24, i32 %166
  %168 = load i8, ptr %167, align 1, !tbaa !2
  switch i8 %168, label %172 [
    i8 32, label %169
    i8 13, label %169
    i8 10, label %169
    i8 9, label %169
  ]

169:                                              ; preds = %165, %165, %165, %165
  %170 = add i32 %166, 1
  %171 = icmp eq i32 %170, %1
  br i1 %171, label %175, label %165, !llvm.loop !35

172:                                              ; preds = %165, %162
  %173 = phi i32 [ %163, %162 ], [ %166, %165 ]
  %174 = icmp ult i32 %173, %1
  br i1 %174, label %177, label %175

175:                                              ; preds = %172, %145, %142, %126, %139, %169, %158
  %176 = phi i32 [ %161, %158 ], [ -1, %169 ], [ -1, %139 ], [ -1, %126 ], [ -1, %142 ], [ -1, %145 ], [ -1, %172 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9) #28
  br label %276

177:                                              ; preds = %172
  %178 = getelementptr inbounds nuw i8, ptr %24, i32 %173
  %179 = load i8, ptr %178, align 1, !tbaa !2
  %180 = icmp eq i8 %179, 93
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9) #28
  br i1 %180, label %276, label %70, !llvm.loop !44

181:                                              ; preds = %8
  %182 = icmp eq i32 %0, 0
  %183 = icmp eq i32 %1, 0
  %184 = or i1 %182, %183
  %185 = icmp eq i32 %2, 0
  %186 = or i1 %184, %185
  %187 = icmp eq i32 %3, 0
  %188 = or i1 %186, %187
  %189 = icmp eq i32 %6, 0
  %190 = or i1 %188, %189
  br i1 %190, label %276, label %191

191:                                              ; preds = %181
  %192 = inttoptr i32 %0 to ptr
  %193 = inttoptr i32 %2 to ptr
  store i32 %3, ptr @last_parse_capacity, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 28, ptr nonnull %10) #28
  store ptr %192, ptr %10, align 4, !tbaa !45
  %194 = getelementptr inbounds nuw i8, ptr %10, i32 4
  %195 = inttoptr i32 %5 to ptr
  store ptr %195, ptr %194, align 4, !tbaa !50
  %196 = getelementptr inbounds nuw i8, ptr %10, i32 8
  store i32 %1, ptr %196, align 4, !tbaa !51
  %197 = getelementptr inbounds nuw i8, ptr %10, i32 12
  store i32 %6, ptr %197, align 4, !tbaa !52
  %198 = getelementptr inbounds nuw i8, ptr %10, i32 16
  store i32 0, ptr %198, align 4, !tbaa !53
  %199 = getelementptr inbounds nuw i8, ptr %10, i32 20
  store i32 0, ptr %199, align 4, !tbaa !54
  %200 = getelementptr inbounds nuw i8, ptr %10, i32 24
  store i32 0, ptr %200, align 4, !tbaa !55
  %201 = call fastcc i32 @next_term_bank(ptr noundef %10)
  %202 = icmp sgt i32 %201, 0
  br i1 %202, label %203, label %269

203:                                              ; preds = %191, %264
  %204 = phi i32 [ %265, %264 ], [ 0, %191 ]
  %205 = phi i32 [ %257, %264 ], [ %3, %191 ]
  %206 = icmp ult i32 %204, %205
  br i1 %206, label %256, label %207

207:                                              ; preds = %203
  %208 = icmp ugt i32 %205, 63161282
  br i1 %208, label %274, label %209

209:                                              ; preds = %207
  %210 = lshr i32 %205, 1
  %211 = tail call i32 @llvm.umax.i32(i32 %210, i32 8192)
  %212 = sub nuw nsw i32 63161283, %211
  %213 = icmp samesign ugt i32 %205, %212
  %214 = add nuw nsw i32 %211, %205
  %215 = select i1 %213, i32 63161283, i32 %214
  %216 = mul nuw i32 %205, 68
  %217 = add nuw i32 %216, 7
  %218 = and i32 %217, -8
  %219 = mul i32 %215, 68
  %220 = xor i32 %218, -1
  %221 = icmp ugt i32 %2, %220
  br i1 %221, label %274, label %222

222:                                              ; preds = %209
  %223 = add i32 %218, %2
  %224 = load i32, ptr @heap_ptr, align 4, !tbaa !5
  %225 = icmp eq i32 %224, %223
  br i1 %225, label %226, label %274

226:                                              ; preds = %222
  %227 = sub i32 %219, %218
  %228 = add i32 %227, 7
  %229 = icmp eq i32 %223, 0
  br i1 %229, label %230, label %231

230:                                              ; preds = %226
  store i32 ptrtoint (ptr @__heap_base to i32), ptr @heap_ptr, align 4, !tbaa !5
  br label %231

231:                                              ; preds = %230, %226
  %232 = phi i32 [ ptrtoint (ptr @__heap_base to i32), %230 ], [ %223, %226 ]
  %233 = and i32 %228, -8
  %234 = add i32 %232, 7
  %235 = and i32 %234, -8
  %236 = xor i32 %233, -1
  %237 = icmp ugt i32 %235, %236
  br i1 %237, label %274, label %238

238:                                              ; preds = %231
  %239 = add i32 %235, %233
  %240 = tail call i32 @llvm.wasm.memory.size.i32(i32 0)
  %241 = lshr i32 %239, 16
  %242 = and i32 %239, 65528
  %243 = icmp ne i32 %242, 0
  %244 = zext i1 %243 to i32
  %245 = add nuw nsw i32 %241, %244
  %246 = icmp ugt i32 %245, %240
  br i1 %246, label %247, label %251

247:                                              ; preds = %238
  %248 = sub nuw nsw i32 %245, %240
  %249 = tail call i32 @llvm.wasm.memory.grow.i32(i32 0, i32 %248)
  %250 = icmp slt i32 %249, 0
  br i1 %250, label %274, label %251

251:                                              ; preds = %247, %238
  store i32 %239, ptr @heap_ptr, align 4, !tbaa !5
  %252 = icmp ne i32 %235, 0
  %253 = icmp eq i32 %235, %223
  %254 = and i1 %252, %253
  br i1 %254, label %255, label %274

255:                                              ; preds = %251
  store i32 %215, ptr @last_parse_capacity, align 4, !tbaa !5
  br label %256

256:                                              ; preds = %255, %203
  %257 = phi i32 [ %205, %203 ], [ %215, %255 ]
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %11) #28
  store i32 0, ptr %11, align 4, !tbaa !5
  %258 = load i32, ptr %199, align 4, !tbaa !54
  %259 = load i32, ptr %200, align 4, !tbaa !55
  %260 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %193, i32 %204
  %261 = call fastcc i32 @parse_row_single_pass(ptr noundef %192, i32 noundef %258, i32 noundef %259, ptr noundef %260, i32 noundef %4, ptr noundef %11, ptr noundef null, i32 noundef 0, ptr noundef null, i32 noundef 0, i32 noundef %7, ptr noundef null)
  %262 = icmp eq i32 %261, 0
  br i1 %262, label %263, label %264

263:                                              ; preds = %256
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %11) #28
  br label %274

264:                                              ; preds = %256
  %265 = add i32 %204, 1
  %266 = load i32, ptr %11, align 4, !tbaa !5
  %267 = call fastcc i32 @next_term_row(ptr noundef %10, i32 noundef %266)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %11) #28
  %268 = icmp sgt i32 %267, 0
  br i1 %268, label %203, label %269, !llvm.loop !56

269:                                              ; preds = %264, %191
  %270 = phi i32 [ %201, %191 ], [ %267, %264 ]
  %271 = phi i32 [ 0, %191 ], [ %265, %264 ]
  %272 = icmp eq i32 %270, 0
  %273 = select i1 %272, i32 %271, i32 -1
  br label %274

274:                                              ; preds = %247, %231, %251, %222, %209, %207, %263, %269
  %275 = phi i32 [ %273, %269 ], [ -1, %263 ], [ -2, %207 ], [ -2, %209 ], [ -2, %222 ], [ -2, %251 ], [ -2, %231 ], [ -2, %247 ]
  call void @llvm.lifetime.end.p0(i64 28, ptr nonnull %10) #28
  br label %276

276:                                              ; preds = %30, %177, %121, %117, %101, %92, %79, %77, %70, %175, %66, %33, %15, %181, %13, %274
  %277 = phi i32 [ %275, %274 ], [ -1, %13 ], [ -1, %181 ], [ -1, %15 ], [ %69, %66 ], [ -1, %33 ], [ %176, %175 ], [ -1, %177 ], [ -1, %70 ], [ -2, %77 ], [ -2, %79 ], [ -2, %92 ], [ -2, %121 ], [ -2, %101 ], [ -2, %117 ], [ -1, %30 ]
  ret i32 %277
}

; Function Attrs: nofree norecurse nosync nounwind
define i32 @parse_term_bank_with_media_hints(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef %6) local_unnamed_addr #16 {
  %8 = icmp ne i32 %6, 0
  %9 = zext i1 %8 to i32
  %10 = tail call fastcc i32 @parse_term_bank_impl(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef 1, i32 noundef %4, i32 noundef %5, i32 noundef %9)
  ret i32 %10
}

; Function Attrs: nofree nosync nounwind
define i32 @encode_term_content(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5) local_unnamed_addr #17 {
  %7 = tail call fastcc i32 @encode_term_content_impl(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef 1)
  ret i32 %7
}

; Function Attrs: nofree nosync nounwind
define internal fastcc i32 @encode_term_content_impl(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef range(i32 0, 2) %6) unnamed_addr #17 {
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = alloca i32, align 4
  %11 = icmp eq i32 %0, 0
  %12 = icmp eq i32 %1, 0
  %13 = or i1 %11, %12
  %14 = icmp eq i32 %3, 0
  %15 = or i1 %13, %14
  %16 = icmp eq i32 %5, 0
  %17 = or i1 %15, %16
  br i1 %17, label %280, label %18

18:                                               ; preds = %7
  %19 = inttoptr i32 %0 to ptr
  %20 = inttoptr i32 %1 to ptr
  %21 = inttoptr i32 %3 to ptr
  %22 = inttoptr i32 %5 to ptr
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %10) #28
  store i32 %4, ptr @last_content_capacity, align 4, !tbaa !5
  %23 = icmp eq i32 %2, 0
  br i1 %23, label %278, label %24

24:                                               ; preds = %18
  %25 = icmp eq i32 %6, 0
  br label %26

26:                                               ; preds = %24, %268
  %27 = phi i32 [ 0, %24 ], [ %212, %268 ]
  %28 = phi i32 [ 0, %24 ], [ %276, %268 ]
  %29 = phi i32 [ %4, %24 ], [ %48, %268 ]
  %30 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %20, i32 %28
  %31 = getelementptr inbounds nuw i8, ptr %30, i32 28
  %32 = getelementptr inbounds nuw i8, ptr %30, i32 24
  %33 = getelementptr inbounds nuw i8, ptr %30, i32 20
  %34 = getelementptr inbounds nuw i8, ptr %30, i32 16
  %35 = getelementptr inbounds nuw i8, ptr %30, i32 52
  %36 = getelementptr inbounds nuw i8, ptr %30, i32 48
  %37 = getelementptr inbounds nuw i8, ptr %30, i32 40
  %38 = getelementptr inbounds nuw i8, ptr %30, i32 60
  %39 = getelementptr inbounds nuw i8, ptr %30, i32 36
  %40 = add i32 %27, 9
  %41 = icmp ugt i32 %27, -10
  %42 = getelementptr inbounds nuw i8, ptr %21, i32 %27
  %43 = getelementptr inbounds nuw i8, ptr %21, i32 %40
  %44 = add i32 %27, 11
  %45 = icmp ugt i32 %40, -3
  %46 = getelementptr inbounds nuw i8, ptr %21, i32 %40
  br label %47

47:                                               ; preds = %267, %26
  %48 = phi i32 [ %29, %26 ], [ %229, %267 ]
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %8) #28
  store i32 0, ptr %8, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9) #28
  store i32 0, ptr %9, align 4, !tbaa !5
  %49 = icmp ugt i32 %40, %48
  %50 = or i1 %41, %49
  br i1 %50, label %221, label %51

51:                                               ; preds = %47
  tail call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(9) %42, ptr noundef nonnull align 1 dereferenceable(9) @encode_term_content_row.PREFIX_RULES, i32 9, i1 false)
  %52 = load i32, ptr %31, align 4, !tbaa !57
  %53 = icmp eq i32 %52, 0
  br i1 %53, label %80, label %54

54:                                               ; preds = %51
  %55 = load i32, ptr %32, align 4, !tbaa !58
  %56 = icmp eq i32 %52, 4
  br i1 %56, label %57, label %73

57:                                               ; preds = %54
  %58 = getelementptr inbounds nuw i8, ptr %19, i32 %55
  %59 = load i8, ptr %58, align 1, !tbaa !2
  %60 = icmp eq i8 %59, 110
  br i1 %60, label %61, label %73

61:                                               ; preds = %57
  %62 = getelementptr i8, ptr %58, i32 1
  %63 = load i8, ptr %62, align 1, !tbaa !2
  %64 = icmp eq i8 %63, 117
  br i1 %64, label %65, label %73

65:                                               ; preds = %61
  %66 = getelementptr i8, ptr %58, i32 2
  %67 = load i8, ptr %66, align 1, !tbaa !2
  %68 = icmp eq i8 %67, 108
  br i1 %68, label %69, label %73

69:                                               ; preds = %65
  %70 = getelementptr i8, ptr %58, i32 3
  %71 = load i8, ptr %70, align 1, !tbaa !2
  %72 = icmp eq i8 %71, 108
  br i1 %72, label %80, label %73

73:                                               ; preds = %69, %65, %61, %57, %54
  %74 = add i32 %52, %40
  %75 = icmp ult i32 %74, %40
  %76 = icmp ugt i32 %74, %48
  %77 = or i1 %75, %76
  br i1 %77, label %221, label %78

78:                                               ; preds = %73
  %79 = getelementptr inbounds nuw i8, ptr %19, i32 %55
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %43, ptr readonly align 1 %79, i32 %52, i1 false)
  br label %84

80:                                               ; preds = %69, %51
  %81 = icmp ugt i32 %44, %48
  %82 = or i1 %45, %81
  br i1 %82, label %221, label %83

83:                                               ; preds = %80
  store i16 8738, ptr %46, align 1
  br label %84

84:                                               ; preds = %83, %78
  %85 = phi i32 [ %74, %78 ], [ %44, %83 ]
  %86 = add i32 %85, 18
  %87 = icmp ugt i32 %85, -19
  %88 = icmp ugt i32 %86, %48
  %89 = or i1 %87, %88
  br i1 %89, label %221, label %90

90:                                               ; preds = %84
  %91 = getelementptr inbounds nuw i8, ptr %21, i32 %85
  tail call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(18) %91, ptr noundef nonnull align 16 dereferenceable(18) @encode_term_content_row.PREFIX_DEFINITION_TAGS, i32 18, i1 false)
  %92 = load i32, ptr %33, align 4, !tbaa !59
  %93 = icmp eq i32 %92, 0
  br i1 %93, label %121, label %94

94:                                               ; preds = %90
  %95 = load i32, ptr %34, align 4, !tbaa !60
  %96 = icmp eq i32 %92, 4
  br i1 %96, label %97, label %113

97:                                               ; preds = %94
  %98 = getelementptr inbounds nuw i8, ptr %19, i32 %95
  %99 = load i8, ptr %98, align 1, !tbaa !2
  %100 = icmp eq i8 %99, 110
  br i1 %100, label %101, label %113

101:                                              ; preds = %97
  %102 = getelementptr i8, ptr %98, i32 1
  %103 = load i8, ptr %102, align 1, !tbaa !2
  %104 = icmp eq i8 %103, 117
  br i1 %104, label %105, label %113

105:                                              ; preds = %101
  %106 = getelementptr i8, ptr %98, i32 2
  %107 = load i8, ptr %106, align 1, !tbaa !2
  %108 = icmp eq i8 %107, 108
  br i1 %108, label %109, label %113

109:                                              ; preds = %105
  %110 = getelementptr i8, ptr %98, i32 3
  %111 = load i8, ptr %110, align 1, !tbaa !2
  %112 = icmp eq i8 %111, 108
  br i1 %112, label %121, label %113

113:                                              ; preds = %109, %105, %101, %97, %94
  %114 = add i32 %92, %86
  %115 = icmp ult i32 %114, %86
  %116 = icmp ugt i32 %114, %48
  %117 = or i1 %115, %116
  br i1 %117, label %221, label %118

118:                                              ; preds = %113
  %119 = getelementptr inbounds nuw i8, ptr %19, i32 %95
  %120 = getelementptr inbounds nuw i8, ptr %21, i32 %86
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %120, ptr readonly align 1 %119, i32 %92, i1 false)
  br label %128

121:                                              ; preds = %109, %90
  %122 = add i32 %85, 20
  %123 = icmp ugt i32 %86, -3
  %124 = icmp ugt i32 %122, %48
  %125 = or i1 %123, %124
  br i1 %125, label %221, label %126

126:                                              ; preds = %121
  %127 = getelementptr inbounds nuw i8, ptr %21, i32 %86
  store i16 8738, ptr %127, align 1
  br label %128

128:                                              ; preds = %126, %118
  %129 = phi i32 [ %114, %118 ], [ %122, %126 ]
  %130 = add i32 %129, 12
  %131 = icmp ugt i32 %129, -13
  %132 = icmp ugt i32 %130, %48
  %133 = or i1 %131, %132
  br i1 %133, label %221, label %134

134:                                              ; preds = %128
  %135 = getelementptr inbounds nuw i8, ptr %21, i32 %129
  tail call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(12) %135, ptr noundef nonnull align 1 dereferenceable(12) @encode_term_content_row.PREFIX_TERM_TAGS, i32 12, i1 false)
  %136 = load i32, ptr %35, align 4, !tbaa !61
  %137 = icmp eq i32 %136, 0
  br i1 %137, label %165, label %138

138:                                              ; preds = %134
  %139 = load i32, ptr %36, align 4, !tbaa !62
  %140 = icmp eq i32 %136, 4
  br i1 %140, label %141, label %157

141:                                              ; preds = %138
  %142 = getelementptr inbounds nuw i8, ptr %19, i32 %139
  %143 = load i8, ptr %142, align 1, !tbaa !2
  %144 = icmp eq i8 %143, 110
  br i1 %144, label %145, label %157

145:                                              ; preds = %141
  %146 = getelementptr i8, ptr %142, i32 1
  %147 = load i8, ptr %146, align 1, !tbaa !2
  %148 = icmp eq i8 %147, 117
  br i1 %148, label %149, label %157

149:                                              ; preds = %145
  %150 = getelementptr i8, ptr %142, i32 2
  %151 = load i8, ptr %150, align 1, !tbaa !2
  %152 = icmp eq i8 %151, 108
  br i1 %152, label %153, label %157

153:                                              ; preds = %149
  %154 = getelementptr i8, ptr %142, i32 3
  %155 = load i8, ptr %154, align 1, !tbaa !2
  %156 = icmp eq i8 %155, 108
  br i1 %156, label %165, label %157

157:                                              ; preds = %153, %149, %145, %141, %138
  %158 = add i32 %136, %130
  %159 = icmp ult i32 %158, %130
  %160 = icmp ugt i32 %158, %48
  %161 = or i1 %159, %160
  br i1 %161, label %221, label %162

162:                                              ; preds = %157
  %163 = getelementptr inbounds nuw i8, ptr %19, i32 %139
  %164 = getelementptr inbounds nuw i8, ptr %21, i32 %130
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %164, ptr readonly align 1 %163, i32 %136, i1 false)
  br label %172

165:                                              ; preds = %153, %134
  %166 = add i32 %129, 14
  %167 = icmp ugt i32 %130, -3
  %168 = icmp ugt i32 %166, %48
  %169 = or i1 %167, %168
  br i1 %169, label %221, label %170

170:                                              ; preds = %165
  %171 = getelementptr inbounds nuw i8, ptr %21, i32 %130
  store i16 8738, ptr %171, align 1
  br label %172

172:                                              ; preds = %170, %162
  %173 = phi i32 [ %158, %162 ], [ %166, %170 ]
  %174 = add i32 %173, 12
  %175 = icmp ugt i32 %173, -13
  %176 = icmp ugt i32 %174, %48
  %177 = or i1 %175, %176
  br i1 %177, label %221, label %178

178:                                              ; preds = %172
  %179 = getelementptr inbounds nuw i8, ptr %21, i32 %173
  tail call void @llvm.memcpy.p0.p0.i32(ptr noundef nonnull align 1 dereferenceable(12) %179, ptr noundef nonnull align 1 dereferenceable(12) @encode_term_content_row.PREFIX_GLOSSARY, i32 12, i1 false)
  store i32 %174, ptr %10, align 4, !tbaa !5
  %180 = load i32, ptr %37, align 4, !tbaa !29
  %181 = icmp eq i32 %180, 0
  br i1 %181, label %201, label %182

182:                                              ; preds = %178
  %183 = load i32, ptr %38, align 4, !tbaa !63
  %184 = icmp eq i32 %183, 0
  br i1 %184, label %185, label %194

185:                                              ; preds = %182
  %186 = add i32 %180, %174
  %187 = icmp ult i32 %186, %174
  %188 = icmp ugt i32 %186, %48
  %189 = or i1 %187, %188
  br i1 %189, label %221, label %190

190:                                              ; preds = %185
  %191 = load i32, ptr %39, align 4, !tbaa !27
  %192 = getelementptr inbounds nuw i8, ptr %19, i32 %191
  %193 = getelementptr inbounds nuw i8, ptr %21, i32 %174
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %193, ptr readonly align 1 %192, i32 %180, i1 false)
  br label %208

194:                                              ; preds = %182
  %195 = load i32, ptr %39, align 4, !tbaa !27
  %196 = add i32 %195, %180
  %197 = call fastcc i32 @write_normalized_glossary_value(ptr noundef %19, i32 noundef %196, i32 noundef %195, i32 noundef %196, ptr noundef nonnull %21, i32 noundef %48, ptr noundef nonnull %10)
  %198 = icmp eq i32 %197, 0
  br i1 %198, label %221, label %199

199:                                              ; preds = %194
  %200 = load i32, ptr %10, align 4, !tbaa !5
  br label %208

201:                                              ; preds = %178
  %202 = add i32 %173, 14
  %203 = icmp ugt i32 %174, -3
  %204 = icmp ugt i32 %202, %48
  %205 = or i1 %203, %204
  br i1 %205, label %221, label %206

206:                                              ; preds = %201
  %207 = getelementptr inbounds nuw i8, ptr %21, i32 %174
  store i16 23899, ptr %207, align 1
  br label %208

208:                                              ; preds = %206, %199, %190
  %209 = phi i32 [ %200, %199 ], [ %202, %206 ], [ %186, %190 ]
  %210 = icmp ult i32 %209, %48
  br i1 %210, label %211, label %221

211:                                              ; preds = %208
  %212 = add nuw i32 %209, 1
  %213 = getelementptr inbounds nuw i8, ptr %21, i32 %209
  store i8 125, ptr %213, align 1
  store i32 %212, ptr %10, align 4, !tbaa !5
  %214 = sub i32 %212, %27
  br i1 %25, label %268, label %215

215:                                              ; preds = %211
  call fastcc void @hash_content_xxh32_pair(ptr noundef nonnull %42, i32 noundef %214, ptr noundef %8, ptr noundef %9)
  %216 = load i32, ptr %8, align 4, !tbaa !5
  %217 = load i32, ptr %9, align 4, !tbaa !5
  %218 = or i32 %217, %216
  %219 = icmp eq i32 %218, 0
  %220 = select i1 %219, i32 1, i32 %216
  br label %268

221:                                              ; preds = %194, %47, %73, %80, %84, %113, %121, %128, %157, %165, %172, %185, %201, %208
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %8) #28
  store i32 %27, ptr %10, align 4, !tbaa !5
  %222 = icmp ugt i32 %48, 2147483646
  br i1 %222, label %278, label %223

223:                                              ; preds = %221
  %224 = lshr i32 %48, 1
  %225 = tail call i32 @llvm.umax.i32(i32 %224, i32 1048576)
  %226 = xor i32 %225, 2147483647
  %227 = icmp samesign ugt i32 %48, %226
  %228 = add nuw i32 %225, %48
  %229 = select i1 %227, i32 2147483647, i32 %228
  %230 = add nuw i32 %48, 7
  %231 = and i32 %230, -8
  %232 = xor i32 %231, -1
  %233 = icmp ugt i32 %3, %232
  br i1 %233, label %278, label %234

234:                                              ; preds = %223
  %235 = add i32 %231, %3
  %236 = load i32, ptr @heap_ptr, align 4, !tbaa !5
  %237 = icmp eq i32 %236, %235
  br i1 %237, label %238, label %278

238:                                              ; preds = %234
  %239 = sub i32 %229, %231
  %240 = add i32 %239, 7
  %241 = icmp eq i32 %235, 0
  br i1 %241, label %242, label %243

242:                                              ; preds = %238
  store i32 ptrtoint (ptr @__heap_base to i32), ptr @heap_ptr, align 4, !tbaa !5
  br label %243

243:                                              ; preds = %242, %238
  %244 = phi i32 [ ptrtoint (ptr @__heap_base to i32), %242 ], [ %235, %238 ]
  %245 = and i32 %240, -8
  %246 = add i32 %244, 7
  %247 = and i32 %246, -8
  %248 = xor i32 %245, -1
  %249 = icmp ugt i32 %247, %248
  br i1 %249, label %278, label %250

250:                                              ; preds = %243
  %251 = add i32 %247, %245
  %252 = tail call i32 @llvm.wasm.memory.size.i32(i32 0)
  %253 = lshr i32 %251, 16
  %254 = and i32 %251, 65528
  %255 = icmp ne i32 %254, 0
  %256 = zext i1 %255 to i32
  %257 = add nuw nsw i32 %253, %256
  %258 = icmp ugt i32 %257, %252
  br i1 %258, label %259, label %263

259:                                              ; preds = %250
  %260 = sub nuw nsw i32 %257, %252
  %261 = tail call i32 @llvm.wasm.memory.grow.i32(i32 0, i32 %260)
  %262 = icmp slt i32 %261, 0
  br i1 %262, label %278, label %263

263:                                              ; preds = %259, %250
  store i32 %251, ptr @heap_ptr, align 4, !tbaa !5
  %264 = icmp ne i32 %247, 0
  %265 = icmp eq i32 %247, %235
  %266 = and i1 %264, %265
  br i1 %266, label %267, label %278

267:                                              ; preds = %263
  store i32 %229, ptr @last_content_capacity, align 4, !tbaa !5
  br label %47, !llvm.loop !64

268:                                              ; preds = %211, %215
  %269 = phi i32 [ %220, %215 ], [ 0, %211 ]
  %270 = phi i32 [ %217, %215 ], [ 0, %211 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %8) #28
  %271 = shl i32 %28, 4
  %272 = getelementptr inbounds nuw i8, ptr %22, i32 %271
  store i32 %27, ptr %272, align 4, !tbaa !5
  %273 = getelementptr inbounds nuw i8, ptr %272, i32 4
  store i32 %214, ptr %273, align 4, !tbaa !5
  %274 = getelementptr inbounds nuw i8, ptr %272, i32 8
  store i32 %269, ptr %274, align 4, !tbaa !5
  %275 = getelementptr inbounds nuw i8, ptr %272, i32 12
  store i32 %270, ptr %275, align 4, !tbaa !5
  %276 = add nuw i32 %28, 1
  %277 = icmp eq i32 %276, %2
  br i1 %277, label %278, label %26, !llvm.loop !65

278:                                              ; preds = %268, %221, %223, %234, %263, %243, %259, %18
  %279 = phi i32 [ 0, %18 ], [ -2, %259 ], [ -2, %243 ], [ -2, %263 ], [ -2, %234 ], [ -2, %223 ], [ -2, %221 ], [ %212, %268 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10) #28
  br label %280

280:                                              ; preds = %7, %278
  %281 = phi i32 [ %279, %278 ], [ -1, %7 ]
  ret i32 %281
}

; Function Attrs: nofree nosync nounwind
define i32 @encode_term_content_no_hash(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5) local_unnamed_addr #17 {
  %7 = tail call fastcc i32 @encode_term_content_impl(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef 0)
  ret i32 %7
}

; Function Attrs: nofree nosync nounwind
define i32 @encode_term_content_token_binary(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5) local_unnamed_addr #17 {
  %7 = alloca i32, align 4
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = icmp eq i32 %0, 0
  %11 = icmp eq i32 %1, 0
  %12 = or i1 %10, %11
  %13 = icmp eq i32 %3, 0
  %14 = or i1 %12, %13
  %15 = icmp eq i32 %5, 0
  %16 = or i1 %14, %15
  br i1 %16, label %96, label %17

17:                                               ; preds = %6
  %18 = inttoptr i32 %0 to ptr
  %19 = inttoptr i32 %1 to ptr
  %20 = inttoptr i32 %3 to ptr
  %21 = inttoptr i32 %5 to ptr
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %7) #28
  store i32 0, ptr %7, align 4, !tbaa !5
  store i32 %4, ptr @last_content_capacity, align 4, !tbaa !5
  %22 = icmp eq i32 %2, 0
  br i1 %22, label %94, label %23

23:                                               ; preds = %17, %81
  %24 = phi i32 [ %85, %81 ], [ 0, %17 ]
  %25 = phi i32 [ %92, %81 ], [ 0, %17 ]
  %26 = phi i32 [ %82, %81 ], [ %4, %17 ]
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %8) #28
  store i32 0, ptr %8, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9) #28
  store i32 0, ptr %9, align 4, !tbaa !5
  %27 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %19, i32 %25
  %28 = call fastcc i32 @encode_term_content_token_binary_row(ptr noundef %18, ptr noundef %27, ptr noundef %20, i32 noundef %26, ptr noundef %7, ptr noundef %8, ptr noundef %9, i32 noundef 0, ptr noundef null)
  %29 = icmp eq i32 %28, 0
  br i1 %29, label %30, label %81

30:                                               ; preds = %23, %78
  %31 = phi i32 [ %39, %78 ], [ %26, %23 ]
  store i32 %24, ptr %7, align 4, !tbaa !5
  %32 = icmp ugt i32 %31, 2147483646
  br i1 %32, label %77, label %33

33:                                               ; preds = %30
  %34 = lshr i32 %31, 1
  %35 = tail call i32 @llvm.umax.i32(i32 %34, i32 1048576)
  %36 = xor i32 %35, 2147483647
  %37 = icmp samesign ugt i32 %31, %36
  %38 = add nuw i32 %35, %31
  %39 = select i1 %37, i32 2147483647, i32 %38
  %40 = add nuw i32 %31, 7
  %41 = and i32 %40, -8
  %42 = xor i32 %41, -1
  %43 = icmp ugt i32 %3, %42
  br i1 %43, label %77, label %44

44:                                               ; preds = %33
  %45 = add i32 %41, %3
  %46 = load i32, ptr @heap_ptr, align 4, !tbaa !5
  %47 = icmp eq i32 %46, %45
  br i1 %47, label %48, label %77

48:                                               ; preds = %44
  %49 = sub i32 %39, %41
  %50 = add i32 %49, 7
  %51 = icmp eq i32 %45, 0
  br i1 %51, label %52, label %53

52:                                               ; preds = %48
  store i32 ptrtoint (ptr @__heap_base to i32), ptr @heap_ptr, align 4, !tbaa !5
  br label %53

53:                                               ; preds = %52, %48
  %54 = phi i32 [ ptrtoint (ptr @__heap_base to i32), %52 ], [ %45, %48 ]
  %55 = and i32 %50, -8
  %56 = add i32 %54, 7
  %57 = and i32 %56, -8
  %58 = xor i32 %55, -1
  %59 = icmp ugt i32 %57, %58
  br i1 %59, label %77, label %60

60:                                               ; preds = %53
  %61 = add i32 %57, %55
  %62 = tail call i32 @llvm.wasm.memory.size.i32(i32 0)
  %63 = lshr i32 %61, 16
  %64 = and i32 %61, 65528
  %65 = icmp ne i32 %64, 0
  %66 = zext i1 %65 to i32
  %67 = add nuw nsw i32 %63, %66
  %68 = icmp ugt i32 %67, %62
  br i1 %68, label %69, label %73

69:                                               ; preds = %60
  %70 = sub nuw nsw i32 %67, %62
  %71 = tail call i32 @llvm.wasm.memory.grow.i32(i32 0, i32 %70)
  %72 = icmp slt i32 %71, 0
  br i1 %72, label %77, label %73

73:                                               ; preds = %69, %60
  store i32 %61, ptr @heap_ptr, align 4, !tbaa !5
  %74 = icmp ne i32 %57, 0
  %75 = icmp eq i32 %57, %45
  %76 = and i1 %74, %75
  br i1 %76, label %78, label %77

77:                                               ; preds = %69, %53, %73, %44, %33, %30
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %8) #28
  br label %94

78:                                               ; preds = %73
  store i32 %39, ptr @last_content_capacity, align 4, !tbaa !5
  %79 = call fastcc i32 @encode_term_content_token_binary_row(ptr noundef %18, ptr noundef %27, ptr noundef %20, i32 noundef %39, ptr noundef %7, ptr noundef %8, ptr noundef %9, i32 noundef 0, ptr noundef null)
  %80 = icmp eq i32 %79, 0
  br i1 %80, label %30, label %81, !llvm.loop !66

81:                                               ; preds = %78, %23
  %82 = phi i32 [ %26, %23 ], [ %39, %78 ]
  %83 = shl i32 %25, 4
  %84 = getelementptr inbounds nuw i8, ptr %21, i32 %83
  store i32 %24, ptr %84, align 4, !tbaa !5
  %85 = load i32, ptr %7, align 4, !tbaa !5
  %86 = sub i32 %85, %24
  %87 = getelementptr inbounds nuw i8, ptr %84, i32 4
  store i32 %86, ptr %87, align 4, !tbaa !5
  %88 = load i32, ptr %8, align 4, !tbaa !5
  %89 = getelementptr inbounds nuw i8, ptr %84, i32 8
  store i32 %88, ptr %89, align 4, !tbaa !5
  %90 = load i32, ptr %9, align 4, !tbaa !5
  %91 = getelementptr inbounds nuw i8, ptr %84, i32 12
  store i32 %90, ptr %91, align 4, !tbaa !5
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %8) #28
  %92 = add nuw i32 %25, 1
  %93 = icmp eq i32 %92, %2
  br i1 %93, label %94, label %23, !llvm.loop !67

94:                                               ; preds = %81, %17, %77
  %95 = phi i32 [ -2, %77 ], [ 0, %17 ], [ %85, %81 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %7) #28
  br label %96

96:                                               ; preds = %6, %94
  %97 = phi i32 [ %95, %94 ], [ -1, %6 ]
  ret i32 %97
}

; Function Attrs: nofree nosync nounwind memory(readwrite, inaccessiblemem: none)
define internal fastcc range(i32 0, 2) i32 @encode_term_content_token_binary_row(ptr noundef %0, ptr noundef readonly captures(none) %1, ptr noundef captures(address) %2, i32 noundef %3, ptr noundef nonnull captures(none) %4, ptr noundef nonnull writeonly captures(none) %5, ptr noundef nonnull writeonly captures(none) %6, i32 noundef %7, ptr noundef captures(address_is_null) %8) unnamed_addr #15 {
  %10 = alloca i32, align 4
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = load i32, ptr %4, align 4, !tbaa !5
  %15 = add i32 %14, 4
  %16 = icmp ugt i32 %14, -5
  %17 = icmp ugt i32 %15, %3
  %18 = or i1 %16, %17
  br i1 %18, label %646, label %19

19:                                               ; preds = %9
  %20 = getelementptr inbounds nuw i8, ptr %2, i32 %14
  store i32 911360589, ptr %20, align 1
  store i32 %15, ptr %4, align 4, !tbaa !5
  %21 = getelementptr inbounds nuw i8, ptr %1, i32 24
  %22 = load i32, ptr %21, align 4, !tbaa !58
  %23 = getelementptr inbounds nuw i8, ptr %1, i32 16
  %24 = load i32, ptr %23, align 4, !tbaa !60
  %25 = getelementptr inbounds nuw i8, ptr %1, i32 48
  %26 = load i32, ptr %25, align 4, !tbaa !62
  %27 = getelementptr inbounds nuw i8, ptr %1, i32 28
  %28 = load i32, ptr %27, align 4, !tbaa !57
  %29 = getelementptr inbounds nuw i8, ptr %1, i32 20
  %30 = load i32, ptr %29, align 4, !tbaa !59
  %31 = getelementptr inbounds nuw i8, ptr %1, i32 52
  %32 = load i32, ptr %31, align 4, !tbaa !61
  switch i32 %28, label %49 [
    i32 0, label %57
    i32 4, label %33
  ]

33:                                               ; preds = %19
  %34 = getelementptr inbounds nuw i8, ptr %0, i32 %22
  %35 = load i8, ptr %34, align 1, !tbaa !2
  %36 = icmp eq i8 %35, 110
  br i1 %36, label %37, label %49

37:                                               ; preds = %33
  %38 = getelementptr i8, ptr %34, i32 1
  %39 = load i8, ptr %38, align 1, !tbaa !2
  %40 = icmp eq i8 %39, 117
  br i1 %40, label %41, label %49

41:                                               ; preds = %37
  %42 = getelementptr i8, ptr %34, i32 2
  %43 = load i8, ptr %42, align 1, !tbaa !2
  %44 = icmp eq i8 %43, 108
  br i1 %44, label %45, label %49

45:                                               ; preds = %41
  %46 = getelementptr i8, ptr %34, i32 3
  %47 = load i8, ptr %46, align 1, !tbaa !2
  %48 = icmp eq i8 %47, 108
  br i1 %48, label %57, label %49

49:                                               ; preds = %19, %33, %37, %41, %45
  %50 = add i32 %15, %28
  %51 = icmp ult i32 %50, %15
  %52 = icmp ugt i32 %50, %3
  %53 = or i1 %51, %52
  br i1 %53, label %646, label %54

54:                                               ; preds = %49
  %55 = getelementptr inbounds nuw i8, ptr %0, i32 %22
  %56 = getelementptr inbounds nuw i8, ptr %2, i32 %15
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %56, ptr readonly align 1 %55, i32 %28, i1 false)
  br label %64

57:                                               ; preds = %19, %45
  %58 = add i32 %14, 6
  %59 = icmp ugt i32 %15, -3
  %60 = icmp ugt i32 %58, %3
  %61 = or i1 %59, %60
  br i1 %61, label %646, label %62

62:                                               ; preds = %57
  %63 = getelementptr inbounds nuw i8, ptr %2, i32 %15
  store i16 8738, ptr %63, align 1
  br label %64

64:                                               ; preds = %62, %54
  %65 = phi i32 [ %50, %54 ], [ %58, %62 ]
  store i32 %65, ptr %4, align 4, !tbaa !5
  %66 = icmp ult i32 %65, %3
  br i1 %66, label %67, label %646

67:                                               ; preds = %64
  %68 = getelementptr inbounds nuw i8, ptr %2, i32 %65
  store i8 0, ptr %68, align 1, !tbaa !2
  %69 = load i32, ptr %4, align 4, !tbaa !5
  %70 = add i32 %69, 1
  store i32 %70, ptr %4, align 4, !tbaa !5
  switch i32 %30, label %87 [
    i32 0, label %95
    i32 4, label %71
  ]

71:                                               ; preds = %67
  %72 = getelementptr inbounds nuw i8, ptr %0, i32 %24
  %73 = load i8, ptr %72, align 1, !tbaa !2
  %74 = icmp eq i8 %73, 110
  br i1 %74, label %75, label %87

75:                                               ; preds = %71
  %76 = getelementptr i8, ptr %72, i32 1
  %77 = load i8, ptr %76, align 1, !tbaa !2
  %78 = icmp eq i8 %77, 117
  br i1 %78, label %79, label %87

79:                                               ; preds = %75
  %80 = getelementptr i8, ptr %72, i32 2
  %81 = load i8, ptr %80, align 1, !tbaa !2
  %82 = icmp eq i8 %81, 108
  br i1 %82, label %83, label %87

83:                                               ; preds = %79
  %84 = getelementptr i8, ptr %72, i32 3
  %85 = load i8, ptr %84, align 1, !tbaa !2
  %86 = icmp eq i8 %85, 108
  br i1 %86, label %95, label %87

87:                                               ; preds = %67, %83, %79, %75, %71
  %88 = add i32 %70, %30
  %89 = icmp ult i32 %88, %70
  %90 = icmp ugt i32 %88, %3
  %91 = or i1 %89, %90
  br i1 %91, label %646, label %92

92:                                               ; preds = %87
  %93 = getelementptr inbounds nuw i8, ptr %0, i32 %24
  %94 = getelementptr inbounds nuw i8, ptr %2, i32 %70
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %94, ptr readonly align 1 %93, i32 %30, i1 false)
  br label %102

95:                                               ; preds = %67, %83
  %96 = add i32 %69, 3
  %97 = icmp ugt i32 %70, -3
  %98 = icmp ugt i32 %96, %3
  %99 = or i1 %97, %98
  br i1 %99, label %646, label %100

100:                                              ; preds = %95
  %101 = getelementptr inbounds nuw i8, ptr %2, i32 %70
  store i16 8738, ptr %101, align 1
  br label %102

102:                                              ; preds = %100, %92
  %103 = phi i32 [ %88, %92 ], [ %96, %100 ]
  store i32 %103, ptr %4, align 4, !tbaa !5
  %104 = icmp ult i32 %103, %3
  br i1 %104, label %105, label %646

105:                                              ; preds = %102
  %106 = getelementptr inbounds nuw i8, ptr %2, i32 %103
  store i8 0, ptr %106, align 1, !tbaa !2
  %107 = load i32, ptr %4, align 4, !tbaa !5
  %108 = add i32 %107, 1
  store i32 %108, ptr %4, align 4, !tbaa !5
  switch i32 %32, label %125 [
    i32 0, label %133
    i32 4, label %109
  ]

109:                                              ; preds = %105
  %110 = getelementptr inbounds nuw i8, ptr %0, i32 %26
  %111 = load i8, ptr %110, align 1, !tbaa !2
  %112 = icmp eq i8 %111, 110
  br i1 %112, label %113, label %125

113:                                              ; preds = %109
  %114 = getelementptr i8, ptr %110, i32 1
  %115 = load i8, ptr %114, align 1, !tbaa !2
  %116 = icmp eq i8 %115, 117
  br i1 %116, label %117, label %125

117:                                              ; preds = %113
  %118 = getelementptr i8, ptr %110, i32 2
  %119 = load i8, ptr %118, align 1, !tbaa !2
  %120 = icmp eq i8 %119, 108
  br i1 %120, label %121, label %125

121:                                              ; preds = %117
  %122 = getelementptr i8, ptr %110, i32 3
  %123 = load i8, ptr %122, align 1, !tbaa !2
  %124 = icmp eq i8 %123, 108
  br i1 %124, label %133, label %125

125:                                              ; preds = %105, %121, %117, %113, %109
  %126 = add i32 %108, %32
  %127 = icmp ult i32 %126, %108
  %128 = icmp ugt i32 %126, %3
  %129 = or i1 %127, %128
  br i1 %129, label %646, label %130

130:                                              ; preds = %125
  %131 = getelementptr inbounds nuw i8, ptr %0, i32 %26
  %132 = getelementptr inbounds nuw i8, ptr %2, i32 %108
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %132, ptr readonly align 1 %131, i32 %32, i1 false)
  br label %140

133:                                              ; preds = %105, %121
  %134 = add i32 %107, 3
  %135 = icmp ugt i32 %108, -3
  %136 = icmp ugt i32 %134, %3
  %137 = or i1 %135, %136
  br i1 %137, label %646, label %138

138:                                              ; preds = %133
  %139 = getelementptr inbounds nuw i8, ptr %2, i32 %108
  store i16 8738, ptr %139, align 1
  br label %140

140:                                              ; preds = %138, %130
  %141 = phi i32 [ %126, %130 ], [ %134, %138 ]
  store i32 %141, ptr %4, align 4, !tbaa !5
  %142 = icmp ult i32 %141, %3
  br i1 %142, label %143, label %646

143:                                              ; preds = %140
  %144 = getelementptr inbounds nuw i8, ptr %2, i32 %141
  store i8 0, ptr %144, align 1, !tbaa !2
  %145 = load i32, ptr %4, align 4, !tbaa !5
  %146 = add i32 %145, 1
  store i32 %146, ptr %4, align 4, !tbaa !5
  %147 = getelementptr inbounds nuw i8, ptr %1, i32 40
  %148 = load i32, ptr %147, align 4, !tbaa !29
  %149 = icmp eq i32 %148, 0
  br i1 %149, label %631, label %150

150:                                              ; preds = %143
  %151 = getelementptr inbounds nuw i8, ptr %1, i32 64
  %152 = load i32, ptr %151, align 4, !tbaa !68
  %153 = icmp eq i32 %152, 0
  br i1 %153, label %154, label %164

154:                                              ; preds = %150
  %155 = add i32 %146, %148
  %156 = icmp ult i32 %155, %146
  %157 = icmp ugt i32 %155, %3
  %158 = or i1 %156, %157
  br i1 %158, label %646, label %159

159:                                              ; preds = %154
  %160 = getelementptr inbounds nuw i8, ptr %1, i32 36
  %161 = load i32, ptr %160, align 4, !tbaa !27
  %162 = getelementptr inbounds nuw i8, ptr %0, i32 %161
  %163 = getelementptr inbounds nuw i8, ptr %2, i32 %146
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %163, ptr readonly align 1 %162, i32 %148, i1 false)
  store i32 %155, ptr %4, align 4, !tbaa !5
  br label %638

164:                                              ; preds = %150
  %165 = and i32 %7, 16
  %166 = icmp eq i32 %165, 0
  br i1 %166, label %624, label %167

167:                                              ; preds = %164
  %168 = getelementptr inbounds nuw i8, ptr %1, i32 36
  %169 = load i32, ptr %168, align 4, !tbaa !27
  %170 = add i32 %169, %148
  %171 = icmp ult i32 %169, %170
  br i1 %171, label %172, label %611

172:                                              ; preds = %167
  %173 = getelementptr inbounds nuw i8, ptr %0, i32 %169
  %174 = load i8, ptr %173, align 1, !tbaa !2
  %175 = icmp eq i8 %174, 91
  br i1 %175, label %176, label %611

176:                                              ; preds = %172
  %177 = icmp ult i32 %146, %3
  br i1 %177, label %178, label %608

178:                                              ; preds = %176
  %179 = getelementptr inbounds nuw i8, ptr %2, i32 %146
  store i8 91, ptr %179, align 1, !tbaa !2
  %180 = load i32, ptr %4, align 4, !tbaa !5
  %181 = add i32 %180, 1
  store i32 %181, ptr %4, align 4, !tbaa !5
  %182 = add nuw i32 %169, 1
  %183 = icmp ult i32 %182, %170
  br i1 %183, label %184, label %608

184:                                              ; preds = %178
  %185 = getelementptr i8, ptr %0, i32 3
  %186 = getelementptr i8, ptr %0, i32 4
  %187 = getelementptr i8, ptr %0, i32 5
  %188 = getelementptr i8, ptr %0, i32 2
  %189 = getelementptr i8, ptr %0, i32 1
  br label %190

190:                                              ; preds = %605, %184
  %191 = phi i32 [ %181, %184 ], [ %585, %605 ]
  %192 = phi i1 [ false, %184 ], [ true, %605 ]
  %193 = phi i32 [ %182, %184 ], [ %606, %605 ]
  %194 = icmp ult i32 %193, %170
  br i1 %194, label %195, label %202

195:                                              ; preds = %190, %199
  %196 = phi i32 [ %200, %199 ], [ %193, %190 ]
  %197 = getelementptr inbounds nuw i8, ptr %0, i32 %196
  %198 = load i8, ptr %197, align 1, !tbaa !2
  switch i8 %198, label %202 [
    i8 32, label %199
    i8 13, label %199
    i8 10, label %199
    i8 9, label %199
  ]

199:                                              ; preds = %195, %195, %195, %195
  %200 = add i32 %196, 1
  %201 = icmp eq i32 %200, %170
  br i1 %201, label %608, label %195, !llvm.loop !35

202:                                              ; preds = %195, %190
  %203 = phi i32 [ %193, %190 ], [ %196, %195 ]
  %204 = icmp ult i32 %203, %170
  br i1 %204, label %205, label %608

205:                                              ; preds = %202
  %206 = getelementptr inbounds nuw i8, ptr %0, i32 %203
  %207 = load i8, ptr %206, align 1, !tbaa !2
  %208 = icmp eq i8 %207, 93
  br i1 %208, label %209, label %215

209:                                              ; preds = %205
  %210 = icmp ult i32 %191, %3
  br i1 %210, label %211, label %608

211:                                              ; preds = %209
  %212 = getelementptr inbounds nuw i8, ptr %2, i32 %191
  store i8 93, ptr %212, align 1, !tbaa !2
  %213 = load i32, ptr %4, align 4, !tbaa !5
  %214 = add i32 %213, 1
  br label %608

215:                                              ; preds = %205
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %11) #28
  store i32 0, ptr %11, align 4, !tbaa !5
  %216 = icmp eq i8 %207, 123
  br i1 %216, label %217, label %544

217:                                              ; preds = %215
  %218 = add nuw i32 %203, 1
  %219 = icmp ult i32 %218, %170
  br i1 %219, label %220, label %227

220:                                              ; preds = %217, %224
  %221 = phi i32 [ %225, %224 ], [ %218, %217 ]
  %222 = getelementptr inbounds nuw i8, ptr %0, i32 %221
  %223 = load i8, ptr %222, align 1, !tbaa !2
  switch i8 %223, label %227 [
    i8 32, label %224
    i8 13, label %224
    i8 10, label %224
    i8 9, label %224
  ]

224:                                              ; preds = %220, %220, %220, %220
  %225 = add i32 %221, 1
  %226 = icmp eq i32 %225, %170
  br i1 %226, label %538, label %220, !llvm.loop !35

227:                                              ; preds = %220, %217
  %228 = phi i32 [ %218, %217 ], [ %221, %220 ]
  %229 = icmp ult i32 %228, %170
  br i1 %229, label %230, label %538

230:                                              ; preds = %227, %534
  %231 = phi i32 [ %535, %534 ], [ %228, %227 ]
  %232 = phi i32 [ %515, %534 ], [ 0, %227 ]
  %233 = phi i32 [ %516, %534 ], [ 0, %227 ]
  %234 = phi i32 [ %514, %534 ], [ 0, %227 ]
  %235 = phi i32 [ %513, %534 ], [ 0, %227 ]
  %236 = phi i32 [ %512, %534 ], [ 0, %227 ]
  %237 = icmp ult i32 %231, %170
  br i1 %237, label %238, label %245

238:                                              ; preds = %230, %242
  %239 = phi i32 [ %243, %242 ], [ %231, %230 ]
  %240 = getelementptr inbounds nuw i8, ptr %0, i32 %239
  %241 = load i8, ptr %240, align 1, !tbaa !2
  switch i8 %241, label %245 [
    i8 32, label %242
    i8 13, label %242
    i8 10, label %242
    i8 9, label %242
  ]

242:                                              ; preds = %238, %238, %238, %238
  %243 = add i32 %239, 1
  %244 = icmp eq i32 %243, %170
  br i1 %244, label %538, label %238, !llvm.loop !35

245:                                              ; preds = %238, %230
  %246 = phi i32 [ %231, %230 ], [ %239, %238 ]
  %247 = icmp ult i32 %246, %170
  br i1 %247, label %248, label %538

248:                                              ; preds = %245
  %249 = getelementptr inbounds nuw i8, ptr %0, i32 %246
  %250 = load i8, ptr %249, align 1, !tbaa !2
  %251 = icmp eq i8 %250, 125
  br i1 %251, label %252, label %258

252:                                              ; preds = %248
  %253 = icmp eq i32 %233, 2
  %254 = icmp ne i32 %232, 0
  %255 = select i1 %253, i1 %254, i1 false
  %256 = icmp ne i32 %236, 0
  %257 = select i1 %255, i1 %256, i1 false
  br i1 %257, label %540, label %538

258:                                              ; preds = %248
  %259 = icmp samesign ult i32 %233, 2
  %260 = icmp eq i8 %250, 34
  %261 = and i1 %259, %260
  %262 = add nuw i32 %246, 1
  %263 = icmp ult i32 %262, %170
  %264 = select i1 %261, i1 %263, i1 false
  br i1 %264, label %265, label %538

265:                                              ; preds = %258, %283
  %266 = phi i32 [ %284, %283 ], [ %262, %258 ]
  %267 = add i32 %266, 8
  %268 = icmp ugt i32 %267, %170
  br i1 %268, label %290, label %269

269:                                              ; preds = %265
  %270 = getelementptr inbounds nuw i8, ptr %0, i32 %266
  %271 = load i64, ptr %270, align 1
  %272 = xor i64 %271, 2459565876494606882
  %273 = add i64 %272, -72340172838076673
  %274 = and i64 %271, -9187201950435737472
  %275 = xor i64 %274, -9187201950435737472
  %276 = xor i64 %271, 6655295901103053916
  %277 = add i64 %276, -72340172838076673
  %278 = add i64 %271, -2314885530818453536
  %279 = or i64 %277, %278
  %280 = or i64 %279, %273
  %281 = and i64 %280, %275
  %282 = icmp eq i64 %281, 0
  br i1 %282, label %283, label %285

283:                                              ; preds = %269, %352
  %284 = phi i32 [ %267, %269 ], [ %353, %352 ]
  br label %265

285:                                              ; preds = %269
  %286 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %281, i1 true)
  %287 = trunc nuw nsw i64 %286 to i32
  %288 = lshr i32 %287, 3
  %289 = add i32 %288, %266
  br label %290

290:                                              ; preds = %265, %285
  %291 = phi i32 [ %289, %285 ], [ %266, %265 ]
  %292 = icmp ult i32 %291, %170
  br i1 %292, label %293, label %538

293:                                              ; preds = %290
  %294 = getelementptr inbounds nuw i8, ptr %0, i32 %291
  %295 = load i8, ptr %294, align 1, !tbaa !2
  %296 = icmp eq i8 %295, 92
  br i1 %296, label %297, label %347

297:                                              ; preds = %293
  %298 = add nuw i32 %291, 1
  %299 = icmp ult i32 %298, %170
  br i1 %299, label %300, label %538

300:                                              ; preds = %297
  %301 = getelementptr inbounds nuw i8, ptr %0, i32 %298
  %302 = load i8, ptr %301, align 1, !tbaa !2
  switch i8 %302, label %538 [
    i8 117, label %303
    i8 116, label %345
    i8 114, label %345
    i8 110, label %345
    i8 102, label %345
    i8 98, label %345
    i8 92, label %345
    i8 47, label %345
    i8 34, label %345
  ]

303:                                              ; preds = %300
  %304 = add i32 %291, 6
  %305 = icmp ugt i32 %304, %170
  br i1 %305, label %538, label %306

306:                                              ; preds = %303
  %307 = add nuw i32 %291, 2
  %308 = icmp ult i32 %307, %304
  br i1 %308, label %309, label %352

309:                                              ; preds = %306
  %310 = getelementptr inbounds nuw i8, ptr %0, i32 %307
  %311 = load i8, ptr %310, align 1, !tbaa !2
  %312 = add i8 %311, -58
  %313 = icmp ult i8 %312, -10
  %314 = and i8 %311, -33
  %315 = add i8 %314, -71
  %316 = icmp ult i8 %315, -6
  %317 = and i1 %313, %316
  br i1 %317, label %538, label %318

318:                                              ; preds = %309
  %319 = getelementptr i8, ptr %185, i32 %291
  %320 = load i8, ptr %319, align 1, !tbaa !2
  %321 = add i8 %320, -58
  %322 = icmp ult i8 %321, -10
  %323 = and i8 %320, -33
  %324 = add i8 %323, -71
  %325 = icmp ult i8 %324, -6
  %326 = and i1 %322, %325
  br i1 %326, label %538, label %327

327:                                              ; preds = %318
  %328 = getelementptr i8, ptr %186, i32 %291
  %329 = load i8, ptr %328, align 1, !tbaa !2
  %330 = add i8 %329, -58
  %331 = icmp ult i8 %330, -10
  %332 = and i8 %329, -33
  %333 = add i8 %332, -71
  %334 = icmp ult i8 %333, -6
  %335 = and i1 %331, %334
  br i1 %335, label %538, label %336

336:                                              ; preds = %327
  %337 = getelementptr i8, ptr %187, i32 %291
  %338 = load i8, ptr %337, align 1, !tbaa !2
  %339 = add i8 %338, -58
  %340 = icmp ult i8 %339, -10
  %341 = and i8 %338, -33
  %342 = add i8 %341, -71
  %343 = icmp ult i8 %342, -6
  %344 = and i1 %340, %343
  br i1 %344, label %538, label %352

345:                                              ; preds = %300, %300, %300, %300, %300, %300, %300, %300
  %346 = add nuw i32 %291, 2
  br label %352, !llvm.loop !42

347:                                              ; preds = %293
  %348 = icmp ult i8 %295, 32
  br i1 %348, label %538, label %349

349:                                              ; preds = %347
  %350 = icmp eq i8 %295, 34
  %351 = add nuw i32 %291, 1
  br i1 %350, label %355, label %352

352:                                              ; preds = %349, %345, %336, %306
  %353 = phi i32 [ %346, %345 ], [ %304, %306 ], [ %304, %336 ], [ %351, %349 ]
  %354 = icmp ult i32 %353, %170
  br i1 %354, label %283, label %538

355:                                              ; preds = %349
  %356 = icmp ugt i32 %246, %291
  br i1 %356, label %424, label %357

357:                                              ; preds = %355
  %358 = add i32 %246, 5
  %359 = sub nuw i32 %291, %246
  %360 = icmp eq i32 %291, %246
  br i1 %360, label %391, label %376

361:                                              ; preds = %382
  %362 = getelementptr i8, ptr %188, i32 %246
  %363 = load i8, ptr %362, align 1, !tbaa !2
  switch i8 %363, label %391 [
    i8 92, label %380
    i8 121, label %364
  ]

364:                                              ; preds = %361
  %365 = icmp eq i32 %359, 2
  br i1 %365, label %391, label %366

366:                                              ; preds = %364
  %367 = getelementptr i8, ptr %185, i32 %246
  %368 = load i8, ptr %367, align 1, !tbaa !2
  switch i8 %368, label %391 [
    i8 92, label %380
    i8 112, label %369
  ]

369:                                              ; preds = %366
  %370 = icmp eq i32 %359, 3
  br i1 %370, label %391, label %371

371:                                              ; preds = %369
  %372 = getelementptr i8, ptr %186, i32 %246
  %373 = load i8, ptr %372, align 1, !tbaa !2
  switch i8 %373, label %391 [
    i8 92, label %380
    i8 101, label %374
  ]

374:                                              ; preds = %371
  %375 = icmp ugt i32 %358, %291
  br i1 %375, label %391, label %386

376:                                              ; preds = %357
  %377 = getelementptr inbounds nuw i8, ptr %0, i32 %262
  %378 = load i8, ptr %377, align 1, !tbaa !2
  %379 = icmp eq i8 %378, 92
  br i1 %379, label %380, label %382

380:                                              ; preds = %376, %371, %366, %361
  %381 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %246, i32 noundef %351, ptr noundef nonnull @.str.2, i32 noundef 4)
  br label %391

382:                                              ; preds = %376
  %383 = icmp ne i8 %378, 116
  %384 = icmp eq i32 %359, 1
  %385 = or i1 %384, %383
  br i1 %385, label %391, label %361

386:                                              ; preds = %374
  %387 = getelementptr inbounds nuw i8, ptr %0, i32 %358
  %388 = load i8, ptr %387, align 1, !tbaa !2
  %389 = icmp eq i8 %388, 34
  %390 = zext i1 %389 to i32
  br label %391

391:                                              ; preds = %386, %382, %380, %374, %371, %369, %366, %364, %361, %357
  %392 = phi i32 [ 0, %374 ], [ %390, %386 ], [ %381, %380 ], [ 0, %369 ], [ 0, %364 ], [ 0, %357 ], [ 0, %382 ], [ 0, %361 ], [ 0, %366 ], [ 0, %371 ]
  %393 = icmp ult i32 %246, %291
  br i1 %393, label %414, label %424

394:                                              ; preds = %414
  %395 = add nuw i32 %246, 2
  %396 = icmp ugt i32 %395, %291
  br i1 %396, label %424, label %397

397:                                              ; preds = %394
  %398 = getelementptr inbounds nuw i8, ptr %0, i32 %395
  %399 = load i8, ptr %398, align 1, !tbaa !2
  switch i8 %399, label %424 [
    i8 92, label %417
    i8 101, label %400
  ]

400:                                              ; preds = %397
  %401 = add nuw i32 %246, 3
  %402 = icmp ugt i32 %401, %291
  br i1 %402, label %424, label %403

403:                                              ; preds = %400
  %404 = getelementptr inbounds nuw i8, ptr %0, i32 %401
  %405 = load i8, ptr %404, align 1, !tbaa !2
  switch i8 %405, label %424 [
    i8 92, label %417
    i8 120, label %406
  ]

406:                                              ; preds = %403
  %407 = add nuw i32 %246, 4
  %408 = icmp ugt i32 %407, %291
  br i1 %408, label %424, label %409

409:                                              ; preds = %406
  %410 = getelementptr inbounds nuw i8, ptr %0, i32 %407
  %411 = load i8, ptr %410, align 1, !tbaa !2
  switch i8 %411, label %424 [
    i8 92, label %417
    i8 116, label %412
  ]

412:                                              ; preds = %409
  %413 = icmp ugt i32 %358, %291
  br i1 %413, label %424, label %420

414:                                              ; preds = %391
  %415 = getelementptr inbounds nuw i8, ptr %0, i32 %262
  %416 = load i8, ptr %415, align 1, !tbaa !2
  switch i8 %416, label %424 [
    i8 92, label %417
    i8 116, label %394
  ]

417:                                              ; preds = %414, %409, %403, %397
  %418 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %246, i32 noundef %351, ptr noundef nonnull @.str.10, i32 noundef 4)
  %419 = icmp ne i32 %418, 0
  br label %424

420:                                              ; preds = %412
  %421 = getelementptr inbounds nuw i8, ptr %0, i32 %358
  %422 = load i8, ptr %421, align 1, !tbaa !2
  %423 = icmp eq i8 %422, 34
  br label %424

424:                                              ; preds = %420, %417, %414, %412, %409, %406, %403, %400, %397, %394, %391, %355
  %425 = phi i32 [ %392, %412 ], [ %392, %420 ], [ 0, %355 ], [ %392, %417 ], [ %392, %406 ], [ %392, %400 ], [ %392, %394 ], [ %392, %391 ], [ %392, %397 ], [ %392, %403 ], [ %392, %409 ], [ %392, %414 ]
  %426 = phi i1 [ false, %412 ], [ %423, %420 ], [ false, %355 ], [ %419, %417 ], [ false, %406 ], [ false, %400 ], [ false, %394 ], [ false, %391 ], [ false, %397 ], [ false, %403 ], [ false, %409 ], [ false, %414 ]
  %427 = icmp ne i32 %425, 0
  %428 = select i1 %427, i1 true, i1 %426
  br i1 %428, label %429, label %538

429:                                              ; preds = %424
  %430 = icmp ult i32 %351, %170
  br i1 %430, label %431, label %438

431:                                              ; preds = %429, %435
  %432 = phi i32 [ %436, %435 ], [ %351, %429 ]
  %433 = getelementptr inbounds nuw i8, ptr %0, i32 %432
  %434 = load i8, ptr %433, align 1, !tbaa !2
  switch i8 %434, label %438 [
    i8 32, label %435
    i8 13, label %435
    i8 10, label %435
    i8 9, label %435
  ]

435:                                              ; preds = %431, %431, %431, %431
  %436 = add i32 %432, 1
  %437 = icmp eq i32 %436, %170
  br i1 %437, label %538, label %431, !llvm.loop !35

438:                                              ; preds = %431, %429
  %439 = phi i32 [ %351, %429 ], [ %432, %431 ]
  %440 = icmp ult i32 %439, %170
  br i1 %440, label %441, label %538

441:                                              ; preds = %438
  %442 = getelementptr inbounds nuw i8, ptr %0, i32 %439
  %443 = load i8, ptr %442, align 1, !tbaa !2
  %444 = icmp eq i8 %443, 58
  br i1 %444, label %445, label %538

445:                                              ; preds = %441
  %446 = add nuw i32 %439, 1
  %447 = icmp ult i32 %446, %170
  br i1 %447, label %448, label %455

448:                                              ; preds = %445, %452
  %449 = phi i32 [ %453, %452 ], [ %446, %445 ]
  %450 = getelementptr inbounds nuw i8, ptr %0, i32 %449
  %451 = load i8, ptr %450, align 1, !tbaa !2
  switch i8 %451, label %455 [
    i8 32, label %452
    i8 13, label %452
    i8 10, label %452
    i8 9, label %452
  ]

452:                                              ; preds = %448, %448, %448, %448
  %453 = add i32 %449, 1
  %454 = icmp eq i32 %453, %170
  br i1 %454, label %455, label %448, !llvm.loop !35

455:                                              ; preds = %452, %448, %445
  %456 = phi i32 [ %446, %445 ], [ %170, %452 ], [ %449, %448 ]
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %10) #28
  store i32 0, ptr %10, align 4, !tbaa !5
  %457 = call fastcc i32 @parse_value_span(ptr noundef nonnull %0, i32 noundef %170, i32 noundef %456, ptr noundef %10)
  %458 = icmp eq i32 %457, 0
  br i1 %458, label %537, label %459

459:                                              ; preds = %455
  %460 = load i32, ptr %10, align 4, !tbaa !5
  %461 = icmp ugt i32 %460, %170
  br i1 %461, label %537, label %462

462:                                              ; preds = %459
  %463 = icmp ult i32 %456, %460
  br i1 %427, label %464, label %504

464:                                              ; preds = %462
  br i1 %463, label %465, label %537

465:                                              ; preds = %464
  %466 = getelementptr inbounds nuw i8, ptr %0, i32 %456
  %467 = load i8, ptr %466, align 1, !tbaa !2
  %468 = icmp eq i8 %467, 34
  br i1 %468, label %469, label %537

469:                                              ; preds = %465
  %470 = add i32 %456, 5
  %471 = xor i32 %456, -1
  %472 = add i32 %460, %471
  %473 = icmp eq i32 %472, 0
  br i1 %473, label %537, label %489

474:                                              ; preds = %493
  %475 = getelementptr i8, ptr %188, i32 %456
  %476 = load i8, ptr %475, align 1, !tbaa !2
  switch i8 %476, label %537 [
    i8 92, label %501
    i8 101, label %477
  ]

477:                                              ; preds = %474
  %478 = icmp eq i32 %472, 2
  br i1 %478, label %537, label %479

479:                                              ; preds = %477
  %480 = getelementptr i8, ptr %185, i32 %456
  %481 = load i8, ptr %480, align 1, !tbaa !2
  switch i8 %481, label %537 [
    i8 92, label %501
    i8 120, label %482
  ]

482:                                              ; preds = %479
  %483 = icmp eq i32 %472, 3
  br i1 %483, label %537, label %484

484:                                              ; preds = %482
  %485 = getelementptr i8, ptr %186, i32 %456
  %486 = load i8, ptr %485, align 1, !tbaa !2
  switch i8 %486, label %537 [
    i8 92, label %501
    i8 116, label %487
  ]

487:                                              ; preds = %484
  %488 = icmp ult i32 %470, %460
  br i1 %488, label %497, label %537

489:                                              ; preds = %469
  %490 = getelementptr i8, ptr %189, i32 %456
  %491 = load i8, ptr %490, align 1, !tbaa !2
  %492 = icmp eq i8 %491, 92
  br i1 %492, label %501, label %493

493:                                              ; preds = %489
  %494 = icmp ne i8 %491, 116
  %495 = icmp eq i32 %472, 1
  %496 = or i1 %495, %494
  br i1 %496, label %537, label %474

497:                                              ; preds = %487
  %498 = getelementptr inbounds nuw i8, ptr %0, i32 %470
  %499 = load i8, ptr %498, align 1, !tbaa !2
  %500 = icmp eq i8 %499, 34
  br i1 %500, label %511, label %537

501:                                              ; preds = %489, %484, %479, %474
  %502 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %456, i32 noundef %460, ptr noundef nonnull @.str.10, i32 noundef 4)
  %503 = icmp eq i32 %502, 0
  br i1 %503, label %537, label %511

504:                                              ; preds = %462
  br i1 %463, label %505, label %537

505:                                              ; preds = %504
  %506 = getelementptr inbounds nuw i8, ptr %0, i32 %456
  %507 = load i8, ptr %506, align 1, !tbaa !2
  %508 = icmp eq i8 %507, 34
  br i1 %508, label %509, label %537

509:                                              ; preds = %505
  %510 = sub i32 %460, %456
  br label %511

511:                                              ; preds = %509, %501, %497
  %512 = phi i32 [ 1, %509 ], [ %236, %501 ], [ %236, %497 ]
  %513 = phi i32 [ %456, %509 ], [ %235, %501 ], [ %235, %497 ]
  %514 = phi i32 [ %510, %509 ], [ %234, %501 ], [ %234, %497 ]
  %515 = phi i32 [ %232, %509 ], [ 1, %501 ], [ 1, %497 ]
  %516 = add nuw nsw i32 %233, 1
  %517 = icmp ult i32 %460, %170
  br i1 %517, label %518, label %525

518:                                              ; preds = %511, %522
  %519 = phi i32 [ %523, %522 ], [ %460, %511 ]
  %520 = getelementptr inbounds nuw i8, ptr %0, i32 %519
  %521 = load i8, ptr %520, align 1, !tbaa !2
  switch i8 %521, label %525 [
    i8 32, label %522
    i8 13, label %522
    i8 10, label %522
    i8 9, label %522
  ]

522:                                              ; preds = %518, %518, %518, %518
  %523 = add i32 %519, 1
  %524 = icmp eq i32 %523, %170
  br i1 %524, label %537, label %518, !llvm.loop !35

525:                                              ; preds = %518, %511
  %526 = phi i32 [ %460, %511 ], [ %519, %518 ]
  %527 = icmp ult i32 %526, %170
  br i1 %527, label %528, label %534

528:                                              ; preds = %525
  %529 = getelementptr inbounds nuw i8, ptr %0, i32 %526
  %530 = load i8, ptr %529, align 1, !tbaa !2
  %531 = icmp eq i8 %530, 44
  %532 = zext i1 %531 to i32
  %533 = add nuw i32 %526, %532
  br label %534

534:                                              ; preds = %528, %525
  %535 = phi i32 [ %526, %525 ], [ %533, %528 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10) #28
  %536 = icmp ult i32 %535, %170
  br i1 %536, label %230, label %538, !llvm.loop !69

537:                                              ; preds = %455, %459, %464, %465, %469, %474, %477, %479, %482, %484, %487, %493, %497, %501, %504, %505, %522
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10) #28
  br label %538

538:                                              ; preds = %224, %534, %441, %438, %424, %258, %245, %242, %352, %347, %336, %327, %318, %309, %303, %300, %297, %290, %435, %537, %252, %227
  %539 = load i8, ptr %206, align 1, !tbaa !2
  switch i8 %539, label %547 [
    i8 123, label %604
    i8 91, label %604
  ]

540:                                              ; preds = %252
  %541 = add nuw i32 %246, 1
  %542 = load i8, ptr %206, align 1, !tbaa !2
  %543 = icmp eq i8 %542, 91
  br i1 %543, label %604, label %553

544:                                              ; preds = %215
  %545 = and i8 %207, -33
  %546 = icmp eq i8 %545, 91
  br i1 %546, label %604, label %547

547:                                              ; preds = %544, %538
  %548 = call fastcc i32 @parse_value_span(ptr noundef nonnull %0, i32 noundef %170, i32 noundef %203, ptr noundef %11)
  %549 = icmp eq i32 %548, 0
  %550 = load i32, ptr %11, align 4
  %551 = icmp ugt i32 %550, %170
  %552 = select i1 %549, i1 true, i1 %551
  br i1 %552, label %604, label %553

553:                                              ; preds = %547, %540
  %554 = phi i32 [ %550, %547 ], [ %541, %540 ]
  %555 = phi i32 [ 0, %547 ], [ %235, %540 ]
  %556 = phi i32 [ 0, %547 ], [ %234, %540 ]
  %557 = phi i1 [ false, %547 ], [ true, %540 ]
  br i1 %192, label %558, label %565

558:                                              ; preds = %553
  %559 = load i32, ptr %4, align 4, !tbaa !5
  %560 = icmp ult i32 %559, %3
  br i1 %560, label %561, label %604

561:                                              ; preds = %558
  %562 = getelementptr inbounds nuw i8, ptr %2, i32 %559
  store i8 44, ptr %562, align 1, !tbaa !2
  %563 = load i32, ptr %4, align 4, !tbaa !5
  %564 = add i32 %563, 1
  store i32 %564, ptr %4, align 4, !tbaa !5
  br label %565

565:                                              ; preds = %561, %553
  br i1 %557, label %566, label %575

566:                                              ; preds = %565
  %567 = load i32, ptr %4, align 4, !tbaa !5
  %568 = add i32 %567, %556
  %569 = icmp ult i32 %568, %567
  %570 = icmp ugt i32 %568, %3
  %571 = or i1 %569, %570
  br i1 %571, label %604, label %572

572:                                              ; preds = %566
  %573 = getelementptr inbounds nuw i8, ptr %0, i32 %555
  %574 = getelementptr inbounds nuw i8, ptr %2, i32 %567
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %574, ptr readonly align 1 %573, i32 %556, i1 false)
  br label %584

575:                                              ; preds = %565
  %576 = sub i32 %554, %203
  %577 = load i32, ptr %4, align 4, !tbaa !5
  %578 = add i32 %577, %576
  %579 = icmp ult i32 %578, %577
  %580 = icmp ugt i32 %578, %3
  %581 = or i1 %579, %580
  br i1 %581, label %604, label %582

582:                                              ; preds = %575
  %583 = getelementptr inbounds nuw i8, ptr %2, i32 %577
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %583, ptr nonnull readonly align 1 %206, i32 %576, i1 false)
  br label %584

584:                                              ; preds = %582, %572
  %585 = phi i32 [ %578, %582 ], [ %568, %572 ]
  store i32 %585, ptr %4, align 4, !tbaa !5
  %586 = icmp ult i32 %554, %170
  br i1 %586, label %587, label %595

587:                                              ; preds = %584, %591
  %588 = phi i32 [ %592, %591 ], [ %554, %584 ]
  %589 = getelementptr inbounds nuw i8, ptr %0, i32 %588
  %590 = load i8, ptr %589, align 1, !tbaa !2
  switch i8 %590, label %595 [
    i8 32, label %591
    i8 13, label %591
    i8 10, label %591
    i8 9, label %591
  ]

591:                                              ; preds = %587, %587, %587, %587
  %592 = add i32 %588, 1
  %593 = icmp eq i32 %592, %170
  br i1 %593, label %594, label %587, !llvm.loop !35

594:                                              ; preds = %591
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %11) #28
  br label %608

595:                                              ; preds = %587, %584
  %596 = phi i32 [ %554, %584 ], [ %588, %587 ]
  %597 = icmp ult i32 %596, %170
  br i1 %597, label %598, label %605

598:                                              ; preds = %595
  %599 = getelementptr inbounds nuw i8, ptr %0, i32 %596
  %600 = load i8, ptr %599, align 1, !tbaa !2
  %601 = icmp eq i8 %600, 44
  %602 = zext i1 %601 to i32
  %603 = add nuw i32 %596, %602
  br label %605

604:                                              ; preds = %575, %566, %558, %547, %544, %540, %538, %538
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %11) #28
  br label %608

605:                                              ; preds = %598, %595
  %606 = phi i32 [ %596, %595 ], [ %603, %598 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %11) #28
  %607 = icmp ult i32 %606, %170
  br i1 %607, label %190, label %608

608:                                              ; preds = %605, %202, %199, %594, %604, %211, %209, %178, %176
  %609 = phi i32 [ %214, %211 ], [ %146, %178 ], [ %146, %209 ], [ %146, %176 ], [ %146, %604 ], [ %146, %594 ], [ %146, %199 ], [ %146, %202 ], [ %146, %605 ]
  %610 = phi i1 [ false, %211 ], [ true, %178 ], [ true, %209 ], [ true, %176 ], [ true, %604 ], [ true, %594 ], [ true, %199 ], [ true, %202 ], [ true, %605 ]
  store i32 %609, ptr %4, align 4, !tbaa !5
  br label %611

611:                                              ; preds = %167, %172, %608
  %612 = phi i1 [ true, %172 ], [ true, %167 ], [ %610, %608 ]
  %613 = icmp eq ptr %8, null
  br i1 %613, label %623, label %614

614:                                              ; preds = %611
  br i1 %612, label %619, label %615

615:                                              ; preds = %614
  %616 = getelementptr inbounds nuw i8, ptr %8, i32 12
  %617 = load i32, ptr %616, align 4, !tbaa !5
  %618 = add i32 %617, 1
  store i32 %618, ptr %616, align 4, !tbaa !5
  br label %638

619:                                              ; preds = %614
  %620 = getelementptr inbounds nuw i8, ptr %8, i32 16
  %621 = load i32, ptr %620, align 4, !tbaa !5
  %622 = add i32 %621, 1
  store i32 %622, ptr %620, align 4, !tbaa !5
  br label %624

623:                                              ; preds = %611
  br i1 %612, label %624, label %638

624:                                              ; preds = %164, %619, %623
  %625 = getelementptr inbounds nuw i8, ptr %1, i32 36
  %626 = load i32, ptr %625, align 4, !tbaa !27
  %627 = load i32, ptr %147, align 4, !tbaa !29
  %628 = add i32 %627, %626
  %629 = tail call fastcc i32 @write_normalized_glossary_value(ptr noundef %0, i32 noundef %628, i32 noundef %626, i32 noundef %628, ptr noundef %2, i32 noundef %3, ptr noundef %4)
  %630 = icmp eq i32 %629, 0
  br i1 %630, label %646, label %638

631:                                              ; preds = %143
  %632 = add i32 %145, 3
  %633 = icmp ugt i32 %146, -3
  %634 = icmp ugt i32 %632, %3
  %635 = or i1 %633, %634
  br i1 %635, label %646, label %636

636:                                              ; preds = %631
  %637 = getelementptr inbounds nuw i8, ptr %2, i32 %146
  store i16 23899, ptr %637, align 1
  store i32 %632, ptr %4, align 4, !tbaa !5
  br label %638

638:                                              ; preds = %636, %615, %159, %623, %624
  %639 = load i32, ptr %4, align 4, !tbaa !5
  %640 = sub i32 %639, %14
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %12) #28
  store i32 0, ptr %12, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %13) #28
  store i32 0, ptr %13, align 4, !tbaa !5
  call fastcc void @hash_content_xxh32_pair(ptr noundef nonnull %20, i32 noundef %640, ptr noundef %12, ptr noundef %13)
  %641 = load i32, ptr %12, align 4, !tbaa !5
  %642 = load i32, ptr %13, align 4, !tbaa !5
  %643 = or i32 %642, %641
  %644 = icmp eq i32 %643, 0
  %645 = select i1 %644, i32 1, i32 %641
  store i32 %645, ptr %5, align 4, !tbaa !5
  store i32 %642, ptr %6, align 4, !tbaa !5
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %13) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %12) #28
  br label %646

646:                                              ; preds = %638, %624, %154, %631, %140, %133, %125, %102, %95, %87, %64, %49, %57, %9
  %647 = phi i32 [ 0, %9 ], [ 1, %638 ], [ 0, %624 ], [ 0, %154 ], [ 0, %631 ], [ 0, %140 ], [ 0, %133 ], [ 0, %125 ], [ 0, %102 ], [ 0, %95 ], [ 0, %87 ], [ 0, %64 ], [ 0, %49 ], [ 0, %57 ]
  ret i32 %647
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define i32 @build_term_string_plan(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef %6, i32 noundef %7, i32 noundef %8, i32 noundef %9, i32 noundef %10, i32 noundef %11, i32 noundef %12, i32 noundef %13) local_unnamed_addr #8 {
  %15 = alloca i32, align 4
  %16 = alloca i32, align 4
  %17 = alloca i32, align 4
  %18 = alloca i32, align 4
  %19 = alloca i32, align 8
  %20 = alloca i32, align 4
  %21 = insertelement <8 x i32> poison, i32 %0, i64 0
  %22 = insertelement <8 x i32> %21, i32 %1, i64 1
  %23 = insertelement <8 x i32> %22, i32 %4, i64 2
  %24 = insertelement <8 x i32> %23, i32 %6, i64 3
  %25 = insertelement <8 x i32> %24, i32 %7, i64 4
  %26 = insertelement <8 x i32> %25, i32 %8, i64 5
  %27 = insertelement <8 x i32> %26, i32 %9, i64 6
  %28 = insertelement <8 x i32> %27, i32 %10, i64 7
  %29 = icmp eq <8 x i32> %28, zeroinitializer
  %30 = icmp eq i32 %11, 0
  %31 = icmp eq i32 %13, 0
  %32 = icmp eq i32 %12, 0
  %33 = bitcast <8 x i1> %29 to i8
  %34 = icmp ne i8 %33, 0
  %35 = or i1 %34, %30
  %36 = or i1 %31, %32
  %37 = or i1 %35, %36
  br i1 %37, label %273, label %38

38:                                               ; preds = %14
  %39 = add i32 %12, -1
  %40 = tail call range(i32 0, 33) i32 @llvm.ctpop.i32(i32 %12)
  %41 = icmp samesign ult i32 %40, 2
  br i1 %41, label %42, label %273

42:                                               ; preds = %38
  %43 = inttoptr i32 %0 to ptr
  %44 = inttoptr i32 %4 to ptr
  %45 = inttoptr i32 %6 to ptr
  %46 = inttoptr i32 %7 to ptr
  %47 = inttoptr i32 %8 to ptr
  %48 = inttoptr i32 %9 to ptr
  %49 = inttoptr i32 %10 to ptr
  %50 = inttoptr i32 %11 to ptr
  %51 = shl i32 %3, 1
  %52 = icmp eq i32 %3, 0
  br i1 %52, label %269, label %53

53:                                               ; preds = %42
  %54 = inttoptr i32 %1 to ptr
  %55 = getelementptr %struct.TermRowMeta, ptr %54, i32 %2
  br label %56

56:                                               ; preds = %53, %258
  %57 = phi i32 [ 0, %53 ], [ %259, %258 ]
  %58 = phi i32 [ 0, %53 ], [ %260, %258 ]
  %59 = phi i32 [ 0, %53 ], [ %265, %258 ]
  %60 = getelementptr %struct.TermRowMeta, ptr %55, i32 %59
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %15)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %16)
  %61 = load i32, ptr %60, align 4, !tbaa !70
  store i32 %61, ptr %15, align 4, !tbaa !5
  %62 = getelementptr inbounds nuw i8, ptr %60, i32 8
  %63 = load i32, ptr %62, align 4, !tbaa !71
  store i32 %63, ptr %16, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %17)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %18)
  %64 = getelementptr inbounds nuw i8, ptr %60, i32 4
  %65 = load i32, ptr %64, align 4, !tbaa !72
  store i32 %65, ptr %17, align 4, !tbaa !5
  %66 = getelementptr inbounds nuw i8, ptr %60, i32 12
  %67 = load i32, ptr %66, align 4, !tbaa !73
  store i32 %67, ptr %18, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %19)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %20)
  store i32 0, ptr %19, align 8
  store i32 0, ptr %20, align 4
  %68 = icmp eq i32 %67, 2
  br i1 %68, label %69, label %77

69:                                               ; preds = %56
  %70 = getelementptr inbounds nuw i8, ptr %43, i32 %63
  %71 = load i8, ptr %70, align 1, !tbaa !2
  %72 = icmp eq i8 %71, 34
  br i1 %72, label %73, label %77

73:                                               ; preds = %69
  %74 = getelementptr i8, ptr %70, i32 1
  %75 = load i8, ptr %74, align 1, !tbaa !2
  %76 = icmp eq i8 %75, 34
  br label %77

77:                                               ; preds = %73, %69, %56
  %78 = phi i1 [ false, %69 ], [ false, %56 ], [ %76, %73 ]
  %79 = icmp ne i32 %65, %67
  %80 = select i1 %78, i1 true, i1 %79
  br i1 %80, label %106, label %81

81:                                               ; preds = %77
  %82 = getelementptr i8, ptr %43, i32 %61
  %83 = getelementptr i8, ptr %43, i32 %63
  br label %84

84:                                               ; preds = %90, %81
  %85 = phi i32 [ 0, %81 ], [ %86, %90 ]
  %86 = add i32 %85, 8
  %87 = icmp ugt i32 %86, %65
  br i1 %87, label %88, label %90

88:                                               ; preds = %84
  %89 = icmp ult i32 %85, %65
  br i1 %89, label %96, label %106

90:                                               ; preds = %84
  %91 = getelementptr inbounds nuw i8, ptr %82, i32 %85
  %92 = load i64, ptr %91, align 1
  %93 = getelementptr inbounds nuw i8, ptr %83, i32 %85
  %94 = load i64, ptr %93, align 1
  %95 = icmp eq i64 %92, %94
  br i1 %95, label %84, label %106, !llvm.loop !74

96:                                               ; preds = %88, %96
  %97 = phi i32 [ %103, %96 ], [ %85, %88 ]
  %98 = getelementptr i8, ptr %82, i32 %97
  %99 = load i8, ptr %98, align 1, !tbaa !2
  %100 = getelementptr i8, ptr %83, i32 %97
  %101 = load i8, ptr %100, align 1, !tbaa !2
  %102 = icmp eq i8 %99, %101
  %103 = add i32 %97, 1
  %104 = icmp ne i32 %103, %65
  %105 = select i1 %102, i1 %104, i1 false
  br i1 %105, label %96, label %106, !llvm.loop !75

106:                                              ; preds = %90, %96, %88, %77
  %107 = phi i1 [ %78, %77 ], [ true, %88 ], [ %102, %96 ], [ false, %90 ]
  br label %108

108:                                              ; preds = %106, %254
  %109 = phi i32 [ %57, %106 ], [ %257, %254 ]
  %110 = phi i32 [ %58, %106 ], [ %256, %254 ]
  %111 = phi i1 [ false, %106 ], [ true, %254 ]
  %112 = phi i1 [ true, %106 ], [ false, %254 ]
  %113 = phi ptr [ %19, %106 ], [ %20, %254 ]
  %114 = phi ptr [ %17, %106 ], [ %18, %254 ]
  %115 = phi ptr [ %15, %106 ], [ %16, %254 ]
  %116 = and i1 %107, %111
  br i1 %116, label %117, label %119

117:                                              ; preds = %108
  %118 = load i32, ptr %19, align 8, !tbaa !5
  store i32 %118, ptr %20, align 4, !tbaa !5
  br label %258

119:                                              ; preds = %108
  %120 = load i32, ptr %115, align 4, !tbaa !5
  %121 = load i32, ptr %114, align 4, !tbaa !5
  %122 = add i32 %120, 1
  %123 = add i32 %121, -2
  %124 = icmp ult i32 %121, 2
  br i1 %124, label %143, label %125

125:                                              ; preds = %119
  %126 = getelementptr inbounds nuw i8, ptr %43, i32 %120
  %127 = load i8, ptr %126, align 1, !tbaa !2
  %128 = icmp eq i8 %127, 34
  br i1 %128, label %129, label %143

129:                                              ; preds = %125
  %130 = add i32 %120, -1
  %131 = add i32 %130, %121
  %132 = getelementptr inbounds nuw i8, ptr %43, i32 %131
  %133 = load i8, ptr %132, align 1, !tbaa !2
  %134 = icmp eq i8 %133, 34
  br i1 %134, label %135, label %143

135:                                              ; preds = %129, %139
  %136 = phi i32 [ %137, %139 ], [ %120, %129 ]
  %137 = add i32 %136, 1
  %138 = icmp ult i32 %137, %131
  br i1 %138, label %139, label %149

139:                                              ; preds = %135
  %140 = getelementptr inbounds nuw i8, ptr %43, i32 %137
  %141 = load i8, ptr %140, align 1, !tbaa !2
  %142 = icmp eq i8 %141, 92
  br i1 %142, label %143, label %135, !llvm.loop !76

143:                                              ; preds = %139, %119, %125, %129
  %144 = getelementptr inbounds nuw i8, ptr %43, i32 %120
  %145 = getelementptr inbounds nuw i8, ptr %44, i32 %110
  %146 = sub i32 %5, %110
  %147 = tail call fastcc i32 @decode_escaped_key(ptr noundef %144, i32 noundef %121, ptr noundef %145, i32 noundef %146)
  %148 = icmp ult i32 %147, 65536
  br i1 %148, label %151, label %267

149:                                              ; preds = %135
  %150 = icmp ugt i32 %123, 65535
  br i1 %150, label %267, label %151

151:                                              ; preds = %143, %149
  %152 = phi i32 [ %123, %149 ], [ %147, %143 ]
  %153 = phi i32 [ %122, %149 ], [ %110, %143 ]
  %154 = phi ptr [ %43, %149 ], [ %44, %143 ]
  %155 = getelementptr inbounds nuw i8, ptr %154, i32 %153
  %156 = tail call fastcc i32 @hash_content_xxh32(ptr noundef %155, i32 noundef %152, i32 noundef -2128831035)
  %157 = mul i32 %152, -2048144789
  %158 = xor i32 %156, %157
  %159 = lshr i32 %158, 16
  %160 = xor i32 %159, %158
  %161 = and i32 %160, %39
  br label %162

162:                                              ; preds = %151, %227
  %163 = phi i32 [ %230, %227 ], [ %161, %151 ]
  %164 = phi i32 [ %229, %227 ], [ 0, %151 ]
  %165 = getelementptr inbounds nuw i32, ptr %50, i32 %163
  %166 = load i32, ptr %165, align 4, !tbaa !5
  %167 = icmp eq i32 %166, 0
  br i1 %167, label %232, label %168

168:                                              ; preds = %162
  %169 = add i32 %166, -1
  %170 = icmp ult i32 %169, %109
  br i1 %170, label %171, label %267

171:                                              ; preds = %168
  %172 = getelementptr inbounds nuw i32, ptr %47, i32 %169
  %173 = load i32, ptr %172, align 4, !tbaa !5
  %174 = icmp eq i32 %173, %156
  br i1 %174, label %175, label %227

175:                                              ; preds = %171
  %176 = getelementptr inbounds nuw i16, ptr %45, i32 %169
  %177 = load i16, ptr %176, align 2, !tbaa !77
  %178 = zext i16 %177 to i32
  %179 = icmp eq i32 %152, %178
  br i1 %179, label %180, label %227

180:                                              ; preds = %175
  %181 = getelementptr inbounds nuw i32, ptr %46, i32 %169
  %182 = load i32, ptr %181, align 4, !tbaa !5
  %183 = getelementptr i8, ptr %44, i32 %182
  br label %184

184:                                              ; preds = %188, %180
  %185 = phi i32 [ 0, %180 ], [ %203, %188 ]
  %186 = sub nuw i32 %152, %185
  %187 = icmp samesign ugt i32 %186, 31
  br i1 %187, label %188, label %204

188:                                              ; preds = %184
  %189 = getelementptr inbounds nuw i8, ptr %183, i32 %185
  %190 = getelementptr inbounds nuw i8, ptr %155, i32 %185
  %191 = load <4 x i32>, ptr %189, align 1, !tbaa !2
  %192 = load <4 x i32>, ptr %190, align 1, !tbaa !2
  %193 = xor <4 x i32> %192, %191
  %194 = getelementptr inbounds nuw i8, ptr %189, i32 16
  %195 = load <4 x i32>, ptr %194, align 1, !tbaa !2
  %196 = getelementptr inbounds nuw i8, ptr %190, i32 16
  %197 = load <4 x i32>, ptr %196, align 1, !tbaa !2
  %198 = xor <4 x i32> %197, %195
  %199 = or <4 x i32> %198, %193
  %200 = bitcast <4 x i32> %199 to <16 x i8>
  %201 = tail call i32 @llvm.wasm.anytrue.v16i8(<16 x i8> %200)
  %202 = icmp eq i32 %201, 0
  %203 = add i32 %185, 32
  br i1 %202, label %184, label %227, !llvm.loop !79

204:                                              ; preds = %184, %210
  %205 = phi i32 [ %216, %210 ], [ %185, %184 ]
  %206 = sub i32 %152, %205
  %207 = icmp ugt i32 %206, 7
  br i1 %207, label %210, label %208

208:                                              ; preds = %204
  %209 = icmp ult i32 %205, %152
  br i1 %209, label %220, label %254

210:                                              ; preds = %204
  %211 = getelementptr inbounds nuw i8, ptr %183, i32 %205
  %212 = load i64, ptr %211, align 1
  %213 = getelementptr inbounds nuw i8, ptr %155, i32 %205
  %214 = load i64, ptr %213, align 1
  %215 = icmp eq i64 %212, %214
  %216 = add i32 %205, 8
  br i1 %215, label %204, label %227, !llvm.loop !80

217:                                              ; preds = %220
  %218 = add nuw i32 %221, 1
  %219 = icmp ult i32 %218, %152
  br i1 %219, label %220, label %254, !llvm.loop !81

220:                                              ; preds = %208, %217
  %221 = phi i32 [ %218, %217 ], [ %205, %208 ]
  %222 = getelementptr i8, ptr %183, i32 %221
  %223 = load i8, ptr %222, align 1, !tbaa !2
  %224 = getelementptr i8, ptr %155, i32 %221
  %225 = load i8, ptr %224, align 1, !tbaa !2
  %226 = icmp eq i8 %223, %225
  br i1 %226, label %217, label %227

227:                                              ; preds = %188, %210, %220, %175, %171
  %228 = add i32 %163, 1
  %229 = add nuw i32 %164, 1
  %230 = and i32 %228, %39
  %231 = icmp eq i32 %229, %12
  br i1 %231, label %232, label %162, !llvm.loop !82

232:                                              ; preds = %227, %162
  %233 = phi i32 [ %230, %227 ], [ %163, %162 ]
  %234 = icmp ult i32 %109, %51
  br i1 %234, label %235, label %267

235:                                              ; preds = %232
  %236 = getelementptr inbounds nuw i32, ptr %50, i32 %233
  %237 = load i32, ptr %236, align 4, !tbaa !5
  %238 = icmp eq i32 %237, 0
  br i1 %238, label %239, label %267

239:                                              ; preds = %235
  %240 = add i32 %152, %110
  %241 = icmp ugt i32 %240, %5
  br i1 %241, label %267, label %242

242:                                              ; preds = %239
  %243 = icmp eq ptr %154, %44
  br i1 %243, label %248, label %244

244:                                              ; preds = %242
  %245 = getelementptr inbounds nuw i8, ptr %44, i32 %110
  %246 = tail call fastcc i32 @copy_valid_utf8(ptr noundef %245, ptr noundef %155, i32 noundef %152)
  %247 = icmp eq i32 %246, 0
  br i1 %247, label %267, label %248

248:                                              ; preds = %244, %242
  %249 = trunc nuw i32 %152 to i16
  %250 = getelementptr inbounds nuw i16, ptr %45, i32 %109
  store i16 %249, ptr %250, align 2, !tbaa !77
  %251 = getelementptr inbounds nuw i32, ptr %46, i32 %109
  store i32 %110, ptr %251, align 4, !tbaa !5
  %252 = getelementptr inbounds nuw i32, ptr %47, i32 %109
  store i32 %156, ptr %252, align 4, !tbaa !5
  %253 = add nuw i32 %109, 1
  store i32 %253, ptr %236, align 4, !tbaa !5
  br label %254

254:                                              ; preds = %208, %217, %248
  %255 = phi i32 [ %109, %248 ], [ %169, %217 ], [ %169, %208 ]
  %256 = phi i32 [ %240, %248 ], [ %110, %217 ], [ %110, %208 ]
  %257 = phi i32 [ %253, %248 ], [ %109, %217 ], [ %109, %208 ]
  store i32 %255, ptr %113, align 4, !tbaa !5
  br i1 %112, label %108, label %258, !llvm.loop !83

258:                                              ; preds = %254, %117
  %259 = phi i32 [ %109, %117 ], [ %257, %254 ]
  %260 = phi i32 [ %110, %117 ], [ %256, %254 ]
  %261 = load i32, ptr %19, align 8, !tbaa !5
  %262 = getelementptr inbounds nuw i32, ptr %48, i32 %59
  store i32 %261, ptr %262, align 4, !tbaa !5
  %263 = load i32, ptr %20, align 4, !tbaa !5
  %264 = getelementptr inbounds nuw i32, ptr %49, i32 %59
  store i32 %263, ptr %264, align 4, !tbaa !5
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %19)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %20)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %17)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %18)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %15)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %16)
  %265 = add nuw i32 %59, 1
  %266 = icmp eq i32 %265, %3
  br i1 %266, label %269, label %56, !llvm.loop !84

267:                                              ; preds = %143, %149, %239, %235, %232, %244, %168
  %268 = phi i32 [ -3, %168 ], [ -4, %244 ], [ -2, %232 ], [ -2, %235 ], [ -2, %239 ], [ -5, %149 ], [ -4, %143 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %19)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %20)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %17)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %18)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %15)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %16)
  br label %273

269:                                              ; preds = %258, %42
  %270 = phi i32 [ 0, %42 ], [ %260, %258 ]
  %271 = phi i32 [ 0, %42 ], [ %259, %258 ]
  %272 = inttoptr i32 %13 to ptr
  store i32 %271, ptr %272, align 4, !tbaa !5
  br label %273

273:                                              ; preds = %267, %269, %14, %38
  %274 = phi i32 [ -1, %38 ], [ -1, %14 ], [ %270, %269 ], [ %268, %267 ]
  ret i32 %274
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: read)
define internal fastcc range(i32 0, 2) i32 @content_bytes_equal(ptr noundef readonly captures(none) %0, i32 noundef %1, i32 noundef %2, i32 noundef %3) unnamed_addr #18 {
  %5 = getelementptr i8, ptr %0, i32 %1
  %6 = getelementptr i8, ptr %0, i32 %2
  br label %7

7:                                                ; preds = %13, %4
  %8 = phi i32 [ 0, %4 ], [ %9, %13 ]
  %9 = add i32 %8, 8
  %10 = icmp ugt i32 %9, %3
  br i1 %10, label %11, label %13

11:                                               ; preds = %7
  %12 = icmp ult i32 %8, %3
  br i1 %12, label %22, label %29

13:                                               ; preds = %7
  %14 = getelementptr inbounds nuw i8, ptr %5, i32 %8
  %15 = load i64, ptr %14, align 1
  %16 = getelementptr inbounds nuw i8, ptr %6, i32 %8
  %17 = load i64, ptr %16, align 1
  %18 = icmp eq i64 %15, %17
  br i1 %18, label %7, label %29, !llvm.loop !74

19:                                               ; preds = %22
  %20 = add i32 %23, 1
  %21 = icmp eq i32 %20, %3
  br i1 %21, label %29, label %22, !llvm.loop !75

22:                                               ; preds = %11, %19
  %23 = phi i32 [ %20, %19 ], [ %8, %11 ]
  %24 = getelementptr i8, ptr %5, i32 %23
  %25 = load i8, ptr %24, align 1, !tbaa !2
  %26 = getelementptr i8, ptr %6, i32 %23
  %27 = load i8, ptr %26, align 1, !tbaa !2
  %28 = icmp eq i8 %25, %27
  br i1 %28, label %19, label %29

29:                                               ; preds = %13, %22, %19, %11
  %30 = phi i32 [ 1, %11 ], [ 0, %22 ], [ 1, %19 ], [ 0, %13 ]
  ret i32 %30
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc i32 @decode_escaped_key(ptr noundef readonly captures(none) %0, i32 noundef %1, ptr noundef writeonly captures(none) %2, i32 noundef %3) unnamed_addr #19 {
  %5 = tail call i32 @llvm.umin.i32(i32 %3, i32 65535)
  %6 = icmp ult i32 %1, 2
  br i1 %6, label %263, label %7

7:                                                ; preds = %4
  %8 = load i8, ptr %0, align 1, !tbaa !2
  %9 = icmp eq i8 %8, 34
  br i1 %9, label %10, label %263

10:                                               ; preds = %7
  %11 = add i32 %1, -1
  %12 = getelementptr inbounds nuw i8, ptr %0, i32 %11
  %13 = load i8, ptr %12, align 1, !tbaa !2
  %14 = icmp eq i8 %13, 34
  br i1 %14, label %15, label %263

15:                                               ; preds = %10
  %16 = icmp ugt i32 %11, 1
  br i1 %16, label %17, label %263

17:                                               ; preds = %15
  %18 = getelementptr i8, ptr %2, i32 1
  %19 = getelementptr i8, ptr %0, i32 2
  %20 = getelementptr i8, ptr %0, i32 3
  br label %21

21:                                               ; preds = %17, %259
  %22 = phi i32 [ %261, %259 ], [ 1, %17 ]
  %23 = phi i32 [ %260, %259 ], [ 0, %17 ]
  %24 = add nuw i32 %22, 1
  %25 = getelementptr inbounds nuw i8, ptr %0, i32 %22
  %26 = load i8, ptr %25, align 1, !tbaa !2
  %27 = icmp eq i8 %26, 92
  br i1 %27, label %110, label %28

28:                                               ; preds = %21
  %29 = icmp ult i8 %26, 32
  %30 = icmp eq i8 %26, 34
  %31 = or i1 %29, %30
  br i1 %31, label %263, label %32

32:                                               ; preds = %28
  %33 = icmp slt i8 %26, 0
  br i1 %33, label %34, label %88

34:                                               ; preds = %32
  %35 = add nsw i8 %26, 62
  %36 = icmp ult i8 %35, 30
  br i1 %36, label %43, label %37

37:                                               ; preds = %34
  %38 = and i8 %26, -16
  %39 = icmp eq i8 %38, -32
  br i1 %39, label %43, label %40

40:                                               ; preds = %37
  %41 = add nsw i8 %26, 16
  %42 = icmp ult i8 %41, 5
  br i1 %42, label %43, label %263

43:                                               ; preds = %40, %37, %34
  %44 = phi i1 [ false, %34 ], [ true, %37 ], [ false, %40 ]
  %45 = phi i32 [ 2, %34 ], [ 3, %37 ], [ 4, %40 ]
  %46 = add nsw i32 %45, -1
  %47 = sub i32 %11, %24
  %48 = icmp ugt i32 %46, %47
  br i1 %48, label %263, label %49

49:                                               ; preds = %43
  %50 = getelementptr inbounds nuw i8, ptr %0, i32 %24
  %51 = load i8, ptr %50, align 1, !tbaa !2
  %52 = icmp eq i8 %26, -32
  %53 = icmp ult i8 %51, -96
  %54 = select i1 %52, i1 %53, i1 false
  br i1 %54, label %263, label %55

55:                                               ; preds = %49
  %56 = icmp eq i8 %26, -19
  %57 = icmp ugt i8 %51, -97
  %58 = select i1 %56, i1 %57, i1 false
  br i1 %58, label %263, label %59

59:                                               ; preds = %55
  %60 = icmp eq i8 %26, -16
  %61 = icmp ult i8 %51, -112
  %62 = select i1 %60, i1 %61, i1 false
  br i1 %62, label %263, label %63

63:                                               ; preds = %59
  %64 = icmp eq i8 %26, -12
  %65 = icmp ugt i8 %51, -113
  %66 = select i1 %64, i1 %65, i1 false
  br i1 %66, label %263, label %82

67:                                               ; preds = %82
  %68 = icmp eq i32 %46, 1
  br i1 %68, label %85, label %69, !llvm.loop !85

69:                                               ; preds = %67
  %70 = getelementptr i8, ptr %50, i32 1
  %71 = load i8, ptr %70, align 1, !tbaa !2
  %72 = icmp slt i8 %71, -64
  br i1 %72, label %73, label %263

73:                                               ; preds = %69
  %74 = icmp eq i32 %46, 2
  br i1 %74, label %85, label %75, !llvm.loop !85

75:                                               ; preds = %73
  %76 = getelementptr i8, ptr %50, i32 2
  %77 = load i8, ptr %76, align 1, !tbaa !2
  %78 = icmp sge i8 %77, -64
  %79 = sub i32 %5, %23
  %80 = icmp ugt i32 %45, %79
  %81 = select i1 %78, i1 true, i1 %80
  br i1 %81, label %263, label %93

82:                                               ; preds = %63
  %83 = load i8, ptr %50, align 1, !tbaa !2
  %84 = icmp slt i8 %83, -64
  br i1 %84, label %67, label %263

85:                                               ; preds = %73, %67
  %86 = sub i32 %5, %23
  %87 = icmp ugt i32 %45, %86
  br i1 %87, label %263, label %93

88:                                               ; preds = %32
  %89 = icmp eq i32 %5, %23
  br i1 %89, label %263, label %90

90:                                               ; preds = %88
  %91 = getelementptr inbounds nuw i8, ptr %2, i32 %23
  store i8 %26, ptr %91, align 1, !tbaa !2
  %92 = add i32 %23, 1
  br label %259

93:                                               ; preds = %75, %85
  %94 = getelementptr inbounds nuw i8, ptr %2, i32 %23
  store i8 %26, ptr %94, align 1, !tbaa !2
  %95 = add i32 %45, %22
  %96 = getelementptr inbounds nuw i8, ptr %0, i32 %24
  %97 = load i8, ptr %96, align 1, !tbaa !2
  %98 = getelementptr i8, ptr %18, i32 %23
  store i8 %97, ptr %98, align 1, !tbaa !2
  %99 = add i32 %23, 2
  br i1 %36, label %257, label %100, !llvm.loop !86

100:                                              ; preds = %93
  %101 = getelementptr i8, ptr %19, i32 %22
  %102 = load i8, ptr %101, align 1, !tbaa !2
  %103 = getelementptr inbounds nuw i8, ptr %2, i32 %99
  store i8 %102, ptr %103, align 1, !tbaa !2
  %104 = add i32 %23, 3
  br i1 %44, label %257, label %105, !llvm.loop !86

105:                                              ; preds = %100
  %106 = getelementptr i8, ptr %20, i32 %22
  %107 = load i8, ptr %106, align 1, !tbaa !2
  %108 = getelementptr inbounds nuw i8, ptr %2, i32 %104
  store i8 %107, ptr %108, align 1, !tbaa !2
  %109 = add i32 %23, 4
  br label %257

110:                                              ; preds = %21
  %111 = icmp ult i32 %24, %11
  br i1 %111, label %112, label %263

112:                                              ; preds = %110
  %113 = add nuw i32 %22, 2
  %114 = getelementptr inbounds nuw i8, ptr %0, i32 %24
  %115 = load i8, ptr %114, align 1, !tbaa !2
  %116 = zext i8 %115 to i32
  switch i8 %115, label %263 [
    i8 34, label %221
    i8 92, label %221
    i8 47, label %221
    i8 98, label %117
    i8 102, label %118
    i8 110, label %119
    i8 114, label %120
    i8 116, label %121
    i8 117, label %122
  ]

117:                                              ; preds = %112
  br label %221

118:                                              ; preds = %112
  br label %221

119:                                              ; preds = %112
  br label %221

120:                                              ; preds = %112
  br label %221

121:                                              ; preds = %112
  br label %221

122:                                              ; preds = %112
  %123 = sub i32 %11, %113
  %124 = icmp ult i32 %123, 4
  br i1 %124, label %263, label %125

125:                                              ; preds = %122
  %126 = getelementptr inbounds nuw i8, ptr %0, i32 %113
  %127 = load i8, ptr %126, align 1, !tbaa !2
  %128 = zext i8 %127 to i32
  %129 = add i8 %127, -48
  %130 = icmp ult i8 %129, 10
  br i1 %130, label %137, label %131

131:                                              ; preds = %125
  %132 = add i8 %127, -97
  %133 = icmp ult i8 %132, 6
  br i1 %133, label %137, label %134

134:                                              ; preds = %131
  %135 = add i8 %127, -65
  %136 = icmp ult i8 %135, 6
  br i1 %136, label %137, label %263

137:                                              ; preds = %134, %131, %125
  %138 = phi i32 [ -48, %125 ], [ -87, %131 ], [ -55, %134 ]
  %139 = add nsw i32 %138, %128
  %140 = getelementptr inbounds nuw i8, ptr %126, i32 1
  %141 = load i8, ptr %140, align 1, !tbaa !2
  %142 = zext i8 %141 to i32
  %143 = add i8 %141, -48
  %144 = icmp ult i8 %143, 10
  br i1 %144, label %151, label %145

145:                                              ; preds = %137
  %146 = add i8 %141, -97
  %147 = icmp ult i8 %146, 6
  br i1 %147, label %151, label %148

148:                                              ; preds = %145
  %149 = add i8 %141, -65
  %150 = icmp ult i8 %149, 6
  br i1 %150, label %151, label %263

151:                                              ; preds = %148, %145, %137
  %152 = phi i32 [ -55, %148 ], [ -87, %145 ], [ -48, %137 ]
  %153 = add nsw i32 %152, %142
  %154 = getelementptr inbounds nuw i8, ptr %126, i32 2
  %155 = load i8, ptr %154, align 1, !tbaa !2
  %156 = zext i8 %155 to i32
  %157 = add i8 %155, -48
  %158 = icmp ult i8 %157, 10
  br i1 %158, label %165, label %159

159:                                              ; preds = %151
  %160 = add i8 %155, -97
  %161 = icmp ult i8 %160, 6
  br i1 %161, label %165, label %162

162:                                              ; preds = %159
  %163 = add i8 %155, -65
  %164 = icmp ult i8 %163, 6
  br i1 %164, label %165, label %263

165:                                              ; preds = %162, %159, %151
  %166 = phi i32 [ -55, %162 ], [ -87, %159 ], [ -48, %151 ]
  %167 = add nsw i32 %166, %156
  %168 = shl nsw i32 %139, 8
  %169 = shl nsw i32 %153, 4
  %170 = or i32 %169, %168
  %171 = or i32 %170, %167
  %172 = getelementptr inbounds nuw i8, ptr %126, i32 3
  %173 = load i8, ptr %172, align 1, !tbaa !2
  %174 = zext i8 %173 to i32
  %175 = add i8 %173, -48
  %176 = icmp ult i8 %175, 10
  br i1 %176, label %183, label %177

177:                                              ; preds = %165
  %178 = add i8 %173, -97
  %179 = icmp ult i8 %178, 6
  br i1 %179, label %183, label %180

180:                                              ; preds = %177
  %181 = add i8 %173, -65
  %182 = icmp ult i8 %181, 6
  br i1 %182, label %183, label %263

183:                                              ; preds = %165, %177, %180
  %184 = phi i32 [ -55, %180 ], [ -87, %177 ], [ -48, %165 ]
  %185 = add nsw i32 %184, %174
  %186 = shl nsw i32 %171, 4
  %187 = or i32 %185, %186
  %188 = freeze i32 %187
  %189 = icmp eq i32 %188, -1
  br i1 %189, label %263, label %190

190:                                              ; preds = %183
  %191 = add i32 %22, 6
  %192 = and i32 %188, -1024
  switch i32 %192, label %214 [
    i32 55296, label %193
    i32 56320, label %221
  ]

193:                                              ; preds = %190
  %194 = sub i32 %11, %191
  %195 = icmp ugt i32 %194, 5
  br i1 %195, label %196, label %221

196:                                              ; preds = %193
  %197 = getelementptr inbounds nuw i8, ptr %0, i32 %191
  %198 = load i8, ptr %197, align 1, !tbaa !2
  %199 = icmp eq i8 %198, 92
  br i1 %199, label %200, label %221

200:                                              ; preds = %196
  %201 = getelementptr i8, ptr %25, i32 7
  %202 = load i8, ptr %201, align 1, !tbaa !2
  %203 = icmp eq i8 %202, 117
  br i1 %203, label %204, label %221

204:                                              ; preds = %200
  %205 = getelementptr inbounds nuw i8, ptr %197, i32 2
  %206 = tail call fastcc i32 @key_hex4(ptr noundef nonnull %205)
  %207 = and i32 %206, -1024
  %208 = icmp eq i32 %207, 56320
  br i1 %208, label %209, label %221

209:                                              ; preds = %204
  %210 = shl nuw nsw i32 %188, 10
  %211 = add nsw i32 %210, -56613888
  %212 = add nsw i32 %211, %206
  %213 = add i32 %22, 12
  br label %221

214:                                              ; preds = %190
  %215 = icmp ult i32 %188, 128
  br i1 %215, label %221, label %216

216:                                              ; preds = %214
  %217 = icmp ult i32 %188, 2048
  br i1 %217, label %221, label %218

218:                                              ; preds = %216
  %219 = icmp ult i32 %188, 65536
  %220 = select i1 %219, i32 3, i32 4
  br label %221

221:                                              ; preds = %218, %190, %193, %196, %200, %204, %209, %121, %120, %119, %118, %117, %112, %112, %112, %216, %214
  %222 = phi i32 [ %188, %214 ], [ %188, %216 ], [ 9, %121 ], [ 13, %120 ], [ 10, %119 ], [ 12, %118 ], [ 8, %117 ], [ %116, %112 ], [ %116, %112 ], [ %116, %112 ], [ %212, %209 ], [ 65533, %204 ], [ 65533, %200 ], [ 65533, %196 ], [ 65533, %193 ], [ 65533, %190 ], [ %188, %218 ]
  %223 = phi i32 [ %191, %214 ], [ %191, %216 ], [ %113, %121 ], [ %113, %120 ], [ %113, %119 ], [ %113, %118 ], [ %113, %117 ], [ %113, %112 ], [ %113, %112 ], [ %113, %112 ], [ %213, %209 ], [ %191, %204 ], [ %191, %200 ], [ %191, %196 ], [ %191, %193 ], [ %191, %190 ], [ %191, %218 ]
  %224 = phi i32 [ 1, %214 ], [ 2, %216 ], [ 1, %121 ], [ 1, %120 ], [ 1, %119 ], [ 1, %118 ], [ 1, %117 ], [ 1, %112 ], [ 1, %112 ], [ 1, %112 ], [ 4, %209 ], [ 3, %204 ], [ 3, %200 ], [ 3, %196 ], [ 3, %193 ], [ 3, %190 ], [ %220, %218 ]
  %225 = sub i32 %5, %23
  %226 = icmp ugt i32 %224, %225
  br i1 %226, label %263, label %227

227:                                              ; preds = %221
  switch i32 %224, label %232 [
    i32 1, label %228
    i32 2, label %235
  ]

228:                                              ; preds = %227
  %229 = trunc i32 %222 to i8
  %230 = add i32 %23, 1
  %231 = getelementptr inbounds nuw i8, ptr %2, i32 %23
  store i8 %229, ptr %231, align 1, !tbaa !2
  br label %259

232:                                              ; preds = %227
  %233 = icmp eq i32 %224, 3
  %234 = select i1 %233, i32 224, i32 240
  br label %235

235:                                              ; preds = %232, %227
  %236 = phi i32 [ %234, %232 ], [ 192, %227 ]
  %237 = add nsw i32 %224, -1
  %238 = mul nuw nsw i32 %237, 6
  %239 = lshr i32 %222, %238
  %240 = or i32 %236, %239
  %241 = trunc i32 %240 to i8
  %242 = getelementptr inbounds nuw i8, ptr %2, i32 %23
  store i8 %241, ptr %242, align 1, !tbaa !2
  %243 = add i32 %23, 1
  br label %244

244:                                              ; preds = %235, %244
  %245 = phi i32 [ %255, %244 ], [ %243, %235 ]
  %246 = phi i32 [ %254, %244 ], [ %237, %235 ]
  %247 = mul i32 %246, 6
  %248 = add i32 %247, -6
  %249 = lshr i32 %222, %248
  %250 = trunc i32 %249 to i8
  %251 = and i8 %250, 63
  %252 = or disjoint i8 %251, -128
  %253 = getelementptr inbounds nuw i8, ptr %2, i32 %245
  store i8 %252, ptr %253, align 1, !tbaa !2
  %254 = add nsw i32 %246, -1
  %255 = add i32 %245, 1
  %256 = icmp eq i32 %254, 0
  br i1 %256, label %259, label %244, !llvm.loop !87

257:                                              ; preds = %105, %100, %93
  %258 = phi i32 [ %99, %93 ], [ %104, %100 ], [ %109, %105 ]
  br label %259, !llvm.loop !88

259:                                              ; preds = %244, %90, %257, %228
  %260 = phi i32 [ %230, %228 ], [ %258, %257 ], [ %92, %90 ], [ %255, %244 ]
  %261 = phi i32 [ %223, %228 ], [ %95, %257 ], [ %24, %90 ], [ %223, %244 ]
  %262 = icmp ult i32 %261, %11
  br i1 %262, label %21, label %263

263:                                              ; preds = %180, %162, %148, %134, %49, %55, %59, %63, %221, %112, %183, %122, %110, %85, %43, %40, %28, %259, %88, %82, %69, %75, %15, %4, %7, %10
  %264 = phi i32 [ -1, %10 ], [ -1, %7 ], [ -1, %4 ], [ 0, %15 ], [ -1, %75 ], [ -1, %69 ], [ -1, %82 ], [ -1, %88 ], [ -1, %180 ], [ -1, %162 ], [ -1, %148 ], [ -1, %134 ], [ -1, %49 ], [ -1, %55 ], [ -1, %59 ], [ -1, %63 ], [ -1, %221 ], [ -1, %112 ], [ -1, %183 ], [ -1, %122 ], [ -1, %110 ], [ -1, %85 ], [ -1, %43 ], [ -1, %40 ], [ -1, %28 ], [ %260, %259 ]
  ret i32 %264
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: read)
define internal fastcc i32 @hash_content_xxh32(ptr noundef readonly captures(address) %0, i32 noundef %1, i32 noundef range(i32 -2128831035, -1028477386) %2) unnamed_addr #18 {
  %4 = ptrtoint ptr %0 to i32
  %5 = getelementptr inbounds nuw i8, ptr %0, i32 %1
  %6 = icmp ugt i32 %1, 15
  br i1 %6, label %7, label %51

7:                                                ; preds = %3
  %8 = getelementptr inbounds i8, ptr %5, i32 -16
  %9 = add nuw nsw i32 %2, 606290984
  %10 = add i32 %2, -2048144777
  %11 = add nsw i32 %2, 1640531535
  br label %12

12:                                               ; preds = %12, %7
  %13 = phi ptr [ %0, %7 ], [ %41, %12 ]
  %14 = phi i32 [ %9, %7 ], [ %22, %12 ]
  %15 = phi i32 [ %10, %7 ], [ %28, %12 ]
  %16 = phi i32 [ %2, %7 ], [ %34, %12 ]
  %17 = phi i32 [ %11, %7 ], [ %40, %12 ]
  %18 = load i32, ptr %13, align 1
  %19 = mul i32 %18, -2048144777
  %20 = add i32 %19, %14
  %21 = tail call noundef i32 @llvm.fshl.i32(i32 %20, i32 %20, i32 13)
  %22 = mul i32 %21, -1640531535
  %23 = getelementptr inbounds nuw i8, ptr %13, i32 4
  %24 = load i32, ptr %23, align 1
  %25 = mul i32 %24, -2048144777
  %26 = add i32 %25, %15
  %27 = tail call noundef i32 @llvm.fshl.i32(i32 %26, i32 %26, i32 13)
  %28 = mul i32 %27, -1640531535
  %29 = getelementptr inbounds nuw i8, ptr %13, i32 8
  %30 = load i32, ptr %29, align 1
  %31 = mul i32 %30, -2048144777
  %32 = add i32 %31, %16
  %33 = tail call noundef i32 @llvm.fshl.i32(i32 %32, i32 %32, i32 13)
  %34 = mul i32 %33, -1640531535
  %35 = getelementptr inbounds nuw i8, ptr %13, i32 12
  %36 = load i32, ptr %35, align 1
  %37 = mul i32 %36, -2048144777
  %38 = add i32 %37, %17
  %39 = tail call noundef i32 @llvm.fshl.i32(i32 %38, i32 %38, i32 13)
  %40 = mul i32 %39, -1640531535
  %41 = getelementptr inbounds nuw i8, ptr %13, i32 16
  %42 = icmp ugt ptr %41, %8
  br i1 %42, label %43, label %12, !llvm.loop !89

43:                                               ; preds = %12
  %44 = tail call noundef i32 @llvm.fshl.i32(i32 %22, i32 %22, i32 1)
  %45 = tail call noundef i32 @llvm.fshl.i32(i32 %28, i32 %28, i32 7)
  %46 = add i32 %45, %44
  %47 = tail call noundef i32 @llvm.fshl.i32(i32 %34, i32 %34, i32 12)
  %48 = add i32 %46, %47
  %49 = tail call noundef i32 @llvm.fshl.i32(i32 %40, i32 %40, i32 18)
  %50 = add i32 %48, %49
  br label %53

51:                                               ; preds = %3
  %52 = add nuw nsw i32 %2, 374761393
  br label %53

53:                                               ; preds = %51, %43
  %54 = phi i32 [ %50, %43 ], [ %52, %51 ]
  %55 = phi ptr [ %41, %43 ], [ %0, %51 ]
  %56 = add i32 %54, %1
  %57 = getelementptr inbounds nuw i8, ptr %55, i32 4
  %58 = icmp ugt ptr %57, %5
  br i1 %58, label %59, label %84

59:                                               ; preds = %84, %53
  %60 = phi i32 [ %56, %53 ], [ %92, %84 ]
  %61 = phi ptr [ %55, %53 ], [ %85, %84 ]
  %62 = icmp ult ptr %61, %5
  br i1 %62, label %63, label %113

63:                                               ; preds = %59
  %64 = ptrtoint ptr %61 to i32
  %65 = add i32 %1, %4
  %66 = sub i32 %65, %64
  %67 = getelementptr i8, ptr %61, i32 %66
  %68 = add i32 %64, 1
  %69 = and i32 %66, 1
  %70 = icmp eq i32 %69, 0
  br i1 %70, label %79, label %71

71:                                               ; preds = %63
  %72 = load i8, ptr %61, align 1, !tbaa !2
  %73 = zext i8 %72 to i32
  %74 = mul i32 %73, 374761393
  %75 = add i32 %74, %60
  %76 = tail call noundef i32 @llvm.fshl.i32(i32 %75, i32 %75, i32 11)
  %77 = mul i32 %76, -1640531535
  %78 = getelementptr inbounds nuw i8, ptr %61, i32 1
  br label %79

79:                                               ; preds = %71, %63
  %80 = phi i32 [ poison, %63 ], [ %77, %71 ]
  %81 = phi ptr [ %61, %63 ], [ %78, %71 ]
  %82 = phi i32 [ %60, %63 ], [ %77, %71 ]
  %83 = icmp eq i32 %65, %68
  br i1 %83, label %113, label %95

84:                                               ; preds = %53, %84
  %85 = phi ptr [ %93, %84 ], [ %57, %53 ]
  %86 = phi ptr [ %85, %84 ], [ %55, %53 ]
  %87 = phi i32 [ %92, %84 ], [ %56, %53 ]
  %88 = load i32, ptr %86, align 1
  %89 = mul i32 %88, -1028477379
  %90 = add i32 %89, %87
  %91 = tail call noundef i32 @llvm.fshl.i32(i32 %90, i32 %90, i32 17)
  %92 = mul i32 %91, 668265263
  %93 = getelementptr inbounds nuw i8, ptr %85, i32 4
  %94 = icmp ugt ptr %93, %5
  br i1 %94, label %59, label %84, !llvm.loop !90

95:                                               ; preds = %79, %95
  %96 = phi ptr [ %111, %95 ], [ %81, %79 ]
  %97 = phi i32 [ %110, %95 ], [ %82, %79 ]
  %98 = load i8, ptr %96, align 1, !tbaa !2
  %99 = zext i8 %98 to i32
  %100 = mul i32 %99, 374761393
  %101 = add i32 %100, %97
  %102 = tail call noundef i32 @llvm.fshl.i32(i32 %101, i32 %101, i32 11)
  %103 = mul i32 %102, -1640531535
  %104 = getelementptr inbounds nuw i8, ptr %96, i32 1
  %105 = load i8, ptr %104, align 1, !tbaa !2
  %106 = zext i8 %105 to i32
  %107 = mul i32 %106, 374761393
  %108 = add i32 %107, %103
  %109 = tail call noundef i32 @llvm.fshl.i32(i32 %108, i32 %108, i32 11)
  %110 = mul i32 %109, -1640531535
  %111 = getelementptr inbounds nuw i8, ptr %96, i32 2
  %112 = icmp eq ptr %111, %67
  br i1 %112, label %113, label %95, !llvm.loop !91

113:                                              ; preds = %79, %95, %59
  %114 = phi i32 [ %60, %59 ], [ %80, %79 ], [ %110, %95 ]
  %115 = lshr i32 %114, 15
  %116 = xor i32 %115, %114
  %117 = mul i32 %116, -2048144777
  %118 = lshr i32 %117, 13
  %119 = xor i32 %118, %117
  %120 = mul i32 %119, -1028477379
  %121 = lshr i32 %120, 16
  %122 = xor i32 %121, %120
  ret i32 %122
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc range(i32 0, 2) i32 @copy_valid_utf8(ptr noundef writeonly captures(none) %0, ptr noundef readonly captures(none) %1, i32 noundef range(i32 0, 65536) %2) unnamed_addr #19 {
  %4 = icmp eq i32 %2, 0
  br i1 %4, label %90, label %5

5:                                                ; preds = %3, %87
  %6 = phi i32 [ %88, %87 ], [ 0, %3 ]
  %7 = add nuw nsw i32 %6, 1
  %8 = getelementptr inbounds nuw i8, ptr %1, i32 %6
  %9 = load i8, ptr %8, align 1, !tbaa !2
  %10 = getelementptr inbounds nuw i8, ptr %0, i32 %6
  store i8 %9, ptr %10, align 1, !tbaa !2
  %11 = icmp sgt i8 %9, -1
  br i1 %11, label %87, label %12, !llvm.loop !92

12:                                               ; preds = %5
  %13 = and i8 %9, -16
  %14 = icmp eq i8 %13, -32
  br i1 %14, label %15, label %35

15:                                               ; preds = %12
  %16 = sub nsw i32 %2, %7
  %17 = icmp ult i32 %16, 2
  br i1 %17, label %90, label %18

18:                                               ; preds = %15
  %19 = getelementptr inbounds nuw i8, ptr %1, i32 %7
  %20 = load i8, ptr %19, align 1, !tbaa !2
  %21 = add nuw nsw i32 %6, 2
  %22 = getelementptr inbounds nuw i8, ptr %1, i32 %21
  %23 = load i8, ptr %22, align 1, !tbaa !2
  %24 = icmp slt i8 %20, -64
  %25 = icmp slt i8 %23, -64
  %26 = select i1 %24, i1 %25, i1 false
  br i1 %26, label %27, label %90

27:                                               ; preds = %18
  %28 = icmp eq i8 %9, -32
  %29 = icmp samesign ult i8 %20, -96
  %30 = and i1 %28, %29
  br i1 %30, label %90, label %31

31:                                               ; preds = %27
  %32 = icmp eq i8 %9, -19
  %33 = icmp samesign ugt i8 %20, -97
  %34 = and i1 %32, %33
  br i1 %34, label %90, label %74, !llvm.loop !92

35:                                               ; preds = %12
  %36 = add nsw i8 %9, 62
  %37 = icmp ult i8 %36, 30
  br i1 %37, label %38, label %44

38:                                               ; preds = %35
  %39 = icmp ult i32 %7, %2
  br i1 %39, label %40, label %90

40:                                               ; preds = %38
  %41 = getelementptr inbounds nuw i8, ptr %1, i32 %7
  %42 = load i8, ptr %41, align 1, !tbaa !2
  %43 = icmp slt i8 %42, -64
  br i1 %43, label %81, label %90, !llvm.loop !92

44:                                               ; preds = %35
  %45 = add nsw i8 %9, 11
  %46 = icmp ult i8 %45, -5
  %47 = sub nsw i32 %2, %7
  %48 = icmp ult i32 %47, 3
  %49 = select i1 %46, i1 true, i1 %48
  br i1 %49, label %90, label %50

50:                                               ; preds = %44
  %51 = getelementptr inbounds nuw i8, ptr %1, i32 %7
  %52 = load i8, ptr %51, align 1, !tbaa !2
  %53 = add nuw nsw i32 %6, 2
  %54 = getelementptr inbounds nuw i8, ptr %1, i32 %53
  %55 = load i8, ptr %54, align 1, !tbaa !2
  %56 = add nuw nsw i32 %6, 3
  %57 = getelementptr inbounds nuw i8, ptr %1, i32 %56
  %58 = load i8, ptr %57, align 1, !tbaa !2
  %59 = icmp slt i8 %52, -64
  %60 = icmp slt i8 %55, -64
  %61 = select i1 %59, i1 %60, i1 false
  %62 = icmp slt i8 %58, -64
  %63 = select i1 %61, i1 %62, i1 false
  br i1 %63, label %64, label %90

64:                                               ; preds = %50
  %65 = icmp eq i8 %9, -16
  %66 = icmp samesign ult i8 %52, -112
  %67 = and i1 %65, %66
  br i1 %67, label %90, label %68

68:                                               ; preds = %64
  %69 = icmp eq i8 %9, -12
  %70 = icmp samesign ugt i8 %52, -113
  %71 = and i1 %69, %70
  br i1 %71, label %90, label %72

72:                                               ; preds = %68
  %73 = getelementptr inbounds nuw i8, ptr %0, i32 %7
  store i8 %52, ptr %73, align 1, !tbaa !2
  br label %74

74:                                               ; preds = %31, %72
  %75 = phi i32 [ %53, %72 ], [ %7, %31 ]
  %76 = phi i8 [ %55, %72 ], [ %20, %31 ]
  %77 = phi i32 [ %56, %72 ], [ %21, %31 ]
  %78 = phi i8 [ %58, %72 ], [ %23, %31 ]
  %79 = phi i32 [ 4, %72 ], [ 3, %31 ]
  %80 = getelementptr inbounds nuw i8, ptr %0, i32 %75
  store i8 %76, ptr %80, align 1, !tbaa !2
  br label %81

81:                                               ; preds = %74, %40
  %82 = phi i32 [ %7, %40 ], [ %77, %74 ]
  %83 = phi i8 [ %42, %40 ], [ %78, %74 ]
  %84 = phi i32 [ 2, %40 ], [ %79, %74 ]
  %85 = getelementptr inbounds nuw i8, ptr %0, i32 %82
  store i8 %83, ptr %85, align 1, !tbaa !2
  %86 = add nuw nsw i32 %6, %84
  br label %87

87:                                               ; preds = %81, %5
  %88 = phi i32 [ %7, %5 ], [ %86, %81 ]
  %89 = icmp ult i32 %88, %2
  br i1 %89, label %5, label %90

90:                                               ; preds = %87, %15, %31, %27, %18, %40, %38, %44, %68, %64, %50, %3
  %91 = phi i32 [ 1, %3 ], [ 0, %50 ], [ 0, %64 ], [ 0, %68 ], [ 0, %44 ], [ 0, %38 ], [ 0, %40 ], [ 0, %18 ], [ 0, %27 ], [ 0, %31 ], [ 0, %15 ], [ 1, %87 ]
  ret i32 %91
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define i32 @encode_term_lookup_index(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef %6, i32 noundef %7, i32 noundef %8, i32 noundef %9, i32 noundef %10, i32 noundef %11, i32 noundef %12, i32 noundef %13, i32 noundef %14, i32 noundef %15, i32 noundef %16) local_unnamed_addr #8 {
  %18 = insertelement <8 x i32> poison, i32 %0, i64 0
  %19 = insertelement <8 x i32> %18, i32 %2, i64 1
  %20 = insertelement <8 x i32> %19, i32 %3, i64 2
  %21 = insertelement <8 x i32> %20, i32 %4, i64 3
  %22 = insertelement <8 x i32> %21, i32 %6, i64 4
  %23 = insertelement <8 x i32> %22, i32 %7, i64 5
  %24 = insertelement <8 x i32> %23, i32 %8, i64 6
  %25 = insertelement <8 x i32> %24, i32 %9, i64 7
  %26 = icmp eq <8 x i32> %25, zeroinitializer
  %27 = insertelement <4 x i32> poison, i32 %11, i64 0
  %28 = insertelement <4 x i32> %27, i32 %13, i64 1
  %29 = insertelement <4 x i32> %28, i32 %14, i64 2
  %30 = insertelement <4 x i32> %29, i32 %15, i64 3
  %31 = icmp eq <4 x i32> %30, zeroinitializer
  %32 = add i32 %10, -65535
  %33 = icmp ult i32 %32, -65534
  %34 = add i32 %5, -65535
  %35 = icmp ult i32 %34, -65534
  %36 = icmp ult i32 %16, %10
  %37 = shufflevector <4 x i1> %31, <4 x i1> poison, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 poison, i32 poison, i32 poison, i32 poison>
  %38 = or <8 x i1> %26, %37
  %39 = shufflevector <8 x i1> %38, <8 x i1> %26, <8 x i32> <i32 0, i32 1, i32 2, i32 3, i32 12, i32 13, i32 14, i32 15>
  %40 = bitcast <8 x i1> %39 to i8
  %41 = icmp ne i8 %40, 0
  %42 = or i1 %41, %33
  %43 = or i1 %35, %36
  %44 = or i1 %42, %43
  br i1 %44, label %684, label %45

45:                                               ; preds = %17
  %46 = add i32 %16, -1
  %47 = tail call range(i32 0, 33) i32 @llvm.ctpop.i32(i32 %16)
  %48 = icmp samesign ult i32 %47, 2
  br i1 %48, label %49, label %684

49:                                               ; preds = %45
  %50 = inttoptr i32 %0 to ptr
  %51 = inttoptr i32 %2 to ptr
  %52 = inttoptr i32 %3 to ptr
  %53 = inttoptr i32 %4 to ptr
  %54 = inttoptr i32 %6 to ptr
  %55 = inttoptr i32 %7 to ptr
  %56 = inttoptr i32 %8 to ptr
  %57 = inttoptr i32 %9 to ptr
  %58 = inttoptr i32 %13 to ptr
  %59 = inttoptr i32 %14 to ptr
  %60 = inttoptr i32 %15 to ptr
  %61 = shl i32 %16, 1
  br label %62

62:                                               ; preds = %49, %183
  %63 = phi i32 [ 0, %49 ], [ %188, %183 ]
  %64 = phi i32 [ 0, %49 ], [ %187, %183 ]
  %65 = phi i32 [ 0, %49 ], [ %86, %183 ]
  %66 = phi i32 [ -1, %49 ], [ %186, %183 ]
  %67 = phi i32 [ 0, %49 ], [ %185, %183 ]
  %68 = phi i32 [ 0, %49 ], [ %184, %183 ]
  %69 = phi i32 [ 0, %49 ], [ %189, %183 ]
  %70 = getelementptr inbounds nuw i32, ptr %54, i32 %69
  %71 = load i32, ptr %70, align 4, !tbaa !5
  %72 = getelementptr inbounds nuw i32, ptr %55, i32 %69
  %73 = load i32, ptr %72, align 4, !tbaa !5
  %74 = icmp ult i32 %71, %5
  br i1 %74, label %75, label %684

75:                                               ; preds = %62
  %76 = getelementptr inbounds nuw i8, ptr %56, i32 %69
  %77 = load i8, ptr %76, align 1, !tbaa !2
  %78 = icmp ugt i8 %77, 1
  br i1 %78, label %684, label %79

79:                                               ; preds = %75
  %80 = icmp ne i8 %77, 0
  %81 = icmp ult i32 %73, %5
  %82 = select i1 %80, i1 true, i1 %81
  br i1 %82, label %83, label %684

83:                                               ; preds = %79
  %84 = xor i8 %77, 1
  %85 = zext nneg i8 %84 to i32
  %86 = add i32 %65, %85
  %87 = getelementptr inbounds nuw i32, ptr %57, i32 %69
  %88 = load i32, ptr %87, align 4, !tbaa !5
  %89 = icmp slt i32 %88, 0
  br i1 %89, label %90, label %92

90:                                               ; preds = %83
  %91 = getelementptr inbounds nuw i16, ptr %59, i32 %69
  store i16 -1, ptr %91, align 2, !tbaa !77
  br label %183

92:                                               ; preds = %83
  %93 = icmp eq i32 %88, %66
  br i1 %93, label %175, label %94

94:                                               ; preds = %92
  %95 = icmp eq i32 %68, 0
  %96 = icmp sgt i32 %88, %66
  %97 = select i1 %95, i1 %96, i1 false
  br i1 %97, label %98, label %103

98:                                               ; preds = %94
  %99 = icmp ugt i32 %63, 65534
  br i1 %99, label %684, label %100

100:                                              ; preds = %98
  %101 = add nuw nsw i32 %63, 1
  %102 = getelementptr inbounds nuw i32, ptr %58, i32 %63
  store i32 %88, ptr %102, align 4, !tbaa !5
  br label %175

103:                                              ; preds = %94
  br i1 %95, label %104, label %135

104:                                              ; preds = %103
  tail call void @llvm.memset.p0.i32(ptr align 2 %60, i8 0, i32 %61, i1 false)
  %105 = icmp eq i32 %63, 0
  br i1 %105, label %135, label %106

106:                                              ; preds = %104, %131
  %107 = phi i32 [ %132, %131 ], [ 0, %104 ]
  %108 = getelementptr inbounds nuw i32, ptr %58, i32 %107
  %109 = load i32, ptr %108, align 4, !tbaa !5
  %110 = and i32 %109, 255
  %111 = xor i32 %110, -2128831035
  %112 = mul i32 %111, 16777619
  %113 = lshr i32 %109, 8
  %114 = and i32 %113, 255
  %115 = xor i32 %112, %114
  %116 = mul i32 %115, 16777619
  %117 = lshr i32 %109, 16
  %118 = and i32 %117, 255
  %119 = xor i32 %116, %118
  %120 = mul i32 %119, 16777619
  %121 = lshr i32 %109, 24
  %122 = xor i32 %120, %121
  %123 = mul i32 %122, 16777619
  br label %124

124:                                              ; preds = %124, %106
  %125 = phi i32 [ %123, %106 ], [ %130, %124 ]
  %126 = and i32 %125, %46
  %127 = getelementptr inbounds nuw i16, ptr %60, i32 %126
  %128 = load i16, ptr %127, align 2, !tbaa !77
  %129 = icmp eq i16 %128, 0
  %130 = add i32 %126, 1
  br i1 %129, label %131, label %124, !llvm.loop !93

131:                                              ; preds = %124
  %132 = add nuw i32 %107, 1
  %133 = trunc i32 %132 to i16
  store i16 %133, ptr %127, align 2, !tbaa !77
  %134 = icmp eq i32 %132, %63
  br i1 %134, label %135, label %106, !llvm.loop !94

135:                                              ; preds = %131, %104, %103
  %136 = and i32 %88, 255
  %137 = xor i32 %136, -2128831035
  %138 = mul i32 %137, 16777619
  %139 = lshr i32 %88, 8
  %140 = and i32 %139, 255
  %141 = xor i32 %138, %140
  %142 = mul i32 %141, 16777619
  %143 = lshr i32 %88, 16
  %144 = and i32 %143, 255
  %145 = xor i32 %142, %144
  %146 = mul i32 %145, 16777619
  %147 = lshr i32 %88, 24
  %148 = xor i32 %146, %147
  %149 = mul i32 %148, 16777619
  %150 = and i32 %149, %46
  %151 = getelementptr inbounds nuw i16, ptr %60, i32 %150
  %152 = load i16, ptr %151, align 2, !tbaa !77
  %153 = icmp eq i16 %152, 0
  br i1 %153, label %160, label %167

154:                                              ; preds = %167
  %155 = add i32 %169, 1
  %156 = and i32 %155, %46
  %157 = getelementptr inbounds nuw i16, ptr %60, i32 %156
  %158 = load i16, ptr %157, align 2, !tbaa !77
  %159 = icmp eq i16 %158, 0
  br i1 %159, label %160, label %167

160:                                              ; preds = %154, %135
  %161 = phi ptr [ %151, %135 ], [ %157, %154 ]
  %162 = icmp ugt i32 %63, 65534
  br i1 %162, label %684, label %163

163:                                              ; preds = %160
  %164 = add nuw nsw i32 %63, 1
  %165 = getelementptr inbounds nuw i32, ptr %58, i32 %63
  store i32 %88, ptr %165, align 4, !tbaa !5
  %166 = trunc nuw i32 %164 to i16
  store i16 %166, ptr %161, align 2, !tbaa !77
  br label %175

167:                                              ; preds = %135, %154
  %168 = phi i16 [ %158, %154 ], [ %152, %135 ]
  %169 = phi i32 [ %156, %154 ], [ %150, %135 ]
  %170 = zext i16 %168 to i32
  %171 = add nsw i32 %170, -1
  %172 = getelementptr inbounds nuw i32, ptr %58, i32 %171
  %173 = load i32, ptr %172, align 4, !tbaa !5
  %174 = icmp eq i32 %173, %88
  br i1 %174, label %175, label %154

175:                                              ; preds = %167, %163, %100, %92
  %176 = phi i32 [ %68, %92 ], [ 0, %100 ], [ 1, %163 ], [ 1, %167 ]
  %177 = phi i32 [ %67, %92 ], [ %63, %100 ], [ %63, %163 ], [ %171, %167 ]
  %178 = phi i32 [ %66, %92 ], [ %88, %100 ], [ %88, %163 ], [ %88, %167 ]
  %179 = phi i32 [ %63, %92 ], [ %101, %100 ], [ %164, %163 ], [ %63, %167 ]
  %180 = trunc nuw i32 %177 to i16
  %181 = getelementptr inbounds nuw i16, ptr %59, i32 %69
  store i16 %180, ptr %181, align 2, !tbaa !77
  %182 = add i32 %64, 1
  br label %183

183:                                              ; preds = %175, %90
  %184 = phi i32 [ %68, %90 ], [ %176, %175 ]
  %185 = phi i32 [ %67, %90 ], [ %177, %175 ]
  %186 = phi i32 [ %66, %90 ], [ %178, %175 ]
  %187 = phi i32 [ %64, %90 ], [ %182, %175 ]
  %188 = phi i32 [ %63, %90 ], [ %179, %175 ]
  %189 = add nuw i32 %69, 1
  %190 = icmp eq i32 %189, %10
  br i1 %190, label %191, label %62, !llvm.loop !95

191:                                              ; preds = %183
  %192 = add nuw nsw i32 %5, 3
  %193 = lshr i32 %192, 2
  br label %194

194:                                              ; preds = %194, %191
  %195 = phi i32 [ 1, %191 ], [ %197, %194 ]
  %196 = icmp samesign ult i32 %195, %193
  %197 = shl i32 %195, 1
  br i1 %196, label %194, label %198, !llvm.loop !96

198:                                              ; preds = %194
  %199 = add i32 %188, 3
  %200 = lshr i32 %199, 2
  br label %201

201:                                              ; preds = %201, %198
  %202 = phi i32 [ 1, %198 ], [ %204, %201 ]
  %203 = icmp samesign ult i32 %202, %200
  %204 = shl i32 %202, 1
  br i1 %203, label %201, label %205, !llvm.loop !96

205:                                              ; preds = %201
  %206 = zext i32 %1 to i64
  %207 = add nuw nsw i64 %206, 3
  %208 = and i64 %207, 8589934588
  %209 = mul nuw nsw i32 %10, 3
  %210 = add nuw nsw i32 %209, %5
  %211 = shl nuw nsw i32 %210, 1
  %212 = add nuw nsw i32 %211, 3
  %213 = and i32 %212, 2147483644
  %214 = add nuw nsw i32 %5, 1
  %215 = add i32 %188, 1
  %216 = shl nuw nsw i32 %214, 1
  %217 = add nuw nsw i32 %216, %5
  %218 = add nuw nsw i32 %217, %10
  %219 = add i32 %218, %86
  %220 = add i32 %219, %187
  %221 = add i32 %220, %188
  %222 = add i32 %221, %215
  %223 = add i32 %222, %195
  %224 = add i32 %223, %202
  %225 = shl i32 %224, 1
  %226 = add i32 %225, 3
  %227 = and i32 %226, -4
  %228 = add nuw nsw i64 %208, 32
  %229 = zext nneg i32 %213 to i64
  %230 = add nuw nsw i64 %228, %229
  %231 = shl i32 %188, 2
  %232 = zext i32 %231 to i64
  %233 = add nuw nsw i64 %230, %232
  %234 = add i32 %227, 32
  %235 = zext i32 %234 to i64
  %236 = add nuw nsw i64 %233, 16
  %237 = add nuw nsw i64 %236, %235
  %238 = zext i32 %12 to i64
  %239 = icmp samesign ugt i64 %237, %238
  %240 = icmp samesign ugt i64 %237, 2147483647
  %241 = select i1 %239, i1 true, i1 %240
  br i1 %241, label %684, label %242

242:                                              ; preds = %205
  %243 = trunc i64 %208 to i32
  %244 = trunc i64 %233 to i32
  %245 = trunc nuw nsw i64 %237 to i32
  %246 = inttoptr i32 %11 to ptr
  store i32 927550541, ptr %246, align 4, !tbaa !5
  %247 = getelementptr inbounds nuw i8, ptr %246, i32 4
  store i32 7, ptr %247, align 4, !tbaa !5
  %248 = getelementptr inbounds nuw i8, ptr %246, i32 8
  store i32 %244, ptr %248, align 4, !tbaa !5
  %249 = getelementptr inbounds nuw i8, ptr %246, i32 12
  store i32 %234, ptr %249, align 4, !tbaa !5
  %250 = getelementptr inbounds nuw i8, ptr %246, i32 16
  store i32 %10, ptr %250, align 4, !tbaa !5
  %251 = getelementptr inbounds nuw i8, ptr %246, i32 20
  store i32 %5, ptr %251, align 4, !tbaa !5
  %252 = getelementptr inbounds nuw i8, ptr %246, i32 24
  store i32 %1, ptr %252, align 4, !tbaa !5
  %253 = getelementptr inbounds nuw i8, ptr %246, i32 28
  store i32 7, ptr %253, align 4, !tbaa !5
  %254 = getelementptr inbounds nuw i8, ptr %246, i32 32
  store i32 %188, ptr %254, align 4, !tbaa !5
  %255 = getelementptr inbounds nuw i8, ptr %246, i32 36
  store i32 %86, ptr %255, align 4, !tbaa !5
  %256 = getelementptr inbounds nuw i8, ptr %246, i32 40
  store i32 0, ptr %256, align 4, !tbaa !5
  %257 = getelementptr inbounds nuw i8, ptr %246, i32 44
  store i32 0, ptr %257, align 4, !tbaa !5
  %258 = getelementptr inbounds nuw i8, ptr %246, i32 48
  tail call void @llvm.memcpy.p0.p0.i32(ptr nonnull align 1 %258, ptr align 1 %50, i32 %1, i1 false)
  %259 = getelementptr inbounds nuw i8, ptr %258, i32 %1
  %260 = sub i32 %243, %1
  tail call void @llvm.memset.p0.i32(ptr nonnull align 1 %259, i8 0, i32 %260, i1 false)
  %261 = add i32 %243, 32
  %262 = getelementptr inbounds nuw i8, ptr %250, i32 %261
  %263 = shl nuw nsw i32 %5, 1
  %264 = add i32 %261, %263
  %265 = getelementptr inbounds nuw i8, ptr %250, i32 %264
  %266 = shl nuw nsw i32 %10, 1
  %267 = add i32 %266, %264
  %268 = getelementptr inbounds nuw i8, ptr %250, i32 %267
  %269 = add i32 %267, %266
  %270 = getelementptr inbounds nuw i8, ptr %250, i32 %269
  %271 = add i32 %269, %266
  %272 = getelementptr inbounds nuw i8, ptr %250, i32 %271
  %273 = add i32 %271, 3
  %274 = and i32 %273, -4
  %275 = sub i32 %274, %271
  tail call void @llvm.memset.p0.i32(ptr nonnull align 1 %272, i8 0, i32 %275, i1 false)
  %276 = getelementptr inbounds nuw i8, ptr %250, i32 %274
  tail call void @llvm.memcpy.p0.p0.i32(ptr nonnull align 4 %276, ptr align 4 %58, i32 %231, i1 false)
  br label %277

277:                                              ; preds = %242, %294
  %278 = phi i32 [ %296, %294 ], [ 0, %242 ]
  %279 = phi i32 [ %297, %294 ], [ 0, %242 ]
  %280 = getelementptr inbounds nuw i32, ptr %52, i32 %279
  %281 = load i32, ptr %280, align 4, !tbaa !5
  %282 = getelementptr inbounds nuw i16, ptr %51, i32 %279
  %283 = load i16, ptr %282, align 2, !tbaa !77
  %284 = zext i16 %283 to i32
  %285 = icmp ne i32 %281, %278
  %286 = add i16 %283, 1
  %287 = icmp ult i16 %286, 2
  %288 = select i1 %285, i1 true, i1 %287
  br i1 %288, label %684, label %289

289:                                              ; preds = %277
  %290 = icmp ugt i32 %278, %1
  %291 = sub nuw i32 %1, %278
  %292 = icmp ult i32 %291, %284
  %293 = select i1 %290, i1 true, i1 %292
  br i1 %293, label %684, label %294

294:                                              ; preds = %289
  %295 = getelementptr inbounds nuw i16, ptr %262, i32 %279
  store i16 %283, ptr %295, align 2, !tbaa !77
  %296 = add i32 %278, %284
  %297 = add nuw i32 %279, 1
  %298 = icmp eq i32 %297, %5
  br i1 %298, label %299, label %277, !llvm.loop !97

299:                                              ; preds = %294
  %300 = icmp eq i32 %296, %1
  br i1 %300, label %301, label %684

301:                                              ; preds = %299
  %302 = getelementptr inbounds nuw i8, ptr %250, i32 %244
  store i32 %10, ptr %302, align 4, !tbaa !5
  %303 = getelementptr inbounds nuw i8, ptr %302, i32 4
  store i32 %5, ptr %303, align 4, !tbaa !5
  %304 = getelementptr inbounds nuw i8, ptr %302, i32 8
  store i32 %195, ptr %304, align 4, !tbaa !5
  %305 = getelementptr inbounds nuw i8, ptr %302, i32 12
  store i32 %202, ptr %305, align 4, !tbaa !5
  %306 = getelementptr inbounds nuw i8, ptr %302, i32 16
  store i32 %86, ptr %306, align 4, !tbaa !5
  %307 = getelementptr inbounds nuw i8, ptr %302, i32 20
  store i32 %188, ptr %307, align 4, !tbaa !5
  %308 = getelementptr inbounds nuw i8, ptr %302, i32 24
  store i32 %187, ptr %308, align 4, !tbaa !5
  %309 = getelementptr inbounds nuw i8, ptr %302, i32 28
  store i32 7, ptr %309, align 4, !tbaa !5
  %310 = getelementptr inbounds nuw i8, ptr %302, i32 32
  %311 = add i32 %197, 32
  %312 = getelementptr inbounds nuw i8, ptr %302, i32 %311
  %313 = add i32 %311, %263
  %314 = getelementptr inbounds nuw i8, ptr %302, i32 %313
  %315 = add i32 %313, %216
  %316 = getelementptr inbounds nuw i8, ptr %302, i32 %315
  %317 = add i32 %315, %266
  %318 = getelementptr inbounds nuw i8, ptr %302, i32 %317
  %319 = add i32 %317, %216
  %320 = getelementptr inbounds nuw i8, ptr %302, i32 %319
  %321 = shl i32 %86, 1
  %322 = add i32 %319, %321
  %323 = getelementptr inbounds nuw i8, ptr %302, i32 %322
  %324 = add i32 %204, %322
  %325 = getelementptr inbounds nuw i8, ptr %302, i32 %324
  %326 = shl i32 %188, 1
  %327 = add i32 %324, %326
  %328 = getelementptr inbounds nuw i8, ptr %302, i32 %327
  %329 = shl i32 %215, 1
  %330 = add i32 %327, %329
  %331 = getelementptr inbounds nuw i8, ptr %302, i32 %330
  %332 = shl i32 %187, 1
  %333 = add i32 %330, %332
  %334 = getelementptr inbounds nuw i8, ptr %302, i32 %333
  %335 = sub i32 %234, %333
  tail call void @llvm.memset.p0.i32(ptr nonnull align 1 %334, i8 0, i32 %335, i1 false)
  tail call void @llvm.memset.p0.i32(ptr nonnull align 2 %310, i8 -1, i32 %197, i1 false)
  tail call void @llvm.memset.p0.i32(ptr nonnull align 2 %323, i8 -1, i32 %204, i1 false)
  tail call void @llvm.memset.p0.i32(ptr noundef nonnull align 2 dereferenceable(1) %314, i8 0, i32 %216, i1 false)
  tail call void @llvm.memset.p0.i32(ptr noundef nonnull align 2 dereferenceable(1) %318, i8 0, i32 %216, i1 false)
  tail call void @llvm.memset.p0.i32(ptr nonnull align 2 %328, i8 0, i32 %329, i1 false)
  %336 = add i32 %195, -1
  %337 = and i32 %5, 1
  %338 = icmp eq i32 %5, 1
  br i1 %338, label %341, label %339

339:                                              ; preds = %301
  %340 = and i32 %5, 65534
  br label %356

341:                                              ; preds = %356, %301
  %342 = phi i32 [ 0, %301 ], [ %374, %356 ]
  %343 = icmp eq i32 %337, 0
  br i1 %343, label %352, label %344

344:                                              ; preds = %341
  %345 = getelementptr inbounds nuw i32, ptr %53, i32 %342
  %346 = load i32, ptr %345, align 4, !tbaa !5
  %347 = and i32 %346, %336
  %348 = getelementptr inbounds nuw i16, ptr %310, i32 %347
  %349 = load i16, ptr %348, align 2, !tbaa !77
  %350 = getelementptr inbounds nuw i16, ptr %312, i32 %342
  store i16 %349, ptr %350, align 2, !tbaa !77
  %351 = trunc i32 %342 to i16
  store i16 %351, ptr %348, align 2, !tbaa !77
  br label %352

352:                                              ; preds = %341, %344
  %353 = icmp eq i32 %188, 0
  br i1 %353, label %377, label %354

354:                                              ; preds = %352
  %355 = add i32 %202, -1
  br label %381

356:                                              ; preds = %356, %339
  %357 = phi i32 [ 0, %339 ], [ %374, %356 ]
  %358 = phi i32 [ 0, %339 ], [ %375, %356 ]
  %359 = getelementptr inbounds nuw i32, ptr %53, i32 %357
  %360 = load i32, ptr %359, align 4, !tbaa !5
  %361 = and i32 %360, %336
  %362 = getelementptr inbounds nuw i16, ptr %310, i32 %361
  %363 = load i16, ptr %362, align 2, !tbaa !77
  %364 = getelementptr inbounds nuw i16, ptr %312, i32 %357
  store i16 %363, ptr %364, align 2, !tbaa !77
  %365 = trunc i32 %357 to i16
  store i16 %365, ptr %362, align 2, !tbaa !77
  %366 = or disjoint i32 %357, 1
  %367 = getelementptr inbounds nuw i32, ptr %53, i32 %366
  %368 = load i32, ptr %367, align 4, !tbaa !5
  %369 = and i32 %368, %336
  %370 = getelementptr inbounds nuw i16, ptr %310, i32 %369
  %371 = load i16, ptr %370, align 2, !tbaa !77
  %372 = getelementptr inbounds nuw i16, ptr %312, i32 %366
  store i16 %371, ptr %372, align 2, !tbaa !77
  %373 = trunc i32 %366 to i16
  store i16 %373, ptr %370, align 2, !tbaa !77
  %374 = add nuw i32 %357, 2
  %375 = add i32 %358, 2
  %376 = icmp eq i32 %375, %340
  br i1 %376, label %341, label %356, !llvm.loop !98

377:                                              ; preds = %381, %352
  %378 = getelementptr inbounds nuw i8, ptr %314, i32 2
  %379 = getelementptr inbounds nuw i8, ptr %318, i32 2
  %380 = getelementptr inbounds nuw i8, ptr %328, i32 2
  br label %413

381:                                              ; preds = %354, %381
  %382 = phi i32 [ 0, %354 ], [ %404, %381 ]
  %383 = getelementptr inbounds nuw i32, ptr %58, i32 %382
  %384 = load i32, ptr %383, align 4, !tbaa !5
  %385 = and i32 %384, 255
  %386 = xor i32 %385, -2128831035
  %387 = mul i32 %386, 16777619
  %388 = lshr i32 %384, 8
  %389 = and i32 %388, 255
  %390 = xor i32 %387, %389
  %391 = mul i32 %390, 16777619
  %392 = lshr i32 %384, 16
  %393 = and i32 %392, 255
  %394 = xor i32 %391, %393
  %395 = mul i32 %394, 16777619
  %396 = lshr i32 %384, 24
  %397 = xor i32 %395, %396
  %398 = mul i32 %397, 16777619
  %399 = and i32 %398, %355
  %400 = getelementptr inbounds nuw i16, ptr %323, i32 %399
  %401 = load i16, ptr %400, align 2, !tbaa !77
  %402 = getelementptr inbounds nuw i16, ptr %325, i32 %382
  store i16 %401, ptr %402, align 2, !tbaa !77
  %403 = trunc i32 %382 to i16
  store i16 %403, ptr %400, align 2, !tbaa !77
  %404 = add nuw i32 %382, 1
  %405 = icmp eq i32 %404, %188
  br i1 %405, label %377, label %381, !llvm.loop !99

406:                                              ; preds = %451
  %407 = tail call i32 @llvm.umax.i32(i32 %214, i32 2)
  %408 = add nsw i32 %407, -1
  %409 = and i32 %408, 1
  %410 = icmp ult i32 %5, 2
  br i1 %410, label %454, label %411

411:                                              ; preds = %406
  %412 = and i32 %408, -2
  br label %513

413:                                              ; preds = %377, %451
  %414 = phi i32 [ %452, %451 ], [ 0, %377 ]
  %415 = getelementptr inbounds nuw i32, ptr %54, i32 %414
  %416 = load i32, ptr %415, align 4, !tbaa !5
  %417 = trunc i32 %416 to i16
  %418 = getelementptr inbounds nuw i16, ptr %265, i32 %414
  store i16 %417, ptr %418, align 2, !tbaa !77
  %419 = getelementptr inbounds nuw i8, ptr %56, i32 %414
  %420 = load i8, ptr %419, align 1, !tbaa !2
  %421 = icmp eq i8 %420, 0
  br i1 %421, label %422, label %426

422:                                              ; preds = %413
  %423 = getelementptr inbounds nuw i32, ptr %55, i32 %414
  %424 = load i32, ptr %423, align 4, !tbaa !5
  %425 = trunc i32 %424 to i16
  br label %426

426:                                              ; preds = %413, %422
  %427 = phi i16 [ %425, %422 ], [ -1, %413 ]
  %428 = getelementptr inbounds nuw i16, ptr %268, i32 %414
  store i16 %427, ptr %428, align 2, !tbaa !77
  %429 = getelementptr inbounds nuw i16, ptr %59, i32 %414
  %430 = load i16, ptr %429, align 2, !tbaa !77
  %431 = getelementptr inbounds nuw i16, ptr %270, i32 %414
  store i16 %430, ptr %431, align 2, !tbaa !77
  %432 = load i16, ptr %418, align 2, !tbaa !77
  %433 = zext i16 %432 to i32
  %434 = getelementptr inbounds nuw i16, ptr %378, i32 %433
  %435 = load i16, ptr %434, align 2, !tbaa !77
  %436 = add i16 %435, 1
  store i16 %436, ptr %434, align 2, !tbaa !77
  %437 = load i16, ptr %428, align 2, !tbaa !77
  %438 = icmp eq i16 %437, -1
  br i1 %438, label %444, label %439

439:                                              ; preds = %426
  %440 = zext i16 %437 to i32
  %441 = getelementptr inbounds nuw i16, ptr %379, i32 %440
  %442 = load i16, ptr %441, align 2, !tbaa !77
  %443 = add i16 %442, 1
  store i16 %443, ptr %441, align 2, !tbaa !77
  br label %444

444:                                              ; preds = %439, %426
  %445 = icmp eq i16 %430, -1
  br i1 %445, label %451, label %446

446:                                              ; preds = %444
  %447 = zext i16 %430 to i32
  %448 = getelementptr inbounds nuw i16, ptr %380, i32 %447
  %449 = load i16, ptr %448, align 2, !tbaa !77
  %450 = add i16 %449, 1
  store i16 %450, ptr %448, align 2, !tbaa !77
  br label %451

451:                                              ; preds = %446, %444
  %452 = add nuw i32 %414, 1
  %453 = icmp eq i32 %452, %10
  br i1 %453, label %406, label %413, !llvm.loop !100

454:                                              ; preds = %513, %406
  %455 = phi i32 [ 1, %406 ], [ %538, %513 ]
  %456 = icmp eq i32 %409, 0
  br i1 %456, label %469, label %457

457:                                              ; preds = %454
  %458 = getelementptr inbounds nuw i16, ptr %314, i32 %455
  %459 = load i16, ptr %458, align 2, !tbaa !77
  %460 = add i32 %455, -1
  %461 = getelementptr inbounds nuw i16, ptr %314, i32 %460
  %462 = load i16, ptr %461, align 2, !tbaa !77
  %463 = add i16 %462, %459
  store i16 %463, ptr %458, align 2, !tbaa !77
  %464 = getelementptr inbounds nuw i16, ptr %318, i32 %455
  %465 = load i16, ptr %464, align 2, !tbaa !77
  %466 = getelementptr inbounds nuw i16, ptr %318, i32 %460
  %467 = load i16, ptr %466, align 2, !tbaa !77
  %468 = add i16 %467, %465
  store i16 %468, ptr %464, align 2, !tbaa !77
  br label %469

469:                                              ; preds = %454, %457
  br i1 %353, label %484, label %485

470:                                              ; preds = %541, %485
  %471 = phi i16 [ %503, %485 ], [ %556, %541 ]
  %472 = phi i32 [ 1, %485 ], [ %557, %541 ]
  %473 = icmp eq i32 %506, 0
  br i1 %473, label %484, label %474

474:                                              ; preds = %470, %474
  %475 = phi i16 [ %480, %474 ], [ %471, %470 ]
  %476 = phi i32 [ %481, %474 ], [ %472, %470 ]
  %477 = phi i32 [ %482, %474 ], [ 0, %470 ]
  %478 = getelementptr inbounds nuw i16, ptr %328, i32 %476
  %479 = load i16, ptr %478, align 2, !tbaa !77
  %480 = add i16 %475, %479
  store i16 %480, ptr %478, align 2, !tbaa !77
  %481 = add nuw i32 %476, 1
  %482 = add i32 %477, 1
  %483 = icmp eq i32 %482, %506
  br i1 %483, label %484, label %474, !llvm.loop !101

484:                                              ; preds = %470, %474, %469
  br label %601

485:                                              ; preds = %469
  %486 = tail call i32 @llvm.umax.i32(i32 %215, i32 2)
  %487 = and i32 %212, 2147483644
  %488 = trunc i64 %207 to i32
  %489 = add i32 %487, %488
  %490 = and i32 %489, -4
  %491 = getelementptr i8, ptr %246, i32 %490
  %492 = getelementptr i8, ptr %491, i32 84
  %493 = add i32 %5, %188
  %494 = mul i32 %493, 6
  %495 = getelementptr i8, ptr %492, i32 %494
  %496 = add i32 %10, %65
  %497 = zext nneg i8 %84 to i32
  %498 = add i32 %496, %497
  %499 = add i32 %498, %195
  %500 = add i32 %499, %202
  %501 = shl i32 %500, 1
  %502 = getelementptr i8, ptr %495, i32 %501
  %503 = load i16, ptr %502, align 2
  %504 = add i32 %486, -1
  %505 = add i32 %486, -2
  %506 = and i32 %504, 3
  %507 = icmp ult i32 %505, 3
  br i1 %507, label %470, label %508

508:                                              ; preds = %485
  %509 = and i32 %504, -4
  %510 = getelementptr i8, ptr %328, i32 2
  %511 = getelementptr i8, ptr %328, i32 4
  %512 = getelementptr i8, ptr %328, i32 6
  br label %541

513:                                              ; preds = %513, %411
  %514 = phi i32 [ 1, %411 ], [ %538, %513 ]
  %515 = phi i32 [ 0, %411 ], [ %539, %513 ]
  %516 = getelementptr inbounds nuw i16, ptr %314, i32 %514
  %517 = load i16, ptr %516, align 2, !tbaa !77
  %518 = add nsw i32 %514, -1
  %519 = getelementptr inbounds nuw i16, ptr %314, i32 %518
  %520 = load i16, ptr %519, align 2, !tbaa !77
  %521 = add i16 %520, %517
  store i16 %521, ptr %516, align 2, !tbaa !77
  %522 = getelementptr inbounds nuw i16, ptr %318, i32 %514
  %523 = load i16, ptr %522, align 2, !tbaa !77
  %524 = getelementptr inbounds nuw i16, ptr %318, i32 %518
  %525 = load i16, ptr %524, align 2, !tbaa !77
  %526 = add i16 %525, %523
  store i16 %526, ptr %522, align 2, !tbaa !77
  %527 = add nuw i32 %514, 1
  %528 = getelementptr inbounds nuw i16, ptr %314, i32 %527
  %529 = load i16, ptr %528, align 2, !tbaa !77
  %530 = getelementptr inbounds nuw i16, ptr %314, i32 %514
  %531 = load i16, ptr %530, align 2, !tbaa !77
  %532 = add i16 %531, %529
  store i16 %532, ptr %528, align 2, !tbaa !77
  %533 = getelementptr inbounds nuw i16, ptr %318, i32 %527
  %534 = load i16, ptr %533, align 2, !tbaa !77
  %535 = getelementptr inbounds nuw i16, ptr %318, i32 %514
  %536 = load i16, ptr %535, align 2, !tbaa !77
  %537 = add i16 %536, %534
  store i16 %537, ptr %533, align 2, !tbaa !77
  %538 = add nuw i32 %514, 2
  %539 = add nuw i32 %515, 2
  %540 = icmp eq i32 %539, %412
  br i1 %540, label %454, label %513, !llvm.loop !103

541:                                              ; preds = %541, %508
  %542 = phi i16 [ %503, %508 ], [ %556, %541 ]
  %543 = phi i32 [ 1, %508 ], [ %557, %541 ]
  %544 = phi i32 [ 0, %508 ], [ %558, %541 ]
  %545 = getelementptr inbounds nuw i16, ptr %328, i32 %543
  %546 = load i16, ptr %545, align 2, !tbaa !77
  %547 = add i16 %542, %546
  store i16 %547, ptr %545, align 2, !tbaa !77
  %548 = getelementptr i16, ptr %510, i32 %543
  %549 = load i16, ptr %548, align 2, !tbaa !77
  %550 = add i16 %547, %549
  store i16 %550, ptr %548, align 2, !tbaa !77
  %551 = getelementptr i16, ptr %511, i32 %543
  %552 = load i16, ptr %551, align 2, !tbaa !77
  %553 = add i16 %550, %552
  store i16 %553, ptr %551, align 2, !tbaa !77
  %554 = getelementptr i16, ptr %512, i32 %543
  %555 = load i16, ptr %554, align 2, !tbaa !77
  %556 = add i16 %553, %555
  store i16 %556, ptr %554, align 2, !tbaa !77
  %557 = add nuw i32 %543, 4
  %558 = add i32 %544, 4
  %559 = icmp eq i32 %558, %509
  br i1 %559, label %470, label %541, !llvm.loop !104

560:                                              ; preds = %634
  %561 = icmp ugt i32 %5, 1
  br i1 %561, label %562, label %636

562:                                              ; preds = %560
  %563 = add nsw i32 %5, -1
  %564 = icmp ult i32 %5, 17
  %565 = add nuw nsw i32 %10, %5
  %566 = icmp ult i32 %565, 8
  %567 = select i1 %564, i1 true, i1 %566
  br i1 %567, label %585, label %568

568:                                              ; preds = %562
  %569 = and i32 %563, -8
  %570 = or disjoint i32 %569, 1
  br label %571

571:                                              ; preds = %571, %568
  %572 = phi i32 [ 0, %568 ], [ %581, %571 ]
  %573 = or disjoint i32 %572, 1
  %574 = or disjoint i32 %572, 2
  %575 = getelementptr inbounds nuw i16, ptr %314, i32 %574
  %576 = load <8 x i16>, ptr %575, align 2, !tbaa !77
  %577 = getelementptr inbounds nuw i16, ptr %314, i32 %573
  store <8 x i16> %576, ptr %577, align 2, !tbaa !77
  %578 = getelementptr inbounds nuw i16, ptr %318, i32 %574
  %579 = load <8 x i16>, ptr %578, align 2, !tbaa !77
  %580 = getelementptr inbounds nuw i16, ptr %318, i32 %573
  store <8 x i16> %579, ptr %580, align 2, !tbaa !77
  %581 = add nuw i32 %572, 8
  %582 = icmp eq i32 %581, %569
  br i1 %582, label %583, label %571, !llvm.loop !105

583:                                              ; preds = %571
  %584 = icmp eq i32 %563, %569
  br i1 %584, label %636, label %585

585:                                              ; preds = %562, %583
  %586 = phi i32 [ 1, %562 ], [ %570, %583 ]
  %587 = add nsw i32 %586, 1
  %588 = and i32 %5, 1
  %589 = icmp eq i32 %588, 0
  br i1 %589, label %590, label %598

590:                                              ; preds = %585
  %591 = add nuw nsw i32 %586, 1
  %592 = getelementptr inbounds nuw i16, ptr %314, i32 %591
  %593 = load i16, ptr %592, align 2, !tbaa !77
  %594 = getelementptr inbounds nuw i16, ptr %314, i32 %586
  store i16 %593, ptr %594, align 2, !tbaa !77
  %595 = getelementptr inbounds nuw i16, ptr %318, i32 %591
  %596 = load i16, ptr %595, align 2, !tbaa !77
  %597 = getelementptr inbounds nuw i16, ptr %318, i32 %586
  store i16 %596, ptr %597, align 2, !tbaa !77
  br label %598

598:                                              ; preds = %590, %585
  %599 = phi i32 [ %586, %585 ], [ %591, %590 ]
  %600 = icmp eq i32 %5, %587
  br i1 %600, label %636, label %659

601:                                              ; preds = %484, %634
  %602 = phi i32 [ %603, %634 ], [ %10, %484 ]
  %603 = add i32 %602, -1
  %604 = getelementptr inbounds nuw i16, ptr %265, i32 %603
  %605 = load i16, ptr %604, align 2, !tbaa !77
  %606 = zext i16 %605 to i32
  %607 = trunc i32 %603 to i16
  %608 = getelementptr inbounds nuw i16, ptr %378, i32 %606
  %609 = load i16, ptr %608, align 2, !tbaa !77
  %610 = add i16 %609, -1
  store i16 %610, ptr %608, align 2, !tbaa !77
  %611 = zext i16 %610 to i32
  %612 = getelementptr inbounds nuw i16, ptr %316, i32 %611
  store i16 %607, ptr %612, align 2, !tbaa !77
  %613 = getelementptr inbounds nuw i16, ptr %268, i32 %603
  %614 = load i16, ptr %613, align 2, !tbaa !77
  %615 = icmp eq i16 %614, -1
  br i1 %615, label %623, label %616

616:                                              ; preds = %601
  %617 = zext i16 %614 to i32
  %618 = getelementptr inbounds nuw i16, ptr %379, i32 %617
  %619 = load i16, ptr %618, align 2, !tbaa !77
  %620 = add i16 %619, -1
  store i16 %620, ptr %618, align 2, !tbaa !77
  %621 = zext i16 %620 to i32
  %622 = getelementptr inbounds nuw i16, ptr %320, i32 %621
  store i16 %607, ptr %622, align 2, !tbaa !77
  br label %623

623:                                              ; preds = %616, %601
  %624 = getelementptr inbounds nuw i16, ptr %59, i32 %603
  %625 = load i16, ptr %624, align 2, !tbaa !77
  %626 = icmp eq i16 %625, -1
  br i1 %626, label %634, label %627

627:                                              ; preds = %623
  %628 = zext i16 %625 to i32
  %629 = getelementptr inbounds nuw i16, ptr %328, i32 %628
  %630 = load i16, ptr %629, align 2, !tbaa !77
  %631 = add i16 %630, 1
  store i16 %631, ptr %629, align 2, !tbaa !77
  %632 = zext i16 %630 to i32
  %633 = getelementptr inbounds nuw i16, ptr %331, i32 %632
  store i16 %607, ptr %633, align 2, !tbaa !77
  br label %634

634:                                              ; preds = %627, %623
  %635 = icmp eq i32 %603, 0
  br i1 %635, label %560, label %601, !llvm.loop !106

636:                                              ; preds = %598, %659, %583, %560
  %637 = trunc nuw i32 %10 to i16
  %638 = getelementptr inbounds nuw i16, ptr %314, i32 %5
  store i16 %637, ptr %638, align 2, !tbaa !77
  %639 = trunc i32 %86 to i16
  %640 = getelementptr inbounds nuw i16, ptr %318, i32 %5
  store i16 %639, ptr %640, align 2, !tbaa !77
  br i1 %353, label %676, label %641

641:                                              ; preds = %636
  %642 = icmp ult i32 %188, 8
  br i1 %642, label %657, label %643

643:                                              ; preds = %641
  %644 = and i32 %188, -8
  %645 = and i32 %188, 7
  br label %646

646:                                              ; preds = %646, %643
  %647 = phi i32 [ 0, %643 ], [ %653, %646 ]
  %648 = sub i32 %188, %647
  %649 = getelementptr i16, ptr %328, i32 %648
  %650 = getelementptr i8, ptr %649, i32 -16
  %651 = load <8 x i16>, ptr %650, align 2, !tbaa !77
  %652 = getelementptr i8, ptr %649, i32 -14
  store <8 x i16> %651, ptr %652, align 2, !tbaa !77
  %653 = add nuw i32 %647, 8
  %654 = icmp eq i32 %653, %644
  br i1 %654, label %655, label %646, !llvm.loop !107

655:                                              ; preds = %646
  %656 = icmp eq i32 %188, %644
  br i1 %656, label %676, label %657

657:                                              ; preds = %641, %655
  %658 = phi i32 [ %188, %641 ], [ %645, %655 ]
  br label %677

659:                                              ; preds = %598, %659
  %660 = phi i32 [ %668, %659 ], [ %599, %598 ]
  %661 = add nuw i32 %660, 1
  %662 = getelementptr inbounds nuw i16, ptr %314, i32 %661
  %663 = load i16, ptr %662, align 2, !tbaa !77
  %664 = getelementptr inbounds nuw i16, ptr %314, i32 %660
  store i16 %663, ptr %664, align 2, !tbaa !77
  %665 = getelementptr inbounds nuw i16, ptr %318, i32 %661
  %666 = load i16, ptr %665, align 2, !tbaa !77
  %667 = getelementptr inbounds nuw i16, ptr %318, i32 %660
  store i16 %666, ptr %667, align 2, !tbaa !77
  %668 = add nuw i32 %660, 2
  %669 = getelementptr inbounds nuw i16, ptr %314, i32 %668
  %670 = load i16, ptr %669, align 2, !tbaa !77
  %671 = getelementptr inbounds nuw i16, ptr %314, i32 %661
  store i16 %670, ptr %671, align 2, !tbaa !77
  %672 = getelementptr inbounds nuw i16, ptr %318, i32 %668
  %673 = load i16, ptr %672, align 2, !tbaa !77
  %674 = getelementptr inbounds nuw i16, ptr %318, i32 %661
  store i16 %673, ptr %674, align 2, !tbaa !77
  %675 = icmp eq i32 %668, %5
  br i1 %675, label %636, label %659, !llvm.loop !108

676:                                              ; preds = %677, %655, %636
  store i16 0, ptr %328, align 2, !tbaa !77
  br label %684

677:                                              ; preds = %657, %677
  %678 = phi i32 [ %682, %677 ], [ %658, %657 ]
  %679 = getelementptr i16, ptr %328, i32 %678
  %680 = getelementptr i8, ptr %679, i32 -2
  %681 = load i16, ptr %680, align 2, !tbaa !77
  store i16 %681, ptr %679, align 2, !tbaa !77
  %682 = add i32 %678, -1
  %683 = icmp eq i32 %682, 0
  br i1 %683, label %676, label %677, !llvm.loop !109

684:                                              ; preds = %160, %98, %62, %75, %79, %277, %289, %676, %299, %205, %17, %45
  %685 = phi i32 [ -1, %45 ], [ -1, %17 ], [ -4, %205 ], [ %245, %676 ], [ -5, %299 ], [ -5, %289 ], [ -5, %277 ], [ -2, %79 ], [ -2, %75 ], [ -2, %62 ], [ -3, %98 ], [ -3, %160 ]
  ret i32 %685
}

; Function Attrs: nofree nosync nounwind
define i32 @encode_term_content_token_binary_dedup(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef %6, i32 noundef %7, i32 noundef %8, i32 noundef %9) local_unnamed_addr #17 {
  %11 = alloca i32, align 4
  %12 = alloca i32, align 4
  %13 = alloca i32, align 4
  %14 = insertelement <8 x i32> poison, i32 %0, i64 0
  %15 = insertelement <8 x i32> %14, i32 %1, i64 1
  %16 = insertelement <8 x i32> %15, i32 %3, i64 2
  %17 = insertelement <8 x i32> %16, i32 %5, i64 3
  %18 = insertelement <8 x i32> %17, i32 %6, i64 4
  %19 = insertelement <8 x i32> %18, i32 %8, i64 5
  %20 = insertelement <8 x i32> %19, i32 %9, i64 6
  %21 = insertelement <8 x i32> %20, i32 %7, i64 7
  %22 = icmp eq <8 x i32> %21, zeroinitializer
  %23 = bitcast <8 x i1> %22 to i8
  %24 = icmp eq i8 %23, 0
  br i1 %24, label %25, label %198

25:                                               ; preds = %10
  %26 = add i32 %7, -1
  %27 = tail call range(i32 0, 33) i32 @llvm.ctpop.i32(i32 %7)
  %28 = icmp samesign ult i32 %27, 2
  br i1 %28, label %29, label %198

29:                                               ; preds = %25
  %30 = inttoptr i32 %0 to ptr
  %31 = inttoptr i32 %1 to ptr
  %32 = inttoptr i32 %3 to ptr
  %33 = inttoptr i32 %5 to ptr
  %34 = inttoptr i32 %6 to ptr
  %35 = inttoptr i32 %8 to ptr
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %11) #28
  store i32 0, ptr %11, align 4, !tbaa !5
  store i32 %4, ptr @last_content_capacity, align 4, !tbaa !5
  %36 = icmp eq i32 %2, 0
  br i1 %36, label %192, label %37

37:                                               ; preds = %29, %185
  %38 = phi i32 [ %187, %185 ], [ 0, %29 ]
  %39 = phi i32 [ %188, %185 ], [ 0, %29 ]
  %40 = phi i32 [ %186, %185 ], [ 0, %29 ]
  %41 = phi i32 [ %97, %185 ], [ %4, %29 ]
  %42 = shl i32 %40, 2
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %12) #28
  store i32 0, ptr %12, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %13) #28
  store i32 0, ptr %13, align 4, !tbaa !5
  %43 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %31, i32 %40
  %44 = call fastcc i32 @encode_term_content_token_binary_row(ptr noundef %30, ptr noundef %43, ptr noundef %32, i32 noundef %41, ptr noundef %11, ptr noundef %12, ptr noundef %13, i32 noundef 0, ptr noundef null)
  %45 = icmp eq i32 %44, 0
  br i1 %45, label %46, label %96

46:                                               ; preds = %37, %93
  %47 = phi i32 [ %55, %93 ], [ %41, %37 ]
  store i32 %38, ptr %11, align 4, !tbaa !5
  %48 = icmp ugt i32 %47, 2147483646
  br i1 %48, label %190, label %49

49:                                               ; preds = %46
  %50 = lshr i32 %47, 1
  %51 = tail call i32 @llvm.umax.i32(i32 %50, i32 1048576)
  %52 = xor i32 %51, 2147483647
  %53 = icmp samesign ugt i32 %47, %52
  %54 = add nuw i32 %51, %47
  %55 = select i1 %53, i32 2147483647, i32 %54
  %56 = add nuw i32 %47, 7
  %57 = and i32 %56, -8
  %58 = xor i32 %57, -1
  %59 = icmp ugt i32 %3, %58
  br i1 %59, label %190, label %60

60:                                               ; preds = %49
  %61 = add i32 %57, %3
  %62 = load i32, ptr @heap_ptr, align 4, !tbaa !5
  %63 = icmp eq i32 %62, %61
  br i1 %63, label %64, label %190

64:                                               ; preds = %60
  %65 = sub i32 %55, %57
  %66 = add i32 %65, 7
  %67 = icmp eq i32 %61, 0
  br i1 %67, label %68, label %69

68:                                               ; preds = %64
  store i32 ptrtoint (ptr @__heap_base to i32), ptr @heap_ptr, align 4, !tbaa !5
  br label %69

69:                                               ; preds = %68, %64
  %70 = phi i32 [ ptrtoint (ptr @__heap_base to i32), %68 ], [ %61, %64 ]
  %71 = and i32 %66, -8
  %72 = add i32 %70, 7
  %73 = and i32 %72, -8
  %74 = xor i32 %71, -1
  %75 = icmp ugt i32 %73, %74
  br i1 %75, label %190, label %76

76:                                               ; preds = %69
  %77 = add i32 %73, %71
  %78 = tail call i32 @llvm.wasm.memory.size.i32(i32 0)
  %79 = lshr i32 %77, 16
  %80 = and i32 %77, 65528
  %81 = icmp ne i32 %80, 0
  %82 = zext i1 %81 to i32
  %83 = add nuw nsw i32 %79, %82
  %84 = icmp ugt i32 %83, %78
  br i1 %84, label %85, label %89

85:                                               ; preds = %76
  %86 = sub nuw nsw i32 %83, %78
  %87 = tail call i32 @llvm.wasm.memory.grow.i32(i32 0, i32 %86)
  %88 = icmp slt i32 %87, 0
  br i1 %88, label %190, label %89

89:                                               ; preds = %85, %76
  store i32 %77, ptr @heap_ptr, align 4, !tbaa !5
  %90 = icmp ne i32 %73, 0
  %91 = icmp eq i32 %73, %61
  %92 = and i1 %90, %91
  br i1 %92, label %93, label %190

93:                                               ; preds = %89
  store i32 %55, ptr @last_content_capacity, align 4, !tbaa !5
  %94 = call fastcc i32 @encode_term_content_token_binary_row(ptr noundef %30, ptr noundef %43, ptr noundef %32, i32 noundef %55, ptr noundef %11, ptr noundef %12, ptr noundef %13, i32 noundef 0, ptr noundef null)
  %95 = icmp eq i32 %94, 0
  br i1 %95, label %46, label %96, !llvm.loop !110

96:                                               ; preds = %93, %37
  %97 = phi i32 [ %41, %37 ], [ %55, %93 ]
  %98 = load i32, ptr %11, align 4, !tbaa !5
  %99 = sub i32 %98, %38
  %100 = load i32, ptr %12, align 4, !tbaa !5
  %101 = load i32, ptr %13, align 4, !tbaa !5
  %102 = mul i32 %101, -1640531535
  %103 = xor i32 %102, %100
  %104 = lshr i32 %103, 16
  %105 = xor i32 %104, %103
  %106 = and i32 %105, %26
  %107 = getelementptr i8, ptr %32, i32 %38
  br label %108

108:                                              ; preds = %96, %156
  %109 = phi i32 [ %106, %96 ], [ %159, %156 ]
  %110 = phi i32 [ 0, %96 ], [ %158, %156 ]
  %111 = getelementptr inbounds nuw i32, ptr %34, i32 %109
  %112 = load i32, ptr %111, align 4, !tbaa !5
  %113 = icmp eq i32 %112, 0
  br i1 %113, label %170, label %114

114:                                              ; preds = %108
  %115 = add i32 %112, -1
  %116 = icmp ult i32 %115, %40
  br i1 %116, label %117, label %190

117:                                              ; preds = %114
  %118 = shl i32 %115, 4
  %119 = getelementptr inbounds nuw i8, ptr %33, i32 %118
  %120 = getelementptr inbounds nuw i8, ptr %119, i32 8
  %121 = load i32, ptr %120, align 4, !tbaa !5
  %122 = icmp eq i32 %121, %100
  br i1 %122, label %123, label %156

123:                                              ; preds = %117
  %124 = getelementptr inbounds nuw i8, ptr %119, i32 12
  %125 = load i32, ptr %124, align 4, !tbaa !5
  %126 = icmp eq i32 %125, %101
  br i1 %126, label %127, label %156

127:                                              ; preds = %123
  %128 = getelementptr inbounds nuw i8, ptr %119, i32 4
  %129 = load i32, ptr %128, align 4, !tbaa !5
  %130 = icmp eq i32 %129, %99
  br i1 %130, label %131, label %156

131:                                              ; preds = %127
  %132 = load i32, ptr %119, align 4, !tbaa !5
  %133 = getelementptr i8, ptr %32, i32 %132
  br label %134

134:                                              ; preds = %140, %131
  %135 = phi i32 [ 0, %131 ], [ %136, %140 ]
  %136 = add i32 %135, 8
  %137 = icmp ugt i32 %136, %99
  br i1 %137, label %138, label %140

138:                                              ; preds = %134
  %139 = icmp ult i32 %135, %99
  br i1 %139, label %149, label %161

140:                                              ; preds = %134
  %141 = getelementptr inbounds nuw i8, ptr %133, i32 %135
  %142 = load i64, ptr %141, align 1
  %143 = getelementptr inbounds nuw i8, ptr %107, i32 %135
  %144 = load i64, ptr %143, align 1
  %145 = icmp eq i64 %142, %144
  br i1 %145, label %134, label %156, !llvm.loop !74

146:                                              ; preds = %149
  %147 = add i32 %150, 1
  %148 = icmp eq i32 %147, %99
  br i1 %148, label %161, label %149, !llvm.loop !75

149:                                              ; preds = %138, %146
  %150 = phi i32 [ %147, %146 ], [ %135, %138 ]
  %151 = getelementptr i8, ptr %133, i32 %150
  %152 = load i8, ptr %151, align 1, !tbaa !2
  %153 = getelementptr i8, ptr %107, i32 %150
  %154 = load i8, ptr %153, align 1, !tbaa !2
  %155 = icmp eq i8 %152, %154
  br i1 %155, label %146, label %156

156:                                              ; preds = %140, %149, %127, %123, %117
  %157 = add i32 %109, 1
  %158 = add nuw i32 %110, 1
  %159 = and i32 %157, %26
  %160 = icmp eq i32 %158, %7
  br i1 %160, label %170, label %108, !llvm.loop !111

161:                                              ; preds = %138, %146
  %162 = getelementptr inbounds nuw i32, ptr %33, i32 %42
  store i32 %132, ptr %162, align 4, !tbaa !5
  %163 = getelementptr inbounds nuw i8, ptr %162, i32 4
  store i32 %99, ptr %163, align 4, !tbaa !5
  %164 = getelementptr inbounds nuw i8, ptr %162, i32 8
  store i32 %100, ptr %164, align 4, !tbaa !5
  %165 = getelementptr inbounds nuw i8, ptr %162, i32 12
  store i32 %101, ptr %165, align 4, !tbaa !5
  %166 = getelementptr inbounds nuw i32, ptr %35, i32 %115
  %167 = load i32, ptr %166, align 4, !tbaa !5
  %168 = getelementptr inbounds nuw i32, ptr %35, i32 %40
  store i32 %167, ptr %168, align 4, !tbaa !5
  store i32 %38, ptr %11, align 4, !tbaa !5
  %169 = add nuw i32 %40, 1
  br label %185

170:                                              ; preds = %156, %108
  %171 = phi i32 [ %159, %156 ], [ %109, %108 ]
  %172 = getelementptr inbounds nuw i32, ptr %34, i32 %171
  %173 = load i32, ptr %172, align 4, !tbaa !5
  %174 = icmp ne i32 %173, 0
  %175 = icmp eq i32 %39, -1
  %176 = select i1 %174, i1 true, i1 %175
  br i1 %176, label %190, label %177

177:                                              ; preds = %170
  %178 = getelementptr inbounds nuw i32, ptr %33, i32 %42
  store i32 %38, ptr %178, align 4, !tbaa !5
  %179 = getelementptr inbounds nuw i8, ptr %178, i32 4
  store i32 %99, ptr %179, align 4, !tbaa !5
  %180 = getelementptr inbounds nuw i8, ptr %178, i32 8
  store i32 %100, ptr %180, align 4, !tbaa !5
  %181 = getelementptr inbounds nuw i8, ptr %178, i32 12
  store i32 %101, ptr %181, align 4, !tbaa !5
  %182 = getelementptr inbounds nuw i32, ptr %35, i32 %40
  store i32 %39, ptr %182, align 4, !tbaa !5
  %183 = add nuw i32 %40, 1
  store i32 %183, ptr %172, align 4, !tbaa !5
  %184 = add nuw i32 %39, 1
  br label %185

185:                                              ; preds = %161, %177
  %186 = phi i32 [ %169, %161 ], [ %183, %177 ]
  %187 = phi i32 [ %38, %161 ], [ %98, %177 ]
  %188 = phi i32 [ %39, %161 ], [ %184, %177 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %13) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %12) #28
  %189 = icmp eq i32 %186, %2
  br i1 %189, label %192, label %37, !llvm.loop !112

190:                                              ; preds = %170, %85, %69, %89, %60, %49, %46, %114
  %191 = phi i32 [ -3, %114 ], [ -2, %46 ], [ -2, %49 ], [ -2, %60 ], [ -2, %89 ], [ -2, %69 ], [ -2, %85 ], [ -3, %170 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %13) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %12) #28
  br label %196

192:                                              ; preds = %185, %29
  %193 = phi i32 [ 0, %29 ], [ %187, %185 ]
  %194 = phi i32 [ 0, %29 ], [ %188, %185 ]
  %195 = inttoptr i32 %9 to ptr
  store i32 %194, ptr %195, align 4, !tbaa !5
  br label %196

196:                                              ; preds = %190, %192
  %197 = phi i32 [ %193, %192 ], [ %191, %190 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %11) #28
  br label %198

198:                                              ; preds = %10, %25, %196
  %199 = phi i32 [ %197, %196 ], [ -1, %25 ], [ -1, %10 ]
  ret i32 %199
}

; Function Attrs: nofree nosync nounwind
define i32 @parse_and_encode_term_bank_token_binary_dedup(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef %6, i32 noundef %7, i32 noundef %8, i32 noundef %9, i32 noundef %10, i32 noundef %11, i32 noundef %12, i32 noundef %13, i32 noundef %14, i32 noundef %15, i32 noundef %16, i32 noundef %17, i32 noundef %18, i32 noundef %19, i32 noundef %20, i32 noundef %21, i32 noundef %22, i32 noundef %23, i32 noundef %24, i32 noundef %25, i32 noundef %26, i32 noundef %27, i32 noundef %28, i32 noundef %29, i32 noundef %30, i32 noundef %31, i32 noundef %32, i32 noundef %33, i32 noundef %34, i32 noundef %35, i32 noundef %36, i32 noundef %37, i32 noundef %38) local_unnamed_addr #17 {
  %40 = alloca i32, align 4
  %41 = alloca [4 x i32], align 16
  %42 = alloca %struct.TermBankCursor, align 4
  %43 = alloca i32, align 4
  %44 = alloca i32, align 4
  %45 = alloca i32, align 4
  %46 = alloca i32, align 4
  %47 = alloca i32, align 4
  %48 = alloca i32, align 4
  %49 = alloca i32, align 4
  %50 = alloca i32, align 8
  %51 = alloca i32, align 4
  %52 = alloca i32, align 4
  %53 = alloca i32, align 4
  %54 = alloca i32, align 4
  %55 = alloca i32, align 4
  %56 = insertelement <16 x i32> poison, i32 %0, i64 0
  %57 = insertelement <16 x i32> %56, i32 %1, i64 1
  %58 = insertelement <16 x i32> %57, i32 %2, i64 2
  %59 = insertelement <16 x i32> %58, i32 %3, i64 3
  %60 = insertelement <16 x i32> %59, i32 %4, i64 4
  %61 = insertelement <16 x i32> %60, i32 %6, i64 5
  %62 = insertelement <16 x i32> %61, i32 %7, i64 6
  %63 = insertelement <16 x i32> %62, i32 %9, i64 7
  %64 = insertelement <16 x i32> %63, i32 %10, i64 8
  %65 = insertelement <16 x i32> %64, i32 %11, i64 9
  %66 = insertelement <16 x i32> %65, i32 %12, i64 10
  %67 = insertelement <16 x i32> %66, i32 %13, i64 11
  %68 = insertelement <16 x i32> %67, i32 %15, i64 12
  %69 = insertelement <16 x i32> %68, i32 %16, i64 13
  %70 = insertelement <16 x i32> %69, i32 %17, i64 14
  %71 = insertelement <16 x i32> %70, i32 %18, i64 15
  %72 = icmp eq <16 x i32> %71, zeroinitializer
  %73 = insertelement <8 x i32> poison, i32 %19, i64 0
  %74 = insertelement <8 x i32> %73, i32 %20, i64 1
  %75 = insertelement <8 x i32> %74, i32 %22, i64 2
  %76 = insertelement <8 x i32> %75, i32 %23, i64 3
  %77 = insertelement <8 x i32> %76, i32 %24, i64 4
  %78 = insertelement <8 x i32> %77, i32 %25, i64 5
  %79 = insertelement <8 x i32> %78, i32 %26, i64 6
  %80 = insertelement <8 x i32> %79, i32 %27, i64 7
  %81 = icmp eq <8 x i32> %80, zeroinitializer
  %82 = icmp eq i32 %8, 0
  %83 = shufflevector <8 x i1> %81, <8 x i1> poison, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison, i32 poison>
  %84 = or <16 x i1> %72, %83
  %85 = shufflevector <16 x i1> %84, <16 x i1> %72, <16 x i32> <i32 0, i32 1, i32 2, i32 3, i32 4, i32 5, i32 6, i32 7, i32 24, i32 25, i32 26, i32 27, i32 28, i32 29, i32 30, i32 31>
  %86 = bitcast <16 x i1> %85 to i16
  %87 = icmp ne i16 %86, 0
  %88 = or i1 %87, %82
  br i1 %88, label %933, label %89

89:                                               ; preds = %39
  %90 = add i32 %8, -1
  %91 = tail call range(i32 0, 33) i32 @llvm.ctpop.i32(i32 %8)
  %92 = icmp samesign ugt i32 %91, 1
  %93 = icmp eq i32 %21, 0
  %94 = or i1 %92, %93
  br i1 %94, label %933, label %95

95:                                               ; preds = %89
  %96 = add i32 %21, -1
  %97 = tail call range(i32 0, 33) i32 @llvm.ctpop.i32(i32 %21)
  %98 = icmp samesign ult i32 %97, 2
  br i1 %98, label %99, label %933

99:                                               ; preds = %95
  %100 = icmp eq i32 %31, 0
  %101 = icmp ne i32 %30, 0
  %102 = xor i1 %101, %100
  br i1 %102, label %103, label %933

103:                                              ; preds = %99
  %104 = icmp ne i32 %31, 0
  %105 = and i32 %29, 1
  %106 = icmp eq i32 %105, 0
  %107 = and i1 %106, %104
  br i1 %107, label %933, label %108

108:                                              ; preds = %103
  %109 = and i32 %29, 8
  %110 = icmp eq i32 %109, 0
  br i1 %110, label %120, label %111

111:                                              ; preds = %108
  %112 = icmp ne i32 %33, 0
  %113 = icmp ne i32 %35, 0
  %114 = and i1 %112, %113
  %115 = icmp ne i32 %34, 0
  %116 = and i1 %115, %114
  %117 = tail call range(i32 0, 33) i32 @llvm.ctpop.i32(i32 %34)
  %118 = icmp samesign ult i32 %117, 2
  %119 = select i1 %116, i1 %118, i1 false
  br i1 %119, label %120, label %933

120:                                              ; preds = %111, %108
  %121 = inttoptr i32 %32 to ptr
  %122 = icmp ne i32 %32, 0
  br i1 %122, label %123, label %124

123:                                              ; preds = %120
  tail call void @llvm.memset.p0.i32(ptr noundef nonnull align 4 dereferenceable(20) %121, i8 0, i32 20, i1 false), !tbaa !5
  br label %124

124:                                              ; preds = %123, %120
  %125 = inttoptr i32 %0 to ptr
  %126 = inttoptr i32 %2 to ptr
  %127 = inttoptr i32 %4 to ptr
  %128 = inttoptr i32 %6 to ptr
  %129 = inttoptr i32 %7 to ptr
  %130 = inttoptr i32 %33 to ptr
  %131 = inttoptr i32 %35 to ptr
  %132 = inttoptr i32 %9 to ptr
  %133 = inttoptr i32 %11 to ptr
  %134 = inttoptr i32 %37 to ptr
  %135 = inttoptr i32 %13 to ptr
  %136 = inttoptr i32 %15 to ptr
  %137 = inttoptr i32 %16 to ptr
  %138 = inttoptr i32 %17 to ptr
  %139 = inttoptr i32 %18 to ptr
  %140 = inttoptr i32 %19 to ptr
  %141 = inttoptr i32 %20 to ptr
  %142 = inttoptr i32 %24 to ptr
  %143 = inttoptr i32 %25 to ptr
  %144 = inttoptr i32 %26 to ptr
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %40) #28
  store i32 0, ptr %40, align 4, !tbaa !5
  %145 = icmp eq i32 %28, 0
  %146 = zext i1 %145 to i32
  %147 = and i32 %29, 4
  %148 = icmp ne i32 %147, 0
  call void @llvm.lifetime.start.p0(i64 16, ptr nonnull %41) #28
  %149 = tail call i32 @llvm.usub.sat.i32(i32 %34, i32 1)
  store i32 %3, ptr @last_parse_capacity, align 4, !tbaa !5
  store i32 %5, ptr @last_content_capacity, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 28, ptr nonnull %42) #28
  store ptr %125, ptr %42, align 4, !tbaa !45
  %150 = getelementptr inbounds nuw i8, ptr %42, i32 4
  %151 = inttoptr i32 %30 to ptr
  store ptr %151, ptr %150, align 4, !tbaa !50
  %152 = getelementptr inbounds nuw i8, ptr %42, i32 8
  store i32 %1, ptr %152, align 4, !tbaa !51
  %153 = getelementptr inbounds nuw i8, ptr %42, i32 12
  %154 = tail call i32 @llvm.umax.i32(i32 %31, i32 1)
  store i32 %154, ptr %153, align 4, !tbaa !52
  %155 = getelementptr inbounds nuw i8, ptr %42, i32 16
  store i32 0, ptr %155, align 4, !tbaa !53
  %156 = getelementptr inbounds nuw i8, ptr %42, i32 20
  store i32 0, ptr %156, align 4, !tbaa !54
  %157 = getelementptr inbounds nuw i8, ptr %42, i32 24
  store i32 0, ptr %157, align 4, !tbaa !55
  %158 = call fastcc i32 @next_term_bank(ptr noundef %42)
  %159 = getelementptr i8, ptr %126, i32 -28
  %160 = icmp sgt i32 %158, 0
  br i1 %160, label %161, label %912

161:                                              ; preds = %124
  %162 = icmp ne i32 %28, 0
  %163 = zext i1 %162 to i32
  %164 = icmp ne i32 %36, 0
  %165 = zext i1 %164 to i32
  %166 = icmp eq i32 %37, 0
  %167 = getelementptr inbounds nuw i8, ptr %121, i32 4
  %168 = getelementptr i8, ptr %125, i32 1
  %169 = and i32 %29, 2
  %170 = icmp eq i32 %169, 0
  %171 = shl i32 %3, 1
  %172 = icmp eq i32 %34, 0
  %173 = getelementptr inbounds nuw i8, ptr %121, i32 8
  br label %174

174:                                              ; preds = %161, %901
  %175 = phi i32 [ 0, %161 ], [ %902, %901 ]
  %176 = phi i32 [ 0, %161 ], [ %907, %901 ]
  %177 = phi i32 [ 0, %161 ], [ %503, %901 ]
  %178 = phi i32 [ 0, %161 ], [ %504, %901 ]
  %179 = phi i32 [ 0, %161 ], [ %908, %901 ]
  %180 = phi i32 [ 0, %161 ], [ %906, %901 ]
  %181 = phi i32 [ %146, %161 ], [ %227, %901 ]
  %182 = phi i32 [ 0, %161 ], [ %905, %901 ]
  %183 = phi i32 [ 0, %161 ], [ %904, %901 ]
  %184 = phi i32 [ %5, %161 ], [ %903, %901 ]
  %185 = icmp eq i32 %179, %3
  br i1 %185, label %186, label %188

186:                                              ; preds = %174
  %187 = inttoptr i32 %12 to ptr
  store i32 %3, ptr %187, align 4, !tbaa !5
  br label %931

188:                                              ; preds = %174
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %43) #28
  store i32 0, ptr %43, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %44) #28
  store i32 -1, ptr %44, align 4, !tbaa !5
  %189 = icmp ne i32 %179, 0
  %190 = and i1 %148, %189
  br i1 %190, label %191, label %199

191:                                              ; preds = %188
  %192 = icmp eq i32 %182, 0
  br i1 %192, label %193, label %199

193:                                              ; preds = %191
  %194 = getelementptr %struct.TermRowMeta, ptr %159, i32 %179
  %195 = load i32, ptr %194, align 4, !tbaa !29
  %196 = icmp ugt i32 %195, 511
  %197 = select i1 %196, ptr %44, ptr null
  %198 = zext i1 %196 to i32
  br label %199

199:                                              ; preds = %193, %191, %188
  %200 = phi ptr [ null, %188 ], [ %44, %191 ], [ %197, %193 ]
  %201 = phi i32 [ 0, %188 ], [ 4, %191 ], [ %198, %193 ]
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %45) #28
  %202 = load i32, ptr %156, align 4, !tbaa !54
  %203 = load i32, ptr %157, align 4, !tbaa !55
  %204 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %126, i32 %179
  %205 = call fastcc i32 @parse_row_single_pass(ptr noundef %125, i32 noundef %202, i32 noundef %203, ptr noundef %204, i32 noundef %163, ptr noundef %43, ptr noundef %126, i32 noundef %179, ptr noundef %200, i32 noundef %201, i32 noundef %165, ptr noundef nonnull %45)
  %206 = icmp eq i32 %205, 0
  br i1 %206, label %207, label %208

207:                                              ; preds = %199
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %45) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %44) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %43) #28
  br label %931

208:                                              ; preds = %199
  %209 = load i32, ptr %44, align 4, !tbaa !5
  br i1 %166, label %212, label %210

210:                                              ; preds = %208
  %211 = getelementptr inbounds nuw i32, ptr %134, i32 %179
  store i32 %209, ptr %211, align 4, !tbaa !5
  br label %212

212:                                              ; preds = %208, %210
  %213 = icmp ne i32 %209, -1
  %214 = and i1 %122, %213
  br i1 %214, label %215, label %218

215:                                              ; preds = %212
  %216 = load i32, ptr %167, align 4, !tbaa !5
  %217 = add i32 %216, 1
  store i32 %217, ptr %167, align 4, !tbaa !5
  br label %218

218:                                              ; preds = %215, %212
  br i1 %190, label %219, label %223

219:                                              ; preds = %218
  %220 = icmp eq i32 %209, -1
  br i1 %220, label %221, label %223

221:                                              ; preds = %219
  %222 = call i32 @llvm.usub.sat.i32(i32 %182, i32 1)
  br label %223

223:                                              ; preds = %221, %219, %218
  %224 = phi i32 [ %182, %218 ], [ 4, %219 ], [ %222, %221 ]
  %225 = getelementptr inbounds nuw i8, ptr %204, i32 56
  %226 = load i32, ptr %225, align 4, !tbaa !113
  %227 = or i32 %226, %181
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %46)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %47)
  %228 = load i32, ptr %204, align 4, !tbaa !70
  store i32 %228, ptr %46, align 4, !tbaa !5
  %229 = getelementptr inbounds nuw i8, ptr %204, i32 8
  %230 = load i32, ptr %229, align 4, !tbaa !71
  store i32 %230, ptr %47, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %48)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %49)
  %231 = getelementptr inbounds nuw i8, ptr %204, i32 4
  %232 = load i32, ptr %231, align 4, !tbaa !72
  store i32 %232, ptr %48, align 4, !tbaa !5
  %233 = getelementptr inbounds nuw i8, ptr %204, i32 12
  %234 = load i32, ptr %233, align 4, !tbaa !73
  store i32 %234, ptr %49, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %50)
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %51)
  store i32 0, ptr %50, align 8
  store i32 0, ptr %51, align 4
  %235 = icmp eq i32 %234, 2
  br i1 %235, label %236, label %244

236:                                              ; preds = %223
  %237 = getelementptr inbounds nuw i8, ptr %125, i32 %230
  %238 = load i8, ptr %237, align 1, !tbaa !2
  %239 = icmp eq i8 %238, 34
  br i1 %239, label %240, label %244

240:                                              ; preds = %236
  %241 = getelementptr i8, ptr %237, i32 1
  %242 = load i8, ptr %241, align 1, !tbaa !2
  %243 = icmp eq i8 %242, 34
  br label %244

244:                                              ; preds = %240, %236, %223
  %245 = phi i1 [ false, %236 ], [ false, %223 ], [ %243, %240 ]
  %246 = icmp ne i32 %232, %234
  %247 = select i1 %245, i1 true, i1 %246
  br i1 %247, label %294, label %248

248:                                              ; preds = %244
  %249 = getelementptr i8, ptr %125, i32 %228
  %250 = getelementptr i8, ptr %125, i32 %230
  br label %251

251:                                              ; preds = %255, %248
  %252 = phi i32 [ 0, %248 ], [ %270, %255 ]
  %253 = sub nuw i32 %232, %252
  %254 = icmp ugt i32 %253, 31
  br i1 %254, label %255, label %271

255:                                              ; preds = %251
  %256 = getelementptr inbounds nuw i8, ptr %249, i32 %252
  %257 = getelementptr inbounds nuw i8, ptr %250, i32 %252
  %258 = load <4 x i32>, ptr %256, align 1, !tbaa !2
  %259 = load <4 x i32>, ptr %257, align 1, !tbaa !2
  %260 = xor <4 x i32> %259, %258
  %261 = getelementptr inbounds nuw i8, ptr %256, i32 16
  %262 = load <4 x i32>, ptr %261, align 1, !tbaa !2
  %263 = getelementptr inbounds nuw i8, ptr %257, i32 16
  %264 = load <4 x i32>, ptr %263, align 1, !tbaa !2
  %265 = xor <4 x i32> %264, %262
  %266 = or <4 x i32> %265, %260
  %267 = bitcast <4 x i32> %266 to <16 x i8>
  %268 = call i32 @llvm.wasm.anytrue.v16i8(<16 x i8> %267)
  %269 = icmp eq i32 %268, 0
  %270 = add i32 %252, 32
  br i1 %269, label %251, label %294, !llvm.loop !79

271:                                              ; preds = %251, %277
  %272 = phi i32 [ %283, %277 ], [ %252, %251 ]
  %273 = sub i32 %232, %272
  %274 = icmp ugt i32 %273, 7
  br i1 %274, label %277, label %275

275:                                              ; preds = %271
  %276 = icmp ult i32 %272, %232
  br i1 %276, label %284, label %294

277:                                              ; preds = %271
  %278 = getelementptr inbounds nuw i8, ptr %249, i32 %272
  %279 = load i64, ptr %278, align 1
  %280 = getelementptr inbounds nuw i8, ptr %250, i32 %272
  %281 = load i64, ptr %280, align 1
  %282 = icmp eq i64 %279, %281
  %283 = add i32 %272, 8
  br i1 %282, label %271, label %294, !llvm.loop !80

284:                                              ; preds = %275, %284
  %285 = phi i32 [ %291, %284 ], [ %272, %275 ]
  %286 = getelementptr i8, ptr %249, i32 %285
  %287 = load i8, ptr %286, align 1, !tbaa !2
  %288 = getelementptr i8, ptr %250, i32 %285
  %289 = load i8, ptr %288, align 1, !tbaa !2
  %290 = icmp eq i8 %287, %289
  %291 = add nuw i32 %285, 1
  %292 = icmp ult i32 %291, %232
  %293 = select i1 %290, i1 %292, i1 false
  br i1 %293, label %284, label %294, !llvm.loop !81

294:                                              ; preds = %255, %277, %284, %275, %244
  %295 = phi i1 [ %245, %244 ], [ true, %275 ], [ %290, %284 ], [ false, %277 ], [ false, %255 ]
  %296 = add i32 %179, -1
  %297 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %126, i32 %296
  %298 = load i32, ptr %45, align 4
  br label %299

299:                                              ; preds = %294, %498
  %300 = phi i32 [ %177, %294 ], [ %501, %498 ]
  %301 = phi i32 [ %178, %294 ], [ %500, %498 ]
  %302 = phi i1 [ false, %294 ], [ true, %498 ]
  %303 = phi i1 [ true, %294 ], [ false, %498 ]
  %304 = phi ptr [ %50, %294 ], [ %51, %498 ]
  %305 = phi ptr [ %48, %294 ], [ %49, %498 ]
  %306 = phi ptr [ %46, %294 ], [ %47, %498 ]
  %307 = phi i32 [ 0, %294 ], [ 1, %498 ]
  %308 = and i1 %295, %302
  br i1 %308, label %309, label %311

309:                                              ; preds = %299
  %310 = load i32, ptr %50, align 8, !tbaa !5
  store i32 %310, ptr %51, align 4, !tbaa !5
  br label %502

311:                                              ; preds = %299
  %312 = load i32, ptr %306, align 4, !tbaa !5
  %313 = load i32, ptr %305, align 4, !tbaa !5
  %314 = add i32 %313, -2
  %315 = icmp ult i32 %314, 33
  %316 = select i1 %189, i1 %315, i1 false
  br i1 %316, label %317, label %375

317:                                              ; preds = %311
  %318 = select i1 %303, i32 4, i32 12
  %319 = getelementptr inbounds nuw i8, ptr %297, i32 %318
  %320 = load i32, ptr %319, align 4, !tbaa !5
  %321 = icmp eq i32 %313, %320
  br i1 %321, label %322, label %377

322:                                              ; preds = %317
  %323 = select i1 %303, i32 0, i32 8
  %324 = getelementptr inbounds nuw i8, ptr %297, i32 %323
  %325 = load i32, ptr %324, align 4, !tbaa !5
  %326 = getelementptr i8, ptr %168, i32 %312
  %327 = getelementptr i8, ptr %168, i32 %325
  br label %328

328:                                              ; preds = %332, %322
  %329 = phi i32 [ 0, %322 ], [ %347, %332 ]
  %330 = sub nuw i32 %314, %329
  %331 = icmp ugt i32 %330, 31
  br i1 %331, label %332, label %348

332:                                              ; preds = %328
  %333 = getelementptr inbounds nuw i8, ptr %326, i32 %329
  %334 = getelementptr inbounds nuw i8, ptr %327, i32 %329
  %335 = load <4 x i32>, ptr %333, align 1, !tbaa !2
  %336 = load <4 x i32>, ptr %334, align 1, !tbaa !2
  %337 = xor <4 x i32> %336, %335
  %338 = getelementptr inbounds nuw i8, ptr %333, i32 16
  %339 = load <4 x i32>, ptr %338, align 1, !tbaa !2
  %340 = getelementptr inbounds nuw i8, ptr %334, i32 16
  %341 = load <4 x i32>, ptr %340, align 1, !tbaa !2
  %342 = xor <4 x i32> %341, %339
  %343 = or <4 x i32> %342, %337
  %344 = bitcast <4 x i32> %343 to <16 x i8>
  %345 = call i32 @llvm.wasm.anytrue.v16i8(<16 x i8> %344)
  %346 = icmp eq i32 %345, 0
  %347 = add i32 %329, 32
  br i1 %346, label %328, label %375, !llvm.loop !79

348:                                              ; preds = %328, %354
  %349 = phi i32 [ %360, %354 ], [ %329, %328 ]
  %350 = sub i32 %314, %349
  %351 = icmp ugt i32 %350, 7
  br i1 %351, label %354, label %352

352:                                              ; preds = %348
  %353 = icmp ult i32 %349, %314
  br i1 %353, label %364, label %371

354:                                              ; preds = %348
  %355 = getelementptr inbounds nuw i8, ptr %326, i32 %349
  %356 = load i64, ptr %355, align 1
  %357 = getelementptr inbounds nuw i8, ptr %327, i32 %349
  %358 = load i64, ptr %357, align 1
  %359 = icmp eq i64 %356, %358
  %360 = add i32 %349, 8
  br i1 %359, label %348, label %375, !llvm.loop !80

361:                                              ; preds = %364
  %362 = add nuw i32 %365, 1
  %363 = icmp ult i32 %362, %314
  br i1 %363, label %364, label %371, !llvm.loop !81

364:                                              ; preds = %352, %361
  %365 = phi i32 [ %362, %361 ], [ %349, %352 ]
  %366 = getelementptr i8, ptr %326, i32 %365
  %367 = load i8, ptr %366, align 1, !tbaa !2
  %368 = getelementptr i8, ptr %327, i32 %365
  %369 = load i8, ptr %368, align 1, !tbaa !2
  %370 = icmp eq i8 %367, %369
  br i1 %370, label %361, label %375

371:                                              ; preds = %361, %352
  %372 = select i1 %303, ptr %139, ptr %140
  %373 = getelementptr inbounds nuw i32, ptr %372, i32 %296
  %374 = load i32, ptr %373, align 4, !tbaa !5
  br label %498

375:                                              ; preds = %332, %354, %364, %311
  %376 = icmp ult i32 %313, 2
  br i1 %376, label %895, label %377

377:                                              ; preds = %317, %375
  %378 = add i32 %312, 1
  %379 = shl nuw nsw i32 1, %307
  %380 = and i32 %298, %379
  %381 = icmp eq i32 %380, 0
  br i1 %381, label %393, label %382

382:                                              ; preds = %377
  br i1 %170, label %895, label %383

383:                                              ; preds = %382
  %384 = getelementptr inbounds nuw i8, ptr %125, i32 %312
  %385 = getelementptr inbounds nuw i8, ptr %135, i32 %301
  %386 = sub i32 %14, %301
  %387 = call fastcc i32 @decode_escaped_key(ptr noundef %384, i32 noundef %313, ptr noundef %385, i32 noundef %386)
  %388 = icmp sgt i32 %387, -1
  br i1 %388, label %389, label %895

389:                                              ; preds = %383
  br i1 %122, label %390, label %393

390:                                              ; preds = %389
  %391 = load i32, ptr %121, align 4, !tbaa !5
  %392 = add i32 %391, 1
  store i32 %392, ptr %121, align 4, !tbaa !5
  br label %393

393:                                              ; preds = %390, %389, %377
  %394 = phi i32 [ %314, %377 ], [ %387, %389 ], [ %387, %390 ]
  %395 = phi i32 [ %378, %377 ], [ %301, %389 ], [ %301, %390 ]
  %396 = phi ptr [ %125, %377 ], [ %135, %389 ], [ %135, %390 ]
  %397 = icmp ugt i32 %394, 65535
  br i1 %397, label %895, label %398

398:                                              ; preds = %393
  %399 = getelementptr inbounds nuw i8, ptr %396, i32 %395
  %400 = call fastcc i32 @hash_content_xxh32(ptr noundef %399, i32 noundef %394, i32 noundef -2128831035)
  %401 = mul i32 %394, -2048144789
  %402 = xor i32 %400, %401
  %403 = lshr i32 %402, 16
  %404 = xor i32 %403, %402
  %405 = and i32 %404, %96
  br label %406

406:                                              ; preds = %398, %471
  %407 = phi i32 [ %474, %471 ], [ %405, %398 ]
  %408 = phi i32 [ %473, %471 ], [ 0, %398 ]
  %409 = getelementptr inbounds nuw i32, ptr %141, i32 %407
  %410 = load i32, ptr %409, align 4, !tbaa !5
  %411 = icmp eq i32 %410, 0
  br i1 %411, label %476, label %412

412:                                              ; preds = %406
  %413 = add i32 %410, -1
  %414 = icmp ult i32 %413, %300
  br i1 %414, label %415, label %897

415:                                              ; preds = %412
  %416 = getelementptr inbounds nuw i32, ptr %138, i32 %413
  %417 = load i32, ptr %416, align 4, !tbaa !5
  %418 = icmp eq i32 %417, %400
  br i1 %418, label %419, label %471

419:                                              ; preds = %415
  %420 = getelementptr inbounds nuw i16, ptr %136, i32 %413
  %421 = load i16, ptr %420, align 2, !tbaa !77
  %422 = zext i16 %421 to i32
  %423 = icmp eq i32 %394, %422
  br i1 %423, label %424, label %471

424:                                              ; preds = %419
  %425 = getelementptr inbounds nuw i32, ptr %137, i32 %413
  %426 = load i32, ptr %425, align 4, !tbaa !5
  %427 = getelementptr i8, ptr %135, i32 %426
  br label %428

428:                                              ; preds = %432, %424
  %429 = phi i32 [ 0, %424 ], [ %447, %432 ]
  %430 = sub nuw i32 %394, %429
  %431 = icmp ugt i32 %430, 31
  br i1 %431, label %432, label %448

432:                                              ; preds = %428
  %433 = getelementptr inbounds nuw i8, ptr %427, i32 %429
  %434 = getelementptr inbounds nuw i8, ptr %399, i32 %429
  %435 = load <4 x i32>, ptr %433, align 1, !tbaa !2
  %436 = load <4 x i32>, ptr %434, align 1, !tbaa !2
  %437 = xor <4 x i32> %436, %435
  %438 = getelementptr inbounds nuw i8, ptr %433, i32 16
  %439 = load <4 x i32>, ptr %438, align 1, !tbaa !2
  %440 = getelementptr inbounds nuw i8, ptr %434, i32 16
  %441 = load <4 x i32>, ptr %440, align 1, !tbaa !2
  %442 = xor <4 x i32> %441, %439
  %443 = or <4 x i32> %442, %437
  %444 = bitcast <4 x i32> %443 to <16 x i8>
  %445 = call i32 @llvm.wasm.anytrue.v16i8(<16 x i8> %444)
  %446 = icmp eq i32 %445, 0
  %447 = add i32 %429, 32
  br i1 %446, label %428, label %471, !llvm.loop !79

448:                                              ; preds = %428, %454
  %449 = phi i32 [ %460, %454 ], [ %429, %428 ]
  %450 = sub i32 %394, %449
  %451 = icmp ugt i32 %450, 7
  br i1 %451, label %454, label %452

452:                                              ; preds = %448
  %453 = icmp ult i32 %449, %394
  br i1 %453, label %464, label %498

454:                                              ; preds = %448
  %455 = getelementptr inbounds nuw i8, ptr %427, i32 %449
  %456 = load i64, ptr %455, align 1
  %457 = getelementptr inbounds nuw i8, ptr %399, i32 %449
  %458 = load i64, ptr %457, align 1
  %459 = icmp eq i64 %456, %458
  %460 = add i32 %449, 8
  br i1 %459, label %448, label %471, !llvm.loop !80

461:                                              ; preds = %464
  %462 = add nuw i32 %465, 1
  %463 = icmp ult i32 %462, %394
  br i1 %463, label %464, label %498, !llvm.loop !81

464:                                              ; preds = %452, %461
  %465 = phi i32 [ %462, %461 ], [ %449, %452 ]
  %466 = getelementptr i8, ptr %427, i32 %465
  %467 = load i8, ptr %466, align 1, !tbaa !2
  %468 = getelementptr i8, ptr %399, i32 %465
  %469 = load i8, ptr %468, align 1, !tbaa !2
  %470 = icmp eq i8 %467, %469
  br i1 %470, label %461, label %471

471:                                              ; preds = %432, %454, %464, %419, %415
  %472 = add nuw i32 %407, 1
  %473 = add nuw i32 %408, 1
  %474 = and i32 %472, %96
  %475 = icmp eq i32 %473, %21
  br i1 %475, label %476, label %406, !llvm.loop !114

476:                                              ; preds = %471, %406
  %477 = phi i32 [ %474, %471 ], [ %407, %406 ]
  %478 = icmp ult i32 %300, %171
  br i1 %478, label %479, label %895

479:                                              ; preds = %476
  %480 = getelementptr inbounds nuw i32, ptr %141, i32 %477
  %481 = load i32, ptr %480, align 4, !tbaa !5
  %482 = icmp eq i32 %481, 0
  br i1 %482, label %483, label %895

483:                                              ; preds = %479
  %484 = add i32 %394, %301
  %485 = icmp ugt i32 %484, %14
  br i1 %485, label %895, label %486

486:                                              ; preds = %483
  %487 = icmp eq ptr %396, %135
  br i1 %487, label %492, label %488

488:                                              ; preds = %486
  %489 = getelementptr inbounds nuw i8, ptr %135, i32 %301
  %490 = call fastcc i32 @copy_valid_utf8(ptr noundef %489, ptr noundef %399, i32 noundef %394)
  %491 = icmp eq i32 %490, 0
  br i1 %491, label %895, label %492

492:                                              ; preds = %488, %486
  %493 = trunc nuw i32 %394 to i16
  %494 = getelementptr inbounds nuw i16, ptr %136, i32 %300
  store i16 %493, ptr %494, align 2, !tbaa !77
  %495 = getelementptr inbounds nuw i32, ptr %137, i32 %300
  store i32 %301, ptr %495, align 4, !tbaa !5
  %496 = getelementptr inbounds nuw i32, ptr %138, i32 %300
  store i32 %400, ptr %496, align 4, !tbaa !5
  %497 = add nuw i32 %300, 1
  store i32 %497, ptr %480, align 4, !tbaa !5
  br label %498

498:                                              ; preds = %452, %461, %492, %371
  %499 = phi i32 [ %300, %492 ], [ %374, %371 ], [ %413, %461 ], [ %413, %452 ]
  %500 = phi i32 [ %484, %492 ], [ %301, %371 ], [ %301, %461 ], [ %301, %452 ]
  %501 = phi i32 [ %497, %492 ], [ %300, %371 ], [ %300, %461 ], [ %300, %452 ]
  store i32 %499, ptr %304, align 4, !tbaa !5
  br i1 %303, label %299, label %502, !llvm.loop !115

502:                                              ; preds = %498, %309
  %503 = phi i32 [ %300, %309 ], [ %501, %498 ]
  %504 = phi i32 [ %301, %309 ], [ %500, %498 ]
  %505 = load i32, ptr %50, align 8, !tbaa !5
  %506 = getelementptr inbounds nuw i32, ptr %139, i32 %179
  store i32 %505, ptr %506, align 4, !tbaa !5
  %507 = load i32, ptr %51, align 4, !tbaa !5
  %508 = getelementptr inbounds nuw i32, ptr %140, i32 %179
  store i32 %507, ptr %508, align 4, !tbaa !5
  %509 = zext i1 %295 to i8
  %510 = getelementptr inbounds nuw i8, ptr %142, i32 %179
  store i8 %509, ptr %510, align 1, !tbaa !2
  %511 = getelementptr inbounds nuw i8, ptr %204, i32 32
  %512 = load i32, ptr %511, align 4, !tbaa !116
  %513 = icmp ult i32 %512, %202
  br i1 %513, label %514, label %895

514:                                              ; preds = %502, %520
  %515 = phi i32 [ %522, %520 ], [ %512, %502 ]
  %516 = icmp eq i32 %515, %202
  br i1 %516, label %523, label %517

517:                                              ; preds = %514
  %518 = getelementptr inbounds nuw i8, ptr %125, i32 %515
  %519 = load i8, ptr %518, align 1, !tbaa !2
  switch i8 %519, label %520 [
    i8 125, label %523
    i8 93, label %523
    i8 44, label %523
    i8 32, label %523
    i8 13, label %523
    i8 10, label %523
  ]

520:                                              ; preds = %517
  %521 = icmp eq i8 %519, 9
  %522 = add i32 %515, 1
  br i1 %521, label %523, label %514

523:                                              ; preds = %520, %517, %517, %517, %517, %517, %517, %514
  %524 = phi i32 [ %515, %517 ], [ %515, %517 ], [ %515, %517 ], [ %515, %517 ], [ %515, %517 ], [ %515, %517 ], [ %515, %520 ], [ %202, %514 ]
  %525 = icmp eq i32 %524, %512
  br i1 %525, label %895, label %526

526:                                              ; preds = %523
  %527 = sub i32 %524, %512
  %528 = icmp eq i32 %527, 4
  br i1 %528, label %529, label %545

529:                                              ; preds = %526
  %530 = getelementptr inbounds nuw i8, ptr %125, i32 %512
  %531 = load i8, ptr %530, align 1, !tbaa !2
  %532 = icmp eq i8 %531, 110
  br i1 %532, label %533, label %545

533:                                              ; preds = %529
  %534 = getelementptr i8, ptr %530, i32 1
  %535 = load i8, ptr %534, align 1, !tbaa !2
  %536 = icmp eq i8 %535, 117
  br i1 %536, label %537, label %545

537:                                              ; preds = %533
  %538 = getelementptr i8, ptr %530, i32 2
  %539 = load i8, ptr %538, align 1, !tbaa !2
  %540 = icmp eq i8 %539, 108
  br i1 %540, label %541, label %545

541:                                              ; preds = %537
  %542 = getelementptr i8, ptr %530, i32 3
  %543 = load i8, ptr %542, align 1, !tbaa !2
  %544 = icmp eq i8 %543, 108
  br i1 %544, label %596, label %545

545:                                              ; preds = %541, %537, %533, %529, %526
  %546 = icmp ult i32 %512, %524
  br i1 %546, label %547, label %554

547:                                              ; preds = %545
  %548 = getelementptr inbounds nuw i8, ptr %125, i32 %512
  %549 = load i8, ptr %548, align 1, !tbaa !2
  %550 = icmp ne i8 %549, 45
  %551 = xor i1 %550, true
  %552 = zext i1 %551 to i32
  %553 = add nuw i32 %512, %552
  br label %554

554:                                              ; preds = %547, %545
  %555 = phi i1 [ true, %545 ], [ %550, %547 ]
  %556 = phi i32 [ %512, %545 ], [ %553, %547 ]
  %557 = icmp ult i32 %556, %524
  br i1 %557, label %558, label %895

558:                                              ; preds = %554
  %559 = getelementptr inbounds nuw i8, ptr %125, i32 %556
  %560 = load i8, ptr %559, align 1, !tbaa !2
  %561 = add i8 %560, -58
  %562 = icmp ult i8 %561, -10
  br i1 %562, label %895, label %563

563:                                              ; preds = %558
  %564 = icmp eq i8 %560, 48
  %565 = add nuw i32 %556, 1
  %566 = icmp ult i32 %565, %524
  %567 = and i1 %566, %564
  br i1 %567, label %895, label %568

568:                                              ; preds = %563
  %569 = select i1 %555, i32 2147483647, i32 -2147483648
  br label %570

570:                                              ; preds = %583, %568
  %571 = phi i32 [ %586, %583 ], [ %556, %568 ]
  %572 = phi i32 [ %585, %583 ], [ 0, %568 ]
  %573 = getelementptr inbounds nuw i8, ptr %125, i32 %571
  %574 = load i8, ptr %573, align 1, !tbaa !2
  %575 = add i8 %574, -58
  %576 = icmp ult i8 %575, -10
  br i1 %576, label %895, label %577

577:                                              ; preds = %570
  %578 = zext nneg i8 %574 to i32
  %579 = add nsw i32 %578, -48
  %580 = sub nuw i32 %569, %579
  %581 = udiv i32 %580, 10
  %582 = icmp ugt i32 %572, %581
  br i1 %582, label %895, label %583

583:                                              ; preds = %577
  %584 = mul nuw nsw i32 %572, 10
  %585 = add nuw i32 %579, %584
  %586 = add i32 %571, 1
  %587 = icmp eq i32 %586, %524
  br i1 %587, label %588, label %570, !llvm.loop !117

588:                                              ; preds = %583
  %589 = sub i32 0, %585
  %590 = select i1 %555, i32 %585, i32 %589
  %591 = icmp eq i32 %590, 0
  br i1 %591, label %592, label %596

592:                                              ; preds = %588
  %593 = getelementptr inbounds nuw i8, ptr %125, i32 %512
  %594 = load i8, ptr %593, align 1, !tbaa !2
  %595 = icmp eq i8 %594, 45
  br i1 %595, label %895, label %596

596:                                              ; preds = %541, %592, %588
  %597 = phi i32 [ 0, %592 ], [ %590, %588 ], [ 0, %541 ]
  %598 = getelementptr inbounds nuw i32, ptr %143, i32 %179
  store i32 %597, ptr %598, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %52) #28
  store i32 -1, ptr %52, align 4, !tbaa !5
  %599 = getelementptr inbounds nuw i8, ptr %204, i32 44
  %600 = load i32, ptr %599, align 4, !tbaa !118
  %601 = icmp eq i32 %600, -1
  br i1 %601, label %613, label %602

602:                                              ; preds = %596
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %53) #28
  store i32 0, ptr %53, align 4, !tbaa !5
  %603 = call fastcc i32 @scan_scalar_span(ptr noundef nonnull %125, i32 noundef %202, i32 noundef %600, ptr noundef %53)
  %604 = icmp eq i32 %603, 0
  br i1 %604, label %611, label %605

605:                                              ; preds = %602
  %606 = load i32, ptr %53, align 4, !tbaa !5
  %607 = call fastcc i32 @parse_int32_token(ptr noundef nonnull %125, i32 noundef %600, i32 noundef %606, i32 noundef -1, ptr noundef %52)
  %608 = icmp eq i32 %607, 0
  br i1 %608, label %611, label %609

609:                                              ; preds = %605
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %53) #28
  %610 = load i32, ptr %52, align 4, !tbaa !5
  br label %613

611:                                              ; preds = %602, %605
  %612 = inttoptr i32 %12 to ptr
  store i32 %179, ptr %612, align 4, !tbaa !5
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %53) #28
  br label %899

613:                                              ; preds = %609, %596
  %614 = phi i32 [ %610, %609 ], [ -1, %596 ]
  %615 = getelementptr inbounds nuw i32, ptr %144, i32 %179
  store i32 %614, ptr %615, align 4, !tbaa !5
  %616 = shl i32 %179, 2
  br i1 %110, label %650, label %617

617:                                              ; preds = %613
  %618 = call fastcc i32 @raw_term_content_hash(ptr noundef nonnull %125, ptr noundef nonnull %204)
  %619 = getelementptr inbounds nuw i32, ptr %131, i32 %179
  store i32 %618, ptr %619, align 4, !tbaa !5
  br i1 %172, label %706, label %620

620:                                              ; preds = %617, %646
  %621 = phi i32 [ %647, %646 ], [ %618, %617 ]
  %622 = phi i32 [ %648, %646 ], [ 0, %617 ]
  %623 = and i32 %621, %149
  %624 = getelementptr inbounds nuw i32, ptr %130, i32 %623
  %625 = load i32, ptr %624, align 4, !tbaa !5
  %626 = icmp eq i32 %625, 0
  br i1 %626, label %627, label %629

627:                                              ; preds = %620
  %628 = add i32 %179, 1
  store i32 %628, ptr %624, align 4, !tbaa !5
  br label %706

629:                                              ; preds = %620
  %630 = add i32 %625, -1
  %631 = icmp ult i32 %630, %179
  br i1 %631, label %632, label %899

632:                                              ; preds = %629
  %633 = getelementptr inbounds nuw i32, ptr %131, i32 %630
  %634 = load i32, ptr %633, align 4, !tbaa !5
  %635 = icmp eq i32 %634, %618
  br i1 %635, label %636, label %646

636:                                              ; preds = %632
  %637 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %126, i32 %630
  %638 = icmp eq i32 %630, %209
  %639 = zext i1 %638 to i32
  %640 = call fastcc i32 @raw_term_content_tokens_equal(ptr noundef nonnull %125, ptr noundef nonnull %204, ptr noundef %637, i32 noundef %639)
  %641 = icmp eq i32 %640, 0
  br i1 %641, label %646, label %642

642:                                              ; preds = %636
  br i1 %122, label %643, label %687

643:                                              ; preds = %642
  %644 = load i32, ptr %173, align 4, !tbaa !5
  %645 = add i32 %644, 1
  store i32 %645, ptr %173, align 4, !tbaa !5
  br label %687

646:                                              ; preds = %636, %632
  %647 = add nuw i32 %623, 1
  %648 = add nuw i32 %622, 1
  %649 = icmp eq i32 %648, %34
  br i1 %649, label %706, label %620, !llvm.loop !119

650:                                              ; preds = %613
  %651 = icmp eq i32 %209, -1
  br i1 %651, label %662, label %652

652:                                              ; preds = %650
  %653 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %126, i32 %209
  %654 = call fastcc i32 @raw_term_content_tokens_equal(ptr noundef nonnull %125, ptr noundef nonnull %204, ptr noundef %653, i32 noundef 1)
  %655 = icmp eq i32 %654, 0
  br i1 %655, label %662, label %656

656:                                              ; preds = %652
  %657 = and i32 %209, 3
  %658 = getelementptr inbounds nuw [4 x i32], ptr %41, i32 0, i32 %657
  %659 = load i32, ptr %658, align 4, !tbaa !5
  %660 = and i32 %179, 3
  %661 = getelementptr inbounds nuw [4 x i32], ptr %41, i32 0, i32 %660
  store i32 %659, ptr %661, align 4, !tbaa !5
  br label %687

662:                                              ; preds = %652, %650
  %663 = call fastcc i32 @raw_term_content_quick_signature(ptr noundef nonnull %125, ptr noundef nonnull %204)
  %664 = call i32 @llvm.usub.sat.i32(i32 %179, i32 4)
  %665 = icmp ugt i32 %179, %664
  br i1 %665, label %669, label %666

666:                                              ; preds = %682, %662
  %667 = and i32 %179, 3
  %668 = getelementptr inbounds nuw [4 x i32], ptr %41, i32 0, i32 %667
  store i32 %663, ptr %668, align 4, !tbaa !5
  br label %706

669:                                              ; preds = %662, %682
  %670 = phi i32 [ %671, %682 ], [ %179, %662 ]
  %671 = add i32 %670, -1
  %672 = and i32 %671, 3
  %673 = getelementptr inbounds nuw [4 x i32], ptr %41, i32 0, i32 %672
  %674 = load i32, ptr %673, align 4, !tbaa !5
  %675 = icmp eq i32 %674, %663
  br i1 %675, label %676, label %682

676:                                              ; preds = %669
  %677 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %126, i32 %671
  %678 = icmp eq i32 %671, %209
  %679 = zext i1 %678 to i32
  %680 = call fastcc i32 @raw_term_content_tokens_equal(ptr noundef %125, ptr noundef nonnull %204, ptr noundef %677, i32 noundef %679)
  %681 = icmp eq i32 %680, 0
  br i1 %681, label %682, label %684

682:                                              ; preds = %676, %669
  %683 = icmp ugt i32 %671, %664
  br i1 %683, label %669, label %666, !llvm.loop !120

684:                                              ; preds = %676
  %685 = and i32 %179, 3
  %686 = getelementptr inbounds nuw [4 x i32], ptr %41, i32 0, i32 %685
  store i32 %663, ptr %686, align 4, !tbaa !5
  br label %687

687:                                              ; preds = %642, %643, %684, %656
  %688 = phi i32 [ %209, %656 ], [ %671, %684 ], [ %630, %643 ], [ %630, %642 ]
  br i1 %148, label %689, label %695

689:                                              ; preds = %687
  %690 = icmp ugt i32 %183, 3
  br i1 %690, label %695, label %691

691:                                              ; preds = %689
  %692 = add nuw nsw i32 %183, 1
  %693 = icmp eq i32 %183, 3
  %694 = select i1 %693, i32 4, i32 %224
  br label %695

695:                                              ; preds = %691, %689, %687
  %696 = phi i32 [ %183, %687 ], [ %183, %689 ], [ %692, %691 ]
  %697 = phi i32 [ %224, %687 ], [ 4, %689 ], [ %694, %691 ]
  %698 = shl i32 %688, 4
  %699 = getelementptr inbounds nuw i8, ptr %128, i32 %698
  %700 = getelementptr inbounds nuw i32, ptr %128, i32 %616
  %701 = load <4 x i32>, ptr %699, align 4, !tbaa !5
  store <4 x i32> %701, ptr %700, align 4, !tbaa !5
  %702 = getelementptr inbounds nuw i32, ptr %132, i32 %688
  %703 = load i32, ptr %702, align 4, !tbaa !5
  %704 = getelementptr inbounds nuw i32, ptr %132, i32 %179
  store i32 %703, ptr %704, align 4, !tbaa !5
  %705 = add i32 %180, 1
  br label %901

706:                                              ; preds = %646, %617, %666, %627
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %54) #28
  store i32 0, ptr %54, align 4, !tbaa !5
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %55) #28
  store i32 0, ptr %55, align 4, !tbaa !5
  %707 = call fastcc i32 @encode_term_content_token_binary_row(ptr noundef %125, ptr noundef nonnull %204, ptr noundef %127, i32 noundef %184, ptr noundef %40, ptr noundef %54, ptr noundef %55, i32 noundef %29, ptr noundef %121)
  %708 = icmp eq i32 %707, 0
  br i1 %708, label %709, label %759

709:                                              ; preds = %706, %756
  %710 = phi i32 [ %718, %756 ], [ %184, %706 ]
  store i32 %175, ptr %40, align 4, !tbaa !5
  %711 = icmp ugt i32 %710, 2147483646
  br i1 %711, label %890, label %712

712:                                              ; preds = %709
  %713 = lshr i32 %710, 1
  %714 = call i32 @llvm.umax.i32(i32 %713, i32 1048576)
  %715 = xor i32 %714, 2147483647
  %716 = icmp samesign ugt i32 %710, %715
  %717 = add nuw i32 %714, %710
  %718 = select i1 %716, i32 2147483647, i32 %717
  %719 = add nuw i32 %710, 7
  %720 = and i32 %719, -8
  %721 = xor i32 %720, -1
  %722 = icmp ugt i32 %4, %721
  br i1 %722, label %890, label %723

723:                                              ; preds = %712
  %724 = add i32 %720, %4
  %725 = load i32, ptr @heap_ptr, align 4, !tbaa !5
  %726 = icmp eq i32 %725, %724
  br i1 %726, label %727, label %890

727:                                              ; preds = %723
  %728 = sub i32 %718, %720
  %729 = add i32 %728, 7
  %730 = icmp eq i32 %724, 0
  br i1 %730, label %731, label %732

731:                                              ; preds = %727
  store i32 ptrtoint (ptr @__heap_base to i32), ptr @heap_ptr, align 4, !tbaa !5
  br label %732

732:                                              ; preds = %731, %727
  %733 = phi i32 [ ptrtoint (ptr @__heap_base to i32), %731 ], [ %724, %727 ]
  %734 = and i32 %729, -8
  %735 = add i32 %733, 7
  %736 = and i32 %735, -8
  %737 = xor i32 %734, -1
  %738 = icmp ugt i32 %736, %737
  br i1 %738, label %890, label %739

739:                                              ; preds = %732
  %740 = add i32 %736, %734
  %741 = call i32 @llvm.wasm.memory.size.i32(i32 0)
  %742 = lshr i32 %740, 16
  %743 = and i32 %740, 65528
  %744 = icmp ne i32 %743, 0
  %745 = zext i1 %744 to i32
  %746 = add nuw nsw i32 %742, %745
  %747 = icmp ugt i32 %746, %741
  br i1 %747, label %748, label %752

748:                                              ; preds = %739
  %749 = sub nuw nsw i32 %746, %741
  %750 = call i32 @llvm.wasm.memory.grow.i32(i32 0, i32 %749)
  %751 = icmp slt i32 %750, 0
  br i1 %751, label %890, label %752

752:                                              ; preds = %748, %739
  store i32 %740, ptr @heap_ptr, align 4, !tbaa !5
  %753 = icmp ne i32 %736, 0
  %754 = icmp eq i32 %736, %724
  %755 = and i1 %753, %754
  br i1 %755, label %756, label %890

756:                                              ; preds = %752
  store i32 %718, ptr @last_content_capacity, align 4, !tbaa !5
  %757 = call fastcc i32 @encode_term_content_token_binary_row(ptr noundef %125, ptr noundef nonnull %204, ptr noundef %127, i32 noundef %718, ptr noundef %40, ptr noundef %54, ptr noundef %55, i32 noundef %29, ptr noundef %121)
  %758 = icmp eq i32 %757, 0
  br i1 %758, label %709, label %759, !llvm.loop !121

759:                                              ; preds = %756, %706
  %760 = phi i32 [ %184, %706 ], [ %718, %756 ]
  %761 = load i32, ptr %40, align 4, !tbaa !5
  %762 = sub i32 %761, %175
  %763 = load i32, ptr %54, align 4, !tbaa !5
  %764 = load i32, ptr %55, align 4, !tbaa !5
  %765 = mul i32 %764, -1640531535
  %766 = xor i32 %765, %763
  %767 = lshr i32 %766, 16
  %768 = xor i32 %767, %766
  %769 = and i32 %768, %90
  br label %770

770:                                              ; preds = %759, %797
  %771 = phi i32 [ %800, %797 ], [ %769, %759 ]
  %772 = phi i32 [ %799, %797 ], [ 0, %759 ]
  %773 = getelementptr inbounds nuw i32, ptr %129, i32 %771
  %774 = load i32, ptr %773, align 4, !tbaa !5
  %775 = icmp eq i32 %774, 0
  br i1 %775, label %810, label %776

776:                                              ; preds = %770
  %777 = add i32 %774, -1
  %778 = icmp ult i32 %777, %179
  br i1 %778, label %779, label %890

779:                                              ; preds = %776
  %780 = shl i32 %777, 4
  %781 = getelementptr inbounds nuw i8, ptr %128, i32 %780
  %782 = getelementptr inbounds nuw i8, ptr %781, i32 8
  %783 = load i32, ptr %782, align 4, !tbaa !5
  %784 = icmp eq i32 %783, %763
  br i1 %784, label %785, label %797

785:                                              ; preds = %779
  %786 = getelementptr inbounds nuw i8, ptr %781, i32 12
  %787 = load i32, ptr %786, align 4, !tbaa !5
  %788 = icmp eq i32 %787, %764
  br i1 %788, label %789, label %797

789:                                              ; preds = %785
  %790 = getelementptr inbounds nuw i8, ptr %781, i32 4
  %791 = load i32, ptr %790, align 4, !tbaa !5
  %792 = icmp eq i32 %791, %762
  br i1 %792, label %793, label %797

793:                                              ; preds = %789
  %794 = load i32, ptr %781, align 4, !tbaa !5
  %795 = call fastcc i32 @content_bytes_equal(ptr noundef %127, i32 noundef %794, i32 noundef %175, i32 noundef %762)
  %796 = icmp eq i32 %795, 0
  br i1 %796, label %797, label %802

797:                                              ; preds = %793, %789, %785, %779
  %798 = add i32 %771, 1
  %799 = add nuw i32 %772, 1
  %800 = and i32 %798, %90
  %801 = icmp eq i32 %799, %8
  br i1 %801, label %810, label %770, !llvm.loop !122

802:                                              ; preds = %793
  %803 = getelementptr inbounds nuw i32, ptr %128, i32 %616
  store i32 %794, ptr %803, align 4, !tbaa !5
  %804 = getelementptr inbounds nuw i8, ptr %803, i32 4
  store i32 %762, ptr %804, align 4, !tbaa !5
  %805 = getelementptr inbounds nuw i8, ptr %803, i32 8
  store i32 %763, ptr %805, align 4, !tbaa !5
  %806 = getelementptr inbounds nuw i8, ptr %803, i32 12
  store i32 %764, ptr %806, align 4, !tbaa !5
  %807 = getelementptr inbounds nuw i32, ptr %132, i32 %777
  %808 = load i32, ptr %807, align 4, !tbaa !5
  %809 = getelementptr inbounds nuw i32, ptr %132, i32 %179
  store i32 %808, ptr %809, align 4, !tbaa !5
  store i32 %175, ptr %40, align 4, !tbaa !5
  br label %892

810:                                              ; preds = %797, %770
  %811 = phi i32 [ %800, %797 ], [ %771, %770 ]
  %812 = getelementptr inbounds nuw i32, ptr %129, i32 %811
  %813 = load i32, ptr %812, align 4, !tbaa !5
  %814 = icmp ne i32 %813, 0
  %815 = icmp eq i32 %176, -1
  %816 = select i1 %814, i1 true, i1 %815
  br i1 %816, label %890, label %817

817:                                              ; preds = %810
  %818 = getelementptr inbounds nuw i32, ptr %128, i32 %616
  store i32 %175, ptr %818, align 4, !tbaa !5
  %819 = getelementptr inbounds nuw i8, ptr %818, i32 4
  store i32 %762, ptr %819, align 4, !tbaa !5
  %820 = getelementptr inbounds nuw i8, ptr %818, i32 8
  store i32 %763, ptr %820, align 4, !tbaa !5
  %821 = getelementptr inbounds nuw i8, ptr %818, i32 12
  store i32 %764, ptr %821, align 4, !tbaa !5
  %822 = getelementptr inbounds nuw i32, ptr %132, i32 %179
  store i32 %176, ptr %822, align 4, !tbaa !5
  %823 = call i32 @llvm.usub.sat.i32(i32 %762, i32 4)
  %824 = getelementptr inbounds nuw i8, ptr %127, i32 %175
  %825 = icmp eq i32 %761, %175
  br i1 %825, label %841, label %826

826:                                              ; preds = %817
  %827 = icmp ugt i32 %762, 3
  br i1 %827, label %828, label %830

828:                                              ; preds = %826
  %829 = load i32, ptr %824, align 1
  br label %841

830:                                              ; preds = %826, %830
  %831 = phi i32 [ %839, %830 ], [ 0, %826 ]
  %832 = phi i32 [ %838, %830 ], [ 0, %826 ]
  %833 = getelementptr i8, ptr %824, i32 %831
  %834 = load i8, ptr %833, align 1, !tbaa !2
  %835 = zext i8 %834 to i32
  %836 = shl nuw nsw i32 %831, 3
  %837 = shl nuw nsw i32 %835, %836
  %838 = or i32 %837, %832
  %839 = add nuw nsw i32 %831, 1
  %840 = icmp eq i32 %839, %762
  br i1 %840, label %841, label %830, !llvm.loop !123

841:                                              ; preds = %830, %817, %828
  %842 = phi i32 [ 0, %817 ], [ %829, %828 ], [ %838, %830 ]
  %843 = mul i32 %176, 12
  %844 = getelementptr inbounds nuw i8, ptr %133, i32 %843
  store i32 %842, ptr %844, align 4, !tbaa !5
  %845 = lshr i32 %823, 1
  %846 = icmp ult i32 %845, %762
  br i1 %846, label %847, label %864

847:                                              ; preds = %841
  %848 = sub nuw i32 %762, %845
  %849 = icmp ugt i32 %848, 3
  %850 = getelementptr i8, ptr %824, i32 %845
  br i1 %849, label %851, label %853

851:                                              ; preds = %847
  %852 = load i32, ptr %850, align 1
  br label %864

853:                                              ; preds = %847, %853
  %854 = phi i32 [ %862, %853 ], [ 0, %847 ]
  %855 = phi i32 [ %861, %853 ], [ 0, %847 ]
  %856 = getelementptr i8, ptr %850, i32 %854
  %857 = load i8, ptr %856, align 1, !tbaa !2
  %858 = zext i8 %857 to i32
  %859 = shl nuw nsw i32 %854, 3
  %860 = shl nuw nsw i32 %858, %859
  %861 = or i32 %860, %855
  %862 = add nuw nsw i32 %854, 1
  %863 = icmp eq i32 %862, %848
  br i1 %863, label %864, label %853, !llvm.loop !124

864:                                              ; preds = %853, %841, %851
  %865 = phi i32 [ 0, %841 ], [ %852, %851 ], [ %861, %853 ]
  %866 = getelementptr i8, ptr %844, i32 4
  store i32 %865, ptr %866, align 4, !tbaa !5
  %867 = icmp ult i32 %823, %762
  br i1 %867, label %868, label %885

868:                                              ; preds = %864
  %869 = sub nuw i32 %762, %823
  %870 = icmp ugt i32 %869, 3
  %871 = getelementptr i8, ptr %824, i32 %823
  br i1 %870, label %872, label %874

872:                                              ; preds = %868
  %873 = load i32, ptr %871, align 1
  br label %885

874:                                              ; preds = %868, %874
  %875 = phi i32 [ %883, %874 ], [ 0, %868 ]
  %876 = phi i32 [ %882, %874 ], [ 0, %868 ]
  %877 = getelementptr i8, ptr %871, i32 %875
  %878 = load i8, ptr %877, align 1, !tbaa !2
  %879 = zext i8 %878 to i32
  %880 = shl nuw nsw i32 %875, 3
  %881 = shl nuw nsw i32 %879, %880
  %882 = or i32 %881, %876
  %883 = add nuw nsw i32 %875, 1
  %884 = icmp eq i32 %883, %869
  br i1 %884, label %885, label %874, !llvm.loop !125

885:                                              ; preds = %874, %864, %872
  %886 = phi i32 [ 0, %864 ], [ %873, %872 ], [ %882, %874 ]
  %887 = getelementptr i8, ptr %844, i32 8
  store i32 %886, ptr %887, align 4, !tbaa !5
  %888 = add i32 %179, 1
  store i32 %888, ptr %812, align 4, !tbaa !5
  %889 = add nuw i32 %176, 1
  br label %892

890:                                              ; preds = %810, %709, %712, %723, %752, %732, %748, %776
  %891 = phi i32 [ -3, %776 ], [ -2, %748 ], [ -2, %732 ], [ -2, %752 ], [ -2, %723 ], [ -2, %712 ], [ -2, %709 ], [ -3, %810 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %55) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %54) #28
  br label %899

892:                                              ; preds = %885, %802
  %893 = phi i32 [ %175, %802 ], [ %761, %885 ]
  %894 = phi i32 [ %176, %802 ], [ %889, %885 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %55) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %54) #28
  br label %901

895:                                              ; preds = %592, %502, %523, %558, %554, %563, %488, %476, %479, %483, %393, %383, %382, %375, %577, %570
  %896 = inttoptr i32 %12 to ptr
  store i32 %179, ptr %896, align 4, !tbaa !5
  br label %897

897:                                              ; preds = %412, %895
  %898 = phi i32 [ -5, %895 ], [ -3, %412 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %50)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %51)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %48)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %49)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %46)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %47)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %45) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %44) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %43) #28
  br label %931

899:                                              ; preds = %629, %611, %890
  %900 = phi i32 [ %891, %890 ], [ -5, %611 ], [ -3, %629 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %52) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %50)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %51)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %48)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %49)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %46)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %47)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %45) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %44) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %43) #28
  br label %931

901:                                              ; preds = %695, %892
  %902 = phi i32 [ %893, %892 ], [ %175, %695 ]
  %903 = phi i32 [ %760, %892 ], [ %184, %695 ]
  %904 = phi i32 [ 0, %892 ], [ %696, %695 ]
  %905 = phi i32 [ %224, %892 ], [ %697, %695 ]
  %906 = phi i32 [ %180, %892 ], [ %705, %695 ]
  %907 = phi i32 [ %894, %892 ], [ %176, %695 ]
  %908 = add i32 %179, 1
  %909 = load i32, ptr %43, align 4, !tbaa !5
  %910 = call fastcc i32 @next_term_row(ptr noundef %42, i32 noundef %909)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %52) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %50)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %51)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %48)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %49)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %46)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %47)
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %45) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %44) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %43) #28
  %911 = icmp sgt i32 %910, 0
  br i1 %911, label %174, label %912, !llvm.loop !126

912:                                              ; preds = %901, %124
  %913 = phi i32 [ 0, %124 ], [ %902, %901 ]
  %914 = phi i32 [ %158, %124 ], [ %910, %901 ]
  %915 = phi i32 [ %146, %124 ], [ %227, %901 ]
  %916 = phi i32 [ 0, %124 ], [ %906, %901 ]
  %917 = phi i32 [ 0, %124 ], [ %908, %901 ]
  %918 = phi i32 [ 0, %124 ], [ %504, %901 ]
  %919 = phi i32 [ 0, %124 ], [ %503, %901 ]
  %920 = phi i32 [ 0, %124 ], [ %907, %901 ]
  %921 = icmp slt i32 %914, 0
  br i1 %921, label %931, label %922

922:                                              ; preds = %912
  %923 = inttoptr i32 %10 to ptr
  store i32 %920, ptr %923, align 4, !tbaa !5
  %924 = inttoptr i32 %12 to ptr
  store i32 %917, ptr %924, align 4, !tbaa !5
  %925 = inttoptr i32 %22 to ptr
  store i32 %919, ptr %925, align 4, !tbaa !5
  %926 = inttoptr i32 %23 to ptr
  store i32 %918, ptr %926, align 4, !tbaa !5
  %927 = inttoptr i32 %27 to ptr
  store i32 %916, ptr %927, align 4, !tbaa !5
  %928 = icmp eq i32 %38, 0
  br i1 %928, label %931, label %929

929:                                              ; preds = %922
  %930 = inttoptr i32 %38 to ptr
  store i32 %915, ptr %930, align 4, !tbaa !5
  br label %931

931:                                              ; preds = %922, %929, %899, %897, %207, %912, %186
  %932 = phi i32 [ -4, %186 ], [ -1, %912 ], [ -1, %207 ], [ %898, %897 ], [ %900, %899 ], [ %913, %929 ], [ %913, %922 ]
  call void @llvm.lifetime.end.p0(i64 28, ptr nonnull %42) #28
  call void @llvm.lifetime.end.p0(i64 16, ptr nonnull %41) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %40) #28
  br label %933

933:                                              ; preds = %111, %99, %103, %39, %89, %95, %931
  %934 = phi i32 [ %932, %931 ], [ -1, %95 ], [ -1, %89 ], [ -1, %39 ], [ -1, %103 ], [ -1, %99 ], [ -1, %111 ]
  ret i32 %934
}

; Function Attrs: nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: none)
define internal fastcc range(i32 -1, 2) i32 @next_term_bank(ptr noundef nonnull captures(none) %0) unnamed_addr #20 {
  %2 = getelementptr inbounds nuw i8, ptr %0, i32 16
  %3 = getelementptr inbounds nuw i8, ptr %0, i32 12
  %4 = load i32, ptr %3, align 4, !tbaa !52
  %5 = load i32, ptr %2, align 4, !tbaa !53
  %6 = icmp ult i32 %5, %4
  br i1 %6, label %7, label %87

7:                                                ; preds = %1
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 4
  %9 = load ptr, ptr %8, align 4, !tbaa !50
  %10 = icmp eq ptr %9, null
  %11 = getelementptr i8, ptr %9, i32 4
  %12 = getelementptr inbounds nuw i8, ptr %0, i32 8
  %13 = getelementptr inbounds nuw i8, ptr %0, i32 20
  %14 = load i32, ptr %13, align 4, !tbaa !54
  br label %15

15:                                               ; preds = %7, %85
  %16 = phi i32 [ %14, %7 ], [ %36, %85 ]
  %17 = phi i32 [ %5, %7 ], [ %18, %85 ]
  %18 = add i32 %17, 1
  store i32 %18, ptr %2, align 4, !tbaa !53
  %19 = shl i32 %17, 3
  br i1 %10, label %23, label %20

20:                                               ; preds = %15
  %21 = getelementptr inbounds nuw i8, ptr %9, i32 %19
  %22 = load i32, ptr %21, align 4, !tbaa !5
  br label %23

23:                                               ; preds = %15, %20
  %24 = phi i32 [ %22, %20 ], [ 0, %15 ]
  %25 = getelementptr i8, ptr %11, i32 %19
  %26 = select i1 %10, ptr %12, ptr %25
  %27 = load i32, ptr %26, align 4, !tbaa !5
  %28 = icmp ult i32 %24, %16
  br i1 %28, label %87, label %29

29:                                               ; preds = %23
  %30 = load i32, ptr %12, align 4, !tbaa !51
  %31 = icmp ugt i32 %24, %30
  %32 = sub nuw i32 %30, %24
  %33 = icmp ugt i32 %27, %32
  %34 = select i1 %31, i1 true, i1 %33
  br i1 %34, label %87, label %35

35:                                               ; preds = %29
  %36 = add i32 %27, %24
  store i32 %36, ptr %13, align 4, !tbaa !54
  %37 = load ptr, ptr %0, align 4, !tbaa !45
  %38 = icmp ult i32 %24, %36
  br i1 %38, label %39, label %46

39:                                               ; preds = %35, %43
  %40 = phi i32 [ %44, %43 ], [ %24, %35 ]
  %41 = getelementptr inbounds nuw i8, ptr %37, i32 %40
  %42 = load i8, ptr %41, align 1, !tbaa !2
  switch i8 %42, label %46 [
    i8 32, label %43
    i8 13, label %43
    i8 10, label %43
    i8 9, label %43
  ]

43:                                               ; preds = %39, %39, %39, %39
  %44 = add i32 %40, 1
  %45 = icmp eq i32 %44, %36
  br i1 %45, label %87, label %39, !llvm.loop !35

46:                                               ; preds = %39, %35
  %47 = phi i32 [ %24, %35 ], [ %40, %39 ]
  %48 = icmp ult i32 %47, %36
  br i1 %48, label %49, label %87

49:                                               ; preds = %46
  %50 = getelementptr inbounds nuw i8, ptr %37, i32 %47
  %51 = load i8, ptr %50, align 1, !tbaa !2
  %52 = icmp eq i8 %51, 91
  br i1 %52, label %53, label %87

53:                                               ; preds = %49
  %54 = add nuw i32 %47, 1
  %55 = icmp ult i32 %54, %36
  br i1 %55, label %56, label %63

56:                                               ; preds = %53, %60
  %57 = phi i32 [ %61, %60 ], [ %54, %53 ]
  %58 = getelementptr inbounds nuw i8, ptr %37, i32 %57
  %59 = load i8, ptr %58, align 1, !tbaa !2
  switch i8 %59, label %63 [
    i8 32, label %60
    i8 13, label %60
    i8 10, label %60
    i8 9, label %60
  ]

60:                                               ; preds = %56, %56, %56, %56
  %61 = add i32 %57, 1
  %62 = icmp eq i32 %61, %36
  br i1 %62, label %87, label %56, !llvm.loop !35

63:                                               ; preds = %56, %53
  %64 = phi i32 [ %54, %53 ], [ %57, %56 ]
  %65 = icmp ult i32 %64, %36
  br i1 %65, label %66, label %87

66:                                               ; preds = %63
  %67 = getelementptr inbounds nuw i8, ptr %37, i32 %64
  %68 = load i8, ptr %67, align 1, !tbaa !2
  %69 = icmp eq i8 %68, 93
  br i1 %69, label %72, label %70

70:                                               ; preds = %66
  %71 = getelementptr inbounds nuw i8, ptr %0, i32 24
  store i32 %64, ptr %71, align 4, !tbaa !55
  br label %87

72:                                               ; preds = %66
  %73 = add nuw i32 %64, 1
  %74 = icmp ult i32 %73, %36
  br i1 %74, label %75, label %82

75:                                               ; preds = %72, %79
  %76 = phi i32 [ %80, %79 ], [ %73, %72 ]
  %77 = getelementptr inbounds nuw i8, ptr %37, i32 %76
  %78 = load i8, ptr %77, align 1, !tbaa !2
  switch i8 %78, label %82 [
    i8 32, label %79
    i8 13, label %79
    i8 10, label %79
    i8 9, label %79
  ]

79:                                               ; preds = %75, %75, %75, %75
  %80 = add i32 %76, 1
  %81 = icmp eq i32 %80, %36
  br i1 %81, label %85, label %75, !llvm.loop !35

82:                                               ; preds = %75, %72
  %83 = phi i32 [ %73, %72 ], [ %76, %75 ]
  %84 = icmp eq i32 %83, %36
  br i1 %84, label %85, label %87

85:                                               ; preds = %79, %82
  %86 = icmp eq i32 %18, %4
  br i1 %86, label %87, label %15

87:                                               ; preds = %85, %29, %23, %49, %46, %63, %82, %43, %60, %1, %70
  %88 = phi i32 [ 1, %70 ], [ 0, %1 ], [ -1, %60 ], [ -1, %43 ], [ 0, %85 ], [ -1, %29 ], [ -1, %23 ], [ -1, %49 ], [ -1, %46 ], [ -1, %63 ], [ -1, %82 ]
  ret i32 %88
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define internal fastcc range(i32 0, 2) i32 @parse_row_single_pass(ptr noundef %0, i32 noundef %1, i32 noundef %2, ptr noundef captures(address_is_null) %3, i32 noundef range(i32 0, 2) %4, ptr noundef nonnull writeonly captures(none) %5, ptr noundef readonly captures(none) %6, i32 noundef %7, ptr noundef writeonly captures(address_is_null) %8, i32 noundef range(i32 0, 5) %9, i32 noundef range(i32 0, 2) %10, ptr noundef captures(address_is_null) %11) unnamed_addr #8 {
  %13 = alloca i32, align 4
  %14 = alloca i32, align 4
  %15 = alloca i32, align 4
  %16 = icmp eq i32 %10, 0
  %17 = icmp ult i32 %2, %1
  br i1 %16, label %728, label %18

18:                                               ; preds = %12
  br i1 %17, label %19, label %1037

19:                                               ; preds = %18
  %20 = getelementptr inbounds nuw i8, ptr %0, i32 %2
  %21 = load i8, ptr %20, align 1, !tbaa !2
  %22 = icmp eq i8 %21, 91
  br i1 %22, label %23, label %1037

23:                                               ; preds = %19
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %13) #28
  %24 = add nuw i32 %2, 1
  %25 = icmp ult i32 %24, %1
  br i1 %25, label %26, label %34

26:                                               ; preds = %23, %30
  %27 = phi i32 [ %31, %30 ], [ %24, %23 ]
  %28 = getelementptr inbounds nuw i8, ptr %0, i32 %27
  %29 = load i8, ptr %28, align 1, !tbaa !2
  switch i8 %29, label %34 [
    i8 32, label %30
    i8 13, label %30
    i8 10, label %30
    i8 9, label %30
  ]

30:                                               ; preds = %26, %26, %26, %26
  %31 = add i32 %27, 1
  %32 = icmp eq i32 %31, %1
  br i1 %32, label %33, label %26, !llvm.loop !35

33:                                               ; preds = %30
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %14) #28
  br label %726

34:                                               ; preds = %26, %23
  %35 = phi i32 [ %24, %23 ], [ %27, %26 ]
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %14) #28
  %36 = icmp ult i32 %35, %1
  br i1 %36, label %37, label %726

37:                                               ; preds = %34
  %38 = getelementptr inbounds nuw i8, ptr %0, i32 %35
  %39 = load i8, ptr %38, align 1, !tbaa !2
  %40 = icmp eq i8 %39, 34
  %41 = add nuw i32 %35, 1
  %42 = icmp ult i32 %41, %1
  %43 = select i1 %40, i1 %42, i1 false
  br i1 %43, label %44, label %726

44:                                               ; preds = %37
  %45 = getelementptr i8, ptr %0, i32 3
  %46 = getelementptr i8, ptr %0, i32 4
  %47 = getelementptr i8, ptr %0, i32 5
  br label %48

48:                                               ; preds = %136, %44
  %49 = phi i32 [ %138, %136 ], [ %41, %44 ]
  %50 = phi i32 [ %137, %136 ], [ 0, %44 ]
  br label %51

51:                                               ; preds = %55, %48
  %52 = phi i32 [ %53, %55 ], [ %49, %48 ]
  %53 = add i32 %52, 8
  %54 = icmp ugt i32 %53, %1
  br i1 %54, label %74, label %55

55:                                               ; preds = %51
  %56 = getelementptr inbounds nuw i8, ptr %0, i32 %52
  %57 = load i64, ptr %56, align 1
  %58 = xor i64 %57, 2459565876494606882
  %59 = add i64 %58, -72340172838076673
  %60 = and i64 %57, -9187201950435737472
  %61 = xor i64 %60, -9187201950435737472
  %62 = xor i64 %57, 6655295901103053916
  %63 = add i64 %62, -72340172838076673
  %64 = add i64 %57, -2314885530818453536
  %65 = or i64 %63, %64
  %66 = or i64 %65, %59
  %67 = and i64 %66, %61
  %68 = icmp eq i64 %67, 0
  br i1 %68, label %51, label %69

69:                                               ; preds = %55
  %70 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %67, i1 true)
  %71 = trunc nuw nsw i64 %70 to i32
  %72 = lshr i32 %71, 3
  %73 = add i32 %72, %52
  br label %74

74:                                               ; preds = %51, %69
  %75 = phi i32 [ %73, %69 ], [ %52, %51 ]
  %76 = icmp ult i32 %75, %1
  br i1 %76, label %77, label %726

77:                                               ; preds = %74
  %78 = getelementptr inbounds nuw i8, ptr %0, i32 %75
  %79 = load i8, ptr %78, align 1, !tbaa !2
  %80 = icmp eq i8 %79, 92
  br i1 %80, label %81, label %131

81:                                               ; preds = %77
  %82 = add nuw i32 %75, 1
  %83 = icmp ult i32 %82, %1
  br i1 %83, label %84, label %726

84:                                               ; preds = %81
  %85 = getelementptr inbounds nuw i8, ptr %0, i32 %82
  %86 = load i8, ptr %85, align 1, !tbaa !2
  switch i8 %86, label %726 [
    i8 117, label %87
    i8 116, label %129
    i8 114, label %129
    i8 110, label %129
    i8 102, label %129
    i8 98, label %129
    i8 92, label %129
    i8 47, label %129
    i8 34, label %129
  ]

87:                                               ; preds = %84
  %88 = add i32 %75, 6
  %89 = icmp ugt i32 %88, %1
  br i1 %89, label %726, label %90

90:                                               ; preds = %87
  %91 = add nuw i32 %75, 2
  %92 = icmp ult i32 %91, %88
  br i1 %92, label %93, label %136

93:                                               ; preds = %90
  %94 = getelementptr inbounds nuw i8, ptr %0, i32 %91
  %95 = load i8, ptr %94, align 1, !tbaa !2
  %96 = add i8 %95, -58
  %97 = icmp ult i8 %96, -10
  %98 = and i8 %95, -33
  %99 = add i8 %98, -71
  %100 = icmp ult i8 %99, -6
  %101 = and i1 %97, %100
  br i1 %101, label %726, label %102

102:                                              ; preds = %93
  %103 = getelementptr i8, ptr %45, i32 %75
  %104 = load i8, ptr %103, align 1, !tbaa !2
  %105 = add i8 %104, -58
  %106 = icmp ult i8 %105, -10
  %107 = and i8 %104, -33
  %108 = add i8 %107, -71
  %109 = icmp ult i8 %108, -6
  %110 = and i1 %106, %109
  br i1 %110, label %726, label %111

111:                                              ; preds = %102
  %112 = getelementptr i8, ptr %46, i32 %75
  %113 = load i8, ptr %112, align 1, !tbaa !2
  %114 = add i8 %113, -58
  %115 = icmp ult i8 %114, -10
  %116 = and i8 %113, -33
  %117 = add i8 %116, -71
  %118 = icmp ult i8 %117, -6
  %119 = and i1 %115, %118
  br i1 %119, label %726, label %120

120:                                              ; preds = %111
  %121 = getelementptr i8, ptr %47, i32 %75
  %122 = load i8, ptr %121, align 1, !tbaa !2
  %123 = add i8 %122, -58
  %124 = icmp ult i8 %123, -10
  %125 = and i8 %122, -33
  %126 = add i8 %125, -71
  %127 = icmp ult i8 %126, -6
  %128 = and i1 %124, %127
  br i1 %128, label %726, label %136

129:                                              ; preds = %84, %84, %84, %84, %84, %84, %84, %84
  %130 = add nuw i32 %75, 2
  br label %136, !llvm.loop !42

131:                                              ; preds = %77
  %132 = icmp ult i8 %79, 32
  br i1 %132, label %726, label %133

133:                                              ; preds = %131
  %134 = icmp eq i8 %79, 34
  %135 = add nuw i32 %75, 1
  br i1 %134, label %140, label %136

136:                                              ; preds = %133, %129, %120, %90
  %137 = phi i32 [ 1, %129 ], [ 1, %90 ], [ 1, %120 ], [ %50, %133 ]
  %138 = phi i32 [ %130, %129 ], [ %88, %90 ], [ %88, %120 ], [ %135, %133 ]
  %139 = icmp ult i32 %138, %1
  br i1 %139, label %48, label %726

140:                                              ; preds = %133
  store i32 %35, ptr %3, align 4, !tbaa !70
  %141 = sub i32 %135, %35
  %142 = getelementptr inbounds nuw i8, ptr %3, i32 4
  store i32 %141, ptr %142, align 4, !tbaa !72
  %143 = icmp ult i32 %135, %1
  br i1 %143, label %144, label %151

144:                                              ; preds = %140, %148
  %145 = phi i32 [ %149, %148 ], [ %135, %140 ]
  %146 = getelementptr inbounds nuw i8, ptr %0, i32 %145
  %147 = load i8, ptr %146, align 1, !tbaa !2
  switch i8 %147, label %151 [
    i8 32, label %148
    i8 13, label %148
    i8 10, label %148
    i8 9, label %148
  ]

148:                                              ; preds = %144, %144, %144, %144
  %149 = add i32 %145, 1
  %150 = icmp eq i32 %149, %1
  br i1 %150, label %726, label %144, !llvm.loop !35

151:                                              ; preds = %144, %140
  %152 = phi i32 [ %135, %140 ], [ %145, %144 ]
  %153 = icmp ult i32 %152, %1
  br i1 %153, label %154, label %726

154:                                              ; preds = %151
  %155 = getelementptr inbounds nuw i8, ptr %0, i32 %152
  %156 = load i8, ptr %155, align 1, !tbaa !2
  %157 = icmp eq i8 %156, 44
  br i1 %157, label %158, label %726

158:                                              ; preds = %154
  %159 = add nuw i32 %152, 1
  %160 = icmp ult i32 %159, %1
  br i1 %160, label %161, label %168

161:                                              ; preds = %158, %165
  %162 = phi i32 [ %166, %165 ], [ %159, %158 ]
  %163 = getelementptr inbounds nuw i8, ptr %0, i32 %162
  %164 = load i8, ptr %163, align 1, !tbaa !2
  switch i8 %164, label %168 [
    i8 32, label %165
    i8 13, label %165
    i8 10, label %165
    i8 9, label %165
  ]

165:                                              ; preds = %161, %161, %161, %161
  %166 = add i32 %162, 1
  %167 = icmp eq i32 %166, %1
  br i1 %167, label %726, label %161, !llvm.loop !35

168:                                              ; preds = %161, %158
  %169 = phi i32 [ %159, %158 ], [ %162, %161 ]
  %170 = icmp ult i32 %169, %1
  br i1 %170, label %171, label %726

171:                                              ; preds = %168
  %172 = getelementptr inbounds nuw i8, ptr %0, i32 %169
  %173 = load i8, ptr %172, align 1, !tbaa !2
  %174 = icmp eq i8 %173, 34
  %175 = add nuw i32 %169, 1
  %176 = icmp ult i32 %175, %1
  %177 = select i1 %174, i1 %176, i1 false
  br i1 %177, label %178, label %726

178:                                              ; preds = %171, %266
  %179 = phi i32 [ %268, %266 ], [ %175, %171 ]
  %180 = phi i32 [ %267, %266 ], [ 0, %171 ]
  br label %181

181:                                              ; preds = %185, %178
  %182 = phi i32 [ %183, %185 ], [ %179, %178 ]
  %183 = add i32 %182, 8
  %184 = icmp ugt i32 %183, %1
  br i1 %184, label %204, label %185

185:                                              ; preds = %181
  %186 = getelementptr inbounds nuw i8, ptr %0, i32 %182
  %187 = load i64, ptr %186, align 1
  %188 = xor i64 %187, 2459565876494606882
  %189 = add i64 %188, -72340172838076673
  %190 = and i64 %187, -9187201950435737472
  %191 = xor i64 %190, -9187201950435737472
  %192 = xor i64 %187, 6655295901103053916
  %193 = add i64 %192, -72340172838076673
  %194 = add i64 %187, -2314885530818453536
  %195 = or i64 %193, %194
  %196 = or i64 %195, %189
  %197 = and i64 %196, %191
  %198 = icmp eq i64 %197, 0
  br i1 %198, label %181, label %199

199:                                              ; preds = %185
  %200 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %197, i1 true)
  %201 = trunc nuw nsw i64 %200 to i32
  %202 = lshr i32 %201, 3
  %203 = add i32 %202, %182
  br label %204

204:                                              ; preds = %181, %199
  %205 = phi i32 [ %203, %199 ], [ %182, %181 ]
  %206 = icmp ult i32 %205, %1
  br i1 %206, label %207, label %726

207:                                              ; preds = %204
  %208 = getelementptr inbounds nuw i8, ptr %0, i32 %205
  %209 = load i8, ptr %208, align 1, !tbaa !2
  %210 = icmp eq i8 %209, 92
  br i1 %210, label %211, label %261

211:                                              ; preds = %207
  %212 = add nuw i32 %205, 1
  %213 = icmp ult i32 %212, %1
  br i1 %213, label %214, label %726

214:                                              ; preds = %211
  %215 = getelementptr inbounds nuw i8, ptr %0, i32 %212
  %216 = load i8, ptr %215, align 1, !tbaa !2
  switch i8 %216, label %726 [
    i8 117, label %217
    i8 116, label %259
    i8 114, label %259
    i8 110, label %259
    i8 102, label %259
    i8 98, label %259
    i8 92, label %259
    i8 47, label %259
    i8 34, label %259
  ]

217:                                              ; preds = %214
  %218 = add i32 %205, 6
  %219 = icmp ugt i32 %218, %1
  br i1 %219, label %726, label %220

220:                                              ; preds = %217
  %221 = add nuw i32 %205, 2
  %222 = icmp ult i32 %221, %218
  br i1 %222, label %223, label %266

223:                                              ; preds = %220
  %224 = getelementptr inbounds nuw i8, ptr %0, i32 %221
  %225 = load i8, ptr %224, align 1, !tbaa !2
  %226 = add i8 %225, -58
  %227 = icmp ult i8 %226, -10
  %228 = and i8 %225, -33
  %229 = add i8 %228, -71
  %230 = icmp ult i8 %229, -6
  %231 = and i1 %227, %230
  br i1 %231, label %726, label %232

232:                                              ; preds = %223
  %233 = getelementptr i8, ptr %45, i32 %205
  %234 = load i8, ptr %233, align 1, !tbaa !2
  %235 = add i8 %234, -58
  %236 = icmp ult i8 %235, -10
  %237 = and i8 %234, -33
  %238 = add i8 %237, -71
  %239 = icmp ult i8 %238, -6
  %240 = and i1 %236, %239
  br i1 %240, label %726, label %241

241:                                              ; preds = %232
  %242 = getelementptr i8, ptr %46, i32 %205
  %243 = load i8, ptr %242, align 1, !tbaa !2
  %244 = add i8 %243, -58
  %245 = icmp ult i8 %244, -10
  %246 = and i8 %243, -33
  %247 = add i8 %246, -71
  %248 = icmp ult i8 %247, -6
  %249 = and i1 %245, %248
  br i1 %249, label %726, label %250

250:                                              ; preds = %241
  %251 = getelementptr i8, ptr %47, i32 %205
  %252 = load i8, ptr %251, align 1, !tbaa !2
  %253 = add i8 %252, -58
  %254 = icmp ult i8 %253, -10
  %255 = and i8 %252, -33
  %256 = add i8 %255, -71
  %257 = icmp ult i8 %256, -6
  %258 = and i1 %254, %257
  br i1 %258, label %726, label %266

259:                                              ; preds = %214, %214, %214, %214, %214, %214, %214, %214
  %260 = add nuw i32 %205, 2
  br label %266, !llvm.loop !42

261:                                              ; preds = %207
  %262 = icmp ult i8 %209, 32
  br i1 %262, label %726, label %263

263:                                              ; preds = %261
  %264 = icmp eq i8 %209, 34
  %265 = add nuw i32 %205, 1
  br i1 %264, label %270, label %266

266:                                              ; preds = %263, %259, %250, %220
  %267 = phi i32 [ 1, %259 ], [ 1, %220 ], [ 1, %250 ], [ %180, %263 ]
  %268 = phi i32 [ %260, %259 ], [ %218, %220 ], [ %218, %250 ], [ %265, %263 ]
  %269 = icmp ult i32 %268, %1
  br i1 %269, label %178, label %726

270:                                              ; preds = %263
  %271 = getelementptr inbounds nuw i8, ptr %3, i32 8
  store i32 %169, ptr %271, align 4, !tbaa !71
  %272 = sub i32 %265, %169
  %273 = getelementptr inbounds nuw i8, ptr %3, i32 12
  store i32 %272, ptr %273, align 4, !tbaa !73
  %274 = icmp eq ptr %11, null
  br i1 %274, label %278, label %275

275:                                              ; preds = %270
  %276 = shl nuw nsw i32 %180, 1
  %277 = or i32 %276, %50
  store i32 %277, ptr %11, align 4, !tbaa !5
  br label %278

278:                                              ; preds = %275, %270
  %279 = icmp ult i32 %265, %1
  br i1 %279, label %280, label %287

280:                                              ; preds = %278, %284
  %281 = phi i32 [ %285, %284 ], [ %265, %278 ]
  %282 = getelementptr inbounds nuw i8, ptr %0, i32 %281
  %283 = load i8, ptr %282, align 1, !tbaa !2
  switch i8 %283, label %287 [
    i8 32, label %284
    i8 13, label %284
    i8 10, label %284
    i8 9, label %284
  ]

284:                                              ; preds = %280, %280, %280, %280
  %285 = add i32 %281, 1
  %286 = icmp eq i32 %285, %1
  br i1 %286, label %726, label %280, !llvm.loop !35

287:                                              ; preds = %280, %278
  %288 = phi i32 [ %265, %278 ], [ %281, %280 ]
  %289 = icmp ult i32 %288, %1
  br i1 %289, label %290, label %726

290:                                              ; preds = %287
  %291 = getelementptr inbounds nuw i8, ptr %0, i32 %288
  %292 = load i8, ptr %291, align 1, !tbaa !2
  %293 = icmp eq i8 %292, 44
  br i1 %293, label %294, label %726

294:                                              ; preds = %290
  %295 = add nuw i32 %288, 1
  %296 = icmp ult i32 %295, %1
  br i1 %296, label %297, label %304

297:                                              ; preds = %294, %301
  %298 = phi i32 [ %302, %301 ], [ %295, %294 ]
  %299 = getelementptr inbounds nuw i8, ptr %0, i32 %298
  %300 = load i8, ptr %299, align 1, !tbaa !2
  switch i8 %300, label %304 [
    i8 32, label %301
    i8 13, label %301
    i8 10, label %301
    i8 9, label %301
  ]

301:                                              ; preds = %297, %297, %297, %297
  %302 = add i32 %298, 1
  %303 = icmp eq i32 %302, %1
  br i1 %303, label %726, label %297, !llvm.loop !35

304:                                              ; preds = %297, %294
  %305 = phi i32 [ %295, %294 ], [ %298, %297 ]
  %306 = icmp ult i32 %305, %1
  br i1 %306, label %307, label %726

307:                                              ; preds = %304
  %308 = getelementptr inbounds nuw i8, ptr %0, i32 %305
  %309 = load i8, ptr %308, align 1, !tbaa !2
  %310 = icmp eq i8 %309, 110
  br i1 %310, label %311, label %328

311:                                              ; preds = %307
  %312 = sub i32 %1, %305
  %313 = icmp ult i32 %312, 4
  br i1 %313, label %726, label %314

314:                                              ; preds = %311
  %315 = getelementptr i8, ptr %308, i32 1
  %316 = load i8, ptr %315, align 1, !tbaa !2
  %317 = icmp eq i8 %316, 117
  br i1 %317, label %318, label %726

318:                                              ; preds = %314
  %319 = getelementptr i8, ptr %308, i32 2
  %320 = load i8, ptr %319, align 1, !tbaa !2
  %321 = icmp eq i8 %320, 108
  br i1 %321, label %322, label %726

322:                                              ; preds = %318
  %323 = getelementptr i8, ptr %308, i32 3
  %324 = load i8, ptr %323, align 1, !tbaa !2
  %325 = icmp eq i8 %324, 108
  br i1 %325, label %326, label %726

326:                                              ; preds = %322
  %327 = add i32 %305, 4
  br label %423

328:                                              ; preds = %307
  %329 = icmp eq i8 %309, 34
  %330 = add nuw i32 %305, 1
  %331 = icmp ult i32 %330, %1
  %332 = select i1 %329, i1 %331, i1 false
  br i1 %332, label %333, label %726

333:                                              ; preds = %328, %351
  %334 = phi i32 [ %352, %351 ], [ %330, %328 ]
  %335 = add i32 %334, 8
  %336 = icmp ugt i32 %335, %1
  br i1 %336, label %358, label %337

337:                                              ; preds = %333
  %338 = getelementptr inbounds nuw i8, ptr %0, i32 %334
  %339 = load i64, ptr %338, align 1
  %340 = xor i64 %339, 2459565876494606882
  %341 = add i64 %340, -72340172838076673
  %342 = and i64 %339, -9187201950435737472
  %343 = xor i64 %342, -9187201950435737472
  %344 = xor i64 %339, 6655295901103053916
  %345 = add i64 %344, -72340172838076673
  %346 = add i64 %339, -2314885530818453536
  %347 = or i64 %345, %346
  %348 = or i64 %347, %341
  %349 = and i64 %348, %343
  %350 = icmp eq i64 %349, 0
  br i1 %350, label %351, label %353

351:                                              ; preds = %337, %420
  %352 = phi i32 [ %335, %337 ], [ %421, %420 ]
  br label %333

353:                                              ; preds = %337
  %354 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %349, i1 true)
  %355 = trunc nuw nsw i64 %354 to i32
  %356 = lshr i32 %355, 3
  %357 = add i32 %356, %334
  br label %358

358:                                              ; preds = %333, %353
  %359 = phi i32 [ %357, %353 ], [ %334, %333 ]
  %360 = icmp ult i32 %359, %1
  br i1 %360, label %361, label %726

361:                                              ; preds = %358
  %362 = getelementptr inbounds nuw i8, ptr %0, i32 %359
  %363 = load i8, ptr %362, align 1, !tbaa !2
  %364 = icmp eq i8 %363, 92
  br i1 %364, label %365, label %415

365:                                              ; preds = %361
  %366 = add nuw i32 %359, 1
  %367 = icmp ult i32 %366, %1
  br i1 %367, label %368, label %726

368:                                              ; preds = %365
  %369 = getelementptr inbounds nuw i8, ptr %0, i32 %366
  %370 = load i8, ptr %369, align 1, !tbaa !2
  switch i8 %370, label %726 [
    i8 117, label %371
    i8 116, label %413
    i8 114, label %413
    i8 110, label %413
    i8 102, label %413
    i8 98, label %413
    i8 92, label %413
    i8 47, label %413
    i8 34, label %413
  ]

371:                                              ; preds = %368
  %372 = add i32 %359, 6
  %373 = icmp ugt i32 %372, %1
  br i1 %373, label %726, label %374

374:                                              ; preds = %371
  %375 = add nuw i32 %359, 2
  %376 = icmp ult i32 %375, %372
  br i1 %376, label %377, label %420

377:                                              ; preds = %374
  %378 = getelementptr inbounds nuw i8, ptr %0, i32 %375
  %379 = load i8, ptr %378, align 1, !tbaa !2
  %380 = add i8 %379, -58
  %381 = icmp ult i8 %380, -10
  %382 = and i8 %379, -33
  %383 = add i8 %382, -71
  %384 = icmp ult i8 %383, -6
  %385 = and i1 %381, %384
  br i1 %385, label %726, label %386

386:                                              ; preds = %377
  %387 = getelementptr i8, ptr %45, i32 %359
  %388 = load i8, ptr %387, align 1, !tbaa !2
  %389 = add i8 %388, -58
  %390 = icmp ult i8 %389, -10
  %391 = and i8 %388, -33
  %392 = add i8 %391, -71
  %393 = icmp ult i8 %392, -6
  %394 = and i1 %390, %393
  br i1 %394, label %726, label %395

395:                                              ; preds = %386
  %396 = getelementptr i8, ptr %46, i32 %359
  %397 = load i8, ptr %396, align 1, !tbaa !2
  %398 = add i8 %397, -58
  %399 = icmp ult i8 %398, -10
  %400 = and i8 %397, -33
  %401 = add i8 %400, -71
  %402 = icmp ult i8 %401, -6
  %403 = and i1 %399, %402
  br i1 %403, label %726, label %404

404:                                              ; preds = %395
  %405 = getelementptr i8, ptr %47, i32 %359
  %406 = load i8, ptr %405, align 1, !tbaa !2
  %407 = add i8 %406, -58
  %408 = icmp ult i8 %407, -10
  %409 = and i8 %406, -33
  %410 = add i8 %409, -71
  %411 = icmp ult i8 %410, -6
  %412 = and i1 %408, %411
  br i1 %412, label %726, label %420

413:                                              ; preds = %368, %368, %368, %368, %368, %368, %368, %368
  %414 = add nuw i32 %359, 2
  br label %420, !llvm.loop !42

415:                                              ; preds = %361
  %416 = icmp ult i8 %363, 32
  br i1 %416, label %726, label %417

417:                                              ; preds = %415
  %418 = icmp eq i8 %363, 34
  %419 = add nuw i32 %359, 1
  br i1 %418, label %423, label %420

420:                                              ; preds = %417, %413, %404, %374
  %421 = phi i32 [ %414, %413 ], [ %372, %374 ], [ %372, %404 ], [ %419, %417 ]
  %422 = icmp ult i32 %421, %1
  br i1 %422, label %351, label %726

423:                                              ; preds = %417, %326
  %424 = phi i32 [ %327, %326 ], [ %419, %417 ]
  %425 = getelementptr inbounds nuw i8, ptr %3, i32 16
  store i32 %305, ptr %425, align 4, !tbaa !60
  %426 = sub i32 %424, %305
  %427 = getelementptr inbounds nuw i8, ptr %3, i32 20
  store i32 %426, ptr %427, align 4, !tbaa !59
  store i32 %424, ptr %13, align 4, !tbaa !5
  %428 = call fastcc i32 @next_format3_field(ptr noundef nonnull %0, i32 noundef %1, ptr noundef %13)
  %429 = icmp eq i32 %428, 0
  br i1 %429, label %726, label %430

430:                                              ; preds = %423
  %431 = load i32, ptr %13, align 4, !tbaa !5
  %432 = icmp ult i32 %431, %1
  br i1 %432, label %433, label %726

433:                                              ; preds = %430
  %434 = getelementptr inbounds nuw i8, ptr %0, i32 %431
  %435 = load i8, ptr %434, align 1, !tbaa !2
  %436 = icmp eq i8 %435, 34
  %437 = add nuw i32 %431, 1
  %438 = icmp ult i32 %437, %1
  %439 = select i1 %436, i1 %438, i1 false
  br i1 %439, label %440, label %726

440:                                              ; preds = %433, %458
  %441 = phi i32 [ %459, %458 ], [ %437, %433 ]
  %442 = add i32 %441, 8
  %443 = icmp ugt i32 %442, %1
  br i1 %443, label %465, label %444

444:                                              ; preds = %440
  %445 = getelementptr inbounds nuw i8, ptr %0, i32 %441
  %446 = load i64, ptr %445, align 1
  %447 = xor i64 %446, 2459565876494606882
  %448 = add i64 %447, -72340172838076673
  %449 = and i64 %446, -9187201950435737472
  %450 = xor i64 %449, -9187201950435737472
  %451 = xor i64 %446, 6655295901103053916
  %452 = add i64 %451, -72340172838076673
  %453 = add i64 %446, -2314885530818453536
  %454 = or i64 %452, %453
  %455 = or i64 %454, %448
  %456 = and i64 %455, %450
  %457 = icmp eq i64 %456, 0
  br i1 %457, label %458, label %460

458:                                              ; preds = %444, %527
  %459 = phi i32 [ %442, %444 ], [ %528, %527 ]
  br label %440

460:                                              ; preds = %444
  %461 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %456, i1 true)
  %462 = trunc nuw nsw i64 %461 to i32
  %463 = lshr i32 %462, 3
  %464 = add i32 %463, %441
  br label %465

465:                                              ; preds = %440, %460
  %466 = phi i32 [ %464, %460 ], [ %441, %440 ]
  %467 = icmp ult i32 %466, %1
  br i1 %467, label %468, label %726

468:                                              ; preds = %465
  %469 = getelementptr inbounds nuw i8, ptr %0, i32 %466
  %470 = load i8, ptr %469, align 1, !tbaa !2
  %471 = icmp eq i8 %470, 92
  br i1 %471, label %472, label %522

472:                                              ; preds = %468
  %473 = add nuw i32 %466, 1
  %474 = icmp ult i32 %473, %1
  br i1 %474, label %475, label %726

475:                                              ; preds = %472
  %476 = getelementptr inbounds nuw i8, ptr %0, i32 %473
  %477 = load i8, ptr %476, align 1, !tbaa !2
  switch i8 %477, label %726 [
    i8 117, label %478
    i8 116, label %520
    i8 114, label %520
    i8 110, label %520
    i8 102, label %520
    i8 98, label %520
    i8 92, label %520
    i8 47, label %520
    i8 34, label %520
  ]

478:                                              ; preds = %475
  %479 = add i32 %466, 6
  %480 = icmp ugt i32 %479, %1
  br i1 %480, label %726, label %481

481:                                              ; preds = %478
  %482 = add nuw i32 %466, 2
  %483 = icmp ult i32 %482, %479
  br i1 %483, label %484, label %527

484:                                              ; preds = %481
  %485 = getelementptr inbounds nuw i8, ptr %0, i32 %482
  %486 = load i8, ptr %485, align 1, !tbaa !2
  %487 = add i8 %486, -58
  %488 = icmp ult i8 %487, -10
  %489 = and i8 %486, -33
  %490 = add i8 %489, -71
  %491 = icmp ult i8 %490, -6
  %492 = and i1 %488, %491
  br i1 %492, label %726, label %493

493:                                              ; preds = %484
  %494 = getelementptr i8, ptr %45, i32 %466
  %495 = load i8, ptr %494, align 1, !tbaa !2
  %496 = add i8 %495, -58
  %497 = icmp ult i8 %496, -10
  %498 = and i8 %495, -33
  %499 = add i8 %498, -71
  %500 = icmp ult i8 %499, -6
  %501 = and i1 %497, %500
  br i1 %501, label %726, label %502

502:                                              ; preds = %493
  %503 = getelementptr i8, ptr %46, i32 %466
  %504 = load i8, ptr %503, align 1, !tbaa !2
  %505 = add i8 %504, -58
  %506 = icmp ult i8 %505, -10
  %507 = and i8 %504, -33
  %508 = add i8 %507, -71
  %509 = icmp ult i8 %508, -6
  %510 = and i1 %506, %509
  br i1 %510, label %726, label %511

511:                                              ; preds = %502
  %512 = getelementptr i8, ptr %47, i32 %466
  %513 = load i8, ptr %512, align 1, !tbaa !2
  %514 = add i8 %513, -58
  %515 = icmp ult i8 %514, -10
  %516 = and i8 %513, -33
  %517 = add i8 %516, -71
  %518 = icmp ult i8 %517, -6
  %519 = and i1 %515, %518
  br i1 %519, label %726, label %527

520:                                              ; preds = %475, %475, %475, %475, %475, %475, %475, %475
  %521 = add nuw i32 %466, 2
  br label %527, !llvm.loop !42

522:                                              ; preds = %468
  %523 = icmp ult i8 %470, 32
  br i1 %523, label %726, label %524

524:                                              ; preds = %522
  %525 = icmp eq i8 %470, 34
  %526 = add nuw i32 %466, 1
  br i1 %525, label %530, label %527

527:                                              ; preds = %524, %520, %511, %481
  %528 = phi i32 [ %521, %520 ], [ %479, %481 ], [ %479, %511 ], [ %526, %524 ]
  %529 = icmp ult i32 %528, %1
  br i1 %529, label %458, label %726

530:                                              ; preds = %524
  store i32 %526, ptr %14, align 4, !tbaa !5
  %531 = getelementptr inbounds nuw i8, ptr %3, i32 24
  store i32 %431, ptr %531, align 4, !tbaa !58
  %532 = sub i32 %526, %431
  %533 = getelementptr inbounds nuw i8, ptr %3, i32 28
  store i32 %532, ptr %533, align 4, !tbaa !57
  store i32 %526, ptr %13, align 4, !tbaa !5
  %534 = call fastcc i32 @next_format3_field(ptr noundef nonnull %0, i32 noundef %1, ptr noundef %13)
  %535 = icmp eq i32 %534, 0
  br i1 %535, label %726, label %536

536:                                              ; preds = %530
  %537 = load i32, ptr %13, align 4, !tbaa !5
  %538 = call fastcc i32 @scan_scalar_span(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %537, ptr noundef %14)
  %539 = icmp eq i32 %538, 0
  br i1 %539, label %726, label %540

540:                                              ; preds = %536
  %541 = load i32, ptr %14, align 4, !tbaa !5
  %542 = tail call fastcc i32 @is_valid_json_number(ptr noundef nonnull %0, i32 noundef %537, i32 noundef %541)
  %543 = icmp eq i32 %542, 0
  br i1 %543, label %726, label %544

544:                                              ; preds = %540
  %545 = getelementptr inbounds nuw i8, ptr %3, i32 32
  store i32 %537, ptr %545, align 4, !tbaa !116
  store i32 %541, ptr %13, align 4, !tbaa !5
  %546 = call fastcc i32 @next_format3_field(ptr noundef nonnull %0, i32 noundef %1, ptr noundef %13)
  %547 = icmp eq i32 %546, 0
  br i1 %547, label %726, label %548

548:                                              ; preds = %544
  %549 = load i32, ptr %13, align 4, !tbaa !5
  %550 = getelementptr inbounds nuw i8, ptr %0, i32 %549
  %551 = load i8, ptr %550, align 1, !tbaa !2
  %552 = icmp eq i8 %551, 91
  br i1 %552, label %553, label %726

553:                                              ; preds = %548
  %554 = getelementptr inbounds nuw i8, ptr %3, i32 56
  store i32 0, ptr %554, align 4, !tbaa !113
  %555 = getelementptr inbounds nuw i8, ptr %3, i32 60
  store i32 0, ptr %555, align 4, !tbaa !63
  %556 = getelementptr inbounds nuw i8, ptr %3, i32 64
  store i32 0, ptr %556, align 4, !tbaa !68
  %557 = icmp eq ptr %8, null
  br i1 %557, label %561, label %558

558:                                              ; preds = %553
  %559 = call fastcc i32 @reuse_validated_glossary(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %549, ptr noundef readonly %6, i32 noundef %7, ptr noundef nonnull %3, ptr noundef %14, ptr noundef %8, i32 noundef range(i32 0, 5) %9)
  %560 = icmp eq i32 %559, 0
  br i1 %560, label %561, label %566

561:                                              ; preds = %558, %553
  %562 = icmp eq i32 %4, 0
  %563 = select i1 %562, ptr null, ptr %554
  %564 = call fastcc i32 @parse_value_span_with_glossary_hints(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %549, ptr noundef %14, ptr noundef %563, ptr noundef nonnull %555, ptr noundef nonnull %556, i32 noundef 1)
  %565 = icmp eq i32 %564, 0
  br i1 %565, label %726, label %566

566:                                              ; preds = %561, %558
  %567 = getelementptr inbounds nuw i8, ptr %3, i32 36
  store i32 %549, ptr %567, align 4, !tbaa !27
  %568 = load i32, ptr %14, align 4, !tbaa !5
  %569 = sub i32 %568, %549
  %570 = getelementptr inbounds nuw i8, ptr %3, i32 40
  store i32 %569, ptr %570, align 4, !tbaa !29
  store i32 %568, ptr %13, align 4, !tbaa !5
  %571 = call fastcc i32 @next_format3_field(ptr noundef nonnull %0, i32 noundef %1, ptr noundef %13)
  %572 = icmp eq i32 %571, 0
  br i1 %572, label %726, label %573

573:                                              ; preds = %566
  %574 = load i32, ptr %13, align 4, !tbaa !5
  %575 = call fastcc i32 @scan_scalar_span(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %574, ptr noundef %14)
  %576 = icmp eq i32 %575, 0
  br i1 %576, label %726, label %577

577:                                              ; preds = %573
  %578 = load i32, ptr %14, align 4, !tbaa !5
  %579 = sub i32 %578, %574
  %580 = icmp eq i32 %579, 4
  br i1 %580, label %581, label %597

581:                                              ; preds = %577
  %582 = getelementptr inbounds nuw i8, ptr %0, i32 %574
  %583 = load i8, ptr %582, align 1, !tbaa !2
  %584 = icmp eq i8 %583, 110
  br i1 %584, label %585, label %597

585:                                              ; preds = %581
  %586 = getelementptr i8, ptr %582, i32 1
  %587 = load i8, ptr %586, align 1, !tbaa !2
  %588 = icmp eq i8 %587, 117
  br i1 %588, label %589, label %597

589:                                              ; preds = %585
  %590 = getelementptr i8, ptr %582, i32 2
  %591 = load i8, ptr %590, align 1, !tbaa !2
  %592 = icmp eq i8 %591, 108
  br i1 %592, label %593, label %597

593:                                              ; preds = %589
  %594 = getelementptr i8, ptr %582, i32 3
  %595 = load i8, ptr %594, align 1, !tbaa !2
  %596 = icmp eq i8 %595, 108
  br i1 %596, label %600, label %597

597:                                              ; preds = %593, %589, %585, %581, %577
  %598 = tail call fastcc i32 @is_valid_json_number(ptr noundef nonnull %0, i32 noundef %574, i32 noundef %578)
  %599 = icmp eq i32 %598, 0
  br i1 %599, label %726, label %600

600:                                              ; preds = %597, %593
  %601 = phi i32 [ -1, %593 ], [ %574, %597 ]
  %602 = getelementptr inbounds nuw i8, ptr %3, i32 44
  store i32 %601, ptr %602, align 4, !tbaa !118
  store i32 %578, ptr %13, align 4, !tbaa !5
  %603 = call fastcc i32 @next_format3_field(ptr noundef nonnull %0, i32 noundef %1, ptr noundef %13)
  %604 = icmp eq i32 %603, 0
  br i1 %604, label %726, label %605

605:                                              ; preds = %600
  %606 = load i32, ptr %13, align 4, !tbaa !5
  %607 = icmp ult i32 %606, %1
  br i1 %607, label %608, label %726

608:                                              ; preds = %605
  %609 = getelementptr inbounds nuw i8, ptr %0, i32 %606
  %610 = load i8, ptr %609, align 1, !tbaa !2
  %611 = icmp eq i8 %610, 34
  %612 = add nuw i32 %606, 1
  %613 = icmp ult i32 %612, %1
  %614 = select i1 %611, i1 %613, i1 false
  br i1 %614, label %615, label %726

615:                                              ; preds = %608, %633
  %616 = phi i32 [ %634, %633 ], [ %612, %608 ]
  %617 = add i32 %616, 8
  %618 = icmp ugt i32 %617, %1
  br i1 %618, label %640, label %619

619:                                              ; preds = %615
  %620 = getelementptr inbounds nuw i8, ptr %0, i32 %616
  %621 = load i64, ptr %620, align 1
  %622 = xor i64 %621, 2459565876494606882
  %623 = add i64 %622, -72340172838076673
  %624 = and i64 %621, -9187201950435737472
  %625 = xor i64 %624, -9187201950435737472
  %626 = xor i64 %621, 6655295901103053916
  %627 = add i64 %626, -72340172838076673
  %628 = add i64 %621, -2314885530818453536
  %629 = or i64 %627, %628
  %630 = or i64 %629, %623
  %631 = and i64 %630, %625
  %632 = icmp eq i64 %631, 0
  br i1 %632, label %633, label %635

633:                                              ; preds = %619, %702
  %634 = phi i32 [ %617, %619 ], [ %703, %702 ]
  br label %615

635:                                              ; preds = %619
  %636 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %631, i1 true)
  %637 = trunc nuw nsw i64 %636 to i32
  %638 = lshr i32 %637, 3
  %639 = add i32 %638, %616
  br label %640

640:                                              ; preds = %615, %635
  %641 = phi i32 [ %639, %635 ], [ %616, %615 ]
  %642 = icmp ult i32 %641, %1
  br i1 %642, label %643, label %726

643:                                              ; preds = %640
  %644 = getelementptr inbounds nuw i8, ptr %0, i32 %641
  %645 = load i8, ptr %644, align 1, !tbaa !2
  %646 = icmp eq i8 %645, 92
  br i1 %646, label %647, label %697

647:                                              ; preds = %643
  %648 = add nuw i32 %641, 1
  %649 = icmp ult i32 %648, %1
  br i1 %649, label %650, label %726

650:                                              ; preds = %647
  %651 = getelementptr inbounds nuw i8, ptr %0, i32 %648
  %652 = load i8, ptr %651, align 1, !tbaa !2
  switch i8 %652, label %726 [
    i8 117, label %653
    i8 116, label %695
    i8 114, label %695
    i8 110, label %695
    i8 102, label %695
    i8 98, label %695
    i8 92, label %695
    i8 47, label %695
    i8 34, label %695
  ]

653:                                              ; preds = %650
  %654 = add i32 %641, 6
  %655 = icmp ugt i32 %654, %1
  br i1 %655, label %726, label %656

656:                                              ; preds = %653
  %657 = add nuw i32 %641, 2
  %658 = icmp ult i32 %657, %654
  br i1 %658, label %659, label %702

659:                                              ; preds = %656
  %660 = getelementptr inbounds nuw i8, ptr %0, i32 %657
  %661 = load i8, ptr %660, align 1, !tbaa !2
  %662 = add i8 %661, -58
  %663 = icmp ult i8 %662, -10
  %664 = and i8 %661, -33
  %665 = add i8 %664, -71
  %666 = icmp ult i8 %665, -6
  %667 = and i1 %663, %666
  br i1 %667, label %726, label %668

668:                                              ; preds = %659
  %669 = getelementptr i8, ptr %45, i32 %641
  %670 = load i8, ptr %669, align 1, !tbaa !2
  %671 = add i8 %670, -58
  %672 = icmp ult i8 %671, -10
  %673 = and i8 %670, -33
  %674 = add i8 %673, -71
  %675 = icmp ult i8 %674, -6
  %676 = and i1 %672, %675
  br i1 %676, label %726, label %677

677:                                              ; preds = %668
  %678 = getelementptr i8, ptr %46, i32 %641
  %679 = load i8, ptr %678, align 1, !tbaa !2
  %680 = add i8 %679, -58
  %681 = icmp ult i8 %680, -10
  %682 = and i8 %679, -33
  %683 = add i8 %682, -71
  %684 = icmp ult i8 %683, -6
  %685 = and i1 %681, %684
  br i1 %685, label %726, label %686

686:                                              ; preds = %677
  %687 = getelementptr i8, ptr %47, i32 %641
  %688 = load i8, ptr %687, align 1, !tbaa !2
  %689 = add i8 %688, -58
  %690 = icmp ult i8 %689, -10
  %691 = and i8 %688, -33
  %692 = add i8 %691, -71
  %693 = icmp ult i8 %692, -6
  %694 = and i1 %690, %693
  br i1 %694, label %726, label %702

695:                                              ; preds = %650, %650, %650, %650, %650, %650, %650, %650
  %696 = add nuw i32 %641, 2
  br label %702, !llvm.loop !42

697:                                              ; preds = %643
  %698 = icmp ult i8 %645, 32
  br i1 %698, label %726, label %699

699:                                              ; preds = %697
  %700 = icmp eq i8 %645, 34
  %701 = add nuw i32 %641, 1
  br i1 %700, label %705, label %702

702:                                              ; preds = %699, %695, %686, %656
  %703 = phi i32 [ %696, %695 ], [ %654, %656 ], [ %654, %686 ], [ %701, %699 ]
  %704 = icmp ult i32 %703, %1
  br i1 %704, label %633, label %726

705:                                              ; preds = %699
  %706 = getelementptr inbounds nuw i8, ptr %3, i32 48
  store i32 %606, ptr %706, align 4, !tbaa !62
  %707 = sub i32 %701, %606
  %708 = getelementptr inbounds nuw i8, ptr %3, i32 52
  store i32 %707, ptr %708, align 4, !tbaa !61
  %709 = icmp ult i32 %701, %1
  br i1 %709, label %710, label %717

710:                                              ; preds = %705, %714
  %711 = phi i32 [ %715, %714 ], [ %701, %705 ]
  %712 = getelementptr inbounds nuw i8, ptr %0, i32 %711
  %713 = load i8, ptr %712, align 1, !tbaa !2
  switch i8 %713, label %717 [
    i8 32, label %714
    i8 13, label %714
    i8 10, label %714
    i8 9, label %714
  ]

714:                                              ; preds = %710, %710, %710, %710
  %715 = add i32 %711, 1
  %716 = icmp eq i32 %715, %1
  br i1 %716, label %726, label %710, !llvm.loop !35

717:                                              ; preds = %710, %705
  %718 = phi i32 [ %701, %705 ], [ %711, %710 ]
  %719 = icmp ult i32 %718, %1
  br i1 %719, label %720, label %726

720:                                              ; preds = %717
  %721 = getelementptr inbounds nuw i8, ptr %0, i32 %718
  %722 = load i8, ptr %721, align 1, !tbaa !2
  %723 = icmp eq i8 %722, 93
  br i1 %723, label %724, label %726

724:                                              ; preds = %720
  %725 = add nuw i32 %718, 1
  store i32 %725, ptr %5, align 4, !tbaa !5
  br label %726

726:                                              ; preds = %136, %131, %120, %111, %102, %93, %87, %84, %81, %74, %148, %165, %266, %261, %250, %241, %232, %223, %217, %214, %211, %204, %284, %301, %420, %415, %404, %395, %386, %377, %371, %368, %365, %358, %527, %522, %511, %502, %493, %484, %478, %475, %472, %465, %702, %697, %686, %677, %668, %659, %653, %650, %647, %640, %714, %724, %720, %717, %608, %605, %600, %597, %573, %566, %561, %548, %544, %540, %536, %530, %433, %430, %423, %328, %322, %318, %314, %311, %304, %290, %287, %171, %168, %154, %151, %37, %34, %33
  %727 = phi i32 [ 1, %724 ], [ 0, %322 ], [ 0, %311 ], [ 0, %423 ], [ 0, %530 ], [ 0, %540 ], [ 0, %536 ], [ 0, %544 ], [ 0, %548 ], [ 0, %561 ], [ 0, %566 ], [ 0, %573 ], [ 0, %597 ], [ 0, %600 ], [ 0, %720 ], [ 0, %717 ], [ 0, %37 ], [ 0, %34 ], [ 0, %33 ], [ 0, %154 ], [ 0, %151 ], [ 0, %168 ], [ 0, %171 ], [ 0, %290 ], [ 0, %287 ], [ 0, %304 ], [ 0, %318 ], [ 0, %314 ], [ 0, %328 ], [ 0, %433 ], [ 0, %430 ], [ 0, %608 ], [ 0, %605 ], [ 0, %714 ], [ 0, %640 ], [ 0, %647 ], [ 0, %650 ], [ 0, %653 ], [ 0, %659 ], [ 0, %668 ], [ 0, %677 ], [ 0, %686 ], [ 0, %697 ], [ 0, %702 ], [ 0, %465 ], [ 0, %472 ], [ 0, %475 ], [ 0, %478 ], [ 0, %484 ], [ 0, %493 ], [ 0, %502 ], [ 0, %511 ], [ 0, %522 ], [ 0, %527 ], [ 0, %358 ], [ 0, %365 ], [ 0, %368 ], [ 0, %371 ], [ 0, %377 ], [ 0, %386 ], [ 0, %395 ], [ 0, %404 ], [ 0, %415 ], [ 0, %420 ], [ 0, %301 ], [ 0, %284 ], [ 0, %204 ], [ 0, %211 ], [ 0, %214 ], [ 0, %217 ], [ 0, %223 ], [ 0, %232 ], [ 0, %241 ], [ 0, %250 ], [ 0, %261 ], [ 0, %266 ], [ 0, %165 ], [ 0, %148 ], [ 0, %74 ], [ 0, %81 ], [ 0, %84 ], [ 0, %87 ], [ 0, %93 ], [ 0, %102 ], [ 0, %111 ], [ 0, %120 ], [ 0, %131 ], [ 0, %136 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %14) #28
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %13) #28
  br label %1037

728:                                              ; preds = %12
  br i1 %17, label %729, label %1037

729:                                              ; preds = %728
  %730 = getelementptr inbounds nuw i8, ptr %0, i32 %2
  %731 = load i8, ptr %730, align 1, !tbaa !2
  %732 = icmp eq i8 %731, 91
  br i1 %732, label %733, label %1037

733:                                              ; preds = %729
  %734 = getelementptr inbounds nuw i8, ptr %3, i32 44
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(44) %3, i8 0, i64 44, i1 false)
  store i32 -1, ptr %734, align 4, !tbaa !118
  %735 = getelementptr inbounds nuw i8, ptr %3, i32 48
  tail call void @llvm.memset.p0.i64(ptr noundef nonnull align 4 dereferenceable(20) %735, i8 0, i64 20, i1 false)
  %736 = icmp ne ptr %11, null
  br i1 %736, label %737, label %738

737:                                              ; preds = %733
  store i32 3, ptr %11, align 4, !tbaa !5
  br label %738

738:                                              ; preds = %737, %733
  %739 = add nuw i32 %2, 1
  %740 = getelementptr i8, ptr %0, i32 -1
  %741 = icmp eq i32 %4, 0
  %742 = getelementptr inbounds nuw i8, ptr %3, i32 56
  %743 = icmp eq ptr %8, null
  %744 = getelementptr inbounds nuw i8, ptr %3, i32 60
  %745 = getelementptr inbounds nuw i8, ptr %3, i32 64
  %746 = getelementptr inbounds nuw i8, ptr %3, i32 36
  %747 = getelementptr inbounds nuw i8, ptr %3, i32 24
  %748 = getelementptr inbounds nuw i8, ptr %3, i32 16
  %749 = getelementptr inbounds nuw i8, ptr %3, i32 8
  %750 = getelementptr i8, ptr %0, i32 3
  %751 = getelementptr i8, ptr %0, i32 4
  %752 = getelementptr i8, ptr %0, i32 5
  br label %753

753:                                              ; preds = %1033, %738
  %754 = phi i32 [ %739, %738 ], [ %1029, %1033 ]
  %755 = phi i32 [ 0, %738 ], [ %997, %1033 ]
  %756 = icmp ult i32 %754, %1
  br i1 %756, label %757, label %1037

757:                                              ; preds = %753, %761
  %758 = phi i32 [ %762, %761 ], [ %754, %753 ]
  %759 = getelementptr inbounds nuw i8, ptr %0, i32 %758
  %760 = load i8, ptr %759, align 1, !tbaa !2
  switch i8 %760, label %764 [
    i8 32, label %761
    i8 13, label %761
    i8 10, label %761
    i8 9, label %761
  ]

761:                                              ; preds = %757, %757, %757, %757
  %762 = add i32 %758, 1
  %763 = icmp eq i32 %762, %1
  br i1 %763, label %1037, label %757, !llvm.loop !35

764:                                              ; preds = %757
  %765 = icmp ult i32 %758, %1
  br i1 %765, label %766, label %1037

766:                                              ; preds = %764
  %767 = icmp eq i8 %760, 93
  br i1 %767, label %768, label %774

768:                                              ; preds = %766
  %769 = add nuw i32 %758, 1
  store i32 %769, ptr %5, align 4, !tbaa !5
  %770 = getelementptr inbounds nuw i8, ptr %3, i32 4
  %771 = load i32, ptr %770, align 4, !tbaa !72
  %772 = icmp ne i32 %771, 0
  %773 = zext i1 %772 to i32
  br label %1037

774:                                              ; preds = %766
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %15) #28
  store i32 0, ptr %15, align 4, !tbaa !5
  %775 = icmp ult i32 %755, 2
  %776 = select i1 %736, i1 %775, i1 false
  br i1 %776, label %777, label %881

777:                                              ; preds = %774
  %778 = icmp eq i8 %760, 34
  %779 = add nuw i32 %758, 1
  %780 = icmp ult i32 %779, %1
  %781 = select i1 %778, i1 %780, i1 false
  br i1 %781, label %782, label %1031

782:                                              ; preds = %777, %870
  %783 = phi i32 [ %872, %870 ], [ %779, %777 ]
  %784 = phi i32 [ %871, %870 ], [ 0, %777 ]
  br label %785

785:                                              ; preds = %782, %789
  %786 = phi i32 [ %787, %789 ], [ %783, %782 ]
  %787 = add i32 %786, 8
  %788 = icmp ugt i32 %787, %1
  br i1 %788, label %808, label %789

789:                                              ; preds = %785
  %790 = getelementptr inbounds nuw i8, ptr %0, i32 %786
  %791 = load i64, ptr %790, align 1
  %792 = xor i64 %791, 2459565876494606882
  %793 = add i64 %792, -72340172838076673
  %794 = and i64 %791, -9187201950435737472
  %795 = xor i64 %794, -9187201950435737472
  %796 = xor i64 %791, 6655295901103053916
  %797 = add i64 %796, -72340172838076673
  %798 = or i64 %793, %797
  %799 = add i64 %791, -2314885530818453536
  %800 = or i64 %798, %799
  %801 = and i64 %795, %800
  %802 = icmp eq i64 %801, 0
  br i1 %802, label %785, label %803

803:                                              ; preds = %789
  %804 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %801, i1 true)
  %805 = trunc nuw nsw i64 %804 to i32
  %806 = lshr i32 %805, 3
  %807 = add i32 %806, %786
  br label %808

808:                                              ; preds = %785, %803
  %809 = phi i32 [ %807, %803 ], [ %786, %785 ]
  %810 = icmp ult i32 %809, %1
  br i1 %810, label %811, label %1031

811:                                              ; preds = %808
  %812 = getelementptr inbounds nuw i8, ptr %0, i32 %809
  %813 = load i8, ptr %812, align 1, !tbaa !2
  %814 = icmp eq i8 %813, 92
  br i1 %814, label %815, label %865

815:                                              ; preds = %811
  %816 = add nuw i32 %809, 1
  %817 = icmp ult i32 %816, %1
  br i1 %817, label %818, label %1031

818:                                              ; preds = %815
  %819 = getelementptr inbounds nuw i8, ptr %0, i32 %816
  %820 = load i8, ptr %819, align 1, !tbaa !2
  switch i8 %820, label %1031 [
    i8 117, label %821
    i8 116, label %863
    i8 114, label %863
    i8 110, label %863
    i8 102, label %863
    i8 98, label %863
    i8 92, label %863
    i8 47, label %863
    i8 34, label %863
  ]

821:                                              ; preds = %818
  %822 = add i32 %809, 6
  %823 = icmp ugt i32 %822, %1
  br i1 %823, label %1031, label %824

824:                                              ; preds = %821
  %825 = add nuw i32 %809, 2
  %826 = icmp ult i32 %825, %822
  br i1 %826, label %827, label %870

827:                                              ; preds = %824
  %828 = getelementptr inbounds nuw i8, ptr %0, i32 %825
  %829 = load i8, ptr %828, align 1, !tbaa !2
  %830 = add i8 %829, -58
  %831 = icmp ult i8 %830, -10
  %832 = and i8 %829, -33
  %833 = add i8 %832, -71
  %834 = icmp ult i8 %833, -6
  %835 = and i1 %831, %834
  br i1 %835, label %1031, label %836

836:                                              ; preds = %827
  %837 = getelementptr i8, ptr %750, i32 %809
  %838 = load i8, ptr %837, align 1, !tbaa !2
  %839 = add i8 %838, -58
  %840 = icmp ult i8 %839, -10
  %841 = and i8 %838, -33
  %842 = add i8 %841, -71
  %843 = icmp ult i8 %842, -6
  %844 = and i1 %840, %843
  br i1 %844, label %1031, label %845

845:                                              ; preds = %836
  %846 = getelementptr i8, ptr %751, i32 %809
  %847 = load i8, ptr %846, align 1, !tbaa !2
  %848 = add i8 %847, -58
  %849 = icmp ult i8 %848, -10
  %850 = and i8 %847, -33
  %851 = add i8 %850, -71
  %852 = icmp ult i8 %851, -6
  %853 = and i1 %849, %852
  br i1 %853, label %1031, label %854

854:                                              ; preds = %845
  %855 = getelementptr i8, ptr %752, i32 %809
  %856 = load i8, ptr %855, align 1, !tbaa !2
  %857 = add i8 %856, -58
  %858 = icmp ult i8 %857, -10
  %859 = and i8 %856, -33
  %860 = add i8 %859, -71
  %861 = icmp ult i8 %860, -6
  %862 = and i1 %858, %861
  br i1 %862, label %1031, label %870

863:                                              ; preds = %818, %818, %818, %818, %818, %818, %818, %818
  %864 = add nuw i32 %809, 2
  br label %870, !llvm.loop !42

865:                                              ; preds = %811
  %866 = icmp ult i8 %813, 32
  br i1 %866, label %1031, label %867

867:                                              ; preds = %865
  %868 = icmp eq i8 %813, 34
  %869 = add nuw i32 %809, 1
  br i1 %868, label %874, label %870

870:                                              ; preds = %867, %854, %824, %863
  %871 = phi i32 [ 1, %863 ], [ 1, %824 ], [ 1, %854 ], [ %784, %867 ]
  %872 = phi i32 [ %864, %863 ], [ %822, %824 ], [ %822, %854 ], [ %869, %867 ]
  %873 = icmp ult i32 %872, %1
  br i1 %873, label %782, label %1031

874:                                              ; preds = %867
  store i32 %869, ptr %15, align 4, !tbaa !5
  %875 = icmp eq i32 %784, 0
  br i1 %875, label %876, label %922

876:                                              ; preds = %874
  %877 = shl nuw nsw i32 1, %755
  %878 = xor i32 %877, -1
  %879 = load i32, ptr %11, align 4, !tbaa !5
  %880 = and i32 %879, %878
  store i32 %880, ptr %11, align 4, !tbaa !5
  br label %922

881:                                              ; preds = %774
  %882 = and i32 %755, -3
  %883 = icmp eq i32 %882, 4
  br i1 %883, label %884, label %897

884:                                              ; preds = %881, %890
  %885 = phi i32 [ %892, %890 ], [ %758, %881 ]
  %886 = icmp eq i32 %885, %1
  br i1 %886, label %893, label %887

887:                                              ; preds = %884
  %888 = getelementptr inbounds nuw i8, ptr %0, i32 %885
  %889 = load i8, ptr %888, align 1, !tbaa !2
  switch i8 %889, label %890 [
    i8 125, label %893
    i8 93, label %893
    i8 44, label %893
    i8 32, label %893
    i8 13, label %893
    i8 10, label %893
  ]

890:                                              ; preds = %887
  %891 = icmp eq i8 %889, 9
  %892 = add i32 %885, 1
  br i1 %891, label %893, label %884

893:                                              ; preds = %890, %887, %887, %887, %887, %887, %887, %884
  %894 = phi i32 [ %885, %887 ], [ %885, %887 ], [ %885, %887 ], [ %885, %887 ], [ %885, %887 ], [ %885, %887 ], [ %885, %890 ], [ %1, %884 ]
  %895 = icmp eq i32 %894, %758
  br i1 %895, label %1031, label %896

896:                                              ; preds = %893
  store i32 %894, ptr %15, align 4, !tbaa !5
  br label %922

897:                                              ; preds = %881
  %898 = icmp eq i32 %755, 5
  br i1 %898, label %899, label %919

899:                                              ; preds = %897
  br i1 %743, label %905, label %900

900:                                              ; preds = %899
  %901 = call fastcc i32 @reuse_validated_glossary(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %758, ptr noundef %6, i32 noundef %7, ptr noundef nonnull %3, ptr noundef %15, ptr noundef %8, i32 noundef %9)
  %902 = icmp eq i32 %901, 0
  br i1 %902, label %903, label %926

903:                                              ; preds = %900
  %904 = load i8, ptr %759, align 1, !tbaa !2
  br label %905

905:                                              ; preds = %903, %899
  %906 = phi i8 [ %904, %903 ], [ %760, %899 ]
  %907 = and i8 %906, -33
  %908 = icmp eq i8 %907, 91
  br i1 %908, label %909, label %914

909:                                              ; preds = %905
  br i1 %741, label %910, label %912

910:                                              ; preds = %909
  %911 = call fastcc i32 @parse_composite_span_no_media(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %758, ptr noundef nonnull %15, ptr noundef nonnull %744, ptr noundef nonnull %745, i32 noundef 0)
  br label %916

912:                                              ; preds = %909
  %913 = call fastcc i32 @parse_composite_span_impl(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %758, ptr noundef nonnull %15, ptr noundef nonnull %742, ptr noundef nonnull %744, ptr noundef nonnull %745, i32 noundef 0)
  br label %916

914:                                              ; preds = %905
  %915 = call fastcc i32 @parse_value_span(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %758, ptr noundef nonnull %15)
  br label %916

916:                                              ; preds = %910, %912, %914
  %917 = phi i32 [ %911, %910 ], [ %913, %912 ], [ %915, %914 ]
  %918 = icmp eq i32 %917, 0
  br i1 %918, label %1031, label %926

919:                                              ; preds = %897
  %920 = call fastcc i32 @parse_value_span(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %758, ptr noundef %15)
  %921 = icmp eq i32 %920, 0
  br i1 %921, label %1031, label %922

922:                                              ; preds = %896, %876, %874, %919
  %923 = icmp ult i32 %755, 8
  br i1 %923, label %926, label %924

924:                                              ; preds = %922
  %925 = load i32, ptr %15, align 4, !tbaa !5
  br label %995

926:                                              ; preds = %900, %916, %922
  %927 = load i32, ptr %15, align 4, !tbaa !5
  %928 = tail call i32 @llvm.usub.sat.i32(i32 %927, i32 %758)
  %929 = icmp ugt i32 %928, 1
  br i1 %929, label %930, label %937

930:                                              ; preds = %926
  %931 = load i8, ptr %759, align 1, !tbaa !2
  %932 = icmp eq i8 %931, 34
  br i1 %932, label %933, label %937

933:                                              ; preds = %930
  %934 = getelementptr i8, ptr %740, i32 %927
  %935 = load i8, ptr %934, align 1, !tbaa !2
  %936 = icmp eq i8 %935, 34
  br label %937

937:                                              ; preds = %933, %930, %926
  %938 = phi i1 [ false, %930 ], [ false, %926 ], [ %936, %933 ]
  switch i32 %755, label %990 [
    i32 0, label %939
    i32 1, label %941
    i32 2, label %943
    i32 3, label %962
    i32 4, label %964
    i32 5, label %967
    i32 6, label %968
    i32 7, label %988
  ]

939:                                              ; preds = %937
  br i1 %938, label %940, label %1031

940:                                              ; preds = %939
  store i32 %758, ptr %3, align 4, !tbaa !70
  br label %991

941:                                              ; preds = %937
  br i1 %938, label %942, label %1031

942:                                              ; preds = %941
  store i32 %758, ptr %749, align 4, !tbaa !71
  br label %991

943:                                              ; preds = %937
  br i1 %938, label %961, label %944

944:                                              ; preds = %943
  %945 = icmp eq i32 %928, 4
  br i1 %945, label %946, label %1031

946:                                              ; preds = %944
  %947 = load i8, ptr %759, align 1, !tbaa !2
  %948 = icmp eq i8 %947, 110
  br i1 %948, label %949, label %1031

949:                                              ; preds = %946
  %950 = getelementptr i8, ptr %759, i32 1
  %951 = load i8, ptr %950, align 1, !tbaa !2
  %952 = icmp eq i8 %951, 117
  br i1 %952, label %953, label %1031

953:                                              ; preds = %949
  %954 = getelementptr i8, ptr %759, i32 2
  %955 = load i8, ptr %954, align 1, !tbaa !2
  %956 = icmp eq i8 %955, 108
  br i1 %956, label %957, label %1031

957:                                              ; preds = %953
  %958 = getelementptr i8, ptr %759, i32 3
  %959 = load i8, ptr %958, align 1, !tbaa !2
  %960 = icmp eq i8 %959, 108
  br i1 %960, label %961, label %1031

961:                                              ; preds = %957, %943
  store i32 %758, ptr %748, align 4, !tbaa !60
  br label %991

962:                                              ; preds = %937
  br i1 %938, label %963, label %1031

963:                                              ; preds = %962
  store i32 %758, ptr %747, align 4, !tbaa !58
  br label %991

964:                                              ; preds = %937
  %965 = tail call fastcc i32 @is_valid_json_number(ptr noundef readonly %0, i32 noundef %758, i32 noundef %927)
  %966 = icmp eq i32 %965, 0
  br i1 %966, label %1031, label %991

967:                                              ; preds = %937
  store i32 %758, ptr %746, align 4, !tbaa !27
  br label %991

968:                                              ; preds = %937
  %969 = icmp eq i32 %928, 4
  br i1 %969, label %970, label %985

970:                                              ; preds = %968
  %971 = load i8, ptr %759, align 1, !tbaa !2
  %972 = icmp eq i8 %971, 110
  br i1 %972, label %973, label %985

973:                                              ; preds = %970
  %974 = getelementptr i8, ptr %759, i32 1
  %975 = load i8, ptr %974, align 1, !tbaa !2
  %976 = icmp eq i8 %975, 117
  br i1 %976, label %977, label %985

977:                                              ; preds = %973
  %978 = getelementptr i8, ptr %759, i32 2
  %979 = load i8, ptr %978, align 1, !tbaa !2
  %980 = icmp eq i8 %979, 108
  br i1 %980, label %981, label %985

981:                                              ; preds = %977
  %982 = getelementptr i8, ptr %759, i32 3
  %983 = load i8, ptr %982, align 1, !tbaa !2
  %984 = icmp eq i8 %983, 108
  br i1 %984, label %991, label %985

985:                                              ; preds = %981, %977, %973, %970, %968
  %986 = tail call fastcc i32 @is_valid_json_number(ptr noundef readonly %0, i32 noundef %758, i32 noundef %927)
  %987 = icmp eq i32 %986, 0
  br i1 %987, label %1031, label %991

988:                                              ; preds = %937
  br i1 %938, label %989, label %1031

989:                                              ; preds = %988
  store i32 %758, ptr %735, align 4, !tbaa !62
  br label %991

990:                                              ; preds = %937
  unreachable

991:                                              ; preds = %940, %942, %961, %963, %964, %967, %981, %985, %989
  %992 = phi i32 [ 4, %940 ], [ 12, %942 ], [ 20, %961 ], [ 28, %963 ], [ 40, %967 ], [ 52, %989 ], [ 32, %964 ], [ 44, %981 ], [ 44, %985 ]
  %993 = phi i32 [ %928, %940 ], [ %928, %942 ], [ %928, %961 ], [ %928, %963 ], [ %928, %967 ], [ %928, %989 ], [ %758, %964 ], [ -1, %981 ], [ %758, %985 ]
  %994 = getelementptr inbounds nuw i8, ptr %3, i32 %992
  store i32 %993, ptr %994, align 4, !tbaa !5
  br label %995

995:                                              ; preds = %924, %991
  %996 = phi i32 [ %925, %924 ], [ %927, %991 ]
  %997 = add i32 %755, 1
  %998 = icmp ult i32 %996, %1
  br i1 %998, label %999, label %1006

999:                                              ; preds = %995, %1003
  %1000 = phi i32 [ %1004, %1003 ], [ %996, %995 ]
  %1001 = getelementptr inbounds nuw i8, ptr %0, i32 %1000
  %1002 = load i8, ptr %1001, align 1, !tbaa !2
  switch i8 %1002, label %1006 [
    i8 32, label %1003
    i8 13, label %1003
    i8 10, label %1003
    i8 9, label %1003
  ]

1003:                                             ; preds = %999, %999, %999, %999
  %1004 = add i32 %1000, 1
  %1005 = icmp eq i32 %1004, %1
  br i1 %1005, label %1031, label %999, !llvm.loop !35

1006:                                             ; preds = %999, %995
  %1007 = phi i32 [ %996, %995 ], [ %1000, %999 ]
  %1008 = icmp ult i32 %1007, %1
  br i1 %1008, label %1009, label %1031

1009:                                             ; preds = %1006
  %1010 = getelementptr inbounds nuw i8, ptr %0, i32 %1007
  %1011 = load i8, ptr %1010, align 1, !tbaa !2
  switch i8 %1011, label %1031 [
    i8 93, label %1012
    i8 44, label %1018
  ]

1012:                                             ; preds = %1009
  %1013 = add nuw i32 %1007, 1
  store i32 %1013, ptr %5, align 4, !tbaa !5
  %1014 = getelementptr inbounds nuw i8, ptr %3, i32 4
  %1015 = load i32, ptr %1014, align 4, !tbaa !72
  %1016 = icmp ne i32 %1015, 0
  %1017 = zext i1 %1016 to i32
  br label %1031

1018:                                             ; preds = %1009
  %1019 = add nuw i32 %1007, 1
  %1020 = icmp ult i32 %1019, %1
  br i1 %1020, label %1021, label %1028

1021:                                             ; preds = %1018, %1025
  %1022 = phi i32 [ %1026, %1025 ], [ %1019, %1018 ]
  %1023 = getelementptr inbounds nuw i8, ptr %0, i32 %1022
  %1024 = load i8, ptr %1023, align 1, !tbaa !2
  switch i8 %1024, label %1028 [
    i8 32, label %1025
    i8 13, label %1025
    i8 10, label %1025
    i8 9, label %1025
  ]

1025:                                             ; preds = %1021, %1021, %1021, %1021
  %1026 = add i32 %1022, 1
  %1027 = icmp eq i32 %1026, %1
  br i1 %1027, label %1031, label %1021, !llvm.loop !35

1028:                                             ; preds = %1021, %1018
  %1029 = phi i32 [ %1019, %1018 ], [ %1022, %1021 ]
  %1030 = icmp ult i32 %1029, %1
  br i1 %1030, label %1033, label %1031

1031:                                             ; preds = %919, %1006, %1009, %1028, %916, %777, %893, %939, %941, %957, %962, %964, %985, %988, %953, %949, %946, %944, %870, %808, %818, %865, %821, %815, %827, %836, %845, %854, %1003, %1025, %1012
  %1032 = phi i32 [ %1017, %1012 ], [ 0, %1025 ], [ 0, %1003 ], [ 0, %854 ], [ 0, %845 ], [ 0, %836 ], [ 0, %827 ], [ 0, %815 ], [ 0, %821 ], [ 0, %865 ], [ 0, %818 ], [ 0, %808 ], [ 0, %870 ], [ 0, %944 ], [ 0, %946 ], [ 0, %949 ], [ 0, %953 ], [ 0, %988 ], [ 0, %985 ], [ 0, %964 ], [ 0, %962 ], [ 0, %957 ], [ 0, %941 ], [ 0, %939 ], [ 0, %893 ], [ 0, %777 ], [ 0, %916 ], [ 0, %1028 ], [ 0, %1009 ], [ 0, %1006 ], [ 0, %919 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %15) #28
  br label %1037

1033:                                             ; preds = %1028
  %1034 = getelementptr inbounds nuw i8, ptr %0, i32 %1029
  %1035 = load i8, ptr %1034, align 1, !tbaa !2
  %1036 = icmp eq i8 %1035, 93
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %15) #28
  br i1 %1036, label %1037, label %753, !llvm.loop !127

1037:                                             ; preds = %1033, %764, %753, %761, %1031, %726, %19, %18, %768, %728, %729
  %1038 = phi i32 [ 0, %729 ], [ 0, %728 ], [ %773, %768 ], [ %727, %726 ], [ 0, %19 ], [ 0, %18 ], [ %1032, %1031 ], [ 0, %761 ], [ 0, %753 ], [ 0, %764 ], [ 0, %1033 ]
  ret i32 %1038
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc range(i32 0, 2) i32 @scan_scalar_span(ptr noundef readonly captures(none) %0, i32 noundef %1, i32 noundef %2, ptr noundef nonnull writeonly captures(none) %3) unnamed_addr #19 {
  %5 = icmp ult i32 %2, %1
  br i1 %5, label %6, label %19

6:                                                ; preds = %4, %12
  %7 = phi i32 [ %14, %12 ], [ %2, %4 ]
  %8 = icmp eq i32 %7, %1
  br i1 %8, label %15, label %9

9:                                                ; preds = %6
  %10 = getelementptr inbounds nuw i8, ptr %0, i32 %7
  %11 = load i8, ptr %10, align 1, !tbaa !2
  switch i8 %11, label %12 [
    i8 125, label %15
    i8 93, label %15
    i8 44, label %15
    i8 32, label %15
    i8 13, label %15
    i8 10, label %15
  ]

12:                                               ; preds = %9
  %13 = icmp eq i8 %11, 9
  %14 = add i32 %7, 1
  br i1 %13, label %15, label %6

15:                                               ; preds = %9, %9, %9, %9, %9, %9, %12, %6
  %16 = phi i32 [ %7, %9 ], [ %7, %9 ], [ %7, %9 ], [ %7, %9 ], [ %7, %9 ], [ %7, %9 ], [ %7, %12 ], [ %1, %6 ]
  %17 = icmp eq i32 %16, %2
  br i1 %17, label %19, label %18

18:                                               ; preds = %15
  store i32 %16, ptr %3, align 4, !tbaa !5
  br label %19

19:                                               ; preds = %18, %15, %4
  %20 = phi i32 [ 0, %4 ], [ 1, %18 ], [ 0, %15 ]
  ret i32 %20
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc range(i32 0, 2) i32 @parse_int32_token(ptr noundef readonly captures(none) %0, i32 noundef %1, i32 noundef %2, i32 noundef range(i32 -1, 1) %3, ptr noundef nonnull writeonly captures(none) %4) unnamed_addr #19 {
  %6 = sub i32 %2, %1
  %7 = icmp eq i32 %6, 4
  br i1 %7, label %8, label %24

8:                                                ; preds = %5
  %9 = getelementptr inbounds nuw i8, ptr %0, i32 %1
  %10 = load i8, ptr %9, align 1, !tbaa !2
  %11 = icmp eq i8 %10, 110
  br i1 %11, label %12, label %24

12:                                               ; preds = %8
  %13 = getelementptr i8, ptr %9, i32 1
  %14 = load i8, ptr %13, align 1, !tbaa !2
  %15 = icmp eq i8 %14, 117
  br i1 %15, label %16, label %24

16:                                               ; preds = %12
  %17 = getelementptr i8, ptr %9, i32 2
  %18 = load i8, ptr %17, align 1, !tbaa !2
  %19 = icmp eq i8 %18, 108
  br i1 %19, label %20, label %24

20:                                               ; preds = %16
  %21 = getelementptr i8, ptr %9, i32 3
  %22 = load i8, ptr %21, align 1, !tbaa !2
  %23 = icmp eq i8 %22, 108
  br i1 %23, label %70, label %24

24:                                               ; preds = %8, %12, %16, %20, %5
  %25 = icmp ult i32 %1, %2
  br i1 %25, label %26, label %33

26:                                               ; preds = %24
  %27 = getelementptr inbounds nuw i8, ptr %0, i32 %1
  %28 = load i8, ptr %27, align 1, !tbaa !2
  %29 = icmp ne i8 %28, 45
  %30 = xor i1 %29, true
  %31 = zext i1 %30 to i32
  %32 = add nuw i32 %1, %31
  br label %33

33:                                               ; preds = %26, %24
  %34 = phi i1 [ true, %24 ], [ %29, %26 ]
  %35 = phi i32 [ %1, %24 ], [ %32, %26 ]
  %36 = icmp ult i32 %35, %2
  br i1 %36, label %37, label %72

37:                                               ; preds = %33
  %38 = getelementptr inbounds nuw i8, ptr %0, i32 %35
  %39 = load i8, ptr %38, align 1, !tbaa !2
  %40 = add i8 %39, -58
  %41 = icmp ult i8 %40, -10
  br i1 %41, label %72, label %42

42:                                               ; preds = %37
  %43 = icmp eq i8 %39, 48
  %44 = add nuw i32 %35, 1
  %45 = icmp ult i32 %44, %2
  %46 = and i1 %45, %43
  br i1 %46, label %72, label %47

47:                                               ; preds = %42
  %48 = select i1 %34, i32 2147483647, i32 -2147483648
  br label %49

49:                                               ; preds = %47, %62
  %50 = phi i32 [ %65, %62 ], [ %35, %47 ]
  %51 = phi i32 [ %64, %62 ], [ 0, %47 ]
  %52 = getelementptr inbounds nuw i8, ptr %0, i32 %50
  %53 = load i8, ptr %52, align 1, !tbaa !2
  %54 = add i8 %53, -58
  %55 = icmp ult i8 %54, -10
  br i1 %55, label %72, label %56

56:                                               ; preds = %49
  %57 = zext nneg i8 %53 to i32
  %58 = add nsw i32 %57, -48
  %59 = sub nuw i32 %48, %58
  %60 = udiv i32 %59, 10
  %61 = icmp ugt i32 %51, %60
  br i1 %61, label %72, label %62

62:                                               ; preds = %56
  %63 = mul nuw nsw i32 %51, 10
  %64 = add nuw i32 %58, %63
  %65 = add i32 %50, 1
  %66 = icmp eq i32 %65, %2
  br i1 %66, label %67, label %49, !llvm.loop !117

67:                                               ; preds = %62
  %68 = sub i32 0, %64
  %69 = select i1 %34, i32 %64, i32 %68
  br label %70

70:                                               ; preds = %20, %67
  %71 = phi i32 [ %69, %67 ], [ %3, %20 ]
  store i32 %71, ptr %4, align 4, !tbaa !5
  br label %72

72:                                               ; preds = %49, %56, %70, %37, %33, %42
  %73 = phi i32 [ 0, %37 ], [ 0, %33 ], [ 0, %42 ], [ 1, %70 ], [ 0, %56 ], [ 0, %49 ]
  ret i32 %73
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: read)
define internal fastcc i32 @raw_term_content_hash(ptr noundef readonly captures(address) %0, ptr noundef readonly captures(none) %1) unnamed_addr #18 {
  %3 = getelementptr inbounds nuw i8, ptr %1, i32 36
  %4 = load i32, ptr %3, align 4, !tbaa !27
  %5 = getelementptr inbounds nuw i8, ptr %0, i32 %4
  %6 = getelementptr inbounds nuw i8, ptr %1, i32 40
  %7 = load i32, ptr %6, align 4, !tbaa !29
  %8 = tail call fastcc i32 @hash_content_xxh32(ptr noundef %5, i32 noundef %7, i32 noundef -2128831035)
  %9 = getelementptr inbounds nuw i8, ptr %1, i32 24
  %10 = load i32, ptr %9, align 4, !tbaa !58
  %11 = getelementptr inbounds nuw i8, ptr %0, i32 %10
  %12 = getelementptr inbounds nuw i8, ptr %1, i32 28
  %13 = load i32, ptr %12, align 4, !tbaa !57
  %14 = tail call fastcc i32 @hash_content_xxh32(ptr noundef %11, i32 noundef %13, i32 noundef -1640531527)
  %15 = tail call noundef i32 @llvm.fshl.i32(i32 %14, i32 %14, i32 5)
  %16 = xor i32 %15, %8
  %17 = getelementptr inbounds nuw i8, ptr %1, i32 16
  %18 = load i32, ptr %17, align 4, !tbaa !60
  %19 = getelementptr inbounds nuw i8, ptr %0, i32 %18
  %20 = getelementptr inbounds nuw i8, ptr %1, i32 20
  %21 = load i32, ptr %20, align 4, !tbaa !59
  %22 = tail call fastcc i32 @hash_content_xxh32(ptr noundef %19, i32 noundef %21, i32 noundef -2048144789)
  %23 = tail call noundef i32 @llvm.fshl.i32(i32 %22, i32 %22, i32 11)
  %24 = xor i32 %16, %23
  %25 = getelementptr inbounds nuw i8, ptr %1, i32 48
  %26 = load i32, ptr %25, align 4, !tbaa !62
  %27 = getelementptr inbounds nuw i8, ptr %0, i32 %26
  %28 = getelementptr inbounds nuw i8, ptr %1, i32 52
  %29 = load i32, ptr %28, align 4, !tbaa !61
  %30 = tail call fastcc i32 @hash_content_xxh32(ptr noundef %27, i32 noundef %29, i32 noundef -1028477387)
  %31 = tail call noundef i32 @llvm.fshl.i32(i32 %30, i32 %30, i32 17)
  %32 = xor i32 %31, %24
  %33 = lshr i32 %32, 16
  %34 = xor i32 %33, %32
  %35 = icmp eq i32 %24, %31
  %36 = select i1 %35, i32 1, i32 %34
  ret i32 %36
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: read)
define internal fastcc range(i32 0, 2) i32 @raw_term_content_tokens_equal(ptr noundef readonly captures(none) %0, ptr noundef readonly captures(none) %1, ptr noundef readonly captures(none) %2, i32 noundef range(i32 0, 2) %3) unnamed_addr #18 {
  %5 = getelementptr inbounds nuw i8, ptr %1, i32 40
  %6 = load i32, ptr %5, align 4, !tbaa !29
  %7 = getelementptr inbounds nuw i8, ptr %2, i32 40
  %8 = load i32, ptr %7, align 4, !tbaa !29
  %9 = icmp eq i32 %6, %8
  br i1 %9, label %10, label %230

10:                                               ; preds = %4
  %11 = icmp eq i32 %3, 0
  br i1 %11, label %12, label %62

12:                                               ; preds = %10
  %13 = getelementptr inbounds nuw i8, ptr %1, i32 36
  %14 = load i32, ptr %13, align 4, !tbaa !27
  %15 = getelementptr inbounds nuw i8, ptr %2, i32 36
  %16 = load i32, ptr %15, align 4, !tbaa !27
  %17 = getelementptr i8, ptr %0, i32 %14
  %18 = getelementptr i8, ptr %0, i32 %16
  br label %19

19:                                               ; preds = %23, %12
  %20 = phi i32 [ 0, %12 ], [ %38, %23 ]
  %21 = sub nuw i32 %6, %20
  %22 = icmp ugt i32 %21, 31
  br i1 %22, label %23, label %39

23:                                               ; preds = %19
  %24 = getelementptr inbounds nuw i8, ptr %17, i32 %20
  %25 = getelementptr inbounds nuw i8, ptr %18, i32 %20
  %26 = load <4 x i32>, ptr %24, align 1, !tbaa !2
  %27 = load <4 x i32>, ptr %25, align 1, !tbaa !2
  %28 = xor <4 x i32> %27, %26
  %29 = getelementptr inbounds nuw i8, ptr %24, i32 16
  %30 = load <4 x i32>, ptr %29, align 1, !tbaa !2
  %31 = getelementptr inbounds nuw i8, ptr %25, i32 16
  %32 = load <4 x i32>, ptr %31, align 1, !tbaa !2
  %33 = xor <4 x i32> %32, %30
  %34 = or <4 x i32> %33, %28
  %35 = bitcast <4 x i32> %34 to <16 x i8>
  %36 = tail call i32 @llvm.wasm.anytrue.v16i8(<16 x i8> %35)
  %37 = icmp eq i32 %36, 0
  %38 = add i32 %20, 32
  br i1 %37, label %19, label %230, !llvm.loop !79

39:                                               ; preds = %19, %45
  %40 = phi i32 [ %51, %45 ], [ %20, %19 ]
  %41 = sub i32 %6, %40
  %42 = icmp ugt i32 %41, 7
  br i1 %42, label %45, label %43

43:                                               ; preds = %39
  %44 = icmp ult i32 %40, %6
  br i1 %44, label %55, label %62

45:                                               ; preds = %39
  %46 = getelementptr inbounds nuw i8, ptr %17, i32 %40
  %47 = load i64, ptr %46, align 1
  %48 = getelementptr inbounds nuw i8, ptr %18, i32 %40
  %49 = load i64, ptr %48, align 1
  %50 = icmp eq i64 %47, %49
  %51 = add i32 %40, 8
  br i1 %50, label %39, label %230, !llvm.loop !80

52:                                               ; preds = %55
  %53 = add nuw i32 %56, 1
  %54 = icmp ult i32 %53, %6
  br i1 %54, label %55, label %62, !llvm.loop !81

55:                                               ; preds = %43, %52
  %56 = phi i32 [ %53, %52 ], [ %40, %43 ]
  %57 = getelementptr i8, ptr %17, i32 %56
  %58 = load i8, ptr %57, align 1, !tbaa !2
  %59 = getelementptr i8, ptr %18, i32 %56
  %60 = load i8, ptr %59, align 1, !tbaa !2
  %61 = icmp eq i8 %58, %60
  br i1 %61, label %52, label %230

62:                                               ; preds = %52, %43, %10
  %63 = getelementptr inbounds nuw i8, ptr %1, i32 28
  %64 = load i32, ptr %63, align 4, !tbaa !57
  %65 = getelementptr inbounds nuw i8, ptr %2, i32 28
  %66 = load i32, ptr %65, align 4, !tbaa !57
  %67 = icmp eq i32 %64, %66
  br i1 %67, label %68, label %230

68:                                               ; preds = %62
  %69 = getelementptr inbounds nuw i8, ptr %1, i32 24
  %70 = load i32, ptr %69, align 4, !tbaa !58
  %71 = getelementptr inbounds nuw i8, ptr %2, i32 24
  %72 = load i32, ptr %71, align 4, !tbaa !58
  %73 = getelementptr i8, ptr %0, i32 %70
  %74 = getelementptr i8, ptr %0, i32 %72
  br label %75

75:                                               ; preds = %79, %68
  %76 = phi i32 [ 0, %68 ], [ %94, %79 ]
  %77 = sub nuw i32 %64, %76
  %78 = icmp ugt i32 %77, 31
  br i1 %78, label %79, label %95

79:                                               ; preds = %75
  %80 = getelementptr inbounds nuw i8, ptr %73, i32 %76
  %81 = getelementptr inbounds nuw i8, ptr %74, i32 %76
  %82 = load <4 x i32>, ptr %80, align 1, !tbaa !2
  %83 = load <4 x i32>, ptr %81, align 1, !tbaa !2
  %84 = xor <4 x i32> %83, %82
  %85 = getelementptr inbounds nuw i8, ptr %80, i32 16
  %86 = load <4 x i32>, ptr %85, align 1, !tbaa !2
  %87 = getelementptr inbounds nuw i8, ptr %81, i32 16
  %88 = load <4 x i32>, ptr %87, align 1, !tbaa !2
  %89 = xor <4 x i32> %88, %86
  %90 = or <4 x i32> %89, %84
  %91 = bitcast <4 x i32> %90 to <16 x i8>
  %92 = tail call i32 @llvm.wasm.anytrue.v16i8(<16 x i8> %91)
  %93 = icmp eq i32 %92, 0
  %94 = add i32 %76, 32
  br i1 %93, label %75, label %230, !llvm.loop !79

95:                                               ; preds = %75, %101
  %96 = phi i32 [ %107, %101 ], [ %76, %75 ]
  %97 = sub i32 %64, %96
  %98 = icmp ugt i32 %97, 7
  br i1 %98, label %101, label %99

99:                                               ; preds = %95
  %100 = icmp ult i32 %96, %64
  br i1 %100, label %111, label %118

101:                                              ; preds = %95
  %102 = getelementptr inbounds nuw i8, ptr %73, i32 %96
  %103 = load i64, ptr %102, align 1
  %104 = getelementptr inbounds nuw i8, ptr %74, i32 %96
  %105 = load i64, ptr %104, align 1
  %106 = icmp eq i64 %103, %105
  %107 = add i32 %96, 8
  br i1 %106, label %95, label %230, !llvm.loop !80

108:                                              ; preds = %111
  %109 = add nuw i32 %112, 1
  %110 = icmp ult i32 %109, %64
  br i1 %110, label %111, label %118, !llvm.loop !81

111:                                              ; preds = %99, %108
  %112 = phi i32 [ %109, %108 ], [ %96, %99 ]
  %113 = getelementptr i8, ptr %73, i32 %112
  %114 = load i8, ptr %113, align 1, !tbaa !2
  %115 = getelementptr i8, ptr %74, i32 %112
  %116 = load i8, ptr %115, align 1, !tbaa !2
  %117 = icmp eq i8 %114, %116
  br i1 %117, label %108, label %230

118:                                              ; preds = %108, %99
  %119 = getelementptr inbounds nuw i8, ptr %1, i32 20
  %120 = load i32, ptr %119, align 4, !tbaa !59
  %121 = getelementptr inbounds nuw i8, ptr %2, i32 20
  %122 = load i32, ptr %121, align 4, !tbaa !59
  %123 = icmp eq i32 %120, %122
  br i1 %123, label %124, label %230

124:                                              ; preds = %118
  %125 = getelementptr inbounds nuw i8, ptr %1, i32 16
  %126 = load i32, ptr %125, align 4, !tbaa !60
  %127 = getelementptr inbounds nuw i8, ptr %2, i32 16
  %128 = load i32, ptr %127, align 4, !tbaa !60
  %129 = getelementptr i8, ptr %0, i32 %126
  %130 = getelementptr i8, ptr %0, i32 %128
  br label %131

131:                                              ; preds = %135, %124
  %132 = phi i32 [ 0, %124 ], [ %150, %135 ]
  %133 = sub nuw i32 %120, %132
  %134 = icmp ugt i32 %133, 31
  br i1 %134, label %135, label %151

135:                                              ; preds = %131
  %136 = getelementptr inbounds nuw i8, ptr %129, i32 %132
  %137 = getelementptr inbounds nuw i8, ptr %130, i32 %132
  %138 = load <4 x i32>, ptr %136, align 1, !tbaa !2
  %139 = load <4 x i32>, ptr %137, align 1, !tbaa !2
  %140 = xor <4 x i32> %139, %138
  %141 = getelementptr inbounds nuw i8, ptr %136, i32 16
  %142 = load <4 x i32>, ptr %141, align 1, !tbaa !2
  %143 = getelementptr inbounds nuw i8, ptr %137, i32 16
  %144 = load <4 x i32>, ptr %143, align 1, !tbaa !2
  %145 = xor <4 x i32> %144, %142
  %146 = or <4 x i32> %145, %140
  %147 = bitcast <4 x i32> %146 to <16 x i8>
  %148 = tail call i32 @llvm.wasm.anytrue.v16i8(<16 x i8> %147)
  %149 = icmp eq i32 %148, 0
  %150 = add i32 %132, 32
  br i1 %149, label %131, label %230, !llvm.loop !79

151:                                              ; preds = %131, %157
  %152 = phi i32 [ %163, %157 ], [ %132, %131 ]
  %153 = sub i32 %120, %152
  %154 = icmp ugt i32 %153, 7
  br i1 %154, label %157, label %155

155:                                              ; preds = %151
  %156 = icmp ult i32 %152, %120
  br i1 %156, label %167, label %174

157:                                              ; preds = %151
  %158 = getelementptr inbounds nuw i8, ptr %129, i32 %152
  %159 = load i64, ptr %158, align 1
  %160 = getelementptr inbounds nuw i8, ptr %130, i32 %152
  %161 = load i64, ptr %160, align 1
  %162 = icmp eq i64 %159, %161
  %163 = add i32 %152, 8
  br i1 %162, label %151, label %230, !llvm.loop !80

164:                                              ; preds = %167
  %165 = add nuw i32 %168, 1
  %166 = icmp ult i32 %165, %120
  br i1 %166, label %167, label %174, !llvm.loop !81

167:                                              ; preds = %155, %164
  %168 = phi i32 [ %165, %164 ], [ %152, %155 ]
  %169 = getelementptr i8, ptr %129, i32 %168
  %170 = load i8, ptr %169, align 1, !tbaa !2
  %171 = getelementptr i8, ptr %130, i32 %168
  %172 = load i8, ptr %171, align 1, !tbaa !2
  %173 = icmp eq i8 %170, %172
  br i1 %173, label %164, label %230

174:                                              ; preds = %164, %155
  %175 = getelementptr inbounds nuw i8, ptr %1, i32 52
  %176 = load i32, ptr %175, align 4, !tbaa !61
  %177 = getelementptr inbounds nuw i8, ptr %2, i32 52
  %178 = load i32, ptr %177, align 4, !tbaa !61
  %179 = icmp eq i32 %176, %178
  br i1 %179, label %180, label %230

180:                                              ; preds = %174
  %181 = getelementptr inbounds nuw i8, ptr %1, i32 48
  %182 = load i32, ptr %181, align 4, !tbaa !62
  %183 = getelementptr inbounds nuw i8, ptr %2, i32 48
  %184 = load i32, ptr %183, align 4, !tbaa !62
  %185 = getelementptr i8, ptr %0, i32 %182
  %186 = getelementptr i8, ptr %0, i32 %184
  br label %187

187:                                              ; preds = %191, %180
  %188 = phi i32 [ 0, %180 ], [ %206, %191 ]
  %189 = sub nuw i32 %176, %188
  %190 = icmp ugt i32 %189, 31
  br i1 %190, label %191, label %207

191:                                              ; preds = %187
  %192 = getelementptr inbounds nuw i8, ptr %185, i32 %188
  %193 = getelementptr inbounds nuw i8, ptr %186, i32 %188
  %194 = load <4 x i32>, ptr %192, align 1, !tbaa !2
  %195 = load <4 x i32>, ptr %193, align 1, !tbaa !2
  %196 = xor <4 x i32> %195, %194
  %197 = getelementptr inbounds nuw i8, ptr %192, i32 16
  %198 = load <4 x i32>, ptr %197, align 1, !tbaa !2
  %199 = getelementptr inbounds nuw i8, ptr %193, i32 16
  %200 = load <4 x i32>, ptr %199, align 1, !tbaa !2
  %201 = xor <4 x i32> %200, %198
  %202 = or <4 x i32> %201, %196
  %203 = bitcast <4 x i32> %202 to <16 x i8>
  %204 = tail call i32 @llvm.wasm.anytrue.v16i8(<16 x i8> %203)
  %205 = icmp eq i32 %204, 0
  %206 = add i32 %188, 32
  br i1 %205, label %187, label %230, !llvm.loop !79

207:                                              ; preds = %187, %213
  %208 = phi i32 [ %219, %213 ], [ %188, %187 ]
  %209 = sub i32 %176, %208
  %210 = icmp ugt i32 %209, 7
  br i1 %210, label %213, label %211

211:                                              ; preds = %207
  %212 = icmp ult i32 %208, %176
  br i1 %212, label %223, label %230

213:                                              ; preds = %207
  %214 = getelementptr inbounds nuw i8, ptr %185, i32 %208
  %215 = load i64, ptr %214, align 1
  %216 = getelementptr inbounds nuw i8, ptr %186, i32 %208
  %217 = load i64, ptr %216, align 1
  %218 = icmp eq i64 %215, %217
  %219 = add i32 %208, 8
  br i1 %218, label %207, label %230, !llvm.loop !80

220:                                              ; preds = %223
  %221 = add nuw i32 %224, 1
  %222 = icmp ult i32 %221, %176
  br i1 %222, label %223, label %230, !llvm.loop !81

223:                                              ; preds = %211, %220
  %224 = phi i32 [ %221, %220 ], [ %208, %211 ]
  %225 = getelementptr i8, ptr %185, i32 %224
  %226 = load i8, ptr %225, align 1, !tbaa !2
  %227 = getelementptr i8, ptr %186, i32 %224
  %228 = load i8, ptr %227, align 1, !tbaa !2
  %229 = icmp eq i8 %226, %228
  br i1 %229, label %220, label %230

230:                                              ; preds = %23, %45, %55, %79, %101, %111, %135, %157, %167, %191, %213, %223, %220, %211, %174, %118, %62, %4
  %231 = phi i32 [ 0, %174 ], [ 0, %118 ], [ 0, %62 ], [ 0, %4 ], [ 1, %211 ], [ 1, %220 ], [ 0, %223 ], [ 0, %213 ], [ 0, %191 ], [ 0, %167 ], [ 0, %157 ], [ 0, %135 ], [ 0, %111 ], [ 0, %101 ], [ 0, %79 ], [ 0, %55 ], [ 0, %45 ], [ 0, %23 ]
  ret i32 %231
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: read)
define internal fastcc i32 @raw_term_content_quick_signature(ptr noundef readonly captures(none) %0, ptr noundef readonly captures(none) %1) unnamed_addr #18 {
  %3 = getelementptr inbounds nuw i8, ptr %1, i32 40
  %4 = load i32, ptr %3, align 4, !tbaa !29
  %5 = getelementptr inbounds nuw i8, ptr %1, i32 36
  %6 = load i32, ptr %5, align 4, !tbaa !27
  %7 = getelementptr inbounds nuw i8, ptr %0, i32 %6
  %8 = tail call i32 @llvm.usub.sat.i32(i32 %4, i32 4)
  %9 = icmp eq i32 %4, 0
  br i1 %9, label %72, label %10

10:                                               ; preds = %2
  %11 = icmp ugt i32 %4, 3
  br i1 %11, label %29, label %12

12:                                               ; preds = %10
  %13 = load i8, ptr %7, align 1, !tbaa !2
  %14 = zext i8 %13 to i32
  %15 = icmp eq i32 %4, 1
  br i1 %15, label %72, label %16, !llvm.loop !128

16:                                               ; preds = %12
  %17 = getelementptr i8, ptr %7, i32 1
  %18 = load i8, ptr %17, align 1, !tbaa !2
  %19 = zext i8 %18 to i32
  %20 = shl nuw nsw i32 %19, 8
  %21 = or disjoint i32 %20, %14
  %22 = icmp eq i32 %4, 2
  br i1 %22, label %72, label %23, !llvm.loop !128

23:                                               ; preds = %16
  %24 = getelementptr i8, ptr %7, i32 2
  %25 = load i8, ptr %24, align 1, !tbaa !2
  %26 = zext i8 %25 to i32
  %27 = shl nuw nsw i32 %26, 16
  %28 = or disjoint i32 %27, %21
  br label %72

29:                                               ; preds = %10
  %30 = load i32, ptr %7, align 1
  %31 = icmp eq i32 %4, 4
  br i1 %31, label %72, label %32

32:                                               ; preds = %29
  %33 = lshr i32 %8, 1
  %34 = icmp ult i32 %33, %4
  br i1 %34, label %35, label %52

35:                                               ; preds = %32
  %36 = sub nuw i32 %4, %33
  %37 = icmp ugt i32 %36, 3
  %38 = getelementptr i8, ptr %7, i32 %33
  br i1 %37, label %39, label %41

39:                                               ; preds = %35
  %40 = load i32, ptr %38, align 1
  br label %52

41:                                               ; preds = %35, %41
  %42 = phi i32 [ %50, %41 ], [ 0, %35 ]
  %43 = phi i32 [ %49, %41 ], [ 0, %35 ]
  %44 = getelementptr i8, ptr %38, i32 %42
  %45 = load i8, ptr %44, align 1, !tbaa !2
  %46 = zext i8 %45 to i32
  %47 = shl nuw nsw i32 %42, 3
  %48 = shl nuw nsw i32 %46, %47
  %49 = or i32 %48, %43
  %50 = add nuw nsw i32 %42, 1
  %51 = icmp eq i32 %50, %36
  br i1 %51, label %52, label %41, !llvm.loop !129

52:                                               ; preds = %41, %32, %39
  %53 = phi i32 [ %40, %39 ], [ 0, %32 ], [ %49, %41 ]
  %54 = icmp ult i32 %8, %4
  br i1 %54, label %55, label %72

55:                                               ; preds = %52
  %56 = sub nuw i32 %4, %8
  %57 = icmp ugt i32 %56, 3
  %58 = getelementptr i8, ptr %7, i32 %8
  br i1 %57, label %59, label %61

59:                                               ; preds = %55
  %60 = load i32, ptr %58, align 1
  br label %72

61:                                               ; preds = %55, %61
  %62 = phi i32 [ %70, %61 ], [ 0, %55 ]
  %63 = phi i32 [ %69, %61 ], [ 0, %55 ]
  %64 = getelementptr i8, ptr %58, i32 %62
  %65 = load i8, ptr %64, align 1, !tbaa !2
  %66 = zext i8 %65 to i32
  %67 = shl nuw nsw i32 %62, 3
  %68 = shl nuw nsw i32 %66, %67
  %69 = or i32 %68, %63
  %70 = add nuw nsw i32 %62, 1
  %71 = icmp eq i32 %70, %56
  br i1 %71, label %72, label %61, !llvm.loop !130

72:                                               ; preds = %12, %16, %23, %61, %29, %59, %52, %2
  %73 = phi i32 [ 0, %2 ], [ %53, %52 ], [ %53, %59 ], [ %30, %29 ], [ %53, %61 ], [ %14, %12 ], [ %21, %16 ], [ %28, %23 ]
  %74 = phi i32 [ 0, %2 ], [ %30, %52 ], [ %30, %59 ], [ %30, %29 ], [ %30, %61 ], [ %14, %12 ], [ %21, %16 ], [ %28, %23 ]
  %75 = phi i32 [ 0, %2 ], [ 0, %52 ], [ %60, %59 ], [ %30, %29 ], [ %69, %61 ], [ %14, %12 ], [ %21, %16 ], [ %28, %23 ]
  %76 = mul i32 %4, -1640531535
  %77 = getelementptr inbounds nuw i8, ptr %1, i32 28
  %78 = load i32, ptr %77, align 4, !tbaa !57
  %79 = mul i32 %78, -2048144789
  %80 = getelementptr inbounds nuw i8, ptr %1, i32 20
  %81 = load i32, ptr %80, align 4, !tbaa !59
  %82 = mul i32 %81, -1028477387
  %83 = getelementptr inbounds nuw i8, ptr %1, i32 52
  %84 = load i32, ptr %83, align 4, !tbaa !61
  %85 = mul i32 %84, 668265263
  %86 = xor i32 %74, %76
  %87 = xor i32 %86, %79
  %88 = xor i32 %87, %82
  %89 = xor i32 %88, %85
  %90 = tail call i32 @llvm.fshl.i32(i32 %89, i32 %89, i32 13)
  %91 = mul i32 %73, 374761393
  %92 = xor i32 %90, %91
  %93 = tail call i32 @llvm.fshl.i32(i32 %92, i32 %92, i32 11)
  %94 = xor i32 %93, %75
  ret i32 %94
}

; Function Attrs: nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: none)
define internal fastcc range(i32 -1, 2) i32 @next_term_row(ptr noundef nonnull captures(none) %0, i32 noundef %1) unnamed_addr #20 {
  %3 = load ptr, ptr %0, align 4, !tbaa !45
  %4 = getelementptr inbounds nuw i8, ptr %0, i32 20
  %5 = load i32, ptr %4, align 4, !tbaa !54
  %6 = icmp ult i32 %1, %5
  br i1 %6, label %7, label %14

7:                                                ; preds = %2, %11
  %8 = phi i32 [ %12, %11 ], [ %1, %2 ]
  %9 = getelementptr inbounds nuw i8, ptr %3, i32 %8
  %10 = load i8, ptr %9, align 1, !tbaa !2
  switch i8 %10, label %14 [
    i8 32, label %11
    i8 13, label %11
    i8 10, label %11
    i8 9, label %11
  ]

11:                                               ; preds = %7, %7, %7, %7
  %12 = add i32 %8, 1
  %13 = icmp eq i32 %12, %5
  br i1 %13, label %54, label %7, !llvm.loop !35

14:                                               ; preds = %7, %2
  %15 = phi i32 [ %1, %2 ], [ %8, %7 ]
  %16 = icmp ult i32 %15, %5
  br i1 %16, label %17, label %54

17:                                               ; preds = %14
  %18 = getelementptr inbounds nuw i8, ptr %3, i32 %15
  %19 = load i8, ptr %18, align 1, !tbaa !2
  switch i8 %19, label %54 [
    i8 93, label %20
    i8 44, label %35
  ]

20:                                               ; preds = %17
  %21 = add nuw i32 %15, 1
  %22 = icmp ult i32 %21, %5
  br i1 %22, label %23, label %30

23:                                               ; preds = %20, %27
  %24 = phi i32 [ %28, %27 ], [ %21, %20 ]
  %25 = getelementptr inbounds nuw i8, ptr %3, i32 %24
  %26 = load i8, ptr %25, align 1, !tbaa !2
  switch i8 %26, label %30 [
    i8 32, label %27
    i8 13, label %27
    i8 10, label %27
    i8 9, label %27
  ]

27:                                               ; preds = %23, %23, %23, %23
  %28 = add i32 %24, 1
  %29 = icmp eq i32 %28, %5
  br i1 %29, label %33, label %23, !llvm.loop !35

30:                                               ; preds = %23, %20
  %31 = phi i32 [ %21, %20 ], [ %24, %23 ]
  %32 = icmp eq i32 %31, %5
  br i1 %32, label %33, label %54

33:                                               ; preds = %27, %30
  %34 = tail call fastcc i32 @next_term_bank(ptr noundef %0)
  br label %54

35:                                               ; preds = %17
  %36 = add nuw i32 %15, 1
  %37 = icmp ult i32 %36, %5
  br i1 %37, label %38, label %45

38:                                               ; preds = %35, %42
  %39 = phi i32 [ %43, %42 ], [ %36, %35 ]
  %40 = getelementptr inbounds nuw i8, ptr %3, i32 %39
  %41 = load i8, ptr %40, align 1, !tbaa !2
  switch i8 %41, label %45 [
    i8 32, label %42
    i8 13, label %42
    i8 10, label %42
    i8 9, label %42
  ]

42:                                               ; preds = %38, %38, %38, %38
  %43 = add i32 %39, 1
  %44 = icmp eq i32 %43, %5
  br i1 %44, label %54, label %38, !llvm.loop !35

45:                                               ; preds = %38, %35
  %46 = phi i32 [ %36, %35 ], [ %39, %38 ]
  %47 = icmp ult i32 %46, %5
  br i1 %47, label %48, label %54

48:                                               ; preds = %45
  %49 = getelementptr inbounds nuw i8, ptr %3, i32 %46
  %50 = load i8, ptr %49, align 1, !tbaa !2
  %51 = icmp eq i8 %50, 93
  br i1 %51, label %54, label %52

52:                                               ; preds = %48
  %53 = getelementptr inbounds nuw i8, ptr %0, i32 24
  store i32 %46, ptr %53, align 4, !tbaa !55
  br label %54

54:                                               ; preds = %11, %42, %45, %48, %17, %30, %14, %52, %33
  %55 = phi i32 [ %34, %33 ], [ 1, %52 ], [ -1, %14 ], [ -1, %30 ], [ -1, %17 ], [ -1, %48 ], [ -1, %45 ], [ -1, %42 ], [ -1, %11 ]
  ret i32 %55
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define i32 @compact_term_lookup_keys(i32 noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, i32 noundef %4, i32 noundef %5, i32 noundef %6, i32 noundef %7, i32 noundef %8, i32 noundef %9, i32 noundef %10, i32 noundef %11, i32 noundef %12, i32 noundef %13, i32 noundef %14, i32 noundef %15, i32 noundef %16, i32 noundef %17, i32 noundef %18, i32 noundef %19) local_unnamed_addr #8 {
  %21 = add i32 %9, -65535
  %22 = icmp ult i32 %21, -65534
  %23 = insertelement <16 x i32> poison, i32 %5, i64 0
  %24 = insertelement <16 x i32> %23, i32 %0, i64 1
  %25 = insertelement <16 x i32> %24, i32 %2, i64 2
  %26 = insertelement <16 x i32> %25, i32 %3, i64 3
  %27 = insertelement <16 x i32> %26, i32 %4, i64 4
  %28 = insertelement <16 x i32> %27, i32 %6, i64 5
  %29 = insertelement <16 x i32> %28, i32 %7, i64 6
  %30 = insertelement <16 x i32> %29, i32 %8, i64 7
  %31 = insertelement <16 x i32> %30, i32 %10, i64 8
  %32 = insertelement <16 x i32> %31, i32 %19, i64 9
  %33 = insertelement <16 x i32> %32, i32 %11, i64 10
  %34 = insertelement <16 x i32> %33, i32 %12, i64 11
  %35 = insertelement <16 x i32> %34, i32 %13, i64 12
  %36 = insertelement <16 x i32> %35, i32 %14, i64 13
  %37 = insertelement <16 x i32> %36, i32 %15, i64 14
  %38 = insertelement <16 x i32> %37, i32 %16, i64 15
  %39 = icmp eq <16 x i32> %38, zeroinitializer
  %40 = icmp ugt i32 %18, 65534
  %41 = icmp ugt i32 %5, 1073741823
  %42 = bitcast <16 x i1> %39 to i16
  %43 = icmp ne i16 %42, 0
  %44 = or i1 %43, %40
  %45 = or i1 %41, %22
  %46 = or i1 %44, %45
  br i1 %46, label %179, label %47

47:                                               ; preds = %20
  %48 = inttoptr i32 %0 to ptr
  %49 = inttoptr i32 %2 to ptr
  %50 = inttoptr i32 %3 to ptr
  %51 = inttoptr i32 %4 to ptr
  %52 = inttoptr i32 %6 to ptr
  %53 = inttoptr i32 %7 to ptr
  %54 = inttoptr i32 %8 to ptr
  %55 = inttoptr i32 %10 to ptr
  %56 = inttoptr i32 %11 to ptr
  %57 = inttoptr i32 %12 to ptr
  %58 = inttoptr i32 %13 to ptr
  %59 = inttoptr i32 %14 to ptr
  %60 = inttoptr i32 %15 to ptr
  %61 = inttoptr i32 %16 to ptr
  %62 = inttoptr i32 %19 to ptr
  br label %63

63:                                               ; preds = %47, %77
  %64 = phi i32 [ %79, %77 ], [ 0, %47 ]
  %65 = phi i32 [ %78, %77 ], [ 0, %47 ]
  %66 = getelementptr inbounds nuw i32, ptr %50, i32 %64
  %67 = load i32, ptr %66, align 4, !tbaa !5
  %68 = icmp ne i32 %67, %65
  %69 = icmp ugt i32 %65, %1
  %70 = or i1 %69, %68
  br i1 %70, label %179, label %71

71:                                               ; preds = %63
  %72 = getelementptr inbounds nuw i16, ptr %49, i32 %64
  %73 = load i16, ptr %72, align 2, !tbaa !77
  %74 = zext i16 %73 to i32
  %75 = sub nuw i32 %1, %65
  %76 = icmp ult i32 %75, %74
  br i1 %76, label %179, label %77

77:                                               ; preds = %71
  %78 = add i32 %65, %74
  %79 = add nuw i32 %64, 1
  %80 = icmp eq i32 %79, %5
  br i1 %80, label %81, label %63, !llvm.loop !131

81:                                               ; preds = %77
  %82 = icmp eq i32 %78, %1
  br i1 %82, label %83, label %179

83:                                               ; preds = %81
  %84 = shl nuw i32 %5, 2
  tail call void @llvm.memset.p0.i32(ptr align 4 %55, i8 0, i32 %84, i1 false)
  %85 = icmp eq i32 %9, 0
  br i1 %85, label %176, label %86

86:                                               ; preds = %83, %169
  %87 = phi i32 [ %174, %169 ], [ 0, %83 ]
  %88 = phi i32 [ %171, %169 ], [ 0, %83 ]
  %89 = phi i32 [ %170, %169 ], [ 0, %83 ]
  %90 = getelementptr inbounds nuw i8, ptr %54, i32 %87
  %91 = load i8, ptr %90, align 1, !tbaa !2
  %92 = icmp ugt i8 %91, 1
  br i1 %92, label %179, label %93

93:                                               ; preds = %86
  %94 = getelementptr inbounds nuw i32, ptr %52, i32 %87
  %95 = load i32, ptr %94, align 4, !tbaa !5
  %96 = icmp eq i8 %91, 0
  %97 = getelementptr inbounds nuw i32, ptr %53, i32 %87
  %98 = select i1 %96, ptr %97, ptr %94
  %99 = load i32, ptr %98, align 4, !tbaa !5
  %100 = getelementptr inbounds nuw i32, ptr %60, i32 %87
  %101 = getelementptr inbounds nuw i32, ptr %59, i32 %87
  %102 = icmp ult i32 %95, %5
  br i1 %102, label %103, label %179

103:                                              ; preds = %93
  %104 = getelementptr inbounds nuw i16, ptr %49, i32 %95
  %105 = load i16, ptr %104, align 2, !tbaa !77
  %106 = zext i16 %105 to i32
  %107 = icmp eq i16 %105, 0
  br i1 %107, label %179, label %108

108:                                              ; preds = %103
  %109 = getelementptr inbounds nuw i32, ptr %55, i32 %95
  %110 = load i32, ptr %109, align 4, !tbaa !5
  %111 = icmp eq i32 %110, 0
  br i1 %111, label %112, label %133

112:                                              ; preds = %108
  %113 = icmp uge i32 %89, %18
  %114 = sub i32 %17, %88
  %115 = icmp ult i32 %114, %106
  %116 = select i1 %113, i1 true, i1 %115
  br i1 %116, label %179, label %117

117:                                              ; preds = %112
  %118 = getelementptr inbounds nuw i16, ptr %56, i32 %89
  store i16 %105, ptr %118, align 2, !tbaa !77
  %119 = getelementptr inbounds nuw i32, ptr %57, i32 %89
  store i32 %88, ptr %119, align 4, !tbaa !5
  %120 = getelementptr inbounds nuw i32, ptr %51, i32 %95
  %121 = load i32, ptr %120, align 4, !tbaa !5
  %122 = getelementptr inbounds nuw i32, ptr %58, i32 %89
  store i32 %121, ptr %122, align 4, !tbaa !5
  %123 = getelementptr inbounds nuw i8, ptr %61, i32 %88
  %124 = getelementptr inbounds nuw i32, ptr %50, i32 %95
  %125 = load i32, ptr %124, align 4, !tbaa !5
  %126 = getelementptr inbounds nuw i8, ptr %48, i32 %125
  %127 = load i16, ptr %104, align 2, !tbaa !77
  %128 = zext i16 %127 to i32
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %123, ptr align 1 %126, i32 %128, i1 false)
  %129 = load i16, ptr %104, align 2, !tbaa !77
  %130 = zext i16 %129 to i32
  %131 = add i32 %88, %130
  %132 = add nuw i32 %89, 1
  store i32 %132, ptr %109, align 4, !tbaa !5
  br label %133

133:                                              ; preds = %117, %108
  %134 = phi i32 [ %132, %117 ], [ %89, %108 ]
  %135 = phi i32 [ %131, %117 ], [ %88, %108 ]
  %136 = phi i32 [ %132, %117 ], [ %110, %108 ]
  %137 = add i32 %136, -1
  store i32 %137, ptr %101, align 4, !tbaa !5
  %138 = icmp ult i32 %99, %5
  br i1 %138, label %139, label %179

139:                                              ; preds = %133
  %140 = getelementptr inbounds nuw i16, ptr %49, i32 %99
  %141 = load i16, ptr %140, align 2, !tbaa !77
  %142 = zext i16 %141 to i32
  %143 = icmp eq i16 %141, 0
  br i1 %143, label %179, label %144

144:                                              ; preds = %139
  %145 = getelementptr inbounds nuw i32, ptr %55, i32 %99
  %146 = load i32, ptr %145, align 4, !tbaa !5
  %147 = icmp eq i32 %146, 0
  br i1 %147, label %148, label %169

148:                                              ; preds = %144
  %149 = icmp uge i32 %134, %18
  %150 = sub i32 %17, %135
  %151 = icmp ult i32 %150, %142
  %152 = select i1 %149, i1 true, i1 %151
  br i1 %152, label %179, label %153

153:                                              ; preds = %148
  %154 = getelementptr inbounds nuw i16, ptr %56, i32 %134
  store i16 %141, ptr %154, align 2, !tbaa !77
  %155 = getelementptr inbounds nuw i32, ptr %57, i32 %134
  store i32 %135, ptr %155, align 4, !tbaa !5
  %156 = getelementptr inbounds nuw i32, ptr %51, i32 %99
  %157 = load i32, ptr %156, align 4, !tbaa !5
  %158 = getelementptr inbounds nuw i32, ptr %58, i32 %134
  store i32 %157, ptr %158, align 4, !tbaa !5
  %159 = getelementptr inbounds nuw i8, ptr %61, i32 %135
  %160 = getelementptr inbounds nuw i32, ptr %50, i32 %99
  %161 = load i32, ptr %160, align 4, !tbaa !5
  %162 = getelementptr inbounds nuw i8, ptr %48, i32 %161
  %163 = load i16, ptr %140, align 2, !tbaa !77
  %164 = zext i16 %163 to i32
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %159, ptr align 1 %162, i32 %164, i1 false)
  %165 = load i16, ptr %140, align 2, !tbaa !77
  %166 = zext i16 %165 to i32
  %167 = add i32 %135, %166
  %168 = add nuw i32 %134, 1
  store i32 %168, ptr %145, align 4, !tbaa !5
  br label %169

169:                                              ; preds = %153, %144
  %170 = phi i32 [ %168, %153 ], [ %134, %144 ]
  %171 = phi i32 [ %167, %153 ], [ %135, %144 ]
  %172 = phi i32 [ %168, %153 ], [ %146, %144 ]
  %173 = add i32 %172, -1
  store i32 %173, ptr %100, align 4, !tbaa !5
  %174 = add nuw i32 %87, 1
  %175 = icmp eq i32 %174, %9
  br i1 %175, label %176, label %86, !llvm.loop !132

176:                                              ; preds = %169, %83
  %177 = phi i32 [ 0, %83 ], [ %170, %169 ]
  %178 = phi i32 [ 0, %83 ], [ %171, %169 ]
  store i32 %178, ptr %62, align 4, !tbaa !5
  br label %179

179:                                              ; preds = %71, %63, %86, %103, %93, %112, %133, %139, %148, %81, %176, %20
  %180 = phi i32 [ -1, %20 ], [ -2, %81 ], [ %177, %176 ], [ -3, %86 ], [ -4, %148 ], [ -3, %139 ], [ -3, %133 ], [ -3, %103 ], [ -3, %93 ], [ -4, %112 ], [ -2, %63 ], [ -2, %71 ]
  ret i32 %180
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn
declare i32 @llvm.wasm.memory.grow.i32(i32, i32) #21

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define internal fastcc range(i32 0, 2) i32 @parse_value_span(ptr noundef %0, i32 noundef %1, i32 noundef %2, ptr noundef nonnull writeonly captures(none) %3) unnamed_addr #8 {
  %5 = icmp ult i32 %2, %1
  br i1 %5, label %6, label %115

6:                                                ; preds = %4
  %7 = getelementptr inbounds nuw i8, ptr %0, i32 %2
  %8 = load i8, ptr %7, align 1, !tbaa !2
  %9 = icmp eq i8 %8, 34
  br i1 %9, label %10, label %108

10:                                               ; preds = %6
  %11 = add nuw i32 %2, 1
  %12 = icmp ult i32 %11, %1
  br i1 %12, label %13, label %115

13:                                               ; preds = %10
  %14 = getelementptr i8, ptr %0, i32 3
  %15 = getelementptr i8, ptr %0, i32 4
  %16 = getelementptr i8, ptr %0, i32 5
  br label %17

17:                                               ; preds = %35, %13
  %18 = phi i32 [ %11, %13 ], [ %36, %35 ]
  %19 = add i32 %18, 8
  %20 = icmp ugt i32 %19, %1
  br i1 %20, label %42, label %21

21:                                               ; preds = %17
  %22 = getelementptr inbounds nuw i8, ptr %0, i32 %18
  %23 = load i64, ptr %22, align 1
  %24 = xor i64 %23, 2459565876494606882
  %25 = add i64 %24, -72340172838076673
  %26 = and i64 %23, -9187201950435737472
  %27 = xor i64 %26, -9187201950435737472
  %28 = xor i64 %23, 6655295901103053916
  %29 = add i64 %28, -72340172838076673
  %30 = or i64 %25, %29
  %31 = add i64 %23, -2314885530818453536
  %32 = or i64 %30, %31
  %33 = and i64 %27, %32
  %34 = icmp eq i64 %33, 0
  br i1 %34, label %35, label %37

35:                                               ; preds = %21, %105
  %36 = phi i32 [ %19, %21 ], [ %106, %105 ]
  br label %17

37:                                               ; preds = %21
  %38 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %33, i1 true)
  %39 = trunc nuw nsw i64 %38 to i32
  %40 = lshr i32 %39, 3
  %41 = add i32 %40, %18
  br label %42

42:                                               ; preds = %17, %37
  %43 = phi i32 [ %41, %37 ], [ %18, %17 ]
  %44 = icmp ult i32 %43, %1
  br i1 %44, label %45, label %115

45:                                               ; preds = %42
  %46 = getelementptr inbounds nuw i8, ptr %0, i32 %43
  %47 = load i8, ptr %46, align 1, !tbaa !2
  %48 = icmp eq i8 %47, 92
  br i1 %48, label %49, label %99

49:                                               ; preds = %45
  %50 = add nuw i32 %43, 1
  %51 = icmp ult i32 %50, %1
  br i1 %51, label %52, label %115

52:                                               ; preds = %49
  %53 = getelementptr inbounds nuw i8, ptr %0, i32 %50
  %54 = load i8, ptr %53, align 1, !tbaa !2
  switch i8 %54, label %115 [
    i8 117, label %55
    i8 116, label %97
    i8 114, label %97
    i8 110, label %97
    i8 102, label %97
    i8 98, label %97
    i8 92, label %97
    i8 47, label %97
    i8 34, label %97
  ]

55:                                               ; preds = %52
  %56 = add i32 %43, 6
  %57 = icmp ugt i32 %56, %1
  br i1 %57, label %115, label %58

58:                                               ; preds = %55
  %59 = add nuw i32 %43, 2
  %60 = icmp ult i32 %59, %56
  br i1 %60, label %61, label %105

61:                                               ; preds = %58
  %62 = getelementptr inbounds nuw i8, ptr %0, i32 %59
  %63 = load i8, ptr %62, align 1, !tbaa !2
  %64 = add i8 %63, -58
  %65 = icmp ult i8 %64, -10
  %66 = and i8 %63, -33
  %67 = add i8 %66, -71
  %68 = icmp ult i8 %67, -6
  %69 = and i1 %65, %68
  br i1 %69, label %115, label %70

70:                                               ; preds = %61
  %71 = getelementptr i8, ptr %14, i32 %43
  %72 = load i8, ptr %71, align 1, !tbaa !2
  %73 = add i8 %72, -58
  %74 = icmp ult i8 %73, -10
  %75 = and i8 %72, -33
  %76 = add i8 %75, -71
  %77 = icmp ult i8 %76, -6
  %78 = and i1 %74, %77
  br i1 %78, label %115, label %79

79:                                               ; preds = %70
  %80 = getelementptr i8, ptr %15, i32 %43
  %81 = load i8, ptr %80, align 1, !tbaa !2
  %82 = add i8 %81, -58
  %83 = icmp ult i8 %82, -10
  %84 = and i8 %81, -33
  %85 = add i8 %84, -71
  %86 = icmp ult i8 %85, -6
  %87 = and i1 %83, %86
  br i1 %87, label %115, label %88

88:                                               ; preds = %79
  %89 = getelementptr i8, ptr %16, i32 %43
  %90 = load i8, ptr %89, align 1, !tbaa !2
  %91 = add i8 %90, -58
  %92 = icmp ult i8 %91, -10
  %93 = and i8 %90, -33
  %94 = add i8 %93, -71
  %95 = icmp ult i8 %94, -6
  %96 = and i1 %92, %95
  br i1 %96, label %115, label %105

97:                                               ; preds = %52, %52, %52, %52, %52, %52, %52, %52
  %98 = add nuw i32 %43, 2
  br label %105, !llvm.loop !42

99:                                               ; preds = %45
  %100 = icmp ult i8 %47, 32
  br i1 %100, label %115, label %101

101:                                              ; preds = %99
  %102 = icmp eq i8 %47, 34
  %103 = add nuw i32 %43, 1
  br i1 %102, label %104, label %105

104:                                              ; preds = %101
  store i32 %103, ptr %3, align 4, !tbaa !5
  br label %115

105:                                              ; preds = %101, %88, %58, %97
  %106 = phi i32 [ %98, %97 ], [ %56, %58 ], [ %56, %88 ], [ %103, %101 ]
  %107 = icmp ult i32 %106, %1
  br i1 %107, label %35, label %115

108:                                              ; preds = %6
  %109 = and i8 %8, -33
  %110 = icmp eq i8 %109, 91
  br i1 %110, label %111, label %113

111:                                              ; preds = %108
  %112 = tail call fastcc range(i32 0, 2) i32 @parse_composite_span_impl(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %2, ptr noundef nonnull %3, ptr noundef null, ptr noundef null, ptr noundef null, i32 noundef 0)
  br label %115

113:                                              ; preds = %108
  %114 = tail call fastcc i32 @parse_scalar_span(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %2, ptr noundef %3)
  br label %115

115:                                              ; preds = %105, %42, %49, %55, %99, %52, %61, %70, %79, %88, %10, %104, %111, %113, %4
  %116 = phi i32 [ 0, %4 ], [ %112, %111 ], [ %114, %113 ], [ 1, %104 ], [ 0, %10 ], [ 0, %88 ], [ 0, %79 ], [ 0, %70 ], [ 0, %61 ], [ 0, %52 ], [ 0, %99 ], [ 0, %55 ], [ 0, %49 ], [ 0, %42 ], [ 0, %105 ]
  ret i32 %116
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc range(i32 0, 2) i32 @parse_scalar_span(ptr noundef readonly captures(none) %0, i32 noundef %1, i32 noundef %2, ptr noundef nonnull writeonly captures(none) %3) unnamed_addr #19 {
  %5 = icmp ult i32 %2, %1
  br i1 %5, label %6, label %83

6:                                                ; preds = %4, %12
  %7 = phi i32 [ %14, %12 ], [ %2, %4 ]
  %8 = icmp eq i32 %7, %1
  br i1 %8, label %15, label %9

9:                                                ; preds = %6
  %10 = getelementptr inbounds nuw i8, ptr %0, i32 %7
  %11 = load i8, ptr %10, align 1, !tbaa !2
  switch i8 %11, label %12 [
    i8 125, label %15
    i8 93, label %15
    i8 44, label %15
    i8 32, label %15
    i8 13, label %15
    i8 10, label %15
  ]

12:                                               ; preds = %9
  %13 = icmp eq i8 %11, 9
  %14 = add i32 %7, 1
  br i1 %13, label %15, label %6

15:                                               ; preds = %12, %9, %9, %9, %9, %9, %9, %6
  %16 = phi i32 [ %7, %9 ], [ %7, %9 ], [ %7, %9 ], [ %7, %9 ], [ %7, %9 ], [ %7, %9 ], [ %7, %12 ], [ %1, %6 ]
  %17 = icmp eq i32 %16, %2
  br i1 %17, label %83, label %18

18:                                               ; preds = %15
  %19 = getelementptr inbounds nuw i8, ptr %0, i32 %2
  %20 = load i8, ptr %19, align 1, !tbaa !2
  switch i8 %20, label %79 [
    i8 116, label %21
    i8 102, label %39
    i8 110, label %61
  ]

21:                                               ; preds = %18
  %22 = sub i32 %16, %2
  %23 = icmp eq i32 %22, 4
  br i1 %23, label %24, label %83

24:                                               ; preds = %21
  %25 = load i8, ptr %19, align 1, !tbaa !2
  %26 = icmp eq i8 %25, 116
  br i1 %26, label %27, label %83, !llvm.loop !133

27:                                               ; preds = %24
  %28 = getelementptr i8, ptr %19, i32 1
  %29 = load i8, ptr %28, align 1, !tbaa !2
  %30 = icmp eq i8 %29, 114
  br i1 %30, label %31, label %83, !llvm.loop !133

31:                                               ; preds = %27
  %32 = getelementptr i8, ptr %19, i32 2
  %33 = load i8, ptr %32, align 1, !tbaa !2
  %34 = icmp eq i8 %33, 117
  br i1 %34, label %35, label %83, !llvm.loop !133

35:                                               ; preds = %31
  %36 = getelementptr i8, ptr %19, i32 3
  %37 = load i8, ptr %36, align 1, !tbaa !2
  %38 = icmp eq i8 %37, 101
  br i1 %38, label %82, label %83

39:                                               ; preds = %18
  %40 = sub i32 %16, %2
  %41 = icmp eq i32 %40, 5
  br i1 %41, label %42, label %83

42:                                               ; preds = %39
  %43 = load i8, ptr %19, align 1, !tbaa !2
  %44 = icmp eq i8 %43, 102
  br i1 %44, label %45, label %83, !llvm.loop !133

45:                                               ; preds = %42
  %46 = getelementptr i8, ptr %19, i32 1
  %47 = load i8, ptr %46, align 1, !tbaa !2
  %48 = icmp eq i8 %47, 97
  br i1 %48, label %49, label %83, !llvm.loop !133

49:                                               ; preds = %45
  %50 = getelementptr i8, ptr %19, i32 2
  %51 = load i8, ptr %50, align 1, !tbaa !2
  %52 = icmp eq i8 %51, 108
  br i1 %52, label %53, label %83, !llvm.loop !133

53:                                               ; preds = %49
  %54 = getelementptr i8, ptr %19, i32 3
  %55 = load i8, ptr %54, align 1, !tbaa !2
  %56 = icmp eq i8 %55, 115
  br i1 %56, label %57, label %83, !llvm.loop !133

57:                                               ; preds = %53
  %58 = getelementptr i8, ptr %19, i32 4
  %59 = load i8, ptr %58, align 1, !tbaa !2
  %60 = icmp eq i8 %59, 101
  br i1 %60, label %82, label %83

61:                                               ; preds = %18
  %62 = sub i32 %16, %2
  %63 = icmp eq i32 %62, 4
  br i1 %63, label %64, label %83

64:                                               ; preds = %61
  %65 = load i8, ptr %19, align 1, !tbaa !2
  %66 = icmp eq i8 %65, 110
  br i1 %66, label %67, label %83, !llvm.loop !133

67:                                               ; preds = %64
  %68 = getelementptr i8, ptr %19, i32 1
  %69 = load i8, ptr %68, align 1, !tbaa !2
  %70 = icmp eq i8 %69, 117
  br i1 %70, label %71, label %83, !llvm.loop !133

71:                                               ; preds = %67
  %72 = getelementptr i8, ptr %19, i32 2
  %73 = load i8, ptr %72, align 1, !tbaa !2
  %74 = icmp eq i8 %73, 108
  br i1 %74, label %75, label %83, !llvm.loop !133

75:                                               ; preds = %71
  %76 = getelementptr i8, ptr %19, i32 3
  %77 = load i8, ptr %76, align 1, !tbaa !2
  %78 = icmp eq i8 %77, 108
  br i1 %78, label %82, label %83

79:                                               ; preds = %18
  %80 = tail call fastcc i32 @is_valid_json_number(ptr noundef nonnull %0, i32 noundef %2, i32 noundef %16)
  %81 = icmp eq i32 %80, 0
  br i1 %81, label %83, label %82

82:                                               ; preds = %57, %35, %79, %75
  store i32 %16, ptr %3, align 4, !tbaa !5
  br label %83

83:                                               ; preds = %64, %67, %71, %42, %45, %49, %53, %24, %27, %31, %57, %35, %79, %61, %39, %21, %15, %4, %82, %75
  %84 = phi i32 [ 1, %82 ], [ 0, %75 ], [ 0, %4 ], [ 0, %15 ], [ 0, %21 ], [ 0, %39 ], [ 0, %61 ], [ 0, %79 ], [ 0, %35 ], [ 0, %57 ], [ 0, %31 ], [ 0, %27 ], [ 0, %24 ], [ 0, %53 ], [ 0, %49 ], [ 0, %45 ], [ 0, %42 ], [ 0, %71 ], [ 0, %67 ], [ 0, %64 ]
  ret i32 %84
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: read)
define internal fastcc range(i32 0, 2) i32 @is_valid_json_number(ptr noundef readonly captures(none) %0, i32 noundef %1, i32 noundef %2) unnamed_addr #18 {
  %4 = icmp ult i32 %1, %2
  br i1 %4, label %5, label %11

5:                                                ; preds = %3
  %6 = getelementptr inbounds nuw i8, ptr %0, i32 %1
  %7 = load i8, ptr %6, align 1, !tbaa !2
  %8 = icmp eq i8 %7, 45
  %9 = zext i1 %8 to i32
  %10 = add nuw i32 %1, %9
  br label %11

11:                                               ; preds = %5, %3
  %12 = phi i32 [ %1, %3 ], [ %10, %5 ]
  %13 = icmp ult i32 %12, %2
  br i1 %13, label %14, label %95

14:                                               ; preds = %11
  %15 = getelementptr inbounds nuw i8, ptr %0, i32 %12
  %16 = load i8, ptr %15, align 1, !tbaa !2
  %17 = icmp eq i8 %16, 48
  br i1 %17, label %18, label %26

18:                                               ; preds = %14
  %19 = add nuw i32 %12, 1
  %20 = icmp ult i32 %19, %2
  br i1 %20, label %21, label %40

21:                                               ; preds = %18
  %22 = getelementptr inbounds nuw i8, ptr %0, i32 %19
  %23 = load i8, ptr %22, align 1, !tbaa !2
  %24 = add i8 %23, -48
  %25 = icmp ult i8 %24, 10
  br i1 %25, label %95, label %40

26:                                               ; preds = %14
  %27 = add i8 %16, -58
  %28 = icmp ult i8 %27, -9
  br i1 %28, label %95, label %29

29:                                               ; preds = %26
  %30 = add i32 %2, -1
  br label %31

31:                                               ; preds = %29, %34
  %32 = phi i32 [ %35, %34 ], [ %12, %29 ]
  %33 = icmp eq i32 %32, %30
  br i1 %33, label %91, label %34

34:                                               ; preds = %31
  %35 = add nuw i32 %32, 1
  %36 = getelementptr inbounds nuw i8, ptr %0, i32 %35
  %37 = load i8, ptr %36, align 1, !tbaa !2
  %38 = add i8 %37, -48
  %39 = icmp ult i8 %38, 10
  br i1 %39, label %31, label %40, !llvm.loop !134

40:                                               ; preds = %34, %18, %21
  %41 = phi i32 [ %19, %21 ], [ %19, %18 ], [ %35, %34 ]
  %42 = icmp ult i32 %41, %2
  br i1 %42, label %43, label %62

43:                                               ; preds = %40
  %44 = getelementptr inbounds nuw i8, ptr %0, i32 %41
  %45 = load i8, ptr %44, align 1, !tbaa !2
  %46 = icmp eq i8 %45, 46
  br i1 %46, label %47, label %62

47:                                               ; preds = %43
  %48 = add nuw i32 %41, 1
  %49 = icmp ult i32 %48, %2
  br i1 %49, label %50, label %95

50:                                               ; preds = %47, %56
  %51 = phi i32 [ %57, %56 ], [ %48, %47 ]
  %52 = getelementptr inbounds nuw i8, ptr %0, i32 %51
  %53 = load i8, ptr %52, align 1, !tbaa !2
  %54 = add i8 %53, -48
  %55 = icmp ult i8 %54, 10
  br i1 %55, label %56, label %59

56:                                               ; preds = %50
  %57 = add i32 %51, 1
  %58 = icmp eq i32 %57, %2
  br i1 %58, label %59, label %50, !llvm.loop !135

59:                                               ; preds = %56, %50
  %60 = phi i32 [ %2, %56 ], [ %51, %50 ]
  %61 = icmp eq i32 %60, %48
  br i1 %61, label %95, label %62

62:                                               ; preds = %59, %43, %40
  %63 = phi i32 [ %60, %59 ], [ %41, %43 ], [ %41, %40 ]
  %64 = icmp ult i32 %63, %2
  br i1 %64, label %65, label %91

65:                                               ; preds = %62
  %66 = getelementptr inbounds nuw i8, ptr %0, i32 %63
  %67 = load i8, ptr %66, align 1, !tbaa !2
  switch i8 %67, label %91 [
    i8 101, label %68
    i8 69, label %68
  ]

68:                                               ; preds = %65, %65
  %69 = add nuw i32 %63, 1
  %70 = icmp ult i32 %69, %2
  br i1 %70, label %71, label %76

71:                                               ; preds = %68
  %72 = getelementptr inbounds nuw i8, ptr %0, i32 %69
  %73 = load i8, ptr %72, align 1, !tbaa !2
  switch i8 %73, label %76 [
    i8 43, label %74
    i8 45, label %74
  ]

74:                                               ; preds = %71, %71
  %75 = add nuw i32 %63, 2
  br label %76

76:                                               ; preds = %71, %74, %68
  %77 = phi i32 [ %75, %74 ], [ %69, %68 ], [ %69, %71 ]
  %78 = icmp ult i32 %77, %2
  br i1 %78, label %79, label %95

79:                                               ; preds = %76, %85
  %80 = phi i32 [ %86, %85 ], [ %77, %76 ]
  %81 = getelementptr inbounds nuw i8, ptr %0, i32 %80
  %82 = load i8, ptr %81, align 1, !tbaa !2
  %83 = add i8 %82, -48
  %84 = icmp ult i8 %83, 10
  br i1 %84, label %85, label %88

85:                                               ; preds = %79
  %86 = add nuw i32 %80, 1
  %87 = icmp eq i32 %86, %2
  br i1 %87, label %88, label %79, !llvm.loop !136

88:                                               ; preds = %85, %79
  %89 = phi i32 [ %2, %85 ], [ %80, %79 ]
  %90 = icmp eq i32 %89, %77
  br i1 %90, label %95, label %91

91:                                               ; preds = %31, %65, %88, %62
  %92 = phi i32 [ %89, %88 ], [ %63, %62 ], [ %63, %65 ], [ %2, %31 ]
  %93 = icmp eq i32 %92, %2
  %94 = zext i1 %93 to i32
  br label %95

95:                                               ; preds = %76, %47, %26, %21, %11, %59, %88, %91
  %96 = phi i32 [ %94, %91 ], [ 0, %88 ], [ 0, %59 ], [ 0, %11 ], [ 0, %21 ], [ 0, %26 ], [ 0, %47 ], [ 0, %76 ]
  ret i32 %96
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc range(i32 0, 2) i32 @parse_composite_span_impl(ptr noundef readonly %0, i32 noundef %1, i32 noundef %2, ptr noundef nonnull writeonly captures(none) %3, ptr noundef captures(address_is_null) %4, ptr noundef captures(address_is_null) %5, ptr noundef captures(address_is_null) %6, i32 noundef range(i32 0, 2) %7) unnamed_addr #19 {
  %9 = alloca [256 x i8], align 16
  %10 = alloca i32, align 4
  %11 = icmp ult i32 %2, %1
  br i1 %11, label %12, label %1011

12:                                               ; preds = %8
  %13 = getelementptr inbounds nuw i8, ptr %0, i32 %2
  %14 = load i8, ptr %13, align 1, !tbaa !2
  switch i8 %14, label %1011 [
    i8 91, label %15
    i8 123, label %15
  ]

15:                                               ; preds = %12, %12
  call void @llvm.lifetime.start.p0(i64 256, ptr nonnull %9) #28
  %16 = icmp eq i8 %14, 91
  %17 = icmp ne i32 %7, 0
  %18 = and i1 %17, %16
  %19 = add nuw i32 %2, 1
  %20 = getelementptr i8, ptr %0, i32 1
  %21 = icmp ult i32 %19, %1
  br i1 %21, label %22, label %1009

22:                                               ; preds = %15
  %23 = select i1 %16, i8 0, i8 3
  %24 = icmp eq ptr %5, null
  %25 = icmp ne ptr %4, null
  %26 = icmp eq ptr %6, null
  %27 = getelementptr i8, ptr %0, i32 3
  %28 = getelementptr i8, ptr %0, i32 4
  %29 = getelementptr i8, ptr %0, i32 5
  %30 = getelementptr i8, ptr %0, i32 1
  %31 = getelementptr i8, ptr %0, i32 2
  %32 = getelementptr i8, ptr %0, i32 3
  %33 = getelementptr i8, ptr %0, i32 4
  %34 = getelementptr i8, ptr %0, i32 1
  %35 = getelementptr i8, ptr %0, i32 2
  %36 = getelementptr i8, ptr %0, i32 3
  %37 = getelementptr i8, ptr %0, i32 4
  %38 = getelementptr i8, ptr %0, i32 2
  %39 = getelementptr i8, ptr %0, i32 3
  %40 = getelementptr i8, ptr %0, i32 2
  %41 = getelementptr i8, ptr %0, i32 3
  %42 = getelementptr i8, ptr %0, i32 2
  %43 = getelementptr i8, ptr %0, i32 3
  %44 = getelementptr i8, ptr %0, i32 7
  %45 = getelementptr i8, ptr %0, i32 8
  %46 = getelementptr i8, ptr %0, i32 9
  %47 = getelementptr i8, ptr %0, i32 10
  %48 = getelementptr i8, ptr %0, i32 11
  %49 = getelementptr i8, ptr %0, i32 12
  %50 = getelementptr i8, ptr %0, i32 13
  %51 = getelementptr i8, ptr %0, i32 14
  %52 = getelementptr i8, ptr %0, i32 15
  %53 = getelementptr i8, ptr %0, i32 16
  %54 = getelementptr i8, ptr %0, i32 17
  %55 = getelementptr i8, ptr %0, i32 19
  %56 = getelementptr i8, ptr %0, i32 1
  %57 = getelementptr i8, ptr %0, i32 1
  %58 = getelementptr i8, ptr %0, i32 1
  br label %59

59:                                               ; preds = %22, %1001
  %60 = phi i32 [ 1, %22 ], [ %1002, %1001 ]
  %61 = phi i8 [ %23, %22 ], [ %1003, %1001 ]
  %62 = phi i32 [ 0, %22 ], [ %1004, %1001 ]
  %63 = phi i32 [ 0, %22 ], [ %1005, %1001 ]
  %64 = phi i32 [ %19, %22 ], [ %1006, %1001 ]
  %65 = phi i32 [ 0, %22 ], [ %1007, %1001 ]
  %66 = getelementptr i8, ptr %0, i32 %64
  %67 = load i8, ptr %66, align 1, !tbaa !2
  switch i8 %67, label %958 [
    i8 32, label %68
    i8 13, label %68
    i8 10, label %68
    i8 9, label %68
    i8 34, label %75
    i8 93, label %913
    i8 125, label %915
    i8 44, label %931
    i8 58, label %945
  ]

68:                                               ; preds = %59, %59, %59, %59
  br i1 %24, label %73, label %69

69:                                               ; preds = %68
  %70 = load i32, ptr %5, align 4, !tbaa !5
  %71 = icmp eq i32 %70, 0
  br i1 %71, label %72, label %73

72:                                               ; preds = %69
  store i32 1, ptr %5, align 4, !tbaa !5
  br label %73

73:                                               ; preds = %72, %69, %68
  %74 = add nuw i32 %64, 1
  br label %1001, !llvm.loop !137

75:                                               ; preds = %59
  %76 = and i8 %61, -5
  %77 = icmp ne i8 %76, 3
  br i1 %77, label %100, label %78

78:                                               ; preds = %75
  %79 = sub nuw i32 %1, %64
  %80 = icmp ugt i32 %79, 8
  br i1 %80, label %81, label %89

81:                                               ; preds = %78
  %82 = load i64, ptr %66, align 1
  %83 = icmp eq i64 %82, 8389754706581218082
  %84 = trunc i64 %82 to i32
  br i1 %83, label %85, label %93

85:                                               ; preds = %81
  %86 = getelementptr i8, ptr %66, i32 8
  %87 = load i8, ptr %86, align 1, !tbaa !2
  %88 = icmp eq i8 %87, 34
  br i1 %88, label %269, label %100

89:                                               ; preds = %78
  %90 = icmp samesign ugt i32 %79, 4
  br i1 %90, label %91, label %100

91:                                               ; preds = %89
  %92 = load i32, ptr %66, align 1
  br label %93

93:                                               ; preds = %91, %81
  %94 = phi i32 [ %92, %91 ], [ %84, %81 ]
  %95 = icmp eq i32 %94, 1734439970
  br i1 %95, label %96, label %100

96:                                               ; preds = %93
  %97 = getelementptr i8, ptr %66, i32 4
  %98 = load i8, ptr %97, align 1, !tbaa !2
  %99 = icmp eq i8 %98, 34
  br i1 %99, label %271, label %100

100:                                              ; preds = %75, %89, %96, %93, %85
  %101 = add nuw i32 %64, 1
  %102 = icmp ult i32 %101, %1
  br i1 %102, label %103, label %1009

103:                                              ; preds = %100, %121
  %104 = phi i32 [ %122, %121 ], [ %101, %100 ]
  %105 = add i32 %104, 8
  %106 = icmp ugt i32 %105, %1
  br i1 %106, label %128, label %107

107:                                              ; preds = %103
  %108 = getelementptr inbounds nuw i8, ptr %0, i32 %104
  %109 = load i64, ptr %108, align 1
  %110 = xor i64 %109, 2459565876494606882
  %111 = add i64 %110, -72340172838076673
  %112 = and i64 %109, -9187201950435737472
  %113 = xor i64 %112, -9187201950435737472
  %114 = xor i64 %109, 6655295901103053916
  %115 = add i64 %114, -72340172838076673
  %116 = or i64 %111, %115
  %117 = add i64 %109, -2314885530818453536
  %118 = or i64 %116, %117
  %119 = and i64 %113, %118
  %120 = icmp eq i64 %119, 0
  br i1 %120, label %121, label %123

121:                                              ; preds = %107, %190
  %122 = phi i32 [ %105, %107 ], [ %191, %190 ]
  br label %103

123:                                              ; preds = %107
  %124 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %119, i1 true)
  %125 = trunc nuw nsw i64 %124 to i32
  %126 = lshr i32 %125, 3
  %127 = add i32 %126, %104
  br label %128

128:                                              ; preds = %103, %123
  %129 = phi i32 [ %127, %123 ], [ %104, %103 ]
  %130 = icmp ult i32 %129, %1
  br i1 %130, label %131, label %1009

131:                                              ; preds = %128
  %132 = getelementptr inbounds nuw i8, ptr %0, i32 %129
  %133 = load i8, ptr %132, align 1, !tbaa !2
  %134 = icmp eq i8 %133, 92
  br i1 %134, label %135, label %185

135:                                              ; preds = %131
  %136 = add nuw i32 %129, 1
  %137 = icmp ult i32 %136, %1
  br i1 %137, label %138, label %1009

138:                                              ; preds = %135
  %139 = getelementptr inbounds nuw i8, ptr %0, i32 %136
  %140 = load i8, ptr %139, align 1, !tbaa !2
  switch i8 %140, label %1009 [
    i8 117, label %141
    i8 116, label %183
    i8 114, label %183
    i8 110, label %183
    i8 102, label %183
    i8 98, label %183
    i8 92, label %183
    i8 47, label %183
    i8 34, label %183
  ]

141:                                              ; preds = %138
  %142 = add i32 %129, 6
  %143 = icmp ugt i32 %142, %1
  br i1 %143, label %1009, label %144

144:                                              ; preds = %141
  %145 = add nuw i32 %129, 2
  %146 = icmp ult i32 %145, %142
  br i1 %146, label %147, label %190

147:                                              ; preds = %144
  %148 = getelementptr inbounds nuw i8, ptr %0, i32 %145
  %149 = load i8, ptr %148, align 1, !tbaa !2
  %150 = add i8 %149, -58
  %151 = icmp ult i8 %150, -10
  %152 = and i8 %149, -33
  %153 = add i8 %152, -71
  %154 = icmp ult i8 %153, -6
  %155 = and i1 %151, %154
  br i1 %155, label %1009, label %156

156:                                              ; preds = %147
  %157 = getelementptr i8, ptr %27, i32 %129
  %158 = load i8, ptr %157, align 1, !tbaa !2
  %159 = add i8 %158, -58
  %160 = icmp ult i8 %159, -10
  %161 = and i8 %158, -33
  %162 = add i8 %161, -71
  %163 = icmp ult i8 %162, -6
  %164 = and i1 %160, %163
  br i1 %164, label %1009, label %165

165:                                              ; preds = %156
  %166 = getelementptr i8, ptr %28, i32 %129
  %167 = load i8, ptr %166, align 1, !tbaa !2
  %168 = add i8 %167, -58
  %169 = icmp ult i8 %168, -10
  %170 = and i8 %167, -33
  %171 = add i8 %170, -71
  %172 = icmp ult i8 %171, -6
  %173 = and i1 %169, %172
  br i1 %173, label %1009, label %174

174:                                              ; preds = %165
  %175 = getelementptr i8, ptr %29, i32 %129
  %176 = load i8, ptr %175, align 1, !tbaa !2
  %177 = add i8 %176, -58
  %178 = icmp ult i8 %177, -10
  %179 = and i8 %176, -33
  %180 = add i8 %179, -71
  %181 = icmp ult i8 %180, -6
  %182 = and i1 %178, %181
  br i1 %182, label %1009, label %190

183:                                              ; preds = %138, %138, %138, %138, %138, %138, %138, %138
  %184 = add nuw i32 %129, 2
  br label %190, !llvm.loop !42

185:                                              ; preds = %131
  %186 = icmp ult i8 %133, 32
  br i1 %186, label %1009, label %187

187:                                              ; preds = %185
  %188 = icmp eq i8 %133, 34
  %189 = add i32 %129, 1
  br i1 %188, label %193, label %190

190:                                              ; preds = %187, %174, %144, %183
  %191 = phi i32 [ %184, %183 ], [ %142, %144 ], [ %142, %174 ], [ %189, %187 ]
  %192 = icmp ult i32 %191, %1
  br i1 %192, label %121, label %1009

193:                                              ; preds = %187
  %194 = getelementptr i8, ptr %66, i32 1
  %195 = load i8, ptr %194, align 1, !tbaa !2
  %196 = icmp eq i8 %195, 105
  %197 = icmp eq i8 %195, 92
  %198 = or i1 %196, %197
  %199 = and i1 %25, %198
  br i1 %199, label %200, label %268

200:                                              ; preds = %193
  %201 = load i32, ptr %4, align 4, !tbaa !5
  %202 = icmp eq i32 %201, 0
  %203 = icmp ule i32 %64, %129
  %204 = and i1 %203, %202
  br i1 %204, label %205, label %268

205:                                              ; preds = %200
  %206 = add i32 %64, 4
  %207 = sub nuw i32 %129, %64
  %208 = icmp eq i32 %129, %64
  br i1 %208, label %231, label %219

209:                                              ; preds = %220
  %210 = getelementptr inbounds nuw i8, ptr %66, i32 2
  %211 = load i8, ptr %210, align 1, !tbaa !2
  switch i8 %211, label %231 [
    i8 92, label %228
    i8 109, label %212
  ]

212:                                              ; preds = %209
  %213 = icmp eq i32 %207, 2
  br i1 %213, label %231, label %214

214:                                              ; preds = %212
  %215 = getelementptr inbounds nuw i8, ptr %66, i32 3
  %216 = load i8, ptr %215, align 1, !tbaa !2
  switch i8 %216, label %231 [
    i8 92, label %228
    i8 103, label %217
  ]

217:                                              ; preds = %214
  %218 = icmp ugt i32 %206, %129
  br i1 %218, label %231, label %224

219:                                              ; preds = %205
  br i1 %197, label %228, label %220

220:                                              ; preds = %219
  %221 = icmp ne i8 %195, 105
  %222 = icmp eq i32 %207, 1
  %223 = or i1 %222, %221
  br i1 %223, label %231, label %209

224:                                              ; preds = %217
  %225 = getelementptr inbounds nuw i8, ptr %0, i32 %206
  %226 = load i8, ptr %225, align 1, !tbaa !2
  %227 = icmp eq i8 %226, 34
  br i1 %227, label %267, label %231

228:                                              ; preds = %219, %214, %209
  %229 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull readonly %0, i32 noundef %64, i32 noundef %189, ptr noundef nonnull @.str.6, i32 noundef 3)
  %230 = icmp eq i32 %229, 0
  br i1 %230, label %231, label %267

231:                                              ; preds = %228, %224, %220, %217, %214, %212, %209, %205
  %232 = add i32 %64, 6
  %233 = icmp ult i32 %64, %129
  br i1 %233, label %259, label %268

234:                                              ; preds = %259
  %235 = add nuw i32 %64, 2
  %236 = icmp ugt i32 %235, %129
  br i1 %236, label %268, label %237

237:                                              ; preds = %234
  %238 = getelementptr inbounds nuw i8, ptr %0, i32 %235
  %239 = load i8, ptr %238, align 1, !tbaa !2
  switch i8 %239, label %268 [
    i8 92, label %264
    i8 109, label %240
  ]

240:                                              ; preds = %237
  %241 = add nuw i32 %64, 3
  %242 = icmp ugt i32 %241, %129
  br i1 %242, label %268, label %243

243:                                              ; preds = %240
  %244 = getelementptr inbounds nuw i8, ptr %0, i32 %241
  %245 = load i8, ptr %244, align 1, !tbaa !2
  switch i8 %245, label %268 [
    i8 92, label %264
    i8 97, label %246
  ]

246:                                              ; preds = %243
  %247 = icmp ugt i32 %206, %129
  br i1 %247, label %268, label %248

248:                                              ; preds = %246
  %249 = getelementptr inbounds nuw i8, ptr %0, i32 %206
  %250 = load i8, ptr %249, align 1, !tbaa !2
  switch i8 %250, label %268 [
    i8 92, label %264
    i8 103, label %251
  ]

251:                                              ; preds = %248
  %252 = add nuw i32 %64, 5
  %253 = icmp ugt i32 %252, %129
  br i1 %253, label %268, label %254

254:                                              ; preds = %251
  %255 = getelementptr inbounds nuw i8, ptr %0, i32 %252
  %256 = load i8, ptr %255, align 1, !tbaa !2
  switch i8 %256, label %268 [
    i8 92, label %264
    i8 101, label %257
  ]

257:                                              ; preds = %254
  %258 = icmp ugt i32 %232, %129
  br i1 %258, label %268, label %260

259:                                              ; preds = %231
  switch i8 %195, label %268 [
    i8 92, label %264
    i8 105, label %234
  ]

260:                                              ; preds = %257
  %261 = getelementptr inbounds nuw i8, ptr %0, i32 %232
  %262 = load i8, ptr %261, align 1, !tbaa !2
  %263 = icmp eq i8 %262, 34
  br i1 %263, label %267, label %268

264:                                              ; preds = %237, %243, %248, %254, %259
  %265 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull readonly %0, i32 noundef %64, i32 noundef %189, ptr noundef nonnull @.str.4, i32 noundef 5)
  %266 = icmp eq i32 %265, 0
  br i1 %266, label %268, label %267

267:                                              ; preds = %260, %224, %228, %264
  store i32 1, ptr %4, align 4, !tbaa !5
  br label %268

268:                                              ; preds = %260, %259, %254, %248, %243, %237, %231, %234, %240, %246, %251, %257, %267, %264, %200, %193
  br i1 %77, label %696, label %373

269:                                              ; preds = %85
  %270 = add i32 %64, 9
  br label %366

271:                                              ; preds = %96
  %272 = add i32 %64, 5
  %273 = icmp ult i32 %272, %1
  br i1 %273, label %274, label %366

274:                                              ; preds = %271
  %275 = getelementptr inbounds nuw i8, ptr %0, i32 %272
  %276 = load i8, ptr %275, align 1, !tbaa !2
  %277 = icmp eq i8 %276, 58
  br i1 %277, label %278, label %366

278:                                              ; preds = %274
  %279 = add i32 %64, 6
  %280 = icmp ult i32 %279, %1
  br i1 %280, label %281, label %287

281:                                              ; preds = %278
  %282 = getelementptr inbounds nuw i8, ptr %0, i32 %279
  %283 = load i8, ptr %282, align 1, !tbaa !2
  %284 = icmp eq i8 %283, 32
  %285 = add i32 %64, 7
  %286 = select i1 %284, i32 %285, i32 %279
  br label %287

287:                                              ; preds = %281, %278
  %288 = phi i32 [ %279, %278 ], [ %286, %281 ]
  %289 = sub i32 %1, %288
  %290 = icmp ult i32 %289, 4
  br i1 %290, label %366, label %291

291:                                              ; preds = %287
  %292 = getelementptr inbounds nuw i8, ptr %0, i32 %288
  %293 = load i32, ptr %292, align 1
  switch i32 %293, label %366 [
    i32 1986618402, label %294
    i32 1634759458, label %305
    i32 1651864098, label %320
    i32 578056738, label %335
    i32 577533218, label %335
    i32 577334306, label %335
    i32 740450594, label %342
  ]

294:                                              ; preds = %291
  %295 = icmp ugt i32 %289, 5
  br i1 %295, label %296, label %366

296:                                              ; preds = %294
  %297 = getelementptr i8, ptr %292, i32 4
  %298 = load i8, ptr %297, align 1, !tbaa !2
  %299 = icmp eq i8 %298, 34
  br i1 %299, label %300, label %366

300:                                              ; preds = %296
  %301 = getelementptr i8, ptr %292, i32 5
  %302 = load i8, ptr %301, align 1, !tbaa !2
  %303 = icmp eq i8 %302, 44
  %304 = add i32 %288, 6
  br i1 %303, label %344, label %366

305:                                              ; preds = %291
  %306 = icmp ugt i32 %289, 6
  br i1 %306, label %307, label %366

307:                                              ; preds = %305
  %308 = getelementptr i8, ptr %292, i32 4
  %309 = load i8, ptr %308, align 1, !tbaa !2
  %310 = icmp eq i8 %309, 110
  br i1 %310, label %311, label %366

311:                                              ; preds = %307
  %312 = getelementptr i8, ptr %292, i32 5
  %313 = load i8, ptr %312, align 1, !tbaa !2
  %314 = icmp eq i8 %313, 34
  br i1 %314, label %315, label %366

315:                                              ; preds = %311
  %316 = getelementptr i8, ptr %292, i32 6
  %317 = load i8, ptr %316, align 1, !tbaa !2
  %318 = icmp eq i8 %317, 44
  %319 = add i32 %288, 7
  br i1 %318, label %344, label %366

320:                                              ; preds = %291
  %321 = icmp ugt i32 %289, 6
  br i1 %321, label %322, label %366

322:                                              ; preds = %320
  %323 = getelementptr i8, ptr %292, i32 4
  %324 = load i8, ptr %323, align 1, !tbaa !2
  %325 = icmp eq i8 %324, 121
  br i1 %325, label %326, label %366

326:                                              ; preds = %322
  %327 = getelementptr i8, ptr %292, i32 5
  %328 = load i8, ptr %327, align 1, !tbaa !2
  %329 = icmp eq i8 %328, 34
  br i1 %329, label %330, label %366

330:                                              ; preds = %326
  %331 = getelementptr i8, ptr %292, i32 6
  %332 = load i8, ptr %331, align 1, !tbaa !2
  %333 = icmp eq i8 %332, 44
  %334 = add i32 %288, 7
  br i1 %333, label %344, label %366

335:                                              ; preds = %291, %291, %291
  %336 = icmp eq i32 %289, 4
  br i1 %336, label %366, label %337

337:                                              ; preds = %335
  %338 = getelementptr i8, ptr %292, i32 4
  %339 = load i8, ptr %338, align 1, !tbaa !2
  %340 = icmp eq i8 %339, 44
  %341 = add i32 %288, 5
  br i1 %340, label %344, label %366

342:                                              ; preds = %291
  %343 = add i32 %288, 4
  br label %344

344:                                              ; preds = %337, %330, %315, %300, %342
  %345 = phi i32 [ %343, %342 ], [ %304, %300 ], [ %319, %315 ], [ %334, %330 ], [ %341, %337 ]
  %346 = icmp eq i32 %345, 0
  br i1 %346, label %366, label %347

347:                                              ; preds = %344
  br i1 %24, label %353, label %348

348:                                              ; preds = %347
  %349 = getelementptr i8, ptr %20, i32 %272
  %350 = load i8, ptr %349, align 1, !tbaa !2
  %351 = icmp eq i8 %350, 32
  br i1 %351, label %352, label %353

352:                                              ; preds = %348
  store i32 1, ptr %5, align 4, !tbaa !5
  br label %353

353:                                              ; preds = %352, %348, %347
  %354 = icmp eq i32 %60, 2
  %355 = select i1 %18, i1 %354, i1 false
  %356 = select i1 %355, i32 0, i32 %62
  %357 = icmp ult i32 %345, %1
  br i1 %357, label %358, label %1001, !llvm.loop !137

358:                                              ; preds = %353
  %359 = getelementptr inbounds nuw i8, ptr %0, i32 %345
  %360 = load i8, ptr %359, align 1, !tbaa !2
  %361 = icmp eq i8 %360, 32
  br i1 %361, label %362, label %1001, !llvm.loop !137

362:                                              ; preds = %358
  br i1 %24, label %364, label %363

363:                                              ; preds = %362
  store i32 1, ptr %5, align 4, !tbaa !5
  br label %364

364:                                              ; preds = %363, %362
  %365 = add nuw i32 %345, 1
  br label %1001, !llvm.loop !137

366:                                              ; preds = %291, %337, %335, %330, %320, %322, %326, %315, %305, %307, %311, %300, %294, %296, %287, %271, %274, %344, %269
  %367 = phi i32 [ 4, %269 ], [ 0, %344 ], [ 0, %274 ], [ 0, %271 ], [ 0, %287 ], [ 0, %296 ], [ 0, %294 ], [ 0, %300 ], [ 0, %311 ], [ 0, %307 ], [ 0, %305 ], [ 0, %315 ], [ 0, %326 ], [ 0, %322 ], [ 0, %320 ], [ 0, %330 ], [ 0, %335 ], [ 0, %337 ], [ 0, %291 ]
  %368 = phi i1 [ true, %269 ], [ false, %344 ], [ false, %274 ], [ false, %271 ], [ false, %287 ], [ false, %296 ], [ false, %294 ], [ false, %300 ], [ false, %311 ], [ false, %307 ], [ false, %305 ], [ false, %315 ], [ false, %326 ], [ false, %322 ], [ false, %320 ], [ false, %330 ], [ false, %335 ], [ false, %337 ], [ false, %291 ]
  %369 = phi i32 [ %270, %269 ], [ %272, %344 ], [ %272, %274 ], [ %272, %271 ], [ %272, %287 ], [ %272, %296 ], [ %272, %294 ], [ %272, %300 ], [ %272, %311 ], [ %272, %307 ], [ %272, %305 ], [ %272, %315 ], [ %272, %326 ], [ %272, %322 ], [ %272, %320 ], [ %272, %330 ], [ %272, %335 ], [ %272, %337 ], [ %272, %291 ]
  %370 = icmp eq i32 %60, 2
  %371 = select i1 %18, i1 %370, i1 false
  %372 = select i1 %371, i32 %367, i32 %62
  br label %657

373:                                              ; preds = %268
  %374 = icmp eq i32 %60, 2
  %375 = select i1 %18, i1 %374, i1 false
  br i1 %375, label %376, label %535

376:                                              ; preds = %373
  %377 = icmp ugt i32 %64, %129
  br i1 %377, label %534, label %378

378:                                              ; preds = %376
  %379 = load i8, ptr %66, align 1, !tbaa !2
  %380 = icmp eq i8 %379, 34
  br i1 %380, label %381, label %534

381:                                              ; preds = %378
  %382 = add i32 %64, 5
  %383 = sub i32 %129, %64
  %384 = icmp eq i32 %129, %64
  br i1 %384, label %415, label %400

385:                                              ; preds = %404
  %386 = getelementptr i8, ptr %31, i32 %64
  %387 = load i8, ptr %386, align 1, !tbaa !2
  switch i8 %387, label %415 [
    i8 92, label %412
    i8 121, label %388
  ]

388:                                              ; preds = %385
  %389 = icmp eq i32 %383, 2
  br i1 %389, label %415, label %390

390:                                              ; preds = %388
  %391 = getelementptr i8, ptr %32, i32 %64
  %392 = load i8, ptr %391, align 1, !tbaa !2
  switch i8 %392, label %415 [
    i8 92, label %412
    i8 112, label %393
  ]

393:                                              ; preds = %390
  %394 = icmp eq i32 %383, 3
  br i1 %394, label %415, label %395

395:                                              ; preds = %393
  %396 = getelementptr i8, ptr %33, i32 %64
  %397 = load i8, ptr %396, align 1, !tbaa !2
  switch i8 %397, label %415 [
    i8 92, label %412
    i8 101, label %398
  ]

398:                                              ; preds = %395
  %399 = icmp ugt i32 %382, %129
  br i1 %399, label %415, label %408

400:                                              ; preds = %381
  %401 = getelementptr i8, ptr %30, i32 %64
  %402 = load i8, ptr %401, align 1, !tbaa !2
  %403 = icmp eq i8 %402, 92
  br i1 %403, label %412, label %404

404:                                              ; preds = %400
  %405 = icmp ne i8 %402, 116
  %406 = icmp eq i32 %383, 1
  %407 = or i1 %405, %406
  br i1 %407, label %415, label %385

408:                                              ; preds = %398
  %409 = getelementptr inbounds nuw i8, ptr %0, i32 %382
  %410 = load i8, ptr %409, align 1, !tbaa !2
  %411 = icmp eq i8 %410, 34
  br i1 %411, label %535, label %415

412:                                              ; preds = %395, %390, %385, %400
  %413 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %64, i32 noundef %189, ptr noundef nonnull @.str.2, i32 noundef 4)
  %414 = icmp eq i32 %413, 0
  br i1 %414, label %415, label %535

415:                                              ; preds = %395, %390, %385, %404, %381, %388, %393, %408, %412, %398
  %416 = add i32 %64, 5
  %417 = icmp ult i32 %64, %129
  br i1 %417, label %438, label %448

418:                                              ; preds = %438
  %419 = add nuw i32 %64, 2
  %420 = icmp ugt i32 %419, %129
  br i1 %420, label %448, label %421

421:                                              ; preds = %418
  %422 = getelementptr inbounds nuw i8, ptr %0, i32 %419
  %423 = load i8, ptr %422, align 1, !tbaa !2
  switch i8 %423, label %448 [
    i8 92, label %445
    i8 101, label %424
  ]

424:                                              ; preds = %421
  %425 = add nuw i32 %64, 3
  %426 = icmp ugt i32 %425, %129
  br i1 %426, label %448, label %427

427:                                              ; preds = %424
  %428 = getelementptr inbounds nuw i8, ptr %0, i32 %425
  %429 = load i8, ptr %428, align 1, !tbaa !2
  switch i8 %429, label %448 [
    i8 92, label %445
    i8 120, label %430
  ]

430:                                              ; preds = %427
  %431 = add nuw i32 %64, 4
  %432 = icmp ugt i32 %431, %129
  br i1 %432, label %448, label %433

433:                                              ; preds = %430
  %434 = getelementptr inbounds nuw i8, ptr %0, i32 %431
  %435 = load i8, ptr %434, align 1, !tbaa !2
  switch i8 %435, label %448 [
    i8 92, label %445
    i8 116, label %436
  ]

436:                                              ; preds = %433
  %437 = icmp ugt i32 %416, %129
  br i1 %437, label %448, label %441

438:                                              ; preds = %415
  %439 = getelementptr i8, ptr %56, i32 %64
  %440 = load i8, ptr %439, align 1, !tbaa !2
  switch i8 %440, label %448 [
    i8 92, label %445
    i8 116, label %418
  ]

441:                                              ; preds = %436
  %442 = getelementptr inbounds nuw i8, ptr %0, i32 %416
  %443 = load i8, ptr %442, align 1, !tbaa !2
  %444 = icmp eq i8 %443, 34
  br i1 %444, label %535, label %448

445:                                              ; preds = %438, %433, %427, %421
  %446 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %64, i32 noundef %189, ptr noundef nonnull @.str.10, i32 noundef 4)
  %447 = icmp eq i32 %446, 0
  br i1 %447, label %448, label %535

448:                                              ; preds = %438, %433, %427, %421, %415, %418, %424, %430, %441, %445, %436
  %449 = add i32 %64, 5
  %450 = icmp ult i32 %64, %129
  br i1 %450, label %471, label %481

451:                                              ; preds = %471
  %452 = add nuw i32 %64, 2
  %453 = icmp ugt i32 %452, %129
  br i1 %453, label %481, label %454

454:                                              ; preds = %451
  %455 = getelementptr inbounds nuw i8, ptr %0, i32 %452
  %456 = load i8, ptr %455, align 1, !tbaa !2
  switch i8 %456, label %481 [
    i8 92, label %478
    i8 97, label %457
  ]

457:                                              ; preds = %454
  %458 = add nuw i32 %64, 3
  %459 = icmp ugt i32 %458, %129
  br i1 %459, label %481, label %460

460:                                              ; preds = %457
  %461 = getelementptr inbounds nuw i8, ptr %0, i32 %458
  %462 = load i8, ptr %461, align 1, !tbaa !2
  switch i8 %462, label %481 [
    i8 92, label %478
    i8 116, label %463
  ]

463:                                              ; preds = %460
  %464 = add nuw i32 %64, 4
  %465 = icmp ugt i32 %464, %129
  br i1 %465, label %481, label %466

466:                                              ; preds = %463
  %467 = getelementptr inbounds nuw i8, ptr %0, i32 %464
  %468 = load i8, ptr %467, align 1, !tbaa !2
  switch i8 %468, label %481 [
    i8 92, label %478
    i8 104, label %469
  ]

469:                                              ; preds = %466
  %470 = icmp ugt i32 %449, %129
  br i1 %470, label %481, label %474

471:                                              ; preds = %448
  %472 = getelementptr i8, ptr %57, i32 %64
  %473 = load i8, ptr %472, align 1, !tbaa !2
  switch i8 %473, label %481 [
    i8 92, label %478
    i8 112, label %451
  ]

474:                                              ; preds = %469
  %475 = getelementptr inbounds nuw i8, ptr %0, i32 %449
  %476 = load i8, ptr %475, align 1, !tbaa !2
  %477 = icmp eq i8 %476, 34
  br i1 %477, label %535, label %481

478:                                              ; preds = %471, %466, %460, %454
  %479 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %64, i32 noundef %189, ptr noundef nonnull @.str.1, i32 noundef 4)
  %480 = icmp eq i32 %479, 0
  br i1 %480, label %481, label %535

481:                                              ; preds = %471, %466, %460, %454, %448, %451, %457, %463, %474, %478, %469
  %482 = add i32 %64, 8
  %483 = icmp ult i32 %64, %129
  br i1 %483, label %522, label %534

484:                                              ; preds = %522
  %485 = add nuw i32 %64, 2
  %486 = icmp ugt i32 %485, %129
  br i1 %486, label %534, label %487

487:                                              ; preds = %484
  %488 = getelementptr inbounds nuw i8, ptr %0, i32 %485
  %489 = load i8, ptr %488, align 1, !tbaa !2
  switch i8 %489, label %534 [
    i8 92, label %530
    i8 111, label %490
  ]

490:                                              ; preds = %487
  %491 = add nuw i32 %64, 3
  %492 = icmp ugt i32 %491, %129
  br i1 %492, label %534, label %493

493:                                              ; preds = %490
  %494 = getelementptr inbounds nuw i8, ptr %0, i32 %491
  %495 = load i8, ptr %494, align 1, !tbaa !2
  switch i8 %495, label %534 [
    i8 92, label %530
    i8 110, label %496
  ]

496:                                              ; preds = %493
  %497 = add nuw i32 %64, 4
  %498 = icmp ugt i32 %497, %129
  br i1 %498, label %534, label %499

499:                                              ; preds = %496
  %500 = getelementptr inbounds nuw i8, ptr %0, i32 %497
  %501 = load i8, ptr %500, align 1, !tbaa !2
  switch i8 %501, label %534 [
    i8 92, label %530
    i8 116, label %502
  ]

502:                                              ; preds = %499
  %503 = add nuw i32 %64, 5
  %504 = icmp ugt i32 %503, %129
  br i1 %504, label %534, label %505

505:                                              ; preds = %502
  %506 = getelementptr inbounds nuw i8, ptr %0, i32 %503
  %507 = load i8, ptr %506, align 1, !tbaa !2
  switch i8 %507, label %534 [
    i8 92, label %530
    i8 101, label %508
  ]

508:                                              ; preds = %505
  %509 = add nuw i32 %64, 6
  %510 = icmp ugt i32 %509, %129
  br i1 %510, label %534, label %511

511:                                              ; preds = %508
  %512 = getelementptr inbounds nuw i8, ptr %0, i32 %509
  %513 = load i8, ptr %512, align 1, !tbaa !2
  switch i8 %513, label %534 [
    i8 92, label %530
    i8 110, label %514
  ]

514:                                              ; preds = %511
  %515 = add nuw i32 %64, 7
  %516 = icmp ugt i32 %515, %129
  br i1 %516, label %534, label %517

517:                                              ; preds = %514
  %518 = getelementptr inbounds nuw i8, ptr %0, i32 %515
  %519 = load i8, ptr %518, align 1, !tbaa !2
  switch i8 %519, label %534 [
    i8 92, label %530
    i8 116, label %520
  ]

520:                                              ; preds = %517
  %521 = icmp ugt i32 %482, %129
  br i1 %521, label %534, label %525

522:                                              ; preds = %481
  %523 = getelementptr i8, ptr %58, i32 %64
  %524 = load i8, ptr %523, align 1, !tbaa !2
  switch i8 %524, label %534 [
    i8 92, label %530
    i8 99, label %484
  ]

525:                                              ; preds = %520
  %526 = getelementptr inbounds nuw i8, ptr %0, i32 %482
  %527 = load i8, ptr %526, align 1, !tbaa !2
  %528 = freeze i8 %527
  %529 = icmp eq i8 %528, 34
  br i1 %529, label %535, label %534

530:                                              ; preds = %522, %517, %511, %505, %499, %493, %487
  %531 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %64, i32 noundef %189, ptr noundef nonnull @.str, i32 noundef 7)
  %532 = freeze i32 %531
  %533 = icmp eq i32 %532, 0
  br i1 %533, label %534, label %535

534:                                              ; preds = %522, %517, %511, %505, %499, %493, %487, %481, %484, %490, %496, %502, %508, %514, %525, %378, %376, %520, %530
  br label %535

535:                                              ; preds = %412, %445, %478, %534, %530, %373, %408, %441, %474, %525
  %536 = phi i32 [ 4, %525 ], [ 2, %474 ], [ 1, %441 ], [ 8, %408 ], [ %62, %373 ], [ 4, %530 ], [ 0, %534 ], [ 2, %478 ], [ 1, %445 ], [ 8, %412 ]
  %537 = getelementptr i8, ptr %66, i32 1
  %538 = load i8, ptr %537, align 1, !tbaa !2
  switch i8 %538, label %657 [
    i8 116, label %539
    i8 92, label %539
  ]

539:                                              ; preds = %535, %535
  br i1 %24, label %543, label %540

540:                                              ; preds = %539
  %541 = load i32, ptr %5, align 4, !tbaa !5
  %542 = icmp eq i32 %541, 0
  br i1 %542, label %549, label %543

543:                                              ; preds = %540, %539
  br i1 %26, label %657, label %544

544:                                              ; preds = %543
  %545 = load i32, ptr %6, align 4, !tbaa !5
  %546 = icmp eq i32 %545, 0
  %547 = icmp ule i32 %64, %129
  %548 = and i1 %546, %547
  br i1 %548, label %551, label %657

549:                                              ; preds = %540
  %550 = icmp ugt i32 %64, %129
  br i1 %550, label %657, label %551

551:                                              ; preds = %544, %549
  %552 = load i8, ptr %66, align 1, !tbaa !2
  %553 = icmp eq i8 %552, 34
  br i1 %553, label %554, label %657

554:                                              ; preds = %551
  %555 = add i32 %64, 5
  %556 = icmp ult i32 %64, %129
  br i1 %556, label %577, label %657

557:                                              ; preds = %577
  %558 = add nuw i32 %64, 2
  %559 = icmp ugt i32 %558, %129
  br i1 %559, label %657, label %560

560:                                              ; preds = %557
  %561 = getelementptr inbounds nuw i8, ptr %0, i32 %558
  %562 = load i8, ptr %561, align 1, !tbaa !2
  switch i8 %562, label %657 [
    i8 92, label %582
    i8 121, label %563
  ]

563:                                              ; preds = %560
  %564 = add nuw i32 %64, 3
  %565 = icmp ugt i32 %564, %129
  br i1 %565, label %657, label %566

566:                                              ; preds = %563
  %567 = getelementptr inbounds nuw i8, ptr %0, i32 %564
  %568 = load i8, ptr %567, align 1, !tbaa !2
  switch i8 %568, label %657 [
    i8 92, label %582
    i8 112, label %569
  ]

569:                                              ; preds = %566
  %570 = add nuw i32 %64, 4
  %571 = icmp ugt i32 %570, %129
  br i1 %571, label %657, label %572

572:                                              ; preds = %569
  %573 = getelementptr inbounds nuw i8, ptr %0, i32 %570
  %574 = load i8, ptr %573, align 1, !tbaa !2
  switch i8 %574, label %657 [
    i8 92, label %582
    i8 101, label %575
  ]

575:                                              ; preds = %572
  %576 = icmp ugt i32 %555, %129
  br i1 %576, label %657, label %578

577:                                              ; preds = %554
  switch i8 %538, label %657 [
    i8 92, label %582
    i8 116, label %557
  ]

578:                                              ; preds = %575
  %579 = getelementptr inbounds nuw i8, ptr %0, i32 %555
  %580 = load i8, ptr %579, align 1, !tbaa !2
  %581 = icmp eq i8 %580, 34
  br i1 %581, label %585, label %657

582:                                              ; preds = %577, %572, %566, %560
  %583 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %64, i32 noundef %189, ptr noundef nonnull @.str.2, i32 noundef 4)
  %584 = icmp eq i32 %583, 0
  br i1 %584, label %657, label %585

585:                                              ; preds = %578, %582
  %586 = icmp ult i32 %189, %1
  br i1 %586, label %587, label %594

587:                                              ; preds = %585, %591
  %588 = phi i32 [ %592, %591 ], [ %189, %585 ]
  %589 = getelementptr inbounds nuw i8, ptr %0, i32 %588
  %590 = load i8, ptr %589, align 1, !tbaa !2
  switch i8 %590, label %594 [
    i8 32, label %591
    i8 13, label %591
    i8 10, label %591
    i8 9, label %591
  ]

591:                                              ; preds = %587, %587, %587, %587
  %592 = add i32 %588, 1
  %593 = icmp eq i32 %592, %1
  br i1 %593, label %657, label %587, !llvm.loop !35

594:                                              ; preds = %587, %585
  %595 = phi i32 [ %189, %585 ], [ %588, %587 ]
  %596 = icmp ult i32 %595, %1
  br i1 %596, label %597, label %657

597:                                              ; preds = %594
  %598 = getelementptr inbounds nuw i8, ptr %0, i32 %595
  %599 = load i8, ptr %598, align 1, !tbaa !2
  %600 = icmp eq i8 %599, 58
  br i1 %600, label %601, label %657

601:                                              ; preds = %597
  %602 = add nuw i32 %595, 1
  %603 = icmp ult i32 %602, %1
  br i1 %603, label %604, label %611

604:                                              ; preds = %601, %608
  %605 = phi i32 [ %609, %608 ], [ %602, %601 ]
  %606 = getelementptr inbounds nuw i8, ptr %0, i32 %605
  %607 = load i8, ptr %606, align 1, !tbaa !2
  switch i8 %607, label %611 [
    i8 32, label %608
    i8 13, label %608
    i8 10, label %608
    i8 9, label %608
  ]

608:                                              ; preds = %604, %604, %604, %604
  %609 = add i32 %605, 1
  %610 = icmp eq i32 %609, %1
  br i1 %610, label %657, label %604, !llvm.loop !35

611:                                              ; preds = %604, %601
  %612 = phi i32 [ %602, %601 ], [ %605, %604 ]
  %613 = icmp ult i32 %612, %1
  br i1 %613, label %614, label %657

614:                                              ; preds = %611
  %615 = getelementptr inbounds nuw i8, ptr %0, i32 %612
  %616 = load i8, ptr %615, align 1, !tbaa !2
  %617 = icmp eq i8 %616, 34
  br i1 %617, label %618, label %657

618:                                              ; preds = %614
  %619 = add i32 %612, 5
  %620 = xor i32 %612, -1
  %621 = add i32 %1, %620
  %622 = icmp eq i32 %621, 0
  br i1 %622, label %657, label %638

623:                                              ; preds = %642
  %624 = getelementptr i8, ptr %35, i32 %612
  %625 = load i8, ptr %624, align 1, !tbaa !2
  switch i8 %625, label %657 [
    i8 92, label %650
    i8 101, label %626
  ]

626:                                              ; preds = %623
  %627 = icmp eq i32 %621, 2
  br i1 %627, label %657, label %628

628:                                              ; preds = %626
  %629 = getelementptr i8, ptr %36, i32 %612
  %630 = load i8, ptr %629, align 1, !tbaa !2
  switch i8 %630, label %657 [
    i8 92, label %650
    i8 120, label %631
  ]

631:                                              ; preds = %628
  %632 = icmp eq i32 %621, 3
  br i1 %632, label %657, label %633

633:                                              ; preds = %631
  %634 = getelementptr i8, ptr %37, i32 %612
  %635 = load i8, ptr %634, align 1, !tbaa !2
  switch i8 %635, label %657 [
    i8 92, label %650
    i8 116, label %636
  ]

636:                                              ; preds = %633
  %637 = icmp ult i32 %619, %1
  br i1 %637, label %646, label %657

638:                                              ; preds = %618
  %639 = getelementptr i8, ptr %34, i32 %612
  %640 = load i8, ptr %639, align 1, !tbaa !2
  %641 = icmp eq i8 %640, 92
  br i1 %641, label %650, label %642

642:                                              ; preds = %638
  %643 = icmp ne i8 %640, 116
  %644 = icmp eq i32 %621, 1
  %645 = or i1 %643, %644
  br i1 %645, label %657, label %623

646:                                              ; preds = %636
  %647 = getelementptr inbounds nuw i8, ptr %0, i32 %619
  %648 = load i8, ptr %647, align 1, !tbaa !2
  %649 = icmp eq i8 %648, 34
  br i1 %649, label %653, label %657

650:                                              ; preds = %633, %628, %623, %638
  %651 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %612, i32 noundef %1, ptr noundef nonnull @.str.10, i32 noundef 4)
  %652 = icmp eq i32 %651, 0
  br i1 %652, label %657, label %653

653:                                              ; preds = %646, %650
  br i1 %24, label %655, label %654

654:                                              ; preds = %653
  store i32 1, ptr %5, align 4, !tbaa !5
  br label %655

655:                                              ; preds = %654, %653
  br i1 %26, label %657, label %656

656:                                              ; preds = %655
  store i32 1, ptr %6, align 4, !tbaa !5
  br label %657

657:                                              ; preds = %591, %608, %366, %633, %628, %623, %577, %572, %566, %560, %554, %557, %563, %569, %642, %618, %626, %631, %646, %578, %575, %549, %551, %636, %611, %614, %594, %597, %582, %656, %655, %650, %544, %543, %535
  %658 = phi i1 [ %375, %656 ], [ %375, %655 ], [ %375, %650 ], [ %375, %544 ], [ %375, %543 ], [ %375, %535 ], [ %375, %582 ], [ %375, %597 ], [ %375, %594 ], [ %375, %614 ], [ %375, %611 ], [ %375, %636 ], [ %375, %551 ], [ %375, %549 ], [ %375, %575 ], [ %375, %578 ], [ %375, %646 ], [ %375, %631 ], [ %375, %626 ], [ %375, %618 ], [ %375, %642 ], [ %375, %569 ], [ %375, %563 ], [ %375, %557 ], [ %375, %554 ], [ %371, %366 ], [ %375, %560 ], [ %375, %566 ], [ %375, %572 ], [ %375, %577 ], [ %375, %623 ], [ %375, %628 ], [ %375, %633 ], [ %375, %608 ], [ %375, %591 ]
  %659 = phi i32 [ %189, %656 ], [ %189, %655 ], [ %189, %650 ], [ %189, %544 ], [ %189, %543 ], [ %189, %535 ], [ %189, %582 ], [ %189, %597 ], [ %189, %594 ], [ %189, %614 ], [ %189, %611 ], [ %189, %636 ], [ %189, %551 ], [ %189, %549 ], [ %189, %575 ], [ %189, %578 ], [ %189, %646 ], [ %189, %631 ], [ %189, %626 ], [ %189, %618 ], [ %189, %642 ], [ %189, %569 ], [ %189, %563 ], [ %189, %557 ], [ %189, %554 ], [ %369, %366 ], [ %189, %560 ], [ %189, %566 ], [ %189, %572 ], [ %189, %577 ], [ %189, %623 ], [ %189, %628 ], [ %189, %633 ], [ %189, %608 ], [ %189, %591 ]
  %660 = phi i1 [ false, %656 ], [ false, %655 ], [ false, %650 ], [ false, %544 ], [ false, %543 ], [ false, %535 ], [ false, %582 ], [ false, %597 ], [ false, %594 ], [ false, %614 ], [ false, %611 ], [ false, %636 ], [ false, %551 ], [ false, %549 ], [ false, %575 ], [ false, %578 ], [ false, %646 ], [ false, %631 ], [ false, %626 ], [ false, %618 ], [ false, %642 ], [ false, %569 ], [ false, %563 ], [ false, %557 ], [ false, %554 ], [ %368, %366 ], [ false, %560 ], [ false, %566 ], [ false, %572 ], [ false, %577 ], [ false, %623 ], [ false, %628 ], [ false, %633 ], [ false, %608 ], [ false, %591 ]
  %661 = phi i32 [ %536, %656 ], [ %536, %655 ], [ %536, %650 ], [ %536, %544 ], [ %536, %543 ], [ %536, %535 ], [ %536, %582 ], [ %536, %597 ], [ %536, %594 ], [ %536, %614 ], [ %536, %611 ], [ %536, %636 ], [ %536, %551 ], [ %536, %549 ], [ %536, %575 ], [ %536, %578 ], [ %536, %646 ], [ %536, %631 ], [ %536, %626 ], [ %536, %618 ], [ %536, %642 ], [ %536, %569 ], [ %536, %563 ], [ %536, %557 ], [ %536, %554 ], [ %372, %366 ], [ %536, %560 ], [ %536, %566 ], [ %536, %572 ], [ %536, %577 ], [ %536, %623 ], [ %536, %628 ], [ %536, %633 ], [ %536, %608 ], [ %536, %591 ]
  %662 = icmp ult i32 %659, %1
  br i1 %662, label %663, label %889

663:                                              ; preds = %657
  %664 = getelementptr inbounds nuw i8, ptr %0, i32 %659
  %665 = load i8, ptr %664, align 1, !tbaa !2
  %666 = icmp eq i8 %665, 58
  br i1 %666, label %667, label %889

667:                                              ; preds = %663
  %668 = add nuw i32 %659, 1
  %669 = icmp ult i32 %668, %1
  br i1 %669, label %670, label %678

670:                                              ; preds = %667
  %671 = getelementptr inbounds nuw i8, ptr %0, i32 %668
  %672 = load i8, ptr %671, align 1, !tbaa !2
  %673 = icmp eq i8 %672, 32
  br i1 %673, label %674, label %678

674:                                              ; preds = %670
  br i1 %24, label %676, label %675

675:                                              ; preds = %674
  store i32 1, ptr %5, align 4, !tbaa !5
  br label %676

676:                                              ; preds = %675, %674
  %677 = add nuw i32 %659, 2
  br label %678

678:                                              ; preds = %667, %670, %676
  %679 = phi i32 [ %677, %676 ], [ %668, %670 ], [ %668, %667 ]
  %680 = icmp ult i32 %679, %1
  %681 = select i1 %660, i1 %680, i1 false
  br i1 %681, label %682, label %1001, !llvm.loop !137

682:                                              ; preds = %678
  %683 = getelementptr inbounds nuw i8, ptr %0, i32 %679
  %684 = load i8, ptr %683, align 1, !tbaa !2
  switch i8 %684, label %1001 [
    i8 91, label %685
    i8 123, label %685
  ], !llvm.loop !137

685:                                              ; preds = %682, %682
  %686 = icmp ugt i32 %60, 255
  br i1 %686, label %1009, label %687

687:                                              ; preds = %685
  %688 = or i32 %65, 4
  %689 = select i1 %658, i32 %688, i32 %65
  %690 = add nsw i32 %60, -1
  %691 = getelementptr inbounds nuw [256 x i8], ptr %9, i32 0, i32 %690
  store i8 6, ptr %691, align 1, !tbaa !2
  %692 = add nuw nsw i32 %60, 1
  %693 = icmp eq i8 %684, 91
  %694 = select i1 %693, i8 0, i8 3
  %695 = add nuw i32 %679, 1
  br label %1001, !llvm.loop !137

696:                                              ; preds = %268
  %697 = icmp eq i8 %61, 5
  br i1 %697, label %698, label %886

698:                                              ; preds = %696
  %699 = icmp eq i32 %60, 2
  %700 = select i1 %18, i1 %699, i1 false
  br i1 %700, label %701, label %889

701:                                              ; preds = %698
  %702 = icmp eq i32 %62, 8
  br i1 %702, label %703, label %884

703:                                              ; preds = %701
  %704 = icmp ugt i32 %64, %129
  br i1 %704, label %889, label %705

705:                                              ; preds = %703
  %706 = load i8, ptr %66, align 1, !tbaa !2
  %707 = icmp eq i8 %706, 34
  br i1 %707, label %708, label %889

708:                                              ; preds = %705
  %709 = add i32 %64, 5
  %710 = add i32 %64, 4
  %711 = sub i32 %129, %64
  %712 = icmp eq i32 %129, %64
  br i1 %712, label %743, label %728

713:                                              ; preds = %732
  %714 = getelementptr i8, ptr %38, i32 %64
  %715 = load i8, ptr %714, align 1, !tbaa !2
  switch i8 %715, label %743 [
    i8 92, label %740
    i8 101, label %716
  ]

716:                                              ; preds = %713
  %717 = icmp eq i32 %711, 2
  br i1 %717, label %743, label %718

718:                                              ; preds = %716
  %719 = getelementptr i8, ptr %39, i32 %64
  %720 = load i8, ptr %719, align 1, !tbaa !2
  switch i8 %720, label %743 [
    i8 92, label %740
    i8 120, label %721
  ]

721:                                              ; preds = %718
  %722 = icmp eq i32 %711, 3
  br i1 %722, label %743, label %723

723:                                              ; preds = %721
  %724 = getelementptr inbounds nuw i8, ptr %0, i32 %710
  %725 = load i8, ptr %724, align 1, !tbaa !2
  switch i8 %725, label %743 [
    i8 92, label %740
    i8 116, label %726
  ]

726:                                              ; preds = %723
  %727 = icmp ult i32 %710, %129
  br i1 %727, label %736, label %743

728:                                              ; preds = %708
  %729 = getelementptr inbounds nuw i8, ptr %0, i32 %101
  %730 = load i8, ptr %729, align 1, !tbaa !2
  %731 = icmp eq i8 %730, 92
  br i1 %731, label %740, label %732

732:                                              ; preds = %728
  %733 = icmp ne i8 %730, 116
  %734 = icmp eq i32 %711, 1
  %735 = or i1 %733, %734
  br i1 %735, label %743, label %713

736:                                              ; preds = %726
  %737 = getelementptr inbounds nuw i8, ptr %0, i32 %709
  %738 = load i8, ptr %737, align 1, !tbaa !2
  %739 = icmp eq i8 %738, 34
  br i1 %739, label %889, label %743

740:                                              ; preds = %723, %718, %713, %728
  %741 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %64, i32 noundef %189, ptr noundef nonnull @.str.10, i32 noundef 4)
  %742 = icmp eq i32 %741, 0
  br i1 %742, label %743, label %889

743:                                              ; preds = %723, %718, %713, %726, %740, %736, %721, %716, %708, %732
  %744 = add i32 %64, 6
  %745 = tail call i32 @llvm.usub.sat.i32(i32 %129, i32 %64)
  %746 = icmp ugt i32 %129, %64
  br i1 %746, label %767, label %889

747:                                              ; preds = %771
  %748 = getelementptr i8, ptr %40, i32 %64
  %749 = load i8, ptr %748, align 1, !tbaa !2
  switch i8 %749, label %869 [
    i8 92, label %779
    i8 109, label %750
  ]

750:                                              ; preds = %747
  %751 = icmp eq i32 %745, 2
  br i1 %751, label %869, label %752

752:                                              ; preds = %750
  %753 = getelementptr i8, ptr %41, i32 %64
  %754 = load i8, ptr %753, align 1, !tbaa !2
  switch i8 %754, label %869 [
    i8 92, label %779
    i8 97, label %755
  ]

755:                                              ; preds = %752
  %756 = icmp eq i32 %745, 3
  br i1 %756, label %869, label %757

757:                                              ; preds = %755
  %758 = getelementptr inbounds nuw i8, ptr %0, i32 %710
  %759 = load i8, ptr %758, align 1, !tbaa !2
  switch i8 %759, label %869 [
    i8 92, label %779
    i8 103, label %760
  ]

760:                                              ; preds = %757
  %761 = icmp eq i32 %745, 4
  br i1 %761, label %869, label %762

762:                                              ; preds = %760
  %763 = getelementptr inbounds nuw i8, ptr %0, i32 %709
  %764 = load i8, ptr %763, align 1, !tbaa !2
  switch i8 %764, label %869 [
    i8 92, label %779
    i8 101, label %765
  ]

765:                                              ; preds = %762
  %766 = icmp ult i32 %709, %129
  br i1 %766, label %775, label %869

767:                                              ; preds = %743
  %768 = getelementptr inbounds nuw i8, ptr %0, i32 %101
  %769 = load i8, ptr %768, align 1, !tbaa !2
  %770 = icmp eq i8 %769, 92
  br i1 %770, label %779, label %771

771:                                              ; preds = %767
  %772 = icmp ne i8 %769, 105
  %773 = icmp eq i32 %745, 1
  %774 = or i1 %772, %773
  br i1 %774, label %869, label %747

775:                                              ; preds = %765
  %776 = getelementptr inbounds nuw i8, ptr %0, i32 %744
  %777 = load i8, ptr %776, align 1, !tbaa !2
  %778 = icmp eq i8 %777, 34
  br i1 %778, label %889, label %869

779:                                              ; preds = %762, %757, %752, %747, %767
  %780 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %64, i32 noundef %189, ptr noundef nonnull @.str.4, i32 noundef 5)
  %781 = icmp eq i32 %780, 0
  br i1 %781, label %869, label %889

782:                                              ; preds = %869
  %783 = icmp eq i32 %745, 1
  br i1 %783, label %889, label %784

784:                                              ; preds = %782
  %785 = getelementptr i8, ptr %42, i32 %64
  %786 = load i8, ptr %785, align 1, !tbaa !2
  switch i8 %786, label %880 [
    i8 92, label %873
    i8 116, label %787
  ]

787:                                              ; preds = %784
  %788 = icmp eq i32 %745, 2
  br i1 %788, label %889, label %789

789:                                              ; preds = %787
  %790 = getelementptr i8, ptr %43, i32 %64
  %791 = load i8, ptr %790, align 1, !tbaa !2
  switch i8 %791, label %880 [
    i8 92, label %873
    i8 114, label %792
  ]

792:                                              ; preds = %789
  %793 = icmp eq i32 %745, 3
  br i1 %793, label %889, label %794

794:                                              ; preds = %792
  %795 = getelementptr inbounds nuw i8, ptr %0, i32 %710
  %796 = load i8, ptr %795, align 1, !tbaa !2
  switch i8 %796, label %880 [
    i8 92, label %873
    i8 117, label %797
  ]

797:                                              ; preds = %794
  %798 = icmp eq i32 %745, 4
  br i1 %798, label %889, label %799

799:                                              ; preds = %797
  %800 = getelementptr inbounds nuw i8, ptr %0, i32 %709
  %801 = load i8, ptr %800, align 1, !tbaa !2
  switch i8 %801, label %880 [
    i8 92, label %873
    i8 99, label %802
  ]

802:                                              ; preds = %799
  %803 = icmp eq i32 %745, 5
  br i1 %803, label %889, label %804

804:                                              ; preds = %802
  %805 = getelementptr inbounds nuw i8, ptr %0, i32 %744
  %806 = load i8, ptr %805, align 1, !tbaa !2
  switch i8 %806, label %880 [
    i8 92, label %873
    i8 116, label %807
  ]

807:                                              ; preds = %804
  %808 = icmp eq i32 %745, 6
  br i1 %808, label %889, label %809

809:                                              ; preds = %807
  %810 = getelementptr i8, ptr %44, i32 %64
  %811 = load i8, ptr %810, align 1, !tbaa !2
  switch i8 %811, label %880 [
    i8 92, label %873
    i8 117, label %812
  ]

812:                                              ; preds = %809
  %813 = icmp eq i32 %745, 7
  br i1 %813, label %889, label %814

814:                                              ; preds = %812
  %815 = getelementptr i8, ptr %45, i32 %64
  %816 = load i8, ptr %815, align 1, !tbaa !2
  switch i8 %816, label %880 [
    i8 92, label %873
    i8 114, label %817
  ]

817:                                              ; preds = %814
  %818 = icmp eq i32 %745, 8
  br i1 %818, label %889, label %819

819:                                              ; preds = %817
  %820 = getelementptr i8, ptr %46, i32 %64
  %821 = load i8, ptr %820, align 1, !tbaa !2
  switch i8 %821, label %880 [
    i8 92, label %873
    i8 101, label %822
  ]

822:                                              ; preds = %819
  %823 = icmp eq i32 %745, 9
  br i1 %823, label %889, label %824

824:                                              ; preds = %822
  %825 = getelementptr i8, ptr %47, i32 %64
  %826 = load i8, ptr %825, align 1, !tbaa !2
  switch i8 %826, label %880 [
    i8 92, label %873
    i8 100, label %827
  ]

827:                                              ; preds = %824
  %828 = icmp eq i32 %745, 10
  br i1 %828, label %889, label %829

829:                                              ; preds = %827
  %830 = getelementptr i8, ptr %48, i32 %64
  %831 = load i8, ptr %830, align 1, !tbaa !2
  switch i8 %831, label %880 [
    i8 92, label %873
    i8 45, label %832
  ]

832:                                              ; preds = %829
  %833 = icmp eq i32 %745, 11
  br i1 %833, label %889, label %834

834:                                              ; preds = %832
  %835 = getelementptr i8, ptr %49, i32 %64
  %836 = load i8, ptr %835, align 1, !tbaa !2
  switch i8 %836, label %880 [
    i8 92, label %873
    i8 99, label %837
  ]

837:                                              ; preds = %834
  %838 = icmp eq i32 %745, 12
  br i1 %838, label %889, label %839

839:                                              ; preds = %837
  %840 = getelementptr i8, ptr %50, i32 %64
  %841 = load i8, ptr %840, align 1, !tbaa !2
  switch i8 %841, label %880 [
    i8 92, label %873
    i8 111, label %842
  ]

842:                                              ; preds = %839
  %843 = icmp eq i32 %745, 13
  br i1 %843, label %889, label %844

844:                                              ; preds = %842
  %845 = getelementptr i8, ptr %51, i32 %64
  %846 = load i8, ptr %845, align 1, !tbaa !2
  switch i8 %846, label %880 [
    i8 92, label %873
    i8 110, label %847
  ]

847:                                              ; preds = %844
  %848 = icmp eq i32 %745, 14
  br i1 %848, label %889, label %849

849:                                              ; preds = %847
  %850 = getelementptr i8, ptr %52, i32 %64
  %851 = load i8, ptr %850, align 1, !tbaa !2
  switch i8 %851, label %880 [
    i8 92, label %873
    i8 116, label %852
  ]

852:                                              ; preds = %849
  %853 = icmp eq i32 %745, 15
  br i1 %853, label %889, label %854

854:                                              ; preds = %852
  %855 = getelementptr i8, ptr %53, i32 %64
  %856 = load i8, ptr %855, align 1, !tbaa !2
  switch i8 %856, label %880 [
    i8 92, label %873
    i8 101, label %857
  ]

857:                                              ; preds = %854
  %858 = icmp eq i32 %745, 16
  br i1 %858, label %889, label %859

859:                                              ; preds = %857
  %860 = getelementptr i8, ptr %54, i32 %64
  %861 = load i8, ptr %860, align 1, !tbaa !2
  switch i8 %861, label %880 [
    i8 92, label %873
    i8 110, label %862
  ]

862:                                              ; preds = %859
  %863 = icmp eq i32 %745, 17
  br i1 %863, label %889, label %864

864:                                              ; preds = %862
  %865 = getelementptr inbounds nuw i8, ptr %0, i32 %870
  %866 = load i8, ptr %865, align 1, !tbaa !2
  switch i8 %866, label %880 [
    i8 92, label %873
    i8 116, label %867
  ]

867:                                              ; preds = %864
  %868 = icmp ult i32 %870, %129
  br i1 %868, label %876, label %889

869:                                              ; preds = %762, %757, %752, %747, %765, %779, %775, %760, %755, %750, %771
  %870 = add i32 %64, 18
  %871 = getelementptr inbounds nuw i8, ptr %0, i32 %101
  %872 = load i8, ptr %871, align 1, !tbaa !2
  switch i8 %872, label %880 [
    i8 92, label %873
    i8 115, label %782
  ]

873:                                              ; preds = %869, %864, %859, %854, %849, %844, %839, %834, %829, %824, %819, %814, %809, %804, %799, %794, %789, %784
  %874 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %64, i32 noundef %189, ptr noundef nonnull @.str.5, i32 noundef 18)
  %875 = icmp eq i32 %874, 0
  br label %880

876:                                              ; preds = %867
  %877 = getelementptr i8, ptr %55, i32 %64
  %878 = load i8, ptr %877, align 1, !tbaa !2
  %879 = icmp ne i8 %878, 34
  br label %880

880:                                              ; preds = %869, %864, %859, %854, %849, %844, %839, %834, %829, %824, %819, %814, %809, %804, %799, %794, %789, %784, %873, %876
  %881 = phi i1 [ %879, %876 ], [ %875, %873 ], [ true, %784 ], [ true, %789 ], [ true, %794 ], [ true, %799 ], [ true, %804 ], [ true, %809 ], [ true, %814 ], [ true, %819 ], [ true, %824 ], [ true, %829 ], [ true, %834 ], [ true, %839 ], [ true, %844 ], [ true, %849 ], [ true, %854 ], [ true, %859 ], [ true, %864 ], [ true, %869 ]
  %882 = freeze i1 %881
  %883 = select i1 %882, i32 0, i32 4
  br label %889

884:                                              ; preds = %701
  %885 = or i32 %62, %65
  br label %889

886:                                              ; preds = %696
  %887 = and i8 %61, -3
  %888 = icmp eq i8 %887, 0
  br i1 %888, label %889, label %1009

889:                                              ; preds = %743, %782, %787, %792, %797, %802, %807, %812, %817, %822, %827, %832, %837, %842, %847, %852, %857, %862, %775, %736, %880, %867, %703, %705, %886, %884, %779, %740, %698, %663, %657
  %890 = phi i32 [ %659, %663 ], [ %659, %657 ], [ %189, %884 ], [ %189, %698 ], [ %189, %779 ], [ %189, %740 ], [ %189, %886 ], [ %189, %705 ], [ %189, %703 ], [ %189, %867 ], [ %189, %880 ], [ %189, %736 ], [ %189, %775 ], [ %189, %862 ], [ %189, %857 ], [ %189, %852 ], [ %189, %847 ], [ %189, %842 ], [ %189, %837 ], [ %189, %832 ], [ %189, %827 ], [ %189, %822 ], [ %189, %817 ], [ %189, %812 ], [ %189, %807 ], [ %189, %802 ], [ %189, %797 ], [ %189, %792 ], [ %189, %787 ], [ %189, %782 ], [ %189, %743 ]
  %891 = phi i32 [ %65, %663 ], [ %65, %657 ], [ %885, %884 ], [ %65, %698 ], [ %65, %779 ], [ %65, %740 ], [ %65, %886 ], [ %65, %705 ], [ %65, %703 ], [ %65, %867 ], [ %65, %880 ], [ %65, %736 ], [ %65, %775 ], [ %65, %862 ], [ %65, %857 ], [ %65, %852 ], [ %65, %847 ], [ %65, %842 ], [ %65, %837 ], [ %65, %832 ], [ %65, %827 ], [ %65, %822 ], [ %65, %817 ], [ %65, %812 ], [ %65, %807 ], [ %65, %802 ], [ %65, %797 ], [ %65, %792 ], [ %65, %787 ], [ %65, %782 ], [ %65, %743 ]
  %892 = phi i32 [ %63, %663 ], [ %63, %657 ], [ %63, %884 ], [ %63, %698 ], [ 2, %779 ], [ 1, %740 ], [ %63, %886 ], [ 0, %705 ], [ 0, %703 ], [ 0, %867 ], [ %883, %880 ], [ 1, %736 ], [ 2, %775 ], [ 0, %862 ], [ 0, %857 ], [ 0, %852 ], [ 0, %847 ], [ 0, %842 ], [ 0, %837 ], [ 0, %832 ], [ 0, %827 ], [ 0, %822 ], [ 0, %817 ], [ 0, %812 ], [ 0, %807 ], [ 0, %802 ], [ 0, %797 ], [ 0, %792 ], [ 0, %787 ], [ 0, %782 ], [ 0, %743 ]
  %893 = phi i32 [ %661, %663 ], [ %661, %657 ], [ %62, %884 ], [ %62, %698 ], [ 8, %779 ], [ 8, %740 ], [ %62, %886 ], [ 8, %705 ], [ 8, %703 ], [ 8, %867 ], [ 8, %880 ], [ 8, %736 ], [ 8, %775 ], [ 8, %862 ], [ 8, %857 ], [ 8, %852 ], [ 8, %847 ], [ 8, %842 ], [ 8, %837 ], [ 8, %832 ], [ 8, %827 ], [ 8, %822 ], [ 8, %817 ], [ 8, %812 ], [ 8, %807 ], [ 8, %802 ], [ 8, %797 ], [ 8, %792 ], [ 8, %787 ], [ 8, %782 ], [ 8, %743 ]
  %894 = phi i8 [ 2, %663 ], [ 2, %657 ], [ 7, %884 ], [ 7, %698 ], [ 7, %779 ], [ 7, %740 ], [ 2, %886 ], [ 7, %705 ], [ 7, %703 ], [ 7, %867 ], [ 7, %880 ], [ 7, %736 ], [ 7, %775 ], [ 7, %862 ], [ 7, %857 ], [ 7, %852 ], [ 7, %847 ], [ 7, %842 ], [ 7, %837 ], [ 7, %832 ], [ 7, %827 ], [ 7, %822 ], [ 7, %817 ], [ 7, %812 ], [ 7, %807 ], [ 7, %802 ], [ 7, %797 ], [ 7, %792 ], [ 7, %787 ], [ 7, %782 ], [ 7, %743 ]
  %895 = phi i8 [ 4, %663 ], [ 4, %657 ], [ 6, %884 ], [ 6, %698 ], [ 6, %779 ], [ 6, %740 ], [ 1, %886 ], [ 6, %705 ], [ 6, %703 ], [ 6, %867 ], [ 6, %880 ], [ 6, %736 ], [ 6, %775 ], [ 6, %862 ], [ 6, %857 ], [ 6, %852 ], [ 6, %847 ], [ 6, %842 ], [ 6, %837 ], [ 6, %832 ], [ 6, %827 ], [ 6, %822 ], [ 6, %817 ], [ 6, %812 ], [ 6, %807 ], [ 6, %802 ], [ 6, %797 ], [ 6, %792 ], [ 6, %787 ], [ 6, %782 ], [ 6, %743 ]
  %896 = icmp ult i32 %890, %1
  %897 = and i1 %77, %896
  br i1 %897, label %898, label %1001, !llvm.loop !137

898:                                              ; preds = %889
  %899 = getelementptr inbounds nuw i8, ptr %0, i32 %890
  %900 = load i8, ptr %899, align 1, !tbaa !2
  %901 = icmp eq i8 %900, 44
  br i1 %901, label %902, label %1001, !llvm.loop !137

902:                                              ; preds = %898
  %903 = add nuw i32 %890, 1
  %904 = icmp ult i32 %903, %1
  br i1 %904, label %905, label %1001, !llvm.loop !137

905:                                              ; preds = %902
  %906 = getelementptr inbounds nuw i8, ptr %0, i32 %903
  %907 = load i8, ptr %906, align 1, !tbaa !2
  %908 = icmp eq i8 %907, 32
  br i1 %908, label %909, label %1001, !llvm.loop !137

909:                                              ; preds = %905
  br i1 %24, label %911, label %910

910:                                              ; preds = %909
  store i32 1, ptr %5, align 4, !tbaa !5
  br label %911

911:                                              ; preds = %910, %909
  %912 = add nuw i32 %890, 2
  br label %1001, !llvm.loop !137

913:                                              ; preds = %59
  %914 = icmp ugt i8 %61, 1
  br i1 %914, label %1009, label %922

915:                                              ; preds = %59
  switch i8 %61, label %1009 [
    i8 6, label %916
    i8 3, label %916
  ]

916:                                              ; preds = %915, %915
  %917 = icmp eq i32 %60, 2
  %918 = select i1 %18, i1 %917, i1 false
  %919 = and i32 %63, %65
  %920 = icmp eq i32 %919, 0
  %921 = select i1 %918, i1 %920, i1 false
  br i1 %921, label %1009, label %922

922:                                              ; preds = %916, %913
  %923 = add nuw i32 %64, 1
  %924 = add i32 %60, -1
  %925 = icmp eq i32 %924, 0
  br i1 %925, label %926, label %927

926:                                              ; preds = %922
  store i32 %923, ptr %3, align 4, !tbaa !5
  br label %1009

927:                                              ; preds = %922
  %928 = add i32 %60, -2
  %929 = getelementptr inbounds nuw [256 x i8], ptr %9, i32 0, i32 %928
  %930 = load i8, ptr %929, align 1, !tbaa !2
  br label %1001, !llvm.loop !137

931:                                              ; preds = %59
  switch i8 %61, label %1009 [
    i8 1, label %933
    i8 6, label %932
  ]

932:                                              ; preds = %931
  br label %933

933:                                              ; preds = %932, %931
  %934 = phi i8 [ 7, %932 ], [ 2, %931 ]
  %935 = add nuw i32 %64, 1
  %936 = icmp ult i32 %935, %1
  br i1 %936, label %937, label %1001, !llvm.loop !137

937:                                              ; preds = %933
  %938 = getelementptr inbounds nuw i8, ptr %0, i32 %935
  %939 = load i8, ptr %938, align 1, !tbaa !2
  %940 = icmp eq i8 %939, 32
  br i1 %940, label %941, label %1001, !llvm.loop !137

941:                                              ; preds = %937
  br i1 %24, label %943, label %942

942:                                              ; preds = %941
  store i32 1, ptr %5, align 4, !tbaa !5
  br label %943

943:                                              ; preds = %942, %941
  %944 = add nuw i32 %64, 2
  br label %1001, !llvm.loop !137

945:                                              ; preds = %59
  %946 = icmp eq i8 %61, 4
  br i1 %946, label %947, label %1009

947:                                              ; preds = %945
  %948 = add nuw i32 %64, 1
  %949 = icmp ult i32 %948, %1
  br i1 %949, label %950, label %1001, !llvm.loop !137

950:                                              ; preds = %947
  %951 = getelementptr inbounds nuw i8, ptr %0, i32 %948
  %952 = load i8, ptr %951, align 1, !tbaa !2
  %953 = icmp eq i8 %952, 32
  br i1 %953, label %954, label %1001, !llvm.loop !137

954:                                              ; preds = %950
  br i1 %24, label %956, label %955

955:                                              ; preds = %954
  store i32 1, ptr %5, align 4, !tbaa !5
  br label %956

956:                                              ; preds = %955, %954
  %957 = add nuw i32 %64, 2
  br label %1001, !llvm.loop !137

958:                                              ; preds = %59
  %959 = and i8 %61, -3
  %960 = icmp eq i8 %959, 0
  br i1 %960, label %975, label %961

961:                                              ; preds = %958
  %962 = icmp eq i8 %61, 5
  br i1 %962, label %963, label %1009

963:                                              ; preds = %961
  %964 = icmp eq i32 %60, 2
  %965 = select i1 %18, i1 %964, i1 false
  br i1 %965, label %966, label %975

966:                                              ; preds = %963
  switch i32 %62, label %972 [
    i32 8, label %975
    i32 4, label %967
  ]

967:                                              ; preds = %966
  %968 = and i8 %67, -33
  %969 = icmp eq i8 %968, 91
  br i1 %969, label %970, label %972

970:                                              ; preds = %967
  %971 = or i32 %65, 4
  br label %975

972:                                              ; preds = %967, %966
  %973 = xor i32 %62, -1
  %974 = and i32 %65, %973
  br label %975

975:                                              ; preds = %958, %972, %970, %966, %963
  %976 = phi i8 [ 6, %970 ], [ 6, %972 ], [ 6, %963 ], [ 6, %966 ], [ 1, %958 ]
  %977 = phi i32 [ %971, %970 ], [ %974, %972 ], [ %65, %963 ], [ %65, %966 ], [ %65, %958 ]
  %978 = phi i32 [ %63, %970 ], [ %63, %972 ], [ %63, %963 ], [ 0, %966 ], [ %63, %958 ]
  %979 = icmp eq i8 %67, 91
  %980 = icmp eq i8 %67, 123
  switch i8 %67, label %995 [
    i8 123, label %981
    i8 91, label %981
  ]

981:                                              ; preds = %975, %975
  %982 = icmp ugt i32 %60, 255
  br i1 %982, label %1009, label %983

983:                                              ; preds = %981
  %984 = icmp eq i32 %60, 1
  %985 = select i1 %18, i1 %984, i1 false
  %986 = and i1 %985, %980
  %987 = select i1 %986, i32 0, i32 %977
  %988 = select i1 %986, i32 0, i32 %978
  %989 = select i1 %986, i32 0, i32 %62
  %990 = add nsw i32 %60, -1
  %991 = getelementptr inbounds nuw [256 x i8], ptr %9, i32 0, i32 %990
  store i8 %976, ptr %991, align 1, !tbaa !2
  %992 = add nuw nsw i32 %60, 1
  %993 = select i1 %979, i8 0, i8 3
  %994 = add nuw i32 %64, 1
  br label %1001, !llvm.loop !137

995:                                              ; preds = %975
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %10) #28
  store i32 0, ptr %10, align 4, !tbaa !5
  %996 = call fastcc i32 @parse_scalar_span(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %64, ptr noundef %10)
  %997 = icmp eq i32 %996, 0
  br i1 %997, label %998, label %999

998:                                              ; preds = %995
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10) #28
  br label %1009

999:                                              ; preds = %995
  %1000 = load i32, ptr %10, align 4, !tbaa !5
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %10) #28
  br label %1001

1001:                                             ; preds = %364, %358, %353, %956, %950, %947, %943, %937, %933, %911, %905, %902, %889, %898, %682, %678, %687, %983, %927, %73, %999
  %1002 = phi i32 [ %60, %999 ], [ %60, %364 ], [ %60, %358 ], [ %60, %353 ], [ %60, %956 ], [ %60, %950 ], [ %60, %947 ], [ %60, %943 ], [ %60, %937 ], [ %60, %933 ], [ %60, %911 ], [ %60, %905 ], [ %60, %902 ], [ %60, %889 ], [ %60, %898 ], [ %60, %682 ], [ %60, %678 ], [ %692, %687 ], [ %992, %983 ], [ %924, %927 ], [ %60, %73 ]
  %1003 = phi i8 [ %976, %999 ], [ 7, %364 ], [ 7, %358 ], [ 7, %353 ], [ 5, %956 ], [ 5, %950 ], [ 5, %947 ], [ %934, %943 ], [ %934, %937 ], [ %934, %933 ], [ %894, %911 ], [ %894, %905 ], [ %894, %902 ], [ %895, %889 ], [ %895, %898 ], [ 5, %682 ], [ 5, %678 ], [ %694, %687 ], [ %993, %983 ], [ %930, %927 ], [ %61, %73 ]
  %1004 = phi i32 [ %62, %999 ], [ %356, %364 ], [ %356, %358 ], [ %356, %353 ], [ %62, %956 ], [ %62, %950 ], [ %62, %947 ], [ %62, %943 ], [ %62, %937 ], [ %62, %933 ], [ %893, %911 ], [ %893, %905 ], [ %893, %902 ], [ %893, %889 ], [ %893, %898 ], [ %661, %682 ], [ %661, %678 ], [ %661, %687 ], [ %989, %983 ], [ %62, %927 ], [ %62, %73 ]
  %1005 = phi i32 [ %978, %999 ], [ %63, %364 ], [ %63, %358 ], [ %63, %353 ], [ %63, %956 ], [ %63, %950 ], [ %63, %947 ], [ %63, %943 ], [ %63, %937 ], [ %63, %933 ], [ %892, %911 ], [ %892, %905 ], [ %892, %902 ], [ %892, %889 ], [ %892, %898 ], [ %63, %682 ], [ %63, %678 ], [ %63, %687 ], [ %988, %983 ], [ %63, %927 ], [ %63, %73 ]
  %1006 = phi i32 [ %1000, %999 ], [ %365, %364 ], [ %345, %358 ], [ %345, %353 ], [ %957, %956 ], [ %948, %950 ], [ %948, %947 ], [ %944, %943 ], [ %935, %937 ], [ %935, %933 ], [ %912, %911 ], [ %903, %905 ], [ %903, %902 ], [ %890, %889 ], [ %890, %898 ], [ %679, %682 ], [ %679, %678 ], [ %695, %687 ], [ %994, %983 ], [ %923, %927 ], [ %74, %73 ]
  %1007 = phi i32 [ %977, %999 ], [ %65, %364 ], [ %65, %358 ], [ %65, %353 ], [ %65, %956 ], [ %65, %950 ], [ %65, %947 ], [ %65, %943 ], [ %65, %937 ], [ %65, %933 ], [ %891, %911 ], [ %891, %905 ], [ %891, %902 ], [ %891, %889 ], [ %891, %898 ], [ %65, %682 ], [ %65, %678 ], [ %689, %687 ], [ %987, %983 ], [ %65, %927 ], [ %65, %73 ]
  %1008 = icmp ult i32 %1006, %1
  br i1 %1008, label %59, label %1009, !llvm.loop !137

1009:                                             ; preds = %1001, %913, %915, %916, %931, %945, %961, %981, %685, %886, %100, %128, %190, %138, %185, %141, %135, %147, %156, %165, %174, %998, %15, %926
  %1010 = phi i32 [ 1, %926 ], [ 0, %15 ], [ 0, %998 ], [ 0, %174 ], [ 0, %165 ], [ 0, %156 ], [ 0, %147 ], [ 0, %135 ], [ 0, %141 ], [ 0, %185 ], [ 0, %138 ], [ 0, %190 ], [ 0, %128 ], [ 0, %100 ], [ 0, %886 ], [ 0, %685 ], [ 0, %981 ], [ 0, %961 ], [ 0, %945 ], [ 0, %931 ], [ 0, %916 ], [ 0, %915 ], [ 0, %913 ], [ 0, %1001 ]
  call void @llvm.lifetime.end.p0(i64 256, ptr nonnull %9) #28
  br label %1011

1011:                                             ; preds = %8, %12, %1009
  %1012 = phi i32 [ %1010, %1009 ], [ 0, %12 ], [ 0, %8 ]
  ret i32 %1012
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.cttz.i64(i64, i1 immarg) #22

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: read)
define internal fastcc range(i32 0, 2) i32 @json_string_matches_ascii_escaped(ptr noundef readonly captures(none) %0, i32 noundef %1, i32 noundef %2, ptr noundef readonly captures(none) %3, i32 noundef range(i32 3, 19) %4) unnamed_addr #18 {
  %6 = icmp ult i32 %1, %2
  br i1 %6, label %7, label %115

7:                                                ; preds = %5
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 %1
  %9 = load i8, ptr %8, align 1, !tbaa !2
  %10 = icmp eq i8 %9, 34
  %11 = add nuw i32 %1, 1
  %12 = icmp ult i32 %11, %2
  %13 = select i1 %10, i1 %12, i1 false
  br i1 %13, label %19, label %115

14:                                               ; preds = %100
  %15 = add nuw nsw i32 %20, 1
  %16 = icmp samesign ult i32 %15, %4
  %17 = icmp ult i32 %101, %2
  %18 = select i1 %16, i1 %17, i1 false
  br i1 %18, label %19, label %107, !llvm.loop !138

19:                                               ; preds = %7, %14
  %20 = phi i32 [ %15, %14 ], [ 0, %7 ]
  %21 = phi i32 [ %101, %14 ], [ %11, %7 ]
  %22 = add nuw i32 %21, 1
  %23 = getelementptr inbounds nuw i8, ptr %0, i32 %21
  %24 = load i8, ptr %23, align 1, !tbaa !2
  %25 = zext i8 %24 to i32
  %26 = icmp eq i8 %24, 92
  br i1 %26, label %27, label %100

27:                                               ; preds = %19
  %28 = sub i32 %2, %22
  %29 = icmp ult i32 %28, 5
  br i1 %29, label %115, label %30

30:                                               ; preds = %27
  %31 = getelementptr inbounds nuw i8, ptr %0, i32 %22
  %32 = load i8, ptr %31, align 1, !tbaa !2
  %33 = icmp eq i8 %32, 117
  br i1 %33, label %34, label %115

34:                                               ; preds = %30
  %35 = getelementptr inbounds nuw i8, ptr %31, i32 1
  %36 = load i8, ptr %35, align 1, !tbaa !2
  %37 = zext i8 %36 to i32
  %38 = add i8 %36, -48
  %39 = icmp ult i8 %38, 10
  br i1 %39, label %46, label %40

40:                                               ; preds = %34
  %41 = add i8 %36, -97
  %42 = icmp ult i8 %41, 6
  br i1 %42, label %46, label %43

43:                                               ; preds = %40
  %44 = add i8 %36, -65
  %45 = icmp ult i8 %44, 6
  br i1 %45, label %46, label %97

46:                                               ; preds = %43, %40, %34
  %47 = phi i32 [ -48, %34 ], [ -87, %40 ], [ -55, %43 ]
  %48 = add nsw i32 %47, %37
  %49 = getelementptr inbounds nuw i8, ptr %31, i32 2
  %50 = load i8, ptr %49, align 1, !tbaa !2
  %51 = zext i8 %50 to i32
  %52 = add i8 %50, -48
  %53 = icmp ult i8 %52, 10
  br i1 %53, label %60, label %54

54:                                               ; preds = %46
  %55 = add i8 %50, -97
  %56 = icmp ult i8 %55, 6
  br i1 %56, label %60, label %57

57:                                               ; preds = %54
  %58 = add i8 %50, -65
  %59 = icmp ult i8 %58, 6
  br i1 %59, label %60, label %97

60:                                               ; preds = %57, %54, %46
  %61 = phi i32 [ -55, %57 ], [ -87, %54 ], [ -48, %46 ]
  %62 = add nsw i32 %61, %51
  %63 = getelementptr inbounds nuw i8, ptr %31, i32 3
  %64 = load i8, ptr %63, align 1, !tbaa !2
  %65 = zext i8 %64 to i32
  %66 = add i8 %64, -48
  %67 = icmp ult i8 %66, 10
  br i1 %67, label %74, label %68

68:                                               ; preds = %60
  %69 = add i8 %64, -97
  %70 = icmp ult i8 %69, 6
  br i1 %70, label %74, label %71

71:                                               ; preds = %68
  %72 = add i8 %64, -65
  %73 = icmp ult i8 %72, 6
  br i1 %73, label %74, label %97

74:                                               ; preds = %71, %68, %60
  %75 = phi i32 [ -55, %71 ], [ -87, %68 ], [ -48, %60 ]
  %76 = add nsw i32 %75, %65
  %77 = shl nsw i32 %48, 8
  %78 = shl nsw i32 %62, 4
  %79 = or i32 %78, %77
  %80 = or i32 %79, %76
  %81 = getelementptr inbounds nuw i8, ptr %31, i32 4
  %82 = load i8, ptr %81, align 1, !tbaa !2
  %83 = zext i8 %82 to i32
  %84 = add i8 %82, -48
  %85 = icmp ult i8 %84, 10
  br i1 %85, label %92, label %86

86:                                               ; preds = %74
  %87 = add i8 %82, -97
  %88 = icmp ult i8 %87, 6
  br i1 %88, label %92, label %89

89:                                               ; preds = %86
  %90 = add i8 %82, -65
  %91 = icmp ult i8 %90, 6
  br i1 %91, label %92, label %97

92:                                               ; preds = %89, %86, %74
  %93 = phi i32 [ -55, %89 ], [ -87, %86 ], [ -48, %74 ]
  %94 = add nsw i32 %93, %83
  %95 = shl nsw i32 %80, 4
  %96 = or i32 %94, %95
  br label %97

97:                                               ; preds = %43, %57, %71, %89, %92
  %98 = phi i32 [ -1, %43 ], [ -1, %57 ], [ -1, %71 ], [ -1, %89 ], [ %96, %92 ]
  %99 = add i32 %21, 6
  br label %100

100:                                              ; preds = %19, %97
  %101 = phi i32 [ %99, %97 ], [ %22, %19 ]
  %102 = phi i32 [ %98, %97 ], [ %25, %19 ]
  %103 = getelementptr inbounds nuw i8, ptr %3, i32 %20
  %104 = load i8, ptr %103, align 1, !tbaa !2
  %105 = zext i8 %104 to i32
  %106 = icmp eq i32 %102, %105
  br i1 %106, label %14, label %115

107:                                              ; preds = %14
  %108 = icmp uge i32 %101, %2
  %109 = select i1 %16, i1 true, i1 %108
  br i1 %109, label %115, label %110

110:                                              ; preds = %107
  %111 = getelementptr inbounds nuw i8, ptr %0, i32 %101
  %112 = load i8, ptr %111, align 1, !tbaa !2
  %113 = icmp eq i8 %112, 34
  %114 = zext i1 %113 to i32
  br label %115

115:                                              ; preds = %27, %30, %100, %107, %110, %5, %7
  %116 = phi i32 [ 0, %7 ], [ 0, %5 ], [ 0, %107 ], [ %114, %110 ], [ 0, %100 ], [ 0, %30 ], [ 0, %27 ]
  ret i32 %116
}

; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read)
define internal fastcc i32 @key_hex4(ptr noundef readonly captures(none) %0) unnamed_addr #23 {
  %2 = load i8, ptr %0, align 1, !tbaa !2
  %3 = zext i8 %2 to i32
  %4 = add i8 %2, -48
  %5 = icmp ult i8 %4, 10
  br i1 %5, label %12, label %6

6:                                                ; preds = %1
  %7 = add i8 %2, -97
  %8 = icmp ult i8 %7, 6
  br i1 %8, label %12, label %9

9:                                                ; preds = %6
  %10 = add i8 %2, -65
  %11 = icmp ult i8 %10, 6
  br i1 %11, label %12, label %63

12:                                               ; preds = %9, %6, %1
  %13 = phi i32 [ -48, %1 ], [ -87, %6 ], [ -55, %9 ]
  %14 = add nsw i32 %13, %3
  %15 = getelementptr inbounds nuw i8, ptr %0, i32 1
  %16 = load i8, ptr %15, align 1, !tbaa !2
  %17 = zext i8 %16 to i32
  %18 = add i8 %16, -48
  %19 = icmp ult i8 %18, 10
  br i1 %19, label %26, label %20

20:                                               ; preds = %12
  %21 = add i8 %16, -97
  %22 = icmp ult i8 %21, 6
  br i1 %22, label %26, label %23

23:                                               ; preds = %20
  %24 = add i8 %16, -65
  %25 = icmp ult i8 %24, 6
  br i1 %25, label %26, label %63

26:                                               ; preds = %12, %20, %23
  %27 = phi i32 [ -55, %23 ], [ -87, %20 ], [ -48, %12 ]
  %28 = add nsw i32 %27, %17
  %29 = getelementptr inbounds nuw i8, ptr %0, i32 2
  %30 = load i8, ptr %29, align 1, !tbaa !2
  %31 = zext i8 %30 to i32
  %32 = add i8 %30, -48
  %33 = icmp ult i8 %32, 10
  br i1 %33, label %40, label %34

34:                                               ; preds = %26
  %35 = add i8 %30, -97
  %36 = icmp ult i8 %35, 6
  br i1 %36, label %40, label %37

37:                                               ; preds = %34
  %38 = add i8 %30, -65
  %39 = icmp ult i8 %38, 6
  br i1 %39, label %40, label %63

40:                                               ; preds = %26, %34, %37
  %41 = phi i32 [ -55, %37 ], [ -87, %34 ], [ -48, %26 ]
  %42 = add nsw i32 %41, %31
  %43 = shl nsw i32 %14, 8
  %44 = shl nsw i32 %28, 4
  %45 = or i32 %43, %44
  %46 = or i32 %42, %45
  %47 = getelementptr inbounds nuw i8, ptr %0, i32 3
  %48 = load i8, ptr %47, align 1, !tbaa !2
  %49 = zext i8 %48 to i32
  %50 = add i8 %48, -48
  %51 = icmp ult i8 %50, 10
  br i1 %51, label %58, label %52

52:                                               ; preds = %40
  %53 = add i8 %48, -97
  %54 = icmp ult i8 %53, 6
  br i1 %54, label %58, label %55

55:                                               ; preds = %52
  %56 = add i8 %48, -65
  %57 = icmp ult i8 %56, 6
  br i1 %57, label %58, label %63

58:                                               ; preds = %40, %52, %55
  %59 = phi i32 [ -55, %55 ], [ -87, %52 ], [ -48, %40 ]
  %60 = add nsw i32 %59, %49
  %61 = shl nsw i32 %46, 4
  %62 = or i32 %60, %61
  br label %63

63:                                               ; preds = %58, %55, %37, %23, %9
  %64 = phi i32 [ -1, %9 ], [ -1, %23 ], [ -1, %37 ], [ -1, %55 ], [ %62, %58 ]
  ret i32 %64
}

; Function Attrs: nofree nosync nounwind memory(readwrite, inaccessiblemem: none)
define internal fastcc range(i32 0, 2) i32 @write_normalized_glossary_value(ptr noundef %0, i32 noundef %1, i32 noundef %2, i32 noundef %3, ptr noundef writeonly captures(none) %4, i32 noundef %5, ptr noundef nonnull captures(none) %6) unnamed_addr #15 {
  %8 = alloca i32, align 4
  %9 = alloca i32, align 4
  %10 = icmp ult i32 %2, %3
  br i1 %10, label %11, label %420

11:                                               ; preds = %7
  %12 = getelementptr inbounds nuw i8, ptr %0, i32 %2
  %13 = load i8, ptr %12, align 1, !tbaa !2
  switch i8 %13, label %411 [
    i8 91, label %14
    i8 123, label %87
  ]

14:                                               ; preds = %11
  %15 = load i32, ptr %6, align 4, !tbaa !5
  %16 = icmp ult i32 %15, %5
  br i1 %16, label %17, label %420

17:                                               ; preds = %14
  %18 = getelementptr inbounds nuw i8, ptr %4, i32 %15
  store i8 91, ptr %18, align 1, !tbaa !2
  %19 = load i32, ptr %6, align 4, !tbaa !5
  %20 = add i32 %19, 1
  store i32 %20, ptr %6, align 4, !tbaa !5
  %21 = add nuw i32 %2, 1
  %22 = icmp ult i32 %21, %3
  br i1 %22, label %23, label %80

23:                                               ; preds = %17, %75
  %24 = phi i1 [ true, %75 ], [ false, %17 ]
  %25 = phi i32 [ %76, %75 ], [ %21, %17 ]
  %26 = icmp ult i32 %25, %1
  br i1 %26, label %27, label %34

27:                                               ; preds = %23, %31
  %28 = phi i32 [ %32, %31 ], [ %25, %23 ]
  %29 = getelementptr inbounds nuw i8, ptr %0, i32 %28
  %30 = load i8, ptr %29, align 1, !tbaa !2
  switch i8 %30, label %34 [
    i8 32, label %31
    i8 13, label %31
    i8 10, label %31
    i8 9, label %31
  ]

31:                                               ; preds = %27, %27, %27, %27
  %32 = add i32 %28, 1
  %33 = icmp eq i32 %32, %1
  br i1 %33, label %34, label %27, !llvm.loop !35

34:                                               ; preds = %27, %31, %23
  %35 = phi i32 [ %25, %23 ], [ %1, %31 ], [ %28, %27 ]
  %36 = icmp ult i32 %35, %3
  br i1 %36, label %37, label %420

37:                                               ; preds = %34
  %38 = getelementptr inbounds nuw i8, ptr %0, i32 %35
  %39 = load i8, ptr %38, align 1, !tbaa !2
  %40 = icmp eq i8 %39, 93
  br i1 %40, label %78, label %41

41:                                               ; preds = %37
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9) #28
  store i32 0, ptr %9, align 4, !tbaa !5
  %42 = call fastcc i32 @parse_value_span(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %35, ptr noundef %9)
  %43 = icmp eq i32 %42, 0
  br i1 %43, label %74, label %44

44:                                               ; preds = %41
  br i1 %24, label %45, label %52

45:                                               ; preds = %44
  %46 = load i32, ptr %6, align 4, !tbaa !5
  %47 = icmp ult i32 %46, %5
  br i1 %47, label %48, label %74

48:                                               ; preds = %45
  %49 = getelementptr inbounds nuw i8, ptr %4, i32 %46
  store i8 44, ptr %49, align 1, !tbaa !2
  %50 = load i32, ptr %6, align 4, !tbaa !5
  %51 = add i32 %50, 1
  store i32 %51, ptr %6, align 4, !tbaa !5
  br label %52

52:                                               ; preds = %48, %44
  %53 = load i32, ptr %9, align 4, !tbaa !5
  %54 = tail call fastcc i32 @write_normalized_glossary_value(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %35, i32 noundef %53, ptr noundef %4, i32 noundef %5, ptr noundef %6)
  %55 = icmp eq i32 %54, 0
  br i1 %55, label %74, label %56

56:                                               ; preds = %52
  %57 = icmp ult i32 %53, %1
  br i1 %57, label %58, label %65

58:                                               ; preds = %56, %62
  %59 = phi i32 [ %63, %62 ], [ %53, %56 ]
  %60 = getelementptr inbounds nuw i8, ptr %0, i32 %59
  %61 = load i8, ptr %60, align 1, !tbaa !2
  switch i8 %61, label %65 [
    i8 32, label %62
    i8 13, label %62
    i8 10, label %62
    i8 9, label %62
  ]

62:                                               ; preds = %58, %58, %58, %58
  %63 = add i32 %59, 1
  %64 = icmp eq i32 %63, %1
  br i1 %64, label %65, label %58, !llvm.loop !35

65:                                               ; preds = %58, %62, %56
  %66 = phi i32 [ %53, %56 ], [ %1, %62 ], [ %59, %58 ]
  %67 = icmp ult i32 %66, %3
  br i1 %67, label %68, label %75

68:                                               ; preds = %65
  %69 = getelementptr inbounds nuw i8, ptr %0, i32 %66
  %70 = load i8, ptr %69, align 1, !tbaa !2
  %71 = icmp eq i8 %70, 44
  %72 = zext i1 %71 to i32
  %73 = add nuw i32 %66, %72
  br label %75

74:                                               ; preds = %41, %52, %45
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9) #28
  br label %420

75:                                               ; preds = %68, %65
  %76 = phi i32 [ %66, %65 ], [ %73, %68 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9) #28
  %77 = icmp ult i32 %76, %3
  br i1 %77, label %23, label %78, !llvm.loop !139

78:                                               ; preds = %37, %75
  %79 = load i32, ptr %6, align 4, !tbaa !5
  br label %80

80:                                               ; preds = %78, %17
  %81 = phi i32 [ %79, %78 ], [ %20, %17 ]
  %82 = icmp ult i32 %81, %5
  br i1 %82, label %83, label %420

83:                                               ; preds = %80
  %84 = getelementptr inbounds nuw i8, ptr %4, i32 %81
  store i8 93, ptr %84, align 1, !tbaa !2
  %85 = load i32, ptr %6, align 4, !tbaa !5
  %86 = add i32 %85, 1
  store i32 %86, ptr %6, align 4, !tbaa !5
  br label %420

87:                                               ; preds = %11
  %88 = icmp ugt i32 %3, %1
  br i1 %88, label %411, label %89

89:                                               ; preds = %87
  %90 = add nuw i32 %2, 1
  %91 = icmp ult i32 %90, %3
  br i1 %91, label %92, label %99

92:                                               ; preds = %89, %96
  %93 = phi i32 [ %97, %96 ], [ %90, %89 ]
  %94 = getelementptr inbounds nuw i8, ptr %0, i32 %93
  %95 = load i8, ptr %94, align 1, !tbaa !2
  switch i8 %95, label %99 [
    i8 32, label %96
    i8 13, label %96
    i8 10, label %96
    i8 9, label %96
  ]

96:                                               ; preds = %92, %92, %92, %92
  %97 = add i32 %93, 1
  %98 = icmp eq i32 %97, %3
  br i1 %98, label %411, label %92, !llvm.loop !35

99:                                               ; preds = %92, %89
  %100 = phi i32 [ %90, %89 ], [ %93, %92 ]
  %101 = icmp ult i32 %100, %3
  br i1 %101, label %102, label %411

102:                                              ; preds = %99
  %103 = getelementptr i8, ptr %0, i32 3
  %104 = getelementptr i8, ptr %0, i32 4
  %105 = getelementptr i8, ptr %0, i32 5
  %106 = getelementptr i8, ptr %0, i32 2
  %107 = getelementptr i8, ptr %0, i32 1
  br label %108

108:                                              ; preds = %398, %102
  %109 = phi i32 [ %399, %398 ], [ %100, %102 ]
  %110 = phi i32 [ %373, %398 ], [ 0, %102 ]
  %111 = phi i32 [ %372, %398 ], [ 0, %102 ]
  %112 = phi i32 [ %371, %398 ], [ 0, %102 ]
  %113 = phi i32 [ %370, %398 ], [ 0, %102 ]
  %114 = getelementptr inbounds nuw i8, ptr %0, i32 %109
  %115 = load i8, ptr %114, align 1, !tbaa !2
  switch i8 %115, label %411 [
    i8 125, label %116
    i8 34, label %120
  ]

116:                                              ; preds = %108
  %117 = icmp ne i32 %113, 0
  %118 = icmp ne i32 %112, 0
  %119 = select i1 %117, i1 %118, i1 false
  br i1 %119, label %401, label %411

120:                                              ; preds = %108
  %121 = add nuw i32 %109, 1
  %122 = icmp ult i32 %121, %3
  br i1 %122, label %123, label %411

123:                                              ; preds = %120, %141
  %124 = phi i32 [ %142, %141 ], [ %121, %120 ]
  %125 = add i32 %124, 8
  %126 = icmp ugt i32 %125, %3
  br i1 %126, label %148, label %127

127:                                              ; preds = %123
  %128 = getelementptr inbounds nuw i8, ptr %0, i32 %124
  %129 = load i64, ptr %128, align 1
  %130 = xor i64 %129, 2459565876494606882
  %131 = add i64 %130, -72340172838076673
  %132 = and i64 %129, -9187201950435737472
  %133 = xor i64 %132, -9187201950435737472
  %134 = xor i64 %129, 6655295901103053916
  %135 = add i64 %134, -72340172838076673
  %136 = add i64 %129, -2314885530818453536
  %137 = or i64 %135, %136
  %138 = or i64 %137, %131
  %139 = and i64 %138, %133
  %140 = icmp eq i64 %139, 0
  br i1 %140, label %141, label %143

141:                                              ; preds = %127, %210
  %142 = phi i32 [ %125, %127 ], [ %211, %210 ]
  br label %123

143:                                              ; preds = %127
  %144 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %139, i1 true)
  %145 = trunc nuw nsw i64 %144 to i32
  %146 = lshr i32 %145, 3
  %147 = add i32 %146, %124
  br label %148

148:                                              ; preds = %123, %143
  %149 = phi i32 [ %147, %143 ], [ %124, %123 ]
  %150 = icmp ult i32 %149, %3
  br i1 %150, label %151, label %411

151:                                              ; preds = %148
  %152 = getelementptr inbounds nuw i8, ptr %0, i32 %149
  %153 = load i8, ptr %152, align 1, !tbaa !2
  %154 = icmp eq i8 %153, 92
  br i1 %154, label %155, label %205

155:                                              ; preds = %151
  %156 = add nuw i32 %149, 1
  %157 = icmp ult i32 %156, %3
  br i1 %157, label %158, label %411

158:                                              ; preds = %155
  %159 = getelementptr inbounds nuw i8, ptr %0, i32 %156
  %160 = load i8, ptr %159, align 1, !tbaa !2
  switch i8 %160, label %411 [
    i8 117, label %161
    i8 116, label %203
    i8 114, label %203
    i8 110, label %203
    i8 102, label %203
    i8 98, label %203
    i8 92, label %203
    i8 47, label %203
    i8 34, label %203
  ]

161:                                              ; preds = %158
  %162 = add i32 %149, 6
  %163 = icmp ugt i32 %162, %3
  br i1 %163, label %411, label %164

164:                                              ; preds = %161
  %165 = add nuw i32 %149, 2
  %166 = icmp ult i32 %165, %162
  br i1 %166, label %167, label %210

167:                                              ; preds = %164
  %168 = getelementptr inbounds nuw i8, ptr %0, i32 %165
  %169 = load i8, ptr %168, align 1, !tbaa !2
  %170 = add i8 %169, -58
  %171 = icmp ult i8 %170, -10
  %172 = and i8 %169, -33
  %173 = add i8 %172, -71
  %174 = icmp ult i8 %173, -6
  %175 = and i1 %171, %174
  br i1 %175, label %411, label %176

176:                                              ; preds = %167
  %177 = getelementptr i8, ptr %103, i32 %149
  %178 = load i8, ptr %177, align 1, !tbaa !2
  %179 = add i8 %178, -58
  %180 = icmp ult i8 %179, -10
  %181 = and i8 %178, -33
  %182 = add i8 %181, -71
  %183 = icmp ult i8 %182, -6
  %184 = and i1 %180, %183
  br i1 %184, label %411, label %185

185:                                              ; preds = %176
  %186 = getelementptr i8, ptr %104, i32 %149
  %187 = load i8, ptr %186, align 1, !tbaa !2
  %188 = add i8 %187, -58
  %189 = icmp ult i8 %188, -10
  %190 = and i8 %187, -33
  %191 = add i8 %190, -71
  %192 = icmp ult i8 %191, -6
  %193 = and i1 %189, %192
  br i1 %193, label %411, label %194

194:                                              ; preds = %185
  %195 = getelementptr i8, ptr %105, i32 %149
  %196 = load i8, ptr %195, align 1, !tbaa !2
  %197 = add i8 %196, -58
  %198 = icmp ult i8 %197, -10
  %199 = and i8 %196, -33
  %200 = add i8 %199, -71
  %201 = icmp ult i8 %200, -6
  %202 = and i1 %198, %201
  br i1 %202, label %411, label %210

203:                                              ; preds = %158, %158, %158, %158, %158, %158, %158, %158
  %204 = add nuw i32 %149, 2
  br label %210, !llvm.loop !42

205:                                              ; preds = %151
  %206 = icmp ult i8 %153, 32
  br i1 %206, label %411, label %207

207:                                              ; preds = %205
  %208 = icmp eq i8 %153, 34
  %209 = add nuw i32 %149, 1
  br i1 %208, label %213, label %210

210:                                              ; preds = %207, %203, %194, %164
  %211 = phi i32 [ %204, %203 ], [ %162, %164 ], [ %162, %194 ], [ %209, %207 ]
  %212 = icmp ult i32 %211, %3
  br i1 %212, label %141, label %411

213:                                              ; preds = %207
  %214 = icmp ugt i32 %109, %149
  br i1 %214, label %282, label %215

215:                                              ; preds = %213
  %216 = add i32 %109, 5
  %217 = sub nuw i32 %149, %109
  %218 = icmp eq i32 %149, %109
  br i1 %218, label %249, label %234

219:                                              ; preds = %240
  %220 = getelementptr i8, ptr %106, i32 %109
  %221 = load i8, ptr %220, align 1, !tbaa !2
  switch i8 %221, label %249 [
    i8 92, label %238
    i8 121, label %222
  ]

222:                                              ; preds = %219
  %223 = icmp eq i32 %217, 2
  br i1 %223, label %249, label %224

224:                                              ; preds = %222
  %225 = getelementptr i8, ptr %103, i32 %109
  %226 = load i8, ptr %225, align 1, !tbaa !2
  switch i8 %226, label %249 [
    i8 92, label %238
    i8 112, label %227
  ]

227:                                              ; preds = %224
  %228 = icmp eq i32 %217, 3
  br i1 %228, label %249, label %229

229:                                              ; preds = %227
  %230 = getelementptr i8, ptr %104, i32 %109
  %231 = load i8, ptr %230, align 1, !tbaa !2
  switch i8 %231, label %249 [
    i8 92, label %238
    i8 101, label %232
  ]

232:                                              ; preds = %229
  %233 = icmp ugt i32 %216, %149
  br i1 %233, label %249, label %244

234:                                              ; preds = %215
  %235 = getelementptr inbounds nuw i8, ptr %0, i32 %121
  %236 = load i8, ptr %235, align 1, !tbaa !2
  %237 = icmp eq i8 %236, 92
  br i1 %237, label %238, label %240

238:                                              ; preds = %234, %229, %224, %219
  %239 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %109, i32 noundef %209, ptr noundef nonnull @.str.2, i32 noundef 4)
  br label %249

240:                                              ; preds = %234
  %241 = icmp ne i8 %236, 116
  %242 = icmp eq i32 %217, 1
  %243 = or i1 %242, %241
  br i1 %243, label %249, label %219

244:                                              ; preds = %232
  %245 = getelementptr inbounds nuw i8, ptr %0, i32 %216
  %246 = load i8, ptr %245, align 1, !tbaa !2
  %247 = icmp eq i8 %246, 34
  %248 = zext i1 %247 to i32
  br label %249

249:                                              ; preds = %244, %240, %238, %232, %229, %227, %224, %222, %219, %215
  %250 = phi i32 [ 0, %232 ], [ %248, %244 ], [ %239, %238 ], [ 0, %227 ], [ 0, %222 ], [ 0, %215 ], [ 0, %240 ], [ 0, %219 ], [ 0, %224 ], [ 0, %229 ]
  %251 = icmp ult i32 %109, %149
  br i1 %251, label %272, label %282

252:                                              ; preds = %272
  %253 = add nuw i32 %109, 2
  %254 = icmp ugt i32 %253, %149
  br i1 %254, label %282, label %255

255:                                              ; preds = %252
  %256 = getelementptr inbounds nuw i8, ptr %0, i32 %253
  %257 = load i8, ptr %256, align 1, !tbaa !2
  switch i8 %257, label %282 [
    i8 92, label %275
    i8 101, label %258
  ]

258:                                              ; preds = %255
  %259 = add nuw i32 %109, 3
  %260 = icmp ugt i32 %259, %149
  br i1 %260, label %282, label %261

261:                                              ; preds = %258
  %262 = getelementptr inbounds nuw i8, ptr %0, i32 %259
  %263 = load i8, ptr %262, align 1, !tbaa !2
  switch i8 %263, label %282 [
    i8 92, label %275
    i8 120, label %264
  ]

264:                                              ; preds = %261
  %265 = add nuw i32 %109, 4
  %266 = icmp ugt i32 %265, %149
  br i1 %266, label %282, label %267

267:                                              ; preds = %264
  %268 = getelementptr inbounds nuw i8, ptr %0, i32 %265
  %269 = load i8, ptr %268, align 1, !tbaa !2
  switch i8 %269, label %282 [
    i8 92, label %275
    i8 116, label %270
  ]

270:                                              ; preds = %267
  %271 = icmp ugt i32 %216, %149
  br i1 %271, label %282, label %278

272:                                              ; preds = %249
  %273 = getelementptr inbounds nuw i8, ptr %0, i32 %121
  %274 = load i8, ptr %273, align 1, !tbaa !2
  switch i8 %274, label %282 [
    i8 92, label %275
    i8 116, label %252
  ]

275:                                              ; preds = %272, %267, %261, %255
  %276 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %109, i32 noundef %209, ptr noundef nonnull @.str.10, i32 noundef 4)
  %277 = icmp ne i32 %276, 0
  br label %282

278:                                              ; preds = %270
  %279 = getelementptr inbounds nuw i8, ptr %0, i32 %216
  %280 = load i8, ptr %279, align 1, !tbaa !2
  %281 = icmp eq i8 %280, 34
  br label %282

282:                                              ; preds = %278, %275, %272, %270, %267, %264, %261, %258, %255, %252, %249, %213
  %283 = phi i32 [ %250, %270 ], [ %250, %278 ], [ 0, %213 ], [ %250, %275 ], [ %250, %264 ], [ %250, %258 ], [ %250, %252 ], [ %250, %249 ], [ %250, %255 ], [ %250, %261 ], [ %250, %267 ], [ %250, %272 ]
  %284 = phi i1 [ false, %270 ], [ %281, %278 ], [ false, %213 ], [ %277, %275 ], [ false, %264 ], [ false, %258 ], [ false, %252 ], [ false, %249 ], [ false, %255 ], [ false, %261 ], [ false, %267 ], [ false, %272 ]
  %285 = icmp ne i32 %283, 0
  %286 = select i1 %285, i1 true, i1 %284
  br i1 %286, label %287, label %411

287:                                              ; preds = %282
  %288 = icmp ult i32 %209, %3
  br i1 %288, label %289, label %296

289:                                              ; preds = %287, %293
  %290 = phi i32 [ %294, %293 ], [ %209, %287 ]
  %291 = getelementptr inbounds nuw i8, ptr %0, i32 %290
  %292 = load i8, ptr %291, align 1, !tbaa !2
  switch i8 %292, label %296 [
    i8 32, label %293
    i8 13, label %293
    i8 10, label %293
    i8 9, label %293
  ]

293:                                              ; preds = %289, %289, %289, %289
  %294 = add i32 %290, 1
  %295 = icmp eq i32 %294, %3
  br i1 %295, label %411, label %289, !llvm.loop !35

296:                                              ; preds = %289, %287
  %297 = phi i32 [ %209, %287 ], [ %290, %289 ]
  %298 = icmp ult i32 %297, %3
  br i1 %298, label %299, label %411

299:                                              ; preds = %296
  %300 = getelementptr inbounds nuw i8, ptr %0, i32 %297
  %301 = load i8, ptr %300, align 1, !tbaa !2
  %302 = icmp eq i8 %301, 58
  br i1 %302, label %303, label %411

303:                                              ; preds = %299
  %304 = add nuw i32 %297, 1
  %305 = icmp ult i32 %304, %3
  br i1 %305, label %306, label %313

306:                                              ; preds = %303, %310
  %307 = phi i32 [ %311, %310 ], [ %304, %303 ]
  %308 = getelementptr inbounds nuw i8, ptr %0, i32 %307
  %309 = load i8, ptr %308, align 1, !tbaa !2
  switch i8 %309, label %313 [
    i8 32, label %310
    i8 13, label %310
    i8 10, label %310
    i8 9, label %310
  ]

310:                                              ; preds = %306, %306, %306, %306
  %311 = add i32 %307, 1
  %312 = icmp eq i32 %311, %3
  br i1 %312, label %313, label %306, !llvm.loop !35

313:                                              ; preds = %310, %306, %303
  %314 = phi i32 [ %304, %303 ], [ %307, %306 ], [ %3, %310 ]
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %8) #28
  store i32 0, ptr %8, align 4, !tbaa !5
  %315 = call fastcc i32 @parse_value_span(ptr noundef nonnull %0, i32 noundef %3, i32 noundef %314, ptr noundef %8)
  %316 = icmp eq i32 %315, 0
  br i1 %316, label %410, label %317

317:                                              ; preds = %313
  %318 = load i32, ptr %8, align 4, !tbaa !5
  %319 = icmp ult i32 %314, %318
  br i1 %285, label %320, label %360

320:                                              ; preds = %317
  br i1 %319, label %321, label %369

321:                                              ; preds = %320
  %322 = getelementptr inbounds nuw i8, ptr %0, i32 %314
  %323 = load i8, ptr %322, align 1, !tbaa !2
  %324 = icmp eq i8 %323, 34
  br i1 %324, label %325, label %369

325:                                              ; preds = %321
  %326 = add i32 %314, 5
  %327 = xor i32 %314, -1
  %328 = add i32 %318, %327
  %329 = icmp eq i32 %328, 0
  br i1 %329, label %369, label %345

330:                                              ; preds = %351
  %331 = getelementptr i8, ptr %106, i32 %314
  %332 = load i8, ptr %331, align 1, !tbaa !2
  switch i8 %332, label %369 [
    i8 92, label %349
    i8 101, label %333
  ]

333:                                              ; preds = %330
  %334 = icmp eq i32 %328, 2
  br i1 %334, label %369, label %335

335:                                              ; preds = %333
  %336 = getelementptr i8, ptr %103, i32 %314
  %337 = load i8, ptr %336, align 1, !tbaa !2
  switch i8 %337, label %369 [
    i8 92, label %349
    i8 120, label %338
  ]

338:                                              ; preds = %335
  %339 = icmp eq i32 %328, 3
  br i1 %339, label %369, label %340

340:                                              ; preds = %338
  %341 = getelementptr i8, ptr %104, i32 %314
  %342 = load i8, ptr %341, align 1, !tbaa !2
  switch i8 %342, label %369 [
    i8 92, label %349
    i8 116, label %343
  ]

343:                                              ; preds = %340
  %344 = icmp ult i32 %326, %318
  br i1 %344, label %355, label %369

345:                                              ; preds = %325
  %346 = getelementptr i8, ptr %107, i32 %314
  %347 = load i8, ptr %346, align 1, !tbaa !2
  %348 = icmp eq i8 %347, 92
  br i1 %348, label %349, label %351

349:                                              ; preds = %345, %340, %335, %330
  %350 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %314, i32 noundef %318, ptr noundef nonnull @.str.10, i32 noundef 4)
  br label %369

351:                                              ; preds = %345
  %352 = icmp ne i8 %347, 116
  %353 = icmp eq i32 %328, 1
  %354 = or i1 %353, %352
  br i1 %354, label %369, label %330

355:                                              ; preds = %343
  %356 = getelementptr inbounds nuw i8, ptr %0, i32 %326
  %357 = load i8, ptr %356, align 1, !tbaa !2
  %358 = icmp eq i8 %357, 34
  %359 = zext i1 %358 to i32
  br label %369

360:                                              ; preds = %317
  br i1 %319, label %361, label %366

361:                                              ; preds = %360
  %362 = getelementptr inbounds nuw i8, ptr %0, i32 %314
  %363 = load i8, ptr %362, align 1, !tbaa !2
  %364 = icmp eq i8 %363, 34
  %365 = zext i1 %364 to i32
  br label %366

366:                                              ; preds = %361, %360
  %367 = phi i32 [ 0, %360 ], [ %365, %361 ]
  %368 = sub i32 %318, %314
  br label %369

369:                                              ; preds = %366, %355, %351, %349, %343, %340, %338, %335, %333, %330, %325, %321, %320
  %370 = phi i32 [ %113, %366 ], [ 0, %321 ], [ 0, %320 ], [ 0, %343 ], [ %359, %355 ], [ %350, %349 ], [ 0, %338 ], [ 0, %333 ], [ 0, %351 ], [ 0, %325 ], [ 0, %330 ], [ 0, %335 ], [ 0, %340 ]
  %371 = phi i32 [ %367, %366 ], [ %112, %321 ], [ %112, %320 ], [ %112, %343 ], [ %112, %355 ], [ %112, %349 ], [ %112, %338 ], [ %112, %333 ], [ %112, %351 ], [ %112, %325 ], [ %112, %330 ], [ %112, %335 ], [ %112, %340 ]
  %372 = phi i32 [ %314, %366 ], [ %111, %321 ], [ %111, %320 ], [ %111, %343 ], [ %111, %355 ], [ %111, %349 ], [ %111, %338 ], [ %111, %333 ], [ %111, %351 ], [ %111, %325 ], [ %111, %330 ], [ %111, %335 ], [ %111, %340 ]
  %373 = phi i32 [ %368, %366 ], [ %110, %321 ], [ %110, %320 ], [ %110, %343 ], [ %110, %355 ], [ %110, %349 ], [ %110, %338 ], [ %110, %333 ], [ %110, %351 ], [ %110, %325 ], [ %110, %330 ], [ %110, %335 ], [ %110, %340 ]
  %374 = icmp ult i32 %318, %3
  br i1 %374, label %375, label %382

375:                                              ; preds = %369, %379
  %376 = phi i32 [ %380, %379 ], [ %318, %369 ]
  %377 = getelementptr inbounds nuw i8, ptr %0, i32 %376
  %378 = load i8, ptr %377, align 1, !tbaa !2
  switch i8 %378, label %382 [
    i8 32, label %379
    i8 13, label %379
    i8 10, label %379
    i8 9, label %379
  ]

379:                                              ; preds = %375, %375, %375, %375
  %380 = add i32 %376, 1
  %381 = icmp eq i32 %380, %3
  br i1 %381, label %410, label %375, !llvm.loop !35

382:                                              ; preds = %375, %369
  %383 = phi i32 [ %318, %369 ], [ %376, %375 ]
  %384 = icmp ult i32 %383, %3
  br i1 %384, label %385, label %410

385:                                              ; preds = %382
  %386 = getelementptr inbounds nuw i8, ptr %0, i32 %383
  %387 = load i8, ptr %386, align 1, !tbaa !2
  switch i8 %387, label %410 [
    i8 44, label %388
    i8 125, label %398
  ]

388:                                              ; preds = %385
  %389 = add nuw i32 %383, 1
  %390 = icmp ult i32 %389, %3
  br i1 %390, label %391, label %398

391:                                              ; preds = %388, %395
  %392 = phi i32 [ %396, %395 ], [ %389, %388 ]
  %393 = getelementptr inbounds nuw i8, ptr %0, i32 %392
  %394 = load i8, ptr %393, align 1, !tbaa !2
  switch i8 %394, label %398 [
    i8 32, label %395
    i8 13, label %395
    i8 10, label %395
    i8 9, label %395
  ]

395:                                              ; preds = %391, %391, %391, %391
  %396 = add i32 %392, 1
  %397 = icmp eq i32 %396, %3
  br i1 %397, label %410, label %391, !llvm.loop !35

398:                                              ; preds = %391, %388, %385
  %399 = phi i32 [ %389, %388 ], [ %383, %385 ], [ %392, %391 ]
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %8) #28
  %400 = icmp ult i32 %399, %3
  br i1 %400, label %108, label %411, !llvm.loop !140

401:                                              ; preds = %116
  %402 = load i32, ptr %6, align 4, !tbaa !5
  %403 = add i32 %402, %110
  %404 = icmp ult i32 %403, %402
  %405 = icmp ugt i32 %403, %5
  %406 = or i1 %404, %405
  br i1 %406, label %420, label %407

407:                                              ; preds = %401
  %408 = getelementptr inbounds nuw i8, ptr %0, i32 %111
  %409 = getelementptr inbounds nuw i8, ptr %4, i32 %402
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %409, ptr readonly align 1 %408, i32 %110, i1 false)
  store i32 %403, ptr %6, align 4, !tbaa !5
  br label %420

410:                                              ; preds = %313, %382, %385, %379, %395
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %8) #28
  br label %411

411:                                              ; preds = %96, %398, %282, %299, %296, %108, %120, %148, %210, %158, %205, %161, %155, %167, %176, %185, %194, %293, %410, %99, %116, %87, %11
  %412 = sub i32 %3, %2
  %413 = load i32, ptr %6, align 4, !tbaa !5
  %414 = add i32 %413, %412
  %415 = icmp ult i32 %414, %413
  %416 = icmp ugt i32 %414, %5
  %417 = or i1 %415, %416
  br i1 %417, label %420, label %418

418:                                              ; preds = %411
  %419 = getelementptr inbounds nuw i8, ptr %4, i32 %413
  tail call void @llvm.memcpy.p0.p0.i32(ptr align 1 %419, ptr nonnull readonly align 1 %12, i32 %412, i1 false)
  store i32 %414, ptr %6, align 4, !tbaa !5
  br label %420

420:                                              ; preds = %34, %407, %401, %14, %418, %411, %83, %80, %74, %7
  %421 = phi i32 [ 0, %7 ], [ 0, %74 ], [ 1, %83 ], [ 0, %80 ], [ 1, %418 ], [ 0, %411 ], [ 0, %14 ], [ 0, %401 ], [ 1, %407 ], [ 0, %34 ]
  ret i32 %421
}

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc void @hash_content_xxh32_pair(ptr noundef readonly captures(address) %0, i32 noundef %1, ptr noundef nonnull writeonly captures(none) %2, ptr noundef nonnull writeonly captures(none) %3) unnamed_addr #19 {
  %5 = ptrtoint ptr %0 to i32
  %6 = getelementptr inbounds nuw i8, ptr %0, i32 %1
  %7 = add i32 %1, -64
  %8 = icmp ult i32 %7, 449
  br i1 %8, label %9, label %48

9:                                                ; preds = %4
  %10 = getelementptr inbounds i8, ptr %6, i32 -16
  br label %11

11:                                               ; preds = %11, %9
  %12 = phi <4 x i32> [ <i32 -1034240543, i32 606290992, i32 -1640531527, i32 8>, %9 ], [ %22, %11 ]
  %13 = phi <4 x i32> [ <i32 -1522540051, i32 117991484, i32 -2128831035, i32 -488299500>, %9 ], [ %21, %11 ]
  %14 = phi ptr [ %0, %9 ], [ %23, %11 ]
  %15 = load <4 x i32>, ptr %14, align 1, !tbaa !2
  %16 = mul <4 x i32> %15, splat (i32 -2048144777)
  %17 = add <4 x i32> %16, %13
  %18 = add <4 x i32> %16, %12
  %19 = tail call <4 x i32> @llvm.fshl.v4i32(<4 x i32> %17, <4 x i32> %17, <4 x i32> splat (i32 13))
  %20 = tail call <4 x i32> @llvm.fshl.v4i32(<4 x i32> %18, <4 x i32> %18, <4 x i32> splat (i32 13))
  %21 = mul <4 x i32> %19, splat (i32 -1640531535)
  %22 = mul <4 x i32> %20, splat (i32 -1640531535)
  %23 = getelementptr inbounds nuw i8, ptr %14, i32 16
  %24 = icmp ugt ptr %23, %10
  br i1 %24, label %25, label %11, !llvm.loop !141

25:                                               ; preds = %11
  %26 = extractelement <4 x i32> %21, i64 0
  %27 = tail call noundef i32 @llvm.fshl.i32(i32 %26, i32 %26, i32 1)
  %28 = extractelement <4 x i32> %21, i64 1
  %29 = tail call noundef i32 @llvm.fshl.i32(i32 %28, i32 %28, i32 7)
  %30 = add i32 %27, %29
  %31 = extractelement <4 x i32> %21, i64 2
  %32 = tail call noundef i32 @llvm.fshl.i32(i32 %31, i32 %31, i32 12)
  %33 = add i32 %30, %32
  %34 = extractelement <4 x i32> %21, i64 3
  %35 = tail call noundef i32 @llvm.fshl.i32(i32 %34, i32 %34, i32 18)
  %36 = add i32 %33, %35
  %37 = extractelement <4 x i32> %22, i64 0
  %38 = tail call noundef i32 @llvm.fshl.i32(i32 %37, i32 %37, i32 1)
  %39 = extractelement <4 x i32> %22, i64 1
  %40 = tail call noundef i32 @llvm.fshl.i32(i32 %39, i32 %39, i32 7)
  %41 = add i32 %38, %40
  %42 = extractelement <4 x i32> %22, i64 2
  %43 = tail call noundef i32 @llvm.fshl.i32(i32 %42, i32 %42, i32 12)
  %44 = add i32 %41, %43
  %45 = extractelement <4 x i32> %22, i64 3
  %46 = tail call noundef i32 @llvm.fshl.i32(i32 %45, i32 %45, i32 18)
  %47 = add i32 %44, %46
  br label %114

48:                                               ; preds = %4
  %49 = icmp ugt i32 %1, 15
  br i1 %49, label %50, label %114

50:                                               ; preds = %48
  %51 = getelementptr inbounds i8, ptr %6, i32 -16
  br label %52

52:                                               ; preds = %52, %50
  %53 = phi i32 [ -1522540051, %50 ], [ %67, %52 ]
  %54 = phi i32 [ 117991484, %50 ], [ %76, %52 ]
  %55 = phi i32 [ -2128831035, %50 ], [ %85, %52 ]
  %56 = phi i32 [ -488299500, %50 ], [ %94, %52 ]
  %57 = phi i32 [ -1034240543, %50 ], [ %70, %52 ]
  %58 = phi i32 [ 606290992, %50 ], [ %79, %52 ]
  %59 = phi i32 [ -1640531527, %50 ], [ %88, %52 ]
  %60 = phi i32 [ 8, %50 ], [ %97, %52 ]
  %61 = phi ptr [ %0, %50 ], [ %90, %52 ]
  %62 = load i32, ptr %61, align 1
  %63 = getelementptr inbounds nuw i8, ptr %61, i32 4
  %64 = mul i32 %62, -2048144777
  %65 = add i32 %64, %53
  %66 = tail call noundef i32 @llvm.fshl.i32(i32 %65, i32 %65, i32 13)
  %67 = mul i32 %66, -1640531535
  %68 = add i32 %64, %57
  %69 = tail call noundef i32 @llvm.fshl.i32(i32 %68, i32 %68, i32 13)
  %70 = mul i32 %69, -1640531535
  %71 = load i32, ptr %63, align 1
  %72 = getelementptr inbounds nuw i8, ptr %61, i32 8
  %73 = mul i32 %71, -2048144777
  %74 = add i32 %73, %54
  %75 = tail call noundef i32 @llvm.fshl.i32(i32 %74, i32 %74, i32 13)
  %76 = mul i32 %75, -1640531535
  %77 = add i32 %73, %58
  %78 = tail call noundef i32 @llvm.fshl.i32(i32 %77, i32 %77, i32 13)
  %79 = mul i32 %78, -1640531535
  %80 = load i32, ptr %72, align 1
  %81 = getelementptr inbounds nuw i8, ptr %61, i32 12
  %82 = mul i32 %80, -2048144777
  %83 = add i32 %82, %55
  %84 = tail call noundef i32 @llvm.fshl.i32(i32 %83, i32 %83, i32 13)
  %85 = mul i32 %84, -1640531535
  %86 = add i32 %82, %59
  %87 = tail call noundef i32 @llvm.fshl.i32(i32 %86, i32 %86, i32 13)
  %88 = mul i32 %87, -1640531535
  %89 = load i32, ptr %81, align 1
  %90 = getelementptr inbounds nuw i8, ptr %61, i32 16
  %91 = mul i32 %89, -2048144777
  %92 = add i32 %91, %56
  %93 = tail call noundef i32 @llvm.fshl.i32(i32 %92, i32 %92, i32 13)
  %94 = mul i32 %93, -1640531535
  %95 = add i32 %91, %60
  %96 = tail call noundef i32 @llvm.fshl.i32(i32 %95, i32 %95, i32 13)
  %97 = mul i32 %96, -1640531535
  %98 = icmp ugt ptr %90, %51
  br i1 %98, label %99, label %52, !llvm.loop !142

99:                                               ; preds = %52
  %100 = tail call noundef i32 @llvm.fshl.i32(i32 %67, i32 %67, i32 1)
  %101 = tail call noundef i32 @llvm.fshl.i32(i32 %76, i32 %76, i32 7)
  %102 = add i32 %101, %100
  %103 = tail call noundef i32 @llvm.fshl.i32(i32 %85, i32 %85, i32 12)
  %104 = add i32 %102, %103
  %105 = tail call noundef i32 @llvm.fshl.i32(i32 %94, i32 %94, i32 18)
  %106 = add i32 %104, %105
  %107 = tail call noundef i32 @llvm.fshl.i32(i32 %70, i32 %70, i32 1)
  %108 = tail call noundef i32 @llvm.fshl.i32(i32 %79, i32 %79, i32 7)
  %109 = add i32 %108, %107
  %110 = tail call noundef i32 @llvm.fshl.i32(i32 %88, i32 %88, i32 12)
  %111 = add i32 %109, %110
  %112 = tail call noundef i32 @llvm.fshl.i32(i32 %97, i32 %97, i32 18)
  %113 = add i32 %111, %112
  br label %114

114:                                              ; preds = %48, %99, %25
  %115 = phi i32 [ %47, %25 ], [ %113, %99 ], [ -1265770134, %48 ]
  %116 = phi i32 [ %36, %25 ], [ %106, %99 ], [ -1754069642, %48 ]
  %117 = phi ptr [ %23, %25 ], [ %90, %99 ], [ %0, %48 ]
  %118 = add i32 %116, %1
  %119 = add i32 %115, %1
  %120 = getelementptr inbounds nuw i8, ptr %117, i32 4
  %121 = icmp ugt ptr %120, %6
  br i1 %121, label %122, label %153

122:                                              ; preds = %153, %114
  %123 = phi i32 [ %119, %114 ], [ %165, %153 ]
  %124 = phi i32 [ %118, %114 ], [ %162, %153 ]
  %125 = phi ptr [ %117, %114 ], [ %154, %153 ]
  %126 = icmp ult ptr %125, %6
  br i1 %126, label %127, label %193

127:                                              ; preds = %122
  %128 = ptrtoint ptr %125 to i32
  %129 = add i32 %1, %5
  %130 = sub i32 %129, %128
  %131 = getelementptr i8, ptr %125, i32 %130
  %132 = add i32 %128, 1
  %133 = and i32 %130, 1
  %134 = icmp eq i32 %133, 0
  br i1 %134, label %146, label %135

135:                                              ; preds = %127
  %136 = load i8, ptr %125, align 1, !tbaa !2
  %137 = zext i8 %136 to i32
  %138 = mul i32 %137, 374761393
  %139 = add i32 %138, %124
  %140 = tail call noundef i32 @llvm.fshl.i32(i32 %139, i32 %139, i32 11)
  %141 = mul i32 %140, -1640531535
  %142 = add i32 %138, %123
  %143 = tail call noundef i32 @llvm.fshl.i32(i32 %142, i32 %142, i32 11)
  %144 = mul i32 %143, -1640531535
  %145 = getelementptr inbounds nuw i8, ptr %125, i32 1
  br label %146

146:                                              ; preds = %135, %127
  %147 = phi i32 [ poison, %127 ], [ %141, %135 ]
  %148 = phi i32 [ poison, %127 ], [ %144, %135 ]
  %149 = phi ptr [ %125, %127 ], [ %145, %135 ]
  %150 = phi i32 [ %124, %127 ], [ %141, %135 ]
  %151 = phi i32 [ %123, %127 ], [ %144, %135 ]
  %152 = icmp eq i32 %129, %132
  br i1 %152, label %193, label %168

153:                                              ; preds = %114, %153
  %154 = phi ptr [ %166, %153 ], [ %120, %114 ]
  %155 = phi ptr [ %154, %153 ], [ %117, %114 ]
  %156 = phi i32 [ %162, %153 ], [ %118, %114 ]
  %157 = phi i32 [ %165, %153 ], [ %119, %114 ]
  %158 = load i32, ptr %155, align 1
  %159 = mul i32 %158, -1028477379
  %160 = add i32 %159, %156
  %161 = tail call noundef i32 @llvm.fshl.i32(i32 %160, i32 %160, i32 17)
  %162 = mul i32 %161, 668265263
  %163 = add i32 %159, %157
  %164 = tail call noundef i32 @llvm.fshl.i32(i32 %163, i32 %163, i32 17)
  %165 = mul i32 %164, 668265263
  %166 = getelementptr inbounds nuw i8, ptr %154, i32 4
  %167 = icmp ugt ptr %166, %6
  br i1 %167, label %122, label %153, !llvm.loop !143

168:                                              ; preds = %146, %168
  %169 = phi ptr [ %191, %168 ], [ %149, %146 ]
  %170 = phi i32 [ %187, %168 ], [ %150, %146 ]
  %171 = phi i32 [ %190, %168 ], [ %151, %146 ]
  %172 = load i8, ptr %169, align 1, !tbaa !2
  %173 = zext i8 %172 to i32
  %174 = mul i32 %173, 374761393
  %175 = add i32 %174, %170
  %176 = tail call noundef i32 @llvm.fshl.i32(i32 %175, i32 %175, i32 11)
  %177 = mul i32 %176, -1640531535
  %178 = add i32 %174, %171
  %179 = tail call noundef i32 @llvm.fshl.i32(i32 %178, i32 %178, i32 11)
  %180 = mul i32 %179, -1640531535
  %181 = getelementptr inbounds nuw i8, ptr %169, i32 1
  %182 = load i8, ptr %181, align 1, !tbaa !2
  %183 = zext i8 %182 to i32
  %184 = mul i32 %183, 374761393
  %185 = add i32 %184, %177
  %186 = tail call noundef i32 @llvm.fshl.i32(i32 %185, i32 %185, i32 11)
  %187 = mul i32 %186, -1640531535
  %188 = add i32 %184, %180
  %189 = tail call noundef i32 @llvm.fshl.i32(i32 %188, i32 %188, i32 11)
  %190 = mul i32 %189, -1640531535
  %191 = getelementptr inbounds nuw i8, ptr %169, i32 2
  %192 = icmp eq ptr %191, %131
  br i1 %192, label %193, label %168, !llvm.loop !144

193:                                              ; preds = %146, %168, %122
  %194 = phi i32 [ %123, %122 ], [ %148, %146 ], [ %190, %168 ]
  %195 = phi i32 [ %124, %122 ], [ %147, %146 ], [ %187, %168 ]
  %196 = lshr i32 %195, 15
  %197 = xor i32 %196, %195
  %198 = mul i32 %197, -2048144777
  %199 = lshr i32 %198, 13
  %200 = xor i32 %199, %198
  %201 = mul i32 %200, -1028477379
  %202 = lshr i32 %201, 16
  %203 = xor i32 %202, %201
  store i32 %203, ptr %2, align 4, !tbaa !5
  %204 = lshr i32 %194, 15
  %205 = xor i32 %204, %194
  %206 = mul i32 %205, -2048144777
  %207 = lshr i32 %206, 13
  %208 = xor i32 %207, %206
  %209 = mul i32 %208, -1028477379
  %210 = lshr i32 %209, 16
  %211 = xor i32 %210, %209
  store i32 %211, ptr %3, align 4, !tbaa !5
  ret void
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.wasm.anytrue.v16i8(<16 x i8>) #22

; Function Attrs: nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc range(i32 0, 2) i32 @reuse_validated_glossary(ptr noundef readonly captures(none) %0, i32 noundef %1, i32 noundef %2, ptr noundef readonly captures(none) %3, i32 noundef %4, ptr noundef writeonly captures(none) %5, ptr noundef nonnull writeonly captures(none) %6, ptr noundef nonnull writeonly captures(none) %7, i32 noundef range(i32 0, 5) %8) unnamed_addr #19 {
  %10 = icmp ult i32 %2, %1
  br i1 %10, label %11, label %136

11:                                               ; preds = %9
  %12 = getelementptr i8, ptr %0, i32 %2
  %13 = load i8, ptr %12, align 1, !tbaa !2
  switch i8 %13, label %136 [
    i8 91, label %14
    i8 123, label %14
  ]

14:                                               ; preds = %11, %11
  %15 = tail call i32 @llvm.usub.sat.i32(i32 %4, i32 %8)
  %16 = icmp ugt i32 %4, %15
  br i1 %16, label %17, label %136

17:                                               ; preds = %14
  %18 = sub i32 %1, %2
  br label %21

19:                                               ; preds = %47, %54, %69, %76, %87, %109, %119, %21, %31
  %20 = icmp ugt i32 %23, %15
  br i1 %20, label %21, label %136

21:                                               ; preds = %17, %19
  %22 = phi i32 [ %4, %17 ], [ %23, %19 ]
  %23 = add i32 %22, -1
  %24 = getelementptr inbounds nuw %struct.TermRowMeta, ptr %3, i32 %23
  %25 = getelementptr inbounds nuw i8, ptr %24, i32 40
  %26 = load i32, ptr %25, align 4, !tbaa !29
  %27 = getelementptr inbounds nuw i8, ptr %24, i32 36
  %28 = load i32, ptr %27, align 4, !tbaa !27
  %29 = add i32 %26, -1
  %30 = icmp ult i32 %29, %18
  br i1 %30, label %31, label %19, !llvm.loop !145

31:                                               ; preds = %21
  %32 = getelementptr i8, ptr %0, i32 %28
  %33 = load i8, ptr %32, align 1, !tbaa !2
  %34 = icmp eq i8 %13, %33
  br i1 %34, label %35, label %19, !llvm.loop !145

35:                                               ; preds = %31
  %36 = tail call i32 @llvm.umin.i32(i32 %26, i32 8)
  %37 = add i32 %26, %2
  %38 = sub i32 %37, %36
  %39 = add i32 %28, %26
  %40 = sub i32 %39, %36
  %41 = getelementptr i8, ptr %0, i32 %38
  %42 = getelementptr i8, ptr %0, i32 %40
  %43 = and i32 %36, 8
  %44 = icmp ugt i32 %26, 7
  br i1 %44, label %47, label %45

45:                                               ; preds = %47, %35
  %46 = icmp eq i32 %43, %36
  br i1 %46, label %61, label %54

47:                                               ; preds = %35
  %48 = load i64, ptr %41, align 1
  %49 = load i64, ptr %42, align 1
  %50 = icmp eq i64 %48, %49
  br i1 %50, label %45, label %19, !llvm.loop !80

51:                                               ; preds = %54
  %52 = add nuw nsw i32 %55, 1
  %53 = icmp eq i32 %52, %36
  br i1 %53, label %61, label %54, !llvm.loop !81

54:                                               ; preds = %45, %51
  %55 = phi i32 [ %52, %51 ], [ %43, %45 ]
  %56 = getelementptr i8, ptr %41, i32 %55
  %57 = load i8, ptr %56, align 1, !tbaa !2
  %58 = getelementptr i8, ptr %42, i32 %55
  %59 = load i8, ptr %58, align 1, !tbaa !2
  %60 = icmp eq i8 %57, %59
  br i1 %60, label %51, label %19

61:                                               ; preds = %51, %45
  %62 = sub i32 %26, %36
  %63 = lshr i32 %62, 1
  %64 = getelementptr i8, ptr %12, i32 %63
  %65 = getelementptr i8, ptr %32, i32 %63
  %66 = icmp ugt i32 %26, 7
  br i1 %66, label %69, label %67

67:                                               ; preds = %69, %61
  br i1 %46, label %68, label %76

68:                                               ; preds = %73, %67
  br label %83

69:                                               ; preds = %61
  %70 = load i64, ptr %64, align 1
  %71 = load i64, ptr %65, align 1
  %72 = icmp eq i64 %70, %71
  br i1 %72, label %67, label %19, !llvm.loop !80

73:                                               ; preds = %76
  %74 = add nuw nsw i32 %77, 1
  %75 = icmp eq i32 %74, %36
  br i1 %75, label %68, label %76, !llvm.loop !81

76:                                               ; preds = %67, %73
  %77 = phi i32 [ %74, %73 ], [ %43, %67 ]
  %78 = getelementptr i8, ptr %64, i32 %77
  %79 = load i8, ptr %78, align 1, !tbaa !2
  %80 = getelementptr i8, ptr %65, i32 %77
  %81 = load i8, ptr %80, align 1, !tbaa !2
  %82 = icmp eq i8 %79, %81
  br i1 %82, label %73, label %19

83:                                               ; preds = %68, %87
  %84 = phi i32 [ %102, %87 ], [ 0, %68 ]
  %85 = sub nuw i32 %26, %84
  %86 = icmp ugt i32 %85, 31
  br i1 %86, label %87, label %103

87:                                               ; preds = %83
  %88 = getelementptr inbounds nuw i8, ptr %12, i32 %84
  %89 = getelementptr inbounds nuw i8, ptr %32, i32 %84
  %90 = load <4 x i32>, ptr %88, align 1, !tbaa !2
  %91 = load <4 x i32>, ptr %89, align 1, !tbaa !2
  %92 = xor <4 x i32> %91, %90
  %93 = getelementptr inbounds nuw i8, ptr %88, i32 16
  %94 = load <4 x i32>, ptr %93, align 1, !tbaa !2
  %95 = getelementptr inbounds nuw i8, ptr %89, i32 16
  %96 = load <4 x i32>, ptr %95, align 1, !tbaa !2
  %97 = xor <4 x i32> %96, %94
  %98 = or <4 x i32> %97, %92
  %99 = bitcast <4 x i32> %98 to <16 x i8>
  %100 = tail call i32 @llvm.wasm.anytrue.v16i8(<16 x i8> %99)
  %101 = icmp eq i32 %100, 0
  %102 = add i32 %84, 32
  br i1 %101, label %83, label %19, !llvm.loop !79

103:                                              ; preds = %83, %109
  %104 = phi i32 [ %115, %109 ], [ %84, %83 ]
  %105 = sub i32 %26, %104
  %106 = icmp ugt i32 %105, 7
  br i1 %106, label %109, label %107

107:                                              ; preds = %103
  %108 = icmp ult i32 %104, %26
  br i1 %108, label %119, label %126

109:                                              ; preds = %103
  %110 = getelementptr inbounds nuw i8, ptr %12, i32 %104
  %111 = load i64, ptr %110, align 1
  %112 = getelementptr inbounds nuw i8, ptr %32, i32 %104
  %113 = load i64, ptr %112, align 1
  %114 = icmp eq i64 %111, %113
  %115 = add i32 %104, 8
  br i1 %114, label %103, label %19, !llvm.loop !80

116:                                              ; preds = %119
  %117 = add i32 %120, 1
  %118 = icmp eq i32 %117, %26
  br i1 %118, label %126, label %119, !llvm.loop !81

119:                                              ; preds = %107, %116
  %120 = phi i32 [ %117, %116 ], [ %104, %107 ]
  %121 = getelementptr i8, ptr %12, i32 %120
  %122 = load i8, ptr %121, align 1, !tbaa !2
  %123 = getelementptr i8, ptr %32, i32 %120
  %124 = load i8, ptr %123, align 1, !tbaa !2
  %125 = icmp eq i8 %122, %124
  br i1 %125, label %116, label %19

126:                                              ; preds = %107, %116
  %127 = getelementptr inbounds nuw i8, ptr %24, i32 56
  %128 = load i32, ptr %127, align 4, !tbaa !113
  %129 = getelementptr inbounds nuw i8, ptr %5, i32 56
  store i32 %128, ptr %129, align 4, !tbaa !113
  %130 = getelementptr inbounds nuw i8, ptr %24, i32 60
  %131 = load i32, ptr %130, align 4, !tbaa !63
  %132 = getelementptr inbounds nuw i8, ptr %5, i32 60
  store i32 %131, ptr %132, align 4, !tbaa !63
  %133 = getelementptr inbounds nuw i8, ptr %24, i32 64
  %134 = load i32, ptr %133, align 4, !tbaa !68
  %135 = getelementptr inbounds nuw i8, ptr %5, i32 64
  store i32 %134, ptr %135, align 4, !tbaa !68
  store i32 %37, ptr %6, align 4, !tbaa !5
  store i32 %23, ptr %7, align 4, !tbaa !5
  br label %136

136:                                              ; preds = %19, %126, %14, %9, %11
  %137 = phi i32 [ 0, %11 ], [ 0, %9 ], [ 1, %126 ], [ 0, %14 ], [ 0, %19 ]
  ret i32 %137
}

; Function Attrs: nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none)
define internal fastcc range(i32 0, 2) i32 @parse_value_span_with_glossary_hints(ptr noundef %0, i32 noundef %1, i32 noundef %2, ptr noundef nonnull writeonly captures(none) %3, ptr noundef captures(address_is_null) %4, ptr noundef captures(address_is_null) %5, ptr noundef captures(address_is_null) %6, i32 noundef range(i32 0, 2) %7) unnamed_addr #8 {
  %9 = icmp ult i32 %2, %1
  br i1 %9, label %10, label %23

10:                                               ; preds = %8
  %11 = getelementptr inbounds nuw i8, ptr %0, i32 %2
  %12 = load i8, ptr %11, align 1, !tbaa !2
  %13 = and i8 %12, -33
  %14 = icmp eq i8 %13, 91
  br i1 %14, label %15, label %21

15:                                               ; preds = %10
  %16 = icmp eq ptr %4, null
  br i1 %16, label %17, label %19

17:                                               ; preds = %15
  %18 = tail call fastcc i32 @parse_composite_span_no_media(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %2, ptr noundef %3, ptr noundef %5, ptr noundef %6, i32 noundef %7)
  br label %23

19:                                               ; preds = %15
  %20 = tail call fastcc i32 @parse_composite_span_impl(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %2, ptr noundef %3, ptr noundef nonnull %4, ptr noundef %5, ptr noundef %6, i32 noundef %7)
  br label %23

21:                                               ; preds = %10
  %22 = tail call fastcc i32 @parse_value_span(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %2, ptr noundef %3)
  br label %23

23:                                               ; preds = %17, %19, %21, %8
  %24 = phi i32 [ 0, %8 ], [ %18, %17 ], [ %20, %19 ], [ %22, %21 ]
  ret i32 %24
}

; Function Attrs: inlinehint nofree norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc range(i32 0, 2) i32 @next_format3_field(ptr noundef readonly captures(none) %0, i32 noundef %1, ptr noundef nonnull captures(none) %2) unnamed_addr #24 {
  %4 = load i32, ptr %2, align 4, !tbaa !5
  %5 = icmp ult i32 %4, %1
  br i1 %5, label %6, label %13

6:                                                ; preds = %3, %10
  %7 = phi i32 [ %11, %10 ], [ %4, %3 ]
  %8 = getelementptr inbounds nuw i8, ptr %0, i32 %7
  %9 = load i8, ptr %8, align 1, !tbaa !2
  switch i8 %9, label %13 [
    i8 32, label %10
    i8 13, label %10
    i8 10, label %10
    i8 9, label %10
  ]

10:                                               ; preds = %6, %6, %6, %6
  %11 = add i32 %7, 1
  %12 = icmp eq i32 %11, %1
  br i1 %12, label %34, label %6, !llvm.loop !35

13:                                               ; preds = %6, %3
  %14 = phi i32 [ %4, %3 ], [ %7, %6 ]
  %15 = icmp ult i32 %14, %1
  br i1 %15, label %16, label %34

16:                                               ; preds = %13
  %17 = getelementptr inbounds nuw i8, ptr %0, i32 %14
  %18 = load i8, ptr %17, align 1, !tbaa !2
  %19 = icmp eq i8 %18, 44
  br i1 %19, label %20, label %34

20:                                               ; preds = %16
  %21 = add nuw i32 %14, 1
  %22 = icmp ult i32 %21, %1
  br i1 %22, label %23, label %30

23:                                               ; preds = %20, %27
  %24 = phi i32 [ %28, %27 ], [ %21, %20 ]
  %25 = getelementptr inbounds nuw i8, ptr %0, i32 %24
  %26 = load i8, ptr %25, align 1, !tbaa !2
  switch i8 %26, label %30 [
    i8 32, label %27
    i8 13, label %27
    i8 10, label %27
    i8 9, label %27
  ]

27:                                               ; preds = %23, %23, %23, %23
  %28 = add i32 %24, 1
  %29 = icmp eq i32 %28, %1
  br i1 %29, label %34, label %23, !llvm.loop !35

30:                                               ; preds = %23, %20
  %31 = phi i32 [ %21, %20 ], [ %24, %23 ]
  %32 = icmp ult i32 %31, %1
  br i1 %32, label %33, label %34

33:                                               ; preds = %30
  store i32 %31, ptr %2, align 4, !tbaa !5
  br label %34

34:                                               ; preds = %10, %27, %30, %13, %16, %33
  %35 = phi i32 [ 1, %33 ], [ 0, %16 ], [ 0, %13 ], [ 0, %30 ], [ 0, %27 ], [ 0, %10 ]
  ret i32 %35
}

; Function Attrs: nofree noinline norecurse nosync nounwind memory(argmem: readwrite)
define internal fastcc range(i32 0, 2) i32 @parse_composite_span_no_media(ptr noundef readonly %0, i32 noundef %1, i32 noundef %2, ptr noundef nonnull writeonly captures(none) %3, ptr noundef captures(address_is_null) %4, ptr noundef captures(address_is_null) %5, i32 noundef range(i32 0, 2) %6) unnamed_addr #25 {
  %8 = alloca [256 x i8], align 16
  %9 = alloca i32, align 4
  %10 = icmp ult i32 %2, %1
  br i1 %10, label %11, label %946

11:                                               ; preds = %7
  %12 = getelementptr inbounds nuw i8, ptr %0, i32 %2
  %13 = load i8, ptr %12, align 1, !tbaa !2
  switch i8 %13, label %946 [
    i8 91, label %14
    i8 123, label %14
  ]

14:                                               ; preds = %11, %11
  call void @llvm.lifetime.start.p0(i64 256, ptr nonnull %8) #28
  %15 = icmp eq i8 %13, 91
  %16 = icmp ne i32 %6, 0
  %17 = and i1 %16, %15
  %18 = add nuw i32 %2, 1
  %19 = getelementptr i8, ptr %0, i32 1
  %20 = icmp ult i32 %18, %1
  br i1 %20, label %21, label %944

21:                                               ; preds = %14
  %22 = select i1 %15, i8 0, i8 3
  %23 = icmp eq ptr %4, null
  %24 = icmp eq ptr %5, null
  %25 = getelementptr i8, ptr %0, i32 3
  %26 = getelementptr i8, ptr %0, i32 4
  %27 = getelementptr i8, ptr %0, i32 5
  %28 = getelementptr i8, ptr %0, i32 2
  %29 = getelementptr i8, ptr %0, i32 3
  %30 = getelementptr i8, ptr %0, i32 5
  %31 = getelementptr i8, ptr %0, i32 2
  %32 = getelementptr i8, ptr %0, i32 3
  %33 = getelementptr i8, ptr %0, i32 5
  %34 = getelementptr i8, ptr %0, i32 2
  %35 = getelementptr i8, ptr %0, i32 3
  %36 = getelementptr i8, ptr %0, i32 5
  %37 = getelementptr i8, ptr %0, i32 2
  %38 = getelementptr i8, ptr %0, i32 3
  %39 = getelementptr i8, ptr %0, i32 4
  %40 = getelementptr i8, ptr %0, i32 5
  %41 = getelementptr i8, ptr %0, i32 6
  %42 = getelementptr i8, ptr %0, i32 8
  %43 = getelementptr i8, ptr %0, i32 2
  %44 = getelementptr i8, ptr %0, i32 3
  %45 = getelementptr i8, ptr %0, i32 5
  %46 = getelementptr i8, ptr %0, i32 1
  %47 = getelementptr i8, ptr %0, i32 2
  %48 = getelementptr i8, ptr %0, i32 3
  %49 = getelementptr i8, ptr %0, i32 4
  %50 = getelementptr i8, ptr %0, i32 2
  %51 = getelementptr i8, ptr %0, i32 3
  %52 = getelementptr i8, ptr %0, i32 2
  %53 = getelementptr i8, ptr %0, i32 3
  %54 = getelementptr i8, ptr %0, i32 2
  %55 = getelementptr i8, ptr %0, i32 3
  %56 = getelementptr i8, ptr %0, i32 7
  %57 = getelementptr i8, ptr %0, i32 8
  %58 = getelementptr i8, ptr %0, i32 9
  %59 = getelementptr i8, ptr %0, i32 10
  %60 = getelementptr i8, ptr %0, i32 11
  %61 = getelementptr i8, ptr %0, i32 12
  %62 = getelementptr i8, ptr %0, i32 13
  %63 = getelementptr i8, ptr %0, i32 14
  %64 = getelementptr i8, ptr %0, i32 15
  %65 = getelementptr i8, ptr %0, i32 16
  %66 = getelementptr i8, ptr %0, i32 17
  %67 = getelementptr i8, ptr %0, i32 19
  br label %68

68:                                               ; preds = %21, %936
  %69 = phi i32 [ 1, %21 ], [ %937, %936 ]
  %70 = phi i8 [ %22, %21 ], [ %938, %936 ]
  %71 = phi i32 [ 0, %21 ], [ %939, %936 ]
  %72 = phi i32 [ 0, %21 ], [ %940, %936 ]
  %73 = phi i32 [ %18, %21 ], [ %941, %936 ]
  %74 = phi i32 [ 0, %21 ], [ %942, %936 ]
  %75 = getelementptr i8, ptr %0, i32 %73
  %76 = load i8, ptr %75, align 1, !tbaa !2
  switch i8 %76, label %893 [
    i8 32, label %77
    i8 13, label %77
    i8 10, label %77
    i8 9, label %77
    i8 34, label %84
    i8 93, label %848
    i8 125, label %850
    i8 44, label %866
    i8 58, label %880
  ]

77:                                               ; preds = %68, %68, %68, %68
  br i1 %23, label %82, label %78

78:                                               ; preds = %77
  %79 = load i32, ptr %4, align 4, !tbaa !5
  %80 = icmp eq i32 %79, 0
  br i1 %80, label %81, label %82

81:                                               ; preds = %78
  store i32 1, ptr %4, align 4, !tbaa !5
  br label %82

82:                                               ; preds = %81, %78, %77
  %83 = add nuw i32 %73, 1
  br label %936, !llvm.loop !137

84:                                               ; preds = %68
  %85 = and i8 %70, -5
  %86 = icmp ne i8 %85, 3
  br i1 %86, label %112, label %87

87:                                               ; preds = %84
  %88 = sub nuw i32 %1, %73
  %89 = icmp ugt i32 %88, 8
  br i1 %89, label %90, label %99

90:                                               ; preds = %87
  %91 = load i64, ptr %75, align 1
  %92 = icmp eq i64 %91, 8389754706581218082
  %93 = trunc i64 %91 to i32
  %94 = trunc i64 %91 to i8
  br i1 %92, label %95, label %104

95:                                               ; preds = %90
  %96 = getelementptr i8, ptr %75, i32 8
  %97 = load i8, ptr %96, align 1, !tbaa !2
  %98 = icmp eq i8 %97, 34
  br i1 %98, label %207, label %112

99:                                               ; preds = %87
  %100 = icmp samesign ugt i32 %88, 4
  br i1 %100, label %101, label %112

101:                                              ; preds = %99
  %102 = load i32, ptr %75, align 1
  %103 = trunc i32 %102 to i8
  br label %104

104:                                              ; preds = %101, %90
  %105 = phi i8 [ %103, %101 ], [ %94, %90 ]
  %106 = phi i32 [ %102, %101 ], [ %93, %90 ]
  %107 = icmp eq i32 %106, 1734439970
  br i1 %107, label %108, label %112

108:                                              ; preds = %104
  %109 = getelementptr i8, ptr %75, i32 4
  %110 = load i8, ptr %109, align 1, !tbaa !2
  %111 = icmp eq i8 %110, 34
  br i1 %111, label %209, label %112

112:                                              ; preds = %84, %99, %108, %104, %95
  %113 = phi i8 [ 34, %84 ], [ 34, %99 ], [ %105, %108 ], [ %105, %104 ], [ 34, %95 ]
  %114 = add nuw i32 %73, 1
  %115 = icmp ult i32 %114, %1
  br i1 %115, label %116, label %944

116:                                              ; preds = %112, %134
  %117 = phi i32 [ %135, %134 ], [ %114, %112 ]
  %118 = add i32 %117, 8
  %119 = icmp ugt i32 %118, %1
  br i1 %119, label %141, label %120

120:                                              ; preds = %116
  %121 = getelementptr inbounds nuw i8, ptr %0, i32 %117
  %122 = load i64, ptr %121, align 1
  %123 = xor i64 %122, 2459565876494606882
  %124 = add i64 %123, -72340172838076673
  %125 = and i64 %122, -9187201950435737472
  %126 = xor i64 %125, -9187201950435737472
  %127 = xor i64 %122, 6655295901103053916
  %128 = add i64 %127, -72340172838076673
  %129 = or i64 %124, %128
  %130 = add i64 %122, -2314885530818453536
  %131 = or i64 %129, %130
  %132 = and i64 %126, %131
  %133 = icmp eq i64 %132, 0
  br i1 %133, label %134, label %136

134:                                              ; preds = %120, %203
  %135 = phi i32 [ %118, %120 ], [ %204, %203 ]
  br label %116

136:                                              ; preds = %120
  %137 = tail call range(i64 0, 65) i64 @llvm.cttz.i64(i64 %132, i1 true)
  %138 = trunc nuw nsw i64 %137 to i32
  %139 = lshr i32 %138, 3
  %140 = add i32 %139, %117
  br label %141

141:                                              ; preds = %116, %136
  %142 = phi i32 [ %140, %136 ], [ %117, %116 ]
  %143 = icmp ult i32 %142, %1
  br i1 %143, label %144, label %944

144:                                              ; preds = %141
  %145 = getelementptr inbounds nuw i8, ptr %0, i32 %142
  %146 = load i8, ptr %145, align 1, !tbaa !2
  %147 = icmp eq i8 %146, 92
  br i1 %147, label %148, label %198

148:                                              ; preds = %144
  %149 = add nuw i32 %142, 1
  %150 = icmp ult i32 %149, %1
  br i1 %150, label %151, label %944

151:                                              ; preds = %148
  %152 = getelementptr inbounds nuw i8, ptr %0, i32 %149
  %153 = load i8, ptr %152, align 1, !tbaa !2
  switch i8 %153, label %944 [
    i8 117, label %154
    i8 116, label %196
    i8 114, label %196
    i8 110, label %196
    i8 102, label %196
    i8 98, label %196
    i8 92, label %196
    i8 47, label %196
    i8 34, label %196
  ]

154:                                              ; preds = %151
  %155 = add i32 %142, 6
  %156 = icmp ugt i32 %155, %1
  br i1 %156, label %944, label %157

157:                                              ; preds = %154
  %158 = add nuw i32 %142, 2
  %159 = icmp ult i32 %158, %155
  br i1 %159, label %160, label %203

160:                                              ; preds = %157
  %161 = getelementptr inbounds nuw i8, ptr %0, i32 %158
  %162 = load i8, ptr %161, align 1, !tbaa !2
  %163 = add i8 %162, -58
  %164 = icmp ult i8 %163, -10
  %165 = and i8 %162, -33
  %166 = add i8 %165, -71
  %167 = icmp ult i8 %166, -6
  %168 = and i1 %164, %167
  br i1 %168, label %944, label %169

169:                                              ; preds = %160
  %170 = getelementptr i8, ptr %25, i32 %142
  %171 = load i8, ptr %170, align 1, !tbaa !2
  %172 = add i8 %171, -58
  %173 = icmp ult i8 %172, -10
  %174 = and i8 %171, -33
  %175 = add i8 %174, -71
  %176 = icmp ult i8 %175, -6
  %177 = and i1 %173, %176
  br i1 %177, label %944, label %178

178:                                              ; preds = %169
  %179 = getelementptr i8, ptr %26, i32 %142
  %180 = load i8, ptr %179, align 1, !tbaa !2
  %181 = add i8 %180, -58
  %182 = icmp ult i8 %181, -10
  %183 = and i8 %180, -33
  %184 = add i8 %183, -71
  %185 = icmp ult i8 %184, -6
  %186 = and i1 %182, %185
  br i1 %186, label %944, label %187

187:                                              ; preds = %178
  %188 = getelementptr i8, ptr %27, i32 %142
  %189 = load i8, ptr %188, align 1, !tbaa !2
  %190 = add i8 %189, -58
  %191 = icmp ult i8 %190, -10
  %192 = and i8 %189, -33
  %193 = add i8 %192, -71
  %194 = icmp ult i8 %193, -6
  %195 = and i1 %191, %194
  br i1 %195, label %944, label %203

196:                                              ; preds = %151, %151, %151, %151, %151, %151, %151, %151
  %197 = add nuw i32 %142, 2
  br label %203, !llvm.loop !42

198:                                              ; preds = %144
  %199 = icmp ult i8 %146, 32
  br i1 %199, label %944, label %200

200:                                              ; preds = %198
  %201 = icmp eq i8 %146, 34
  %202 = add i32 %142, 1
  br i1 %201, label %206, label %203

203:                                              ; preds = %200, %187, %157, %196
  %204 = phi i32 [ %197, %196 ], [ %155, %157 ], [ %155, %187 ], [ %202, %200 ]
  %205 = icmp ult i32 %204, %1
  br i1 %205, label %134, label %944

206:                                              ; preds = %200
  br i1 %86, label %634, label %311

207:                                              ; preds = %95
  %208 = add i32 %73, 9
  br label %304

209:                                              ; preds = %108
  %210 = add i32 %73, 5
  %211 = icmp ult i32 %210, %1
  br i1 %211, label %212, label %304

212:                                              ; preds = %209
  %213 = getelementptr inbounds nuw i8, ptr %0, i32 %210
  %214 = load i8, ptr %213, align 1, !tbaa !2
  %215 = icmp eq i8 %214, 58
  br i1 %215, label %216, label %304

216:                                              ; preds = %212
  %217 = add i32 %73, 6
  %218 = icmp ult i32 %217, %1
  br i1 %218, label %219, label %225

219:                                              ; preds = %216
  %220 = getelementptr inbounds nuw i8, ptr %0, i32 %217
  %221 = load i8, ptr %220, align 1, !tbaa !2
  %222 = icmp eq i8 %221, 32
  %223 = add i32 %73, 7
  %224 = select i1 %222, i32 %223, i32 %217
  br label %225

225:                                              ; preds = %219, %216
  %226 = phi i32 [ %217, %216 ], [ %224, %219 ]
  %227 = sub i32 %1, %226
  %228 = icmp ult i32 %227, 4
  br i1 %228, label %304, label %229

229:                                              ; preds = %225
  %230 = getelementptr inbounds nuw i8, ptr %0, i32 %226
  %231 = load i32, ptr %230, align 1
  switch i32 %231, label %304 [
    i32 1986618402, label %232
    i32 1634759458, label %243
    i32 1651864098, label %258
    i32 578056738, label %273
    i32 577533218, label %273
    i32 577334306, label %273
    i32 740450594, label %280
  ]

232:                                              ; preds = %229
  %233 = icmp ugt i32 %227, 5
  br i1 %233, label %234, label %304

234:                                              ; preds = %232
  %235 = getelementptr i8, ptr %230, i32 4
  %236 = load i8, ptr %235, align 1, !tbaa !2
  %237 = icmp eq i8 %236, 34
  br i1 %237, label %238, label %304

238:                                              ; preds = %234
  %239 = getelementptr i8, ptr %230, i32 5
  %240 = load i8, ptr %239, align 1, !tbaa !2
  %241 = icmp eq i8 %240, 44
  %242 = add i32 %226, 6
  br i1 %241, label %282, label %304

243:                                              ; preds = %229
  %244 = icmp ugt i32 %227, 6
  br i1 %244, label %245, label %304

245:                                              ; preds = %243
  %246 = getelementptr i8, ptr %230, i32 4
  %247 = load i8, ptr %246, align 1, !tbaa !2
  %248 = icmp eq i8 %247, 110
  br i1 %248, label %249, label %304

249:                                              ; preds = %245
  %250 = getelementptr i8, ptr %230, i32 5
  %251 = load i8, ptr %250, align 1, !tbaa !2
  %252 = icmp eq i8 %251, 34
  br i1 %252, label %253, label %304

253:                                              ; preds = %249
  %254 = getelementptr i8, ptr %230, i32 6
  %255 = load i8, ptr %254, align 1, !tbaa !2
  %256 = icmp eq i8 %255, 44
  %257 = add i32 %226, 7
  br i1 %256, label %282, label %304

258:                                              ; preds = %229
  %259 = icmp ugt i32 %227, 6
  br i1 %259, label %260, label %304

260:                                              ; preds = %258
  %261 = getelementptr i8, ptr %230, i32 4
  %262 = load i8, ptr %261, align 1, !tbaa !2
  %263 = icmp eq i8 %262, 121
  br i1 %263, label %264, label %304

264:                                              ; preds = %260
  %265 = getelementptr i8, ptr %230, i32 5
  %266 = load i8, ptr %265, align 1, !tbaa !2
  %267 = icmp eq i8 %266, 34
  br i1 %267, label %268, label %304

268:                                              ; preds = %264
  %269 = getelementptr i8, ptr %230, i32 6
  %270 = load i8, ptr %269, align 1, !tbaa !2
  %271 = icmp eq i8 %270, 44
  %272 = add i32 %226, 7
  br i1 %271, label %282, label %304

273:                                              ; preds = %229, %229, %229
  %274 = icmp eq i32 %227, 4
  br i1 %274, label %304, label %275

275:                                              ; preds = %273
  %276 = getelementptr i8, ptr %230, i32 4
  %277 = load i8, ptr %276, align 1, !tbaa !2
  %278 = icmp eq i8 %277, 44
  %279 = add i32 %226, 5
  br i1 %278, label %282, label %304

280:                                              ; preds = %229
  %281 = add i32 %226, 4
  br label %282

282:                                              ; preds = %275, %268, %253, %238, %280
  %283 = phi i32 [ %281, %280 ], [ %242, %238 ], [ %257, %253 ], [ %272, %268 ], [ %279, %275 ]
  %284 = icmp eq i32 %283, 0
  br i1 %284, label %304, label %285

285:                                              ; preds = %282
  br i1 %23, label %291, label %286

286:                                              ; preds = %285
  %287 = getelementptr i8, ptr %19, i32 %210
  %288 = load i8, ptr %287, align 1, !tbaa !2
  %289 = icmp eq i8 %288, 32
  br i1 %289, label %290, label %291

290:                                              ; preds = %286
  store i32 1, ptr %4, align 4, !tbaa !5
  br label %291

291:                                              ; preds = %290, %286, %285
  %292 = icmp eq i32 %69, 2
  %293 = select i1 %17, i1 %292, i1 false
  %294 = select i1 %293, i32 0, i32 %71
  %295 = icmp ult i32 %283, %1
  br i1 %295, label %296, label %936, !llvm.loop !137

296:                                              ; preds = %291
  %297 = getelementptr inbounds nuw i8, ptr %0, i32 %283
  %298 = load i8, ptr %297, align 1, !tbaa !2
  %299 = icmp eq i8 %298, 32
  br i1 %299, label %300, label %936, !llvm.loop !137

300:                                              ; preds = %296
  br i1 %23, label %302, label %301

301:                                              ; preds = %300
  store i32 1, ptr %4, align 4, !tbaa !5
  br label %302

302:                                              ; preds = %301, %300
  %303 = add nuw i32 %283, 1
  br label %936, !llvm.loop !137

304:                                              ; preds = %229, %275, %273, %268, %258, %260, %264, %253, %243, %245, %249, %238, %232, %234, %225, %209, %212, %282, %207
  %305 = phi i32 [ 4, %207 ], [ 0, %282 ], [ 0, %212 ], [ 0, %209 ], [ 0, %225 ], [ 0, %234 ], [ 0, %232 ], [ 0, %238 ], [ 0, %249 ], [ 0, %245 ], [ 0, %243 ], [ 0, %253 ], [ 0, %264 ], [ 0, %260 ], [ 0, %258 ], [ 0, %268 ], [ 0, %273 ], [ 0, %275 ], [ 0, %229 ]
  %306 = phi i1 [ true, %207 ], [ false, %282 ], [ false, %212 ], [ false, %209 ], [ false, %225 ], [ false, %234 ], [ false, %232 ], [ false, %238 ], [ false, %249 ], [ false, %245 ], [ false, %243 ], [ false, %253 ], [ false, %264 ], [ false, %260 ], [ false, %258 ], [ false, %268 ], [ false, %273 ], [ false, %275 ], [ false, %229 ]
  %307 = phi i32 [ %208, %207 ], [ %210, %282 ], [ %210, %212 ], [ %210, %209 ], [ %210, %225 ], [ %210, %234 ], [ %210, %232 ], [ %210, %238 ], [ %210, %249 ], [ %210, %245 ], [ %210, %243 ], [ %210, %253 ], [ %210, %264 ], [ %210, %260 ], [ %210, %258 ], [ %210, %268 ], [ %210, %273 ], [ %210, %275 ], [ %210, %229 ]
  %308 = icmp eq i32 %69, 2
  %309 = select i1 %17, i1 %308, i1 false
  %310 = select i1 %309, i32 %305, i32 %71
  br label %595

311:                                              ; preds = %206
  %312 = icmp eq i32 %69, 2
  %313 = select i1 %17, i1 %312, i1 false
  br i1 %313, label %314, label %471

314:                                              ; preds = %311
  %315 = icmp ule i32 %73, %142
  %316 = icmp eq i8 %113, 34
  %317 = select i1 %315, i1 %316, i1 false
  br i1 %317, label %318, label %471

318:                                              ; preds = %314
  %319 = add i32 %73, 4
  %320 = sub nuw i32 %142, %73
  %321 = icmp eq i32 %142, %73
  br i1 %321, label %352, label %337

322:                                              ; preds = %341
  %323 = getelementptr i8, ptr %28, i32 %73
  %324 = load i8, ptr %323, align 1, !tbaa !2
  switch i8 %324, label %352 [
    i8 92, label %349
    i8 121, label %325
  ]

325:                                              ; preds = %322
  %326 = icmp eq i32 %320, 2
  br i1 %326, label %352, label %327

327:                                              ; preds = %325
  %328 = getelementptr i8, ptr %29, i32 %73
  %329 = load i8, ptr %328, align 1, !tbaa !2
  switch i8 %329, label %352 [
    i8 92, label %349
    i8 112, label %330
  ]

330:                                              ; preds = %327
  %331 = icmp eq i32 %320, 3
  br i1 %331, label %352, label %332

332:                                              ; preds = %330
  %333 = getelementptr inbounds nuw i8, ptr %0, i32 %319
  %334 = load i8, ptr %333, align 1, !tbaa !2
  switch i8 %334, label %352 [
    i8 92, label %349
    i8 101, label %335
  ]

335:                                              ; preds = %332
  %336 = icmp ult i32 %319, %142
  br i1 %336, label %345, label %352

337:                                              ; preds = %318
  %338 = getelementptr inbounds nuw i8, ptr %0, i32 %114
  %339 = load i8, ptr %338, align 1, !tbaa !2
  %340 = icmp eq i8 %339, 92
  br i1 %340, label %349, label %341

341:                                              ; preds = %337
  %342 = icmp ne i8 %339, 116
  %343 = icmp eq i32 %320, 1
  %344 = or i1 %342, %343
  br i1 %344, label %352, label %322

345:                                              ; preds = %335
  %346 = getelementptr i8, ptr %30, i32 %73
  %347 = load i8, ptr %346, align 1, !tbaa !2
  %348 = icmp eq i8 %347, 34
  br i1 %348, label %471, label %352

349:                                              ; preds = %332, %327, %322, %337
  %350 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %73, i32 noundef %202, ptr noundef nonnull @.str.2, i32 noundef 4)
  %351 = icmp eq i32 %350, 0
  br i1 %351, label %352, label %471

352:                                              ; preds = %332, %327, %322, %341, %318, %325, %330, %345, %349, %335
  %353 = add i32 %73, 4
  %354 = tail call i32 @llvm.usub.sat.i32(i32 %142, i32 %73)
  %355 = icmp ugt i32 %142, %73
  br i1 %355, label %371, label %387

356:                                              ; preds = %375
  %357 = getelementptr i8, ptr %31, i32 %73
  %358 = load i8, ptr %357, align 1, !tbaa !2
  switch i8 %358, label %387 [
    i8 92, label %384
    i8 101, label %359
  ]

359:                                              ; preds = %356
  %360 = icmp eq i32 %354, 2
  br i1 %360, label %387, label %361

361:                                              ; preds = %359
  %362 = getelementptr i8, ptr %32, i32 %73
  %363 = load i8, ptr %362, align 1, !tbaa !2
  switch i8 %363, label %387 [
    i8 92, label %384
    i8 120, label %364
  ]

364:                                              ; preds = %361
  %365 = icmp eq i32 %354, 3
  br i1 %365, label %387, label %366

366:                                              ; preds = %364
  %367 = getelementptr inbounds nuw i8, ptr %0, i32 %353
  %368 = load i8, ptr %367, align 1, !tbaa !2
  switch i8 %368, label %387 [
    i8 92, label %384
    i8 116, label %369
  ]

369:                                              ; preds = %366
  %370 = icmp ult i32 %353, %142
  br i1 %370, label %379, label %387

371:                                              ; preds = %352
  %372 = getelementptr inbounds nuw i8, ptr %0, i32 %114
  %373 = load i8, ptr %372, align 1, !tbaa !2
  %374 = icmp eq i8 %373, 92
  br i1 %374, label %384, label %375

375:                                              ; preds = %371
  %376 = icmp ne i8 %373, 116
  %377 = icmp eq i32 %354, 1
  %378 = or i1 %376, %377
  br i1 %378, label %387, label %356

379:                                              ; preds = %369
  %380 = getelementptr i8, ptr %33, i32 %73
  %381 = load i8, ptr %380, align 1, !tbaa !2
  %382 = icmp eq i8 %381, 34
  %383 = zext i1 %382 to i32
  br i1 %382, label %471, label %387

384:                                              ; preds = %366, %361, %356, %371
  %385 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %73, i32 noundef %202, ptr noundef nonnull @.str.10, i32 noundef 4)
  %386 = icmp eq i32 %385, 0
  br i1 %386, label %387, label %471

387:                                              ; preds = %366, %361, %356, %375, %352, %359, %364, %379, %369, %384
  %388 = add i32 %73, 4
  %389 = tail call i32 @llvm.usub.sat.i32(i32 %142, i32 %73)
  %390 = icmp ugt i32 %142, %73
  br i1 %390, label %406, label %421

391:                                              ; preds = %410
  %392 = getelementptr i8, ptr %34, i32 %73
  %393 = load i8, ptr %392, align 1, !tbaa !2
  switch i8 %393, label %421 [
    i8 92, label %418
    i8 97, label %394
  ]

394:                                              ; preds = %391
  %395 = icmp eq i32 %389, 2
  br i1 %395, label %421, label %396

396:                                              ; preds = %394
  %397 = getelementptr i8, ptr %35, i32 %73
  %398 = load i8, ptr %397, align 1, !tbaa !2
  switch i8 %398, label %421 [
    i8 92, label %418
    i8 116, label %399
  ]

399:                                              ; preds = %396
  %400 = icmp eq i32 %389, 3
  br i1 %400, label %421, label %401

401:                                              ; preds = %399
  %402 = getelementptr inbounds nuw i8, ptr %0, i32 %388
  %403 = load i8, ptr %402, align 1, !tbaa !2
  switch i8 %403, label %421 [
    i8 92, label %418
    i8 104, label %404
  ]

404:                                              ; preds = %401
  %405 = icmp ult i32 %388, %142
  br i1 %405, label %414, label %421

406:                                              ; preds = %387
  %407 = getelementptr inbounds nuw i8, ptr %0, i32 %114
  %408 = load i8, ptr %407, align 1, !tbaa !2
  %409 = icmp eq i8 %408, 92
  br i1 %409, label %418, label %410

410:                                              ; preds = %406
  %411 = icmp ne i8 %408, 112
  %412 = icmp eq i32 %389, 1
  %413 = or i1 %411, %412
  br i1 %413, label %421, label %391

414:                                              ; preds = %404
  %415 = getelementptr i8, ptr %36, i32 %73
  %416 = load i8, ptr %415, align 1, !tbaa !2
  %417 = icmp eq i8 %416, 34
  br i1 %417, label %471, label %421

418:                                              ; preds = %401, %396, %391, %406
  %419 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %73, i32 noundef %202, ptr noundef nonnull @.str.1, i32 noundef 4)
  %420 = icmp eq i32 %419, 0
  br i1 %420, label %421, label %471

421:                                              ; preds = %401, %396, %391, %410, %387, %394, %399, %414, %418, %404
  %422 = add i32 %73, 7
  %423 = tail call i32 @llvm.usub.sat.i32(i32 %142, i32 %73)
  %424 = icmp ugt i32 %142, %73
  br i1 %424, label %457, label %471

425:                                              ; preds = %457
  %426 = icmp eq i32 %423, 1
  br i1 %426, label %471, label %427

427:                                              ; preds = %425
  %428 = getelementptr i8, ptr %37, i32 %73
  %429 = load i8, ptr %428, align 1, !tbaa !2
  switch i8 %429, label %467 [
    i8 92, label %460
    i8 111, label %430
  ]

430:                                              ; preds = %427
  %431 = icmp eq i32 %423, 2
  br i1 %431, label %471, label %432

432:                                              ; preds = %430
  %433 = getelementptr i8, ptr %38, i32 %73
  %434 = load i8, ptr %433, align 1, !tbaa !2
  switch i8 %434, label %467 [
    i8 92, label %460
    i8 110, label %435
  ]

435:                                              ; preds = %432
  %436 = icmp eq i32 %423, 3
  br i1 %436, label %471, label %437

437:                                              ; preds = %435
  %438 = getelementptr i8, ptr %39, i32 %73
  %439 = load i8, ptr %438, align 1, !tbaa !2
  switch i8 %439, label %467 [
    i8 92, label %460
    i8 116, label %440
  ]

440:                                              ; preds = %437
  %441 = icmp eq i32 %423, 4
  br i1 %441, label %471, label %442

442:                                              ; preds = %440
  %443 = getelementptr i8, ptr %40, i32 %73
  %444 = load i8, ptr %443, align 1, !tbaa !2
  switch i8 %444, label %467 [
    i8 92, label %460
    i8 101, label %445
  ]

445:                                              ; preds = %442
  %446 = icmp eq i32 %423, 5
  br i1 %446, label %471, label %447

447:                                              ; preds = %445
  %448 = getelementptr i8, ptr %41, i32 %73
  %449 = load i8, ptr %448, align 1, !tbaa !2
  switch i8 %449, label %467 [
    i8 92, label %460
    i8 110, label %450
  ]

450:                                              ; preds = %447
  %451 = icmp eq i32 %423, 6
  br i1 %451, label %471, label %452

452:                                              ; preds = %450
  %453 = getelementptr inbounds nuw i8, ptr %0, i32 %422
  %454 = load i8, ptr %453, align 1, !tbaa !2
  switch i8 %454, label %467 [
    i8 92, label %460
    i8 116, label %455
  ]

455:                                              ; preds = %452
  %456 = icmp ult i32 %422, %142
  br i1 %456, label %463, label %471

457:                                              ; preds = %421
  %458 = getelementptr inbounds nuw i8, ptr %0, i32 %114
  %459 = load i8, ptr %458, align 1, !tbaa !2
  switch i8 %459, label %467 [
    i8 92, label %460
    i8 99, label %425
  ]

460:                                              ; preds = %457, %452, %447, %442, %437, %432, %427
  %461 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %73, i32 noundef %202, ptr noundef nonnull @.str, i32 noundef 7)
  %462 = icmp eq i32 %461, 0
  br label %467

463:                                              ; preds = %455
  %464 = getelementptr i8, ptr %42, i32 %73
  %465 = load i8, ptr %464, align 1, !tbaa !2
  %466 = icmp ne i8 %465, 34
  br label %467

467:                                              ; preds = %457, %452, %447, %442, %437, %432, %427, %460, %463
  %468 = phi i1 [ %466, %463 ], [ %462, %460 ], [ true, %427 ], [ true, %432 ], [ true, %437 ], [ true, %442 ], [ true, %447 ], [ true, %452 ], [ true, %457 ]
  %469 = freeze i1 %468
  %470 = select i1 %469, i32 0, i32 4
  br label %471

471:                                              ; preds = %414, %418, %345, %349, %421, %425, %430, %435, %440, %445, %450, %379, %467, %384, %314, %455, %311
  %472 = phi i32 [ %71, %311 ], [ %385, %384 ], [ 0, %455 ], [ 0, %314 ], [ %470, %467 ], [ %383, %379 ], [ 0, %450 ], [ 0, %445 ], [ 0, %440 ], [ 0, %435 ], [ 0, %430 ], [ 0, %425 ], [ 0, %421 ], [ 8, %349 ], [ 8, %345 ], [ 2, %418 ], [ 2, %414 ]
  %473 = getelementptr i8, ptr %75, i32 1
  %474 = load i8, ptr %473, align 1, !tbaa !2
  switch i8 %474, label %595 [
    i8 116, label %475
    i8 92, label %475
  ]

475:                                              ; preds = %471, %471
  br i1 %23, label %479, label %476

476:                                              ; preds = %475
  %477 = load i32, ptr %4, align 4, !tbaa !5
  %478 = icmp eq i32 %477, 0
  br i1 %478, label %487, label %479

479:                                              ; preds = %476, %475
  br i1 %24, label %595, label %480

480:                                              ; preds = %479
  %481 = load i32, ptr %5, align 4, !tbaa !5
  %482 = icmp eq i32 %481, 0
  %483 = icmp ule i32 %73, %142
  %484 = and i1 %483, %482
  %485 = icmp eq i8 %113, 34
  %486 = select i1 %484, i1 %485, i1 false
  br i1 %486, label %491, label %595

487:                                              ; preds = %476
  %488 = icmp ule i32 %73, %142
  %489 = icmp eq i8 %113, 34
  %490 = select i1 %488, i1 %489, i1 false
  br i1 %490, label %491, label %595

491:                                              ; preds = %487, %480
  %492 = add i32 %73, 4
  %493 = tail call i32 @llvm.usub.sat.i32(i32 %142, i32 %73)
  %494 = icmp ugt i32 %142, %73
  br i1 %494, label %510, label %595

495:                                              ; preds = %512
  %496 = getelementptr i8, ptr %43, i32 %73
  %497 = load i8, ptr %496, align 1, !tbaa !2
  switch i8 %497, label %595 [
    i8 92, label %520
    i8 121, label %498
  ]

498:                                              ; preds = %495
  %499 = icmp eq i32 %493, 2
  br i1 %499, label %595, label %500

500:                                              ; preds = %498
  %501 = getelementptr i8, ptr %44, i32 %73
  %502 = load i8, ptr %501, align 1, !tbaa !2
  switch i8 %502, label %595 [
    i8 92, label %520
    i8 112, label %503
  ]

503:                                              ; preds = %500
  %504 = icmp eq i32 %493, 3
  br i1 %504, label %595, label %505

505:                                              ; preds = %503
  %506 = getelementptr inbounds nuw i8, ptr %0, i32 %492
  %507 = load i8, ptr %506, align 1, !tbaa !2
  switch i8 %507, label %595 [
    i8 92, label %520
    i8 101, label %508
  ]

508:                                              ; preds = %505
  %509 = icmp ult i32 %492, %142
  br i1 %509, label %516, label %595

510:                                              ; preds = %491
  %511 = icmp eq i8 %474, 92
  br i1 %511, label %520, label %512

512:                                              ; preds = %510
  %513 = icmp ne i8 %474, 116
  %514 = icmp eq i32 %493, 1
  %515 = or i1 %513, %514
  br i1 %515, label %595, label %495

516:                                              ; preds = %508
  %517 = getelementptr i8, ptr %45, i32 %73
  %518 = load i8, ptr %517, align 1, !tbaa !2
  %519 = icmp eq i8 %518, 34
  br i1 %519, label %523, label %595

520:                                              ; preds = %505, %500, %495, %510
  %521 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %73, i32 noundef %202, ptr noundef nonnull @.str.2, i32 noundef 4)
  %522 = icmp eq i32 %521, 0
  br i1 %522, label %595, label %523

523:                                              ; preds = %516, %520
  %524 = icmp ult i32 %202, %1
  br i1 %524, label %525, label %532

525:                                              ; preds = %523, %529
  %526 = phi i32 [ %530, %529 ], [ %202, %523 ]
  %527 = getelementptr inbounds nuw i8, ptr %0, i32 %526
  %528 = load i8, ptr %527, align 1, !tbaa !2
  switch i8 %528, label %532 [
    i8 32, label %529
    i8 13, label %529
    i8 10, label %529
    i8 9, label %529
  ]

529:                                              ; preds = %525, %525, %525, %525
  %530 = add i32 %526, 1
  %531 = icmp eq i32 %530, %1
  br i1 %531, label %595, label %525, !llvm.loop !35

532:                                              ; preds = %525, %523
  %533 = phi i32 [ %202, %523 ], [ %526, %525 ]
  %534 = icmp ult i32 %533, %1
  br i1 %534, label %535, label %595

535:                                              ; preds = %532
  %536 = getelementptr inbounds nuw i8, ptr %0, i32 %533
  %537 = load i8, ptr %536, align 1, !tbaa !2
  %538 = icmp eq i8 %537, 58
  br i1 %538, label %539, label %595

539:                                              ; preds = %535
  %540 = add nuw i32 %533, 1
  %541 = icmp ult i32 %540, %1
  br i1 %541, label %542, label %549

542:                                              ; preds = %539, %546
  %543 = phi i32 [ %547, %546 ], [ %540, %539 ]
  %544 = getelementptr inbounds nuw i8, ptr %0, i32 %543
  %545 = load i8, ptr %544, align 1, !tbaa !2
  switch i8 %545, label %549 [
    i8 32, label %546
    i8 13, label %546
    i8 10, label %546
    i8 9, label %546
  ]

546:                                              ; preds = %542, %542, %542, %542
  %547 = add i32 %543, 1
  %548 = icmp eq i32 %547, %1
  br i1 %548, label %595, label %542, !llvm.loop !35

549:                                              ; preds = %542, %539
  %550 = phi i32 [ %540, %539 ], [ %543, %542 ]
  %551 = icmp ult i32 %550, %1
  br i1 %551, label %552, label %595

552:                                              ; preds = %549
  %553 = getelementptr inbounds nuw i8, ptr %0, i32 %550
  %554 = load i8, ptr %553, align 1, !tbaa !2
  %555 = icmp eq i8 %554, 34
  br i1 %555, label %556, label %595

556:                                              ; preds = %552
  %557 = add i32 %550, 5
  %558 = xor i32 %550, -1
  %559 = add i32 %1, %558
  %560 = icmp eq i32 %559, 0
  br i1 %560, label %595, label %576

561:                                              ; preds = %580
  %562 = getelementptr i8, ptr %47, i32 %550
  %563 = load i8, ptr %562, align 1, !tbaa !2
  switch i8 %563, label %595 [
    i8 92, label %588
    i8 101, label %564
  ]

564:                                              ; preds = %561
  %565 = icmp eq i32 %559, 2
  br i1 %565, label %595, label %566

566:                                              ; preds = %564
  %567 = getelementptr i8, ptr %48, i32 %550
  %568 = load i8, ptr %567, align 1, !tbaa !2
  switch i8 %568, label %595 [
    i8 92, label %588
    i8 120, label %569
  ]

569:                                              ; preds = %566
  %570 = icmp eq i32 %559, 3
  br i1 %570, label %595, label %571

571:                                              ; preds = %569
  %572 = getelementptr i8, ptr %49, i32 %550
  %573 = load i8, ptr %572, align 1, !tbaa !2
  switch i8 %573, label %595 [
    i8 92, label %588
    i8 116, label %574
  ]

574:                                              ; preds = %571
  %575 = icmp ult i32 %557, %1
  br i1 %575, label %584, label %595

576:                                              ; preds = %556
  %577 = getelementptr i8, ptr %46, i32 %550
  %578 = load i8, ptr %577, align 1, !tbaa !2
  %579 = icmp eq i8 %578, 92
  br i1 %579, label %588, label %580

580:                                              ; preds = %576
  %581 = icmp ne i8 %578, 116
  %582 = icmp eq i32 %559, 1
  %583 = or i1 %581, %582
  br i1 %583, label %595, label %561

584:                                              ; preds = %574
  %585 = getelementptr inbounds nuw i8, ptr %0, i32 %557
  %586 = load i8, ptr %585, align 1, !tbaa !2
  %587 = icmp eq i8 %586, 34
  br i1 %587, label %591, label %595

588:                                              ; preds = %571, %566, %561, %576
  %589 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %550, i32 noundef %1, ptr noundef nonnull @.str.10, i32 noundef 4)
  %590 = icmp eq i32 %589, 0
  br i1 %590, label %595, label %591

591:                                              ; preds = %584, %588
  br i1 %23, label %593, label %592

592:                                              ; preds = %591
  store i32 1, ptr %4, align 4, !tbaa !5
  br label %593

593:                                              ; preds = %592, %591
  br i1 %24, label %595, label %594

594:                                              ; preds = %593
  store i32 1, ptr %5, align 4, !tbaa !5
  br label %595

595:                                              ; preds = %529, %546, %571, %566, %561, %505, %500, %495, %512, %491, %498, %503, %580, %556, %564, %569, %584, %516, %304, %508, %487, %574, %549, %552, %532, %535, %520, %594, %593, %588, %480, %479, %471
  %596 = phi i32 [ %472, %594 ], [ %472, %593 ], [ %472, %588 ], [ %472, %480 ], [ %472, %479 ], [ %472, %471 ], [ %472, %520 ], [ %472, %535 ], [ %472, %532 ], [ %472, %552 ], [ %472, %549 ], [ %472, %574 ], [ %472, %487 ], [ %472, %508 ], [ %310, %304 ], [ %472, %516 ], [ %472, %584 ], [ %472, %569 ], [ %472, %564 ], [ %472, %556 ], [ %472, %580 ], [ %472, %503 ], [ %472, %498 ], [ %472, %491 ], [ %472, %512 ], [ %472, %495 ], [ %472, %500 ], [ %472, %505 ], [ %472, %561 ], [ %472, %566 ], [ %472, %571 ], [ %472, %546 ], [ %472, %529 ]
  %597 = phi i32 [ %202, %594 ], [ %202, %593 ], [ %202, %588 ], [ %202, %480 ], [ %202, %479 ], [ %202, %471 ], [ %202, %520 ], [ %202, %535 ], [ %202, %532 ], [ %202, %552 ], [ %202, %549 ], [ %202, %574 ], [ %202, %487 ], [ %202, %508 ], [ %307, %304 ], [ %202, %516 ], [ %202, %584 ], [ %202, %569 ], [ %202, %564 ], [ %202, %556 ], [ %202, %580 ], [ %202, %503 ], [ %202, %498 ], [ %202, %491 ], [ %202, %512 ], [ %202, %495 ], [ %202, %500 ], [ %202, %505 ], [ %202, %561 ], [ %202, %566 ], [ %202, %571 ], [ %202, %546 ], [ %202, %529 ]
  %598 = phi i1 [ false, %594 ], [ false, %593 ], [ false, %588 ], [ false, %480 ], [ false, %479 ], [ false, %471 ], [ false, %520 ], [ false, %535 ], [ false, %532 ], [ false, %552 ], [ false, %549 ], [ false, %574 ], [ false, %487 ], [ false, %508 ], [ %306, %304 ], [ false, %516 ], [ false, %584 ], [ false, %569 ], [ false, %564 ], [ false, %556 ], [ false, %580 ], [ false, %503 ], [ false, %498 ], [ false, %491 ], [ false, %512 ], [ false, %495 ], [ false, %500 ], [ false, %505 ], [ false, %561 ], [ false, %566 ], [ false, %571 ], [ false, %546 ], [ false, %529 ]
  %599 = phi i1 [ %313, %594 ], [ %313, %593 ], [ %313, %588 ], [ %313, %480 ], [ %313, %479 ], [ %313, %471 ], [ %313, %520 ], [ %313, %535 ], [ %313, %532 ], [ %313, %552 ], [ %313, %549 ], [ %313, %574 ], [ %313, %487 ], [ %313, %508 ], [ %309, %304 ], [ %313, %516 ], [ %313, %584 ], [ %313, %569 ], [ %313, %564 ], [ %313, %556 ], [ %313, %580 ], [ %313, %503 ], [ %313, %498 ], [ %313, %491 ], [ %313, %512 ], [ %313, %495 ], [ %313, %500 ], [ %313, %505 ], [ %313, %561 ], [ %313, %566 ], [ %313, %571 ], [ %313, %546 ], [ %313, %529 ]
  %600 = icmp ult i32 %597, %1
  br i1 %600, label %601, label %824

601:                                              ; preds = %595
  %602 = getelementptr inbounds nuw i8, ptr %0, i32 %597
  %603 = load i8, ptr %602, align 1, !tbaa !2
  %604 = icmp eq i8 %603, 58
  br i1 %604, label %605, label %824

605:                                              ; preds = %601
  %606 = add nuw i32 %597, 1
  %607 = icmp ult i32 %606, %1
  br i1 %607, label %608, label %616

608:                                              ; preds = %605
  %609 = getelementptr inbounds nuw i8, ptr %0, i32 %606
  %610 = load i8, ptr %609, align 1, !tbaa !2
  %611 = icmp eq i8 %610, 32
  br i1 %611, label %612, label %616

612:                                              ; preds = %608
  br i1 %23, label %614, label %613

613:                                              ; preds = %612
  store i32 1, ptr %4, align 4, !tbaa !5
  br label %614

614:                                              ; preds = %613, %612
  %615 = add nuw i32 %597, 2
  br label %616

616:                                              ; preds = %605, %608, %614
  %617 = phi i32 [ %615, %614 ], [ %606, %608 ], [ %606, %605 ]
  %618 = icmp ult i32 %617, %1
  %619 = select i1 %598, i1 %618, i1 false
  br i1 %619, label %620, label %936, !llvm.loop !137

620:                                              ; preds = %616
  %621 = getelementptr inbounds nuw i8, ptr %0, i32 %617
  %622 = load i8, ptr %621, align 1, !tbaa !2
  switch i8 %622, label %936 [
    i8 91, label %623
    i8 123, label %623
  ], !llvm.loop !137

623:                                              ; preds = %620, %620
  %624 = icmp ugt i32 %69, 255
  br i1 %624, label %944, label %625

625:                                              ; preds = %623
  %626 = or i32 %74, 4
  %627 = select i1 %599, i32 %626, i32 %74
  %628 = add nsw i32 %69, -1
  %629 = getelementptr inbounds nuw [256 x i8], ptr %8, i32 0, i32 %628
  store i8 6, ptr %629, align 1, !tbaa !2
  %630 = add nuw nsw i32 %69, 1
  %631 = icmp eq i8 %622, 91
  %632 = select i1 %631, i8 0, i8 3
  %633 = add nuw i32 %617, 1
  br label %936, !llvm.loop !137

634:                                              ; preds = %206
  %635 = icmp eq i8 %70, 5
  br i1 %635, label %636, label %821

636:                                              ; preds = %634
  %637 = icmp eq i32 %69, 2
  %638 = select i1 %17, i1 %637, i1 false
  br i1 %638, label %639, label %824

639:                                              ; preds = %636
  %640 = icmp eq i32 %71, 8
  br i1 %640, label %641, label %819

641:                                              ; preds = %639
  %642 = icmp ugt i32 %73, %142
  br i1 %642, label %824, label %643

643:                                              ; preds = %641
  %644 = add i32 %73, 5
  %645 = add i32 %73, 4
  %646 = sub nuw i32 %142, %73
  %647 = icmp eq i32 %142, %73
  br i1 %647, label %678, label %663

648:                                              ; preds = %667
  %649 = getelementptr i8, ptr %50, i32 %73
  %650 = load i8, ptr %649, align 1, !tbaa !2
  switch i8 %650, label %678 [
    i8 92, label %675
    i8 101, label %651
  ]

651:                                              ; preds = %648
  %652 = icmp eq i32 %646, 2
  br i1 %652, label %678, label %653

653:                                              ; preds = %651
  %654 = getelementptr i8, ptr %51, i32 %73
  %655 = load i8, ptr %654, align 1, !tbaa !2
  switch i8 %655, label %678 [
    i8 92, label %675
    i8 120, label %656
  ]

656:                                              ; preds = %653
  %657 = icmp eq i32 %646, 3
  br i1 %657, label %678, label %658

658:                                              ; preds = %656
  %659 = getelementptr inbounds nuw i8, ptr %0, i32 %645
  %660 = load i8, ptr %659, align 1, !tbaa !2
  switch i8 %660, label %678 [
    i8 92, label %675
    i8 116, label %661
  ]

661:                                              ; preds = %658
  %662 = icmp ult i32 %645, %142
  br i1 %662, label %671, label %678

663:                                              ; preds = %643
  %664 = getelementptr inbounds nuw i8, ptr %0, i32 %114
  %665 = load i8, ptr %664, align 1, !tbaa !2
  %666 = icmp eq i8 %665, 92
  br i1 %666, label %675, label %667

667:                                              ; preds = %663
  %668 = icmp ne i8 %665, 116
  %669 = icmp eq i32 %646, 1
  %670 = select i1 %668, i1 true, i1 %669
  br i1 %670, label %678, label %648

671:                                              ; preds = %661
  %672 = getelementptr inbounds nuw i8, ptr %0, i32 %644
  %673 = load i8, ptr %672, align 1, !tbaa !2
  %674 = icmp eq i8 %673, 34
  br i1 %674, label %824, label %678

675:                                              ; preds = %658, %653, %648, %663
  %676 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %73, i32 noundef %202, ptr noundef nonnull @.str.10, i32 noundef 4)
  %677 = icmp eq i32 %676, 0
  br i1 %677, label %678, label %824

678:                                              ; preds = %658, %653, %648, %667, %643, %651, %656, %671, %675, %661
  %679 = add i32 %73, 6
  %680 = tail call i32 @llvm.usub.sat.i32(i32 %142, i32 %73)
  %681 = icmp ugt i32 %142, %73
  br i1 %681, label %702, label %824

682:                                              ; preds = %706
  %683 = getelementptr i8, ptr %52, i32 %73
  %684 = load i8, ptr %683, align 1, !tbaa !2
  switch i8 %684, label %804 [
    i8 92, label %714
    i8 109, label %685
  ]

685:                                              ; preds = %682
  %686 = icmp eq i32 %680, 2
  br i1 %686, label %804, label %687

687:                                              ; preds = %685
  %688 = getelementptr i8, ptr %53, i32 %73
  %689 = load i8, ptr %688, align 1, !tbaa !2
  switch i8 %689, label %804 [
    i8 92, label %714
    i8 97, label %690
  ]

690:                                              ; preds = %687
  %691 = icmp eq i32 %680, 3
  br i1 %691, label %804, label %692

692:                                              ; preds = %690
  %693 = getelementptr inbounds nuw i8, ptr %0, i32 %645
  %694 = load i8, ptr %693, align 1, !tbaa !2
  switch i8 %694, label %804 [
    i8 92, label %714
    i8 103, label %695
  ]

695:                                              ; preds = %692
  %696 = icmp eq i32 %680, 4
  br i1 %696, label %804, label %697

697:                                              ; preds = %695
  %698 = getelementptr inbounds nuw i8, ptr %0, i32 %644
  %699 = load i8, ptr %698, align 1, !tbaa !2
  switch i8 %699, label %804 [
    i8 92, label %714
    i8 101, label %700
  ]

700:                                              ; preds = %697
  %701 = icmp ult i32 %644, %142
  br i1 %701, label %710, label %804

702:                                              ; preds = %678
  %703 = getelementptr inbounds nuw i8, ptr %0, i32 %114
  %704 = load i8, ptr %703, align 1, !tbaa !2
  %705 = icmp eq i8 %704, 92
  br i1 %705, label %714, label %706

706:                                              ; preds = %702
  %707 = icmp ne i8 %704, 105
  %708 = icmp eq i32 %680, 1
  %709 = or i1 %707, %708
  br i1 %709, label %804, label %682

710:                                              ; preds = %700
  %711 = getelementptr inbounds nuw i8, ptr %0, i32 %679
  %712 = load i8, ptr %711, align 1, !tbaa !2
  %713 = icmp eq i8 %712, 34
  br i1 %713, label %824, label %804

714:                                              ; preds = %697, %692, %687, %682, %702
  %715 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %73, i32 noundef %202, ptr noundef nonnull @.str.4, i32 noundef 5)
  %716 = icmp eq i32 %715, 0
  br i1 %716, label %804, label %824

717:                                              ; preds = %804
  %718 = icmp eq i32 %680, 1
  br i1 %718, label %824, label %719

719:                                              ; preds = %717
  %720 = getelementptr i8, ptr %54, i32 %73
  %721 = load i8, ptr %720, align 1, !tbaa !2
  switch i8 %721, label %815 [
    i8 92, label %808
    i8 116, label %722
  ]

722:                                              ; preds = %719
  %723 = icmp eq i32 %680, 2
  br i1 %723, label %824, label %724

724:                                              ; preds = %722
  %725 = getelementptr i8, ptr %55, i32 %73
  %726 = load i8, ptr %725, align 1, !tbaa !2
  switch i8 %726, label %815 [
    i8 92, label %808
    i8 114, label %727
  ]

727:                                              ; preds = %724
  %728 = icmp eq i32 %680, 3
  br i1 %728, label %824, label %729

729:                                              ; preds = %727
  %730 = getelementptr inbounds nuw i8, ptr %0, i32 %645
  %731 = load i8, ptr %730, align 1, !tbaa !2
  switch i8 %731, label %815 [
    i8 92, label %808
    i8 117, label %732
  ]

732:                                              ; preds = %729
  %733 = icmp eq i32 %680, 4
  br i1 %733, label %824, label %734

734:                                              ; preds = %732
  %735 = getelementptr inbounds nuw i8, ptr %0, i32 %644
  %736 = load i8, ptr %735, align 1, !tbaa !2
  switch i8 %736, label %815 [
    i8 92, label %808
    i8 99, label %737
  ]

737:                                              ; preds = %734
  %738 = icmp eq i32 %680, 5
  br i1 %738, label %824, label %739

739:                                              ; preds = %737
  %740 = getelementptr inbounds nuw i8, ptr %0, i32 %679
  %741 = load i8, ptr %740, align 1, !tbaa !2
  switch i8 %741, label %815 [
    i8 92, label %808
    i8 116, label %742
  ]

742:                                              ; preds = %739
  %743 = icmp eq i32 %680, 6
  br i1 %743, label %824, label %744

744:                                              ; preds = %742
  %745 = getelementptr i8, ptr %56, i32 %73
  %746 = load i8, ptr %745, align 1, !tbaa !2
  switch i8 %746, label %815 [
    i8 92, label %808
    i8 117, label %747
  ]

747:                                              ; preds = %744
  %748 = icmp eq i32 %680, 7
  br i1 %748, label %824, label %749

749:                                              ; preds = %747
  %750 = getelementptr i8, ptr %57, i32 %73
  %751 = load i8, ptr %750, align 1, !tbaa !2
  switch i8 %751, label %815 [
    i8 92, label %808
    i8 114, label %752
  ]

752:                                              ; preds = %749
  %753 = icmp eq i32 %680, 8
  br i1 %753, label %824, label %754

754:                                              ; preds = %752
  %755 = getelementptr i8, ptr %58, i32 %73
  %756 = load i8, ptr %755, align 1, !tbaa !2
  switch i8 %756, label %815 [
    i8 92, label %808
    i8 101, label %757
  ]

757:                                              ; preds = %754
  %758 = icmp eq i32 %680, 9
  br i1 %758, label %824, label %759

759:                                              ; preds = %757
  %760 = getelementptr i8, ptr %59, i32 %73
  %761 = load i8, ptr %760, align 1, !tbaa !2
  switch i8 %761, label %815 [
    i8 92, label %808
    i8 100, label %762
  ]

762:                                              ; preds = %759
  %763 = icmp eq i32 %680, 10
  br i1 %763, label %824, label %764

764:                                              ; preds = %762
  %765 = getelementptr i8, ptr %60, i32 %73
  %766 = load i8, ptr %765, align 1, !tbaa !2
  switch i8 %766, label %815 [
    i8 92, label %808
    i8 45, label %767
  ]

767:                                              ; preds = %764
  %768 = icmp eq i32 %680, 11
  br i1 %768, label %824, label %769

769:                                              ; preds = %767
  %770 = getelementptr i8, ptr %61, i32 %73
  %771 = load i8, ptr %770, align 1, !tbaa !2
  switch i8 %771, label %815 [
    i8 92, label %808
    i8 99, label %772
  ]

772:                                              ; preds = %769
  %773 = icmp eq i32 %680, 12
  br i1 %773, label %824, label %774

774:                                              ; preds = %772
  %775 = getelementptr i8, ptr %62, i32 %73
  %776 = load i8, ptr %775, align 1, !tbaa !2
  switch i8 %776, label %815 [
    i8 92, label %808
    i8 111, label %777
  ]

777:                                              ; preds = %774
  %778 = icmp eq i32 %680, 13
  br i1 %778, label %824, label %779

779:                                              ; preds = %777
  %780 = getelementptr i8, ptr %63, i32 %73
  %781 = load i8, ptr %780, align 1, !tbaa !2
  switch i8 %781, label %815 [
    i8 92, label %808
    i8 110, label %782
  ]

782:                                              ; preds = %779
  %783 = icmp eq i32 %680, 14
  br i1 %783, label %824, label %784

784:                                              ; preds = %782
  %785 = getelementptr i8, ptr %64, i32 %73
  %786 = load i8, ptr %785, align 1, !tbaa !2
  switch i8 %786, label %815 [
    i8 92, label %808
    i8 116, label %787
  ]

787:                                              ; preds = %784
  %788 = icmp eq i32 %680, 15
  br i1 %788, label %824, label %789

789:                                              ; preds = %787
  %790 = getelementptr i8, ptr %65, i32 %73
  %791 = load i8, ptr %790, align 1, !tbaa !2
  switch i8 %791, label %815 [
    i8 92, label %808
    i8 101, label %792
  ]

792:                                              ; preds = %789
  %793 = icmp eq i32 %680, 16
  br i1 %793, label %824, label %794

794:                                              ; preds = %792
  %795 = getelementptr i8, ptr %66, i32 %73
  %796 = load i8, ptr %795, align 1, !tbaa !2
  switch i8 %796, label %815 [
    i8 92, label %808
    i8 110, label %797
  ]

797:                                              ; preds = %794
  %798 = icmp eq i32 %680, 17
  br i1 %798, label %824, label %799

799:                                              ; preds = %797
  %800 = getelementptr inbounds nuw i8, ptr %0, i32 %805
  %801 = load i8, ptr %800, align 1, !tbaa !2
  switch i8 %801, label %815 [
    i8 92, label %808
    i8 116, label %802
  ]

802:                                              ; preds = %799
  %803 = icmp ult i32 %805, %142
  br i1 %803, label %811, label %824

804:                                              ; preds = %697, %692, %687, %682, %706, %685, %690, %695, %710, %714, %700
  %805 = add i32 %73, 18
  %806 = getelementptr inbounds nuw i8, ptr %0, i32 %114
  %807 = load i8, ptr %806, align 1, !tbaa !2
  switch i8 %807, label %815 [
    i8 92, label %808
    i8 115, label %717
  ]

808:                                              ; preds = %804, %799, %794, %789, %784, %779, %774, %769, %764, %759, %754, %749, %744, %739, %734, %729, %724, %719
  %809 = tail call fastcc i32 @json_string_matches_ascii_escaped(ptr noundef nonnull %0, i32 noundef %73, i32 noundef %202, ptr noundef nonnull @.str.5, i32 noundef 18)
  %810 = icmp eq i32 %809, 0
  br label %815

811:                                              ; preds = %802
  %812 = getelementptr i8, ptr %67, i32 %73
  %813 = load i8, ptr %812, align 1, !tbaa !2
  %814 = icmp ne i8 %813, 34
  br label %815

815:                                              ; preds = %804, %799, %794, %789, %784, %779, %774, %769, %764, %759, %754, %749, %744, %739, %734, %729, %724, %719, %808, %811
  %816 = phi i1 [ %814, %811 ], [ %810, %808 ], [ true, %719 ], [ true, %724 ], [ true, %729 ], [ true, %734 ], [ true, %739 ], [ true, %744 ], [ true, %749 ], [ true, %754 ], [ true, %759 ], [ true, %764 ], [ true, %769 ], [ true, %774 ], [ true, %779 ], [ true, %784 ], [ true, %789 ], [ true, %794 ], [ true, %799 ], [ true, %804 ]
  %817 = freeze i1 %816
  %818 = select i1 %817, i32 0, i32 4
  br label %824

819:                                              ; preds = %639
  %820 = or i32 %71, %74
  br label %824

821:                                              ; preds = %634
  %822 = and i8 %70, -3
  %823 = icmp eq i8 %822, 0
  br i1 %823, label %824, label %944

824:                                              ; preds = %678, %717, %722, %727, %732, %737, %742, %747, %752, %757, %762, %767, %772, %777, %782, %787, %792, %797, %710, %671, %815, %641, %802, %821, %819, %714, %675, %636, %601, %595
  %825 = phi i32 [ %597, %601 ], [ %597, %595 ], [ %202, %819 ], [ %202, %636 ], [ %202, %714 ], [ %202, %675 ], [ %202, %821 ], [ %202, %802 ], [ %202, %641 ], [ %202, %815 ], [ %202, %671 ], [ %202, %710 ], [ %202, %797 ], [ %202, %792 ], [ %202, %787 ], [ %202, %782 ], [ %202, %777 ], [ %202, %772 ], [ %202, %767 ], [ %202, %762 ], [ %202, %757 ], [ %202, %752 ], [ %202, %747 ], [ %202, %742 ], [ %202, %737 ], [ %202, %732 ], [ %202, %727 ], [ %202, %722 ], [ %202, %717 ], [ %202, %678 ]
  %826 = phi i32 [ %74, %601 ], [ %74, %595 ], [ %820, %819 ], [ %74, %636 ], [ %74, %714 ], [ %74, %675 ], [ %74, %821 ], [ %74, %802 ], [ %74, %641 ], [ %74, %815 ], [ %74, %671 ], [ %74, %710 ], [ %74, %797 ], [ %74, %792 ], [ %74, %787 ], [ %74, %782 ], [ %74, %777 ], [ %74, %772 ], [ %74, %767 ], [ %74, %762 ], [ %74, %757 ], [ %74, %752 ], [ %74, %747 ], [ %74, %742 ], [ %74, %737 ], [ %74, %732 ], [ %74, %727 ], [ %74, %722 ], [ %74, %717 ], [ %74, %678 ]
  %827 = phi i32 [ %72, %601 ], [ %72, %595 ], [ %72, %819 ], [ %72, %636 ], [ 2, %714 ], [ 1, %675 ], [ %72, %821 ], [ 0, %802 ], [ 0, %641 ], [ %818, %815 ], [ 1, %671 ], [ 2, %710 ], [ 0, %797 ], [ 0, %792 ], [ 0, %787 ], [ 0, %782 ], [ 0, %777 ], [ 0, %772 ], [ 0, %767 ], [ 0, %762 ], [ 0, %757 ], [ 0, %752 ], [ 0, %747 ], [ 0, %742 ], [ 0, %737 ], [ 0, %732 ], [ 0, %727 ], [ 0, %722 ], [ 0, %717 ], [ 0, %678 ]
  %828 = phi i32 [ %596, %601 ], [ %596, %595 ], [ %71, %819 ], [ %71, %636 ], [ 8, %714 ], [ 8, %675 ], [ %71, %821 ], [ 8, %802 ], [ 8, %641 ], [ 8, %815 ], [ 8, %671 ], [ 8, %710 ], [ 8, %797 ], [ 8, %792 ], [ 8, %787 ], [ 8, %782 ], [ 8, %777 ], [ 8, %772 ], [ 8, %767 ], [ 8, %762 ], [ 8, %757 ], [ 8, %752 ], [ 8, %747 ], [ 8, %742 ], [ 8, %737 ], [ 8, %732 ], [ 8, %727 ], [ 8, %722 ], [ 8, %717 ], [ 8, %678 ]
  %829 = phi i8 [ 2, %601 ], [ 2, %595 ], [ 7, %819 ], [ 7, %636 ], [ 7, %714 ], [ 7, %675 ], [ 2, %821 ], [ 7, %802 ], [ 7, %641 ], [ 7, %815 ], [ 7, %671 ], [ 7, %710 ], [ 7, %797 ], [ 7, %792 ], [ 7, %787 ], [ 7, %782 ], [ 7, %777 ], [ 7, %772 ], [ 7, %767 ], [ 7, %762 ], [ 7, %757 ], [ 7, %752 ], [ 7, %747 ], [ 7, %742 ], [ 7, %737 ], [ 7, %732 ], [ 7, %727 ], [ 7, %722 ], [ 7, %717 ], [ 7, %678 ]
  %830 = phi i8 [ 4, %601 ], [ 4, %595 ], [ 6, %819 ], [ 6, %636 ], [ 6, %714 ], [ 6, %675 ], [ 1, %821 ], [ 6, %802 ], [ 6, %641 ], [ 6, %815 ], [ 6, %671 ], [ 6, %710 ], [ 6, %797 ], [ 6, %792 ], [ 6, %787 ], [ 6, %782 ], [ 6, %777 ], [ 6, %772 ], [ 6, %767 ], [ 6, %762 ], [ 6, %757 ], [ 6, %752 ], [ 6, %747 ], [ 6, %742 ], [ 6, %737 ], [ 6, %732 ], [ 6, %727 ], [ 6, %722 ], [ 6, %717 ], [ 6, %678 ]
  %831 = icmp ult i32 %825, %1
  %832 = and i1 %86, %831
  br i1 %832, label %833, label %936, !llvm.loop !137

833:                                              ; preds = %824
  %834 = getelementptr inbounds nuw i8, ptr %0, i32 %825
  %835 = load i8, ptr %834, align 1, !tbaa !2
  %836 = icmp eq i8 %835, 44
  br i1 %836, label %837, label %936, !llvm.loop !137

837:                                              ; preds = %833
  %838 = add nuw i32 %825, 1
  %839 = icmp ult i32 %838, %1
  br i1 %839, label %840, label %936, !llvm.loop !137

840:                                              ; preds = %837
  %841 = getelementptr inbounds nuw i8, ptr %0, i32 %838
  %842 = load i8, ptr %841, align 1, !tbaa !2
  %843 = icmp eq i8 %842, 32
  br i1 %843, label %844, label %936, !llvm.loop !137

844:                                              ; preds = %840
  br i1 %23, label %846, label %845

845:                                              ; preds = %844
  store i32 1, ptr %4, align 4, !tbaa !5
  br label %846

846:                                              ; preds = %845, %844
  %847 = add nuw i32 %825, 2
  br label %936, !llvm.loop !137

848:                                              ; preds = %68
  %849 = icmp ugt i8 %70, 1
  br i1 %849, label %944, label %857

850:                                              ; preds = %68
  switch i8 %70, label %944 [
    i8 6, label %851
    i8 3, label %851
  ]

851:                                              ; preds = %850, %850
  %852 = icmp eq i32 %69, 2
  %853 = select i1 %17, i1 %852, i1 false
  %854 = and i32 %72, %74
  %855 = icmp eq i32 %854, 0
  %856 = select i1 %853, i1 %855, i1 false
  br i1 %856, label %944, label %857

857:                                              ; preds = %851, %848
  %858 = add nuw i32 %73, 1
  %859 = add i32 %69, -1
  %860 = icmp eq i32 %859, 0
  br i1 %860, label %861, label %862

861:                                              ; preds = %857
  store i32 %858, ptr %3, align 4, !tbaa !5
  br label %944

862:                                              ; preds = %857
  %863 = add i32 %69, -2
  %864 = getelementptr inbounds nuw [256 x i8], ptr %8, i32 0, i32 %863
  %865 = load i8, ptr %864, align 1, !tbaa !2
  br label %936, !llvm.loop !137

866:                                              ; preds = %68
  switch i8 %70, label %944 [
    i8 1, label %868
    i8 6, label %867
  ]

867:                                              ; preds = %866
  br label %868

868:                                              ; preds = %867, %866
  %869 = phi i8 [ 7, %867 ], [ 2, %866 ]
  %870 = add nuw i32 %73, 1
  %871 = icmp ult i32 %870, %1
  br i1 %871, label %872, label %936, !llvm.loop !137

872:                                              ; preds = %868
  %873 = getelementptr inbounds nuw i8, ptr %0, i32 %870
  %874 = load i8, ptr %873, align 1, !tbaa !2
  %875 = icmp eq i8 %874, 32
  br i1 %875, label %876, label %936, !llvm.loop !137

876:                                              ; preds = %872
  br i1 %23, label %878, label %877

877:                                              ; preds = %876
  store i32 1, ptr %4, align 4, !tbaa !5
  br label %878

878:                                              ; preds = %877, %876
  %879 = add nuw i32 %73, 2
  br label %936, !llvm.loop !137

880:                                              ; preds = %68
  %881 = icmp eq i8 %70, 4
  br i1 %881, label %882, label %944

882:                                              ; preds = %880
  %883 = add nuw i32 %73, 1
  %884 = icmp ult i32 %883, %1
  br i1 %884, label %885, label %936, !llvm.loop !137

885:                                              ; preds = %882
  %886 = getelementptr inbounds nuw i8, ptr %0, i32 %883
  %887 = load i8, ptr %886, align 1, !tbaa !2
  %888 = icmp eq i8 %887, 32
  br i1 %888, label %889, label %936, !llvm.loop !137

889:                                              ; preds = %885
  br i1 %23, label %891, label %890

890:                                              ; preds = %889
  store i32 1, ptr %4, align 4, !tbaa !5
  br label %891

891:                                              ; preds = %890, %889
  %892 = add nuw i32 %73, 2
  br label %936, !llvm.loop !137

893:                                              ; preds = %68
  %894 = and i8 %70, -3
  %895 = icmp eq i8 %894, 0
  br i1 %895, label %910, label %896

896:                                              ; preds = %893
  %897 = icmp eq i8 %70, 5
  br i1 %897, label %898, label %944

898:                                              ; preds = %896
  %899 = icmp eq i32 %69, 2
  %900 = select i1 %17, i1 %899, i1 false
  br i1 %900, label %901, label %910

901:                                              ; preds = %898
  switch i32 %71, label %907 [
    i32 8, label %910
    i32 4, label %902
  ]

902:                                              ; preds = %901
  %903 = and i8 %76, -33
  %904 = icmp eq i8 %903, 91
  br i1 %904, label %905, label %907

905:                                              ; preds = %902
  %906 = or i32 %74, 4
  br label %910

907:                                              ; preds = %902, %901
  %908 = xor i32 %71, -1
  %909 = and i32 %74, %908
  br label %910

910:                                              ; preds = %893, %907, %905, %901, %898
  %911 = phi i8 [ 6, %905 ], [ 6, %907 ], [ 6, %898 ], [ 6, %901 ], [ 1, %893 ]
  %912 = phi i32 [ %906, %905 ], [ %909, %907 ], [ %74, %898 ], [ %74, %901 ], [ %74, %893 ]
  %913 = phi i32 [ %72, %905 ], [ %72, %907 ], [ %72, %898 ], [ 0, %901 ], [ %72, %893 ]
  %914 = icmp eq i8 %76, 91
  %915 = icmp eq i8 %76, 123
  switch i8 %76, label %930 [
    i8 123, label %916
    i8 91, label %916
  ]

916:                                              ; preds = %910, %910
  %917 = icmp ugt i32 %69, 255
  br i1 %917, label %944, label %918

918:                                              ; preds = %916
  %919 = icmp eq i32 %69, 1
  %920 = select i1 %17, i1 %919, i1 false
  %921 = and i1 %920, %915
  %922 = select i1 %921, i32 0, i32 %912
  %923 = select i1 %921, i32 0, i32 %913
  %924 = select i1 %921, i32 0, i32 %71
  %925 = add nsw i32 %69, -1
  %926 = getelementptr inbounds nuw [256 x i8], ptr %8, i32 0, i32 %925
  store i8 %911, ptr %926, align 1, !tbaa !2
  %927 = add nuw nsw i32 %69, 1
  %928 = select i1 %914, i8 0, i8 3
  %929 = add nuw i32 %73, 1
  br label %936, !llvm.loop !137

930:                                              ; preds = %910
  call void @llvm.lifetime.start.p0(i64 4, ptr nonnull %9) #28
  store i32 0, ptr %9, align 4, !tbaa !5
  %931 = call fastcc i32 @parse_scalar_span(ptr noundef nonnull %0, i32 noundef %1, i32 noundef %73, ptr noundef %9)
  %932 = icmp eq i32 %931, 0
  br i1 %932, label %933, label %934

933:                                              ; preds = %930
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9) #28
  br label %944

934:                                              ; preds = %930
  %935 = load i32, ptr %9, align 4, !tbaa !5
  call void @llvm.lifetime.end.p0(i64 4, ptr nonnull %9) #28
  br label %936

936:                                              ; preds = %302, %296, %291, %891, %885, %882, %878, %872, %868, %846, %840, %837, %824, %833, %620, %616, %625, %918, %862, %82, %934
  %937 = phi i32 [ %69, %934 ], [ %69, %302 ], [ %69, %296 ], [ %69, %291 ], [ %69, %891 ], [ %69, %885 ], [ %69, %882 ], [ %69, %878 ], [ %69, %872 ], [ %69, %868 ], [ %69, %846 ], [ %69, %840 ], [ %69, %837 ], [ %69, %824 ], [ %69, %833 ], [ %69, %620 ], [ %69, %616 ], [ %630, %625 ], [ %927, %918 ], [ %859, %862 ], [ %69, %82 ]
  %938 = phi i8 [ %911, %934 ], [ 7, %302 ], [ 7, %296 ], [ 7, %291 ], [ 5, %891 ], [ 5, %885 ], [ 5, %882 ], [ %869, %878 ], [ %869, %872 ], [ %869, %868 ], [ %829, %846 ], [ %829, %840 ], [ %829, %837 ], [ %830, %824 ], [ %830, %833 ], [ 5, %620 ], [ 5, %616 ], [ %632, %625 ], [ %928, %918 ], [ %865, %862 ], [ %70, %82 ]
  %939 = phi i32 [ %71, %934 ], [ %294, %302 ], [ %294, %296 ], [ %294, %291 ], [ %71, %891 ], [ %71, %885 ], [ %71, %882 ], [ %71, %878 ], [ %71, %872 ], [ %71, %868 ], [ %828, %846 ], [ %828, %840 ], [ %828, %837 ], [ %828, %824 ], [ %828, %833 ], [ %596, %620 ], [ %596, %616 ], [ %596, %625 ], [ %924, %918 ], [ %71, %862 ], [ %71, %82 ]
  %940 = phi i32 [ %913, %934 ], [ %72, %302 ], [ %72, %296 ], [ %72, %291 ], [ %72, %891 ], [ %72, %885 ], [ %72, %882 ], [ %72, %878 ], [ %72, %872 ], [ %72, %868 ], [ %827, %846 ], [ %827, %840 ], [ %827, %837 ], [ %827, %824 ], [ %827, %833 ], [ %72, %620 ], [ %72, %616 ], [ %72, %625 ], [ %923, %918 ], [ %72, %862 ], [ %72, %82 ]
  %941 = phi i32 [ %935, %934 ], [ %303, %302 ], [ %283, %296 ], [ %283, %291 ], [ %892, %891 ], [ %883, %885 ], [ %883, %882 ], [ %879, %878 ], [ %870, %872 ], [ %870, %868 ], [ %847, %846 ], [ %838, %840 ], [ %838, %837 ], [ %825, %824 ], [ %825, %833 ], [ %617, %620 ], [ %617, %616 ], [ %633, %625 ], [ %929, %918 ], [ %858, %862 ], [ %83, %82 ]
  %942 = phi i32 [ %912, %934 ], [ %74, %302 ], [ %74, %296 ], [ %74, %291 ], [ %74, %891 ], [ %74, %885 ], [ %74, %882 ], [ %74, %878 ], [ %74, %872 ], [ %74, %868 ], [ %826, %846 ], [ %826, %840 ], [ %826, %837 ], [ %826, %824 ], [ %826, %833 ], [ %74, %620 ], [ %74, %616 ], [ %627, %625 ], [ %922, %918 ], [ %74, %862 ], [ %74, %82 ]
  %943 = icmp ult i32 %941, %1
  br i1 %943, label %68, label %944, !llvm.loop !137

944:                                              ; preds = %936, %848, %850, %851, %866, %880, %896, %916, %623, %821, %112, %141, %203, %151, %198, %154, %148, %160, %169, %178, %187, %933, %14, %861
  %945 = phi i32 [ 1, %861 ], [ 0, %14 ], [ 0, %933 ], [ 0, %187 ], [ 0, %178 ], [ 0, %169 ], [ 0, %160 ], [ 0, %148 ], [ 0, %154 ], [ 0, %198 ], [ 0, %151 ], [ 0, %203 ], [ 0, %141 ], [ 0, %112 ], [ 0, %821 ], [ 0, %623 ], [ 0, %916 ], [ 0, %896 ], [ 0, %880 ], [ 0, %866 ], [ 0, %851 ], [ 0, %850 ], [ 0, %848 ], [ 0, %936 ]
  call void @llvm.lifetime.end.p0(i64 256, ptr nonnull %8) #28
  br label %946

946:                                              ; preds = %7, %11, %944
  %947 = phi i32 [ %945, %944 ], [ 0, %11 ], [ 0, %7 ]
  ret i32 %947
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umax.i32(i32, i32) #26

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.ctpop.i32(i32) #26

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.umin.i32(i32, i32) #26

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.usub.sat.i32(i32, i32) #26

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.fshl.i32(i32, i32, i32) #26

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #27

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare <4 x i32> @llvm.fshl.v4i32(<4 x i32>, <4 x i32>, <4 x i32>) #26

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #1 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #2 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: readwrite) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #3 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #4 = { nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #7 = { nofree norecurse nosync nounwind memory(readwrite, argmem: read, inaccessiblemem: none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #8 = { nofree norecurse nosync nounwind memory(readwrite, inaccessiblemem: none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #9 = { nofree norecurse nosync nounwind memory(read, inaccessiblemem: none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #10 = { mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #11 = { mustprogress nofree norecurse nosync nounwind willreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #12 = { mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #13 = { nofree nosync nounwind memory(readwrite, inaccessiblemem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #14 = { mustprogress nocallback nofree nosync nounwind willreturn memory(read) }
attributes #15 = { nofree nosync nounwind memory(readwrite, inaccessiblemem: none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #16 = { nofree norecurse nosync nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #17 = { nofree nosync nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #18 = { nofree norecurse nosync nounwind memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #19 = { nofree norecurse nosync nounwind memory(argmem: readwrite) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #20 = { nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: none) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #21 = { mustprogress nocallback nofree nosync nounwind willreturn }
attributes #22 = { mustprogress nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #23 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #24 = { inlinehint nofree norecurse nosync nounwind memory(argmem: readwrite) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #25 = { nofree noinline norecurse nosync nounwind memory(argmem: readwrite) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="generic" "target-features"="+atomics,+bulk-memory,+bulk-memory-opt,+call-indirect-overlong,+multivalue,+mutable-globals,+nontrapping-fptoint,+reference-types,+sign-ext,+simd128" }
attributes #26 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #27 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #28 = { nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{!"Ubuntu clang version 21.1.8 (6ubuntu1)"}
!2 = !{!3, !3, i64 0}
!3 = !{!"omnipotent char", !4, i64 0}
!4 = !{!"Simple C/C++ TBAA"}
!5 = !{!6, !6, i64 0}
!6 = !{!"int", !3, i64 0}
!7 = distinct !{!7, !8}
!8 = !{!"llvm.loop.mustprogress"}
!9 = distinct !{!9, !8}
!10 = distinct !{!10, !8}
!11 = distinct !{!11, !8}
!12 = distinct !{!12, !8}
!13 = distinct !{!13, !8, !14, !15}
!14 = !{!"llvm.loop.isvectorized", i32 1}
!15 = !{!"llvm.loop.unroll.runtime.disable"}
!16 = distinct !{!16, !8}
!17 = distinct !{!17, !8}
!18 = distinct !{!18, !8}
!19 = distinct !{!19, !8}
!20 = distinct !{!20, !8}
!21 = distinct !{!21, !8}
!22 = distinct !{!22, !8}
!23 = distinct !{!23, !8}
!24 = !{!25, !6, i64 0}
!25 = !{!"", !6, i64 0, !3, i64 4}
!26 = distinct !{!26, !8}
!27 = !{!28, !6, i64 36}
!28 = !{!"", !6, i64 0, !6, i64 4, !6, i64 8, !6, i64 12, !6, i64 16, !6, i64 20, !6, i64 24, !6, i64 28, !6, i64 32, !6, i64 36, !6, i64 40, !6, i64 44, !6, i64 48, !6, i64 52, !6, i64 56, !6, i64 60, !6, i64 64}
!29 = !{!28, !6, i64 40}
!30 = distinct !{!30, !8}
!31 = distinct !{!31, !8}
!32 = distinct !{!32, !8}
!33 = distinct !{!33, !8}
!34 = distinct !{!34, !8}
!35 = distinct !{!35, !8}
!36 = !{!37, !6, i64 4}
!37 = !{!"", !6, i64 0, !6, i64 4, !6, i64 8}
!38 = !{!37, !6, i64 8}
!39 = !{!37, !6, i64 0}
!40 = !{i64 0, i64 4, !5, i64 4, i64 4, !5, i64 8, i64 4, !5}
!41 = distinct !{!41, !8}
!42 = distinct !{!42, !8}
!43 = distinct !{!43, !8}
!44 = distinct !{!44, !8}
!45 = !{!46, !47, i64 0}
!46 = !{!"", !47, i64 0, !49, i64 4, !6, i64 8, !6, i64 12, !6, i64 16, !6, i64 20, !6, i64 24}
!47 = !{!"p1 omnipotent char", !48, i64 0}
!48 = !{!"any pointer", !3, i64 0}
!49 = !{!"p1 int", !48, i64 0}
!50 = !{!46, !49, i64 4}
!51 = !{!46, !6, i64 8}
!52 = !{!46, !6, i64 12}
!53 = !{!46, !6, i64 16}
!54 = !{!46, !6, i64 20}
!55 = !{!46, !6, i64 24}
!56 = distinct !{!56, !8}
!57 = !{!28, !6, i64 28}
!58 = !{!28, !6, i64 24}
!59 = !{!28, !6, i64 20}
!60 = !{!28, !6, i64 16}
!61 = !{!28, !6, i64 52}
!62 = !{!28, !6, i64 48}
!63 = !{!28, !6, i64 60}
!64 = distinct !{!64, !8}
!65 = distinct !{!65, !8}
!66 = distinct !{!66, !8}
!67 = distinct !{!67, !8}
!68 = !{!28, !6, i64 64}
!69 = distinct !{!69, !8}
!70 = !{!28, !6, i64 0}
!71 = !{!28, !6, i64 8}
!72 = !{!28, !6, i64 4}
!73 = !{!28, !6, i64 12}
!74 = distinct !{!74, !8}
!75 = distinct !{!75, !8}
!76 = distinct !{!76, !8}
!77 = !{!78, !78, i64 0}
!78 = !{!"short", !3, i64 0}
!79 = distinct !{!79, !8}
!80 = distinct !{!80, !8}
!81 = distinct !{!81, !8}
!82 = distinct !{!82, !8}
!83 = distinct !{!83, !8}
!84 = distinct !{!84, !8}
!85 = distinct !{!85, !8}
!86 = distinct !{!86, !8}
!87 = distinct !{!87, !8, !15, !14}
!88 = distinct !{!88, !8}
!89 = distinct !{!89, !8}
!90 = distinct !{!90, !8}
!91 = distinct !{!91, !8}
!92 = distinct !{!92, !8}
!93 = distinct !{!93, !8}
!94 = distinct !{!94, !8}
!95 = distinct !{!95, !8}
!96 = distinct !{!96, !8}
!97 = distinct !{!97, !8}
!98 = distinct !{!98, !8}
!99 = distinct !{!99, !8}
!100 = distinct !{!100, !8}
!101 = distinct !{!101, !102}
!102 = !{!"llvm.loop.unroll.disable"}
!103 = distinct !{!103, !8}
!104 = distinct !{!104, !8}
!105 = distinct !{!105, !8, !14, !15}
!106 = distinct !{!106, !8}
!107 = distinct !{!107, !8, !14, !15}
!108 = distinct !{!108, !8, !14}
!109 = distinct !{!109, !8, !15, !14}
!110 = distinct !{!110, !8}
!111 = distinct !{!111, !8}
!112 = distinct !{!112, !8}
!113 = !{!28, !6, i64 56}
!114 = distinct !{!114, !8}
!115 = distinct !{!115, !8}
!116 = !{!28, !6, i64 32}
!117 = distinct !{!117, !8}
!118 = !{!28, !6, i64 44}
!119 = distinct !{!119, !8}
!120 = distinct !{!120, !8}
!121 = distinct !{!121, !8}
!122 = distinct !{!122, !8}
!123 = distinct !{!123, !8, !15, !14}
!124 = distinct !{!124, !8, !15, !14}
!125 = distinct !{!125, !8, !15, !14}
!126 = distinct !{!126, !8}
!127 = distinct !{!127, !8}
!128 = distinct !{!128, !8}
!129 = distinct !{!129, !8, !15, !14}
!130 = distinct !{!130, !8, !15, !14}
!131 = distinct !{!131, !8}
!132 = distinct !{!132, !8}
!133 = distinct !{!133, !8}
!134 = distinct !{!134, !8}
!135 = distinct !{!135, !8}
!136 = distinct !{!136, !8}
!137 = distinct !{!137, !8}
!138 = distinct !{!138, !8}
!139 = distinct !{!139, !8}
!140 = distinct !{!140, !8}
!141 = distinct !{!141, !8}
!142 = distinct !{!142, !8}
!143 = distinct !{!143, !8}
!144 = distinct !{!144, !8}
!145 = distinct !{!145, !8}
