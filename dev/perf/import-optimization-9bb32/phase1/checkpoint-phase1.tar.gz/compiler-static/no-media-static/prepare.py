from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/workspace/scratch/9bb32f82fa3b/manabitan')
HERE = Path(__file__).parent
COMPILER = '/tmp/manabitan-native-9bb32/native-toolchain/bin/clang'
LINKER = '/tmp/manabitan-native-9bb32/native-toolchain/bin/wasm-ld'
source_path = ROOT / 'ext/js/dictionary/wasm/term-bank-parser.c'
source = source_path.read_text()
start = source.index('static int parse_composite_span_impl(')
end = source.index('\nstatic int parse_composite_span(', start)
original = source[start:end]
body = original[original.index(') {') + 2:]
shared = original.replace(
    'static int parse_composite_span_impl(',
    'static __attribute__((always_inline)) inline int parse_composite_span_body(',
    1,
)
assert shared[shared.index(') {') + 2:] == body

wrappers = '''
static int parse_composite_span_impl(
    const uint8_t* src,
    uint32_t len,
    uint32_t start,
    uint32_t* out_end,
    uint32_t* media_hint,
    uint32_t* normalization_hint,
    uint32_t* text_normalization_hint,
    int validate_glossary_types
) {
    return parse_composite_span_body(
        src, len, start, out_end, media_hint,
        normalization_hint, text_normalization_hint, validate_glossary_types
    );
}

static int parse_composite_span_no_media(
    const uint8_t* src,
    uint32_t len,
    uint32_t start,
    uint32_t* out_end,
    uint32_t* normalization_hint,
    uint32_t* text_normalization_hint,
    int validate_glossary_types
) {
    return parse_composite_span_body(
        src, len, start, out_end, 0,
        normalization_hint, text_normalization_hint, validate_glossary_types
    );
}
'''
candidate = source[:start] + shared + wrappers + source[end:]
original_call = '        return parse_composite_span_impl(src, len, start, out_end, media_hint, normalization_hint, text_normalization_hint, validate_glossary_types);'
assert candidate.count(original_call) == 1
candidate = candidate.replace(original_call, '''        if (media_hint == 0) {
            return parse_composite_span_no_media(
                src, len, start, out_end,
                normalization_hint, text_normalization_hint, validate_glossary_types
            );
        }
''' + original_call)
candidate_path = HERE / 'term-bank-parser-no-media.c'
candidate_path.write_text(candidate)
manifest = json.loads((ROOT / 'dev/data/dictionary-wasm/manifest.json').read_text())
target = next(item for item in manifest['targets'] if item['name'] == 'term-bank-parser.wasm')
arguments = [argument for argument in target['arguments'] if argument != '-Wl,--strip-all']
command = [COMPILER, f'-fuse-ld={LINKER}', *arguments, '-o', str(HERE / 'term-bank-parser-no-media.wasm'), str(candidate_path), str(ROOT / target['sources'][1])]
subprocess.run(command, check=True)
compile_arguments = [argument for argument in arguments if not argument.startswith('-Wl,')]
for suffix, extra in [('s', []), ('ll', ['-emit-llvm'])]:
    subprocess.run([COMPILER, *compile_arguments, '-S', *extra, '-o', str(HERE / f'term-bank-parser-no-media.{suffix}'), str(candidate_path)], check=True)
identity = {
    'scope': 'Scratch-only static code probe; no timings, production edits, policy changes, or publication.',
    'baselineCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'originalSourceSha256': hashlib.sha256(source.encode()).hexdigest(),
    'diagnosticSourceSha256': hashlib.sha256(candidate.encode()).hexdigest(),
    'sharedGrammarBodySha256': hashlib.sha256(body.encode()).hexdigest(),
    'grammarBodyUnchanged': True,
    'onlyConstantParameter': 'media_hint == NULL',
    'dynamicParametersPreserved': ['normalization_hint', 'text_normalization_hint', 'validate_glossary_types'],
    'ordinaryGenericCompositeRouteUnchanged': True,
    'command': command,
}
(HERE / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps({key: value for key, value in identity.items() if key != 'command'}, indent=2))
