#!/usr/bin/env python3
"""Read retained hosted diagnostics; never run an import or modify product files."""
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
BASELINE = "9e10d3b3fcf66d344ab31bc42c9b522fa5215da2"
FINAL_KEYS = [
    "totalMs", "commitMs", "termContentEndImportSessionMs",
    "termContentEndImportSessionCloseWritableMs", "termRecordEndImportSessionMs",
    "termRecordEndImportSessionFlushPendingWritesMs",
    "termRecordEndImportSessionAwaitQueuedWritesMs",
    "termRecordEndImportSessionCloseWritableMs", "termRecordDrainCycleCount",
    "termRecordWriteCallCount", "termRecordTotalWriteBytes",
    "termRecordLookupIndexWriteCallCount", "termRecordLookupIndexWriteBytes",
    "termRecordLookupIndexAwaitMs", "termRecordLookupIndexMaxQueuedBytes",
    "termRecordLookupIndexWorkerFileCount", "termsVirtualTableSyncMs",
    "createIndexesMs", "cacheResetMs", "runtimePragmasMs",
]


def identity(path):
    return {"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def diagnostic(path):
    data = json.loads(path.read_text())
    debug = next(
        phase["data"]["importDebug"] for phase in data["phases"]
        if isinstance(phase.get("data"), dict)
        and isinstance(phase["data"].get("importDebug"), dict)
    )
    phases = debug["importerPhaseTimings"]
    final = next(phase for phase in phases if phase["phase"] == "bulk-finalization")
    term = next(phase for phase in phases if phase["phase"].startswith("term-file-fast-path:"))
    return {
        "source": identity(path),
        "finalizationElapsedMs": final["elapsedMs"],
        "finalizationStartEpochMs": final["startEpochMs"],
        "finalizationEndEpochMs": final["endEpochMs"],
        "finalizationDetails": {key: final["details"].get(key) for key in FINAL_KEYS},
        "termPipelineElapsedMs": term["elapsedMs"],
        "termRows": term["details"]["rows"],
        "termSourceBytes": term["details"]["parserSourceUncompressedBytes"],
    }


def writer_finish_tasks(path):
    events = json.loads(path.read_text())["traceEvents"]
    profiles = {}
    for event in events:
        if event.get("name") == "Profile":
            profiles[(event["pid"], event["id"])] = {
                "tid": event["tid"], "start": event["args"]["data"]["startTime"],
                "nodes": {}, "samples": [],
            }
    for event in events:
        if event.get("name") != "ProfileChunk":
            continue
        profile = profiles[(event["pid"], event["id"])]
        data = event["args"]["data"]
        cpu = data.get("cpuProfile", {})
        profile["nodes"].update((node["id"], node) for node in cpu.get("nodes", []))
        profile["samples"].extend(zip(cpu.get("samples", []), data.get("timeDeltas", [])))
    findings = []
    for (pid, profile_id), profile in profiles.items():
        nodes = profile["nodes"]
        finish_roots = {
            node_id for node_id, node in nodes.items()
            if node.get("callFrame", {}).get("url", "").endswith("term-record-import-index-writer.js")
            and node.get("callFrame", {}).get("lineNumber") == 197
        }
        if not finish_roots:
            continue

        def belongs_to_finish(node_id):
            while node_id in nodes:
                if node_id in finish_roots:
                    return True
                node_id = nodes[node_id].get("parent")
            return False

        time = profile["start"]
        intervals = []
        for node_id, delta in profile["samples"]:
            previous = time
            time += delta
            if belongs_to_finish(node_id):
                intervals.append({
                    "startUs": previous, "endUs": time, "deltaUs": delta,
                    "frame": nodes[node_id]["callFrame"].get("functionName"),
                })
        tasks = []
        for event in events:
            if not (
                event.get("pid") == pid and event.get("tid") == profile["tid"]
                and event.get("name") == "RunTask" and event.get("ph") == "X"
                and event.get("dur", 0) >= 1000
            ):
                continue
            if any(
                interval["startUs"] < event["ts"] + event["dur"]
                and interval["endUs"] > event["ts"] for interval in intervals
            ):
                tasks.append({
                    "startUs": event["ts"], "wallMs": event["dur"] / 1000,
                    "threadCpuMs": event.get("tdur", 0) / 1000,
                    "wallMinusThreadCpuMs": (event["dur"] - event.get("tdur", 0)) / 1000,
                })
        findings.append({
            "pid": pid, "profileId": profile_id, "threadId": profile["tid"],
            "finishFrameSource": "term-record-import-index-writer.js:198 (1-based)",
            "sampleIntervals": intervals, "overlappingLongTasks": tasks,
            "summedTaskWallMs": sum(task["wallMs"] for task in tasks),
            "summedTaskThreadCpuMs": sum(task["threadCpuMs"] for task in tasks),
        })
    return {"source": identity(path), "profiles": findings}


report = {
    "baselineCommit": BASELINE,
    "scope": "Read-only analysis of already retained hosted ordinary and traced baselines; no new timings.",
    "limitations": [
        "One ordinary and one traced diagnostic per dictionary; these are not repeated qualification cohorts.",
        "CPU-profile time deltas are sampled wall intervals, not CPU measurements; signed trace jitter is preserved.",
        "RunTask tdur is thread CPU. Wall minus thread CPU includes blocking/descheduling; it does not identify disk service latency separately.",
        "Whole-session write/queue counters must not be read as finalization-only work.",
    ],
    "dictionaries": {},
}
for dictionary in ["jmdict", "jitendex", "vndb"]:
    folder = ROOT / f"hosted-baseline-{dictionary}"
    report["dictionaries"][dictionary] = {
        "ordinary": diagnostic(folder / "ordinary/run-1.json"),
        "traced": diagnostic(folder / "trace/run-1.json"),
        "writerFinishTrace": writer_finish_tasks(folder / "trace/run-1.trace.json"),
    }
report["sourceCallGraph"] = [
    "dictionary-importer.js:2950 -> DictionaryImportSession.finalizeBulkImport",
    "dictionary-import-session.js:216 -> DictionaryDatabase.finishBulkImport",
    "dictionary-database.js:1543,1570,1597 -> concurrent content/record endImportSession; await both before COMMIT",
    "term-record-opfs-store.js:1498 -> flush descriptor writes -> await descriptor queue -> _closeAllWritables",
    "term-record-opfs-store.js:6524 -> per-shard Promise.allSettled(descriptor finalization, lookup-index finalization)",
    "term-record-opfs-store.js:6286 -> flush pending index chunks/queue -> rewrite final 40-byte header -> close lookup writer",
    "term-record-import-index-writer.js:194 -> await writer queue -> access.flush() -> access.close(), preserving failures",
    "term-record-opfs-store.js:6430 -> local sync writer for JMdict/Jitendex; >=1GiB source eligibility enables I/O worker for VNDB",
]
report["conclusions"] = [
    "JMdict's large tail is real critical-path publication latency: traced index-writer flush occupies a 103.521ms task with only 1.915ms thread CPU.",
    "Descriptor/content close branches already overlap. The index-writer queue has almost no outstanding wait in JMdict; the final native flush dominates.",
    "Jitendex uses the same local route and nearly identical index bytes, but closes much faster in these diagnostics. Dictionary-specific CPU work is not established.",
    "VNDB has two index files on one I/O worker. Its traced final close tasks total 102.893ms wall and 1.675ms CPU; its ordinary tail is smaller, showing substantial observed variation.",
    "No fresh low-risk product optimization is justified by this tail. Per-shard parallelism cannot help the one-file JMdict/Jitendex route, and the VNDB native flushes share a worker.",
    "Removing the explicit flush would discard existing observable flush-failure/publication guarantees; the flush is not a redundant duplicate call in this source path.",
]
report["priorWorkAndConstraints"] = {
    "868": "Descriptor-close attribution already identified blocking by local index flush; descriptor-only writer held.",
    "813": "Adaptive local periodic flushes failed repeated JMdict full-import gain.",
    "821": "Existing >=1GiB I/O-worker eligibility; retuning worker/gates is excluded.",
    "844": "Writer work budget already excludes idle time.",
    "883": "MessageChannel yield already replaces timer floor.",
    "337": "Sticky failure after awaited drains is correctness behavior to preserve.",
    "additionalAudit": "prior_optimization_audit found no further per-shard-close/duplicate-flush proposal.",
}
report["existingFailureTestsReadNotRun"] = [
    "test/term-record-import-index-writer.test.js:260 keeps flush/close failures sticky and closes exactly once",
    "test/term-record-import-index-writer.test.js:324 synchronous flush failure fails finalization",
    "test/term-record-import-index-flush.test.js:211 earlier periodic flush cannot hide failed final header flush",
]
destination = ROOT / "finalization-tail-analysis.json"
destination.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"report": str(destination), "bytes": destination.stat().st_size, "conclusion": "No new low-risk tail optimization; blocking native flush dominates."}))
