import collections
import hashlib
import json
import pathlib
import tarfile

ROOT = pathlib.Path('/workspace/scratch/9bb32f82fa3b/manabitan')
OUT = pathlib.Path('/workspace/scratch/9bb32f82fa3b/profiling')
EVIDENCE = ROOT / 'dev/perf/import-qualification-evidence-20261125-a7f7'
manifest = json.loads((EVIDENCE / 'baseline-profiles-manifest.json.txt').read_text())
archive = EVIDENCE / manifest['archive']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest['archiveSha256']
result = {'scope': 'Prior hosted diagnostics; single ordinary observations are not a speed comparison and traced samples are not wall-clock contributions.', 'archive': str(archive), 'archiveSha256': manifest['archiveSha256'], 'dictionaries': {}}

with tarfile.open(archive) as tar:
    for row in manifest['files']:
        value = tar.extractfile(row['path']).read()
        assert len(value) == row['size']
        assert hashlib.sha256(value).hexdigest() == row['sha256']
    for dictionary in ['jmdict', 'jitendex', 'vndb']:
        prefix = f'current-profile-{dictionary}'
        ordinary = json.load(tar.extractfile(f'{prefix}/ordinary/summary.json'))
        trace_report = json.load(tar.extractfile(f'{prefix}/trace/summary.json'))
        trace = json.load(tar.extractfile(f'{prefix}/trace/run-1.trace.json'))
        run = ordinary['runs'][0]
        phases = run['importDebug']['importerPhaseTimings']
        term_phases = [x for x in phases if x['phase'].startswith('term-file-fast-path:')]
        node_table = {}
        profile_chunks = []
        process_names = {}
        thread_names = {}
        for event in trace['traceEvents']:
            pid, tid = event.get('pid'), event.get('tid')
            if event.get('name') == 'process_name':
                process_names[pid] = event.get('args', {}).get('name')
            elif event.get('name') == 'thread_name':
                thread_names[(pid, tid)] = event.get('args', {}).get('name')
            data = event.get('args', {}).get('data', {})
            profile = data.get('cpuProfile')
            key = (pid, tid, str(event.get('id2', event.get('id'))))
            if profile:
                for node in profile.get('nodes', []):
                    node_table[(key, node['id'])] = node
                profile_chunks.append((key, profile.get('samples', []), data.get('timeDeltas', [])))
        times = collections.Counter()
        counts = collections.Counter()
        threads = collections.defaultdict(collections.Counter)
        for key, samples, deltas in profile_chunks:
            for i, node_id in enumerate(samples):
                frame = node_table.get((key, node_id), {}).get('callFrame', {})
                function = (frame.get('functionName'), frame.get('url', ''), frame.get('lineNumber'))
                elapsed = deltas[i] if i < len(deltas) else 0
                times[function] += elapsed
                counts[function] += 1
                threads[key[:2]][function] += elapsed
        hot = [{'sampledMs': round(value / 1000, 3), 'samples': counts[key], 'function': key[0], 'source': key[1], 'line': key[2]} for key, value in times.most_common(60)]
        thread_results = []
        for key, functions in threads.items():
            busy_us = sum(value for function, value in functions.items() if function[0] != '(idle)')
            thread_results.append({'pid': key[0], 'tid': key[1], 'process': process_names.get(key[0]), 'thread': thread_names.get(key), 'sampledBusyMs': round(busy_us / 1000, 3), 'top': [{'sampledMs': round(value / 1000, 3), 'function': function[0], 'source': function[1]} for function, value in functions.most_common(8)]})
        thread_results.sort(key=lambda x: x['sampledBusyMs'], reverse=True)
        metrics = {name: round(sum(float(p['details'].get(name, 0) or 0) for p in term_phases), 3) for name in ['rows', 'chunkCount', 'importerChunkSinkMs', 'sourceArchiveReadMs', 'parserParseBankMs', 'parserSourceInflateMs', 'parserSourceCrcMs', 'parserResultCopyMs', 'parserOrderedSinkWaitMs', 'parserBorrowedContentResultCount', 'parserLookupIndexPrepareMs', 'parserParallelWorkerWallMs', 'parserParallelPeakQueuedOwnedContentBytes', 'parserParallelOwnedContentBytes', 'bulkAddTermsMs', 'contentCompressMs', 'dedupScanMs', 'contentMetadataPublishMs', 'contentMetadataIndexPublishMs', 'termRecordEncodeMs', 'termRecordWriteMs', 'termRecordValidationMs']}
        result['dictionaries'][dictionary] = {
            'gitSha': ordinary['gitSha'], 'source': ordinary['source'], 'nodeVersion': ordinary['hostEnvironment'].get('nodeVersion'), 'browserVersion': ordinary['browserVersion'],
            'ordinaryImportMs': ordinary['timing']['medianMs'], 'ordinaryWorkerMs': ordinary['workerTiming']['medianMs'], 'traceImportMs': trace_report['timing']['medianMs'],
            'phases': [{'phase': p['phase'], 'elapsedMs': p['elapsedMs']} for p in phases], 'metrics': metrics,
            'workerPolicies': [{'workers': p['details'].get('parserParallelWorkerCount'), 'groupsPerWorker': p['details'].get('parserParallelPipelineGroupsPerWorker'), 'groups': p['details'].get('parserParallelGroupCount')} for p in term_phases],
            'hotspots': hot, 'threads': thread_results,
        }
(OUT / 'retained-profile-summary.json').write_text(json.dumps(result, indent=2) + '\n')
for dictionary, data in result['dictionaries'].items():
    print(dictionary, json.dumps({k: data[k] for k in ['gitSha','ordinaryImportMs','ordinaryWorkerMs','phases','metrics','workerPolicies']}))
    print('top nonidle', json.dumps([x for x in data['hotspots'] if x['function'] != '(idle)'][:12]))
