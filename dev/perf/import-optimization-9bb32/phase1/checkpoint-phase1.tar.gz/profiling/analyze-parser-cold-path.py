import collections
import hashlib
import json
import pathlib
import re

root = pathlib.Path(__file__).resolve().parent
output = {}
for dictionary in ('jmdict', 'jitendex', 'vndb'):
    path = root / ('hosted-baseline-' + dictionary) / 'trace/run-1.trace.json'
    raw = path.read_bytes()
    document = json.loads(raw)
    events = document['traceEvents'] if isinstance(document, dict) else document
    profiles = {}
    for event in sorted(events, key=lambda item: item.get('ts', 0)):
        if event.get('name') not in ('Profile', 'ProfileChunk'):
            continue
        key = (event['pid'], event.get('id'))
        profile = profiles.setdefault(key, {'nodes': {}, 'samples': [], 'thread': None, 'time': None})
        data = event.get('args', {}).get('data', {})
        if event['name'] == 'Profile':
            profile['time'] = data['startTime']
            profile['thread'] = event['tid']
            continue
        cpu = data.get('cpuProfile', {})
        for node in cpu.get('nodes', []):
            profile['nodes'][node['id']] = node
        samples, deltas = cpu.get('samples', []), data.get('timeDeltas', [])
        assert len(samples) == len(deltas)
        assert profile['time'] is not None
        for node, delta in zip(samples, deltas):
            profile['time'] += delta
            profile['samples'].append((profile['time'], delta, node))
    parser = []
    for key, profile in profiles.items():
        nodes = profile['nodes']
        # This exact module URL identifies the byte-identical pinned parser in
        # all three freshly retained traces, independently of worker script IDs.
        module_urls = {n.get('callFrame', {}).get('url') for n in nodes.values()
                       if n.get('callFrame', {}).get('functionName') == 'wasm-function[13]'
                       and n.get('callFrame', {}).get('columnNumber') == 17819}
        if not module_urls:
            continue
        samples = []
        for stamp, delta, node_id in profile['samples']:
            frames = []
            cursor = node_id
            seen = set()
            while cursor in nodes and cursor not in seen:
                seen.add(cursor)
                node = nodes[cursor]
                frames.append(node.get('callFrame', {}))
                cursor = node.get('parent')
            if not any(frame.get('url') in module_urls for frame in frames):
                continue
            self_13 = frames[0].get('url') in module_urls and frames[0].get('functionName') == 'wasm-function[13]'
            inclusive_13 = any(frame.get('url') in module_urls and frame.get('functionName') == 'wasm-function[13]' for frame in frames)
            samples.append({'time': stamp, 'delta': delta, 'self13': self_13, 'inclusive13': inclusive_13})
        if samples:
            parser.append({'profileId': key[1], 'thread': profile['thread'], 'moduleUrls': sorted(module_urls), 'samples': samples})
    first = min(s['time'] for p in parser for s in p['samples'])
    last = max(s['time'] for p in parser for s in p['samples'])
    span = last - first
    summaries = []
    bins = [0.0] * 4
    for profile in parser:
        samples = profile.pop('samples')
        hot = [s for s in samples if s['self13']]
        local_first = min(s['time'] for s in samples)
        local_last = max(s['time'] for s in samples)
        for sample in hot:
            index = min(3, int(4 * (sample['time'] - first) / span))
            bins[index] += sample['delta'] / 1000
        summaries.append({**profile, 'firstParserSampleMs': (local_first-first)/1000,
                          'lastParserSampleMs': (local_last-first)/1000,
                          'parserSampledMs': sum(s['delta'] for s in samples)/1000,
                          'function13SampleCount': len(hot),
                          'function13SampledSelfMs': sum(s['delta'] for s in hot)/1000,
                          'function13SampledInclusiveMs': sum(s['delta'] for s in samples if s['inclusive13'])/1000,
                          'firstFunction13SampleMs': (hot[0]['time']-first)/1000,
                          'lastFunction13SampleMs': (hot[-1]['time']-first)/1000,
                          'function13SelfAfterLocalMidpointMs': sum(s['delta'] for s in hot if s['time'] >= (local_first+local_last)/2)/1000})
    compiles = [e for e in events if e.get('name') == 'v8.compileModule']
    actual_wasm_compile_events = [e for e in events if re.search('liftoff|turbofan|tier|wasm.*compil|compil.*wasm',e.get('name',''),re.I)]
    output[dictionary] = {'traceSha256': hashlib.sha256(raw).hexdigest(),
                          'parserWindowSampleSpanMs': span/1000,
                          'function13GlobalQuartileSelfMs': bins,
                          'workers': summaries,
                          'jsCompileModuleEvents': len(compiles),
                          'jsCompileModuleSummedWallMs': sum(e.get('dur',0) for e in compiles)/1000,
                          'wasmCompilationOrTieringEventCount': len(actual_wasm_compile_events)}

report = {'scope': 'Existing diagnostic trace only. V8 sampled wall attribution can include descheduling and is not exact CPU cost. Parser window is first-to-last sampled parser activity, not the full import boundary. Configured categories omit v8.wasm compilation/tiering; absent events cannot establish zero compilation or a code tier. Function 13 is mapped to parse_composite_span_impl by a byte-identical named rebuild.', 'dictionaries': output}
(root/'parser-cold-path-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
