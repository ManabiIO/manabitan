import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir, open, writeFile} from 'node:fs/promises';
import {join} from 'node:path';

const digest = (bytes) => createHash('sha256').update(bytes).digest('hex');

export async function createCanonicalCorpus(outputPath) {
    const directory = `${outputPath}.groups`;
    await mkdir(directory, {recursive: false});
    const groups = [];
    return {
        directory, groups,
        async append(chunk, progress) {
            const number = groups.length;
            const name = `group-${String(number).padStart(4, '0')}`;
            const columns = {};
            let position = 0;
            const file = await open(join(directory, `${name}.bin`), 'wx');
            async function encode(value, label) {
                if (!ArrayBuffer.isView(value)) {
                    assert(value === null || typeof value !== 'object', `Unexpected object: ${label}`);
                    return value;
                }
                const padding = (8 - position % 8) % 8;
                if (padding) { await file.writeFile(new Uint8Array(padding)); position += padding; }
                const bytes = new Uint8Array(value.buffer, value.byteOffset, value.byteLength);
                const descriptor = {type: value.constructor.name, position, length: value.length, byteLength: value.byteLength, sha256: digest(bytes)};
                await file.writeFile(bytes);
                position += bytes.byteLength;
                columns[label] = descriptor;
                return {$column: label};
            }
            const data = {};
            try {
                for (const field of ['rowCount', 'contentRowStart', 'contentBytesBaseOffset', 'contentBytesLength', 'contentMetaByUniqueIndex', 'useResolvedContentReferences', 'contentBytesBuffer', 'contentMetaList', 'contentUniqueIndexList']) {
                    if (typeof chunk[field] !== 'undefined') data[field] = await encode(chunk[field], field);
                }
                const plan = {};
                for (const [key, value] of Object.entries(chunk.contentDedupPlan)) {
                    if (typeof value !== 'undefined') plan[key] = await encode(value, `plan.${key}`);
                }
                data.contentDedupPlan = plan;
                data.dictionaryTotalRows = progress.totalRows;
            } finally {
                await file.close();
            }
            const header = {number, binary: `${name}.bin`, byteLength: position, progress, chunk: data, columns};
            const text = JSON.stringify(header, null, 2) + '\n';
            await writeFile(join(directory, `${name}.json`), text, {flag: 'wx'});
            const entry = {number, header: `${name}.json`, headerSha256: digest(text), rows: chunk.rowCount, uniqueCount: chunk.contentDedupPlan.uniqueCount, contentBytes: chunk.contentBytesLength, byteLength: position};
            groups.push(entry);
            return entry;
        },
    };
}
