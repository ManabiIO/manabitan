	.file	"term-bank-parser-composite-minsize.c"
	.globaltype	__stack_pointer, i32
	.functype	memset (i32, i32, i32) -> (i32)
	.functype	memcpy (i32, i32, i32) -> (i32)
	.functype	inflate_and_join_term_banks (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	term_bank_inflate (i32, i32, i32, i32) -> (i32)
	.functype	crc32_bytes (i32, i32) -> (i32)
	.functype	inflate_zip_media_batch (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	verify_term_bank_source_crcs (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	crc32_update_gap (i32, i32, i32) -> (i32)
	.functype	wasm_reset_heap () -> ()
	.functype	wasm_alloc (i32) -> (i32)
	.functype	wasm_get_last_parse_capacity () -> (i32)
	.functype	wasm_get_last_content_capacity () -> (i32)
	.functype	project_single_glossary_image_path (i32, i32) -> (i64)
	.functype	project_glossary_image_value (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_term_bank (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_term_bank_impl (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_term_bank_with_media_hints (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content (i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_impl (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_no_hash (i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_token_binary (i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_token_binary_row (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	build_term_string_plan (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	content_bytes_equal (i32, i32, i32, i32) -> (i32)
	.functype	decode_escaped_key (i32, i32, i32, i32) -> (i32)
	.functype	hash_content_xxh32 (i32, i32, i32) -> (i32)
	.functype	copy_valid_utf8 (i32, i32, i32) -> (i32)
	.functype	encode_term_lookup_index (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_token_binary_dedup (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_and_encode_term_bank_token_binary_dedup (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	next_term_bank (i32) -> (i32)
	.functype	parse_row_single_pass (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	scan_scalar_span (i32, i32, i32, i32) -> (i32)
	.functype	parse_int32_token (i32, i32, i32, i32, i32) -> (i32)
	.functype	raw_term_content_hash (i32, i32) -> (i32)
	.functype	raw_term_content_tokens_equal (i32, i32, i32, i32) -> (i32)
	.functype	raw_term_content_quick_signature (i32, i32) -> (i32)
	.functype	next_term_row (i32, i32) -> (i32)
	.functype	compact_term_lookup_keys (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_value_span (i32, i32, i32, i32) -> (i32)
	.functype	parse_scalar_span (i32, i32, i32, i32) -> (i32)
	.functype	is_valid_json_number (i32, i32, i32) -> (i32)
	.functype	parse_composite_span_impl (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	json_string_matches_ascii_escaped (i32, i32, i32, i32, i32) -> (i32)
	.functype	key_hex4 (i32) -> (i32)
	.functype	write_normalized_glossary_value (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	hash_content_xxh32_pair (i32, i32, i32, i32) -> ()
	.functype	reuse_validated_glossary (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_value_span_with_glossary_hints (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	next_format3_field (i32, i32, i32) -> (i32)
	.section	.text.memset,"",@
	.hidden	memset                          # -- Begin function memset
	.globl	memset
	.type	memset,@function
memset:                                 # @memset
	.functype	memset (i32, i32, i32) -> (i32)
# %bb.0:
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label0
# %bb.1:
	local.get	0
	local.get	1
	local.get	2
	memory.fill	0
.LBB0_2:
	end_block                               # label0:
	local.get	0
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.memcpy,"",@
	.hidden	memcpy                          # -- Begin function memcpy
	.globl	memcpy
	.type	memcpy,@function
memcpy:                                 # @memcpy
	.functype	memcpy (i32, i32, i32) -> (i32)
# %bb.0:
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label1
# %bb.1:
	local.get	0
	local.get	1
	local.get	2
	memory.copy	0, 0
.LBB1_2:
	end_block                               # label1:
	local.get	0
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.inflate_and_join_term_banks,"",@
	.globl	inflate_and_join_term_banks     # -- Begin function inflate_and_join_term_banks
	.type	inflate_and_join_term_banks,@function
inflate_and_join_term_banks:            # @inflate_and_join_term_banks
	.functype	inflate_and_join_term_banks (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-1
	local.set	12
	block   	
	local.get	7
	i32.eqz
	br_if   	0                               # 0: down to label2
# %bb.1:
	local.get	9
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label2
# %bb.2:
	block   	
	local.get	10
	br_if   	0                               # 0: down to label3
# %bb.3:
	local.get	11
	br_if   	1                               # 1: down to label2
.LBB2_4:
	end_block                               # label3:
	block   	
	local.get	10
	br_if   	0                               # 0: down to label4
# %bb.5:
	local.get	8
	i32.const	91
	i32.store8	0
.LBB2_6:
	end_block                               # label4:
	local.get	10
	i32.eqz
	local.set	13
	local.get	8
	i32.const	1
	i32.add 
	local.set	14
	i32.const	0
	local.set	15
	i32.const	0
	local.set	16
.LBB2_7:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB2_21 Depth 2
                                        #     Child Loop BB2_28 Depth 2
                                        #     Child Loop BB2_38 Depth 2
                                        #     Child Loop BB2_43 Depth 2
	loop    	                                # label5:
	i32.const	-1
	local.set	12
	local.get	1
	local.get	2
	local.get	16
	i32.const	2
	i32.shl 
	local.tee	17
	i32.add 
	i32.load	0
	local.tee	18
	i32.lt_u
	br_if   	1                               # 1: down to label2
# %bb.8:                                #   in Loop: Header=BB2_7 Depth=1
	local.get	3
	local.get	17
	i32.add 
	i32.load	0
	local.tee	19
	local.get	1
	local.get	18
	i32.sub 
	i32.gt_u
	br_if   	1                               # 1: down to label2
# %bb.9:                                #   in Loop: Header=BB2_7 Depth=1
	local.get	4
	local.get	17
	i32.add 
	i32.load	0
	local.tee	20
	local.get	9
	local.get	13
	i32.sub 
	i32.gt_u
	br_if   	1                               # 1: down to label2
# %bb.10:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	8
	local.get	13
	i32.add 
	local.set	21
	i32.const	-1
	local.set	12
	block   	
	block   	
	block   	
	local.get	5
	local.get	17
	i32.add 
	i32.load	0
	br_table 	{0, 4, 4, 4, 4, 4, 4, 4, 1, 4} # 4: down to label2
                                        # 1: down to label7
.LBB2_11:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label8:
	block   	
	local.get	19
	local.get	20
	i32.eq  
	br_if   	0                               # 0: down to label9
# %bb.12:
	i32.const	-3
	return
.LBB2_13:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label9:
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label6
# %bb.14:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	21
	local.get	0
	local.get	18
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label6
.LBB2_15:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label7:
	local.get	0
	local.get	18
	i32.add 
	local.get	19
	local.get	21
	local.get	20
	call	term_bank_inflate
	local.tee	12
	br_if   	2                               # 2: down to label2
.LBB2_16:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label6:
	block   	
	local.get	11
	br_if   	0                               # 0: down to label10
# %bb.17:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	21
	local.get	20
	call	crc32_bytes
	local.get	6
	local.get	17
	i32.add 
	i32.load	0
	i32.eq  
	br_if   	0                               # 0: down to label10
# %bb.18:
	i32.const	-4
	return
.LBB2_19:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label10:
	local.get	20
	local.set	17
	local.get	20
	local.set	18
	block   	
	local.get	20
	i32.eqz
	br_if   	0                               # 0: down to label11
# %bb.20:                               #   in Loop: Header=BB2_7 Depth=1
	i32.const	0
	local.set	17
.LBB2_21:                               #   Parent Loop BB2_7 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label13:
	local.get	21
	local.get	17
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label12
# %bb.22:                               #   in Loop: Header=BB2_21 Depth=2
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label12
# %bb.23:                               #   in Loop: Header=BB2_21 Depth=2
	local.get	20
	local.get	17
	i32.const	1
	i32.add 
	local.tee	17
	i32.ne  
	br_if   	0                               # 0: up to label13
# %bb.24:                               #   in Loop: Header=BB2_7 Depth=1
	end_loop
	local.get	20
	local.set	17
	local.get	20
	local.set	18
	br      	1                               # 1: down to label11
.LBB2_25:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label12:
	block   	
	local.get	20
	local.get	17
	i32.gt_u
	br_if   	0                               # 0: down to label14
# %bb.26:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	20
	local.set	18
	br      	1                               # 1: down to label11
.LBB2_27:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label14:
	local.get	21
	i32.const	-1
	i32.add 
	local.set	19
	local.get	20
	local.set	18
.LBB2_28:                               #   Parent Loop BB2_7 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label15:
	local.get	19
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	12
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label11
# %bb.29:                               #   in Loop: Header=BB2_28 Depth=2
	i32.const	1
	local.get	12
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label11
# %bb.30:                               #   in Loop: Header=BB2_28 Depth=2
	local.get	18
	i32.const	-1
	i32.add 
	local.tee	18
	local.get	17
	i32.gt_u
	br_if   	0                               # 0: up to label15
# %bb.31:                               #   in Loop: Header=BB2_7 Depth=1
	end_loop
	local.get	17
	local.set	18
.LBB2_32:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label11:
	i32.const	-5
	local.set	12
	local.get	18
	local.get	17
	i32.sub 
	i32.const	2
	i32.lt_u
	br_if   	1                               # 1: down to label2
# %bb.33:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	21
	local.get	17
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	1                               # 1: down to label2
# %bb.34:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	21
	local.get	18
	i32.add 
	i32.const	-1
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	1                               # 1: down to label2
# %bb.35:                               #   in Loop: Header=BB2_7 Depth=1
	block   	
	local.get	10
	br_if   	0                               # 0: down to label16
# %bb.36:                               #   in Loop: Header=BB2_7 Depth=1
	block   	
	block   	
	local.get	17
	i32.const	1
	i32.add 
	local.tee	12
	local.get	18
	i32.const	-1
	i32.add 
	local.tee	20
	i32.ge_u
	br_if   	0                               # 0: down to label18
# %bb.37:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	14
	local.get	13
	i32.add 
	local.set	12
	local.get	18
	i32.const	-2
	i32.add 
	local.set	19
.LBB2_38:                               #   Parent Loop BB2_7 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label20:
	local.get	12
	local.get	17
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label19
# %bb.39:                               #   in Loop: Header=BB2_38 Depth=2
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label19
# %bb.40:                               #   in Loop: Header=BB2_38 Depth=2
	local.get	19
	local.get	17
	i32.const	1
	i32.add 
	local.tee	17
	i32.eq  
	br_if   	3                               # 3: down to label17
	br      	0                               # 0: up to label20
.LBB2_41:                               #   in Loop: Header=BB2_7 Depth=1
	end_loop
	end_block                               # label19:
	local.get	17
	i32.const	1
	i32.add 
	local.set	12
.LBB2_42:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label18:
	block   	
	local.get	20
	local.get	12
	i32.le_u
	br_if   	0                               # 0: down to label21
.LBB2_43:                               #   Parent Loop BB2_7 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label22:
	local.get	21
	local.get	20
	i32.add 
	i32.const	-1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	17
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label21
# %bb.44:                               #   in Loop: Header=BB2_43 Depth=2
	i32.const	1
	local.get	17
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label21
# %bb.45:                               #   in Loop: Header=BB2_43 Depth=2
	local.get	20
	i32.const	-1
	i32.add 
	local.tee	20
	local.get	12
	i32.gt_u
	br_if   	0                               # 0: up to label22
	br      	2                               # 2: down to label17
.LBB2_46:                               #   in Loop: Header=BB2_7 Depth=1
	end_loop
	end_block                               # label21:
	local.get	20
	local.get	12
	i32.eq  
	br_if   	0                               # 0: down to label17
# %bb.47:                               #   in Loop: Header=BB2_7 Depth=1
	block   	
	local.get	15
	i32.eqz
	br_if   	0                               # 0: down to label23
# %bb.48:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	21
	i32.const	44
	i32.store8	0
	local.get	13
	i32.const	1
	i32.add 
	local.set	13
.LBB2_49:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label23:
	local.get	20
	local.get	12
	i32.sub 
	local.set	17
	block   	
	local.get	8
	local.get	13
	i32.add 
	local.tee	18
	local.get	21
	local.get	12
	i32.add 
	local.tee	20
	i32.eq  
	br_if   	0                               # 0: down to label24
# %bb.50:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	17
	i32.eqz
	br_if   	0                               # 0: down to label24
# %bb.51:                               #   in Loop: Header=BB2_7 Depth=1
	local.get	18
	local.get	20
	local.get	17
	memory.copy	0, 0
.LBB2_52:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label24:
	local.get	15
	i32.const	1
	i32.add 
	local.set	15
	local.get	13
	local.get	17
	i32.add 
	local.set	13
.LBB2_53:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label17:
	local.get	16
	i32.const	1
	i32.add 
	local.tee	16
	local.get	7
	i32.ne  
	br_if   	1                               # 1: up to label5
# %bb.54:
	i32.const	-1
	local.set	12
	local.get	13
	local.get	9
	i32.ge_u
	br_if   	2                               # 2: down to label2
# %bb.55:
	local.get	8
	local.get	13
	i32.add 
	i32.const	93
	i32.store8	0
	local.get	13
	i32.const	1
	i32.add 
	local.set	12
	br      	2                               # 2: down to label2
.LBB2_56:                               #   in Loop: Header=BB2_7 Depth=1
	end_block                               # label16:
	local.get	10
	local.get	16
	i32.const	3
	i32.shl 
	i32.add 
	local.tee	17
	local.get	20
	i32.store	4
	local.get	17
	local.get	13
	i32.store	0
	local.get	20
	local.get	13
	i32.add 
	local.tee	13
	local.set	12
	local.get	16
	i32.const	1
	i32.add 
	local.tee	16
	local.get	7
	i32.ne  
	br_if   	0                               # 0: up to label5
.LBB2_57:
	end_loop
	end_block                               # label2:
	local.get	12
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.crc32_bytes,"",@
	.type	crc32_bytes,@function           # -- Begin function crc32_bytes
crc32_bytes:                            # @crc32_bytes
	.functype	crc32_bytes (i32, i32) -> (i32)
	.local  	v128, i32, v128, v128, v128, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64
# %bb.0:
	block   	
	i32.const	0
	i32.load8_u	crc32_table_initialized
	br_if   	0                               # 0: down to label25
# %bb.1:
	v128.const	0, 1, 2, 3
	local.set	2
	i32.const	-1024
	local.set	3
.LBB3_2:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label26:
	local.get	3
	i32.const	crc32_table+1024
	i32.add 
	local.get	2
	v128.const	2, 2, 2, 2
	v128.and
	v128.const	0, 0, 0, 0
	local.tee	4
	i32x4.ne
	v128.const	-306674912, -306674912, -306674912, -306674912
	local.tee	5
	v128.and
	local.get	2
	v128.const	1, 1, 1, 1
	v128.and
	local.get	4
	i32x4.ne
	local.get	5
	v128.and
	local.get	2
	i32.const	1
	i32x4.shr_u
	v128.xor
	local.tee	6
	i32.const	1
	i32x4.shr_u
	v128.xor
	local.tee	7
	v128.const	32, 32, 32, 32
	local.tee	8
	v128.and
	local.get	4
	i32x4.ne
	local.get	5
	v128.and
	local.get	6
	local.get	8
	v128.and
	local.get	4
	i32x4.ne
	v128.const	1994146192, 1994146192, 1994146192, 1994146192
	v128.and
	local.get	2
	local.get	8
	v128.and
	local.get	4
	i32x4.ne
	v128.const	997073096, 997073096, 997073096, 997073096
	v128.and
	local.get	2
	v128.const	16, 16, 16, 16
	v128.and
	local.get	4
	i32x4.ne
	v128.const	498536548, 498536548, 498536548, 498536548
	v128.and
	local.get	2
	v128.const	8, 8, 8, 8
	v128.and
	local.get	4
	i32x4.ne
	v128.const	249268274, 249268274, 249268274, 249268274
	v128.and
	local.get	2
	v128.const	4, 4, 4, 4
	local.tee	5
	v128.and
	local.get	4
	i32x4.ne
	v128.const	124634137, 124634137, 124634137, 124634137
	v128.and
	local.get	7
	i32.const	6
	i32x4.shr_u
	v128.xor
	v128.xor
	v128.xor
	v128.xor
	v128.xor
	v128.xor
	v128.store	0
	local.get	2
	local.get	5
	i32x4.add
	local.set	2
	local.get	3
	i32.const	16
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label26
# %bb.3:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_4:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label27:
	local.get	3
	i32.const	crc32_table+2048
	i32.add 
	local.get	3
	i32.const	crc32_table+1024
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+2052
	i32.add 
	local.get	3
	i32.const	crc32_table+1028
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label27
# %bb.5:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_6:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label28:
	local.get	3
	i32.const	crc32_table+3072
	i32.add 
	local.get	3
	i32.const	crc32_table+2048
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+3076
	i32.add 
	local.get	3
	i32.const	crc32_table+2052
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label28
# %bb.7:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_8:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label29:
	local.get	3
	i32.const	crc32_table+4096
	i32.add 
	local.get	3
	i32.const	crc32_table+3072
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+4100
	i32.add 
	local.get	3
	i32.const	crc32_table+3076
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label29
# %bb.9:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_10:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label30:
	local.get	3
	i32.const	crc32_table+5120
	i32.add 
	local.get	3
	i32.const	crc32_table+4096
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+5124
	i32.add 
	local.get	3
	i32.const	crc32_table+4100
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label30
# %bb.11:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_12:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label31:
	local.get	3
	i32.const	crc32_table+6144
	i32.add 
	local.get	3
	i32.const	crc32_table+5120
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+6148
	i32.add 
	local.get	3
	i32.const	crc32_table+5124
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label31
# %bb.13:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_14:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label32:
	local.get	3
	i32.const	crc32_table+7168
	i32.add 
	local.get	3
	i32.const	crc32_table+6144
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+7172
	i32.add 
	local.get	3
	i32.const	crc32_table+6148
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label32
# %bb.15:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_16:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label33:
	local.get	3
	i32.const	crc32_table+8192
	i32.add 
	local.get	3
	i32.const	crc32_table+7168
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+8196
	i32.add 
	local.get	3
	i32.const	crc32_table+7172
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label33
# %bb.17:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_18:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label34:
	local.get	3
	i32.const	crc32_table+9216
	i32.add 
	local.get	3
	i32.const	crc32_table+8192
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+9220
	i32.add 
	local.get	3
	i32.const	crc32_table+8196
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label34
# %bb.19:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_20:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label35:
	local.get	3
	i32.const	crc32_table+10240
	i32.add 
	local.get	3
	i32.const	crc32_table+9216
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+10244
	i32.add 
	local.get	3
	i32.const	crc32_table+9220
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label35
# %bb.21:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_22:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label36:
	local.get	3
	i32.const	crc32_table+11264
	i32.add 
	local.get	3
	i32.const	crc32_table+10240
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+11268
	i32.add 
	local.get	3
	i32.const	crc32_table+10244
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label36
# %bb.23:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_24:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label37:
	local.get	3
	i32.const	crc32_table+12288
	i32.add 
	local.get	3
	i32.const	crc32_table+11264
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+12292
	i32.add 
	local.get	3
	i32.const	crc32_table+11268
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label37
# %bb.25:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_26:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label38:
	local.get	3
	i32.const	crc32_table+13312
	i32.add 
	local.get	3
	i32.const	crc32_table+12288
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+13316
	i32.add 
	local.get	3
	i32.const	crc32_table+12292
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label38
# %bb.27:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_28:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label39:
	local.get	3
	i32.const	crc32_table+14336
	i32.add 
	local.get	3
	i32.const	crc32_table+13312
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+14340
	i32.add 
	local.get	3
	i32.const	crc32_table+13316
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label39
# %bb.29:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_30:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label40:
	local.get	3
	i32.const	crc32_table+15360
	i32.add 
	local.get	3
	i32.const	crc32_table+14336
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+15364
	i32.add 
	local.get	3
	i32.const	crc32_table+14340
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label40
# %bb.31:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_32:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label41:
	local.get	3
	i32.const	crc32_table+16384
	i32.add 
	local.get	3
	i32.const	crc32_table+15360
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+16388
	i32.add 
	local.get	3
	i32.const	crc32_table+15364
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label41
# %bb.33:
	end_loop
	i32.const	0
	i32.const	1
	i32.store8	crc32_table_initialized
.LBB3_34:
	end_block                               # label25:
	block   	
	block   	
	block   	
	block   	
	local.get	1
	i32.const	262143
	i32.gt_u
	br_if   	0                               # 0: down to label45
# %bb.35:
	block   	
	local.get	1
	i32.const	16
	i32.ge_u
	br_if   	0                               # 0: down to label46
# %bb.36:
	i32.const	0
	local.set	9
	i32.const	-1
	local.set	3
	br      	3                               # 3: down to label43
.LBB3_37:
	end_block                               # label46:
	i32.const	-1
	local.set	3
	local.get	1
	local.set	10
	local.get	0
	local.set	9
.LBB3_38:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label47:
	local.get	9
	i32.load	0:p2align=0
	local.get	3
	i32.xor 
	local.tee	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+14336
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+15360
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+13312
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+12288
	i32.xor 
	local.get	9
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+11264
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+10240
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+9216
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+8192
	i32.xor 
	local.get	9
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	9
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.set	3
	local.get	9
	i32.const	16
	i32.add 
	local.set	9
	local.get	10
	i32.const	-16
	i32.add 
	local.tee	10
	i32.const	15
	i32.gt_u
	br_if   	0                               # 0: up to label47
	br      	2                               # 2: down to label44
.LBB3_39:
	end_loop
	end_block                               # label45:
	i32.const	0
	local.set	10
	block   	
	i32.const	0
	i32.load8_u	crc32_braid_initialized
	br_if   	0                               # 0: down to label48
# %bb.40:
.LBB3_41:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_42 Depth 2
	loop    	                                # label49:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table
	local.set	3
	i32.const	56
	local.set	9
.LBB3_42:                               #   Parent Loop BB3_41 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label50:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label50
# %bb.43:                               #   in Loop: Header=BB3_41 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label49
# %bb.44:
	end_loop
	i32.const	0
	local.set	10
.LBB3_45:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_46 Depth 2
	loop    	                                # label51:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+1024
	local.set	3
	i32.const	56
	local.set	9
.LBB3_46:                               #   Parent Loop BB3_45 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label52:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label52
# %bb.47:                               #   in Loop: Header=BB3_45 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+1024
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label51
# %bb.48:
	end_loop
	i32.const	0
	local.set	10
.LBB3_49:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_50 Depth 2
	loop    	                                # label53:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+2048
	local.set	3
	i32.const	56
	local.set	9
.LBB3_50:                               #   Parent Loop BB3_49 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label54:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label54
# %bb.51:                               #   in Loop: Header=BB3_49 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+2048
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label53
# %bb.52:
	end_loop
	i32.const	0
	local.set	10
.LBB3_53:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_54 Depth 2
	loop    	                                # label55:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+3072
	local.set	3
	i32.const	56
	local.set	9
.LBB3_54:                               #   Parent Loop BB3_53 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label56:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label56
# %bb.55:                               #   in Loop: Header=BB3_53 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+3072
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label55
# %bb.56:
	end_loop
	i32.const	0
	local.set	10
.LBB3_57:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_58 Depth 2
	loop    	                                # label57:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+4096
	local.set	3
	i32.const	56
	local.set	9
.LBB3_58:                               #   Parent Loop BB3_57 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label58:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label58
# %bb.59:                               #   in Loop: Header=BB3_57 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+4096
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label57
# %bb.60:
	end_loop
	i32.const	0
	local.set	10
.LBB3_61:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_62 Depth 2
	loop    	                                # label59:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+5120
	local.set	3
	i32.const	56
	local.set	9
.LBB3_62:                               #   Parent Loop BB3_61 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label60:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label60
# %bb.63:                               #   in Loop: Header=BB3_61 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+5120
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label59
# %bb.64:
	end_loop
	i32.const	0
	local.set	10
.LBB3_65:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_66 Depth 2
	loop    	                                # label61:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+6144
	local.set	3
	i32.const	56
	local.set	9
.LBB3_66:                               #   Parent Loop BB3_65 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label62:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label62
# %bb.67:                               #   in Loop: Header=BB3_65 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+6144
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label61
# %bb.68:
	end_loop
	i32.const	0
	local.set	10
.LBB3_69:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_70 Depth 2
	loop    	                                # label63:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+7168
	local.set	3
	i32.const	56
	local.set	9
.LBB3_70:                               #   Parent Loop BB3_69 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label64:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label64
# %bb.71:                               #   in Loop: Header=BB3_69 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+7168
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label63
# %bb.72:
	end_loop
	i32.const	0
	i32.const	1
	i32.store8	crc32_braid_initialized
.LBB3_73:
	end_block                               # label48:
	local.get	1
	i32.const	-64
	i32.and 
	local.tee	12
	i32.const	-64
	i32.add 
	local.set	13
	i32.const	-1
	local.set	11
	i32.const	0
	local.set	14
	i32.const	0
	local.set	15
	i32.const	0
	local.set	16
	i32.const	0
	local.set	17
	i32.const	0
	local.set	18
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
	i32.const	0
	local.set	10
.LBB3_74:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label65:
	local.get	11
	local.get	0
	local.get	10
	i32.add 
	local.tee	3
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	11
	local.get	14
	local.get	3
	i32.const	56
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	14
	local.get	15
	local.get	3
	i32.const	48
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	15
	local.get	16
	local.get	3
	i32.const	40
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	16
	local.get	17
	local.get	3
	i32.const	32
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	17
	local.get	18
	local.get	3
	i32.const	24
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	18
	local.get	19
	local.get	3
	i32.const	16
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	19
	local.get	20
	local.get	3
	i32.const	8
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	20
	local.get	10
	i32.const	64
	i32.add 
	local.tee	10
	local.get	13
	i32.lt_u
	br_if   	0                               # 0: up to label65
# %bb.75:
	end_loop
	local.get	11
	local.get	0
	local.get	13
	i32.add 
	local.tee	3
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	8:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	20
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	16:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	19
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	24:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	18
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	32:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	17
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	40:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	16
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	48:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	15
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	56:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	14
	i32.xor 
	local.tee	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.set	3
	local.get	12
	local.get	1
	i32.eq  
	br_if   	2                               # 2: down to label42
# %bb.76:
.LBB3_77:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label66:
	local.get	0
	local.get	12
	i32.add 
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	12
	i32.const	1
	i32.add 
	local.tee	12
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: up to label66
	br      	3                               # 3: down to label42
.LBB3_78:
	end_loop
	end_block                               # label44:
	local.get	1
	i32.const	262128
	i32.and 
	local.set	9
.LBB3_79:
	end_block                               # label43:
	local.get	9
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label42
# %bb.80:
	local.get	9
	i32.const	1
	i32.or  
	local.set	10
	block   	
	local.get	1
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label67
# %bb.81:
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	10
	local.set	9
.LBB3_82:
	end_block                               # label67:
	local.get	1
	local.get	10
	i32.eq  
	br_if   	0                               # 0: down to label42
# %bb.83:
	local.get	1
	local.get	9
	i32.sub 
	local.set	10
	local.get	0
	local.get	9
	i32.add 
	local.set	9
.LBB3_84:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label68:
	local.get	9
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.get	9
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	2
	i32.add 
	local.set	9
	local.get	10
	i32.const	-2
	i32.add 
	local.tee	10
	br_if   	0                               # 0: up to label68
.LBB3_85:
	end_loop
	end_block                               # label42:
	local.get	3
	i32.const	-1
	i32.xor 
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.inflate_zip_media_batch,"",@
	.globl	inflate_zip_media_batch         # -- Begin function inflate_zip_media_batch
	.type	inflate_zip_media_batch,@function
inflate_zip_media_batch:                # @inflate_zip_media_batch
	.functype	inflate_zip_media_batch (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	block   	
	local.get	7
	br_if   	0                               # 0: down to label69
# %bb.1:
	i32.const	-1
	return
.LBB4_2:
	end_block                               # label69:
	i32.const	0
	local.set	11
	local.get	10
	local.set	12
.LBB4_3:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label70:
	block   	
	local.get	1
	local.get	2
	i32.load	0
	local.tee	13
	i32.ge_u
	br_if   	0                               # 0: down to label71
# %bb.4:
	i32.const	-1
	return
.LBB4_5:                                #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label71:
	block   	
	local.get	3
	i32.load	0
	local.tee	14
	local.get	1
	local.get	13
	i32.sub 
	i32.le_u
	br_if   	0                               # 0: down to label72
# %bb.6:
	i32.const	-1
	return
.LBB4_7:                                #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label72:
	block   	
	local.get	4
	i32.load	0
	local.tee	15
	local.get	11
	i32.const	2147483647
	i32.xor 
	i32.le_u
	br_if   	0                               # 0: down to label73
# %bb.8:
	i32.const	-1
	return
.LBB4_9:                                #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label73:
	block   	
	block   	
	local.get	10
	br_if   	0                               # 0: down to label75
# %bb.10:                               #   in Loop: Header=BB4_3 Depth=1
	i32.const	0
	local.set	16
	br      	1                               # 1: down to label74
.LBB4_11:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label75:
	block   	
	local.get	9
	local.get	11
	i32.ge_u
	br_if   	0                               # 0: down to label76
# %bb.12:
	i32.const	-1
	return
.LBB4_13:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label76:
	block   	
	local.get	15
	local.get	9
	local.get	11
	i32.sub 
	i32.le_u
	br_if   	0                               # 0: down to label77
# %bb.14:
	i32.const	-1
	return
.LBB4_15:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label77:
	local.get	12
	local.get	11
	i32.store	0
	local.get	11
	local.set	16
.LBB4_16:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label74:
	local.get	0
	local.get	13
	i32.add 
	local.set	17
	local.get	8
	local.get	16
	i32.add 
	local.set	13
	i32.const	-1
	local.set	16
	block   	
	block   	
	block   	
	block   	
	local.get	5
	i32.load	0
	br_table 	{0, 3, 3, 3, 3, 3, 3, 3, 1, 3} # 3: down to label78
                                        # 1: down to label80
.LBB4_17:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label81:
	block   	
	local.get	14
	local.get	15
	i32.eq  
	br_if   	0                               # 0: down to label82
# %bb.18:
	i32.const	-3
	return
.LBB4_19:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label82:
	block   	
	local.get	10
	br_if   	0                               # 0: down to label83
# %bb.20:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	17
	local.set	13
	br      	2                               # 2: down to label79
.LBB4_21:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label83:
	local.get	14
	i32.eqz
	br_if   	1                               # 1: down to label79
# %bb.22:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	13
	local.get	17
	local.get	14
	memory.copy	0, 0
	br      	1                               # 1: down to label79
.LBB4_23:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label80:
	block   	
	local.get	10
	br_if   	0                               # 0: down to label84
# %bb.24:                               #   in Loop: Header=BB4_3 Depth=1
	block   	
	local.get	14
	i32.const	5
	i32.lt_u
	br_if   	0                               # 0: down to label85
# %bb.25:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	14
	i32.const	-5
	i32.add 
	local.get	15
	i32.ne  
	br_if   	0                               # 0: down to label85
# %bb.26:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	15
	i32.const	65535
	i32.gt_u
	br_if   	0                               # 0: down to label85
# %bb.27:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	17
	i32.load8_u	0
	i32.const	7
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label85
# %bb.28:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	17
	i32.load16_u	1:p2align=0
	local.get	15
	i32.ne  
	br_if   	0                               # 0: down to label85
# %bb.29:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	17
	i32.load16_u	3:p2align=0
	local.get	15
	i32.xor 
	i32.const	65535
	i32.ne  
	br_if   	0                               # 0: down to label85
# %bb.30:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	17
	i32.const	5
	i32.add 
	local.set	13
	br      	2                               # 2: down to label79
.LBB4_31:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label85:
	local.get	15
	local.get	9
	i32.le_u
	br_if   	0                               # 0: down to label84
# %bb.32:
	i32.const	-1
	return
.LBB4_33:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label84:
	local.get	17
	local.get	14
	local.get	13
	local.get	15
	call	term_bank_inflate
	local.tee	16
	br_if   	1                               # 1: down to label78
.LBB4_34:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label79:
	block   	
	local.get	13
	local.get	15
	call	crc32_bytes
	local.get	6
	i32.load	0
	i32.eq  
	br_if   	0                               # 0: down to label86
# %bb.35:
	i32.const	-4
	return
.LBB4_36:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label86:
	local.get	2
	i32.const	4
	i32.add 
	local.set	2
	local.get	3
	i32.const	4
	i32.add 
	local.set	3
	local.get	4
	i32.const	4
	i32.add 
	local.set	4
	local.get	12
	i32.const	4
	i32.add 
	local.set	12
	local.get	5
	i32.const	4
	i32.add 
	local.set	5
	local.get	6
	i32.const	4
	i32.add 
	local.set	6
	local.get	15
	local.get	11
	i32.add 
	local.tee	11
	local.set	16
	local.get	7
	i32.const	-1
	i32.add 
	local.tee	7
	br_if   	1                               # 1: up to label70
.LBB4_37:
	end_block                               # label78:
	end_loop
	local.get	16
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.verify_term_bank_source_crcs,"",@
	.globl	verify_term_bank_source_crcs    # -- Begin function verify_term_bank_source_crcs
	.type	verify_term_bank_source_crcs,@function
verify_term_bank_source_crcs:           # @verify_term_bank_source_crcs
	.functype	verify_term_bank_source_crcs (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	528
	i32.sub 
	local.tee	9
	global.set	__stack_pointer
	i32.const	-1
	local.set	10
	block   	
	local.get	0
	i32.eqz
	br_if   	0                               # 0: down to label87
# %bb.1:
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label87
# %bb.2:
	local.get	3
	i32.eqz
	br_if   	0                               # 0: down to label87
# %bb.3:
	local.get	4
	i32.eqz
	br_if   	0                               # 0: down to label87
# %bb.4:
	block   	
	block   	
	block   	
	block   	
	local.get	6
	i32.eqz
	br_if   	0                               # 0: down to label91
# %bb.5:
	local.get	5
	i32.eqz
	br_if   	4                               # 4: down to label87
# %bb.6:
	local.get	7
	i32.eqz
	br_if   	4                               # 4: down to label87
# %bb.7:
	i32.const	-1
	local.set	10
	local.get	9
	i32.const	-1
	i32.store	12
	local.get	0
	i32.const	0
	call	crc32_bytes
	drop
	local.get	9
	i32.const	464
	i32.add 
	local.set	11
	local.get	9
	i32.const	400
	i32.add 
	local.set	12
	local.get	9
	i32.const	336
	i32.add 
	local.set	13
	local.get	9
	i32.const	272
	i32.add 
	local.set	14
	local.get	9
	i32.const	208
	i32.add 
	local.set	15
	local.get	9
	i32.const	144
	i32.add 
	local.set	16
	local.get	9
	i32.const	12
	i32.add 
	i32.const	68
	i32.add 
	local.set	17
	local.get	9
	i32.const	16
	i32.add 
	local.set	18
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
	i32.const	0
	local.set	21
	i32.const	0
	local.set	22
	i32.const	0
	local.set	23
	i32.const	-1
	local.set	24
	br      	1                               # 1: down to label90
.LBB5_8:
	end_block                               # label91:
	i32.const	-1
	local.set	10
	local.get	9
	i32.const	-1
	i32.store	12
	i32.const	0
	local.set	25
	local.get	0
	i32.const	0
	call	crc32_bytes
	drop
.LBB5_9:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label92:
	local.get	2
	i32.load	0
	local.tee	20
	local.get	25
	i32.ne  
	br_if   	4                               # 4: down to label87
# %bb.10:                               #   in Loop: Header=BB5_9 Depth=1
	local.get	1
	local.get	20
	i32.lt_u
	br_if   	4                               # 4: down to label87
# %bb.11:                               #   in Loop: Header=BB5_9 Depth=1
	local.get	2
	i32.const	4
	i32.add 
	i32.load	0
	local.tee	26
	local.get	1
	local.get	20
	i32.sub 
	i32.gt_u
	br_if   	4                               # 4: down to label87
# %bb.12:                               #   in Loop: Header=BB5_9 Depth=1
	local.get	0
	local.get	25
	i32.add 
	local.get	26
	call	crc32_bytes
	local.get	4
	i32.load	0
	i32.ne  
	br_if   	2                               # 2: down to label89
# %bb.13:                               #   in Loop: Header=BB5_9 Depth=1
	local.get	2
	i32.const	8
	i32.add 
	local.set	2
	local.get	4
	i32.const	4
	i32.add 
	local.set	4
	local.get	26
	local.get	25
	i32.add 
	local.set	25
	local.get	3
	i32.const	-1
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label92
# %bb.14:
	end_loop
	i32.const	0
	local.set	22
	i32.const	0
	local.set	21
	i32.const	0
	local.set	19
	br      	2                               # 2: down to label88
.LBB5_15:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB5_20 Depth 2
                                        #       Child Loop BB5_31 Depth 3
                                        #         Child Loop BB5_34 Depth 4
                                        #         Child Loop BB5_36 Depth 4
	end_block                               # label90:
	loop    	                                # label93:
	local.get	2
	local.get	23
	i32.const	3
	i32.shl 
	i32.add 
	local.tee	27
	i32.load	0
	local.tee	26
	local.get	20
	i32.ne  
	br_if   	3                               # 3: down to label87
# %bb.16:                               #   in Loop: Header=BB5_15 Depth=1
	local.get	1
	local.get	26
	i32.lt_u
	br_if   	3                               # 3: down to label87
# %bb.17:                               #   in Loop: Header=BB5_15 Depth=1
	local.get	27
	i32.load	4
	local.tee	27
	local.get	1
	local.get	26
	i32.sub 
	i32.gt_u
	br_if   	3                               # 3: down to label87
# %bb.18:                               #   in Loop: Header=BB5_15 Depth=1
	local.get	27
	local.get	20
	i32.add 
	local.set	25
	i32.const	0
	local.set	26
	block   	
	local.get	19
	local.get	6
	i32.ge_u
	br_if   	0                               # 0: down to label94
# %bb.19:                               #   in Loop: Header=BB5_15 Depth=1
	i32.const	0
	local.set	26
.LBB5_20:                               #   Parent Loop BB5_15 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB5_31 Depth 3
                                        #         Child Loop BB5_34 Depth 4
                                        #         Child Loop BB5_36 Depth 4
	loop    	                                # label95:
	local.get	25
	local.get	5
	local.get	19
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	27
	i32.load	36
	local.tee	28
	i32.le_u
	br_if   	1                               # 1: down to label94
# %bb.21:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	28
	local.get	20
	i32.lt_u
	br_if   	5                               # 5: down to label87
# %bb.22:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	27
	i32.load	40
	local.tee	29
	i32.eqz
	br_if   	5                               # 5: down to label87
# %bb.23:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	29
	local.get	25
	local.get	28
	i32.sub 
	i32.gt_u
	br_if   	5                               # 5: down to label87
# %bb.24:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	26
	local.get	0
	local.get	20
	i32.add 
	local.get	28
	local.get	20
	i32.sub 
	call	crc32_update_gap
	local.set	30
	block   	
	block   	
	local.get	7
	local.get	19
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	26
	i32.load	0
	local.tee	20
	i32.const	-1
	i32.ne  
	br_if   	0                               # 0: down to label97
# %bb.25:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	0
	local.get	28
	i32.add 
	local.get	29
	call	crc32_bytes
	local.set	31
	br      	1                               # 1: down to label96
.LBB5_26:                               #   in Loop: Header=BB5_20 Depth=2
	end_block                               # label97:
	local.get	20
	local.get	19
	i32.ge_u
	br_if   	6                               # 6: down to label87
# %bb.27:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	5
	local.get	20
	i32.const	68
	i32.mul 
	i32.add 
	i32.load	40
	local.get	29
	i32.ne  
	br_if   	6                               # 6: down to label87
# %bb.28:                               #   in Loop: Header=BB5_20 Depth=2
	local.get	22
	i32.const	1
	i32.add 
	local.set	22
	local.get	29
	local.get	21
	i32.add 
	local.set	21
	local.get	7
	local.get	20
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.set	31
.LBB5_29:                               #   in Loop: Header=BB5_20 Depth=2
	end_block                               # label96:
	local.get	26
	local.get	31
	i32.store	0
	block   	
	local.get	24
	local.get	29
	i32.eq  
	br_if   	0                               # 0: down to label98
# %bb.30:                               #   in Loop: Header=BB5_20 Depth=2
	i32.const	-2147483648
	local.set	24
	i32.const	8388608
	local.set	27
	local.get	29
	local.set	32
.LBB5_31:                               #   Parent Loop BB5_15 Depth=1
                                        #     Parent Loop BB5_20 Depth=2
                                        # =>    This Loop Header: Depth=3
                                        #         Child Loop BB5_34 Depth 4
                                        #         Child Loop BB5_36 Depth 4
	loop    	                                # label99:
	block   	
	block   	
	local.get	32
	i32.const	1
	i32.and 
	br_if   	0                               # 0: down to label101
# %bb.32:                               #   in Loop: Header=BB5_31 Depth=3
	local.get	24
	local.set	33
	br      	1                               # 1: down to label100
.LBB5_33:                               #   in Loop: Header=BB5_31 Depth=3
	end_block                               # label101:
	i32.const	0
	local.set	33
	i32.const	-2147483648
	local.set	20
	local.get	27
	local.set	26
.LBB5_34:                               #   Parent Loop BB5_15 Depth=1
                                        #     Parent Loop BB5_20 Depth=2
                                        #       Parent Loop BB5_31 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	loop    	                                # label102:
	i32.const	0
	local.get	26
	i32.const	1
	i32.and 
	i32.sub 
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.const	0
	local.get	20
	i32.const	1
	i32.shr_u
	local.get	24
	i32.and 
	i32.select
	local.get	26
	i32.const	0
	local.get	20
	local.get	24
	i32.and 
	i32.select
	local.get	33
	i32.xor 
	i32.xor 
	local.set	33
	local.get	20
	i32.const	3
	i32.gt_u
	local.set	35
	local.get	20
	i32.const	2
	i32.shr_u
	local.set	20
	local.get	26
	i32.const	30
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.set	26
	local.get	35
	br_if   	0                               # 0: up to label102
.LBB5_35:                               #   in Loop: Header=BB5_31 Depth=3
	end_loop
	end_block                               # label100:
	i32.const	0
	local.set	24
	i32.const	-2147483648
	local.set	20
	local.get	27
	local.set	26
.LBB5_36:                               #   Parent Loop BB5_15 Depth=1
                                        #     Parent Loop BB5_20 Depth=2
                                        #       Parent Loop BB5_31 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	loop    	                                # label103:
	i32.const	0
	local.get	26
	i32.const	1
	i32.and 
	i32.sub 
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.const	0
	local.get	20
	i32.const	1
	i32.shr_u
	local.get	27
	i32.and 
	i32.select
	local.get	26
	i32.const	0
	local.get	20
	local.get	27
	i32.and 
	i32.select
	local.get	24
	i32.xor 
	i32.xor 
	local.set	24
	local.get	20
	i32.const	3
	i32.gt_u
	local.set	35
	local.get	20
	i32.const	2
	i32.shr_u
	local.set	20
	local.get	26
	i32.const	30
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.set	26
	local.get	35
	br_if   	0                               # 0: up to label103
# %bb.37:                               #   in Loop: Header=BB5_31 Depth=3
	end_loop
	local.get	32
	i32.const	2
	i32.lt_u
	local.set	20
	local.get	24
	local.set	27
	local.get	33
	local.set	24
	local.get	32
	i32.const	1
	i32.shr_u
	local.set	32
	local.get	20
	i32.eqz
	br_if   	0                               # 0: up to label99
# %bb.38:                               #   in Loop: Header=BB5_20 Depth=2
	end_loop
	local.get	9
	i32.const	0
	i32.store	464
	local.get	9
	i32.const	0
	i32.store	400
	local.get	9
	i32.const	0
	i32.store	336
	local.get	9
	i32.const	0
	i32.store	272
	local.get	9
	i32.const	0
	i32.store	208
	local.get	9
	i32.const	0
	i32.store	144
	local.get	9
	i32.const	0
	i32.store	80
	local.get	9
	i32.const	0
	i32.store	16
	local.get	9
	local.get	33
	i32.store	496
	local.get	9
	i32.const	0
	local.get	33
	i32.const	1
	i32.and 
	i32.sub 
	i32.const	-306674912
	i32.and 
	local.get	33
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	26
	i32.store	480
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	local.tee	24
	i32.store	512
	local.get	9
	local.get	33
	i32.const	30
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	27
	i32.store	472
	local.get	9
	local.get	24
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	520
	local.get	9
	local.get	33
	i32.const	29
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	27
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	20
	i32.store	468
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	524
	local.get	9
	local.get	24
	local.get	20
	i32.xor 
	i32.store	516
	local.get	9
	local.get	33
	local.get	27
	i32.xor 
	local.tee	24
	i32.store	504
	local.get	9
	local.get	24
	local.get	20
	i32.xor 
	i32.store	508
	local.get	9
	local.get	33
	local.get	20
	i32.xor 
	i32.store	500
	local.get	9
	local.get	26
	local.get	27
	i32.xor 
	local.tee	24
	i32.store	488
	local.get	9
	local.get	24
	local.get	20
	i32.xor 
	i32.store	492
	local.get	9
	local.get	26
	local.get	20
	i32.xor 
	i32.store	484
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	476
	local.get	9
	local.get	33
	i32.const	28
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	20
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.store	432
	local.get	9
	local.get	33
	i32.const	27
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	35
	i32.store	416
	local.get	9
	local.get	34
	local.get	35
	i32.xor 
	local.tee	32
	i32.store	448
	local.get	9
	local.get	33
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	35
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	24
	i32.store	408
	local.get	9
	local.get	32
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	456
	local.get	9
	local.get	26
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	24
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	26
	i32.store	404
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	460
	local.get	9
	local.get	32
	local.get	26
	i32.xor 
	i32.store	452
	local.get	9
	local.get	34
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	440
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	444
	local.get	9
	local.get	34
	local.get	26
	i32.xor 
	i32.store	436
	local.get	9
	local.get	35
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	424
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	428
	local.get	9
	local.get	35
	local.get	26
	i32.xor 
	i32.store	420
	local.get	9
	local.get	24
	local.get	26
	i32.xor 
	i32.store	412
	local.get	9
	local.get	27
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	33
	i32.store	368
	local.get	9
	local.get	20
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	33
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	32
	i32.store	352
	local.get	9
	local.get	33
	local.get	32
	i32.xor 
	local.tee	36
	i32.store	384
	local.get	9
	local.get	34
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	32
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	27
	i32.store	344
	local.get	9
	local.get	36
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	392
	local.get	9
	local.get	35
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	27
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	20
	i32.store	340
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	396
	local.get	9
	local.get	36
	local.get	20
	i32.xor 
	i32.store	388
	local.get	9
	local.get	33
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	376
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	380
	local.get	9
	local.get	33
	local.get	20
	i32.xor 
	i32.store	372
	local.get	9
	local.get	32
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	360
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	364
	local.get	9
	local.get	32
	local.get	20
	i32.xor 
	i32.store	356
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	348
	local.get	9
	local.get	24
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	20
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.store	304
	local.get	9
	local.get	26
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	35
	i32.store	288
	local.get	9
	local.get	34
	local.get	35
	i32.xor 
	local.tee	36
	i32.store	320
	local.get	9
	local.get	33
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	35
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	24
	i32.store	280
	local.get	9
	local.get	36
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	328
	local.get	9
	local.get	32
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	24
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	26
	i32.store	276
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	332
	local.get	9
	local.get	36
	local.get	26
	i32.xor 
	i32.store	324
	local.get	9
	local.get	34
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	312
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	316
	local.get	9
	local.get	34
	local.get	26
	i32.xor 
	i32.store	308
	local.get	9
	local.get	35
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	296
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	300
	local.get	9
	local.get	35
	local.get	26
	i32.xor 
	i32.store	292
	local.get	9
	local.get	24
	local.get	26
	i32.xor 
	i32.store	284
	local.get	9
	local.get	27
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	33
	i32.store	240
	local.get	9
	local.get	20
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	33
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	32
	i32.store	224
	local.get	9
	local.get	33
	local.get	32
	i32.xor 
	local.tee	36
	i32.store	256
	local.get	9
	local.get	34
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	32
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	27
	i32.store	216
	local.get	9
	local.get	36
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	264
	local.get	9
	local.get	35
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	27
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	20
	i32.store	212
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	268
	local.get	9
	local.get	36
	local.get	20
	i32.xor 
	i32.store	260
	local.get	9
	local.get	33
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	248
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	252
	local.get	9
	local.get	33
	local.get	20
	i32.xor 
	i32.store	244
	local.get	9
	local.get	32
	local.get	27
	i32.xor 
	local.tee	34
	i32.store	232
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	236
	local.get	9
	local.get	32
	local.get	20
	i32.xor 
	i32.store	228
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	220
	local.get	9
	local.get	24
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	20
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.store	176
	local.get	9
	local.get	26
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	35
	i32.store	160
	local.get	9
	local.get	34
	local.get	35
	i32.xor 
	local.tee	36
	i32.store	192
	local.get	9
	local.get	33
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	35
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	24
	i32.store	152
	local.get	9
	local.get	36
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	200
	local.get	9
	local.get	32
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	24
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	26
	i32.store	148
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	204
	local.get	9
	local.get	36
	local.get	26
	i32.xor 
	i32.store	196
	local.get	9
	local.get	34
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	184
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	188
	local.get	9
	local.get	34
	local.get	26
	i32.xor 
	i32.store	180
	local.get	9
	local.get	35
	local.get	24
	i32.xor 
	local.tee	33
	i32.store	168
	local.get	9
	local.get	33
	local.get	26
	i32.xor 
	i32.store	172
	local.get	9
	local.get	35
	local.get	26
	i32.xor 
	i32.store	164
	local.get	9
	local.get	24
	local.get	26
	i32.xor 
	i32.store	156
	local.get	9
	local.get	27
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	27
	i32.store	112
	local.get	9
	local.get	20
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	27
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	33
	i32.store	96
	local.get	9
	local.get	27
	local.get	33
	i32.xor 
	local.tee	32
	i32.store	128
	local.get	9
	local.get	34
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	33
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.store	88
	local.get	9
	local.get	32
	local.get	34
	i32.xor 
	local.tee	36
	i32.store	136
	local.get	9
	local.get	35
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	20
	i32.store	84
	local.get	9
	local.get	36
	local.get	20
	i32.xor 
	i32.store	140
	local.get	9
	local.get	32
	local.get	20
	i32.xor 
	i32.store	132
	local.get	9
	local.get	27
	local.get	34
	i32.xor 
	local.tee	35
	i32.store	120
	local.get	9
	local.get	35
	local.get	20
	i32.xor 
	i32.store	124
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	116
	local.get	9
	local.get	33
	local.get	34
	i32.xor 
	local.tee	35
	i32.store	104
	local.get	9
	local.get	35
	local.get	20
	i32.xor 
	i32.store	108
	local.get	9
	local.get	33
	local.get	20
	i32.xor 
	i32.store	100
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	92
	local.get	9
	local.get	24
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	20
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	24
	i32.store	48
	local.get	9
	local.get	26
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	24
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	34
	i32.store	32
	local.get	9
	local.get	24
	local.get	34
	i32.xor 
	local.tee	35
	i32.store	64
	local.get	9
	local.get	27
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	34
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	26
	i32.store	24
	local.get	9
	local.get	35
	local.get	26
	i32.xor 
	local.tee	27
	i32.store	72
	local.get	9
	local.get	33
	i32.const	26
	i32.shl 
	i32.const	31
	i32.shr_s
	i32.const	-306674912
	i32.and 
	local.get	26
	i32.const	1
	i32.shr_u
	i32.xor 
	local.tee	20
	i32.store	20
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	76
	local.get	9
	local.get	35
	local.get	20
	i32.xor 
	i32.store	68
	local.get	9
	local.get	24
	local.get	26
	i32.xor 
	local.tee	27
	i32.store	56
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	60
	local.get	9
	local.get	24
	local.get	20
	i32.xor 
	i32.store	52
	local.get	9
	local.get	34
	local.get	26
	i32.xor 
	local.tee	27
	i32.store	40
	local.get	9
	local.get	27
	local.get	20
	i32.xor 
	i32.store	44
	local.get	9
	local.get	34
	local.get	20
	i32.xor 
	i32.store	36
	local.get	9
	local.get	26
	local.get	20
	i32.xor 
	i32.store	28
	local.get	9
	local.get	29
	i32.store	12
	local.get	29
	local.set	24
.LBB5_39:                               #   in Loop: Header=BB5_20 Depth=2
	end_block                               # label98:
	local.get	18
	local.get	30
	i32.const	15
	i32.and 
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.get	17
	local.get	30
	i32.const	2
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	16
	local.get	30
	i32.const	6
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	15
	local.get	30
	i32.const	10
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	14
	local.get	30
	i32.const	14
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	13
	local.get	30
	i32.const	18
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	12
	local.get	30
	i32.const	22
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	11
	local.get	30
	i32.const	26
	i32.shr_u
	i32.const	60
	i32.and 
	i32.add 
	i32.load	0
	i32.xor 
	local.get	31
	i32.xor 
	local.set	26
	local.get	29
	local.get	28
	i32.add 
	local.set	20
	local.get	19
	i32.const	1
	i32.add 
	local.tee	19
	local.get	6
	i32.ne  
	br_if   	0                               # 0: up to label95
# %bb.40:                               #   in Loop: Header=BB5_15 Depth=1
	end_loop
	local.get	6
	local.set	19
.LBB5_41:                               #   in Loop: Header=BB5_15 Depth=1
	end_block                               # label94:
	local.get	26
	local.get	0
	local.get	20
	i32.add 
	local.get	25
	local.get	20
	i32.sub 
	call	crc32_update_gap
	local.get	4
	local.get	23
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.ne  
	br_if   	1                               # 1: down to label89
# %bb.42:                               #   in Loop: Header=BB5_15 Depth=1
	local.get	25
	local.set	20
	local.get	23
	i32.const	1
	i32.add 
	local.tee	23
	local.get	3
	i32.eq  
	br_if   	2                               # 2: down to label88
	br      	0                               # 0: up to label93
.LBB5_43:
	end_loop
	end_block                               # label89:
	i32.const	-4
	local.set	10
	br      	1                               # 1: down to label87
.LBB5_44:
	end_block                               # label88:
	i32.const	-1
	local.set	10
	local.get	25
	local.get	1
	i32.ne  
	br_if   	0                               # 0: down to label87
# %bb.45:
	local.get	19
	local.get	6
	i32.ne  
	br_if   	0                               # 0: down to label87
# %bb.46:
	i32.const	0
	local.set	10
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label87
# %bb.47:
	local.get	8
	local.get	22
	i32.store	8
	local.get	8
	local.get	21
	i32.store	4
	local.get	8
	local.get	1
	local.get	21
	i32.sub 
	i32.store	0
.LBB5_48:
	end_block                               # label87:
	local.get	9
	i32.const	528
	i32.add 
	global.set	__stack_pointer
	local.get	10
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.crc32_update_gap,"",@
	.type	crc32_update_gap,@function      # -- Begin function crc32_update_gap
crc32_update_gap:                       # @crc32_update_gap
	.functype	crc32_update_gap (i32, i32, i32) -> (i32)
	.local  	i32, i32
# %bb.0:
	local.get	0
	i32.const	-1
	i32.xor 
	local.set	3
	i32.const	0
	local.set	0
	block   	
	local.get	2
	i32.const	16
	i32.lt_u
	br_if   	0                               # 0: down to label104
# %bb.1:
	local.get	2
	local.set	4
	local.get	1
	local.set	0
.LBB6_2:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label105:
	local.get	0
	i32.load	0:p2align=0
	local.get	3
	i32.xor 
	local.tee	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+14336
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+15360
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+13312
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+12288
	i32.xor 
	local.get	0
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+11264
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+10240
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+9216
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+8192
	i32.xor 
	local.get	0
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	0
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.set	3
	local.get	0
	i32.const	16
	i32.add 
	local.set	0
	local.get	4
	i32.const	-16
	i32.add 
	local.tee	4
	i32.const	15
	i32.gt_u
	br_if   	0                               # 0: up to label105
# %bb.3:
	end_loop
	local.get	2
	i32.const	-16
	i32.and 
	local.set	0
.LBB6_4:
	end_block                               # label104:
	block   	
	local.get	0
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label106
# %bb.5:
	local.get	0
	i32.const	1
	i32.or  
	local.set	4
	block   	
	local.get	2
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label107
# %bb.6:
	local.get	1
	local.get	0
	i32.add 
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	4
	local.set	0
.LBB6_7:
	end_block                               # label107:
	local.get	2
	local.get	4
	i32.eq  
	br_if   	0                               # 0: down to label106
# %bb.8:
	local.get	2
	local.get	0
	i32.sub 
	local.set	4
	local.get	1
	local.get	0
	i32.add 
	local.set	0
.LBB6_9:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label108:
	local.get	0
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.get	0
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	0
	i32.const	2
	i32.add 
	local.set	0
	local.get	4
	i32.const	-2
	i32.add 
	local.tee	4
	br_if   	0                               # 0: up to label108
.LBB6_10:
	end_loop
	end_block                               # label106:
	local.get	3
	i32.const	-1
	i32.xor 
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.wasm_reset_heap,"",@
	.globl	wasm_reset_heap                 # -- Begin function wasm_reset_heap
	.type	wasm_reset_heap,@function
wasm_reset_heap:                        # @wasm_reset_heap
	.functype	wasm_reset_heap () -> ()
# %bb.0:
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.wasm_alloc,"",@
	.globl	wasm_alloc                      # -- Begin function wasm_alloc
	.type	wasm_alloc,@function
wasm_alloc:                             # @wasm_alloc
	.functype	wasm_alloc (i32) -> (i32)
	.local  	i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	1
	block   	
	i32.const	0
	i32.load	heap_ptr
	local.tee	2
	br_if   	0                               # 0: down to label109
# %bb.1:
	i32.const	__heap_base
	local.set	2
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB8_2:
	end_block                               # label109:
	block   	
	local.get	0
	i32.const	-8
	i32.gt_u
	br_if   	0                               # 0: down to label110
# %bb.3:
	local.get	2
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	2
	local.get	0
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	0
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	0                               # 0: down to label110
# %bb.4:
	i32.const	0
	local.set	1
	block   	
	local.get	2
	local.get	0
	i32.add 
	local.tee	0
	i32.const	16
	i32.shr_u
	local.get	0
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	3
	memory.size	0
	local.tee	4
	i32.le_u
	br_if   	0                               # 0: down to label111
# %bb.5:
	local.get	3
	local.get	4
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	1                               # 1: down to label110
.LBB8_6:
	end_block                               # label111:
	i32.const	0
	local.get	0
	i32.store	heap_ptr
	local.get	2
	local.set	1
.LBB8_7:
	end_block                               # label110:
	local.get	1
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.wasm_get_last_parse_capacity,"",@
	.globl	wasm_get_last_parse_capacity    # -- Begin function wasm_get_last_parse_capacity
	.type	wasm_get_last_parse_capacity,@function
wasm_get_last_parse_capacity:           # @wasm_get_last_parse_capacity
	.functype	wasm_get_last_parse_capacity () -> (i32)
# %bb.0:
	i32.const	0
	i32.load	last_parse_capacity
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.wasm_get_last_content_capacity,"",@
	.globl	wasm_get_last_content_capacity  # -- Begin function wasm_get_last_content_capacity
	.type	wasm_get_last_content_capacity,@function
wasm_get_last_content_capacity:         # @wasm_get_last_content_capacity
	.functype	wasm_get_last_content_capacity () -> (i32)
# %bb.0:
	i32.const	0
	i32.load	last_content_capacity
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.project_single_glossary_image_path,"",@
	.globl	project_single_glossary_image_path # -- Begin function project_single_glossary_image_path
	.type	project_single_glossary_image_path,@function
project_single_glossary_image_path:     # @project_single_glossary_image_path
	.functype	project_single_glossary_image_path (i32, i32) -> (i64)
	.local  	i32, i64, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	2
	global.set	__stack_pointer
	i64.const	0
	local.set	3
	block   	
	local.get	1
	i64.extend_i32_u
	local.get	0
	i64.extend_i32_u
	i64.add 
	memory.size	0
	i64.extend_i32_u
	i64.const	16
	i64.shl 
	i64.gt_u
	br_if   	0                               # 0: down to label112
# %bb.1:
	i32.const	0
	local.set	4
	block   	
	local.get	1
	i32.eqz
	br_if   	0                               # 0: down to label113
# %bb.2:
.LBB11_3:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label114:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label113
# %bb.4:                                #   in Loop: Header=BB11_3 Depth=1
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label113
# %bb.5:                                #   in Loop: Header=BB11_3 Depth=1
	local.get	1
	local.get	4
	i32.const	1
	i32.add 
	local.tee	4
	i32.ne  
	br_if   	0                               # 0: up to label114
	br      	2                               # 2: down to label112
.LBB11_6:
	end_loop
	end_block                               # label113:
	local.get	4
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label112
# %bb.7:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label112
# %bb.8:
	i64.const	0
	local.set	3
	local.get	0
	local.get	1
	local.get	4
	i32.const	0
	i32.const	0
	local.get	2
	local.get	2
	i32.const	4
	i32.add 
	call	project_glossary_image_value
	i32.eqz
	br_if   	0                               # 0: down to label112
# %bb.9:
	block   	
	local.get	2
	i32.load	0
	local.tee	4
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label115
# %bb.10:
.LBB11_11:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label116:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label115
# %bb.12:                               #   in Loop: Header=BB11_11 Depth=1
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label115
# %bb.13:                               #   in Loop: Header=BB11_11 Depth=1
	local.get	1
	local.get	4
	i32.const	1
	i32.add 
	local.tee	4
	i32.ne  
	br_if   	0                               # 0: up to label116
# %bb.14:
	end_loop
	local.get	1
	local.set	4
.LBB11_15:
	end_block                               # label115:
	local.get	4
	local.get	1
	i32.ne  
	br_if   	0                               # 0: down to label112
# %bb.16:
	local.get	2
	i32.load	4
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label112
# %bb.17:
	local.get	2
	i64.load32_u	8
	i64.const	32
	i64.shl 
	local.get	2
	i64.load32_u	12
	i64.or  
	local.set	3
.LBB11_18:
	end_block                               # label112:
	local.get	2
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	3
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.project_glossary_image_value,"",@
	.type	project_glossary_image_value,@function # -- Begin function project_glossary_image_value
project_glossary_image_value:           # @project_glossary_image_value
	.functype	project_glossary_image_value (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	7
	global.set	__stack_pointer
	local.get	6
	i32.const	0
	i32.store	8
	local.get	6
	i64.const	0
	i64.store	0:p2align=2
	block   	
	block   	
	local.get	2
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label118
# %bb.1:
	i32.const	0
	local.set	8
	br      	1                               # 1: down to label117
.LBB12_2:
	end_block                               # label118:
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	223
	i32.and 
	i32.const	91
	i32.eq  
	br_if   	0                               # 0: down to label119
# %bb.3:
	local.get	0
	local.get	1
	local.get	2
	local.get	5
	call	parse_value_span
	local.set	8
	br      	1                               # 1: down to label117
.LBB12_4:
	end_block                               # label119:
	block   	
	local.get	4
	i32.const	255
	i32.le_u
	br_if   	0                               # 0: down to label120
# %bb.5:
	i32.const	0
	local.set	8
	br      	1                               # 1: down to label117
.LBB12_6:
	end_block                               # label120:
	block   	
	block   	
	local.get	8
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label122
# %bb.7:
	block   	
	local.get	3
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label123
# %bb.8:
	local.get	0
	local.get	1
	local.get	2
	local.get	5
	i32.const	0
	i32.const	0
	i32.const	0
	i32.const	0
	call	parse_composite_span_impl
	local.set	8
	br      	3                               # 3: down to label117
.LBB12_9:
	end_block                               # label123:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label124
# %bb.10:
.LBB12_11:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label125:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	8
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label124
# %bb.12:                               #   in Loop: Header=BB12_11 Depth=1
	i32.const	1
	local.get	8
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label124
# %bb.13:                               #   in Loop: Header=BB12_11 Depth=1
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label125
# %bb.14:
	end_loop
	local.get	1
	local.set	2
	br      	2                               # 2: down to label121
.LBB12_15:
	end_block                               # label124:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label121
# %bb.16:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	1                               # 1: down to label121
# %bb.17:
	i32.const	1
	local.set	8
	local.get	5
	local.get	2
	i32.const	1
	i32.add 
	i32.store	0
	br      	2                               # 2: down to label117
.LBB12_18:
	end_block                               # label122:
	i32.const	0
	local.set	8
	local.get	3
	i32.eqz
	br_if   	1                               # 1: down to label117
# %bb.19:
	local.get	7
	i32.const	8
	i32.add 
	i32.const	0
	i32.store	0
	local.get	7
	i64.const	0
	i64.store	0
	block   	
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	9
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label127
# %bb.20:
.LBB12_21:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label128:
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label127
# %bb.22:                               #   in Loop: Header=BB12_21 Depth=1
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label127
# %bb.23:                               #   in Loop: Header=BB12_21 Depth=1
	local.get	1
	local.get	9
	i32.const	1
	i32.add 
	local.tee	9
	i32.ne  
	br_if   	0                               # 0: up to label128
# %bb.24:
	end_loop
	local.get	1
	local.set	9
	br      	1                               # 1: down to label126
.LBB12_25:
	end_block                               # label127:
	local.get	9
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label126
# %bb.26:
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	125
	i32.ne  
	br_if   	0                               # 0: down to label126
# %bb.27:
	i32.const	1
	local.set	8
	local.get	5
	local.get	9
	i32.const	1
	i32.add 
	i32.store	0
	br      	2                               # 2: down to label117
.LBB12_28:
	end_block                               # label126:
	local.get	0
	i32.const	5
	i32.add 
	local.set	10
	local.get	0
	i32.const	4
	i32.add 
	local.set	11
	local.get	0
	i32.const	3
	i32.add 
	local.set	12
	local.get	0
	i32.const	2
	i32.add 
	local.set	13
	local.get	0
	i32.const	1
	i32.add 
	local.set	14
	local.get	0
	i32.const	8
	i32.add 
	local.set	15
	local.get	0
	i32.const	6
	i32.add 
	local.set	16
	local.get	4
	i32.const	1
	i32.add 
	local.set	17
	i32.const	0
	local.set	18
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
	i32.const	0
	local.set	21
.LBB12_29:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB12_36 Depth 2
                                        #     Child Loop BB12_127 Depth 2
                                        #     Child Loop BB12_134 Depth 2
                                        #     Child Loop BB12_231 Depth 2
                                        #     Child Loop BB12_246 Depth 2
	loop    	                                # label129:
	block   	
	local.get	9
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label130
# %bb.30:
	i32.const	0
	local.set	8
	br      	3                               # 3: down to label117
.LBB12_31:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label130:
	block   	
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	0                               # 0: down to label131
# %bb.32:
	i32.const	0
	local.set	8
	br      	3                               # 3: down to label117
.LBB12_33:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label131:
	block   	
	local.get	9
	i32.const	1
	i32.add 
	local.tee	22
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label132
# %bb.34:
	i32.const	0
	local.set	8
	br      	3                               # 3: down to label117
.LBB12_35:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label132:
	local.get	22
	local.set	4
.LBB12_36:                              #   Parent Loop BB12_29 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label134:
	block   	
	local.get	4
	local.tee	2
	i32.const	8
	i32.add 
	local.tee	4
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label135
# %bb.37:                               #   in Loop: Header=BB12_36 Depth=2
	local.get	0
	local.get	2
	i32.add 
	i64.load	0:p2align=0
	local.tee	23
	i64.const	-1
	i64.xor 
	local.get	23
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	23
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	local.get	23
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	23
	i64.eqz
	br_if   	1                               # 1: up to label134
# %bb.38:                               #   in Loop: Header=BB12_36 Depth=2
	local.get	23
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	2
	i32.add 
	local.set	2
.LBB12_39:                              #   in Loop: Header=BB12_36 Depth=2
	end_block                               # label135:
	block   	
	local.get	2
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label136
# %bb.40:
	i32.const	0
	local.set	8
	br      	5                               # 5: down to label117
.LBB12_41:                              #   in Loop: Header=BB12_36 Depth=2
	end_block                               # label136:
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label138
# %bb.42:                               #   in Loop: Header=BB12_36 Depth=2
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	4
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label139
# %bb.43:
	i32.const	0
	local.set	8
	br      	7                               # 7: down to label117
.LBB12_44:                              #   in Loop: Header=BB12_36 Depth=2
	end_block                               # label139:
	i32.const	0
	local.set	8
	block   	
	block   	
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 8, 8, 1, 8, 8, 8, 1, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 1, 8, 1, 0, 8} # 8: down to label117
                                        # 1: down to label140
                                        # 0: down to label141
.LBB12_45:                              #   in Loop: Header=BB12_36 Depth=2
	end_block                               # label141:
	block   	
	local.get	2
	i32.const	6
	i32.add 
	local.tee	4
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label142
# %bb.46:
	i32.const	0
	local.set	8
	br      	8                               # 8: down to label117
.LBB12_47:                              #   in Loop: Header=BB12_36 Depth=2
	end_block                               # label142:
	local.get	2
	i32.const	2
	i32.add 
	local.tee	8
	local.get	4
	i32.ge_u
	br_if   	2                               # 2: down to label137
# %bb.48:                               #   in Loop: Header=BB12_36 Depth=2
	block   	
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label143
# %bb.49:                               #   in Loop: Header=BB12_36 Depth=2
	local.get	8
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	0                               # 0: down to label143
# %bb.50:
	i32.const	0
	local.set	8
	br      	8                               # 8: down to label117
.LBB12_51:                              #   in Loop: Header=BB12_36 Depth=2
	end_block                               # label143:
	block   	
	local.get	12
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label144
# %bb.52:                               #   in Loop: Header=BB12_36 Depth=2
	local.get	8
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	0                               # 0: down to label144
# %bb.53:
	i32.const	0
	local.set	8
	br      	8                               # 8: down to label117
.LBB12_54:                              #   in Loop: Header=BB12_36 Depth=2
	end_block                               # label144:
	block   	
	local.get	11
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label145
# %bb.55:                               #   in Loop: Header=BB12_36 Depth=2
	local.get	8
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	0                               # 0: down to label145
# %bb.56:
	i32.const	0
	local.set	8
	br      	8                               # 8: down to label117
.LBB12_57:                              #   in Loop: Header=BB12_36 Depth=2
	end_block                               # label145:
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label137
# %bb.58:                               #   in Loop: Header=BB12_36 Depth=2
	local.get	2
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label137
# %bb.59:
	i32.const	0
	local.set	8
	br      	7                               # 7: down to label117
.LBB12_60:                              #   in Loop: Header=BB12_36 Depth=2
	end_block                               # label140:
	local.get	2
	i32.const	2
	i32.add 
	local.set	4
	br      	1                               # 1: down to label137
.LBB12_61:                              #   in Loop: Header=BB12_36 Depth=2
	end_block                               # label138:
	block   	
	local.get	8
	i32.const	32
	i32.ge_u
	br_if   	0                               # 0: down to label146
# %bb.62:
	i32.const	0
	local.set	8
	br      	6                               # 6: down to label117
.LBB12_63:                              #   in Loop: Header=BB12_36 Depth=2
	end_block                               # label146:
	local.get	2
	i32.const	1
	i32.add 
	local.set	4
	local.get	8
	i32.const	34
	i32.eq  
	br_if   	2                               # 2: down to label133
.LBB12_64:                              #   in Loop: Header=BB12_36 Depth=2
	end_block                               # label137:
	local.get	4
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: up to label134
# %bb.65:
	end_loop
	i32.const	0
	local.set	8
	br      	3                               # 3: down to label117
.LBB12_66:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label133:
	block   	
	block   	
	local.get	2
	local.get	9
	i32.ge_u
	br_if   	0                               # 0: down to label148
# %bb.67:                               #   in Loop: Header=BB12_29 Depth=1
	i32.const	0
	local.set	24
	i32.const	1
	local.set	25
	i32.const	0
	local.set	26
	br      	1                               # 1: down to label147
.LBB12_68:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label148:
	local.get	2
	local.get	9
	i32.sub 
	local.set	8
	i32.const	0
	local.set	24
	block   	
	local.get	2
	local.get	9
	i32.eq  
	br_if   	0                               # 0: down to label149
# %bb.69:                               #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	22
	i32.add 
	i32.load8_u	0
	local.tee	25
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label150
# %bb.70:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	25
	i32.const	99
	i32.ne  
	br_if   	1                               # 1: down to label149
# %bb.71:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label149
# %bb.72:                               #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	13
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label149
                                        # 0: down to label151
.LBB12_73:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label151:
	local.get	8
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label149
# %bb.74:                               #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	12
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label149
                                        # 0: down to label152
.LBB12_75:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label152:
	local.get	8
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label149
# %bb.76:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	11
	local.get	9
	i32.add 
	i32.load8_u	0
	local.tee	25
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label150
# %bb.77:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	25
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label149
# %bb.78:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	4
	i32.eq  
	br_if   	1                               # 1: down to label149
# %bb.79:                               #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	10
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label149
                                        # 0: down to label153
.LBB12_80:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label153:
	local.get	8
	i32.const	5
	i32.eq  
	br_if   	1                               # 1: down to label149
# %bb.81:                               #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	16
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label149
                                        # 0: down to label154
.LBB12_82:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label154:
	local.get	8
	i32.const	6
	i32.eq  
	br_if   	1                               # 1: down to label149
# %bb.83:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	9
	i32.const	7
	i32.add 
	local.tee	26
	i32.add 
	i32.load8_u	0
	local.tee	25
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label150
# %bb.84:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	25
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label149
# %bb.85:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	26
	local.get	2
	i32.ge_u
	br_if   	1                               # 1: down to label149
# %bb.86:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	15
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	24
	br      	1                               # 1: down to label149
.LBB12_87:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label150:
	local.get	0
	local.get	9
	local.get	4
	i32.const	.L.str
	i32.const	7
	call	json_string_matches_ascii_escaped
	local.set	24
.LBB12_88:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label149:
	i32.const	0
	local.get	8
	local.get	8
	local.get	2
	i32.gt_u
	i32.select
	local.set	27
	local.get	9
	i32.const	4
	i32.add 
	local.set	28
	i32.const	1
	local.set	25
	block   	
	local.get	2
	local.get	9
	i32.gt_u
	local.tee	8
	i32.eqz
	br_if   	0                               # 0: down to label155
# %bb.89:                               #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	22
	i32.add 
	i32.load8_u	0
	local.tee	26
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label156
# %bb.90:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	26
	i32.const	112
	i32.ne  
	br_if   	1                               # 1: down to label155
# %bb.91:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	27
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label155
# %bb.92:                               #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	13
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 0, 2}   # 2: down to label155
                                        # 0: down to label157
.LBB12_93:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label157:
	local.get	27
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label155
# %bb.94:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	12
	local.get	9
	i32.add 
	i32.load8_u	0
	local.tee	26
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label156
# %bb.95:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	26
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label155
# %bb.96:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	27
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label155
# %bb.97:                               #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	28
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label155
                                        # 0: down to label158
.LBB12_98:                              #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label158:
	local.get	28
	local.get	2
	i32.ge_u
	br_if   	1                               # 1: down to label155
# %bb.99:                               #   in Loop: Header=BB12_29 Depth=1
	local.get	10
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	local.set	25
	br      	1                               # 1: down to label155
.LBB12_100:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label156:
	local.get	0
	local.get	9
	local.get	4
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	local.set	25
.LBB12_101:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label155:
	block   	
	block   	
	block   	
	local.get	3
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label161
# %bb.102:                              #   in Loop: Header=BB12_29 Depth=1
	i32.const	0
	local.set	26
	local.get	8
	i32.eqz
	br_if   	3                               # 3: down to label147
# %bb.103:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	22
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	2                               # 2: down to label159
# %bb.104:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	116
	i32.ne  
	br_if   	3                               # 3: down to label147
# %bb.105:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	27
	i32.const	1
	i32.ne  
	br_if   	1                               # 1: down to label160
	br      	3                               # 3: down to label147
.LBB12_106:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label161:
	i32.const	0
	local.set	26
	local.get	8
	i32.eqz
	br_if   	2                               # 2: down to label147
# %bb.107:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	22
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label162
# %bb.108:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	116
	i32.ne  
	br_if   	3                               # 3: down to label147
# %bb.109:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	27
	i32.const	1
	i32.eq  
	br_if   	3                               # 3: down to label147
# %bb.110:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	13
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 4, 4, 4, 4, 0, 4}   # 4: down to label147
                                        # 0: down to label163
.LBB12_111:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label163:
	local.get	27
	i32.const	2
	i32.eq  
	br_if   	3                               # 3: down to label147
# %bb.112:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	9
	i32.const	3
	i32.add 
	local.tee	8
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 0, 4} # 4: down to label147
                                        # 0: down to label164
.LBB12_113:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label164:
	local.get	8
	local.get	2
	i32.ge_u
	br_if   	3                               # 3: down to label147
# %bb.114:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	11
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	26
	br      	3                               # 3: down to label147
.LBB12_115:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label162:
	local.get	0
	local.get	9
	local.get	4
	i32.const	.L.str.3
	i32.const	3
	call	json_string_matches_ascii_escaped
	local.set	26
	br      	2                               # 2: down to label147
.LBB12_116:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label160:
	local.get	13
	local.get	9
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label159
# %bb.117:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	121
	i32.ne  
	br_if   	1                               # 1: down to label147
# %bb.118:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	27
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label147
# %bb.119:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	12
	local.get	9
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label159
# %bb.120:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	112
	i32.ne  
	br_if   	1                               # 1: down to label147
# %bb.121:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	27
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label147
# %bb.122:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	28
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label147
                                        # 0: down to label165
.LBB12_123:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label165:
	local.get	28
	local.get	2
	i32.ge_u
	br_if   	1                               # 1: down to label147
# %bb.124:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	10
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	26
	br      	1                               # 1: down to label147
.LBB12_125:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label159:
	local.get	0
	local.get	9
	local.get	4
	i32.const	.L.str.2
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	26
.LBB12_126:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label147:
	block   	
	local.get	4
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label166
.LBB12_127:                             #   Parent Loop BB12_29 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label167:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label166
# %bb.128:                              #   in Loop: Header=BB12_127 Depth=2
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label166
# %bb.129:                              #   in Loop: Header=BB12_127 Depth=2
	local.get	1
	local.get	4
	i32.const	1
	i32.add 
	local.tee	4
	i32.ne  
	br_if   	0                               # 0: up to label167
# %bb.130:
	end_loop
	i32.const	0
	local.set	8
	br      	3                               # 3: down to label117
.LBB12_131:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label166:
	i32.const	0
	local.set	8
	local.get	4
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label117
# %bb.132:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	2                               # 2: down to label117
# %bb.133:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	4
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label168
.LBB12_134:                             #   Parent Loop BB12_29 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label169:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	8
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label168
# %bb.135:                              #   in Loop: Header=BB12_134 Depth=2
	i32.const	1
	local.get	8
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label168
# %bb.136:                              #   in Loop: Header=BB12_134 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label169
# %bb.137:                              #   in Loop: Header=BB12_29 Depth=1
	end_loop
	local.get	1
	local.set	2
.LBB12_138:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label168:
	block   	
	block   	
	local.get	24
	i32.eqz
	br_if   	0                               # 0: down to label171
# %bb.139:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	1
	local.get	2
	i32.const	2
	local.get	17
	local.get	7
	i32.const	12
	i32.add 
	local.get	7
	call	project_glossary_image_value
	br_if   	1                               # 1: down to label170
# %bb.140:
	i32.const	0
	local.set	8
	br      	4                               # 4: down to label117
.LBB12_141:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label171:
	local.get	0
	local.get	1
	local.get	2
	local.get	7
	i32.const	12
	i32.add 
	call	parse_value_span
	br_if   	0                               # 0: down to label170
# %bb.142:
	i32.const	0
	local.set	8
	br      	3                               # 3: down to label117
.LBB12_143:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label170:
	block   	
	local.get	25
	br_if   	0                               # 0: down to label172
# %bb.144:                              #   in Loop: Header=BB12_29 Depth=1
	i32.const	0
	local.set	18
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label172
# %bb.145:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	7
	i32.load	12
	local.get	2
	i32.sub 
	local.set	18
	i32.const	1
	local.set	20
	local.get	2
	local.set	19
.LBB12_146:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label172:
	local.get	7
	i32.load	12
	local.set	9
	block   	
	local.get	26
	i32.eqz
	br_if   	0                               # 0: down to label173
# %bb.147:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	block   	
	block   	
	block   	
	local.get	3
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label177
# %bb.148:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	2
	local.get	9
	i32.ge_u
	br_if   	3                               # 3: down to label174
# %bb.149:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	3                               # 3: down to label174
# %bb.150:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	2
	i32.const	6
	i32.add 
	local.set	4
	local.get	9
	local.get	2
	i32.const	-1
	i32.xor 
	i32.add 
	local.tee	8
	i32.eqz
	br_if   	2                               # 2: down to label175
# %bb.151:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	block   	
	local.get	14
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	22
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label179
# %bb.152:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	22
	i32.const	105
	i32.ne  
	br_if   	4                               # 4: down to label175
# %bb.153:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	1
	i32.eq  
	br_if   	4                               # 4: down to label175
# %bb.154:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	13
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 5} # 5: down to label175
                                        # 0: down to label180
.LBB12_155:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label180:
	local.get	8
	i32.const	2
	i32.eq  
	br_if   	4                               # 4: down to label175
# %bb.156:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	12
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 5, 5, 5, 5, 0, 5}   # 5: down to label175
                                        # 0: down to label181
.LBB12_157:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label181:
	local.get	8
	i32.const	3
	i32.eq  
	br_if   	4                               # 4: down to label175
# %bb.158:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	11
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 5} # 5: down to label175
                                        # 0: down to label182
.LBB12_159:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label182:
	local.get	8
	i32.const	4
	i32.eq  
	br_if   	4                               # 4: down to label175
# %bb.160:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{0, 4, 4, 4, 4, 4, 4, 4, 4, 1, 4} # 4: down to label175
                                        # 1: down to label178
.LBB12_161:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label179:
	local.get	0
	local.get	2
	local.get	9
	i32.const	.L.str.4
	i32.const	5
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	3                               # 3: down to label175
# %bb.162:                              #   in Loop: Header=BB12_29 Depth=1
	i32.const	1
	local.set	21
	br      	5                               # 5: down to label173
.LBB12_163:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label178:
	local.get	4
	local.get	9
	i32.lt_u
	br_if   	1                               # 1: down to label176
	br      	2                               # 2: down to label175
.LBB12_164:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label177:
	i32.const	0
	local.set	21
	local.get	2
	local.get	9
	i32.ge_u
	br_if   	3                               # 3: down to label173
# %bb.165:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	3                               # 3: down to label173
# %bb.166:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	9
	local.get	2
	i32.const	-1
	i32.xor 
	i32.add 
	local.tee	8
	i32.eqz
	br_if   	3                               # 3: down to label173
# %bb.167:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	14
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	4
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label183
# %bb.168:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	4
	i32.const	105
	i32.ne  
	br_if   	4                               # 4: down to label173
# %bb.169:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	1
	i32.eq  
	br_if   	4                               # 4: down to label173
# %bb.170:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	13
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 5} # 5: down to label173
                                        # 0: down to label184
.LBB12_171:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label184:
	local.get	8
	i32.const	2
	i32.eq  
	br_if   	4                               # 4: down to label173
# %bb.172:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	12
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 0, 5} # 5: down to label173
                                        # 0: down to label185
.LBB12_173:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label185:
	local.get	2
	i32.const	4
	i32.add 
	local.tee	2
	local.get	9
	i32.ge_u
	br_if   	4                               # 4: down to label173
# %bb.174:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	21
	br      	4                               # 4: down to label173
.LBB12_175:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label183:
	local.get	0
	local.get	2
	local.get	9
	i32.const	.L.str.6
	i32.const	3
	call	json_string_matches_ascii_escaped
	local.set	21
	br      	3                               # 3: down to label173
.LBB12_176:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label176:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label175
# %bb.177:                              #   in Loop: Header=BB12_29 Depth=1
	i32.const	1
	local.set	21
	br      	2                               # 2: down to label173
.LBB12_178:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label175:
	local.get	2
	i32.const	1
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	0                               # 0: down to label174
# %bb.179:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label186
# %bb.180:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	115
	i32.ne  
	br_if   	1                               # 1: down to label174
# %bb.181:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	2
	i32.const	2
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.182:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label186
# %bb.183:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label174
# %bb.184:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	2
	i32.const	3
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.185:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label186
# %bb.186:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	114
	i32.ne  
	br_if   	1                               # 1: down to label174
# %bb.187:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	2
	i32.const	4
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.188:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label186
# %bb.189:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	117
	i32.ne  
	br_if   	1                               # 1: down to label174
# %bb.190:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	2
	i32.const	5
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.191:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label174
                                        # 0: down to label187
.LBB12_192:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label187:
	local.get	4
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.193:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label186
# %bb.194:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label174
# %bb.195:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	2
	i32.const	7
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.196:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label186
# %bb.197:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	117
	i32.ne  
	br_if   	1                               # 1: down to label174
# %bb.198:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	2
	i32.const	8
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.199:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label186
# %bb.200:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	114
	i32.ne  
	br_if   	1                               # 1: down to label174
# %bb.201:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	2
	i32.const	9
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.202:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label174
                                        # 0: down to label188
.LBB12_203:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label188:
	local.get	2
	i32.const	10
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.204:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label174
                                        # 0: down to label189
.LBB12_205:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label189:
	local.get	2
	i32.const	11
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.206:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label186
# %bb.207:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	45
	i32.ne  
	br_if   	1                               # 1: down to label174
# %bb.208:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	2
	i32.const	12
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.209:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label174
                                        # 0: down to label190
.LBB12_210:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label190:
	local.get	2
	i32.const	13
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.211:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label174
                                        # 0: down to label191
.LBB12_212:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label191:
	local.get	2
	i32.const	14
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.213:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label174
                                        # 0: down to label192
.LBB12_214:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label192:
	local.get	2
	i32.const	15
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.215:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label186
# %bb.216:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label174
# %bb.217:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	2
	i32.const	16
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.218:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label174
                                        # 0: down to label193
.LBB12_219:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label193:
	local.get	2
	i32.const	17
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.220:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label174
                                        # 0: down to label194
.LBB12_221:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label194:
	local.get	2
	i32.const	18
	i32.add 
	local.tee	8
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.222:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	8
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label186
# %bb.223:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	8
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label174
# %bb.224:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	2
	i32.const	19
	i32.add 
	local.tee	2
	local.get	9
	i32.ge_u
	br_if   	1                               # 1: down to label174
# %bb.225:                              #   in Loop: Header=BB12_29 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label174
# %bb.226:                              #   in Loop: Header=BB12_29 Depth=1
	i32.const	2
	local.set	21
	br      	2                               # 2: down to label173
.LBB12_227:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label186:
	local.get	0
	local.get	2
	local.get	9
	i32.const	.L.str.5
	i32.const	18
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	0                               # 0: down to label174
# %bb.228:                              #   in Loop: Header=BB12_29 Depth=1
	i32.const	2
	local.set	21
	br      	1                               # 1: down to label173
.LBB12_229:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label174:
	i32.const	0
	local.set	21
.LBB12_230:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label173:
	block   	
	local.get	9
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label195
.LBB12_231:                             #   Parent Loop BB12_29 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label196:
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label195
# %bb.232:                              #   in Loop: Header=BB12_231 Depth=2
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label195
# %bb.233:                              #   in Loop: Header=BB12_231 Depth=2
	local.get	1
	local.get	9
	i32.const	1
	i32.add 
	local.tee	9
	i32.ne  
	br_if   	0                               # 0: up to label196
# %bb.234:
	end_loop
	i32.const	0
	local.set	8
	br      	3                               # 3: down to label117
.LBB12_235:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label195:
	i32.const	0
	local.set	8
	local.get	9
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label117
# %bb.236:                              #   in Loop: Header=BB12_29 Depth=1
	block   	
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	44
	i32.eq  
	br_if   	0                               # 0: down to label197
# %bb.237:
	local.get	2
	i32.const	125
	i32.ne  
	br_if   	3                               # 3: down to label117
# %bb.238:
	block   	
	block   	
	local.get	21
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label199
# %bb.239:
	local.get	6
	local.get	18
	i32.store	8
	local.get	6
	local.get	19
	i32.store	4
	local.get	6
	local.get	20
	i32.store	0
	br      	1                               # 1: down to label198
.LBB12_240:
	end_block                               # label199:
	block   	
	block   	
	local.get	3
	i32.const	2
	i32.eq  
	br_if   	0                               # 0: down to label201
# %bb.241:
	local.get	21
	i32.const	2
	i32.ne  
	br_if   	1                               # 1: down to label200
.LBB12_242:
	end_block                               # label201:
	local.get	6
	local.get	7
	i64.load	0
	i64.store	0:p2align=2
	local.get	6
	i32.const	8
	i32.add 
	local.get	7
	i32.const	8
	i32.add 
	i32.load	0
	i32.store	0
	br      	1                               # 1: down to label198
.LBB12_243:
	end_block                               # label200:
	local.get	6
	i32.const	0
	i32.store	8
	local.get	6
	i64.const	0
	i64.store	0:p2align=2
.LBB12_244:
	end_block                               # label198:
	i32.const	1
	local.set	8
	local.get	5
	local.get	9
	i32.const	1
	i32.add 
	i32.store	0
	br      	3                               # 3: down to label117
.LBB12_245:                             #   in Loop: Header=BB12_29 Depth=1
	end_block                               # label197:
	block   	
	local.get	9
	i32.const	1
	i32.add 
	local.tee	9
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label202
.LBB12_246:                             #   Parent Loop BB12_29 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label203:
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label202
# %bb.247:                              #   in Loop: Header=BB12_246 Depth=2
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label202
# %bb.248:                              #   in Loop: Header=BB12_246 Depth=2
	local.get	1
	local.get	9
	i32.const	1
	i32.add 
	local.tee	9
	i32.ne  
	br_if   	0                               # 0: up to label203
	br      	4                               # 4: down to label117
.LBB12_249:                             #   in Loop: Header=BB12_29 Depth=1
	end_loop
	end_block                               # label202:
	local.get	9
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label117
# %bb.250:                              #   in Loop: Header=BB12_29 Depth=1
	i32.const	0
	local.set	8
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	125
	i32.ne  
	br_if   	0                               # 0: up to label129
	br      	2                               # 2: down to label117
.LBB12_251:
	end_loop
	end_block                               # label121:
	i32.const	2
	i32.const	1
	local.get	3
	i32.select
	local.set	3
	local.get	4
	i32.const	1
	i32.add 
	local.set	4
.LBB12_252:                             # =>This Loop Header: Depth=1
                                        #     Child Loop BB12_260 Depth 2
                                        #     Child Loop BB12_268 Depth 2
	loop    	                                # label204:
	block   	
	local.get	2
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label205
# %bb.253:
	i32.const	0
	local.set	8
	br      	2                               # 2: down to label117
.LBB12_254:                             #   in Loop: Header=BB12_252 Depth=1
	end_block                               # label205:
	i32.const	0
	local.set	8
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	local.get	4
	local.get	7
	i32.const	12
	i32.add 
	local.get	7
	call	project_glossary_image_value
	i32.eqz
	br_if   	1                               # 1: down to label117
# %bb.255:                              #   in Loop: Header=BB12_252 Depth=1
	block   	
	local.get	7
	i32.load	0
	i32.eqz
	br_if   	0                               # 0: down to label206
# %bb.256:                              #   in Loop: Header=BB12_252 Depth=1
	block   	
	local.get	6
	i32.load	0
	br_if   	0                               # 0: down to label207
# %bb.257:                              #   in Loop: Header=BB12_252 Depth=1
	local.get	6
	local.get	7
	i64.load	0:p2align=2
	i64.store	0:p2align=2
	local.get	6
	i32.const	8
	i32.add 
	local.get	7
	i32.const	8
	i32.add 
	i32.load	0
	i32.store	0
	br      	1                               # 1: down to label206
.LBB12_258:                             #   in Loop: Header=BB12_252 Depth=1
	end_block                               # label207:
	local.get	6
	i32.const	2
	i32.store	0
.LBB12_259:                             #   in Loop: Header=BB12_252 Depth=1
	end_block                               # label206:
	block   	
	local.get	7
	i32.load	12
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label208
.LBB12_260:                             #   Parent Loop BB12_252 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label209:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	9
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label208
# %bb.261:                              #   in Loop: Header=BB12_260 Depth=2
	i32.const	1
	local.get	9
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label208
# %bb.262:                              #   in Loop: Header=BB12_260 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label209
	br      	3                               # 3: down to label117
.LBB12_263:                             #   in Loop: Header=BB12_252 Depth=1
	end_loop
	end_block                               # label208:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label117
# %bb.264:                              #   in Loop: Header=BB12_252 Depth=1
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	9
	i32.const	44
	i32.eq  
	br_if   	0                               # 0: down to label210
# %bb.265:
	local.get	9
	i32.const	93
	i32.ne  
	br_if   	2                               # 2: down to label117
# %bb.266:
	i32.const	1
	local.set	8
	local.get	5
	local.get	2
	i32.const	1
	i32.add 
	i32.store	0
	br      	2                               # 2: down to label117
.LBB12_267:                             #   in Loop: Header=BB12_252 Depth=1
	end_block                               # label210:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label211
.LBB12_268:                             #   Parent Loop BB12_252 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label212:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	9
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label211
# %bb.269:                              #   in Loop: Header=BB12_268 Depth=2
	i32.const	1
	local.get	9
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label211
# %bb.270:                              #   in Loop: Header=BB12_268 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label212
	br      	3                               # 3: down to label117
.LBB12_271:                             #   in Loop: Header=BB12_252 Depth=1
	end_loop
	end_block                               # label211:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label117
# %bb.272:                              #   in Loop: Header=BB12_252 Depth=1
	i32.const	0
	local.set	8
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: up to label204
.LBB12_273:
	end_loop
	end_block                               # label117:
	local.get	7
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	8
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_term_bank,"",@
	.globl	parse_term_bank                 # -- Begin function parse_term_bank
	.type	parse_term_bank,@function
parse_term_bank:                        # @parse_term_bank
	.functype	parse_term_bank (i32, i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	i32.const	0
	local.get	4
	local.get	5
	local.get	6
	i32.const	0
	i32.ne  
	call	parse_term_bank_impl
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_term_bank_impl,"",@
	.type	parse_term_bank_impl,@function  # -- Begin function parse_term_bank_impl
parse_term_bank_impl:                   # @parse_term_bank_impl
	.functype	parse_term_bank_impl (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	32
	i32.sub 
	local.tee	8
	global.set	__stack_pointer
	block   	
	block   	
	block   	
	local.get	5
	br_if   	0                               # 0: down to label215
# %bb.1:
	i32.const	-1
	local.set	9
	local.get	6
	br_if   	2                               # 2: down to label213
# %bb.2:
	local.get	0
	i32.eqz
	br_if   	2                               # 2: down to label213
# %bb.3:
	local.get	1
	i32.eqz
	br_if   	2                               # 2: down to label213
# %bb.4:
	local.get	2
	i32.eqz
	br_if   	2                               # 2: down to label213
# %bb.5:
	local.get	3
	i32.eqz
	br_if   	2                               # 2: down to label213
# %bb.6:
	i32.const	0
	local.set	10
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
.LBB14_7:                               # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label217:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	6
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label216
# %bb.8:                                #   in Loop: Header=BB14_7 Depth=1
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label216
# %bb.9:                                #   in Loop: Header=BB14_7 Depth=1
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label217
	br      	4                               # 4: down to label213
.LBB14_10:
	end_loop
	end_block                               # label216:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label213
# %bb.11:
	local.get	6
	i32.const	91
	i32.ne  
	br_if   	2                               # 2: down to label213
# %bb.12:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label218
# %bb.13:
.LBB14_14:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label219:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label218
# %bb.15:                               #   in Loop: Header=BB14_14 Depth=1
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label218
# %bb.16:                               #   in Loop: Header=BB14_14 Depth=1
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label219
# %bb.17:
	end_loop
	local.get	1
	local.set	10
	br      	2                               # 2: down to label214
.LBB14_18:
	end_block                               # label218:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label214
# %bb.19:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	1                               # 1: down to label214
# %bb.20:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label220
# %bb.21:
.LBB14_22:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label221:
	local.get	0
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label220
# %bb.23:                               #   in Loop: Header=BB14_22 Depth=1
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label220
# %bb.24:                               #   in Loop: Header=BB14_22 Depth=1
	local.get	1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	i32.ne  
	br_if   	0                               # 0: up to label221
# %bb.25:
	end_loop
	local.get	1
	local.set	3
.LBB14_26:
	end_block                               # label220:
	i32.const	-1
	i32.const	0
	local.get	3
	local.get	1
	i32.ne  
	i32.select
	local.set	9
	br      	2                               # 2: down to label213
.LBB14_27:
	end_block                               # label215:
	i32.const	-1
	local.set	9
	local.get	0
	i32.eqz
	br_if   	1                               # 1: down to label213
# %bb.28:
	local.get	1
	i32.eqz
	br_if   	1                               # 1: down to label213
# %bb.29:
	local.get	2
	i32.eqz
	br_if   	1                               # 1: down to label213
# %bb.30:
	local.get	3
	i32.eqz
	br_if   	1                               # 1: down to label213
# %bb.31:
	local.get	6
	i32.eqz
	br_if   	1                               # 1: down to label213
# %bb.32:
	i32.const	0
	local.set	10
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
	local.get	8
	i32.const	0
	i32.store	28
	local.get	8
	i64.const	0
	i64.store	20:p2align=2
	local.get	8
	local.get	6
	i32.store	16
	local.get	8
	local.get	1
	i32.store	12
	local.get	8
	local.get	5
	i32.store	8
	local.get	8
	local.get	0
	i32.store	4
	block   	
	local.get	8
	i32.const	4
	i32.add 
	call	next_term_bank
	local.tee	5
	i32.const	1
	i32.lt_s
	br_if   	0                               # 0: down to label222
# %bb.33:
	local.get	2
	local.set	1
	i32.const	0
	local.set	10
.LBB14_34:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label223:
	block   	
	local.get	10
	local.get	3
	i32.lt_u
	br_if   	0                               # 0: down to label224
# %bb.35:                               #   in Loop: Header=BB14_34 Depth=1
	i32.const	-2
	local.set	9
	local.get	3
	i32.const	63161282
	i32.gt_u
	br_if   	4                               # 4: down to label213
# %bb.36:                               #   in Loop: Header=BB14_34 Depth=1
	local.get	2
	local.get	3
	i32.const	68
	i32.mul 
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	6
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label213
# %bb.37:                               #   in Loop: Header=BB14_34 Depth=1
	i32.const	0
	i32.load	heap_ptr
	local.get	6
	local.get	2
	i32.add 
	local.tee	5
	i32.ne  
	br_if   	4                               # 4: down to label213
# %bb.38:                               #   in Loop: Header=BB14_34 Depth=1
	i32.const	63161283
	local.get	3
	i32.const	1
	i32.shr_u
	local.tee	11
	i32.const	8192
	local.get	11
	i32.const	8192
	i32.gt_u
	i32.select
	local.tee	11
	local.get	3
	i32.add 
	local.get	3
	i32.const	63161283
	local.get	11
	i32.sub 
	i32.gt_u
	i32.select
	local.tee	3
	i32.const	68
	i32.mul 
	local.get	6
	i32.sub 
	i32.const	7
	i32.add 
	local.set	11
	local.get	5
	local.set	6
	block   	
	local.get	5
	br_if   	0                               # 0: down to label225
# %bb.39:                               #   in Loop: Header=BB14_34 Depth=1
	i32.const	__heap_base
	local.set	6
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB14_40:                              #   in Loop: Header=BB14_34 Depth=1
	end_block                               # label225:
	local.get	6
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	6
	local.get	11
	i32.const	-8
	i32.and 
	local.tee	11
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label213
# %bb.41:                               #   in Loop: Header=BB14_34 Depth=1
	block   	
	local.get	6
	local.get	11
	i32.add 
	local.tee	11
	i32.const	16
	i32.shr_u
	local.get	11
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	12
	memory.size	0
	local.tee	13
	i32.le_u
	br_if   	0                               # 0: down to label226
# %bb.42:                               #   in Loop: Header=BB14_34 Depth=1
	local.get	12
	local.get	13
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	5                               # 5: down to label213
.LBB14_43:                              #   in Loop: Header=BB14_34 Depth=1
	end_block                               # label226:
	i32.const	0
	local.get	11
	i32.store	heap_ptr
	local.get	6
	i32.eqz
	br_if   	4                               # 4: down to label213
# %bb.44:                               #   in Loop: Header=BB14_34 Depth=1
	local.get	6
	local.get	5
	i32.ne  
	br_if   	4                               # 4: down to label213
# %bb.45:                               #   in Loop: Header=BB14_34 Depth=1
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
.LBB14_46:                              #   in Loop: Header=BB14_34 Depth=1
	end_block                               # label224:
	local.get	8
	i32.const	0
	i32.store	0
	block   	
	local.get	0
	local.get	8
	i32.load	24
	local.get	8
	i32.load	28
	local.get	1
	local.get	4
	local.get	8
	i32.const	0
	i32.const	0
	i32.const	0
	i32.const	0
	local.get	7
	i32.const	0
	call	parse_row_single_pass
	br_if   	0                               # 0: down to label227
# %bb.47:
	i32.const	-1
	local.set	9
	br      	4                               # 4: down to label213
.LBB14_48:                              #   in Loop: Header=BB14_34 Depth=1
	end_block                               # label227:
	local.get	1
	i32.const	68
	i32.add 
	local.set	1
	local.get	10
	i32.const	1
	i32.add 
	local.set	10
	local.get	8
	i32.const	4
	i32.add 
	local.get	8
	i32.load	0
	call	next_term_row
	local.tee	5
	i32.const	0
	i32.gt_s
	br_if   	0                               # 0: up to label223
.LBB14_49:
	end_loop
	end_block                               # label222:
	i32.const	-1
	local.get	10
	local.get	5
	i32.select
	local.set	9
	br      	1                               # 1: down to label213
.LBB14_50:
	end_block                               # label214:
	i32.const	0
	local.set	6
.LBB14_51:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB14_67 Depth 2
                                        #     Child Loop BB14_81 Depth 2
	loop    	                                # label228:
	block   	
	local.get	10
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label229
# %bb.52:
	i32.const	-1
	local.set	9
	br      	2                               # 2: down to label213
.LBB14_53:                              #   in Loop: Header=BB14_51 Depth=1
	end_block                               # label229:
	block   	
	local.get	6
	local.get	3
	i32.lt_u
	br_if   	0                               # 0: down to label230
# %bb.54:                               #   in Loop: Header=BB14_51 Depth=1
	i32.const	-2
	local.set	9
	local.get	3
	i32.const	63161282
	i32.gt_u
	br_if   	2                               # 2: down to label213
# %bb.55:                               #   in Loop: Header=BB14_51 Depth=1
	local.get	2
	local.get	3
	i32.const	68
	i32.mul 
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	11
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	2                               # 2: down to label213
# %bb.56:                               #   in Loop: Header=BB14_51 Depth=1
	i32.const	0
	i32.load	heap_ptr
	local.get	11
	local.get	2
	i32.add 
	local.tee	5
	i32.ne  
	br_if   	2                               # 2: down to label213
# %bb.57:                               #   in Loop: Header=BB14_51 Depth=1
	i32.const	63161283
	local.get	3
	i32.const	1
	i32.shr_u
	local.tee	12
	i32.const	8192
	local.get	12
	i32.const	8192
	i32.gt_u
	i32.select
	local.tee	12
	local.get	3
	i32.add 
	local.get	3
	i32.const	63161283
	local.get	12
	i32.sub 
	i32.gt_u
	i32.select
	local.tee	3
	i32.const	68
	i32.mul 
	local.get	11
	i32.sub 
	i32.const	7
	i32.add 
	local.set	12
	local.get	5
	local.set	11
	block   	
	local.get	5
	br_if   	0                               # 0: down to label231
# %bb.58:                               #   in Loop: Header=BB14_51 Depth=1
	i32.const	__heap_base
	local.set	11
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB14_59:                              #   in Loop: Header=BB14_51 Depth=1
	end_block                               # label231:
	local.get	11
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	11
	local.get	12
	i32.const	-8
	i32.and 
	local.tee	12
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	2                               # 2: down to label213
# %bb.60:                               #   in Loop: Header=BB14_51 Depth=1
	block   	
	local.get	11
	local.get	12
	i32.add 
	local.tee	12
	i32.const	16
	i32.shr_u
	local.get	12
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	13
	memory.size	0
	local.tee	14
	i32.le_u
	br_if   	0                               # 0: down to label232
# %bb.61:                               #   in Loop: Header=BB14_51 Depth=1
	local.get	13
	local.get	14
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	3                               # 3: down to label213
.LBB14_62:                              #   in Loop: Header=BB14_51 Depth=1
	end_block                               # label232:
	i32.const	0
	local.get	12
	i32.store	heap_ptr
	local.get	11
	i32.eqz
	br_if   	2                               # 2: down to label213
# %bb.63:                               #   in Loop: Header=BB14_51 Depth=1
	local.get	11
	local.get	5
	i32.ne  
	br_if   	2                               # 2: down to label213
# %bb.64:                               #   in Loop: Header=BB14_51 Depth=1
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
.LBB14_65:                              #   in Loop: Header=BB14_51 Depth=1
	end_block                               # label230:
	local.get	8
	i32.const	0
	i32.store	4
	i32.const	-1
	local.set	9
	local.get	0
	local.get	1
	local.get	10
	local.get	2
	local.get	6
	i32.const	68
	i32.mul 
	i32.add 
	local.get	4
	local.get	8
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	i32.const	0
	i32.const	0
	local.get	7
	i32.const	0
	call	parse_row_single_pass
	i32.eqz
	br_if   	1                               # 1: down to label213
# %bb.66:                               #   in Loop: Header=BB14_51 Depth=1
	block   	
	local.get	8
	i32.load	4
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label233
.LBB14_67:                              #   Parent Loop BB14_51 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label234:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label233
# %bb.68:                               #   in Loop: Header=BB14_67 Depth=2
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label233
# %bb.69:                               #   in Loop: Header=BB14_67 Depth=2
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label234
	br      	3                               # 3: down to label213
.LBB14_70:                              #   in Loop: Header=BB14_51 Depth=1
	end_loop
	end_block                               # label233:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label213
# %bb.71:                               #   in Loop: Header=BB14_51 Depth=1
	local.get	6
	i32.const	1
	i32.add 
	local.set	6
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	5
	i32.const	44
	i32.eq  
	br_if   	0                               # 0: down to label235
# %bb.72:
	local.get	5
	i32.const	93
	i32.ne  
	br_if   	2                               # 2: down to label213
# %bb.73:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label236
# %bb.74:
.LBB14_75:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label237:
	local.get	0
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label236
# %bb.76:                               #   in Loop: Header=BB14_75 Depth=1
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label236
# %bb.77:                               #   in Loop: Header=BB14_75 Depth=1
	local.get	1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	i32.ne  
	br_if   	0                               # 0: up to label237
# %bb.78:
	end_loop
	local.get	1
	local.set	3
.LBB14_79:
	end_block                               # label236:
	local.get	6
	i32.const	-1
	local.get	3
	local.get	1
	i32.eq  
	i32.select
	local.set	9
	br      	2                               # 2: down to label213
.LBB14_80:                              #   in Loop: Header=BB14_51 Depth=1
	end_block                               # label235:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label238
.LBB14_81:                              #   Parent Loop BB14_51 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label239:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label238
# %bb.82:                               #   in Loop: Header=BB14_81 Depth=2
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label238
# %bb.83:                               #   in Loop: Header=BB14_81 Depth=2
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label239
	br      	3                               # 3: down to label213
.LBB14_84:                              #   in Loop: Header=BB14_51 Depth=1
	end_loop
	end_block                               # label238:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label213
# %bb.85:                               #   in Loop: Header=BB14_51 Depth=1
	i32.const	-1
	local.set	9
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: up to label228
.LBB14_86:
	end_loop
	end_block                               # label213:
	local.get	8
	i32.const	32
	i32.add 
	global.set	__stack_pointer
	local.get	9
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_term_bank_with_media_hints,"",@
	.globl	parse_term_bank_with_media_hints # -- Begin function parse_term_bank_with_media_hints
	.type	parse_term_bank_with_media_hints,@function
parse_term_bank_with_media_hints:       # @parse_term_bank_with_media_hints
	.functype	parse_term_bank_with_media_hints (i32, i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	i32.const	1
	local.get	4
	local.get	5
	local.get	6
	i32.const	0
	i32.ne  
	call	parse_term_bank_impl
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content,"",@
	.globl	encode_term_content             # -- Begin function encode_term_content
	.type	encode_term_content,@function
encode_term_content:                    # @encode_term_content
	.functype	encode_term_content (i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	local.get	4
	local.get	5
	i32.const	1
	call	encode_term_content_impl
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_impl,"",@
	.type	encode_term_content_impl,@function # -- Begin function encode_term_content_impl
encode_term_content_impl:               # @encode_term_content_impl
	.functype	encode_term_content_impl (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	7
	global.set	__stack_pointer
	i32.const	-1
	local.set	8
	block   	
	local.get	0
	i32.eqz
	br_if   	0                               # 0: down to label240
# %bb.1:
	local.get	1
	i32.eqz
	br_if   	0                               # 0: down to label240
# %bb.2:
	local.get	3
	i32.eqz
	br_if   	0                               # 0: down to label240
# %bb.3:
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label240
# %bb.4:
	i32.const	0
	local.set	8
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label240
# %bb.5:
	i32.const	0
	local.set	8
	i32.const	0
	local.set	9
.LBB17_6:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB17_7 Depth 2
	loop    	                                # label241:
	local.get	8
	local.tee	10
	i32.const	11
	i32.add 
	local.set	11
	local.get	3
	local.get	10
	i32.const	9
	i32.add 
	local.tee	12
	i32.add 
	local.set	13
	local.get	1
	local.get	9
	i32.const	68
	i32.mul 
	i32.add 
	local.set	14
	local.get	10
	i32.const	-10
	i32.gt_u
	local.set	15
	local.get	3
	local.get	10
	i32.add 
	local.tee	16
	i32.const	8
	i32.add 
	local.set	17
	local.get	12
	i32.const	-3
	i32.gt_u
	local.set	18
.LBB17_7:                               #   Parent Loop BB17_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	loop    	                                # label244:
	local.get	7
	i32.const	0
	i32.store	12
	local.get	7
	i32.const	0
	i32.store	8
	block   	
	local.get	15
	br_if   	0                               # 0: down to label245
# %bb.8:                                #   in Loop: Header=BB17_7 Depth=2
	local.get	12
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label245
# %bb.9:                                #   in Loop: Header=BB17_7 Depth=2
	local.get	17
	i32.const	0
	i32.load8_u	encode_term_content_row.PREFIX_RULES+8
	i32.store8	0
	local.get	16
	i32.const	0
	i64.load	encode_term_content_row.PREFIX_RULES:p2align=0
	i64.store	0:p2align=0
	block   	
	block   	
	local.get	14
	i32.load	28
	local.tee	19
	i32.eqz
	br_if   	0                               # 0: down to label247
# %bb.10:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	14
	i32.load	24
	local.set	20
	block   	
	local.get	19
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label248
# %bb.11:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	0
	local.get	20
	i32.add 
	local.tee	21
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label248
# %bb.12:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label248
# %bb.13:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label248
# %bb.14:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label247
.LBB17_15:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label248:
	local.get	19
	local.get	12
	i32.add 
	local.tee	21
	local.get	19
	i32.lt_u
	br_if   	2                               # 2: down to label245
# %bb.16:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	local.get	4
	i32.gt_u
	br_if   	2                               # 2: down to label245
# %bb.17:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label246
# %bb.18:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	13
	local.get	0
	local.get	20
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label246
.LBB17_19:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label247:
	local.get	18
	br_if   	1                               # 1: down to label245
# %bb.20:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	11
	local.get	4
	i32.gt_u
	br_if   	1                               # 1: down to label245
# %bb.21:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	13
	i32.const	8738
	i32.store16	0:p2align=0
	local.get	11
	local.set	21
.LBB17_22:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label246:
	local.get	21
	i32.const	-19
	i32.gt_u
	br_if   	0                               # 0: down to label245
# %bb.23:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	i32.const	18
	i32.add 
	local.tee	20
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label245
# %bb.24:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	3
	local.get	21
	i32.add 
	local.tee	19
	i32.const	0
	v128.load	encode_term_content_row.PREFIX_DEFINITION_TAGS
	v128.store	0:p2align=0
	local.get	19
	i32.const	16
	i32.add 
	i32.const	0
	i32.load16_u	encode_term_content_row.PREFIX_DEFINITION_TAGS+16
	i32.store16	0:p2align=0
	block   	
	block   	
	local.get	14
	i32.load	20
	local.tee	19
	i32.eqz
	br_if   	0                               # 0: down to label250
# %bb.25:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	14
	i32.load	16
	local.set	8
	block   	
	local.get	19
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label251
# %bb.26:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	0
	local.get	8
	i32.add 
	local.tee	22
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label251
# %bb.27:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	22
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label251
# %bb.28:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	22
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label251
# %bb.29:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	22
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label250
.LBB17_30:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label251:
	local.get	19
	local.get	20
	i32.add 
	local.tee	21
	local.get	19
	i32.lt_u
	br_if   	2                               # 2: down to label245
# %bb.31:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	local.get	4
	i32.gt_u
	br_if   	2                               # 2: down to label245
# %bb.32:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label249
# %bb.33:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	3
	local.get	20
	i32.add 
	local.get	0
	local.get	8
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label249
.LBB17_34:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label250:
	local.get	20
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label245
# %bb.35:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	i32.const	20
	i32.add 
	local.tee	21
	local.get	4
	i32.gt_u
	br_if   	1                               # 1: down to label245
# %bb.36:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	3
	local.get	20
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB17_37:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label249:
	local.get	21
	i32.const	-13
	i32.gt_u
	br_if   	0                               # 0: down to label245
# %bb.38:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	i32.const	12
	i32.add 
	local.tee	20
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label245
# %bb.39:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	3
	local.get	21
	i32.add 
	local.tee	19
	i32.const	0
	i64.load	encode_term_content_row.PREFIX_TERM_TAGS:p2align=0
	i64.store	0:p2align=0
	local.get	19
	i32.const	8
	i32.add 
	i32.const	0
	i32.load	encode_term_content_row.PREFIX_TERM_TAGS+8:p2align=0
	i32.store	0:p2align=0
	block   	
	block   	
	local.get	14
	i32.load	52
	local.tee	19
	i32.eqz
	br_if   	0                               # 0: down to label253
# %bb.40:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	14
	i32.load	48
	local.set	8
	block   	
	local.get	19
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label254
# %bb.41:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	0
	local.get	8
	i32.add 
	local.tee	22
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label254
# %bb.42:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	22
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label254
# %bb.43:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	22
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label254
# %bb.44:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	22
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label253
.LBB17_45:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label254:
	local.get	19
	local.get	20
	i32.add 
	local.tee	21
	local.get	19
	i32.lt_u
	br_if   	2                               # 2: down to label245
# %bb.46:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	local.get	4
	i32.gt_u
	br_if   	2                               # 2: down to label245
# %bb.47:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label252
# %bb.48:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	3
	local.get	20
	i32.add 
	local.get	0
	local.get	8
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label252
.LBB17_49:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label253:
	local.get	20
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label245
# %bb.50:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	i32.const	14
	i32.add 
	local.tee	21
	local.get	4
	i32.gt_u
	br_if   	1                               # 1: down to label245
# %bb.51:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	3
	local.get	20
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB17_52:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label252:
	local.get	21
	i32.const	-13
	i32.gt_u
	br_if   	0                               # 0: down to label245
# %bb.53:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	i32.const	12
	i32.add 
	local.tee	19
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label245
# %bb.54:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	3
	local.get	21
	i32.add 
	local.tee	20
	i32.const	0
	i64.load	encode_term_content_row.PREFIX_GLOSSARY:p2align=0
	i64.store	0:p2align=0
	local.get	20
	i32.const	8
	i32.add 
	i32.const	0
	i32.load	encode_term_content_row.PREFIX_GLOSSARY+8:p2align=0
	i32.store	0:p2align=0
	local.get	7
	local.get	19
	i32.store	4
	block   	
	block   	
	local.get	14
	i32.load	40
	local.tee	20
	i32.eqz
	br_if   	0                               # 0: down to label256
# %bb.55:                               #   in Loop: Header=BB17_7 Depth=2
	block   	
	local.get	14
	i32.load	60
	br_if   	0                               # 0: down to label257
# %bb.56:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	20
	local.get	19
	i32.add 
	local.tee	21
	local.get	20
	i32.lt_u
	br_if   	3                               # 3: down to label245
# %bb.57:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	local.get	4
	i32.gt_u
	br_if   	3                               # 3: down to label245
# %bb.58:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	20
	i32.eqz
	br_if   	2                               # 2: down to label255
# %bb.59:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	3
	local.get	19
	i32.add 
	local.get	0
	local.get	14
	i32.load	36
	i32.add 
	local.get	20
	memory.copy	0, 0
	br      	2                               # 2: down to label255
.LBB17_60:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label257:
	local.get	0
	local.get	14
	i32.load	36
	local.tee	19
	local.get	20
	i32.add 
	local.tee	21
	local.get	19
	local.get	21
	local.get	3
	local.get	4
	local.get	7
	i32.const	4
	i32.add 
	call	write_normalized_glossary_value
	i32.eqz
	br_if   	2                               # 2: down to label245
# %bb.61:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	7
	i32.load	4
	local.set	21
	br      	1                               # 1: down to label255
.LBB17_62:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label256:
	local.get	19
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label245
# %bb.63:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	i32.const	14
	i32.add 
	local.tee	21
	local.get	4
	i32.gt_u
	br_if   	1                               # 1: down to label245
# %bb.64:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	3
	local.get	19
	i32.add 
	i32.const	23899
	i32.store16	0:p2align=0
.LBB17_65:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label255:
	local.get	21
	local.get	4
	i32.ge_u
	br_if   	0                               # 0: down to label245
# %bb.66:                               #   in Loop: Header=BB17_6 Depth=1
	local.get	3
	local.get	21
	i32.add 
	i32.const	125
	i32.store8	0
	local.get	7
	local.get	21
	i32.const	1
	i32.add 
	local.tee	8
	i32.store	4
	local.get	8
	local.get	10
	i32.sub 
	local.set	21
	local.get	6
	br_if   	2                               # 2: down to label243
# %bb.67:                               #   in Loop: Header=BB17_6 Depth=1
	i32.const	0
	local.set	20
	i32.const	0
	local.set	12
	br      	3                               # 3: down to label242
.LBB17_68:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label245:
	local.get	7
	local.get	10
	i32.store	4
	i32.const	-2
	local.set	8
	local.get	4
	i32.const	2147483646
	i32.gt_u
	br_if   	4                               # 4: down to label240
# %bb.69:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	3
	local.get	4
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	21
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label240
# %bb.70:                               #   in Loop: Header=BB17_7 Depth=2
	i32.const	0
	i32.load	heap_ptr
	local.get	21
	local.get	3
	i32.add 
	local.tee	19
	i32.ne  
	br_if   	4                               # 4: down to label240
# %bb.71:                               #   in Loop: Header=BB17_7 Depth=2
	i32.const	2147483647
	local.get	4
	i32.const	1
	i32.shr_u
	local.tee	20
	i32.const	1048576
	local.get	20
	i32.const	1048576
	i32.gt_u
	i32.select
	local.tee	20
	local.get	4
	i32.add 
	local.get	4
	local.get	20
	i32.const	2147483647
	i32.xor 
	i32.gt_u
	i32.select
	local.tee	4
	local.get	21
	i32.sub 
	i32.const	7
	i32.add 
	local.set	20
	local.get	19
	local.set	21
	block   	
	local.get	19
	br_if   	0                               # 0: down to label258
# %bb.72:                               #   in Loop: Header=BB17_7 Depth=2
	i32.const	__heap_base
	local.set	21
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB17_73:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label258:
	local.get	21
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	21
	local.get	20
	i32.const	-8
	i32.and 
	local.tee	20
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label240
# %bb.74:                               #   in Loop: Header=BB17_7 Depth=2
	block   	
	local.get	21
	local.get	20
	i32.add 
	local.tee	20
	i32.const	16
	i32.shr_u
	local.get	20
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	22
	memory.size	0
	local.tee	23
	i32.le_u
	br_if   	0                               # 0: down to label259
# %bb.75:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	22
	local.get	23
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	5                               # 5: down to label240
.LBB17_76:                              #   in Loop: Header=BB17_7 Depth=2
	end_block                               # label259:
	i32.const	0
	local.get	20
	i32.store	heap_ptr
	local.get	21
	i32.eqz
	br_if   	4                               # 4: down to label240
# %bb.77:                               #   in Loop: Header=BB17_7 Depth=2
	local.get	21
	local.get	19
	i32.ne  
	br_if   	4                               # 4: down to label240
# %bb.78:                               #   in Loop: Header=BB17_7 Depth=2
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	br      	0                               # 0: up to label244
.LBB17_79:                              #   in Loop: Header=BB17_6 Depth=1
	end_loop
	end_block                               # label243:
	local.get	16
	local.get	21
	local.get	7
	i32.const	12
	i32.add 
	local.get	7
	i32.const	8
	i32.add 
	call	hash_content_xxh32_pair
	local.get	7
	i32.load	12
	local.tee	19
	i32.const	1
	local.get	19
	local.get	7
	i32.load	8
	local.tee	12
	i32.or  
	i32.select
	local.set	20
.LBB17_80:                              #   in Loop: Header=BB17_6 Depth=1
	end_block                               # label242:
	local.get	5
	local.get	9
	i32.const	4
	i32.shl 
	i32.add 
	local.tee	19
	local.get	12
	i32.store	12
	local.get	19
	local.get	20
	i32.store	8
	local.get	19
	local.get	21
	i32.store	4
	local.get	19
	local.get	10
	i32.store	0
	local.get	9
	i32.const	1
	i32.add 
	local.tee	9
	local.get	2
	i32.ne  
	br_if   	0                               # 0: up to label241
.LBB17_81:
	end_loop
	end_block                               # label240:
	local.get	7
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	8
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_no_hash,"",@
	.globl	encode_term_content_no_hash     # -- Begin function encode_term_content_no_hash
	.type	encode_term_content_no_hash,@function
encode_term_content_no_hash:            # @encode_term_content_no_hash
	.functype	encode_term_content_no_hash (i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	local.get	4
	local.get	5
	i32.const	0
	call	encode_term_content_impl
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_token_binary,"",@
	.globl	encode_term_content_token_binary # -- Begin function encode_term_content_token_binary
	.type	encode_term_content_token_binary,@function
encode_term_content_token_binary:       # @encode_term_content_token_binary
	.functype	encode_term_content_token_binary (i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	6
	global.set	__stack_pointer
	i32.const	-1
	local.set	7
	block   	
	local.get	0
	i32.eqz
	br_if   	0                               # 0: down to label260
# %bb.1:
	local.get	1
	i32.eqz
	br_if   	0                               # 0: down to label260
# %bb.2:
	local.get	3
	i32.eqz
	br_if   	0                               # 0: down to label260
# %bb.3:
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label260
# %bb.4:
	i32.const	0
	local.set	7
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	6
	i32.const	0
	i32.store	12
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label260
# %bb.5:
	i32.const	0
	local.set	8
	i32.const	0
	local.set	9
.LBB19_6:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB19_7 Depth 2
	loop    	                                # label261:
	local.get	6
	i32.const	0
	i32.store	8
	local.get	6
	i32.const	0
	i32.store	4
	block   	
	local.get	0
	local.get	1
	local.get	9
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	10
	local.get	3
	local.get	4
	local.get	6
	i32.const	12
	i32.add 
	local.get	6
	i32.const	8
	i32.add 
	local.get	6
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	call	encode_term_content_token_binary_row
	br_if   	0                               # 0: down to label262
.LBB19_7:                               #   Parent Loop BB19_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label263:
	local.get	6
	local.get	8
	i32.store	12
	block   	
	block   	
	local.get	4
	i32.const	2147483646
	i32.gt_u
	br_if   	0                               # 0: down to label265
# %bb.8:                                #   in Loop: Header=BB19_7 Depth=2
	local.get	3
	local.get	4
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	11
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	0                               # 0: down to label265
# %bb.9:                                #   in Loop: Header=BB19_7 Depth=2
	i32.const	0
	i32.load	heap_ptr
	local.get	11
	local.get	3
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: down to label265
# %bb.10:                               #   in Loop: Header=BB19_7 Depth=2
	i32.const	2147483647
	local.get	4
	i32.const	1
	i32.shr_u
	local.tee	12
	i32.const	1048576
	local.get	12
	i32.const	1048576
	i32.gt_u
	i32.select
	local.tee	12
	local.get	4
	i32.add 
	local.get	4
	local.get	12
	i32.const	2147483647
	i32.xor 
	i32.gt_u
	i32.select
	local.tee	4
	local.get	11
	i32.sub 
	i32.const	7
	i32.add 
	local.set	12
	local.get	7
	local.set	11
	block   	
	local.get	7
	br_if   	0                               # 0: down to label266
# %bb.11:                               #   in Loop: Header=BB19_7 Depth=2
	i32.const	__heap_base
	local.set	11
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB19_12:                              #   in Loop: Header=BB19_7 Depth=2
	end_block                               # label266:
	local.get	11
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	11
	local.get	12
	i32.const	-8
	i32.and 
	local.tee	12
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	0                               # 0: down to label265
# %bb.13:                               #   in Loop: Header=BB19_7 Depth=2
	block   	
	local.get	11
	local.get	12
	i32.add 
	local.tee	12
	i32.const	16
	i32.shr_u
	local.get	12
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	13
	memory.size	0
	local.tee	14
	i32.le_u
	br_if   	0                               # 0: down to label267
# %bb.14:                               #   in Loop: Header=BB19_7 Depth=2
	local.get	13
	local.get	14
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	1                               # 1: down to label265
.LBB19_15:                              #   in Loop: Header=BB19_7 Depth=2
	end_block                               # label267:
	i32.const	0
	local.get	12
	i32.store	heap_ptr
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label265
# %bb.16:                               #   in Loop: Header=BB19_7 Depth=2
	local.get	11
	local.get	7
	i32.eq  
	br_if   	1                               # 1: down to label264
.LBB19_17:
	end_block                               # label265:
	i32.const	-2
	local.set	7
	br      	4                               # 4: down to label260
.LBB19_18:                              #   in Loop: Header=BB19_7 Depth=2
	end_block                               # label264:
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	0
	local.get	10
	local.get	3
	local.get	4
	local.get	6
	i32.const	12
	i32.add 
	local.get	6
	i32.const	8
	i32.add 
	local.get	6
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	call	encode_term_content_token_binary_row
	i32.eqz
	br_if   	0                               # 0: up to label263
.LBB19_19:                              #   in Loop: Header=BB19_6 Depth=1
	end_loop
	end_block                               # label262:
	local.get	5
	local.get	9
	i32.const	4
	i32.shl 
	i32.add 
	local.tee	11
	local.get	8
	i32.store	0
	local.get	11
	local.get	6
	i32.load	12
	local.tee	7
	local.get	8
	i32.sub 
	i32.store	4
	local.get	11
	local.get	6
	i32.load	8
	i32.store	8
	local.get	11
	local.get	6
	i32.load	4
	i32.store	12
	local.get	7
	local.set	8
	local.get	9
	i32.const	1
	i32.add 
	local.tee	9
	local.get	2
	i32.ne  
	br_if   	0                               # 0: up to label261
.LBB19_20:
	end_loop
	end_block                               # label260:
	local.get	6
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	7
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_token_binary_row,"",@
	.type	encode_term_content_token_binary_row,@function # -- Begin function encode_term_content_token_binary_row
encode_term_content_token_binary_row:   # @encode_term_content_token_binary_row
	.functype	encode_term_content_token_binary_row (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	9
	global.set	__stack_pointer
	i32.const	0
	local.set	10
	block   	
	local.get	4
	i32.load	0
	local.tee	11
	i32.const	-5
	i32.gt_u
	br_if   	0                               # 0: down to label268
# %bb.1:
	local.get	11
	i32.const	4
	i32.add 
	local.tee	12
	local.get	3
	i32.gt_u
	br_if   	0                               # 0: down to label268
# %bb.2:
	local.get	2
	local.get	11
	i32.add 
	local.tee	13
	i32.const	911360589
	i32.store	0:p2align=0
	local.get	4
	local.get	12
	i32.store	0
	local.get	1
	i32.load	52
	local.set	14
	local.get	1
	i32.load	20
	local.set	15
	local.get	1
	i32.load	48
	local.set	16
	local.get	1
	i32.load	16
	local.set	17
	local.get	1
	i32.load	24
	local.set	18
	block   	
	block   	
	block   	
	block   	
	local.get	1
	i32.load	28
	local.tee	19
	br_table 	{2, 1, 1, 1, 0, 1}      # 1: down to label271
                                        # 0: down to label272
.LBB20_3:
	end_block                               # label272:
	local.get	0
	local.get	18
	i32.add 
	local.tee	20
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label271
# %bb.4:
	local.get	20
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label271
# %bb.5:
	local.get	20
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label271
# %bb.6:
	local.get	20
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label270
.LBB20_7:
	end_block                               # label271:
	local.get	12
	local.get	19
	i32.add 
	local.tee	20
	local.get	12
	i32.lt_u
	br_if   	2                               # 2: down to label268
# %bb.8:
	local.get	20
	local.get	3
	i32.gt_u
	br_if   	2                               # 2: down to label268
# %bb.9:
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label269
# %bb.10:
	local.get	2
	local.get	12
	i32.add 
	local.get	0
	local.get	18
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label269
.LBB20_11:
	end_block                               # label270:
	local.get	12
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label268
# %bb.12:
	local.get	11
	i32.const	6
	i32.add 
	local.tee	20
	local.get	3
	i32.gt_u
	br_if   	1                               # 1: down to label268
# %bb.13:
	local.get	2
	local.get	12
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB20_14:
	end_block                               # label269:
	local.get	4
	local.get	20
	i32.store	0
	local.get	20
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label268
# %bb.15:
	i32.const	0
	local.set	10
	local.get	2
	local.get	20
	i32.add 
	i32.const	0
	i32.store8	0
	local.get	4
	local.get	4
	i32.load	0
	local.tee	20
	i32.const	1
	i32.add 
	local.tee	12
	i32.store	0
	block   	
	block   	
	block   	
	block   	
	local.get	15
	br_table 	{2, 1, 1, 1, 0, 1}      # 1: down to label275
                                        # 0: down to label276
.LBB20_16:
	end_block                               # label276:
	local.get	0
	local.get	17
	i32.add 
	local.tee	19
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label275
# %bb.17:
	local.get	19
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label275
# %bb.18:
	local.get	19
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label275
# %bb.19:
	local.get	19
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label274
.LBB20_20:
	end_block                               # label275:
	local.get	12
	local.get	15
	i32.add 
	local.tee	20
	local.get	12
	i32.lt_u
	br_if   	2                               # 2: down to label268
# %bb.21:
	local.get	20
	local.get	3
	i32.gt_u
	br_if   	2                               # 2: down to label268
# %bb.22:
	local.get	15
	i32.eqz
	br_if   	1                               # 1: down to label273
# %bb.23:
	local.get	2
	local.get	12
	i32.add 
	local.get	0
	local.get	17
	i32.add 
	local.get	15
	memory.copy	0, 0
	br      	1                               # 1: down to label273
.LBB20_24:
	end_block                               # label274:
	local.get	12
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label268
# %bb.25:
	local.get	20
	i32.const	3
	i32.add 
	local.tee	20
	local.get	3
	i32.gt_u
	br_if   	1                               # 1: down to label268
# %bb.26:
	local.get	2
	local.get	12
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB20_27:
	end_block                               # label273:
	local.get	4
	local.get	20
	i32.store	0
	local.get	20
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label268
# %bb.28:
	i32.const	0
	local.set	10
	local.get	2
	local.get	20
	i32.add 
	i32.const	0
	i32.store8	0
	local.get	4
	local.get	4
	i32.load	0
	local.tee	20
	i32.const	1
	i32.add 
	local.tee	12
	i32.store	0
	block   	
	block   	
	block   	
	block   	
	local.get	14
	br_table 	{2, 1, 1, 1, 0, 1}      # 1: down to label279
                                        # 0: down to label280
.LBB20_29:
	end_block                               # label280:
	local.get	0
	local.get	16
	i32.add 
	local.tee	19
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label279
# %bb.30:
	local.get	19
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label279
# %bb.31:
	local.get	19
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label279
# %bb.32:
	local.get	19
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label278
.LBB20_33:
	end_block                               # label279:
	local.get	12
	local.get	14
	i32.add 
	local.tee	20
	local.get	12
	i32.lt_u
	br_if   	2                               # 2: down to label268
# %bb.34:
	local.get	20
	local.get	3
	i32.gt_u
	br_if   	2                               # 2: down to label268
# %bb.35:
	local.get	14
	i32.eqz
	br_if   	1                               # 1: down to label277
# %bb.36:
	local.get	2
	local.get	12
	i32.add 
	local.get	0
	local.get	16
	i32.add 
	local.get	14
	memory.copy	0, 0
	br      	1                               # 1: down to label277
.LBB20_37:
	end_block                               # label278:
	local.get	12
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label268
# %bb.38:
	local.get	20
	i32.const	3
	i32.add 
	local.tee	20
	local.get	3
	i32.gt_u
	br_if   	1                               # 1: down to label268
# %bb.39:
	local.get	2
	local.get	12
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB20_40:
	end_block                               # label277:
	local.get	4
	local.get	20
	i32.store	0
	local.get	20
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label268
# %bb.41:
	i32.const	0
	local.set	10
	local.get	2
	local.get	20
	i32.add 
	i32.const	0
	i32.store8	0
	local.get	4
	local.get	4
	i32.load	0
	local.tee	19
	i32.const	1
	i32.add 
	local.tee	12
	i32.store	0
	block   	
	block   	
	local.get	1
	i32.load	40
	local.tee	20
	i32.eqz
	br_if   	0                               # 0: down to label282
# %bb.42:
	block   	
	local.get	1
	i32.load	64
	br_if   	0                               # 0: down to label283
# %bb.43:
	i32.const	0
	local.set	10
	local.get	12
	local.get	20
	i32.add 
	local.tee	8
	local.get	12
	i32.lt_u
	br_if   	3                               # 3: down to label268
# %bb.44:
	local.get	8
	local.get	3
	i32.gt_u
	br_if   	3                               # 3: down to label268
# %bb.45:
	block   	
	local.get	20
	i32.eqz
	br_if   	0                               # 0: down to label284
# %bb.46:
	local.get	2
	local.get	12
	i32.add 
	local.get	0
	local.get	1
	i32.load	36
	i32.add 
	local.get	20
	memory.copy	0, 0
.LBB20_47:
	end_block                               # label284:
	local.get	4
	local.get	8
	i32.store	0
	br      	2                               # 2: down to label281
.LBB20_48:
	end_block                               # label283:
	block   	
	local.get	7
	i32.const	16
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label285
# %bb.49:
	i32.const	1
	local.set	19
	block   	
	local.get	1
	i32.load	36
	local.tee	10
	local.get	10
	local.get	20
	i32.add 
	local.tee	20
	i32.ge_u
	br_if   	0                               # 0: down to label286
# %bb.50:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label286
# %bb.51:
	i32.const	1
	local.set	19
	block   	
	local.get	12
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label287
# %bb.52:
	local.get	2
	local.get	12
	i32.add 
	i32.const	91
	i32.store8	0
	i32.const	1
	local.set	19
	local.get	4
	local.get	4
	i32.load	0
	i32.const	1
	i32.add 
	local.tee	18
	i32.store	0
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label287
# %bb.53:
	local.get	0
	i32.const	1
	i32.add 
	local.set	21
	local.get	0
	i32.const	2
	i32.add 
	local.set	22
	local.get	0
	i32.const	5
	i32.add 
	local.set	23
	local.get	0
	i32.const	4
	i32.add 
	local.set	24
	local.get	0
	i32.const	3
	i32.add 
	local.set	25
	i32.const	0
	local.set	17
.LBB20_54:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB20_55 Depth 2
                                        #     Child Loop BB20_64 Depth 2
                                        #     Child Loop BB20_69 Depth 2
                                        #       Child Loop BB20_70 Depth 3
                                        #       Child Loop BB20_84 Depth 3
                                        #       Child Loop BB20_137 Depth 3
                                        #       Child Loop BB20_143 Depth 3
                                        #       Child Loop BB20_172 Depth 3
                                        #     Child Loop BB20_195 Depth 2
	loop    	                                # label288:
	block   	
	local.get	10
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label289
.LBB20_55:                              #   Parent Loop BB20_54 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label290:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	19
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label289
# %bb.56:                               #   in Loop: Header=BB20_55 Depth=2
	i32.const	1
	local.get	19
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label289
# %bb.57:                               #   in Loop: Header=BB20_55 Depth=2
	i32.const	1
	local.set	19
	local.get	20
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label290
	br      	3                               # 3: down to label287
.LBB20_58:                              #   in Loop: Header=BB20_54 Depth=1
	end_loop
	end_block                               # label289:
	i32.const	1
	local.set	19
	local.get	10
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label287
# %bb.59:                               #   in Loop: Header=BB20_54 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	local.tee	16
	i32.load8_u	0
	local.tee	7
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: down to label291
# %bb.60:
	local.get	18
	local.get	3
	i32.ge_u
	br_if   	2                               # 2: down to label287
# %bb.61:
	local.get	2
	local.get	18
	i32.add 
	i32.const	93
	i32.store8	0
	local.get	4
	i32.load	0
	i32.const	1
	i32.add 
	local.set	12
	i32.const	0
	local.set	19
	br      	2                               # 2: down to label287
.LBB20_62:                              #   in Loop: Header=BB20_54 Depth=1
	end_block                               # label291:
	local.get	9
	i32.const	0
	i32.store	8
	block   	
	block   	
	block   	
	local.get	7
	i32.const	123
	i32.ne  
	br_if   	0                               # 0: down to label294
# %bb.63:                               #   in Loop: Header=BB20_54 Depth=1
	block   	
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label296
.LBB20_64:                              #   Parent Loop BB20_54 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label297:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label296
# %bb.65:                               #   in Loop: Header=BB20_64 Depth=2
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label296
# %bb.66:                               #   in Loop: Header=BB20_64 Depth=2
	local.get	20
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label297
	br      	2                               # 2: down to label295
.LBB20_67:                              #   in Loop: Header=BB20_54 Depth=1
	end_loop
	end_block                               # label296:
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label295
# %bb.68:                               #   in Loop: Header=BB20_54 Depth=1
	i32.const	0
	local.set	26
	i32.const	0
	local.set	27
	i32.const	0
	local.set	14
	i32.const	0
	local.set	28
	i32.const	0
	local.set	29
.LBB20_69:                              #   Parent Loop BB20_54 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB20_70 Depth 3
                                        #       Child Loop BB20_84 Depth 3
                                        #       Child Loop BB20_137 Depth 3
                                        #       Child Loop BB20_143 Depth 3
                                        #       Child Loop BB20_172 Depth 3
	loop    	                                # label298:
	block   	
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label299
.LBB20_70:                              #   Parent Loop BB20_54 Depth=1
                                        #     Parent Loop BB20_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label300:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label299
# %bb.71:                               #   in Loop: Header=BB20_70 Depth=3
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label299
# %bb.72:                               #   in Loop: Header=BB20_70 Depth=3
	local.get	20
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label300
	br      	3                               # 3: down to label295
.LBB20_73:                              #   in Loop: Header=BB20_69 Depth=2
	end_loop
	end_block                               # label299:
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label295
# %bb.74:                               #   in Loop: Header=BB20_69 Depth=2
	block   	
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	local.tee	18
	i32.const	125
	i32.ne  
	br_if   	0                               # 0: down to label301
# %bb.75:                               #   in Loop: Header=BB20_54 Depth=1
	local.get	27
	i32.const	2
	i32.ne  
	br_if   	2                               # 2: down to label295
# %bb.76:                               #   in Loop: Header=BB20_54 Depth=1
	local.get	26
	i32.eqz
	br_if   	2                               # 2: down to label295
# %bb.77:                               #   in Loop: Header=BB20_54 Depth=1
	local.get	29
	i32.eqz
	br_if   	2                               # 2: down to label295
# %bb.78:                               #   in Loop: Header=BB20_54 Depth=1
	local.get	16
	i32.load8_u	0
	i32.const	91
	i32.eq  
	br_if   	7                               # 7: down to label287
# %bb.79:                               #   in Loop: Header=BB20_54 Depth=1
	i32.const	1
	local.set	18
	local.get	7
	i32.const	1
	i32.add 
	local.set	7
	br      	5                               # 5: down to label292
.LBB20_80:                              #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label301:
	local.get	27
	i32.const	1
	i32.gt_u
	br_if   	1                               # 1: down to label295
# %bb.81:                               #   in Loop: Header=BB20_69 Depth=2
	local.get	18
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label295
# %bb.82:                               #   in Loop: Header=BB20_69 Depth=2
	local.get	7
	i32.const	1
	i32.add 
	local.tee	30
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label295
# %bb.83:                               #   in Loop: Header=BB20_69 Depth=2
	local.get	30
	local.set	15
.LBB20_84:                              #   Parent Loop BB20_54 Depth=1
                                        #     Parent Loop BB20_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label302:
	block   	
	local.get	15
	local.tee	18
	i32.const	8
	i32.add 
	local.tee	15
	local.get	20
	i32.gt_u
	br_if   	0                               # 0: down to label303
# %bb.85:                               #   in Loop: Header=BB20_84 Depth=3
	local.get	0
	local.get	18
	i32.add 
	i64.load	0:p2align=0
	local.tee	31
	i64.const	-1
	i64.xor 
	local.get	31
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	31
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	31
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	31
	i64.eqz
	br_if   	1                               # 1: up to label302
# %bb.86:                               #   in Loop: Header=BB20_84 Depth=3
	local.get	31
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	18
	i32.add 
	local.set	18
.LBB20_87:                              #   in Loop: Header=BB20_84 Depth=3
	end_block                               # label303:
	local.get	18
	local.get	20
	i32.ge_u
	br_if   	2                               # 2: down to label295
# %bb.88:                               #   in Loop: Header=BB20_84 Depth=3
	block   	
	block   	
	block   	
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label306
# %bb.89:                               #   in Loop: Header=BB20_84 Depth=3
	local.get	18
	i32.const	1
	i32.add 
	local.tee	15
	local.get	20
	i32.ge_u
	br_if   	5                               # 5: down to label295
# %bb.90:                               #   in Loop: Header=BB20_84 Depth=3
	block   	
	block   	
	local.get	0
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 1, 0, 7} # 7: down to label295
                                        # 1: down to label307
                                        # 0: down to label308
.LBB20_91:                              #   in Loop: Header=BB20_84 Depth=3
	end_block                               # label308:
	local.get	18
	i32.const	6
	i32.add 
	local.tee	15
	local.get	20
	i32.gt_u
	br_if   	6                               # 6: down to label295
# %bb.92:                               #   in Loop: Header=BB20_84 Depth=3
	local.get	18
	i32.const	2
	i32.add 
	local.tee	32
	local.get	15
	i32.ge_u
	br_if   	2                               # 2: down to label305
# %bb.93:                               #   in Loop: Header=BB20_84 Depth=3
	block   	
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label309
# %bb.94:                               #   in Loop: Header=BB20_84 Depth=3
	local.get	32
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label295
.LBB20_95:                              #   in Loop: Header=BB20_84 Depth=3
	end_block                               # label309:
	block   	
	local.get	25
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label310
# %bb.96:                               #   in Loop: Header=BB20_84 Depth=3
	local.get	32
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label295
.LBB20_97:                              #   in Loop: Header=BB20_84 Depth=3
	end_block                               # label310:
	block   	
	local.get	24
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label311
# %bb.98:                               #   in Loop: Header=BB20_84 Depth=3
	local.get	32
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label295
.LBB20_99:                              #   in Loop: Header=BB20_84 Depth=3
	end_block                               # label311:
	local.get	23
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	18
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label305
# %bb.100:                              #   in Loop: Header=BB20_84 Depth=3
	local.get	18
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label305
	br      	6                               # 6: down to label295
.LBB20_101:                             #   in Loop: Header=BB20_84 Depth=3
	end_block                               # label307:
	local.get	18
	i32.const	2
	i32.add 
	local.set	15
	br      	1                               # 1: down to label305
.LBB20_102:                             #   in Loop: Header=BB20_84 Depth=3
	end_block                               # label306:
	local.get	32
	i32.const	32
	i32.lt_u
	br_if   	4                               # 4: down to label295
# %bb.103:                              #   in Loop: Header=BB20_84 Depth=3
	local.get	18
	i32.const	1
	i32.add 
	local.set	15
	local.get	32
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label304
.LBB20_104:                             #   in Loop: Header=BB20_84 Depth=3
	end_block                               # label305:
	local.get	15
	local.get	20
	i32.lt_u
	br_if   	1                               # 1: up to label302
	br      	3                               # 3: down to label295
.LBB20_105:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label304:
	end_loop
	i32.const	0
	local.set	32
	i32.const	0
	local.set	33
	block   	
	local.get	18
	local.get	7
	i32.lt_u
	br_if   	0                               # 0: down to label312
# %bb.106:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	7
	i32.const	5
	i32.add 
	local.set	34
	i32.const	0
	local.set	33
	i32.const	0
	local.set	32
	block   	
	local.get	18
	local.get	7
	i32.eq  
	br_if   	0                               # 0: down to label313
# %bb.107:                              #   in Loop: Header=BB20_69 Depth=2
	block   	
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label314
# %bb.108:                              #   in Loop: Header=BB20_69 Depth=2
	i32.const	0
	local.set	32
	local.get	18
	local.get	7
	i32.sub 
	local.tee	36
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label313
# %bb.109:                              #   in Loop: Header=BB20_69 Depth=2
	i32.const	0
	local.set	32
	local.get	35
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label313
# %bb.110:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	22
	local.get	7
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label314
# %bb.111:                              #   in Loop: Header=BB20_69 Depth=2
	i32.const	0
	local.set	32
	local.get	35
	i32.const	121
	i32.ne  
	br_if   	1                               # 1: down to label313
# %bb.112:                              #   in Loop: Header=BB20_69 Depth=2
	i32.const	0
	local.set	32
	local.get	36
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label313
# %bb.113:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	25
	local.get	7
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label314
# %bb.114:                              #   in Loop: Header=BB20_69 Depth=2
	i32.const	0
	local.set	32
	local.get	35
	i32.const	112
	i32.ne  
	br_if   	1                               # 1: down to label313
# %bb.115:                              #   in Loop: Header=BB20_69 Depth=2
	i32.const	0
	local.set	32
	local.get	36
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label313
# %bb.116:                              #   in Loop: Header=BB20_69 Depth=2
	i32.const	0
	local.set	32
	block   	
	local.get	24
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label313
                                        # 0: down to label315
.LBB20_117:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label315:
	i32.const	0
	local.set	32
	local.get	34
	local.get	18
	i32.gt_u
	br_if   	1                               # 1: down to label313
# %bb.118:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	0
	local.get	34
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	32
	br      	1                               # 1: down to label313
.LBB20_119:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label314:
	local.get	0
	local.get	7
	local.get	15
	i32.const	.L.str.2
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	32
.LBB20_120:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label313:
	local.get	18
	local.get	7
	i32.le_u
	br_if   	0                               # 0: down to label312
# %bb.121:                              #   in Loop: Header=BB20_69 Depth=2
	block   	
	block   	
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	local.tee	30
	i32.const	116
	i32.ne  
	br_if   	0                               # 0: down to label317
# %bb.122:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	7
	i32.const	2
	i32.add 
	local.tee	30
	local.get	18
	i32.gt_u
	br_if   	2                               # 2: down to label312
# %bb.123:                              #   in Loop: Header=BB20_69 Depth=2
	block   	
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{2, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label312
                                        # 0: down to label318
.LBB20_124:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label318:
	local.get	7
	i32.const	3
	i32.add 
	local.tee	30
	local.get	18
	i32.gt_u
	br_if   	2                               # 2: down to label312
# %bb.125:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	local.tee	30
	i32.const	92
	i32.eq  
	br_if   	1                               # 1: down to label316
# %bb.126:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	30
	i32.const	120
	i32.ne  
	br_if   	2                               # 2: down to label312
# %bb.127:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	7
	i32.const	4
	i32.add 
	local.tee	30
	local.get	18
	i32.gt_u
	br_if   	2                               # 2: down to label312
# %bb.128:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	local.tee	30
	i32.const	92
	i32.eq  
	br_if   	1                               # 1: down to label316
# %bb.129:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	30
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label312
# %bb.130:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	34
	local.get	18
	i32.gt_u
	br_if   	2                               # 2: down to label312
# %bb.131:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	0
	local.get	34
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	33
	br      	2                               # 2: down to label312
.LBB20_132:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label317:
	local.get	30
	i32.const	92
	i32.ne  
	br_if   	1                               # 1: down to label312
.LBB20_133:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label316:
	local.get	0
	local.get	7
	local.get	15
	i32.const	.L.str.10
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	33
.LBB20_134:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label312:
	block   	
	local.get	32
	br_if   	0                               # 0: down to label319
# %bb.135:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	33
	i32.eqz
	br_if   	2                               # 2: down to label295
.LBB20_136:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label319:
	block   	
	local.get	15
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label320
.LBB20_137:                             #   Parent Loop BB20_54 Depth=1
                                        #     Parent Loop BB20_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label321:
	local.get	0
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	7
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label320
# %bb.138:                              #   in Loop: Header=BB20_137 Depth=3
	i32.const	1
	local.get	7
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label320
# %bb.139:                              #   in Loop: Header=BB20_137 Depth=3
	local.get	20
	local.get	15
	i32.const	1
	i32.add 
	local.tee	15
	i32.ne  
	br_if   	0                               # 0: up to label321
	br      	3                               # 3: down to label295
.LBB20_140:                             #   in Loop: Header=BB20_69 Depth=2
	end_loop
	end_block                               # label320:
	local.get	15
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label295
# %bb.141:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	0
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	1                               # 1: down to label295
# %bb.142:                              #   in Loop: Header=BB20_69 Depth=2
	block   	
	local.get	15
	i32.const	1
	i32.add 
	local.tee	18
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label322
.LBB20_143:                             #   Parent Loop BB20_54 Depth=1
                                        #     Parent Loop BB20_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label323:
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	7
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label322
# %bb.144:                              #   in Loop: Header=BB20_143 Depth=3
	i32.const	1
	local.get	7
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label322
# %bb.145:                              #   in Loop: Header=BB20_143 Depth=3
	local.get	20
	local.get	18
	i32.const	1
	i32.add 
	local.tee	18
	i32.ne  
	br_if   	0                               # 0: up to label323
# %bb.146:                              #   in Loop: Header=BB20_69 Depth=2
	end_loop
	local.get	20
	local.set	18
.LBB20_147:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label322:
	local.get	9
	i32.const	0
	i32.store	12
	local.get	0
	local.get	20
	local.get	18
	local.get	9
	i32.const	12
	i32.add 
	call	parse_value_span
	i32.eqz
	br_if   	1                               # 1: down to label295
# %bb.148:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	9
	i32.load	12
	local.tee	7
	local.get	20
	i32.gt_u
	br_if   	1                               # 1: down to label295
# %bb.149:                              #   in Loop: Header=BB20_69 Depth=2
	block   	
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label325
# %bb.150:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	7
	local.get	18
	i32.le_u
	br_if   	3                               # 3: down to label295
# %bb.151:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	3                               # 3: down to label295
# %bb.152:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	7
	local.get	18
	i32.const	-1
	i32.xor 
	i32.add 
	local.tee	15
	i32.eqz
	br_if   	3                               # 3: down to label295
# %bb.153:                              #   in Loop: Header=BB20_69 Depth=2
	block   	
	local.get	21
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label326
# %bb.154:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	15
	i32.const	1
	i32.eq  
	br_if   	4                               # 4: down to label295
# %bb.155:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	32
	i32.const	116
	i32.ne  
	br_if   	4                               # 4: down to label295
# %bb.156:                              #   in Loop: Header=BB20_69 Depth=2
	block   	
	local.get	22
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 5, 5, 5, 5, 5, 5, 5, 5, 0, 5} # 5: down to label295
                                        # 0: down to label327
.LBB20_157:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label327:
	local.get	15
	i32.const	2
	i32.eq  
	br_if   	4                               # 4: down to label295
# %bb.158:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	25
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label326
# %bb.159:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	32
	i32.const	120
	i32.ne  
	br_if   	4                               # 4: down to label295
# %bb.160:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	15
	i32.const	3
	i32.eq  
	br_if   	4                               # 4: down to label295
# %bb.161:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	24
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	15
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label326
# %bb.162:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	15
	i32.const	116
	i32.ne  
	br_if   	4                               # 4: down to label295
# %bb.163:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	18
	i32.const	5
	i32.add 
	local.tee	18
	local.get	7
	i32.ge_u
	br_if   	4                               # 4: down to label295
# %bb.164:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	4                               # 4: down to label295
# %bb.165:                              #   in Loop: Header=BB20_69 Depth=2
	i32.const	1
	local.set	26
	br      	2                               # 2: down to label324
.LBB20_166:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label326:
	local.get	0
	local.get	18
	local.get	7
	i32.const	.L.str.10
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	3                               # 3: down to label295
# %bb.167:                              #   in Loop: Header=BB20_69 Depth=2
	i32.const	1
	local.set	26
	br      	1                               # 1: down to label324
.LBB20_168:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label325:
	local.get	7
	local.get	18
	i32.le_u
	br_if   	2                               # 2: down to label295
# %bb.169:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	2                               # 2: down to label295
# %bb.170:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	7
	local.get	18
	i32.sub 
	local.set	14
	i32.const	1
	local.set	29
	local.get	18
	local.set	28
.LBB20_171:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label324:
	block   	
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label328
.LBB20_172:                             #   Parent Loop BB20_54 Depth=1
                                        #     Parent Loop BB20_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label329:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label328
# %bb.173:                              #   in Loop: Header=BB20_172 Depth=3
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label328
# %bb.174:                              #   in Loop: Header=BB20_172 Depth=3
	local.get	20
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label329
	br      	3                               # 3: down to label295
.LBB20_175:                             #   in Loop: Header=BB20_69 Depth=2
	end_loop
	end_block                               # label328:
	block   	
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label330
# %bb.176:                              #   in Loop: Header=BB20_69 Depth=2
	local.get	7
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.eq  
	i32.add 
	local.set	7
.LBB20_177:                             #   in Loop: Header=BB20_69 Depth=2
	end_block                               # label330:
	local.get	27
	i32.const	1
	i32.add 
	local.set	27
	local.get	7
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: up to label298
.LBB20_178:                             #   in Loop: Header=BB20_54 Depth=1
	end_loop
	end_block                               # label295:
	local.get	16
	i32.load8_u	0
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	1                               # 1: down to label293
	br      	4                               # 4: down to label287
.LBB20_179:                             #   in Loop: Header=BB20_54 Depth=1
	end_block                               # label294:
	local.get	7
	i32.const	223
	i32.and 
	i32.const	91
	i32.eq  
	br_if   	3                               # 3: down to label287
.LBB20_180:                             #   in Loop: Header=BB20_54 Depth=1
	end_block                               # label293:
	local.get	0
	local.get	20
	local.get	10
	local.get	9
	i32.const	8
	i32.add 
	call	parse_value_span
	i32.eqz
	br_if   	2                               # 2: down to label287
# %bb.181:                              #   in Loop: Header=BB20_54 Depth=1
	i32.const	0
	local.set	28
	i32.const	0
	local.set	14
	i32.const	0
	local.set	18
	local.get	9
	i32.load	8
	local.tee	7
	local.get	20
	i32.gt_u
	br_if   	2                               # 2: down to label287
.LBB20_182:                             #   in Loop: Header=BB20_54 Depth=1
	end_block                               # label292:
	block   	
	local.get	17
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label331
# %bb.183:                              #   in Loop: Header=BB20_54 Depth=1
	local.get	4
	i32.load	0
	local.tee	15
	local.get	3
	i32.ge_u
	br_if   	2                               # 2: down to label287
# %bb.184:                              #   in Loop: Header=BB20_54 Depth=1
	local.get	2
	local.get	15
	i32.add 
	i32.const	44
	i32.store8	0
	local.get	4
	local.get	4
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
.LBB20_185:                             #   in Loop: Header=BB20_54 Depth=1
	end_block                               # label331:
	block   	
	block   	
	local.get	18
	i32.eqz
	br_if   	0                               # 0: down to label333
# %bb.186:                              #   in Loop: Header=BB20_54 Depth=1
	local.get	4
	i32.load	0
	local.tee	10
	local.get	14
	i32.add 
	local.tee	18
	local.get	10
	i32.lt_u
	br_if   	3                               # 3: down to label287
# %bb.187:                              #   in Loop: Header=BB20_54 Depth=1
	local.get	18
	local.get	3
	i32.gt_u
	br_if   	3                               # 3: down to label287
# %bb.188:                              #   in Loop: Header=BB20_54 Depth=1
	local.get	14
	i32.eqz
	br_if   	1                               # 1: down to label332
# %bb.189:                              #   in Loop: Header=BB20_54 Depth=1
	local.get	2
	local.get	10
	i32.add 
	local.get	0
	local.get	28
	i32.add 
	local.get	14
	memory.copy	0, 0
	br      	1                               # 1: down to label332
.LBB20_190:                             #   in Loop: Header=BB20_54 Depth=1
	end_block                               # label333:
	local.get	4
	i32.load	0
	local.tee	15
	local.get	7
	local.get	10
	i32.sub 
	local.tee	10
	i32.add 
	local.tee	18
	local.get	15
	i32.lt_u
	br_if   	2                               # 2: down to label287
# %bb.191:                              #   in Loop: Header=BB20_54 Depth=1
	local.get	18
	local.get	3
	i32.gt_u
	br_if   	2                               # 2: down to label287
# %bb.192:                              #   in Loop: Header=BB20_54 Depth=1
	local.get	10
	i32.eqz
	br_if   	0                               # 0: down to label332
# %bb.193:                              #   in Loop: Header=BB20_54 Depth=1
	local.get	2
	local.get	15
	i32.add 
	local.get	16
	local.get	10
	memory.copy	0, 0
.LBB20_194:                             #   in Loop: Header=BB20_54 Depth=1
	end_block                               # label332:
	local.get	4
	local.get	18
	i32.store	0
	block   	
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label334
.LBB20_195:                             #   Parent Loop BB20_54 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label335:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label334
# %bb.196:                              #   in Loop: Header=BB20_195 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label334
# %bb.197:                              #   in Loop: Header=BB20_195 Depth=2
	local.get	20
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label335
	br      	3                               # 3: down to label287
.LBB20_198:                             #   in Loop: Header=BB20_54 Depth=1
	end_loop
	end_block                               # label334:
	block   	
	block   	
	local.get	7
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: down to label337
# %bb.199:                              #   in Loop: Header=BB20_54 Depth=1
	local.get	7
	local.set	10
	br      	1                               # 1: down to label336
.LBB20_200:                             #   in Loop: Header=BB20_54 Depth=1
	end_block                               # label337:
	local.get	7
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.eq  
	i32.add 
	local.set	10
.LBB20_201:                             #   in Loop: Header=BB20_54 Depth=1
	end_block                               # label336:
	i32.const	1
	local.set	17
	local.get	10
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: up to label288
# %bb.202:
	end_loop
	i32.const	1
	local.set	19
.LBB20_203:
	end_block                               # label287:
	local.get	4
	local.get	12
	i32.store	0
.LBB20_204:
	end_block                               # label286:
	block   	
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label338
# %bb.205:
	block   	
	local.get	19
	br_if   	0                               # 0: down to label339
# %bb.206:
	local.get	8
	local.get	8
	i32.load	12
	i32.const	1
	i32.add 
	i32.store	12
	br      	4                               # 4: down to label281
.LBB20_207:
	end_block                               # label339:
	local.get	8
	local.get	8
	i32.load	16
	i32.const	1
	i32.add 
	i32.store	16
	br      	1                               # 1: down to label285
.LBB20_208:
	end_block                               # label338:
	local.get	19
	i32.eqz
	br_if   	2                               # 2: down to label281
.LBB20_209:
	end_block                               # label285:
	local.get	0
	local.get	1
	i32.load	40
	local.get	1
	i32.load	36
	local.tee	1
	i32.add 
	local.tee	12
	local.get	1
	local.get	12
	local.get	2
	local.get	3
	local.get	4
	call	write_normalized_glossary_value
	br_if   	1                               # 1: down to label281
# %bb.210:
	i32.const	0
	local.set	10
	br      	2                               # 2: down to label268
.LBB20_211:
	end_block                               # label282:
	local.get	12
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label268
# %bb.212:
	local.get	19
	i32.const	3
	i32.add 
	local.tee	1
	local.get	3
	i32.gt_u
	br_if   	1                               # 1: down to label268
# %bb.213:
	local.get	2
	local.get	12
	i32.add 
	i32.const	23899
	i32.store16	0:p2align=0
	local.get	4
	local.get	1
	i32.store	0
.LBB20_214:
	end_block                               # label281:
	local.get	4
	i32.load	0
	local.set	1
	local.get	9
	i32.const	0
	i32.store	12
	local.get	9
	i32.const	0
	i32.store	8
	local.get	13
	local.get	1
	local.get	11
	i32.sub 
	local.get	9
	i32.const	12
	i32.add 
	local.get	9
	i32.const	8
	i32.add 
	call	hash_content_xxh32_pair
	i32.const	1
	local.set	10
	local.get	5
	local.get	9
	i32.load	12
	local.tee	1
	i32.const	1
	local.get	1
	local.get	9
	i32.load	8
	local.tee	4
	i32.or  
	i32.select
	i32.store	0
	local.get	6
	local.get	4
	i32.store	0
.LBB20_215:
	end_block                               # label268:
	local.get	9
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	10
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.build_term_string_plan,"",@
	.globl	build_term_string_plan          # -- Begin function build_term_string_plan
	.type	build_term_string_plan,@function
build_term_string_plan:                 # @build_term_string_plan
	.functype	build_term_string_plan (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	32
	i32.sub 
	local.tee	14
	global.set	__stack_pointer
	i32.const	-1
	local.set	15
	block   	
	local.get	0
	i32x4.splat
	local.get	1
	i32x4.replace_lane	1
	local.get	4
	i32x4.replace_lane	2
	local.get	6
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	16
	i32x4.eq
	v128.const	65535, 65535, 65535, 65535
	local.tee	17
	v128.and
	local.get	7
	i32x4.splat
	local.get	8
	i32x4.replace_lane	1
	local.get	9
	i32x4.replace_lane	2
	local.get	10
	i32x4.replace_lane	3
	local.get	16
	i32x4.eq
	local.get	17
	v128.and
	i16x8.narrow_i32x4_u
	v128.any_true
	br_if   	0                               # 0: down to label340
# %bb.1:
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label340
# %bb.2:
	local.get	13
	i32.eqz
	br_if   	0                               # 0: down to label340
# %bb.3:
	local.get	12
	i32.eqz
	br_if   	0                               # 0: down to label340
# %bb.4:
	i32.const	-1
	local.set	15
	local.get	12
	local.get	12
	i32.const	-1
	i32.add 
	local.tee	18
	i32.and 
	br_if   	0                               # 0: down to label340
# %bb.5:
	block   	
	block   	
	local.get	3
	br_if   	0                               # 0: down to label342
# %bb.6:
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
	br      	1                               # 1: down to label341
.LBB21_7:
	end_block                               # label342:
	local.get	3
	i32.const	1
	i32.shl 
	local.set	21
	local.get	1
	local.get	2
	i32.const	68
	i32.mul 
	i32.add 
	local.set	22
	i32.const	0
	local.set	20
	i32.const	0
	local.set	19
	i32.const	0
	local.set	23
.LBB21_8:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB21_14 Depth 2
                                        #     Child Loop BB21_19 Depth 2
                                        #     Child Loop BB21_22 Depth 2
                                        #       Child Loop BB21_28 Depth 3
                                        #       Child Loop BB21_35 Depth 3
                                        #         Child Loop BB21_41 Depth 4
                                        #         Child Loop BB21_43 Depth 4
                                        #         Child Loop BB21_46 Depth 4
	loop    	                                # label343:
	local.get	14
	local.get	22
	local.get	23
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	15
	i32.load	0
	local.tee	1
	i32.store	28
	local.get	14
	local.get	15
	i32.load	8
	local.tee	2
	i32.store	24
	local.get	14
	local.get	15
	i32.load	4
	local.tee	24
	i32.store	20
	local.get	14
	local.get	15
	i32.load	12
	local.tee	15
	i32.store	16
	local.get	14
	i32.const	0
	i32.store	8
	local.get	14
	i32.const	0
	i32.store	4
	i32.const	0
	local.set	25
	block   	
	local.get	15
	i32.const	2
	i32.ne  
	br_if   	0                               # 0: down to label344
# %bb.9:                                #   in Loop: Header=BB21_8 Depth=1
	i32.const	0
	local.set	25
	local.get	0
	local.get	2
	i32.add 
	local.tee	26
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label344
# %bb.10:                               #   in Loop: Header=BB21_8 Depth=1
	local.get	26
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	25
.LBB21_11:                              #   in Loop: Header=BB21_8 Depth=1
	end_block                               # label344:
	block   	
	local.get	25
	br_if   	0                               # 0: down to label345
# %bb.12:                               #   in Loop: Header=BB21_8 Depth=1
	local.get	24
	local.get	15
	i32.ne  
	br_if   	0                               # 0: down to label345
# %bb.13:                               #   in Loop: Header=BB21_8 Depth=1
	local.get	24
	i32.const	-1
	i32.add 
	local.set	26
	i32.const	0
	local.set	15
	local.get	0
	local.get	1
	i32.add 
	local.tee	27
	local.set	1
	local.get	0
	local.get	2
	i32.add 
	local.tee	28
	local.set	2
.LBB21_14:                              #   Parent Loop BB21_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label347:
	block   	
	local.get	15
	i32.const	8
	i32.add 
	local.tee	29
	local.get	24
	i32.le_u
	br_if   	0                               # 0: down to label348
# %bb.15:                               #   in Loop: Header=BB21_8 Depth=1
	local.get	15
	local.get	24
	i32.lt_u
	br_if   	2                               # 2: down to label346
# %bb.16:                               #   in Loop: Header=BB21_8 Depth=1
	i32.const	1
	local.set	25
	br      	3                               # 3: down to label345
.LBB21_17:                              #   in Loop: Header=BB21_14 Depth=2
	end_block                               # label348:
	local.get	28
	local.get	15
	i32.add 
	local.set	30
	local.get	27
	local.get	15
	i32.add 
	local.set	31
	local.get	1
	i32.const	8
	i32.add 
	local.set	1
	local.get	2
	i32.const	8
	i32.add 
	local.set	2
	local.get	26
	i32.const	-8
	i32.add 
	local.set	26
	local.get	29
	local.set	15
	local.get	31
	i64.load	0:p2align=0
	local.get	30
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label347
# %bb.18:                               #   in Loop: Header=BB21_8 Depth=1
	end_loop
	i32.const	0
	local.set	25
	br      	1                               # 1: down to label345
.LBB21_19:                              #   Parent Loop BB21_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	end_block                               # label346:
	loop    	                                # label349:
	local.get	1
	i32.load8_u	0
	local.tee	15
	local.get	2
	i32.load8_u	0
	local.tee	29
	i32.eq  
	local.set	25
	local.get	15
	local.get	29
	i32.ne  
	br_if   	1                               # 1: down to label345
# %bb.20:                               #   in Loop: Header=BB21_19 Depth=2
	local.get	26
	i32.const	0
	i32.ne  
	local.set	15
	local.get	1
	i32.const	1
	i32.add 
	local.set	1
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	local.get	26
	i32.const	-1
	i32.add 
	local.set	26
	local.get	15
	br_if   	0                               # 0: up to label349
.LBB21_21:                              #   in Loop: Header=BB21_8 Depth=1
	end_loop
	end_block                               # label345:
	local.get	14
	i32.const	28
	i32.add 
	local.set	1
	local.get	14
	i32.const	20
	i32.add 
	local.set	26
	local.get	14
	i32.const	8
	i32.add 
	local.set	32
	i32.const	1
	local.set	33
	i32.const	0
	local.set	15
.LBB21_22:                              #   Parent Loop BB21_8 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB21_28 Depth 3
                                        #       Child Loop BB21_35 Depth 3
                                        #         Child Loop BB21_41 Depth 4
                                        #         Child Loop BB21_43 Depth 4
                                        #         Child Loop BB21_46 Depth 4
	block   	
	loop    	                                # label351:
	block   	
	local.get	25
	local.get	15
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label352
# %bb.23:                               #   in Loop: Header=BB21_8 Depth=1
	local.get	14
	local.get	14
	i32.load	8
	i32.store	4
	br      	2                               # 2: down to label350
.LBB21_24:                              #   in Loop: Header=BB21_22 Depth=2
	end_block                               # label352:
	local.get	1
	i32.load	0
	local.set	2
	block   	
	block   	
	block   	
	local.get	26
	i32.load	0
	local.tee	26
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label355
# %bb.25:                               #   in Loop: Header=BB21_22 Depth=2
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label355
# %bb.26:                               #   in Loop: Header=BB21_22 Depth=2
	local.get	0
	local.get	2
	local.get	26
	i32.add 
	i32.const	-1
	i32.add 
	local.tee	29
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label355
# %bb.27:                               #   in Loop: Header=BB21_22 Depth=2
	local.get	26
	i32.const	-2
	i32.add 
	local.set	30
	local.get	2
	i32.const	1
	i32.add 
	local.set	31
	local.get	2
	i32.const	1
	i32.add 
	local.set	15
.LBB21_28:                              #   Parent Loop BB21_8 Depth=1
                                        #     Parent Loop BB21_22 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label356:
	local.get	15
	local.get	29
	i32.ge_u
	br_if   	2                               # 2: down to label354
# %bb.29:                               #   in Loop: Header=BB21_28 Depth=3
	local.get	0
	local.get	15
	i32.add 
	local.set	1
	local.get	15
	i32.const	1
	i32.add 
	local.set	15
	local.get	1
	i32.load8_u	0
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: up to label356
.LBB21_30:                              #   in Loop: Header=BB21_22 Depth=2
	end_loop
	end_block                               # label355:
	local.get	19
	local.set	31
	local.get	4
	local.set	34
	local.get	0
	local.get	2
	i32.add 
	local.get	26
	local.get	4
	local.get	19
	i32.add 
	local.get	5
	local.get	19
	i32.sub 
	call	decode_escaped_key
	local.tee	30
	i32.const	65536
	i32.lt_u
	br_if   	1                               # 1: down to label353
# %bb.31:
	i32.const	-4
	local.set	15
	br      	6                               # 6: down to label340
.LBB21_32:                              #   in Loop: Header=BB21_22 Depth=2
	end_block                               # label354:
	local.get	0
	local.set	34
	local.get	30
	i32.const	65535
	i32.le_u
	br_if   	0                               # 0: down to label353
# %bb.33:
	i32.const	-5
	local.set	15
	br      	5                               # 5: down to label340
.LBB21_34:                              #   in Loop: Header=BB21_22 Depth=2
	end_block                               # label353:
	local.get	34
	local.get	31
	i32.add 
	local.tee	35
	local.get	30
	i32.const	-2128831035
	call	hash_content_xxh32
	local.tee	36
	local.get	30
	i32.const	-2048144789
	i32.mul 
	i32.xor 
	local.tee	15
	i32.const	16
	i32.shr_u
	local.get	15
	i32.xor 
	local.get	18
	i32.and 
	local.set	27
	i32.const	0
	local.set	37
.LBB21_35:                              #   Parent Loop BB21_8 Depth=1
                                        #     Parent Loop BB21_22 Depth=2
                                        # =>    This Loop Header: Depth=3
                                        #         Child Loop BB21_41 Depth 4
                                        #         Child Loop BB21_43 Depth 4
                                        #         Child Loop BB21_46 Depth 4
	block   	
	block   	
	loop    	                                # label359:
	local.get	11
	local.get	27
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	15
	i32.eqz
	br_if   	1                               # 1: down to label358
# %bb.36:                               #   in Loop: Header=BB21_35 Depth=3
	block   	
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	28
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: down to label360
# %bb.37:
	i32.const	-3
	local.set	15
	br      	8                               # 8: down to label340
.LBB21_38:                              #   in Loop: Header=BB21_35 Depth=3
	end_block                               # label360:
	block   	
	local.get	8
	local.get	28
	i32.const	2
	i32.shl 
	local.tee	15
	i32.add 
	i32.load	0
	local.get	36
	i32.ne  
	br_if   	0                               # 0: down to label361
# %bb.39:                               #   in Loop: Header=BB21_35 Depth=3
	local.get	30
	local.get	6
	local.get	28
	i32.const	1
	i32.shl 
	i32.add 
	i32.load16_u	0
	i32.ne  
	br_if   	0                               # 0: down to label361
# %bb.40:                               #   in Loop: Header=BB21_35 Depth=3
	i32.const	0
	local.set	2
	local.get	4
	local.get	7
	local.get	15
	i32.add 
	i32.load	0
	i32.add 
	local.tee	38
	local.set	15
	local.get	35
	local.set	1
.LBB21_41:                              #   Parent Loop BB21_8 Depth=1
                                        #     Parent Loop BB21_22 Depth=2
                                        #       Parent Loop BB21_35 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	loop    	                                # label362:
	block   	
	local.get	30
	local.get	2
	i32.add 
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label363
# %bb.42:                               #   in Loop: Header=BB21_35 Depth=3
	i32.const	0
	local.set	26
	local.get	30
	local.set	29
.LBB21_43:                              #   Parent Loop BB21_8 Depth=1
                                        #     Parent Loop BB21_22 Depth=2
                                        #       Parent Loop BB21_35 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	block   	
	loop    	                                # label365:
	block   	
	local.get	2
	local.get	29
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label366
# %bb.44:                               #   in Loop: Header=BB21_35 Depth=3
	local.get	26
	local.get	2
	i32.sub 
	local.tee	15
	local.get	30
	i32.lt_u
	br_if   	2                               # 2: down to label364
	br      	8                               # 8: down to label357
.LBB21_45:                              #   in Loop: Header=BB21_43 Depth=4
	end_block                               # label366:
	local.get	1
	local.get	26
	i32.add 
	local.set	31
	local.get	15
	local.get	26
	i32.add 
	local.set	24
	local.get	29
	i32.const	-8
	i32.add 
	local.set	29
	local.get	26
	i32.const	8
	i32.add 
	local.set	26
	local.get	24
	i64.load	0:p2align=0
	local.get	31
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label365
	br      	4                               # 4: down to label361
.LBB21_46:                              #   Parent Loop BB21_8 Depth=1
                                        #     Parent Loop BB21_22 Depth=2
                                        #       Parent Loop BB21_35 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	end_loop
	end_block                               # label364:
	loop    	                                # label367:
	local.get	38
	local.get	15
	i32.add 
	i32.load8_u	0
	local.get	35
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	3                               # 3: down to label361
# %bb.47:                               #   in Loop: Header=BB21_46 Depth=4
	local.get	15
	i32.const	1
	i32.add 
	local.tee	15
	local.get	30
	i32.ge_u
	br_if   	6                               # 6: down to label357
	br      	0                               # 0: up to label367
.LBB21_48:                              #   in Loop: Header=BB21_41 Depth=4
	end_loop
	end_block                               # label363:
	local.get	15
	i32.const	16
	i32.add 
	local.set	26
	local.get	1
	i32.const	16
	i32.add 
	local.set	29
	local.get	15
	v128.load	0:p2align=0
	local.set	16
	local.get	1
	v128.load	0:p2align=0
	local.set	17
	local.get	15
	i32.const	32
	i32.add 
	local.set	15
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	2
	i32.const	-32
	i32.add 
	local.set	2
	local.get	29
	v128.load	0:p2align=0
	local.get	26
	v128.load	0:p2align=0
	v128.xor
	local.get	17
	local.get	16
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label362
.LBB21_49:                              #   in Loop: Header=BB21_35 Depth=3
	end_loop
	end_block                               # label361:
	local.get	27
	i32.const	1
	i32.add 
	local.get	18
	i32.and 
	local.set	27
	local.get	37
	i32.const	1
	i32.add 
	local.tee	37
	local.get	12
	i32.ne  
	br_if   	0                               # 0: up to label359
.LBB21_50:                              #   in Loop: Header=BB21_22 Depth=2
	end_loop
	end_block                               # label358:
	i32.const	-2
	local.set	15
	local.get	20
	local.get	21
	i32.ge_u
	br_if   	5                               # 5: down to label340
# %bb.51:                               #   in Loop: Header=BB21_22 Depth=2
	local.get	11
	local.get	27
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	1
	i32.load	0
	br_if   	5                               # 5: down to label340
# %bb.52:                               #   in Loop: Header=BB21_22 Depth=2
	local.get	30
	local.get	19
	i32.add 
	local.tee	2
	local.get	5
	i32.gt_u
	br_if   	5                               # 5: down to label340
# %bb.53:                               #   in Loop: Header=BB21_22 Depth=2
	block   	
	local.get	34
	local.get	4
	i32.eq  
	br_if   	0                               # 0: down to label368
# %bb.54:                               #   in Loop: Header=BB21_22 Depth=2
	local.get	4
	local.get	19
	i32.add 
	local.get	35
	local.get	30
	call	copy_valid_utf8
	br_if   	0                               # 0: down to label368
# %bb.55:
	i32.const	-4
	local.set	15
	br      	6                               # 6: down to label340
.LBB21_56:                              #   in Loop: Header=BB21_22 Depth=2
	end_block                               # label368:
	local.get	7
	local.get	20
	i32.const	2
	i32.shl 
	local.tee	15
	i32.add 
	local.get	19
	i32.store	0
	local.get	8
	local.get	15
	i32.add 
	local.get	36
	i32.store	0
	local.get	6
	local.get	20
	i32.const	1
	i32.shl 
	i32.add 
	local.get	30
	i32.store16	0
	local.get	1
	local.get	20
	i32.const	1
	i32.add 
	local.tee	15
	i32.store	0
	local.get	20
	local.set	28
	local.get	2
	local.set	19
	local.get	15
	local.set	20
.LBB21_57:                              #   in Loop: Header=BB21_22 Depth=2
	end_block                               # label357:
	local.get	32
	local.get	28
	i32.store	0
	i32.const	1
	local.set	15
	local.get	33
	i32.const	1
	i32.and 
	local.set	2
	local.get	14
	i32.const	24
	i32.add 
	local.set	1
	local.get	14
	i32.const	16
	i32.add 
	local.set	26
	local.get	14
	i32.const	4
	i32.add 
	local.set	32
	i32.const	0
	local.set	33
	local.get	2
	br_if   	0                               # 0: up to label351
.LBB21_58:                              #   in Loop: Header=BB21_8 Depth=1
	end_loop
	end_block                               # label350:
	local.get	9
	local.get	23
	i32.const	2
	i32.shl 
	local.tee	15
	i32.add 
	local.get	14
	i32.load	8
	i32.store	0
	local.get	10
	local.get	15
	i32.add 
	local.get	14
	i32.load	4
	i32.store	0
	local.get	23
	i32.const	1
	i32.add 
	local.tee	23
	local.get	3
	i32.ne  
	br_if   	0                               # 0: up to label343
.LBB21_59:
	end_loop
	end_block                               # label341:
	local.get	13
	local.get	20
	i32.store	0
	local.get	19
	local.set	15
.LBB21_60:
	end_block                               # label340:
	local.get	14
	i32.const	32
	i32.add 
	global.set	__stack_pointer
	local.get	15
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.content_bytes_equal,"",@
	.type	content_bytes_equal,@function   # -- Begin function content_bytes_equal
content_bytes_equal:                    # @content_bytes_equal
	.functype	content_bytes_equal (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32
# %bb.0:
	local.get	0
	local.get	2
	i32.add 
	local.set	4
	local.get	0
	local.get	1
	i32.add 
	local.set	5
	i32.const	0
	local.set	0
.LBB22_1:                               # =>This Inner Loop Header: Depth=1
	block   	
	block   	
	block   	
	loop    	                                # label372:
	block   	
	local.get	0
	i32.const	8
	i32.add 
	local.tee	2
	local.get	3
	i32.le_u
	br_if   	0                               # 0: down to label373
# %bb.2:
	block   	
	local.get	3
	local.get	0
	i32.gt_u
	br_if   	0                               # 0: down to label374
# %bb.3:
	i32.const	1
	return
.LBB22_4:
	end_block                               # label374:
	local.get	3
	local.get	0
	i32.sub 
	local.set	1
	local.get	5
	local.get	0
	i32.add 
	local.set	2
	local.get	4
	local.get	0
	i32.add 
	local.set	0
	br      	2                               # 2: down to label371
.LBB22_5:                               #   in Loop: Header=BB22_1 Depth=1
	end_block                               # label373:
	local.get	4
	local.get	0
	i32.add 
	local.set	1
	local.get	5
	local.get	0
	i32.add 
	local.set	6
	local.get	2
	local.set	0
	local.get	6
	i64.load	0:p2align=0
	local.get	1
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label372
	br      	2                               # 2: down to label370
.LBB22_6:                               # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label371:
	loop    	                                # label375:
	local.get	2
	i32.load8_u	0
	local.get	0
	i32.load8_u	0
	i32.ne  
	br_if   	1                               # 1: down to label370
# %bb.7:                                #   in Loop: Header=BB22_6 Depth=1
	i32.const	1
	local.set	6
	local.get	0
	i32.const	1
	i32.add 
	local.set	0
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	local.get	1
	i32.const	-1
	i32.add 
	local.tee	1
	i32.eqz
	br_if   	2                               # 2: down to label369
	br      	0                               # 0: up to label375
.LBB22_8:
	end_loop
	end_block                               # label370:
	i32.const	0
	local.set	6
.LBB22_9:
	end_block                               # label369:
	local.get	6
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.decode_escaped_key,"",@
	.type	decode_escaped_key,@function    # -- Begin function decode_escaped_key
decode_escaped_key:                     # @decode_escaped_key
	.functype	decode_escaped_key (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-1
	local.set	4
	block   	
	local.get	1
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label376
# %bb.1:
	local.get	0
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label376
# %bb.2:
	i32.const	-1
	local.set	4
	local.get	0
	local.get	1
	i32.const	-1
	i32.add 
	local.tee	5
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label376
# %bb.3:
	i32.const	0
	local.set	4
	local.get	5
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label376
# %bb.4:
	local.get	3
	i32.const	65535
	local.get	3
	i32.const	65535
	i32.lt_u
	i32.select
	local.set	6
	local.get	0
	i32.const	3
	i32.add 
	local.set	7
	local.get	0
	i32.const	2
	i32.add 
	local.set	8
	local.get	2
	i32.const	1
	i32.add 
	local.set	9
	i32.const	0
	local.set	4
	i32.const	1
	local.set	1
.LBB23_5:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB23_86 Depth 2
	loop    	                                # label377:
	local.get	4
	local.set	10
	local.get	1
	i32.const	1
	i32.add 
	local.set	11
	block   	
	block   	
	local.get	0
	local.get	1
	i32.add 
	local.tee	12
	i32.load8_u	0
	local.tee	3
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label379
# %bb.6:                                #   in Loop: Header=BB23_5 Depth=1
	i32.const	-1
	local.set	4
	local.get	3
	i32.const	32
	i32.lt_u
	br_if   	3                               # 3: down to label376
# %bb.7:                                #   in Loop: Header=BB23_5 Depth=1
	local.get	3
	i32.const	34
	i32.eq  
	br_if   	3                               # 3: down to label376
# %bb.8:                                #   in Loop: Header=BB23_5 Depth=1
	block   	
	block   	
	block   	
	local.get	3
	i32.extend8_s
	i32.const	-1
	i32.gt_s
	br_if   	0                               # 0: down to label382
# %bb.9:                                #   in Loop: Header=BB23_5 Depth=1
	i32.const	0
	local.set	13
	block   	
	block   	
	local.get	3
	i32.const	62
	i32.add 
	i32.const	255
	i32.and 
	i32.const	30
	i32.lt_u
	local.tee	14
	i32.eqz
	br_if   	0                               # 0: down to label384
# %bb.10:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	2
	local.set	15
	br      	1                               # 1: down to label383
.LBB23_11:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label384:
	block   	
	local.get	3
	i32.const	240
	i32.and 
	i32.const	224
	i32.ne  
	br_if   	0                               # 0: down to label385
# %bb.12:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	3
	local.set	15
	i32.const	1
	local.set	13
	br      	1                               # 1: down to label383
.LBB23_13:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label385:
	i32.const	4
	local.set	15
	local.get	3
	i32.const	16
	i32.add 
	i32.const	255
	i32.and 
	i32.const	4
	i32.gt_u
	br_if   	7                               # 7: down to label376
.LBB23_14:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label383:
	i32.const	-1
	local.set	4
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	12
	local.get	5
	local.get	11
	i32.sub 
	i32.gt_u
	br_if   	6                               # 6: down to label376
# %bb.15:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	0
	local.get	11
	i32.add 
	local.tee	11
	i32.load8_u	0
	local.set	16
	block   	
	local.get	3
	i32.const	224
	i32.ne  
	br_if   	0                               # 0: down to label386
# %bb.16:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	16
	i32.const	255
	i32.and 
	i32.const	160
	i32.lt_u
	br_if   	7                               # 7: down to label376
.LBB23_17:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label386:
	block   	
	local.get	3
	i32.const	237
	i32.ne  
	br_if   	0                               # 0: down to label387
# %bb.18:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	16
	i32.const	255
	i32.and 
	i32.const	159
	i32.gt_u
	br_if   	7                               # 7: down to label376
.LBB23_19:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label387:
	block   	
	local.get	3
	i32.const	240
	i32.ne  
	br_if   	0                               # 0: down to label388
# %bb.20:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	16
	i32.const	255
	i32.and 
	i32.const	144
	i32.lt_u
	br_if   	7                               # 7: down to label376
.LBB23_21:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label388:
	block   	
	local.get	3
	i32.const	244
	i32.ne  
	br_if   	0                               # 0: down to label389
# %bb.22:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	16
	i32.const	255
	i32.and 
	i32.const	143
	i32.gt_u
	br_if   	7                               # 7: down to label376
.LBB23_23:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label389:
	local.get	11
	i32.load8_s	0
	i32.const	-64
	i32.ge_s
	br_if   	6                               # 6: down to label376
# %bb.24:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	12
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label381
# %bb.25:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	11
	i32.const	1
	i32.add 
	i32.load8_s	0
	i32.const	-65
	i32.gt_s
	br_if   	6                               # 6: down to label376
# %bb.26:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	12
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label381
# %bb.27:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	11
	i32.const	2
	i32.add 
	i32.load8_s	0
	i32.const	-65
	i32.gt_s
	br_if   	6                               # 6: down to label376
# %bb.28:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	15
	local.get	6
	local.get	10
	i32.sub 
	i32.le_u
	br_if   	2                               # 2: down to label380
	br      	6                               # 6: down to label376
.LBB23_29:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label382:
	local.get	6
	local.get	10
	i32.eq  
	br_if   	5                               # 5: down to label376
# %bb.30:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	2
	local.get	10
	i32.add 
	local.get	3
	i32.store8	0
	local.get	10
	i32.const	1
	i32.add 
	local.set	4
	local.get	11
	local.set	1
	br      	3                               # 3: down to label378
.LBB23_31:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label381:
	local.get	15
	local.get	6
	local.get	10
	i32.sub 
	i32.gt_u
	br_if   	4                               # 4: down to label376
.LBB23_32:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label380:
	local.get	2
	local.get	10
	i32.add 
	local.get	3
	i32.store8	0
	local.get	9
	local.get	10
	i32.add 
	local.get	11
	i32.load8_u	0
	i32.store8	0
	local.get	10
	i32.const	2
	i32.add 
	local.set	4
	local.get	15
	local.get	1
	i32.add 
	local.set	3
	block   	
	local.get	14
	i32.eqz
	br_if   	0                               # 0: down to label390
# %bb.33:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	3
	local.set	1
	br      	2                               # 2: down to label378
.LBB23_34:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label390:
	local.get	2
	local.get	4
	i32.add 
	local.get	8
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.store8	0
	local.get	10
	i32.const	3
	i32.add 
	local.set	4
	block   	
	local.get	13
	i32.eqz
	br_if   	0                               # 0: down to label391
# %bb.35:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	3
	local.set	1
	br      	2                               # 2: down to label378
.LBB23_36:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label391:
	local.get	2
	local.get	4
	i32.add 
	local.get	7
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.store8	0
	local.get	10
	i32.const	4
	i32.add 
	local.set	4
	local.get	3
	local.set	1
	br      	1                               # 1: down to label378
.LBB23_37:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label379:
	i32.const	-1
	local.set	4
	local.get	5
	local.get	11
	i32.le_u
	br_if   	2                               # 2: down to label376
# %bb.38:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	1
	i32.const	2
	i32.add 
	local.set	16
	i32.const	1
	local.set	15
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	-34
	i32.add 
	br_table 	{6, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 6, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 6, 9, 9, 9, 9, 9, 0, 9, 9, 9, 1, 9, 9, 9, 9, 9, 9, 9, 2, 9, 9, 9, 3, 9, 4, 5, 9} # 9: down to label376
                                        # 6: down to label392
                                        # 0: down to label398
                                        # 1: down to label397
                                        # 2: down to label396
                                        # 3: down to label395
                                        # 4: down to label394
                                        # 5: down to label393
.LBB23_39:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label398:
	i32.const	8
	local.set	11
	br      	5                               # 5: down to label392
.LBB23_40:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label397:
	i32.const	12
	local.set	11
	br      	4                               # 4: down to label392
.LBB23_41:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label396:
	i32.const	10
	local.set	11
	br      	3                               # 3: down to label392
.LBB23_42:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label395:
	i32.const	13
	local.set	11
	br      	2                               # 2: down to label392
.LBB23_43:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label394:
	i32.const	9
	local.set	11
	br      	1                               # 1: down to label392
.LBB23_44:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label393:
	local.get	5
	local.get	16
	i32.sub 
	i32.const	4
	i32.lt_u
	br_if   	3                               # 3: down to label376
# %bb.45:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	-48
	local.set	17
	i32.const	-48
	local.set	13
	block   	
	local.get	0
	local.get	16
	i32.add 
	local.tee	3
	i32.load8_u	0
	local.tee	11
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label399
# %bb.46:                               #   in Loop: Header=BB23_5 Depth=1
	block   	
	local.get	11
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label400
# %bb.47:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	-87
	local.set	13
	br      	1                               # 1: down to label399
.LBB23_48:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label400:
	local.get	11
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.gt_u
	br_if   	4                               # 4: down to label376
# %bb.49:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	-55
	local.set	13
.LBB23_50:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label399:
	block   	
	local.get	3
	i32.load8_u	1
	local.tee	16
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label401
# %bb.51:                               #   in Loop: Header=BB23_5 Depth=1
	block   	
	local.get	16
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label402
# %bb.52:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	-87
	local.set	17
	br      	1                               # 1: down to label401
.LBB23_53:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label402:
	local.get	16
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.gt_u
	br_if   	4                               # 4: down to label376
# %bb.54:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	-55
	local.set	17
.LBB23_55:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label401:
	i32.const	-48
	local.set	18
	i32.const	-48
	local.set	19
	block   	
	local.get	3
	i32.load8_u	2
	local.tee	14
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label403
# %bb.56:                               #   in Loop: Header=BB23_5 Depth=1
	block   	
	local.get	14
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label404
# %bb.57:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	-87
	local.set	19
	br      	1                               # 1: down to label403
.LBB23_58:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label404:
	local.get	14
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.gt_u
	br_if   	4                               # 4: down to label376
# %bb.59:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	-55
	local.set	19
.LBB23_60:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label403:
	block   	
	local.get	3
	i32.load8_u	3
	local.tee	3
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label405
# %bb.61:                               #   in Loop: Header=BB23_5 Depth=1
	block   	
	local.get	3
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label406
# %bb.62:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	-87
	local.set	18
	br      	1                               # 1: down to label405
.LBB23_63:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label406:
	local.get	3
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.gt_u
	br_if   	4                               # 4: down to label376
# %bb.64:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	-55
	local.set	18
.LBB23_65:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label405:
	i32.const	-1
	local.set	4
	local.get	18
	local.get	3
	i32.add 
	local.get	17
	local.get	16
	i32.add 
	i32.const	4
	i32.shl 
	local.get	13
	local.get	11
	i32.add 
	i32.const	8
	i32.shl 
	i32.or  
	local.get	19
	local.get	14
	i32.add 
	i32.or  
	i32.const	4
	i32.shl 
	i32.or  
	local.tee	3
	i32.const	-1
	i32.eq  
	br_if   	3                               # 3: down to label376
# %bb.66:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	1
	i32.const	6
	i32.add 
	local.set	16
	i32.const	65533
	local.set	11
	block   	
	local.get	3
	i32.const	-1024
	i32.and 
	local.tee	4
	i32.const	56320
	i32.ne  
	br_if   	0                               # 0: down to label407
# %bb.67:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	3
	local.set	15
	br      	1                               # 1: down to label392
.LBB23_68:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label407:
	block   	
	local.get	4
	i32.const	55296
	i32.ne  
	br_if   	0                               # 0: down to label408
# %bb.69:                               #   in Loop: Header=BB23_5 Depth=1
	block   	
	local.get	5
	local.get	16
	i32.sub 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label409
# %bb.70:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	3
	local.set	15
	br      	2                               # 2: down to label392
.LBB23_71:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label409:
	block   	
	local.get	0
	local.get	16
	i32.add 
	local.tee	4
	i32.load8_u	0
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label410
# %bb.72:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	3
	local.set	15
	br      	2                               # 2: down to label392
.LBB23_73:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label410:
	block   	
	local.get	12
	i32.const	7
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.eq  
	br_if   	0                               # 0: down to label411
# %bb.74:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	3
	local.set	15
	br      	2                               # 2: down to label392
.LBB23_75:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label411:
	i32.const	3
	local.set	15
	local.get	4
	i32.const	2
	i32.add 
	call	key_hex4
	local.tee	4
	i32.const	-1024
	i32.and 
	i32.const	56320
	i32.ne  
	br_if   	1                               # 1: down to label392
# %bb.76:                               #   in Loop: Header=BB23_5 Depth=1
	local.get	1
	i32.const	12
	i32.add 
	local.set	16
	local.get	3
	i32.const	10
	i32.shl 
	local.get	4
	i32.add 
	i32.const	-56613888
	i32.add 
	local.set	11
	i32.const	4
	local.set	15
	br      	1                               # 1: down to label392
.LBB23_77:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label408:
	block   	
	local.get	3
	i32.const	128
	i32.lt_u
	br_if   	0                               # 0: down to label412
# %bb.78:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	2
	local.set	15
	local.get	3
	i32.const	2048
	i32.lt_u
	br_if   	0                               # 0: down to label412
# %bb.79:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	3
	i32.const	4
	local.get	3
	i32.const	65536
	i32.lt_u
	i32.select
	local.set	15
.LBB23_80:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label412:
	local.get	3
	local.set	11
.LBB23_81:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label392:
	i32.const	-1
	local.set	4
	local.get	15
	local.get	6
	local.get	10
	i32.sub 
	i32.gt_u
	br_if   	2                               # 2: down to label376
# %bb.82:                               #   in Loop: Header=BB23_5 Depth=1
	i32.const	192
	local.set	4
	block   	
	block   	
	block   	
	block   	
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	3
	br_table 	{0, 2, 1}               # 2: down to label414
                                        # 1: down to label415
.LBB23_83:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label416:
	local.get	2
	local.get	10
	i32.add 
	local.get	11
	i32.store8	0
	local.get	10
	i32.const	1
	i32.add 
	local.set	4
	br      	2                               # 2: down to label413
.LBB23_84:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label415:
	i32.const	224
	i32.const	240
	local.get	15
	i32.const	3
	i32.eq  
	i32.select
	local.set	4
.LBB23_85:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label414:
	local.get	2
	local.get	10
	i32.add 
	local.get	4
	local.get	11
	local.get	15
	i32.const	6
	i32.mul 
	local.tee	1
	i32.const	-6
	i32.add 
	i32.shr_u
	i32.or  
	i32.store8	0
	local.get	10
	i32.const	1
	i32.add 
	local.set	4
	local.get	1
	i32.const	-12
	i32.add 
	local.set	1
.LBB23_86:                              #   Parent Loop BB23_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label417:
	local.get	2
	local.get	4
	i32.add 
	local.get	11
	local.get	1
	i32.shr_u
	i32.const	63
	i32.and 
	i32.const	128
	i32.or  
	i32.store8	0
	local.get	1
	i32.const	-6
	i32.add 
	local.set	1
	local.get	4
	i32.const	1
	i32.add 
	local.set	4
	local.get	3
	i32.const	-1
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label417
.LBB23_87:                              #   in Loop: Header=BB23_5 Depth=1
	end_loop
	end_block                               # label413:
	local.get	16
	local.set	1
.LBB23_88:                              #   in Loop: Header=BB23_5 Depth=1
	end_block                               # label378:
	local.get	1
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: up to label377
.LBB23_89:
	end_loop
	end_block                               # label376:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.hash_content_xxh32,"",@
	.type	hash_content_xxh32,@function    # -- Begin function hash_content_xxh32
hash_content_xxh32:                     # @hash_content_xxh32
	.functype	hash_content_xxh32 (i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32
# %bb.0:
	local.get	0
	local.get	1
	i32.add 
	local.set	3
	block   	
	block   	
	local.get	1
	i32.const	16
	i32.lt_u
	br_if   	0                               # 0: down to label419
# %bb.1:
	local.get	2
	i32.const	1640531535
	i32.add 
	local.set	4
	local.get	2
	i32.const	-2048144777
	i32.add 
	local.set	5
	local.get	2
	i32.const	606290984
	i32.add 
	local.set	6
	local.get	3
	i32.const	-16
	i32.add 
	local.set	7
.LBB24_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label420:
	local.get	0
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.get	6
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	6
	local.get	0
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.get	4
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	4
	local.get	0
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.get	2
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	2
	local.get	0
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.get	5
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	5
	local.get	0
	i32.const	16
	i32.add 
	local.tee	0
	local.get	7
	i32.le_u
	br_if   	0                               # 0: up to label420
# %bb.3:
	end_loop
	local.get	5
	i32.const	7
	i32.rotl
	local.get	6
	i32.const	1
	i32.rotl
	i32.add 
	local.get	2
	i32.const	12
	i32.rotl
	i32.add 
	local.get	4
	i32.const	18
	i32.rotl
	i32.add 
	local.set	2
	br      	1                               # 1: down to label418
.LBB24_4:
	end_block                               # label419:
	local.get	2
	i32.const	374761393
	i32.add 
	local.set	2
.LBB24_5:
	end_block                               # label418:
	local.get	2
	local.get	1
	i32.add 
	local.set	2
	block   	
	block   	
	local.get	0
	i32.const	4
	i32.add 
	local.get	3
	i32.le_u
	br_if   	0                               # 0: down to label422
# %bb.6:
	local.get	0
	local.set	4
	br      	1                               # 1: down to label421
.LBB24_7:
	end_block                               # label422:
.LBB24_8:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label423:
	local.get	0
	i32.load	0:p2align=0
	i32.const	-1028477379
	i32.mul 
	local.get	2
	i32.add 
	i32.const	17
	i32.rotl
	i32.const	668265263
	i32.mul 
	local.set	2
	local.get	0
	i32.const	8
	i32.add 
	local.set	5
	local.get	0
	i32.const	4
	i32.add 
	local.tee	4
	local.set	0
	local.get	5
	local.get	3
	i32.le_u
	br_if   	0                               # 0: up to label423
.LBB24_9:
	end_loop
	end_block                               # label421:
	block   	
	local.get	4
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label424
# %bb.10:
	local.get	4
	i32.const	1
	i32.add 
	local.set	0
	block   	
	local.get	3
	local.get	4
	i32.sub 
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label425
# %bb.11:
	local.get	4
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.get	2
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	2
	local.get	0
	local.set	4
.LBB24_12:
	end_block                               # label425:
	local.get	3
	local.get	0
	i32.eq  
	br_if   	0                               # 0: down to label424
# %bb.13:
.LBB24_14:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label426:
	local.get	4
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.get	4
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.get	2
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	2
	local.get	4
	i32.const	2
	i32.add 
	local.tee	4
	local.get	3
	i32.ne  
	br_if   	0                               # 0: up to label426
.LBB24_15:
	end_loop
	end_block                               # label424:
	local.get	2
	i32.const	15
	i32.shr_u
	local.get	2
	i32.xor 
	i32.const	-2048144777
	i32.mul 
	local.tee	0
	i32.const	13
	i32.shr_u
	local.get	0
	i32.xor 
	i32.const	-1028477379
	i32.mul 
	local.tee	0
	i32.const	16
	i32.shr_u
	local.get	0
	i32.xor 
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.copy_valid_utf8,"",@
	.type	copy_valid_utf8,@function       # -- Begin function copy_valid_utf8
copy_valid_utf8:                        # @copy_valid_utf8
	.functype	copy_valid_utf8 (i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	block   	
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label428
# %bb.1:
	i32.const	0
	local.set	3
.LBB25_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label429:
	local.get	0
	local.get	3
	i32.add 
	local.get	1
	local.get	3
	i32.add 
	i32.load8_s	0
	local.tee	4
	i32.store8	0
	local.get	3
	i32.const	1
	i32.add 
	local.set	5
	block   	
	block   	
	local.get	4
	i32.const	-1
	i32.le_s
	br_if   	0                               # 0: down to label431
# %bb.3:                                #   in Loop: Header=BB25_2 Depth=1
	local.get	5
	local.set	3
	br      	1                               # 1: down to label430
.LBB25_4:                               #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label431:
	block   	
	block   	
	block   	
	local.get	4
	i32.const	-16
	i32.and 
	i32.const	-32
	i32.ne  
	br_if   	0                               # 0: down to label434
# %bb.5:                                #   in Loop: Header=BB25_2 Depth=1
	i32.const	0
	local.set	6
	local.get	2
	local.get	5
	i32.sub 
	i32.const	2
	i32.lt_u
	br_if   	6                               # 6: down to label427
# %bb.6:                                #   in Loop: Header=BB25_2 Depth=1
	local.get	1
	local.get	5
	i32.add 
	i32.load8_s	0
	local.tee	7
	i32.const	-65
	i32.gt_s
	br_if   	6                               # 6: down to label427
# %bb.7:                                #   in Loop: Header=BB25_2 Depth=1
	local.get	1
	local.get	3
	i32.const	2
	i32.add 
	local.tee	8
	i32.add 
	i32.load8_s	0
	local.tee	9
	i32.const	-65
	i32.gt_s
	br_if   	6                               # 6: down to label427
# %bb.8:                                #   in Loop: Header=BB25_2 Depth=1
	block   	
	local.get	4
	i32.const	-32
	i32.ne  
	br_if   	0                               # 0: down to label435
# %bb.9:                                #   in Loop: Header=BB25_2 Depth=1
	local.get	7
	i32.const	-96
	i32.lt_u
	br_if   	7                               # 7: down to label427
.LBB25_10:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label435:
	i32.const	3
	local.set	10
	local.get	4
	i32.const	-19
	i32.ne  
	br_if   	1                               # 1: down to label433
# %bb.11:                               #   in Loop: Header=BB25_2 Depth=1
	local.get	7
	i32.const	-97
	i32.le_u
	br_if   	1                               # 1: down to label433
	br      	6                               # 6: down to label427
.LBB25_12:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label434:
	block   	
	local.get	4
	i32.const	62
	i32.add 
	i32.const	255
	i32.and 
	i32.const	29
	i32.gt_u
	br_if   	0                               # 0: down to label436
# %bb.13:                               #   in Loop: Header=BB25_2 Depth=1
	i32.const	0
	local.set	6
	local.get	2
	local.get	5
	i32.le_u
	br_if   	6                               # 6: down to label427
# %bb.14:                               #   in Loop: Header=BB25_2 Depth=1
	i32.const	2
	local.set	10
	local.get	5
	local.set	8
	local.get	1
	local.get	5
	i32.add 
	i32.load8_s	0
	local.tee	9
	i32.const	-64
	i32.lt_s
	br_if   	2                               # 2: down to label432
	br      	6                               # 6: down to label427
.LBB25_15:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label436:
	i32.const	0
	local.set	6
	local.get	4
	i32.const	11
	i32.add 
	i32.const	255
	i32.and 
	i32.const	251
	i32.lt_u
	br_if   	5                               # 5: down to label427
# %bb.16:                               #   in Loop: Header=BB25_2 Depth=1
	local.get	2
	local.get	5
	i32.sub 
	i32.const	3
	i32.lt_u
	br_if   	5                               # 5: down to label427
# %bb.17:                               #   in Loop: Header=BB25_2 Depth=1
	local.get	1
	local.get	5
	i32.add 
	i32.load8_s	0
	local.tee	10
	i32.const	-65
	i32.gt_s
	br_if   	5                               # 5: down to label427
# %bb.18:                               #   in Loop: Header=BB25_2 Depth=1
	local.get	1
	local.get	3
	i32.const	2
	i32.add 
	local.tee	11
	i32.add 
	i32.load8_s	0
	local.tee	7
	i32.const	-65
	i32.gt_s
	br_if   	5                               # 5: down to label427
# %bb.19:                               #   in Loop: Header=BB25_2 Depth=1
	local.get	1
	local.get	3
	i32.const	3
	i32.add 
	local.tee	8
	i32.add 
	i32.load8_s	0
	local.tee	9
	i32.const	-65
	i32.gt_s
	br_if   	5                               # 5: down to label427
# %bb.20:                               #   in Loop: Header=BB25_2 Depth=1
	block   	
	local.get	4
	i32.const	-16
	i32.ne  
	br_if   	0                               # 0: down to label437
# %bb.21:                               #   in Loop: Header=BB25_2 Depth=1
	local.get	10
	i32.const	-112
	i32.lt_u
	br_if   	6                               # 6: down to label427
.LBB25_22:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label437:
	block   	
	local.get	4
	i32.const	-12
	i32.ne  
	br_if   	0                               # 0: down to label438
# %bb.23:                               #   in Loop: Header=BB25_2 Depth=1
	local.get	10
	i32.const	-113
	i32.gt_u
	br_if   	6                               # 6: down to label427
.LBB25_24:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label438:
	local.get	0
	local.get	5
	i32.add 
	local.get	10
	i32.store8	0
	i32.const	4
	local.set	10
	local.get	11
	local.set	5
.LBB25_25:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label433:
	local.get	0
	local.get	5
	i32.add 
	local.get	7
	i32.store8	0
.LBB25_26:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label432:
	local.get	0
	local.get	8
	i32.add 
	local.get	9
	i32.store8	0
	local.get	3
	local.get	10
	i32.add 
	local.set	3
.LBB25_27:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label430:
	local.get	3
	local.get	2
	i32.lt_u
	br_if   	0                               # 0: up to label429
.LBB25_28:
	end_loop
	end_block                               # label428:
	i32.const	1
	local.set	6
.LBB25_29:
	end_block                               # label427:
	local.get	6
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_lookup_index,"",@
	.globl	encode_term_lookup_index        # -- Begin function encode_term_lookup_index
	.type	encode_term_lookup_index,@function
encode_term_lookup_index:               # @encode_term_lookup_index
	.functype	encode_term_lookup_index (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i64, i32, i32, i32, i64, i32, i32, i32, i32, i64, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-1
	local.set	17
	block   	
	local.get	0
	i32x4.splat
	local.get	2
	i32x4.replace_lane	1
	local.get	3
	i32x4.replace_lane	2
	local.get	4
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	18
	i32x4.eq
	local.get	6
	i32x4.splat
	local.get	7
	i32x4.replace_lane	1
	local.get	8
	i32x4.replace_lane	2
	local.get	9
	i32x4.replace_lane	3
	local.get	18
	i32x4.eq
	i8x16.shuffle	0, 1, 4, 5, 8, 9, 12, 13, 16, 17, 20, 21, 24, 25, 28, 29
	local.tee	19
	local.get	11
	i32x4.splat
	local.get	13
	i32x4.replace_lane	1
	local.get	14
	i32x4.replace_lane	2
	local.get	15
	i32x4.replace_lane	3
	local.get	18
	i32x4.eq
	local.get	18
	i8x16.shuffle	0, 1, 4, 5, 8, 9, 12, 13, 0, 1, 0, 1, 0, 1, 0, 1
	v128.or
	local.get	19
	i8x16.shuffle	0, 1, 2, 3, 4, 5, 6, 7, 24, 25, 26, 27, 28, 29, 30, 31
	v128.any_true
	br_if   	0                               # 0: down to label439
# %bb.1:
	local.get	10
	i32.const	-65535
	i32.add 
	i32.const	-65534
	i32.lt_u
	br_if   	0                               # 0: down to label439
# %bb.2:
	local.get	5
	i32.const	-65535
	i32.add 
	i32.const	-65534
	i32.lt_u
	br_if   	0                               # 0: down to label439
# %bb.3:
	local.get	16
	local.get	10
	i32.lt_u
	br_if   	0                               # 0: down to label439
# %bb.4:
	i32.const	-1
	local.set	17
	local.get	16
	local.get	16
	i32.const	-1
	i32.add 
	local.tee	20
	i32.and 
	br_if   	0                               # 0: down to label439
# %bb.5:
	local.get	16
	i32.const	1
	i32.shl 
	local.set	21
	i32.const	0
	local.set	22
	i32.const	0
	local.set	23
	i32.const	0
	local.set	16
	i32.const	-1
	local.set	24
	i32.const	0
	local.set	25
	i32.const	0
	local.set	26
	i32.const	0
	local.set	27
.LBB26_6:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB26_23 Depth 2
                                        #       Child Loop BB26_24 Depth 3
                                        #     Child Loop BB26_27 Depth 2
	loop    	                                # label440:
	local.get	16
	local.set	28
	i32.const	-2
	local.set	17
	local.get	6
	local.get	27
	i32.const	2
	i32.shl 
	local.tee	16
	i32.add 
	i32.load	0
	local.get	5
	i32.ge_u
	br_if   	1                               # 1: down to label439
# %bb.7:                                #   in Loop: Header=BB26_6 Depth=1
	local.get	8
	local.get	27
	i32.add 
	i32.load8_u	0
	local.tee	29
	i32.const	1
	i32.gt_u
	br_if   	1                               # 1: down to label439
# %bb.8:                                #   in Loop: Header=BB26_6 Depth=1
	block   	
	local.get	29
	br_if   	0                               # 0: down to label441
# %bb.9:                                #   in Loop: Header=BB26_6 Depth=1
	local.get	7
	local.get	16
	i32.add 
	i32.load	0
	local.get	5
	i32.ge_u
	br_if   	2                               # 2: down to label439
.LBB26_10:                              #   in Loop: Header=BB26_6 Depth=1
	end_block                               # label441:
	block   	
	block   	
	local.get	9
	local.get	16
	i32.add 
	i32.load	0
	local.tee	30
	i32.const	-1
	i32.gt_s
	br_if   	0                               # 0: down to label443
# %bb.11:                               #   in Loop: Header=BB26_6 Depth=1
	local.get	14
	local.get	27
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	65535
	i32.store16	0
	br      	1                               # 1: down to label442
.LBB26_12:                              #   in Loop: Header=BB26_6 Depth=1
	end_block                               # label443:
	block   	
	local.get	30
	local.get	24
	i32.eq  
	br_if   	0                               # 0: down to label444
# %bb.13:                               #   in Loop: Header=BB26_6 Depth=1
	block   	
	local.get	26
	br_if   	0                               # 0: down to label445
# %bb.14:                               #   in Loop: Header=BB26_6 Depth=1
	local.get	30
	local.get	24
	i32.le_s
	br_if   	0                               # 0: down to label445
# %bb.15:                               #   in Loop: Header=BB26_6 Depth=1
	block   	
	local.get	22
	i32.const	65534
	i32.le_u
	br_if   	0                               # 0: down to label446
# %bb.16:
	i32.const	-3
	return
.LBB26_17:                              #   in Loop: Header=BB26_6 Depth=1
	end_block                               # label446:
	local.get	13
	local.get	22
	i32.const	2
	i32.shl 
	i32.add 
	local.get	30
	i32.store	0
	i32.const	0
	local.set	26
	local.get	22
	local.set	25
	local.get	30
	local.set	24
	local.get	22
	i32.const	1
	i32.add 
	local.set	22
	br      	1                               # 1: down to label444
.LBB26_18:                              #   in Loop: Header=BB26_6 Depth=1
	end_block                               # label445:
	block   	
	local.get	26
	br_if   	0                               # 0: down to label447
# %bb.19:                               #   in Loop: Header=BB26_6 Depth=1
	block   	
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label448
# %bb.20:                               #   in Loop: Header=BB26_6 Depth=1
	local.get	15
	i32.const	0
	local.get	21
	memory.fill	0
.LBB26_21:                              #   in Loop: Header=BB26_6 Depth=1
	end_block                               # label448:
	local.get	22
	i32.eqz
	br_if   	0                               # 0: down to label447
# %bb.22:                               #   in Loop: Header=BB26_6 Depth=1
	i32.const	0
	local.set	24
.LBB26_23:                              #   Parent Loop BB26_6 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB26_24 Depth 3
	loop    	                                # label449:
	local.get	13
	local.get	24
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	17
	i32.const	255
	i32.and 
	i32.const	-2128831035
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	17
	i32.const	8
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	17
	i32.const	16
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	17
	i32.const	24
	i32.shr_u
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.set	17
.LBB26_24:                              #   Parent Loop BB26_6 Depth=1
                                        #     Parent Loop BB26_23 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label450:
	local.get	17
	local.get	20
	i32.and 
	local.tee	16
	i32.const	1
	i32.add 
	local.set	17
	local.get	15
	local.get	16
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	16
	i32.load16_u	0
	br_if   	0                               # 0: up to label450
# %bb.25:                               #   in Loop: Header=BB26_23 Depth=2
	end_loop
	local.get	16
	local.get	24
	i32.const	1
	i32.add 
	local.tee	24
	i32.store16	0
	local.get	24
	local.get	22
	i32.ne  
	br_if   	0                               # 0: up to label449
.LBB26_26:                              #   in Loop: Header=BB26_6 Depth=1
	end_loop
	end_block                               # label447:
	local.get	15
	local.get	30
	i32.const	255
	i32.and 
	i32.const	-2128831035
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	30
	i32.const	8
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	30
	i32.const	16
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	30
	i32.const	24
	i32.shr_u
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	20
	i32.and 
	local.tee	24
	i32.const	1
	i32.shl 
	i32.add 
	local.set	17
.LBB26_27:                              #   Parent Loop BB26_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label451:
	block   	
	local.get	17
	i32.load16_u	0
	local.tee	16
	br_if   	0                               # 0: down to label452
# %bb.28:                               #   in Loop: Header=BB26_6 Depth=1
	block   	
	local.get	22
	i32.const	65534
	i32.le_u
	br_if   	0                               # 0: down to label453
# %bb.29:
	i32.const	-3
	return
.LBB26_30:                              #   in Loop: Header=BB26_6 Depth=1
	end_block                               # label453:
	i32.const	1
	local.set	26
	local.get	17
	local.get	22
	i32.const	1
	i32.add 
	local.tee	16
	i32.store16	0
	local.get	13
	local.get	22
	i32.const	2
	i32.shl 
	i32.add 
	local.get	30
	i32.store	0
	local.get	22
	local.set	25
	local.get	30
	local.set	24
	local.get	16
	local.set	22
	br      	2                               # 2: down to label444
.LBB26_31:                              #   in Loop: Header=BB26_27 Depth=2
	end_block                               # label452:
	block   	
	local.get	13
	local.get	16
	i32.const	65535
	i32.and 
	i32.const	-1
	i32.add 
	local.tee	25
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.get	30
	i32.eq  
	br_if   	0                               # 0: down to label454
# %bb.32:                               #   in Loop: Header=BB26_27 Depth=2
	local.get	15
	local.get	24
	i32.const	1
	i32.add 
	local.get	20
	i32.and 
	local.tee	24
	i32.const	1
	i32.shl 
	i32.add 
	local.set	17
	br      	1                               # 1: up to label451
.LBB26_33:                              #   in Loop: Header=BB26_6 Depth=1
	end_block                               # label454:
	end_loop
	i32.const	1
	local.set	26
	local.get	30
	local.set	24
.LBB26_34:                              #   in Loop: Header=BB26_6 Depth=1
	end_block                               # label444:
	local.get	14
	local.get	27
	i32.const	1
	i32.shl 
	i32.add 
	local.get	25
	i32.store16	0
	local.get	23
	i32.const	1
	i32.add 
	local.set	23
.LBB26_35:                              #   in Loop: Header=BB26_6 Depth=1
	end_block                               # label442:
	local.get	28
	local.get	29
	i32.const	1
	i32.xor 
	local.tee	30
	i32.add 
	local.set	16
	local.get	27
	i32.const	1
	i32.add 
	local.tee	27
	local.get	10
	i32.ne  
	br_if   	0                               # 0: up to label440
# %bb.36:
	end_loop
	local.get	5
	i32.const	3
	i32.add 
	i32.const	2
	i32.shr_u
	local.set	17
	i32.const	1
	local.set	27
.LBB26_37:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label455:
	local.get	27
	local.tee	15
	i32.const	1
	i32.shl 
	local.set	27
	local.get	15
	local.get	17
	i32.lt_u
	br_if   	0                               # 0: up to label455
# %bb.38:
	end_loop
	local.get	22
	i32.const	3
	i32.add 
	i32.const	2
	i32.shr_u
	local.set	17
	i32.const	1
	local.set	24
.LBB26_39:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label456:
	local.get	24
	local.tee	20
	i32.const	1
	i32.shl 
	local.set	24
	local.get	20
	local.get	17
	i32.lt_u
	br_if   	0                               # 0: up to label456
# %bb.40:
	end_loop
	i32.const	-4
	local.set	17
	local.get	1
	i64.extend_i32_u
	i64.const	3
	i64.add 
	local.tee	31
	i64.const	8589934588
	i64.and 
	local.tee	32
	local.get	10
	i32.const	3
	i32.mul 
	local.get	5
	i32.add 
	i32.const	1
	i32.shl 
	i32.const	3
	i32.add 
	local.tee	33
	i32.const	2147483644
	i32.and 
	local.tee	34
	i64.extend_i32_u
	i64.add 
	local.get	22
	i32.const	2
	i32.shl 
	local.tee	35
	i64.extend_i32_u
	i64.add 
	i64.const	32
	i64.add 
	local.tee	36
	local.get	5
	i32.const	1
	i32.add 
	local.tee	37
	i32.const	1
	i32.shl 
	local.tee	38
	local.get	5
	i32.add 
	local.get	10
	i32.add 
	local.get	16
	i32.add 
	local.get	23
	i32.add 
	local.get	22
	i32.add 
	local.get	22
	i32.const	1
	i32.add 
	local.tee	39
	i32.add 
	local.get	15
	i32.add 
	local.get	20
	i32.add 
	i32.const	1
	i32.shl 
	i32.const	3
	i32.add 
	i32.const	-4
	i32.and 
	i32.const	32
	i32.add 
	local.tee	40
	i64.extend_i32_u
	i64.add 
	i64.const	16
	i64.add 
	local.tee	41
	local.get	12
	i64.extend_i32_u
	i64.gt_u
	br_if   	0                               # 0: down to label439
# %bb.41:
	local.get	41
	i64.const	2147483647
	i64.gt_u
	br_if   	0                               # 0: down to label439
# %bb.42:
	local.get	11
	i64.const	0
	i64.store	40:p2align=2
	local.get	11
	local.get	16
	i32.store	36
	local.get	11
	local.get	22
	i32.store	32
	local.get	11
	i32.const	7
	i32.store	28
	local.get	11
	local.get	1
	i32.store	24
	local.get	11
	local.get	5
	i32.store	20
	local.get	11
	local.get	10
	i32.store	16
	local.get	11
	local.get	40
	i32.store	12
	local.get	11
	i64.const	30992321613
	i64.store	0:p2align=2
	local.get	11
	local.get	36
	i32.wrap_i64
	local.tee	42
	i32.store	8
	local.get	11
	i32.const	48
	i32.add 
	local.set	17
	block   	
	local.get	1
	i32.eqz
	br_if   	0                               # 0: down to label457
# %bb.43:
	local.get	17
	local.get	0
	local.get	1
	memory.copy	0, 0
.LBB26_44:
	end_block                               # label457:
	i32.const	0
	local.set	29
	block   	
	local.get	32
	i32.wrap_i64
	local.tee	43
	local.get	1
	i32.sub 
	local.tee	25
	i32.eqz
	br_if   	0                               # 0: down to label458
# %bb.45:
	local.get	17
	local.get	1
	i32.add 
	i32.const	0
	local.get	25
	memory.fill	0
.LBB26_46:
	end_block                               # label458:
	local.get	11
	i32.const	16
	i32.add 
	local.set	21
	block   	
	local.get	10
	i32.const	1
	i32.shl 
	local.tee	44
	local.get	43
	i32.const	32
	i32.add 
	local.tee	25
	local.get	5
	i32.const	1
	i32.shl 
	local.tee	45
	i32.add 
	i32.add 
	local.tee	0
	local.get	44
	i32.add 
	local.tee	12
	local.get	44
	i32.add 
	local.tee	17
	i32.const	3
	i32.add 
	i32.const	-4
	i32.and 
	local.tee	9
	local.get	17
	i32.sub 
	local.tee	26
	i32.eqz
	br_if   	0                               # 0: down to label459
# %bb.47:
	local.get	21
	local.get	17
	i32.add 
	i32.const	0
	local.get	26
	memory.fill	0
.LBB26_48:
	end_block                               # label459:
	block   	
	local.get	35
	i32.eqz
	br_if   	0                               # 0: down to label460
# %bb.49:
	local.get	21
	local.get	9
	i32.add 
	local.get	13
	local.get	35
	memory.copy	0, 0
.LBB26_50:
	end_block                               # label460:
	local.get	21
	local.get	25
	i32.add 
	local.set	9
	local.get	21
	local.get	0
	i32.add 
	local.set	26
	local.get	21
	local.get	12
	i32.add 
	local.set	12
	local.get	41
	i32.wrap_i64
	local.set	46
	local.get	5
	local.set	0
.LBB26_51:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label461:
	i32.const	-5
	local.set	17
	local.get	3
	i32.load	0
	local.get	29
	i32.ne  
	br_if   	1                               # 1: down to label439
# %bb.52:                               #   in Loop: Header=BB26_51 Depth=1
	local.get	2
	i32.load16_u	0
	local.tee	25
	i32.const	1
	i32.add 
	i32.const	65535
	i32.and 
	i32.const	2
	i32.lt_u
	br_if   	1                               # 1: down to label439
# %bb.53:                               #   in Loop: Header=BB26_51 Depth=1
	local.get	1
	local.get	29
	i32.lt_u
	br_if   	1                               # 1: down to label439
# %bb.54:                               #   in Loop: Header=BB26_51 Depth=1
	local.get	1
	local.get	29
	i32.sub 
	local.get	25
	i32.lt_u
	br_if   	1                               # 1: down to label439
# %bb.55:                               #   in Loop: Header=BB26_51 Depth=1
	local.get	9
	local.get	25
	i32.store16	0
	local.get	3
	i32.const	4
	i32.add 
	local.set	3
	local.get	2
	i32.const	2
	i32.add 
	local.set	2
	local.get	9
	i32.const	2
	i32.add 
	local.set	9
	local.get	29
	local.get	25
	i32.add 
	local.set	29
	local.get	0
	i32.const	-1
	i32.add 
	local.tee	0
	br_if   	0                               # 0: up to label461
# %bb.56:
	end_loop
	local.get	29
	local.get	1
	i32.ne  
	br_if   	0                               # 0: down to label439
# %bb.57:
	local.get	21
	local.get	42
	i32.add 
	local.tee	2
	i32.const	7
	i32.store	28
	local.get	2
	local.get	23
	i32.store	24
	local.get	2
	local.get	22
	i32.store	20
	local.get	2
	local.get	16
	i32.store	16
	local.get	2
	local.get	20
	i32.store	12
	local.get	2
	local.get	15
	i32.store	8
	local.get	2
	local.get	5
	i32.store	4
	local.get	2
	local.get	10
	i32.store	0
	i32.const	0
	local.set	17
	block   	
	local.get	40
	local.get	24
	local.get	27
	i32.const	32
	i32.add 
	local.tee	47
	local.get	45
	i32.add 
	local.tee	9
	local.get	38
	i32.add 
	local.tee	1
	local.get	44
	i32.add 
	local.tee	0
	local.get	38
	i32.add 
	local.tee	42
	local.get	16
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	3
	i32.add 
	local.tee	48
	local.get	22
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	49
	local.get	39
	i32.const	1
	i32.shl 
	local.tee	25
	i32.add 
	local.tee	50
	local.get	23
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	29
	i32.sub 
	local.tee	23
	i32.eqz
	br_if   	0                               # 0: down to label462
# %bb.58:
	local.get	2
	local.get	29
	i32.add 
	i32.const	0
	local.get	23
	memory.fill	0
.LBB26_59:
	end_block                               # label462:
	local.get	2
	i32.const	32
	i32.add 
	local.set	29
	block   	
	local.get	27
	i32.eqz
	br_if   	0                               # 0: down to label463
# %bb.60:
	local.get	29
	i32.const	255
	local.get	27
	memory.fill	0
.LBB26_61:
	end_block                               # label463:
	local.get	2
	local.get	3
	i32.add 
	local.set	3
	block   	
	local.get	24
	i32.eqz
	br_if   	0                               # 0: down to label464
# %bb.62:
	local.get	3
	i32.const	255
	local.get	24
	memory.fill	0
.LBB26_63:
	end_block                               # label464:
	local.get	2
	local.get	9
	i32.add 
	local.set	21
	block   	
	local.get	38
	i32.eqz
	local.tee	27
	br_if   	0                               # 0: down to label465
# %bb.64:
	local.get	21
	i32.const	0
	local.get	38
	memory.fill	0
.LBB26_65:
	end_block                               # label465:
	local.get	2
	local.get	0
	i32.add 
	local.set	40
	block   	
	local.get	27
	br_if   	0                               # 0: down to label466
# %bb.66:
	local.get	40
	i32.const	0
	local.get	38
	memory.fill	0
.LBB26_67:
	end_block                               # label466:
	local.get	2
	local.get	49
	i32.add 
	local.set	23
	block   	
	local.get	25
	i32.eqz
	br_if   	0                               # 0: down to label467
# %bb.68:
	local.get	23
	i32.const	0
	local.get	25
	memory.fill	0
.LBB26_69:
	end_block                               # label467:
	local.get	5
	i32.const	1
	i32.and 
	local.set	38
	local.get	15
	i32.const	-1
	i32.add 
	local.set	25
	block   	
	local.get	5
	i32.const	1
	i32.eq  
	br_if   	0                               # 0: down to label468
# %bb.70:
	local.get	34
	local.get	43
	i32.add 
	local.get	11
	i32.add 
	local.get	35
	i32.add 
	local.get	15
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	82
	i32.add 
	local.set	27
	i32.const	0
	local.get	5
	i32.const	65534
	i32.and 
	i32.sub 
	local.set	0
	i32.const	1
	local.set	17
	local.get	4
	local.set	24
.LBB26_71:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label469:
	local.get	27
	i32.const	-2
	i32.add 
	local.get	29
	local.get	24
	i32.load	0
	local.get	25
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	9
	i32.load16_u	0
	i32.store16	0
	local.get	9
	local.get	17
	i32.const	-1
	i32.add 
	i32.store16	0
	local.get	27
	local.get	29
	local.get	24
	i32.const	4
	i32.add 
	i32.load	0
	local.get	25
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	9
	i32.load16_u	0
	i32.store16	0
	local.get	9
	local.get	17
	i32.store16	0
	local.get	27
	i32.const	4
	i32.add 
	local.set	27
	local.get	24
	i32.const	8
	i32.add 
	local.set	24
	local.get	0
	local.get	17
	i32.const	2
	i32.add 
	local.tee	17
	i32.add 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: up to label469
# %bb.72:
	end_loop
	local.get	17
	i32.const	-1
	i32.add 
	local.set	17
.LBB26_73:
	end_block                               # label468:
	block   	
	local.get	38
	i32.eqz
	br_if   	0                               # 0: down to label470
# %bb.74:
	local.get	2
	local.get	47
	i32.add 
	local.get	17
	i32.const	1
	i32.shl 
	i32.add 
	local.get	29
	local.get	4
	local.get	17
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.get	25
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	27
	i32.load16_u	0
	i32.store16	0
	local.get	27
	local.get	17
	i32.store16	0
.LBB26_75:
	end_block                               # label470:
	block   	
	local.get	22
	i32.eqz
	br_if   	0                               # 0: down to label471
# %bb.76:
	local.get	2
	local.get	48
	i32.add 
	local.set	27
	local.get	20
	i32.const	-1
	i32.add 
	local.set	29
	i32.const	0
	local.set	24
.LBB26_77:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label472:
	local.get	27
	local.get	3
	local.get	13
	i32.load	0
	local.tee	17
	i32.const	255
	i32.and 
	i32.const	-2128831035
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	17
	i32.const	8
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	17
	i32.const	16
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	17
	i32.const	24
	i32.shr_u
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	29
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	17
	i32.load16_u	0
	i32.store16	0
	local.get	17
	local.get	24
	i32.store16	0
	local.get	27
	i32.const	2
	i32.add 
	local.set	27
	local.get	13
	i32.const	4
	i32.add 
	local.set	13
	local.get	22
	local.get	24
	i32.const	1
	i32.add 
	local.tee	24
	i32.ne  
	br_if   	0                               # 0: up to label472
.LBB26_78:
	end_loop
	end_block                               # label471:
	local.get	2
	local.get	1
	i32.add 
	local.set	3
	local.get	2
	local.get	42
	i32.add 
	local.set	0
	local.get	2
	local.get	50
	i32.add 
	local.set	4
	local.get	23
	i32.const	2
	i32.add 
	local.set	1
	local.get	40
	i32.const	2
	i32.add 
	local.set	9
	local.get	21
	i32.const	2
	i32.add 
	local.set	24
	local.get	11
	local.get	43
	local.get	45
	i32.add 
	i32.add 
	local.set	2
	i32.const	0
	local.set	17
	local.get	10
	local.set	13
.LBB26_79:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label473:
	local.get	2
	local.get	17
	i32.add 
	i32.const	48
	i32.add 
	local.tee	29
	local.get	6
	i32.load	0
	i32.store16	0
	i32.const	65535
	local.set	27
	block   	
	local.get	8
	i32.load8_u	0
	br_if   	0                               # 0: down to label474
# %bb.80:                               #   in Loop: Header=BB26_79 Depth=1
	local.get	7
	i32.load	0
	local.set	27
.LBB26_81:                              #   in Loop: Header=BB26_79 Depth=1
	end_block                               # label474:
	local.get	26
	local.get	17
	i32.add 
	local.tee	25
	local.get	27
	i32.store16	0
	local.get	12
	local.get	17
	i32.add 
	local.get	14
	local.get	17
	i32.add 
	i32.load16_u	0
	local.tee	27
	i32.store16	0
	local.get	24
	local.get	29
	i32.load16_u	0
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	29
	local.get	29
	i32.load16_u	0
	i32.const	1
	i32.add 
	i32.store16	0
	block   	
	local.get	25
	i32.load16_u	0
	local.tee	29
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label475
# %bb.82:                               #   in Loop: Header=BB26_79 Depth=1
	local.get	9
	local.get	29
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	29
	local.get	29
	i32.load16_u	0
	i32.const	1
	i32.add 
	i32.store16	0
.LBB26_83:                              #   in Loop: Header=BB26_79 Depth=1
	end_block                               # label475:
	block   	
	local.get	27
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label476
# %bb.84:                               #   in Loop: Header=BB26_79 Depth=1
	local.get	1
	local.get	27
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	27
	local.get	27
	i32.load16_u	0
	i32.const	1
	i32.add 
	i32.store16	0
.LBB26_85:                              #   in Loop: Header=BB26_79 Depth=1
	end_block                               # label476:
	local.get	6
	i32.const	4
	i32.add 
	local.set	6
	local.get	8
	i32.const	1
	i32.add 
	local.set	8
	local.get	7
	i32.const	4
	i32.add 
	local.set	7
	local.get	17
	i32.const	2
	i32.add 
	local.set	17
	local.get	13
	i32.const	-1
	i32.add 
	local.tee	13
	br_if   	0                               # 0: up to label473
# %bb.86:
	end_loop
	i32.const	1
	local.set	17
	local.get	37
	i32.const	2
	local.get	37
	i32.const	2
	i32.gt_u
	i32.select
	i32.const	-1
	i32.add 
	local.tee	27
	i32.const	1
	i32.and 
	local.set	2
	block   	
	local.get	5
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label477
# %bb.87:
	local.get	11
	local.get	34
	local.get	43
	i32.add 
	i32.add 
	local.get	35
	i32.add 
	local.get	15
	i32.const	1
	i32.shl 
	i32.add 
	local.set	17
	local.get	27
	i32.const	-2
	i32.and 
	local.set	8
	local.get	5
	i32.const	2
	i32.shl 
	local.get	44
	i32.add 
	local.set	7
	i32.const	0
	local.set	6
.LBB26_88:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label478:
	local.get	17
	local.get	45
	i32.add 
	local.tee	27
	i32.const	82
	i32.add 
	local.tee	13
	local.get	27
	i32.const	80
	i32.add 
	i32.load16_u	0
	local.get	13
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	17
	local.get	7
	i32.add 
	local.tee	29
	i32.const	84
	i32.add 
	local.tee	25
	local.get	29
	i32.const	82
	i32.add 
	i32.load16_u	0
	local.get	25
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	27
	i32.const	84
	i32.add 
	local.tee	27
	local.get	13
	i32.load16_u	0
	local.get	27
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	29
	i32.const	86
	i32.add 
	local.tee	27
	local.get	25
	i32.load16_u	0
	local.get	27
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	17
	i32.const	4
	i32.add 
	local.set	17
	local.get	8
	local.get	6
	i32.const	2
	i32.add 
	local.tee	6
	i32.ne  
	br_if   	0                               # 0: up to label478
# %bb.89:
	end_loop
	local.get	6
	i32.const	1
	i32.add 
	local.set	17
.LBB26_90:
	end_block                               # label477:
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label479
# %bb.91:
	local.get	21
	local.get	17
	i32.const	1
	i32.shl 
	local.tee	17
	i32.add 
	local.tee	27
	local.get	21
	local.get	17
	i32.const	-2
	i32.add 
	local.tee	13
	i32.add 
	i32.load16_u	0
	local.get	27
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	40
	local.get	17
	i32.add 
	local.tee	17
	local.get	40
	local.get	13
	i32.add 
	i32.load16_u	0
	local.get	17
	i32.load16_u	0
	i32.add 
	i32.store16	0
.LBB26_92:
	end_block                               # label479:
	block   	
	local.get	22
	i32.eqz
	br_if   	0                               # 0: down to label480
# %bb.93:
	i32.const	1
	local.set	17
	local.get	11
	local.get	33
	i32.const	2147483644
	i32.and 
	local.get	31
	i32.wrap_i64
	local.tee	8
	i32.add 
	i32.const	-4
	i32.and 
	i32.add 
	local.get	5
	local.get	22
	i32.add 
	local.tee	2
	i32.const	6
	i32.mul 
	local.tee	25
	i32.add 
	local.get	10
	local.get	28
	i32.add 
	local.get	30
	i32.add 
	local.get	15
	i32.add 
	local.get	20
	i32.add 
	local.tee	7
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	84
	i32.add 
	i32.load16_u	0
	local.set	27
	local.get	39
	i32.const	2
	local.get	39
	i32.const	2
	i32.gt_u
	i32.select
	local.tee	29
	i32.const	-1
	i32.add 
	local.tee	6
	i32.const	3
	i32.and 
	local.set	13
	block   	
	local.get	29
	i32.const	-2
	i32.add 
	i32.const	3
	i32.lt_u
	br_if   	0                               # 0: down to label481
# %bb.94:
	local.get	11
	local.get	33
	i32.const	2
	i32.shr_u
	local.get	8
	i32.const	2
	i32.shr_u
	i32.add 
	i32.const	2
	i32.shl 
	i32.add 
	local.get	25
	i32.add 
	local.get	7
	i32.const	1
	i32.shl 
	i32.add 
	local.set	17
	local.get	6
	i32.const	-4
	i32.and 
	local.set	6
	i32.const	0
	local.set	29
.LBB26_95:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label482:
	local.get	17
	i32.const	86
	i32.add 
	local.tee	25
	local.get	27
	local.get	25
	i32.load16_u	0
	i32.add 
	local.tee	27
	i32.store16	0
	local.get	17
	i32.const	88
	i32.add 
	local.tee	25
	local.get	27
	local.get	25
	i32.load16_u	0
	i32.add 
	local.tee	27
	i32.store16	0
	local.get	17
	i32.const	90
	i32.add 
	local.tee	25
	local.get	27
	local.get	25
	i32.load16_u	0
	i32.add 
	local.tee	27
	i32.store16	0
	local.get	17
	i32.const	92
	i32.add 
	local.tee	25
	local.get	27
	local.get	25
	i32.load16_u	0
	i32.add 
	local.tee	27
	i32.store16	0
	local.get	17
	i32.const	8
	i32.add 
	local.set	17
	local.get	6
	local.get	29
	i32.const	4
	i32.add 
	local.tee	29
	i32.ne  
	br_if   	0                               # 0: up to label482
# %bb.96:
	end_loop
	local.get	29
	i32.const	1
	i32.add 
	local.set	17
.LBB26_97:
	end_block                               # label481:
	local.get	13
	i32.eqz
	br_if   	0                               # 0: down to label480
# %bb.98:
	local.get	33
	i32.const	2
	i32.shr_u
	local.get	8
	i32.const	2
	i32.shr_u
	i32.add 
	i32.const	2
	i32.shl 
	local.get	17
	i32.const	1
	i32.shl 
	i32.add 
	local.get	11
	i32.add 
	local.get	2
	i32.const	6
	i32.mul 
	i32.add 
	local.get	7
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	84
	i32.add 
	local.set	17
.LBB26_99:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label483:
	local.get	17
	local.get	27
	local.get	17
	i32.load16_u	0
	i32.add 
	local.tee	27
	i32.store16	0
	local.get	17
	i32.const	2
	i32.add 
	local.set	17
	local.get	13
	i32.const	-1
	i32.add 
	local.tee	13
	br_if   	0                               # 0: up to label483
.LBB26_100:
	end_loop
	end_block                               # label480:
	local.get	10
	i32.const	-1
	i32.add 
	local.set	27
	local.get	44
	local.get	14
	i32.add 
	i32.const	-2
	i32.add 
	local.set	29
	local.get	43
	local.get	44
	i32.add 
	local.get	45
	i32.add 
	local.get	11
	i32.add 
	i32.const	46
	i32.add 
	local.set	25
	local.get	10
	i32.const	2
	i32.shl 
	local.get	43
	i32.add 
	local.get	45
	i32.add 
	local.get	11
	i32.add 
	i32.const	46
	i32.add 
	local.set	6
	i32.const	0
	local.set	17
.LBB26_101:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label484:
	local.get	24
	local.get	25
	local.get	17
	i32.add 
	i32.load16_u	0
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	13
	local.get	13
	i32.load16_u	0
	i32.const	-1
	i32.add 
	local.tee	13
	i32.store16	0
	local.get	3
	local.get	13
	i32.const	65535
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.get	27
	i32.store16	0
	block   	
	local.get	6
	local.get	17
	i32.add 
	i32.load16_u	0
	local.tee	13
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label485
# %bb.102:                              #   in Loop: Header=BB26_101 Depth=1
	local.get	9
	local.get	13
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	13
	local.get	13
	i32.load16_u	0
	i32.const	-1
	i32.add 
	local.tee	13
	i32.store16	0
	local.get	0
	local.get	13
	i32.const	65535
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.get	27
	i32.store16	0
.LBB26_103:                             #   in Loop: Header=BB26_101 Depth=1
	end_block                               # label485:
	block   	
	local.get	29
	local.get	17
	i32.add 
	i32.load16_u	0
	local.tee	13
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label486
# %bb.104:                              #   in Loop: Header=BB26_101 Depth=1
	local.get	23
	local.get	13
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	13
	local.get	13
	i32.load16_u	0
	local.tee	13
	i32.const	1
	i32.add 
	i32.store16	0
	local.get	4
	local.get	13
	i32.const	1
	i32.shl 
	i32.add 
	local.get	27
	i32.store16	0
.LBB26_105:                             #   in Loop: Header=BB26_101 Depth=1
	end_block                               # label486:
	local.get	17
	i32.const	-2
	i32.add 
	local.set	17
	local.get	27
	i32.const	-1
	i32.add 
	local.tee	27
	i32.const	-1
	i32.ne  
	br_if   	0                               # 0: up to label484
# %bb.106:
	end_loop
	block   	
	local.get	5
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label487
# %bb.107:
	i32.const	1
	local.set	25
	block   	
	local.get	5
	i32.const	17
	i32.lt_u
	br_if   	0                               # 0: down to label488
# %bb.108:
	i32.const	1
	local.set	25
	local.get	10
	local.get	5
	i32.add 
	i32.const	8
	i32.lt_u
	br_if   	0                               # 0: down to label488
# %bb.109:
	local.get	11
	local.get	34
	local.get	31
	i32.wrap_i64
	i32.const	-4
	i32.and 
	i32.add 
	local.tee	27
	local.get	5
	i32.const	2
	i32.shl 
	i32.add 
	local.get	44
	i32.add 
	i32.add 
	local.get	35
	i32.add 
	local.set	17
	local.get	15
	i32.const	1
	i32.shl 
	local.set	24
	local.get	5
	i32.const	-1
	i32.add 
	local.tee	8
	i32.const	-8
	i32.and 
	local.tee	6
	i32.const	1
	i32.or  
	local.set	25
	local.get	11
	local.get	27
	local.get	45
	i32.add 
	i32.add 
	local.get	35
	i32.add 
	local.set	27
	local.get	6
	local.set	13
.LBB26_110:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label489:
	local.get	27
	local.get	24
	i32.add 
	local.tee	29
	i32.const	82
	i32.add 
	local.get	29
	i32.const	84
	i32.add 
	v128.load	0:p2align=1
	v128.store	0:p2align=1
	local.get	17
	local.get	24
	i32.add 
	local.tee	29
	i32.const	84
	i32.add 
	local.get	29
	i32.const	86
	i32.add 
	v128.load	0:p2align=1
	v128.store	0:p2align=1
	local.get	27
	i32.const	16
	i32.add 
	local.set	27
	local.get	17
	i32.const	16
	i32.add 
	local.set	17
	local.get	13
	i32.const	-8
	i32.add 
	local.tee	13
	br_if   	0                               # 0: up to label489
# %bb.111:
	end_loop
	local.get	8
	local.get	6
	i32.eq  
	br_if   	1                               # 1: down to label487
.LBB26_112:
	end_block                               # label488:
	local.get	25
	i32.const	1
	i32.add 
	local.set	17
	block   	
	local.get	5
	i32.const	1
	i32.and 
	br_if   	0                               # 0: down to label490
# %bb.113:
	local.get	21
	local.get	25
	i32.const	1
	i32.shl 
	local.tee	27
	i32.add 
	local.get	21
	local.get	25
	i32.const	1
	i32.add 
	local.tee	25
	i32.const	1
	i32.shl 
	local.tee	24
	i32.add 
	i32.load16_u	0
	i32.store16	0
	local.get	40
	local.get	27
	i32.add 
	local.get	40
	local.get	24
	i32.add 
	i32.load16_u	0
	i32.store16	0
.LBB26_114:
	end_block                               # label490:
	local.get	5
	local.get	17
	i32.eq  
	br_if   	0                               # 0: down to label487
# %bb.115:
	local.get	11
	local.get	34
	local.get	31
	i32.wrap_i64
	i32.const	-4
	i32.and 
	i32.add 
	local.tee	27
	local.get	45
	i32.add 
	i32.add 
	local.get	35
	i32.add 
	local.get	15
	i32.const	1
	i32.shl 
	local.tee	24
	i32.add 
	local.set	17
	local.get	11
	local.get	27
	local.get	5
	i32.const	2
	i32.shl 
	i32.add 
	local.get	44
	i32.add 
	i32.add 
	local.get	35
	i32.add 
	local.get	24
	i32.add 
	local.set	27
	local.get	25
	i32.const	1
	i32.shl 
	local.set	29
	local.get	5
	local.get	25
	i32.sub 
	local.set	25
.LBB26_116:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label491:
	local.get	17
	local.get	29
	i32.add 
	local.tee	24
	i32.const	80
	i32.add 
	local.get	24
	i32.const	82
	i32.add 
	local.tee	6
	i32.load16_u	0
	i32.store16	0
	local.get	27
	local.get	29
	i32.add 
	local.tee	13
	i32.const	82
	i32.add 
	local.get	13
	i32.const	84
	i32.add 
	local.tee	8
	i32.load16_u	0
	i32.store16	0
	local.get	6
	local.get	24
	i32.const	84
	i32.add 
	i32.load16_u	0
	i32.store16	0
	local.get	8
	local.get	13
	i32.const	86
	i32.add 
	i32.load16_u	0
	i32.store16	0
	local.get	17
	i32.const	4
	i32.add 
	local.set	17
	local.get	27
	i32.const	4
	i32.add 
	local.set	27
	local.get	25
	i32.const	-2
	i32.add 
	local.tee	25
	br_if   	0                               # 0: up to label491
.LBB26_117:
	end_loop
	end_block                               # label487:
	local.get	21
	local.get	5
	i32.const	1
	i32.shl 
	local.tee	17
	i32.add 
	local.get	10
	i32.store16	0
	local.get	40
	local.get	17
	i32.add 
	local.get	16
	i32.store16	0
	block   	
	local.get	22
	i32.eqz
	br_if   	0                               # 0: down to label492
# %bb.118:
	local.get	22
	local.set	16
	block   	
	local.get	22
	i32.const	8
	i32.lt_u
	br_if   	0                               # 0: down to label493
# %bb.119:
	local.get	5
	i32.const	6
	i32.mul 
	local.get	33
	i32.const	2
	i32.shr_u
	local.get	31
	i32.wrap_i64
	i32.const	2
	i32.shr_u
	i32.add 
	i32.const	2
	i32.shl 
	i32.add 
	local.get	11
	i32.add 
	local.get	22
	i32.const	3
	i32.shl 
	i32.add 
	local.get	10
	local.get	28
	i32.add 
	local.get	30
	i32.add 
	local.get	15
	i32.add 
	local.get	20
	i32.add 
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	70
	i32.add 
	local.set	17
	local.get	22
	i32.const	7
	i32.and 
	local.set	16
	local.get	22
	i32.const	-8
	i32.and 
	local.tee	24
	local.set	27
.LBB26_120:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label494:
	local.get	17
	local.get	17
	i32.const	-2
	i32.add 
	v128.load	0:p2align=1
	v128.store	0:p2align=1
	local.get	17
	i32.const	-16
	i32.add 
	local.set	17
	local.get	27
	i32.const	-8
	i32.add 
	local.tee	27
	br_if   	0                               # 0: up to label494
# %bb.121:
	end_loop
	local.get	22
	local.get	24
	i32.eq  
	br_if   	1                               # 1: down to label492
.LBB26_122:
	end_block                               # label493:
	local.get	33
	i32.const	2
	i32.shr_u
	local.get	31
	i32.wrap_i64
	i32.const	2
	i32.shr_u
	i32.add 
	i32.const	2
	i32.shl 
	local.get	16
	i32.const	1
	i32.shl 
	i32.add 
	local.get	11
	i32.add 
	local.get	5
	local.get	22
	i32.add 
	i32.const	6
	i32.mul 
	i32.add 
	local.get	10
	local.get	28
	i32.add 
	local.get	30
	i32.add 
	local.get	15
	i32.add 
	local.get	20
	i32.add 
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	84
	i32.add 
	local.set	17
.LBB26_123:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label495:
	local.get	17
	local.get	17
	i32.const	-2
	i32.add 
	local.tee	15
	i32.load16_u	0
	i32.store16	0
	local.get	15
	local.set	17
	local.get	16
	i32.const	-1
	i32.add 
	local.tee	16
	br_if   	0                               # 0: up to label495
.LBB26_124:
	end_loop
	end_block                               # label492:
	local.get	23
	i32.const	0
	i32.store16	0
	local.get	46
	local.set	17
.LBB26_125:
	end_block                               # label439:
	local.get	17
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_token_binary_dedup,"",@
	.globl	encode_term_content_token_binary_dedup # -- Begin function encode_term_content_token_binary_dedup
	.type	encode_term_content_token_binary_dedup,@function
encode_term_content_token_binary_dedup: # @encode_term_content_token_binary_dedup
	.functype	encode_term_content_token_binary_dedup (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	10
	global.set	__stack_pointer
	i32.const	-1
	local.set	11
	block   	
	local.get	0
	i32x4.splat
	local.get	1
	i32x4.replace_lane	1
	local.get	3
	i32x4.replace_lane	2
	local.get	5
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	12
	i32x4.eq
	v128.const	65535, 65535, 65535, 65535
	local.tee	13
	v128.and
	local.get	6
	i32x4.splat
	local.get	8
	i32x4.replace_lane	1
	local.get	9
	i32x4.replace_lane	2
	local.get	7
	i32x4.replace_lane	3
	local.get	12
	i32x4.eq
	local.get	13
	v128.and
	i16x8.narrow_i32x4_u
	v128.any_true
	br_if   	0                               # 0: down to label496
# %bb.1:
	i32.const	-1
	local.set	11
	local.get	7
	local.get	7
	i32.const	-1
	i32.add 
	local.tee	14
	i32.and 
	br_if   	0                               # 0: down to label496
# %bb.2:
	i32.const	0
	local.set	15
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	10
	i32.const	0
	i32.store	12
	i32.const	0
	local.set	16
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label497
# %bb.3:
	i32.const	0
	local.set	15
	i32.const	0
	local.set	16
	i32.const	0
	local.set	17
.LBB27_4:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB27_5 Depth 2
                                        #     Child Loop BB27_17 Depth 2
                                        #       Child Loop BB27_24 Depth 3
                                        #       Child Loop BB27_27 Depth 3
	loop    	                                # label498:
	local.get	10
	i32.const	0
	i32.store	8
	local.get	10
	i32.const	0
	i32.store	4
	block   	
	local.get	0
	local.get	1
	local.get	17
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	18
	local.get	3
	local.get	4
	local.get	10
	i32.const	12
	i32.add 
	local.get	10
	i32.const	8
	i32.add 
	local.get	10
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	call	encode_term_content_token_binary_row
	br_if   	0                               # 0: down to label499
.LBB27_5:                               #   Parent Loop BB27_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label500:
	local.get	10
	local.get	15
	i32.store	12
	i32.const	-2
	local.set	11
	local.get	4
	i32.const	2147483646
	i32.gt_u
	br_if   	4                               # 4: down to label496
# %bb.6:                                #   in Loop: Header=BB27_5 Depth=2
	local.get	3
	local.get	4
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	19
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label496
# %bb.7:                                #   in Loop: Header=BB27_5 Depth=2
	i32.const	0
	i32.load	heap_ptr
	local.get	19
	local.get	3
	i32.add 
	local.tee	20
	i32.ne  
	br_if   	4                               # 4: down to label496
# %bb.8:                                #   in Loop: Header=BB27_5 Depth=2
	i32.const	2147483647
	local.get	4
	i32.const	1
	i32.shr_u
	local.tee	21
	i32.const	1048576
	local.get	21
	i32.const	1048576
	i32.gt_u
	i32.select
	local.tee	21
	local.get	4
	i32.add 
	local.get	4
	local.get	21
	i32.const	2147483647
	i32.xor 
	i32.gt_u
	i32.select
	local.tee	4
	local.get	19
	i32.sub 
	i32.const	7
	i32.add 
	local.set	21
	local.get	20
	local.set	19
	block   	
	local.get	20
	br_if   	0                               # 0: down to label501
# %bb.9:                                #   in Loop: Header=BB27_5 Depth=2
	i32.const	__heap_base
	local.set	19
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB27_10:                              #   in Loop: Header=BB27_5 Depth=2
	end_block                               # label501:
	local.get	19
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	19
	local.get	21
	i32.const	-8
	i32.and 
	local.tee	21
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label496
# %bb.11:                               #   in Loop: Header=BB27_5 Depth=2
	block   	
	local.get	19
	local.get	21
	i32.add 
	local.tee	21
	i32.const	16
	i32.shr_u
	local.get	21
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	22
	memory.size	0
	local.tee	23
	i32.le_u
	br_if   	0                               # 0: down to label502
# %bb.12:                               #   in Loop: Header=BB27_5 Depth=2
	local.get	22
	local.get	23
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	5                               # 5: down to label496
.LBB27_13:                              #   in Loop: Header=BB27_5 Depth=2
	end_block                               # label502:
	i32.const	0
	local.get	21
	i32.store	heap_ptr
	local.get	19
	i32.eqz
	br_if   	4                               # 4: down to label496
# %bb.14:                               #   in Loop: Header=BB27_5 Depth=2
	local.get	19
	local.get	20
	i32.ne  
	br_if   	4                               # 4: down to label496
# %bb.15:                               #   in Loop: Header=BB27_5 Depth=2
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	0
	local.get	18
	local.get	3
	local.get	4
	local.get	10
	i32.const	12
	i32.add 
	local.get	10
	i32.const	8
	i32.add 
	local.get	10
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	call	encode_term_content_token_binary_row
	i32.eqz
	br_if   	0                               # 0: up to label500
.LBB27_16:                              #   in Loop: Header=BB27_4 Depth=1
	end_loop
	end_block                               # label499:
	local.get	17
	i32.const	2
	i32.shl 
	local.set	24
	local.get	10
	i32.load	4
	local.tee	25
	i32.const	-1640531535
	i32.mul 
	local.get	10
	i32.load	8
	local.tee	26
	i32.xor 
	local.tee	11
	i32.const	16
	i32.shr_u
	local.get	11
	i32.xor 
	local.get	14
	i32.and 
	local.set	27
	local.get	3
	local.get	15
	i32.add 
	local.set	28
	local.get	10
	i32.load	12
	local.tee	29
	local.get	15
	i32.sub 
	local.set	30
	i32.const	0
	local.set	31
.LBB27_17:                              #   Parent Loop BB27_4 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB27_24 Depth 3
                                        #       Child Loop BB27_27 Depth 3
	block   	
	block   	
	block   	
	loop    	                                # label506:
	local.get	6
	local.get	27
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	11
	i32.eqz
	br_if   	1                               # 1: down to label505
# %bb.18:                               #   in Loop: Header=BB27_17 Depth=2
	block   	
	local.get	11
	i32.const	-1
	i32.add 
	local.tee	32
	local.get	17
	i32.lt_u
	br_if   	0                               # 0: down to label507
# %bb.19:
	i32.const	-3
	local.set	11
	br      	7                               # 7: down to label496
.LBB27_20:                              #   in Loop: Header=BB27_17 Depth=2
	end_block                               # label507:
	block   	
	local.get	5
	local.get	32
	i32.const	4
	i32.shl 
	i32.add 
	local.tee	20
	i32.load	8
	local.get	26
	i32.ne  
	br_if   	0                               # 0: down to label508
# %bb.21:                               #   in Loop: Header=BB27_17 Depth=2
	local.get	20
	i32.load	12
	local.get	25
	i32.ne  
	br_if   	0                               # 0: down to label508
# %bb.22:                               #   in Loop: Header=BB27_17 Depth=2
	local.get	20
	i32.load	4
	local.get	30
	i32.ne  
	br_if   	0                               # 0: down to label508
# %bb.23:                               #   in Loop: Header=BB27_17 Depth=2
	i32.const	0
	local.set	11
	local.get	3
	local.get	20
	i32.load	0
	local.tee	33
	i32.add 
	local.tee	34
	local.set	20
	local.get	28
	local.set	19
	local.get	30
	local.set	21
.LBB27_24:                              #   Parent Loop BB27_4 Depth=1
                                        #     Parent Loop BB27_17 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	block   	
	loop    	                                # label510:
	block   	
	local.get	11
	i32.const	8
	i32.add 
	local.tee	18
	local.get	30
	i32.le_u
	br_if   	0                               # 0: down to label511
# %bb.25:                               #   in Loop: Header=BB27_17 Depth=2
	local.get	11
	local.get	30
	i32.lt_u
	br_if   	2                               # 2: down to label509
	br      	6                               # 6: down to label504
.LBB27_26:                              #   in Loop: Header=BB27_24 Depth=3
	end_block                               # label511:
	local.get	28
	local.get	11
	i32.add 
	local.set	22
	local.get	34
	local.get	11
	i32.add 
	local.set	23
	local.get	20
	i32.const	8
	i32.add 
	local.set	20
	local.get	19
	i32.const	8
	i32.add 
	local.set	19
	local.get	21
	i32.const	-8
	i32.add 
	local.set	21
	local.get	18
	local.set	11
	local.get	23
	i64.load	0:p2align=0
	local.get	22
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label510
	br      	2                               # 2: down to label508
.LBB27_27:                              #   Parent Loop BB27_4 Depth=1
                                        #     Parent Loop BB27_17 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	end_loop
	end_block                               # label509:
	loop    	                                # label512:
	local.get	20
	i32.load8_u	0
	local.get	19
	i32.load8_u	0
	i32.ne  
	br_if   	1                               # 1: down to label508
# %bb.28:                               #   in Loop: Header=BB27_27 Depth=3
	local.get	20
	i32.const	1
	i32.add 
	local.set	20
	local.get	19
	i32.const	1
	i32.add 
	local.set	19
	local.get	21
	i32.const	-1
	i32.add 
	local.tee	21
	i32.eqz
	br_if   	4                               # 4: down to label504
	br      	0                               # 0: up to label512
.LBB27_29:                              #   in Loop: Header=BB27_17 Depth=2
	end_loop
	end_block                               # label508:
	local.get	27
	i32.const	1
	i32.add 
	local.get	14
	i32.and 
	local.set	27
	local.get	31
	i32.const	1
	i32.add 
	local.tee	31
	local.get	7
	i32.ne  
	br_if   	0                               # 0: up to label506
.LBB27_30:                              #   in Loop: Header=BB27_4 Depth=1
	end_loop
	end_block                               # label505:
	i32.const	-3
	local.set	11
	local.get	6
	local.get	27
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	20
	i32.load	0
	br_if   	4                               # 4: down to label496
# %bb.31:                               #   in Loop: Header=BB27_4 Depth=1
	local.get	16
	i32.const	-1
	i32.eq  
	br_if   	4                               # 4: down to label496
# %bb.32:                               #   in Loop: Header=BB27_4 Depth=1
	local.get	5
	local.get	24
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	11
	local.get	25
	i32.store	12
	local.get	11
	local.get	26
	i32.store	8
	local.get	11
	local.get	30
	i32.store	4
	local.get	11
	local.get	15
	i32.store	0
	local.get	8
	local.get	24
	i32.add 
	local.get	16
	i32.store	0
	local.get	20
	local.get	17
	i32.const	1
	i32.add 
	local.tee	17
	i32.store	0
	local.get	16
	i32.const	1
	i32.add 
	local.set	16
	local.get	29
	local.set	15
	br      	1                               # 1: down to label503
.LBB27_33:                              #   in Loop: Header=BB27_4 Depth=1
	end_block                               # label504:
	local.get	5
	local.get	24
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	11
	local.get	25
	i32.store	12
	local.get	11
	local.get	26
	i32.store	8
	local.get	11
	local.get	30
	i32.store	4
	local.get	11
	local.get	33
	i32.store	0
	local.get	8
	local.get	24
	i32.add 
	local.get	8
	local.get	32
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.store	0
	local.get	10
	local.get	15
	i32.store	12
	local.get	17
	i32.const	1
	i32.add 
	local.set	17
.LBB27_34:                              #   in Loop: Header=BB27_4 Depth=1
	end_block                               # label503:
	local.get	17
	local.get	2
	i32.ne  
	br_if   	0                               # 0: up to label498
.LBB27_35:
	end_loop
	end_block                               # label497:
	local.get	9
	local.get	16
	i32.store	0
	local.get	15
	local.set	11
.LBB27_36:
	end_block                               # label496:
	local.get	10
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	11
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_and_encode_term_bank_token_binary_dedup,"",@
	.globl	parse_and_encode_term_bank_token_binary_dedup # -- Begin function parse_and_encode_term_bank_token_binary_dedup
	.type	parse_and_encode_term_bank_token_binary_dedup,@function
parse_and_encode_term_bank_token_binary_dedup: # @parse_and_encode_term_bank_token_binary_dedup
	.functype	parse_and_encode_term_bank_token_binary_dedup (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	112
	i32.sub 
	local.tee	39
	global.set	__stack_pointer
	i32.const	-1
	local.set	40
	block   	
	local.get	0
	i32x4.splat
	local.get	1
	i32x4.replace_lane	1
	local.get	2
	i32x4.replace_lane	2
	local.get	3
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	41
	i32x4.eq
	local.get	4
	i32x4.splat
	local.get	6
	i32x4.replace_lane	1
	local.get	7
	i32x4.replace_lane	2
	local.get	9
	i32x4.replace_lane	3
	local.get	41
	i32x4.eq
	i8x16.shuffle	0, 4, 8, 12, 16, 20, 24, 28, 0, 0, 0, 0, 0, 0, 0, 0
	local.get	10
	i32x4.splat
	local.get	11
	i32x4.replace_lane	1
	local.get	12
	i32x4.replace_lane	2
	local.get	13
	i32x4.replace_lane	3
	local.get	41
	i32x4.eq
	local.tee	42
	i32x4.extract_lane	0
	i8x16.replace_lane	8
	local.get	42
	i32x4.extract_lane	1
	i8x16.replace_lane	9
	local.get	42
	i32x4.extract_lane	2
	i8x16.replace_lane	10
	local.get	42
	i32x4.extract_lane	3
	i8x16.replace_lane	11
	local.get	15
	i32x4.splat
	local.get	16
	i32x4.replace_lane	1
	local.get	17
	i32x4.replace_lane	2
	local.get	18
	i32x4.replace_lane	3
	local.get	41
	i32x4.eq
	local.tee	42
	i32x4.extract_lane	0
	i8x16.replace_lane	12
	local.get	42
	i32x4.extract_lane	1
	i8x16.replace_lane	13
	local.get	42
	i32x4.extract_lane	2
	i8x16.replace_lane	14
	local.get	42
	i32x4.extract_lane	3
	i8x16.replace_lane	15
	local.tee	42
	local.get	19
	i32x4.splat
	local.get	20
	i32x4.replace_lane	1
	local.get	22
	i32x4.replace_lane	2
	local.get	23
	i32x4.replace_lane	3
	local.get	41
	i32x4.eq
	local.get	24
	i32x4.splat
	local.get	25
	i32x4.replace_lane	1
	local.get	26
	i32x4.replace_lane	2
	local.get	27
	i32x4.replace_lane	3
	local.get	41
	i32x4.eq
	i8x16.shuffle	0, 4, 8, 12, 16, 20, 24, 28, 0, 0, 0, 0, 0, 0, 0, 0
	v128.or
	local.get	42
	i8x16.shuffle	0, 1, 2, 3, 4, 5, 6, 7, 24, 25, 26, 27, 28, 29, 30, 31
	v128.any_true
	br_if   	0                               # 0: down to label513
# %bb.1:
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label513
# %bb.2:
	i32.const	-1
	local.set	40
	local.get	8
	local.get	8
	i32.const	-1
	i32.add 
	local.tee	43
	i32.and 
	br_if   	0                               # 0: down to label513
# %bb.3:
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label513
# %bb.4:
	i32.const	-1
	local.set	40
	local.get	21
	local.get	21
	i32.const	-1
	i32.add 
	local.tee	44
	i32.and 
	br_if   	0                               # 0: down to label513
# %bb.5:
	local.get	30
	i32.const	0
	i32.ne  
	local.get	31
	i32.eqz
	i32.eq  
	br_if   	0                               # 0: down to label513
# %bb.6:
	block   	
	local.get	29
	i32.const	1
	i32.and 
	br_if   	0                               # 0: down to label514
# %bb.7:
	local.get	31
	br_if   	1                               # 1: down to label513
.LBB28_8:
	end_block                               # label514:
	block   	
	local.get	29
	i32.const	8
	i32.and 
	local.tee	45
	i32.eqz
	br_if   	0                               # 0: down to label515
# %bb.9:
	local.get	34
	i32.eqz
	br_if   	1                               # 1: down to label513
# %bb.10:
	local.get	33
	i32.eqz
	br_if   	1                               # 1: down to label513
# %bb.11:
	local.get	35
	i32.eqz
	br_if   	1                               # 1: down to label513
# %bb.12:
	local.get	34
	i32.popcnt
	i32.const	1
	i32.gt_u
	br_if   	1                               # 1: down to label513
.LBB28_13:
	end_block                               # label515:
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label516
# %bb.14:
	local.get	32
	v128.const	0, 0
	v128.store	0:p2align=2
	local.get	32
	i32.const	16
	i32.add 
	i32.const	0
	i32.store	0
.LBB28_15:
	end_block                               # label516:
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
	i32.const	0
	local.get	5
	i32.store	last_content_capacity
	local.get	39
	i32.const	0
	i32.store	108
	local.get	39
	i32.const	0
	i32.store	76
	local.get	39
	i64.const	0
	i64.store	68:p2align=2
	local.get	39
	local.get	31
	i32.const	1
	local.get	31
	i32.const	1
	i32.gt_u
	i32.select
	i32.store	64
	local.get	39
	local.get	1
	i32.store	60
	local.get	39
	local.get	30
	i32.store	56
	local.get	39
	local.get	0
	i32.store	52
	local.get	28
	i32.eqz
	local.set	46
	block   	
	block   	
	local.get	39
	i32.const	52
	i32.add 
	call	next_term_bank
	local.tee	1
	i32.const	1
	i32.ge_s
	br_if   	0                               # 0: down to label518
# %bb.16:
	i32.const	0
	local.set	47
	i32.const	0
	local.set	48
	i32.const	0
	local.set	49
	i32.const	0
	local.set	50
	i32.const	0
	local.set	51
	i32.const	0
	local.set	52
	br      	1                               # 1: down to label517
.LBB28_17:
	end_block                               # label518:
	i32.const	0
	local.get	34
	i32.const	-1
	i32.add 
	local.tee	40
	local.get	40
	local.get	34
	i32.gt_u
	i32.select
	local.set	53
	local.get	2
	i32.const	-28
	i32.add 
	local.set	54
	local.get	29
	i32.const	4
	i32.and 
	local.set	55
	local.get	2
	i32.const	-68
	i32.add 
	local.set	56
	local.get	3
	i32.const	1
	i32.shl 
	local.set	57
	local.get	29
	i32.const	2
	i32.and 
	local.set	58
	local.get	0
	i32.const	1
	i32.add 
	local.set	59
	local.get	36
	i32.const	0
	i32.ne  
	local.set	60
	local.get	28
	i32.const	0
	i32.ne  
	local.set	61
	i32.const	-1
	local.set	62
	i32.const	0
	local.set	47
	i32.const	0
	local.set	52
	i32.const	0
	local.set	51
	i32.const	0
	local.set	50
	i32.const	0
	local.set	49
	i32.const	0
	local.set	48
	i32.const	0
	local.set	31
	i32.const	0
	local.set	63
.LBB28_18:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB28_41 Depth 2
                                        #     Child Loop BB28_43 Depth 2
                                        #     Child Loop BB28_48 Depth 2
                                        #     Child Loop BB28_53 Depth 2
                                        #       Child Loop BB28_59 Depth 3
                                        #       Child Loop BB28_61 Depth 3
                                        #       Child Loop BB28_64 Depth 3
                                        #       Child Loop BB28_77 Depth 3
                                        #         Child Loop BB28_83 Depth 4
                                        #         Child Loop BB28_85 Depth 4
                                        #         Child Loop BB28_88 Depth 4
                                        #     Child Loop BB28_102 Depth 2
                                        #     Child Loop BB28_121 Depth 2
                                        #     Child Loop BB28_134 Depth 2
                                        #     Child Loop BB28_148 Depth 2
                                        #     Child Loop BB28_159 Depth 2
                                        #     Child Loop BB28_171 Depth 2
                                        #     Child Loop BB28_184 Depth 2
                                        #     Child Loop BB28_190 Depth 2
                                        #     Child Loop BB28_195 Depth 2
	loop    	                                # label519:
	block   	
	local.get	49
	local.get	3
	i32.ne  
	br_if   	0                               # 0: down to label520
# %bb.19:
	local.get	12
	local.get	3
	i32.store	0
	i32.const	-4
	local.set	40
	br      	3                               # 3: down to label513
.LBB28_20:                              #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label520:
	i32.const	0
	local.set	40
	local.get	39
	i32.const	0
	i32.store	48
	local.get	39
	i32.const	-1
	i32.store	44
	i32.const	0
	local.set	1
	block   	
	local.get	55
	i32.const	0
	i32.ne  
	local.get	49
	i32.const	0
	i32.ne  
	i32.and 
	local.tee	30
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label521
# %bb.21:                               #   in Loop: Header=BB28_18 Depth=1
	block   	
	local.get	31
	i32.eqz
	br_if   	0                               # 0: down to label522
# %bb.22:                               #   in Loop: Header=BB28_18 Depth=1
	i32.const	4
	local.set	1
	local.get	39
	i32.const	44
	i32.add 
	local.set	40
	br      	1                               # 1: down to label521
.LBB28_23:                              #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label522:
	local.get	39
	i32.const	44
	i32.add 
	i32.const	0
	local.get	54
	local.get	49
	i32.const	68
	i32.mul 
	i32.add 
	i32.load	0
	i32.const	511
	i32.gt_u
	local.tee	1
	i32.select
	local.set	40
.LBB28_24:                              #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label521:
	block   	
	local.get	0
	local.get	39
	i32.load	72
	local.tee	64
	local.get	39
	i32.load	76
	local.get	2
	local.get	49
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	65
	local.get	61
	local.get	39
	i32.const	48
	i32.add 
	local.get	2
	local.get	49
	local.get	40
	local.get	1
	local.get	60
	local.get	39
	i32.const	40
	i32.add 
	call	parse_row_single_pass
	br_if   	0                               # 0: down to label523
# %bb.25:
	i32.const	-1
	local.set	40
	br      	3                               # 3: down to label513
.LBB28_26:                              #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label523:
	local.get	39
	i32.load	44
	local.set	66
	block   	
	local.get	37
	i32.eqz
	br_if   	0                               # 0: down to label524
# %bb.27:                               #   in Loop: Header=BB28_18 Depth=1
	local.get	37
	local.get	49
	i32.const	2
	i32.shl 
	i32.add 
	local.get	66
	i32.store	0
.LBB28_28:                              #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label524:
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label525
# %bb.29:                               #   in Loop: Header=BB28_18 Depth=1
	local.get	66
	i32.const	-1
	i32.eq  
	br_if   	0                               # 0: down to label525
# %bb.30:                               #   in Loop: Header=BB28_18 Depth=1
	local.get	32
	local.get	32
	i32.load	4
	i32.const	1
	i32.add 
	i32.store	4
.LBB28_31:                              #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label525:
	block   	
	block   	
	local.get	30
	br_if   	0                               # 0: down to label527
# %bb.32:                               #   in Loop: Header=BB28_18 Depth=1
	local.get	31
	local.set	67
	br      	1                               # 1: down to label526
.LBB28_33:                              #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label527:
	i32.const	4
	local.set	67
	local.get	66
	i32.const	-1
	i32.ne  
	br_if   	0                               # 0: down to label526
# %bb.34:                               #   in Loop: Header=BB28_18 Depth=1
	i32.const	0
	local.get	31
	i32.const	-1
	i32.add 
	local.tee	40
	local.get	40
	local.get	31
	i32.gt_u
	i32.select
	local.set	67
.LBB28_35:                              #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label526:
	local.get	65
	i32.load	56
	local.set	68
	local.get	39
	local.get	65
	i32.load	0
	local.tee	30
	i32.store	36
	local.get	39
	local.get	65
	i32.load	8
	local.tee	1
	i32.store	32
	local.get	39
	local.get	65
	i32.load	4
	local.tee	36
	i32.store	28
	local.get	39
	local.get	65
	i32.load	12
	local.tee	40
	i32.store	24
	i32.const	0
	local.set	69
	local.get	39
	i32.const	0
	i32.store	16
	local.get	39
	i32.const	0
	i32.store	12
	block   	
	local.get	40
	i32.const	2
	i32.ne  
	br_if   	0                               # 0: down to label528
# %bb.36:                               #   in Loop: Header=BB28_18 Depth=1
	local.get	0
	local.get	1
	i32.add 
	local.tee	31
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label528
# %bb.37:                               #   in Loop: Header=BB28_18 Depth=1
	local.get	31
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	69
.LBB28_38:                              #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label528:
	block   	
	local.get	69
	br_if   	0                               # 0: down to label529
# %bb.39:                               #   in Loop: Header=BB28_18 Depth=1
	local.get	36
	local.get	40
	i32.ne  
	br_if   	0                               # 0: down to label529
# %bb.40:                               #   in Loop: Header=BB28_18 Depth=1
	i32.const	0
	local.set	31
	local.get	0
	local.get	30
	i32.add 
	local.tee	70
	local.set	40
	local.get	0
	local.get	1
	i32.add 
	local.tee	71
	local.set	1
.LBB28_41:                              #   Parent Loop BB28_18 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label530:
	block   	
	local.get	36
	local.get	31
	i32.add 
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label531
# %bb.42:                               #   in Loop: Header=BB28_18 Depth=1
	i32.const	0
	local.set	30
	local.get	36
	local.set	28
.LBB28_43:                              #   Parent Loop BB28_18 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label533:
	block   	
	local.get	31
	local.get	28
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label534
# %bb.44:                               #   in Loop: Header=BB28_18 Depth=1
	local.get	30
	local.get	31
	i32.sub 
	local.tee	40
	local.get	36
	i32.lt_u
	br_if   	2                               # 2: down to label532
# %bb.45:                               #   in Loop: Header=BB28_18 Depth=1
	i32.const	1
	local.set	69
	br      	5                               # 5: down to label529
.LBB28_46:                              #   in Loop: Header=BB28_43 Depth=2
	end_block                               # label534:
	local.get	1
	local.get	30
	i32.add 
	local.set	72
	local.get	40
	local.get	30
	i32.add 
	local.set	73
	local.get	28
	i32.const	-8
	i32.add 
	local.set	28
	local.get	30
	i32.const	8
	i32.add 
	local.set	30
	local.get	73
	i64.load	0:p2align=0
	local.get	72
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label533
# %bb.47:                               #   in Loop: Header=BB28_18 Depth=1
	end_loop
	i32.const	0
	local.set	69
	br      	3                               # 3: down to label529
.LBB28_48:                              #   Parent Loop BB28_18 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	end_block                               # label532:
	loop    	                                # label535:
	local.get	70
	local.get	40
	i32.add 
	i32.load8_u	0
	local.tee	1
	local.get	71
	local.get	40
	i32.add 
	i32.load8_u	0
	local.tee	31
	i32.eq  
	local.set	69
	local.get	1
	local.get	31
	i32.ne  
	br_if   	3                               # 3: down to label529
# %bb.49:                               #   in Loop: Header=BB28_48 Depth=2
	local.get	40
	i32.const	1
	i32.add 
	local.tee	40
	local.get	36
	i32.lt_u
	br_if   	0                               # 0: up to label535
	br      	3                               # 3: down to label529
.LBB28_50:                              #   in Loop: Header=BB28_41 Depth=2
	end_loop
	end_block                               # label531:
	local.get	40
	i32.const	16
	i32.add 
	local.set	30
	local.get	1
	i32.const	16
	i32.add 
	local.set	28
	local.get	40
	v128.load	0:p2align=0
	local.set	41
	local.get	1
	v128.load	0:p2align=0
	local.set	42
	local.get	40
	i32.const	32
	i32.add 
	local.set	40
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	31
	i32.const	-32
	i32.add 
	local.set	31
	local.get	28
	v128.load	0:p2align=0
	local.get	30
	v128.load	0:p2align=0
	v128.xor
	local.get	42
	local.get	41
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label530
# %bb.51:                               #   in Loop: Header=BB28_18 Depth=1
	end_loop
	i32.const	0
	local.set	69
.LBB28_52:                              #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label529:
	local.get	68
	local.get	46
	i32.or  
	local.set	46
	local.get	2
	local.get	49
	i32.const	-1
	i32.add 
	local.tee	74
	i32.const	68
	i32.mul 
	i32.add 
	local.set	75
	i32.const	0
	local.set	73
	local.get	39
	i32.const	36
	i32.add 
	local.set	40
	local.get	39
	i32.const	28
	i32.add 
	local.set	1
	local.get	39
	i32.const	16
	i32.add 
	local.set	76
	i32.const	1
	local.set	77
	local.get	39
	i32.load	40
	local.set	78
.LBB28_53:                              #   Parent Loop BB28_18 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB28_59 Depth 3
                                        #       Child Loop BB28_61 Depth 3
                                        #       Child Loop BB28_64 Depth 3
                                        #       Child Loop BB28_77 Depth 3
                                        #         Child Loop BB28_83 Depth 4
                                        #         Child Loop BB28_85 Depth 4
                                        #         Child Loop BB28_88 Depth 4
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	loop    	                                # label543:
	block   	
	local.get	69
	local.get	73
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label544
# %bb.54:                               #   in Loop: Header=BB28_18 Depth=1
	local.get	39
	local.get	39
	i32.load	16
	i32.store	12
	br      	2                               # 2: down to label542
.LBB28_55:                              #   in Loop: Header=BB28_53 Depth=2
	end_block                               # label544:
	local.get	1
	i32.load	0
	local.tee	68
	i32.const	-2
	i32.add 
	local.set	36
	local.get	40
	i32.load	0
	local.set	79
	block   	
	block   	
	block   	
	block   	
	local.get	49
	i32.eqz
	br_if   	0                               # 0: down to label548
# %bb.56:                               #   in Loop: Header=BB28_53 Depth=2
	local.get	36
	i32.const	32
	i32.gt_u
	br_if   	0                               # 0: down to label548
# %bb.57:                               #   in Loop: Header=BB28_53 Depth=2
	local.get	68
	local.get	75
	i32.const	4
	i32.const	12
	local.get	77
	i32.const	1
	i32.and 
	local.tee	80
	i32.select
	i32.add 
	i32.load	0
	i32.ne  
	br_if   	1                               # 1: down to label547
# %bb.58:                               #   in Loop: Header=BB28_53 Depth=2
	local.get	0
	local.get	79
	i32.add 
	local.set	28
	local.get	59
	local.get	79
	i32.add 
	local.set	70
	local.get	0
	local.get	75
	i32.const	0
	i32.const	8
	local.get	80
	i32.select
	i32.add 
	i32.load	0
	local.tee	40
	i32.add 
	local.set	72
	local.get	59
	local.get	40
	i32.add 
	local.set	71
	i32.const	17
	local.set	1
	local.get	36
	local.set	40
.LBB28_59:                              #   Parent Loop BB28_18 Depth=1
                                        #     Parent Loop BB28_53 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label549:
	block   	
	local.get	40
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label550
# %bb.60:                               #   in Loop: Header=BB28_53 Depth=2
	local.get	1
	i32.const	-17
	i32.add 
	local.set	1
.LBB28_61:                              #   Parent Loop BB28_18 Depth=1
                                        #     Parent Loop BB28_53 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	block   	
	loop    	                                # label552:
	block   	
	local.get	40
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label553
# %bb.62:                               #   in Loop: Header=BB28_53 Depth=2
	local.get	1
	local.get	36
	i32.lt_u
	br_if   	2                               # 2: down to label551
	br      	7                               # 7: down to label546
.LBB28_63:                              #   in Loop: Header=BB28_61 Depth=3
	end_block                               # label553:
	local.get	71
	local.get	1
	i32.add 
	local.set	31
	local.get	70
	local.get	1
	i32.add 
	local.set	30
	local.get	40
	i32.const	-8
	i32.add 
	local.set	40
	local.get	1
	i32.const	8
	i32.add 
	local.set	1
	local.get	30
	i64.load	0:p2align=0
	local.get	31
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label552
	br      	4                               # 4: down to label548
.LBB28_64:                              #   Parent Loop BB28_18 Depth=1
                                        #     Parent Loop BB28_53 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	end_loop
	end_block                               # label551:
	loop    	                                # label554:
	local.get	70
	local.get	1
	i32.add 
	i32.load8_u	0
	local.get	71
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	3                               # 3: down to label548
# %bb.65:                               #   in Loop: Header=BB28_64 Depth=3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	local.get	36
	i32.ge_u
	br_if   	5                               # 5: down to label546
	br      	0                               # 0: up to label554
.LBB28_66:                              #   in Loop: Header=BB28_59 Depth=3
	end_loop
	end_block                               # label550:
	local.get	28
	local.get	1
	i32.add 
	local.set	31
	local.get	72
	local.get	1
	i32.add 
	local.set	30
	local.get	40
	i32.const	-32
	i32.add 
	local.set	40
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	30
	v128.load	0:p2align=0
	local.get	31
	v128.load	0:p2align=0
	v128.xor
	local.get	30
	i32.const	-16
	i32.add 
	v128.load	0:p2align=0
	local.get	31
	i32.const	-16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label549
.LBB28_67:                              #   in Loop: Header=BB28_53 Depth=2
	end_loop
	end_block                               # label548:
	local.get	68
	i32.const	2
	i32.lt_u
	br_if   	5                               # 5: down to label541
.LBB28_68:                              #   in Loop: Header=BB28_53 Depth=2
	end_block                               # label547:
	block   	
	block   	
	local.get	78
	local.get	73
	i32.shr_u
	i32.const	1
	i32.and 
	br_if   	0                               # 0: down to label556
# %bb.69:                               #   in Loop: Header=BB28_53 Depth=2
	local.get	79
	i32.const	1
	i32.add 
	local.set	40
	local.get	0
	local.set	81
	br      	1                               # 1: down to label555
.LBB28_70:                              #   in Loop: Header=BB28_53 Depth=2
	end_block                               # label556:
	local.get	58
	i32.eqz
	br_if   	5                               # 5: down to label541
# %bb.71:                               #   in Loop: Header=BB28_53 Depth=2
	local.get	0
	local.get	79
	i32.add 
	local.get	68
	local.get	13
	local.get	50
	i32.add 
	local.get	14
	local.get	50
	i32.sub 
	call	decode_escaped_key
	local.tee	36
	i32.const	0
	i32.lt_s
	br_if   	5                               # 5: down to label541
# %bb.72:                               #   in Loop: Header=BB28_53 Depth=2
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label557
# %bb.73:                               #   in Loop: Header=BB28_53 Depth=2
	local.get	32
	local.get	32
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
.LBB28_74:                              #   in Loop: Header=BB28_53 Depth=2
	end_block                               # label557:
	local.get	50
	local.set	40
	local.get	13
	local.set	81
.LBB28_75:                              #   in Loop: Header=BB28_53 Depth=2
	end_block                               # label555:
	local.get	36
	i32.const	65535
	i32.gt_u
	br_if   	4                               # 4: down to label541
# %bb.76:                               #   in Loop: Header=BB28_53 Depth=2
	local.get	81
	local.get	40
	i32.add 
	local.tee	79
	local.get	36
	i32.const	-2128831035
	call	hash_content_xxh32
	local.tee	82
	local.get	36
	i32.const	-2048144789
	i32.mul 
	i32.xor 
	local.tee	40
	i32.const	16
	i32.shr_u
	local.get	40
	i32.xor 
	local.get	44
	i32.and 
	local.set	70
	i32.const	0
	local.set	68
.LBB28_77:                              #   Parent Loop BB28_18 Depth=1
                                        #     Parent Loop BB28_53 Depth=2
                                        # =>    This Loop Header: Depth=3
                                        #         Child Loop BB28_83 Depth 4
                                        #         Child Loop BB28_85 Depth 4
                                        #         Child Loop BB28_88 Depth 4
	block   	
	loop    	                                # label559:
	local.get	20
	local.get	70
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	40
	i32.eqz
	br_if   	1                               # 1: down to label558
# %bb.78:                               #   in Loop: Header=BB28_77 Depth=3
	block   	
	local.get	40
	i32.const	-1
	i32.add 
	local.tee	71
	local.get	51
	i32.lt_u
	br_if   	0                               # 0: down to label560
# %bb.79:
	i32.const	-3
	local.set	40
	br      	15                              # 15: down to label513
.LBB28_80:                              #   in Loop: Header=BB28_77 Depth=3
	end_block                               # label560:
	block   	
	local.get	17
	local.get	71
	i32.const	2
	i32.shl 
	local.tee	40
	i32.add 
	i32.load	0
	local.get	82
	i32.ne  
	br_if   	0                               # 0: down to label561
# %bb.81:                               #   in Loop: Header=BB28_77 Depth=3
	local.get	36
	local.get	15
	local.get	71
	i32.const	1
	i32.shl 
	i32.add 
	i32.load16_u	0
	i32.ne  
	br_if   	0                               # 0: down to label561
# %bb.82:                               #   in Loop: Header=BB28_77 Depth=3
	i32.const	0
	local.set	31
	local.get	13
	local.get	16
	local.get	40
	i32.add 
	i32.load	0
	i32.add 
	local.tee	80
	local.set	40
	local.get	79
	local.set	1
.LBB28_83:                              #   Parent Loop BB28_18 Depth=1
                                        #     Parent Loop BB28_53 Depth=2
                                        #       Parent Loop BB28_77 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	loop    	                                # label562:
	block   	
	local.get	36
	local.get	31
	i32.add 
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label563
# %bb.84:                               #   in Loop: Header=BB28_77 Depth=3
	i32.const	0
	local.set	30
	local.get	36
	local.set	28
.LBB28_85:                              #   Parent Loop BB28_18 Depth=1
                                        #     Parent Loop BB28_53 Depth=2
                                        #       Parent Loop BB28_77 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	block   	
	loop    	                                # label565:
	block   	
	local.get	31
	local.get	28
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label566
# %bb.86:                               #   in Loop: Header=BB28_77 Depth=3
	local.get	30
	local.get	31
	i32.sub 
	local.tee	40
	local.get	36
	i32.lt_u
	br_if   	2                               # 2: down to label564
	br      	9                               # 9: down to label545
.LBB28_87:                              #   in Loop: Header=BB28_85 Depth=4
	end_block                               # label566:
	local.get	1
	local.get	30
	i32.add 
	local.set	72
	local.get	40
	local.get	30
	i32.add 
	local.set	73
	local.get	28
	i32.const	-8
	i32.add 
	local.set	28
	local.get	30
	i32.const	8
	i32.add 
	local.set	30
	local.get	73
	i64.load	0:p2align=0
	local.get	72
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label565
	br      	4                               # 4: down to label561
.LBB28_88:                              #   Parent Loop BB28_18 Depth=1
                                        #     Parent Loop BB28_53 Depth=2
                                        #       Parent Loop BB28_77 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	end_loop
	end_block                               # label564:
	loop    	                                # label567:
	local.get	80
	local.get	40
	i32.add 
	i32.load8_u	0
	local.get	79
	local.get	40
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	3                               # 3: down to label561
# %bb.89:                               #   in Loop: Header=BB28_88 Depth=4
	local.get	40
	i32.const	1
	i32.add 
	local.tee	40
	local.get	36
	i32.ge_u
	br_if   	7                               # 7: down to label545
	br      	0                               # 0: up to label567
.LBB28_90:                              #   in Loop: Header=BB28_83 Depth=4
	end_loop
	end_block                               # label563:
	local.get	40
	i32.const	16
	i32.add 
	local.set	30
	local.get	1
	i32.const	16
	i32.add 
	local.set	28
	local.get	40
	v128.load	0:p2align=0
	local.set	41
	local.get	1
	v128.load	0:p2align=0
	local.set	42
	local.get	40
	i32.const	32
	i32.add 
	local.set	40
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	31
	i32.const	-32
	i32.add 
	local.set	31
	local.get	28
	v128.load	0:p2align=0
	local.get	30
	v128.load	0:p2align=0
	v128.xor
	local.get	42
	local.get	41
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label562
.LBB28_91:                              #   in Loop: Header=BB28_77 Depth=3
	end_loop
	end_block                               # label561:
	local.get	70
	i32.const	1
	i32.add 
	local.get	44
	i32.and 
	local.set	70
	local.get	68
	i32.const	1
	i32.add 
	local.tee	68
	local.get	21
	i32.ne  
	br_if   	0                               # 0: up to label559
.LBB28_92:                              #   in Loop: Header=BB28_53 Depth=2
	end_loop
	end_block                               # label558:
	local.get	51
	local.get	57
	i32.ge_u
	br_if   	4                               # 4: down to label541
# %bb.93:                               #   in Loop: Header=BB28_53 Depth=2
	local.get	20
	local.get	70
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	40
	i32.load	0
	br_if   	4                               # 4: down to label541
# %bb.94:                               #   in Loop: Header=BB28_53 Depth=2
	local.get	36
	local.get	50
	i32.add 
	local.tee	1
	local.get	14
	i32.gt_u
	br_if   	4                               # 4: down to label541
# %bb.95:                               #   in Loop: Header=BB28_53 Depth=2
	block   	
	local.get	81
	local.get	13
	i32.eq  
	br_if   	0                               # 0: down to label568
# %bb.96:                               #   in Loop: Header=BB28_53 Depth=2
	local.get	13
	local.get	50
	i32.add 
	local.get	79
	local.get	36
	call	copy_valid_utf8
	i32.eqz
	br_if   	5                               # 5: down to label541
.LBB28_97:                              #   in Loop: Header=BB28_53 Depth=2
	end_block                               # label568:
	local.get	16
	local.get	51
	i32.const	2
	i32.shl 
	local.tee	31
	i32.add 
	local.get	50
	i32.store	0
	local.get	17
	local.get	31
	i32.add 
	local.get	82
	i32.store	0
	local.get	15
	local.get	51
	i32.const	1
	i32.shl 
	i32.add 
	local.get	36
	i32.store16	0
	local.get	40
	local.get	51
	i32.const	1
	i32.add 
	local.tee	31
	i32.store	0
	local.get	51
	local.set	71
	local.get	1
	local.set	50
	local.get	31
	local.set	51
	br      	1                               # 1: down to label545
.LBB28_98:                              #   in Loop: Header=BB28_53 Depth=2
	end_block                               # label546:
	local.get	18
	local.get	19
	local.get	80
	i32.select
	local.get	74
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.set	71
.LBB28_99:                              #   in Loop: Header=BB28_53 Depth=2
	end_block                               # label545:
	local.get	76
	local.get	71
	i32.store	0
	i32.const	1
	local.set	73
	local.get	77
	i32.const	1
	i32.and 
	local.set	31
	local.get	39
	i32.const	32
	i32.add 
	local.set	40
	local.get	39
	i32.const	24
	i32.add 
	local.set	1
	local.get	39
	i32.const	12
	i32.add 
	local.set	76
	i32.const	0
	local.set	77
	local.get	31
	br_if   	0                               # 0: up to label543
.LBB28_100:                             #   in Loop: Header=BB28_18 Depth=1
	end_loop
	end_block                               # label542:
	local.get	18
	local.get	49
	i32.const	2
	i32.shl 
	local.tee	72
	i32.add 
	local.get	39
	i32.load	16
	i32.store	0
	local.get	19
	local.get	72
	i32.add 
	local.get	39
	i32.load	12
	i32.store	0
	local.get	24
	local.get	49
	i32.add 
	local.get	69
	i32.store8	0
	local.get	65
	i32.load	32
	local.tee	36
	local.get	64
	i32.ge_u
	br_if   	0                               # 0: down to label541
# %bb.101:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	36
	local.set	31
.LBB28_102:                             #   Parent Loop BB28_18 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label570:
	block   	
	local.get	64
	local.get	31
	local.tee	40
	i32.ne  
	br_if   	0                               # 0: down to label571
# %bb.103:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	64
	local.set	40
	br      	2                               # 2: down to label569
.LBB28_104:                             #   in Loop: Header=BB28_102 Depth=2
	end_block                               # label571:
	block   	
	block   	
	local.get	0
	local.get	40
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	-10
	i32.add 
	br_table 	{3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0} # 1: down to label572
                                        # 3: down to label569
                                        # 0: down to label573
.LBB28_105:                             #   in Loop: Header=BB28_102 Depth=2
	end_block                               # label573:
	local.get	1
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label569
# %bb.106:                              #   in Loop: Header=BB28_102 Depth=2
	local.get	1
	i32.const	125
	i32.eq  
	br_if   	2                               # 2: down to label569
.LBB28_107:                             #   in Loop: Header=BB28_102 Depth=2
	end_block                               # label572:
	local.get	40
	i32.const	1
	i32.add 
	local.set	31
	local.get	1
	i32.const	9
	i32.ne  
	br_if   	0                               # 0: up to label570
.LBB28_108:                             #   in Loop: Header=BB28_18 Depth=1
	end_loop
	end_block                               # label569:
	local.get	40
	local.get	36
	i32.eq  
	br_if   	0                               # 0: down to label541
# %bb.109:                              #   in Loop: Header=BB28_18 Depth=1
	block   	
	block   	
	block   	
	local.get	40
	local.get	36
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label576
# %bb.110:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	0
	local.get	36
	i32.add 
	local.tee	1
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label576
# %bb.111:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	1
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label576
# %bb.112:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	1
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label576
# %bb.113:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	1
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label575
.LBB28_114:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label576:
	i32.const	1
	local.set	73
	local.get	36
	local.set	31
	block   	
	local.get	40
	local.get	36
	i32.le_u
	br_if   	0                               # 0: down to label577
# %bb.115:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	0
	local.get	36
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	45
	i32.ne  
	local.set	73
	local.get	36
	local.get	1
	i32.const	45
	i32.eq  
	i32.add 
	local.set	31
.LBB28_116:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label577:
	local.get	40
	local.get	31
	i32.le_u
	br_if   	2                               # 2: down to label541
# %bb.117:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	0
	local.get	31
	i32.add 
	local.tee	1
	i32.load8_u	0
	local.tee	30
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	246
	i32.lt_u
	br_if   	2                               # 2: down to label541
# %bb.118:                              #   in Loop: Header=BB28_18 Depth=1
	block   	
	local.get	31
	i32.const	1
	i32.add 
	local.get	40
	i32.ge_u
	br_if   	0                               # 0: down to label578
# %bb.119:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	30
	i32.const	255
	i32.and 
	i32.const	48
	i32.eq  
	br_if   	3                               # 3: down to label541
.LBB28_120:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label578:
	i32.const	2147483647
	i32.const	-2147483648
	local.get	73
	i32.select
	local.set	28
	local.get	40
	local.get	31
	i32.sub 
	local.set	30
	i32.const	0
	local.set	40
.LBB28_121:                             #   Parent Loop BB28_18 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label579:
	local.get	1
	i32.load8_u	0
	local.tee	31
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	246
	i32.lt_u
	br_if   	3                               # 3: down to label541
# %bb.122:                              #   in Loop: Header=BB28_121 Depth=2
	local.get	40
	local.get	28
	local.get	31
	i32.const	-48
	i32.add 
	local.tee	31
	i32.sub 
	i32.const	10
	i32.div_u
	i32.gt_u
	br_if   	3                               # 3: down to label541
# %bb.123:                              #   in Loop: Header=BB28_121 Depth=2
	local.get	1
	i32.const	1
	i32.add 
	local.set	1
	local.get	31
	local.get	40
	i32.const	10
	i32.mul 
	i32.add 
	local.set	40
	local.get	30
	i32.const	-1
	i32.add 
	local.tee	30
	br_if   	0                               # 0: up to label579
# %bb.124:                              #   in Loop: Header=BB28_18 Depth=1
	end_loop
	local.get	40
	i32.const	0
	local.get	40
	i32.sub 
	local.get	73
	i32.select
	local.tee	40
	br_if   	1                               # 1: down to label574
# %bb.125:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	0
	local.get	36
	i32.add 
	i32.load8_u	0
	i32.const	45
	i32.eq  
	br_if   	2                               # 2: down to label541
.LBB28_126:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label575:
	i32.const	0
	local.set	40
.LBB28_127:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label574:
	local.get	25
	local.get	72
	i32.add 
	local.get	40
	i32.store	0
	i32.const	-1
	local.set	40
	local.get	39
	i32.const	-1
	i32.store	8
	block   	
	local.get	65
	i32.load	44
	local.tee	1
	i32.const	-1
	i32.eq  
	br_if   	0                               # 0: down to label580
# %bb.128:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	39
	i32.const	0
	i32.store	4
	local.get	0
	local.get	64
	local.get	1
	local.get	39
	i32.const	4
	i32.add 
	call	scan_scalar_span
	i32.eqz
	br_if   	1                               # 1: down to label541
# %bb.129:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	0
	local.get	1
	local.get	39
	i32.load	4
	i32.const	-1
	local.get	39
	i32.const	8
	i32.add 
	call	parse_int32_token
	i32.eqz
	br_if   	1                               # 1: down to label541
# %bb.130:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	39
	i32.load	8
	local.set	40
.LBB28_131:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label580:
	local.get	26
	local.get	72
	i32.add 
	local.get	40
	i32.store	0
	local.get	45
	i32.eqz
	br_if   	1                               # 1: down to label540
# %bb.132:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	35
	local.get	72
	i32.add 
	local.get	0
	local.get	65
	call	raw_term_content_hash
	local.tee	30
	i32.store	0
	local.get	34
	i32.eqz
	br_if   	4                               # 4: down to label537
# %bb.133:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	34
	local.set	1
	local.get	30
	local.set	40
.LBB28_134:                             #   Parent Loop BB28_18 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label581:
	block   	
	local.get	33
	local.get	40
	local.get	53
	i32.and 
	local.tee	31
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	28
	i32.load	0
	local.tee	40
	br_if   	0                               # 0: down to label582
# %bb.135:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	28
	local.get	49
	i32.const	1
	i32.add 
	i32.store	0
	br      	6                               # 6: down to label537
.LBB28_136:                             #   in Loop: Header=BB28_134 Depth=2
	end_block                               # label582:
	block   	
	local.get	40
	i32.const	-1
	i32.add 
	local.tee	40
	local.get	49
	i32.lt_u
	br_if   	0                               # 0: down to label583
# %bb.137:
	i32.const	-3
	local.set	40
	br      	10                              # 10: down to label513
.LBB28_138:                             #   in Loop: Header=BB28_134 Depth=2
	end_block                               # label583:
	block   	
	local.get	35
	local.get	40
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.get	30
	i32.ne  
	br_if   	0                               # 0: down to label584
# %bb.139:                              #   in Loop: Header=BB28_134 Depth=2
	local.get	0
	local.get	65
	local.get	2
	local.get	40
	i32.const	68
	i32.mul 
	i32.add 
	local.get	40
	local.get	66
	i32.eq  
	call	raw_term_content_tokens_equal
	i32.eqz
	br_if   	0                               # 0: down to label584
# %bb.140:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	32
	i32.eqz
	br_if   	4                               # 4: down to label539
# %bb.141:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	32
	local.get	32
	i32.load	8
	i32.const	1
	i32.add 
	i32.store	8
	br      	4                               # 4: down to label539
.LBB28_142:                             #   in Loop: Header=BB28_134 Depth=2
	end_block                               # label584:
	local.get	31
	i32.const	1
	i32.add 
	local.set	40
	local.get	1
	i32.const	-1
	i32.add 
	local.tee	1
	br_if   	0                               # 0: up to label581
	br      	5                               # 5: down to label537
.LBB28_143:
	end_loop
	end_block                               # label541:
	local.get	12
	local.get	49
	i32.store	0
	i32.const	-5
	local.set	40
	br      	7                               # 7: down to label513
.LBB28_144:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label540:
	block   	
	local.get	66
	i32.const	-1
	i32.eq  
	br_if   	0                               # 0: down to label585
# %bb.145:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	0
	local.get	65
	local.get	2
	local.get	66
	i32.const	68
	i32.mul 
	i32.add 
	i32.const	1
	call	raw_term_content_tokens_equal
	i32.eqz
	br_if   	0                               # 0: down to label585
# %bb.146:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	39
	i32.const	80
	i32.add 
	local.get	49
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	local.get	39
	i32.const	80
	i32.add 
	local.get	66
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	i32.load	0
	i32.store	0
	local.get	66
	local.set	40
	br      	1                               # 1: down to label539
.LBB28_147:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label585:
	local.get	0
	local.get	65
	call	raw_term_content_quick_signature
	local.set	30
	local.get	56
	local.set	1
	local.get	62
	local.set	40
	local.get	49
	i32.const	0
	local.get	49
	i32.const	-4
	i32.add 
	local.tee	31
	local.get	31
	local.get	49
	i32.gt_u
	i32.select
	local.tee	28
	i32.le_u
	br_if   	1                               # 1: down to label538
.LBB28_148:                             #   Parent Loop BB28_18 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label587:
	block   	
	local.get	39
	i32.const	80
	i32.add 
	local.get	40
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	i32.load	0
	local.get	30
	i32.ne  
	br_if   	0                               # 0: down to label588
# %bb.149:                              #   in Loop: Header=BB28_148 Depth=2
	local.get	0
	local.get	65
	local.get	1
	local.get	66
	local.get	40
	i32.eq  
	call	raw_term_content_tokens_equal
	br_if   	2                               # 2: down to label586
.LBB28_150:                             #   in Loop: Header=BB28_148 Depth=2
	end_block                               # label588:
	local.get	1
	i32.const	-68
	i32.add 
	local.set	1
	local.get	40
	local.get	28
	i32.gt_u
	local.set	31
	local.get	40
	i32.const	-1
	i32.add 
	local.set	40
	local.get	31
	i32.eqz
	br_if   	3                               # 3: down to label538
	br      	0                               # 0: up to label587
.LBB28_151:                             #   in Loop: Header=BB28_18 Depth=1
	end_loop
	end_block                               # label586:
	local.get	39
	i32.const	80
	i32.add 
	local.get	49
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	local.get	30
	i32.store	0
.LBB28_152:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label539:
	block   	
	block   	
	local.get	55
	br_if   	0                               # 0: down to label590
# %bb.153:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	67
	local.set	31
	br      	1                               # 1: down to label589
.LBB28_154:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label590:
	i32.const	4
	local.set	31
	local.get	63
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label589
# %bb.155:                              #   in Loop: Header=BB28_18 Depth=1
	i32.const	4
	local.get	67
	local.get	63
	i32.const	3
	i32.eq  
	i32.select
	local.set	31
	local.get	63
	i32.const	1
	i32.add 
	local.set	63
.LBB28_156:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label589:
	local.get	6
	local.get	72
	i32.const	2
	i32.shl 
	i32.add 
	local.get	6
	local.get	40
	i32.const	4
	i32.shl 
	i32.add 
	v128.load	0:p2align=2
	v128.store	0:p2align=2
	local.get	9
	local.get	72
	i32.add 
	local.get	9
	local.get	40
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.store	0
	local.get	48
	i32.const	1
	i32.add 
	local.set	48
	br      	2                               # 2: down to label536
.LBB28_157:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label538:
	local.get	39
	i32.const	80
	i32.add 
	local.get	49
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	local.get	30
	i32.store	0
.LBB28_158:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label537:
	local.get	39
	i32.const	0
	i32.store	4
	local.get	39
	i32.const	0
	i32.store	0
	block   	
	local.get	0
	local.get	65
	local.get	4
	local.get	5
	local.get	39
	i32.const	108
	i32.add 
	local.get	39
	i32.const	4
	i32.add 
	local.get	39
	local.get	29
	local.get	32
	call	encode_term_content_token_binary_row
	br_if   	0                               # 0: down to label591
.LBB28_159:                             #   Parent Loop BB28_18 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label592:
	local.get	39
	local.get	47
	i32.store	108
	i32.const	-2
	local.set	40
	local.get	5
	i32.const	2147483646
	i32.gt_u
	br_if   	5                               # 5: down to label513
# %bb.160:                              #   in Loop: Header=BB28_159 Depth=2
	local.get	4
	local.get	5
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	31
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	5                               # 5: down to label513
# %bb.161:                              #   in Loop: Header=BB28_159 Depth=2
	i32.const	0
	i32.load	heap_ptr
	local.get	31
	local.get	4
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	5                               # 5: down to label513
# %bb.162:                              #   in Loop: Header=BB28_159 Depth=2
	i32.const	2147483647
	local.get	5
	i32.const	1
	i32.shr_u
	local.tee	30
	i32.const	1048576
	local.get	30
	i32.const	1048576
	i32.gt_u
	i32.select
	local.tee	30
	local.get	5
	i32.add 
	local.get	5
	local.get	30
	i32.const	2147483647
	i32.xor 
	i32.gt_u
	i32.select
	local.tee	5
	local.get	31
	i32.sub 
	i32.const	7
	i32.add 
	local.set	30
	local.get	1
	local.set	31
	block   	
	local.get	1
	br_if   	0                               # 0: down to label593
# %bb.163:                              #   in Loop: Header=BB28_159 Depth=2
	i32.const	__heap_base
	local.set	31
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB28_164:                             #   in Loop: Header=BB28_159 Depth=2
	end_block                               # label593:
	local.get	31
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	31
	local.get	30
	i32.const	-8
	i32.and 
	local.tee	30
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	5                               # 5: down to label513
# %bb.165:                              #   in Loop: Header=BB28_159 Depth=2
	block   	
	local.get	31
	local.get	30
	i32.add 
	local.tee	30
	i32.const	16
	i32.shr_u
	local.get	30
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	28
	memory.size	0
	local.tee	36
	i32.le_u
	br_if   	0                               # 0: down to label594
# %bb.166:                              #   in Loop: Header=BB28_159 Depth=2
	local.get	28
	local.get	36
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	6                               # 6: down to label513
.LBB28_167:                             #   in Loop: Header=BB28_159 Depth=2
	end_block                               # label594:
	i32.const	0
	local.get	30
	i32.store	heap_ptr
	local.get	31
	i32.eqz
	br_if   	5                               # 5: down to label513
# %bb.168:                              #   in Loop: Header=BB28_159 Depth=2
	local.get	31
	local.get	1
	i32.ne  
	br_if   	5                               # 5: down to label513
# %bb.169:                              #   in Loop: Header=BB28_159 Depth=2
	i32.const	0
	local.get	5
	i32.store	last_content_capacity
	local.get	0
	local.get	65
	local.get	4
	local.get	5
	local.get	39
	i32.const	108
	i32.add 
	local.get	39
	i32.const	4
	i32.add 
	local.get	39
	local.get	29
	local.get	32
	call	encode_term_content_token_binary_row
	i32.eqz
	br_if   	0                               # 0: up to label592
.LBB28_170:                             #   in Loop: Header=BB28_18 Depth=1
	end_loop
	end_block                               # label591:
	local.get	39
	i32.load	0
	local.tee	73
	i32.const	-1640531535
	i32.mul 
	local.get	39
	i32.load	4
	local.tee	28
	i32.xor 
	local.tee	40
	i32.const	16
	i32.shr_u
	local.get	40
	i32.xor 
	local.get	43
	i32.and 
	local.set	1
	local.get	39
	i32.load	108
	local.tee	70
	local.get	47
	i32.sub 
	local.set	36
	local.get	8
	local.set	31
.LBB28_171:                             #   Parent Loop BB28_18 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	block   	
	block   	
	block   	
	loop    	                                # label600:
	local.get	7
	local.get	1
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	40
	i32.eqz
	br_if   	1                               # 1: down to label599
# %bb.172:                              #   in Loop: Header=BB28_171 Depth=2
	block   	
	local.get	40
	i32.const	-1
	i32.add 
	local.tee	40
	local.get	49
	i32.lt_u
	br_if   	0                               # 0: down to label601
# %bb.173:
	i32.const	-3
	local.set	40
	br      	10                              # 10: down to label513
.LBB28_174:                             #   in Loop: Header=BB28_171 Depth=2
	end_block                               # label601:
	block   	
	local.get	6
	local.get	40
	i32.const	4
	i32.shl 
	i32.add 
	local.tee	30
	i32.load	8
	local.get	28
	i32.ne  
	br_if   	0                               # 0: down to label602
# %bb.175:                              #   in Loop: Header=BB28_171 Depth=2
	local.get	30
	i32.load	12
	local.get	73
	i32.ne  
	br_if   	0                               # 0: down to label602
# %bb.176:                              #   in Loop: Header=BB28_171 Depth=2
	local.get	30
	i32.load	4
	local.get	36
	i32.ne  
	br_if   	0                               # 0: down to label602
# %bb.177:                              #   in Loop: Header=BB28_171 Depth=2
	local.get	4
	local.get	30
	i32.load	0
	local.tee	30
	local.get	47
	local.get	36
	call	content_bytes_equal
	br_if   	3                               # 3: down to label598
.LBB28_178:                             #   in Loop: Header=BB28_171 Depth=2
	end_block                               # label602:
	local.get	1
	i32.const	1
	i32.add 
	local.get	43
	i32.and 
	local.set	1
	local.get	31
	i32.const	-1
	i32.add 
	local.tee	31
	br_if   	0                               # 0: up to label600
.LBB28_179:                             #   in Loop: Header=BB28_18 Depth=1
	end_loop
	end_block                               # label599:
	i32.const	-3
	local.set	40
	local.get	7
	local.get	1
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	68
	i32.load	0
	br_if   	7                               # 7: down to label513
# %bb.180:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	52
	i32.const	-1
	i32.eq  
	br_if   	7                               # 7: down to label513
# %bb.181:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	6
	local.get	72
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	40
	local.get	73
	i32.store	12
	local.get	40
	local.get	28
	i32.store	8
	local.get	40
	local.get	36
	i32.store	4
	local.get	40
	local.get	47
	i32.store	0
	local.get	9
	local.get	72
	i32.add 
	local.get	52
	i32.store	0
	i32.const	0
	local.set	31
	i32.const	0
	local.get	36
	i32.const	-4
	i32.add 
	local.tee	40
	local.get	40
	local.get	36
	i32.gt_u
	i32.select
	local.set	72
	local.get	4
	local.get	47
	i32.add 
	local.set	71
	i32.const	0
	local.set	30
	local.get	70
	local.get	47
	i32.eq  
	br_if   	2                               # 2: down to label596
# %bb.182:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	36
	i32.const	3
	i32.gt_u
	br_if   	1                               # 1: down to label597
# %bb.183:                              #   in Loop: Header=BB28_18 Depth=1
	i32.const	0
	local.set	40
	local.get	71
	local.set	1
	local.get	36
	local.set	28
	i32.const	0
	local.set	30
.LBB28_184:                             #   Parent Loop BB28_18 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label603:
	local.get	1
	i32.load8_u	0
	local.get	40
	i32.shl 
	local.get	30
	i32.or  
	local.set	30
	local.get	1
	i32.const	1
	i32.add 
	local.set	1
	local.get	40
	i32.const	8
	i32.add 
	local.set	40
	local.get	28
	i32.const	-1
	i32.add 
	local.tee	28
	br_if   	0                               # 0: up to label603
	br      	3                               # 3: down to label596
.LBB28_185:                             #   in Loop: Header=BB28_18 Depth=1
	end_loop
	end_block                               # label598:
	local.get	6
	local.get	72
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	1
	local.get	73
	i32.store	12
	local.get	1
	local.get	28
	i32.store	8
	local.get	1
	local.get	36
	i32.store	4
	local.get	1
	local.get	30
	i32.store	0
	local.get	9
	local.get	72
	i32.add 
	local.get	9
	local.get	40
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.store	0
	local.get	39
	local.get	47
	i32.store	108
	i32.const	0
	local.set	63
	br      	2                               # 2: down to label595
.LBB28_186:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label597:
	local.get	71
	i32.load	0:p2align=0
	local.set	30
.LBB28_187:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label596:
	local.get	11
	local.get	52
	i32.const	12
	i32.mul 
	i32.add 
	local.tee	73
	local.get	30
	i32.store	0
	block   	
	local.get	36
	local.get	72
	i32.const	1
	i32.shr_u
	local.tee	1
	i32.le_u
	br_if   	0                               # 0: down to label604
# %bb.188:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	71
	local.get	1
	i32.add 
	local.set	40
	block   	
	local.get	36
	local.get	1
	i32.sub 
	local.tee	30
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label605
# %bb.189:                              #   in Loop: Header=BB28_18 Depth=1
	i32.const	0
	local.set	1
	i32.const	0
	local.set	31
.LBB28_190:                             #   Parent Loop BB28_18 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label606:
	local.get	40
	i32.load8_u	0
	local.get	1
	i32.shl 
	local.get	31
	i32.or  
	local.set	31
	local.get	40
	i32.const	1
	i32.add 
	local.set	40
	local.get	1
	i32.const	8
	i32.add 
	local.set	1
	local.get	30
	i32.const	-1
	i32.add 
	local.tee	30
	br_if   	0                               # 0: up to label606
	br      	2                               # 2: down to label604
.LBB28_191:                             #   in Loop: Header=BB28_18 Depth=1
	end_loop
	end_block                               # label605:
	local.get	40
	i32.load	0:p2align=0
	local.set	31
.LBB28_192:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label604:
	local.get	73
	i32.const	4
	i32.add 
	local.get	31
	i32.store	0
	i32.const	0
	local.set	63
	i32.const	0
	local.set	31
	block   	
	local.get	36
	local.get	72
	i32.le_u
	br_if   	0                               # 0: down to label607
# %bb.193:                              #   in Loop: Header=BB28_18 Depth=1
	block   	
	local.get	36
	local.get	72
	i32.sub 
	local.tee	1
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label608
# %bb.194:                              #   in Loop: Header=BB28_18 Depth=1
	local.get	4
	local.get	70
	i32.add 
	local.set	28
	i32.const	0
	local.set	40
	i32.const	0
	local.get	1
	i32.sub 
	local.set	1
	i32.const	0
	local.set	31
.LBB28_195:                             #   Parent Loop BB28_18 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label609:
	local.get	28
	local.get	1
	i32.add 
	i32.load8_u	0
	local.get	40
	i32.shl 
	local.get	31
	i32.or  
	local.set	31
	local.get	40
	i32.const	8
	i32.add 
	local.set	40
	local.get	1
	i32.const	1
	i32.add 
	local.tee	30
	local.set	1
	local.get	30
	br_if   	0                               # 0: up to label609
	br      	2                               # 2: down to label607
.LBB28_196:                             #   in Loop: Header=BB28_18 Depth=1
	end_loop
	end_block                               # label608:
	local.get	71
	local.get	72
	i32.add 
	i32.load	0:p2align=0
	local.set	31
.LBB28_197:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label607:
	local.get	73
	i32.const	8
	i32.add 
	local.get	31
	i32.store	0
	local.get	68
	local.get	49
	i32.const	1
	i32.add 
	i32.store	0
	local.get	52
	i32.const	1
	i32.add 
	local.set	52
	local.get	70
	local.set	47
.LBB28_198:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label595:
	local.get	67
	local.set	31
.LBB28_199:                             #   in Loop: Header=BB28_18 Depth=1
	end_block                               # label536:
	local.get	56
	i32.const	68
	i32.add 
	local.set	56
	local.get	62
	i32.const	1
	i32.add 
	local.set	62
	local.get	49
	i32.const	1
	i32.add 
	local.set	49
	local.get	39
	i32.const	52
	i32.add 
	local.get	39
	i32.load	48
	call	next_term_row
	local.tee	1
	i32.const	0
	i32.gt_s
	br_if   	0                               # 0: up to label519
.LBB28_200:
	end_loop
	end_block                               # label517:
	i32.const	-1
	local.set	40
	local.get	1
	i32.const	0
	i32.lt_s
	br_if   	0                               # 0: down to label513
# %bb.201:
	local.get	10
	local.get	52
	i32.store	0
	local.get	12
	local.get	49
	i32.store	0
	local.get	22
	local.get	51
	i32.store	0
	local.get	23
	local.get	50
	i32.store	0
	local.get	27
	local.get	48
	i32.store	0
	block   	
	local.get	38
	i32.eqz
	br_if   	0                               # 0: down to label610
# %bb.202:
	local.get	38
	local.get	46
	i32.store	0
.LBB28_203:
	end_block                               # label610:
	local.get	47
	local.set	40
.LBB28_204:
	end_block                               # label513:
	local.get	39
	i32.const	112
	i32.add 
	global.set	__stack_pointer
	local.get	40
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.next_term_bank,"",@
	.type	next_term_bank,@function        # -- Begin function next_term_bank
next_term_bank:                         # @next_term_bank
	.functype	next_term_bank (i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	1
	block   	
	local.get	0
	i32.load	16
	local.tee	2
	local.get	0
	i32.load	12
	local.tee	3
	i32.ge_u
	br_if   	0                               # 0: down to label611
# %bb.1:
	local.get	0
	i32.const	8
	i32.add 
	local.set	4
	local.get	0
	i32.load	4
	local.tee	5
	i32.const	4
	i32.add 
	local.set	6
	local.get	0
	i32.load	20
	local.set	7
.LBB29_2:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB29_12 Depth 2
                                        #     Child Loop BB29_20 Depth 2
                                        #     Child Loop BB29_29 Depth 2
	loop    	                                # label612:
	local.get	0
	local.get	2
	i32.const	1
	i32.add 
	local.tee	8
	i32.store	16
	local.get	2
	i32.const	3
	i32.shl 
	local.set	9
	block   	
	block   	
	local.get	5
	br_if   	0                               # 0: down to label614
# %bb.3:                                #   in Loop: Header=BB29_2 Depth=1
	i32.const	0
	local.set	2
	br      	1                               # 1: down to label613
.LBB29_4:                               #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label614:
	local.get	5
	local.get	9
	i32.add 
	i32.load	0
	local.set	2
.LBB29_5:                               #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label613:
	block   	
	local.get	2
	local.get	7
	i32.ge_u
	br_if   	0                               # 0: down to label615
# %bb.6:
	i32.const	-1
	return
.LBB29_7:                               #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label615:
	block   	
	local.get	4
	i32.load	0
	local.tee	10
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label616
# %bb.8:
	i32.const	-1
	return
.LBB29_9:                               #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label616:
	block   	
	local.get	6
	local.get	9
	i32.add 
	local.get	4
	local.get	5
	i32.select
	i32.load	0
	local.tee	9
	local.get	10
	local.get	2
	i32.sub 
	i32.le_u
	br_if   	0                               # 0: down to label617
# %bb.10:
	i32.const	-1
	return
.LBB29_11:                              #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label617:
	local.get	0
	local.get	9
	local.get	2
	i32.add 
	local.tee	7
	i32.store	20
	local.get	0
	i32.load	0
	local.set	10
	block   	
	local.get	2
	local.get	7
	i32.ge_u
	br_if   	0                               # 0: down to label618
.LBB29_12:                              #   Parent Loop BB29_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label619:
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	1
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label618
# %bb.13:                               #   in Loop: Header=BB29_12 Depth=2
	i32.const	1
	local.get	1
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label618
# %bb.14:                               #   in Loop: Header=BB29_12 Depth=2
	i32.const	-1
	local.set	1
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	local.get	9
	i32.const	-1
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label619
	br      	3                               # 3: down to label611
.LBB29_15:                              #   in Loop: Header=BB29_2 Depth=1
	end_loop
	end_block                               # label618:
	block   	
	local.get	2
	local.get	7
	i32.lt_u
	br_if   	0                               # 0: down to label620
# %bb.16:
	i32.const	-1
	return
.LBB29_17:                              #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label620:
	block   	
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.eq  
	br_if   	0                               # 0: down to label621
# %bb.18:
	i32.const	-1
	return
.LBB29_19:                              #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label621:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	local.get	7
	i32.ge_u
	br_if   	0                               # 0: down to label622
.LBB29_20:                              #   Parent Loop BB29_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label623:
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	9
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label622
# %bb.21:                               #   in Loop: Header=BB29_20 Depth=2
	i32.const	1
	local.get	9
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label622
# %bb.22:                               #   in Loop: Header=BB29_20 Depth=2
	local.get	7
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label623
# %bb.23:
	end_loop
	i32.const	-1
	return
.LBB29_24:                              #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label622:
	block   	
	local.get	2
	local.get	7
	i32.lt_u
	br_if   	0                               # 0: down to label624
# %bb.25:
	i32.const	-1
	return
.LBB29_26:                              #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label624:
	block   	
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.eq  
	br_if   	0                               # 0: down to label625
# %bb.27:
	local.get	0
	local.get	2
	i32.store	24
	i32.const	1
	return
.LBB29_28:                              #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label625:
	block   	
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	local.get	7
	i32.ge_u
	br_if   	0                               # 0: down to label627
.LBB29_29:                              #   Parent Loop BB29_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label628:
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	9
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label627
# %bb.30:                               #   in Loop: Header=BB29_29 Depth=2
	i32.const	1
	local.get	9
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label627
# %bb.31:                               #   in Loop: Header=BB29_29 Depth=2
	local.get	7
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label628
	br      	2                               # 2: down to label626
.LBB29_32:                              #   in Loop: Header=BB29_2 Depth=1
	end_loop
	end_block                               # label627:
	i32.const	-1
	local.set	1
	local.get	2
	local.get	7
	i32.ne  
	br_if   	2                               # 2: down to label611
.LBB29_33:                              #   in Loop: Header=BB29_2 Depth=1
	end_block                               # label626:
	i32.const	0
	local.set	1
	local.get	8
	local.set	2
	local.get	8
	local.get	3
	i32.ne  
	br_if   	0                               # 0: up to label612
.LBB29_34:
	end_loop
	end_block                               # label611:
	local.get	1
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_row_single_pass,"",@
	.type	parse_row_single_pass,@function # -- Begin function parse_row_single_pass
parse_row_single_pass:                  # @parse_row_single_pass
	.functype	parse_row_single_pass (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, v128, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	12
	global.set	__stack_pointer
	block   	
	block   	
	block   	
	local.get	10
	i32.eqz
	br_if   	0                               # 0: down to label631
# %bb.1:
	i32.const	0
	local.set	13
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label629
# %bb.2:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	2                               # 2: down to label629
# %bb.3:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	14
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label632
# %bb.4:
.LBB30_5:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label633:
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label632
# %bb.6:                                #   in Loop: Header=BB30_5 Depth=1
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label632
# %bb.7:                                #   in Loop: Header=BB30_5 Depth=1
	local.get	1
	local.get	14
	i32.const	1
	i32.add 
	local.tee	14
	i32.ne  
	br_if   	0                               # 0: up to label633
# %bb.8:
	end_loop
	i32.const	0
	local.set	13
	br      	3                               # 3: down to label629
.LBB30_9:
	end_block                               # label632:
	i32.const	0
	local.set	13
	local.get	14
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label629
# %bb.10:
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	2                               # 2: down to label629
# %bb.11:
	local.get	14
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label629
# %bb.12:
	local.get	0
	i32.const	5
	i32.add 
	local.set	15
	local.get	0
	i32.const	4
	i32.add 
	local.set	16
	local.get	0
	i32.const	3
	i32.add 
	local.set	17
	i32.const	0
	local.set	18
.LBB30_13:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label634:
	block   	
	block   	
	local.get	2
	i32.const	8
	i32.add 
	local.tee	10
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label636
# %bb.14:                               #   in Loop: Header=BB30_13 Depth=1
	local.get	2
	local.set	10
	br      	1                               # 1: down to label635
.LBB30_15:                              #   in Loop: Header=BB30_13 Depth=1
	end_block                               # label636:
	local.get	0
	local.get	2
	i32.add 
	local.set	13
	local.get	10
	local.set	2
	local.get	13
	i64.load	0:p2align=0
	local.tee	19
	i64.const	-1
	i64.xor 
	local.get	19
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	19
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	19
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	19
	i64.eqz
	br_if   	1                               # 1: up to label634
# %bb.16:                               #   in Loop: Header=BB30_13 Depth=1
	local.get	19
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	10
	i32.add 
	i32.const	-8
	i32.add 
	local.set	10
.LBB30_17:                              #   in Loop: Header=BB30_13 Depth=1
	end_block                               # label635:
	i32.const	0
	local.set	13
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	3                               # 3: down to label629
# %bb.18:                               #   in Loop: Header=BB30_13 Depth=1
	block   	
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label639
# %bb.19:                               #   in Loop: Header=BB30_13 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	6                               # 6: down to label629
# %bb.20:                               #   in Loop: Header=BB30_13 Depth=1
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 8, 8, 1, 8, 8, 8, 1, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 1, 8, 1, 0, 8} # 8: down to label629
                                        # 1: down to label640
                                        # 0: down to label641
.LBB30_21:                              #   in Loop: Header=BB30_13 Depth=1
	end_block                               # label641:
	local.get	10
	i32.const	6
	i32.add 
	local.tee	2
	local.get	1
	i32.gt_u
	br_if   	7                               # 7: down to label629
# %bb.22:                               #   in Loop: Header=BB30_13 Depth=1
	i32.const	1
	local.set	18
	local.get	10
	i32.const	2
	i32.add 
	local.tee	20
	local.get	2
	i32.ge_u
	br_if   	2                               # 2: down to label638
# %bb.23:                               #   in Loop: Header=BB30_13 Depth=1
	block   	
	local.get	0
	local.get	20
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label642
# %bb.24:                               #   in Loop: Header=BB30_13 Depth=1
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	8                               # 8: down to label629
.LBB30_25:                              #   in Loop: Header=BB30_13 Depth=1
	end_block                               # label642:
	block   	
	local.get	17
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label643
# %bb.26:                               #   in Loop: Header=BB30_13 Depth=1
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	8                               # 8: down to label629
.LBB30_27:                              #   in Loop: Header=BB30_13 Depth=1
	end_block                               # label643:
	block   	
	local.get	16
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label644
# %bb.28:                               #   in Loop: Header=BB30_13 Depth=1
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	8                               # 8: down to label629
.LBB30_29:                              #   in Loop: Header=BB30_13 Depth=1
	end_block                               # label644:
	local.get	15
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label638
# %bb.30:                               #   in Loop: Header=BB30_13 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label638
	br      	7                               # 7: down to label629
.LBB30_31:                              #   in Loop: Header=BB30_13 Depth=1
	end_block                               # label640:
	local.get	10
	i32.const	2
	i32.add 
	local.set	2
	i32.const	1
	local.set	18
	br      	1                               # 1: down to label638
.LBB30_32:                              #   in Loop: Header=BB30_13 Depth=1
	end_block                               # label639:
	local.get	20
	i32.const	32
	i32.lt_u
	br_if   	5                               # 5: down to label629
# %bb.33:                               #   in Loop: Header=BB30_13 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.set	2
	local.get	20
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label637
.LBB30_34:                              #   in Loop: Header=BB30_13 Depth=1
	end_block                               # label638:
	local.get	2
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label634
	br      	4                               # 4: down to label629
.LBB30_35:
	end_block                               # label637:
	end_loop
	local.get	3
	local.get	14
	i32.store	0
	local.get	3
	local.get	2
	local.get	14
	i32.sub 
	i32.store	4
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label645
# %bb.36:
.LBB30_37:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label646:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label645
# %bb.38:                               #   in Loop: Header=BB30_37 Depth=1
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label645
# %bb.39:                               #   in Loop: Header=BB30_37 Depth=1
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label646
	br      	4                               # 4: down to label629
.LBB30_40:
	end_loop
	end_block                               # label645:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label629
# %bb.41:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	2                               # 2: down to label629
# %bb.42:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	14
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label647
# %bb.43:
.LBB30_44:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label648:
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label647
# %bb.45:                               #   in Loop: Header=BB30_44 Depth=1
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label647
# %bb.46:                               #   in Loop: Header=BB30_44 Depth=1
	local.get	1
	local.get	14
	i32.const	1
	i32.add 
	local.tee	14
	i32.ne  
	br_if   	0                               # 0: up to label648
	br      	4                               # 4: down to label629
.LBB30_47:
	end_loop
	end_block                               # label647:
	local.get	14
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label629
# %bb.48:
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	2                               # 2: down to label629
# %bb.49:
	local.get	14
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label629
# %bb.50:
	i32.const	0
	local.set	21
.LBB30_51:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label649:
	block   	
	block   	
	local.get	2
	i32.const	8
	i32.add 
	local.tee	10
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label651
# %bb.52:                               #   in Loop: Header=BB30_51 Depth=1
	local.get	2
	local.set	10
	br      	1                               # 1: down to label650
.LBB30_53:                              #   in Loop: Header=BB30_51 Depth=1
	end_block                               # label651:
	local.get	0
	local.get	2
	i32.add 
	local.set	13
	local.get	10
	local.set	2
	local.get	13
	i64.load	0:p2align=0
	local.tee	19
	i64.const	-1
	i64.xor 
	local.get	19
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	19
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	19
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	19
	i64.eqz
	br_if   	1                               # 1: up to label649
# %bb.54:                               #   in Loop: Header=BB30_51 Depth=1
	local.get	19
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	10
	i32.add 
	i32.const	-8
	i32.add 
	local.set	10
.LBB30_55:                              #   in Loop: Header=BB30_51 Depth=1
	end_block                               # label650:
	i32.const	0
	local.set	13
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	3                               # 3: down to label629
# %bb.56:                               #   in Loop: Header=BB30_51 Depth=1
	block   	
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label654
# %bb.57:                               #   in Loop: Header=BB30_51 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	6                               # 6: down to label629
# %bb.58:                               #   in Loop: Header=BB30_51 Depth=1
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 8, 8, 1, 8, 8, 8, 1, 8, 8, 8, 8, 8, 8, 8, 1, 8, 8, 8, 1, 8, 1, 0, 8} # 8: down to label629
                                        # 1: down to label655
                                        # 0: down to label656
.LBB30_59:                              #   in Loop: Header=BB30_51 Depth=1
	end_block                               # label656:
	local.get	10
	i32.const	6
	i32.add 
	local.tee	2
	local.get	1
	i32.gt_u
	br_if   	7                               # 7: down to label629
# %bb.60:                               #   in Loop: Header=BB30_51 Depth=1
	i32.const	1
	local.set	21
	local.get	10
	i32.const	2
	i32.add 
	local.tee	20
	local.get	2
	i32.ge_u
	br_if   	2                               # 2: down to label653
# %bb.61:                               #   in Loop: Header=BB30_51 Depth=1
	block   	
	local.get	0
	local.get	20
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label657
# %bb.62:                               #   in Loop: Header=BB30_51 Depth=1
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	8                               # 8: down to label629
.LBB30_63:                              #   in Loop: Header=BB30_51 Depth=1
	end_block                               # label657:
	block   	
	local.get	17
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label658
# %bb.64:                               #   in Loop: Header=BB30_51 Depth=1
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	8                               # 8: down to label629
.LBB30_65:                              #   in Loop: Header=BB30_51 Depth=1
	end_block                               # label658:
	block   	
	local.get	16
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label659
# %bb.66:                               #   in Loop: Header=BB30_51 Depth=1
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	8                               # 8: down to label629
.LBB30_67:                              #   in Loop: Header=BB30_51 Depth=1
	end_block                               # label659:
	local.get	15
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label653
# %bb.68:                               #   in Loop: Header=BB30_51 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label653
	br      	7                               # 7: down to label629
.LBB30_69:                              #   in Loop: Header=BB30_51 Depth=1
	end_block                               # label655:
	local.get	10
	i32.const	2
	i32.add 
	local.set	2
	i32.const	1
	local.set	21
	br      	1                               # 1: down to label653
.LBB30_70:                              #   in Loop: Header=BB30_51 Depth=1
	end_block                               # label654:
	local.get	20
	i32.const	32
	i32.lt_u
	br_if   	5                               # 5: down to label629
# %bb.71:                               #   in Loop: Header=BB30_51 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.set	2
	local.get	20
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label652
.LBB30_72:                              #   in Loop: Header=BB30_51 Depth=1
	end_block                               # label653:
	local.get	2
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label649
	br      	4                               # 4: down to label629
.LBB30_73:
	end_block                               # label652:
	end_loop
	local.get	3
	local.get	14
	i32.store	8
	local.get	3
	local.get	2
	local.get	14
	i32.sub 
	i32.store	12
	block   	
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label660
# %bb.74:
	local.get	11
	local.get	21
	i32.const	1
	i32.shl 
	local.get	18
	i32.or  
	i32.store	0
.LBB30_75:
	end_block                               # label660:
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label661
# %bb.76:
.LBB30_77:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label662:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label661
# %bb.78:                               #   in Loop: Header=BB30_77 Depth=1
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label661
# %bb.79:                               #   in Loop: Header=BB30_77 Depth=1
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label662
	br      	4                               # 4: down to label629
.LBB30_80:
	end_loop
	end_block                               # label661:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label629
# %bb.81:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	2                               # 2: down to label629
# %bb.82:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label663
# %bb.83:
.LBB30_84:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label664:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label663
# %bb.85:                               #   in Loop: Header=BB30_84 Depth=1
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label663
# %bb.86:                               #   in Loop: Header=BB30_84 Depth=1
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label664
	br      	4                               # 4: down to label629
.LBB30_87:
	end_loop
	end_block                               # label663:
	local.get	1
	local.get	2
	i32.le_u
	br_if   	2                               # 2: down to label629
# %bb.88:
	block   	
	local.get	0
	local.get	2
	i32.add 
	local.tee	14
	i32.load8_u	0
	local.tee	10
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label665
# %bb.89:
	local.get	1
	local.get	2
	i32.sub 
	i32.const	4
	i32.lt_u
	br_if   	3                               # 3: down to label629
# %bb.90:
	local.get	14
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	3                               # 3: down to label629
# %bb.91:
	local.get	14
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	3                               # 3: down to label629
# %bb.92:
	local.get	14
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	3                               # 3: down to label629
# %bb.93:
	local.get	2
	i32.const	4
	i32.add 
	local.set	14
	br      	2                               # 2: down to label630
.LBB30_94:
	end_block                               # label665:
	local.get	10
	i32.const	34
	i32.ne  
	br_if   	2                               # 2: down to label629
# %bb.95:
	local.get	2
	i32.const	1
	i32.add 
	local.tee	14
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label629
# %bb.96:
.LBB30_97:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label666:
	block   	
	local.get	14
	local.tee	10
	i32.const	8
	i32.add 
	local.tee	14
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label667
# %bb.98:                               #   in Loop: Header=BB30_97 Depth=1
	local.get	0
	local.get	10
	i32.add 
	i64.load	0:p2align=0
	local.tee	19
	i64.const	-1
	i64.xor 
	local.get	19
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	19
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	19
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	19
	i64.eqz
	br_if   	1                               # 1: up to label666
# %bb.99:                               #   in Loop: Header=BB30_97 Depth=1
	local.get	19
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	10
	i32.add 
	local.set	10
.LBB30_100:                             #   in Loop: Header=BB30_97 Depth=1
	end_block                               # label667:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	3                               # 3: down to label629
# %bb.101:                              #   in Loop: Header=BB30_97 Depth=1
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label669
# %bb.102:                              #   in Loop: Header=BB30_97 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	14
	local.get	1
	i32.ge_u
	br_if   	5                               # 5: down to label629
# %bb.103:                              #   in Loop: Header=BB30_97 Depth=1
	block   	
	block   	
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 1, 0, 7} # 7: down to label629
                                        # 1: down to label670
                                        # 0: down to label671
.LBB30_104:                             #   in Loop: Header=BB30_97 Depth=1
	end_block                               # label671:
	local.get	10
	i32.const	6
	i32.add 
	local.tee	14
	local.get	1
	i32.gt_u
	br_if   	6                               # 6: down to label629
# %bb.105:                              #   in Loop: Header=BB30_97 Depth=1
	local.get	10
	i32.const	2
	i32.add 
	local.tee	11
	local.get	14
	i32.ge_u
	br_if   	2                               # 2: down to label668
# %bb.106:                              #   in Loop: Header=BB30_97 Depth=1
	block   	
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label672
# %bb.107:                              #   in Loop: Header=BB30_97 Depth=1
	local.get	11
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label629
.LBB30_108:                             #   in Loop: Header=BB30_97 Depth=1
	end_block                               # label672:
	block   	
	local.get	17
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label673
# %bb.109:                              #   in Loop: Header=BB30_97 Depth=1
	local.get	11
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label629
.LBB30_110:                             #   in Loop: Header=BB30_97 Depth=1
	end_block                               # label673:
	block   	
	local.get	16
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label674
# %bb.111:                              #   in Loop: Header=BB30_97 Depth=1
	local.get	11
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label629
.LBB30_112:                             #   in Loop: Header=BB30_97 Depth=1
	end_block                               # label674:
	local.get	15
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label668
# %bb.113:                              #   in Loop: Header=BB30_97 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label668
	br      	6                               # 6: down to label629
.LBB30_114:                             #   in Loop: Header=BB30_97 Depth=1
	end_block                               # label670:
	local.get	10
	i32.const	2
	i32.add 
	local.set	14
	br      	1                               # 1: down to label668
.LBB30_115:                             #   in Loop: Header=BB30_97 Depth=1
	end_block                               # label669:
	local.get	11
	i32.const	32
	i32.lt_u
	br_if   	4                               # 4: down to label629
# %bb.116:                              #   in Loop: Header=BB30_97 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.set	14
	local.get	11
	i32.const	34
	i32.eq  
	br_if   	3                               # 3: down to label630
.LBB30_117:                             #   in Loop: Header=BB30_97 Depth=1
	end_block                               # label668:
	local.get	14
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: up to label666
	br      	3                               # 3: down to label629
.LBB30_118:
	end_loop
	end_block                               # label631:
	i32.const	0
	local.set	13
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label629
# %bb.119:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	1                               # 1: down to label629
# %bb.120:
	local.get	3
	v128.const	0, 0
	local.tee	22
	v128.store	0:p2align=2
	local.get	3
	local.get	22
	v128.store	48:p2align=2
	local.get	3
	i32.const	32
	i32.add 
	i64.const	0
	i64.store	0:p2align=2
	local.get	3
	i32.const	16
	i32.add 
	local.get	22
	v128.store	0:p2align=2
	local.get	3
	i32.const	40
	i32.add 
	i64.const	-4294967296
	i64.store	0:p2align=2
	local.get	3
	i32.const	64
	i32.add 
	local.tee	23
	i32.const	0
	i32.store	0
	block   	
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label675
# %bb.121:
	local.get	11
	i32.const	3
	i32.store	0
.LBB30_122:
	end_block                               # label675:
	local.get	3
	i32.const	48
	i32.add 
	local.set	24
	local.get	3
	i32.const	56
	i32.add 
	i32.const	0
	local.get	4
	i32.select
	local.set	25
	local.get	0
	i32.const	5
	i32.add 
	local.set	15
	local.get	0
	i32.const	4
	i32.add 
	local.set	16
	local.get	0
	i32.const	3
	i32.add 
	local.set	17
	local.get	3
	i32.const	60
	i32.add 
	local.set	26
	local.get	0
	i32.const	-1
	i32.add 
	local.set	21
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	i32.const	0
	local.set	18
.LBB30_123:                             # =>This Loop Header: Depth=1
                                        #     Child Loop BB30_124 Depth 2
                                        #     Child Loop BB30_161 Depth 2
                                        #     Child Loop BB30_135 Depth 2
                                        #     Child Loop BB30_221 Depth 2
                                        #     Child Loop BB30_230 Depth 2
	loop    	                                # label676:
	i32.const	0
	local.set	13
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label629
.LBB30_124:                             #   Parent Loop BB30_123 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label678:
	local.get	0
	local.get	2
	i32.add 
	local.tee	4
	i32.load8_u	0
	local.tee	14
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label677
# %bb.125:                              #   in Loop: Header=BB30_124 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label677
# %bb.126:                              #   in Loop: Header=BB30_124 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label678
	br      	4                               # 4: down to label629
.LBB30_127:                             #   in Loop: Header=BB30_123 Depth=1
	end_loop
	end_block                               # label677:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label629
# %bb.128:                              #   in Loop: Header=BB30_123 Depth=1
	block   	
	local.get	14
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: down to label679
# %bb.129:
	local.get	5
	local.get	2
	i32.const	1
	i32.add 
	i32.store	0
	local.get	3
	i32.load	4
	i32.const	0
	i32.ne  
	local.set	13
	br      	3                               # 3: down to label629
.LBB30_130:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label679:
	local.get	12
	i32.const	0
	i32.store	4
	block   	
	block   	
	block   	
	block   	
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label683
# %bb.131:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	18
	i32.const	1
	i32.gt_u
	br_if   	0                               # 0: down to label683
# %bb.132:                              #   in Loop: Header=BB30_123 Depth=1
	i32.const	0
	local.set	13
	local.get	14
	i32.const	34
	i32.ne  
	br_if   	6                               # 6: down to label629
# %bb.133:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	6                               # 6: down to label629
# %bb.134:                              #   in Loop: Header=BB30_123 Depth=1
	i32.const	0
	local.set	27
.LBB30_135:                             #   Parent Loop BB30_123 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label684:
	block   	
	block   	
	local.get	10
	i32.const	8
	i32.add 
	local.tee	13
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label686
# %bb.136:                              #   in Loop: Header=BB30_135 Depth=2
	local.get	10
	local.set	14
	br      	1                               # 1: down to label685
.LBB30_137:                             #   in Loop: Header=BB30_135 Depth=2
	end_block                               # label686:
	local.get	0
	local.get	10
	i32.add 
	local.set	14
	local.get	13
	local.set	10
	local.get	14
	i64.load	0:p2align=0
	local.tee	19
	i64.const	-1
	i64.xor 
	local.get	19
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	19
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	local.get	19
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	19
	i64.eqz
	br_if   	1                               # 1: up to label684
# %bb.138:                              #   in Loop: Header=BB30_135 Depth=2
	local.get	19
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	13
	i32.add 
	i32.const	-8
	i32.add 
	local.set	14
.LBB30_139:                             #   in Loop: Header=BB30_135 Depth=2
	end_block                               # label685:
	i32.const	0
	local.set	13
	local.get	14
	local.get	1
	i32.ge_u
	br_if   	7                               # 7: down to label629
# %bb.140:                              #   in Loop: Header=BB30_135 Depth=2
	block   	
	block   	
	block   	
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label689
# %bb.141:                              #   in Loop: Header=BB30_135 Depth=2
	local.get	14
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	10                              # 10: down to label629
# %bb.142:                              #   in Loop: Header=BB30_135 Depth=2
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 1, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 1, 12, 12, 12, 12, 12, 1, 12, 12, 12, 1, 12, 12, 12, 12, 12, 12, 12, 1, 12, 12, 12, 1, 12, 1, 0, 12} # 12: down to label629
                                        # 1: down to label690
                                        # 0: down to label691
.LBB30_143:                             #   in Loop: Header=BB30_135 Depth=2
	end_block                               # label691:
	local.get	14
	i32.const	6
	i32.add 
	local.tee	10
	local.get	1
	i32.gt_u
	br_if   	11                              # 11: down to label629
# %bb.144:                              #   in Loop: Header=BB30_135 Depth=2
	i32.const	1
	local.set	27
	local.get	14
	i32.const	2
	i32.add 
	local.tee	20
	local.get	10
	i32.ge_u
	br_if   	2                               # 2: down to label688
# %bb.145:                              #   in Loop: Header=BB30_135 Depth=2
	block   	
	local.get	0
	local.get	20
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label692
# %bb.146:                              #   in Loop: Header=BB30_135 Depth=2
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	12                              # 12: down to label629
.LBB30_147:                             #   in Loop: Header=BB30_135 Depth=2
	end_block                               # label692:
	block   	
	local.get	17
	local.get	14
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label693
# %bb.148:                              #   in Loop: Header=BB30_135 Depth=2
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	12                              # 12: down to label629
.LBB30_149:                             #   in Loop: Header=BB30_135 Depth=2
	end_block                               # label693:
	block   	
	local.get	16
	local.get	14
	i32.add 
	i32.load8_u	0
	local.tee	20
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label694
# %bb.150:                              #   in Loop: Header=BB30_135 Depth=2
	local.get	20
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	12                              # 12: down to label629
.LBB30_151:                             #   in Loop: Header=BB30_135 Depth=2
	end_block                               # label694:
	local.get	15
	local.get	14
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label688
# %bb.152:                              #   in Loop: Header=BB30_135 Depth=2
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label688
	br      	11                              # 11: down to label629
.LBB30_153:                             #   in Loop: Header=BB30_135 Depth=2
	end_block                               # label690:
	local.get	14
	i32.const	2
	i32.add 
	local.set	10
	i32.const	1
	local.set	27
	br      	1                               # 1: down to label688
.LBB30_154:                             #   in Loop: Header=BB30_135 Depth=2
	end_block                               # label689:
	local.get	20
	i32.const	32
	i32.lt_u
	br_if   	9                               # 9: down to label629
# %bb.155:                              #   in Loop: Header=BB30_135 Depth=2
	local.get	14
	i32.const	1
	i32.add 
	local.set	10
	local.get	20
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label687
.LBB30_156:                             #   in Loop: Header=BB30_135 Depth=2
	end_block                               # label688:
	local.get	10
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label684
	br      	8                               # 8: down to label629
.LBB30_157:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label687:
	end_loop
	local.get	12
	local.get	10
	i32.store	4
	local.get	27
	br_if   	1                               # 1: down to label682
# %bb.158:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	11
	local.get	11
	i32.load	0
	i32.const	-2
	local.get	18
	i32.rotl
	i32.and 
	i32.store	0
	br      	1                               # 1: down to label682
.LBB30_159:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label683:
	block   	
	block   	
	local.get	18
	i32.const	-3
	i32.and 
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label696
# %bb.160:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	2
	local.set	14
.LBB30_161:                             #   Parent Loop BB30_123 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label698:
	block   	
	local.get	1
	local.get	14
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: down to label699
# %bb.162:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	1
	local.set	10
	br      	2                               # 2: down to label697
.LBB30_163:                             #   in Loop: Header=BB30_161 Depth=2
	end_block                               # label699:
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	13
	i32.const	-10
	i32.add 
	br_table 	{3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0} # 1: down to label700
                                        # 3: down to label697
                                        # 0: down to label701
.LBB30_164:                             #   in Loop: Header=BB30_161 Depth=2
	end_block                               # label701:
	local.get	13
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label697
# %bb.165:                              #   in Loop: Header=BB30_161 Depth=2
	local.get	13
	i32.const	125
	i32.eq  
	br_if   	2                               # 2: down to label697
.LBB30_166:                             #   in Loop: Header=BB30_161 Depth=2
	end_block                               # label700:
	local.get	10
	i32.const	1
	i32.add 
	local.set	14
	local.get	13
	i32.const	9
	i32.ne  
	br_if   	0                               # 0: up to label698
.LBB30_167:                             #   in Loop: Header=BB30_123 Depth=1
	end_loop
	end_block                               # label697:
	local.get	10
	local.get	2
	i32.ne  
	br_if   	1                               # 1: down to label695
# %bb.168:
	i32.const	0
	local.set	13
	br      	7                               # 7: down to label629
.LBB30_169:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label696:
	block   	
	local.get	18
	i32.const	5
	i32.ne  
	br_if   	0                               # 0: down to label702
# %bb.170:                              #   in Loop: Header=BB30_123 Depth=1
	block   	
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label703
# %bb.171:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	0
	local.get	1
	local.get	2
	local.get	6
	local.get	7
	local.get	3
	local.get	12
	i32.const	4
	i32.add 
	local.get	8
	local.get	9
	call	reuse_validated_glossary
	br_if   	4                               # 4: down to label681
# %bb.172:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	4
	i32.load8_u	0
	local.set	14
.LBB30_173:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label703:
	block   	
	block   	
	local.get	14
	i32.const	223
	i32.and 
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label705
# %bb.174:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	0
	local.get	1
	local.get	2
	local.get	12
	i32.const	4
	i32.add 
	local.get	25
	local.get	26
	local.get	23
	i32.const	0
	call	parse_composite_span_impl
	local.set	10
	br      	1                               # 1: down to label704
.LBB30_175:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label705:
	local.get	0
	local.get	1
	local.get	2
	local.get	12
	i32.const	4
	i32.add 
	call	parse_value_span
	local.set	10
.LBB30_176:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label704:
	local.get	10
	br_if   	3                               # 3: down to label681
# %bb.177:
	i32.const	0
	local.set	13
	br      	7                               # 7: down to label629
.LBB30_178:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label702:
	local.get	0
	local.get	1
	local.get	2
	local.get	12
	i32.const	4
	i32.add 
	call	parse_value_span
	br_if   	1                               # 1: down to label682
# %bb.179:
	i32.const	0
	local.set	13
	br      	6                               # 6: down to label629
.LBB30_180:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label695:
	local.get	12
	local.get	10
	i32.store	4
.LBB30_181:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label682:
	local.get	18
	i32.const	8
	i32.lt_u
	br_if   	0                               # 0: down to label681
# %bb.182:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	12
	i32.load	4
	local.set	10
	br      	1                               # 1: down to label680
.LBB30_183:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label681:
	i32.const	0
	local.set	20
	block   	
	i32.const	0
	local.get	12
	i32.load	4
	local.tee	10
	local.get	2
	i32.sub 
	local.tee	13
	local.get	13
	local.get	10
	i32.gt_u
	i32.select
	local.tee	14
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label706
# %bb.184:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	4
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label706
# %bb.185:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	21
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	20
.LBB30_186:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label706:
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	18
	br_table 	{0, 1, 2, 3, 4, 5, 6, 7, 0} # 1: down to label714
                                        # 2: down to label713
                                        # 3: down to label712
                                        # 4: down to label711
                                        # 5: down to label710
                                        # 6: down to label709
                                        # 7: down to label708
                                        # 0: down to label715
.LBB30_187:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label715:
	block   	
	local.get	20
	br_if   	0                               # 0: down to label716
# %bb.188:
	i32.const	0
	local.set	13
	br      	12                              # 12: down to label629
.LBB30_189:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label716:
	local.get	3
	local.get	2
	i32.store	0
	i32.const	4
	local.set	13
	br      	7                               # 7: down to label707
.LBB30_190:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label714:
	block   	
	local.get	20
	br_if   	0                               # 0: down to label717
# %bb.191:
	i32.const	0
	local.set	13
	br      	11                              # 11: down to label629
.LBB30_192:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label717:
	local.get	3
	local.get	2
	i32.store	8
	i32.const	12
	local.set	13
	br      	6                               # 6: down to label707
.LBB30_193:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label713:
	block   	
	local.get	20
	br_if   	0                               # 0: down to label718
# %bb.194:                              #   in Loop: Header=BB30_123 Depth=1
	i32.const	0
	local.set	13
	local.get	14
	i32.const	4
	i32.ne  
	br_if   	10                              # 10: down to label629
# %bb.195:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	4
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	10                              # 10: down to label629
# %bb.196:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	4
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	10                              # 10: down to label629
# %bb.197:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	4
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	10                              # 10: down to label629
# %bb.198:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	4
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	10                              # 10: down to label629
.LBB30_199:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label718:
	local.get	3
	local.get	2
	i32.store	16
	i32.const	20
	local.set	13
	br      	5                               # 5: down to label707
.LBB30_200:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label712:
	block   	
	local.get	20
	br_if   	0                               # 0: down to label719
# %bb.201:
	i32.const	0
	local.set	13
	br      	9                               # 9: down to label629
.LBB30_202:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label719:
	local.get	3
	local.get	2
	i32.store	24
	i32.const	28
	local.set	13
	br      	4                               # 4: down to label707
.LBB30_203:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label711:
	block   	
	local.get	0
	local.get	2
	local.get	10
	call	is_valid_json_number
	i32.eqz
	br_if   	0                               # 0: down to label720
# %bb.204:                              #   in Loop: Header=BB30_123 Depth=1
	i32.const	32
	local.set	13
	local.get	2
	local.set	14
	br      	4                               # 4: down to label707
.LBB30_205:
	end_block                               # label720:
	i32.const	0
	local.set	13
	br      	7                               # 7: down to label629
.LBB30_206:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label710:
	local.get	3
	local.get	2
	i32.store	36
	i32.const	40
	local.set	13
	br      	2                               # 2: down to label707
.LBB30_207:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label709:
	block   	
	local.get	14
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label721
# %bb.208:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	4
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label721
# %bb.209:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	4
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label721
# %bb.210:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	4
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label721
# %bb.211:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	4
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label721
# %bb.212:                              #   in Loop: Header=BB30_123 Depth=1
	i32.const	-1
	local.set	14
	i32.const	44
	local.set	13
	br      	2                               # 2: down to label707
.LBB30_213:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label721:
	block   	
	local.get	0
	local.get	2
	local.get	10
	call	is_valid_json_number
	i32.eqz
	br_if   	0                               # 0: down to label722
# %bb.214:                              #   in Loop: Header=BB30_123 Depth=1
	i32.const	44
	local.set	13
	local.get	2
	local.set	14
	br      	2                               # 2: down to label707
.LBB30_215:
	end_block                               # label722:
	i32.const	0
	local.set	13
	br      	5                               # 5: down to label629
.LBB30_216:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label708:
	block   	
	local.get	20
	br_if   	0                               # 0: down to label723
# %bb.217:
	i32.const	0
	local.set	13
	br      	5                               # 5: down to label629
.LBB30_218:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label723:
	local.get	24
	local.get	2
	i32.store	0
	i32.const	52
	local.set	13
.LBB30_219:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label707:
	local.get	3
	local.get	13
	i32.add 
	local.get	14
	i32.store	0
.LBB30_220:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label680:
	block   	
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label724
.LBB30_221:                             #   Parent Loop BB30_123 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label725:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label724
# %bb.222:                              #   in Loop: Header=BB30_221 Depth=2
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label724
# %bb.223:                              #   in Loop: Header=BB30_221 Depth=2
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label725
# %bb.224:
	end_loop
	i32.const	0
	local.set	13
	br      	3                               # 3: down to label629
.LBB30_225:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label724:
	i32.const	0
	local.set	13
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label629
# %bb.226:                              #   in Loop: Header=BB30_123 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	44
	i32.eq  
	br_if   	0                               # 0: down to label726
# %bb.227:
	local.get	2
	i32.const	93
	i32.ne  
	br_if   	3                               # 3: down to label629
# %bb.228:
	local.get	5
	local.get	10
	i32.const	1
	i32.add 
	i32.store	0
	local.get	3
	i32.load	4
	i32.const	0
	i32.ne  
	local.set	13
	br      	3                               # 3: down to label629
.LBB30_229:                             #   in Loop: Header=BB30_123 Depth=1
	end_block                               # label726:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label727
.LBB30_230:                             #   Parent Loop BB30_123 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label728:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label727
# %bb.231:                              #   in Loop: Header=BB30_230 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label727
# %bb.232:                              #   in Loop: Header=BB30_230 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label728
	br      	4                               # 4: down to label629
.LBB30_233:                             #   in Loop: Header=BB30_123 Depth=1
	end_loop
	end_block                               # label727:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label629
# %bb.234:                              #   in Loop: Header=BB30_123 Depth=1
	local.get	18
	i32.const	1
	i32.add 
	local.set	18
	i32.const	0
	local.set	13
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: up to label676
	br      	2                               # 2: down to label629
.LBB30_235:
	end_loop
	end_block                               # label630:
	local.get	3
	local.get	2
	i32.store	16
	local.get	12
	local.get	14
	i32.store	12
	local.get	3
	local.get	14
	local.get	2
	i32.sub 
	i32.store	20
	local.get	0
	local.get	1
	local.get	12
	i32.const	12
	i32.add 
	call	next_format3_field
	i32.eqz
	br_if   	0                               # 0: down to label629
# %bb.236:
	local.get	12
	i32.load	12
	local.tee	11
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label629
# %bb.237:
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label629
# %bb.238:
	local.get	11
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label629
# %bb.239:
.LBB30_240:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label729:
	block   	
	local.get	10
	local.tee	2
	i32.const	8
	i32.add 
	local.tee	10
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label730
# %bb.241:                              #   in Loop: Header=BB30_240 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i64.load	0:p2align=0
	local.tee	19
	i64.const	-1
	i64.xor 
	local.get	19
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	19
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	19
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	19
	i64.eqz
	br_if   	1                               # 1: up to label729
# %bb.242:                              #   in Loop: Header=BB30_240 Depth=1
	local.get	19
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	2
	i32.add 
	local.set	2
.LBB30_243:                             #   in Loop: Header=BB30_240 Depth=1
	end_block                               # label730:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label629
# %bb.244:                              #   in Loop: Header=BB30_240 Depth=1
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label733
# %bb.245:                              #   in Loop: Header=BB30_240 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	4                               # 4: down to label629
# %bb.246:                              #   in Loop: Header=BB30_240 Depth=1
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 1, 6, 6, 6, 6, 6, 1, 6, 6, 6, 1, 6, 6, 6, 6, 6, 6, 6, 1, 6, 6, 6, 1, 6, 1, 0, 6} # 6: down to label629
                                        # 1: down to label734
                                        # 0: down to label735
.LBB30_247:                             #   in Loop: Header=BB30_240 Depth=1
	end_block                               # label735:
	local.get	2
	i32.const	6
	i32.add 
	local.tee	10
	local.get	1
	i32.gt_u
	br_if   	5                               # 5: down to label629
# %bb.248:                              #   in Loop: Header=BB30_240 Depth=1
	local.get	2
	i32.const	2
	i32.add 
	local.tee	14
	local.get	10
	i32.ge_u
	br_if   	2                               # 2: down to label732
# %bb.249:                              #   in Loop: Header=BB30_240 Depth=1
	block   	
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label736
# %bb.250:                              #   in Loop: Header=BB30_240 Depth=1
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label629
.LBB30_251:                             #   in Loop: Header=BB30_240 Depth=1
	end_block                               # label736:
	block   	
	local.get	17
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label737
# %bb.252:                              #   in Loop: Header=BB30_240 Depth=1
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label629
.LBB30_253:                             #   in Loop: Header=BB30_240 Depth=1
	end_block                               # label737:
	block   	
	local.get	16
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label738
# %bb.254:                              #   in Loop: Header=BB30_240 Depth=1
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label629
.LBB30_255:                             #   in Loop: Header=BB30_240 Depth=1
	end_block                               # label738:
	local.get	15
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label732
# %bb.256:                              #   in Loop: Header=BB30_240 Depth=1
	local.get	2
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label732
	br      	5                               # 5: down to label629
.LBB30_257:                             #   in Loop: Header=BB30_240 Depth=1
	end_block                               # label734:
	local.get	2
	i32.const	2
	i32.add 
	local.set	10
	br      	1                               # 1: down to label732
.LBB30_258:                             #   in Loop: Header=BB30_240 Depth=1
	end_block                               # label733:
	local.get	14
	i32.const	32
	i32.lt_u
	br_if   	3                               # 3: down to label629
# %bb.259:                              #   in Loop: Header=BB30_240 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.set	10
	local.get	14
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label731
.LBB30_260:                             #   in Loop: Header=BB30_240 Depth=1
	end_block                               # label732:
	local.get	10
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label729
	br      	2                               # 2: down to label629
.LBB30_261:
	end_block                               # label731:
	end_loop
	local.get	3
	local.get	11
	i32.store	24
	local.get	3
	local.get	10
	local.get	11
	i32.sub 
	i32.store	28
	local.get	12
	local.get	10
	i32.store	8
	local.get	12
	local.get	10
	i32.store	12
	local.get	0
	local.get	1
	local.get	12
	i32.const	12
	i32.add 
	call	next_format3_field
	i32.eqz
	br_if   	0                               # 0: down to label629
# %bb.262:
	local.get	0
	local.get	1
	local.get	12
	i32.load	12
	local.tee	2
	local.get	12
	i32.const	8
	i32.add 
	call	scan_scalar_span
	i32.eqz
	br_if   	0                               # 0: down to label629
# %bb.263:
	local.get	0
	local.get	2
	local.get	12
	i32.load	8
	local.tee	10
	call	is_valid_json_number
	i32.eqz
	br_if   	0                               # 0: down to label629
# %bb.264:
	local.get	3
	local.get	2
	i32.store	32
	local.get	12
	local.get	10
	i32.store	12
	local.get	0
	local.get	1
	local.get	12
	i32.const	12
	i32.add 
	call	next_format3_field
	i32.eqz
	br_if   	0                               # 0: down to label629
# %bb.265:
	local.get	0
	local.get	12
	i32.load	12
	local.tee	2
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label629
# %bb.266:
	i32.const	0
	local.set	13
	local.get	3
	i32.const	0
	i32.store	64
	local.get	3
	i64.const	0
	i64.store	56:p2align=2
	block   	
	block   	
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label740
# %bb.267:
	local.get	0
	local.get	1
	local.get	2
	local.get	6
	local.get	7
	local.get	3
	local.get	12
	i32.const	8
	i32.add 
	local.get	8
	local.get	9
	call	reuse_validated_glossary
	br_if   	1                               # 1: down to label739
.LBB30_268:
	end_block                               # label740:
	local.get	0
	local.get	1
	local.get	2
	local.get	12
	i32.const	8
	i32.add 
	local.get	3
	i32.const	56
	i32.add 
	i32.const	0
	local.get	4
	i32.select
	local.get	3
	i32.const	60
	i32.add 
	local.get	3
	i32.const	64
	i32.add 
	i32.const	1
	call	parse_value_span_with_glossary_hints
	i32.eqz
	br_if   	1                               # 1: down to label629
.LBB30_269:
	end_block                               # label739:
	local.get	3
	local.get	2
	i32.store	36
	local.get	3
	local.get	12
	i32.load	8
	local.tee	10
	local.get	2
	i32.sub 
	i32.store	40
	local.get	12
	local.get	10
	i32.store	12
	i32.const	0
	local.set	13
	local.get	0
	local.get	1
	local.get	12
	i32.const	12
	i32.add 
	call	next_format3_field
	i32.eqz
	br_if   	0                               # 0: down to label629
# %bb.270:
	local.get	0
	local.get	1
	local.get	12
	i32.load	12
	local.tee	2
	local.get	12
	i32.const	8
	i32.add 
	call	scan_scalar_span
	i32.eqz
	br_if   	0                               # 0: down to label629
# %bb.271:
	block   	
	block   	
	local.get	12
	i32.load	8
	local.tee	10
	local.get	2
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label742
# %bb.272:
	local.get	0
	local.get	2
	i32.add 
	local.tee	4
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label742
# %bb.273:
	local.get	4
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label742
# %bb.274:
	local.get	4
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label742
# %bb.275:
	i32.const	-1
	local.set	14
	local.get	4
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label741
.LBB30_276:
	end_block                               # label742:
	local.get	2
	local.set	14
	local.get	0
	local.get	2
	local.get	10
	call	is_valid_json_number
	i32.eqz
	br_if   	1                               # 1: down to label629
.LBB30_277:
	end_block                               # label741:
	local.get	3
	local.get	14
	i32.store	44
	local.get	12
	local.get	10
	i32.store	12
	local.get	0
	local.get	1
	local.get	12
	i32.const	12
	i32.add 
	call	next_format3_field
	i32.eqz
	br_if   	0                               # 0: down to label629
# %bb.278:
	local.get	12
	i32.load	12
	local.tee	4
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label629
# %bb.279:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label629
# %bb.280:
	local.get	4
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label629
# %bb.281:
.LBB30_282:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label743:
	block   	
	local.get	10
	local.tee	2
	i32.const	8
	i32.add 
	local.tee	10
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label744
# %bb.283:                              #   in Loop: Header=BB30_282 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i64.load	0:p2align=0
	local.tee	19
	i64.const	-1
	i64.xor 
	local.get	19
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	19
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	19
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	19
	i64.eqz
	br_if   	1                               # 1: up to label743
# %bb.284:                              #   in Loop: Header=BB30_282 Depth=1
	local.get	19
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	2
	i32.add 
	local.set	2
.LBB30_285:                             #   in Loop: Header=BB30_282 Depth=1
	end_block                               # label744:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label629
# %bb.286:                              #   in Loop: Header=BB30_282 Depth=1
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label747
# %bb.287:                              #   in Loop: Header=BB30_282 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	4                               # 4: down to label629
# %bb.288:                              #   in Loop: Header=BB30_282 Depth=1
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 1, 6, 6, 6, 6, 6, 1, 6, 6, 6, 1, 6, 6, 6, 6, 6, 6, 6, 1, 6, 6, 6, 1, 6, 1, 0, 6} # 6: down to label629
                                        # 1: down to label748
                                        # 0: down to label749
.LBB30_289:                             #   in Loop: Header=BB30_282 Depth=1
	end_block                               # label749:
	local.get	2
	i32.const	6
	i32.add 
	local.tee	10
	local.get	1
	i32.gt_u
	br_if   	5                               # 5: down to label629
# %bb.290:                              #   in Loop: Header=BB30_282 Depth=1
	local.get	2
	i32.const	2
	i32.add 
	local.tee	14
	local.get	10
	i32.ge_u
	br_if   	2                               # 2: down to label746
# %bb.291:                              #   in Loop: Header=BB30_282 Depth=1
	block   	
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label750
# %bb.292:                              #   in Loop: Header=BB30_282 Depth=1
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label629
.LBB30_293:                             #   in Loop: Header=BB30_282 Depth=1
	end_block                               # label750:
	block   	
	local.get	17
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label751
# %bb.294:                              #   in Loop: Header=BB30_282 Depth=1
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label629
.LBB30_295:                             #   in Loop: Header=BB30_282 Depth=1
	end_block                               # label751:
	block   	
	local.get	16
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	14
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label752
# %bb.296:                              #   in Loop: Header=BB30_282 Depth=1
	local.get	14
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label629
.LBB30_297:                             #   in Loop: Header=BB30_282 Depth=1
	end_block                               # label752:
	local.get	15
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label746
# %bb.298:                              #   in Loop: Header=BB30_282 Depth=1
	local.get	2
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label746
	br      	5                               # 5: down to label629
.LBB30_299:                             #   in Loop: Header=BB30_282 Depth=1
	end_block                               # label748:
	local.get	2
	i32.const	2
	i32.add 
	local.set	10
	br      	1                               # 1: down to label746
.LBB30_300:                             #   in Loop: Header=BB30_282 Depth=1
	end_block                               # label747:
	local.get	14
	i32.const	32
	i32.lt_u
	br_if   	3                               # 3: down to label629
# %bb.301:                              #   in Loop: Header=BB30_282 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.set	10
	local.get	14
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label745
.LBB30_302:                             #   in Loop: Header=BB30_282 Depth=1
	end_block                               # label746:
	local.get	10
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label743
	br      	2                               # 2: down to label629
.LBB30_303:
	end_block                               # label745:
	end_loop
	local.get	3
	local.get	4
	i32.store	48
	local.get	3
	local.get	10
	local.get	4
	i32.sub 
	i32.store	52
	block   	
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label753
# %bb.304:
.LBB30_305:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label754:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label753
# %bb.306:                              #   in Loop: Header=BB30_305 Depth=1
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label753
# %bb.307:                              #   in Loop: Header=BB30_305 Depth=1
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label754
	br      	2                               # 2: down to label629
.LBB30_308:
	end_loop
	end_block                               # label753:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label629
# %bb.309:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: down to label629
# %bb.310:
	i32.const	1
	local.set	13
	local.get	5
	local.get	10
	i32.const	1
	i32.add 
	i32.store	0
.LBB30_311:
	end_block                               # label629:
	local.get	12
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	13
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.scan_scalar_span,"",@
	.type	scan_scalar_span,@function      # -- Begin function scan_scalar_span
scan_scalar_span:                       # @scan_scalar_span
	.functype	scan_scalar_span (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	4
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label755
# %bb.1:
	local.get	2
	local.set	5
.LBB31_2:                               # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label757:
	block   	
	local.get	1
	local.get	5
	local.tee	6
	i32.ne  
	br_if   	0                               # 0: down to label758
# %bb.3:
	local.get	1
	local.set	6
	br      	2                               # 2: down to label756
.LBB31_4:                               #   in Loop: Header=BB31_2 Depth=1
	end_block                               # label758:
	block   	
	block   	
	local.get	0
	local.get	6
	i32.add 
	i32.load8_u	0
	local.tee	7
	i32.const	-10
	i32.add 
	br_table 	{3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0} # 1: down to label759
                                        # 3: down to label756
                                        # 0: down to label760
.LBB31_5:                               #   in Loop: Header=BB31_2 Depth=1
	end_block                               # label760:
	local.get	7
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label756
# %bb.6:                                #   in Loop: Header=BB31_2 Depth=1
	local.get	7
	i32.const	125
	i32.eq  
	br_if   	2                               # 2: down to label756
.LBB31_7:                               #   in Loop: Header=BB31_2 Depth=1
	end_block                               # label759:
	local.get	6
	i32.const	1
	i32.add 
	local.set	5
	local.get	7
	i32.const	9
	i32.ne  
	br_if   	0                               # 0: up to label757
.LBB31_8:
	end_loop
	end_block                               # label756:
	local.get	6
	local.get	2
	i32.eq  
	br_if   	0                               # 0: down to label755
# %bb.9:
	local.get	3
	local.get	6
	i32.store	0
	i32.const	1
	local.set	4
.LBB31_10:
	end_block                               # label755:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_int32_token,"",@
	.type	parse_int32_token,@function     # -- Begin function parse_int32_token
parse_int32_token:                      # @parse_int32_token
	.functype	parse_int32_token (i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32
# %bb.0:
	block   	
	block   	
	block   	
	local.get	2
	local.get	1
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label763
# %bb.1:
	local.get	0
	local.get	1
	i32.add 
	local.tee	5
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label763
# %bb.2:
	local.get	5
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label763
# %bb.3:
	local.get	5
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label763
# %bb.4:
	local.get	5
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label762
.LBB32_5:
	end_block                               # label763:
	i32.const	1
	local.set	6
	block   	
	local.get	2
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label764
# %bb.6:
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	3
	i32.const	45
	i32.ne  
	local.set	6
	local.get	1
	local.get	3
	i32.const	45
	i32.eq  
	i32.add 
	local.set	1
.LBB32_7:
	end_block                               # label764:
	i32.const	0
	local.set	5
	local.get	2
	local.get	1
	i32.le_u
	br_if   	1                               # 1: down to label761
# %bb.8:
	local.get	0
	local.get	1
	i32.add 
	local.tee	0
	i32.load8_u	0
	local.tee	3
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	246
	i32.lt_u
	br_if   	1                               # 1: down to label761
# %bb.9:
	block   	
	local.get	1
	i32.const	1
	i32.add 
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label765
# %bb.10:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	48
	i32.eq  
	br_if   	2                               # 2: down to label761
.LBB32_11:
	end_block                               # label765:
	i32.const	2147483647
	i32.const	-2147483648
	local.get	6
	i32.select
	local.set	7
	local.get	2
	local.get	1
	i32.sub 
	local.set	3
	i32.const	0
	local.set	5
	i32.const	0
	local.set	1
.LBB32_12:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label766:
	local.get	0
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	246
	i32.lt_u
	br_if   	2                               # 2: down to label761
# %bb.13:                               #   in Loop: Header=BB32_12 Depth=1
	local.get	1
	local.get	7
	local.get	2
	i32.const	-48
	i32.add 
	local.tee	2
	i32.sub 
	i32.const	10
	i32.div_u
	i32.gt_u
	br_if   	2                               # 2: down to label761
# %bb.14:                               #   in Loop: Header=BB32_12 Depth=1
	local.get	0
	i32.const	1
	i32.add 
	local.set	0
	local.get	2
	local.get	1
	i32.const	10
	i32.mul 
	i32.add 
	local.set	1
	local.get	3
	i32.const	-1
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label766
# %bb.15:
	end_loop
	local.get	1
	i32.const	0
	local.get	1
	i32.sub 
	local.get	6
	i32.select
	local.set	3
.LBB32_16:
	end_block                               # label762:
	local.get	4
	local.get	3
	i32.store	0
	i32.const	1
	local.set	5
.LBB32_17:
	end_block                               # label761:
	local.get	5
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.raw_term_content_hash,"",@
	.type	raw_term_content_hash,@function # -- Begin function raw_term_content_hash
raw_term_content_hash:                  # @raw_term_content_hash
	.functype	raw_term_content_hash (i32, i32) -> (i32)
	.local  	i32, i32, i32
# %bb.0:
	local.get	0
	local.get	1
	i32.load	36
	i32.add 
	local.get	1
	i32.load	40
	i32.const	-2128831035
	call	hash_content_xxh32
	local.set	2
	local.get	0
	local.get	1
	i32.load	24
	i32.add 
	local.get	1
	i32.load	28
	i32.const	-1640531527
	call	hash_content_xxh32
	local.set	3
	local.get	0
	local.get	1
	i32.load	16
	i32.add 
	local.get	1
	i32.load	20
	i32.const	-2048144789
	call	hash_content_xxh32
	local.set	4
	i32.const	1
	local.get	0
	local.get	1
	i32.load	48
	i32.add 
	local.get	1
	i32.load	52
	i32.const	-1028477387
	call	hash_content_xxh32
	i32.const	17
	i32.rotl
	local.tee	1
	local.get	2
	local.get	3
	i32.const	5
	i32.rotl
	i32.xor 
	local.get	4
	i32.const	11
	i32.rotl
	i32.xor 
	local.tee	0
	i32.xor 
	local.tee	2
	i32.const	16
	i32.shr_u
	local.get	2
	i32.xor 
	local.get	0
	local.get	1
	i32.eq  
	i32.select
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.raw_term_content_tokens_equal,"",@
	.type	raw_term_content_tokens_equal,@function # -- Begin function raw_term_content_tokens_equal
raw_term_content_tokens_equal:          # @raw_term_content_tokens_equal
	.functype	raw_term_content_tokens_equal (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i64, i64, i32
# %bb.0:
	i32.const	0
	local.set	4
	block   	
	local.get	1
	i32.load	40
	local.tee	5
	local.get	2
	i32.load	40
	i32.ne  
	br_if   	0                               # 0: down to label767
# %bb.1:
	block   	
	block   	
	local.get	3
	br_if   	0                               # 0: down to label769
# %bb.2:
	local.get	0
	local.get	2
	i32.load	36
	i32.add 
	local.set	6
	local.get	0
	local.get	1
	i32.load	36
	i32.add 
	local.set	7
	i32.const	0
	local.set	3
	local.get	5
	local.set	8
.LBB34_3:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label770:
	block   	
	local.get	8
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label771
# %bb.4:
	i32.const	0
	local.get	3
	i32.sub 
	local.set	8
	local.get	6
	local.get	3
	i32.add 
	local.set	9
	local.get	7
	local.get	3
	i32.add 
	local.set	3
.LBB34_5:                               # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label773:
	block   	
	local.get	5
	local.get	8
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label774
# %bb.6:
	i32.const	0
	local.get	8
	i32.sub 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	5                               # 5: down to label769
# %bb.7:
	br      	2                               # 2: down to label772
.LBB34_8:                               #   in Loop: Header=BB34_5 Depth=1
	end_block                               # label774:
	local.get	8
	i32.const	-8
	i32.add 
	local.set	8
	local.get	9
	i64.load	0:p2align=0
	local.set	10
	local.get	3
	i64.load	0:p2align=0
	local.set	11
	local.get	3
	i32.const	8
	i32.add 
	local.set	3
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	local.get	10
	i64.eq  
	br_if   	0                               # 0: up to label773
	br      	5                               # 5: down to label768
.LBB34_9:                               # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label772:
	loop    	                                # label775:
	local.get	7
	local.get	3
	i32.add 
	i32.load8_u	0
	local.get	6
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	4                               # 4: down to label768
# %bb.10:                               #   in Loop: Header=BB34_9 Depth=1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label769
	br      	0                               # 0: up to label775
.LBB34_11:                              #   in Loop: Header=BB34_3 Depth=1
	end_loop
	end_block                               # label771:
	local.get	7
	local.get	3
	i32.add 
	local.set	9
	local.get	6
	local.get	3
	i32.add 
	local.set	12
	local.get	8
	i32.const	-32
	i32.add 
	local.set	8
	local.get	3
	i32.const	32
	i32.add 
	local.set	3
	local.get	12
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	9
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	12
	v128.load	0:p2align=0
	local.get	9
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label770
	br      	2                               # 2: down to label768
.LBB34_12:
	end_loop
	end_block                               # label769:
	local.get	1
	i32.load	28
	local.tee	5
	local.get	2
	i32.load	28
	i32.ne  
	br_if   	1                               # 1: down to label767
# %bb.13:
	local.get	0
	local.get	2
	i32.load	24
	i32.add 
	local.set	6
	local.get	0
	local.get	1
	i32.load	24
	i32.add 
	local.set	7
	i32.const	0
	local.set	3
	local.get	5
	local.set	8
.LBB34_14:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label776:
	block   	
	local.get	8
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label777
# %bb.15:
	i32.const	0
	local.get	3
	i32.sub 
	local.set	8
	local.get	6
	local.get	3
	i32.add 
	local.set	9
	local.get	7
	local.get	3
	i32.add 
	local.set	3
.LBB34_16:                              # =>This Inner Loop Header: Depth=1
	block   	
	block   	
	loop    	                                # label780:
	block   	
	local.get	5
	local.get	8
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label781
# %bb.17:
	i32.const	0
	local.set	4
	i32.const	0
	local.get	8
	i32.sub 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label778
# %bb.18:
	br      	2                               # 2: down to label779
.LBB34_19:                              #   in Loop: Header=BB34_16 Depth=1
	end_block                               # label781:
	local.get	8
	i32.const	-8
	i32.add 
	local.set	8
	local.get	9
	i64.load	0:p2align=0
	local.set	10
	local.get	3
	i64.load	0:p2align=0
	local.set	11
	local.get	3
	i32.const	8
	i32.add 
	local.set	3
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	local.get	10
	i64.eq  
	br_if   	0                               # 0: up to label780
	br      	5                               # 5: down to label768
.LBB34_20:                              # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label779:
	loop    	                                # label782:
	local.get	7
	local.get	3
	i32.add 
	i32.load8_u	0
	local.get	6
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	5                               # 5: down to label767
# %bb.21:                               #   in Loop: Header=BB34_20 Depth=1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: up to label782
.LBB34_22:
	end_loop
	end_block                               # label778:
	local.get	1
	i32.load	20
	local.tee	5
	local.get	2
	i32.load	20
	i32.ne  
	br_if   	3                               # 3: down to label767
# %bb.23:
	local.get	0
	local.get	2
	i32.load	16
	i32.add 
	local.set	6
	local.get	0
	local.get	1
	i32.load	16
	i32.add 
	local.set	7
	i32.const	0
	local.set	3
	local.get	5
	local.set	8
.LBB34_24:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label783:
	block   	
	local.get	8
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label784
# %bb.25:
	i32.const	0
	local.get	3
	i32.sub 
	local.set	8
	local.get	6
	local.get	3
	i32.add 
	local.set	9
	local.get	7
	local.get	3
	i32.add 
	local.set	3
.LBB34_26:                              # =>This Inner Loop Header: Depth=1
	block   	
	block   	
	loop    	                                # label787:
	block   	
	local.get	5
	local.get	8
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label788
# %bb.27:
	i32.const	0
	local.set	4
	i32.const	0
	local.get	8
	i32.sub 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label785
# %bb.28:
	br      	2                               # 2: down to label786
.LBB34_29:                              #   in Loop: Header=BB34_26 Depth=1
	end_block                               # label788:
	local.get	8
	i32.const	-8
	i32.add 
	local.set	8
	local.get	9
	i64.load	0:p2align=0
	local.set	10
	local.get	3
	i64.load	0:p2align=0
	local.set	11
	i32.const	0
	local.set	4
	local.get	3
	i32.const	8
	i32.add 
	local.set	3
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	local.get	10
	i64.eq  
	br_if   	0                               # 0: up to label787
	br      	8                               # 8: down to label767
.LBB34_30:                              # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label786:
	loop    	                                # label789:
	local.get	7
	local.get	3
	i32.add 
	i32.load8_u	0
	local.get	6
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	7                               # 7: down to label767
# %bb.31:                               #   in Loop: Header=BB34_30 Depth=1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: up to label789
.LBB34_32:
	end_loop
	end_block                               # label785:
	local.get	1
	i32.load	52
	local.tee	5
	local.get	2
	i32.load	52
	i32.ne  
	br_if   	5                               # 5: down to label767
# %bb.33:
	local.get	0
	local.get	2
	i32.load	48
	i32.add 
	local.set	6
	local.get	0
	local.get	1
	i32.load	48
	i32.add 
	local.set	7
	i32.const	0
	local.set	3
	local.get	5
	local.set	8
.LBB34_34:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label790:
	block   	
	local.get	8
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label791
# %bb.35:
	i32.const	0
	local.get	3
	i32.sub 
	local.set	8
	local.get	6
	local.get	3
	i32.add 
	local.set	9
	local.get	7
	local.get	3
	i32.add 
	local.set	3
.LBB34_36:                              # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label793:
	block   	
	local.get	5
	local.get	8
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label794
# %bb.37:
	i32.const	0
	local.get	8
	i32.sub 
	local.tee	3
	local.get	5
	i32.lt_u
	br_if   	2                               # 2: down to label792
# %bb.38:
	i32.const	1
	return
.LBB34_39:                              #   in Loop: Header=BB34_36 Depth=1
	end_block                               # label794:
	local.get	8
	i32.const	-8
	i32.add 
	local.set	8
	local.get	9
	i64.load	0:p2align=0
	local.set	10
	local.get	3
	i64.load	0:p2align=0
	local.set	11
	i32.const	0
	local.set	4
	local.get	3
	i32.const	8
	i32.add 
	local.set	3
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	local.get	10
	i64.eq  
	br_if   	0                               # 0: up to label793
	br      	9                               # 9: down to label767
.LBB34_40:                              # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label792:
	loop    	                                # label795:
	local.get	7
	local.get	3
	i32.add 
	i32.load8_u	0
	local.get	6
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	7                               # 7: down to label768
# %bb.41:                               #   in Loop: Header=BB34_40 Depth=1
	i32.const	1
	local.set	4
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	8                               # 8: down to label767
	br      	0                               # 0: up to label795
.LBB34_42:                              #   in Loop: Header=BB34_34 Depth=1
	end_loop
	end_block                               # label791:
	local.get	7
	local.get	3
	i32.add 
	local.set	9
	local.get	6
	local.get	3
	i32.add 
	local.set	12
	local.get	8
	i32.const	-32
	i32.add 
	local.set	8
	local.get	3
	i32.const	32
	i32.add 
	local.set	3
	i32.const	0
	local.set	4
	local.get	12
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	9
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	12
	v128.load	0:p2align=0
	local.get	9
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label790
	br      	6                               # 6: down to label767
.LBB34_43:                              #   in Loop: Header=BB34_24 Depth=1
	end_loop
	end_block                               # label784:
	local.get	7
	local.get	3
	i32.add 
	local.set	9
	local.get	6
	local.get	3
	i32.add 
	local.set	12
	local.get	8
	i32.const	-32
	i32.add 
	local.set	8
	local.get	3
	i32.const	32
	i32.add 
	local.set	3
	i32.const	0
	local.set	4
	local.get	12
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	9
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	12
	v128.load	0:p2align=0
	local.get	9
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label783
	br      	4                               # 4: down to label767
.LBB34_44:                              #   in Loop: Header=BB34_14 Depth=1
	end_loop
	end_block                               # label777:
	local.get	7
	local.get	3
	i32.add 
	local.set	9
	local.get	6
	local.get	3
	i32.add 
	local.set	12
	local.get	8
	i32.const	-32
	i32.add 
	local.set	8
	local.get	3
	i32.const	32
	i32.add 
	local.set	3
	local.get	12
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	9
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	12
	v128.load	0:p2align=0
	local.get	9
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label776
.LBB34_45:
	end_loop
	end_block                               # label768:
	i32.const	0
	local.set	4
.LBB34_46:
	end_block                               # label767:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.raw_term_content_quick_signature,"",@
	.type	raw_term_content_quick_signature,@function # -- Begin function raw_term_content_quick_signature
raw_term_content_quick_signature:       # @raw_term_content_quick_signature
	.functype	raw_term_content_quick_signature (i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	2
	block   	
	block   	
	local.get	1
	i32.load	40
	local.tee	3
	br_if   	0                               # 0: down to label797
# %bb.1:
	i32.const	0
	local.set	4
	i32.const	0
	local.set	5
	br      	1                               # 1: down to label796
.LBB35_2:
	end_block                               # label797:
	local.get	0
	local.get	1
	i32.load	36
	local.tee	6
	i32.add 
	local.set	7
	block   	
	block   	
	local.get	3
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label799
# %bb.3:
	local.get	7
	i32.load8_u	0
	local.set	2
	local.get	3
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label798
# %bb.4:
	local.get	7
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	8
	i32.shl 
	local.get	2
	i32.or  
	local.set	2
	local.get	3
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label798
# %bb.5:
	local.get	7
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	16
	i32.shl 
	local.get	2
	i32.or  
	local.set	2
	br      	1                               # 1: down to label798
.LBB35_6:
	end_block                               # label799:
	local.get	7
	i32.load	0:p2align=0
	local.set	4
	block   	
	local.get	3
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label800
# %bb.7:
	local.get	4
	local.set	2
	local.get	4
	local.set	5
	br      	2                               # 2: down to label796
.LBB35_8:
	end_block                               # label800:
	i32.const	0
	local.get	3
	i32.const	-4
	i32.add 
	local.tee	2
	local.get	2
	local.get	3
	i32.gt_u
	i32.select
	local.set	8
	i32.const	0
	local.set	5
	i32.const	0
	local.set	2
	block   	
	local.get	3
	local.get	8
	i32.const	1
	i32.shr_u
	local.tee	9
	i32.le_u
	br_if   	0                               # 0: down to label801
# %bb.9:
	local.get	7
	local.get	9
	i32.add 
	local.set	10
	block   	
	local.get	3
	local.get	9
	i32.sub 
	local.tee	11
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label802
# %bb.10:
	i32.const	0
	local.set	9
	i32.const	0
	local.set	2
.LBB35_11:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label803:
	local.get	10
	i32.load8_u	0
	local.get	9
	i32.shl 
	local.get	2
	i32.or  
	local.set	2
	local.get	10
	i32.const	1
	i32.add 
	local.set	10
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	i32.const	-1
	i32.add 
	local.tee	11
	br_if   	0                               # 0: up to label803
	br      	2                               # 2: down to label801
.LBB35_12:
	end_loop
	end_block                               # label802:
	local.get	10
	i32.load	0:p2align=0
	local.set	2
.LBB35_13:
	end_block                               # label801:
	local.get	3
	local.get	8
	i32.le_u
	br_if   	1                               # 1: down to label796
# %bb.14:
	block   	
	local.get	3
	local.get	8
	i32.sub 
	local.tee	5
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label804
# %bb.15:
	i32.const	0
	local.set	10
	i32.const	0
	local.get	5
	i32.sub 
	local.set	9
	local.get	0
	local.get	3
	local.get	6
	i32.add 
	i32.add 
	local.set	0
	i32.const	0
	local.set	5
.LBB35_16:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label805:
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.get	10
	i32.shl 
	local.get	5
	i32.or  
	local.set	5
	local.get	10
	i32.const	8
	i32.add 
	local.set	10
	local.get	9
	i32.const	1
	i32.add 
	local.tee	11
	local.set	9
	local.get	11
	br_if   	0                               # 0: up to label805
	br      	3                               # 3: down to label796
.LBB35_17:
	end_loop
	end_block                               # label804:
	local.get	7
	local.get	8
	i32.add 
	i32.load	0:p2align=0
	local.set	5
	br      	1                               # 1: down to label796
.LBB35_18:
	end_block                               # label798:
	local.get	2
	local.set	4
	local.get	2
	local.set	5
.LBB35_19:
	end_block                               # label796:
	local.get	4
	local.get	3
	i32.const	-1640531535
	i32.mul 
	i32.xor 
	local.get	1
	i32.load	28
	i32.const	-2048144789
	i32.mul 
	i32.xor 
	local.get	1
	i32.load	20
	i32.const	-1028477387
	i32.mul 
	i32.xor 
	local.get	1
	i32.load	52
	i32.const	668265263
	i32.mul 
	i32.xor 
	i32.const	13
	i32.rotl
	local.get	2
	i32.const	374761393
	i32.mul 
	i32.xor 
	i32.const	11
	i32.rotl
	local.get	5
	i32.xor 
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.next_term_row,"",@
	.type	next_term_row,@function         # -- Begin function next_term_row
next_term_row:                          # @next_term_row
	.functype	next_term_row (i32, i32) -> (i32)
	.local  	i32, i32, i32, i32
# %bb.0:
	local.get	0
	i32.load	0
	local.set	2
	block   	
	local.get	1
	local.get	0
	i32.load	20
	local.tee	3
	i32.ge_u
	br_if   	0                               # 0: down to label806
# %bb.1:
.LBB36_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label807:
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label806
# %bb.3:                                #   in Loop: Header=BB36_2 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label806
# %bb.4:                                #   in Loop: Header=BB36_2 Depth=1
	local.get	3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	0                               # 0: up to label807
# %bb.5:
	end_loop
	i32.const	-1
	return
.LBB36_6:
	end_block                               # label806:
	i32.const	-1
	local.set	5
	block   	
	local.get	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label808
# %bb.7:
	block   	
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	4
	i32.const	44
	i32.eq  
	br_if   	0                               # 0: down to label809
# %bb.8:
	local.get	4
	i32.const	93
	i32.ne  
	br_if   	1                               # 1: down to label808
# %bb.9:
	block   	
	block   	
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label811
# %bb.10:
.LBB36_11:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label812:
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label811
# %bb.12:                               #   in Loop: Header=BB36_11 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label811
# %bb.13:                               #   in Loop: Header=BB36_11 Depth=1
	local.get	3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	0                               # 0: up to label812
	br      	2                               # 2: down to label810
.LBB36_14:
	end_loop
	end_block                               # label811:
	local.get	1
	local.get	3
	i32.ne  
	br_if   	2                               # 2: down to label808
.LBB36_15:
	end_block                               # label810:
	local.get	0
	call	next_term_bank
	return
.LBB36_16:
	end_block                               # label809:
	block   	
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label813
# %bb.17:
.LBB36_18:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label814:
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label813
# %bb.19:                               #   in Loop: Header=BB36_18 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label813
# %bb.20:                               #   in Loop: Header=BB36_18 Depth=1
	local.get	3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	0                               # 0: up to label814
	br      	2                               # 2: down to label808
.LBB36_21:
	end_loop
	end_block                               # label813:
	local.get	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label808
# %bb.22:
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.eq  
	br_if   	0                               # 0: down to label808
# %bb.23:
	local.get	0
	local.get	1
	i32.store	24
	i32.const	1
	local.set	5
.LBB36_24:
	end_block                               # label808:
	local.get	5
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.compact_term_lookup_keys,"",@
	.globl	compact_term_lookup_keys        # -- Begin function compact_term_lookup_keys
	.type	compact_term_lookup_keys,@function
compact_term_lookup_keys:               # @compact_term_lookup_keys
	.functype	compact_term_lookup_keys (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, v128, v128, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-1
	local.set	20
	block   	
	local.get	5
	i32x4.splat
	local.get	0
	i32x4.replace_lane	1
	local.get	2
	i32x4.replace_lane	2
	local.get	3
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	21
	i32x4.eq
	v128.const	255, 255, 255, 255
	local.tee	22
	v128.and
	local.get	4
	i32x4.splat
	local.get	6
	i32x4.replace_lane	1
	local.get	7
	i32x4.replace_lane	2
	local.get	8
	i32x4.replace_lane	3
	local.get	21
	i32x4.eq
	local.get	22
	v128.and
	i16x8.narrow_i32x4_u
	local.get	10
	i32x4.splat
	local.get	19
	i32x4.replace_lane	1
	local.get	11
	i32x4.replace_lane	2
	local.get	12
	i32x4.replace_lane	3
	local.get	21
	i32x4.eq
	local.get	22
	v128.and
	local.get	13
	i32x4.splat
	local.get	14
	i32x4.replace_lane	1
	local.get	15
	i32x4.replace_lane	2
	local.get	16
	i32x4.replace_lane	3
	local.get	21
	i32x4.eq
	local.get	22
	v128.and
	i16x8.narrow_i32x4_u
	i8x16.narrow_i16x8_u
	v128.any_true
	br_if   	0                               # 0: down to label815
# %bb.1:
	local.get	18
	i32.const	65534
	i32.gt_u
	br_if   	0                               # 0: down to label815
# %bb.2:
	local.get	5
	i32.const	1073741823
	i32.gt_u
	br_if   	0                               # 0: down to label815
# %bb.3:
	local.get	9
	i32.const	-65535
	i32.add 
	i32.const	-65534
	i32.lt_u
	br_if   	0                               # 0: down to label815
# %bb.4:
	i32.const	0
	local.set	23
	local.get	3
	local.set	24
	local.get	2
	local.set	25
	local.get	5
	local.set	26
.LBB37_5:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label816:
	i32.const	-2
	local.set	20
	local.get	1
	local.get	23
	i32.lt_u
	br_if   	1                               # 1: down to label815
# %bb.6:                                #   in Loop: Header=BB37_5 Depth=1
	local.get	24
	i32.load	0
	local.get	23
	i32.ne  
	br_if   	1                               # 1: down to label815
# %bb.7:                                #   in Loop: Header=BB37_5 Depth=1
	local.get	1
	local.get	23
	i32.sub 
	local.get	25
	i32.load16_u	0
	local.tee	27
	i32.lt_u
	br_if   	1                               # 1: down to label815
# %bb.8:                                #   in Loop: Header=BB37_5 Depth=1
	local.get	24
	i32.const	4
	i32.add 
	local.set	24
	local.get	25
	i32.const	2
	i32.add 
	local.set	25
	local.get	23
	local.get	27
	i32.add 
	local.set	23
	local.get	26
	i32.const	-1
	i32.add 
	local.tee	26
	br_if   	0                               # 0: up to label816
# %bb.9:
	end_loop
	local.get	23
	local.get	1
	i32.ne  
	br_if   	0                               # 0: down to label815
# %bb.10:
	i32.const	0
	local.set	23
	block   	
	local.get	5
	i32.const	2
	i32.shl 
	local.tee	24
	i32.eqz
	br_if   	0                               # 0: down to label817
# %bb.11:
	local.get	10
	i32.const	0
	local.get	24
	memory.fill	0
.LBB37_12:
	end_block                               # label817:
	i32.const	0
	local.set	25
	block   	
	local.get	9
	i32.eqz
	br_if   	0                               # 0: down to label818
# %bb.13:
	i32.const	0
	local.set	25
	i32.const	0
	local.set	23
.LBB37_14:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label819:
	block   	
	local.get	8
	i32.load8_u	0
	local.tee	24
	i32.const	1
	i32.le_u
	br_if   	0                               # 0: down to label820
# %bb.15:
	i32.const	-3
	return
.LBB37_16:                              #   in Loop: Header=BB37_14 Depth=1
	end_block                               # label820:
	block   	
	local.get	6
	i32.load	0
	local.tee	1
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: down to label821
# %bb.17:
	i32.const	-3
	return
.LBB37_18:                              #   in Loop: Header=BB37_14 Depth=1
	end_block                               # label821:
	block   	
	local.get	2
	local.get	1
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	27
	i32.load16_u	0
	local.tee	26
	br_if   	0                               # 0: down to label822
# %bb.19:
	i32.const	-3
	return
.LBB37_20:                              #   in Loop: Header=BB37_14 Depth=1
	end_block                               # label822:
	local.get	6
	local.get	7
	local.get	24
	i32.select
	i32.load	0
	local.set	24
	block   	
	local.get	10
	local.get	1
	i32.const	2
	i32.shl 
	local.tee	28
	i32.add 
	local.tee	29
	i32.load	0
	local.tee	1
	br_if   	0                               # 0: down to label823
# %bb.21:                               #   in Loop: Header=BB37_14 Depth=1
	i32.const	-4
	local.set	20
	local.get	23
	local.get	18
	i32.ge_u
	br_if   	3                               # 3: down to label815
# %bb.22:                               #   in Loop: Header=BB37_14 Depth=1
	local.get	17
	local.get	25
	i32.sub 
	local.get	26
	i32.lt_u
	br_if   	3                               # 3: down to label815
# %bb.23:                               #   in Loop: Header=BB37_14 Depth=1
	local.get	12
	local.get	23
	i32.const	2
	i32.shl 
	local.tee	1
	i32.add 
	local.get	25
	i32.store	0
	local.get	13
	local.get	1
	i32.add 
	local.get	4
	local.get	28
	i32.add 
	i32.load	0
	i32.store	0
	local.get	11
	local.get	23
	i32.const	1
	i32.shl 
	i32.add 
	local.get	26
	i32.store16	0
	block   	
	local.get	27
	i32.load16_u	0
	local.tee	1
	i32.eqz
	br_if   	0                               # 0: down to label824
# %bb.24:                               #   in Loop: Header=BB37_14 Depth=1
	local.get	16
	local.get	25
	i32.add 
	local.get	0
	local.get	3
	local.get	28
	i32.add 
	i32.load	0
	i32.add 
	local.get	1
	memory.copy	0, 0
.LBB37_25:                              #   in Loop: Header=BB37_14 Depth=1
	end_block                               # label824:
	local.get	29
	local.get	23
	i32.const	1
	i32.add 
	local.tee	23
	i32.store	0
	local.get	25
	local.get	27
	i32.load16_u	0
	i32.add 
	local.set	25
	local.get	23
	local.set	1
.LBB37_26:                              #   in Loop: Header=BB37_14 Depth=1
	end_block                               # label823:
	local.get	14
	local.get	1
	i32.const	-1
	i32.add 
	i32.store	0
	block   	
	local.get	24
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: down to label825
# %bb.27:
	i32.const	-3
	return
.LBB37_28:                              #   in Loop: Header=BB37_14 Depth=1
	end_block                               # label825:
	i32.const	-3
	local.set	20
	local.get	2
	local.get	24
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	26
	i32.load16_u	0
	local.tee	1
	i32.eqz
	br_if   	2                               # 2: down to label815
# %bb.29:                               #   in Loop: Header=BB37_14 Depth=1
	block   	
	local.get	10
	local.get	24
	i32.const	2
	i32.shl 
	local.tee	27
	i32.add 
	local.tee	28
	i32.load	0
	local.tee	24
	br_if   	0                               # 0: down to label826
# %bb.30:                               #   in Loop: Header=BB37_14 Depth=1
	i32.const	-4
	local.set	20
	local.get	23
	local.get	18
	i32.ge_u
	br_if   	3                               # 3: down to label815
# %bb.31:                               #   in Loop: Header=BB37_14 Depth=1
	local.get	17
	local.get	25
	i32.sub 
	local.get	1
	i32.lt_u
	br_if   	3                               # 3: down to label815
# %bb.32:                               #   in Loop: Header=BB37_14 Depth=1
	local.get	12
	local.get	23
	i32.const	2
	i32.shl 
	local.tee	24
	i32.add 
	local.get	25
	i32.store	0
	local.get	13
	local.get	24
	i32.add 
	local.get	4
	local.get	27
	i32.add 
	i32.load	0
	i32.store	0
	local.get	11
	local.get	23
	i32.const	1
	i32.shl 
	i32.add 
	local.get	1
	i32.store16	0
	block   	
	local.get	26
	i32.load16_u	0
	local.tee	24
	i32.eqz
	br_if   	0                               # 0: down to label827
# %bb.33:                               #   in Loop: Header=BB37_14 Depth=1
	local.get	16
	local.get	25
	i32.add 
	local.get	0
	local.get	3
	local.get	27
	i32.add 
	i32.load	0
	i32.add 
	local.get	24
	memory.copy	0, 0
.LBB37_34:                              #   in Loop: Header=BB37_14 Depth=1
	end_block                               # label827:
	local.get	28
	local.get	23
	i32.const	1
	i32.add 
	local.tee	23
	i32.store	0
	local.get	25
	local.get	26
	i32.load16_u	0
	i32.add 
	local.set	25
	local.get	23
	local.set	24
.LBB37_35:                              #   in Loop: Header=BB37_14 Depth=1
	end_block                               # label826:
	local.get	15
	local.get	24
	i32.const	-1
	i32.add 
	i32.store	0
	local.get	8
	i32.const	1
	i32.add 
	local.set	8
	local.get	6
	i32.const	4
	i32.add 
	local.set	6
	local.get	14
	i32.const	4
	i32.add 
	local.set	14
	local.get	15
	i32.const	4
	i32.add 
	local.set	15
	local.get	7
	i32.const	4
	i32.add 
	local.set	7
	local.get	9
	i32.const	-1
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label819
.LBB37_36:
	end_loop
	end_block                               # label818:
	local.get	19
	local.get	25
	i32.store	0
	local.get	23
	local.set	20
.LBB37_37:
	end_block                               # label815:
	local.get	20
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_value_span,"",@
	.type	parse_value_span,@function      # -- Begin function parse_value_span
parse_value_span:                       # @parse_value_span
	.functype	parse_value_span (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i64, i32
# %bb.0:
	i32.const	0
	local.set	4
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label828
# %bb.1:
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	5
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label829
# %bb.2:
	local.get	2
	i32.const	1
	i32.add 
	local.tee	5
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label828
# %bb.3:
	local.get	0
	i32.const	5
	i32.add 
	local.set	6
	local.get	0
	i32.const	4
	i32.add 
	local.set	7
	local.get	0
	i32.const	3
	i32.add 
	local.set	8
.LBB38_4:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label830:
	block   	
	local.get	5
	local.tee	2
	i32.const	8
	i32.add 
	local.tee	5
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label831
# %bb.5:                                #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i64.load	0:p2align=0
	local.tee	9
	i64.const	-1
	i64.xor 
	local.get	9
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	9
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	local.get	9
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	9
	i64.eqz
	br_if   	1                               # 1: up to label830
# %bb.6:                                #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	2
	i32.add 
	local.set	2
.LBB38_7:                               #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label831:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label828
# %bb.8:                                #   in Loop: Header=BB38_4 Depth=1
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label834
# %bb.9:                                #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	5
	local.get	1
	i32.ge_u
	br_if   	5                               # 5: down to label828
# %bb.10:                               #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	5
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{2, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 2, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 2, 6, 6, 6, 6, 6, 2, 6, 6, 6, 2, 6, 6, 6, 6, 6, 6, 6, 2, 6, 6, 6, 2, 6, 2, 0, 6} # 6: down to label828
                                        # 2: down to label833
                                        # 0: down to label835
.LBB38_11:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label835:
	local.get	2
	i32.const	6
	i32.add 
	local.tee	5
	local.get	1
	i32.gt_u
	br_if   	5                               # 5: down to label828
# %bb.12:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	i32.const	2
	i32.add 
	local.tee	10
	local.get	5
	i32.ge_u
	br_if   	2                               # 2: down to label832
# %bb.13:                               #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label836
# %bb.14:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label828
.LBB38_15:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label836:
	block   	
	local.get	8
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label837
# %bb.16:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label828
.LBB38_17:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label837:
	block   	
	local.get	7
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label838
# %bb.18:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label828
.LBB38_19:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label838:
	local.get	6
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label832
# %bb.20:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label832
	br      	5                               # 5: down to label828
.LBB38_21:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label834:
	local.get	10
	i32.const	32
	i32.lt_u
	br_if   	4                               # 4: down to label828
# %bb.22:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.set	5
	local.get	10
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label832
# %bb.23:
	local.get	3
	local.get	5
	i32.store	0
	i32.const	1
	return
.LBB38_24:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label833:
	local.get	2
	i32.const	2
	i32.add 
	local.set	5
.LBB38_25:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label832:
	local.get	5
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: up to label830
	br      	2                               # 2: down to label828
.LBB38_26:
	end_loop
	end_block                               # label829:
	block   	
	local.get	5
	i32.const	223
	i32.and 
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label839
# %bb.27:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	i32.const	0
	i32.const	0
	i32.const	0
	i32.const	0
	call	parse_composite_span_impl
	return
.LBB38_28:
	end_block                               # label839:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	call	parse_scalar_span
	local.set	4
.LBB38_29:
	end_block                               # label828:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_scalar_span,"",@
	.type	parse_scalar_span,@function     # -- Begin function parse_scalar_span
parse_scalar_span:                      # @parse_scalar_span
	.functype	parse_scalar_span (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	4
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label840
# %bb.1:
	local.get	2
	local.set	5
.LBB39_2:                               # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label842:
	block   	
	local.get	1
	local.get	5
	local.tee	6
	i32.ne  
	br_if   	0                               # 0: down to label843
# %bb.3:
	local.get	1
	local.set	6
	br      	2                               # 2: down to label841
.LBB39_4:                               #   in Loop: Header=BB39_2 Depth=1
	end_block                               # label843:
	block   	
	block   	
	local.get	0
	local.get	6
	i32.add 
	i32.load8_u	0
	local.tee	7
	i32.const	-10
	i32.add 
	br_table 	{3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0} # 1: down to label844
                                        # 3: down to label841
                                        # 0: down to label845
.LBB39_5:                               #   in Loop: Header=BB39_2 Depth=1
	end_block                               # label845:
	local.get	7
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label841
# %bb.6:                                #   in Loop: Header=BB39_2 Depth=1
	local.get	7
	i32.const	125
	i32.eq  
	br_if   	2                               # 2: down to label841
.LBB39_7:                               #   in Loop: Header=BB39_2 Depth=1
	end_block                               # label844:
	local.get	6
	i32.const	1
	i32.add 
	local.set	5
	local.get	7
	i32.const	9
	i32.ne  
	br_if   	0                               # 0: up to label842
.LBB39_8:
	end_loop
	end_block                               # label841:
	local.get	6
	local.get	2
	i32.eq  
	br_if   	0                               # 0: down to label840
# %bb.9:
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	local.tee	7
	i32.load8_u	0
	i32.const	-102
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 2, 3, 3, 3, 3, 3, 0, 3} # 3: down to label847
                                        # 2: down to label848
                                        # 0: down to label850
.LBB39_10:
	end_block                               # label850:
	local.get	6
	local.get	2
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	4                               # 4: down to label840
# %bb.11:
	local.get	7
	i32.load8_u	0
	i32.const	116
	i32.ne  
	br_if   	4                               # 4: down to label840
# %bb.12:
	local.get	7
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	114
	i32.ne  
	br_if   	4                               # 4: down to label840
# %bb.13:
	local.get	7
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	4                               # 4: down to label840
# %bb.14:
	local.get	7
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	101
	i32.eq  
	br_if   	3                               # 3: down to label846
	br      	4                               # 4: down to label840
.LBB39_15:
	end_block                               # label849:
	local.get	6
	local.get	2
	i32.sub 
	i32.const	5
	i32.ne  
	br_if   	3                               # 3: down to label840
# %bb.16:
	local.get	7
	i32.load8_u	0
	i32.const	102
	i32.ne  
	br_if   	3                               # 3: down to label840
# %bb.17:
	local.get	7
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	97
	i32.ne  
	br_if   	3                               # 3: down to label840
# %bb.18:
	local.get	7
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	3                               # 3: down to label840
# %bb.19:
	local.get	7
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	115
	i32.ne  
	br_if   	3                               # 3: down to label840
# %bb.20:
	local.get	7
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	101
	i32.eq  
	br_if   	2                               # 2: down to label846
	br      	3                               # 3: down to label840
.LBB39_21:
	end_block                               # label848:
	local.get	6
	local.get	2
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	2                               # 2: down to label840
# %bb.22:
	local.get	7
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	2                               # 2: down to label840
# %bb.23:
	local.get	7
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	2                               # 2: down to label840
# %bb.24:
	local.get	7
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	2                               # 2: down to label840
# %bb.25:
	local.get	7
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label846
	br      	2                               # 2: down to label840
.LBB39_26:
	end_block                               # label847:
	local.get	0
	local.get	2
	local.get	6
	call	is_valid_json_number
	i32.eqz
	br_if   	1                               # 1: down to label840
.LBB39_27:
	end_block                               # label846:
	local.get	3
	local.get	6
	i32.store	0
	i32.const	1
	local.set	4
.LBB39_28:
	end_block                               # label840:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.is_valid_json_number,"",@
	.type	is_valid_json_number,@function  # -- Begin function is_valid_json_number
is_valid_json_number:                   # @is_valid_json_number
	.functype	is_valid_json_number (i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32
# %bb.0:
	block   	
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label851
# %bb.1:
	local.get	1
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	45
	i32.eq  
	i32.add 
	local.set	1
.LBB40_2:
	end_block                               # label851:
	i32.const	0
	local.set	3
	block   	
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label852
# %bb.3:
	block   	
	block   	
	block   	
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	4
	i32.const	48
	i32.ne  
	br_if   	0                               # 0: down to label855
# %bb.4:
	local.get	1
	i32.const	1
	i32.add 
	local.tee	4
	local.get	2
	i32.ge_u
	br_if   	1                               # 1: down to label854
# %bb.5:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.ge_u
	br_if   	1                               # 1: down to label854
	br      	3                               # 3: down to label852
.LBB40_6:
	end_block                               # label855:
	local.get	4
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	247
	i32.lt_u
	br_if   	2                               # 2: down to label852
# %bb.7:
	local.get	0
	i32.const	1
	i32.add 
	local.set	5
	local.get	2
	i32.const	-1
	i32.add 
	local.set	6
.LBB40_8:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label856:
	block   	
	local.get	6
	local.get	1
	i32.ne  
	br_if   	0                               # 0: down to label857
# %bb.9:
	local.get	2
	local.set	4
	br      	3                               # 3: down to label853
.LBB40_10:                              #   in Loop: Header=BB40_8 Depth=1
	end_block                               # label857:
	local.get	5
	local.get	1
	i32.add 
	local.set	7
	local.get	1
	i32.const	1
	i32.add 
	local.tee	4
	local.set	1
	local.get	7
	i32.load8_u	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: up to label856
.LBB40_11:
	end_loop
	end_block                               # label854:
	block   	
	local.get	4
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label858
# %bb.12:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	46
	i32.ne  
	br_if   	0                               # 0: down to label858
# %bb.13:
	local.get	4
	i32.const	1
	i32.add 
	local.tee	1
	local.get	2
	i32.ge_u
	br_if   	2                               # 2: down to label852
# %bb.14:
	local.get	1
	local.set	4
.LBB40_15:                              # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label860:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	9
	i32.gt_u
	br_if   	1                               # 1: down to label859
# %bb.16:                               #   in Loop: Header=BB40_15 Depth=1
	local.get	2
	local.get	4
	i32.const	1
	i32.add 
	local.tee	4
	i32.ne  
	br_if   	0                               # 0: up to label860
# %bb.17:
	end_loop
	local.get	2
	local.set	4
.LBB40_18:
	end_block                               # label859:
	local.get	4
	local.get	1
	i32.eq  
	br_if   	2                               # 2: down to label852
.LBB40_19:
	end_block                               # label858:
	local.get	4
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label853
# %bb.20:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.or  
	i32.const	101
	i32.ne  
	br_if   	0                               # 0: down to label853
# %bb.21:
	block   	
	local.get	4
	i32.const	1
	i32.add 
	local.tee	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label861
# %bb.22:
	block   	
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-43
	i32.add 
	br_table 	{0, 1, 0, 1}            # 1: down to label861
                                        # 0: down to label862
.LBB40_23:
	end_block                               # label862:
	local.get	4
	i32.const	2
	i32.add 
	local.set	1
.LBB40_24:
	end_block                               # label861:
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	1                               # 1: down to label852
# %bb.25:
	local.get	1
	local.set	4
.LBB40_26:                              # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label864:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	9
	i32.gt_u
	br_if   	1                               # 1: down to label863
# %bb.27:                               #   in Loop: Header=BB40_26 Depth=1
	local.get	2
	local.get	4
	i32.const	1
	i32.add 
	local.tee	4
	i32.ne  
	br_if   	0                               # 0: up to label864
# %bb.28:
	end_loop
	local.get	2
	local.set	4
.LBB40_29:
	end_block                               # label863:
	local.get	4
	local.get	1
	i32.eq  
	br_if   	1                               # 1: down to label852
.LBB40_30:
	end_block                               # label853:
	local.get	4
	local.get	2
	i32.eq  
	local.set	3
.LBB40_31:
	end_block                               # label852:
	local.get	3
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_composite_span_impl,"",@
	.type	parse_composite_span_impl,@function # -- Begin function parse_composite_span_impl
parse_composite_span_impl:              # @parse_composite_span_impl
	.functype	parse_composite_span_impl (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	272
	i32.sub 
	local.tee	8
	global.set	__stack_pointer
	i32.const	0
	local.set	9
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label865
# %bb.1:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	0                               # 0: down to label865
# %bb.2:
	i32.const	0
	local.set	9
	local.get	7
	i32.const	0
	i32.ne  
	local.get	10
	i32.const	91
	i32.eq  
	local.tee	7
	i32.and 
	local.set	11
	i32.const	0
	i32.const	3
	local.get	7
	i32.select
	local.set	12
	local.get	0
	i32.const	19
	i32.add 
	local.set	13
	local.get	0
	i32.const	6
	i32.add 
	local.set	14
	local.get	0
	i32.const	1
	i32.add 
	local.set	15
	local.get	2
	i32.const	1
	i32.add 
	local.set	7
	i32.const	0
	local.set	16
	i32.const	0
	local.set	17
	i32.const	0
	local.set	18
	i32.const	1
	local.set	19
.LBB41_3:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB41_101 Depth 2
                                        #       Child Loop BB41_102 Depth 3
                                        #       Child Loop BB41_117 Depth 3
                                        #     Child Loop BB41_162 Depth 2
                                        #     Child Loop BB41_170 Depth 2
                                        #     Child Loop BB41_178 Depth 2
                                        #     Child Loop BB41_186 Depth 2
                                        #     Child Loop BB41_259 Depth 2
                                        #     Child Loop BB41_265 Depth 2
                                        #     Child Loop BB41_200 Depth 2
                                        #     Child Loop BB41_208 Depth 2
                                        #     Child Loop BB41_216 Depth 2
	loop    	                                # label866:
	local.get	1
	local.get	7
	local.tee	20
	i32.le_u
	br_if   	1                               # 1: down to label865
# %bb.4:                                #   in Loop: Header=BB41_3 Depth=1
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	0
	local.get	20
	i32.add 
	local.tee	21
	i32.load8_u	0
	local.tee	2
	i32.const	-9
	i32.add 
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label882
# %bb.5:                                #   in Loop: Header=BB41_3 Depth=1
	block   	
	local.get	2
	i32.const	-32
	i32.add 
	br_table 	{1, 8, 2, 0}            # 8: down to label875
                                        # 2: down to label881
                                        # 0: down to label883
.LBB41_6:                               #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label883:
	local.get	2
	i32.const	125
	i32.eq  
	br_if   	3                               # 3: down to label879
# %bb.7:                                #   in Loop: Header=BB41_3 Depth=1
	local.get	2
	i32.const	44
	i32.eq  
	br_if   	5                               # 5: down to label877
# %bb.8:                                #   in Loop: Header=BB41_3 Depth=1
	local.get	2
	i32.const	58
	i32.eq  
	br_if   	6                               # 6: down to label876
# %bb.9:                                #   in Loop: Header=BB41_3 Depth=1
	local.get	2
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label880
# %bb.10:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	2
	i32.const	13
	i32.ne  
	br_if   	7                               # 7: down to label875
.LBB41_11:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label882:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label884
# %bb.12:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	5
	i32.load	0
	br_if   	0                               # 0: down to label884
# %bb.13:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB41_14:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label884:
	local.get	20
	i32.const	1
	i32.add 
	local.set	7
	br      	15                              # 15: up to label866
.LBB41_15:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label881:
	local.get	12
	i32.const	251
	i32.and 
	local.tee	22
	i32.const	3
	i32.ne  
	local.tee	23
	br_if   	11                              # 11: down to label869
# %bb.16:                               #   in Loop: Header=BB41_3 Depth=1
	block   	
	block   	
	block   	
	block   	
	local.get	1
	local.get	20
	i32.sub 
	local.tee	2
	i32.const	9
	i32.lt_u
	br_if   	0                               # 0: down to label888
# %bb.17:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	21
	i64.load	0:p2align=0
	local.tee	24
	i64.const	8389754706581218082
	i64.eq  
	br_if   	2                               # 2: down to label886
# %bb.18:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	24
	i32.wrap_i64
	local.set	2
	br      	1                               # 1: down to label887
.LBB41_19:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label888:
	local.get	2
	i32.const	5
	i32.lt_u
	br_if   	14                              # 14: down to label869
# %bb.20:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	21
	i32.load	0:p2align=0
	local.set	2
.LBB41_21:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label887:
	local.get	2
	i32.const	1734439970
	i32.ne  
	br_if   	13                              # 13: down to label869
# %bb.22:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	21
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label885
	br      	13                              # 13: down to label869
.LBB41_23:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label886:
	local.get	21
	i32.const	8
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	12                              # 12: down to label869
# %bb.24:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	9
	i32.add 
	local.set	2
	i32.const	1
	local.set	25
	i32.const	4
	local.set	7
	br      	11                              # 11: down to label870
.LBB41_25:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label885:
	i32.const	0
	local.set	7
	local.get	20
	i32.const	5
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	9                               # 9: down to label871
# %bb.26:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	9                               # 9: down to label871
# %bb.27:                               #   in Loop: Header=BB41_3 Depth=1
	block   	
	local.get	20
	i32.const	6
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label889
# %bb.28:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	7
	i32.add 
	local.get	10
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.eq  
	i32.select
	local.set	10
.LBB41_29:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label889:
	i32.const	0
	local.set	7
	local.get	1
	local.get	10
	i32.sub 
	local.tee	25
	i32.const	4
	i32.lt_u
	br_if   	9                               # 9: down to label871
# %bb.30:                               #   in Loop: Header=BB41_3 Depth=1
	block   	
	block   	
	local.get	0
	local.get	10
	i32.add 
	local.tee	12
	i32.load	0:p2align=0
	local.tee	20
	i32.const	577334306
	i32.eq  
	br_if   	0                               # 0: down to label891
# %bb.31:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	577533218
	i32.eq  
	br_if   	0                               # 0: down to label891
# %bb.32:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	578056738
	i32.eq  
	br_if   	0                               # 0: down to label891
# %bb.33:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	740450594
	i32.eq  
	br_if   	1                               # 1: down to label890
# %bb.34:                               #   in Loop: Header=BB41_3 Depth=1
	block   	
	block   	
	local.get	20
	i32.const	1634759458
	i32.eq  
	br_if   	0                               # 0: down to label893
# %bb.35:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	1651864098
	i32.eq  
	br_if   	1                               # 1: down to label892
# %bb.36:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	local.get	20
	i32.const	1986618402
	i32.ne  
	br_if   	13                              # 13: down to label871
# %bb.37:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	local.get	25
	i32.const	6
	i32.lt_u
	br_if   	13                              # 13: down to label871
# %bb.38:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	local.get	12
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	13                              # 13: down to label871
# %bb.39:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	local.get	12
	i32.const	5
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	13                              # 13: down to label871
# %bb.40:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	6
	i32.add 
	local.set	7
	br      	12                              # 12: down to label872
.LBB41_41:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label893:
	i32.const	0
	local.set	7
	local.get	25
	i32.const	7
	i32.lt_u
	br_if   	12                              # 12: down to label871
# %bb.42:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	local.get	12
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	12                              # 12: down to label871
# %bb.43:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	local.get	12
	i32.const	5
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	12                              # 12: down to label871
# %bb.44:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	local.get	12
	i32.const	6
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	12                              # 12: down to label871
	br      	10                              # 10: down to label873
.LBB41_45:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label892:
	i32.const	0
	local.set	7
	local.get	25
	i32.const	7
	i32.lt_u
	br_if   	11                              # 11: down to label871
# %bb.46:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	local.get	12
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	121
	i32.ne  
	br_if   	11                              # 11: down to label871
# %bb.47:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	local.get	12
	i32.const	5
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	11                              # 11: down to label871
# %bb.48:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	local.get	12
	i32.const	6
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	11                              # 11: down to label871
	br      	9                               # 9: down to label873
.LBB41_49:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label891:
	i32.const	0
	local.set	7
	local.get	25
	i32.const	4
	i32.eq  
	br_if   	10                              # 10: down to label871
# %bb.50:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	local.get	12
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	10                              # 10: down to label871
# %bb.51:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	5
	i32.add 
	local.set	7
	br      	9                               # 9: down to label872
.LBB41_52:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label890:
	local.get	10
	i32.const	4
	i32.add 
	local.set	7
	br      	8                               # 8: down to label872
.LBB41_53:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label880:
	local.get	12
	i32.const	255
	i32.and 
	i32.const	1
	i32.le_u
	br_if   	1                               # 1: down to label878
	br      	14                              # 14: down to label865
.LBB41_54:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label879:
	block   	
	local.get	12
	i32.const	255
	i32.and 
	i32.const	-3
	i32.add 
	br_table 	{0, 14, 14, 0, 14}      # 14: down to label865
                                        # 0: down to label894
.LBB41_55:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label894:
	local.get	11
	local.get	19
	i32.const	2
	i32.eq  
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label878
# %bb.56:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	17
	local.get	16
	i32.and 
	i32.eqz
	br_if   	13                              # 13: down to label865
.LBB41_57:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label878:
	local.get	20
	i32.const	1
	i32.add 
	local.set	7
	block   	
	local.get	19
	i32.const	-1
	i32.add 
	local.tee	2
	br_if   	0                               # 0: down to label895
# %bb.58:
	local.get	3
	local.get	7
	i32.store	0
	i32.const	1
	local.set	9
	br      	13                              # 13: down to label865
.LBB41_59:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label895:
	local.get	19
	local.get	8
	i32.const	16
	i32.add 
	i32.add 
	i32.const	-2
	i32.add 
	i32.load8_u	0
	local.set	12
	local.get	2
	local.set	19
	br      	11                              # 11: up to label866
.LBB41_60:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label877:
	local.get	12
	i32.const	255
	i32.and 
	local.set	2
	i32.const	2
	local.set	12
	block   	
	local.get	2
	i32.const	1
	i32.eq  
	br_if   	0                               # 0: down to label896
# %bb.61:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	2
	i32.const	6
	i32.ne  
	br_if   	12                              # 12: down to label865
# %bb.62:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	7
	local.set	12
.LBB41_63:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label896:
	local.get	20
	i32.const	1
	i32.add 
	local.tee	7
	local.get	1
	i32.ge_u
	br_if   	10                              # 10: up to label866
# %bb.64:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	10                              # 10: up to label866
	br      	2                               # 2: down to label874
.LBB41_65:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label876:
	local.get	12
	i32.const	255
	i32.and 
	i32.const	4
	i32.ne  
	br_if   	10                              # 10: down to label865
# %bb.66:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	5
	local.set	12
	local.get	20
	i32.const	1
	i32.add 
	local.tee	7
	local.get	1
	i32.ge_u
	br_if   	9                               # 9: up to label866
# %bb.67:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	9                               # 9: up to label866
	br      	1                               # 1: down to label874
.LBB41_68:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label875:
	block   	
	block   	
	local.get	12
	i32.const	253
	i32.and 
	br_if   	0                               # 0: down to label898
# %bb.69:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	1
	local.set	25
	br      	1                               # 1: down to label897
.LBB41_70:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label898:
	local.get	12
	i32.const	255
	i32.and 
	i32.const	5
	i32.ne  
	br_if   	10                              # 10: down to label865
# %bb.71:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	6
	local.set	25
.LBB41_72:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label897:
	block   	
	block   	
	local.get	11
	local.get	19
	i32.const	2
	i32.eq  
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label900
# %bb.73:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	12
	i32.const	255
	i32.and 
	i32.const	5
	i32.ne  
	br_if   	0                               # 0: down to label900
# %bb.74:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	10
	block   	
	block   	
	local.get	18
	i32.const	-4
	i32.add 
	br_table 	{0, 1, 1, 1, 3, 1}      # 1: down to label901
                                        # 3: down to label899
.LBB41_75:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label902:
	local.get	2
	i32.const	223
	i32.and 
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label901
# %bb.76:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	16
	i32.const	4
	i32.or  
	local.set	16
	br      	1                               # 1: down to label900
.LBB41_77:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label901:
	local.get	16
	local.get	18
	i32.const	-1
	i32.xor 
	i32.and 
	local.set	16
.LBB41_78:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label900:
	local.get	17
	local.set	10
.LBB41_79:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label899:
	block   	
	local.get	2
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	0                               # 0: down to label903
# %bb.80:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	19
	i32.const	255
	i32.gt_u
	br_if   	10                              # 10: down to label865
# %bb.81:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	19
	local.get	8
	i32.const	16
	i32.add 
	i32.add 
	i32.const	-1
	i32.add 
	local.get	25
	i32.store8	0
	i32.const	0
	local.get	18
	local.get	11
	local.get	19
	i32.const	1
	i32.eq  
	i32.and 
	local.get	2
	i32.const	123
	i32.eq  
	i32.and 
	local.tee	7
	i32.select
	local.set	18
	i32.const	0
	local.get	10
	local.get	7
	i32.select
	local.set	17
	i32.const	0
	local.get	16
	local.get	7
	i32.select
	local.set	16
	i32.const	0
	i32.const	3
	local.get	2
	i32.const	91
	i32.eq  
	i32.select
	local.set	12
	local.get	20
	i32.const	1
	i32.add 
	local.set	7
	local.get	19
	i32.const	1
	i32.add 
	local.set	19
	br      	9                               # 9: up to label866
.LBB41_82:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label903:
	local.get	8
	i32.const	0
	i32.store	12
	local.get	0
	local.get	1
	local.get	20
	local.get	8
	i32.const	12
	i32.add 
	call	parse_scalar_span
	i32.eqz
	br_if   	9                               # 9: down to label865
# %bb.83:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	8
	i32.load	12
	local.set	7
	local.get	10
	local.set	17
	local.get	25
	local.set	12
	br      	8                               # 8: up to label866
.LBB41_84:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label874:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label904
# %bb.85:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB41_86:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label904:
	local.get	20
	i32.const	2
	i32.add 
	local.set	7
	br      	7                               # 7: up to label866
.LBB41_87:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label873:
	local.get	10
	i32.const	7
	i32.add 
	local.set	7
.LBB41_88:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label872:
	block   	
	local.get	7
	br_if   	0                               # 0: down to label905
# %bb.89:                               #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	7
	br      	1                               # 1: down to label871
.LBB41_90:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label905:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label906
# %bb.91:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	15
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	0                               # 0: down to label906
# %bb.92:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB41_93:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label906:
	i32.const	0
	local.get	18
	local.get	19
	i32.const	2
	i32.eq  
	i32.select
	local.get	18
	local.get	11
	i32.select
	local.set	18
	i32.const	7
	local.set	12
	local.get	7
	local.get	1
	i32.ge_u
	br_if   	5                               # 5: up to label866
# %bb.94:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	5                               # 5: up to label866
# %bb.95:                               #   in Loop: Header=BB41_3 Depth=1
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label907
# %bb.96:                               #   in Loop: Header=BB41_3 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB41_97:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label907:
	local.get	7
	i32.const	1
	i32.add 
	local.set	7
	br      	5                               # 5: up to label866
.LBB41_98:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label871:
	i32.const	0
	local.set	25
.LBB41_99:                              #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label870:
	local.get	7
	local.get	18
	local.get	11
	local.get	19
	i32.const	2
	i32.eq  
	i32.and 
	local.tee	23
	i32.select
	local.set	18
	br      	1                               # 1: down to label868
.LBB41_100:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label869:
	local.get	20
	i32.const	1
	i32.add 
	local.set	2
.LBB41_101:                             #   Parent Loop BB41_3 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB41_102 Depth 3
                                        #       Child Loop BB41_117 Depth 3
	loop    	                                # label908:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	4                               # 4: down to label865
.LBB41_102:                             #   Parent Loop BB41_3 Depth=1
                                        #     Parent Loop BB41_101 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	block   	
	loop    	                                # label910:
	block   	
	local.get	2
	i32.const	8
	i32.add 
	local.tee	7
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label911
# %bb.103:                              #   in Loop: Header=BB41_101 Depth=2
	local.get	2
	local.set	7
	br      	2                               # 2: down to label909
.LBB41_104:                             #   in Loop: Header=BB41_102 Depth=3
	end_block                               # label911:
	local.get	0
	local.get	2
	i32.add 
	local.set	10
	local.get	7
	local.set	2
	local.get	10
	i64.load	0:p2align=0
	local.tee	24
	i64.const	-1
	i64.xor 
	local.get	24
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	24
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	local.get	24
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	24
	i64.eqz
	br_if   	0                               # 0: up to label910
# %bb.105:                              #   in Loop: Header=BB41_101 Depth=2
	end_loop
	local.get	24
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	7
	i32.add 
	i32.const	-8
	i32.add 
	local.set	7
.LBB41_106:                             #   in Loop: Header=BB41_101 Depth=2
	end_block                               # label909:
	local.get	7
	local.get	1
	i32.ge_u
	br_if   	4                               # 4: down to label865
# %bb.107:                              #   in Loop: Header=BB41_101 Depth=2
	block   	
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label912
# %bb.108:                              #   in Loop: Header=BB41_101 Depth=2
	local.get	7
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	5                               # 5: down to label865
# %bb.109:                              #   in Loop: Header=BB41_101 Depth=2
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	-110
	i32.add 
	br_table 	{1, 8, 8, 8, 1, 8, 1, 2, 0} # 8: down to label865
                                        # 1: down to label914
                                        # 2: down to label913
                                        # 0: down to label915
.LBB41_110:                             #   in Loop: Header=BB41_101 Depth=2
	end_block                               # label915:
	block   	
	local.get	2
	i32.const	-98
	i32.add 
	br_table 	{1, 8, 8, 8, 1, 0}      # 8: down to label865
                                        # 1: down to label914
                                        # 0: down to label916
.LBB41_111:                             #   in Loop: Header=BB41_101 Depth=2
	end_block                               # label916:
	local.get	2
	i32.const	34
	i32.eq  
	br_if   	0                               # 0: down to label914
# %bb.112:                              #   in Loop: Header=BB41_101 Depth=2
	local.get	2
	i32.const	47
	i32.eq  
	br_if   	0                               # 0: down to label914
# %bb.113:                              #   in Loop: Header=BB41_101 Depth=2
	local.get	2
	i32.const	92
	i32.ne  
	br_if   	7                               # 7: down to label865
.LBB41_114:                             #   in Loop: Header=BB41_101 Depth=2
	end_block                               # label914:
	local.get	7
	i32.const	2
	i32.add 
	local.set	2
	br      	2                               # 2: up to label908
.LBB41_115:                             #   in Loop: Header=BB41_101 Depth=2
	end_block                               # label913:
	local.get	7
	i32.const	6
	i32.add 
	local.tee	2
	local.get	1
	i32.gt_u
	br_if   	5                               # 5: down to label865
# %bb.116:                              #   in Loop: Header=BB41_101 Depth=2
	local.get	7
	i32.const	2
	i32.add 
	local.set	7
.LBB41_117:                             #   Parent Loop BB41_3 Depth=1
                                        #     Parent Loop BB41_101 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label917:
	local.get	7
	local.get	2
	i32.ge_u
	br_if   	2                               # 2: up to label908
# %bb.118:                              #   in Loop: Header=BB41_117 Depth=3
	local.get	0
	local.get	7
	i32.add 
	local.set	10
	local.get	7
	i32.const	1
	i32.add 
	local.tee	25
	local.set	7
	local.get	10
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: up to label917
# %bb.119:                              #   in Loop: Header=BB41_117 Depth=3
	local.get	25
	local.set	7
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	0                               # 0: up to label917
	br      	6                               # 6: down to label865
.LBB41_120:                             #   in Loop: Header=BB41_101 Depth=2
	end_loop
	end_block                               # label912:
	local.get	10
	i32.const	32
	i32.lt_u
	br_if   	4                               # 4: down to label865
# %bb.121:                              #   in Loop: Header=BB41_101 Depth=2
	local.get	7
	i32.const	1
	i32.add 
	local.set	2
	local.get	10
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: up to label908
# %bb.122:                              #   in Loop: Header=BB41_3 Depth=1
	end_loop
	local.get	21
	i32.const	1
	i32.add 
	local.set	26
	block   	
	local.get	4
	i32.eqz
	br_if   	0                               # 0: down to label918
# %bb.123:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	26
	i32.load8_u	0
	local.tee	10
	i32.const	105
	i32.eq  
	local.tee	27
	local.get	10
	i32.const	92
	i32.eq  
	local.tee	25
	i32.or  
	i32.eqz
	br_if   	0                               # 0: down to label918
# %bb.124:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	7
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: down to label918
# %bb.125:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	4
	i32.load	0
	br_if   	0                               # 0: down to label918
# %bb.126:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	4
	i32.add 
	local.set	28
	block   	
	block   	
	local.get	7
	local.get	20
	i32.eq  
	br_if   	0                               # 0: down to label920
# %bb.127:                              #   in Loop: Header=BB41_3 Depth=1
	block   	
	local.get	25
	br_if   	0                               # 0: down to label921
# %bb.128:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	7
	local.get	20
	i32.sub 
	local.tee	29
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label920
# %bb.129:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	105
	i32.ne  
	br_if   	1                               # 1: down to label920
# %bb.130:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	21
	i32.load8_u	2
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label921
# %bb.131:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	109
	i32.ne  
	br_if   	1                               # 1: down to label920
# %bb.132:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	29
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label920
# %bb.133:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	21
	i32.load8_u	3
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label921
# %bb.134:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	103
	i32.ne  
	br_if   	1                               # 1: down to label920
# %bb.135:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	28
	local.get	7
	i32.gt_u
	br_if   	1                               # 1: down to label920
# %bb.136:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	28
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label920
	br      	2                               # 2: down to label919
.LBB41_137:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label921:
	local.get	0
	local.get	20
	local.get	2
	i32.const	.L.str.6
	i32.const	3
	call	json_string_matches_ascii_escaped
	br_if   	1                               # 1: down to label919
.LBB41_138:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label920:
	local.get	7
	local.get	20
	i32.le_u
	br_if   	1                               # 1: down to label918
# %bb.139:                              #   in Loop: Header=BB41_3 Depth=1
	block   	
	local.get	25
	br_if   	0                               # 0: down to label922
# %bb.140:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	27
	i32.eqz
	br_if   	2                               # 2: down to label918
# %bb.141:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	2
	i32.add 
	local.tee	10
	local.get	7
	i32.gt_u
	br_if   	2                               # 2: down to label918
# %bb.142:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label922
# %bb.143:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	109
	i32.ne  
	br_if   	2                               # 2: down to label918
# %bb.144:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	3
	i32.add 
	local.tee	10
	local.get	7
	i32.gt_u
	br_if   	2                               # 2: down to label918
# %bb.145:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label922
# %bb.146:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	97
	i32.ne  
	br_if   	2                               # 2: down to label918
# %bb.147:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	28
	local.get	7
	i32.gt_u
	br_if   	2                               # 2: down to label918
# %bb.148:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	28
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label922
# %bb.149:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	103
	i32.ne  
	br_if   	2                               # 2: down to label918
# %bb.150:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	5
	i32.add 
	local.tee	10
	local.get	7
	i32.gt_u
	br_if   	2                               # 2: down to label918
# %bb.151:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label922
# %bb.152:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	101
	i32.ne  
	br_if   	2                               # 2: down to label918
# %bb.153:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	6
	i32.add 
	local.tee	10
	local.get	7
	i32.gt_u
	br_if   	2                               # 2: down to label918
# %bb.154:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label919
	br      	2                               # 2: down to label918
.LBB41_155:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label922:
	local.get	0
	local.get	20
	local.get	2
	i32.const	.L.str.4
	i32.const	5
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	1                               # 1: down to label918
.LBB41_156:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label919:
	local.get	4
	i32.const	1
	i32.store	0
.LBB41_157:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label918:
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	23
	br_if   	0                               # 0: down to label927
# %bb.158:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	11
	local.get	19
	i32.const	2
	i32.eq  
	i32.and 
	local.tee	23
	i32.const	1
	i32.ne  
	br_if   	4                               # 4: down to label923
# %bb.159:                              #   in Loop: Header=BB41_3 Depth=1
	i32.const	0
	local.set	18
	local.get	7
	local.get	20
	i32.lt_u
	br_if   	4                               # 4: down to label923
# %bb.160:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	21
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	4                               # 4: down to label923
# %bb.161:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	local.get	7
	i32.sub 
	local.set	18
	local.get	20
	i32.const	5
	i32.add 
	local.set	27
	i32.const	0
	local.set	10
.LBB41_162:                             #   Parent Loop BB41_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	block   	
	loop    	                                # label931:
	local.get	10
	i32.const	4
	i32.eq  
	br_if   	1                               # 1: down to label930
# %bb.163:                              #   in Loop: Header=BB41_162 Depth=2
	local.get	18
	local.get	10
	i32.add 
	i32.eqz
	br_if   	3                               # 3: down to label928
# %bb.164:                              #   in Loop: Header=BB41_162 Depth=2
	local.get	21
	local.get	10
	i32.add 
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.tee	25
	i32.const	92
	i32.eq  
	br_if   	2                               # 2: down to label929
# %bb.165:                              #   in Loop: Header=BB41_162 Depth=2
	local.get	10
	i32.const	.L.str.2
	i32.add 
	local.set	12
	local.get	10
	i32.const	1
	i32.add 
	local.set	10
	local.get	25
	local.get	12
	i32.load8_u	0
	i32.eq  
	br_if   	0                               # 0: up to label931
	br      	3                               # 3: down to label928
.LBB41_166:                             #   in Loop: Header=BB41_3 Depth=1
	end_loop
	end_block                               # label930:
	local.get	27
	local.get	7
	i32.gt_u
	br_if   	1                               # 1: down to label928
# %bb.167:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	27
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label928
	br      	5                               # 5: down to label924
.LBB41_168:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label929:
	local.get	0
	local.get	20
	local.get	2
	i32.const	.L.str.2
	i32.const	4
	call	json_string_matches_ascii_escaped
	br_if   	4                               # 4: down to label924
.LBB41_169:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label928:
	i32.const	0
	local.set	10
.LBB41_170:                             #   Parent Loop BB41_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	block   	
	loop    	                                # label935:
	local.get	10
	i32.const	4
	i32.eq  
	br_if   	1                               # 1: down to label934
# %bb.171:                              #   in Loop: Header=BB41_170 Depth=2
	local.get	20
	local.get	10
	i32.add 
	local.get	7
	i32.ge_u
	br_if   	3                               # 3: down to label932
# %bb.172:                              #   in Loop: Header=BB41_170 Depth=2
	local.get	21
	local.get	10
	i32.add 
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.tee	25
	i32.const	92
	i32.eq  
	br_if   	2                               # 2: down to label933
# %bb.173:                              #   in Loop: Header=BB41_170 Depth=2
	local.get	10
	i32.const	.L.str.10
	i32.add 
	local.set	12
	local.get	10
	i32.const	1
	i32.add 
	local.set	10
	local.get	25
	local.get	12
	i32.load8_u	0
	i32.eq  
	br_if   	0                               # 0: up to label935
	br      	3                               # 3: down to label932
.LBB41_174:                             #   in Loop: Header=BB41_3 Depth=1
	end_loop
	end_block                               # label934:
	local.get	27
	local.get	7
	i32.gt_u
	br_if   	1                               # 1: down to label932
# %bb.175:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	27
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label932
	br      	4                               # 4: down to label925
.LBB41_176:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label933:
	local.get	0
	local.get	20
	local.get	2
	i32.const	.L.str.10
	i32.const	4
	call	json_string_matches_ascii_escaped
	br_if   	3                               # 3: down to label925
.LBB41_177:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label932:
	i32.const	0
	local.set	10
.LBB41_178:                             #   Parent Loop BB41_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	block   	
	loop    	                                # label939:
	local.get	10
	i32.const	4
	i32.eq  
	br_if   	1                               # 1: down to label938
# %bb.179:                              #   in Loop: Header=BB41_178 Depth=2
	local.get	20
	local.get	10
	i32.add 
	local.get	7
	i32.ge_u
	br_if   	3                               # 3: down to label936
# %bb.180:                              #   in Loop: Header=BB41_178 Depth=2
	local.get	21
	local.get	10
	i32.add 
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.tee	25
	i32.const	92
	i32.eq  
	br_if   	2                               # 2: down to label937
# %bb.181:                              #   in Loop: Header=BB41_178 Depth=2
	local.get	10
	i32.const	.L.str.1
	i32.add 
	local.set	12
	local.get	10
	i32.const	1
	i32.add 
	local.set	10
	local.get	25
	local.get	12
	i32.load8_u	0
	i32.eq  
	br_if   	0                               # 0: up to label939
	br      	3                               # 3: down to label936
.LBB41_182:                             #   in Loop: Header=BB41_3 Depth=1
	end_loop
	end_block                               # label938:
	local.get	27
	local.get	7
	i32.gt_u
	br_if   	1                               # 1: down to label936
# %bb.183:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	27
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label936
	br      	3                               # 3: down to label926
.LBB41_184:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label937:
	local.get	0
	local.get	20
	local.get	2
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	br_if   	2                               # 2: down to label926
.LBB41_185:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label936:
	local.get	20
	i32.const	8
	i32.add 
	local.set	27
	i32.const	0
	local.set	10
.LBB41_186:                             #   Parent Loop BB41_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	block   	
	loop    	                                # label943:
	local.get	10
	i32.const	7
	i32.eq  
	br_if   	1                               # 1: down to label942
# %bb.187:                              #   in Loop: Header=BB41_186 Depth=2
	i32.const	0
	local.set	18
	local.get	20
	local.get	10
	i32.add 
	local.get	7
	i32.ge_u
	br_if   	8                               # 8: down to label923
# %bb.188:                              #   in Loop: Header=BB41_186 Depth=2
	local.get	21
	local.get	10
	i32.add 
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.tee	25
	i32.const	92
	i32.eq  
	br_if   	2                               # 2: down to label941
# %bb.189:                              #   in Loop: Header=BB41_186 Depth=2
	local.get	10
	i32.const	.L.str
	i32.add 
	local.set	12
	local.get	10
	i32.const	1
	i32.add 
	local.set	10
	local.get	25
	local.get	12
	i32.load8_u	0
	i32.eq  
	br_if   	0                               # 0: up to label943
	br      	8                               # 8: down to label923
.LBB41_190:                             #   in Loop: Header=BB41_3 Depth=1
	end_loop
	end_block                               # label942:
	i32.const	0
	local.set	18
	local.get	27
	local.get	7
	i32.gt_u
	br_if   	6                               # 6: down to label923
# %bb.191:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	27
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label940
	br      	6                               # 6: down to label923
.LBB41_192:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label941:
	local.get	0
	local.get	20
	local.get	2
	i32.const	.L.str
	i32.const	7
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	5                               # 5: down to label923
.LBB41_193:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label940:
	i32.const	4
	local.set	18
	br      	4                               # 4: down to label923
.LBB41_194:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label927:
	block   	
	block   	
	block   	
	block   	
	local.get	12
	i32.const	255
	i32.and 
	i32.const	5
	i32.ne  
	br_if   	0                               # 0: down to label947
# %bb.195:                              #   in Loop: Header=BB41_3 Depth=1
	i32.const	6
	local.set	12
	i32.const	7
	local.set	10
	local.get	11
	local.get	19
	i32.const	2
	i32.eq  
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	9                               # 9: down to label867
# %bb.196:                              #   in Loop: Header=BB41_3 Depth=1
	block   	
	local.get	18
	i32.const	8
	i32.ne  
	br_if   	0                               # 0: down to label948
# %bb.197:                              #   in Loop: Header=BB41_3 Depth=1
	block   	
	local.get	7
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: down to label949
# %bb.198:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	21
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label949
# %bb.199:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	local.get	7
	i32.sub 
	local.set	23
	local.get	20
	i32.const	5
	i32.add 
	local.set	26
	local.get	20
	i32.const	4
	i32.add 
	local.set	27
	i32.const	0
	local.set	25
.LBB41_200:                             #   Parent Loop BB41_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	block   	
	loop    	                                # label953:
	local.get	25
	i32.const	4
	i32.eq  
	br_if   	1                               # 1: down to label952
# %bb.201:                              #   in Loop: Header=BB41_200 Depth=2
	local.get	23
	local.get	25
	i32.add 
	i32.eqz
	br_if   	3                               # 3: down to label950
# %bb.202:                              #   in Loop: Header=BB41_200 Depth=2
	local.get	21
	local.get	25
	i32.add 
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.tee	18
	i32.const	92
	i32.eq  
	br_if   	2                               # 2: down to label951
# %bb.203:                              #   in Loop: Header=BB41_200 Depth=2
	local.get	25
	i32.const	.L.str.10
	i32.add 
	local.set	17
	local.get	25
	i32.const	1
	i32.add 
	local.set	25
	local.get	18
	local.get	17
	i32.load8_u	0
	i32.eq  
	br_if   	0                               # 0: up to label953
	br      	3                               # 3: down to label950
.LBB41_204:                             #   in Loop: Header=BB41_3 Depth=1
	end_loop
	end_block                               # label952:
	local.get	27
	local.get	7
	i32.ge_u
	br_if   	1                               # 1: down to label950
# %bb.205:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	26
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label950
	br      	7                               # 7: down to label944
.LBB41_206:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label951:
	local.get	0
	local.get	20
	local.get	2
	i32.const	.L.str.10
	i32.const	4
	call	json_string_matches_ascii_escaped
	br_if   	6                               # 6: down to label944
.LBB41_207:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label950:
	i32.const	0
	local.set	25
	i32.const	0
	local.get	7
	local.get	20
	i32.sub 
	local.tee	18
	local.get	18
	local.get	7
	i32.gt_u
	i32.select
	local.set	17
.LBB41_208:                             #   Parent Loop BB41_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	block   	
	loop    	                                # label957:
	local.get	25
	i32.const	5
	i32.eq  
	br_if   	1                               # 1: down to label956
# %bb.209:                              #   in Loop: Header=BB41_208 Depth=2
	local.get	17
	local.get	25
	i32.eq  
	br_if   	3                               # 3: down to label954
# %bb.210:                              #   in Loop: Header=BB41_208 Depth=2
	local.get	21
	local.get	25
	i32.add 
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.tee	18
	i32.const	92
	i32.eq  
	br_if   	2                               # 2: down to label955
# %bb.211:                              #   in Loop: Header=BB41_208 Depth=2
	local.get	25
	i32.const	.L.str.4
	i32.add 
	local.set	23
	local.get	25
	i32.const	1
	i32.add 
	local.set	25
	local.get	18
	local.get	23
	i32.load8_u	0
	i32.eq  
	br_if   	0                               # 0: up to label957
	br      	3                               # 3: down to label954
.LBB41_212:                             #   in Loop: Header=BB41_3 Depth=1
	end_loop
	end_block                               # label956:
	local.get	26
	local.get	7
	i32.ge_u
	br_if   	1                               # 1: down to label954
# %bb.213:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	14
	local.get	20
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label954
	br      	6                               # 6: down to label945
.LBB41_214:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label955:
	local.get	0
	local.get	20
	local.get	2
	i32.const	.L.str.4
	i32.const	5
	call	json_string_matches_ascii_escaped
	br_if   	5                               # 5: down to label945
.LBB41_215:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label954:
	local.get	20
	i32.const	18
	i32.add 
	local.set	26
	i32.const	0
	local.set	25
.LBB41_216:                             #   Parent Loop BB41_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	loop    	                                # label960:
	local.get	25
	i32.const	18
	i32.eq  
	br_if   	1                               # 1: down to label959
# %bb.217:                              #   in Loop: Header=BB41_216 Depth=2
	local.get	17
	local.get	25
	i32.eq  
	br_if   	3                               # 3: down to label949
# %bb.218:                              #   in Loop: Header=BB41_216 Depth=2
	local.get	21
	local.get	25
	i32.add 
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.tee	18
	i32.const	92
	i32.eq  
	br_if   	2                               # 2: down to label958
# %bb.219:                              #   in Loop: Header=BB41_216 Depth=2
	local.get	25
	i32.const	.L.str.5
	i32.add 
	local.set	23
	local.get	25
	i32.const	1
	i32.add 
	local.set	25
	local.get	18
	local.get	23
	i32.load8_u	0
	i32.eq  
	br_if   	0                               # 0: up to label960
	br      	3                               # 3: down to label949
.LBB41_220:                             #   in Loop: Header=BB41_3 Depth=1
	end_loop
	end_block                               # label959:
	local.get	26
	local.get	7
	i32.ge_u
	br_if   	1                               # 1: down to label949
# %bb.221:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	13
	local.get	20
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label949
	br      	4                               # 4: down to label946
.LBB41_222:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label958:
	local.get	0
	local.get	20
	local.get	2
	i32.const	.L.str.5
	i32.const	18
	call	json_string_matches_ascii_escaped
	br_if   	3                               # 3: down to label946
.LBB41_223:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label949:
	i32.const	8
	local.set	18
	i32.const	0
	local.set	17
	br      	10                              # 10: down to label867
.LBB41_224:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label948:
	local.get	18
	local.get	16
	i32.or  
	local.set	16
	br      	9                               # 9: down to label867
.LBB41_225:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label947:
	local.get	12
	i32.const	253
	i32.and 
	br_if   	10                              # 10: down to label865
# %bb.226:                              #   in Loop: Header=BB41_3 Depth=1
	i32.const	1
	local.set	12
	i32.const	2
	local.set	10
	br      	8                               # 8: down to label867
.LBB41_227:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label946:
	i32.const	8
	local.set	18
	i32.const	4
	local.set	17
	br      	7                               # 7: down to label867
.LBB41_228:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label945:
	i32.const	8
	local.set	18
	i32.const	2
	local.set	17
	br      	6                               # 6: down to label867
.LBB41_229:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label944:
	i32.const	8
	local.set	18
	i32.const	1
	local.set	17
	br      	5                               # 5: down to label867
.LBB41_230:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label926:
	i32.const	2
	local.set	18
	br      	2                               # 2: down to label923
.LBB41_231:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label925:
	i32.const	1
	local.set	18
	br      	1                               # 1: down to label923
.LBB41_232:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label924:
	i32.const	8
	local.set	18
.LBB41_233:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label923:
	i32.const	0
	local.set	25
	block   	
	local.get	26
	i32.load8_u	0
	local.tee	10
	i32.const	116
	i32.eq  
	br_if   	0                               # 0: down to label961
# %bb.234:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	92
	i32.ne  
	br_if   	1                               # 1: down to label868
.LBB41_235:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label961:
	block   	
	block   	
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label964
# %bb.236:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	5
	i32.load	0
	i32.eqz
	br_if   	1                               # 1: down to label963
.LBB41_237:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label964:
	local.get	6
	i32.eqz
	br_if   	2                               # 2: down to label868
# %bb.238:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	6
	i32.load	0
	br_if   	2                               # 2: down to label868
# %bb.239:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label962
	br      	2                               # 2: down to label868
.LBB41_240:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label963:
	local.get	7
	local.get	20
	i32.lt_u
	br_if   	1                               # 1: down to label868
.LBB41_241:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label962:
	local.get	21
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label868
# %bb.242:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	7
	local.get	20
	i32.eq  
	br_if   	0                               # 0: down to label868
# %bb.243:                              #   in Loop: Header=BB41_3 Depth=1
	block   	
	block   	
	local.get	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label966
# %bb.244:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	7
	local.get	20
	i32.sub 
	local.tee	12
	i32.const	1
	i32.eq  
	br_if   	2                               # 2: down to label868
# %bb.245:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label868
# %bb.246:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	21
	i32.load8_u	2
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label966
# %bb.247:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	121
	i32.ne  
	br_if   	2                               # 2: down to label868
# %bb.248:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	12
	i32.const	2
	i32.eq  
	br_if   	2                               # 2: down to label868
# %bb.249:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	21
	i32.load8_u	3
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label966
# %bb.250:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	112
	i32.ne  
	br_if   	2                               # 2: down to label868
# %bb.251:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	12
	i32.const	3
	i32.eq  
	br_if   	2                               # 2: down to label868
# %bb.252:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	21
	i32.load8_u	4
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label966
# %bb.253:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	101
	i32.ne  
	br_if   	2                               # 2: down to label868
# %bb.254:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	5
	i32.add 
	local.tee	10
	local.get	7
	i32.gt_u
	br_if   	2                               # 2: down to label868
# %bb.255:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label965
	br      	2                               # 2: down to label868
.LBB41_256:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label966:
	local.get	0
	local.get	20
	local.get	2
	i32.const	.L.str.2
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	1                               # 1: down to label868
.LBB41_257:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label965:
	local.get	2
	local.set	7
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label967
# %bb.258:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	2
	local.set	7
.LBB41_259:                             #   Parent Loop BB41_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label968:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label967
# %bb.260:                              #   in Loop: Header=BB41_259 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label967
# %bb.261:                              #   in Loop: Header=BB41_259 Depth=2
	local.get	1
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label968
	br      	2                               # 2: down to label868
.LBB41_262:                             #   in Loop: Header=BB41_3 Depth=1
	end_loop
	end_block                               # label967:
	local.get	7
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label868
# %bb.263:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	0                               # 0: down to label868
# %bb.264:                              #   in Loop: Header=BB41_3 Depth=1
	block   	
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label969
.LBB41_265:                             #   Parent Loop BB41_3 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label970:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label969
# %bb.266:                              #   in Loop: Header=BB41_265 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label969
# %bb.267:                              #   in Loop: Header=BB41_265 Depth=2
	local.get	1
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label970
	br      	2                               # 2: down to label868
.LBB41_268:                             #   in Loop: Header=BB41_3 Depth=1
	end_loop
	end_block                               # label969:
	local.get	7
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label868
# %bb.269:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	7
	i32.add 
	local.tee	10
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label868
# %bb.270:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	1
	local.get	7
	i32.const	-1
	i32.xor 
	i32.add 
	local.tee	20
	i32.eqz
	br_if   	0                               # 0: down to label868
# %bb.271:                              #   in Loop: Header=BB41_3 Depth=1
	block   	
	block   	
	local.get	10
	i32.load8_u	1
	local.tee	12
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label972
# %bb.272:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	1
	i32.eq  
	br_if   	2                               # 2: down to label868
# %bb.273:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	12
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label868
# %bb.274:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.load8_u	2
	local.tee	12
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label972
# %bb.275:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	12
	i32.const	101
	i32.ne  
	br_if   	2                               # 2: down to label868
# %bb.276:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	2
	i32.eq  
	br_if   	2                               # 2: down to label868
# %bb.277:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.load8_u	3
	local.tee	12
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label972
# %bb.278:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	12
	i32.const	120
	i32.ne  
	br_if   	2                               # 2: down to label868
# %bb.279:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	20
	i32.const	3
	i32.eq  
	br_if   	2                               # 2: down to label868
# %bb.280:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.load8_u	4
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label972
# %bb.281:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label868
# %bb.282:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	7
	i32.const	5
	i32.add 
	local.tee	7
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label868
# %bb.283:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label971
	br      	2                               # 2: down to label868
.LBB41_284:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label972:
	local.get	0
	local.get	7
	local.get	1
	i32.const	.L.str.10
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	1                               # 1: down to label868
.LBB41_285:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label971:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label973
# %bb.286:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB41_287:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label973:
	local.get	6
	i32.eqz
	br_if   	0                               # 0: down to label868
# %bb.288:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	6
	i32.const	1
	i32.store	0
.LBB41_289:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label868:
	i32.const	4
	local.set	12
	i32.const	2
	local.set	10
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label867
# %bb.290:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	0                               # 0: down to label867
# %bb.291:                              #   in Loop: Header=BB41_3 Depth=1
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	7
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label974
# %bb.292:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	0                               # 0: down to label974
# %bb.293:                              #   in Loop: Header=BB41_3 Depth=1
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label975
# %bb.294:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB41_295:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label975:
	local.get	2
	i32.const	2
	i32.add 
	local.set	7
.LBB41_296:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label974:
	i32.const	5
	local.set	12
	local.get	25
	local.get	7
	local.get	1
	i32.lt_u
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	1                               # 1: up to label866
# %bb.297:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	1                               # 1: up to label866
# %bb.298:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	19
	i32.const	255
	i32.gt_u
	br_if   	2                               # 2: down to label865
# %bb.299:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	19
	local.get	8
	i32.const	16
	i32.add 
	i32.add 
	i32.const	-1
	i32.add 
	i32.const	6
	i32.store8	0
	i32.const	0
	i32.const	3
	local.get	2
	i32.const	91
	i32.eq  
	i32.select
	local.set	12
	local.get	16
	i32.const	4
	i32.or  
	local.get	16
	local.get	23
	i32.select
	local.set	16
	local.get	7
	i32.const	1
	i32.add 
	local.set	7
	local.get	19
	i32.const	1
	i32.add 
	local.set	19
	br      	1                               # 1: up to label866
.LBB41_300:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label867:
	local.get	2
	local.set	7
	local.get	22
	i32.const	3
	i32.eq  
	br_if   	0                               # 0: up to label866
# %bb.301:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	2
	local.set	7
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: up to label866
# %bb.302:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	2
	local.set	7
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	0                               # 0: up to label866
# %bb.303:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	local.set	12
	local.get	2
	i32.const	1
	i32.add 
	local.tee	7
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: up to label866
# %bb.304:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	10
	local.set	12
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	0                               # 0: up to label866
# %bb.305:                              #   in Loop: Header=BB41_3 Depth=1
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label976
# %bb.306:                              #   in Loop: Header=BB41_3 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB41_307:                             #   in Loop: Header=BB41_3 Depth=1
	end_block                               # label976:
	local.get	2
	i32.const	2
	i32.add 
	local.set	7
	local.get	10
	local.set	12
	br      	0                               # 0: up to label866
.LBB41_308:
	end_loop
	end_block                               # label865:
	local.get	8
	i32.const	272
	i32.add 
	global.set	__stack_pointer
	local.get	9
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.json_string_matches_ascii_escaped,"",@
	.type	json_string_matches_ascii_escaped,@function # -- Begin function json_string_matches_ascii_escaped
json_string_matches_ascii_escaped:      # @json_string_matches_ascii_escaped
	.functype	json_string_matches_ascii_escaped (i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	5
	block   	
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label977
# %bb.1:
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label977
# %bb.2:
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label977
# %bb.3:
	i32.const	0
	local.set	6
.LBB42_4:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label978:
	local.get	1
	i32.const	1
	i32.add 
	local.set	7
	block   	
	block   	
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label980
# %bb.5:                                #   in Loop: Header=BB42_4 Depth=1
	local.get	7
	local.set	1
	br      	1                               # 1: down to label979
.LBB42_6:                               #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label980:
	i32.const	0
	local.set	5
	local.get	2
	local.get	7
	i32.sub 
	i32.const	5
	i32.lt_u
	br_if   	2                               # 2: down to label977
# %bb.7:                                #   in Loop: Header=BB42_4 Depth=1
	local.get	0
	local.get	7
	i32.add 
	local.tee	7
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	2                               # 2: down to label977
# %bb.8:                                #   in Loop: Header=BB42_4 Depth=1
	i32.const	-48
	local.set	9
	i32.const	-48
	local.set	10
	block   	
	block   	
	local.get	7
	i32.load8_u	1
	local.tee	8
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label982
# %bb.9:                                #   in Loop: Header=BB42_4 Depth=1
	block   	
	local.get	8
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label983
# %bb.10:                               #   in Loop: Header=BB42_4 Depth=1
	i32.const	-87
	local.set	10
	br      	1                               # 1: down to label982
.LBB42_11:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label983:
	block   	
	local.get	8
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label984
# %bb.12:                               #   in Loop: Header=BB42_4 Depth=1
	i32.const	-1
	local.set	8
	br      	2                               # 2: down to label981
.LBB42_13:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label984:
	i32.const	-55
	local.set	10
.LBB42_14:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label982:
	block   	
	local.get	7
	i32.load8_u	2
	local.tee	5
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label985
# %bb.15:                               #   in Loop: Header=BB42_4 Depth=1
	block   	
	local.get	5
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label986
# %bb.16:                               #   in Loop: Header=BB42_4 Depth=1
	i32.const	-87
	local.set	9
	br      	1                               # 1: down to label985
.LBB42_17:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label986:
	block   	
	local.get	5
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label987
# %bb.18:                               #   in Loop: Header=BB42_4 Depth=1
	i32.const	-1
	local.set	8
	br      	2                               # 2: down to label981
.LBB42_19:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label987:
	i32.const	-55
	local.set	9
.LBB42_20:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label985:
	i32.const	-48
	local.set	11
	i32.const	-48
	local.set	12
	block   	
	local.get	7
	i32.load8_u	3
	local.tee	13
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label988
# %bb.21:                               #   in Loop: Header=BB42_4 Depth=1
	block   	
	local.get	13
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label989
# %bb.22:                               #   in Loop: Header=BB42_4 Depth=1
	i32.const	-87
	local.set	12
	br      	1                               # 1: down to label988
.LBB42_23:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label989:
	block   	
	local.get	13
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label990
# %bb.24:                               #   in Loop: Header=BB42_4 Depth=1
	i32.const	-1
	local.set	8
	br      	2                               # 2: down to label981
.LBB42_25:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label990:
	i32.const	-55
	local.set	12
.LBB42_26:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label988:
	block   	
	local.get	7
	i32.load8_u	4
	local.tee	7
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label991
# %bb.27:                               #   in Loop: Header=BB42_4 Depth=1
	block   	
	local.get	7
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label992
# %bb.28:                               #   in Loop: Header=BB42_4 Depth=1
	i32.const	-87
	local.set	11
	br      	1                               # 1: down to label991
.LBB42_29:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label992:
	block   	
	local.get	7
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label993
# %bb.30:                               #   in Loop: Header=BB42_4 Depth=1
	i32.const	-1
	local.set	8
	br      	2                               # 2: down to label981
.LBB42_31:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label993:
	i32.const	-55
	local.set	11
.LBB42_32:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label991:
	local.get	11
	local.get	7
	i32.add 
	local.get	9
	local.get	5
	i32.add 
	i32.const	4
	i32.shl 
	local.get	10
	local.get	8
	i32.add 
	i32.const	8
	i32.shl 
	i32.or  
	local.get	12
	local.get	13
	i32.add 
	i32.or  
	i32.const	4
	i32.shl 
	i32.or  
	local.set	8
.LBB42_33:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label981:
	local.get	1
	i32.const	6
	i32.add 
	local.set	1
.LBB42_34:                              #   in Loop: Header=BB42_4 Depth=1
	end_block                               # label979:
	i32.const	0
	local.set	5
	local.get	8
	local.get	3
	local.get	6
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	1                               # 1: down to label977
# %bb.35:                               #   in Loop: Header=BB42_4 Depth=1
	block   	
	local.get	6
	i32.const	1
	i32.add 
	local.tee	6
	local.get	4
	i32.ge_u
	br_if   	0                               # 0: down to label994
# %bb.36:                               #   in Loop: Header=BB42_4 Depth=1
	local.get	1
	local.get	2
	i32.lt_u
	br_if   	1                               # 1: up to label978
.LBB42_37:
	end_block                               # label994:
	end_loop
	local.get	6
	local.get	4
	i32.lt_u
	br_if   	0                               # 0: down to label977
# %bb.38:
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label977
# %bb.39:
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	5
.LBB42_40:
	end_block                               # label977:
	local.get	5
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.key_hex4,"",@
	.type	key_hex4,@function              # -- Begin function key_hex4
key_hex4:                               # @key_hex4
	.functype	key_hex4 (i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-48
	local.set	1
	i32.const	-48
	local.set	2
	block   	
	local.get	0
	i32.load8_u	0
	local.tee	3
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label995
# %bb.1:
	block   	
	local.get	3
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label996
# %bb.2:
	i32.const	-87
	local.set	2
	br      	1                               # 1: down to label995
.LBB43_3:
	end_block                               # label996:
	block   	
	local.get	3
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label997
# %bb.4:
	i32.const	-1
	return
.LBB43_5:
	end_block                               # label997:
	i32.const	-55
	local.set	2
.LBB43_6:
	end_block                               # label995:
	block   	
	local.get	0
	i32.load8_u	1
	local.tee	4
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label998
# %bb.7:
	block   	
	local.get	4
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label999
# %bb.8:
	i32.const	-87
	local.set	1
	br      	1                               # 1: down to label998
.LBB43_9:
	end_block                               # label999:
	block   	
	local.get	4
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label1000
# %bb.10:
	i32.const	-1
	return
.LBB43_11:
	end_block                               # label1000:
	i32.const	-55
	local.set	1
.LBB43_12:
	end_block                               # label998:
	i32.const	-48
	local.set	5
	i32.const	-48
	local.set	6
	block   	
	local.get	0
	i32.load8_u	2
	local.tee	7
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label1001
# %bb.13:
	block   	
	local.get	7
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label1002
# %bb.14:
	i32.const	-87
	local.set	6
	br      	1                               # 1: down to label1001
.LBB43_15:
	end_block                               # label1002:
	block   	
	local.get	7
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label1003
# %bb.16:
	i32.const	-1
	return
.LBB43_17:
	end_block                               # label1003:
	i32.const	-55
	local.set	6
.LBB43_18:
	end_block                               # label1001:
	block   	
	local.get	0
	i32.load8_u	3
	local.tee	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label1004
# %bb.19:
	block   	
	local.get	0
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label1005
# %bb.20:
	i32.const	-87
	local.set	5
	br      	1                               # 1: down to label1004
.LBB43_21:
	end_block                               # label1005:
	block   	
	local.get	0
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label1006
# %bb.22:
	i32.const	-1
	return
.LBB43_23:
	end_block                               # label1006:
	i32.const	-55
	local.set	5
.LBB43_24:
	end_block                               # label1004:
	local.get	5
	local.get	0
	i32.add 
	local.get	6
	local.get	7
	i32.add 
	local.get	2
	local.get	3
	i32.add 
	i32.const	8
	i32.shl 
	local.get	1
	local.get	4
	i32.add 
	i32.const	4
	i32.shl 
	i32.or  
	i32.or  
	i32.const	4
	i32.shl 
	i32.or  
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.write_normalized_glossary_value,"",@
	.type	write_normalized_glossary_value,@function # -- Begin function write_normalized_glossary_value
write_normalized_glossary_value:        # @write_normalized_glossary_value
	.functype	write_normalized_glossary_value (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	7
	global.set	__stack_pointer
	i32.const	0
	local.set	8
	block   	
	local.get	3
	local.get	2
	i32.le_u
	br_if   	0                               # 0: down to label1007
# %bb.1:
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	local.tee	9
	i32.load8_u	0
	local.tee	10
	i32.const	123
	i32.eq  
	br_if   	0                               # 0: down to label1010
# %bb.2:
	local.get	10
	i32.const	91
	i32.ne  
	br_if   	1                               # 1: down to label1009
# %bb.3:
	local.get	6
	i32.load	0
	local.tee	10
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label1007
# %bb.4:
	local.get	4
	local.get	10
	i32.add 
	i32.const	91
	i32.store8	0
	local.get	6
	local.get	6
	i32.load	0
	i32.const	1
	i32.add 
	local.tee	11
	i32.store	0
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label1011
# %bb.5:
	i32.const	0
	local.set	11
.LBB44_6:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB44_7 Depth 2
                                        #     Child Loop BB44_19 Depth 2
	loop    	                                # label1012:
	block   	
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label1013
.LBB44_7:                               #   Parent Loop BB44_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label1014:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label1013
# %bb.8:                                #   in Loop: Header=BB44_7 Depth=2
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label1013
# %bb.9:                                #   in Loop: Header=BB44_7 Depth=2
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label1014
# %bb.10:                               #   in Loop: Header=BB44_6 Depth=1
	end_loop
	local.get	1
	local.set	10
.LBB44_11:                              #   in Loop: Header=BB44_6 Depth=1
	end_block                               # label1013:
	i32.const	0
	local.set	8
	local.get	10
	local.get	3
	i32.ge_u
	br_if   	5                               # 5: down to label1007
# %bb.12:                               #   in Loop: Header=BB44_6 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.eq  
	br_if   	0                               # 0: down to label1015
# %bb.13:                               #   in Loop: Header=BB44_6 Depth=1
	local.get	7
	i32.const	0
	i32.store	8
	local.get	0
	local.get	1
	local.get	10
	local.get	7
	i32.const	8
	i32.add 
	call	parse_value_span
	i32.eqz
	br_if   	6                               # 6: down to label1007
# %bb.14:                               #   in Loop: Header=BB44_6 Depth=1
	block   	
	local.get	11
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label1016
# %bb.15:                               #   in Loop: Header=BB44_6 Depth=1
	local.get	6
	i32.load	0
	local.tee	2
	local.get	5
	i32.ge_u
	br_if   	7                               # 7: down to label1007
# %bb.16:                               #   in Loop: Header=BB44_6 Depth=1
	local.get	4
	local.get	2
	i32.add 
	i32.const	44
	i32.store8	0
	local.get	6
	local.get	6
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
.LBB44_17:                              #   in Loop: Header=BB44_6 Depth=1
	end_block                               # label1016:
	local.get	0
	local.get	1
	local.get	10
	local.get	7
	i32.load	8
	local.tee	2
	local.get	4
	local.get	5
	local.get	6
	call	write_normalized_glossary_value
	i32.eqz
	br_if   	6                               # 6: down to label1007
# %bb.18:                               #   in Loop: Header=BB44_6 Depth=1
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label1017
.LBB44_19:                              #   Parent Loop BB44_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label1018:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label1017
# %bb.20:                               #   in Loop: Header=BB44_19 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label1017
# %bb.21:                               #   in Loop: Header=BB44_19 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label1018
# %bb.22:                               #   in Loop: Header=BB44_6 Depth=1
	end_loop
	local.get	1
	local.set	2
.LBB44_23:                              #   in Loop: Header=BB44_6 Depth=1
	end_block                               # label1017:
	block   	
	block   	
	local.get	2
	local.get	3
	i32.lt_u
	br_if   	0                               # 0: down to label1020
# %bb.24:                               #   in Loop: Header=BB44_6 Depth=1
	local.get	2
	local.set	10
	br      	1                               # 1: down to label1019
.LBB44_25:                              #   in Loop: Header=BB44_6 Depth=1
	end_block                               # label1020:
	local.get	2
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.eq  
	i32.add 
	local.set	10
.LBB44_26:                              #   in Loop: Header=BB44_6 Depth=1
	end_block                               # label1019:
	i32.const	1
	local.set	11
	local.get	10
	local.get	3
	i32.lt_u
	br_if   	1                               # 1: up to label1012
.LBB44_27:
	end_block                               # label1015:
	end_loop
	local.get	6
	i32.load	0
	local.set	11
.LBB44_28:
	end_block                               # label1011:
	i32.const	0
	local.set	8
	local.get	11
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label1007
# %bb.29:
	local.get	4
	local.get	11
	i32.add 
	i32.const	93
	i32.store8	0
	i32.const	1
	local.set	8
	local.get	6
	local.get	6
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
	br      	3                               # 3: down to label1007
.LBB44_30:
	end_block                               # label1010:
	local.get	3
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label1009
# %bb.31:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label1021
# %bb.32:
.LBB44_33:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label1022:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	1
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label1021
# %bb.34:                               #   in Loop: Header=BB44_33 Depth=1
	i32.const	1
	local.get	1
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label1021
# %bb.35:                               #   in Loop: Header=BB44_33 Depth=1
	local.get	3
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label1022
	br      	2                               # 2: down to label1009
.LBB44_36:
	end_loop
	end_block                               # label1021:
	local.get	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label1009
# %bb.37:
	local.get	0
	i32.const	1
	i32.add 
	local.set	12
	local.get	0
	i32.const	2
	i32.add 
	local.set	13
	local.get	0
	i32.const	5
	i32.add 
	local.set	14
	local.get	0
	i32.const	4
	i32.add 
	local.set	15
	local.get	0
	i32.const	3
	i32.add 
	local.set	16
	i32.const	0
	local.set	17
	i32.const	0
	local.set	18
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
.LBB44_38:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB44_49 Depth 2
                                        #     Child Loop BB44_102 Depth 2
                                        #     Child Loop BB44_108 Depth 2
                                        #     Child Loop BB44_134 Depth 2
                                        #     Child Loop BB44_141 Depth 2
	loop    	                                # label1023:
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	34
	i32.eq  
	br_if   	0                               # 0: down to label1024
# %bb.39:
	local.get	1
	i32.const	125
	i32.ne  
	br_if   	2                               # 2: down to label1009
# %bb.40:
	local.get	20
	i32.eqz
	br_if   	2                               # 2: down to label1009
# %bb.41:
	local.get	19
	i32.eqz
	br_if   	2                               # 2: down to label1009
# %bb.42:
	i32.const	0
	local.set	8
	local.get	6
	i32.load	0
	local.tee	10
	local.get	17
	i32.add 
	local.tee	2
	local.get	10
	i32.lt_u
	br_if   	4                               # 4: down to label1007
# %bb.43:
	local.get	2
	local.get	5
	i32.gt_u
	br_if   	4                               # 4: down to label1007
# %bb.44:
	block   	
	local.get	17
	i32.eqz
	br_if   	0                               # 0: down to label1025
# %bb.45:
	local.get	4
	local.get	10
	i32.add 
	local.get	0
	local.get	18
	i32.add 
	local.get	17
	memory.copy	0, 0
.LBB44_46:
	end_block                               # label1025:
	local.get	6
	local.get	2
	i32.store	0
	br      	3                               # 3: down to label1008
.LBB44_47:                              #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1024:
	local.get	10
	i32.const	1
	i32.add 
	local.tee	21
	local.get	3
	i32.ge_u
	br_if   	1                               # 1: down to label1009
# %bb.48:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	21
	local.set	11
.LBB44_49:                              #   Parent Loop BB44_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label1026:
	block   	
	local.get	11
	local.tee	1
	i32.const	8
	i32.add 
	local.tee	11
	local.get	3
	i32.gt_u
	br_if   	0                               # 0: down to label1027
# %bb.50:                               #   in Loop: Header=BB44_49 Depth=2
	local.get	0
	local.get	1
	i32.add 
	i64.load	0:p2align=0
	local.tee	22
	i64.const	-1
	i64.xor 
	local.get	22
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	22
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	22
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	22
	i64.eqz
	br_if   	1                               # 1: up to label1026
# %bb.51:                               #   in Loop: Header=BB44_49 Depth=2
	local.get	22
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	1
	i32.add 
	local.set	1
.LBB44_52:                              #   in Loop: Header=BB44_49 Depth=2
	end_block                               # label1027:
	local.get	1
	local.get	3
	i32.ge_u
	br_if   	2                               # 2: down to label1009
# %bb.53:                               #   in Loop: Header=BB44_49 Depth=2
	block   	
	block   	
	block   	
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label1030
# %bb.54:                               #   in Loop: Header=BB44_49 Depth=2
	local.get	1
	i32.const	1
	i32.add 
	local.tee	11
	local.get	3
	i32.ge_u
	br_if   	5                               # 5: down to label1009
# %bb.55:                               #   in Loop: Header=BB44_49 Depth=2
	block   	
	block   	
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 1, 0, 7} # 7: down to label1009
                                        # 1: down to label1031
                                        # 0: down to label1032
.LBB44_56:                              #   in Loop: Header=BB44_49 Depth=2
	end_block                               # label1032:
	local.get	1
	i32.const	6
	i32.add 
	local.tee	11
	local.get	3
	i32.gt_u
	br_if   	6                               # 6: down to label1009
# %bb.57:                               #   in Loop: Header=BB44_49 Depth=2
	local.get	1
	i32.const	2
	i32.add 
	local.tee	23
	local.get	11
	i32.ge_u
	br_if   	2                               # 2: down to label1029
# %bb.58:                               #   in Loop: Header=BB44_49 Depth=2
	block   	
	local.get	0
	local.get	23
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label1033
# %bb.59:                               #   in Loop: Header=BB44_49 Depth=2
	local.get	23
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label1009
.LBB44_60:                              #   in Loop: Header=BB44_49 Depth=2
	end_block                               # label1033:
	block   	
	local.get	16
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label1034
# %bb.61:                               #   in Loop: Header=BB44_49 Depth=2
	local.get	23
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label1009
.LBB44_62:                              #   in Loop: Header=BB44_49 Depth=2
	end_block                               # label1034:
	block   	
	local.get	15
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label1035
# %bb.63:                               #   in Loop: Header=BB44_49 Depth=2
	local.get	23
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label1009
.LBB44_64:                              #   in Loop: Header=BB44_49 Depth=2
	end_block                               # label1035:
	local.get	14
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label1029
# %bb.65:                               #   in Loop: Header=BB44_49 Depth=2
	local.get	1
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label1029
	br      	6                               # 6: down to label1009
.LBB44_66:                              #   in Loop: Header=BB44_49 Depth=2
	end_block                               # label1031:
	local.get	1
	i32.const	2
	i32.add 
	local.set	11
	br      	1                               # 1: down to label1029
.LBB44_67:                              #   in Loop: Header=BB44_49 Depth=2
	end_block                               # label1030:
	local.get	23
	i32.const	32
	i32.lt_u
	br_if   	4                               # 4: down to label1009
# %bb.68:                               #   in Loop: Header=BB44_49 Depth=2
	local.get	1
	i32.const	1
	i32.add 
	local.set	11
	local.get	23
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label1028
.LBB44_69:                              #   in Loop: Header=BB44_49 Depth=2
	end_block                               # label1029:
	local.get	11
	local.get	3
	i32.lt_u
	br_if   	1                               # 1: up to label1026
	br      	3                               # 3: down to label1009
.LBB44_70:                              #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1028:
	end_loop
	i32.const	0
	local.set	23
	i32.const	0
	local.set	24
	block   	
	local.get	1
	local.get	10
	i32.lt_u
	br_if   	0                               # 0: down to label1036
# %bb.71:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	10
	i32.const	5
	i32.add 
	local.set	25
	i32.const	0
	local.set	24
	i32.const	0
	local.set	23
	block   	
	local.get	1
	local.get	10
	i32.eq  
	br_if   	0                               # 0: down to label1037
# %bb.72:                               #   in Loop: Header=BB44_38 Depth=1
	block   	
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	local.tee	26
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label1038
# %bb.73:                               #   in Loop: Header=BB44_38 Depth=1
	i32.const	0
	local.set	23
	local.get	1
	local.get	10
	i32.sub 
	local.tee	27
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label1037
# %bb.74:                               #   in Loop: Header=BB44_38 Depth=1
	i32.const	0
	local.set	23
	local.get	26
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label1037
# %bb.75:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	13
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	26
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label1038
# %bb.76:                               #   in Loop: Header=BB44_38 Depth=1
	i32.const	0
	local.set	23
	local.get	26
	i32.const	121
	i32.ne  
	br_if   	1                               # 1: down to label1037
# %bb.77:                               #   in Loop: Header=BB44_38 Depth=1
	i32.const	0
	local.set	23
	local.get	27
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label1037
# %bb.78:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	16
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	26
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label1038
# %bb.79:                               #   in Loop: Header=BB44_38 Depth=1
	i32.const	0
	local.set	23
	local.get	26
	i32.const	112
	i32.ne  
	br_if   	1                               # 1: down to label1037
# %bb.80:                               #   in Loop: Header=BB44_38 Depth=1
	i32.const	0
	local.set	23
	local.get	27
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label1037
# %bb.81:                               #   in Loop: Header=BB44_38 Depth=1
	i32.const	0
	local.set	23
	block   	
	local.get	15
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label1037
                                        # 0: down to label1039
.LBB44_82:                              #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1039:
	i32.const	0
	local.set	23
	local.get	25
	local.get	1
	i32.gt_u
	br_if   	1                               # 1: down to label1037
# %bb.83:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	0
	local.get	25
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	23
	br      	1                               # 1: down to label1037
.LBB44_84:                              #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1038:
	local.get	0
	local.get	10
	local.get	11
	i32.const	.L.str.2
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	23
.LBB44_85:                              #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1037:
	local.get	1
	local.get	10
	i32.le_u
	br_if   	0                               # 0: down to label1036
# %bb.86:                               #   in Loop: Header=BB44_38 Depth=1
	block   	
	block   	
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	local.tee	21
	i32.const	116
	i32.ne  
	br_if   	0                               # 0: down to label1041
# %bb.87:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	10
	i32.const	2
	i32.add 
	local.tee	21
	local.get	1
	i32.gt_u
	br_if   	2                               # 2: down to label1036
# %bb.88:                               #   in Loop: Header=BB44_38 Depth=1
	block   	
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{2, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label1036
                                        # 0: down to label1042
.LBB44_89:                              #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1042:
	local.get	10
	i32.const	3
	i32.add 
	local.tee	21
	local.get	1
	i32.gt_u
	br_if   	2                               # 2: down to label1036
# %bb.90:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	local.tee	21
	i32.const	92
	i32.eq  
	br_if   	1                               # 1: down to label1040
# %bb.91:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	21
	i32.const	120
	i32.ne  
	br_if   	2                               # 2: down to label1036
# %bb.92:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	10
	i32.const	4
	i32.add 
	local.tee	21
	local.get	1
	i32.gt_u
	br_if   	2                               # 2: down to label1036
# %bb.93:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	local.tee	21
	i32.const	92
	i32.eq  
	br_if   	1                               # 1: down to label1040
# %bb.94:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	21
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label1036
# %bb.95:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	25
	local.get	1
	i32.gt_u
	br_if   	2                               # 2: down to label1036
# %bb.96:                               #   in Loop: Header=BB44_38 Depth=1
	local.get	0
	local.get	25
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	24
	br      	2                               # 2: down to label1036
.LBB44_97:                              #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1041:
	local.get	21
	i32.const	92
	i32.ne  
	br_if   	1                               # 1: down to label1036
.LBB44_98:                              #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1040:
	local.get	0
	local.get	10
	local.get	11
	i32.const	.L.str.10
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	24
.LBB44_99:                              #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1036:
	block   	
	local.get	23
	br_if   	0                               # 0: down to label1043
# %bb.100:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	24
	i32.eqz
	br_if   	2                               # 2: down to label1009
.LBB44_101:                             #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1043:
	block   	
	local.get	11
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label1044
.LBB44_102:                             #   Parent Loop BB44_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label1045:
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label1044
# %bb.103:                              #   in Loop: Header=BB44_102 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label1044
# %bb.104:                              #   in Loop: Header=BB44_102 Depth=2
	local.get	3
	local.get	11
	i32.const	1
	i32.add 
	local.tee	11
	i32.ne  
	br_if   	0                               # 0: up to label1045
	br      	3                               # 3: down to label1009
.LBB44_105:                             #   in Loop: Header=BB44_38 Depth=1
	end_loop
	end_block                               # label1044:
	local.get	11
	local.get	3
	i32.ge_u
	br_if   	1                               # 1: down to label1009
# %bb.106:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	1                               # 1: down to label1009
# %bb.107:                              #   in Loop: Header=BB44_38 Depth=1
	block   	
	local.get	11
	i32.const	1
	i32.add 
	local.tee	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label1046
.LBB44_108:                             #   Parent Loop BB44_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label1047:
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label1046
# %bb.109:                              #   in Loop: Header=BB44_108 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label1046
# %bb.110:                              #   in Loop: Header=BB44_108 Depth=2
	local.get	3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	0                               # 0: up to label1047
# %bb.111:                              #   in Loop: Header=BB44_38 Depth=1
	end_loop
	local.get	3
	local.set	1
.LBB44_112:                             #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1046:
	local.get	7
	i32.const	0
	i32.store	12
	local.get	0
	local.get	3
	local.get	1
	local.get	7
	i32.const	12
	i32.add 
	call	parse_value_span
	i32.eqz
	br_if   	1                               # 1: down to label1009
# %bb.113:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	7
	i32.load	12
	local.set	10
	block   	
	block   	
	block   	
	block   	
	local.get	23
	i32.eqz
	br_if   	0                               # 0: down to label1051
# %bb.114:                              #   in Loop: Header=BB44_38 Depth=1
	i32.const	0
	local.set	20
	local.get	10
	local.get	1
	i32.le_u
	br_if   	3                               # 3: down to label1048
# %bb.115:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	3                               # 3: down to label1048
# %bb.116:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	10
	local.get	1
	i32.const	-1
	i32.xor 
	i32.add 
	local.tee	11
	i32.eqz
	br_if   	3                               # 3: down to label1048
# %bb.117:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	12
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	92
	i32.eq  
	br_if   	2                               # 2: down to label1049
# %bb.118:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	11
	i32.const	1
	i32.eq  
	br_if   	3                               # 3: down to label1048
# %bb.119:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	23
	i32.const	116
	i32.ne  
	br_if   	3                               # 3: down to label1048
# %bb.120:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	13
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{2, 3, 3, 3, 3, 3, 3, 3, 3, 1, 3} # 3: down to label1048
                                        # 1: down to label1050
.LBB44_121:                             #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1051:
	i32.const	0
	local.set	19
	block   	
	local.get	10
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label1052
# %bb.122:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	19
.LBB44_123:                             #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1052:
	local.get	10
	local.get	1
	i32.sub 
	local.set	17
	local.get	1
	local.set	18
	br      	2                               # 2: down to label1048
.LBB44_124:                             #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1050:
	local.get	11
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label1048
# %bb.125:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	16
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label1049
# %bb.126:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	23
	i32.const	120
	i32.ne  
	br_if   	1                               # 1: down to label1048
# %bb.127:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	11
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label1048
# %bb.128:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	15
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label1049
# %bb.129:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	11
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label1048
# %bb.130:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	1
	i32.const	5
	i32.add 
	local.tee	1
	local.get	10
	i32.ge_u
	br_if   	1                               # 1: down to label1048
# %bb.131:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	20
	br      	1                               # 1: down to label1048
.LBB44_132:                             #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1049:
	local.get	0
	local.get	1
	local.get	10
	i32.const	.L.str.10
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	20
.LBB44_133:                             #   in Loop: Header=BB44_38 Depth=1
	end_block                               # label1048:
	block   	
	local.get	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label1053
.LBB44_134:                             #   Parent Loop BB44_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label1054:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	1
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label1053
# %bb.135:                              #   in Loop: Header=BB44_134 Depth=2
	i32.const	1
	local.get	1
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label1053
# %bb.136:                              #   in Loop: Header=BB44_134 Depth=2
	local.get	3
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label1054
	br      	3                               # 3: down to label1009
.LBB44_137:                             #   in Loop: Header=BB44_38 Depth=1
	end_loop
	end_block                               # label1053:
	local.get	10
	local.get	3
	i32.ge_u
	br_if   	1                               # 1: down to label1009
# %bb.138:                              #   in Loop: Header=BB44_38 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	125
	i32.eq  
	br_if   	0                               # 0: down to label1055
# %bb.139:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	1
	i32.const	44
	i32.ne  
	br_if   	2                               # 2: down to label1009
# %bb.140:                              #   in Loop: Header=BB44_38 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label1055
.LBB44_141:                             #   Parent Loop BB44_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label1056:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	1
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label1055
# %bb.142:                              #   in Loop: Header=BB44_141 Depth=2
	i32.const	1
	local.get	1
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label1055
# %bb.143:                              #   in Loop: Header=BB44_141 Depth=2
	local.get	3
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label1056
	br      	3                               # 3: down to label1009
.LBB44_144:                             #   in Loop: Header=BB44_38 Depth=1
	end_loop
	end_block                               # label1055:
	local.get	10
	local.get	3
	i32.lt_u
	br_if   	0                               # 0: up to label1023
.LBB44_145:
	end_loop
	end_block                               # label1009:
	local.get	6
	i32.load	0
	local.tee	10
	local.get	3
	local.get	2
	i32.sub 
	local.tee	2
	i32.add 
	local.tee	0
	local.get	10
	i32.lt_u
	br_if   	1                               # 1: down to label1007
# %bb.146:
	local.get	0
	local.get	5
	i32.gt_u
	br_if   	1                               # 1: down to label1007
# %bb.147:
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label1057
# %bb.148:
	local.get	4
	local.get	10
	i32.add 
	local.get	9
	local.get	2
	memory.copy	0, 0
.LBB44_149:
	end_block                               # label1057:
	local.get	6
	local.get	0
	i32.store	0
.LBB44_150:
	end_block                               # label1008:
	i32.const	1
	local.set	8
.LBB44_151:
	end_block                               # label1007:
	local.get	7
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	8
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.hash_content_xxh32_pair,"",@
	.type	hash_content_xxh32_pair,@function # -- Begin function hash_content_xxh32_pair
hash_content_xxh32_pair:                # @hash_content_xxh32_pair
	.functype	hash_content_xxh32_pair (i32, i32, i32, i32) -> ()
	.local  	i32, i32, v128, v128, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	local.get	0
	local.get	1
	i32.add 
	local.set	4
	block   	
	block   	
	local.get	1
	i32.const	-64
	i32.add 
	i32.const	448
	i32.gt_u
	br_if   	0                               # 0: down to label1059
# %bb.1:
	local.get	4
	i32.const	-16
	i32.add 
	local.set	5
	v128.const	-1522540051, 117991484, -2128831035, -488299500
	local.set	6
	v128.const	-1034240543, 606290992, -1640531527, 8
	local.set	7
.LBB45_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label1060:
	local.get	0
	v128.load	0:p2align=0
	v128.const	-2048144777, -2048144777, -2048144777, -2048144777
	i32x4.mul
	local.tee	8
	local.get	7
	i32x4.add
	local.tee	7
	i32.const	13
	i32x4.shl
	local.get	7
	i32.const	19
	i32x4.shr_u
	v128.or
	v128.const	-1640531535, -1640531535, -1640531535, -1640531535
	local.tee	9
	i32x4.mul
	local.set	7
	local.get	8
	local.get	6
	i32x4.add
	local.tee	6
	i32.const	13
	i32x4.shl
	local.get	6
	i32.const	19
	i32x4.shr_u
	v128.or
	local.get	9
	i32x4.mul
	local.set	6
	local.get	0
	i32.const	16
	i32.add 
	local.tee	0
	local.get	5
	i32.le_u
	br_if   	0                               # 0: up to label1060
# %bb.3:
	end_loop
	local.get	7
	i32x4.extract_lane	0
	i32.const	1
	i32.rotl
	local.get	7
	i32x4.extract_lane	1
	i32.const	7
	i32.rotl
	i32.add 
	local.get	7
	i32x4.extract_lane	2
	i32.const	12
	i32.rotl
	i32.add 
	local.get	7
	i32x4.extract_lane	3
	i32.const	18
	i32.rotl
	i32.add 
	local.set	5
	local.get	6
	i32x4.extract_lane	0
	i32.const	1
	i32.rotl
	local.get	6
	i32x4.extract_lane	1
	i32.const	7
	i32.rotl
	i32.add 
	local.get	6
	i32x4.extract_lane	2
	i32.const	12
	i32.rotl
	i32.add 
	local.get	6
	i32x4.extract_lane	3
	i32.const	18
	i32.rotl
	i32.add 
	local.set	10
	br      	1                               # 1: down to label1058
.LBB45_4:
	end_block                               # label1059:
	block   	
	local.get	1
	i32.const	16
	i32.ge_u
	br_if   	0                               # 0: down to label1061
# %bb.5:
	i32.const	-1754069642
	local.set	10
	i32.const	-1265770134
	local.set	5
	br      	1                               # 1: down to label1058
.LBB45_6:
	end_block                               # label1061:
	local.get	4
	i32.const	-16
	i32.add 
	local.set	11
	i32.const	-1640531527
	local.set	5
	i32.const	606290992
	local.set	10
	i32.const	-1034240543
	local.set	12
	i32.const	-488299500
	local.set	13
	i32.const	-2128831035
	local.set	14
	i32.const	117991484
	local.set	15
	i32.const	-1522540051
	local.set	16
	i32.const	8
	local.set	17
.LBB45_7:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label1062:
	local.get	0
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.tee	18
	local.get	12
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	12
	local.get	18
	local.get	16
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	16
	local.get	0
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.tee	18
	local.get	17
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	17
	local.get	18
	local.get	13
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	13
	local.get	0
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.tee	18
	local.get	5
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	5
	local.get	18
	local.get	14
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	14
	local.get	0
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.tee	18
	local.get	10
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	10
	local.get	18
	local.get	15
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	15
	local.get	0
	i32.const	16
	i32.add 
	local.tee	0
	local.get	11
	i32.le_u
	br_if   	0                               # 0: up to label1062
# %bb.8:
	end_loop
	local.get	10
	i32.const	7
	i32.rotl
	local.get	12
	i32.const	1
	i32.rotl
	i32.add 
	local.get	5
	i32.const	12
	i32.rotl
	i32.add 
	local.get	17
	i32.const	18
	i32.rotl
	i32.add 
	local.set	5
	local.get	15
	i32.const	7
	i32.rotl
	local.get	16
	i32.const	1
	i32.rotl
	i32.add 
	local.get	14
	i32.const	12
	i32.rotl
	i32.add 
	local.get	13
	i32.const	18
	i32.rotl
	i32.add 
	local.set	10
.LBB45_9:
	end_block                               # label1058:
	local.get	5
	local.get	1
	i32.add 
	local.set	5
	local.get	10
	local.get	1
	i32.add 
	local.set	10
	block   	
	block   	
	local.get	0
	i32.const	4
	i32.add 
	local.get	4
	i32.le_u
	br_if   	0                               # 0: down to label1064
# %bb.10:
	local.get	0
	local.set	12
	br      	1                               # 1: down to label1063
.LBB45_11:
	end_block                               # label1064:
.LBB45_12:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label1065:
	local.get	0
	i32.load	0:p2align=0
	i32.const	-1028477379
	i32.mul 
	local.tee	12
	local.get	5
	i32.add 
	i32.const	17
	i32.rotl
	i32.const	668265263
	i32.mul 
	local.set	5
	local.get	12
	local.get	10
	i32.add 
	i32.const	17
	i32.rotl
	i32.const	668265263
	i32.mul 
	local.set	10
	local.get	0
	i32.const	8
	i32.add 
	local.set	13
	local.get	0
	i32.const	4
	i32.add 
	local.tee	12
	local.set	0
	local.get	13
	local.get	4
	i32.le_u
	br_if   	0                               # 0: up to label1065
.LBB45_13:
	end_loop
	end_block                               # label1063:
	block   	
	local.get	12
	local.get	4
	i32.ge_u
	br_if   	0                               # 0: down to label1066
# %bb.14:
	local.get	12
	i32.const	1
	i32.add 
	local.set	0
	block   	
	local.get	4
	local.get	12
	i32.sub 
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label1067
# %bb.15:
	local.get	12
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.tee	12
	local.get	5
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	5
	local.get	12
	local.get	10
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	10
	local.get	0
	local.set	12
.LBB45_16:
	end_block                               # label1067:
	local.get	4
	local.get	0
	i32.eq  
	br_if   	0                               # 0: down to label1066
# %bb.17:
.LBB45_18:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label1068:
	local.get	12
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.tee	0
	local.get	12
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.tee	13
	local.get	5
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	5
	local.get	0
	local.get	13
	local.get	10
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	10
	local.get	12
	i32.const	2
	i32.add 
	local.tee	12
	local.get	4
	i32.ne  
	br_if   	0                               # 0: up to label1068
.LBB45_19:
	end_loop
	end_block                               # label1066:
	local.get	2
	local.get	10
	i32.const	15
	i32.shr_u
	local.get	10
	i32.xor 
	i32.const	-2048144777
	i32.mul 
	local.tee	0
	i32.const	13
	i32.shr_u
	local.get	0
	i32.xor 
	i32.const	-1028477379
	i32.mul 
	local.tee	0
	i32.const	16
	i32.shr_u
	local.get	0
	i32.xor 
	i32.store	0
	local.get	3
	local.get	5
	i32.const	15
	i32.shr_u
	local.get	5
	i32.xor 
	i32.const	-2048144777
	i32.mul 
	local.tee	0
	i32.const	13
	i32.shr_u
	local.get	0
	i32.xor 
	i32.const	-1028477379
	i32.mul 
	local.tee	0
	i32.const	16
	i32.shr_u
	local.get	0
	i32.xor 
	i32.store	0
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.reuse_validated_glossary,"",@
	.type	reuse_validated_glossary,@function # -- Begin function reuse_validated_glossary
reuse_validated_glossary:               # @reuse_validated_glossary
	.functype	reuse_validated_glossary (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, v128, v128
# %bb.0:
	i32.const	0
	local.set	9
	block   	
	local.get	1
	local.get	2
	i32.le_u
	br_if   	0                               # 0: down to label1069
# %bb.1:
	local.get	0
	local.get	2
	i32.add 
	local.tee	10
	i32.load8_u	0
	local.tee	11
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	0                               # 0: down to label1069
# %bb.2:
	i32.const	0
	local.set	9
	local.get	4
	i32.const	0
	local.get	4
	local.get	8
	i32.sub 
	local.tee	8
	local.get	8
	local.get	4
	i32.gt_u
	i32.select
	local.tee	12
	i32.le_u
	br_if   	0                               # 0: down to label1069
# %bb.3:
	local.get	0
	local.get	2
	i32.add 
	local.set	13
	local.get	1
	local.get	2
	i32.sub 
	local.set	14
.LBB46_4:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB46_10 Depth 2
                                        #     Child Loop BB46_16 Depth 2
                                        #     Child Loop BB46_19 Depth 2
                                        #     Child Loop BB46_21 Depth 2
                                        #     Child Loop BB46_24 Depth 2
	loop    	                                # label1070:
	block   	
	local.get	3
	local.get	4
	i32.const	-1
	i32.add 
	local.tee	4
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	15
	i32.load	40
	local.tee	16
	i32.const	-1
	i32.add 
	local.get	14
	i32.ge_u
	br_if   	0                               # 0: down to label1071
# %bb.5:                                #   in Loop: Header=BB46_4 Depth=1
	local.get	11
	local.get	0
	local.get	15
	i32.load	36
	local.tee	17
	i32.add 
	local.tee	1
	i32.load8_u	0
	i32.ne  
	br_if   	0                               # 0: down to label1071
# %bb.6:                                #   in Loop: Header=BB46_4 Depth=1
	local.get	16
	i32.const	8
	local.get	16
	i32.const	8
	i32.lt_u
	i32.select
	local.set	18
	local.get	17
	local.get	16
	i32.add 
	local.set	19
	local.get	16
	local.get	2
	i32.add 
	local.set	20
	block   	
	local.get	16
	i32.const	7
	i32.gt_u
	local.tee	21
	i32.eqz
	br_if   	0                               # 0: down to label1072
# %bb.7:                                #   in Loop: Header=BB46_4 Depth=1
	local.get	0
	local.get	20
	local.get	18
	i32.sub 
	i32.add 
	i64.load	0:p2align=0
	local.get	0
	local.get	19
	local.get	18
	i32.sub 
	i32.add 
	i64.load	0:p2align=0
	i64.ne  
	br_if   	1                               # 1: down to label1071
.LBB46_8:                               #   in Loop: Header=BB46_4 Depth=1
	end_block                               # label1072:
	block   	
	local.get	18
	i32.const	8
	i32.and 
	local.tee	22
	local.get	18
	i32.eq  
	local.tee	23
	br_if   	0                               # 0: down to label1073
# %bb.9:                                #   in Loop: Header=BB46_4 Depth=1
	local.get	13
	local.get	16
	i32.add 
	local.set	24
	local.get	22
	local.get	18
	i32.sub 
	local.set	8
	local.get	0
	local.get	19
	i32.add 
	local.set	19
.LBB46_10:                              #   Parent Loop BB46_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label1074:
	local.get	24
	local.get	8
	i32.add 
	i32.load8_u	0
	local.get	19
	local.get	8
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	2                               # 2: down to label1071
# %bb.11:                               #   in Loop: Header=BB46_10 Depth=2
	local.get	8
	i32.const	1
	i32.add 
	local.tee	8
	br_if   	0                               # 0: up to label1074
.LBB46_12:                              #   in Loop: Header=BB46_4 Depth=1
	end_loop
	end_block                               # label1073:
	local.get	16
	local.get	18
	i32.sub 
	i32.const	1
	i32.shr_u
	local.set	8
	block   	
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label1075
# %bb.13:                               #   in Loop: Header=BB46_4 Depth=1
	local.get	10
	local.get	8
	i32.add 
	i64.load	0:p2align=0
	local.get	1
	local.get	8
	i32.add 
	i64.load	0:p2align=0
	i64.ne  
	br_if   	1                               # 1: down to label1071
.LBB46_14:                              #   in Loop: Header=BB46_4 Depth=1
	end_block                               # label1075:
	block   	
	local.get	23
	br_if   	0                               # 0: down to label1076
# %bb.15:                               #   in Loop: Header=BB46_4 Depth=1
	local.get	18
	local.get	22
	i32.sub 
	local.set	19
	local.get	13
	local.get	8
	local.get	22
	i32.add 
	local.tee	24
	i32.add 
	local.set	8
	local.get	0
	local.get	24
	local.get	17
	i32.add 
	i32.add 
	local.set	24
.LBB46_16:                              #   Parent Loop BB46_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label1077:
	local.get	8
	i32.load8_u	0
	local.get	24
	i32.load8_u	0
	i32.ne  
	br_if   	2                               # 2: down to label1071
# %bb.17:                               #   in Loop: Header=BB46_16 Depth=2
	local.get	8
	i32.const	1
	i32.add 
	local.set	8
	local.get	24
	i32.const	1
	i32.add 
	local.set	24
	local.get	19
	i32.const	-1
	i32.add 
	local.tee	19
	br_if   	0                               # 0: up to label1077
.LBB46_18:                              #   in Loop: Header=BB46_4 Depth=1
	end_loop
	end_block                               # label1076:
	i32.const	0
	local.set	24
	local.get	16
	local.set	19
	local.get	10
	local.set	8
.LBB46_19:                              #   Parent Loop BB46_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label1079:
	block   	
	local.get	16
	local.get	24
	i32.add 
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label1080
# %bb.20:                               #   in Loop: Header=BB46_4 Depth=1
	i32.const	0
	local.set	18
	local.get	8
	local.set	17
	local.get	1
	local.set	21
	local.get	16
	local.set	22
.LBB46_21:                              #   Parent Loop BB46_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label1082:
	block   	
	local.get	24
	local.get	22
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label1083
# %bb.22:                               #   in Loop: Header=BB46_4 Depth=1
	local.get	18
	local.get	24
	i32.sub 
	local.get	16
	i32.lt_u
	br_if   	2                               # 2: down to label1081
	br      	5                               # 5: down to label1078
.LBB46_23:                              #   in Loop: Header=BB46_21 Depth=2
	end_block                               # label1083:
	local.get	1
	local.get	18
	i32.add 
	local.set	23
	local.get	8
	local.get	18
	i32.add 
	local.set	25
	local.get	17
	i32.const	8
	i32.add 
	local.set	17
	local.get	21
	i32.const	8
	i32.add 
	local.set	21
	local.get	19
	i32.const	-8
	i32.add 
	local.set	19
	local.get	22
	i32.const	-8
	i32.add 
	local.set	22
	local.get	18
	i32.const	8
	i32.add 
	local.set	18
	local.get	25
	i64.load	0:p2align=0
	local.get	23
	i64.load	0:p2align=0
	i64.ne  
	br_if   	5                               # 5: down to label1071
	br      	0                               # 0: up to label1082
.LBB46_24:                              #   Parent Loop BB46_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	end_loop
	end_block                               # label1081:
	loop    	                                # label1084:
	local.get	17
	i32.load8_u	0
	local.get	21
	i32.load8_u	0
	i32.ne  
	br_if   	4                               # 4: down to label1071
# %bb.25:                               #   in Loop: Header=BB46_24 Depth=2
	local.get	17
	i32.const	1
	i32.add 
	local.set	17
	local.get	21
	i32.const	1
	i32.add 
	local.set	21
	local.get	19
	i32.const	-1
	i32.add 
	local.tee	19
	i32.eqz
	br_if   	3                               # 3: down to label1078
	br      	0                               # 0: up to label1084
.LBB46_26:                              #   in Loop: Header=BB46_19 Depth=2
	end_loop
	end_block                               # label1080:
	local.get	8
	i32.const	16
	i32.add 
	local.set	18
	local.get	1
	i32.const	16
	i32.add 
	local.set	17
	local.get	8
	v128.load	0:p2align=0
	local.set	26
	local.get	1
	v128.load	0:p2align=0
	local.set	27
	local.get	19
	i32.const	-32
	i32.add 
	local.set	19
	local.get	8
	i32.const	32
	i32.add 
	local.set	8
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	24
	i32.const	-32
	i32.add 
	local.set	24
	local.get	17
	v128.load	0:p2align=0
	local.get	18
	v128.load	0:p2align=0
	v128.xor
	local.get	27
	local.get	26
	v128.xor
	v128.or
	v128.any_true
	br_if   	2                               # 2: down to label1071
	br      	0                               # 0: up to label1079
.LBB46_27:
	end_loop
	end_block                               # label1078:
	local.get	5
	local.get	15
	i64.load	56:p2align=2
	i64.store	56:p2align=2
	local.get	5
	local.get	15
	i32.load	64
	i32.store	64
	local.get	6
	local.get	20
	i32.store	0
	local.get	7
	local.get	4
	i32.store	0
	i32.const	1
	local.set	9
	br      	2                               # 2: down to label1069
.LBB46_28:                              #   in Loop: Header=BB46_4 Depth=1
	end_block                               # label1071:
	local.get	4
	local.get	12
	i32.gt_u
	br_if   	0                               # 0: up to label1070
.LBB46_29:
	end_loop
	end_block                               # label1069:
	local.get	9
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_value_span_with_glossary_hints,"",@
	.type	parse_value_span_with_glossary_hints,@function # -- Begin function parse_value_span_with_glossary_hints
parse_value_span_with_glossary_hints:   # @parse_value_span_with_glossary_hints
	.functype	parse_value_span_with_glossary_hints (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32
# %bb.0:
	i32.const	0
	local.set	8
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label1085
# %bb.1:
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	223
	i32.and 
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label1086
# %bb.2:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	local.get	4
	local.get	5
	local.get	6
	local.get	7
	call	parse_composite_span_impl
	return
.LBB47_3:
	end_block                               # label1086:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	call	parse_value_span
	local.set	8
.LBB47_4:
	end_block                               # label1085:
	local.get	8
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.next_format3_field,"",@
	.type	next_format3_field,@function    # -- Begin function next_format3_field
next_format3_field:                     # @next_format3_field
	.functype	next_format3_field (i32, i32, i32) -> (i32)
	.local  	i32, i32, i32
# %bb.0:
	block   	
	local.get	2
	i32.load	0
	local.tee	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label1087
# %bb.1:
.LBB48_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label1088:
	local.get	0
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label1087
# %bb.3:                                #   in Loop: Header=BB48_2 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label1087
# %bb.4:                                #   in Loop: Header=BB48_2 Depth=1
	local.get	1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	i32.ne  
	br_if   	0                               # 0: up to label1088
# %bb.5:
	end_loop
	i32.const	0
	return
.LBB48_6:
	end_block                               # label1087:
	i32.const	0
	local.set	5
	block   	
	local.get	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label1089
# %bb.7:
	local.get	0
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	0                               # 0: down to label1089
# %bb.8:
	block   	
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label1090
# %bb.9:
.LBB48_10:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label1091:
	local.get	0
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label1090
# %bb.11:                               #   in Loop: Header=BB48_10 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label1090
# %bb.12:                               #   in Loop: Header=BB48_10 Depth=1
	local.get	1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	i32.ne  
	br_if   	0                               # 0: up to label1091
	br      	2                               # 2: down to label1089
.LBB48_13:
	end_loop
	end_block                               # label1090:
	local.get	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label1089
# %bb.14:
	local.get	2
	local.get	3
	i32.store	0
	i32.const	1
	local.set	5
.LBB48_15:
	end_block                               # label1089:
	local.get	5
                                        # fallthrough-return
	end_function
                                        # -- End function
	.type	heap_ptr,@object                # @heap_ptr
	.section	.bss.heap_ptr,"",@
	.p2align	2, 0x0
heap_ptr:
	.int32	0                               # 0x0
	.size	heap_ptr, 4

	.type	last_parse_capacity,@object     # @last_parse_capacity
	.section	.bss.last_parse_capacity,"",@
	.p2align	2, 0x0
last_parse_capacity:
	.int32	0                               # 0x0
	.size	last_parse_capacity, 4

	.type	last_content_capacity,@object   # @last_content_capacity
	.section	.bss.last_content_capacity,"",@
	.p2align	2, 0x0
last_content_capacity:
	.int32	0                               # 0x0
	.size	last_content_capacity, 4

	.type	crc32_table_initialized,@object # @crc32_table_initialized
	.section	.bss.crc32_table_initialized,"",@
	.p2align	2, 0x0
crc32_table_initialized:
	.int8	0                               # 0x0
	.size	crc32_table_initialized, 1

	.type	crc32_table,@object             # @crc32_table
	.section	.bss.crc32_table,"",@
	.p2align	4, 0x0
crc32_table:
	.skip	16384
	.size	crc32_table, 16384

	.type	crc32_braid_initialized,@object # @crc32_braid_initialized
	.section	.bss.crc32_braid_initialized,"",@
	.p2align	2, 0x0
crc32_braid_initialized:
	.int8	0                               # 0x0
	.size	crc32_braid_initialized, 1

	.type	crc32_braid_table,@object       # @crc32_braid_table
	.section	.bss.crc32_braid_table,"",@
	.p2align	4, 0x0
crc32_braid_table:
	.skip	8192
	.size	crc32_braid_table, 8192

	.type	.L.str,@object                  # @.str
	.section	.rodata..L.str,"S",@
.L.str:
	.asciz	"content"
	.size	.L.str, 8

	.type	.L.str.1,@object                # @.str.1
	.section	.rodata..L.str.1,"S",@
.L.str.1:
	.asciz	"path"
	.size	.L.str.1, 5

	.type	.L.str.2,@object                # @.str.2
	.section	.rodata..L.str.2,"S",@
.L.str.2:
	.asciz	"type"
	.size	.L.str.2, 5

	.type	.L.str.3,@object                # @.str.3
	.section	.rodata..L.str.3,"S",@
.L.str.3:
	.asciz	"tag"
	.size	.L.str.3, 4

	.type	.L.str.4,@object                # @.str.4
	.section	.rodata..L.str.4,"S",@
.L.str.4:
	.asciz	"image"
	.size	.L.str.4, 6

	.type	.L.str.5,@object                # @.str.5
	.section	.rodata..L.str.5,"S",@
.L.str.5:
	.asciz	"structured-content"
	.size	.L.str.5, 19

	.type	.L.str.6,@object                # @.str.6
	.section	.rodata..L.str.6,"S",@
.L.str.6:
	.asciz	"img"
	.size	.L.str.6, 4

	.type	.L.str.10,@object               # @.str.10
	.section	.rodata..L.str.10,"S",@
.L.str.10:
	.asciz	"text"
	.size	.L.str.10, 5

	.type	encode_term_content_row.PREFIX_RULES,@object # @encode_term_content_row.PREFIX_RULES
	.section	.rodata.encode_term_content_row.PREFIX_RULES,"S",@
encode_term_content_row.PREFIX_RULES:
	.asciz	"{\"rules\":"
	.size	encode_term_content_row.PREFIX_RULES, 10

	.type	encode_term_content_row.PREFIX_DEFINITION_TAGS,@object # @encode_term_content_row.PREFIX_DEFINITION_TAGS
	.section	.rodata.encode_term_content_row.PREFIX_DEFINITION_TAGS,"S",@
	.p2align	4, 0x0
encode_term_content_row.PREFIX_DEFINITION_TAGS:
	.asciz	",\"definitionTags\":"
	.size	encode_term_content_row.PREFIX_DEFINITION_TAGS, 19

	.type	encode_term_content_row.PREFIX_TERM_TAGS,@object # @encode_term_content_row.PREFIX_TERM_TAGS
	.section	.rodata.encode_term_content_row.PREFIX_TERM_TAGS,"S",@
encode_term_content_row.PREFIX_TERM_TAGS:
	.asciz	",\"termTags\":"
	.size	encode_term_content_row.PREFIX_TERM_TAGS, 13

	.type	encode_term_content_row.PREFIX_GLOSSARY,@object # @encode_term_content_row.PREFIX_GLOSSARY
	.section	.rodata.encode_term_content_row.PREFIX_GLOSSARY,"S",@
encode_term_content_row.PREFIX_GLOSSARY:
	.asciz	",\"glossary\":"
	.size	encode_term_content_row.PREFIX_GLOSSARY, 13

	.ident	"Ubuntu clang version 21.1.8 (6ubuntu1)"
	.size	__heap_base, 1
	.section	.custom_section.producers,"",@
	.int8	1
	.int8	12
	.ascii	"processed-by"
	.int8	1
	.int8	12
	.ascii	"Ubuntu clang"
	.int8	17
	.ascii	"21.1.8 (6ubuntu1)"
	.section	.rodata.encode_term_content_row.PREFIX_GLOSSARY,"S",@
	.section	.custom_section.target_features,"",@
	.int8	10
	.int8	43
	.int8	7
	.ascii	"atomics"
	.int8	43
	.int8	11
	.ascii	"bulk-memory"
	.int8	43
	.int8	15
	.ascii	"bulk-memory-opt"
	.int8	43
	.int8	22
	.ascii	"call-indirect-overlong"
	.int8	43
	.int8	10
	.ascii	"multivalue"
	.int8	43
	.int8	15
	.ascii	"mutable-globals"
	.int8	43
	.int8	19
	.ascii	"nontrapping-fptoint"
	.int8	43
	.int8	15
	.ascii	"reference-types"
	.int8	43
	.int8	8
	.ascii	"sign-ext"
	.int8	43
	.int8	7
	.ascii	"simd128"
	.section	.rodata.encode_term_content_row.PREFIX_GLOSSARY,"S",@
