from pathlib import Path
import json
import sys

ROOT = Path(__file__).parent


def unsigned_leb(bytes, position):
    result = shift = 0
    while True:
        value = bytes[position]
        position += 1
        result += (value & 127) << shift
        if value < 128:
            return result, position
        shift += 7


def string(bytes, position):
    length, position = unsigned_leb(bytes, position)
    return bytes[position:position + length].decode(), position + length


def sections(bytes):
    position = 8
    standard = {}
    custom = {}
    while position < len(bytes):
        id = bytes[position]
        length, position = unsigned_leb(bytes, position + 1)
        value = bytes[position:position + length]
        position += length
        if id:
            standard[id] = value
        else:
            name, offset = string(value, 0)
            custom[name] = value[offset:]
    return standard, custom


def functions(bytes):
    standard, custom = sections(bytes)
    names = {}
    position = 0
    named = custom['name']
    while position < len(named):
        id = named[position]
        length, position = unsigned_leb(named, position + 1)
        end = position + length
        if id == 1:
            count, position = unsigned_leb(named, position)
            for _ in range(count):
                index, position = unsigned_leb(named, position)
                name, position = string(named, position)
                names[index] = name
        position = end
    # These freestanding parser modules import no functions (memory only).
    code = standard[10]
    count, position = unsigned_leb(code, 0)
    result = {}
    for index in range(count):
        length, position = unsigned_leb(code, position)
        result[names[index]] = code[position:position + length]
        position += length
    return standard, result


baseline, baseline_functions = functions((ROOT / 'term-bank-parser-named.wasm').read_bytes())
candidate_file = ROOT / sys.argv[1]
candidate, candidate_functions = functions(candidate_file.read_bytes())
differences = []
for name in baseline_functions.keys() | candidate_functions.keys():
    old = baseline_functions.get(name, b'')
    new = candidate_functions.get(name, b'')
    if old != new:
        differences.append({'name': name, 'baselineBytes': len(old), 'diagnosticBytes': len(new)})
result = {
    'baselineCodeBytes': len(baseline[10]),
    'diagnosticCodeBytes': len(candidate[10]),
    'codeIdentical': baseline[10] == candidate[10],
    'changedFunctions': differences,
}
candidate_file.with_suffix('.comparison.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
