import collections
import hashlib
import json
import pathlib

root = pathlib.Path('/workspace/scratch/9bb32f82fa3b/profiling')
artifact_data = {
    'jmdict': (15245601099, 'bf7a1d371cddca326f47b204df157afc4b6e8979adcb4a3c4d2dbb8234219621'),
    'jitendex': (15245163622, '218f93b5a599514a34884656e9a75f817349f1e1990581371d09fec0d61bad17'),
    'vndb': (15245103878, 'bb62a3f7516a59d27eb76a36dd87282845bbdd0d6aa3e9191ca308cfc4c9c760'),
}
results = {'run': 46100901761, 'sourceSha': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2', 'scope': 'One ordinary full import plus a separate diagnostic trace per dictionary, on separate hosted runners. This is bottleneck evidence, not an optimization comparison. Internal timers overlap; trace sampled attribution includes blocking waits and must not be summed into complete-import time.', 'dictionaries': {}}
for dictionary, (artifact_id, artifact_sha) in artifact_data.items():
    archive = root / f'baseline-9bb32-{dictionary}.zip'
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == artifact_sha
    directory = root / f'hosted-baseline-{dictionary}'
    ordinary = json.loads((directory / 'ordinary/summary.json').read_text())
    traced = json.loads((directory / 'trace/summary.json').read_text())
    raw_ordinary = json.loads((directory / 'ordinary/run-1.json').read_text())
    assert raw_ordinary['status'] == 'success'
    assert ordinary['gitSha'] == traced['gitSha'] == results['sourceSha']
    assert ordinary['source']['dirty'] is False and traced['source']['dirty'] is False
    assert ordinary['runs'][0]['packageSha256'] == traced['runs'][0]['packageSha256']
    run = ordinary['runs'][0]
    phases = run['importDebug']['importerPhaseTimings']
    term_phases = [x for x in phases if x['phase'].startswith('term-file-fast-path:')]
    events = json.loads((directory / 'trace/run-1.trace.json').read_text())['traceEvents']
    nodes = {}
    chunks = []
    for event in events:
        data = event.get('args', {}).get('data', {})
        profile = data.get('cpuProfile')
        key = (event.get('pid'), event.get('tid'), str(event.get('id2', event.get('id'))))
        if profile:
            for node in profile.get('nodes', []):
                nodes[(key, node['id'])] = node
            chunks.append((key, profile.get('samples', []), data.get('timeDeltas', [])))
    times = collections.Counter()
    counts = collections.Counter()
    for key, samples, deltas in chunks:
        for index, node_id in enumerate(samples):
            frame = nodes.get((key, node_id), {}).get('callFrame', {})
            function = (frame.get('functionName'), frame.get('url', ''), frame.get('lineNumber'))
            counts[function] += 1
            if index < len(deltas):
                times[function] += deltas[index]
    hotspots = [{'sampledMs': round(value / 1000, 3), 'samples': counts[key], 'function': key[0], 'source': key[1], 'line': key[2]} for key, value in times.most_common()]
    (directory / 'hotspots.json').write_text(json.dumps(hotspots, indent=2) + '\n')
    metrics = {name: round(sum(float(p['details'].get(name, 0) or 0) for p in term_phases), 3) for name in ['rows', 'chunkCount', 'importerChunkSinkMs', 'sourceArchiveReadMs', 'parserParseBankMs', 'parserSourceInflateMs', 'parserSourceCrcMs', 'parserResultCopyMs', 'parserOrderedSinkWaitMs', 'parserBorrowedContentResultCount', 'parserLookupIndexPrepareMs', 'parserParallelWorkerWallMs', 'parserParallelPeakQueuedOwnedContentBytes', 'parserParallelOwnedContentBytes', 'bulkAddTermsMs', 'contentCompressMs', 'dedupScanMs', 'dedupCanonicalScanMs', 'dedupExactCompareMs', 'contentMetadataPublishMs', 'contentMetadataIndexPublishMs', 'termRecordEncodeMs', 'termRecordFieldEncodeMs', 'termRecordWriteMs', 'termRecordValidationMs']}
    result = {
        'artifactId': artifact_id, 'artifactSha256': artifact_sha,
        'hostEnvironment': ordinary['hostEnvironment'], 'browserVersion': ordinary['browserVersion'], 'packageSha256': run['packageSha256'],
        'ordinaryImportMs': run['totalImportMs'], 'ordinaryWorkerMs': run['workerImportMs'], 'traceImportMs': traced['runs'][0]['totalImportMs'],
        'phases': [{'phase': p['phase'], 'elapsedMs': p['elapsedMs']} for p in phases], 'metrics': metrics,
        'finalization': next((p['details'] for p in phases if p['phase'] == 'bulk-finalization'), None),
        'workerPolicies': [{'workers': p['details'].get('parserParallelWorkerCount'), 'groupsPerWorker': p['details'].get('parserParallelPipelineGroupsPerWorker'), 'groups': p['details'].get('parserParallelGroupCount'), 'effectiveExperiments': p['details'].get('parserExperiments')} for p in term_phases],
        'hotspots': hotspots[:65],
        'databaseHotspots': [x for x in hotspots if 'dictionary-database.js' in x['source']],
        'recordHotspots': [x for x in hotspots if 'term-record-opfs-store.js' in x['source']],
    }
    results['dictionaries'][dictionary] = result
    print(dictionary, json.dumps({key: result[key] for key in ['ordinaryImportMs', 'ordinaryWorkerMs', 'phases', 'metrics']}))
(root / 'hosted-baseline-summary.json').write_text(json.dumps(results, indent=2) + '\n')
