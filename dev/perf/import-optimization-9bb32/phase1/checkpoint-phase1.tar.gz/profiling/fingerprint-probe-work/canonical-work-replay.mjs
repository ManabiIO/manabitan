import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {open, readFile, writeFile} from 'node:fs/promises';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';

const [rootArg, capturePath, outputPath, diagnosticWasmPath] = process.argv.slice(2);
assert(rootArg && capturePath && outputPath && diagnosticWasmPath);
const repetitions = 1;
const root = resolve(rootArg);
const git = (...args) => execFileSync('git', args, {cwd: root, encoding: 'utf8'}).trim();
const gitIdentity = {sha: git('rev-parse', 'HEAD'), tree: git('rev-parse', 'HEAD^{tree}'), status: git('status', '--porcelain'), diffSha256: createHash('sha256').update(execFileSync('git', ['diff', '--binary', 'HEAD', '--'], {cwd: root})).digest('hex')};
const localImport = (path) => import(pathToFileURL(join(root, path)).href);
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const {DictionaryDatabase} = await localImport('ext/js/dictionary/dictionary-database.js');
const {NativeCanonicalScanner} = await localImport('ext/js/dictionary/term-content-canonical-scan.js');
const {RAW_TERM_CONTENT_TOKEN_DICT_NAME} = await localImport('ext/js/dictionary/raw-term-content.js');
const wasmBytes = await readFile(diagnosticWasmPath);
const module = await WebAssembly.compile(wasmBytes);
const captureBytes = await readFile(capturePath);
const capture = JSON.parse(captureBytes);
assert.equal(capture.complete, true);
assert(capture.canonicalCapture?.groups?.length > 0);
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: capture.hardwareConcurrency, deviceMemory: capture.deviceMemory}});
const corpus = capture.canonicalCapture;
const source = {};
for (const path of ['ext/js/dictionary/dictionary-database.js', 'ext/js/dictionary/term-content-canonical-layout.js', 'ext/js/dictionary/term-content-canonical-scan.js', 'ext/js/dictionary/term-content-metadata-arena.js', 'ext/js/dictionary/wasm/term-content-canonical-scan-v1.c', 'ext/lib/term-content-canonical-scan-v1.wasm', 'dev/data/dictionary-wasm/manifest.json']) source[path] = hash(await readFile(join(root, path)));
// A capture is valid only for the same source parser and compressed grouping
// policy. Candidate table-layout changes do not change these dependencies.
for (const [path, expected] of Object.entries(capture.source)) {
    if (/term-bank-|term-lookup-|dictionary-importer\.js/.test(path)) assert.equal(hash(await readFile(join(root, path))), expected, `Capture producer differs: ${path}`);
}
const constructors = {Uint8Array, Uint16Array, Uint32Array, Int32Array, Float64Array};
const headers = [];
const handles = [];
for (const entry of corpus.groups) {
    const bytes = await readFile(join(corpus.directory, entry.header));
    assert.equal(hash(bytes), entry.headerSha256);
    const header = JSON.parse(bytes);
    headers.push(header);
    handles.push(await open(join(corpus.directory, header.binary), 'r'));
}
const STRIDE = 2 ** 32;
async function loadChunk(index) {
    const header = headers[index];
    const bytes = await readFile(join(corpus.directory, header.binary));
    assert.equal(bytes.byteLength, header.byteLength);
    const values = {};
    for (const [name, column] of Object.entries(header.columns)) {
        const view = bytes.subarray(column.position, column.position + column.byteLength);
        assert.equal(hash(view), column.sha256, `Corpus column differs: ${index}/${name}`);
        const ctor = constructors[column.type];
        assert(ctor);
        assert.equal(view.byteOffset % ctor.BYTES_PER_ELEMENT, 0);
        values[name] = new ctor(view.buffer, view.byteOffset, column.length);
    }
    const revive = (value) => value?.$column ? values[value.$column] : value;
    const chunk = Object.fromEntries(Object.entries(header.chunk).map(([key, value]) => [key, revive(value)]));
    chunk.contentDedupPlan = Object.fromEntries(Object.entries(header.chunk.contentDedupPlan).map(([key, value]) => [key, revive(value)]));
    Object.assign(chunk, {dictionary: capture.fixture.expectedTitle, contentDictNameList: null, uniformContentDictName: RAW_TERM_CONTENT_TOKEN_DICT_NAME, contentBytesList: [], contentHash1List: new Uint32Array(0), contentHash2List: new Uint32Array(0)});
    return chunk;
}
function digestColumn(digest, value) {
    if (ArrayBuffer.isView(value)) digest.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength));
    else digest.update(JSON.stringify(value));
}
const observations = [];
const counterNames = ["calls", "rows", "alreadyResolvedRows", "occupiedProbes", "tagRejects", "fullHashPairMatches", "selectedPublishedMatches", "insertedRows", "pendingRows"];
const counterOffset = 8263840;
const scope = 'UNTIMED logical work accounting only. Uses the existing actual DictionaryDatabase canonical resolver/publication replay and exact production-worker corpus. Instrumented C adds integer counters in unused fixed-prefix space after all production scratch columns; baseline hypothetical tag rejection reads hash1 again, so counters describe logical branch work, not measured machine loads or performance. No elapsed/process timing is retained. Private Buffer-backed input, deterministic raw virtual storage, and metadataValidated:false remain the original replay scope. Compression, OPFS, record encoding, parser concurrency, media and UI are excluded.';
async function save(complete) {
    await writeFile(outputPath, JSON.stringify({complete, scope, diagnosticWasmSha256: hash(wasmBytes), counterNames, node: process.version, gitIdentity, source, runnerSha256: hash(await readFile(new URL(import.meta.url))), captureSha256: hash(captureBytes), fixture: capture.fixture, options: capture.options, hardwareConcurrency: capture.hardwareConcurrency, observations}, null, 2) + '\n');
}
try {
    for (let iteration = 0; iteration < repetitions; ++iteration) {
        globalThis.gc?.();
        const database = new DictionaryDatabase();
        database._nativeCanonicalScanner = new NativeCanonicalScanner({loadModule: async () => module});
        let diskReads = 0;
        let diskReadBytes = 0;
        database._readTermEntryContentBytesDetailed = async (offset, length, name) => {
            assert.equal(name, RAW_TERM_CONTENT_TOKEN_DICT_NAME);
            const index = Math.floor(offset / STRIDE);
            const sourceOffset = offset - index * STRIDE;
            assert(index >= 0 && index < handles.length);
            const column = headers[index].columns.contentBytesBuffer;
            assert(sourceOffset >= 0 && sourceOffset + length <= column.byteLength);
            const bytes = new Uint8Array(length);
            let done = 0;
            while (done < length) {
                const result = await handles[index].read(bytes, done, length - done, column.position + sourceOffset + done);
                assert(result.bytesRead > 0);
                done += result.bytesRead;
            }
            ++diskReads;
            diskReadBytes += length;
            return {status: 'ok', bytes};
        };
        database._readTermEntryContentBytesDetailedBatch = async (requests) => await Promise.all(requests.map(({contentOffset, contentLength, contentDictName}) => database._readTermEntryContentBytesDetailed(contentOffset, contentLength, contentDictName)));
        const digest = createHash('sha256');
        const groups = [];


        for (let index = 0; index < headers.length; ++index) {
            const chunk = await loadChunk(index);
            globalThis.gc?.();

            const result = await database._resolveArtifactTermContentDedup(chunk, true);

            assert.equal(result.nativeScanMetrics.dedupNativeFallbackCount, 0);
            assert.equal(result.nativeScanMetrics.dedupNativeCallCount, 1, "Diagnostic requires exactly one native call per corpus group");
            const counters = new BigUint64Array(database._termContentMetadataArena.memory.buffer, counterOffset, counterNames.length);
            const diagnostic = Object.fromEntries(counterNames.map((name, i) => { const value = Number(counters[i]); assert(Number.isSafeInteger(value)); return [name, value]; }));
            assert.equal(diagnostic.calls, 1);
            diagnostic.baselineHash1Comparisons = diagnostic.occupiedProbes;
            diagnostic.fingerprintHash1Comparisons = diagnostic.occupiedProbes - diagnostic.tagRejects;
            const pendingOffsets = Float64Array.from(result.pendingContentSpans.offsets, (offset) => index * STRIDE + offset);
            const pendingLengths = result.pendingContentSpans.lengths;

            database._publishResolvedArtifactTermContentPlan(result.contentDedupPlan, result.pendingPlanUniqueStart, result.pendingPlanUniqueIndexes, pendingOffsets, pendingLengths, RAW_TERM_CONTENT_TOKEN_DICT_NAME);
            const publicationMetrics = {contentMetadataProjectionMs: 0, dedupRecentSourceCacheMs: 0, dedupRecentSourceCacheBytes: 0, contentMetadataIndexPublishMs: 0};
            database._publishArtifactTermContentMetadata({
                ...result,
                count: chunk.rowCount,
                pendingOffsets, pendingLengths,
                pendingResolvedDictNames: RAW_TERM_CONTENT_TOKEN_DICT_NAME,
                contentUniqueIndexList: chunk.contentUniqueIndexList,
                importMetrics: publicationMetrics,
                metadataValidated: false,
                useResolvedContentReferences: chunk.useResolvedContentReferences,
            });

            assert.equal(database._termEntryContentMetaHashPairPendingCount, 0);
            for (const key of ['pendingContentHash1s', 'pendingContentHash2s', 'pendingPlanUniqueIndexes']) digestColumn(digest, result[key]);
            digestColumn(digest, result.pendingContentSpans.offsets);
            digestColumn(digest, result.pendingContentSpans.lengths);
            digestColumn(digest, result.stagedContentMetadata?.indexes ?? null);
            for (const key of ['resolvedFlags', 'resolvedOffsets', 'resolvedLengths', 'resolvedDictNames', 'resolvedUniformDictName']) digestColumn(digest, result.contentDedupPlan[key] ?? null);
            const observation = {index, rows: chunk.rowCount, uniqueCount: result.contentDedupPlan.uniqueCount, pendingContentCount: result.pendingContentCount, persistedHitCount: result.persistedHitCount, pendingHitCount: result.pendingHitCount, exactFallbackCount: result.exactFallbackCount, recentSourceHitCount: result.recentSourceHitCount, native: result.nativeScanMetrics, diagnostic};
            groups.push(observation);
        }
        for (const key of ['Hash1Table', 'Hash2Table', 'StateTable', 'LengthTable', 'SignaturePresentTable', 'Signature1Table', 'Signature2Table', 'Signature3Table', 'IdTable', 'OffsetTable', 'DictNameIdTable']) {
            digestColumn(digest, database[`_termEntryContentMeta${key}`].subarray(0, database._termEntryContentMetaDenseCount));
        }
        const total = (key) => groups.reduce((sum, group) => sum + (group[key] ?? 0), 0);

        const diagnostic = Object.fromEntries(counterNames.map((name) => [name, groups.reduce((sum, group) => sum + group.diagnostic[name], 0)]));
        const result = {iteration, groups, totals: Object.fromEntries(['rows','uniqueCount','pendingContentCount','persistedHitCount','pendingHitCount','exactFallbackCount','recentSourceHitCount'].map((key) => [key,total(key)])), native: {...database._nativeCanonicalScanner.stats}, diagnostic, semanticSha256: digest.digest('hex'), denseCount: database._termEntryContentMetaDenseCount, publishedCount: database._termEntryContentMetaHashPairCount, pendingCount: database._termEntryContentMetaHashPairPendingCount, arenaBytes: database._termContentMetadataArena.memory.buffer.byteLength, slotCount: database._termEntryContentMetaHashPairTable.length, recentCacheLimitBytes: database._recentTermContentSourceCacheMaxBytes, diskReads, diskReadBytes};
        assert.equal(result.semanticSha256, '54a24db94601f4cec620483442db66268ca385113e468ffbb6272a41e6335db5');
        assert.equal(diagnostic.calls, result.native.calls);
        assert.equal(diagnostic.rows, result.native.rows);
        assert.equal(diagnostic.insertedRows, result.native.inserted);
        assert.equal(diagnostic.pendingRows, result.native.nativePendingRows);
        assert.equal(diagnostic.selectedPublishedMatches, result.native.exactDescriptorRows);
        observations.push(result);
        await save(false);
        process.stdout.write(JSON.stringify({iteration, totals: result.totals, native: result.native, diagnostic, semanticSha256: result.semanticSha256}) + '\n');
    }
    for (const [path, expected] of Object.entries(source)) assert.equal(hash(await readFile(join(root, path))), expected, `Source changed during replay: ${path}`);
    assert.equal(git('rev-parse', 'HEAD'), gitIdentity.sha, 'Source commit changed during replay');
    await save(true);
} finally {
    await Promise.all(handles.map((handle) => handle.close()));
}
