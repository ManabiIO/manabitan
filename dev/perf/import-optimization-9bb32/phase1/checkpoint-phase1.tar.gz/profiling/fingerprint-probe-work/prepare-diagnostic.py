from pathlib import Path
import hashlib,json,subprocess
here=Path(__file__).resolve().parent
baseline=Path('/workspace/scratch/9bb32f82fa3b/baseline')
candidate=Path('/workspace/scratch/9bb32f82fa3b/slot-fingerprint')
compiler='/tmp/manabitan-native-9bb32/native-toolchain/bin/clang'
linker='/tmp/manabitan-native-9bb32/native-toolchain/bin/wasm-ld'
def replace_once(text,old,new):
 assert text.count(old)==1,(old,text.count(old))
 return text.replace(old,new)
names=['calls','rows','alreadyResolvedRows','occupiedProbes','tagRejects','fullHashPairMatches','selectedPublishedMatches','insertedRows','pendingRows']
identities=[]
for label,root in [('baseline',baseline),('fingerprint',candidate)]:
 source=(root/'ext/js/dictionary/wasm/term-content-canonical-scan-v1.c').read_text()
 original_hash=hashlib.sha256(source.encode()).hexdigest()
 source=replace_once(source,'#define U8(p) ((uint8_t *)(uintptr_t)(p))','#define U8(p) ((uint8_t *)(uintptr_t)(p))\n\n/* UNTImed diagnostic only: unused fixed-prefix tail, outside production columns. */\n#define DIAGNOSTIC_COUNTERS LAYOUT_END\n_Static_assert(DIAGNOSTIC_COUNTERS % 8u == 0u, "diagnostic alignment");\n_Static_assert(DIAGNOSTIC_COUNTERS + 9u * 8u <= PREFIX, "diagnostic counters fit unused prefix");')
 source=replace_once(source,'    const uint32_t n = c[14] - c[13], mask = c[1] - 1;','    volatile uint64_t *d = (volatile uint64_t *)(uintptr_t)DIAGNOSTIC_COUNTERS;\n    for (uint32_t k = 0u; k < 9u; ++k) { d[k] = 0u; }\n    d[0] = 1u;\n    const uint32_t n = c[14] - c[13], mask = c[1] - 1;')
 source=replace_once(source,'    for (uint32_t i = c[15]; i < n; ++i) {','    for (uint32_t i = c[15]; i < n; ++i) {\n        ++d[1];')
 source=replace_once(source,'        if (flags[i] == 1) {','        if (flags[i] == 1) {\n            ++d[2];')
 old='            if (index >= c[10] || ++probes >= c[1]) { return -4; }'
 fingerprint='encoded' if label=='fingerprint' else 'hash1[index]'
 source=replace_once(source,old,old+f'\n            ++d[3];\n            if ((({fingerprint} ^ m[2]) & 0xf0000000u) != 0u) {{ ++d[4]; }}')
 source=replace_once(source,'                pair = 1;','                ++d[5];\n                pair = 1;')
 source=replace_once(source,'                    existing = index;','                    ++d[6];\n                    existing = index;')
 source=replace_once(source,'            staged = index;','            ++d[7];\n            staged = index;')
 source=replace_once(source,'        uint32_t j = h[2]++;','        ++d[8];\n        uint32_t j = h[2]++;')
 source_path=here/f'{label}-canonical-instrumented.c'
 source_path.write_text(source)
 artifact=here/f'{label}-canonical-instrumented.wasm'
 manifest=json.loads((root/'dev/data/dictionary-wasm/manifest.json').read_text())
 target=next(x for x in manifest['targets'] if x['name']=='term-content-canonical-scan-v1.wasm')
 command=[compiler,f'-fuse-ld={linker}',*target['arguments'],'-o',str(artifact),str(source_path)]
 subprocess.run(command,check=True)
 identities.append({'label':label,'root':str(root),'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'originalSourceSha256':original_hash,'diagnosticSourceSha256':hashlib.sha256(source.encode()).hexdigest(),'diagnosticWasmSha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'command':command})
original=Path('/workspace/scratch/9bb32f82fa3b/profiling/canonical-replay.mjs').read_text()
s=original
s=replace_once(s,"import os from 'node:os';\n",'')
s=replace_once(s,"const [rootArg, capturePath, outputPath, repetitionsArg = '1'] = process.argv.slice(2);\nassert(rootArg && capturePath && outputPath);\nconst repetitions = Number(repetitionsArg);\nassert(Number.isSafeInteger(repetitions) && repetitions > 0);","const [rootArg, capturePath, outputPath, diagnosticWasmPath] = process.argv.slice(2);\nassert(rootArg && capturePath && outputPath && diagnosticWasmPath);\nconst repetitions = 1;")
s=replace_once(s,"const wasmBytes = await readFile(join(root, 'ext/lib/term-content-canonical-scan-v1.wasm'));","const wasmBytes = await readFile(diagnosticWasmPath);")
s=replace_once(s,'const observations = [];','const observations = [];\nconst counterNames = '+json.dumps(names)+';\nconst counterOffset = 8263840;')
lines=s.splitlines()
for i,line in enumerate(lines):
 if line.startswith('const scope = '):
  lines[i]="const scope = 'UNTIMED logical work accounting only. Uses the existing actual DictionaryDatabase canonical resolver/publication replay and exact production-worker corpus. Instrumented C adds integer counters in unused fixed-prefix space after all production scratch columns; baseline hypothetical tag rejection reads hash1 again, so counters describe logical branch work, not measured machine loads or performance. No elapsed/process timing is retained. Private Buffer-backed input, deterministic raw virtual storage, and metadataValidated:false remain the original replay scope. Compression, OPFS, record encoding, parser concurrency, media and UI are excluded.';"
 elif line.strip().startswith(('const loadBefore =','const cpuBefore =','const start = performance.now()', 'const resolveMs =', 'const publishStart =', 'const publishMs =','const cpu = process.cpuUsage')):
  lines[i]=''
 elif line.strip().startswith('const observation = '):
  lines[i]="            const observation = {index, rows: chunk.rowCount, uniqueCount: result.contentDedupPlan.uniqueCount, pendingContentCount: result.pendingContentCount, persistedHitCount: result.persistedHitCount, pendingHitCount: result.pendingHitCount, exactFallbackCount: result.exactFallbackCount, recentSourceHitCount: result.recentSourceHitCount, native: result.nativeScanMetrics, diagnostic};"
 elif line.strip().startswith('const result = {iteration, groups, totals:'):
  lines[i]="        const diagnostic = Object.fromEntries(counterNames.map((name) => [name, groups.reduce((sum, group) => sum + group.diagnostic[name], 0)]));\n        const result = {iteration, groups, totals: Object.fromEntries(['rows','uniqueCount','pendingContentCount','persistedHitCount','pendingHitCount','exactFallbackCount','recentSourceHitCount'].map((key) => [key,total(key)])), native: {...database._nativeCanonicalScanner.stats}, diagnostic, semanticSha256: digest.digest('hex'), denseCount: database._termEntryContentMetaDenseCount, publishedCount: database._termEntryContentMetaHashPairCount, pendingCount: database._termEntryContentMetaHashPairPendingCount, arenaBytes: database._termContentMetadataArena.memory.buffer.byteLength, slotCount: database._termEntryContentMetaHashPairTable.length, recentCacheLimitBytes: database._recentTermContentSourceCacheMaxBytes, diskReads, diskReadBytes};\n        assert.equal(result.semanticSha256, '54a24db94601f4cec620483442db66268ca385113e468ffbb6272a41e6335db5');\n        assert.equal(diagnostic.calls, result.native.calls);\n        assert.equal(diagnostic.rows, result.native.rows);\n        assert.equal(diagnostic.insertedRows, result.native.inserted);\n        assert.equal(diagnostic.pendingRows, result.native.nativePendingRows);\n        assert.equal(diagnostic.selectedPublishedMatches, result.native.exactDescriptorRows);"
 elif line.strip().startswith('process.stdout.write(JSON.stringify({iteration, totals:'):
  lines[i]="        process.stdout.write(JSON.stringify({iteration, totals: result.totals, native: result.native, diagnostic, semanticSha256: result.semanticSha256}) + '\\n');"
s='\n'.join(lines)+'\n'
s=replace_once(s,'{complete, scope, node: process.version,','{complete, scope, diagnosticWasmSha256: hash(wasmBytes), counterNames, node: process.version,')
s=replace_once(s,'            assert.equal(result.nativeScanMetrics.dedupNativeFallbackCount, 0);','            assert.equal(result.nativeScanMetrics.dedupNativeFallbackCount, 0);\n            assert.equal(result.nativeScanMetrics.dedupNativeCallCount, 1, "Diagnostic requires exactly one native call per corpus group");\n            const counters = new BigUint64Array(database._termContentMetadataArena.memory.buffer, counterOffset, counterNames.length);\n            const diagnostic = Object.fromEntries(counterNames.map((name, i) => { const value = Number(counters[i]); assert(Number.isSafeInteger(value)); return [name, value]; }));\n            assert.equal(diagnostic.calls, 1);\n            diagnostic.baselineHash1Comparisons = diagnostic.occupiedProbes;\n            diagnostic.fingerprintHash1Comparisons = diagnostic.occupiedProbes - diagnostic.tagRejects;')
assert 'performance.now' not in s
assert 'process.cpuUsage' not in s
(here/'canonical-work-replay.mjs').write_text(s)
(here/'identity.json').write_text(json.dumps({'scope':'Untimed diagnostic only; no production source or artifact is modified.','counterOffset':8263840,'counterNames':names,'originalReplaySha256':hashlib.sha256(original.encode()).hexdigest(),'diagnosticReplaySha256':hashlib.sha256(s.encode()).hexdigest(),'variants':identities},indent=2)+'\n')
print(json.dumps({'directory':str(here),'variants':[{k:v for k,v in x.items() if k not in ['command']} for x in identities]},indent=2))
