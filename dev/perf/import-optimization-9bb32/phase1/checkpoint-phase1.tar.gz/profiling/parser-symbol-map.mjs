import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';

const root = '/workspace/scratch/9bb32f82fa3b/manabitan';
const outputDirectory = '/workspace/scratch/9bb32f82fa3b/profiling/parser-symbol-map';
const compiler = '/tmp/manabitan-native-9bb32/native-toolchain/bin/clang';
const linker = '/tmp/manabitan-native-9bb32/native-toolchain/bin/wasm-ld';
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'dev/data/dictionary-wasm/manifest.json'), 'utf8'));
const target = manifest.targets.find(({name}) => name === 'term-bank-parser.wasm');
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex');
const baseline = fs.readFileSync(path.join(root, 'dev/data/dictionary-wasm', target.name));
if (sha256(baseline) !== target.sha256) throw new Error('Pinned baseline hash mismatch');
fs.mkdirSync(outputDirectory, {recursive: true});
const namedFile = path.join(outputDirectory, 'term-bank-parser-named.wasm');
const args = [`-fuse-ld=${linker}`, ...target.arguments.filter((value) => value !== '-Wl,--strip-all'), '-o', namedFile, ...target.sources.map((source) => path.join(root, source))];
execFileSync(compiler, args, {stdio: 'inherit'});
const named = fs.readFileSync(namedFile);

function reader(bytes, start = 0) {
    let position = start;
    return {
        get position() { return position; },
        u32() {
            let result = 0;
            for (let shift = 0; shift <= 28; shift += 7) {
                const byte = bytes[position++];
                result += (byte & 0x7f) * (2 ** shift);
                if ((byte & 0x80) === 0) return result >>> 0;
            }
            throw new Error('Invalid unsigned LEB');
        },
        string() {
            const length = this.u32();
            const value = bytes.toString('utf8', position, position + length);
            position += length;
            return value;
        },
    };
}

function sections(bytes) {
    const result = [];
    let position = 8;
    while (position < bytes.length) {
        const id = bytes[position++];
        const input = reader(bytes, position);
        const length = input.u32();
        position = input.position;
        const contents = bytes.subarray(position, position + length);
        result.push({id, contents, name: id === 0 ? reader(contents).string() : null});
        position += length;
    }
    if (position !== bytes.length) throw new Error('Invalid section length');
    return result;
}

const baselineSections = sections(baseline);
const namedSections = sections(named);
const code = baselineSections.find(({id}) => id === 10).contents;
const namedCode = namedSections.find(({id}) => id === 10).contents;
if (!code.equals(namedCode)) throw new Error('Named module Code section differs');
const standardIdentity = baselineSections.filter(({id}) => id !== 0).map(({id, contents}) => {
    const counterpart = namedSections.find((section) => section.id === id);
    if (!counterpart || !contents.equals(counterpart.contents)) throw new Error(`Standard section ${id} differs`);
    return {id, bytes: contents.length, sha256: sha256(contents)};
});
const names = new Map();
const nameSection = namedSections.find(({id, name}) => id === 0 && name === 'name');
if (!nameSection) throw new Error('Named module lacks name section');
const nameReader = reader(nameSection.contents);
nameReader.string();
let position = nameReader.position;
while (position < nameSection.contents.length) {
    const subsection = nameSection.contents[position++];
    const header = reader(nameSection.contents, position);
    const length = header.u32();
    const contents = nameSection.contents.subarray(header.position, header.position + length);
    if (subsection === 1) {
        const input = reader(contents);
        const count = input.u32();
        for (let i = 0; i < count; ++i) names.set(input.u32(), input.string());
    }
    position = header.position + length;
}
const hotspots = JSON.parse(fs.readFileSync('/workspace/scratch/9bb32f82fa3b/profiling/hosted-baseline-jmdict/hotspots.json', 'utf8'));
const mappedHotspots = hotspots.filter(({source}) => source === 'wasm://wasm/0004212e').map((entry) => {
    const index = Number(entry.function.match(/\[(\d+)\]/)?.[1]);
    return {...entry, index, name: names.get(index) ?? null};
});
const result = {
    baselineCommit: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim(),
    baselineSha256: sha256(baseline),
    namedSha256: sha256(named),
    codeSectionSha256: sha256(code),
    codeSectionBytes: code.length,
    codeSectionIdentical: true,
    standardSectionsIdentical: true,
    standardIdentity,
    compiler: execFileSync(compiler, ['--version'], {encoding: 'utf8'}).trim(),
    linker: execFileSync(linker, ['--version'], {encoding: 'utf8'}).trim(),
    arguments: args,
    functionNames: Object.fromEntries(names),
    mappedHotspots,
};
fs.writeFileSync(path.join(outputDirectory, 'symbol-map.json'), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({baselineCommit: result.baselineCommit, baselineSha256: result.baselineSha256, codeSectionIdentical: true, standardSectionsIdentical: true, codeSectionBytes: code.length, mappedHotspots}, null, 2));
