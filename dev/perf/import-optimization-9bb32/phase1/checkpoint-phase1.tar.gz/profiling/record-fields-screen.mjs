import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';

const root = '/workspace/scratch/9bb32f82fa3b';
const arms = {};
for (const [arm, tree] of [['A', 'baseline'], ['B', 'record-fields']]) {
    const module = await import(pathToFileURL(`${root}/${tree}/ext/js/dictionary/term-record-opfs-store.js`));
    arms[arm] = {module, store: new module.TermRecordOpfsStore(), chunks: []};
}
const hash = (value) => createHash('sha256').update(value).digest('hex');
const captureBytes = await readFile(`${root}/profiling/canonical-capture-jmdict.json`);
const capture = JSON.parse(captureBytes);
const scoreBytes = await readFile(`${root}/profiling/jmdict-scores.bin`);
const scoreList = new Int32Array(scoreBytes.buffer, scoreBytes.byteOffset, scoreBytes.byteLength / 4);
assert.equal(scoreList.length, capture.fixture.termRows);
let rowStart = 0;
let virtualBase = 2 ** 40;
const inputDigests = [];
for (const group of capture.canonicalCapture.groups) {
    const headerBytes = await readFile(`${capture.canonicalCapture.directory}/${group.header}`);
    assert.equal(hash(headerBytes), group.headerSha256);
    const header = JSON.parse(headerBytes);
    const bytes = await readFile(`${capture.canonicalCapture.directory}/${header.binary}`);
    const column = (name) => {
        const c = header.columns[name];
        const v = bytes.subarray(c.position, c.position + c.byteLength);
        assert.equal(hash(v), c.sha256);
        return new Uint32Array(v.buffer, v.byteOffset, c.length);
    };
    const meta = column('contentMetaList');
    const representatives = column('plan.uniqueRowIndexes');
    const unique = Uint32Array.from(column('contentUniqueIndexList'));
    const offsets = new Float64Array(group.uniqueCount);
    const lengths = new Uint32Array(group.uniqueCount);
    for (let i = 0; i < group.uniqueCount; ++i) {
        const m = (header.chunk.contentMetaByUniqueIndex === true ? i : representatives[i]) * 4;
        offsets[i] = virtualBase + meta[m];
        lengths[i] = meta[m + 1];
    }
    const scores = scoreList.slice(rowStart, rowStart + group.rows);
    for (const arm of Object.values(arms)) {
        arm.chunks.push({base: virtualBase, chunk: arm.module.createArtifactTermRecordChunkWithResolvedContent({rowCount: group.rows, scoreList: scores}, unique, offsets, lengths)});
    }
    inputDigests.push({rows: group.rows, references: hash(new Uint8Array(unique.buffer)), lengths: hash(new Uint8Array(lengths.buffer)), scores: hash(new Uint8Array(scores.buffer))});
    rowStart += group.rows;
    virtualBase += group.contentBytes;
}
assert.equal(rowStart, scoreList.length);
const outputDigest = createHash('sha256');
for (let i = 0; i < arms.A.chunks.length; ++i) {
    const results = Object.values(arms).map(({store, chunks}) => store._encodeArtifactRecordFields(chunks[i].chunk, [], [], chunks[i].base));
    assert.deepEqual(results[0], results[1]);
    outputDigest.update(results[0]);
}
let consumed = 0;
function execute(arm) {
    const {store, chunks} = arms[arm];
    const start = performance.now();
    for (const {chunk, base} of chunks) {
        const bytes = store._encodeArtifactRecordFields(chunk, [], [], base);
        consumed += bytes.byteLength + bytes[bytes.length - 1];
    }
    return performance.now() - start;
}
const observations = [];
for (let i = 0; i < 8 + 31; ++i) {
    const row = {index: i, warmup: i < 8};
    for (const arm of i % 2 ? ['B', 'A'] : ['A', 'B']) {
        globalThis.gc?.();
        row[arm] = execute(arm);
    }
    observations.push(row);
}
const median = (values) => values.toSorted((a, b) => a - b)[Math.floor(values.length / 2)];
const timed = observations.filter(({warmup}) => !warmup);
const summary = {
    baselineMs: median(timed.map(({A}) => A)), candidateMs: median(timed.map(({B}) => B)),
    pairedDeltaMs: median(timed.map(({A, B}) => B - A)), pairedDeltaPct: median(timed.map(({A, B}) => (B / A - 1) * 100)),
    wins: timed.filter(({A, B}) => B < A).length,
};
const report = {
    scope: 'JMdict record-field component only. Exact locked scores, current production worker group boundaries, actual per-group unique-content maps and lengths. Virtual monotonic source offsets replace global dedup resolved storage offsets. Full import, global alias persistence, compression, ownership transfer, browser and OPFS are excluded. Warmed in-process pairs are exploratory and cannot establish end-to-end gains.',
    node: process.version, fixture: capture.fixture, captureSha256: hash(captureBytes), scoreSha256: hash(scoreBytes),
    inputDigests, outputDigest: outputDigest.digest('hex'), byteParity: true, summary, observations, consumed,
};
await writeFile(`${root}/profiling/record-fields-screen.json`, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify(summary, null, 2));
