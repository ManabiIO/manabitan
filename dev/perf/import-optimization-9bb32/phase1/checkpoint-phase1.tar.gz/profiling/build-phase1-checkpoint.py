#!/usr/bin/env python3
"""Freeze phase-one evidence without changing source records or product trees."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path("/workspace/scratch/9bb32f82fa3b")
PROF = ROOT / "profiling"
TMP = Path("/tmp/manabitan-profiling-9bb32")
OUT = PROF / "checkpoint-phase1"
BASE = "9e10d3b3fcf66d344ab31bc42c9b522fa5215da2"
FINGERPRINT = "178ee43328141693e88b90b4b518d483c87b2fac"
MINSIZE = "2907ba1bad0958c22fe363f88d7cceb4d4bc604e"
AS_OF = "2026-11-28T04:22:00Z"
files = {}
origins = {}
excluded = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode()


def add(name, value, origin=None):
    if name in files:
        raise ValueError(f"Duplicate checkpoint path: {name}")
    if isinstance(value, Path) and (not value.is_file() or value.is_symlink()):
        raise ValueError(f"Not an owned regular evidence file: {value}")
    files[name] = value
    origins[name] = origin or (str(value) if isinstance(value, Path) else "Generated checkpoint metadata")


def git(tree, *args):
    return subprocess.check_output(["git", *args], cwd=tree)


def frozen_file(tree, commit, source, destination):
    data = git(tree, "show", f"{commit}:{source}")
    add(destination, data, f"ManabiIO/manabitan@{commit}:{source}")


# A deterministic selection of all retained ordinary evidence. Preserve even
# empty failure logs; omit bulk payloads, duplicate renderings and distributions.
for path in sorted(PROF.rglob("*")):
    relative = path.relative_to(PROF)
    if any(part in {"runtime", "__pycache__", "checkpoint-phase1"} or part.endswith(".groups") for part in relative.parts):
        continue
    if not path.is_file() or path.is_symlink():
        continue
    if path.suffix in {".zip", ".gz", ".xz", ".html", ".bin", ".pyc"}:
        excluded.append({"path": str(path), "bytes": path.stat().st_size,
                         "reason": "Bulk corpus/archive, duplicate HTML, or reproducible binary input; original retained outside checkpoint"})
        continue
    add(f"profiling/{relative.as_posix()}", path)

for path in sorted(TMP.iterdir()):
    if path.is_file() and path.name.startswith("composite-minsize-"):
        add(f"compiler-static/{path.name}", path)
for path in sorted((TMP / "no-media-static").rglob("*")):
    if path.is_file():
        add(f"compiler-static/no-media-static/{path.relative_to(TMP / 'no-media-static').as_posix()}", path)

for name in ["manifest.json", "bin/clang", "bin/wasm-ld"]:
    path = Path("/tmp/manabitan-native-9bb32/native-toolchain") / name
    data = path.read_bytes()
    if name.startswith("bin/") and not data.startswith(b"#!"):
        raise ValueError("Refusing to include compiler executable distribution")
    add(f"toolchain-provenance/{name}", path)

baseline = ROOT / "baseline"
frozen_paths = [
    "dev/perf/import-qualification-20261125-a7f7.py",
    "test/perf/dictionaries.lock.json",
    "dev/perf/dictionary-fixtures.js", "dev/perf/prepare-dictionaries.js",
    "dev/perf/import-benchmark.js", "test/chromium/import-flags-ab-benchmark.js",
    "test/fixtures/parser-settlement/worker-node.mjs",
    "dev/bin/build-dictionary-wasm.js", "dev/dictionary-wasm.js",
]
frozen_paths += [path.relative_to(baseline).as_posix()
                 for path in sorted((baseline / "dev/perf/import-memory-20261125-a7f7").rglob("*"))
                 if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"]
for source in frozen_paths:
    frozen_file(baseline, BASE, source, f"frozen/baseline/{source}")

bindings = {"baseline": BASE, "asOfUtc": AS_OF, "candidates": {}}
for name, tree, commit, workflow in [
    ("fingerprint", ROOT / "slot-fingerprint", FINGERPRINT, ".github/workflows/import-slot-fingerprints-9bb32.yml"),
    ("minsize", TMP / "composite-minsize", MINSIZE, ".github/workflows/import-composite-minsize-9bb32.yml"),
]:
    if git(tree, "rev-parse", "HEAD").decode().strip() != commit:
        raise ValueError(f"Frozen {name} worktree moved")
    patch = git(tree, "diff", "--binary", "--no-ext-diff", BASE, commit, "--")
    add(f"frozen/candidates/{name}.patch", patch, f"git diff --binary {BASE} {commit}")
    frozen_file(tree, commit, "dev/data/dictionary-wasm/manifest.json", f"frozen/candidates/{name}-wasm-manifest.json")
    frozen_file(tree, commit, workflow, f"frozen/candidates/{name}-source-qa.yml")
    bindings["candidates"][name] = {
        "commit": commit, "tree": git(tree, "rev-parse", "HEAD^{tree}").decode().strip(),
        "sourcePatchSha256": sha(patch), "worktreeStatus": git(tree, "status", "--porcelain").decode(),
    }
frozen_file(baseline, BASE, "dev/data/dictionary-wasm/manifest.json", "frozen/baseline-wasm-manifest.json")
bindings["hostedPlans"] = {
    "fingerprint": {"commit": "b64b3d0423d758252fce9333ceef6e98431de47b", "run": 46104243724,
                    "repositoryPath": ".github/workflows/import-slot-qualification-9bb32.yml",
                    "retainedPath": "profiling/hosted-plans/fingerprint-qualification.yml"},
    "minsize": {"commit": "0c2a8a75cd0322cc13348b977a7e915b555d5a88", "run": 46104898097,
                "repositoryPath": ".github/workflows/import-composite-minsize-qualification-9bb32.yml",
                "retainedPath": "profiling/hosted-plans/minsize-qualification.yml"},
}
bindings["hostedPlanCopyAuthority"] = "Root verified immutable GitHub source and wrote these copies before checkpoint assembly."
for plan in bindings["hostedPlans"].values():
    plan["sha256"] = sha(files[plan["retainedPath"]].read_bytes())

patch_receipts = []
for name, tree, new_files in [
    ("score-plan", ROOT / "score-plan", ["ext/js/dictionary/term-record-score-plan.js", "test/term-record-score-plan.test.js"]),
    ("record-fields", ROOT / "record-fields", []),
]:
    if git(tree, "rev-parse", "HEAD").decode().strip() != BASE:
        raise ValueError(f"Rejected {name} base moved")
    patch = git(tree, "diff", "--binary", "--no-ext-diff", "HEAD", "--")
    for source in new_files:
        result = subprocess.run(["git", "diff", "--no-index", "--binary", "--", "/dev/null", source],
                                cwd=tree, capture_output=True, check=False)
        if result.returncode != 1 or result.stderr:
            raise ValueError(f"Cannot capture untracked source {source}")
        patch += result.stdout
        add(f"rejected/{name}/newfiles/{source}", tree / source)
    result = subprocess.run(["git", "apply", "--check", "--binary", "-"],
                            cwd=baseline, input=patch, capture_output=True, check=False)
    if result.returncode != 0:
        raise ValueError(f"Rejected patch does not apply: {result.stderr.decode()}")
    add(f"rejected/{name}/candidate.patch", patch, f"{tree}: git diff HEAD plus explicit new source files")
    patch_receipts.append({"name": name, "baseCommit": BASE, "patchSha256": sha(patch),
                           "newFiles": new_files, "gitApplyCheckExitCode": result.returncode,
                           "gitStatus": git(tree, "status", "--porcelain", "--untracked-files=all").decode(),
                           "excludedUntrackedLinks": ["node_modules", "ext/lib"] if name == "score-plan" else ["node_modules"]})
add("rejected/patch-receipts.json", json_bytes(patch_receipts))
add("frozen/bindings.json", json_bytes(bindings))

status = {
    "asOfUtc": AS_OF, "repository": "ManabiIO/manabitan", "baselineCommit": BASE,
    "fullBrowserQualification": "PENDING; no complete browser performance/memory acceptance result exists in this checkpoint",
    "pullRequestsCreatedByThisTask": 0, "publicationAuthorizedByThisCheckpoint": False,
    "fingerprint": {"source": FINGERPRINT, "qualificationRun": 46104243724,
                    "qualificationState": "First Jitendex AB job running; other jobs incomplete as reported by root",
                    "sourceQaRun": 46102827974, "sourceQa": "PASS: 670 unit files, 15145 passed tests, 47 skipped; native/lint/types/build gates passed",
                    "component": "Screening signal only; full import gain and memory still unqualified"},
    "minsize": {"source": MINSIZE, "screenedSource": "483586aee547c1c568aac17e2faf413f71bc0477",
                "qualificationRun": 46104898097, "sourceQaRun": 46104779877, "sourceQa": "PENDING",
                "focusedTests": "380 passed locally; pinned regeneration passed",
                "component": "All 3 JMdict producer pairs faster; first Jitendex pair regressed; next candidate SIGKILL stopped cohort without retry; VNDB parity later verified separately, not timed"},
    "supersededQualification": {"run": 46102936165,
                                "reason": "Prospective package-member gate omitted shipped canonical C source; superseded before any job or timing"},
    "rejectedOrHeld": {
        "score-plan": "Preparation moves roughly 8 ms from serial sink but adds CPU/buffers/complexity; no full-import claim",
        "record-fields": "31 warmed component pairs, 15 wins, paired median +0.211895 ms; no benefit",
        "restrict": "No hot memory-operation reduction; reject guard/fallback complexity",
        "no-media-specialization": "Static probe perturbed hint-capable kernel and grew Code section; no runtime test",
        "parser-slot-fingerprints": "Only 101098 first-hash comparisons avoidable versus 854041 insertion tag encodes; shelved before runtime changes",
        "finalization-tail": "Dominated by blocking native flush; overlap/flush-policy alternatives already owned or rejected",
    },
    "failedAndSupersededRecords": "Original bytes, empty logs, partial reports, linker errors, interrupted local validation, and invalidated early option-mismatched screens are retained verbatim",
    "reviewsIncludedAfterStatusSnapshot": ["profiling/record-field-proof-review.json; review only, with no new candidate or qualification result"],
    "omissions": ["Full dictionary archives and canonical .groups payloads", "Node/Clang/compiler distributions and dependencies", "Product ZIPs and duplicate rendered HTML"],
}
add("STATUS.json", json_bytes(status))

readme = """# Manabitan import optimization: phase-one evidence

**Full browser qualification is pending. No PR has been created for these experiments.**
This checkpoint records the state reported at 2026-11-28 04:22 UTC. It is diagnostic
evidence, not acceptance of either candidate. Later hosted results must be retained
as a separate update; do not rewrite this checkpoint's raw observations.

## Frozen identities and current status

- Baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
- Canonical slot fingerprints: `178ee43328141693e88b90b4b518d483c87b2fac`.
  Source QA run 46102827974 passed; full browser run 46104243724 remains incomplete.
- Composite minsize: `2907ba1bad0958c22fe363f88d7cceb4d4bc604e`.
  Runtime bytes equal screened 483586ae; the extra commit is a source-QA workflow.
  Local 380-test/native checks passed. Source QA 46104779877 and browser 46104898097
  remain pending at this checkpoint.
- Frozen browser workflow copies and exact commit/run bindings are in
  `profiling/hosted-plans/` and `frozen/bindings.json`. The older fingerprint run
  46102936165 was superseded prospectively for a package-member gate correction;
  its original workflow and the correction receipt are retained too.

## What is retained

`profiling/` contains ordinary and traced hosted baseline JSON, all raw component
screens and their schedules/status, failed or partial attempts, replay/analysis
scripts, source-QA logs, package comparisons, native symbol/assembly receipts,
canonical fingerprint operation counts and production assembly proof, parser-slot
counter attempts and the compatibility audit, and finalization attribution. A
small subsequent record-field-proof review is included without changing the
04:22 qualification-status snapshot.
`compiler-static/` adds minsize IR/validation receipts and both no-media static
probes. Small generated diagnostic WASMs are retained; they are not release
packages. `toolchain-provenance/` contains the compiler manifest and relocation
wrapper scripts, without the compiler distribution.

`rejected/` contains complete unapplied score-plan and record-fields patches.
The score-plan patch includes both new files, also retained separately. Each patch
passed `git apply --check` against the frozen baseline; nothing was applied.
`frozen/` retains candidate patches, native manifests, source-QA workflows, locked
dictionary manifest, and baseline qualification/memory/receipt tooling.

The original reports are not cleaned or normalized. In particular:

- `exploratory-observation-status.json` invalidates early mismatched-option screens.
- `composite-minsize-screen-1/cohort-status.json` records the SIGKILL stop. The empty
  failed observation log is retained and no missing result JSON is fabricated.
- Separate VNDB parity does not resume or replace that stopped timing cohort.
- Parser-slot compilation attempt 1 and attempt 2 failed; their logs/identities stay.
- Local interrupted unit/type/build attempts remain alongside later hosted QA.

## Integrity and deterministic packaging

Run `python3 verify-phase1-checkpoint.py checkpoint-phase1.tar.gz` beside this file.
`INVENTORY.json` binds every archived file except itself by SHA256 and byte count,
and records its source path or commit. The archive also contains the inventory.
External `SHA256SUMS` binds the archive, inventory, status, verifier, and packaging
receipt. Tar members are sorted regular files with mode 0644, UID/GID 0 and mtime 0;
gzip uses an empty filename, mtime 0 and level 9. A verified second repack must have
the identical archive SHA256. `--repack PATH` performs that check without importing
a dictionary. Packaging changes metadata only, never retained file contents.

## Reproduction boundaries

Use isolated checkouts at the commits above and the locked archives from
`test/perf/dictionaries.lock.json`. Hosted qualification uses Node 22.22.0; the
retained local component screens use bundled Node 24.20.0. Reproduce each plan with
its recorded runtime identity rather than treating those versions as equivalent.
Install project dependencies and build
generated libraries using the repository's pinned scripts. Native regeneration
uses Clang/LLD 21.1.8 and each retained manifest's unchanged arguments:
`npm run build:dictionary-wasm -- --check`. Source-QA workflow files specify the
complete gates; hosted qualification workflows specify topology, run order,
package-member gates, baseline controls and memory/semantic qualification.

The raw canonical corpus and archive payloads are omitted for size. Their manifests
and archive receipt are retained. Regenerate a capture with the retained runner:
`node pipeline-replay.mjs BASELINE_TREE jmdict NEW_CAPTURE_JSON 1 '{}' 4 capture`.
Use jitendex/vndb for the other corpora. This writes a new `.groups` directory;
verify fixture/source and group-column identities before reusing a capture.
`canonical-replay.mjs TREE CAPTURE_JSON OUTPUT_JSON REPETITIONS` replays the
canonical component. The pipeline runner's `verify` mode hashes complete parser
outputs separately; `timing` mode is a producer component, never a full import.
Hosted stored-lookup checks sample persisted lookups and verify referenced media
in the prescribed qualification slots. Complete component digests do not establish
exhaustive persisted-row equality.
Follow the original plans' failure policy and do not fill missing old observations.

The omitted `jmdict-scores.bin` is the little-endian Int32 score vector from field 4
of locked JMdict term banks in numeric bank order (528299 rows). Its required SHA256
is 8402c2d8fb9865b294b6ce20f2e704af067b77f57ad15ca144ac3b14688315eb.
Score/record component scripts also declare their synthetic/virtual reference
limitations. Some diagnostic scripts intentionally retain absolute workspace
paths; recreate that layout or adapt a separate copy and record its new hash.
Never edit these archived originals to make a rerun appear identical.

No product behavior, dictionary, worker count, threshold, or benchmark schedule was
changed while assembling this checkpoint. Original files and worktrees remain.
"""
add("README.md", readme.encode())
verifier_path = PROF / "verify-phase1-checkpoint.py"
add("verify-phase1-checkpoint.py", verifier_path)
add("EXCLUSIONS.json", json_bytes({"excludedFiles": excluded, "excludedDirectories": [
    str(PROF / "runtime"), str(PROF / "canonical-capture-jmdict.json.groups"),
    "node_modules and generated-library dependency trees", "compiler executable/library distributions",
], "smallDiagnosticWasmPolicy": "Retained explicitly at root's request; only distributions and bulk payloads omitted."}))

inventory = {"format": 1, "asOfUtc": AS_OF, "selfExcluded": "INVENTORY.json is bound by outer SHA256SUMS and archive digest",
             "files": []}
for name, value in sorted(files.items()):
    data = value.read_bytes() if isinstance(value, Path) else value
    inventory["files"].append({"path": name, "bytes": len(data), "sha256": sha(data), "origin": origins[name]})
files["INVENTORY.json"] = json_bytes(inventory)
OUT.mkdir(exist_ok=True)
for name in ["README.md", "STATUS.json", "INVENTORY.json", "verify-phase1-checkpoint.py"]:
    value = files[name]
    (OUT / name).write_bytes(value.read_bytes() if isinstance(value, Path) else value)

spec = importlib.util.spec_from_file_location("checkpoint_verifier", verifier_path)
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)
archive_path = OUT / "checkpoint-phase1.tar.gz"
with archive_path.open("wb") as output:
    verifier.write_archive(files, output)
repack_path = OUT / "checkpoint-repack.tmp.tar.gz"
receipt = verifier.verify(archive_path, repack_path)
repack_path.unlink()
receipt.update({"asOfUtc": AS_OF, "deterministic": True, "compressedUnder5MiB": receipt["archiveBytes"] < 5 * 1024 * 1024,
                "originalsPreserved": True, "worktreesRemoved": False, "published": False,
                "pythonVersion": sys.version, "patchChecks": patch_receipts})
(OUT / "PACKAGING.json").write_bytes(json_bytes(receipt))
checksums = "".join(f"{sha(path.read_bytes())}  {path.name}\n" for path in sorted(OUT.iterdir())
                    if path.is_file() and path.name != "SHA256SUMS")
(OUT / "SHA256SUMS").write_text(checksums)
print(json.dumps({"directory": str(OUT), "members": receipt["verifiedMembers"],
                  "rawBytes": receipt["rawBytes"], "archiveBytes": receipt["archiveBytes"],
                  "archiveSha256": receipt["archiveSha256"], "deterministic": True,
                  "under5MiB": receipt["compressedUnder5MiB"]}, indent=2))
