import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';

const root = '/workspace/scratch/9bb32f82fa3b';
const baseline = await import(pathToFileURL(`${root}/manabitan/ext/js/dictionary/term-record-opfs-store.js`));
const candidate = await import(pathToFileURL(`${root}/score-plan/ext/js/dictionary/term-record-opfs-store.js`));
const {prepareTermRecordScorePlan} = await import(pathToFileURL(`${root}/score-plan/ext/js/dictionary/term-record-score-plan.js`));
const scoreBytes = await readFile(`${root}/profiling/jmdict-scores.bin`);
const allScores = new Int32Array(scoreBytes.buffer, scoreBytes.byteOffset, scoreBytes.byteLength / 4);
const production = JSON.parse(await readFile(`${root}/profiling/pipeline-jmdict.json`, 'utf8')).observations[0].chunks;
const fixtures = [];
let start = 0;
for (const group of production) {
    for (const range of group.preparedIndexes) {
        const [offset, count] = range.split(':').map(Number);
        const scores = allScores.slice(start + offset, start + offset + count);
        const unique = Uint32Array.from({length: count}, (_, i) => i);
        const offsets = Float64Array.from({length: count}, (_, i) => 2 ** 40 + i * 17);
        const lengths = new Uint32Array(count).fill(17);
        const a = baseline.createArtifactTermRecordChunkWithResolvedContent({rowCount: count, scoreList: scores}, unique, offsets, lengths);
        const b = candidate.createArtifactTermRecordChunkWithResolvedContent({rowCount: count, scoreList: scores}, unique, offsets, lengths);
        const plan = prepareTermRecordScorePlan(scores, 0, count);
        assert(plan);
        fixtures.push({a, b, plan});
    }
    start += group.rows;
}
assert.equal(start, allScores.length);
const aStore = new baseline.TermRecordOpfsStore();
const bStore = new candidate.TermRecordOpfsStore();
for (const {a, b, plan} of fixtures) {
    assert.deepEqual(aStore._encodeArtifactRecordFields(a, [], [], 2 ** 40), bStore._encodeArtifactRecordFields(b, [], [], 2 ** 40, plan));
}
let bytes = 0;
function execute(mode) {
    const started = performance.now();
    for (const {a, b, plan} of fixtures) {
        if (mode === 'prepare') {
            const result = prepareTermRecordScorePlan(b.scoreList, 0, b.rowCount);
            bytes += result.keys.byteLength + result.scores.byteLength;
        } else {
            const result = mode === 'baseline' ? aStore._encodeArtifactRecordFields(a, [], [], 2 ** 40) : bStore._encodeArtifactRecordFields(b, [], [], 2 ** 40, plan);
            bytes += result.byteLength;
        }
    }
    return performance.now() - started;
}
for (let i = 0; i < 8; ++i) for (const mode of ['baseline', 'candidate', 'prepare']) execute(mode);
const measurements = [];
for (let i = 0; i < 31; ++i) {
    const result = {i};
    for (const mode of (i % 2 ? ['candidate', 'baseline', 'prepare'] : ['prepare', 'baseline', 'candidate'])) {
        globalThis.gc?.();
        result[mode] = execute(mode);
    }
    measurements.push(result);
}
const median = (x) => x.toSorted((a, b) => a - b)[Math.floor(x.length / 2)];
const summary = Object.fromEntries(['baseline', 'candidate', 'prepare'].map((mode) => [mode, median(measurements.map((row) => row[mode]))]));
summary.pairedDeltaMs = median(measurements.map((row) => row.candidate - row.baseline));
summary.pairedDeltaPct = median(measurements.map((row) => (row.candidate / row.baseline - 1) * 100));
summary.fullPreparationPlusSinkMs = median(measurements.map((row) => row.candidate + row.prepare));
const report = {
    scope: 'Score-plan component screen. Exact locked JMdict score values and native planner segment boundaries; synthetic monotonic one-to-one content references of length 17. Not an import benchmark. Candidate keeps source/key/order validation; no persistence, compression, worker overhead or media.',
    node: process.version, rows: allScores.length, groups: production.length, segments: fixtures.length,
    scoreSha256: createHash('sha256').update(scoreBytes).digest('hex'),
    scoreCounts: fixtures.map(({plan}) => plan.scores.length),
    retainedPlanBytes: fixtures.reduce((n, {plan}) => n + plan.keys.byteLength + plan.scores.byteLength, 0),
    byteParity: true, summary, measurements, observableBytes: bytes,
};
await writeFile(`${root}/profiling/score-plan-screen.json`, JSON.stringify(report, null, 2));
console.log(JSON.stringify({rows: report.rows, retainedPlanBytes: report.retainedPlanBytes, scoreCounts: report.scoreCounts, summary}, null, 2));
