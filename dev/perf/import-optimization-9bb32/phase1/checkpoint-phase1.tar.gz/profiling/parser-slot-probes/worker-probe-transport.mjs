// Scratch-only native accounting; production worker is imported unchanged.
import assert from 'node:assert/strict';
import {parentPort, workerData} from 'node:worker_threads';
let diagnosticExports = null;
const instantiate = WebAssembly.instantiate.bind(WebAssembly);
WebAssembly.instantiate = async (...args) => {
    const result = await instantiate(...args);
    const instance = result instanceof WebAssembly.Instance ? result : result.instance;
    if (typeof instance?.exports.diagnostic_slot_probe_count === 'function') diagnosticExports = instance.exports;
    return result;
};
globalThis.self = globalThis;
globalThis.addEventListener = (type, listener) => {
    if (type === 'message') parentPort.on('message', (data) => listener({data}));
};
globalThis.postMessage = (message, transfer) => {
    if (message.type === 'result') {
        assert(diagnosticExports);
        const values = Array.from({length: 29}, (_, index) => {
            const value = Number(diagnosticExports.diagnostic_slot_probe_count(index));
            assert(Number.isSafeInteger(value) && value >= 0);
            return value;
        });
        // Counters reset at entry to each fused call, and are read once only.
        assert.equal(message.profile?.fusedParseAttempts, 1);
        assert.equal(message.profile?.fusedParseFallbacks, 0);
        assert.equal(values[0], 1);
        assert.equal(values[1], message.rowCount);
        message = {...message, __diagnosticSlotProbes: values};
    }
    parentPort.postMessage(message, transfer);
};
await import(workerData.url);
