#!/usr/bin/env python3
"""Create untimed fused-parser probe accounting without touching product source."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROFILE = HERE.parent
ROOT = PROFILE.parent / 'baseline'
SOURCE = ROOT / 'ext/js/dictionary/wasm/term-bank-parser.c'
PIPELINE = PROFILE / 'pipeline-replay.mjs'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def once(text, before, after):
    assert text.count(before) == 1, (before[:100], text.count(before))
    return text.replace(before, after, 1)

names = [
    'calls', 'rows', 'stringQueries', 'stringEqualReadingBypasses',
    'stringAdjacentKeyBypasses', 'stringOccupiedProbes', 'stringNibbleRejects',
    'stringFullHashMatches', 'stringHashAndLengthMatches', 'stringExactMatches',
    'stringInsertions', 'contentQueries', 'contentRecentBypasses',
    'contentOccupiedProbes', 'contentNibbleRejects', 'contentFirstHashMatches',
    'contentFullHashPairMatches', 'contentHashPairAndLengthMatches',
    'contentExactMatches', 'contentInsertions', 'stringTableSlots',
    'contentTableSlots', 'metaCapacity', 'bankCount', 'sourceBytes',
    'encodedContentBytes', 'internedStringBytes', 'stringUniqueCount',
    'contentUniqueCount',
]
source = SOURCE.read_text()
source = once(source, 'static uint32_t last_content_capacity = 0u;', '''static uint32_t last_content_capacity = 0u;

/* Scratch-only diagnostic. These counters never influence product decisions.
 * Volatile increments are deliberately untimed and may add redundant reads.
 * The statically allocated array remains outside all bump-allocated buffers. */
static volatile uint64_t diagnostic_slot_probes[29];
__attribute__((visibility("default")))
uint64_t diagnostic_slot_probe_count(uint32_t index) {
    return index < 29u ? diagnostic_slot_probes[index] : 0u;
}
''')
begin = source.index('int32_t parse_and_encode_term_bank_token_binary_dedup(')
end = source.index('/* Segment compaction consumes only parser-owned columns.', begin)
prefix, fused, suffix = source[:begin], source[begin:end], source[end:]
fused = once(fused, ') {\n    if (', ''') {
    for (uint32_t diagnostic_i = 0u; diagnostic_i < 29u; ++diagnostic_i) {
        diagnostic_slot_probes[diagnostic_i] = 0u;
    }
    diagnostic_slot_probes[0] = 1u;
    diagnostic_slot_probes[20] = string_hash_table_size;
    diagnostic_slot_probes[21] = hash_table_size;
    diagnostic_slot_probes[22] = metas_capacity;
    diagnostic_slot_probes[23] = bank_count == 0u ? 1u : bank_count;
    diagnostic_slot_probes[24] = json_len;
    if (''')
fused = once(fused, 'if (field == 1u && reading_equals_expression) {', '''if (field == 1u && reading_equals_expression) {
                ++diagnostic_slot_probes[3];''')
fused = once(fused, '                    string_indexes[field] = field == 0u ?', '''                    ++diagnostic_slot_probes[4];
                    string_indexes[field] = field == 0u ?''')
fused = once(fused, '            const uint32_t string_hash = hash_content_xxh32', '''            ++diagnostic_slot_probes[2];
            const uint32_t string_hash = hash_content_xxh32''')
fused = once(fused, '                if (candidate >= string_unique_count) { return -3; }', '''                if (candidate >= string_unique_count) { return -3; }
                ++diagnostic_slot_probes[5];
                if (((string_hashes[candidate] ^ string_hash) & 0xf0000000u) != 0u) {
                    ++diagnostic_slot_probes[6];
                }
                if (string_hashes[candidate] == string_hash) {
                    ++diagnostic_slot_probes[7];
                    if (string_lengths[candidate] == value_length) { ++diagnostic_slot_probes[8]; }
                }''')
fused = once(fused, '                    matched_index = candidate;', '''                    ++diagnostic_slot_probes[9];
                    matched_index = candidate;''')
fused = once(fused, '            string_hash_table[string_slot] = string_unique_count + 1u;', '''            string_hash_table[string_slot] = string_unique_count + 1u;
            ++diagnostic_slot_probes[10];''')
fused = once(fused, '        if (recent_match != 0xffffffffu) {', '''        if (recent_match != 0xffffffffu) {
            ++diagnostic_slot_probes[12];''')
fused = once(fused, '            uint32_t mixed = hash1 ^ (hash2 * 0x9e3779b1u);', '''            ++diagnostic_slot_probes[11];
            uint32_t mixed = hash1 ^ (hash2 * 0x9e3779b1u);''')
fused = once(fused, '                const uint32_t candidate_offset = candidate_row * 4u;', '''                const uint32_t candidate_offset = candidate_row * 4u;
                ++diagnostic_slot_probes[13];
                if (((row_meta[candidate_offset + 2u] ^ hash1) & 0xf0000000u) != 0u) {
                    ++diagnostic_slot_probes[14];
                }
                if (row_meta[candidate_offset + 2u] == hash1) {
                    ++diagnostic_slot_probes[15];
                    if (row_meta[candidate_offset + 3u] == hash2) {
                        ++diagnostic_slot_probes[16];
                        if (row_meta[candidate_offset + 1u] == length) { ++diagnostic_slot_probes[17]; }
                    }
                }''')
fused = once(fused, '                    matched_row = candidate_row;', '''                    ++diagnostic_slot_probes[18];
                    matched_row = candidate_row;''')
fused = once(fused, '                hash_table[slot] = row_count + 1u;', '''                hash_table[slot] = row_count + 1u;
                ++diagnostic_slot_probes[19];''')
fused = once(fused, '    return (int32_t)cursor;', '''    diagnostic_slot_probes[1] = row_count;
    diagnostic_slot_probes[25] = cursor;
    diagnostic_slot_probes[26] = strings_cursor;
    diagnostic_slot_probes[27] = string_unique_count;
    diagnostic_slot_probes[28] = unique_count;
    return (int32_t)cursor;''')
native = HERE / 'term-bank-parser-probe-counts.c'
native.write_text(prefix + fused + suffix)

adapter = HERE / 'worker-probe-transport.mjs'
adapter.write_text('''// Scratch-only native accounting; production worker is imported unchanged.
import assert from 'node:assert/strict';
import {parentPort, workerData} from 'node:worker_threads';
let diagnosticExports = null;
const instantiate = WebAssembly.instantiate.bind(WebAssembly);
WebAssembly.instantiate = async (...args) => {
    const result = await instantiate(...args);
    const instance = result instanceof WebAssembly.Instance ? result : result.instance;
    if (typeof instance?.exports.diagnostic_slot_probe_count === 'function') diagnosticExports = instance.exports;
    return result;
};
globalThis.self = globalThis;
globalThis.addEventListener = (type, listener) => {
    if (type === 'message') parentPort.on('message', (data) => listener({data}));
};
globalThis.postMessage = (message, transfer) => {
    if (message.type === 'result') {
        assert(diagnosticExports);
        const values = Array.from({length: 29}, (_, index) => {
            const value = Number(diagnosticExports.diagnostic_slot_probe_count(index));
            assert(Number.isSafeInteger(value) && value >= 0);
            return value;
        });
        // Counters reset at entry to each fused call, and are read once only.
        assert.equal(message.profile?.fusedParseAttempts, 1);
        assert.equal(message.profile?.fusedParseFallbacks, 0);
        assert.equal(values[0], 1);
        assert.equal(values[1], message.rowCount);
        message = {...message, __diagnosticSlotProbes: values};
    }
    parentPort.postMessage(message, transfer);
};
await import(workerData.url);
''')

runner = PIPELINE.read_text()
runner = once(runner, "import {readFile, writeFile} from 'node:fs/promises';", "import {readFile, writeFile as originalWriteFile} from 'node:fs/promises';")
runner = once(runner, "from './canonical-corpus.mjs';", "from '../canonical-corpus.mjs';")
runner = once(runner, 'const runnerEntryMs = performance.now();', '''const slotProbeGroups = [];
const diagnosticIdentity = JSON.parse(await readFile(new URL('./identity.json', import.meta.url)));
const expectedVerification = JSON.parse(await readFile(new URL('../composite-minsize-screen-1/jmdict-verify-A.json', import.meta.url)));
const counterNames = diagnosticIdentity.counterNames;
const omittedFields = new Set(['startup', 'workers', 'loadBefore', 'loadAfter', 'memory', 'maxRssKiB']);
function omitInstrumentationTimings(value) {
    if (Array.isArray(value)) return value.map(omitInstrumentationTimings);
    if (value !== null && typeof value === 'object') {
        return Object.fromEntries(Object.entries(value).filter(([key]) => !omittedFields.has(key) && !key.endsWith('Ms')).map(([key, item]) => [key, omitInstrumentationTimings(item)]));
    }
    return value;
}
async function writeFile(path, contents) {
    const value = omitInstrumentationTimings(JSON.parse(contents));
    value.scope = 'Untimed instrumented work accounting only. Original raw native slots and all product decisions are unchanged. Count hypothetical high-nibble rejection; do not interpret elapsed times, physical memory loads, cache behavior or whole-import speed. Production source planner, parser workers and output digest are retained. Extra counters are read by the diagnostic transport adapter and excluded from logical parser output.';
    value.instrumentation = diagnosticIdentity;
    value.probeGroups = slotProbeGroups;
    value.probeTotals = Object.fromEntries(counterNames.map((key) => [key, slotProbeGroups.reduce((sum, group) => sum + group.counters[key], 0)]));
    await originalWriteFile(path, JSON.stringify(value, null, 2) + '\\n');
}
const runnerEntryMs = performance.now();''')
runner = once(runner, "const archivePath = join(root, 'builds/e2e-dictionary-cache', fixture.cacheFile);", "const archivePath = join(root, '../manabitan/builds/e2e-dictionary-cache', fixture.cacheFile);")
runner = once(runner, "const wasmBytes = await readFile(join(root, 'ext/lib/term-bank-parser.wasm'));", "const wasmBytes = await readFile(new URL('./term-bank-parser-probe-counts.wasm', import.meta.url));\nassert.equal(hash(wasmBytes), diagnosticIdentity.instrumentedWasmSha256);")
runner = once(runner, "this.worker = new ThreadWorker(pathToFileURL(join(root, 'test/fixtures/parser-settlement/worker-node.mjs')),", "this.worker = new ThreadWorker(new URL('./worker-probe-transport.mjs', import.meta.url),")
runner = once(runner, "        this.worker.on('message', (data) => {", '''        this.worker.on('message', (data) => {
            if (data?.__diagnosticSlotProbes) {
                assert.equal(data.__diagnosticSlotProbes.length, counterNames.length);
                slotProbeGroups.push({worker: this.lifecycle.worker, id: data.id, counters: Object.fromEntries(counterNames.map((name, index) => [name, data.__diagnosticSlotProbes[index]]))});
                delete data.__diagnosticSlotProbes;
            }''')
runner = once(runner, "        process.stderr.write(JSON.stringify({phase, iteration, elapsedMs, processCpuMs: row.processCpuMs, chunks: chunks.length, rows, digest: row.digest}) + '\\n');", "        process.stderr.write(JSON.stringify({scope: 'untimed-native-probe-counts', phase, iteration, chunks: chunks.length, rows, digest: row.digest}) + '\\n');")
runner = once(runner, '    for (const [file, expected] of Object.entries(startIdentity))', '''    assert.equal(mode, 'verify');
    assert.equal(observations.length, 1);
    assert.equal(observations[0].digest, expectedVerification.observations[0].digest);
    assert.deepEqual(observations[0].chunks, expectedVerification.observations[0].chunks);
    assert.deepEqual(startIdentity, expectedVerification.source);
    assert.equal(gitIdentity.sha, expectedVerification.gitIdentity.sha);
    assert.equal(slotProbeGroups.length, 12);
    assert.equal(slotProbeGroups.reduce((sum, group) => sum + group.counters.rows, 0), fixture.termRows);
    for (const [file, expected] of Object.entries(startIdentity))''')
runner_path = HERE / 'parser-probe-replay.mjs'
runner_path.write_text(runner)

manifest = json.loads((ROOT / 'dev/data/dictionary-wasm/manifest.json').read_text())
target = next(x for x in manifest['targets'] if x['name'] == 'term-bank-parser.wasm')
command = ['/tmp/manabitan-native-9bb32/native-toolchain/bin/clang', '-fuse-ld=/tmp/manabitan-native-9bb32/native-toolchain/bin/wasm-ld', *target['arguments'], '-Wl,--export=diagnostic_slot_probe_count', str(native), str(ROOT / target['sources'][1]), '-o', str(HERE / 'term-bank-parser-probe-counts.wasm')]
identity = {
    'scope': 'Scratch-only untimed native operation accounting, no product candidate.',
    'baselineCommit': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2',
    'baselineParserSourceSha256': digest(SOURCE),
    'baselineParserWasmSha256': digest(ROOT / 'ext/lib/term-bank-parser.wasm'),
    'baselineInflateSourceSha256': digest(ROOT / target['sources'][1]),
    'baselineManifestSha256': digest(ROOT / 'dev/data/dictionary-wasm/manifest.json'),
    'originalPipelineSha256': digest(PIPELINE),
    'baselineVerificationSha256': digest(PROFILE / 'composite-minsize-screen-1/jmdict-verify-A.json'),
    'instrumentedSourceSha256': digest(native),
    'instrumentedWasmSha256': None,
    'diagnosticRunnerSha256': digest(runner_path),
    'diagnosticTransportSha256': digest(adapter),
    'prepareScriptSha256': digest(Path(__file__)),
    'counterNames': names,
    'compilerCommand': command,
    'notes': [
        'Original raw index+1 slot words, full hashes, byte equality, insertion order and bounds checks are unchanged.',
        'Counters reset on each fused call and are read once before forwarding its result; each result must have one fused call and no fallback.',
        'Hypothetical tags use high4 bits of the existing full hash; extra diagnostic hash loads are intentional and untimed.',
        'Static volatile counter storage can move heap addresses and changes generated code; full logical output parity is required.',
        'All product JS is loaded unchanged from the frozen baseline; one shared instrumented module is passed to all three native parser workers.',
        'Original locked archive size and SHA checks remain intact despite the explicit cache path override.',
        'No elapsed/cpu/startup/memory timing fields are retained in the diagnostic report.',
    ],
}
(HERE / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps({'prepared': True, 'instrumentedSourceSha256': identity['instrumentedSourceSha256'], 'files': [p.name for p in HERE.iterdir()]}))
