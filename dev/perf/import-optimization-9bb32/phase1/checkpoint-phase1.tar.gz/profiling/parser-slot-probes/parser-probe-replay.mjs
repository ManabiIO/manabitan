import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {createReadStream, openAsBlob} from 'node:fs';
import {readFile, writeFile as originalWriteFile} from 'node:fs/promises';
import os from 'node:os';
import {join, resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
import {Worker as ThreadWorker} from 'node:worker_threads';
import {createCanonicalCorpus} from '../canonical-corpus.mjs';

const slotProbeGroups = [];
const diagnosticIdentity = JSON.parse(await readFile(new URL('./identity.json', import.meta.url)));
const expectedVerification = JSON.parse(await readFile(new URL('../composite-minsize-screen-1/jmdict-verify-A.json', import.meta.url)));
const counterNames = diagnosticIdentity.counterNames;
const omittedFields = new Set(['startup', 'workers', 'loadBefore', 'loadAfter', 'memory', 'maxRssKiB']);
function omitInstrumentationTimings(value) {
    if (Array.isArray(value)) return value.map(omitInstrumentationTimings);
    if (value !== null && typeof value === 'object') {
        return Object.fromEntries(Object.entries(value).filter(([key]) => !omittedFields.has(key) && !key.endsWith('Ms')).map(([key, item]) => [key, omitInstrumentationTimings(item)]));
    }
    return value;
}
async function writeFile(path, contents) {
    const value = omitInstrumentationTimings(JSON.parse(contents));
    value.scope = 'Untimed instrumented work accounting only. Original raw native slots and all product decisions are unchanged. Count hypothetical high-nibble rejection; do not interpret elapsed times, physical memory loads, cache behavior or whole-import speed. Production source planner, parser workers and output digest are retained. Extra counters are read by the diagnostic transport adapter and excluded from logical parser output.';
    value.instrumentation = diagnosticIdentity;
    value.probeGroups = slotProbeGroups;
    value.probeTotals = Object.fromEntries(counterNames.map((key) => [key, slotProbeGroups.reduce((sum, group) => sum + group.counters[key], 0)]));
    await originalWriteFile(path, JSON.stringify(value, null, 2) + '\n');
}
const runnerEntryMs = performance.now();
const [rootArg, dictionary = 'jmdict', outputPath, repeatsArg = '1', flagsJson = '{}', hardwareConcurrencyArg = '4', mode = 'all'] = process.argv.slice(2);
assert(rootArg && outputPath);
const root = resolve(rootArg);
const git = (...args) => execFileSync('git', args, {cwd: root, encoding: 'utf8'}).trim();
const gitIdentity = {sha: git('rev-parse', 'HEAD'), tree: git('rev-parse', 'HEAD^{tree}'), status: git('status', '--porcelain')};
const repeats = Number(repeatsArg);
assert(Number.isSafeInteger(repeats) && repeats > 0);
const localImport = (file) => import(pathToFileURL(join(root, file)).href);
const moduleImportStart = performance.now();
const {BlobReader, Uint8ArrayWriter, ZipReader} = await localImport('node_modules/@zip.js/zip.js/index.js');
const parser = await localImport('ext/js/dictionary/term-bank-wasm-parser.js');
const {RawZipPayloadReader, TermBankSourcePipeline} = await localImport('ext/js/dictionary/term-bank-source-pipeline.js');
const {readDenseZipFileMap} = await localImport('ext/js/dictionary/dense-zip-directory.js');
const {TermRecordOpfsStore, createArtifactTermRecordChunkWithResolvedContent} = await localImport('ext/js/dictionary/term-record-opfs-store.js');
const {DictionaryImporter, isNativeImageProjectionSourceSizeEligible} = await localImport('ext/js/dictionary/dictionary-importer.js');
const {MIN_EXACT_LOOKUP_SOURCE_BYTES} = await localImport('ext/js/dictionary/term-lookup-route.js');
const moduleImportMs = performance.now() - moduleImportStart;
const flags = JSON.parse(flagsJson);
const fixtureVerificationStart = performance.now();
const lockBytes = await readFile(join(root, 'test/perf/dictionaries.lock.json'));
const fixture = JSON.parse(lockBytes).dictionaries[dictionary];
assert(fixture);
const archivePath = join(root, '../manabitan/builds/e2e-dictionary-cache', fixture.cacheFile);
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex');
const archiveHash = createHash('sha256');
for await (const bytes of createReadStream(archivePath)) archiveHash.update(bytes);
assert.equal(archiveHash.digest('hex'), fixture.sha256);
const archive = await openAsBlob(archivePath);
assert.equal(archive.size, fixture.sizeBytes);
const fixtureVerificationMs = performance.now() - fixtureVerificationStart;
const wasmReadStart = performance.now();
const wasmBytes = await readFile(new URL('./term-bank-parser-probe-counts.wasm', import.meta.url));
assert.equal(hash(wasmBytes), diagnosticIdentity.instrumentedWasmSha256);
const wasmReadMs = performance.now() - wasmReadStart;
const wasmCompileStart = performance.now();
const compiledParserModule = await WebAssembly.compile(wasmBytes);
const wasmCompileMs = performance.now() - wasmCompileStart;
parser.setTermBankWasmModule(compiledParserModule);
const terminations = [];
const workerLifecycles = [];
class BrowserWorker extends EventTarget {
    constructor(url) {
        super();
        this.lifecycle = {worker: workerLifecycles.length, createdAtMs: performance.now(), onlineAtMs: null, initializeSentAtMs: null, readyAtMs: null, firstParseSentAtMs: null, terminatedAtMs: null};
        workerLifecycles.push(this.lifecycle);
        this.worker = new ThreadWorker(new URL('./worker-probe-transport.mjs', import.meta.url), {workerData: {url: url.href}});
        this.worker.on('online', () => { this.lifecycle.onlineAtMs = performance.now(); });
        this.worker.on('message', (data) => {
            if (data?.__diagnosticSlotProbes) {
                assert.equal(data.__diagnosticSlotProbes.length, counterNames.length);
                slotProbeGroups.push({worker: this.lifecycle.worker, id: data.id, counters: Object.fromEntries(counterNames.map((name, index) => [name, data.__diagnosticSlotProbes[index]]))});
                delete data.__diagnosticSlotProbes;
            }
            if (data?.type === 'ready') this.lifecycle.readyAtMs = performance.now();
            this.dispatchEvent(new MessageEvent('message', {data}));
        });
        this.worker.on('error', (error) => {
            const event = new Event('error');
            Object.defineProperty(event, 'message', {value: error.message});
            this.dispatchEvent(event);
        });
        this.worker.on('messageerror', () => this.dispatchEvent(new MessageEvent('messageerror')));
    }
    postMessage(data, transfer) {
        if (data?.type === 'initialize') this.lifecycle.initializeSentAtMs = performance.now();
        if (data?.type === 'parse' && this.lifecycle.firstParseSentAtMs === null) this.lifecycle.firstParseSentAtMs = performance.now();
        this.worker.postMessage(data, transfer);
    }
    terminate() { this.lifecycle.terminatedAtMs = performance.now(); terminations.push(this.worker.terminate()); }
}
globalThis.Worker = BrowserWorker;
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: Number(hardwareConcurrencyArg), deviceMemory: 8}});

const catalogStart = performance.now();
let reader = null;
let entries = null;
if (dictionary === 'vndb') {
    const fileMap = await readDenseZipFileMap(archive, async function () { throw new Error('Replay expected the validated compressed source path'); });
    if (fileMap) entries = [...fileMap.keys()].filter((name) => /^term_bank_\d+\.json$/.test(name)).map((name) => fileMap.get(name));
}
if (!entries) {
    reader = new ZipReader(new BlobReader(archive));
    entries = await reader.getEntries();
}
const termFiles = entries.filter(({filename}) => /^term_bank_\d+\.json$/.test(filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)));
const importer = new DictionaryImporter(null);
const rawTermBankSourceBytes = importer._getRawTermBankSourceBytes(termFiles);
assert(Number.isSafeInteger(rawTermBankSourceBytes) && rawTermBankSourceBytes > 0);
const options = {
    ...flags,
    copyContentBytes: false,
    includeContentMetadata: true,
    initialContentBytesPerRow: importer._termBankWasmInitialContentBytesPerRow,
    minimalDecode: importer._wasmCanonicalRowsFastPath,
    reuseExpressionForReadingDecode: importer._wasmReuseExpressionForReadingDecode,
    preallocateChunkRows: importer._wasmPreallocateChunkRows,
    skipTagRuleDecode: fixture.mediaFiles > 0,
    lazyGlossaryDecode: true,
    emitTermByteLists: false,
    computeContentHashes: true,
    emitContentSlab: true,
    emitTokenBinaryContent: true,
    mediaHintFastScan: fixture.mediaFiles > 0,
    projectImagePaths: fixture.mediaFiles > 0 && isNativeImageProjectionSourceSizeEligible(rawTermBankSourceBytes),
    validateGlossaryTypes: true,
    prepareLookupIndexes: true,
    prepareLookupRoute: rawTermBankSourceBytes >= MIN_EXACT_LOOKUP_SOURCE_BYTES,
    maxPendingChunks: 2,
};
const catalogMs = performance.now() - catalogStart;
const observations = [];
const canonicalCapture = mode === 'capture' ? await createCanonicalCorpus(outputPath) : null;
const startIdentity = {};
for (const file of ['ext/js/dictionary/dictionary-importer.js', 'ext/js/dictionary/term-bank-wasm-parser.js', 'ext/js/dictionary/term-bank-wasm-parser-worker.js', 'ext/js/dictionary/term-bank-source-pipeline.js', 'ext/js/dictionary/term-bank-experiments.js', 'ext/js/dictionary/term-record-opfs-store.js', 'ext/js/dictionary/term-record-preinterned-plan.js', 'ext/js/dictionary/term-lookup-index-preparation.js', 'ext/js/dictionary/term-lookup-route.js', 'ext/js/dictionary/wasm/term-bank-parser.c', 'ext/lib/term-bank-parser.wasm', 'dev/data/dictionary-wasm/manifest.json']) {
    startIdentity[file] = hash(await readFile(join(root, file)));
}
function digestView(digest, value) {
    if (value && ArrayBuffer.isView(value)) digest.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength));
}

function digestValue(digest, value) {
    if (typeof value === 'undefined') { digest.update('undefined;'); return; }
    if (value === null) { digest.update('null;'); return; }
    if (ArrayBuffer.isView(value)) {
        digest.update(`view:${value.constructor.name}:${value.byteLength}:`);
        digestView(digest, value);
        return;
    }
    if (value instanceof Map) {
        digest.update(`map:${value.size}:`);
        for (const [key, item] of [...value].sort(([a], [b]) => String(a).localeCompare(String(b)))) { digestValue(digest, key); digestValue(digest, item); }
        return;
    }
    if (Array.isArray(value)) {
        digest.update(`array:${value.length}:`);
        for (const item of value) digestValue(digest, item);
        return;
    }
    if (typeof value === 'object') {
        const keys = Object.keys(value).sort();
        digest.update(`object:${keys.length}:`);
        for (const key of keys) { digestValue(digest, key); digestValue(digest, value[key]); }
        return;
    }
    assert.notEqual(typeof value, 'function', 'Functions are not parser output data');
    digest.update(`${typeof value}:${Object.is(value, -0) ? '-0' : JSON.stringify(value)};`);
}

async function execute(phase, iteration) {
    const workerStartIndex = workerLifecycles.length;
    const rawReader = new RawZipPayloadReader(archive);
    const sourcePipeline = new TermBankSourcePipeline({
        termFiles,
        enabled: true,
        read: async (file) => await file.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}),
        readCompressed: async (file, signal) => await rawReader.read(file, signal, true),
    });
    const profiles = [];
    const chunks = [];
    let rows = 0;
    const digest = createHash('sha256');
    const verify = phase === 'verify' || phase === 'encoder';
    const encoderMeasurements = [];
    let contentBase = 0;
    async function consume(chunk, progress) {
        assert(chunk.contentDedupPlan && chunk.contentMetaList && chunk.contentUniqueIndexList);
        rows += chunk.rowCount;
        chunks.push({rows: chunk.rowCount, contentBytes: chunk.contentBytesLength, contentByUnique: chunk.contentMetaByUniqueIndex === true, preparedIndexes: [...chunk.preparedLookupIndexes.keys()]});
        if (phase === 'capture') {
            assert(canonicalCapture !== null);
            await canonicalCapture.append(chunk, progress);
            globalThis.gc?.();
            return;
        }
        if (!verify) return;
        if (phase === 'verify') {
            digestValue(digest, {
                progress,
                rowCount: chunk.rowCount,
                contentRowStart: chunk.contentRowStart,
                expressionBytesList: chunk.expressionBytesList,
                readingBytesList: chunk.readingBytesList,
                readingEqualsExpressionList: chunk.readingEqualsExpressionList,
                scoreList: chunk.scoreList,
                sequenceList: chunk.sequenceList,
                contentBytesList: chunk.contentBytesList,
                contentHash1List: chunk.contentHash1List,
                contentHash2List: chunk.contentHash2List,
                contentBytes: chunk.contentBytesBuffer.subarray(chunk.contentBytesBaseOffset ?? 0, (chunk.contentBytesBaseOffset ?? 0) + chunk.contentBytesLength),
                contentMetaList: chunk.contentMetaList,
                contentMetaByUniqueIndex: chunk.contentMetaByUniqueIndex,
                contentUniqueIndexList: chunk.contentUniqueIndexList,
                contentDedupPlan: chunk.contentDedupPlan,
                useResolvedContentReferences: chunk.useResolvedContentReferences,
                termRecordPreinternedPlan: chunk.termRecordPreinternedPlan,
                preparedLookupIndexes: chunk.preparedLookupIndexes,
                mediaRows: chunk.mediaRows,
            });
            globalThis.gc?.();
            return;
        }
        digestView(digest, chunk.scoreList);
        digestView(digest, chunk.sequenceList);
        digestView(digest, chunk.readingEqualsExpressionList);
        digestView(digest, chunk.contentMetaList);
        digestView(digest, chunk.contentUniqueIndexList);
        digestView(digest, chunk.contentBytesBuffer.subarray(chunk.contentBytesBaseOffset ?? 0, (chunk.contentBytesBaseOffset ?? 0) + chunk.contentBytesLength));
        for (const [key, index] of chunk.preparedLookupIndexes) {
            digest.update(key);
            digest.update(index.bytes);
        }
        if (phase === 'encoder') {
            const plan = chunk.contentDedupPlan;
            const offsets = new Float64Array(plan.uniqueCount);
            const lengths = new Uint32Array(plan.uniqueCount);
            for (let i = 0; i < plan.uniqueCount; ++i) {
                const meta = (chunk.contentMetaByUniqueIndex ? i : plan.uniqueRowIndexes[i]) * 4;
                offsets[i] = contentBase + chunk.contentMetaList[meta];
                lengths[i] = chunk.contentMetaList[meta + 1];
            }
            const store = new TermRecordOpfsStore();
            const recordChunk = createArtifactTermRecordChunkWithResolvedContent({...chunk, dictionary: fixture.expectedTitle}, chunk.contentUniqueIndexList, offsets, lengths, chunk.preparedLookupIndexes);
            let fieldCalls = 0;
            let fieldBytes = 0;
            let observedFieldMs = 0;
            const original = store._encodeArtifactRecordFields.bind(store);
            store._encodeArtifactRecordFields = (...args) => {
                const start = performance.now();
                const result = original(...args);
                observedFieldMs += performance.now() - start;
                ++fieldCalls;
                fieldBytes += result.byteLength;
                return result;
            };
            let checkOutput = false;
            store._appendEncodedChunk = async (...args) => {
                if (checkOutput) { digest.update(args[5]); digest.update(args[6]); }
            };
            const measurements = [];
            for (let pass = 0; pass < 7; ++pass) {
                globalThis.gc?.();
                checkOutput = pass === 6;
                const start = performance.now();
                const metrics = await store._encodeAndAppendArtifactChunkForState({}, recordChunk, rows - chunk.rowCount + 1, new Float64Array(0), new Uint32Array(0), chunk.termRecordPreinternedPlan, 'raw', chunk.preparedLookupIndexes);
                measurements.push({pass, elapsedMs: performance.now() - start, ...metrics});
            }
            encoderMeasurements.push({rows: chunk.rowCount, uniqueContent: plan.uniqueCount, fieldCalls, fieldBytes, observedFieldMs, measurements});
            contentBase += chunk.contentBytesLength;
        }
        globalThis.gc?.();
    }
    globalThis.gc?.();
    const loadBefore = os.loadavg();
    const cpuBefore = process.cpuUsage();
    const started = performance.now();
    try {
        for (let start = 0; start < termFiles.length;) {
            const plan = sourcePipeline.createCompressedImportRunPlan(start);
            if (plan !== null) {
                assert.equal(await parser.parseTermBankWithWasmColumnChunksParallelCompressedLazy(plan.loaders, plan.estimatedByteLengths, 3, consume, options), true);
                profiles.push(parser.consumeLastTermBankWasmParseProfile());
                sourcePipeline.releaseBatch(plan.files);
                start += plan.files.length;
            } else {
                const files = sourcePipeline.getBatch(start);
                const batch = await sourcePipeline.readBatch(files);
                if (batch?.promises) {
                    assert.equal(await parser.parseTermBankWithWasmColumnChunksParallelDeferred(batch.promises, batch.estimatedByteLengths, 3, consume, options), true);
                } else {
                    await parser.parseTermBankWithWasmColumnChunks(batch, 3, consume, 2048, {...options, singleChunk: true});
                }
                profiles.push(parser.consumeLastTermBankWasmParseProfile());
                sourcePipeline.releaseBatch(files);
                start += files.length;
            }
        }
        assert.equal(rows, fixture.termRows);
        const elapsedMs = performance.now() - started;
        const cpu = process.cpuUsage(cpuBefore);
        const workers = workerLifecycles.slice(workerStartIndex).map((worker) => ({...worker, createdRelativeProducerMs: worker.createdAtMs - started, readyRelativeProducerMs: worker.readyAtMs === null ? null : worker.readyAtMs - started, startupMs: worker.readyAtMs === null ? null : worker.readyAtMs - worker.createdAtMs}));
        const readyTimes = workers.map((worker) => worker.readyRelativeProducerMs).filter((value) => value !== null);
        const row = {phase, iteration, rows, elapsedMs, compilePlusProducerMs: wasmCompileMs + elapsedMs, producerStartRelativeEntryMs: started - runnerEntryMs, allWorkersReadyRelativeProducerMs: readyTimes.length === workers.length ? Math.max(...readyTimes) : null, workers, processCpuMs: (cpu.user + cpu.system) / 1000, loadBefore, loadAfter: os.loadavg(), memory: process.memoryUsage(), maxRssKiB: process.resourceUsage().maxRSS, digest: verify ? digest.digest('hex') : null, chunks, profiles, encoderMeasurements};
        observations.push(row);
        await writeFile(outputPath, JSON.stringify({complete: false, fixture, source: startIdentity, observations}, null, 2) + '\n');
        process.stderr.write(JSON.stringify({scope: 'untimed-native-probe-counts', phase, iteration, chunks: chunks.length, rows, digest: row.digest}) + '\n');
    } finally {
        await sourcePipeline.dispose();
        await parser.disposeParallelTermBankParser();
        await Promise.all(terminations.splice(0));
    }
}
try {
    if (mode === 'capture') {
        await execute('capture', 0);
    } else if (mode === 'encoder') {
        await execute('encoder', 0);
    } else {
        if (mode === 'all') await execute('warmup', 0);
        if (mode !== 'verify') for (let i = 0; i < repeats; ++i) await execute('measured', i);
        if (mode !== 'timing') await execute('verify', 0);
    }
    assert.equal(mode, 'verify');
    assert.equal(observations.length, 1);
    assert.equal(observations[0].digest, expectedVerification.observations[0].digest);
    assert.deepEqual(observations[0].chunks, expectedVerification.observations[0].chunks);
    assert.deepEqual(startIdentity, expectedVerification.source);
    assert.equal(gitIdentity.sha, expectedVerification.gitIdentity.sha);
    assert.equal(slotProbeGroups.length, 12);
    assert.equal(slotProbeGroups.reduce((sum, group) => sum + group.counters.rows, 0), fixture.termRows);
    for (const [file, expected] of Object.entries(startIdentity)) assert.equal(hash(await readFile(join(root, file))), expected, `Source changed: ${file}`);
    assert.equal(git('rev-parse', 'HEAD'), gitIdentity.sha, 'Source commit changed during observation');
    await writeFile(outputPath, JSON.stringify({complete: true, scope: 'Component configuration with explicitly supplied hardwareConcurrency and deviceMemory=8; not a claim about the hosted browser topology. Production compressed source planner and native workers, adapting worker_threads transport only. Timing mode uses counter-only sinks and includes cold worker startup, inflate, parse, copies and prepared indexes; main WebAssembly.compile executes once before producer timing and its awaited API duration is reported separately, not total compiler CPU or later tiering work. Its compiled module is shared with workers; compile cost is not multiplied by worker count. Verification is separate and hashes all logical parser output columns, native content, media rows, plans and prepared lookup indexes; verification timings are not authoritative. Encoder mode runs the production resolved-reference record encoder seven times per group and intercepts persistence. Capture mode writes original native content/hash/plan columns and progress without dedup mutation. Excludes compression, global deduplication, browser OPFS, media storage and UI; not a complete-import result. Each pass uses fresh parser workers.', node: process.version, gitIdentity, startup: {nodePreEntryMs: runnerEntryMs, moduleImportMs, fixtureVerificationMs, wasmReadMs, wasmCompileMs, catalogMs}, fixture, lockSha256: hash(lockBytes), wasmSha256: hash(wasmBytes), runnerSha256: hash(await readFile(new URL(import.meta.url))), source: startIdentity, rawTermBankSourceBytes, options, hardwareConcurrency: Number(hardwareConcurrencyArg), deviceMemory: 8, canonicalCapture: canonicalCapture === null ? null : {directory: canonicalCapture.directory, groups: canonicalCapture.groups}, observations}, null, 2) + '\n');
} finally {
    await parser.disposeParallelTermBankParser();
    await Promise.all(terminations);
    await reader?.close();
}
