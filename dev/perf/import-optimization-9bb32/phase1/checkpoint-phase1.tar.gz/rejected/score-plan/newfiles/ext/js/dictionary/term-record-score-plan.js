/*
 * Copyright (C) 2026 Manabitan authors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

const MAX_COMPACT_SCORE_COUNT = 0xffff - 1;
const COMPACT_SCORE_TABLE_RADIUS = 256;
const COMPACT_SCORE_TABLE_MIN_ROWS = 64;
const ARRAY_BUFFER_BYTE_LENGTH_DESCRIPTOR = Object.getOwnPropertyDescriptor(ArrayBuffer.prototype, 'byteLength');

/** @typedef {{scores: Int32Array, keys: Uint16Array}} PreparedTermRecordScorePlan */

/**
 * Prepares the offset-independent part of compact record fields in the parser
 * worker. The score table uses the same first-seen ordering as the writer.
 * @param {number[]|Int32Array|Float64Array} scoreList
 * @param {number} start
 * @param {number} count
 * @returns {PreparedTermRecordScorePlan|null}
 */
export function prepareTermRecordScorePlan(scoreList, start, count) {
    if (
        !(scoreList instanceof Int32Array) ||
        !Number.isSafeInteger(start) || start < 0 ||
        !Number.isSafeInteger(count) || count <= 0 || start + count > scoreList.length
    ) { return null; }
    const keys = new Uint16Array(count);
    /** @type {number[]} */
    const scores = [];
    /** @type {Map<number, number>} */
    const scoreIndexes = new Map();
    const inlineScoreIndexes = count >= COMPACT_SCORE_TABLE_MIN_ROWS ?
        new Uint16Array(COMPACT_SCORE_TABLE_RADIUS * 2) : null;
    for (let i = 0; i < count; ++i) {
        const score = scoreList[start + i];
        const inlineScore = score + COMPACT_SCORE_TABLE_RADIUS;
        const useInlineScore = inlineScoreIndexes !== null && inlineScore >= 0 && inlineScore < inlineScoreIndexes.length;
        let scoreIndex = useInlineScore ? inlineScoreIndexes[inlineScore] - 1 : (scoreIndexes.get(score) ?? -1);
        if (scoreIndex < 0) {
            scoreIndex = scores.length;
            if (scoreIndex >= MAX_COMPACT_SCORE_COUNT) { return null; }
            if (useInlineScore) {
                inlineScoreIndexes[inlineScore] = scoreIndex + 1;
            } else {
                scoreIndexes.set(score, scoreIndex);
            }
            scores.push(score);
        }
        keys[i] = scoreIndex;
    }
    // Compact records must be strictly smaller than the legacy 12-byte rows.
    if (16 + (scores.length * 4) + (count * 8) >= count * 12) { return null; }
    return {scores: Int32Array.from(scores), keys};
}

/**
 * Snapshots owned ordinary arrays without invoking property accessors. The
 * writer still verifies every key against the current score column, so this
 * shape check does not cache a validation result across an awaited append.
 * @param {unknown} value
 * @param {number} count
 * @returns {PreparedTermRecordScorePlan|null}
 */
export function getPreparedTermRecordScorePlan(value, count) {
    if (typeof value !== 'object' || value === null) { return null; }
    const scores = /** @type {unknown} */ (Object.getOwnPropertyDescriptor(value, 'scores')?.value);
    const keys = /** @type {unknown} */ (Object.getOwnPropertyDescriptor(value, 'keys')?.value);
    if (
        !(scores instanceof Int32Array) || !(keys instanceof Uint16Array) ||
        !isPrivateOrdinaryView(scores, Int32Array.prototype) ||
        !isPrivateOrdinaryView(keys, Uint16Array.prototype) ||
        scores.length === 0 || scores.length > MAX_COMPACT_SCORE_COUNT || keys.length !== count
    ) { return null; }
    const seenScores = new Set();
    for (let i = 0; i < scores.length; ++i) {
        const score = scores[i];
        if (seenScores.has(score)) { return null; }
        seenScores.add(score);
    }
    return {scores, keys};
}

/**
 * @param {Int32Array|Uint16Array} value
 * @param {object} prototype
 * @returns {boolean}
 */
function isPrivateOrdinaryView(value, prototype) {
    if (
        typeof ARRAY_BUFFER_BYTE_LENGTH_DESCRIPTOR?.get !== 'function' ||
        !ArrayBuffer.isView(value) || Object.getPrototypeOf(value) !== prototype ||
        Object.hasOwn(value, 'length') || Object.hasOwn(value, 'buffer')
    ) { return false; }
    try {
        ARRAY_BUFFER_BYTE_LENGTH_DESCRIPTOR.get.call(value.buffer);
    } catch { return false; }
    return true;
}
