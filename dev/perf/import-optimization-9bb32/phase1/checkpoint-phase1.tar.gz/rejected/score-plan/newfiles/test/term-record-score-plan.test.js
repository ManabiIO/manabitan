/*
 * Copyright (C) 2026 Manabitan authors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import {describe, expect, test} from 'vitest';
import {createArtifactTermRecordChunkWithResolvedContent, TermRecordOpfsStore} from '../ext/js/dictionary/term-record-opfs-store.js';
import {getPreparedTermRecordScorePlan, prepareTermRecordScorePlan} from '../ext/js/dictionary/term-record-score-plan.js';

/** @param {number} [count=128] */
function fixture(count = 128) {
    const values = [256, -256, 255, -257, -2147483648, 2147483647, 0];
    return createArtifactTermRecordChunkWithResolvedContent(
        {rowCount: count, scoreList: Int32Array.from({length: count}, (_, i) => values[i % values.length])},
        Uint32Array.from({length: count}, (_, i) => (i * 17) % count),
        Float64Array.from({length: count}, (_, i) => 2 ** 40 + i * 19),
        Uint32Array.from({length: count}, (_, i) => i % 31),
    );
}

describe('prepared compact record scores', () => {
    test('preserves exact bytes and first-seen score order across inline/map values', () => {
        const chunk = fixture();
        const plan = prepareTermRecordScorePlan(chunk.scoreList, 0, chunk.rowCount);
        expect(Array.from(plan?.scores ?? [])).toEqual([256, -256, 255, -257, -2147483648, 2147483647, 0]);
        const store = new TermRecordOpfsStore();
        const expected = store._encodeArtifactRecordFields(chunk, [], [], 2 ** 40);
        const actual = store._encodeArtifactRecordFields(chunk, [], [], 2 ** 40, plan);
        expect(actual).toEqual(expected);
        expect(actual.buffer.byteLength).toBe(actual.byteLength);
        expect(store._tryEncodePreparedArtifactRecordFields(chunk, 2 ** 40, /** @type {NonNullable<typeof plan>} */ (plan))).toEqual(expected);
    });

    test('prepares exact subranges with their own first-seen order', () => {
        const chunk = fixture();
        const plan = prepareTermRecordScorePlan(chunk.scoreList, 3, 64);
        expect(Array.from(plan?.scores ?? [])).toEqual([-257, -2147483648, 2147483647, 0, 256, -256, 255]);
        expect(plan?.keys.length).toBe(64);
    });

    test('does not prepare fractional, negative-zero, wide, tiny or high-cardinality scores', () => {
        for (const values of [Float64Array.of(1.5, -0, 2 ** 40), [1, 1, 1], Int32Array.of(1, 1, 1), Int32Array.from({length: 65535}, (_, i) => i)]) {
            expect(prepareTermRecordScorePlan(values, 0, values.length)).toBeNull();
        }
    });

    test('falls back after scores or plan keys change without retaining stale values', () => {
        const store = new TermRecordOpfsStore();
        for (const mutation of ['score', 'key', 'order', 'duplicate', 'unused']) {
            const chunk = fixture();
            const plan = /** @type {NonNullable<ReturnType<typeof prepareTermRecordScorePlan>>} */ (prepareTermRecordScorePlan(chunk.scoreList, 0, chunk.rowCount));
            if (mutation === 'score') { chunk.scoreList[64] = 900; }
            if (mutation === 'key') { plan.keys[64] = 0xffff; }
            if (mutation === 'order') {
                [plan.scores[0], plan.scores[1]] = [plan.scores[1], plan.scores[0]];
                for (let i = 0; i < plan.keys.length; ++i) {
                    if (plan.keys[i] < 2) { plan.keys[i] = 1 - plan.keys[i]; }
                }
            }
            if (mutation === 'duplicate') { plan.scores[1] = plan.scores[0]; }
            if (mutation === 'unused') { plan.scores = Int32Array.from([...plan.scores, 999]); }
            expect(store._tryEncodePreparedArtifactRecordFields(chunk, 2 ** 40, plan)).toBeNull();
            expect(store._encodeArtifactRecordFields(chunk, [], [], 2 ** 40, plan)).toEqual(store._encodeArtifactRecordFields(chunk, [], [], 2 ** 40));
        }
    });

    test('keeps legacy large-content fields and rejects out-of-range references', () => {
        const chunk = fixture();
        const plan = prepareTermRecordScorePlan(chunk.scoreList, 0, chunk.rowCount);
        const store = new TermRecordOpfsStore();
        chunk.resolvedContentReferences.lengths[0] = 65535;
        const expected = store._encodeArtifactRecordFields(chunk, [], [], 2 ** 40);
        expect(expected.byteLength).toBe(chunk.rowCount * 12);
        expect(store._encodeArtifactRecordFields(chunk, [], [], 2 ** 40, plan)).toEqual(expected);
        chunk.resolvedContentReferences.lengths[0] = 1;
        chunk.resolvedContentReferences.uniqueIndexList[127] = 128;
        expect(() => store._encodeArtifactRecordFields(chunk, [], [], 2 ** 40, plan)).toThrow('Invalid resolved term content reference index: 128');
    });

    test('requires private ordinary plan arrays and existing chunk origin', () => {
        const chunk = fixture();
        const plan = /** @type {NonNullable<ReturnType<typeof prepareTermRecordScorePlan>>} */ (prepareTermRecordScorePlan(chunk.scoreList, 0, chunk.rowCount));
        const store = new TermRecordOpfsStore();
        expect(store._tryEncodePreparedArtifactRecordFields({...chunk}, 2 ** 40, plan)).toBeNull();
        expect(getPreparedTermRecordScorePlan({...plan, keys: new Uint16Array(new SharedArrayBuffer(256))}, 128)).toBeNull();
        expect(getPreparedTermRecordScorePlan({...plan, keys: new Proxy(plan.keys, {})}, 128)).toBeNull();
        expect(getPreparedTermRecordScorePlan({...plan, keys: plan.keys.subarray(0, 127)}, 128)).toBeNull();
        for (const property of ['length', 'buffer']) {
            const keys = plan.keys.slice();
            Object.defineProperty(keys, property, {get() { throw new Error('Unexpected accessor'); }});
            expect(getPreparedTermRecordScorePlan({...plan, keys}, 128)).toBeNull();
        }
    });
});
