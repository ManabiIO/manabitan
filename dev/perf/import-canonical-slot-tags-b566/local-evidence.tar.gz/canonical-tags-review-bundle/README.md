# Canonical slot tags: local review evidence

## Candidate and scope

Baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
Measured production candidate: `ea3cb4418b0163e3c7b1b5b5e1ad43c72171823a`.

The candidate stores a small rejection tag in unused high bits of the existing canonical slot word. A different tag skips the random full-hash loads for a probe collision. A matching tag still requires the original hash pair and existing exact-byte comparison. This changes no content hash, dictionary ordering, storage format, capacity policy, worker count, compression setting or typed-buffer size.

This bundle contains local component measurements and full source-to-sink output oracles. It does **not** establish a browser import speedup. The source-to-sink replay excludes SQLite, OPFS, UI, media processing and import finalization; the smaller resolver screen excludes parser, compression and persistence. Node main-thread CPU includes identical replay-state restoration and assertions. Browser qualification and full repository validation belong in separate PR receipts.

Production canonical WASM is 1755 bytes, SHA-256 `6bd9fe86d20561b4725aaba6794184679d5fcdad71c90cdd8f8f0c720b2f9cff`, +131 bytes versus develop. Its scanner function body is byte-identical to the 1719-byte diagnostic module used in the earlier kernel screens. `evidence/canonical-tags/production-body-proof.json` records both body hashes. The parser module remains exactly develop (`8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee`).

## What the fixed resolver screen shows

The production resolver ran on three actual JMdict captures: the initial all-miss group 0, a middle group 5 with 463 exact published hits, and final group 11 with 695 hits. Each arm restores the same input and metadata before calling the real production resolver. The candidate's original plain slots are packed once before timing. Complete metadata and result oracles accept only validated slot-tag encoding differences; every occupied tag must match the authoritative hash pair.

The fixed schedule was 12 adjacent AB/BA pairs per group, 32 calls per arm, with one A/A control after every third pair. Four single-call preflights per arm/group preceded timing. All 120 observations and 3096 resolver calls passed. Maximum RSS was 572888 KiB. No attempt was trimmed, retimed, retried or replaced.

| Actual group | Baseline median resolver ms/call | Candidate median resolver ms/call | Median paired change |
| --- | ---: | ---: | ---: |
| 0 | 1.777 | 1.489 | -14.82% |
| 5 | 5.166 | 4.721 | -9.40% |
| 11 | 6.026 | 5.178 | -15.06% |

Across 36 individual group pairs, the median resolver-wall change is −13.89%. The median of 12 ratios formed by summing the three groups within each block is −23.87% (descriptive bootstrap interval [−35.00,−0.97]%). That block statistic is more favorable because different groups contain large baseline observations in different blocks, giving those groups larger within-block weights. It is not the average of the three group medians. `evidence/canonical-tags/resolver-cohort-1/aggregation-audit.json` independently reconstructs every pair, order, time and weighted ratio. No value is a full-corpus estimate.

Same-code A/A controls also drifted favorably: block-sum resolver wall −8.70%, with a wide interval [−35.36,+3.09]%. Reset-plus-resolver thread CPU was −20.00% for A/B but its interval [−33.81,+12.85]% includes zero; A/A CPU was −9.55%. The sharper wall signal is concentrated in the canonical phase, while exact-byte comparison is approximately flat. Independent production arenas may introduce memory-placement effects. These facts limit the strength and scope of the measured gain.

Earlier bare-kernel screens are retained, including the less favorable replication. Separate arenas gave block-sum native-wall −16.03%; the opposite-order run sharing exactly one physical arena gave −6.99% with interval [−19.02,+14.58]%, crossing zero. Their identical-code and new-module legacy-mode controls are in the raw reports. These are mechanism diagnostics, not additional import samples.

## Full source-to-sink correctness

Fresh processes and empty database objects replayed all three pinned corpora with the actual source planner, native parser workers, canonical resolver, compression workers and record encoders. Record bytes, content bytes, descriptor digests and all 612 content readbacks equal develop. Native canonical scanning activated in each first group with zero fallback and no prewarming, exercising lazy module initialization and capability negotiation. The final packed-slot validator checked every live slot.

| Corpus | Rows | Successful content readbacks | Validated live slots |
| --- | ---: | ---: | ---: |
| JMdict | 528299 | 36 | 362032 |
| Jitendex | 436555 | 66 | 363243 |
| VNDB | 6648310 | 510 | 157150 |

The production reports and baseline reports include every output SHA, source file hash, runtime identity, fixture SHA, parser mode, group and route count. Media processing is outside this component replay, so these counts do not replace browser media verification.

## Bundle contents and failed attempts

`evidence/canonical-tags/` contains every raw JSON receipt from the completed tag smoke, both native cohorts, resolver smoke/cohort and all-three parity, their analyzers, source/build receipts, diagnostic C/module, the production patch and source-contract review. Completed progress snapshots are retained even where they duplicate final summaries.

`evidence/canonical-capture-tools/` contains the exact historical capture harness and worker bootstrap, recovered with byte hashes equal to the original capture receipt. `evidence/canonical-captures/captures.json` identifies the original 16 MiB of compressed inputs; those data blobs are omitted. The generation code, pinned fixture lock and complete capture correctness report are included. No fixture archive or dependency tree is bundled.

No tag benchmark smoke or fixed cohort failed. Four earlier setup/harness failures are retained separately: VNDB catalog expansion exceeding the fixed heap limit, the uniform-record-shard assumption, the parser diagnostic using Node Buffer slice semantics in zip.js, and the native parser smoke's initial-content-capacity assumption. Their available complete failure summaries and logs are included (two startup failures produced no summary), with the corrected behavior explained in `evidence/canonical-tags/negative-experiments-index.json`. Other rejected or held experiments are indexed by exact source checkpoint and original evidence location. Their results are not pooled with this candidate.

`bundle-manifest.json` lists every bundled file's byte count and SHA-256. Original receipts retain their historical absolute paths; current executable paths may differ when reproduced. The bundle is a snapshot of the measured candidate, not a substitute for the final PR head identity or later validation.

The original capture run includes snapshot cloning, serialization, compression, hashing and file writes inside its replay timer. Its generic timing description predates that capture hook. **None of the capture-run timing fields are used as performance measurements here.** The capture run supplies inputs and correctness oracles; measured results come only from the separately recorded kernel and resolver cohorts.

## Reproduce

Use Node exactly 22.22.0 and Python 3. Do not run compilation, unit tests, profilers or other benchmark jobs concurrently with a cohort. The original Node used only `--max-old-space-size=512`; engine tiering and GC defaults were unchanged. The harness fixes navigator policy to 4 hardware threads and 8 GiB. Use unique output directories; scripts refuse to overwrite final receipts.

Obtain both exact source commits in independent worktrees, then run `npm ci` and `npm run build:libs` in each. The committed source-bound WASM artifacts are sufficient; an independent native rebuild uses pinned Clang/LLD 21.1.8 and `npm run build:dictionary-wasm -- --check`. The included production binary patch can reconstruct the measured source from the baseline if the candidate ref is not yet available; verify every source hash and record the actual checkout identity rather than claiming its commit changed.

Run the following from the extracted bundle root after setting absolute paths:

```sh
BENCH_NODE=/absolute/path/to/node-v22.22.0/bin/node
BASE_ROOT=/absolute/path/to/manabitan-base
CANDIDATE_ROOT=/absolute/path/to/manabitan-canonical-tags
CORPUS_CACHE=/absolute/path/to/pinned-dictionary-zips
RUN_ROOT=/absolute/path/to/new-reproduction-output
```

Place the archive filenames from `fixtures/dictionaries.lock.json` in `CORPUS_CACHE`, using the pinned release URLs. The runners verify complete archive sizes and SHA-256 values before use.

Regenerate the exact actual resolver inputs using the original capture entry point:

```sh
"$BENCH_NODE" --max-old-space-size=512 \
  evidence/canonical-capture-tools/sink-replay.mjs \
  "$BASE_ROOT" "$CORPUS_CACHE" "$RUN_ROOT/capture-run" jmdict \
  "--capture-dedup=$RUN_ROOT/captures"
cmp evidence/canonical-captures/captures.json "$RUN_ROOT/captures/captures.json"
```

The generator's recorded SHA is `d8aa67e07d84a85ae73a27f23fad6ce1281f92d5e6ff65ca31d737472222d997`, bootstrap `0d6267ec814f1144763c22957b866c192875f40d29fad88b8ca0a6adc8e33e67`. Bundling verified these exact source bytes without acquiring a new capture. If regenerated capture bytes differ, retain that attempt and investigate; do not relabel it as the original input.

The production resolver smoke and fixed cohort use the same runner and policy:

```sh
"$BENCH_NODE" --max-old-space-size=512 \
  evidence/component-tools/dedup-tags-replay.mjs \
  "$BASE_ROOT" "$CANDIDATE_ROOT" "$RUN_ROOT/captures" \
  "$RUN_ROOT/resolver-smoke" 1 1
"$BENCH_NODE" --max-old-space-size=512 \
  evidence/component-tools/dedup-tags-replay.mjs \
  "$BASE_ROOT" "$CANDIDATE_ROOT" "$RUN_ROOT/captures" \
  "$RUN_ROOT/resolver-cohort" 12 32
python3 evidence/canonical-tags/analyze-resolver.py "$RUN_ROOT/resolver-cohort"
```

The historical native diagnostic schedules can be reproduced separately:

```sh
"$BENCH_NODE" --max-old-space-size=512 \
  evidence/canonical-tags/screen-v1.mjs \
  "$BASE_ROOT" "$RUN_ROOT/captures" \
  evidence/canonical-tags/candidate.wasm "$RUN_ROOT/kernel-separate" 12 64
"$BENCH_NODE" --max-old-space-size=512 \
  evidence/canonical-tags/screen.mjs \
  "$BASE_ROOT" "$RUN_ROOT/captures" \
  evidence/canonical-tags/candidate.wasm "$RUN_ROOT/kernel-shared" 12 64 shared BA
python3 evidence/canonical-tags/analyze-independent.py "$RUN_ROOT/kernel-separate"
python3 evidence/canonical-tags/analyze-independent.py "$RUN_ROOT/kernel-shared"
```

For all-three correctness, run a fresh process per source and corpus (the production catalog is necessary for VNDB's large central directory):

```sh
for corpus in jmdict jitendex vndb; do
  "$BENCH_NODE" --max-old-space-size=512   \
  evidence/component-tools/sink-replay-tags.mjs   \
  "$BASE_ROOT" "$CORPUS_CACHE" "$RUN_ROOT/base-$corpus" "$corpus" --production-catalog
  "$BENCH_NODE" --max-old-space-size=512   \
  evidence/component-tools/sink-replay-tags.mjs   \
  "$CANDIDATE_ROOT" "$CORPUS_CACHE" "$RUN_ROOT/tags-$corpus" "$corpus" --production-catalog
done
```

Compare `rows`, `recordRows`, `samples`, `samplesPassed`, `recordBytes`, `contentBytes`, `recordByteSha256`, `recordDescriptorSha256` and `contentByteSha256` exactly. Require every report complete, candidate native fallback 0, first-group native activation, no canonical prewarm, and nonzero validated packed tags. The archived `canonical-tags-parity.py` implements these checks for the original absolute workspace; use the generic commands above outside that workspace. Parity runs are correctness evidence, not an A/B import timing experiment.
