from pathlib import Path
import hashlib
import json
import os
import subprocess

directory = Path(__file__).resolve().parent
plan = json.loads((directory / 'source-plan.json').read_text())
compiler = os.environ['MANABITAN_CLANG']
linker = os.environ['MANABITAN_WASM_LD']
compiler_version = subprocess.check_output([compiler, '--version'], text=True)
linker_version = subprocess.check_output([linker, '--version'], text=True)
assert f"clang version {plan['toolchain']['compilerVersion']}" in compiler_version
assert f"LLD {plan['toolchain']['linkerVersion']}" in linker_version
builds = []
for name, source in [('baseline', plan['baselineSource']), ('candidate', plan['candidateSource'])]:
    output = directory / f'{name}.wasm'
    arguments = [compiler, f'-fuse-ld={linker}', *plan['baselineTarget']['arguments'], '-o', str(output), source]
    subprocess.run(arguments, check=True)
    content = output.read_bytes()
    digest = hashlib.sha256(content).hexdigest()
    if name == 'baseline':
        assert digest == plan['baselineTarget']['sha256']
    builds.append({'name': name, 'arguments': arguments, 'bytes': len(content), 'sha256': digest})
receipt = {'compilerVersion': compiler_version, 'linkerVersion': linker_version, 'builds': builds}
(directory / 'build.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps([{'name': b['name'], 'bytes': b['bytes'], 'sha256': b['sha256']} for b in builds]))
