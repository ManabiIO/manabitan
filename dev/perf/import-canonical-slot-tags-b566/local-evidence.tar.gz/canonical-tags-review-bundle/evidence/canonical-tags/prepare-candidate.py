from pathlib import Path
import hashlib
import json
import difflib

directory = Path(__file__).resolve().parent
root = directory.parents[1] / 'manabitan-base'
source_path = root / 'ext/js/dictionary/wasm/term-content-canonical-scan-v1.c'
original = source_path.read_text()
candidate = original
replacements = [
    ('int32_t scan_canonical(void) {', '''int32_t scan_canonical(uint32_t slot_index_mask) {
    // Diagnostic optional ABI: omitted/zero retains the original slot format.
    if (slot_index_mask == 0u) { slot_index_mask = 0xffffffffu; }
    const uint32_t tag_mask = ~slot_index_mask;'''),
    ('if (c[12] > MAX_ROWS || c[14] < c[13]', '''if ((slot_index_mask & (slot_index_mask + 1u)) != 0u || c[10] > slot_index_mask ||
        c[12] > MAX_ROWS || c[14] < c[13]'''),
    ('uint32_t index = slots[slot] - 1;', 'uint32_t index = (slots[slot] & slot_index_mask) - 1u;'),
    ('if (hash1[index] == m[2] && hash2[index] == m[3]) {', '''if ((slots[slot] & tag_mask) == (hash & tag_mask) &&
                hash1[index] == m[2] && hash2[index] == m[3]) {'''),
    ('slots[slot] = index + 1;', 'slots[slot] = (index + 1u) | (hash & tag_mask);'),
]
for old, new in replacements:
    assert candidate.count(old) == 1, old
    candidate = candidate.replace(old, new)
target = directory / 'term-content-canonical-scan-tags.c'
target.write_text(candidate)
(directory / 'candidate.patch').write_text(''.join(difflib.unified_diff(
    original.splitlines(keepends=True), candidate.splitlines(keepends=True),
    fromfile=str(source_path), tofile=str(target))))
manifest = json.loads((root / 'dev/data/dictionary-wasm/manifest.json').read_text())
canonical = next(x for x in manifest['targets'] if 'canonical' in x['name'])
(directory / 'source-plan.json').write_text(json.dumps({
    'scope': 'Diagnostic native reject filter only; no production JS, capacity policy, content hashes or exact-byte rules are changed.',
    'baselineSource': str(source_path),
    'baselineSourceSha256': hashlib.sha256(original.encode()).hexdigest(),
    'candidateSource': str(target),
    'candidateSourceSha256': hashlib.sha256(candidate.encode()).hexdigest(),
    'baselineTarget': canonical,
    'toolchain': manifest['toolchain'],
    'slotRule': 'mask is the least contiguous low-bit mask that can represent denseCapacity (index+1); tag is the remaining high bits of the existing mixed hash. Empty remains zero. Bounds and probe limits precede the reject filter; matching tags require both original hashes and the unchanged exact-candidate protocol.',
}, indent=2) + '\n')
print(json.dumps({'source': str(target), 'bytes': len(candidate), 'addedLines': len(candidate.splitlines()) - len(original.splitlines())}))
