import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, writeFile, mkdir} from 'node:fs/promises'
import {join, resolve} from 'node:path'
import {fileURLToPath, pathToFileURL} from 'node:url'
import {deserialize} from 'node:v8'
import {gunzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
import {createReplayState, resetReplayState, verifyReplayResult} from '../component-tools/dedup-snapshot.mjs'

const [baseArg, captureArg, candidateArg, outputArg, pairsArg = '12', repeatsArg = '16', memoryMode = 'separate', initialOrder = 'AB'] = process.argv.slice(2)
assert(baseArg && captureArg && candidateArg && outputArg)
const root = resolve(baseArg)
const captureDirectory = resolve(captureArg)
const candidatePath = resolve(candidateArg)
const output = resolve(outputArg)
const pairs = Number(pairsArg)
const repeats = Number(repeatsArg)
assert(Number.isInteger(pairs) && pairs > 0 && pairs <= 24)
assert(Number.isInteger(repeats) && repeats > 0 && repeats <= 64)
assert(['separate', 'shared'].includes(memoryMode))
assert(['AB', 'BA'].includes(initialOrder))
assert.equal(typeof process.threadCpuUsage, 'function')
await mkdir(output, {recursive: true})
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: 4, deviceMemory: 8}})
const originalFetch = globalThis.fetch
globalThis.fetch = async (url, options) => {
    const value = new URL(typeof url === 'string' ? url : url.url ?? url.href)
    return value.protocol === 'file:' ? new Response(await readFile(fileURLToPath(value))) : originalFetch(url, options)
}
const sha = (value) => createHash('sha256').update(value).digest('hex')
const hashMix = (first, second) => {
    let mixed = (first ^ Math.imul(second, 0x9e3779b1)) >>> 0
    return (mixed ^ (mixed >>> 16)) >>> 0
}
const indexMask = (capacity) => {
    let limit = 1
    while (limit <= capacity) limit *= 2
    assert(limit <= 0x100000000)
    return limit - 1
}
const importLocal = (file) => import(pathToFileURL(join(root, file)))
const {DictionaryDatabase} = await importLocal('ext/js/dictionary/dictionary-database.js')
const {compileCanonicalScanModule} = await importLocal('ext/js/dictionary/term-content-canonical-scan.js')
const {CANONICAL_SCAN_LAYOUT: layout} = await importLocal('ext/js/dictionary/term-content-canonical-layout.js')
await compileCanonicalScanModule()
const baselineBytes = await readFile(join(root, 'ext/lib/term-content-canonical-scan-v1.wasm'))
const candidateBytes = await readFile(candidatePath)
const modules = {
    baseline: await WebAssembly.compile(baselineBytes),
    candidate: await WebAssembly.compile(candidateBytes),
}
const captureManifestBytes = await readFile(join(captureDirectory, 'captures.json'))
const captures = JSON.parse(captureManifestBytes.toString('utf8'))
const identityFiles = [
    fileURLToPath(import.meta.url),
    fileURLToPath(new URL('../component-tools/dedup-snapshot.mjs', import.meta.url)),
    candidatePath,
    join(root, 'ext/lib/term-content-canonical-scan-v1.wasm'),
    join(root, 'ext/js/dictionary/term-content-canonical-scan.js'),
    join(root, 'ext/js/dictionary/dictionary-database.js'),
    join(root, 'ext/js/dictionary/term-content-metadata-arena.js'),
    join(captureDirectory, 'captures.json'),
]
const sourceHashes = Object.fromEntries(await Promise.all(identityFiles.map(async (path) => [path, sha(await readFile(path))])))
const cases = []
for (const entry of captures) {
    const archive = await readFile(join(captureDirectory, entry.filename))
    assert.equal(sha(archive), entry.sha256)
    const capture = deserialize(gunzipSync(archive))
    const state = createReplayState(new DictionaryDatabase(), capture)
    const nativeCases = []
    state.db._nativeCanonicalScanner._hooks.beforeNative = ({a}) => {
        nativeCases.push({before: new Uint8Array(a.memory.buffer).slice(), after: null})
    }
    state.db._nativeCanonicalScanner._hooks.beforeOutputView = ({a, column}) => {
        if (column === 0) nativeCases.at(-1).after = new Uint8Array(a.memory.buffer).slice()
    }
    const result = await state.db._resolveArtifactTermContentDedup(resetReplayState(state), true)
    verifyReplayResult(state, result)
    assert.equal(nativeCases.length, 1, 'This diagnostic admits only the complete captured single native segment')
    const raw = nativeCases[0]
    assert(raw.after)
    const config = new Uint32Array(raw.before.buffer, 1088, 22).slice()
    const header = new Uint32Array(raw.after.buffer, 1024, 7).slice()
    assert.equal(header[1], config[14] - config[13], 'Captured native segment must finish all actual representatives')
    const mask = indexMask(config[10])
    const arms = {}
    const sharedMemory = memoryMode === 'shared' ? new WebAssembly.Memory({initial: raw.before.byteLength / 65536, maximum: raw.before.byteLength / 65536}) : null
    for (const name of ['baseline', 'candidate', 'legacyControl']) {
        const tagged = name === 'candidate'
        const memory = sharedMemory ?? new WebAssembly.Memory({initial: raw.before.byteLength / 65536, maximum: raw.before.byteLength / 65536})
        const module = name === 'baseline' ? modules.baseline : modules.candidate
        const instance = new WebAssembly.Instance(module, {env: {memory}})
        const initial = raw.before.slice()
        if (tagged) {
            const slots = new Uint32Array(initial.buffer, config[0], config[1])
            const first = new Uint32Array(initial.buffer, config[2], config[10])
            const second = new Uint32Array(initial.buffer, config[3], config[10])
            for (let i = 0; i < slots.length; i++) {
                if (slots[i] === 0) continue
                const id = slots[i]
                assert(id <= config[10])
                slots[i] = (id | (hashMix(first[id - 1], second[id - 1]) & ~mask)) >>> 0
            }
        }
        arms[name] = {memory, bytes: new Uint8Array(memory.buffer), scan: instance.exports.scan_canonical, initial, mask: tagged ? mask : 0xffffffff}
    }
    cases.push({group: capture.group, config, header, expected: raw.after, beforeSha256: sha(raw.before), afterSha256: sha(raw.after), mask, arms})
}

function verify(testCase, arm) {
    const {config, expected} = testCase
    const actual = arm.bytes.slice()
    const slots = new Uint32Array(actual.buffer, config[0], config[1])
    const first = new Uint32Array(actual.buffer, config[2], config[10])
    const second = new Uint32Array(actual.buffer, config[3], config[10])
    for (let i = 0; i < slots.length; i++) {
        const stored = slots[i]
        if (stored === 0) continue
        const id = (stored & arm.mask) >>> 0
        assert(id > 0 && id <= config[10])
        assert.equal((stored & ~arm.mask) >>> 0, (hashMix(first[id - 1], second[id - 1]) & ~arm.mask) >>> 0, 'Cached tags must agree with both authoritative hashes')
        slots[i] = id
    }
    const header = new Uint32Array(actual.buffer, 1024, 7)
    const journal = new Uint32Array(actual.buffer, layout.JOURNAL, header[0] * 3)
    const expectedJournal = new Uint32Array(expected.buffer, layout.JOURNAL, header[0] * 3)
    for (let i = 0; i < journal.length; i += 3) {
        // Every native insertion targets an empty slot. Preserve the complete
        // rollback word; masking must not hide a corrupt high-bit-only value.
        assert.equal(expectedJournal[i + 1], 0)
        assert.equal(journal[i + 1], 0)
    }
    assert.deepEqual(actual.subarray(1024, 1024 + 28), expected.subarray(1024, 1024 + 28), 'Native header')
    assert.deepEqual(actual.subarray(1088, 1088 + 88), expected.subarray(1088, 1088 + 88), 'Read-only native config')
    assert.deepEqual(actual.subarray(layout.META), expected.subarray(layout.META), 'All input scratch, native results, rollback journal and authoritative metadata')
}

const observations = []
function runOne(testCase, name, phase, pair, position) {
    const arm = testCase.arms[name]
    let nativeWallMs = 0
    const cpuBefore = process.threadCpuUsage()
    const start = performance.now()
    for (let repetition = 0; repetition < repeats; repetition++) {
        arm.bytes.set(arm.initial)
        const nativeStart = performance.now()
        const code = arm.scan(name === 'candidate' ? arm.mask : 0)
        nativeWallMs += performance.now() - nativeStart
        assert.equal(code, 0)
    }
    const wallMs = performance.now() - start
    const cpu = process.threadCpuUsage(cpuBefore)
    verify(testCase, arm)
    const observation = {phase, pair, position, group: testCase.group, arm: name, repeats, nativeWallMs, resetAndNativeWallMs: wallMs, resetAndNativeThreadCpuMs: (cpu.user + cpu.system) / 1000, oracleMatched: true}
    observations.push(observation)
    return observation
}

const plan = {
    scope: 'Native canonical lookup/insert kernel on exact pre-call memory captured from real JMdict production resolver groups0/5/11. Hash tags only reject impossible hash-pair matches; matched tags retain original pair tests and exact-candidate output.',
    timing: 'A timed arm repeats full fixed-memory restoration and native scan. The thread-CPU timer includes identical restoration work, so it is not exclusive kernel CPU. Native-only wall durations are also accumulated. Module compilation, allocations, tag construction and complete oracle hashing are outside all timers. Every arm is verified after its fixed batch. No explicit GC, warm-only selection, trimmed observations, retries or changed production inputs.',
    baselineCommit: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim(),
    baselineWasmSha256: sha(baselineBytes), candidateWasmSha256: sha(candidateBytes),
    baselineWasmBytes: baselineBytes.length, candidateWasmBytes: candidateBytes.length,
    harnessSha256: sha(await readFile(fileURLToPath(import.meta.url))),
    snapshotHelperSha256: sourceHashes[fileURLToPath(new URL('../component-tools/dedup-snapshot.mjs', import.meta.url))],
    captureManifestSha256: sha(captureManifestBytes), sourceHashes,
    node: process.version, nodeSha256: sha(await readFile(process.execPath)), execArgv: process.execArgv,
    pairs, repeats, memoryMode, initialOrder,
    memoryBoundary: memoryMode === 'shared' ? 'All three modules/arms import the same fixed arena per captured group. Each arm restores its complete initial bytes before each call; only packed slot words differ. This controls persistent address placement and cache color between arms.' : 'Each arm imports a separate same-sized fixed memory; unchanged baseline controls share the baseline instance.',
    cases: cases.map(({group, config, header, beforeSha256, afterSha256, mask}) => ({group, config: [...config], header: [...header], beforeSha256, afterSha256, mask})),
    controls: 'One unchanged baseline/baseline control pair after each third experimental pair. After the main fixed experiment, four candidate-tagged/candidate-legacy pairs distinguish actual tag filtering from generic ABI/compiler changes.',
}
await writeFile(join(output, 'plan.json'), JSON.stringify(plan, null, 2) + '\n', {flag: 'wx'})
let complete = false
let failure = null
try {
    for (const testCase of cases) {
        for (const name of ['baseline', 'candidate', 'legacyControl']) runOne(testCase, name, 'firstObserved', 0, 0)
        for (let warmup = 0; warmup < 2; warmup++) {
            for (const name of warmup % 2 ? ['candidate', 'baseline'] : ['baseline', 'candidate']) runOne(testCase, name, 'warmup', warmup, 0)
        }
    }
    for (let pair = 0; pair < pairs; pair++) {
        for (let step = 0; step < cases.length; step++) {
            const testCase = cases[(step + pair) % cases.length]
            const baselineFirst = (pair % 2 === 0) === (initialOrder === 'AB')
            const order = baselineFirst ? ['baseline', 'candidate'] : ['candidate', 'baseline']
            order.forEach((name, position) => runOne(testCase, name, 'paired', pair, position))
            if ((pair + 1) % 3 === 0) {
                runOne(testCase, 'baseline', 'sameCodeControl', pair, 0)
                runOne(testCase, 'baseline', 'sameCodeControl', pair, 1)
            }
        }
        await writeFile(join(output, 'progress.json'), JSON.stringify({pairsCompleted: pair + 1, observations}, null, 2) + '\n')
    }
    for (let pair = 0; pair < 4; pair++) {
        for (const testCase of cases) {
            const legacyFirst = (pair % 2 === 0) === (initialOrder === 'AB')
            const order = legacyFirst ? ['legacyControl', 'candidate'] : ['candidate', 'legacyControl']
            order.forEach((name, position) => runOne(testCase, name, 'mechanismControl', pair, position))
        }
    }
    for (const [path, expected] of Object.entries(sourceHashes)) assert.equal(sha(await readFile(path)), expected, `Source changed during cohort: ${path}`)
    complete = true
} catch (error) {
    failure = String(error.stack ?? error)
} finally {
    const summary = {complete, failure, plan, observations, maxRssKiB: process.resourceUsage().maxRSS}
    await writeFile(join(output, 'summary.json'), JSON.stringify(summary, null, 2) + '\n', {flag: 'wx'})
    console.log(JSON.stringify({complete, failure, observations: observations.length, maxRssKiB: summary.maxRssKiB}))
    if (!complete) process.exitCode = 1
}
