import collections
import json
import pathlib
import random
import statistics
import sys

directory = pathlib.Path(sys.argv[1])
report = json.loads((directory / 'summary.json').read_text())
assert report['complete'], report['failure']
observations = report['observations']
assert all(observation['fullOracleMatched'] for observation in observations)
metrics = {
    'resolverWallPerCallMs': 'resolverWallMs',
    'canonicalWallPerCallMs': 'canonicalWallMs',
    'exactWallPerCallMs': 'exactWallMs',
    'resetAndResolverWallPerCallMs': 'resetAndResolverWallMs',
    'resetAndResolverThreadCpuPerCallMs': 'resetAndResolverThreadCpuMs',
}


def interval(values):
    rng = random.Random(566)
    boot = sorted(statistics.median(rng.choices(values, k=len(values))) for _ in range(10000))
    return [boot[250], boot[9750]]


def summarize(pairs, field):
    before = [pair['A'][field] for pair in pairs]
    after = [pair['B'][field] for pair in pairs]
    difference = [b - a for a, b in zip(before, after)]
    percent = [(b / a - 1) * 100 if a else 0 for a, b in zip(before, after)]
    return {
        'pairs': len(pairs),
        'referenceMedian': statistics.median(before),
        'comparisonMedian': statistics.median(after),
        'pairedMedianDifference': statistics.median(difference),
        'pairedMedianDifference95CI': interval(difference),
        'pairedMedianPercent': statistics.median(percent),
        'pairedMedianPercent95CI': interval(percent),
        'equalWorkTotalChangePercent': (sum(after) / sum(before) - 1) * 100 if sum(before) else 0,
        'comparisonFasterPairs': sum(value < 0 for value in difference),
        'referenceRange': [min(before), max(before)],
        'comparisonRange': [min(after), max(after)],
    }


by_pair = collections.defaultdict(dict)
first_observed = []
for observation in observations:
    row = {**observation, **{field: observation[source] / observation['repeats'] for field, source in metrics.items()}}
    if row['phase'] == 'firstObserved':
        first_observed.append(row)
    if row['phase'] == 'paired':
        label = 'A' if row['variant'] == 'baseline' else 'B'
        assert row['variant'] in ['baseline', 'candidate']
    elif row['phase'] == 'sameCodeControl':
        label = 'A' if row['position'] == 0 else 'B'
        assert row['variant'] == 'baseline'
    else:
        continue
    key = (row['phase'], row['group'], row['pair'])
    assert label not in by_pair[key]
    by_pair[key][label] = row
assert all(set(pair) == {'A', 'B'} for pair in by_pair.values())
groups = sorted({key[1] for key in by_pair})
phases = ['paired', 'sameCodeControl']
aggregate = collections.defaultdict(lambda: {'A': collections.Counter(), 'B': collections.Counter()})
for (phase, group, pair_index), pair in by_pair.items():
    for label in ['A', 'B']:
        for field in metrics:
            aggregate[(phase, pair_index)][label][field] += pair[label][field]
for group in groups:
    assert sum(phase == 'paired' and g == group for phase, g, _ in by_pair) == report['plan']['pairs']
    assert sum(phase == 'sameCodeControl' and g == group for phase, g, _ in by_pair) == report['plan']['pairs'] // 3

analysis = {
    'complete': True,
    'allOraclesMatched': True,
    'groups': groups,
    'observations': len(observations),
    'resolverCallsAcrossAllPhases': sum(observation['repeats'] for observation in observations),
    'resolverCallsPaired': sum(observation['repeats'] for observation in observations if observation['phase'] == 'paired'),
    'scope': report['plan']['scope'],
    'timing': report['plan']['timing'],
    'memoryMode': report['plan'].get('memoryMode', 'separate'),
    'memoryBoundary': report['plan'].get('memoryBoundary', 'A/A reuses the baseline arena; A/B comparisons use separate production DB instances and arenas.'),
    'plan': report['plan'],
    'capturedGroupSum': {},
    'pooledGroupPairs': {},
    'byGroup': {},
    'orderDiagnostic': {},
    'firstObservedBatches': first_observed,
    'maxRssKiB': report['maxRssKiB'],
    'comparisonLabels': {
        'paired': 'comparison=full tagged production resolver; reference=full baseline production resolver',
        'sameCodeControl': 'comparison=second baseline arm; reference=first baseline arm',
    },
    'warning': 'Three actual captured groups only; sums are equal-work full-resolver component equivalents, not full-corpus or import times. Thread CPU includes identical metadata/plan restoration and per-call assertions. Resolver, canonical, and exact-byte wall times are accumulated separately and are not exclusive CPU. Independent arenas can introduce memory-placement/cache effects; A/A reuses one arena. Entire fresh source-to-sink correctness was established separately. Bootstrap intervals describe this fixed cohort and do not cover environmental/scope uncertainty. All observations are retained.',
}
for phase in phases:
    pooled = [pair for (p, group, index), pair in by_pair.items() if p == phase]
    grouped = [pair for (p, index), pair in aggregate.items() if p == phase]
    analysis['capturedGroupSum'][phase] = {field: summarize(grouped, field) for field in metrics}
    analysis['pooledGroupPairs'][phase] = {field: summarize(pooled, field) for field in metrics}
    for group in groups:
        rows = [pair for (p, g, index), pair in by_pair.items() if p == phase and g == group]
        analysis['byGroup'].setdefault(group, {})[phase] = {field: summarize(rows, field) for field in metrics}
for position, label in [(0, 'baselineFirst'), (1, 'candidateFirst')]:
    pairs = [pair for (phase, group, index), pair in by_pair.items() if phase == 'paired' and pair['A']['position'] == position]
    analysis['orderDiagnostic'][label] = {field: summarize(pairs, field) for field in metrics}
analysis['rawCapturedGroupSums'] = [{'phase': phase, 'pair': index, **pair} for (phase, index), pair in aggregate.items()]
(directory / 'analysis-independent.json').write_text(json.dumps(analysis, indent=2) + '\n')
print(json.dumps({key: value for key, value in analysis.items() if key not in ('plan', 'byGroup', 'rawCapturedGroupSums', 'firstObservedBatches')}, indent=2))
