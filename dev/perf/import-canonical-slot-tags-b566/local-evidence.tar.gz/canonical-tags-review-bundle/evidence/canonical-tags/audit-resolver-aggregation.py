import collections
import hashlib
import json
import math
from pathlib import Path
import statistics

root = Path(__file__).resolve().parent
source = root / 'resolver-cohort-1/summary.json'
recorded = json.loads((root / 'resolver-cohort-1/analysis-independent.json').read_text())
report = json.loads(source.read_text())
assert report['complete'] and report['failure'] is None
observations = report['observations']
assert len(observations) == 120
assert all(x['fullOracleMatched'] for x in observations)
phase_counts = collections.Counter(x['phase'] for x in observations)
assert phase_counts == {'firstObserved': 6, 'preflight': 18, 'paired': 72, 'sameCodeControl': 24}
assert sum(x['repeats'] for x in observations) == 3096
pairs = {}
for row in observations:
    if row['phase'] != 'paired':
        continue
    assert row['repeats'] == 32
    key = row['pair'], row['group']
    pair = pairs.setdefault(key, {})
    assert row['variant'] not in pair
    pair[row['variant']] = row
assert len(pairs) == 36
blocks = []
group_ratios = collections.defaultdict(list)
group_times = collections.defaultdict(lambda: {'baseline': [], 'candidate': []})
for pair_index in range(12):
    groups = []
    before_sum = 0
    after_sum = 0
    for group in (0, 5, 11):
        before, after = (pairs[pair_index, group][key] for key in ('baseline', 'candidate'))
        assert before['position'] == pair_index % 2
        assert after['position'] == 1 - pair_index % 2
        a, b = (x['resolverWallMs'] / x['repeats'] for x in (before, after))
        percent = 100 * (b / a - 1)
        group_ratios[group].append(percent)
        group_times[group]['baseline'].append(a)
        group_times[group]['candidate'].append(b)
        before_sum += a
        after_sum += b
        groups.append({'group': group, 'baselineMs': a, 'candidateMs': b, 'pairedPercent': percent})
    weighted = sum(x['baselineMs'] / before_sum * x['pairedPercent'] for x in groups)
    percent = 100 * (after_sum / before_sum - 1)
    assert math.isclose(weighted, percent, abs_tol=1e-12)
    for group in groups:
        group['baselineWeightInBlock'] = group['baselineMs'] / before_sum
    blocks.append({'pair': pair_index, 'order': 'AB' if pair_index % 2 == 0 else 'BA',
                   'groups': groups, 'baselineSumMs': before_sum, 'candidateSumMs': after_sum,
                   'pairedSumPercent': percent, 'verifiedWeightedGroupPercent': weighted})
median_sum_percent = statistics.median(x['pairedSumPercent'] for x in blocks)
assert math.isclose(median_sum_percent, recorded['capturedGroupSum']['paired']['resolverWallPerCallMs']['pairedMedianPercent'], abs_tol=1e-12)
pooled = [value for values in group_ratios.values() for value in values]
pooled_median = statistics.median(pooled)
assert math.isclose(pooled_median, recorded['pooledGroupPairs']['paired']['resolverWallPerCallMs']['pairedMedianPercent'], abs_tol=1e-12)
by_group = {group: {'pairedMedianPercent': statistics.median(values),
                    'baselineMedianMs': statistics.median(group_times[group]['baseline']),
                    'candidateMedianMs': statistics.median(group_times[group]['candidate']),
                    'baselineRangeMs': [min(group_times[group]['baseline']), max(group_times[group]['baseline'])],
                    'candidateRangeMs': [min(group_times[group]['candidate']), max(group_times[group]['candidate'])]}
            for group, values in group_ratios.items()}
for group, values in by_group.items():
    assert math.isclose(values['pairedMedianPercent'], recorded['byGroup'][str(group)]['paired']['resolverWallPerCallMs']['pairedMedianPercent'], abs_tol=1e-12)
result = {
    'sourceReportSha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'auditScriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'pairAssignmentAndOrderVerified': True,
    'allRecordedAttemptsRetained': True,
    'phaseObservationCounts': dict(phase_counts),
    'totalResolverCalls': sum(x['repeats'] for x in observations),
    'medianOfTwelveBlockSumRatiosPercent': median_sum_percent,
    'medianOfThirtySixGroupPairRatiosPercent': pooled_median,
    'equalWorkAllCallsRatioPercent': 100 * (sum(x['candidateSumMs'] for x in blocks) / sum(x['baselineSumMs'] for x in blocks) - 1),
    'byGroup': by_group,
    'blocks': blocks,
    'explanation': 'Each block ratio equals the baseline-time-weighted average of its three group ratios. The median of block ratios does not equal an average or median of the three separate group medians. Large baseline observations occur in different groups across blocks, giving those groups larger weight in their blocks. This is a correct calculation but a noisy aggregate, not a general speedup estimate.',
    'reportingRecommendation': 'Lead with group-specific resolver medians or the pooled 36-pair median, retain the block-sum statistic with its exact definition, and show A/A drift and all raw observations. Do not extrapolate these three groups to all JMdict or browser import time. No observations were removed or retimed.',
}
(root / 'resolver-cohort-1/aggregation-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'blocks'}, indent=2))
