import collections
import json
import pathlib
import random
import statistics
import sys

directory = pathlib.Path(sys.argv[1])
report = json.loads((directory / 'summary.json').read_text())
assert report['complete'], report['failure']
observations = report['observations']
assert all(observation['oracleMatched'] for observation in observations)
metrics = {
    'nativeWallPerCallMs': 'nativeWallMs',
    'restoreAndNativeWallPerCallMs': 'resetAndNativeWallMs',
    'restoreAndNativeThreadCpuPerCallMs': 'resetAndNativeThreadCpuMs',
}


def interval(values):
    rng = random.Random(566)
    boot = sorted(statistics.median(rng.choices(values, k=len(values))) for _ in range(10000))
    return [boot[250], boot[9750]]


def summarize(pairs, field):
    before = [pair['A'][field] for pair in pairs]
    after = [pair['B'][field] for pair in pairs]
    difference = [b - a for a, b in zip(before, after)]
    percent = [(b / a - 1) * 100 for a, b in zip(before, after)]
    return {
        'pairs': len(pairs),
        'referenceMedian': statistics.median(before),
        'comparisonMedian': statistics.median(after),
        'pairedMedianDifference': statistics.median(difference),
        'pairedMedianDifference95CI': interval(difference),
        'pairedMedianPercent': statistics.median(percent),
        'pairedMedianPercent95CI': interval(percent),
        'equalWorkTotalChangePercent': (sum(after) / sum(before) - 1) * 100,
        'comparisonFasterPairs': sum(value < 0 for value in difference),
        'referenceRange': [min(before), max(before)],
        'comparisonRange': [min(after), max(after)],
    }


by_pair = collections.defaultdict(dict)
first_observed = []
for observation in observations:
    row = {**observation, **{field: observation[source] / observation['repeats'] for field, source in metrics.items()}}
    if row['phase'] == 'firstObserved':
        first_observed.append(row)
    if row['phase'] == 'paired':
        label = 'A' if row['arm'] == 'baseline' else 'B'
        assert row['arm'] in ['baseline', 'candidate']
    elif row['phase'] == 'sameCodeControl':
        label = 'A' if row['position'] == 0 else 'B'
        assert row['arm'] == 'baseline'
    elif row['phase'] == 'mechanismControl':
        label = 'A' if row['arm'] == 'legacyControl' else 'B'
        assert row['arm'] in ['legacyControl', 'candidate']
    else:
        continue
    key = (row['phase'], row['group'], row['pair'])
    assert label not in by_pair[key]
    by_pair[key][label] = row
assert all(set(pair) == {'A', 'B'} for pair in by_pair.values())
groups = sorted({key[1] for key in by_pair})
phases = ['paired', 'sameCodeControl', 'mechanismControl']
aggregate = collections.defaultdict(lambda: {'A': collections.Counter(), 'B': collections.Counter()})
for (phase, group, pair_index), pair in by_pair.items():
    for label in ['A', 'B']:
        for field in metrics:
            aggregate[(phase, pair_index)][label][field] += pair[label][field]
for group in groups:
    assert sum(phase == 'paired' and g == group for phase, g, _ in by_pair) == report['plan']['pairs']
    assert sum(phase == 'sameCodeControl' and g == group for phase, g, _ in by_pair) == report['plan']['pairs'] // 3
    assert sum(phase == 'mechanismControl' and g == group for phase, g, _ in by_pair) == 4

analysis = {
    'complete': True,
    'allOraclesMatched': True,
    'groups': groups,
    'observations': len(observations),
    'nativeCallsAcrossAllPhases': sum(observation['repeats'] for observation in observations),
    'nativeCallsPaired': sum(observation['repeats'] for observation in observations if observation['phase'] == 'paired'),
    'scope': report['plan']['scope'],
    'timing': report['plan']['timing'],
    'memoryMode': report['plan'].get('memoryMode', 'separate'),
    'memoryBoundary': report['plan'].get('memoryBoundary', 'A/A reuses the baseline arena; A/B and mechanism comparisons use separate arenas.'),
    'plan': report['plan'],
    'capturedGroupSum': {},
    'pooledGroupPairs': {},
    'byGroup': {},
    'orderDiagnostic': {},
    'firstObservedBatches': first_observed,
    'maxRssKiB': report['maxRssKiB'],
    'comparisonLabels': {
        'paired': 'comparison=tagged candidate; reference=baseline module',
        'sameCodeControl': 'comparison=second baseline arm; reference=first baseline arm',
        'mechanismControl': 'comparison=tagged candidate; reference=same candidate module in legacy slot mode',
    },
    'warning': 'Three actual captured groups only; group sums are equal-work native component equivalents, not full-corpus or import times. Thread CPU includes full arena restoration and JS loop/timer costs. Native wall is accumulated separately and is not exclusive native CPU. See memoryBoundary for the placement control in this cohort. Bootstrap intervals describe this fixed cohort and do not cover environmental/scope uncertainty. All observations are retained.',
}
for phase in phases:
    pooled = [pair for (p, group, index), pair in by_pair.items() if p == phase]
    grouped = [pair for (p, index), pair in aggregate.items() if p == phase]
    analysis['capturedGroupSum'][phase] = {field: summarize(grouped, field) for field in metrics}
    analysis['pooledGroupPairs'][phase] = {field: summarize(pooled, field) for field in metrics}
    for group in groups:
        rows = [pair for (p, g, index), pair in by_pair.items() if p == phase and g == group]
        analysis['byGroup'].setdefault(group, {})[phase] = {field: summarize(rows, field) for field in metrics}
for position, label in [(0, 'baselineFirst'), (1, 'candidateFirst')]:
    pairs = [pair for (phase, group, index), pair in by_pair.items() if phase == 'paired' and pair['A']['position'] == position]
    analysis['orderDiagnostic'][label] = {field: summarize(pairs, field) for field in metrics}
analysis['rawCapturedGroupSums'] = [{'phase': phase, 'pair': index, **pair} for (phase, index), pair in aggregate.items()]
(directory / 'analysis-independent.json').write_text(json.dumps(analysis, indent=2) + '\n')
print(json.dumps({key: value for key, value in analysis.items() if key not in ('plan', 'byGroup', 'rawCapturedGroupSums', 'firstObservedBatches')}, indent=2))
