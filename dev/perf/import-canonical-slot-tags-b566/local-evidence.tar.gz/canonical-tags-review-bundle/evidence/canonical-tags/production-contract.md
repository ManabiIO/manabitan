# Packed canonical metadata slot contract

The production candidate starts at develop `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. It does not include either parser-hint experiment.

Each authoritative `Uint32Array` slot keeps `denseIndex + 1` in its low bits and a rejection tag in the remaining high bits. The tag uses the existing full hash-pair mix. Empty slots remain zero. A matching tag still requires both original hashes; published content still requires the existing exact-byte comparison. Hashes, signatures, dense IDs, content ordering and persisted record bytes retain their existing meanings.

The arena owns a nonwritable, nonconfigurable `slotIndexMask`. The mask must represent its dense capacity, including the last index plus one. Slot copying requires both the same slot capacity and the same index mask. A mask-changing dense growth rebuilds slots even when the slot count is unchanged. Rehashing decodes the old generation with its old mask and repacks into the new generation; it preserves both published and pending entries and skips freed IDs. The replacement is published only after all allocations, copying and rehashing succeed.

The native `scan_canonical` export accepts an optional mask. Omitted or zero retains the legacy untagged representation. `canonical_slot_tag_version()` returns `1` and is defined after the scanner, preserving the scanner's function index of four. The JavaScript adapter checks this capability and the existing ABI/layout exports before calling a module on packed slots. An old module can fall back to the packed-aware JavaScript path before progress. A trap or failure after accepted mutation cannot silently retry through fallback.

Every native segment reacquires the current arena and mask after exact-byte awaits. Native index bounds and probe exhaustion checks occur before tag rejection. Synchronous rollback treats journal slot values as opaque words, restoring tags together with IDs. Ordinary outer rollback continues to mark owned pending entries empty and rehash surviving entries.

All JavaScript slot readers and writers use the same representation: direct staging, prepared reservation, published lookup, published replacement, fast insertion, and both dense and sparse rehash traversals. Content capacity policies, memory budgets, worker counts, compression settings and storage formats are unchanged. The tag occupies existing slot bits and adds no typed buffer or per-row allocation.

Focused coverage includes default native ABI calls, full-hash collisions after matching tags, bucket collisions with different tags, malformed low IDs rejected before tag skipping, probe exhaustion, same-slot-count mask growth, old-mask sparse rehashing, immutable mask descriptors, native and JavaScript reservations/rollback, and old-module capability fallback. Existing differential tests also cover exact-comparison await boundaries, arena replacement, trap/copy failures, full slot restoration and record/index output equality.

The earlier bare-kernel timing screens are component evidence. This production checkpoint makes no complete-import speed claim and is not published. Full pipeline parity, source-bound benchmarks and required broader qualification remain separate gates.
