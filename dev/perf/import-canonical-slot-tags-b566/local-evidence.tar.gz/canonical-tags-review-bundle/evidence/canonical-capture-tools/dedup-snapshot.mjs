import assert from 'node:assert/strict'
import {serialize} from 'node:v8'
import {gzipSync} from 'node:zlib'
import {createHash} from 'node:crypto'
import {mkdir, writeFile} from 'node:fs/promises'
import {join} from 'node:path'

export const arenaColumns = {
    _termEntryContentMetaHashPairTable: 'slots',
    _termEntryContentMetaHash1Table: 'hash1',
    _termEntryContentMetaHash2Table: 'hash2',
    _termEntryContentMetaStateTable: 'state',
    _termEntryContentMetaLengthTable: 'length',
    _termEntryContentMetaSignaturePresentTable: 'signaturePresent',
    _termEntryContentMetaSignature1Table: 'signature1',
    _termEntryContentMetaSignature2Table: 'signature2',
    _termEntryContentMetaSignature3Table: 'signature3',
}

export function clone(value) {
    if (value === null || typeof value !== 'object') return value
    if (ArrayBuffer.isView(value)) return value.slice()
    if (Array.isArray(value)) return value.map(clone)
    if (value instanceof Map) return new Map([...value].map(([key, item]) => [clone(key), clone(item)]))
    if (value instanceof Set) return new Set([...value].map(clone))
    const result = {}
    for (const [key, item] of Object.entries(value)) {
        if (typeof item !== 'function') result[key] = clone(item)
    }
    return result
}

export function snapshotMetadata(db, copy = true) {
    const properties = {}
    for (const key of Object.keys(db)) {
        if (key.startsWith('_termEntryContentMeta') && !Object.hasOwn(arenaColumns, key)) properties[key] = copy ? clone(db[key]) : db[key]
    }
    const arena = db._termContentMetadataArena
    return {
        properties,
        arena: arena === null ? null : {
            denseCapacity: arena.state.length,
            slotCapacity: arena.slots.length,
            columns: Object.fromEntries(Object.values(arenaColumns).map((key) => [key, copy ? arena[key].slice() : arena[key]])),
        },
    }
}

export function snapshotChunk(chunk) {
    const keys = ['dictionary', 'rowCount', 'dictionaryTotalRows', 'contentBytesList', 'contentHash1List', 'contentHash2List', 'contentBytesBuffer', 'contentBytesBaseOffset', 'contentMetaList', 'contentMetaByUniqueIndex', 'contentUniqueIndexList', 'contentDedupPlan', 'contentRowStart', 'contentDictNameList', 'uniformContentDictName', 'useResolvedContentReferences']
    return Object.fromEntries(keys.filter((key) => Object.hasOwn(chunk, key)).map((key) => [key, clone(chunk[key])]))
}

export function normalizeResult(result) {
    const keys = ['contentOffsets', 'contentLengths', 'resolvedContentDictNames', 'pendingContentBytes', 'pendingContentHash1s', 'pendingContentHash2s', 'pendingContentDictNames', 'pendingRowToUniqueIndex', 'pendingContentCount', 'uniformContentDictName', 'pendingHitCount', 'persistedHitCount', 'exactFallbackCount', 'recentSourceHitCount', 'pendingPlanUniqueIndexes', 'pendingPlanUniqueStart', 'stagedContentMetadata']
    const normalized = Object.fromEntries(keys.map((key) => [key, clone(result[key])]))
    normalized.pendingContentSpans = result.pendingContentSpans === null ? null : {offsets: result.pendingContentSpans.offsets.slice(), lengths: result.pendingContentSpans.lengths.slice()}
    const planKeys = ['resolvedFlags', 'resolvedOffsets', 'resolvedLengths', 'resolvedDictNames', 'resolvedUniformDictName', 'pendingEpochs', 'pendingIndexes', 'nextEpoch', 'nextUnresolvedUniqueIndex', 'persistedLookupRequired', 'resolutionDeferred']
    normalized.plan = Object.fromEntries(planKeys.map((key) => [key, clone(result.contentDedupPlan?.[key])]))
    normalized.native = Object.fromEntries(Object.entries(result.nativeScanMetrics ?? {}).filter(([key]) => key !== 'dedupNativeCopiedInputBytes'))
    return normalized
}

export function metadataIdentity(value) {
    if (value === null || typeof value !== 'object') return value
    if (ArrayBuffer.isView(value)) return {type: value.constructor.name, length: value.length, sha256: createHash('sha256').update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength)).digest('hex')}
    if (Array.isArray(value)) return value.map(metadataIdentity)
    if (value instanceof Map) return {map: [...value].map(([key, item]) => [metadataIdentity(key), metadataIdentity(item)])}
    if (value instanceof Set) return {set: [...value].map(metadataIdentity)}
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, metadataIdentity(item)]))
}

export function installDedupCapture(db, output, selectedGroups, getGroupIndex) {
    const selected = new Set(selectedGroups)
    const originalResolve = db._resolveArtifactTermContentDedup.bind(db)
    const originalRecent = db._findRecentTermContentSource.bind(db)
    const originalRead = db._readTermEntryContentBytesDetailedBatch.bind(db)
    const captures = []
    let active = null
    db._findRecentTermContentSource = (meta) => {
        const result = originalRecent(meta)
        if (active !== null) {
            const entry = result ? {
                index: meta.tableIndex,
                batchId: db._termEntryContentMetaRecentSourceBatchIdTable[meta.tableIndex],
                offset: result.offset,
                length: result.length,
                bytes: result.buffer.slice(result.offset, result.offset + result.length),
            } : {index: meta.tableIndex, missing: true}
            const previous = active.cacheReads.get(meta.tableIndex)
            if (previous) assert.deepEqual(entry, previous)
            else active.cacheReads.set(meta.tableIndex, entry)
        }
        return result
    }
    db._readTermEntryContentBytesDetailedBatch = async (requests) => {
        if (active !== null) active.storageReadRequests.push(clone(requests))
        return await originalRead(requests)
    }
    db._resolveArtifactTermContentDedup = async (chunk, reserve) => {
        const group = getGroupIndex()
        if (!selected.has(group)) return await originalResolve(chunk, reserve)
        selected.delete(group)
        assert.equal(reserve, true)
        assert.equal(db._inFlightTermContentSourceBatches.size, 0, 'Capture only serial baseline sink boundaries')
        const capture = {
            format: 1,
            group,
            scope: 'Actual pinned-corpus full dedup resolver input and authoritative metadata. Recent-cache captures contain exactly the byte ranges read by this resolver, at their original batch IDs and offsets. Replay rejects uncaptured cache or storage reads.',
            input: snapshotChunk(chunk),
            before: snapshotMetadata(db),
            cacheBatches: [...db._recentTermContentSourceBatches].map(([id, bytes]) => ({id, byteLength: bytes.byteLength})),
            cacheReads: new Map(),
            storageReadRequests: [],
        }
        active = capture
        let result
        try { result = await originalResolve(chunk, reserve) } finally { active = null }
        assert.equal(capture.storageReadRequests.length, 0, 'Expected all actual JMdict exact reads to hit recent source cache')
        capture.oracle = normalizeResult(result)
        capture.after = metadataIdentity(snapshotMetadata(db, false))
        const bytes = gzipSync(serialize(capture), {level: 6})
        const filename = `group-${String(group).padStart(2, '0')}.bin.gz`
        await mkdir(output, {recursive: true})
        await writeFile(join(output, filename), bytes, {flag: 'wx'})
        captures.push({group, filename, bytes: bytes.byteLength, sha256: createHash('sha256').update(bytes).digest('hex'), rows: chunk.rowCount, uniqueRows: chunk.contentDedupPlan.uniqueCount, pending: result.pendingContentCount, persistedHits: result.persistedHitCount, exact: result.exactFallbackCount, cacheReads: capture.cacheReads.size})
        await writeFile(join(output, 'captures.json'), JSON.stringify(captures, null, 2) + '\n')
        assert(captures.reduce((total, item) => total + item.bytes, 0) < 40 * 1024 * 1024, 'Capture archive budget exceeded')
        return result
    }
    return captures
}

export function createReplayState(db, capture) {
    const template = capture.before.arena ?? capture.after.arena
    assert(template)
    db._resizeTermContentMetadataArena(template.denseCapacity, template.slotCapacity)
    const cacheBatches = new Map(capture.cacheBatches.map(({id, byteLength}) => [id, new Uint8Array(byteLength)]))
    for (const entry of capture.cacheReads.values()) {
        if (!entry.missing) cacheBatches.get(entry.batchId).set(entry.bytes, entry.offset)
    }
    const originalRecent = db._findRecentTermContentSource.bind(db)
    db._findRecentTermContentSource = (meta) => {
        const expected = capture.cacheReads.get(meta.tableIndex)
        assert(expected, `Uncaptured recent-cache lookup for metadata ${meta.tableIndex}`)
        const result = originalRecent(meta)
        if (expected.missing) assert.equal(result, undefined)
        else {
            assert(result)
            assert.equal(result.offset, expected.offset)
            assert.equal(result.length, expected.length)
        }
        return result
    }
    db._readTermEntryContentBytesDetailedBatch = async () => { throw new Error('Replay attempted uncaptured persistent storage read') }
    return {db, capture, cacheBatches}
}

export function resetReplayState(state) {
    const {db, capture, cacheBatches} = state
    const before = capture.before
    for (const field of Object.values(arenaColumns)) {
        const target = db._termContentMetadataArena[field]
        target.fill(0)
        if (before.arena) target.set(before.arena.columns[field])
    }
    for (const [key, value] of Object.entries(before.properties)) {
        if (ArrayBuffer.isView(value) && ArrayBuffer.isView(db[key]) && db[key].constructor === value.constructor && db[key].length >= value.length) {
            db[key].fill(0)
            db[key].set(value)
        } else db[key] = clone(value)
    }
    if (before.arena === null) db._termEntryContentMetaHashPairMask = db._termContentMetadataArena.slots.length - 1
    db._recentTermContentSourceBatches = cacheBatches
    db._inFlightTermContentSourceBatches.clear()
    const chunk = {...capture.input, contentDedupPlan: clone(capture.input.contentDedupPlan)}
    return chunk
}

export function verifyReplayResult(state, result) {
    assert.deepEqual(normalizeResult(result), state.capture.oracle)
    assert.deepEqual(metadataIdentity(snapshotMetadata(state.db, false)), state.capture.after)
}
