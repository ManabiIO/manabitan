import {parentPort, workerData} from 'node:worker_threads'
import {readFile, writeFile} from 'node:fs/promises'
import {fileURLToPath} from 'node:url'

globalThis.self = globalThis
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: workerData.navigator})
const nativeFetch = globalThis.fetch
globalThis.fetch = async (url, options) => {
    const resolved = new URL(typeof url === 'string' ? url : url.url ?? url.href)
    if (resolved.protocol !== 'file:') return await nativeFetch(url, options)
    return new Response(await readFile(fileURLToPath(resolved)), {headers: {'Content-Type': resolved.pathname.endsWith('.wasm') ? 'application/wasm' : 'application/octet-stream'}})
}

let session = null
const post = async (method, params = {}) => await new Promise((resolve, reject) => session.post(method, params, (error, result) => error ? reject(error) : resolve(result)))
if (workerData.profilePath) {
    const {Session} = await import('node:inspector')
    session = new Session()
    session.connect()
    await post('Profiler.enable')
    await post('Profiler.setSamplingInterval', {interval: 200})
    await post('Profiler.start')
}
globalThis.addEventListener = (type, listener) => {
    if (type === 'message') parentPort.on('message', (data) => {
        if (data?.b566ProfilerStop !== true) listener({data})
    })
}
globalThis.postMessage = (message, transfer) => parentPort.postMessage(
    workerData.traceEvents ? {b566WorkerSentUs: Number(process.hrtime.bigint() / 1000n), message} : message,
    transfer,
)
parentPort.on('message', async (data) => {
    if (data?.b566ProfilerStop !== true) return
    if (session) {
        const {profile} = await post('Profiler.stop')
        await writeFile(workerData.profilePath, JSON.stringify(profile))
        session.disconnect()
    }
    parentPort.postMessage({b566ProfilerStopped: true})
})
await import(workerData.url)
