import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {createReplayState, resetReplayState, normalizeResult, snapshotMetadata, metadataIdentity} from './dedup-snapshot.mjs'

export function mixedHash(first, second) {
    const value = (first ^ Math.imul(second, 0x9e3779b1)) >>> 0
    return (value ^ (value >>> 16)) >>> 0
}

function expectedIndexMask(capacity) {
    return capacity === 0 ? 0xffffffff : 0xffffffff >>> Math.clz32(capacity)
}

export function normalizeAndValidateSlots(arena, denseCount) {
    const mask = arena.slotIndexMask ?? 0xffffffff
    if (typeof arena.slotIndexMask === 'number') assert.equal(mask, expectedIndexMask(arena.state.length))
    const normalized = new Uint32Array(arena.slots.length)
    let liveSlots = 0
    let taggedSlots = 0
    for (let slot = 0; slot < arena.slots.length; slot++) {
        const stored = arena.slots[slot]
        if (stored === 0) continue
        const id = (stored & mask) >>> 0
        assert(id > 0 && id <= arena.state.length && id <= denseCount, `Invalid packed slot ID ${id}`)
        assert.notEqual(arena.state[id - 1], 0, 'Occupied slots must refer to active metadata')
        const tag = (stored & ~mask) >>> 0
        assert.equal(tag, (mixedHash(arena.hash1[id - 1], arena.hash2[id - 1]) & ~mask) >>> 0,
            `Cached tag differs from authoritative hashes at slot ${slot}`)
        normalized[slot] = id
        liveSlots++
        if (tag !== 0) taggedSlots++
    }
    return {normalized, summary: {slotIndexMask: mask, denseCapacity: arena.state.length,
        denseCount, slotCapacity: arena.slots.length, liveSlots, taggedSlots,
        normalizedSlotsSha256: createHash('sha256').update(new Uint8Array(normalized.buffer)).digest('hex')}}
}

export function createTaggedReplayState(db, capture, tagged) {
    const state = createReplayState(db, capture)
    state.originalCapture = capture
    state.tagged = tagged
    const arena = db._termContentMetadataArena
    state.preparedSlotIndexMask = arena.slotIndexMask ?? 0xffffffff
    state.preparedDenseCapacity = arena.state.length
    state.preparedSlotCapacity = arena.slots.length
    if (tagged) {
        assert.equal(typeof arena.slotIndexMask, 'number', 'Candidate must use its real packed-slot arena')
        assert.equal(arena.slotIndexMask, expectedIndexMask(arena.state.length))
        const before = capture.before
        if (before.arena !== null) {
            const columns = before.arena.columns
            const slots = columns.slots.slice()
            for (let slot = 0; slot < slots.length; slot++) {
                const id = slots[slot]
                if (id === 0) continue
                assert(id <= arena.slotIndexMask && id <= columns.state.length)
                slots[slot] = (id | (mixedHash(columns.hash1[id - 1], columns.hash2[id - 1]) & ~arena.slotIndexMask)) >>> 0
            }
            // Convert the legacy capture once, outside timing. Each replay now
            // restores an already-packed table using the same copies as base.
            state.capture = {...capture, before: {...before, arena: {...before.arena,
                columns: {...columns, slots}}}}
        }
    } else {
        assert.equal(state.preparedSlotIndexMask, 0xffffffff, 'Reference must retain the original slot format')
    }
    return state
}

export function resetTaggedReplayState(state) {
    const arena = state.db._termContentMetadataArena
    assert.equal(arena.slotIndexMask ?? 0xffffffff, state.preparedSlotIndexMask, 'Replay arena mask changed')
    assert.equal(arena.state.length, state.preparedDenseCapacity, 'Replay arena dense capacity changed')
    assert.equal(arena.slots.length, state.preparedSlotCapacity, 'Replay arena slot capacity changed')
    return resetReplayState(state)
}

export function verifyTaggedReplayResult(state, result) {
    assert.deepEqual(normalizeResult(result), state.originalCapture.oracle, 'Every resolved/pending field and native route metric must match')
    const metadata = snapshotMetadata(state.db, false)
    const {normalized, summary} = normalizeAndValidateSlots(state.db._termContentMetadataArena, state.db._termEntryContentMetaDenseCount)
    metadata.arena.columns.slots = normalized
    assert.deepEqual(metadataIdentity(metadata), state.originalCapture.after, 'All authoritative metadata must match after decoding slots')
    return summary
}
