import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {createReadStream, openAsBlob} from 'node:fs'
import {mkdir, readFile, writeFile} from 'node:fs/promises'
import {join, resolve} from 'node:path'
import {pathToFileURL, fileURLToPath} from 'node:url'
import {Worker as ThreadWorker} from 'node:worker_threads'
import {execFileSync} from 'node:child_process'
import {normalizeAndValidateSlots} from './dedup-tag-state.mjs'

const [rootPath, cachePath, outputPath, dictionary = 'jmdict', ...switches] = process.argv.slice(2)
assert(rootPath && cachePath && outputPath, 'Expected source root, fixture cache, output directory, dictionary')
const root = resolve(rootPath)
const output = resolve(outputPath)
await mkdir(output, {recursive: true})
const profileEnabled = switches.includes('--profile')
const prewarmCanonical = switches.includes('--prewarm-canonical')
const productionCatalog = switches.includes('--production-catalog')
const traceWorkerEvents = switches.includes('--worker-events')
const successorCountersOnly = switches.includes('--successor-counters-only')
const flagsPath = switches.find((argument) => argument.startsWith('--flags='))?.slice(8)
const captureDedupPath = switches.find((argument) => argument.startsWith('--capture-dedup='))?.slice(16)
const flags = flagsPath ? JSON.parse(await readFile(flagsPath, 'utf8')) : {}
const navigatorPolicy = {hardwareConcurrency: 4, deviceMemory: 8}
const localImport = (filename) => import(pathToFileURL(join(root, filename)))
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const hrtimeUs = () => Number(process.hrtime.bigint() / 1000n)
const phases = []
const phase = (name) => phases.push({name, us: hrtimeUs()})
const nativeFetch = globalThis.fetch
globalThis.fetch = async (url, options) => {
    const resolved = new URL(typeof url === 'string' ? url : url.url ?? url.href)
    if (resolved.protocol !== 'file:') return await nativeFetch(url, options)
    return new Response(await readFile(fileURLToPath(resolved)), {headers: {'Content-Type': resolved.pathname.endsWith('.wasm') ? 'application/wasm' : 'application/octet-stream'}})
}
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: navigatorPolicy})

const workers = []
const terminations = []
const sourceGroups = []
const workerEvents = []
let activeSinkGroup = -1
class BrowserWorker extends EventTarget {
    constructor(url) {
        super()
        this.id = workers.length + 1
        this.module = url.pathname.split('/').at(-1)
        this.termination = null
        this.worker = new ThreadWorker(new URL('./worker-bootstrap.mjs', import.meta.url), {
            workerData: {url: url.href, navigator: navigatorPolicy, profilePath: profileEnabled ? join(output, `worker-${this.id}.cpuprofile`) : null, traceEvents: traceWorkerEvents},
        })
        this.worker.on('message', (data) => {
            if (data?.b566WorkerSentUs) {
                const message = data.message
                workerEvents.push({worker: this.id, module: this.module, direction: 'fromWorker', sentUs: data.b566WorkerSentUs, receivedUs: hrtimeUs(), id: message.id ?? null, type: message.type ?? (message.compressed instanceof ArrayBuffer ? 'compressed' : message.error ? 'error' : 'other')})
                data = message
            }
            if (data?.b566ProfilerStopped === true) this.profileStopped?.()
            else this.dispatchEvent(new MessageEvent('message', {data}))
        })
        this.worker.on('error', (error) => {
            const event = new Event('error')
            Object.defineProperty(event, 'message', {value: error.message})
            this.dispatchEvent(event)
        })
        this.worker.on('messageerror', () => this.dispatchEvent(new MessageEvent('messageerror')))
        workers.push(this)
    }

    postMessage(data, transfer) {
        if (data.type === 'parse') sourceGroups.push({worker: this.id, id: data.id, files: data.sourceMetadata?.map(({filename}) => filename) ?? null, bytes: data.sourceBuffers?.map((buffer) => buffer.byteLength) ?? []})
        if (traceWorkerEvents && this.module === 'zstd-term-content-compression-worker.js' && typeof data.id === 'number') workerEvents.push({worker: this.id, module: this.module, direction: 'toWorker', sentUs: hrtimeUs(), id: data.id, group: activeSinkGroup, type: 'compress'})
        this.worker.postMessage(data, transfer)
    }

    terminate() {
        if (this.termination) return
        this.termination = (async () => {
            if (profileEnabled) await new Promise((resolve) => {
                this.profileStopped = resolve
                this.worker.postMessage({b566ProfilerStop: true})
            })
            await this.worker.terminate()
        })()
        terminations.push(this.termination)
    }
}
globalThis.Worker = BrowserWorker

const lockBytes = await readFile(join(root, 'test/perf/dictionaries.lock.json'))
const fixture = JSON.parse(lockBytes).dictionaries[dictionary]
assert(fixture, `Unknown fixture ${dictionary}`)
const archivePath = join(resolve(cachePath), fixture.cacheFile)
const archiveHash = createHash('sha256')
for await (const bytes of createReadStream(archivePath)) archiveHash.update(bytes)
assert.equal(archiveHash.digest('hex'), fixture.sha256)
const archive = await openAsBlob(archivePath)
assert.equal(archive.size, fixture.sizeBytes)
const sourceFiles = [
    'ext/js/dictionary/dictionary-database.js',
    'ext/js/dictionary/dictionary-importer.js',
    'ext/js/dictionary/dense-zip-directory.js',
    'ext/js/dictionary/dense-zip-file-map.js',
    'ext/js/dictionary/dense-zip-filenames.js',
    'ext/js/dictionary/term-content-canonical-scan.js',
    'ext/js/dictionary/term-content-metadata-arena.js',
    'ext/js/dictionary/term-content-block-store.js',
    'ext/js/dictionary/term-content-opfs-store.js',
    'ext/js/dictionary/term-record-opfs-store.js',
    'ext/js/dictionary/term-bank-wasm-parser.js',
    'ext/js/dictionary/term-bank-source-pipeline.js',
    'ext/js/dictionary/term-bank-wasm-parser-worker.js',
    'ext/js/dictionary/term-bank-experiments.js',
    'ext/js/dictionary/zstd-term-content.js',
    'ext/js/dictionary/zstd-term-content-compression-worker.js',
    'ext/lib/term-bank-parser.wasm',
    'ext/lib/term-content-canonical-scan-v1.wasm',
    'ext/lib/zstd.wasm',
    'ext/lib/zstd-wasm.js',
    'package-lock.json',
]
const sourceHashes = {}
for (const name of sourceFiles) sourceHashes[name] = sha(await readFile(join(root, name)))
const harnessSha256 = sha(await readFile(fileURLToPath(import.meta.url)))
const workerBootstrapSha256 = sha(await readFile(new URL('./worker-bootstrap.mjs', import.meta.url)))
const tagHelperSha256 = sha(await readFile(new URL('./dedup-tag-state.mjs', import.meta.url)))
const snapshotHelperSha256 = sha(await readFile(new URL('./dedup-snapshot.mjs', import.meta.url)))
const sourceCommit = execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim()
const sourceStatus = execFileSync('git', ['status', '--porcelain', '--untracked-files=no'], {cwd: root, encoding: 'utf8'}).trim()

phase('setupStart')
const {BlobReader, Uint8ArrayWriter, ZipReader} = await localImport('node_modules/@zip.js/zip.js/index.js')
const parser = await localImport('ext/js/dictionary/term-bank-wasm-parser.js')
const pipelineModule = await localImport('ext/js/dictionary/term-bank-source-pipeline.js')
const {DictionaryDatabase} = await localImport('ext/js/dictionary/dictionary-database.js')
const {RAW_TERM_CONTENT_TOKEN_DICT_NAME} = await localImport('ext/js/dictionary/raw-term-content.js')
const {initializeTermContentZstd} = await localImport('ext/js/dictionary/zstd-term-content.js')
const {snapshotTermBankExperiments} = await localImport('ext/js/dictionary/term-bank-experiments.js')
phase('parserCompileStart')
parser.setTermBankWasmModule(await WebAssembly.compile(await readFile(join(root, 'ext/lib/term-bank-parser.wasm'))))
phase('parserCompileEnd')
phase('zstdInitializeStart')
await initializeTermContentZstd()
phase('zstdInitializeEnd')
if (prewarmCanonical) {
    const {compileCanonicalScanModule} = await localImport('ext/js/dictionary/term-content-canonical-scan.js')
    phase('canonicalPrewarmStart')
    await compileCanonicalScanModule()
    phase('canonicalPrewarmEnd')
}

let reader
let termFiles
let sourceCatalog = 'zip.js'
if (productionCatalog) {
    const {DictionaryImporter} = await localImport('ext/js/dictionary/dictionary-importer.js')
    const importer = new DictionaryImporter(null)
    const catalog = await importer._getFilesFromArchive(archive)
    reader = catalog.zipReader
    sourceCatalog = catalog.catalog
    termFiles = []
    for (const filename of catalog.fileMap.keys()) {
        if (/^term_bank_\d+\.json$/.test(filename)) termFiles.push(catalog.fileMap.get(filename))
    }
} else {
    reader = new ZipReader(new BlobReader(archive))
    termFiles = (await reader.getEntries()).filter(({filename}) => /^term_bank_\d+\.json$/.test(filename))
}
termFiles.sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
const sourceBytes = termFiles.reduce((total, entry) => total + entry.uncompressedSize, 0)
const rawReader = new pipelineModule.RawZipPayloadReader(archive)
const sourcePipeline = new pipelineModule.TermBankSourcePipeline({
    termFiles,
    enabled: true,
    read: async (file) => await file.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}),
    readCompressed: async (file, signal) => await rawReader.read(file, signal),
})
const db = new DictionaryDatabase()
db.setImportOptimizationFlags({...flags, termContentStorageMode: 'raw-bytes', rawTermBankSourceBytes: sourceBytes, expectedTermContentImportBytes: sourceBytes, expectedTermRecordImportBytes: sourceBytes, queueTermContentWrites: true})
db._bulkImportTransactionOpen = true
db._deferTermsVirtualTableSync = true
db._termContentZstdInitialized = true
await db._termContentStore.beginImportSession()
db._termContentBlockImportSession = db._termContentBlockStore.beginImportSession()
const canonicalLoads = []
const canonicalSegments = []
if (profileEnabled) {
    const originalLoad = db._nativeCanonicalScanner._loadModule
    db._nativeCanonicalScanner._loadModule = async () => {
        const start = hrtimeUs()
        try { return await originalLoad() } finally { canonicalLoads.push({startUs: start, endUs: hrtimeUs()}) }
    }
    db._nativeCanonicalScanner._hooks = {
        beforeNative: ({a, beforeDense, beforePending}) => {
            canonicalSegments.push({group: groups.length, startUs: hrtimeUs(), beforeDense, beforePending, arenaBytes: a.memory.buffer.byteLength})
        },
        beforeOutputView: ({header, column}) => {
            if (column !== 0) return
            Object.assign(canonicalSegments.at(-1), {endUs: hrtimeUs(), header: Array.from(header)})
        },
    }
}
const recordOutputs = []
let recordRows = 0
const originalRecordAppend = db._termRecordStore.appendBatchFromArtifactChunkResolvedContent.bind(db._termRecordStore)
db._termRecordStore._getOrCreateShardState = async () => ({})
db._termRecordStore._importSessionActive = true
db._termRecordStore._deferIndexBuild = true
db._termRecordStore._appendEncodedChunk = async (...args) => {
    recordOutputs.push({firstId: args[1], rows: args[2], name: args[3], base: args[4], index: args[5].slice(), fields: args[6].slice(), format: args[7]})
}
db._termRecordStore.appendBatchFromArtifactChunkResolvedContent = async (chunk, offsets, lengths, names) => {
    const name = Array.isArray(names) ? names[0] : names
    assert.equal(typeof name, 'string')
    if (Array.isArray(names) && !names.every((value) => value === name)) {
        db._termRecordStore._nextId = recordRows + 1
        const metrics = await originalRecordAppend(chunk, offsets, lengths, names)
        recordRows += chunk.rowCount
        return metrics
    }
    const metrics = await db._termRecordStore._encodeAndAppendArtifactChunkForState({}, chunk, recordRows + 1, offsets, lengths, chunk.termRecordPreinternedPlan, name, chunk.preparedLookupIndexes)
    recordRows += chunk.rowCount
    return {buildRecordsMs: 0, ...metrics}
}

const groups = []
const capturedDedup = captureDedupPath ? (await import('./dedup-snapshot.mjs')).installDedupCapture(db, resolve(captureDedupPath), [0, 5, 11], () => groups.length) : null
const successorDiagnostics = {peekRequests: 0, ready: 0, mediaExcluded: 0, preparationCalls: 0, preparationStarts: 0, consumed: 0, discarded: 0, preparationErrors: 0, events: []}
if ((flags.experimentalContentDedupPreresolve === true || successorCountersOnly) && typeof db._preresolveNextArtifactTermContent === 'function') {
    const originalPrepare = db._preresolveNextArtifactTermContent.bind(db)
    db._preresolveNextArtifactTermContent = async (chunk) => {
        successorDiagnostics.preparationCalls++
        const startUs = successorCountersOnly ? 0 : hrtimeUs()
        await originalPrepare(chunk)
        const endUs = successorCountersOnly ? 0 : hrtimeUs()
        const prepared = db._preresolvedArtifactTermContent
        if (prepared !== null) {
            successorDiagnostics.preparationStarts++
            if (prepared.error !== null) successorDiagnostics.preparationErrors++
            if (!successorCountersOnly) successorDiagnostics.events.push({event: 'prepared', currentGroup: groups.length, rows: prepared.chunk.rowCount, startUs, endUs, elapsedMs: prepared.elapsedMs, pending: prepared.result?.pendingContentCount ?? null, persistedHits: prepared.result?.persistedHitCount ?? null, error: prepared.error === null ? null : String(prepared.error)})
        }
    }
    const originalTake = db._takePreresolvedArtifactTermContent.bind(db)
    db._takePreresolvedArtifactTermContent = (chunk) => {
        const result = originalTake(chunk)
        if (result !== null) successorDiagnostics.consumed++
        return result
    }
    const originalDiscard = db._discardPreresolvedArtifactTermContent.bind(db)
    db._discardPreresolvedArtifactTermContent = () => {
        if (db._preresolvedArtifactTermContent !== null) successorDiagnostics.discarded++
        return originalDiscard()
    }
}
const profiles = []
const samples = []
let rows = 0
let sinkMs = 0
async function consume(chunk, progress) {
    const picks = [0, Math.floor(chunk.rowCount / 2), chunk.rowCount - 1]
    const pendingSamples = picks.map((row) => {
        const unique = chunk.contentUniqueIndexList[row]
        const meta = (chunk.contentMetaByUniqueIndex ? unique : row) * 4
        const start = chunk.contentBytesBaseOffset + chunk.contentMetaList[meta]
        const length = chunk.contentMetaList[meta + 1]
        return {unique, bytes: chunk.contentBytesBuffer.slice(start, start + length)}
    })
    const wrap = (raw) => ({...raw, dictionary: fixture.expectedTitle, dictionaryTotalRows: progress.totalRows, contentDictNameList: null, uniformContentDictName: RAW_TERM_CONTENT_TOKEN_DICT_NAME})
    const input = wrap(chunk)
    if (flags.experimentalContentDedupPreresolve === true) {
        input.peekNextReadyArtifactChunk = () => {
            successorDiagnostics.peekRequests++
            const next = chunk.peekNextReadyColumnChunk?.()
            if (!next) return null
            successorDiagnostics.ready++
            const admitted = next.mediaRows.length === 0
            if (!admitted) successorDiagnostics.mediaExcluded++
            if (!successorCountersOnly) successorDiagnostics.events.push({event: 'peek', currentGroup: groups.length, rows: next.rowCount, uniqueRows: next.contentDedupPlan?.uniqueCount, rowMetadata: next.contentMetaByUniqueIndex !== true, resolutionDeferred: next.contentDedupPlan?.resolutionDeferred === true, borrowed: typeof next.releaseBorrowedContent === 'function', mediaRows: next.mediaRows.length})
            return admitted ? wrap(next) : null
        }
    }
    const startUs = hrtimeUs()
    const start = performance.now()
    activeSinkGroup = groups.length
    await db._bulkAddArtifactTermsChunkWithContentDedup(input)
    activeSinkGroup = -1
    const elapsed = performance.now() - start
    const endUs = hrtimeUs()
    sinkMs += elapsed
    for (const sample of pendingSamples) {
        const plan = input.contentDedupPlan
        samples.push({...sample, offset: plan.resolvedOffsets[sample.unique], length: plan.resolvedLengths[sample.unique], name: plan.resolvedDictNames?.[sample.unique] ?? plan.resolvedUniformDictName})
    }
    rows += chunk.rowCount
    groups.push({index: groups.length, rows: chunk.rowCount, uniqueRows: chunk.contentDedupPlan?.uniqueCount, contentMetaByUniqueIndex: chunk.contentMetaByUniqueIndex === true, contentMetaWords: chunk.contentMetaList.length, borrowed: typeof chunk.releaseBorrowedContent === 'function', cumulativeRows: rows, dictionaryTotalRows: progress.totalRows, sinkMs: elapsed, startUs, endUs, metrics: {...db.getLastBulkAddTermsMetrics()}})
}

const options = {...flags, emitTermByteLists: false, computeContentHashes: true, emitContentSlab: true, emitTokenBinaryContent: true, mediaHintFastScan: fixture.mediaFiles > 0, projectImagePaths: fixture.mediaFiles > 0, validateGlossaryTypes: true, prepareLookupIndexes: true, maxPendingChunks: 2}
let inspectorSession = null
const inspectorPost = async (method, params = {}) => await new Promise((resolve, reject) => inspectorSession.post(method, params, (error, result) => error ? reject(error) : resolve(result)))
if (profileEnabled) {
    const {Session} = await import('node:inspector')
    inspectorSession = new Session()
    inspectorSession.connect()
    await inspectorPost('Profiler.enable')
    await inspectorPost('Profiler.setSamplingInterval', {interval: 200})
    await inspectorPost('Profiler.start')
}
phase('replayStart')
const cpuBefore = process.cpuUsage()
const mainThreadCpuBefore = typeof process.threadCpuUsage === 'function' ? process.threadCpuUsage() : null
const replayStart = performance.now()
let replayMs = null
let cpuUse = null
let mainThreadCpuUse = null
let replayMaxRssKiB = null
let complete = false
let failure = null
try {
    for (let start = 0; start < termFiles.length;) {
        const compressedPlan = sourcePipeline.createCompressedImportRunPlan(start)
        if (compressedPlan !== null) {
            assert.equal(await parser.parseTermBankWithWasmColumnChunksParallelCompressedLazy(compressedPlan.loaders, compressedPlan.estimatedByteLengths, 3, consume, options), true)
            profiles.push(parser.consumeLastTermBankWasmParseProfile())
            sourcePipeline.releaseBatch(compressedPlan.files)
            start += compressedPlan.files.length
        } else {
            const files = sourcePipeline.getBatch(start)
            const batch = await sourcePipeline.readBatch(files)
            if (batch?.promises) assert.equal(await parser.parseTermBankWithWasmColumnChunksParallelDeferred(batch.promises, batch.estimatedByteLengths, 3, consume, options), true)
            else await parser.parseTermBankWithWasmColumnChunks(batch, 3, consume, 2048, {...options, singleChunk: true})
            profiles.push(parser.consumeLastTermBankWasmParseProfile())
            sourcePipeline.releaseBatch(files)
            start += files.length
        }
    }
    replayMs = performance.now() - replayStart
    cpuUse = process.cpuUsage(cpuBefore)
    mainThreadCpuUse = mainThreadCpuBefore === null ? null : process.threadCpuUsage(mainThreadCpuBefore)
    replayMaxRssKiB = process.resourceUsage().maxRSS
    phase('replayEnd')
    assert.equal(rows, fixture.termRows)
    assert.equal(recordRows, fixture.termRows)
    complete = true
} catch (error) {
    replayMs = performance.now() - replayStart
    cpuUse = process.cpuUsage(cpuBefore)
    mainThreadCpuUse = mainThreadCpuBefore === null ? null : process.threadCpuUsage(mainThreadCpuBefore)
    replayMaxRssKiB = process.resourceUsage().maxRSS
    phase('replayError')
    failure = String(error?.stack ?? error)
} finally {
    if (inspectorSession) {
        const {profile} = await inspectorPost('Profiler.stop')
        await writeFile(join(output, 'main.cpuprofile'), JSON.stringify(profile), {flag: 'wx'})
        inspectorSession.disconnect()
    }
    await sourcePipeline.dispose()
    await parser.disposeParallelTermBankParser()
    for (const worker of workers) worker.terminate()
    await Promise.all(terminations)
    await reader.close()
}

const recordHash = createHash('sha256')
const recordDescriptorHash = createHash('sha256')
let recordBytes = 0
for (const {index, fields, ...descriptor} of recordOutputs) {
    recordHash.update(index)
    recordHash.update(fields)
    recordDescriptorHash.update(JSON.stringify({...descriptor, indexBytes: index.byteLength, fieldBytes: fields.byteLength}))
    recordBytes += index.byteLength + fields.byteLength
}
const contentHash = createHash('sha256')
for (const bytes of db._termContentStore._chunks) contentHash.update(bytes)
let samplesPassed = 0
for (const sample of samples) {
    const actual = await db._termContentBlockStore.read(sample.offset, sample.length, sample.name)
    try { assert.deepEqual(actual, sample.bytes) } catch (error) {
        complete = false
        failure ??= `Content sample mismatch: ${String(error)}`
        break
    }
    samplesPassed++
}
const totals = {}
for (const {metrics} of groups) for (const [key, value] of Object.entries(metrics)) if (typeof value === 'number') totals[key] = (totals[key] ?? 0) + value
for (const name of sourceFiles) assert.equal(sha(await readFile(join(root, name))), sourceHashes[name], `Source changed during replay: ${name}`)
const slotTagState = normalizeAndValidateSlots(db._termContentMetadataArena, db._termEntryContentMetaDenseCount).summary
assert.equal(sha(await readFile(new URL('./dedup-tag-state.mjs', import.meta.url))), tagHelperSha256)
assert.equal(sha(await readFile(new URL('./dedup-snapshot.mjs', import.meta.url))), snapshotHelperSha256)
const report = {
    complete, failure, scope: 'Component replay: pinned ZIP through actual source planner, native parser workers, canonical dedup, four compression workers and record encoders. Content uses production memory fallback, record persistence is intercepted and copied. Excludes SQLite, OPFS, UI, media processing and import finalization. Not an end-to-end import benchmark.',
    timing: 'replayMs starts immediately before source-plan execution and ends after its final sink settles. ZIP metadata, module imports, parser compilation and Zstd initialization are outside timing; lazy canonical compilation and parser worker startup are inside. No explicit GC, hashing, readback, profile writes or progress I/O occurs inside replayMs. Samples and record copies are included identically in every cohort.',
    sourceRoot: root, sourceCommit, sourceStatus, sourceHashes, harnessSha256, workerBootstrapSha256, tagHelperSha256, snapshotHelperSha256, slotTagState,
    node: process.version, execPath: process.execPath, nodeSha256: sha(await readFile(process.execPath)), execArgv: process.execArgv, navigatorPolicy, dictionary, fixture, lockSha256: sha(lockBytes), sourceBytes,
    profileEnabled, prewarmCanonical, productionCatalog, sourceCatalog, traceWorkerEvents, successorCountersOnly, capturedDedup, experiments: snapshotTermBankExperiments(flags), options,
    rows, recordRows, replayMs, sinkMs, cpuUse, mainThreadCpuUse, replayMaxRssKiB, maxRssKiB: process.resourceUsage().maxRSS,
    recordBytes, contentBytes: db._termContentStore._length, recordByteSha256: recordHash.digest('hex'), recordDescriptorSha256: recordDescriptorHash.digest('hex'), contentByteSha256: contentHash.digest('hex'),
    samples: samples.length, samplesPassed, workerCount: workers.length, canonicalStats: db._nativeCanonicalScanner.stats,
    canonicalLoads, canonicalSegments, successorDiagnostics, workerEvents, phases, totals, groups, sourceGroups, profiles,
}
await writeFile(join(output, 'summary.json'), JSON.stringify(report, null, 2) + '\n', {flag: 'wx'})
console.log(JSON.stringify({complete, rows, replayMs, sinkMs, recordBytes, contentBytes: report.contentBytes, samplesPassed, recordByteSha256: report.recordByteSha256, contentByteSha256: report.contentByteSha256, failure}))
if (!complete) process.exitCode = 1
