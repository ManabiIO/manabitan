import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, writeFile, mkdir} from 'node:fs/promises'
import {join, resolve} from 'node:path'
import {fileURLToPath, pathToFileURL} from 'node:url'
import {deserialize} from 'node:v8'
import {gunzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
import {createTaggedReplayState, resetTaggedReplayState, verifyTaggedReplayResult} from './dedup-tag-state.mjs'

const [baselineArg, candidateArg, captureArg, outputArg, pairsArg = '12', repeatsArg = '32'] = process.argv.slice(2)
assert(baselineArg && candidateArg && captureArg && outputArg)
assert.equal(typeof process.threadCpuUsage, 'function')
const roots = {baseline: resolve(baselineArg), candidate: resolve(candidateArg)}
const output = resolve(outputArg)
const pairs = Number(pairsArg)
const repeats = Number(repeatsArg)
assert(Number.isInteger(pairs) && pairs > 0 && pairs <= 24)
assert(Number.isInteger(repeats) && repeats > 0 && repeats <= 64)
await mkdir(output, {recursive: true})
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: 4, deviceMemory: 8}})
const originalFetch = globalThis.fetch
globalThis.fetch = async (url, options) => {
    const value = new URL(typeof url === 'string' ? url : url.url ?? url.href)
    return value.protocol === 'file:' ? new Response(await readFile(fileURLToPath(value))) : originalFetch(url, options)
}
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const manifestBytes = await readFile(join(resolve(captureArg), 'captures.json'))
const captureManifest = JSON.parse(manifestBytes)
const captures = []
for (const entry of captureManifest) {
    const bytes = await readFile(join(resolve(captureArg), entry.filename))
    assert.equal(sha(bytes), entry.sha256)
    captures.push(deserialize(gunzipSync(bytes)))
}
assert.deepEqual(captures.map(({group}) => group), [0, 5, 11])
const sourceNames = ['ext/js/dictionary/dictionary-database.js', 'ext/js/dictionary/term-content-canonical-scan.js',
    'ext/js/dictionary/term-content-metadata-arena.js', 'ext/js/dictionary/wasm/term-content-canonical-scan-v1.c',
    'ext/lib/term-content-canonical-scan-v1.wasm', 'dev/data/dictionary-wasm/manifest.json']
const sourceIdentity = async (root) => ({root,
    commit: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim(),
    trackedStatus: execFileSync('git', ['status', '--porcelain', '--untracked-files=no'], {cwd: root, encoding: 'utf8'}).trim(),
    sourceHashes: Object.fromEntries(await Promise.all(sourceNames.map(async (name) => [name, sha(await readFile(join(root, name)))]))),
})
const variants = {}
for (const [name, root] of Object.entries(roots)) {
    const importLocal = (file) => import(pathToFileURL(join(root, file)))
    const {DictionaryDatabase} = await importLocal('ext/js/dictionary/dictionary-database.js')
    const {compileCanonicalScanModule} = await importLocal('ext/js/dictionary/term-content-canonical-scan.js')
    await compileCanonicalScanModule()
    variants[name] = {identity: await sourceIdentity(root),
        states: captures.map((capture) => createTaggedReplayState(new DictionaryDatabase(), capture, name === 'candidate'))}
}
const harnessSha256 = sha(await readFile(fileURLToPath(import.meta.url)))
const snapshotHelperSha256 = sha(await readFile(new URL('./dedup-snapshot.mjs', import.meta.url)))
const tagHelperSha256 = sha(await readFile(new URL('./dedup-tag-state.mjs', import.meta.url)))
const plan = {
    scope: 'Actual full DictionaryDatabase._resolveArtifactTermContentDedup on the original pinned JMdict group0/5/11 source and published-metadata captures. Real exact-byte matches use captured production recent-cache bytes and reject uncaptured reads. No compression, persistence, full-corpus or browser import timing claim.',
    timing: 'Long main-thread CPU and batch wall include fixed metadata/source-plan restoration plus actual resolver calls. Candidate snapshots are converted to their real slot format once before timing; each timed reset performs the same table/property copies as baseline. Resolver-only wall is accumulated separately. Full result and authoritative-metadata hashes run after each batch; every call checks pending/exact counts and native activation. Four single-call preflights per variant/group prove the full oracle before fixed timing. No explicit GC, retries, trimmed observations or adaptive cohort size.',
    memoryBoundary: 'Independent production database instances and fixed arenas per variant/group; captures and cache bytes are identical. Same-code controls reuse the baseline state. Entire first-source pipeline correctness is qualified separately because these component arenas and compiled modules are preallocated.',
    pairs, repeats, groups: captureManifest,
    identities: Object.fromEntries(Object.entries(variants).map(([name, {identity}]) => [name, identity])),
    harnessSha256, snapshotHelperSha256, tagHelperSha256, captureManifestSha256: sha(manifestBytes),
    node: process.version, nodeSha256: sha(await readFile(process.execPath)), execPath: process.execPath, execArgv: process.execArgv,
}
await writeFile(join(output, 'plan.json'), JSON.stringify(plan, null, 2) + '\n', {flag: 'wx'})
const observations = []
let complete = false
let failure = null
async function runBatch(variant, captureIndex, phase, pair, position, count = repeats) {
    const state = variants[variant].states[captureIndex]
    const expected = state.originalCapture.oracle
    let resolverWallMs = 0
    let canonicalWallMs = 0
    let exactWallMs = 0
    let result = null
    const nativeBefore = {...state.db._nativeCanonicalScanner.stats}
    const loadavgBefore = (await readFile('/proc/loadavg', 'utf8')).trim()
    const cpuBefore = process.threadCpuUsage()
    const started = performance.now()
    for (let repetition = 0; repetition < count; repetition++) {
        const chunk = resetTaggedReplayState(state)
        const resolverStarted = performance.now()
        result = await state.db._resolveArtifactTermContentDedup(chunk, true)
        resolverWallMs += performance.now() - resolverStarted
        canonicalWallMs += result.dedupCanonicalScanMs
        exactWallMs += result.dedupExactCompareMs
        assert.equal(result.pendingContentCount, expected.pendingContentCount)
        assert.equal(result.persistedHitCount, expected.persistedHitCount)
        assert.equal(result.exactFallbackCount, expected.exactFallbackCount)
        assert.equal(result.nativeScanMetrics.dedupNativeCallCount, expected.native.dedupNativeCallCount)
        assert.equal(result.nativeScanMetrics.dedupNativeFallbackCount, 0)
    }
    const resetAndResolverWallMs = performance.now() - started
    const cpu = process.threadCpuUsage(cpuBefore)
    const slots = verifyTaggedReplayResult(state, result)
    const native = Object.fromEntries(Object.entries(state.db._nativeCanonicalScanner.stats)
        .filter(([, value]) => typeof value === 'number').map(([key, value]) => [key, value - nativeBefore[key]]))
    assert.equal(native.fallbacks, 0)
    assert.equal(native.calls, count)
    const observation = {variant, group: state.originalCapture.group, phase, pair, position, repeats: count,
        resolverWallMs, canonicalWallMs, exactWallMs, resetAndResolverWallMs,
        resetAndResolverThreadCpuMs: (cpu.user + cpu.system) / 1000, cpu,
        pending: result.pendingContentCount, persistedHits: result.persistedHitCount,
        exact: result.exactFallbackCount, slots, native, fullOracleMatched: true,
        loadavgBefore, afterTimingMemory: process.memoryUsage(), maxRssKiB: process.resourceUsage().maxRSS}
    observations.push(observation)
    return observation
}
const save = async () => await writeFile(join(output, 'progress.json'),
    JSON.stringify({plan, complete, failure, observations}, null, 2) + '\n')
try {
    for (let group = 0; group < captures.length; group++) {
        for (let preflight = 0; preflight < 4; preflight++) {
            const order = preflight % 2 ? ['candidate', 'baseline'] : ['baseline', 'candidate']
            for (const [position, variant] of order.entries()) {
                await runBatch(variant, group, preflight === 0 ? 'firstObserved' : 'preflight', preflight, position, 1)
            }
        }
        await save()
    }
    for (let pair = 0; pair < pairs; pair++) {
        for (let step = 0; step < captures.length; step++) {
            const group = (step + pair) % captures.length
            const order = pair % 2 ? ['candidate', 'baseline'] : ['baseline', 'candidate']
            for (const [position, variant] of order.entries()) await runBatch(variant, group, 'paired', pair, position)
            if ((pair + 1) % 3 === 0) {
                await runBatch('baseline', group, 'sameCodeControl', pair, 0)
                await runBatch('baseline', group, 'sameCodeControl', pair, 1)
            }
        }
        await save()
        console.log(JSON.stringify({pairsCompleted: pair + 1, observations: observations.length, fullOraclesMatched: true}))
    }
    for (const [name, {identity}] of Object.entries(variants)) assert.deepEqual(await sourceIdentity(roots[name]), identity)
    assert.equal(sha(await readFile(fileURLToPath(import.meta.url))), harnessSha256)
    assert.equal(sha(await readFile(new URL('./dedup-snapshot.mjs', import.meta.url))), snapshotHelperSha256)
    assert.equal(sha(await readFile(new URL('./dedup-tag-state.mjs', import.meta.url))), tagHelperSha256)
    complete = true
} catch (error) {
    failure = String(error?.stack ?? error)
} finally {
    await save()
    await writeFile(join(output, 'summary.json'), JSON.stringify({plan, complete, failure, observations,
        maxRssKiB: process.resourceUsage().maxRSS}, null, 2) + '\n', {flag: 'wx'})
    console.log(JSON.stringify({complete, failure, observations: observations.length}))
    if (!complete) process.exitCode = 1
}
