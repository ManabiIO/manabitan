import hashlib
import json
import pathlib
import subprocess
import sys
import time

workspace = pathlib.Path('/workspace/scratch/b566a6f460b8')
source = workspace / 'manabitan-canonical-tags'
node = workspace / 'runtime/node22'
runner = workspace / 'evidence/component-tools/sink-replay-tags.mjs'
bootstrap = workspace / 'evidence/component-tools/worker-bootstrap.mjs'
out = pathlib.Path(sys.argv[1]).resolve()
expected_commit = 'ea3cb4418b0163e3c7b1b5b5e1ad43c72171823a'
expected_module = '6bd9fe86d20561b4725aaba6794184679d5fcdad71c90cdd8f8f0c720b2f9cff'
expected_parser = '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee'
out.mkdir(parents=True, exist_ok=True)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == expected_commit
assert hashlib.sha256((source / 'ext/lib/term-content-canonical-scan-v1.wasm').read_bytes()).hexdigest() == expected_module
assert hashlib.sha256((source / 'ext/lib/term-bank-parser.wasm').read_bytes()).hexdigest() == expected_parser
baselines = {
    'jmdict': workspace / 'evidence/calibration/aa-a1/summary.json',
    'jitendex': workspace / 'evidence/calibration/jitendex-correctness/summary.json',
    'vndb': workspace / 'evidence/calibration/vndb-dense-mixed-correctness/summary.json',
}
identity = {
    'sourceCommit': expected_commit,
    'canonicalWasmSha256': expected_module,
    'parserWasmSha256': expected_parser,
    'runnerSha256': hashlib.sha256(runner.read_bytes()).hexdigest(),
    'bootstrapSha256': hashlib.sha256(bootstrap.read_bytes()).hexdigest(),
    'driverSha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
}
plan = {'scope': 'All-three pinned-corpus source-to-sink component correctness replay. No timing comparison or complete browser import claim.',
        'identity': identity, 'baselineReports': {name: str(path) for name, path in baselines.items()},
        'order': list(baselines)}
with (out / 'plan.json').open('x') as stream:
    json.dump(plan, stream, indent=2)
attempts = []
failed = False
for dictionary, baseline_path in baselines.items():
    baseline = json.loads(baseline_path.read_text())
    assert baseline['complete']
    assert baseline['sourceCommit'] == '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
    run = out / dictionary
    run.mkdir(exist_ok=False)
    command = [str(node), '--max-old-space-size=512', str(runner), str(source),
               str(workspace / 'manabitan-base/builds/e2e-dictionary-cache'), str(run), dictionary, '--production-catalog']
    attempt = {'dictionary': dictionary, 'command': command, 'baselineReportSha256': hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
               'directory': str(run), 'loadavgBefore': pathlib.Path('/proc/loadavg').read_text().strip(), 'startedUnixSeconds': time.time()}
    start = time.monotonic()
    with (run / 'run.log').open('w') as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
    attempt.update({'exitCode': result.returncode, 'processWallSeconds': time.monotonic() - start})
    try:
        assert result.returncode == 0, f'Process exited {result.returncode}'
        report = json.loads((run / 'summary.json').read_text())
        assert report['complete'], report['failure']
        assert report['sourceCommit'] == expected_commit
        assert report['sourceHashes']['ext/lib/term-content-canonical-scan-v1.wasm'] == expected_module
        assert report['sourceHashes']['ext/lib/term-bank-parser.wasm'] == expected_parser
        assert report['harnessSha256'] == identity['runnerSha256']
        assert report['workerBootstrapSha256'] == identity['bootstrapSha256']
        assert report['fixture']['sha256'] == baseline['fixture']['sha256']
        fields = ['rows', 'recordRows', 'samples', 'samplesPassed', 'recordBytes', 'contentBytes',
                  'recordByteSha256', 'recordDescriptorSha256', 'contentByteSha256']
        for field in fields:
            assert report[field] == baseline[field], f'{dictionary}: {field} differs from develop'
        assert report['canonicalStats']['fallbacks'] == 0
        assert report['prewarmCanonical'] is False
        assert report['groups'][0]['metrics']['dedupNativeCallCount'] > 0
        assert report['groups'][0]['metrics']['dedupNativeFallbackCount'] == 0
        assert report['slotTagState']['taggedSlots'] > 0
        assert report['slotTagState']['slotIndexMask'] != 0xffffffff
        attempt.update({'verified': True, **{field: report[field] for field in fields},
                        'replayMaxRssKiB': report['replayMaxRssKiB'],
                        'sourceHashes': report['sourceHashes'], 'slotTagState': report['slotTagState'],
                        'firstGroupMetrics': report['groups'][0]['metrics'],
                        'canonicalStats': report['canonicalStats'],
                        'fusedParseAttempts': sum(profile['fusedParseAttempts'] for profile in report['profiles']),
                        'fusedParseFallbacks': sum(profile['fusedParseFallbacks'] for profile in report['profiles'])})
    except Exception as error:
        attempt.update({'verified': False, 'error': str(error)})
        failed = True
    attempts.append(attempt)
    (out / 'progress.json').write_text(json.dumps({'plan': plan, 'attempts': attempts, 'failed': failed}, indent=2) + '\n')
    print(json.dumps({'dictionary': dictionary, 'verified': attempt['verified'], 'rows': attempt.get('rows'), 'error': attempt.get('error')}), flush=True)
    if failed:
        break
summary = {'plan': plan, 'complete': not failed and len(attempts) == len(baselines), 'attempts': attempts}
(out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
raise SystemExit(0 if summary['complete'] else 1)
