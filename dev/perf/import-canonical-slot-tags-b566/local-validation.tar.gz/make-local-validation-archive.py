from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile


ROOT = Path('/workspace/scratch/b566a6f460b8')
EVIDENCE = ROOT / 'evidence/canonical-tags'
VALIDATION = EVIDENCE / 'validation'
CANDIDATE = 'ea3cb4418b0163e3c7b1b5b5e1ad43c72171823a'
BASELINE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_file(path):
    return json.loads(path.read_text())


def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()


def encode(value):
    return (json.dumps(value, indent=2) + '\n').encode()


checkpoint = json_file(EVIDENCE / 'production-checkpoint.json')
initial = json_file(VALIDATION / 'status.json')
followup = json_file(VALIDATION / 'followup-status.json')
split = json_file(VALIDATION / 'lint-split-status.json')
focused = json_file(VALIDATION / 'lint-changed-final-status.json')
assert initial['complete'] and followup['complete']
assert split['interrupted'] and focused['state'] != 'running'

identities = {}
for name, folder, expected in [
    ('candidate', 'manabitan-canonical-tags', CANDIDATE),
    ('baseline', 'manabitan-base', BASELINE),
]:
    tree = ROOT / folder
    head = git(tree, 'rev-parse', 'HEAD')
    assert head == expected
    paths = [
        *checkpoint['changedFileHashes'],
        'test/zstd-term-content-packed-dispatch.test.js',
        'ext/js/dictionary/zstd-term-content.js',
        'ext/js/dictionary/zstd-term-content-compression-worker.js',
        'ext/lib/zstd.wasm',
        'package-lock.json',
    ]
    hashes = {path: sha((tree / path).read_bytes()) for path in paths if (tree / path).is_file()}
    if name == 'candidate':
        for path, expected_hash in checkpoint['changedFileHashes'].items():
            assert hashes[path] == expected_hash, path
    identities[name] = {
        'head': head,
        'root': str(tree),
        'trackedStatusAtArchive': git(tree, 'status', '--porcelain', '--untracked-files=no'),
        'sha256': hashes,
    }

dependency_root = (ROOT / 'manabitan-canonical-tags/node_modules').resolve()
versions = {
    package: json_file(dependency_root / package / 'package.json')['version']
    for package in ['vitest', 'eslint', 'typescript', '@typescript-eslint/parser']
}
identities['environment'] = {
    'node': subprocess.check_output([str(ROOT / 'runtime/node22'), '--version'], text=True).strip(),
    'nodeSha256': sha((ROOT / 'runtime/node22').read_bytes()),
    'dependencyRoot': str(dependency_root),
    'dependencyVersions': versions,
    'nativeCompilerSetup': '/workspace/scratch/f34c9c9fae89/toolchains/llvm21-env.sh',
    'nativeCompilerVersion': '21.1.8',
}

summary = {
    'candidate': CANDIDATE,
    'baseline': BASELINE,
    'fullUnit': {
        'status': 'incomplete: process failed on one unexpected fork exit',
        'filesPassed': 669,
        'filesTotal': 670,
        'testsPassed': 15149,
        'testsSkipped': 47,
        'testsTotal': 15197,
        'missingSuite': 'test/zstd-term-content-packed-dispatch.test.js',
        'cause': 'No assertion failure or fatal-heap diagnostic established the cause.',
        'followup': 'The unchanged missing suite passed 13/13 on candidate and baseline; the original failed full-suite receipt remains authoritative.',
    },
    'build': 'passed: standard test:build dry run for all targets',
    'types': 'passed: main, dev, test and bench projects',
    'qualificationPython': 'passed: 32 tests',
    'fullLint': 'incomplete: original full run and multiple path groups received SIGKILL; the last path group was interrupted at the parent request',
    'finalChangedFileLint': 'incomplete: one attempt over the seven changed JavaScript files received SIGKILL without a rule diagnostic',
    'earlierFocusedLint': 'The earlier combined run found only new-test formatting/JSDoc issues; those were fixed, and the new-test lint passed separately. Full logs are retained rather than relabelled as one clean final full run.',
    'sourceChangesDuringValidation': 'none in the frozen production/test files; source hashes were rechecked before archiving',
    'remainingGate': 'Hosted ordinary CI must provide fresh full-unit and full-lint results.',
}

files = {
    'source-identities.json': encode(identities),
    'summary.json': encode(summary),
    'make-local-validation-archive.py': Path(__file__).read_bytes(),
}
for path in sorted(VALIDATION.iterdir()):
    if path.is_file():
        files['validation/' + path.name] = path.read_bytes()
for name in [
    'production-checkpoint.json',
    'production-validation-plan.json',
    'production-contract.md',
    'production-body-proof.json',
    'production-export-proof.json',
    'production-build.log',
    'production-focused.log',
    'production-final-focused.log',
    'production-eslint.log',
    'production-new-test-eslint.log',
]:
    files[name] = (EVIDENCE / name).read_bytes()

files['manifest.json'] = encode({
    'format': 1,
    'candidate': CANDIDATE,
    'baseline': BASELINE,
    'files': [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())],
})


def archive_bytes():
    output = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for name, data in sorted(files.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                archive.addfile(info, io.BytesIO(data))
    return output.getvalue()


data = archive_bytes()
assert data == archive_bytes(), 'Archive construction must be deterministic'
destination = EVIDENCE / 'local-validation-ea3cb4418b.tar.gz'
destination.write_bytes(data)
receipt = {'path': str(destination), 'bytes': len(data), 'sha256': sha(data), 'members': len(files)}
(EVIDENCE / 'local-validation-archive-receipt.json').write_bytes(encode(receipt))
print(json.dumps(receipt, indent=2))
