import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, writeFile, mkdir} from 'node:fs/promises'
import {join, resolve} from 'node:path'
import {fileURLToPath, pathToFileURL} from 'node:url'
import {deserialize} from 'node:v8'
import {gunzipSync} from 'node:zlib'
import {execFileSync} from 'node:child_process'
import {createReplayState, resetReplayState, verifyReplayResult} from '../component-tools/dedup-snapshot.mjs'

const [baseArg, candidateArg, captureArg, outputArg] = process.argv.slice(2)
assert(baseArg && candidateArg && captureArg && outputArg)
const roots = {baseline: resolve(baseArg), candidate: resolve(candidateArg)}
const captureDirectory = resolve(captureArg)
const output = resolve(outputArg)
await mkdir(output, {recursive: true})
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const mix = (first, second) => {
    const hash = (first ^ Math.imul(second, 0x9e3779b1)) >>> 0
    return (hash ^ (hash >>> 16)) >>> 0
}
const indexMaskFor = (capacity) => capacity === 0 ? 0xffffffff : 0xffffffff >>> Math.clz32(capacity)
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: 4, deviceMemory: 8}})
const originalFetch = globalThis.fetch
globalThis.fetch = async (url, options) => {
    const value = new URL(typeof url === 'string' ? url : url.url ?? url.href)
    return value.protocol === 'file:' ? new Response(await readFile(fileURLToPath(value))) : originalFetch(url, options)
}
const importBase = (name) => import(pathToFileURL(join(roots.baseline, name)))
const {DictionaryDatabase} = await importBase('ext/js/dictionary/dictionary-database.js')
const {compileCanonicalScanModule} = await importBase('ext/js/dictionary/term-content-canonical-scan.js')
const {CANONICAL_SCAN_LAYOUT: layout, CANONICAL_SCAN_MAX_ROWS: MAX_ROWS,
    CANONICAL_SCAN_EXACT_BATCH_SIZE: EXACT_BATCH_SIZE} = await importBase('ext/js/dictionary/term-content-canonical-layout.js')
const manifestBytes = await readFile(join(captureDirectory, 'captures.json'))
const manifest = JSON.parse(manifestBytes)
assert.deepEqual(manifest.map(({group}) => group), [0, 5, 11])
const moduleBytes = Object.fromEntries(await Promise.all(Object.entries(roots).map(async ([name, root]) =>
    [name, await readFile(join(root, 'ext/lib/term-content-canonical-scan-v1.wasm'))])))
const expectedModules = {
    baseline: '40948d5c20d26253e86c93d267e3cbb3817ea87c9731e02bcca0523c0eb3d6af',
    candidate: '6bd9fe86d20561b4725aaba6794184679d5fcdad71c90cdd8f8f0c720b2f9cff',
}
for (const name of Object.keys(roots)) assert.equal(sha(moduleBytes[name]), expectedModules[name])
const sourceFiles = ['ext/js/dictionary/wasm/term-content-canonical-scan-v1.c',
    'ext/js/dictionary/term-content-canonical-scan.js', 'ext/js/dictionary/term-content-metadata-arena.js',
    'ext/js/dictionary/dictionary-database.js', 'ext/js/dictionary/term-content-canonical-layout.js',
    'ext/lib/term-content-canonical-scan-v1.wasm', 'dev/data/dictionary-wasm/manifest.json']
const sourceIdentity = async (root) => ({root,
    commit: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim(),
    sourceHashes: Object.fromEntries(await Promise.all(sourceFiles.map(async (name) => [name, sha(await readFile(join(root, name)))]))),
})
const identities = Object.fromEntries(await Promise.all(Object.entries(roots).map(async ([name, root]) => [name, await sourceIdentity(root)])))
const harnessSha256 = sha(await readFile(fileURLToPath(import.meta.url)))
const snapshotHelperSha256 = sha(await readFile(new URL('../component-tools/dedup-snapshot.mjs', import.meta.url)))

function views(bytes) {
    assert.equal(bytes.byteOffset, 0)
    const u32 = (offset, length) => new Uint32Array(bytes.buffer, offset, length)
    const u8 = (offset, length) => new Uint8Array(bytes.buffer, offset, length)
    const c = u32(1088, 22)
    return {c, h: u32(1024, 7), slots: u32(c[0], c[1]), hash1: u32(c[2], c[10]), hash2: u32(c[3], c[10]),
        state: u8(c[4], c[10]), length: u32(c[5], c[10]), present: u8(c[6], c[10]),
        s1: u32(c[7], c[10]), s2: u32(c[8], c[10]), s3: u32(c[9], c[10]),
        meta: u32(layout.META, 4 * MAX_ROWS), identity: u32(layout.IDENT, MAX_ROWS),
        rows: u32(layout.ROWS, MAX_ROWS), sigs: u32(layout.SIGS, 3 * MAX_ROWS),
        flags: u8(layout.FLAGS, MAX_ROWS), out: u32(layout.OUT, 6 * MAX_ROWS),
        journal: u32(layout.JOURNAL, 3 * MAX_ROWS), exact: u32(layout.EXACT, 2 * EXACT_BATCH_SIZE)}
}

function packInitialSlots(bytes, mask) {
    const {slots, hash1, hash2, c} = views(bytes)
    assert.equal(mask, indexMaskFor(c[10]))
    for (let slot = 0; slot < slots.length; slot++) {
        const id = slots[slot]
        if (id === 0) continue
        assert(id <= c[10] && id <= mask)
        slots[slot] = (id | (mix(hash1[id - 1], hash2[id - 1]) & ~mask)) >>> 0
    }
}

function normalizeSlots(bytes, mask) {
    const copy = bytes.slice()
    const {slots, hash1, hash2, state, h, c} = views(copy)
    let liveSlots = 0
    for (let slot = 0; slot < slots.length; slot++) {
        const stored = slots[slot]
        if (stored === 0) continue
        const id = (stored & mask) >>> 0
        assert(id > 0 && id <= c[10] && id <= h[5])
        assert.notEqual(state[id - 1], 0)
        assert.equal((stored & ~mask) >>> 0, (mix(hash1[id - 1], hash2[id - 1]) & ~mask) >>> 0)
        slots[slot] = id
        liveSlots++
    }
    return {bytes: copy, liveSlots}
}

function assertOutputBytes(actual, expected) {
    assert.deepEqual(actual.subarray(1024, 1052), expected.subarray(1024, 1052), 'Complete native result header')
    assert.deepEqual(actual.subarray(1088, 1176), expected.subarray(1088, 1176), 'Complete read-only configuration')
    assert.deepEqual(actual.subarray(layout.META), expected.subarray(layout.META),
        'All input columns, pending output, exact descriptors, journal and authoritative metadata')
}

// Untimed port of scan_canonical's admitted-input control flow. Validation of
// these actual inputs is performed first by the unmodified native module.
// Counters inspect both full hashes for classification, including rejected
// slots. They are logical comparison counts, not hardware load counters.
function simulate(bytes, slotIndexMask) {
    const {c, h, slots, hash1, hash2, state, length, present, s1, s2, s3,
        meta, identity, rows, sigs, flags, out, journal, exact} = views(bytes)
    const mask = slotIndexMask || 0xffffffff
    const tagMask = ~mask
    const stats = {rowsVisited: 0, alreadyResolvedRows: 0, probedRows: 0,
        totalSlotVisits: 0, occupiedSlotProbes: 0, emptySlotTerminations: 0,
        wrongFullHashPairs: 0, matchingFullHashPairs: 0,
        tagRejections: 0, matchingTagFalsePositives: 0,
        firstHashChecks: 0, conditionalSecondHashChecks: 0,
        tagRejectedButFirstHashMatches: 0,
        publishedMatches: 0, insertedEntries: 0, pendingRows: 0}
    const path = createHash('sha256')
    const tuple = new Uint32Array(3)
    const tupleBytes = new Uint8Array(tuple.buffer)
    const recordProbe = (row, slot, id) => {
        tuple[0] = row
        tuple[1] = slot
        tuple[2] = id
        path.update(tupleBytes)
    }
    h[0] = h[2] = h[3] = h[4] = h[6] = 0
    h[1] = c[15]
    h[5] = c[11]
    assert.equal((mask & (mask + 1)) >>> 0, 0)
    assert(c[10] <= mask && c[12] <= MAX_ROWS && c[14] >= c[13])
    assert(c[14] - c[13] <= MAX_ROWS && c[15] <= c[14] - c[13])
    assert(c[1] > 0 && (c[1] & (c[1] - 1)) === 0 && c[11] <= c[10])
    assert.equal(c[21], 0, 'Real capture must not request a fault-injection trap')
    const n = c[14] - c[13]
    const bucketMask = c[1] - 1
    let returnCode = 0
    for (let i = c[15]; i < n; i++) {
        const unique = c[13] + i
        const global = rows[i]
        assert(global >= c[16] && global - c[16] < c[12])
        const row = global - c[16]
        assert.equal(identity[row], unique)
        h[1] = i + 1
        stats.rowsVisited++
        if (flags[i] === 1) {
            h[4]++
            stats.alreadyResolvedRows++
            continue
        }
        stats.probedRows++
        const m = row * 4
        const offset = c[17] + meta[m]
        assert(offset <= 0xffffffff && offset + meta[m + 1] <= c[18])
        const hash = mix(meta[m + 2], meta[m + 3])
        let slot = hash & bucketMask
        let probes = 0
        let existing = 0xffffffff
        let pair = false
        for (;;) {
            const stored = slots[slot]
            stats.totalSlotVisits++
            const id = (stored & mask) >>> 0
            recordProbe(i, slot, id)
            if (stored === 0) {
                stats.emptySlotTerminations++
                break
            }
            const index = (id - 1) >>> 0
            assert(index < c[10] && ++probes < c[1], 'Native index/probe guards precede tag rejection')
            stats.occupiedSlotProbes++
            const tagMatches = ((stored & tagMask) >>> 0) === ((hash & tagMask) >>> 0)
            const firstMatches = hash1[index] === meta[m + 2]
            const secondMatches = hash2[index] === meta[m + 3]
            const pairMatches = firstMatches && secondMatches
            if (pairMatches) stats.matchingFullHashPairs++
            else stats.wrongFullHashPairs++
            if (tagMatches) {
                stats.firstHashChecks++
                if (firstMatches) stats.conditionalSecondHashChecks++
                if (!pairMatches) stats.matchingTagFalsePositives++
            } else {
                stats.tagRejections++
                if (firstMatches) stats.tagRejectedButFirstHashMatches++
                assert(!pairMatches, 'A rejection tag must never reject a matching full hash pair')
            }
            if (tagMatches && pairMatches) {
                pair = true
                if (c[19] && state[index] === 1) {
                    existing = index
                    break
                }
            }
            slot = (slot + 1) & bucketMask
        }
        if (existing !== 0xffffffff) {
            const j = h[3]
            exact[j * 2] = i
            exact[j * 2 + 1] = existing
            h[3] = j + 1
            stats.publishedMatches++
            if (h[3] === EXACT_BATCH_SIZE) {
                returnCode = 1
                break
            }
            continue
        }
        let staged = 0xffffffff
        if (c[20] && !pair) {
            const index = h[5]
            assert(index < c[10] && state[index] === 0 && meta[m + 1] !== 0xffffffff)
            const j = h[0]
            journal[j * 3] = slot
            journal[j * 3 + 1] = slots[slot]
            journal[j * 3 + 2] = index
            h[0] = j + 1
            hash1[index] = meta[m + 2]
            hash2[index] = meta[m + 3]
            length[index] = meta[m + 1]
            s1[index] = sigs[i * 3]
            s2[index] = sigs[i * 3 + 1]
            s3[index] = sigs[i * 3 + 2]
            present[index] = 1
            state[index] = 2
            slots[slot] = ((index + 1) | (hash & tagMask)) >>> 0
            staged = index
            h[5] = index + 1
            stats.insertedEntries++
        }
        const j = h[2]++
        out[j] = offset
        out[MAX_ROWS + j] = meta[m + 1]
        out[2 * MAX_ROWS + j] = meta[m + 2]
        out[3 * MAX_ROWS + j] = meta[m + 3]
        out[4 * MAX_ROWS + j] = unique
        out[5 * MAX_ROWS + j] = staged
        stats.pendingRows++
    }
    assert.equal(stats.occupiedSlotProbes, stats.wrongFullHashPairs + stats.matchingFullHashPairs)
    assert.equal(stats.wrongFullHashPairs, stats.tagRejections + stats.matchingTagFalsePositives)
    assert.equal(stats.totalSlotVisits, stats.occupiedSlotProbes + stats.emptySlotTerminations)
    assert.equal(stats.firstHashChecks, stats.occupiedSlotProbes - stats.tagRejections)
    return {returnCode, stats, normalizedProbePathSha256: path.digest('hex')}
}

const plan = {
    scope: 'Untimed mechanism audit of actual pinned JMdict canonical slot probes for groups0/5/11. No new timing observations and no latency estimate.',
    method: 'Capture exact beforeNative/first-output memory from the original real-source resolver input. Run the unchanged production baseline and tagged modules. Independently simulate their admitted-input probe/insert control flow, compare all consumed input/output/authoritative bytes, and count/hash the normalized slot-visit sequence.',
    countMeaning: 'Logical source-level first-hash and conditional-second-hash comparisons. Classification intentionally inspects both hashes even on rejected slots. Counts are not observed hardware loads, cache misses, branch misses or CPU time. A mismatched first hash already skips the second check in baseline.',
    identities, moduleHashes: expectedModules, harnessSha256, snapshotHelperSha256,
    captureManifestSha256: sha(manifestBytes), captures: manifest,
    node: process.version, nodeSha256: sha(await readFile(process.execPath)), execArgv: process.execArgv,
    oracle: 'Complete header/config and every byte from META to end of memory; only independently validated slot tags may be normalized when comparing formats. Both actual modules must match the legacy reference. Simulation must additionally match its native module without normalization. Full original baseline resolver result/metadata oracle is mandatory.',
}
await writeFile(join(output, 'plan.json'), JSON.stringify(plan, null, 2) + '\n', {flag: 'wx'})
const observations = []
let complete = false
let failure = null
try {
    await compileCanonicalScanModule()
    const modules = Object.fromEntries(await Promise.all(Object.entries(moduleBytes).map(async ([name, bytes]) => [name, await WebAssembly.compile(bytes)])))
    for (const entry of manifest) {
        const bytes = await readFile(join(captureDirectory, entry.filename))
        assert.equal(sha(bytes), entry.sha256)
        const capture = deserialize(gunzipSync(bytes))
        const state = createReplayState(new DictionaryDatabase(), capture)
        const segments = []
        state.db._nativeCanonicalScanner._hooks.beforeNative = ({a}) => segments.push({before: new Uint8Array(a.memory.buffer).slice(), after: null})
        state.db._nativeCanonicalScanner._hooks.beforeOutputView = ({a, column}) => {
            if (column === 0) segments.at(-1).after = new Uint8Array(a.memory.buffer).slice()
        }
        const resolved = await state.db._resolveArtifactTermContentDedup(resetReplayState(state), true)
        verifyReplayResult(state, resolved)
        assert.equal(segments.length, 1)
        const raw = segments[0]
        assert(raw.after)
        const originalViews = views(raw.before)
        assert.equal(views(raw.after).h[1], originalViews.c[14] - originalViews.c[13])
        const packedMask = indexMaskFor(originalViews.c[10])
        const arms = {}
        for (const name of ['baseline', 'candidate']) {
            const mask = name === 'candidate' ? packedMask : 0xffffffff
            const initial = raw.before.slice()
            if (name === 'candidate') packInitialSlots(initial, mask)
            const memory = new WebAssembly.Memory({initial: initial.byteLength / 65536, maximum: initial.byteLength / 65536})
            const instance = new WebAssembly.Instance(modules[name], {env: {memory}})
            if (name === 'candidate') assert.equal(instance.exports.canonical_slot_tag_version(), 1)
            const native = new Uint8Array(memory.buffer)
            native.set(initial)
            const code = instance.exports.scan_canonical(name === 'candidate' ? mask : 0)
            assert.equal(code, 0, 'The whole real group must complete in its original single native segment')
            const normalized = normalizeSlots(native, mask)
            assertOutputBytes(normalized.bytes, raw.after)
            const simulation = initial.slice()
            const result = simulate(simulation, name === 'candidate' ? mask : 0)
            assert.equal(result.returnCode, code)
            assertOutputBytes(simulation, native)
            const simulationNormalized = normalizeSlots(simulation, mask)
            assertOutputBytes(simulationNormalized.bytes, raw.after)
            arms[name] = {...result, slotIndexMask: mask, liveSlots: normalized.liveSlots,
                normalizedMetadataAndResultsSha256: sha(normalized.bytes.subarray(layout.META)),
                nativeOutputSha256: sha(native.subarray(layout.META)), allNativeAndSimulationOraclesMatched: true}
        }
        assert.equal(arms.baseline.normalizedProbePathSha256, arms.candidate.normalizedProbePathSha256)
        const invariantCounters = ['rowsVisited', 'alreadyResolvedRows', 'probedRows', 'totalSlotVisits', 'occupiedSlotProbes',
            'emptySlotTerminations', 'wrongFullHashPairs', 'matchingFullHashPairs', 'publishedMatches', 'insertedEntries', 'pendingRows']
        for (const key of invariantCounters) assert.equal(arms.baseline.stats[key], arms.candidate.stats[key], key)
        const avoidedFirstHashChecks = arms.baseline.stats.firstHashChecks - arms.candidate.stats.firstHashChecks
        const avoidedConditionalSecondHashChecks = arms.baseline.stats.conditionalSecondHashChecks - arms.candidate.stats.conditionalSecondHashChecks
        assert.equal(avoidedFirstHashChecks, arms.candidate.stats.tagRejections)
        assert.equal(avoidedConditionalSecondHashChecks, arms.candidate.stats.tagRejectedButFirstHashMatches)
        observations.push({group: capture.group, captureSha256: entry.sha256,
            inputMemorySha256: sha(raw.before), referenceNativeAfterSha256: sha(raw.after),
            config: [...originalViews.c], referenceHeader: [...views(raw.after).h], arms,
            avoidedFirstHashChecks, avoidedConditionalSecondHashChecks,
            wrongPairRejectionPercent: arms.candidate.stats.wrongFullHashPairs === 0 ? 0 :
                100 * arms.candidate.stats.tagRejections / arms.candidate.stats.wrongFullHashPairs,
            fullBaselineResolverOracleMatched: true})
        await writeFile(join(output, 'progress.json'), JSON.stringify({plan, observations}, null, 2) + '\n')
        console.log(JSON.stringify({group: capture.group, allOraclesMatched: true}))
    }
    for (const [name, root] of Object.entries(roots)) assert.deepEqual(await sourceIdentity(root), identities[name])
    assert.equal(sha(await readFile(fileURLToPath(import.meta.url))), harnessSha256)
    assert.equal(sha(await readFile(new URL('../component-tools/dedup-snapshot.mjs', import.meta.url))), snapshotHelperSha256)
    complete = true
} catch (error) {
    failure = String(error?.stack ?? error)
} finally {
    await writeFile(join(output, 'summary.json'), JSON.stringify({plan, complete, failure, observations}, null, 2) + '\n', {flag: 'wx'})
    console.log(JSON.stringify({complete, failure, groups: observations.length}))
    if (!complete) process.exitCode = 1
}
