# Canonical slot tags: untimed mechanism audit

This audit explains what the rejection tag skips on three real JMdict resolver inputs. It reports source-level comparisons, not hardware loads, cache misses, CPU cost or import latency. It adds no performance observations to the frozen timing experiment.

The baseline is `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`; the production candidate is `ea3cb4418b0163e3c7b1b5b5e1ad43c72171823a`. Both exact, unchanged production WASM modules run on the original captured input state. An independently reviewed JavaScript port of the C scan loop counts probe decisions and must produce the same complete result and metadata bytes as its corresponding native module. It also requires the same normalized probe sequence for both formats.

## Observed counts

| Actual JMdict group | Representatives | Occupied probes | Wrong full-hash pairs | Tag rejections | Matching-tag false positives |
| --- | ---: | ---: | ---: | ---: | ---: |
| 0 | 34,951 | 572 | 572 | 572 | 0 |
| 5 | 34,006 | 8,174 | 7,711 | 7,709 | 2 |
| 11 | 35,062 | 21,759 | 21,064 | 21,062 | 2 |
| **Total captured groups** | **104,019** | **30,505** | **29,347** | **29,343** | **4** |

There were also 102,861 empty-slot terminations, giving 133,366 total slot visits. Tags reject 29,343 of 29,347 wrong full-hash pairs (99.986%). All 1,158 matching full-hash pairs are retained and reach the unchanged exact-candidate path.

Logical first-hash checks fall from **30,505 to 1,162**, avoiding **29,343 first-hash checks**. Conditional second-hash checks remain **1,158 in both variants**, so there are **zero second-check savings on these inputs**. The baseline already short-circuits the second comparison when its first hash differs. The simulation deliberately reads both hashes for classification; its own reads are not a model of measured hardware traffic.

Counts cover groups 0, 5 and 11 only. They do not establish the size of a speedup or extrapolate to all JMdict, Jitendex, VNDB or browser imports. The initial sparse table has only 572 occupied probes; the mechanism offers more opportunities as the table fills.

## Exact checks

All three original full resolver results and authoritative metadata match their capture oracles. For both production native modules and both simulated formats, the audit checks the complete header, configuration, and every byte from the input metadata prefix through the end of memory: input columns, pending output, exact descriptors, rollback journal and authoritative metadata. Every packed slot's tag is independently checked against its full hash pair before normalization. Simulation must also match its native module without normalization. No candidate source or WASM was instrumented or changed.

The first audit completed successfully with no failed or replaced attempt. Original plans, results, logs, source/module/helper hashes and the analyzer are included. Source identity is checked before and after acquisition.

## Reproduce

Use the revision2 timing bundle with SHA-256 `204babf872f4cde9eef2f50c09cd11d985ae14f7a2202f46cad90f4272c1a28f`. Extract this mechanism archive into that bundle's root directory. Its paths add `evidence/canonical-tags-mechanism/` beside the existing component tools, without replacing any timing-bundle file. Obtain the exact baseline/candidate worktrees and regenerate the original captures using the timing bundle's README.

With absolute paths assigned to `BENCH_NODE`, `BASE_ROOT`, `CANDIDATE_ROOT`, `CAPTURE_ROOT` and a fresh `AUDIT_OUTPUT` directory:

```sh
"$BENCH_NODE" --max-old-space-size=512 \
  evidence/canonical-tags-mechanism/probe-audit.mjs \
  "$BASE_ROOT" "$CANDIDATE_ROOT" "$CAPTURE_ROOT" "$AUDIT_OUTPUT"
python3 evidence/canonical-tags-mechanism/summarize-probes.py "$AUDIT_OUTPUT"
```

Node is exactly 22.22.0. The capture manifest and both native module SHA-256 values are enforced by the runner. A mismatch stops the audit and preserves its failure. No benchmark timing is collected.
