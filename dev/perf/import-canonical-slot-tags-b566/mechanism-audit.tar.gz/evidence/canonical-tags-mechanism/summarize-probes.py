from pathlib import Path
import hashlib
import json
import sys

out = Path(sys.argv[1]).resolve()
source = out / 'summary.json'
report = json.loads(source.read_text())
assert report['complete'], report['failure']
assert [row['group'] for row in report['observations']] == [0, 5, 11]
rows = []
for observation in report['observations']:
    assert observation['fullBaselineResolverOracleMatched']
    base = observation['arms']['baseline']
    candidate = observation['arms']['candidate']
    assert base['allNativeAndSimulationOraclesMatched']
    assert candidate['allNativeAndSimulationOraclesMatched']
    assert base['normalizedProbePathSha256'] == candidate['normalizedProbePathSha256']
    assert base['normalizedMetadataAndResultsSha256'] == candidate['normalizedMetadataAndResultsSha256']
    a, b = base['stats'], candidate['stats']
    assert a['firstHashChecks'] == a['occupiedSlotProbes']
    assert b['wrongFullHashPairs'] == b['tagRejections'] + b['matchingTagFalsePositives']
    assert b['matchingFullHashPairs'] + b['wrongFullHashPairs'] == b['occupiedSlotProbes']
    rows.append({
        'group': observation['group'],
        'representatives': b['rowsVisited'],
        'probedRepresentatives': b['probedRows'],
        'occupiedSlotProbes': b['occupiedSlotProbes'],
        'emptySlotTerminations': b['emptySlotTerminations'],
        'totalSlotVisits': b['totalSlotVisits'],
        'wrongFullHashPairs': b['wrongFullHashPairs'],
        'matchingFullHashPairs': b['matchingFullHashPairs'],
        'tagRejections': b['tagRejections'],
        'matchingTagFalsePositives': b['matchingTagFalsePositives'],
        'baselineFirstHashChecks': a['firstHashChecks'],
        'candidateFirstHashChecks': b['firstHashChecks'],
        'avoidedFirstHashChecks': observation['avoidedFirstHashChecks'],
        'baselineConditionalSecondHashChecks': a['conditionalSecondHashChecks'],
        'candidateConditionalSecondHashChecks': b['conditionalSecondHashChecks'],
        'avoidedConditionalSecondHashChecks': observation['avoidedConditionalSecondHashChecks'],
        'publishedMatches': b['publishedMatches'],
        'insertedEntries': b['insertedEntries'],
    })
total = {key: sum(row[key] for row in rows) for key in rows[0] if key != 'group'}
for row in [*rows, total]:
    row['wrongPairRejectionPercent'] = 100 * row['tagRejections'] / row['wrongFullHashPairs'] if row['wrongFullHashPairs'] else 0
    before = row['baselineFirstHashChecks'] + row['baselineConditionalSecondHashChecks']
    after = row['candidateFirstHashChecks'] + row['candidateConditionalSecondHashChecks']
    row['baselineLogicalHashChecks'] = before
    row['candidateLogicalHashChecks'] = after
    row['logicalHashCheckReductionPercent'] = 100 * (before - after) / before if before else 0
result = {
    'scope': report['plan']['scope'],
    'countMeaning': report['plan']['countMeaning'],
    'allNativeAndSimulationOraclesMatched': True,
    'sourceSummarySha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'analyzerSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'identities': report['plan']['identities'],
    'byGroup': rows,
    'capturedGroupTotals': total,
    'limits': 'Counts cover only the three specified actual captures, not every JMdict group, another corpus or a browser import. The simulation reads both hashes to classify slots; logical production checks avoided are derived from the original short-circuit conditions. These are not sampled hardware loads or cache misses. No latency or CPU time was measured.',
}
(out / 'analysis.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
