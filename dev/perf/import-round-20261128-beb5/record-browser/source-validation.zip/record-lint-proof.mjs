import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {readFile, writeFile} from 'node:fs/promises'
import {createRequire} from 'node:module'

const directory = '/workspace/scratch/beb5caac0497/record-lint'
const baseline = 'a28175a001f343a27cdfc5f723a627a1e8b6a41d'
const require = createRequire(`${directory}/package.json`)
const esbuild = require('esbuild')
const espree = require('espree')
const sha = value => createHash('sha256').update(value).digest('hex')
const git = args => execFileSync('git', args, {cwd: directory, encoding: 'utf8'}).trim()
const changed = git(['diff', '--name-only', baseline]).split('\n')
assert.deepEqual(changed, ['ext/js/dictionary/term-record-fields-wasm.js', 'test/term-record-fields-wasm.test.js'])
function clean(value, testNames = false) {
  if (Array.isArray(value)) return value.map(item => clean(item, testNames))
  if (value === null || typeof value !== 'object') return value
  return Object.fromEntries(Object.entries(value).filter(([key]) => !['start', 'end', 'loc', 'range'].includes(key)).map(([key, item]) => {
    if (testNames && value.type === 'FunctionExpression' && key === 'id' && ['mutatedSlice', 'mutatedGet'].includes(item?.name)) return [key, null]
    return [key, clean(item, testNames)]
  }))
}
const files = []
for (const file of changed) {
  const before = execFileSync('git', ['show', `${baseline}:${file}`], {cwd: directory, encoding: 'utf8'})
  const after = await readFile(`${directory}/${file}`, 'utf8')
  const parse = source => clean(espree.parse(source, {ecmaVersion: 'latest', sourceType: 'module'}), file.startsWith('test/'))
  const oldAst = parse(before)
  const newAst = parse(after)
  assert.deepEqual(newAst, oldAst, `${file} AST equality`)
  const record = {file, beforeSha256: sha(before), afterSha256: sha(after), normalizedAstSha256: sha(JSON.stringify(oldAst)), astEqual: true}
  if (file.startsWith('ext/')) {
    const options = {loader: 'js', target: 'esnext', format: 'esm', minifyWhitespace: true, legalComments: 'none', sourcemap: false}
    const original = (await esbuild.transform(before, options)).code
    const candidate = (await esbuild.transform(after, options)).code
    assert.equal(candidate, original, 'Normalized production output')
    record.normalizedRuntimeSha256 = sha(original)
    record.normalizedRuntimeBytes = Buffer.byteLength(original)
    record.esbuildRuntimeEqual = true
  } else {
    record.testOnlyNormalization = 'The two callback FunctionExpression names mutatedSlice/mutatedGet are ignored; all statements, expressions and assertions must otherwise match exactly.'
  }
  files.push(record)
}
const report = {complete: true, baseline, branch: git(['branch', '--show-current']), node: process.version, esbuildVersion: esbuild.version,
  espreeVersion: require('espree/package.json').version, files,
  runtimeScope: 'Exact production AST equality ignoring source positions; independent esbuild output equality after comment removal and whitespace normalization. No executable runtime change.',
  unchangedProductionFiles: ['ext/js/dictionary/term-record-opfs-store.js', 'ext/js/dictionary/wasm/term-record-fields-v1.c', 'dev/data/dictionary-wasm/term-record-fields-v1.wasm'],
  proofSha256: sha(await readFile(new URL(import.meta.url)))}
for (const file of report.unchangedProductionFiles) assert.equal(git(['diff', baseline, '--', file]), '')
await writeFile('/workspace/scratch/beb5caac0497/record-lint-proof.json', JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report))
