#!/usr/bin/env python3
"""Repeat the required frozen unit gate after a proven linker PATH correction."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/tmp/manabitan-beb5/crc-no-unroll-current')
OUT = Path('/tmp/manabitan-beb5/crc-current-gates')
NODE_DIR = '/workspace/scratch/4a7792ac8b89/toolchains/node-v22.22.0-linux-x64/bin'
LLVM = '/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr'
HEAD = '59ad5a6ddb8342e563cfd09b6fe605cb76bae765'
TREE = '6f6c0ba610392f6ae6aa6df5c826e3d677f6f1af'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True).strip()


def check_source():
    assert git('rev-parse', 'HEAD') == HEAD
    assert git('rev-parse', 'HEAD^{tree}') == TREE
    assert git('status', '--porcelain', '--untracked-files=no') == ''
    assert sha(ROOT / 'ext/js/dictionary/wasm/term-bank-parser.c') == '9b7167fa52c0752dfc10c1a55efea537581ca321ecb65743f113941317139bf4'
    assert sha(ROOT / 'dev/data/dictionary-wasm/term-bank-parser.wasm') == '91774a3c167689211fe49e75b68eb0f91bed42c319bf83e01325dfcf976d0fc3'


previous_path = OUT / 'source-gates.json'
previous = json.loads(previous_path.read_text())
assert previous['complete'] is True, 'Do not overlap the existing source gates'
assert previous['candidate'] == HEAD and previous['tree'] == TREE
assert next(gate for gate in previous['gates'] if gate['gate'] == 'unit')['exitCode'] != 0
assert not (OUT / 'corrected-units.json').exists()
assert not (OUT / 'corrected-unit.log').exists()
check_source()
env = os.environ.copy()
prefix = NODE_DIR + ':' + LLVM + '/bin:' + LLVM + '/lib/llvm-21/bin:'
env['PATH'] = prefix + env.get('PATH', '')
env['MANABITAN_CLANG'] = LLVM + '/bin/clang-21'
env['MANABITAN_WASM_LD'] = LLVM + '/bin/wasm-ld-21'
env['LD_LIBRARY_PATH'] = LLVM + '/lib/x86_64-linux-gnu'
env['NODE_OPTIONS'] = '--max-old-space-size=4096'
assert subprocess.check_output([NODE_DIR + '/node', '--version'], env=env, text=True).strip() == 'v22.22.0'
assert sha(ROOT / 'package-lock.json') == sha((ROOT / 'node_modules').resolve().parent / 'package-lock.json')
probe_code = "import {findCompiler} from './test/util/wasm-compiler.js'\nconsole.log(JSON.stringify(findCompiler('/tmp/manabitan-beb5/crc-current-gates/compiler-probe')))\n"
compiler = json.loads(subprocess.check_output([NODE_DIR + '/node', '--input-type=module', '-e', probe_code], cwd=ROOT, env=env, text=True))
assert compiler == {'command': LLVM + '/bin/clang-21', 'args': []}
command = ['npm', 'run', 'test:unit', '--', '--maxWorkers=2']
report = {
    'candidate': HEAD, 'tree': TREE, 'nodeVersion': 'v22.22.0',
    'originalSourceGateReportSha256': sha(previous_path),
    'originalUnitLogSha256': sha(OUT / 'unit.log'),
    'originalFailureRetained': True,
    'reason': 'The test compiler probe invokes wasm-ld-21, which was absent from PATH. The exact unchanged probe now succeeds using the existing pinned compiler and linker.',
    'correction': {'pathPrefix': prefix, 'compiler': compiler},
    'runtimeEdits': False, 'testEdits': False, 'timeoutsUnchanged': True,
    'testConcurrency': 2, 'noPerformanceMeasurements': True,
    'runnerSha256': sha(Path(__file__)), 'command': command,
    'complete': False, 'startedUtcEpoch': time.time(),
}


def save():
    (OUT / 'corrected-units.json').write_text(json.dumps(report, indent=2) + '\n')


save()
print(json.dumps({'gate': 'full-unit-corrected-linker-path', 'status': 'started', 'compiler': compiler}), flush=True)
with (OUT / 'corrected-unit.log').open('xb') as output:
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
check_source()
report.update({
    'complete': True, 'exitCode': result.returncode,
    'seconds': time.time() - report['startedUtcEpoch'],
    'log': 'corrected-unit.log', 'logSha256': sha(OUT / 'corrected-unit.log'),
    'sourceStillFrozen': True,
})
save()
print(json.dumps(report), flush=True)
sys.exit(result.returncode)
