#!/usr/bin/env python3
"""Run the frozen current-develop CRC candidate's source gates once."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path("/tmp/manabitan-beb5/crc-no-unroll-current")
OUT = Path("/tmp/manabitan-beb5/crc-current-gates")
NODE_DIR = "/workspace/scratch/4a7792ac8b89/toolchains/node-v22.22.0-linux-x64/bin"
LLVM = "/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr"
HEAD = "59ad5a6ddb8342e563cfd09b6fe605cb76bae765"
TREE = "6f6c0ba610392f6ae6aa6df5c826e3d677f6f1af"
OUT.mkdir(exist_ok=True)

def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT, text=True).strip()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def check_source():
    assert git("rev-parse", "HEAD") == HEAD
    assert git("rev-parse", "HEAD^{tree}") == TREE
    assert git("status", "--porcelain", "--untracked-files=no") == ""
    assert sha(ROOT / "ext/js/dictionary/wasm/term-bank-parser.c") == "9b7167fa52c0752dfc10c1a55efea537581ca321ecb65743f113941317139bf4"
    assert sha(ROOT / "dev/data/dictionary-wasm/term-bank-parser.wasm") == "91774a3c167689211fe49e75b68eb0f91bed42c319bf83e01325dfcf976d0fc3"

env = os.environ.copy()
env["PATH"] = NODE_DIR + os.pathsep + env.get("PATH", "")
env["MANABITAN_CLANG"] = LLVM + "/bin/clang-21"
env["MANABITAN_WASM_LD"] = LLVM + "/bin/wasm-ld-21"
env["LD_LIBRARY_PATH"] = LLVM + "/lib/x86_64-linux-gnu"
env["NODE_OPTIONS"] = "--max-old-space-size=4096"
node_version = subprocess.check_output([NODE_DIR + "/node", "--version"], env=env, text=True).strip()
assert node_version == "v22.22.0"
dependency_root = (ROOT / "node_modules").resolve().parent
assert sha(ROOT / "package-lock.json") == sha(dependency_root / "package-lock.json")
check_source()
gates = [
    ("prepare-libraries", ["npm", "run", "build:libs"]),
    ("unit", ["npm", "run", "test:unit", "--", "--maxWorkers=2"]),
    ("javascript", ["npm", "run", "test:js"]),
    ("types-main", ["npm", "run", "test:ts:main"]),
    ("types-dev", ["npm", "run", "test:ts:dev"]),
    ("types-test", ["npm", "run", "test:ts:test"]),
    ("types-bench", ["npm", "run", "test:ts:bench"]),
    ("build-dry-all", ["npm", "run", "test:build"]),
    ("json-format", ["npm", "run", "test:json:format"]),
]
report = {
    "candidate": HEAD, "tree": TREE, "parent": git("rev-parse", "HEAD^"),
    "nodeVersion": node_version, "dependencyRoot": str(dependency_root),
    "packageLockSha256": sha(ROOT / "package-lock.json"),
    "testConcurrency": 2, "timeoutsUnchanged": True,
    "runtimeEdits": False, "noPerformanceMeasurements": True,
    "nativeSourceSha256": sha(ROOT / "ext/js/dictionary/wasm/term-bank-parser.c"),
    "nativeWasmSha256": sha(ROOT / "dev/data/dictionary-wasm/term-bank-parser.wasm"),
    "runnerSha256": sha(Path(__file__)), "gates": [], "complete": False,
}
def save():
    (OUT / "source-gates.json").write_text(json.dumps(report, indent=2) + "\n")
save()
for name, command in gates:
    check_source()
    start = time.time()
    path = OUT / (name + ".log")
    print(json.dumps({"gate": name, "status": "started", "utcEpoch": start}), flush=True)
    with path.open("xb") as output:
        process = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
    duration = time.time() - start
    check_source()
    row = {"gate": name, "command": command, "exitCode": process.returncode,
           "seconds": duration, "log": path.name, "logSha256": sha(path)}
    report["gates"].append(row)
    save()
    print(json.dumps(row), flush=True)
    if name == "prepare-libraries" and process.returncode != 0:
        print(json.dumps({"stopped": "Generated dependencies failed; later gates were not attempted."}), flush=True)
        sys.exit(1)
report["complete"] = True
report["allPassed"] = all(row["exitCode"] == 0 for row in report["gates"])
save()
print(json.dumps({"complete": True, "allPassed": report["allPassed"],
                  "reportSha256": sha(OUT / "source-gates.json")}), flush=True)
sys.exit(0 if report["allPassed"] else 1)
