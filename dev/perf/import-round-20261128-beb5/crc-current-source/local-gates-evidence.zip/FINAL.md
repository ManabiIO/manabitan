# Current-develop CRC candidate: local gates complete

The frozen runtime passed every requested local source gate after a single, verified compiler-discovery environment correction. The runtime is unchanged. Local `59ad5a6ddb8342e563cfd09b6fe605cb76bae765` and published `19db774b564064a7e339d3c3a79ea8da04ab48b5` have the identical tree `6f6c0ba610392f6ae6aa6df5c826e3d677f6f1af`, based on `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`.

## Required gates

- Full corrected unit run: **669 files passed; 15,139 tests passed, 47 skipped**.
- Complete JavaScript lint passed.
- All four type projects (main, dev, test, bench) passed.
- All-target build dry run and JSON format checks passed.
- Independent source/native receipt review passed: 837 CRC vectors, 157 production source cases, and all 12 JMdict groups / 53 banks / 528,299 rows; both frozen production WASM modules reproduced exactly.

## Preserved initial failure

The first full unit run had two setup failures: `term-bank-crc.test.js` and `term-bank-memory-page.test.js` could not discover a supported compiler. It retained 667 passing files, 15,118 passing tests and 68 skipped tests. Its complete report still records failure.

The exact compiler probe showed Debian Clang21 invokes the versioned `wasm-ld-21`, which was absent from the process PATH. Adding only the unversioned LLVMbin directory did not resolve it; that failed probe is also retained. Prepending the existing pinned toolchain usr/bin and LLVMbin directories made the unchanged repository probe succeed. No source, test or timeout was edited. The entire unit suite was rerun; 21 previously skipped tests were then enabled.

## Qualification scope

The independent browser-protocol source review passed at local study `bff4cdbe5939d795e28e96124aa5ce0a9b1c81de` / tree `f4b08d4dfc6f2493336a5318c20c4f2b64b90593`. It checks the exact published runtime, strict two-member package differences, pinned compiler probes, mandatory native/source/unit prerequisites, fixed three-corpus observation schedules, controls and retained failures.

These source gates establish correctness and reproducibility, not an import-performance gain. Complete native/oracle artifacts are retained separately in `crc-current-validation`; their hashes and reviewed results are bound by `independent-native-review.json`. The all-target build check is a dry run. Actual release packages and complete browser measurements remain separately qualified.
