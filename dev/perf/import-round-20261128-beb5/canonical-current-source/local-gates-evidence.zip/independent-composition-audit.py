#!/usr/bin/env python3
"""Read-only exact-source composition audit; no native execution or timing."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

BASE = "dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16"
OLD_BASE = "9e10d3b3fcf66d344ab31bc42c9b522fa5215da2"
OLD_MEASURED = "570ccc3968046269cb00d2053e49d3c32367031a"
OLD_CORRECTED = "ee903e032650430839468fef391b8d820196e61d"
MANIFEST = "dev/data/dictionary-wasm/manifest.json"
PARSER_C = "ext/js/dictionary/wasm/term-bank-parser.c"
PARSER_WASM = "dev/data/dictionary-wasm/term-bank-parser.wasm"
CANON_WASM = "dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm"
SCANNER = "ext/js/dictionary/term-content-canonical-scan.js"
TEST = "test/term-lookup-native-checksum.test.js"
COPIED = sorted([
    CANON_WASM,
    "ext/js/dictionary/dictionary-database.js",
    "ext/js/dictionary/term-content-canonical-layout.js",
    SCANNER,
    "ext/js/dictionary/term-record-opfs-store.js",
    "ext/js/dictionary/wasm/term-content-canonical-scan-v1.c",
])
PARSER_SHA = "5d216041823936521f8a70b721472fb8c42052d165d771a92b59ed967d8d2695"
CANON_SHA = "631a1c430f50579f2ca7227f05ee3793a508d3e5c2ab988024b1616e1f7b8896"
TEST_SHA = "c52acfda2080a5e9a9e9bf27d02c0bc4d89dc5c5f9115706b220d83f5cbd5f53"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("repo")
    parser.add_argument("candidate")
    parser.add_argument("tree")
    parser.add_argument("out")
    parser.add_argument("--with-test", action="store_true")
    args = parser.parse_args()
    repo = Path(args.repo)
    def git(*values):
        return subprocess.check_output(["git", "-C", str(repo), *values])
    def blob(commit, path):
        return git("show", f"{commit}:{path}")
    def digest(data):
        return hashlib.sha256(data).hexdigest()
    def identity(commit, path):
        data = blob(commit, path)
        return {"gitBlob": git("rev-parse", f"{commit}:{path}").decode().strip(), "sha256": digest(data), "bytes": len(data)}
    assert git("rev-parse", "HEAD").decode().strip() == args.candidate
    assert git("show", "-s", "--format=%P", args.candidate).decode().strip() == BASE
    assert git("rev-parse", f"{args.candidate}^{{tree}}").decode().strip() == args.tree
    assert not git("status", "--porcelain", "--untracked-files=no").strip()
    changed = sorted(git("diff", "--name-only", BASE, args.candidate).decode().splitlines())
    expected = sorted([MANIFEST, *COPIED, *([TEST] if args.with_test else [])])
    assert changed == expected, (changed, expected)
    copied = []
    for path in COPIED:
        assert blob(BASE, path) == blob(OLD_BASE, path), path
        assert blob(args.candidate, path) == blob(OLD_CORRECTED, path), path
        # Files present in the sparse working tree must also match the frozen blob.
        working = repo / path
        if working.exists():
            assert working.read_bytes() == blob(args.candidate, path), path
        copied.append({"path": path, "currentBaselineEqualsOldBaseline": True, "candidateEqualsCorrectedOldCandidate": True, "baseline": identity(BASE, path), "candidate": identity(args.candidate, path)})
    corrections = [
        b"/** @type {unknown} */\n",
        b"/** @type {(this: WeakMap<WebAssembly.Memory, CanonicalInstance>, key: WebAssembly.Memory) => CanonicalInstance|undefined} */\n",
    ]
    corrected = blob(OLD_CORRECTED, SCANNER)
    stripped = corrected
    for line in corrections:
        assert stripped.count(line) == 1, line
        stripped = stripped.replace(line, b"", 1)
    assert stripped == blob(OLD_MEASURED, SCANNER)
    for path in COPIED:
        if path != SCANNER:
            assert blob(OLD_CORRECTED, path) == blob(OLD_MEASURED, path), path
    for path in [PARSER_C, PARSER_WASM]:
        assert blob(args.candidate, path) == blob(BASE, path), path
    assert digest(blob(args.candidate, PARSER_WASM)) == PARSER_SHA
    assert digest(blob(args.candidate, CANON_WASM)) == CANON_SHA
    base_manifest = json.loads(blob(BASE, MANIFEST))
    candidate_manifest = json.loads(blob(args.candidate, MANIFEST))
    expected_manifest = json.loads(json.dumps(base_manifest))
    expected_manifest["sourceDigest"] = candidate_manifest["sourceDigest"]
    for target in expected_manifest["targets"]:
        if target["name"] == Path(CANON_WASM).name:
            target["sha256"] = CANON_SHA
    assert candidate_manifest == expected_manifest
    source_bindings = []
    for commit, manifest in [(BASE, base_manifest), (args.candidate, candidate_manifest)]:
        native_paths = sorted(path for path in git("ls-tree", "-r", "--name-only", commit, "ext/js/dictionary/wasm").decode().splitlines() if path.lower().endswith((".c", ".h")))
        bound = "".join(path + "\0" + digest(blob(commit, path)) + "\n" for path in native_paths).encode()
        assert len(native_paths) == manifest["sourceFileCount"] == 14
        assert digest(bound) == manifest["sourceDigest"]
        for target in manifest["targets"]:
            path = "dev/data/dictionary-wasm/" + target["name"]
            assert digest(blob(commit, path)) == target["sha256"], path
        source_bindings.append({"commit": commit, "sourceDigest": digest(bound), "sourceFileCount": len(native_paths), "nativeSources": [{"path": path, "sha256": digest(blob(commit, path))} for path in native_paths]})
    test = None
    if args.with_test:
        assert blob(args.candidate, TEST) == blob(OLD_CORRECTED, TEST)
        assert digest(blob(args.candidate, TEST)) == TEST_SHA
        test = {"path": TEST, **identity(args.candidate, TEST), "equalsOldCorrectedTest": True}
    build_path = Path(args.out).parent / "native-build.log"
    build_data = build_path.read_bytes()
    build_json = json.loads(build_data[build_data.index(b"{"):])
    assert build_json == {"mode": "write", "toolchain": {"compilerVersion": "21.1.8", "linkerVersion": "21.1.8"}, "targets": [{"name": Path(CANON_WASM).name, "sha256": CANON_SHA}, {"name": Path(PARSER_WASM).name, "sha256": PARSER_SHA}]}
    result = {"complete": True, "scope": "Independent Git/source/manifest composition review only. Reads the retained native-build receipt; does not independently recompile, run tests or measure performance.", "baseline": BASE, "candidate": args.candidate, "candidateTree": args.tree, "soleParentVerified": True, "trackedWorkingTreeClean": True, "exactChangedPaths": changed, "copiedProductFiles": copied, "twoAddedJSDocLinesOnlyComparedWithOriginalMeasuredScanner": True, "unchangedCurrentParser": {"source": identity(args.candidate, PARSER_C), "wasm": identity(args.candidate, PARSER_WASM)}, "manifestOnlySourceDigestAndCanonicalTargetShaChanged": True, "sourceBindings": source_bindings, "test": test, "nativeBuildReceipt": {"sha256": digest(build_data), "value": build_json}, "limitations": ["The current baseline includes the separate #972 parser change; old full-import timings do not qualify this current tree.", "CRC no-unroll is absent from this candidate. The two mechanisms are qualified separately.", "Source/unit/browser qualification remains separate from this composition proof."]}
    Path(args.out).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"complete": True, "candidate": args.candidate, "tree": args.tree, "changedPaths": len(changed), "out": args.out, "sha256": digest(Path(args.out).read_bytes())}))


if __name__ == "__main__":
    main()
