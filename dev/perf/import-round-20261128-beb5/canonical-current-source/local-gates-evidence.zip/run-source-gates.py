#!/usr/bin/env python3
"""Run the frozen canonical candidate's required source gates, without timings."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path('/tmp/manabitan-beb5/canonical-current')
OUT = Path('/tmp/manabitan-beb5/canonical-current-gates')
NODE_DIR = '/workspace/scratch/4a7792ac8b89/toolchains/node-v22.22.0-linux-x64/bin'
LLVM = '/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr'
HEAD = '45e51b53b860ac5491a6af8e6fedb5bed95dd3c0'
TREE = 'fc90894e914a29de988753bbe4b062bb2f617f93'
BASE = 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16'
EXPECTED = {
    'ext/js/dictionary/wasm/term-bank-parser.c': '7e836d21cb68165dc0fd6fe8aec074d50b77706debe2360b352b9cc34a67d24a',
    'dev/data/dictionary-wasm/term-bank-parser.wasm': '5d216041823936521f8a70b721472fb8c42052d165d771a92b59ed967d8d2695',
    'ext/js/dictionary/wasm/term-content-canonical-scan-v1.c': 'd485531b3796491c7cc22657decff9f9a19e5096ed29e2823911a990699d0f97',
    'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm': '631a1c430f50579f2ca7227f05ee3793a508d3e5c2ab988024b1616e1f7b8896',
    'dev/data/dictionary-wasm/manifest.json': '5a0ce28ef82c86994535db8fe6a35934ee793a7dc5035e24369b812eaefe1dc9',
    'test/term-lookup-native-checksum.test.js': 'c52acfda2080a5e9a9e9bf27d02c0bc4d89dc5c5f9115706b220d83f5cbd5f53',
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*arguments):
    return subprocess.check_output(['git', *arguments], cwd=ROOT, text=True).strip()


def check_source():
    assert git('rev-parse', 'HEAD') == HEAD
    assert git('rev-parse', 'HEAD^{tree}') == TREE
    assert git('show', '-s', '--format=%P', 'HEAD') == BASE
    assert git('status', '--porcelain', '--untracked-files=no') == ''
    for name, expected in EXPECTED.items():
        assert sha(ROOT / name) == expected, name
    for line in git('ls-files', '-t').splitlines():
        assert not line.startswith('S ') or line[2:].startswith('builds/'), line


env = os.environ.copy()
prefix = NODE_DIR + ':' + LLVM + '/bin:' + LLVM + '/lib/llvm-21/bin:'
env['PATH'] = prefix + env.get('PATH', '')
env['MANABITAN_CLANG'] = LLVM + '/bin/clang-21'
env['MANABITAN_WASM_LD'] = LLVM + '/bin/wasm-ld-21'
env['LD_LIBRARY_PATH'] = LLVM + '/lib/x86_64-linux-gnu'
env['NODE_OPTIONS'] = '--max-old-space-size=4096'
node_version = subprocess.check_output([NODE_DIR + '/node', '--version'], env=env, text=True).strip()
assert node_version == 'v22.22.0'
assert sha(ROOT / 'package-lock.json') == sha((ROOT / 'node_modules').resolve().parent / 'package-lock.json')
assert not (OUT / 'source-gates.json').exists(), 'Existing gate evidence must not be overwritten'
crc_report_path = Path('/tmp/manabitan-beb5/crc-current-gates/corrected-units.json')
crc_report = json.loads(crc_report_path.read_text())
assert crc_report['complete'] is True, 'Do not overlap the CRC full unit suite'
check_source()
(OUT / 'compiler-probe').mkdir(exist_ok=True)
probe = "import assert from 'node:assert/strict'\nimport {findCompiler} from './test/util/wasm-compiler.js'\nconst selected = findCompiler('/tmp/manabitan-beb5/canonical-current-gates/compiler-probe')\nassert.deepEqual(selected, {command: process.env.MANABITAN_CLANG, args: []})\nconsole.log(JSON.stringify(selected))\n"
gates = [
    ('prepare-libraries', ['npm', 'run', 'build:libs']),
    ('compiler-probe', [NODE_DIR + '/node', '--input-type=module', '-e', probe]),
    ('native-reproduction', ['npm', 'run', 'build:dictionary-wasm', '--', '--check']),
    ('unit', ['npm', 'run', 'test:unit', '--', '--maxWorkers=2']),
    ('javascript', ['npm', 'run', 'test:js']),
    ('types-main', ['npm', 'run', 'test:ts:main']),
    ('types-dev', ['npm', 'run', 'test:ts:dev']),
    ('types-test', ['npm', 'run', 'test:ts:test']),
    ('types-bench', ['npm', 'run', 'test:ts:bench']),
    ('build-dry-all', ['npm', 'run', 'test:build']),
    ('json-format', ['npm', 'run', 'test:json:format']),
]
report = {
    'candidate': HEAD, 'tree': TREE, 'soleParent': BASE,
    'nodeVersion': node_version, 'dependencyRoot': str((ROOT / 'node_modules').resolve()),
    'dependencyAcquisition': 'Reused existing installed cache with byte-identical package-lock; no new install.',
    'packageLockSha256': sha(ROOT / 'package-lock.json'),
    'environment': {'pathPrefix': prefix, 'MANABITAN_CLANG': env['MANABITAN_CLANG'], 'MANABITAN_WASM_LD': env['MANABITAN_WASM_LD'], 'LD_LIBRARY_PATH': env['LD_LIBRARY_PATH'], 'NODE_OPTIONS': env['NODE_OPTIONS']},
    'sourceHashes': EXPECTED,
    'testConcurrency': 2, 'timeoutsUnchanged': True,
    'runtimeEdits': False, 'testEdits': False, 'crcCandidateStacked': False,
    'performanceMeasurements': False, 'fullStaticSourceInputsPresent': True,
    'priorCrcUnitCompletion': {'path': str(crc_report_path), 'sha256': sha(crc_report_path), 'exitCode': crc_report['exitCode']},
    'runnerSha256': sha(Path(__file__)),
    'plannedGates': [{'gate': name, 'command': command} for name, command in gates],
    'gates': [], 'complete': False,
}


def save():
    path = OUT / 'source-gates.json'
    temporary = OUT / 'source-gates.json.tmp'
    temporary.write_text(json.dumps(report, indent=2) + '\n')
    temporary.replace(path)


save()
for name, command in gates:
    check_source()
    start = time.time()
    path = OUT / (name + '.log')
    report['activeGate'] = {'gate': name, 'startedUtcEpoch': start}
    save()
    print(json.dumps({'gate': name, 'status': 'started', 'utcEpoch': start}), flush=True)
    with path.open('xb') as output:
        process = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
    check_source()
    row = {'gate': name, 'command': command, 'exitCode': process.returncode,
           'seconds': time.time() - start, 'log': path.name, 'logSha256': sha(path)}
    report['gates'].append(row)
    report.pop('activeGate', None)
    save()
    print(json.dumps(row), flush=True)
    if name in ('prepare-libraries', 'compiler-probe') and process.returncode != 0:
        report['stopped'] = 'Required environment preparation failed; later gates were not attempted.'
        report['allPassed'] = False
        save()
        sys.exit(1)
report['complete'] = True
report['sourceStillFrozen'] = True
report['allPassed'] = all(row['exitCode'] == 0 for row in report['gates'])
save()
print(json.dumps({'complete': True, 'allPassed': report['allPassed'], 'reportSha256': sha(OUT / 'source-gates.json')}), flush=True)
sys.exit(0 if report['allPassed'] else 1)
