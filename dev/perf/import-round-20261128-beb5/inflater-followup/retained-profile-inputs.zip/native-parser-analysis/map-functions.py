import hashlib
import json
import pathlib
import re

directory = pathlib.Path(__file__).parent
root = directory.parent / 'inflight'
baseline = (root / 'dev/data/dictionary-wasm/term-bank-parser.wasm').read_bytes()
named = (directory / 'term-bank-parser-names.wasm').read_bytes()

def unsigned(data, offset):
    value = 0
    shift = 0
    while True:
        byte = data[offset]
        offset += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, offset
        shift += 7

def string(data, offset):
    length, offset = unsigned(data, offset)
    return data[offset:offset+length].decode(), offset + length

def sections(data):
    offset = 8
    result = []
    while offset < len(data):
        section_id = data[offset]
        length, offset = unsigned(data, offset + 1)
        result.append((section_id, data[offset:offset+length]))
        offset += length
    return result

original_sections = sections(baseline)
named_sections = sections(named)
assert [entry for entry in original_sections if entry[0]] == [entry for entry in named_sections if entry[0]], 'Executable sections changed'
names = {}
for section_id, data in named_sections:
    if section_id != 0:
        continue
    name, offset = string(data, 0)
    if name != 'name':
        continue
    while offset < len(data):
        subsection = data[offset]
        length, offset = unsigned(data, offset + 1)
        end = offset + length
        if subsection == 1:
            count, offset = unsigned(data, offset)
            for _ in range(count):
                index, offset = unsigned(data, offset)
                function_name, offset = string(data, offset)
                names[index] = function_name
        offset = end

receipt = {'baselineSha256': hashlib.sha256(baseline).hexdigest(), 'namedSha256': hashlib.sha256(named).hexdigest(),
           'allExecutableSectionsIdentical': True, 'functionNames': names, 'profiles': {}}
for dictionary in ['jmdict', 'jitendex']:
    profile = json.loads((directory.parent / 'profiles' / dictionary / 'trace/attribution.json').read_text())
    totals = {}
    for thread in profile['threads']:
        if thread['name'] != 'term-bank-wasm-parser-worker.js':
            continue
        for entry in thread['self']:
            match = re.fullmatch(r'wasm-function\[(\d+)\]', entry['name'])
            if match:
                index = int(match.group(1))
                function = names.get(index, str(index))
                totals[function] = totals.get(function, 0) + entry['sampleMs']
    receipt['profiles'][dictionary] = sorted(totals.items(), key=lambda entry: -entry[1])

(directory / 'function-profile.json').write_text(json.dumps(receipt, indent=2) + '\n')
for dictionary, rows in receipt['profiles'].items():
    print(dictionary)
    for function, milliseconds in rows[:15]:
        print(f'{milliseconds:8.3f}ms {function}')
