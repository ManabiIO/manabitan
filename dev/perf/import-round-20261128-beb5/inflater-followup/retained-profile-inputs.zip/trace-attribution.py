import collections
import json
import sys
from pathlib import Path


def analyze(path):
    events = json.loads(path.read_text())["traceEvents"]
    worker_names = {}
    thread_names = {}
    profiles = {}
    changes = []
    for event in events:
        key = (event.get("pid"), event.get("tid"))
        name = event.get("name")
        data = event.get("args", {}).get("data", {})
        if name == "thread_name":
            thread_names[key] = event["args"]["name"]
        if name == "TracingSessionIdForWorker":
            worker_names[(event["pid"], data["workerThreadId"])] = data["url"].rsplit("/", 1)[-1]
        if name == "EventDispatch" and data.get("type") == "change":
            changes.append(event["ts"])
        if name == "Profile":
            profiles[(event["pid"], event["id"])] = {
                "thread": key,
                "start": data["startTime"],
                "time": data["startTime"],
                "nodes": {},
                "rawSamples": [],
                "samples": [],
                "negativeDeltas": 0,
            }

    start = min(changes) if changes else min(event["ts"] for event in events if event.get("ts", 0) > 0)
    end = max(event.get("ts", 0) + event.get("dur", 0) for event in events)
    for event in events:
        if event.get("name") != "ProfileChunk":
            continue
        profile = profiles[(event["pid"], event["id"])]
        data = event["args"]["data"]
        cpu = data.get("cpuProfile", {})
        for node in cpu.get("nodes", []):
            profile["nodes"][node["id"]] = node
        for index, (sample, delta) in enumerate(zip(cpu.get("samples", []), data.get("timeDeltas", []))):
            profile["time"] += delta
            profile["negativeDeltas"] += delta < 0
            line = data.get("lines", [None] * len(cpu["samples"]))[index]
            profile["rawSamples"].append((profile["time"], sample, line))

    # Chromium can serialize profiler samples out of timestamp order, yielding
    # negative deltas. Sort their reconstructed timestamps before assigning
    # interval weights; dropping only negative weights would double-count time.
    for profile in profiles.values():
        previous = profile["start"]
        for timestamp, sample, line in sorted(profile["rawSamples"], key=lambda row: row[0]):
            weight = max(0, min(timestamp, end) - max(previous, start))
            if weight:
                profile["samples"].append((sample, weight, previous, timestamp, line))
            previous = timestamp

    tasks = collections.defaultdict(float)
    for event in events:
        if event.get("name") != "RunTask" or event.get("ph") != "X":
            continue
        lo, hi = event["ts"], event["ts"] + event.get("dur", 0)
        fraction = max(0, min(hi, end) - max(lo, start)) / max(1, hi - lo)
        tasks[(event["pid"], event["tid"])] += event.get("tdur", 0) * fraction

    result = {"path": str(path), "startUs": start, "endUs": end, "spanMs": (end - start) / 1000, "threads": []}
    for profile in profiles.values():
        leaves = collections.Counter()
        inclusive = collections.Counter()
        lines = collections.Counter()
        ranges = collections.defaultdict(lambda: [None, None])
        nodes = profile["nodes"]
        for sample, weight, lo, hi, line in profile["samples"]:
            current = sample
            seen = set()
            while current and current not in seen:
                seen.add(current)
                node = nodes[current]
                frame = node["callFrame"]
                key = (frame.get("functionName", ""), frame.get("url", ""), frame.get("lineNumber", -1) + 1)
                inclusive[key] += weight
                bounds = ranges[key]
                bounds[0] = lo if bounds[0] is None else min(bounds[0], lo)
                bounds[1] = hi if bounds[1] is None else max(bounds[1], hi)
                if current == sample:
                    leaves[key] += weight
                    lines[(key, line)] += weight
                current = node.get("parent")

        def top(counter, limit):
            return [
                {"name": key[0], "url": key[1], "line": key[2], "sampleMs": round(value / 1000, 3),
                 "firstMs": round((ranges[key][0] - start) / 1000, 3),
                 "lastMs": round((ranges[key][1] - start) / 1000, 3)}
                for key, value in counter.most_common(limit)
            ]

        thread = profile["thread"]
        result["threads"].append({
            "pid": thread[0], "tid": thread[1],
            "name": worker_names.get(thread, thread_names.get(thread, "unknown")),
            "runTaskCpuMs": round(tasks[thread] / 1000, 3),
            "sampledMs": round(sum(weight for _, weight, _, _, _ in profile["samples"]) / 1000, 3),
            "reorderedNegativeDeltas": profile["negativeDeltas"],
            "self": top(leaves, 25),
            "inclusive": top(inclusive, 30),
            "metadataSelf": top(collections.Counter({key: value for key, value in leaves.items()
                if "TermContentMetadata" in key[0] or "TermEntryContentMeta" in key[0]
                or "_cacheRecentPublished" in key[0] or "term-content-metadata-arena" in key[1]}), 100),
            "metadataInclusive": top(collections.Counter({key: value for key, value in inclusive.items()
                if "TermContentMetadata" in key[0] or "TermEntryContentMeta" in key[0]
                or "_cacheRecentPublished" in key[0] or "term-content-metadata-arena" in key[1]}), 100),
            "metadataLines": [
                {"function": key[0], "line": line, "sampleMs": round(value / 1000, 3)}
                for (key, line), value in lines.most_common()
                if "TermContentMetadata" in key[0] or "TermEntryContentMeta" in key[0]
                or "_cacheRecentPublished" in key[0] or "term-content-metadata-arena" in key[1]
            ],
            "recordLines": [
                {"function": key[0], "line": line, "sampleMs": round(value / 1000, 3)}
                for (key, line), value in lines.most_common()
                if "Artifact" in key[0] or "CompactRecord" in key[0]
            ],
        })
    return result


if __name__ == "__main__":
    path = Path(sys.argv[1])
    result = analyze(path)
    destination = Path(sys.argv[2]) if len(sys.argv) > 2 else path.with_suffix(".attribution.json")
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(f"{destination}: {result['spanMs']:.3f} ms import-change-to-trace-end window")
    for thread in result["threads"]:
        print(f"{thread['name']} tid={thread['tid']} RunTask thread CPU={thread['runTaskCpuMs']:.3f} ms sampled={thread['sampledMs']:.3f} ms")
        if thread["name"] == "offscreen-dictionary-worker.js":
            for entry in thread["self"][:20]:
                print(f"  {entry['sampleMs']:8.3f} ms self {entry['name']} ({entry['url'].rsplit('/', 1)[-1]}:{entry['line']}) [{entry['firstMs']},{entry['lastMs']}]")
