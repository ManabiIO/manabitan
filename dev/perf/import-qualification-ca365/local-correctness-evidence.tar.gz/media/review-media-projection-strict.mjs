import fs from 'node:fs/promises'
import {resolve} from 'node:path'
import {pathToFileURL} from 'node:url'

if (!process.argv[2]) throw new Error('Usage: node review-media-projection-strict.mjs <repository-path>')
const repository = resolve(process.argv[2])
const {tryCollectGlossaryImagePaths} = await import(pathToFileURL(resolve(repository, 'ext/js/dictionary/dictionary-image-references.js')))
const {getImageMediaTypeFromFileName} = await import(pathToFileURL(resolve(repository, 'ext/js/media/media-util.js')))

const {instance} = await WebAssembly.instantiate(await fs.readFile(resolve(repository, 'dev/data/dictionary-wasm/term-bank-parser.wasm')))
const wasm = instance.exports
const encoder = new TextEncoder()
const decoder = new TextDecoder('utf-8', {ignoreBOM: true})
let seed = 0xc365831
const next = n => { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return (seed >>> 0) % n }
const literals = ['null', 'true', 'false', '0', '-0.4e+2', '"img"', '"image"', '"structured-content"', '"text"', '"猫.png"', '"ignored.bin"', '"quoted\\\".webp"', '"\\ud800.png"']
const keys = ['type', 'tag', 'path', 'content', 'unknown', 'data', 'style', '__proto__']
const key = name => next(3) === 0 ? JSON.stringify(name).replace(name[0], `\\u${name.charCodeAt(0).toString(16).padStart(4, '0')}`) : JSON.stringify(name)
const value = depth => {
    if (depth === 0 || next(3) === 0) return literals[next(literals.length)]
    if (next(4) === 0) return `[${Array.from({length: next(4)}, () => value(depth - 1)).join(',')}]`
    const fields = Array.from({length: 1 + next(7)}, () => `${key(keys[next(keys.length)])}:${value(depth - 1)}`)
    return `{${fields.join(next(2) ? ',' : ',\n ')}}`
}
let rawNativeSpan = 0n
const project = source => {
    const bytes = encoder.encode(source)
    wasm.wasm_reset_heap()
    const pointer = wasm.wasm_alloc(bytes.length)
    new Uint8Array(wasm.memory.buffer, pointer, bytes.length).set(bytes)
    const span = wasm.project_single_glossary_image_path(pointer, bytes.length)
    rawNativeSpan = span
    if (span === 0n) return null
    const start = Number(span >> 32n & 0xffffffffn)
    const length = Number(span & 0xffffffffn)
    if (start + length > bytes.length) throw new Error('Projection escaped input bounds')
    const path = JSON.parse(decoder.decode(bytes.subarray(start, start + length)))
    if (typeof path !== 'string') throw new Error('Projection returned a nonstring token')
    return getImageMediaTypeFromFileName(path) === null ? null : [path]
}
const stats = {seed: '0xc365831', valid: 0, invalid: 0, projected: 0, fallback: 0}
for (let i = 0; i < 5000; ++i) {
    const base = `[${Array.from({length: 1 + next(4)}, () => value(4)).join(',')}${i % 3 === 0 ? ',{"type":"image","path":"forced.png"}' : ''}]`
    const mutation = [
        `${base}garbage`,
        base.slice(0, -1),
        `${base.slice(0, -1)},]`,
        base.replace(':', '::'),
        base.replace('"', '"\\q'),
    ][i % 5]
    for (const source of [base, mutation]) {
        let valid = true
        try { JSON.parse(source) } catch { valid = false }
        const result = project(source)
        if (!valid) {
            ++stats.invalid
            if (rawNativeSpan !== 0n) throw new Error(`Malformed accepted by native projector: ${source}`)
            continue
        }
        ++stats.valid
        if (result === null) { ++stats.fallback; continue }
        ++stats.projected
        const expected = tryCollectGlossaryImagePaths(source)
        if (JSON.stringify(result) !== JSON.stringify(expected)) throw new Error(`Semantic mismatch: ${source}\n${JSON.stringify({result, expected})}`)
    }
}
console.log(JSON.stringify(stats, null, 2))
