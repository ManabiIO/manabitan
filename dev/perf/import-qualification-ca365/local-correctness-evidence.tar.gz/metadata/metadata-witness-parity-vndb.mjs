import fs from 'node:fs/promises'
import {createReadStream} from 'node:fs'
import {createHash} from 'node:crypto'
import {pathToFileURL} from 'node:url'
import {ZipReader, Reader, Uint8ArrayWriter} from './manabitan/node_modules/@zip.js/zip.js/index.js'

const root = '/workspace/scratch/ca3652ed5eb0'
const roots = {baseline: `${root}/manabitan`, candidate: `${root}/jitendex`}
const output = `${root}/metadata-witness-parity-vndb.json`
const lockBytes = await fs.readFile(`${roots.baseline}/test/perf/dictionaries.lock.json`)
const locks = JSON.parse(lockBytes).dictionaries
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
const modules = {}
const sourceIdentity = {}
for (const [label, sourceRoot] of Object.entries(roots)) {
    modules[label] = await import(pathToFileURL(`${sourceRoot}/ext/js/dictionary/term-bank-wasm-parser.js`))
    const wasm = await fs.readFile(`${sourceRoot}/ext/lib/term-bank-parser.wasm`)
    modules[label].setTermBankWasmModule(await WebAssembly.compile(wasm))
    sourceIdentity[label] = {wasmSha256: sha(wasm), sources: {}}
    for (const source of ['ext/js/dictionary/term-bank-wasm-parser.js', 'ext/js/dictionary/wasm/term-bank-parser.c']) {
        sourceIdentity[label].sources[source] = sha(await fs.readFile(`${sourceRoot}/${source}`))
    }
}
const report = {purpose: 'One-pass complete parser output parity; no timing or browser import claim', sourceIdentity, lockSha256: sha(lockBytes), dictionaries: {}}
const options = {singleChunk: true, emitTermByteLists: false, computeContentHashes: true,
    emitContentSlab: true, emitTokenBinaryContent: true, mediaHintFastScan: true,
    validateGlossaryTypes: true, prepareLookupIndexes: true}
const feed = (hash, name, value) => {
    hash.update(name)
    if (ArrayBuffer.isView(value)) {
        hash.update(`${value.constructor.name}:${value.byteLength}:`)
        hash.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength))
    } else {
        hash.update(JSON.stringify(value) ?? 'undefined')
    }
    hash.update('\0')
}
function digestChunk(hash, chunk) {
    feed(hash, 'rowCount', chunk.rowCount)
    for (const key of ['readingEqualsExpressionList', 'scoreList', 'sequenceList', 'contentHash1List', 'contentHash2List', 'contentUniqueIndexList', 'contentMetaByUniqueIndex', 'contentMetaList']) {
        feed(hash, key, chunk[key])
    }
    const {contentBytesBuffer, contentBytesBaseOffset = 0, contentBytesLength} = chunk
    if (!(contentBytesBuffer instanceof Uint8Array) || typeof contentBytesLength !== 'number') throw new Error('Missing canonical content slab')
    feed(hash, 'contentBytes', contentBytesBuffer.subarray(contentBytesBaseOffset, contentBytesBaseOffset + contentBytesLength))
    const plan = chunk.termRecordPreinternedPlan
    for (const key of ['stringLengths', 'stringOffsets', 'stringHashes', 'stringsBuffer', 'expressionIndexes', 'readingIndexes']) feed(hash, `plan-${key}`, plan[key])
    feed(hash, 'hasPreparedIndexes', chunk.preparedLookupIndexes instanceof Map)
    for (const [key, entry] of chunk.preparedLookupIndexes ?? []) {
        feed(hash, 'lookup-key', key)
        feed(hash, 'lookup-bytes', entry.bytes)
        for (const field of ['stringLengths', 'stringOffsets', 'stringHashes', 'stringsBuffer', 'expressionIndexes', 'readingIndexes']) feed(hash, `lookup-${field}`, entry.preinternedPlan[field])
    }
    feed(hash, 'media-count', chunk.mediaRows.length)
    for (const {index, imagePaths, row} of chunk.mediaRows) {
        feed(hash, 'media-index', index)
        feed(hash, 'media-imagePaths', imagePaths)
        for (const key of Object.keys(row).sort()) feed(hash, `media-${key}`, row[key])
    }
}
for (const [dictionary, groupSize] of Object.entries({vndb: 10})) {
    const lock = locks[dictionary]
    const archivePath = `${roots.baseline}/builds/e2e-dictionary-cache/${lock.cacheFile}`
    const archiveHash = createHash('sha256')
    for await (const bytes of createReadStream(archivePath)) archiveHash.update(bytes)
    const handle = await fs.open(archivePath)
    const fileSize = (await handle.stat()).size
    if (fileSize !== lock.sizeBytes || archiveHash.digest('hex') !== lock.sha256) throw new Error(`Fixture mismatch ${dictionary}`)
    class FileReader extends Reader {
        constructor() { super(); this.size = fileSize }
        async readUint8Array(offset, length) {
            const bytes = new Uint8Array(length)
            let done = 0
            while (done < length) {
                const {bytesRead} = await handle.read(bytes, done, length - done, offset + done)
                if (bytesRead === 0) throw new Error('Truncated archive')
                done += bytesRead
            }
            return bytes
        }
    }
    const reader = new ZipReader(new FileReader())
    const entries = []
    for await (const entry of reader.getEntriesGenerator()) if (/^term_bank_\d+\.json$/.test(entry.filename)) entries.push(entry)
    entries.sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
    const states = Object.fromEntries(Object.keys(roots).map(label => [label, {hash: createHash('sha256'), rows: 0, groups: 0, mediaRows: 0, nestedMetadataReuseCount: 0, nestedMetadataReuseBytes: 0, maxWasmHeapBytes: 0, fusedParseFallbacks: 0}]))
    try {
        for (let start = 0; start < entries.length; start += groupSize) {
            const sources = []
            for (const entry of entries.slice(start, start + groupSize)) sources.push(await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}))
            for (const [label, parser] of Object.entries(modules)) {
                const state = states[label]
                await parser.parseTermBankWithWasmColumnChunks(sources, 3, chunk => {
                    digestChunk(state.hash, chunk)
                    state.rows += chunk.rowCount
                    state.mediaRows += chunk.mediaRows.length
                }, 2048, options)
                const profile = parser.consumeLastTermBankWasmParseProfile()
                if (!profile) throw new Error('Missing profile')
                for (const key of ['nestedMetadataReuseCount', 'nestedMetadataReuseBytes', 'fusedParseFallbacks']) state[key] += profile[key] ?? 0
                state.maxWasmHeapBytes = Math.max(state.maxWasmHeapBytes, profile.maxWasmHeapBytes ?? 0)
                ++state.groups
            }
            if (start % (groupSize * 50) === 0) console.log(`${dictionary}: ${states.candidate.rows}/${lock.termRows}`)
        }
    } finally { await reader.close(); await handle.close() }
    const results = {}
    for (const [label, {hash, ...state}] of Object.entries(states)) {
        if (state.rows !== lock.termRows) throw new Error(`Wrong row count ${dictionary} ${label}`)
        results[label] = {...state, digest: hash.digest('hex')}
    }
    if (results.baseline.digest !== results.candidate.digest) throw new Error(`Output mismatch ${dictionary}`)
    report.dictionaries[dictionary] = {archiveSha256: lock.sha256, groupSize, ...results}
    await fs.writeFile(output, JSON.stringify(report, null, 2))
    console.log(JSON.stringify({dictionary, ...results}))
}
for (const [label, sourceRoot] of Object.entries(roots)) {
    for (const [source, expected] of Object.entries(sourceIdentity[label].sources)) {
        if (sha(await fs.readFile(`${sourceRoot}/${source}`)) !== expected) throw new Error('Source changed during parity')
    }
}
report.complete = true
report.runnerSha256 = sha(await fs.readFile(new URL(import.meta.url)))
await fs.writeFile(output, JSON.stringify(report, null, 2))
console.log(output)
