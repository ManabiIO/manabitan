import fs from 'node:fs/promises'
import {createHash} from 'node:crypto'

const moduleUrl = new URL('./jitendex/ext/js/dictionary/term-bank-wasm-parser.js', import.meta.url)
const baseline = await import(`${moduleUrl}?review=baseline`)
const candidate = await import(`${moduleUrl}?review=candidate`)
baseline.setTermBankWasmModule(await WebAssembly.compile(await fs.readFile(new URL('./manabitan/dev/data/dictionary-wasm/term-bank-parser.wasm', import.meta.url))))
candidate.setTermBankWasmModule(await WebAssembly.compile(await fs.readFile(new URL('./jitendex/dev/data/dictionary-wasm/term-bank-parser.wasm', import.meta.url))))
const encoder = new TextEncoder()
let seed = 0xc365831
const next = n => { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; return (seed >>> 0) % n }
const literals = ['null', 'true', 'false', '0', '-0.4e+2', '"img"', '"image"', '"text"', '"日本語"', '"\\u0069mage"', '"quoted\\\".webp"', '"\\ud800.png"']
const keys = ['type', 'tag', 'path', 'content', 'unknown', 'data', 'style', '__proto__', 'image', 'img']
const key = name => next(3) === 0 ? JSON.stringify(name).replace(name[0], `\\u${name.charCodeAt(0).toString(16).padStart(4, '0')}`) : JSON.stringify(name)
const object = () => `{${Array.from({length: 1 + next(7)}, () => `${key(keys[next(keys.length)])}${next(2) ? ':' : ' \t: '} ${literals[next(literals.length)]}`).join(next(2) ? ',' : ',\n ')}}`
const row = (meta, index, field = 'data') => `["entry-${index}","","noun","",${index},[{"type":"structured-content","content":{"tag":"span",${JSON.stringify(field)}:${meta},"content":"definition-${index}"}}],${index},""]`
const parse = async (api, banks) => {
    const hash = createHash('sha256')
    let rows = 0
    let error = null
    try {
        await api.parseTermBankWithWasmColumnChunks(banks.map(source => encoder.encode(source)), 3, chunk => {
            rows += chunk.rowCount
            const plan = chunk.termRecordPreinternedPlan
            for (let i = 0; i < chunk.rowCount; ++i) {
                for (const id of [plan.expressionIndexes[i], plan.readingIndexes[i]]) {
                    const start = plan.stringOffsets[id]
                    const value = plan.stringsBuffer.subarray(start, start + plan.stringLengths[id])
                    hash.update(String(value.length)).update(':').update(value)
                }
                const start = (chunk.contentBytesBaseOffset ?? 0) + chunk.contentMetaList[i * 4]
                const length = chunk.contentMetaList[i * 4 + 1]
                hash.update(String(length)).update(':').update(chunk.contentBytesBuffer.subarray(start, start + length))
                hash.update(JSON.stringify([chunk.readingEqualsExpressionList[i], chunk.scoreList[i], chunk.sequenceList[i], chunk.contentMetaList[i * 4 + 2], chunk.contentMetaList[i * 4 + 3]]))
            }
            hash.update(JSON.stringify(chunk.mediaRows.map(({index, row}) => [index, row.glossaryMayContainMedia, row.glossaryJson, row.glossaryJsonBytes ? [...row.glossaryJsonBytes] : null])))
        }, 2048, {singleChunk: true, emitTermByteLists: false, computeContentHashes: true, emitContentSlab: true,
            emitTokenBinaryContent: true, mediaHintFastScan: true, validateGlossaryTypes: true,
            prepareLookupIndexes: true, experimentalFusedSingleBank: true, experimentalValidatedGlossaryReuse: false})
    } catch (e) { error = String(e.message) }
    return {rows, hash: hash.digest('hex'), error, profile: api.consumeLastTermBankWasmParseProfile()}
}
const stats = {seed: '0xc365831', successfulGroups: 0, rows: 0, malformedGroups: 0, witnessHits: 0, witnessBytes: 0}
for (let group = 0; group < 20; ++group) {
    const objects = Array.from({length: 17}, object)
    const rows = Array.from({length: 102}, (_, i) => row(objects[i % objects.length], group * 102 + i, i % 2 ? 'style' : 'data'))
    const banks = Array.from({length: 3}, (_, i) => `[${rows.slice(i * 34, (i + 1) * 34).join(',')}]`)
    const base = await parse(baseline, banks)
    const next = await parse(candidate, banks)
    if (base.error || next.error || base.rows !== next.rows || base.hash !== next.hash) throw new Error(`Mismatch in valid group ${group}: ${JSON.stringify({base, next})}`)
    ++stats.successfulGroups
    stats.rows += next.rows
    stats.witnessHits += next.profile.nestedMetadataReuseCount
    stats.witnessBytes += next.profile.nestedMetadataReuseBytes
}
const good = '{"content":"glossary","type":"text","tag":"img","value":3}'
for (const bad of [`${good}true`, good.slice(0, -1) + ',}', good.replace(':3', ':01'), good.replace('"glossary"', '"\\q"'), good.replace(':3', ':1e'), good.slice(0, -1), '{"content":"glossary","type":"text","tag":"img","value":false]']) {
    const banks = [`[${row(good, 0)},${row(good, 1)},${row(bad, 2)}]`]
    const base = await parse(baseline, banks)
    const next = await parse(candidate, banks)
    if (!base.error || !next.error || base.rows !== 0 || next.rows !== 0) throw new Error(`Malformed successor mismatch: ${JSON.stringify({bad, base, next})}`)
    ++stats.malformedGroups
}
if (stats.witnessHits === 0) throw new Error('Candidate cache never activated')
console.log(JSON.stringify(stats, null, 2))
