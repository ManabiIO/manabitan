/*
 * Copyright (C) 2026 Manabitan authors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import {buildTermLookupFilter} from './term-lookup-route.js';
import {
    consumeLastTermBankWasmParseProfile,
    copyWasmBackedColumnChunk,
    inflateCompressedTermBankSourcesWasm,
    initializeTermBankWasmParser,
    parseTermBankWithWasmColumnChunks,
    setTermBankWasmModule,
} from './term-bank-wasm-parser.js';
import {safePerformance} from '../core/safe-performance.js';
import {snapshotTermBankExperiments} from './term-bank-experiments.js';
import {prepareTermLookupIndexesFromPreinternedPlan} from './term-lookup-index-preparation.js';
import {shouldBorrowProjectedTermContent, shouldOwnTermContentBytes} from './term-content-ownership.js';

/** @typedef {import('./term-bank-wasm-parser.js').TermBankColumnParserOptions} ParserOptions */
/** @typedef {{compressionMethod: unknown, compressedSize: unknown, uncompressedSize: unknown, signature: unknown, filename?: unknown}} CompressedSourceMetadata */
/** @typedef {{type: 'initialize', module: unknown}} InitializeRequest */
/** @typedef {{type: 'parse', id: unknown, sourceBuffers: unknown, sourceMetadata?: unknown, sourceSentEpochMs?: unknown, version: unknown, chunkSize?: unknown, options?: unknown}} ParseRequest */

Reflect.set(globalThis, '__manabitanTermBankParserWorker', true);

/** @type {Promise<void>|null} */
let initialization = null;

self.addEventListener('message', onMessage);

/** @param {MessageEvent<unknown>} event */
function onMessage(event) {
    const data = /** @type {InitializeRequest|ParseRequest|null} */ (
        typeof event.data === 'object' ? event.data : null
    );
    if (data?.type === 'initialize') {
        void initialize(data);
    } else if (data?.type === 'parse') {
        void parse(data);
    }
}

/** @param {InitializeRequest} data */
async function initialize(data) {
    try {
        if (!(data.module instanceof WebAssembly.Module)) {
            throw new TypeError('Term-bank parser worker module is invalid');
        }
        setTermBankWasmModule(data.module);
        initialization = initializeTermBankWasmParser();
        await initialization;
        self.postMessage({type: 'ready'});
    } catch (error) {
        self.postMessage({type: 'initialization-error', error: serializeError(error)});
    }
}

/** @param {ParseRequest} data */
async function parse(data) {
    const id = typeof data.id === 'number' && Number.isSafeInteger(data.id) ? data.id : -1;
    const sourceDeliveryMs = Number.isSafeInteger(data.sourceSentEpochMs) && /** @type {number} */ (data.sourceSentEpochMs) >= 0 ?
        Math.max(0, Date.now() - /** @type {number} */ (data.sourceSentEpochMs)) :
        null;
    /** @type {ArrayBuffer[]} */
    const sourceBuffers = [];
    if (Array.isArray(data.sourceBuffers)) {
        for (const value of /** @type {unknown[]} */ (data.sourceBuffers)) {
            if (value instanceof ArrayBuffer) { sourceBuffers.push(value); }
        }
    }
    try {
        if (initialization === null) {
            throw new Error('Term-bank parser worker is not initialized');
        }
        await initialization;
        if (!Array.isArray(data.sourceBuffers) || sourceBuffers.length !== data.sourceBuffers.length) {
            throw new TypeError('Term-bank parser worker source buffers are invalid');
        }
        if (data.version !== 1 && data.version !== 3) {
            throw new TypeError('Term-bank parser worker dictionary version is invalid');
        }
        const chunkSize = typeof data.chunkSize === 'number' && Number.isFinite(data.chunkSize) ? data.chunkSize : void 0;
        const rawOptions = data.options;
        const options = /** @type {ParserOptions} */ (
            typeof rawOptions === 'object' && rawOptions !== null ? rawOptions : {}
        );
        const experiments = snapshotTermBankExperiments(options);
        const sourceBytes = sourceBuffers.map((buffer) => new Uint8Array(buffer));
        let preloadedSource;
        if (typeof data.sourceMetadata !== 'undefined') {
            if (!Array.isArray(data.sourceMetadata) || data.sourceMetadata.length !== sourceBytes.length) {
                throw new TypeError('Term-bank parser worker compressed source metadata is invalid');
            }
            const sourceMetadata = /** @type {CompressedSourceMetadata[]} */ (data.sourceMetadata);
            preloadedSource = await inflateCompressedTermBankSourcesWasm(sourceBytes.map((bytes, index) => {
                const metadata = sourceMetadata[index];
                return {
                    bytes,
                    compressionMethod: /** @type {0|8} */ (metadata.compressionMethod),
                    compressedSize: /** @type {number} */ (metadata.compressedSize),
                    uncompressedSize: /** @type {number} */ (metadata.uncompressedSize),
                    signature: /** @type {number} */ (metadata.signature),
                    filename: typeof metadata.filename === 'string' ? metadata.filename : void 0,
                };
            }), experiments, data.version === 3 && options.validateGlossaryTypes === true);
        }
        /** @type {ReturnType<typeof copyWasmBackedColumnChunk>|null} */
        let resultChunk = null;
        let resultRowCount = 0;
        let resultCopyMs = 0;
        let borrowsWorkerMemory = false;
        let ownsContentBytes = false;
        await parseTermBankWithWasmColumnChunks(
            typeof preloadedSource === 'undefined' ? sourceBytes : new Uint8Array(0),
            data.version,
            (chunk) => {
                if (resultChunk !== null) {
                    throw new Error('Parallel term-bank parser emitted multiple chunks');
                }
                resultRowCount = chunk.rowCount;
                const tResultCopyStart = safePerformance.now();
                // Compact cacheable slabs and small projected slabs transfer
                // ownership so the next parse can overlap the ordered sink.
                const ownCacheableContent = options.ownContentBytes !== true && typeof SharedArrayBuffer === 'function' && shouldOwnTermContentBytes(
                    chunk.contentBytesLength,
                    chunk.contentDedupPlan?.uniqueCount,
                    chunk.contentDedupPlan?.sourceRowCount,
                    chunk.rowCount,
                );
                /* eslint-disable @stylistic/semi */
                // Reuse the existing borrowed-result lease for byte-heavy
                // projected groups. Never create a shared buffer for this path;
                // nonshared sources retain the original private transfer.
                const borrowProjectedContent = (
                    options.ownContentBytes === true &&
                    options.projectImagePaths === true &&
                    typeof SharedArrayBuffer === 'function' &&
                    chunk.contentBytesBuffer?.buffer instanceof SharedArrayBuffer &&
                    shouldBorrowProjectedTermContent(
                        chunk.contentBytesLength,
                        chunk.contentDedupPlan?.uniqueCount,
                        chunk.contentDedupPlan?.sourceRowCount,
                        chunk.rowCount,
                    )
                )
                const shareContentBytes = options.ownContentBytes !== true || borrowProjectedContent
                /* eslint-enable @stylistic/semi */
                resultChunk = copyWasmBackedColumnChunk(chunk, shareContentBytes, options.projectImagePaths === true, options.prepareLookupRoute === true);
                if (
                    ownCacheableContent && resultChunk.contentBytesBuffer instanceof Uint8Array &&
                    resultChunk.contentBytesBuffer.buffer === chunk.contentBytesBuffer?.buffer
                ) {
                    // Compression workers retain the shared-span path. This slab
                    // is independent of the reusable parser heap and is never
                    // written again after the result is posted.
                    const owned = new Uint8Array(new SharedArrayBuffer(resultChunk.contentBytesBuffer.byteLength));
                    owned.set(resultChunk.contentBytesBuffer);
                    resultChunk.contentBytesBuffer = owned;
                }
                ownsContentBytes = ownCacheableContent || resultChunk.contentBytesBuffer?.buffer instanceof ArrayBuffer;
                borrowsWorkerMemory = (
                    typeof SharedArrayBuffer === 'function' &&
                    chunk.contentBytesBuffer?.buffer instanceof SharedArrayBuffer &&
                    resultChunk.contentBytesBuffer?.buffer === chunk.contentBytesBuffer.buffer
                );
                resultCopyMs = Math.max(0, safePerformance.now() - tResultCopyStart);
            },
            chunkSize,
            {...options, ...experiments, maxPendingChunks: 1, singleChunk: true, compactContentMetadata: true, preloadedSource},
        );
        const profile = consumeLastTermBankWasmParseProfile();
        // A validated empty group emits no storage chunk. Keep that distinct
        // from a missing result for a nonempty group; parsing and CRC checks
        // above still run before this result is published.
        if (resultChunk === null && profile?.rowCount !== 0) {
            throw new Error('Parallel term-bank parser did not emit a chunk');
        }
        const stableResultChunk = /** @type {ReturnType<typeof copyWasmBackedColumnChunk>|null} */ (resultChunk);
        if (profile !== null) {
            profile.resultCopyMs = resultCopyMs;
            profile.sourceDeliveryMs = sourceDeliveryMs ?? 0;
            profile.borrowedContentResultCount = borrowsWorkerMemory ? 1 : 0;
            if (typeof preloadedSource !== 'undefined') {
                Object.assign(profile, {
                    sourceInflateMs: preloadedSource.inflateMs,
                    sourceCrcMs: preloadedSource.crcMs ?? 0,
                    sourceCrcScannedBytes: preloadedSource.crcScannedBytes ?? 0,
                    sourceCrcReusedBytes: preloadedSource.crcReusedBytes ?? 0,
                    sourceCrcReusedGlossaryCount: preloadedSource.crcReusedGlossaryCount ?? 0,
                    sourceCompressedBytes: preloadedSource.compressedBytes,
                    sourceUncompressedBytes: preloadedSource.uncompressedBytes,
                });
            }
        }
        if (stableResultChunk !== null && options.prepareLookupIndexes === true && !(stableResultChunk.preparedLookupIndexes instanceof Map)) {
            const prepared = prepareTermLookupIndexesFromPreinternedPlan(stableResultChunk, null, experiments);
            if (prepared !== null) {
                stableResultChunk.preparedLookupIndexes = prepared.indexes;
                stableResultChunk.preparedLookupIndexEncodeMs = prepared.totalMs;
                if (profile !== null) {
                    profile.lookupIndexPrepareMs = (profile.lookupIndexPrepareMs ?? 0) + prepared.totalMs;
                    profile.lookupIndexCompactMs = prepared.compactMs;
                    profile.lookupIndexEncodeMs = (profile.lookupIndexEncodeMs ?? 0) + prepared.indexEncodeMs;
                    profile.directLookupArenaSegments = prepared.directArenaSegments;
                    profile.directLookupArenaCopiedBytesAvoided = prepared.directArenaCopiedBytesAvoided;
                    profile.lookupCompactionSourceValidationPasses = prepared.compactionSourceValidationPasses;
                }
            }
        }
        if (options.prepareLookupRoute === true && stableResultChunk?.preparedLookupIndexes instanceof Map) {
            for (const index of stableResultChunk.preparedLookupIndexes.values()) {
                index.routeFilter ??= buildTermLookupFilter(index.preinternedPlan.stringHashes);
            }
        }
        const transfer = stableResultChunk === null ? [] : collectChunkTransferables(stableResultChunk);
        self.postMessage({
            type: 'result',
            id,
            rowCount: resultRowCount,
            resultSentEpochMs: Date.now(),
            borrowsWorkerMemory,
            ownsContentBytes,
            chunk: stableResultChunk,
            profile,
        }, transfer);
    } catch (error) {
        self.postMessage({type: 'parse-error', id, error: serializeError(error)});
    }
}

/**
 * @param {ReturnType<typeof copyWasmBackedColumnChunk>} chunk
 * @returns {Transferable[]}
 */
function collectChunkTransferables(chunk) {
    /** @type {Set<ArrayBuffer>} */
    const buffers = new Set();
    /** @param {unknown} value */
    const addView = (value) => {
        if (!ArrayBuffer.isView(value)) { return; }
        const buffer = value.buffer;
        if (buffer instanceof ArrayBuffer && buffer.byteLength > 0) { buffers.add(buffer); }
    };
    for (const bytes of chunk.expressionBytesList) { addView(bytes); }
    for (const bytes of chunk.readingBytesList) { addView(bytes); }
    for (const bytes of chunk.contentBytesList) { addView(bytes); }
    addView(chunk.readingEqualsExpressionList);
    addView(chunk.scoreList);
    addView(chunk.sequenceList);
    addView(chunk.contentHash1List);
    addView(chunk.contentHash2List);
    addView(chunk.contentBytesBuffer);
    addView(chunk.contentMetaList);
    addView(chunk.contentUniqueIndexList);
    for (const {row} of chunk.mediaRows) {
        addView(row.expressionBytes);
        addView(row.readingBytes);
        addView(row.glossaryJsonBytes);
        addView(row.termEntryContentBytes);
    }
    const plan = chunk.termRecordPreinternedPlan;
    addView(plan.stringLengths);
    addView(plan.stringOffsets);
    addView(plan.stringHashes);
    addView(plan.stringsBuffer);
    addView(plan.expressionIndexes);
    addView(plan.readingIndexes);
    const preparedLookupIndexes = /** @type {unknown} */ (chunk.preparedLookupIndexes);
    if (preparedLookupIndexes instanceof Map) {
        for (const prepared of preparedLookupIndexes.values()) {
            if (typeof prepared !== 'object' || prepared === null) { continue; }
            addView(Reflect.get(prepared, 'bytes'));
            addView(Reflect.get(prepared, 'routeFilter'));
            const preparedPlan = /** @type {unknown} */ (Reflect.get(prepared, 'preinternedPlan'));
            if (typeof preparedPlan !== 'object' || preparedPlan === null) { continue; }
            addView(Reflect.get(preparedPlan, 'stringLengths'));
            addView(Reflect.get(preparedPlan, 'stringOffsets'));
            addView(Reflect.get(preparedPlan, 'stringHashes'));
            addView(Reflect.get(preparedPlan, 'stringsBuffer'));
            addView(Reflect.get(preparedPlan, 'expressionIndexes'));
            addView(Reflect.get(preparedPlan, 'readingIndexes'));
        }
    }
    const rawDedupPlan = /** @type {unknown} */ (chunk.contentDedupPlan);
    const dedupPlan = /** @type {{uniqueRowIndexes?: unknown, uniqueSignatures?: unknown, resolvedFlags?: unknown, resolvedOffsets?: unknown, resolvedLengths?: unknown, pendingEpochs?: unknown, pendingIndexes?: unknown, pendingSpanOffsetsScratch?: unknown, pendingSpanLengthsScratch?: unknown}|null} */ (
        typeof rawDedupPlan === 'object' ? rawDedupPlan : null
    );
    if (typeof dedupPlan === 'object' && dedupPlan !== null) {
        if (dedupPlan.uniqueRowIndexes instanceof Uint32Array) {
            addView(dedupPlan.uniqueRowIndexes);
        }
        addView(dedupPlan.uniqueSignatures);
        addView(dedupPlan.resolvedFlags);
        addView(dedupPlan.resolvedOffsets);
        addView(dedupPlan.resolvedLengths);
        addView(dedupPlan.pendingEpochs);
        addView(dedupPlan.pendingIndexes);
        addView(dedupPlan.pendingSpanOffsetsScratch);
        addView(dedupPlan.pendingSpanLengthsScratch);
    }
    return [...buffers];
}

/**
 * @param {unknown} error
 * @returns {{name: string, message: string, stack?: string}}
 */
function serializeError(error) {
    if (error instanceof Error) {
        return {name: error.name, message: error.message, ...(typeof error.stack === 'string' ? {stack: error.stack} : {})};
    }
    return {name: 'Error', message: `${error}`};
}
