# Separate prior memory study: independent audit

Run [45642179064](https://github.com/ManabiIO/manabitan/actions/runs/45642179064), attempt 1; workflow `718c23b87e3f0b0cdc89d42f2db2770092de47c9`.

Baseline `7d1643e6147a10cb2165e9744cf0e63b59e46632`; candidate `7a8b25a44a3fe165107ed816377cc72bb0fac67d`. The candidate extension and native-artifact trees are identical to `5afd2e97ec2707b150acfde61115aee688547a78`.

All four artifact SHA-256 digests and byte sizes match GitHub metadata. Every archived entry was hashed. Both release packages in each cell were independently bound to their source, member maps and native manifests. The unchanged frozen raw-scan and receipt auditors reproduce every original audit receipt.

All 16 observations passed the frozen semantic, storage, lookup and restart checks. The audit recomputed 1504 raw scans. Each observation reads 64 sampled media files; the memory interval excludes media readback and restart. This is separate from the exhaustive media checks in the current campaign.

| Corpus | Host / order | Qualified observations | PSS median / maximum paired change | Private median / maximum paired change | Result |
|---|---|---:|---:|---:|---|
| jitendex | 1 / ABBA | 4/4 | -2.5578% / -1.6808% | -3.1031% / -2.1663% | pass |
| jitendex | 2 / BAAB | 4/4 | +1.8317% / +2.3784% | +2.5668% / +3.3156% | pass |
| vndb | 1 / ABBA | 3/4 | null / null | null / null | coverage failure |
| vndb | 2 / BAAB | 1/4 | null / null | null / null | coverage failure |

The fixed bounds require every observation to qualify, each metric’s median paired increase ≤5%, and every individual paired increase ≤10%, on both hosts. Jitendex passes both hosts. VNDB fails coverage on both hosts; its aggregate metrics stay null and cannot qualify.

## Every observation

| Corpus / host | Slot | Qualified scans | Maximum covered gap (ms) | PSS (KiB) | Private (KiB) | Qualification failures |
|---|---|---:|---:|---:|---:|---|
| jitendex / 1 | A1 | 17 | 164.904016 | 1055722 | 825180 | none |
| jitendex / 1 | B1 | 13 | 146.021474 | 1037977 | 807304 | none |
| jitendex / 1 | B2 | 14 | 148.569258 | 1049895 | 819940 | none |
| jitendex / 1 | A2 | 14 | 170.196895 | 1087240 | 854460 | none |
| jitendex / 2 | B1 | 13 | 163.251545 | 1068192 | 836224 | none |
| jitendex / 2 | A1 | 13 | 224.244401 | 1043376 | 809388 | none |
| jitendex / 2 | A2 | 11 | 187.527807 | 1062270 | 829084 | none |
| jitendex / 2 | B2 | 12 | 202.698431 | 1075920 | 844156 | none |
| vndb / 1 | A1 | 48 | 161.775619 | 1421061 | 1188860 | none |
| vndb / 1 | B1 | 45 | 171.575019 | 1411740 | 1179096 | none |
| vndb / 1 | B2 | 42 | 173.296953 | 1427052 | 1193948 | none |
| vndb / 1 | A2 | 46 | 350.425804 | None | None | covered-import-scan-gap-over-250ms |
| vndb / 2 | B1 | 42 | 324.494085 | None | None | covered-import-scan-gap-over-250ms |
| vndb / 2 | A1 | 41 | 258.866332 | None | None | covered-import-scan-gap-over-250ms |
| vndb / 2 | A2 | 45 | 244.012203 | 1383326 | 1152024 | none |
| vndb / 2 | B2 | 40 | 275.215655 | None | None | covered-import-scan-gap-over-250ms |

The JSON retains all individual pair values, bracket gaps, raw counts, unavailable-read classifications, source identities and artifact digests. Raw scans, reports, receipts, source files and package manifests remain in each cell’s evidence directory. Temporary release ZIPs and only this audit’s verified outer download ZIPs were removed.

PSS/private figures are non-atomic sampled process-tree observations, not exact memory peaks. This prior study is not pooled with or substituted into the current independent run `45647030792`.
