"""Audit the separate completed #875 cohort without reusing its observations."""
import functools
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / 'qualification'
HEAD = '718c23b87e3f0b0cdc89d42f2db2770092de47c9'
BASE = '7d1643e6147a10cb2165e9744cf0e63b59e46632'
CANDIDATE = '7a8b25a44a3fe165107ed816377cc72bb0fac67d'
CURRENT = '5afd2e97ec2707b150acfde61115aee688547a78'
RUN = 45642179064
DIRECTORY = 'dev/perf/import-memory-20261124-3aac'
HARNESS = 'test/chromium/extension-two-dictionary-import.e2e.js'
MEMBERS = {
    'manifest.json', 'js/dictionary/dictionary-importer.js',
    'js/dictionary/term-bank-wasm-parser-worker.js',
    'js/dictionary/term-bank-wasm-parser.js',
    'js/dictionary/wasm/term-bank-parser.c', 'lib/term-bank-parser.wasm',
    'lib/term-content-canonical-scan-v1.wasm',
}


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def sha(value):
    return hashlib.sha256(value).hexdigest()


@functools.lru_cache(None)
def git_bytes(commit, path):
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=REPO)


def git_object(revision):
    return subprocess.check_output(['git', 'rev-parse', revision], cwd=REPO, text=True).strip()


def stream_digest(stream):
    result = hashlib.sha256()
    length = 0
    while block := stream.read(1024 * 1024):
        result.update(block)
        length += len(block)
    return result.hexdigest(), length


FROZEN = HERE / 'frozen-auditor'
FROZEN.mkdir(exist_ok=True)
for filename in ('audit_memory.py', 'chromium_memory.py', 'protocol.py', 'run_memory.py',
                 'storage_receipts.py', 'verify_receipts.py'):
    (FROZEN / filename).write_bytes(git_bytes(HEAD, DIRECTORY + '/' + filename))
sys.path.insert(0, str(FROZEN))
from run_memory import memory_overlay, schedule


def verify_package(archive, evidence, cell, arm, commit, plan):
    data = archive.read(f'{arm}-product.zip')
    identity = json.loads((evidence / f'{arm}-identity.json').read_text())
    assert identity['commit'] == commit
    assert identity['tree'] == git_object(f'{commit}^{{tree}}')
    assert identity['packageSha256'] == sha(data)
    assert identity['buildCleanBeforeOverlay'] is True
    assert identity['harnessOverlaySha256'] == plan['memoryOverlaySha256']
    recorded = json.loads((evidence / f'{arm}-package-entries.json').read_text())
    with zipfile.ZipFile(io.BytesIO(data)) as package:
        files = [item for item in package.infolist() if not item.is_dir()]
        assert len(files) == len({item.filename for item in files})
        actual = {}
        for member in files:
            with package.open(member) as stream:
                actual[member.filename] = stream_digest(stream)[0]
            if member.filename in MEMBERS:
                target = cell / 'package-source' / arm / member.filename
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(package.read(member))
        assert actual == recorded
        manifest = json.loads(git_bytes(commit, 'dev/data/dictionary-wasm/manifest.json'))
        save(cell / 'package-source' / arm / 'native-manifest.json', manifest)
        for target in manifest['targets']:
            assert actual['lib/' + target['name']] == target['sha256']
        for member in MEMBERS:
            if member.startswith('js/'):
                assert package.read(member) == git_bytes(commit, 'ext/' + member)
    return data, {'sourceCommit': commit, 'sourceTree': identity['tree'],
                  'packageSha256': sha(data), 'packageBytes': len(data),
                  'allMembersVerified': True, 'ownNativeManifestVerified': True,
                  'members': actual}


def audit(artifact):
    archive_path = HERE / 'downloads' / f"artifact-{artifact['id']}.zip"
    assert archive_path.parent.resolve() == (HERE / 'downloads').resolve()
    with archive_path.open('rb') as stream:
        digest, size = stream_digest(stream)
    assert digest == artifact['digest'].removeprefix('sha256:')
    assert size == artifact['size_in_bytes']
    assert artifact['workflow_run']['id'] == RUN and artifact['workflow_run']['head_sha'] == HEAD
    name = artifact['name'].removeprefix('current-media-memory-').removesuffix('-2754')
    dictionary, replication = name.split('-rep')
    replication = int(replication)
    assert dictionary in ('jitendex', 'vndb') and replication in (1, 2)
    cell = HERE / name
    cell.mkdir(exist_ok=False)
    evidence = cell / 'evidence'
    evidence.mkdir()
    save(cell / 'artifact-metadata.json', artifact)
    inventory = []
    with zipfile.ZipFile(archive_path) as archive:
        entries = archive.infolist()
        assert len(entries) == len({entry.filename for entry in entries})
        for entry in entries:
            path = PurePosixPath(entry.filename)
            assert not path.is_absolute() and '..' not in path.parts
            assert (entry.external_attr >> 16) & 0o170000 != 0o120000
            if entry.is_dir():
                continue
            with archive.open(entry) as stream:
                entry_hash, entry_size = stream_digest(stream)
            inventory.append({'path': entry.filename, 'sha256': entry_hash, 'bytes': entry_size})
            if entry.filename in ('A-product.zip', 'B-product.zip'):
                continue
            target = evidence / path
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(entry) as source, target.open('wb') as destination:
                shutil.copyfileobj(source, destination, 1024 * 1024)

        plan = json.loads((evidence / 'plan.json').read_text())
        assert plan['toolingCommit'] == HEAD and int(plan['workflowRun']) == RUN
        assert int(plan['workflowAttempt']) == 1 and plan['dictionary'] == dictionary
        assert plan['replication'] == replication and plan['schedule'] == schedule(replication)
        assert plan['mediaCheck'] == 'sample' and plan['authoritativeTiming'] is False
        assert plan['fixture'] == json.loads(git_bytes(BASE, 'test/perf/dictionaries.lock.json'))['dictionaries'][dictionary]
        for arm, commit in [('A', BASE), ('B', CANDIDATE)]:
            assert plan['sourceIdentities'][arm] == {'commit': commit, 'tree': git_object(f'{commit}^{{tree}}')}
        for file in (evidence / 'source').rglob('*'):
            if file.is_file():
                assert file.read_bytes() == git_bytes(HEAD, file.relative_to(evidence / 'source').as_posix())
        for path, expected in plan['harnessSha256'].items():
            assert sha(git_bytes(BASE, path)) == expected
            assert sha(git_bytes(CANDIDATE, path)) == expected
        for path, expected in plan['dependencySourceSha256'].items():
            assert sha(git_bytes(BASE, path)) == expected == sha(git_bytes(HEAD, path))
        original = git_bytes(BASE, HARNESS)
        assert (evidence / 'original-harness.e2e.js').read_bytes() == original
        assert (evidence / 'memory-harness.e2e.js').read_text() == memory_overlay(original.decode())

        replay = cell / 'independent-replay'
        replay.mkdir()
        for file in evidence.iterdir():
            if file.name not in ('memory-audit.json', 'receipt-audit.json'):
                (replay / file.name).symlink_to(file)
        binding = {}
        try:
            for arm, commit in [('A', BASE), ('B', CANDIDATE)]:
                package_data, binding[arm] = verify_package(archive, evidence, cell, arm, commit, plan)
                # The unchanged receipt auditor requires release ZIP paths. These
                # are owned temporary inputs removed immediately after replay.
                (replay / f'{arm}-product.zip').write_bytes(package_data)
                del package_data
            actual_delta = sorted(key for key in binding['A']['members'].keys() | binding['B']['members'].keys()
                                  if binding['A']['members'].get(key) != binding['B']['members'].get(key))
            assert actual_delta == plan['expectedPackageDifferences']
            binding['exactPackagedDelta'] = actual_delta
            audits = {}
            for script, output in [('audit_memory.py', 'memory-audit.json'), ('verify_receipts.py', 'receipt-audit.json')]:
                result = subprocess.run(['python3', str(FROZEN / script), str(replay)], capture_output=True, text=True)
                (cell / ('independent-' + script.removesuffix('.py') + '.log')).write_text(result.stdout + result.stderr)
                assert result.returncode == 0, result.stderr
                audits[output] = json.loads((replay / output).read_text())
                assert audits[output] == json.loads((evidence / output).read_text())
        finally:
            for arm in ('A', 'B'):
                owned_zip = replay / f'{arm}-product.zip'
                if owned_zip.exists():
                    owned_zip.unlink()

    observations = []
    for item in plan['schedule']:
        memory = json.loads((evidence / item['name'] / 'memory.json').read_text())
        summary = json.loads((evidence / item['name'] / 'summary.json').read_text())
        assert memory['windowDurationMs'] >= summary['runs'][0]['totalImportMs']
        assert summary['browserVersion'] == '153.0.8010.12'
        values = {key: memory.get(key) for key in (
            'qualifiedForWholeTreePss', 'maxSampledPssKiB', 'maxSampledPrivateKiB',
            'maximumCoveredSampleGapMs', 'preImportBracketGapMs', 'postImportBracketGapMs',
            'stableFullyReadImportSampleCount', 'allObservedSampleCount', 'qualificationFailures',
            'benchmarkExitCode', 'windowDurationMs', 'samplesWithUnavailableSmaps',
            'samplesWithUnreadableAddressSpaces', 'confirmedExitedZombieIdentityCount',
        )}
        media = summary['runs'][0]['validation']['media']
        observations.append({**item, **values, 'rawScanCount': len(memory['samples']),
                             'mediaReadbackMode': media['mode'], 'mediaFilesRead': media['files'],
                             'totalMediaFiles': media['totalFiles'], 'mediaBytesRead': media['bytes'],
                             'lookupReceiptCount': len(summary['runs'][0]['validation']['lookup']['observations'])})
    comparison = json.loads((evidence / 'memory-comparison.json').read_text())
    qualification = json.loads((evidence / 'qualification.json').read_text())
    result = {'runId': RUN, 'workflowHead': HEAD, 'baseCommit': BASE, 'candidateCommit': CANDIDATE,
              'candidateProductIdenticalTo': CURRENT, 'dictionary': dictionary, 'replication': replication,
              'artifactId': artifact['id'], 'artifactSha256': digest, 'artifactBytes': size,
              'sourceAndPackageBindingVerified': True, 'frozenRawScanAuditReproduced': True,
              'frozenReceiptAuditReproduced': True, 'mediaReadbackMode': 'sample',
              'observations': observations, 'pairs': comparison['pairs'], 'metrics': comparison['metrics'],
              'everyObservationQualified': comparison['everyObservationQualified'],
              'passesProspectiveMemoryScreen': comparison['passesProspectiveMemoryScreen'],
              'qualifiedObservations': sum(item['qualifiedForWholeTreePss'] for item in observations),
              'rawScanCount': sum(item['rawScanCount'] for item in observations),
              'correctnessPassed': audits['receipt-audit.json']['allCorrectnessPassed'],
              'recordedQualification': qualification,
              'classification': 'pass' if comparison['passesProspectiveMemoryScreen'] else
                 'coverage failure' if not comparison['everyObservationQualified'] else 'measured threshold breach'}
    save(cell / 'archive-entry-manifest.json', inventory)
    save(cell / 'package-binding.json', binding)
    save(cell / 'independent-result.json', result)
    save(cell / 'extraction.json', {'runId': RUN, 'workflowHead': HEAD, 'artifactId': artifact['id'],
                                  'artifactSha256': digest, 'artifactBytes': size,
                                  'allArchiveEntriesReadAndHashed': True,
                                  'releaseZipsRetained': False, 'sourceArchiveDeleted': True})
    archive_path.unlink()
    print(json.dumps({key: result[key] for key in ('dictionary', 'replication', 'classification',
                                                  'qualifiedObservations', 'rawScanCount', 'metrics')}) , flush=True)
    return result


def main():
    product_identity = {}
    for path in ('ext', 'dev/data/dictionary-wasm'):
        before, after = git_object(f'{CANDIDATE}:{path}'), git_object(f'{CURRENT}:{path}')
        assert before == after
        product_identity[path] = before
    artifacts = json.loads((HERE / 'artifacts.json').read_text())
    if isinstance(artifacts, dict):
        artifacts = artifacts['artifacts']
    results = []
    for artifact in artifacts:
        name = artifact['name'].removeprefix('current-media-memory-').removesuffix('-2754')
        result_path = HERE / name / 'independent-result.json'
        results.append(json.loads(result_path.read_text()) if result_path.exists() else audit(artifact))
    results.sort(key=lambda row: (row['dictionary'], row['replication']))
    summary = {'runId': RUN, 'workflowHead': HEAD, 'baseCommit': BASE, 'candidateCommit': CANDIDATE,
               'candidateProductIdenticalTo': CURRENT, 'verifiedProductTrees': product_identity,
               'separateFromRun': 45647030792, 'mediaReadbackMode': 'sample',
               'observations': 16, 'rawScanCount': sum(row['rawScanCount'] for row in results),
               'correctnessPassedEveryObservation': all(row['correctnessPassed'] for row in results),
               'bothReplicationsPassByDictionary': {
                   dictionary: all(row['passesProspectiveMemoryScreen'] for row in results if row['dictionary'] == dictionary)
                   for dictionary in ('jitendex', 'vndb')},
               'cells': results,
               'limitations': ['Non-atomic sampled whole-tree PSS/private maxima are not exact peaks.',
                               'Only complete scans wholly within the import markers contribute to maxima.',
                               'Startup, media readback and restart are outside the memory import window.',
                               'Each observation validates 64 sampled media files; this is not exhaustive media readback.',
                               'This older independent study is not pooled with or substituted into run 45647030792.']}
    save(HERE / 'prior-memory-audit-summary.json', summary)
    lines = [
        '# Separate prior memory study: independent audit', '',
        f'Run [{RUN}](https://github.com/ManabiIO/manabitan/actions/runs/{RUN}), attempt 1; workflow `{HEAD}`.', '',
        f'Baseline `{BASE}`; candidate `{CANDIDATE}`. The candidate extension and native-artifact trees are identical to `{CURRENT}`.', '',
        'All four artifact SHA-256 digests and byte sizes match GitHub metadata. Every archived entry was hashed. Both release packages in each cell were independently bound to their source, member maps and native manifests. The unchanged frozen raw-scan and receipt auditors reproduce every original audit receipt.', '',
        f'All 16 observations passed the frozen semantic, storage, lookup and restart checks. The audit recomputed {summary["rawScanCount"]} raw scans. Each observation reads 64 sampled media files; the memory interval excludes media readback and restart. This is separate from the exhaustive media checks in the current campaign.', '',
        '| Corpus | Host / order | Qualified observations | PSS median / maximum paired change | Private median / maximum paired change | Result |',
        '|---|---|---:|---:|---:|---|',
    ]
    for row in results:
        def format_metric(name):
            item = row['metrics'][name]
            return 'null / null' if item['medianPairedChangePercent'] is None else f"{item['medianPairedChangePercent']:+.4f}% / {item['maximumPairedChangePercent']:+.4f}%"
        order = ''.join(item['arm'] for item in row['observations'])
        lines.append(f"| {row['dictionary']} | {row['replication']} / {order} | {row['qualifiedObservations']}/4 | {format_metric('maxSampledPssKiB')} | {format_metric('maxSampledPrivateKiB')} | {row['classification']} |")
    lines += ['', 'The fixed bounds require every observation to qualify, each metric’s median paired increase ≤5%, and every individual paired increase ≤10%, on both hosts. Jitendex passes both hosts. VNDB fails coverage on both hosts; its aggregate metrics stay null and cannot qualify.', '',
              '## Every observation', '',
              '| Corpus / host | Slot | Qualified scans | Maximum covered gap (ms) | PSS (KiB) | Private (KiB) | Qualification failures |',
              '|---|---|---:|---:|---:|---:|---|']
    for row in results:
        for obs in row['observations']:
            lines.append(f"| {row['dictionary']} / {row['replication']} | {obs['name']} | {obs['stableFullyReadImportSampleCount']} | {obs['maximumCoveredSampleGapMs']} | {obs['maxSampledPssKiB']} | {obs['maxSampledPrivateKiB']} | {', '.join(obs['qualificationFailures']) or 'none'} |")
    lines += ['', 'The JSON retains all individual pair values, bracket gaps, raw counts, unavailable-read classifications, source identities and artifact digests. Raw scans, reports, receipts, source files and package manifests remain in each cell’s evidence directory. Temporary release ZIPs and only this audit’s verified outer download ZIPs were removed.', '',
              'PSS/private figures are non-atomic sampled process-tree observations, not exact memory peaks. This prior study is not pooled with or substituted into the current independent run `45647030792`.', '']
    (HERE / 'prior-memory-audit-summary.md').write_text('\n'.join(lines))


if __name__ == '__main__':
    main()
