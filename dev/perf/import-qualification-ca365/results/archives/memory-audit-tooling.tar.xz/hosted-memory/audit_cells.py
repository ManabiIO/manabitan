"""Independently bind and recompute all cells of the frozen memory campaign."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import statistics
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'qualification'
RUN_ID = 45647030792
HEAD = '7b021ebe3e7625a56ab9dde346ae72f3cd39b770'


def git_bytes(path, commit=HEAD):
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=REPO)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


PROTOCOL_BYTES = git_bytes('dev/perf/import-qualification-ca365.json')
PROTOCOL = json.loads(PROTOCOL_BYTES)
FIXTURE_BYTES = git_bytes('test/perf/dictionaries.lock.json', PROTOCOL['base'])
FIXTURES = json.loads(FIXTURE_BYTES)['dictionaries']
assert (REPO / 'dev/perf/benchmark-support.js').read_bytes() == git_bytes('dev/perf/benchmark-support.js', PROTOCOL['base'])
FROZEN = HERE / 'frozen-auditor'
FROZEN.mkdir(exist_ok=True)
for name in ('audit_memory.py', 'chromium_memory.py', 'overlay_helpers.py'):
    (FROZEN / name).write_bytes(git_bytes('dev/perf/import-memory-ca365/' + name))
(FROZEN / 'qualify.py').write_bytes(git_bytes('dev/perf/qualify-import-ca365.py'))
sys.path.insert(0, str(FROZEN))
from chromium_memory import summarize_import_window, tree_signature, confirmed_exited_zombie, GONE_ERRORS
from overlay_helpers import memory_overlay, schedule
spec = importlib.util.spec_from_file_location('frozen_study', FROZEN / 'qualify.py')
study = importlib.util.module_from_spec(spec)
spec.loader.exec_module(study)


def validate_scans(memory, markers):
    """Retain the frozen auditor's scan checks even for an incomplete cell."""
    assert memory['windowMarkers'] == markers
    previous_end = 0
    for sample in memory['samples']:
        start, end = sample['startedAtMonotonicNs'], sample['finishedAtMonotonicNs']
        assert type(start) is int and type(end) is int and previous_end <= start <= end
        previous_end = end
        before, after = sample['discoveryBefore'], sample['discoveryAfter']
        assert sample['stableObservedProcessTree'] == (tree_signature(before) == tree_signature(after))
        reads, unavailable = sample['processes'], sample['unavailableProcesses']
        assert len({p['pid'] for p in reads + unavailable}) == len(reads) + len(unavailable)
        assert {p['pid'] for p in before['processes']} == {p['pid'] for p in reads + unavailable}
        for metric, key in [('pssKiB', 'readableProcessPssKiB'), ('privateKiB', 'readableProcessPrivateKiB')]:
            assert all(type(p[metric]) is int and p[metric] >= 0 for p in reads)
            assert sample[key] == sum(p[metric] for p in reads)
        after_by_pid = {p['pid']: p for p in after['processes']}
        exited = {p['pid'] for p in unavailable if confirmed_exited_zombie(p, after_by_pid.get(p['pid']))}
        assert {p['pid'] for p in sample['confirmedExitedZombies']} == exited
        unreadable = [p for p in unavailable if p['pid'] not in exited]
        assert unreadable == sample['unreadableAddressSpaces']
        roles = {p['role'] for p in reads}
        assert sorted(roles) == sample['observedRoles']
        errors = before['inventoryIdentityReadErrors'] + after['inventoryIdentityReadErrors']
        reasons = []
        if not before['browserSeedPids']: reasons.append('no-browser-seed')
        if len(reads) < 2: reasons.append('no-multiple-process-coverage')
        if 'browser' not in roles: reasons.append('no-readable-browser-process')
        if 'renderer' not in roles: reasons.append('no-readable-renderer-process')
        if not sample['stableObservedProcessTree']: reasons.append('process-tree-changed-during-scan')
        if unreadable: reasons.append('unreadable-discovered-process-smaps')
        if any(e['errno'] not in GONE_ERRORS for e in errors): reasons.append('incomplete-process-identity-inventory')
        assert sample['qualificationFailures'] == reasons
        assert sample['qualifiedForWholeTreePss'] == (not reasons)
    assert summarize_import_window(memory['samples'], markers, memory['benchmarkExitCode']) == memory


def covered_gaps(memory, markers):
    """Retain every interval from the frozen coverage rule, not just its maximum."""
    if len(markers) != 2 or [row.get('event') for row in markers] != ['start', 'end']:
        return None
    start, end = [int(row['monotonicNs']) for row in markers]
    inside = [row for row in memory['samples'] if row['qualifiedForWholeTreePss'] and
              row['startedAtMonotonicNs'] >= start and row['finishedAtMonotonicNs'] <= end]
    points = [start] + [(row['startedAtMonotonicNs'] + row['finishedAtMonotonicNs']) // 2 for row in inside] + [end]
    gaps = [{'index': index, 'fromImportStartMs': (a - start) / 1e6,
             'toImportStartMs': (b - start) / 1e6, 'durationMs': (b - a) / 1e6}
            for index, (a, b) in enumerate(zip(points, points[1:]))]
    assert max(row['durationMs'] for row in gaps) == memory['maximumCoveredSampleGapMs']
    return gaps


def verify_cell_source(cell, candidate, dictionary, replication):
    evidence = cell / 'evidence'
    assert (evidence / 'protocol.json').read_bytes() == PROTOCOL_BYTES
    assert (evidence / 'executed-packager.py').read_bytes() == git_bytes('dev/perf/qualify-import-ca365.py')
    assert (evidence / 'executed-workflow.yml').read_bytes() == git_bytes('.github/workflows/import-memory-ca365.yml')
    for path in (evidence / 'observer-source').rglob('*'):
        if path.is_file():
            rel = path.relative_to(evidence / 'observer-source').as_posix()
            assert path.read_bytes() == git_bytes('dev/perf/import-memory-ca365/' + rel), rel
    original = git_bytes('test/chromium/extension-two-dictionary-import.e2e.js', PROTOCOL['base'])
    assert (evidence / 'original-harness.e2e.js').read_bytes() == original
    overlay = memory_overlay(original.decode()).encode()
    assert (evidence / 'memory-harness.e2e.js').read_bytes() == overlay
    plan = json.loads((evidence / 'plan.json').read_text())
    assert plan['candidate'] == candidate and plan['dictionary'] == dictionary and plan['replication'] == replication
    assert plan['workflowCommit'] == HEAD and int(plan['workflowRun']) == RUN_ID and int(plan['workflowAttempt']) == 1
    assert plan['config'] == PROTOCOL and plan['schedule'] == schedule(replication)
    assert plan['memoryOverlaySha256'] == sha(overlay) and plan['originalHarnessSha256'] == sha(original)
    assert plan['authoritativeTiming'] is False
    assert plan['promotionCriteria'] == {'maximumMedianPairedIncreasePercent': 5, 'maximumIndividualPairedIncreasePercent': 10, 'everyObservationQualified': True}
    assert plan['frozenCoverage'] == {'minimumFullyCoveredImportScans': 5, 'maximumCoveredGapMs': 250, 'maximumBracketGapMs': 250, 'betweenScanWaitMs': 25}
    assert json.loads((evidence / 'fixture.json').read_text()) == FIXTURES[dictionary]
    receipts = {arm: json.loads((evidence / f'package-memory-{arm}-receipt.json').read_text()) for arm in ('A', 'B')}
    assert receipts['A']['harnessSha256'] == receipts['B']['harnessSha256']
    return plan, receipts, sha(overlay)


NODE_VALIDATE = r"""
import fs from 'node:fs'
import {pathToFileURL} from 'node:url'
const [repo, fixturePath, dictionary, ...reports] = process.argv.slice(1)
const {extractImportResult} = await import(pathToFileURL(repo + '/dev/perf/benchmark-support.js'))
const fixture = JSON.parse(fs.readFileSync(fixturePath, 'utf8'))
const values = reports.map(path => ({path, ...extractImportResult(JSON.parse(fs.readFileSync(path, 'utf8')), dictionary, fixture, false, null, 'all')}))
console.log(JSON.stringify(values))
"""


def audit_cell(cell, candidate, dictionary, replication):
    evidence = cell / 'evidence'
    extraction = json.loads((cell / 'extraction.json').read_text())
    result = {'candidate': candidate, 'dictionary': dictionary, 'replication': replication,
              'artifactId': extraction['artifactId'], 'artifactSha256': extraction['artifactSha256'],
              'artifactBytes': extraction['artifactBytes'], 'workflowHead': HEAD, 'runId': RUN_ID,
              'candidateCommit': PROTOCOL['candidates'][candidate]['commit'], 'baseCommit': PROTOCOL['base'],
              'sourceBindingVerified': False, 'independentFrozenAuditor': None,
              'observations': [], 'pairs': [], 'verificationErrors': [], 'semanticFailures': []}
    try:
        plan, receipts, overlay_hash = verify_cell_source(cell, candidate, dictionary, replication)
        result['sourceBindingVerified'] = True
    except Exception as error:
        result['verificationErrors'].append(f'Source binding: {type(error).__name__}: {error}')
        plan, receipts, overlay_hash = {'schedule': schedule(replication)}, {}, None
    semantic = None
    for item in plan['schedule']:
        folder = evidence / item['name']
        row = {**item, 'acquired': False, 'qualified': False, 'semanticPassed': False,
               'maxSampledPssKiB': None, 'maxSampledPrivateKiB': None,
               'qualificationFailures': [], 'rawScanCount': 0}
        if not (folder / 'memory.json').exists():
            row['qualificationFailures'] = ['observation-not-acquired']
            if (folder / 'acquisition-failure.json').exists():
                row['acquisitionFailure'] = json.loads((folder / 'acquisition-failure.json').read_text())
            result['observations'].append(row)
            continue
        memory = json.loads((folder / 'memory.json').read_text())
        markers = [json.loads(line) for line in (folder / 'markers.jsonl').read_text().splitlines() if line] if (folder / 'markers.jsonl').exists() else []
        try:
            validate_scans(memory, markers)
            row['coveredSampleGaps'] = covered_gaps(memory, markers)
            row['coveredGapViolations'] = [gap for gap in row['coveredSampleGaps'] or [] if gap['durationMs'] > 250]
            row['rawRecomputed'] = True
        except Exception as error:
            row['rawRecomputed'] = False
            result['verificationErrors'].append(f"{item['name']} raw scans: {type(error).__name__}: {error}")
        for key in ['maxSampledPssKiB', 'maxSampledPrivateKiB', 'qualificationFailures', 'benchmarkExitCode',
                    'stableFullyReadImportSampleCount', 'preImportBracketGapMs', 'postImportBracketGapMs',
                    'maximumCoveredSampleGapMs', 'windowDurationMs', 'allObservedSampleCount']:
            row[key] = memory.get(key)
        row.update({'acquired': True, 'qualified': memory['qualifiedForWholeTreePss'], 'rawScanCount': len(memory['samples'])})
        try:
            report = json.loads((folder / 'run-1.json').read_text())
            summary = json.loads((folder / 'summary.json').read_text())
            receipt = receipts[item['arm']]
            assert report['packageSha256'] == receipt['packageSha256'] and report['browserVersion'] == PROTOCOL['browserVersion']
            assert len(summary['runs']) == 1 and summary['gitSha'] == receipt['sourceCommit']
            assert summary['schemaVersion'] == 3 and summary['dictionary'] == dictionary
            assert summary['buildTarget'] == 'chrome' and summary['mediaCheck'] == 'all'
            assert summary['traceEnabled'] is False and summary['importFlags'] is None
            assert summary['hostEnvironment']['nodeVersion'] == 'v22.22.0'
            assert summary['browserVersion'] == PROTOCOL['browserVersion']
            assert summary['runs'][0]['packageSha256'] == receipt['packageSha256']
            assert summary['source']['gitSha'] == receipt['sourceCommit']
            assert summary['source']['dirty'] is True
            assert summary['source']['sha256']['builds/manabitan-chrome.zip'] == receipt['packageSha256']
            for name, value in summary['source']['sha256'].items():
                if name in receipt['harnessSha256']:
                    expected = overlay_hash if name == 'test/chromium/extension-two-dictionary-import.e2e.js' else receipt['harnessSha256'][name]
                    assert value == expected, name
            assert summary['source']['sha256']['test/chromium/extension-two-dictionary-import.e2e.js'] == overlay_hash
            assert summary['fixture'] == FIXTURES[dictionary]
            current = study.semantic_receipt(report)
            media = current['media']
            assert media['mode'] == 'all' and media['files'] == media['totalFiles'] == FIXTURES[dictionary]['mediaFiles']
            assert media['bytes'] == media['totalBytes'] == FIXTURES[dictionary]['mediaBytes']
            assert semantic is None or current == semantic
            semantic = current
            if (folder / 'semantic-receipt.json').exists():
                assert json.loads((folder / 'semantic-receipt.json').read_text()) == current
            assert memory['windowDurationMs'] is not None and memory['windowDurationMs'] >= summary['runs'][0]['totalImportMs']
            subprocess.run(['node', '--input-type=module', '-e', NODE_VALIDATE, str(REPO), str(evidence / 'fixture.json'), dictionary, str(folder / 'run-1.json')], check=True, capture_output=True, text=True)
            row['semanticPassed'] = True
            row['lookupReceipts'] = len(report['benchmark']['validation']['lookup']['observations'])
            row['mediaFiles'] = media['files']
            row['mediaBytes'] = media['bytes']
        except Exception as error:
            message = f"{item['name']}: {type(error).__name__}: {error}"
            result['semanticFailures'].append(message)
            row['semanticFailure'] = message
        result['observations'].append(row)
    result['semanticReceiptSha256'] = sha(json.dumps(semantic, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()) if semantic is not None else None
    # Replay the unmodified frozen auditor in a view of original evidence. Its
    # output stays separate from the CI-generated audit receipt.
    replay = cell / 'independent-replay'
    replay.mkdir(exist_ok=True)
    for item in evidence.iterdir():
        link = replay / item.name
        if item.name != 'memory-audit.json' and not link.exists():
            link.symlink_to(item)
    command = subprocess.run(['python3', str(FROZEN / 'audit_memory.py'), str(replay)], capture_output=True, text=True)
    (cell / 'independent-audit.log').write_text(command.stdout + command.stderr)
    result['independentFrozenAuditor'] = {'exitCode': command.returncode, 'completed': command.returncode == 0}
    if command.returncode == 0:
        replayed = json.loads((replay / 'memory-audit.json').read_text())
        result['independentFrozenAuditor']['result'] = replayed
        if (evidence / 'memory-audit.json').exists() and json.loads((evidence / 'memory-audit.json').read_text()) != replayed:
            result['verificationErrors'].append('Frozen auditor output differs from retained CI audit')
    elif all(row['acquired'] for row in result['observations']) and (evidence / 'memory-comparison.json').exists():
        result['verificationErrors'].append('Frozen full-cell auditor failed; inspect independent-audit.log')
    qualified = all(row['acquired'] and row['qualified'] for row in result['observations'])
    for pair_id in (1, 2):
        pair_rows = {row['arm']: row for row in result['observations'] if row['pair'] == pair_id}
        pair_qualified = all(row['acquired'] and row['qualified'] for row in pair_rows.values())
        pair = {'pair': pair_id, 'qualified': pair_qualified}
        for metric in ('maxSampledPssKiB', 'maxSampledPrivateKiB'):
            a, b = pair_rows['A'][metric], pair_rows['B'][metric]
            pair[metric] = {'baseline': a, 'candidate': b, 'changePercent': 100 * (b / a - 1) if pair_qualified and a > 0 else None}
        result['pairs'].append(pair)
    result['metrics'] = {}
    for metric in ('maxSampledPssKiB', 'maxSampledPrivateKiB'):
        values = [row[metric]['changePercent'] for row in result['pairs']]
        result['metrics'][metric] = {'medianPairedChangePercent': statistics.median(values) if qualified else None,
                                     'maximumPairedChangePercent': max(values) if qualified else None}
    numeric_pass = qualified and all(row['medianPairedChangePercent'] <= 5 and row['maximumPairedChangePercent'] <= 10 for row in result['metrics'].values())
    result.update({'acquiredObservations': sum(row['acquired'] for row in result['observations']),
                   'qualifiedObservations': sum(row['qualified'] for row in result['observations']),
                   'semanticObservations': sum(row['semanticPassed'] for row in result['observations']),
                   'rawScanCount': sum(row['rawScanCount'] for row in result['observations']),
                   'everyObservationQualified': qualified, 'passesNumericMemoryBounds': numeric_pass})
    if result['verificationErrors']:
        result['classification'] = 'evidence verification failure'
    elif result['acquiredObservations'] < 4:
        result['classification'] = 'acquisition incomplete'
    elif result['semanticFailures']:
        result['classification'] = 'semantic or import validation failure'
    elif not qualified:
        result['classification'] = 'coverage failure'
    elif not numeric_pass:
        result['classification'] = 'measured threshold breach'
    else:
        result['classification'] = 'pass'
    result['passesFullMemoryQualification'] = result['classification'] == 'pass'
    if (evidence / 'failure-status.json').exists():
        result['retainedFailureStatus'] = json.loads((evidence / 'failure-status.json').read_text())
    save(cell / 'independent-result.json', result)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('cell', nargs='*')
    args = parser.parse_args()
    selected = set(args.cell)
    for candidate in PROTOCOL['candidates']:
        for dictionary in ('jmdict', 'jitendex', 'vndb'):
            for replication in (1, 2):
                name = f'{candidate}-{dictionary}-{replication}'
                if selected and name not in selected:
                    continue
                cell = HERE / name
                if not (cell / 'extraction.json').exists():
                    continue
                result = audit_cell(cell, candidate, dictionary, replication)
                print(json.dumps({key: result[key] for key in ('candidate', 'dictionary', 'replication', 'classification', 'qualifiedObservations', 'rawScanCount', 'metrics', 'verificationErrors', 'semanticFailures')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
