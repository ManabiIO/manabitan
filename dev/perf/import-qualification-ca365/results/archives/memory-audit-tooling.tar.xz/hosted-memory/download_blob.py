import hashlib
import json
from pathlib import Path
import sys
import urllib.request

url, target, digest, size = sys.argv[1:]
path = Path(target)
path.parent.mkdir(parents=True, exist_ok=True)
hasher = hashlib.sha256()
count = 0
with urllib.request.urlopen(url, timeout=60) as source, path.open('xb') as output:
    while block := source.read(1024 * 1024):
        output.write(block)
        hasher.update(block)
        count += len(block)
if hasher.hexdigest() != digest.removeprefix('sha256:') or count != int(size):
    raise RuntimeError('Artifact archive hash/size mismatch')
print(json.dumps({'file': str(path), 'sha256': hasher.hexdigest(), 'bytes': count}))
