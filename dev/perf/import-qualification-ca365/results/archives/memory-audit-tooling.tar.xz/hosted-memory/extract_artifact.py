"""Verify one frozen Actions archive, retain evidence, and discard release ZIPs."""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'qualification'
RUN_ID = 45647030792
HEAD = '7b021ebe3e7625a56ab9dde346ae72f3cd39b770'
PROTOCOL = json.loads(subprocess.check_output(['git', 'show', f'{HEAD}:dev/perf/import-qualification-ca365.json'], cwd=REPO))
RETAIN_PACKAGE_MEMBERS = {
    'manifest.json',
    'js/dictionary/dictionary-importer.js',
    'js/dictionary/term-bank-wasm-parser-worker.js',
    'js/dictionary/term-bank-wasm-parser.js',
    'js/dictionary/wasm/term-bank-parser.c',
    'lib/term-bank-parser.wasm',
    'lib/term-content-canonical-scan-v1.wasm',
}


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def hash_stream(source):
    digest = hashlib.sha256()
    size = 0
    while block := source.read(1024 * 1024):
        size += len(block)
        digest.update(block)
    return digest.hexdigest(), size


def read_git(commit, name):
    return subprocess.check_output(['git', 'show', f'{commit}:{name}'], cwd=REPO)


def package_binding(archive, entry, evidence, result_root, arm, commit):
    with archive.open(entry) as source:
        package_hash, package_size = hash_stream(source)
    receipt_name = f'package-memory-{arm}-receipt.json'
    members_name = f'package-memory-{arm}-members.json'
    receipt = json.loads(archive.read(receipt_name))
    reported_members = json.loads(archive.read(members_name))
    if receipt['sourceCommit'] != commit or receipt['packageSha256'] != package_hash:
        raise RuntimeError(f'{arm}: source/package receipt mismatch')
    tree = subprocess.check_output(['git', 'rev-parse', f'{commit}^{{tree}}'], cwd=REPO, text=True).strip()
    if receipt['sourceTree'] != tree:
        raise RuntimeError(f'{arm}: source tree mismatch')
    # Keep the compressed inner release temporarily in memory; never write it
    # to the workspace. Hash every decompressed member independently.
    with zipfile.ZipFile(io.BytesIO(archive.read(entry))) as package:
        infos = [item for item in package.infolist() if not item.is_dir()]
        if len(infos) != len({item.filename for item in infos}):
            raise RuntimeError(f'{arm}: duplicate release member')
        actual_members = {}
        for member in infos:
            with package.open(member) as source:
                actual_members[member.filename] = hash_stream(source)[0]
            if member.filename in RETAIN_PACKAGE_MEMBERS:
                target = result_root / arm / member.filename
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(package.read(member))
        if actual_members != reported_members or receipt['memberCount'] != len(actual_members):
            raise RuntimeError(f'{arm}: release member receipt mismatch')
        native_manifest = json.loads(read_git(commit, 'dev/data/dictionary-wasm/manifest.json'))
        save(result_root / arm / 'native-manifest.json', native_manifest)
        for target in native_manifest['targets']:
            if actual_members['lib/' + target['name']] != target['sha256']:
                raise RuntimeError(f'{arm}: native artifact does not match own manifest')
        for name in RETAIN_PACKAGE_MEMBERS:
            if name.startswith('js/') and package.read(name) != read_git(commit, 'ext/' + name):
                raise RuntimeError(f'{arm}: packaged source differs from frozen commit: {name}')
    for name, expected in receipt['harnessSha256'].items():
        if hashlib.sha256(read_git(commit, name)).hexdigest() != expected:
            raise RuntimeError(f'{arm}: harness source hash mismatch: {name}')
    return {'sourceCommit': commit, 'sourceTree': tree, 'packageSha256': package_hash,
            'packageBytes': package_size, 'memberCount': len(actual_members),
            'allMembersVerified': True, 'ownNativeManifestVerified': True,
            'sourceAndHarnessVerified': True, 'members': actual_members}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('archive', type=Path)
    parser.add_argument('metadata', type=Path)
    args = parser.parse_args()
    artifact = json.loads(args.metadata.read_text())
    archive = args.archive.resolve()
    if archive.parent != (HERE / 'downloads').resolve() or archive.name != f"artifact-{artifact['id']}.zip":
        raise RuntimeError('Only this audit\'s explicitly named downloaded ZIP may be deleted')
    with archive.open('rb') as stream:
        actual_hash, actual_size = hash_stream(stream)
    expected_hash = artifact.get('digest', '').removeprefix('sha256:')
    if len(expected_hash) != 64 or actual_hash != expected_hash or actual_size != artifact['size_in_bytes']:
        raise RuntimeError('Downloaded artifact fails GitHub size/SHA-256 identity')
    run = artifact.get('workflow_run', {})
    if run.get('id') != RUN_ID or run.get('head_sha') != HEAD:
        raise RuntimeError('Artifact belongs to another run or workflow head')
    prefix = 'import-memory-ca365-'
    if not artifact['name'].startswith(prefix):
        raise RuntimeError('Unexpected artifact name')
    cell_name = artifact['name'][len(prefix):]
    candidate, dictionary, replica_text = cell_name.rsplit('-', 2)
    replica = int(replica_text)
    if candidate not in PROTOCOL['candidates'] or dictionary not in ('jmdict', 'jitendex', 'vndb') or replica not in (1, 2):
        raise RuntimeError('Unexpected candidate/corpus/replica')
    cell = HERE / cell_name
    cell.mkdir(exist_ok=False)
    save(cell / 'artifact-metadata.json', artifact)
    evidence = cell / 'evidence'
    evidence.mkdir()
    bindings = {}
    inventory = []
    with zipfile.ZipFile(archive) as zipped:
        names = [entry.filename for entry in zipped.infolist()]
        if len(names) != len(set(names)):
            raise RuntimeError('Duplicate artifact path')
        for entry in zipped.infolist():
            path = PurePosixPath(entry.filename)
            if path.is_absolute() or '..' in path.parts or (entry.external_attr >> 16) & 0o170000 == 0o120000:
                raise RuntimeError(f'Unsafe artifact entry: {entry.filename}')
            if entry.is_dir():
                continue
            with zipped.open(entry) as source:
                digest, size = hash_stream(source)
            inventory.append({'path': entry.filename, 'sha256': digest, 'bytes': size})
            if entry.filename.startswith('package-memory-') and entry.filename.endswith('.zip'):
                arm = entry.filename.removeprefix('package-memory-').removesuffix('.zip')
                if arm not in ('A', 'B'):
                    raise RuntimeError('Unexpected release arm')
                commit = PROTOCOL['base'] if arm == 'A' else PROTOCOL['candidates'][candidate]['commit']
                bindings[arm] = package_binding(zipped, entry, evidence, cell / 'package-source', arm, commit)
                continue
            destination = evidence / path
            destination.parent.mkdir(parents=True, exist_ok=True)
            with zipped.open(entry) as source, destination.open('wb') as target:
                shutil.copyfileobj(source, target, 1024 * 1024)
        if bindings:
            if set(bindings) != {'A', 'B'}:
                # Setup failures may publish only the first complete package.
                bindings['incomplete'] = True
            else:
                delta = sorted(name for name in bindings['A']['members'].keys() | bindings['B']['members'].keys()
                               if bindings['A']['members'].get(name) != bindings['B']['members'].get(name))
                if delta != sorted(PROTOCOL['candidates'][candidate]['packagedDelta']):
                    raise RuntimeError(f'Package allowlist differs: {delta}')
                if json.loads((evidence / 'package-delta.json').read_text()) != delta:
                    raise RuntimeError('Recorded package delta differs')
                bindings['exactPackagedDelta'] = delta
    save(cell / 'archive-entry-manifest.json', inventory)
    save(cell / 'package-binding.json', bindings)
    save(cell / 'extraction.json', {'artifactId': artifact['id'], 'artifactName': artifact['name'],
                                  'artifactSha256': actual_hash, 'artifactBytes': actual_size,
                                  'runId': RUN_ID, 'workflowHead': HEAD,
                                  'candidate': candidate, 'dictionary': dictionary, 'replication': replica,
                                  'allArchiveEntriesReadAndHashed': True,
                                  'releaseZipsRetained': False, 'sourceArchiveDeleted': True})
    # Delete only the exact newly downloaded file after every verification and
    # extraction step succeeded; no pre-existing workspace archive is touched.
    archive.unlink()
    print(json.dumps({'cell': cell_name, 'artifactId': artifact['id'], 'archiveSha256': actual_hash,
                      'entries': len(inventory), 'packages': [k for k in bindings if k in ('A', 'B')]}))


if __name__ == '__main__':
    main()
