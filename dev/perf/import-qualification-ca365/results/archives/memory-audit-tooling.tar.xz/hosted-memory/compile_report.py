"""Produce complete, unpooled receipts for every scheduled memory cell/slot."""
import json
from datetime import datetime, timezone
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'qualification'
RUN_ID = 45647030792
HEAD = '7b021ebe3e7625a56ab9dde346ae72f3cd39b770'
PROTOCOL = json.loads(subprocess.check_output(['git', 'show', f'{HEAD}:dev/perf/import-qualification-ca365.json'], cwd=REPO))


def fixed_schedule(replica):
    counts = {'A': 0, 'B': 0}
    values = []
    for index, arm in enumerate('ABBA' if replica == 1 else 'BAAB', 1):
        counts[arm] += 1
        values.append({'index': index, 'arm': arm, 'name': f'{arm}{counts[arm]}', 'pair': (index - 1) // 2 + 1})
    return values


polls = sorted(HERE.glob('poll-*-jobs.json'))
jobs = json.loads(polls[-1].read_text())['jobs'] if polls else []
job_by_name = {row['name']: row for row in jobs}
cells = []
for candidate in PROTOCOL['candidates']:
    for dictionary in ('jmdict', 'jitendex', 'vndb'):
        for replica in (1, 2):
            name = f'{candidate}-{dictionary}-{replica}'
            folder = HERE / name
            job = job_by_name.get(f'{candidate} memory {dictionary} host {replica}', {})
            if (folder / 'independent-result.json').exists():
                result = json.loads((folder / 'independent-result.json').read_text())
            else:
                finished = job.get('status') == 'completed'
                result = {'candidate': candidate, 'dictionary': dictionary, 'replication': replica,
                          'classification': 'missing retained artifact' if finished else 'pending',
                          'artifactId': None, 'artifactSha256': None, 'acquiredObservations': 0,
                          'qualifiedObservations': 0, 'semanticObservations': 0, 'rawScanCount': 0,
                          'metrics': {key: {'medianPairedChangePercent': None, 'maximumPairedChangePercent': None}
                                      for key in ('maxSampledPssKiB', 'maxSampledPrivateKiB')},
                          'passesFullMemoryQualification': False if finished else None,
                          'observations': [{**row, 'acquired': False, 'qualified': False,
                                            'maxSampledPssKiB': None, 'maxSampledPrivateKiB': None,
                                            'qualificationFailures': ['not-acquired'] if finished else ['pending'],
                                            'rawScanCount': 0} for row in fixed_schedule(replica)]}
            result['jobId'] = job.get('id')
            result['jobStatus'] = job.get('status')
            result['jobConclusion'] = job.get('conclusion')
            result['runnerId'] = job.get('runner_id')
            result['runnerName'] = job.get('runner_name')
            if job.get('status') == 'completed' and result['classification'] == 'pass' and job.get('conclusion') != 'success':
                result['operationalFailureAfterValidAcquisition'] = True
            cells.append(result)

complete = len(jobs) == 12 and all(row.get('status') == 'completed' for row in jobs)
result = {'schemaVersion': 1, 'runId': RUN_ID, 'runUrl': f'https://github.com/ManabiIO/manabitan/actions/runs/{RUN_ID}',
          'auditUpdatedAtUtc': datetime.now(timezone.utc).isoformat(),
          'latestJobsSnapshot': polls[-1].name if polls else None,
          'workflowHead': HEAD, 'baseCommit': PROTOCOL['base'],
          'candidateCommits': {name: data['commit'] for name, data in PROTOCOL['candidates'].items()},
          'allJobsCompleted': complete, 'scheduledCells': 12, 'scheduledObservations': 48,
          'acquiredObservations': sum(row['acquiredObservations'] for row in cells),
          'qualifiedObservations': sum(row['qualifiedObservations'] for row in cells),
          'semanticObservations': sum(row['semanticObservations'] for row in cells),
          'rawScansAudited': sum(row['rawScanCount'] for row in cells),
          'protocol': {'medianPairedMaximumIncreasePercent': 5, 'individualPairMaximumIncreasePercent': 10,
                       'requiresEveryObservationQualified': True, 'minimumFullyCoveredImportScans': 5,
                       'maximumCoveredGapMs': 250, 'maximumBracketGapMs': 250, 'betweenScanWaitMs': 25},
          'scope': 'Non-atomic sampled Chromium process-tree PSS/private maxima inside the marked import window; not exact peaks or timing evidence.',
          'cohortIsolation': 'Only run 45647030792, attempt 1, head 7b021ebe3e7625a56ab9dde346ae72f3cd39b770. No observations replaced, excluded or pooled with another campaign, including run 45642179064.',
          'candidates': {}, 'cells': cells}
result['crossCellSemanticEquality'] = {}
result['coveredGapViolations'] = [
    {'candidate': cell['candidate'], 'dictionary': cell['dictionary'], 'replication': cell['replication'],
     'observation': observation['name'], **gap}
    for cell in cells for observation in cell['observations'] for gap in observation.get('coveredGapViolations', [])
]
result['qualifiedPairThresholdBreaches'] = [
    {'candidate': cell['candidate'], 'dictionary': cell['dictionary'], 'replication': cell['replication'],
     'pair': pair['pair'], 'metric': metric, 'changePercent': pair[metric]['changePercent']}
    for cell in cells for pair in cell.get('pairs', []) for metric in ('maxSampledPssKiB', 'maxSampledPrivateKiB')
    if pair['qualified'] and pair[metric]['changePercent'] > 10
]
result['coverageFailedObservations'] = sum(
    observation['acquired'] and not observation['qualified']
    for cell in cells for observation in cell['observations']
)
result['coveredGapViolationCount'] = len(result['coveredGapViolations'])
result['distinctAssignedRunners'] = len({cell['runnerId'] for cell in cells if cell['runnerId']})
result['cellClassifications'] = {label: sum(cell['classification'] == label for cell in cells)
                               for label in sorted({cell['classification'] for cell in cells})}
result['evidenceVerificationErrors'] = [error for cell in cells for error in cell.get('verificationErrors', [])]
result['semanticValidationFailures'] = [error for cell in cells for error in cell.get('semanticFailures', [])]
for dictionary in ('jmdict', 'jitendex', 'vndb'):
    hashes = {row.get('semanticReceiptSha256') for row in cells if row['dictionary'] == dictionary and row.get('semanticReceiptSha256') is not None}
    result['crossCellSemanticEquality'][dictionary] = {'distinctReceipts': len(hashes), 'matches': len(hashes) <= 1,
                                                      'sha256': next(iter(hashes)) if len(hashes) == 1 else None}
for candidate in PROTOCOL['candidates']:
    chosen = [row for row in cells if row['candidate'] == candidate]
    pending = any(row['classification'] == 'pending' for row in chosen)
    result['candidates'][candidate] = {'passesFullMemoryQualification': None if pending else all(row['passesFullMemoryQualification'] for row in chosen),
                                     'passesBothHostsByDictionary': {
                                         dictionary: None if any(row['classification'] == 'pending' for row in chosen if row['dictionary'] == dictionary)
                                         else all(row['passesFullMemoryQualification'] for row in chosen if row['dictionary'] == dictionary)
                                         for dictionary in ('jmdict', 'jitendex', 'vndb')},
                                     'classifications': {row['dictionary'] + '-' + str(row['replication']): row['classification'] for row in chosen}}
(HERE / 'memory-audit-summary.json').write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')


def number(value, digits=3):
    return '—' if value is None else f'{value:.{digits}f}'


def change(metric):
    if metric['medianPairedChangePercent'] is None:
        return 'Unqualified / unavailable'
    return f"{metric['medianPairedChangePercent']:+.3f}% / {metric['maximumPairedChangePercent']:+.3f}%"


lines = [
    '# Frozen memory qualification audit', '',
    f"[Run {RUN_ID}]({result['runUrl']}) · workflow head `{HEAD}` · attempt 1", '',
    f"Baseline `{PROTOCOL['base']}`. Metadata candidate `{PROTOCOL['candidates']['metadata-witness']['commit']}`. Native projection candidate `{PROTOCOL['candidates']['native-projection']['commit']}`.", '',
    f"Scheduled: 12 cells / 48 observations. Acquired: {result['acquiredObservations']}; qualified: {result['qualifiedObservations']}; semantic checks passed: {result['semanticObservations']}; raw scans audited: {result['rawScansAudited']}.", '',
    f"Cell classifications: {', '.join(f'{count} {label}' for label, count in result['cellClassifications'].items())}. Complete candidate qualification: {', '.join(name + '=' + str(value['passesFullMemoryQualification']).lower() for name, value in result['candidates'].items())}.", '',
    f"Coverage-failed observations: {result['coverageFailedObservations']}; covered intervals above 250 ms: {result['coveredGapViolationCount']}. Qualified individual pairs above the +10% limit: {len(result['qualifiedPairThresholdBreaches'])}. Evidence verification errors: {len(result['evidenceVerificationErrors'])}; semantic validation failures: {len(result['semanticValidationFailures'])}.", '',
    result['scope'], '', result['cohortIsolation'], '',
    '## Cell results', '',
    'PSS/private columns show median paired change / largest individual paired change. The fixed limits are +5% / +10%, and every observation must qualify. An unqualified maximum is missing, never zero.', '',
    '| Candidate | Corpus | Host | Qualified | PSS median / largest | Private median / largest | Classification | Artifact |',
    '|---|---|---:|---:|---:|---:|---|---|',
]
for cell in cells:
    artifact = f"`{cell['artifactId']}`" if cell['artifactId'] is not None else '—'
    lines.append(f"| {cell['candidate']} | {cell['dictionary']} | {cell['replication']} | {cell['qualifiedObservations']}/4 | {change(cell['metrics']['maxSampledPssKiB'])} | {change(cell['metrics']['maxSampledPrivateKiB'])} | {cell['classification']} | {artifact} |")
lines += ['', '## Every scheduled observation', '',
          'All gaps are milliseconds. Blank unavailable maxima and gaps are shown as em dashes. Slot order is fixed ABBA for host 1 and BAAB for host 2.', '',
          '| Candidate / corpus / host | Slot | Qualified | PSS KiB | Private KiB | Covered scans | Largest covered gap | Pre / post bracket | Failure reasons |',
          '|---|---|---|---:|---:|---:|---:|---:|---|']
for cell in cells:
    label = f"{cell['candidate']} / {cell['dictionary']} / {cell['replication']}"
    for row in cell['observations']:
        brackets = f"{number(row.get('preImportBracketGapMs'))} / {number(row.get('postImportBracketGapMs'))}"
        reasons = ', '.join(row.get('qualificationFailures') or []) or 'None'
        if row.get('semanticFailure'):
            reasons += '; ' + row['semanticFailure'].replace('|', '/')
        lines.append(f"| {label} | {row['name']} | {'yes' if row['qualified'] else 'no'} | {number(row.get('maxSampledPssKiB'), 0)} | {number(row.get('maxSampledPrivateKiB'), 0)} | {row.get('stableFullyReadImportSampleCount', '—')} | {number(row.get('maximumCoveredSampleGapMs'))} | {brackets} | {reasons} |")
lines += ['', '## Every covered gap exceeding 250 ms', '',
          'These are all intervals over the frozen limit, in observation order. Each interval joins the import boundary or a fully covered scan midpoint. The JSON also retains every interval below the limit and its position relative to import start.', '',
          '| Candidate / corpus / host | Observation | Gap index | Duration (ms) | From / to import start (ms) |',
          '|---|---|---:|---:|---:|']
for gap in result['coveredGapViolations']:
    label = f"{gap['candidate']} / {gap['dictionary']} / {gap['replication']}"
    lines.append(f"| {label} | {gap['observation']} | {gap['index']} | {gap['durationMs']:.6f} | {gap['fromImportStartMs']:.6f} / {gap['toImportStartMs']:.6f} |")
if not result['coveredGapViolations']:
    lines.append('| None among acquired observations | — | — | — | — |')
lines += ['', '## Evidence binding', '',
          'Downloaded archives are checked against GitHub artifact ID, run/head identity, byte size and SHA-256. Every embedded package member is independently hashed; source commits, source trees, own native manifests, exact package allowlists, fixture locks, original/overlaid harnesses and observer bytes are bound to the frozen source. Release ZIPs are not retained locally. Original raw scans and CI audit receipts remain intact; independent replay output is separate.', '',
          f"All acquired observations use pinned Node 22.22.0 and Chromium {PROTOCOL['browserVersion']}. The scheduled jobs have {result['distinctAssignedRunners']} distinct GitHub runner identities. The source-media validation mode is exhaustive, with all 72 public lookup receipts and restart validation retained per observation. Semantic receipt hashes match across every acquired arm and host within each corpus.", '',
          '| Cell | Artifact ID | Archive bytes | SHA-256 |', '|---|---:|---:|---|']
for cell in cells:
    if cell['artifactId'] is not None:
        lines.append(f"| {cell['candidate']} / {cell['dictionary']} / {cell['replication']} | {cell['artifactId']} | {cell['artifactBytes']} | `{cell['artifactSha256']}` |")
errors = [(f"{cell['candidate']}/{cell['dictionary']}/{cell['replication']}", error) for cell in cells for error in cell.get('verificationErrors', [])]
if errors:
    lines += ['', '## Verification errors requiring investigation', '']
    lines += [f'- {cell}: {error}' for cell, error in errors]
(HERE / 'memory-audit-summary.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({key: result[key] for key in ('allJobsCompleted', 'scheduledCells', 'scheduledObservations', 'acquiredObservations', 'qualifiedObservations', 'rawScansAudited', 'candidates')}, indent=2))
