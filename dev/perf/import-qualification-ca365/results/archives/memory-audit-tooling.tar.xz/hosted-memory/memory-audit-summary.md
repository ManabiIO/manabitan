# Frozen memory qualification audit

[Run 45647030792](https://github.com/ManabiIO/manabitan/actions/runs/45647030792) · workflow head `7b021ebe3e7625a56ab9dde346ae72f3cd39b770` · attempt 1

Baseline `7d1643e6147a10cb2165e9744cf0e63b59e46632`. Metadata candidate `11bf4550a26e98ccc3df1579da7444244fe1e861`. Native projection candidate `5afd2e97ec2707b150acfde61115aee688547a78`.

Scheduled: 12 cells / 48 observations. Acquired: 48; qualified: 42; semantic checks passed: 48; raw scans audited: 4985.

Cell classifications: 4 coverage failure, 8 pass. Complete candidate qualification: metadata-witness=false, native-projection=false.

Coverage-failed observations: 6; covered intervals above 250 ms: 19. Qualified individual pairs above the +10% limit: 0. Evidence verification errors: 0; semantic validation failures: 0.

Non-atomic sampled Chromium process-tree PSS/private maxima inside the marked import window; not exact peaks or timing evidence.

Only run 45647030792, attempt 1, head 7b021ebe3e7625a56ab9dde346ae72f3cd39b770. No observations replaced, excluded or pooled with another campaign, including run 45642179064.

## Cell results

PSS/private columns show median paired change / largest individual paired change. The fixed limits are +5% / +10%, and every observation must qualify. An unqualified maximum is missing, never zero.

| Candidate | Corpus | Host | Qualified | PSS median / largest | Private median / largest | Classification | Artifact |
|---|---|---:|---:|---:|---:|---|---|
| metadata-witness | jmdict | 1 | 3/4 | Unqualified / unavailable | Unqualified / unavailable | coverage failure | `15041125557` |
| metadata-witness | jmdict | 2 | 4/4 | -0.033% / +0.074% | +0.048% / +0.276% | pass | `15040996373` |
| metadata-witness | jitendex | 1 | 4/4 | -2.159% / +0.242% | -2.590% / +0.587% | pass | `15041745094` |
| metadata-witness | jitendex | 2 | 4/4 | +1.938% / +2.043% | +2.401% / +3.046% | pass | `15041181349` |
| metadata-witness | vndb | 1 | 3/4 | Unqualified / unavailable | Unqualified / unavailable | coverage failure | `15042550092` |
| metadata-witness | vndb | 2 | 1/4 | Unqualified / unavailable | Unqualified / unavailable | coverage failure | `15041903599` |
| native-projection | jmdict | 1 | 4/4 | +1.135% / +2.222% | +1.236% / +2.510% | pass | `15040146032` |
| native-projection | jmdict | 2 | 4/4 | +0.344% / +3.439% | -0.008% / +3.774% | pass | `15039704465` |
| native-projection | jitendex | 1 | 4/4 | -0.489% / +1.549% | -0.643% / +1.945% | pass | `15038564647` |
| native-projection | jitendex | 2 | 3/4 | Unqualified / unavailable | Unqualified / unavailable | coverage failure | `15039624007` |
| native-projection | vndb | 1 | 4/4 | +0.725% / +2.042% | +0.667% / +1.997% | pass | `15040639037` |
| native-projection | vndb | 2 | 4/4 | +0.087% / +3.074% | +0.175% / +3.671% | pass | `15042975244` |

## Every scheduled observation

All gaps are milliseconds. Blank unavailable maxima and gaps are shown as em dashes. Slot order is fixed ABBA for host 1 and BAAB for host 2.

| Candidate / corpus / host | Slot | Qualified | PSS KiB | Private KiB | Covered scans | Largest covered gap | Pre / post bracket | Failure reasons |
|---|---|---|---:|---:|---:|---:|---:|---|
| metadata-witness / jmdict / 1 | A1 | no | — | — | 7 | 287.425 | 12.810 / 86.799 | covered-import-scan-gap-over-250ms |
| metadata-witness / jmdict / 1 | B1 | yes | 1040175 | 807616 | 7 | 204.933 | 135.868 / 84.366 | None |
| metadata-witness / jmdict / 1 | B2 | yes | 997954 | 765644 | 6 | 234.013 | 45.791 / 62.326 | None |
| metadata-witness / jmdict / 1 | A2 | yes | 991249 | 761396 | 6 | 249.290 | 34.176 / 22.275 | None |
| metadata-witness / jmdict / 2 | B1 | yes | 1022845 | 790936 | 18 | 139.692 | 57.173 / 5.137 | None |
| metadata-witness / jmdict / 2 | A1 | yes | 1024278 | 788760 | 13 | 123.535 | 28.642 / 7.258 | None |
| metadata-witness / jmdict / 2 | A2 | yes | 1014531 | 785804 | 13 | 131.740 | 12.700 / 38.533 | None |
| metadata-witness / jmdict / 2 | B2 | yes | 1015282 | 784396 | 13 | 142.305 | 6.193 / 30.946 | None |
| metadata-witness / jitendex / 1 | A1 | yes | 1052701 | 820176 | 12 | 180.723 | 1.230 / 51.847 | None |
| metadata-witness / jitendex / 1 | B1 | yes | 1055246 | 824992 | 12 | 219.485 | 12.604 / 1.618 | None |
| metadata-witness / jitendex / 1 | B2 | yes | 1041065 | 808416 | 11 | 203.072 | 60.202 / 96.502 | None |
| metadata-witness / jitendex / 1 | A2 | yes | 1090799 | 857892 | 10 | 202.819 | 31.788 / 99.311 | None |
| metadata-witness / jitendex / 2 | B1 | yes | 1064724 | 831776 | 12 | 189.171 | 23.011 / 62.829 | None |
| metadata-witness / jitendex / 2 | A1 | yes | 1045563 | 817428 | 13 | 218.288 | 106.525 / 79.031 | None |
| metadata-witness / jitendex / 2 | A2 | yes | 1052280 | 820128 | 11 | 194.872 | 59.512 / 95.976 | None |
| metadata-witness / jitendex / 2 | B2 | yes | 1073773 | 845112 | 12 | 186.208 | 47.414 / 109.114 | None |
| metadata-witness / vndb / 1 | A1 | yes | 1398602 | 1174516 | 63 | 216.671 | 62.557 / 106.533 | None |
| metadata-witness / vndb / 1 | B1 | yes | 1401884 | 1175316 | 56 | 188.893 | 14.085 / 19.288 | None |
| metadata-witness / vndb / 1 | B2 | no | — | — | 51 | 256.098 | 13.940 / 44.488 | covered-import-scan-gap-over-250ms |
| metadata-witness / vndb / 1 | A2 | yes | 1369666 | 1151680 | 53 | 201.618 | 78.000 / 57.148 | None |
| metadata-witness / vndb / 2 | B1 | no | — | — | 45 | 285.403 | 1.196 / 7.786 | covered-import-scan-gap-over-250ms |
| metadata-witness / vndb / 2 | A1 | no | — | — | 46 | 284.050 | 114.220 / 20.185 | covered-import-scan-gap-over-250ms |
| metadata-witness / vndb / 2 | A2 | no | — | — | 44 | 285.084 | 119.769 / 74.231 | covered-import-scan-gap-over-250ms |
| metadata-witness / vndb / 2 | B2 | yes | 1424459 | 1201432 | 46 | 242.599 | 109.640 / 135.371 | None |
| native-projection / jmdict / 1 | A1 | yes | 1009127 | 779640 | 10 | 99.985 | 22.684 / 0.287 | None |
| native-projection / jmdict / 1 | B1 | yes | 1031547 | 799212 | 11 | 109.409 | 48.495 / 43.252 | None |
| native-projection / jmdict / 1 | B2 | yes | 1022891 | 789328 | 11 | 106.870 | 43.879 / 15.941 | None |
| native-projection / jmdict / 1 | A2 | yes | 1022391 | 789628 | 9 | 107.582 | 47.531 / 29.882 | None |
| native-projection / jmdict / 2 | B1 | yes | 987921 | 756388 | 9 | 147.720 | 33.764 / 39.387 | None |
| native-projection / jmdict / 2 | A1 | yes | 1015860 | 786188 | 10 | 172.340 | 26.280 / 71.949 | None |
| native-projection / jmdict / 2 | A2 | yes | 979411 | 748960 | 8 | 165.978 | 87.465 / 73.356 | None |
| native-projection / jmdict / 2 | B2 | yes | 1013091 | 777228 | 8 | 159.092 | 40.875 / 11.575 | None |
| native-projection / jitendex / 1 | A1 | yes | 1069194 | 836752 | 13 | 205.068 | 30.829 / 5.612 | None |
| native-projection / jitendex / 1 | B1 | yes | 1042171 | 809720 | 12 | 177.388 | 101.214 / 5.296 | None |
| native-projection / jitendex / 1 | B2 | yes | 1053216 | 821820 | 12 | 208.345 | 133.266 / 96.436 | None |
| native-projection / jitendex / 1 | A2 | yes | 1037153 | 806144 | 12 | 183.308 | 56.804 / 17.155 | None |
| native-projection / jitendex / 2 | B1 | yes | 1075560 | 844776 | 12 | 211.477 | 106.127 / 61.069 | None |
| native-projection / jitendex / 2 | A1 | yes | 1038016 | 804280 | 12 | 200.703 | 9.431 / 40.562 | None |
| native-projection / jitendex / 2 | A2 | no | — | — | 11 | 250.151 | 104.496 / 33.174 | covered-import-scan-gap-over-250ms |
| native-projection / jitendex / 2 | B2 | yes | 1042043 | 808160 | 12 | 184.296 | 3.732 / 16.451 | None |
| native-projection / vndb / 1 | A1 | yes | 1388294 | 1160708 | 72 | 143.649 | 43.276 / 4.159 | None |
| native-projection / vndb / 1 | B1 | yes | 1416649 | 1183892 | 67 | 148.825 | 8.203 / 63.709 | None |
| native-projection / vndb / 1 | B2 | yes | 1407005 | 1173664 | 65 | 155.889 | 45.099 / 32.655 | None |
| native-projection / vndb / 1 | A2 | yes | 1415402 | 1181492 | 69 | 152.372 | 64.411 / 10.094 | None |
| native-projection / vndb / 2 | B1 | yes | 1472131 | 1240784 | 52 | 242.559 | 4.517 / 4.628 | None |
| native-projection / vndb / 2 | A1 | yes | 1428232 | 1196848 | 49 | 183.535 | 78.117 / 36.936 | None |
| native-projection / vndb / 2 | A2 | yes | 1414139 | 1181608 | 51 | 201.653 | 18.171 / 41.292 | None |
| native-projection / vndb / 2 | B2 | yes | 1373145 | 1142356 | 49 | 213.248 | 34.291 / 95.170 | None |

## Every covered gap exceeding 250 ms

These are all intervals over the frozen limit, in observation order. Each interval joins the import boundary or a fully covered scan midpoint. The JSON also retains every interval below the limit and its position relative to import start.

| Candidate / corpus / host | Observation | Gap index | Duration (ms) | From / to import start (ms) |
|---|---|---:|---:|---:|
| metadata-witness / jmdict / 1 | A1 | 3 | 250.570414 | 400.530142 / 651.100556 |
| metadata-witness / jmdict / 1 | A1 | 4 | 287.424968 | 651.100556 / 938.525524 |
| metadata-witness / vndb / 1 | B2 | 8 | 256.097518 | 855.178215 / 1111.275733 |
| metadata-witness / vndb / 2 | B1 | 15 | 263.339833 | 2540.260689 / 2803.600522 |
| metadata-witness / vndb / 2 | B1 | 16 | 285.403263 | 2803.600522 / 3089.003785 |
| metadata-witness / vndb / 2 | B1 | 17 | 254.801976 | 3089.003785 / 3343.805761 |
| metadata-witness / vndb / 2 | B1 | 19 | 258.321107 | 3572.578427 / 3830.899534 |
| metadata-witness / vndb / 2 | B1 | 20 | 253.836030 | 3830.899534 / 4084.735564 |
| metadata-witness / vndb / 2 | B1 | 22 | 252.607707 | 4314.072027 / 4566.679734 |
| metadata-witness / vndb / 2 | B1 | 29 | 265.343033 | 5981.407787 / 6246.750820 |
| metadata-witness / vndb / 2 | B1 | 30 | 253.854524 | 6246.750820 / 6500.605344 |
| metadata-witness / vndb / 2 | A1 | 22 | 250.353288 | 4108.333651 / 4358.686939 |
| metadata-witness / vndb / 2 | A1 | 25 | 284.049876 | 4821.991467 / 5106.041343 |
| metadata-witness / vndb / 2 | A2 | 15 | 251.910512 | 2483.284731 / 2735.195243 |
| metadata-witness / vndb / 2 | A2 | 16 | 283.015442 | 2735.195243 / 3018.210685 |
| metadata-witness / vndb / 2 | A2 | 17 | 273.728804 | 3018.210685 / 3291.939489 |
| metadata-witness / vndb / 2 | A2 | 20 | 255.217942 | 3783.486668 / 4038.704610 |
| metadata-witness / vndb / 2 | A2 | 24 | 285.083894 | 4719.792514 / 5004.876408 |
| native-projection / jitendex / 2 | A2 | 6 | 250.151437 | 974.610647 / 1224.762084 |

## Evidence binding

Downloaded archives are checked against GitHub artifact ID, run/head identity, byte size and SHA-256. Every embedded package member is independently hashed; source commits, source trees, own native manifests, exact package allowlists, fixture locks, original/overlaid harnesses and observer bytes are bound to the frozen source. Release ZIPs are not retained locally. Original raw scans and CI audit receipts remain intact; independent replay output is separate.

All acquired observations use pinned Node 22.22.0 and Chromium 153.0.8010.12. The scheduled jobs have 12 distinct GitHub runner identities. The source-media validation mode is exhaustive, with all 72 public lookup receipts and restart validation retained per observation. Semantic receipt hashes match across every acquired arm and host within each corpus.

| Cell | Artifact ID | Archive bytes | SHA-256 |
|---|---:|---:|---|
| metadata-witness / jmdict / 1 | 15041125557 | 34060287 | `7979349ffe24fd59349dbc775a8ae9bd3613fab05f340c893a4e0c2dd7a4d864` |
| metadata-witness / jmdict / 2 | 15040996373 | 34221593 | `6ab5c6e40582a336b2fa3e5443a8b4a297d2de4573009e07ae48337de6cacefb` |
| metadata-witness / jitendex / 1 | 15041745094 | 34076570 | `5732116e0ee8ce2ad9302db1f247a9fb14dadaf0f0bb11802da40d7110b089f9` |
| metadata-witness / jitendex / 2 | 15041181349 | 34075758 | `6e51cbe61870f8e08817c99426edd53bbc40d24bfcc4ebec01f74ce9c067b4b4` |
| metadata-witness / vndb / 1 | 15042550092 | 34344790 | `a2a80a8b2ac2618a7ba68293e1b7df2665dc978c39361afcef4e669b33da4da3` |
| metadata-witness / vndb / 2 | 15041903599 | 34240313 | `5de5322309da2d4ee57d26d0a50c98fd0f3e07b12df34cba6bb92ba35577e798` |
| native-projection / jmdict / 1 | 15040146032 | 34129986 | `780a63b7b622b3c1c904d5f8b756f368ff8386bb897cf2ce0188876219b84bc1` |
| native-projection / jmdict / 2 | 15039704465 | 34101937 | `23b5fcb1df42051e4898a0f382fb947a37e2dd8d58fe711db81d00bfbf7cd24c` |
| native-projection / jitendex / 1 | 15038564647 | 34072772 | `483b864355adaa698c9dd04c23e314d4560b5a407fa227a2b77f217efcd3236d` |
| native-projection / jitendex / 2 | 15039624007 | 34081816 | `b28a3c2f6e27f00adb2a19a87a83f857cb043260e7e8ccf606c65373baefec36` |
| native-projection / vndb / 1 | 15040639037 | 34492247 | `697698ff7ef3eb09b783193f11842994da8de8c600c64014a10764c11f7a7b0d` |
| native-projection / vndb / 2 | 15042975244 | 34282889 | `e318dca1ecd7845d84fb339af350e2869d2d332aee8ef1802c7a31eb24f1f6f0` |
