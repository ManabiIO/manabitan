#!/usr/bin/env python3
"""Materialize one short-lived connector URL without logging its contents."""
import hashlib
import json
from pathlib import Path
import sys
import urllib.error
import urllib.request

url, path_text, expected = sys.argv[1:]
path = Path(path_text)
if path.exists() or path.with_suffix(path.suffix + '.part').exists():
    raise RuntimeError('Refusing to replace an existing download')
expected = expected.removeprefix('sha256:').lower()
if len(expected) != 64 or any(c not in '0123456789abcdef' for c in expected):
    raise RuntimeError('Expected artifact SHA-256')
path.parent.mkdir(parents=True, exist_ok=True)
temporary = path.with_suffix(path.suffix + '.part')
digest = hashlib.sha256()
length = 0
try:
    with urllib.request.urlopen(url, timeout=60) as response, temporary.open('xb') as output:
        while block := response.read(1024 * 1024):
            output.write(block)
            digest.update(block)
            length += len(block)
except Exception as error:
    print(json.dumps({'downloadFailed': True, 'errorType': type(error).__name__, 'httpStatus': getattr(error, 'code', None)}))
    sys.exit(1)
actual = digest.hexdigest()
if actual != expected:
    print(json.dumps({'downloadFailed': True, 'reason': 'Artifact SHA-256 mismatch', 'expected': expected, 'actual': actual, 'bytes': length}))
    sys.exit(1)
temporary.rename(path)
print(json.dumps({'path': str(path), 'sha256': actual, 'bytes': length, 'digestVerified': True}))
