# Native projection: fixed complete-import timing cohort

The complete cohort has valid evidence but does **not** pass its prespecified
performance screen. All six jobs completed successfully, and independent audit
reconciles all 132 observations. Numerical performance acceptance is separate
from successful job execution and correctness.

Run: [45647030745](https://github.com/ManabiIO/manabitan/actions/runs/45647030745),
attempt 1. Frozen workflow `7b021ebe3e7625a56ab9dde346ae72f3cd39b770`;
A/C baseline `7d1643e6147a10cb2165e9744cf0e63b59e46632`;
B candidate `5afd2e97ec2707b150acfde61115aee688547a78`.

Each independent GitHub runner completed three scheduled warmups and six
balanced A/B/C timing triplets. Replica 0 also performed separate A/B exhaustive
media diagnostics after timing. Replica 0 has 23 observations and replica 1 has
21. C uses the identical A release package. Every observation uses a fresh
browser profile, production defaults, Node 22.22.0 and Chromium 153.0.8010.12.
The timing boundary is browser-monotonic file-input change through visible
import completion. Timing runs have process sampling and tracing disabled.

Negative percentages indicate a shorter import. These are medians of the six
paired changes on each host; hosts and previous studies are not pooled.

| Corpus | Host | B/A | B/C | C/A control | Faster B/A; B/C | Fixed screen |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| JMdict | 0 | −0.5455% | −0.0418% | +1.1116% | 4/6; 3/6 | Non-target pass |
| JMdict | 1 | +0.7808% | +0.5509% | +0.9424% | 1/6; 2/6 | Non-target pass |
| Jitendex | 0 | −0.9815% | +2.7873% | −1.6029% | 4/6; 2/6 | Non-target pass |
| Jitendex | 1 | +0.5773% | +3.8180% | +0.5985% | 2/6; 2/6 | Non-target failure |
| VNDB | 0 | −3.6665% | −5.6507% | +0.8874% | 6/6; 6/6 | Target failure |
| VNDB | 1 | −4.4850% | −4.4071% | −0.7253% | 5/6; 5/6 | Target failure |

The fixed target criterion requires at least 5% reduction and five faster pairs
against **both** controls on **each** host. VNDB host 0 misses the reduction
threshold against A; host 1 misses it against both controls. The fixed non-target
limit is at most 3% regression against either control on either host; Jitendex
host 1 exceeds it against C. All observations, including these failures, remain.
There were no exclusions, replacements, outcome-dependent reruns or changed
thresholds.

## Evidence audit

- All six outer artifact SHA-256 digests match GitHub's artifact metadata.
- All twelve contained A/B release ZIPs and every archive member were streamed
  through SHA-256 verification against their retained manifests and receipts.
  Release ZIPs were not retained locally; each downloaded outer ZIP was deleted
  only after verified extraction.
- Exact source commits/trees, critical packaged JS/C/WASM bytes, native artifact
  manifests, frozen workflow/runner/protocol, unchanged harness hashes, fixture
  identities, observation order, browser/runtime identity and production-default
  configuration reconcile.
- All 132 observations preserve complete lookup/restart/content checks. Each has
  72 public lookup observations. Public semantics agree between arms, passes and
  hosts. All paired changes, medians, faster-pair counts and `performanceScreen`
  verdicts were independently recomputed.
- Both VNDB exhaustive diagnostics verify 146,570 images and 188,131,284 payload
  bytes each, with digest
  `ea94d392bc833baf0bee7b3d6becc3d3517eee84ee314a44986438ac6d5217cb`.
- VNDB storage is 609,553,611 bytes in 43 observations. Host 1 `cohort-1-B`
  records 609,561,803 bytes: the entire 8,192-byte difference is in the active
  SQLite SAH file (536,576 rather than 528,384 bytes). Other term/media file sizes
  and the seven 4,096-byte SAH files match. This additive diagnostic does not
  introduce a new acceptance rule or alter a frozen screen.

`summary.json` is the final per-host summary. Each cell retains its reports,
receipts, raw observations, package manifests, artifact metadata and independent
audit. `jobs-native-final.json` records six distinct GitHub runner IDs.
`artifact-index.json`, `source-binding.json`, and `media-and-artifact-checks.json`
record additional provenance. The auditor and extraction helpers are retained.

This timing cohort makes no memory qualification claim. Current-source screen
45642169759, memory study 45642179064, and earlier studies remain separate;
their failures are neither replaced nor pooled with this cohort.
