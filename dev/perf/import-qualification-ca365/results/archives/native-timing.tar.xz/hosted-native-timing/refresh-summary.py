#!/usr/bin/env python3
"""Summarize per-host audits without pooling any timing observations."""
from datetime import datetime, timezone
import json
from pathlib import Path

root = Path(__file__).resolve().parent
order = {'jmdict': 0, 'jitendex': 1, 'vndb': 2}
audits = sorted((json.loads(path.read_text()) for path in root.glob('native-projection-*/independent-audit.json')),
                key=lambda row: (order[row['dictionary']], row['replica']))
assert all(row['candidate'] == 'native-projection' for row in audits)
assert len({(row['dictionary'], row['replica']) for row in audits}) == len(audits)
assert len({json.dumps(row['packageMemberDigests'], sort_keys=True) for row in audits}) == 1
semantic_identity = {}
for dictionary in order:
    hosts = [row for row in audits if row['dictionary'] == dictionary]
    if len(hosts) == 2:
        assert hosts[0]['semanticDigests']['sample'] == hosts[1]['semanticDigests']['sample']
        semantic_identity[dictionary] = True
    else:
        semantic_identity[dictionary] = None
failures = [{'dictionary': row['dictionary'], 'replica': row['replica'], 'screen': row['performanceScreen']}
            for row in audits if row['performanceScreen']['passes'] is False]
summary = {
    'runId': '45647030745', 'runAttempt': 1,
    'workflowCommit': '7b021ebe3e7625a56ab9dde346ae72f3cd39b770',
    'baselineCommit': '7d1643e6147a10cb2165e9744cf0e63b59e46632',
    'candidateCommit': '5afd2e97ec2707b150acfde61115aee688547a78',
    'updatedAtUtc': datetime.now(timezone.utc).isoformat(),
    'plannedCells': 6, 'auditedCells': len(audits),
    'complete': len(audits) == 6 and all(row['complete'] for row in audits),
    'verifiedObservations': sum(row['verifiedObservations'] for row in audits),
    'allIntegrityAuditsPassed': all(row['integrityAuditPassed'] for row in audits),
    'knownPerformanceScreenFailures': failures,
    'allPerformanceScreensPassed': False if failures else True if len(audits) == 6 else None,
    'packageMemberIdentityAcrossHosts': True,
    'publicSemanticIdentityAcrossHosts': semantic_identity,
    'noPooledTimingStatistics': True, 'memoryNotAssessedByTimingCohort': True,
    'separateFromRuns': ['45642169759', '45642179064'],
    'cells': [{key: row[key] for key in ['dictionary', 'replica', 'artifact', 'verifiedObservations',
                                       'medians', 'fasterPairs', 'performanceScreen']} for row in audits],
}
(root / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({key: summary[key] for key in ['complete', 'auditedCells', 'verifiedObservations',
                                              'allIntegrityAuditsPassed', 'allPerformanceScreensPassed']}, indent=2))
