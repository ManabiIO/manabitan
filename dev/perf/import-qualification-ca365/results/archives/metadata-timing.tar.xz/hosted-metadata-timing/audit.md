# Metadata import timing audit

**The candidate fails the frozen import-speed screen.** Both Jitendex hosts are slower than both baseline controls by median paired timing. The candidate is not qualified for promotion as an import-speed improvement.

Workflow run [45647030745](https://github.com/ManabiIO/manabitan/actions/runs/45647030745) evaluates candidate `11bf4550a26e98ccc3df1579da7444244fe1e861` against `7d1643e6147a10cb2165e9744cf0e63b59e46632` under frozen workflow `7b021ebe3e7625a56ab9dde346ae72f3cd39b770`.

Acquisition checkpoint **2026-11-25T16:30:28Z**: 0 running, 0 queued, 6 completed; 6 metadata artifacts available. Completed cells audited: 6. Polling paused: True.

Complete audited acquisition: **True**. Frozen timing screen: **False**. Missing or invalid evidence remains unqualified.

| Corpus | Host | Complete and valid | B vs A median | B vs C median | C vs A median | Faster pairs A / C | Screen |
| --- | ---: | --- | ---: | ---: | ---: | --- | --- |
| jmdict | 0 | True | +1.600% | +2.312% | -1.165% | 1 / 2 | True |
| jmdict | 1 | True | +0.687% | +0.433% | -0.909% | 2 / 2 | True |
| jitendex | 0 | True | +2.614% | +2.385% | +1.224% | 0 / 2 | False |
| jitendex | 1 | True | +3.641% | +3.148% | +0.479% | 0 / 0 | False |
| vndb | 0 | True | -2.206% | -0.378% | +0.053% | 4 / 3 | True |
| vndb | 1 | True | +0.802% | -0.748% | +1.821% | 2 / 4 | True |

Negative paired percentages favor the candidate. Jitendex must improve by at least 5% against both identical-source controls on each host, with at least five of six faster pairs against each control. JMdict and VNDB must not regress by more than 3% against either control on either host.

All 132 of 132 scheduled observations were verified; 108 contribute to the timing comparisons. The predetermined warmups and full-media validation observations remain in the evidence and are excluded from timing by schedule.

## Evidence integrity

Each cell audit independently verifies the downloaded artifact digest, every nested release ZIP/member byte, exact source and harness identities, frozen fixture and schedule, every scheduled observation, browser timing boundaries, public lookup/restart/media equality, and the numerical screen recomputed from raw durations. Release ZIPs are hashed without disk retention; report and manifest files remain with their extraction manifest.

Cross-host comparisons preserve both hosts. They do not replace either host’s threshold result with a pooled value. Full pair values, errors, source identities and cross-host checks are in [audit.json](audit.json).

## Limits

- Thresholds apply separately to each host and each control. No outcome-dependent exclusions or pooled-host substitution.
- A successful acquisition job does not establish numerical performance-screen passage.
- Browser process sampling is disabled in these timing observations. Memory qualification is separate.
- Semantic equality covers the frozen public lookup, persistence/restart and media validation workload; complete parser parity is separate evidence.
