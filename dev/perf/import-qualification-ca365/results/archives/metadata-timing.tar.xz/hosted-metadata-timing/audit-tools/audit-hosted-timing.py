#!/usr/bin/env python3
"""Audit extracted, immutable ca365 timing evidence without changing its records."""

import argparse
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import json
import math
from pathlib import Path
import re
import statistics
import subprocess
import sys


HARNESS_PATHS = [
    'package-lock.json', 'test/perf/dictionaries.lock.json',
    'dev/perf/benchmark-support.js', 'dev/perf/dictionary-fixtures.js',
    'dev/perf/import-benchmark.js', 'test/e2e/import-timing.js',
    'test/chromium/extension-two-dictionary-import.e2e.js',
]


def read(path):
    return json.loads(path.read_text())


def digest(value):
    return hashlib.sha256(value).hexdigest()


def semantic_digest(value):
    return digest(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode())


def require(condition, message):
    if not condition:
        raise ValueError(message)


def equal_number(actual, expected, label):
    require(isinstance(actual, (int, float)) and math.isfinite(actual), f'{label}: nonfinite metric')
    require(math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-8), f'{label}: {actual} != {expected}')


@lru_cache(maxsize=None)
def git_bytes(repo, commit, path):
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=repo)


@lru_cache(maxsize=None)
def git_tree(repo, commit):
    return subprocess.check_output(['git', 'rev-parse', f'{commit}^{{tree}}'], cwd=repo, text=True).strip()


def expected_schedule(protocol, replica):
    result = [dict(name=f'warmup-{arm}', arm=arm, phase='warmup', media='sample')
              for arm in protocol['warmups'][replica]]
    for index, cohort in enumerate(protocol['orders'][replica]):
        result.extend(dict(name=f'cohort-{index}-{arm}', arm=arm, phase='timed', cohort=index, media='sample')
                      for arm in cohort)
    if replica == 0:
        result.extend(dict(name=f'all-media-{arm}', arm=arm, phase='validation', media='all') for arm in ['A', 'B'])
    return result


def verify_semantic(report, fixture, media_mode):
    validation = report['benchmark']['validation']
    require(validation['title'] == fixture['expectedTitle'], 'Unexpected dictionary title')
    require(validation['revision'] == fixture['revision'], 'Unexpected revision')
    require(validation['termRows'] == fixture['termRows'], 'Unexpected term row count')
    require(validation['contentReadable'] is True, 'Content unreadable')
    terms = validation['probeTerms']
    require(len(terms) == len(set(terms)) == validation['probeCount'] == 12, 'Expected 12 unique probes')
    restart = validation['restart']
    for key in ['title', 'revision', 'termRows', 'contentReadable']:
        require(restart[key] == validation[key], f'Restart mismatch: {key}')
    require(restart['probeCount'] == 12, 'Missing restart probes')
    lookups = validation['lookup']['observations']
    require(len(lookups) == 72, 'Expected all 72 public lookup observations')
    identities = {}
    seen = set()
    for row in lookups:
        term = row['term']
        key = (row['pass'], term)
        require(term in terms and isinstance(row['pass'], int) and 0 <= row['pass'] < 6, 'Invalid probe/pass')
        require(key not in seen, 'Duplicate probe/pass')
        seen.add(key)
        require(row['originalTextLength'] == len(term.encode('utf-16-le', errors='surrogatepass')) // 2, 'Probe length mismatch')
        require(row['hasExactHeadwordMatch'] is True, 'Missing exact headword match')
        require(isinstance(row['results'], int) and row['results'] > 0, 'Missing public lookup results')
        require(re.fullmatch('[0-9a-f]{64}', row['sha256']) is not None, 'Invalid public result hash')
        require(isinstance(row['elapsedMs'], (int, float)) and math.isfinite(row['elapsedMs']) and row['elapsedMs'] >= 0, 'Invalid lookup duration')
        identity = {name: row[name] for name in ['term', 'sha256', 'results', 'originalTextLength', 'hasExactHeadwordMatch']}
        require(term not in identities or identities[term] == identity, 'Public result changes between passes/restart')
        identities[term] = identity
    media = validation['media']
    if 'mediaFiles' in fixture:
        expected_files = fixture['mediaFiles'] if media_mode == 'all' else min(fixture['mediaFiles'], 64)
        require(media['mode'] == media_mode and media['totalFiles'] == fixture['mediaFiles'], 'Media mode/count mismatch')
        require(media['totalBytes'] == fixture['mediaBytes'] and media['files'] == expected_files, 'Media byte/count mismatch')
        require(restart['mediaFiles'] == fixture['mediaFiles'], 'Restart media count mismatch')
        require(isinstance(media['bytes'], int) and 0 <= media['bytes'] <= fixture['mediaBytes'], 'Media checked byte bound')
        require(expected_files == 0 or media['bytes'] > 0, 'Media payload not checked')
        require(media_mode != 'all' or media['bytes'] == fixture['mediaBytes'], 'Incomplete all-media verification')
        require(re.fullmatch('[0-9a-f]{64}', media['sha256']) is not None, 'Invalid media digest')
        require(expected_files != 0 or media['sha256'] == digest(b''), 'Unexpected empty-media digest')
        require(validation['storage']['bytes'] > 0, 'Missing persisted storage')
    return {
        'title': validation['title'], 'revision': validation['revision'], 'termRows': validation['termRows'],
        'contentReadable': True, 'probeTerms': sorted(terms),
        'publicResults': [identities[term] for term in sorted(identities)], 'restart': restart, 'media': media,
    }


def audit_cell(cell, args, protocol, result):
    execution = read(cell / 'execution.json')
    result.update({key: execution[key] for key in ['candidate', 'dictionary', 'replica']})
    candidate = protocol['candidates'][execution['candidate']]
    replica = execution['replica']
    require(replica in [0, 1], 'Unexpected replica')
    require(str(execution['runId']) == str(args.run), 'Wrong workflow run')
    require(str(execution['runAttempt']) == '1', 'Unexpected rerun attempt')
    require(execution['workflowCommit'] == args.workflow, 'Wrong frozen workflow commit')
    require(read(cell / 'protocol.json') == protocol, 'Protocol differs from frozen source')
    for actual_path, git_path, field in [
        ('protocol.json', 'dev/perf/import-qualification-ca365.json', 'protocolSha256'),
        ('executed-runner.py', 'dev/perf/qualify-import-ca365.py', 'runnerSha256'),
        ('executed-workflow.yml', '.github/workflows/import-qualification-ca365.yml', None),
    ]:
        expected = digest(git_bytes(args.repo, args.workflow, git_path))
        require(digest((cell / actual_path).read_bytes()) == expected, f'Changed executed source: {actual_path}')
        require(field is None or execution[field] == expected, f'Execution digest mismatch: {field}')
    receipts = {arm: read(cell / f'package-{arm}-receipt.json') for arm in ['A', 'B', 'C']}
    member_maps = {}
    package_verification = read(cell / 'package-verification.json')
    extraction = read(cell / 'extraction-manifest.json')
    require(extraction['downloadDigestVerified'] is True, 'Outer artifact digest not verified')
    require(extraction['artifactName'] == f'import-qualification-ca365-{execution["candidate"]}-{execution["dictionary"]}-{replica}', 'Wrong artifact cohort')
    require(set(package_verification) == {'package-A.zip', 'package-B.zip'}, 'Missing independently verified release package')
    result['artifact'] = {key: extraction[key] for key in ['artifactId', 'artifactName', 'artifactSha256', 'artifactBytes']}
    for arm in ['A', 'B']:
        receipt = receipts[arm]
        commit = protocol['base'] if arm == 'A' else candidate['commit']
        require(receipt['sourceCommit'] == commit, f'{arm}: wrong source commit')
        require(receipt['sourceTree'] == git_tree(args.repo, commit), f'{arm}: wrong source tree')
        require(receipt['generatedLibrariesShared'] is True and receipt['nativeModulesRestoredFromOwnManifest'] is True, f'{arm}: native/library receipt missing')
        expected_harness = {path: digest(git_bytes(args.repo, commit, path)) for path in HARNESS_PATHS}
        require(receipt['harnessSha256'] == expected_harness, f'{arm}: harness receipt differs from source Git objects')
        members = read(cell / f'package-{arm}-members.json')
        require(len(members) == receipt['memberCount'], f'{arm}: package member count mismatch')
        verification = package_verification[f'package-{arm}.zip']
        require(verification['matchesReceiptAndMemberManifest'] is True, f'{arm}: release verification incomplete')
        require(verification['packageSha256'] == receipt['packageSha256'], f'{arm}: independently hashed ZIP differs')
        require(verification['memberCount'] == receipt['memberCount'] and verification['members'] == members, f'{arm}: independently hashed members differ')
        for member in candidate['packagedDelta']:
            path = 'dev/data/dictionary-wasm/term-bank-parser.wasm' if member == 'lib/term-bank-parser.wasm' else f'ext/{member}'
            require(members[member] == digest(git_bytes(args.repo, commit, path)), f'{arm}: package/source mismatch for {member}')
        native_manifest = json.loads(git_bytes(args.repo, commit, 'dev/data/dictionary-wasm/manifest.json'))
        for target in native_manifest['targets']:
            require(members[f'lib/{target["name"]}'] == target['sha256'], f'{arm}: native artifact differs from manifest')
        member_maps[arm] = members
    require(receipts['A']['harnessSha256'] == receipts['B']['harnessSha256'], 'Harness differs between arms')
    require(receipts['C'] == {**receipts['A'], 'identicalTo': 'A'}, 'C is not the identical A control')
    changed = sorted(key for key in member_maps['A'].keys() | member_maps['B'].keys() if member_maps['A'].get(key) != member_maps['B'].get(key))
    require(changed == sorted(candidate['packagedDelta']) == read(cell / 'package-delta.json'), 'Unexpected package delta')
    fixture = read(cell / 'fixture.json')
    fixture_lock = json.loads(git_bytes(args.repo, protocol['base'], 'test/perf/dictionaries.lock.json'))
    require(fixture == fixture_lock['dictionaries'][execution['dictionary']], 'Fixture differs from pinned source lock')
    schedule = expected_schedule(protocol, replica)
    require(read(cell / 'schedule.json') == schedule, 'Schedule differs from prospective order')
    observations = read(cell / 'observations.json')
    result['scheduledObservations'] = len(schedule)
    result['recordedObservations'] = len(observations)
    require(len(observations) <= len(schedule), 'Unscheduled extra observations')
    semantics = {}
    verified = []
    for index, observation in enumerate(observations):
        item = schedule[index]
        try:
            require(all(observation.get(key) == value for key, value in item.items()), 'Observation out of scheduled order')
            arm_receipt = receipts[item['arm']]
            require(observation['sourceCommit'] == arm_receipt['sourceCommit'], 'Observation source mismatch')
            require(observation['packageSha256'] == arm_receipt['packageSha256'], 'Observation package mismatch')
            destination = cell / item['name']
            receipt = read(destination / 'receipt.json')
            require(all(observation.get(key) == value for key, value in receipt.items()), 'Original observation receipt differs')
            require(observation['status'] == 'success', f'Recorded failure: {observation.get("error")}')
            report = read(destination / 'run-1.json')
            summary = read(destination / 'summary.json')
            require(report['status'] == 'success' and report['skippedVerification'] is False, 'Report unsuccessful or verification skipped')
            require(report['packageSha256'] == arm_receipt['packageSha256'], 'Executed package mismatch')
            require(report['buildTarget'] == summary['buildTarget'] == 'chrome', 'Unexpected build target')
            require(report['browserVersion'] == summary['browserVersion'] == protocol['browserVersion'], 'Browser differs from protocol')
            require(summary['gitSha'] == arm_receipt['sourceCommit'], 'Summary source mismatch')
            require(summary['fixture'] == fixture, 'Observation fixture mismatch')
            require(summary['authoritativeTiming'] is True and summary['traceEnabled'] is False, 'Timing not authoritative')
            require(summary['importFlags'] is None and summary['mediaCheck'] == item['media'], 'Summary flag/mode override')
            benchmark = report['benchmark']
            require(benchmark['dictionary'] == execution['dictionary'] and benchmark['mediaCheck'] == item['media'], 'Wrong benchmark cohort')
            for name in ['pinnedDictionaries', 'productionImportDefaults', 'authoritativeTiming']:
                require(benchmark[name] is True, f'Benchmark {name} not true')
            for name in ['traceEnabled', 'phaseProfiling', 'phaseScreenshots', 'processSampling']:
                require(benchmark[name] is False, f'Perturbed timing: {name}')
            require(benchmark['importFlags'] is None, 'Benchmark import flag override')
            require(len(summary['runs']) == 1, 'Observation contains more than one import')
            run = summary['runs'][0]
            phases = [phase for phase in report['phases'] if phase['name'] == f'{fixture["label"]}: total import']
            require(len(phases) == 1, 'Missing/duplicate total-import phase')
            timing = phases[0]['data']['browserTiming']
            require(timing['trigger'] == 'file-input-change' and timing['errorCount'] == 0, 'Invalid browser clock boundary')
            require(timing['sequence'] > timing['sequenceBefore'], 'Stale browser operation')
            duration = timing['completedAtMs'] - timing['startedAtMs']
            require(duration > 0, 'Invalid browser duration')
            equal_number(run['totalImportMs'], duration, 'Browser to summary duration')
            equal_number(observation['totalImportMs'], duration, 'Summary to observation duration')
            require(run['workerImportMs'] == observation['workerImportMs'], 'Worker duration mismatch')
            require(run['packageSha256'] == arm_receipt['packageSha256'], 'Summary package mismatch')
            debug = phases[0]['data']['importDebug']
            require(debug['hasResult'] is True and debug['resultTitle'] == fixture['expectedTitle'], 'No valid completion result')
            require(debug['errorCount'] == debug['addSettingsErrorCount'] == 0 and debug['usesFallbackStorage'] is False, 'Import/storage error')
            require(summary['hostEnvironment']['nodeVersion'] == 'v22.22.0', 'Node version mismatch')
            for host in ['host-before.json', 'host-after.json']:
                require(read(destination / host)['nodeVersion'] == 'v22.22.0', f'{host}: Node version mismatch')
            semantic = verify_semantic(report, fixture, item['media'])
            require(read(destination / 'semantic-receipt.json') == semantic, 'Semantic receipt differs from report')
            require(item['media'] not in semantics or semantics[item['media']] == semantic, 'Semantics differ between arms/observations')
            semantics[item['media']] = semantic
            verified.append(observation)
        except (KeyError, ValueError, OSError, TypeError) as error:
            result['observationErrors'].append({'name': item['name'], 'error': str(error)})
    result['verifiedObservations'] = len(verified)
    complete = len(verified) == len(schedule)
    analysis = read(cell / 'analysis.json')
    require(analysis['complete'] is complete, 'Analysis completeness does not match audited reports')
    require(analysis['criterion'] == protocol['criterion'], 'Analysis criterion differs from protocol')
    require(analysis['failures'] == [row['name'] for row in observations if row['status'] != 'success'], 'Failure list changed')
    pairs = []
    for index in range(len(protocol['orders'][replica])):
        cohort = {row['arm']: row for row in verified if row.get('cohort') == index}
        if len(cohort) != 3:
            pairs.append({'cohort': index, 'qualified': False})
            continue
        values = {arm: row['totalImportMs'] for arm, row in cohort.items()}
        pairs.append({'cohort': index, 'qualified': True, 'ms': values,
                      **{f'{left}vs{right}': 100 * (values[left] / values[right] - 1)
                         for left, right in [('B', 'A'), ('B', 'C'), ('C', 'A')]}})
    require(len(analysis['pairs']) == len(pairs), 'Pair count changed')
    for reported, recomputed in zip(analysis['pairs'], pairs):
        require(reported['cohort'] == recomputed['cohort'] and reported['qualified'] == recomputed['qualified'], 'Pair eligibility changed')
        if recomputed['qualified']:
            require(reported['ms'] == recomputed['ms'], 'Pair raw durations changed')
            for key in ['BvsA', 'BvsC', 'CvsA']:
                equal_number(reported[key], recomputed[key], key)
    result['complete'] = complete
    result['pairs'] = pairs
    if complete:
        medians = {key: statistics.median(row[key] for row in pairs) for key in ['BvsA', 'BvsC', 'CvsA']}
        faster = {key: sum(row[key] < 0 for row in pairs) for key in ['BvsA', 'BvsC']}
        for key, value in medians.items():
            equal_number(analysis['medians'][key], value, f'Median {key}')
        require(analysis['fasterPairs'] == faster, 'Faster-pair count changed')
        target = execution['dictionary'] in candidate['targetDictionaries']
        thresholds = protocol['thresholds']
        passes = all(medians[key] <= -thresholds['targetMinimumReductionPercent'] and faster[key] >= thresholds['targetMinimumFasterPairs']
                     for key in ['BvsA', 'BvsC']) if target else all(medians[key] <= thresholds['nonTargetMaximumRegressionPercent'] for key in ['BvsA', 'BvsC'])
        screen = {'role': 'target' if target else 'non-target', 'passes': passes}
        require(analysis['performanceScreen'] == screen, 'Performance screen does not match frozen thresholds')
        result.update(medians=medians, fasterPairs=faster, performanceScreen=screen)
    else:
        require(analysis['performanceScreen']['passes'] is None, 'Incomplete data has a performance verdict')
        result['performanceScreen'] = analysis['performanceScreen']
    result['semanticDigests'] = {mode: semantic_digest(value) for mode, value in semantics.items()}
    result['packageMemberDigests'] = {arm: semantic_digest(value) for arm, value in member_maps.items()}
    result['sourceCommits'] = {arm: receipt['sourceCommit'] for arm, receipt in receipts.items()}
    result['memoryQualified'] = False
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('cell', type=Path)
    parser.add_argument('--repo', required=True)
    parser.add_argument('--run', required=True)
    parser.add_argument('--workflow', required=True)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    protocol = json.loads(git_bytes(args.repo, args.workflow, 'dev/perf/import-qualification-ca365.json'))
    result = {
        'path': str(args.cell), 'integrityErrors': [], 'observationErrors': [], 'performanceScreen': None,
        'auditedAtUtc': datetime.now(timezone.utc).isoformat(), 'auditPythonVersion': sys.version,
        'auditorSha256': digest(Path(__file__).read_bytes()),
    }
    try:
        result = audit_cell(args.cell, args, protocol, result)
    except (KeyError, ValueError, OSError, TypeError, subprocess.CalledProcessError) as error:
        result['integrityErrors'].append(str(error))
        result.update(complete=False, performanceScreen=None, memoryQualified=False)
    result['integrityAuditPassed'] = not result.get('integrityErrors') and not result.get('observationErrors')
    output = json.dumps(result, indent=2, ensure_ascii=False) + '\n'
    if args.output:
        args.output.write_text(output)
    print(output, end='')
    raise SystemExit(0 if result['integrityAuditPassed'] else 1)


if __name__ == '__main__':
    main()
