#!/usr/bin/env python3
"""Summarize all six audited cells without pooling independent-host gates."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('root', type=Path)
    args = parser.parse_args()
    root = args.root
    binding = read(root / 'source-binding.json')
    protocol = read(root / 'frozen-protocol.json')
    checkpoint = read(root / 'jobs-latest.json') if (root / 'jobs-latest.json').exists() else None
    cells = []
    issues = []
    for dictionary in ['jmdict', 'jitendex', 'vndb']:
        for replica in [0, 1]:
            name = f'{dictionary}-host-{replica}'
            path = root / name / 'independent-audit.json'
            if path.exists():
                audit = read(path)
                if audit.get('candidate') != 'metadata-witness' or audit.get('dictionary') != dictionary or audit.get('replica') != replica:
                    issues.append(f'{name}: cell identity missing or wrong')
                cells.append({'name': name, **audit})
            else:
                cells.append({'name': name, 'dictionary': dictionary, 'replica': replica,
                              'complete': False, 'integrityAuditPassed': False, 'missingArtifactAudit': True})
    complete = all(cell.get('complete') is True and cell.get('integrityAuditPassed') is True for cell in cells)
    activation_storage = {}
    for cell in cells:
        path = root / cell['name'] / 'activation-and-storage.json'
        if path.exists():
            activation_storage[cell['name']] = read(path)['summary']
    cross_host = {}
    for dictionary in ['jmdict', 'jitendex', 'vndb']:
        hosts = [cell for cell in cells if cell.get('dictionary') == dictionary]
        comparable = len(hosts) == 2 and all(cell.get('complete') and cell.get('integrityAuditPassed') for cell in hosts)
        comparison = {'comparable': comparable, 'bothHostScreensPass': None}
        if comparable:
            comparison.update({
                'publicLookupRestartAndSampleMediaMatch': hosts[0]['semanticDigests']['sample'] == hosts[1]['semanticDigests']['sample'],
                'releaseMemberBytesMatch': hosts[0]['packageMemberDigests'] == hosts[1]['packageMemberDigests'],
                'sourceCommitsMatch': hosts[0]['sourceCommits'] == hosts[1]['sourceCommits'],
                'bothHostScreensPass': all(cell['performanceScreen']['passes'] is True for cell in hosts),
            })
            for key in ['publicLookupRestartAndSampleMediaMatch', 'releaseMemberBytesMatch', 'sourceCommitsMatch']:
                if comparison[key] is not True:
                    issues.append(f'{dictionary}: cross-host {key} is false')
        cross_host[dictionary] = comparison
    result = {
        'schemaVersion': 1,
        'checkedAtUtc': datetime.now(timezone.utc).isoformat(),
        'repository': 'ManabiIO/manabitan', 'qualificationPr': 918, 'sourcePr': 831,
        'runId': binding['runId'], 'candidate': 'metadata-witness',
        'commits': binding['commits'], 'trees': binding['trees'],
        'protocolSha256': hashlib.sha256((root / 'frozen-protocol.json').read_bytes()).hexdigest(),
        'complete': complete, 'crossHostIntegrityIssues': issues,
        'scheduledObservations': sum(cell.get('scheduledObservations', 0) for cell in cells),
        'verifiedObservations': sum(cell.get('verifiedObservations', 0) for cell in cells),
        'timedObservations': sum(3 * sum(pair.get('qualified') is True for pair in cell.get('pairs', [])) for cell in cells),
        'passesFrozenTimingScreen': (all(item['bothHostScreensPass'] is True for item in cross_host.values()) if complete and not issues else None),
        'targetDictionary': 'jitendex', 'crossHost': cross_host, 'cells': cells,
        'activationAndLogicalStorage': activation_storage,
        'acquisitionCheckpoint': checkpoint,
        'limitations': [
            'Thresholds apply separately to each host and each control. No outcome-dependent exclusions or pooled-host substitution.',
            'A successful acquisition job does not establish numerical performance-screen passage.',
            'Browser process sampling is disabled in these timing observations. Memory qualification is separate.',
            'Semantic equality covers the frozen public lookup, persistence/restart and media validation workload; complete parser parity is separate evidence.',
        ],
    }
    (root / 'audit.json').write_text(json.dumps(result, indent=2) + '\n')
    lines = ['# Metadata import timing audit', '',
             f'Workflow run [{binding["runId"]}](https://github.com/ManabiIO/manabitan/actions/runs/{binding["runId"]}) evaluates candidate `{binding["commits"]["candidate"]}` against `{binding["commits"]["baseline"]}` under frozen workflow `{binding["commits"]["workflow"]}`.', '',
             f'Complete audited acquisition: **{complete}**. Frozen timing screen: **{result["passesFrozenTimingScreen"]}**. Missing or invalid evidence remains unqualified.', '',
             '| Corpus | Host | Complete and valid | B vs A median | B vs C median | C vs A median | Faster pairs A / C | Screen |',
             '| --- | ---: | --- | ---: | ---: | ---: | --- | --- |']
    if checkpoint is not None:
        active = sum(job['status'] == 'in_progress' for job in checkpoint['jobs'])
        queued = sum(job['status'] == 'queued' for job in checkpoint['jobs'])
        audited = sum(cell.get('complete') is True and cell.get('integrityAuditPassed') is True for cell in cells)
        lines[4:4] = [f'Acquisition checkpoint **{checkpoint["checkedAtUtc"]}**: {active} running, {queued} queued, {checkpoint.get("completedCells", 0)} completed; {len(checkpoint["artifacts"])} metadata artifacts available. Completed cells audited: {audited}. Polling paused: {checkpoint.get("pollingPaused", False)}.', '']
    if complete and result['passesFrozenTimingScreen'] is False:
        lines[2:2] = ['**The candidate fails the frozen import-speed screen.** Both Jitendex hosts are slower than both baseline controls by median paired timing. The candidate is not qualified for promotion as an import-speed improvement.', '']
    for cell in cells:
        medians = cell.get('medians', {})
        faster = cell.get('fasterPairs', {})
        metric = lambda key: f'{medians[key]:+.3f}%' if key in medians else '—'
        screen = cell.get('performanceScreen') or {}
        valid = cell.get('complete') is True and cell.get('integrityAuditPassed') is True
        lines.append(f'| {cell.get("dictionary", "unknown")} | {cell.get("replica", "?")} | {valid} | {metric("BvsA")} | {metric("BvsC")} | {metric("CvsA")} | {faster.get("BvsA", "—")} / {faster.get("BvsC", "—")} | {screen.get("passes", "unqualified")} |')
    lines += ['', 'Negative paired percentages favor the candidate. Jitendex must improve by at least 5% against both identical-source controls on each host, with at least five of six faster pairs against each control. JMdict and VNDB must not regress by more than 3% against either control on either host.', '',
              f'All {result["verifiedObservations"]} of {result["scheduledObservations"]} scheduled observations were verified; {result["timedObservations"]} contribute to the timing comparisons. The predetermined warmups and full-media validation observations remain in the evidence and are excluded from timing by schedule.', '',
              '## Evidence integrity', '',
              'Each cell audit independently verifies the downloaded artifact digest, every nested release ZIP/member byte, exact source and harness identities, frozen fixture and schedule, every scheduled observation, browser timing boundaries, public lookup/restart/media equality, and the numerical screen recomputed from raw durations. Release ZIPs are hashed without disk retention; report and manifest files remain with their extraction manifest.', '',
              'Cross-host comparisons preserve both hosts. They do not replace either host’s threshold result with a pooled value. Full pair values, errors, source identities and cross-host checks are in [audit.json](audit.json).', '', '## Limits', '']
    lines.extend(f'- {item}' for item in result['limitations'])
    if issues:
        lines += ['', '## Cross-host issues', ''] + [f'- {issue}' for issue in issues]
    for cell in cells:
        errors = cell.get('integrityErrors', []) + [f'{item["name"]}: {item["error"]}' for item in cell.get('observationErrors', [])]
        if errors:
            lines += ['', f'## {cell["name"]} failures', ''] + [f'- {error}' for error in errors]
    (root / 'audit.md').write_text('\n'.join(lines) + '\n')
    print(json.dumps({'complete': complete, 'crossHostIntegrityIssues': issues, 'passesFrozenTimingScreen': result['passesFrozenTimingScreen'], 'json': str(root / 'audit.json'), 'markdown': str(root / 'audit.md')}))


if __name__ == '__main__':
    main()
