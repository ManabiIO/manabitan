#!/usr/bin/env python3
"""Retain activation/storage observations; these add no performance gate."""
import hashlib
import json
from pathlib import Path
import sys

cell = Path(sys.argv[1])
observations = json.loads((cell / 'observations.json').read_text())
rows = []
for item in observations:
    path = cell / item['name'] / 'run-1.json'
    if not path.exists():
        rows.append({'name': item['name'], 'arm': item['arm'], 'phase': item['phase'], 'reportMissing': True})
        continue
    data = path.read_bytes()
    report = json.loads(data)
    phases = [phase for phase in report.get('phases', []) if phase.get('name', '').endswith(': total import')]
    counts = []
    for phase in phases:
        for timing in phase.get('data', {}).get('importDebug', {}).get('importerPhaseTimings', []):
            details = timing.get('details', {})
            if 'fastPathParserNestedMetadataReuseCount' in details:
                counts.append({key: details[key] for key in ['fastPathParserNestedMetadataReuseCount', 'fastPathParserNestedMetadataReuseBytes']})
    storage = report.get('benchmark', {}).get('validation', {}).get('storage', {})
    rows.append({'name': item['name'], 'arm': item['arm'], 'phase': item['phase'],
                 'reportSha256': hashlib.sha256(data).hexdigest(), 'reportStatus': report.get('status'),
                 'metadataReuseDiagnostics': counts,
                 'opfsLogicalFileBytesAfterValidation': storage.get('bytes')})
summary = {}
for arm in ['A', 'B', 'C']:
    selected = [row for row in rows if row['arm'] == arm]
    storage = [row['opfsLogicalFileBytesAfterValidation'] for row in selected if isinstance(row.get('opfsLogicalFileBytesAfterValidation'), int)]
    counts = [diag['fastPathParserNestedMetadataReuseCount'] for row in selected for diag in row.get('metadataReuseDiagnostics', [])]
    bytes_reused = [diag['fastPathParserNestedMetadataReuseBytes'] for row in selected for diag in row.get('metadataReuseDiagnostics', [])]
    summary[arm] = {'observations': len(selected),
                    'opfsLogicalFileBytesRange': [min(storage), max(storage)] if storage else None,
                    'metadataReuseCountRange': [min(counts), max(counts)] if counts else None,
                    'metadataReuseBytesRange': [min(bytes_reused), max(bytes_reused)] if bytes_reused else None}
result = {'schemaVersion': 1, 'purpose': 'Activation and logical-file-size observations only; no additional performance gate or memory claim.', 'summary': summary, 'observations': rows}
(cell / 'activation-and-storage.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(summary, indent=2))
