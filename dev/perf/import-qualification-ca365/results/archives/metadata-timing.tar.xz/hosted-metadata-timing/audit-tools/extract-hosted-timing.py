#!/usr/bin/env python3
"""Verify one Actions artifact, retain reports, and hash release ZIPs in memory.

This only deletes an explicitly selected downloaded artifact with --delete-archive,
after successful extraction and durable evidence-manifest writes.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import zipfile

KEEP_SUFFIXES = {'.json', '.jsonl', '.txt', '.log', '.py', '.yml', '.yaml', '.patch', '.html', '.md', '.sha256', '.csv'}


def digest_stream(source, destination=None):
    digest = hashlib.sha256()
    total = 0
    while block := source.read(1024 * 1024):
        digest.update(block)
        total += len(block)
        if destination is not None:
            destination.write(block)
    return digest.hexdigest(), total


def safe_name(name):
    path = PurePosixPath(name)
    if path.is_absolute() or any(part in {'..', ''} for part in path.parts) or '\\' in name:
        raise ValueError(f'Unsafe archive member: {name!r}')
    if not path.parts:
        raise ValueError('Empty archive member')
    return path


def nested_package(outer, info):
    with outer.open(info) as source:
        archive_sha256, archive_bytes = digest_stream(source)
    members = {}
    sizes = {}
    # ZipExtFile provides a seekable stream; releases are never written to disk.
    # Header-order reads avoid repeated backward decompression of the outer ZIP.
    with outer.open(info) as source, zipfile.ZipFile(source) as package:
        entries = sorted(package.infolist(), key=lambda entry: entry.header_offset)
        for entry in entries:
            safe_name(entry.filename)
            if entry.is_dir():
                continue
            if entry.filename in members:
                raise ValueError(f'Duplicate package member: {entry.filename}')
            with package.open(entry) as content:
                digest, length = digest_stream(content)
            if length != entry.file_size:
                raise ValueError(f'Package member length mismatch: {entry.filename}')
            members[entry.filename] = digest
            sizes[entry.filename] = length
    return {'packageSha256': archive_sha256, 'packageBytes': archive_bytes,
            'memberCount': len(members), 'members': dict(sorted(members.items())),
            'memberBytes': dict(sorted(sizes.items())), 'releaseZipRetained': False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('archive', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--artifact-id', required=True, type=int)
    parser.add_argument('--artifact-name', required=True)
    parser.add_argument('--delete-archive', action='store_true')
    args = parser.parse_args()
    archive = args.archive.resolve()
    output = args.output.resolve()
    if output.exists():
        raise ValueError(f'Refusing to replace existing evidence directory: {output}')
    expected = args.sha256.removeprefix('sha256:').lower()
    if len(expected) != 64 or any(c not in '0123456789abcdef' for c in expected):
        raise ValueError('Expected a SHA-256 digest')
    with archive.open('rb') as source:
        actual, archive_bytes = digest_stream(source)
    if actual != expected:
        raise ValueError(f'Artifact digest mismatch: expected {expected}, received {actual}')
    staging = output.with_name(output.name + '.extracting')
    if staging.exists():
        raise ValueError(f'Refusing to reuse incomplete extraction directory: {staging}')
    staging.mkdir(parents=True)
    packages = {}
    inventory = []
    seen = set()
    with zipfile.ZipFile(archive) as zipped:
        for info in zipped.infolist():
            relative = safe_name(info.filename)
            if info.filename in seen:
                raise ValueError(f'Duplicate artifact member: {info.filename}')
            seen.add(info.filename)
            if info.is_dir():
                continue
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise ValueError(f'Symlink artifact member: {info.filename}')
            row = {'path': info.filename, 'uncompressedBytes': info.file_size}
            if relative.name in {'package-A.zip', 'package-B.zip'}:
                packages[relative.name] = nested_package(zipped, info)
                row.update({'sha256': packages[relative.name]['packageSha256'], 'retained': False,
                            'reason': 'Release ZIP fully hashed; every member hashed without disk retention'})
            else:
                retain = relative.suffix.lower() in KEEP_SUFFIXES
                destination = staging.joinpath(*relative.parts)
                if retain:
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    with zipped.open(info) as source, destination.open('xb') as target:
                        digest, length = digest_stream(source, target)
                else:
                    with zipped.open(info) as source:
                        digest, length = digest_stream(source)
                if length != info.file_size:
                    raise ValueError(f'Artifact member length mismatch: {info.filename}')
                row.update({'sha256': digest, 'retained': retain})
                if not retain:
                    row['reason'] = 'Non-report payload; content hash retained in extraction manifest'
            inventory.append(row)
    evidence_files = {path.name: path for path in staging.rglob('*') if path.is_file()}
    for name, verification in packages.items():
        arm = name.removeprefix('package-').removesuffix('.zip')
        receipt = evidence_files.get(f'package-{arm}-receipt.json')
        member_manifest = evidence_files.get(f'package-{arm}-members.json')
        if receipt is None or member_manifest is None:
            raise ValueError(f'Release {arm} has no retained receipt/member manifest')
        expected_receipt = json.loads(receipt.read_text())
        expected_members = json.loads(member_manifest.read_text())
        if expected_receipt['packageSha256'] != verification['packageSha256']:
            raise ValueError(f'Release {arm} archive differs from receipt')
        if expected_members != verification['members']:
            raise ValueError(f'Release {arm} member bytes differ from manifest')
        if expected_receipt['memberCount'] != verification['memberCount']:
            raise ValueError(f'Release {arm} member count differs from receipt')
        verification['matchesReceiptAndMemberManifest'] = True
    manifest = {'schemaVersion': 1, 'artifactId': args.artifact_id, 'artifactName': args.artifact_name,
                'artifactSha256': actual, 'artifactBytes': archive_bytes,
                'downloadDigestVerified': True, 'files': inventory,
                'retainedBytes': sum(row['uncompressedBytes'] for row in inventory if row['retained']),
                'packageZipsRetained': False, 'deleteDownloadedArtifactRequested': args.delete_archive}
    (staging / 'package-verification.json').write_text(json.dumps(packages, indent=2) + '\n')
    (staging / 'extraction-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    staging.rename(output)
    if args.delete_archive:
        archive.unlink()
    print(json.dumps({'artifactId': args.artifact_id, 'output': str(output), 'artifactSha256': actual,
                      'retainedBytes': manifest['retainedBytes'], 'verifiedPackages': list(packages),
                      'downloadedArtifactDeleted': args.delete_archive}, indent=2))


if __name__ == '__main__':
    main()
