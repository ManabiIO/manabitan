#!/usr/bin/env python3
"""Recompute only the already acquired screen; never launches an import."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import random
import statistics
import subprocess
import sys
from functools import lru_cache

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'manabitan'
BASE = '7d1643e6147a10cb2165e9744cf0e63b59e46632'
CANDIDATE = '7a8b25a44a3fe165107ed816377cc72bb0fac67d'
FOLLOWUP = '5afd2e97ec2707b150acfde61115aee688547a78'
TOOLING = 'ae85fc50a77ce5d13cb9001ad376f741f915ec7a'
spec = importlib.util.spec_from_file_location('timing_auditor', ROOT.parent / 'audit-hosted-timing.py')
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def read(path):
    return json.loads(path.read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


@lru_cache(maxsize=None)
def git_data(commit, path):
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=REPO)


@lru_cache(maxsize=None)
def tree(commit):
    return subprocess.check_output(['git', 'rev-parse', f'{commit}^{{tree}}'], cwd=REPO, text=True).strip()


def compare(left, right):
    changes = [(b / a - 1) * 100 for a, b in zip(left, right)]
    randomizer = random.Random(20261124)
    samples = sorted(statistics.median(randomizer.choices(changes, k=6)) for _ in range(10000))
    return dict(pairs=6, fasterPairs=sum(value < 0 for value in changes), worstPairPercent=max(changes),
                bestPairPercent=min(changes), pairedChangesPercent=changes,
                pairedMedianPercent=statistics.median(changes),
                pairedMedianBootstrap95Percent=[samples[249], samples[9749]],
                equalWorkPercent=(sum(right) / sum(left) - 1) * 100,
                baselineMedianMs=statistics.median(left), candidateMedianMs=statistics.median(right))


result = {'runId': '45642169759', 'stage': 'existing single-host screen per corpus',
          'toolingCommit': TOOLING, 'baselineCommit': BASE, 'candidateCommit': CANDIDATE,
          'separateFrom': ['45647030745', '45642179064'], 'newImportsExecuted': 0,
          'memoryQualified': False, 'dictionaries': {},
          'auditedAtUtc': datetime.now(timezone.utc).isoformat(), 'auditPythonVersion': sys.version,
          'auditorSha256': sha(Path(__file__).read_bytes()),
          'semanticHelperSha256': sha((ROOT.parent / 'audit-hosted-timing.py').read_bytes())}
product_delta = subprocess.check_output(['git', 'diff', '--name-only', CANDIDATE, FOLLOWUP, '--', 'ext', 'dev/data/dictionary-wasm'], cwd=REPO, text=True)
assert product_delta == '', product_delta
result['productIdenticalToFollowup'] = FOLLOWUP
for dictionary in ['jmdict', 'jitendex', 'vndb']:
    directory = ROOT / f'current-media-screen-{dictionary}-2754'
    cohort = directory / 'cohort'
    protocol = read(cohort / 'protocol.json')
    assert protocol['toolingCommit'] == TOOLING
    assert protocol['github']['GITHUB_RUN_ID'] == result['runId']
    assert protocol['github']['GITHUB_RUN_ATTEMPT'] == '1'
    assert protocol['harnessOverlay'] is None
    assert protocol['nodeVersion'] == 'v22.22.0'
    assert (directory / 'runner.py').read_bytes() == (ROOT / 'tooling-source/runner.py').read_bytes()
    assert (directory / 'workflow.yml').read_bytes() == (ROOT / 'tooling-source/workflow.yml').read_bytes()
    assert sha((directory / 'runner.py').read_bytes()) == protocol['runnerSha256']
    packages = {arm: read(cohort / f'package-{arm}.json') for arm in 'ABC'}
    for arm in 'ABC':
        commit = CANDIDATE if arm == 'B' else BASE
        identity = {'commit': commit, 'tree': tree(commit)}
        assert protocol['sourceIdentities'][arm] == identity == packages[arm]['source']
        assert len(packages[arm]['entries']) == len(packages['A']['entries'])
        for member in protocol['expectedPackageDifferences']:
            source = 'dev/data/dictionary-wasm/term-bank-parser.wasm' if member == 'lib/term-bank-parser.wasm' else 'ext/' + member
            assert packages[arm]['entries'][member] == sha(git_data(commit, source)), (arm, member)
        for path in audit.HARNESS_PATHS:
            assert protocol['unchangedHarnessSha256'][path] == sha(git_data(commit, path)), (arm, path)
    assert packages['C'] == {**packages['A'], 'identicalArchiveFromArm': 'A'}
    changed = sorted(path for path in packages['A']['entries'].keys() | packages['B']['entries'].keys()
                     if packages['A']['entries'].get(path) != packages['B']['entries'].get(path))
    assert changed == sorted(protocol['expectedPackageDifferences']) == read(cohort / 'package-differences.json')
    fixture = json.loads(git_data(BASE, 'test/perf/dictionaries.lock.json'))['dictionaries'][dictionary]
    assert protocol['fixture'] == fixture
    observations = read(cohort / 'observations.json')
    names = [f'warmup-{arm}' for arm in 'ABC']
    names += [f'block-{block:02}-{position}-{arm}' for block, order in enumerate(protocol['orders'], 1) for position, arm in enumerate(order, 1)]
    names += ['diagnostic-A', 'diagnostic-B']
    assert len(observations) == 23 and [row['name'] for row in observations] == names
    assert all(row['status'] == 'success' for row in observations)
    semantics = {}
    timings = {arm: [] for arm in 'ABC'}
    storage = set()
    non_sah = None
    for row in observations:
        report = read(cohort / row['name'] / 'run-1.json')
        summary = read(cohort / row['name'] / 'summary.json')
        assert row['source'] == packages[row['arm']]['source']
        assert summary['gitSha'] == row['source']['commit']
        assert summary['authoritativeTiming'] is True and summary['traceEnabled'] is False
        assert report['packageSha256'] == packages[row['arm']]['archiveSha256']
        assert report['browserVersion'] == '153.0.8010.12'
        assert report['status'] == 'success' and report['skippedVerification'] is False
        semantic = audit.verify_semantic(report, fixture, row['mediaCheck'])
        assert row['mediaCheck'] not in semantics or semantic == semantics[row['mediaCheck']]
        semantics[row['mediaCheck']] = semantic
        phases = [phase for phase in report['phases'] if phase['name'] == fixture['label'] + ': total import']
        assert len(phases) == 1
        clock = phases[0]['data']['browserTiming']
        elapsed = clock['completedAtMs'] - clock['startedAtMs']
        assert elapsed == row['totalImportMs'] == summary['runs'][0]['totalImportMs']
        if row['cohort'] == 'timed':
            timings[row['arm']].append(elapsed)
        receipt = read(cohort / row['name'] / 'storage-receipt.json')
        raw_bytes = sum(entry['bytes'] for entry in receipt['rawFiles'])
        assert raw_bytes == receipt['rawStorageBytes'] == row['storageBytes'] == report['benchmark']['validation']['storage']['bytes']
        storage.add(raw_bytes)
        assert non_sah is None or non_sah == receipt['nonSahFiles']
        non_sah = receipt['nonSahFiles']
    assert all(len(values) == 6 for values in timings.values())
    analysis = read(cohort / 'analysis.json')
    assert analysis['status'] == 'complete' and analysis['screeningOnly'] is True and analysis['independentQualificationRequired'] is True
    assert analysis['allTimingsMs'] == timings
    recalculated = {'candidate': compare(timings['A'], timings['B']),
                    'candidateVsSecondBaseline': compare(timings['C'], timings['B']),
                    'identicalProductControl': compare(timings['A'], timings['C'])}
    for name, values in recalculated.items():
        for key, value in values.items():
            assert analysis[name][key] == value, (dictionary, name, key)
    result['dictionaries'][dictionary] = {
        'observations': len(observations), 'timedObservations': 18, 'exhaustiveDiagnostics': 2,
        'sourceAndCriticalPackageMemberHashesMatchGit': True,
        'packageMemberCountPerArm': len(packages['A']['entries']),
        'rawBrowserTimesAndAllAnalysisFieldsRecomputed': True,
        'semanticDigests': {mode: audit.semantic_digest(value) for mode, value in semantics.items()},
        'exhaustiveMedia': semantics['all']['media'], 'observedStorageBytes': sorted(storage),
        'comparisons': recalculated,
    }
assert result['dictionaries']['vndb']['observedStorageBytes'] == [609553611]
reopened = read(ROOT / 'reopened-reports.json')
assert reopened['runId'] == result['runId']
assert sum(row['observations'] for row in reopened['dictionaries'].values()) == 69
result['reopenedUsingUnchangedProductionValidator'] = 69
result['limits'] = [
    'One existing six-block host per corpus; no independent qualification claim',
    'Release ZIP bytes were not present in these artifacts; package receipts and critical source-bound member hashes were reconciled, not freshly rehashed release archives',
    'Separate current/historical memory failures remain unresolved',
]
(ROOT / 'independent-audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'runId': result['runId'], 'observations': 69, 'dictionaries': {
    key: {name: value['comparisons'][field]['pairedMedianPercent'] for name, field in [('BvsA', 'candidate'), ('BvsC', 'candidateVsSecondBaseline'), ('CvsA', 'identicalProductControl')]}
    for key, value in result['dictionaries'].items()}}, indent=2))
