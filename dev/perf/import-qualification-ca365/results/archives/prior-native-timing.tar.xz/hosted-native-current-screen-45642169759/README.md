# Independent audit of the existing current-source native projection screen

This directory preserves and audits the already completed
[run 45642169759](https://github.com/ManabiIO/manabitan/actions/runs/45642169759),
attempt 1, tooling commit `ae85fc50a77ce5d13cb9001ad376f741f915ec7a`.
No new imports were acquired.

A/C source: `7d1643e6147a10cb2165e9744cf0e63b59e46632`.
B source: `7a8b25a44a3fe165107ed816377cc72bb0fac67d`.
Git comparison confirms the shipped product is identical to the later test-only
follow-up `5afd2e97ec2707b150acfde61115aee688547a78`; the original study remains
at its original B commit.

All three downloaded artifact digests match GitHub metadata. All 69 raw reports
were reopened with the unchanged production validator. Source identities,
critical packaged JS/C/WASM member hashes, unchanged harness hashes, complete
observation order, browser/runtime/package receipts, lookup/restart/media
semantics, and raw browser durations reconcile. Every paired statistic and the
original deterministic descriptive bootstrap interval were recomputed.

| Corpus | B/A paired median | B/C paired median | C/A control |
| --- | ---: | ---: | ---: |
| JMdict | −1.0439% | −1.1512% | +0.0549% |
| Jitendex | −0.1231% | +0.0482% | +0.3524% |
| VNDB | −5.0427% | −4.0169% | −0.6947% |

Each corpus has one separate host with three excluded warmups, six timing
triplets and two exhaustive diagnostics: 23 observations per corpus. For VNDB,
B is faster in five of six A comparisons and all six C comparisons. The original
descriptive intervals are [−6.5649%, −1.8562%] against A and
[−5.7527%, −2.9346%] against C. The baseline/candidate medians are 6,593.85 and
6,292.20 ms, and equal-work B/A is −4.5244%.

Both VNDB exhaustive diagnostics verify 146,570 images / 188,131,284 bytes, with
digest `ea94d392bc833baf0bee7b3d6becc3d3517eee84ee314a44986438ac6d5217cb`.
All 23 VNDB observations in this older screen use 609,553,611 OPFS bytes.

These remain exploratory single-host screens. They are not pooled with the
separately planned 45647030745 cohort, and do not resolve any memory hold.
The artifacts do not contain release ZIP bytes; this new audit reconciles their
receipts and critical source-bound member hashes but does not freshly rehash
those unavailable release archives. Each retained package manifest has 551
members; archive membership depends on the recorded build context.

`independent-audit.json` records the complete recalculation and limits;
`reopened-reports.json` records the validator pass for all 69 reports;
`github-provenance.json` identifies original artifacts and digests. The original
artifact contents, fetched tooling source, and read-only audit scripts remain.
