import fs from 'node:fs/promises'
import path from 'node:path'
import {createHash} from 'node:crypto'
import {fileURLToPath} from 'node:url'
import {extractImportResult} from '../vndb/dev/perf/benchmark-support.js'

const root = path.dirname(fileURLToPath(import.meta.url))
const harnessPath = new URL('../vndb/dev/perf/benchmark-support.js', import.meta.url)
const harnessSha256 = createHash('sha256').update(await fs.readFile(harnessPath)).digest('hex')
const read = async file => JSON.parse(await fs.readFile(file, 'utf8'))
const require = (condition, message) => { if (!condition) throw new Error(message) }
const result = {kind: 'reopen-existing-correctness-reports', runId: '45642169759', auditNodeVersion: process.version, harnessSha256, dictionaries: {}}
for (const dictionary of ['jmdict', 'jitendex', 'vndb']) {
    const directory = path.join(root, `current-media-screen-${dictionary}-2754`, 'cohort')
    const protocol = await read(path.join(directory, 'protocol.json'))
    require(protocol.unchangedHarnessSha256['dev/perf/benchmark-support.js'] === harnessSha256, 'Audit validator differs from frozen source')
    const observations = await read(path.join(directory, 'observations.json'))
    const receipts = Object.fromEntries(await Promise.all(['A', 'B', 'C'].map(async arm => [arm, await read(path.join(directory, `package-${arm}.json`))])))
    const checked = []
    for (const observation of observations) {
        const report = await read(path.join(directory, observation.name, 'run-1.json'))
        const summary = await read(path.join(directory, observation.name, 'summary.json'))
        const receipt = receipts[observation.arm]
        require(observation.status === 'success', `${dictionary}/${observation.name}: failed observation`)
        require(summary.gitSha === receipt.source.commit && observation.source.commit === receipt.source.commit, 'Source receipt mismatch')
        require(report.packageSha256 === receipt.archiveSha256 && summary.runs[0].packageSha256 === receipt.archiveSha256, 'Package receipt mismatch')
        require(report.browserVersion === '153.0.8010.12' && summary.browserVersion === report.browserVersion, 'Browser mismatch')
        require(summary.authoritativeTiming === true && summary.traceEnabled === false, 'Non-authoritative timing')
        require(summary.hostEnvironment.nodeVersion === 'v22.22.0', 'Acquisition Node runtime mismatch')
        require(summary.runs.length === 1 && report.buildTarget === 'chrome', 'Not one release Chrome import')
        const extracted = extractImportResult(report, dictionary, protocol.fixture, false, null, observation.mediaCheck)
        require(extracted.totalImportMs === observation.totalImportMs && extracted.totalImportMs === summary.runs[0].totalImportMs, 'Raw browser time differs from recorded duration')
        checked.push({name: observation.name, arm: observation.arm, cohort: observation.cohort, block: observation.block, mediaCheck: observation.mediaCheck, totalImportMs: extracted.totalImportMs})
    }
    result.dictionaries[dictionary] = {observations: checked.length, verified: checked}
}
await fs.writeFile(path.join(root, 'reopened-reports.json'), JSON.stringify(result, null, 2) + '\n')
console.log(JSON.stringify({runId: result.runId, dictionaries: Object.fromEntries(Object.entries(result.dictionaries).map(([key, value]) => [key, value.observations]))}))
