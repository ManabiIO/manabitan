"""Read the checked Zstd WASM's DCtx malloc request without rebuilding it."""

import hashlib
import json
import re
import sys
from pathlib import Path


def read_u32(data, position):
    value = 0
    shift = 0
    while True:
        byte = data[position]
        position += 1
        value |= (byte & 127) << shift
        if not byte & 128:
            return value, position
        shift += 7


def read_string(data, position):
    length, position = read_u32(data, position)
    return data[position:position + length].decode(), position + length


root = Path(sys.argv[1])
binary = (root / 'dev/data/zstd-simd.wasm').read_bytes()
assert binary[:8] == b'\0asm\1\0\0\0'
position = 8
sections = {}
while position < len(binary):
    section_id = binary[position]
    length, position = read_u32(binary, position + 1)
    sections[section_id] = binary[position:position + length]
    position += length

imports = sections[2]
import_count, position = read_u32(imports, 0)
for _ in range(import_count):
    _, position = read_string(imports, position)
    _, position = read_string(imports, position)
    assert imports[position] == 0, 'Expected function imports only'
    _, position = read_u32(imports, position + 1)

export_section = sections[7]
export_count, position = read_u32(export_section, 0)
exports = {}
for _ in range(export_count):
    name, position = read_string(export_section, position)
    kind = export_section[position]
    index, position = read_u32(export_section, position + 1)
    if kind == 0:
        exports[name] = index

code = sections[10]
function_count, position = read_u32(code, 0)
functions = []
for _ in range(function_count):
    length, position = read_u32(code, position)
    functions.append(code[position:position + length])
    position += length

wrapper = (root / 'dev/lib/zstd-simd-module.js').read_text()
dctx_export = re.search(r'Module\["_ZSTD_createDCtx"\]=wasmExports\["([^"]+)"\]', wrapper)[1]
malloc_export = re.search(r'Module\["_malloc"\]=wasmExports\["([^"]+)"\]', wrapper)[1]
body = functions[exports[dctx_export] - import_count]
local_groups, position = read_u32(body, 0)
for _ in range(local_groups):
    _, position = read_u32(body, position)
    position += 1
instruction_start = position
assert body[position] == 0x41, 'Expected initial i32.const malloc size'
allocation_bytes, position = read_u32(body, position + 1)
assert body[position] == 0x10, 'Expected direct malloc call after size'
callee, position = read_u32(body, position + 1)
assert callee == exports[malloc_export]
worker_source = (root / 'ext/js/dictionary/zstd-term-content.js').read_text()
worker_count = int(re.search(r'const COMPRESSION_WORKER_COUNT = (\d+)', worker_source)[1])
print(json.dumps({
    'artifact': 'dev/data/zstd-simd.wasm',
    'sha256': hashlib.sha256(binary).hexdigest(),
    'dctx_export': dctx_export,
    'dctx_function': exports[dctx_export],
    'malloc_export': malloc_export,
    'malloc_function': exports[malloc_export],
    'decoded_instruction_prefix': f'i32.const {allocation_bytes}; call {callee}',
    'instruction_prefix_hex': body[instruction_start:position].hex(' '),
    'native_allocation_request_bytes_per_context': allocation_bytes,
    'compression_worker_count': worker_count,
    'native_allocation_request_bytes_avoided_per_pool': allocation_bytes * worker_count,
    'scope': 'Native allocator request bytes; excludes allocator overhead. Not an RSS, WASM capacity, or throughput measurement.',
}, indent=2))
