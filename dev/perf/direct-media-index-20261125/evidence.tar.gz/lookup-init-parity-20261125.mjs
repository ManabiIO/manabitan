import {createHash} from 'node:crypto'
import {readFile, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
import assert from 'node:assert/strict'
import {ZipReader, Uint8ArrayReader, Uint8ArrayWriter} from '@zip.js/zip.js'

// Untimed replay of the existing two-worker lazy source partition policy.
// Groups execute sequentially here; this is not an end-to-end import benchmark.
// Run from the candidate checkout:
// node builds/perf/lookup-init-parity-20261125.mjs BASELINE_ROOT [DICTIONARY]
const candidateRoot = process.cwd()
const baselineRoot = path.resolve(process.argv[2])
const dictionary = process.argv[3] ?? 'jmdict'
const sha = (value) => createHash('sha256').update(value).digest('hex')
const lockBytes = await readFile(path.join(candidateRoot, 'test/perf/dictionaries.lock.json'))
const lock = JSON.parse(lockBytes).dictionaries[dictionary]
assert.ok(lock)
const archive = await readFile(path.join(candidateRoot, 'builds/e2e-dictionary-cache', lock.cacheFile))
assert.equal(sha(archive), lock.sha256)
const arms = []
for (const root of [baselineRoot, candidateRoot]) {
    const parser = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-bank-wasm-parser.js')).href)
    const prep = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-lookup-index-preparation.js')).href)
    const wasmBytes = await readFile(path.join(root, 'ext/lib/term-bank-parser.wasm'))
    parser.setTermBankWasmModule(await WebAssembly.compile(wasmBytes))
    arms.push({parser, prep, wasmSha256: sha(wasmBytes)})
}
const {hashTermKeyBytes} = await import(pathToFileURL(path.join(baselineRoot, 'ext/js/dictionary/term-key-hash.js')).href)
const normalizePlan = (plan) => {
    const offsets = new Uint32Array(plan.stringLengths.length)
    const hashes = new Uint32Array(plan.stringLengths.length)
    let cursor = 0
    for (let key = 0; key < offsets.length; ++key) {
        offsets[key] = cursor
        hashes[key] = hashTermKeyBytes(plan.stringsBuffer.subarray(cursor, cursor + plan.stringLengths[key]))
        cursor += plan.stringLengths[key]
    }
    // Supplied optional columns stay authoritative; reconstruct only omission.
    return {...plan, stringOffsets: plan.stringOffsets ?? offsets, stringHashes: plan.stringHashes ?? hashes}
}
const options = {
    singleChunk: true,
    emitTermByteLists: false,
    computeContentHashes: true,
    emitContentSlab: true,
    emitTokenBinaryContent: true,
    mediaHintFastScan: lock.mediaFiles > 0,
    validateGlossaryTypes: true,
    prepareLookupIndexes: true,
}
const rows = []
let partitionPlan
const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)))
try {
    const entries = (await reader.getEntries()).filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename))
        .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
    const totalBytes = entries.reduce((total, entry) => total + entry.uncompressedSize, 0)
    const groupCount = Math.min(entries.length, Math.max(2 * (options.mediaHintFastScan ? 3 : 4), Math.ceil(totalBytes / (24 * 1024 * 1024))))
    partitionPlan = {workers: 2, media: options.mediaHintFastScan, lazyTargetBytes: 24 * 1024 * 1024, totalBytes, groupCount}
    // Same byte-balancing calculation as partitionSourceBanks; consume validated
    // ZIP sizes, retaining exact bank membership in the output for replay.
    const groups = []
    let start = 0
    let consumedBytes = 0
    for (let groupIndex = 0; groupIndex < groupCount - 1; ++groupIndex) {
        const remainingGroups = groupCount - groupIndex
        const targetBytes = (totalBytes - consumedBytes) / remainingGroups
        let end = start + 1
        let bytes = entries[start].uncompressedSize
        const maxEnd = entries.length - (remainingGroups - 1)
        while (end < maxEnd) {
            const nextBytes = bytes + entries[end].uncompressedSize
            if (Math.abs(nextBytes - targetBytes) > Math.abs(bytes - targetBytes)) { break }
            bytes = nextBytes
            ++end
        }
        groups.push(entries.slice(start, end))
        start = end
        consumedBytes += bytes
    }
    groups.push(entries.slice(start))
    for (const selected of groups) {
        const banks = await Promise.all(selected.map((entry) => entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true})))
        const outputs = []
        const profiles = []
        const native = []
        for (const {parser, prep} of arms) {
            let result
            await parser.parseTermBankWithWasmColumnChunks(banks, 3, (chunk) => {
                result = parser.copyWasmBackedColumnChunk(chunk)
            }, 2048, options)
            assert.ok(result)
            native.push(Boolean(result.preparedLookupIndexes))
            profiles.push(parser.consumeLastTermBankWasmParseProfile())
            if (!result.preparedLookupIndexes) {
                result.preparedLookupIndexes = prep.prepareTermLookupIndexesFromPreinternedPlan(result)?.indexes
            }
            assert.ok(result.preparedLookupIndexes)
            outputs.push(result)
        }
        const [a, b] = outputs
        assert.equal(b.rowCount, a.rowCount)
        for (const key of [
            'readingEqualsExpressionList', 'scoreList', 'sequenceList',
            'contentBytesBuffer', 'contentMetaList', 'contentUniqueIndexList',
            'contentHash1List', 'contentHash2List',
            'contentBytesBaseOffset', 'contentBytesLength', 'contentMetaByUniqueIndex',
        ]) {
            assert.deepEqual(b[key], a[key], key)
        }
        assert.deepEqual(b.mediaRows, a.mediaRows)
        assert.deepEqual(normalizePlan(b.termRecordPreinternedPlan), normalizePlan(a.termRecordPreinternedPlan))
        assert.equal(b.preparedLookupIndexes.size, a.preparedLookupIndexes.size)
        let avoidedInitializationBytes = 0
        let indexBytes = 0
        let avoidedKeyCopyBytes = 0
        const hashes = []
        for (const [key, index] of a.preparedLookupIndexes) {
            const actual = b.preparedLookupIndexes.get(key)
            assert.ok(actual)
            assert.deepEqual(actual.bytes, index.bytes)
            assert.deepEqual(normalizePlan(actual.preinternedPlan), normalizePlan(index.preinternedPlan))
            hashes.push({key, sha256: sha(index.bytes), byteLength: index.bytes.byteLength})
            const header = new Uint32Array(index.bytes.buffer, index.bytes.byteOffset, 4)
            const base = new Uint32Array(index.bytes.buffer, index.bytes.byteOffset + 16, 8)
            const derived = new Uint32Array(index.bytes.buffer, index.bytes.byteOffset + 16 + header[2], 8)
            const align4 = (value) => (value + 3) & ~3
            const baseU16Bytes = (base[1] + base[0] * 3) * 2
            const derivedU16Bytes = (
                derived[2] + derived[1] + (derived[1] + 1) + derived[0] +
                (derived[1] + 1) + derived[4] + derived[3] + derived[5] +
                (derived[5] + 1) + derived[6]
            ) * 2
            const remainingZeroBytes = 8 + (align4(base[2]) - base[2]) +
                (align4(baseU16Bytes) - baseU16Bytes) + 4 * (base[1] + 1) +
                2 * (base[4] + 1) + (align4(derivedU16Bytes) - derivedU16Bytes)
            if (native.every(Boolean)) {
                avoidedInitializationBytes += index.bytes.byteLength + 2 * (base[1] + base[4]) - remainingZeroBytes
            }
            if (profiles.every((profile) => profile.nativeSegmentedLookupSegments > 0)) { avoidedKeyCopyBytes += base[2] }
            indexBytes += index.bytes.byteLength
        }
        const avoidedKeyScratchBytes = profiles.every((profile) => profile.nativeSegmentedLookupSegments > 0) ?
            profiles[0].nativeLookupScratchReusedBytes - profiles[1].nativeLookupScratchReusedBytes : 0
        assert.ok(avoidedKeyScratchBytes >= 0)
        rows.push({firstBank: selected[0].filename, lastBank: selected.at(-1).filename, banks: selected.length, rows: a.rowCount,
            native, baselineSegments: profiles[0].nativeSegmentedLookupSegments, candidateSegments: profiles[1].nativeSegmentedLookupSegments,
            baselineFallbacks: profiles[0].nativeSegmentedLookupFallbacks, candidateFallbacks: profiles[1].nativeSegmentedLookupFallbacks,
            baselineWasmHeap: profiles[0].maxWasmHeapBytes, candidateWasmHeap: profiles[1].maxWasmHeapBytes,
            indexBytes, avoidedInitializationBytes, avoidedKeyCopyBytes, avoidedKeyScratchBytes, hashes})
    }
} finally {
    await reader.close()
}
assert.equal(rows.reduce((total, row) => total + row.rows, 0), lock.termRows)
const report = {
    dictionary,
    lockSha256: sha(lockBytes),
    fixtureSha256: lock.sha256,
    baselineWasmSha256: arms[0].wasmSha256,
    candidateWasmSha256: arms[1].wasmSha256,
    partitionPlan,
    rows: lock.termRows,
    banks: rows.reduce((total, row) => total + row.banks, 0),
    indexBytes: rows.reduce((total, row) => total + row.indexBytes, 0),
    avoidedInitializationBytes: rows.reduce((total, row) => total + row.avoidedInitializationBytes, 0),
    avoidedKeyCopyBytes: rows.reduce((total, row) => total + row.avoidedKeyCopyBytes, 0),
    avoidedKeyScratchBytes: rows.reduce((total, row) => total + row.avoidedKeyScratchBytes, 0),
    baselineSegments: rows.reduce((total, row) => total + row.baselineSegments, 0),
    candidateSegments: rows.reduce((total, row) => total + row.candidateSegments, 0),
    baselineFallbacks: rows.reduce((total, row) => total + row.baselineFallbacks, 0),
    candidateFallbacks: rows.reduce((total, row) => total + row.candidateFallbacks, 0),
    groups: rows,
}
await writeFile(path.join(candidateRoot, `builds/perf/lookup-init-parity-${dictionary}-20261125.json`), JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify({...report, groups: report.groups.length}, null, 2))
