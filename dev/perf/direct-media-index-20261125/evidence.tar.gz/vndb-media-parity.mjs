import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {createReadStream, openAsBlob} from 'node:fs'
import {readFile, writeFile} from 'node:fs/promises'
import {pathToFileURL} from 'node:url'

const [baselineRoot, candidateRoot, output] = process.argv.slice(2)
const moduleAt = (root, path) => import(pathToFileURL(`${root}/${path}`).href)
const lock = JSON.parse(await readFile(`${candidateRoot}/test/perf/dictionaries.lock.json`, 'utf8')).dictionaries.vndb
const archivePath = `${candidateRoot}/builds/e2e-dictionary-cache/${lock.cacheFile}`
const archive = await openAsBlob(archivePath)
assert.equal(archive.size, lock.sizeBytes)

async function hash(stream) {
    const value = createHash('sha256')
    for await (const part of stream) value.update(part)
    return value.digest('hex')
}

assert.equal(await hash(createReadStream(archivePath)), lock.sha256)
const [{readDenseZipDirectory}, {getImageMediaTypeFromFileName}] = await Promise.all([
    moduleAt(baselineRoot, 'ext/js/dictionary/dense-zip-directory.js'),
    moduleAt(baselineRoot, 'ext/js/media/media-util.js'),
])
const entries = await readDenseZipDirectory(archive)
assert(entries !== null)
const files = entries.filter(({filename}) => getImageMediaTypeFromFileName(filename) !== null)
assert.equal(files.length, lock.mediaFiles)
const [{preparePackedSourceZipMediaEntries}, {createGenerationMediaIndex}, baselineParser, baselineReader] = await Promise.all([
    moduleAt(baselineRoot, 'ext/js/dictionary/source-zip-media-pack.js'),
    moduleAt(baselineRoot, 'ext/js/dictionary/dictionary-generation-media-store.js'),
    moduleAt(baselineRoot, 'ext/js/dictionary/term-bank-wasm-parser.js'),
    moduleAt(baselineRoot, 'ext/js/dictionary/term-bank-source-pipeline.js'),
])
const [{preparePackedSourceZipMediaIndex}, candidateParser, candidateReader] = await Promise.all([
    moduleAt(candidateRoot, 'ext/js/dictionary/source-zip-media-pack.js'),
    moduleAt(candidateRoot, 'ext/js/dictionary/term-bank-wasm-parser.js'),
    moduleAt(candidateRoot, 'ext/js/dictionary/term-bank-source-pipeline.js'),
])
baselineParser.setTermBankWasmModule(await WebAssembly.compile(await readFile(`${baselineRoot}/ext/lib/term-bank-parser.wasm`)))
candidateParser.setTermBankWasmModule(await WebAssembly.compile(await readFile(`${candidateRoot}/ext/lib/term-bank-parser.wasm`)))
const baseline = await preparePackedSourceZipMediaEntries(archive, files, new baselineReader.RawZipPayloadReader(archive), () => {})
assert(baseline !== null)
const baselinePlan = createGenerationMediaIndex(baseline.records, baseline.blob.size)
assert(baselinePlan !== null)
const candidate = await preparePackedSourceZipMediaIndex(archive, files, new candidateReader.RawZipPayloadReader(archive), () => {})
assert(candidate !== null)
assert.deepEqual(candidate.plan, baselinePlan)
assert.equal(candidate.blob.size, baseline.blob.size)
assert.equal(candidate.uncompressedBytes, lock.mediaBytes)
for (const key of ['rangeReadCount', 'rangeReadBytes', 'compressedBytes', 'uncompressedBytes']) assert.equal(candidate[key], baseline[key])
const baselineBlobSha256 = await hash(baseline.blob.stream())
const candidateBlobSha256 = await hash(candidate.blob.stream())
assert.equal(candidateBlobSha256, baselineBlobSha256)
const result = {
    fixture: {bytes: archive.size, sha256: lock.sha256},
    mediaCount: files.length,
    mediaBytes: candidate.uncompressedBytes,
    descriptor: candidate.plan.descriptor,
    indexBytes: candidate.plan.index.byteLength,
    indexSha256: createHash('sha256').update(candidate.plan.index).digest('hex'),
    payloadBytes: candidate.blob.size,
    payloadSha256: candidateBlobSha256,
    rangeReadCount: candidate.rangeReadCount,
    rangeReadBytes: candidate.rangeReadBytes,
    compressedBytes: candidate.compressedBytes,
    fullRecordObjectsAvoided: baseline.records.length,
    byteParity: true,
    metricsParity: true,
    timingClaim: false,
}
await writeFile(output, `${JSON.stringify(result, null, 2)}\n`)
console.log(JSON.stringify(result, null, 2))
