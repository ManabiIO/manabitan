"""Restore pinned LLVM21.1.8 in an isolated temporary directory, no installation."""
import concurrent.futures
import hashlib
import json
from pathlib import Path
import subprocess
import urllib.request

root = Path('/tmp/manabitan-81585d-toolchain')
root.mkdir(exist_ok=True)
version = '21.1.8~++20251221032947+2078da43e25a-1~exp1~20251221153113.67'
packages = {
    'clang-21': '43167d4912316e591f4dc122bd8e9cd0c2db95c31edcc47cde97e89a496c2024',
    'libclang-common-21-dev': '8b5d26e30f336b0f5727f506b9d3e31890d225efc1a5eb1f73ab4e253ced9da6',
    'libclang-cpp21': '2e04f5de6f6f877f505a7abee85e1210d71b3b07d380ec5ebfaec45efe5a7fea',
    'libclang1-21': '9ba73f312d5e76875363f493287ad6a5ee6754c22bbca3a07061ae07c1129659',
    'libllvm21': '06646d519de58f391ca049b8a47bbd678c929540f4cb8a73caac29818c5cf720',
    'lld-21': '498f0690630be48f0f11e3c62bedc0d646ed2951c10c707e388a322cd9b93a0f',
}

def fetch(item):
    name, digest = item
    url = f'https://apt.llvm.org/bookworm/pool/main/l/llvm-toolchain-21/{name}_{version}_amd64.deb'
    target = root / f'{name}.deb'
    with urllib.request.urlopen(url, timeout=30) as response, target.open('wb') as out:
        while block := response.read(1024 * 1024):
            out.write(block)
    actual = hashlib.file_digest(target.open('rb'), 'sha256').hexdigest()
    if actual != digest:
        raise RuntimeError(f'Package checksum mismatch: {name}')
    print(f'Verified {name}', flush=True)
    return {'name': name, 'url': url, 'sha256': digest, 'bytes': target.stat().st_size}

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    receipts = list(pool.map(fetch, packages.items()))
for receipt in receipts:
    subprocess.run(['dpkg-deb', '--extract', str(root / f"{receipt['name']}.deb"), str(root)], check=True)
Path(__file__).with_name('toolchain-packages.json').write_text(json.dumps(receipts, indent=2) + '\n')
print(str(root), flush=True)
