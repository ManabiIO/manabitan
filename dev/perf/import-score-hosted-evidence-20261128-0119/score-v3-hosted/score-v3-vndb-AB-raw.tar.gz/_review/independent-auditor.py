#!/usr/bin/env python3
"""Read-only independent audit of one explicitly bound import browser cohort.

Rebuild timing statistics from browser monotonic events, revalidate every raw
semantic receipt, and recompute raw memory coverage with the artifact's frozen
observer plus an independent sum/maxima check. Never launches Chromium or
changes the extracted evidence. Run with --help for explicit source bindings.
"""

import argparse
from collections import Counter
from datetime import datetime
import hashlib
import importlib
import io
import json
import math
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys
import zipfile

sys.dont_write_bytecode = True


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text())


def close(a, b):
    assert math.isclose(a, b, rel_tol=1e-13, abs_tol=1e-9), (a, b)


def json_sha(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode())


def schedule(order, pairs):
    result = []
    for pair, arms in ((1, order), (2, order[::-1])):
        result += [dict(kind='warmup', pair=pair, arm=arm, id=f'warmup-{pair}-{arm}') for arm in arms]
    control = 0
    for pair in range(1, pairs + 1):
        arms = order if pair % 2 else order[::-1]
        result += [dict(kind='candidate', pair=pair, arm=arm, id=f'pair-{pair:02}-{arm}') for arm in arms]
        if pair % 3 == 0:
            control += 1
            arms = 'AC' if order == 'AB' else 'CA'
            if control % 2 == 0:
                arms = arms[::-1]
            result += [dict(kind='control', pair=control, arm=arm, id=f'control-{control:02}-{arm}') for arm in arms]
    return result


def paired_statistics(observations, kind, other):
    selected = [row for row in observations if row['kind'] == kind]
    pairs = []
    for number in sorted({row['pair'] for row in selected}):
        rows = [row for row in selected if row['pair'] == number]
        assert len(rows) == 2 and {row['arm'] for row in rows} == {'A', other}
        arms = {row['arm']: row['totalImportMs'] for row in rows}
        pairs.append(dict(pair=number, order=''.join(row['arm'] for row in rows),
                          baselineMs=arms['A'], otherMs=arms[other], ratio=arms[other] / arms['A']))
    ratios = [row['ratio'] for row in pairs]
    rng = random.Random(897)
    bootstrap = sorted(statistics.median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
    total_a, total_b = (sum(row[key] for row in pairs) for key in ('baselineMs', 'otherMs'))
    values = dict(count=len(pairs), ratios=ratios,
                  medianPairedChangePercent=(statistics.median(ratios) - 1) * 100,
                  equalWorkChangePercent=(total_b / total_a - 1) * 100,
                  worstPairChangePercent=(max(ratios) - 1) * 100,
                  descriptiveBootstrap95Percent=[(bootstrap[index] - 1) * 100 for index in (249, 9749)],
                  fasterPairs=sum(value < 1 for value in ratios))
    return values, dict(pairs=pairs, baselineTotalMs=total_a, otherTotalMs=total_b,
                        baselineMedianMs=statistics.median(row['baselineMs'] for row in pairs),
                        otherMedianMs=statistics.median(row['otherMs'] for row in pairs))


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--cohort', required=True, type=Path)
parser.add_argument('--archive', required=True, type=Path)
parser.add_argument('--archive-sha256', required=True)
parser.add_argument('--artifact-id', required=True, type=int)
parser.add_argument('--run-id', required=True, type=int)
parser.add_argument('--repo', required=True, type=Path)
parser.add_argument('--dictionary', required=True)
parser.add_argument('--pairs', type=int, default=6)
parser.add_argument('--candidate', required=True)
parser.add_argument('--candidate-source-sha256', required=True)
parser.add_argument('--expected-package-entry', action='append', default=[])
parser.add_argument('--expected-added-package-entry', action='append', default=[])
parser.add_argument('--vndb-sah-allocation-units', type=int, nargs=2)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()
cell = args.cohort.resolve()
inputs = cell.with_name(cell.name + '-inputs')
archive = args.archive.resolve()
baseline = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
baseline_source_sha = '7325a63fa3d054a3c8b426c87880671ca57f5956dce842d9daef4acd4d617594'
record_entry = 'js/dictionary/term-record-opfs-store.js'
record_source = 'ext/' + record_entry
harness_path = 'test/chromium/extension-two-dictionary-import.e2e.js'
expected_changed = args.expected_package_entry or [record_entry]
expected_added = args.expected_added_package_entry
assert len(expected_changed) == len(set(expected_changed))
assert len(expected_added) == len(set(expected_added))
assert set(expected_added) <= set(expected_changed)
if args.dictionary == 'vndb':
    assert args.vndb_sah_allocation_units == [37, 37], 'Require the prospectively bound current-source storage policy'
else:
    assert args.vndb_sah_allocation_units is None

assert file_sha(archive) == args.archive_sha256
extracted_hashes = {}
with zipfile.ZipFile(archive) as zipped:
    names = [entry.filename for entry in zipped.infolist() if not entry.is_dir()]
    assert len(names) == len(set(names))
    extracted_names = {str(path.relative_to(cell.parent)) for root in (cell, inputs) for path in root.rglob('*') if path.is_file()}
    # The acquisition step omitted these reproducible large ZIP files from
    # the on-disk extraction. Audit their bytes and entries in-place below.
    omitted_packages = {cell.name + '/package-A.zip', cell.name + '/package-B.zip'}
    assert extracted_names <= set(names) and set(names) - extracted_names <= omitted_packages, (extracted_names - set(names), set(names) - extracted_names)
    for name in names:
        expected = sha(zipped.read(name))
        if name in extracted_names:
            assert file_sha(cell.parent / name) == expected, name
        extracted_hashes[name] = expected

plan = read(cell / 'registered-plan.json')
identities = read(cell / 'source-identities.json')
arms = identities['arms']
assert plan['baseline'] == baseline and plan['candidate'] == args.candidate
assert plan['dictionary'] == args.dictionary and plan['flags'] == {}
assert plan['initialOrder'] in ('AB', 'BA') and plan['pairs'] == args.pairs
assert args.pairs in (6, 12)
assert sorted(plan['expectedPackageEntries']) == sorted(expected_changed)
assert sorted(plan.get('expectedAddedPackageEntries', [])) == sorted(expected_added)
assert plan['vndbSahAllocationPolicy'] == (dict(unitBytes=4096, rangeUnits=[37, 37], origin='explicit') if args.dictionary == 'vndb' else None)
assert plan['sourceBoundary'] == 'Each revision built independently before timing; no product or harness overlays'
assert plan['failurePolicy'] == 'Stop on first failed observation; retain all completed and failed evidence'
assert (inputs / 'workflow-source.txt').read_text().strip() == args.candidate
assert arms['A']['sha'] == baseline and arms['B']['sha'] == args.candidate
entries_a, entries_b = (arms[arm]['entries'] for arm in 'AB')
assert not (entries_a.keys() - entries_b.keys()), 'Package removals are not allowed'
assert sorted(entries_b.keys() - entries_a.keys()) == sorted(expected_added)
changed = sorted(name for name in entries_a.keys() | entries_b.keys() if entries_a.get(name) != entries_b.get(name))
assert changed == identities['changedPackageEntries'] == sorted(expected_changed)
assert arms['A']['entries'][record_entry] == baseline_source_sha
assert arms['B']['entries'][record_entry] == args.candidate_source_sha256
assert arms['A']['lockSha256'] == arms['B']['lockSha256']
assert arms['A']['fixtureLockSha256'] == arms['B']['fixtureLockSha256'] == file_sha(inputs / 'dictionaries.lock.json')
fixture = read(inputs / 'dictionaries.lock.json')['dictionaries'][args.dictionary]
git_bindings = {}
for arm, identity in arms.items():
    def git_show(path):
        return subprocess.check_output(['git', 'show', identity['sha'] + ':' + path], cwd=args.repo,
                                       env={**os.environ, 'GIT_NO_LAZY_FETCH': '1'})
    assert sha(git_show(record_source)) == identity['entries'][record_entry]
    for entry in expected_changed:
        if entry not in identity['entries']:
            assert arm == 'A' and entry in expected_added
            continue
        source = 'dev/data/dictionary-wasm/' + entry.removeprefix('lib/') if entry.startswith('lib/') else 'ext/' + entry
        assert sha(git_show(source)) == identity['entries'][entry], (arm, source)
    tree = subprocess.check_output(['git', 'rev-parse', identity['sha'] + '^{tree}'], cwd=args.repo, text=True).strip()
    assert tree == identity['tree']
    verified_paths = []
    for path, expected in identity['sourceHashes'].items():
        if not path.startswith('builds/'):
            assert sha(git_show(path)) == expected, (arm, path)
            verified_paths.append(path)
    git_bindings[arm] = dict(sha=identity['sha'], tree=tree, productSourceSha256=identity['entries'][record_entry],
                             verifiedHarnessAndLockPaths=verified_paths, packageManifestEntries=len(identity['entries']))
browser = read(cell / 'browser-identity.json')
assert browser['version'] == '153.0.8010.12'
assert browser['sha256'] == '8c599d43aec53f2460a31ae2f4af6bd863f8258b34ff519564bc5d4726bfaa1e'
with zipfile.ZipFile(archive) as zipped:
    for arm, identity in arms.items():
        package_bytes = zipped.read(cell.name + f'/package-{arm}.zip')
        assert sha(package_bytes) == identity['packageSha256']
        with zipfile.ZipFile(io.BytesIO(package_bytes)) as package:
            entries = [info.filename for info in package.infolist() if not info.is_dir()]
            assert len(entries) == len(set(entries))
            assert set(entries) == identity['entries'].keys()
            assert {name: sha(package.read(name)) for name in entries} == identity['entries']

# Re-execute only frozen validation/audit functions, after binding their exact
# source bytes to the original ZIP. No runner/benchmark code is imported.
qualification = inputs / 'qualification'
sys.path.insert(0, str(qualification))
receipts = importlib.import_module('qualification_receipts')
memory_auditor = importlib.import_module('audit_memory')
protocol = importlib.import_module('protocol')
assert file_sha(qualification / 'audit_memory.py') == '871f29b9d87c42468714263a0eda05ee9edd2f76bff269ea9cb6d6d1fe51de7c'
assert file_sha(qualification / 'chromium_memory.py') == '8044bf3f4c48a868c7e076dc5f1bef9c2663f6323fe4a4fba5c121161cada4c7'

validated = []
common_reference = None
media_references = {}
phase_rows = []
term_counter_names = ('termRecordFieldEncodeMs', 'termRecordValidationMs', 'termRecordEncodeMs',
                      'termRecordWriteMs', 'dedupCanonicalScanMs', 'dedupRecentSourceCacheMs',
                      'contentCompressMs', 'contentMetadataMs', 'contentMetadataIndexPublishMs')
final_counter_names = ('termRecordEndImportSessionMs', 'termRecordEndImportSessionCloseWritableMs')


def validate(name, arm, media_check='sample', overlay=None):
    global common_reference
    location = cell / name
    summary, report = read(location / 'summary.json'), read(location / 'run-1.json')
    identity = arms[arm]
    source_hashes = dict(identity['sourceHashes'])
    if overlay is not None:
        source_hashes[harness_path] = sha(overlay.encode())
    receipt = receipts.validate_import_summary(summary, report, dictionary=args.dictionary, fixture=fixture,
                source_sha=identity['sha'], package_sha256=identity['packageSha256'],
                browser_version=browser['version'], import_flags=None, source_hashes=source_hashes,
                source_dirty=overlay is not None, media_check=media_check,
                vndb_sah_allocation_units=args.vndb_sah_allocation_units)
    assert receipt == read(location / 'canonical-receipt.json')
    if common_reference is None:
        common_reference = receipt['common']
    assert receipt['common'] == common_reference
    if media_check in media_references:
        assert receipt['media'] == media_references[media_check]
    else:
        media_references[media_check] = receipt['media']
    run = summary['runs'][0]
    phase = next(phase for phase in report['phases'] if phase.get('data') and phase['data'].get('kind') == 'dictionary-import')
    event = phase['data']['browserTiming']
    raw_duration = event['completedAtMs'] - event['startedAtMs']
    close(raw_duration, run['totalImportMs'])
    assert event['sequenceBefore'] == 0 and event['sequence'] == 1
    assert phase['data']['importDebug']['usesFallbackStorage'] is False
    assert phase['data']['importDebug']['openStorageDiagnostics']['mode'] == 'opfs-sahpool'
    worker = run['step4Breakdown']['dictionaries'][0]
    assert worker['parserWorkerCount'] == 3
    assert worker['parserGroupCount'] == {'jmdict': 12, 'jitendex': 22, 'vndb': 170}[args.dictionary]
    product_phases = run['importDebug']['importerPhaseTimings']
    term_phases = [phase for phase in product_phases if phase['phase'].startswith('term-file-fast-path:')]
    final_phases = [phase for phase in product_phases if phase['phase'] == 'bulk-finalization']
    assert len(term_phases) == len(final_phases) == 1
    counters = {'totalImportMs': raw_duration}
    for names, phase in ((term_counter_names, term_phases[0]), (final_counter_names, final_phases[0])):
        for key in names:
            value = phase['details'][key]
            assert type(value) in (int, float) and math.isfinite(value) and value >= 0
            counters[key] = value
    phase_rows.append(dict(name=name, arm=arm, instrumented=overlay is not None, counters=counters))
    # Independent explicit coverage checks supplement the frozen verifier.
    validation = report['benchmark']['validation']
    lookups = validation['lookup']['observations']
    assert len(lookups) == 72
    assert {(row['pass'], row['term']) for row in lookups} == {(i, term) for i in range(6) for term in validation['probeTerms']}
    assert all(row['results'] > 0 and row['hasExactHeadwordMatch'] is True for row in lookups)
    assert len(validation['probeTerms']) == len(set(validation['probeTerms'])) == 12
    for term in validation['probeTerms']:
        assert len({(row['results'], row['sha256']) for row in lookups if row['term'] == term}) == 1
    assert validation['restart']['contentReadable'] is True
    assert validation['restart']['termRows'] == fixture['termRows']
    files = validation['storage']['files']
    assert len({item['path'] for item in files}) == len(files)
    assert sum(item['bytes'] for item in files) == validation['storage']['bytes']
    assert validation['media']['files'] == (fixture['mediaFiles'] if media_check == 'all' else min(64, fixture['mediaFiles']))
    if media_check == 'all':
        assert validation['media']['bytes'] == fixture['mediaBytes']
    validated.append(dict(name=name, arm=arm, mediaCheck=media_check, instrumented=overlay is not None,
                          sourceSha=identity['sha'], packageSha256=identity['packageSha256'],
                          rawBrowserDurationMs=raw_duration, probeCount=12, lookupCount=72,
                          mediaFiles=validation['media']['files'], mediaBytes=validation['media']['bytes'],
                          storageBytes=validation['storage']['bytes'], parserWorkers=worker['parserWorkerCount'],
                          parserGroups=worker['parserGroupCount'], commonSemanticSha256=json_sha(receipt['common'])))
    return summary, report, raw_duration


expected = schedule(plan['initialOrder'], plan['pairs'])
assert plan['schedule'] == expected
saved_observations = read(cell / 'observations.json')
assert [{key: row[key] for key in ('kind', 'pair', 'arm', 'id')} for row in saved_observations] == expected
observations = []
previous_end = None
for item, saved in zip(expected, saved_observations):
    summary, report, duration = validate(item['id'], 'B' if item['arm'] == 'B' else 'A')
    close(duration, saved['totalImportMs'])
    before, after = (read(cell / item['id'] / filename) for filename in ('host-before.json', 'host-after.json'))
    start = datetime.fromisoformat(report['startedAtIso'])
    bracket_start, bracket_end = (datetime.fromisoformat(x['capturedAtIso']) for x in (before, after))
    assert bracket_start <= start <= bracket_end
    if previous_end is not None:
        assert previous_end <= bracket_start
    previous_end = bracket_end
    observations.append(dict(**item, totalImportMs=duration))
assert observations == saved_observations
candidate, candidate_extra = paired_statistics(observations, 'candidate', 'B')
control, control_extra = paired_statistics(observations, 'control', 'C')
phase_comparison = {}
for metric in ('totalImportMs', *term_counter_names, *final_counter_names):
    paired = []
    for number in range(1, args.pairs + 1):
        rows = {arm: next(row for row in phase_rows if row['name'] == f'pair-{number:02}-{arm}') for arm in ('A', 'B')}
        a, b = (rows[arm]['counters'][metric] for arm in ('A', 'B'))
        paired.append(dict(pair=number, A=a, B=b, deltaMs=b-a))
    phase_comparison[metric] = dict(Amedian=statistics.median(row['A'] for row in paired),
                                    Bmedian=statistics.median(row['B'] for row in paired),
                                    medianPairedDeltaMs=statistics.median(row['deltaMs'] for row in paired),
                                    A=[row['A'] for row in paired], B=[row['B'] for row in paired])
analysis = read(cell / 'analysis.json')
for key, actual in (('candidateVsBaseline', candidate), ('identicalCodeControl', control)):
    assert actual.keys() == analysis[key].keys()
    for field, value in actual.items():
        if isinstance(value, list):
            assert len(value) == len(analysis[key][field])
            for a, b in zip(value, analysis[key][field]):
                close(a, b)
        else:
            close(value, analysis[key][field])

for arm in plan['initialOrder']:
    validate('exhaustive-media-' + arm, arm, 'all')

memory_root = cell / 'memory'
memory_plan = read(memory_root / 'plan.json')
replication = 1 if plan['initialOrder'] == 'AB' else 2
assert memory_plan['replication'] == replication
assert memory_plan['authoritativeTiming'] is False
assert memory_plan['sourceHashes'] == arms
assert memory_plan['schedule'] == plan['memorySchedule'] == protocol.schedule(replication)
original = (memory_root / 'harness-original.js').read_text()
overlay = (memory_root / 'harness-instrumented.js').read_text()
assert protocol.memory_overlay(original) == overlay
assert sha(overlay.encode()) == memory_plan['overlaySha256']
assert all(identity['sourceHashes'][harness_path] == sha(original.encode()) for identity in arms.values())
memory_result = memory_auditor.audit_cell(memory_root)
assert memory_result == read(memory_root / 'memory-audit.json')
memory_observations = []
for item in memory_plan['schedule']:
    validate('memory/' + item['name'], item['arm'], overlay=overlay)
    raw = read(memory_root / item['name'] / 'memory.json')
    markers = [json.loads(line) for line in (memory_root / item['name'] / 'markers.jsonl').read_text().splitlines() if line]
    assert markers == raw['windowMarkers']
    start, end = (int(marker['monotonicNs']) for marker in markers)
    inside = [sample for sample in raw['samples'] if start <= sample['startedAtMonotonicNs'] <= sample['finishedAtMonotonicNs'] <= end]
    covered = [sample for sample in inside if sample['qualifiedForWholeTreePss']]
    assert len(inside) == raw['fullyContainedImportSampleCount']
    assert len(covered) == raw['stableFullyReadImportSampleCount'] >= 5
    assert raw['benchmarkExitCode'] == 0 and raw['qualificationFailures'] == []
    for sample in covered:
        assert sample['unreadableAddressSpaces'] == []
        assert {'browser', 'renderer'} <= {process['role'] for process in sample['processes']}
        for key in ('pssKiB', 'privateKiB'):
            assert all(type(process[key]) is int and process[key] >= 0 for process in sample['processes'])
    for metric, maximum in (('pssKiB', 'maxSampledPssKiB'), ('privateKiB', 'maxSampledPrivateKiB')):
        assert max(sum(process[metric] for process in sample['processes']) for sample in covered) == raw[maximum]
    midpoints = [start] + [(sample['startedAtMonotonicNs'] + sample['finishedAtMonotonicNs']) // 2 for sample in covered] + [end]
    maximum_gap = max((b - a) / 1e6 for a, b in zip(midpoints, midpoints[1:]))
    close(maximum_gap, raw['maximumCoveredSampleGapMs'])
    assert maximum_gap <= 250
    memory_observations.append({**item, **{key: raw[key] for key in (
        'allObservedSampleCount', 'fullyContainedImportSampleCount', 'stableFullyReadImportSampleCount',
        'maxSampledPssKiB', 'maxSampledPrivateKiB', 'maximumCoveredSampleGapMs',
        'preImportBracketGapMs', 'postImportBracketGapMs', 'qualifiedForWholeTreePss', 'qualificationFailures')},
        'rawScanFailureCounts': dict(Counter(reason for sample in raw['samples'] for reason in sample['qualificationFailures']))})
assert read(memory_root / 'semantic-failures.json') == []
comparison = read(memory_root / 'memory-comparison.json')
memory_metrics = {}
for metric in ('maxSampledPssKiB', 'maxSampledPrivateKiB'):
    changes = []
    for number in (1, 2):
        selected = {row['arm']: row for row in memory_observations if row['pair'] == number}
        changes.append(100 * (selected['B'][metric] / selected['A'][metric] - 1))
    memory_metrics[metric] = dict(medianPairedChangePercent=statistics.median(changes), maximumPairedChangePercent=max(changes))
assert memory_metrics == comparison['metrics'] == memory_result['metrics']
assert analysis['memoryPassed'] == memory_result['passesProspectiveMemoryScreen']
assert analysis['status'] == ('correctness-memory-passed' if memory_result['passesProspectiveMemoryScreen'] else 'memory-or-semantics-failed')

result = dict(
    schemaVersion=1, complete=True, artifactId=args.artifact_id, workflowRunId=args.run_id,
    archiveSha256=args.archive_sha256, archiveBytes=archive.stat().st_size, artifactFileCount=len(extracted_hashes),
    extractionFileCount=len(extracted_names), embeddedPackageBytesAndAllEntriesVerified=True,
    sourceBindings=git_bindings, fixture=fixture, browserIdentity=browser,
    changedPackageEntries=changed, addedPackageEntries=expected_added,
    vndbSahAllocationPolicy=plan['vndbSahAllocationPolicy'], registeredOrder=plan['initialOrder'],
    observationsByKind=dict(Counter(row['kind'] for row in observations)),
    timing=dict(candidateVsBaseline=candidate, candidateDetail=candidate_extra,
                identicalCodeControl=control, controlDetail=control_extra,
                scope=f'Uninstrumented browser file-input change to post-UI completion, {args.pairs} paired observations on one host; warmups, exhaustive-media and memory runs excluded.',
                interpretation='Descriptive results for the exact bound product source only; no formal equivalence conclusion, no removal of outliers, and no extension to a later candidate.'),
    ordinaryImportPhaseCounters=dict(scope='Existing production counters from the same uninstrumented raw reports; counter durations can overlap and cannot be added or subtracted as a whole-import attribution.',
                                      comparisons=phase_comparison,
                                      observations=[row for row in phase_rows if row['name'].startswith('pair-')]),
    semantics=dict(validatedObservationCount=len(validated), allCommonReceiptsEqual=True,
                   allRawReportsMatchSummaries=True, outputDigestSha256=common_reference['validation']['outputDigestSha256'],
                   commonSemanticSha256=json_sha(common_reference), storage=common_reference['validation']['storage'],
                   media=media_references, observations=validated,
                   scope='Complete fixed validation coverage: 12 probe terms, 72 cold/warm lookup observations and restart per run; sampled media per timed run plus separate exhaustive media in both arms. This is not exhaustive term-content byte verification.'),
    memory=dict(**memory_result, independentMaximaAndGapRecomputation=True, observationDetails=memory_observations,
                scope='Separate external observer; only stable fully-read scans entirely inside import markers contribute to sampled PSS/private maxima. Instrumented timings excluded.'),
    extractedInputSha256=extracted_hashes, auditScriptSha256=file_sha(Path(__file__)),
    limitations=['Only one host and one initial-order cohort is audited here; no pooled or opposite-order claim.',
                 'The remote browser executable is not included in this artifact; its identity is bound through the recorded binary hash and matching runtime versions. Both embedded extension ZIPs, every package entry, source blobs and harness hashes are independently verified.',
                 'Memory is non-atomic sampled PSS/private usage, not an exact peak; all raw outside-window and failed scans remain in the original archive.',
                 'Artifact/run IDs are caller-supplied acquisition metadata; ZIP SHA-256, exact extraction and embedded source/workflow identities are independently verified.'])
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
print(json.dumps(dict(output=str(args.output), archiveSha256=args.archive_sha256,
                      candidate=candidate, control=control, semantics=result['semantics']['validatedObservationCount'],
                      memory=memory_result), indent=2))
