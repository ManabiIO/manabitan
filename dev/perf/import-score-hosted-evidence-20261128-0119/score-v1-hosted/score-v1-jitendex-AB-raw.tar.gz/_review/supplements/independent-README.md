# Independent Jitendex V1 hosted audit

The six paired browser observations do not show a latency gain: paired median
**+0.2512%**, equal-work **−0.00945%**, with the candidate faster in 2/6 pairs.
The descriptive bootstrap interval is −1.9514% to +1.7137%. The two identical
baseline-code controls have median −0.5606% and equal-work −0.5734%. All raw
observations are retained. These are one host's results for V1, not the later
V3 prefix selection candidate, and do not constitute a formal equivalence test.

`audit-jitendex-v1.py` independently rebuilds these statistics from the
raw browser `completedAtMs − startedAtMs` events and checks the recorded
schedule and summaries. It verifies SHA-256 for the entire original artifact,
all 214 extracted files and both embedded extension ZIPs directly within the
artifact. Both packages contain 554 entries; exactly the record-store module
differs. All recorded source/harness/lock hashes and source trees are also
checked against the exact Git commits. The remote Chromium binary is bound by
its recorded hash and matching runtime version; its bytes are not included.

| Identity | Value |
| --- | --- |
| Workflow run | 46102526376 |
| Artifact | 15245794690 |
| Artifact bytes | 35,017,778 |
| Artifact SHA-256 | `9bffe84d5487c29b37bee5a977ae17b0c42576a088e5eb45709e92ad6caf2d16` |
| Baseline | `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` |
| Candidate/workflow | `1c0239a54df4c8b30124e6cabe644e833c9af64a` |
| Candidate record module | `9222c10f4ae48d802aedd05057df9c651f0466a1065b52a5ab502aaf5e334dd5` |
| Browser | Chromium 153.0.8010.12 |
| Runtime/host | Node 22.22.0; AMD EPYC 7763; four available CPUs |
| Parser policy | Three workers, 22 Jitendex groups, production defaults |

All 26 run reports validate: four warmups, twelve candidate measurements,
four identical-code control measurements, two separate exhaustive-media runs
and four separate memory runs. Each contains all 12 probe terms, 72 cold/warm
lookup observations, successful restart/readback and exactly matching logical
storage sizes after normalizing only validated random SAH filenames. The
output probe digest is
`754fc8c99cea76757778abe6b30f16a293c91bba3d45a68dcb9e3e9bac3ca215`.
Storage totals 67,466,332 bytes. Timed/sample receipts cover 64 media files /
1,302,012 bytes; both exhaustive runs verify all 236 files / 4,992,155 bytes
with digest
`74aeb87663f4b89600affca40005fab432058227cd3fcb31c9f74d19a72a0402`.
This is complete coverage of the fixed validation protocol, not an exhaustive
comparison of every imported term's content bytes.

The separate ABBA memory audit re-executes the frozen raw-scan auditor and
independently recomputes process sums, wholly contained import-window maxima
and covered-scan gaps. All four observations qualify: 276 retained raw scans,
46 stable complete scans wholly inside the import windows. Maximum covered
gap is 213.899256 ms. Median paired PSS changes +0.01789%, worst +0.07968%;
median private memory changes −0.32773%, worst +0.12074%. Both pre-registered
memory limits pass. These are sampled, non-atomic PSS/private maxima; external
sampling makes these runs' timing non-authoritative, and their timing is
excluded from the latency result.

Reproduce from the repository root:

```sh
python3 builds/research-0119/score-v1-hosted/audit-jitendex-v1.py \
  --cohort builds/research-0119/score-v1-hosted/jitendex-AB/import-score-cache-jitendex-AB \
  --archive /tmp/manabitan-artifacts-0119/score-v1-jitendex-AB.zip \
  --archive-sha256 9bffe84d5487c29b37bee5a977ae17b0c42576a088e5eb45709e92ad6caf2d16 \
  --artifact-id 15245794690 --run-id 46102526376 --repo . \
  --dictionary jitendex --candidate 1c0239a54df4c8b30124e6cabe644e833c9af64a \
  --candidate-source-sha256 9222c10f4ae48d802aedd05057df9c651f0466a1065b52a5ab502aaf5e334dd5 \
  --output builds/research-0119/score-v1-hosted/jitendex-AB-independent-audit.json
```

The result binds the audit script itself and every artifact input by SHA-256.
It imports only the artifact's byte-verified receipt/memory validation helpers;
it never executes the benchmark runner or launches a browser. Artifact and
workflow IDs are the acquisition metadata supplied by the parent task; the
archive, extracted bytes and embedded workflow/source identities are verified
locally.
