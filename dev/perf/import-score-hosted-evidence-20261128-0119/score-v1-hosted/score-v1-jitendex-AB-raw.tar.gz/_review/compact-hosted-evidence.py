#!/usr/bin/env python3
"""Retain all raw hosted evidence, excluding only independently verified release ZIPs.

No input is deleted. Both embedded packages are fully revalidated before writing.
The output is deliberately a raw-evidence subset, not a copy of the original ZIP.
"""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
import zipfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def encode(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def safe_name(name):
    value = PurePosixPath(name)
    assert not value.is_absolute() and '..' not in value.parts and str(value) == name
    return name


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--artifact', required=True, type=Path)
parser.add_argument('--audit', required=True, type=Path)
parser.add_argument('--audit-script', required=True, type=Path)
parser.add_argument('--acquisition-receipt', type=Path)
parser.add_argument('--supplement', action='append', default=[], help='Unique short name=path; stored under _review/supplements/')
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--receipt', required=True, type=Path)
args = parser.parse_args()
assert not args.output.exists() and not args.receipt.exists(), 'Do not overwrite retained evidence'
audit_bytes = args.audit.read_bytes()
audit = json.loads(audit_bytes)
assert audit['complete'] is True and audit['embeddedPackageBytesAndAllEntriesVerified'] is True
assert args.artifact.stat().st_size == audit['archiveBytes']
assert file_sha(args.artifact) == audit['archiveSha256']
assert file_sha(args.audit_script) == audit['auditScriptSha256']
supplements = {
    '_review/independent-audit.json': audit_bytes,
    '_review/independent-auditor.py': args.audit_script.read_bytes(),
    '_review/compact-hosted-evidence.py': Path(__file__).read_bytes(),
}
if args.acquisition_receipt:
    raw = args.acquisition_receipt.read_bytes()
    acquisition = json.loads(raw)
    assert acquisition['archiveSha256'] == audit['archiveSha256']
    if 'archiveBytes' in acquisition:
        assert acquisition['archiveBytes'] == audit['archiveBytes']
    assert acquisition['artifactId'] == audit['artifactId']
    assert acquisition['runId'] == audit['workflowRunId']
    supplements['_review/artifact-acquisition-receipt.json'] = raw
for specification in args.supplement:
    name, path = specification.split('=', 1)
    name = safe_name('_review/supplements/' + name)
    assert name not in supplements
    supplements[name] = Path(path).read_bytes()

with zipfile.ZipFile(args.artifact) as artifact:
    entries = [entry for entry in artifact.infolist() if not entry.is_dir()]
    names = [safe_name(entry.filename) for entry in entries]
    assert len(names) == len(set(names)) == audit['artifactFileCount']
    assert set(names) == set(audit['extractedInputSha256'])
    assert not any(name.startswith('_review/') for name in names)
    source_names = [name for name in names if name.endswith('/source-identities.json')]
    assert len(source_names) == 1
    cohort = str(PurePosixPath(source_names[0]).parent)
    identities = json.loads(artifact.read(source_names[0]))
    omitted = {f'{cohort}/package-{arm}.zip' for arm in 'AB'}
    assert omitted <= set(names)
    member_inventory = []
    package_inventory = {}
    for entry in entries:
        raw = artifact.read(entry.filename)
        digest = sha(raw)
        assert digest == audit['extractedInputSha256'][entry.filename]
        member_inventory.append({'path': entry.filename, 'bytes': len(raw), 'sha256': digest,
                                 'retained': entry.filename not in omitted})
        if entry.filename in omitted:
            arm = entry.filename[-5]
            identity = identities['arms'][arm]
            assert digest == identity['packageSha256']
            assert identity['sha'] == audit['sourceBindings'][arm]['sha']
            assert identity['tree'] == audit['sourceBindings'][arm]['tree']
            with zipfile.ZipFile(io.BytesIO(raw)) as package:
                package_entries = [item for item in package.infolist() if not item.is_dir()]
                package_names = [item.filename for item in package_entries]
                assert len(package_names) == len(set(package_names))
                assert set(package_names) == set(identity['entries'])
                rows = []
                for item in package_entries:
                    content = package.read(item.filename)
                    content_sha = sha(content)
                    assert content_sha == identity['entries'][item.filename]
                    rows.append({'path': item.filename, 'bytes': len(content), 'sha256': content_sha,
                                 'zipCRC32': item.CRC, 'zipCompressionMethod': item.compress_type,
                                 'zipCompressedBytes': item.compress_size, 'zipDateTime': item.date_time})
                package_inventory[arm] = {'path': entry.filename, 'bytes': len(raw), 'sha256': digest,
                                          'sourceSha': identity['sha'], 'sourceTree': identity['tree'],
                                          'allEntryBytesVerifiedBeforeOmission': True, 'entries': rows}
    assert set(package_inventory) == set('AB')
    manifest = {
        'schemaVersion': 1, 'scope': 'All original raw artifact files except two fully verified release package ZIP payloads; no observations excluded.',
        'originalArtifact': {key: audit[key] for key in ('artifactId', 'workflowRunId', 'archiveSha256', 'archiveBytes', 'artifactFileCount')},
        'originalMembers': member_inventory, 'omittedPackageInventories': package_inventory,
        'independentAuditSha256': sha(audit_bytes), 'independentAuditorSha256': audit['auditScriptSha256'],
        'compactorSha256': sha(Path(__file__).read_bytes()),
        'supplements': {name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(supplements.items())},
        'limits': [
            'This compact archive is not byte-identical to the original GitHub artifact and does not retain release package payloads.',
            'Package verification here is a retained receipt of actual ZIP and entry-byte checks performed before omission. A future independent package-byte check requires reacquiring the original artifact or an independently reproduced package.',
            'Rebuilding source does not by itself reproduce original ZIP timestamps, metadata or container SHA-256. Source/package inventories bind those original identities without claiming such reconstruction.',
            'Raw timing, semantic, restart, lookup, media, host, memory and input evidence remains byte-for-byte complete; all warmups, controls, failed scans and outliers are retained.',
        ],
    }
    supplements['_review/compact-manifest.json'] = encode(manifest)
    expected = {row['path']: {'bytes': row['bytes'], 'sha256': row['sha256']} for row in member_inventory if row['retained']}
    expected.update({name: {'bytes': len(raw), 'sha256': sha(raw)} for name, raw in supplements.items()})
    with args.output.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.PAX_FORMAT) as tar:
                for name in sorted(expected):
                    raw = supplements[name] if name in supplements else artifact.read(name)
                    info = tarfile.TarInfo(name)
                    info.size = len(raw)
                    info.mode = 0o644
                    info.mtime = 0
                    tar.addfile(info, io.BytesIO(raw))

verified = {}
with tarfile.open(args.output, 'r:gz') as tar:
    for item in tar:
        assert item.isfile() and item.name not in verified
        raw = tar.extractfile(item).read()
        verified[item.name] = {'bytes': len(raw), 'sha256': sha(raw)}
assert verified == expected, 'Written compact archive does not reproduce all retained bytes'
result = {
    'schemaVersion': 1, 'complete': True,
    'originalArtifact': manifest['originalArtifact'],
    'compactArchive': {'bytes': args.output.stat().st_size, 'sha256': file_sha(args.output),
                       'memberCount': len(expected), 'uncompressedBytes': sum(row['bytes'] for row in expected.values())},
    'retainedOriginalFileCount': len(names) - 2, 'omittedFileCount': 2,
    'omittedPackageBytes': sum(row['bytes'] for row in package_inventory.values()),
    'allOriginalNonPackageBytesVerifiedInOutput': True,
    'allOmittedPackageEntriesVerifiedBeforeWriting': True,
    'independentAuditSha256': sha(audit_bytes), 'independentAuditorSha256': audit['auditScriptSha256'],
    'compactorSha256': manifest['compactorSha256'], 'limits': manifest['limits'],
}
args.receipt.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
