#!/usr/bin/env python3
"""Audit the retained V1 validation artifact without rerunning its checks."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

root = Path(__file__).resolve().parent
base = root / 'score-v1-hosted'
cell = base / 'score-v1-validation'
archive = base / 'score-v1-validation.zip'
expected_sha = '72edb896f850af6da9ecf2606183009afc4c67f924a2d720d8195d99777812b5'
candidate = '1c0239a54df4c8b30124e6cabe644e833c9af64a'
repo = root.parent.parent
sha = lambda value: hashlib.sha256(value).hexdigest()
receipt = json.loads((cell / 'artifact-receipt.json').read_text())
assert receipt['artifactId'] == 15247501691 and receipt['runId'] == 46102526376
assert receipt['candidate'] == candidate and receipt['archiveSha256'] == expected_sha
assert receipt['archiveBytes'] == archive.stat().st_size == 478297
assert sha(archive.read_bytes()) == expected_sha
members = {}
with zipfile.ZipFile(archive) as zipped:
    assert len(zipped.namelist()) == len(set(zipped.namelist())) == 6
    assert set(zipped.namelist()) == {row['path'] for row in receipt['members']}
    for item in receipt['members']:
        value = (cell / item['path']).read_bytes()
        assert value == zipped.read(item['path'])
        assert len(value) == item['bytes'] and sha(value) == item['sha256']
        members[item['path']] = {'bytes': len(value), 'sha256': sha(value)}
workflow = base / 'score-v1-jmdict-BA/import-score-cache-jmdict-BA-inputs/workflow.yml'
workflow_bytes = subprocess.check_output(['git', 'show', candidate + ':.github/workflows/import-score-cache-0119.yml'], cwd=repo)
assert workflow_bytes == workflow.read_bytes()
assert 'defaults:\n  run:\n    shell: bash\n' in workflow.read_text()
unit = json.loads((cell / 'unit.json').read_text())
assert unit['success'] is True and unit['numFailedTests'] == 0 and unit['numFailedTestSuites'] == 0
assert len(unit['testResults']) == 669
assert all(item['status'] == 'passed' for item in unit['testResults'])
assertions = [test for item in unit['testResults'] for test in item['assertionResults']]
counts = Counter(test['status'] for test in assertions)
assert counts == {'passed': 15137, 'skipped': 47}
assert len(assertions) == unit['numTotalTests'] == 15184
assert unit['numPassedTests'] == 15137 and unit['numPendingTests'] == 47
assert all(not test.get('failureMessages') for test in assertions)
direct = next(item for item in unit['testResults'] if item['name'].endswith('/term-record-direct-field-columns.test.js'))
assert len(direct['assertionResults']) == 17
for title in ('preserves first-use score IDs after repeated signed-score cache collisions',
              'uses current scores after colliding slots and columns change between calls'):
    matches = [test for test in direct['assertionResults'] if test['title'] == title]
    assert len(matches) == 1 and matches[0]['status'] == 'passed'
logs = {path.name: path.read_text() for path in cell.glob('*.log')}
assert re.search(r'Ran 32 tests in [0-9.]+s\s+OK\s*$', logs['qualification.log'])
targets = ['chrome', 'chrome-dev', 'chrome-playwright', 'firefox', 'firefox-dev', 'firefox-android', 'edge']
assert all(f'Building {target}...' in logs['build.log'] for target in targets)
assert logs['build.log'].rstrip().endswith('Restoring manifest...')
for name, command in (('types-main.log', '> npx tsc --noEmit --project jsconfig.json'),
                      ('types-test.log', '> npx tsc --noEmit --project test/jsconfig.typecheck.json')):
    assert logs[name].rstrip().endswith(command)
    assert not re.search(r'error TS\d+', logs[name])
assert '> npx eslint . --ignore-pattern' in logs['lint.log']
assert '[WARNING]' in logs['lint.log'] and 'commonjs-variable-in-esm' in logs['lint.log']
assert 'problems (' not in logs['lint.log'] and 'Oops! Something went wrong!' not in logs['lint.log']
result = {
    'schemaVersion': 1, 'complete': True,
    'scope': 'Archived validation of V1 candidate only; no claim that these hosted results cover V3.',
    'candidate': candidate, 'productSourceSha256': '9222c10f4ae48d802aedd05057df9c651f0466a1065b52a5ab502aaf5e334dd5',
    'artifactId': receipt['artifactId'], 'runId': receipt['runId'],
    'archiveSha256': expected_sha, 'archiveBytes': archive.stat().st_size,
    'workflowSha256': sha(workflow_bytes), 'members': members,
    'unit': {'success': True, 'passedFiles': 669, 'passedTests': 15137, 'skippedTests': 47, 'failedTests': 0,
             'vitestNestedSuiteCount': unit['numTotalTestSuites'],
             'suiteCountNote': 'Vitest numTotalTestSuites includes nested describe suites; file count is testResults.length.',
             'directFieldRegressionFileCases': 17, 'bothV1CacheRegressionsPassed': True},
    'qualificationObserverAndReceiptRegressions': {'passed': 32, 'logFooter': 'OK'},
    'build': {'targets': targets, 'finalLogLine': 'Restoring manifest...'},
    'lint': {'noEslintErrorsReported': True,
             'retainedWarning': 'Bundler commonjs-variable-in-esm warning in existing ext/js/dictionary/mdx/vendor/pako-inflate.js.'},
    'types': {'mainCommandReachedLogEndWithoutDiagnostics': True, 'testCommandReachedLogEndWithoutDiagnostics': True},
    'parentReportedWorkflowJobConclusion': 'success',
    'qualification': 'Unit JSON and Python footer explicitly report success. Other archived logs are consistent with successful completion; command exit statuses are established by the separately acquired workflow job conclusion, not by empty TypeScript diagnostics alone.',
    'auditScriptSha256': sha(Path(__file__).read_bytes()),
}
output = base / 'validation-independent-audit.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
