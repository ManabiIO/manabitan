#!/usr/bin/env python3
"""Index already audited score cohorts without combining their timings."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def file_sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def describe(path):
    return {'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size, 'sha256': file_sha(path)}


CASES = [
    ('v1', 'jmdict', 'AB', 'jmdict-AB-independent-audit.json'),
    ('v1', 'jmdict', 'BA', 'jmdict-BA-independent-audit.json'),
    ('v1', 'jitendex', 'AB', 'jitendex-AB-independent-audit.json'),
    ('v1', 'vndb', 'AB', 'vndb-AB-independent-failure-audit.json'),
    ('v3', 'jmdict', 'AB', 'jmdict-AB-independent-audit.json'),
    ('v3', 'jmdict', 'BA', 'jmdict-BA-independent-audit.json'),
    ('v3', 'jitendex', 'AB', 'jitendex-AB-general-audit-v2.json'),
    ('v3', 'vndb', 'AB', 'vndb-AB-independent-audit.json'),
]
SCRIPTS = [
    'audit-score-hosted.py', 'score-v1-hosted/audit-jitendex-v1.py',
    'audit-import-hosted-0119-v1.py.txt', 'audit-import-hosted-0119-3a338e76.py.txt',
    'audit-import-hosted-0119-gap-failure.py', 'audit-score-v1-validation.py',
    'audit-score-v3-validation.py', 'compact-hosted-evidence.py',
    'audit-score-api-receipts.py', 'index-score-hosted-evidence.py',
]
scripts = [describe(ROOT / name) for name in SCRIPTS]
script_digests = {row['sha256'] for row in scripts}
api_path = ROOT / 'score-api-receipts-audit.json'
api_audit = json.loads(api_path.read_text())
assert api_audit['complete'] and len(api_audit['cohorts']) == 8
assert api_audit['auditScript']['sha256'] in script_digests
cohorts = []
for version, dictionary, order, audit_name in CASES:
    folder = ROOT / f'score-{version}-hosted'
    audit_path = folder / audit_name
    audit = json.loads(audit_path.read_text())
    assert audit['complete'] and audit['embeddedPackageBytesAndAllEntriesVerified']
    assert audit['auditScriptSha256'] in script_digests
    assert audit['registeredOrder'] == order
    api = next(row for row in api_audit['cohorts'] if (row['variant'], row['dictionary'], row['order']) == (version, dictionary, order))
    assert api['independentAudit']['sha256'] == file_sha(audit_path)
    stem = f'score-{version}-{dictionary}-{order}'
    archive = folder / f'{stem}-raw.tar.gz'
    receipt_path = folder / f'{stem}-raw-receipt.json'
    receipt = json.loads(receipt_path.read_text())
    if 'compactArchive' in receipt:
        assert file_sha(archive) == receipt['compactArchive']['sha256']
        assert archive.stat().st_size == receipt['compactArchive']['bytes']
        assert receipt['originalArtifact']['archiveSha256'] == audit['archiveSha256']
        assert receipt['allOriginalNonPackageBytesVerifiedInOutput']
        assert receipt['allOmittedPackageEntriesVerifiedBeforeWriting']
        retained = receipt['retainedOriginalFileCount']
        preservation = None
    else:
        assert version == 'v1' and dictionary == 'jmdict' and order == 'BA'
        assert file_sha(archive) == receipt['archiveSha256']
        assert archive.stat().st_size == receipt['archiveBytes']
        preservation_path = folder / f'{stem}-raw-preservation-audit.json'
        preserved = json.loads(preservation_path.read_text())
        assert preserved['allOriginalNonPackageMembersVerified']
        assert preserved['originalArchiveSha256'] == audit['archiveSha256']
        assert preserved['compactArchiveSha256'] == file_sha(archive)
        retained = preserved['retainedOriginalMembers']
        preservation = describe(preservation_path)
    assert retained == audit['artifactFileCount'] - 2
    memory = audit['memory']
    cohorts.append({
        'variant': version, 'dictionary': dictionary, 'order': order,
        'independentAudit': describe(audit_path), 'independentAuditorSha256': audit['auditScriptSha256'],
        'compactArchive': describe(archive), 'compactReceipt': describe(receipt_path),
        'legacyPreservationAudit': preservation,
        'originalArtifact': {key: audit[key] for key in ('artifactId', 'workflowRunId', 'archiveSha256', 'archiveBytes', 'artifactFileCount')},
        'sourceBindings': audit['sourceBindings'], 'fixture': audit['fixture'],
        'apiJobConclusion': {'jobId': api['jobId'], 'conclusion': api['jobConclusion'],
                             'artifactDigest': api['artifact']['digest']},
        'retainedOriginalFiles': retained, 'omittedFiles': 2,
        'allSourcePackageAndSemanticChecksPassed': True,
        'semanticObservations': audit['semantics']['validatedObservationCount'],
        'semanticOutputDigestSha256': audit['semantics']['outputDigestSha256'],
        'postRestartStorageBytes': audit['semantics']['storage']['bytes'],
        'candidateVsBaseline': audit['timing']['candidateVsBaseline'],
        'identicalCodeControl': audit['timing']['identicalCodeControl'],
        'phaseCounterComparisons': audit.get('ordinaryImportPhaseCounters', {}).get('comparisons'),
        'memory': {key: memory[key] for key in ('rawScanCount', 'everyObservationQualified', 'passesProspectiveMemoryScreen', 'metrics')},
        'memoryFailureObservations': [row for row in memory['observationDetails'] if not row['qualifiedForWholeTreePss']],
    })

validation = []
for version in ('v1', 'v3'):
    path = ROOT / f'score-{version}-hosted/validation-independent-audit.json'
    value = json.loads(path.read_text())
    assert value['complete'] and value['auditScriptSha256'] in script_digests
    api = next(row for row in api_audit['validation'] if row['variant'] == version)
    assert api['sourceAudit']['sha256'] == file_sha(path)
    validation.append({'variant': version, 'audit': describe(path),
                       'verifiedApiJobConclusion': {'jobId': api['jobId'], 'conclusion': api['jobConclusion'],
                                                    'steps': api['verifiedStepConclusions']},
                       **{key: value[key] for key in ('candidate', 'productSourceSha256', 'artifactId', 'runId', 'archiveSha256', 'archiveBytes', 'unit', 'qualificationObserverAndReceiptRegressions', 'parentReportedWorkflowJobConclusion', 'qualification')}})

route_path = ROOT / 'score-evidence/raw/vndb-record-stream-screen-prefix-node24.json'
route = json.loads(route_path.read_text())
assert route['complete'] and route['summary']['rows'] == 6648310 and route['summary']['groups'] == 170
assert route['summary']['prefixCacheEligibleGroups'] == route['summary']['prefixCacheEligibleRows'] == 0
assert route['summary']['inlineScoreCoverage'] == 1
assert all(not group['prefixCacheEligible'] for group in route['fieldGroups'])
vndb_v3 = next(row for row in cohorts if row['variant'] == 'v3' and row['dictionary'] == 'vndb')
assert route['candidateRecordSourceSha256'] == vndb_v3['sourceBindings']['B']['productSourceSha256']
assert route['fixture']['sha256'] == vndb_v3['fixture']['sha256']

result = {
    'schemaVersion': 1,
    'scope': 'Index of independent per-source/per-host hosted audits and compact raw evidence; no pooled timing estimate.',
    'decision': 'No score-cache PR supported by the completed experiment. V3 JMdict complete-import observations did not establish a gain despite lower field-encoding counters. Favorable single-cohort VNDB estimates remain descriptive and are not attributed to an inactive score helper.',
    'pending': [],
    'baseline': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2',
    'cohorts': cohorts, 'validation': validation, 'scripts': scripts,
    'apiConclusionAndArtifactBindingAudit': describe(api_path),
    'apiReceipts': api_audit['apiReceipts'],
    'v1VndbFailureLog': api_audit['v1VndbFailureLog'],
    'v3VndbRouteEvidence': {'receipt': describe(route_path), 'node': route['node'],
                           'rows': route['summary']['rows'], 'groups': route['summary']['groups'],
                           'prefixCacheEligibleGroups': 0, 'prefixCacheEligibleRows': 0,
                           'inlineScoreCoverage': 1,
                           'scope': 'Local full production-parser corpus and source-bound eligibility evidence, with deterministic synthetic resolved offsets; not browser execution coverage or complete-import timing. The score helper is ineligible for every group, so the favorable hosted point estimate is not attributed to cache hits.'},
    'compactArchiveTotalBytes': sum(row['compactArchive']['bytes'] for row in cohorts),
    'retentionPolicy': [
        'Retain every original non-package member: raw reports and summaries, all observations, controls, warmups, media checks, host states, inputs, source/package inventories, and all raw memory scans.',
        'Omit only package-A.zip and package-B.zip after actual ZIP hashes and every entry byte have been verified. Preserve full entry inventories, original artifact hashes, exact auditors and receipt of that verification.',
        'The compact archives permit raw-data reanalysis but do not constitute an independently repeatable package-byte check without reacquiring the original artifact. ZIP container metadata is not claimed reproducible from source.',
        'Memory observations remain separate from timing. Unqualified observations retain null reported maxima and null cohort comparisons; no threshold relaxation, outlier removal or retry.',
        'Retain original full validation artifacts or all six original validation payloads plus their hashes. Empty diagnostic logs are not standalone proof of command exit success; preserve API job conclusions separately.',
    ],
}
output = ROOT / 'score-hosted-evidence-index.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output': str(output), 'cohorts': len(cohorts), 'compactArchiveTotalBytes': result['compactArchiveTotalBytes'], 'pending': result['pending']}))
