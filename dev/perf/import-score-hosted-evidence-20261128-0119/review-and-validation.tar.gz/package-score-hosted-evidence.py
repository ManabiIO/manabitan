#!/usr/bin/env python3
"""Preserve completed hosted score experiments without discarded observations."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent
DEST = ROOT.parents[1] / 'dev/perf/import-score-hosted-evidence-20261128-0119'
DEST.mkdir(parents=True, exist_ok=True)
index = json.loads((ROOT / 'score-hosted-evidence-index.json').read_text())
assert len(index['cohorts']) == 8 and not index['pending']
files = set()
for c in index['cohorts']:
    for key in ('compactReceipt', 'legacyPreservationAudit', 'independentAudit'):
        if c.get(key): files.add(c[key]['path'])
    info = c['compactArchive']
    source = ROOT / info['path']
    assert source.stat().st_size == info['bytes']
    assert hashlib.sha256(source.read_bytes()).hexdigest() == info['sha256']
    target = DEST / info['path']
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, target)

files.update([
    'score-hosted-evidence-index.json', 'score-hosted-evidence-README.md',
    'score-api-receipts-audit.json', 'audit-score-api-receipts.py',
    'index-score-hosted-evidence.py', 'compact-hosted-evidence.py',
    'audit-score-hosted.py', 'audit-import-hosted-0119-v1.py.txt',
    'audit-import-hosted-0119-3a338e76.py.txt',
    'audit-import-hosted-0119-gap-failure.py',
    'audit-score-v1-validation.py', 'audit-score-v3-validation.py',
    'score-v1-hosted/audit-jitendex-v1.py',
    'score-v1-hosted/validation-independent-audit.json',
    'score-v3-hosted/validation-independent-audit.json',
    'score-v3-hosted/jitendex-AB-general-audit.json',
    'score-v3-hosted/jitendex-AB-general-audit-v2.json',
    'package-score-hosted-evidence.py',
])
for version in ('v1', 'v3'):
    folder = ROOT / f'score-{version}-hosted/score-{version}-validation'
    for path in folder.rglob('*'):
        if path.is_file(): files.add(str(path.relative_to(ROOT)))
for path in (ROOT / 'api-receipts').glob('*.json'):
    if any(k in path.name for k in ('runJobs46102526376', 'runJobs46103360828', 'scoreV3ArtifactsLatest', 'artifacts46102526376', 'scoreV1VndbJobLogs')):
        files.add(str(path.relative_to(ROOT)))

manifest = []
tar_path = DEST / 'review-and-validation.tar.gz'
with tar_path.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w|') as tar:
            for relative in sorted(files):
                data = (ROOT / relative).read_bytes()
                item = tarfile.TarInfo(relative)
                item.size = len(data)
                item.mode = 0o644
                item.mtime = 0
                tar.addfile(item, io.BytesIO(data))
                manifest.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with tarfile.open(tar_path, 'r:gz') as tar:
    actual = {m.name: hashlib.sha256(tar.extractfile(m).read()).hexdigest() for m in tar.getmembers() if m.isfile()}
assert actual == {x['path']: x['sha256'] for x in manifest}

readme = (ROOT / 'score-hosted-evidence-README.md').read_text()
readme += '\n## Retained repository layout\n\nThe two `score-v*-hosted/` directories contain the eight immutable raw-subset archives. `review-and-validation.tar.gz` retains the complete source-validation payloads, independent audits, exact auditor versions, final GitHub API receipts and evidence index. Its internal paths match the research index. The adjacent manifest binds every compressed archive and every review member. Extract the review archive into a fresh directory to inspect its index and receipts; unpack each raw-subset archive separately to avoid collisions between its original runner paths. Reacquire the original Actions artifact for a full package-byte re-audit, as explained above.\n'
(DEST / 'README.md').write_text(readme)
subprocess.run([str(ROOT.parents[1] / 'node_modules/.bin/prettier'), '--write', str(DEST / 'README.md')], check=True, capture_output=True)
outputs = []
for path in sorted(DEST.rglob('*')):
    if path.is_file() and path.name != 'files.sha256.json.txt':
        data = path.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        outputs.append({'path': str(path.relative_to(DEST)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'gitBlobSha': blob})
(DEST / 'files.sha256.json.txt').write_text(json.dumps({'outputs': outputs, 'reviewMembers': manifest}, indent=2) + '\n')
print(json.dumps({'destination': str(DEST), 'files': len(outputs) + 1, 'reviewMembers': len(manifest), 'bytes': sum(x['bytes'] for x in outputs), 'reviewArchive': next(x for x in outputs if x['path'] == tar_path.name)}, indent=2))
