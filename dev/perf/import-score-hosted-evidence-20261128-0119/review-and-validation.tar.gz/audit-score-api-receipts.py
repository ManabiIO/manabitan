#!/usr/bin/env python3
"""Bind saved GitHub API job/artifact receipts to exact local score audits."""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text())


def describe(path):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def payload(name):
    path = ROOT / 'api-receipts' / name
    receipt = read(path)
    result = receipt['result']
    assert result['isError'] is False
    structured = result['structuredContent']
    body = json.loads(structured['content'])
    return body, {**describe(path), 'savedAtUtc': receipt['saved_at_utc'], 'url': structured['url']}


CONFIGS = [
    ('v1', 46102526376, '1c0239a54df4c8b30124e6cabe644e833c9af64a',
     'runJobs46102526376-20261128T0437.json', 'artifacts46102526376-20261128T0437.json',
     [('jmdict', 'AB', 'jmdict-AB-independent-audit.json'), ('jmdict', 'BA', 'jmdict-BA-independent-audit.json'),
      ('jitendex', 'AB', 'jitendex-AB-independent-audit.json'), ('vndb', 'AB', 'vndb-AB-independent-failure-audit.json')]),
    ('v3', 46103360828, '02bfdeefe6d032a8598a68c196a5ccd949c5ae5d',
     'runJobs46103360828-20261128T0437.json', 'scoreV3ArtifactsLatest-20261128T0437.json',
     [('jmdict', 'AB', 'jmdict-AB-independent-audit.json'), ('jmdict', 'BA', 'jmdict-BA-independent-audit.json'),
      ('jitendex', 'AB', 'jitendex-AB-general-audit-v2.json'), ('vndb', 'AB', 'vndb-AB-independent-audit.json')]),
]
validation_steps = ['Unit suite', 'JavaScript lint', 'Main and test TypeScript',
                    'All target dry builds', 'Qualification observer and receipt regressions']
sources = []
cohorts = []
validations = []
for version, run, candidate, jobs_file, artifacts_file, cases in CONFIGS:
    jobs_body, jobs_receipt = payload(jobs_file)
    artifacts_body, artifacts_receipt = payload(artifacts_file)
    sources.extend([jobs_receipt, artifacts_receipt])
    assert jobs_body['total_count'] == len(jobs_body['jobs']) == 6
    assert artifacts_body['total_count'] == len(artifacts_body['artifacts']) == 6
    jobs = {job['name']: job for job in jobs_body['jobs']}
    artifacts = {item['id']: item for item in artifacts_body['artifacts']}
    assert len(jobs) == len(artifacts) == 6
    assert all(job['run_id'] == run and job['head_sha'] == candidate for job in jobs.values())
    assert all(job['status'] == 'completed' for job in jobs.values())

    def bound_artifact(audit, expected_name):
        artifact = artifacts[audit['artifactId']]
        assert artifact['name'] == expected_name
        assert artifact['workflow_run']['id'] == run
        assert artifact['workflow_run']['head_sha'] == candidate
        assert artifact['digest'] == 'sha256:' + audit['archiveSha256']
        assert artifact['size_in_bytes'] == audit['archiveBytes']
        return {'id': artifact['id'], 'name': artifact['name'], 'bytes': artifact['size_in_bytes'],
                'digest': artifact['digest'], 'workflowRun': artifact['workflow_run']}

    for dictionary, order, filename in cases:
        audit_path = ROOT / f'score-{version}-hosted' / filename
        audit = read(audit_path)
        assert audit['workflowRunId'] == run and audit['sourceBindings']['B']['sha'] == candidate
        job = jobs[f'{dictionary} ({order}, {audit["timing"]["candidateVsBaseline"]["count"]} pairs)']
        expected = 'failure' if version == 'v1' and dictionary == 'vndb' else 'success'
        assert job['conclusion'] == expected
        assert audit['memory']['passesProspectiveMemoryScreen'] == (expected == 'success')
        step = next(step for step in job['steps'] if step['name'] == 'Run fixed complete-import and separate memory cohorts')
        assert step['status'] == 'completed' and step['conclusion'] == expected
        retention = next(step for step in job['steps'] if step['name'] == 'Retain every observation and failure')
        assert retention['status'] == 'completed' and retention['conclusion'] == 'success'
        cohorts.append({'variant': version, 'dictionary': dictionary, 'order': order,
                        'independentAudit': describe(audit_path), 'jobId': job['id'], 'jobConclusion': job['conclusion'],
                        'cohortStepConclusion': step['conclusion'], 'retentionStepConclusion': retention['conclusion'],
                        'artifact': bound_artifact(audit, f'import-score-cache-{dictionary}-{order}-0119')})

    validation_path = ROOT / f'score-{version}-hosted/validation-independent-audit.json'
    validation = read(validation_path)
    assert validation['candidate'] == candidate and validation['runId'] == run
    job = jobs['Source validation']
    assert job['conclusion'] == 'success'
    selected = []
    for name in validation_steps:
        step = next(step for step in job['steps'] if step['name'] == name)
        assert step['status'] == 'completed' and step['conclusion'] == 'success'
        selected.append(step)
    validations.append({'variant': version, 'candidate': candidate, 'sourceAudit': describe(validation_path),
                        'jobId': job['id'], 'jobConclusion': job['conclusion'], 'verifiedStepConclusions': selected,
                        'artifact': bound_artifact(validation, 'import-score-cache-validation-0119')})

log_path = ROOT / 'api-receipts/scoreV1VndbJobLogs-20261128T0437.json'
log_receipt = read(log_path)
assert log_receipt['result']['isError'] is False
log = log_receipt['result']['structuredContent']['content']
assert 'RuntimeError: Complete timing retained; separate memory/semantic qualification failed' in log
assert '##[error]Process completed with exit code 1.' in log
assert 'name: import-score-cache-vndb-AB-0119' in log
result = {
    'schemaVersion': 1, 'complete': True,
    'scope': 'Saved final score V1/V3 GitHub API receipts bound to independently verified artifact bytes, source versions and outcomes. Native queued snapshots are excluded.',
    'apiReceipts': sources, 'cohorts': cohorts, 'validation': validations,
    'v1VndbFailureLog': {**describe(log_path), 'scope': 'Retains runner failure after complete timing, nonzero exit and successful evidence upload path; raw memory audit identifies the specific coverage failure.'},
    'auditScript': describe(Path(__file__).resolve()),
}
output = ROOT / 'score-api-receipts-audit.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output': str(output), 'cohortsBound': len(cohorts), 'validationJobsWithVerifiedStepSuccess': len(validations),
                  'failedCohorts': [row['jobId'] for row in cohorts if row['jobConclusion'] == 'failure']}))
