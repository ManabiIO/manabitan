#!/usr/bin/env python3
"""Audit archived V3 validation without rerunning or extending its checks."""

import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import zipfile


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--cohort', type=Path, required=True)
parser.add_argument('--archive', type=Path, required=True)
parser.add_argument('--workflow', type=Path, required=True)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
cell, archive = args.cohort, args.archive
expected_sha = '58e50bf8c8a6424b32f96965bb3906ba57ee2335799be0cf8a7805f3b0da7af4'
candidate = '02bfdeefe6d032a8598a68c196a5ccd949c5ae5d'
product_sha = '65e3bc1c98b45175d350d79a282b6445225339fafbb9024a7f02f0379222f3c9'
sha = lambda value: hashlib.sha256(value).hexdigest()
receipt = json.loads((cell / 'artifact-receipt.json').read_text())
assert receipt['artifactId'] == 15247923936 and receipt['runId'] == 46103360828
assert receipt['archiveSha256'] == expected_sha
assert receipt['archiveBytes'] == archive.stat().st_size == 482035
assert sha(archive.read_bytes()) == expected_sha
members = {}
with zipfile.ZipFile(archive) as zipped:
    assert len(zipped.namelist()) == len(set(zipped.namelist())) == 6
    assert set(zipped.namelist()) == {row['path'] for row in receipt['members']}
    for item in receipt['members']:
        value = (cell / item['path']).read_bytes()
        assert value == zipped.read(item['path'])
        assert len(value) == item['bytes'] and sha(value) == item['sha256']
        members[item['path']] = {'bytes': len(value), 'sha256': sha(value)}


def git_show(path):
    return subprocess.check_output(['git', 'show', candidate + ':' + path], cwd=args.repo,
                                   env={**os.environ, 'GIT_NO_LAZY_FETCH': '1'})


workflow_bytes = git_show('.github/workflows/import-score-cache-0119.yml')
assert workflow_bytes == args.workflow.read_bytes()
assert 'defaults:\n  run:\n    shell: bash\n' in workflow_bytes.decode()
assert sha(git_show('ext/js/dictionary/term-record-opfs-store.js')) == product_sha
unit = json.loads((cell / 'unit.json').read_text())
assert unit['success'] is True and unit['numFailedTests'] == 0 and unit['numFailedTestSuites'] == 0
assert len(unit['testResults']) == 669
assert all(item['status'] == 'passed' for item in unit['testResults'])
assertions = [test for item in unit['testResults'] for test in item['assertionResults']]
counts = Counter(test['status'] for test in assertions)
assert counts == {'passed': 15139, 'skipped': 47}
assert len(assertions) == unit['numTotalTests'] == 15186
assert unit['numPassedTests'] == 15139 and unit['numPendingTests'] == 47
assert all(not test.get('failureMessages') for test in assertions)
direct = next(item for item in unit['testResults'] if item['name'].endswith('/term-record-direct-field-columns.test.js'))
assert len(direct['assertionResults']) == 19
required_tests = (
    'preserves first-use score IDs after repeated signed-score cache collisions',
    'uses current scores after colliding slots and columns change between calls',
    'preserves scores outside the inline range after the bounded eligibility prefix',
    'rechecks cache eligibility when the score prefix changes between calls',
)
for title in required_tests:
    matches = [test for test in direct['assertionResults'] if test['title'] == title]
    assert len(matches) == 1 and matches[0]['status'] == 'passed'
logs = {path.name: path.read_text() for path in cell.glob('*.log')}
assert re.search(r'Ran 32 tests in [0-9.]+s\s+OK\s*$', logs['qualification.log'])
targets = ['chrome', 'chrome-dev', 'chrome-playwright', 'firefox', 'firefox-dev', 'firefox-android', 'edge']
assert all(f'Building {target}...' in logs['build.log'] for target in targets)
assert logs['build.log'].rstrip().endswith('Restoring manifest...')
for name, command in (('types-main.log', '> npx tsc --noEmit --project jsconfig.json'),
                      ('types-test.log', '> npx tsc --noEmit --project test/jsconfig.typecheck.json')):
    assert logs[name].rstrip().endswith(command)
    assert not re.search(r'error TS\d+', logs[name])
assert '> npx eslint . --ignore-pattern' in logs['lint.log']
assert '[WARNING]' in logs['lint.log'] and 'commonjs-variable-in-esm' in logs['lint.log']
assert 'problems (' not in logs['lint.log'] and 'Oops! Something went wrong!' not in logs['lint.log']
result = {
    'schemaVersion': 1, 'complete': True,
    'scope': 'Archived validation of the exact V3 score-cache candidate only; no browser performance claim.',
    'candidate': candidate, 'productSourceSha256': product_sha,
    'artifactId': receipt['artifactId'], 'runId': receipt['runId'],
    'archiveSha256': expected_sha, 'archiveBytes': archive.stat().st_size,
    'workflowSha256': sha(workflow_bytes), 'members': members,
    'unit': {'success': True, 'passedFiles': 669, 'passedTests': 15139, 'skippedTests': 47, 'failedTests': 0,
             'vitestNestedSuiteCount': unit['numTotalTestSuites'],
             'suiteCountNote': 'Vitest numTotalTestSuites includes nested describe suites; file count is testResults.length.',
             'directFieldRegressionFileCases': 19, 'scoreCacheAndPrefixRegressionsPassed': list(required_tests)},
    'qualificationObserverAndReceiptRegressions': {'passed': 32, 'logFooter': 'OK'},
    'build': {'targets': targets, 'finalLogLine': 'Restoring manifest...'},
    'lint': {'noEslintErrorsReported': True,
             'retainedWarning': 'Bundler commonjs-variable-in-esm warning in existing ext/js/dictionary/mdx/vendor/pako-inflate.js.'},
    'types': {'mainCommandReachedLogEndWithoutDiagnostics': True, 'testCommandReachedLogEndWithoutDiagnostics': True},
    'parentReportedWorkflowJobConclusion': 'success',
    'qualification': 'Unit JSON and Python footer explicitly report success. Other archived logs are consistent with successful completion; command exit statuses are established by the separately acquired workflow job conclusion, not by empty TypeScript diagnostics alone.',
    'auditScriptSha256': sha(Path(__file__).read_bytes()),
}
args.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('complete', 'candidate', 'artifactId', 'archiveSha256', 'unit', 'qualificationObserverAndReceiptRegressions', 'parentReportedWorkflowJobConclusion')}, indent=2))
