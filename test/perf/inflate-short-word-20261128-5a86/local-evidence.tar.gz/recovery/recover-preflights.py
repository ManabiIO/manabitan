#!/usr/bin/env python3
"""Recover only complete recorded receipt content matching pre-reset hashes."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
plan = json.loads((root / 'plan.json').read_bytes())
base = '/tmp/manabitan-session-5a86/profile/short-word-screen'
node = plan['nodeExecutable']


def accept(name, data, expected):
    raw = (json.dumps(data, indent=2) + '\n').encode()
    digest = hashlib.sha256(raw).hexdigest()
    target = root / name
    target.parent.mkdir(parents=True, exist_ok=True)
    if digest != expected:
        target.with_suffix(target.suffix + '.unaccepted').write_bytes(raw)
        raise ValueError((name, len(raw), digest))
    target.write_bytes(raw)
    print(json.dumps({'name': name, 'bytes': len(raw), 'sha256': digest, 'recoveredExact': True}))


manifest = json.loads((root / 'observer-manifest.json').read_bytes())
manifest['files']['run.py'] = '69d8a89063f6bb8cf9bff9d732dec8b6749182745779dfe5138dc21130855410'
accept('preflight-plain-uint8array-20261128/observer-manifest.json', manifest,
       'e1aa20efa81c1153d648933714e035d3debfe0364515069f11a527f66fe2192e')
manifest['files']['observe.mjs'] = '260b45695cd0f5799b920abb64187677697c97a1c8a5314d58a3fb95be29c2f8'
manifest['files']['plan.json'] = '721aa7e98f1b2e74f5a1848ab25f75f4c579f32c55ad618de25a37907e734277'
accept('preflight-20261128/observer-manifest.json', manifest,
       'd62a43d67d16f20c5b094bf637c354d5834ed00107957fea7b7c81797ae6e429')
for arm, digest in [('A', '2f772775a7eb6a28b6945a206c138f84c3d50bed12650fc14beea8828eba2b7f'),
                    ('B', '4b628ec8347bbf8dcd7130903a62c3414bc1e6d318cce64f455cfa2c12a0bb81')]:
    data = {'preflight': True, 'noDecodeOrTimingObservation': True,
            'planSha256': '1ae467eaa524b3aa71d25463fab594379d6d2ee607294bfb351cdde266eee802',
            'source': plan['sources'][arm], 'groups': plan['groups'], 'banks': 53,
            'sourceBytes': 171617523, 'archiveSha256': plan['fixture']['sha256'], 'oracleSha256': plan['oracle']['sha256']}
    accept('preflight-plain-uint8array-20261128/preflight-' + arm + '.json', data, digest)

corrected = []
for arm, log_hash in [('A', 'e1fef0069f8609fa642ee493550a537a9bf80b5370912c936dccf8c3ead80865'),
                      ('B', '91c75bab253e6f7a6980b56f78e6e4083ef6c4a54a3f82295e24b0b30d932cd0')]:
    corrected.append({'label': 'preflight-' + arm,
                      'command': [node, base + '/observe.mjs', base + '/plan.json',
                                  '1ae467eaa524b3aa71d25463fab594379d6d2ee607294bfb351cdde266eee802', arm,
                                  base + '/preflight-plain-uint8array-20261128/preflight-' + arm + '.json', 'preflight'],
                      'returnCode': 0, 'logSha256': log_hash})
accept('preflight-plain-uint8array-20261128/receipts.json', corrected,
       'dacf52b8cc39eae13caebae1a182b1e69be6beea0b8e3ae2eca8a9de5cd48ff2')
original = [
    {'label': 'syntax-observer', 'command': [node, '--check', base + '/observe.mjs'],
     'returnCode': 0, 'logSha256': 'e0cb71fe601c6aa0bc77d1c72b7de24eb689cec9d73775860edf39dc4fa5755c'},
    {'label': 'syntax-driver', 'command': ['python3', '-c', "import ast; from pathlib import Path; ast.parse(Path('" + base + "/run.py').read_text())"],
     'returnCode': 0, 'logSha256': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'},
    {'label': 'preflight-A', 'command': [node, base + '/observe.mjs', base + '/plan.json',
                                      '721aa7e98f1b2e74f5a1848ab25f75f4c579f32c55ad618de25a37907e734277',
                                      'A', base + '/preflight-20261128/preflight-A.json', 'preflight'],
     'returnCode': 1, 'logSha256': 'b9cc1da5b18512741ea1d7a8d5d97f961d5c1ed5fc5f18f8fd6117908d347e18'},
]
accept('preflight-20261128/receipts.json', original,
       'd0db209556cc06c819eb5c7fca985d3920626942746f646fcdef59cc4fad07b6')
