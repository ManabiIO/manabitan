#!/usr/bin/env python3
"""Accept prior audit content only on its independently recorded pre-loss hash."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).parent
plan = json.loads((root / 'plan.json').read_bytes())
records = [
('cohort-20261128/report.json',12460,'d44110e5083129327c21fb0af231ac2ec7adda02e5a614f28537899d83691402'),
('cohort-20261128-controller-receipt.json',475,'990c229edf6dc6b76d5215195bcef11b106b6dd1af9f2162b8eca4329fe64cd9'),
('cohort-20261128-controller.log',0,'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'),
('observe.mjs',10088,'4bd1085be4fd16cc5e5246be3682bcabfdb546331afb4d5ce123084a9f37a4e4'),
('observer-manifest.json',274,'881d693de5f1170c82da4e944e1bc38b7a05c226081a165f7951c6f4ed1e3f82'),
('plan.json',11776,'1ae467eaa524b3aa71d25463fab594379d6d2ee607294bfb351cdde266eee802'),
('preflight-20261128/frozen-inputs/observe.mjs',10072,'260b45695cd0f5799b920abb64187677697c97a1c8a5314d58a3fb95be29c2f8'),
('preflight-20261128/frozen-inputs/observer-manifest.json',274,'d62a43d67d16f20c5b094bf637c354d5834ed00107957fea7b7c81797ae6e429'),
('preflight-20261128/frozen-inputs/plan.json',11776,'721aa7e98f1b2e74f5a1848ab25f75f4c579f32c55ad618de25a37907e734277'),
('preflight-20261128/frozen-inputs/run.py',9879,'69d8a89063f6bb8cf9bff9d732dec8b6749182745779dfe5138dc21130855410'),
('preflight-20261128/preflight-A.log',692,'b9cc1da5b18512741ea1d7a8d5d97f961d5c1ed5fc5f18f8fd6117908d347e18'),
('preflight-20261128/receipts.json',1291,'d0db209556cc06c819eb5c7fca985d3920626942746f646fcdef59cc4fad07b6'),
('preflight-20261128/syntax-driver.log',0,'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'),
('preflight-20261128/syntax-observer.log',174,'e0cb71fe601c6aa0bc77d1c72b7de24eb689cec9d73775860edf39dc4fa5755c'),
('preflight-plain-uint8array-20261128/frozen-inputs/observe.mjs',10088,'4bd1085be4fd16cc5e5246be3682bcabfdb546331afb4d5ce123084a9f37a4e4'),
('preflight-plain-uint8array-20261128/frozen-inputs/observer-manifest.json',274,'e1aa20efa81c1153d648933714e035d3debfe0364515069f11a527f66fe2192e'),
('preflight-plain-uint8array-20261128/frozen-inputs/plan.json',11776,'1ae467eaa524b3aa71d25463fab594379d6d2ee607294bfb351cdde266eee802'),
('preflight-plain-uint8array-20261128/frozen-inputs/run.py',9879,'69d8a89063f6bb8cf9bff9d732dec8b6749182745779dfe5138dc21130855410'),
('preflight-plain-uint8array-20261128/preflight-A.json',3770,'2f772775a7eb6a28b6945a206c138f84c3d50bed12650fc14beea8828eba2b7f'),
('preflight-plain-uint8array-20261128/preflight-A.log',257,'e1fef0069f8609fa642ee493550a537a9bf80b5370912c936dccf8c3ead80865'),
('preflight-plain-uint8array-20261128/preflight-B.json',3775,'4b628ec8347bbf8dcd7130903a62c3414bc1e6d318cce64f455cfa2c12a0bb81'),
('preflight-plain-uint8array-20261128/preflight-B.log',258,'91c75bab253e6f7a6980b56f78e6e4083ef6c4a54a3f82295e24b0b30d932cd0'),
('preflight-plain-uint8array-20261128/receipts.json',1245,'dacf52b8cc39eae13caebae1a182b1e69be6beea0b8e3ae2eca8a9de5cd48ff2'),
('run.py',10732,'6740a59f94254e2d0060f094993c818f73a472fd9b7be96deceaa13139274c92'),
]
result = {
    'status': 'PASS: failure evidence reconciled; acquisition did not complete',
    'noAcquisitionByReviewer': True,
    'files': {name: {'bytes': size, 'sha256': digest} for name, size, digest in records},
    'source': {'A': plan['sources']['A']['commit'], 'B': plan['sources']['B']['commit'], 'C': plan['sources']['C']['commit']},
    'prescribedChildren': 36, 'observedChildren': 0, 'completedSweeps': 0,
    'signal': 9, 'emptyControllerLog': True, 'originalReportFailureIsNull': True,
    'failureWindow': 'After the initial incomplete report was saved and before the first child log was opened and child subprocess launched. There is no persisted checkpoint between initial verification and the first pre-slot verification, so the exact substage or failed operation cannot be identified from these receipts.',
    'cause': 'Not established; signal 9 alone does not establish resource exhaustion or any specific kill reason.',
    'preflights': 'Original adapter failure and corrected A/B no-decode preflights are retained. Successful preparation is not a decode or timing observation.',
    'statistics': {'cold': None, 'postcoldSweeps': None, 'fourSweepMean': None, 'wall': None, 'nativeInclusiveCrc': None, 'cpu': None, 'BA': None, 'BC': None, 'CA': None},
    'continuation': {'completionRequired': True, 'completionPassed': False, 'eligibleFromThisCohort': False,
                     'disposition': 'HOLD; no unchanged local rerun. There is no effect estimate or performance qualification.'},
    'remainingSourceGates': plan['knownValidationLimitations'],
}
raw = (json.dumps(result, indent=2) + '\n').encode()
digest = hashlib.sha256(raw).hexdigest()
(root / 'review.recovery-attempt.json').write_bytes(raw)
if digest != '11ce7d08c149d065324038f6ffefa0c3143d475319c8e337a8eb2c065dbfc1b3':
    raise SystemExit(f'UNACCEPTED: {len(raw)} bytes {digest}')
(root / 'original-independent-failure-review.json').write_bytes(raw)
print(json.dumps({'accepted': True, 'bytes': len(raw), 'sha256': digest,
                  'provenance': 'Original complete auditor and its complete original-file inventory were printed before loss; recovered content matches independently recorded pre-loss SHA-256. This is the historical review, not a new audit of unavailable files.'}))
