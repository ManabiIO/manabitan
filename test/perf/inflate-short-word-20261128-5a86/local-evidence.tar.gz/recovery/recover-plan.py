#!/usr/bin/env python3
"""Restore the complete observed plan and accept only its pre-loss SHA-256."""
import copy
import hashlib
import json
from pathlib import Path

baseline = {
    'root': '/workspace/scratch/5a86d1e7822a/manabitan',
    'commit': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2',
    'tree': 'd99ea4d04658f7ec1c76acdc5f3684594212a471',
    'files': {
        'dev/dictionary-wasm.js': '65ffde7d98a687784b63cbad65047cb5adb53cb6789787e88f0b9b7281208d17',
        'dev/data/dictionary-wasm/manifest.json': 'ddffecdd5f333c623b20447bb219a358e15c425f906d90509d0e1443701f0224',
        'dev/data/dictionary-wasm/term-bank-parser.wasm': '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee',
        'ext/lib/term-bank-parser.wasm': '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee',
        'ext/js/dictionary/term-bank-wasm-parser.js': '31854cfb3d20ba60b701ec31cf19de26bd55cc745cc4f998cb33f0554ec83cca',
        'ext/js/dictionary/term-bank-source-pipeline.js': '602c1369d8df6c134601dde28ab7b6ed4b77235811153c2036f3ae29731d93c9',
        'ext/js/dictionary/term-bank-experiments.js': 'c3a0302d5ae434267191416cd6848612aeb011e6313731aed39450a44dae84fb',
        'ext/js/dictionary/wasm/term-bank-parser.c': '5a8257cb77d061694b6b2d247057aebb53ea2f49521d8d9893b3af175f145d8a',
        'ext/js/dictionary/wasm/term-bank-inflate.c': '6d86d0a56f524cdccd1701a9ac7c466c50ecc699ef68d377a82b9f2aaaa317cc',
        'ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h': 'ade3034c1d5c840cb31bd9738a015be804862a8dfce03c14ac2f5b3a826792b8',
        'ext/js/dictionary/wasm/vendor/libdeflate/README.md': '1aa68185f1fc2cb9a6e25612ebb07f6527a6695fbe17d60b0c43011b0e578ac9',
        'package-lock.json': '01e065503317a90b43a5bc60cd9f874238762c75a13c8115a9c484a626960a96',
        'test/perf/dictionaries.lock.json': '60aa981791f3b60ca17588212aea5bd3536fb8f59288855e5accd019c6e4cf89',
    },
    'wasmSha256': '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee',
}
candidate = copy.deepcopy(baseline)
candidate.update(root='/tmp/manabitan-session-5a86/inflate-short-word',
                 commit='1c93b0a18f5dd53a13dfdd3d054687c85e097247',
                 tree='7bf2f889a94d955bf8845b9f8d9e2d4afb464617',
                 wasmSha256='e522cb7f60cef3c8d305853afc57e8eb6c5d2121bf39ae773bff407901cc04b6')
candidate['files'].update({
    'dev/data/dictionary-wasm/manifest.json': '90d96cdc97d81c1d215210d0848378bb64fc02f2ed38228bfc893a021fd127c6',
    'dev/data/dictionary-wasm/term-bank-parser.wasm': candidate['wasmSha256'],
    'ext/lib/term-bank-parser.wasm': candidate['wasmSha256'],
    'ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h': '182cffdacc45c36381c674a4bc03c7ca178e00a2935f20fc2cbdf155af474c99',
    'ext/js/dictionary/wasm/vendor/libdeflate/README.md': '8370e1c45bf97b7d26c6771fa3b65dfa3bed8cce37f28a3b00705540a2f0feb2',
})
plan = {
    'schema': 1,
    'purpose': 'Fixed component screen deciding whether a distinct short-word decoder candidate merits hosted complete-import screening; never a PR speed claim.',
    'boundary': 'Five complete fixed JMdict decodes per fresh Node process, twelve production-byte-balanced groups in serial. Cold first decode is after untimed module compilation and input/oracle preparation; four subsequent sweeps are all retained and averaged with equal weight, without a steady-state claim. Primary clock sums awaited production inflate helper calls, including allocation and compressed-input copies. Existing native sourceInflate counter is secondary and includes immediate CRC. Separate process user/system CPU counters bracket the same calls and may include runtime/compiler threads. Input acquisition, output SHA/CRC/spans verification and receipt writes are outside every measured call. No explicit GC, affinity, flags, worker-count or production-budget change.',
    'nodeVersion': 'v22.22.0',
    'nodeExecutable': '/home/agent/manabitan-toolchains-5a86d1e7822a/node-v22.22.0-linux-x64/bin/node',
    'nodeExecutableSha256': '1bec56ef7cfa9a76f3e0b7c0a87f220eb73f23102b9c0b4c7529a3f7c3ce7c31',
    'observerSha256': '4bd1085be4fd16cc5e5246be3682bcabfdb546331afb4d5ce123084a9f37a4e4',
    'sources': {'A': baseline, 'B': candidate, 'C': copy.deepcopy(baseline)},
    'fixture': {'path': '/workspace/scratch/5a86d1e7822a/manabitan/builds/e2e-dictionary-cache/JMdict.zip',
                'sha256': '3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f', 'bytes': 15645766},
    'oracle': {'path': '/tmp/manabitan-session-5a86/profile/deflate-path-census-20261128-complete/jmdict-deflate-path-census.json',
               'sha256': '507c25a0257d5fd8b789e294386f6b703f77efda0863e0ef64b7c176e06d8023',
               'scope': 'Every bank was independently decompressed with raw Python zlib and compared byte-for-byte with unchanged and instrumented pinned portable decoder; original CRC and exact input/output lengths checked. Oracle hash and every bank identity are bound before each child.'},
    'groups': [[f'term_bank_{i}.json' for i in range(start, end + 1)] for start, end in
               [(1, 5), (6, 9), (10, 13), (14, 17), (18, 22), (23, 27), (28, 31), (32, 36), (37, 40), (41, 44), (45, 48), (49, 53)]],
    'policy': {'actualProductionWorkers': 3, 'groupsPerWorker': 4, 'targetBytes': 25165824,
               'componentExecutionConcurrency': 1, 'sourceBankCount': 53, 'sourceBytes': 171617523,
               'compressedBytes': 15632849, 'options': {}, 'requestGlossaryCrcTransaction': True,
               'expectedDeferredCrc': False},
    'orders': ['ABC', 'ACB', 'BAC', 'BCA', 'CAB', 'CBA', 'ABC', 'ACB', 'BAC', 'BCA', 'CAB', 'CBA'],
    'freshProcesses': 36,
    'sweeps': {'cold': 1, 'postcold': 4, 'selectiveDiscard': False, 'steadyStateClaim': False},
    'completionRule': 'All36 frozen slots must complete with all5 sweeps,53 banks,12 exact groups,171617523 decoded bytes, equal complete output/spans digest and native heap shapes. Stop on the first exit, signal, source/receipt/oracle failure; preserve raw stdout/report/receipt and do not retry, substitute, discard, reorder or silently reinterpret any slot.',
    'summaryRule': 'Twelve ordered three-arm blocks. Report B/A, B/C and C/A cold and each postcold sweep separately, plus all-four-postcold mean paired medians, equal-work ratios and faster-block counts for wall, native-inclusive-CRC and process CPU clocks. Every observed tail remains.',
    'continuation': {'minimumPairedWallImprovementPercent': 2, 'minimumFasterBlocks': 9,
                     'maximumSameCodeMedianDriftPercent': 2, 'maximumColdMedianRegressionPercent': 5,
                     'candidateEqualWorkWallAgainstBoth': 'negative', 'candidateMedianCpuAgainstBoth': 'negative',
                     'allCorrectnessAndSourceGates': 'required', 'onFailure': 'hold; no unchanged local rerun',
                     'onPass': 'eligible only for hosted full import/source/memory qualification, including full leak-enabled sanitizer; no PR or whole-import gain claim'},
    'knownValidationLimitations': [
        'LeakSanitizer under this local ptrace environment failed; separately-labelled AddressSanitizer+UBSan-only run passed231528 cases. Full leak-enabled hosted check remains required.',
        'Final exact-head scoped ESLint is unpassed: process was killed by signal9. An earlier lint pass is not transferred to this final test source. Exact final TypeScript and test suite pass; hosted exact-source lint remains required.',
        'Native-host census and sanitizer do not replace actual wasm32 bounds tests or full browser memory qualification.',
    ],
    'expectedPackageChanges': ['js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h',
                               'js/dictionary/wasm/vendor/libdeflate/README.md', 'lib/term-bank-parser.wasm'],
}
raw = (json.dumps(plan, indent=2) + '\n').encode()
digest = hashlib.sha256(raw).hexdigest()
root = Path(__file__).parent
(root / 'plan.recovery-attempt.json').write_bytes(raw)
if digest != '1ae467eaa524b3aa71d25463fab594379d6d2ee607294bfb351cdde266eee802' or len(raw) != 11776:
    raise SystemExit(f'UNACCEPTED: {len(raw)} bytes {digest}')
(root / 'plan.json').write_bytes(raw)
print(json.dumps({'accepted': True, 'bytes': len(raw), 'sha256': digest,
                  'provenance': 'Complete original plan content printed before loss; exact pre-loss byte length and SHA-256 matched.'}))
