import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {readFile, writeFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {performance} from 'node:perf_hooks';
import {crc32} from 'node:zlib';

const [planPath, planSha, arm, output, mode] = process.argv.slice(2);
assert(planPath && planSha && ['A', 'B', 'C'].includes(arm) && output);
assert(mode === undefined || mode === 'preflight');
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const planBytes = await readFile(planPath);
assert.equal(sha(planBytes), planSha);
const plan = JSON.parse(planBytes);
assert.equal(process.version, plan.nodeVersion);
assert.equal(sha(await readFile(fileURLToPath(import.meta.url))), plan.observerSha256);
const source = plan.sources[arm];
const root = source.root;
const git = (...args) => execFileSync('git', args, {cwd: root, encoding: 'utf8'}).trim();
const verifySource = async () => {
    assert.equal(git('rev-parse', 'HEAD'), source.commit);
    assert.equal(git('rev-parse', 'HEAD^{tree}'), source.tree);
    assert.equal(git('status', '--porcelain'), '');
    for (const [filename, expected] of Object.entries(source.files)) {
        assert.equal(sha(await readFile(path.join(root, filename))), expected, filename);
    }
};
await verifySource();
const nativeArtifacts = await import(pathToFileURL(path.join(root, 'dev/dictionary-wasm.js')));
nativeArtifacts.loadDictionaryWasm();
const parser = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-bank-wasm-parser.js')));
const wasmBytes = await readFile(path.join(root, 'ext/lib/term-bank-parser.wasm'));
assert.equal(sha(wasmBytes), source.wasmSha256);
const tCompile = performance.now();
const module = await WebAssembly.compile(wasmBytes);
const moduleCompileMs = performance.now() - tCompile;
assert.deepEqual(WebAssembly.Module.imports(module), []);
parser.setTermBankWasmModule(module);

const oracleBytes = await readFile(plan.oracle.path);
assert.equal(sha(oracleBytes), plan.oracle.sha256);
const oracle = JSON.parse(oracleBytes);
assert.equal(oracle.complete, true);
assert.equal(oracle.archive.sha256, plan.fixture.sha256);
const archive = await readFile(plan.fixture.path);
assert.equal(archive.byteLength, plan.fixture.bytes);
assert.equal(sha(archive), plan.fixture.sha256);
const require = createRequire(path.join(root, 'package.json'));
const {ZipReader, Uint8ArrayReader} = require('@zip.js/zip.js');
const {RawZipPayloadReader} = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-bank-source-pipeline.js')));
const zip = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)), {useWebWorkers: false});
const raw = new RawZipPayloadReader(archive.buffer.slice(archive.byteOffset, archive.byteOffset + archive.byteLength));
const banks = [];
try {
    const entries = (await zip.getEntries()).filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename))
        .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)));
    assert.equal(entries.length, 53);
    const signal = new AbortController().signal;
    for (const [index, entry] of entries.entries()) {
        const expected = oracle.banks[index];
        assert.equal(entry.filename, expected.filename);
        assert.equal(entry.compressedSize, expected.compressedBytes);
        assert.equal(entry.uncompressedSize, expected.decodedBytes);
        assert.equal(entry.signature, expected.crc32);
        assert.equal(entry.compressionMethod, 8);
        const bytes = await raw.read(entry, signal);
        assert.equal(sha(bytes), expected.compressedSha256);
        banks.push({bytes, compressionMethod: 8, compressedSize: entry.compressedSize,
            uncompressedSize: entry.uncompressedSize, signature: entry.signature, filename: entry.filename,
            expectedSha256: expected.decodedSha256});
    }
} finally { await zip.close(); }

// This is the existing byte-balancing algorithm with the observed three-worker
// default and four groups per worker. Only execution is serial for the component.
const total = banks.reduce((sum, bank) => sum + bank.uncompressedSize, 0);
const requested = Math.min(banks.length, Math.max(3 * 4, Math.ceil(total / (24 * 1024 * 1024))));
const groups = [];
let start = 0;
let consumed = 0;
for (let index = 0; index < requested - 1; ++index) {
    const remaining = requested - index;
    const target = (total - consumed) / remaining;
    let end = start + 1;
    let bytes = banks[start].uncompressedSize;
    const maxEnd = banks.length - (remaining - 1);
    while (end < maxEnd) {
        const next = bytes + banks[end].uncompressedSize;
        if (Math.abs(next - target) > Math.abs(bytes - target)) { break; }
        bytes = next;
        ++end;
    }
    groups.push(banks.slice(start, end));
    start = end;
    consumed += bytes;
}
groups.push(banks.slice(start));
assert.deepEqual(groups.map((group) => group.map((bank) => bank.filename)), plan.groups);
assert.equal(groups.length, 12);
assert.equal(total, 171617523);
assert.equal(banks.reduce((sum, bank) => sum + bank.compressedSize, 0), 15632849);
if (mode === 'preflight') {
    await verifySource();
    await writeFile(output, JSON.stringify({preflight: true, noDecodeOrTimingObservation: true,
        planSha256: planSha, source, groups: plan.groups, banks: banks.length,
        sourceBytes: total, archiveSha256: plan.fixture.sha256, oracleSha256: plan.oracle.sha256}, null, 2) + '\n', {flag: 'wx'});
    console.log('Source, module, archive, oracle and all production groups verified; no decode run.');
    process.exit(0);
}

const report = {complete: false, arm, pid: process.pid, node: process.version,
    planSha256: planSha, observerSha256: plan.observerSha256, oracleSha256: plan.oracle.sha256,
    source, archiveSha256: plan.fixture.sha256, moduleCompileMs,
    boundary: plan.boundary, sweeps: []};
await writeFile(output, JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
for (let sweep = 0; sweep < 5; ++sweep) {
    const value = {index: sweep, kind: sweep === 0 ? 'cold-first-complete-decode' : 'postcold-prescribed-sweep',
        callElapsedMs: 0, sourceInflateMs: 0, cpuUserMicros: 0, cpuSystemMicros: 0,
        maxNativeHeapBytes: 0, decodedBytes: 0, groups: []};
    const outputDigest = createHash('sha256');
    for (const [groupIndex, group] of groups.entries()) {
        // Match the worker's format-3 glossary-validation transaction request.
        // JMdict's unchanged admission still selects immediate complete CRCs.
        const cpu0 = process.cpuUsage();
        const t0 = performance.now();
        const result = await parser.inflateCompressedTermBankSourcesWasm(group, {}, true);
        const callElapsedMs = performance.now() - t0;
        const cpu = process.cpuUsage(cpu0);
        value.callElapsedMs += callElapsedMs;
        value.sourceInflateMs += result.inflateMs;
        value.cpuUserMicros += cpu.user;
        value.cpuSystemMicros += cpu.system;
        const expectedBytes = group.reduce((sum, bank) => sum + bank.uncompressedSize, 0);
        assert.equal(result.jsonLength, expectedBytes);
        assert.equal(result.uncompressedBytes, expectedBytes);
        assert.equal(result.sourceCount, group.length);
        assert.equal(result.bankSpanCount, group.length);
        assert.equal(result.crcSignaturesPtr, 0, 'Do not alter immediate-CRC admission');
        assert.equal(result.crcStatsPtr, 0);
        assert(result.bankSpansPtr > 0);
        const spans = new Uint32Array(result.wasm.memory.buffer, result.bankSpansPtr, group.length * 2);
        let cursor = 0;
        for (let index = 0; index < group.length; ++index) {
            const bank = group[index];
            assert.equal(spans[index * 2], cursor);
            assert.equal(spans[index * 2 + 1], bank.uncompressedSize);
            const decoded = new Uint8Array(result.wasm.memory.buffer, result.jsonPtr + cursor, bank.uncompressedSize);
            assert.equal(sha(decoded), bank.expectedSha256, bank.filename);
            assert.equal(crc32(decoded), bank.signature, bank.filename);
            outputDigest.update(decoded);
            cursor += bank.uncompressedSize;
        }
        assert.equal(cursor, result.jsonLength);
        outputDigest.update(new Uint8Array(spans.buffer, spans.byteOffset, spans.byteLength));
        value.maxNativeHeapBytes = Math.max(value.maxNativeHeapBytes, result.wasm.memory.buffer.byteLength);
        value.decodedBytes += expectedBytes;
        value.groups.push({groupIndex, firstBank: group[0].filename, lastBank: group.at(-1).filename,
            bankCount: group.length, decodedBytes: expectedBytes, compressedBytes: result.compressedBytes,
            callElapsedMs, sourceInflateMs: result.inflateMs, cpuUserMicros: cpu.user,
            cpuSystemMicros: cpu.system, heapBytes: result.wasm.memory.buffer.byteLength});
    }
    assert.equal(value.decodedBytes, total);
    value.digest = outputDigest.digest('hex');
    value.cpuTotalMs = (value.cpuUserMicros + value.cpuSystemMicros) / 1000;
    if (report.sweeps.length > 0) { assert.equal(value.digest, report.sweeps[0].digest); }
    value.afterVerificationMemory = process.memoryUsage();
    report.sweeps.push(value);
    await writeFile(output, JSON.stringify(report, null, 2) + '\n');
}
await verifySource();
assert.equal(sha(await readFile(planPath)), planSha);
assert.equal(sha(await readFile(fileURLToPath(import.meta.url))), plan.observerSha256);
assert.equal(sha(await readFile(plan.oracle.path)), plan.oracle.sha256);
report.lifetimeMaxRssKiB = process.resourceUsage().maxRSS;
report.complete = true;
await writeFile(output, JSON.stringify(report, null, 2) + '\n');
console.log(JSON.stringify({arm, complete: true, digest: report.sweeps[0].digest,
    callElapsedMs: report.sweeps.map((sweep) => sweep.callElapsedMs),
    sourceInflateMs: report.sweeps.map((sweep) => sweep.sourceInflateMs)}));
