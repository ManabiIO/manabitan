#!/usr/bin/env python3
"""Fixed fresh-process component screen, stop at the first failed slot."""
import hashlib
import itertools
import json
from pathlib import Path
import statistics
import subprocess
import sys

HERE = Path(__file__).resolve().parent
manifest_sha = sys.argv[1]
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest_raw = (HERE / 'observer-manifest.json').read_bytes()
assert sha(manifest_raw) == manifest_sha
manifest = json.loads(manifest_raw)
plan = json.loads((HERE / 'plan.json').read_bytes())
assert len(plan['orders']) == 12
assert sorted(plan['orders']) == sorted([''.join(order) for order in itertools.permutations('ABC')] * 2)
assert plan['sweeps'] == {'cold': 1, 'postcold': 4, 'selectiveDiscard': False, 'steadyStateClaim': False}
plan_sha = manifest['files']['plan.json']
out = Path(sys.argv[2])
out.mkdir(exist_ok=False)

def verify():
    assert sha((HERE / 'observer-manifest.json').read_bytes()) == manifest_sha
    for name, expected in manifest['files'].items():
        assert sha((HERE / name).read_bytes()) == expected, name
    assert sha(Path(plan['oracle']['path']).read_bytes()) == plan['oracle']['sha256']
    assert sha(Path(plan['nodeExecutable']).read_bytes()) == plan['nodeExecutableSha256']
    for arm, source in plan['sources'].items():
        def git(*args):
            return subprocess.check_output(['git', *args], cwd=source['root'], text=True).strip()
        assert git('rev-parse', 'HEAD') == source['commit']
        assert git('rev-parse', 'HEAD^{tree}') == source['tree']
        assert git('status', '--porcelain') == ''
        for name, expected in source['files'].items():
            assert sha((Path(source['root']) / name).read_bytes()) == expected, (arm, name)

def save(report):
    (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

if not __debug__:
    raise RuntimeError('Assertions are required for the source and receipt gates')
report = {'complete': False, 'manifestSha256': manifest_sha, 'planSha256': plan_sha,
          'plan': plan, 'observations': [], 'failure': None}
save(report)
try:
    verify()
except Exception as error:
    report['failure'] = {'label': None, 'stage': 'initial-source-check', 'reason': repr(error)}
    save(report)
    raise
digest = None
heap_shape = None
for block, order in enumerate(plan['orders']):
    for arm in order:
        label = f'{block + 1:02d}-{arm}'
        try:
            verify()
        except Exception as error:
            report['failure'] = {'label': label, 'stage': 'pre-slot-source-check', 'reason': repr(error)}
            save(report)
            raise
        output = out / (label + '.json')
        command = [plan['nodeExecutable'], str(HERE / 'observe.mjs'), str(HERE / 'plan.json'), plan_sha, arm, str(output)]
        with (out / (label + '.log')).open('xb') as log:
            result = subprocess.run(command, cwd=HERE, stdout=log, stderr=subprocess.STDOUT)
        receipt = {'block': block + 1, 'arm': arm, 'order': order, 'command': command,
                   'exitCode': result.returncode if result.returncode >= 0 else None,
                   'signal': -result.returncode if result.returncode < 0 else None,
                   'logSha256': sha((out / (label + '.log')).read_bytes())}
        if output.exists():
            raw_bytes = output.read_bytes()
            receipt['rawSha256'] = sha(raw_bytes)
            try:
                receipt['raw'] = json.loads(raw_bytes)
            except Exception as error:
                receipt['rawParseError'] = repr(error)
        else:
            receipt['rawParseError'] = 'Child output file is missing'
        report['observations'].append(receipt)
        save(report)
        if result.returncode != 0:
            report['failure'] = {'label': label, 'stage': 'child-exit', 'reason': 'Child exited unsuccessfully; no retry or replacement'}
            save(report)
            sys.exit(1)
        if 'rawParseError' in receipt:
            report['failure'] = {'label': label, 'stage': 'child-output-parse', 'reason': receipt['rawParseError']}
            save(report)
            sys.exit(1)
        try:
            raw = receipt['raw']
            assert raw['complete'] and raw['arm'] == arm and raw['planSha256'] == plan_sha
            assert raw['source'] == plan['sources'][arm]
            assert len(raw['sweeps']) == 5
            for index, sweep in enumerate(raw['sweeps']):
                assert sweep['index'] == index
                assert len(sweep['groups']) == 12 and sweep['decodedBytes'] == 171617523
                assert sum(group['bankCount'] for group in sweep['groups']) == 53
                assert sum(group['compressedBytes'] for group in sweep['groups']) == 15632849
                assert sweep['callElapsedMs'] >= sweep['sourceInflateMs'] >= 0
                assert sweep['cpuTotalMs'] == (sweep['cpuUserMicros'] + sweep['cpuSystemMicros']) / 1000
                if digest is None:
                    digest = sweep['digest']
                assert sweep['digest'] == digest
            current_heap_shape = [[group['heapBytes'] for group in sweep['groups']] for sweep in raw['sweeps']]
            if heap_shape is None:
                heap_shape = current_heap_shape
            assert current_heap_shape == heap_shape, 'Native heap shape changed'
            verify()
        except Exception as error:
            report['failure'] = {'label': label, 'stage': 'post-slot-receipt-source-check', 'reason': repr(error)}
            save(report)
            raise
        print(json.dumps({'slot': label, 'complete': True,
                          'callElapsedMs': [s['callElapsedMs'] for s in raw['sweeps']]}), flush=True)

comparisons = []
assert len(report['observations']) == 36
for block in range(1, 13):
    values = {observation['arm']: observation['raw']['sweeps'] for observation in report['observations'] if observation['block'] == block}
    for clock in ('callElapsedMs', 'sourceInflateMs', 'cpuTotalMs'):
        cold = {arm: sweeps[0][clock] for arm, sweeps in values.items()}
        postcold = {arm: statistics.mean(s[clock] for s in sweeps[1:]) for arm, sweeps in values.items()}
        comparisons.append({'block': block, 'clock': clock, 'cold': cold, 'postcoldMean': postcold,
                            'coldBAPercent': 100 * (cold['B'] / cold['A'] - 1),
                            'coldCAPercent': 100 * (cold['C'] / cold['A'] - 1),
                            'coldBCPercent': 100 * (cold['B'] / cold['C'] - 1),
                            'postcoldBAPercent': 100 * (postcold['B'] / postcold['A'] - 1),
                            'postcoldCAPercent': 100 * (postcold['C'] / postcold['A'] - 1),
                            'postcoldBCPercent': 100 * (postcold['B'] / postcold['C'] - 1)})
report['comparisons'] = comparisons
report['summary'] = {}
for clock in ('callElapsedMs', 'sourceInflateMs', 'cpuTotalMs'):
    selected = [comparison for comparison in comparisons if comparison['clock'] == clock]
    report['summary'][clock] = {'pairedMedianBAPercent': statistics.median(c['postcoldBAPercent'] for c in selected),
                              'pairedMedianCAPercent': statistics.median(c['postcoldCAPercent'] for c in selected),
                              'pairedMedianBCPercent': statistics.median(c['postcoldBCPercent'] for c in selected),
                              'candidateFasterBlocks': sum(c['postcoldBAPercent'] < 0 for c in selected),
                              'candidateFasterThanControlBlocks': sum(c['postcoldBCPercent'] < 0 for c in selected),
                              'controlFasterBlocks': sum(c['postcoldCAPercent'] < 0 for c in selected),
                              'equalWorkBAPercent': 100 * (sum(c['postcoldMean']['B'] for c in selected) / sum(c['postcoldMean']['A'] for c in selected) - 1),
                              'equalWorkBCPercent': 100 * (sum(c['postcoldMean']['B'] for c in selected) / sum(c['postcoldMean']['C'] for c in selected) - 1),
                              'equalWorkCAPercent': 100 * (sum(c['postcoldMean']['C'] for c in selected) / sum(c['postcoldMean']['A'] for c in selected) - 1),
                              'coldPairedMedianBAPercent': statistics.median(c['coldBAPercent'] for c in selected),
                              'coldPairedMedianBCPercent': statistics.median(c['coldBCPercent'] for c in selected),
                              'coldPairedMedianCAPercent': statistics.median(c['coldCAPercent'] for c in selected)}
    per_sweep = []
    for sweep in range(5):
        entries = []
        for block in range(1, 13):
            values = {o['arm']: o['raw']['sweeps'][sweep][clock] for o in report['observations'] if o['block'] == block}
            entries.append({'block': block, 'values': values,
                            'BAPercent': 100 * (values['B'] / values['A'] - 1),
                            'BCPercent': 100 * (values['B'] / values['C'] - 1),
                            'CAPercent': 100 * (values['C'] / values['A'] - 1)})
        per_sweep.append({'sweep': sweep, 'blocks': entries,
                          'pairedMedians': {pair: statistics.median(e[pair + 'Percent'] for e in entries) for pair in ('BA', 'BC', 'CA')},
                          'equalWork': {pair: 100 * (sum(e['values'][pair[0]] for e in entries) / sum(e['values'][pair[1]] for e in entries) - 1) for pair in ('BA', 'BC', 'CA')}})
    report['summary'][clock]['allSweeps'] = per_sweep
criteria = plan['continuation']
wall = report['summary']['callElapsedMs']
cpu = report['summary']['cpuTotalMs']
checks = {
    'candidateMedianWallAgainstBoth': all(wall['pairedMedian' + pair + 'Percent'] <= -criteria['minimumPairedWallImprovementPercent'] for pair in ('BA', 'BC')),
    'candidateEqualWorkWallAgainstBoth': all(wall['equalWork' + pair + 'Percent'] < 0 for pair in ('BA', 'BC')),
    'candidateMedianCpuAgainstBoth': all(cpu['pairedMedian' + pair + 'Percent'] < 0 for pair in ('BA', 'BC')),
    'candidateFasterBlocksAgainstBoth': min(wall['candidateFasterBlocks'], wall['candidateFasterThanControlBlocks']) >= criteria['minimumFasterBlocks'],
    'sameCodeMedianWallDrift': abs(wall['pairedMedianCAPercent']) <= criteria['maximumSameCodeMedianDriftPercent'],
    'sameCodeMedianCpuDrift': abs(cpu['pairedMedianCAPercent']) <= criteria['maximumSameCodeMedianDriftPercent'],
    'coldWallAgainstBoth': all(wall['coldPairedMedian' + pair + 'Percent'] <= criteria['maximumColdMedianRegressionPercent'] for pair in ('BA', 'BC')),
}
report['continuationChecks'] = checks
report['eligibleForHostedScreen'] = all(checks.values())
report['complete'] = True
save(report)
print(json.dumps({'complete': True, 'summary': report['summary']}), flush=True)
