#!/usr/bin/env python3
"""Read one retained Firefox study artifact; validate receipts and recompute paired statistics."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
import zipfile


parser = argparse.ArgumentParser()
parser.add_argument("archive", type=Path)
parser.add_argument("--sha256", required=True)
args = parser.parse_args()
archive_digest = hashlib.sha256(args.archive.read_bytes()).hexdigest()
assert archive_digest == args.sha256
with zipfile.ZipFile(args.archive) as archive:
    assert archive.testzip() is None
    read = lambda name: json.loads(archive.read(name))
    cohort = read("cohort.json")
    preparation = read("preparation.json")
    manifest = read("manifest.json")
    assert cohort["complete"] is True and cohort["failures"] == []
    assert preparation["complete"] is True
    assert preparation["diagnosticCommit"] == "a4a2ee2b29fce97f6e22c65f7e4bb497bec342ee"
    assert len(cohort["observations"]) == len(cohort["planned"]) == 104
    assert [o["label"] for o in cohort["observations"]] == [o["label"] for o in cohort["planned"]]
    assert hashlib.sha256(archive.read("manifest.json")).hexdigest() == cohort["manifestSha256"] == preparation["manifestSha256"]
    runtime = preparation["browserRuntime"]
    package_entries = {arm: read(f"{arm}-package-entries.json") for arm in "ABCD"}
    assert package_entries["A"] == package_entries["C"]
    for arm in ("B", "D"):
        changed = sorted(key for key in set(package_entries["A"]) | set(package_entries[arm])
                         if package_entries["A"].get(key) != package_entries[arm].get(key))
        expected_changes = ["js/dictionary/term-bank-source-pipeline.js"]
        if arm == "D":
            expected_changes.insert(0, "js/dictionary/dictionary-importer.js")
        assert changed == expected_changes
    summaries = []
    profiles = set()
    for observation in cohort["observations"]:
        label, arm = observation["label"], observation["arm"]
        expected = preparation["arms"][arm]
        summary = read(f"observations/{label}/summary.json")
        command = read(f"commands/{label}/command.json")
        assert command["complete"] is True and command["exitCode"] == 0
        assert summary["completed"] is True and summary["phase"] == "complete"
        assert summary["authoritativeTiming"] is True and summary["skippedVerification"] is False
        assert summary["error"] is None and summary["cleanupErrors"] == [] and summary["diagnosticErrors"] == []
        assert not observation.get("error")
        assert summary["totalImportMs"] == observation["totalImportMs"]
        assert summary["source"]["commit"] == expected["commit"]
        assert summary["source"]["tree"] == expected["tree"]
        assert summary["source"]["packageLockSha256"] == manifest["sharedProductInputs"]["package-lock.json"]
        assert summary["source"]["commonGeneratedOverlay"] == expected["commonGeneratedOverlay"]
        assert summary["package"]["sha256"] == expected["packageSha256"]
        assert summary["runtime"]["binarySha256"] == runtime["binarySha256"]
        assert summary["runtime"]["geckodriverSha256"] == runtime["geckodriver"]["binarySha256"]
        assert summary["runtime"]["node"] == manifest["node"] and summary["runtime"]["headless"] is False
        assert summary["fixture"]["sha256"] == preparation["fixture"]["sha256"]
        assert summary["fixture"]["lockSha256"] == manifest["sharedProductInputs"]["test/perf/dictionaries.lock.json"]
        assert summary["browser"]["freshProfile"] is True and summary["browser"]["suppliedProfile"] is False
        assert summary["browser"]["profile"] not in profiles
        profiles.add(summary["browser"]["profile"])
        assert summary["reload"]["kind"] == "addon-manager-reload-from-browser-chrome"
        assert summary["reload"]["priorOrigin"] != summary["reload"]["nextOrigin"]
        assert summary["reload"]["reimported"] is False
        assert summary["validation"]["extensionReloadVerified"] is True
        assert summary["validation"]["title"] == summary["fixture"]["expectedTitle"]
        assert summary["validation"]["revision"] == summary["fixture"]["revision"]
        expected_semantics = [{k: p[k] for k in ("expression", "reading", "glossary")} for p in summary["fixture"]["probes"]]
        assert len(expected_semantics) == 12
        for phase in ("beforeReload", "afterReload"):
            result = summary[phase]
            assert result["semantics"] == expected_semantics
            assert result["counts"]["counts"][0]["terms"] == 526942
            assert result["probeCount"] == 12
            assert result["storage"]["usesFallbackStorage"] is False
            assert result["storage"]["openStorageDiagnostics"]["mode"] == "opfs-sahpool"
            for digest_name in ("semanticDigest", "storageSampleDigest"):
                assert result[digest_name] == summary["validation"][digest_name]
        environment = summary["productionEnvironment"]
        assert environment["flags"] is None and environment["profiling"] is False
        assert environment["deviceMemory"] is None and environment["hardwareConcurrency"] == 4
        assert len(summary["termFileWork"]) == 1
        counters = summary["termFileWork"][0]["counters"]
        for key in ("parserFusedFallbacks", "parserDiscardedFusedRows", "dedupNativeFallbackCount"):
            assert counters[key] == 0
        assert counters["rows"] == 526942
        assert counters["parserSourceCompressedBytes"] == counters["parserSourceTransferredBytes"] == 15574114
        assert counters["parserSourceUncompressedBytes"] == 171092992
        assert counters.get("sourceInitialPrefetchFileCount", 0) == expected["expectedInitialPrefetchFileCount"]
        summaries.append((observation, summary))
    measured = {(o["block"], o["arm"]): o for o in cohort["observations"] if not o["warmup"]}
    statistics_by_arm = {}
    for arm in ("B", "C", "D"):
        baseline = [measured[(block, "A")]["totalImportMs"] for block in range(24)]
        candidate = [measured[(block, arm)]["totalImportMs"] for block in range(24)]
        changes = [(b / a - 1) * 100 for a, b in zip(baseline, candidate)]
        derived = {
            "medianPairedChangePercent": statistics.median(changes),
            "equalWorkChangePercent": (sum(candidate) / sum(baseline) - 1) * 100,
            "fasterPairs": sum(b < a for a, b in zip(baseline, candidate)),
            "worstPairPercent": max(changes),
        }
        for key, value in derived.items():
            assert math.isclose(value, cohort["statistics"][arm][key], abs_tol=1e-10)
        statistics_by_arm[arm] = {**derived, "pairs": 24,
            "descriptiveBootstrap95Percent": cohort["statistics"][arm]["descriptiveBootstrap95Percent"]}
    for key in ("semanticDigest", "storageSampleDigest"):
        assert len({s["validation"][key] for _, s in summaries}) == 1
    first = summaries[0][1]
    receipt = {
        "archive": str(args.archive.resolve()), "archiveSha256": archive_digest,
        "browser": cohort["browser"], "replication": cohort["replication"],
        "complete": True, "verifiedObservations": len(summaries),
        "warmups": sum(o["warmup"] for o in cohort["observations"]),
        "measured": len(measured), "distinctProfiles": len(profiles),
        "manifestSha256": cohort["manifestSha256"], "diagnosticCommit": preparation["diagnosticCommit"],
        "baselineControlPackageEntryParity": True,
        "packageEntryCount": len(package_entries["A"]),
        "sources": {a: {k: p[k] for k in ("commit", "tree", "packageSha256")} for a, p in preparation["arms"].items()},
        "runtime": runtime, "productionEnvironment": first["productionEnvironment"],
        "host": {k: first["hostBefore"][k] for k in ("cpuModel", "logicalCpuCount", "totalMemoryBytes")},
        "validation": first["validation"],
        "firstWarmup": {"label": cohort["observations"][0]["label"], "totalImportMs": first["totalImportMs"], "reload": first["reload"]},
        "largestParserWasmHeapBytes": sorted({s["largestParserWasmHeapBytes"] for _, s in summaries}),
        "statistics": statistics_by_arm,
        "qualification": "One complete cell; do not pool across hosts or subtract the same-source control. RSS snapshots are not peak-memory evidence."
    }
    destination = args.archive.with_suffix("")
    destination.mkdir(exist_ok=True)
    for name in ("cohort.json", "preparation.json", "manifest.json", "workflow.yml", "driver.py"):
        (destination / name).write_bytes(archive.read(name))
    (destination / "first-warmup-summary.json").write_text(json.dumps(first, indent=2) + "\n")
    output = destination / "independent-audit.json"
    output.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"audit": str(output.resolve()), "observations": len(summaries), "statistics": statistics_by_arm}, indent=2))
