#!/usr/bin/env python3
"""Independently verify the two fixed Chromium cells without pooling samples."""

import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[1] / "manabitan-browser"
HEAD = "a4a2ee2b29fce97f6e22c65f7e4bb497bec342ee"
ARCHIVE_HASHES = {
    "forward": "0cdfc9d2680bcb21fa38f13fe2a90f93ecd271ca372d077a22c2063c41130186",
    "reverse": "5632cd6eef0b471f17097f1b841710068c9f0d67453826a62c2395d4e55db88a",
}
PRODUCTS = {
    "A": "d829f5b6e6a75ee8859d38d537d224ec33c4930e",
    "B": "98b25cbce108b7c63ffe318f06186dadd26d476c",
    "C": "d829f5b6e6a75ee8859d38d537d224ec33c4930e",
    "D": "2ae43ece52ab621fa1af763bf65635f1bedc0fad",
}
SOURCE_HASHES = {}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def check_source(commit, filename, observed):
    key = (commit, filename)
    if key not in SOURCE_HASHES:
        SOURCE_HASHES[key] = sha256(subprocess.check_output(["git", "show", f"{commit}:{filename}"], cwd=REPOSITORY))
    assert observed == SOURCE_HASHES[key], (commit, filename)


def describe(values):
    return {"median": statistics.median(values), "mean": statistics.mean(values), "minimum": min(values), "maximum": max(values)}


def contrast(baseline, candidate):
    changes = [100 * (b / a - 1) for a, b in zip(baseline, candidate)]
    rng = random.Random(20261119)
    boot = sorted(statistics.median(rng.choices(changes, k=24)) for _ in range(10_000))
    return {"pairs": 24, "pairedChangesPercent": changes,
            "medianPairedChangePercent": statistics.median(changes),
            "equalWorkChangePercent": 100 * (sum(candidate) / sum(baseline) - 1),
            "fasterPairs": sum(b < a for a, b in zip(baseline, candidate)),
            "worstPairPercent": max(changes), "descriptiveBootstrap95Percent": [boot[250], boot[9749]]}


def analyze(replication):
    archive = ROOT / f"jmdict-study-chromium-{replication}-44633675935.zip"
    assert sha256(archive.read_bytes()) == ARCHIVE_HASHES[replication]
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        read = lambda name: json.loads(zipped.read(name))
        manifest = read("manifest.json")
        preparation = read("preparation.json")
        cohort = read("cohort.json")
        assert preparation["complete"] is True and cohort["complete"] is True
        assert cohort["failures"] == [] and preparation["diagnosticCommit"] == HEAD
        assert preparation["node"] == manifest["node"] == "v22.22.0"
        assert cohort["browser"] == preparation["browser"] == "chromium"
        assert cohort["replication"] == preparation["replication"] == replication
        assert cohort["dictionary"] == preparation["dictionary"] == manifest["dictionary"] == "jmdict"
        assert cohort["manifestSha256"] == preparation["manifestSha256"] == sha256(zipped.read("manifest.json"))
        assert sha256(zipped.read("driver.py")) == manifest["harnessSha256"]["dev/perf/jmdict-browser-study/run.py"]
        assert sha256(zipped.read("workflow.yml")) == manifest["harnessSha256"][manifest["workflow"]]
        entries = {arm: read(f"{arm}-package-entries.json") for arm in "ABCD"}
        assert entries["A"] == entries["C"]
        for arm in "ABCD":
            source = manifest["sources"][manifest["arms"][arm]]
            prepared = preparation["arms"][arm]
            assert source["commit"] == prepared["commit"] == PRODUCTS[arm]
            assert source["tree"] == prepared["tree"]
            assert prepared["buildTarget"] == "chrome"
            assert prepared["expectedInitialPrefetchFileCount"] == (1 if arm == "D" else 0)
            assert all(prepared["frozenFiles"][p] == h for p, h in manifest["sharedProductInputs"].items())
            assert prepared["commonGeneratedOverlay"]["ext/legal-npm.html"] == entries[arm]["legal-npm.html"]
            changed = sorted(p for p in entries["A"].keys() | entries[arm].keys() if entries["A"].get(p) != entries[arm].get(p))
            assert changed == sorted(p.removeprefix("ext/") for p in source["productPaths"])
        expected = []
        for warmup, order in enumerate(("ABCD", "DCBA")):
            for arm in order[::-1] if replication == "reverse" else order:
                expected.append({"label": f"warmup-{warmup + 1}-{arm}", "arm": arm, "warmup": True, "block": warmup})
        for block in range(24):
            order = ("ABCD", "BDAC", "CADB", "DCBA")[block % 4]
            for arm in order[::-1] if replication == "reverse" else order:
                expected.append({"label": f"block-{block + 1:02d}-{arm}", "arm": arm, "warmup": False, "block": block})
        assert expected == cohort["planned"] and len(cohort["observations"]) == 104
        fixture = preparation["fixture"]
        rows = {}
        versions, digests, experiments = set(), set(), set()
        host_profiles = set()
        phase_fields = ("sourceArchiveReadMs", "parserSourcePreparationMs", "parserSourceDeliveryMs", "parserParallelWorkerWallMs", "importerChunkSinkMs", "dedupRecentSourceCacheMs", "contentPackMs")
        phase_samples = {arm: {key: [] for key in phase_fields} for arm in "ABCD"}
        path_samples = {arm: {} for arm in "ABCD"}
        previous_command_end = 0
        for item, observation in zip(expected, cohort["observations"]):
            assert all(observation[k] == value for k, value in item.items()) and not observation.get("error")
            arm = observation["arm"]
            prepared = preparation["arms"][arm]
            command = read(observation["command"])
            assert command["complete"] is True and command["exitCode"] == 0 and not command.get("timedOut")
            assert command["startedAt"] >= previous_command_end
            previous_command_end = command["completedAt"]
            summary = read(observation["directory"] + "/summary.json")
            assert summary["schemaVersion"] == 3 and summary["dictionary"] == "jmdict" and summary["buildTarget"] == "chrome"
            assert summary["authoritativeTiming"] is True and summary["traceEnabled"] is False and summary["importFlags"] is None
            assert summary["gitSha"] == summary["source"]["gitSha"] == PRODUCTS[arm]
            assert summary["fixture"] == fixture and len(summary["runs"]) == 1
            for filename, value in summary["source"]["sha256"].items():
                if filename.startswith("builds/"):
                    if filename.endswith("manabitan-chrome.zip"):
                        assert value == prepared["packageSha256"]
                else:
                    check_source(PRODUCTS[arm], filename, value)
            run = summary["runs"][0]
            assert run["tracePath"] is None and run["packageSha256"] == prepared["packageSha256"]
            report = read(observation["directory"] + "/" + Path(run["reportJsonPath"]).name)
            assert report["status"] == "success" and report["skippedVerification"] is False
            assert report["packageSha256"] == prepared["packageSha256"] and report["buildTarget"] == "chrome"
            benchmark = report["benchmark"]
            for flag, value in {"dictionary": "jmdict", "pinnedDictionaries": True, "productionImportDefaults": True,
                                "traceEnabled": False, "authoritativeTiming": True, "phaseProfiling": False,
                                "phaseScreenshots": False, "processSampling": False, "importFlags": None}.items():
                assert benchmark[flag] == value
            phases = [p for p in report["phases"] if (p.get("data") or {}).get("kind") == "dictionary-import"]
            assert len(phases) == 1
            timing = phases[0]["data"]["browserTiming"]
            assert timing["trigger"] == "file-input-change" and timing["sequence"] > timing["sequenceBefore"] and timing["errorCount"] == 0
            elapsed = timing["completedAtMs"] - timing["startedAtMs"]
            assert math.isfinite(elapsed) and elapsed > 0 and elapsed == run["totalImportMs"] == observation["totalImportMs"]
            validation = run["validation"]
            assert validation == observation["validation"] == benchmark["validation"]
            for tested in (validation, validation["restart"]):
                assert tested["title"] == fixture["expectedTitle"] and tested["revision"] == fixture["revision"]
                assert tested["termRows"] == fixture["termRows"] == 526942 and tested["probeCount"] == 12 and tested["contentReadable"] is True
            digests.add(validation["outputDigestSha256"])
            versions.add(summary["browserVersion"])
            debug = run["importDebug"]
            assert debug == observation["importDebug"] == phases[0]["data"]["importDebug"]
            assert debug["hasResult"] is True and debug["resultTitle"] == fixture["expectedTitle"]
            assert debug["errorCount"] == debug["addSettingsErrorCount"] == 0
            assert debug["usesFallbackStorage"] is False and debug["openStorageDiagnostics"]["mode"] == "opfs-sahpool"
            terms = [p for p in debug["importerPhaseTimings"] if p["phase"].startswith("term-file")]
            assert len(terms) == 1 and terms[0]["phase"].startswith("term-file-fast-path:")
            details = terms[0]["details"]
            for field, value in {"rows": 526942, "parserSourceCompressedBytes": 15574114,
                                 "parserSourceTransferredBytes": 15574114, "parserSourceUncompressedBytes": 171092992,
                                 "parserFusedFallbacks": 0, "parserDiscardedFusedRows": 0, "dedupNativeFallbackCount": 0,
                                 "sourceInitialPrefetchFileCount": 1 if arm == "D" else 0,
                                 "sourceInitialPrefetchEstimatedBytes": 3226520 if arm == "D" else 0}.items():
                assert details[field] == value
            finalization = [p["details"] for p in debug["importerPhaseTimings"] if p["phase"] == "bulk-finalization"]
            assert len(finalization) == 1 and finalization[0]["ok"] is True and finalization[0]["published"] is True and finalization[0]["housekeepingErrors"] == []
            experiments.add(json.dumps(details["parserExperiments"], sort_keys=True))
            environment = summary["hostEnvironment"]
            host_profiles.add(json.dumps({k: environment[k] for k in ("nodeVersion", "platform", "cpuModel", "logicalCpuCount", "availableParallelism", "cgroupCpuMax", "cgroupMemoryMaxBytes")}, sort_keys=True))
            if not observation["warmup"]:
                rows[(observation["block"], arm)] = elapsed
                for field in phase_fields:
                    phase_samples[arm][field].append(details[field])
                for field in ("parserParallelWorkerCount", "parserParallelGroupCount", "parserFusedAttempts", "dedupNativeCallCount", "parserMaxWasmHeapBytes", "sourcePrefetchMaxBytes", "dedupNativeExactCandidates", "dedupRecentSourceHitCount", "dedupRecentSourceCacheBytes"):
                    path_samples[arm].setdefault(field, set()).add(details[field])
        assert len(versions) == len(digests) == len(experiments) == len(host_profiles) == 1
        totals = {arm: [rows[(block, arm)] for block in range(24)] for arm in "ABCD"}
        comparisons = {arm + "/A": contrast(totals["A"], totals[arm]) for arm in "CBD"}
        for arm in "CBD":
            observed = cohort["statistics"][arm]
            for key, value in comparisons[arm + "/A"].items():
                if isinstance(value, list):
                    assert len(value) == len(observed[key]) and all(math.isclose(a, b, rel_tol=0, abs_tol=1e-10) for a, b in zip(value, observed[key]))
                else:
                    assert math.isclose(value, observed[key], rel_tol=0, abs_tol=1e-10)
        extracted = ROOT / f"chromium-{replication}-evidence"
        extracted.mkdir(exist_ok=True)
        for name in ("cohort.json", "preparation.json", "manifest.json", "driver.py", "workflow.yml", *(f"{arm}-package-entries.json" for arm in "ABCD")):
            target = extracted / name
            data = zipped.read(name)
            if target.exists():
                assert target.read_bytes() == data, f"Changed preserved evidence: {target}"
            else:
                with target.open("xb") as stream:
                    stream.write(data)
        result = {"replication": replication, "browser": "chromium", "complete": True,
                  "sourceRun": 44633675935, "diagnosticCommit": HEAD, "archive": archive.name,
                  "archiveSha256": ARCHIVE_HASHES[replication], "observations": 104, "excludedWarmups": 8, "timedObservations": 96,
                  "validation": "All raw command, summary and browser reports verified; no observations dropped; independent statistics equal driver output",
                  "contentDigest": next(iter(digests)), "browserVersion": next(iter(versions)),
                  "browserRuntime": preparation["browserRuntime"], "hostEnvironment": json.loads(next(iter(host_profiles))),
                  "products": PRODUCTS, "armTimesMs": {arm: describe(values) for arm, values in totals.items()},
                  "comparisons": comparisons,
                  "pathReceipts": {arm: {field: sorted(values) for field, values in metrics.items()} for arm, metrics in path_samples.items()},
                  "diagnosticPhaseMediansMs": {arm: {field: statistics.median(values) for field, values in metrics.items()} for arm, metrics in phase_samples.items()},
                  "interpretation": "Each cell remains separate. C/A is a same-source control; do not subtract it. Phase durations overlap and are not summed. No peak-memory evidence."}
        analysis_path = ROOT / f"chromium-{replication}-independent-analysis.json"
        analysis_text = json.dumps(result, indent=2, allow_nan=False) + "\n"
        if analysis_path.exists():
            assert analysis_path.read_text() == analysis_text, f"Changed reproduced analysis: {analysis_path}"
        else:
            with analysis_path.open("x") as stream:
                stream.write(analysis_text)
        print(json.dumps({"replication": replication, "allChecksPassed": True,
                          "armTimesMs": result["armTimesMs"], "hostEnvironment": result["hostEnvironment"],
                          "comparisons": {arm: {k: v for k, v in values.items() if k != "pairedChangesPercent"} for arm, values in comparisons.items()}}))


for cell in ("forward", "reverse"):
    analyze(cell)
