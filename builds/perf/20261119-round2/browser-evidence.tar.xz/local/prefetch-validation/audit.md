# Compressed-source prefetch audit — 2026-11-19

## Candidate and boundary

Frozen candidate: `2ae43ece52ab621fa1af763bf65635f1bedc0fad`, tree `7f19cf482e7472ae5e06f499b122b222a66bfe9d`, based directly on `d829f5b6e6a75ee8859d38d537d224ec33c4930e`.

The importer already starts ordinary decoded-source prefetch before bulk-import setup. An admitted compressed-source plan skips that prefetch, leaving its first archive materialization until parser workers claim sources. Bulk setup performs asynchronous checkpoints, journal publication, and content/record import-session initialization before the source loop. The candidate starts only the first compressed read in the existing identity-keyed pool before that setup. Later loading reuses the same owned payload; native inflation, CRC, exact size/consumption checks, parser validation, worker count, grouping and storage remain unchanged.

This is an overlap hypothesis. No timing result has been collected for this candidate. Source-read phase timers begin after the new first read, so reduced source-read phase values alone cannot establish a speedup. Use the full browser import completion boundary for the decision.

## Admission and memory

The new prefetch requires an already-admitted compressed format-3 plan, raw-byte storage, deduplication, available workers, and no media work. Media detection and parser prewarming remain in their original locations. The no-media guard prevents a speculative archive cache from changing eligibility for later cached media batching.

The existing 24 MiB / 96 MiB prefetch budget covers `new Blob archive materialization + max(first compressed size, first decoded size)`. An existing ArrayBuffer is already owned and charges only the source estimate. Unknown/invalid/zero decoded metadata and over-budget cases decline prefetch. Large Blob archives therefore keep their current lazy ranged-read behavior. Exactly one source identity is prefetched; no larger lead window is introduced.

Locked JMdict has 53 term banks and a 15,587,032-byte archive. The first bank is 232,201 compressed bytes and 3,226,520 decoded bytes. Its conservative prefetch charge is 18,813,552 bytes, below both existing budgets. The actual new payload is the compressed copy; this stage does not allocate the decoded bank. Prefetch moves allocation earlier and can retain one bounded unused read if subsequent startup fails or parsing declines. No peak-memory improvement is claimed.

## Ownership and errors

The import session owns the source pipeline and archive before the new read starts. Cancellation is checked before the call. The pool publishes read ownership before invoking the reader, and speculative rejection is observed without replacing the cached failure. The later loader still verifies compressed length and feeds ordinary metadata/CRC validation. Failure cleanup aborts and joins every owned pending read before archive closure and rollback. Parser startup's existing rule against activating its lazy loaders before worker readiness remains unchanged.

Independent read-only review by storage_audit found no blocking issue after the media-scope refinement. New tests exercise reuse, original rejection (including undefined), exact and exceeded byte caps, disabled/unavailable/invalid input, media/version/storage/dedup/worker guards, and startup failure/cancellation with deliberately delayed read settlement.

## Alternatives audited

- Returning a view from the cached archive does not remove the required payload copy today: worker dispatch copies non-whole-buffer views before transfer. Transferring the whole archive would detach storage needed by later sources; sharing it would require a broader ownership/protocol change.
- Multi-bank inflation already writes into parser-owned memory and preserves bank spans, avoiding the old interior-join copy. The full-buffer inflater and braided CRC path are already present.
- [Merged PR #664](https://github.com/ManabiIO/manabitan/pull/664) already covers immutable CRC setup reuse, 64-bit inflater words, and a validated object-colon fast path. Repeating those changes would duplicate shipped work.
- [PR #352](https://github.com/ManabiIO/manabitan/pull/352) concerns coalesced large-archive header reads. It is separate from the ordinary 15.6 MB JMdict archive path and was not revived here.
- Live PRs [#758](https://github.com/ManabiIO/manabitan/pull/758), [#759](https://github.com/ManabiIO/manabitan/pull/759), and [#764](https://github.com/ManabiIO/manabitan/pull/764) already cover recent-source copy/publication/preflight/final-copy work. No part of those candidates is included.

## Validation and next gate

Before freeze: 155 tests in eight focused files passed, including 28 new cases; scoped ESLint, main TypeScript, the package-required test/jsconfig.typecheck.json TypeScript project, and all seven dry-build targets passed. All five bundled WASM files equal baseline byte-for-byte. Full unit validation completed at 22:58:43 UTC with 617 files and 13,694 tests passed, 47 skipped, exit 0. The frozen commit/tree, all three source hashes, and all five baseline-equal WASM artifacts were checked again after the suite. See validation-summary.json and full-unit.command.json for the exact command and environment. Earlier incorrect editor-project TypeScript commands and the corrected test annotation are retained in the validation receipts.

Browser qualification should retain fixed opposite execution orders and identical-code controls, keep source/artifact/fixture identities pinned, and require identical row/content/persistence results. JMdict and JMnedict should report first-source prefetch count one; normal media-enabled Jitendex should remain zero. Compare complete imports, preserve tails, and inspect memory separately from timing.
