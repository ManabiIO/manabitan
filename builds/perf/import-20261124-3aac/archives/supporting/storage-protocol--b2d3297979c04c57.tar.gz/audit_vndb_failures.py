# SPDX-License-Identifier: GPL-3.0-or-later
"""Reconcile every retained observation in the three originally failed cells.

This script never changes their failure status or computes partial-cohort gains.
It reads existing evidence only; no acquisition or import is performed.
"""

import hashlib
import json
from pathlib import Path
import sys

from storage_receipts import normalize_storage_receipt


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def audit(artifacts):
    cells = []
    common_semantics = None
    common_non_sah = None
    for label in ('prefix', 'media', 'cache'):
        root = artifacts / f'import-{label}-screen-vndb-forward-45465463257-1'
        cohort = root / 'cohort'
        plan = load(cohort / 'protocol.json')
        state = load(cohort / 'state.json')
        observations = load(cohort / 'observations.json')
        assert state['status'] == 'failed'
        assert state['error'] == 'Correctness receipt differs across arms/observations: storageBytes'
        assert plan['stage'] == 'screen' and plan['dictionary'] == 'vndb'
        assert plan['plannedBlocks'] == 6 and plan['harnessOverlay'] is None
        packages = {arm: load(cohort / f'package-{arm}.json') for arm in 'ABC'}
        assert packages['C']['identicalArchiveFromArm'] == 'A'
        assert all(packages['A'][key] == packages['C'][key] for key in ('archiveSha256', 'entries', 'source'))
        expected_names = [f'warmup-{arm}' for arm in 'ABC']
        expected_names += [f'block-{block:02d}-{position}-{arm}'
                           for block, order in enumerate(plan['orders'], 1)
                           for position, arm in enumerate(order, 1)]
        assert [row['name'] for row in observations] == expected_names[:len(observations)]
        assert all(row['status'] == 'success' for row in observations[:-1])
        assert observations[-1]['status'] == 'failed'
        records = []
        by_arm = {arm: [] for arm in 'ABC'}
        for row in observations:
            location = cohort / row['name']
            summary = load(location / 'summary.json')
            native = load(location / 'run-1.json')
            assert native['status'] == 'success' and native['failureReason'] == ''
            assert len(summary['runs']) == 1 and summary['fixture'] == plan['fixture']
            assert summary['source']['dirty'] is False
            assert summary['gitSha'] == summary['source']['gitSha'] == row['source']['commit']
            run = summary['runs'][0]
            assert run['packageSha256'] == packages[row['arm']]['archiveSha256']
            v = run['validation']
            assert v['termRows'] == 6648310 and v['contentReadable'] is True
            assert v['restart'] == {'title': plan['fixture']['expectedTitle'], 'revision': plan['fixture']['revision'],
                                     'termRows': 6648310, 'mediaFiles': 146570, 'contentReadable': True, 'probeCount': 12}
            terms = v['probeTerms']
            lookups = v['lookup']['observations']
            assert len(terms) == len(set(terms)) == 12 and len(lookups) == 72
            assert {(r['pass'], r['term']) for r in lookups} == {(number, term) for number in range(6) for term in terms}
            assert all(r['results'] > 0 and r['hasExactHeadwordMatch'] is True for r in lookups)
            assert v['media']['mode'] == 'sample' and v['media']['files'] == 64
            assert v['media']['totalFiles'] == 146570 and v['media']['totalBytes'] == 188131284
            semantics = {'lookup': sorted([r['pass'], r['term'], r['results'], r['sha256']] for r in lookups),
                         'media': v['media'], 'restart': v['restart'], 'outputDigestSha256': v['outputDigestSha256']}
            if common_semantics is None:
                common_semantics = semantics
            assert semantics == common_semantics
            storage = normalize_storage_receipt(v['storage'], 'vndb')
            if common_non_sah is None:
                common_non_sah = storage['nonSahFiles']
            assert storage['nonSahFiles'] == common_non_sah
            by_arm[row['arm']].append(storage['sahPool']['activeFileBytes'])
            records.append({'name': row['name'], 'arm': row['arm'], 'cohort': row['cohort'],
                            'originalStudyStatus': row['status'], 'nativeStatus': native['status'],
                            'rawTotalBytes': storage['rawStorageBytes'], 'sahPool': storage['sahPool'],
                            'rawFiles': storage['rawFiles'], 'totalImportMsRetainedNotAnalyzed': run['totalImportMs'],
                            'summarySha256': digest(location / 'summary.json'),
                            'nativeReportSha256': digest(location / 'run-1.json'),
                            'commandLogSha256': digest(location / 'command.log')})
        cells.append({'label': label, 'artifact': root.name, 'originalState': state,
                      'sourceIdentities': plan['sourceIdentities'], 'originalCohortComplete': False,
                      'acquiredObservations': len(records), 'plannedTimedObservations': 18,
                      'timedObservationsAttempted': sum(r['cohort'] == 'timed' for r in records),
                      'fullMediaDiagnosticsAcquired': False, 'activeSahBytesByArm': by_arm,
                      'records': records, 'stateSha256': digest(cohort / 'state.json'),
                      'protocolSha256': digest(cohort / 'protocol.json'),
                      'runnerSha256': digest(root / 'runner.py')})
    return {'schemaVersion': 1, 'workflowRun': '45465463257', 'scope': 'Read-only failure reconciliation, not promotion or timing analysis',
            'originalCohortsRemainFailed': True, 'observationCount': sum(c['acquiredObservations'] for c in cells),
            'allNativeImportsSucceeded': True, 'sampledSemanticReceiptsEqual': True,
            'fullPersistedByteEqualityProved': False, 'nonSahFiles': common_non_sah,
            'observedRawTotals': sorted({r['rawTotalBytes'] for c in cells for r in c['records']}),
            'observedActiveSahBytes': sorted({r['sahPool']['activeFileBytes'] for c in cells for r in c['records']}),
            'semanticReceipt': common_semantics, 'cells': cells}


if __name__ == '__main__':
    result = audit(Path(sys.argv[1]))
    Path(sys.argv[2]).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('cells', 'semanticReceipt', 'nonSahFiles')}))
