import {afterEach, expect, test, vi} from 'vitest';
import {DictionaryImporter} from '../ext/js/dictionary/dictionary-importer.js';

afterEach(() => {
    Reflect.deleteProperty(globalThis, '__manabitanActivationEvents');
    vi.restoreAllMocks();
    vi.unstubAllGlobals();
});

test('the production offscreen owner transports activation events through its completion port', async () => {
    vi.stubGlobal('self', {addEventListener: vi.fn(), postMessage: vi.fn()});
    const {OffscreenDictionaryWorkerHandler} = await import('../ext/js/background/offscreen-dictionary-worker.js');
    const worker = new OffscreenDictionaryWorkerHandler();
    Reflect.set(worker, '_dictionaryDatabase', {usesFallbackStorage: () => false, getOpenStorageDiagnostics: () => null});
    Reflect.set(worker, '_translator', {clearDatabaseCaches: vi.fn()});
    Reflect.set(worker, '_ensureDatabasePrepared', vi.fn().mockResolvedValue(undefined));
    Reflect.set(globalThis, '__manabitanActivationEvents', [{event: 'stale'}]);
    const witness = {event: 'offscreen-transport-witness', count: 7};
    const importDictionary = vi.spyOn(DictionaryImporter.prototype, 'importDictionary').mockImplementation(async () => {
        const events = Reflect.get(globalThis, '__manabitanActivationEvents');
        expect(events).toEqual([]);
        events.push(witness);
        return {result: {title: 'Fixture'}, errors: [], debug: {phaseTimings: []}};
    });
    const messages = [];
    const port = {postMessage: (message) => messages.push(structuredClone(message)), close: vi.fn()};
    worker._onMessage({
        data: {id: 1, action: 'importDictionaryOffscreen', params: {operationId: `${Date.now()}:activation-witness`, archiveContent: new Blob(['fixture']), details: {}}},
        ports: [port],
    });
    await Reflect.get(worker, '_requestQueue');
    expect(importDictionary).toHaveBeenCalledOnce();
    const completion = messages.find((message) => message.type === 'complete');
    expect(completion).toBeDefined();
    const phase = completion.result.debug.importerDebug.phaseTimings[0];
    expect(phase).toMatchObject({phase: 'activation-diagnostic', elapsedMs: 0, details: {instrumentationOnly: true, owner: 'offscreen', events: [witness]}});
    expect(Reflect.has(globalThis, '__manabitanActivationEvents')).toBe(false);
    expect(port.close).toHaveBeenCalledOnce();
});
