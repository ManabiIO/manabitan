import collections
import hashlib
import json
from pathlib import Path

root = Path('/workspace/scratch/3aacd533c01f/round2')
artifact = root / 'artifacts/import-critical-path-3aac-vndb-45458569610-1'
trace_path = artifact / 'trace/run-1.trace.json'
trace_bytes = trace_path.read_bytes()
events = json.loads(trace_bytes)['traceEvents']
profiles = collections.defaultdict(lambda: {'nodes': {}, 'chunks': []})
for event in events:
    if event.get('name') != 'ProfileChunk':
        continue
    profile = profiles[(event['pid'], event['id'])]
    data = event['args']['data']
    for node in data.get('cpuProfile', {}).get('nodes', []):
        prior = profile['nodes'].get(node['id'])
        assert prior is None or prior == node
        profile['nodes'][node['id']] = node
    profile['chunks'].append(data)

source = (root / 'baseline/ext/js/dictionary/term-bank-wasm-parser.js').read_text().splitlines()
callback_line = next(i for i, line in enumerate(source) if 'const mediaRows = chunk.mediaRows.map' in line)
report = {
    'schema': 1,
    'sourceCommit': '698d685c21618a8e8dbdab7a49a8dcf0d30680eb',
    'traceSha256': hashlib.sha256(trace_bytes).hexdigest(),
    'scope': 'Diagnostic weighted V8 sampling across parser workers. Sum of sample timeDeltas, not measured CPU consumption or complete-import elapsed savings. All samples within copyWasmBackedColumnChunk are retained; native and JS stacks may be affected by sampling and scheduling.',
    'parserSourceSha256': hashlib.sha256((root / 'baseline/ext/js/dictionary/term-bank-wasm-parser.js').read_bytes()).hexdigest(),
    'profiles': [],
}
self_functions = collections.Counter()
self_function_samples = collections.Counter()
self_lines = collections.Counter()
inclusive_copy_us = 0
inclusive_collector_us = 0
for key, profile in profiles.items():
    nodes = profile['nodes']
    if not any(node['callFrame'].get('functionName') == 'copyWasmBackedColumnChunk' for node in nodes.values()):
        continue
    summary = {'pid': key[0], 'profileId': key[1], 'copyWeightedSampleUs': 0, 'collectorWeightedSampleUs': 0, 'copySamples': 0,
               'negativeDeltaCount': 0, 'negativeDeltaUs': 0, 'negativeCopyDeltaCount': 0, 'negativeCopyDeltaUs': 0}
    for data in profile['chunks']:
        samples = data.get('cpuProfile', {}).get('samples', [])
        deltas = data.get('timeDeltas', [])
        lines = data.get('lines', [])
        assert len(samples) == len(deltas)
        for index, (sample, delta) in enumerate(zip(samples, deltas)):
            if delta < 0:
                summary['negativeDeltaCount'] += 1
                summary['negativeDeltaUs'] += delta
            chain = []
            node = nodes.get(sample)
            while node is not None:
                chain.append(node)
                node = nodes.get(node.get('parent'))
            names = {node['callFrame'].get('functionName', '') for node in chain}
            if 'copyWasmBackedColumnChunk' not in names:
                continue
            inclusive_copy_us += delta
            if delta < 0:
                summary['negativeCopyDeltaCount'] += 1
                summary['negativeCopyDeltaUs'] += delta
            summary['copyWeightedSampleUs'] += delta
            summary['copySamples'] += 1
            if 'tryCollectGlossaryImagePaths' in names:
                inclusive_collector_us += delta
                summary['collectorWeightedSampleUs'] += delta
            frame = chain[0]['callFrame']
            self_functions[frame.get('functionName', '')] += delta
            self_function_samples[frame.get('functionName', '')] += 1
            if frame.get('url', '').endswith('/term-bank-wasm-parser.js') and frame.get('lineNumber') == callback_line and index < len(lines):
                self_lines[lines[index]] += delta
    report['profiles'].append(summary)

report['copyWeightedSampleMs'] = inclusive_copy_us / 1000
report['collectorWeightedSampleMs'] = inclusive_collector_us / 1000
report['selfFunctionWeightedSampleMs'] = {name: value / 1000 for name, value in self_functions.most_common()}
report['selfFunctionSamples'] = dict(self_function_samples.most_common())
report['clockQualification'] = 'Chrome recorded negative timeDeltas. Signed weights above retain them exactly; copyPositiveWeightOnlyMs is a sensitivity calculation, not replacement evidence. Counts and both sums are descriptive sampling diagnostics, not exact CPU time.'
report['copyPositiveWeightOnlyMs'] = report['copyWeightedSampleMs'] - sum(profile['negativeCopyDeltaUs'] for profile in report['profiles']) / 1000
report['mediaCallbackSelfLines'] = [{'line': line, 'weightedSampleMs': value / 1000, 'source': source[line - 1].strip()} for line, value in self_lines.most_common()]
report['ordinaryPhases'] = {}
ordinary = json.loads((artifact / 'ordinary/run-1.json').read_text())
phase = next(value for value in ordinary['phases'] if value['name'] == 'VNDB: total import')
timing = phase['data']['browserTiming']
report['ordinaryObservedImportMs'] = timing['completedAtMs'] - timing['startedAtMs']
for value in phase['data']['importDebug']['importerPhaseTimings']:
    report['ordinaryPhases'][value['phase']] = {'elapsedMs': value['elapsedMs'], 'details': value['details']}
output = root / 'vndb-audit/media-projection-trace-attribution.json'
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({key: report[key] for key in ['copyWeightedSampleMs', 'collectorWeightedSampleMs', 'selfFunctionWeightedSampleMs', 'mediaCallbackSelfLines', 'ordinaryObservedImportMs']}, indent=2))
