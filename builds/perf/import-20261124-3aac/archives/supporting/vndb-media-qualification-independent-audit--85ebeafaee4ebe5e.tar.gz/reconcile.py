#!/usr/bin/env python3
"""Independently reconcile two retained frozen VNDB qualification hosts; no acquisition."""

import hashlib
import json
import math
from pathlib import Path
import random
import re
import statistics
import subprocess

ROOT = Path('/workspace/scratch/3aacd533c01f/round2')
REPO = ROOT / 'baseline'
OUT = Path(__file__).parent
RUN_ID = '45475087387'
TOOLING = '2fb6c247852c64be1b836aff60b3eba5eb1acc7e'
SOURCES = {
    'A': {'commit': 'bbccabd520972cc351a65d9f545bd5369b6e9747', 'tree': 'f81fc2c29b58f1c2329de6b8fa6b2a91015b6b07'},
    'media': {'commit': 'fb71a03f4611bcfa71e135693bebd1fe778153bf', 'tree': '0939bd1eec85dc0b3f15ef002a8f0f5111c80103'},
    'prefix': {'commit': 'ebb1da8d2cc2b28901400968891b632605f1b3f0', 'tree': '243ab638da9cb73e08d84609c41dcdfdf08475cd'},
}
EXPECTED_DIFFS = {
    'media': ['js/dictionary/term-bank-wasm-parser-worker.js', 'js/dictionary/term-bank-wasm-parser.js', 'js/dictionary/wasm/term-bank-parser.c', 'lib/term-bank-parser.wasm'],
    'prefix': ['js/dictionary/term-content-block-store.js', 'js/dictionary/term-content-opfs-store.js', 'js/dictionary/term-content-ownership.js', 'js/dictionary/zstd-term-content.js', 'lib/zstd-wasm.js', 'lib/zstd-wasm.js.map'],
}
NON_SAH = {
    'manabitan-dictionary-media-v1/{generation}.bin': 199563210,
    'manabitan-term-content.bin': 7533449,
    'manabitan-term-records/dict-28|VNDB%20Characters%20by%20Beeraw-block-v2.mbtr': 38,
    'manabitan-term-records/dict-28|VNDB%20Characters%20by%20Beeraw-block-v2.mbtr.mbti': 399513708,
    'manabitan-term-records/dict-28|VNDB%20Characters%20by%20Beeraw-v6.mbtr': 26,
    'manabitan-term-records/dict-28|VNDB%20Characters%20by%20Beeraw-v6.mbtr.mbti': 2386124,
}
ORDERS = ['ABC', 'CBA', 'BAC', 'CAB', 'BCA', 'ACB', 'ACB', 'BCA', 'CAB', 'BAC', 'CBA', 'ABC']
POLICY = 'pinned-import-storage-20261124-v1'


def read(path):
    return json.loads(path.read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


BLOBS = {}
def blob(tree, name):
    key = (tree, name)
    if key not in BLOBS:
        BLOBS[key] = subprocess.check_output(['git', '-C', str(REPO), 'show', f'{tree}:{name}'])
    return BLOBS[key]


def compare(a, b):
    changes = [(y / x - 1) * 100 for x, y in zip(a, b, strict=True)]
    rng = random.Random(20261124)
    medians = sorted(statistics.median(rng.choices(changes, k=len(changes))) for _ in range(10000))
    return {
        'pairs': len(changes), 'fasterPairs': sum(x < 0 for x in changes), 'bestPairPercent': min(changes),
        'worstPairPercent': max(changes), 'pairedChangesPercent': changes,
        'pairedMedianPercent': statistics.median(changes), 'pairedMedianBootstrap95Percent': [medians[249], medians[9749]],
        'equalWorkPercent': (sum(b) / sum(a) - 1) * 100,
        'baselineMedianMs': statistics.median(a), 'candidateMedianMs': statistics.median(b),
    }


def storage_check(raw, receipt):
    files = raw['files']
    assert len(files) == 14 and len({x['path'] for x in files}) == 14
    assert all(type(x['bytes']) is int and x['bytes'] >= 0 for x in files)
    assert raw['bytes'] == sum(x['bytes'] for x in files) == receipt['rawStorageBytes']
    assert receipt['rawFiles'] == files
    non_sah, sah = {}, []
    for item in files:
        path = item['path']
        if re.fullmatch(r'manabitan/sqlite-sahpool-v1/\.opaque/[^/]+', path):
            sah.append(item['bytes'])
        else:
            if re.fullmatch(r'manabitan-dictionary-media-v1/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.bin', path):
                path = 'manabitan-dictionary-media-v1/{generation}.bin'
            assert path not in non_sah
            non_sah[path] = item['bytes']
    assert non_sah == NON_SAH
    sah.sort()
    assert len(sah) == 8 and sah[:7] == [4096] * 7
    assert sah[7] % 4096 == 0 and 129 <= sah[7] // 4096 <= 131
    assert receipt['policyVersion'] == POLICY and receipt['dictionary'] == 'vndb'
    assert receipt['nonSahBytes'] == sum(NON_SAH.values()) == 608996555
    assert receipt['nonSahFiles'] == [{'path': p, 'bytes': b} for p, b in sorted(NON_SAH.items())]
    expected_pool = {'activeAllocationUnits': sah[7] // 4096, 'activeFileBytes': sah[7], 'allocationUnitBytes': 4096, 'emptyFileBytes': 4096, 'emptyFileCount': 7, 'fileCount': 8, 'sortedFileBytes': sah, 'totalBytes': sum(sah)}
    assert receipt['sahPool'] == expected_pool
    return sah[7]


lock = json.loads(blob(SOURCES['A']['tree'], 'test/perf/dictionaries.lock.json'))['dictionaries']
fixture = lock['vndb']
results = []
cross_cell_lookup = cross_cell_media = cross_cell_probe = None
for direction in ['forward', 'reverse']:
    lane = 'media'
    orders = ORDERS if direction == 'forward' else [order[::-1] for order in reversed(ORDERS)]
    base = ROOT / f'artifacts/import-media-qualification-storage-v1-vndb-{direction}-{RUN_ID}-1'
    cohort = base / 'cohort'
    protocol, observations, analysis = [read(cohort / p) for p in ['protocol.json', 'observations.json', 'analysis.json']]
    identities = {'A': SOURCES['A'], 'B': SOURCES[lane], 'C': SOURCES['A']}
    assert protocol['sourceIdentities'] == identities
    assert protocol['toolingCommit'] == protocol['github']['GITHUB_SHA'] == TOOLING
    assert protocol['github']['GITHUB_RUN_ID'] == RUN_ID and protocol['github']['GITHUB_RUN_ATTEMPT'] == '1'
    assert protocol['stage'] == 'qualification' and protocol['dictionary'] == 'vndb'
    assert protocol['plannedBlocks'] == 12 and protocol['orders'] == orders and protocol['reversedSchedule'] is (direction == 'reverse')
    assert protocol['warmupsExcluded'] == 3 and protocol['harnessOverlay'] is None
    assert protocol['diagnosticArms'] == ['A', 'B'] and protocol['nodeVersion'] == 'v22.22.0'
    assert protocol['fixture'] == fixture and protocol['storagePolicyVersion'] == POLICY
    runner = (base / 'runner.py').read_bytes()
    assert sha(runner) == protocol['runnerSha256']
    assert runner == blob(TOOLING, 'dev/perf/import-runtime-20261124-3aac.py')
    assert (base / 'workflow.yml').read_bytes() == blob(TOOLING, '.github/workflows/import-studies-20261124-3aac.yml')
    for path, expected in protocol['storagePolicySha256'].items():
        assert sha((base / 'storage-policy' / path).read_bytes()) == expected
        assert sha(blob(TOOLING, f'dev/perf/import-storage-20261124-3aac/{path}')) == expected
    for path, digest in protocol['unchangedHarnessSha256'].items():
        assert sha(blob(SOURCES['A']['tree'], path)) == digest
        assert sha(blob(SOURCES[lane]['tree'], path)) == digest
        assert sha(blob(TOOLING, path)) == digest
    packages = {arm: read(cohort / f'package-{arm}.json') for arm in 'ABC'}
    for arm, package in packages.items():
        assert package['source'] == identities[arm]
        assert len(package['entries']) == 550
    assert packages['C']['identicalArchiveFromArm'] == 'A'
    assert packages['C']['archiveSha256'] == packages['A']['archiveSha256']
    assert packages['C']['entries'] == packages['A']['entries']
    different = sorted(x for x in set(packages['A']['entries']) | set(packages['B']['entries']) if packages['A']['entries'].get(x) != packages['B']['entries'].get(x))
    assert different == EXPECTED_DIFFS[lane] == protocol['expectedPackageDifferences'] == read(cohort / 'package-differences.json')
    for arm in 'AB':
        assert (cohort / f'source-status-{arm}.txt').read_text().strip() == ''
    assert read(cohort / 'fixture.json') == {'sizeBytes': fixture['sizeBytes'], 'sha256': fixture['sha256'], 'fixture': fixture}
    setup = read(cohort / 'setup-fixtures.json')
    assert set(setup) == set(protocol['setupCacheDictionaryIds']) == {'jmdict', 'jmnedict', 'jitendex', 'vndb'}
    for dictionary, receipt in setup.items():
        assert receipt == {'sizeBytes': lock[dictionary]['sizeBytes'], 'sha256': lock[dictionary]['sha256'], 'fixture': lock[dictionary]}
    names = [('warmup-' + arm, arm, 'excluded-warmup', None, None) for arm in ('ABC' if direction == 'forward' else 'CBA')]
    names += [(f'block-{i:02d}-{j}-{arm}', arm, 'timed', i, j) for i, order in enumerate(orders, 1) for j, arm in enumerate(order, 1)]
    names += [(f'diagnostic-{arm}', arm, 'exhaustive-diagnostic', None, None) for arm in 'AB']
    assert len(observations) == len(names) == 41
    assert sorted(p.parent.name for p in cohort.glob('*/run-1.json')) == sorted(x[0] for x in names)
    timings = {arm: [] for arm in 'ABC'}
    expected_lookup = expected_probe = None
    expected_media = {}
    storage_observations = []
    report_hashes = {}
    for entry, scheduled in zip(observations, names, strict=True):
        name, arm, kind, block, position = scheduled
        assert [entry[k] for k in ['name', 'arm', 'cohort', 'block', 'position']] == list(scheduled)
        assert entry['source'] == identities[arm] and entry['status'] == 'success'
        media_mode = 'all' if kind == 'exhaustive-diagnostic' else 'sample'
        assert entry['mediaCheck'] == media_mode
        folder = cohort / name
        raw_bytes = (folder / 'run-1.json').read_bytes()
        raw, summary = json.loads(raw_bytes), read(folder / 'summary.json')
        report_hashes[name] = sha(raw_bytes)
        assert raw['status'] == 'success' and raw['skippedVerification'] is False
        assert summary['schemaVersion'] == 3 and summary['dictionary'] == 'vndb' and summary['buildTarget'] == 'chrome'
        assert summary['fixture'] == fixture and summary['mediaCheck'] == media_mode
        assert summary['authoritativeTiming'] is True and summary['traceEnabled'] is False and summary['importFlags'] is None
        assert summary['source']['dirty'] is False
        assert summary['gitSha'] == summary['source']['gitSha'] == identities[arm]['commit']
        assert summary['hostEnvironment']['nodeVersion'] == 'v22.22.0'
        assert summary['browserVersion'] == raw['browserVersion'] == '153.0.8010.12'
        assert len(summary['runs']) == 1
        run = summary['runs'][0]
        assert run['tracePath'] is None and run['index'] == 1
        assert run['packageSha256'] == raw['packageSha256'] == packages[arm]['archiveSha256']
        for path, value in summary['source']['sha256'].items():
            if path.startswith('builds/'):
                assert value == (packages[arm]['archiveSha256'] if path == 'builds/manabitan-chrome.zip' else None)
            else:
                assert value == protocol['unchangedHarnessSha256'][path]
        flags = raw['benchmark']
        assert flags['dictionary'] == 'vndb' and flags['mediaCheck'] == media_mode and flags['importFlags'] is None
        assert flags['productionImportDefaults'] is True and flags['pinnedDictionaries'] is True and flags['authoritativeTiming'] is True
        assert all(flags[k] is False for k in ['traceEnabled', 'phaseProfiling', 'phaseScreenshots', 'processSampling'])
        imports = [p['data'] for p in raw['phases'] if isinstance(p.get('data'), dict) and p['data'].get('kind') == 'dictionary-import']
        assert len(imports) == 1
        clock = imports[0]['browserTiming']
        duration = clock['completedAtMs'] - clock['startedAtMs']
        assert math.isfinite(duration) and duration > 0
        assert clock['trigger'] == 'file-input-change' and clock['errorCount'] == 0
        assert duration == run['totalImportMs'] == entry['totalImportMs']
        if kind == 'timed':
            timings[arm].append(duration)
        assert imports[0]['importDebug'] == run['importDebug']
        assert run['importDebug']['usesFallbackStorage'] is False and run['importDebug']['errorCount'] == 0
        validation = flags['validation']
        assert validation == run['validation']
        assert validation['title'] == fixture['expectedTitle'] and validation['revision'] == fixture['revision']
        assert validation['termRows'] == validation['restart']['termRows'] == fixture['termRows']
        assert validation['contentReadable'] is True and validation['restart']['contentReadable'] is True
        assert validation['probeCount'] == validation['restart']['probeCount'] == 12
        lookup = validation['lookup']['observations']
        assert len(lookup) == 72 and len(set(validation['probeTerms'])) == 12
        assert all(x['hasExactHeadwordMatch'] is True and x['results'] > 0 for x in lookup)
        assert all([x['term'] for x in lookup if x['pass'] == pass_id] == validation['probeTerms'] for pass_id in range(6))
        receipts = sorted([x['pass'], x['term'], x['results'], x['sha256']] for x in lookup)
        if expected_lookup is None:
            expected_lookup = receipts
            expected_probe = validation['outputDigestSha256']
        assert receipts == expected_lookup and validation['outputDigestSha256'] == expected_probe
        media = validation['media']
        assert media['mode'] == media_mode and media['totalFiles'] == validation['restart']['mediaFiles'] == 146570
        assert media['totalBytes'] == 188131284 and media['files'] == (146570 if media_mode == 'all' else 64)
        assert media['bytes'] == (188131284 if media_mode == 'all' else 86256)
        if media_mode in expected_media:
            assert media == expected_media[media_mode]
        expected_media[media_mode] = media
        active = storage_check(validation['storage'], read(folder / 'storage-receipt.json'))
        assert entry['storageBytes'] == validation['storage']['bytes'] and entry['activeSahFileBytes'] == active and entry['nonSahBytes'] == 608996555
        storage_observations.append({k: entry[k] for k in ['name', 'arm', 'cohort', 'storageBytes', 'activeSahFileBytes', 'nonSahBytes']})
    assert all(len(timings[a]) == 12 for a in 'ABC') and timings == analysis['allTimingsMs']
    assert analysis['status'] == 'complete' and analysis['screeningOnly'] is False and analysis['independentQualificationRequired'] is False
    metrics = {}
    for key, base_arm, candidate_arm in [('candidate', 'A', 'B'), ('candidateVsSecondBaseline', 'C', 'B'), ('identicalProductControl', 'A', 'C')]:
        metrics[key] = compare(timings[base_arm], timings[candidate_arm])
        assert all(value == analysis[key][field] for field, value in metrics[key].items())
    correctness = read(cohort / 'correctness.json')
    assert correctness['status'] == 'passed'
    assert correctness['identicalReceipts']['lookup'] == expected_lookup
    for mode, media in expected_media.items():
        assert correctness['identicalReceipts'][f'media-{mode}'] == media
    allocations = read(cohort / 'storage-allocations.json')
    assert allocations == {'policyVersion': POLICY, 'allRawReceiptsRetained': True, 'observations': storage_observations}
    state = read(cohort / 'state.json')
    assert state['status'] == 'success' and state['timedObservations'] == 36 and state['attemptedObservations'] == 41 and state['exhaustiveDiagnostics'] == 2
    if cross_cell_lookup is None:
        cross_cell_lookup, cross_cell_media, cross_cell_probe = expected_lookup, expected_media, expected_probe
    assert (expected_lookup, expected_media, expected_probe) == (cross_cell_lookup, cross_cell_media, cross_cell_probe)
    results.append({
        'artifact': base.name, 'lane': lane, 'schedule': direction, 'orders': orders, 'allChecksPass': True, 'sourceIdentities': identities,
        'toolingCommit': TOOLING, 'runnerSha256': protocol['runnerSha256'], 'unchangedHarnessFileCount': len(protocol['unchangedHarnessSha256']),
        'packageHashesReported': {arm: packages[arm]['archiveSha256'] for arm in 'ABC'},
        'packageDifferences': different, 'packageEntryCount': 550, 'observations': 41, 'timed': 36, 'warmups': 3, 'exhaustiveDiagnostics': 2,
        'timingsMs': timings, 'metrics': metrics, 'media': expected_media, 'termRows': 6648310,
        'lookupReceiptsPerObservation': 72, 'offsetSensitiveDigest': expected_probe, 'nonSahFiles': NON_SAH,
        'storageObservations': storage_observations, 'rawReportSha256': report_hashes,
    })

receipt = {
    'schemaVersion': 1, 'workflowRun': RUN_ID, 'allChecksPass': True, 'newAcquisition': False,
    'scope': 'Two independent frozen VNDB qualification hosts; all 82 original observations retained. No stages or hosts pooled. Claims apply only to frozen baseline bbccabd, not newer develop.',
    'packageLimit': 'Product archives are not included. Archive and decompressed-entry inventories are reconciled as retained receipts; raw product ZIP bytes could not be independently rehashed.',
    'storageLimit': 'Prospective policy permits only VNDB active SQLite allocation 129-131 x4096 bytes. All other normalized paths/sizes exact; no whole SQLite byte-equivalence claim. Earlier failed cohorts remain failed.',
    'canonicalScope': 'Complete rows and restart; 12 deterministic terms x6 passes. Exhaustive persisted media in the two separate diagnostics per cell. No exhaustive all-row canonical-content claim.',
    'results': results,
}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'allChecksPass': True, 'observations': 82, 'receipt': str(OUT / 'receipt.json'), 'metrics': {r['schedule']: {k: v['pairedMedianPercent'] for k, v in r['metrics'].items()} for r in results}}))
