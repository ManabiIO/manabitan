#!/usr/bin/env python3
"""Read-only reconciliation of corrected diagnostic artifacts; never time imports."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/scratch/3aacd533c01f/round2')
BASE = Path(__file__).parent
REPO = ROOT / 'baseline'
TOOLING_SHA = '200b8680bad62e9f40b015ceebebc7382b54dd4b'
TOOLING_TREE = '02fd3a7018bd0025141f178bd3ca35b3d7244a85'
SOURCES = {
    'prefix': ('ebb1da8d2cc2b28901400968891b632605f1b3f0', '243ab638da9cb73e08d84609c41dcdfdf08475cd'),
    'cache': ('cdb23a11d991a72f860e400d0d81bb0747a5b4f9', '1edef4035041ef848175e3278169daf2260ac34a'),
}
LOCK_SHA = '60aa981791f3b60ca17588212aea5bd3536fb8f59288855e5accd019c6e4cf89'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def blob(tree, path):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', f'{tree}:{path}'])


def lookup_receipts(validation):
    observations = validation['lookup']['observations']
    assert len(observations) == 72
    assert all(x['hasExactHeadwordMatch'] is True and x['results'] > 0 for x in observations)
    terms = validation['probeTerms']
    assert len(terms) == len(set(terms)) == 12
    result = []
    for pass_id in range(6):
        group = [x for x in observations if x['pass'] == pass_id]
        assert [x['term'] for x in group] == terms
        receipts = [{k: x[k] for k in ['term', 'results', 'originalTextLength', 'hasExactHeadwordMatch', 'sha256']} for x in group]
        if result:
            assert receipts == result[0]
        result.append(receipts)
    return result


def storage_receipt(validation):
    storage = validation['storage']
    files = storage['files']
    assert storage['bytes'] == sum(x['bytes'] for x in files)
    assert len({x['path'] for x in files}) == len(files)
    non_pool = sorted((re.sub(r'^manabitan-dictionary-media-v1/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.bin$', 'manabitan-dictionary-media-v1/<generation>.bin', x['path']), x['bytes']) for x in files if '/.opaque/' not in x['path'])
    assert len({path for path, _ in non_pool}) == len(non_pool)
    pool = sorted(x['bytes'] for x in files if '/.opaque/' in x['path'])
    return {'bytes': storage['bytes'], 'nonPoolFiles': non_pool, 'poolSizes': pool}


metadata = json.loads((BASE / 'github-metadata.json').read_text())
assert metadata['run'] == 45470204352 and metadata['head'] == TOOLING_SHA
assert len(metadata['artifacts']) == len(metadata['jobs']) == 4
assert all(job['conclusion'] == 'success' for job in metadata['jobs'])
results = []
for item in metadata['artifacts']:
    archive = BASE / f'artifact-{item["id"]}.zip'
    assert archive.stat().st_size == item['size_in_bytes']
    assert f'sha256:{digest(archive.read_bytes())}' == item['digest']
    directory = BASE / f'artifact-{item["id"]}'
    activation = json.loads((directory / 'activation.json').read_text())
    report_bytes = (directory / 'diagnostic/run-1.json').read_bytes()
    report = json.loads(report_bytes)
    summary = json.loads((directory / 'diagnostic/summary.json').read_text())
    mode, dictionary = activation['mode'], activation['dictionary']
    source, tree = SOURCES[mode]
    assert item['name'] == f'import-activation-3aac-{mode}-{dictionary}-45470204352-1'
    assert (directory / 'source-identity.txt').read_text().splitlines() == [source, tree]
    assert (directory / 'tooling-sha.txt').read_text().strip() == TOOLING_SHA
    assert (activation['source'], activation['tree']) == (source, tree)
    assert (directory / 'node-version.txt').read_text().strip() == 'v22.22.0'
    assert digest((directory / 'dictionaries.lock.json').read_bytes()) == LOCK_SHA
    lock = json.loads((directory / 'dictionaries.lock.json').read_text())['dictionaries']
    assert summary['fixture'] == lock[dictionary]
    prepared = (directory / 'prepare-dictionaries.log').read_text()
    for key in ['jmdict', 'jmnedict', 'jitendex'] + (['vndb'] if dictionary == 'vndb' else []):
        assert f'sha256={lock[key]["sha256"]}' in prepared
    patch_name = 'private-prefix.patch' if mode == 'prefix' else 'cache-publication.patch'
    patch = (directory / 'instrumentation.patch').read_bytes()
    assert patch == (directory / 'actual-source.patch').read_bytes()
    assert patch == blob(TOOLING_TREE, f'dev/perf/activation-20261124/{patch_name}')
    assert (directory / 'instrumentation.sha256').read_text().split()[0] == digest(patch)
    for retained, path in [
        ('summarize.py', 'dev/perf/activation-20261124/summarize.py'),
        ('workflow.yml', '.github/workflows/import-activation-20261124-3aac.yml'),
    ]:
        assert (directory / retained).read_bytes() == blob(TOOLING_TREE, path)
    assert summary['source']['gitSha'] == summary['gitSha'] == source
    assert summary['source']['dirty'] is True
    assert len(summary['runs']) == 1
    package_hash = (directory / 'package.sha256').read_text().split()[0]
    assert package_hash == activation['packageSha256'] == report['packageSha256']
    for path, value in summary['source']['sha256'].items():
        if path == 'builds/manabitan-chrome.zip':
            assert value == package_hash
        elif path.startswith('builds/'):
            assert value is None
        else:
            assert digest(blob(tree, path)) == value
    assert activation['reportSha256'] == digest(report_bytes)
    assert report['browserVersion'] == activation['browserVersion'] == summary['browserVersion'] == '153.0.8010.12'
    assert report['status'] == 'success' and report['skippedVerification'] is False
    benchmark = report['benchmark']
    assert benchmark['dictionary'] == dictionary
    assert benchmark['pinnedDictionaries'] is True and benchmark['productionImportDefaults'] is True
    assert benchmark['importFlags'] is None and benchmark['mediaCheck'] == 'sample'
    assert benchmark['traceEnabled'] is False and benchmark['processSampling'] is False
    imports = [x['data'] for x in report['phases'] if isinstance(x.get('data'), dict) and x['data'].get('kind') == 'dictionary-import']
    assert len(imports) == 1
    debug = imports[0]['importDebug']
    assert debug['usesFallbackStorage'] is False and debug['errorCount'] == 0
    markers = [x for x in debug['importerPhaseTimings'] if x['phase'] == 'activation-diagnostic']
    assert len(markers) == 1
    details = markers[0]['details']
    assert details['owner'] == 'offscreen' and details['instrumentationOnly'] is True
    events = details['events']
    assert events == activation['events']
    assert dict(Counter(x['event'] for x in events)) == activation['eventCounts']
    assert activation['activationOwner'] == 'offscreen' and activation['timingsAuthoritative'] is False
    assert activation['allChecksPass'] is True and all(value is True for value in activation['checks'].values())
    independently_counted = {}
    if mode == 'prefix' and dictionary == 'jitendex':
        first = events[0]
        assert first['event'] == 'attempt' and first['force'] is False
        assert first['sourceKind'] == 'private' and first['ownsContent'] is True
        assert first['compressionDictName'] == 'jmdict'
        assert (len(events) - 1) % 3 == 0
        groups = [events[i:i + 3] for i in range(1, len(events), 3)]
        prior_start = -1
        for attempt, begin, placement in groups:
            assert attempt['event'] == 'attempt' and attempt['force'] is True
            assert attempt['compressionDictName'] == 'jmdict' and attempt['sourceKind'] == 'private' and attempt['ownsContent'] is True
            assert begin['event'] == 'begin' and begin['privateSource'] is True and begin['initialSelection'] is False
            assert begin['uncompressedBytes'] == attempt['uncompressedBytes']
            assert placement['event'] == 'private-prefix'
            assert placement['primaryStartOffset'] == placement['startOffset'] + begin['uniqueCount'] * 20
            assert placement['primaryStartOffset'] + placement['primaryBytesUpperBound'] <= placement['maximumEndOffset'] == 0xfffffffe
            assert placement['startOffset'] > prior_start
            prior_start = placement['startOffset']
        independently_counted = {
            'attempts': 1 + len(groups), 'privateAdmissions': len(groups), 'privatePrefixReservations': len(groups),
            'privateSuffixFallbacks': 0, 'existingSharedAdmissions': 0, 'firstPrivateAttempts': 1,
            'privateAdmittedContentBytes': sum(x[1]['uncompressedBytes'] for x in groups),
            'privateAdmittedUniqueCount': sum(x[1]['uniqueCount'] for x in groups),
            'eligibleOwnedSourceBytes': sum(x[0]['sourceBytes'] for x in groups),
        }
        assert independently_counted == activation['activation']
    elif mode == 'prefix' and dictionary == 'jmdict':
        assert len(events) % 2 == 0
        for index in range(0, len(events), 2):
            attempt, begin = events[index:index + 2]
            assert attempt['event'] == 'attempt' and attempt['sourceKind'] == 'shared' and attempt['ownsContent'] is True
            assert attempt['compressionDictName'] == 'jmdict' and attempt['force'] is (index != 0)
            assert begin['event'] == 'begin' and begin['privateSource'] is False
            assert begin['initialSelection'] is (index == 0)
        assert activation['activation']['existingSharedAdmissions'] == len(events) // 2 == 12
        assert activation['activation']['privateAdmissions'] == 0
        independently_counted = {'existingSharedAdmissions': len(events) // 2, 'initialSharedSelection': 1, 'privateAdmissions': 0}
    elif mode == 'prefix' and dictionary == 'vndb':
        assert all(x['event'] == 'attempt' and x['sourceKind'] == 'private' and x['ownsContent'] is True and x['compressionDictName'] is None for x in events)
        assert [x['force'] for x in events] == [False, False] + [True] * (len(events) - 2)
        assert activation['activation']['privateAdmissions'] == activation['activation']['existingSharedAdmissions'] == 0
        independently_counted = {'attempts': len(events), 'unforcedSelectionAttempts': 2, 'privateAdmissions': 0, 'sharedAdmissions': 0}
    else:
        assert mode == 'cache' and dictionary == 'jmdict' and len(events) % 2 == 0
        for index in range(0, len(events), 2):
            publisher, receiver = events[index:index + 2]
            assert publisher['event'] == 'cache-publisher' and receiver['event'] == 'cache-receiver'
            assert all(publisher[k] == receiver[k] for k in ['publishedContiguous', 'count', 'sourceBytes'])
            assert publisher['publishedContiguous'] is True and receiver['reusePublishedRange'] is True
        receivers = events[1::2]
        independently_counted = {
            'publisherCalls': len(receivers), 'publisherProofTrueCalls': len(receivers), 'receiverCalls': len(receivers),
            'receiverReusedProofCalls': len(receivers), 'receiverReusedProofRows': sum(x['count'] for x in receivers),
            'receiverReusedSourceBytes': sum(x['sourceBytes'] for x in receivers),
        }
        assert independently_counted == activation['activation']
    validation = benchmark['validation']
    fixture = lock[dictionary]
    assert validation['title'] == fixture['expectedTitle'] and validation['revision'] == fixture['revision']
    assert validation['termRows'] == validation['restart']['termRows'] == fixture['termRows']
    assert validation['contentReadable'] is True and validation['restart']['contentReadable'] is True
    assert validation['probeCount'] == validation['restart']['probeCount'] == 12
    assert validation['media']['totalFiles'] == validation['restart']['mediaFiles'] == fixture['mediaFiles']
    assert validation['media']['totalBytes'] == fixture['mediaBytes']
    assert validation['media']['files'] == min(64, fixture['mediaFiles'])
    if dictionary == 'vndb':
        reference = ROOT / 'activation-failures-45468163108/artifact-14956350395/diagnostic/run-1.json'
    else:
        arm = 'B' if dictionary == 'jitendex' else 'A'
        reference = ROOT / f'artifacts/import-prefix-qualification-{dictionary}-forward-45468314006-1/cohort/diagnostic-{arm}/run-1.json'
    prior = json.loads(reference.read_text())['benchmark']['validation']
    assert lookup_receipts(validation) == lookup_receipts(prior)
    assert storage_receipt(validation) == storage_receipt(prior)
    assert validation['outputDigestSha256'] == prior['outputDigestSha256']
    results.append({
        'artifactId': item['id'], 'archiveSha256': digest(archive.read_bytes()), 'mode': mode, 'dictionary': dictionary,
        'source': source, 'tree': tree, 'instrumentationSha256': digest(patch), 'packageSha256Reported': package_hash,
        'reportSha256': digest(report_bytes), 'owner': details['owner'], 'eventCounts': dict(Counter(x['event'] for x in events)),
        'activation': activation['activation'], 'independentSequenceChecks': independently_counted,
        'termRows': validation['termRows'], 'lookupReceipts': 72, 'sampledMedia': validation['media'],
        'storageBytes': validation['storage']['bytes'], 'priorCorrectnessReference': str(reference),
        'allChecksPass': True,
    })

output = {
    'schemaVersion': 1, 'runId': 45470204352, 'toolingSha': TOOLING_SHA, 'toolingTree': TOOLING_TREE,
    'allChecksPass': True, 'timingsAuthoritative': False,
    'timingCaveat': 'Raw standard benchmark.authoritativeTiming remains true because the benchmark harness was unchanged. Instrumentation overlay makes these four observations diagnostic-only; no timing is used.',
    'packageCaveat': 'The archive retains package SHA receipts but not built product ZIPs; reported package hashes are reconciled across raw report, summary and sha256 receipt, not independently rehashed from absent product bytes.',
    'correctnessScope': 'Complete row counts and restart, 72 deterministic canonical lookup receipts (12 terms x 6 passes), sampled media, exact normalized per-file logical sizes; no exhaustive all-row content or full-media parity claim for these diagnostic runs.',
    'firstFailuresRetained': str(ROOT / 'activation-failures-45468163108'),
    'results': results,
}
(BASE / 'independent-review.json').write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps({'allChecksPass': True, 'cells': len(results), 'output': str(BASE / 'independent-review.json')}))
