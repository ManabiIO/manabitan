#!/usr/bin/env python3
"""Summarize retained PR875 memory observations; performs no acquisition."""

import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/3aacd533c01f/round2')
ARTIFACT = ROOT / 'artifacts/import-memory-3aac-media-jitendex-rep2-45471351138-1'
OUT = Path(__file__).parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def role(process):
    argv = ' '.join(process['argv'])
    if '--extension-process' in argv:
        return 'extension-renderer'
    if process['role'] == 'utility':
        return next((x.split('=', 1)[1] for x in argv.split() if x.startswith('--utility-sub-type=')), 'utility')
    if process['role'] == 'renderer':
        return next((f'renderer-client-{x.split("=", 1)[1]}' for x in argv.split() if x.startswith('--renderer-client-id=')), 'renderer')
    return process['role']


comparison = json.loads((ARTIFACT / 'memory-comparison.json').read_text())
assert comparison['pairs'][0]['qualified'] is True
assert comparison['pairs'][1]['qualified'] is False
assert comparison['passesProspectiveMemoryScreen'] is False
result = {
    'schemaVersion': 1, 'sourceArtifact': str(ARTIFACT), 'noNewAcquisition': True,
    'sourceIdentities': json.loads((ARTIFACT / 'plan.json').read_text())['sourceIdentities'],
    'qualifiedPair': comparison['pairs'][0],
    'otherPairQualified': False,
    'conclusion': 'Valid first pair fails private-memory bound. No concrete new retention owner identified by bounded source audit. Process-level samples do not identify the cause; do not dismiss as noise or infer a particular GC/allocator cause.',
    'observations': {},
}
for name in ['A1', 'B1']:
    memory_path = ARTIFACT / name / 'memory.json'
    report_path = ARTIFACT / name / 'run-1.json'
    memory = json.loads(memory_path.read_text())
    start, end = [int(x['monotonicNs']) for x in memory['windowMarkers']]
    samples = [s for s in memory['samples'] if s['qualifiedForWholeTreePss'] and s['startedAtMonotonicNs'] >= start and s['finishedAtMonotonicNs'] <= end]
    assert memory['qualifiedForWholeTreePss'] and len(samples) == 13
    private_peak = max(samples, key=lambda s: s['readableProcessPrivateKiB'])
    pss_peak = max(samples, key=lambda s: s['readableProcessPssKiB'])
    assert private_peak is pss_peak
    assert private_peak['readableProcessPrivateKiB'] == memory['maxSampledPrivateKiB']
    assert pss_peak['readableProcessPssKiB'] == memory['maxSampledPssKiB']
    processes = [dict(pid=p['pid'], startTimeTicks=p['startTimeTicks'], role=role(p), pssKiB=p['pssKiB'], privateKiB=p['privateKiB'], threadCount=p['threadCount']) for p in private_peak['processes']]
    report = json.loads(report_path.read_text())
    imported = [p['data'] for p in report['phases'] if isinstance(p.get('data'), dict) and p['data'].get('kind') == 'dictionary-import']
    assert len(imported) == 1
    phases = imported[0]['importDebug']['importerPhaseTimings']
    parser = next(x for x in phases if x['phase'].startswith('term-file-fast-path:'))
    selected = ['parserMaxWasmHeapBytes', 'parserParallelOwnedContentBytes', 'parserParallelPeakQueuedOwnedContentBytes', 'parserParallelPipelineGroupsPerWorker', 'parserParallelWorkerCount']
    timeline = []
    for sample in samples:
        extension = [p for p in sample['processes'] if role(p) == 'extension-renderer']
        assert len(extension) == 1
        timeline.append({
            'startMs': (sample['startedAtMonotonicNs'] - start) / 1e6,
            'endMs': (sample['finishedAtMonotonicNs'] - start) / 1e6,
            'wholeTreePssKiB': sample['readableProcessPssKiB'], 'wholeTreePrivateKiB': sample['readableProcessPrivateKiB'],
            'extensionPssKiB': extension[0]['pssKiB'], 'extensionPrivateKiB': extension[0]['privateKiB'],
        })
    result['observations'][name] = {
        'memorySha256': sha(memory_path), 'reportSha256': sha(report_path),
        'maximumPrivateKiB': memory['maxSampledPrivateKiB'], 'maximumPssKiB': memory['maxSampledPssKiB'],
        'peakStartMs': (private_peak['startedAtMonotonicNs'] - start) / 1e6,
        'peakEndMs': (private_peak['finishedAtMonotonicNs'] - start) / 1e6,
        'peakProcesses': processes, 'qualifiedTimeline': timeline,
        'parserCounters': {k: parser['details'][k] for k in selected},
        'parserPhaseStartEpochMs': parser['startEpochMs'], 'parserPhaseEndEpochMs': parser['endEpochMs'],
    }
(OUT / 'receipt.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'receipt': str(OUT / 'receipt.json'), 'validPairPrivateChangePercent': comparison['pairs'][0]['maxSampledPrivateKiB']['changePercent']}))
