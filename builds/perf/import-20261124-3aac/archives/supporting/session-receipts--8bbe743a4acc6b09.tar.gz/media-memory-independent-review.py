#!/usr/bin/env python3
"""Read-only reconciliation of the fixed media-memory run and its failures."""

import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
RUN = 45471351138
TOOLING = 'df1e9f4ac1e4c4e2e02b96de90bfe63d3ff359dc'
SOURCE = {
    'A': {'commit': 'bbccabd520972cc351a65d9f545bd5369b6e9747',
          'tree': 'f81fc2c29b58f1c2329de6b8fa6b2a91015b6b07'},
    'B': {'commit': 'fb71a03f4611bcfa71e135693bebd1fe778153bf',
          'tree': '0939bd1eec85dc0b3f15ef002a8f0f5111c80103'},
}
CELLS = sorted((ROOT / 'artifacts').glob(f'import-memory-3aac-media-*-{RUN}-1'))
assert {p.name for p in CELLS} == {
    f'import-memory-3aac-media-{dictionary}-rep{rep}-{RUN}-1'
    for dictionary in ('jitendex', 'vndb') for rep in (1, 2)
}
MODULE_PATH = 'dev/perf/import-memory-20261124-3aac'
sys.path.insert(0, str(CELLS[0] / 'source' / MODULE_PATH))
from audit_memory import audit_cell
from verify_receipts import verify


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def gap_failure(memory):
    start, end = [int(m['monotonicNs']) for m in memory['windowMarkers']]
    covered = [(i, s) for i, s in enumerate(memory['samples'])
               if start <= s['startedAtMonotonicNs'] <= s['finishedAtMonotonicNs'] <= end
               and s['qualifiedForWholeTreePss']]
    points = [('start', start)] + [
        (i, (s['startedAtMonotonicNs'] + s['finishedAtMonotonicNs']) // 2)
        for i, s in covered
    ] + [('end', end)]
    left, right = max(zip(points, points[1:]), key=lambda pair: pair[1][1] - pair[0][1])
    maximum_gap = (right[1] - left[1]) / 1e6
    assert maximum_gap == memory['maximumCoveredSampleGapMs']
    affected = []
    for index, sample in enumerate(memory['samples']):
        midpoint = (sample['startedAtMonotonicNs'] + sample['finishedAtMonotonicNs']) // 2
        if not left[1] <= midpoint <= right[1]:
            continue
        after = {p['pid']: p for p in sample['discoveryAfter']['processes']}
        unreadable = []
        for process in sample['unreadableAddressSpaces']:
            unreadable.append({
                key: process.get(key)
                for key in ('pid', 'startTimeTicks', 'state', 'threadCount', 'role',
                            'executable', 'metadataReadErrors', 'smapsReadError')
            } | {'samePidPresentAfterScan': process['pid'] in after})
        affected.append({
            'rawSampleIndex': index,
            'relativeMidpointMs': (midpoint - start) / 1e6,
            'scanDurationMs': (sample['finishedAtMonotonicNs'] - sample['startedAtMonotonicNs']) / 1e6,
            'qualificationFailures': sample['qualificationFailures'],
            'stableObservedProcessTree': sample['stableObservedProcessTree'],
            'unreadableAddressSpaces': unreadable,
        })
    return {'maximumCoveredGapMs': maximum_gap, 'leftPoint': left[0], 'rightPoint': right[0],
            'scansAcrossMaximumGap': affected}


def qualified_peak(memory, metric):
    if not memory['qualifiedForWholeTreePss']:
        return None
    start, end = [int(m['monotonicNs']) for m in memory['windowMarkers']]
    raw_key = 'readableProcessPssKiB' if metric == 'pssKiB' else 'readableProcessPrivateKiB'
    inside = [(i, s) for i, s in enumerate(memory['samples'])
              if start <= s['startedAtMonotonicNs'] <= s['finishedAtMonotonicNs'] <= end
              and s['qualifiedForWholeTreePss']]
    index, sample = max(inside, key=lambda row: row[1][raw_key])
    roles = {}
    for process in sample['processes']:
        roles[process['role']] = roles.get(process['role'], 0) + process[metric]
    return {'rawSampleIndex': index, 'valueKiB': sample[raw_key], 'sumByProcessRoleKiB': roles}


provenance_path = ROOT / 'evidence/builds/perf/import-20261124-3aac/provenance' / f'github-artifacts-{RUN}.json'
provenance = read(provenance_path)
artifacts = {a['name']: a for a in provenance['artifacts']}
report = {
    'schemaVersion': 1, 'workflowRun': RUN, 'workflowAttempt': 1,
    'workflowUrl': f'https://github.com/ManabiIO/manabitan/actions/runs/{RUN}',
    'sourceIdentities': SOURCE, 'toolingCommit': TOOLING,
    'authoritativeTiming': False, 'newAcquisitions': 0, 'rerunsOrReplacements': 0,
    'rawEvidenceModified': False,
    'reviewerScriptSha256': digest(Path(__file__)),
    'githubArtifactMetadataSha256': digest(provenance_path), 'cells': [],
    'scope': 'Read-only recomputation of original raw scans, marker bytes, package/source receipts, and sampled-media/restart correctness. This is not another memory acquisition or timing cohort.',
}
for cell in CELLS:
    plan = read(cell / 'plan.json')
    assert plan['sourceIdentities'] == SOURCE and plan['toolingCommit'] == TOOLING
    assert int(plan['workflowRun']) == RUN and int(plan['workflowAttempt']) == 1
    assert artifacts[cell.name]['workflow_run']['head_sha'] == TOOLING
    for module in ('chromium_memory.py', 'audit_memory.py', 'protocol.py', 'run_memory.py',
                   'verify_receipts.py', 'storage_receipts.py'):
        assert digest(cell / 'source' / MODULE_PATH / module) == digest(CELLS[0] / 'source' / MODULE_PATH / module)
    memory_audit = audit_cell(cell)
    receipt_audit = verify(cell)
    assert memory_audit == read(cell / 'memory-audit.json')
    assert receipt_audit == read(cell / 'receipt-audit.json')
    comparison = read(cell / 'memory-comparison.json')
    qualification = read(cell / 'qualification.json')
    assert qualification['retriedObservations'] == 0
    assert qualification['memoryScreenPassed'] == memory_audit['passesProspectiveMemoryScreen']
    assert qualification['correctnessPassed'] == receipt_audit['allCorrectnessPassed']
    observations, input_hashes = [], {}
    for entry in plan['schedule']:
        location = cell / entry['name']
        memory = read(location / 'memory.json')
        fields = ('qualifiedForWholeTreePss', 'qualificationFailures', 'benchmarkExitCode',
                  'maxSampledPssKiB', 'maxSampledPrivateKiB', 'allObservedSampleCount',
                  'fullyContainedImportSampleCount', 'stableFullyReadImportSampleCount',
                  'maximumCoveredSampleGapMs', 'preImportBracketGapMs', 'postImportBracketGapMs',
                  'samplesWithUnreadableAddressSpaces', 'confirmedExitedZombieObservationCount')
        observation = entry | {key: memory[key] for key in fields}
        observation['coverageGapDetails'] = gap_failure(memory) if not memory['qualifiedForWholeTreePss'] else None
        if plan['dictionary'] == 'jitendex' and plan['replication'] == 2 and entry['pair'] == 1:
            observation['qualifiedPeakRoleBreakdown'] = {
                metric: qualified_peak(memory, metric) for metric in ('pssKiB', 'privateKiB')
            }
        observations.append(observation)
        for name in ('memory.json', 'markers.jsonl', 'acquisition.json', 'summary.json', 'correctness.json'):
            input_hashes[f"{entry['name']}/{name}"] = digest(location / name)
    for name in ('plan.json', 'qualification.json', 'memory-comparison.json', 'memory-audit.json',
                 'receipt-audit.json', 'storage-allocation-summary.json', 'correctness.json',
                 'A-identity.json', 'B-identity.json', 'A-package-entries.json', 'B-package-entries.json'):
        input_hashes[name] = digest(cell / name)
    assert len(observations) == 4
    report['cells'].append({
        'artifact': cell.name, 'githubArtifactId': artifacts[cell.name]['id'],
        'githubArtifactDigest': artifacts[cell.name]['digest'],
        'dictionary': plan['dictionary'], 'replication': plan['replication'],
        'sourceIdentities': plan['sourceIdentities'], 'fixture': plan['fixture'],
        'qualification': qualification, 'memoryAudit': memory_audit, 'receiptAudit': receipt_audit,
        'metrics': comparison['metrics'], 'pairs': comparison['pairs'], 'observations': observations,
        'storageAllocationSummary': read(cell / 'storage-allocation-summary.json'),
        'inputSha256': input_hashes,
    })
report['decision'] = {
    'jitendex': 'Not qualified: replication 1 passes; replication 2 has a baseline A2 coverage failure and a qualified first-pair private-memory increase of 11.540878945904876%, exceeding the fixed 10% individual gate. No valid replication-2 aggregate estimate exists.',
    'vndb': 'Not qualified: replication 2 passes; replication 1 loses both baseline observations to covered-scan gaps above 250 ms, leaving no qualified pairs. This is an unresolved coverage result, not evidence of a RAM regression.',
    'correctness': 'All 16 original commands exited 0 and all source/package/semantic sampled-media/lookup/restart receipts recompute successfully.',
    'coverageCause': 'All three invalid observations have one scan during which an observed single-thread zombie disappears before rediscovery; smaps returns ENOENT, so the frozen ESRCH plus stable Z-to-Z exception does not apply. Skipping that uncovered scan yields the recorded gap violation. No relaxation or replacement is applied.',
    'interpretation': 'The qualified Jitendex private-memory pair is a measured gate breach, not a demonstrated repeatable causal effect. Sampled whole-tree maxima are non-atomic observations and do not establish exact peaks. Neither dictionary satisfies the required two independent replications.',
}
output = ROOT / 'media-memory-independent-review.json'
output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'output': str(output), 'cells': len(report['cells']),
                  'observations': sum(len(c['observations']) for c in report['cells']),
                  'rawScans': sum(c['memoryAudit']['rawScanCount'] for c in report['cells']),
                  'decision': report['decision']}, indent=2))
