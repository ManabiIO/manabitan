#!/usr/bin/env python3
"""Reconcile all three completed frozen canonical-input screens without acquisition."""

import hashlib
import json
import math
from pathlib import Path
import random
import re
import statistics
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
RUN = 45472377306
DICTIONARIES = ('jmdict', 'jitendex', 'vndb')
ORDERS = ('ABC', 'CBA', 'BAC', 'CAB', 'BCA', 'ACB')
BASE = {'commit': 'bbccabd520972cc351a65d9f545bd5369b6e9747',
        'tree': 'f81fc2c29b58f1c2329de6b8fa6b2a91015b6b07'}
CANDIDATE = {'commit': '2dfa72962c9d9f1976011e41b9bbce2375f4dbb5',
             'tree': '64345e92fff3800b5035b6aab52dff06e20bc874'}
CHANGED = ['js/dictionary/wasm/term-content-canonical-scan-v1.c',
           'lib/term-content-canonical-scan-v1.wasm']
SOURCE_IDENTITIES = {'A': BASE, 'B': CANDIDATE, 'C': BASE}
FIRST = ROOT / 'artifacts' / f'import-canonical-screen-storage-v1-jmdict-forward-{RUN}-1'
sys.path.insert(0, str(FIRST / 'storage-policy'))
from storage_receipts import POLICY_VERSION, normalize_storage_receipt, storage_comparison_key


def read(path):
    return json.loads(path.read_text())


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def comparison(base, candidate):
    changes = [(b / a - 1) * 100 for a, b in zip(base, candidate, strict=True)]
    rng = random.Random(20261124)
    samples = sorted(statistics.median(rng.choices(changes, k=len(changes))) for _ in range(10000))
    return {
        'pairs': len(changes), 'fasterPairs': sum(value < 0 for value in changes),
        'bestPairPercent': min(changes), 'worstPairPercent': max(changes),
        'pairedChangesPercent': changes, 'pairedMedianPercent': statistics.median(changes),
        'pairedMedianBootstrap95Percent': [samples[249], samples[9749]],
        'equalWorkPercent': (sum(candidate) / sum(base) - 1) * 100,
        'baselineMedianMs': statistics.median(base), 'candidateMedianMs': statistics.median(candidate),
    }


report = {
    'schemaVersion': 1, 'workflowRun': RUN, 'workflowAttempt': 1,
    'workflowUrl': f'https://github.com/ManabiIO/manabitan/actions/runs/{RUN}',
    'sourceIdentities': SOURCE_IDENTITIES,
    'scope': 'Independent read-only reconciliation of all 23 observations per completed screen: fixed schedule, source/package/fixture/harness identities, native summary receipts, storage, media, restart and paired arithmetic. No new acquisitions or source changes.',
    'reviewerScriptSha256': digest(Path(__file__)), 'newAcquisitions': 0,
    'retriesOrReplacements': 0, 'excludedPostHocObservations': 0,
    'cells': [], 'pendingDictionary': None,
    'vndbArchiveVerification': read(ROOT / 'canonical-vndb-artifact-receipt.json'),
}
previous_harness = previous_packages = None
for dictionary in DICTIONARIES:
    artifact = ROOT / 'artifacts' / f'import-canonical-screen-storage-v1-{dictionary}-forward-{RUN}-1'
    cell = artifact / 'cohort'
    protocol, state = read(cell / 'protocol.json'), read(cell / 'state.json')
    observations, analysis = read(cell / 'observations.json'), read(cell / 'analysis.json')
    assert protocol['sourceIdentities'] == SOURCE_IDENTITIES
    assert protocol['toolingCommit'] == '8774a1cebe9974e5353af48453159413350d9a6a'
    assert protocol['github']['GITHUB_RUN_ID'] == str(RUN)
    assert protocol['github']['GITHUB_RUN_ATTEMPT'] == '1'
    assert protocol['runnerSha256'] == digest(artifact / 'runner.py')
    assert protocol['orders'] == list(ORDERS) and protocol['plannedBlocks'] == 6
    assert protocol['stage'] == 'screen' and protocol['reversedSchedule'] is False
    assert protocol['harnessOverlay'] is None and protocol['nodeVersion'] == 'v22.22.0'
    assert protocol['diagnosticArms'] == ['A', 'B'] and protocol['diagnosticMediaCheck'] == 'all'
    assert protocol['timingMediaCheck'] == 'sample' and protocol['warmupsExcluded'] == 3
    assert protocol['storagePolicyVersion'] == POLICY_VERSION
    for name, value in protocol['storagePolicySha256'].items():
        assert digest(artifact / 'storage-policy' / name) == value
    assert digest(artifact / 'storage-policy/storage_receipts.py') == '4469e1c0a463819b5f75ff79ebd011860c7077edecb727ff6ddcb4f05a96ca02'
    if previous_harness is not None:
        assert previous_harness == protocol['unchangedHarnessSha256']
    previous_harness = protocol['unchangedHarnessSha256']
    packages = {arm: read(cell / f'package-{arm}.json') for arm in 'ABC'}
    for arm in 'ABC':
        assert packages[arm]['source'] == SOURCE_IDENTITIES[arm]
    assert packages['C'] == packages['A'] | {'identicalArchiveFromArm': 'A'}
    assert all((cell / f'source-status-{arm}.txt').read_text().strip() == '' for arm in 'AB')
    actual_changes = [name for name in sorted(set(packages['A']['entries']) | set(packages['B']['entries']))
                      if packages['A']['entries'].get(name) != packages['B']['entries'].get(name)]
    assert actual_changes == CHANGED == protocol['expectedPackageDifferences'] == read(cell / 'package-differences.json')
    assert packages['A']['entries'][CHANGED[1]] == '40948d5c20d26253e86c93d267e3cbb3817ea87c9731e02bcca0523c0eb3d6af'
    assert packages['B']['entries'][CHANGED[1]] == '5e16593eb74b04513eb06b08ff98111853cc6bec51e45292feed92f424d732ae'
    if previous_packages is not None:
        assert all(previous_packages[arm]['entries'] == packages[arm]['entries'] for arm in 'ABC')
    previous_packages = packages
    fixture = protocol['fixture']
    assert read(cell / 'fixture.json') == {'fixture': fixture, 'sizeBytes': fixture['sizeBytes'], 'sha256': fixture['sha256']}
    assert read(cell / 'setup-fixtures.json')[dictionary] == read(cell / 'fixture.json')
    schedule = [(f'warmup-{arm}', arm, 'excluded-warmup', None, None, 'sample') for arm in 'ABC']
    schedule += [(f'block-{block:02d}-{position}-{arm}', arm, 'timed', block, position, 'sample')
                 for block, order in enumerate(ORDERS, 1) for position, arm in enumerate(order, 1)]
    schedule += [(f'diagnostic-{arm}', arm, 'exhaustive-diagnostic', None, None, 'all') for arm in 'AB']
    assert len(observations) == len(schedule) == 23
    expected_receipts, browsers, digests, raw_storage, active_sah_sizes = {}, set(), set(), set(), set()
    timings = {arm: [] for arm in 'ABC'}
    input_hashes = {}
    for observation, expected in zip(observations, schedule, strict=True):
        name, arm, cohort, block, position, media_check = expected
        assert all(observation[key] == value for key, value in {
            'name': name, 'arm': arm, 'cohort': cohort, 'block': block, 'position': position,
            'mediaCheck': media_check, 'source': SOURCE_IDENTITIES[arm], 'status': 'success',
        }.items())
        summary = read(cell / name / 'summary.json')
        assert all(summary[key] == value for key, value in {
            'schemaVersion': 3, 'dictionary': dictionary, 'buildTarget': 'chrome',
            'fixture': fixture, 'authoritativeTiming': True, 'traceEnabled': False,
            'gitSha': SOURCE_IDENTITIES[arm]['commit'], 'importFlags': None, 'mediaCheck': media_check,
        }.items())
        assert len(summary['runs']) == 1 and summary['hostEnvironment']['nodeVersion'] == 'v22.22.0'
        run, source = summary['runs'][0], summary['source']
        assert source['gitSha'] == SOURCE_IDENTITIES[arm]['commit'] and source['dirty'] is False
        assert run['packageSha256'] == packages[arm]['archiveSha256'] == source['sha256']['builds/manabitan-chrome.zip']
        for path, value in source['sha256'].items():
            if path in protocol['unchangedHarnessSha256']:
                assert value == protocol['unchangedHarnessSha256'][path]
        assert summary['browserVersion'] == run['browserVersion'] == '153.0.8010.12'
        browsers.add(run['browserVersion'])
        assert math.isfinite(run['totalImportMs']) and run['totalImportMs'] > 0
        assert run['totalImportMs'] == observation['totalImportMs']
        if cohort == 'timed':
            timings[arm].append(run['totalImportMs'])
        validation = run['validation']
        for key, value in {'title': fixture['expectedTitle'], 'revision': fixture['revision'],
                           'termRows': fixture['termRows'], 'contentReadable': True, 'probeCount': 12}.items():
            assert validation[key] == validation['restart'][key] == value
        assert validation['restart']['mediaFiles'] == fixture['mediaFiles']
        terms, lookups = validation['probeTerms'], validation['lookup']['observations']
        assert len(terms) == len(set(terms)) == 12 and len(lookups) == 72
        assert {(row['pass'], row['term']) for row in lookups} == {(i, term) for i in range(6) for term in terms}
        assert all(row['results'] > 0 and row['hasExactHeadwordMatch'] is True
                   and re.fullmatch('[a-f0-9]{64}', row['sha256']) for row in lookups)
        digests.add(validation['outputDigestSha256'])
        media = validation['media']
        assert media['mode'] == media_check and media['totalFiles'] == fixture['mediaFiles']
        assert media['totalBytes'] == fixture['mediaBytes']
        assert media['files'] == (fixture['mediaFiles'] if media_check == 'all' else min(64, fixture['mediaFiles']))
        if media_check == 'all':
            assert media['bytes'] == fixture['mediaBytes']
        storage = normalize_storage_receipt(validation['storage'], dictionary)
        assert storage == read(cell / name / 'storage-receipt.json')
        assert observation['storageBytes'] == storage['rawStorageBytes']
        assert observation['activeSahFileBytes'] == storage['sahPool']['activeFileBytes']
        assert observation['nonSahBytes'] == storage['nonSahBytes']
        raw_storage.add(storage['rawStorageBytes'])
        active_sah_sizes.add(storage['sahPool']['activeFileBytes'])
        receipts = {'lookup': sorted([row['pass'], row['term'], row['results'], row['sha256']] for row in lookups),
                    'storageInvariant': storage_comparison_key(storage),
                    f'media-{media_check}': {k: media[k] for k in ('mode', 'totalFiles', 'totalBytes', 'files', 'bytes', 'sha256')}}
        for key, value in receipts.items():
            if key in expected_receipts:
                assert expected_receipts[key] == value
            expected_receipts[key] = value
        input_hashes[f'{name}/summary.json'] = digest(cell / name / 'summary.json')
        input_hashes[f'{name}/storage-receipt.json'] = digest(cell / name / 'storage-receipt.json')
    assert len(digests) == len(browsers) == len(raw_storage) == 1
    assert read(cell / 'correctness.json') == {'status': 'passed', 'identicalReceipts': expected_receipts}
    assert state['status'] == 'success' and state['attemptedObservations'] == 23
    assert state['timedObservations'] == 18 and state['exhaustiveDiagnostics'] == 2
    assert analysis['allTimingsMs'] == timings and analysis['status'] == 'complete'
    comparisons = {}
    for key, base_arm, candidate_arm in (('candidate', 'A', 'B'), ('candidateVsSecondBaseline', 'C', 'B'),
                                         ('identicalProductControl', 'A', 'C')):
        comparisons[key] = comparison(timings[base_arm], timings[candidate_arm])
        assert all(analysis[key][k] == v for k, v in comparisons[key].items())
    for name in ('protocol.json', 'state.json', 'analysis.json', 'observations.json', 'correctness.json',
                 'package-A.json', 'package-B.json', 'package-C.json', 'fixture.json', 'setup-fixtures.json'):
        input_hashes[name] = digest(cell / name)
    report['cells'].append({
        'artifact': artifact.name, 'dictionary': dictionary, 'sourceIdentities': SOURCE_IDENTITIES,
        'attemptedObservations': 23, 'timedObservations': 18, 'prespecifiedWarmups': 3,
        'exhaustiveDiagnostics': 2, 'browserVersion': next(iter(browsers)),
        'fixture': fixture, 'packageDifferences': actual_changes,
        'packageSha256': {arm: packages[arm]['archiveSha256'] for arm in 'ABC'},
        'packageEntryCount': {arm: len(packages[arm]['entries']) for arm in 'ABC'},
        'allTimingsMs': timings, 'comparisons': comparisons, 'correctnessPassed': True,
        'canonicalProbeDigest': next(iter(digests)), 'rawStorageBytes': next(iter(raw_storage)),
        'activeSahFileBytes': sorted(active_sah_sizes),
        'storagePolicyVersion': POLICY_VERSION,
        'exhaustiveMediaReceipt': expected_receipts['media-all'], 'inputSha256': input_hashes,
    })
report['decisions'] = {
    'jmdict': 'No demonstrated material total-import gain: B/C paired median -0.1053%, with 3/6 faster pairs and an interval crossing zero. The retained 1495.7 ms A observation inflates the B/A equal-work reduction, while the same-code C/A control shows almost the same reduction. No tail is excluded.',
    'jitendex': 'No demonstrated material total-import gain: B/C paired median -0.6593%, with 5/6 faster pairs but an interval crossing zero. B/A -2.1959% must be considered alongside C/A -1.2521% control drift. No qualification claim follows from this exploratory screen.',
    'vndb': 'No demonstrated material total-import gain: B/A paired median -0.7313% and B/C -0.4309%, with 4/6 faster pairs against each baseline and both intervals crossing zero. The identical-product C/A median is -0.3003%; all tails are retained. All 23 original observations pass correctness, including 146,570 media files / 188,131,284 bytes in each exhaustive diagnostic. The active SAH file is 528,384 bytes in every observation, within the unchanged prospective 129-131 aligned 4,096-byte full-file allocation-unit bound.',
    'scopeLimit': 'Inventory counts, 12 canonical probes, 72 production lookup receipts, restart, exact normalized storage inventory, and exhaustive media were checked. These receipts do not establish byte-for-byte equality of every term or persisted database page.',
    'next': 'Retain all three complete cohorts. None demonstrates a material total-import gain, so these results do not justify performance promotion or another unchanged-source screen.',
}
output = ROOT / 'canonical-screen-independent-review.json'
output.write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
print(json.dumps({'output': str(output), 'cells': len(report['cells']),
                  'verifiedObservations': 69, 'decisions': report['decisions']}, indent=2))
