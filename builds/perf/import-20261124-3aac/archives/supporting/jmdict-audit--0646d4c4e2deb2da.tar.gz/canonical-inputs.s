	.file	"term-content-canonical-scan-v1.c"
	.functype	canonical_abi_version () -> (i32)
	.export_name	canonical_abi_version, canonical_abi_version
	.functype	canonical_layout_end () -> (i32)
	.export_name	canonical_layout_end, canonical_layout_end
	.functype	canonical_max_rows () -> (i32)
	.export_name	canonical_max_rows, canonical_max_rows
	.functype	canonical_prefix_bytes () -> (i32)
	.export_name	canonical_prefix_bytes, canonical_prefix_bytes
	.functype	scan_canonical () -> (i32)
	.export_name	scan_canonical, scan_canonical
	.section	.text.canonical_abi_version,"R",@
	.hidden	canonical_abi_version           # -- Begin function canonical_abi_version
	.globl	canonical_abi_version
	.type	canonical_abi_version,@function
canonical_abi_version:                  # @canonical_abi_version
	.functype	canonical_abi_version () -> (i32)
# %bb.0:
	i32.const	1
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.canonical_layout_end,"R",@
	.hidden	canonical_layout_end            # -- Begin function canonical_layout_end
	.globl	canonical_layout_end
	.type	canonical_layout_end,@function
canonical_layout_end:                   # @canonical_layout_end
	.functype	canonical_layout_end () -> (i32)
# %bb.0:
	i32.const	8263840
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.canonical_max_rows,"R",@
	.hidden	canonical_max_rows              # -- Begin function canonical_max_rows
	.globl	canonical_max_rows
	.type	canonical_max_rows,@function
canonical_max_rows:                     # @canonical_max_rows
	.functype	canonical_max_rows () -> (i32)
# %bb.0:
	i32.const	100000
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.canonical_prefix_bytes,"R",@
	.hidden	canonical_prefix_bytes          # -- Begin function canonical_prefix_bytes
	.globl	canonical_prefix_bytes
	.type	canonical_prefix_bytes,@function
canonical_prefix_bytes:                 # @canonical_prefix_bytes
	.functype	canonical_prefix_bytes () -> (i32)
# %bb.0:
	i32.const	8388608
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.scan_canonical,"R",@
	.hidden	scan_canonical                  # -- Begin function scan_canonical
	.globl	scan_canonical
	.type	scan_canonical,@function
scan_canonical:                         # @scan_canonical
	.functype	scan_canonical () -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i64, i64, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	memory.size	0
	local.set	0
	i32.const	0
	i32.const	0
	i32.store	1048
	i32.const	0
	i32.const	0
	i32.store	1040
	i32.const	0
	i32.const	0
	i32.store	1036
	i32.const	0
	i32.const	0
	i32.store	1032
	i32.const	0
	i32.const	0
	i32.store	1024
	i32.const	0
	i32.const	0
	i32.load	1148
	i32.store	1028
	i32.const	0
	i32.const	0
	i32.load	1132
	local.tee	1
	i32.store	1044
	i32.const	-1
	local.set	2
	block   	
	i32.const	0
	i32.load	1136
	local.tee	3
	i32.const	100000
	i32.gt_u
	br_if   	0                               # 0: down to label0
# %bb.1:
	i32.const	0
	i32.load	1144
	local.tee	4
	i32.const	0
	i32.load	1140
	local.tee	5
	i32.lt_u
	br_if   	0                               # 0: down to label0
# %bb.2:
	local.get	4
	local.get	5
	i32.sub 
	local.tee	4
	i32.const	100000
	i32.gt_u
	br_if   	0                               # 0: down to label0
# %bb.3:
	i32.const	0
	i32.load	1148
	local.tee	6
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label0
# %bb.4:
	i32.const	0
	i32.load	1092
	local.tee	7
	i32.eqz
	br_if   	0                               # 0: down to label0
# %bb.5:
	i32.const	-1
	local.set	2
	local.get	7
	local.get	7
	i32.const	-1
	i32.add 
	i32.and 
	br_if   	0                               # 0: down to label0
# %bb.6:
	local.get	0
	i32.const	128
	i32.lt_u
	br_if   	0                               # 0: down to label0
# %bb.7:
	i32.const	0
	i32.load	1096
	local.tee	8
	i32.const	8388608
	i32.lt_u
	br_if   	0                               # 0: down to label0
# %bb.8:
	local.get	8
	i32.const	3
	i32.and 
	br_if   	0                               # 0: down to label0
# %bb.9:
	i32.const	0
	i32.load	1128
	local.tee	9
	i64.extend_i32_u
	local.tee	10
	i64.const	2
	i64.shl 
	local.tee	11
	local.get	8
	i64.extend_i32_u
	i64.add 
	local.get	0
	i64.extend_i32_u
	i64.const	16
	i64.shl 
	local.tee	12
	i64.gt_u
	br_if   	0                               # 0: down to label0
# %bb.10:
	i32.const	0
	i32.load	1100
	local.tee	0
	i32.const	8388608
	i32.lt_u
	br_if   	0                               # 0: down to label0
# %bb.11:
	local.get	0
	i32.const	3
	i32.and 
	br_if   	0                               # 0: down to label0
# %bb.12:
	local.get	11
	local.get	0
	i64.extend_i32_u
	i64.add 
	local.get	12
	i64.gt_u
	br_if   	0                               # 0: down to label0
# %bb.13:
	i32.const	0
	i32.load	1104
	local.tee	13
	i32.const	8388608
	i32.lt_u
	br_if   	0                               # 0: down to label0
# %bb.14:
	local.get	10
	local.get	13
	i64.extend_i32_u
	i64.add 
	local.get	12
	i64.gt_u
	br_if   	0                               # 0: down to label0
# %bb.15:
	i32.const	0
	i32.load	1108
	local.tee	14
	i32.const	8388608
	i32.lt_u
	br_if   	0                               # 0: down to label0
# %bb.16:
	local.get	14
	i32.const	3
	i32.and 
	br_if   	0                               # 0: down to label0
# %bb.17:
	local.get	11
	local.get	14
	i64.extend_i32_u
	i64.add 
	local.get	12
	i64.gt_u
	br_if   	0                               # 0: down to label0
# %bb.18:
	i32.const	0
	i32.load	1112
	local.tee	15
	i32.const	8388608
	i32.lt_u
	br_if   	0                               # 0: down to label0
# %bb.19:
	local.get	10
	local.get	15
	i64.extend_i32_u
	i64.add 
	local.get	12
	i64.gt_u
	br_if   	0                               # 0: down to label0
# %bb.20:
	i32.const	0
	i32.load	1116
	local.tee	16
	i32.const	8388608
	i32.lt_u
	br_if   	0                               # 0: down to label0
# %bb.21:
	local.get	16
	i32.const	3
	i32.and 
	br_if   	0                               # 0: down to label0
# %bb.22:
	local.get	11
	local.get	16
	i64.extend_i32_u
	i64.add 
	local.get	12
	i64.gt_u
	br_if   	0                               # 0: down to label0
# %bb.23:
	i32.const	0
	i32.load	1120
	local.tee	17
	i32.const	8388608
	i32.lt_u
	br_if   	0                               # 0: down to label0
# %bb.24:
	local.get	17
	i32.const	3
	i32.and 
	br_if   	0                               # 0: down to label0
# %bb.25:
	local.get	11
	local.get	17
	i64.extend_i32_u
	i64.add 
	local.get	12
	i64.gt_u
	br_if   	0                               # 0: down to label0
# %bb.26:
	i32.const	0
	i32.load	1124
	local.tee	18
	i32.const	8388608
	i32.lt_u
	br_if   	0                               # 0: down to label0
# %bb.27:
	local.get	18
	i32.const	3
	i32.and 
	br_if   	0                               # 0: down to label0
# %bb.28:
	local.get	11
	local.get	18
	i64.extend_i32_u
	i64.add 
	local.get	12
	i64.gt_u
	br_if   	0                               # 0: down to label0
# %bb.29:
	i32.const	0
	i32.load	1088
	local.tee	19
	i32.const	8388608
	i32.lt_u
	br_if   	0                               # 0: down to label0
# %bb.30:
	local.get	19
	i32.const	3
	i32.and 
	br_if   	0                               # 0: down to label0
# %bb.31:
	local.get	7
	i64.extend_i32_u
	i64.const	2
	i64.shl 
	local.get	19
	i64.extend_i32_u
	i64.add 
	local.get	12
	i64.gt_u
	br_if   	0                               # 0: down to label0
# %bb.32:
	local.get	1
	local.get	9
	i32.gt_u
	br_if   	0                               # 0: down to label0
# %bb.33:
	i32.const	0
	local.set	2
	local.get	6
	local.get	4
	i32.ge_u
	br_if   	0                               # 0: down to label0
# %bb.34:
	local.get	7
	i32.const	-1
	i32.add 
	local.set	20
	i32.const	0
	i32.load	1172
	local.set	21
	i32.const	0
	i32.load	1152
	local.set	22
	i32.const	0
	i64.load32_u	1160
	local.set	11
	i32.const	0
	i64.load32_u	1156
	local.set	10
	i32.const	0
	i32.load	1168
	local.set	23
	i32.const	0
	i32.load	1164
	local.set	24
.LBB4_35:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB4_46 Depth 2
                                        #     Child Loop BB4_53 Depth 2
	loop    	                                # label1:
	i32.const	-2
	local.set	2
	local.get	6
	local.tee	25
	i32.const	2
	i32.shl 
	i32.load	2131072
	local.tee	1
	local.get	22
	i32.lt_u
	br_if   	1                               # 1: down to label0
# %bb.36:                               #   in Loop: Header=BB4_35 Depth=1
	local.get	1
	local.get	22
	i32.sub 
	local.tee	1
	local.get	3
	i32.ge_u
	br_if   	1                               # 1: down to label0
# %bb.37:                               #   in Loop: Header=BB4_35 Depth=1
	local.get	1
	i32.const	2
	i32.shl 
	i32.load	1731072
	local.get	25
	local.get	5
	i32.add 
	local.tee	26
	i32.ne  
	br_if   	1                               # 1: down to label0
# %bb.38:                               #   in Loop: Header=BB4_35 Depth=1
	i32.const	0
	local.get	25
	i32.const	1
	i32.add 
	local.tee	6
	i32.store	1028
	block   	
	block   	
	local.get	25
	i32.load8_u	3731072
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label3
# %bb.39:                               #   in Loop: Header=BB4_35 Depth=1
	i32.const	0
	i32.const	0
	i32.load	1040
	i32.const	1
	i32.add 
	i32.store	1040
	br      	1                               # 1: down to label2
.LBB4_40:                               #   in Loop: Header=BB4_35 Depth=1
	end_block                               # label3:
	i32.const	-3
	local.set	2
	local.get	1
	i32.const	4
	i32.shl 
	local.tee	1
	i64.load32_u	131072
	local.get	10
	i64.add 
	local.tee	12
	local.get	1
	i32.load	131076
	local.tee	27
	i64.extend_i32_u
	i64.add 
	local.get	11
	i64.gt_u
	br_if   	2                               # 2: down to label0
# %bb.41:                               #   in Loop: Header=BB4_35 Depth=1
	local.get	12
	i64.const	4294967295
	i64.gt_u
	br_if   	2                               # 2: down to label0
# %bb.42:                               #   in Loop: Header=BB4_35 Depth=1
	block   	
	block   	
	block   	
	block   	
	local.get	19
	local.get	1
	i32.load	131084
	local.tee	28
	i32.const	-1640531535
	i32.mul 
	local.get	1
	i32.load	131080
	local.tee	29
	i32.xor 
	local.tee	2
	i32.const	16
	i32.shr_u
	local.get	2
	i32.xor 
	local.get	20
	i32.and 
	local.tee	1
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	30
	br_if   	0                               # 0: down to label7
# %bb.43:                               #   in Loop: Header=BB4_35 Depth=1
	i32.const	0
	local.set	31
	br      	1                               # 1: down to label6
.LBB4_44:                               #   in Loop: Header=BB4_35 Depth=1
	end_block                               # label7:
	block   	
	local.get	24
	i32.eqz
	br_if   	0                               # 0: down to label8
# %bb.45:                               #   in Loop: Header=BB4_35 Depth=1
	i32.const	0
	local.set	31
	local.get	7
	local.set	32
.LBB4_46:                               #   Parent Loop BB4_35 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label9:
	i32.const	-4
	local.set	2
	local.get	30
	i32.const	-1
	i32.add 
	local.tee	30
	local.get	9
	i32.ge_u
	br_if   	7                               # 7: down to label0
# %bb.47:                               #   in Loop: Header=BB4_46 Depth=2
	local.get	32
	i32.const	-1
	i32.add 
	local.tee	32
	i32.eqz
	br_if   	7                               # 7: down to label0
# %bb.48:                               #   in Loop: Header=BB4_46 Depth=2
	block   	
	local.get	8
	local.get	30
	i32.const	2
	i32.shl 
	local.tee	2
	i32.add 
	i32.load	0
	local.get	29
	i32.ne  
	br_if   	0                               # 0: down to label10
# %bb.49:                               #   in Loop: Header=BB4_46 Depth=2
	local.get	0
	local.get	2
	i32.add 
	i32.load	0
	local.get	28
	i32.ne  
	br_if   	0                               # 0: down to label10
# %bb.50:                               #   in Loop: Header=BB4_46 Depth=2
	i32.const	1
	local.set	31
	local.get	13
	local.get	30
	i32.add 
	i32.load8_u	0
	i32.const	1
	i32.eq  
	br_if   	4                               # 4: down to label5
.LBB4_51:                               #   in Loop: Header=BB4_46 Depth=2
	end_block                               # label10:
	local.get	19
	local.get	1
	i32.const	1
	i32.add 
	local.get	20
	i32.and 
	local.tee	1
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	30
	br_if   	0                               # 0: up to label9
	br      	2                               # 2: down to label6
.LBB4_52:                               #   in Loop: Header=BB4_35 Depth=1
	end_loop
	end_block                               # label8:
	i32.const	0
	local.set	31
	local.get	7
	local.set	32
.LBB4_53:                               #   Parent Loop BB4_35 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label11:
	i32.const	-4
	local.set	2
	local.get	30
	i32.const	-1
	i32.add 
	local.tee	30
	local.get	9
	i32.ge_u
	br_if   	6                               # 6: down to label0
# %bb.54:                               #   in Loop: Header=BB4_53 Depth=2
	local.get	32
	i32.const	-1
	i32.add 
	local.tee	32
	i32.eqz
	br_if   	6                               # 6: down to label0
# %bb.55:                               #   in Loop: Header=BB4_53 Depth=2
	block   	
	local.get	8
	local.get	30
	i32.const	2
	i32.shl 
	local.tee	2
	i32.add 
	i32.load	0
	local.get	29
	i32.ne  
	br_if   	0                               # 0: down to label12
# %bb.56:                               #   in Loop: Header=BB4_53 Depth=2
	i32.const	1
	local.get	31
	local.get	0
	local.get	2
	i32.add 
	i32.load	0
	local.get	28
	i32.eq  
	i32.select
	local.set	31
.LBB4_57:                               #   in Loop: Header=BB4_53 Depth=2
	end_block                               # label12:
	local.get	19
	local.get	1
	i32.const	1
	i32.add 
	local.get	20
	i32.and 
	local.tee	1
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	30
	br_if   	0                               # 0: up to label11
.LBB4_58:                               #   in Loop: Header=BB4_35 Depth=1
	end_loop
	end_block                               # label6:
	i32.const	-1
	local.set	30
	block   	
	local.get	23
	i32.eqz
	br_if   	0                               # 0: down to label13
# %bb.59:                               #   in Loop: Header=BB4_35 Depth=1
	local.get	31
	br_if   	0                               # 0: down to label13
# %bb.60:                               #   in Loop: Header=BB4_35 Depth=1
	i32.const	-5
	local.set	2
	i32.const	0
	i32.load	1044
	local.tee	30
	local.get	9
	i32.ge_u
	br_if   	5                               # 5: down to label0
# %bb.61:                               #   in Loop: Header=BB4_35 Depth=1
	local.get	27
	i32.const	-1
	i32.eq  
	br_if   	5                               # 5: down to label0
# %bb.62:                               #   in Loop: Header=BB4_35 Depth=1
	local.get	13
	local.get	30
	i32.add 
	local.tee	32
	i32.load8_u	0
	i32.const	255
	i32.and 
	br_if   	5                               # 5: down to label0
# %bb.63:                               #   in Loop: Header=BB4_35 Depth=1
	i32.const	0
	i32.load	1024
	local.tee	31
	i32.const	12
	i32.mul 
	local.tee	2
	local.get	1
	i32.store	6231072
	local.get	19
	local.get	1
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	33
	i32.load	0
	local.set	1
	local.get	2
	i32.const	6231080
	i32.add 
	local.get	30
	i32.store	0
	local.get	2
	i32.const	6231076
	i32.add 
	local.get	1
	i32.store	0
	i32.const	0
	local.get	31
	i32.const	1
	i32.add 
	i32.store	1024
	#APP
	#NO_APP
	local.get	8
	local.get	30
	i32.const	2
	i32.shl 
	local.tee	2
	i32.add 
	local.get	29
	i32.store	0
	local.get	0
	local.get	2
	i32.add 
	local.get	28
	i32.store	0
	local.get	14
	local.get	2
	i32.add 
	local.get	27
	i32.store	0
	local.get	16
	local.get	2
	i32.add 
	local.get	25
	i32.const	12
	i32.mul 
	local.tee	1
	i32.load	2531072
	i32.store	0
	local.get	17
	local.get	2
	i32.add 
	local.get	1
	i32.const	2531076
	i32.add 
	i32.load	0
	i32.store	0
	local.get	18
	local.get	2
	i32.add 
	local.get	1
	i32.const	2531080
	i32.add 
	i32.load	0
	i32.store	0
	local.get	15
	local.get	30
	i32.add 
	i32.const	1
	i32.store8	0
	local.get	32
	i32.const	2
	i32.store8	0
	local.get	33
	local.get	30
	i32.const	1
	i32.add 
	local.tee	2
	i32.store	0
	i32.const	0
	local.get	2
	i32.store	1044
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label13
# %bb.64:                               #   in Loop: Header=BB4_35 Depth=1
	i32.const	0
	i32.load	1024
	local.get	21
	i32.eq  
	br_if   	2                               # 2: down to label4
.LBB4_65:                               #   in Loop: Header=BB4_35 Depth=1
	end_block                               # label13:
	i32.const	0
	i32.const	0
	i32.load	1032
	local.tee	2
	i32.const	1
	i32.add 
	i32.store	1032
	local.get	2
	i32.const	2
	i32.shl 
	local.tee	2
	i32.const	5831072
	i32.add 
	local.get	30
	i32.store	0
	local.get	2
	i32.const	5431072
	i32.add 
	local.get	26
	i32.store	0
	local.get	2
	i32.const	5031072
	i32.add 
	local.get	28
	i32.store	0
	local.get	2
	i32.const	4631072
	i32.add 
	local.get	29
	i32.store	0
	local.get	2
	i32.const	4231072
	i32.add 
	local.get	27
	i32.store	0
	local.get	2
	local.get	12
	i64.store32	3831072
	br      	2                               # 2: down to label2
.LBB4_66:                               #   in Loop: Header=BB4_35 Depth=1
	end_block                               # label5:
	i32.const	0
	i32.load	1036
	local.tee	1
	i32.const	3
	i32.shl 
	local.tee	2
	local.get	30
	i32.store	7431076
	local.get	2
	local.get	25
	i32.store	7431072
	i32.const	1
	local.set	2
	i32.const	0
	local.get	1
	i32.const	1
	i32.add 
	i32.store	1036
	i32.const	0
	i32.load	1036
	i32.const	4096
	i32.ne  
	br_if   	1                               # 1: down to label2
	br      	3                               # 3: down to label0
.LBB4_67:
	end_block                               # label4:
	unreachable
.LBB4_68:                               #   in Loop: Header=BB4_35 Depth=1
	end_block                               # label2:
	i32.const	0
	local.set	2
	local.get	6
	local.get	4
	i32.lt_u
	br_if   	0                               # 0: up to label1
.LBB4_69:
	end_loop
	end_block                               # label0:
	local.get	2
                                        # fallthrough-return
	end_function
                                        # -- End function
	.no_dead_strip	canonical_abi_version
	.no_dead_strip	canonical_layout_end
	.no_dead_strip	canonical_max_rows
	.no_dead_strip	canonical_prefix_bytes
	.no_dead_strip	scan_canonical
	.ident	"Debian clang version 21.1.8 (++20251221032947+2078da43e25a-1~exp1~20251221153113.67)"
	.no_dead_strip	__indirect_function_table
	.section	.custom_section.producers,"",@
	.int8	1
	.int8	12
	.ascii	"processed-by"
	.int8	1
	.int8	12
	.ascii	"Debian clang"
	.int8	63
	.ascii	"21.1.8 (++20251221032947+2078da43e25a-1~exp1~20251221153113.67)"
	.section	.text.scan_canonical,"R",@
	.section	.custom_section.target_features,"",@
	.int8	8
	.int8	43
	.int8	11
	.ascii	"bulk-memory"
	.int8	43
	.int8	15
	.ascii	"bulk-memory-opt"
	.int8	43
	.int8	22
	.ascii	"call-indirect-overlong"
	.int8	43
	.int8	10
	.ascii	"multivalue"
	.int8	43
	.int8	15
	.ascii	"mutable-globals"
	.int8	43
	.int8	19
	.ascii	"nontrapping-fptoint"
	.int8	43
	.int8	15
	.ascii	"reference-types"
	.int8	43
	.int8	8
	.ascii	"sign-ext"
	.section	.text.scan_canonical,"R",@
