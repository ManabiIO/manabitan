/*
 * Copyright (C) 2026 Manabitan authors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
/* eslint @stylistic/semi: ["error", "never"] */

import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {createReadStream, openAsBlob} from 'node:fs'
import {readFile, writeFile} from 'node:fs/promises'
import {join, resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
import {performance} from 'node:perf_hooks'
import {BlobReader, Uint8ArrayWriter, ZipReader} from '@zip.js/zip.js'

// Bounded component follow-up after the parallel harness was killed before
// output. Parse one complete source bank at a time without workers. Actual
// record encoders and sidecar builder use deterministic native-content spans,
// not compressed physical offsets. Timing begins after the ZIP reader closes.
const [parentPath, candidatePath, cachePath, outputPath, dictionary = 'jmdict', cpus = '4', memory = '8'] = process.argv.slice(2)
assert(parentPath && candidatePath && cachePath && outputPath)
const parentRoot = resolve(parentPath)
const candidateRoot = resolve(candidatePath)
// The CLI explicitly selects the two local source trees to compare.
// eslint-disable-next-line no-unsanitized/method
const localImport = (root, filename) => import(pathToFileURL(join(root, filename)))
const parser = await localImport(candidateRoot, 'ext/js/dictionary/term-bank-wasm-parser.js')
const parents = await localImport(parentRoot, 'ext/js/dictionary/term-record-opfs-store.js')
const candidates = await localImport(candidateRoot, 'ext/js/dictionary/term-record-opfs-store.js')
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const lockBytes = await readFile(join(candidateRoot, 'test/perf/dictionaries.lock.json'))
assert.deepEqual(lockBytes, await readFile(join(parentRoot, 'test/perf/dictionaries.lock.json')))
const fixture = JSON.parse(lockBytes).dictionaries[dictionary]
assert(fixture)
const archivePath = join(cachePath, fixture.cacheFile)
const archiveHash = createHash('sha256')
for await (const bytes of createReadStream(archivePath)) { archiveHash.update(bytes) }
assert.equal(archiveHash.digest('hex'), fixture.sha256)
const archive = await openAsBlob(archivePath)
assert.equal(archive.size, fixture.sizeBytes)
const wasm = await readFile(join(candidateRoot, 'ext/lib/term-bank-parser.wasm'))
assert.deepEqual(wasm, await readFile(join(parentRoot, 'ext/lib/term-bank-parser.wasm')))
parser.setTermBankWasmModule(await WebAssembly.compile(wasm))

const sourceGroups = []
const timingInputs = []
const sourceHashes = {}
for (const [name, sourceRoot] of [['parent', parentRoot], ['candidate', candidateRoot]]) {
    sourceHashes[name] = sha(await readFile(join(sourceRoot, 'ext/js/dictionary/term-record-opfs-store.js')))
}
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: 1, deviceMemory: 4}})

const reader = new ZipReader(new BlobReader(archive))
const entries = await reader.getEntries()
const termFiles = entries.filter(({filename}) => /^term_bank_\d+\.json$/.test(filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
const groups = []
const profiles = []
const fullDigest = createHash('sha256')
let rowCount = 0
let contentBase = 2 ** 40

async function encode(module, chunk, offsets, lengths) {
    const store = new module.TermRecordOpfsStore()
    const writes = []
    const envelopes = []
    store._appendEncodedChunk = async (...args) => {
        writes.push(args.slice(1, 8))
        envelopes.push(store._createLookupIndexChunk(...args.slice(1, 3), ...args.slice(4, 8)))
    }
    const recordChunk = module.createArtifactTermRecordChunkWithResolvedContent(
        {...chunk, dictionary: fixture.expectedTitle},
        chunk.contentUniqueIndexList,
        offsets,
        lengths,
        chunk.preparedLookupIndexes,
    )
    await store._encodeAndAppendArtifactChunkForState({}, recordChunk, rowCount + 1, new Float64Array(0), new Uint32Array(0), chunk.termRecordPreinternedPlan, 'raw', chunk.preparedLookupIndexes)
    return {writes, envelopes}
}

async function consume(chunk) {
    const plan = chunk.contentDedupPlan
    assert(plan && chunk.contentUniqueIndexList && chunk.contentMetaList)
    const offsets = new Float64Array(plan.uniqueCount)
    const lengths = new Uint32Array(plan.uniqueCount)
    for (let i = 0; i < plan.uniqueCount; ++i) {
        const meta = (chunk.contentMetaByUniqueIndex ? i : plan.uniqueRowIndexes[i]) * 4
        offsets[i] = contentBase + chunk.contentMetaList[meta]
        lengths[i] = chunk.contentMetaList[meta + 1]
    }
    const before = await encode(parents, chunk, offsets, lengths)
    const after = await encode(candidates, chunk, offsets, lengths)
    assert.deepEqual(after.writes, before.writes)
    assert.deepEqual(after.envelopes, before.envelopes)
    for (const envelope of after.envelopes) { fullDigest.update(envelope) }
    const compactScoreEntries = after.writes.reduce((sum, args) => sum + (args[6] === 2 ? args[1] : 0), 0)
    // Fixed selection before outcomes: first run of every tenth emitted group.
    // Keep only one source's immutable bytes; both arms consume those bytes.
    if (groups.length % 10 === 0 && after.writes[0]?.[6] === 2) {
        timingInputs.push(after.writes[0])
    }
    groups.push({rows: chunk.rowCount, prepared: [...chunk.preparedLookupIndexes.keys()], runRows: after.writes.map((args) => args[1]), compactScoreEntries})
    rowCount += chunk.rowCount
    contentBase += chunk.contentBytesLength ?? chunk.contentBytesBuffer.byteLength
    process.stderr.write(`${dictionary}: ${rowCount}/${fixture.termRows} rows\n`)
}

const media = fixture.mediaFiles > 0
const options = {
    emitTermByteLists: false,
    computeContentHashes: true,
    emitContentSlab: true,
    emitTokenBinaryContent: true,
    mediaHintFastScan: media,
    projectImagePaths: media,
    validateGlossaryTypes: true,
    prepareLookupIndexes: true,
    maxPendingChunks: 2,
}
let complete = false
let error = null
try {
    for (const file of termFiles) {
        const bytes = await file.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true})
        sourceGroups.push({files: [file.filename], bytes: [bytes.byteLength]})
        await parser.parseTermBankWithWasmColumnChunks(bytes, 3, consume, 2048, {...options, singleChunk: true})
        profiles.push(parser.consumeLastTermBankWasmParseProfile())
    }
    assert.equal(rowCount, fixture.termRows)
    complete = true
} catch (failure) {
    error = String(failure)
    throw failure
} finally {
    await parser.disposeParallelTermBankParser()
    await reader.close()
    const summary = {rows: 0, runs: 0, compactScoreEntries: 0}
    for (const group of groups) {
        summary.rows += group.rows
        summary.runs += group.runRows.length
        summary.compactScoreEntries += group.compactScoreEntries
    }
    const timing = complete ? await measureAfterDrain() : null
    const report = {
        complete,
        error,
        node: process.version,
        dictionary,
        hardwareConcurrency: Number(cpus),
        deviceMemory: Number(memory),
        fixture,
        lockSha256: sha(lockBytes),
        parserWasmSha256: sha(wasm),
        parentSourceSha256: sha(await readFile(join(parentRoot, 'ext/js/dictionary/term-record-opfs-store.js'))),
        candidateSourceSha256: sha(await readFile(join(candidateRoot, 'ext/js/dictionary/term-record-opfs-store.js'))),
        scope: 'Sequential one-bank native parser output through record encoders and sidecar envelope builder (bounded component fixture grouping; no production worker or grouping claim), with deterministic native-content spans and intercepted persistence. Component timings exclude parsing, compression, OPFS, browser/IPC, UI, and import completion; shared-host observations are exploratory only.',
        summary,
        timing,
        runnerSha256: sha(await readFile(new URL(import.meta.url))),
        encodedByteSha256: fullDigest.digest('hex'),
        groups,
        sourceGroups,
        profiles,
    }
    await writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'})
    console.log(JSON.stringify({complete, error, ...summary}))
}

// Expose the actual unmodified private production validator in this process.
// Only static relative import specifiers are absolutized for the data URL;
// the function body is not extracted, replaced, rewritten or specialized.
async function exposeValidator(sourceRoot) {
    const filename = join(sourceRoot, 'ext/js/dictionary/term-record-opfs-store.js')
    const source = await readFile(filename, 'utf8')
    const instrumented = source.replace(/(from\s+)(['"])(\.\.?\/[^'"]+)\2/g, (_all, prefix, quote, specifier) => `${prefix}${quote}${new URL(specifier, pathToFileURL(filename)).href}${quote}`) + '\nexport {parseCompactRecordFields as scoreValidation}\n'
    const loaded = await import(`data:text/javascript;base64,${Buffer.from(instrumented).toString('base64')}`)
    return loaded.scoreValidation
}

async function measureAfterDrain() {
    const validateA = await exposeValidator(parentRoot)
    const validateB = await exposeValidator(candidateRoot)
    const storeA = new parents.TermRecordOpfsStore()
    const storeB = new candidates.TermRecordOpfsStore()
    const compactRows = timingInputs.reduce((sum, args) => sum + args[1], 0)
    assert(compactRows > 0)
    const digest = createHash('sha256')
    const errors = []
    for (const args of timingInputs) {
        const [firstId, count, , base, payload, fields, format] = args
        assert.equal(format, 2)
        const before = validateA(fields, count)
        const after = validateB(fields, count)
        assert.deepEqual(after, before)
        assert.deepEqual(storeA._createLookupIndexChunk(firstId, count, base, payload, fields, format), storeB._createLookupIndexChunk(firstId, count, base, payload, fields, format))
        digest.update(fields)
        const corrupted = new Uint8Array(fields)
        const header = new Uint32Array(corrupted.buffer, 0, 4)
        const keys = new Uint16Array(corrupted.buffer, 16 + header[2] * 4 + count * 6, count)
        keys[count - 1] = header[2]
        let first
        let second
        try { validateA(corrupted, count) } catch (failure) { first = String(failure) }
        try { validateB(corrupted, count) } catch (failure) { second = String(failure) }
        assert.equal(first, 'Error: Compact term-record score key is invalid')
        assert.equal(second, first)
        errors.push(first)
    }
    const observations = []
    // The schedule is fixed before collection, preserving every observation.
    // C calls the exact baseline code with the same source fixtures as A.
    for (const boundary of ['validator', 'sidecar']) {
        const repeats = boundary === 'validator' ? 32 : 4
        const run = (arm) => {
            const validate = arm === 'B' ? validateB : validateA
            const store = arm === 'B' ? storeB : storeA
            let sink = 0
            const start = performance.now()
            for (let repetition = 0; repetition < repeats; ++repetition) {
                for (const [firstId, count, , base, payload, fields, format] of timingInputs) {
                    if (boundary === 'validator') {
                        const result = validate(fields, count)
                        sink += result.scoreKeys[count - 1]
                    } else {
                        const result = store._createLookupIndexChunk(firstId, count, base, payload, fields, format)
                        sink += result.byteLength
                    }
                }
            }
            return {elapsedMs: performance.now() - start, sink}
        }
        for (let warmup = 0; warmup < 2; ++warmup) {
            for (const arm of ['A', 'B', 'C']) { run(arm) }
        }
        for (let block = 0; block < 12; ++block) {
            const order = ['ABC', 'ACB', 'BAC', 'BCA', 'CAB', 'CBA'][block % 6]
            for (const arm of order) {
                observations.push({boundary, block, arm, repeats, rows: compactRows, ...run(arm)})
            }
        }
    }
    for (const [name, sourceRoot] of [['parent', parentRoot], ['candidate', candidateRoot]]) {
        assert.equal(sha(await readFile(join(sourceRoot, 'ext/js/dictionary/term-record-opfs-store.js'))), sourceHashes[name])
    }
    return {selection: 'first compact run of every tenth source bank', compactRows, inputs: timingInputs.length, fieldsSha256: digest.digest('hex'), equivalentBadIdErrors: errors.length, observations}
}
