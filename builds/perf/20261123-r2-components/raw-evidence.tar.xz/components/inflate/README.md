# Native DEFLATE SIMD copy screen, 2026-11-23

## Decision and scope

The full-byte oracle passed. The fixed local component screen does not support a reliable all-corpus improvement claim. VNDB was faster than the adjacent unchanged-control mean in all four triples, but the same-code controls drifted by a similar aggregate amount. JMdict and Jitendex were inconsistent across triples. This is a reason to qualify the frozen candidate in complete browser imports, not a demonstrated complete-import speedup.

Candidate local commit: `efb21934f2f988813118b085b90a146933a4f519`, based on `5e1f8c12f7ff798ba407323aff675cb23b22af02`. The parent published an identical tree as draft PR #812 at `5555f3efd3e0c8baa99e93b4c14e7f1889c30383`. No earlier parser or media candidate is included.

## Change and safety boundary

The WASM build uses two ordered 16-byte load/store pairs for DEFLATE matches whose backward distance is at least 16. Each store precedes the next load, preserving forward expansion at distances 16 through 31. The 32-byte step can overrun the logical match by at most 31 bytes, within the existing fast-loop guard. Smaller distances and the bounded generic tail retain the original implementation. Full compressed consumption, output length, CRC, malformed-input and trailing-byte checks are unchanged.

The baseline already enables `-msimd128`. No new WASM feature, threshold, worker setting, cache policy, compression setting, import flag or data format is introduced. The reproducible parser artifact grows from 54,596 to 54,658 bytes.

| Artifact | SHA-256 |
| --- | --- |
| Baseline parser WASM | `cc749c53fc32dfb28eefbd69f99868f8c303caa1a3f1354231516dfa5a6e1b0f` |
| Candidate parser WASM | `c9b2a31648d4e9fab93a7e89d527f031156ccaf36ee914c6182b7c37dff4a8c4` |
| Shared component harness | `92fb8eac24124d2f7dc6a914c9e65f893c823e3e9ed2f6f3cf6822a6f68ed86b` |

The exact Clang/LLD 21.1.8 rebuild check passed. Assembly inspection confirms ordered stores between the two loads. The two focused WASM suites passed all 86 tests, including controlled fast-loop distances through 32,768, lengths through 258, alignments, physical EOF boundaries, malformed streams, CRC faults and tails. Focused ESLint passed. Full repository CI is handled separately by the parent; this evidence bundle does not assert its outcome.

## Full-byte oracle

`oracle.json` records actual archive hashes, source/build hashes and framed output digests. Each source is inflated through both production wrappers and independently through Node zlib. Every output byte and per-bank span is compared. Every non-directory ZIP entry is covered, including all term banks and all other entries such as media, indexes and tags.

| Corpus | Entries | Uncompressed bytes compared | Output digest |
| --- | ---: | ---: | --- |
| JMdict | 55 | 171,110,164 | `6d3473707c7860e836dd6a04a5b9d4a5d3b5dc6aac52319e56558647cb5d7702` |
| Jitendex | 471 | 542,580,806 | `78cd42bd940cf84f54802b4b84d04c32b53a63e18500aaebb17375dc28e59b65` |
| VNDB | 147,237 | 4,456,124,609 | `5bdc59cab3c12f3c60cdcb014dc0fb2011f9eccec1bdbb5ab84e2e2150198dbc` |

The oracle was run before the final maximum-distance test addition and local commit. Its runtime source and WASM file hashes exactly match the committed source used for all screen arms. Its tracked-diff receipt records that earlier uncommitted state; it is not represented as having run at the later commit ID. The unchanged harness hash matches the complete screen.

Two initial preparation failures are retained: zip.js was initially given a Node Buffer whose `slice` semantics differ from plain Uint8Array, then the raw reader rejected the large VNDB archive as an ArrayBuffer under its production admission rule. The harness now supplies a plain Uint8Array to zip.js and a Blob to the raw reader for a large archive. Both fixes affect only untimed harness setup. No production admission or validation was changed. No timing observation existed before these corrections.

This oracle proves inflated archive bytes and boundaries. It does not test persisted database outputs, user lookups, restart behavior, browser memory or extension startup.

## Frozen local screen

`screen/plan.json` was written before timing. Four triples execute in the fixed order A/B/C, for 12 fresh Node 22.22.0 processes. A and C have identical baseline source and executable identities; B uses the frozen candidate. Every process retains one excluded complete warmup pass over all three corpora, then one measured pass over all three. All 12 arms succeeded. All 36 warmup corpus passes and 36 measured corpus passes remain available in the raw JSON files. No arm was repeated or dropped and no source or harness changed during the cohort.

Compressed term payloads are prepared outside the timer. The 12 JMdict, 22 Jitendex and 170 VNDB groups use the production byte-balancing rule and match prior three-worker Chromium receipts. The native timer includes DEFLATE, full CRC and bank array-boundary checks. A separate wrapper timer includes allocation, metadata and compressed-input copies. Both exclude source I/O, hash validation, module loading/compilation, independent output comparison, parsing, worker transfer, persistence and UI. Groups run sequentially in the component process; this is not the production multiworker execution topology.

All percentages below are time changes: `100 * (candidate/reference - 1)`, so negative is faster. Equal-work ratios compare summed measured milliseconds. Candidate reference is the mean of A and C within each triple.

| Corpus | Native median | Native equal work | Wrapper median | Wrapper equal work | Native unchanged C/A equal work |
| --- | ---: | ---: | ---: | ---: | ---: |
| JMdict | -1.971% | -1.756% | -1.628% | -1.491% | -6.041% |
| Jitendex | -4.316% | -2.777% | -4.322% | -2.433% | +1.706% |
| VNDB | -8.107% | -7.791% | -8.017% | -7.740% | +7.918% |

| Corpus | Native candidate changes, all four triples | Native unchanged C/A changes, all four triples |
| --- | --- | --- |
| JMdict | +0.168%, -6.338%, -4.110%, +3.524% | -4.110%, -8.632%, -2.451%, -8.749% |
| Jitendex | -3.120%, -5.512%, -6.143%, +3.962% | -6.134%, +4.776%, +4.483%, +4.089% |
| VNDB | -7.770%, -8.444%, -13.533%, -0.684% | -3.028%, +10.395%, +19.321%, +4.949% |

`analyze-screen.py` validates all receipt hashes, source identities, corpus layouts, warmup labels, per-group sums and successful exits before deriving `screen/summary.json`. The summary also preserves each arm's absolute times and separate B/A and B/C comparisons.

## Reproduction

Provide clean baseline and candidate worktrees with their matching `ext/lib` assets, the pinned archives, and Node 22.22.0. The scripts use explicit paths; no current working directory is required.

```sh
NODE=/path/to/node-v22.22.0/bin/node
BASELINE=/path/to/baseline
CANDIDATE=/path/to/candidate
FIXTURES=/path/to/pinned-archives
"$NODE" inflate-component.mjs oracle "$BASELINE" "$CANDIDATE" "$FIXTURES" oracle-new.json
python3 run-screen.py "$NODE" "$BASELINE" "$CANDIDATE" "$FIXTURES" screen-new
python3 analyze-screen.py screen-new
```

The screen refuses to overwrite an existing plan. Source identities and harness hashes are checked after every arm. A failed arm terminates the fixed cohort and leaves its log and all prior observations intact.
