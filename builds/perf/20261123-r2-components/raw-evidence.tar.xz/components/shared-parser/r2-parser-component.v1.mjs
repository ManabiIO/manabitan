import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {createReadStream, openAsBlob} from 'node:fs'
import {readFile, writeFile} from 'node:fs/promises'
import {execFileSync} from 'node:child_process'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
import {performance} from 'node:perf_hooks'

const [mode, dictionary, baselineRoot, candidateRoot, archivePath, outputPath, sampleCountValue = '0'] = process.argv.slice(2)
assert.ok(mode === 'oracle' || mode === 'measure')
assert.equal(process.version, 'v22.22.0')
const fixtureLock = JSON.parse(await readFile(path.join(baselineRoot, 'test/perf/dictionaries.lock.json'), 'utf8'))
const fixture = dictionary === 'vndb' ? {
    sha256: 'da5baed5332761513dcef8d0b07ad0d9201cdd7f37831dea37e7162994ec3792',
    sizeBytes: 291705969, termRows: 6648310,
} : fixtureLock.dictionaries[dictionary]
assert.ok(fixture && ['jmdict', 'jitendex', 'vndb'].includes(dictionary))
const corpus = {
    jmdict: {banks: 53, sourceBytes: 171092992, groups: 12},
    jitendex: {banks: 218, sourceBytes: 537538792, groups: 22},
    vndb: {banks: 665, sourceBytes: 4267992967, groups: 170},
}[dictionary]
const runnerPath = new URL(import.meta.url)
const runnerSha256 = createHash('sha256').update(await readFile(runnerPath)).digest('hex')
const sampleCount = Number(sampleCountValue)
const options = {
    emitContentSlab: true,
    emitTokenBinaryContent: true,
    emitTermByteLists: false,
    mediaHintFastScan: false,
    projectImagePaths: false,
    validateGlossaryTypes: true,
    computeContentHashes: true,
    prepareLookupIndexes: true,
    experimentalNativeEscapedKeys: false,
    ownContentBytes: false,
    maxPendingChunks: 1,
    singleChunk: true,
}

async function loadParser(root) {
    const parser = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-bank-wasm-parser.js')))
    const lookup = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-lookup-index-preparation.js')))
    const experiments = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-bank-experiments.js')))
    const ownership = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-content-ownership.js')))
    const bytes = await readFile(path.join(root, 'ext/lib/term-bank-parser.wasm'))
    parser.setTermBankWasmModule(await WebAssembly.compile(bytes))
    return {parser, lookup, experiments, ownership, wasmSha256: createHash('sha256').update(bytes).digest('hex')}
}

async function sourceIdentity(root) {
    const files = {}
    for (const name of ['ext/js/dictionary/term-bank-wasm-parser.js', 'ext/js/dictionary/term-lookup-index-preparation.js',
        'ext/js/dictionary/term-bank-experiments.js', 'ext/js/dictionary/dictionary-image-references.js',
        'ext/js/dictionary/term-bank-source-pipeline.js', 'ext/js/dictionary/dense-zip-directory.js',
        'ext/js/dictionary/term-content-ownership.js', 'ext/js/media/media-util.js',
        'ext/js/dictionary/term-lookup-index.js', 'ext/js/dictionary/term-record-preinterned-plan.js',
        'ext/js/dictionary/wasm/term-bank-parser.c', 'dev/data/dictionary-wasm/manifest.json',
        'ext/lib/term-bank-parser.wasm', 'package-lock.json', 'test/perf/dictionaries.lock.json']) {
        files[name] = createHash('sha256').update(await readFile(path.join(root, name))).digest('hex')
    }
    return {root, head: execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim(), files}
}

const identities = [await sourceIdentity(baselineRoot), await sourceIdentity(candidateRoot)]
const archiveHash = createHash('sha256')
for await (const bytes of createReadStream(archivePath)) archiveHash.update(bytes)
const fixtureSha256 = archiveHash.digest('hex')
assert.equal(fixtureSha256, fixture.sha256)

const baseline = await loadParser(baselineRoot)
const candidate = mode === 'oracle' ? await loadParser(candidateRoot) : baseline
// Each arm uses its own pinned binary; changed native code is an intended source comparison.
const {readDenseZipDirectory} = await import(pathToFileURL(path.join(baselineRoot, 'ext/js/dictionary/dense-zip-directory.js')))
const {RawZipPayloadReader} = await import(pathToFileURL(path.join(baselineRoot, 'ext/js/dictionary/term-bank-source-pipeline.js')))
const {getImageMediaTypeFromFileName} = await import(pathToFileURL(path.join(baselineRoot, 'ext/js/media/media-util.js')))
const archive = await openAsBlob(archivePath)
assert.equal(archive.size, fixture.sizeBytes)
let directory = await readDenseZipDirectory(archive)
let directoryReader = 'dense-zip'
if (directory === null) {
    const {ZipReader, BlobReader} = await import(pathToFileURL(path.join(baselineRoot, 'node_modules/@zip.js/zip.js/index.js')))
    const zip = new ZipReader(new BlobReader(archive), {useWebWorkers: false})
    try { directory = await zip.getEntries() } finally { await zip.close() }
    directoryReader = 'zip.js'
}
assert.ok(directory)
const mediaPipeline = directory.some(({filename}) => getImageMediaTypeFromFileName(filename) !== null)
options.mediaHintFastScan = mediaPipeline
options.projectImagePaths = mediaPipeline
options.ownContentBytes = mediaPipeline && corpus.sourceBytes >= 512 * 1024 * 1024
options.experimentalNativeEscapedKeys = options.ownContentBytes
const banks = directory.filter(({filename}) => /^term_bank_\d+\.json$/.test(filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
assert.equal(banks.length, corpus.banks)
const reader = new RawZipPayloadReader(archive)
const signal = new AbortController().signal
const totalBytes = banks.reduce((sum, bank) => sum + bank.uncompressedSize, 0)
assert.equal(totalBytes, corpus.sourceBytes)
// Captured production group counts on the fixed three-parser-worker hosted cells.
// This serial component uses their byte-balanced partitions; it does not emulate worker overlap.
const groupCount = corpus.groups
const groups = []
let start = 0
let consumedBytes = 0
for (let i = 0; i < groupCount - 1; ++i) {
    const remainingGroups = groupCount - i
    const targetBytes = (totalBytes - consumedBytes) / remainingGroups
    let end = start + 1
    let bytes = banks[start].uncompressedSize
    const maxEnd = banks.length - (remainingGroups - 1)
    while (end < maxEnd) {
        const nextBytes = bytes + banks[end].uncompressedSize
        if (Math.abs(nextBytes - targetBytes) > Math.abs(bytes - targetBytes)) break
        bytes = nextBytes
        ++end
    }
    groups.push(banks.slice(start, end))
    start = end
    consumedBytes += bytes
}
groups.push(banks.slice(start))
const selected = sampleCount > 0 && sampleCount < groups.length ?
    Array.from({length: sampleCount}, (_, i) => Math.floor(i * (groups.length - 1) / Math.max(1, sampleCount - 1))) :
    groups.map((_, i) => i)

function hashChunk(chunk) {
    const hash = createHash('sha256')
    function append(value) {
        if (ArrayBuffer.isView(value)) {
            hash.update(`${value.constructor.name}:${value.byteLength}:`)
            hash.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength))
        } else if (Array.isArray(value)) {
            hash.update(`Array:${value.length}:`)
            for (const item of value) append(item)
        } else if (value instanceof Map) {
            hash.update(`Map:${value.size}:`)
            for (const [key, item] of value) {
                append(key)
                append(item)
            }
            hash.update('EndMap:')
        } else if (value !== null && typeof value === 'object') {
            const keys = Object.keys(value).sort()
            hash.update(`Object:${keys.length}:`)
            for (const key of keys) {
                append(key)
                append(value[key])
            }
            hash.update('EndObject:')
        } else {
            hash.update(`${typeof value}:${JSON.stringify(value)}:`)
        }
    }
    for (const key of [
        'rowCount', 'contentRowStart', 'expressionBytesList', 'readingBytesList',
        'readingEqualsExpressionList', 'scoreList', 'sequenceList', 'contentBytesList',
        'contentHash1List', 'contentHash2List', 'contentBytesBuffer', 'contentBytesBaseOffset',
        'contentBytesLength', 'contentMetaList', 'contentUniqueIndexList',
        'contentDedupPlan', 'useResolvedContentReferences', 'termRecordPreinternedPlan', 'preparedLookupIndexes', 'mediaRows',
    ]) {
        append(key)
        append(chunk[key])
    }
    return hash.digest('hex')
}

async function parseGroup(loaded, sources) {
    const started = performance.now()
    const preloadedSource = await loaded.parser.inflateCompressedTermBankSourcesWasm(sources, options)
    let stable = null
    let nativePrepared = false
    let sourceChunk = null
    let borrowedContent = false
    await loaded.parser.parseTermBankWithWasmColumnChunks(new Uint8Array(0), 3, (chunk) => {
        assert.equal(stable, null)
        sourceChunk = chunk
        nativePrepared = chunk.preparedLookupIndexes instanceof Map
        const ownCacheableContent = !options.ownContentBytes &&
            loaded.ownership.shouldOwnTermContentBytes(chunk.contentBytesLength,
                chunk.contentDedupPlan?.uniqueCount, chunk.contentDedupPlan?.sourceRowCount, chunk.rowCount)
        stable = loaded.parser.copyWasmBackedColumnChunk(chunk, !options.ownContentBytes, options.projectImagePaths)
        if (ownCacheableContent && stable.contentBytesBuffer instanceof Uint8Array &&
            stable.contentBytesBuffer.buffer === chunk.contentBytesBuffer?.buffer) {
            const owned = new Uint8Array(new SharedArrayBuffer(stable.contentBytesBuffer.byteLength))
            owned.set(stable.contentBytesBuffer)
            stable.contentBytesBuffer = owned
        }
        borrowedContent = stable.contentBytesBuffer?.buffer === chunk.contentBytesBuffer?.buffer
    }, 262144, {...options, preloadedSource})
    const profile = loaded.parser.consumeLastTermBankWasmParseProfile()
    assert.ok(stable)
    if (!(stable.preparedLookupIndexes instanceof Map)) {
        const prepared = loaded.lookup.prepareTermLookupIndexesFromPreinternedPlan(stable, null, loaded.experiments.snapshotTermBankExperiments(options))
        if (prepared !== null) stable.preparedLookupIndexes = prepared.indexes
    }
    const elapsedMs = performance.now() - started
    assert.ok(profile)
    assert.equal(profile.fusedParseFallbacks, 0)
    return {stable, profile, elapsedMs, sourceInflateMs: preloadedSource.inflateMs, nativePrepared,
        lookup: inspectLookup(stable, nativePrepared), copy: inspectCopy(sourceChunk, stable, borrowedContent)}
}

function inspectCopy(source, stable, borrowedContent) {
    const copiedBytesByField = {}
    const reusedBytesByField = {}
    const sourceBytesByField = {}
    const add = (name, from, to) => {
        if (ArrayBuffer.isView(from)) sourceBytesByField[name] = (sourceBytesByField[name] ?? 0) + from.byteLength
        if (!ArrayBuffer.isView(to)) return
        const reused = ArrayBuffer.isView(from) && from.buffer === to.buffer
        const fields = reused ? reusedBytesByField : copiedBytesByField
        fields[name] = (fields[name] ?? 0) + to.byteLength
    }
    for (const name of ['readingEqualsExpressionList', 'scoreList', 'sequenceList',
        'contentHash1List', 'contentHash2List', 'contentMetaList', 'contentUniqueIndexList']) {
        add(name, source[name], stable[name])
    }
    for (const name of ['expressionBytesList', 'readingBytesList', 'contentBytesList']) {
        for (let i = 0; i < source[name].length; ++i) add(name, source[name][i], stable[name][i])
    }
    for (const name of ['stringLengths', 'stringOffsets', 'stringHashes', 'stringsBuffer', 'expressionIndexes', 'readingIndexes']) {
        add(`plan.${name}`, source.termRecordPreinternedPlan[name], stable.termRecordPreinternedPlan[name])
    }
    const whole = stable.preparedLookupIndexes?.get(`0:${stable.rowCount}`)
    const reusedOwnedKeys = whole && stable.termRecordPreinternedPlan.stringsBuffer.buffer === whole.bytes.buffer ?
        stable.termRecordPreinternedPlan.stringsBuffer.byteLength : 0
    if (reusedOwnedKeys > 0) {
        copiedBytesByField['plan.stringsBuffer'] -= reusedOwnedKeys
        reusedBytesByField['plan.stringsBuffer'] = (reusedBytesByField['plan.stringsBuffer'] ?? 0) + reusedOwnedKeys
    }
    const contentBytes = stable.contentBytesBuffer?.byteLength ?? 0
    sourceBytesByField.contentBytesBuffer = contentBytes
    ;(borrowedContent ? reusedBytesByField : copiedBytesByField).contentBytesBuffer = contentBytes
    let projectionDecodeCopyBytes = 0
    let projectionDecodeCopyCalls = 0
    for (let i = 0; i < source.mediaRows.length; ++i) {
        const from = source.mediaRows[i].row
        const to = stable.mediaRows[i].row
        for (const name of ['expressionBytes', 'readingBytes', 'glossaryJsonBytes', 'termEntryContentBytes']) add(`media.${name}`, from[name], to[name])
        if (options.projectImagePaths && from.termEntryContentBytes.length > 0 && from.glossaryJson.length === 0 &&
            from.glossaryJsonBytes instanceof Uint8Array && !(from.glossaryJsonBytes.buffer instanceof ArrayBuffer)) {
            projectionDecodeCopyBytes += from.glossaryJsonBytes.byteLength
            ++projectionDecodeCopyCalls
        }
    }
    const ownedBuffers = new Set()
    const sharedBuffers = new Set()
    const seen = new Set()
    const visit = (value) => {
        if (value === null || typeof value !== 'object' || seen.has(value)) return
        seen.add(value)
        if (ArrayBuffer.isView(value)) {
            if (value.byteLength > 0) (value.buffer instanceof ArrayBuffer ? ownedBuffers : sharedBuffers).add(value.buffer)
        } else if (value instanceof Map) {
            for (const item of value.values()) visit(item)
        } else {
            for (const item of Object.values(value)) visit(item)
        }
    }
    visit(stable)
    return {sourceBytesByField, copiedBytesByField, reusedBytesByField, borrowedContent,
        copiedViewBytes: Object.values(copiedBytesByField).reduce((sum, bytes) => sum + bytes, 0),
        ownedBufferCount: ownedBuffers.size,
        ownedBufferBytes: [...ownedBuffers].reduce((sum, buffer) => sum + buffer.byteLength, 0),
        sharedBufferCount: sharedBuffers.size,
        sharedBackingBufferBytes: [...sharedBuffers].reduce((sum, buffer) => sum + buffer.byteLength, 0),
        projectionDecodeCopyBytes, projectionDecodeCopyCalls, mediaRowObjectCount: source.mediaRows.length}
}

function inspectLookup(chunk, nativePrepared) {
    const result = {indexes: 0, outputBytes: 0, keyBytes: 0, originalZeroFillBytes: 0,
        explicitZeroBytes: 0, removedHashNextFillBytes: 0, avoidedInitializationBytes: 0,
        nativePrepared, ownedKeyArenaBytesReused: 0}
    const whole = chunk.preparedLookupIndexes.get(`0:${chunk.rowCount}`)
    if (whole && chunk.termRecordPreinternedPlan.stringsBuffer.buffer === whole.bytes.buffer) {
        result.ownedKeyArenaBytesReused = chunk.termRecordPreinternedPlan.stringsBuffer.byteLength
    }
    for (const {bytes} of chunk.preparedLookupIndexes.values()) {
        const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
        assert.equal(view.getUint32(4, true), 7)
        const rows = view.getUint32(16, true)
        const keys = view.getUint32(20, true)
        const strings = view.getUint32(24, true)
        const sequenceKeys = view.getUint32(32, true)
        const readingPostings = view.getUint32(36, true)
        const derivedOffset = 16 + view.getUint32(8, true)
        const keySlots = view.getUint32(derivedOffset + 8, true)
        const sequenceSlots = view.getUint32(derivedOffset + 12, true)
        const sequencePostings = view.getUint32(derivedOffset + 24, true)
        const u16Base = (keys + rows * 3) * 2
        const u16Derived = (keySlots + keys + (keys + 1) * 2 + rows + readingPostings +
            sequenceSlots + sequenceKeys + sequenceKeys + 1 + sequencePostings) * 2
        const padding = ((4 - strings % 4) % 4) + ((4 - u16Base % 4) % 4) + ((4 - u16Derived % 4) % 4)
        const explicitZero = 8 + padding + (keys + 1) * 4 + (sequenceKeys + 1) * 2
        ++result.indexes
        result.outputBytes += bytes.length
        result.keyBytes += strings
        if (!nativePrepared) continue
        result.originalZeroFillBytes += bytes.length
        result.explicitZeroBytes += explicitZero
        result.removedHashNextFillBytes += (keys + sequenceKeys) * 2
        result.avoidedInitializationBytes += bytes.length - explicitZero + (keys + sequenceKeys) * 2
    }
    return result
}

const observations = []
let termRows = 0
let mediaRows = 0
let rowsWithoutMediaProjection = 0
const report = {schemaVersion: 2, mode, dictionary, complete: false,
    boundary: 'serialized compressed source inflation + fused column parser + worker result ownership/image projection + prepared lookup indexes; excludes browser, parallel overlap, storage, input reads, validation hashing and byte accounting',
    runtime: process.version, v8: process.versions.v8, baselineRoot, candidateRoot, archivePath,
    fixtureSha256, fixture, identities, runnerSha256,
    wasmSha256: {baseline: baseline.wasmSha256, candidate: candidate.wasmSha256},
    options, directoryReader, totalBanks: banks.length, sourceBytes: totalBytes, productionGroupCount: groups.length,
    selectedGroupCount: selected.length, observations}
const save = async () => writeFile(outputPath, JSON.stringify({...report, termRows, mediaRows, rowsWithoutMediaProjection}, null, 2) + '\n')
await save()
try {
    // Each compressed payload is read before its timed interval. No observation is retried.
    for (const index of selected) {
        const files = groups[index]
        const observation = {index, banks: files.map(({filename}) => filename), status: 'started'}
        observations.push(observation)
        const sources = []
        for (const file of files) sources.push({...file, bytes: await reader.read(file, signal)})
        const first = await parseGroup(baseline, sources)
        const rowCount = first.stable.rowCount
        const mediaCount = first.stable.mediaRows.length
        if (mode === 'oracle') {
            // The two modules have independent memories; hash before either arm parses again.
            const firstDigest = hashChunk(first.stable)
            const second = await parseGroup(candidate, sources)
            assert.equal(hashChunk(second.stable), firstDigest, `Output mismatch in group ${index}`)
            assert.equal(second.stable.rowCount, rowCount)
            assert.equal(second.stable.mediaRows.length, mediaCount)
            Object.assign(observation, {digest: firstDigest, baselineLookup: first.lookup, candidateLookup: second.lookup,
                baselineCopy: first.copy, candidateCopy: second.copy})
        } else {
            Object.assign(observation, {elapsedMs: first.elapsedMs, sourceInflateMs: first.sourceInflateMs,
                lookupPrepareMs: first.profile.lookupIndexPrepareMs, lookup: first.lookup,
                copy: first.copy,
                rowDecodeMs: first.profile.rowDecodeMs, parseBankMs: first.profile.parseBankMs,
                resultFallbacks: first.profile.fusedParseFallbacks})
        }
        termRows += rowCount
        mediaRows += mediaCount
        rowsWithoutMediaProjection += rowCount - mediaCount
        Object.assign(observation, {status: 'success', termRows: rowCount, mediaRows: mediaCount})
        if (observations.length % 10 === 0) {
            await save()
            console.log(JSON.stringify({completedGroups: observations.length, totalGroups: selected.length, termRows}))
        }
    }
    if (selected.length === groups.length) assert.equal(termRows, fixture.termRows)
    assert.deepEqual(await sourceIdentity(baselineRoot), identities[0], 'Baseline source changed during the run')
    assert.deepEqual(await sourceIdentity(candidateRoot), identities[1], 'Candidate source changed during the run')
    assert.equal(createHash('sha256').update(await readFile(runnerPath)).digest('hex'), runnerSha256, 'Runner source changed')
    report.complete = true
    await save()
} catch (error) {
    report.failure = String(error)
    await save()
    throw error
}
console.log(JSON.stringify({outputPath, termRows, mediaRows, selectedGroupCount: selected.length,
    ...(mode === 'measure' ? {totalComponentMs: observations.reduce((sum, row) => sum + row.elapsedMs, 0),
        totalLookupPrepareMs: observations.reduce((sum, row) => sum + row.lookupPrepareMs, 0)} : {})}))
