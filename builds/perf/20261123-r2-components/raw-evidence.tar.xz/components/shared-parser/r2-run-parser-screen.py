#!/usr/bin/env python3
"""Run four fixed fresh-process A/B/C parser triples for each locked corpus."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import time


def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()


def write_json(file, value, exclusive=False):
    with file.open("x" if exclusive else "w") as output:
        json.dump(value, output, indent=2)
        output.write("\n")


IDENTITY_FILES = [
    "ext/js/dictionary/term-bank-wasm-parser.js",
    "ext/js/dictionary/term-lookup-index-preparation.js",
    "ext/js/dictionary/term-bank-experiments.js",
    "ext/js/dictionary/dictionary-image-references.js",
    "ext/js/dictionary/term-bank-source-pipeline.js",
    "ext/js/dictionary/dense-zip-directory.js",
    "ext/js/dictionary/term-content-ownership.js",
    "ext/js/media/media-util.js",
    "ext/js/dictionary/term-lookup-index.js",
    "ext/js/dictionary/term-record-preinterned-plan.js",
    "ext/js/dictionary/wasm/term-bank-parser.c",
    "dev/data/dictionary-wasm/manifest.json",
    "ext/lib/term-bank-parser.wasm",
    "package-lock.json",
    "test/perf/dictionaries.lock.json",
]


def identity(root):
    def git(*args):
        return subprocess.check_output(["git", "-C", str(root), *args])

    return {
        "root": str(root),
        "head": git("rev-parse", "HEAD").decode().strip(),
        "files": {name: digest(root / name) for name in IDENTITY_FILES},
    }


def source_state(root):
    result = identity(root)
    diff = subprocess.check_output(["git", "-C", str(root), "diff", "--binary", "HEAD"])
    result["trackedDiffSha256"] = hashlib.sha256(diff).hexdigest()
    return result


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("node", type=Path)
parser.add_argument("baseline", type=Path)
parser.add_argument("candidate", type=Path)
parser.add_argument("fixtures", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=False)
node = args.node.resolve()
harness = Path(__file__).with_name("r2-parser-component.mjs").resolve()
roots = {"A": args.baseline.resolve(), "B": args.candidate.resolve(), "C": args.baseline.resolve()}
identities = {label: identity(root) for label, root in roots.items()}
states = {label: source_state(root) for label, root in roots.items()}
assert identities["A"] == identities["C"]
fixtures = {
    "jmdict": {"path": str((args.fixtures / "JMdict.zip").resolve()), "rows": 526942, "groups": 12, "banks": 53},
    "jitendex": {"path": str((args.fixtures / "jitendex-yomitan.zip").resolve()), "rows": 435448, "groups": 22, "banks": 218},
    "vndb": {"path": str((args.fixtures / "vndb_characters_by_bee.zip").resolve()), "rows": 6648310, "groups": 170, "banks": 665},
}
schedule = [
    {"dictionary": dictionary, "triple": triple, "position": position, "label": label}
    for dictionary in fixtures
    for triple in range(1, 5)
    for position, label in enumerate("ABC" if triple % 2 == 1 else "CBA", start=1)
]
plan = {
    "schemaVersion": 1,
    "frozenAtUtc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "schedule": schedule,
    "arms": identities,
    "sourceStates": states,
    "fixtures": fixtures,
    "node": str(node),
    "nodeSha256": digest(node),
    "nodeVersion": subprocess.check_output([str(node), "--version"], text=True).strip(),
    "harnessSha256": digest(harness),
    "runnerSha256": digest(Path(__file__)),
    "childTimeoutSeconds": 180,
    "host": {"platform": platform.platform(), "machine": platform.machine(), "cpus": os.cpu_count()},
    "warmup": "No excluded warmup. Every arm is a fresh process; all production-shaped groups, including the first group, are retained and measured.",
    "measured": "Exploratory cold component screen. One full corpus pass per fresh child; four triples in exact ABC, CBA, ABC, CBA order per dictionary; dictionaries in fixed JMdict/Jitendex/VNDB order; 36 child processes total.",
    "boundary": "Serialized compressed source inflation + fused column parser + worker result ownership/image projection + prepared lookup indexes. Excludes input reads, validation hashing, byte accounting, browser, workers, persistence and UI; not a full-import performance measurement.",
    "control": "A and C are identical baseline source and WASM. B lies between them in each triple.",
    "comparison": "Per dictionary: every triple's B/A-1, B/C-1 and C/A-1, plus median and equal-work aggregate; negative is faster. B/mean(A,C)-1 is descriptive only. All effects and controls are retained.",
    "failure": "The first failed arm or provenance mismatch stops the declared cohort. Retain all completed and failing outputs; no retries or arm replacement. A cohort-complete receipt is written only after every arm and final provenance checks pass.",
}
assert plan["nodeVersion"] == "v22.22.0"
plan_path = args.output / "plan.json"
receipts_path = args.output / "receipts.json"
write_json(plan_path, plan, exclusive=True)
receipts = []
try:
    for entry in schedule:
        dictionary, triple, label = entry["dictionary"], entry["triple"], entry["label"]
        name = f"{dictionary}-{triple:02d}-{label}"
        output = args.output / f"{name}.json"
        log_path = args.output / f"{name}.log"
        root = roots[label]
        command = [str(node), str(harness), "measure", dictionary, str(root), str(root), fixtures[dictionary]["path"], str(output), "0"]
        assert not output.exists()
        print(f"Starting {name}", flush=True)
        started = time.time()
        timed_out = False
        with log_path.open("x") as log:
            try:
                completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                           check=False, timeout=plan["childTimeoutSeconds"])
                exit_code = completed.returncode
            except subprocess.TimeoutExpired:
                timed_out = True
                exit_code = None
                log.write(f"\nDeclared child timeout after {plan['childTimeoutSeconds']} seconds; cohort stopped without retry.\n")
        receipt = {**entry, "command": command, "startedEpochSeconds": started,
                   "elapsedSeconds": time.time() - started, "exitCode": exit_code, "timedOut": timed_out,
                   "logSha256": digest(log_path)}
        if output.exists():
            receipt["outputSha256"] = digest(output)
        receipts.append(receipt)
        write_json(receipts_path, receipts)
        assert exit_code == 0 and not timed_out, receipt
        result = json.loads(output.read_text())
        assert result["complete"] is True and "failure" not in result
        assert result["mode"] == "measure" and result["dictionary"] == dictionary
        assert result["runnerSha256"] == plan["harnessSha256"]
        assert result["identities"] == [identities[label], identities[label]]
        assert result["termRows"] == fixtures[dictionary]["rows"]
        assert result["selectedGroupCount"] == result["productionGroupCount"] == fixtures[dictionary]["groups"]
        assert source_state(root) == states[label], f"Source changed during {name}"
        assert digest(harness) == plan["harnessSha256"], f"Harness changed during {name}"
        assert digest(Path(__file__)) == plan["runnerSha256"], f"Screen runner changed during {name}"
        print(f"Finished {name}: {receipt['elapsedSeconds']:.3f}s", flush=True)
    for label, root in roots.items():
        assert source_state(root) == states[label], f"Final source mismatch: {label}"
    assert digest(node) == plan["nodeSha256"], "Runtime changed during cohort"
    write_json(args.output / "cohort-complete.json", {
        "schemaVersion": 1, "completedArms": len(receipts),
        "planSha256": digest(plan_path), "receiptsSha256": digest(receipts_path),
        "completedAtUtc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }, exclusive=True)
except BaseException as error:
    write_json(args.output / "cohort-failure.json", {
        "schemaVersion": 1, "error": repr(error), "completedProcessCount": len(receipts),
        "planSha256": digest(plan_path),
        "receiptsSha256": digest(receipts_path) if receipts_path.exists() else None,
    }, exclusive=True)
    raise
print("Completed all 36 predeclared arms", flush=True)
