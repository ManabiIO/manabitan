#!/usr/bin/env python3
"""Verify every frozen parser-screen observation and retain all triple effects."""

import argparse
import hashlib
import json
import math
from pathlib import Path
from statistics import median


def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()


def comparison(numerator, denominator):
    changes = [100 * (a / b - 1) for a, b in zip(numerator, denominator, strict=True)]
    return {"perTriplePercent": changes, "medianPercent": median(changes),
            "equalWorkPercent": 100 * (sum(numerator) / sum(denominator) - 1)}


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("screen", type=Path)
args = parser.parse_args()
assert not (args.screen / "cohort-failure.json").exists(), "Failed cohorts cannot supply a complete comparison"
completion = json.loads((args.screen / "cohort-complete.json").read_text())
plan_path = args.screen / "plan.json"
receipts_path = args.screen / "receipts.json"
assert digest(plan_path) == completion["planSha256"]
assert digest(receipts_path) == completion["receiptsSha256"]
plan = json.loads(plan_path.read_text())
receipts = json.loads(receipts_path.read_text())
schedule = [
    {"dictionary": dictionary, "triple": triple, "position": position, "label": label}
    for dictionary in ["jmdict", "jitendex", "vndb"]
    for triple in range(1, 5)
    for position, label in enumerate("ABC" if triple % 2 == 1 else "CBA", start=1)
]
assert plan["schedule"] == schedule
assert completion["completedArms"] == len(receipts) == len(schedule) == 36
assert plan["arms"]["A"] == plan["arms"]["C"]
rows = {}
layouts = {}
fixtures = {}
for entry, receipt in zip(schedule, receipts, strict=True):
    assert all(receipt[key] == entry[key] for key in entry)
    assert receipt["exitCode"] == 0 and receipt["timedOut"] is False
    dictionary, triple, label = entry["dictionary"], entry["triple"], entry["label"]
    name = f"{dictionary}-{triple:02d}-{label}"
    result_path = args.screen / f"{name}.json"
    assert digest(result_path) == receipt["outputSha256"]
    assert digest(args.screen / f"{name}.log") == receipt["logSha256"]
    result = json.loads(result_path.read_text())
    assert result["mode"] == "measure" and result["dictionary"] == dictionary
    assert result["complete"] is True and "failure" not in result
    assert result["runtime"] == plan["nodeVersion"]
    assert result["runnerSha256"] == plan["harnessSha256"]
    assert result["identities"] == [plan["arms"][label]] * 2
    fixture = plan["fixtures"][dictionary]
    assert result["termRows"] == fixture["rows"]
    assert result["selectedGroupCount"] == result["productionGroupCount"] == fixture["groups"]
    assert result["totalBanks"] == fixture["banks"]
    observations = result["observations"]
    assert len(observations) == fixture["groups"]
    assert [row["index"] for row in observations] == list(range(fixture["groups"]))
    assert all(row["status"] == "success" for row in observations)
    assert sum(row["termRows"] for row in observations) == fixture["rows"]
    layout = [{key: row[key] for key in ["index", "banks", "termRows", "mediaRows"]} for row in observations]
    fixture_identity = {key: result[key] for key in ["fixtureSha256", "sourceBytes", "options", "directoryReader"]}
    if dictionary in layouts:
        assert layouts[dictionary] == layout
        assert fixtures[dictionary] == fixture_identity
    else:
        layouts[dictionary] = layout
        fixtures[dictionary] = fixture_identity
    for metric in ["elapsedMs", "sourceInflateMs", "lookupPrepareMs", "parseBankMs"]:
        assert all(math.isfinite(row[metric]) and row[metric] >= 0 for row in observations), metric
    assert all(row["elapsedMs"] > 0 and row["resultFallbacks"] == 0 for row in observations)
    rows[(dictionary, triple, label)] = {
        metric: sum(row[metric] for row in observations)
        for metric in ["elapsedMs", "sourceInflateMs", "lookupPrepareMs", "parseBankMs"]
    }

summaries = []
for dictionary in ["jmdict", "jitendex", "vndb"]:
    for metric in ["elapsedMs", "sourceInflateMs", "lookupPrepareMs", "parseBankMs"]:
        arms = {label: [rows[(dictionary, triple, label)][metric] for triple in range(1, 5)] for label in "ABC"}
        assert all(value > 0 for values in arms.values() for value in values), f"No positive aggregate for {metric}"
        result = {"dictionary": dictionary, "boundary": metric, "milliseconds": arms,
                  "candidateVsAdjacentControlMean": comparison(arms["B"], [(a + c) / 2 for a, c in zip(arms["A"], arms["C"], strict=True)]),
                  "candidateVsA": comparison(arms["B"], arms["A"]),
                  "candidateVsC": comparison(arms["B"], arms["C"]),
                  "sameCodeControlCVsA": comparison(arms["C"], arms["A"])}
        summaries.append(result)
        print(json.dumps(result))
summary = {"schemaVersion": 1, "verifiedArms": 36, "screenPlanSha256": digest(plan_path),
           "screenReceiptsSha256": digest(receipts_path), "completionSha256": digest(args.screen / "cohort-complete.json"),
           "analysisSha256": digest(Path(__file__)), "signConvention": "100 * (candidate / reference - 1): negative is faster",
           "boundary": plan["boundary"], "fixtures": fixtures, "layouts": layouts, "summaries": summaries}
with (args.screen / "summary.json").open("x") as file:
    json.dump(summary, file, indent=2)
    file.write("\n")
