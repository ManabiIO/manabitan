## Problem

The baseline three-corpus browser traces identify source CRC validation as substantial native import work. The existing eight-lane braid extracts table indices from 64-bit words even though every CRC state and table entry is 32 bits.

## Change

Express each eight-byte input word as two little-endian 32-bit halves. Keep the exact current eight lanes, 64-byte step, tables, 256 KiB admission threshold, initial state, final fold, and scalar tail. CRC validation remains mandatory for every decoded byte.

The pinned generated module changes only function 2 (`crc32_bytes`); all other function bodies and non-custom sections are byte-identical to baseline. Each 64-byte braid iteration removes 32 i64 shifts and 40 i64-to-i32 conversions, using sixteen 32-bit loads in place of eight 64-bit loads. This is static instruction evidence, not a speed result. The module shrinks by 114 bytes.

## Validation

- 73 focused CRC/inflater tests passed, including every tail modulo 64, all sixteen alignments, threshold edges, physical memory ends, corrupt data, and overlap cases.
- Every non-directory entry in the complete pinned JMdict, Jitendex, and VNDB archives matches both baseline and independent Node zlib: 5,169,815,579 decompressed bytes. The oracle used the exact committed production module.
- Clang/LLD 21.1.8 reproduces the module; full lowering receipts are retained.
- [Full CI and all PR checks passed](https://github.com/ManabiIO/manabitan/actions/runs/45120129751).

## Performance decision: HOLD

Keep draft: the complete browser study does not demonstrate a repeatable material whole-import gain.

### Retained incomplete component screen

The fixed component screen stopped on **`02-C`, signal 9 / exit −9**, after its first complete ABC triple. The predeclared fail-stop rule was honored: no retries, remaining arms, discarded failures, or point estimate from the incomplete cohort. The raw results and failure receipt remain in #814. The termination cause was not established; the successful browser cohort does not reclassify this local attempt as passed.

### Complete-browser qualification

[Run 45121755673](https://github.com/ManabiIO/manabitan/actions/runs/45121755673) completed this candidate's six cells and all **252 fresh-profile imports**: six excluded warmups, twelve adjacent alternating AB/BA candidate pairs and six interleaved AC/CA same-code control pairs per cell, with independent reversed-order replication for each dictionary. All raw observations are retained. Independent source/package, fixture/work, operation-clock and statistical audits pass. Node 22.22.0 / Chromium 153.0.8010.12 used identical production defaults, OPFS storage and the post-UI import-complete boundary; restart and twelve source-derived persisted-content probes passed for every import.

Every entry is **forward / reverse**; negative is faster. Equal work is the ratio of summed paired durations within one cell. C/A uses the exact A package. Hosts are not pooled and control effects are not subtracted.

| Dictionary | B/A median, F / R | B/A equal work, F / R | C/A median, F / R | C/A equal work, F / R |
|---|---:|---:|---:|---:|
| JMdict | −0.70% / −1.04% | −0.67% / −1.21% | +0.01% / −0.53% | +0.55% / −0.95% |
| Jitendex | −0.20% / −0.54% | +0.56% / −0.78% | +0.47% / −2.75% | +0.36% / −1.85% |
| VNDB | −0.26% / −1.33% | −0.79% / −2.96% | −1.04% / +1.34% | −0.80% / +2.20% |

All per-pair ratios, descriptive intervals, slow tails, source receipts and prior local failures remain in the study artifacts and evidence PR #814. Browser probes are sampled persisted correctness evidence; the whole-data component oracle has its separate scope. Existing phase counters are overlapping parser-worker duration sums, not additive wall-time decomposition. Frozen browser study source: `05740992c377629eb3017be35cf8c6064d9ef445`.

VNDB reverse has a favorable median interval [−3.39%, −0.05%], but forward does not replicate it: its interval is [−2.98%, +2.59%], and the forward same-code equal-work control is −0.80%. VNDB inflate/CRC equal-work phase counters decrease by 1.84% / 2.99%, providing scoped mechanism evidence. JMdict and Jitendex whole-import effects are small or change direction relative to equal work and controls. **HOLD: static instruction reduction and a favorable single cell do not qualify a complete-import speedup.**

Baseline `5e1f8c12f7ff798ba407323aff675cb23b22af02`; runtime `4884b4bd93d45f152ec828bcca44990f18976a05`; tree `3843616849501e3557b50c0689555e3736b0a31d`.
