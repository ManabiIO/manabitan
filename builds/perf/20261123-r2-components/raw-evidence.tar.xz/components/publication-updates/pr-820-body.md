## Problem

Native whole-chunk lookup indexes already contain an owned UTF-8 key arena and key-length table. The parser result copies both again into its key plan before transfer, adding work and another backing allocation.

## Change

When the native producer owns the complete sidecar and row byte lists are omitted, let its key plan refer to those exact owned subviews. A private WeakMap witnesses the producer and descriptor identities. Replaced descriptors fall back to ordinary copying; in-place edits stay visible to the current validation path. Explicit row-byte-list callers keep their existing aliases and copying behavior. Segmented and arbitrary split plans retain their existing contracts.

Retained record caches detach one tightly sized key arena when keeping a subview would otherwise pin the whole prepared sidecar. Normal OPFS imports discard these materialized records and keep the copy reduction. No grouping, concurrency, compression, or persisted format changes.

## Correctness and work reduction

- Complete stable row/content/media/key-plan/index outputs match baseline for all 526,942 JMdict, 435,448 Jitendex and 6,648,310 VNDB rows.
- Summed duplicate copied bytes removed in the serial corpus partitions: **8,301,780 JMdict; 9,706,463 Jitendex; 202,591,586 VNDB**. These are copy/allocation-volume reductions, not peak-memory or elapsed-time claims. Partitions have production-shaped group counts; exact bank membership was not independently matched to the browser planner.
- 234 parser/boundary and 195 record-store tests passed. Ownership coverage includes detached/transferred buffers, source reuse, descriptor replacement, in-place edits, explicit byte lists and retained-cache backing-buffer size/mutation independence.
- Main types, scoped lint and all-target build dry runs passed. The local complete test-type process was killed with exit 137 and no diagnostics; that original failure remains retained. [Hosted full CI 45122913657 passed](https://github.com/ManabiIO/manabitan/actions/runs/45122913657), including the complete test-type gate, unit suites, pinned build, and Chromium/Firefox extension E2E. Optional workflow lanes were skipped, not represented as passes.
- Native WASM is unchanged.

## Performance decision: HOLD

Keep draft. The completed timing campaign does not establish a repeatable material complete-import gain. Four independent memory cells support small descriptive sampled-memory reductions; both JMdict memory cells remain unqualified. No all-corpus memory qualification or exact browser peak-memory claim is made.

### Complete-browser timing

[Run 45123053286](https://github.com/ManabiIO/manabitan/actions/runs/45123053286) completed all six cells and **252 fresh-profile imports**: six excluded warmups, twelve adjacent alternating candidate/parent pairs and six interleaved same-code C/A pairs per cell, with independent reversed-order replication. Independent source/package, fixture/work, raw operation-clock and statistical checks pass. Timing used Node 22.22.0 / Chromium 153.0.8010.12, identical production defaults and OPFS storage through the post-UI import-complete event. Twelve source-derived persisted probes and restart verification passed for every import.

Entries are **forward / reverse**; negative is faster. Equal work compares summed paired durations within one cell. No hosts are pooled and no control effects are subtracted.

| Dictionary | B/A median, F / R | B/A equal work, F / R | C/A median, F / R | C/A equal work, F / R |
|---|---:|---:|---:|---:|
| JMdict | −0.50% / +0.53% | +0.11% / +0.93% | −0.37% / +1.09% | −0.87% / +1.07% |
| Jitendex | +0.37% / +1.73% | +0.22% / +1.60% | −0.53% / +0.66% | −4.26% / +0.99% |
| VNDB | −1.22% / −0.95% | +0.67% / −1.03% | −0.63% / +0.95% | −0.52% / +0.72% |

VNDB's result-copy equal-work counters decrease 7.24% / 6.21%, consistent with the intended mechanism. Its forward timing cohort retains two +12.05% / +13.07% slower pairs, yielding +0.67% equal work despite a favorable median interval. Reverse's median interval includes zero. JMdict and Jitendex are slower on equal work in both directions. Copy counters are overlapping worker-duration sums, not wall-time savings. Frozen timing study source: `9941723a323c76e8d73a16880e658fa243f17187`.

### Separate process-tree memory diagnostics

[Run 45124025705](https://github.com/ManabiIO/manabitan/actions/runs/45124025705) completed all 24 browser imports. Four complete cells qualified for memory comparisons; each cell contains two adjacent pairs. The table preserves each independent job and does not pool memory estimates across hosts.

| Dictionary | ABBA sampled PSS / private median | BAAB sampled PSS / private median |
|---|---:|---:|
| JMdict | Unqualified — coverage failure | Unqualified — coverage failure |
| Jitendex | −0.54% / −0.55% | −4.79% / −5.82% |
| VNDB | −2.29% / −2.75% | −2.52% / −2.88% |

Both JMdict cells contain one unreadable stable two-thread zombie leader, outside the frozen single-thread-zombie exemption. Their maxima and comparisons remain withheld, with failure receipts retained and no salvaged scans or retries. These are measurement-coverage failures, not import failures or measured regressions.

These values are maxima of covered, discovered Chromium process-tree samples during startup, import, readback and restart. They are not exact import peaks or settled-memory measurements; scans are non-atomic and may miss short-lived/reparented processes. Observer-run elapsed times are not authoritative speed evidence. Frozen memory study source: `a9a90967f1dfc9c9c68d06ae5ad4ad1e999f67b2`; unchanged observer SHA-256: `ca6c0f7761062761697a810d4bd0007ff0257bbce69099df45657ffdb7ee8f10`.

**HOLD under the repository acceptance rule:** the copy/memory evidence is scoped and useful, but a material replicated complete-import benefit and complete memory qualification are absent. All raw observations, slow tails, full-data oracle receipts and local/measurement failures remain in #814. Sampled browser probes do not replace exhaustive persisted-database equality.

Baseline: `5e1f8c12f7ff798ba407323aff675cb23b22af02`. Runtime: `8fe5926cec1396a05ed4ea52be751e48784329b7`. Exact published tree: `df4e570212e6ef8a60f12f578b57c6d04455faa3`.
