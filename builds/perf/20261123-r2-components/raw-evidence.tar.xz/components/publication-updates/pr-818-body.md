## Problem and change

Glossaries that begin with ordinary strings currently traverse the general composite JSON state machine. Consume their leading string run with the existing bounded string validator, preserving conservative media hints and every whitespace-normalization hint. A closing bracket completes the array. A mixed array resumes the general parser at its first unconsumed value with the exact existing array state; prefixes are not rescanned and object validation remains intact.

JSON grammar, depth limits, content normalization, native ABI, grouping, compression and persisted formats remain unchanged. The parser module grows by 1,061 bytes.

## Validation

- 711 focused tests passed across composite grammar, string scanning, experimental combinations, escaped-key fallback and full parser tests. The final 95-case composite suite passed after a test-only lint escape correction.
- Added cases cover supported/unsupported objects after string prefixes, duplicate-key rules, mixed scalar/nested values, escaped image markers, truncation and malformed delimiters.
- Every complete row/content/media/key-plan/index output matches baseline across all 526,942 JMdict, 435,448 Jitendex and 6,648,310 VNDB rows. Serial oracle partitions use production-shaped group counts; exact bank membership was not independently matched to the browser planner.
- Scoped ESLint and an exact pinned Clang/LLD 21.1.8 rebuild passed.
- [Full CI and all PR checks passed](https://github.com/ManabiIO/manabitan/actions/runs/45120133351).

## Performance decision: HOLD

Keep draft: the completed fixed component screen and complete-browser qualification do not establish a material import benefit.

The cold component screen completed all 36 declared processes without retries or source changes. Its JMdict and Jitendex controls drift substantially, and the intended JMdict native-parse phase is adverse (+6.03% versus A, +4.74% versus C). All component observations remain retained; they are not full-browser timing evidence.

### Complete-browser qualification

[Run 45121755673](https://github.com/ManabiIO/manabitan/actions/runs/45121755673) completed this candidate's six cells and all **252 fresh-profile imports**: six excluded warmups, twelve adjacent alternating AB/BA candidate pairs and six interleaved AC/CA same-code control pairs per cell, with independent reversed-order replication for each dictionary. All raw observations are retained. Independent source/package, fixture/work, operation-clock and statistical audits pass. Node 22.22.0 / Chromium 153.0.8010.12 used identical production defaults, OPFS storage and the post-UI import-complete boundary; restart and twelve source-derived persisted-content probes passed for every import.

Every entry is **forward / reverse**; negative is faster. Equal work is the ratio of summed paired durations within one cell. C/A uses the exact A package. Hosts are not pooled and control effects are not subtracted.

| Dictionary | B/A median, F / R | B/A equal work, F / R | C/A median, F / R | C/A equal work, F / R |
|---|---:|---:|---:|---:|
| JMdict | −0.24% / +0.39% | −0.22% / +0.13% | −0.38% / +0.55% | −0.45% / −0.45% |
| Jitendex | −1.06% / −0.33% | −1.09% / −0.69% | −0.34% / −1.57% | −0.46% / −0.74% |
| VNDB | −0.19% / +0.94% | +0.00% / +1.72% | +0.08% / +1.32% | +0.06% / +2.71% |

All per-pair ratios, descriptive intervals, slow tails, source receipts and prior local failures remain in the study artifacts and evidence PR #814. Browser probes are sampled persisted correctness evidence; the whole-data component oracle has its separate scope. Existing phase counters are overlapping parser-worker duration sums, not additive wall-time decomposition. Frozen browser study source: `05740992c377629eb3017be35cf8c6064d9ef445`.

The intended JMdict parse equal-work counter is +0.97% / +1.27%, while complete import is near zero and changes sign. Jitendex improvements are modest and comparable to same-code variation; VNDB reverse is slower. All six whole-import median intervals include zero. **HOLD: no qualified complete-import benefit supports the additional parser path.**

Baseline `5e1f8c12f7ff798ba407323aff675cb23b22af02`; runtime `524b41a112a1ba0b1ac31723da274c97d5525653`; tree `7a8c4413a707970103bd182cec83625dab2936ab`.
