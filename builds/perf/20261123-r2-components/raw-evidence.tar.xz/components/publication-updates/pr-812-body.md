## Problem

Compressed dictionary sources spend parser work expanding DEFLATE history matches. The native decoder currently copies long matches in 8-byte words even though the pinned production WASM already enables SIMD.

## Change

Use interleaved 16-byte WASM loads and stores for fast-loop matches at distance 16 or greater, advancing 32 bytes per iteration. The forward copy order preserves overlapping matches; the maximum 31-byte overrun remains inside the existing fast-loop guard. Short-distance matches, the bounded tail, CRC checks, exact input consumption, output limits, and non-WASM builds retain their existing paths.

The generated parser grows by 62 bytes (54,596 → 54,658). The manifest and vendor provenance bind the reviewed change. Compression settings, source grouping, workers, and persisted formats are unchanged.

## Validation

- 86 focused production-WASM tests passed, covering malformed streams, CRC/size/trailing rejection, output-memory boundaries, overlap distances, and the maximum DEFLATE history distance.
- Every non-directory entry in the pinned JMdict, Jitendex, and VNDB archives matched both the baseline decoder and independent Node zlib: 5,169,815,579 decompressed bytes in total.
- Clang/LLD 21.1.8 regenerated the checked-in module reproducibly.
- Full CI and all other PR checks passed at the exact published runtime.

## Performance decision: HOLD

The complete browser study did **not** establish a repeatable whole-import improvement. This remains draft.

[Run 45119098795](https://github.com/ManabiIO/manabitan/actions/runs/45119098795) completed all 252 fresh-profile imports: six cells, each with six excluded warmups, twelve adjacent alternating AB/BA candidate pairs, six interleaved AC/CA same-code control pairs, and an independent reversed-order host. There were no failed imports or discarded measured observations. Timing ends at the post-UI import-complete event; restart checks and twelve source-derived persisted-content probes passed for every import.

Percentages below are median paired candidate/baseline changes; negative is faster. Control is a separate same-code C/A median and is not subtracted.

| Dictionary | Forward candidate | Forward control | Reversed candidate | Reversed control |
|---|---:|---:|---:|---:|
| JMdict | −1.97% | +0.66% | +0.64% | +0.98% |
| Jitendex | −0.65% | +0.85% | +0.90% | +1.26% |
| VNDB | +1.33% | +0.04% | +0.13% | +0.16% |

Every candidate median bootstrap interval crosses zero. The earlier fixed component screen also had large same-code drift; neither screen nor browser results justify a speed claim. All observations and failures are retained in the study artifacts and the evidence PR #814. The browser evidence covers Linux x64 Chromium; sampled persisted probes are not exhaustive equality, which is separately covered by the archive byte oracle above.

Source baseline: `5e1f8c12f7ff798ba407323aff675cb23b22af02`. Published runtime: `5555f3efd3e0c8baa99e93b4c14e7f1889c30383`, tree `a7c6e31bfb8449d9715916adb89cbf50b143bf2e`. Frozen study source: `1788fa1fe889c407d24d0f4b5ca23689946fbcec`.
