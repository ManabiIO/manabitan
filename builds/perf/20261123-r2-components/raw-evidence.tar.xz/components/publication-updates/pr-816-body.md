## Problem and change

The native v7 lookup encoder clears its entire output arena and then overwrites most of it. Initialize only counters, reserved header words, alignment padding, and hash heads. Every payload field and next-link is completely written before publication. Dirty-arena tests cover reserved/padding bytes and failed-write recovery.

## Correctness and deterministic work

- Every stable parser/content/media/key-plan/index byte matches baseline across all 526,942 JMdict, 435,448 Jitendex, and 6,648,310 VNDB rows.
- Avoided initialization bytes in the component partitions: 18,489,908 / 18,844,739 / 327,921,810 respectively. These are summed write reductions, not peak-memory or import-speed results. The serial partitions have production-shaped group counts; their bank membership was not independently matched to the browser planner.
- 124 focused lookup/native/preparation tests passed, with dirty-arena and segmented/sentinel cases also checked separately. Scoped lint and the exact Clang/LLD 21.1.8 rebuild passed.
- The parser module grows by 106 bytes; allocation and persisted-format contracts are unchanged.
- [Full CI and all PR checks passed](https://github.com/ManabiIO/manabitan/actions/runs/45120129003).

## Performance decision: HOLD

The completed browser qualification does not establish a repeatable material whole-import improvement. This remains draft.

### Cold component screen

The frozen cold component screen completed all 36 declared processes without failures, retries, excluded groups, or source changes: four ABC/CBA triples per corpus, with A and C identical baseline sources. It did not demonstrate a gain. All results, including adverse VNDB observations, are retained.

| Corpus | Equal-work B/A | Equal-work B/C | Same-code C/A |
|---|---:|---:|---:|
| JMdict | −0.91% | +1.68% | −2.55% |
| Jitendex | +4.23% | −5.92% | +10.79% |
| VNDB | +10.15% | +4.54% | +5.37% |

Negative is faster. Same-code per-triple drift is large. Native VNDB lookup preparation is also adverse (+8.99% versus A, +10.74% versus C); avoided writes alone do not establish faster execution.

### Complete-browser qualification

[Run 45121755673](https://github.com/ManabiIO/manabitan/actions/runs/45121755673) completed this candidate's six cells and all **252 fresh-profile imports**: six excluded warmups, twelve adjacent alternating AB/BA candidate pairs and six interleaved AC/CA same-code control pairs per cell, with independent reversed-order replication for each dictionary. All raw observations are retained. Independent source/package, fixture/work, operation-clock and statistical audits pass. Node 22.22.0 / Chromium 153.0.8010.12 used identical production defaults, OPFS storage and the post-UI import-complete boundary; restart and twelve source-derived persisted-content probes passed for every import.

Every entry is **forward / reverse**; negative is faster. Equal work is the ratio of summed paired durations within one cell. C/A uses the exact A package. Hosts are not pooled and control effects are not subtracted.

| Dictionary | B/A median, F / R | B/A equal work, F / R | C/A median, F / R | C/A equal work, F / R |
|---|---:|---:|---:|---:|
| JMdict | +1.62% / −0.03% | +1.27% / −0.10% | +0.13% / −0.60% | +0.18% / −0.15% |
| Jitendex | −0.13% / −0.57% | +0.56% / −0.49% | +1.60% / +0.25% | +1.29% / −0.46% |
| VNDB | −0.97% / +0.35% | −0.34% / +1.12% | +0.28% / +0.59% | +0.26% / +1.53% |

All per-pair ratios, descriptive intervals, slow tails, source receipts and prior local failures remain in the study artifacts and evidence PR #814. Browser probes are sampled persisted correctness evidence; the whole-data component oracle has its separate scope. Existing phase counters are overlapping parser-worker duration sums, not additive wall-time decomposition. Frozen browser study source: `05740992c377629eb3017be35cf8c6064d9ef445`.

**Final decision: HOLD; keep draft.** No dictionary demonstrates a repeatable material complete-import gain. Jitendex native lookup-preparation equal-work counters decrease by 12.38% / 9.41%, while complete import changes +0.56% / −0.49%. VNDB complete-import direction reverses and JMdict forward is slower. All six whole-import median intervals include zero. Reduced initialization volume alone does not meet the repository promotion rule.

Baseline `5e1f8c12f7ff798ba407323aff675cb23b22af02`; runtime `3a4ef7ed11dd6b0509c12ad495ab8f591b68872b`; tree `498eb640147187391a57bfbf0eea828639b80248`.
