#!/usr/bin/env python3
"""Run the declared four fresh-process A/B/C inflation triples without adaptation."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import time


def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()


def identity(root):
    def git(*args):
        return subprocess.check_output(["git", "-C", str(root), *args])

    paths = [
        "ext/js/dictionary/term-bank-wasm-parser.js",
        "ext/js/dictionary/wasm/term-bank-inflate.c",
        "ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h",
        "ext/js/dictionary/wasm/vendor/libdeflate/common_defs.h",
        "ext/js/dictionary/wasm/term-bank-parser.c",
        "ext/lib/term-bank-parser.wasm",
        "dev/data/dictionary-wasm/manifest.json",
        "package-lock.json",
    ]
    return {
        "root": str(root),
        "head": git("rev-parse", "HEAD").decode().strip(),
        "trackedDiffSha256": hashlib.sha256(git("diff", "--binary", "HEAD").strip()).hexdigest(),
        "files": {name: digest(root / name) for name in paths},
    }


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("node", type=Path)
parser.add_argument("baseline", type=Path)
parser.add_argument("candidate", type=Path)
parser.add_argument("fixtures", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
harness = Path(__file__).with_name("inflate-component.mjs").resolve()
roots = {"A": args.baseline.resolve(), "B": args.candidate.resolve(), "C": args.baseline.resolve()}
identities = {label: identity(root) for label, root in roots.items()}
assert identities["A"] == identities["C"]
schedule = [
    {"triple": triple, "position": position, "label": label}
    for triple, order in enumerate(["ABC", "CBA", "ABC", "CBA"], start=1)
    for position, label in enumerate(order, start=1)
]
plan = {
    "schemaVersion": 1,
    "frozenAtUtc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "schedule": schedule,
    "arms": identities,
    "node": str(args.node.resolve()),
    "nodeSha256": digest(args.node),
    "nodeVersion": subprocess.check_output([str(args.node), "--version"], text=True).strip(),
    "harnessSha256": digest(harness),
    "runnerSha256": digest(Path(__file__)),
    "host": {"platform": platform.platform(), "machine": platform.machine(), "cpus": os.cpu_count()},
    "warmup": "One complete pass over all three corpora per fresh process; retained and excluded from comparisons.",
    "measured": "One complete pass over all three corpora per arm; four triples ordered ABC, CBA, ABC, CBA, no adaptive repetitions. Exploratory fresh-process component screen with a single retained excluded warmup per arm.",
    "boundary": "Native inflate plus full CRC and term-bank array boundaries; separate wrapper wall sum includes allocations and compressed-input copies. Fixture reads, hashes, module compilation, independent output oracle, parsing, workers, persistence and UI are outside both timers.",
    "control": "A and C use exactly the same baseline sources and bytes. B is between them in every triple.",
    "comparison": "For each corpus and boundary, B/A-1, B/C-1 and same-code C/A-1 separately for every triple; equal-work aggregate and median reported. B/mean(A,C)-1 is descriptive only. Negative time change is faster. No full-import or browser-performance claim.",
    "failure": "Any failed arm terminates the fixed cohort; retain all completed and failed observations, do not replace an arm.",
}
plan_path = args.output / "plan.json"
with plan_path.open("x") as file:
    json.dump(plan, file, indent=2)
    file.write("\n")
receipts = []
for entry in schedule:
    triple, label = entry["triple"], entry["label"]
    name = f"{triple:02d}-{label}"
    output = args.output / f"{name}.json"
    root = roots[label]
    command = [str(args.node), str(harness), "measure", str(root), str(root), str(args.fixtures), str(output)]
    print(f"Starting {name}", flush=True)
    started = time.time()
    with (args.output / f"{name}.log").open("x") as log:
        completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=False)
    receipt = {**entry, "command": command, "startedEpochSeconds": started, "elapsedSeconds": time.time() - started,
               "exitCode": completed.returncode, "logSha256": digest(args.output / f"{name}.log")}
    if output.exists():
        receipt["outputSha256"] = digest(output)
    receipts.append(receipt)
    (args.output / "receipts.json").write_text(json.dumps(receipts, indent=2) + "\n")
    assert completed.returncode == 0, receipt
    assert identity(root) == identities[label], f"Source changed during {name}"
    assert digest(harness) == plan["harnessSha256"], f"Harness changed during {name}"
    print(f"Finished {name}: {receipt['elapsedSeconds']:.3f}s", flush=True)
print("Completed all 12 predeclared arms", flush=True)
