# CRC word-half lowering, 2026-11-23

Local candidate `c19478fdbdf1310c85b348915fcbcfa8df02d08a` is based on `5e1f8c12f7ff798ba407323aff675cb23b22af02`. The parent published the identical tree as draft PR #817 at `4884b4bd93d45f152ec828bcca44990f18976a05`.

The candidate keeps the existing eight-lane, 64-byte braided CRC algorithm, tables, 256 KiB admission threshold, final fold and full-byte verification. It expresses each eight-byte input word as two explicit little-endian uint32 halves. The 32-bit lane state affects only the low half. This preserves all eight lookup indexes while removing repeated 64-bit extraction/conversion instructions.

## Mechanism and correctness

The pinned Clang/LLD 21.1.8 build and exact rebuild check passed. The production WASM changes in exactly one noncustom section, the code section, and one of its 44 function bodies: index 2, `crc32_bytes`. All other sections and function bodies remain byte-identical. Parser WASM size changes from 54,596 to 54,482 bytes.

Baseline WASM SHA-256: `cc749c53fc32dfb28eefbd69f99868f8c303caa1a3f1354231516dfa5a6e1b0f`.

Candidate WASM SHA-256: `f0dd04f21bd2c472691910bc8a04fb499a7eed42d7e566ca016332e04e8b02e5`.

In the emitted 64-byte braided loop, the baseline has eight i64 loads, 32 i64 shifts and 40 i32 wraps from i64. The candidate has none of those operations and uses sixteen i32 input loads. Counted integer opcodes decrease from 498 to 434. This is a static WASM instruction count, not an execution-time measurement or a machine-code cost model. Both versions already keep all eight lane states in locals and fully unroll the inner lane loop; no redundant state-memory store or inner loop was found.

`record-lowering.py` regenerates `lowering-receipt.json` from the retained baseline/candidate assembly and production modules. The receipt includes source, assembly, module and CRC-body hashes and identifies every changed function/section.

All 73 focused tests passed across the CRC, inflater and controlled-match suites. CRC coverage adds every tail modulo 64 at all 16 alignments plus physical input-memory-end placements; existing threshold vectors, published vectors and corrupted-checksum rejection remain covered.

The exact committed production binary passed `oracle.json`: every non-directory entry from all three pinned archives matched baseline and independent Node zlib byte-for-byte, with the production CRC/size/consumption checks active.

| Corpus | Entries | Uncompressed bytes | Output SHA-256 |
| --- | ---: | ---: | --- |
| JMdict | 55 | 171,110,164 | `6d3473707c7860e836dd6a04a5b9d4a5d3b5dc6aac52319e56558647cb5d7702` |
| Jitendex | 471 | 542,580,806 | `78cd42bd940cf84f54802b4b84d04c32b53a63e18500aaebb17375dc28e59b65` |
| VNDB | 147,237 | 4,456,124,609 | `5bdc59cab3c12f3c60cdcb014dc0fb2011f9eccec1bdbb5ab84e2e2150198dbc` |

This oracle covers inflated archive bytes and boundaries, not complete persisted database output, browser memory, user lookup latency or startup.

## Incomplete fixed local screen

The screen plan was frozen before observations: four triples in the order ABC, CBA, ABC, CBA; A and C use the identical baseline. Each arm is a fresh Node 22.22.0 process with one retained excluded warmup pass and one measured pass over all three corpora. The primary comparisons are B/A, B/C and same-code C/A separately. The adjacent-control mean is descriptive only. This fresh-process component experiment does not reproduce the full extension topology.

The first three arms, 01-A/B/C, completed. The first arm of the second triple, 02-C, was terminated by SIGKILL, recorded as exit code -9, after 16.443 seconds. The runner obeyed its predeclared failure rule: it stopped immediately, ran no remaining arms and made no retry or replacement. The complete four-triple cohort does not exist, and no local gain is claimed.

All three completed arm JSON files, their logs, the failed-arm log, the original plan and every process receipt remain in `screen/`. There are nine complete measured corpus passes and nine complete excluded warmup corpus passes. The failed-arm log retains two completed warmup corpus summaries before interruption; it never reached the measured pass or wrote its final per-group JSON. `partial-summary.json` validates retained identities/hashes and labels the first-triple numbers as descriptive only. The normal complete-cohort analyzer intentionally requires all 12 successful arms.

The cause of SIGKILL is not established. `/sys/fs/cgroup` and pressure counters were unavailable, kernel-log access was denied, and the visible host `oom_kill` counter was cumulative with no before snapshot. The frozen runner did not collect peak RSS, and the exited process's peak cannot be reconstructed. The later memory/load snapshot and these limitations are retained in `screen-failure-environment.json`.

The native browser qualification is a separate parent-owned study. This local bundle does not substitute for that study or infer a browser result from the incomplete component cohort.

## Reproduction

Use the unchanged `inflate-component.mjs`, the explicit baseline/candidate roots with matching `ext/lib` assets, the pinned archives and Node 22.22.0:

```sh
node inflate-component.mjs oracle /path/to/baseline /path/to/candidate /path/to/fixtures oracle-new.json
python3 record-lowering.py /path/to/baseline /path/to/candidate
```

The retained screen runner documents the original failed experiment. Re-running it would be a new experiment and must use a new output directory and a separately declared plan. No such rerun was performed here.
