import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import {openAsBlob} from 'node:fs'
import {readFile, writeFile} from 'node:fs/promises'
import {performance} from 'node:perf_hooks'
import path from 'node:path'
import {pathToFileURL} from 'node:url'
import {inflateRawSync} from 'node:zlib'

const [mode, baselineRoot, candidateRoot, fixtureRoot, outputPath] = process.argv.slice(2)
assert.ok(['oracle', 'measure'].includes(mode))
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
async function identity(root) {
    const files = {}
    for (const name of ['ext/js/dictionary/term-bank-wasm-parser.js', 'ext/js/dictionary/wasm/term-bank-inflate.c',
        'ext/js/dictionary/wasm/vendor/libdeflate/lib/decompress_template.h', 'ext/js/dictionary/wasm/vendor/libdeflate/common_defs.h',
        'ext/js/dictionary/wasm/term-bank-parser.c', 'ext/lib/term-bank-parser.wasm', 'dev/data/dictionary-wasm/manifest.json', 'package-lock.json']) {
        files[name] = sha256(await readFile(path.join(root, name)))
    }
    const git = (...args) => execFileSync('git', ['-C', root, ...args], {encoding: 'utf8'}).trim()
    return {root, head: git('rev-parse', 'HEAD'), trackedDiffSha256: sha256(git('diff', '--binary', 'HEAD')), files}
}
async function load(root) {
    const parser = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-bank-wasm-parser.js')))
    const bytes = await readFile(path.join(root, 'ext/lib/term-bank-parser.wasm'))
    const module = await WebAssembly.compile(bytes)
    assert.deepEqual(WebAssembly.Module.imports(module), [])
    parser.setTermBankWasmModule(module)
    return parser
}
const identities = [await identity(baselineRoot), await identity(candidateRoot)]
const baseline = await load(baselineRoot)
const candidate = mode === 'oracle' ? await load(candidateRoot) : baseline
const {readDenseZipDirectory} = await import(pathToFileURL(path.join(baselineRoot, 'ext/js/dictionary/dense-zip-directory.js')))
const {RawZipPayloadReader} = await import(pathToFileURL(path.join(baselineRoot, 'ext/js/dictionary/term-bank-source-pipeline.js')))
const {ZipReader, Uint8ArrayReader} = await import(pathToFileURL(path.join(baselineRoot, 'ext/lib/zip.js')))
const lock = JSON.parse(await readFile(path.join(baselineRoot, 'test/perf/dictionaries.lock.json'), 'utf8')).dictionaries
const fixtures = [
    {id: 'jmdict', ...lock.jmdict, expectedTermBanks: 53, expectedTermBytes: 171092992, groups: 12},
    {id: 'jitendex', ...lock.jitendex, expectedTermBanks: 218, expectedTermBytes: 537538792, groups: 22},
    {id: 'vndb', cacheFile: 'vndb_characters_by_bee.zip', sha256: 'da5baed5332761513dcef8d0b07ad0d9201cdd7f37831dea37e7162994ec3792',
        sizeBytes: 291705969, expectedTermBanks: 665, expectedTermBytes: 4267992967, groups: 170},
]

function partition(banks, count) {
    let remainingBytes = banks.reduce((sum, bank) => sum + bank.uncompressedSize, 0)
    const groups = []
    let start = 0
    for (let index = 0; index < count - 1; ++index) {
        const remainingGroups = count - index
        const target = remainingBytes / remainingGroups
        let end = start + 1
        let bytes = banks[start].uncompressedSize
        while (end < banks.length - (remainingGroups - 1)) {
            const next = bytes + banks[end].uncompressedSize
            if (Math.abs(next - target) > Math.abs(bytes - target)) break
            bytes = next
            ++end
        }
        groups.push(banks.slice(start, end))
        start = end
        remainingBytes -= bytes
    }
    groups.push(banks.slice(start))
    return groups
}

async function prepare(fixture) {
    const archivePath = path.join(fixtureRoot, fixture.cacheFile)
    const archiveBytes = await readFile(archivePath)
    assert.equal(archiveBytes.length, fixture.sizeBytes)
    assert.equal(sha256(archiveBytes), fixture.sha256)
    assert.equal(archiveBytes.byteOffset, 0)
    assert.equal(archiveBytes.buffer.byteLength, archiveBytes.byteLength)
    let entries = await readDenseZipDirectory(await openAsBlob(archivePath))
    if (entries === null) {
        const zip = new ZipReader(new Uint8ArrayReader(Uint8Array.from(archiveBytes)), {useWebWorkers: false})
        entries = await zip.getEntries()
        await zip.close()
    }
    const archiveContent = RawZipPayloadReader.supportsArchive(archiveBytes.buffer) ? archiveBytes.buffer : new Blob([archiveBytes])
    const reader = new RawZipPayloadReader(archiveContent)
    const signal = new AbortController().signal
    const isTermBank = ({filename}) => /^term_bank_\d+\.json$/.test(filename)
    const banks = entries.filter(isTermBank).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
    assert.equal(banks.length, fixture.expectedTermBanks)
    assert.equal(banks.reduce((sum, bank) => sum + bank.uncompressedSize, 0), fixture.expectedTermBytes)
    const groups = partition(banks, fixture.groups)
    assert.ok(groups.every((group) => group.length > 1))
    const preparedGroups = []
    for (const group of groups) {
        const prepared = []
        for (const bank of group) prepared.push({...bank, bytes: await reader.read(bank, signal)})
        preparedGroups.push(prepared)
    }
    const otherBatches = []
    if (mode === 'oracle') {
        let batch = []
        let compressed = 0
        let uncompressed = 0
        for (const entry of entries.filter((entry) => !entry.directory && !isTermBank(entry))) {
            assert.ok(entry.compressedSize <= 4 * 1024 * 1024 && entry.uncompressedSize <= 4 * 1024 * 1024, entry.filename)
            if (batch.length >= 1024 || compressed + entry.compressedSize > 4 * 1024 * 1024 || uncompressed + entry.uncompressedSize > 4 * 1024 * 1024) {
                otherBatches.push(batch)
                batch = []
                compressed = uncompressed = 0
            }
            batch.push({...entry, bytes: await reader.read(entry, signal)})
            compressed += entry.compressedSize
            uncompressed += entry.uncompressedSize
        }
        if (batch.length > 0) otherBatches.push(batch)
    }
    return {fixture, groups: preparedGroups, otherBatches, archiveEntries: entries.filter((entry) => !entry.directory).length}
}

async function inflateTerms(parser, sources) {
    const started = performance.now()
    const result = await parser.inflateCompressedTermBankSourcesWasm(sources)
    const wrapperMs = performance.now() - started
    const expectedBytes = sources.reduce((sum, source) => sum + source.uncompressedSize, 0)
    assert.equal(result.jsonLength, expectedBytes)
    assert.equal(result.bankSpanCount, sources.length)
    return {result, wrapperMs, nativeInflateCrcMs: result.inflateMs}
}

const corpora = []
for (const fixture of fixtures) {
    corpora.push(await prepare(fixture))
    console.log(JSON.stringify({prepared: fixture.id, banks: fixture.expectedTermBanks, groups: fixture.groups}))
}
const observations = []
const parity = []
if (mode === 'oracle') {
    for (const corpus of corpora) {
        const outputHash = createHash('sha256')
        let files = 0
        let bytes = 0
        const check = (source, first, second) => {
            const independent = source.compressionMethod === 0 ? source.bytes : inflateRawSync(source.bytes)
            assert.equal(independent.length, source.uncompressedSize)
            assert.equal(Buffer.compare(first, independent), 0, `${corpus.fixture.id}:${source.filename}:baseline`)
            assert.equal(Buffer.compare(second, independent), 0, `${corpus.fixture.id}:${source.filename}:candidate`)
            outputHash.update(`${source.filename}\0${independent.length}\0`)
            outputHash.update(independent)
            ++files
            bytes += independent.length
        }
        for (const sources of corpus.groups) {
            const {result: first} = await inflateTerms(baseline, sources)
            const {result: second} = await inflateTerms(candidate, sources)
            const firstSpans = new Uint32Array(first.wasm.memory.buffer, first.bankSpansPtr, sources.length * 2)
            const secondSpans = new Uint32Array(second.wasm.memory.buffer, second.bankSpansPtr, sources.length * 2)
            assert.deepEqual(secondSpans, firstSpans)
            for (let i = 0; i < sources.length; ++i) {
                assert.equal(firstSpans[i * 2 + 1], sources[i].uncompressedSize)
                check(sources[i], new Uint8Array(first.wasm.memory.buffer, first.jsonPtr + firstSpans[i * 2], firstSpans[i * 2 + 1]),
                    new Uint8Array(second.wasm.memory.buffer, second.jsonPtr + secondSpans[i * 2], secondSpans[i * 2 + 1]))
            }
        }
        for (const sources of corpus.otherBatches) {
            const first = await baseline.inflateCompressedZipMediaBatchWasm(sources)
            const second = await candidate.inflateCompressedZipMediaBatchWasm(sources)
            assert.equal(first.sources.length, sources.length)
            assert.equal(second.sources.length, sources.length)
            for (let i = 0; i < sources.length; ++i) check(sources[i], first.sources[i], second.sources[i])
        }
        assert.equal(files, corpus.archiveEntries)
        parity.push({dictionary: corpus.fixture.id, files, bytes, outputSha256: outputHash.digest('hex')})
        console.log(JSON.stringify(parity.at(-1)))
    }
} else {
    // Predetermined single complete warmup; its observations remain recorded.
    for (const warmup of [true, false]) {
        for (const corpus of corpora) {
            const groups = []
            for (let i = 0; i < corpus.groups.length; ++i) {
                const sources = corpus.groups[i]
                const {result, wrapperMs, nativeInflateCrcMs} = await inflateTerms(baseline, sources)
                groups.push({index: i, banks: sources.map(({filename}) => filename), compressedBytes: result.compressedBytes,
                    outputBytes: result.uncompressedBytes, wrapperMs, nativeInflateCrcMs})
            }
            const observation = {dictionary: corpus.fixture.id, warmup, groups,
                wrapperMs: groups.reduce((sum, row) => sum + row.wrapperMs, 0),
                nativeInflateCrcMs: groups.reduce((sum, row) => sum + row.nativeInflateCrcMs, 0)}
            observations.push(observation)
            console.log(JSON.stringify({dictionary: observation.dictionary, warmup, wrapperMs: observation.wrapperMs, nativeInflateCrcMs: observation.nativeInflateCrcMs}))
        }
    }
}
assert.deepEqual(await identity(baselineRoot), identities[0])
assert.deepEqual(await identity(candidateRoot), identities[1])
await writeFile(outputPath, JSON.stringify({schemaVersion: 1, mode, runtime: process.version, versions: process.versions,
    harnessSha256: sha256(await readFile(new URL(import.meta.url))), identities,
    boundary: 'resident compressed term payloads through production native inflation, full CRC, and array-boundary checks; wrapper timing also includes allocation/metadata/input-copy; excludes fixture I/O, validation hashing, parsing, IPC, storage and UI',
    grouping: '12 JMdict / 22 Jitendex / 170 VNDB groups using production byte-balancing; matches frozen Chromium three-worker receipts',
    fixtures, observations, parity}, null, 2) + '\n')
