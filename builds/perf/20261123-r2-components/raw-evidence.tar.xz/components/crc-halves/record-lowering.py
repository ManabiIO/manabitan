#!/usr/bin/env python3
"""Record pinned CRC assembly and production-module differences without timing."""

from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def unsigned_leb(data, at):
    value = shift = 0
    while True:
        byte = data[at]
        at += 1
        value |= (byte & 127) << shift
        if not byte & 128:
            return value, at
        shift += 7


def sections_and_bodies(data):
    sections = {}
    bodies = []
    at = 8
    assert data[:8] == b"\0asm\x01\0\0\0"
    while at < len(data):
        section = data[at]
        size, start = unsigned_leb(data, at + 1)
        end = start + size
        if section != 0:
            assert section not in sections
            sections[section] = data[start:end]
        if section == 10:
            count, cursor = unsigned_leb(data, start)
            for _ in range(count):
                length, cursor = unsigned_leb(data, cursor)
                bodies.append(data[cursor:cursor + length])
                cursor += length
            assert cursor == end
        at = end
    return sections, bodies


directory = Path(__file__).resolve().parent
baseline, candidate = map(Path, sys.argv[1:3])
result = {"schemaVersion": 1, "compiler": "Clang 21.1.8", "linker": "LLD 21.1.8",
          "compileArguments": ["--target=wasm32-freestanding", "-O3", "-matomics", "-mbulk-memory", "-msimd128", "-nostdlib", "-S"],
          "scope": "Static emitted integer opcode counts, not execution counts or measured machine-code cost. The pinned compiler unrolls all eight lane updates; LBB3_74 is the sole outer 64-byte loop.",
          "variants": {}}
modules = []
for label, root in [("baseline", baseline), ("candidate", candidate)]:
    assembly_path = directory / f"{label}-parser.s"
    assembly = assembly_path.read_text()
    function = assembly.split("\ncrc32_bytes:", 1)[1].split("\n\tend_function", 1)[0]
    loop = function.split(".LBB3_74:", 1)[1].split("# %bb.75:", 1)[0]
    opcode_counts = lambda text: dict(sorted(Counter(re.findall(r"^\s+((?:i32|i64)\.[a-z0-9_]+)", text, re.M)).items()))
    function_counts = opcode_counts(function)
    loop_counts = opcode_counts(loop)
    assert not any(key.endswith(".store") or ".store" in key for key in loop_counts)
    wasm = (root / "dev/data/dictionary-wasm/term-bank-parser.wasm").read_bytes()
    sections, bodies = sections_and_bodies(wasm)
    modules.append((sections, bodies))
    result["variants"][label] = {
        "root": str(root.resolve()), "sourceSha256": sha256((root / "ext/js/dictionary/wasm/term-bank-parser.c").read_bytes()),
        "assemblySha256": sha256(assembly_path.read_bytes()), "wasmSha256": sha256(wasm), "wasmBytes": len(wasm),
        "crcFunctionIndex": 2, "crcBodySha256": sha256(bodies[2]), "crcBodyBytes": len(bodies[2]),
        "crcFunctionIntegerOpcodes": function_counts, "crcFunctionIntegerOpcodeCount": sum(function_counts.values()),
        "braidedLoopIntegerOpcodes": loop_counts, "braidedLoopIntegerOpcodeCount": sum(loop_counts.values()),
        "braidedLoopStateMemoryStores": 0,
    }
    (directory / f"{label}-crc.s").write_text("crc32_bytes:" + function + "\n\tend_function\n")
base_sections, base_bodies = modules[0]
candidate_sections, candidate_bodies = modules[1]
assert base_sections.keys() == candidate_sections.keys()
assert len(base_bodies) == len(candidate_bodies)
result["changedNonCustomSections"] = [key for key in base_sections if base_sections[key] != candidate_sections[key]]
result["changedFunctionIndexes"] = [index for index, (a, b) in enumerate(zip(base_bodies, candidate_bodies, strict=True)) if a != b]
result["totalDefinedFunctions"] = len(base_bodies)
result["scriptSha256"] = sha256(Path(__file__).read_bytes())
(directory / "lowering-receipt.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result))
