	.file	"term-bank-parser.c"
	.globaltype	__stack_pointer, i32
	.functype	memset (i32, i32, i32) -> (i32)
	.functype	memcpy (i32, i32, i32) -> (i32)
	.functype	inflate_and_join_term_banks (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	term_bank_inflate (i32, i32, i32, i32) -> (i32)
	.functype	crc32_bytes (i32, i32) -> (i32)
	.functype	inflate_zip_media_batch (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	wasm_reset_heap () -> ()
	.functype	wasm_alloc (i32) -> (i32)
	.functype	wasm_get_last_parse_capacity () -> (i32)
	.functype	wasm_get_last_content_capacity () -> (i32)
	.functype	parse_term_bank (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_term_bank_impl (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_term_bank_with_media_hints (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content (i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_impl (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_no_hash (i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_token_binary (i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_token_binary_row (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	build_term_string_plan (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	content_bytes_equal (i32, i32, i32, i32) -> (i32)
	.functype	decode_escaped_key (i32, i32, i32, i32) -> (i32)
	.functype	hash_content_xxh32 (i32, i32, i32) -> (i32)
	.functype	copy_valid_utf8 (i32, i32, i32) -> (i32)
	.functype	encode_term_lookup_index (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	encode_term_content_token_binary_dedup (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	parse_and_encode_term_bank_token_binary_dedup (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	next_term_bank (i32) -> (i32)
	.functype	parse_row_single_pass (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	scan_scalar_span (i32, i32, i32, i32) -> (i32)
	.functype	parse_int32_token (i32, i32, i32, i32, i32) -> (i32)
	.functype	raw_term_content_hash (i32, i32) -> (i32)
	.functype	raw_term_content_tokens_equal (i32, i32, i32, i32) -> (i32)
	.functype	raw_term_content_quick_signature (i32, i32) -> (i32)
	.functype	next_term_row (i32, i32) -> (i32)
	.functype	compact_term_lookup_keys (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	write_normalized_glossary_value (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	hash_content_xxh32_pair (i32, i32, i32, i32) -> ()
	.functype	parse_value_span (i32, i32, i32, i32) -> (i32)
	.functype	parse_scalar_span (i32, i32, i32, i32) -> (i32)
	.functype	parse_composite_span_impl (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.functype	json_string_matches_ascii_escaped (i32, i32, i32, i32, i32) -> (i32)
	.functype	key_hex4 (i32) -> (i32)
	.functype	is_valid_json_number (i32, i32, i32) -> (i32)
	.section	.text.memset,"",@
	.hidden	memset                          # -- Begin function memset
	.globl	memset
	.type	memset,@function
memset:                                 # @memset
	.functype	memset (i32, i32, i32) -> (i32)
# %bb.0:
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label0
# %bb.1:
	local.get	0
	local.get	1
	local.get	2
	memory.fill	0
.LBB0_2:
	end_block                               # label0:
	local.get	0
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.memcpy,"",@
	.hidden	memcpy                          # -- Begin function memcpy
	.globl	memcpy
	.type	memcpy,@function
memcpy:                                 # @memcpy
	.functype	memcpy (i32, i32, i32) -> (i32)
# %bb.0:
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label1
# %bb.1:
	local.get	0
	local.get	1
	local.get	2
	memory.copy	0, 0
.LBB1_2:
	end_block                               # label1:
	local.get	0
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.inflate_and_join_term_banks,"",@
	.globl	inflate_and_join_term_banks     # -- Begin function inflate_and_join_term_banks
	.type	inflate_and_join_term_banks,@function
inflate_and_join_term_banks:            # @inflate_and_join_term_banks
	.functype	inflate_and_join_term_banks (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-1
	local.set	11
	block   	
	local.get	7
	i32.eqz
	br_if   	0                               # 0: down to label2
# %bb.1:
	local.get	9
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label2
# %bb.2:
	block   	
	local.get	10
	br_if   	0                               # 0: down to label3
# %bb.3:
	local.get	8
	i32.const	91
	i32.store8	0
.LBB2_4:
	end_block                               # label3:
	local.get	10
	i32.eqz
	local.set	12
	local.get	8
	i32.const	1
	i32.add 
	local.set	13
	i32.const	0
	local.set	14
	i32.const	0
	local.set	15
.LBB2_5:                                # =>This Loop Header: Depth=1
                                        #     Child Loop BB2_18 Depth 2
                                        #     Child Loop BB2_25 Depth 2
                                        #     Child Loop BB2_35 Depth 2
                                        #     Child Loop BB2_40 Depth 2
	loop    	                                # label4:
	i32.const	-1
	local.set	11
	local.get	1
	local.get	2
	local.get	15
	i32.const	2
	i32.shl 
	local.tee	16
	i32.add 
	i32.load	0
	local.tee	17
	i32.lt_u
	br_if   	1                               # 1: down to label2
# %bb.6:                                #   in Loop: Header=BB2_5 Depth=1
	local.get	3
	local.get	16
	i32.add 
	i32.load	0
	local.tee	18
	local.get	1
	local.get	17
	i32.sub 
	i32.gt_u
	br_if   	1                               # 1: down to label2
# %bb.7:                                #   in Loop: Header=BB2_5 Depth=1
	local.get	4
	local.get	16
	i32.add 
	i32.load	0
	local.tee	19
	local.get	9
	local.get	12
	i32.sub 
	i32.gt_u
	br_if   	1                               # 1: down to label2
# %bb.8:                                #   in Loop: Header=BB2_5 Depth=1
	local.get	8
	local.get	12
	i32.add 
	local.set	20
	i32.const	-1
	local.set	11
	block   	
	block   	
	block   	
	local.get	5
	local.get	16
	i32.add 
	i32.load	0
	br_table 	{0, 4, 4, 4, 4, 4, 4, 4, 1, 4} # 4: down to label2
                                        # 1: down to label6
.LBB2_9:                                #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label7:
	block   	
	local.get	18
	local.get	19
	i32.eq  
	br_if   	0                               # 0: down to label8
# %bb.10:
	i32.const	-3
	return
.LBB2_11:                               #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label8:
	local.get	18
	i32.eqz
	br_if   	1                               # 1: down to label5
# %bb.12:                               #   in Loop: Header=BB2_5 Depth=1
	local.get	20
	local.get	0
	local.get	17
	i32.add 
	local.get	18
	memory.copy	0, 0
	br      	1                               # 1: down to label5
.LBB2_13:                               #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label6:
	local.get	0
	local.get	17
	i32.add 
	local.get	18
	local.get	20
	local.get	19
	call	term_bank_inflate
	local.tee	11
	br_if   	2                               # 2: down to label2
.LBB2_14:                               #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label5:
	block   	
	local.get	20
	local.get	19
	call	crc32_bytes
	local.get	6
	local.get	16
	i32.add 
	i32.load	0
	i32.eq  
	br_if   	0                               # 0: down to label9
# %bb.15:
	i32.const	-4
	return
.LBB2_16:                               #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label9:
	local.get	19
	local.set	16
	local.get	19
	local.set	17
	block   	
	local.get	19
	i32.eqz
	br_if   	0                               # 0: down to label10
# %bb.17:                               #   in Loop: Header=BB2_5 Depth=1
	i32.const	0
	local.set	16
.LBB2_18:                               #   Parent Loop BB2_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label12:
	local.get	20
	local.get	16
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	17
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label11
# %bb.19:                               #   in Loop: Header=BB2_18 Depth=2
	i32.const	1
	local.get	17
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label11
# %bb.20:                               #   in Loop: Header=BB2_18 Depth=2
	local.get	19
	local.get	16
	i32.const	1
	i32.add 
	local.tee	16
	i32.ne  
	br_if   	0                               # 0: up to label12
# %bb.21:                               #   in Loop: Header=BB2_5 Depth=1
	end_loop
	local.get	19
	local.set	16
	local.get	19
	local.set	17
	br      	1                               # 1: down to label10
.LBB2_22:                               #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label11:
	block   	
	local.get	19
	local.get	16
	i32.gt_u
	br_if   	0                               # 0: down to label13
# %bb.23:                               #   in Loop: Header=BB2_5 Depth=1
	local.get	19
	local.set	17
	br      	1                               # 1: down to label10
.LBB2_24:                               #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label13:
	local.get	20
	i32.const	-1
	i32.add 
	local.set	18
	local.get	19
	local.set	17
.LBB2_25:                               #   Parent Loop BB2_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label14:
	local.get	18
	local.get	17
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	11
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label10
# %bb.26:                               #   in Loop: Header=BB2_25 Depth=2
	i32.const	1
	local.get	11
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label10
# %bb.27:                               #   in Loop: Header=BB2_25 Depth=2
	local.get	17
	i32.const	-1
	i32.add 
	local.tee	17
	local.get	16
	i32.gt_u
	br_if   	0                               # 0: up to label14
# %bb.28:                               #   in Loop: Header=BB2_5 Depth=1
	end_loop
	local.get	16
	local.set	17
.LBB2_29:                               #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label10:
	i32.const	-5
	local.set	11
	local.get	17
	local.get	16
	i32.sub 
	i32.const	2
	i32.lt_u
	br_if   	1                               # 1: down to label2
# %bb.30:                               #   in Loop: Header=BB2_5 Depth=1
	local.get	20
	local.get	16
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	1                               # 1: down to label2
# %bb.31:                               #   in Loop: Header=BB2_5 Depth=1
	local.get	20
	local.get	17
	i32.add 
	i32.const	-1
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	1                               # 1: down to label2
# %bb.32:                               #   in Loop: Header=BB2_5 Depth=1
	block   	
	local.get	10
	br_if   	0                               # 0: down to label15
# %bb.33:                               #   in Loop: Header=BB2_5 Depth=1
	block   	
	block   	
	local.get	16
	i32.const	1
	i32.add 
	local.tee	11
	local.get	17
	i32.const	-1
	i32.add 
	local.tee	19
	i32.ge_u
	br_if   	0                               # 0: down to label17
# %bb.34:                               #   in Loop: Header=BB2_5 Depth=1
	local.get	13
	local.get	12
	i32.add 
	local.set	11
	local.get	17
	i32.const	-2
	i32.add 
	local.set	18
.LBB2_35:                               #   Parent Loop BB2_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label19:
	local.get	11
	local.get	16
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	17
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label18
# %bb.36:                               #   in Loop: Header=BB2_35 Depth=2
	i32.const	1
	local.get	17
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label18
# %bb.37:                               #   in Loop: Header=BB2_35 Depth=2
	local.get	18
	local.get	16
	i32.const	1
	i32.add 
	local.tee	16
	i32.eq  
	br_if   	3                               # 3: down to label16
	br      	0                               # 0: up to label19
.LBB2_38:                               #   in Loop: Header=BB2_5 Depth=1
	end_loop
	end_block                               # label18:
	local.get	16
	i32.const	1
	i32.add 
	local.set	11
.LBB2_39:                               #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label17:
	block   	
	local.get	19
	local.get	11
	i32.le_u
	br_if   	0                               # 0: down to label20
.LBB2_40:                               #   Parent Loop BB2_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label21:
	local.get	20
	local.get	19
	i32.add 
	i32.const	-1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	16
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label20
# %bb.41:                               #   in Loop: Header=BB2_40 Depth=2
	i32.const	1
	local.get	16
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label20
# %bb.42:                               #   in Loop: Header=BB2_40 Depth=2
	local.get	19
	i32.const	-1
	i32.add 
	local.tee	19
	local.get	11
	i32.gt_u
	br_if   	0                               # 0: up to label21
	br      	2                               # 2: down to label16
.LBB2_43:                               #   in Loop: Header=BB2_5 Depth=1
	end_loop
	end_block                               # label20:
	local.get	19
	local.get	11
	i32.eq  
	br_if   	0                               # 0: down to label16
# %bb.44:                               #   in Loop: Header=BB2_5 Depth=1
	block   	
	local.get	14
	i32.eqz
	br_if   	0                               # 0: down to label22
# %bb.45:                               #   in Loop: Header=BB2_5 Depth=1
	local.get	20
	i32.const	44
	i32.store8	0
	local.get	12
	i32.const	1
	i32.add 
	local.set	12
.LBB2_46:                               #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label22:
	local.get	19
	local.get	11
	i32.sub 
	local.set	16
	block   	
	local.get	8
	local.get	12
	i32.add 
	local.tee	17
	local.get	20
	local.get	11
	i32.add 
	local.tee	19
	i32.eq  
	br_if   	0                               # 0: down to label23
# %bb.47:                               #   in Loop: Header=BB2_5 Depth=1
	local.get	16
	i32.eqz
	br_if   	0                               # 0: down to label23
# %bb.48:                               #   in Loop: Header=BB2_5 Depth=1
	local.get	17
	local.get	19
	local.get	16
	memory.copy	0, 0
.LBB2_49:                               #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label23:
	local.get	14
	i32.const	1
	i32.add 
	local.set	14
	local.get	12
	local.get	16
	i32.add 
	local.set	12
.LBB2_50:                               #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label16:
	local.get	15
	i32.const	1
	i32.add 
	local.tee	15
	local.get	7
	i32.ne  
	br_if   	1                               # 1: up to label4
# %bb.51:
	i32.const	-1
	local.set	11
	local.get	12
	local.get	9
	i32.ge_u
	br_if   	2                               # 2: down to label2
# %bb.52:
	local.get	8
	local.get	12
	i32.add 
	i32.const	93
	i32.store8	0
	local.get	12
	i32.const	1
	i32.add 
	local.set	11
	br      	2                               # 2: down to label2
.LBB2_53:                               #   in Loop: Header=BB2_5 Depth=1
	end_block                               # label15:
	local.get	10
	local.get	15
	i32.const	3
	i32.shl 
	i32.add 
	local.tee	16
	local.get	19
	i32.store	4
	local.get	16
	local.get	12
	i32.store	0
	local.get	19
	local.get	12
	i32.add 
	local.tee	12
	local.set	11
	local.get	15
	i32.const	1
	i32.add 
	local.tee	15
	local.get	7
	i32.ne  
	br_if   	0                               # 0: up to label4
.LBB2_54:
	end_loop
	end_block                               # label2:
	local.get	11
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.crc32_bytes,"",@
	.type	crc32_bytes,@function           # -- Begin function crc32_bytes
crc32_bytes:                            # @crc32_bytes
	.functype	crc32_bytes (i32, i32) -> (i32)
	.local  	v128, i32, v128, v128, v128, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	block   	
	i32.const	0
	i32.load8_u	crc32_table_initialized
	br_if   	0                               # 0: down to label24
# %bb.1:
	v128.const	0, 1, 2, 3
	local.set	2
	i32.const	-1024
	local.set	3
.LBB3_2:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label25:
	local.get	3
	i32.const	crc32_table+1024
	i32.add 
	local.get	2
	v128.const	2, 2, 2, 2
	v128.and
	v128.const	0, 0, 0, 0
	local.tee	4
	i32x4.ne
	v128.const	-306674912, -306674912, -306674912, -306674912
	local.tee	5
	v128.and
	local.get	2
	v128.const	1, 1, 1, 1
	v128.and
	local.get	4
	i32x4.ne
	local.get	5
	v128.and
	local.get	2
	i32.const	1
	i32x4.shr_u
	v128.xor
	local.tee	6
	i32.const	1
	i32x4.shr_u
	v128.xor
	local.tee	7
	v128.const	32, 32, 32, 32
	local.tee	8
	v128.and
	local.get	4
	i32x4.ne
	local.get	5
	v128.and
	local.get	6
	local.get	8
	v128.and
	local.get	4
	i32x4.ne
	v128.const	1994146192, 1994146192, 1994146192, 1994146192
	v128.and
	local.get	2
	local.get	8
	v128.and
	local.get	4
	i32x4.ne
	v128.const	997073096, 997073096, 997073096, 997073096
	v128.and
	local.get	2
	v128.const	16, 16, 16, 16
	v128.and
	local.get	4
	i32x4.ne
	v128.const	498536548, 498536548, 498536548, 498536548
	v128.and
	local.get	2
	v128.const	8, 8, 8, 8
	v128.and
	local.get	4
	i32x4.ne
	v128.const	249268274, 249268274, 249268274, 249268274
	v128.and
	local.get	2
	v128.const	4, 4, 4, 4
	local.tee	5
	v128.and
	local.get	4
	i32x4.ne
	v128.const	124634137, 124634137, 124634137, 124634137
	v128.and
	local.get	7
	i32.const	6
	i32x4.shr_u
	v128.xor
	v128.xor
	v128.xor
	v128.xor
	v128.xor
	v128.xor
	v128.store	0
	local.get	2
	local.get	5
	i32x4.add
	local.set	2
	local.get	3
	i32.const	16
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label25
# %bb.3:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_4:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label26:
	local.get	3
	i32.const	crc32_table+2048
	i32.add 
	local.get	3
	i32.const	crc32_table+1024
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+2052
	i32.add 
	local.get	3
	i32.const	crc32_table+1028
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label26
# %bb.5:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_6:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label27:
	local.get	3
	i32.const	crc32_table+3072
	i32.add 
	local.get	3
	i32.const	crc32_table+2048
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+3076
	i32.add 
	local.get	3
	i32.const	crc32_table+2052
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label27
# %bb.7:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_8:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label28:
	local.get	3
	i32.const	crc32_table+4096
	i32.add 
	local.get	3
	i32.const	crc32_table+3072
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+4100
	i32.add 
	local.get	3
	i32.const	crc32_table+3076
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label28
# %bb.9:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_10:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label29:
	local.get	3
	i32.const	crc32_table+5120
	i32.add 
	local.get	3
	i32.const	crc32_table+4096
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+5124
	i32.add 
	local.get	3
	i32.const	crc32_table+4100
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label29
# %bb.11:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_12:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label30:
	local.get	3
	i32.const	crc32_table+6144
	i32.add 
	local.get	3
	i32.const	crc32_table+5120
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+6148
	i32.add 
	local.get	3
	i32.const	crc32_table+5124
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label30
# %bb.13:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_14:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label31:
	local.get	3
	i32.const	crc32_table+7168
	i32.add 
	local.get	3
	i32.const	crc32_table+6144
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+7172
	i32.add 
	local.get	3
	i32.const	crc32_table+6148
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label31
# %bb.15:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_16:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label32:
	local.get	3
	i32.const	crc32_table+8192
	i32.add 
	local.get	3
	i32.const	crc32_table+7168
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+8196
	i32.add 
	local.get	3
	i32.const	crc32_table+7172
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label32
# %bb.17:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_18:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label33:
	local.get	3
	i32.const	crc32_table+9216
	i32.add 
	local.get	3
	i32.const	crc32_table+8192
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+9220
	i32.add 
	local.get	3
	i32.const	crc32_table+8196
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label33
# %bb.19:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_20:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label34:
	local.get	3
	i32.const	crc32_table+10240
	i32.add 
	local.get	3
	i32.const	crc32_table+9216
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+10244
	i32.add 
	local.get	3
	i32.const	crc32_table+9220
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label34
# %bb.21:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_22:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label35:
	local.get	3
	i32.const	crc32_table+11264
	i32.add 
	local.get	3
	i32.const	crc32_table+10240
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+11268
	i32.add 
	local.get	3
	i32.const	crc32_table+10244
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label35
# %bb.23:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_24:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label36:
	local.get	3
	i32.const	crc32_table+12288
	i32.add 
	local.get	3
	i32.const	crc32_table+11264
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+12292
	i32.add 
	local.get	3
	i32.const	crc32_table+11268
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label36
# %bb.25:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_26:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label37:
	local.get	3
	i32.const	crc32_table+13312
	i32.add 
	local.get	3
	i32.const	crc32_table+12288
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+13316
	i32.add 
	local.get	3
	i32.const	crc32_table+12292
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label37
# %bb.27:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_28:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label38:
	local.get	3
	i32.const	crc32_table+14336
	i32.add 
	local.get	3
	i32.const	crc32_table+13312
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+14340
	i32.add 
	local.get	3
	i32.const	crc32_table+13316
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label38
# %bb.29:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_30:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label39:
	local.get	3
	i32.const	crc32_table+15360
	i32.add 
	local.get	3
	i32.const	crc32_table+14336
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+15364
	i32.add 
	local.get	3
	i32.const	crc32_table+14340
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label39
# %bb.31:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_32:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label40:
	local.get	3
	i32.const	crc32_table+16384
	i32.add 
	local.get	3
	i32.const	crc32_table+15360
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+16388
	i32.add 
	local.get	3
	i32.const	crc32_table+15364
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label40
# %bb.33:
	end_loop
	i32.const	0
	i32.const	1
	i32.store8	crc32_table_initialized
.LBB3_34:
	end_block                               # label24:
	block   	
	block   	
	block   	
	block   	
	local.get	1
	i32.const	262143
	i32.gt_u
	br_if   	0                               # 0: down to label44
# %bb.35:
	block   	
	local.get	1
	i32.const	16
	i32.ge_u
	br_if   	0                               # 0: down to label45
# %bb.36:
	i32.const	0
	local.set	9
	i32.const	-1
	local.set	3
	br      	3                               # 3: down to label42
.LBB3_37:
	end_block                               # label45:
	i32.const	-1
	local.set	3
	local.get	1
	local.set	10
	local.get	0
	local.set	9
.LBB3_38:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label46:
	local.get	9
	i32.load	0:p2align=0
	local.get	3
	i32.xor 
	local.tee	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+14336
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+15360
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+13312
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+12288
	i32.xor 
	local.get	9
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+11264
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+10240
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+9216
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+8192
	i32.xor 
	local.get	9
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	9
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.set	3
	local.get	9
	i32.const	16
	i32.add 
	local.set	9
	local.get	10
	i32.const	-16
	i32.add 
	local.tee	10
	i32.const	15
	i32.gt_u
	br_if   	0                               # 0: up to label46
	br      	2                               # 2: down to label43
.LBB3_39:
	end_loop
	end_block                               # label44:
	i32.const	0
	local.set	10
	block   	
	i32.const	0
	i32.load8_u	crc32_braid_initialized
	br_if   	0                               # 0: down to label47
# %bb.40:
.LBB3_41:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_42 Depth 2
	loop    	                                # label48:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table
	local.set	3
	i32.const	56
	local.set	9
.LBB3_42:                               #   Parent Loop BB3_41 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label49:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label49
# %bb.43:                               #   in Loop: Header=BB3_41 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label48
# %bb.44:
	end_loop
	i32.const	0
	local.set	10
.LBB3_45:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_46 Depth 2
	loop    	                                # label50:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+1024
	local.set	3
	i32.const	56
	local.set	9
.LBB3_46:                               #   Parent Loop BB3_45 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label51:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label51
# %bb.47:                               #   in Loop: Header=BB3_45 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+1024
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label50
# %bb.48:
	end_loop
	i32.const	0
	local.set	10
.LBB3_49:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_50 Depth 2
	loop    	                                # label52:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+2048
	local.set	3
	i32.const	56
	local.set	9
.LBB3_50:                               #   Parent Loop BB3_49 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label53:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label53
# %bb.51:                               #   in Loop: Header=BB3_49 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+2048
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label52
# %bb.52:
	end_loop
	i32.const	0
	local.set	10
.LBB3_53:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_54 Depth 2
	loop    	                                # label54:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+3072
	local.set	3
	i32.const	56
	local.set	9
.LBB3_54:                               #   Parent Loop BB3_53 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label55:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label55
# %bb.55:                               #   in Loop: Header=BB3_53 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+3072
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label54
# %bb.56:
	end_loop
	i32.const	0
	local.set	10
.LBB3_57:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_58 Depth 2
	loop    	                                # label56:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+4096
	local.set	3
	i32.const	56
	local.set	9
.LBB3_58:                               #   Parent Loop BB3_57 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label57:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label57
# %bb.59:                               #   in Loop: Header=BB3_57 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+4096
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label56
# %bb.60:
	end_loop
	i32.const	0
	local.set	10
.LBB3_61:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_62 Depth 2
	loop    	                                # label58:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+5120
	local.set	3
	i32.const	56
	local.set	9
.LBB3_62:                               #   Parent Loop BB3_61 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label59:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label59
# %bb.63:                               #   in Loop: Header=BB3_61 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+5120
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label58
# %bb.64:
	end_loop
	i32.const	0
	local.set	10
.LBB3_65:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_66 Depth 2
	loop    	                                # label60:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+6144
	local.set	3
	i32.const	56
	local.set	9
.LBB3_66:                               #   Parent Loop BB3_65 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label61:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label61
# %bb.67:                               #   in Loop: Header=BB3_65 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+6144
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label60
# %bb.68:
	end_loop
	i32.const	0
	local.set	10
.LBB3_69:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_70 Depth 2
	loop    	                                # label62:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+7168
	local.set	3
	i32.const	56
	local.set	9
.LBB3_70:                               #   Parent Loop BB3_69 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label63:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label63
# %bb.71:                               #   in Loop: Header=BB3_69 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+7168
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label62
# %bb.72:
	end_loop
	i32.const	0
	i32.const	1
	i32.store8	crc32_braid_initialized
.LBB3_73:
	end_block                               # label47:
	local.get	1
	i32.const	-64
	i32.and 
	local.tee	12
	i32.const	-64
	i32.add 
	local.set	13
	i32.const	-1
	local.set	11
	i32.const	0
	local.set	14
	i32.const	0
	local.set	15
	i32.const	0
	local.set	16
	i32.const	0
	local.set	17
	i32.const	0
	local.set	18
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
	i32.const	0
	local.set	10
.LBB3_74:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label64:
	local.get	0
	local.get	10
	i32.add 
	local.tee	3
	i32.load	0:p2align=0
	local.get	11
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	3
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	11
	local.get	3
	i32.const	56
	i32.add 
	i32.load	0:p2align=0
	local.get	14
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	3
	i32.const	60
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	14
	local.get	3
	i32.const	48
	i32.add 
	i32.load	0:p2align=0
	local.get	15
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	3
	i32.const	52
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	15
	local.get	3
	i32.const	40
	i32.add 
	i32.load	0:p2align=0
	local.get	16
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	3
	i32.const	44
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	16
	local.get	3
	i32.const	32
	i32.add 
	i32.load	0:p2align=0
	local.get	17
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	3
	i32.const	36
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	17
	local.get	3
	i32.const	24
	i32.add 
	i32.load	0:p2align=0
	local.get	18
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	3
	i32.const	28
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	18
	local.get	3
	i32.const	16
	i32.add 
	i32.load	0:p2align=0
	local.get	19
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	3
	i32.const	20
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	19
	local.get	3
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	local.get	20
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	3
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	20
	local.get	10
	i32.const	64
	i32.add 
	local.tee	10
	local.get	13
	i32.lt_u
	br_if   	0                               # 0: up to label64
# %bb.75:
	end_loop
	local.get	0
	local.get	13
	i32.add 
	local.tee	3
	i32.load	0:p2align=0
	local.get	11
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	3
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i32.load	8:p2align=0
	i32.xor 
	local.get	20
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	3
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i32.load	16:p2align=0
	i32.xor 
	local.get	19
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	3
	i32.const	20
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i32.load	24:p2align=0
	i32.xor 
	local.get	18
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	3
	i32.const	28
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i32.load	32:p2align=0
	i32.xor 
	local.get	17
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	3
	i32.const	36
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i32.load	40:p2align=0
	i32.xor 
	local.get	16
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	3
	i32.const	44
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i32.load	48:p2align=0
	i32.xor 
	local.get	15
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	3
	i32.const	52
	i32.add 
	i32.load	0:p2align=0
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i32.load	56:p2align=0
	i32.xor 
	local.get	14
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	3
	i32.const	60
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.set	3
	local.get	12
	local.get	1
	i32.eq  
	br_if   	2                               # 2: down to label41
# %bb.76:
.LBB3_77:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label65:
	local.get	0
	local.get	12
	i32.add 
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	12
	i32.const	1
	i32.add 
	local.tee	12
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: up to label65
	br      	3                               # 3: down to label41
.LBB3_78:
	end_loop
	end_block                               # label43:
	local.get	1
	i32.const	262128
	i32.and 
	local.set	9
.LBB3_79:
	end_block                               # label42:
	local.get	9
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label41
# %bb.80:
	local.get	9
	i32.const	1
	i32.or  
	local.set	10
	block   	
	local.get	1
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label66
# %bb.81:
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	10
	local.set	9
.LBB3_82:
	end_block                               # label66:
	local.get	1
	local.get	10
	i32.eq  
	br_if   	0                               # 0: down to label41
# %bb.83:
	local.get	1
	local.get	9
	i32.sub 
	local.set	10
	local.get	0
	local.get	9
	i32.add 
	local.set	9
.LBB3_84:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label67:
	local.get	9
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.get	9
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	2
	i32.add 
	local.set	9
	local.get	10
	i32.const	-2
	i32.add 
	local.tee	10
	br_if   	0                               # 0: up to label67
.LBB3_85:
	end_loop
	end_block                               # label41:
	local.get	3
	i32.const	-1
	i32.xor 
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.inflate_zip_media_batch,"",@
	.globl	inflate_zip_media_batch         # -- Begin function inflate_zip_media_batch
	.type	inflate_zip_media_batch,@function
inflate_zip_media_batch:                # @inflate_zip_media_batch
	.functype	inflate_zip_media_batch (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32
# %bb.0:
	block   	
	local.get	7
	br_if   	0                               # 0: down to label68
# %bb.1:
	i32.const	-1
	return
.LBB4_2:
	end_block                               # label68:
	i32.const	0
	local.set	11
.LBB4_3:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label69:
	block   	
	local.get	1
	local.get	2
	i32.load	0
	local.tee	12
	i32.ge_u
	br_if   	0                               # 0: down to label70
# %bb.4:
	i32.const	-1
	return
.LBB4_5:                                #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label70:
	block   	
	local.get	3
	i32.load	0
	local.tee	13
	local.get	1
	local.get	12
	i32.sub 
	i32.le_u
	br_if   	0                               # 0: down to label71
# %bb.6:
	i32.const	-1
	return
.LBB4_7:                                #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label71:
	block   	
	local.get	9
	local.get	11
	i32.ge_u
	br_if   	0                               # 0: down to label72
# %bb.8:
	i32.const	-1
	return
.LBB4_9:                                #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label72:
	block   	
	local.get	4
	i32.load	0
	local.tee	14
	local.get	9
	local.get	11
	i32.sub 
	i32.le_u
	br_if   	0                               # 0: down to label73
# %bb.10:
	i32.const	-1
	return
.LBB4_11:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label73:
	local.get	10
	local.get	11
	i32.store	0
	local.get	8
	local.get	11
	i32.add 
	local.set	15
	i32.const	-1
	local.set	16
	block   	
	block   	
	block   	
	block   	
	local.get	5
	i32.load	0
	br_table 	{0, 3, 3, 3, 3, 3, 3, 3, 1, 3} # 3: down to label74
                                        # 1: down to label76
.LBB4_12:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label77:
	block   	
	local.get	13
	local.get	14
	i32.eq  
	br_if   	0                               # 0: down to label78
# %bb.13:
	i32.const	-3
	return
.LBB4_14:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label78:
	local.get	13
	i32.eqz
	br_if   	1                               # 1: down to label75
# %bb.15:                               #   in Loop: Header=BB4_3 Depth=1
	local.get	15
	local.get	0
	local.get	12
	i32.add 
	local.get	13
	memory.copy	0, 0
	br      	1                               # 1: down to label75
.LBB4_16:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label76:
	local.get	0
	local.get	12
	i32.add 
	local.get	13
	local.get	15
	local.get	14
	call	term_bank_inflate
	local.tee	16
	br_if   	1                               # 1: down to label74
.LBB4_17:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label75:
	block   	
	local.get	15
	local.get	14
	call	crc32_bytes
	local.get	6
	i32.load	0
	i32.eq  
	br_if   	0                               # 0: down to label79
# %bb.18:
	i32.const	-4
	return
.LBB4_19:                               #   in Loop: Header=BB4_3 Depth=1
	end_block                               # label79:
	local.get	2
	i32.const	4
	i32.add 
	local.set	2
	local.get	3
	i32.const	4
	i32.add 
	local.set	3
	local.get	4
	i32.const	4
	i32.add 
	local.set	4
	local.get	10
	i32.const	4
	i32.add 
	local.set	10
	local.get	5
	i32.const	4
	i32.add 
	local.set	5
	local.get	6
	i32.const	4
	i32.add 
	local.set	6
	local.get	14
	local.get	11
	i32.add 
	local.tee	11
	local.set	16
	local.get	7
	i32.const	-1
	i32.add 
	local.tee	7
	br_if   	1                               # 1: up to label69
.LBB4_20:
	end_block                               # label74:
	end_loop
	local.get	16
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.wasm_reset_heap,"",@
	.globl	wasm_reset_heap                 # -- Begin function wasm_reset_heap
	.type	wasm_reset_heap,@function
wasm_reset_heap:                        # @wasm_reset_heap
	.functype	wasm_reset_heap () -> ()
# %bb.0:
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.wasm_alloc,"",@
	.globl	wasm_alloc                      # -- Begin function wasm_alloc
	.type	wasm_alloc,@function
wasm_alloc:                             # @wasm_alloc
	.functype	wasm_alloc (i32) -> (i32)
	.local  	i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	1
	block   	
	i32.const	0
	i32.load	heap_ptr
	local.tee	2
	br_if   	0                               # 0: down to label80
# %bb.1:
	i32.const	__heap_base
	local.set	2
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB6_2:
	end_block                               # label80:
	block   	
	local.get	0
	i32.const	-8
	i32.gt_u
	br_if   	0                               # 0: down to label81
# %bb.3:
	local.get	2
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	2
	local.get	0
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	0
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	0                               # 0: down to label81
# %bb.4:
	i32.const	0
	local.set	1
	block   	
	local.get	2
	local.get	0
	i32.add 
	local.tee	0
	i32.const	16
	i32.shr_u
	local.get	0
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	3
	memory.size	0
	local.tee	4
	i32.le_u
	br_if   	0                               # 0: down to label82
# %bb.5:
	local.get	3
	local.get	4
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	1                               # 1: down to label81
.LBB6_6:
	end_block                               # label82:
	i32.const	0
	local.get	0
	i32.store	heap_ptr
	local.get	2
	local.set	1
.LBB6_7:
	end_block                               # label81:
	local.get	1
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.wasm_get_last_parse_capacity,"",@
	.globl	wasm_get_last_parse_capacity    # -- Begin function wasm_get_last_parse_capacity
	.type	wasm_get_last_parse_capacity,@function
wasm_get_last_parse_capacity:           # @wasm_get_last_parse_capacity
	.functype	wasm_get_last_parse_capacity () -> (i32)
# %bb.0:
	i32.const	0
	i32.load	last_parse_capacity
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.wasm_get_last_content_capacity,"",@
	.globl	wasm_get_last_content_capacity  # -- Begin function wasm_get_last_content_capacity
	.type	wasm_get_last_content_capacity,@function
wasm_get_last_content_capacity:         # @wasm_get_last_content_capacity
	.functype	wasm_get_last_content_capacity () -> (i32)
# %bb.0:
	i32.const	0
	i32.load	last_content_capacity
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_term_bank,"",@
	.globl	parse_term_bank                 # -- Begin function parse_term_bank
	.type	parse_term_bank,@function
parse_term_bank:                        # @parse_term_bank
	.functype	parse_term_bank (i32, i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	i32.const	0
	local.get	4
	local.get	5
	local.get	6
	i32.const	0
	i32.ne  
	call	parse_term_bank_impl
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_term_bank_impl,"",@
	.type	parse_term_bank_impl,@function  # -- Begin function parse_term_bank_impl
parse_term_bank_impl:                   # @parse_term_bank_impl
	.functype	parse_term_bank_impl (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	32
	i32.sub 
	local.tee	8
	global.set	__stack_pointer
	block   	
	block   	
	block   	
	local.get	5
	br_if   	0                               # 0: down to label85
# %bb.1:
	i32.const	-1
	local.set	9
	local.get	6
	br_if   	2                               # 2: down to label83
# %bb.2:
	local.get	0
	i32.eqz
	br_if   	2                               # 2: down to label83
# %bb.3:
	local.get	1
	i32.eqz
	br_if   	2                               # 2: down to label83
# %bb.4:
	local.get	2
	i32.eqz
	br_if   	2                               # 2: down to label83
# %bb.5:
	local.get	3
	i32.eqz
	br_if   	2                               # 2: down to label83
# %bb.6:
	i32.const	0
	local.set	10
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
.LBB10_7:                               # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label87:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	6
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label86
# %bb.8:                                #   in Loop: Header=BB10_7 Depth=1
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label86
# %bb.9:                                #   in Loop: Header=BB10_7 Depth=1
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label87
	br      	4                               # 4: down to label83
.LBB10_10:
	end_loop
	end_block                               # label86:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label83
# %bb.11:
	local.get	6
	i32.const	91
	i32.ne  
	br_if   	2                               # 2: down to label83
# %bb.12:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label88
# %bb.13:
.LBB10_14:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label89:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label88
# %bb.15:                               #   in Loop: Header=BB10_14 Depth=1
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label88
# %bb.16:                               #   in Loop: Header=BB10_14 Depth=1
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label89
# %bb.17:
	end_loop
	local.get	1
	local.set	10
	br      	2                               # 2: down to label84
.LBB10_18:
	end_block                               # label88:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label84
# %bb.19:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	1                               # 1: down to label84
# %bb.20:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label90
# %bb.21:
.LBB10_22:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label91:
	local.get	0
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label90
# %bb.23:                               #   in Loop: Header=BB10_22 Depth=1
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label90
# %bb.24:                               #   in Loop: Header=BB10_22 Depth=1
	local.get	1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	i32.ne  
	br_if   	0                               # 0: up to label91
# %bb.25:
	end_loop
	local.get	1
	local.set	3
.LBB10_26:
	end_block                               # label90:
	i32.const	-1
	i32.const	0
	local.get	3
	local.get	1
	i32.ne  
	i32.select
	local.set	9
	br      	2                               # 2: down to label83
.LBB10_27:
	end_block                               # label85:
	i32.const	-1
	local.set	9
	local.get	0
	i32.eqz
	br_if   	1                               # 1: down to label83
# %bb.28:
	local.get	1
	i32.eqz
	br_if   	1                               # 1: down to label83
# %bb.29:
	local.get	2
	i32.eqz
	br_if   	1                               # 1: down to label83
# %bb.30:
	local.get	3
	i32.eqz
	br_if   	1                               # 1: down to label83
# %bb.31:
	local.get	6
	i32.eqz
	br_if   	1                               # 1: down to label83
# %bb.32:
	i32.const	0
	local.set	10
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
	local.get	8
	i32.const	0
	i32.store	28
	local.get	8
	i64.const	0
	i64.store	20:p2align=2
	local.get	8
	local.get	6
	i32.store	16
	local.get	8
	local.get	1
	i32.store	12
	local.get	8
	local.get	5
	i32.store	8
	local.get	8
	local.get	0
	i32.store	4
	block   	
	local.get	8
	i32.const	4
	i32.add 
	call	next_term_bank
	local.tee	5
	i32.const	1
	i32.lt_s
	br_if   	0                               # 0: down to label92
# %bb.33:
	local.get	2
	local.set	1
	i32.const	0
	local.set	10
.LBB10_34:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label93:
	block   	
	local.get	10
	local.get	3
	i32.lt_u
	br_if   	0                               # 0: down to label94
# %bb.35:                               #   in Loop: Header=BB10_34 Depth=1
	i32.const	-2
	local.set	9
	local.get	3
	i32.const	63161282
	i32.gt_u
	br_if   	4                               # 4: down to label83
# %bb.36:                               #   in Loop: Header=BB10_34 Depth=1
	local.get	2
	local.get	3
	i32.const	68
	i32.mul 
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	6
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label83
# %bb.37:                               #   in Loop: Header=BB10_34 Depth=1
	i32.const	0
	i32.load	heap_ptr
	local.get	6
	local.get	2
	i32.add 
	local.tee	5
	i32.ne  
	br_if   	4                               # 4: down to label83
# %bb.38:                               #   in Loop: Header=BB10_34 Depth=1
	i32.const	63161283
	local.get	3
	i32.const	1
	i32.shr_u
	local.tee	11
	i32.const	8192
	local.get	11
	i32.const	8192
	i32.gt_u
	i32.select
	local.tee	11
	local.get	3
	i32.add 
	local.get	3
	i32.const	63161283
	local.get	11
	i32.sub 
	i32.gt_u
	i32.select
	local.tee	3
	i32.const	68
	i32.mul 
	local.get	6
	i32.sub 
	i32.const	7
	i32.add 
	local.set	11
	local.get	5
	local.set	6
	block   	
	local.get	5
	br_if   	0                               # 0: down to label95
# %bb.39:                               #   in Loop: Header=BB10_34 Depth=1
	i32.const	__heap_base
	local.set	6
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB10_40:                              #   in Loop: Header=BB10_34 Depth=1
	end_block                               # label95:
	local.get	6
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	6
	local.get	11
	i32.const	-8
	i32.and 
	local.tee	11
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label83
# %bb.41:                               #   in Loop: Header=BB10_34 Depth=1
	block   	
	local.get	6
	local.get	11
	i32.add 
	local.tee	11
	i32.const	16
	i32.shr_u
	local.get	11
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	12
	memory.size	0
	local.tee	13
	i32.le_u
	br_if   	0                               # 0: down to label96
# %bb.42:                               #   in Loop: Header=BB10_34 Depth=1
	local.get	12
	local.get	13
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	5                               # 5: down to label83
.LBB10_43:                              #   in Loop: Header=BB10_34 Depth=1
	end_block                               # label96:
	i32.const	0
	local.get	11
	i32.store	heap_ptr
	local.get	6
	i32.eqz
	br_if   	4                               # 4: down to label83
# %bb.44:                               #   in Loop: Header=BB10_34 Depth=1
	local.get	6
	local.get	5
	i32.ne  
	br_if   	4                               # 4: down to label83
# %bb.45:                               #   in Loop: Header=BB10_34 Depth=1
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
.LBB10_46:                              #   in Loop: Header=BB10_34 Depth=1
	end_block                               # label94:
	local.get	8
	i32.const	0
	i32.store	0
	block   	
	local.get	0
	local.get	8
	i32.load	24
	local.get	8
	i32.load	28
	local.get	1
	local.get	4
	local.get	8
	i32.const	0
	i32.const	0
	i32.const	0
	i32.const	0
	local.get	7
	i32.const	0
	call	parse_row_single_pass
	br_if   	0                               # 0: down to label97
# %bb.47:
	i32.const	-1
	local.set	9
	br      	4                               # 4: down to label83
.LBB10_48:                              #   in Loop: Header=BB10_34 Depth=1
	end_block                               # label97:
	local.get	1
	i32.const	68
	i32.add 
	local.set	1
	local.get	10
	i32.const	1
	i32.add 
	local.set	10
	local.get	8
	i32.const	4
	i32.add 
	local.get	8
	i32.load	0
	call	next_term_row
	local.tee	5
	i32.const	0
	i32.gt_s
	br_if   	0                               # 0: up to label93
.LBB10_49:
	end_loop
	end_block                               # label92:
	i32.const	-1
	local.get	10
	local.get	5
	i32.select
	local.set	9
	br      	1                               # 1: down to label83
.LBB10_50:
	end_block                               # label84:
	i32.const	0
	local.set	6
.LBB10_51:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB10_67 Depth 2
                                        #     Child Loop BB10_81 Depth 2
	loop    	                                # label98:
	block   	
	local.get	10
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label99
# %bb.52:
	i32.const	-1
	local.set	9
	br      	2                               # 2: down to label83
.LBB10_53:                              #   in Loop: Header=BB10_51 Depth=1
	end_block                               # label99:
	block   	
	local.get	6
	local.get	3
	i32.lt_u
	br_if   	0                               # 0: down to label100
# %bb.54:                               #   in Loop: Header=BB10_51 Depth=1
	i32.const	-2
	local.set	9
	local.get	3
	i32.const	63161282
	i32.gt_u
	br_if   	2                               # 2: down to label83
# %bb.55:                               #   in Loop: Header=BB10_51 Depth=1
	local.get	2
	local.get	3
	i32.const	68
	i32.mul 
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	11
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	2                               # 2: down to label83
# %bb.56:                               #   in Loop: Header=BB10_51 Depth=1
	i32.const	0
	i32.load	heap_ptr
	local.get	11
	local.get	2
	i32.add 
	local.tee	5
	i32.ne  
	br_if   	2                               # 2: down to label83
# %bb.57:                               #   in Loop: Header=BB10_51 Depth=1
	i32.const	63161283
	local.get	3
	i32.const	1
	i32.shr_u
	local.tee	12
	i32.const	8192
	local.get	12
	i32.const	8192
	i32.gt_u
	i32.select
	local.tee	12
	local.get	3
	i32.add 
	local.get	3
	i32.const	63161283
	local.get	12
	i32.sub 
	i32.gt_u
	i32.select
	local.tee	3
	i32.const	68
	i32.mul 
	local.get	11
	i32.sub 
	i32.const	7
	i32.add 
	local.set	12
	local.get	5
	local.set	11
	block   	
	local.get	5
	br_if   	0                               # 0: down to label101
# %bb.58:                               #   in Loop: Header=BB10_51 Depth=1
	i32.const	__heap_base
	local.set	11
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB10_59:                              #   in Loop: Header=BB10_51 Depth=1
	end_block                               # label101:
	local.get	11
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	11
	local.get	12
	i32.const	-8
	i32.and 
	local.tee	12
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	2                               # 2: down to label83
# %bb.60:                               #   in Loop: Header=BB10_51 Depth=1
	block   	
	local.get	11
	local.get	12
	i32.add 
	local.tee	12
	i32.const	16
	i32.shr_u
	local.get	12
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	13
	memory.size	0
	local.tee	14
	i32.le_u
	br_if   	0                               # 0: down to label102
# %bb.61:                               #   in Loop: Header=BB10_51 Depth=1
	local.get	13
	local.get	14
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	3                               # 3: down to label83
.LBB10_62:                              #   in Loop: Header=BB10_51 Depth=1
	end_block                               # label102:
	i32.const	0
	local.get	12
	i32.store	heap_ptr
	local.get	11
	i32.eqz
	br_if   	2                               # 2: down to label83
# %bb.63:                               #   in Loop: Header=BB10_51 Depth=1
	local.get	11
	local.get	5
	i32.ne  
	br_if   	2                               # 2: down to label83
# %bb.64:                               #   in Loop: Header=BB10_51 Depth=1
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
.LBB10_65:                              #   in Loop: Header=BB10_51 Depth=1
	end_block                               # label100:
	local.get	8
	i32.const	0
	i32.store	4
	i32.const	-1
	local.set	9
	local.get	0
	local.get	1
	local.get	10
	local.get	2
	local.get	6
	i32.const	68
	i32.mul 
	i32.add 
	local.get	4
	local.get	8
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	i32.const	0
	i32.const	0
	local.get	7
	i32.const	0
	call	parse_row_single_pass
	i32.eqz
	br_if   	1                               # 1: down to label83
# %bb.66:                               #   in Loop: Header=BB10_51 Depth=1
	block   	
	local.get	8
	i32.load	4
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label103
.LBB10_67:                              #   Parent Loop BB10_51 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label104:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label103
# %bb.68:                               #   in Loop: Header=BB10_67 Depth=2
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label103
# %bb.69:                               #   in Loop: Header=BB10_67 Depth=2
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label104
	br      	3                               # 3: down to label83
.LBB10_70:                              #   in Loop: Header=BB10_51 Depth=1
	end_loop
	end_block                               # label103:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label83
# %bb.71:                               #   in Loop: Header=BB10_51 Depth=1
	local.get	6
	i32.const	1
	i32.add 
	local.set	6
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	5
	i32.const	44
	i32.eq  
	br_if   	0                               # 0: down to label105
# %bb.72:
	local.get	5
	i32.const	93
	i32.ne  
	br_if   	2                               # 2: down to label83
# %bb.73:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	3
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label106
# %bb.74:
.LBB10_75:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label107:
	local.get	0
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label106
# %bb.76:                               #   in Loop: Header=BB10_75 Depth=1
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label106
# %bb.77:                               #   in Loop: Header=BB10_75 Depth=1
	local.get	1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	i32.ne  
	br_if   	0                               # 0: up to label107
# %bb.78:
	end_loop
	local.get	1
	local.set	3
.LBB10_79:
	end_block                               # label106:
	local.get	6
	i32.const	-1
	local.get	3
	local.get	1
	i32.eq  
	i32.select
	local.set	9
	br      	2                               # 2: down to label83
.LBB10_80:                              #   in Loop: Header=BB10_51 Depth=1
	end_block                               # label105:
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label108
.LBB10_81:                              #   Parent Loop BB10_51 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label109:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	5
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label108
# %bb.82:                               #   in Loop: Header=BB10_81 Depth=2
	i32.const	1
	local.get	5
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label108
# %bb.83:                               #   in Loop: Header=BB10_81 Depth=2
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label109
	br      	3                               # 3: down to label83
.LBB10_84:                              #   in Loop: Header=BB10_51 Depth=1
	end_loop
	end_block                               # label108:
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label83
# %bb.85:                               #   in Loop: Header=BB10_51 Depth=1
	i32.const	-1
	local.set	9
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: up to label98
.LBB10_86:
	end_loop
	end_block                               # label83:
	local.get	8
	i32.const	32
	i32.add 
	global.set	__stack_pointer
	local.get	9
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_term_bank_with_media_hints,"",@
	.globl	parse_term_bank_with_media_hints # -- Begin function parse_term_bank_with_media_hints
	.type	parse_term_bank_with_media_hints,@function
parse_term_bank_with_media_hints:       # @parse_term_bank_with_media_hints
	.functype	parse_term_bank_with_media_hints (i32, i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	i32.const	1
	local.get	4
	local.get	5
	local.get	6
	i32.const	0
	i32.ne  
	call	parse_term_bank_impl
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content,"",@
	.globl	encode_term_content             # -- Begin function encode_term_content
	.type	encode_term_content,@function
encode_term_content:                    # @encode_term_content
	.functype	encode_term_content (i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	local.get	4
	local.get	5
	i32.const	1
	call	encode_term_content_impl
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_impl,"",@
	.type	encode_term_content_impl,@function # -- Begin function encode_term_content_impl
encode_term_content_impl:               # @encode_term_content_impl
	.functype	encode_term_content_impl (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	7
	global.set	__stack_pointer
	i32.const	-1
	local.set	8
	block   	
	local.get	0
	i32.eqz
	br_if   	0                               # 0: down to label110
# %bb.1:
	local.get	1
	i32.eqz
	br_if   	0                               # 0: down to label110
# %bb.2:
	local.get	3
	i32.eqz
	br_if   	0                               # 0: down to label110
# %bb.3:
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label110
# %bb.4:
	i32.const	0
	local.set	8
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label110
# %bb.5:
	i32.const	0
	local.set	8
	i32.const	0
	local.set	9
.LBB13_6:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB13_7 Depth 2
	loop    	                                # label111:
	local.get	8
	local.tee	10
	i32.const	11
	i32.add 
	local.set	11
	local.get	3
	local.get	10
	i32.const	9
	i32.add 
	local.tee	12
	i32.add 
	local.set	13
	local.get	1
	local.get	9
	i32.const	68
	i32.mul 
	i32.add 
	local.set	14
	local.get	10
	i32.const	-10
	i32.gt_u
	local.set	15
	local.get	3
	local.get	10
	i32.add 
	local.tee	16
	i32.const	8
	i32.add 
	local.set	17
	local.get	12
	i32.const	-3
	i32.gt_u
	local.set	18
.LBB13_7:                               #   Parent Loop BB13_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	loop    	                                # label114:
	local.get	7
	i32.const	0
	i32.store	12
	local.get	7
	i32.const	0
	i32.store	8
	block   	
	local.get	15
	br_if   	0                               # 0: down to label115
# %bb.8:                                #   in Loop: Header=BB13_7 Depth=2
	local.get	12
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label115
# %bb.9:                                #   in Loop: Header=BB13_7 Depth=2
	local.get	17
	i32.const	0
	i32.load8_u	encode_term_content_row.PREFIX_RULES+8
	i32.store8	0
	local.get	16
	i32.const	0
	i64.load	encode_term_content_row.PREFIX_RULES:p2align=0
	i64.store	0:p2align=0
	block   	
	block   	
	local.get	14
	i32.load	28
	local.tee	19
	i32.eqz
	br_if   	0                               # 0: down to label117
# %bb.10:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	14
	i32.load	24
	local.set	20
	block   	
	local.get	19
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label118
# %bb.11:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	0
	local.get	20
	i32.add 
	local.tee	21
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label118
# %bb.12:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label118
# %bb.13:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label118
# %bb.14:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label117
.LBB13_15:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label118:
	local.get	19
	local.get	12
	i32.add 
	local.tee	21
	local.get	19
	i32.lt_u
	br_if   	2                               # 2: down to label115
# %bb.16:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	local.get	4
	i32.gt_u
	br_if   	2                               # 2: down to label115
# %bb.17:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label116
# %bb.18:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	13
	local.get	0
	local.get	20
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label116
.LBB13_19:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label117:
	local.get	18
	br_if   	1                               # 1: down to label115
# %bb.20:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	11
	local.get	4
	i32.gt_u
	br_if   	1                               # 1: down to label115
# %bb.21:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	13
	i32.const	8738
	i32.store16	0:p2align=0
	local.get	11
	local.set	21
.LBB13_22:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label116:
	local.get	21
	i32.const	-19
	i32.gt_u
	br_if   	0                               # 0: down to label115
# %bb.23:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	i32.const	18
	i32.add 
	local.tee	20
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label115
# %bb.24:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	3
	local.get	21
	i32.add 
	local.tee	19
	i32.const	0
	v128.load	encode_term_content_row.PREFIX_DEFINITION_TAGS
	v128.store	0:p2align=0
	local.get	19
	i32.const	16
	i32.add 
	i32.const	0
	i32.load16_u	encode_term_content_row.PREFIX_DEFINITION_TAGS+16
	i32.store16	0:p2align=0
	block   	
	block   	
	local.get	14
	i32.load	20
	local.tee	19
	i32.eqz
	br_if   	0                               # 0: down to label120
# %bb.25:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	14
	i32.load	16
	local.set	8
	block   	
	local.get	19
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label121
# %bb.26:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	0
	local.get	8
	i32.add 
	local.tee	22
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label121
# %bb.27:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	22
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label121
# %bb.28:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	22
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label121
# %bb.29:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	22
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label120
.LBB13_30:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label121:
	local.get	19
	local.get	20
	i32.add 
	local.tee	21
	local.get	19
	i32.lt_u
	br_if   	2                               # 2: down to label115
# %bb.31:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	local.get	4
	i32.gt_u
	br_if   	2                               # 2: down to label115
# %bb.32:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label119
# %bb.33:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	3
	local.get	20
	i32.add 
	local.get	0
	local.get	8
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label119
.LBB13_34:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label120:
	local.get	20
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label115
# %bb.35:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	i32.const	20
	i32.add 
	local.tee	21
	local.get	4
	i32.gt_u
	br_if   	1                               # 1: down to label115
# %bb.36:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	3
	local.get	20
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB13_37:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label119:
	local.get	21
	i32.const	-13
	i32.gt_u
	br_if   	0                               # 0: down to label115
# %bb.38:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	i32.const	12
	i32.add 
	local.tee	20
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label115
# %bb.39:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	3
	local.get	21
	i32.add 
	local.tee	19
	i32.const	0
	i64.load	encode_term_content_row.PREFIX_TERM_TAGS:p2align=0
	i64.store	0:p2align=0
	local.get	19
	i32.const	8
	i32.add 
	i32.const	0
	i32.load	encode_term_content_row.PREFIX_TERM_TAGS+8:p2align=0
	i32.store	0:p2align=0
	block   	
	block   	
	local.get	14
	i32.load	52
	local.tee	19
	i32.eqz
	br_if   	0                               # 0: down to label123
# %bb.40:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	14
	i32.load	48
	local.set	8
	block   	
	local.get	19
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label124
# %bb.41:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	0
	local.get	8
	i32.add 
	local.tee	22
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label124
# %bb.42:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	22
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label124
# %bb.43:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	22
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label124
# %bb.44:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	22
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label123
.LBB13_45:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label124:
	local.get	19
	local.get	20
	i32.add 
	local.tee	21
	local.get	19
	i32.lt_u
	br_if   	2                               # 2: down to label115
# %bb.46:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	local.get	4
	i32.gt_u
	br_if   	2                               # 2: down to label115
# %bb.47:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label122
# %bb.48:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	3
	local.get	20
	i32.add 
	local.get	0
	local.get	8
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label122
.LBB13_49:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label123:
	local.get	20
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label115
# %bb.50:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	i32.const	14
	i32.add 
	local.tee	21
	local.get	4
	i32.gt_u
	br_if   	1                               # 1: down to label115
# %bb.51:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	3
	local.get	20
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB13_52:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label122:
	local.get	21
	i32.const	-13
	i32.gt_u
	br_if   	0                               # 0: down to label115
# %bb.53:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	i32.const	12
	i32.add 
	local.tee	19
	local.get	4
	i32.gt_u
	br_if   	0                               # 0: down to label115
# %bb.54:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	3
	local.get	21
	i32.add 
	local.tee	20
	i32.const	0
	i64.load	encode_term_content_row.PREFIX_GLOSSARY:p2align=0
	i64.store	0:p2align=0
	local.get	20
	i32.const	8
	i32.add 
	i32.const	0
	i32.load	encode_term_content_row.PREFIX_GLOSSARY+8:p2align=0
	i32.store	0:p2align=0
	local.get	7
	local.get	19
	i32.store	4
	block   	
	block   	
	local.get	14
	i32.load	40
	local.tee	20
	i32.eqz
	br_if   	0                               # 0: down to label126
# %bb.55:                               #   in Loop: Header=BB13_7 Depth=2
	block   	
	local.get	14
	i32.load	60
	br_if   	0                               # 0: down to label127
# %bb.56:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	20
	local.get	19
	i32.add 
	local.tee	21
	local.get	20
	i32.lt_u
	br_if   	3                               # 3: down to label115
# %bb.57:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	local.get	4
	i32.gt_u
	br_if   	3                               # 3: down to label115
# %bb.58:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	20
	i32.eqz
	br_if   	2                               # 2: down to label125
# %bb.59:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	3
	local.get	19
	i32.add 
	local.get	0
	local.get	14
	i32.load	36
	i32.add 
	local.get	20
	memory.copy	0, 0
	br      	2                               # 2: down to label125
.LBB13_60:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label127:
	local.get	0
	local.get	14
	i32.load	36
	local.tee	19
	local.get	20
	i32.add 
	local.tee	21
	local.get	19
	local.get	21
	local.get	3
	local.get	4
	local.get	7
	i32.const	4
	i32.add 
	call	write_normalized_glossary_value
	i32.eqz
	br_if   	2                               # 2: down to label115
# %bb.61:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	7
	i32.load	4
	local.set	21
	br      	1                               # 1: down to label125
.LBB13_62:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label126:
	local.get	19
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label115
# %bb.63:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	i32.const	14
	i32.add 
	local.tee	21
	local.get	4
	i32.gt_u
	br_if   	1                               # 1: down to label115
# %bb.64:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	3
	local.get	19
	i32.add 
	i32.const	23899
	i32.store16	0:p2align=0
.LBB13_65:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label125:
	local.get	21
	local.get	4
	i32.ge_u
	br_if   	0                               # 0: down to label115
# %bb.66:                               #   in Loop: Header=BB13_6 Depth=1
	local.get	3
	local.get	21
	i32.add 
	i32.const	125
	i32.store8	0
	local.get	7
	local.get	21
	i32.const	1
	i32.add 
	local.tee	8
	i32.store	4
	local.get	8
	local.get	10
	i32.sub 
	local.set	21
	local.get	6
	br_if   	2                               # 2: down to label113
# %bb.67:                               #   in Loop: Header=BB13_6 Depth=1
	i32.const	0
	local.set	20
	i32.const	0
	local.set	12
	br      	3                               # 3: down to label112
.LBB13_68:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label115:
	local.get	7
	local.get	10
	i32.store	4
	i32.const	-2
	local.set	8
	local.get	4
	i32.const	2147483646
	i32.gt_u
	br_if   	4                               # 4: down to label110
# %bb.69:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	3
	local.get	4
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	21
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label110
# %bb.70:                               #   in Loop: Header=BB13_7 Depth=2
	i32.const	0
	i32.load	heap_ptr
	local.get	21
	local.get	3
	i32.add 
	local.tee	19
	i32.ne  
	br_if   	4                               # 4: down to label110
# %bb.71:                               #   in Loop: Header=BB13_7 Depth=2
	i32.const	2147483647
	local.get	4
	i32.const	1
	i32.shr_u
	local.tee	20
	i32.const	1048576
	local.get	20
	i32.const	1048576
	i32.gt_u
	i32.select
	local.tee	20
	local.get	4
	i32.add 
	local.get	4
	local.get	20
	i32.const	2147483647
	i32.xor 
	i32.gt_u
	i32.select
	local.tee	4
	local.get	21
	i32.sub 
	i32.const	7
	i32.add 
	local.set	20
	local.get	19
	local.set	21
	block   	
	local.get	19
	br_if   	0                               # 0: down to label128
# %bb.72:                               #   in Loop: Header=BB13_7 Depth=2
	i32.const	__heap_base
	local.set	21
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB13_73:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label128:
	local.get	21
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	21
	local.get	20
	i32.const	-8
	i32.and 
	local.tee	20
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label110
# %bb.74:                               #   in Loop: Header=BB13_7 Depth=2
	block   	
	local.get	21
	local.get	20
	i32.add 
	local.tee	20
	i32.const	16
	i32.shr_u
	local.get	20
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	22
	memory.size	0
	local.tee	23
	i32.le_u
	br_if   	0                               # 0: down to label129
# %bb.75:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	22
	local.get	23
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	5                               # 5: down to label110
.LBB13_76:                              #   in Loop: Header=BB13_7 Depth=2
	end_block                               # label129:
	i32.const	0
	local.get	20
	i32.store	heap_ptr
	local.get	21
	i32.eqz
	br_if   	4                               # 4: down to label110
# %bb.77:                               #   in Loop: Header=BB13_7 Depth=2
	local.get	21
	local.get	19
	i32.ne  
	br_if   	4                               # 4: down to label110
# %bb.78:                               #   in Loop: Header=BB13_7 Depth=2
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	br      	0                               # 0: up to label114
.LBB13_79:                              #   in Loop: Header=BB13_6 Depth=1
	end_loop
	end_block                               # label113:
	local.get	16
	local.get	21
	local.get	7
	i32.const	12
	i32.add 
	local.get	7
	i32.const	8
	i32.add 
	call	hash_content_xxh32_pair
	local.get	7
	i32.load	12
	local.tee	19
	i32.const	1
	local.get	19
	local.get	7
	i32.load	8
	local.tee	12
	i32.or  
	i32.select
	local.set	20
.LBB13_80:                              #   in Loop: Header=BB13_6 Depth=1
	end_block                               # label112:
	local.get	5
	local.get	9
	i32.const	4
	i32.shl 
	i32.add 
	local.tee	19
	local.get	12
	i32.store	12
	local.get	19
	local.get	20
	i32.store	8
	local.get	19
	local.get	21
	i32.store	4
	local.get	19
	local.get	10
	i32.store	0
	local.get	9
	i32.const	1
	i32.add 
	local.tee	9
	local.get	2
	i32.ne  
	br_if   	0                               # 0: up to label111
.LBB13_81:
	end_loop
	end_block                               # label110:
	local.get	7
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	8
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_no_hash,"",@
	.globl	encode_term_content_no_hash     # -- Begin function encode_term_content_no_hash
	.type	encode_term_content_no_hash,@function
encode_term_content_no_hash:            # @encode_term_content_no_hash
	.functype	encode_term_content_no_hash (i32, i32, i32, i32, i32, i32) -> (i32)
# %bb.0:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	local.get	4
	local.get	5
	i32.const	0
	call	encode_term_content_impl
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_token_binary,"",@
	.globl	encode_term_content_token_binary # -- Begin function encode_term_content_token_binary
	.type	encode_term_content_token_binary,@function
encode_term_content_token_binary:       # @encode_term_content_token_binary
	.functype	encode_term_content_token_binary (i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	6
	global.set	__stack_pointer
	i32.const	-1
	local.set	7
	block   	
	local.get	0
	i32.eqz
	br_if   	0                               # 0: down to label130
# %bb.1:
	local.get	1
	i32.eqz
	br_if   	0                               # 0: down to label130
# %bb.2:
	local.get	3
	i32.eqz
	br_if   	0                               # 0: down to label130
# %bb.3:
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label130
# %bb.4:
	i32.const	0
	local.set	7
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	6
	i32.const	0
	i32.store	12
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label130
# %bb.5:
	i32.const	0
	local.set	8
	i32.const	0
	local.set	9
.LBB15_6:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB15_7 Depth 2
	loop    	                                # label131:
	local.get	6
	i32.const	0
	i32.store	8
	local.get	6
	i32.const	0
	i32.store	4
	block   	
	local.get	0
	local.get	1
	local.get	9
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	10
	local.get	3
	local.get	4
	local.get	6
	i32.const	12
	i32.add 
	local.get	6
	i32.const	8
	i32.add 
	local.get	6
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	call	encode_term_content_token_binary_row
	br_if   	0                               # 0: down to label132
.LBB15_7:                               #   Parent Loop BB15_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label133:
	local.get	6
	local.get	8
	i32.store	12
	block   	
	block   	
	local.get	4
	i32.const	2147483646
	i32.gt_u
	br_if   	0                               # 0: down to label135
# %bb.8:                                #   in Loop: Header=BB15_7 Depth=2
	local.get	3
	local.get	4
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	11
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	0                               # 0: down to label135
# %bb.9:                                #   in Loop: Header=BB15_7 Depth=2
	i32.const	0
	i32.load	heap_ptr
	local.get	11
	local.get	3
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: down to label135
# %bb.10:                               #   in Loop: Header=BB15_7 Depth=2
	i32.const	2147483647
	local.get	4
	i32.const	1
	i32.shr_u
	local.tee	12
	i32.const	1048576
	local.get	12
	i32.const	1048576
	i32.gt_u
	i32.select
	local.tee	12
	local.get	4
	i32.add 
	local.get	4
	local.get	12
	i32.const	2147483647
	i32.xor 
	i32.gt_u
	i32.select
	local.tee	4
	local.get	11
	i32.sub 
	i32.const	7
	i32.add 
	local.set	12
	local.get	7
	local.set	11
	block   	
	local.get	7
	br_if   	0                               # 0: down to label136
# %bb.11:                               #   in Loop: Header=BB15_7 Depth=2
	i32.const	__heap_base
	local.set	11
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB15_12:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label136:
	local.get	11
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	11
	local.get	12
	i32.const	-8
	i32.and 
	local.tee	12
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	0                               # 0: down to label135
# %bb.13:                               #   in Loop: Header=BB15_7 Depth=2
	block   	
	local.get	11
	local.get	12
	i32.add 
	local.tee	12
	i32.const	16
	i32.shr_u
	local.get	12
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	13
	memory.size	0
	local.tee	14
	i32.le_u
	br_if   	0                               # 0: down to label137
# %bb.14:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	13
	local.get	14
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	1                               # 1: down to label135
.LBB15_15:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label137:
	i32.const	0
	local.get	12
	i32.store	heap_ptr
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label135
# %bb.16:                               #   in Loop: Header=BB15_7 Depth=2
	local.get	11
	local.get	7
	i32.eq  
	br_if   	1                               # 1: down to label134
.LBB15_17:
	end_block                               # label135:
	i32.const	-2
	local.set	7
	br      	4                               # 4: down to label130
.LBB15_18:                              #   in Loop: Header=BB15_7 Depth=2
	end_block                               # label134:
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	0
	local.get	10
	local.get	3
	local.get	4
	local.get	6
	i32.const	12
	i32.add 
	local.get	6
	i32.const	8
	i32.add 
	local.get	6
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	call	encode_term_content_token_binary_row
	i32.eqz
	br_if   	0                               # 0: up to label133
.LBB15_19:                              #   in Loop: Header=BB15_6 Depth=1
	end_loop
	end_block                               # label132:
	local.get	5
	local.get	9
	i32.const	4
	i32.shl 
	i32.add 
	local.tee	11
	local.get	8
	i32.store	0
	local.get	11
	local.get	6
	i32.load	12
	local.tee	7
	local.get	8
	i32.sub 
	i32.store	4
	local.get	11
	local.get	6
	i32.load	8
	i32.store	8
	local.get	11
	local.get	6
	i32.load	4
	i32.store	12
	local.get	7
	local.set	8
	local.get	9
	i32.const	1
	i32.add 
	local.tee	9
	local.get	2
	i32.ne  
	br_if   	0                               # 0: up to label131
.LBB15_20:
	end_loop
	end_block                               # label130:
	local.get	6
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	7
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_token_binary_row,"",@
	.type	encode_term_content_token_binary_row,@function # -- Begin function encode_term_content_token_binary_row
encode_term_content_token_binary_row:   # @encode_term_content_token_binary_row
	.functype	encode_term_content_token_binary_row (i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	9
	global.set	__stack_pointer
	i32.const	0
	local.set	10
	block   	
	local.get	4
	i32.load	0
	local.tee	11
	i32.const	-5
	i32.gt_u
	br_if   	0                               # 0: down to label138
# %bb.1:
	local.get	11
	i32.const	4
	i32.add 
	local.tee	12
	local.get	3
	i32.gt_u
	br_if   	0                               # 0: down to label138
# %bb.2:
	local.get	2
	local.get	11
	i32.add 
	local.tee	13
	i32.const	911360589
	i32.store	0:p2align=0
	local.get	4
	local.get	12
	i32.store	0
	local.get	1
	i32.load	52
	local.set	14
	local.get	1
	i32.load	20
	local.set	15
	local.get	1
	i32.load	48
	local.set	16
	local.get	1
	i32.load	16
	local.set	17
	local.get	1
	i32.load	24
	local.set	18
	block   	
	block   	
	block   	
	block   	
	local.get	1
	i32.load	28
	local.tee	19
	br_table 	{2, 1, 1, 1, 0, 1}      # 1: down to label141
                                        # 0: down to label142
.LBB16_3:
	end_block                               # label142:
	local.get	0
	local.get	18
	i32.add 
	local.tee	20
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label141
# %bb.4:
	local.get	20
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label141
# %bb.5:
	local.get	20
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label141
# %bb.6:
	local.get	20
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label140
.LBB16_7:
	end_block                               # label141:
	local.get	12
	local.get	19
	i32.add 
	local.tee	20
	local.get	12
	i32.lt_u
	br_if   	2                               # 2: down to label138
# %bb.8:
	local.get	20
	local.get	3
	i32.gt_u
	br_if   	2                               # 2: down to label138
# %bb.9:
	local.get	19
	i32.eqz
	br_if   	1                               # 1: down to label139
# %bb.10:
	local.get	2
	local.get	12
	i32.add 
	local.get	0
	local.get	18
	i32.add 
	local.get	19
	memory.copy	0, 0
	br      	1                               # 1: down to label139
.LBB16_11:
	end_block                               # label140:
	local.get	12
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label138
# %bb.12:
	local.get	11
	i32.const	6
	i32.add 
	local.tee	20
	local.get	3
	i32.gt_u
	br_if   	1                               # 1: down to label138
# %bb.13:
	local.get	2
	local.get	12
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB16_14:
	end_block                               # label139:
	local.get	4
	local.get	20
	i32.store	0
	local.get	20
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label138
# %bb.15:
	i32.const	0
	local.set	10
	local.get	2
	local.get	20
	i32.add 
	i32.const	0
	i32.store8	0
	local.get	4
	local.get	4
	i32.load	0
	local.tee	20
	i32.const	1
	i32.add 
	local.tee	12
	i32.store	0
	block   	
	block   	
	block   	
	block   	
	local.get	15
	br_table 	{2, 1, 1, 1, 0, 1}      # 1: down to label145
                                        # 0: down to label146
.LBB16_16:
	end_block                               # label146:
	local.get	0
	local.get	17
	i32.add 
	local.tee	19
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label145
# %bb.17:
	local.get	19
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label145
# %bb.18:
	local.get	19
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label145
# %bb.19:
	local.get	19
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label144
.LBB16_20:
	end_block                               # label145:
	local.get	12
	local.get	15
	i32.add 
	local.tee	20
	local.get	12
	i32.lt_u
	br_if   	2                               # 2: down to label138
# %bb.21:
	local.get	20
	local.get	3
	i32.gt_u
	br_if   	2                               # 2: down to label138
# %bb.22:
	local.get	15
	i32.eqz
	br_if   	1                               # 1: down to label143
# %bb.23:
	local.get	2
	local.get	12
	i32.add 
	local.get	0
	local.get	17
	i32.add 
	local.get	15
	memory.copy	0, 0
	br      	1                               # 1: down to label143
.LBB16_24:
	end_block                               # label144:
	local.get	12
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label138
# %bb.25:
	local.get	20
	i32.const	3
	i32.add 
	local.tee	20
	local.get	3
	i32.gt_u
	br_if   	1                               # 1: down to label138
# %bb.26:
	local.get	2
	local.get	12
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB16_27:
	end_block                               # label143:
	local.get	4
	local.get	20
	i32.store	0
	local.get	20
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label138
# %bb.28:
	i32.const	0
	local.set	10
	local.get	2
	local.get	20
	i32.add 
	i32.const	0
	i32.store8	0
	local.get	4
	local.get	4
	i32.load	0
	local.tee	20
	i32.const	1
	i32.add 
	local.tee	12
	i32.store	0
	block   	
	block   	
	block   	
	block   	
	local.get	14
	br_table 	{2, 1, 1, 1, 0, 1}      # 1: down to label149
                                        # 0: down to label150
.LBB16_29:
	end_block                               # label150:
	local.get	0
	local.get	16
	i32.add 
	local.tee	19
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label149
# %bb.30:
	local.get	19
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label149
# %bb.31:
	local.get	19
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label149
# %bb.32:
	local.get	19
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label148
.LBB16_33:
	end_block                               # label149:
	local.get	12
	local.get	14
	i32.add 
	local.tee	20
	local.get	12
	i32.lt_u
	br_if   	2                               # 2: down to label138
# %bb.34:
	local.get	20
	local.get	3
	i32.gt_u
	br_if   	2                               # 2: down to label138
# %bb.35:
	local.get	14
	i32.eqz
	br_if   	1                               # 1: down to label147
# %bb.36:
	local.get	2
	local.get	12
	i32.add 
	local.get	0
	local.get	16
	i32.add 
	local.get	14
	memory.copy	0, 0
	br      	1                               # 1: down to label147
.LBB16_37:
	end_block                               # label148:
	local.get	12
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label138
# %bb.38:
	local.get	20
	i32.const	3
	i32.add 
	local.tee	20
	local.get	3
	i32.gt_u
	br_if   	1                               # 1: down to label138
# %bb.39:
	local.get	2
	local.get	12
	i32.add 
	i32.const	8738
	i32.store16	0:p2align=0
.LBB16_40:
	end_block                               # label147:
	local.get	4
	local.get	20
	i32.store	0
	local.get	20
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label138
# %bb.41:
	i32.const	0
	local.set	10
	local.get	2
	local.get	20
	i32.add 
	i32.const	0
	i32.store8	0
	local.get	4
	local.get	4
	i32.load	0
	local.tee	19
	i32.const	1
	i32.add 
	local.tee	12
	i32.store	0
	block   	
	block   	
	local.get	1
	i32.load	40
	local.tee	20
	i32.eqz
	br_if   	0                               # 0: down to label152
# %bb.42:
	block   	
	local.get	1
	i32.load	64
	br_if   	0                               # 0: down to label153
# %bb.43:
	i32.const	0
	local.set	10
	local.get	12
	local.get	20
	i32.add 
	local.tee	8
	local.get	12
	i32.lt_u
	br_if   	3                               # 3: down to label138
# %bb.44:
	local.get	8
	local.get	3
	i32.gt_u
	br_if   	3                               # 3: down to label138
# %bb.45:
	block   	
	local.get	20
	i32.eqz
	br_if   	0                               # 0: down to label154
# %bb.46:
	local.get	2
	local.get	12
	i32.add 
	local.get	0
	local.get	1
	i32.load	36
	i32.add 
	local.get	20
	memory.copy	0, 0
.LBB16_47:
	end_block                               # label154:
	local.get	4
	local.get	8
	i32.store	0
	br      	2                               # 2: down to label151
.LBB16_48:
	end_block                               # label153:
	block   	
	local.get	7
	i32.const	16
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label155
# %bb.49:
	i32.const	1
	local.set	19
	block   	
	local.get	1
	i32.load	36
	local.tee	10
	local.get	10
	local.get	20
	i32.add 
	local.tee	20
	i32.ge_u
	br_if   	0                               # 0: down to label156
# %bb.50:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label156
# %bb.51:
	i32.const	1
	local.set	19
	block   	
	local.get	12
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label157
# %bb.52:
	local.get	2
	local.get	12
	i32.add 
	i32.const	91
	i32.store8	0
	i32.const	1
	local.set	19
	local.get	4
	local.get	4
	i32.load	0
	i32.const	1
	i32.add 
	local.tee	18
	i32.store	0
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label157
# %bb.53:
	local.get	0
	i32.const	1
	i32.add 
	local.set	21
	local.get	0
	i32.const	2
	i32.add 
	local.set	22
	local.get	0
	i32.const	5
	i32.add 
	local.set	23
	local.get	0
	i32.const	4
	i32.add 
	local.set	24
	local.get	0
	i32.const	3
	i32.add 
	local.set	25
	i32.const	0
	local.set	17
.LBB16_54:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB16_55 Depth 2
                                        #     Child Loop BB16_64 Depth 2
                                        #     Child Loop BB16_69 Depth 2
                                        #       Child Loop BB16_70 Depth 3
                                        #       Child Loop BB16_84 Depth 3
                                        #       Child Loop BB16_137 Depth 3
                                        #       Child Loop BB16_143 Depth 3
                                        #       Child Loop BB16_172 Depth 3
                                        #     Child Loop BB16_195 Depth 2
	loop    	                                # label158:
	block   	
	local.get	10
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label159
.LBB16_55:                              #   Parent Loop BB16_54 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label160:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	19
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label159
# %bb.56:                               #   in Loop: Header=BB16_55 Depth=2
	i32.const	1
	local.get	19
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label159
# %bb.57:                               #   in Loop: Header=BB16_55 Depth=2
	i32.const	1
	local.set	19
	local.get	20
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label160
	br      	3                               # 3: down to label157
.LBB16_58:                              #   in Loop: Header=BB16_54 Depth=1
	end_loop
	end_block                               # label159:
	i32.const	1
	local.set	19
	local.get	10
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label157
# %bb.59:                               #   in Loop: Header=BB16_54 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	local.tee	16
	i32.load8_u	0
	local.tee	7
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: down to label161
# %bb.60:
	local.get	18
	local.get	3
	i32.ge_u
	br_if   	2                               # 2: down to label157
# %bb.61:
	local.get	2
	local.get	18
	i32.add 
	i32.const	93
	i32.store8	0
	local.get	4
	i32.load	0
	i32.const	1
	i32.add 
	local.set	12
	i32.const	0
	local.set	19
	br      	2                               # 2: down to label157
.LBB16_62:                              #   in Loop: Header=BB16_54 Depth=1
	end_block                               # label161:
	local.get	9
	i32.const	0
	i32.store	8
	block   	
	block   	
	block   	
	local.get	7
	i32.const	123
	i32.ne  
	br_if   	0                               # 0: down to label164
# %bb.63:                               #   in Loop: Header=BB16_54 Depth=1
	block   	
	block   	
	local.get	10
	i32.const	1
	i32.add 
	local.tee	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label166
.LBB16_64:                              #   Parent Loop BB16_54 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label167:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label166
# %bb.65:                               #   in Loop: Header=BB16_64 Depth=2
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label166
# %bb.66:                               #   in Loop: Header=BB16_64 Depth=2
	local.get	20
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label167
	br      	2                               # 2: down to label165
.LBB16_67:                              #   in Loop: Header=BB16_54 Depth=1
	end_loop
	end_block                               # label166:
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label165
# %bb.68:                               #   in Loop: Header=BB16_54 Depth=1
	i32.const	0
	local.set	26
	i32.const	0
	local.set	27
	i32.const	0
	local.set	14
	i32.const	0
	local.set	28
	i32.const	0
	local.set	29
.LBB16_69:                              #   Parent Loop BB16_54 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB16_70 Depth 3
                                        #       Child Loop BB16_84 Depth 3
                                        #       Child Loop BB16_137 Depth 3
                                        #       Child Loop BB16_143 Depth 3
                                        #       Child Loop BB16_172 Depth 3
	loop    	                                # label168:
	block   	
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label169
.LBB16_70:                              #   Parent Loop BB16_54 Depth=1
                                        #     Parent Loop BB16_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label170:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label169
# %bb.71:                               #   in Loop: Header=BB16_70 Depth=3
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label169
# %bb.72:                               #   in Loop: Header=BB16_70 Depth=3
	local.get	20
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label170
	br      	3                               # 3: down to label165
.LBB16_73:                              #   in Loop: Header=BB16_69 Depth=2
	end_loop
	end_block                               # label169:
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label165
# %bb.74:                               #   in Loop: Header=BB16_69 Depth=2
	block   	
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	local.tee	18
	i32.const	125
	i32.ne  
	br_if   	0                               # 0: down to label171
# %bb.75:                               #   in Loop: Header=BB16_54 Depth=1
	local.get	27
	i32.const	2
	i32.ne  
	br_if   	2                               # 2: down to label165
# %bb.76:                               #   in Loop: Header=BB16_54 Depth=1
	local.get	26
	i32.eqz
	br_if   	2                               # 2: down to label165
# %bb.77:                               #   in Loop: Header=BB16_54 Depth=1
	local.get	29
	i32.eqz
	br_if   	2                               # 2: down to label165
# %bb.78:                               #   in Loop: Header=BB16_54 Depth=1
	local.get	16
	i32.load8_u	0
	i32.const	91
	i32.eq  
	br_if   	7                               # 7: down to label157
# %bb.79:                               #   in Loop: Header=BB16_54 Depth=1
	i32.const	1
	local.set	18
	local.get	7
	i32.const	1
	i32.add 
	local.set	7
	br      	5                               # 5: down to label162
.LBB16_80:                              #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label171:
	local.get	27
	i32.const	1
	i32.gt_u
	br_if   	1                               # 1: down to label165
# %bb.81:                               #   in Loop: Header=BB16_69 Depth=2
	local.get	18
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label165
# %bb.82:                               #   in Loop: Header=BB16_69 Depth=2
	local.get	7
	i32.const	1
	i32.add 
	local.tee	30
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label165
# %bb.83:                               #   in Loop: Header=BB16_69 Depth=2
	local.get	30
	local.set	15
.LBB16_84:                              #   Parent Loop BB16_54 Depth=1
                                        #     Parent Loop BB16_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label172:
	block   	
	local.get	15
	local.tee	18
	i32.const	8
	i32.add 
	local.tee	15
	local.get	20
	i32.gt_u
	br_if   	0                               # 0: down to label173
# %bb.85:                               #   in Loop: Header=BB16_84 Depth=3
	local.get	0
	local.get	18
	i32.add 
	i64.load	0:p2align=0
	local.tee	31
	i64.const	-1
	i64.xor 
	local.get	31
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	31
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	31
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	31
	i64.eqz
	br_if   	1                               # 1: up to label172
# %bb.86:                               #   in Loop: Header=BB16_84 Depth=3
	local.get	31
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	18
	i32.add 
	local.set	18
.LBB16_87:                              #   in Loop: Header=BB16_84 Depth=3
	end_block                               # label173:
	local.get	18
	local.get	20
	i32.ge_u
	br_if   	2                               # 2: down to label165
# %bb.88:                               #   in Loop: Header=BB16_84 Depth=3
	block   	
	block   	
	block   	
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label176
# %bb.89:                               #   in Loop: Header=BB16_84 Depth=3
	local.get	18
	i32.const	1
	i32.add 
	local.tee	15
	local.get	20
	i32.ge_u
	br_if   	5                               # 5: down to label165
# %bb.90:                               #   in Loop: Header=BB16_84 Depth=3
	block   	
	block   	
	local.get	0
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 1, 0, 7} # 7: down to label165
                                        # 1: down to label177
                                        # 0: down to label178
.LBB16_91:                              #   in Loop: Header=BB16_84 Depth=3
	end_block                               # label178:
	local.get	18
	i32.const	6
	i32.add 
	local.tee	15
	local.get	20
	i32.gt_u
	br_if   	6                               # 6: down to label165
# %bb.92:                               #   in Loop: Header=BB16_84 Depth=3
	local.get	18
	i32.const	2
	i32.add 
	local.tee	32
	local.get	15
	i32.ge_u
	br_if   	2                               # 2: down to label175
# %bb.93:                               #   in Loop: Header=BB16_84 Depth=3
	block   	
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label179
# %bb.94:                               #   in Loop: Header=BB16_84 Depth=3
	local.get	32
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label165
.LBB16_95:                              #   in Loop: Header=BB16_84 Depth=3
	end_block                               # label179:
	block   	
	local.get	25
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label180
# %bb.96:                               #   in Loop: Header=BB16_84 Depth=3
	local.get	32
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label165
.LBB16_97:                              #   in Loop: Header=BB16_84 Depth=3
	end_block                               # label180:
	block   	
	local.get	24
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label181
# %bb.98:                               #   in Loop: Header=BB16_84 Depth=3
	local.get	32
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label165
.LBB16_99:                              #   in Loop: Header=BB16_84 Depth=3
	end_block                               # label181:
	local.get	23
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	18
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label175
# %bb.100:                              #   in Loop: Header=BB16_84 Depth=3
	local.get	18
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label175
	br      	6                               # 6: down to label165
.LBB16_101:                             #   in Loop: Header=BB16_84 Depth=3
	end_block                               # label177:
	local.get	18
	i32.const	2
	i32.add 
	local.set	15
	br      	1                               # 1: down to label175
.LBB16_102:                             #   in Loop: Header=BB16_84 Depth=3
	end_block                               # label176:
	local.get	32
	i32.const	32
	i32.lt_u
	br_if   	4                               # 4: down to label165
# %bb.103:                              #   in Loop: Header=BB16_84 Depth=3
	local.get	18
	i32.const	1
	i32.add 
	local.set	15
	local.get	32
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label174
.LBB16_104:                             #   in Loop: Header=BB16_84 Depth=3
	end_block                               # label175:
	local.get	15
	local.get	20
	i32.lt_u
	br_if   	1                               # 1: up to label172
	br      	3                               # 3: down to label165
.LBB16_105:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label174:
	end_loop
	i32.const	0
	local.set	32
	i32.const	0
	local.set	33
	block   	
	local.get	18
	local.get	7
	i32.lt_u
	br_if   	0                               # 0: down to label182
# %bb.106:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	7
	i32.const	5
	i32.add 
	local.set	34
	i32.const	0
	local.set	33
	i32.const	0
	local.set	32
	block   	
	local.get	18
	local.get	7
	i32.eq  
	br_if   	0                               # 0: down to label183
# %bb.107:                              #   in Loop: Header=BB16_69 Depth=2
	block   	
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label184
# %bb.108:                              #   in Loop: Header=BB16_69 Depth=2
	i32.const	0
	local.set	32
	local.get	18
	local.get	7
	i32.sub 
	local.tee	36
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label183
# %bb.109:                              #   in Loop: Header=BB16_69 Depth=2
	i32.const	0
	local.set	32
	local.get	35
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label183
# %bb.110:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	22
	local.get	7
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label184
# %bb.111:                              #   in Loop: Header=BB16_69 Depth=2
	i32.const	0
	local.set	32
	local.get	35
	i32.const	121
	i32.ne  
	br_if   	1                               # 1: down to label183
# %bb.112:                              #   in Loop: Header=BB16_69 Depth=2
	i32.const	0
	local.set	32
	local.get	36
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label183
# %bb.113:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	25
	local.get	7
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label184
# %bb.114:                              #   in Loop: Header=BB16_69 Depth=2
	i32.const	0
	local.set	32
	local.get	35
	i32.const	112
	i32.ne  
	br_if   	1                               # 1: down to label183
# %bb.115:                              #   in Loop: Header=BB16_69 Depth=2
	i32.const	0
	local.set	32
	local.get	36
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label183
# %bb.116:                              #   in Loop: Header=BB16_69 Depth=2
	i32.const	0
	local.set	32
	block   	
	local.get	24
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label183
                                        # 0: down to label185
.LBB16_117:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label185:
	i32.const	0
	local.set	32
	local.get	34
	local.get	18
	i32.gt_u
	br_if   	1                               # 1: down to label183
# %bb.118:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	0
	local.get	34
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	32
	br      	1                               # 1: down to label183
.LBB16_119:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label184:
	local.get	0
	local.get	7
	local.get	15
	i32.const	.L.str
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	32
.LBB16_120:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label183:
	local.get	18
	local.get	7
	i32.le_u
	br_if   	0                               # 0: down to label182
# %bb.121:                              #   in Loop: Header=BB16_69 Depth=2
	block   	
	block   	
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	local.tee	30
	i32.const	116
	i32.ne  
	br_if   	0                               # 0: down to label187
# %bb.122:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	7
	i32.const	2
	i32.add 
	local.tee	30
	local.get	18
	i32.gt_u
	br_if   	2                               # 2: down to label182
# %bb.123:                              #   in Loop: Header=BB16_69 Depth=2
	block   	
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{2, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label182
                                        # 0: down to label188
.LBB16_124:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label188:
	local.get	7
	i32.const	3
	i32.add 
	local.tee	30
	local.get	18
	i32.gt_u
	br_if   	2                               # 2: down to label182
# %bb.125:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	local.tee	30
	i32.const	92
	i32.eq  
	br_if   	1                               # 1: down to label186
# %bb.126:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	30
	i32.const	120
	i32.ne  
	br_if   	2                               # 2: down to label182
# %bb.127:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	7
	i32.const	4
	i32.add 
	local.tee	30
	local.get	18
	i32.gt_u
	br_if   	2                               # 2: down to label182
# %bb.128:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	0
	local.get	30
	i32.add 
	i32.load8_u	0
	local.tee	30
	i32.const	92
	i32.eq  
	br_if   	1                               # 1: down to label186
# %bb.129:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	30
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label182
# %bb.130:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	34
	local.get	18
	i32.gt_u
	br_if   	2                               # 2: down to label182
# %bb.131:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	0
	local.get	34
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	33
	br      	2                               # 2: down to label182
.LBB16_132:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label187:
	local.get	30
	i32.const	92
	i32.ne  
	br_if   	1                               # 1: down to label182
.LBB16_133:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label186:
	local.get	0
	local.get	7
	local.get	15
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	33
.LBB16_134:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label182:
	block   	
	local.get	32
	br_if   	0                               # 0: down to label189
# %bb.135:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	33
	i32.eqz
	br_if   	2                               # 2: down to label165
.LBB16_136:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label189:
	block   	
	local.get	15
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label190
.LBB16_137:                             #   Parent Loop BB16_54 Depth=1
                                        #     Parent Loop BB16_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label191:
	local.get	0
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	7
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label190
# %bb.138:                              #   in Loop: Header=BB16_137 Depth=3
	i32.const	1
	local.get	7
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label190
# %bb.139:                              #   in Loop: Header=BB16_137 Depth=3
	local.get	20
	local.get	15
	i32.const	1
	i32.add 
	local.tee	15
	i32.ne  
	br_if   	0                               # 0: up to label191
	br      	3                               # 3: down to label165
.LBB16_140:                             #   in Loop: Header=BB16_69 Depth=2
	end_loop
	end_block                               # label190:
	local.get	15
	local.get	20
	i32.ge_u
	br_if   	1                               # 1: down to label165
# %bb.141:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	0
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	1                               # 1: down to label165
# %bb.142:                              #   in Loop: Header=BB16_69 Depth=2
	block   	
	local.get	15
	i32.const	1
	i32.add 
	local.tee	18
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label192
.LBB16_143:                             #   Parent Loop BB16_54 Depth=1
                                        #     Parent Loop BB16_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label193:
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	7
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label192
# %bb.144:                              #   in Loop: Header=BB16_143 Depth=3
	i32.const	1
	local.get	7
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label192
# %bb.145:                              #   in Loop: Header=BB16_143 Depth=3
	local.get	20
	local.get	18
	i32.const	1
	i32.add 
	local.tee	18
	i32.ne  
	br_if   	0                               # 0: up to label193
# %bb.146:                              #   in Loop: Header=BB16_69 Depth=2
	end_loop
	local.get	20
	local.set	18
.LBB16_147:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label192:
	local.get	9
	i32.const	0
	i32.store	12
	local.get	0
	local.get	20
	local.get	18
	local.get	9
	i32.const	12
	i32.add 
	call	parse_value_span
	i32.eqz
	br_if   	1                               # 1: down to label165
# %bb.148:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	9
	i32.load	12
	local.tee	7
	local.get	20
	i32.gt_u
	br_if   	1                               # 1: down to label165
# %bb.149:                              #   in Loop: Header=BB16_69 Depth=2
	block   	
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label195
# %bb.150:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	7
	local.get	18
	i32.le_u
	br_if   	3                               # 3: down to label165
# %bb.151:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	3                               # 3: down to label165
# %bb.152:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	7
	local.get	18
	i32.const	-1
	i32.xor 
	i32.add 
	local.tee	15
	i32.eqz
	br_if   	3                               # 3: down to label165
# %bb.153:                              #   in Loop: Header=BB16_69 Depth=2
	block   	
	local.get	21
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label196
# %bb.154:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	15
	i32.const	1
	i32.eq  
	br_if   	4                               # 4: down to label165
# %bb.155:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	32
	i32.const	116
	i32.ne  
	br_if   	4                               # 4: down to label165
# %bb.156:                              #   in Loop: Header=BB16_69 Depth=2
	block   	
	local.get	22
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 5, 5, 5, 5, 5, 5, 5, 5, 0, 5} # 5: down to label165
                                        # 0: down to label197
.LBB16_157:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label197:
	local.get	15
	i32.const	2
	i32.eq  
	br_if   	4                               # 4: down to label165
# %bb.158:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	25
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label196
# %bb.159:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	32
	i32.const	120
	i32.ne  
	br_if   	4                               # 4: down to label165
# %bb.160:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	15
	i32.const	3
	i32.eq  
	br_if   	4                               # 4: down to label165
# %bb.161:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	24
	local.get	18
	i32.add 
	i32.load8_u	0
	local.tee	15
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label196
# %bb.162:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	15
	i32.const	116
	i32.ne  
	br_if   	4                               # 4: down to label165
# %bb.163:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	18
	i32.const	5
	i32.add 
	local.tee	18
	local.get	7
	i32.ge_u
	br_if   	4                               # 4: down to label165
# %bb.164:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	4                               # 4: down to label165
# %bb.165:                              #   in Loop: Header=BB16_69 Depth=2
	i32.const	1
	local.set	26
	br      	2                               # 2: down to label194
.LBB16_166:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label196:
	local.get	0
	local.get	18
	local.get	7
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	3                               # 3: down to label165
# %bb.167:                              #   in Loop: Header=BB16_69 Depth=2
	i32.const	1
	local.set	26
	br      	1                               # 1: down to label194
.LBB16_168:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label195:
	local.get	7
	local.get	18
	i32.le_u
	br_if   	2                               # 2: down to label165
# %bb.169:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	0
	local.get	18
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	2                               # 2: down to label165
# %bb.170:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	7
	local.get	18
	i32.sub 
	local.set	14
	i32.const	1
	local.set	29
	local.get	18
	local.set	28
.LBB16_171:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label194:
	block   	
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label198
.LBB16_172:                             #   Parent Loop BB16_54 Depth=1
                                        #     Parent Loop BB16_69 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label199:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	18
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label198
# %bb.173:                              #   in Loop: Header=BB16_172 Depth=3
	i32.const	1
	local.get	18
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label198
# %bb.174:                              #   in Loop: Header=BB16_172 Depth=3
	local.get	20
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label199
	br      	3                               # 3: down to label165
.LBB16_175:                             #   in Loop: Header=BB16_69 Depth=2
	end_loop
	end_block                               # label198:
	block   	
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label200
# %bb.176:                              #   in Loop: Header=BB16_69 Depth=2
	local.get	7
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.eq  
	i32.add 
	local.set	7
.LBB16_177:                             #   in Loop: Header=BB16_69 Depth=2
	end_block                               # label200:
	local.get	27
	i32.const	1
	i32.add 
	local.set	27
	local.get	7
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: up to label168
.LBB16_178:                             #   in Loop: Header=BB16_54 Depth=1
	end_loop
	end_block                               # label165:
	local.get	16
	i32.load8_u	0
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	1                               # 1: down to label163
	br      	4                               # 4: down to label157
.LBB16_179:                             #   in Loop: Header=BB16_54 Depth=1
	end_block                               # label164:
	local.get	7
	i32.const	223
	i32.and 
	i32.const	91
	i32.eq  
	br_if   	3                               # 3: down to label157
.LBB16_180:                             #   in Loop: Header=BB16_54 Depth=1
	end_block                               # label163:
	local.get	0
	local.get	20
	local.get	10
	local.get	9
	i32.const	8
	i32.add 
	call	parse_value_span
	i32.eqz
	br_if   	2                               # 2: down to label157
# %bb.181:                              #   in Loop: Header=BB16_54 Depth=1
	i32.const	0
	local.set	28
	i32.const	0
	local.set	14
	i32.const	0
	local.set	18
	local.get	9
	i32.load	8
	local.tee	7
	local.get	20
	i32.gt_u
	br_if   	2                               # 2: down to label157
.LBB16_182:                             #   in Loop: Header=BB16_54 Depth=1
	end_block                               # label162:
	block   	
	local.get	17
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label201
# %bb.183:                              #   in Loop: Header=BB16_54 Depth=1
	local.get	4
	i32.load	0
	local.tee	15
	local.get	3
	i32.ge_u
	br_if   	2                               # 2: down to label157
# %bb.184:                              #   in Loop: Header=BB16_54 Depth=1
	local.get	2
	local.get	15
	i32.add 
	i32.const	44
	i32.store8	0
	local.get	4
	local.get	4
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
.LBB16_185:                             #   in Loop: Header=BB16_54 Depth=1
	end_block                               # label201:
	block   	
	block   	
	local.get	18
	i32.eqz
	br_if   	0                               # 0: down to label203
# %bb.186:                              #   in Loop: Header=BB16_54 Depth=1
	local.get	4
	i32.load	0
	local.tee	10
	local.get	14
	i32.add 
	local.tee	18
	local.get	10
	i32.lt_u
	br_if   	3                               # 3: down to label157
# %bb.187:                              #   in Loop: Header=BB16_54 Depth=1
	local.get	18
	local.get	3
	i32.gt_u
	br_if   	3                               # 3: down to label157
# %bb.188:                              #   in Loop: Header=BB16_54 Depth=1
	local.get	14
	i32.eqz
	br_if   	1                               # 1: down to label202
# %bb.189:                              #   in Loop: Header=BB16_54 Depth=1
	local.get	2
	local.get	10
	i32.add 
	local.get	0
	local.get	28
	i32.add 
	local.get	14
	memory.copy	0, 0
	br      	1                               # 1: down to label202
.LBB16_190:                             #   in Loop: Header=BB16_54 Depth=1
	end_block                               # label203:
	local.get	4
	i32.load	0
	local.tee	15
	local.get	7
	local.get	10
	i32.sub 
	local.tee	10
	i32.add 
	local.tee	18
	local.get	15
	i32.lt_u
	br_if   	2                               # 2: down to label157
# %bb.191:                              #   in Loop: Header=BB16_54 Depth=1
	local.get	18
	local.get	3
	i32.gt_u
	br_if   	2                               # 2: down to label157
# %bb.192:                              #   in Loop: Header=BB16_54 Depth=1
	local.get	10
	i32.eqz
	br_if   	0                               # 0: down to label202
# %bb.193:                              #   in Loop: Header=BB16_54 Depth=1
	local.get	2
	local.get	15
	i32.add 
	local.get	16
	local.get	10
	memory.copy	0, 0
.LBB16_194:                             #   in Loop: Header=BB16_54 Depth=1
	end_block                               # label202:
	local.get	4
	local.get	18
	i32.store	0
	block   	
	local.get	7
	local.get	20
	i32.ge_u
	br_if   	0                               # 0: down to label204
.LBB16_195:                             #   Parent Loop BB16_54 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label205:
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label204
# %bb.196:                              #   in Loop: Header=BB16_195 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label204
# %bb.197:                              #   in Loop: Header=BB16_195 Depth=2
	local.get	20
	local.get	7
	i32.const	1
	i32.add 
	local.tee	7
	i32.ne  
	br_if   	0                               # 0: up to label205
	br      	3                               # 3: down to label157
.LBB16_198:                             #   in Loop: Header=BB16_54 Depth=1
	end_loop
	end_block                               # label204:
	block   	
	block   	
	local.get	7
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: down to label207
# %bb.199:                              #   in Loop: Header=BB16_54 Depth=1
	local.get	7
	local.set	10
	br      	1                               # 1: down to label206
.LBB16_200:                             #   in Loop: Header=BB16_54 Depth=1
	end_block                               # label207:
	local.get	7
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.eq  
	i32.add 
	local.set	10
.LBB16_201:                             #   in Loop: Header=BB16_54 Depth=1
	end_block                               # label206:
	i32.const	1
	local.set	17
	local.get	10
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: up to label158
# %bb.202:
	end_loop
	i32.const	1
	local.set	19
.LBB16_203:
	end_block                               # label157:
	local.get	4
	local.get	12
	i32.store	0
.LBB16_204:
	end_block                               # label156:
	block   	
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label208
# %bb.205:
	block   	
	local.get	19
	br_if   	0                               # 0: down to label209
# %bb.206:
	local.get	8
	local.get	8
	i32.load	12
	i32.const	1
	i32.add 
	i32.store	12
	br      	4                               # 4: down to label151
.LBB16_207:
	end_block                               # label209:
	local.get	8
	local.get	8
	i32.load	16
	i32.const	1
	i32.add 
	i32.store	16
	br      	1                               # 1: down to label155
.LBB16_208:
	end_block                               # label208:
	local.get	19
	i32.eqz
	br_if   	2                               # 2: down to label151
.LBB16_209:
	end_block                               # label155:
	local.get	0
	local.get	1
	i32.load	40
	local.get	1
	i32.load	36
	local.tee	1
	i32.add 
	local.tee	12
	local.get	1
	local.get	12
	local.get	2
	local.get	3
	local.get	4
	call	write_normalized_glossary_value
	br_if   	1                               # 1: down to label151
# %bb.210:
	i32.const	0
	local.set	10
	br      	2                               # 2: down to label138
.LBB16_211:
	end_block                               # label152:
	local.get	12
	i32.const	-3
	i32.gt_u
	br_if   	1                               # 1: down to label138
# %bb.212:
	local.get	19
	i32.const	3
	i32.add 
	local.tee	1
	local.get	3
	i32.gt_u
	br_if   	1                               # 1: down to label138
# %bb.213:
	local.get	2
	local.get	12
	i32.add 
	i32.const	23899
	i32.store16	0:p2align=0
	local.get	4
	local.get	1
	i32.store	0
.LBB16_214:
	end_block                               # label151:
	local.get	4
	i32.load	0
	local.set	1
	local.get	9
	i32.const	0
	i32.store	12
	local.get	9
	i32.const	0
	i32.store	8
	local.get	13
	local.get	1
	local.get	11
	i32.sub 
	local.get	9
	i32.const	12
	i32.add 
	local.get	9
	i32.const	8
	i32.add 
	call	hash_content_xxh32_pair
	i32.const	1
	local.set	10
	local.get	5
	local.get	9
	i32.load	12
	local.tee	1
	i32.const	1
	local.get	1
	local.get	9
	i32.load	8
	local.tee	4
	i32.or  
	i32.select
	i32.store	0
	local.get	6
	local.get	4
	i32.store	0
.LBB16_215:
	end_block                               # label138:
	local.get	9
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	10
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.build_term_string_plan,"",@
	.globl	build_term_string_plan          # -- Begin function build_term_string_plan
	.type	build_term_string_plan,@function
build_term_string_plan:                 # @build_term_string_plan
	.functype	build_term_string_plan (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	32
	i32.sub 
	local.tee	14
	global.set	__stack_pointer
	i32.const	-1
	local.set	15
	block   	
	local.get	0
	i32x4.splat
	local.get	1
	i32x4.replace_lane	1
	local.get	4
	i32x4.replace_lane	2
	local.get	6
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	16
	i32x4.eq
	v128.const	65535, 65535, 65535, 65535
	local.tee	17
	v128.and
	local.get	7
	i32x4.splat
	local.get	8
	i32x4.replace_lane	1
	local.get	9
	i32x4.replace_lane	2
	local.get	10
	i32x4.replace_lane	3
	local.get	16
	i32x4.eq
	local.get	17
	v128.and
	i16x8.narrow_i32x4_u
	v128.any_true
	br_if   	0                               # 0: down to label210
# %bb.1:
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label210
# %bb.2:
	local.get	13
	i32.eqz
	br_if   	0                               # 0: down to label210
# %bb.3:
	local.get	12
	i32.eqz
	br_if   	0                               # 0: down to label210
# %bb.4:
	i32.const	-1
	local.set	15
	local.get	12
	local.get	12
	i32.const	-1
	i32.add 
	local.tee	18
	i32.and 
	br_if   	0                               # 0: down to label210
# %bb.5:
	block   	
	block   	
	local.get	3
	br_if   	0                               # 0: down to label212
# %bb.6:
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
	br      	1                               # 1: down to label211
.LBB17_7:
	end_block                               # label212:
	local.get	3
	i32.const	1
	i32.shl 
	local.set	21
	local.get	1
	local.get	2
	i32.const	68
	i32.mul 
	i32.add 
	local.set	22
	i32.const	0
	local.set	20
	i32.const	0
	local.set	19
	i32.const	0
	local.set	23
.LBB17_8:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB17_14 Depth 2
                                        #     Child Loop BB17_19 Depth 2
                                        #     Child Loop BB17_22 Depth 2
                                        #       Child Loop BB17_28 Depth 3
                                        #       Child Loop BB17_35 Depth 3
                                        #         Child Loop BB17_41 Depth 4
                                        #         Child Loop BB17_43 Depth 4
                                        #         Child Loop BB17_46 Depth 4
                                        #       Child Loop BB17_56 Depth 3
	loop    	                                # label213:
	local.get	14
	local.get	22
	local.get	23
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	15
	i32.load	0
	local.tee	1
	i32.store	28
	local.get	14
	local.get	15
	i32.load	8
	local.tee	2
	i32.store	24
	local.get	14
	local.get	15
	i32.load	4
	local.tee	24
	i32.store	20
	local.get	14
	local.get	15
	i32.load	12
	local.tee	15
	i32.store	16
	local.get	14
	i32.const	0
	i32.store	8
	local.get	14
	i32.const	0
	i32.store	4
	i32.const	0
	local.set	25
	block   	
	local.get	15
	i32.const	2
	i32.ne  
	br_if   	0                               # 0: down to label214
# %bb.9:                                #   in Loop: Header=BB17_8 Depth=1
	i32.const	0
	local.set	25
	local.get	0
	local.get	2
	i32.add 
	local.tee	26
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label214
# %bb.10:                               #   in Loop: Header=BB17_8 Depth=1
	local.get	26
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	25
.LBB17_11:                              #   in Loop: Header=BB17_8 Depth=1
	end_block                               # label214:
	block   	
	local.get	25
	br_if   	0                               # 0: down to label215
# %bb.12:                               #   in Loop: Header=BB17_8 Depth=1
	local.get	24
	local.get	15
	i32.ne  
	br_if   	0                               # 0: down to label215
# %bb.13:                               #   in Loop: Header=BB17_8 Depth=1
	local.get	24
	i32.const	-1
	i32.add 
	local.set	26
	i32.const	0
	local.set	15
	local.get	0
	local.get	1
	i32.add 
	local.tee	27
	local.set	1
	local.get	0
	local.get	2
	i32.add 
	local.tee	28
	local.set	2
.LBB17_14:                              #   Parent Loop BB17_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label217:
	block   	
	local.get	15
	i32.const	8
	i32.add 
	local.tee	29
	local.get	24
	i32.le_u
	br_if   	0                               # 0: down to label218
# %bb.15:                               #   in Loop: Header=BB17_8 Depth=1
	local.get	15
	local.get	24
	i32.lt_u
	br_if   	2                               # 2: down to label216
# %bb.16:                               #   in Loop: Header=BB17_8 Depth=1
	i32.const	1
	local.set	25
	br      	3                               # 3: down to label215
.LBB17_17:                              #   in Loop: Header=BB17_14 Depth=2
	end_block                               # label218:
	local.get	28
	local.get	15
	i32.add 
	local.set	30
	local.get	27
	local.get	15
	i32.add 
	local.set	31
	local.get	1
	i32.const	8
	i32.add 
	local.set	1
	local.get	2
	i32.const	8
	i32.add 
	local.set	2
	local.get	26
	i32.const	-8
	i32.add 
	local.set	26
	local.get	29
	local.set	15
	local.get	31
	i64.load	0:p2align=0
	local.get	30
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label217
# %bb.18:                               #   in Loop: Header=BB17_8 Depth=1
	end_loop
	i32.const	0
	local.set	25
	br      	1                               # 1: down to label215
.LBB17_19:                              #   Parent Loop BB17_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	end_block                               # label216:
	loop    	                                # label219:
	local.get	1
	i32.load8_u	0
	local.tee	15
	local.get	2
	i32.load8_u	0
	local.tee	29
	i32.eq  
	local.set	25
	local.get	15
	local.get	29
	i32.ne  
	br_if   	1                               # 1: down to label215
# %bb.20:                               #   in Loop: Header=BB17_19 Depth=2
	local.get	26
	i32.const	0
	i32.ne  
	local.set	15
	local.get	1
	i32.const	1
	i32.add 
	local.set	1
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	local.get	26
	i32.const	-1
	i32.add 
	local.set	26
	local.get	15
	br_if   	0                               # 0: up to label219
.LBB17_21:                              #   in Loop: Header=BB17_8 Depth=1
	end_loop
	end_block                               # label215:
	local.get	14
	i32.const	28
	i32.add 
	local.set	1
	local.get	14
	i32.const	20
	i32.add 
	local.set	26
	local.get	14
	i32.const	8
	i32.add 
	local.set	32
	i32.const	1
	local.set	33
	i32.const	0
	local.set	15
.LBB17_22:                              #   Parent Loop BB17_8 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB17_28 Depth 3
                                        #       Child Loop BB17_35 Depth 3
                                        #         Child Loop BB17_41 Depth 4
                                        #         Child Loop BB17_43 Depth 4
                                        #         Child Loop BB17_46 Depth 4
                                        #       Child Loop BB17_56 Depth 3
	block   	
	loop    	                                # label221:
	block   	
	local.get	25
	local.get	15
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label222
# %bb.23:                               #   in Loop: Header=BB17_8 Depth=1
	local.get	14
	local.get	14
	i32.load	8
	i32.store	4
	br      	2                               # 2: down to label220
.LBB17_24:                              #   in Loop: Header=BB17_22 Depth=2
	end_block                               # label222:
	local.get	1
	i32.load	0
	local.set	2
	block   	
	block   	
	block   	
	local.get	26
	i32.load	0
	local.tee	26
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label225
# %bb.25:                               #   in Loop: Header=BB17_22 Depth=2
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label225
# %bb.26:                               #   in Loop: Header=BB17_22 Depth=2
	local.get	0
	local.get	2
	local.get	26
	i32.add 
	i32.const	-1
	i32.add 
	local.tee	29
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label225
# %bb.27:                               #   in Loop: Header=BB17_22 Depth=2
	local.get	26
	i32.const	-2
	i32.add 
	local.set	30
	local.get	2
	i32.const	1
	i32.add 
	local.set	31
	local.get	2
	i32.const	1
	i32.add 
	local.set	15
.LBB17_28:                              #   Parent Loop BB17_8 Depth=1
                                        #     Parent Loop BB17_22 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label226:
	local.get	15
	local.get	29
	i32.ge_u
	br_if   	2                               # 2: down to label224
# %bb.29:                               #   in Loop: Header=BB17_28 Depth=3
	local.get	0
	local.get	15
	i32.add 
	local.set	1
	local.get	15
	i32.const	1
	i32.add 
	local.set	15
	local.get	1
	i32.load8_u	0
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: up to label226
.LBB17_30:                              #   in Loop: Header=BB17_22 Depth=2
	end_loop
	end_block                               # label225:
	local.get	19
	local.set	31
	local.get	4
	local.set	34
	local.get	0
	local.get	2
	i32.add 
	local.get	26
	local.get	4
	local.get	19
	i32.add 
	local.get	5
	local.get	19
	i32.sub 
	call	decode_escaped_key
	local.tee	30
	i32.const	65536
	i32.lt_u
	br_if   	1                               # 1: down to label223
# %bb.31:
	i32.const	-4
	local.set	15
	br      	6                               # 6: down to label210
.LBB17_32:                              #   in Loop: Header=BB17_22 Depth=2
	end_block                               # label224:
	local.get	0
	local.set	34
	local.get	30
	i32.const	65535
	i32.le_u
	br_if   	0                               # 0: down to label223
# %bb.33:
	i32.const	-5
	local.set	15
	br      	5                               # 5: down to label210
.LBB17_34:                              #   in Loop: Header=BB17_22 Depth=2
	end_block                               # label223:
	local.get	34
	local.get	31
	i32.add 
	local.tee	35
	local.get	30
	i32.const	-2128831035
	call	hash_content_xxh32
	local.tee	36
	local.get	30
	i32.const	-2048144789
	i32.mul 
	i32.xor 
	local.tee	15
	i32.const	16
	i32.shr_u
	local.get	15
	i32.xor 
	local.get	18
	i32.and 
	local.set	27
	i32.const	0
	local.set	37
.LBB17_35:                              #   Parent Loop BB17_8 Depth=1
                                        #     Parent Loop BB17_22 Depth=2
                                        # =>    This Loop Header: Depth=3
                                        #         Child Loop BB17_41 Depth 4
                                        #         Child Loop BB17_43 Depth 4
                                        #         Child Loop BB17_46 Depth 4
	block   	
	block   	
	loop    	                                # label229:
	local.get	11
	local.get	27
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	15
	i32.eqz
	br_if   	1                               # 1: down to label228
# %bb.36:                               #   in Loop: Header=BB17_35 Depth=3
	block   	
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	28
	local.get	20
	i32.lt_u
	br_if   	0                               # 0: down to label230
# %bb.37:
	i32.const	-3
	local.set	15
	br      	8                               # 8: down to label210
.LBB17_38:                              #   in Loop: Header=BB17_35 Depth=3
	end_block                               # label230:
	block   	
	local.get	8
	local.get	28
	i32.const	2
	i32.shl 
	local.tee	15
	i32.add 
	i32.load	0
	local.get	36
	i32.ne  
	br_if   	0                               # 0: down to label231
# %bb.39:                               #   in Loop: Header=BB17_35 Depth=3
	local.get	30
	local.get	6
	local.get	28
	i32.const	1
	i32.shl 
	i32.add 
	i32.load16_u	0
	i32.ne  
	br_if   	0                               # 0: down to label231
# %bb.40:                               #   in Loop: Header=BB17_35 Depth=3
	i32.const	0
	local.set	2
	local.get	4
	local.get	7
	local.get	15
	i32.add 
	i32.load	0
	i32.add 
	local.tee	38
	local.set	15
	local.get	35
	local.set	1
.LBB17_41:                              #   Parent Loop BB17_8 Depth=1
                                        #     Parent Loop BB17_22 Depth=2
                                        #       Parent Loop BB17_35 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	loop    	                                # label232:
	block   	
	local.get	30
	local.get	2
	i32.add 
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label233
# %bb.42:                               #   in Loop: Header=BB17_35 Depth=3
	i32.const	0
	local.set	26
	local.get	30
	local.set	29
.LBB17_43:                              #   Parent Loop BB17_8 Depth=1
                                        #     Parent Loop BB17_22 Depth=2
                                        #       Parent Loop BB17_35 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	block   	
	loop    	                                # label235:
	block   	
	local.get	2
	local.get	29
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label236
# %bb.44:                               #   in Loop: Header=BB17_35 Depth=3
	local.get	26
	local.get	2
	i32.sub 
	local.tee	15
	local.get	30
	i32.lt_u
	br_if   	2                               # 2: down to label234
	br      	8                               # 8: down to label227
.LBB17_45:                              #   in Loop: Header=BB17_43 Depth=4
	end_block                               # label236:
	local.get	1
	local.get	26
	i32.add 
	local.set	31
	local.get	15
	local.get	26
	i32.add 
	local.set	24
	local.get	29
	i32.const	-8
	i32.add 
	local.set	29
	local.get	26
	i32.const	8
	i32.add 
	local.set	26
	local.get	24
	i64.load	0:p2align=0
	local.get	31
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label235
	br      	4                               # 4: down to label231
.LBB17_46:                              #   Parent Loop BB17_8 Depth=1
                                        #     Parent Loop BB17_22 Depth=2
                                        #       Parent Loop BB17_35 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	end_loop
	end_block                               # label234:
	loop    	                                # label237:
	local.get	38
	local.get	15
	i32.add 
	i32.load8_u	0
	local.get	35
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	3                               # 3: down to label231
# %bb.47:                               #   in Loop: Header=BB17_46 Depth=4
	local.get	15
	i32.const	1
	i32.add 
	local.tee	15
	local.get	30
	i32.ge_u
	br_if   	6                               # 6: down to label227
	br      	0                               # 0: up to label237
.LBB17_48:                              #   in Loop: Header=BB17_41 Depth=4
	end_loop
	end_block                               # label233:
	local.get	15
	i32.const	16
	i32.add 
	local.set	26
	local.get	1
	i32.const	16
	i32.add 
	local.set	29
	local.get	15
	v128.load	0:p2align=0
	local.set	16
	local.get	1
	v128.load	0:p2align=0
	local.set	17
	local.get	15
	i32.const	32
	i32.add 
	local.set	15
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	2
	i32.const	-32
	i32.add 
	local.set	2
	local.get	29
	v128.load	0:p2align=0
	local.get	26
	v128.load	0:p2align=0
	v128.xor
	local.get	17
	local.get	16
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label232
.LBB17_49:                              #   in Loop: Header=BB17_35 Depth=3
	end_loop
	end_block                               # label231:
	local.get	27
	i32.const	1
	i32.add 
	local.get	18
	i32.and 
	local.set	27
	local.get	37
	i32.const	1
	i32.add 
	local.tee	37
	local.get	12
	i32.ne  
	br_if   	0                               # 0: up to label229
.LBB17_50:                              #   in Loop: Header=BB17_22 Depth=2
	end_loop
	end_block                               # label228:
	i32.const	-2
	local.set	15
	local.get	20
	local.get	21
	i32.ge_u
	br_if   	5                               # 5: down to label210
# %bb.51:                               #   in Loop: Header=BB17_22 Depth=2
	local.get	11
	local.get	27
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	38
	i32.load	0
	br_if   	5                               # 5: down to label210
# %bb.52:                               #   in Loop: Header=BB17_22 Depth=2
	local.get	30
	local.get	19
	i32.add 
	local.tee	39
	local.get	5
	i32.gt_u
	br_if   	5                               # 5: down to label210
# %bb.53:                               #   in Loop: Header=BB17_22 Depth=2
	block   	
	local.get	34
	local.get	4
	i32.eq  
	br_if   	0                               # 0: down to label238
# %bb.54:                               #   in Loop: Header=BB17_22 Depth=2
	local.get	30
	i32.eqz
	br_if   	0                               # 0: down to label238
# %bb.55:                               #   in Loop: Header=BB17_22 Depth=2
	local.get	4
	local.get	19
	i32.add 
	local.set	29
	i32.const	0
	local.set	1
.LBB17_56:                              #   Parent Loop BB17_8 Depth=1
                                        #     Parent Loop BB17_22 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label239:
	local.get	29
	local.get	1
	i32.add 
	local.get	35
	local.get	1
	i32.add 
	i32.load8_s	0
	local.tee	2
	i32.store8	0
	local.get	1
	i32.const	1
	i32.add 
	local.set	26
	block   	
	block   	
	local.get	2
	i32.const	-1
	i32.le_s
	br_if   	0                               # 0: down to label241
# %bb.57:                               #   in Loop: Header=BB17_56 Depth=3
	local.get	26
	local.set	1
	br      	1                               # 1: down to label240
.LBB17_58:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label241:
	i32.const	0
	local.set	37
	block   	
	block   	
	local.get	2
	i32.const	62
	i32.add 
	i32.const	255
	i32.and 
	i32.const	30
	i32.lt_u
	local.tee	28
	i32.eqz
	br_if   	0                               # 0: down to label243
# %bb.59:                               #   in Loop: Header=BB17_56 Depth=3
	i32.const	1
	local.set	27
	br      	1                               # 1: down to label242
.LBB17_60:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label243:
	block   	
	local.get	2
	i32.const	-16
	i32.and 
	i32.const	-32
	i32.ne  
	br_if   	0                               # 0: down to label244
# %bb.61:                               #   in Loop: Header=BB17_56 Depth=3
	i32.const	2
	local.set	27
	i32.const	1
	local.set	37
	br      	1                               # 1: down to label242
.LBB17_62:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label244:
	block   	
	local.get	2
	i32.const	16
	i32.add 
	i32.const	255
	i32.and 
	i32.const	4
	i32.le_u
	br_if   	0                               # 0: down to label245
# %bb.63:
	i32.const	-4
	local.set	15
	br      	10                              # 10: down to label210
.LBB17_64:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label245:
	i32.const	3
	local.set	27
.LBB17_65:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label242:
	i32.const	-4
	local.set	15
	local.get	27
	local.get	30
	local.get	26
	i32.sub 
	i32.gt_u
	br_if   	8                               # 8: down to label210
# %bb.66:                               #   in Loop: Header=BB17_56 Depth=3
	local.get	35
	local.get	26
	i32.add 
	local.tee	31
	i32.load8_u	0
	local.set	24
	block   	
	local.get	2
	i32.const	-32
	i32.ne  
	br_if   	0                               # 0: down to label246
# %bb.67:                               #   in Loop: Header=BB17_56 Depth=3
	local.get	24
	i32.const	255
	i32.and 
	i32.const	160
	i32.lt_u
	br_if   	9                               # 9: down to label210
.LBB17_68:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label246:
	block   	
	local.get	2
	i32.const	-19
	i32.ne  
	br_if   	0                               # 0: down to label247
# %bb.69:                               #   in Loop: Header=BB17_56 Depth=3
	local.get	24
	i32.const	255
	i32.and 
	i32.const	159
	i32.gt_u
	br_if   	9                               # 9: down to label210
.LBB17_70:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label247:
	block   	
	local.get	2
	i32.const	-16
	i32.ne  
	br_if   	0                               # 0: down to label248
# %bb.71:                               #   in Loop: Header=BB17_56 Depth=3
	local.get	24
	i32.const	255
	i32.and 
	i32.const	144
	i32.lt_u
	br_if   	9                               # 9: down to label210
.LBB17_72:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label248:
	block   	
	local.get	2
	i32.const	-12
	i32.ne  
	br_if   	0                               # 0: down to label249
# %bb.73:                               #   in Loop: Header=BB17_56 Depth=3
	local.get	24
	i32.const	255
	i32.and 
	i32.const	143
	i32.gt_u
	br_if   	9                               # 9: down to label210
.LBB17_74:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label249:
	local.get	31
	i32.load8_s	0
	i32.const	-64
	i32.ge_s
	br_if   	8                               # 8: down to label210
# %bb.75:                               #   in Loop: Header=BB17_56 Depth=3
	block   	
	block   	
	local.get	28
	br_if   	0                               # 0: down to label251
# %bb.76:                               #   in Loop: Header=BB17_56 Depth=3
	local.get	31
	i32.load8_s	1
	i32.const	-65
	i32.gt_s
	br_if   	10                              # 10: down to label210
# %bb.77:                               #   in Loop: Header=BB17_56 Depth=3
	block   	
	local.get	37
	br_if   	0                               # 0: down to label252
# %bb.78:                               #   in Loop: Header=BB17_56 Depth=3
	local.get	31
	i32.load8_s	2
	i32.const	-64
	i32.ge_s
	br_if   	11                              # 11: down to label210
.LBB17_79:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label252:
	local.get	29
	local.get	26
	i32.add 
	local.get	31
	i32.load8_u	0
	i32.store8	0
	local.get	28
	br_if   	1                               # 1: down to label250
# %bb.80:                               #   in Loop: Header=BB17_56 Depth=3
	local.get	29
	local.get	1
	i32.const	2
	i32.add 
	local.tee	15
	i32.add 
	local.get	35
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.store8	0
	local.get	37
	br_if   	1                               # 1: down to label250
# %bb.81:                               #   in Loop: Header=BB17_56 Depth=3
	local.get	29
	local.get	1
	i32.const	3
	i32.add 
	local.tee	15
	i32.add 
	local.get	35
	local.get	15
	i32.add 
	i32.load8_u	0
	i32.store8	0
	br      	1                               # 1: down to label250
.LBB17_82:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label251:
	local.get	29
	local.get	26
	i32.add 
	local.get	31
	i32.load8_u	0
	i32.store8	0
.LBB17_83:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label250:
	local.get	27
	local.get	26
	i32.add 
	local.set	1
.LBB17_84:                              #   in Loop: Header=BB17_56 Depth=3
	end_block                               # label240:
	local.get	1
	local.get	30
	i32.lt_u
	br_if   	0                               # 0: up to label239
.LBB17_85:                              #   in Loop: Header=BB17_22 Depth=2
	end_loop
	end_block                               # label238:
	local.get	7
	local.get	20
	i32.const	2
	i32.shl 
	local.tee	15
	i32.add 
	local.get	19
	i32.store	0
	local.get	8
	local.get	15
	i32.add 
	local.get	36
	i32.store	0
	local.get	6
	local.get	20
	i32.const	1
	i32.shl 
	i32.add 
	local.get	30
	i32.store16	0
	local.get	38
	local.get	20
	i32.const	1
	i32.add 
	local.tee	15
	i32.store	0
	local.get	20
	local.set	28
	local.get	39
	local.set	19
	local.get	15
	local.set	20
.LBB17_86:                              #   in Loop: Header=BB17_22 Depth=2
	end_block                               # label227:
	local.get	32
	local.get	28
	i32.store	0
	i32.const	1
	local.set	15
	local.get	33
	i32.const	1
	i32.and 
	local.set	2
	local.get	14
	i32.const	24
	i32.add 
	local.set	1
	local.get	14
	i32.const	16
	i32.add 
	local.set	26
	local.get	14
	i32.const	4
	i32.add 
	local.set	32
	i32.const	0
	local.set	33
	local.get	2
	br_if   	0                               # 0: up to label221
.LBB17_87:                              #   in Loop: Header=BB17_8 Depth=1
	end_loop
	end_block                               # label220:
	local.get	9
	local.get	23
	i32.const	2
	i32.shl 
	local.tee	15
	i32.add 
	local.get	14
	i32.load	8
	i32.store	0
	local.get	10
	local.get	15
	i32.add 
	local.get	14
	i32.load	4
	i32.store	0
	local.get	23
	i32.const	1
	i32.add 
	local.tee	23
	local.get	3
	i32.ne  
	br_if   	0                               # 0: up to label213
.LBB17_88:
	end_loop
	end_block                               # label211:
	local.get	13
	local.get	20
	i32.store	0
	local.get	19
	local.set	15
.LBB17_89:
	end_block                               # label210:
	local.get	14
	i32.const	32
	i32.add 
	global.set	__stack_pointer
	local.get	15
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.content_bytes_equal,"",@
	.type	content_bytes_equal,@function   # -- Begin function content_bytes_equal
content_bytes_equal:                    # @content_bytes_equal
	.functype	content_bytes_equal (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32
# %bb.0:
	local.get	0
	local.get	2
	i32.add 
	local.set	4
	local.get	0
	local.get	1
	i32.add 
	local.set	5
	i32.const	0
	local.set	0
.LBB18_1:                               # =>This Inner Loop Header: Depth=1
	block   	
	block   	
	block   	
	loop    	                                # label256:
	block   	
	local.get	0
	i32.const	8
	i32.add 
	local.tee	2
	local.get	3
	i32.le_u
	br_if   	0                               # 0: down to label257
# %bb.2:
	block   	
	local.get	3
	local.get	0
	i32.gt_u
	br_if   	0                               # 0: down to label258
# %bb.3:
	i32.const	1
	return
.LBB18_4:
	end_block                               # label258:
	local.get	3
	local.get	0
	i32.sub 
	local.set	1
	local.get	5
	local.get	0
	i32.add 
	local.set	2
	local.get	4
	local.get	0
	i32.add 
	local.set	0
	br      	2                               # 2: down to label255
.LBB18_5:                               #   in Loop: Header=BB18_1 Depth=1
	end_block                               # label257:
	local.get	4
	local.get	0
	i32.add 
	local.set	1
	local.get	5
	local.get	0
	i32.add 
	local.set	6
	local.get	2
	local.set	0
	local.get	6
	i64.load	0:p2align=0
	local.get	1
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label256
	br      	2                               # 2: down to label254
.LBB18_6:                               # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label255:
	loop    	                                # label259:
	local.get	2
	i32.load8_u	0
	local.get	0
	i32.load8_u	0
	i32.ne  
	br_if   	1                               # 1: down to label254
# %bb.7:                                #   in Loop: Header=BB18_6 Depth=1
	i32.const	1
	local.set	6
	local.get	0
	i32.const	1
	i32.add 
	local.set	0
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	local.get	1
	i32.const	-1
	i32.add 
	local.tee	1
	i32.eqz
	br_if   	2                               # 2: down to label253
	br      	0                               # 0: up to label259
.LBB18_8:
	end_loop
	end_block                               # label254:
	i32.const	0
	local.set	6
.LBB18_9:
	end_block                               # label253:
	local.get	6
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.decode_escaped_key,"",@
	.type	decode_escaped_key,@function    # -- Begin function decode_escaped_key
decode_escaped_key:                     # @decode_escaped_key
	.functype	decode_escaped_key (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-1
	local.set	4
	block   	
	local.get	1
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label260
# %bb.1:
	local.get	0
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label260
# %bb.2:
	i32.const	-1
	local.set	4
	local.get	0
	local.get	1
	i32.const	-1
	i32.add 
	local.tee	5
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label260
# %bb.3:
	i32.const	0
	local.set	4
	local.get	5
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label260
# %bb.4:
	local.get	3
	i32.const	65535
	local.get	3
	i32.const	65535
	i32.lt_u
	i32.select
	local.set	6
	local.get	0
	i32.const	3
	i32.add 
	local.set	7
	local.get	0
	i32.const	2
	i32.add 
	local.set	8
	local.get	2
	i32.const	1
	i32.add 
	local.set	9
	i32.const	0
	local.set	4
	i32.const	1
	local.set	1
.LBB19_5:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB19_86 Depth 2
	loop    	                                # label261:
	local.get	4
	local.set	10
	local.get	1
	i32.const	1
	i32.add 
	local.set	11
	block   	
	block   	
	local.get	0
	local.get	1
	i32.add 
	local.tee	12
	i32.load8_u	0
	local.tee	3
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label263
# %bb.6:                                #   in Loop: Header=BB19_5 Depth=1
	i32.const	-1
	local.set	4
	local.get	3
	i32.const	32
	i32.lt_u
	br_if   	3                               # 3: down to label260
# %bb.7:                                #   in Loop: Header=BB19_5 Depth=1
	local.get	3
	i32.const	34
	i32.eq  
	br_if   	3                               # 3: down to label260
# %bb.8:                                #   in Loop: Header=BB19_5 Depth=1
	block   	
	block   	
	block   	
	local.get	3
	i32.extend8_s
	i32.const	-1
	i32.gt_s
	br_if   	0                               # 0: down to label266
# %bb.9:                                #   in Loop: Header=BB19_5 Depth=1
	i32.const	0
	local.set	13
	block   	
	block   	
	local.get	3
	i32.const	62
	i32.add 
	i32.const	255
	i32.and 
	i32.const	30
	i32.lt_u
	local.tee	14
	i32.eqz
	br_if   	0                               # 0: down to label268
# %bb.10:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	2
	local.set	15
	br      	1                               # 1: down to label267
.LBB19_11:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label268:
	block   	
	local.get	3
	i32.const	240
	i32.and 
	i32.const	224
	i32.ne  
	br_if   	0                               # 0: down to label269
# %bb.12:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	3
	local.set	15
	i32.const	1
	local.set	13
	br      	1                               # 1: down to label267
.LBB19_13:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label269:
	i32.const	4
	local.set	15
	local.get	3
	i32.const	16
	i32.add 
	i32.const	255
	i32.and 
	i32.const	4
	i32.gt_u
	br_if   	7                               # 7: down to label260
.LBB19_14:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label267:
	i32.const	-1
	local.set	4
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	12
	local.get	5
	local.get	11
	i32.sub 
	i32.gt_u
	br_if   	6                               # 6: down to label260
# %bb.15:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	0
	local.get	11
	i32.add 
	local.tee	11
	i32.load8_u	0
	local.set	16
	block   	
	local.get	3
	i32.const	224
	i32.ne  
	br_if   	0                               # 0: down to label270
# %bb.16:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	16
	i32.const	255
	i32.and 
	i32.const	160
	i32.lt_u
	br_if   	7                               # 7: down to label260
.LBB19_17:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label270:
	block   	
	local.get	3
	i32.const	237
	i32.ne  
	br_if   	0                               # 0: down to label271
# %bb.18:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	16
	i32.const	255
	i32.and 
	i32.const	159
	i32.gt_u
	br_if   	7                               # 7: down to label260
.LBB19_19:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label271:
	block   	
	local.get	3
	i32.const	240
	i32.ne  
	br_if   	0                               # 0: down to label272
# %bb.20:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	16
	i32.const	255
	i32.and 
	i32.const	144
	i32.lt_u
	br_if   	7                               # 7: down to label260
.LBB19_21:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label272:
	block   	
	local.get	3
	i32.const	244
	i32.ne  
	br_if   	0                               # 0: down to label273
# %bb.22:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	16
	i32.const	255
	i32.and 
	i32.const	143
	i32.gt_u
	br_if   	7                               # 7: down to label260
.LBB19_23:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label273:
	local.get	11
	i32.load8_s	0
	i32.const	-64
	i32.ge_s
	br_if   	6                               # 6: down to label260
# %bb.24:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	12
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label265
# %bb.25:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	11
	i32.const	1
	i32.add 
	i32.load8_s	0
	i32.const	-65
	i32.gt_s
	br_if   	6                               # 6: down to label260
# %bb.26:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	12
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label265
# %bb.27:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	11
	i32.const	2
	i32.add 
	i32.load8_s	0
	i32.const	-65
	i32.gt_s
	br_if   	6                               # 6: down to label260
# %bb.28:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	15
	local.get	6
	local.get	10
	i32.sub 
	i32.le_u
	br_if   	2                               # 2: down to label264
	br      	6                               # 6: down to label260
.LBB19_29:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label266:
	local.get	6
	local.get	10
	i32.eq  
	br_if   	5                               # 5: down to label260
# %bb.30:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	2
	local.get	10
	i32.add 
	local.get	3
	i32.store8	0
	local.get	10
	i32.const	1
	i32.add 
	local.set	4
	local.get	11
	local.set	1
	br      	3                               # 3: down to label262
.LBB19_31:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label265:
	local.get	15
	local.get	6
	local.get	10
	i32.sub 
	i32.gt_u
	br_if   	4                               # 4: down to label260
.LBB19_32:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label264:
	local.get	2
	local.get	10
	i32.add 
	local.get	3
	i32.store8	0
	local.get	9
	local.get	10
	i32.add 
	local.get	11
	i32.load8_u	0
	i32.store8	0
	local.get	10
	i32.const	2
	i32.add 
	local.set	4
	local.get	15
	local.get	1
	i32.add 
	local.set	3
	block   	
	local.get	14
	i32.eqz
	br_if   	0                               # 0: down to label274
# %bb.33:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	3
	local.set	1
	br      	2                               # 2: down to label262
.LBB19_34:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label274:
	local.get	2
	local.get	4
	i32.add 
	local.get	8
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.store8	0
	local.get	10
	i32.const	3
	i32.add 
	local.set	4
	block   	
	local.get	13
	i32.eqz
	br_if   	0                               # 0: down to label275
# %bb.35:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	3
	local.set	1
	br      	2                               # 2: down to label262
.LBB19_36:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label275:
	local.get	2
	local.get	4
	i32.add 
	local.get	7
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.store8	0
	local.get	10
	i32.const	4
	i32.add 
	local.set	4
	local.get	3
	local.set	1
	br      	1                               # 1: down to label262
.LBB19_37:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label263:
	i32.const	-1
	local.set	4
	local.get	5
	local.get	11
	i32.le_u
	br_if   	2                               # 2: down to label260
# %bb.38:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	1
	i32.const	2
	i32.add 
	local.set	16
	i32.const	1
	local.set	15
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	-34
	i32.add 
	br_table 	{6, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 6, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 6, 9, 9, 9, 9, 9, 0, 9, 9, 9, 1, 9, 9, 9, 9, 9, 9, 9, 2, 9, 9, 9, 3, 9, 4, 5, 9} # 9: down to label260
                                        # 6: down to label276
                                        # 0: down to label282
                                        # 1: down to label281
                                        # 2: down to label280
                                        # 3: down to label279
                                        # 4: down to label278
                                        # 5: down to label277
.LBB19_39:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label282:
	i32.const	8
	local.set	11
	br      	5                               # 5: down to label276
.LBB19_40:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label281:
	i32.const	12
	local.set	11
	br      	4                               # 4: down to label276
.LBB19_41:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label280:
	i32.const	10
	local.set	11
	br      	3                               # 3: down to label276
.LBB19_42:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label279:
	i32.const	13
	local.set	11
	br      	2                               # 2: down to label276
.LBB19_43:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label278:
	i32.const	9
	local.set	11
	br      	1                               # 1: down to label276
.LBB19_44:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label277:
	local.get	5
	local.get	16
	i32.sub 
	i32.const	4
	i32.lt_u
	br_if   	3                               # 3: down to label260
# %bb.45:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	-48
	local.set	17
	i32.const	-48
	local.set	13
	block   	
	local.get	0
	local.get	16
	i32.add 
	local.tee	3
	i32.load8_u	0
	local.tee	11
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label283
# %bb.46:                               #   in Loop: Header=BB19_5 Depth=1
	block   	
	local.get	11
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label284
# %bb.47:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	-87
	local.set	13
	br      	1                               # 1: down to label283
.LBB19_48:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label284:
	local.get	11
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.gt_u
	br_if   	4                               # 4: down to label260
# %bb.49:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	-55
	local.set	13
.LBB19_50:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label283:
	block   	
	local.get	3
	i32.load8_u	1
	local.tee	16
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label285
# %bb.51:                               #   in Loop: Header=BB19_5 Depth=1
	block   	
	local.get	16
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label286
# %bb.52:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	-87
	local.set	17
	br      	1                               # 1: down to label285
.LBB19_53:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label286:
	local.get	16
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.gt_u
	br_if   	4                               # 4: down to label260
# %bb.54:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	-55
	local.set	17
.LBB19_55:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label285:
	i32.const	-48
	local.set	18
	i32.const	-48
	local.set	19
	block   	
	local.get	3
	i32.load8_u	2
	local.tee	14
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label287
# %bb.56:                               #   in Loop: Header=BB19_5 Depth=1
	block   	
	local.get	14
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label288
# %bb.57:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	-87
	local.set	19
	br      	1                               # 1: down to label287
.LBB19_58:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label288:
	local.get	14
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.gt_u
	br_if   	4                               # 4: down to label260
# %bb.59:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	-55
	local.set	19
.LBB19_60:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label287:
	block   	
	local.get	3
	i32.load8_u	3
	local.tee	3
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label289
# %bb.61:                               #   in Loop: Header=BB19_5 Depth=1
	block   	
	local.get	3
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label290
# %bb.62:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	-87
	local.set	18
	br      	1                               # 1: down to label289
.LBB19_63:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label290:
	local.get	3
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.gt_u
	br_if   	4                               # 4: down to label260
# %bb.64:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	-55
	local.set	18
.LBB19_65:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label289:
	i32.const	-1
	local.set	4
	local.get	18
	local.get	3
	i32.add 
	local.get	17
	local.get	16
	i32.add 
	i32.const	4
	i32.shl 
	local.get	13
	local.get	11
	i32.add 
	i32.const	8
	i32.shl 
	i32.or  
	local.get	19
	local.get	14
	i32.add 
	i32.or  
	i32.const	4
	i32.shl 
	i32.or  
	local.tee	3
	i32.const	-1
	i32.eq  
	br_if   	3                               # 3: down to label260
# %bb.66:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	1
	i32.const	6
	i32.add 
	local.set	16
	i32.const	65533
	local.set	11
	block   	
	local.get	3
	i32.const	-1024
	i32.and 
	local.tee	4
	i32.const	56320
	i32.ne  
	br_if   	0                               # 0: down to label291
# %bb.67:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	3
	local.set	15
	br      	1                               # 1: down to label276
.LBB19_68:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label291:
	block   	
	local.get	4
	i32.const	55296
	i32.ne  
	br_if   	0                               # 0: down to label292
# %bb.69:                               #   in Loop: Header=BB19_5 Depth=1
	block   	
	local.get	5
	local.get	16
	i32.sub 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label293
# %bb.70:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	3
	local.set	15
	br      	2                               # 2: down to label276
.LBB19_71:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label293:
	block   	
	local.get	0
	local.get	16
	i32.add 
	local.tee	4
	i32.load8_u	0
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label294
# %bb.72:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	3
	local.set	15
	br      	2                               # 2: down to label276
.LBB19_73:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label294:
	block   	
	local.get	12
	i32.const	7
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.eq  
	br_if   	0                               # 0: down to label295
# %bb.74:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	3
	local.set	15
	br      	2                               # 2: down to label276
.LBB19_75:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label295:
	i32.const	3
	local.set	15
	local.get	4
	i32.const	2
	i32.add 
	call	key_hex4
	local.tee	4
	i32.const	-1024
	i32.and 
	i32.const	56320
	i32.ne  
	br_if   	1                               # 1: down to label276
# %bb.76:                               #   in Loop: Header=BB19_5 Depth=1
	local.get	1
	i32.const	12
	i32.add 
	local.set	16
	local.get	3
	i32.const	10
	i32.shl 
	local.get	4
	i32.add 
	i32.const	-56613888
	i32.add 
	local.set	11
	i32.const	4
	local.set	15
	br      	1                               # 1: down to label276
.LBB19_77:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label292:
	block   	
	local.get	3
	i32.const	128
	i32.lt_u
	br_if   	0                               # 0: down to label296
# %bb.78:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	2
	local.set	15
	local.get	3
	i32.const	2048
	i32.lt_u
	br_if   	0                               # 0: down to label296
# %bb.79:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	3
	i32.const	4
	local.get	3
	i32.const	65536
	i32.lt_u
	i32.select
	local.set	15
.LBB19_80:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label296:
	local.get	3
	local.set	11
.LBB19_81:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label276:
	i32.const	-1
	local.set	4
	local.get	15
	local.get	6
	local.get	10
	i32.sub 
	i32.gt_u
	br_if   	2                               # 2: down to label260
# %bb.82:                               #   in Loop: Header=BB19_5 Depth=1
	i32.const	192
	local.set	4
	block   	
	block   	
	block   	
	block   	
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	3
	br_table 	{0, 2, 1}               # 2: down to label298
                                        # 1: down to label299
.LBB19_83:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label300:
	local.get	2
	local.get	10
	i32.add 
	local.get	11
	i32.store8	0
	local.get	10
	i32.const	1
	i32.add 
	local.set	4
	br      	2                               # 2: down to label297
.LBB19_84:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label299:
	i32.const	224
	i32.const	240
	local.get	15
	i32.const	3
	i32.eq  
	i32.select
	local.set	4
.LBB19_85:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label298:
	local.get	2
	local.get	10
	i32.add 
	local.get	4
	local.get	11
	local.get	15
	i32.const	6
	i32.mul 
	local.tee	1
	i32.const	-6
	i32.add 
	i32.shr_u
	i32.or  
	i32.store8	0
	local.get	10
	i32.const	1
	i32.add 
	local.set	4
	local.get	1
	i32.const	-12
	i32.add 
	local.set	1
.LBB19_86:                              #   Parent Loop BB19_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label301:
	local.get	2
	local.get	4
	i32.add 
	local.get	11
	local.get	1
	i32.shr_u
	i32.const	63
	i32.and 
	i32.const	128
	i32.or  
	i32.store8	0
	local.get	1
	i32.const	-6
	i32.add 
	local.set	1
	local.get	4
	i32.const	1
	i32.add 
	local.set	4
	local.get	3
	i32.const	-1
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label301
.LBB19_87:                              #   in Loop: Header=BB19_5 Depth=1
	end_loop
	end_block                               # label297:
	local.get	16
	local.set	1
.LBB19_88:                              #   in Loop: Header=BB19_5 Depth=1
	end_block                               # label262:
	local.get	1
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: up to label261
.LBB19_89:
	end_loop
	end_block                               # label260:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.hash_content_xxh32,"",@
	.type	hash_content_xxh32,@function    # -- Begin function hash_content_xxh32
hash_content_xxh32:                     # @hash_content_xxh32
	.functype	hash_content_xxh32 (i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32
# %bb.0:
	local.get	0
	local.get	1
	i32.add 
	local.set	3
	block   	
	block   	
	local.get	1
	i32.const	16
	i32.lt_u
	br_if   	0                               # 0: down to label303
# %bb.1:
	local.get	2
	i32.const	1640531535
	i32.add 
	local.set	4
	local.get	2
	i32.const	-2048144777
	i32.add 
	local.set	5
	local.get	2
	i32.const	606290984
	i32.add 
	local.set	6
	local.get	3
	i32.const	-16
	i32.add 
	local.set	7
.LBB20_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label304:
	local.get	0
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.get	6
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	6
	local.get	0
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.get	4
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	4
	local.get	0
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.get	2
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	2
	local.get	0
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.get	5
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	5
	local.get	0
	i32.const	16
	i32.add 
	local.tee	0
	local.get	7
	i32.le_u
	br_if   	0                               # 0: up to label304
# %bb.3:
	end_loop
	local.get	5
	i32.const	7
	i32.rotl
	local.get	6
	i32.const	1
	i32.rotl
	i32.add 
	local.get	2
	i32.const	12
	i32.rotl
	i32.add 
	local.get	4
	i32.const	18
	i32.rotl
	i32.add 
	local.set	2
	br      	1                               # 1: down to label302
.LBB20_4:
	end_block                               # label303:
	local.get	2
	i32.const	374761393
	i32.add 
	local.set	2
.LBB20_5:
	end_block                               # label302:
	local.get	2
	local.get	1
	i32.add 
	local.set	2
	block   	
	block   	
	local.get	0
	i32.const	4
	i32.add 
	local.get	3
	i32.le_u
	br_if   	0                               # 0: down to label306
# %bb.6:
	local.get	0
	local.set	4
	br      	1                               # 1: down to label305
.LBB20_7:
	end_block                               # label306:
.LBB20_8:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label307:
	local.get	0
	i32.load	0:p2align=0
	i32.const	-1028477379
	i32.mul 
	local.get	2
	i32.add 
	i32.const	17
	i32.rotl
	i32.const	668265263
	i32.mul 
	local.set	2
	local.get	0
	i32.const	8
	i32.add 
	local.set	5
	local.get	0
	i32.const	4
	i32.add 
	local.tee	4
	local.set	0
	local.get	5
	local.get	3
	i32.le_u
	br_if   	0                               # 0: up to label307
.LBB20_9:
	end_loop
	end_block                               # label305:
	block   	
	local.get	4
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label308
# %bb.10:
	local.get	4
	i32.const	1
	i32.add 
	local.set	0
	block   	
	local.get	3
	local.get	4
	i32.sub 
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label309
# %bb.11:
	local.get	4
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.get	2
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	2
	local.get	0
	local.set	4
.LBB20_12:
	end_block                               # label309:
	local.get	3
	local.get	0
	i32.eq  
	br_if   	0                               # 0: down to label308
# %bb.13:
.LBB20_14:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label310:
	local.get	4
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.get	4
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.get	2
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	2
	local.get	4
	i32.const	2
	i32.add 
	local.tee	4
	local.get	3
	i32.ne  
	br_if   	0                               # 0: up to label310
.LBB20_15:
	end_loop
	end_block                               # label308:
	local.get	2
	i32.const	15
	i32.shr_u
	local.get	2
	i32.xor 
	i32.const	-2048144777
	i32.mul 
	local.tee	0
	i32.const	13
	i32.shr_u
	local.get	0
	i32.xor 
	i32.const	-1028477379
	i32.mul 
	local.tee	0
	i32.const	16
	i32.shr_u
	local.get	0
	i32.xor 
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.copy_valid_utf8,"",@
	.type	copy_valid_utf8,@function       # -- Begin function copy_valid_utf8
copy_valid_utf8:                        # @copy_valid_utf8
	.functype	copy_valid_utf8 (i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	block   	
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label312
# %bb.1:
	i32.const	0
	local.set	3
.LBB21_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label313:
	local.get	0
	local.get	3
	i32.add 
	local.get	1
	local.get	3
	i32.add 
	i32.load8_s	0
	local.tee	4
	i32.store8	0
	local.get	3
	i32.const	1
	i32.add 
	local.set	5
	block   	
	block   	
	local.get	4
	i32.const	-1
	i32.le_s
	br_if   	0                               # 0: down to label315
# %bb.3:                                #   in Loop: Header=BB21_2 Depth=1
	local.get	5
	local.set	3
	br      	1                               # 1: down to label314
.LBB21_4:                               #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label315:
	i32.const	0
	local.set	6
	block   	
	block   	
	local.get	4
	i32.const	62
	i32.add 
	i32.const	255
	i32.and 
	i32.const	30
	i32.lt_u
	local.tee	7
	i32.eqz
	br_if   	0                               # 0: down to label317
# %bb.5:                                #   in Loop: Header=BB21_2 Depth=1
	i32.const	1
	local.set	8
	i32.const	0
	local.set	9
	br      	1                               # 1: down to label316
.LBB21_6:                               #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label317:
	block   	
	local.get	4
	i32.const	-16
	i32.and 
	i32.const	-32
	i32.ne  
	br_if   	0                               # 0: down to label318
# %bb.7:                                #   in Loop: Header=BB21_2 Depth=1
	i32.const	2
	local.set	8
	i32.const	1
	local.set	9
	br      	1                               # 1: down to label316
.LBB21_8:                               #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label318:
	i32.const	0
	local.set	9
	block   	
	local.get	4
	i32.const	16
	i32.add 
	i32.const	255
	i32.and 
	i32.const	4
	i32.le_u
	br_if   	0                               # 0: down to label319
# %bb.9:
	i32.const	0
	return
.LBB21_10:                              #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label319:
	i32.const	3
	local.set	8
.LBB21_11:                              #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label316:
	local.get	8
	local.get	2
	local.get	5
	i32.sub 
	i32.gt_u
	br_if   	3                               # 3: down to label311
# %bb.12:                               #   in Loop: Header=BB21_2 Depth=1
	local.get	1
	local.get	5
	i32.add 
	local.tee	10
	i32.load8_u	0
	local.set	11
	block   	
	local.get	4
	i32.const	-32
	i32.ne  
	br_if   	0                               # 0: down to label320
# %bb.13:                               #   in Loop: Header=BB21_2 Depth=1
	local.get	11
	i32.const	255
	i32.and 
	i32.const	160
	i32.lt_u
	br_if   	4                               # 4: down to label311
.LBB21_14:                              #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label320:
	block   	
	local.get	4
	i32.const	-19
	i32.ne  
	br_if   	0                               # 0: down to label321
# %bb.15:                               #   in Loop: Header=BB21_2 Depth=1
	local.get	11
	i32.const	255
	i32.and 
	i32.const	159
	i32.gt_u
	br_if   	4                               # 4: down to label311
.LBB21_16:                              #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label321:
	block   	
	local.get	4
	i32.const	-16
	i32.ne  
	br_if   	0                               # 0: down to label322
# %bb.17:                               #   in Loop: Header=BB21_2 Depth=1
	local.get	11
	i32.const	255
	i32.and 
	i32.const	144
	i32.lt_u
	br_if   	4                               # 4: down to label311
.LBB21_18:                              #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label322:
	block   	
	local.get	4
	i32.const	-12
	i32.ne  
	br_if   	0                               # 0: down to label323
# %bb.19:                               #   in Loop: Header=BB21_2 Depth=1
	local.get	11
	i32.const	255
	i32.and 
	i32.const	143
	i32.gt_u
	br_if   	4                               # 4: down to label311
.LBB21_20:                              #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label323:
	local.get	10
	i32.load8_s	0
	i32.const	-64
	i32.ge_s
	br_if   	3                               # 3: down to label311
# %bb.21:                               #   in Loop: Header=BB21_2 Depth=1
	block   	
	block   	
	local.get	7
	br_if   	0                               # 0: down to label325
# %bb.22:                               #   in Loop: Header=BB21_2 Depth=1
	local.get	10
	i32.load8_s	1
	i32.const	-65
	i32.gt_s
	br_if   	5                               # 5: down to label311
# %bb.23:                               #   in Loop: Header=BB21_2 Depth=1
	block   	
	local.get	9
	br_if   	0                               # 0: down to label326
# %bb.24:                               #   in Loop: Header=BB21_2 Depth=1
	local.get	10
	i32.load8_s	2
	i32.const	-64
	i32.ge_s
	br_if   	6                               # 6: down to label311
.LBB21_25:                              #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label326:
	local.get	0
	local.get	5
	i32.add 
	local.get	10
	i32.load8_u	0
	i32.store8	0
	local.get	7
	br_if   	1                               # 1: down to label324
# %bb.26:                               #   in Loop: Header=BB21_2 Depth=1
	local.get	0
	local.get	3
	i32.const	2
	i32.add 
	local.tee	4
	i32.add 
	local.get	1
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.store8	0
	local.get	9
	br_if   	1                               # 1: down to label324
# %bb.27:                               #   in Loop: Header=BB21_2 Depth=1
	local.get	0
	local.get	3
	i32.const	3
	i32.add 
	local.tee	3
	i32.add 
	local.get	1
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.store8	0
	br      	1                               # 1: down to label324
.LBB21_28:                              #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label325:
	local.get	0
	local.get	5
	i32.add 
	local.get	10
	i32.load8_u	0
	i32.store8	0
.LBB21_29:                              #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label324:
	local.get	8
	local.get	5
	i32.add 
	local.set	3
.LBB21_30:                              #   in Loop: Header=BB21_2 Depth=1
	end_block                               # label314:
	local.get	3
	local.get	2
	i32.lt_u
	br_if   	0                               # 0: up to label313
.LBB21_31:
	end_loop
	end_block                               # label312:
	i32.const	1
	local.set	6
.LBB21_32:
	end_block                               # label311:
	local.get	6
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_lookup_index,"",@
	.globl	encode_term_lookup_index        # -- Begin function encode_term_lookup_index
	.type	encode_term_lookup_index,@function
encode_term_lookup_index:               # @encode_term_lookup_index
	.functype	encode_term_lookup_index (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i64, i64, i32, i32, i32, i64, i32, i32, i32, i64, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-1
	local.set	17
	block   	
	local.get	0
	i32x4.splat
	local.get	2
	i32x4.replace_lane	1
	local.get	3
	i32x4.replace_lane	2
	local.get	4
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	18
	i32x4.eq
	local.get	6
	i32x4.splat
	local.get	7
	i32x4.replace_lane	1
	local.get	8
	i32x4.replace_lane	2
	local.get	9
	i32x4.replace_lane	3
	local.get	18
	i32x4.eq
	i8x16.shuffle	0, 1, 4, 5, 8, 9, 12, 13, 16, 17, 20, 21, 24, 25, 28, 29
	local.tee	19
	local.get	11
	i32x4.splat
	local.get	13
	i32x4.replace_lane	1
	local.get	14
	i32x4.replace_lane	2
	local.get	15
	i32x4.replace_lane	3
	local.get	18
	i32x4.eq
	local.get	18
	i8x16.shuffle	0, 1, 4, 5, 8, 9, 12, 13, 0, 1, 0, 1, 0, 1, 0, 1
	v128.or
	local.get	19
	i8x16.shuffle	0, 1, 2, 3, 4, 5, 6, 7, 24, 25, 26, 27, 28, 29, 30, 31
	v128.any_true
	br_if   	0                               # 0: down to label327
# %bb.1:
	local.get	10
	i32.const	-65535
	i32.add 
	i32.const	-65534
	i32.lt_u
	br_if   	0                               # 0: down to label327
# %bb.2:
	local.get	5
	i32.const	-65535
	i32.add 
	i32.const	-65534
	i32.lt_u
	br_if   	0                               # 0: down to label327
# %bb.3:
	local.get	16
	local.get	10
	i32.lt_u
	br_if   	0                               # 0: down to label327
# %bb.4:
	i32.const	-1
	local.set	17
	local.get	16
	local.get	16
	i32.const	-1
	i32.add 
	local.tee	20
	i32.and 
	br_if   	0                               # 0: down to label327
# %bb.5:
	i32.const	0
	local.set	21
	block   	
	local.get	16
	i32.const	1
	i32.shl 
	local.tee	16
	i32.eqz
	br_if   	0                               # 0: down to label328
# %bb.6:
	local.get	15
	i32.const	0
	local.get	16
	memory.fill	0
.LBB22_7:
	end_block                               # label328:
	i32.const	0
	local.set	22
	i32.const	0
	local.set	23
	i32.const	-1
	local.set	24
	i32.const	0
	local.set	16
	i32.const	0
	local.set	25
.LBB22_8:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB22_16 Depth 2
	loop    	                                # label329:
	local.get	23
	local.set	26
	i32.const	-2
	local.set	17
	local.get	6
	local.get	25
	i32.const	2
	i32.shl 
	local.tee	23
	i32.add 
	i32.load	0
	local.get	5
	i32.ge_u
	br_if   	1                               # 1: down to label327
# %bb.9:                                #   in Loop: Header=BB22_8 Depth=1
	local.get	8
	local.get	25
	i32.add 
	i32.load8_u	0
	local.tee	27
	i32.const	1
	i32.gt_u
	br_if   	1                               # 1: down to label327
# %bb.10:                               #   in Loop: Header=BB22_8 Depth=1
	block   	
	local.get	27
	br_if   	0                               # 0: down to label330
# %bb.11:                               #   in Loop: Header=BB22_8 Depth=1
	local.get	7
	local.get	23
	i32.add 
	i32.load	0
	local.get	5
	i32.ge_u
	br_if   	2                               # 2: down to label327
.LBB22_12:                              #   in Loop: Header=BB22_8 Depth=1
	end_block                               # label330:
	block   	
	block   	
	local.get	9
	local.get	23
	i32.add 
	i32.load	0
	local.tee	23
	i32.const	-1
	i32.gt_s
	br_if   	0                               # 0: down to label332
# %bb.13:                               #   in Loop: Header=BB22_8 Depth=1
	local.get	14
	local.get	25
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	65535
	i32.store16	0
	br      	1                               # 1: down to label331
.LBB22_14:                              #   in Loop: Header=BB22_8 Depth=1
	end_block                               # label332:
	block   	
	local.get	23
	local.get	24
	i32.eq  
	br_if   	0                               # 0: down to label333
# %bb.15:                               #   in Loop: Header=BB22_8 Depth=1
	local.get	15
	local.get	23
	i32.const	255
	i32.and 
	i32.const	-2128831035
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	23
	i32.const	8
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	23
	i32.const	16
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	23
	i32.const	24
	i32.shr_u
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	20
	i32.and 
	local.tee	24
	i32.const	1
	i32.shl 
	i32.add 
	local.set	16
.LBB22_16:                              #   Parent Loop BB22_8 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label334:
	block   	
	local.get	16
	i32.load16_u	0
	local.tee	17
	br_if   	0                               # 0: down to label335
# %bb.17:                               #   in Loop: Header=BB22_8 Depth=1
	block   	
	local.get	21
	i32.const	65534
	i32.le_u
	br_if   	0                               # 0: down to label336
# %bb.18:
	i32.const	-3
	return
.LBB22_19:                              #   in Loop: Header=BB22_8 Depth=1
	end_block                               # label336:
	local.get	16
	local.get	21
	i32.const	1
	i32.add 
	local.tee	17
	i32.store16	0
	local.get	13
	local.get	21
	i32.const	2
	i32.shl 
	i32.add 
	local.get	23
	i32.store	0
	local.get	21
	local.set	16
	local.get	23
	local.set	24
	local.get	17
	local.set	21
	br      	2                               # 2: down to label333
.LBB22_20:                              #   in Loop: Header=BB22_16 Depth=2
	end_block                               # label335:
	block   	
	local.get	13
	local.get	17
	i32.const	65535
	i32.and 
	i32.const	-1
	i32.add 
	local.tee	16
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.get	23
	i32.eq  
	br_if   	0                               # 0: down to label337
# %bb.21:                               #   in Loop: Header=BB22_16 Depth=2
	local.get	15
	local.get	24
	i32.const	1
	i32.add 
	local.get	20
	i32.and 
	local.tee	24
	i32.const	1
	i32.shl 
	i32.add 
	local.set	16
	br      	1                               # 1: up to label334
.LBB22_22:                              #   in Loop: Header=BB22_8 Depth=1
	end_block                               # label337:
	end_loop
	local.get	23
	local.set	24
.LBB22_23:                              #   in Loop: Header=BB22_8 Depth=1
	end_block                               # label333:
	local.get	14
	local.get	25
	i32.const	1
	i32.shl 
	i32.add 
	local.get	16
	i32.store16	0
	local.get	22
	i32.const	1
	i32.add 
	local.set	22
.LBB22_24:                              #   in Loop: Header=BB22_8 Depth=1
	end_block                               # label331:
	local.get	26
	local.get	27
	i32.const	1
	i32.xor 
	local.tee	27
	i32.add 
	local.set	23
	local.get	25
	i32.const	1
	i32.add 
	local.tee	25
	local.get	10
	i32.ne  
	br_if   	0                               # 0: up to label329
# %bb.25:
	end_loop
	local.get	5
	i32.const	3
	i32.add 
	i32.const	2
	i32.shr_u
	local.set	17
	i32.const	1
	local.set	25
.LBB22_26:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label338:
	local.get	25
	local.tee	16
	i32.const	1
	i32.shl 
	local.set	25
	local.get	16
	local.get	17
	i32.lt_u
	br_if   	0                               # 0: up to label338
# %bb.27:
	end_loop
	local.get	21
	i32.const	3
	i32.add 
	i32.const	2
	i32.shr_u
	local.set	17
	i32.const	1
	local.set	15
.LBB22_28:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label339:
	local.get	15
	local.tee	24
	i32.const	1
	i32.shl 
	local.set	15
	local.get	24
	local.get	17
	i32.lt_u
	br_if   	0                               # 0: up to label339
# %bb.29:
	end_loop
	i32.const	-4
	local.set	17
	local.get	1
	i64.extend_i32_u
	i64.const	3
	i64.add 
	local.tee	28
	i64.const	8589934588
	i64.and 
	local.tee	29
	local.get	10
	i32.const	3
	i32.mul 
	local.get	5
	i32.add 
	i32.const	1
	i32.shl 
	i32.const	3
	i32.add 
	local.tee	30
	i32.const	2147483644
	i32.and 
	local.tee	31
	i64.extend_i32_u
	i64.add 
	local.get	21
	i32.const	2
	i32.shl 
	local.tee	32
	i64.extend_i32_u
	i64.add 
	i64.const	32
	i64.add 
	local.tee	33
	local.get	5
	i32.const	1
	i32.add 
	local.tee	34
	i32.const	1
	i32.shl 
	local.tee	35
	local.get	5
	i32.add 
	local.get	10
	i32.add 
	local.get	23
	i32.add 
	local.get	22
	i32.add 
	local.get	21
	i32.add 
	local.get	21
	i32.const	1
	i32.add 
	local.tee	36
	i32.add 
	local.get	16
	i32.add 
	local.get	24
	i32.add 
	i32.const	1
	i32.shl 
	i32.const	3
	i32.add 
	i32.const	-4
	i32.and 
	i32.const	32
	i32.add 
	local.tee	9
	i64.extend_i32_u
	i64.add 
	i64.const	16
	i64.add 
	local.tee	37
	local.get	12
	i64.extend_i32_u
	i64.gt_u
	br_if   	0                               # 0: down to label327
# %bb.30:
	local.get	37
	i64.const	2147483647
	i64.gt_u
	br_if   	0                               # 0: down to label327
# %bb.31:
	i32.const	0
	local.set	20
	block   	
	local.get	37
	i32.wrap_i64
	local.tee	38
	i32.eqz
	br_if   	0                               # 0: down to label340
# %bb.32:
	local.get	11
	i32.const	0
	local.get	38
	memory.fill	0
.LBB22_33:
	end_block                               # label340:
	local.get	11
	local.get	23
	i32.store	36
	local.get	11
	local.get	21
	i32.store	32
	local.get	11
	i32.const	7
	i32.store	28
	local.get	11
	local.get	1
	i32.store	24
	local.get	11
	local.get	5
	i32.store	20
	local.get	11
	local.get	10
	i32.store	16
	local.get	11
	local.get	9
	i32.store	12
	local.get	11
	local.get	33
	i32.wrap_i64
	local.tee	39
	i32.store	8
	local.get	11
	i64.const	30992321613
	i64.store	0:p2align=2
	block   	
	local.get	1
	i32.eqz
	br_if   	0                               # 0: down to label341
# %bb.34:
	local.get	11
	i32.const	48
	i32.add 
	local.get	0
	local.get	1
	memory.copy	0, 0
.LBB22_35:
	end_block                               # label341:
	local.get	10
	i32.const	1
	i32.shl 
	local.tee	40
	local.get	29
	i32.wrap_i64
	local.tee	41
	i32.const	32
	i32.add 
	local.tee	9
	local.get	5
	i32.const	1
	i32.shl 
	local.tee	42
	i32.add 
	i32.add 
	local.tee	12
	local.get	40
	i32.add 
	local.set	17
	local.get	11
	i32.const	16
	i32.add 
	local.set	43
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label342
# %bb.36:
	local.get	43
	local.get	40
	local.get	17
	i32.add 
	i32.const	3
	i32.add 
	i32.const	-4
	i32.and 
	i32.add 
	local.get	13
	local.get	32
	memory.copy	0, 0
.LBB22_37:
	end_block                               # label342:
	local.get	43
	local.get	9
	i32.add 
	local.set	0
	local.get	43
	local.get	12
	i32.add 
	local.set	44
	local.get	43
	local.get	17
	i32.add 
	local.set	45
	local.get	5
	local.set	12
.LBB22_38:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label343:
	i32.const	-5
	local.set	17
	local.get	3
	i32.load	0
	local.get	20
	i32.ne  
	br_if   	1                               # 1: down to label327
# %bb.39:                               #   in Loop: Header=BB22_38 Depth=1
	local.get	2
	i32.load16_u	0
	local.tee	9
	i32.const	1
	i32.add 
	i32.const	65535
	i32.and 
	i32.const	2
	i32.lt_u
	br_if   	1                               # 1: down to label327
# %bb.40:                               #   in Loop: Header=BB22_38 Depth=1
	local.get	1
	local.get	20
	i32.lt_u
	br_if   	1                               # 1: down to label327
# %bb.41:                               #   in Loop: Header=BB22_38 Depth=1
	local.get	1
	local.get	20
	i32.sub 
	local.get	9
	i32.lt_u
	br_if   	1                               # 1: down to label327
# %bb.42:                               #   in Loop: Header=BB22_38 Depth=1
	local.get	0
	local.get	9
	i32.store16	0
	local.get	3
	i32.const	4
	i32.add 
	local.set	3
	local.get	2
	i32.const	2
	i32.add 
	local.set	2
	local.get	0
	i32.const	2
	i32.add 
	local.set	0
	local.get	20
	local.get	9
	i32.add 
	local.set	20
	local.get	12
	i32.const	-1
	i32.add 
	local.tee	12
	br_if   	0                               # 0: up to label343
# %bb.43:
	end_loop
	local.get	20
	local.get	1
	i32.ne  
	br_if   	0                               # 0: down to label327
# %bb.44:
	local.get	43
	local.get	39
	i32.add 
	local.tee	1
	i32.const	7
	i32.store	28
	local.get	1
	local.get	22
	i32.store	24
	local.get	1
	local.get	21
	i32.store	20
	local.get	1
	local.get	23
	i32.store	16
	local.get	1
	local.get	24
	i32.store	12
	local.get	1
	local.get	16
	i32.store	8
	local.get	1
	local.get	5
	i32.store	4
	local.get	1
	local.get	10
	i32.store	0
	local.get	1
	i32.const	32
	i32.add 
	local.set	9
	block   	
	local.get	25
	i32.eqz
	br_if   	0                               # 0: down to label344
# %bb.45:
	local.get	9
	i32.const	255
	local.get	25
	memory.fill	0
.LBB22_46:
	end_block                               # label344:
	local.get	1
	local.get	25
	i32.const	32
	i32.add 
	local.tee	17
	i32.add 
	local.set	43
	block   	
	local.get	42
	i32.eqz
	br_if   	0                               # 0: down to label345
# %bb.47:
	local.get	43
	i32.const	255
	local.get	42
	memory.fill	0
.LBB22_48:
	end_block                               # label345:
	local.get	1
	local.get	17
	local.get	42
	i32.add 
	local.tee	39
	local.get	35
	i32.add 
	local.tee	46
	local.get	40
	i32.add 
	local.tee	47
	local.get	35
	i32.add 
	local.tee	48
	local.get	23
	i32.const	1
	i32.shl 
	i32.add 
	i32.add 
	local.set	22
	block   	
	local.get	15
	i32.eqz
	br_if   	0                               # 0: down to label346
# %bb.49:
	local.get	22
	i32.const	255
	local.get	15
	memory.fill	0
.LBB22_50:
	end_block                               # label346:
	local.get	22
	local.get	15
	i32.add 
	local.set	20
	block   	
	local.get	21
	i32.const	1
	i32.shl 
	local.tee	12
	i32.eqz
	br_if   	0                               # 0: down to label347
# %bb.51:
	local.get	20
	i32.const	255
	local.get	12
	memory.fill	0
.LBB22_52:
	end_block                               # label347:
	local.get	5
	i32.const	1
	i32.and 
	local.set	35
	local.get	16
	i32.const	-1
	i32.add 
	local.set	3
	i32.const	0
	local.set	17
	block   	
	local.get	5
	i32.const	1
	i32.eq  
	br_if   	0                               # 0: down to label348
# %bb.53:
	local.get	31
	local.get	41
	i32.add 
	local.get	11
	i32.add 
	local.get	32
	i32.add 
	local.get	16
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	82
	i32.add 
	local.set	25
	i32.const	0
	local.get	5
	i32.const	65534
	i32.and 
	i32.sub 
	local.set	0
	i32.const	1
	local.set	17
	local.get	4
	local.set	15
.LBB22_54:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label349:
	local.get	25
	i32.const	-2
	i32.add 
	local.get	9
	local.get	15
	i32.load	0
	local.get	3
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	2
	i32.load16_u	0
	i32.store16	0
	local.get	2
	local.get	17
	i32.const	-1
	i32.add 
	i32.store16	0
	local.get	25
	local.get	9
	local.get	15
	i32.const	4
	i32.add 
	i32.load	0
	local.get	3
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	2
	i32.load16_u	0
	i32.store16	0
	local.get	2
	local.get	17
	i32.store16	0
	local.get	25
	i32.const	4
	i32.add 
	local.set	25
	local.get	15
	i32.const	8
	i32.add 
	local.set	15
	local.get	0
	local.get	17
	i32.const	2
	i32.add 
	local.tee	17
	i32.add 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: up to label349
# %bb.55:
	end_loop
	local.get	17
	i32.const	-1
	i32.add 
	local.set	17
.LBB22_56:
	end_block                               # label348:
	block   	
	local.get	35
	i32.eqz
	br_if   	0                               # 0: down to label350
# %bb.57:
	local.get	43
	local.get	17
	i32.const	1
	i32.shl 
	i32.add 
	local.get	9
	local.get	4
	local.get	17
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.get	3
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	25
	i32.load16_u	0
	i32.store16	0
	local.get	25
	local.get	17
	i32.store16	0
.LBB22_58:
	end_block                               # label350:
	local.get	20
	local.get	12
	i32.add 
	local.set	0
	local.get	36
	i32.const	1
	i32.shl 
	local.set	9
	local.get	1
	local.get	39
	i32.add 
	local.set	43
	local.get	1
	local.get	47
	i32.add 
	local.set	35
	block   	
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label351
# %bb.59:
	local.get	24
	i32.const	-1
	i32.add 
	local.set	15
	i32.const	0
	local.set	25
.LBB22_60:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label352:
	local.get	20
	local.get	22
	local.get	13
	i32.load	0
	local.tee	17
	i32.const	255
	i32.and 
	i32.const	-2128831035
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	17
	i32.const	8
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	17
	i32.const	16
	i32.shr_u
	i32.const	255
	i32.and 
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	17
	i32.const	24
	i32.shr_u
	i32.xor 
	i32.const	16777619
	i32.mul 
	local.get	15
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	17
	i32.load16_u	0
	i32.store16	0
	local.get	17
	local.get	25
	i32.store16	0
	local.get	20
	i32.const	2
	i32.add 
	local.set	20
	local.get	13
	i32.const	4
	i32.add 
	local.set	13
	local.get	21
	local.get	25
	i32.const	1
	i32.add 
	local.tee	25
	i32.ne  
	br_if   	0                               # 0: up to label352
.LBB22_61:
	end_loop
	end_block                               # label351:
	local.get	1
	local.get	46
	i32.add 
	local.set	2
	local.get	1
	local.get	48
	i32.add 
	local.set	4
	local.get	0
	local.get	9
	i32.add 
	local.set	1
	local.get	0
	i32.const	2
	i32.add 
	local.set	12
	local.get	35
	i32.const	2
	i32.add 
	local.set	3
	local.get	43
	i32.const	2
	i32.add 
	local.set	13
	local.get	11
	local.get	41
	local.get	42
	i32.add 
	i32.add 
	local.set	22
	i32.const	0
	local.set	17
	local.get	10
	local.set	15
.LBB22_62:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label353:
	local.get	22
	local.get	17
	i32.add 
	i32.const	48
	i32.add 
	local.tee	20
	local.get	6
	i32.load	0
	i32.store16	0
	i32.const	65535
	local.set	25
	block   	
	local.get	8
	i32.load8_u	0
	br_if   	0                               # 0: down to label354
# %bb.63:                               #   in Loop: Header=BB22_62 Depth=1
	local.get	7
	i32.load	0
	local.set	25
.LBB22_64:                              #   in Loop: Header=BB22_62 Depth=1
	end_block                               # label354:
	local.get	44
	local.get	17
	i32.add 
	local.tee	9
	local.get	25
	i32.store16	0
	local.get	45
	local.get	17
	i32.add 
	local.get	14
	local.get	17
	i32.add 
	i32.load16_u	0
	local.tee	25
	i32.store16	0
	local.get	13
	local.get	20
	i32.load16_u	0
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	20
	local.get	20
	i32.load16_u	0
	i32.const	1
	i32.add 
	i32.store16	0
	block   	
	local.get	9
	i32.load16_u	0
	local.tee	20
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label355
# %bb.65:                               #   in Loop: Header=BB22_62 Depth=1
	local.get	3
	local.get	20
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	20
	local.get	20
	i32.load16_u	0
	i32.const	1
	i32.add 
	i32.store16	0
.LBB22_66:                              #   in Loop: Header=BB22_62 Depth=1
	end_block                               # label355:
	block   	
	local.get	25
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label356
# %bb.67:                               #   in Loop: Header=BB22_62 Depth=1
	local.get	12
	local.get	25
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	25
	local.get	25
	i32.load16_u	0
	i32.const	1
	i32.add 
	i32.store16	0
.LBB22_68:                              #   in Loop: Header=BB22_62 Depth=1
	end_block                               # label356:
	local.get	6
	i32.const	4
	i32.add 
	local.set	6
	local.get	8
	i32.const	1
	i32.add 
	local.set	8
	local.get	7
	i32.const	4
	i32.add 
	local.set	7
	local.get	17
	i32.const	2
	i32.add 
	local.set	17
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	15
	br_if   	0                               # 0: up to label353
# %bb.69:
	end_loop
	i32.const	1
	local.set	17
	local.get	34
	i32.const	2
	local.get	34
	i32.const	2
	i32.gt_u
	i32.select
	i32.const	-1
	i32.add 
	local.tee	25
	i32.const	1
	i32.and 
	local.set	22
	block   	
	local.get	5
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label357
# %bb.70:
	local.get	11
	local.get	31
	local.get	41
	i32.add 
	i32.add 
	local.get	32
	i32.add 
	local.get	16
	i32.const	1
	i32.shl 
	i32.add 
	local.set	17
	local.get	25
	i32.const	-2
	i32.and 
	local.set	9
	local.get	5
	i32.const	2
	i32.shl 
	local.get	40
	i32.add 
	local.set	7
	i32.const	0
	local.set	8
.LBB22_71:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label358:
	local.get	17
	local.get	42
	i32.add 
	local.tee	25
	i32.const	82
	i32.add 
	local.tee	15
	local.get	25
	i32.const	80
	i32.add 
	i32.load16_u	0
	local.get	15
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	17
	local.get	7
	i32.add 
	local.tee	20
	i32.const	84
	i32.add 
	local.tee	6
	local.get	20
	i32.const	82
	i32.add 
	i32.load16_u	0
	local.get	6
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	25
	i32.const	84
	i32.add 
	local.tee	25
	local.get	15
	i32.load16_u	0
	local.get	25
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	20
	i32.const	86
	i32.add 
	local.tee	25
	local.get	6
	i32.load16_u	0
	local.get	25
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	17
	i32.const	4
	i32.add 
	local.set	17
	local.get	9
	local.get	8
	i32.const	2
	i32.add 
	local.tee	8
	i32.ne  
	br_if   	0                               # 0: up to label358
# %bb.72:
	end_loop
	local.get	8
	i32.const	1
	i32.add 
	local.set	17
.LBB22_73:
	end_block                               # label357:
	block   	
	local.get	22
	i32.eqz
	br_if   	0                               # 0: down to label359
# %bb.74:
	local.get	43
	local.get	17
	i32.const	1
	i32.shl 
	local.tee	17
	i32.add 
	local.tee	25
	local.get	43
	local.get	17
	i32.const	-2
	i32.add 
	local.tee	15
	i32.add 
	i32.load16_u	0
	local.get	25
	i32.load16_u	0
	i32.add 
	i32.store16	0
	local.get	35
	local.get	17
	i32.add 
	local.tee	17
	local.get	35
	local.get	15
	i32.add 
	i32.load16_u	0
	local.get	17
	i32.load16_u	0
	i32.add 
	i32.store16	0
.LBB22_75:
	end_block                               # label359:
	block   	
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label360
# %bb.76:
	i32.const	1
	local.set	17
	local.get	11
	local.get	30
	i32.const	2147483644
	i32.and 
	local.get	28
	i32.wrap_i64
	local.tee	9
	i32.add 
	i32.const	-4
	i32.and 
	i32.add 
	local.get	5
	local.get	21
	i32.add 
	local.tee	22
	i32.const	6
	i32.mul 
	local.tee	6
	i32.add 
	local.get	10
	local.get	26
	i32.add 
	local.get	27
	i32.add 
	local.get	16
	i32.add 
	local.get	24
	i32.add 
	local.tee	7
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	84
	i32.add 
	i32.load16_u	0
	local.set	25
	local.get	36
	i32.const	2
	local.get	36
	i32.const	2
	i32.gt_u
	i32.select
	local.tee	20
	i32.const	-1
	i32.add 
	local.tee	8
	i32.const	3
	i32.and 
	local.set	15
	block   	
	local.get	20
	i32.const	-2
	i32.add 
	i32.const	3
	i32.lt_u
	br_if   	0                               # 0: down to label361
# %bb.77:
	local.get	11
	local.get	30
	i32.const	2
	i32.shr_u
	local.get	9
	i32.const	2
	i32.shr_u
	i32.add 
	i32.const	2
	i32.shl 
	i32.add 
	local.get	6
	i32.add 
	local.get	7
	i32.const	1
	i32.shl 
	i32.add 
	local.set	17
	local.get	8
	i32.const	-4
	i32.and 
	local.set	8
	i32.const	0
	local.set	20
.LBB22_78:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label362:
	local.get	17
	i32.const	86
	i32.add 
	local.tee	6
	local.get	25
	local.get	6
	i32.load16_u	0
	i32.add 
	local.tee	25
	i32.store16	0
	local.get	17
	i32.const	88
	i32.add 
	local.tee	6
	local.get	25
	local.get	6
	i32.load16_u	0
	i32.add 
	local.tee	25
	i32.store16	0
	local.get	17
	i32.const	90
	i32.add 
	local.tee	6
	local.get	25
	local.get	6
	i32.load16_u	0
	i32.add 
	local.tee	25
	i32.store16	0
	local.get	17
	i32.const	92
	i32.add 
	local.tee	6
	local.get	25
	local.get	6
	i32.load16_u	0
	i32.add 
	local.tee	25
	i32.store16	0
	local.get	17
	i32.const	8
	i32.add 
	local.set	17
	local.get	8
	local.get	20
	i32.const	4
	i32.add 
	local.tee	20
	i32.ne  
	br_if   	0                               # 0: up to label362
# %bb.79:
	end_loop
	local.get	20
	i32.const	1
	i32.add 
	local.set	17
.LBB22_80:
	end_block                               # label361:
	local.get	15
	i32.eqz
	br_if   	0                               # 0: down to label360
# %bb.81:
	local.get	30
	i32.const	2
	i32.shr_u
	local.get	9
	i32.const	2
	i32.shr_u
	i32.add 
	i32.const	2
	i32.shl 
	local.get	17
	i32.const	1
	i32.shl 
	i32.add 
	local.get	11
	i32.add 
	local.get	22
	i32.const	6
	i32.mul 
	i32.add 
	local.get	7
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	84
	i32.add 
	local.set	17
.LBB22_82:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label363:
	local.get	17
	local.get	25
	local.get	17
	i32.load16_u	0
	i32.add 
	local.tee	25
	i32.store16	0
	local.get	17
	i32.const	2
	i32.add 
	local.set	17
	local.get	15
	i32.const	-1
	i32.add 
	local.tee	15
	br_if   	0                               # 0: up to label363
.LBB22_83:
	end_loop
	end_block                               # label360:
	local.get	10
	i32.const	-1
	i32.add 
	local.set	25
	local.get	40
	local.get	14
	i32.add 
	i32.const	-2
	i32.add 
	local.set	20
	local.get	41
	local.get	40
	i32.add 
	local.get	42
	i32.add 
	local.get	11
	i32.add 
	i32.const	46
	i32.add 
	local.set	6
	local.get	10
	i32.const	2
	i32.shl 
	local.get	41
	i32.add 
	local.get	42
	i32.add 
	local.get	11
	i32.add 
	i32.const	46
	i32.add 
	local.set	8
	i32.const	0
	local.set	17
.LBB22_84:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label364:
	local.get	13
	local.get	6
	local.get	17
	i32.add 
	i32.load16_u	0
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	15
	local.get	15
	i32.load16_u	0
	i32.const	-1
	i32.add 
	local.tee	15
	i32.store16	0
	local.get	2
	local.get	15
	i32.const	65535
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.get	25
	i32.store16	0
	block   	
	local.get	8
	local.get	17
	i32.add 
	i32.load16_u	0
	local.tee	15
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label365
# %bb.85:                               #   in Loop: Header=BB22_84 Depth=1
	local.get	3
	local.get	15
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	15
	local.get	15
	i32.load16_u	0
	i32.const	-1
	i32.add 
	local.tee	15
	i32.store16	0
	local.get	4
	local.get	15
	i32.const	65535
	i32.and 
	i32.const	1
	i32.shl 
	i32.add 
	local.get	25
	i32.store16	0
.LBB22_86:                              #   in Loop: Header=BB22_84 Depth=1
	end_block                               # label365:
	block   	
	local.get	20
	local.get	17
	i32.add 
	i32.load16_u	0
	local.tee	15
	i32.const	65535
	i32.eq  
	br_if   	0                               # 0: down to label366
# %bb.87:                               #   in Loop: Header=BB22_84 Depth=1
	local.get	0
	local.get	15
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	15
	local.get	15
	i32.load16_u	0
	local.tee	15
	i32.const	1
	i32.add 
	i32.store16	0
	local.get	1
	local.get	15
	i32.const	1
	i32.shl 
	i32.add 
	local.get	25
	i32.store16	0
.LBB22_88:                              #   in Loop: Header=BB22_84 Depth=1
	end_block                               # label366:
	local.get	17
	i32.const	-2
	i32.add 
	local.set	17
	local.get	25
	i32.const	-1
	i32.add 
	local.tee	25
	i32.const	-1
	i32.ne  
	br_if   	0                               # 0: up to label364
# %bb.89:
	end_loop
	block   	
	local.get	5
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label367
# %bb.90:
	i32.const	1
	local.set	6
	block   	
	local.get	5
	i32.const	17
	i32.lt_u
	br_if   	0                               # 0: down to label368
# %bb.91:
	i32.const	1
	local.set	6
	local.get	10
	local.get	5
	i32.add 
	i32.const	8
	i32.lt_u
	br_if   	0                               # 0: down to label368
# %bb.92:
	local.get	11
	local.get	31
	local.get	28
	i32.wrap_i64
	i32.const	-4
	i32.and 
	i32.add 
	local.tee	25
	local.get	5
	i32.const	2
	i32.shl 
	i32.add 
	local.get	40
	i32.add 
	i32.add 
	local.get	32
	i32.add 
	local.set	17
	local.get	16
	i32.const	1
	i32.shl 
	local.set	13
	local.get	5
	i32.const	-1
	i32.add 
	local.tee	14
	i32.const	-8
	i32.and 
	local.tee	8
	i32.const	1
	i32.or  
	local.set	6
	local.get	11
	local.get	25
	local.get	42
	i32.add 
	i32.add 
	local.get	32
	i32.add 
	local.set	25
	local.get	8
	local.set	15
.LBB22_93:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label369:
	local.get	25
	local.get	13
	i32.add 
	local.tee	20
	i32.const	82
	i32.add 
	local.get	20
	i32.const	84
	i32.add 
	v128.load	0:p2align=1
	v128.store	0:p2align=1
	local.get	17
	local.get	13
	i32.add 
	local.tee	20
	i32.const	84
	i32.add 
	local.get	20
	i32.const	86
	i32.add 
	v128.load	0:p2align=1
	v128.store	0:p2align=1
	local.get	25
	i32.const	16
	i32.add 
	local.set	25
	local.get	17
	i32.const	16
	i32.add 
	local.set	17
	local.get	15
	i32.const	-8
	i32.add 
	local.tee	15
	br_if   	0                               # 0: up to label369
# %bb.94:
	end_loop
	local.get	14
	local.get	8
	i32.eq  
	br_if   	1                               # 1: down to label367
.LBB22_95:
	end_block                               # label368:
	local.get	6
	i32.const	1
	i32.add 
	local.set	17
	block   	
	local.get	5
	i32.const	1
	i32.and 
	br_if   	0                               # 0: down to label370
# %bb.96:
	local.get	43
	local.get	6
	i32.const	1
	i32.shl 
	local.tee	25
	i32.add 
	local.get	43
	local.get	6
	i32.const	1
	i32.add 
	local.tee	6
	i32.const	1
	i32.shl 
	local.tee	13
	i32.add 
	i32.load16_u	0
	i32.store16	0
	local.get	35
	local.get	25
	i32.add 
	local.get	35
	local.get	13
	i32.add 
	i32.load16_u	0
	i32.store16	0
.LBB22_97:
	end_block                               # label370:
	local.get	5
	local.get	17
	i32.eq  
	br_if   	0                               # 0: down to label367
# %bb.98:
	local.get	11
	local.get	31
	local.get	28
	i32.wrap_i64
	i32.const	-4
	i32.and 
	i32.add 
	local.tee	25
	local.get	42
	i32.add 
	i32.add 
	local.get	32
	i32.add 
	local.get	16
	i32.const	1
	i32.shl 
	local.tee	13
	i32.add 
	local.set	17
	local.get	11
	local.get	25
	local.get	5
	i32.const	2
	i32.shl 
	i32.add 
	local.get	40
	i32.add 
	i32.add 
	local.get	32
	i32.add 
	local.get	13
	i32.add 
	local.set	25
	local.get	6
	i32.const	1
	i32.shl 
	local.set	20
	local.get	5
	local.get	6
	i32.sub 
	local.set	6
.LBB22_99:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label371:
	local.get	17
	local.get	20
	i32.add 
	local.tee	13
	i32.const	80
	i32.add 
	local.get	13
	i32.const	82
	i32.add 
	local.tee	8
	i32.load16_u	0
	i32.store16	0
	local.get	25
	local.get	20
	i32.add 
	local.tee	15
	i32.const	82
	i32.add 
	local.get	15
	i32.const	84
	i32.add 
	local.tee	14
	i32.load16_u	0
	i32.store16	0
	local.get	8
	local.get	13
	i32.const	84
	i32.add 
	i32.load16_u	0
	i32.store16	0
	local.get	14
	local.get	15
	i32.const	86
	i32.add 
	i32.load16_u	0
	i32.store16	0
	local.get	17
	i32.const	4
	i32.add 
	local.set	17
	local.get	25
	i32.const	4
	i32.add 
	local.set	25
	local.get	6
	i32.const	-2
	i32.add 
	local.tee	6
	br_if   	0                               # 0: up to label371
.LBB22_100:
	end_loop
	end_block                               # label367:
	local.get	43
	local.get	5
	i32.const	1
	i32.shl 
	local.tee	17
	i32.add 
	local.get	10
	i32.store16	0
	local.get	35
	local.get	17
	i32.add 
	local.get	23
	i32.store16	0
	block   	
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label372
# %bb.101:
	local.get	21
	local.set	23
	block   	
	local.get	21
	i32.const	8
	i32.lt_u
	br_if   	0                               # 0: down to label373
# %bb.102:
	local.get	5
	i32.const	6
	i32.mul 
	local.get	30
	i32.const	2
	i32.shr_u
	local.get	28
	i32.wrap_i64
	i32.const	2
	i32.shr_u
	i32.add 
	i32.const	2
	i32.shl 
	i32.add 
	local.get	11
	i32.add 
	local.get	21
	i32.const	3
	i32.shl 
	i32.add 
	local.get	10
	local.get	26
	i32.add 
	local.get	27
	i32.add 
	local.get	16
	i32.add 
	local.get	24
	i32.add 
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	70
	i32.add 
	local.set	17
	local.get	21
	i32.const	7
	i32.and 
	local.set	23
	local.get	21
	i32.const	-8
	i32.and 
	local.tee	13
	local.set	25
.LBB22_103:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label374:
	local.get	17
	local.get	17
	i32.const	-2
	i32.add 
	v128.load	0:p2align=1
	v128.store	0:p2align=1
	local.get	17
	i32.const	-16
	i32.add 
	local.set	17
	local.get	25
	i32.const	-8
	i32.add 
	local.tee	25
	br_if   	0                               # 0: up to label374
# %bb.104:
	end_loop
	local.get	21
	local.get	13
	i32.eq  
	br_if   	1                               # 1: down to label372
.LBB22_105:
	end_block                               # label373:
	local.get	30
	i32.const	2
	i32.shr_u
	local.get	28
	i32.wrap_i64
	i32.const	2
	i32.shr_u
	i32.add 
	i32.const	2
	i32.shl 
	local.get	23
	i32.const	1
	i32.shl 
	i32.add 
	local.get	11
	i32.add 
	local.get	5
	local.get	21
	i32.add 
	i32.const	6
	i32.mul 
	i32.add 
	local.get	10
	local.get	26
	i32.add 
	local.get	27
	i32.add 
	local.get	16
	i32.add 
	local.get	24
	i32.add 
	i32.const	1
	i32.shl 
	i32.add 
	i32.const	84
	i32.add 
	local.set	16
.LBB22_106:                             # =>This Inner Loop Header: Depth=1
	loop    	                                # label375:
	local.get	16
	local.get	16
	i32.const	-2
	i32.add 
	local.tee	17
	i32.load16_u	0
	i32.store16	0
	local.get	17
	local.set	16
	local.get	23
	i32.const	-1
	i32.add 
	local.tee	23
	br_if   	0                               # 0: up to label375
.LBB22_107:
	end_loop
	end_block                               # label372:
	local.get	0
	i32.const	0
	i32.store16	0
	local.get	38
	local.set	17
.LBB22_108:
	end_block                               # label327:
	local.get	17
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.encode_term_content_token_binary_dedup,"",@
	.globl	encode_term_content_token_binary_dedup # -- Begin function encode_term_content_token_binary_dedup
	.type	encode_term_content_token_binary_dedup,@function
encode_term_content_token_binary_dedup: # @encode_term_content_token_binary_dedup
	.functype	encode_term_content_token_binary_dedup (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	10
	global.set	__stack_pointer
	i32.const	-1
	local.set	11
	block   	
	local.get	0
	i32x4.splat
	local.get	1
	i32x4.replace_lane	1
	local.get	3
	i32x4.replace_lane	2
	local.get	5
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	12
	i32x4.eq
	v128.const	65535, 65535, 65535, 65535
	local.tee	13
	v128.and
	local.get	6
	i32x4.splat
	local.get	8
	i32x4.replace_lane	1
	local.get	9
	i32x4.replace_lane	2
	local.get	7
	i32x4.replace_lane	3
	local.get	12
	i32x4.eq
	local.get	13
	v128.and
	i16x8.narrow_i32x4_u
	v128.any_true
	br_if   	0                               # 0: down to label376
# %bb.1:
	i32.const	-1
	local.set	11
	local.get	7
	local.get	7
	i32.const	-1
	i32.add 
	local.tee	14
	i32.and 
	br_if   	0                               # 0: down to label376
# %bb.2:
	i32.const	0
	local.set	15
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	10
	i32.const	0
	i32.store	12
	i32.const	0
	local.set	16
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label377
# %bb.3:
	i32.const	0
	local.set	15
	i32.const	0
	local.set	16
	i32.const	0
	local.set	17
.LBB23_4:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB23_5 Depth 2
                                        #     Child Loop BB23_17 Depth 2
                                        #       Child Loop BB23_24 Depth 3
                                        #       Child Loop BB23_27 Depth 3
	loop    	                                # label378:
	local.get	10
	i32.const	0
	i32.store	8
	local.get	10
	i32.const	0
	i32.store	4
	block   	
	local.get	0
	local.get	1
	local.get	17
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	18
	local.get	3
	local.get	4
	local.get	10
	i32.const	12
	i32.add 
	local.get	10
	i32.const	8
	i32.add 
	local.get	10
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	call	encode_term_content_token_binary_row
	br_if   	0                               # 0: down to label379
.LBB23_5:                               #   Parent Loop BB23_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label380:
	local.get	10
	local.get	15
	i32.store	12
	i32.const	-2
	local.set	11
	local.get	4
	i32.const	2147483646
	i32.gt_u
	br_if   	4                               # 4: down to label376
# %bb.6:                                #   in Loop: Header=BB23_5 Depth=2
	local.get	3
	local.get	4
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	19
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label376
# %bb.7:                                #   in Loop: Header=BB23_5 Depth=2
	i32.const	0
	i32.load	heap_ptr
	local.get	19
	local.get	3
	i32.add 
	local.tee	20
	i32.ne  
	br_if   	4                               # 4: down to label376
# %bb.8:                                #   in Loop: Header=BB23_5 Depth=2
	i32.const	2147483647
	local.get	4
	i32.const	1
	i32.shr_u
	local.tee	21
	i32.const	1048576
	local.get	21
	i32.const	1048576
	i32.gt_u
	i32.select
	local.tee	21
	local.get	4
	i32.add 
	local.get	4
	local.get	21
	i32.const	2147483647
	i32.xor 
	i32.gt_u
	i32.select
	local.tee	4
	local.get	19
	i32.sub 
	i32.const	7
	i32.add 
	local.set	21
	local.get	20
	local.set	19
	block   	
	local.get	20
	br_if   	0                               # 0: down to label381
# %bb.9:                                #   in Loop: Header=BB23_5 Depth=2
	i32.const	__heap_base
	local.set	19
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB23_10:                              #   in Loop: Header=BB23_5 Depth=2
	end_block                               # label381:
	local.get	19
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	19
	local.get	21
	i32.const	-8
	i32.and 
	local.tee	21
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	4                               # 4: down to label376
# %bb.11:                               #   in Loop: Header=BB23_5 Depth=2
	block   	
	local.get	19
	local.get	21
	i32.add 
	local.tee	21
	i32.const	16
	i32.shr_u
	local.get	21
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	22
	memory.size	0
	local.tee	23
	i32.le_u
	br_if   	0                               # 0: down to label382
# %bb.12:                               #   in Loop: Header=BB23_5 Depth=2
	local.get	22
	local.get	23
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	5                               # 5: down to label376
.LBB23_13:                              #   in Loop: Header=BB23_5 Depth=2
	end_block                               # label382:
	i32.const	0
	local.get	21
	i32.store	heap_ptr
	local.get	19
	i32.eqz
	br_if   	4                               # 4: down to label376
# %bb.14:                               #   in Loop: Header=BB23_5 Depth=2
	local.get	19
	local.get	20
	i32.ne  
	br_if   	4                               # 4: down to label376
# %bb.15:                               #   in Loop: Header=BB23_5 Depth=2
	i32.const	0
	local.get	4
	i32.store	last_content_capacity
	local.get	0
	local.get	18
	local.get	3
	local.get	4
	local.get	10
	i32.const	12
	i32.add 
	local.get	10
	i32.const	8
	i32.add 
	local.get	10
	i32.const	4
	i32.add 
	i32.const	0
	i32.const	0
	call	encode_term_content_token_binary_row
	i32.eqz
	br_if   	0                               # 0: up to label380
.LBB23_16:                              #   in Loop: Header=BB23_4 Depth=1
	end_loop
	end_block                               # label379:
	local.get	17
	i32.const	2
	i32.shl 
	local.set	24
	local.get	10
	i32.load	4
	local.tee	25
	i32.const	-1640531535
	i32.mul 
	local.get	10
	i32.load	8
	local.tee	26
	i32.xor 
	local.tee	11
	i32.const	16
	i32.shr_u
	local.get	11
	i32.xor 
	local.get	14
	i32.and 
	local.set	27
	local.get	3
	local.get	15
	i32.add 
	local.set	28
	local.get	10
	i32.load	12
	local.tee	29
	local.get	15
	i32.sub 
	local.set	30
	i32.const	0
	local.set	31
.LBB23_17:                              #   Parent Loop BB23_4 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB23_24 Depth 3
                                        #       Child Loop BB23_27 Depth 3
	block   	
	block   	
	block   	
	loop    	                                # label386:
	local.get	6
	local.get	27
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	11
	i32.eqz
	br_if   	1                               # 1: down to label385
# %bb.18:                               #   in Loop: Header=BB23_17 Depth=2
	block   	
	local.get	11
	i32.const	-1
	i32.add 
	local.tee	32
	local.get	17
	i32.lt_u
	br_if   	0                               # 0: down to label387
# %bb.19:
	i32.const	-3
	local.set	11
	br      	7                               # 7: down to label376
.LBB23_20:                              #   in Loop: Header=BB23_17 Depth=2
	end_block                               # label387:
	block   	
	local.get	5
	local.get	32
	i32.const	4
	i32.shl 
	i32.add 
	local.tee	20
	i32.load	8
	local.get	26
	i32.ne  
	br_if   	0                               # 0: down to label388
# %bb.21:                               #   in Loop: Header=BB23_17 Depth=2
	local.get	20
	i32.load	12
	local.get	25
	i32.ne  
	br_if   	0                               # 0: down to label388
# %bb.22:                               #   in Loop: Header=BB23_17 Depth=2
	local.get	20
	i32.load	4
	local.get	30
	i32.ne  
	br_if   	0                               # 0: down to label388
# %bb.23:                               #   in Loop: Header=BB23_17 Depth=2
	i32.const	0
	local.set	11
	local.get	3
	local.get	20
	i32.load	0
	local.tee	33
	i32.add 
	local.tee	34
	local.set	20
	local.get	28
	local.set	19
	local.get	30
	local.set	21
.LBB23_24:                              #   Parent Loop BB23_4 Depth=1
                                        #     Parent Loop BB23_17 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	block   	
	loop    	                                # label390:
	block   	
	local.get	11
	i32.const	8
	i32.add 
	local.tee	18
	local.get	30
	i32.le_u
	br_if   	0                               # 0: down to label391
# %bb.25:                               #   in Loop: Header=BB23_17 Depth=2
	local.get	11
	local.get	30
	i32.lt_u
	br_if   	2                               # 2: down to label389
	br      	6                               # 6: down to label384
.LBB23_26:                              #   in Loop: Header=BB23_24 Depth=3
	end_block                               # label391:
	local.get	28
	local.get	11
	i32.add 
	local.set	22
	local.get	34
	local.get	11
	i32.add 
	local.set	23
	local.get	20
	i32.const	8
	i32.add 
	local.set	20
	local.get	19
	i32.const	8
	i32.add 
	local.set	19
	local.get	21
	i32.const	-8
	i32.add 
	local.set	21
	local.get	18
	local.set	11
	local.get	23
	i64.load	0:p2align=0
	local.get	22
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label390
	br      	2                               # 2: down to label388
.LBB23_27:                              #   Parent Loop BB23_4 Depth=1
                                        #     Parent Loop BB23_17 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	end_loop
	end_block                               # label389:
	loop    	                                # label392:
	local.get	20
	i32.load8_u	0
	local.get	19
	i32.load8_u	0
	i32.ne  
	br_if   	1                               # 1: down to label388
# %bb.28:                               #   in Loop: Header=BB23_27 Depth=3
	local.get	20
	i32.const	1
	i32.add 
	local.set	20
	local.get	19
	i32.const	1
	i32.add 
	local.set	19
	local.get	21
	i32.const	-1
	i32.add 
	local.tee	21
	i32.eqz
	br_if   	4                               # 4: down to label384
	br      	0                               # 0: up to label392
.LBB23_29:                              #   in Loop: Header=BB23_17 Depth=2
	end_loop
	end_block                               # label388:
	local.get	27
	i32.const	1
	i32.add 
	local.get	14
	i32.and 
	local.set	27
	local.get	31
	i32.const	1
	i32.add 
	local.tee	31
	local.get	7
	i32.ne  
	br_if   	0                               # 0: up to label386
.LBB23_30:                              #   in Loop: Header=BB23_4 Depth=1
	end_loop
	end_block                               # label385:
	i32.const	-3
	local.set	11
	local.get	6
	local.get	27
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	20
	i32.load	0
	br_if   	4                               # 4: down to label376
# %bb.31:                               #   in Loop: Header=BB23_4 Depth=1
	local.get	16
	i32.const	-1
	i32.eq  
	br_if   	4                               # 4: down to label376
# %bb.32:                               #   in Loop: Header=BB23_4 Depth=1
	local.get	5
	local.get	24
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	11
	local.get	25
	i32.store	12
	local.get	11
	local.get	26
	i32.store	8
	local.get	11
	local.get	30
	i32.store	4
	local.get	11
	local.get	15
	i32.store	0
	local.get	8
	local.get	24
	i32.add 
	local.get	16
	i32.store	0
	local.get	20
	local.get	17
	i32.const	1
	i32.add 
	local.tee	17
	i32.store	0
	local.get	16
	i32.const	1
	i32.add 
	local.set	16
	local.get	29
	local.set	15
	br      	1                               # 1: down to label383
.LBB23_33:                              #   in Loop: Header=BB23_4 Depth=1
	end_block                               # label384:
	local.get	5
	local.get	24
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	11
	local.get	25
	i32.store	12
	local.get	11
	local.get	26
	i32.store	8
	local.get	11
	local.get	30
	i32.store	4
	local.get	11
	local.get	33
	i32.store	0
	local.get	8
	local.get	24
	i32.add 
	local.get	8
	local.get	32
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.store	0
	local.get	10
	local.get	15
	i32.store	12
	local.get	17
	i32.const	1
	i32.add 
	local.set	17
.LBB23_34:                              #   in Loop: Header=BB23_4 Depth=1
	end_block                               # label383:
	local.get	17
	local.get	2
	i32.ne  
	br_if   	0                               # 0: up to label378
.LBB23_35:
	end_loop
	end_block                               # label377:
	local.get	9
	local.get	16
	i32.store	0
	local.get	15
	local.set	11
.LBB23_36:
	end_block                               # label376:
	local.get	10
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	11
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_and_encode_term_bank_token_binary_dedup,"",@
	.globl	parse_and_encode_term_bank_token_binary_dedup # -- Begin function parse_and_encode_term_bank_token_binary_dedup
	.type	parse_and_encode_term_bank_token_binary_dedup,@function
parse_and_encode_term_bank_token_binary_dedup: # @parse_and_encode_term_bank_token_binary_dedup
	.functype	parse_and_encode_term_bank_token_binary_dedup (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	112
	i32.sub 
	local.tee	37
	global.set	__stack_pointer
	i32.const	-1
	local.set	38
	block   	
	local.get	0
	i32x4.splat
	local.get	1
	i32x4.replace_lane	1
	local.get	2
	i32x4.replace_lane	2
	local.get	3
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	39
	i32x4.eq
	local.get	4
	i32x4.splat
	local.get	6
	i32x4.replace_lane	1
	local.get	7
	i32x4.replace_lane	2
	local.get	9
	i32x4.replace_lane	3
	local.get	39
	i32x4.eq
	i8x16.shuffle	0, 4, 8, 12, 16, 20, 24, 28, 0, 0, 0, 0, 0, 0, 0, 0
	local.get	10
	i32x4.splat
	local.get	11
	i32x4.replace_lane	1
	local.get	12
	i32x4.replace_lane	2
	local.get	13
	i32x4.replace_lane	3
	local.get	39
	i32x4.eq
	local.tee	40
	i32x4.extract_lane	0
	i8x16.replace_lane	8
	local.get	40
	i32x4.extract_lane	1
	i8x16.replace_lane	9
	local.get	40
	i32x4.extract_lane	2
	i8x16.replace_lane	10
	local.get	40
	i32x4.extract_lane	3
	i8x16.replace_lane	11
	local.get	15
	i32x4.splat
	local.get	16
	i32x4.replace_lane	1
	local.get	17
	i32x4.replace_lane	2
	local.get	18
	i32x4.replace_lane	3
	local.get	39
	i32x4.eq
	local.tee	40
	i32x4.extract_lane	0
	i8x16.replace_lane	12
	local.get	40
	i32x4.extract_lane	1
	i8x16.replace_lane	13
	local.get	40
	i32x4.extract_lane	2
	i8x16.replace_lane	14
	local.get	40
	i32x4.extract_lane	3
	i8x16.replace_lane	15
	local.tee	40
	local.get	19
	i32x4.splat
	local.get	20
	i32x4.replace_lane	1
	local.get	22
	i32x4.replace_lane	2
	local.get	23
	i32x4.replace_lane	3
	local.get	39
	i32x4.eq
	local.get	24
	i32x4.splat
	local.get	25
	i32x4.replace_lane	1
	local.get	26
	i32x4.replace_lane	2
	local.get	27
	i32x4.replace_lane	3
	local.get	39
	i32x4.eq
	i8x16.shuffle	0, 4, 8, 12, 16, 20, 24, 28, 0, 0, 0, 0, 0, 0, 0, 0
	v128.or
	local.get	40
	i8x16.shuffle	0, 1, 2, 3, 4, 5, 6, 7, 24, 25, 26, 27, 28, 29, 30, 31
	v128.any_true
	br_if   	0                               # 0: down to label393
# %bb.1:
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label393
# %bb.2:
	i32.const	-1
	local.set	38
	local.get	8
	local.get	8
	i32.const	-1
	i32.add 
	local.tee	41
	i32.and 
	br_if   	0                               # 0: down to label393
# %bb.3:
	local.get	21
	i32.eqz
	br_if   	0                               # 0: down to label393
# %bb.4:
	i32.const	-1
	local.set	38
	local.get	21
	local.get	21
	i32.const	-1
	i32.add 
	local.tee	42
	i32.and 
	br_if   	0                               # 0: down to label393
# %bb.5:
	local.get	30
	i32.const	0
	i32.ne  
	local.get	31
	i32.eqz
	i32.eq  
	br_if   	0                               # 0: down to label393
# %bb.6:
	block   	
	local.get	29
	i32.const	1
	i32.and 
	br_if   	0                               # 0: down to label394
# %bb.7:
	local.get	31
	br_if   	1                               # 1: down to label393
.LBB24_8:
	end_block                               # label394:
	block   	
	local.get	29
	i32.const	8
	i32.and 
	local.tee	43
	i32.eqz
	br_if   	0                               # 0: down to label395
# %bb.9:
	local.get	34
	i32.eqz
	br_if   	1                               # 1: down to label393
# %bb.10:
	local.get	33
	i32.eqz
	br_if   	1                               # 1: down to label393
# %bb.11:
	local.get	35
	i32.eqz
	br_if   	1                               # 1: down to label393
# %bb.12:
	local.get	34
	i32.popcnt
	i32.const	1
	i32.gt_u
	br_if   	1                               # 1: down to label393
.LBB24_13:
	end_block                               # label395:
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label396
# %bb.14:
	local.get	32
	v128.const	0, 0
	v128.store	0:p2align=2
	local.get	32
	i32.const	16
	i32.add 
	i32.const	0
	i32.store	0
.LBB24_15:
	end_block                               # label396:
	i32.const	0
	local.get	3
	i32.store	last_parse_capacity
	i32.const	0
	local.get	5
	i32.store	last_content_capacity
	local.get	37
	i32.const	0
	i32.store	108
	local.get	37
	i32.const	0
	i32.store	76
	local.get	37
	i64.const	0
	i64.store	68:p2align=2
	local.get	37
	local.get	31
	i32.const	1
	local.get	31
	i32.const	1
	i32.gt_u
	i32.select
	i32.store	64
	local.get	37
	local.get	1
	i32.store	60
	local.get	37
	local.get	30
	i32.store	56
	local.get	37
	local.get	0
	i32.store	52
	i32.const	0
	local.set	44
	i32.const	0
	local.set	45
	i32.const	0
	local.set	46
	i32.const	0
	local.set	47
	i32.const	0
	local.set	48
	i32.const	0
	local.set	49
	block   	
	local.get	37
	i32.const	52
	i32.add 
	call	next_term_bank
	local.tee	1
	i32.const	1
	i32.lt_s
	br_if   	0                               # 0: down to label397
# %bb.16:
	i32.const	0
	local.get	34
	i32.const	-1
	i32.add 
	local.tee	38
	local.get	38
	local.get	34
	i32.gt_u
	i32.select
	local.set	50
	local.get	2
	i32.const	-28
	i32.add 
	local.set	51
	local.get	29
	i32.const	4
	i32.and 
	local.set	52
	local.get	2
	i32.const	-68
	i32.add 
	local.set	53
	local.get	3
	i32.const	1
	i32.shl 
	local.set	54
	local.get	29
	i32.const	2
	i32.and 
	local.set	55
	local.get	0
	i32.const	1
	i32.add 
	local.set	56
	local.get	36
	i32.const	0
	i32.ne  
	local.set	57
	local.get	28
	i32.const	0
	i32.ne  
	local.set	58
	i32.const	-1
	local.set	59
	i32.const	0
	local.set	44
	i32.const	0
	local.set	49
	i32.const	0
	local.set	48
	i32.const	0
	local.set	47
	i32.const	0
	local.set	46
	i32.const	0
	local.set	45
	i32.const	0
	local.set	31
	i32.const	0
	local.set	60
.LBB24_17:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB24_38 Depth 2
                                        #     Child Loop BB24_40 Depth 2
                                        #     Child Loop BB24_45 Depth 2
                                        #     Child Loop BB24_50 Depth 2
                                        #       Child Loop BB24_56 Depth 3
                                        #       Child Loop BB24_58 Depth 3
                                        #       Child Loop BB24_61 Depth 3
                                        #       Child Loop BB24_74 Depth 3
                                        #         Child Loop BB24_80 Depth 4
                                        #         Child Loop BB24_82 Depth 4
                                        #         Child Loop BB24_85 Depth 4
                                        #     Child Loop BB24_99 Depth 2
                                        #     Child Loop BB24_118 Depth 2
                                        #     Child Loop BB24_131 Depth 2
                                        #     Child Loop BB24_145 Depth 2
                                        #     Child Loop BB24_156 Depth 2
                                        #     Child Loop BB24_168 Depth 2
                                        #     Child Loop BB24_181 Depth 2
                                        #     Child Loop BB24_187 Depth 2
                                        #     Child Loop BB24_192 Depth 2
	loop    	                                # label398:
	block   	
	local.get	46
	local.get	3
	i32.ne  
	br_if   	0                               # 0: down to label399
# %bb.18:
	local.get	12
	local.get	3
	i32.store	0
	i32.const	-4
	local.set	38
	br      	3                               # 3: down to label393
.LBB24_19:                              #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label399:
	i32.const	0
	local.set	38
	local.get	37
	i32.const	0
	i32.store	48
	local.get	37
	i32.const	-1
	i32.store	44
	i32.const	0
	local.set	1
	block   	
	local.get	52
	i32.const	0
	i32.ne  
	local.get	46
	i32.const	0
	i32.ne  
	i32.and 
	local.tee	30
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label400
# %bb.20:                               #   in Loop: Header=BB24_17 Depth=1
	block   	
	local.get	31
	i32.eqz
	br_if   	0                               # 0: down to label401
# %bb.21:                               #   in Loop: Header=BB24_17 Depth=1
	i32.const	4
	local.set	1
	local.get	37
	i32.const	44
	i32.add 
	local.set	38
	br      	1                               # 1: down to label400
.LBB24_22:                              #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label401:
	local.get	37
	i32.const	44
	i32.add 
	i32.const	0
	local.get	51
	local.get	46
	i32.const	68
	i32.mul 
	i32.add 
	i32.load	0
	i32.const	511
	i32.gt_u
	local.tee	1
	i32.select
	local.set	38
.LBB24_23:                              #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label400:
	block   	
	local.get	0
	local.get	37
	i32.load	72
	local.tee	61
	local.get	37
	i32.load	76
	local.get	2
	local.get	46
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	62
	local.get	58
	local.get	37
	i32.const	48
	i32.add 
	local.get	2
	local.get	46
	local.get	38
	local.get	1
	local.get	57
	local.get	37
	i32.const	40
	i32.add 
	call	parse_row_single_pass
	br_if   	0                               # 0: down to label402
# %bb.24:
	i32.const	-1
	local.set	38
	br      	3                               # 3: down to label393
.LBB24_25:                              #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label402:
	local.get	37
	i32.load	44
	local.set	63
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label403
# %bb.26:                               #   in Loop: Header=BB24_17 Depth=1
	local.get	63
	i32.const	-1
	i32.eq  
	br_if   	0                               # 0: down to label403
# %bb.27:                               #   in Loop: Header=BB24_17 Depth=1
	local.get	32
	local.get	32
	i32.load	4
	i32.const	1
	i32.add 
	i32.store	4
.LBB24_28:                              #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label403:
	block   	
	block   	
	local.get	30
	br_if   	0                               # 0: down to label405
# %bb.29:                               #   in Loop: Header=BB24_17 Depth=1
	local.get	31
	local.set	64
	br      	1                               # 1: down to label404
.LBB24_30:                              #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label405:
	i32.const	4
	local.set	64
	local.get	63
	i32.const	-1
	i32.ne  
	br_if   	0                               # 0: down to label404
# %bb.31:                               #   in Loop: Header=BB24_17 Depth=1
	i32.const	0
	local.get	31
	i32.const	-1
	i32.add 
	local.tee	38
	local.get	38
	local.get	31
	i32.gt_u
	i32.select
	local.set	64
.LBB24_32:                              #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label404:
	local.get	37
	local.get	62
	i32.load	0
	local.tee	30
	i32.store	36
	local.get	37
	local.get	62
	i32.load	8
	local.tee	1
	i32.store	32
	local.get	37
	local.get	62
	i32.load	4
	local.tee	28
	i32.store	28
	local.get	37
	local.get	62
	i32.load	12
	local.tee	38
	i32.store	24
	i32.const	0
	local.set	65
	local.get	37
	i32.const	0
	i32.store	16
	local.get	37
	i32.const	0
	i32.store	12
	block   	
	local.get	38
	i32.const	2
	i32.ne  
	br_if   	0                               # 0: down to label406
# %bb.33:                               #   in Loop: Header=BB24_17 Depth=1
	local.get	0
	local.get	1
	i32.add 
	local.tee	31
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label406
# %bb.34:                               #   in Loop: Header=BB24_17 Depth=1
	local.get	31
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	65
.LBB24_35:                              #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label406:
	block   	
	local.get	65
	br_if   	0                               # 0: down to label407
# %bb.36:                               #   in Loop: Header=BB24_17 Depth=1
	local.get	28
	local.get	38
	i32.ne  
	br_if   	0                               # 0: down to label407
# %bb.37:                               #   in Loop: Header=BB24_17 Depth=1
	i32.const	0
	local.set	31
	local.get	0
	local.get	30
	i32.add 
	local.tee	66
	local.set	38
	local.get	0
	local.get	1
	i32.add 
	local.tee	67
	local.set	1
.LBB24_38:                              #   Parent Loop BB24_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label408:
	block   	
	local.get	28
	local.get	31
	i32.add 
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label409
# %bb.39:                               #   in Loop: Header=BB24_17 Depth=1
	i32.const	0
	local.set	30
	local.get	28
	local.set	36
.LBB24_40:                              #   Parent Loop BB24_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label411:
	block   	
	local.get	31
	local.get	36
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label412
# %bb.41:                               #   in Loop: Header=BB24_17 Depth=1
	local.get	30
	local.get	31
	i32.sub 
	local.tee	38
	local.get	28
	i32.lt_u
	br_if   	2                               # 2: down to label410
# %bb.42:                               #   in Loop: Header=BB24_17 Depth=1
	i32.const	1
	local.set	65
	br      	5                               # 5: down to label407
.LBB24_43:                              #   in Loop: Header=BB24_40 Depth=2
	end_block                               # label412:
	local.get	1
	local.get	30
	i32.add 
	local.set	68
	local.get	38
	local.get	30
	i32.add 
	local.set	69
	local.get	36
	i32.const	-8
	i32.add 
	local.set	36
	local.get	30
	i32.const	8
	i32.add 
	local.set	30
	local.get	69
	i64.load	0:p2align=0
	local.get	68
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label411
# %bb.44:                               #   in Loop: Header=BB24_17 Depth=1
	end_loop
	i32.const	0
	local.set	65
	br      	3                               # 3: down to label407
.LBB24_45:                              #   Parent Loop BB24_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	end_block                               # label410:
	loop    	                                # label413:
	local.get	66
	local.get	38
	i32.add 
	i32.load8_u	0
	local.tee	1
	local.get	67
	local.get	38
	i32.add 
	i32.load8_u	0
	local.tee	31
	i32.eq  
	local.set	65
	local.get	1
	local.get	31
	i32.ne  
	br_if   	3                               # 3: down to label407
# %bb.46:                               #   in Loop: Header=BB24_45 Depth=2
	local.get	38
	i32.const	1
	i32.add 
	local.tee	38
	local.get	28
	i32.lt_u
	br_if   	0                               # 0: up to label413
	br      	3                               # 3: down to label407
.LBB24_47:                              #   in Loop: Header=BB24_38 Depth=2
	end_loop
	end_block                               # label409:
	local.get	38
	i32.const	16
	i32.add 
	local.set	30
	local.get	1
	i32.const	16
	i32.add 
	local.set	36
	local.get	38
	v128.load	0:p2align=0
	local.set	39
	local.get	1
	v128.load	0:p2align=0
	local.set	40
	local.get	38
	i32.const	32
	i32.add 
	local.set	38
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	31
	i32.const	-32
	i32.add 
	local.set	31
	local.get	36
	v128.load	0:p2align=0
	local.get	30
	v128.load	0:p2align=0
	v128.xor
	local.get	40
	local.get	39
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label408
# %bb.48:                               #   in Loop: Header=BB24_17 Depth=1
	end_loop
	i32.const	0
	local.set	65
.LBB24_49:                              #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label407:
	local.get	2
	local.get	46
	i32.const	-1
	i32.add 
	local.tee	70
	i32.const	68
	i32.mul 
	i32.add 
	local.set	71
	i32.const	0
	local.set	69
	local.get	37
	i32.const	36
	i32.add 
	local.set	38
	local.get	37
	i32.const	28
	i32.add 
	local.set	1
	local.get	37
	i32.const	16
	i32.add 
	local.set	72
	i32.const	1
	local.set	73
	local.get	37
	i32.load	40
	local.set	74
.LBB24_50:                              #   Parent Loop BB24_17 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB24_56 Depth 3
                                        #       Child Loop BB24_58 Depth 3
                                        #       Child Loop BB24_61 Depth 3
                                        #       Child Loop BB24_74 Depth 3
                                        #         Child Loop BB24_80 Depth 4
                                        #         Child Loop BB24_82 Depth 4
                                        #         Child Loop BB24_85 Depth 4
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	loop    	                                # label421:
	block   	
	local.get	65
	local.get	69
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label422
# %bb.51:                               #   in Loop: Header=BB24_17 Depth=1
	local.get	37
	local.get	37
	i32.load	16
	i32.store	12
	br      	2                               # 2: down to label420
.LBB24_52:                              #   in Loop: Header=BB24_50 Depth=2
	end_block                               # label422:
	local.get	1
	i32.load	0
	local.tee	75
	i32.const	-2
	i32.add 
	local.set	28
	local.get	38
	i32.load	0
	local.set	76
	block   	
	block   	
	block   	
	block   	
	local.get	46
	i32.eqz
	br_if   	0                               # 0: down to label426
# %bb.53:                               #   in Loop: Header=BB24_50 Depth=2
	local.get	28
	i32.const	32
	i32.gt_u
	br_if   	0                               # 0: down to label426
# %bb.54:                               #   in Loop: Header=BB24_50 Depth=2
	local.get	75
	local.get	71
	i32.const	4
	i32.const	12
	local.get	73
	i32.const	1
	i32.and 
	local.tee	77
	i32.select
	i32.add 
	i32.load	0
	i32.ne  
	br_if   	1                               # 1: down to label425
# %bb.55:                               #   in Loop: Header=BB24_50 Depth=2
	local.get	0
	local.get	76
	i32.add 
	local.set	36
	local.get	56
	local.get	76
	i32.add 
	local.set	66
	local.get	0
	local.get	71
	i32.const	0
	i32.const	8
	local.get	77
	i32.select
	i32.add 
	i32.load	0
	local.tee	38
	i32.add 
	local.set	68
	local.get	56
	local.get	38
	i32.add 
	local.set	67
	i32.const	17
	local.set	1
	local.get	28
	local.set	38
.LBB24_56:                              #   Parent Loop BB24_17 Depth=1
                                        #     Parent Loop BB24_50 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label427:
	block   	
	local.get	38
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label428
# %bb.57:                               #   in Loop: Header=BB24_50 Depth=2
	local.get	1
	i32.const	-17
	i32.add 
	local.set	1
.LBB24_58:                              #   Parent Loop BB24_17 Depth=1
                                        #     Parent Loop BB24_50 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	block   	
	loop    	                                # label430:
	block   	
	local.get	38
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label431
# %bb.59:                               #   in Loop: Header=BB24_50 Depth=2
	local.get	1
	local.get	28
	i32.lt_u
	br_if   	2                               # 2: down to label429
	br      	7                               # 7: down to label424
.LBB24_60:                              #   in Loop: Header=BB24_58 Depth=3
	end_block                               # label431:
	local.get	67
	local.get	1
	i32.add 
	local.set	31
	local.get	66
	local.get	1
	i32.add 
	local.set	30
	local.get	38
	i32.const	-8
	i32.add 
	local.set	38
	local.get	1
	i32.const	8
	i32.add 
	local.set	1
	local.get	30
	i64.load	0:p2align=0
	local.get	31
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label430
	br      	4                               # 4: down to label426
.LBB24_61:                              #   Parent Loop BB24_17 Depth=1
                                        #     Parent Loop BB24_50 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	end_loop
	end_block                               # label429:
	loop    	                                # label432:
	local.get	66
	local.get	1
	i32.add 
	i32.load8_u	0
	local.get	67
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	3                               # 3: down to label426
# %bb.62:                               #   in Loop: Header=BB24_61 Depth=3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	local.get	28
	i32.ge_u
	br_if   	5                               # 5: down to label424
	br      	0                               # 0: up to label432
.LBB24_63:                              #   in Loop: Header=BB24_56 Depth=3
	end_loop
	end_block                               # label428:
	local.get	36
	local.get	1
	i32.add 
	local.set	31
	local.get	68
	local.get	1
	i32.add 
	local.set	30
	local.get	38
	i32.const	-32
	i32.add 
	local.set	38
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	30
	v128.load	0:p2align=0
	local.get	31
	v128.load	0:p2align=0
	v128.xor
	local.get	30
	i32.const	-16
	i32.add 
	v128.load	0:p2align=0
	local.get	31
	i32.const	-16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label427
.LBB24_64:                              #   in Loop: Header=BB24_50 Depth=2
	end_loop
	end_block                               # label426:
	local.get	75
	i32.const	2
	i32.lt_u
	br_if   	5                               # 5: down to label419
.LBB24_65:                              #   in Loop: Header=BB24_50 Depth=2
	end_block                               # label425:
	block   	
	block   	
	local.get	74
	local.get	69
	i32.shr_u
	i32.const	1
	i32.and 
	br_if   	0                               # 0: down to label434
# %bb.66:                               #   in Loop: Header=BB24_50 Depth=2
	local.get	76
	i32.const	1
	i32.add 
	local.set	38
	local.get	0
	local.set	78
	br      	1                               # 1: down to label433
.LBB24_67:                              #   in Loop: Header=BB24_50 Depth=2
	end_block                               # label434:
	local.get	55
	i32.eqz
	br_if   	5                               # 5: down to label419
# %bb.68:                               #   in Loop: Header=BB24_50 Depth=2
	local.get	0
	local.get	76
	i32.add 
	local.get	75
	local.get	13
	local.get	47
	i32.add 
	local.get	14
	local.get	47
	i32.sub 
	call	decode_escaped_key
	local.tee	28
	i32.const	0
	i32.lt_s
	br_if   	5                               # 5: down to label419
# %bb.69:                               #   in Loop: Header=BB24_50 Depth=2
	block   	
	local.get	32
	i32.eqz
	br_if   	0                               # 0: down to label435
# %bb.70:                               #   in Loop: Header=BB24_50 Depth=2
	local.get	32
	local.get	32
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
.LBB24_71:                              #   in Loop: Header=BB24_50 Depth=2
	end_block                               # label435:
	local.get	47
	local.set	38
	local.get	13
	local.set	78
.LBB24_72:                              #   in Loop: Header=BB24_50 Depth=2
	end_block                               # label433:
	local.get	28
	i32.const	65535
	i32.gt_u
	br_if   	4                               # 4: down to label419
# %bb.73:                               #   in Loop: Header=BB24_50 Depth=2
	local.get	78
	local.get	38
	i32.add 
	local.tee	76
	local.get	28
	i32.const	-2128831035
	call	hash_content_xxh32
	local.tee	79
	local.get	28
	i32.const	-2048144789
	i32.mul 
	i32.xor 
	local.tee	38
	i32.const	16
	i32.shr_u
	local.get	38
	i32.xor 
	local.get	42
	i32.and 
	local.set	66
	i32.const	0
	local.set	75
.LBB24_74:                              #   Parent Loop BB24_17 Depth=1
                                        #     Parent Loop BB24_50 Depth=2
                                        # =>    This Loop Header: Depth=3
                                        #         Child Loop BB24_80 Depth 4
                                        #         Child Loop BB24_82 Depth 4
                                        #         Child Loop BB24_85 Depth 4
	block   	
	loop    	                                # label437:
	local.get	20
	local.get	66
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	38
	i32.eqz
	br_if   	1                               # 1: down to label436
# %bb.75:                               #   in Loop: Header=BB24_74 Depth=3
	block   	
	local.get	38
	i32.const	-1
	i32.add 
	local.tee	67
	local.get	48
	i32.lt_u
	br_if   	0                               # 0: down to label438
# %bb.76:
	i32.const	-3
	local.set	38
	br      	15                              # 15: down to label393
.LBB24_77:                              #   in Loop: Header=BB24_74 Depth=3
	end_block                               # label438:
	block   	
	local.get	17
	local.get	67
	i32.const	2
	i32.shl 
	local.tee	38
	i32.add 
	i32.load	0
	local.get	79
	i32.ne  
	br_if   	0                               # 0: down to label439
# %bb.78:                               #   in Loop: Header=BB24_74 Depth=3
	local.get	28
	local.get	15
	local.get	67
	i32.const	1
	i32.shl 
	i32.add 
	i32.load16_u	0
	i32.ne  
	br_if   	0                               # 0: down to label439
# %bb.79:                               #   in Loop: Header=BB24_74 Depth=3
	i32.const	0
	local.set	31
	local.get	13
	local.get	16
	local.get	38
	i32.add 
	i32.load	0
	i32.add 
	local.tee	77
	local.set	38
	local.get	76
	local.set	1
.LBB24_80:                              #   Parent Loop BB24_17 Depth=1
                                        #     Parent Loop BB24_50 Depth=2
                                        #       Parent Loop BB24_74 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	loop    	                                # label440:
	block   	
	local.get	28
	local.get	31
	i32.add 
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label441
# %bb.81:                               #   in Loop: Header=BB24_74 Depth=3
	i32.const	0
	local.set	30
	local.get	28
	local.set	36
.LBB24_82:                              #   Parent Loop BB24_17 Depth=1
                                        #     Parent Loop BB24_50 Depth=2
                                        #       Parent Loop BB24_74 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	block   	
	loop    	                                # label443:
	block   	
	local.get	31
	local.get	36
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label444
# %bb.83:                               #   in Loop: Header=BB24_74 Depth=3
	local.get	30
	local.get	31
	i32.sub 
	local.tee	38
	local.get	28
	i32.lt_u
	br_if   	2                               # 2: down to label442
	br      	9                               # 9: down to label423
.LBB24_84:                              #   in Loop: Header=BB24_82 Depth=4
	end_block                               # label444:
	local.get	1
	local.get	30
	i32.add 
	local.set	68
	local.get	38
	local.get	30
	i32.add 
	local.set	69
	local.get	36
	i32.const	-8
	i32.add 
	local.set	36
	local.get	30
	i32.const	8
	i32.add 
	local.set	30
	local.get	69
	i64.load	0:p2align=0
	local.get	68
	i64.load	0:p2align=0
	i64.eq  
	br_if   	0                               # 0: up to label443
	br      	4                               # 4: down to label439
.LBB24_85:                              #   Parent Loop BB24_17 Depth=1
                                        #     Parent Loop BB24_50 Depth=2
                                        #       Parent Loop BB24_74 Depth=3
                                        # =>      This Inner Loop Header: Depth=4
	end_loop
	end_block                               # label442:
	loop    	                                # label445:
	local.get	77
	local.get	38
	i32.add 
	i32.load8_u	0
	local.get	76
	local.get	38
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	3                               # 3: down to label439
# %bb.86:                               #   in Loop: Header=BB24_85 Depth=4
	local.get	38
	i32.const	1
	i32.add 
	local.tee	38
	local.get	28
	i32.ge_u
	br_if   	7                               # 7: down to label423
	br      	0                               # 0: up to label445
.LBB24_87:                              #   in Loop: Header=BB24_80 Depth=4
	end_loop
	end_block                               # label441:
	local.get	38
	i32.const	16
	i32.add 
	local.set	30
	local.get	1
	i32.const	16
	i32.add 
	local.set	36
	local.get	38
	v128.load	0:p2align=0
	local.set	39
	local.get	1
	v128.load	0:p2align=0
	local.set	40
	local.get	38
	i32.const	32
	i32.add 
	local.set	38
	local.get	1
	i32.const	32
	i32.add 
	local.set	1
	local.get	31
	i32.const	-32
	i32.add 
	local.set	31
	local.get	36
	v128.load	0:p2align=0
	local.get	30
	v128.load	0:p2align=0
	v128.xor
	local.get	40
	local.get	39
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label440
.LBB24_88:                              #   in Loop: Header=BB24_74 Depth=3
	end_loop
	end_block                               # label439:
	local.get	66
	i32.const	1
	i32.add 
	local.get	42
	i32.and 
	local.set	66
	local.get	75
	i32.const	1
	i32.add 
	local.tee	75
	local.get	21
	i32.ne  
	br_if   	0                               # 0: up to label437
.LBB24_89:                              #   in Loop: Header=BB24_50 Depth=2
	end_loop
	end_block                               # label436:
	local.get	48
	local.get	54
	i32.ge_u
	br_if   	4                               # 4: down to label419
# %bb.90:                               #   in Loop: Header=BB24_50 Depth=2
	local.get	20
	local.get	66
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	38
	i32.load	0
	br_if   	4                               # 4: down to label419
# %bb.91:                               #   in Loop: Header=BB24_50 Depth=2
	local.get	28
	local.get	47
	i32.add 
	local.tee	1
	local.get	14
	i32.gt_u
	br_if   	4                               # 4: down to label419
# %bb.92:                               #   in Loop: Header=BB24_50 Depth=2
	block   	
	local.get	78
	local.get	13
	i32.eq  
	br_if   	0                               # 0: down to label446
# %bb.93:                               #   in Loop: Header=BB24_50 Depth=2
	local.get	13
	local.get	47
	i32.add 
	local.get	76
	local.get	28
	call	copy_valid_utf8
	i32.eqz
	br_if   	5                               # 5: down to label419
.LBB24_94:                              #   in Loop: Header=BB24_50 Depth=2
	end_block                               # label446:
	local.get	16
	local.get	48
	i32.const	2
	i32.shl 
	local.tee	31
	i32.add 
	local.get	47
	i32.store	0
	local.get	17
	local.get	31
	i32.add 
	local.get	79
	i32.store	0
	local.get	15
	local.get	48
	i32.const	1
	i32.shl 
	i32.add 
	local.get	28
	i32.store16	0
	local.get	38
	local.get	48
	i32.const	1
	i32.add 
	local.tee	31
	i32.store	0
	local.get	48
	local.set	67
	local.get	1
	local.set	47
	local.get	31
	local.set	48
	br      	1                               # 1: down to label423
.LBB24_95:                              #   in Loop: Header=BB24_50 Depth=2
	end_block                               # label424:
	local.get	18
	local.get	19
	local.get	77
	i32.select
	local.get	70
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.set	67
.LBB24_96:                              #   in Loop: Header=BB24_50 Depth=2
	end_block                               # label423:
	local.get	72
	local.get	67
	i32.store	0
	i32.const	1
	local.set	69
	local.get	73
	i32.const	1
	i32.and 
	local.set	31
	local.get	37
	i32.const	32
	i32.add 
	local.set	38
	local.get	37
	i32.const	24
	i32.add 
	local.set	1
	local.get	37
	i32.const	12
	i32.add 
	local.set	72
	i32.const	0
	local.set	73
	local.get	31
	br_if   	0                               # 0: up to label421
.LBB24_97:                              #   in Loop: Header=BB24_17 Depth=1
	end_loop
	end_block                               # label420:
	local.get	18
	local.get	46
	i32.const	2
	i32.shl 
	local.tee	68
	i32.add 
	local.get	37
	i32.load	16
	i32.store	0
	local.get	19
	local.get	68
	i32.add 
	local.get	37
	i32.load	12
	i32.store	0
	local.get	24
	local.get	46
	i32.add 
	local.get	65
	i32.store8	0
	local.get	62
	i32.load	32
	local.tee	28
	local.get	61
	i32.ge_u
	br_if   	0                               # 0: down to label419
# %bb.98:                               #   in Loop: Header=BB24_17 Depth=1
	local.get	28
	local.set	31
.LBB24_99:                              #   Parent Loop BB24_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label448:
	block   	
	local.get	61
	local.get	31
	local.tee	38
	i32.ne  
	br_if   	0                               # 0: down to label449
# %bb.100:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	61
	local.set	38
	br      	2                               # 2: down to label447
.LBB24_101:                             #   in Loop: Header=BB24_99 Depth=2
	end_block                               # label449:
	block   	
	block   	
	local.get	0
	local.get	38
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	-10
	i32.add 
	br_table 	{3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0} # 1: down to label450
                                        # 3: down to label447
                                        # 0: down to label451
.LBB24_102:                             #   in Loop: Header=BB24_99 Depth=2
	end_block                               # label451:
	local.get	1
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label447
# %bb.103:                              #   in Loop: Header=BB24_99 Depth=2
	local.get	1
	i32.const	125
	i32.eq  
	br_if   	2                               # 2: down to label447
.LBB24_104:                             #   in Loop: Header=BB24_99 Depth=2
	end_block                               # label450:
	local.get	38
	i32.const	1
	i32.add 
	local.set	31
	local.get	1
	i32.const	9
	i32.ne  
	br_if   	0                               # 0: up to label448
.LBB24_105:                             #   in Loop: Header=BB24_17 Depth=1
	end_loop
	end_block                               # label447:
	local.get	38
	local.get	28
	i32.eq  
	br_if   	0                               # 0: down to label419
# %bb.106:                              #   in Loop: Header=BB24_17 Depth=1
	block   	
	block   	
	block   	
	local.get	38
	local.get	28
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label454
# %bb.107:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	0
	local.get	28
	i32.add 
	local.tee	1
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label454
# %bb.108:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	1
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label454
# %bb.109:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	1
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label454
# %bb.110:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	1
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label453
.LBB24_111:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label454:
	i32.const	1
	local.set	69
	local.get	28
	local.set	31
	block   	
	local.get	38
	local.get	28
	i32.le_u
	br_if   	0                               # 0: down to label455
# %bb.112:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	0
	local.get	28
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	45
	i32.ne  
	local.set	69
	local.get	28
	local.get	1
	i32.const	45
	i32.eq  
	i32.add 
	local.set	31
.LBB24_113:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label455:
	local.get	38
	local.get	31
	i32.le_u
	br_if   	2                               # 2: down to label419
# %bb.114:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	0
	local.get	31
	i32.add 
	local.tee	1
	i32.load8_u	0
	local.tee	30
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	246
	i32.lt_u
	br_if   	2                               # 2: down to label419
# %bb.115:                              #   in Loop: Header=BB24_17 Depth=1
	block   	
	local.get	31
	i32.const	1
	i32.add 
	local.get	38
	i32.ge_u
	br_if   	0                               # 0: down to label456
# %bb.116:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	30
	i32.const	255
	i32.and 
	i32.const	48
	i32.eq  
	br_if   	3                               # 3: down to label419
.LBB24_117:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label456:
	i32.const	2147483647
	i32.const	-2147483648
	local.get	69
	i32.select
	local.set	36
	local.get	38
	local.get	31
	i32.sub 
	local.set	30
	i32.const	0
	local.set	38
.LBB24_118:                             #   Parent Loop BB24_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label457:
	local.get	1
	i32.load8_u	0
	local.tee	31
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	246
	i32.lt_u
	br_if   	3                               # 3: down to label419
# %bb.119:                              #   in Loop: Header=BB24_118 Depth=2
	local.get	38
	local.get	36
	local.get	31
	i32.const	-48
	i32.add 
	local.tee	31
	i32.sub 
	i32.const	10
	i32.div_u
	i32.gt_u
	br_if   	3                               # 3: down to label419
# %bb.120:                              #   in Loop: Header=BB24_118 Depth=2
	local.get	1
	i32.const	1
	i32.add 
	local.set	1
	local.get	31
	local.get	38
	i32.const	10
	i32.mul 
	i32.add 
	local.set	38
	local.get	30
	i32.const	-1
	i32.add 
	local.tee	30
	br_if   	0                               # 0: up to label457
# %bb.121:                              #   in Loop: Header=BB24_17 Depth=1
	end_loop
	local.get	38
	i32.const	0
	local.get	38
	i32.sub 
	local.get	69
	i32.select
	local.tee	38
	br_if   	1                               # 1: down to label452
# %bb.122:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	0
	local.get	28
	i32.add 
	i32.load8_u	0
	i32.const	45
	i32.eq  
	br_if   	2                               # 2: down to label419
.LBB24_123:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label453:
	i32.const	0
	local.set	38
.LBB24_124:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label452:
	local.get	25
	local.get	68
	i32.add 
	local.get	38
	i32.store	0
	i32.const	-1
	local.set	38
	local.get	37
	i32.const	-1
	i32.store	8
	block   	
	local.get	62
	i32.load	44
	local.tee	1
	i32.const	-1
	i32.eq  
	br_if   	0                               # 0: down to label458
# %bb.125:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	37
	i32.const	0
	i32.store	4
	local.get	0
	local.get	61
	local.get	1
	local.get	37
	i32.const	4
	i32.add 
	call	scan_scalar_span
	i32.eqz
	br_if   	1                               # 1: down to label419
# %bb.126:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	0
	local.get	1
	local.get	37
	i32.load	4
	i32.const	-1
	local.get	37
	i32.const	8
	i32.add 
	call	parse_int32_token
	i32.eqz
	br_if   	1                               # 1: down to label419
# %bb.127:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	37
	i32.load	8
	local.set	38
.LBB24_128:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label458:
	local.get	26
	local.get	68
	i32.add 
	local.get	38
	i32.store	0
	local.get	43
	i32.eqz
	br_if   	1                               # 1: down to label418
# %bb.129:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	35
	local.get	68
	i32.add 
	local.get	0
	local.get	62
	call	raw_term_content_hash
	local.tee	30
	i32.store	0
	local.get	34
	i32.eqz
	br_if   	4                               # 4: down to label415
# %bb.130:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	34
	local.set	1
	local.get	30
	local.set	38
.LBB24_131:                             #   Parent Loop BB24_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label459:
	block   	
	local.get	33
	local.get	38
	local.get	50
	i32.and 
	local.tee	31
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	36
	i32.load	0
	local.tee	38
	br_if   	0                               # 0: down to label460
# %bb.132:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	36
	local.get	46
	i32.const	1
	i32.add 
	i32.store	0
	br      	6                               # 6: down to label415
.LBB24_133:                             #   in Loop: Header=BB24_131 Depth=2
	end_block                               # label460:
	block   	
	local.get	38
	i32.const	-1
	i32.add 
	local.tee	38
	local.get	46
	i32.lt_u
	br_if   	0                               # 0: down to label461
# %bb.134:
	i32.const	-3
	local.set	38
	br      	10                              # 10: down to label393
.LBB24_135:                             #   in Loop: Header=BB24_131 Depth=2
	end_block                               # label461:
	block   	
	local.get	35
	local.get	38
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.get	30
	i32.ne  
	br_if   	0                               # 0: down to label462
# %bb.136:                              #   in Loop: Header=BB24_131 Depth=2
	local.get	0
	local.get	62
	local.get	2
	local.get	38
	i32.const	68
	i32.mul 
	i32.add 
	local.get	38
	local.get	63
	i32.eq  
	call	raw_term_content_tokens_equal
	i32.eqz
	br_if   	0                               # 0: down to label462
# %bb.137:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	32
	i32.eqz
	br_if   	4                               # 4: down to label417
# %bb.138:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	32
	local.get	32
	i32.load	8
	i32.const	1
	i32.add 
	i32.store	8
	br      	4                               # 4: down to label417
.LBB24_139:                             #   in Loop: Header=BB24_131 Depth=2
	end_block                               # label462:
	local.get	31
	i32.const	1
	i32.add 
	local.set	38
	local.get	1
	i32.const	-1
	i32.add 
	local.tee	1
	br_if   	0                               # 0: up to label459
	br      	5                               # 5: down to label415
.LBB24_140:
	end_loop
	end_block                               # label419:
	local.get	12
	local.get	46
	i32.store	0
	i32.const	-5
	local.set	38
	br      	7                               # 7: down to label393
.LBB24_141:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label418:
	block   	
	local.get	63
	i32.const	-1
	i32.eq  
	br_if   	0                               # 0: down to label463
# %bb.142:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	0
	local.get	62
	local.get	2
	local.get	63
	i32.const	68
	i32.mul 
	i32.add 
	i32.const	1
	call	raw_term_content_tokens_equal
	i32.eqz
	br_if   	0                               # 0: down to label463
# %bb.143:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	37
	i32.const	80
	i32.add 
	local.get	46
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	local.get	37
	i32.const	80
	i32.add 
	local.get	63
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	i32.load	0
	i32.store	0
	local.get	63
	local.set	38
	br      	1                               # 1: down to label417
.LBB24_144:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label463:
	local.get	0
	local.get	62
	call	raw_term_content_quick_signature
	local.set	30
	local.get	53
	local.set	1
	local.get	59
	local.set	38
	local.get	46
	i32.const	0
	local.get	46
	i32.const	-4
	i32.add 
	local.tee	31
	local.get	31
	local.get	46
	i32.gt_u
	i32.select
	local.tee	36
	i32.le_u
	br_if   	1                               # 1: down to label416
.LBB24_145:                             #   Parent Loop BB24_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label465:
	block   	
	local.get	37
	i32.const	80
	i32.add 
	local.get	38
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	i32.load	0
	local.get	30
	i32.ne  
	br_if   	0                               # 0: down to label466
# %bb.146:                              #   in Loop: Header=BB24_145 Depth=2
	local.get	0
	local.get	62
	local.get	1
	local.get	63
	local.get	38
	i32.eq  
	call	raw_term_content_tokens_equal
	br_if   	2                               # 2: down to label464
.LBB24_147:                             #   in Loop: Header=BB24_145 Depth=2
	end_block                               # label466:
	local.get	1
	i32.const	-68
	i32.add 
	local.set	1
	local.get	38
	local.get	36
	i32.gt_u
	local.set	31
	local.get	38
	i32.const	-1
	i32.add 
	local.set	38
	local.get	31
	i32.eqz
	br_if   	3                               # 3: down to label416
	br      	0                               # 0: up to label465
.LBB24_148:                             #   in Loop: Header=BB24_17 Depth=1
	end_loop
	end_block                               # label464:
	local.get	37
	i32.const	80
	i32.add 
	local.get	46
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	local.get	30
	i32.store	0
.LBB24_149:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label417:
	block   	
	block   	
	local.get	52
	br_if   	0                               # 0: down to label468
# %bb.150:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	64
	local.set	31
	br      	1                               # 1: down to label467
.LBB24_151:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label468:
	i32.const	4
	local.set	31
	local.get	60
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label467
# %bb.152:                              #   in Loop: Header=BB24_17 Depth=1
	i32.const	4
	local.get	64
	local.get	60
	i32.const	3
	i32.eq  
	i32.select
	local.set	31
	local.get	60
	i32.const	1
	i32.add 
	local.set	60
.LBB24_153:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label467:
	local.get	6
	local.get	68
	i32.const	2
	i32.shl 
	i32.add 
	local.get	6
	local.get	38
	i32.const	4
	i32.shl 
	i32.add 
	v128.load	0:p2align=2
	v128.store	0:p2align=2
	local.get	9
	local.get	68
	i32.add 
	local.get	9
	local.get	38
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.store	0
	local.get	45
	i32.const	1
	i32.add 
	local.set	45
	br      	2                               # 2: down to label414
.LBB24_154:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label416:
	local.get	37
	i32.const	80
	i32.add 
	local.get	46
	i32.const	3
	i32.and 
	i32.const	2
	i32.shl 
	i32.or  
	local.get	30
	i32.store	0
.LBB24_155:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label415:
	local.get	37
	i32.const	0
	i32.store	4
	local.get	37
	i32.const	0
	i32.store	0
	block   	
	local.get	0
	local.get	62
	local.get	4
	local.get	5
	local.get	37
	i32.const	108
	i32.add 
	local.get	37
	i32.const	4
	i32.add 
	local.get	37
	local.get	29
	local.get	32
	call	encode_term_content_token_binary_row
	br_if   	0                               # 0: down to label469
.LBB24_156:                             #   Parent Loop BB24_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label470:
	local.get	37
	local.get	44
	i32.store	108
	i32.const	-2
	local.set	38
	local.get	5
	i32.const	2147483646
	i32.gt_u
	br_if   	5                               # 5: down to label393
# %bb.157:                              #   in Loop: Header=BB24_156 Depth=2
	local.get	4
	local.get	5
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	31
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	5                               # 5: down to label393
# %bb.158:                              #   in Loop: Header=BB24_156 Depth=2
	i32.const	0
	i32.load	heap_ptr
	local.get	31
	local.get	4
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	5                               # 5: down to label393
# %bb.159:                              #   in Loop: Header=BB24_156 Depth=2
	i32.const	2147483647
	local.get	5
	i32.const	1
	i32.shr_u
	local.tee	30
	i32.const	1048576
	local.get	30
	i32.const	1048576
	i32.gt_u
	i32.select
	local.tee	30
	local.get	5
	i32.add 
	local.get	5
	local.get	30
	i32.const	2147483647
	i32.xor 
	i32.gt_u
	i32.select
	local.tee	5
	local.get	31
	i32.sub 
	i32.const	7
	i32.add 
	local.set	30
	local.get	1
	local.set	31
	block   	
	local.get	1
	br_if   	0                               # 0: down to label471
# %bb.160:                              #   in Loop: Header=BB24_156 Depth=2
	i32.const	__heap_base
	local.set	31
	i32.const	0
	i32.const	__heap_base
	i32.store	heap_ptr
.LBB24_161:                             #   in Loop: Header=BB24_156 Depth=2
	end_block                               # label471:
	local.get	31
	i32.const	7
	i32.add 
	i32.const	-8
	i32.and 
	local.tee	31
	local.get	30
	i32.const	-8
	i32.and 
	local.tee	30
	i32.const	-1
	i32.xor 
	i32.gt_u
	br_if   	5                               # 5: down to label393
# %bb.162:                              #   in Loop: Header=BB24_156 Depth=2
	block   	
	local.get	31
	local.get	30
	i32.add 
	local.tee	30
	i32.const	16
	i32.shr_u
	local.get	30
	i32.const	65528
	i32.and 
	i32.const	0
	i32.ne  
	i32.add 
	local.tee	36
	memory.size	0
	local.tee	28
	i32.le_u
	br_if   	0                               # 0: down to label472
# %bb.163:                              #   in Loop: Header=BB24_156 Depth=2
	local.get	36
	local.get	28
	i32.sub 
	memory.grow	0
	i32.const	0
	i32.lt_s
	br_if   	6                               # 6: down to label393
.LBB24_164:                             #   in Loop: Header=BB24_156 Depth=2
	end_block                               # label472:
	i32.const	0
	local.get	30
	i32.store	heap_ptr
	local.get	31
	i32.eqz
	br_if   	5                               # 5: down to label393
# %bb.165:                              #   in Loop: Header=BB24_156 Depth=2
	local.get	31
	local.get	1
	i32.ne  
	br_if   	5                               # 5: down to label393
# %bb.166:                              #   in Loop: Header=BB24_156 Depth=2
	i32.const	0
	local.get	5
	i32.store	last_content_capacity
	local.get	0
	local.get	62
	local.get	4
	local.get	5
	local.get	37
	i32.const	108
	i32.add 
	local.get	37
	i32.const	4
	i32.add 
	local.get	37
	local.get	29
	local.get	32
	call	encode_term_content_token_binary_row
	i32.eqz
	br_if   	0                               # 0: up to label470
.LBB24_167:                             #   in Loop: Header=BB24_17 Depth=1
	end_loop
	end_block                               # label469:
	local.get	37
	i32.load	0
	local.tee	69
	i32.const	-1640531535
	i32.mul 
	local.get	37
	i32.load	4
	local.tee	36
	i32.xor 
	local.tee	38
	i32.const	16
	i32.shr_u
	local.get	38
	i32.xor 
	local.get	41
	i32.and 
	local.set	1
	local.get	37
	i32.load	108
	local.tee	66
	local.get	44
	i32.sub 
	local.set	28
	local.get	8
	local.set	31
.LBB24_168:                             #   Parent Loop BB24_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	block   	
	block   	
	block   	
	block   	
	loop    	                                # label478:
	local.get	7
	local.get	1
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	local.tee	38
	i32.eqz
	br_if   	1                               # 1: down to label477
# %bb.169:                              #   in Loop: Header=BB24_168 Depth=2
	block   	
	local.get	38
	i32.const	-1
	i32.add 
	local.tee	38
	local.get	46
	i32.lt_u
	br_if   	0                               # 0: down to label479
# %bb.170:
	i32.const	-3
	local.set	38
	br      	10                              # 10: down to label393
.LBB24_171:                             #   in Loop: Header=BB24_168 Depth=2
	end_block                               # label479:
	block   	
	local.get	6
	local.get	38
	i32.const	4
	i32.shl 
	i32.add 
	local.tee	30
	i32.load	8
	local.get	36
	i32.ne  
	br_if   	0                               # 0: down to label480
# %bb.172:                              #   in Loop: Header=BB24_168 Depth=2
	local.get	30
	i32.load	12
	local.get	69
	i32.ne  
	br_if   	0                               # 0: down to label480
# %bb.173:                              #   in Loop: Header=BB24_168 Depth=2
	local.get	30
	i32.load	4
	local.get	28
	i32.ne  
	br_if   	0                               # 0: down to label480
# %bb.174:                              #   in Loop: Header=BB24_168 Depth=2
	local.get	4
	local.get	30
	i32.load	0
	local.tee	30
	local.get	44
	local.get	28
	call	content_bytes_equal
	br_if   	3                               # 3: down to label476
.LBB24_175:                             #   in Loop: Header=BB24_168 Depth=2
	end_block                               # label480:
	local.get	1
	i32.const	1
	i32.add 
	local.get	41
	i32.and 
	local.set	1
	local.get	31
	i32.const	-1
	i32.add 
	local.tee	31
	br_if   	0                               # 0: up to label478
.LBB24_176:                             #   in Loop: Header=BB24_17 Depth=1
	end_loop
	end_block                               # label477:
	i32.const	-3
	local.set	38
	local.get	7
	local.get	1
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	75
	i32.load	0
	br_if   	7                               # 7: down to label393
# %bb.177:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	49
	i32.const	-1
	i32.eq  
	br_if   	7                               # 7: down to label393
# %bb.178:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	6
	local.get	68
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	38
	local.get	69
	i32.store	12
	local.get	38
	local.get	36
	i32.store	8
	local.get	38
	local.get	28
	i32.store	4
	local.get	38
	local.get	44
	i32.store	0
	local.get	9
	local.get	68
	i32.add 
	local.get	49
	i32.store	0
	i32.const	0
	local.set	31
	i32.const	0
	local.get	28
	i32.const	-4
	i32.add 
	local.tee	38
	local.get	38
	local.get	28
	i32.gt_u
	i32.select
	local.set	68
	local.get	4
	local.get	44
	i32.add 
	local.set	67
	i32.const	0
	local.set	30
	local.get	66
	local.get	44
	i32.eq  
	br_if   	2                               # 2: down to label474
# %bb.179:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	28
	i32.const	3
	i32.gt_u
	br_if   	1                               # 1: down to label475
# %bb.180:                              #   in Loop: Header=BB24_17 Depth=1
	i32.const	0
	local.set	38
	local.get	67
	local.set	1
	local.get	28
	local.set	36
	i32.const	0
	local.set	30
.LBB24_181:                             #   Parent Loop BB24_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label481:
	local.get	1
	i32.load8_u	0
	local.get	38
	i32.shl 
	local.get	30
	i32.or  
	local.set	30
	local.get	1
	i32.const	1
	i32.add 
	local.set	1
	local.get	38
	i32.const	8
	i32.add 
	local.set	38
	local.get	36
	i32.const	-1
	i32.add 
	local.tee	36
	br_if   	0                               # 0: up to label481
	br      	3                               # 3: down to label474
.LBB24_182:                             #   in Loop: Header=BB24_17 Depth=1
	end_loop
	end_block                               # label476:
	local.get	6
	local.get	68
	i32.const	2
	i32.shl 
	i32.add 
	local.tee	1
	local.get	69
	i32.store	12
	local.get	1
	local.get	36
	i32.store	8
	local.get	1
	local.get	28
	i32.store	4
	local.get	1
	local.get	30
	i32.store	0
	local.get	9
	local.get	68
	i32.add 
	local.get	9
	local.get	38
	i32.const	2
	i32.shl 
	i32.add 
	i32.load	0
	i32.store	0
	local.get	37
	local.get	44
	i32.store	108
	i32.const	0
	local.set	60
	br      	2                               # 2: down to label473
.LBB24_183:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label475:
	local.get	67
	i32.load	0:p2align=0
	local.set	30
.LBB24_184:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label474:
	local.get	11
	local.get	49
	i32.const	12
	i32.mul 
	i32.add 
	local.tee	69
	local.get	30
	i32.store	0
	block   	
	local.get	28
	local.get	68
	i32.const	1
	i32.shr_u
	local.tee	1
	i32.le_u
	br_if   	0                               # 0: down to label482
# %bb.185:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	67
	local.get	1
	i32.add 
	local.set	38
	block   	
	local.get	28
	local.get	1
	i32.sub 
	local.tee	30
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label483
# %bb.186:                              #   in Loop: Header=BB24_17 Depth=1
	i32.const	0
	local.set	1
	i32.const	0
	local.set	31
.LBB24_187:                             #   Parent Loop BB24_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label484:
	local.get	38
	i32.load8_u	0
	local.get	1
	i32.shl 
	local.get	31
	i32.or  
	local.set	31
	local.get	38
	i32.const	1
	i32.add 
	local.set	38
	local.get	1
	i32.const	8
	i32.add 
	local.set	1
	local.get	30
	i32.const	-1
	i32.add 
	local.tee	30
	br_if   	0                               # 0: up to label484
	br      	2                               # 2: down to label482
.LBB24_188:                             #   in Loop: Header=BB24_17 Depth=1
	end_loop
	end_block                               # label483:
	local.get	38
	i32.load	0:p2align=0
	local.set	31
.LBB24_189:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label482:
	local.get	69
	i32.const	4
	i32.add 
	local.get	31
	i32.store	0
	i32.const	0
	local.set	60
	i32.const	0
	local.set	31
	block   	
	local.get	28
	local.get	68
	i32.le_u
	br_if   	0                               # 0: down to label485
# %bb.190:                              #   in Loop: Header=BB24_17 Depth=1
	block   	
	local.get	28
	local.get	68
	i32.sub 
	local.tee	1
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label486
# %bb.191:                              #   in Loop: Header=BB24_17 Depth=1
	local.get	4
	local.get	66
	i32.add 
	local.set	36
	i32.const	0
	local.set	38
	i32.const	0
	local.get	1
	i32.sub 
	local.set	1
	i32.const	0
	local.set	31
.LBB24_192:                             #   Parent Loop BB24_17 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label487:
	local.get	36
	local.get	1
	i32.add 
	i32.load8_u	0
	local.get	38
	i32.shl 
	local.get	31
	i32.or  
	local.set	31
	local.get	38
	i32.const	8
	i32.add 
	local.set	38
	local.get	1
	i32.const	1
	i32.add 
	local.tee	30
	local.set	1
	local.get	30
	br_if   	0                               # 0: up to label487
	br      	2                               # 2: down to label485
.LBB24_193:                             #   in Loop: Header=BB24_17 Depth=1
	end_loop
	end_block                               # label486:
	local.get	67
	local.get	68
	i32.add 
	i32.load	0:p2align=0
	local.set	31
.LBB24_194:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label485:
	local.get	69
	i32.const	8
	i32.add 
	local.get	31
	i32.store	0
	local.get	75
	local.get	46
	i32.const	1
	i32.add 
	i32.store	0
	local.get	49
	i32.const	1
	i32.add 
	local.set	49
	local.get	66
	local.set	44
.LBB24_195:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label473:
	local.get	64
	local.set	31
.LBB24_196:                             #   in Loop: Header=BB24_17 Depth=1
	end_block                               # label414:
	local.get	53
	i32.const	68
	i32.add 
	local.set	53
	local.get	59
	i32.const	1
	i32.add 
	local.set	59
	local.get	46
	i32.const	1
	i32.add 
	local.set	46
	local.get	37
	i32.const	52
	i32.add 
	local.get	37
	i32.load	48
	call	next_term_row
	local.tee	1
	i32.const	0
	i32.gt_s
	br_if   	0                               # 0: up to label398
.LBB24_197:
	end_loop
	end_block                               # label397:
	i32.const	-1
	local.set	38
	local.get	1
	i32.const	0
	i32.lt_s
	br_if   	0                               # 0: down to label393
# %bb.198:
	local.get	10
	local.get	49
	i32.store	0
	local.get	12
	local.get	46
	i32.store	0
	local.get	22
	local.get	48
	i32.store	0
	local.get	23
	local.get	47
	i32.store	0
	local.get	27
	local.get	45
	i32.store	0
	local.get	44
	local.set	38
.LBB24_199:
	end_block                               # label393:
	local.get	37
	i32.const	112
	i32.add 
	global.set	__stack_pointer
	local.get	38
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.next_term_bank,"",@
	.type	next_term_bank,@function        # -- Begin function next_term_bank
next_term_bank:                         # @next_term_bank
	.functype	next_term_bank (i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	1
	block   	
	local.get	0
	i32.load	16
	local.tee	2
	local.get	0
	i32.load	12
	local.tee	3
	i32.ge_u
	br_if   	0                               # 0: down to label488
# %bb.1:
	local.get	0
	i32.const	8
	i32.add 
	local.set	4
	local.get	0
	i32.load	4
	local.tee	5
	i32.const	4
	i32.add 
	local.set	6
	local.get	0
	i32.load	20
	local.set	7
.LBB25_2:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB25_12 Depth 2
                                        #     Child Loop BB25_20 Depth 2
                                        #     Child Loop BB25_29 Depth 2
	loop    	                                # label489:
	local.get	0
	local.get	2
	i32.const	1
	i32.add 
	local.tee	8
	i32.store	16
	local.get	2
	i32.const	3
	i32.shl 
	local.set	9
	block   	
	block   	
	local.get	5
	br_if   	0                               # 0: down to label491
# %bb.3:                                #   in Loop: Header=BB25_2 Depth=1
	i32.const	0
	local.set	2
	br      	1                               # 1: down to label490
.LBB25_4:                               #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label491:
	local.get	5
	local.get	9
	i32.add 
	i32.load	0
	local.set	2
.LBB25_5:                               #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label490:
	block   	
	local.get	2
	local.get	7
	i32.ge_u
	br_if   	0                               # 0: down to label492
# %bb.6:
	i32.const	-1
	return
.LBB25_7:                               #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label492:
	block   	
	local.get	4
	i32.load	0
	local.tee	10
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label493
# %bb.8:
	i32.const	-1
	return
.LBB25_9:                               #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label493:
	block   	
	local.get	6
	local.get	9
	i32.add 
	local.get	4
	local.get	5
	i32.select
	i32.load	0
	local.tee	9
	local.get	10
	local.get	2
	i32.sub 
	i32.le_u
	br_if   	0                               # 0: down to label494
# %bb.10:
	i32.const	-1
	return
.LBB25_11:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label494:
	local.get	0
	local.get	9
	local.get	2
	i32.add 
	local.tee	7
	i32.store	20
	local.get	0
	i32.load	0
	local.set	10
	block   	
	local.get	2
	local.get	7
	i32.ge_u
	br_if   	0                               # 0: down to label495
.LBB25_12:                              #   Parent Loop BB25_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label496:
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	1
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label495
# %bb.13:                               #   in Loop: Header=BB25_12 Depth=2
	i32.const	1
	local.get	1
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label495
# %bb.14:                               #   in Loop: Header=BB25_12 Depth=2
	i32.const	-1
	local.set	1
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	local.get	9
	i32.const	-1
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label496
	br      	3                               # 3: down to label488
.LBB25_15:                              #   in Loop: Header=BB25_2 Depth=1
	end_loop
	end_block                               # label495:
	block   	
	local.get	2
	local.get	7
	i32.lt_u
	br_if   	0                               # 0: down to label497
# %bb.16:
	i32.const	-1
	return
.LBB25_17:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label497:
	block   	
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.eq  
	br_if   	0                               # 0: down to label498
# %bb.18:
	i32.const	-1
	return
.LBB25_19:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label498:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	local.get	7
	i32.ge_u
	br_if   	0                               # 0: down to label499
.LBB25_20:                              #   Parent Loop BB25_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label500:
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	9
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label499
# %bb.21:                               #   in Loop: Header=BB25_20 Depth=2
	i32.const	1
	local.get	9
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label499
# %bb.22:                               #   in Loop: Header=BB25_20 Depth=2
	local.get	7
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label500
# %bb.23:
	end_loop
	i32.const	-1
	return
.LBB25_24:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label499:
	block   	
	local.get	2
	local.get	7
	i32.lt_u
	br_if   	0                               # 0: down to label501
# %bb.25:
	i32.const	-1
	return
.LBB25_26:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label501:
	block   	
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.eq  
	br_if   	0                               # 0: down to label502
# %bb.27:
	local.get	0
	local.get	2
	i32.store	24
	i32.const	1
	return
.LBB25_28:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label502:
	block   	
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	local.get	7
	i32.ge_u
	br_if   	0                               # 0: down to label504
.LBB25_29:                              #   Parent Loop BB25_2 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label505:
	local.get	10
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	9
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label504
# %bb.30:                               #   in Loop: Header=BB25_29 Depth=2
	i32.const	1
	local.get	9
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label504
# %bb.31:                               #   in Loop: Header=BB25_29 Depth=2
	local.get	7
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label505
	br      	2                               # 2: down to label503
.LBB25_32:                              #   in Loop: Header=BB25_2 Depth=1
	end_loop
	end_block                               # label504:
	i32.const	-1
	local.set	1
	local.get	2
	local.get	7
	i32.ne  
	br_if   	2                               # 2: down to label488
.LBB25_33:                              #   in Loop: Header=BB25_2 Depth=1
	end_block                               # label503:
	i32.const	0
	local.set	1
	local.get	8
	local.set	2
	local.get	8
	local.get	3
	i32.ne  
	br_if   	0                               # 0: up to label489
.LBB25_34:
	end_loop
	end_block                               # label488:
	local.get	1
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_row_single_pass,"",@
	.type	parse_row_single_pass,@function # -- Begin function parse_row_single_pass
parse_row_single_pass:                  # @parse_row_single_pass
	.functype	parse_row_single_pass (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	12
	global.set	__stack_pointer
	i32.const	0
	local.set	13
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label506
# %bb.1:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label506
# %bb.2:
	local.get	3
	v128.const	0, 0
	local.tee	14
	v128.store	0:p2align=2
	local.get	3
	local.get	14
	v128.store	48:p2align=2
	local.get	3
	i32.const	32
	i32.add 
	i64.const	0
	i64.store	0:p2align=2
	local.get	3
	i32.const	16
	i32.add 
	local.get	14
	v128.store	0:p2align=2
	local.get	3
	i32.const	40
	i32.add 
	i64.const	-4294967296
	i64.store	0:p2align=2
	local.get	3
	i32.const	64
	i32.add 
	local.tee	15
	i32.const	0
	i32.store	0
	block   	
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label507
# %bb.3:
	local.get	11
	i32.const	3
	i32.store	0
.LBB26_4:
	end_block                               # label507:
	local.get	3
	i32.const	48
	i32.add 
	local.set	16
	i32.const	0
	local.get	7
	local.get	9
	i32.sub 
	local.tee	9
	local.get	9
	local.get	7
	i32.gt_u
	i32.select
	local.set	17
	local.get	3
	i32.const	56
	i32.add 
	local.tee	18
	i32.const	0
	local.get	4
	i32.select
	local.set	19
	local.get	0
	i32.const	5
	i32.add 
	local.set	20
	local.get	0
	i32.const	4
	i32.add 
	local.set	21
	local.get	0
	i32.const	3
	i32.add 
	local.set	22
	local.get	3
	i32.const	60
	i32.add 
	local.set	23
	local.get	0
	i32.const	-1
	i32.add 
	local.set	24
	local.get	2
	i32.const	1
	i32.add 
	local.set	2
	i32.const	0
	local.set	25
.LBB26_5:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB26_7 Depth 2
                                        #     Child Loop BB26_61 Depth 2
                                        #       Child Loop BB26_67 Depth 3
                                        #       Child Loop BB26_73 Depth 3
                                        #       Child Loop BB26_76 Depth 3
                                        #       Child Loop BB26_78 Depth 3
                                        #       Child Loop BB26_82 Depth 3
                                        #     Child Loop BB26_46 Depth 2
                                        #     Child Loop BB26_20 Depth 2
                                        #     Child Loop BB26_131 Depth 2
                                        #     Child Loop BB26_140 Depth 2
	loop    	                                # label508:
	i32.const	0
	local.set	13
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label506
# %bb.6:                                #   in Loop: Header=BB26_5 Depth=1
	local.get	0
	local.get	2
	i32.add 
	local.set	9
.LBB26_7:                               #   Parent Loop BB26_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label510:
	local.get	0
	local.get	2
	i32.add 
	local.tee	26
	i32.load8_u	0
	local.tee	27
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label509
# %bb.8:                                #   in Loop: Header=BB26_7 Depth=2
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label509
# %bb.9:                                #   in Loop: Header=BB26_7 Depth=2
	local.get	9
	i32.const	1
	i32.add 
	local.set	9
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label510
	br      	3                               # 3: down to label506
.LBB26_10:                              #   in Loop: Header=BB26_5 Depth=1
	end_loop
	end_block                               # label509:
	local.get	1
	local.get	2
	i32.le_u
	br_if   	1                               # 1: down to label506
# %bb.11:                               #   in Loop: Header=BB26_5 Depth=1
	block   	
	local.get	27
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: down to label511
# %bb.12:
	local.get	5
	local.get	2
	i32.const	1
	i32.add 
	i32.store	0
	local.get	3
	i32.load	4
	i32.const	0
	i32.ne  
	local.get	10
	i32.eqz
	local.get	25
	i32.const	8
	i32.eq  
	i32.or  
	i32.and 
	local.set	13
	br      	2                               # 2: down to label506
.LBB26_13:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label511:
	block   	
	local.get	10
	i32.eqz
	br_if   	0                               # 0: down to label512
# %bb.14:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	25
	i32.const	7
	i32.gt_u
	br_if   	2                               # 2: down to label506
.LBB26_15:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label512:
	local.get	12
	i32.const	0
	i32.store	12
	block   	
	block   	
	local.get	11
	i32.eqz
	br_if   	0                               # 0: down to label514
# %bb.16:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	25
	i32.const	1
	i32.gt_u
	br_if   	0                               # 0: down to label514
# %bb.17:                               #   in Loop: Header=BB26_5 Depth=1
	i32.const	0
	local.set	13
	local.get	27
	i32.const	34
	i32.ne  
	br_if   	3                               # 3: down to label506
# %bb.18:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	9
	local.get	1
	i32.ge_u
	br_if   	3                               # 3: down to label506
# %bb.19:                               #   in Loop: Header=BB26_5 Depth=1
	i32.const	0
	local.set	28
.LBB26_20:                              #   Parent Loop BB26_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label515:
	block   	
	block   	
	local.get	9
	i32.const	8
	i32.add 
	local.tee	4
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label517
# %bb.21:                               #   in Loop: Header=BB26_20 Depth=2
	local.get	9
	local.set	4
	br      	1                               # 1: down to label516
.LBB26_22:                              #   in Loop: Header=BB26_20 Depth=2
	end_block                               # label517:
	local.get	0
	local.get	9
	i32.add 
	local.set	27
	local.get	4
	local.set	9
	local.get	27
	i64.load	0:p2align=0
	local.tee	29
	i64.const	-1
	i64.xor 
	local.get	29
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	29
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	local.get	29
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	29
	i64.eqz
	br_if   	1                               # 1: up to label515
# %bb.23:                               #   in Loop: Header=BB26_20 Depth=2
	local.get	29
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	4
	i32.add 
	i32.const	-8
	i32.add 
	local.set	4
.LBB26_24:                              #   in Loop: Header=BB26_20 Depth=2
	end_block                               # label516:
	i32.const	0
	local.set	13
	local.get	4
	local.get	1
	i32.ge_u
	br_if   	4                               # 4: down to label506
# %bb.25:                               #   in Loop: Header=BB26_20 Depth=2
	block   	
	block   	
	block   	
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	local.tee	27
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label520
# %bb.26:                               #   in Loop: Header=BB26_20 Depth=2
	local.get	4
	i32.const	1
	i32.add 
	local.tee	9
	local.get	1
	i32.ge_u
	br_if   	7                               # 7: down to label506
# %bb.27:                               #   in Loop: Header=BB26_20 Depth=2
	block   	
	block   	
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 1, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 9, 1, 9, 9, 9, 9, 9, 1, 9, 9, 9, 1, 9, 9, 9, 9, 9, 9, 9, 1, 9, 9, 9, 1, 9, 1, 0, 9} # 9: down to label506
                                        # 1: down to label521
                                        # 0: down to label522
.LBB26_28:                              #   in Loop: Header=BB26_20 Depth=2
	end_block                               # label522:
	local.get	4
	i32.const	6
	i32.add 
	local.tee	9
	local.get	1
	i32.gt_u
	br_if   	8                               # 8: down to label506
# %bb.29:                               #   in Loop: Header=BB26_20 Depth=2
	i32.const	1
	local.set	28
	local.get	4
	i32.const	2
	i32.add 
	local.tee	27
	local.get	9
	i32.ge_u
	br_if   	2                               # 2: down to label519
# %bb.30:                               #   in Loop: Header=BB26_20 Depth=2
	block   	
	local.get	0
	local.get	27
	i32.add 
	i32.load8_u	0
	local.tee	27
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label523
# %bb.31:                               #   in Loop: Header=BB26_20 Depth=2
	local.get	27
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	9                               # 9: down to label506
.LBB26_32:                              #   in Loop: Header=BB26_20 Depth=2
	end_block                               # label523:
	block   	
	local.get	22
	local.get	4
	i32.add 
	i32.load8_u	0
	local.tee	27
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label524
# %bb.33:                               #   in Loop: Header=BB26_20 Depth=2
	local.get	27
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	9                               # 9: down to label506
.LBB26_34:                              #   in Loop: Header=BB26_20 Depth=2
	end_block                               # label524:
	block   	
	local.get	21
	local.get	4
	i32.add 
	i32.load8_u	0
	local.tee	27
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label525
# %bb.35:                               #   in Loop: Header=BB26_20 Depth=2
	local.get	27
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	9                               # 9: down to label506
.LBB26_36:                              #   in Loop: Header=BB26_20 Depth=2
	end_block                               # label525:
	local.get	20
	local.get	4
	i32.add 
	i32.load8_u	0
	local.tee	4
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label519
# %bb.37:                               #   in Loop: Header=BB26_20 Depth=2
	local.get	4
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label519
	br      	8                               # 8: down to label506
.LBB26_38:                              #   in Loop: Header=BB26_20 Depth=2
	end_block                               # label521:
	local.get	4
	i32.const	2
	i32.add 
	local.set	9
	i32.const	1
	local.set	28
	br      	1                               # 1: down to label519
.LBB26_39:                              #   in Loop: Header=BB26_20 Depth=2
	end_block                               # label520:
	local.get	27
	i32.const	32
	i32.lt_u
	br_if   	6                               # 6: down to label506
# %bb.40:                               #   in Loop: Header=BB26_20 Depth=2
	local.get	4
	i32.const	1
	i32.add 
	local.set	9
	local.get	27
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label518
.LBB26_41:                              #   in Loop: Header=BB26_20 Depth=2
	end_block                               # label519:
	local.get	9
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label515
	br      	5                               # 5: down to label506
.LBB26_42:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label518:
	end_loop
	local.get	12
	local.get	9
	i32.store	12
	local.get	28
	br_if   	1                               # 1: down to label513
# %bb.43:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	11
	local.get	11
	i32.load	0
	i32.const	-2
	local.get	25
	i32.rotl
	i32.and 
	i32.store	0
	br      	1                               # 1: down to label513
.LBB26_44:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label514:
	block   	
	block   	
	block   	
	local.get	25
	i32.const	-3
	i32.and 
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label528
# %bb.45:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	2
	local.set	27
.LBB26_46:                              #   Parent Loop BB26_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	block   	
	loop    	                                # label530:
	block   	
	local.get	1
	local.get	27
	local.tee	9
	i32.ne  
	br_if   	0                               # 0: down to label531
# %bb.47:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	1
	local.set	9
	br      	2                               # 2: down to label529
.LBB26_48:                              #   in Loop: Header=BB26_46 Depth=2
	end_block                               # label531:
	block   	
	block   	
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.tee	4
	i32.const	-10
	i32.add 
	br_table 	{3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0} # 1: down to label532
                                        # 3: down to label529
                                        # 0: down to label533
.LBB26_49:                              #   in Loop: Header=BB26_46 Depth=2
	end_block                               # label533:
	local.get	4
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label529
# %bb.50:                               #   in Loop: Header=BB26_46 Depth=2
	local.get	4
	i32.const	125
	i32.eq  
	br_if   	2                               # 2: down to label529
.LBB26_51:                              #   in Loop: Header=BB26_46 Depth=2
	end_block                               # label532:
	local.get	9
	i32.const	1
	i32.add 
	local.set	27
	local.get	4
	i32.const	9
	i32.ne  
	br_if   	0                               # 0: up to label530
.LBB26_52:                              #   in Loop: Header=BB26_5 Depth=1
	end_loop
	end_block                               # label529:
	local.get	9
	local.get	2
	i32.ne  
	br_if   	1                               # 1: down to label527
# %bb.53:
	i32.const	0
	local.set	13
	br      	5                               # 5: down to label506
.LBB26_54:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label528:
	local.get	25
	i32.const	5
	i32.ne  
	br_if   	1                               # 1: down to label526
# %bb.55:                               #   in Loop: Header=BB26_5 Depth=1
	i32.const	0
	local.set	13
	block   	
	local.get	10
	i32.eqz
	br_if   	0                               # 0: down to label534
# %bb.56:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	27
	i32.const	91
	i32.ne  
	br_if   	5                               # 5: down to label506
.LBB26_57:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label534:
	block   	
	local.get	8
	i32.eqz
	br_if   	0                               # 0: down to label535
# %bb.58:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	27
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	0                               # 0: down to label535
# %bb.59:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	7
	local.get	17
	i32.le_u
	br_if   	0                               # 0: down to label535
# %bb.60:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	1
	local.get	2
	i32.sub 
	local.set	30
	local.get	7
	local.set	31
.LBB26_61:                              #   Parent Loop BB26_5 Depth=1
                                        # =>  This Loop Header: Depth=2
                                        #       Child Loop BB26_67 Depth 3
                                        #       Child Loop BB26_73 Depth 3
                                        #       Child Loop BB26_76 Depth 3
                                        #       Child Loop BB26_78 Depth 3
                                        #       Child Loop BB26_82 Depth 3
	loop    	                                # label536:
	block   	
	local.get	6
	local.get	31
	i32.const	-1
	i32.add 
	local.tee	31
	i32.const	68
	i32.mul 
	i32.add 
	local.tee	32
	i32.load	40
	local.tee	33
	i32.const	-1
	i32.add 
	local.get	30
	i32.ge_u
	br_if   	0                               # 0: down to label537
# %bb.62:                               #   in Loop: Header=BB26_61 Depth=2
	local.get	27
	local.get	0
	local.get	32
	i32.load	36
	local.tee	34
	i32.add 
	local.tee	35
	i32.load8_u	0
	i32.ne  
	br_if   	0                               # 0: down to label537
# %bb.63:                               #   in Loop: Header=BB26_61 Depth=2
	local.get	34
	local.get	33
	i32.add 
	local.set	36
	local.get	33
	local.get	33
	i32.const	8
	local.get	33
	i32.const	8
	i32.lt_u
	i32.select
	local.tee	37
	i32.sub 
	local.set	38
	block   	
	local.get	33
	i32.const	7
	i32.gt_u
	local.tee	39
	i32.eqz
	br_if   	0                               # 0: down to label538
# %bb.64:                               #   in Loop: Header=BB26_61 Depth=2
	local.get	26
	local.get	38
	i32.add 
	i64.load	0:p2align=0
	local.get	0
	local.get	36
	local.get	37
	i32.sub 
	i32.add 
	i64.load	0:p2align=0
	i64.ne  
	br_if   	1                               # 1: down to label537
.LBB26_65:                              #   in Loop: Header=BB26_61 Depth=2
	end_block                               # label538:
	block   	
	local.get	37
	i32.const	8
	i32.and 
	local.tee	40
	local.get	37
	i32.eq  
	local.tee	41
	br_if   	0                               # 0: down to label539
# %bb.66:                               #   in Loop: Header=BB26_61 Depth=2
	local.get	40
	local.get	37
	i32.sub 
	local.set	4
	local.get	9
	local.get	33
	i32.add 
	local.set	28
	local.get	0
	local.get	36
	i32.add 
	local.set	36
.LBB26_67:                              #   Parent Loop BB26_5 Depth=1
                                        #     Parent Loop BB26_61 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label540:
	local.get	28
	local.get	4
	i32.add 
	i32.load8_u	0
	local.get	36
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	2                               # 2: down to label537
# %bb.68:                               #   in Loop: Header=BB26_67 Depth=3
	local.get	4
	i32.const	1
	i32.add 
	local.tee	4
	br_if   	0                               # 0: up to label540
.LBB26_69:                              #   in Loop: Header=BB26_61 Depth=2
	end_loop
	end_block                               # label539:
	local.get	38
	i32.const	1
	i32.shr_u
	local.set	4
	block   	
	local.get	39
	i32.eqz
	br_if   	0                               # 0: down to label541
# %bb.70:                               #   in Loop: Header=BB26_61 Depth=2
	local.get	26
	local.get	4
	i32.add 
	i64.load	0:p2align=0
	local.get	35
	local.get	4
	i32.add 
	i64.load	0:p2align=0
	i64.ne  
	br_if   	1                               # 1: down to label537
.LBB26_71:                              #   in Loop: Header=BB26_61 Depth=2
	end_block                               # label541:
	block   	
	local.get	41
	br_if   	0                               # 0: down to label542
# %bb.72:                               #   in Loop: Header=BB26_61 Depth=2
	local.get	37
	local.get	40
	i32.sub 
	local.set	28
	local.get	0
	local.get	4
	local.get	40
	i32.add 
	i32.add 
	local.set	4
.LBB26_73:                              #   Parent Loop BB26_5 Depth=1
                                        #     Parent Loop BB26_61 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label543:
	local.get	4
	local.get	2
	i32.add 
	i32.load8_u	0
	local.get	4
	local.get	34
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	2                               # 2: down to label537
# %bb.74:                               #   in Loop: Header=BB26_73 Depth=3
	local.get	4
	i32.const	1
	i32.add 
	local.set	4
	local.get	28
	i32.const	-1
	i32.add 
	local.tee	28
	br_if   	0                               # 0: up to label543
.LBB26_75:                              #   in Loop: Header=BB26_61 Depth=2
	end_loop
	end_block                               # label542:
	i32.const	0
	local.set	34
	local.get	35
	local.set	28
	local.get	9
	local.set	36
	local.get	33
	local.set	37
	i32.const	0
	local.set	4
.LBB26_76:                              #   Parent Loop BB26_5 Depth=1
                                        #     Parent Loop BB26_61 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	block   	
	loop    	                                # label545:
	local.get	37
	i32.const	31
	i32.le_u
	br_if   	1                               # 1: down to label544
# %bb.77:                               #   in Loop: Header=BB26_76 Depth=3
	local.get	9
	local.get	4
	i32.add 
	local.set	38
	local.get	35
	local.get	4
	i32.add 
	local.set	39
	local.get	28
	i32.const	32
	i32.add 
	local.set	28
	local.get	34
	i32.const	-32
	i32.add 
	local.set	34
	local.get	36
	i32.const	32
	i32.add 
	local.set	36
	local.get	37
	i32.const	-32
	i32.add 
	local.set	37
	local.get	4
	i32.const	32
	i32.add 
	local.set	4
	local.get	39
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	38
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	39
	v128.load	0:p2align=0
	local.get	38
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	br_if   	2                               # 2: down to label537
	br      	0                               # 0: up to label545
.LBB26_78:                              #   Parent Loop BB26_5 Depth=1
                                        #     Parent Loop BB26_61 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	end_loop
	end_block                               # label544:
	block   	
	loop    	                                # label547:
	local.get	33
	local.get	34
	i32.add 
	local.tee	37
	i32.const	7
	i32.le_u
	br_if   	1                               # 1: down to label546
# %bb.79:                               #   in Loop: Header=BB26_78 Depth=3
	local.get	34
	i32.const	-8
	i32.add 
	local.set	34
	local.get	28
	i64.load	0:p2align=0
	local.set	29
	local.get	36
	i64.load	0:p2align=0
	local.set	42
	local.get	28
	i32.const	8
	i32.add 
	local.set	28
	local.get	36
	i32.const	8
	i32.add 
	local.set	36
	local.get	42
	local.get	29
	i64.ne  
	br_if   	2                               # 2: down to label537
	br      	0                               # 0: up to label547
.LBB26_80:                              #   in Loop: Header=BB26_61 Depth=2
	end_loop
	end_block                               # label546:
	block   	
	i32.const	0
	local.get	34
	i32.sub 
	local.get	33
	i32.ge_u
	br_if   	0                               # 0: down to label548
# %bb.81:                               #   in Loop: Header=BB26_61 Depth=2
	i32.const	0
	local.set	4
.LBB26_82:                              #   Parent Loop BB26_5 Depth=1
                                        #     Parent Loop BB26_61 Depth=2
                                        # =>    This Inner Loop Header: Depth=3
	loop    	                                # label549:
	local.get	36
	local.get	4
	i32.add 
	i32.load8_u	0
	local.get	28
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	2                               # 2: down to label537
# %bb.83:                               #   in Loop: Header=BB26_82 Depth=3
	local.get	37
	local.get	4
	i32.const	1
	i32.add 
	local.tee	4
	i32.ne  
	br_if   	0                               # 0: up to label549
.LBB26_84:                              #   in Loop: Header=BB26_5 Depth=1
	end_loop
	end_block                               # label548:
	local.get	18
	local.get	32
	i32.load	56
	i32.store	0
	local.get	23
	local.get	32
	i32.load	60
	i32.store	0
	local.get	15
	local.get	32
	i32.load	64
	i32.store	0
	local.get	8
	local.get	31
	i32.store	0
	local.get	12
	local.get	2
	local.get	33
	i32.add 
	i32.store	12
	br      	5                               # 5: down to label513
.LBB26_85:                              #   in Loop: Header=BB26_61 Depth=2
	end_block                               # label537:
	local.get	31
	local.get	17
	i32.gt_u
	br_if   	0                               # 0: up to label536
.LBB26_86:                              #   in Loop: Header=BB26_5 Depth=1
	end_loop
	end_block                               # label535:
	block   	
	local.get	27
	i32.const	223
	i32.and 
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label550
# %bb.87:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	0
	local.get	1
	local.get	2
	local.get	12
	i32.const	12
	i32.add 
	local.get	19
	local.get	23
	local.get	15
	local.get	10
	call	parse_composite_span_impl
	br_if   	3                               # 3: down to label513
	br      	5                               # 5: down to label506
.LBB26_88:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label550:
	local.get	0
	local.get	1
	local.get	2
	local.get	12
	i32.const	12
	i32.add 
	call	parse_value_span
	br_if   	2                               # 2: down to label513
	br      	4                               # 4: down to label506
.LBB26_89:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label527:
	local.get	12
	local.get	9
	i32.store	12
	br      	1                               # 1: down to label513
.LBB26_90:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label526:
	local.get	0
	local.get	1
	local.get	2
	local.get	12
	i32.const	12
	i32.add 
	call	parse_value_span
	br_if   	0                               # 0: down to label513
# %bb.91:
	i32.const	0
	local.set	13
	br      	2                               # 2: down to label506
.LBB26_92:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label513:
	local.get	12
	i32.load	12
	local.set	9
	block   	
	local.get	25
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label551
# %bb.93:                               #   in Loop: Header=BB26_5 Depth=1
	i32.const	0
	local.set	27
	block   	
	i32.const	0
	local.get	9
	local.get	2
	i32.sub 
	local.tee	4
	local.get	4
	local.get	9
	i32.gt_u
	i32.select
	local.tee	4
	i32.const	2
	i32.lt_u
	br_if   	0                               # 0: down to label552
# %bb.94:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	26
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label552
# %bb.95:                               #   in Loop: Header=BB26_5 Depth=1
	local.get	24
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	27
.LBB26_96:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label552:
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	25
	br_table 	{0, 1, 2, 3, 4, 5, 6, 7, 0} # 1: down to label560
                                        # 2: down to label559
                                        # 3: down to label558
                                        # 4: down to label557
                                        # 5: down to label556
                                        # 6: down to label555
                                        # 7: down to label554
                                        # 0: down to label561
.LBB26_97:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label561:
	block   	
	local.get	27
	br_if   	0                               # 0: down to label562
# %bb.98:
	i32.const	0
	local.set	13
	br      	11                              # 11: down to label506
.LBB26_99:                              #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label562:
	local.get	3
	local.get	2
	i32.store	0
	i32.const	4
	local.set	27
	br      	7                               # 7: down to label553
.LBB26_100:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label560:
	block   	
	local.get	27
	br_if   	0                               # 0: down to label563
# %bb.101:
	i32.const	0
	local.set	13
	br      	10                              # 10: down to label506
.LBB26_102:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label563:
	local.get	3
	local.get	2
	i32.store	8
	i32.const	12
	local.set	27
	br      	6                               # 6: down to label553
.LBB26_103:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label559:
	block   	
	local.get	27
	br_if   	0                               # 0: down to label564
# %bb.104:                              #   in Loop: Header=BB26_5 Depth=1
	i32.const	0
	local.set	13
	local.get	4
	i32.const	4
	i32.ne  
	br_if   	9                               # 9: down to label506
# %bb.105:                              #   in Loop: Header=BB26_5 Depth=1
	local.get	26
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	9                               # 9: down to label506
# %bb.106:                              #   in Loop: Header=BB26_5 Depth=1
	local.get	26
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	9                               # 9: down to label506
# %bb.107:                              #   in Loop: Header=BB26_5 Depth=1
	local.get	26
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	9                               # 9: down to label506
# %bb.108:                              #   in Loop: Header=BB26_5 Depth=1
	local.get	26
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	9                               # 9: down to label506
.LBB26_109:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label564:
	local.get	3
	local.get	2
	i32.store	16
	i32.const	20
	local.set	27
	br      	5                               # 5: down to label553
.LBB26_110:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label558:
	block   	
	local.get	27
	br_if   	0                               # 0: down to label565
# %bb.111:
	i32.const	0
	local.set	13
	br      	8                               # 8: down to label506
.LBB26_112:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label565:
	local.get	3
	local.get	2
	i32.store	24
	i32.const	28
	local.set	27
	br      	4                               # 4: down to label553
.LBB26_113:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label557:
	block   	
	local.get	0
	local.get	2
	local.get	9
	call	is_valid_json_number
	i32.eqz
	br_if   	0                               # 0: down to label566
# %bb.114:                              #   in Loop: Header=BB26_5 Depth=1
	i32.const	32
	local.set	27
	local.get	2
	local.set	4
	br      	4                               # 4: down to label553
.LBB26_115:
	end_block                               # label566:
	i32.const	0
	local.set	13
	br      	6                               # 6: down to label506
.LBB26_116:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label556:
	local.get	3
	local.get	2
	i32.store	36
	i32.const	40
	local.set	27
	br      	2                               # 2: down to label553
.LBB26_117:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label555:
	block   	
	local.get	4
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label567
# %bb.118:                              #   in Loop: Header=BB26_5 Depth=1
	local.get	26
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label567
# %bb.119:                              #   in Loop: Header=BB26_5 Depth=1
	local.get	26
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label567
# %bb.120:                              #   in Loop: Header=BB26_5 Depth=1
	local.get	26
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label567
# %bb.121:                              #   in Loop: Header=BB26_5 Depth=1
	local.get	26
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label567
# %bb.122:                              #   in Loop: Header=BB26_5 Depth=1
	i32.const	-1
	local.set	4
	i32.const	44
	local.set	27
	br      	2                               # 2: down to label553
.LBB26_123:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label567:
	block   	
	local.get	0
	local.get	2
	local.get	9
	call	is_valid_json_number
	i32.eqz
	br_if   	0                               # 0: down to label568
# %bb.124:                              #   in Loop: Header=BB26_5 Depth=1
	i32.const	44
	local.set	27
	local.get	2
	local.set	4
	br      	2                               # 2: down to label553
.LBB26_125:
	end_block                               # label568:
	i32.const	0
	local.set	13
	br      	4                               # 4: down to label506
.LBB26_126:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label554:
	block   	
	local.get	27
	br_if   	0                               # 0: down to label569
# %bb.127:
	i32.const	0
	local.set	13
	br      	4                               # 4: down to label506
.LBB26_128:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label569:
	local.get	16
	local.get	2
	i32.store	0
	i32.const	52
	local.set	27
.LBB26_129:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label553:
	local.get	3
	local.get	27
	i32.add 
	local.get	4
	i32.store	0
.LBB26_130:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label551:
	block   	
	local.get	9
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label570
.LBB26_131:                             #   Parent Loop BB26_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label571:
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label570
# %bb.132:                              #   in Loop: Header=BB26_131 Depth=2
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label570
# %bb.133:                              #   in Loop: Header=BB26_131 Depth=2
	local.get	1
	local.get	9
	i32.const	1
	i32.add 
	local.tee	9
	i32.ne  
	br_if   	0                               # 0: up to label571
# %bb.134:
	end_loop
	i32.const	0
	local.set	13
	br      	2                               # 2: down to label506
.LBB26_135:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label570:
	i32.const	0
	local.set	13
	local.get	9
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label506
# %bb.136:                              #   in Loop: Header=BB26_5 Depth=1
	local.get	25
	i32.const	1
	i32.add 
	local.set	25
	block   	
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	44
	i32.eq  
	br_if   	0                               # 0: down to label572
# %bb.137:
	local.get	2
	i32.const	93
	i32.ne  
	br_if   	2                               # 2: down to label506
# %bb.138:
	local.get	5
	local.get	9
	i32.const	1
	i32.add 
	i32.store	0
	local.get	3
	i32.load	4
	i32.const	0
	i32.ne  
	local.get	10
	i32.eqz
	local.get	25
	i32.const	8
	i32.eq  
	i32.or  
	i32.and 
	local.set	13
	br      	2                               # 2: down to label506
.LBB26_139:                             #   in Loop: Header=BB26_5 Depth=1
	end_block                               # label572:
	block   	
	local.get	9
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label573
.LBB26_140:                             #   Parent Loop BB26_5 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label574:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	9
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label573
# %bb.141:                              #   in Loop: Header=BB26_140 Depth=2
	i32.const	1
	local.get	9
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label573
# %bb.142:                              #   in Loop: Header=BB26_140 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label574
	br      	3                               # 3: down to label506
.LBB26_143:                             #   in Loop: Header=BB26_5 Depth=1
	end_loop
	end_block                               # label573:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label506
# %bb.144:                              #   in Loop: Header=BB26_5 Depth=1
	i32.const	0
	local.set	13
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.ne  
	br_if   	0                               # 0: up to label508
.LBB26_145:
	end_loop
	end_block                               # label506:
	local.get	12
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	13
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.scan_scalar_span,"",@
	.type	scan_scalar_span,@function      # -- Begin function scan_scalar_span
scan_scalar_span:                       # @scan_scalar_span
	.functype	scan_scalar_span (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	4
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label575
# %bb.1:
	local.get	2
	local.set	5
.LBB27_2:                               # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label577:
	block   	
	local.get	1
	local.get	5
	local.tee	6
	i32.ne  
	br_if   	0                               # 0: down to label578
# %bb.3:
	local.get	1
	local.set	6
	br      	2                               # 2: down to label576
.LBB27_4:                               #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label578:
	block   	
	block   	
	local.get	0
	local.get	6
	i32.add 
	i32.load8_u	0
	local.tee	7
	i32.const	-10
	i32.add 
	br_table 	{3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0} # 1: down to label579
                                        # 3: down to label576
                                        # 0: down to label580
.LBB27_5:                               #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label580:
	local.get	7
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label576
# %bb.6:                                #   in Loop: Header=BB27_2 Depth=1
	local.get	7
	i32.const	125
	i32.eq  
	br_if   	2                               # 2: down to label576
.LBB27_7:                               #   in Loop: Header=BB27_2 Depth=1
	end_block                               # label579:
	local.get	6
	i32.const	1
	i32.add 
	local.set	5
	local.get	7
	i32.const	9
	i32.ne  
	br_if   	0                               # 0: up to label577
.LBB27_8:
	end_loop
	end_block                               # label576:
	local.get	6
	local.get	2
	i32.eq  
	br_if   	0                               # 0: down to label575
# %bb.9:
	local.get	3
	local.get	6
	i32.store	0
	i32.const	1
	local.set	4
.LBB27_10:
	end_block                               # label575:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_int32_token,"",@
	.type	parse_int32_token,@function     # -- Begin function parse_int32_token
parse_int32_token:                      # @parse_int32_token
	.functype	parse_int32_token (i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32
# %bb.0:
	block   	
	block   	
	block   	
	local.get	2
	local.get	1
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label583
# %bb.1:
	local.get	0
	local.get	1
	i32.add 
	local.tee	5
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	0                               # 0: down to label583
# %bb.2:
	local.get	5
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	0                               # 0: down to label583
# %bb.3:
	local.get	5
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	0                               # 0: down to label583
# %bb.4:
	local.get	5
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label582
.LBB28_5:
	end_block                               # label583:
	i32.const	1
	local.set	6
	block   	
	local.get	2
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label584
# %bb.6:
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	3
	i32.const	45
	i32.ne  
	local.set	6
	local.get	1
	local.get	3
	i32.const	45
	i32.eq  
	i32.add 
	local.set	1
.LBB28_7:
	end_block                               # label584:
	i32.const	0
	local.set	5
	local.get	2
	local.get	1
	i32.le_u
	br_if   	1                               # 1: down to label581
# %bb.8:
	local.get	0
	local.get	1
	i32.add 
	local.tee	0
	i32.load8_u	0
	local.tee	3
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	246
	i32.lt_u
	br_if   	1                               # 1: down to label581
# %bb.9:
	block   	
	local.get	1
	i32.const	1
	i32.add 
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label585
# %bb.10:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	48
	i32.eq  
	br_if   	2                               # 2: down to label581
.LBB28_11:
	end_block                               # label585:
	i32.const	2147483647
	i32.const	-2147483648
	local.get	6
	i32.select
	local.set	7
	local.get	2
	local.get	1
	i32.sub 
	local.set	3
	i32.const	0
	local.set	5
	i32.const	0
	local.set	1
.LBB28_12:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label586:
	local.get	0
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	246
	i32.lt_u
	br_if   	2                               # 2: down to label581
# %bb.13:                               #   in Loop: Header=BB28_12 Depth=1
	local.get	1
	local.get	7
	local.get	2
	i32.const	-48
	i32.add 
	local.tee	2
	i32.sub 
	i32.const	10
	i32.div_u
	i32.gt_u
	br_if   	2                               # 2: down to label581
# %bb.14:                               #   in Loop: Header=BB28_12 Depth=1
	local.get	0
	i32.const	1
	i32.add 
	local.set	0
	local.get	2
	local.get	1
	i32.const	10
	i32.mul 
	i32.add 
	local.set	1
	local.get	3
	i32.const	-1
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label586
# %bb.15:
	end_loop
	local.get	1
	i32.const	0
	local.get	1
	i32.sub 
	local.get	6
	i32.select
	local.set	3
.LBB28_16:
	end_block                               # label582:
	local.get	4
	local.get	3
	i32.store	0
	i32.const	1
	local.set	5
.LBB28_17:
	end_block                               # label581:
	local.get	5
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.raw_term_content_hash,"",@
	.type	raw_term_content_hash,@function # -- Begin function raw_term_content_hash
raw_term_content_hash:                  # @raw_term_content_hash
	.functype	raw_term_content_hash (i32, i32) -> (i32)
	.local  	i32, i32, i32
# %bb.0:
	local.get	0
	local.get	1
	i32.load	36
	i32.add 
	local.get	1
	i32.load	40
	i32.const	-2128831035
	call	hash_content_xxh32
	local.set	2
	local.get	0
	local.get	1
	i32.load	24
	i32.add 
	local.get	1
	i32.load	28
	i32.const	-1640531527
	call	hash_content_xxh32
	local.set	3
	local.get	0
	local.get	1
	i32.load	16
	i32.add 
	local.get	1
	i32.load	20
	i32.const	-2048144789
	call	hash_content_xxh32
	local.set	4
	i32.const	1
	local.get	0
	local.get	1
	i32.load	48
	i32.add 
	local.get	1
	i32.load	52
	i32.const	-1028477387
	call	hash_content_xxh32
	i32.const	17
	i32.rotl
	local.tee	1
	local.get	2
	local.get	3
	i32.const	5
	i32.rotl
	i32.xor 
	local.get	4
	i32.const	11
	i32.rotl
	i32.xor 
	local.tee	0
	i32.xor 
	local.tee	2
	i32.const	16
	i32.shr_u
	local.get	2
	i32.xor 
	local.get	0
	local.get	1
	i32.eq  
	i32.select
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.raw_term_content_tokens_equal,"",@
	.type	raw_term_content_tokens_equal,@function # -- Begin function raw_term_content_tokens_equal
raw_term_content_tokens_equal:          # @raw_term_content_tokens_equal
	.functype	raw_term_content_tokens_equal (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i64, i64, i32
# %bb.0:
	i32.const	0
	local.set	4
	block   	
	local.get	1
	i32.load	40
	local.tee	5
	local.get	2
	i32.load	40
	i32.ne  
	br_if   	0                               # 0: down to label587
# %bb.1:
	block   	
	block   	
	local.get	3
	br_if   	0                               # 0: down to label589
# %bb.2:
	local.get	0
	local.get	2
	i32.load	36
	i32.add 
	local.set	6
	local.get	0
	local.get	1
	i32.load	36
	i32.add 
	local.set	7
	i32.const	0
	local.set	3
	local.get	5
	local.set	8
.LBB30_3:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label590:
	block   	
	local.get	8
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label591
# %bb.4:
	i32.const	0
	local.get	3
	i32.sub 
	local.set	8
	local.get	6
	local.get	3
	i32.add 
	local.set	9
	local.get	7
	local.get	3
	i32.add 
	local.set	3
.LBB30_5:                               # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label593:
	block   	
	local.get	5
	local.get	8
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label594
# %bb.6:
	i32.const	0
	local.get	8
	i32.sub 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	5                               # 5: down to label589
# %bb.7:
	br      	2                               # 2: down to label592
.LBB30_8:                               #   in Loop: Header=BB30_5 Depth=1
	end_block                               # label594:
	local.get	8
	i32.const	-8
	i32.add 
	local.set	8
	local.get	9
	i64.load	0:p2align=0
	local.set	10
	local.get	3
	i64.load	0:p2align=0
	local.set	11
	local.get	3
	i32.const	8
	i32.add 
	local.set	3
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	local.get	10
	i64.eq  
	br_if   	0                               # 0: up to label593
	br      	5                               # 5: down to label588
.LBB30_9:                               # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label592:
	loop    	                                # label595:
	local.get	7
	local.get	3
	i32.add 
	i32.load8_u	0
	local.get	6
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	4                               # 4: down to label588
# %bb.10:                               #   in Loop: Header=BB30_9 Depth=1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label589
	br      	0                               # 0: up to label595
.LBB30_11:                              #   in Loop: Header=BB30_3 Depth=1
	end_loop
	end_block                               # label591:
	local.get	7
	local.get	3
	i32.add 
	local.set	9
	local.get	6
	local.get	3
	i32.add 
	local.set	12
	local.get	8
	i32.const	-32
	i32.add 
	local.set	8
	local.get	3
	i32.const	32
	i32.add 
	local.set	3
	local.get	12
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	9
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	12
	v128.load	0:p2align=0
	local.get	9
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label590
	br      	2                               # 2: down to label588
.LBB30_12:
	end_loop
	end_block                               # label589:
	local.get	1
	i32.load	28
	local.tee	5
	local.get	2
	i32.load	28
	i32.ne  
	br_if   	1                               # 1: down to label587
# %bb.13:
	local.get	0
	local.get	2
	i32.load	24
	i32.add 
	local.set	6
	local.get	0
	local.get	1
	i32.load	24
	i32.add 
	local.set	7
	i32.const	0
	local.set	3
	local.get	5
	local.set	8
.LBB30_14:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label596:
	block   	
	local.get	8
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label597
# %bb.15:
	i32.const	0
	local.get	3
	i32.sub 
	local.set	8
	local.get	6
	local.get	3
	i32.add 
	local.set	9
	local.get	7
	local.get	3
	i32.add 
	local.set	3
.LBB30_16:                              # =>This Inner Loop Header: Depth=1
	block   	
	block   	
	loop    	                                # label600:
	block   	
	local.get	5
	local.get	8
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label601
# %bb.17:
	i32.const	0
	local.set	4
	i32.const	0
	local.get	8
	i32.sub 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label598
# %bb.18:
	br      	2                               # 2: down to label599
.LBB30_19:                              #   in Loop: Header=BB30_16 Depth=1
	end_block                               # label601:
	local.get	8
	i32.const	-8
	i32.add 
	local.set	8
	local.get	9
	i64.load	0:p2align=0
	local.set	10
	local.get	3
	i64.load	0:p2align=0
	local.set	11
	local.get	3
	i32.const	8
	i32.add 
	local.set	3
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	local.get	10
	i64.eq  
	br_if   	0                               # 0: up to label600
	br      	5                               # 5: down to label588
.LBB30_20:                              # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label599:
	loop    	                                # label602:
	local.get	7
	local.get	3
	i32.add 
	i32.load8_u	0
	local.get	6
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	5                               # 5: down to label587
# %bb.21:                               #   in Loop: Header=BB30_20 Depth=1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: up to label602
.LBB30_22:
	end_loop
	end_block                               # label598:
	local.get	1
	i32.load	20
	local.tee	5
	local.get	2
	i32.load	20
	i32.ne  
	br_if   	3                               # 3: down to label587
# %bb.23:
	local.get	0
	local.get	2
	i32.load	16
	i32.add 
	local.set	6
	local.get	0
	local.get	1
	i32.load	16
	i32.add 
	local.set	7
	i32.const	0
	local.set	3
	local.get	5
	local.set	8
.LBB30_24:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label603:
	block   	
	local.get	8
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label604
# %bb.25:
	i32.const	0
	local.get	3
	i32.sub 
	local.set	8
	local.get	6
	local.get	3
	i32.add 
	local.set	9
	local.get	7
	local.get	3
	i32.add 
	local.set	3
.LBB30_26:                              # =>This Inner Loop Header: Depth=1
	block   	
	block   	
	loop    	                                # label607:
	block   	
	local.get	5
	local.get	8
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label608
# %bb.27:
	i32.const	0
	local.set	4
	i32.const	0
	local.get	8
	i32.sub 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label605
# %bb.28:
	br      	2                               # 2: down to label606
.LBB30_29:                              #   in Loop: Header=BB30_26 Depth=1
	end_block                               # label608:
	local.get	8
	i32.const	-8
	i32.add 
	local.set	8
	local.get	9
	i64.load	0:p2align=0
	local.set	10
	local.get	3
	i64.load	0:p2align=0
	local.set	11
	i32.const	0
	local.set	4
	local.get	3
	i32.const	8
	i32.add 
	local.set	3
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	local.get	10
	i64.eq  
	br_if   	0                               # 0: up to label607
	br      	8                               # 8: down to label587
.LBB30_30:                              # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label606:
	loop    	                                # label609:
	local.get	7
	local.get	3
	i32.add 
	i32.load8_u	0
	local.get	6
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	7                               # 7: down to label587
# %bb.31:                               #   in Loop: Header=BB30_30 Depth=1
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: up to label609
.LBB30_32:
	end_loop
	end_block                               # label605:
	local.get	1
	i32.load	52
	local.tee	5
	local.get	2
	i32.load	52
	i32.ne  
	br_if   	5                               # 5: down to label587
# %bb.33:
	local.get	0
	local.get	2
	i32.load	48
	i32.add 
	local.set	6
	local.get	0
	local.get	1
	i32.load	48
	i32.add 
	local.set	7
	i32.const	0
	local.set	3
	local.get	5
	local.set	8
.LBB30_34:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label610:
	block   	
	local.get	8
	i32.const	31
	i32.gt_u
	br_if   	0                               # 0: down to label611
# %bb.35:
	i32.const	0
	local.get	3
	i32.sub 
	local.set	8
	local.get	6
	local.get	3
	i32.add 
	local.set	9
	local.get	7
	local.get	3
	i32.add 
	local.set	3
.LBB30_36:                              # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label613:
	block   	
	local.get	5
	local.get	8
	i32.add 
	i32.const	7
	i32.gt_u
	br_if   	0                               # 0: down to label614
# %bb.37:
	i32.const	0
	local.get	8
	i32.sub 
	local.tee	3
	local.get	5
	i32.lt_u
	br_if   	2                               # 2: down to label612
# %bb.38:
	i32.const	1
	return
.LBB30_39:                              #   in Loop: Header=BB30_36 Depth=1
	end_block                               # label614:
	local.get	8
	i32.const	-8
	i32.add 
	local.set	8
	local.get	9
	i64.load	0:p2align=0
	local.set	10
	local.get	3
	i64.load	0:p2align=0
	local.set	11
	i32.const	0
	local.set	4
	local.get	3
	i32.const	8
	i32.add 
	local.set	3
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	local.get	10
	i64.eq  
	br_if   	0                               # 0: up to label613
	br      	9                               # 9: down to label587
.LBB30_40:                              # =>This Inner Loop Header: Depth=1
	end_loop
	end_block                               # label612:
	loop    	                                # label615:
	local.get	7
	local.get	3
	i32.add 
	i32.load8_u	0
	local.get	6
	local.get	3
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	7                               # 7: down to label588
# %bb.41:                               #   in Loop: Header=BB30_40 Depth=1
	i32.const	1
	local.set	4
	local.get	3
	i32.const	1
	i32.add 
	local.tee	3
	local.get	5
	i32.ge_u
	br_if   	8                               # 8: down to label587
	br      	0                               # 0: up to label615
.LBB30_42:                              #   in Loop: Header=BB30_34 Depth=1
	end_loop
	end_block                               # label611:
	local.get	7
	local.get	3
	i32.add 
	local.set	9
	local.get	6
	local.get	3
	i32.add 
	local.set	12
	local.get	8
	i32.const	-32
	i32.add 
	local.set	8
	local.get	3
	i32.const	32
	i32.add 
	local.set	3
	i32.const	0
	local.set	4
	local.get	12
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	9
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	12
	v128.load	0:p2align=0
	local.get	9
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label610
	br      	6                               # 6: down to label587
.LBB30_43:                              #   in Loop: Header=BB30_24 Depth=1
	end_loop
	end_block                               # label604:
	local.get	7
	local.get	3
	i32.add 
	local.set	9
	local.get	6
	local.get	3
	i32.add 
	local.set	12
	local.get	8
	i32.const	-32
	i32.add 
	local.set	8
	local.get	3
	i32.const	32
	i32.add 
	local.set	3
	i32.const	0
	local.set	4
	local.get	12
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	9
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	12
	v128.load	0:p2align=0
	local.get	9
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label603
	br      	4                               # 4: down to label587
.LBB30_44:                              #   in Loop: Header=BB30_14 Depth=1
	end_loop
	end_block                               # label597:
	local.get	7
	local.get	3
	i32.add 
	local.set	9
	local.get	6
	local.get	3
	i32.add 
	local.set	12
	local.get	8
	i32.const	-32
	i32.add 
	local.set	8
	local.get	3
	i32.const	32
	i32.add 
	local.set	3
	local.get	12
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	local.get	9
	i32.const	16
	i32.add 
	v128.load	0:p2align=0
	v128.xor
	local.get	12
	v128.load	0:p2align=0
	local.get	9
	v128.load	0:p2align=0
	v128.xor
	v128.or
	v128.any_true
	i32.eqz
	br_if   	0                               # 0: up to label596
.LBB30_45:
	end_loop
	end_block                               # label588:
	i32.const	0
	local.set	4
.LBB30_46:
	end_block                               # label587:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.raw_term_content_quick_signature,"",@
	.type	raw_term_content_quick_signature,@function # -- Begin function raw_term_content_quick_signature
raw_term_content_quick_signature:       # @raw_term_content_quick_signature
	.functype	raw_term_content_quick_signature (i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	2
	block   	
	block   	
	local.get	1
	i32.load	40
	local.tee	3
	br_if   	0                               # 0: down to label617
# %bb.1:
	i32.const	0
	local.set	4
	i32.const	0
	local.set	5
	br      	1                               # 1: down to label616
.LBB31_2:
	end_block                               # label617:
	local.get	0
	local.get	1
	i32.load	36
	local.tee	6
	i32.add 
	local.set	7
	block   	
	block   	
	local.get	3
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label619
# %bb.3:
	local.get	7
	i32.load8_u	0
	local.set	2
	local.get	3
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label618
# %bb.4:
	local.get	7
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	8
	i32.shl 
	local.get	2
	i32.or  
	local.set	2
	local.get	3
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label618
# %bb.5:
	local.get	7
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	16
	i32.shl 
	local.get	2
	i32.or  
	local.set	2
	br      	1                               # 1: down to label618
.LBB31_6:
	end_block                               # label619:
	local.get	7
	i32.load	0:p2align=0
	local.set	4
	block   	
	local.get	3
	i32.const	4
	i32.ne  
	br_if   	0                               # 0: down to label620
# %bb.7:
	local.get	4
	local.set	2
	local.get	4
	local.set	5
	br      	2                               # 2: down to label616
.LBB31_8:
	end_block                               # label620:
	i32.const	0
	local.get	3
	i32.const	-4
	i32.add 
	local.tee	2
	local.get	2
	local.get	3
	i32.gt_u
	i32.select
	local.set	8
	i32.const	0
	local.set	5
	i32.const	0
	local.set	2
	block   	
	local.get	3
	local.get	8
	i32.const	1
	i32.shr_u
	local.tee	9
	i32.le_u
	br_if   	0                               # 0: down to label621
# %bb.9:
	local.get	7
	local.get	9
	i32.add 
	local.set	10
	block   	
	local.get	3
	local.get	9
	i32.sub 
	local.tee	11
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label622
# %bb.10:
	i32.const	0
	local.set	9
	i32.const	0
	local.set	2
.LBB31_11:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label623:
	local.get	10
	i32.load8_u	0
	local.get	9
	i32.shl 
	local.get	2
	i32.or  
	local.set	2
	local.get	10
	i32.const	1
	i32.add 
	local.set	10
	local.get	9
	i32.const	8
	i32.add 
	local.set	9
	local.get	11
	i32.const	-1
	i32.add 
	local.tee	11
	br_if   	0                               # 0: up to label623
	br      	2                               # 2: down to label621
.LBB31_12:
	end_loop
	end_block                               # label622:
	local.get	10
	i32.load	0:p2align=0
	local.set	2
.LBB31_13:
	end_block                               # label621:
	local.get	3
	local.get	8
	i32.le_u
	br_if   	1                               # 1: down to label616
# %bb.14:
	block   	
	local.get	3
	local.get	8
	i32.sub 
	local.tee	5
	i32.const	3
	i32.gt_u
	br_if   	0                               # 0: down to label624
# %bb.15:
	i32.const	0
	local.set	10
	i32.const	0
	local.get	5
	i32.sub 
	local.set	9
	local.get	0
	local.get	3
	local.get	6
	i32.add 
	i32.add 
	local.set	0
	i32.const	0
	local.set	5
.LBB31_16:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label625:
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.get	10
	i32.shl 
	local.get	5
	i32.or  
	local.set	5
	local.get	10
	i32.const	8
	i32.add 
	local.set	10
	local.get	9
	i32.const	1
	i32.add 
	local.tee	11
	local.set	9
	local.get	11
	br_if   	0                               # 0: up to label625
	br      	3                               # 3: down to label616
.LBB31_17:
	end_loop
	end_block                               # label624:
	local.get	7
	local.get	8
	i32.add 
	i32.load	0:p2align=0
	local.set	5
	br      	1                               # 1: down to label616
.LBB31_18:
	end_block                               # label618:
	local.get	2
	local.set	4
	local.get	2
	local.set	5
.LBB31_19:
	end_block                               # label616:
	local.get	4
	local.get	3
	i32.const	-1640531535
	i32.mul 
	i32.xor 
	local.get	1
	i32.load	28
	i32.const	-2048144789
	i32.mul 
	i32.xor 
	local.get	1
	i32.load	20
	i32.const	-1028477387
	i32.mul 
	i32.xor 
	local.get	1
	i32.load	52
	i32.const	668265263
	i32.mul 
	i32.xor 
	i32.const	13
	i32.rotl
	local.get	2
	i32.const	374761393
	i32.mul 
	i32.xor 
	i32.const	11
	i32.rotl
	local.get	5
	i32.xor 
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.next_term_row,"",@
	.type	next_term_row,@function         # -- Begin function next_term_row
next_term_row:                          # @next_term_row
	.functype	next_term_row (i32, i32) -> (i32)
	.local  	i32, i32, i32, i32
# %bb.0:
	local.get	0
	i32.load	0
	local.set	2
	block   	
	local.get	1
	local.get	0
	i32.load	20
	local.tee	3
	i32.ge_u
	br_if   	0                               # 0: down to label626
# %bb.1:
.LBB32_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label627:
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label626
# %bb.3:                                #   in Loop: Header=BB32_2 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label626
# %bb.4:                                #   in Loop: Header=BB32_2 Depth=1
	local.get	3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	0                               # 0: up to label627
# %bb.5:
	end_loop
	i32.const	-1
	return
.LBB32_6:
	end_block                               # label626:
	i32.const	-1
	local.set	5
	block   	
	local.get	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label628
# %bb.7:
	block   	
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	4
	i32.const	44
	i32.eq  
	br_if   	0                               # 0: down to label629
# %bb.8:
	local.get	4
	i32.const	93
	i32.ne  
	br_if   	1                               # 1: down to label628
# %bb.9:
	block   	
	block   	
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label631
# %bb.10:
.LBB32_11:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label632:
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label631
# %bb.12:                               #   in Loop: Header=BB32_11 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label631
# %bb.13:                               #   in Loop: Header=BB32_11 Depth=1
	local.get	3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	0                               # 0: up to label632
	br      	2                               # 2: down to label630
.LBB32_14:
	end_loop
	end_block                               # label631:
	local.get	1
	local.get	3
	i32.ne  
	br_if   	2                               # 2: down to label628
.LBB32_15:
	end_block                               # label630:
	local.get	0
	call	next_term_bank
	return
.LBB32_16:
	end_block                               # label629:
	block   	
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label633
# %bb.17:
.LBB32_18:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label634:
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	4
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label633
# %bb.19:                               #   in Loop: Header=BB32_18 Depth=1
	i32.const	1
	local.get	4
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label633
# %bb.20:                               #   in Loop: Header=BB32_18 Depth=1
	local.get	3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	0                               # 0: up to label634
	br      	2                               # 2: down to label628
.LBB32_21:
	end_loop
	end_block                               # label633:
	local.get	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label628
# %bb.22:
	local.get	2
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.eq  
	br_if   	0                               # 0: down to label628
# %bb.23:
	local.get	0
	local.get	1
	i32.store	24
	i32.const	1
	local.set	5
.LBB32_24:
	end_block                               # label628:
	local.get	5
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.compact_term_lookup_keys,"",@
	.globl	compact_term_lookup_keys        # -- Begin function compact_term_lookup_keys
	.type	compact_term_lookup_keys,@function
compact_term_lookup_keys:               # @compact_term_lookup_keys
	.functype	compact_term_lookup_keys (i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, v128, v128, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-1
	local.set	20
	block   	
	local.get	5
	i32x4.splat
	local.get	0
	i32x4.replace_lane	1
	local.get	2
	i32x4.replace_lane	2
	local.get	3
	i32x4.replace_lane	3
	v128.const	0, 0, 0, 0
	local.tee	21
	i32x4.eq
	v128.const	255, 255, 255, 255
	local.tee	22
	v128.and
	local.get	4
	i32x4.splat
	local.get	6
	i32x4.replace_lane	1
	local.get	7
	i32x4.replace_lane	2
	local.get	8
	i32x4.replace_lane	3
	local.get	21
	i32x4.eq
	local.get	22
	v128.and
	i16x8.narrow_i32x4_u
	local.get	10
	i32x4.splat
	local.get	19
	i32x4.replace_lane	1
	local.get	11
	i32x4.replace_lane	2
	local.get	12
	i32x4.replace_lane	3
	local.get	21
	i32x4.eq
	local.get	22
	v128.and
	local.get	13
	i32x4.splat
	local.get	14
	i32x4.replace_lane	1
	local.get	15
	i32x4.replace_lane	2
	local.get	16
	i32x4.replace_lane	3
	local.get	21
	i32x4.eq
	local.get	22
	v128.and
	i16x8.narrow_i32x4_u
	i8x16.narrow_i16x8_u
	v128.any_true
	br_if   	0                               # 0: down to label635
# %bb.1:
	local.get	18
	i32.const	65534
	i32.gt_u
	br_if   	0                               # 0: down to label635
# %bb.2:
	local.get	5
	i32.const	1073741823
	i32.gt_u
	br_if   	0                               # 0: down to label635
# %bb.3:
	local.get	9
	i32.const	-65535
	i32.add 
	i32.const	-65534
	i32.lt_u
	br_if   	0                               # 0: down to label635
# %bb.4:
	i32.const	0
	local.set	23
	local.get	3
	local.set	24
	local.get	2
	local.set	25
	local.get	5
	local.set	26
.LBB33_5:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label636:
	i32.const	-2
	local.set	20
	local.get	1
	local.get	23
	i32.lt_u
	br_if   	1                               # 1: down to label635
# %bb.6:                                #   in Loop: Header=BB33_5 Depth=1
	local.get	24
	i32.load	0
	local.get	23
	i32.ne  
	br_if   	1                               # 1: down to label635
# %bb.7:                                #   in Loop: Header=BB33_5 Depth=1
	local.get	1
	local.get	23
	i32.sub 
	local.get	25
	i32.load16_u	0
	local.tee	27
	i32.lt_u
	br_if   	1                               # 1: down to label635
# %bb.8:                                #   in Loop: Header=BB33_5 Depth=1
	local.get	24
	i32.const	4
	i32.add 
	local.set	24
	local.get	25
	i32.const	2
	i32.add 
	local.set	25
	local.get	23
	local.get	27
	i32.add 
	local.set	23
	local.get	26
	i32.const	-1
	i32.add 
	local.tee	26
	br_if   	0                               # 0: up to label636
# %bb.9:
	end_loop
	local.get	23
	local.get	1
	i32.ne  
	br_if   	0                               # 0: down to label635
# %bb.10:
	i32.const	0
	local.set	23
	block   	
	local.get	5
	i32.const	2
	i32.shl 
	local.tee	24
	i32.eqz
	br_if   	0                               # 0: down to label637
# %bb.11:
	local.get	10
	i32.const	0
	local.get	24
	memory.fill	0
.LBB33_12:
	end_block                               # label637:
	i32.const	0
	local.set	25
	block   	
	local.get	9
	i32.eqz
	br_if   	0                               # 0: down to label638
# %bb.13:
	i32.const	0
	local.set	25
	i32.const	0
	local.set	23
.LBB33_14:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label639:
	block   	
	local.get	8
	i32.load8_u	0
	local.tee	24
	i32.const	1
	i32.le_u
	br_if   	0                               # 0: down to label640
# %bb.15:
	i32.const	-3
	return
.LBB33_16:                              #   in Loop: Header=BB33_14 Depth=1
	end_block                               # label640:
	block   	
	local.get	6
	i32.load	0
	local.tee	1
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: down to label641
# %bb.17:
	i32.const	-3
	return
.LBB33_18:                              #   in Loop: Header=BB33_14 Depth=1
	end_block                               # label641:
	block   	
	local.get	2
	local.get	1
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	27
	i32.load16_u	0
	local.tee	26
	br_if   	0                               # 0: down to label642
# %bb.19:
	i32.const	-3
	return
.LBB33_20:                              #   in Loop: Header=BB33_14 Depth=1
	end_block                               # label642:
	local.get	6
	local.get	7
	local.get	24
	i32.select
	i32.load	0
	local.set	24
	block   	
	local.get	10
	local.get	1
	i32.const	2
	i32.shl 
	local.tee	28
	i32.add 
	local.tee	29
	i32.load	0
	local.tee	1
	br_if   	0                               # 0: down to label643
# %bb.21:                               #   in Loop: Header=BB33_14 Depth=1
	i32.const	-4
	local.set	20
	local.get	23
	local.get	18
	i32.ge_u
	br_if   	3                               # 3: down to label635
# %bb.22:                               #   in Loop: Header=BB33_14 Depth=1
	local.get	17
	local.get	25
	i32.sub 
	local.get	26
	i32.lt_u
	br_if   	3                               # 3: down to label635
# %bb.23:                               #   in Loop: Header=BB33_14 Depth=1
	local.get	12
	local.get	23
	i32.const	2
	i32.shl 
	local.tee	1
	i32.add 
	local.get	25
	i32.store	0
	local.get	13
	local.get	1
	i32.add 
	local.get	4
	local.get	28
	i32.add 
	i32.load	0
	i32.store	0
	local.get	11
	local.get	23
	i32.const	1
	i32.shl 
	i32.add 
	local.get	26
	i32.store16	0
	block   	
	local.get	27
	i32.load16_u	0
	local.tee	1
	i32.eqz
	br_if   	0                               # 0: down to label644
# %bb.24:                               #   in Loop: Header=BB33_14 Depth=1
	local.get	16
	local.get	25
	i32.add 
	local.get	0
	local.get	3
	local.get	28
	i32.add 
	i32.load	0
	i32.add 
	local.get	1
	memory.copy	0, 0
.LBB33_25:                              #   in Loop: Header=BB33_14 Depth=1
	end_block                               # label644:
	local.get	29
	local.get	23
	i32.const	1
	i32.add 
	local.tee	23
	i32.store	0
	local.get	25
	local.get	27
	i32.load16_u	0
	i32.add 
	local.set	25
	local.get	23
	local.set	1
.LBB33_26:                              #   in Loop: Header=BB33_14 Depth=1
	end_block                               # label643:
	local.get	14
	local.get	1
	i32.const	-1
	i32.add 
	i32.store	0
	block   	
	local.get	24
	local.get	5
	i32.lt_u
	br_if   	0                               # 0: down to label645
# %bb.27:
	i32.const	-3
	return
.LBB33_28:                              #   in Loop: Header=BB33_14 Depth=1
	end_block                               # label645:
	i32.const	-3
	local.set	20
	local.get	2
	local.get	24
	i32.const	1
	i32.shl 
	i32.add 
	local.tee	26
	i32.load16_u	0
	local.tee	1
	i32.eqz
	br_if   	2                               # 2: down to label635
# %bb.29:                               #   in Loop: Header=BB33_14 Depth=1
	block   	
	local.get	10
	local.get	24
	i32.const	2
	i32.shl 
	local.tee	27
	i32.add 
	local.tee	28
	i32.load	0
	local.tee	24
	br_if   	0                               # 0: down to label646
# %bb.30:                               #   in Loop: Header=BB33_14 Depth=1
	i32.const	-4
	local.set	20
	local.get	23
	local.get	18
	i32.ge_u
	br_if   	3                               # 3: down to label635
# %bb.31:                               #   in Loop: Header=BB33_14 Depth=1
	local.get	17
	local.get	25
	i32.sub 
	local.get	1
	i32.lt_u
	br_if   	3                               # 3: down to label635
# %bb.32:                               #   in Loop: Header=BB33_14 Depth=1
	local.get	12
	local.get	23
	i32.const	2
	i32.shl 
	local.tee	24
	i32.add 
	local.get	25
	i32.store	0
	local.get	13
	local.get	24
	i32.add 
	local.get	4
	local.get	27
	i32.add 
	i32.load	0
	i32.store	0
	local.get	11
	local.get	23
	i32.const	1
	i32.shl 
	i32.add 
	local.get	1
	i32.store16	0
	block   	
	local.get	26
	i32.load16_u	0
	local.tee	24
	i32.eqz
	br_if   	0                               # 0: down to label647
# %bb.33:                               #   in Loop: Header=BB33_14 Depth=1
	local.get	16
	local.get	25
	i32.add 
	local.get	0
	local.get	3
	local.get	27
	i32.add 
	i32.load	0
	i32.add 
	local.get	24
	memory.copy	0, 0
.LBB33_34:                              #   in Loop: Header=BB33_14 Depth=1
	end_block                               # label647:
	local.get	28
	local.get	23
	i32.const	1
	i32.add 
	local.tee	23
	i32.store	0
	local.get	25
	local.get	26
	i32.load16_u	0
	i32.add 
	local.set	25
	local.get	23
	local.set	24
.LBB33_35:                              #   in Loop: Header=BB33_14 Depth=1
	end_block                               # label646:
	local.get	15
	local.get	24
	i32.const	-1
	i32.add 
	i32.store	0
	local.get	8
	i32.const	1
	i32.add 
	local.set	8
	local.get	6
	i32.const	4
	i32.add 
	local.set	6
	local.get	14
	i32.const	4
	i32.add 
	local.set	14
	local.get	15
	i32.const	4
	i32.add 
	local.set	15
	local.get	7
	i32.const	4
	i32.add 
	local.set	7
	local.get	9
	i32.const	-1
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label639
.LBB33_36:
	end_loop
	end_block                               # label638:
	local.get	19
	local.get	25
	i32.store	0
	local.get	23
	local.set	20
.LBB33_37:
	end_block                               # label635:
	local.get	20
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.write_normalized_glossary_value,"",@
	.type	write_normalized_glossary_value,@function # -- Begin function write_normalized_glossary_value
write_normalized_glossary_value:        # @write_normalized_glossary_value
	.functype	write_normalized_glossary_value (i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	16
	i32.sub 
	local.tee	7
	global.set	__stack_pointer
	i32.const	0
	local.set	8
	block   	
	local.get	3
	local.get	2
	i32.le_u
	br_if   	0                               # 0: down to label648
# %bb.1:
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	local.tee	9
	i32.load8_u	0
	local.tee	10
	i32.const	123
	i32.eq  
	br_if   	0                               # 0: down to label651
# %bb.2:
	local.get	10
	i32.const	91
	i32.ne  
	br_if   	1                               # 1: down to label650
# %bb.3:
	local.get	6
	i32.load	0
	local.tee	10
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label648
# %bb.4:
	local.get	4
	local.get	10
	i32.add 
	i32.const	91
	i32.store8	0
	local.get	6
	local.get	6
	i32.load	0
	i32.const	1
	i32.add 
	local.tee	11
	i32.store	0
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label652
# %bb.5:
	i32.const	0
	local.set	11
.LBB34_6:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB34_7 Depth 2
                                        #     Child Loop BB34_19 Depth 2
	loop    	                                # label653:
	block   	
	local.get	10
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label654
.LBB34_7:                               #   Parent Loop BB34_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label655:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	2
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label654
# %bb.8:                                #   in Loop: Header=BB34_7 Depth=2
	i32.const	1
	local.get	2
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label654
# %bb.9:                                #   in Loop: Header=BB34_7 Depth=2
	local.get	1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label655
# %bb.10:                               #   in Loop: Header=BB34_6 Depth=1
	end_loop
	local.get	1
	local.set	10
.LBB34_11:                              #   in Loop: Header=BB34_6 Depth=1
	end_block                               # label654:
	i32.const	0
	local.set	8
	local.get	10
	local.get	3
	i32.ge_u
	br_if   	5                               # 5: down to label648
# %bb.12:                               #   in Loop: Header=BB34_6 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	93
	i32.eq  
	br_if   	0                               # 0: down to label656
# %bb.13:                               #   in Loop: Header=BB34_6 Depth=1
	local.get	7
	i32.const	0
	i32.store	8
	local.get	0
	local.get	1
	local.get	10
	local.get	7
	i32.const	8
	i32.add 
	call	parse_value_span
	i32.eqz
	br_if   	6                               # 6: down to label648
# %bb.14:                               #   in Loop: Header=BB34_6 Depth=1
	block   	
	local.get	11
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label657
# %bb.15:                               #   in Loop: Header=BB34_6 Depth=1
	local.get	6
	i32.load	0
	local.tee	2
	local.get	5
	i32.ge_u
	br_if   	7                               # 7: down to label648
# %bb.16:                               #   in Loop: Header=BB34_6 Depth=1
	local.get	4
	local.get	2
	i32.add 
	i32.const	44
	i32.store8	0
	local.get	6
	local.get	6
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
.LBB34_17:                              #   in Loop: Header=BB34_6 Depth=1
	end_block                               # label657:
	local.get	0
	local.get	1
	local.get	10
	local.get	7
	i32.load	8
	local.tee	2
	local.get	4
	local.get	5
	local.get	6
	call	write_normalized_glossary_value
	i32.eqz
	br_if   	6                               # 6: down to label648
# %bb.18:                               #   in Loop: Header=BB34_6 Depth=1
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label658
.LBB34_19:                              #   Parent Loop BB34_6 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label659:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label658
# %bb.20:                               #   in Loop: Header=BB34_19 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label658
# %bb.21:                               #   in Loop: Header=BB34_19 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label659
# %bb.22:                               #   in Loop: Header=BB34_6 Depth=1
	end_loop
	local.get	1
	local.set	2
.LBB34_23:                              #   in Loop: Header=BB34_6 Depth=1
	end_block                               # label658:
	block   	
	block   	
	local.get	2
	local.get	3
	i32.lt_u
	br_if   	0                               # 0: down to label661
# %bb.24:                               #   in Loop: Header=BB34_6 Depth=1
	local.get	2
	local.set	10
	br      	1                               # 1: down to label660
.LBB34_25:                              #   in Loop: Header=BB34_6 Depth=1
	end_block                               # label661:
	local.get	2
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.eq  
	i32.add 
	local.set	10
.LBB34_26:                              #   in Loop: Header=BB34_6 Depth=1
	end_block                               # label660:
	i32.const	1
	local.set	11
	local.get	10
	local.get	3
	i32.lt_u
	br_if   	1                               # 1: up to label653
.LBB34_27:
	end_block                               # label656:
	end_loop
	local.get	6
	i32.load	0
	local.set	11
.LBB34_28:
	end_block                               # label652:
	i32.const	0
	local.set	8
	local.get	11
	local.get	5
	i32.ge_u
	br_if   	3                               # 3: down to label648
# %bb.29:
	local.get	4
	local.get	11
	i32.add 
	i32.const	93
	i32.store8	0
	i32.const	1
	local.set	8
	local.get	6
	local.get	6
	i32.load	0
	i32.const	1
	i32.add 
	i32.store	0
	br      	3                               # 3: down to label648
.LBB34_30:
	end_block                               # label651:
	local.get	3
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label650
# %bb.31:
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label662
# %bb.32:
.LBB34_33:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label663:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	1
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label662
# %bb.34:                               #   in Loop: Header=BB34_33 Depth=1
	i32.const	1
	local.get	1
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label662
# %bb.35:                               #   in Loop: Header=BB34_33 Depth=1
	local.get	3
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label663
	br      	2                               # 2: down to label650
.LBB34_36:
	end_loop
	end_block                               # label662:
	local.get	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label650
# %bb.37:
	local.get	0
	i32.const	1
	i32.add 
	local.set	12
	local.get	0
	i32.const	2
	i32.add 
	local.set	13
	local.get	0
	i32.const	5
	i32.add 
	local.set	14
	local.get	0
	i32.const	4
	i32.add 
	local.set	15
	local.get	0
	i32.const	3
	i32.add 
	local.set	16
	i32.const	0
	local.set	17
	i32.const	0
	local.set	18
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
.LBB34_38:                              # =>This Loop Header: Depth=1
                                        #     Child Loop BB34_49 Depth 2
                                        #     Child Loop BB34_102 Depth 2
                                        #     Child Loop BB34_108 Depth 2
                                        #     Child Loop BB34_134 Depth 2
                                        #     Child Loop BB34_141 Depth 2
	loop    	                                # label664:
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	34
	i32.eq  
	br_if   	0                               # 0: down to label665
# %bb.39:
	local.get	1
	i32.const	125
	i32.ne  
	br_if   	2                               # 2: down to label650
# %bb.40:
	local.get	20
	i32.eqz
	br_if   	2                               # 2: down to label650
# %bb.41:
	local.get	19
	i32.eqz
	br_if   	2                               # 2: down to label650
# %bb.42:
	i32.const	0
	local.set	8
	local.get	6
	i32.load	0
	local.tee	10
	local.get	17
	i32.add 
	local.tee	2
	local.get	10
	i32.lt_u
	br_if   	4                               # 4: down to label648
# %bb.43:
	local.get	2
	local.get	5
	i32.gt_u
	br_if   	4                               # 4: down to label648
# %bb.44:
	block   	
	local.get	17
	i32.eqz
	br_if   	0                               # 0: down to label666
# %bb.45:
	local.get	4
	local.get	10
	i32.add 
	local.get	0
	local.get	18
	i32.add 
	local.get	17
	memory.copy	0, 0
.LBB34_46:
	end_block                               # label666:
	local.get	6
	local.get	2
	i32.store	0
	br      	3                               # 3: down to label649
.LBB34_47:                              #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label665:
	local.get	10
	i32.const	1
	i32.add 
	local.tee	21
	local.get	3
	i32.ge_u
	br_if   	1                               # 1: down to label650
# %bb.48:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	21
	local.set	11
.LBB34_49:                              #   Parent Loop BB34_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label667:
	block   	
	local.get	11
	local.tee	1
	i32.const	8
	i32.add 
	local.tee	11
	local.get	3
	i32.gt_u
	br_if   	0                               # 0: down to label668
# %bb.50:                               #   in Loop: Header=BB34_49 Depth=2
	local.get	0
	local.get	1
	i32.add 
	i64.load	0:p2align=0
	local.tee	22
	i64.const	-1
	i64.xor 
	local.get	22
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	22
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	local.get	22
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	22
	i64.eqz
	br_if   	1                               # 1: up to label667
# %bb.51:                               #   in Loop: Header=BB34_49 Depth=2
	local.get	22
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	1
	i32.add 
	local.set	1
.LBB34_52:                              #   in Loop: Header=BB34_49 Depth=2
	end_block                               # label668:
	local.get	1
	local.get	3
	i32.ge_u
	br_if   	2                               # 2: down to label650
# %bb.53:                               #   in Loop: Header=BB34_49 Depth=2
	block   	
	block   	
	block   	
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label671
# %bb.54:                               #   in Loop: Header=BB34_49 Depth=2
	local.get	1
	i32.const	1
	i32.add 
	local.tee	11
	local.get	3
	i32.ge_u
	br_if   	5                               # 5: down to label650
# %bb.55:                               #   in Loop: Header=BB34_49 Depth=2
	block   	
	block   	
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 7, 7, 7, 7, 7, 7, 1, 7, 7, 7, 1, 7, 1, 0, 7} # 7: down to label650
                                        # 1: down to label672
                                        # 0: down to label673
.LBB34_56:                              #   in Loop: Header=BB34_49 Depth=2
	end_block                               # label673:
	local.get	1
	i32.const	6
	i32.add 
	local.tee	11
	local.get	3
	i32.gt_u
	br_if   	6                               # 6: down to label650
# %bb.57:                               #   in Loop: Header=BB34_49 Depth=2
	local.get	1
	i32.const	2
	i32.add 
	local.tee	23
	local.get	11
	i32.ge_u
	br_if   	2                               # 2: down to label670
# %bb.58:                               #   in Loop: Header=BB34_49 Depth=2
	block   	
	local.get	0
	local.get	23
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label674
# %bb.59:                               #   in Loop: Header=BB34_49 Depth=2
	local.get	23
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label650
.LBB34_60:                              #   in Loop: Header=BB34_49 Depth=2
	end_block                               # label674:
	block   	
	local.get	16
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label675
# %bb.61:                               #   in Loop: Header=BB34_49 Depth=2
	local.get	23
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label650
.LBB34_62:                              #   in Loop: Header=BB34_49 Depth=2
	end_block                               # label675:
	block   	
	local.get	15
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label676
# %bb.63:                               #   in Loop: Header=BB34_49 Depth=2
	local.get	23
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	7                               # 7: down to label650
.LBB34_64:                              #   in Loop: Header=BB34_49 Depth=2
	end_block                               # label676:
	local.get	14
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label670
# %bb.65:                               #   in Loop: Header=BB34_49 Depth=2
	local.get	1
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label670
	br      	6                               # 6: down to label650
.LBB34_66:                              #   in Loop: Header=BB34_49 Depth=2
	end_block                               # label672:
	local.get	1
	i32.const	2
	i32.add 
	local.set	11
	br      	1                               # 1: down to label670
.LBB34_67:                              #   in Loop: Header=BB34_49 Depth=2
	end_block                               # label671:
	local.get	23
	i32.const	32
	i32.lt_u
	br_if   	4                               # 4: down to label650
# %bb.68:                               #   in Loop: Header=BB34_49 Depth=2
	local.get	1
	i32.const	1
	i32.add 
	local.set	11
	local.get	23
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label669
.LBB34_69:                              #   in Loop: Header=BB34_49 Depth=2
	end_block                               # label670:
	local.get	11
	local.get	3
	i32.lt_u
	br_if   	1                               # 1: up to label667
	br      	3                               # 3: down to label650
.LBB34_70:                              #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label669:
	end_loop
	i32.const	0
	local.set	23
	i32.const	0
	local.set	24
	block   	
	local.get	1
	local.get	10
	i32.lt_u
	br_if   	0                               # 0: down to label677
# %bb.71:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	10
	i32.const	5
	i32.add 
	local.set	25
	i32.const	0
	local.set	24
	i32.const	0
	local.set	23
	block   	
	local.get	1
	local.get	10
	i32.eq  
	br_if   	0                               # 0: down to label678
# %bb.72:                               #   in Loop: Header=BB34_38 Depth=1
	block   	
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	local.tee	26
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label679
# %bb.73:                               #   in Loop: Header=BB34_38 Depth=1
	i32.const	0
	local.set	23
	local.get	1
	local.get	10
	i32.sub 
	local.tee	27
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label678
# %bb.74:                               #   in Loop: Header=BB34_38 Depth=1
	i32.const	0
	local.set	23
	local.get	26
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label678
# %bb.75:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	13
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	26
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label679
# %bb.76:                               #   in Loop: Header=BB34_38 Depth=1
	i32.const	0
	local.set	23
	local.get	26
	i32.const	121
	i32.ne  
	br_if   	1                               # 1: down to label678
# %bb.77:                               #   in Loop: Header=BB34_38 Depth=1
	i32.const	0
	local.set	23
	local.get	27
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label678
# %bb.78:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	16
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	26
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label679
# %bb.79:                               #   in Loop: Header=BB34_38 Depth=1
	i32.const	0
	local.set	23
	local.get	26
	i32.const	112
	i32.ne  
	br_if   	1                               # 1: down to label678
# %bb.80:                               #   in Loop: Header=BB34_38 Depth=1
	i32.const	0
	local.set	23
	local.get	27
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label678
# %bb.81:                               #   in Loop: Header=BB34_38 Depth=1
	i32.const	0
	local.set	23
	block   	
	local.get	15
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label678
                                        # 0: down to label680
.LBB34_82:                              #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label680:
	i32.const	0
	local.set	23
	local.get	25
	local.get	1
	i32.gt_u
	br_if   	1                               # 1: down to label678
# %bb.83:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	0
	local.get	25
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	23
	br      	1                               # 1: down to label678
.LBB34_84:                              #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label679:
	local.get	0
	local.get	10
	local.get	11
	i32.const	.L.str
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	23
.LBB34_85:                              #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label678:
	local.get	1
	local.get	10
	i32.le_u
	br_if   	0                               # 0: down to label677
# %bb.86:                               #   in Loop: Header=BB34_38 Depth=1
	block   	
	block   	
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	local.tee	21
	i32.const	116
	i32.ne  
	br_if   	0                               # 0: down to label682
# %bb.87:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	10
	i32.const	2
	i32.add 
	local.tee	21
	local.get	1
	i32.gt_u
	br_if   	2                               # 2: down to label677
# %bb.88:                               #   in Loop: Header=BB34_38 Depth=1
	block   	
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{2, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label677
                                        # 0: down to label683
.LBB34_89:                              #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label683:
	local.get	10
	i32.const	3
	i32.add 
	local.tee	21
	local.get	1
	i32.gt_u
	br_if   	2                               # 2: down to label677
# %bb.90:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	local.tee	21
	i32.const	92
	i32.eq  
	br_if   	1                               # 1: down to label681
# %bb.91:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	21
	i32.const	120
	i32.ne  
	br_if   	2                               # 2: down to label677
# %bb.92:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	10
	i32.const	4
	i32.add 
	local.tee	21
	local.get	1
	i32.gt_u
	br_if   	2                               # 2: down to label677
# %bb.93:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	0
	local.get	21
	i32.add 
	i32.load8_u	0
	local.tee	21
	i32.const	92
	i32.eq  
	br_if   	1                               # 1: down to label681
# %bb.94:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	21
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label677
# %bb.95:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	25
	local.get	1
	i32.gt_u
	br_if   	2                               # 2: down to label677
# %bb.96:                               #   in Loop: Header=BB34_38 Depth=1
	local.get	0
	local.get	25
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	24
	br      	2                               # 2: down to label677
.LBB34_97:                              #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label682:
	local.get	21
	i32.const	92
	i32.ne  
	br_if   	1                               # 1: down to label677
.LBB34_98:                              #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label681:
	local.get	0
	local.get	10
	local.get	11
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	24
.LBB34_99:                              #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label677:
	block   	
	local.get	23
	br_if   	0                               # 0: down to label684
# %bb.100:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	24
	i32.eqz
	br_if   	2                               # 2: down to label650
.LBB34_101:                             #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label684:
	block   	
	local.get	11
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label685
.LBB34_102:                             #   Parent Loop BB34_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label686:
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label685
# %bb.103:                              #   in Loop: Header=BB34_102 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label685
# %bb.104:                              #   in Loop: Header=BB34_102 Depth=2
	local.get	3
	local.get	11
	i32.const	1
	i32.add 
	local.tee	11
	i32.ne  
	br_if   	0                               # 0: up to label686
	br      	3                               # 3: down to label650
.LBB34_105:                             #   in Loop: Header=BB34_38 Depth=1
	end_loop
	end_block                               # label685:
	local.get	11
	local.get	3
	i32.ge_u
	br_if   	1                               # 1: down to label650
# %bb.106:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	1                               # 1: down to label650
# %bb.107:                              #   in Loop: Header=BB34_38 Depth=1
	block   	
	local.get	11
	i32.const	1
	i32.add 
	local.tee	1
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label687
.LBB34_108:                             #   Parent Loop BB34_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label688:
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	10
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label687
# %bb.109:                              #   in Loop: Header=BB34_108 Depth=2
	i32.const	1
	local.get	10
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label687
# %bb.110:                              #   in Loop: Header=BB34_108 Depth=2
	local.get	3
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	i32.ne  
	br_if   	0                               # 0: up to label688
# %bb.111:                              #   in Loop: Header=BB34_38 Depth=1
	end_loop
	local.get	3
	local.set	1
.LBB34_112:                             #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label687:
	local.get	7
	i32.const	0
	i32.store	12
	local.get	0
	local.get	3
	local.get	1
	local.get	7
	i32.const	12
	i32.add 
	call	parse_value_span
	i32.eqz
	br_if   	1                               # 1: down to label650
# %bb.113:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	7
	i32.load	12
	local.set	10
	block   	
	block   	
	block   	
	block   	
	local.get	23
	i32.eqz
	br_if   	0                               # 0: down to label692
# %bb.114:                              #   in Loop: Header=BB34_38 Depth=1
	i32.const	0
	local.set	20
	local.get	10
	local.get	1
	i32.le_u
	br_if   	3                               # 3: down to label689
# %bb.115:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	3                               # 3: down to label689
# %bb.116:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	10
	local.get	1
	i32.const	-1
	i32.xor 
	i32.add 
	local.tee	11
	i32.eqz
	br_if   	3                               # 3: down to label689
# %bb.117:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	12
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	92
	i32.eq  
	br_if   	2                               # 2: down to label690
# %bb.118:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	11
	i32.const	1
	i32.eq  
	br_if   	3                               # 3: down to label689
# %bb.119:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	23
	i32.const	116
	i32.ne  
	br_if   	3                               # 3: down to label689
# %bb.120:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	13
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{2, 3, 3, 3, 3, 3, 3, 3, 3, 1, 3} # 3: down to label689
                                        # 1: down to label691
.LBB34_121:                             #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label692:
	i32.const	0
	local.set	19
	block   	
	local.get	10
	local.get	1
	i32.le_u
	br_if   	0                               # 0: down to label693
# %bb.122:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	19
.LBB34_123:                             #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label693:
	local.get	10
	local.get	1
	i32.sub 
	local.set	17
	local.get	1
	local.set	18
	br      	2                               # 2: down to label689
.LBB34_124:                             #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label691:
	local.get	11
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label689
# %bb.125:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	16
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	23
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label690
# %bb.126:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	23
	i32.const	120
	i32.ne  
	br_if   	1                               # 1: down to label689
# %bb.127:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	11
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label689
# %bb.128:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	15
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	11
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label690
# %bb.129:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	11
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label689
# %bb.130:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	1
	i32.const	5
	i32.add 
	local.tee	1
	local.get	10
	i32.ge_u
	br_if   	1                               # 1: down to label689
# %bb.131:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	20
	br      	1                               # 1: down to label689
.LBB34_132:                             #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label690:
	local.get	0
	local.get	1
	local.get	10
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	local.set	20
.LBB34_133:                             #   in Loop: Header=BB34_38 Depth=1
	end_block                               # label689:
	block   	
	local.get	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label694
.LBB34_134:                             #   Parent Loop BB34_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label695:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	1
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label694
# %bb.135:                              #   in Loop: Header=BB34_134 Depth=2
	i32.const	1
	local.get	1
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label694
# %bb.136:                              #   in Loop: Header=BB34_134 Depth=2
	local.get	3
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label695
	br      	3                               # 3: down to label650
.LBB34_137:                             #   in Loop: Header=BB34_38 Depth=1
	end_loop
	end_block                               # label694:
	local.get	10
	local.get	3
	i32.ge_u
	br_if   	1                               # 1: down to label650
# %bb.138:                              #   in Loop: Header=BB34_38 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	1
	i32.const	125
	i32.eq  
	br_if   	0                               # 0: down to label696
# %bb.139:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	1
	i32.const	44
	i32.ne  
	br_if   	2                               # 2: down to label650
# %bb.140:                              #   in Loop: Header=BB34_38 Depth=1
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	local.get	3
	i32.ge_u
	br_if   	0                               # 0: down to label696
.LBB34_141:                             #   Parent Loop BB34_38 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label697:
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	1
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label696
# %bb.142:                              #   in Loop: Header=BB34_141 Depth=2
	i32.const	1
	local.get	1
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label696
# %bb.143:                              #   in Loop: Header=BB34_141 Depth=2
	local.get	3
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.ne  
	br_if   	0                               # 0: up to label697
	br      	3                               # 3: down to label650
.LBB34_144:                             #   in Loop: Header=BB34_38 Depth=1
	end_loop
	end_block                               # label696:
	local.get	10
	local.get	3
	i32.lt_u
	br_if   	0                               # 0: up to label664
.LBB34_145:
	end_loop
	end_block                               # label650:
	local.get	6
	i32.load	0
	local.tee	10
	local.get	3
	local.get	2
	i32.sub 
	local.tee	2
	i32.add 
	local.tee	0
	local.get	10
	i32.lt_u
	br_if   	1                               # 1: down to label648
# %bb.146:
	local.get	0
	local.get	5
	i32.gt_u
	br_if   	1                               # 1: down to label648
# %bb.147:
	block   	
	local.get	2
	i32.eqz
	br_if   	0                               # 0: down to label698
# %bb.148:
	local.get	4
	local.get	10
	i32.add 
	local.get	9
	local.get	2
	memory.copy	0, 0
.LBB34_149:
	end_block                               # label698:
	local.get	6
	local.get	0
	i32.store	0
.LBB34_150:
	end_block                               # label649:
	i32.const	1
	local.set	8
.LBB34_151:
	end_block                               # label648:
	local.get	7
	i32.const	16
	i32.add 
	global.set	__stack_pointer
	local.get	8
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.hash_content_xxh32_pair,"",@
	.type	hash_content_xxh32_pair,@function # -- Begin function hash_content_xxh32_pair
hash_content_xxh32_pair:                # @hash_content_xxh32_pair
	.functype	hash_content_xxh32_pair (i32, i32, i32, i32) -> ()
	.local  	i32, i32, v128, v128, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	local.get	0
	local.get	1
	i32.add 
	local.set	4
	block   	
	block   	
	local.get	1
	i32.const	-64
	i32.add 
	i32.const	448
	i32.gt_u
	br_if   	0                               # 0: down to label700
# %bb.1:
	local.get	4
	i32.const	-16
	i32.add 
	local.set	5
	v128.const	-1522540051, 117991484, -2128831035, -488299500
	local.set	6
	v128.const	-1034240543, 606290992, -1640531527, 8
	local.set	7
.LBB35_2:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label701:
	local.get	0
	v128.load	0:p2align=0
	v128.const	-2048144777, -2048144777, -2048144777, -2048144777
	i32x4.mul
	local.tee	8
	local.get	7
	i32x4.add
	local.tee	7
	i32.const	13
	i32x4.shl
	local.get	7
	i32.const	19
	i32x4.shr_u
	v128.or
	v128.const	-1640531535, -1640531535, -1640531535, -1640531535
	local.tee	9
	i32x4.mul
	local.set	7
	local.get	8
	local.get	6
	i32x4.add
	local.tee	6
	i32.const	13
	i32x4.shl
	local.get	6
	i32.const	19
	i32x4.shr_u
	v128.or
	local.get	9
	i32x4.mul
	local.set	6
	local.get	0
	i32.const	16
	i32.add 
	local.tee	0
	local.get	5
	i32.le_u
	br_if   	0                               # 0: up to label701
# %bb.3:
	end_loop
	local.get	7
	i32x4.extract_lane	0
	i32.const	1
	i32.rotl
	local.get	7
	i32x4.extract_lane	1
	i32.const	7
	i32.rotl
	i32.add 
	local.get	7
	i32x4.extract_lane	2
	i32.const	12
	i32.rotl
	i32.add 
	local.get	7
	i32x4.extract_lane	3
	i32.const	18
	i32.rotl
	i32.add 
	local.set	5
	local.get	6
	i32x4.extract_lane	0
	i32.const	1
	i32.rotl
	local.get	6
	i32x4.extract_lane	1
	i32.const	7
	i32.rotl
	i32.add 
	local.get	6
	i32x4.extract_lane	2
	i32.const	12
	i32.rotl
	i32.add 
	local.get	6
	i32x4.extract_lane	3
	i32.const	18
	i32.rotl
	i32.add 
	local.set	10
	br      	1                               # 1: down to label699
.LBB35_4:
	end_block                               # label700:
	block   	
	local.get	1
	i32.const	16
	i32.ge_u
	br_if   	0                               # 0: down to label702
# %bb.5:
	i32.const	-1754069642
	local.set	10
	i32.const	-1265770134
	local.set	5
	br      	1                               # 1: down to label699
.LBB35_6:
	end_block                               # label702:
	local.get	4
	i32.const	-16
	i32.add 
	local.set	11
	i32.const	-1640531527
	local.set	5
	i32.const	606290992
	local.set	10
	i32.const	-1034240543
	local.set	12
	i32.const	-488299500
	local.set	13
	i32.const	-2128831035
	local.set	14
	i32.const	117991484
	local.set	15
	i32.const	-1522540051
	local.set	16
	i32.const	8
	local.set	17
.LBB35_7:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label703:
	local.get	0
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.tee	18
	local.get	12
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	12
	local.get	18
	local.get	16
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	16
	local.get	0
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.tee	18
	local.get	17
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	17
	local.get	18
	local.get	13
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	13
	local.get	0
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.tee	18
	local.get	5
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	5
	local.get	18
	local.get	14
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	14
	local.get	0
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	i32.const	-2048144777
	i32.mul 
	local.tee	18
	local.get	10
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	10
	local.get	18
	local.get	15
	i32.add 
	i32.const	13
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	15
	local.get	0
	i32.const	16
	i32.add 
	local.tee	0
	local.get	11
	i32.le_u
	br_if   	0                               # 0: up to label703
# %bb.8:
	end_loop
	local.get	10
	i32.const	7
	i32.rotl
	local.get	12
	i32.const	1
	i32.rotl
	i32.add 
	local.get	5
	i32.const	12
	i32.rotl
	i32.add 
	local.get	17
	i32.const	18
	i32.rotl
	i32.add 
	local.set	5
	local.get	15
	i32.const	7
	i32.rotl
	local.get	16
	i32.const	1
	i32.rotl
	i32.add 
	local.get	14
	i32.const	12
	i32.rotl
	i32.add 
	local.get	13
	i32.const	18
	i32.rotl
	i32.add 
	local.set	10
.LBB35_9:
	end_block                               # label699:
	local.get	5
	local.get	1
	i32.add 
	local.set	5
	local.get	10
	local.get	1
	i32.add 
	local.set	10
	block   	
	block   	
	local.get	0
	i32.const	4
	i32.add 
	local.get	4
	i32.le_u
	br_if   	0                               # 0: down to label705
# %bb.10:
	local.get	0
	local.set	12
	br      	1                               # 1: down to label704
.LBB35_11:
	end_block                               # label705:
.LBB35_12:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label706:
	local.get	0
	i32.load	0:p2align=0
	i32.const	-1028477379
	i32.mul 
	local.tee	12
	local.get	5
	i32.add 
	i32.const	17
	i32.rotl
	i32.const	668265263
	i32.mul 
	local.set	5
	local.get	12
	local.get	10
	i32.add 
	i32.const	17
	i32.rotl
	i32.const	668265263
	i32.mul 
	local.set	10
	local.get	0
	i32.const	8
	i32.add 
	local.set	13
	local.get	0
	i32.const	4
	i32.add 
	local.tee	12
	local.set	0
	local.get	13
	local.get	4
	i32.le_u
	br_if   	0                               # 0: up to label706
.LBB35_13:
	end_loop
	end_block                               # label704:
	block   	
	local.get	12
	local.get	4
	i32.ge_u
	br_if   	0                               # 0: down to label707
# %bb.14:
	local.get	12
	i32.const	1
	i32.add 
	local.set	0
	block   	
	local.get	4
	local.get	12
	i32.sub 
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label708
# %bb.15:
	local.get	12
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.tee	12
	local.get	5
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	5
	local.get	12
	local.get	10
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	10
	local.get	0
	local.set	12
.LBB35_16:
	end_block                               # label708:
	local.get	4
	local.get	0
	i32.eq  
	br_if   	0                               # 0: down to label707
# %bb.17:
.LBB35_18:                              # =>This Inner Loop Header: Depth=1
	loop    	                                # label709:
	local.get	12
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.tee	0
	local.get	12
	i32.load8_u	0
	i32.const	374761393
	i32.mul 
	local.tee	13
	local.get	5
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	5
	local.get	0
	local.get	13
	local.get	10
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	i32.add 
	i32.const	11
	i32.rotl
	i32.const	-1640531535
	i32.mul 
	local.set	10
	local.get	12
	i32.const	2
	i32.add 
	local.tee	12
	local.get	4
	i32.ne  
	br_if   	0                               # 0: up to label709
.LBB35_19:
	end_loop
	end_block                               # label707:
	local.get	2
	local.get	10
	i32.const	15
	i32.shr_u
	local.get	10
	i32.xor 
	i32.const	-2048144777
	i32.mul 
	local.tee	0
	i32.const	13
	i32.shr_u
	local.get	0
	i32.xor 
	i32.const	-1028477379
	i32.mul 
	local.tee	0
	i32.const	16
	i32.shr_u
	local.get	0
	i32.xor 
	i32.store	0
	local.get	3
	local.get	5
	i32.const	15
	i32.shr_u
	local.get	5
	i32.xor 
	i32.const	-2048144777
	i32.mul 
	local.tee	0
	i32.const	13
	i32.shr_u
	local.get	0
	i32.xor 
	i32.const	-1028477379
	i32.mul 
	local.tee	0
	i32.const	16
	i32.shr_u
	local.get	0
	i32.xor 
	i32.store	0
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_value_span,"",@
	.type	parse_value_span,@function      # -- Begin function parse_value_span
parse_value_span:                       # @parse_value_span
	.functype	parse_value_span (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i64, i32
# %bb.0:
	i32.const	0
	local.set	4
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label710
# %bb.1:
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	5
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label711
# %bb.2:
	local.get	2
	i32.const	1
	i32.add 
	local.tee	5
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label710
# %bb.3:
	local.get	0
	i32.const	5
	i32.add 
	local.set	6
	local.get	0
	i32.const	4
	i32.add 
	local.set	7
	local.get	0
	i32.const	3
	i32.add 
	local.set	8
.LBB36_4:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label712:
	block   	
	local.get	5
	local.tee	2
	i32.const	8
	i32.add 
	local.tee	5
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label713
# %bb.5:                                #   in Loop: Header=BB36_4 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i64.load	0:p2align=0
	local.tee	9
	i64.const	-1
	i64.xor 
	local.get	9
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	9
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	local.get	9
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	9
	i64.eqz
	br_if   	1                               # 1: up to label712
# %bb.6:                                #   in Loop: Header=BB36_4 Depth=1
	local.get	9
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	2
	i32.add 
	local.set	2
.LBB36_7:                               #   in Loop: Header=BB36_4 Depth=1
	end_block                               # label713:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label710
# %bb.8:                                #   in Loop: Header=BB36_4 Depth=1
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label716
# %bb.9:                                #   in Loop: Header=BB36_4 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	5
	local.get	1
	i32.ge_u
	br_if   	5                               # 5: down to label710
# %bb.10:                               #   in Loop: Header=BB36_4 Depth=1
	block   	
	local.get	0
	local.get	5
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{2, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 2, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 2, 6, 6, 6, 6, 6, 2, 6, 6, 6, 2, 6, 6, 6, 6, 6, 6, 6, 2, 6, 6, 6, 2, 6, 2, 0, 6} # 6: down to label710
                                        # 2: down to label715
                                        # 0: down to label717
.LBB36_11:                              #   in Loop: Header=BB36_4 Depth=1
	end_block                               # label717:
	local.get	2
	i32.const	6
	i32.add 
	local.tee	5
	local.get	1
	i32.gt_u
	br_if   	5                               # 5: down to label710
# %bb.12:                               #   in Loop: Header=BB36_4 Depth=1
	local.get	2
	i32.const	2
	i32.add 
	local.tee	10
	local.get	5
	i32.ge_u
	br_if   	2                               # 2: down to label714
# %bb.13:                               #   in Loop: Header=BB36_4 Depth=1
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label718
# %bb.14:                               #   in Loop: Header=BB36_4 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label710
.LBB36_15:                              #   in Loop: Header=BB36_4 Depth=1
	end_block                               # label718:
	block   	
	local.get	8
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label719
# %bb.16:                               #   in Loop: Header=BB36_4 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label710
.LBB36_17:                              #   in Loop: Header=BB36_4 Depth=1
	end_block                               # label719:
	block   	
	local.get	7
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label720
# %bb.18:                               #   in Loop: Header=BB36_4 Depth=1
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	6                               # 6: down to label710
.LBB36_19:                              #   in Loop: Header=BB36_4 Depth=1
	end_block                               # label720:
	local.get	6
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label714
# %bb.20:                               #   in Loop: Header=BB36_4 Depth=1
	local.get	2
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label714
	br      	5                               # 5: down to label710
.LBB36_21:                              #   in Loop: Header=BB36_4 Depth=1
	end_block                               # label716:
	local.get	10
	i32.const	32
	i32.lt_u
	br_if   	4                               # 4: down to label710
# %bb.22:                               #   in Loop: Header=BB36_4 Depth=1
	local.get	2
	i32.const	1
	i32.add 
	local.set	5
	local.get	10
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label714
# %bb.23:
	local.get	3
	local.get	5
	i32.store	0
	i32.const	1
	return
.LBB36_24:                              #   in Loop: Header=BB36_4 Depth=1
	end_block                               # label715:
	local.get	2
	i32.const	2
	i32.add 
	local.set	5
.LBB36_25:                              #   in Loop: Header=BB36_4 Depth=1
	end_block                               # label714:
	local.get	5
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: up to label712
	br      	2                               # 2: down to label710
.LBB36_26:
	end_loop
	end_block                               # label711:
	block   	
	local.get	5
	i32.const	223
	i32.and 
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label721
# %bb.27:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	i32.const	0
	i32.const	0
	i32.const	0
	i32.const	0
	call	parse_composite_span_impl
	return
.LBB36_28:
	end_block                               # label721:
	local.get	0
	local.get	1
	local.get	2
	local.get	3
	call	parse_scalar_span
	local.set	4
.LBB36_29:
	end_block                               # label710:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_scalar_span,"",@
	.type	parse_scalar_span,@function     # -- Begin function parse_scalar_span
parse_scalar_span:                      # @parse_scalar_span
	.functype	parse_scalar_span (i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	4
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label722
# %bb.1:
	local.get	2
	local.set	5
.LBB37_2:                               # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label724:
	block   	
	local.get	1
	local.get	5
	local.tee	6
	i32.ne  
	br_if   	0                               # 0: down to label725
# %bb.3:
	local.get	1
	local.set	6
	br      	2                               # 2: down to label723
.LBB37_4:                               #   in Loop: Header=BB37_2 Depth=1
	end_block                               # label725:
	block   	
	block   	
	local.get	0
	local.get	6
	i32.add 
	i32.load8_u	0
	local.tee	7
	i32.const	-10
	i32.add 
	br_table 	{3, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 0} # 1: down to label726
                                        # 3: down to label723
                                        # 0: down to label727
.LBB37_5:                               #   in Loop: Header=BB37_2 Depth=1
	end_block                               # label727:
	local.get	7
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label723
# %bb.6:                                #   in Loop: Header=BB37_2 Depth=1
	local.get	7
	i32.const	125
	i32.eq  
	br_if   	2                               # 2: down to label723
.LBB37_7:                               #   in Loop: Header=BB37_2 Depth=1
	end_block                               # label726:
	local.get	6
	i32.const	1
	i32.add 
	local.set	5
	local.get	7
	i32.const	9
	i32.ne  
	br_if   	0                               # 0: up to label724
.LBB37_8:
	end_loop
	end_block                               # label723:
	local.get	6
	local.get	2
	i32.eq  
	br_if   	0                               # 0: down to label722
# %bb.9:
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	local.tee	7
	i32.load8_u	0
	i32.const	-102
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 2, 3, 3, 3, 3, 3, 0, 3} # 3: down to label729
                                        # 2: down to label730
                                        # 0: down to label732
.LBB37_10:
	end_block                               # label732:
	local.get	6
	local.get	2
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	4                               # 4: down to label722
# %bb.11:
	local.get	7
	i32.load8_u	0
	i32.const	116
	i32.ne  
	br_if   	4                               # 4: down to label722
# %bb.12:
	local.get	7
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	114
	i32.ne  
	br_if   	4                               # 4: down to label722
# %bb.13:
	local.get	7
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	4                               # 4: down to label722
# %bb.14:
	local.get	7
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	101
	i32.eq  
	br_if   	3                               # 3: down to label728
	br      	4                               # 4: down to label722
.LBB37_15:
	end_block                               # label731:
	local.get	6
	local.get	2
	i32.sub 
	i32.const	5
	i32.ne  
	br_if   	3                               # 3: down to label722
# %bb.16:
	local.get	7
	i32.load8_u	0
	i32.const	102
	i32.ne  
	br_if   	3                               # 3: down to label722
# %bb.17:
	local.get	7
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	97
	i32.ne  
	br_if   	3                               # 3: down to label722
# %bb.18:
	local.get	7
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	3                               # 3: down to label722
# %bb.19:
	local.get	7
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	115
	i32.ne  
	br_if   	3                               # 3: down to label722
# %bb.20:
	local.get	7
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	101
	i32.eq  
	br_if   	2                               # 2: down to label728
	br      	3                               # 3: down to label722
.LBB37_21:
	end_block                               # label730:
	local.get	6
	local.get	2
	i32.sub 
	i32.const	4
	i32.ne  
	br_if   	2                               # 2: down to label722
# %bb.22:
	local.get	7
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	2                               # 2: down to label722
# %bb.23:
	local.get	7
	i32.const	1
	i32.add 
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	2                               # 2: down to label722
# %bb.24:
	local.get	7
	i32.const	2
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.ne  
	br_if   	2                               # 2: down to label722
# %bb.25:
	local.get	7
	i32.const	3
	i32.add 
	i32.load8_u	0
	i32.const	108
	i32.eq  
	br_if   	1                               # 1: down to label728
	br      	2                               # 2: down to label722
.LBB37_26:
	end_block                               # label729:
	local.get	0
	local.get	2
	local.get	6
	call	is_valid_json_number
	i32.eqz
	br_if   	1                               # 1: down to label722
.LBB37_27:
	end_block                               # label728:
	local.get	3
	local.get	6
	i32.store	0
	i32.const	1
	local.set	4
.LBB37_28:
	end_block                               # label722:
	local.get	4
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.parse_composite_span_impl,"",@
	.type	parse_composite_span_impl,@function # -- Begin function parse_composite_span_impl
parse_composite_span_impl:              # @parse_composite_span_impl
	.functype	parse_composite_span_impl (i32, i32, i32, i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64, i32, i32, i32, i32
# %bb.0:
	global.get	__stack_pointer
	i32.const	272
	i32.sub 
	local.tee	8
	global.set	__stack_pointer
	i32.const	0
	local.set	9
	block   	
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label733
# %bb.1:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	0                               # 0: down to label733
# %bb.2:
	i32.const	0
	local.set	9
	local.get	2
	i32.const	1
	i32.add 
	local.tee	11
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label733
# %bb.3:
	local.get	7
	i32.const	0
	i32.ne  
	local.get	10
	i32.const	91
	i32.eq  
	local.tee	2
	i32.and 
	local.set	12
	local.get	0
	i32.const	1
	i32.add 
	local.set	13
	i32.const	0
	i32.const	3
	local.get	2
	i32.select
	local.set	14
	local.get	0
	i32.const	19
	i32.add 
	local.set	15
	local.get	0
	i32.const	17
	i32.add 
	local.set	16
	local.get	0
	i32.const	16
	i32.add 
	local.set	17
	local.get	0
	i32.const	15
	i32.add 
	local.set	18
	local.get	0
	i32.const	14
	i32.add 
	local.set	19
	local.get	0
	i32.const	13
	i32.add 
	local.set	20
	local.get	0
	i32.const	12
	i32.add 
	local.set	21
	local.get	0
	i32.const	11
	i32.add 
	local.set	22
	local.get	0
	i32.const	10
	i32.add 
	local.set	23
	local.get	0
	i32.const	9
	i32.add 
	local.set	24
	local.get	0
	i32.const	8
	i32.add 
	local.set	25
	local.get	0
	i32.const	7
	i32.add 
	local.set	26
	local.get	0
	i32.const	3
	i32.add 
	local.set	27
	local.get	0
	i32.const	2
	i32.add 
	local.set	28
	local.get	0
	i32.const	4
	i32.add 
	local.set	29
	local.get	0
	i32.const	5
	i32.add 
	local.set	30
	i32.const	1
	local.set	31
	i32.const	0
	local.set	32
	i32.const	0
	local.set	33
	i32.const	0
	local.set	34
.LBB38_4:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB38_103 Depth 2
                                        #     Child Loop BB38_342 Depth 2
                                        #     Child Loop BB38_348 Depth 2
	block   	
	loop    	                                # label735:
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	0
	local.get	11
	i32.add 
	local.tee	35
	i32.load8_u	0
	local.tee	2
	i32.const	-9
	i32.add 
	br_table 	{1, 1, 8, 8, 1, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 1, 8, 2, 8, 8, 8, 8, 8, 8, 8, 8, 8, 6, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 8, 7, 0} # 1: down to label748
                                        # 8: down to label741
                                        # 2: down to label747
                                        # 6: down to label743
                                        # 7: down to label742
                                        # 0: down to label749
.LBB38_5:                               #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label749:
	local.get	2
	i32.const	93
	i32.eq  
	br_if   	2                               # 2: down to label746
# %bb.6:                                #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	i32.const	125
	i32.ne  
	br_if   	7                               # 7: down to label741
# %bb.7:                                #   in Loop: Header=BB38_4 Depth=1
	i32.const	0
	local.set	9
	local.get	14
	i32.const	255
	i32.and 
	i32.const	-3
	i32.add 
	br_table 	{3, 15, 15, 3, 15}      # 15: down to label733
                                        # 3: down to label745
.LBB38_8:                               #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label748:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label750
# %bb.9:                                #   in Loop: Header=BB38_4 Depth=1
	local.get	5
	i32.load	0
	br_if   	0                               # 0: down to label750
# %bb.10:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB38_11:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label750:
	local.get	11
	i32.const	1
	i32.add 
	local.set	11
	br      	11                              # 11: down to label736
.LBB38_12:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label747:
	local.get	14
	i32.const	251
	i32.and 
	local.tee	36
	i32.const	3
	i32.ne  
	local.tee	37
	br_if   	7                               # 7: down to label739
# %bb.13:                               #   in Loop: Header=BB38_4 Depth=1
	block   	
	block   	
	block   	
	block   	
	local.get	1
	local.get	11
	i32.sub 
	local.tee	2
	i32.const	9
	i32.lt_u
	br_if   	0                               # 0: down to label754
# %bb.14:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i64.load	0:p2align=0
	local.tee	38
	i64.const	8389754706581218082
	i64.eq  
	br_if   	2                               # 2: down to label752
# %bb.15:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	38
	i32.wrap_i64
	local.set	2
	br      	1                               # 1: down to label753
.LBB38_16:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label754:
	local.get	2
	i32.const	5
	i32.lt_u
	br_if   	10                              # 10: down to label739
# %bb.17:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.load	0:p2align=0
	local.set	2
.LBB38_18:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label753:
	local.get	2
	i32.const	1734439970
	i32.ne  
	br_if   	9                               # 9: down to label739
# %bb.19:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label751
	br      	9                               # 9: down to label739
.LBB38_20:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label752:
	local.get	35
	i32.const	8
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	8                               # 8: down to label739
# %bb.21:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	9
	i32.add 
	local.set	7
	i32.const	4
	local.set	2
	br      	7                               # 7: down to label740
.LBB38_22:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label751:
	i32.const	0
	local.set	2
	local.get	11
	i32.const	5
	i32.add 
	local.tee	7
	local.get	1
	i32.ge_u
	br_if   	6                               # 6: down to label740
# %bb.23:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	6                               # 6: down to label740
# %bb.24:                               #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	11
	i32.const	6
	i32.add 
	local.tee	9
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label755
# %bb.25:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	7
	i32.add 
	local.get	9
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.eq  
	i32.select
	local.set	9
.LBB38_26:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label755:
	local.get	1
	local.get	9
	i32.sub 
	local.tee	10
	i32.const	4
	i32.lt_u
	br_if   	6                               # 6: down to label740
# %bb.27:                               #   in Loop: Header=BB38_4 Depth=1
	block   	
	block   	
	local.get	0
	local.get	9
	i32.add 
	local.tee	14
	i32.load	0:p2align=0
	local.tee	11
	i32.const	740450593
	i32.gt_s
	br_if   	0                               # 0: down to label757
# %bb.28:                               #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	11
	i32.const	577334306
	i32.eq  
	br_if   	0                               # 0: down to label758
# %bb.29:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	577533218
	i32.eq  
	br_if   	0                               # 0: down to label758
# %bb.30:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	578056738
	i32.ne  
	br_if   	9                               # 9: down to label740
.LBB38_31:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label758:
	local.get	10
	i32.const	4
	i32.eq  
	br_if   	8                               # 8: down to label740
# %bb.32:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	14
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	8                               # 8: down to label740
# %bb.33:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	5
	i32.add 
	local.set	11
	br      	1                               # 1: down to label756
.LBB38_34:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label757:
	block   	
	block   	
	local.get	11
	i32.const	1651864097
	i32.gt_s
	br_if   	0                               # 0: down to label760
# %bb.35:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	740450594
	i32.eq  
	br_if   	1                               # 1: down to label759
# %bb.36:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	1634759458
	i32.ne  
	br_if   	9                               # 9: down to label740
# %bb.37:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	7
	i32.lt_u
	br_if   	9                               # 9: down to label740
# %bb.38:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	14
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	110
	i32.ne  
	br_if   	9                               # 9: down to label740
# %bb.39:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	14
	i32.const	5
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	9                               # 9: down to label740
# %bb.40:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	14
	i32.const	6
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	9                               # 9: down to label740
# %bb.41:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	7
	i32.add 
	local.set	11
	br      	2                               # 2: down to label756
.LBB38_42:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label760:
	block   	
	local.get	11
	i32.const	1651864098
	i32.eq  
	br_if   	0                               # 0: down to label761
# %bb.43:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	1986618402
	i32.ne  
	br_if   	9                               # 9: down to label740
# %bb.44:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	6
	i32.lt_u
	br_if   	9                               # 9: down to label740
# %bb.45:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	14
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	9                               # 9: down to label740
# %bb.46:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	14
	i32.const	5
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	9                               # 9: down to label740
# %bb.47:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	6
	i32.add 
	local.set	11
	br      	2                               # 2: down to label756
.LBB38_48:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label761:
	local.get	10
	i32.const	7
	i32.lt_u
	br_if   	8                               # 8: down to label740
# %bb.49:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	14
	i32.const	4
	i32.add 
	i32.load8_u	0
	i32.const	121
	i32.ne  
	br_if   	8                               # 8: down to label740
# %bb.50:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	14
	i32.const	5
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	8                               # 8: down to label740
# %bb.51:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	14
	i32.const	6
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	8                               # 8: down to label740
# %bb.52:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	7
	i32.add 
	local.set	11
	br      	1                               # 1: down to label756
.LBB38_53:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label759:
	local.get	9
	i32.const	4
	i32.add 
	local.set	11
.LBB38_54:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label756:
	local.get	11
	i32.eqz
	br_if   	6                               # 6: down to label740
# %bb.55:                               #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label762
# %bb.56:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	13
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	0                               # 0: down to label762
# %bb.57:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB38_58:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label762:
	i32.const	0
	local.get	32
	local.get	31
	i32.const	2
	i32.eq  
	i32.select
	local.get	32
	local.get	12
	i32.select
	local.set	32
	i32.const	7
	local.set	14
	local.get	11
	local.get	1
	i32.ge_u
	br_if   	10                              # 10: down to label736
# %bb.59:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	10                              # 10: down to label736
# %bb.60:                               #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label763
# %bb.61:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB38_62:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label763:
	local.get	11
	i32.const	1
	i32.add 
	local.set	11
	br      	10                              # 10: down to label736
.LBB38_63:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label746:
	local.get	14
	i32.const	255
	i32.and 
	i32.const	1
	i32.le_u
	br_if   	1                               # 1: down to label744
	br      	11                              # 11: down to label734
.LBB38_64:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label745:
	local.get	12
	local.get	31
	i32.const	2
	i32.eq  
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label744
# %bb.65:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	33
	local.get	34
	i32.and 
	i32.eqz
	br_if   	11                              # 11: down to label733
.LBB38_66:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label744:
	local.get	11
	i32.const	1
	i32.add 
	local.set	11
	block   	
	local.get	31
	i32.const	-1
	i32.add 
	local.tee	2
	br_if   	0                               # 0: down to label764
# %bb.67:
	local.get	3
	local.get	11
	i32.store	0
	i32.const	1
	local.set	9
	br      	11                              # 11: down to label733
.LBB38_68:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label764:
	local.get	31
	local.get	8
	i32.const	16
	i32.add 
	i32.add 
	i32.const	-2
	i32.add 
	i32.load8_u	0
	local.set	14
	local.get	2
	local.set	31
	br      	7                               # 7: down to label736
.LBB38_69:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label743:
	local.get	14
	i32.const	255
	i32.and 
	local.set	2
	i32.const	2
	local.set	14
	i32.const	0
	local.set	9
	block   	
	block   	
	local.get	2
	i32.const	-1
	i32.add 
	br_table 	{1, 11, 11, 11, 11, 0, 11} # 11: down to label733
                                        # 0: down to label766
.LBB38_70:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label766:
	i32.const	7
	local.set	14
.LBB38_71:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label765:
	block   	
	local.get	11
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label767
# %bb.72:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	local.set	11
	br      	7                               # 7: down to label736
.LBB38_73:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label767:
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.eq  
	br_if   	0                               # 0: down to label768
# %bb.74:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	local.set	11
	br      	7                               # 7: down to label736
.LBB38_75:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label768:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label769
# %bb.76:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB38_77:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label769:
	local.get	11
	i32.const	2
	i32.add 
	local.set	11
	br      	6                               # 6: down to label736
.LBB38_78:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label742:
	local.get	14
	i32.const	255
	i32.and 
	i32.const	4
	i32.ne  
	br_if   	7                               # 7: down to label734
# %bb.79:                               #   in Loop: Header=BB38_4 Depth=1
	i32.const	5
	local.set	14
	block   	
	local.get	11
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: down to label770
# %bb.80:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	local.set	11
	br      	6                               # 6: down to label736
.LBB38_81:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label770:
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.eq  
	br_if   	0                               # 0: down to label771
# %bb.82:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	local.set	11
	br      	6                               # 6: down to label736
.LBB38_83:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label771:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label772
# %bb.84:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB38_85:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label772:
	local.get	11
	i32.const	2
	i32.add 
	local.set	11
	br      	5                               # 5: down to label736
.LBB38_86:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label741:
	block   	
	block   	
	block   	
	local.get	14
	i32.const	253
	i32.and 
	br_if   	0                               # 0: down to label775
# %bb.87:                               #   in Loop: Header=BB38_4 Depth=1
	i32.const	1
	local.set	14
	br      	1                               # 1: down to label774
.LBB38_88:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label775:
	local.get	14
	i32.const	255
	i32.and 
	i32.const	5
	i32.ne  
	br_if   	8                               # 8: down to label734
# %bb.89:                               #   in Loop: Header=BB38_4 Depth=1
	i32.const	6
	local.set	14
	local.get	12
	local.get	31
	i32.const	2
	i32.eq  
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	0                               # 0: down to label774
# %bb.90:                               #   in Loop: Header=BB38_4 Depth=1
	i32.const	0
	local.set	7
	block   	
	block   	
	local.get	32
	i32.const	-4
	i32.add 
	br_table 	{0, 1, 1, 1, 3, 1}      # 1: down to label776
                                        # 3: down to label773
.LBB38_91:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label777:
	local.get	2
	i32.const	223
	i32.and 
	i32.const	91
	i32.ne  
	br_if   	0                               # 0: down to label776
# %bb.92:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	34
	i32.const	4
	i32.or  
	local.set	34
	br      	1                               # 1: down to label774
.LBB38_93:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label776:
	local.get	34
	local.get	32
	i32.const	-1
	i32.xor 
	i32.and 
	local.set	34
.LBB38_94:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label774:
	local.get	33
	local.set	7
.LBB38_95:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label773:
	block   	
	local.get	2
	i32.const	32
	i32.or  
	i32.const	123
	i32.ne  
	br_if   	0                               # 0: down to label778
# %bb.96:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	31
	i32.const	255
	i32.gt_u
	br_if   	7                               # 7: down to label734
# %bb.97:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	31
	local.get	8
	i32.const	16
	i32.add 
	i32.add 
	i32.const	-1
	i32.add 
	local.get	14
	i32.store8	0
	i32.const	0
	local.get	32
	local.get	12
	local.get	31
	i32.const	1
	i32.eq  
	i32.and 
	local.get	2
	i32.const	123
	i32.eq  
	i32.and 
	local.tee	9
	i32.select
	local.set	32
	i32.const	0
	local.get	7
	local.get	9
	i32.select
	local.set	33
	i32.const	0
	local.get	34
	local.get	9
	i32.select
	local.set	34
	i32.const	0
	i32.const	3
	local.get	2
	i32.const	91
	i32.eq  
	i32.select
	local.set	14
	local.get	11
	i32.const	1
	i32.add 
	local.set	11
	local.get	31
	i32.const	1
	i32.add 
	local.set	31
	br      	5                               # 5: down to label736
.LBB38_98:                              #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label778:
	local.get	8
	i32.const	0
	i32.store	12
	local.get	0
	local.get	1
	local.get	11
	local.get	8
	i32.const	12
	i32.add 
	call	parse_scalar_span
	i32.eqz
	br_if   	6                               # 6: down to label734
# %bb.99:                               #   in Loop: Header=BB38_4 Depth=1
	local.get	8
	i32.load	12
	local.set	11
	local.get	7
	local.set	33
	br      	4                               # 4: down to label736
.LBB38_100:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label740:
	local.get	2
	local.get	32
	local.get	31
	i32.const	2
	i32.eq  
	i32.select
	local.get	32
	local.get	12
	i32.select
	local.set	32
	br      	1                               # 1: down to label738
.LBB38_101:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label739:
	i32.const	0
	local.set	9
	local.get	11
	i32.const	1
	i32.add 
	local.tee	39
	local.get	1
	i32.ge_u
	br_if   	5                               # 5: down to label733
# %bb.102:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	39
	local.set	7
.LBB38_103:                             #   Parent Loop BB38_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label779:
	block   	
	local.get	7
	local.tee	2
	i32.const	8
	i32.add 
	local.tee	7
	local.get	1
	i32.gt_u
	br_if   	0                               # 0: down to label780
# %bb.104:                              #   in Loop: Header=BB38_103 Depth=2
	local.get	0
	local.get	2
	i32.add 
	i64.load	0:p2align=0
	local.tee	38
	i64.const	-1
	i64.xor 
	local.get	38
	i64.const	2459565876494606882
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	local.get	38
	i64.const	6655295901103053916
	i64.xor 
	i64.const	-72340172838076673
	i64.add 
	i64.or  
	local.get	38
	i64.const	-2314885530818453536
	i64.add 
	i64.or  
	i64.and 
	i64.const	-9187201950435737472
	i64.and 
	local.tee	38
	i64.eqz
	br_if   	1                               # 1: up to label779
# %bb.105:                              #   in Loop: Header=BB38_103 Depth=2
	local.get	38
	i64.ctz 
	i32.wrap_i64
	i32.const	3
	i32.shr_u
	local.get	2
	i32.add 
	local.set	2
.LBB38_106:                             #   in Loop: Header=BB38_103 Depth=2
	end_block                               # label780:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	6                               # 6: down to label733
# %bb.107:                              #   in Loop: Header=BB38_103 Depth=2
	block   	
	block   	
	block   	
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	92
	i32.ne  
	br_if   	0                               # 0: down to label783
# %bb.108:                              #   in Loop: Header=BB38_103 Depth=2
	local.get	2
	i32.const	1
	i32.add 
	local.tee	7
	local.get	1
	i32.ge_u
	br_if   	9                               # 9: down to label733
# %bb.109:                              #   in Loop: Header=BB38_103 Depth=2
	block   	
	block   	
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	-34
	i32.add 
	br_table 	{1, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 1, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 11, 1, 11, 11, 11, 11, 11, 1, 11, 11, 11, 1, 11, 11, 11, 11, 11, 11, 11, 1, 11, 11, 11, 1, 11, 1, 0, 11} # 11: down to label733
                                        # 1: down to label784
                                        # 0: down to label785
.LBB38_110:                             #   in Loop: Header=BB38_103 Depth=2
	end_block                               # label785:
	local.get	2
	i32.const	6
	i32.add 
	local.tee	7
	local.get	1
	i32.gt_u
	br_if   	10                              # 10: down to label733
# %bb.111:                              #   in Loop: Header=BB38_103 Depth=2
	local.get	2
	i32.const	2
	i32.add 
	local.tee	10
	local.get	7
	i32.ge_u
	br_if   	2                               # 2: down to label782
# %bb.112:                              #   in Loop: Header=BB38_103 Depth=2
	block   	
	local.get	0
	local.get	10
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label786
# %bb.113:                              #   in Loop: Header=BB38_103 Depth=2
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	11                              # 11: down to label733
.LBB38_114:                             #   in Loop: Header=BB38_103 Depth=2
	end_block                               # label786:
	block   	
	local.get	27
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label787
# %bb.115:                              #   in Loop: Header=BB38_103 Depth=2
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	11                              # 11: down to label733
.LBB38_116:                             #   in Loop: Header=BB38_103 Depth=2
	end_block                               # label787:
	block   	
	local.get	29
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	10
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	0                               # 0: down to label788
# %bb.117:                              #   in Loop: Header=BB38_103 Depth=2
	local.get	10
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.lt_u
	br_if   	11                              # 11: down to label733
.LBB38_118:                             #   in Loop: Header=BB38_103 Depth=2
	end_block                               # label788:
	local.get	30
	local.get	2
	i32.add 
	i32.load8_u	0
	local.tee	2
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	245
	i32.gt_u
	br_if   	2                               # 2: down to label782
# %bb.119:                              #   in Loop: Header=BB38_103 Depth=2
	local.get	2
	i32.const	-33
	i32.and 
	i32.const	-71
	i32.add 
	i32.const	255
	i32.and 
	i32.const	250
	i32.ge_u
	br_if   	2                               # 2: down to label782
	br      	10                              # 10: down to label733
.LBB38_120:                             #   in Loop: Header=BB38_103 Depth=2
	end_block                               # label784:
	local.get	2
	i32.const	2
	i32.add 
	local.set	7
	br      	1                               # 1: down to label782
.LBB38_121:                             #   in Loop: Header=BB38_103 Depth=2
	end_block                               # label783:
	local.get	10
	i32.const	32
	i32.lt_u
	br_if   	8                               # 8: down to label733
# %bb.122:                              #   in Loop: Header=BB38_103 Depth=2
	local.get	2
	i32.const	1
	i32.add 
	local.set	7
	local.get	10
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label781
.LBB38_123:                             #   in Loop: Header=BB38_103 Depth=2
	end_block                               # label782:
	local.get	7
	local.get	1
	i32.lt_u
	br_if   	1                               # 1: up to label779
	br      	7                               # 7: down to label733
.LBB38_124:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label781:
	end_loop
	local.get	35
	i32.const	1
	i32.add 
	local.set	10
	block   	
	local.get	4
	i32.eqz
	br_if   	0                               # 0: down to label789
# %bb.125:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.load8_u	0
	local.tee	40
	i32.const	105
	i32.eq  
	local.get	40
	i32.const	92
	i32.eq  
	local.tee	41
	i32.or  
	i32.eqz
	br_if   	0                               # 0: down to label789
# %bb.126:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	local.get	11
	i32.lt_u
	br_if   	0                               # 0: down to label789
# %bb.127:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	4
	i32.load	0
	br_if   	0                               # 0: down to label789
# %bb.128:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	4
	i32.add 
	local.set	42
	block   	
	block   	
	local.get	2
	local.get	11
	i32.eq  
	br_if   	0                               # 0: down to label791
# %bb.129:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	41
	br_if   	0                               # 0: down to label792
# %bb.130:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	local.get	11
	i32.sub 
	local.tee	41
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label791
# %bb.131:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	40
	i32.const	105
	i32.ne  
	br_if   	1                               # 1: down to label791
# %bb.132:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	35
	i32.load8_u	2
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label791
                                        # 0: down to label793
.LBB38_133:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label793:
	local.get	41
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label791
# %bb.134:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	35
	i32.load8_u	3
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label791
                                        # 0: down to label794
.LBB38_135:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label794:
	local.get	42
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label791
# %bb.136:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	42
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label791
	br      	2                               # 2: down to label790
.LBB38_137:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label792:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.6
	i32.const	3
	call	json_string_matches_ascii_escaped
	br_if   	1                               # 1: down to label790
.LBB38_138:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label791:
	local.get	2
	local.get	11
	i32.le_u
	br_if   	1                               # 1: down to label789
# %bb.139:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	block   	
	local.get	40
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label789
                                        # 0: down to label796
.LBB38_140:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label796:
	local.get	11
	i32.const	2
	i32.add 
	local.tee	40
	local.get	2
	i32.gt_u
	br_if   	2                               # 2: down to label789
# %bb.141:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	40
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label789
                                        # 0: down to label797
.LBB38_142:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label797:
	local.get	11
	i32.const	3
	i32.add 
	local.tee	40
	local.get	2
	i32.gt_u
	br_if   	2                               # 2: down to label789
# %bb.143:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	40
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 0, 3}   # 3: down to label789
                                        # 0: down to label798
.LBB38_144:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label798:
	local.get	42
	local.get	2
	i32.gt_u
	br_if   	2                               # 2: down to label789
# %bb.145:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	42
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label789
                                        # 0: down to label799
.LBB38_146:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label799:
	local.get	11
	i32.const	5
	i32.add 
	local.tee	40
	local.get	2
	i32.gt_u
	br_if   	2                               # 2: down to label789
# %bb.147:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	40
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label789
                                        # 0: down to label800
.LBB38_148:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label800:
	local.get	11
	i32.const	6
	i32.add 
	local.tee	40
	local.get	2
	i32.gt_u
	br_if   	2                               # 2: down to label789
# %bb.149:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	40
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label790
	br      	2                               # 2: down to label789
.LBB38_150:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label795:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.4
	i32.const	5
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	1                               # 1: down to label789
.LBB38_151:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label790:
	local.get	4
	i32.const	1
	i32.store	0
.LBB38_152:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label789:
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	37
	br_if   	0                               # 0: down to label805
# %bb.153:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	12
	local.get	31
	i32.const	2
	i32.eq  
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	4                               # 4: down to label801
# %bb.154:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	local.get	11
	i32.lt_u
	br_if   	3                               # 3: down to label802
# %bb.155:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	3                               # 3: down to label802
# %bb.156:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	5
	i32.add 
	local.set	14
	local.get	2
	local.get	11
	i32.eq  
	br_if   	2                               # 2: down to label803
# %bb.157:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	block   	
	local.get	13
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	9
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label807
# %bb.158:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	116
	i32.ne  
	br_if   	4                               # 4: down to label803
# %bb.159:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	local.get	11
	i32.sub 
	local.tee	9
	i32.const	1
	i32.eq  
	br_if   	4                               # 4: down to label803
# %bb.160:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	28
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label807
# %bb.161:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	32
	i32.const	121
	i32.ne  
	br_if   	4                               # 4: down to label803
# %bb.162:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	2
	i32.eq  
	br_if   	4                               # 4: down to label803
# %bb.163:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	27
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label807
# %bb.164:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	32
	i32.const	112
	i32.ne  
	br_if   	4                               # 4: down to label803
# %bb.165:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	3
	i32.eq  
	br_if   	4                               # 4: down to label803
# %bb.166:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	29
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{0, 4, 4, 4, 4, 4, 4, 4, 4, 1, 4} # 4: down to label803
                                        # 1: down to label806
.LBB38_167:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label807:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	3                               # 3: down to label803
# %bb.168:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	8
	local.set	32
	br      	5                               # 5: down to label801
.LBB38_169:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label806:
	local.get	14
	local.get	2
	i32.le_u
	br_if   	1                               # 1: down to label804
	br      	2                               # 2: down to label803
.LBB38_170:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label805:
	block   	
	block   	
	block   	
	local.get	14
	i32.const	255
	i32.and 
	i32.const	5
	i32.ne  
	br_if   	0                               # 0: down to label810
# %bb.171:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	6
	local.set	9
	i32.const	7
	local.set	14
	local.get	12
	local.get	31
	i32.const	2
	i32.eq  
	i32.and 
	i32.const	1
	i32.ne  
	br_if   	8                               # 8: down to label737
# %bb.172:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	32
	i32.const	8
	i32.ne  
	br_if   	0                               # 0: down to label811
# %bb.173:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	8
	local.set	32
	i32.const	0
	local.set	33
	local.get	2
	local.get	11
	i32.lt_u
	br_if   	9                               # 9: down to label737
# %bb.174:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	9                               # 9: down to label737
# %bb.175:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	local.get	11
	i32.sub 
	local.set	10
	local.get	11
	i32.const	4
	i32.add 
	local.set	35
	local.get	11
	i32.const	5
	i32.add 
	local.set	37
	block   	
	local.get	2
	local.get	11
	i32.eq  
	br_if   	0                               # 0: down to label812
# %bb.176:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	39
	i32.add 
	i32.load8_u	0
	local.tee	33
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label813
# %bb.177:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	33
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label812
# %bb.178:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	1
	i32.eq  
	br_if   	1                               # 1: down to label812
# %bb.179:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	28
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label812
                                        # 0: down to label814
.LBB38_180:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label814:
	local.get	10
	i32.const	2
	i32.eq  
	br_if   	1                               # 1: down to label812
# %bb.181:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	27
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	33
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label813
# %bb.182:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	33
	i32.const	120
	i32.ne  
	br_if   	1                               # 1: down to label812
# %bb.183:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	3
	i32.eq  
	br_if   	1                               # 1: down to label812
# %bb.184:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	35
	i32.add 
	i32.load8_u	0
	local.tee	33
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label813
# %bb.185:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	33
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label812
# %bb.186:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	local.get	2
	i32.ge_u
	br_if   	1                               # 1: down to label812
# %bb.187:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	37
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label812
# %bb.188:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	1
	local.set	33
	br      	11                              # 11: down to label737
.LBB38_189:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label813:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	0                               # 0: down to label812
# %bb.190:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	1
	local.set	33
	br      	10                              # 10: down to label737
.LBB38_191:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label812:
	i32.const	0
	local.set	33
	i32.const	6
	local.set	9
	local.get	2
	local.get	11
	i32.le_u
	br_if   	9                               # 9: down to label737
# %bb.192:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	0
	local.get	10
	local.get	10
	local.get	2
	i32.gt_u
	i32.select
	local.set	10
	local.get	11
	i32.const	6
	i32.add 
	local.set	41
	block   	
	block   	
	local.get	0
	local.get	39
	i32.add 
	local.tee	39
	i32.load8_u	0
	local.tee	40
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label816
# %bb.193:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	40
	i32.const	105
	i32.ne  
	br_if   	5                               # 5: down to label808
# %bb.194:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	1
	i32.eq  
	br_if   	5                               # 5: down to label808
# %bb.195:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	28
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 6} # 6: down to label808
                                        # 0: down to label817
.LBB38_196:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label817:
	local.get	10
	i32.const	2
	i32.eq  
	br_if   	5                               # 5: down to label808
# %bb.197:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	27
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 6, 6, 6, 6, 0, 6}   # 6: down to label808
                                        # 0: down to label818
.LBB38_198:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label818:
	local.get	10
	i32.const	3
	i32.eq  
	br_if   	5                               # 5: down to label808
# %bb.199:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	35
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 0, 6} # 6: down to label808
                                        # 0: down to label819
.LBB38_200:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label819:
	local.get	10
	i32.const	4
	i32.eq  
	br_if   	5                               # 5: down to label808
# %bb.201:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	37
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{0, 5, 5, 5, 5, 5, 5, 5, 5, 1, 5} # 5: down to label808
                                        # 1: down to label815
.LBB38_202:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label816:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.4
	i32.const	5
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	4                               # 4: down to label808
# %bb.203:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	2
	local.set	33
	br      	10                              # 10: down to label737
.LBB38_204:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label815:
	local.get	37
	local.get	2
	i32.lt_u
	br_if   	2                               # 2: down to label809
	br      	3                               # 3: down to label808
.LBB38_205:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label811:
	local.get	32
	local.get	34
	i32.or  
	local.set	34
	br      	8                               # 8: down to label737
.LBB38_206:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label810:
	local.get	14
	i32.const	253
	i32.and 
	br_if   	11                              # 11: down to label733
# %bb.207:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	1
	local.set	9
	i32.const	2
	local.set	14
	br      	7                               # 7: down to label737
.LBB38_208:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label809:
	local.get	0
	local.get	41
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label808
# %bb.209:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	2
	local.set	33
	br      	6                               # 6: down to label737
.LBB38_210:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label808:
	i32.const	1
	local.set	40
	block   	
	block   	
	block   	
	block   	
	block   	
	local.get	39
	i32.load8_u	0
	local.tee	39
	i32.const	115
	i32.eq  
	br_if   	0                               # 0: down to label824
# %bb.211:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	39
	i32.const	92
	i32.ne  
	br_if   	2                               # 2: down to label822
	br      	1                               # 1: down to label823
.LBB38_212:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label824:
	local.get	10
	i32.const	1
	i32.eq  
	br_if   	9                               # 9: down to label737
# %bb.213:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	28
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	39
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label823
# %bb.214:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	39
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label822
# %bb.215:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	2
	i32.eq  
	br_if   	9                               # 9: down to label737
# %bb.216:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	27
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	39
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label823
# %bb.217:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	39
	i32.const	114
	i32.ne  
	br_if   	1                               # 1: down to label822
# %bb.218:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	3
	i32.eq  
	br_if   	9                               # 9: down to label737
# %bb.219:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	35
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label823
# %bb.220:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.const	117
	i32.ne  
	br_if   	1                               # 1: down to label822
# %bb.221:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	4
	i32.eq  
	br_if   	9                               # 9: down to label737
# %bb.222:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	37
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label822
                                        # 0: down to label825
.LBB38_223:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label825:
	local.get	10
	i32.const	5
	i32.eq  
	br_if   	9                               # 9: down to label737
# %bb.224:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	41
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label823
# %bb.225:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label822
# %bb.226:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	10
	i32.const	6
	i32.ne  
	br_if   	0                               # 0: down to label826
# %bb.227:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	6
	local.set	9
	br      	10                              # 10: down to label737
.LBB38_228:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label826:
	local.get	26
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label823
# %bb.229:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.const	117
	i32.ne  
	br_if   	1                               # 1: down to label822
# %bb.230:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	7
	i32.eq  
	br_if   	3                               # 3: down to label820
# %bb.231:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	25
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label823
# %bb.232:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.const	114
	i32.ne  
	br_if   	1                               # 1: down to label822
# %bb.233:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	8
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.234:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	24
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label822
                                        # 0: down to label827
.LBB38_235:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label827:
	local.get	10
	i32.const	9
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.236:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	23
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label822
                                        # 0: down to label828
.LBB38_237:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label828:
	local.get	10
	i32.const	10
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.238:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	22
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label823
# %bb.239:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.const	45
	i32.ne  
	br_if   	1                               # 1: down to label822
# %bb.240:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	11
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.241:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	21
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label822
                                        # 0: down to label829
.LBB38_242:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label829:
	local.get	10
	i32.const	12
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.243:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	20
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label822
                                        # 0: down to label830
.LBB38_244:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label830:
	local.get	10
	i32.const	13
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.245:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	19
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label822
                                        # 0: down to label831
.LBB38_246:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label831:
	local.get	10
	i32.const	14
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.247:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	18
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label823
# %bb.248:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label822
# %bb.249:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	15
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.250:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	17
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label822
                                        # 0: down to label832
.LBB38_251:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label832:
	local.get	10
	i32.const	16
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.252:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	16
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label822
                                        # 0: down to label833
.LBB38_253:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label833:
	local.get	10
	i32.const	17
	i32.eq  
	br_if   	2                               # 2: down to label821
# %bb.254:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	11
	i32.const	18
	i32.add 
	local.tee	10
	i32.add 
	i32.load8_u	0
	local.tee	35
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label823
# %bb.255:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label822
# %bb.256:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	local.get	2
	i32.ge_u
	br_if   	2                               # 2: down to label821
# %bb.257:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	15
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	local.set	40
	br      	1                               # 1: down to label822
.LBB38_258:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label823:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.5
	i32.const	18
	call	json_string_matches_ascii_escaped
	i32.eqz
	local.set	40
.LBB38_259:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label822:
	i32.const	0
	i32.const	4
	local.get	40
	i32.const	1
	i32.and 
	i32.select
	local.set	33
	br      	7                               # 7: down to label737
.LBB38_260:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label821:
	i32.const	8
	local.set	32
.LBB38_261:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label820:
	i32.const	7
	local.set	14
	i32.const	6
	local.set	9
	br      	5                               # 5: down to label737
.LBB38_262:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label804:
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label803
# %bb.263:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	8
	local.set	32
	br      	2                               # 2: down to label801
.LBB38_264:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label803:
	block   	
	local.get	2
	local.get	11
	i32.gt_u
	local.tee	9
	i32.eqz
	br_if   	0                               # 0: down to label834
# %bb.265:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	13
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label835
# %bb.266:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	32
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label834
# %bb.267:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	2
	i32.add 
	local.tee	32
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label834
# %bb.268:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label834
                                        # 0: down to label836
.LBB38_269:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label836:
	local.get	11
	i32.const	3
	i32.add 
	local.tee	32
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label834
# %bb.270:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label835
# %bb.271:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	32
	i32.const	120
	i32.ne  
	br_if   	1                               # 1: down to label834
# %bb.272:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	4
	i32.add 
	local.tee	32
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label834
# %bb.273:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label835
# %bb.274:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	32
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label834
# %bb.275:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	14
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label834
# %bb.276:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label834
# %bb.277:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	1
	local.set	32
	br      	3                               # 3: down to label801
.LBB38_278:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label835:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	0                               # 0: down to label834
# %bb.279:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	1
	local.set	32
	br      	2                               # 2: down to label801
.LBB38_280:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label834:
	block   	
	local.get	9
	i32.eqz
	br_if   	0                               # 0: down to label837
# %bb.281:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	13
	local.get	11
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label838
# %bb.282:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	32
	i32.const	112
	i32.ne  
	br_if   	1                               # 1: down to label837
# %bb.283:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	2
	i32.add 
	local.tee	32
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label837
# %bb.284:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 0, 2}   # 2: down to label837
                                        # 0: down to label839
.LBB38_285:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label839:
	local.get	11
	i32.const	3
	i32.add 
	local.tee	32
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label837
# %bb.286:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	local.tee	32
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label838
# %bb.287:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	32
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label837
# %bb.288:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	4
	i32.add 
	local.tee	32
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label837
# %bb.289:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	32
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label837
                                        # 0: down to label840
.LBB38_290:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label840:
	local.get	14
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label837
# %bb.291:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label837
# %bb.292:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	2
	local.set	32
	br      	3                               # 3: down to label801
.LBB38_293:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label838:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.2
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	0                               # 0: down to label837
# %bb.294:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	2
	local.set	32
	br      	2                               # 2: down to label801
.LBB38_295:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label837:
	local.get	9
	i32.eqz
	br_if   	0                               # 0: down to label802
# %bb.296:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	block   	
	local.get	13
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label802
                                        # 0: down to label842
.LBB38_297:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label842:
	local.get	11
	i32.const	2
	i32.add 
	local.tee	9
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label802
# %bb.298:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label802
                                        # 0: down to label843
.LBB38_299:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label843:
	local.get	11
	i32.const	3
	i32.add 
	local.tee	9
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label802
# %bb.300:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label802
                                        # 0: down to label844
.LBB38_301:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label844:
	local.get	11
	i32.const	4
	i32.add 
	local.tee	9
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label802
# %bb.302:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.tee	9
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label841
# %bb.303:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label802
# %bb.304:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	14
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label802
# %bb.305:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	14
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label802
                                        # 0: down to label845
.LBB38_306:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label845:
	local.get	11
	i32.const	6
	i32.add 
	local.tee	9
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label802
# %bb.307:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	-92
	i32.add 
	br_table 	{1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 2} # 2: down to label802
                                        # 0: down to label846
.LBB38_308:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label846:
	local.get	11
	i32.const	7
	i32.add 
	local.tee	9
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label802
# %bb.309:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.tee	9
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label841
# %bb.310:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	116
	i32.ne  
	br_if   	1                               # 1: down to label802
# %bb.311:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	8
	i32.add 
	local.tee	9
	local.get	2
	i32.gt_u
	br_if   	1                               # 1: down to label802
# %bb.312:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	1                               # 1: down to label802
# %bb.313:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	4
	local.set	32
	br      	2                               # 2: down to label801
.LBB38_314:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label841:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str.3
	i32.const	7
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	0                               # 0: down to label802
# %bb.315:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	4
	local.set	32
	br      	1                               # 1: down to label801
.LBB38_316:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label802:
	i32.const	0
	local.set	32
.LBB38_317:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label801:
	block   	
	local.get	10
	i32.load8_u	0
	local.tee	9
	i32.const	116
	i32.eq  
	br_if   	0                               # 0: down to label847
# %bb.318:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	92
	i32.ne  
	br_if   	1                               # 1: down to label738
.LBB38_319:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label847:
	block   	
	block   	
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label850
# %bb.320:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	5
	i32.load	0
	i32.eqz
	br_if   	1                               # 1: down to label849
.LBB38_321:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label850:
	local.get	6
	i32.eqz
	br_if   	2                               # 2: down to label738
# %bb.322:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	6
	i32.load	0
	br_if   	2                               # 2: down to label738
# %bb.323:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	local.get	11
	i32.ge_u
	br_if   	1                               # 1: down to label848
	br      	2                               # 2: down to label738
.LBB38_324:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label849:
	local.get	2
	local.get	11
	i32.lt_u
	br_if   	1                               # 1: down to label738
.LBB38_325:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label848:
	local.get	35
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label738
# %bb.326:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	local.get	11
	i32.eq  
	br_if   	0                               # 0: down to label738
# %bb.327:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	block   	
	local.get	9
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label852
# %bb.328:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	local.get	11
	i32.sub 
	local.tee	10
	i32.const	1
	i32.eq  
	br_if   	2                               # 2: down to label738
# %bb.329:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label738
# %bb.330:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.load8_u	2
	local.tee	9
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label852
# %bb.331:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	121
	i32.ne  
	br_if   	2                               # 2: down to label738
# %bb.332:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	2
	i32.eq  
	br_if   	2                               # 2: down to label738
# %bb.333:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	35
	i32.load8_u	3
	local.tee	9
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label852
# %bb.334:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	112
	i32.ne  
	br_if   	2                               # 2: down to label738
# %bb.335:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	3
	i32.eq  
	br_if   	2                               # 2: down to label738
# %bb.336:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	35
	i32.load8_u	4
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label738
                                        # 0: down to label853
.LBB38_337:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label853:
	local.get	11
	i32.const	5
	i32.add 
	local.tee	11
	local.get	2
	i32.gt_u
	br_if   	2                               # 2: down to label738
# %bb.338:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label851
	br      	2                               # 2: down to label738
.LBB38_339:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label852:
	local.get	0
	local.get	11
	local.get	7
	i32.const	.L.str
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	1                               # 1: down to label738
.LBB38_340:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label851:
	local.get	7
	local.set	2
	block   	
	local.get	7
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label854
# %bb.341:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	7
	local.set	2
.LBB38_342:                             #   Parent Loop BB38_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label855:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	11
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label854
# %bb.343:                              #   in Loop: Header=BB38_342 Depth=2
	i32.const	1
	local.get	11
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label854
# %bb.344:                              #   in Loop: Header=BB38_342 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label855
	br      	2                               # 2: down to label738
.LBB38_345:                             #   in Loop: Header=BB38_4 Depth=1
	end_loop
	end_block                               # label854:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label738
# %bb.346:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	0                               # 0: down to label738
# %bb.347:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label856
.LBB38_348:                             #   Parent Loop BB38_4 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label857:
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	-9
	i32.add 
	local.tee	11
	i32.const	23
	i32.gt_u
	br_if   	1                               # 1: down to label856
# %bb.349:                              #   in Loop: Header=BB38_348 Depth=2
	i32.const	1
	local.get	11
	i32.shl 
	i32.const	8388627
	i32.and 
	i32.eqz
	br_if   	1                               # 1: down to label856
# %bb.350:                              #   in Loop: Header=BB38_348 Depth=2
	local.get	1
	local.get	2
	i32.const	1
	i32.add 
	local.tee	2
	i32.ne  
	br_if   	0                               # 0: up to label857
	br      	2                               # 2: down to label738
.LBB38_351:                             #   in Loop: Header=BB38_4 Depth=1
	end_loop
	end_block                               # label856:
	local.get	2
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label738
# %bb.352:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	2
	i32.add 
	local.tee	11
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label738
# %bb.353:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	1
	local.get	2
	i32.const	-1
	i32.xor 
	i32.add 
	local.tee	9
	i32.eqz
	br_if   	0                               # 0: down to label738
# %bb.354:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	block   	
	local.get	11
	i32.load8_u	1
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label859
# %bb.355:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	1
	i32.eq  
	br_if   	2                               # 2: down to label738
# %bb.356:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label738
# %bb.357:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	11
	i32.load8_u	2
	i32.const	-92
	i32.add 
	br_table 	{1, 3, 3, 3, 3, 3, 3, 3, 3, 0, 3} # 3: down to label738
                                        # 0: down to label860
.LBB38_358:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label860:
	local.get	9
	i32.const	2
	i32.eq  
	br_if   	2                               # 2: down to label738
# %bb.359:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.load8_u	3
	local.tee	10
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label859
# %bb.360:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	10
	i32.const	120
	i32.ne  
	br_if   	2                               # 2: down to label738
# %bb.361:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	9
	i32.const	3
	i32.eq  
	br_if   	2                               # 2: down to label738
# %bb.362:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.load8_u	4
	local.tee	11
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label859
# %bb.363:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	11
	i32.const	116
	i32.ne  
	br_if   	2                               # 2: down to label738
# %bb.364:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	2
	i32.const	5
	i32.add 
	local.tee	2
	local.get	1
	i32.ge_u
	br_if   	2                               # 2: down to label738
# %bb.365:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	2
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	br_if   	1                               # 1: down to label858
	br      	2                               # 2: down to label738
.LBB38_366:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label859:
	local.get	0
	local.get	2
	local.get	1
	i32.const	.L.str.1
	i32.const	4
	call	json_string_matches_ascii_escaped
	i32.eqz
	br_if   	1                               # 1: down to label738
.LBB38_367:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label858:
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label861
# %bb.368:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB38_369:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label861:
	local.get	6
	i32.eqz
	br_if   	0                               # 0: down to label738
# %bb.370:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	6
	i32.const	1
	i32.store	0
.LBB38_371:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label738:
	i32.const	4
	local.set	9
	i32.const	2
	local.set	14
	local.get	7
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label737
# %bb.372:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	58
	i32.ne  
	br_if   	0                               # 0: down to label737
# %bb.373:                              #   in Loop: Header=BB38_4 Depth=1
	i32.const	5
	local.set	14
	local.get	7
	i32.const	1
	i32.add 
	local.tee	11
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label736
# %bb.374:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	1                               # 1: down to label736
# %bb.375:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label862
# %bb.376:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB38_377:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label862:
	local.get	7
	i32.const	2
	i32.add 
	local.set	11
	br      	1                               # 1: down to label736
.LBB38_378:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label737:
	block   	
	local.get	36
	i32.const	3
	i32.eq  
	br_if   	0                               # 0: down to label863
# %bb.379:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	7
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label863
# %bb.380:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	7
	i32.add 
	i32.load8_u	0
	i32.const	44
	i32.ne  
	br_if   	0                               # 0: down to label863
# %bb.381:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	7
	i32.const	1
	i32.add 
	local.tee	11
	local.get	1
	i32.ge_u
	br_if   	1                               # 1: down to label736
# %bb.382:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	0
	local.get	11
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.ne  
	br_if   	1                               # 1: down to label736
# %bb.383:                              #   in Loop: Header=BB38_4 Depth=1
	block   	
	local.get	5
	i32.eqz
	br_if   	0                               # 0: down to label864
# %bb.384:                              #   in Loop: Header=BB38_4 Depth=1
	local.get	5
	i32.const	1
	i32.store	0
.LBB38_385:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label864:
	local.get	7
	i32.const	2
	i32.add 
	local.set	11
	br      	1                               # 1: down to label736
.LBB38_386:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label863:
	local.get	9
	local.set	14
	local.get	7
	local.set	11
.LBB38_387:                             #   in Loop: Header=BB38_4 Depth=1
	end_block                               # label736:
	local.get	11
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: up to label735
.LBB38_388:
	end_loop
	end_block                               # label734:
	i32.const	0
	local.set	9
.LBB38_389:
	end_block                               # label733:
	local.get	8
	i32.const	272
	i32.add 
	global.set	__stack_pointer
	local.get	9
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.json_string_matches_ascii_escaped,"",@
	.type	json_string_matches_ascii_escaped,@function # -- Begin function json_string_matches_ascii_escaped
json_string_matches_ascii_escaped:      # @json_string_matches_ascii_escaped
	.functype	json_string_matches_ascii_escaped (i32, i32, i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	0
	local.set	5
	block   	
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label865
# %bb.1:
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.ne  
	br_if   	0                               # 0: down to label865
# %bb.2:
	local.get	1
	i32.const	1
	i32.add 
	local.tee	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label865
# %bb.3:
	i32.const	0
	local.set	6
.LBB39_4:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label866:
	local.get	1
	i32.const	1
	i32.add 
	local.set	7
	block   	
	block   	
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	8
	i32.const	92
	i32.eq  
	br_if   	0                               # 0: down to label868
# %bb.5:                                #   in Loop: Header=BB39_4 Depth=1
	local.get	7
	local.set	1
	br      	1                               # 1: down to label867
.LBB39_6:                               #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label868:
	i32.const	0
	local.set	5
	local.get	2
	local.get	7
	i32.sub 
	i32.const	5
	i32.lt_u
	br_if   	2                               # 2: down to label865
# %bb.7:                                #   in Loop: Header=BB39_4 Depth=1
	local.get	0
	local.get	7
	i32.add 
	local.tee	7
	i32.load8_u	0
	i32.const	117
	i32.ne  
	br_if   	2                               # 2: down to label865
# %bb.8:                                #   in Loop: Header=BB39_4 Depth=1
	i32.const	-48
	local.set	9
	i32.const	-48
	local.set	10
	block   	
	block   	
	local.get	7
	i32.load8_u	1
	local.tee	8
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label870
# %bb.9:                                #   in Loop: Header=BB39_4 Depth=1
	block   	
	local.get	8
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label871
# %bb.10:                               #   in Loop: Header=BB39_4 Depth=1
	i32.const	-87
	local.set	10
	br      	1                               # 1: down to label870
.LBB39_11:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label871:
	block   	
	local.get	8
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label872
# %bb.12:                               #   in Loop: Header=BB39_4 Depth=1
	i32.const	-1
	local.set	8
	br      	2                               # 2: down to label869
.LBB39_13:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label872:
	i32.const	-55
	local.set	10
.LBB39_14:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label870:
	block   	
	local.get	7
	i32.load8_u	2
	local.tee	5
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label873
# %bb.15:                               #   in Loop: Header=BB39_4 Depth=1
	block   	
	local.get	5
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label874
# %bb.16:                               #   in Loop: Header=BB39_4 Depth=1
	i32.const	-87
	local.set	9
	br      	1                               # 1: down to label873
.LBB39_17:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label874:
	block   	
	local.get	5
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label875
# %bb.18:                               #   in Loop: Header=BB39_4 Depth=1
	i32.const	-1
	local.set	8
	br      	2                               # 2: down to label869
.LBB39_19:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label875:
	i32.const	-55
	local.set	9
.LBB39_20:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label873:
	i32.const	-48
	local.set	11
	i32.const	-48
	local.set	12
	block   	
	local.get	7
	i32.load8_u	3
	local.tee	13
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label876
# %bb.21:                               #   in Loop: Header=BB39_4 Depth=1
	block   	
	local.get	13
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label877
# %bb.22:                               #   in Loop: Header=BB39_4 Depth=1
	i32.const	-87
	local.set	12
	br      	1                               # 1: down to label876
.LBB39_23:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label877:
	block   	
	local.get	13
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label878
# %bb.24:                               #   in Loop: Header=BB39_4 Depth=1
	i32.const	-1
	local.set	8
	br      	2                               # 2: down to label869
.LBB39_25:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label878:
	i32.const	-55
	local.set	12
.LBB39_26:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label876:
	block   	
	local.get	7
	i32.load8_u	4
	local.tee	7
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label879
# %bb.27:                               #   in Loop: Header=BB39_4 Depth=1
	block   	
	local.get	7
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label880
# %bb.28:                               #   in Loop: Header=BB39_4 Depth=1
	i32.const	-87
	local.set	11
	br      	1                               # 1: down to label879
.LBB39_29:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label880:
	block   	
	local.get	7
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label881
# %bb.30:                               #   in Loop: Header=BB39_4 Depth=1
	i32.const	-1
	local.set	8
	br      	2                               # 2: down to label869
.LBB39_31:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label881:
	i32.const	-55
	local.set	11
.LBB39_32:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label879:
	local.get	11
	local.get	7
	i32.add 
	local.get	9
	local.get	5
	i32.add 
	i32.const	4
	i32.shl 
	local.get	10
	local.get	8
	i32.add 
	i32.const	8
	i32.shl 
	i32.or  
	local.get	12
	local.get	13
	i32.add 
	i32.or  
	i32.const	4
	i32.shl 
	i32.or  
	local.set	8
.LBB39_33:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label869:
	local.get	1
	i32.const	6
	i32.add 
	local.set	1
.LBB39_34:                              #   in Loop: Header=BB39_4 Depth=1
	end_block                               # label867:
	i32.const	0
	local.set	5
	local.get	8
	local.get	3
	local.get	6
	i32.add 
	i32.load8_u	0
	i32.ne  
	br_if   	1                               # 1: down to label865
# %bb.35:                               #   in Loop: Header=BB39_4 Depth=1
	block   	
	local.get	6
	i32.const	1
	i32.add 
	local.tee	6
	local.get	4
	i32.ge_u
	br_if   	0                               # 0: down to label882
# %bb.36:                               #   in Loop: Header=BB39_4 Depth=1
	local.get	1
	local.get	2
	i32.lt_u
	br_if   	1                               # 1: up to label866
.LBB39_37:
	end_block                               # label882:
	end_loop
	local.get	6
	local.get	4
	i32.lt_u
	br_if   	0                               # 0: down to label865
# %bb.38:
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label865
# %bb.39:
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	34
	i32.eq  
	local.set	5
.LBB39_40:
	end_block                               # label865:
	local.get	5
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.key_hex4,"",@
	.type	key_hex4,@function              # -- Begin function key_hex4
key_hex4:                               # @key_hex4
	.functype	key_hex4 (i32) -> (i32)
	.local  	i32, i32, i32, i32, i32, i32, i32
# %bb.0:
	i32.const	-48
	local.set	1
	i32.const	-48
	local.set	2
	block   	
	local.get	0
	i32.load8_u	0
	local.tee	3
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label883
# %bb.1:
	block   	
	local.get	3
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label884
# %bb.2:
	i32.const	-87
	local.set	2
	br      	1                               # 1: down to label883
.LBB40_3:
	end_block                               # label884:
	block   	
	local.get	3
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label885
# %bb.4:
	i32.const	-1
	return
.LBB40_5:
	end_block                               # label885:
	i32.const	-55
	local.set	2
.LBB40_6:
	end_block                               # label883:
	block   	
	local.get	0
	i32.load8_u	1
	local.tee	4
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label886
# %bb.7:
	block   	
	local.get	4
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label887
# %bb.8:
	i32.const	-87
	local.set	1
	br      	1                               # 1: down to label886
.LBB40_9:
	end_block                               # label887:
	block   	
	local.get	4
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label888
# %bb.10:
	i32.const	-1
	return
.LBB40_11:
	end_block                               # label888:
	i32.const	-55
	local.set	1
.LBB40_12:
	end_block                               # label886:
	i32.const	-48
	local.set	5
	i32.const	-48
	local.set	6
	block   	
	local.get	0
	i32.load8_u	2
	local.tee	7
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label889
# %bb.13:
	block   	
	local.get	7
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label890
# %bb.14:
	i32.const	-87
	local.set	6
	br      	1                               # 1: down to label889
.LBB40_15:
	end_block                               # label890:
	block   	
	local.get	7
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label891
# %bb.16:
	i32.const	-1
	return
.LBB40_17:
	end_block                               # label891:
	i32.const	-55
	local.set	6
.LBB40_18:
	end_block                               # label889:
	block   	
	local.get	0
	i32.load8_u	3
	local.tee	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: down to label892
# %bb.19:
	block   	
	local.get	0
	i32.const	-97
	i32.add 
	i32.const	255
	i32.and 
	i32.const	6
	i32.ge_u
	br_if   	0                               # 0: down to label893
# %bb.20:
	i32.const	-87
	local.set	5
	br      	1                               # 1: down to label892
.LBB40_21:
	end_block                               # label893:
	block   	
	local.get	0
	i32.const	-65
	i32.add 
	i32.const	255
	i32.and 
	i32.const	5
	i32.le_u
	br_if   	0                               # 0: down to label894
# %bb.22:
	i32.const	-1
	return
.LBB40_23:
	end_block                               # label894:
	i32.const	-55
	local.set	5
.LBB40_24:
	end_block                               # label892:
	local.get	5
	local.get	0
	i32.add 
	local.get	6
	local.get	7
	i32.add 
	local.get	2
	local.get	3
	i32.add 
	i32.const	8
	i32.shl 
	local.get	1
	local.get	4
	i32.add 
	i32.const	4
	i32.shl 
	i32.or  
	i32.or  
	i32.const	4
	i32.shl 
	i32.or  
                                        # fallthrough-return
	end_function
                                        # -- End function
	.section	.text.is_valid_json_number,"",@
	.type	is_valid_json_number,@function  # -- Begin function is_valid_json_number
is_valid_json_number:                   # @is_valid_json_number
	.functype	is_valid_json_number (i32, i32, i32) -> (i32)
	.local  	i32, i32, i32, i32, i32
# %bb.0:
	block   	
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label895
# %bb.1:
	local.get	1
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	45
	i32.eq  
	i32.add 
	local.set	1
.LBB41_2:
	end_block                               # label895:
	i32.const	0
	local.set	3
	block   	
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label896
# %bb.3:
	block   	
	block   	
	block   	
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	local.tee	4
	i32.const	48
	i32.ne  
	br_if   	0                               # 0: down to label899
# %bb.4:
	local.get	1
	i32.const	1
	i32.add 
	local.tee	4
	local.get	2
	i32.ge_u
	br_if   	1                               # 1: down to label898
# %bb.5:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.ge_u
	br_if   	1                               # 1: down to label898
	br      	3                               # 3: down to label896
.LBB41_6:
	end_block                               # label899:
	local.get	4
	i32.const	-58
	i32.add 
	i32.const	255
	i32.and 
	i32.const	247
	i32.lt_u
	br_if   	2                               # 2: down to label896
# %bb.7:
	local.get	0
	i32.const	1
	i32.add 
	local.set	5
	local.get	2
	i32.const	-1
	i32.add 
	local.set	6
.LBB41_8:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label900:
	block   	
	local.get	6
	local.get	1
	i32.ne  
	br_if   	0                               # 0: down to label901
# %bb.9:
	local.get	2
	local.set	4
	br      	3                               # 3: down to label897
.LBB41_10:                              #   in Loop: Header=BB41_8 Depth=1
	end_block                               # label901:
	local.get	5
	local.get	1
	i32.add 
	local.set	7
	local.get	1
	i32.const	1
	i32.add 
	local.tee	4
	local.set	1
	local.get	7
	i32.load8_u	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	10
	i32.lt_u
	br_if   	0                               # 0: up to label900
.LBB41_11:
	end_loop
	end_block                               # label898:
	block   	
	local.get	4
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label902
# %bb.12:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	46
	i32.ne  
	br_if   	0                               # 0: down to label902
# %bb.13:
	local.get	4
	i32.const	1
	i32.add 
	local.tee	1
	local.get	2
	i32.ge_u
	br_if   	2                               # 2: down to label896
# %bb.14:
	local.get	1
	local.set	4
.LBB41_15:                              # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label904:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	9
	i32.gt_u
	br_if   	1                               # 1: down to label903
# %bb.16:                               #   in Loop: Header=BB41_15 Depth=1
	local.get	2
	local.get	4
	i32.const	1
	i32.add 
	local.tee	4
	i32.ne  
	br_if   	0                               # 0: up to label904
# %bb.17:
	end_loop
	local.get	2
	local.set	4
.LBB41_18:
	end_block                               # label903:
	local.get	4
	local.get	1
	i32.eq  
	br_if   	2                               # 2: down to label896
.LBB41_19:
	end_block                               # label902:
	local.get	4
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label897
# %bb.20:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	32
	i32.or  
	i32.const	101
	i32.ne  
	br_if   	0                               # 0: down to label897
# %bb.21:
	block   	
	local.get	4
	i32.const	1
	i32.add 
	local.tee	1
	local.get	2
	i32.ge_u
	br_if   	0                               # 0: down to label905
# %bb.22:
	block   	
	local.get	0
	local.get	1
	i32.add 
	i32.load8_u	0
	i32.const	-43
	i32.add 
	br_table 	{0, 1, 0, 1}            # 1: down to label905
                                        # 0: down to label906
.LBB41_23:
	end_block                               # label906:
	local.get	4
	i32.const	2
	i32.add 
	local.set	1
.LBB41_24:
	end_block                               # label905:
	local.get	1
	local.get	2
	i32.ge_u
	br_if   	1                               # 1: down to label896
# %bb.25:
	local.get	1
	local.set	4
.LBB41_26:                              # =>This Inner Loop Header: Depth=1
	block   	
	loop    	                                # label908:
	local.get	0
	local.get	4
	i32.add 
	i32.load8_u	0
	i32.const	-48
	i32.add 
	i32.const	255
	i32.and 
	i32.const	9
	i32.gt_u
	br_if   	1                               # 1: down to label907
# %bb.27:                               #   in Loop: Header=BB41_26 Depth=1
	local.get	2
	local.get	4
	i32.const	1
	i32.add 
	local.tee	4
	i32.ne  
	br_if   	0                               # 0: up to label908
# %bb.28:
	end_loop
	local.get	2
	local.set	4
.LBB41_29:
	end_block                               # label907:
	local.get	4
	local.get	1
	i32.eq  
	br_if   	1                               # 1: down to label896
.LBB41_30:
	end_block                               # label897:
	local.get	4
	local.get	2
	i32.eq  
	local.set	3
.LBB41_31:
	end_block                               # label896:
	local.get	3
                                        # fallthrough-return
	end_function
                                        # -- End function
	.type	heap_ptr,@object                # @heap_ptr
	.section	.bss.heap_ptr,"",@
	.p2align	2, 0x0
heap_ptr:
	.int32	0                               # 0x0
	.size	heap_ptr, 4

	.type	last_parse_capacity,@object     # @last_parse_capacity
	.section	.bss.last_parse_capacity,"",@
	.p2align	2, 0x0
last_parse_capacity:
	.int32	0                               # 0x0
	.size	last_parse_capacity, 4

	.type	last_content_capacity,@object   # @last_content_capacity
	.section	.bss.last_content_capacity,"",@
	.p2align	2, 0x0
last_content_capacity:
	.int32	0                               # 0x0
	.size	last_content_capacity, 4

	.type	crc32_table_initialized,@object # @crc32_table_initialized
	.section	.bss.crc32_table_initialized,"",@
	.p2align	2, 0x0
crc32_table_initialized:
	.int8	0                               # 0x0
	.size	crc32_table_initialized, 1

	.type	crc32_table,@object             # @crc32_table
	.section	.bss.crc32_table,"",@
	.p2align	4, 0x0
crc32_table:
	.skip	16384
	.size	crc32_table, 16384

	.type	crc32_braid_initialized,@object # @crc32_braid_initialized
	.section	.bss.crc32_braid_initialized,"",@
	.p2align	2, 0x0
crc32_braid_initialized:
	.int8	0                               # 0x0
	.size	crc32_braid_initialized, 1

	.type	crc32_braid_table,@object       # @crc32_braid_table
	.section	.bss.crc32_braid_table,"",@
	.p2align	4, 0x0
crc32_braid_table:
	.skip	8192
	.size	crc32_braid_table, 8192

	.type	encode_term_content_row.PREFIX_RULES,@object # @encode_term_content_row.PREFIX_RULES
	.section	.rodata.encode_term_content_row.PREFIX_RULES,"S",@
encode_term_content_row.PREFIX_RULES:
	.asciz	"{\"rules\":"
	.size	encode_term_content_row.PREFIX_RULES, 10

	.type	encode_term_content_row.PREFIX_DEFINITION_TAGS,@object # @encode_term_content_row.PREFIX_DEFINITION_TAGS
	.section	.rodata.encode_term_content_row.PREFIX_DEFINITION_TAGS,"S",@
	.p2align	4, 0x0
encode_term_content_row.PREFIX_DEFINITION_TAGS:
	.asciz	",\"definitionTags\":"
	.size	encode_term_content_row.PREFIX_DEFINITION_TAGS, 19

	.type	encode_term_content_row.PREFIX_TERM_TAGS,@object # @encode_term_content_row.PREFIX_TERM_TAGS
	.section	.rodata.encode_term_content_row.PREFIX_TERM_TAGS,"S",@
encode_term_content_row.PREFIX_TERM_TAGS:
	.asciz	",\"termTags\":"
	.size	encode_term_content_row.PREFIX_TERM_TAGS, 13

	.type	encode_term_content_row.PREFIX_GLOSSARY,@object # @encode_term_content_row.PREFIX_GLOSSARY
	.section	.rodata.encode_term_content_row.PREFIX_GLOSSARY,"S",@
encode_term_content_row.PREFIX_GLOSSARY:
	.asciz	",\"glossary\":"
	.size	encode_term_content_row.PREFIX_GLOSSARY, 13

	.type	.L.str,@object                  # @.str
	.section	.rodata..L.str,"S",@
.L.str:
	.asciz	"type"
	.size	.L.str, 5

	.type	.L.str.1,@object                # @.str.1
	.section	.rodata..L.str.1,"S",@
.L.str.1:
	.asciz	"text"
	.size	.L.str.1, 5

	.type	.L.str.2,@object                # @.str.2
	.section	.rodata..L.str.2,"S",@
.L.str.2:
	.asciz	"path"
	.size	.L.str.2, 5

	.type	.L.str.3,@object                # @.str.3
	.section	.rodata..L.str.3,"S",@
.L.str.3:
	.asciz	"content"
	.size	.L.str.3, 8

	.type	.L.str.4,@object                # @.str.4
	.section	.rodata..L.str.4,"S",@
.L.str.4:
	.asciz	"image"
	.size	.L.str.4, 6

	.type	.L.str.5,@object                # @.str.5
	.section	.rodata..L.str.5,"S",@
.L.str.5:
	.asciz	"structured-content"
	.size	.L.str.5, 19

	.type	.L.str.6,@object                # @.str.6
	.section	.rodata..L.str.6,"S",@
.L.str.6:
	.asciz	"img"
	.size	.L.str.6, 4

	.ident	"Debian clang version 21.1.8 (++20251221032947+2078da43e25a-1~exp1~20251221153113.67)"
	.size	__heap_base, 1
	.section	.custom_section.producers,"",@
	.int8	1
	.int8	12
	.ascii	"processed-by"
	.int8	1
	.int8	12
	.ascii	"Debian clang"
	.int8	63
	.ascii	"21.1.8 (++20251221032947+2078da43e25a-1~exp1~20251221153113.67)"
	.section	.rodata..L.str.6,"S",@
	.section	.custom_section.target_features,"",@
	.int8	10
	.int8	43
	.int8	7
	.ascii	"atomics"
	.int8	43
	.int8	11
	.ascii	"bulk-memory"
	.int8	43
	.int8	15
	.ascii	"bulk-memory-opt"
	.int8	43
	.int8	22
	.ascii	"call-indirect-overlong"
	.int8	43
	.int8	10
	.ascii	"multivalue"
	.int8	43
	.int8	15
	.ascii	"mutable-globals"
	.int8	43
	.int8	19
	.ascii	"nontrapping-fptoint"
	.int8	43
	.int8	15
	.ascii	"reference-types"
	.int8	43
	.int8	8
	.ascii	"sign-ext"
	.int8	43
	.int8	7
	.ascii	"simd128"
	.section	.rodata..L.str.6,"S",@
