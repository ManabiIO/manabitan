crc32_bytes:                            # @crc32_bytes
	.functype	crc32_bytes (i32, i32) -> (i32)
	.local  	v128, i32, v128, v128, v128, v128, v128, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64
# %bb.0:
	block   	
	i32.const	0
	i32.load8_u	crc32_table_initialized
	br_if   	0                               # 0: down to label24
# %bb.1:
	v128.const	0, 1, 2, 3
	local.set	2
	i32.const	-1024
	local.set	3
.LBB3_2:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label25:
	local.get	3
	i32.const	crc32_table+1024
	i32.add 
	local.get	2
	v128.const	2, 2, 2, 2
	v128.and
	v128.const	0, 0, 0, 0
	local.tee	4
	i32x4.ne
	v128.const	-306674912, -306674912, -306674912, -306674912
	local.tee	5
	v128.and
	local.get	2
	v128.const	1, 1, 1, 1
	v128.and
	local.get	4
	i32x4.ne
	local.get	5
	v128.and
	local.get	2
	i32.const	1
	i32x4.shr_u
	v128.xor
	local.tee	6
	i32.const	1
	i32x4.shr_u
	v128.xor
	local.tee	7
	v128.const	32, 32, 32, 32
	local.tee	8
	v128.and
	local.get	4
	i32x4.ne
	local.get	5
	v128.and
	local.get	6
	local.get	8
	v128.and
	local.get	4
	i32x4.ne
	v128.const	1994146192, 1994146192, 1994146192, 1994146192
	v128.and
	local.get	2
	local.get	8
	v128.and
	local.get	4
	i32x4.ne
	v128.const	997073096, 997073096, 997073096, 997073096
	v128.and
	local.get	2
	v128.const	16, 16, 16, 16
	v128.and
	local.get	4
	i32x4.ne
	v128.const	498536548, 498536548, 498536548, 498536548
	v128.and
	local.get	2
	v128.const	8, 8, 8, 8
	v128.and
	local.get	4
	i32x4.ne
	v128.const	249268274, 249268274, 249268274, 249268274
	v128.and
	local.get	2
	v128.const	4, 4, 4, 4
	local.tee	5
	v128.and
	local.get	4
	i32x4.ne
	v128.const	124634137, 124634137, 124634137, 124634137
	v128.and
	local.get	7
	i32.const	6
	i32x4.shr_u
	v128.xor
	v128.xor
	v128.xor
	v128.xor
	v128.xor
	v128.xor
	v128.store	0
	local.get	2
	local.get	5
	i32x4.add
	local.set	2
	local.get	3
	i32.const	16
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label25
# %bb.3:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_4:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label26:
	local.get	3
	i32.const	crc32_table+2048
	i32.add 
	local.get	3
	i32.const	crc32_table+1024
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+2052
	i32.add 
	local.get	3
	i32.const	crc32_table+1028
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label26
# %bb.5:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_6:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label27:
	local.get	3
	i32.const	crc32_table+3072
	i32.add 
	local.get	3
	i32.const	crc32_table+2048
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+3076
	i32.add 
	local.get	3
	i32.const	crc32_table+2052
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label27
# %bb.7:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_8:                                # =>This Inner Loop Header: Depth=1
	loop    	                                # label28:
	local.get	3
	i32.const	crc32_table+4096
	i32.add 
	local.get	3
	i32.const	crc32_table+3072
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+4100
	i32.add 
	local.get	3
	i32.const	crc32_table+3076
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label28
# %bb.9:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_10:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label29:
	local.get	3
	i32.const	crc32_table+5120
	i32.add 
	local.get	3
	i32.const	crc32_table+4096
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+5124
	i32.add 
	local.get	3
	i32.const	crc32_table+4100
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label29
# %bb.11:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_12:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label30:
	local.get	3
	i32.const	crc32_table+6144
	i32.add 
	local.get	3
	i32.const	crc32_table+5120
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+6148
	i32.add 
	local.get	3
	i32.const	crc32_table+5124
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label30
# %bb.13:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_14:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label31:
	local.get	3
	i32.const	crc32_table+7168
	i32.add 
	local.get	3
	i32.const	crc32_table+6144
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+7172
	i32.add 
	local.get	3
	i32.const	crc32_table+6148
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label31
# %bb.15:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_16:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label32:
	local.get	3
	i32.const	crc32_table+8192
	i32.add 
	local.get	3
	i32.const	crc32_table+7168
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+8196
	i32.add 
	local.get	3
	i32.const	crc32_table+7172
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label32
# %bb.17:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_18:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label33:
	local.get	3
	i32.const	crc32_table+9216
	i32.add 
	local.get	3
	i32.const	crc32_table+8192
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+9220
	i32.add 
	local.get	3
	i32.const	crc32_table+8196
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label33
# %bb.19:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_20:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label34:
	local.get	3
	i32.const	crc32_table+10240
	i32.add 
	local.get	3
	i32.const	crc32_table+9216
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+10244
	i32.add 
	local.get	3
	i32.const	crc32_table+9220
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label34
# %bb.21:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_22:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label35:
	local.get	3
	i32.const	crc32_table+11264
	i32.add 
	local.get	3
	i32.const	crc32_table+10240
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+11268
	i32.add 
	local.get	3
	i32.const	crc32_table+10244
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label35
# %bb.23:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_24:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label36:
	local.get	3
	i32.const	crc32_table+12288
	i32.add 
	local.get	3
	i32.const	crc32_table+11264
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+12292
	i32.add 
	local.get	3
	i32.const	crc32_table+11268
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label36
# %bb.25:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_26:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label37:
	local.get	3
	i32.const	crc32_table+13312
	i32.add 
	local.get	3
	i32.const	crc32_table+12288
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+13316
	i32.add 
	local.get	3
	i32.const	crc32_table+12292
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label37
# %bb.27:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_28:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label38:
	local.get	3
	i32.const	crc32_table+14336
	i32.add 
	local.get	3
	i32.const	crc32_table+13312
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+14340
	i32.add 
	local.get	3
	i32.const	crc32_table+13316
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label38
# %bb.29:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_30:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label39:
	local.get	3
	i32.const	crc32_table+15360
	i32.add 
	local.get	3
	i32.const	crc32_table+14336
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+15364
	i32.add 
	local.get	3
	i32.const	crc32_table+14340
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label39
# %bb.31:
	end_loop
	i32.const	-1024
	local.set	3
.LBB3_32:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label40:
	local.get	3
	i32.const	crc32_table+16384
	i32.add 
	local.get	3
	i32.const	crc32_table+15360
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	crc32_table+16388
	i32.add 
	local.get	3
	i32.const	crc32_table+15364
	i32.add 
	i32.load	0
	local.tee	9
	i32.const	8
	i32.shr_u
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	i32.store	0
	local.get	3
	i32.const	8
	i32.add 
	local.tee	3
	br_if   	0                               # 0: up to label40
# %bb.33:
	end_loop
	i32.const	0
	i32.const	1
	i32.store8	crc32_table_initialized
.LBB3_34:
	end_block                               # label24:
	block   	
	block   	
	block   	
	block   	
	local.get	1
	i32.const	262143
	i32.gt_u
	br_if   	0                               # 0: down to label44
# %bb.35:
	block   	
	local.get	1
	i32.const	16
	i32.ge_u
	br_if   	0                               # 0: down to label45
# %bb.36:
	i32.const	0
	local.set	9
	i32.const	-1
	local.set	3
	br      	3                               # 3: down to label42
.LBB3_37:
	end_block                               # label45:
	i32.const	-1
	local.set	3
	local.get	1
	local.set	10
	local.get	0
	local.set	9
.LBB3_38:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label46:
	local.get	9
	i32.load	0:p2align=0
	local.get	3
	i32.xor 
	local.tee	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+14336
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+15360
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+13312
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+12288
	i32.xor 
	local.get	9
	i32.const	4
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+11264
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+10240
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+9216
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+8192
	i32.xor 
	local.get	9
	i32.const	8
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	9
	i32.const	12
	i32.add 
	i32.load	0:p2align=0
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table
	i32.xor 
	local.set	3
	local.get	9
	i32.const	16
	i32.add 
	local.set	9
	local.get	10
	i32.const	-16
	i32.add 
	local.tee	10
	i32.const	15
	i32.gt_u
	br_if   	0                               # 0: up to label46
	br      	2                               # 2: down to label43
.LBB3_39:
	end_loop
	end_block                               # label44:
	i32.const	0
	local.set	10
	block   	
	i32.const	0
	i32.load8_u	crc32_braid_initialized
	br_if   	0                               # 0: down to label47
# %bb.40:
.LBB3_41:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_42 Depth 2
	loop    	                                # label48:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table
	local.set	3
	i32.const	56
	local.set	9
.LBB3_42:                               #   Parent Loop BB3_41 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label49:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label49
# %bb.43:                               #   in Loop: Header=BB3_41 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label48
# %bb.44:
	end_loop
	i32.const	0
	local.set	10
.LBB3_45:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_46 Depth 2
	loop    	                                # label50:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+1024
	local.set	3
	i32.const	56
	local.set	9
.LBB3_46:                               #   Parent Loop BB3_45 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label51:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label51
# %bb.47:                               #   in Loop: Header=BB3_45 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+1024
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label50
# %bb.48:
	end_loop
	i32.const	0
	local.set	10
.LBB3_49:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_50 Depth 2
	loop    	                                # label52:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+2048
	local.set	3
	i32.const	56
	local.set	9
.LBB3_50:                               #   Parent Loop BB3_49 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label53:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label53
# %bb.51:                               #   in Loop: Header=BB3_49 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+2048
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label52
# %bb.52:
	end_loop
	i32.const	0
	local.set	10
.LBB3_53:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_54 Depth 2
	loop    	                                # label54:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+3072
	local.set	3
	i32.const	56
	local.set	9
.LBB3_54:                               #   Parent Loop BB3_53 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label55:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label55
# %bb.55:                               #   in Loop: Header=BB3_53 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+3072
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label54
# %bb.56:
	end_loop
	i32.const	0
	local.set	10
.LBB3_57:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_58 Depth 2
	loop    	                                # label56:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+4096
	local.set	3
	i32.const	56
	local.set	9
.LBB3_58:                               #   Parent Loop BB3_57 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label57:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label57
# %bb.59:                               #   in Loop: Header=BB3_57 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+4096
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label56
# %bb.60:
	end_loop
	i32.const	0
	local.set	10
.LBB3_61:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_62 Depth 2
	loop    	                                # label58:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+5120
	local.set	3
	i32.const	56
	local.set	9
.LBB3_62:                               #   Parent Loop BB3_61 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label59:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label59
# %bb.63:                               #   in Loop: Header=BB3_61 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+5120
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label58
# %bb.64:
	end_loop
	i32.const	0
	local.set	10
.LBB3_65:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_66 Depth 2
	loop    	                                # label60:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+6144
	local.set	3
	i32.const	56
	local.set	9
.LBB3_66:                               #   Parent Loop BB3_65 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label61:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label61
# %bb.67:                               #   in Loop: Header=BB3_65 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+6144
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label60
# %bb.68:
	end_loop
	i32.const	0
	local.set	10
.LBB3_69:                               # =>This Loop Header: Depth=1
                                        #     Child Loop BB3_70 Depth 2
	loop    	                                # label62:
	local.get	10
	i32.const	2
	i32.shl 
	local.tee	11
	i32.load	crc32_table+7168
	local.set	3
	i32.const	56
	local.set	9
.LBB3_70:                               #   Parent Loop BB3_69 Depth=1
                                        # =>  This Inner Loop Header: Depth=2
	loop    	                                # label63:
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	-4
	i32.add 
	local.tee	9
	br_if   	0                               # 0: up to label63
# %bb.71:                               #   in Loop: Header=BB3_69 Depth=1
	end_loop
	local.get	11
	local.get	3
	i32.store	crc32_braid_table+7168
	local.get	10
	i32.const	1
	i32.add 
	local.tee	10
	i32.const	256
	i32.ne  
	br_if   	0                               # 0: up to label62
# %bb.72:
	end_loop
	i32.const	0
	i32.const	1
	i32.store8	crc32_braid_initialized
.LBB3_73:
	end_block                               # label47:
	local.get	1
	i32.const	-64
	i32.and 
	local.tee	12
	i32.const	-64
	i32.add 
	local.set	13
	i32.const	-1
	local.set	11
	i32.const	0
	local.set	14
	i32.const	0
	local.set	15
	i32.const	0
	local.set	16
	i32.const	0
	local.set	17
	i32.const	0
	local.set	18
	i32.const	0
	local.set	19
	i32.const	0
	local.set	20
	i32.const	0
	local.set	10
.LBB3_74:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label64:
	local.get	11
	local.get	0
	local.get	10
	i32.add 
	local.tee	3
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	11
	local.get	14
	local.get	3
	i32.const	56
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	14
	local.get	15
	local.get	3
	i32.const	48
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	15
	local.get	16
	local.get	3
	i32.const	40
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	16
	local.get	17
	local.get	3
	i32.const	32
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	17
	local.get	18
	local.get	3
	i32.const	24
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	18
	local.get	19
	local.get	3
	i32.const	16
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	19
	local.get	20
	local.get	3
	i32.const	8
	i32.add 
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+6144
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+7168
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+5120
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_braid_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_braid_table
	i32.xor 
	local.set	20
	local.get	10
	i32.const	64
	i32.add 
	local.tee	10
	local.get	13
	i32.lt_u
	br_if   	0                               # 0: up to label64
# %bb.75:
	end_loop
	local.get	11
	local.get	0
	local.get	13
	i32.add 
	local.tee	3
	i64.load	0:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	8:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	20
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	16:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	19
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	24:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	18
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	32:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	17
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	40:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	16
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	48:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	15
	i32.xor 
	local.tee	9
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	local.get	9
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	i32.xor 
	local.get	9
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	9
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.get	3
	i64.load	56:p2align=0
	local.tee	21
	i32.wrap_i64
	i32.xor 
	local.get	14
	i32.xor 
	local.tee	3
	i32.const	6
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+6144
	local.get	3
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+7168
	i32.xor 
	local.get	3
	i32.const	14
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+5120
	i32.xor 
	local.get	3
	i32.const	22
	i32.shr_u
	i32.const	1020
	i32.and 
	i32.load	crc32_table+4096
	i32.xor 
	local.get	21
	i64.const	32
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+3072
	i32.xor 
	local.get	21
	i64.const	40
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+2048
	i32.xor 
	local.get	21
	i64.const	48
	i64.shr_u
	i32.wrap_i64
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table+1024
	i32.xor 
	local.get	21
	i64.const	56
	i64.shr_u
	i32.wrap_i64
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	i32.xor 
	local.set	3
	local.get	12
	local.get	1
	i32.eq  
	br_if   	2                               # 2: down to label41
# %bb.76:
.LBB3_77:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label65:
	local.get	0
	local.get	12
	i32.add 
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	12
	i32.const	1
	i32.add 
	local.tee	12
	local.get	1
	i32.lt_u
	br_if   	0                               # 0: up to label65
	br      	3                               # 3: down to label41
.LBB3_78:
	end_loop
	end_block                               # label43:
	local.get	1
	i32.const	262128
	i32.and 
	local.set	9
.LBB3_79:
	end_block                               # label42:
	local.get	9
	local.get	1
	i32.ge_u
	br_if   	0                               # 0: down to label41
# %bb.80:
	local.get	9
	i32.const	1
	i32.or  
	local.set	10
	block   	
	local.get	1
	i32.const	1
	i32.and 
	i32.eqz
	br_if   	0                               # 0: down to label66
# %bb.81:
	local.get	0
	local.get	9
	i32.add 
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	10
	local.set	9
.LBB3_82:
	end_block                               # label66:
	local.get	1
	local.get	10
	i32.eq  
	br_if   	0                               # 0: down to label41
# %bb.83:
	local.get	1
	local.get	9
	i32.sub 
	local.set	10
	local.get	0
	local.get	9
	i32.add 
	local.set	9
.LBB3_84:                               # =>This Inner Loop Header: Depth=1
	loop    	                                # label67:
	local.get	9
	i32.const	1
	i32.add 
	i32.load8_u	0
	local.get	9
	i32.load8_u	0
	local.get	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.tee	3
	i32.xor 
	i32.const	255
	i32.and 
	i32.const	2
	i32.shl 
	i32.load	crc32_table
	local.get	3
	i32.const	8
	i32.shr_u
	i32.xor 
	local.set	3
	local.get	9
	i32.const	2
	i32.add 
	local.set	9
	local.get	10
	i32.const	-2
	i32.add 
	local.tee	10
	br_if   	0                               # 0: up to label67
.LBB3_85:
	end_loop
	end_block                               # label41:
	local.get	3
	i32.const	-1
	i32.xor 
                                        # fallthrough-return
	end_function
