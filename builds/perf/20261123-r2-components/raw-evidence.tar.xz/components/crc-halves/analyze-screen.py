#!/usr/bin/env python3
"""Verify the frozen inflation cohort and summarize every measured triple."""

import argparse
import hashlib
import json
import math
from pathlib import Path
from statistics import median


def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("screen", type=Path)
args = parser.parse_args()
plan = json.loads((args.screen / "plan.json").read_text())
receipts = json.loads((args.screen / "receipts.json").read_text())
assert len(receipts) == len(plan["schedule"]) == 12
assert plan["arms"]["A"] == plan["arms"]["C"]
rows = {}
layouts = {}
for entry, receipt in zip(plan["schedule"], receipts, strict=True):
    assert all(receipt[key] == entry[key] for key in entry)
    assert receipt["exitCode"] == 0
    name = f"{entry['triple']:02d}-{entry['label']}"
    result_path = args.screen / f"{name}.json"
    assert digest(result_path) == receipt["outputSha256"]
    assert digest(args.screen / f"{name}.log") == receipt["logSha256"]
    result = json.loads(result_path.read_text())
    assert result["mode"] == "measure"
    assert result["runtime"] == plan["nodeVersion"]
    assert result["harnessSha256"] == plan["harnessSha256"]
    assert result["identities"] == [plan["arms"][entry["label"]]] * 2
    assert len(result["observations"]) == 6
    for observation, expected in zip(result["observations"], [(warmup, corpus) for warmup in [True, False] for corpus in ["jmdict", "jitendex", "vndb"]], strict=True):
        assert (observation["warmup"], observation["dictionary"]) == expected
        corpus = observation["dictionary"]
        layout = [{key: group[key] for key in ["index", "banks", "compressedBytes", "outputBytes"]} for group in observation["groups"]]
        if corpus in layouts:
            assert layouts[corpus] == layout
        else:
            layouts[corpus] = layout
        for metric in ["nativeInflateCrcMs", "wrapperMs"]:
            assert all(math.isfinite(group[metric]) and group[metric] > 0 for group in observation["groups"])
            assert math.isclose(sum(group[metric] for group in observation["groups"]), observation[metric], rel_tol=1e-12)
        if not observation["warmup"]:
            rows[(entry["triple"], entry["label"], corpus)] = observation


def comparison(numerator, denominator):
    changes = [100 * (a / b - 1) for a, b in zip(numerator, denominator, strict=True)]
    return {"perTriplePercent": changes, "medianPercent": median(changes), "equalWorkPercent": 100 * (sum(numerator) / sum(denominator) - 1)}


summaries = []
for corpus in ["jmdict", "jitendex", "vndb"]:
    for metric in ["nativeInflateCrcMs", "wrapperMs"]:
        arms = {label: [rows[(triple, label, corpus)][metric] for triple in range(1, 5)] for label in "ABC"}
        summary = {"dictionary": corpus, "boundary": metric, "milliseconds": arms,
                   "candidateVsAdjacentControlMean": comparison(arms["B"], [(a + c) / 2 for a, c in zip(arms["A"], arms["C"], strict=True)]),
                   "candidateVsA": comparison(arms["B"], arms["A"]),
                   "candidateVsC": comparison(arms["B"], arms["C"]),
                   "sameCodeControlCVsA": comparison(arms["C"], arms["A"])}
        summaries.append(summary)
        print(json.dumps(summary))
result = {"schemaVersion": 1, "screenPlanSha256": digest(args.screen / "plan.json"), "screenReceiptsSha256": digest(args.screen / "receipts.json"),
          "scriptSha256": digest(Path(__file__)), "verifiedArms": 12, "retainedWarmupCorpusPasses": 36,
          "measuredCorpusPasses": 36, "signConvention": "100 * (candidate / reference - 1): negative is faster",
          "layouts": layouts, "summaries": summaries}
(args.screen / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
