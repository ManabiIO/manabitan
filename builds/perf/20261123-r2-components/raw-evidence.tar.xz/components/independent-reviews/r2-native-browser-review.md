# Independent review: round 2 native browser qualification

**Recommendation: HOLD PRs #816, #817 and #818.** All 18 declared browser cells are complete and pass this independent source, work and raw-timing audit. None demonstrates a repeatable material complete-import benefit that meets the repository performance acceptance rule.

## Frozen scope and independent checks

- Workflow run: `45121755673`; research source: `05740992c377629eb3017be35cf8c6064d9ef445`.
- Parent: `5e1f8c12f7ff798ba407323aff675cb23b22af02`; lookup: `3a4ef7ed11dd6b0509c12ad495ab8f591b68872b`; CRC: `4884b4bd93d45f152ec828bcca44990f18976a05`; flat glossary: `524b41a112a1ba0b1ac31723da274c97d5525653`.
- Node `22.22.0`, Chrome for Testing `153.0.8010.12`, Playwright `1.63.0`; executable hashes match across all cells and are recorded in the independent JSON.
- Three candidates × three dictionaries × two independent order directions. Every cell contains the exact frozen 42-import schedule: six excluded warmups, 12 alternating candidate/parent pairs, and six interleaved same-code C/A pairs. Total: **756 successful imports, 108 excluded warmups, 648 measured imports, 216 candidate pairs and 108 control pairs**. No prepare/run/analyze failure marker is present in these cells.
- Reconstructed every measured duration from the raw browser operation clock and checked exact agreement with the summaries and observations. The file-input trigger, operation sequence, post-operation completion, optional next frame, zero errors, OPFS mode and import-session finalization agree. Profiling, screenshots, process sampling and trace collection are disabled.
- Checked exact source pins/trees, symmetric test overlay, dependency-lock hashes, fixture lock/SHA/size receipts, completion hashes, schedule identities, and observed package hashes. A and C have identical package-entry maps. The only changed package entries are `js/dictionary/wasm/term-bank-parser.c` and `lib/term-bank-parser.wasm`; both match the immutable published runtime blob manifest for the declared arm.
- Recomputed every paired ratio, median, equal-work ratio, worst pair and seeded descriptive bootstrap interval directly from the raw measurements using a separate reviewer. All retained analysis values match exactly. Each cell is interpreted separately; no host pooling or subtraction of control effects.

| Corpus | Rows per import | Term banks | Native parser chunks | Compressed term-source bytes | Uncompressed term-source bytes |
| --- | ---: | ---: | ---: | ---: | ---: |
| JMdict | 526,942 | 53 | 12 | 15,574,114 | 171,092,992 |
| Jitendex | 435,448 | 218 | 22 | 33,696,215 | 537,538,792 |
| VNDB | 6,648,310 | 665 | 170 | 86,850,424 | 4,267,992,967 |

These work counts, recorded content/record/index write-byte counters, native fallback counts, production parser options and source-derived probe digests match across all arms and cells for each dictionary. The browser performs 12 distinct source-derived readability probes and restart checks on every import. Those probes and the recorded write counters are **not exhaustive persisted-database or media-payload equality**; the separate whole-output native/component oracles provide additional correctness evidence within their declared boundaries.

## Complete-import results

Every table entry is **forward / reverse**. Negative values mean faster. “Equal work” is the ratio of summed candidate durations to summed paired parent durations within that one cell. C/A is an unchanged-code control, presented without adjusting B/A.

| Candidate | Corpus | B/A median | B/A equal work | C/A median | C/A equal work | Decision |
| --- | --- | ---: | ---: | ---: | ---: | --- |
| Lookup initialization (#816) | JMdict | +1.62% / -0.03% | +1.27% / -0.10% | +0.13% / -0.60% | +0.18% / -0.15% | HOLD |
| Lookup initialization (#816) | Jitendex | -0.13% / -0.57% | +0.56% / -0.49% | +1.60% / +0.25% | +1.29% / -0.46% | HOLD |
| Lookup initialization (#816) | VNDB | -0.97% / +0.35% | -0.34% / +1.12% | +0.28% / +0.59% | +0.26% / +1.53% | HOLD |
| CRC halves (#817) | JMdict | -0.70% / -1.04% | -0.67% / -1.21% | +0.01% / -0.53% | +0.55% / -0.95% | HOLD |
| CRC halves (#817) | Jitendex | -0.20% / -0.54% | +0.56% / -0.78% | +0.47% / -2.75% | +0.36% / -1.85% | HOLD |
| CRC halves (#817) | VNDB | -0.26% / -1.33% | -0.79% / -2.96% | -1.04% / +1.34% | -0.80% / +2.20% | HOLD |
| Flat glossary (#818) | JMdict | -0.24% / +0.39% | -0.22% / +0.13% | -0.38% / +0.55% | -0.45% / -0.45% | HOLD |
| Flat glossary (#818) | Jitendex | -1.06% / -0.33% | -1.09% / -0.69% | -0.34% / -1.57% | -0.46% / -0.74% | HOLD |
| Flat glossary (#818) | VNDB | -0.19% / +0.94% | +0.00% / +1.72% | +0.08% / +1.32% | +0.06% / +2.71% | HOLD |

All 18 candidate median bootstrap intervals contain zero except CRC/VNDB reverse: **[−3.39%, −0.05%]**. Its forward interval is **[−2.98%, +2.59%]**, with a −0.26% median and an −1.04% same-code median. The favorable reverse result therefore does not establish a replicated gain. These are descriptive intervals for the fixed cells, not a claim that the one favorable cell survives selection among 18 comparisons. All individual ratios, intervals and slow tails are retained in the independent JSON.

The largest slower pair in each candidate is lookup +13.26% (VNDB forward), CRC +11.73% (Jitendex forward), and flat glossary +11.99% (VNDB reverse). No pair was removed.

## Intended mechanism versus complete import

The following numbers use the existing importer phase counters sampled in each report. They are **overlapping sums of parser-worker durations**, not an additive decomposition of complete-import time or separately isolated phase measurements. They cannot be converted into milliseconds saved on the critical path by summing or subtracting them.

| Candidate and observed phase | Corpus | Phase B/A median, F / R | Phase B/A equal work, F / R | Phase C/A median, F / R |
| --- | --- | ---: | ---: | ---: |
| Lookup: native index preparation | JMdict | -5.33% / -4.39% | -1.36% / -2.51% | -10.86% / +3.52% |
| Lookup: native index preparation | Jitendex | -10.57% / -8.51% | -12.38% / -9.41% | -7.36% / +6.68% |
| Lookup: native index preparation | VNDB | -2.16% / -2.55% | -1.35% / -1.95% | +5.46% / -1.03% |
| CRC: source inflate + CRC | JMdict | +9.63% / -2.20% | +5.73% / -1.36% | -2.55% / +0.87% |
| CRC: source inflate + CRC | Jitendex | -0.76% / -7.14% | -1.01% / -5.23% | +2.32% / -3.72% |
| CRC: source inflate + CRC | VNDB | -2.38% / -2.57% | -1.84% / -2.99% | +0.46% / +2.00% |
| Flat: native term-bank parse | JMdict | -1.21% / +2.62% | +0.97% / +1.27% | +0.92% / -0.71% |
| Flat: native term-bank parse | Jitendex | -0.98% / -0.43% | -1.89% / -1.37% | +0.76% / +0.86% |
| Flat: native term-bank parse | VNDB | -1.68% / +0.64% | -1.21% / +0.58% | -0.20% / -3.28% |

- **Lookup initialization:** Jitendex index-preparation counters improve in both directions, which is compatible with avoiding redundant output writes. Complete import is +0.56% / −0.49% on equal work. VNDB preparation improves only modestly and complete import changes sign. This does not justify a default change solely from the byte-write reduction.
- **CRC halves:** VNDB inflate/CRC counters decrease in both cells, giving a plausible local mechanism. JMdict counters change direction, and the larger complete-import VNDB reverse result fails forward replication. Preserve this as mechanism evidence, not a qualified complete-import win.
- **Flat glossary:** The main intended JMdict parse counter is +0.97% / +1.27% on equal work, and complete import changes sign near zero. Jitendex has modest decreases whose whole-import magnitude is comparable to control variation. VNDB reverse is slower. There is no demonstrated benefit that compensates for the new parser path.

The repository acceptance rule in `dev/perf/import-experiments-20260914.md` requires a material complete-import benefit (or removal of a reproduced severe exception-path cliff with negligible normal-path cost), independent reversed-order qualification, and memory/storage/lookup/reliability gates. These three ordinary-path candidates have not met the complete-import gate; correctness alone is not promotion evidence.

## Ready-to-paste PR updates

### PR #816 — selective lookup output initialization

Completed the frozen browser qualification on JMdict, Jitendex and VNDB, with 12 candidate/parent pairs, six same-code control pairs and six excluded warmups in each forward and independent reverse cell (252 successful imports total). The independent raw/source audit passes. Complete-import equal-work changes are JMdict +1.27% / −0.10%, Jitendex +0.56% / −0.49%, and VNDB −0.34% / +1.12%. Jitendex native index-preparation counters decrease, but the change does not produce a repeatable complete-import improvement. **HOLD as a performance candidate; do not promote on reduced write volume alone.** Full ratios, controls, intervals and tails are retained in the research evidence.

### PR #817 — 32-bit CRC word halves

Completed all six frozen browser cells (252 successful imports), with 12 candidate/parent pairs and six unchanged-code controls per cell; the independent source, work and raw-timing audit passes. Complete-import equal-work changes are JMdict −0.67% / −1.21%, Jitendex +0.56% / −0.78%, and VNDB −0.79% / −2.96%. VNDB reverse has a favorable median interval, but forward does not replicate it; its forward same-code control is −0.80% on equal work. Native VNDB inflate/CRC counters decrease modestly in both cells. **HOLD: plausible component mechanism without a repeatable material complete-import gain.** The earlier local screen stopped on signal 9 remains retained as incomplete and is not reclassified by these browser results.

### PR #818 — leading flat-glossary string scan

Completed all six frozen browser cells (252 successful imports), with 12 candidate/parent pairs, six unchanged-code controls and six excluded warmups per cell. The independent source/work/timing audit passes. Complete-import equal-work changes are JMdict −0.22% / +0.13%, Jitendex −1.09% / −0.69%, and VNDB +0.00% / +1.72%. The intended JMdict parse counter is +0.97% / +1.27% on equal work; the whole-import effect is near zero and changes sign. Jitendex differences are modest and comparable to control variation. **HOLD: no qualified complete-import benefit supports the added parser path.** All observations and slow tails remain in the evidence.

## Review artifacts and retained review failure

- Independent reader: `qualification/r2-native-browser-independent-review.py`.
- Complete recomputed results, all pair ratios and provenance hashes: `qualification/r2-native-browser-independent-review.json`.
- Successful audit log: `qualification/r2-native-browser-independent-review-fixed.log`.
- The first review script incorrectly assumed three pipeline groups per worker for every corpus. Its assertion stopped on JMdict before producing a result; baseline source selects four for plain JMdict and three for media-aware Jitendex/VNDB. The initial script and log are retained as `qualification/r2-native-browser-independent-review.v1.py` and `qualification/r2-native-browser-independent-review.log`. This was an offline reviewer error, not a benchmark failure or rerun.
- Raw cells: `r2-evidence/native-browser-45121755673/`; immutable package/blob bindings: `qualification/r2-published-runtime-blobs.json`.
