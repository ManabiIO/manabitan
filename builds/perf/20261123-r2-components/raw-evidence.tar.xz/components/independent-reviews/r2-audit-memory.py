import hashlib,importlib.util,json,math,statistics
from pathlib import Path

ROOT=Path('/workspace/scratch/fcfffdc555c8')
CAMPAIGN=ROOT/'r2-evidence/memory-45124025705'
OUT=ROOT/'qualification'
BASELINE='5e1f8c12f7ff798ba407323aff675cb23b22af02'
CANDIDATE='8fe5926cec1396a05ed4ea52be751e48784329b7'
RESEARCH='a9a90967f1dfc9c9c68d06ae5ad4ad1e999f67b2'
TREE='df4e570212e6ef8a60f12f578b57c6d04455faa3'
OBSERVER_SHA='ca6c0f7761062761697a810d4bd0007ff0257bbce69099df45657ffdb7ee8f10'
EXPECTED_DELTA=['js/dictionary/term-bank-wasm-parser.js','js/dictionary/term-record-opfs-store.js']

def hashfile(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def read(p):return json.loads(p.read_text())
def require(v,msg):
 if not v:raise AssertionError(msg)
def load(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def verify_sample(s,observer):
 before=s['discoveryBefore'];after=s['discoveryAfter'];values=s['processes'];unavailable=s['unavailableProcesses']
 stable=observer.tree_signature(before)==observer.tree_signature(after)
 require(stable==s['stableObservedProcessTree'],'Stable tree derivation mismatch')
 identified={(p['pid'],p['startTimeTicks']) for p in before['processes']}
 actual=[(p['pid'],p['startTimeTicks']) for p in values+unavailable]
 require(len(actual)==len(set(actual)) and set(actual)==identified,'Discovered address spaces missing/duplicated')
 after_by_pid={p['pid']:p for p in after['processes']}
 zombies=[{**p,'confirmationAfter':after_by_pid[p['pid']],'exclusionReason':'same-identity-single-thread-Z-to-Z-exe-ENOENT-smaps-ESRCH'} for p in unavailable if observer.confirmed_exited_zombie(p,after_by_pid.get(p['pid']))]
 require(zombies==s['confirmedExitedZombies'],'Zombie exemption derivation mismatch')
 excluded={p['pid'] for p in zombies};unreadable=[p for p in unavailable if p['pid'] not in excluded]
 require(unreadable==s['unreadableAddressSpaces'],'Unqualified address-space omission')
 errors=before['inventoryIdentityReadErrors']+after['inventoryIdentityReadErrors']
 persistent=[p for p in errors if p['errno'] not in observer.GONE_ERRORS]
 roles={p['role'] for p in values};reasons=[]
 if not before['browserSeedPids']:reasons.append('no-browser-seed')
 if len(values)<2:reasons.append('no-multiple-process-coverage')
 if 'browser' not in roles:reasons.append('no-readable-browser-process')
 if 'renderer' not in roles:reasons.append('no-readable-renderer-process')
 if not stable:reasons.append('process-tree-changed-during-scan')
 if unreadable:reasons.append('unreadable-discovered-process-smaps')
 if persistent:reasons.append('incomplete-process-identity-inventory')
 require(reasons==s['qualificationFailures'] and (not reasons)==s['qualifiedForWholeTreePss'],'Sample qualification derivation mismatch')
 require(sorted(roles)==s['observedRoles'],'Observed role derivation mismatch')
 for metric in ['pssKiB','rssKiB','privateKiB']:
  require(all(type(p[metric]) is int and p[metric]>=0 for p in values),'Invalid raw process memory value')
 require(sum(p['pssKiB'] for p in values)==s['readableProcessPssKiB'],'PSS sum mismatch')
 require(sum(p['privateKiB'] for p in values)==s['readableProcessPrivateKiB'],'Private sum mismatch')
 return [{'pid':p['pid'],'startTimeTicks':p['startTimeTicks'],'stateBefore':p['state'],'threadsBefore':p['threadCount'],'stateAfter':after_by_pid.get(p['pid'],{}).get('state'),'threadsAfter':after_by_pid.get(p['pid'],{}).get('threadCount'),'errno':p['smapsReadError']['errno'],'smapsError':p['smapsReadError']['error'],'role':p['role'],'sameIdentityAfter':after_by_pid.get(p['pid'],{}).get('startTimeTicks')==p['startTimeTicks'],'stableTree':stable} for p in unreadable]

result={'schemaVersion':1,'runId':45124025705,'authoritativeTiming':False,'researchSha':RESEARCH,'baseline':BASELINE,'candidate':CANDIDATE,'candidateTree':TREE,'observerSha256':OBSERVER_SHA,'auditScriptSha256':hashfile(Path(__file__)),'cells':[],'failures':[]}
all_runtimes=[];total_samples=0;total_good_samples=0;functional_successes=0;memory_successes=0
for cell in sorted(p for p in CAMPAIGN.iterdir() if p.is_dir()):
 frozen=cell/'research-sources';driver=load('audit_'+cell.name.replace('-','_'),frozen/'dev/perf/import-r2-memory-20261123.py');observer=driver.observer
 prep=read(cell/'preparation.json');config=read(cell/'config.json');rows=read(cell/'observations.json');analysis=read(cell/'memory-analysis.json')
 rep=prep['replication'];case=prep['case'];dictionary=prep['dictionary'];expected=driver.schedule(rep)
 require(prep['researchSha']==RESEARCH and (cell/'research-sha.txt').read_text().strip()==RESEARCH,'Research source mismatch')
 require(prep['researchTree']==(cell/'research-tree.txt').read_text().strip()=='2d18913b028a814e5af2732509c3bba7bbea94ca','Research tree mismatch')
 require(prep['identities']['A']['sha']==BASELINE and prep['identities']['B']['sha']==CANDIDATE and prep['identities']['B']['tree']==TREE,'Runtime source mismatch')
 require(prep['authoritativeTiming'] is False,'Memory classification missing')
 driver.validate_config(config,case)
 require(prep['studySourceHashes']==driver.source_hashes(),'Retained coordinator source hashes mismatch')
 require(hashfile(frozen/'dev/perf/import-r2-memory-observer-20261123.py')==OBSERVER_SHA,'Observer bytes changed')
 require(config['baseline']==BASELINE and config['cases'][case]['sha']==CANDIDATE,'Config source mismatch')
 require(read(cell/'schedule.json')==expected and len(rows)==4 and [{k:r[k] for k in e} for r,e in zip(rows,expected)]==expected,'Schedule mismatch')
 require(prep['runtime']['node']=='v22.22.0','Node mismatch');all_runtimes.append(prep['runtime'])
 wrapper=prep['runtime']['deadlineWrapper'];require(wrapper['seconds']==180 and wrapper['killAfterSeconds']==5 and 'GNU coreutils' in wrapper['version'],'Deadline changed')
 entries={arm:read(cell/f'package-entries-{arm}.json') for arm in ['A','B']}
 delta=driver.common.package_differences(entries['A'],entries['B']);require(delta==EXPECTED_DELTA==prep['packageDifferences']==read(cell/'package-differences.json'),'Package delta mismatch')
 for arm,root in [('A',ROOT/'manabitan-baseline'),('B',ROOT/'manabitan-r2-transfer')]:
  for name in EXPECTED_DELTA:require(entries[arm][name]==hashfile(root/'ext'/name),'Packaged source differs from intended committed file')
  require(prep['identities'][arm]['packageLockSha256']==hashfile(root/'package-lock.json'),'Dependency lock mismatch')
  require(prep['identities'][arm]['originalFixtureLockSha256']==hashfile(root/'test/perf/dictionaries.lock.json'),'Original fixture lock mismatch')
 require(prep['identities']['A']['overlaySha256']==prep['identities']['B']['overlaySha256'],'Asymmetric overlay')
 require({name:hashfile(cell/'overlay'/name) for name in driver.common.OVERLAY_FILES}==prep['identities']['A']['overlaySha256'],'Retained overlay hash mismatch')
 observations=[]
 for row in rows:
  folder=cell/'observations'/row['name'];mem=read(folder/'chromium-memory.json');summary=read(folder/'summary.json');report=read(folder/'run-1.json');identity=read(folder/'identity.json')
  require(driver.observation_hashes(folder)==row['receiptHashes'],'Raw observation file hashes changed')
  require(identity['authoritativeTiming'] is False and identity['arm']==row['arm'] and identity['source']==prep['identities'][row['arm']] and identity['preparationSha256']==hashfile(cell/'preparation.json'),'Observation identity mismatch')
  require(identity['command'][:3]==[wrapper['executable'],'--kill-after=5s','180s'],'Observation deadline missing')
  verified=driver.validate_observation(summary,report,prep,row['arm']);functional_successes+=1
  require(all(row[k]==v for k,v in verified.items()),'Readback/work receipt differs from raw reports')
  require(mem['benchmarkExitCode']==0,'Browser command failed')
  require({k:v for k,v in mem.items() if k!='samples'}==row['memory'],'Observer raw/summary mismatch')
  bad=[]
  for index,sample in enumerate(mem['samples']):
   for entry in verify_sample(sample,observer):bad.append({'sampleIndex':index,**entry})
  require(observer.summarize_samples(mem['samples'],mem['benchmarkExitCode'])==mem,'Observer summary/coverage/maxima recomputation mismatch')
  total_samples+=mem['sampleCount'];total_good_samples+=mem['stableFullyReadTreeSampleCount'];memory_successes+=mem['qualifiedForWholeTreePss']
  observation={'name':row['name'],'arm':row['arm'],'status':row['status'],'browserVerificationPassed':True,'qualifiedMemory':mem['qualifiedForWholeTreePss'],'sampleCount':mem['sampleCount'],'qualifiedSamples':mem['stableFullyReadTreeSampleCount'],'processCountRange':mem['observedProcessCountRange'],'maxSampledPssKiB':mem['maxSampledPssKiB'],'maxSampledPrivateKiB':mem['maxSampledPrivateKiB'],'qualificationFailures':mem['qualificationFailures'],'unreadableAddressSpaces':bad,'outputDigestSha256':verified['outputDigestSha256']}
  if not mem['qualifiedForWholeTreePss']:
   require(row['status']=='failed' and row['error']=='ValueError: Process-tree coverage is unqualified','Unexpected failed observation classification')
   observation['stableUnreadableAddressSpaces']=[x for x in bad if x['stableTree']]
   require(observation['stableUnreadableAddressSpaces'],'Expected stable-tree blocker missing')
   result['failures'].append({'cell':cell.name,**observation})
  else:require(row['status']=='success','Successful coverage row unexpectedly failed')
  observations.append(observation)
 require(len({o['outputDigestSha256'] for o in observations})==1,'Cross-arm persisted-content digest changed')
 require(all(r['workReceipt']==rows[0]['workReceipt'] for r in rows),'Cross-arm work receipt changed')
 qualified=all(o['qualifiedMemory'] for o in observations)
 pairs=[]
 if qualified:
  receipt=read(cell/'cohort-complete.json');require(not (cell/'run-failure.json').exists() and not (cell/'prepare-failure.json').exists(),'Failure with qualified cohort')
  require(receipt['case']==case and receipt['dictionary']==dictionary and receipt['replication']==rep and receipt['authoritativeTiming'] is False,'Completion cell mismatch')
  for name in ['observations','schedule','preparation','config']:require(receipt[name+'Sha256']==hashfile(cell/f'{name}.json'),'Completion hash mismatch')
  for start in [0,2]:
   selected={r['arm']:r for r in observations[start:start+2]};metrics={}
   for key in ['maxSampledPssKiB','maxSampledPrivateKiB']:
    a,b=selected['A'][key],selected['B'][key];metrics[key]={'baseline':a,'candidate':b,'changePercent':100*(b/a-1)}
   pairs.append({'indices':[start,start+1],'metrics':metrics})
  require(pairs==analysis['pairs'] and analysis['qualifiedMemoryMeasurement'] is True and not analysis['qualificationFailures'],'Stored memory pairs differ from recomputation')
  require(analysis['medianPairedPercent']=={k:statistics.median(p['metrics'][k]['changePercent'] for p in pairs) for k in ['maxSampledPssKiB','maxSampledPrivateKiB']},'Stored memory medians differ')
 else:
  require(not (cell/'cohort-complete.json').exists() and (cell/'run-failure.json').exists(),'Failed cohort receipt rule violated')
  require(analysis['qualifiedMemoryMeasurement'] is False and analysis['pairs']==[] and 'medianPairedPercent' not in analysis,'Failed memory cell published aggregate')
 result['cells'].append({'cell':cell.name,'dictionary':dictionary,'replication':rep,'order':''.join(r['arm'] for r in rows),'qualifiedMemoryMeasurement':qualified,'observations':observations,'pairs':pairs,'medianPairedPercent':analysis.get('medianPairedPercent'),'providerArchiveSha256':hashfile(cell.with_suffix('.zip'))})
require(len(result['cells'])==6 and sum(len(c['observations']) for c in result['cells'])==24,'Campaign missing cells/imports')
for runtime in all_runtimes[1:]:require(runtime==all_runtimes[0],'Runtime identity differs among memory jobs')
result['runtime']=all_runtimes[0];result['counts']={'cells':6,'imports':24,'browserVerificationPassed':functional_successes,'memoryQualifiedObservations':memory_successes,'memoryQualifiedCells':sum(c['qualifiedMemoryMeasurement'] for c in result['cells']),'samples':total_samples,'qualifiedSamples':total_good_samples}
result['dictionaryComparisons']={}
for dictionary in ['jmdict','jitendex','vndb']:
 cells=[c for c in result['cells'] if c['dictionary']==dictionary];qualified=all(c['qualifiedMemoryMeasurement'] for c in cells)
 data={'qualifiedAcrossBothOrders':qualified,'pairedPssPercentChanges':[],'pairedPrivatePercentChanges':[]}
 if qualified:
  for c in cells:
   for pair in c['pairs']:
    data['pairedPssPercentChanges'].append(pair['metrics']['maxSampledPssKiB']['changePercent']);data['pairedPrivatePercentChanges'].append(pair['metrics']['maxSampledPrivateKiB']['changePercent'])
  data['descriptiveMedianPairedPssPercent']=statistics.median(data['pairedPssPercentChanges']);data['descriptiveMedianPairedPrivatePercent']=statistics.median(data['pairedPrivatePercentChanges'])
 result['dictionaryComparisons'][dictionary]=data
result['conclusion']='Four complete cells support descriptive sampled-memory comparisons for Jitendex and VNDB. Both JMdict cells remain unqualified; no JMdict memory comparison, exact peak claim, timing inference or all-corpus memory qualification is justified.'
(OUT/'r2-memory-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'counts':result['counts'],'dictionaryComparisons':result['dictionaryComparisons'],'failureNames':[(x['cell'],x['name']) for x in result['failures']]},indent=2))
