# Resolved content validation dispatch, 2026-11-23

Candidate commit: `d0f9f604b873663ecf05a895b80e5be3326200fc`.

Candidate tree: `64d89a6c4d6b9722d30580d5cc834ebb7eac0057`.

Base commit: `5e1f8c12f7ff798ba407323aff675cb23b22af02`.

The candidate changes only the synchronous run-boundary validation inside `TermRecordOpfsStore._encodeAndAppendArtifactChunkForState`, plus a focused test file. It is independent of PR #764's resolved record-field encoding change, whose live head `1e82e1a237410c5a850661c1c361c444fa624546` was inspected before implementation.

## Change and validity scope

For ordinary ArrayBuffer-backed typed reference columns, the validator selects the current reference object once per run and loads the row's unique-content index once for both its offset and length. Both offset-table and length-table bounds remain checked for every row. The existing numeric, safe-integer, sentinel and offset-span splitting checks remain in their original order.

No validity is cached across an awaited append. The next run reselects the reference object and fixed-span/fixed-length dispatch, so replacement or mutation at an async boundary is observed. Shared-backed columns and fixed-length or fixed-span overrides stay on the original helpers. There is no new retained cache, metadata format, threshold, scheduler policy or persisted representation.

The baseline VNDB trace suggested this separate serial path: offset and length helper samples under the run validation loop totaled roughly 166 ms of profiling weight. The other helper samples occurred inside the encoding loop already covered by PR #764. These sampling weights include scheduling/blocked-time effects and are not a performance result. No local timing or whole-import improvement is claimed for this candidate.

## Validation

- All 208 tests passed across the existing term-record store suite and the new focused suite.
- Changed maintained JavaScript passed ESLint.
- The complete main TypeScript project passed, with a measured peak resident set of 748,544 KiB.
- The new test and its transitive types passed a scoped test-project TypeScript check, with a measured peak resident set of 403,660 KiB.
- All-target build dry run passed.
- An independent source review found no error-precedence, bounds, fixed-length or async-lifetime blocker.

`oracle-committed.json` records an exact-committed-source comparison against the pristine baseline. All 23 bounded cases match in full serialized lookup-sidecar bytes, run boundaries, and error class/message. The matrix includes compact, legacy and float64 fields; duplicate and null content offsets; large offset splits; each shared-backed reference column; generic arrays; short offset/length tables; missing and invalid row indexes; invalid numeric offsets; reserved lengths; fixed-length and fixed-span overrides; error precedence; and reference/fixed-length changes after awaited appends.

The tests also compare resolved-reference results with the unchanged generic-array path and explicitly verify that the compact, legacy and float64 cases exercise their intended persisted formats. The baseline oracle captures actual sidecar construction at the persistence boundary; it does not claim real OPFS/SQLite persistence, complete dictionary output parity or browser qualification.

`compare.mjs` is a reusable baseline/candidate comparison. It accepts explicit source roots and output path:

```sh
node compare.mjs /path/to/baseline /path/to/candidate oracle-new.json
```

Full repository unit/type/extension checks and any browser performance study are parent-owned CI gates. They were not replaced by the focused local checks.

## Retained setup failures

Two ambiguous test arrow expressions were parenthesized after the first scoped lint failure; the original log remains. The requested external timing wrapper was unavailable, so `run-command.py` now records command exit, elapsed/user/system time and child peak RSS directly. The scoped test config initially could not resolve ambient packages from its external evidence directory; its two failed setup logs remain alongside the corrected configuration. Those setup corrections changed neither runtime code nor oracle expectations.
