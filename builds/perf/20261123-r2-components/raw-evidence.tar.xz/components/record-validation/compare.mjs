import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {execFileSync} from 'node:child_process'
import {readFile, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {pathToFileURL} from 'node:url'

const [baselineRoot, candidateRoot, output] = process.argv.slice(2)
const digest = (bytes) => createHash('sha256').update(bytes).digest('hex')
async function identity(root) {
    return {
        root,
        head: execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim(),
        diffSha256: digest(execFileSync('git', ['-C', root, 'diff', '--binary', 'HEAD'])),
        recordStoreSha256: digest(await readFile(path.join(root, 'ext/js/dictionary/term-record-opfs-store.js'))),
    }
}
const identities = await Promise.all([identity(baselineRoot), identity(candidateRoot)])
const baseline = (await import(pathToFileURL(path.join(baselineRoot, 'ext/js/dictionary/term-record-opfs-store.js')))).TermRecordOpfsStore
const candidate = (await import(pathToFileURL(path.join(candidateRoot, 'ext/js/dictionary/term-record-opfs-store.js')))).TermRecordOpfsStore
function fixture(count = 32) {
    const offsets = Array.from({length: count}, (_, i) => i < 16 ? (i === 1 ? -1 : 16) : 0x100000010 + i * 16)
    const lengths = new Array(count).fill(7)
    return {
        chunk: {
            dictionary: 'Resolved validation parity', rowCount: count,
            expressionBytesList: offsets.map((_, i) => new TextEncoder().encode(`word-${i}`)), readingBytesList: [],
            readingEqualsExpressionList: new Uint8Array(count).fill(1), scoreList: new Int32Array(count).fill(2), sequenceList: new Int32Array(count).fill(-1),
            resolvedContentReferences: {uniqueIndexList: Uint32Array.from({length: count}, (_, i) => i), offsets: Float64Array.from(offsets), lengths: Uint32Array.from(lengths)},
        }, offsets, lengths,
    }
}
const cases = [
    ['empty', () => fixture(0)],
    ['compact-split-sentinel', () => fixture()],
    ['legacy-split', () => { const data = fixture(); data.chunk.resolvedContentReferences.lengths.fill(70000); return data }],
    ['float64-split', () => { const data = fixture(); data.chunk.scoreList = new Float64Array(32).fill(1.25); return data }],
    ['fixed-length', () => { const data = fixture(); data.chunk.fixedContentLength = 7; data.chunk.resolvedContentReferences.lengths = new Uint32Array(0); return data }],
    ['fixed-span', () => { const data = fixture(); data.chunk.fixedContentOffsetBase = 1024; data.chunk.fixedContentLength = 7; data.chunk.resolvedContentReferences.offsets.fill(NaN); return data }],
    ...['uniqueIndexList', 'offsets', 'lengths'].map((field) => [`shared-${field}`, () => {
        const data = fixture()
        const values = data.chunk.resolvedContentReferences[field]
        const shared = new values.constructor(new SharedArrayBuffer(values.byteLength))
        shared.set(values)
        data.chunk.resolvedContentReferences[field] = shared
        return data
    }]),
    ['generic-arrays', () => { const data = fixture(); delete data.chunk.resolvedContentReferences; return data }],
    ['short-offsets', () => { const data = fixture(); data.chunk.resolvedContentReferences.offsets = new Float64Array(1); return data }],
    ['short-lengths', () => { const data = fixture(); data.chunk.resolvedContentReferences.lengths = new Uint32Array(1); return data }],
    ['missing-index', () => { const data = fixture(); data.chunk.resolvedContentReferences.uniqueIndexList = new Uint32Array(1); return data }],
    ['bad-index', () => { const data = fixture(); data.chunk.resolvedContentReferences.uniqueIndexList[0] = 0xffffffff; return data }],
    ...[NaN, Infinity, -2, 0.5, Number.MAX_SAFE_INTEGER + 1].map((value) => [`bad-offset-${value}`, () => { const data = fixture(); data.chunk.resolvedContentReferences.offsets[0] = value; return data }]),
    ['reserved-length', () => { const data = fixture(); data.chunk.resolvedContentReferences.lengths[0] = 0xffffffff; return data }],
    ['length-bounds-before-offset-validation', () => { const data = fixture(); data.chunk.resolvedContentReferences.offsets[0] = 0.5; data.chunk.resolvedContentReferences.lengths = new Uint32Array(0); return data }],
    ['references-replaced-after-await', () => {
        const data = fixture(3)
        data.chunk.resolvedContentReferences.offsets.set([0, 0x100000000, 16])
        data.afterAppend = async (count) => {
            if (count !== 1) return
            await Promise.resolve()
            data.chunk.resolvedContentReferences = {uniqueIndexList: Uint32Array.of(0, 1, 2), offsets: Float64Array.of(0, 100, 110), lengths: Uint32Array.of(4, 5, 6)}
        }
        return data
    }],
    ['fixed-length-changed-after-await', () => {
        const data = fixture(3)
        data.chunk.resolvedContentReferences.offsets.set([0, 0x100000000, 16])
        data.afterAppend = async (count) => {
            if (count !== 1) return
            await Promise.resolve()
            data.chunk.fixedContentLength = 13
        }
        return data
    }],
]
async function run(Store, make) {
    const {chunk, offsets, lengths, afterAppend = () => {}} = make()
    const store = new Store()
    const frames = []
    store._appendEncodedChunk = async (_state, firstId, count, _name, base, payload, fields, format) => {
        frames.push(store._createLookupIndexChunk(firstId, count, base, payload, fields, format))
        await afterAppend(frames.length)
    }
    try {
        await store._encodeAndAppendArtifactChunkForState({}, chunk, 1, offsets, lengths)
        return {frames, error: null}
    } catch (error) {
        return {frames, error: {name: error.name, message: error.message}}
    }
}
const results = []
for (const [name, make] of cases) {
    const first = await run(baseline, make)
    const second = await run(candidate, make)
    assert.deepEqual(second, first, name)
    results.push({name, error: first.error, frameCount: first.frames.length, frameBytes: first.frames.map((bytes) => bytes.length), frameSha256: first.frames.map(digest)})
}
assert.deepEqual(await identity(baselineRoot), identities[0])
assert.deepEqual(await identity(candidateRoot), identities[1])
await writeFile(output, JSON.stringify({schemaVersion: 1, runtime: process.version, identities, scriptSha256: digest(await readFile(new URL(import.meta.url))), scope: 'Exact serialized lookup-sidecar bytes, run boundaries and failure names/messages for bounded valid/malformed/fixed/shared/mutation cases. No persistence, full dictionary or performance claim.', cases: results}, null, 2) + '\n')
console.log(JSON.stringify({passed: results.length, output}))
