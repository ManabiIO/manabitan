#!/usr/bin/env python3
import json
from pathlib import Path
import resource
import subprocess
import sys
import time

log = Path(sys.argv[1])
started = time.time()
with log.open("w") as file:
    result = subprocess.run(sys.argv[2:], stdout=file, stderr=subprocess.STDOUT, check=False)
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
log.with_suffix(log.suffix + ".receipt.json").write_text(json.dumps({
    "command": sys.argv[2:], "startedEpochSeconds": started,
    "elapsedSeconds": time.time() - started, "exitCode": result.returncode,
    "peakResidentKiB": usage.ru_maxrss, "userCpuSeconds": usage.ru_utime,
    "systemCpuSeconds": usage.ru_stime,
}, indent=2) + "\n")
sys.exit(result.returncode if result.returncode >= 0 else 128 - result.returncode)
