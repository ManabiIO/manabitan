import assert from 'node:assert/strict';
import {mkdir, readFile} from 'node:fs/promises';
import path from 'node:path';
import {
    baselineRoot, baselineCommit, candidateRoot, sourceReceipt, evidenceRoot,
    helperFiles, fileHashes, fileIdentity, originalOraclePath, correctedOraclePath, saveJson, frozenParentRoot, dbFile, candidateDbSha,
} from './common.mjs';

const arm = process.argv[2];
assert(['A', 'B'].includes(arm));
const candidateCommit = process.argv[4];
if (arm === 'B') { assert(/^[0-9a-f]{40}$/.test(candidateCommit)); }
const output = path.join(evidenceRoot, process.argv[3]);
await mkdir(output);
const source = await sourceReceipt(arm === 'B' ? candidateRoot : baselineRoot, arm === 'B' ? candidateCommit : baselineCommit);
const parent = await sourceReceipt(baselineRoot, baselineCommit);
for (const [file, hash] of Object.entries(parent.identity)) {
    assert.equal(source.identity[file], arm === 'B' && file === dbFile ? candidateDbSha : hash, `Only the database source may differ from dcfc: ${file}`);
}
const runtimeChanges = ['ext/lib/term-bank-parser.wasm'];
if (arm === 'B') {
    runtimeChanges.push(dbFile);
}
const expectedRuntimeChanges = Object.fromEntries(runtimeChanges.map((file) => [file, source.identity[file]]));
const finalOraclePath = path.join(frozenParentRoot, 'final-output-oracle.json');
const parentReceiptPath = path.join(frozenParentRoot, 'result.json');
const parentReceipt = JSON.parse(await readFile(parentReceiptPath, 'utf8'));
assert.equal(parentReceipt.success, true);
assert.deepEqual(parentReceipt.source, parent);
assert.equal(parentReceipt.finalOracle.sha256, '5a2d8167f046e313949af8005ed493b651d10a4de95bfc5a2de24699ec61a58e');
assert.deepEqual(await fileIdentity(finalOraclePath), parentReceipt.finalOracle);
const config = {
    schemaVersion: 1, arm, mode: 'correctness', output, preciseCoverage: false,
    source, parent, expectedRuntimeChanges, helpers: await fileHashes(evidenceRoot, helperFiles),
    oracles: {
        original: (await fileIdentity(originalOraclePath)).sha256,
        corrected: (await fileIdentity(correctedOraclePath)).sha256,
    },
    expectedFinalOracle: {path: finalOraclePath, ...await fileIdentity(finalOraclePath)},
    parentAcquisition: {path: parentReceiptPath, ...await fileIdentity(parentReceiptPath)},
    protocol: JSON.parse(await readFile(path.join(evidenceRoot, 'protocol.json'), 'utf8')),
};
await saveJson(path.join(output, 'config.json'), config);
console.log(path.join(output, 'config.json'));
