import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {evidenceRoot, fileIdentity, fileHashes, helperFiles, saveJson, sha} from './common.mjs';

const output = path.resolve(evidenceRoot, process.argv[2]);
const config = JSON.parse(await readFile(path.join(output, 'config.json'), 'utf8'));
const candidate = JSON.parse(await readFile(path.join(output, 'result.json'), 'utf8'));
const baselineBytes = await readFile(config.parentAcquisition.path);
assert.equal(sha(baselineBytes), config.parentAcquisition.sha256);
const baseline = JSON.parse(baselineBytes);
assert.equal(baseline.success, true);
assert.equal(candidate.success, true);
assert.equal(candidate.timingEligible, false);
assert.equal(candidate.source.commit, '5ee2c0c1db0036fb7289952675d315c54c58cce7');
assert.deepEqual(candidate.source, config.source);
assert.deepEqual(baseline.source, config.parent);
assert.deepEqual(await fileHashes(evidenceRoot, helperFiles), config.helpers);
assert.deepEqual(candidate.finalOracle, baseline.finalOracle);
assert.deepEqual(await fileIdentity(path.join(output, 'final-output-oracle.json')), baseline.finalOracle);
assert.deepEqual(
    JSON.parse(await readFile(path.join(output, 'final-output-oracle.json'), 'utf8')),
    JSON.parse(await readFile(config.expectedFinalOracle.path, 'utf8')),
);
for (const field of ['rows', 'totalBytes', 'parserPolicy', 'codecWorkers', 'plannedBlocks', 'compressionRequests', 'sourceConsumedReplies', 'compressionReplies']) {
    assert.equal(candidate[field], baseline[field], field);
}
assert.equal(candidate.groupResults.length, 12);
assert.equal(candidate.rows, 528299);
assert.equal(candidate.compressionReplies, 103);
for (let i = 0; i < 12; ++i) {
    const a = baseline.groupResults[i];
    const b = candidate.groupResults[i];
    for (const field of ['index', 'banks', 'rows', 'ownsContentBytes', 'registeredSourceBytes', 'sourceByteOffsetModulo8', 'sourceSha256', 'descriptorSha256', 'nativeFrameSha256']) {
        assert.deepEqual(b[field], a[field], `Group ${i}: ${field}`);
    }
    for (const field of ['dedupNativeCallCount', 'dedupNativeScannedRows', 'dedupNativeBulkPendingRows', 'dedupNativeExactCandidates', 'dedupNativeFallbackCount']) {
        assert.equal(b.metrics[field], a.metrics[field], `Group ${i}: ${field}`);
    }
}
assert.equal(candidate.allocation.dictionaryNameBackingBytes, 0);
assert.equal(candidate.allocation.retainedDictionaryNameBackingBytesAvoided, 2097152);
assert.equal(candidate.allocation.nativeArenaBytes, baseline.allocation.nativeArenaBytes);
assert.deepEqual(candidate.dictionaryNameRepresentation, {
    physicalTable: null,
    _termEntryContentMetaDictNameIdPrefixValue: 1,
    _termEntryContentMetaDictNameIdPrefixEnd: 362032,
});
assert.equal(candidate.dictionaryNameMaterializations, 0);
assert.equal(candidate.prefixPublications.length, 12);
const comparison = {
    success: true,
    timingEligible: false,
    baseline: baseline.source,
    candidate: candidate.source,
    baselineAcquisition: config.parentAcquisition,
    candidateAcquisition: {path: path.join(output, 'result.json'), ...await fileIdentity(path.join(output, 'result.json'))},
    helpers: config.helpers,
    rows: candidate.rows,
    groups: candidate.groupResults.length,
    frames: candidate.compressionReplies,
    finalOracle: candidate.finalOracle,
    allocation: candidate.allocation,
    dictionaryNameRepresentation: candidate.dictionaryNameRepresentation,
    prefixPublications: candidate.prefixPublications,
    dictionaryNameMaterializations: candidate.dictionaryNameMaterializations,
    retainedBackingBytesAvoided: 2097152,
    limitation: 'Exactly one retained Uint32 backing is removed. No browser import latency or process peak-memory claim; representation scalar properties remain and are recorded explicitly.',
};
await saveJson(path.join(evidenceRoot, `${process.argv[2]}-comparison.json`), comparison);
console.log(JSON.stringify({success: true, rows: candidate.rows, groups: 12, frames: 103, retainedBackingBytesAvoided: 2097152, finalOracleSha256: candidate.finalOracle.sha256}));
