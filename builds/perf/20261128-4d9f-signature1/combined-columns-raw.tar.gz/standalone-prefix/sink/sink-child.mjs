// Actual current JMdict producer -> canonical public sink, with a Node OPFS
// boundary adapter. No measured child uses inspector or reconstructed spans.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream, openAsBlob} from 'node:fs';
import {mkdir, readFile, readdir} from 'node:fs/promises';
import {Session} from 'node:inspector/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {Worker} from 'node:worker_threads';
import {BlobReader, TextWriter, ZipReader} from '@zip.js/zip.js';
import {
    assertResources, baselineRoot, candidateDbSha, correctedOraclePath, dbFile,
    evidenceRoot, fileHashes, fileIdentity, helperFiles, originalOraclePath,
    resources, saveJson, sha, sourceReceipt,
} from './common.mjs';

assert.equal(process.version, 'v22.22.0');
const configBytes = await readFile(process.argv[2]);
const config = JSON.parse(configBytes);
const output = path.resolve(config.output);
await mkdir(output, {recursive: true});
const sourceRoot = config.source.root;
const sourceModule = (file) => import(pathToFileURL(path.join(sourceRoot, file)).href);
const initialResources = await resources();
assertResources(initialResources);
const initialSource = await sourceReceipt(sourceRoot, config.source.commit);
assert.deepEqual(initialSource, config.source);
assert.deepEqual(await fileHashes(evidenceRoot, helperFiles), config.helpers);
assert.equal(config.preciseCoverage, config.mode === 'admission');
assert.notEqual(config.mode, 'measured-with-coverage');
if (config.preciseCoverage) { assert.equal(initialSource.identity[dbFile], candidateDbSha); }
const oracleBytes = await readFile(originalOraclePath);
const oracle = JSON.parse(oracleBytes);
const correctedBytes = await readFile(correctedOraclePath);
const corrected = JSON.parse(correctedBytes);
assert.equal(sha(oracleBytes), config.oracles.original);
assert.equal(sha(correctedBytes), config.oracles.corrected);
assert.equal(config.mode, 'correctness');
assert.equal(config.preciseCoverage, false);
const changedRuntimeFiles = config.arm === 'B' ? [
    'ext/lib/term-bank-parser.wasm',
    'ext/js/dictionary/dictionary-database.js',
] : ['ext/lib/term-bank-parser.wasm'];
assert.deepEqual(Object.keys(config.expectedRuntimeChanges).sort(), [...changedRuntimeFiles].sort());
for (const [file, hash] of Object.entries(corrected.sourceIdentity)) {
    assert.equal(initialSource.identity[file], config.expectedRuntimeChanges[file] ?? hash, `Source/oracle binding: ${file}`);
}
for (const file of changedRuntimeFiles) {
    if (config.arm === 'B') { assert.notEqual(initialSource.identity[file], corrected.sourceIdentity[file]); }
}
const parentReceiptBytes = await readFile(config.parentAcquisition.path);
assert.equal(sha(parentReceiptBytes), config.parentAcquisition.sha256);
const parentReceipt = JSON.parse(parentReceiptBytes);
assert.equal(parentReceipt.success, true);
assert.deepEqual(parentReceipt.source, config.parent);
for (const [file, hash] of Object.entries(config.parent.identity)) {
    assert.equal(initialSource.identity[file], config.arm === 'B' && file === dbFile ? candidateDbSha : hash, `Unexpected dcfc source delta: ${file}`);
}
const currentOracleBytes = await readFile(config.expectedFinalOracle.path);
assert.equal(sha(currentOracleBytes), config.expectedFinalOracle.sha256);
const currentOracle = JSON.parse(currentOracleBytes);
const expectedAdoptedBytes = corrected.groupResults.map((group) => group.metrics.dedupRecentSourceAdoptedBytes);
const lockBytes = await readFile(path.join(baselineRoot, 'test/perf/dictionaries.lock.json'));
assert.equal(sha(lockBytes), oracle.lockSha256);
const fixture = JSON.parse(lockBytes).dictionaries.jmdict;
const archivePath = path.join(baselineRoot, 'builds/e2e-dictionary-cache', fixture.cacheFile);
assert.deepEqual(await fileIdentity(archivePath), {bytes: fixture.sizeBytes, sha256: fixture.sha256});
assert.equal(fixture.sha256, oracle.fixtureSha256);
globalThis.fetch = async (input) => {
    const url = new URL(String(input));
    assert.equal(url.protocol, 'file:');
    return new Response(await readFile(url), {headers: {'Content-Type': 'application/wasm'}});
};

const api = await sourceModule('ext/js/dictionary/zstd-term-content.js');
const codecWorkers = [];
const observedPools = new Set();
const requestOrder = [];
const completedBlocks = new Map();
const captures = [];
const groupResults = [];
const registrationCalls = [];
const admissionShapes = [];
let currentGroup = -1;
let pendingCapture = null;
let plannedBlocks = 0;
let compressionRequests = 0;
let compressionReplies = 0;
let sourceConsumedReplies = 0;
let fatalWorkerError = null;
let database;
let env;
let zip;
let coverageSession;
let coverageProof = null;
let drainMs = null;
let pipelineEnvelopeMs = null;
const bridge = `
    import {parentPort, workerData} from 'node:worker_threads';
    import {readFile} from 'node:fs/promises';
    globalThis.self = {
        addEventListener(type, listener) {
            if (type !== 'message') throw Error('Unexpected codec listener');
            parentPort.on('message', (data) => listener({data}));
        },
        postMessage(message, transfer = []) { parentPort.postMessage(message, transfer); },
    };
    globalThis.fetch = async (input) => {
        const url = new URL(String(input));
        if (url.protocol !== 'file:') throw Error('Codec boundary cannot fetch network resources');
        return new Response(await readFile(url), {headers: {'Content-Type': 'application/wasm'}});
    };
    await import(workerData.entry);
`;
class ActualCodecWorker extends EventTarget {
    constructor(entry) {
        super();
        assert.equal(String(entry), pathToFileURL(path.join(sourceRoot, 'ext/js/dictionary/zstd-term-content-compression-worker.js')).href);
        this.index = codecWorkers.length;
        this.terminated = false;
        this.ready = new Promise((resolve, reject) => { this.resolveReady = resolve; this.rejectReady = reject; });
        this.thread = new Worker(new URL(`data:text/javascript,${encodeURIComponent(bridge)}`), {workerData: {entry: String(entry)}});
        codecWorkers.push(this);
        this.thread.on('message', (data) => {
            if (data.type === 'ready') { this.resolveReady(); }
            if (data.type === 'initialization-error') { this.rejectReady(Error(String(data.error))); }
            if (data.type === 'source-consumed') { ++sourceConsumedReplies; }
            if (data.compressed instanceof ArrayBuffer) {
                assert(!completedBlocks.has(data.id));
                ++compressionReplies;
                completedBlocks.set(data.id, data.compressed);
            }
            this.dispatchEvent(new MessageEvent('message', {data}));
        });
        const fail = (error) => {
            fatalWorkerError ??= error;
            this.rejectReady(error);
            const event = new Event('error');
            Object.defineProperty(event, 'message', {value: String(error.message)});
            this.dispatchEvent(event);
        };
        this.thread.on('error', fail);
        this.thread.on('messageerror', () => {
            fatalWorkerError ??= Error('Codec message deserialization failed');
            this.dispatchEvent(new MessageEvent('messageerror'));
        });
        this.thread.on('exit', (code) => { if (!this.terminated) { fail(Error(`Unexpected codec worker exit ${code}`)); } });
    }
    postMessage(data, transfer = []) {
        assert.equal(typeof data.id, 'number');
        assert(data.source instanceof Uint8Array);
        ++compressionRequests;
        requestOrder.push({id: data.id, group: currentGroup, bytes: data.contentBytes, spans: data.sourceOffsets.length, worker: this.index});
        this.thread.postMessage(data, transfer);
    }
    terminate() { this.terminated = true; this.termination ??= this.thread.terminate(); }
}
globalThis.Worker = ActualCodecWorker;
const originalBegin = api.TermContentCompressionPool.prototype.beginCompressWrappedSpans;
api.TermContentCompressionPool.prototype.beginCompressWrappedSpans = function (source, offsets, lengths, starts, blocks, dictName, options) {
    assert.equal(pendingCapture, null);
    pendingCapture = {source, offsets, lengths, starts, blocks};
    observedPools.add(this);
    plannedBlocks += blocks.length;
    captures.push({group: currentGroup, sourceBytes: source.byteLength, sourceByteOffsetModulo8: source.byteOffset % 8, spanCount: offsets.length, blockLengths: [...blocks], dictName});
    return originalBegin.call(this, source, offsets, lengths, starts, blocks, dictName, options);
};
function boundary(label) {
    assert.equal(fatalWorkerError, null);
    const pendingCounts = [...observedPools].map((pool) => pool._pending.size);
    assert(pendingCounts.every((count) => count === 0), `${label}: a codec job is outstanding`);
    assert.equal(plannedBlocks, compressionRequests, `${label}: undispatched planned block`);
    assert.equal(compressionRequests, sourceConsumedReplies, `${label}: unacknowledged source`);
    assert.equal(compressionRequests, compressionReplies, `${label}: incomplete compression result`);
    assert.equal(database._inFlightTermContentSourceBatches.size, 0, `${label}: registration not released`);
    return {label, plannedBlocks, compressionRequests, sourceConsumedReplies, compressionReplies, pendingCounts};
}

const {registerOwnedTermContent} = await sourceModule('ext/js/dictionary/term-content-ownership.js');
const {RAW_TERM_CONTENT_TOKEN_DICT_NAME} = await sourceModule('ext/js/dictionary/raw-term-content.js');
let parserListener;
let parserReply = null;
globalThis.self = {
    addEventListener(type, listener) { assert.equal(type, 'message'); parserListener = listener; },
    postMessage(message, transfer = []) {
        const reply = parserReply;
        assert(reply);
        parserReply = null;
        reply(structuredClone(message, {transfer}));
    },
};
await sourceModule('ext/js/dictionary/term-bank-wasm-parser-worker.js');
async function parseRequest(message) {
    assert.equal(parserReply, null);
    let timeout;
    const reply = new Promise((resolve, reject) => {
        parserReply = resolve;
        timeout = setTimeout(() => reject(Error('Parser adapter response deadline exceeded')), 30000);
    });
    try {
        parserListener({data: message});
        const result = await reply;
        assert(!result.error, JSON.stringify(result.error));
        return result;
    } finally { clearTimeout(timeout); }
}
const {DictionaryDatabase} = await sourceModule('ext/js/dictionary/dictionary-database.js');
const prefixPublications = [];
let dictionaryNameMaterializations = 0;
if (config.arm === 'B') {
    const originalFill = DictionaryDatabase.prototype._fillTermEntryContentMetaDictNameIds;
    const originalMaterialize = DictionaryDatabase.prototype._materializeTermEntryContentMetaDictNameIds;
    assert.equal(typeof originalFill, 'function');
    assert.equal(typeof originalMaterialize, 'function');
    DictionaryDatabase.prototype._materializeTermEntryContentMetaDictNameIds = function (...args) {
        ++dictionaryNameMaterializations;
        return originalMaterialize.apply(this, args);
    };
    DictionaryDatabase.prototype._fillTermEntryContentMetaDictNameIds = function (firstIndex, endIndex, dictNameId) {
        assert.equal(this._termEntryContentMetaDictNameIdTable, null);
        const before = {value: this._termEntryContentMetaDictNameIdPrefixValue, end: this._termEntryContentMetaDictNameIdPrefixEnd};
        const result = originalFill.call(this, firstIndex, endIndex, dictNameId);
        assert.equal(this._termEntryContentMetaDictNameIdTable, null);
        assert.equal(firstIndex, before.end);
        assert(endIndex > firstIndex);
        assert.equal(dictNameId, 1);
        assert.equal(this._termEntryContentMetaDictNameIdPrefixValue, 1);
        assert.equal(this._termEntryContentMetaDictNameIdPrefixEnd, endIndex);
        prefixPublications.push({group: currentGroup, firstIndex, endIndex, dictNameId, before, after: {value: this._termEntryContentMetaDictNameIdPrefixValue, end: this._termEntryContentMetaDictNameIdPrefixEnd}});
        return result;
    };
}
const originalRegister = DictionaryDatabase.prototype._registerInFlightTermContentSources;
DictionaryDatabase.prototype._registerInFlightTermContentSources = function (...args) {
    const start = performance.now();
    let result;
    try { result = originalRegister.apply(this, args); } finally {
        registrationCalls.push({group: currentGroup, milliseconds: performance.now() - start, rows: args[0].length});
    }
    if (config.preciseCoverage) {
        const [offsets, lengths, names, , spans] = args;
        admissionShapes.push({
            group: currentGroup, count: offsets.length, offsetsType: offsets.constructor.name,
            lengthsType: lengths.constructor.name, sourceOffsetsType: spans?.offsets?.constructor?.name,
            sourceBytesType: spans?.buffer?.constructor?.name, identicalLengths: spans?.lengths === lengths,
            uniformName: typeof names === 'string', activeAfterRegistration: this._inFlightTermContentSourceBatches.size,
            fixedPrivateMetadata: [offsets, lengths, spans?.offsets].every((column) => column?.buffer instanceof ArrayBuffer && column.buffer.resizable === false),
        });
    }
    return result;
};

async function digestDirectory(root) {
    const files = [];
    const rawFiles = [];
    const shardGenerations = new Map();
    async function digestFile(relative) {
        const isRecord = relative.startsWith('manabitan-term-records/') && relative.endsWith('.mbtr');
        const isIndex = relative.startsWith('manabitan-term-records/') && relative.endsWith('.mbtr.mbti');
        const generationOffset = isRecord ? 8 : isIndex ? 24 : null;
        const expectedMagic = isRecord ? 'MBTRD16X' : isIndex ? 'MBTIDX11' : null;
        const raw = createHash('sha256');
        const normalized = createHash('sha256');
        let bytes = 0;
        let generationHex = null;
        for await (const chunk of createReadStream(path.join(root, relative))) {
            raw.update(chunk);
            if (bytes === 0 && generationOffset !== null) {
                assert(chunk.byteLength >= generationOffset + 16);
                assert.equal(chunk.subarray(0, 8).toString('utf8'), expectedMagic);
                generationHex = chunk.subarray(generationOffset, generationOffset + 16).toString('hex');
                normalized.update(chunk.subarray(0, generationOffset));
                normalized.update(new Uint8Array(16));
                normalized.update(chunk.subarray(generationOffset + 16));
            } else { normalized.update(chunk); }
            bytes += chunk.byteLength;
        }
        if (generationOffset !== null) {
            assert(generationHex);
            const recordPath = isIndex ? relative.slice(0, -'.mbti'.length) : relative;
            const pair = shardGenerations.get(recordPath) ?? {};
            pair[isRecord ? 'record' : 'index'] = generationHex;
            shardGenerations.set(recordPath, pair);
        }
        files.push({path: relative, bytes, sha256: normalized.digest('hex'), normalizedGenerationRange: generationOffset === null ? null : [generationOffset, generationOffset + 16]});
        rawFiles.push({path: relative, bytes, sha256: raw.digest('hex'), generationHex});
    }
    async function visit(relative) {
        const entries = await readdir(path.join(root, relative), {withFileTypes: true});
        entries.sort((a, b) => a.name.localeCompare(b.name, 'en'));
        for (const entry of entries) {
            const name = path.join(relative, entry.name);
            assert(!entry.isSymbolicLink());
            if (entry.isDirectory()) { await visit(name); } else {
                assert(entry.isFile());
                await digestFile(name);
            }
        }
    }
    await visit('');
    assert(shardGenerations.size > 0);
    for (const [recordPath, pair] of shardGenerations) {
        assert.equal(typeof pair.record, 'string', `Missing authoritative descriptor: ${recordPath}`);
        assert.equal(pair.index, pair.record, `Generation linkage mismatch: ${recordPath}`);
    }
    await saveJson(path.join(output, 'raw-final-files.json'), {files: rawFiles, shardGenerations: [...shardGenerations]});
    return {files, shardCount: shardGenerations.size, generationLinkageVerified: true};
}
function valueDigest(value) {
    if (ArrayBuffer.isView(value)) {
        return {type: value.constructor.name, length: value.length, bytes: value.byteLength, sha256: sha(new Uint8Array(value.buffer, value.byteOffset, value.byteLength))};
    }
    if (value instanceof Map) { return {type: 'Map', size: value.size, entries: [...value].map(([key, item]) => [valueDigest(key), valueDigest(item)])}; }
    if (Array.isArray(value)) { return value.map(valueDigest); }
    if (value !== null && typeof value === 'object') {
        assert.equal(Object.getPrototypeOf(value), Object.prototype, 'Unknown metadata object would escape full hashing');
        return Object.fromEntries(Object.entries(value).sort(([a], [b]) => a.localeCompare(b, 'en')).map(([key, item]) => [key, valueDigest(item)]));
    }
    assert(['number', 'string', 'boolean', 'undefined'].includes(typeof value) || value === null);
    if (typeof value === 'number' && !Number.isFinite(value)) { return {number: String(value)}; }
    return value;
}
function metadataDigest(db) {
    const names = Object.keys(db).filter((name) => name.startsWith('_termEntryContentMeta')).sort();
    const representationNames = config.arm === 'B' ? [
        '_termEntryContentMetaDictNameIdPrefixValue',
        '_termEntryContentMetaDictNameIdPrefixEnd',
    ] : [];
    assert.deepEqual(names, [...Object.keys(currentOracle.metadata), ...representationNames].sort(), 'Every metadata property must be accounted for');
    let logicalDictionaryNames = db._termEntryContentMetaDictNameIdTable;
    if (config.arm === 'B' && logicalDictionaryNames === null) {
        // Independent mapping of the representation; no product getter or
        // materializer participates in the logical-column oracle.
        const capacity = db._termEntryContentMetaStateTable.length;
        const value = db._termEntryContentMetaDictNameIdPrefixValue;
        const end = db._termEntryContentMetaDictNameIdPrefixEnd;
        assert(Number.isInteger(value) && value >= 0 && value <= 0xffffffff);
        assert(Number.isInteger(end) && end >= 0 && end <= capacity);
        logicalDictionaryNames = new Uint32Array(capacity);
        logicalDictionaryNames.fill(value, 0, end);
    }
    return Object.fromEntries(names.filter((name) => !representationNames.includes(name)).map((name) => [name, valueDigest(
        name === '_termEntryContentMetaDictNameIdTable' ? logicalDictionaryNames : db[name],
    )]));
}
function dictionaryNameRepresentation(db) {
    const table = db._termEntryContentMetaDictNameIdTable;
    if (config.arm !== 'B') { return {physicalTable: valueDigest(table)}; }
    // These are explicitly validated and retained in the result separately
    // from the baseline logical metadata schema; they are never ignored.
    const representation = {
        physicalTable: table === null ? null : valueDigest(table),
        _termEntryContentMetaDictNameIdPrefixValue: db._termEntryContentMetaDictNameIdPrefixValue,
        _termEntryContentMetaDictNameIdPrefixEnd: db._termEntryContentMetaDictNameIdPrefixEnd,
    };
    assert.equal(table, null, 'JMdict must not materialize dictionary-name IDs');
    assert.equal(representation._termEntryContentMetaDictNameIdPrefixValue, 1);
    assert.equal(representation._termEntryContentMetaDictNameIdPrefixEnd, 362032);
    return representation;
}
function allocationReceipt(db) {
    const arena = db._termContentMetadataArena;
    const capacity = arena.state.length;
    const table = db._termEntryContentMetaDictNameIdTable;
    const parentColumn = currentOracle.metadata._termEntryContentMetaDictNameIdTable;
    assert.equal(parentColumn.type, 'Uint32Array');
    assert.equal(parentColumn.length, capacity);
    assert.equal(parentColumn.bytes, capacity * 4);
    if (table !== null) {
        assert(table instanceof Uint32Array);
        assert.equal(table.byteOffset, 0);
        assert.equal(table.byteLength, capacity * 4);
        assert.equal(table.buffer.byteLength, table.byteLength);
        assert.notEqual(table.buffer, arena.memory.buffer);
    }
    const receipt = {
        denseCount: db._termEntryContentMetaDenseCount,
        capacity,
        hashSlots: arena.slots.length,
        nativeArenaBytes: arena.memory.buffer.byteLength,
        physicalDictionaryNameIds: table === null ? null : valueDigest(table),
        dictionaryNameBackingBytes: table === null ? 0 : table.buffer.byteLength,
        baselineDictionaryNameBackingBytes: parentColumn.bytes,
        retainedDictionaryNameBackingBytesAvoided: parentColumn.bytes - (table === null ? 0 : table.buffer.byteLength),
        ownedArenaAndDictionaryNameBytes: arena.memory.buffer.byteLength + (table === null ? 0 : table.buffer.byteLength),
    };
    assert.equal(capacity, 524288);
    assert.equal(receipt.denseCount, 362032);
    assert.equal(receipt.hashSlots, 1048576);
    assert.equal(receipt.nativeArenaBytes, parentReceipt.allocation.nativeArenaBytes);
    assert.equal(receipt.nativeArenaBytes, 26214400);
    if (config.arm === 'B') {
        assert.equal(table, null);
        assert.equal(receipt.retainedDictionaryNameBackingBytesAvoided, 2097152);
        assert.equal(dictionaryNameMaterializations, 0);
        assert.equal(prefixPublications.length, 12);
        assert.deepEqual(prefixPublications.map(({group}) => group), Array.from({length: 12}, (_, i) => i));
        for (const publication of prefixPublications) {
            assert.equal(publication.endIndex - publication.firstIndex, parentReceipt.groupResults[publication.group].metrics.dedupNativeBulkPendingRows);
        }
    }
    return receipt;
}
async function collectCoverageProof() {
    const {result} = await coverageSession.post('Profiler.takePreciseCoverage');
    await coverageSession.post('Profiler.stopPreciseCoverage');
    const script = result.find((entry) => entry.url === pathToFileURL(path.join(sourceRoot, dbFile)).href);
    assert(script, 'Candidate module missing from precise coverage');
    const source = await readFile(path.join(sourceRoot, dbFile), 'utf8');
    const names = ['createPendingTermContentSpans', 'hasSimpleInFlightTermContentSources', '_registerInFlightTermContentSources'];
    const functions = script.functions.filter((entry) => names.includes(entry.functionName));
    assert.equal(functions.length, 3);
    const functionByName = (name) => functions.find((entry) => entry.functionName === name);
    const countAt = (fn, position) => {
        const containing = fn.ranges.filter((range) => range.startOffset <= position && position < range.endOffset);
        containing.sort((a, b) => (a.endOffset - a.startOffset) - (b.endOffset - b.startOffset));
        assert(containing.length > 0);
        return containing[0].count;
    };
    const validator = functionByName('hasSimpleInFlightTermContentSources');
    const validatorRange = validator.ranges[0];
    const trueOffset = source.lastIndexOf('return true;', validatorRange.endOffset);
    assert(trueOffset >= validatorRange.startOffset);
    const register = functionByName('_registerInFlightTermContentSources');
    const genericOffset = source.indexOf('const buffer = pendingContentSpans', register.ranges[0].startOffset);
    assert(genericOffset >= register.ranges[0].startOffset && genericOffset < register.ranges[0].endOffset);
    const proof = {
        sourceSha256: sha(source), functions, trueOffset, genericOffset,
        producerCalls: functionByName('createPendingTermContentSpans').ranges[0].count,
        validatorCalls: validator.ranges[0].count,
        trueReturnCount: countAt(validator, trueOffset),
        genericLoopBodyCount: countAt(register, genericOffset),
        registrationCalls: register.ranges[0].count,
        admissionShapes,
    };
    await saveJson(path.join(output, 'precise-coverage.json'), {script, proof});
    assert.equal(proof.producerCalls, 12);
    assert.equal(proof.validatorCalls, 12);
    assert.equal(proof.trueReturnCount, 12);
    assert.equal(proof.genericLoopBodyCount, 0);
    assert.equal(proof.registrationCalls, 12);
    assert.equal(admissionShapes.length, 12);
    for (const shape of admissionShapes) {
        assert(shape.count > 0 && shape.identicalLengths && shape.uniformName && shape.fixedPrivateMetadata);
        assert.equal(shape.offsetsType, 'Float64Array');
        assert.equal(shape.sourceOffsetsType, 'Uint32Array');
        assert.equal(shape.activeAfterRegistration, 1);
    }
    return proof;
}

try {
    const {createNodeOpfs} = await sourceModule('test/fixtures/opfs-continuation/node-opfs-adapter.mjs');
    env = await createNodeOpfs();
    Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: 4, deviceMemory: 8, storage: {getDirectory: async () => env.root}}});
    const {compileCanonicalScanModule} = await sourceModule('ext/js/dictionary/term-content-canonical-scan.js');
    const {RawZipPayloadReader} = await sourceModule('ext/js/dictionary/term-bank-source-pipeline.js');
    const archive = await openAsBlob(archivePath);
    zip = new ZipReader(new BlobReader(archive), {useWebWorkers: false});
    const entries = await zip.getEntries();
    const index = JSON.parse(await entries.find((entry) => entry.filename === 'index.json').getData(new TextWriter(), {useWebWorkers: false}));
    assert.equal(index.title, fixture.expectedTitle);
    assert.equal(index.revision, fixture.revision);
    const banks = entries.filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)));
    const totalBytes = banks.reduce((total, bank) => total + bank.uncompressedSize, 0);
    const groupCount = Math.min(banks.length, Math.max(3 * 4, Math.ceil(totalBytes / (24 * 1024 * 1024))));
    const groups = [];
    let start = 0;
    let consumed = 0;
    for (let groupIndex = 0; groupIndex < groupCount - 1; ++groupIndex) {
        const remaining = groupCount - groupIndex;
        const target = (totalBytes - consumed) / remaining;
        let end = start + 1;
        let bytes = banks[start].uncompressedSize;
        const maxEnd = banks.length - remaining + 1;
        while (end < maxEnd) {
            const next = bytes + banks[end].uncompressedSize;
            if (Math.abs(next - target) > Math.abs(bytes - target)) { break; }
            bytes = next;
            ++end;
        }
        groups.push(banks.slice(start, end));
        start = end;
        consumed += bytes;
    }
    groups.push(banks.slice(start));
    assert.equal(groups.length, 12);
    assert.equal(totalBytes, oracle.totalBytes);
    assert.deepEqual(groups.map((group) => group.map(({filename}) => filename)), oracle.groupResults.map((group) => group.banks));
    await parseRequest({type: 'initialize', module: await WebAssembly.compile(await readFile(path.join(sourceRoot, 'ext/lib/term-bank-parser.wasm')))});
    await api.initializeTermContentZstd();
    assert.equal(codecWorkers.length, 4);
    await Promise.all(codecWorkers.map((worker) => worker.ready));
    await compileCanonicalScanModule();
    database = new DictionaryDatabase();
    database.setImportOptimizationFlags({termContentStorageMode: 'raw-bytes', queueTermContentWrites: true, rawTermBankSourceBytes: totalBytes});
    database._bulkImportTransactionOpen = true;
    database._deferTermsVirtualTableSync = true;
    database._termContentZstdInitialized = true;
    await database._termContentStore.prepare();
    await database._termRecordStore.prepare();
    await database._termContentStore.beginImportSession();
    await database._termRecordStore.beginImportSession();
    database._termContentBlockImportSession = database._termContentBlockStore.beginImportSession();
    const payloads = new RawZipPayloadReader(archive);
    const options = {copyContentBytes: false, includeContentMetadata: true, initialContentBytesPerRow: 48, minimalDecode: true, reuseExpressionForReadingDecode: true, preallocateChunkRows: true, skipTagRuleDecode: false, lazyGlossaryDecode: true, mediaHintFastScan: false, projectImagePaths: false, validateGlossaryTypes: true, computeContentHashes: true, emitContentSlab: true, emitTokenBinaryContent: true, emitTermByteLists: false, prepareLookupIndexes: true, prepareLookupRoute: totalBytes >= 128 * 1024 * 1024, ownContentBytes: false};
    if (config.preciseCoverage) {
        coverageSession = new Session();
        coverageSession.connect();
        await coverageSession.post('Profiler.enable');
        await coverageSession.post('Profiler.startPreciseCoverage', {callCount: true, detailed: true, allowTriggeredUpdates: false});
    }
    let rows = 0;
    let estimatedRows = 0;
    const pipelineStart = performance.now();
    for (currentGroup = 0; currentGroup < groups.length; ++currentGroup) {
        const before = boundary(`before-group-${currentGroup}`);
        const group = groups[currentGroup];
        const sourceBuffers = [];
        for (const bank of group) {
            const bytes = await payloads.read(bank, new AbortController().signal);
            sourceBuffers.push(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
        }
        const parseStart = performance.now();
        const parsed = await parseRequest({type: 'parse', id: currentGroup, version: 3, sourceBuffers, sourceMetadata: group.map(({filename, compressedSize, uncompressedSize, compressionMethod, signature}) => ({filename, compressedSize, uncompressedSize, compressionMethod, signature})), chunkSize: 8192, options});
        const parseMs = performance.now() - parseStart;
        const chunk = parsed.chunk;
        parsed.chunk = null;
        assert(chunk);
        assert.equal(chunk.rowCount, parsed.rowCount);
        // Exact runParallelParserJob parent receipt, before the public sink.
        const ownsContentBytes = parsed.ownsContentBytes === true && parsed.borrowsWorkerMemory !== true && registerOwnedTermContent(chunk?.contentBytesBuffer);
        assert.equal(ownsContentBytes, true);
        assert.equal(chunk.useResolvedContentReferences, true);
        assert.equal(typeof chunk.releaseBorrowedContent, 'undefined');
        assert(chunk.preparedLookupIndexes instanceof Map);
        const {mediaRows, ...columnPayload} = chunk;
        assert.equal(mediaRows.length, 0);
        const groupBytes = group.reduce((sum, bank) => sum + bank.uncompressedSize, 0);
        if (currentGroup === 0) { estimatedRows = Math.max(chunk.rowCount, Math.round(chunk.rowCount * totalBytes / groupBytes)); }
        rows += chunk.rowCount;
        const payload = {...columnPayload, dictionary: index.title, dictionaryTotalRows: currentGroup + 1 === groups.length ? rows : Math.max(rows, estimatedRows), contentDictNameList: null, uniformContentDictName: RAW_TERM_CONTENT_TOKEN_DICT_NAME};
        const sinkStart = performance.now();
        await database.bulkAddArtifactTermsChunk(payload);
        const sinkMs = performance.now() - sinkStart;
        const after = boundary(`after-group-${currentGroup}`);
        // All byte hashing and report work below is outside the sink interval.
        assert(pendingCapture);
        const {source, offsets, lengths, starts, blocks} = pendingCapture;
        pendingCapture = null;
        let lower = source.byteLength;
        let upper = 0;
        for (let index = 0; index < offsets.length; ++index) {
            lower = Math.min(lower, offsets[index]);
            upper = Math.max(upper, offsets[index] + lengths[index]);
        }
        lower -= lower % 8;
        const expectedCapture = oracle.captures[currentGroup];
        const sourceSha256 = sha(source.subarray(lower, upper));
        assert.equal(sourceSha256, expectedCapture.sourceSha256);
        const descriptorHash = createHash('sha256');
        for (const column of [Uint32Array.from(offsets, (offset) => offset - lower), lengths, starts, blocks]) {
            descriptorHash.update(new Uint8Array(column.buffer, column.byteOffset, column.byteLength));
        }
        const descriptorSha256 = descriptorHash.digest('hex');
        assert.equal(descriptorSha256, expectedCapture.descriptorSha256);
        assert.equal(captures.at(-1).spanCount, expectedCapture.spanCount);
        assert.deepEqual(captures.at(-1).blockLengths, expectedCapture.blockLengths);
        const requests = requestOrder.filter((entry) => entry.group === currentGroup);
        const nativeFrameSha256 = requests.map(({id}) => {
            assert(completedBlocks.has(id));
            const hash = sha(new Uint8Array(completedBlocks.get(id)));
            completedBlocks.delete(id);
            return hash;
        });
        assert.deepEqual(nativeFrameSha256, expectedCapture.expectedBlockHashes);
        assert.equal(completedBlocks.size, 0);
        const metrics = {...database._lastBulkAddTermsMetrics};
        assert.equal(metrics.dedupRecentSourceAdoptedBytes, expectedAdoptedBytes[currentGroup]);
        assert.equal(metrics.dedupNativeFallbackCount, 0);
        assert(metrics.dedupNativeCallCount > 0, 'Native canonical scanner must execute');
        for (const name of ['dedupNativeCallCount', 'dedupNativeScannedRows', 'dedupNativeBulkPendingRows', 'dedupNativeExactCandidates']) {
            assert.equal(metrics[name], corrected.groupResults[currentGroup].metrics[name], `Canonical workload changed: ${name}`);
        }
        const registration = registrationCalls.filter((entry) => entry.group === currentGroup);
        assert.equal(registration.length, 1);
        assert.equal(registration[0].rows, expectedCapture.spanCount, 'Registration must cover every actual captured unique span');
        groupResults.push({index: currentGroup, banks: group.map(({filename}) => filename), rows: chunk.rowCount, parseMsDiagnostic: parseMs, sinkMs, registration, before, after, ownsContentBytes, borrowsWorkerMemory: parsed.borrowsWorkerMemory, registeredSourceBytes: chunk.contentBytesBuffer.byteLength, sourceByteOffsetModulo8: chunk.contentBytesBuffer.byteOffset % 8, sourceSha256, descriptorSha256, nativeFrameSha256, metrics});
    }
    assert.equal(rows, fixture.termRows);
    assert.equal(registrationCalls.length, 12);
    const drainStart = performance.now();
    database._termContentBlockImportSession.close();
    database._termContentBlockImportSession = null;
    await Promise.all([database._termContentStore.endImportSession(), database._termRecordStore.endImportSession()]);
    drainMs = performance.now() - drainStart;
    pipelineEnvelopeMs = performance.now() - pipelineStart;
    const finalBoundary = boundary('after-final-drain');
    assert.equal(plannedBlocks, 103);
    if (coverageSession) { coverageProof = await collectCoverageProof(); }
    const allocation = allocationReceipt(database);
    const finalOracle = {persisted: await digestDirectory(env.rootPath), metadata: metadataDigest(database)};
    await saveJson(path.join(output, 'final-output-oracle.json'), finalOracle);
    if (config.expectedFinalOracle) {
        const expectedBytes = await readFile(config.expectedFinalOracle.path);
        assert.equal(sha(expectedBytes), config.expectedFinalOracle.sha256);
        assert.deepEqual(finalOracle, JSON.parse(expectedBytes));
    }
    assert.deepEqual(await sourceReceipt(sourceRoot, config.source.commit), initialSource);
    assert.deepEqual(await fileHashes(evidenceRoot, helperFiles), config.helpers);
    const sinkCallMs = groupResults.reduce((total, group) => total + group.sinkMs, 0);
    const directRegistrationMs = registrationCalls.reduce((total, entry) => total + entry.milliseconds, 0);
    const result = {
        schemaVersion: 1, mode: config.mode, arm: config.arm, round: config.round ?? null, success: true,
        timingEligible: false,
        boundary: 'Noncontiguous aggregate of 12 foreground public sink calls plus final session drain; sequential actual producer, Node OPFS adapter. Diagnostic pipeline envelope includes parsing and oracle gaps. No browser import claim.',
        source: initialSource, helpers: config.helpers, configSha256: sha(configBytes),
        node: process.version, execArgv: process.execArgv, fixtureSha256: fixture.sha256, lockSha256: sha(lockBytes),
        originalOracleSha256: sha(oracleBytes), correctedOracleSha256: sha(correctedBytes),
        rows, totalBytes, parserPolicy: 3, codecWorkers: codecWorkers.length,
        plannedBlocks, compressionRequests, sourceConsumedReplies, compressionReplies, finalBoundary,
        sinkCallMs, drainMs, primaryForegroundSinkAndDrainMs: sinkCallMs + drainMs,
        directRegistrationMs, pipelineEnvelopeMsDiagnostic: pipelineEnvelopeMs,
        groupResults, captures, requestOrder, registrationCalls, coverageProof,
        finalOracle: await fileIdentity(path.join(output, 'final-output-oracle.json')),
        allocation, dictionaryNameRepresentation: dictionaryNameRepresentation(database), prefixPublications, dictionaryNameMaterializations,
        parentAcquisition: config.parentAcquisition,
        initialResources, finalResources: await resources(),
    };
    await saveJson(path.join(output, 'result.json'), result);
    console.log(JSON.stringify({mode: config.mode, arm: config.arm, rows, groups: groupResults.length, frames: compressionReplies, admissionProved: coverageProof !== null, outputParity: Boolean(config.expectedFinalOracle)}));
} catch (error) {
    await saveJson(path.join(output, 'failure.json'), {
        error: String(error?.stack ?? error), mode: config.mode, arm: config.arm, currentGroup,
        groupResults, registrationCalls, captures, requestOrder,
        plannedBlocks, compressionRequests, compressionReplies, sourceConsumedReplies,
        prefixPublications, dictionaryNameMaterializations,
        source: initialSource, helpers: config.helpers, configSha256: sha(configBytes),
        initialResources, finalResources: await resources(),
    });
    throw error;
} finally {
    coverageSession?.disconnect();
    for (const worker of codecWorkers) { worker.terminate(); }
    await Promise.all(codecWorkers.map((worker) => worker.termination));
    database?._termContentBlockImportSession?.close();
    await zip?.close();
    await env?.dispose();
}
