# Uniform dictionary-name metadata prefix

## Scope and evidence

This is an isolated candidate based on develop `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`, in `/home/agent/manabitan-dictname-prefix-4d9ffe79ec6f`. It does not contain the separate constant-S1 prototype. No native source, WASM asset, persistent format, cache capacity, or concurrency setting changes.

The exact dcfc JMdict baseline sink receipt in `../canonical-signatures/sink/correctness-A-1/` has 362,032 allocated dense IDs in a capacity of 524,288. Its dictionary-name ID column is 362,032 words of `1` followed by zero words, SHA-256 `8d7adf4d1a175342f0b75dc05a48eacc9c24e63803296f17491e27b3553d324c`. The baseline allocates 2,097,152 bytes for this column. Twelve native segments produce successive pending ranges, no free indices, and no stored collision entries. Those source and counter observations predict twelve contiguous prefix extensions; the candidate full sink replay must verify that prediction before claiming an actual corpus allocation reduction.

The previously considered Uint8-to-Uint32 widening design was rejected. Replacing a caller-visible dictionary-ID backing before bulk alias validation changes the established scalar feedback through aliased input views. This candidate has no backing to alias while virtual. Once a backing exists, it stays Uint32 and follows the existing scalar write and normal arena-growth behavior.

## State invariants

- While `_termEntryContentMetaDictNameIdTable` is null, numeric indices within the current dense capacity have the prefix value below `PrefixEnd` and zero from there to capacity. The prefix value is stored after normal Uint32 coercion. Invalid numeric indices read as `undefined`.
- Zero writes in the zero tail are no-ops. Writes of the same value inside the prefix or immediately extending it can remain virtual. Any hole or different value materializes the complete logical column before the caller's first metadata write.
- Materialization allocates and fills a private Uint32Array before publishing it. It includes free, rolled-back, and unused logical words. An allocation failure leaves the old representation and metadata words unchanged.
- Physical storage is never compacted again until cache reset. Existing physical alias checks and scalar writes retain their original order. When the physical column grows, its old backing is replaced exactly as before.
- Dense growth copies only through the existing dense high-water mark, including free IDs below it. The virtual prefix is clipped at that mark on growth, matching the previous full table's copy behavior for privately written unused tail values.
- Checked contiguous publication validates the entire range, metadata, and all existing physical aliases before preparing allocation or advancing the prefix. If that check falls back, scalar publication advances only the prefix actually written before a later error.
- The column is not part of the native canonical scanner ABI. Native staging and rollback do not write it. Logical stale values therefore persist exactly as they did in the old external Uint32 column.

## Runtime changes

The sole production change is `ext/js/dictionary/dictionary-database.js`: initialization/reset, the metadata reader, four writer paths, dense growth, and private read/materialize/prepare/write helpers. The checked bulk publication alias inventory omits the absent backing but still includes an existing physical column. A newly materialized backing is private and cannot alias a previously supplied source view.

Existing tests that directly constructed physical aliases now explicitly materialize the column first. Logical snapshot oracles reconstruct the virtual values; the fourteen-allocation dense growth fault test explicitly retains its original physical-allocation coverage. A new focused suite covers normal and scalar publication, coercion, free/stale words, growth/high-water truncation, real allocation and injected hook failures, invalid numeric reads, nonrepresentable holes, and physical alias feedback.

## Qualification status

Normal `build:libs` and the five focused prefix/publication/dedup/growth/native-canonical suites passed on the first attempt under Node 22.22.0: 227 tests, 5 files, zero failures. Targeted ESLint on all five changed files also passed. The unmodified native asset is used by the canonical differential suite. Logs are `build-libs-attempt-1.log`, `focused-attempt-1.log`, and `eslint-attempt-1.log` alongside this document.

The complete current-source JMdict sink comparison then passed on its first acquisition, using clean candidate `5ee2c0c1db0036fb7289952675d315c54c58cce7` against the frozen dcfc parent. All 528,299 rows, twelve groups, 103 codec frames, source slabs/descriptors, native work counts, persisted file bytes, and every logical metadata column match. The final oracle remains SHA-256 `5a2d8167f046e313949af8005ed493b651d10a4de95bfc5a2de24699ec61a58e`.

The physical dictionary-name table stays null. Exactly twelve contiguous prefix fills extend value `1` to end `362032`, with zero materialization calls and capacity `524288`. The unchanged native arena retains 26,214,400 bytes; the separate 2,097,152-byte dictionary-name backing is avoided. Both new representation scalars are explicitly recorded and checked separately; the full logical Uint32 column is reconstructed without any product getter or materializer. Evidence and reproducible source-bound helpers are in `sink/`; the compact comparison is `sink/correctness-B-1-comparison.json`.

This establishes removal of one retained 2 MiB backing on the pinned JMdict sink workload. It does not establish import latency or process peak-memory improvement. Other dictionaries and heterogeneous codec paths may materialize the ordinary column. Broad candidate validation and any combined constant-column PR remain under the root agent's review.
