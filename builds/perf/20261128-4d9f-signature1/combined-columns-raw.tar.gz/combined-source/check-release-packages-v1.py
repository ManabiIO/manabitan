#!/usr/bin/env python3
"""Inspect exact release ZIP entries; this is package evidence, not a speed test."""
import argparse
import hashlib
import json
import pathlib
import subprocess
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--baseline-root", type=pathlib.Path, required=True)
parser.add_argument("--baseline-source", required=True)
parser.add_argument("--candidate-root", type=pathlib.Path, required=True)
parser.add_argument("--candidate-source", required=True)
parser.add_argument("--output", type=pathlib.Path, required=True)
args = parser.parse_args()
if args.output.exists():
    raise SystemExit("Output already exists; retain it and use a new receipt path")
expected = {
    "js/dictionary/dictionary-database.js",
    "js/dictionary/term-content-canonical-scan.js",
    "js/dictionary/term-content-metadata-arena.js",
    "lib/term-content-canonical-scan-v1.wasm",
}
digest = lambda data: hashlib.sha256(data).hexdigest()
def git(root, *argv):
    return subprocess.check_output(["git", "-C", str(root), *argv], text=True).strip()
def inspect(root, source):
    assert git(root, "rev-parse", "HEAD") == source
    assert not git(root, "status", "--porcelain", "--untracked-files=no")
    package_path = root / "builds/manabitan-chrome.zip"
    with zipfile.ZipFile(package_path) as package:
        members = [i.filename for i in package.infolist() if not i.is_dir()]
        assert len(members) == len(set(members)), "Duplicate ZIP entries"
        entries = {p: {"sha256": digest(package.read(p)), "bytes": len(package.read(p))}
                   for p in sorted(members)}
        for p in expected:
            assert package.read(p) == (root / "ext" / p).read_bytes(), p
    wasm = root / "dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm"
    assert entries["lib/term-content-canonical-scan-v1.wasm"]["sha256"] == digest(wasm.read_bytes())
    return {
        "source": source,
        "tree": git(root, "rev-parse", "HEAD^{tree}"),
        "package": {"bytes": package_path.stat().st_size, "sha256": digest(package_path.read_bytes())},
        "lockSha256": digest((root / "package-lock.json").read_bytes()),
        "fixtureLockSha256": digest((root / "test/perf/dictionaries.lock.json").read_bytes()),
        "entries": entries,
    }
a = inspect(args.baseline_root, args.baseline_source)
b = inspect(args.candidate_root, args.candidate_source)
assert set(a["entries"]) == set(b["entries"]), "Package inventory changed"
changed = {p for p in a["entries"] if a["entries"][p] != b["entries"][p]}
assert changed == expected, {"actualChanged": sorted(changed), "expectedChanged": sorted(expected)}
assert a["lockSha256"] == b["lockSha256"]
assert a["fixtureLockSha256"] == b["fixtureLockSha256"]
result = {
    "status": "passed",
    "scope": "Local ordinary release Chrome builds, exact full entry inventory and source-bound changed bytes; no latency or process-memory claim.",
    "baseline": a, "candidate": b,
    "changedEntries": sorted(changed),
    "packageDeltaBytes": b["package"]["bytes"] - a["package"]["bytes"],
    "nativeWasmDeltaBytes": b["entries"]["lib/term-content-canonical-scan-v1.wasm"]["bytes"] - a["entries"]["lib/term-content-canonical-scan-v1.wasm"]["bytes"],
}
args.output.parent.mkdir(parents=True, exist_ok=True)
with args.output.open("x") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
print(json.dumps({k: v for k, v in result.items() if k not in ("baseline", "candidate")}, indent=2))

