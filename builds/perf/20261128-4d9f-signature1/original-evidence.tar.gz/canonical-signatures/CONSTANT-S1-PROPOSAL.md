# Exact constant first-signature representation

## Scope and status

This proposal replaces only the first four-byte rejection signature for content beginning with `MBR6`. It preserves every logical signature word, signed/unsigned candidate distinction, collision ordering, byte comparison, storage read and read failure. It does not implement the earlier full lazy-signature proposal, which root rejected because that proposal could add cold reads for collisions previously rejected by their samples.

Implementation baseline is `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`. The concrete allocation receipt below is from the unchanged earlier `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` full JMdict DB-owner replay. Root confirmed that the intervening merge changes the parser, not these metadata columns. This is an allocation opportunity, not an import-speed or process-peak claim.

## Proven constant receipt

The retained full metadata oracle is `../current-db-profile/lookup-capture-2/final-output-oracle.json`. Its dense count is 362,032 and column capacity is 524,288. Reconstructing 362,032 little-endian `0x3652424d` words (`MBR6`) followed by the zero-filled capacity tail reproduces the complete `_termEntryContentMetaSignature1Table` SHA256 exactly:

`6fed4e642e597cae275a2d1cf84a38569ba214b0ae712a1c37be4e918af5ce5a`

The full signature-present and state columns independently match 362,032 bytes of value 1 followed by zeros. The first-signature column occupies 2,097,152 bytes. This root discovery was independently reconstructed during this source audit. Jitendex/VNDB field-census receipts do not retain these metadata columns, so no whole-corpus constant-column claim is made for them yet.

The same JMdict oracle proves dictionary-name ID 1 for the live prefix, but dictionary-name representation is excluded from this prototype. PR #980 handles the separate Float64 metadata ID column; it does not implement either first-signature or dictionary-name ID elision.

## Representation

- `signaturePresent == 0`: no signature triple; the old first word is still logically retained.
- `signaturePresent == 1`: a complete signature triple whose first word is in the optional external Uint32 column.
- `signaturePresent == 2`: a complete signature triple whose first word is exactly `0x3652424d`; the other two words remain in their current dense columns.

The optional first-word column is owned by the arena generation but is outside its fixed WebAssembly memory. Ordinary MBR6 generations leave it unallocated. Logical first-word reads return the constant for marker 2, the external word when materialized, or zero for a valid untouched slot. Missing or malformed numeric indexes keep their previous undefined result. Candidate readers expose ordinary numeric triples for both marker 1 and marker 2, so the existing rejection and #322 collision logic is unchanged.

Materialization allocates and fills a replacement column before publishing it. It includes every marker-2 slot, including empty/free entries whose former word is retained. Only after successful allocation and filling are marker-2 entries converted to marker 1. Subsequent JS writes use the physical column. An unsigned replacement of an implicit signed entry materializes first, then clears the presence marker, preserving the old unused word. A generic staged rollback retains old words as before. A native synchronous rollback clears the corresponding words to zero as before.

Growing an arena copies a materialized first-word column through the same high-water mark as the other dense columns; an implicit column stays unallocated. Replacement construction and copying complete before DB publication, preserving the existing failed-growth transaction boundary. No new retained source bytes or cache capacity are introduced.

## Native boundary

Keep the legacy `scan_canonical` entry intact and add an explicitly named compact-first-signature entry. The JS wrapper requires the new entry before any native mutation; an old/mismatched asset takes the current JS fallback. The old version/layout exports remain valid because the legacy entry remains compatible. No scratch layout or output-column layout changes.

The compact entry ignores the former first-signature table pointer, stores marker 2 for the actual copied input word equal to MBR6, and marker 1 for every other input word. It writes the second and third words exactly as today. Reserved header word 6 becomes a rare non-MBR6 insertion flag for this entry only.

Immediately after a successful native return, before output adoption, hooks or any await, the JS wrapper materializes if the flag is set or the optional column already exists. Existing output columns already contain each inserted dense index and input unique index. The wrapper reads first words from the native `SIGS` snapshot using those indexes, writes the external column, and converts new markers to 1. This rare path needs no new output buffer, callback or source retention. Ordinary MBR6/null-column calls add no JS row scan. Allocation failure is caught by the existing synchronous journal owner and rolls back the unaccepted segment.

## Writer coverage

All current first-word writers must use the same representation:

1. `_setTermContentSignatures` after an existing storage read.
2. `_writeTermEntryContentMetaHashPairIndex` including unsigned replacement.
3. `_stageArtifactTermContentMetadata` with logical 0–3-byte spans.
4. `_reservePreparedArtifactTermContentMetadata` after native or JS sampling.
5. `_insertTermEntryContentMetaByHashPairFast`.
6. Native canonical staging and its synchronous rollback.

Existing collision-list object signatures remain ordinary numbers and require no representation change. Their multiplicity/order must remain identical, including equal samples on different bytes.

Any rare allocation must occur before a writer increments the dense count, removes a free index, writes hashes/offsets, or publishes a state/slot. Native inserts are the sole exception because their complete synchronous journal already owns rollback.

## Validation gates

Meaningful focused coverage must prove zero optional first-column capacity for MBR6-only writes, exact logical snapshots against the previous representation, short logical spans, MBR5/other nonmagic words, unsigned replacement, same-hash/same-sample collisions, no added storage reads, retained free/unused words, native trap and adoption failures, old-asset fallback, arena growth and allocation failure before publication. Existing metadata/publication/canonical differential tests remain required, followed by repository unit/build/type validation if the prototype survives review.

Source preparation is authorized. Compilation and CPU-heavy tests are coordinated with root. Browser qualification and whole-corpus allocation evidence remain future gates; no PR has been opened for this prototype.
