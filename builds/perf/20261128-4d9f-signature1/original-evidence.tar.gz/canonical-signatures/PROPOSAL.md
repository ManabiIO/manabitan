# Lazy canonical signature columns: source-only proposal

## Decision and smallest useful scope

The ordinary native path can avoid eager sampled-signature columns without weakening exact deduplication. This is not a one-line omission: signature presence currently also distinguishes concrete collision candidates from legacy metadata, and the current native ABI requires the columns even though its probe loop never reads them.

The smallest useful first implementation would retain the existing one-byte signature-state column, make only the three uint32 signature columns lazy, and leave parser-produced `uniqueSignatures` unchanged. The signature-state byte distinguishes legacy metadata, materialized signatures, and concrete source content whose signatures are deferred. Do not pack that marker into the published/pending state in the first version; doing so would change many unrelated state tests and rollback paths.

The prospective saving is therefore **12 bytes per dense capacity entry**, rather than all 13. At capacity 524,288, that is 6,291,456 bytes (6 MiB). Removing the remaining marker would need a separate representation proof. No source has been edited or benchmarked for this proposal.

## What the current source proves

Audited baseline: `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. Root subsequently identified implementation target `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`, which integrates #972. Freeze its relevant database/arena/canonical-source identities before implementation; keep every 9e10 profile and capture labelled with its original source. The following counts remain 9e10 evidence.

- `TermContentMetadataArena` places hash slots, hash pair, state, length, signature-present byte and three signature words into one fixed WASM memory. Arena replacement preserves stable dense IDs and is published only after copying/rehashing succeeds.
- `scan_canonical` reads hashes and state while probing. It **does not read signature words to reject or accept candidates**. It writes the three prepared signature words and `present=1` when staging a new dense entry.
- The adapter copies all unique signature triples into native input scratch before scanning. Missing/short signature input currently selects JavaScript fallback.
- JavaScript candidate selection accepts metadata without signatures and still checks supported representation, length and complete bytes. Both scalar and batched exact matchers use recent owned sources, then in-flight sources, then persisted reads.
- Native and JavaScript exact matching have forced same-hash/same-signature unequal-byte regressions. Samples are rejection filters, never equality witnesses.
- [#322](https://github.com/ManabiIO/manabitan/pull/322) established a separate correctness obligation: `_cacheTermEntryContentMeta` retains distinct same-hash candidates when both metadata entries have signatures. If either is unsigned legacy metadata, it preserves its old replacement behavior. Simply clearing presence would silently change this rule.
- [#676](https://github.com/ManabiIO/manabitan/pull/676) preserves logical 0–3-byte boundaries when sampling. [#743](https://github.com/ManabiIO/manabitan/pull/743) optimizes bounded signature reads. Neither is a lazy-column proposal. Searches for lazy signatures, signature columns, canonical signatures and signature collisions found no exact prior lazy-column implementation.

## Proposed representation

Retain one byte per dense ID with named values:

| State | Meaning | Candidate rejection | Collision-retention identity |
| --- | --- | --- | --- |
| 0 | Legacy metadata without concrete source/signature evidence | No signature rejection | Preserve existing legacy replacement behavior |
| 1 | Three materialized signatures | Existing three-word rejection | Concrete candidate |
| 2 | Concrete source content with deferred signatures | No signature rejection | Concrete candidate |

The last column must be tested separately from whether three numbers exist. A returned metadata object can expose an internal deferred-signature marker for state 2; callers with three explicit numeric signatures remain concrete exactly as today. `_cacheTermEntryContentMeta` should use “both concrete candidates” for its existing append-versus-replace decision. The list order and offset comparison remain unchanged.

This marker describes the existing source-backed candidate identity. It does not authorize equality, retain a mutable source, or allow a hash match to stand in for byte comparison.

### Keep lazy signature arrays outside the native hot memory

The native scanner has no use for these values after eager staging is removed. Make `signature1`, `signature2`, and `signature3` initially shared-empty uint32 arrays owned by the arena object. Allocate all three ordinary JavaScript uint32 arrays into local variables, then publish them together, only when a signature materialization is needed. Rebind the database's three aliases as one synchronous operation. No await or native call may observe a partially allocated set.

This avoids replacing the entire authoritative WASM memory at the first collision. The signature-state byte remains in native memory. `copyFrom` copies the three cold arrays only if the prior arena actually has them; a replacement with a larger dense capacity allocates/copies them atomically when needed. The hash/state/length/slot replacement transaction remains unchanged.

A materialized entry requires all three arrays to cover its dense ID. A deferred entry must never read stale values in those arrays. Reset and rollback clear the marker, and clear words when allocated, before an ID can be reused. Allocation failure leaves the old three arrays and marker unchanged.

The fixed 8 MiB native scratch prefix should remain unchanged in this first version, even though its signature scratch becomes unused by the new route. Do not claim its 1.2 MB SIGS region as an allocation saving.

## Native adapter / compatibility

Add an explicitly discoverable signature-free native entry point or capability; do not call the old entry point with absent columns. The current C validator requires all four signature-related pointers inside its memory, and the current insertion code writes all of them.

One safe shape is a new `scan_canonical_without_signatures` export backed by the same implementation with a fixed mode. Its admission still validates all original row bounds, representative identities, content spans, slots and capacities. It does not validate/read the three unused signature pointers, does not read SIGS scratch, and stages marker 2. The old export keeps its old eager contract for old callers. The adapter uses the new export only after checking its presence and all existing layout/version guards; otherwise it follows the established JavaScript fallback before mutation.

Retain the parser's `uniqueSignatures` production, owned transfer and normal input eligibility in the first implementation. That limits the change to the canonical consumer and its metadata owner. It does not require changing parser WASM or combining this work with #961. The adapter omits only its SIGS copy and the corresponding copied-input-byte metric on the new route.

The generic JavaScript fallback must understand deferred marker 2 and retain complete exact comparisons. A narrow first version may keep generic explicit-signature writers eager for compatibility. That means a generic/legacy fallback can allocate the columns without a true collision; this must be disclosed as a scope limit. If the requirement is universal allocation only after a proved collision, the generic reserve/insert/cache paths must also adopt deferred state, increasing the diff.

## Materialize on unequal bytes, not an ordinary equal duplicate

For an ordinary deferred native candidate:

1. Candidate selection checks hash pair, length and representation as today. Absent signatures do not reject it.
2. Resolve its bytes through the existing recent/in-flight/persisted path, under the existing ownership and read limits.
3. Compare the entire logical content span. A successful equality returns the same reference **without allocating signature arrays**.
4. If complete byte comparison fails, allocate the cold columns if necessary and sample the existing candidate's stable bytes into its three words. Publish state 1 only after the words are written. Incoming content still follows the existing resolution/publication path; if it becomes a collision-list entry, that object's signature triple can be computed from its already-live source.

The recent-cache and in-flight branches currently return/continue without sampling; they need the mismatch hook. The persisted-read branches currently call `_setTermContentSignatures` before comparing; for deferred state they must compare first and materialize only on mismatch. Legacy unsigned metadata retains the old upgrade/replacement semantics, or must receive its concrete-identity marker independently of lazy allocation. Do not accidentally redefine legacy behavior by treating every old entry as a native producer entry.

No whole source is retained for this change. Source byte views are consumed synchronously while their existing owner is live. A persisted read adds no new source lifetime. After an await, obtain the current arena/arrays and verify that the intended published metadata identity still owns the dense slot before learning into it; do not cache writable arena views across the read.

### Same-batch pending collisions are a separate path

`scan_canonical` can find a same-hash pending entry and append an unreserved pending output. Later `_publishArtifactTermContentMetadata` routes that value to `_appendStagedTermEntryContentMetaCollision`; it does not pass through the persisted exact matcher. The existing method's contract is “parser-verified distinct value.” Such a producer has already proved unequal canonical bytes before giving the values distinct unique IDs.

The implementation must explicitly cover this path. Where the accepted producer supplies that established exact-distinctness proof, the collision publication can activate lazy storage and sample any still-live source spans already available through the publication arguments or existing in-flight map. Preserve the collision entry object and order even if the primary's source is no longer immediately accessible. It can remain deferred and be learned at its next actual exact comparison; do not introduce a new source read or retention solely to fill the sample.

For a generic/unwitnessed plan, a raw hash-pair match or different numeric unique IDs alone must not be relabeled a fresh byte-inequality proof. Retain its established generic path, or perform exact comparison using the already-owned spans before activating the optimization. This is the main producer-provenance edge to settle in implementation review. It does not justify skipping or coalescing collision entries.

## Collision cost that cannot be eliminated

The first equal-length hash collision against cold persisted content may now require a read that eager signatures would have rejected. Exact bytes are the only available proof once the samples have been omitted. Later comparisons can use learned signatures. This is a real tradeoff, not a correctness problem, and it needs a forced-collision read-count control.

Batched candidate lists are built before some comparisons/reads occur. Learning during a wave does not automatically update other already-created metadata objects. Do not claim that one learned triple instantly eliminates all reads in that wave. Keeping the original bounded wave/read scheduling is the smallest implementation; invalidating/restarting candidate lists is separate complexity and should be avoided unless a concrete adversarial regression requires it.

The three sampled words themselves do not defend against equal-sample collisions: #322 and the canonical scanner's tests explicitly exercise those. Complete byte comparison and collision multiplicity remain mandatory in every version.

## Concrete current JMdict work

Source-bound actual sink capture: `experiments/current-db-profile/lookup-capture-2/result.json`, source 9e10, 12 native calls, zero native fallback. It reports 366,030 scanned representatives, 362,032 native pending entries, 3,998 exact candidates, and 3,998 persisted/recent exact matches. Thus no signature rejection occurred among its native candidates.

| Quantity | Existing work | First lazy version |
| --- | ---: | ---: |
| Unique signature triples copied to native scratch | 4,392,360 B | 0 B on new native route |
| Three dense signature words stored for new pending entries | 4,344,384 B | 0 B without collisions |
| Per-entry marker stores | 362,032 B | Unchanged; marker becomes deferred |
| Dense signature allocation at capacity 524,288 | 6,291,456 B for three words | 0 B until lazy activation |
| Producer-owned signature triples | 4,392,360 B across groups | Unchanged in first version |

Capacity 524,288 is the next power of two above the observed dense count, not a sampled-process memory result. Verify actual arena capacities in a source-bound diagnostic before publishing an allocation claim. Growth copies may also decrease; no total is claimed without observing every replacement. The first version removes 8,736,744 bytes of identified copy/store work in this capture, plus possible growth work. It does not remove full-content hashing or exact equality.

## Comparison with canonical identity/row-input packing

The same actual capture accounts for these adapter inputs:

| Input | Bytes |
| --- | ---: |
| META: four words per source row | 8,452,784 |
| IDENT: source-row unique IDs | 2,113,196 |
| ROWS: representative row IDs | 1,464,120 |
| SIGS: three words per unique | 4,392,360 |
| FLAGS | 366,030 |
| Total | 16,788,490 |

A row/identity packing change can have a smaller compatibility surface because it need not alter candidate identity or optional persistent metadata. It must preserve representative validation/error order, especially the rule that rows beyond an exact-match batch are not validated before its await. Gathering META by unique ID could save copy bytes but add JavaScript per-row work; contiguous `.set` is not equivalent to a gather. Signature laziness has the clearer retained-allocation benefit, but more collision and fallback obligations. Measure the two designs separately if both pass review.

## Required correctness / resource gates before timing

- Same hash, unequal sampled bytes; same hash and same samples with unequal unsampled bytes; several collision entries and stable ordering.
- Pending same-batch collision, published collision, repeated equal duplicates, legacy unsigned replacement, and mixed legacy/deferred/materialized metadata.
- Recent owned source, borrowed in-flight source, cold persisted read, unsupported content representation, 0–3-byte and empty content.
- No allocation on an ordinary equal duplicate in the deferred path; allocation failure atomicity; arena growth/copy; rollback followed by ID reuse; stale metadata after awaited reads; native trap and output-adoption failure.
- Missing old-native capability selects JavaScript before mutation; old eager native callers retain their contract; all full persisted-content/record/lookup oracles match.
- Allocation/copy diagnostics separate from uninstrumented timing, with complete fixed controls. A memory-work result may justify review without a latency claim, but it must use observed capacities and distinguish requested bytes from browser RSS/PSS.
