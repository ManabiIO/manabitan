// Prepared source diagnostic only; not a production implementation or timing test.
// Usage: node dict-name-width-counterexample.mjs /path/to/current-dcfc-checkout
import path from 'node:path';
import {pathToFileURL} from 'node:url';

const root = process.argv[2];
if (!root) { throw new Error('Pass the baseline checkout path'); }
const {DictionaryDatabase} = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/dictionary-database.js')).href);

function fixture(narrow, shifted) {
    const db = new DictionaryDatabase();
    const source = Uint8Array.from({length: 16}, (_, i) => i + 1);
    const staged = db._stageArtifactTermContentMetadata(
        new Uint32Array([10, 11, 12, 13]),
        new Uint32Array([20, 21, 22, 23]),
        [],
        {buffer: source, offsets: new Uint32Array([0, 4, 8, 12]), lengths: new Uint32Array([4, 4, 4, 4])},
    );
    if (narrow) {
        // Model only the proposed initial byte column, retaining logical values.
        db._termEntryContentMetaDictNameIdTable = new Uint8Array(db._termEntryContentMetaDictNameIdTable);
    }
    const originalIds = db._termEntryContentMetaDictNameIdTable;
    const order = shifted ? [2, 1, 3] : [0, 1, 2];
    const indexes = new Int32Array(originalIds.buffer, originalIds.byteOffset + (shifted ? 4 : 0), 3);
    indexes.set(order);
    staged.indexes = indexes;
    db._termEntryContentMetaDictNameIdByValue.set('raw', 256);
    db._termEntryContentMetaDictNames[256] = 'raw';
    if (narrow) {
        // Model atomic promotion at ID preparation, before publication sees inputs.
        db._termEntryContentMetaDictNameIdTable = new Uint32Array(originalIds);
    }
    const state = {
        count: 3,
        contentOffsets: new Float64Array(3),
        contentLengths: new Uint32Array(3),
        resolvedContentDictNames: 'raw',
        pendingRowToUniqueIndex: new Int32Array([0, 1, 2]),
        pendingContentBytes: order.map((i) => source.slice(i * 4, i * 4 + 4)),
        pendingContentHash1s: Uint32Array.from(order, (i) => 10 + i),
        pendingContentHash2s: Uint32Array.from(order, (i) => 20 + i),
        pendingOffsets: new Float64Array([100, 104, 108]),
        pendingLengths: new Uint32Array([4, 4, 4]),
        pendingResolvedDictNames: 'raw',
        pendingContentSpans: null,
        stagedContentMetadata: staged,
    };
    const originalTry = db._tryPublishContiguousArtifactTermContentMetadata.bind(db);
    let accepted = null;
    db._tryPublishContiguousArtifactTermContentMetadata = (...args) => (accepted = originalTry(...args));
    let error = null;
    try { db._publishArtifactTermContentMetadata(state); } catch (value) { error = String(value); }
    return {
        narrowThenPromote: narrow,
        shifted,
        accepted,
        error,
        stagedInputAfter: [...indexes],
        pendingCount: db._termEntryContentMetaHashPairPendingCount,
        publishedCount: db._termEntryContentMetaHashPairCount,
        denseCount: db._termEntryContentMetaDenseCount,
        logicalStates: [...db._termEntryContentMetaStateTable],
    };
}

process.stdout.write(JSON.stringify({
    scope: 'Source-model alias diagnostic, not a production candidate or benchmark',
    cases: [false, true].map((shifted) => ({
        unchangedWide: fixture(false, shifted),
        proposedPromotionModel: fixture(true, shifted),
    })),
}, null, 2) + '\n');
