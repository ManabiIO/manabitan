# Independent source review — implicit first content signature

Reviewed commit: `df25b497c46d79e72d1cd3b52589e31ade24b35a`, based on current `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`. This review covered the four runtime source changes and the new focused tests; it did not run another benchmark or duplicate the author's test run. The initial cloud drafts were reviewed first and one source-alias ordering problem was corrected before this commit.

## Findings

No remaining correctness blocker was found in the reviewed commit.

- The native compact entry keeps h[0] journal publication before authoritative mutation. It records a non-MBR6 insertion in reserved h[6]. JS restores physical first words from the copied SIGS scratch and OUT unique/staged columns before hooks, adoption or awaits. Nonzero first index, skipped resolved rows and same-pair pending collisions do not disturb that mapping.
- A native failure/trap or synchronous output/adoption failure clears first words along with the other newly inserted suffix fields and rewinds dense/pending counters. When allocation failed before a physical column existed, clearing presence makes the logical word zero. Generic staged rollback retains old words, preserving its separate existing semantics.
- Presence marker 2 is a signed triple whose first word is exactly MBR6. A physical column can coexist with presence marker 2. Materialization visits all capacity slots, including empty/free slots, but leaves every arena byte unchanged. This preserves accepted arena-backed byte views and stale words.
- Signed-to-unsigned replacement materializes before setting a presence marker 2 slot to 0, including reuse of a free/rolled-back slot. The old first word therefore remains available physically even when the new metadata is unsigned. Same-pair signed collision retention and exact-byte comparisons remain unchanged.
- Once the physical column exists, every later native insertion is patched, including MBR6 rows; no stale nonmagic physical word survives beneath a newly normalized presence marker 1 marker.
- Replacement arena construction copies the allocated dense high-water prefix, including reusable empty IDs. Publication remains after all new column allocation/copy/rehash work. The optional first-word column is outside fixed native memory and does not detach old views.
- The original scan_canonical export keeps its original pointer/marker contract. New JS requires the explicit new entry and returns the existing unsupported/ABI fallback before scanning an old-only module. The reserved ABI slot and native source/manifest/module are updated together.
- Generic span and fast writers now sample all three input words before the new allocation point or metadata mutation. The prepared-signature path already has all three scalars, and the native path uses its pre-call snapshot.

## Issue corrected during review

The initial materializer converted all presence marker 2 entries to 1 while creating the optional array. That bulk mutation could change a valid byte view into arena memory between the generic writer's S1 and S2/S3 reads. The reviewed commit instead leaves existing markers unchanged and fills only the new external column. The new test explicitly asserts byte-for-byte unchanged arena memory during materialization. Generic writers also pre-sample the three words. This resolves the identified new alias edge.

## Validation scope reviewed

The author reports 244 passing focused tests, including 31 new cases. The new source covers allocation failure, post-materialization adoption failure, native trap rollback, nonzero-range exception mapping, copied-signature provenance, stale physical and implicit slots, unsigned replacement, growth, logical short-span padding, UInt32 coercion, old-module fallback and exact collision reads. These test sources were inspected in this review. Actual three-corpus output/memory and timing evidence remains a separate gate; this source review does not establish performance or browser memory qualification.
