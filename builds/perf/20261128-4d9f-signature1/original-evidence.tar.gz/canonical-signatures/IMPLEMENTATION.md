# Constant MBR6 first-signature prototype

## Current implementation

The prototype is committed locally on `perf/implicit-mbr6-signature1-4d9ffe`, with exact source/tree/file identities in `source-and-focused-receipt.json`. Its base is current develop `dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16`. The full Git binary patch is retained beside this note so loss of the temporary worktree does not lose source or the regenerated native asset. No remote branch or PR has been published for this prototype.

The first signature is a four-byte rejection sample. Every live entry in the retained complete JMdict metadata oracle has the value `0x3652424d` (`MBR6`). The prototype stores that exact value implicitly while leaving the other two samples and every candidate filter/read/byte-comparison path intact. The earlier proposal to defer all three signatures was rejected and is not part of this change.

## Revised representation invariants

- Marker 0 means unsigned metadata. A prior first word can remain in the physical column and must be retained after unsigned replacement.
- Marker 1 means a signed triple whose first word is physical.
- Marker 2 means a signed triple whose first word is exactly MBR6. This marker remains valid both before and after physical materialization.
- The optional first-word array is outside the fixed native memory. It starts null. Materialization fills every marker-2 slot, including empty/free entries, before publishing the new array. It does **not** mutate presence markers or any other arena bytes; accepted source views can alias them.
- Later per-entry writes normalize only the entry they already change. Generic span/fast writers capture all three input sample words before allocation or metadata mutation. Unsigned replacement materializes first when its existing marker is 2, including reuse of an empty/free ID.
- Generic staged rollback retains old signature words. Native synchronous rollback clears its new words to zero. Growth copies through the existing dense high-water mark; it preserves free/unused logical values and an implicit column remains null.

The native module retains its original entry and adds `scan_canonical_implicit_signature1`. The JS adapter requires the new export before native mutation, preserving old-asset JS fallback. Reserved header word 6 flags a non-MBR6 insertion; existing output columns map inserted indexes to the native SIGS snapshot. The adapter restores physical first words before any hook, adoption or await whenever the flag is set or the optional column already exists. Ordinary MBR6-only/null-array segments add no JS row scan.

## Exact allocation and artifact results

`allocation-receipt-1.json` instantiates the old and new arena classes and records backing lengths, with no timing claim. At the observed JMdict dense capacity 524,288 and hash-slot capacity 1,048,576, native backing decreases from 26,214,400 to 24,117,248 bytes while the optional column is null: **2,097,152 bytes saved**.

The complete prior JMdict metadata oracle is `../current-db-profile/lookup-capture-2/final-output-oracle.json`, on frozen source `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. Its 362,032 live MBR6 words plus zero capacity tail reproduce the full S1 hash `6fed4e642e597cae275a2d1cf84a38569ba214b0ae712a1c37be4e918af5ce5a`. Current dcfc full-owner replay remains a separate qualification gate. Jitendex/VNDB census artifacts do not retain their complete signature columns, so no full-corpus constant-column claim is made for them yet.

Fallback resource accounting includes the external array. Page rounding can add or save less than one 65,536-byte page compared with the old integrated layout: measured extra backing is 64 bytes at dense capacity 16, 68 bytes at 17, and 1,024 bytes at 256; capacity 2,048 saves 57,344 bytes; capacities 16,384 and 524,288 cancel exactly after materialization. This is not an allocation-neutral claim for every fallback capacity.

Pinned Clang/LLD 21.1.8 rebuilt the canonical module from 1,624 to 2,082 bytes (+458). Its new SHA256 is `d629347973c6d7eb98a1125302dd4713e22a5d0a7059b25dd2c2ee37d3e3baf0`. The parser module remained byte-identical to the dcfc baseline. Normal `build-libs` copied the regenerated canonical module into the extension; the packaged and vendored bytes agree.

## Validation and outstanding gates

Seven focused suites passed **244/244 tests**, including 31 new cases. The coverage includes logical 0–3-byte spans, MBR5/nonmagic and Uint32 coercion, unused/free-word preservation, materialization alias safety, ordinary null-array allocation, same-hash/same-sample collision order and byte reads, no extra cold read on signature rejection, nonzero native unique ranges with resolved rows/pair collisions, native physical overwrite of a stale word, trap/materialization/adoption rollback, and old-entry-only asset fallback.

The first run passed the 213 existing cases but exhausted a test worker's 2 GiB heap while Vitest deeply enumerated an 8 MiB typed-array equality assertion in the new suite. That failed log is retained. The assertion now compares all bytes with a bounded predicate, and the complete seven-file set passed on retry. No import experiment is attributed to that test failure.

Full repository unit/build/type/lint gates, independent source review and exact current-source JMdict DB-owner output/logical-column parity remain outstanding. Root owns that next qualification. There is no import-speed or process-peak claim, and publication remains contingent on a worthwhile reviewed gain.
