# Separate dictionary-name ID width audit

## Recommendation

Defer a Uint8-to-Uint32 dictionary-name ID column under the current supported alias contract. The normal-path mechanism is small and the allocation opportunity is real, but promotion changes backing identity while the publication owner explicitly supports caller input views that alias that backing. Preserving only numeric stored values is insufficient to preserve those scalar read/write effects. No production edit or new timing experiment was made for this idea.

The captured JMdict dictionary-name ID column is 362,032 words of value 1 followed by zero tail at capacity 524,288; the complete SHA256 is `8d7adf4d1a175342f0b75dc05a48eacc9c24e63803296f17491e27b3553d324c`. A byte column would save 1,572,864 bytes at that capacity. This is a source/receipt-derived opportunity, not measured end-to-end memory or timing evidence.

## Exact sites

The audited database source is unchanged between frozen 9e10 and current dcfc. All seven lifecycle/write sites are in `ext/js/dictionary/dictionary-database.js`:

1. Constructor initializes an empty Uint32 column.
2. `_clearTermEntryContentMetaCaches` resets that column.
3. `_writeTermEntryContentMetaHashPairIndex` interns a name, then writes one ID.
4. `_resizeTermContentMetadataArena` allocates/copies the column and publishes the replacement only after all replacement work succeeds.
5. `_insertTermEntryContentMetaByHashPairFast` accepts a direct dictionary-name ID argument and writes it for a new entry. It does not itself intern that argument.
6. `_tryPublishContiguousArtifactTermContentMetadata` accepts a direct ID and bulk-fills a checked contiguous range.
7. `_publishArtifactTermContentMetadata` writes staged IDs in its scalar fallback, using either a cached uniform ID or a per-row interner result.

Native canonical code does not read or write this column. `_internTermEntryContentMetaDictName` is an ID producer; cached Map values can exceed 255 independently of the array width. Guarding only newly interned names therefore misses cached IDs and both direct numeric call paths.

## Small mechanism, absent aliases

Start/reset with Uint8 storage. Before every actual write, compute `id >>> 0` and promote when that stored value exceeds 255. This preserves the former Uint32 coercion for negative, fractional, nonfinite and >2^32 numeric inputs rather than treating the raw argument as a new validation rule. Allocate and copy a full Uint32 replacement before publishing its field; retain that width until reset. Growth follows the current width and copies the existing dense high-water mark, including free/stale entries.

Promotion must happen before a new entry is removed from the free list, increments the dense count, changes hashes/offsets or publishes state. Existing single-entry publication already has a failure owner for index allocation; it must remain coherent on failure. Bulk publication must finish its existing bounds, alias and complete-row validation before any promotion or mutation. These ordinary mechanics are roughly 40–60 lines plus tests.

## Why the alias case is different

PR #837 introduced the current publication fast path with an explicit condition: all inputs remain unchanged until all bulk writes finish, and overlapping inputs use the scalar loop to retain its original partial-publication and error behavior. The current test `dictionary-content-publication-range.test.js` includes both reservation indexes sharing the dictionary-ID backing and output offset/dictionary-ID ranges sharing storage.

A promotion in the interner, before `_tryPublishContiguousArtifactTermContentMetadata`, replaces the target backing before that helper tests aliases. A staged-index view into the original dictionary-ID buffer then appears independent of the replacement. The existing alias witness is erased and the helper can accept a request it previously rejected.

Moving promotion after the alias check only fixes the bulk-admission decision. In the scalar fallback, writes to the replacement still stop affecting the caller's original view. A shifted staged-index view can depend on an earlier dictionary-ID write changing a later index; the original scalar code deliberately preserves that interleaving. Merely retaining the old target for comparison does not preserve those effects.

The source counterexample in `dict-name-width-counterexample.mjs` uses the actual existing private publication methods and a cached ID of 256. It compares the unchanged wide owner with a model of proposed byte storage followed by promotion. It includes the existing aligned-index alias and a shifted index view whose later scalar input can be overwritten by the first dictionary-ID write. The script is a prepared diagnostic and has **not been executed** during this source-only assignment. It is not a production candidate or performance test.

Preserving arbitrary accepted overlapping views through width promotion would require remapping/write-through machinery or an explicit narrower alias contract. Neither belongs in a small allocation-only change without a separate correctness justification. Ordinary pinned imports do not establish that the generic alias behavior can be discarded.

## Prior overlap

Searches for metadata Uint8/narrowing and dictionary-name ID columns did not identify an exact previous proposal. [#980](https://github.com/ManabiIO/manabitan/pull/980) is the separate implicit-zero Float64 metadata ID column. [#837](https://github.com/ManabiIO/manabitan/pull/837) is the relevant alias/partial-publication behavior. [#947](https://github.com/ManabiIO/manabitan/pull/947) verifies #942's deferred per-unique resolution columns, not this dictionary-name metadata column.

This idea remains separate from the frozen, independently qualifying constant-S1 prototype.
