import assert from 'node:assert/strict';
import {mkdir, readFile} from 'node:fs/promises';
import path from 'node:path';
import {
    baselineRoot, baselineCommit, candidateRoot, sourceReceipt, evidenceRoot,
    helperFiles, fileHashes, fileIdentity, originalOraclePath, correctedOraclePath, saveJson,
} from './common.mjs';

const arm = process.argv[2];
assert(['A', 'B'].includes(arm));
const candidateCommit = process.argv[4];
if (arm === 'B') { assert(/^[0-9a-f]{40}$/.test(candidateCommit)); }
const output = path.join(evidenceRoot, process.argv[3]);
await mkdir(output);
const source = await sourceReceipt(arm === 'B' ? candidateRoot : baselineRoot, arm === 'B' ? candidateCommit : baselineCommit);
const parent = await sourceReceipt(baselineRoot, baselineCommit);
assert.equal(source.identity['ext/lib/zstd-wasm.js'], parent.identity['ext/lib/zstd-wasm.js']);
assert.equal(source.identity['dev/lib/zstd-wasm.js'], parent.identity['dev/lib/zstd-wasm.js']);
assert.equal(source.identity['ext/lib/zstd.wasm'], parent.identity['ext/lib/zstd.wasm']);
assert.equal(source.identity['ext/lib/term-bank-parser.wasm'], parent.identity['ext/lib/term-bank-parser.wasm']);
const runtimeChanges = ['ext/lib/term-bank-parser.wasm'];
if (arm === 'B') {
    runtimeChanges.push(
        'ext/js/dictionary/dictionary-database.js',
        'ext/js/dictionary/term-content-canonical-scan.js',
        'ext/lib/term-content-canonical-scan-v1.wasm',
    );
}
const expectedRuntimeChanges = Object.fromEntries(runtimeChanges.map((file) => [file, source.identity[file]]));
const finalOraclePath = path.resolve(evidenceRoot, '../../current-db-profile/upstream-830/20261128-inflight-validation-830/cohort-1/round-01-A/final-output-oracle.json');
const config = {
    schemaVersion: 1, arm, mode: 'correctness', output, preciseCoverage: false,
    source, parent, expectedRuntimeChanges, helpers: await fileHashes(evidenceRoot, helperFiles),
    oracles: {
        original: (await fileIdentity(originalOraclePath)).sha256,
        corrected: (await fileIdentity(correctedOraclePath)).sha256,
    },
    expectedFinalOracle: {path: finalOraclePath, ...await fileIdentity(finalOraclePath)},
    protocol: JSON.parse(await readFile(path.join(evidenceRoot, 'protocol.json'), 'utf8')),
};
await saveJson(path.join(output, 'config.json'), config);
console.log(path.join(output, 'config.json'));
