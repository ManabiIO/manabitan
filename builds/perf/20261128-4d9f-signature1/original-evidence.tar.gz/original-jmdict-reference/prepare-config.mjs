import {mkdir} from 'node:fs/promises';
import path from 'node:path';
import {baselineRoot, baselineCommit, sourceReceipt, evidenceRoot, helperFiles, fileHashes, fileIdentity, originalOraclePath, correctedOraclePath, saveJson} from './common.mjs';
const output = path.join(evidenceRoot, process.argv[2]);
await mkdir(output);
const config = {schemaVersion: 1, arm: 'A', mode: 'profile', output, preciseCoverage: false,
source: await sourceReceipt(baselineRoot, baselineCommit), helpers: await fileHashes(evidenceRoot, helperFiles),
oracles: {original:(await fileIdentity(originalOraclePath)).sha256, corrected:(await fileIdentity(correctedOraclePath)).sha256},
expectedFinalOracle: {path:path.join(evidenceRoot,'upstream-830/20261128-inflight-validation-830/cohort-1/round-01-A/final-output-oracle.json'), ...await fileIdentity(path.join(evidenceRoot,'upstream-830/20261128-inflight-validation-830/cohort-1/round-01-A/final-output-oracle.json'))}};
await saveJson(path.join(output,'config.json'),config);
console.log(path.join(output,'config.json'));
