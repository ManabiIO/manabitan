import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {fileIdentity, sources} from './common.mjs';

const [aDirectory, bDirectory, output] = process.argv.slice(2).map(value => path.resolve(value));
assert(aDirectory && bDirectory && output);
const read = async (directory, file) => JSON.parse(await readFile(path.join(directory, file), 'utf8'));
const [a, b] = await Promise.all([read(aDirectory, 'result.json'), read(bDirectory, 'result.json')]);
assert(a.success && b.success && !a.timingEligible && !b.timingEligible);
assert.equal(a.arm, 'A'); assert.equal(b.arm, 'B');
assert.equal(a.source.commit, sources.A.commit); assert.equal(b.source.commit, sources.B.commit);
assert.equal(a.corpus, b.corpus);
for (const key of ['fixture', 'lockSha256', 'node', 'execArgv', 'helperIdentity', 'policy',
    'rows', 'mediaRows', 'totalBytes', 'bankCount', 'archiveCatalog', 'archiveEntryCount', 'manifestSha256',
    'compression', 'indexWorker', 'summary', 'actualIndexBytes', 'actualContentBytes', 'actualAllFilesBytes',
    'files', 'sourceChecks', 'chunks']) { assert.deepEqual(b[key], a[key], `Parent/candidate ${key}`); }
assert.equal(a.groupResults.length, b.groupResults.length);
const allocation = [];
for (let index = 0; index < a.groupResults.length; ++index) {
    const ag = a.groupResults[index];
    const bg = b.groupResults[index];
    const withoutDiagnostics = ({memory, signatureAllocation, ...rest}) => rest;
    assert.deepEqual(withoutDiagnostics(bg), withoutDiagnostics(ag), `Complete group ${index} source/sink oracle`);
    for (const key of ['arenaWasAllocated', 'denseCount', 'capacity', 'hashSlots']) { assert.equal(bg.signatureAllocation[key], ag.signatureAllocation[key], `Group ${index} allocation ${key}`); }
    allocation.push({group: index, parent: ag.signatureAllocation, candidate: bg.signatureAllocation,
        ownedBytesAvoided: ag.signatureAllocation.ownedArenaAndSignature1Bytes - bg.signatureAllocation.ownedArenaAndSignature1Bytes});
}
if (a.corpus === 'vndb') {
    for (const key of ['sha256', 'sourceCommit', 'groupsMatched', 'mediaRows', 'projectedPaths', 'uniqueImagePaths',
        'repeatedProjectedReferences', 'projectedPathDigest', 'uniqueImagePathsSha256', 'allGroupsAndProjectedPathsMatch']) {
        assert.deepEqual(b.mediaOracle[key], a.mediaOracle[key], `Independent media oracle ${key}`);
    }
}
const [aOracle, bOracle] = await Promise.all([read(aDirectory, 'final-output-oracle.json'), read(bDirectory, 'final-output-oracle.json')]);
assert.deepEqual(bOracle, aOracle, 'Every normalized persisted file and every independently decoded logical metadata column');
const [aOracleIdentity, bOracleIdentity] = await Promise.all([
    fileIdentity(path.join(aDirectory, 'final-output-oracle.json')),
    fileIdentity(path.join(bDirectory, 'final-output-oracle.json')),
]);
assert.deepEqual(aOracleIdentity, a.finalOracle);
assert.deepEqual(bOracleIdentity, b.finalOracle);
assert.deepEqual(bOracleIdentity, aOracleIdentity);
const result = {
    schemaVersion: 1, success: true, timingEligible: false, corpus: a.corpus,
    parent: {directory: aDirectory, commit: a.source.commit},
    candidate: {directory: bDirectory, commit: b.source.commit},
    rows: a.rows, groups: a.groupResults.length, fixture: a.fixture, node: a.node,
    exactParserOutputsAndLookupPayloads: true, exactRecordFieldsAndEnvelopes: true,
    exactNormalizedFinalFileBytes: true, exactIndependentLogicalMetadata: true,
    finalOutputOracle: aOracleIdentity,
    persistedFiles: aOracle.persisted.files,
    generationLinkageVerified: aOracle.persisted.generationLinkageVerified,
    logicalMetadataColumns: Object.keys(aOracle.metadata),
    compression: a.compression, indexWorker: a.indexWorker,
    parentAllocation: a.signatureAllocation, candidateAllocation: b.signatureAllocation,
    finalOwnedBytesAvoided: a.signatureAllocation.ownedArenaAndSignature1Bytes - b.signatureAllocation.ownedArenaAndSignature1Bytes,
    candidateNullPhysicalSignature1EveryGroup: b.nullPhysicalSignature1EveryGroup,
    perGroupAllocation: allocation,
    limitations: ['Sequential production-group term-sink replay, not concurrent browser import timing.',
        'Final owned-array/native-memory accounting is not browser peak or settled memory.',
        'Media projection/reference coverage is checked; separate media persistence, UI, SQLite, restart and lookup remain outside this boundary.'],
};
await writeFile(output, `${JSON.stringify(result, null, 2)}\n`, {flag: 'wx'});
console.log(JSON.stringify({success: true, corpus: result.corpus, rows: result.rows, groups: result.groups,
    finalOutputOracle: result.finalOutputOracle.sha256, finalOwnedBytesAvoided: result.finalOwnedBytesAvoided,
    candidateNullPhysicalSignature1EveryGroup: result.candidateNullPhysicalSignature1EveryGroup}));
