import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createReadStream} from 'node:fs';
import {readFile, statfs} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

export const evidenceRoot = path.dirname(fileURLToPath(import.meta.url));
export const frozenRoot = '/workspace/scratch/4d9ffe79ec6f/manabitan';
export const frozenCommit = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2';
export const priorEvidenceRoot = path.resolve(evidenceRoot, '../../experiments/record-reference-table');
export const sources = {
    A: {root: '/home/agent/manabitan-current-4d9ffe79ec6f', commit: 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16'},
    B: {root: '/home/agent/manabitan-signature1-4d9ffe79ec6f', commit: '232de57c6fd78ef1115d6db97d2ac5bb2c224417'},
};
export const nodeSha256 = '1bec56ef7cfa9a76f3e0b7c0a87f220eb73f23102b9c0b4c7529a3f7c3ce7c31';
export const sourceFiles = [
    'dev/lib/zstd-wasm.js', 'package-lock.json',
    'test/fixtures/opfs-continuation/node-opfs-adapter.mjs',
    'ext/js/dictionary/term-bank-wasm-parser.js',
    'ext/js/dictionary/term-bank-wasm-parser-worker.js',
    'ext/js/dictionary/term-bank-source-pipeline.js',
    'ext/js/dictionary/dictionary-database.js',
    'ext/js/dictionary/dictionary-importer.js',
    'ext/js/dictionary/term-content-ownership.js',
    'ext/js/dictionary/term-content-opfs-store.js',
    'ext/js/dictionary/term-record-opfs-store.js',
    'ext/js/dictionary/term-content-block-envelope.js',
    'ext/js/dictionary/term-bank-experiments.js',
    'ext/js/dictionary/raw-term-content.js',
    'ext/js/dictionary/zstd-term-content-compression-worker.js',
    'ext/js/dictionary/term-content-canonical-scan.js',
    'ext/js/dictionary/term-content-metadata-arena.js',
    'ext/js/dictionary/term-content-block-store.js',
    'ext/js/dictionary/zstd-term-content.js',
    'ext/js/dictionary/wasm/term-bank-parser.c',
    'ext/js/dictionary/wasm/term-bank-inflate.c',
    'ext/js/dictionary/wasm/term-content-canonical-scan-v1.c',
    'ext/js/dictionary/dense-zip-directory.js',
    'ext/js/dictionary/dense-zip-file-map.js',
    'ext/js/dictionary/dense-zip-filenames.js',
    'dev/data/dictionary-wasm/manifest.json',
    'dev/data/dictionary-wasm/term-bank-parser.wasm',
    'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm',
    'ext/lib/term-bank-parser.wasm',
    'ext/lib/term-content-canonical-scan-v1.wasm',
    'ext/lib/zstd-wasm.js', 'ext/lib/zstd.wasm', 'ext/lib/zstd-dicts/jmdict.zdict',
    'ext/lib/zip.js',
];
const mergedParserChanges = new Set([
    'ext/js/dictionary/wasm/term-bank-parser.c',
    'dev/data/dictionary-wasm/manifest.json',
    'dev/data/dictionary-wasm/term-bank-parser.wasm',
    'ext/lib/term-bank-parser.wasm',
]);
const signatureChanges = new Set([
    'ext/js/dictionary/dictionary-database.js',
    'ext/js/dictionary/term-content-canonical-scan.js',
    'ext/js/dictionary/term-content-metadata-arena.js',
    'ext/js/dictionary/wasm/term-content-canonical-scan-v1.c',
    'dev/data/dictionary-wasm/manifest.json',
    'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm',
    'ext/lib/term-content-canonical-scan-v1.wasm',
]);
const regeneratedZipCommentDelta = {
    file: 'ext/lib/zip.js',
    frozenSha256: 'd41cfb9b932267ebb9d018b5f77f3b973e9f48173d0f1136a2581a83735f344d',
    actualSha256: '48cdbc73ba8dccbba63e8d868d9a2a430625e98e0898c883b593f39d2356790e',
    restoredPrefix: '// ../manabitan-runtime-deps-4d9ffe79ec6f/node_modules/',
    frozenPrefix: '// node_modules/',
    commentLines: 24,
};
export const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
export async function fileIdentity(file) {
    const hash = createHash('sha256');
    let bytes = 0;
    for await (const chunk of createReadStream(file)) { bytes += chunk.byteLength; hash.update(chunk); }
    return {bytes, sha256: hash.digest('hex')};
}
export async function fileHashes(root, files) {
    return Object.fromEntries(await Promise.all([...new Set(files)].map(async file => [file, (await fileIdentity(path.join(root, file))).sha256])));
}
export async function sourceReceipt(root, commit) {
    assert.equal(execFileSync('git', ['-C', root, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim(), commit);
    const diff = execFileSync('git', ['-C', root, 'diff', 'HEAD', '--binary']);
    assert.equal(diff.byteLength, 0, 'Tracked source must remain unchanged');
    const identity = await fileHashes(root, sourceFiles);
    const manifest = JSON.parse(await readFile(path.join(root, 'dev/data/dictionary-wasm/manifest.json'), 'utf8'));
    assert.equal(manifest.toolchain.compilerVersion, '21.1.8');
    assert.equal(manifest.toolchain.linkerVersion, '21.1.8');
    for (const target of manifest.targets) {
        assert.equal(identity[`ext/lib/${target.name}`], target.sha256);
        assert.equal(identity[`dev/data/dictionary-wasm/${target.name}`], target.sha256);
    }
    return {root, commit, diffSha256: sha256(diff), identity};
}
export async function validateSourceFamily(arm, source) {
    assert(['A', 'B'].includes(arm));
    const frozen = await sourceReceipt(frozenRoot, frozenCommit);
    const parent = await sourceReceipt(sources.A.root, sources.A.commit);
    const zip = regeneratedZipCommentDelta;
    assert.equal(frozen.identity[zip.file], zip.frozenSha256);
    assert.equal(parent.identity[zip.file], zip.actualSha256);
    assert.equal(source.identity[zip.file], zip.actualSha256);
    const zipBytes = await readFile(path.join(parent.root, zip.file));
    const zipText = zipBytes.toString('utf8');
    const pathLines = zipText.split('\n').filter(line => line.includes(zip.restoredPrefix));
    assert.equal(pathLines.length, zip.commentLines);
    assert(pathLines.every(line => line.startsWith(zip.restoredPrefix)));
    assert.equal(sha256(zipText.replaceAll(zip.restoredPrefix, zip.frozenPrefix)), zip.frozenSha256,
        'Only exact esbuild source-path line comments may differ from the historical ZIP asset');
    for (const [file, hash] of Object.entries(frozen.identity)) {
        if (!mergedParserChanges.has(file) && file !== zip.file) { assert.equal(parent.identity[file], hash, `Unapproved merged-parent delta: ${file}`); }
        if (!mergedParserChanges.has(file) && file !== zip.file && !(arm === 'B' && signatureChanges.has(file))) {
            assert.equal(source.identity[file], hash, `Unapproved historical-source delta: ${file}`);
        }
    }
    for (const [file, hash] of Object.entries(parent.identity)) {
        if (!(arm === 'B' && signatureChanges.has(file))) { assert.equal(source.identity[file], hash, `Unapproved current-parent delta: ${file}`); }
    }
    const changedFiles = execFileSync('git', ['-C', source.root, 'diff', '--name-only', frozenCommit, source.commit], {encoding: 'utf8'}).trim().split('\n').filter(Boolean);
    for (const file of changedFiles) {
        if (file.startsWith('ext/') || file.startsWith('dev/data/dictionary-wasm/')) {
            assert(mergedParserChanges.has(file) || (arm === 'B' && signatureChanges.has(file)), `Unexpected runtime path: ${file}`);
        }
    }
    return {frozen, parent, arm, changedFiles, generatedCommentDelta: zip, allowedMergedParserChanges: [...mergedParserChanges], allowedCandidateChanges: arm === 'B' ? [...signatureChanges] : []};
}
export function assertHistoricalOracleIdentity(referenceIdentity, actualIdentity, family) {
    for (const [file, hash] of Object.entries(referenceIdentity)) {
        assert.equal(family.frozen.identity[file], hash, `Historical oracle is not the frozen source: ${file}`);
        if (actualIdentity[file] !== hash) {
            const provedCommentOnlyDelta = file === family.generatedCommentDelta.file &&
                hash === family.generatedCommentDelta.frozenSha256 && actualIdentity[file] === family.generatedCommentDelta.actualSha256;
            assert(mergedParserChanges.has(file) || (family.arm === 'B' && signatureChanges.has(file)) || provedCommentOnlyDelta, `Unapproved historical oracle source delta: ${file}`);
        }
    }
}
export async function resources() {
    const free = async location => { const s = await statfs(location); return {location, availableBytes: s.bavail * s.bsize, totalBytes: s.blocks * s.bsize}; };
    const optional = async file => { try { return (await readFile(file, 'utf8')).trim(); } catch (error) { return {unavailable: error.code}; } };
    return {
        utc: new Date().toISOString(), node: process.version, versions: process.versions, execArgv: process.execArgv,
        platform: process.platform, arch: process.arch, cpus: os.availableParallelism(), loadAverage: os.loadavg(),
        freeMemoryBytes: os.freemem(), processMemory: process.memoryUsage(), processUsage: process.resourceUsage(),
        temp: await free(os.tmpdir()), reports: await free(evidenceRoot),
        cgroup: Object.fromEntries(await Promise.all(['/sys/fs/cgroup/memory.max', '/sys/fs/cgroup/memory.current'].map(async file => [file, await optional(file)]))),
    };
}
