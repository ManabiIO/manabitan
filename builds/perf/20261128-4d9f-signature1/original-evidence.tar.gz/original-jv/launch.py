#!/usr/bin/env python3
"""One complete correctness acquisition; preserves exit/signal and every log."""
import hashlib
import json
from pathlib import Path
import signal
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
corpus, arm, output_argument = sys.argv[1:]
assert corpus in ('jitendex', 'vndb') and arm in ('A', 'B')
output = Path(output_argument).resolve()
logs = {kind: Path(str(output) + suffix) for kind, suffix in {
    'stdout': '.stdout.log', 'stderr': '.stderr.log', 'launcher': '.launcher.json'
}.items()}
assert not output.exists()
assert all(not file.exists() for file in logs.values())
output.parent.mkdir(parents=True, exist_ok=True)
command = ['/home/agent/manabitan-node22-4d9ffe79ec6f/node', '--max-old-space-size=512',
           str(here / 'sink-parity.mjs'), corpus, arm, str(output)]
receipt = {'schemaVersion': 1, 'timingEligible': False, 'command': command,
           'deadlineSeconds': 1200, 'startedEpoch': time.time(),
           'launcherSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
def checkpoint():
    logs['launcher'].write_text(json.dumps(receipt, indent=2) + '\n')
with logs['stdout'].open('xb') as stdout, logs['stderr'].open('xb') as stderr:
    child = subprocess.Popen(command, stdout=stdout, stderr=stderr)
    receipt.update(status='running', pid=child.pid)
    checkpoint()
    try:
        code = child.wait(timeout=receipt['deadlineSeconds'])
    except subprocess.TimeoutExpired:
        receipt['deadlineExceeded'] = True
        child.kill()
        code = child.wait()
    receipt.update(returncode=code,
                   terminatingSignal=signal.Signals(-code).name if code < 0 else None,
                   finishedEpoch=time.time(), status='complete' if code == 0 else 'failed')
    checkpoint()
print(json.dumps(receipt, indent=2))
sys.exit(0 if code == 0 else 1)
