export MANABITAN_CLANG=/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr/bin/clang-21
export CLANG="$MANABITAN_CLANG"
export MANABITAN_WASM_LD=/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr/bin/wasm-ld-21
export LD_LIBRARY_PATH=/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}
export PATH=/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr/bin:/workspace/scratch/f34c9c9fae89/toolchains/llvm21/usr/lib/llvm-21/bin:$PATH
