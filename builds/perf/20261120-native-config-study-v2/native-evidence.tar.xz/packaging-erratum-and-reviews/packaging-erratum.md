# Native candidate package-entry correction

The earlier statement that the package changes only `lib/term-content-canonical-scan-v1.wasm` is incorrect. Normal extension packages also include the canonical C source.

The exact baseline-to-candidate package delta is:

| Package entry | Immutable repository source |
| --- | --- |
| `js/dictionary/wasm/term-content-canonical-scan-v1.c` | `ext/js/dictionary/wasm/term-content-canonical-scan-v1.c` |
| `lib/term-content-canonical-scan-v1.wasm` | `dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm` |

This correction applies to `packagePaths` in the frozen `candidate-freeze.json`, the copied `candidate.packagePaths` in `frozen-cohort.json`, the package-only sentence in `native-candidate-notes.md`, and the earlier chat summary. The statement that only one of the five generated WASM assets changed remains correct.

The full 538-entry Chromium forward and reverse package maps were independently compared across the complete key union. A/C maps match each other, B/D maps match each other, and exactly these two paths differ. Both entries in all eight maps match bytes from immutable baseline `bde55dfbee1451edc32051f8bf51e8a870d5c72c` or candidate `19b13a550d9b7f2a53f37d74aa36b2ee9c3e7472`, respectively. The JSON supplement records every map hash and source digest.

The native candidate, component protocol and all 104 component observations are unchanged. The component screen loaded the correct source and generated module, so this packaging-description error does not alter its correctness results or its inconclusive performance decision. All 30 files indexed by the original native evidence receipt were verified unchanged when this supplement was written.

Hosted v1 package preparation caught the incomplete allowlist before any import observation. The coordinator reports the same preparation stop in all four browser/order cells. A separately frozen v2 protocol must declare both package entries and validate the full package-entry union before browser measurements. No measurements were rerun for this correction.

Read this supplement together with the original frozen receipt. The original files are preserved exactly; this correction does not rewrite their historical hashes.
