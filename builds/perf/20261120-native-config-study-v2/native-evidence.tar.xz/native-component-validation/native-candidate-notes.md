# Immutable canonical-scan configuration candidate

## Current decision

The full-resolver component result is inconclusive. Candidate medians moved favorably, but the same-source control moved by a similar amount, only 13 of 24 pairs favored each candidate arm, and both descriptive intervals crossed zero. No component performance gate passed. A separate fixed browser diagnostic is warranted only as a measurement of the actual engines and full import path; it does not imply runtime promotion.

## Frozen implementation

- Baseline: `bde55dfbee1451edc32051f8bf51e8a870d5c72c`.
- Candidate: `19b13a550d9b7f2a53f37d74aa36b2ee9c3e7472`.
- Tree: `c8f0aace6e3b11355220f22dfff8e668df97673b`.
- Canonical WASM: `3bfd2ea83fdd8f3397cc5eafa1d4e5fa6f20afa1e4f3251fce4a858b030e959c`.
- The four changed tracked files are canonical C, its committed WASM artifact, the dictionary-WASM manifest, and the new direct header ABI test. The package changes only `lib/term-content-canonical-scan-v1.wasm`. Parser WASM and the other generated modules remain unchanged.

The first correct implementation snapshots only the configuration fields still read inside the hot loop into named scalar locals. Existing header initialization and initial validation stay in their original order. Table pointers, loop bound, mask and loop start were already local. No native header counter, journal publication, compiler memory barrier, cache budget, ownership boundary, error order, cancellation behavior or storage format changes.

## ABI and rollback reasoning

Configuration occupies bytes 1088 through 1175. Every validated authoritative column and slot array begins at or above the fixed 8 MiB prefix. Header and fixed output/journal scratch regions are separate from configuration below that prefix, and validated row counts bound every scratch write. The synchronous module imports only nonshared memory; it has no host callback or reentrant await. Configuration therefore cannot change within a valid call. Snapshotting after the existing validation also preserves invalid-configuration behavior and avoids new pre-validation reads.

The new tests observe the production kernel directly before JS rollback can hide native progress. They assert all seven header words and committed journal entries at traps after insertions 1, 2 and 3, late row/identity/source errors, invalid configuration, invalid hash-table index, capacity failure, non-reserving output, resolved-row counts, and the exact-descriptor 4096 boundary with a deliberately invalid next row. All 12 cases passed the unchanged baseline WASM first. The existing differential owner tests still cover adoption failures, later-segment rollback, arena replacement, and complete record/index bytes.

Independent read-only review found no alias, arithmetic, trap-order or ownership blocker. No `restrict` annotation or assumption that arbitrary authoritative columns are disjoint was introduced.

## Static instruction evidence

The pinned Clang/LLD 21.1.8 rebuild is coherent. LLVM wasm32 `-O3` assembly contains 11 absolute configuration-load instruction occurrences inside the baseline row-loop region and zero in the candidate. All seven header-load and six header-store occurrences remain in the same order. These are static code occurrences, not dynamic instruction counts or CPU cycle estimates. Canonical WASM grows from 1,624 to 1,709 bytes; register-pressure and code-size tradeoffs remain possible. Assembly files and their hashes are retained. No source tuning followed instruction inspection or timing.

## Fixed component cohort

The fixed component protocol contains 104 retained replays: two warmups per arm followed by 24 balanced four-arm blocks. A/C use the baseline; B/D use the candidate. Order cycles through ABCD, BDAC, CADB and DCBA. There were no retries, exclusions, extensions, pooling or control subtraction. The runner source and candidate were frozen before timing.

Two complete source fixtures are parsed before timing, one per source root. Every replay owns a fresh database and exact-byte virtual storage map; explicit GC precedes each resolver sequence. Seven-bank grouping creates eight groups and differs from the browser planner. All 526,942 source rows are checked byte-for-byte after timing; reference, canonical-content, source-descriptor and exact-descriptor digests agree across all arms. Path counts are identical: 364,609 native scanned rows, 360,859 new canonical contents, 162,333 within-group hits, 3,750 persisted/exact hits, 2,915 recent-source hits and 835 virtual reads. The unchanged recent-source cache limit is 48 MiB.

The primary metric is complete resolver wall time, including its nested exact matching. Publication is timed separately; virtual writes, compression, OPFS, parser work, source construction, transport and output verification are outside resolver timing. The component is not a browser or whole-import test.

| Comparison | Median paired change | Median paired time | Faster pairs | Descriptive 95% interval |
| --- | ---: | ---: | ---: | --- |
| C/A | -5.11% | -2.48 ms | 12/24 | [-16.36%, +20.90%] |
| D/B | +1.15% | +0.58 ms | 11/24 | [-7.43%, +12.71%] |
| B/A | -6.07% | -3.15 ms | 13/24 | [-16.79%, +7.07%] |
| D/A | -4.53% | -2.50 ms | 13/24 | [-24.79%, +20.04%] |

Resolver arm medians A/B/C/D are 54.95 / 51.32 / 53.53 / 52.66 ms. Large tails are retained. Publication controls also drift, so nested timers do not support attributing a whole-import gain. Exact matching is unchanged by the candidate. Intervals are descriptive bootstrap intervals and do not correct temporal dependence or multiple comparisons.

The cohort ran from 11:15:17 to 11:16:42 UTC. Every output oracle, native counter, source/runner identity, archive identity and generated artifact check passed. `component-results.json` retains all observations; `component-summary.json` and `summarize-component.py` retain the complete analysis.

## Validation and retained setup failures

Five focused files passed 166 tests. All 12 new direct ABI cases passed baseline first. The exact LLVM rebuild check, main types, required test types and all seven dry builds have passed. The full suite passed 13,788 tests with 47 skipped across 620 files in 471.64 seconds, using one worker and a 2 GiB heap. `required-validation.json` records every command, timestamp and log hash. All source hashes and generated module hashes remain unchanged after validation; only canonical WASM differs from baseline.

Initial scoped lint reported 16 array-element-newline formatting errors in the new test and was corrected without changing runtime C. The first inline assembly summary expected a marker absent from LLVM wasm assembly; it failed before producing a receipt and was corrected to use `end_function`. Both source assemblies, the initial lint log and setup notes are retained. Neither issue affected or caused a retry of the fixed cohort.

The historical qualification sentence in `dev/data/dictionary-wasm/README.md` still describes the earlier released canonical artifact. This experimental candidate has not acquired that qualification. Any eventual product PR must update the provenance statement with the actual browser outcome.
