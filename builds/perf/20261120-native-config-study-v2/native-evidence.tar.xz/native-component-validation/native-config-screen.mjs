#!/usr/bin/env node
/*
 * Copyright (C) 2026  Manabitan authors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
/* eslint @stylistic/semi: ["error", "never"] */
// This component screen deliberately instruments the production private methods.
/* eslint no-underscore-dangle: ["error", {"allow": ["_nativeCanonicalScanner", "_findMatchingPersistedTermEntryContentMetaBatch", "_readTermEntryContentBytesDetailedBatch", "_resolveArtifactTermContentDedup", "_publishArtifactTermContentMetadata", "_recentTermContentSourceBatchBytes", "_termEntryContentMetaHashPairPendingCount", "_recentTermContentSourceCacheMaxBytes"]}] */

/**
 * Fixed four-arm current-source canonical resolver component screen.
 * Based on cf7efa0229562798f54cb0009a3ba85ee3b16369 component screen.
 * Native config candidate only; no diagnostic adapter timers in timed sources.
 *
 * node dev/perf/import-dedup-screen.js jmdict --baseline-root /path/to/base --pairs 8
 * Add --device-memory-gib 8 to exercise the browser's existing high-memory policy.
 * Without that option, the runtime's real device-memory hint is left untouched.
 *
 * Fixture decoding, WASM compilation, parser execution, warmups, virtual storage
 * writes and complete output verification are outside the resolver timer. The
 * backing map serves exact bytes without compression, disk I/O or promises that
 * model disk latency. Results are NOT browser or whole-import measurements.
 */

import assert from 'node:assert/strict'
import {spawnSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {mkdir, readFile, rename, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {fileURLToPath, pathToFileURL} from 'node:url'
import {parseArgs} from 'node:util'
import {ZipReader, Uint8ArrayReader, Uint8ArrayWriter} from '@zip.js/zip.js'
import {parseJson} from '../../../ext/js/core/json.js'
import {safePerformance} from '../../../ext/js/core/safe-performance.js'
import {loadDictionaryWasm} from '../../../dev/dictionary-wasm.js'
import {getHostEnvironment} from '../../../dev/perf/host-environment.js'

/** @typedef {import('../../../ext/js/dictionary/dictionary-database.js').DictionaryDatabase} Database */
/** @typedef {import('../../../ext/js/dictionary/dictionary-database.js').ArtifactTermContentChunk} ContentChunk */
/** @typedef {import('../../../ext/js/dictionary/dictionary-database.js').ArtifactTermContentDedupPlan} ContentPlan */
/** @typedef {Awaited<ReturnType<Database['_resolveArtifactTermContentDedup']>>} Resolution */
/** @typedef {typeof import('../../../ext/js/dictionary/term-bank-wasm-parser.js')} Parser */
/** @typedef {import('../../../ext/js/dictionary/term-content-canonical-scan.js').NativeCanonicalScanner} CanonicalScanner */
/** @typedef {{rowCount: number, contentBytesBuffer: Uint8Array, contentMetaList: Uint32Array, contentUniqueIndexList: Uint32Array, uniqueRowIndexes: Uint32Array, uniqueSignatures: Uint32Array}} FixtureChunk */
/** @typedef {import('./dictionary-fixtures.js').DictionaryFixture} Fixture */
/** @typedef {{offset: number, length: number, hash1: number, hash2: number, bytes: Uint8Array}} VirtualContent */
/** @typedef {{wallMs: number, cpuMs: number}} Duration */
/** @typedef {{wall: number, cpu: ReturnType<typeof process.cpuUsage>}} TimingStart */
/** @typedef {{rows: number, pendingHits: number, persistedHits: number, uniqueContent: number, exactFallbacks: number, recentSourceHits: number, exactCalls: number, exactDescriptors: number, storageReadCalls: number, storageReadEntries: number, peakRecentSourceBytes: number}} Counters */
/**
 * @typedef {object} Measurement
 * @property {Duration} resolver
 * @property {Duration} exact
 * @property {Duration} publication
 * @property {number} ownerExactMs
 * @property {Counters} counters
 * @property {string} referenceDigest
 * @property {string} canonicalContentDigest
 * @property {string} resolvedContentDigest
 * @property {CanonicalScanner['stats']} nativeStats
 * @property {Array<{rows: number, stats: Record<string, number>}>} groupNativeStats
 * @property {string} canonicalDescriptorDigest
 * @property {string} exactDescriptorDigest
 * @property {string} storageRequestDigest
 * @property {number} recentSourceCacheBudgetBytes
 * @property {string} scope
 * @property {boolean} authoritativeWholeImportTiming
 * @property {string} cpuBoundary
 * @property {string[]} exclusions
 * @property {string} dictionary
 * @property {string} sourceRoot
 * @property {ReturnType<typeof sourceGitIdentity>} sourceGit
 * @property {Record<string, unknown>} hostBefore
 * @property {Record<string, unknown>} hostAfter
 * @property {number} filesPerGroup
 * @property {Array<{rows: number, uniqueContent: number, sourceBytes: number}>} groups
 * @property {number|null} deviceMemoryGiB
 * @property {number} warmupCount
 * @property {string} node
 * @property {string} v8
 * @property {string} archiveSha256
 * @property {string} lockSha256
 * @property {Record<string, string>} sourceHashes
 * @property {Record<string, string>} runnerSourceHashes
 * @property {string} runnerSha256
 * @property {string} sourceContentDigest
 * @property {number} encodedSourceBytes
 * @property {ReturnType<typeof process.memoryUsage>} harnessMemoryAfterVerification
 * @property {number} harnessLifetimeMaxRssKiB
 */
/** @typedef {{pair: number, arm: string, status: string, result?: Awaited<ReturnType<typeof prepareReplay>>, error?: string, stdout?: string, stderr?: string, exitCode?: number|null, signal?: string|null}} Observation */

const root = fileURLToPath(new URL('../../../', import.meta.url))
const filename = fileURLToPath(import.meta.url)
/** Same fixed component grouping as import-lookup-screen.js; not browser scheduling. @type {Record<string, number>} */
const filesPerGroup = {jmdict: 7, jmnedict: 9, jitendex: 10}
// Production direct-block eligibility is real; block writes/reads are virtual.
const virtualDictName = 'raw-block-v2:jmdict'
const runnerFiles = [
    'builds/perf/20261120-canonical-config/native-config-screen.mjs',
    'dev/perf/host-environment.js',
    'dev/dictionary-wasm.js',
    'dev/json.js',
    'ext/js/core/json.js',
    'ext/js/core/safe-performance.js',
    'test/perf/dictionaries.lock.json',
    'package-lock.json',
]
const sourceFiles = [
    'package.json',
    'package-lock.json',
    'ext/js/dictionary/dictionary-database.js',
    'ext/js/dictionary/term-bank-wasm-parser.js',
    'ext/js/dictionary/term-bank-experiments.js',
    'ext/js/dictionary/term-content-canonical-layout.js',
    'ext/js/dictionary/term-content-canonical-scan.js',
    'ext/js/dictionary/term-content-metadata-arena.js',
    'ext/js/dictionary/term-content-block-store.js',
    'ext/js/dictionary/term-entry-content-hash.js',
    'ext/js/dictionary/raw-term-content.js',
    'ext/js/dictionary/wasm/term-bank-parser.c',
    'ext/js/dictionary/wasm/term-content-canonical-scan-v1.c',
    'dev/data/dictionary-wasm/manifest.json',
    'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm',
    'dev/data/dictionary-wasm/term-bank-parser.wasm',
    'ext/lib/term-bank-parser.wasm',
    'ext/lib/term-content-canonical-scan-v1.wasm',
]

/**
 * @param {import('node:crypto').BinaryLike} bytes
 * @returns {string}
 */
function sha256(bytes) { return createHash('sha256').update(bytes).digest('hex') }

/**
 * @param {string} sourceRoot
 * @param {string[]} [files]
 * @returns {Promise<Record<string, string>>}
 */
async function sourceIdentity(sourceRoot, files = sourceFiles) {
    /** @type {Record<string, string>} */
    const hashes = {}
    for (const file of files) { hashes[file] = sha256(await readFile(path.join(sourceRoot, file))) }
    return hashes
}

/**
 * @param {string} sourceRoot
 * @returns {{commit: string|null, dirty: boolean|null, status: string|null, trackedDiffSha256: string|null, error: string|null}}
 */
function sourceGitIdentity(sourceRoot) {
    const commit = spawnSync('git', ['rev-parse', '--verify', 'HEAD'], {cwd: sourceRoot, encoding: 'utf8'})
    const status = spawnSync('git', ['status', '--porcelain', '--untracked-files=normal'], {cwd: sourceRoot, encoding: 'utf8'})
    const diff = spawnSync('git', ['diff', '--no-ext-diff', '--no-textconv', '--binary', 'HEAD', '--'], {cwd: sourceRoot, encoding: 'utf8', maxBuffer: 32 * 1024 * 1024})
    const failure = [commit, status, diff].find((result) => result.error || result.status !== 0)
    return {
        commit: commit.status === 0 ? commit.stdout.trim() : null,
        dirty: status.status === 0 ? status.stdout.length > 0 : null,
        status: status.status === 0 ? status.stdout : null,
        trackedDiffSha256: diff.status === 0 ? sha256(diff.stdout) : null,
        error: typeof failure === 'undefined' ? null : String(failure.error ?? failure.stderr),
    }
}

/** @returns {TimingStart} */
function startTiming() { return {wall: safePerformance.now(), cpu: process.cpuUsage()} }

/**
 * @param {TimingStart} start
 * @returns {Duration}
 */
function endTiming(start) {
    const cpu = process.cpuUsage(start.cpu)
    return {wallMs: safePerformance.now() - start.wall, cpuMs: (cpu.user + cpu.system) / 1000}
}

/**
 * @param {Duration} total
 * @param {Duration} part
 */
function addDuration(total, part) {
    total.wallMs += part.wallMs
    total.cpuMs += part.cpuMs
}

/**
 * Preserve the production cache policy; this is an explicit device-hint scenario.
 * @param {number|null} deviceMemoryGiB
 */
function setDeviceMemoryScenario(deviceMemoryGiB) {
    if (deviceMemoryGiB === null) { return }
    if (typeof globalThis.navigator === 'undefined') {
        Object.defineProperty(globalThis, 'navigator', {value: {}, configurable: true})
    }
    Object.defineProperty(globalThis.navigator, 'deviceMemory', {value: deviceMemoryGiB, configurable: true})
}

/**
 * @param {Parser} parser
 * @param {string} dictionary
 * @param {string} cacheDir
 * @param {string} sourceRoot
 * @returns {Promise<{chunks: FixtureChunk[], fixture: Fixture, archiveSha256: string, lockSha256: string, sourceContentDigest: string, encodedSourceBytes: number, canonicalDescriptorDigest: string}>}
 * @throws {Error} If fixture identity, parser ownership or canonical plans are invalid.
 */
async function loadChunks(parser, dictionary, cacheDir, sourceRoot) {
    const lockBytes = await readFile(path.join(root, 'test/perf/dictionaries.lock.json'))
    const lock = /** @type {{schemaVersion: number, dictionaries: Record<string, Fixture>}} */ (parseJson(lockBytes.toString()))
    const fixture = lock.dictionaries?.[dictionary]
    if (lock.schemaVersion !== 1 || !fixture) { throw new Error('Invalid dictionary fixture lock') }
    const archive = await readFile(path.join(cacheDir, fixture.cacheFile))
    const archiveSha256 = sha256(archive)
    if (archive.byteLength !== fixture.sizeBytes || archiveSha256 !== fixture.sha256) {
        throw new Error(`Pinned ${dictionary} archive size or SHA-256 does not match the lock`)
    }
    const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)))
    /** @type {Uint8Array[]} */
    const sources = []
    try {
        const entries = await reader.getEntries()
        const index = entries.find((entry) => entry.filename === 'index.json')
        if (!index?.getData) { throw new Error('Missing dictionary index') }
        const indexBytes = await index.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true})
        const info = /** @type {{title: string, revision: string, format: number}} */ (parseJson(new TextDecoder().decode(indexBytes)))
        if (info.title !== fixture.expectedTitle || info.revision !== fixture.revision || info.format !== 3) {
            throw new Error('Dictionary index does not match the locked format, title and revision')
        }
        const banks = entries.filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename))
            .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
        for (const entry of banks) {
            if (!entry.getData) { throw new Error(`Unreadable term bank: ${entry.filename}`) }
            sources.push(await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}))
        }
    } finally { await reader.close() }
    parser.setTermBankWasmModule(await WebAssembly.compile(await readFile(path.join(sourceRoot, 'ext/lib/term-bank-parser.wasm'))))
    /** @type {FixtureChunk[]} */
    const chunks = []
    for (let start = 0; start < sources.length; start += filesPerGroup[dictionary]) {
        await parser.parseTermBankWithWasmColumnChunks(sources.slice(start, start + filesPerGroup[dictionary]), 3, (chunk) => {
            // The next parse resets the WASM arena. Copy before returning the sink.
            const owned = parser.copyWasmBackedColumnChunk(chunk)
            /** @type {unknown} */
            const plan = owned.contentDedupPlan
            if (
                !(owned.contentBytesBuffer instanceof Uint8Array) ||
                !(owned.contentMetaList instanceof Uint32Array) ||
                !(owned.contentUniqueIndexList instanceof Uint32Array) ||
                typeof plan !== 'object' || plan === null ||
                !('uniqueRowIndexes' in plan) || !('uniqueSignatures' in plan) ||
                !(plan.uniqueRowIndexes instanceof Uint32Array) ||
                !(plan.uniqueSignatures instanceof Uint32Array) ||
                owned.contentBytesBaseOffset !== 0 || owned.contentRowStart !== 0 ||
                owned.contentMetaList.length !== owned.rowCount * 4 ||
                owned.contentUniqueIndexList.length !== owned.rowCount ||
                plan.uniqueSignatures.length !== plan.uniqueRowIndexes.length * 3
            ) {
                throw new Error('Parser did not produce an owned complete canonical content group')
            }
            chunks.push({
                rowCount: owned.rowCount,
                contentBytesBuffer: owned.contentBytesBuffer,
                contentMetaList: owned.contentMetaList,
                contentUniqueIndexList: owned.contentUniqueIndexList,
                uniqueRowIndexes: new Uint32Array(plan.uniqueRowIndexes),
                uniqueSignatures: new Uint32Array(plan.uniqueSignatures),
            })
        }, 2048, {
            singleChunk: true,
            emitTermByteLists: false,
            computeContentHashes: true,
            emitContentSlab: true,
            emitTokenBinaryContent: true,
            mediaHintFastScan: true,
            validateGlossaryTypes: true,
            prepareLookupIndexes: true,
        })
    }
    if (chunks.reduce((count, chunk) => count + chunk.rowCount, 0) !== fixture.termRows) {
        throw new Error('Complete parsed term count differs from the fixture lock')
    }
    const canonicalDescriptors = createHash('sha256')
    for (const chunk of chunks) {
        canonicalDescriptors.update(JSON.stringify([chunk.rowCount, chunk.uniqueRowIndexes.length, chunk.contentBytesBuffer.byteLength]))
        for (const column of [chunk.contentMetaList, chunk.contentUniqueIndexList, chunk.uniqueRowIndexes, chunk.uniqueSignatures]) {
            canonicalDescriptors.update(new Uint8Array(column.buffer, column.byteOffset, column.byteLength))
        }
    }
    const canonicalDescriptorDigest = canonicalDescriptors.digest('hex')
    const contentHash = createHash('sha256')
    let encodedSourceBytes = 0
    const header = Buffer.alloc(12)
    for (const chunk of chunks) {
        for (let row = 0; row < chunk.rowCount; ++row) {
            const at = row * 4
            const offset = chunk.contentMetaList[at]
            const length = chunk.contentMetaList[at + 1]
            if (offset > chunk.contentBytesBuffer.length || length > chunk.contentBytesBuffer.length - offset) {
                throw new Error('Parser content span is out of bounds')
            }
            header.writeUInt32LE(length, 0)
            header.writeUInt32LE(chunk.contentMetaList[at + 2], 4)
            header.writeUInt32LE(chunk.contentMetaList[at + 3], 8)
            contentHash.update(header)
            contentHash.update(chunk.contentBytesBuffer.subarray(offset, offset + length))
            encodedSourceBytes += length
        }
    }
    return {chunks, fixture, archiveSha256, lockSha256: sha256(lockBytes), sourceContentDigest: contentHash.digest('hex'), encodedSourceBytes, canonicalDescriptorDigest}
}

/**
 * @param {FixtureChunk} fixture
 * @param {number} dictionaryTotalRows Verified complete row count from the fixture lock.
 * @returns {ContentChunk & {dictionaryTotalRows: number, contentDedupPlan: ContentPlan}}
 */
function freshChunk(fixture, dictionaryTotalRows) {
    const uniqueCount = fixture.uniqueRowIndexes.length
    return {
        ...fixture,
        dictionaryTotalRows,
        contentRowStart: 0,
        contentBytesBaseOffset: 0,
        contentBytesList: [],
        contentHash1List: new Uint32Array(0),
        contentHash2List: new Uint32Array(0),
        contentDictNameList: null,
        uniformContentDictName: virtualDictName,
        useResolvedContentReferences: true,
        contentDedupPlan: {
            uniqueCount,
            sourceRowCount: fixture.rowCount,
            uniqueRowIndexes: fixture.uniqueRowIndexes,
            uniqueSignatures: fixture.uniqueSignatures,
            resolvedFlags: new Uint8Array(uniqueCount),
            resolvedOffsets: new Float64Array(uniqueCount),
            resolvedLengths: new Uint32Array(uniqueCount),
            resolvedDictNames: null,
            pendingEpochs: new Uint32Array(uniqueCount),
            pendingIndexes: new Uint32Array(uniqueCount),
            pendingSpanOffsetsScratch: new Uint32Array(fixture.rowCount),
            pendingSpanLengthsScratch: new Uint32Array(fixture.rowCount),
            nextEpoch: 1,
            nextUnresolvedUniqueIndex: 0,
        },
    }
}

/**
 * Supply completed persistence results to the production publication method.
 * Only virtual-offset assignment and the storage boundary are simulated.
 * @param {ContentChunk & {contentDedupPlan: ContentPlan}} chunk
 * @param {Resolution} dedup
 * @param {Map<number, VirtualContent>} storage
 * @param {number} cursor
 * @returns {{pendingOffsets: Float64Array, pendingLengths: Uint32Array, cursor: number}}
 * @throws {Error} If resolved dictionary mappings or pending references are invalid.
 */
function storePending(chunk, dedup, storage, cursor) {
    const plan = chunk.contentDedupPlan
    // Check resolver-owned mappings before simulating publication of new bytes.
    // Assigning the uniform name unconditionally would conceal missing or wrong
    // mappings in mixed-hit groups and in groups with no pending content.
    assert.equal(plan.resolvedDictNames, null, 'Unexpected per-entry dictionary mapping')
    if (plan.resolvedFlags.includes(1)) {
        assert.equal(plan.resolvedUniformDictName, virtualDictName, 'Resolved hit has the wrong dictionary mapping')
    }
    const pendingOffsets = new Float64Array(dedup.pendingContentCount)
    const pendingLengths = new Uint32Array(dedup.pendingContentCount)
    for (let i = 0; i < dedup.pendingContentCount; ++i) {
        const spans = dedup.pendingContentSpans
        const bytes = spans === null ?
            dedup.pendingContentBytes[i] :
            spans.buffer.subarray(spans.offsets[i], spans.offsets[i] + spans.lengths[i])
        pendingOffsets[i] = cursor
        pendingLengths[i] = bytes.length
        storage.set(cursor, {offset: cursor, length: bytes.length, hash1: dedup.pendingContentHash1s[i], hash2: dedup.pendingContentHash2s[i], bytes})
        // Distinct empty payloads must not alias the next virtual address.
        cursor += Math.max(1, bytes.length)
        if (!Number.isSafeInteger(cursor)) { throw new RangeError('Virtual content offset overflow') }
        const uniqueIndex = dedup.pendingPlanUniqueStart === null ? dedup.pendingPlanUniqueIndexes[i] : dedup.pendingPlanUniqueStart + i
        assert.ok(Number.isSafeInteger(uniqueIndex) && uniqueIndex >= 0 && uniqueIndex < plan.resolvedFlags.length, 'Pending unique index is invalid')
        assert.equal(plan.resolvedFlags[uniqueIndex], 0, 'Pending content would overwrite a resolved hit')
        plan.resolvedOffsets[uniqueIndex] = pendingOffsets[i]
        plan.resolvedLengths[uniqueIndex] = pendingLengths[i]
        plan.resolvedUniformDictName = virtualDictName
        plan.resolvedFlags[uniqueIndex] = 1
    }
    return {pendingOffsets, pendingLengths, cursor}
}

/**
 * @param {string} dictionary
 * @param {string} cacheDir
 * @param {string} sourceRoot
 * @param {number|null} deviceMemoryGiB
 * @returns {Promise<Measurement>} Complete verified component measurement and provenance.
 * @throws {Error} If provenance, content or reference verification fails.
 */
async function prepareReplay(dictionary, cacheDir, sourceRoot, deviceMemoryGiB) {
    setDeviceMemoryScenario(deviceMemoryGiB)
    const initialIdentity = await sourceIdentity(sourceRoot)
    const initialRunnerIdentity = await sourceIdentity(root, runnerFiles)
    const sourceGit = sourceGitIdentity(sourceRoot)
    const verifiedWasm = loadDictionaryWasm(sourceRoot)
    for (const [name, bytes] of verifiedWasm) {
        assert.deepEqual(await readFile(path.join(sourceRoot, 'ext/lib', name)), bytes, `Generated ${name} differs from its source-verified artifact`)
    }
    // Only the caller-selected local worktree supplies modules, never the archive.
    // eslint-disable-next-line no-unsanitized/method, @typescript-eslint/no-unsafe-assignment
    const parser = /** @type {Parser} */ (await import(pathToFileURL(path.join(sourceRoot, 'ext/js/dictionary/term-bank-wasm-parser.js')).href))
    // eslint-disable-next-line no-unsanitized/method, @typescript-eslint/no-unsafe-assignment
    const {DictionaryDatabase} = /** @type {typeof import('../../../ext/js/dictionary/dictionary-database.js')} */ (await import(pathToFileURL(path.join(sourceRoot, 'ext/js/dictionary/dictionary-database.js')).href))
    // eslint-disable-next-line no-unsanitized/method, @typescript-eslint/no-unsafe-assignment
    const {NativeCanonicalScanner} = /** @type {typeof import('../../../ext/js/dictionary/term-content-canonical-scan.js')} */ (await import(pathToFileURL(path.join(sourceRoot, 'ext/js/dictionary/term-content-canonical-scan.js')).href))
    const canonicalModule = await WebAssembly.compile(await readFile(path.join(sourceRoot, 'ext/lib/term-content-canonical-scan-v1.wasm')))
    const fixture = await loadChunks(parser, dictionary, cacheDir, sourceRoot)

    const execute = async () => {
        const database = new DictionaryDatabase()
        const scanner = new NativeCanonicalScanner({loadModule: async () => canonicalModule})
        database._nativeCanonicalScanner = scanner
        const chunks = fixture.chunks.map((chunk) => freshChunk(chunk, fixture.fixture.termRows))
        /** @type {Map<number, VirtualContent>} */
        const storage = new Map()
        const resolver = {wallMs: 0, cpuMs: 0}
        const exact = {wallMs: 0, cpuMs: 0}
        const publication = {wallMs: 0, cpuMs: 0}
        const counters = {rows: 0, pendingHits: 0, persistedHits: 0, uniqueContent: 0, exactFallbacks: 0, recentSourceHits: 0, exactCalls: 0, exactDescriptors: 0, storageReadCalls: 0, storageReadEntries: 0, peakRecentSourceBytes: 0}
        /** @type {Parameters<Database['_findMatchingPersistedTermEntryContentMetaBatch']>[0][]} */
        const descriptorBatches = []
        /** @type {Parameters<Database['_readTermEntryContentBytesDetailedBatch']>[0][]} */
        const storageRequestBatches = []
        /** @type {Array<{rows: number, stats: Record<string, number>}>} */
        const groupNativeStats = []
        let ownerExactMs = 0
        let cursor = 0
        const originalExact = database._findMatchingPersistedTermEntryContentMetaBatch.bind(database)
        database._findMatchingPersistedTermEntryContentMetaBatch = async (descriptors) => {
            ++counters.exactCalls
            counters.exactDescriptors += descriptors.length
            descriptorBatches.push(descriptors)
            const start = startTiming()
            try {
                return await originalExact(descriptors)
            } finally {
                addDuration(exact, endTiming(start))
            }
        }
        database._readTermEntryContentBytesDetailedBatch = async (requests) => {
            ++counters.storageReadCalls
            counters.storageReadEntries += requests.length
            storageRequestBatches.push(requests)
            return requests.map(({contentOffset, contentLength, contentDictName}) => {
                const entry = storage.get(contentOffset)
                if (!entry || contentDictName !== virtualDictName || entry.length !== contentLength) {
                    throw new Error('Exact matcher requested an invalid virtual content reference')
                }
                return {status: 'ok', bytes: entry.bytes}
            })
        }
        globalThis.gc?.()
        for (const chunk of chunks) {
            const beforeNativeStats = {...scanner.stats}
            const beforeResolve = startTiming()
            const dedup = await database._resolveArtifactTermContentDedup(chunk, true)
            addDuration(resolver, endTiming(beforeResolve))
            /** @type {Record<string, number>} */
            const delta = {}
            for (const [key, value] of Object.entries(scanner.stats)) {
                if (typeof value === 'number') {
                    delta[key] = value - /** @type {number} */ (beforeNativeStats[/** @type {keyof CanonicalScanner['stats']} */ (key)])
                }
            }
            groupNativeStats.push({rows: chunk.rowCount, stats: delta})
            const persisted = storePending(chunk, dedup, storage, cursor)
            cursor = persisted.cursor
            let resolvedDictNames = dedup.resolvedContentDictNames
            if (dedup.pendingContentCount > 0) {
                const beforePublish = startTiming()
                resolvedDictNames = database._publishArtifactTermContentMetadata({
                    ...dedup,
                    count: chunk.rowCount,
                    contentUniqueIndexList: chunk.contentUniqueIndexList ?? void 0,
                    pendingOffsets: persisted.pendingOffsets,
                    pendingLengths: persisted.pendingLengths,
                    pendingResolvedDictNames: virtualDictName,
                    useResolvedContentReferences: true,
                })
                addDuration(publication, endTiming(beforePublish))
            }
            assert.equal(resolvedDictNames, virtualDictName, 'Published dictionary mapping differs from virtual storage')
            counters.rows += chunk.rowCount
            counters.pendingHits += dedup.pendingHitCount
            counters.persistedHits += dedup.persistedHitCount
            counters.uniqueContent += dedup.pendingContentCount
            counters.exactFallbacks += dedup.exactFallbackCount
            counters.recentSourceHits += dedup.recentSourceHitCount ?? 0
            counters.peakRecentSourceBytes = Math.max(counters.peakRecentSourceBytes, database._recentTermContentSourceBatchBytes)
            ownerExactMs += /** @type {Resolution & {dedupExactCompareMs?: number}} */ (dedup).dedupExactCompareMs ?? 0
        }
        if (scanner.stats.fallbacks !== 0) { throw new Error(`Unexpected native canonical fallback: ${scanner.stats.fallbackReason}`) }
        if (database._termEntryContentMetaHashPairPendingCount !== 0) { throw new Error('Unpublished content metadata remains') }
        if (counters.rows !== fixture.fixture.termRows || counters.rows !== counters.pendingHits + counters.persistedHits + counters.uniqueContent) {
            throw new Error('Dedupe row accounting does not cover the full dictionary')
        }

        // Digest source descriptors and ordered exact requests only after all timers stop.
        const exactDescriptorHash = createHash('sha256')
        for (const batch of descriptorBatches) {
            exactDescriptorHash.update(JSON.stringify({count: batch.length}))
            for (const descriptor of batch) {
                const {hash1, hash2, contentBytes, primary} = descriptor
                exactDescriptorHash.update(JSON.stringify({hash1, hash2, length: contentBytes.byteLength, primary: typeof primary === 'undefined' ? null : {id: primary.id, offset: primary.offset, length: primary.length, dictName: primary.dictName}}))
                exactDescriptorHash.update(contentBytes)
            }
        }
        const exactDescriptorDigest = exactDescriptorHash.digest('hex')
        const storageRequestDigest = sha256(JSON.stringify(storageRequestBatches))
        // Complete equality checks and digests run after all measured phases.
        const resolved = createHash('sha256')
        const references = createHash('sha256').update(virtualDictName)
        const canonical = createHash('sha256').update(virtualDictName)
        const contentHeader = Buffer.alloc(12)
        const referenceHeader = Buffer.alloc(12)
        for (let index = 0; index < chunks.length; ++index) {
            const chunk = chunks[index]
            const source = fixture.chunks[index]
            const plan = chunk.contentDedupPlan
            if (plan.resolvedUniformDictName !== virtualDictName || plan.resolvedDictNames !== null) {
                throw new Error('Unexpected resolved content dictionary mapping')
            }
            for (let row = 0; row < chunk.rowCount; ++row) {
                const uniqueIndex = source.contentUniqueIndexList[row]
                if (plan.resolvedFlags[uniqueIndex] !== 1) { throw new Error('Unresolved source row') }
                const offset = plan.resolvedOffsets[uniqueIndex]
                const length = plan.resolvedLengths[uniqueIndex]
                const content = storage.get(offset)
                const at = row * 4
                const expectedOffset = source.contentMetaList[at]
                const expectedLength = source.contentMetaList[at + 1]
                if (!content || content.length !== length || length !== expectedLength || Buffer.compare(
                    content.bytes,
                    source.contentBytesBuffer.subarray(expectedOffset, expectedOffset + expectedLength),
                ) !== 0) {
                    throw new Error(`Resolved content differs from source at group ${index}, row ${row}`)
                }
                contentHeader.writeUInt32LE(length, 0)
                contentHeader.writeUInt32LE(source.contentMetaList[at + 2], 4)
                contentHeader.writeUInt32LE(source.contentMetaList[at + 3], 8)
                resolved.update(contentHeader).update(content.bytes)
                referenceHeader.writeDoubleLE(offset, 0)
                referenceHeader.writeUInt32LE(length, 8)
                references.update(referenceHeader)
            }
        }
        for (const content of storage.values()) {
            referenceHeader.writeDoubleLE(content.offset, 0)
            referenceHeader.writeUInt32LE(content.length, 8)
            contentHeader.writeUInt32LE(content.length, 0)
            contentHeader.writeUInt32LE(content.hash1, 4)
            contentHeader.writeUInt32LE(content.hash2, 8)
            canonical.update(referenceHeader).update(contentHeader).update(content.bytes)
        }
        const resolvedContentDigest = resolved.digest('hex')
        if (resolvedContentDigest !== fixture.sourceContentDigest) { throw new Error('Complete source/content digest mismatch') }
        return {
            resolver,
            exact,
            publication,
            ownerExactMs,
            counters,
            referenceDigest: references.digest('hex'),
            canonicalContentDigest: canonical.digest('hex'),
            resolvedContentDigest,
            nativeStats: {...scanner.stats},
            groupNativeStats,
            canonicalDescriptorDigest: fixture.canonicalDescriptorDigest,
            exactDescriptorDigest,
            storageRequestDigest,
            recentSourceCacheBudgetBytes: database._recentTermContentSourceCacheMaxBytes,
        }
    }
    return {
        execute,
        metadata: {
            scope: 'complete-canonical-dedup-resolver-with-exact-byte-virtual-storage',
            authoritativeWholeImportTiming: false,
            dictionary,
            sourceRoot,
            sourceGit,
            filesPerGroup: filesPerGroup[dictionary],
            groups: fixture.chunks.map((chunk) => ({rows: chunk.rowCount, uniqueContent: chunk.uniqueRowIndexes.length, sourceBytes: chunk.contentBytesBuffer.length})),
            deviceMemoryGiB,
            node: process.version,
            v8: process.versions.v8,
            archiveSha256: fixture.archiveSha256,
            lockSha256: fixture.lockSha256,
            sourceHashes: initialIdentity,
            runnerSourceHashes: initialRunnerIdentity,
            sourceContentDigest: fixture.sourceContentDigest,
            canonicalDescriptorDigest: fixture.canonicalDescriptorDigest,
            encodedSourceBytes: fixture.encodedSourceBytes,
        },
        verify: async () => {
            assert.deepEqual(await sourceIdentity(sourceRoot), initialIdentity, 'Source changed during fixed cohort')
            assert.deepEqual(sourceGitIdentity(sourceRoot), sourceGit, 'Checkout changed during fixed cohort')
            assert.deepEqual(await sourceIdentity(root, runnerFiles), initialRunnerIdentity, 'Runner changed during fixed cohort')
            loadDictionaryWasm(sourceRoot)
        },
    }
}

/**
 * @param {{referenceDigest: string, canonicalContentDigest: string, resolvedContentDigest: string, counters: object, canonicalDescriptorDigest: string, exactDescriptorDigest: string, storageRequestDigest: string}} result
 * @returns {object}
 */
function correctnessIdentity(result) {
    return {references: result.referenceDigest, canonical: result.canonicalContentDigest, resolved: result.resolvedContentDigest, counters: result.counters, descriptors: result.canonicalDescriptorDigest, exactDescriptors: result.exactDescriptorDigest, storageRequests: result.storageRequestDigest}
}

/**
 * @param {number[]} values
 * @returns {number}
 */
function median(values) {
    const sorted = [...values].sort((a, b) => a - b)
    return (sorted[Math.floor((sorted.length - 1) / 2)] + sorted[Math.floor(sorted.length / 2)]) / 2
}

// Four-arm fixed cohort. Source setup and complete fixture parsing are done once
// per source root; each replay owns a fresh database and virtual storage map.
// Both baseline arms share one source; both candidate arms share the other.
// No adapter instrumentation is loaded into either timed source.
const {values} = parseArgs({options: {
    'baseline-root': {type: 'string'},
    'source-root': {type: 'string'},
    'cache-dir': {type: 'string'},
    'out': {type: 'string'},
    'preflight': {type: 'boolean', default: false},
}})
for (const key of ['baseline-root', 'source-root', 'cache-dir', 'out']) {
    assert.equal(typeof values[key], 'string', `Missing --${key}`)
}
const roots = {baseline: path.resolve(values['baseline-root']), candidate: path.resolve(values['source-root'])}
const arms = {A: 'baseline', B: 'candidate', C: 'baseline', D: 'candidate'}
const planned = []
if (values.preflight) {
    for (const arm of 'AB') { planned.push({label: `preflight-${arm}`, arm, block: 0, warmup: true}) }
} else {
    for (let warmup = 0; warmup < 2; ++warmup) {
        for (const arm of ['ABCD', 'DCBA'][warmup]) {
            planned.push({label: `warmup-${warmup + 1}-${arm}`, arm, block: warmup, warmup: true})
        }
    }
    for (let block = 0; block < 24; ++block) {
        for (const arm of ['ABCD', 'BDAC', 'CADB', 'DCBA'][block % 4]) {
            planned.push({label: `block-${block + 1}-${arm}`, arm, block, warmup: false})
        }
    }
}
const report = {
    scope: 'Full canonical resolver component only; no browser or whole-import timing',
    primaryMetric: 'resolver.wallMs',
    nestedMetric: 'exact.wallMs overlaps resolver.wallMs',
    separateMetric: 'publication.wallMs excludes virtual writes and is outside resolver.wallMs',
    exclusions: ['ZIP inflation', 'parser', 'module compilation', 'compression', 'OPFS', 'virtual writes', 'complete output verification', 'worker transport', 'UI'],
    startedAt: new Date().toISOString(),
    preflight: values.preflight,
    arms,
    roots,
    planned,
    blocks: values.preflight ? 0 : 24,
    warmupsPerArm: values.preflight ? 1 : 2,
    maxRetries: 0,
    maxDroppedObservations: 0,
    noControlSubtraction: true,
    singleProcess: true,
    freshDatabasePerReplay: true,
    explicitGcBeforeEachResolverSequence: true,
    node: process.version,
    v8: process.versions.v8,
    hostBefore: getHostEnvironment(),
    observations: [],
    sources: {},
    complete: false,
}
await mkdir(path.dirname(values.out), {recursive: true})
const save = async () => {
    const temporary = `${values.out}.${process.pid}.tmp`
    await writeFile(temporary, JSON.stringify(report, null, 2) + '\n')
    await rename(temporary, values.out)
}
await save()
try {
    const replays = {}
    for (const [name, sourceRoot] of Object.entries(roots)) {
        replays[name] = await prepareReplay('jmdict', values['cache-dir'], sourceRoot, null)
        report.sources[name] = replays[name].metadata
    }
    const {baseline, candidate} = report.sources
    for (const key of ['archiveSha256', 'lockSha256', 'sourceContentDigest', 'canonicalDescriptorDigest', 'groups', 'encodedSourceBytes']) {
        assert.deepEqual(candidate[key], baseline[key], `Source fixture mismatch: ${key}`)
    }
    assert.equal(baseline.canonicalDescriptorDigest, '10b7674c9e0a44a49b3094389b3c5e63a7c32ca20d1877d29fc84f1f4d7a6828')
    let expectedOutput
    let expectedNativeWork
    for (const item of planned) {
        const observation = {...item, status: 'started'}
        report.observations.push(observation)
        await save()
        const result = await replays[arms[item.arm]].execute()
        assert.ok(!Object.keys(result.nativeStats).some((key) => key.startsWith('diagnostic')), 'Adapter instrumentation leaked into timed source')
        assert.equal(result.exactDescriptorDigest, '9df85741d5403934620f568bbb8450e27fc21eca727873bd59ea2a72040b3e8e')
        assert.equal(result.recentSourceCacheBudgetBytes, 48 * 1024 * 1024)
        if (typeof expectedOutput === 'undefined') {
            expectedOutput = correctnessIdentity(result)
            expectedNativeWork = result.nativeStats
        } else {
            assert.deepEqual(correctnessIdentity(result), expectedOutput, 'Full row/reference/content/path output changed')
            assert.deepEqual(result.nativeStats, expectedNativeWork, 'Native work counters changed')
        }
        observation.result = result
        observation.status = 'passed'
        await save()
        console.log(`${item.label}: resolver ${result.resolver.wallMs.toFixed(3)} ms; exact ${result.exact.wallMs.toFixed(3)} ms; publication ${result.publication.wallMs.toFixed(3)} ms`)
    }
    for (const replay of Object.values(replays)) { await replay.verify() }
    assert.equal(report.observations.length, planned.length)
    report.identitiesVerifiedAfter = true
    report.correctnessIdentity = expectedOutput
    report.nativeWork = expectedNativeWork
    report.hostAfter = getHostEnvironment()
    report.finishedAt = new Date().toISOString()
    report.complete = true
    await save()
} catch (error) {
    report.error = String(error)
    report.finishedAt = new Date().toISOString()
    report.hostAfter = getHostEnvironment()
    await save()
    throw error
}
