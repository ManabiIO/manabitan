#!/usr/bin/env python3
"""Summarize every fixed native-config observation without exclusions or pooling."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import random
import statistics


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def distribution(values):
    return {"min": min(values), "median": statistics.median(values), "max": max(values), "values": values}


def compare(pairs):
    changes = [100 * (candidate / baseline - 1) for baseline, candidate in pairs]
    rng = random.Random(20261120)
    resamples = sorted(statistics.median(rng.choices(changes, k=len(changes))) for _ in range(10000))
    return {
        "pairs": len(pairs),
        "pairedChangesPercent": changes,
        "medianPairedChangePercent": statistics.median(changes),
        "medianPairedChangeMs": statistics.median(candidate - baseline for baseline, candidate in pairs),
        "equalWorkChangePercent": 100 * (sum(candidate for _, candidate in pairs) / sum(baseline for baseline, _ in pairs) - 1),
        "fasterPairs": sum(candidate < baseline for baseline, candidate in pairs),
        "worstPairPercent": max(changes),
        "descriptiveBootstrap95Percent": [resamples[250], resamples[9749]],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", type=Path)
    parser.add_argument("frozen", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    assert not args.output.exists(), "Refusing to overwrite a previous analysis"
    raw = json.loads(args.results.read_text())
    frozen = json.loads(args.frozen.read_text())
    assert raw["complete"] and raw["identitiesVerifiedAfter"] and not raw["preflight"]
    assert len(raw["observations"]) == len(raw["planned"]) == frozen["plannedObservations"] == 104
    assert raw["correctnessIdentity"] == frozen["expectedCorrectnessIdentity"]
    assert raw["nativeWork"] == frozen["expectedNativeWork"]
    assert raw["sources"] == frozen["sourceIdentities"]
    indexed = {}
    for planned, observed in zip(raw["planned"], raw["observations"]):
        assert observed["status"] == "passed"
        assert all(observed[key] == value for key, value in planned.items())
        if not planned["warmup"]:
            key = (planned["block"], planned["arm"])
            assert key not in indexed
            indexed[key] = observed["result"]
    assert len(indexed) == frozen["measuredObservations"] == 96
    assert sum(observed["warmup"] for observed in raw["observations"]) == 8
    metrics = [frozen["primaryMetric"], *frozen["secondaryMetrics"]]
    arm_distributions = {}
    comparisons = {}
    for metric in metrics:
        phase, field = metric.split(".")
        values = {arm: [indexed[(block, arm)][phase][field] for block in range(24)] for arm in "ABCD"}
        assert all(math.isfinite(value) and value > 0 for arm in values.values() for value in arm)
        arm_distributions[metric] = {arm: distribution(arm_values) for arm, arm_values in values.items()}
        comparisons[metric] = {
            numerator + "/" + denominator: compare(list(zip(values[denominator], values[numerator])))
            for numerator, denominator in [("C", "A"), ("D", "B"), ("B", "A"), ("D", "A")]
        }
    summary = {
        "scope": raw["scope"],
        "primaryMetric": frozen["primaryMetric"],
        "baselineCommit": frozen["candidate"]["baselineCommit"],
        "candidateCommit": frozen["candidate"]["candidateCommit"],
        "sourceResultsSha256": digest(args.results),
        "frozenPlanSha256": digest(args.frozen),
        "analysisScriptSha256": digest(Path(__file__)),
        "startedAt": raw["startedAt"],
        "finishedAt": raw["finishedAt"],
        "observations": 104,
        "measuredObservations": 96,
        "warmups": 8,
        "allOutputAndWorkOraclesPassed": True,
        "identitiesVerifiedAfter": True,
        "armDistributions": arm_distributions,
        "comparisons": comparisons,
        "method": {
            "noRetries": True,
            "noExclusions": True,
            "noPooling": True,
            "noControlSubtraction": True,
            "bootstrapResamples": 10000,
            "bootstrapSeed": 20261120,
            "intervalsAreDescriptive": True,
        },
        "limitations": [
            "Single local Node/V8 process with two source preparations outside timing",
            "Seven-bank component grouping differs from the browser planner",
            "Exact-byte virtual storage excludes OPFS, envelope checksums and decompression",
            "Exact time overlaps the resolver; publication is a separate component",
            "No full-import, browser, concurrency or memory-performance claim",
            "Intervals do not correct temporal dependence or multiple comparisons",
        ],
    }
    args.output.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"primary": comparisons[frozen["primaryMetric"]], "armMediansMs": {arm: values["median"] for arm, values in arm_distributions[frozen["primaryMetric"]].items()}}, indent=2))


if __name__ == "__main__":
    main()
