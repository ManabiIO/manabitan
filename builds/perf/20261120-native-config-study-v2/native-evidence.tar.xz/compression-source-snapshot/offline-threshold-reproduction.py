#!/usr/bin/env python3
"""Posthoc offline reproduction of frozen metadata; no Zstd execution or timing."""

import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re


AUDIT_SHA256 = '4cc154c39c18683d32dfb66e25d1e48457ab7eca60a7326b688cafd2b7b04c5b'
MANIFEST_SHA256 = '4629920d51385465dfa1d5afd3230c88d0bc3a7d3ccf23d5e0379d1b1425ab39'
UPSTREAM = '82d322c4973d9e2968d94047a40892bc6d9a9bdf'


def check(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(content):
    return hashlib.sha256(content).hexdigest()


def blob_id(content):
    return hashlib.sha1(b'blob ' + str(len(content)).encode('ascii') + b'\0' + content).hexdigest()


def compact(source):
    return re.sub(r'\s+', '', source)


def reproduce(root):
    mapping_bytes = (root / 'source-snapshot-receipt.json').read_bytes()
    mapping = json.loads(mapping_bytes)
    verified = {}
    for relative, expected in mapping['files'].items():
        retained = Path(relative)
        check(not retained.is_absolute() and '..' not in retained.parts, 'Invalid retained path')
        data = (root / retained).read_bytes()
        actual = {'sha256': sha256(data), 'bytes': len(data)}
        check(actual['sha256'] == expected['sha256'] and actual['bytes'] == expected['bytes'], 'Retained bytes differ: ' + relative)
        if 'gitBlob' in expected:
            actual['gitBlob'] = blob_id(data)
            check(actual['gitBlob'] == expected['gitBlob'], 'Retained Git blob differs: ' + relative)
        verified[relative] = actual

    audit_bytes = (root / 'inputs/original-compression-audit-receipt.json').read_bytes()
    manifest_bytes = (root / 'inputs/real-fixture-manifest.json').read_bytes()
    check(sha256(audit_bytes) == AUDIT_SHA256, 'Frozen audit receipt differs')
    check(sha256(manifest_bytes) == MANIFEST_SHA256, 'Frozen fixture manifest differs')
    audit = json.loads(audit_bytes)
    manifest = json.loads(manifest_bytes)
    check(audit['upstream']['commit'] == mapping['upstreamCommit'] == UPSTREAM, 'Wrong upstream identity')
    check(len(audit['upstream']['sources']) == 7, 'Expected seven inspected upstream files')
    for relative, expected in audit['upstream']['sources'].items():
        actual = verified['upstream/' + relative]
        check(all(actual[key] == expected[key] for key in ('sha256', 'bytes', 'gitBlob')), 'Snapshot differs from original audit source: ' + relative)

    source = (root / 'upstream/lib/compress/zstd_compress.c').read_text()
    cutoff_match = re.search(r'^#define ZSTD_USE_CDICT_PARAMS_SRCSIZE_CUTOFF \((\d+) KB\)$', source, re.M)
    multiplier_match = re.search(r'^#define ZSTD_USE_CDICT_PARAMS_DICTSIZE_MULTIPLIER \((\d+)ULL\)$', source, re.M)
    check(cutoff_match is not None and multiplier_match is not None, 'Pinned source constants missing')
    cutoff = int(cutoff_match.group(1)) * 1024
    multiplier = int(multiplier_match.group(1))
    condition = '''if ( (cdict)
      && (cdict->dictContentSize > 0)
      && ( pledgedSrcSize < ZSTD_USE_CDICT_PARAMS_SRCSIZE_CUTOFF
        || pledgedSrcSize < cdict->dictContentSize * ZSTD_USE_CDICT_PARAMS_DICTSIZE_MULTIPLIER
        || pledgedSrcSize == ZSTD_CONTENTSIZE_UNKNOWN
        || cdict->compressionLevel == 0)
      && (params->attachDictPref != ZSTD_dictForceLoad) ) {
        return ZSTD_resetCCtx_usingCDict(cctx, cdict, params, pledgedSrcSize, zbuff);
    }'''
    check(compact(condition) in compact(source), 'Pinned source predicate differs from transcription')
    creator_start = source.index('ZSTD_CDict* ZSTD_createCDict(const void* dict, size_t dictSize, int compressionLevel)')
    creator_end = source.index('ZSTD_CDict* ZSTD_createCDict_byReference', creator_start)
    check('cdict->compressionLevel=(compressionLevel==0)?ZSTD_CLEVEL_DEFAULT:compressionLevel;' in compact(source[creator_start:creator_end]), 'Ordinary CDict level assignment differs')
    check('cdict->dictContentSize=dictSize;' in compact(source), 'Dictionary-size assignment missing')
    check('ZSTD_compressBegin_usingCDict_internal(cctx,cdict,fParams,srcSize)' in compact(source), 'One-shot CDict does not pass known source size')

    dictionary = audit['dictionary']
    dictionary_size = dictionary['bytes']
    dictionary_source = audit['baseline']['sources']['dev/data/zstd-dicts/jmdict.zdict']
    check(dictionary_source['bytes'] == dictionary_size == 16384 and dictionary_source['sha256'] == dictionary['sha256'], 'Dictionary metadata disagrees within frozen receipt')
    check(dictionary['compressionLevel'] == -1 and dictionary_size > 0, 'Wrong ordinary dictionary assumptions')
    assumptions = audit['conditionAssumptions']
    check(assumptions == {
        'nonemptyCDict': True, 'forceLoadDisabled': True,
        'oneShotKnownSourceSize': True, 'ordinaryCreateCDictStoredLevel': -1,
        'sourceCutoffBytes': cutoff, 'dictionaryMultiplier': multiplier,
        'dictionaryCutoffBytes': dictionary_size * multiplier,
        'comparisonsAreStrict': True, 'advancedCDictExcluded': True,
    }, 'Original audit assumptions differ')
    check(len(manifest['blocks']) == 28 and manifest['sourceCommit'] == audit['baseline']['commit'], 'Wrong fixture source or count')
    blocks = []
    for index, block in enumerate(manifest['blocks']):
        size = block['uncompressedLength']
        check(type(size) is int and size > 0, 'Invalid decoded input length')
        predicates = {
            'sourceStrictlyBelow128KiB': size < cutoff,
            'sourceStrictlyBelowSixDictionaryLengths': size < dictionary_size * multiplier,
            'unknownPledgedSourceSize': False,
            'storedCompressionLevelZero': False,
        }
        reused = any(predicates.values())
        blocks.append({
            'index': index, 'sourceBytes': size,
            'compressedEnvelopeBytes': block['length'],
            'sourceSha256': block['uncompressedSha256'],
            'predicates': predicates,
            'standardCDictReusesPreparedState': reused,
            'path': 'resetCCtx_usingCDict' if reused else 'resetCCtx_internal + compress_insertDictionary',
        })
    check(blocks == audit['fixture']['blocks'], 'Posthoc classifications differ from frozen audit')
    sizes = [block['sourceBytes'] for block in blocks]
    aggregate = {
        'blockCount': len(blocks), 'decodedBytes': sum(sizes),
        'minimumDecodedBlockBytes': min(sizes), 'maximumDecodedBlockBytes': max(sizes),
        'standardCDictPreparedReuseBlockCount': sum(block['standardCDictReusesPreparedState'] for block in blocks),
    }
    check(all(audit['fixture'][key] == value for key, value in aggregate.items()), 'Aggregate differs from frozen audit')
    check(aggregate['standardCDictPreparedReuseBlockCount'] == 0, 'Unexpected prepared-state reuse')
    return {
        'schemaVersion': 1, 'ok': True,
        'kind': 'Posthoc offline source and metadata reproduction, not a compression or timing experiment',
        'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'sourceSnapshotReceiptSha256': sha256(mapping_bytes),
        'originalAuditReceiptSha256': AUDIT_SHA256,
        'fixtureManifestSha256': MANIFEST_SHA256,
        'upstreamCommit': UPSTREAM,
        'verifiedStaticFileCount': len(verified),
        'verifiedFiles': verified,
        'sourcePredicateMatchesTranscription': True,
        'sourceCutoffBytes': cutoff,
        'dictionaryCutoffBytes': dictionary_size * multiplier,
        'dictionaryMetadataSource': 'Original frozen audit receipt; dictionary bytes are not needed or recompressed here',
        'originalAuditBlockRecordsMatchExactly': True,
        'aggregate': aggregate,
        'blocks': blocks,
        'limitations': [
            'Checked transcription of pinned C condition; no C compilation or native execution.',
            'Seven-bank component fixture, not the browser import planner.',
            'No compressed-byte equivalence, timing, or speedup claim.',
        ],
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    check(not args.output.exists(), 'Refusing to overwrite an earlier reproduction')
    result = reproduce(Path(__file__).resolve().parent)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'ok': result['ok'], 'output': str(args.output), 'sha256': sha256(args.output.read_bytes()), 'aggregate': result['aggregate']}, indent=2))


if __name__ == '__main__':
    main()
