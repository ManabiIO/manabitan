# Portable compression audit source snapshot

This directory is a **posthoc reproduction supplement** to the unchanged
2026-11-20 compression audit. It contains no new compression or performance
experiment. It was assembled after that audit's receipt was frozen.

`upstream/` preserves the exact seven upstream files indexed by the original
audit receipt, including their original notice comments and the upstream BSD
`LICENSE`. The separately referenced upstream GPLv2 `COPYING` text is included
as an additional license document. All eight files were read from Zstd commit
`82d322c4973d9e2968d94047a40892bc6d9a9bdf` and verified against their Git blob IDs.
The original seven also match every size and SHA256 in the frozen audit receipt.
This is an inspection snapshot, not a complete buildable Zstd checkout.

`inputs/original-compression-audit-receipt.json` and
`inputs/real-fixture-manifest.json` are exact copies of existing frozen evidence.
The dictionary length and identity come from the original identity-checked
dictionary receipt. No dictionary compression or fixture decompression is needed
to classify these known decoded lengths.

`source-snapshot-receipt.json` maps each retained file to its original identity
and records verification of the unchanged original three audit files.

## Offline reproduction

From any location with Python 3.9 or newer, run:

```sh
python3 /path/to/20261120-compression-source-snapshot/offline-threshold-reproduction.py --output /path/to/new-result.json
```

The script uses only Python's standard library. It requires no Git checkout,
network, WASM runtime, compiler, dictionary archive, or native Zstd execution.
It checks every retained static file against the mapping receipt, recomputes Git
blob IDs, validates the seven original source identities against the frozen
audit receipt, checks the pinned C predicate and parses its two threshold
constants, then recomputes every one of the 28 classifications. It requires exact
agreement with the original audit's block records and aggregate lengths. This is
a checked transcription of the pinned condition, not an independent C compiler
evaluation or an output-byte oracle.

The saved `posthoc-reproduction.json` is the complete result of one offline
reproduction. It reports **zero of 28 blocks eligible for ordinary CDict prepared
state reuse**. The fixture remains the seven-bank component corpus described in
its own manifest; it is not a new browser import observation.

Original audit documents were not edited. No aggregate archive was created.
