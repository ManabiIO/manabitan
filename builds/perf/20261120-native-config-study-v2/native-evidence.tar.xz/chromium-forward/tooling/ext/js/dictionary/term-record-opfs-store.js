/*
 * Copyright (C) 2026 Manabitan authors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

import {openSyncImportIndexWriter, SyncImportIndexWriter} from './term-record-import-index-writer.js';
import {reportDiagnostics} from '../core/diagnostics-reporter.js';
import {safePerformance} from '../core/safe-performance.js';
import {toError} from '../core/to-error.js';
import {
    RAW_TERM_CONTENT_COMPRESSED_SHARED_GLOSSARY_DICT_NAME,
    RAW_TERM_CONTENT_DICT_NAME,
    RAW_TERM_CONTENT_SHARED_GLOSSARY_DICT_NAME,
    RAW_TERM_CONTENT_TOKEN_DICT_NAME,
} from './raw-term-content.js';
import {
    appendExactRowMatches,
    appendPrefixIdMatches,
    encodePersistedTermLookupIndex,
    encodePersistedTermLookupIndexFromPreinternedPlan,
    findExactKey,
    findExactRows,
    findPrefixRows,
    findSequenceRows,
    getPersistedTermLookupBaseBytes,
    getPersistedTermKeyBytes,
    getPersistedTermSequence,
    hashTermLookupKeyBytes,
    parseChecksummedPersistedTermLookupIndex,
    rebuildPersistedTermLookupIndexFromBase,
    splitPersistedTermLookupIndex,
    warmPersistedTermPrefixIndex,
} from './term-lookup-index.js';
import {
    hasCompletePreparedTermLookupIndexes,
    MAX_PREPARED_TERM_LOOKUP_INDEX_ROWS,
    prepareTermLookupIndexesFromPreinternedPlan,
} from './term-lookup-index-preparation.js';
import {
    compactTermRecordPreinternedPlan,
    getTermRecordPreinternedPlan,
    hasCompleteTermRecordPreinternedPlan,
    selectTermRecordPreinternedPlan,
    sliceTermRecordPreinternedPlan,
} from './term-record-preinterned-plan.js';

const SHARD_DIRECTORY_NAME = 'manabitan-term-records';
const SHARD_FILE_PREFIX = 'dict-';
const SHARD_FILE_SUFFIX = '.mbtr';
const LOOKUP_INDEX_FILE_SUFFIX = '.mbti';
const SHARD_FILE_CONTENT_DICT_SEPARATOR = '|';
const SHARD_FILE_SEGMENT_SEPARATOR = '^';
const BINARY_MAGIC_TEXT = 'MBTRD16X';
const BINARY_MAGIC_BYTES = 8;
const SHARD_GENERATION_BYTES = 16;
const BINARY_HEADER_PREFIX_BYTES = BINARY_MAGIC_BYTES + SHARD_GENERATION_BYTES;
const U32_NULL = 0xffffffff;
const MAX_TERM_RECORD_ID = U32_NULL - 1;
const MAX_CONTENT_OFFSET_DELTA = U32_NULL - 1;
const U32_RANGE = 0x100000000;
const U16_NULL = 0xffff;
const DEFAULT_FLUSH_THRESHOLD_BYTES = 8 * 1024 * 1024;
const LOW_MEMORY_FLUSH_THRESHOLD_BYTES = 8 * 1024 * 1024;
const PREFIX_WARM_YIELD_BUDGET_MS = 8;
const HIGH_MEMORY_FLUSH_THRESHOLD_BYTES = 16 * 1024 * 1024;
const DEFAULT_QUEUED_WRITE_BUDGET_BYTES = 64 * 1024 * 1024;
const LOW_MEMORY_QUEUED_WRITE_BUDGET_BYTES = 24 * 1024 * 1024;
const HIGH_MEMORY_QUEUED_WRITE_BUDGET_BYTES = 64 * 1024 * 1024;
const DEFAULT_WRITE_COALESCE_TARGET_BYTES = 4 * 1024 * 1024;
const LOW_MEMORY_WRITE_COALESCE_TARGET_BYTES = 1024 * 1024;
const HIGH_MEMORY_WRITE_COALESCE_TARGET_BYTES = 16 * 1024 * 1024;
const LARGE_IMPORT_EXPECTED_BYTES_THRESHOLD = 512 * 1024 * 1024;
const LARGE_IMPORT_WRITE_COALESCE_TARGET_BYTES = 64 * 1024 * 1024;
const WRITE_COALESCE_MAX_CHUNKS = 512;
const MAX_SHARD_SEGMENT_FILE_BYTES = 1024 * 1024 * 1024;
const SHARD_LOAD_CONCURRENCY = 3;
const LOOKUP_INDEX_MAGIC_TEXT = 'MBTIDX11';
const LOOKUP_INDEX_MAGIC_BYTES = 8;
const LOOKUP_INDEX_FILE_HEADER_BYTES = 40;
const LOOKUP_INDEX_CHUNK_HEADER_BYTES = 40;
const LOOKUP_INDEX_RECORD_FIELDS_BYTES = 12;
const LOOKUP_INDEX_RECORD_FIELDS_FORMAT_LEGACY = 1;
const LOOKUP_INDEX_RECORD_FIELDS_FORMAT_COMPACT = 2;
const LOOKUP_INDEX_RECORD_FIELDS_FORMAT_FLOAT64_SCORE = 3;
const FLOAT64_SCORE_RECORD_FIELDS_BYTES = 16;
const COMPACT_RECORD_FIELDS_MAGIC = 0x3246524d;
const COMPACT_RECORD_FIELDS_HEADER_BYTES = 16;
const COMPACT_RECORD_FIELDS_BYTES_PER_ROW = 8;
const COMPACT_SCORE_TABLE_RADIUS = 256;
const COMPACT_SCORE_TABLE_MIN_ROWS = 64;
const LOOKUP_INDEX_FLUSH_THRESHOLD_BYTES = 4 * 1024 * 1024;
const EAGER_IMPORT_LOOKUP_INDEX_WRITE_START_BYTES = 2 * 1024 * 1024;
const MAX_COMPACT_LOOKUP_INDEX_ROWS = MAX_PREPARED_TERM_LOOKUP_INDEX_ROWS;
const PERSISTED_ONLY_IMPORT_ROW_THRESHOLD = 250000;
const STORAGE_READ_RETRY_COUNT = 2;
const REPAIR_YIELD_BUDGET_MS = 8;
const MAX_LOOKUP_INDEX_OVERHEAD_BYTES = 64 * 1024 * 1024;
const MAX_LOOKUP_INDEX_BYTES_PER_RECORD = 512;
const EMPTY_BYTES = new Uint8Array(0);

/**
 * Parses an on-disk decimal filename field without allowing Number rounding,
 * prefixes, signs, whitespace, or other non-canonical spellings.
 * @param {string} value
 * @returns {number|null}
 */
function parseCanonicalSafeInteger(value) {
    if (!/^(?:0|[1-9][0-9]*)$/.test(value)) { return null; }
    const parsed = Number(value);
    return Number.isSafeInteger(parsed) && String(parsed) === value ? parsed : null;
}

/**
 * @param {Uint8Array} content
 * @param {number} offset
 * @param {number} count
 * @param {number} format
 * @returns {number}
 * @throws {Error}
 */
function getRecordFieldsByteLength(content, offset, count, format) {
    if (format === LOOKUP_INDEX_RECORD_FIELDS_FORMAT_LEGACY) {
        return count * LOOKUP_INDEX_RECORD_FIELDS_BYTES;
    }
    if (format === LOOKUP_INDEX_RECORD_FIELDS_FORMAT_FLOAT64_SCORE) {
        return count * FLOAT64_SCORE_RECORD_FIELDS_BYTES;
    }
    if (
        format !== LOOKUP_INDEX_RECORD_FIELDS_FORMAT_COMPACT ||
        offset < 0 ||
        (offset + COMPACT_RECORD_FIELDS_HEADER_BYTES) > content.byteLength
    ) {
        throw new Error('Invalid compact term-record fields header');
    }
    const view = new DataView(
        content.buffer,
        content.byteOffset + offset,
        COMPACT_RECORD_FIELDS_HEADER_BYTES,
    );
    const scoreCount = view.getUint32(8, true);
    if (
        view.getUint32(0, true) !== COMPACT_RECORD_FIELDS_MAGIC ||
        view.getUint32(4, true) !== count ||
        scoreCount === 0 ||
        scoreCount >= U16_NULL ||
        view.getUint32(12, true) !== LOOKUP_INDEX_RECORD_FIELDS_FORMAT_COMPACT
    ) {
        throw new Error('Invalid compact term-record fields dimensions');
    }
    const byteLength = COMPACT_RECORD_FIELDS_HEADER_BYTES +
    (scoreCount * 4) +
    (count * COMPACT_RECORD_FIELDS_BYTES_PER_ROW);
    if (!Number.isSafeInteger(byteLength)) {
        throw new Error('Compact term-record fields length is unsafe');
    }
    return byteLength;
}

/**
 * @param {Uint8Array} bytes
 * @param {number} count
 * @returns {{offsets: Uint32Array, lengths: Uint16Array, scoreKeys: Uint16Array, scores: Int32Array}}
 * @throws {Error}
 */
function parseCompactRecordFields(bytes, count) {
    const byteLength = getRecordFieldsByteLength(bytes, 0, count, LOOKUP_INDEX_RECORD_FIELDS_FORMAT_COMPACT);
    if (byteLength !== bytes.byteLength) {
        throw new Error('Compact term-record fields length is invalid');
    }
    const header = new Uint32Array(bytes.buffer, bytes.byteOffset, COMPACT_RECORD_FIELDS_HEADER_BYTES / 4);
    const scoreCount = header[2];
    let cursor = COMPACT_RECORD_FIELDS_HEADER_BYTES;
    const scores = new Int32Array(bytes.buffer, bytes.byteOffset + cursor, scoreCount);
    cursor += scoreCount * 4;
    const offsets = new Uint32Array(bytes.buffer, bytes.byteOffset + cursor, count);
    cursor += count * 4;
    const lengths = new Uint16Array(bytes.buffer, bytes.byteOffset + cursor, count);
    cursor += count * 2;
    const scoreKeys = new Uint16Array(bytes.buffer, bytes.byteOffset + cursor, count);
    for (const scoreKey of scoreKeys) {
        if (scoreKey >= scoreCount) {
            throw new Error('Compact term-record score key is invalid');
        }
    }
    return {offsets, lengths, scoreKeys, scores};
}

/**
 * @param {number} score
 * @returns {boolean}
 */
function isLosslessInt32Score(score) {
    return (
        Number.isInteger(score) &&
        score >= -0x80000000 &&
        score <= 0x7fffffff &&
        !Object.is(score, -0)
    );
}

/**
 * @param {Uint8Array} bytes
 * @param {number} count
 * @param {number} format
 * @param {number} contentOffsetBase
 * @returns {{offsets: Uint32Array, lengths: Uint16Array, scoreKeys: Uint16Array, scores: Int32Array}|null}
 * @throws {Error}
 */
function validateRecordFields(bytes, count, format, contentOffsetBase) {
    const compactFields = format === LOOKUP_INDEX_RECORD_FIELDS_FORMAT_COMPACT ?
        parseCompactRecordFields(bytes, count) :
        null;
    if (contentOffsetBase <= Number.MAX_SAFE_INTEGER - MAX_CONTENT_OFFSET_DELTA) {
        return compactFields;
    }
    const fixedView = compactFields === null ?
        new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength) :
        null;
    const fixedRowBytes = format === LOOKUP_INDEX_RECORD_FIELDS_FORMAT_FLOAT64_SCORE ?
        FLOAT64_SCORE_RECORD_FIELDS_BYTES :
        LOOKUP_INDEX_RECORD_FIELDS_BYTES;
    for (let row = 0; row < count; ++row) {
        const contentOffsetDelta = compactFields === null ?
            /** @type {DataView} */ (fixedView).getUint32(row * fixedRowBytes, true) :
            compactFields.offsets[row];
        if (
            contentOffsetDelta !== U32_NULL &&
            !Number.isSafeInteger(contentOffsetBase + contentOffsetDelta)
        ) {
            throw new Error('Term-record content offset is unsafe');
        }
    }
    return compactFields;
}

/**
 * @param {{fixedContentOffsetBase?: number, fixedContentLength?: number, resolvedContentReferences?: {uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}}} chunk
 * @param {number} count
 * @returns {boolean}
 */
function hasFixedContentSpan(chunk, count) {
    return (
        count > 0 &&
        typeof chunk.fixedContentOffsetBase === 'number' &&
        Number.isFinite(chunk.fixedContentOffsetBase) &&
        chunk.fixedContentOffsetBase >= 0 &&
        typeof chunk.fixedContentLength === 'number' &&
        Number.isFinite(chunk.fixedContentLength) &&
        chunk.fixedContentLength >= 0
    );
}

/**
 * @param {{fixedContentOffsetBase?: number, fixedContentLength?: number, resolvedContentReferences?: {uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}}} chunk
 * @param {number[]|Uint32Array|Float64Array} contentOffsets
 * @param {number} index
 * @param {boolean} [useFixedContentSpan] Selected within the current synchronous batch.
 * @returns {number}
 * @throws {RangeError}
 */
function getArtifactContentOffset(chunk, contentOffsets, index, useFixedContentSpan = hasFixedContentSpan(chunk, index + 1)) {
    if (useFixedContentSpan) {
        return /** @type {number} */ (chunk.fixedContentOffsetBase) + (index * /** @type {number} */ (chunk.fixedContentLength));
    }
    const references = chunk.resolvedContentReferences;
    if (typeof references === 'object' && references !== null) {
        const uniqueIndex = references.uniqueIndexList[index];
        if (uniqueIndex >= references.offsets.length) {
            throw new RangeError(`Invalid resolved term content reference index: ${uniqueIndex}`);
        }
        return references.offsets[uniqueIndex];
    }
    return contentOffsets[index];
}

/**
 * @param {{fixedContentLength?: number, resolvedContentReferences?: {uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}}} chunk
 * @param {number[]|Uint32Array} contentLengths
 * @param {number} index
 * @returns {number}
 * @throws {RangeError}
 */
function getArtifactContentLength(chunk, contentLengths, index) {
    if (typeof chunk.fixedContentLength === 'number') { return chunk.fixedContentLength; }
    const references = chunk.resolvedContentReferences;
    if (typeof references === 'object' && references !== null) {
        const uniqueIndex = references.uniqueIndexList[index];
        if (uniqueIndex >= references.lengths.length) {
            throw new RangeError(`Invalid resolved term content reference index: ${uniqueIndex}`);
        }
        return references.lengths[uniqueIndex];
    }
    return contentLengths[index];
}

/**
 * @param {{resolvedContentReferences?: {uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}}} chunk
 * @param {number} count
 * @returns {boolean}
 */
function hasResolvedContentReferences(chunk, count) {
    const references = chunk.resolvedContentReferences;
    return (
        typeof references === 'object' &&
        references !== null &&
        references.uniqueIndexList instanceof Uint32Array &&
        references.uniqueIndexList.length >= count &&
        references.offsets instanceof Float64Array &&
        references.lengths instanceof Uint32Array &&
        references.offsets.length === references.lengths.length
    );
}

/**
 * @param {{resolvedContentReferences?: {uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}}} chunk
 * @param {number} start
 * @param {number} end
 * @returns {{uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}|undefined}
 */
function sliceResolvedContentReferences(chunk, start, end) {
    const references = chunk.resolvedContentReferences;
    if (typeof references !== 'object' || references === null) { return void 0; }
    return {
        uniqueIndexList: references.uniqueIndexList.subarray(start, end),
        offsets: references.offsets,
        lengths: references.lengths,
    };
}

/**
 * Reconstructs parser string offsets only for small imports which retain
 * materialized records. Persisted-only imports do not need this metadata.
 * @param {Uint16Array|undefined} lengths
 * @param {number} byteLength
 * @returns {Uint32Array|null}
 */
function reconstructTermStringOffsets(lengths, byteLength) {
    if (!(lengths instanceof Uint16Array) || lengths.length === 0) { return null; }
    const offsets = new Uint32Array(lengths.length);
    let cursor = 0;
    for (let i = 0; i < lengths.length; ++i) {
        const length = lengths[i];
        if (length <= 0 || cursor > byteLength - length) { return null; }
        offsets[i] = cursor;
        cursor += length;
    }
    return cursor === byteLength ? offsets : null;
}

/**
 * @param {DataView} view
 * @param {number} offset
 * @param {number} value
 * @throws {RangeError} If value is outside the non-negative safe integer range.
 */
function writeSafeU64Le(view, offset, value) {
    if (!Number.isSafeInteger(value) || value < 0) {
        throw new RangeError(`Invalid unsigned 64-bit safe integer: ${value}`);
    }
    const high = Math.floor(value / U32_RANGE);
    const low = value - (high * U32_RANGE);
    view.setUint32(offset, low, true);
    view.setUint32(offset + 4, high, true);
}

/**
 * @param {DataView} view
 * @param {number} offset
 * @returns {number}
 * @throws {RangeError} If the decoded value is outside the safe integer range.
 */
function readSafeU64Le(view, offset) {
    const low = view.getUint32(offset, true);
    const high = view.getUint32(offset + 4, true);
    const value = low + (high * U32_RANGE);
    if (!Number.isSafeInteger(value)) {
        throw new RangeError('Term content offset base exceeds the JavaScript safe integer range');
    }
    return value;
}

/**
 * @param {number} value
 * @throws {RangeError} If value is not a supported content offset.
 */
function validateContentOffset(value) {
    if (value !== -1 && (!Number.isSafeInteger(value) || value < 0)) {
        throw new RangeError(`Invalid term content offset: ${value}`);
    }
}

/**
 * @param {number} value
 * @throws {RangeError} If value is not a supported content length.
 */
function validateContentLength(value) {
    if (value !== -1 && (!Number.isSafeInteger(value) || value < 0 || value >= U32_NULL)) {
        throw new RangeError(`Invalid term content length: ${value}`);
    }
}

/**
 * @param {number[]} offsets
 * @returns {number}
 * @throws {RangeError} If an offset is invalid.
 */
function getContentOffsetBase(offsets) {
    let base = Number.POSITIVE_INFINITY;
    for (const offset of offsets) {
        validateContentOffset(offset);
        if (offset >= 0 && offset < base) { base = offset; }
    }
    return base === Number.POSITIVE_INFINITY ? 0 : base;
}

/**
 * @param {number} offset
 * @param {number} base
 * @returns {number}
 * @throws {RangeError} If the offset is outside the encodable chunk range.
 */
function getContentOffsetDelta(offset, base) {
    if (offset < 0) { return U32_NULL; }
    const delta = offset - base;
    if (!Number.isSafeInteger(delta) || delta < 0 || delta > MAX_CONTENT_OFFSET_DELTA) {
        throw new RangeError(`Term content offset ${offset} is outside the encodable chunk range for base ${base}`);
    }
    return delta;
}

/**
 * @param {Uint8Array} bytes
 * @returns {number}
 */
function hashLookupIndexBytes(bytes) {
    return hashTermLookupKeyBytes(bytes);
}

/**
 * @param {Uint8Array} a
 * @param {Uint8Array} b
 * @returns {boolean}
 */
function bytesEqual(a, b) {
    if (a.byteLength !== b.byteLength) { return false; }
    for (let i = 0; i < a.byteLength; ++i) {
        if (a[i] !== b[i]) { return false; }
    }
    return true;
}

/**
 * @param {Array<{expressionBytes: Uint8Array, readingBytes: Uint8Array|null, sequence: number|null}>} rows
 * @returns {Uint8Array}
 * @throws {RangeError} If an indexed string is too large for the sidecar format.
 */
const ENTRY_CONTENT_DICT_NAME_CODE_RAW = 0;
const ENTRY_CONTENT_DICT_NAME_CODE_RAW_V2 = 1;
const ENTRY_CONTENT_DICT_NAME_CODE_RAW_V3 = 2;
const ENTRY_CONTENT_DICT_NAME_CODE_RAW_V4 = 3;
const ENTRY_CONTENT_DICT_NAME_CODE_JMDICT = 4;
const ENTRY_CONTENT_DICT_NAME_CODE_RAW_V6 = 5;
const ENTRY_CONTENT_DICT_NAME_CODE_CUSTOM = 0xff;
const ENTRY_CONTENT_DICT_NAME_VALUE_MASK = 0x7fff;

/** Error raised when a persisted record no longer matches its lookup sidecar. */
class TermRecordIntegrityError extends Error {
    /**
     * @param {string} message
     */
    constructor(message) {
        super(message);
        /** @type {string} */
        this.name = 'TermRecordIntegrityError';
    }
}

/** Error raised when a persisted lookup index cannot be trusted. */
class PersistentLookupIndexError extends Error {
    /**
     * @param {'missing'|'invalid'|'transient'} kind
     * @param {string} message
     * @param {unknown} [cause]
     */
    constructor(kind, message, cause) {
        super(message, typeof cause === 'undefined' ? void 0 : {cause});
        /** @type {string} */
        this.name = 'PersistentLookupIndexError';
        /** @type {'missing'|'invalid'|'transient'} */
        this.kind = kind;
    }
}

/**
 * @param {unknown} error
 * @returns {boolean}
 */
function isStorageEntryNotFoundError(error) {
    return error instanceof Error && (
        error.name === 'NotFoundError' ||
        /\b(?:file|entry) not found\b/i.test(error.message)
    );
}

class DenseIdRecordStore {
    /** */
    constructor() {
        /** @type {(TermRecord|undefined)[]} */
        this._records = [];
        /** @type {number} */
        this.size = 0;
    }

    /** */
    clear() {
        this._records = [];
        this.size = 0;
    }

    /**
     * @param {number} maxId
     * @returns {void}
     */
    ensureCapacity(maxId) {
        if (maxId < 0) { return; }
        const requiredLength = maxId + 1;
        if (this._records.length >= requiredLength) { return; }
        this._records.length = requiredLength;
    }

    /**
     * @param {number} id
     * @param {TermRecord} record
     * @returns {DenseIdRecordStore}
     */
    set(id, record) {
        if (typeof this._records[id] === 'undefined') {
            ++this.size;
        }
        this._records[id] = record;
        return this;
    }

    /**
     * @param {number} id
     * @returns {TermRecord|undefined}
     */
    get(id) {
        return this._records[id];
    }

    /**
     * @param {number} id
     * @returns {boolean}
     */
    delete(id) {
        if (typeof this._records[id] === 'undefined') {
            return false;
        }
        this._records[id] = void 0;
        --this.size;
        return true;
    }

    /**
     * @returns {Generator<number, void, void>}
     * @yields {number}
     */
    *keys() {
        for (let i = 1, ii = this._records.length; i < ii; ++i) {
            if (typeof this._records[i] !== 'undefined') {
                yield i;
            }
        }
    }

    /**
     * @returns {Generator<TermRecord, void, void>}
     * @yields {TermRecord}
     */
    *values() {
        for (let i = 1, ii = this._records.length; i < ii; ++i) {
            const record = this._records[i];
            if (typeof record !== 'undefined') {
                yield record;
            }
        }
    }

    /**
     * @returns {(TermRecord|undefined)[]}
     */
    getRawRecords() {
        return this._records;
    }
}

/**
 * @typedef {object} TermRecord
 * @property {number} id
 * @property {string} dictionary
 * @property {string} [expression]
 * @property {string} [reading]
 * @property {boolean} [readingEqualsExpression]
 * @property {Uint8Array} [expressionBytes]
 * @property {Uint8Array} [readingBytes]
 * @property {string|null} [expressionReverse]
 * @property {string|null} [readingReverse]
 * @property {number} entryContentOffset
 * @property {number} entryContentLength
 * @property {string} entryContentDictName
 * @property {number} score
 * @property {number|null} sequence
 */

/**
 * @typedef {object} TermRecordShardState
 * @property {string} fileName
 * @property {FileSystemFileHandle} fileHandle
 * @property {FileSystemWritableFileStream|null} writable
 * @property {number} fileLength
 * @property {number} pendingWriteBytes
 * @property {Uint8Array[]} pendingWriteChunks
 * @property {number} queuedWriteBytes
 * @property {Promise<void>|null} queuedWritePromise
 * @property {Error|null} queuedWriteError
 * @property {Uint8Array[]} queuedWriteChunks
 * @property {boolean} importWriteStarted
 * @property {string|null} sharedContentDictName
 * @property {number} segmentIndex
 * @property {string} logicalKey
 * @property {number} initialFileLength
 * @property {Uint8Array[]} pendingLookupIndexChunks
 * @property {number} pendingLookupIndexBytes
 * @property {number} pendingLookupIndexRecordCount
 * @property {FileSystemFileHandle|null} lookupIndexFileHandle
 * @property {FileSystemWritableFileStream|SyncImportIndexWriter|null} lookupIndexWritable
 * @property {number} lookupIndexChunkCount
 * @property {number} lookupIndexRecordCount
 * @property {number} lookupIndexQueuedBytes
 * @property {number} lookupIndexMaxQueuedBytes
 * @property {Promise<void>|null} lookupIndexWritePromise
 * @property {Error|null} lookupIndexWriteError
 * @property {boolean} appendFormatValidated
 * @property {Uint8Array} generationId
 */

/**
 * @typedef {object} TermRecordEndImportSessionMetrics
 * @property {number} flushPendingWritesMs
 * @property {number} awaitQueuedWritesMs
 * @property {number} closeWritableMs
 * @property {number} totalMs
 * @property {number} drainCycleCount
 * @property {number} writeCallCount
 * @property {number} singleChunkWriteCount
 * @property {number} mergedWriteCount
 * @property {number} totalWriteBytes
 * @property {number} mergedWriteBytes
 * @property {number} maxWriteBytes
 * @property {number} minWriteBytes
 * @property {number} mergedGroupChunkCount
 * @property {number} maxMergedGroupChunkCount
 * @property {number} minMergedGroupChunkCount
 * @property {number} writeCoalesceTargetBytes
 * @property {number} lookupIndexWriteCallCount
 * @property {number} lookupIndexWriteBytes
 * @property {number} lookupIndexAwaitMs
 * @property {number} lookupIndexMaxQueuedBytes
 */

/**
 * @typedef {object} PersistentRecordChunk
 * @property {number} firstId
 * @property {number} count
 * @property {string} fileName
 * @property {string} dictionaryName
 * @property {string} contentDictName
 * @property {number} contentOffsetBase
 * @property {Uint8Array} recordFields
 * @property {number} recordFieldsFormat
 * @property {{offsets: Uint32Array, lengths: Uint16Array, scoreKeys: Uint16Array, scores: Int32Array}|null} compactRecordFields
 * @property {import('./term-lookup-index.js').PersistedTermLookupIndex} lookupIndex
 */

/**
 * @typedef {object} TermRecordRenamePlan
 * @property {TermRecordShardState} state
 * @property {{dictionaryName: string, contentDictName: string, segmentIndex: number}} shardInfo
 * @property {string} nextFileName
 * @property {FileSystemFileHandle} nextFileHandle
 * @property {File} file
 * @property {number} fileSize
 * @property {File} indexFile
 */

export class TermRecordOpfsStore {
    constructor() {
        /** @type {FileSystemDirectoryHandle|null} */
        this._rootDirectoryHandle = null;
        /** @type {FileSystemDirectoryHandle|null} */
        this._recordsDirectoryHandle = null;
        /** @type {Map<string, TermRecordShardState>} */
        this._shardStateByFileName = new Map();
        /** @type {Map<string, TermRecordShardState>} */
        this._activeAppendShardStateByKey = new Map();
        /** @type {Set<string>} */
        this._pendingDictionaryDeletionNames = new Set();
        /** @type {Map<string, PersistentRecordChunk[]>} */
        this._persistentRecordChunksByDictionary = new Map();
        /** @type {Set<string>} */
        this._persistentIndexLoadedDictionaryNames = new Set();
        /** @type {Map<string, Promise<boolean>>} */
        this._persistentIndexLoadPromiseByDictionary = new Map();
        /** @type {Map<string, Promise<boolean>>} */
        this._persistentIndexRepairPromiseByDictionary = new Map();
        /** @type {Map<string, {cancelled: boolean}>} */
        this._persistentIndexRepairControlByDictionary = new Map();
        /** @type {Promise<void>} */
        this._persistentIndexRepairTail = Promise.resolve();
        /** @type {Map<string, {attempts: number, retryAt: number}>} */
        this._persistentIndexRepairRetryByDictionary = new Map();
        /** @type {Promise<void>} */
        this._storageMutationTail = Promise.resolve();
        /** @type {boolean} */
        this._storageMutationActive = false;
        /** @type {Map<string, {kind: 'missing'|'invalid'|'transient', message: string}>} */
        this._persistentIndexFailureByDictionary = new Map();
        /** @type {Map<string, {status: 'available'|'repairPending'|'repairing'|'temporarilyUnavailable'|'reimportRequired', reason: string|null}>} */
        this._dictionaryHealthByName = new Map();
        /** @type {((dictionaryName: string, status: 'available'|'repairPending'|'repairing'|'temporarilyUnavailable'|'reimportRequired', reason: string|null) => void)|null} */
        this._dictionaryHealthChangeHandler = null;
        /** @type {number} */
        this._persistentLookupGeneration = 0;
        /** @type {Map<string, number>} */
        this._persistentLookupGenerationByDictionary = new Map();
        /** @type {number} */
        this._flushThresholdBytes = this._computeFlushThresholdBytes();
        /** @type {number} */
        this._queuedWriteBudgetBytes = this._computeQueuedWriteBudgetBytes();
        /** @type {boolean} */
        this._importSessionActive = false;
        /** @type {DenseIdRecordStore} */
        this._recordsById = new DenseIdRecordStore();
        /** @type {Map<string, number[]>} */
        this._recordIdsByDictionary = new Map();
        /** @type {Set<string>} */
        this._recordIdStaleDictionaryNames = new Set();
        /** @type {number} */
        this._nextId = 1;
        /** @type {boolean} */
        this._nextIdMayNeedShardScan = false;
        /** @type {Map<string, {expression: Map<string, number[]>, reading: Map<string, number[]>, expressionReverse: Map<string, number[]>, readingReverse: Map<string, number[]>, sequence: Map<number, number[]>}>} */
        this._indexByDictionary = new Map();
        /** @type {WeakSet<{expression: Map<string, number[]>, reading: Map<string, number[]>, expressionReverse: Map<string, number[]>, readingReverse: Map<string, number[]>, sequence: Map<number, number[]>}>} */
        this._reverseIndexReady = new WeakSet();
        /** @type {boolean} */
        this._deferIndexBuild = false;
        /** @type {boolean} */
        this._indexDirty = false;
        /** @type {boolean} */
        this._reloadFromShardsAfterImport = false;
        /** @type {Set<string>} */
        this._importSessionDictionaryNames = new Set();
        /** @type {Set<string>} */
        this._loadedDictionaryNames = new Set();
        /** @type {boolean} */
        this._allShardContentsLoaded = false;
        /** @type {TextEncoder} */
        this._textEncoder = new TextEncoder();
        /** @type {TextDecoder} */
        // These are length-delimited field characters, not a document BOM.
        this._textDecoder = new TextDecoder('utf-8', {ignoreBOM: true});
        /** @type {Uint32Array} */
        this._preinternedCompactionRemap = new Uint32Array(0);
        /** @type {string[]} */
        this._invalidShardFileNames = [];
        /** @type {number} */
        this._writeCoalesceTargetBytes = this._computeWriteCoalesceTargetBytes();
        /** @type {number|null} */
        this._expectedImportBytes = null;
        /** @type {TermRecordEndImportSessionMetrics|null} */
        this._lastEndImportSessionMetrics = null;
        /** @type {{drainCycleCount: number, writeCallCount: number, singleChunkWriteCount: number, mergedWriteCount: number, totalWriteBytes: number, mergedWriteBytes: number, maxWriteBytes: number, minWriteBytes: number, mergedGroupChunkCount: number, maxMergedGroupChunkCount: number, minMergedGroupChunkCount: number, writeCoalesceTargetBytes: number}} */
        this._writeDrainMetrics = this._createEmptyWriteDrainMetrics();
        /** @type {{writeCallCount: number, writeBytes: number, awaitMs: number, maxQueuedBytes: number}} */
        this._lookupIndexWriteMetrics = this._createEmptyLookupIndexWriteMetrics();
    }

    /** */
    _invalidateAllPersistentLookupState() {
        ++this._persistentLookupGeneration;
        this._persistentRecordChunksByDictionary.clear();
        this._persistentIndexLoadedDictionaryNames.clear();
        this._persistentIndexLoadPromiseByDictionary.clear();
        this._persistentIndexFailureByDictionary.clear();
        this._persistentLookupGenerationByDictionary.clear();
        this._persistentIndexRepairRetryByDictionary.clear();
    }

    /**
     * @param {string} dictionaryName
     * @param {boolean} [resetRepairRetry=true]
     */
    _invalidatePersistentLookupState(dictionaryName, resetRepairRetry = true) {
        this._persistentLookupGenerationByDictionary.set(
            dictionaryName,
            (this._persistentLookupGenerationByDictionary.get(dictionaryName) ?? 0) + 1,
        );
        this._persistentRecordChunksByDictionary.delete(dictionaryName);
        this._persistentIndexLoadedDictionaryNames.delete(dictionaryName);
        this._persistentIndexLoadPromiseByDictionary.delete(dictionaryName);
        this._persistentIndexFailureByDictionary.delete(dictionaryName);
        this._loadedDictionaryNames.delete(dictionaryName);
        this._allShardContentsLoaded = false;
        if (resetRepairRetry) { this._persistentIndexRepairRetryByDictionary.delete(dictionaryName); }
    }

    /**
     * Invalidates only the dictionary whose shard bytes are about to change.
     * Unrelated dictionaries remain lookup-ready throughout an import.
     * @param {string} dictionaryName
     */
    _registerDictionaryMutation(dictionaryName) {
        let firstMutation = true;
        if (this._importSessionActive) {
            firstMutation = !this._importSessionDictionaryNames.has(dictionaryName);
            this._importSessionDictionaryNames.add(dictionaryName);
        }
        this._indexByDictionary.delete(dictionaryName);
        if (firstMutation) {
            // Append paths publish materialized records before opening the shard.
            // Preserve that explicit publication, but never a stale sidecar marker.
            const materializedLoaded = (
                this._loadedDictionaryNames.has(dictionaryName) &&
                !this._persistentIndexLoadedDictionaryNames.has(dictionaryName)
            );
            this._invalidatePersistentLookupState(dictionaryName);
            if (materializedLoaded) { this._loadedDictionaryNames.add(dictionaryName); }
        }
    }

    /**
     * Keeps destructive shard mutations serialized and waits for every repair
     * which was already allowed to publish derived sidecars.
     * @template T
     * @param {() => Promise<T>} callback
     * @param {boolean} [allowActiveImport=false]
     * @returns {Promise<T>}
     */
    async _runExclusiveStorageMutation(callback, allowActiveImport = false) {
        const previous = this._storageMutationTail;
        /** @type {() => void} */
        let release = () => {};
        this._storageMutationTail = new Promise((resolve) => { release = resolve; });
        await previous;
        this._storageMutationActive = true;
        try {
            for (const control of this._persistentIndexRepairControlByDictionary.values()) {
                control.cancelled = true;
            }
            await this._awaitPersistentIndexRepairs();
            if (this._importSessionActive && !allowActiveImport) {
                throw new Error('Cannot mutate term-record storage during an active import session');
            }
            return await callback();
        } finally {
            this._storageMutationActive = false;
            release();
        }
    }

    /** @returns {Promise<void>} */
    async _awaitPersistentIndexRepairs() {
        while (this._persistentIndexRepairPromiseByDictionary.size > 0) {
            await Promise.allSettled(this._persistentIndexRepairPromiseByDictionary.values());
        }
    }

    /**
     * @param {string} dictionaryName
     * @returns {number}
     */
    _getPersistentLookupGeneration(dictionaryName) {
        return this._persistentLookupGenerationByDictionary.get(dictionaryName) ?? 0;
    }

    /**
     * Checks ownership before publishing either successful lookup state or a
     * failure. An obsolete read must not change a newer generation's health.
     * @param {string} dictionaryName
     * @param {number} globalGeneration
     * @param {number} dictionaryGeneration
     * @returns {boolean}
     */
    _isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, dictionaryGeneration) {
        return (
            globalGeneration === this._persistentLookupGeneration &&
            dictionaryGeneration === this._getPersistentLookupGeneration(dictionaryName) &&
            this.getDictionaryHealth(dictionaryName).status !== 'reimportRequired'
        );
    }

    /**
     * @param {string} dictionaryName
     * @returns {{status: 'available'|'repairPending'|'repairing'|'temporarilyUnavailable'|'reimportRequired', reason: string|null}}
     */
    getDictionaryHealth(dictionaryName) {
        return this._dictionaryHealthByName.get(dictionaryName) ?? {status: 'available', reason: null};
    }

    /**
     * Returns bounded runtime state for diagnosing lookup availability without
     * reading record or sidecar payloads.
     * @param {Iterable<string>} [dictionaryNames=[]]
     * @returns {{importSessionActive: boolean, reloadFromShardsAfterImport: boolean, persistentLookupGeneration: number, dictionaries: Array<Record<string, unknown>>}}
     */
    getDiagnostics(dictionaryNames = []) {
        const names = [...new Set([...dictionaryNames].map((value) => `${value}`).filter((value) => value.length > 0))];
        const dictionaries = names.map((dictionaryName) => {
            const states = this._getDictionaryShardStates(dictionaryName);
            return {
                dictionaryName,
                health: this.getDictionaryHealth(dictionaryName),
                loaded: this._loadedDictionaryNames.has(dictionaryName),
                persistentIndexLoaded: this._persistentIndexLoadedDictionaryNames.has(dictionaryName),
                persistentIndexLoading: this._persistentIndexLoadPromiseByDictionary.has(dictionaryName),
                persistentIndexRepairing: this._persistentIndexRepairPromiseByDictionary.has(dictionaryName),
                persistentIndexFailure: this._persistentIndexFailureByDictionary.get(dictionaryName) ?? null,
                persistentChunkCount: this._persistentRecordChunksByDictionary.get(dictionaryName)?.length ?? 0,
                materializedRecordCount: this._getLiveRecordIdsForDictionary(dictionaryName)?.length ?? 0,
                shardCount: states.length,
                shardBytes: states.reduce((sum, state) => sum + state.fileLength, 0),
                shardFiles: states.slice(0, 8).map((state) => state.fileName),
            };
        });
        return {
            importSessionActive: this._importSessionActive,
            reloadFromShardsAfterImport: this._reloadFromShardsAfterImport,
            persistentLookupGeneration: this._persistentLookupGeneration,
            dictionaries,
        };
    }

    /**
     * @param {((dictionaryName: string, status: 'available'|'repairPending'|'repairing'|'temporarilyUnavailable'|'reimportRequired', reason: string|null) => void)|null} handler
     */
    setDictionaryHealthChangeHandler(handler) {
        this._dictionaryHealthChangeHandler = handler;
    }

    /**
     * @param {string} dictionaryName
     * @returns {boolean}
     */
    isDictionaryAvailable(dictionaryName) {
        const {status} = this.getDictionaryHealth(dictionaryName);
        return status === 'available' || (status === 'repairPending' && this._hasCompleteDictionaryLookupState(dictionaryName));
    }

    /**
     * @param {string} dictionaryName
     * @param {string} reason
     */
    markDictionaryReimportRequired(dictionaryName, reason) {
        this._setDictionaryHealth(dictionaryName, 'reimportRequired', reason);
        this._discardMaterializedDictionary(dictionaryName);
        this._invalidatePersistentLookupState(dictionaryName);
    }

    /**
     * @param {string} dictionaryName
     * @param {'available'|'repairPending'|'repairing'|'temporarilyUnavailable'|'reimportRequired'} status
     * @param {string|null} reason
     */
    _setDictionaryHealth(dictionaryName, status, reason = null) {
        if (status === 'available') { this._persistentIndexRepairRetryByDictionary.delete(dictionaryName); }
        const previous = this._dictionaryHealthByName.get(dictionaryName);
        const previousStatus = previous?.status ?? 'available';
        const previousReason = previous?.reason ?? null;
        if (previousStatus === status && previousReason === reason) { return; }
        if (status === 'available') {
            this._dictionaryHealthByName.delete(dictionaryName);
        } else {
            this._dictionaryHealthByName.set(dictionaryName, {status, reason});
        }
        reportDiagnostics('term-record-dictionary-health-changed', {
            dictionaryName,
            previousStatus,
            status,
            reason,
        });
        try {
            this._dictionaryHealthChangeHandler?.(dictionaryName, status, reason);
        } catch (error) {
            reportDiagnostics('term-record-dictionary-health-persist-failed', {
                dictionaryName,
                status,
                error: error instanceof Error ? error.message : String(error),
            });
        }
    }

    /**
     * @returns {Promise<void>}
     */
    async prepare() {
        await this._runExclusiveStorageMutation(async () => await this._prepare());
    }

    /** @returns {Promise<void>} */
    async _prepare() {
        await this._closeAllWritables();
        this._recordsById.clear();
        this._recordIdsByDictionary.clear();
        this._recordIdStaleDictionaryNames.clear();
        this._indexByDictionary.clear();
        this._nextId = 1;
        this._nextIdMayNeedShardScan = false;
        this._deferIndexBuild = false;
        this._indexDirty = false;
        this._reloadFromShardsAfterImport = false;
        this._importSessionDictionaryNames.clear();
        this._loadedDictionaryNames.clear();
        this._allShardContentsLoaded = false;
        this._rootDirectoryHandle = null;
        this._recordsDirectoryHandle = null;
        this._shardStateByFileName.clear();
        this._activeAppendShardStateByKey.clear();
        this._invalidateAllPersistentLookupState();
        this._dictionaryHealthByName.clear();
        this._preinternedCompactionRemap = new Uint32Array(0);
        this._invalidShardFileNames = [];
        await this._ensureRecordsDirectoryHandle();
        if (this._recordsDirectoryHandle === null) { return; }

        const shardFileCount = await this._loadShardFiles(false);
        this._nextIdMayNeedShardScan = shardFileCount > 0;
        if (shardFileCount === 0) {
            this._nextIdMayNeedShardScan = false;
            await this.verifyIntegrity();
            this._allShardContentsLoaded = true;
        }
    }

    /** @returns {Promise<void>} */
    async _ensureRecordsDirectoryHandle() {
        if (this._recordsDirectoryHandle !== null) { return; }
        if (typeof navigator === 'undefined' || !('storage' in navigator) || !('getDirectory' in navigator.storage)) { return; }
        this._rootDirectoryHandle = await navigator.storage.getDirectory();
        this._recordsDirectoryHandle = await this._rootDirectoryHandle.getDirectoryHandle(SHARD_DIRECTORY_NAME, {create: true});
    }

    /**
     * @returns {Promise<void>}
     */
    async beginImportSession() {
        await this._runExclusiveStorageMutation(async () => {
            if (this._importSessionActive) {
                return;
            }
            this._importSessionActive = true;
            this._deferIndexBuild = true;
            this._indexDirty = true;
            this._reloadFromShardsAfterImport = false;
            this._importSessionDictionaryNames.clear();
            this._indexByDictionary.clear();
            this._queuedWriteBudgetBytes = this._computeQueuedWriteBudgetBytes();
            this._writeCoalesceTargetBytes = this._computeWriteCoalesceTargetBytes();
            this._writeDrainMetrics = this._createEmptyWriteDrainMetrics();
            this._lookupIndexWriteMetrics = this._createEmptyLookupIndexWriteMetrics();
            for (const state of this._shardStateByFileName.values()) {
                state.pendingWriteBytes = 0;
                state.pendingWriteChunks = [];
                state.queuedWriteBytes = 0;
                state.queuedWritePromise = null;
                state.queuedWriteError = null;
                state.queuedWriteChunks = [];
                state.importWriteStarted = false;
                state.initialFileLength = state.fileLength;
                state.pendingLookupIndexChunks = [];
                state.pendingLookupIndexBytes = 0;
                state.pendingLookupIndexRecordCount = 0;
                state.lookupIndexFileHandle = null;
                state.lookupIndexWritable = null;
                state.lookupIndexChunkCount = 0;
                state.lookupIndexRecordCount = 0;
                state.lookupIndexQueuedBytes = 0;
                state.lookupIndexMaxQueuedBytes = 0;
                state.lookupIndexWritePromise = null;
                state.lookupIndexWriteError = null;
            }
        }, true);
    }

    /**
     * @returns {Promise<import('dictionary-import-journal').TermRecordCheckpoint>}
     */
    async createImportCheckpoint() {
        await this._closeAllWritables();
        // Retired files cannot become part of a later import's committed
        // checkpoint or be rediscovered under its reused dictionary title.
        // Retry before journal ownership, when deleting orphan bytes cannot
        // invalidate an accepted rollback target.
        for (const dictionaryName of this._pendingDictionaryDeletionNames) {
            await this.deleteByDictionary(dictionaryName);
        }
        if (this._recordsDirectoryHandle === null) { return {shards: []}; }
        const shards = [];
        for (const fileName of await this._listTermRecordStorageFileNames()) {
            const fileHandle = await this._recordsDirectoryHandle.getFileHandle(fileName);
            shards.push({fileName, fileLength: (await fileHandle.getFile()).size});
        }
        return {shards};
    }

    /**
     * @param {import('dictionary-import-journal').TermRecordCheckpoint} checkpoint
     * @returns {Promise<void>}
     */
    async rollbackImportSession(checkpoint) {
        await this._runExclusiveStorageMutation(
            async () => await this._rollbackImportSession(checkpoint),
            true,
        );
    }

    /**
     * @param {import('dictionary-import-journal').TermRecordCheckpoint} checkpoint
     * @returns {Promise<void>}
     */
    async _rollbackImportSession(checkpoint) {
        if (
            typeof checkpoint !== 'object' ||
            checkpoint === null ||
            !Array.isArray(checkpoint.shards)
        ) {
            throw new TypeError('Invalid term-record import checkpoint');
        }
        /** @type {Map<string, number>} */
        const checkpointByName = new Map();
        for (const shard of checkpoint.shards) {
            if (
                typeof shard !== 'object' ||
                shard === null ||
                typeof shard.fileName !== 'string' ||
                !this._isCanonicalTermRecordStorageFileName(shard.fileName) ||
                !Number.isSafeInteger(shard.fileLength) ||
                shard.fileLength < 0 ||
                checkpointByName.has(shard.fileName)
            ) {
                throw new TypeError('Invalid term-record import checkpoint shard');
            }
            checkpointByName.set(shard.fileName, shard.fileLength);
        }
        // Validate the complete restoration target before abandoning writes. A
        // corrupt journal must not mutate the active store before it is rejected.
        await this._abandonImportWritesForRollback();
        // Startup recovery precedes normal preparation: an unpublished shard
        // must not have to pass ordinary lookup loading first.
        await this._ensureRecordsDirectoryHandle();
        if (this._recordsDirectoryHandle === null) { return; }
        /** @type {Error[]} */
        const errors = [];
        // Truncation can extend a short file with zeroes. Confirm every
        // committed checkpoint prefix exists before deleting or truncating any
        // term-record storage file.
        for (const [fileName, fileLength] of checkpointByName) {
            try {
                const fileHandle = await this._recordsDirectoryHandle.getFileHandle(fileName);
                if ((await fileHandle.getFile()).size < fileLength) {
                    throw new Error(`Cannot restore missing term-record bytes for ${fileName}`);
                }
            } catch (error) {
                errors.push(error instanceof Error ? error : new Error(String(error)));
            }
        }
        if (errors.length > 0) {
            throw new AggregateError(errors, 'Failed to roll back term-record import storage');
        }
        /** @type {string[]} */
        let currentFileNames = [];
        try {
            currentFileNames = await this._listTermRecordStorageFileNames();
        } catch (error) {
            errors.push(error instanceof Error ? error : new Error(String(error)));
        }
        for (const fileName of currentFileNames) {
            try {
                const fileLength = checkpointByName.get(fileName);
                if (typeof fileLength === 'undefined') {
                    await this._recordsDirectoryHandle.removeEntry(fileName);
                    continue;
                }
                const fileHandle = await this._recordsDirectoryHandle.getFileHandle(fileName);
                const writable = await fileHandle.createWritable({keepExistingData: true});
                try {
                    await writable.truncate(fileLength);
                } finally {
                    await writable.close();
                }
            } catch (error) {
                errors.push(error instanceof Error ? error : new Error(String(error)));
            }
        }
        for (const {fileName, fileLength} of checkpoint.shards) {
            try {
                const fileHandle = await this._recordsDirectoryHandle.getFileHandle(fileName);
                if ((await fileHandle.getFile()).size !== fileLength) {
                    throw new Error(`Cannot restore missing term-record bytes for ${fileName}`);
                }
            } catch (error) {
                errors.push(error instanceof Error ? error : new Error(String(error)));
            }
        }
        try {
            await this._prepare();
        } catch (error) {
            errors.push(error instanceof Error ? error : new Error(String(error)));
        }
        if (errors.length > 0) {
            throw new AggregateError(errors, 'Failed to roll back term-record import storage');
        }
    }

    /**
     * Stops import writes without flushing data which is about to be discarded.
     * @returns {Promise<void>}
     */
    async _abandonImportWritesForRollback() {
        this._importSessionActive = false;
        this._deferIndexBuild = false;
        this._indexDirty = false;
        this._preinternedCompactionRemap = new Uint32Array(0);
        this._importSessionDictionaryNames.clear();
        const states = [...this._shardStateByFileName.values()];
        const queuedWrites = [];
        for (const state of states) {
            state.pendingWriteBytes = 0;
            state.pendingWriteChunks = [];
            state.queuedWriteBytes = 0;
            state.queuedWriteChunks = [];
            state.pendingLookupIndexChunks = [];
            state.pendingLookupIndexBytes = 0;
            state.pendingLookupIndexRecordCount = 0;
            if (state.queuedWritePromise !== null) {
                queuedWrites.push(state.queuedWritePromise);
            }
            if (state.lookupIndexWritePromise !== null) {
                queuedWrites.push(state.lookupIndexWritePromise);
            }
        }
        const settledWrites = await Promise.allSettled(queuedWrites);
        const abandonedWriteErrors = settledWrites
            .filter((result) => result.status === 'rejected')
            .map((result) => (
                result.reason instanceof Error ?
                    result.reason.message :
                    String(result.reason)
            ));
        if (abandonedWriteErrors.length > 0) {
            reportDiagnostics('term-record-store-rollback-abandoned-write-errors', {
                errors: abandonedWriteErrors,
            });
        }
        for (const state of states) {
            state.queuedWritePromise = null;
            state.queuedWriteError = null;
            state.lookupIndexWritePromise = null;
            state.lookupIndexWriteError = null;
            state.lookupIndexQueuedBytes = 0;
            const writable = state.writable;
            state.writable = null;
            if (writable !== null) {
                try {
                    const abort = /** @type {unknown} */ (Reflect.get(writable, 'abort'));
                    const closePromise = typeof abort === 'function' ?
                        /** @type {() => Promise<void>} */ (abort).call(writable) :
                        writable.close();
                    await closePromise;
                } catch (_) {
                    // Restoration below uses fresh handles and verifies every checkpoint file.
                }
            }
            const lookupIndexWritable = state.lookupIndexWritable;
            state.lookupIndexWritable = null;
            state.lookupIndexFileHandle = null;
            state.lookupIndexChunkCount = 0;
            state.lookupIndexRecordCount = 0;
            if (lookupIndexWritable === null) { continue; }
            try {
                const abort = /** @type {unknown} */ (Reflect.get(lookupIndexWritable, 'abort'));
                const closePromise = typeof abort === 'function' ?
                    /** @type {() => Promise<void>} */ (abort).call(lookupIndexWritable) :
                    lookupIndexWritable.close();
                await closePromise;
            } catch (_) {
                // Checkpoint restoration validates the committed sidecar bytes below.
            }
        }
        this._invalidateAllPersistentLookupState();
    }

    /**
     * @returns {Promise<void>}
     */
    async endImportSession() {
        try {
            await this._endImportSession();
        } finally {
            this._preinternedCompactionRemap = new Uint32Array(0);
        }
    }

    /**
     * @returns {Promise<void>}
     */
    async _endImportSession() {
        if (!this._importSessionActive && !this._hasPendingShardWrites()) {
            return;
        }
        const tStart = safePerformance.now();
        let flushPendingWritesMs = 0;
        let awaitQueuedWritesMs = 0;
        let closeWritableMs = 0;
        const tFlushPendingWritesStart = safePerformance.now();
        await this._flushPendingWrites();
        flushPendingWritesMs = safePerformance.now() - tFlushPendingWritesStart;
        const tAwaitQueuedWritesStart = safePerformance.now();
        await this._awaitQueuedWrites();
        awaitQueuedWritesMs = safePerformance.now() - tAwaitQueuedWritesStart;
        const tCloseWritableStart = safePerformance.now();
        await this._closeAllWritables();
        for (const dictionaryName of this._importSessionDictionaryNames) {
            this._setDictionaryHealth(dictionaryName, 'available');
        }
        this._importSessionDictionaryNames.clear();
        this._importSessionActive = false;
        closeWritableMs = safePerformance.now() - tCloseWritableStart;
        this._deferIndexBuild = false;
        this._lastEndImportSessionMetrics = {
            flushPendingWritesMs,
            awaitQueuedWritesMs,
            closeWritableMs,
            totalMs: safePerformance.now() - tStart,
            ...this._writeDrainMetrics,
            lookupIndexWriteCallCount: this._lookupIndexWriteMetrics.writeCallCount,
            lookupIndexWriteBytes: this._lookupIndexWriteMetrics.writeBytes,
            lookupIndexAwaitMs: this._lookupIndexWriteMetrics.awaitMs,
            lookupIndexMaxQueuedBytes: this._lookupIndexWriteMetrics.maxQueuedBytes,
        };
        if (this._reloadFromShardsAfterImport) {
            this._indexByDictionary.clear();
            this._indexDirty = false;
            return;
        }
        if (this._indexDirty) {
            this._indexByDictionary.clear();
            this._indexDirty = false;
        }
    }

    /**
     * @returns {TermRecordEndImportSessionMetrics|null}
     */
    getLastEndImportSessionMetrics() {
        return this._lastEndImportSessionMetrics;
    }

    /**
     * @param {number|null} value
     */
    setExpectedImportBytes(value) {
        this._expectedImportBytes = (typeof value === 'number' && Number.isFinite(value) && value > 0) ?
            Math.max(1, Math.trunc(value)) :
            null;
        this._writeCoalesceTargetBytes = this._computeWriteCoalesceTargetBytes();
        this._writeDrainMetrics = this._createEmptyWriteDrainMetrics();
    }

    /**
     * @returns {Promise<void>}
     */
    async reset() {
        // A reset must join cancelled repair writers before removing their
        // containers, including a close or abort which is still settling.
        await this._runExclusiveStorageMutation(async () => await this._reset(), true);
    }

    /** @returns {Promise<void>} */
    async _reset() {
        await this._abandonImportWritesForRollback();
        await this._ensureRecordsDirectoryHandle();
        /** @type {Error[]} */
        const resetErrors = [];
        if (this._recordsDirectoryHandle !== null) {
            const shardFileNames = await this._listTermRecordStorageFileNames();
            for (const fileName of shardFileNames) {
                try {
                    await this._removeStorageFileOrTruncate(fileName, false);
                } catch (error) {
                    resetErrors.push(toError(error));
                }
            }
        }

        // Reset runtime ownership even when persistent cleanup fails. Some files
        // may already have been removed/truncated, so retaining materialized
        // records would expose state which no longer matches persistence.
        this._recordsById.clear();
        this._recordIdsByDictionary.clear();
        this._recordIdStaleDictionaryNames.clear();
        this._indexByDictionary.clear();
        this._nextId = 1;
        this._nextIdMayNeedShardScan = false;
        this._deferIndexBuild = false;
        this._indexDirty = false;
        this._shardStateByFileName.clear();
        this._invalidShardFileNames = [];
        this._activeAppendShardStateByKey.clear();
        this._invalidateAllPersistentLookupState();
        this._dictionaryHealthByName.clear();
        this._importSessionActive = false;
        this._importSessionDictionaryNames.clear();
        this._preinternedCompactionRemap = new Uint32Array(0);
        this._loadedDictionaryNames.clear();
        this._allShardContentsLoaded = false;

        if (resetErrors.length > 0) {
            throw new AggregateError(resetErrors, 'Failed to reset term-record storage');
        }
        this._pendingDictionaryDeletionNames.clear();
    }

    /**
     * @returns {number}
     */
    get size() {
        let count = this._recordsById.size;
        for (const dictionaryName of this._persistentIndexLoadedDictionaryNames) {
            const chunks = this._persistentRecordChunksByDictionary.get(dictionaryName);
            if (typeof chunks === 'undefined') { continue; }
            let persistentCount = 0;
            for (const chunk of chunks) { persistentCount += chunk.count; }
            const materializedCount = this._getLiveRecordIdsForDictionary(dictionaryName)?.length ?? 0;
            count += Math.max(0, persistentCount - materializedCount);
        }
        return count;
    }

    /**
     * @returns {boolean}
     */
    isEmpty() {
        return this.size === 0;
    }

    /**
     * @param {{dictionary: string, expression: string, reading: string, expressionBytes?: Uint8Array, readingBytes?: Uint8Array, expressionReverse: string|null, readingReverse: string|null, entryContentOffset: number, entryContentLength: number, entryContentDictName: string|null, score: number, sequence: number|null}[]} records
     * @param {import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan|null} [preinternedPlan]
     * @returns {Promise<void>}
     */
    async appendBatch(records, preinternedPlan = null) {
        if (records.length === 0) { return; }
        for (const row of records) {
            this._assertShardAcceptsAppend(row.dictionary, row.entryContentDictName ?? 'raw');
        }
        await this._ensureNextIdReadyForAppend(records.length);
        /** @type {Map<string, TermRecord[]>} */
        const recordsByShard = new Map();
        for (const row of records) {
            const id = this._nextId++;
            const record = {
                id,
                dictionary: row.dictionary,
                expression: row.expression,
                reading: row.reading,
                expressionBytes: row.expressionBytes instanceof Uint8Array ? row.expressionBytes : void 0,
                readingBytes: row.readingBytes instanceof Uint8Array ? row.readingBytes : void 0,
                expressionReverse: row.expressionReverse,
                readingReverse: row.readingReverse,
                entryContentOffset: row.entryContentOffset,
                entryContentLength: row.entryContentLength,
                entryContentDictName: row.entryContentDictName ?? 'raw',
                score: row.score,
                sequence: row.sequence,
            };
            this._cacheAppendedRecord(record);
            this._setDictionaryHealth(record.dictionary, 'available');
            const shardFileName = this._getShardFileName(record.dictionary, record.entryContentDictName);
            const shardRecords = recordsByShard.get(shardFileName);
            if (typeof shardRecords === 'undefined') {
                recordsByShard.set(shardFileName, [record]);
            } else {
                shardRecords.push(record);
            }
            if (!this._deferIndexBuild) {
                const existingIndex = this._indexByDictionary.get(record.dictionary);
                if (typeof existingIndex !== 'undefined') {
                    this._addRecordToDictionaryIndex(existingIndex, record);
                }
            }
        }
        if (this._deferIndexBuild) {
            this._indexDirty = true;
        }
        for (const dictionaryRecords of recordsByShard.values()) {
            const firstRecord = dictionaryRecords[0];
            const state = await this._getOrCreateShardState(firstRecord.dictionary, firstRecord.entryContentDictName);
            if (state === null) { continue; }
            await this._encodeAndAppendChunkRunsForState(state, dictionaryRecords, preinternedPlan);
        }
    }

    /**
     * Fast-path append for SQL row arrays from dictionary-database bulk term insert.
     * @param {unknown[][]} rows
     * @param {number} start
     * @param {number} count
     * @returns {Promise<void>}
     */
    async appendBatchFromTermRows(rows, start, count) {
        if (count <= 0) { return; }
        let previousDictionary = '';
        let previousContentDictName = '';
        for (let i = start, ii = start + count; i < ii; ++i) {
            const row = /** @type {[string, string, string, (string|null), (string|null), unknown, number, number, (string|null), unknown, unknown, unknown, number, unknown, (number|null)]} */ (rows[i]);
            const dictionary = row[0];
            const contentDictName = row[8] ?? 'raw';
            if (i === start || dictionary !== previousDictionary || contentDictName !== previousContentDictName) {
                this._assertShardAcceptsAppend(dictionary, contentDictName);
                previousDictionary = dictionary;
                previousContentDictName = contentDictName;
            }
        }
        await this._ensureNextIdReadyForAppend(count);
        /** @type {Map<string, TermRecord[]>|null} */
        let recordsByShard = null;
        /** @type {TermRecord[]} */
        const singleDictionaryRecords = [];
        let singleDictionaryName = '';
        let singleContentDictName = 'raw';
        for (let i = start, ii = start + count; i < ii; ++i) {
            const row = /** @type {[string, string, string, (string|null), (string|null), unknown, number, number, (string|null), unknown, unknown, unknown, number, unknown, (number|null)]} */ (rows[i]);
            const id = this._nextId++;
            const dictionary = row[0];
            /** @type {TermRecord} */
            const record = {
                id,
                dictionary,
                expression: row[1],
                reading: row[2],
                expressionReverse: row[3],
                readingReverse: row[4],
                entryContentOffset: row[6],
                entryContentLength: row[7],
                entryContentDictName: row[8] ?? 'raw',
                score: row[12],
                sequence: row[14],
            };
            this._cacheAppendedRecord(record);
            if (i === start) {
                singleDictionaryName = dictionary;
                singleContentDictName = record.entryContentDictName;
            }
            if (recordsByShard === null) {
                if (dictionary === singleDictionaryName && record.entryContentDictName === singleContentDictName) {
                    singleDictionaryRecords.push(record);
                } else {
                    recordsByShard = new Map();
                    recordsByShard.set(this._getShardFileName(singleDictionaryName, singleContentDictName), singleDictionaryRecords);
                    recordsByShard.set(this._getShardFileName(dictionary, record.entryContentDictName), [record]);
                }
            } else {
                const shardFileName = this._getShardFileName(dictionary, record.entryContentDictName);
                let dictionaryRecords = recordsByShard.get(shardFileName);
                if (typeof dictionaryRecords === 'undefined') {
                    dictionaryRecords = [];
                    recordsByShard.set(shardFileName, dictionaryRecords);
                }
                dictionaryRecords.push(record);
            }
            if (!this._deferIndexBuild) {
                const existingIndex = this._indexByDictionary.get(dictionary);
                if (typeof existingIndex !== 'undefined') {
                    this._addRecordToDictionaryIndex(existingIndex, record);
                }
            }
        }
        if (this._deferIndexBuild) {
            this._indexDirty = true;
        }
        if (recordsByShard === null) {
            const state = await this._getOrCreateShardState(singleDictionaryName, singleContentDictName);
            if (state !== null) {
                await this._encodeAndAppendChunkRunsForState(state, singleDictionaryRecords);
            }
            return;
        }
        for (const dictionaryRecords of recordsByShard.values()) {
            const firstRecord = dictionaryRecords[0];
            const state = await this._getOrCreateShardState(firstRecord.dictionary, firstRecord.entryContentDictName);
            if (state === null) { continue; }
            await this._encodeAndAppendChunkRunsForState(state, dictionaryRecords);
        }
    }

    /**
     * Fast-path append for importer DatabaseTermEntry arrays paired with resolved content refs.
     * @param {unknown[]} rows
     * @param {number} start
     * @param {number} count
     * @param {number[]|Uint32Array|Float64Array} contentOffsets
     * @param {number[]|Uint32Array} contentLengths
     * @param {(string|null)[]} contentDictNames
     * @param {import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan|null} [preinternedPlan]
     * @returns {Promise<{buildRecordsMs: number, encodeMs: number, appendWriteMs: number}>}
     */
    async appendBatchFromResolvedImportTermEntries(rows, start, count, contentOffsets, contentLengths, contentDictNames, preinternedPlan = null) {
        if (count <= 0) { return {buildRecordsMs: 0, encodeMs: 0, appendWriteMs: 0}; }
        if (contentOffsets.length < (start + count) || contentLengths.length < (start + count) || contentDictNames.length < (start + count)) {
            throw new Error('appendBatchFromResolvedImportTermEntries content refs length is smaller than row count');
        }
        let previousDictionary = '';
        let previousContentDictName = '';
        for (let i = start, ii = start + count; i < ii; ++i) {
            const row = /** @type {{dictionary: string}} */ (rows[i]);
            const dictionary = row.dictionary;
            const contentDictName = contentDictNames[i] ?? 'raw';
            if (i === start || dictionary !== previousDictionary || contentDictName !== previousContentDictName) {
                this._assertShardAcceptsAppend(dictionary, contentDictName);
                previousDictionary = dictionary;
                previousContentDictName = contentDictName;
            }
        }
        await this._ensureNextIdReadyForAppend(count);
        const tBuildStart = safePerformance.now();
        let buildRecordsMs = 0;
        let encodeMs = 0;
        let appendWriteMs = 0;
        /** @type {Map<string, {records: TermRecord[], indexes: number[]}>|null} */
        let recordsByShard = null;
        /** @type {TermRecord[]} */
        const singleDictionaryRecords = new Array(count);
        let singleDictionaryRecordCount = 0;
        let singleDictionaryName = '';
        let singleContentDictName = 'raw';
        for (let i = start, ii = start + count; i < ii; ++i) {
            const row = /** @type {{dictionary: string, expression: string, reading: string, readingEqualsExpression?: boolean, expressionBytes?: Uint8Array, readingBytes?: Uint8Array, expressionReverse?: string, readingReverse?: string, score: number, sequence?: number}} */ (rows[i]);
            const id = this._nextId++;
            const dictionary = row.dictionary;
            const readingEqualsExpression = row.readingEqualsExpression ?? (row.reading === row.expression);
            const useLazyArtifactStrings = preinternedPlan !== null;
            /** @type {TermRecord} */
            const record = {
                id,
                dictionary,
                expression: useLazyArtifactStrings ? '' : row.expression,
                reading: useLazyArtifactStrings ? '' : row.reading,
                readingEqualsExpression,
                expressionBytes: row.expressionBytes instanceof Uint8Array ? row.expressionBytes : void 0,
                readingBytes: !readingEqualsExpression && row.readingBytes instanceof Uint8Array ? row.readingBytes : void 0,
                expressionReverse: row.expressionReverse ?? null,
                readingReverse: row.readingReverse ?? null,
                entryContentOffset: contentOffsets[i],
                entryContentLength: contentLengths[i],
                entryContentDictName: contentDictNames[i] ?? 'raw',
                score: row.score,
                sequence: typeof row.sequence === 'number' ? row.sequence : null,
            };
            this._cacheAppendedRecord(record);
            if (i === start) {
                singleDictionaryName = dictionary;
                singleContentDictName = record.entryContentDictName;
            }
            if (recordsByShard === null) {
                if (dictionary === singleDictionaryName && record.entryContentDictName === singleContentDictName) {
                    singleDictionaryRecords[singleDictionaryRecordCount++] = record;
                } else {
                    recordsByShard = new Map();
                    recordsByShard.set(
                        this._getShardFileName(singleDictionaryName, singleContentDictName),
                        {
                            records: singleDictionaryRecords.slice(0, singleDictionaryRecordCount),
                            indexes: Array.from({length: singleDictionaryRecordCount}, (_, index) => index),
                        },
                    );
                    recordsByShard.set(this._getShardFileName(dictionary, record.entryContentDictName), {records: [record], indexes: [i - start]});
                }
            } else {
                const shardFileName = this._getShardFileName(dictionary, record.entryContentDictName);
                let shardRecords = recordsByShard.get(shardFileName);
                if (typeof shardRecords === 'undefined') {
                    shardRecords = {records: [], indexes: []};
                    recordsByShard.set(shardFileName, shardRecords);
                }
                shardRecords.records.push(record);
                shardRecords.indexes.push(i - start);
            }
            if (!this._deferIndexBuild) {
                const existingIndex = this._indexByDictionary.get(dictionary);
                if (typeof existingIndex !== 'undefined') {
                    this._addRecordToDictionaryIndex(existingIndex, record);
                }
            }
        }
        if (this._deferIndexBuild) {
            this._indexDirty = true;
        }
        buildRecordsMs = safePerformance.now() - tBuildStart;
        if (recordsByShard === null) {
            const state = await this._getOrCreateShardState(singleDictionaryName, singleContentDictName);
            if (state !== null) {
                const metrics = await this._encodeAndAppendChunkRunsForState(state, singleDictionaryRecords, preinternedPlan);
                encodeMs += metrics.encodeMs;
                appendWriteMs += metrics.appendWriteMs;
            }
            return {buildRecordsMs, encodeMs, appendWriteMs};
        }
        for (const {records: dictionaryRecords, indexes} of recordsByShard.values()) {
            const firstRecord = dictionaryRecords[0];
            const state = await this._getOrCreateShardState(firstRecord.dictionary, firstRecord.entryContentDictName);
            if (state === null) { continue; }
            const metrics = await this._encodeAndAppendChunkRunsForState(state, dictionaryRecords, preinternedPlan, indexes);
            encodeMs += metrics.encodeMs;
            appendWriteMs += metrics.appendWriteMs;
        }
        return {buildRecordsMs, encodeMs, appendWriteMs};
    }

    /**
     * Fast-path append for importer DatabaseTermEntry arrays paired with content spans.
     * @param {unknown[]} rows
     * @param {number} start
     * @param {number} count
     * @param {{offset: number, length: number}[]} spans
     * @returns {Promise<void>}
     */
    async appendBatchFromImportTermEntries(rows, start, count, spans) {
        if (count <= 0) { return; }
        if (spans.length < count) {
            throw new Error('appendBatchFromImportTermEntries spans length is smaller than row count');
        }
        let previousDictionary = '';
        for (let i = 0; i < count; ++i) {
            const dictionary = /** @type {{dictionary: string}} */ (rows[start + i]).dictionary;
            if (i === 0 || dictionary !== previousDictionary) {
                this._assertShardAcceptsAppend(dictionary, 'raw');
                previousDictionary = dictionary;
            }
        }
        await this._ensureNextIdReadyForAppend(count);
        /** @type {Map<string, TermRecord[]>|null} */
        let recordsByShard = null;
        /** @type {TermRecord[]} */
        const singleDictionaryRecords = [];
        let singleDictionaryName = '';
        let singleContentDictName = 'raw';
        for (let i = 0; i < count; ++i) {
            const row = /** @type {{dictionary: string, expression: string, reading: string, expressionBytes?: Uint8Array, readingBytes?: Uint8Array, expressionReverse?: string, readingReverse?: string, score: number, sequence?: number}} */ (rows[start + i]);
            const span = spans[i];
            const id = this._nextId++;
            const dictionary = row.dictionary;
            /** @type {TermRecord} */
            const record = {
                id,
                dictionary,
                expression: row.expression,
                reading: row.reading,
                expressionBytes: row.expressionBytes instanceof Uint8Array ? row.expressionBytes : void 0,
                readingBytes: row.readingBytes instanceof Uint8Array ? row.readingBytes : void 0,
                expressionReverse: row.expressionReverse ?? null,
                readingReverse: row.readingReverse ?? null,
                entryContentOffset: span.offset,
                entryContentLength: span.length,
                entryContentDictName: 'raw',
                score: row.score,
                sequence: typeof row.sequence === 'number' ? row.sequence : null,
            };
            this._cacheAppendedRecord(record);
            if (i === 0) {
                singleDictionaryName = dictionary;
                singleContentDictName = record.entryContentDictName;
            }
            if (recordsByShard === null) {
                if (dictionary === singleDictionaryName && record.entryContentDictName === singleContentDictName) {
                    singleDictionaryRecords.push(record);
                } else {
                    recordsByShard = new Map();
                    recordsByShard.set(this._getShardFileName(singleDictionaryName, singleContentDictName), singleDictionaryRecords);
                    recordsByShard.set(this._getShardFileName(dictionary, record.entryContentDictName), [record]);
                }
            } else {
                const shardFileName = this._getShardFileName(dictionary, record.entryContentDictName);
                let dictionaryRecords = recordsByShard.get(shardFileName);
                if (typeof dictionaryRecords === 'undefined') {
                    dictionaryRecords = [];
                    recordsByShard.set(shardFileName, dictionaryRecords);
                }
                dictionaryRecords.push(record);
            }
            if (!this._deferIndexBuild) {
                const existingIndex = this._indexByDictionary.get(dictionary);
                if (typeof existingIndex !== 'undefined') {
                    this._addRecordToDictionaryIndex(existingIndex, record);
                }
            }
        }
        if (this._deferIndexBuild) {
            this._indexDirty = true;
        }
        if (recordsByShard === null) {
            const state = await this._getOrCreateShardState(singleDictionaryName, singleContentDictName);
            if (state !== null) {
                await this._encodeAndAppendChunkRunsForState(state, singleDictionaryRecords);
            }
            return;
        }
        for (const dictionaryRecords of recordsByShard.values()) {
            const firstRecord = dictionaryRecords[0];
            const state = await this._getOrCreateShardState(firstRecord.dictionary, firstRecord.entryContentDictName);
            if (state === null) { continue; }
            await this._encodeAndAppendChunkRunsForState(state, dictionaryRecords);
        }
    }

    /**
     * Fast-path append for importer DatabaseTermEntry arrays paired with raw content offset/length arrays.
     * @param {unknown[]} rows
     * @param {number} start
     * @param {number} count
     * @param {number[]} contentOffsets
     * @param {number[]} contentLengths
     * @param {string|(string|null)[]} [contentDictNames='raw']
     * @returns {Promise<{buildRecordsMs: number, encodeMs: number, appendWriteMs: number}>}
     */
    async appendBatchFromImportTermEntriesResolvedContent(rows, start, count, contentOffsets, contentLengths, contentDictNames = 'raw') {
        if (count <= 0) { return {buildRecordsMs: 0, encodeMs: 0, appendWriteMs: 0}; }
        if (
            contentOffsets.length < count ||
            contentLengths.length < count ||
            (Array.isArray(contentDictNames) && contentDictNames.length < count)
        ) {
            throw new Error('appendBatchFromImportTermEntriesResolvedContent content arrays are smaller than row count');
        }
        const uniformContentDictName = Array.isArray(contentDictNames) ? null : (contentDictNames ?? 'raw');
        let previousDictionary = '';
        let previousContentDictName = '';
        for (let i = 0; i < count; ++i) {
            const dictionary = /** @type {{dictionary: string}} */ (rows[start + i]).dictionary;
            const contentDictName = uniformContentDictName ?? (contentDictNames[i] ?? 'raw');
            if (i === 0 || dictionary !== previousDictionary || contentDictName !== previousContentDictName) {
                this._assertShardAcceptsAppend(dictionary, contentDictName);
                previousDictionary = dictionary;
                previousContentDictName = contentDictName;
            }
        }
        await this._ensureNextIdReadyForAppend(count);
        const tBuildStart = safePerformance.now();
        let buildRecordsMs = 0;
        let encodeMs = 0;
        let appendWriteMs = 0;
        /** @type {Map<string, {records: TermRecord[], indexes: number[]}>|null} */
        let recordsByShard = null;
        /** @type {TermRecord[]} */
        const singleDictionaryRecords = new Array(count);
        let singleDictionaryRecordCount = 0;
        let firstDictionaryName = '';
        let firstContentDictName = 'raw';
        for (let i = 0; i < count; ++i) {
            const row = /** @type {{dictionary: string, expression: string, reading: string, readingEqualsExpression?: boolean, expressionBytes?: Uint8Array, readingBytes?: Uint8Array, expressionReverse?: string, readingReverse?: string, score: number, sequence?: number}} */ (rows[start + i]);
            const id = this._nextId++;
            const dictionary = row.dictionary;
            const entryContentDictName = uniformContentDictName ?? (contentDictNames[i] ?? 'raw');
            /** @type {TermRecord} */
            const record = {
                id,
                dictionary,
                expression: row.expression,
                reading: row.reading,
                readingEqualsExpression: row.readingEqualsExpression === true,
                expressionBytes: row.expressionBytes instanceof Uint8Array ? row.expressionBytes : void 0,
                readingBytes: row.readingBytes instanceof Uint8Array ? row.readingBytes : void 0,
                expressionReverse: row.expressionReverse ?? null,
                readingReverse: row.readingReverse ?? null,
                entryContentOffset: contentOffsets[i],
                entryContentLength: contentLengths[i],
                entryContentDictName,
                score: row.score,
                sequence: typeof row.sequence === 'number' ? row.sequence : null,
            };
            this._cacheAppendedRecord(record);
            if (i === 0) {
                firstDictionaryName = dictionary;
                firstContentDictName = entryContentDictName;
            }
            if (recordsByShard === null) {
                if (dictionary === firstDictionaryName && entryContentDictName === firstContentDictName) {
                    singleDictionaryRecords[singleDictionaryRecordCount++] = record;
                } else {
                    recordsByShard = new Map();
                    recordsByShard.set(
                        this._getShardFileName(firstDictionaryName, firstContentDictName),
                        {
                            records: singleDictionaryRecords.slice(0, singleDictionaryRecordCount),
                            indexes: Array.from({length: singleDictionaryRecordCount}, (_value, index) => index),
                        },
                    );
                    recordsByShard.set(
                        this._getShardFileName(dictionary, entryContentDictName),
                        {records: [record], indexes: [i]},
                    );
                }
            } else {
                const shardFileName = this._getShardFileName(dictionary, entryContentDictName);
                let shardRecords = recordsByShard.get(shardFileName);
                if (typeof shardRecords === 'undefined') {
                    shardRecords = {records: [], indexes: []};
                    recordsByShard.set(shardFileName, shardRecords);
                }
                shardRecords.records.push(record);
                shardRecords.indexes.push(i);
            }
            if (!this._deferIndexBuild) {
                const existingIndex = this._indexByDictionary.get(dictionary);
                if (typeof existingIndex !== 'undefined') {
                    this._addRecordToDictionaryIndex(existingIndex, record);
                }
            }
        }
        if (this._deferIndexBuild) {
            this._indexDirty = true;
        }
        buildRecordsMs = safePerformance.now() - tBuildStart;
        const preinternedPlan = (
            start === 0 &&
            count === rows.length &&
            rows !== null &&
            typeof rows === 'object'
        ) ?
            getTermRecordPreinternedPlan(rows) :
            null;
        if (recordsByShard === null) {
            const state = await this._getOrCreateShardState(firstDictionaryName, firstContentDictName);
            if (state !== null) {
                const metrics = await this._encodeAndAppendChunkRunsForState(state, singleDictionaryRecords, preinternedPlan);
                encodeMs += metrics.encodeMs;
                appendWriteMs += metrics.appendWriteMs;
            }
            return {buildRecordsMs, encodeMs, appendWriteMs};
        }
        for (const {records: dictionaryRecords, indexes} of recordsByShard.values()) {
            const firstRecord = dictionaryRecords[0];
            const state = await this._getOrCreateShardState(firstRecord.dictionary, firstRecord.entryContentDictName);
            if (state === null) { continue; }
            const metrics = await this._encodeAndAppendChunkRunsForState(
                state,
                dictionaryRecords,
                preinternedPlan,
                indexes,
            );
            encodeMs += metrics.encodeMs;
            appendWriteMs += metrics.appendWriteMs;
        }
        return {buildRecordsMs, encodeMs, appendWriteMs};
    }

    /**
     * @param {{dictionary: string, rowCount: number, dictionaryTotalRows?: number, expressionBytesList: Uint8Array[], readingBytesList: Uint8Array[], readingEqualsExpressionList: boolean[]|Uint8Array, scoreList: number[]|Int32Array|Float64Array, sequenceList: (number|undefined)[]|Int32Array|Float64Array, fixedContentOffsetBase?: number, fixedContentLength?: number, resolvedContentReferences?: {uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}, termRecordPreinternedPlan?: import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan|null, preparedLookupIndexes?: Map<string, {bytes: Uint8Array, preinternedPlan: import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan}>}} chunk
     * @param {number[]|Uint32Array|Float64Array} contentOffsets
     * @param {number[]|Uint32Array} contentLengths
     * @param {string | (string|null)[]} contentDictNames
     * @returns {Promise<{buildRecordsMs: number, encodeMs: number, appendWriteMs: number, validationMs: number, recordFieldEncodeMs: number, lookupIndexEncodeMs: number}>}
     */
    async appendBatchFromArtifactChunkResolvedContent(chunk, contentOffsets, contentLengths, contentDictNames) {
        const count = chunk.rowCount;
        if (count <= 0) {
            return {
                buildRecordsMs: 0,
                encodeMs: 0,
                appendWriteMs: 0,
                validationMs: 0,
                recordFieldEncodeMs: 0,
                lookupIndexEncodeMs: 0,
            };
        }
        const fixedContentSpan = hasFixedContentSpan(chunk, count);
        const resolvedContentReferences = hasResolvedContentReferences(chunk, count);
        if (
            (!fixedContentSpan && !resolvedContentReferences && (contentOffsets.length < count || contentLengths.length < count)) ||
            (Array.isArray(contentDictNames) && contentDictNames.length < count)
        ) {
            throw new Error('appendBatchFromArtifactChunkResolvedContent content arrays are smaller than row count');
        }
        const uniformContentDictName = Array.isArray(contentDictNames) ? null : (contentDictNames ?? 'raw');
        if (uniformContentDictName !== null) {
            this._assertShardAcceptsAppend(chunk.dictionary, uniformContentDictName);
        } else {
            let previousContentDictName = '';
            for (let i = 0; i < count; ++i) {
                const contentDictName = contentDictNames[i] ?? 'raw';
                if (i === 0 || contentDictName !== previousContentDictName) {
                    this._assertShardAcceptsAppend(chunk.dictionary, contentDictName);
                    previousContentDictName = contentDictName;
                }
            }
        }
        await this._ensureNextIdReadyForAppend(count);
        const tBuildStart = safePerformance.now();
        const firstId = this._nextId;
        const firstContentDictName = uniformContentDictName ?? (contentDictNames[0] ?? 'raw');
        const preinternedPlan = chunk.termRecordPreinternedPlan ?? null;
        const stableStringLengths = preinternedPlan?.stringLengths;
        const stableStringsBuffer = preinternedPlan?.stringsBuffer;
        const stableExpressionIndexes = preinternedPlan?.expressionIndexes;
        const stableReadingIndexes = preinternedPlan?.readingIndexes;
        const skipRecordMaterialization = (
            this._importSessionActive &&
            (chunk.dictionaryTotalRows ?? count) >= PERSISTED_ONLY_IMPORT_ROW_THRESHOLD
        );
        const stableStringOffsets = skipRecordMaterialization ?
            null :
            (
                preinternedPlan?.stringOffsets instanceof Uint32Array ?
                    preinternedPlan.stringOffsets :
                    reconstructTermStringOffsets(stableStringLengths, stableStringsBuffer?.byteLength ?? -1)
            );
        const hasStableStringSlices = (
            stableStringOffsets instanceof Uint32Array &&
            stableStringLengths instanceof Uint16Array &&
            stableStringsBuffer instanceof Uint8Array &&
            stableExpressionIndexes instanceof Uint32Array &&
            stableReadingIndexes instanceof Uint32Array &&
            stableStringOffsets.length === stableStringLengths.length &&
            stableExpressionIndexes.length >= count &&
            stableReadingIndexes.length >= count
        );
        if (skipRecordMaterialization) {
            this._nextId += count;
            this._reloadFromShardsAfterImport = true;
            this._loadedDictionaryNames.delete(chunk.dictionary);
            this._allShardContentsLoaded = false;
        } else {
            this._recordsById.ensureCapacity(firstId + count - 1);
            const existingIndex = this._deferIndexBuild ? void 0 : this._indexByDictionary.get(chunk.dictionary);
            for (let i = 0; i < count; ++i) {
                const id = this._nextId++;
                const sequenceValue = chunk.sequenceList[i];
                const entryContentDictName = uniformContentDictName ?? (contentDictNames[i] ?? 'raw');
                const expressionIndex = stableExpressionIndexes?.[i] ?? -1;
                const readingIndex = stableReadingIndexes?.[i] ?? -1;
                const hasStableExpression = hasStableStringSlices && expressionIndex >= 0 && expressionIndex < stableStringLengths.length;
                const hasStableReading = hasStableStringSlices && readingIndex >= 0 && readingIndex < stableStringLengths.length;
                const expressionOffset = hasStableExpression ? stableStringOffsets[expressionIndex] : 0;
                const readingOffset = hasStableReading ? stableStringOffsets[readingIndex] : 0;
                const expressionBytes = hasStableExpression ?
                    stableStringsBuffer.subarray(expressionOffset, expressionOffset + stableStringLengths[expressionIndex]) :
                    chunk.expressionBytesList[i];
                const readingBytes = hasStableReading ?
                    stableStringsBuffer.subarray(readingOffset, readingOffset + stableStringLengths[readingIndex]) :
                    chunk.readingBytesList[i];
                /** @type {TermRecord} */
                const record = {
                    id,
                    dictionary: chunk.dictionary,
                    readingEqualsExpression: chunk.readingEqualsExpressionList[i] === true || chunk.readingEqualsExpressionList[i] === 1,
                    expressionBytes,
                    readingBytes: (chunk.readingEqualsExpressionList[i] === true || chunk.readingEqualsExpressionList[i] === 1) ? void 0 : readingBytes,
                    entryContentOffset: getArtifactContentOffset(chunk, contentOffsets, i),
                    entryContentLength: getArtifactContentLength(chunk, contentLengths, i),
                    entryContentDictName,
                    score: chunk.scoreList[i] ?? 0,
                    sequence: typeof sequenceValue === 'number' && sequenceValue >= 0 ? sequenceValue : null,
                };
                this._cacheAppendedRecord(record);
                if (typeof existingIndex !== 'undefined') {
                    this._addRecordToDictionaryIndex(existingIndex, record);
                }
            }
            if (this._deferIndexBuild) {
                this._indexDirty = true;
            }
        }
        const buildRecordsMs = safePerformance.now() - tBuildStart;
        let encodeMs = 0;
        let appendWriteMs = 0;
        let validationMs = 0;
        let recordFieldEncodeMs = 0;
        let lookupIndexEncodeMs = 0;
        if (uniformContentDictName !== null) {
            const state = await this._getOrCreateShardState(chunk.dictionary, uniformContentDictName);
            if (state === null) {
                return {buildRecordsMs, encodeMs, appendWriteMs, validationMs, recordFieldEncodeMs, lookupIndexEncodeMs};
            }
            const metrics = await this._encodeAndAppendArtifactChunkForState(
                state,
                chunk,
                firstId,
                contentOffsets,
                contentLengths,
                chunk.termRecordPreinternedPlan ?? null,
                uniformContentDictName,
                chunk.preparedLookupIndexes ?? null,
            );
            encodeMs += metrics.encodeMs;
            appendWriteMs += metrics.appendWriteMs;
            validationMs += metrics.validationMs;
            recordFieldEncodeMs += metrics.recordFieldEncodeMs;
            lookupIndexEncodeMs += metrics.lookupIndexEncodeMs;
            return {buildRecordsMs, encodeMs, appendWriteMs, validationMs, recordFieldEncodeMs, lookupIndexEncodeMs};
        }
        let singleContentDictName = true;
        for (let i = 1; i < count; ++i) {
            if ((contentDictNames[i] ?? 'raw') !== firstContentDictName) {
                singleContentDictName = false;
                break;
            }
        }
        if (singleContentDictName) {
            const state = await this._getOrCreateShardState(chunk.dictionary, firstContentDictName);
            if (state === null) {
                return {buildRecordsMs, encodeMs, appendWriteMs, validationMs, recordFieldEncodeMs, lookupIndexEncodeMs};
            }
            const metrics = await this._encodeAndAppendArtifactChunkForState(
                state,
                chunk,
                firstId,
                contentOffsets,
                contentLengths,
                chunk.termRecordPreinternedPlan ?? null,
                firstContentDictName,
                chunk.preparedLookupIndexes ?? null,
            );
            encodeMs += metrics.encodeMs;
            appendWriteMs += metrics.appendWriteMs;
            validationMs += metrics.validationMs;
            recordFieldEncodeMs += metrics.recordFieldEncodeMs;
            lookupIndexEncodeMs += metrics.lookupIndexEncodeMs;
            return {buildRecordsMs, encodeMs, appendWriteMs, validationMs, recordFieldEncodeMs, lookupIndexEncodeMs};
        }
        for (let runStart = 0; runStart < count;) {
            const contentDictName = contentDictNames[runStart] ?? 'raw';
            let runEnd = runStart + 1;
            while (runEnd < count && (contentDictNames[runEnd] ?? 'raw') === contentDictName) {
                ++runEnd;
            }
            const runCount = runEnd - runStart;
            const state = await this._getOrCreateShardState(chunk.dictionary, contentDictName);
            if (state === null) {
                runStart = runEnd;
                continue;
            }
            /** @type {{dictionary: string, rowCount: number, dictionaryTotalRows?: number, expressionBytesList: Uint8Array[], readingBytesList: Uint8Array[], readingEqualsExpressionList: boolean[]|Uint8Array, scoreList: number[]|Int32Array|Float64Array, sequenceList: (number|undefined)[]|Int32Array|Float64Array, resolvedContentReferences?: {uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}, termRecordPreinternedPlan?: import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan|null}} */
            const chunkSlice = {
                dictionary: chunk.dictionary,
                rowCount: runCount,
                expressionBytesList: chunk.expressionBytesList.slice(runStart, runEnd),
                readingBytesList: chunk.readingBytesList.slice(runStart, runEnd),
                readingEqualsExpressionList: chunk.readingEqualsExpressionList.slice(runStart, runEnd),
                scoreList: chunk.scoreList.slice(runStart, runEnd),
                sequenceList: chunk.sequenceList.slice(runStart, runEnd),
                termRecordPreinternedPlan: sliceTermRecordPreinternedPlan(chunk.termRecordPreinternedPlan ?? null, runStart, runCount),
                resolvedContentReferences: sliceResolvedContentReferences(chunk, runStart, runEnd),
            };
            const metrics = await this._encodeAndAppendArtifactChunkForState(
                state,
                chunkSlice,
                firstId + runStart,
                contentOffsets.slice(runStart, runEnd),
                contentLengths.slice(runStart, runEnd),
                chunkSlice.termRecordPreinternedPlan ?? null,
                contentDictName,
            );
            encodeMs += metrics.encodeMs;
            appendWriteMs += metrics.appendWriteMs;
            validationMs += metrics.validationMs;
            recordFieldEncodeMs += metrics.recordFieldEncodeMs;
            lookupIndexEncodeMs += metrics.lookupIndexEncodeMs;
            runStart = runEnd;
        }
        return {buildRecordsMs, encodeMs, appendWriteMs, validationMs, recordFieldEncodeMs, lookupIndexEncodeMs};
    }

    /**
     * @param {TermRecordShardState} state
     * @param {TermRecord[]} records
     * @param {import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan|null} [preinternedPlan]
     * @returns {Promise<{encodeMs: number, appendWriteMs: number}>}
     */
    async _encodeAndAppendChunkForState(state, records, preinternedPlan = null) {
        const tEncodeStart = safePerformance.now();
        const {contentOffsetBase, lookupIndexBytes, recordFields, recordFieldsFormat} = await this._encodeRecords(records, preinternedPlan);
        const encodeMs = safePerformance.now() - tEncodeStart;
        const tAppendStart = safePerformance.now();
        await this._appendEncodedChunk(
            state,
            records[0]?.id ?? 0,
            records.length,
            records[0]?.entryContentDictName ?? 'raw',
            contentOffsetBase,
            lookupIndexBytes,
            recordFields,
            recordFieldsFormat,
        );
        const appendWriteMs = safePerformance.now() - tAppendStart;
        return {encodeMs, appendWriteMs};
    }

    /**
     * The current shard format stores `firstId` and `count` per chunk, so the
     * records written in a single chunk must have contiguous IDs.
     * @param {TermRecordShardState} state
     * @param {TermRecord[]} records
     * @param {import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan|null} [preinternedPlan]
     * @param {number[]|null} [recordIndexes=null]
     * @returns {Promise<{encodeMs: number, appendWriteMs: number}>}
     */
    async _encodeAndAppendChunkRunsForState(state, records, preinternedPlan = null, recordIndexes = null) {
        let encodeMs = 0;
        let appendWriteMs = 0;
        for (let runStart = 0; runStart < records.length;) {
            let runEnd = runStart + 1;
            let minContentOffset = records[runStart].entryContentOffset >= 0 ? records[runStart].entryContentOffset : Number.POSITIVE_INFINITY;
            let maxContentOffset = records[runStart].entryContentOffset >= 0 ? records[runStart].entryContentOffset : Number.NEGATIVE_INFINITY;
            while (runEnd < records.length && records[runEnd].id === (records[runEnd - 1].id + 1)) {
                const contentOffset = records[runEnd].entryContentOffset;
                const nextMinContentOffset = contentOffset >= 0 ? Math.min(minContentOffset, contentOffset) : minContentOffset;
                const nextMaxContentOffset = contentOffset >= 0 ? Math.max(maxContentOffset, contentOffset) : maxContentOffset;
                if (
                    nextMinContentOffset !== Number.POSITIVE_INFINITY &&
                    (nextMaxContentOffset - nextMinContentOffset) > MAX_CONTENT_OFFSET_DELTA
                ) {
                    break;
                }
                minContentOffset = nextMinContentOffset;
                maxContentOffset = nextMaxContentOffset;
                ++runEnd;
            }
            const runRecords = records.slice(runStart, runEnd);
            const runPlan = (
                recordIndexes !== null ?
                    selectTermRecordPreinternedPlan(preinternedPlan, recordIndexes.slice(runStart, runEnd)) :
                    sliceTermRecordPreinternedPlan(preinternedPlan, runStart, runEnd - runStart)
            );
            const metrics = await this._encodeAndAppendChunkForState(state, runRecords, runPlan);
            encodeMs += metrics.encodeMs;
            appendWriteMs += metrics.appendWriteMs;
            runStart = runEnd;
        }
        return {encodeMs, appendWriteMs};
    }

    /**
     * @param {TermRecordShardState} state
     * @param {{dictionary: string, rowCount: number, expressionBytesList: Uint8Array[], readingBytesList: Uint8Array[], readingEqualsExpressionList: boolean[]|Uint8Array, scoreList: number[]|Int32Array|Float64Array, sequenceList: (number|undefined)[]|Int32Array|Float64Array, fixedContentOffsetBase?: number, fixedContentLength?: number, resolvedContentReferences?: {uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}}} chunk
     * @param {number} firstId
     * @param {number[]|Uint32Array|Float64Array} contentOffsets
     * @param {number[]|Uint32Array} contentLengths
     * @param {import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan|null} [preinternedPlan]
     * @param {string} [contentDictName='raw']
     * @param {Map<string, {bytes: Uint8Array, preinternedPlan: import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan}>|null} [preparedLookupIndexes=null]
     * @returns {Promise<{encodeMs: number, appendWriteMs: number, validationMs: number, recordFieldEncodeMs: number, lookupIndexEncodeMs: number}>}
     */
    async _encodeAndAppendArtifactChunkForState(state, chunk, firstId, contentOffsets, contentLengths, preinternedPlan = null, contentDictName = 'raw', preparedLookupIndexes = null) {
        let encodeMs = 0;
        let appendWriteMs = 0;
        let validationMs = 0;
        let recordFieldEncodeMs = 0;
        let lookupIndexEncodeMs = 0;
        const count = chunk.rowCount;
        const hasWholeChunkPreparedIndex = (
            preparedLookupIndexes?.has(`0:${count}`) === true &&
            hasCompletePreparedTermLookupIndexes(preparedLookupIndexes, count)
        );
        const runRowLimit = hasWholeChunkPreparedIndex ? count : MAX_COMPACT_LOOKUP_INDEX_ROWS;
        for (let runStart = 0; runStart < count;) {
            // Recompute after every awaited append; no validity is cached
            // across runs. The row loop itself is synchronous.
            const tValidationStart = safePerformance.now();
            const useFixedContentSpan = hasFixedContentSpan(chunk, count);
            let runEnd = runStart;
            let minContentOffset = Number.POSITIVE_INFINITY;
            let maxContentOffset = Number.NEGATIVE_INFINITY;
            while (runEnd < count) {
                if ((runEnd - runStart) >= runRowLimit) {
                    break;
                }
                const contentOffset = getArtifactContentOffset(chunk, contentOffsets, runEnd, useFixedContentSpan);
                const contentLength = getArtifactContentLength(chunk, contentLengths, runEnd);
                validateContentOffset(contentOffset);
                validateContentLength(contentLength);
                const nextMinContentOffset = contentOffset >= 0 ? Math.min(minContentOffset, contentOffset) : minContentOffset;
                const nextMaxContentOffset = contentOffset >= 0 ? Math.max(maxContentOffset, contentOffset) : maxContentOffset;
                if (
                    runEnd > runStart &&
                    nextMinContentOffset !== Number.POSITIVE_INFINITY &&
                    (nextMaxContentOffset - nextMinContentOffset) > MAX_CONTENT_OFFSET_DELTA
                ) {
                    break;
                }
                minContentOffset = nextMinContentOffset;
                maxContentOffset = nextMaxContentOffset;
                ++runEnd;
            }
            const runContentOffsetBase = minContentOffset === Number.POSITIVE_INFINITY ? 0 : minContentOffset;
            const runValidationMs = safePerformance.now() - tValidationStart;
            const runCount = runEnd - runStart;
            const isWholeChunk = runStart === 0 && runEnd === count;
            const runChunk = isWholeChunk ?
                chunk :
                {
                    dictionary: chunk.dictionary,
                    rowCount: runCount,
                    expressionBytesList: chunk.expressionBytesList.slice(runStart, runEnd),
                    readingBytesList: chunk.readingBytesList.slice(runStart, runEnd),
                    readingEqualsExpressionList: chunk.readingEqualsExpressionList.slice(runStart, runEnd),
                    scoreList: chunk.scoreList.slice(runStart, runEnd),
                    sequenceList: chunk.sequenceList.slice(runStart, runEnd),
                    fixedContentOffsetBase: (
                        typeof chunk.fixedContentOffsetBase === 'number' && typeof chunk.fixedContentLength === 'number' ?
                            chunk.fixedContentOffsetBase + (runStart * chunk.fixedContentLength) :
                            void 0
                    ),
                    fixedContentLength: chunk.fixedContentLength,
                    resolvedContentReferences: sliceResolvedContentReferences(chunk, runStart, runEnd),
                };
            const runUsesContentReferences = hasResolvedContentReferences(runChunk, runCount);
            const runOffsets = isWholeChunk || hasFixedContentSpan(runChunk, runCount) || runUsesContentReferences ? contentOffsets : contentOffsets.slice(runStart, runEnd);
            const runLengths = isWholeChunk || hasFixedContentSpan(runChunk, runCount) || runUsesContentReferences ? contentLengths : contentLengths.slice(runStart, runEnd);
            const preparedLookupIndex = preparedLookupIndexes?.get(`${runStart}:${runCount}`) ?? null;
            const runPlan = preparedLookupIndex?.preinternedPlan ?? compactTermRecordPreinternedPlan(
                preinternedPlan,
                runStart,
                runCount,
                this._getPreinternedCompactionRemap(preinternedPlan?.stringLengths.length ?? 0),
                chunk.readingEqualsExpressionList,
            );
            const tEncodeStart = safePerformance.now();
            const encodedChunk = await this._encodeArtifactChunkRecords(
                runChunk,
                runOffsets,
                runLengths,
                runPlan,
                preparedLookupIndex?.bytes ?? null,
                runContentOffsetBase,
            );
            encodeMs += safePerformance.now() - tEncodeStart;
            validationMs += runValidationMs + encodedChunk.validationMs;
            recordFieldEncodeMs += encodedChunk.recordFieldEncodeMs;
            lookupIndexEncodeMs += encodedChunk.lookupIndexEncodeMs;
            const tAppendStart = safePerformance.now();
            await this._appendEncodedChunk(
                state,
                firstId + runStart,
                runCount,
                contentDictName,
                encodedChunk.contentOffsetBase,
                encodedChunk.lookupIndexBytes,
                encodedChunk.recordFields,
                encodedChunk.recordFieldsFormat,
            );
            appendWriteMs += safePerformance.now() - tAppendStart;
            runStart = runEnd;
        }
        return {encodeMs, appendWriteMs, validationMs, recordFieldEncodeMs, lookupIndexEncodeMs};
    }

    /**
     * Builds offset-independent lookup sidecars before term content persistence
     * completes. Exact range keys ensure offset-driven shard splits safely fall
     * back to the normal encoder.
     * @param {{rowCount: number, readingEqualsExpressionList: boolean[]|Uint8Array, sequenceList: (number|undefined)[]|Int32Array|Float64Array, termRecordPreinternedPlan?: import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan|null}} chunk
     * @returns {{indexes: Map<string, {bytes: Uint8Array, preinternedPlan: import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan}>, encodeMs: number}|null}
     */
    prepareArtifactChunkLookupIndexes(chunk) {
        const result = prepareTermLookupIndexesFromPreinternedPlan(
            chunk,
            this._getPreinternedCompactionRemap(chunk.termRecordPreinternedPlan?.stringLengths.length ?? 0),
        );
        return result === null ? null : {indexes: result.indexes, encodeMs: result.totalMs};
    }

    /**
     * @param {number} minimumLength
     * @returns {Uint32Array}
     */
    _getPreinternedCompactionRemap(minimumLength) {
        if (this._preinternedCompactionRemap.length < minimumLength) {
            this._preinternedCompactionRemap = new Uint32Array(minimumLength);
        }
        return this._preinternedCompactionRemap;
    }

    /**
     * @param {string} dictionaryName
     * @returns {Promise<number>}
     */
    async deleteByDictionary(dictionaryName) {
        return await this._runExclusiveStorageMutation(async () => await this._deleteByDictionary(dictionaryName));
    }

    /**
     * @param {string} dictionaryName
     * @returns {Promise<number>}
     */
    async _deleteByDictionary(dictionaryName) {
        this._loadedDictionaryNames.delete(dictionaryName);
        this._allShardContentsLoaded = false;
        let deletedCount = 0;
        const ids = this._getLiveRecordIdsForDictionary(dictionaryName) ?? [...this._recordsById.keys()];
        for (const id of ids) {
            const record = this._recordsById.get(id);
            if (typeof record === 'undefined' || record.dictionary !== dictionaryName) { continue; }
            this._deleteRecord(id);
            ++deletedCount;
        }
        this._recordIdsByDictionary.delete(dictionaryName);
        this._recordIdStaleDictionaryNames.delete(dictionaryName);
        this._indexByDictionary.delete(dictionaryName);
        this._invalidatePersistentLookupState(dictionaryName);
        this._setDictionaryHealth(dictionaryName, 'available');
        await this._deleteShardByDictionary(dictionaryName);
        return deletedCount;
    }

    /**
     * @param {string} fromDictionaryName
     * @param {string} toDictionaryName
     * @param {boolean} [preserveSourceFiles=false]
     * @returns {Promise<number>}
     */
    async replaceDictionaryName(fromDictionaryName, toDictionaryName, preserveSourceFiles = false) {
        return await this._runExclusiveStorageMutation(async () => await this._replaceDictionaryName(
            fromDictionaryName,
            toDictionaryName,
            preserveSourceFiles,
        ));
    }

    /**
     * Removes a destination copy created with preserveSourceFiles=true and
     * reloads the still-authoritative source shards.
     * @param {string} fromDictionaryName
     * @param {string} toDictionaryName
     * @returns {Promise<void>}
     * @throws {Error} If rollback cleanup or source reload fails.
     */
    async rollbackPreservedDictionaryRename(fromDictionaryName, toDictionaryName) {
        const fromName = `${fromDictionaryName}`;
        const toName = `${toDictionaryName}`;
        if (fromName.length === 0 || toName.length === 0 || fromName === toName) {
            throw new Error('Dictionary rename rollback titles must be distinct and non-empty');
        }
        await this._runExclusiveStorageMutation(async () => {
            if (this._recordsDirectoryHandle === null) {
                await this._replaceDictionaryName(toName, fromName, false);
                return;
            }
            /** @type {Error[]} */
            const errors = [];
            try {
                await this._cleanupShardFilesByDictionaryPredicate((dictionaryName) => dictionaryName === toName);
            } catch (error) {
                errors.push(toError(error));
            }
            try {
                await this._prepare();
            } catch (error) {
                errors.push(toError(error));
            }
            if (errors.length > 0) {
                throw new AggregateError(errors, `Failed to roll back preserved dictionary rename ${toName} to ${fromName}`);
            }
        });
    }

    /**
     * @param {string} fromDictionaryName
     * @param {string} toDictionaryName
     * @param {boolean} preserveSourceFiles
     * @returns {Promise<number>}
     */
    async _replaceDictionaryName(fromDictionaryName, toDictionaryName, preserveSourceFiles) {
        const fromName = `${fromDictionaryName}`;
        const toName = `${toDictionaryName}`;
        if (fromName.length === 0 || toName.length === 0 || fromName === toName) {
            return 0;
        }

        this._loadedDictionaryNames.delete(fromName);
        this._loadedDictionaryNames.delete(toName);
        this._allShardContentsLoaded = false;
        await this._flushPendingWrites();
        await this._awaitQueuedWrites();
        await this._closeAllWritables();
        const [sourceIndexLoaded] = await Promise.all([
            this._tryLoadPersistentDictionaryIndex(fromName),
            this._tryLoadPersistentDictionaryIndex(toName),
        ]);
        const hasLiveTargetRecords = this._hasRecordsForDictionary(toName);
        if (!hasLiveTargetRecords && !this._indexByDictionary.has(toName)) {
            const removedStaleTargetFiles = await this._cleanupShardFilesByDictionaryPredicate((dictionaryName) => dictionaryName === toName);
            if (removedStaleTargetFiles.length > 0) {
                reportDiagnostics('term-record-store-rename-cleanup-stale-target', {
                    fromName,
                    toName,
                    removedStaleTargetFiles,
                });
            }
        }

        const sourceStates = [...this._shardStateByFileName.values()]
            .filter((state) => this._decodeDictionaryNameFromShardFileName(state.fileName) === fromName)
            .sort((a, b) => a.fileName.localeCompare(b.fileName));
        let hasUsableSourceIndex = sourceIndexLoaded;
        if (!hasUsableSourceIndex && sourceStates.length > 0) {
            hasUsableSourceIndex = await this._tryRepairPersistentDictionaryIndex(fromName, true) &&
            await this._tryLoadPersistentDictionaryIndex(fromName);
            if (!hasUsableSourceIndex) {
                throw new Error(`Cannot rename dictionary with unreadable authoritative term records: ${fromName}`);
            }
        }

        const recordIdsToRename = [];
        const candidateRecordIds = this._getLiveRecordIdsForDictionary(fromName) ?? this._recordsById.keys();
        for (const id of candidateRecordIds) {
            const record = this._recordsById.get(id);
            if (typeof record === 'undefined' || record.dictionary !== fromName) { continue; }
            recordIdsToRename.push(id);
        }
        const renamedCount = recordIdsToRename.length > 0 ?
            recordIdsToRename.length :
            (this._persistentRecordChunksByDictionary.get(fromName) ?? []).reduce((sum, {count}) => sum + count, 0);
        if (renamedCount === 0) {
            if (sourceStates.length > 0) {
                throw new Error(`Cannot establish source record count for dictionary rename: ${fromName}`);
            }
            return 0;
        }

        if (this._recordsDirectoryHandle === null) {
            for (const id of recordIdsToRename) {
                const record = this._recordsById.get(id);
                if (typeof record !== 'undefined') {
                    record.dictionary = toName;
                }
            }
            this._renameRecordIdIndex(fromName, toName, recordIdsToRename);
            this._indexByDictionary.delete(fromName);
            this._indexByDictionary.delete(toName);
            this._indexDirty = false;
            this._setDictionaryHealth(fromName, 'available');
            this._setDictionaryHealth(toName, 'available');
            return renamedCount;
        }
        /** @type {TermRecordRenamePlan[]} */
        const renamePlans = [];
        for (const state of sourceStates) {
            let file;
            try {
                file = await state.fileHandle.getFile();
            } catch (error) {
                throw new Error(`Cannot read source shard during dictionary rename: ${state.fileName}`, {cause: error});
            }
            const shardInfo = this._decodeShardInfoFromShardFileName(state.fileName);
            if (shardInfo === null) {
                throw new Error(`Cannot decode source shard name during dictionary rename: ${state.fileName}`);
            }
            let indexFile;
            try {
                const indexFileHandle = await this._recordsDirectoryHandle.getFileHandle(
                    `${state.fileName}${LOOKUP_INDEX_FILE_SUFFIX}`,
                    {create: false},
                );
                indexFile = await indexFileHandle.getFile();
            } catch (error) {
                throw new Error(`Cannot read authoritative source container during dictionary rename: ${state.fileName}`, {cause: error});
            }
            const nextFileName = this._getShardSegmentFileName(toName, shardInfo.contentDictName, shardInfo.segmentIndex);
            const existingTargetState = this._shardStateByFileName.get(nextFileName);
            if (typeof existingTargetState !== 'undefined') {
                if (hasLiveTargetRecords) {
                    throw new Error(`Target shard file already exists for dictionary rename: ${nextFileName}`);
                }
                await this._flushPendingWritesForShard(existingTargetState);
                await this._closeShardWritable(existingTargetState);
                this._shardStateByFileName.delete(nextFileName);
                this._activeAppendShardStateByKey.delete(existingTargetState.logicalKey);
                try {
                    await this._recordsDirectoryHandle.removeEntry(nextFileName);
                } catch (_) {
                    // NOP - fall through and let create/write validation below fail if cleanup was insufficient.
                }
                try {
                    await this._recordsDirectoryHandle.removeEntry(`${nextFileName}${LOOKUP_INDEX_FILE_SUFFIX}`);
                } catch (_) {
                    // NOP
                }
                reportDiagnostics('term-record-store-rename-remove-colliding-target', {
                    fromName,
                    toName,
                    nextFileName,
                });
            }
            const nextFileHandle = await this._recordsDirectoryHandle.getFileHandle(nextFileName, {create: true});
            try {
                const nextFile = await nextFileHandle.getFile();
                if (nextFile.size > 0) {
                    if (!hasLiveTargetRecords) {
                        try {
                            await this._recordsDirectoryHandle.removeEntry(nextFileName);
                            try {
                                await this._recordsDirectoryHandle.removeEntry(`${nextFileName}${LOOKUP_INDEX_FILE_SUFFIX}`);
                            } catch (_) {
                                // NOP
                            }
                            reportDiagnostics('term-record-store-rename-remove-colliding-target-bytes', {
                                fromName,
                                toName,
                                nextFileName,
                                nextFileSize: nextFile.size,
                            });
                            const replacementHandle = await this._recordsDirectoryHandle.getFileHandle(nextFileName, {create: true});
                            renamePlans.push({
                                state,
                                shardInfo,
                                nextFileName,
                                nextFileHandle: replacementHandle,
                                file,
                                fileSize: file.size,
                                indexFile,
                            });
                            continue;
                        } catch (_) {
                            // NOP - fall through to the explicit collision error below.
                        }
                    }
                    throw new Error(`Target shard file already contains data for dictionary rename: ${nextFileName}`);
                }
            } catch (e) {
                if (e instanceof Error && /already contains data|already exists/.test(e.message)) {
                    throw e;
                }
                throw new Error(`Cannot inspect target shard during dictionary rename: ${nextFileName}`, {cause: e});
            }
            renamePlans.push({
                state,
                shardInfo,
                nextFileName,
                nextFileHandle,
                file,
                fileSize: file.size,
                indexFile,
            });
        }
        /**
         * @param {FileSystemFileHandle} fileHandle
         * @param {File} file
         * @returns {Promise<void>}
         */
        const writeShardFile = async (fileHandle, file) => {
            const writable = await fileHandle.createWritable();
            try {
                await writable.truncate(0);
                if (file.size > 0) {
                    await writable.write(file);
                }
            } finally {
                await writable.close();
            }
        };
        /** @type {TermRecordRenamePlan[]} */
        const createdPlans = [];
        /** @type {TermRecordRenamePlan[]} */
        const removedPlans = [];
        try {
            for (const plan of renamePlans) {
                // Cleanup owns this destination before the first mutating write.
                // If the shard copy succeeds but index creation/write fails, the
                // partially-created destination must still be removed.
                createdPlans.push(plan);
                await writeShardFile(plan.nextFileHandle, plan.file);
                const nextIndexHandle = await this._recordsDirectoryHandle.getFileHandle(
                    `${plan.nextFileName}${LOOKUP_INDEX_FILE_SUFFIX}`,
                    {create: true},
                );
                await writeShardFile(nextIndexHandle, plan.indexFile);
            }
            if (!preserveSourceFiles) {
                for (const plan of renamePlans) {
                    // Restoration owns the source before the first delete. An
                    // index-only orphan is recoverable as a descriptor on
                    // startup, so failing to remove the old index cannot be
                    // treated as a successful rename.
                    removedPlans.push(plan);
                    await this._recordsDirectoryHandle.removeEntry(plan.state.fileName);
                    await this._recordsDirectoryHandle.removeEntry(`${plan.state.fileName}${LOOKUP_INDEX_FILE_SUFFIX}`);
                }
            }
        } catch (e) {
            /** @type {Error[]} */
            const cleanupErrors = [];
            for (const plan of [...removedPlans].reverse()) {
                try {
                    const restoredHandle = await this._recordsDirectoryHandle.getFileHandle(plan.state.fileName, {create: true});
                    await writeShardFile(restoredHandle, plan.file);
                    const restoredIndexHandle = await this._recordsDirectoryHandle.getFileHandle(
                        `${plan.state.fileName}${LOOKUP_INDEX_FILE_SUFFIX}`,
                        {create: true},
                    );
                    await writeShardFile(restoredIndexHandle, plan.indexFile);
                } catch (error) {
                    cleanupErrors.push(toError(error));
                }
            }
            for (const plan of [...createdPlans].reverse()) {
                // Remove/truncate the recoverable index first. If unlinking is
                // blocked by another runtime, an empty index cannot recreate the
                // destination descriptor on the next startup.
                try {
                    await this._removeStorageFileOrTruncate(
                        `${plan.nextFileName}${LOOKUP_INDEX_FILE_SUFFIX}`,
                        true,
                    );
                } catch (error) {
                    cleanupErrors.push(toError(error));
                }
                try {
                    await this._removeStorageFileOrTruncate(plan.nextFileName, true);
                } catch (error) {
                    cleanupErrors.push(toError(error));
                }
            }
            if (cleanupErrors.length > 0) {
                throw new AggregateError(
                    [toError(e), ...cleanupErrors],
                    `Dictionary rename and rollback cleanup failed for ${fromName} to ${toName}`,
                );
            }
            throw e;
        }

        for (const id of recordIdsToRename) {
            const record = this._recordsById.get(id);
            if (typeof record !== 'undefined') {
                record.dictionary = toName;
            }
        }
        this._renameRecordIdIndex(fromName, toName, recordIdsToRename);
        this._indexByDictionary.delete(fromName);
        this._indexByDictionary.delete(toName);
        this._invalidatePersistentLookupState(fromName);
        this._invalidatePersistentLookupState(toName);
        this._indexDirty = false;
        for (const plan of renamePlans) {
            this._shardStateByFileName.delete(plan.state.fileName);
            this._activeAppendShardStateByKey.delete(plan.state.logicalKey);
            const nextState = this._createShardState(
                plan.nextFileName,
                plan.nextFileHandle,
                plan.fileSize,
                plan.shardInfo.contentDictName,
                plan.shardInfo.segmentIndex,
                this._getShardFileName(toName, plan.shardInfo.contentDictName),
            );
            this._shardStateByFileName.set(plan.nextFileName, nextState);
            this._setActiveAppendShardState(nextState);
        }
        this._setDictionaryHealth(fromName, 'available');
        this._setDictionaryHealth(toName, 'available');

        return renamedCount;
    }

    /**
     * @param {(dictionaryName: string) => boolean} predicate
     * @returns {Promise<string[]>}
     */
    async cleanupShardFilesByDictionaryPredicate(predicate) {
        return await this._runExclusiveStorageMutation(
            async () => await this._cleanupShardFilesByDictionaryPredicate(predicate),
        );
    }

    /**
     * @param {(dictionaryName: string) => boolean} predicate
     * @returns {Promise<string[]>}
     */
    async _cleanupShardFilesByDictionaryPredicate(predicate) {
        if (this._recordsDirectoryHandle === null) {
            return [];
        }
        this._allShardContentsLoaded = false;
        const removedFileNames = [];
        /** @type {Set<string>} */
        const removedDictionaryNames = new Set();
        const shardFiles = await this._listShardStorageFiles();
        for (const {descriptorFileName: fileName, hasDescriptor} of shardFiles) {
            const dictionaryName = this._decodeDictionaryNameFromShardFileName(fileName);
            if (dictionaryName === null || !predicate(dictionaryName)) {
                continue;
            }
            const state = this._shardStateByFileName.get(fileName);
            if (typeof state !== 'undefined') {
                await this._flushPendingWritesForShard(state);
                await this._closeShardWritable(state);
            }
            if (hasDescriptor) {
                await this._removeStorageFileOrTruncate(fileName, true);
            }
            if (typeof state !== 'undefined') {
                this._shardStateByFileName.delete(fileName);
                this._activeAppendShardStateByKey.delete(state.logicalKey);
            }
            await this._removeStorageFileOrTruncate(`${fileName}${LOOKUP_INDEX_FILE_SUFFIX}`, true);
            removedDictionaryNames.add(dictionaryName);
            removedFileNames.push(fileName);
        }
        if (removedDictionaryNames.size > 0) {
            const recordIdsToDelete = [];
            let requiresFullRecordScan = false;
            for (const dictionaryName of removedDictionaryNames) {
                const ids = this._getLiveRecordIdsForDictionary(dictionaryName);
                if (typeof ids === 'undefined') {
                    requiresFullRecordScan = true;
                    break;
                }
                for (const id of ids) {
                    recordIdsToDelete.push(id);
                }
            }
            if (requiresFullRecordScan) {
                recordIdsToDelete.length = 0;
                for (const id of this._recordsById.keys()) {
                    const record = this._recordsById.get(id);
                    if (typeof record !== 'undefined' && removedDictionaryNames.has(record.dictionary)) {
                        recordIdsToDelete.push(id);
                    }
                }
            }
            for (const id of recordIdsToDelete) {
                this._deleteRecord(id);
            }
            for (const dictionaryName of removedDictionaryNames) {
                this._loadedDictionaryNames.delete(dictionaryName);
                this._recordIdsByDictionary.delete(dictionaryName);
                this._recordIdStaleDictionaryNames.delete(dictionaryName);
                this._invalidatePersistentLookupState(dictionaryName);
                this._setDictionaryHealth(dictionaryName, 'available');
            }
            this._indexByDictionary.clear();
            this._indexDirty = false;
        }
        return removedFileNames;
    }

    /**
     * @param {Iterable<number>} ids
     * @returns {Map<number, TermRecord>}
     */
    getByIds(ids) {
        /** @type {Map<number, TermRecord>} */
        const result = new Map();
        for (const id of ids) {
            const record = this._recordsById.get(id);
            if (typeof record !== 'undefined') {
                // ID-only consumers (including glossary search) have not run an
                // expression-index lookup that would decode these lazy bytes.
                this._ensureDecodedRecordStrings(record);
                result.set(id, record);
            }
        }
        return result;
    }

    /**
     * @param {File} file
     * @param {number} start
     * @param {number} end
     * @returns {Promise<Uint8Array>}
     */
    async _readFileRange(file, start, end) {
        if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || end < start || end > file.size) {
            throw new RangeError(`Invalid term-record file range: ${start}..${end} of ${file.size}`);
        }
        const slice = /** @type {unknown} */ (Reflect.get(file, 'slice'));
        if (typeof slice === 'function') {
            const blob = /** @type {Blob} */ (/** @type {(start: number, end: number) => Blob} */ (slice).call(file, start, end));
            return new Uint8Array(await blob.arrayBuffer());
        }
        const content = new Uint8Array(await file.arrayBuffer());
        return content.slice(start, end);
    }

    /**
     * @param {number} id
     * @returns {PersistentRecordChunk|null}
     */
    _findPersistentRecordChunk(id) {
        for (const chunks of this._persistentRecordChunksByDictionary.values()) {
            let low = 0;
            let high = chunks.length - 1;
            while (low <= high) {
                const middle = (low + high) >>> 1;
                const chunk = chunks[middle];
                if (id < chunk.firstId) {
                    high = middle - 1;
                } else if (id >= (chunk.firstId + chunk.count)) {
                    low = middle + 1;
                } else {
                    return chunk;
                }
            }
        }
        return null;
    }

    /**
     * @param {Iterable<number>} ids
     * @returns {Promise<Map<number, TermRecord>>}
     */
    async getByIdsAsync(ids) {
        const idList = [...new Set(ids)];
        const result = this.getByIds(idList);
        /** @type {Map<ReturnType<TermRecordOpfsStore['_findPersistentRecordChunk']>, number[]>} */
        const idsByChunk = new Map();
        for (const id of idList) {
            if (result.has(id)) { continue; }
            const chunk = this._findPersistentRecordChunk(id);
            if (chunk === null) { continue; }
            const chunkIds = idsByChunk.get(chunk);
            if (typeof chunkIds === 'undefined') {
                idsByChunk.set(chunk, [id]);
            } else {
                chunkIds.push(id);
            }
        }
        const chunkEntries = [...idsByChunk];
        for (const [chunk, chunkIds] of chunkEntries) {
            if (chunk === null) { continue; }
            if (
                this.getDictionaryHealth(chunk.dictionaryName).status === 'reimportRequired' ||
                !(this._persistentRecordChunksByDictionary.get(chunk.dictionaryName) ?? []).includes(chunk)
            ) { continue; }
            const compactFields = chunk.compactRecordFields;
            const fieldsView = compactFields === null ?
                new DataView(
                    chunk.recordFields.buffer,
                    chunk.recordFields.byteOffset,
                    chunk.recordFields.byteLength,
                ) :
                null;
            for (const id of chunkIds) {
                const ordinal = id - chunk.firstId;
                const fieldsOffset = ordinal * (
                    chunk.recordFieldsFormat === LOOKUP_INDEX_RECORD_FIELDS_FORMAT_FLOAT64_SCORE ?
                        FLOAT64_SCORE_RECORD_FIELDS_BYTES :
                        LOOKUP_INDEX_RECORD_FIELDS_BYTES
                );
                const expressionBytes = getPersistedTermKeyBytes(chunk.lookupIndex, ordinal, 'expression');
                if (expressionBytes === null) { continue; }
                const readingBytes = getPersistedTermKeyBytes(chunk.lookupIndex, ordinal, 'reading');
                const contentOffsetDelta = compactFields === null ?
                    /** @type {DataView} */ (fieldsView).getUint32(fieldsOffset, true) :
                    compactFields.offsets[ordinal];
                const rawContentLength = compactFields === null ?
                    /** @type {DataView} */ (fieldsView).getUint32(fieldsOffset + 4, true) :
                    compactFields.lengths[ordinal];
                const entryContentOffset = contentOffsetDelta === U32_NULL ?
                    -1 :
                    chunk.contentOffsetBase + contentOffsetDelta;
                const expression = this._textDecoder.decode(expressionBytes);
                const record = {
                    id,
                    dictionary: chunk.dictionaryName,
                    expression,
                    reading: readingBytes === null ? expression : this._textDecoder.decode(readingBytes),
                    expressionReverse: null,
                    readingReverse: null,
                    entryContentOffset,
                    entryContentLength: rawContentLength === (compactFields === null ? U32_NULL : U16_NULL) ? -1 : rawContentLength,
                    entryContentDictName: chunk.contentDictName,
                    score: compactFields === null ?
                        (chunk.recordFieldsFormat === LOOKUP_INDEX_RECORD_FIELDS_FORMAT_FLOAT64_SCORE ?
                            /** @type {DataView} */ (fieldsView).getFloat64(fieldsOffset + 8, true) :
                            /** @type {DataView} */ (fieldsView).getInt32(fieldsOffset + 8, true)) :
                        compactFields.scores[compactFields.scoreKeys[ordinal]],
                    sequence: getPersistedTermSequence(chunk.lookupIndex, ordinal),
                };
                this._storeRecord(record);
                result.set(id, record);
            }
        }
        return result;
    }

    /**
     * @returns {number[]}
     */
    getAllIds() {
        return [...this._recordsById.keys()].sort((a, b) => a - b);
    }

    /**
     * Keep import batches bounded: authoritative records and lookup keys are
     * already encoded into OPFS by the append owner. Retaining each record here
     * pins parser buffers and millions of row objects until publication.
     * Non-import appends and in-memory test stores retain their existing cache.
     * @param {TermRecord} record
     */
    _cacheAppendedRecord(record) {
        if (this._importSessionActive && this._recordsDirectoryHandle !== null) {
            this._reloadFromShardsAfterImport = true;
            this._loadedDictionaryNames.delete(record.dictionary);
            this._allShardContentsLoaded = false;
            return;
        }
        this._storeRecord(record);
        this._loadedDictionaryNames.add(record.dictionary);
    }

    /**
     * @param {TermRecord} record
     * @returns {boolean} Whether the record must be added to its dictionary indexes.
     */
    _storeRecord(record) {
        const existing = this._recordsById.get(record.id);
        this._recordsById.set(record.id, record);
        if (typeof existing !== 'undefined') {
            if (existing.dictionary !== record.dictionary) {
                this._markRecordIdsStale(existing.dictionary);
                this._markRecordIdsStale(record.dictionary);
                let ids = this._recordIdsByDictionary.get(record.dictionary);
                if (typeof ids === 'undefined') {
                    ids = [];
                    this._recordIdsByDictionary.set(record.dictionary, ids);
                }
                ids.push(record.id);
                return true;
            }
            return false;
        }
        this._getOrCreateRecordIdsForDictionary(record.dictionary).push(record.id);
        return true;
    }

    /**
     * @param {string} dictionaryName
     * @returns {number[]}
     */
    _getOrCreateRecordIdsForDictionary(dictionaryName) {
        let ids = this._recordIdsByDictionary.get(dictionaryName);
        if (typeof ids === 'undefined') {
            ids = [];
            this._recordIdsByDictionary.set(dictionaryName, ids);
        }
        return ids;
    }

    /**
     * @param {string} dictionaryName
     * @returns {{expression: Map<string, number[]>, reading: Map<string, number[]>, expressionReverse: Map<string, number[]>, readingReverse: Map<string, number[]>, sequence: Map<number, number[]>}}
     */
    _getOrCreateDictionaryIndex(dictionaryName) {
        let index = this._indexByDictionary.get(dictionaryName);
        if (typeof index === 'undefined') {
            index = {
                expression: new Map(),
                reading: new Map(),
                expressionReverse: new Map(),
                readingReverse: new Map(),
                sequence: new Map(),
            };
            this._indexByDictionary.set(dictionaryName, index);
        }
        return index;
    }

    /**
     * @param {string} dictionaryName
     * @returns {number[]|undefined}
     */
    _getLiveRecordIdsForDictionary(dictionaryName) {
        const ids = this._recordIdsByDictionary.get(dictionaryName);
        if (typeof ids === 'undefined') {
            return void 0;
        }
        if (!this._recordIdStaleDictionaryNames.has(dictionaryName)) {
            return ids;
        }
        /** @type {Set<number>} */
        const seenIds = new Set();
        /** @type {number[]} */
        const compactedIds = [];
        const records = this._recordsById.getRawRecords();
        for (const id of ids) {
            if (seenIds.has(id)) { continue; }
            seenIds.add(id);
            const record = records[id];
            if (typeof record !== 'undefined' && record.dictionary === dictionaryName) {
                compactedIds.push(id);
            }
        }
        this._recordIdsByDictionary.set(dictionaryName, compactedIds);
        this._recordIdStaleDictionaryNames.delete(dictionaryName);
        return compactedIds;
    }

    /**
     * @param {number} id
     * @returns {boolean}
     */
    _deleteRecord(id) {
        const existing = this._recordsById.get(id);
        const deleted = this._recordsById.delete(id);
        if (deleted && typeof existing !== 'undefined') {
            this._markRecordIdsStale(existing.dictionary);
        }
        return deleted;
    }

    /**
     * @param {string} dictionaryName
     * @returns {void}
     */
    _markRecordIdsStale(dictionaryName) {
        if (dictionaryName.length > 0) {
            this._recordIdStaleDictionaryNames.add(dictionaryName);
        }
    }

    /**
     * @param {string} fromName
     * @param {string} toName
     * @param {number[]} renamedIds
     * @returns {void}
     */
    _renameRecordIdIndex(fromName, toName, renamedIds) {
        const existingFromIds = this._recordIdsByDictionary.get(fromName);
        if (typeof existingFromIds !== 'undefined') {
            this._recordIdsByDictionary.delete(fromName);
        }
        this._markRecordIdsStale(fromName);
        this._markRecordIdsStale(toName);
        let toIds = this._recordIdsByDictionary.get(toName);
        if (typeof toIds === 'undefined') {
            toIds = [];
            this._recordIdsByDictionary.set(toName, toIds);
        }
        for (const id of renamedIds) {
            toIds.push(id);
        }
    }

    /**
     * @param {number} count Number of IDs required by the pending append.
     * @returns {Promise<void>}
     * @throws {Error} If existing record IDs cannot be established from every authoritative container.
     * @throws {RangeError} If the pending append cannot fit in the persisted uint32 ID space.
     */
    async _ensureNextIdReadyForAppend(count) {
        if (!Number.isSafeInteger(count) || count <= 0) {
            throw new RangeError('Invalid term-record ID reservation count');
        }
        if (this._nextIdMayNeedShardScan && this._recordsDirectoryHandle !== null) {
            let maxId = this._nextId - 1;
            for (const state of this._shardStateByFileName.values()) {
                const indexFileName = `${state.fileName}${LOOKUP_INDEX_FILE_SUFFIX}`;
                let fileHandle;
                try {
                    fileHandle = await this._recordsDirectoryHandle.getFileHandle(indexFileName, {create: false});
                } catch (error) {
                    // An empty descriptor left by cleanup has no IDs to reserve.
                    // Any other unreadable/missing container leaves the maximum unknown.
                    if (state.fileLength === 0 && isStorageEntryNotFoundError(error)) {
                        continue;
                    }
                    throw new Error(`Cannot reserve term-record IDs: cannot open ${indexFileName}`, {cause: error});
                }
                const file = await fileHandle.getFile();
                if (file.size === 0 && state.fileLength === 0) { continue; }
                const descriptorFile = await state.fileHandle.getFile();
                if (
                    descriptorFile.size !== state.fileLength ||
                    descriptorFile.size < BINARY_HEADER_PREFIX_BYTES
                ) {
                    throw new Error(`Cannot reserve term-record IDs: invalid descriptor ${state.fileName}`);
                }
                const descriptorHeader = await this._readFileRange(
                    descriptorFile,
                    0,
                    BINARY_HEADER_PREFIX_BYTES,
                );
                if (
                    this._textDecoder.decode(descriptorHeader.subarray(0, BINARY_MAGIC_BYTES)) !==
                    BINARY_MAGIC_TEXT
                ) {
                    throw new Error(`Cannot reserve term-record IDs: invalid descriptor ${state.fileName}`);
                }
                const descriptorGenerationId = descriptorHeader.subarray(
                    BINARY_MAGIC_BYTES,
                    BINARY_HEADER_PREFIX_BYTES,
                );
                const shardMaxId = await this._scanPersistentIndexMaxRecordIdFile(
                    file,
                    state.fileLength,
                    descriptorGenerationId,
                );
                if (shardMaxId === null) {
                    throw new Error(`Cannot reserve term-record IDs: invalid container ${indexFileName}`);
                }
                maxId = Math.max(maxId, shardMaxId);
            }
            // Publish only after every authoritative shard has been inspected.
            // A failed scan remains retryable and must not consume an ID.
            this._nextId = Math.max(this._nextId, maxId + 1);
            this._nextIdMayNeedShardScan = false;
        }
        if (
            !Number.isSafeInteger(this._nextId) ||
            this._nextId <= 0 ||
            this._nextId > MAX_TERM_RECORD_ID ||
            count > (MAX_TERM_RECORD_ID - this._nextId + 1)
        ) {
            throw new RangeError('Term-record ID space is exhausted');
        }
    }

    /**
     * Scans only persisted index framing needed to establish the maximum ID.
     * Browser File objects support ranged reads, so payload/index bodies never
     * need to be materialized merely to reserve the next append ID.
     * @param {File} file
     * @param {number} expectedDescriptorFileLength
     * @param {Uint8Array} expectedGenerationId
     * @returns {Promise<number|null>}
     */
    async _scanPersistentIndexMaxRecordIdFile(file, expectedDescriptorFileLength, expectedGenerationId) {
        if (
            !Number.isSafeInteger(file.size) ||
            file.size < LOOKUP_INDEX_FILE_HEADER_BYTES ||
            !Number.isSafeInteger(expectedDescriptorFileLength) ||
            expectedDescriptorFileLength < 0 ||
            !(expectedGenerationId instanceof Uint8Array) ||
            expectedGenerationId.byteLength !== SHARD_GENERATION_BYTES
        ) {
            return null;
        }
        const slice = /** @type {unknown} */ (Reflect.get(file, 'slice'));
        if (typeof slice !== 'function') {
            const content = new Uint8Array(await file.arrayBuffer());
            if (content.byteLength < LOOKUP_INDEX_FILE_HEADER_BYTES) { return null; }
            const header = content.subarray(0, LOOKUP_INDEX_FILE_HEADER_BYTES);
            const headerView = new DataView(header.buffer, header.byteOffset, header.byteLength);
            let descriptorFileLength;
            try {
                descriptorFileLength = readSafeU64Le(headerView, 8);
            } catch (_) {
                return null;
            }
            if (
                this._textDecoder.decode(header.subarray(0, LOOKUP_INDEX_MAGIC_BYTES)) !== LOOKUP_INDEX_MAGIC_TEXT ||
                descriptorFileLength !== expectedDescriptorFileLength ||
                !bytesEqual(
                    header.subarray(24, LOOKUP_INDEX_FILE_HEADER_BYTES),
                    expectedGenerationId,
                )
            ) {
                return null;
            }
            return this._scanPersistentIndexMaxRecordId(content);
        }
        const header = await this._readFileRange(file, 0, LOOKUP_INDEX_FILE_HEADER_BYTES);
        if (this._textDecoder.decode(header.subarray(0, LOOKUP_INDEX_MAGIC_BYTES)) !== LOOKUP_INDEX_MAGIC_TEXT) {
            return null;
        }
        const headerView = new DataView(header.buffer, header.byteOffset, header.byteLength);
        let descriptorFileLength;
        try {
            descriptorFileLength = readSafeU64Le(headerView, 8);
        } catch (_) {
            return null;
        }
        const chunkCount = headerView.getUint32(16, true);
        const expectedRecordCount = headerView.getUint32(20, true);
        if (
            descriptorFileLength !== expectedDescriptorFileLength ||
            !bytesEqual(
                header.subarray(24, LOOKUP_INDEX_FILE_HEADER_BYTES),
                expectedGenerationId,
            ) ||
            chunkCount === 0 ||
            expectedRecordCount === 0 ||
            chunkCount > expectedRecordCount
        ) {
            return null;
        }
        const minimumIndexBytes = LOOKUP_INDEX_FILE_HEADER_BYTES +
        (chunkCount * LOOKUP_INDEX_CHUNK_HEADER_BYTES) +
        (expectedRecordCount * COMPACT_RECORD_FIELDS_BYTES_PER_ROW);
        const maximumIndexBytes = Math.max(
            MAX_LOOKUP_INDEX_OVERHEAD_BYTES,
            Math.min(
                Number.MAX_SAFE_INTEGER,
                (expectedRecordCount * MAX_LOOKUP_INDEX_BYTES_PER_RECORD) + MAX_LOOKUP_INDEX_OVERHEAD_BYTES,
            ),
        );
        if (
            !Number.isSafeInteger(minimumIndexBytes) ||
            minimumIndexBytes > file.size ||
            file.size > maximumIndexBytes
        ) {
            return null;
        }

        let cursor = LOOKUP_INDEX_FILE_HEADER_BYTES;
        let maxId = 0;
        let recordCount = 0;
        for (let chunk = 0; chunk < chunkCount; ++chunk) {
            const chunkHeaderEnd = cursor + LOOKUP_INDEX_CHUNK_HEADER_BYTES;
            if (!Number.isSafeInteger(chunkHeaderEnd) || chunkHeaderEnd > file.size) { return null; }
            const chunkHeader = await this._readFileRange(file, cursor, chunkHeaderEnd);
            const view = new DataView(chunkHeader.buffer, chunkHeader.byteOffset, chunkHeader.byteLength);
            const firstId = view.getUint32(0, true);
            const count = view.getUint32(4, true);
            const payloadLength = view.getUint32(16, true);
            const recordFieldsFormat = view.getUint32(36, true);
            if (
                firstId <= 0 ||
                count === 0 ||
                (firstId + count - 1) > MAX_TERM_RECORD_ID ||
                recordCount > expectedRecordCount - count
            ) {
                return null;
            }
            maxId = Math.max(maxId, firstId + count - 1);
            recordCount += count;
            const recordFieldsOffset = chunkHeaderEnd + payloadLength;
            if (!Number.isSafeInteger(recordFieldsOffset) || recordFieldsOffset > file.size) { return null; }

            let recordFieldsLength;
            try {
                if (recordFieldsFormat === LOOKUP_INDEX_RECORD_FIELDS_FORMAT_COMPACT) {
                    const compactHeaderEnd = recordFieldsOffset + COMPACT_RECORD_FIELDS_HEADER_BYTES;
                    if (!Number.isSafeInteger(compactHeaderEnd) || compactHeaderEnd > file.size) { return null; }
                    const compactHeader = await this._readFileRange(file, recordFieldsOffset, compactHeaderEnd);
                    recordFieldsLength = getRecordFieldsByteLength(compactHeader, 0, count, recordFieldsFormat);
                } else {
                    recordFieldsLength = getRecordFieldsByteLength(EMPTY_BYTES, 0, count, recordFieldsFormat);
                }
            } catch (_) {
                return null;
            }
            cursor = recordFieldsOffset + recordFieldsLength;
            if (!Number.isSafeInteger(cursor) || cursor > file.size) { return null; }
        }
        return cursor === file.size && maxId > 0 && recordCount === expectedRecordCount ? maxId : null;
    }

    /**
     * @param {Uint8Array} content
     * @returns {number|null}
     */
    _scanPersistentIndexMaxRecordId(content) {
        if (content.byteLength < LOOKUP_INDEX_FILE_HEADER_BYTES) { return null; }
        if (this._textDecoder.decode(content.subarray(0, LOOKUP_INDEX_MAGIC_BYTES)) !== LOOKUP_INDEX_MAGIC_TEXT) {
            return null;
        }
        const view = new DataView(content.buffer, content.byteOffset, content.byteLength);
        const chunkCount = view.getUint32(16, true);
        let cursor = LOOKUP_INDEX_FILE_HEADER_BYTES;
        let maxId = 0;
        let recordCount = 0;
        for (let chunk = 0; chunk < chunkCount; ++chunk) {
            if ((cursor + LOOKUP_INDEX_CHUNK_HEADER_BYTES) > content.byteLength) { return null; }
            const firstId = view.getUint32(cursor, true);
            const count = view.getUint32(cursor + 4, true);
            const payloadLength = view.getUint32(cursor + 16, true);
            const recordFieldsFormat = view.getUint32(cursor + 36, true);
            if (firstId <= 0 || count === 0 || (firstId + count - 1) > 0xffffffff) { return null; }
            maxId = Math.max(maxId, firstId + count - 1);
            recordCount += count;
            const recordFieldsOffset = cursor + LOOKUP_INDEX_CHUNK_HEADER_BYTES + payloadLength;
            let recordFieldsLength;
            try {
                recordFieldsLength = getRecordFieldsByteLength(content, recordFieldsOffset, count, recordFieldsFormat);
            } catch (_) {
                return null;
            }
            cursor = recordFieldsOffset + recordFieldsLength;
            if (cursor > content.byteLength) { return null; }
        }
        return cursor === content.byteLength && maxId > 0 && recordCount === view.getUint32(20, true) ? maxId : null;
    }

    /**
     * @param {string} dictionaryName
     * @returns {Generator<TermRecord, void, void>}
     * @yields {TermRecord}
     */
    *_iterateRecordsForDictionary(dictionaryName) {
        const ids = this._getLiveRecordIdsForDictionary(dictionaryName);
        if (typeof ids !== 'undefined') {
            const records = this._recordsById.getRawRecords();
            for (const id of ids) {
                const record = records[id];
                if (typeof record !== 'undefined') {
                    yield record;
                }
            }
            return;
        }
        for (const record of this._recordsById.values()) {
            if (record.dictionary === dictionaryName) {
                yield record;
            }
        }
    }

    /**
     * @param {string} dictionaryName
     * @returns {{expression: Map<string, number[]>, reading: Map<string, number[]>, expressionReverse: Map<string, number[]>, readingReverse: Map<string, number[]>, sequence: Map<number, number[]>}}
     */
    getDictionaryIndex(dictionaryName) {
        this._ensureIndexesReady();
        const existing = this._indexByDictionary.get(dictionaryName);
        if (typeof existing !== 'undefined') {
            if (
                existing.expression.size === 0 &&
                existing.reading.size === 0 &&
                this._hasRecordsForDictionary(dictionaryName)
            ) {
                this._indexByDictionary.delete(dictionaryName);
            } else {
                return existing;
            }
        }
        const created = {
            expression: new Map(),
            reading: new Map(),
            expressionReverse: new Map(),
            readingReverse: new Map(),
            sequence: new Map(),
        };
        this._addDictionaryRecordsToIndex(dictionaryName, created);
        if (
            created.expression.size === 0 &&
            created.reading.size === 0 &&
            this._hasRecordsForDictionary(dictionaryName)
        ) {
            this._rebuildIndexesFromRecords();
            const rebuilt = this._indexByDictionary.get(dictionaryName);
            if (typeof rebuilt !== 'undefined') {
                return rebuilt;
            }
        }
        this._indexByDictionary.set(dictionaryName, created);
        return created;
    }

    /**
     * @param {Iterable<string>} dictionaryNames
     * @returns {void}
     */
    ensureDictionaryIndexes(dictionaryNames) {
        this._ensureIndexesReady();
        /** @type {Set<string>} */
        const pending = new Set();
        for (const dictionaryName of dictionaryNames) {
            const name = `${dictionaryName}`;
            if (name.length === 0) { continue; }
            const existing = this._indexByDictionary.get(name);
            if (typeof existing === 'undefined') {
                pending.add(name);
            } else if (
                existing.expression.size === 0 &&
                existing.reading.size === 0 &&
                this._hasRecordsForDictionary(name)
            ) {
                this._indexByDictionary.delete(name);
                pending.add(name);
            }
        }
        if (pending.size === 0) { return; }
        if (pending.size === 1) {
            this.getDictionaryIndex(/** @type {string} */ ([...pending][0]));
            return;
        }

        /** @type {Map<string, {expression: Map<string, number[]>, reading: Map<string, number[]>, expressionReverse: Map<string, number[]>, readingReverse: Map<string, number[]>, sequence: Map<number, number[]>}>} */
        const createdIndexes = new Map();
        for (const name of pending) {
            const index = {
                expression: new Map(),
                reading: new Map(),
                expressionReverse: new Map(),
                readingReverse: new Map(),
                sequence: new Map(),
            };
            createdIndexes.set(name, index);
            this._indexByDictionary.set(name, index);
        }
        for (const [name, index] of createdIndexes) {
            this._addDictionaryRecordsToIndex(name, index);
        }
        for (const [name, index] of createdIndexes) {
            if (
                index.expression.size === 0 &&
                index.reading.size === 0 &&
                this._hasRecordsForDictionary(name)
            ) {
                this._indexByDictionary.delete(name);
            }
        }
    }

    /**
     * @param {string} dictionaryName
     * @param {{expression: Map<string, number[]>, reading: Map<string, number[]>, expressionReverse: Map<string, number[]>, readingReverse: Map<string, number[]>, sequence: Map<number, number[]>}} [index]
     * @returns {{expression: Map<string, number[]>, reading: Map<string, number[]>, expressionReverse: Map<string, number[]>, readingReverse: Map<string, number[]>, sequence: Map<number, number[]>}}
     */
    ensureDictionaryReverseIndex(dictionaryName, index = this.getDictionaryIndex(dictionaryName)) {
        if (this._reverseIndexReady.has(index)) {
            return index;
        }
        index.expressionReverse.clear();
        index.readingReverse.clear();
        if (this._persistentIndexLoadedDictionaryNames.has(dictionaryName)) {
            for (const [expression, ids] of index.expression) {
                index.expressionReverse.set(this._reverseString(expression), ids);
            }
            for (const [reading, ids] of index.reading) {
                index.readingReverse.set(this._reverseString(reading), ids);
            }
        } else {
            this._addDictionaryRecordsToReverseIndex(dictionaryName, index);
        }
        this._reverseIndexReady.add(index);
        return index;
    }

    /**
     * @returns {string[]}
     */
    getShardFileNames() {
        return [...this._shardStateByFileName.keys()].sort((a, b) => a.localeCompare(b));
    }

    /**
     * @param {string} dictionaryName
     * @returns {boolean}
     */
    _hasRecordsForDictionary(dictionaryName) {
        if ((this._persistentRecordChunksByDictionary.get(dictionaryName)?.length ?? 0) > 0) {
            return true;
        }
        const ids = this._recordIdsByDictionary.get(dictionaryName);
        if (typeof ids !== 'undefined') {
            for (const id of ids) {
                const record = this._recordsById.get(id);
                if (typeof record !== 'undefined' && record.dictionary === dictionaryName) {
                    return true;
                }
            }
            return false;
        }
        for (const record of this._recordsById.values()) {
            if (record.dictionary === dictionaryName) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param {number} id
     * @returns {TermRecord|undefined}
     */
    getById(id) {
        const record = this._recordsById.get(id);
        if (typeof record !== 'undefined') { this._ensureDecodedRecordStrings(record); }
        return record;
    }

    /**
     * @param {string} dictionaryName
     * @returns {Promise<boolean>}
     */
    async _tryLoadPersistentDictionaryIndex(dictionaryName) {
        const globalGeneration = this._persistentLookupGeneration;
        const dictionaryGeneration = this._getPersistentLookupGeneration(dictionaryName);
        const isCurrent = () => this._isPersistentLookupGenerationCurrent(
            dictionaryName,
            globalGeneration,
            dictionaryGeneration,
        );
        if (!isCurrent()) { return false; }
        if (this._persistentIndexLoadedDictionaryNames.has(dictionaryName)) {
            this._setDictionaryHealth(dictionaryName, 'available');
            return isCurrent();
        }
        const existing = this._persistentIndexLoadPromiseByDictionary.get(dictionaryName);
        if (typeof existing !== 'undefined') {
            const loaded = await existing;
            return isCurrent() && loaded;
        }
        const load = (async () => {
            for (let attempt = 0; attempt < STORAGE_READ_RETRY_COUNT; ++attempt) {
                if (!isCurrent()) { return false; }
                const loaded = await this._loadPersistentDictionaryIndex(
                    dictionaryName,
                    globalGeneration,
                    dictionaryGeneration,
                );
                if (!isCurrent()) { return false; }
                if (loaded) { return true; }
                if (this._persistentIndexFailureByDictionary.get(dictionaryName)?.kind !== 'transient') {
                    break;
                }
                await new Promise((resolve) => { setTimeout(resolve, 0); });
            }
            return false;
        })();
        this._persistentIndexLoadPromiseByDictionary.set(dictionaryName, load);
        try {
            const loaded = await load;
            return isCurrent() && loaded;
        } finally {
            if (this._persistentIndexLoadPromiseByDictionary.get(dictionaryName) === load) {
                this._persistentIndexLoadPromiseByDictionary.delete(dictionaryName);
            }
        }
    }

    /**
     * @param {string} dictionaryName
     * @param {number} globalGeneration
     * @param {number} [dictionaryGeneration]
     * @returns {Promise<boolean>}
     */
    async _loadPersistentDictionaryIndex(
        dictionaryName,
        globalGeneration,
        dictionaryGeneration = this._getPersistentLookupGeneration(dictionaryName),
    ) {
        if (!this._isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, dictionaryGeneration)) { return false; }
        if (this._persistentIndexLoadedDictionaryNames.has(dictionaryName)) {
            this._setDictionaryHealth(dictionaryName, 'available');
            return true;
        }
        if (this._recordsDirectoryHandle === null) {
            this._recordPersistentIndexFailure(dictionaryName, 'transient', 'Term-record directory is unavailable');
            return false;
        }
        const states = [...this._shardStateByFileName.values()]
            .filter((state) => this._decodeDictionaryNameFromShardFileName(state.fileName) === dictionaryName)
            .sort((a, b) => a.fileName.localeCompare(b.fileName));
        if (states.length === 0) {
            this._recordPersistentIndexFailure(dictionaryName, 'missing', 'No term-record shards exist');
            return false;
        }
        /** @type {PersistentRecordChunk[]} */
        const recordChunks = [];
        try {
            for (const state of states) {
                let indexFileHandle;
                try {
                    indexFileHandle = await this._recordsDirectoryHandle.getFileHandle(
                        `${state.fileName}${LOOKUP_INDEX_FILE_SUFFIX}`,
                        {create: false},
                    );
                } catch (error) {
                    if (isStorageEntryNotFoundError(error)) {
                        throw new PersistentLookupIndexError('missing', `Lookup index is missing for ${state.fileName}`, error);
                    }
                    throw error;
                }
                let recordFile;
                let indexFile;
                try {
                    [recordFile, indexFile] = await Promise.all([
                        state.fileHandle.getFile(),
                        indexFileHandle.getFile(),
                    ]);
                } catch (error) {
                    if (isStorageEntryNotFoundError(error)) {
                        throw new PersistentLookupIndexError(
                            'invalid',
                            `Term-record shard or lookup index disappeared for ${state.fileName}`,
                            error,
                        );
                    }
                    throw error;
                }
                if (recordFile.size < (BINARY_HEADER_PREFIX_BYTES + 2) || indexFile.size < LOOKUP_INDEX_FILE_HEADER_BYTES) {
                    throw new PersistentLookupIndexError('invalid', `Lookup index is truncated for ${state.fileName}`);
                }
                const [indexHeader, recordHeader] = await Promise.all([
                    this._readFileRange(indexFile, 0, LOOKUP_INDEX_FILE_HEADER_BYTES),
                    this._readFileRange(recordFile, 0, BINARY_HEADER_PREFIX_BYTES),
                ]);
                if (!this._isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, dictionaryGeneration)) { return false; }
                const headerView = new DataView(indexHeader.buffer, indexHeader.byteOffset, indexHeader.byteLength);
                if (this._textDecoder.decode(indexHeader.subarray(0, LOOKUP_INDEX_MAGIC_BYTES)) !== LOOKUP_INDEX_MAGIC_TEXT) {
                    throw new PersistentLookupIndexError('invalid', `Lookup index header is invalid for ${state.fileName}`);
                }
                if (this._textDecoder.decode(recordHeader.subarray(0, BINARY_MAGIC_BYTES)) !== BINARY_MAGIC_TEXT) {
                    throw new PersistentLookupIndexError('invalid', `Term-record shard header is invalid for ${state.fileName}`);
                }
                const recordGenerationId = recordHeader.subarray(BINARY_MAGIC_BYTES, BINARY_HEADER_PREFIX_BYTES);
                const indexGenerationId = indexHeader.subarray(24, LOOKUP_INDEX_FILE_HEADER_BYTES);
                if (!bytesEqual(recordGenerationId, indexGenerationId)) {
                    throw new PersistentLookupIndexError('invalid', `Lookup index generation does not match ${state.fileName}`);
                }
                state.generationId = new Uint8Array(recordGenerationId);
                let expectedDescriptorFileLength;
                try {
                    expectedDescriptorFileLength = readSafeU64Le(headerView, 8);
                } catch (error) {
                    throw new PersistentLookupIndexError(
                        'invalid',
                        `Lookup index record length is invalid for ${state.fileName}`,
                        error,
                    );
                }
                const chunkCount = headerView.getUint32(16, true);
                const expectedRecordCount = headerView.getUint32(20, true);
                if (expectedDescriptorFileLength !== recordFile.size || chunkCount === 0 || expectedRecordCount === 0) {
                    throw new PersistentLookupIndexError('invalid', `Lookup index metadata does not match ${state.fileName}`);
                }
                const minimumIndexBytes = LOOKUP_INDEX_FILE_HEADER_BYTES +
                (chunkCount * LOOKUP_INDEX_CHUNK_HEADER_BYTES) +
                (expectedRecordCount * COMPACT_RECORD_FIELDS_BYTES_PER_ROW);
                const maximumIndexBytes = Math.max(
                    MAX_LOOKUP_INDEX_OVERHEAD_BYTES,
                    Math.min(
                        Number.MAX_SAFE_INTEGER,
                        (expectedRecordCount * MAX_LOOKUP_INDEX_BYTES_PER_RECORD) + MAX_LOOKUP_INDEX_OVERHEAD_BYTES,
                    ),
                );
                if (
                    !Number.isSafeInteger(minimumIndexBytes) ||
                    minimumIndexBytes > indexFile.size ||
                    indexFile.size > maximumIndexBytes
                ) {
                    throw new PersistentLookupIndexError('invalid', `Lookup index size is implausible for ${state.fileName}`);
                }
                let cursor = LOOKUP_INDEX_FILE_HEADER_BYTES;
                let actualRecordCount = 0;
                for (let chunkIndex = 0; chunkIndex < chunkCount; ++chunkIndex) {
                    const chunkHeaderStart = cursor;
                    const chunkHeaderEnd = chunkHeaderStart + LOOKUP_INDEX_CHUNK_HEADER_BYTES;
                    if (!Number.isSafeInteger(chunkHeaderEnd) || chunkHeaderEnd > indexFile.size) {
                        throw new PersistentLookupIndexError('invalid', `Lookup index chunk header is truncated for ${state.fileName}`);
                    }
                    const chunkHeader = await this._readFileRange(indexFile, chunkHeaderStart, chunkHeaderEnd);
                    if (!this._isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, dictionaryGeneration)) { return false; }
                    const chunkView = new DataView(chunkHeader.buffer, chunkHeader.byteOffset, chunkHeader.byteLength);
                    const firstId = chunkView.getUint32(0, true);
                    const count = chunkView.getUint32(4, true);
                    let contentOffsetBase;
                    try {
                        contentOffsetBase = readSafeU64Le(chunkView, 8);
                    } catch (error) {
                        throw new PersistentLookupIndexError(
                            'invalid',
                            `Lookup index content offset base is invalid for ${state.fileName}`,
                            error,
                        );
                    }
                    const payloadLength = chunkView.getUint32(16, true);
                    const baseLength = chunkView.getUint32(20, true);
                    const baseHash = chunkView.getUint32(24, true);
                    const derivedHash = chunkView.getUint32(28, true);
                    const recordFieldsHash = chunkView.getUint32(32, true);
                    const formatFlags = chunkView.getUint32(36, true);
                    const payloadStart = chunkHeaderEnd;
                    const recordFieldsStart = payloadStart + payloadLength;
                    if (
                        firstId <= 0 ||
                        count === 0 ||
                        (firstId + count - 1) > 0xffffffff ||
                        baseLength === 0 ||
                        baseLength >= payloadLength ||
                        (
                            formatFlags !== LOOKUP_INDEX_RECORD_FIELDS_FORMAT_LEGACY &&
                            formatFlags !== LOOKUP_INDEX_RECORD_FIELDS_FORMAT_COMPACT &&
                            formatFlags !== LOOKUP_INDEX_RECORD_FIELDS_FORMAT_FLOAT64_SCORE
                        ) ||
                        !Number.isSafeInteger(recordFieldsStart) ||
                        recordFieldsStart > indexFile.size
                    ) {
                        throw new PersistentLookupIndexError('invalid', `Lookup index chunk metadata is invalid for ${state.fileName}`);
                    }
                    let recordFieldsHeader = EMPTY_BYTES;
                    if (formatFlags === LOOKUP_INDEX_RECORD_FIELDS_FORMAT_COMPACT) {
                        const compactHeaderEnd = recordFieldsStart + COMPACT_RECORD_FIELDS_HEADER_BYTES;
                        if (!Number.isSafeInteger(compactHeaderEnd) || compactHeaderEnd > indexFile.size) {
                            throw new PersistentLookupIndexError('invalid', `Compact term-record fields header is truncated for ${state.fileName}`);
                        }
                        // Keep I/O outside the format-validation catch. A failed
                        // snapshot read is retryable, not evidence for repair.
                        recordFieldsHeader = await this._readFileRange(indexFile, recordFieldsStart, compactHeaderEnd);
                    }
                    let recordFieldsLength;
                    try {
                        recordFieldsLength = getRecordFieldsByteLength(recordFieldsHeader, 0, count, formatFlags);
                    } catch (error) {
                        throw new PersistentLookupIndexError('invalid', `Lookup index record fields are invalid for ${state.fileName}`, error);
                    }
                    const chunkBodyEnd = recordFieldsStart + recordFieldsLength;
                    if (!Number.isSafeInteger(chunkBodyEnd) || chunkBodyEnd > indexFile.size) {
                        throw new PersistentLookupIndexError('invalid', `Lookup index chunk metadata is invalid for ${state.fileName}`);
                    }
                    const chunkBody = await this._readFileRange(indexFile, payloadStart, chunkBodyEnd);
                    if (!this._isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, dictionaryGeneration)) { return false; }
                    const payload = chunkBody.subarray(0, payloadLength);
                    let sections;
                    try {
                        sections = splitPersistedTermLookupIndex(payload);
                    } catch (error) {
                        throw new PersistentLookupIndexError('invalid', `Lookup index framing is invalid for ${state.fileName}`, error);
                    }
                    if (
                        sections.base.byteLength !== baseLength ||
                        hashLookupIndexBytes(sections.base) !== baseHash
                    ) {
                        throw new PersistentLookupIndexError('invalid', `Lookup index authoritative base checksum failed for ${state.fileName}`);
                    }
                    if (hashLookupIndexBytes(sections.derived) !== derivedHash) {
                        throw new PersistentLookupIndexError('invalid', `Lookup index derived checksum failed for ${state.fileName}`);
                    }
                    const recordFields = chunkBody.subarray(payloadLength);
                    if (hashLookupIndexBytes(recordFields) !== recordFieldsHash) {
                        throw new PersistentLookupIndexError('invalid', `Lookup index record fields checksum failed for ${state.fileName}`);
                    }
                    let compactRecordFields;
                    try {
                        compactRecordFields = validateRecordFields(
                            recordFields,
                            count,
                            formatFlags,
                            contentOffsetBase,
                        );
                    } catch (error) {
                        throw new PersistentLookupIndexError('invalid', `Lookup index record fields are invalid for ${state.fileName}`, error);
                    }
                    let lookupIndex;
                    try {
                        lookupIndex = parseChecksummedPersistedTermLookupIndex(payload);
                    } catch (error) {
                        throw new PersistentLookupIndexError('invalid', `Lookup index payload is invalid for ${state.fileName}`, error);
                    }
                    if (
                        lookupIndex.expressionKeys.length !== count ||
                        lookupIndex.readingKeys.length !== count ||
                        lookupIndex.sequencePostingRows.length > count
                    ) {
                        throw new PersistentLookupIndexError('invalid', `Lookup index row counts are invalid for ${state.fileName}`);
                    }
                    recordChunks.push({
                        firstId,
                        count,
                        fileName: state.fileName,
                        dictionaryName,
                        contentDictName: state.sharedContentDictName ?? 'raw',
                        contentOffsetBase,
                        recordFields,
                        recordFieldsFormat: formatFlags,
                        compactRecordFields,
                        lookupIndex,
                    });
                    actualRecordCount += count;
                    cursor = chunkBodyEnd;
                }
                if (cursor !== indexFile.size || actualRecordCount !== expectedRecordCount) {
                    throw new PersistentLookupIndexError('invalid', `Lookup index file length is invalid for ${state.fileName}`);
                }
            }
        } catch (error) {
            if (!this._isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, dictionaryGeneration)) { return false; }
            if (error instanceof PersistentLookupIndexError) {
                this._recordPersistentIndexFailure(dictionaryName, error.kind, error.message);
            } else {
                this._recordPersistentIndexFailure(
                    dictionaryName,
                    'transient',
                    error instanceof Error ? error.message : String(error),
                );
            }
            return false;
        }
        if (!this._isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, dictionaryGeneration)) { return false; }
        recordChunks.sort((a, b) => a.firstId - b.firstId);
        for (let i = 1; i < recordChunks.length; ++i) {
            if (recordChunks[i].firstId <= (recordChunks[i - 1].firstId + recordChunks[i - 1].count - 1)) {
                this._recordPersistentIndexFailure(dictionaryName, 'invalid', 'Lookup index record ranges overlap');
                return false;
            }
        }
        if (
            this._importSessionActive ||
            states.some((state) => this._shardStateByFileName.get(state.fileName) !== state)
        ) {
            this._recordPersistentIndexFailure(dictionaryName, 'transient', 'Lookup index generation changed while loading');
            return false;
        }
        if (!this._validatePersistentRecordIdOwnership(dictionaryName, recordChunks)) { return false; }
        this._indexByDictionary.delete(dictionaryName);
        this._persistentRecordChunksByDictionary.set(dictionaryName, recordChunks);
        this._persistentIndexLoadedDictionaryNames.add(dictionaryName);
        this._persistentIndexFailureByDictionary.delete(dictionaryName);
        this._setDictionaryHealth(dictionaryName, 'available');
        return true;
    }

    /**
     * IDs are extension-wide identities used by record hydration and row caches.
     * Two independently valid containers cannot own the same ID. Neither owner
     * is authoritative enough to choose a winner, so quarantine both rather
     * than returning one dictionary's content for the other's lookup match.
     * @param {string} dictionaryName
     * @param {PersistentRecordChunk[]} recordChunks Sorted, nonoverlapping ranges.
     * @returns {boolean}
     */
    _validatePersistentRecordIdOwnership(dictionaryName, recordChunks) {
        /** @type {Set<string>} */
        const conflicts = new Set();
        for (const [otherName, otherChunks] of this._persistentRecordChunksByDictionary) {
            if (otherName === dictionaryName) { continue; }
            let left = 0;
            let right = 0;
            while (left < recordChunks.length && right < otherChunks.length) {
                const current = recordChunks[left];
                const other = otherChunks[right];
                if (current.firstId + current.count <= other.firstId) {
                    ++left;
                } else if (other.firstId + other.count <= current.firstId) {
                    ++right;
                } else {
                    conflicts.add(otherName);
                    break;
                }
            }
        }
        // Append/materialized paths can retain records after their persistent
        // lookup view is invalidated. Those IDs still own their cached rows.
        // Already-validated persistent owners are covered by the interval walk.
        for (const [otherName, ids] of this._recordIdsByDictionary) {
            if (otherName === dictionaryName || this._persistentRecordChunksByDictionary.has(otherName) || conflicts.has(otherName)) { continue; }
            for (const id of ids) {
                if (this._recordsById.get(id)?.dictionary !== otherName) { continue; }
                let low = 0;
                let high = recordChunks.length - 1;
                while (low <= high) {
                    const middle = (low + high) >>> 1;
                    const chunk = recordChunks[middle];
                    if (id < chunk.firstId) {
                        high = middle - 1;
                    } else if (id >= chunk.firstId + chunk.count) {
                        low = middle + 1;
                    } else {
                        conflicts.add(otherName);
                        break;
                    }
                }
                if (conflicts.has(otherName)) { break; }
            }
        }
        if (conflicts.size === 0) { return true; }
        conflicts.add(dictionaryName);
        for (const name of conflicts) {
            this.markDictionaryReimportRequired(name, 'Dictionary record IDs overlap another dictionary');
        }
        return false;
    }

    /**
     * @param {string} dictionaryName
     * @param {'missing'|'invalid'|'transient'} kind
     * @param {string} message
     */
    _recordPersistentIndexFailure(dictionaryName, kind, message) {
        this._persistentIndexFailureByDictionary.set(dictionaryName, {kind, message});
        reportDiagnostics('term-record-persistent-index-load-failed', {dictionaryName, kind, message});
    }

    /**
     * @param {string} dictionaryName
     * @param {boolean} [allowDuringStorageMutation=false]
     * @param {boolean} [loadAfterRepair=false]
     * @returns {Promise<boolean>}
     */
    _tryRepairPersistentDictionaryIndex(dictionaryName, allowDuringStorageMutation = false, loadAfterRepair = false) {
        if (this._pendingDictionaryDeletionNames.has(dictionaryName)) { return Promise.resolve(false); }
        if (this.getDictionaryHealth(dictionaryName).status === 'reimportRequired') { return Promise.resolve(false); }
        if (this._importSessionActive || (this._storageMutationActive && !allowDuringStorageMutation)) {
            return Promise.resolve(false);
        }
        const existing = this._persistentIndexRepairPromiseByDictionary.get(dictionaryName);
        if (typeof existing !== 'undefined') { return existing; }
        const retry = this._persistentIndexRepairRetryByDictionary.get(dictionaryName);
        if (typeof retry !== 'undefined' && Date.now() < retry.retryAt) { return Promise.resolve(false); }
        const globalGeneration = this._persistentLookupGeneration;
        const generation = this._getPersistentLookupGeneration(dictionaryName);
        const control = {cancelled: false};
        const isOwned = () => (
            !control.cancelled &&
            !this._importSessionActive &&
            !this._pendingDictionaryDeletionNames.has(dictionaryName) &&
            (!this._storageMutationActive || allowDuringStorageMutation)
        );
        const isCurrent = () => isOwned() && this._isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, generation);
        this._setDictionaryHealth(dictionaryName, 'repairPending', 'Dictionary lookup index needs repair');
        this._persistentIndexRepairControlByDictionary.set(dictionaryName, control);
        // The registry owns queued work, rebuild, publication and optional reload
        // until settlement. Every rejection is observed on this same promise.
        const repair = this._persistentIndexRepairTail.then(async () => {
            let publicationGeneration = generation;
            try {
                if (!isCurrent()) { return false; }
                const repaired = await this._repairPersistentDictionaryIndex(dictionaryName, isOwned);
                if (repaired) {
                    publicationGeneration = generation + 1;
                    if (!loadAfterRepair) { return true; }
                    if (!isOwned() || !this._isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, generation + 1)) {
                        return false;
                    }
                    if (await this._tryLoadPersistentDictionaryIndex(dictionaryName)) {
                        if (isOwned() && this._isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, generation + 1)) {
                            this._loadedDictionaryNames.add(dictionaryName);
                            return true;
                        }
                        return false;
                    }
                }
                if (isOwned() && this._isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, publicationGeneration)) {
                    this._deferPersistentIndexRepair(dictionaryName);
                    this._setDictionaryHealth(dictionaryName, 'temporarilyUnavailable', 'Dictionary lookup data is unavailable');
                }
                return false;
            } catch (error) {
                if (isOwned() && this._isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, publicationGeneration)) {
                    if (error instanceof TermRecordIntegrityError) {
                        this.markDictionaryReimportRequired(dictionaryName, 'Dictionary record data is damaged');
                    } else {
                        this._deferPersistentIndexRepair(dictionaryName);
                        this._setDictionaryHealth(dictionaryName, 'temporarilyUnavailable', String(error));
                    }
                }
                return false;
            } finally {
                if (control.cancelled && this._isPersistentLookupGenerationCurrent(dictionaryName, globalGeneration, publicationGeneration)) {
                    this._setDictionaryHealth(dictionaryName, 'repairPending', 'Dictionary repair was cancelled for a storage update');
                }
                this._persistentIndexRepairPromiseByDictionary.delete(dictionaryName);
                this._persistentIndexRepairControlByDictionary.delete(dictionaryName);
            }
        });
        this._persistentIndexRepairPromiseByDictionary.set(dictionaryName, repair);
        this._persistentIndexRepairTail = repair.then(() => {});
        return repair;
    }

    /** @param {string} dictionaryName */
    _deferPersistentIndexRepair(dictionaryName) {
        const attempts = Math.min(6, (this._persistentIndexRepairRetryByDictionary.get(dictionaryName)?.attempts ?? 0) + 1);
        this._persistentIndexRepairRetryByDictionary.set(dictionaryName, {
            attempts,
            retryAt: Date.now() + Math.min(30000, 1000 * (2 ** (attempts - 1))),
        });
    }

    /**
     * @param {string} dictionaryName
     * @param {() => boolean} [isOwned]
     * @returns {Promise<boolean>}
     */
    async _repairPersistentDictionaryIndex(dictionaryName, isOwned = () => true) {
        if (!isOwned()) { return false; }
        if (this._recordsDirectoryHandle === null) {
            this._setDictionaryHealth(dictionaryName, 'temporarilyUnavailable', 'Term-record directory is unavailable');
            return false;
        }
        const states = this._getDictionaryShardStates(dictionaryName);
        if (states.length === 0) {
            this.markDictionaryReimportRequired(dictionaryName, 'Dictionary record data is missing');
            return false;
        }
        const globalGeneration = this._persistentLookupGeneration;
        const generation = this._getPersistentLookupGeneration(dictionaryName);
        const isCurrent = () => isOwned() && this._isPersistentLookupGenerationCurrent(
            dictionaryName,
            globalGeneration,
            generation,
        );
        this._setDictionaryHealth(dictionaryName, 'repairing', null);
        const startedAt = safePerformance.now();
        let recordCount = 0;
        let indexBytes = 0;
        try {
            for (const state of states) {
                if (!isCurrent()) { return false; }
                if (
                    this._importSessionActive ||
                    this._shardStateByFileName.get(state.fileName) !== state
                ) {
                    this._recordPersistentIndexFailure(dictionaryName, 'transient', 'Lookup index generation changed during repair');
                    this._setDictionaryHealth(dictionaryName, 'temporarilyUnavailable', 'Dictionary repair was superseded by a storage update');
                    return false;
                }
                const result = await this._rebuildLookupIndexForShard(state, () => (
                    isCurrent() &&
                    !this._importSessionActive &&
                    this._shardStateByFileName.get(state.fileName) === state
                ));
                recordCount += result.recordCount;
                indexBytes += result.indexBytes;
            }
            if (!isCurrent()) { return false; }
            if (
                this._importSessionActive ||
                states.some((state) => this._shardStateByFileName.get(state.fileName) !== state)
            ) {
                this._recordPersistentIndexFailure(dictionaryName, 'transient', 'Lookup index generation changed during repair');
                this._setDictionaryHealth(dictionaryName, 'temporarilyUnavailable', 'Dictionary repair was superseded by a storage update');
                return false;
            }
            // Rebuilding is not recovery until the replacement index reloads.
            this._invalidatePersistentLookupState(dictionaryName, false);
            reportDiagnostics('term-record-persistent-index-repair-complete', {
                dictionaryName,
                shardCount: states.length,
                recordCount,
                indexBytes,
                elapsedMs: safePerformance.now() - startedAt,
            });
            return true;
        } catch (error) {
            if (!isCurrent()) { return false; }
            const message = error instanceof Error ? error.message : String(error);
            const integrityFailure = error instanceof TermRecordIntegrityError;
            if (integrityFailure) {
                this.markDictionaryReimportRequired(dictionaryName, 'Dictionary record data is damaged');
            } else {
                this._setDictionaryHealth(
                    dictionaryName,
                    'temporarilyUnavailable',
                    'Dictionary repair could not access browser storage',
                );
            }
            reportDiagnostics('term-record-persistent-index-repair-failed', {
                dictionaryName,
                shardCount: states.length,
                elapsedMs: safePerformance.now() - startedAt,
                integrityFailure,
                error: message,
            });
            return false;
        }
    }

    /**
     * @param {TermRecordShardState} state
     * @param {() => boolean} [isCurrent]
     * @returns {Promise<{recordCount: number, indexBytes: number}>}
     * @throws {Error} If authoritative storage is invalid or the repair is superseded.
     */
    async _rebuildLookupIndexForShard(state, isCurrent = () => true) {
        /** @throws {Error} If the repair no longer owns this dictionary generation. */
        const assertCurrent = () => {
            if (!isCurrent()) { throw new Error('Term-record index repair was superseded'); }
        };
        assertCurrent();
        if (this._recordsDirectoryHandle === null) {
            throw new Error('Term-record directory is unavailable');
        }
        let descriptorFile;
        try {
            descriptorFile = await state.fileHandle.getFile();
        } catch (error) {
            if (isStorageEntryNotFoundError(error)) {
                throw new TermRecordIntegrityError(`Term-record descriptor no longer exists: ${state.fileName}`);
            }
            throw error;
        }
        assertCurrent();
        state.fileLength = descriptorFile.size;
        if (descriptorFile.size < (BINARY_HEADER_PREFIX_BYTES + 2)) {
            throw new TermRecordIntegrityError(`Term-record descriptor is truncated: ${state.fileName}`);
        }
        const initialHeaderLength = Math.min(descriptorFile.size, BINARY_HEADER_PREFIX_BYTES + 2 + 4);
        const initialHeader = await this._readFileRange(descriptorFile, 0, initialHeaderLength);
        assertCurrent();
        if (!this._isBinaryFormat(initialHeader)) {
            throw new TermRecordIntegrityError(`Term-record descriptor header is invalid: ${state.fileName}`);
        }
        const initialView = new DataView(initialHeader.buffer, initialHeader.byteOffset, initialHeader.byteLength);
        const generationId = new Uint8Array(initialHeader.subarray(BINARY_MAGIC_BYTES, BINARY_HEADER_PREFIX_BYTES));
        state.generationId = generationId;
        let cursor = BINARY_HEADER_PREFIX_BYTES;
        const meta16 = initialView.getUint16(cursor, true); cursor += 2;
        let meta = meta16;
        if (meta16 === U16_NULL) {
            if ((cursor + 4) > initialHeader.byteLength) {
                throw new TermRecordIntegrityError(`Term-record shard metadata is truncated: ${state.fileName}`);
            }
            meta = initialView.getUint32(cursor, true); cursor += 4;
        }
        const customNameLength = (meta & 0xff) === ENTRY_CONTENT_DICT_NAME_CODE_CUSTOM ? (meta >>> 8) : 0;
        cursor += customNameLength;
        if (cursor > descriptorFile.size) {
            throw new TermRecordIntegrityError(`Term-record descriptor metadata is truncated: ${state.fileName}`);
        }

        const indexFileName = `${state.fileName}${LOOKUP_INDEX_FILE_SUFFIX}`;
        let indexFileHandle;
        let indexFile;
        try {
            indexFileHandle = await this._recordsDirectoryHandle.getFileHandle(indexFileName, {create: false});
            indexFile = await indexFileHandle.getFile();
        } catch (error) {
            if (isStorageEntryNotFoundError(error)) {
                throw new TermRecordIntegrityError(`Authoritative term-record container is missing: ${indexFileName}`);
            }
            throw error;
        }
        if (indexFile.size < LOOKUP_INDEX_FILE_HEADER_BYTES) {
            throw new TermRecordIntegrityError(`Authoritative term-record container is truncated: ${indexFileName}`);
        }
        const content = new Uint8Array(await indexFile.arrayBuffer());
        assertCurrent();
        const sourceView = new DataView(content.buffer, content.byteOffset, content.byteLength);
        if (this._textDecoder.decode(content.subarray(0, LOOKUP_INDEX_MAGIC_BYTES)) !== LOOKUP_INDEX_MAGIC_TEXT) {
            throw new TermRecordIntegrityError(`Authoritative term-record container header is invalid: ${indexFileName}`);
        }
        const sourceGeneration = content.subarray(24, LOOKUP_INDEX_FILE_HEADER_BYTES);
        if (!bytesEqual(sourceGeneration, generationId)) {
            throw new TermRecordIntegrityError(`Authoritative term-record generation does not match ${state.fileName}`);
        }
        let expectedDescriptorLength;
        try {
            expectedDescriptorLength = readSafeU64Le(sourceView, 8);
        } catch (error) {
            throw new TermRecordIntegrityError(`Authoritative descriptor length is invalid: ${state.fileName}: ${String(error)}`);
        }
        const sourceChunkCount = sourceView.getUint32(16, true);
        const sourceRecordCount = sourceView.getUint32(20, true);
        if (
            expectedDescriptorLength !== descriptorFile.size ||
            sourceChunkCount === 0 ||
            sourceRecordCount === 0
        ) {
            throw new TermRecordIntegrityError(`Authoritative term-record container metadata is invalid: ${indexFileName}`);
        }

        // FileSystemWritableFileStream publishes its staged replacement on
        // close. A failed or aborted repair therefore leaves the prior
        // authoritative container available for a later retry.
        const writable = await indexFileHandle.createWritable();
        let chunkCount = 0;
        let recordCount = 0;
        let indexBytes = LOOKUP_INDEX_FILE_HEADER_BYTES;
        let yieldDeadline = safePerformance.now() + REPAIR_YIELD_BUDGET_MS;
        try {
            // Creation itself can suspend. Keep this check inside the abort
            // scope so a newly opened, obsolete writer is always abandoned.
            assertCurrent();
            await writable.truncate(0);
            await writable.seek(0);
            await writable.write(new Uint8Array(LOOKUP_INDEX_FILE_HEADER_BYTES));
            cursor = LOOKUP_INDEX_FILE_HEADER_BYTES;
            for (let sourceChunk = 0; sourceChunk < sourceChunkCount; ++sourceChunk) {
                assertCurrent();
                if ((cursor + LOOKUP_INDEX_CHUNK_HEADER_BYTES) > content.byteLength) {
                    throw new TermRecordIntegrityError(`Authoritative chunk header is truncated: ${indexFileName}`);
                }
                const firstId = sourceView.getUint32(cursor, true); cursor += 4;
                const count = sourceView.getUint32(cursor, true); cursor += 4;
                let contentOffsetBase;
                try {
                    contentOffsetBase = readSafeU64Le(sourceView, cursor);
                } catch (error) {
                    throw new TermRecordIntegrityError(`Authoritative chunk content offset is invalid: ${state.fileName}: ${String(error)}`);
                }
                cursor += 8;
                const payloadLength = sourceView.getUint32(cursor, true); cursor += 4;
                const baseLength = sourceView.getUint32(cursor, true); cursor += 4;
                const baseHash = sourceView.getUint32(cursor, true); cursor += 4;
                const derivedHash = sourceView.getUint32(cursor, true); cursor += 4;
                const recordFieldsHash = sourceView.getUint32(cursor, true); cursor += 4;
                const formatFlags = sourceView.getUint32(cursor, true); cursor += 4;
                const lastId = firstId + count - 1;
                if (
                    firstId <= 0 ||
                    count === 0 ||
                    lastId > 0xffffffff ||
                    baseLength === 0 ||
                    baseLength >= payloadLength ||
                    (
                        formatFlags !== LOOKUP_INDEX_RECORD_FIELDS_FORMAT_LEGACY &&
                        formatFlags !== LOOKUP_INDEX_RECORD_FIELDS_FORMAT_COMPACT &&
                        formatFlags !== LOOKUP_INDEX_RECORD_FIELDS_FORMAT_FLOAT64_SCORE
                    )
                ) {
                    throw new TermRecordIntegrityError(`Authoritative chunk metadata is invalid: ${state.fileName}`);
                }
                const payloadEnd = cursor + payloadLength;
                let recordFieldsLength;
                try {
                    recordFieldsLength = getRecordFieldsByteLength(content, payloadEnd, count, formatFlags);
                } catch (error) {
                    throw new TermRecordIntegrityError(`Authoritative chunk fields are invalid: ${state.fileName}: ${String(error)}`);
                }
                const recordFieldsEnd = payloadEnd + recordFieldsLength;
                if (!Number.isSafeInteger(recordFieldsEnd) || recordFieldsEnd > content.byteLength) {
                    throw new TermRecordIntegrityError(`Authoritative chunk payload is truncated: ${state.fileName}`);
                }
                const payload = content.subarray(cursor, payloadEnd);
                const recordFields = content.subarray(payloadEnd, recordFieldsEnd);
                let base;
                let derivedValid = false;
                try {
                    const sections = splitPersistedTermLookupIndex(payload);
                    base = sections.base;
                    derivedValid = hashLookupIndexBytes(sections.derived) === derivedHash;
                } catch (_) {
                    base = getPersistedTermLookupBaseBytes(payload, baseLength);
                }
                if (
                    base.byteLength !== baseLength ||
                    hashLookupIndexBytes(base) !== baseHash ||
                    hashLookupIndexBytes(recordFields) !== recordFieldsHash
                ) {
                    throw new TermRecordIntegrityError(`Authoritative term-record bytes are damaged: ${state.fileName}`);
                }
                try {
                    validateRecordFields(recordFields, count, formatFlags, contentOffsetBase);
                } catch (error) {
                    throw new TermRecordIntegrityError(`Authoritative term-record fields are invalid: ${state.fileName}: ${String(error)}`);
                }
                let lookupPayload = payload;
                if (!derivedValid) {
                    lookupPayload = rebuildPersistedTermLookupIndexFromBase(base);
                } else {
                    try {
                        parseChecksummedPersistedTermLookupIndex(payload);
                    } catch (_) {
                        lookupPayload = rebuildPersistedTermLookupIndexFromBase(base);
                    }
                }
                const indexChunk = this._createLookupIndexChunk(
                    firstId,
                    count,
                    contentOffsetBase,
                    lookupPayload,
                    recordFields,
                    formatFlags,
                );
                await writable.write(indexChunk);
                ++chunkCount;
                recordCount += count;
                indexBytes += indexChunk.byteLength;
                cursor = recordFieldsEnd;
                if (safePerformance.now() >= yieldDeadline) {
                    await new Promise((resolve) => { setTimeout(resolve, 0); });
                    yieldDeadline = safePerformance.now() + REPAIR_YIELD_BUDGET_MS;
                }
            }
            if (
                chunkCount !== sourceChunkCount ||
                recordCount !== sourceRecordCount ||
                cursor !== content.byteLength
            ) {
                throw new TermRecordIntegrityError(`Authoritative term-record container is incomplete: ${state.fileName}`);
            }
            assertCurrent();
            const header = new Uint8Array(LOOKUP_INDEX_FILE_HEADER_BYTES);
            header.set(this._textEncoder.encode(LOOKUP_INDEX_MAGIC_TEXT), 0);
            const headerView = new DataView(header.buffer, header.byteOffset, header.byteLength);
            writeSafeU64Le(headerView, 8, descriptorFile.size);
            headerView.setUint32(16, chunkCount, true);
            headerView.setUint32(20, recordCount, true);
            header.set(generationId, 24);
            await writable.seek(0);
            await writable.write(header);
            assertCurrent();
            await writable.close();
        } catch (error) {
            const abort = Reflect.get(writable, 'abort');
            if (typeof abort === 'function') {
                try {
                    await /** @type {() => Promise<void>} */ (abort).call(writable);
                } catch (_) {
                    // Preserve the original repair failure.
                }
            }
            throw error;
        }
        return {recordCount, indexBytes};
    }

    /**
     * @param {string} dictionaryName
     * @returns {TermRecordShardState[]}
     */
    _getDictionaryShardStates(dictionaryName) {
        return [...this._shardStateByFileName.values()]
            .filter((state) => this._decodeDictionaryNameFromShardFileName(state.fileName) === dictionaryName)
            .sort((a, b) => a.fileName.localeCompare(b.fileName));
    }

    /**
     * @param {string} dictionaryName
     * @param {string} query
     * @param {'expression'|'reading'} field
     * @returns {number[]}
     */
    findTermIds(dictionaryName, query, field) {
        const chunks = this._persistentRecordChunksByDictionary.get(dictionaryName);
        if (this._persistentIndexLoadedDictionaryNames.has(dictionaryName) && typeof chunks !== 'undefined') {
            const queryBytes = this._textEncoder.encode(query);
            const queryHash = hashTermLookupKeyBytes(queryBytes);
            const ids = [];
            for (const chunk of chunks) {
                for (const row of findExactRows(chunk.lookupIndex, queryBytes, field, queryHash)) {
                    ids.push(chunk.firstId + row);
                }
            }
            return ids;
        }
        return [...(this.getDictionaryIndex(dictionaryName)[field].get(query) ?? [])];
    }

    /**
     * Resolves all requested readings for one expression together. Persistent
     * indexes verify per-row reading keys, avoiding reading-wide postings and
     * intersection sets. Record hydration remains the final pair oracle.
     * @param {string} dictionaryName
     * @param {string} expression
     * @param {{reading: string}[]} requests
     * @returns {Map<string, number[]>}
     */
    findTermPairCandidates(dictionaryName, expression, requests) {
        /** @type {Map<string, number[]>} */
        const matches = new Map();
        if (requests.length === 0) { return matches; }
        const chunks = this._persistentRecordChunksByDictionary.get(dictionaryName);
        if (this._persistentIndexLoadedDictionaryNames.has(dictionaryName) && typeof chunks !== 'undefined') {
            if (requests.length === 1) {
                const {reading} = requests[0];
                const ids = this._findSingleReadingTermPairCandidates(chunks, expression, reading);
                if (typeof ids !== 'undefined') { matches.set(reading, ids); }
                return matches;
            }
            const expressionBytes = this._textEncoder.encode(expression);
            const expressionHash = hashTermLookupKeyBytes(expressionBytes);
            /** @type {Map<string, {bytes: Uint8Array, hash: number}>|null} */
            let queries = null;
            for (const chunk of chunks) {
                const expressionKey = findExactKey(chunk.lookupIndex, expressionBytes, expressionHash);
                if (expressionKey < 0) { continue; }
                const {expressionPostingOffsets, expressionPostingRows} = chunk.lookupIndex;
                const postingStart = expressionPostingOffsets[expressionKey];
                const postingEnd = expressionPostingOffsets[expressionKey + 1];
                if (postingStart === postingEnd) { continue; }
                if (queries === null) {
                    queries = new Map();
                    for (const {reading} of requests) {
                        if (queries.has(reading)) { continue; }
                        const bytes = reading === expression ? expressionBytes : this._textEncoder.encode(reading);
                        queries.set(reading, {bytes, hash: reading === expression ? expressionHash : hashTermLookupKeyBytes(bytes)});
                    }
                }
                // Key IDs belong to one chunk. Resolve only after its expression
                // hits, so an ordinary miss never encodes or probes readings.
                /** @type {Map<string, number>} */
                const readingKeys = new Map();
                for (const [reading, {bytes, hash}] of queries) {
                    const key = reading === expression ? expressionKey : findExactKey(chunk.lookupIndex, bytes, hash);
                    if (key >= 0) { readingKeys.set(reading, key); }
                }
                if (readingKeys.size === 0) { continue; }
                for (let postingIndex = postingStart; postingIndex < postingEnd; ++postingIndex) {
                    const row = expressionPostingRows[postingIndex];
                    const rowReadingKey = chunk.lookupIndex.readingKeys[row];
                    const actualReadingKey = rowReadingKey === U16_NULL ? expressionKey : rowReadingKey;
                    for (const [reading, key] of readingKeys) {
                        if (actualReadingKey !== key) { continue; }
                        let ids = matches.get(reading);
                        if (typeof ids === 'undefined') { matches.set(reading, ids = []); }
                        ids.push(chunk.firstId + row);
                    }
                }
            }
            return matches;
        }
        const index = this.getDictionaryIndex(dictionaryName);
        const expressionIds = index.expression.get(expression) ?? [];
        if (expressionIds.length === 0) { return matches; }
        for (const reading of new Set(requests.map((request) => request.reading))) {
            // Equal text includes aliased readings omitted from reading postings.
            // The existing hydrated-record check rejects other readings later.
            const readingIds = reading === expression ? null : new Set(index.reading.get(reading) ?? []);
            const ids = readingIds === null ? [...expressionIds] : expressionIds.filter((id) => readingIds.has(id));
            if (ids.length > 0) { matches.set(reading, ids); }
        }
        return matches;
    }

    /**
     * Select one reading without building per-query/per-chunk maps. The batch
     * path uses the same validated chunk-local reading keys and row ordering.
     * @param {PersistentRecordChunk[]} chunks
     * @param {string} expression
     * @param {string} reading
     * @returns {number[]|undefined}
     */
    _findSingleReadingTermPairCandidates(chunks, expression, reading) {
        const expressionBytes = this._textEncoder.encode(expression);
        const expressionHash = hashTermLookupKeyBytes(expressionBytes);
        /** @type {Uint8Array|null} */
        let readingBytes = null;
        let readingHash = 0;
        /** @type {number[]|undefined} */
        let ids;
        for (const chunk of chunks) {
            const expressionKey = findExactKey(chunk.lookupIndex, expressionBytes, expressionHash);
            if (expressionKey < 0) { continue; }
            const {expressionPostingOffsets, expressionPostingRows} = chunk.lookupIndex;
            const start = expressionPostingOffsets[expressionKey];
            const end = expressionPostingOffsets[expressionKey + 1];
            if (start === end) { continue; }
            let readingKey = expressionKey;
            if (reading !== expression) {
                if (readingBytes === null) {
                    readingBytes = this._textEncoder.encode(reading);
                    readingHash = hashTermLookupKeyBytes(readingBytes);
                }
                readingKey = findExactKey(chunk.lookupIndex, readingBytes, readingHash);
                if (readingKey < 0) { continue; }
            }
            for (let index = start; index < end; ++index) {
                const row = expressionPostingRows[index];
                const rowReadingKey = chunk.lookupIndex.readingKeys[row];
                if ((rowReadingKey === U16_NULL ? expressionKey : rowReadingKey) !== readingKey) { continue; }
                if (typeof ids === 'undefined') { ids = []; }
                ids.push(chunk.firstId + row);
            }
        }
        return ids;
    }

    /**
     * Resolves expression and reading postings together so persistent chunks only
     * hash and probe the query once.
     * @param {string} dictionaryName
     * @param {string} query
     * @returns {{expression: number[], reading: number[]}}
     */
    findTermIdMatches(dictionaryName, query) {
        const chunks = this._persistentRecordChunksByDictionary.get(dictionaryName);
        if (this._persistentIndexLoadedDictionaryNames.has(dictionaryName) && typeof chunks !== 'undefined') {
            const queryBytes = this._textEncoder.encode(query);
            const queryHash = hashTermLookupKeyBytes(queryBytes);
            /** @type {number[]} */
            const expression = [];
            /** @type {number[]} */
            const reading = [];
            for (const chunk of chunks) {
                appendExactRowMatches(
                    chunk.lookupIndex,
                    queryBytes,
                    expression,
                    reading,
                    chunk.firstId,
                    queryHash,
                );
            }
            return {expression, reading};
        }
        const index = this.getDictionaryIndex(dictionaryName);
        return {
            expression: [...(index.expression.get(query) ?? [])],
            reading: [...(index.reading.get(query) ?? [])],
        };
    }

    /**
     * Resolves the same query across dictionaries while sharing UTF-8 encoding
     * and hashing, which are otherwise repeated for every enabled dictionary.
     * @param {string[]} dictionaryNames
     * @param {string} query
     * @returns {Array<{expression: number[], reading: number[]}>}
     */
    findTermIdMatchesForDictionaries(dictionaryNames, query) {
        /** @type {Uint8Array|null} */
        let queryBytes = null;
        let queryHash = 0;
        return dictionaryNames.map((dictionaryName) => {
            const chunks = this._persistentRecordChunksByDictionary.get(dictionaryName);
            if (this._persistentIndexLoadedDictionaryNames.has(dictionaryName) && typeof chunks !== 'undefined') {
                if (queryBytes === null) {
                    queryBytes = this._textEncoder.encode(query);
                    queryHash = hashTermLookupKeyBytes(queryBytes);
                }
                /** @type {number[]} */
                const expression = [];
                /** @type {number[]} */
                const reading = [];
                for (const chunk of chunks) {
                    appendExactRowMatches(
                        chunk.lookupIndex,
                        queryBytes,
                        expression,
                        reading,
                        chunk.firstId,
                        queryHash,
                    );
                }
                return {expression, reading};
            }
            const index = this.getDictionaryIndex(dictionaryName);
            return {
                expression: [...(index.expression.get(query) ?? [])],
                reading: [...(index.reading.get(query) ?? [])],
            };
        });
    }

    /**
     * @param {Iterable<string>} dictionaryNames
     * @returns {Promise<void>}
     */
    async warmPrefixIndexes(dictionaryNames) {
        await new Promise((resolve) => { setTimeout(resolve, 0); });
        let yieldDeadline = safePerformance.now() + PREFIX_WARM_YIELD_BUDGET_MS;
        for (const dictionaryName of dictionaryNames) {
            const chunks = this._persistentRecordChunksByDictionary.get(dictionaryName);
            if (!this._persistentIndexLoadedDictionaryNames.has(dictionaryName) || typeof chunks === 'undefined') {
                continue;
            }
            for (const chunk of chunks) {
                warmPersistedTermPrefixIndex(chunk.lookupIndex);
                if (safePerformance.now() < yieldDeadline) { continue; }
                await new Promise((resolve) => { setTimeout(resolve, 0); });
                yieldDeadline = safePerformance.now() + PREFIX_WARM_YIELD_BUDGET_MS;
            }
        }
    }

    /**
     * @param {string} dictionaryName
     * @param {string} query
     * @param {'expression'|'reading'} field
     * @param {boolean} [reverse=false]
     * @returns {Array<{id: number, exact: boolean}>}
     */
    findTermPrefixIdMatches(dictionaryName, query, field, reverse = false) {
        const chunks = this._persistentRecordChunksByDictionary.get(dictionaryName);
        if (this._persistentIndexLoadedDictionaryNames.has(dictionaryName) && typeof chunks !== 'undefined') {
            const queryBytes = this._textEncoder.encode(query);
            const matches = [];
            for (const chunk of chunks) {
                for (const {row, exact} of findPrefixRows(chunk.lookupIndex, queryBytes, field, reverse)) {
                    matches.push({id: chunk.firstId + row, exact});
                }
            }
            return matches;
        }
        const index = this.getDictionaryIndex(dictionaryName);
        const lookup = index[field];
        const matches = [];
        for (const [key, ids] of lookup) {
            const matched = reverse ? key.endsWith(query) : key.startsWith(query);
            if (!matched) { continue; }
            for (const id of ids) { matches.push({id, exact: key === query}); }
        }
        return matches;
    }

    /**
     * Resolves both prefix fields across dictionaries while sharing UTF-8
     * encoding and each persisted key-range scan.
     * @param {string[]} dictionaryNames
     * @param {string} query
     * @param {boolean} [reverse=false]
     * @returns {Array<{expression: Array<{id: number, exact: boolean}>, reading: Array<{id: number, exact: boolean}>}>}
     */
    findTermPrefixIdMatchesForDictionaries(dictionaryNames, query, reverse = false) {
        /** @type {Uint8Array|null} */
        let queryBytes = null;
        return dictionaryNames.map((dictionaryName) => {
            const chunks = this._persistentRecordChunksByDictionary.get(dictionaryName);
            if (this._persistentIndexLoadedDictionaryNames.has(dictionaryName) && typeof chunks !== 'undefined') {
                queryBytes ??= this._textEncoder.encode(query);
                /** @type {Array<{id: number, exact: boolean}>} */
                const expression = [];
                /** @type {Array<{id: number, exact: boolean}>} */
                const reading = [];
                for (const chunk of chunks) {
                    appendPrefixIdMatches(
                        chunk.lookupIndex,
                        queryBytes,
                        expression,
                        reading,
                        chunk.firstId,
                        reverse,
                    );
                }
                return {expression, reading};
            }
            return {
                expression: this.findTermPrefixIdMatches(dictionaryName, query, 'expression', reverse),
                reading: this.findTermPrefixIdMatches(dictionaryName, query, 'reading', reverse),
            };
        });
    }

    /**
     * @param {string} dictionaryName
     * @param {number} sequence
     * @returns {number[]}
     */
    findTermIdsBySequence(dictionaryName, sequence) {
        const chunks = this._persistentRecordChunksByDictionary.get(dictionaryName);
        if (this._persistentIndexLoadedDictionaryNames.has(dictionaryName) && typeof chunks !== 'undefined') {
            const ids = [];
            for (const chunk of chunks) {
                for (const row of findSequenceRows(chunk.lookupIndex, sequence)) {
                    ids.push(chunk.firstId + row);
                }
            }
            return ids;
        }
        return [...(this.getDictionaryIndex(dictionaryName).sequence.get(sequence) ?? [])];
    }

    /**
     * @param {string} dictionaryName
     * @returns {boolean}
     */
    hasPersistentTermLookupIndex(dictionaryName) {
        return (
            this._persistentIndexLoadedDictionaryNames.has(dictionaryName) &&
            this._persistentRecordChunksByDictionary.has(dictionaryName)
        );
    }

    /**
     * @param {string} dictionaryName
     * @returns {boolean}
     */
    _hasCompleteDictionaryLookupState(dictionaryName) {
        if (this.hasPersistentTermLookupIndex(dictionaryName)) { return true; }
        return (
            this._allShardContentsLoaded &&
            this._loadedDictionaryNames.has(dictionaryName) &&
            (!this._importSessionActive || !this._importSessionDictionaryNames.has(dictionaryName)) &&
            this._hasRecordsForDictionary(dictionaryName)
        );
    }

    /**
     * @param {string} dictionaryName
     * @returns {number}
     */
    getDictionaryRecordCount(dictionaryName) {
        const chunks = this._persistentRecordChunksByDictionary.get(dictionaryName);
        if (this._persistentIndexLoadedDictionaryNames.has(dictionaryName) && typeof chunks !== 'undefined') {
            let count = 0;
            for (const chunk of chunks) { count += chunk.count; }
            return count;
        }
        const ids = this._getLiveRecordIdsForDictionary(dictionaryName);
        if (typeof ids !== 'undefined') { return ids.length; }
        let count = 0;
        for (const record of this._recordsById.values()) {
            if (record.dictionary === dictionaryName) { ++count; }
        }
        return count;
    }

    /**
     * Returns one authoritative ID page without materializing term records.
     * Persistent chunks already describe contiguous ID ranges, so derived index
     * builders can keep both ID and record hydration bounded.
     * @param {string} dictionaryName
     * @param {number} offset
     * @param {number} limit
     * @returns {number[]}
     */
    getDictionaryIdBatch(dictionaryName, offset, limit) {
        if (!Number.isInteger(offset) || offset < 0 || !Number.isInteger(limit) || limit <= 0) {
            return [];
        }
        const chunks = this._persistentRecordChunksByDictionary.get(dictionaryName);
        if (this._persistentIndexLoadedDictionaryNames.has(dictionaryName) && typeof chunks !== 'undefined') {
            const ids = [];
            let remainingOffset = offset;
            for (const chunk of chunks) {
                if (remainingOffset >= chunk.count) {
                    remainingOffset -= chunk.count;
                    continue;
                }
                const start = remainingOffset;
                const count = Math.min(chunk.count - start, limit - ids.length);
                for (let i = 0; i < count; ++i) {
                    ids.push(chunk.firstId + start + i);
                }
                remainingOffset = 0;
                if (ids.length >= limit) { break; }
            }
            return ids;
        }
        const liveIds = this._getLiveRecordIdsForDictionary(dictionaryName);
        if (typeof liveIds !== 'undefined') { return liveIds.slice(offset, offset + limit); }
        const ids = [];
        let matched = 0;
        for (const record of this._recordsById.values()) {
            if (record.dictionary !== dictionaryName) { continue; }
            if (matched++ < offset) { continue; }
            ids.push(record.id);
            if (ids.length >= limit) { break; }
        }
        return ids;
    }

    /**
     * @param {string} dictionaryName
     * @param {number} limit
     * @returns {number[]}
     */
    getDictionarySampleIds(dictionaryName, limit) {
        return this.getDictionaryIdBatch(dictionaryName, 0, limit);
    }

    /**
     * @param {Iterable<string>} dictionaryNames
     * @param {{repairMode?: 'await'|'background'}} [options]
     * @returns {Promise<void>}
     */
    async ensureDictionariesLoaded(dictionaryNames, {repairMode = 'await'} = {}) {
        if (repairMode !== 'await' && repairMode !== 'background') {
            throw new Error(`Invalid dictionary repair mode: ${repairMode}`);
        }
        // Persisted names are identities; whitespace and U+FEFF are significant.
        if (this._recordsDirectoryHandle === null) {
            for (const value of dictionaryNames) {
                const dictionaryName = `${value}`;
                if (
                    dictionaryName.length > 0 &&
                    !this._pendingDictionaryDeletionNames.has(dictionaryName) &&
                    this.getDictionaryHealth(dictionaryName).status !== 'reimportRequired'
                ) {
                    this._setDictionaryHealth(
                        dictionaryName,
                        'temporarilyUnavailable',
                        'Term-record directory is unavailable',
                    );
                }
            }
            return;
        }
        const globalGeneration = this._persistentLookupGeneration;
        /** @type {Map<string, number>} */
        const pending = new Map();
        for (const dictionaryName of dictionaryNames) {
            const name = `${dictionaryName}`;
            const existingRepair = this._persistentIndexRepairPromiseByDictionary.get(name);
            if (typeof existingRepair !== 'undefined') {
                if (repairMode === 'await') {
                    await existingRepair;
                } else {
                    continue;
                }
            }
            const healthStatus = this.getDictionaryHealth(name).status;
            if (
                name.length === 0 ||
                this._pendingDictionaryDeletionNames.has(name) ||
                healthStatus === 'reimportRequired' ||
                (repairMode === 'background' && Date.now() < (this._persistentIndexRepairRetryByDictionary.get(name)?.retryAt ?? 0)) ||
                (healthStatus === 'available' && this._hasCompleteDictionaryLookupState(name))
            ) {
                continue;
            }
            pending.set(name, this._getPersistentLookupGeneration(name));
        }
        if (pending.size === 0) { return; }
        /**
         * @param {string} name
         * @returns {boolean}
         */
        const isCurrent = (name) => {
            const generation = pending.get(name);
            return (
                typeof generation === 'number' &&
                this._isPersistentLookupGenerationCurrent(name, globalGeneration, generation)
            );
        };
        const persistentIndexNames = [...pending.keys()];
        /** @type {string[]} */
        const persistentIndexLoadedNames = [];
        let nextPersistentIndex = 0;
        const loadNextPersistentIndex = async () => {
            while (true) {
                const index = nextPersistentIndex++;
                if (index >= persistentIndexNames.length) { return; }
                const dictionaryName = persistentIndexNames[index];
                if (!isCurrent(dictionaryName)) { continue; }
                if (
                    await this._tryLoadPersistentDictionaryIndex(dictionaryName) &&
                    isCurrent(dictionaryName)
                ) {
                    persistentIndexLoadedNames.push(dictionaryName);
                }
            }
        };
        const persistentIndexLoadConcurrency = Math.min(3, persistentIndexNames.length);
        await Promise.all(
            Array.from({length: persistentIndexLoadConcurrency}, () => loadNextPersistentIndex()),
        );
        for (const dictionaryName of persistentIndexLoadedNames) {
            if (isCurrent(dictionaryName) && pending.delete(dictionaryName)) {
                this._loadedDictionaryNames.add(dictionaryName);
            }
        }
        if (pending.size === 0) { return; }

        // The derived lookup section can be rebuilt from each container's
        // authoritative base. Serialize repairs to cap CPU and memory.
        for (const [dictionaryName, generation] of pending) {
            if (!isCurrent(dictionaryName)) {
                pending.delete(dictionaryName);
                continue;
            }
            const failure = this._persistentIndexFailureByDictionary.get(dictionaryName);
            if (failure?.kind === 'transient') {
                this._setDictionaryHealth(
                    dictionaryName,
                    'temporarilyUnavailable',
                    failure.message || 'Dictionary lookup data is temporarily unavailable',
                );
                pending.delete(dictionaryName);
                continue;
            }
            this._setDictionaryHealth(dictionaryName, 'repairPending', 'Dictionary lookup index needs repair');
            const repair = this._tryRepairPersistentDictionaryIndex(dictionaryName, false, repairMode === 'background');
            if (repairMode === 'background') {
                pending.delete(dictionaryName);
                continue;
            }
            if (!await repair) { continue; }
            // A successful repair invalidates exactly this dictionary once.
            // Do not adopt any additional invalidation from a concurrent update.
            if (!this._isPersistentLookupGenerationCurrent(
                dictionaryName,
                globalGeneration,
                generation + 1,
            )) {
                pending.delete(dictionaryName);
                continue;
            }
            pending.set(dictionaryName, generation + 1);
            if (
                await this._tryLoadPersistentDictionaryIndex(dictionaryName) &&
                isCurrent(dictionaryName)
            ) {
                pending.delete(dictionaryName);
                this._loadedDictionaryNames.add(dictionaryName);
            }
        }
        if (pending.size === 0) { return; }

        for (const dictionaryName of pending.keys()) {
            if (isCurrent(dictionaryName)) {
                this._setDictionaryHealth(
                    dictionaryName,
                    'temporarilyUnavailable',
                    'Dictionary lookup data is unavailable',
                );
            }
        }
    }

    /**
     * @param {string} dictionaryName
     */
    _discardMaterializedDictionary(dictionaryName) {
        const ids = this._getLiveRecordIdsForDictionary(dictionaryName) ?? this._recordsById.keys();
        for (const id of ids) {
            const record = this._recordsById.get(id);
            if (record?.dictionary === dictionaryName) {
                this._deleteRecord(id);
            }
        }
        this._recordIdsByDictionary.delete(dictionaryName);
        this._recordIdStaleDictionaryNames.delete(dictionaryName);
        this._indexByDictionary.delete(dictionaryName);
        this._loadedDictionaryNames.delete(dictionaryName);
    }

    /** @returns {Promise<void>} */
    async ensureAllDictionariesLoaded() {
        if (this._allShardContentsLoaded || this._recordsDirectoryHandle === null) {
            return;
        }
        /** @type {string[]} */
        const dictionaryNames = [];
        for (const fileName of this._shardStateByFileName.keys()) {
            const dictionaryName = this._decodeDictionaryNameFromShardFileName(fileName);
            if (dictionaryName !== null && dictionaryName.length > 0 && !dictionaryNames.includes(dictionaryName)) {
                dictionaryNames.push(dictionaryName);
            }
        }
        await this.ensureDictionariesLoaded(dictionaryNames);
        this._allShardContentsLoaded = dictionaryNames.every((name) => this._hasCompleteDictionaryLookupState(name));
        // Lookup readiness does not reserve IDs: lazy chunks need not have materialized records.
        // Keep the allocator scan pending until it has inspected every authoritative container.
    }

    /**
     * @param {string[]|null} [expectedDictionaryNames]
     * @returns {Promise<{
     *   expectedShardCount: number,
     *   actualShardCount: number,
     *   missingShardCount: number,
     *   missingShardFileNames: string[],
     *   missingDictionaryNames: string[],
     *   orphanShardCount: number,
     *   orphanShardFileNames: string[],
     *   orphanDictionaryNames: string[],
     *   removedOrphanShardCount: number,
     *   invalidShardPayloadCount: number,
     *   invalidShardFileNames: string[],
     *   rewroteAllShardsFromMemory: boolean
     * }>}
     */
    async verifyIntegrity(expectedDictionaryNames = null) {
        if (!this._allShardContentsLoaded && this._recordsById.size === 0) {
            /** @type {Set<string>|null} */
            const expectedNames = Array.isArray(expectedDictionaryNames) ?
                new Set(expectedDictionaryNames.filter((name) => typeof name === 'string' && name.length > 0)) :
                null;
            /** @type {Set<string>} */
            const actualNames = new Set();
            /** @type {Map<string, string[]>} */
            const actualFileNamesByDictionary = new Map();
            for (const fileName of this._shardStateByFileName.keys()) {
                const dictionaryName = this._decodeDictionaryNameFromShardFileName(fileName);
                if (dictionaryName === null) { continue; }
                actualNames.add(dictionaryName);
                const fileNames = actualFileNamesByDictionary.get(dictionaryName);
                if (typeof fileNames === 'undefined') {
                    actualFileNamesByDictionary.set(dictionaryName, [fileName]);
                } else {
                    fileNames.push(fileName);
                }
            }
            /** @type {string[]} */
            let missingDictionaryNames = [];
            /** @type {string[]} */
            let orphanDictionaryNames = [];
            if (expectedNames !== null) {
                missingDictionaryNames = [...expectedNames].filter((name) => !actualNames.has(name)).sort();
                orphanDictionaryNames = [...actualNames].filter((name) => !expectedNames.has(name)).sort();
            }
            const orphanShardFileNames = orphanDictionaryNames
                .flatMap((name) => actualFileNamesByDictionary.get(name) ?? [])
                .sort();
            let removedOrphanShardCount = 0;
            for (const dictionaryName of orphanDictionaryNames) {
                try {
                    // A failed deletion must still retire every codec shard
                    // for this identity. A later import may use another codec.
                    await this._deleteShardByDictionary(dictionaryName);
                } catch (error) {
                    reportDiagnostics('term-record-orphan-shard-cleanup-failed', {
                        dictionaryName,
                        error: error instanceof Error ? error.message : String(error),
                    });
                    continue;
                }
                removedOrphanShardCount += actualFileNamesByDictionary.get(dictionaryName)?.length ?? 0;
            }
            const summary = {
                expectedShardCount: expectedNames?.size ?? 0,
                actualShardCount: this._shardStateByFileName.size,
                missingShardCount: missingDictionaryNames.length,
                missingShardFileNames: missingDictionaryNames.map((name) => this._getShardFileName(name)),
                missingDictionaryNames,
                orphanShardCount: orphanShardFileNames.length,
                orphanShardFileNames,
                orphanDictionaryNames,
                removedOrphanShardCount,
                invalidShardPayloadCount: this._invalidShardFileNames.length,
                invalidShardFileNames: [...this._invalidShardFileNames].sort(),
                rewroteAllShardsFromMemory: false,
            };
            reportDiagnostics('term-record-shard-integrity-summary', summary);
            return summary;
        }
        /** @type {Set<string>} */
        const expectedShardKeys = new Set();
        for (const record of this._recordsById.values()) {
            const shardKey = this._getShardFileName(record.dictionary, record.entryContentDictName);
            expectedShardKeys.add(shardKey);
        }
        if (Array.isArray(expectedDictionaryNames)) {
            for (const dictionaryName of expectedDictionaryNames) {
                if (typeof dictionaryName !== 'string' || dictionaryName.length === 0) { continue; }
                expectedShardKeys.add(this._getShardFileName(dictionaryName));
            }
        }

        /** @type {Map<string, string[]>} */
        const actualFilesByShardKey = new Map();
        for (const fileName of this._shardStateByFileName.keys()) {
            const shardInfo = this._decodeShardInfoFromShardFileName(fileName);
            if (shardInfo === null) { continue; }
            const shardKey = this._getShardFileName(shardInfo.dictionaryName, shardInfo.contentDictName);
            const existing = actualFilesByShardKey.get(shardKey);
            if (typeof existing === 'undefined') {
                actualFilesByShardKey.set(shardKey, [fileName]);
            } else {
                existing.push(fileName);
            }
        }

        /** @type {string[]} */
        const missingShardFileNames = [];
        /** @type {string[]} */
        const orphanShardFileNames = [];
        for (const shardKey of expectedShardKeys) {
            if (!actualFilesByShardKey.has(shardKey)) {
                missingShardFileNames.push(shardKey);
            }
        }
        for (const [shardKey, fileNames] of actualFilesByShardKey) {
            if (!expectedShardKeys.has(shardKey)) {
                orphanShardFileNames.push(...fileNames);
            }
        }

        let removedOrphanShardCount = 0;
        for (const fileName of orphanShardFileNames) {
            try {
                // Remove the descriptor first so a partial cleanup cannot leave
                // a discoverable dictionary without its authoritative container.
                await this._removeStorageFileOrTruncate(fileName, true);
                await this._removeStorageFileOrTruncate(`${fileName}${LOOKUP_INDEX_FILE_SUFFIX}`, true);
            } catch (error) {
                reportDiagnostics('term-record-orphan-shard-cleanup-failed', {
                    fileName,
                    error: error instanceof Error ? error.message : String(error),
                });
                continue;
            }
            this._shardStateByFileName.delete(fileName);
            ++removedOrphanShardCount;
        }

        const missingDictionaryNames = missingShardFileNames
            .map((fileName) => this._decodeDictionaryNameFromShardFileName(fileName))
            .filter((value) => typeof value === 'string');
        const orphanDictionaryNames = orphanShardFileNames
            .map((fileName) => this._decodeDictionaryNameFromShardFileName(fileName))
            .filter((value) => typeof value === 'string');

        const summary = {
            expectedShardCount: expectedShardKeys.size,
            actualShardCount: this._shardStateByFileName.size,
            missingShardCount: missingShardFileNames.length,
            missingShardFileNames: [...missingShardFileNames].sort(),
            missingDictionaryNames: [...new Set(missingDictionaryNames)].sort(),
            orphanShardCount: orphanShardFileNames.length,
            orphanShardFileNames: [...orphanShardFileNames].sort(),
            orphanDictionaryNames: [...new Set(orphanDictionaryNames)].sort(),
            removedOrphanShardCount,
            invalidShardPayloadCount: this._invalidShardFileNames.length,
            invalidShardFileNames: [...this._invalidShardFileNames].sort(),
            rewroteAllShardsFromMemory: false,
        };
        reportDiagnostics('term-record-shard-integrity-summary', summary);
        return summary;
    }

    /**
     * @param {Uint8Array} content
     * @returns {boolean}
     */
    _isBinaryFormat(content) {
        if (content.byteLength < BINARY_HEADER_PREFIX_BYTES) {
            return false;
        }
        const magic = this._textDecoder.decode(content.subarray(0, BINARY_MAGIC_BYTES));
        return magic === BINARY_MAGIC_TEXT;
    }

    /**
     * @param {string} value
     * @returns {{meta: number, bytes: Uint8Array|null}}
     * @throws {RangeError} If a custom dictionary name exceeds the persisted format limit.
     */
    _encodeEntryContentDictNameMeta(value) {
        switch (value) {
            case '':
            case 'raw':
                return {meta: ENTRY_CONTENT_DICT_NAME_CODE_RAW, bytes: null};
            case RAW_TERM_CONTENT_DICT_NAME:
                return {meta: ENTRY_CONTENT_DICT_NAME_CODE_RAW_V2, bytes: null};
            case RAW_TERM_CONTENT_SHARED_GLOSSARY_DICT_NAME:
                return {meta: ENTRY_CONTENT_DICT_NAME_CODE_RAW_V3, bytes: null};
            case RAW_TERM_CONTENT_COMPRESSED_SHARED_GLOSSARY_DICT_NAME:
                return {meta: ENTRY_CONTENT_DICT_NAME_CODE_RAW_V4, bytes: null};
            case 'jmdict':
                return {meta: ENTRY_CONTENT_DICT_NAME_CODE_JMDICT, bytes: null};
            case RAW_TERM_CONTENT_TOKEN_DICT_NAME:
                return {meta: ENTRY_CONTENT_DICT_NAME_CODE_RAW_V6, bytes: null};
            default: {
                const bytes = this._textEncoder.encode(value);
                if (bytes.byteLength > 0x00ffffff) {
                    throw new RangeError('Term-record content dictionary name exceeds the shard format limit');
                }
                return {meta: (((bytes.byteLength >>> 0) << 8) | ENTRY_CONTENT_DICT_NAME_CODE_CUSTOM) >>> 0, bytes};
            }
        }
    }

    /**
     * @param {Uint8Array} content
     * @param {number} offset
     * @param {number} length
     * @returns {string}
     */
    _decodeString(content, offset, length) {
        if (length <= 0) {
            return '';
        }
        const bytes = content.subarray(offset, offset + length);
        // Some browser TextDecoder implementations reject shared WASM views.
        // Copy only this string; ordinary buffers stay on the no-copy path.
        // Shared memory can exist without an exposed same-realm constructor.
        return this._textDecoder.decode(bytes.buffer instanceof ArrayBuffer ? bytes : Uint8Array.from(bytes));
    }

    /**
     * @param {string} value
     * @returns {string}
     */
    _reverseString(value) {
        let result = '';
        for (let i = value.length - 1; i >= 0; --i) {
            const c = value.charCodeAt(i);
            if (
                (c & 0xfc00) === 0xdc00 &&
                i > 0
            ) {
                const c2 = value.charCodeAt(i - 1);
                if ((c2 & 0xfc00) === 0xd800) {
                    result += value[i - 1] + value[i];
                    --i;
                    continue;
                }
            }
            result += value[i];
        }
        return result;
    }

    /**
     * @param {TermRecord[]} records
     * @param {import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan|null} [preinternedPlan]
     * @returns {Promise<{contentOffsetBase: number, lookupIndexBytes: Uint8Array, recordFields: Uint8Array, recordFieldsFormat: number}>}
     */
    async _encodeRecords(records, preinternedPlan = null) {
        if (records.length === 0) {
            return {
                contentOffsetBase: 0,
                lookupIndexBytes: new Uint8Array(0),
                recordFields: new Uint8Array(0),
                recordFieldsFormat: LOOKUP_INDEX_RECORD_FIELDS_FORMAT_LEGACY,
            };
        }
        const contentOffsetBase = getContentOffsetBase(records.map(({entryContentOffset}) => entryContentOffset));
        const useFloat64Scores = records.some(({score}) => !isLosslessInt32Score(score));
        const recordFieldsFormat = useFloat64Scores ?
            LOOKUP_INDEX_RECORD_FIELDS_FORMAT_FLOAT64_SCORE :
            LOOKUP_INDEX_RECORD_FIELDS_FORMAT_LEGACY;
        const recordFieldsBytesPerRow = useFloat64Scores ?
            FLOAT64_SCORE_RECORD_FIELDS_BYTES :
            LOOKUP_INDEX_RECORD_FIELDS_BYTES;
        const recordFields = new Uint8Array(records.length * recordFieldsBytesPerRow);
        const recordFieldsView = new DataView(recordFields.buffer);
        const readingEqualsExpressionList = new Uint8Array(records.length);
        const sequenceList = new Array(records.length);
        /** @type {Array<{expressionBytes: Uint8Array, readingBytes: Uint8Array|null, sequence: number|null}>|null} */
        const lookupRows = hasCompleteTermRecordPreinternedPlan(preinternedPlan, records.length) ? null : new Array(records.length);
        for (let i = 0; i < records.length; ++i) {
            const record = records[i];
            const {entryContentOffset, entryContentLength} = record;
            getContentOffsetDelta(entryContentOffset, contentOffsetBase);
            validateContentLength(entryContentLength);
            const expression = record.expression ?? '';
            const reading = record.reading ?? expression;
            const readingEqualsExpression = record.readingEqualsExpression ?? (reading === expression);
            const sequence = record.sequence ?? -1;
            const fieldOffset = i * recordFieldsBytesPerRow;
            recordFieldsView.setUint32(fieldOffset, getContentOffsetDelta(entryContentOffset, contentOffsetBase), true);
            recordFieldsView.setUint32(fieldOffset + 4, entryContentLength < 0 ? U32_NULL : entryContentLength, true);
            if (useFloat64Scores) {
                recordFieldsView.setFloat64(fieldOffset + 8, record.score, true);
            } else {
                recordFieldsView.setInt32(fieldOffset + 8, record.score, true);
            }
            readingEqualsExpressionList[i] = readingEqualsExpression ? 1 : 0;
            sequenceList[i] = sequence;
            if (lookupRows !== null) {
                lookupRows[i] = {
                    expressionBytes: record.expressionBytes instanceof Uint8Array ? record.expressionBytes : this._textEncoder.encode(expression),
                    readingBytes: readingEqualsExpression ?
                        null :
                        (
                            record.readingBytes instanceof Uint8Array ?
                                record.readingBytes :
                                this._textEncoder.encode(reading)
                        ),
                    sequence: sequence >= 0 ? sequence : null,
                };
            }
        }
        const lookupIndexBytes = lookupRows === null ?
            encodePersistedTermLookupIndexFromPreinternedPlan(
                /** @type {import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan} */ (preinternedPlan),
                readingEqualsExpressionList,
                sequenceList,
                records.length,
            ) :
            encodePersistedTermLookupIndex(lookupRows);
        return {
            contentOffsetBase,
            lookupIndexBytes,
            recordFields,
            recordFieldsFormat,
        };
    }

    /**
     * Encodes the hot artifact path as columnar random-access fields. Content
     * lengths use u16 and repeated scores use per-chunk u16 dictionary keys;
     * unusual chunks fall back to the legacy fixed-width rows.
     * @param {{rowCount: number, scoreList: number[]|Int32Array|Float64Array, fixedContentOffsetBase?: number, fixedContentLength?: number, resolvedContentReferences?: {uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}}} chunk
     * @param {number[]|Uint32Array|Float64Array} contentOffsets
     * @param {number[]|Uint32Array} contentLengths
     * @param {number} contentOffsetBase
     * @returns {Uint8Array}
     */
    _encodeArtifactRecordFields(chunk, contentOffsets, contentLengths, contentOffsetBase) {
        const count = chunk.rowCount;
        const useFixedContentSpan = hasFixedContentSpan(chunk, count);
        const offsets = new Uint32Array(count);
        const lengths = new Uint16Array(count);
        const scoreKeys = new Uint16Array(count);
        /** @type {number[]} */
        const scores = [];
        const useFloat64Scores = !(chunk.scoreList instanceof Int32Array) && chunk.scoreList.some((score) => !isLosslessInt32Score(score ?? 0));
        /** @type {Map<number, number>} */
        const scoreIndexes = new Map();
        if (useFloat64Scores) {
            const output = new Uint8Array(count * FLOAT64_SCORE_RECORD_FIELDS_BYTES);
            const view = new DataView(output.buffer);
            for (let i = 0; i < count; ++i) {
                const fieldOffset = i * FLOAT64_SCORE_RECORD_FIELDS_BYTES;
                const contentOffset = getArtifactContentOffset(chunk, contentOffsets, i, useFixedContentSpan);
                const contentLength = getArtifactContentLength(chunk, contentLengths, i);
                view.setUint32(fieldOffset, contentOffset < 0 ? U32_NULL : contentOffset - contentOffsetBase, true);
                view.setUint32(fieldOffset + 4, contentLength < 0 ? U32_NULL : contentLength, true);
                view.setFloat64(fieldOffset + 8, chunk.scoreList[i] ?? 0, true);
            }
            return output;
        }
        // Common integer scores use a bounded table. Store the key plus one
        // so zero can mark an unseen score without initializing the table.
        const inlineScoreIndexes = chunk.scoreList instanceof Int32Array && count >= COMPACT_SCORE_TABLE_MIN_ROWS ?
            new Uint16Array(COMPACT_SCORE_TABLE_RADIUS * 2) :
            null;
        let compact = true;
        for (let i = 0; i < count; ++i) {
            const contentOffset = getArtifactContentOffset(chunk, contentOffsets, i, useFixedContentSpan);
            const contentLength = getArtifactContentLength(chunk, contentLengths, i);
            if (contentLength >= U16_NULL) {
                compact = false;
                break;
            }
            offsets[i] = contentOffset < 0 ? U32_NULL : contentOffset - contentOffsetBase;
            lengths[i] = contentLength < 0 ? U16_NULL : contentLength;
            const score = chunk.scoreList[i] ?? 0;
            const inlineScore = score + COMPACT_SCORE_TABLE_RADIUS;
            const useInlineScore = inlineScoreIndexes !== null && inlineScore >= 0 && inlineScore < inlineScoreIndexes.length;
            let scoreIndex = useInlineScore ? inlineScoreIndexes[inlineScore] - 1 : (scoreIndexes.get(score) ?? -1);
            if (scoreIndex < 0) {
                scoreIndex = scores.length;
                if (scoreIndex >= U16_NULL) {
                    compact = false;
                    break;
                }
                if (useInlineScore) {
                    inlineScoreIndexes[inlineScore] = scoreIndex + 1;
                } else {
                    scoreIndexes.set(score, scoreIndex);
                }
                scores.push(score);
            }
            scoreKeys[i] = scoreIndex;
        }
        const compactByteLength = COMPACT_RECORD_FIELDS_HEADER_BYTES +
        (scores.length * 4) +
        (count * COMPACT_RECORD_FIELDS_BYTES_PER_ROW);
        if (
            !compact ||
            scores.length === 0 ||
            compactByteLength >= count * LOOKUP_INDEX_RECORD_FIELDS_BYTES
        ) {
            const legacy = new Uint8Array(count * LOOKUP_INDEX_RECORD_FIELDS_BYTES);
            const legacyU32 = new Uint32Array(legacy.buffer);
            const legacyI32 = new Int32Array(legacy.buffer);
            for (let i = 0; i < count; ++i) {
                const fieldOffset = i * 3;
                const contentOffset = getArtifactContentOffset(chunk, contentOffsets, i, useFixedContentSpan);
                const contentLength = getArtifactContentLength(chunk, contentLengths, i);
                legacyU32[fieldOffset] = contentOffset < 0 ? U32_NULL : contentOffset - contentOffsetBase;
                legacyU32[fieldOffset + 1] = contentLength < 0 ? U32_NULL : contentLength;
                legacyI32[fieldOffset + 2] = chunk.scoreList[i] ?? 0;
            }
            return legacy;
        }
        const output = new Uint8Array(compactByteLength);
        const header = new Uint32Array(output.buffer, 0, COMPACT_RECORD_FIELDS_HEADER_BYTES / 4);
        header[0] = COMPACT_RECORD_FIELDS_MAGIC;
        header[1] = count;
        header[2] = scores.length;
        header[3] = LOOKUP_INDEX_RECORD_FIELDS_FORMAT_COMPACT;
        let cursor = COMPACT_RECORD_FIELDS_HEADER_BYTES;
        new Int32Array(output.buffer, cursor, scores.length).set(scores);
        cursor += scores.length * 4;
        new Uint32Array(output.buffer, cursor, count).set(offsets);
        cursor += count * 4;
        new Uint16Array(output.buffer, cursor, count).set(lengths);
        cursor += count * 2;
        new Uint16Array(output.buffer, cursor, count).set(scoreKeys);
        return output;
    }

    /**
     * @param {{dictionary: string, rowCount: number, expressionBytesList: Uint8Array[], readingBytesList: Uint8Array[], readingEqualsExpressionList: boolean[]|Uint8Array, scoreList: number[]|Int32Array|Float64Array, sequenceList: (number|undefined)[]|Int32Array|Float64Array, fixedContentOffsetBase?: number, fixedContentLength?: number, resolvedContentReferences?: {uniqueIndexList: Uint32Array, offsets: Float64Array, lengths: Uint32Array}}} chunk
     * @param {number[]|Uint32Array|Float64Array} contentOffsets
     * @param {number[]|Uint32Array} contentLengths
     * @param {import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan|null} [preinternedPlan]
     * @param {Uint8Array|null} [preparedLookupIndexBytes=null]
     * @param {number|null} [validatedContentOffsetBase=null]
     * @returns {Promise<{contentOffsetBase: number, lookupIndexBytes: Uint8Array, recordFields: Uint8Array, recordFieldsFormat: number, validationMs: number, recordFieldEncodeMs: number, lookupIndexEncodeMs: number}>}
     */
    async _encodeArtifactChunkRecords(chunk, contentOffsets, contentLengths, preinternedPlan = null, preparedLookupIndexBytes = null, validatedContentOffsetBase = null) {
        if (chunk.rowCount === 0) {
            return {
                contentOffsetBase: 0,
                lookupIndexBytes: new Uint8Array(0),
                recordFields: new Uint8Array(0),
                recordFieldsFormat: LOOKUP_INDEX_RECORD_FIELDS_FORMAT_LEGACY,
                validationMs: 0,
                recordFieldEncodeMs: 0,
                lookupIndexEncodeMs: 0,
            };
        }
        const tValidationStart = safePerformance.now();
        let contentOffsetBase = validatedContentOffsetBase;
        if (contentOffsetBase === null) {
            contentOffsetBase = Number.POSITIVE_INFINITY;
            let maxContentOffset = Number.NEGATIVE_INFINITY;
            for (let i = 0; i < chunk.rowCount; ++i) {
                const contentOffset = getArtifactContentOffset(chunk, contentOffsets, i);
                const contentLength = getArtifactContentLength(chunk, contentLengths, i);
                validateContentOffset(contentOffset);
                validateContentLength(contentLength);
                if (contentOffset >= 0) {
                    contentOffsetBase = Math.min(contentOffsetBase, contentOffset);
                    maxContentOffset = Math.max(maxContentOffset, contentOffset);
                }
            }
            if (contentOffsetBase === Number.POSITIVE_INFINITY) { contentOffsetBase = 0; }
            getContentOffsetDelta(maxContentOffset, contentOffsetBase);
        }
        const validationMs = safePerformance.now() - tValidationStart;
        const tRecordEncodeStart = safePerformance.now();
        const recordFields = this._encodeArtifactRecordFields(
            chunk,
            contentOffsets,
            contentLengths,
            contentOffsetBase,
        );
        // Compact fields are strictly smaller than legacy fields; float64 fields
        // have their own fixed width. Infer the format from the emitted bytes
        // so the encoder remains the only owner of score representation.
        const recordFieldsFormat = recordFields.byteLength === chunk.rowCount * FLOAT64_SCORE_RECORD_FIELDS_BYTES ?
            LOOKUP_INDEX_RECORD_FIELDS_FORMAT_FLOAT64_SCORE :
            (recordFields.byteLength === chunk.rowCount * LOOKUP_INDEX_RECORD_FIELDS_BYTES ?
                LOOKUP_INDEX_RECORD_FIELDS_FORMAT_LEGACY :
                LOOKUP_INDEX_RECORD_FIELDS_FORMAT_COMPACT);
        const recordFieldEncodeMs = safePerformance.now() - tRecordEncodeStart;
        const tLookupIndexEncodeStart = safePerformance.now();
        let lookupIndexBytes = preparedLookupIndexBytes;
        if (lookupIndexBytes === null) {
            lookupIndexBytes = hasCompleteTermRecordPreinternedPlan(preinternedPlan, chunk.rowCount) ?
                encodePersistedTermLookupIndexFromPreinternedPlan(
                    /** @type {import('./term-record-preinterned-plan.js').PreinternedTermRecordPlan} */ (preinternedPlan),
                    chunk.readingEqualsExpressionList,
                    chunk.sequenceList,
                    chunk.rowCount,
                ) :
                encodePersistedTermLookupIndex(Array.from({length: chunk.rowCount}, (_, i) => {
                    const readingEqualsExpression = chunk.readingEqualsExpressionList[i] === true || chunk.readingEqualsExpressionList[i] === 1;
                    const sequence = chunk.sequenceList[i];
                    return {
                        expressionBytes: chunk.expressionBytesList[i],
                        readingBytes: readingEqualsExpression ? null : chunk.readingBytesList[i],
                        sequence: typeof sequence === 'number' && sequence >= 0 ? sequence : null,
                    };
                }));
        }
        return {
            contentOffsetBase,
            lookupIndexBytes,
            recordFields,
            recordFieldsFormat,
            validationMs,
            recordFieldEncodeMs,
            lookupIndexEncodeMs: preparedLookupIndexBytes === null ? safePerformance.now() - tLookupIndexEncodeStart : 0,
        };
    }

    /**
     * @param {TermRecordShardState} state
     * @param {number} firstId
     * @param {number} count
     * @param {string|null} [contentDictNameOverride=null]
     * @param {number} contentOffsetBase
     * @param {Uint8Array|null} [lookupIndexBytes=null]
     * @param {Uint8Array|null} [recordFields=null]
     * @param {number} [recordFieldsFormat=LOOKUP_INDEX_RECORD_FIELDS_FORMAT_LEGACY]
     * @returns {Promise<void>}
     */
    async _appendEncodedChunk(
        state,
        firstId,
        count,
        contentDictNameOverride = null,
        contentOffsetBase = 0,
        lookupIndexBytes = null,
        recordFields = null,
        recordFieldsFormat = LOOKUP_INDEX_RECORD_FIELDS_FORMAT_LEGACY,
    ) {
        if (count <= 0) { return; }
        await this._validateShardAppendFormat(state);
        if (state.queuedWriteError !== null) { throw state.queuedWriteError; }
        if (state.lookupIndexWriteError !== null) { throw state.lookupIndexWriteError; }
        const firstRecord = this._recordsById.get(firstId) ?? null;
        const contentDictName = contentDictNameOverride ?? firstRecord?.entryContentDictName ?? 'raw';
        if (state.sharedContentDictName === null) {
            state.sharedContentDictName = contentDictName;
        } else if (state.sharedContentDictName !== contentDictName) {
            throw new Error(`Mixed entryContentDictName values are not supported within shard ${state.fileName}`);
        }

        /** @type {Uint8Array|null} */
        const binaryHeader = state.fileLength === 0 ?
            this._createBinaryHeader(state.sharedContentDictName, state.generationId) :
            null;
        const chunks = binaryHeader === null ? [] : [binaryHeader];
        let totalBytes = 0;
        for (const pendingChunk of chunks) {
            totalBytes += pendingChunk.byteLength;
        }
        state.pendingWriteChunks.push(...chunks);
        state.pendingWriteBytes += totalBytes;
        state.fileLength += totalBytes;
        if (
            state.initialFileLength === 0 &&
            lookupIndexBytes instanceof Uint8Array &&
            lookupIndexBytes.byteLength > 0
        ) {
            const lookupIndexChunk = this._createLookupIndexChunk(
                firstId,
                count,
                contentOffsetBase,
                lookupIndexBytes,
                recordFields,
                recordFieldsFormat,
            );
            state.pendingLookupIndexChunks.push(lookupIndexChunk);
            state.pendingLookupIndexBytes += lookupIndexChunk.byteLength;
            state.pendingLookupIndexRecordCount += count;
            if (state.pendingLookupIndexBytes >= LOOKUP_INDEX_FLUSH_THRESHOLD_BYTES) {
                await this._flushPendingLookupIndexChunks(state, !this._importSessionActive);
            } else if (
                this._importSessionActive &&
                state.lookupIndexChunkCount === 0 &&
                state.lookupIndexWritePromise === null &&
                state.pendingLookupIndexBytes >= EAGER_IMPORT_LOOKUP_INDEX_WRITE_START_BYTES
            ) {
                await this._flushPendingLookupIndexChunks(state, false);
            }
        }

        if (
            !this._importSessionActive ||
            state.pendingWriteBytes >= this._flushThresholdBytes
        ) {
            await this._flushPendingWritesForShard(state);
            if (!this._importSessionActive) {
                await this._closeShardWritable(state);
            }
        }
    }

    /**
     * @param {string} [contentDictName]
     * @param {Uint8Array} [generationId]
     * @returns {Uint8Array}
     * @throws {Error} If the generation ID or dictionary metadata is invalid.
     */
    _createBinaryHeader(contentDictName = 'raw', generationId = this._createShardGenerationId()) {
        const header = this._textEncoder.encode(BINARY_MAGIC_TEXT);
        if (!(generationId instanceof Uint8Array) || generationId.byteLength !== SHARD_GENERATION_BYTES) {
            throw new Error('Invalid term-record shard generation ID');
        }
        const {meta: entryContentDictNameMeta, bytes: entryContentDictNameBytes} = this._encodeEntryContentDictNameMeta(contentDictName);
        const hasExtendedMeta = entryContentDictNameMeta > ENTRY_CONTENT_DICT_NAME_VALUE_MASK;
        const output = new Uint8Array(
            header.byteLength +
            SHARD_GENERATION_BYTES +
            2 +
            (hasExtendedMeta ? 4 : 0) +
            (entryContentDictNameBytes?.byteLength ?? 0),
        );
        output.set(header, 0);
        output.set(generationId, header.byteLength);
        const view = new DataView(output.buffer, output.byteOffset, output.byteLength);
        let cursor = BINARY_HEADER_PREFIX_BYTES;
        if (hasExtendedMeta) {
            view.setUint16(cursor, U16_NULL, true); cursor += 2;
            view.setUint32(cursor, entryContentDictNameMeta >>> 0, true); cursor += 4;
        } else {
            view.setUint16(cursor, entryContentDictNameMeta >>> 0, true); cursor += 2;
        }
        if (entryContentDictNameBytes !== null) {
            output.set(entryContentDictNameBytes, cursor);
        }
        return output;
    }

    /** @returns {Uint8Array} */
    _createShardGenerationId() {
        const generationId = new Uint8Array(SHARD_GENERATION_BYTES);
        const crypto = globalThis.crypto;
        if (typeof crypto?.getRandomValues === 'function') {
            crypto.getRandomValues(generationId);
            return generationId;
        }
        for (let i = 0; i < generationId.length; ++i) {
            generationId[i] = Math.floor(Math.random() * 256);
        }
        return generationId;
    }

    /**
     * @param {number} firstId
     * @param {number} count
     * @param {number} contentOffsetBase
     * @param {Uint8Array} payload
     * @param {Uint8Array|null} recordFields
     * @param {number} [recordFieldsFormat=LOOKUP_INDEX_RECORD_FIELDS_FORMAT_LEGACY]
     * @returns {Uint8Array}
     * @throws {Error} If the authoritative fields do not match the declared record count.
     */
    _createLookupIndexChunk(
        firstId,
        count,
        contentOffsetBase,
        payload,
        recordFields,
        recordFieldsFormat = LOOKUP_INDEX_RECORD_FIELDS_FORMAT_LEGACY,
    ) {
        if (!(recordFields instanceof Uint8Array)) {
            throw new Error('Invalid authoritative term-record fields');
        }
        if (
            getRecordFieldsByteLength(recordFields, 0, count, recordFieldsFormat) !== recordFields.byteLength
        ) {
            throw new Error('Invalid authoritative term-record fields');
        }
        validateRecordFields(recordFields, count, recordFieldsFormat, contentOffsetBase);
        const {base, derived} = splitPersistedTermLookupIndex(payload);
        const output = new Uint8Array(
            LOOKUP_INDEX_CHUNK_HEADER_BYTES +
            payload.byteLength +
            recordFields.byteLength,
        );
        const view = new DataView(output.buffer, output.byteOffset, output.byteLength);
        view.setUint32(0, firstId, true);
        view.setUint32(4, count, true);
        writeSafeU64Le(view, 8, contentOffsetBase);
        view.setUint32(16, payload.byteLength, true);
        view.setUint32(20, base.byteLength, true);
        view.setUint32(24, hashLookupIndexBytes(base), true);
        view.setUint32(28, hashLookupIndexBytes(derived), true);
        view.setUint32(32, hashLookupIndexBytes(recordFields), true);
        view.setUint32(36, recordFieldsFormat, true);
        output.set(payload, LOOKUP_INDEX_CHUNK_HEADER_BYTES);
        output.set(recordFields, LOOKUP_INDEX_CHUNK_HEADER_BYTES + payload.byteLength);
        return output;
    }

    /**
     * @param {TermRecordShardState} state
     * @returns {Promise<void>}
     */
    async _flushLookupIndexFile(state) {
        if (
            (
                state.pendingLookupIndexChunks.length === 0 &&
                state.lookupIndexWritable === null &&
                state.lookupIndexWritePromise === null
            ) ||
            this._recordsDirectoryHandle === null
        ) {
            return;
        }
        const indexFileName = `${state.fileName}${LOOKUP_INDEX_FILE_SUFFIX}`;
        if (state.initialFileLength !== 0) {
            // Appending to an existing descriptor invalidates the previous
            // sidecar's descriptor-length metadata. Do not leave a stale
            // authoritative container behind when unlink is blocked.
            await this._removeStorageFileOrTruncate(indexFileName, true);
            state.pendingLookupIndexChunks = [];
            state.pendingLookupIndexBytes = 0;
            state.pendingLookupIndexRecordCount = 0;
            return;
        }
        /** @type {Error|null} */
        let operationError = null;
        try {
            await this._flushPendingLookupIndexChunks(state, true);
            const writable = state.lookupIndexWritable;
            if (writable !== null) {
                const header = new Uint8Array(LOOKUP_INDEX_FILE_HEADER_BYTES);
                header.set(this._textEncoder.encode(LOOKUP_INDEX_MAGIC_TEXT), 0);
                const view = new DataView(header.buffer, header.byteOffset, header.byteLength);
                writeSafeU64Le(view, 8, state.fileLength);
                view.setUint32(16, state.lookupIndexChunkCount, true);
                view.setUint32(20, state.lookupIndexRecordCount, true);
                header.set(state.generationId, 24);
                await writable.seek(0);
                await writable.write(header);
            }
        } catch (error) {
            operationError = error instanceof Error ? error : new Error(String(error));
        }
        /** @type {Error|null} */
        let closeError = null;
        const writable = state.lookupIndexWritable;
        if (writable !== null) {
            try {
                await writable.close();
            } catch (error) {
                closeError = error instanceof Error ? error : new Error(String(error));
            } finally {
                state.lookupIndexWritable = null;
            }
        }
        state.lookupIndexFileHandle = null;
        if (operationError !== null && closeError !== null) {
            throw new AggregateError(
                [operationError, closeError],
                `Failed to finalize term-record lookup index ${indexFileName}`,
            );
        }
        if (operationError !== null) { throw operationError; }
        if (closeError !== null) { throw closeError; }
        state.pendingLookupIndexChunks = [];
        state.pendingLookupIndexBytes = 0;
        state.pendingLookupIndexRecordCount = 0;
        state.lookupIndexChunkCount = 0;
        state.lookupIndexRecordCount = 0;
    }

    /**
     * @param {TermRecordShardState} state
     * @param {boolean} [waitForCompletion=true]
     * @returns {Promise<void>}
     */
    async _flushPendingLookupIndexChunks(state, waitForCompletion = true) {
        if (state.lookupIndexWriteError !== null) {
            throw state.lookupIndexWriteError;
        }
        if (state.pendingLookupIndexChunks.length === 0 || this._recordsDirectoryHandle === null) {
            if (waitForCompletion) {
                await this._awaitLookupIndexWritesForShard(state);
            }
            return;
        }
        const chunks = state.pendingLookupIndexChunks;
        const recordCount = state.pendingLookupIndexRecordCount;
        const byteLength = state.pendingLookupIndexBytes;
        state.pendingLookupIndexChunks = [];
        state.pendingLookupIndexBytes = 0;
        state.pendingLookupIndexRecordCount = 0;
        const previousWrite = state.lookupIndexWritePromise ?? Promise.resolve();
        state.lookupIndexQueuedBytes += byteLength;
        state.lookupIndexMaxQueuedBytes = Math.max(state.lookupIndexMaxQueuedBytes, state.lookupIndexQueuedBytes);
        this._lookupIndexWriteMetrics.maxQueuedBytes = Math.max(
            this._lookupIndexWriteMetrics.maxQueuedBytes,
            state.lookupIndexMaxQueuedBytes,
        );
        const writePromise = previousWrite
            .then(async () => {
                if (state.lookupIndexWritable === null) {
                    const indexFileName = `${state.fileName}${LOOKUP_INDEX_FILE_SUFFIX}`;
                    state.lookupIndexFileHandle = await this._recordsDirectoryHandle?.getFileHandle(indexFileName, {create: true}) ?? null;
                    if (state.lookupIndexFileHandle === null) {
                        throw new Error('Term-record lookup index directory became unavailable during import');
                    }
                    state.lookupIndexWritable = await this._createLookupIndexWritable(state);
                    await state.lookupIndexWritable.write(new Uint8Array(LOOKUP_INDEX_FILE_HEADER_BYTES));
                }
                await (state.lookupIndexWritable instanceof SyncImportIndexWriter ? state.lookupIndexWritable.writeChunks(chunks) : state.lookupIndexWritable.write(new Blob(chunks)));
                ++this._lookupIndexWriteMetrics.writeCallCount;
                this._lookupIndexWriteMetrics.writeBytes += byteLength;
                state.lookupIndexChunkCount += chunks.length;
                state.lookupIndexRecordCount += recordCount;
            })
            .catch((error) => {
                state.lookupIndexWriteError = error instanceof Error ? error : new Error(String(error));
                throw state.lookupIndexWriteError;
            })
            .finally(() => {
                state.lookupIndexQueuedBytes = Math.max(0, state.lookupIndexQueuedBytes - byteLength);
            });
        state.lookupIndexWritePromise = writePromise;
        void writePromise.catch(() => {});
        if (waitForCompletion || state.lookupIndexQueuedBytes >= this._queuedWriteBudgetBytes) {
            await this._awaitLookupIndexWritesForShard(state);
        }
    }

    /**
     * Creates and initializes a fresh lookup-index writer by truncating it to zero bytes.
     * The synchronous opener owns its access-handle truncation; the fallback is truncated here.
     * @param {TermRecordShardState} state
     * @returns {Promise<FileSystemWritableFileStream|SyncImportIndexWriter>}
     */
    async _createLookupIndexWritable(state) {
        const fileHandle = state.lookupIndexFileHandle;
        if (fileHandle === null) { throw new Error('Term-record lookup index file handle is unavailable'); }
        if (this._importSessionActive && state.initialFileLength === 0) {
            const writer = await openSyncImportIndexWriter(/** @type {Parameters<typeof openSyncImportIndexWriter>[0]} */ (/** @type {unknown} */ (fileHandle)));
            if (writer !== null) { return writer; }
        }
        const writable = await fileHandle.createWritable();
        try {
            await writable.truncate(0);
        } catch (error) {
            try {
                await writable.abort();
            } catch (abortError) {
                throw new AggregateError([error, abortError], 'Failed to initialize asynchronous import index writer');
            }
            throw error;
        }
        return writable;
    }

    /**
     * @param {TermRecordShardState} state
     * @returns {Promise<void>}
     */
    async _awaitLookupIndexWritesForShard(state) {
        if (state.lookupIndexWriteError !== null) {
            throw state.lookupIndexWriteError;
        }
        const writePromise = state.lookupIndexWritePromise;
        if (writePromise === null) { return; }
        const startedAt = safePerformance.now();
        try {
            await writePromise;
        } finally {
            this._lookupIndexWriteMetrics.awaitMs += safePerformance.now() - startedAt;
            if (state.lookupIndexWritePromise === writePromise && state.lookupIndexWriteError === null) {
                state.lookupIndexWritePromise = null;
            }
        }
    }

    /**
     * @returns {Promise<void>}
     */
    async _flushPendingWrites() {
        if (this._shardStateByFileName.size === 0) {
            return;
        }
        for (const state of this._shardStateByFileName.values()) {
            await this._flushPendingWritesForShard(state);
        }
    }

    /**
     * @returns {Promise<void>}
     */
    async _awaitQueuedWrites() {
        if (this._shardStateByFileName.size === 0) {
            return;
        }
        for (const state of this._shardStateByFileName.values()) {
            await this._awaitQueuedWritesForShard(state);
        }
    }

    /**
     * @returns {Promise<void>}
     */
    async _closeAllWritables() {
        /** @type {Error[]} */
        const errors = [];
        for (const state of this._shardStateByFileName.values()) {
            const results = await Promise.allSettled([
                this._finalizeShardWritable(state),
                this._flushLookupIndexFile(state),
            ]);
            for (const result of results) {
                if (result.status === 'fulfilled') { continue; }
                errors.push(
                    result.reason instanceof Error ?
                        result.reason :
                        new Error(String(result.reason)),
                );
            }
        }
        if (errors.length === 1) {
            throw errors[0];
        }
        if (errors.length > 1) {
            throw new AggregateError(errors, 'Failed to finalize term-record storage');
        }
    }

    /**
     * @param {TermRecordShardState} state
     * @returns {Promise<void>}
     */
    async _finalizeShardWritable(state) {
        /** @type {Error[]} */
        const errors = [];
        try {
            await this._awaitQueuedWritesForShard(state);
        } catch (error) {
            errors.push(error instanceof Error ? error : new Error(String(error)));
        }
        try {
            await this._closeShardWritable(state);
        } catch (error) {
            errors.push(error instanceof Error ? error : new Error(String(error)));
        }
        if (errors.length === 1) {
            throw errors[0];
        }
        if (errors.length > 1) {
            throw new AggregateError(
                errors,
                `Failed to finalize term-record file ${state.fileName}`,
            );
        }
    }

    /**
     * @param {TermRecordShardState} state
     * @returns {Promise<void>}
     */
    async _closeShardWritable(state) {
        if (state.writable === null) {
            return;
        }
        try {
            await state.writable.close();
        } catch (error) {
            if (!this._isClosingWritableStreamError(error)) {
                throw error;
            }
        } finally {
            state.writable = null;
        }
    }

    /**
     * @param {unknown} error
     * @returns {boolean}
     */
    _isClosingWritableStreamError(error) {
        const message = (error instanceof Error) ? error.message : String(error);
        return (
            message.includes('closing writable stream') ||
            message.includes('closed or closing stream')
        );
    }

    /**
     * @param {TermRecordShardState} state
     * @param {number} seekOffset
     * @returns {Promise<void>}
     */
    async _reopenShardWritable(state, seekOffset) {
        state.writable = await state.fileHandle.createWritable({keepExistingData: true});
        await state.writable.seek(Math.max(0, seekOffset));
    }

    /**
     * @param {boolean} materializeRecords
     * @returns {Promise<number>}
     */
    async _loadShardFiles(materializeRecords = true) {
        if (this._recordsDirectoryHandle === null) {
            return 0;
        }
        const entriesMethod = /** @type {unknown} */ (Reflect.get(this._recordsDirectoryHandle, 'entries'));
        if (typeof entriesMethod !== 'function') {
            return 0;
        }
        const entries = /** @type {() => AsyncIterable<[string, FileSystemHandle]>} */ (entriesMethod).call(this._recordsDirectoryHandle);
        /** @type {Map<string, FileSystemFileHandle>} */
        const fileHandlesByName = new Map();
        for await (const entry of entries) {
            const name = String(entry[0] ?? '');
            const fileSystemHandle = /** @type {FileSystemHandle} */ (/** @type {unknown} */ (entry[1]));
            if (fileSystemHandle.kind === 'file') {
                fileHandlesByName.set(name, /** @type {FileSystemFileHandle} */ (fileSystemHandle));
            }
        }
        for (const name of fileHandlesByName.keys()) {
            if (
                (this._isShardFileName(name) || name.endsWith(`${SHARD_FILE_SUFFIX}${LOOKUP_INDEX_FILE_SUFFIX}`)) &&
                !this._isCanonicalTermRecordStorageFileName(name)
            ) {
                throw new Error(`Invalid term-record storage file name: ${name}`);
            }
        }
        await this._recoverMissingDescriptors(fileHandlesByName);
        let shardFileCount = 0;
        /** @type {Array<{state: TermRecordShardState, file: File}>} */
        const statesToMaterialize = [];
        for (const [name, fileHandle] of fileHandlesByName) {
            if (!this._isShardFileName(name)) { continue; }
            // Reprepare/rescans must not adopt bytes left by a failed deletion.
            const dictionaryName = this._decodeDictionaryNameFromShardFileName(name);
            if (dictionaryName !== null && this._pendingDictionaryDeletionNames.has(dictionaryName)) { continue; }
            let file = null;
            for (let attempt = 0; attempt < STORAGE_READ_RETRY_COUNT && file === null; ++attempt) {
                try {
                    file = await fileHandle.getFile();
                } catch (_) {
                    if ((attempt + 1) < STORAGE_READ_RETRY_COUNT) {
                        await new Promise((resolve) => { setTimeout(resolve, 0); });
                    }
                }
            }
            ++shardFileCount;
            const shardInfo = this._decodeShardInfoFromShardFileName(name);
            const state = this._createShardState(
                name,
                fileHandle,
                file?.size ?? 1,
                shardInfo?.contentDictName ?? null,
                shardInfo?.segmentIndex ?? 0,
                shardInfo === null ? name : this._getShardFileName(shardInfo.dictionaryName, shardInfo.contentDictName),
            );
            this._shardStateByFileName.set(name, state);
            this._setActiveAppendShardState(state);
            if (!materializeRecords || file === null || file.size <= 0) {
                continue;
            }
            statesToMaterialize.push({state, file});
        }
        if (statesToMaterialize.length > 0) {
            await this._loadShardStatesContents(statesToMaterialize);
        }
        return shardFileCount;
    }

    /**
     * Recreates missing descriptor files only from finalized authoritative
     * containers. Existing descriptors are never replaced here: a temporary
     * descriptor read failure must remain a retryable storage failure.
     * @param {Map<string, FileSystemFileHandle>} fileHandlesByName
     * @returns {Promise<void>}
     */
    async _recoverMissingDescriptors(fileHandlesByName) {
        if (this._recordsDirectoryHandle === null) { return; }
        for (const [indexFileName, indexFileHandle] of fileHandlesByName) {
            if (!indexFileName.endsWith(`${SHARD_FILE_SUFFIX}${LOOKUP_INDEX_FILE_SUFFIX}`)) { continue; }
            const descriptorFileName = indexFileName.slice(0, -LOOKUP_INDEX_FILE_SUFFIX.length);
            if (!this._isShardFileName(descriptorFileName)) { continue; }
            const dictionaryName = this._decodeDictionaryNameFromShardFileName(descriptorFileName);
            if (dictionaryName !== null && this._pendingDictionaryDeletionNames.has(dictionaryName)) { continue; }
            let descriptorFileHandle = fileHandlesByName.get(descriptorFileName) ?? null;
            if (descriptorFileHandle !== null) {
                try {
                    if ((await descriptorFileHandle.getFile()).size > 0) { continue; }
                } catch (_) {
                    // Preserve the existing retryable behavior for a descriptor
                    // whose current contents cannot be inspected.
                    continue;
                }
            }
            const shardInfo = this._decodeShardInfoFromShardFileName(descriptorFileName);
            if (shardInfo === null) { continue; }
            try {
                const indexFile = await indexFileHandle.getFile();
                if (indexFile.size < LOOKUP_INDEX_FILE_HEADER_BYTES) { continue; }
                const header = await this._readFileRange(indexFile, 0, LOOKUP_INDEX_FILE_HEADER_BYTES);
                if (header.byteLength !== LOOKUP_INDEX_FILE_HEADER_BYTES) { continue; }
                if (this._textDecoder.decode(header.subarray(0, LOOKUP_INDEX_MAGIC_BYTES)) !== LOOKUP_INDEX_MAGIC_TEXT) {
                    continue;
                }
                const view = new DataView(header.buffer, header.byteOffset, header.byteLength);
                // Invalid metadata is dictionary-local; only failed I/O should
                // leave this scan incomplete and block startup verification.
                const expectedDescriptorLength = view.getUint32(8, true) + (view.getUint32(12, true) * U32_RANGE);
                if (!Number.isSafeInteger(expectedDescriptorLength)) { continue; }
                if (view.getUint32(16, true) === 0 || view.getUint32(20, true) === 0) { continue; }
                const generationId = new Uint8Array(header.subarray(24, LOOKUP_INDEX_FILE_HEADER_BYTES));
                const descriptor = this._createBinaryHeader(shardInfo.contentDictName, generationId);
                if (descriptor.byteLength !== expectedDescriptorLength) { continue; }
                descriptorFileHandle ??= await this._recordsDirectoryHandle.getFileHandle(descriptorFileName, {create: true});
                const writable = await descriptorFileHandle.createWritable();
                try {
                    await writable.truncate(0);
                    await writable.write(descriptor);
                    await writable.close();
                } catch (error) {
                    const abort = Reflect.get(writable, 'abort');
                    if (typeof abort === 'function') {
                        try {
                            await /** @type {() => Promise<void>} */ (abort).call(writable);
                        } catch (_) {
                            // Preserve the descriptor recovery failure.
                        }
                    }
                    throw error;
                }
                fileHandlesByName.set(descriptorFileName, descriptorFileHandle);
                reportDiagnostics('term-record-descriptor-recovered', {
                    descriptorFileName,
                    indexFileName,
                });
            } catch (error) {
                reportDiagnostics('term-record-descriptor-recovery-failed', {
                    descriptorFileName,
                    indexFileName,
                    error: error instanceof Error ? error.message : String(error),
                });
                // An incomplete scan must not let startup persist a missing-data
                // verdict for a container whose recovery failed transiently.
                throw error;
            }
        }
    }

    /**
     * @param {TermRecordShardState} state
     * @param {File|null} [existingFile=null]
     * @returns {Promise<boolean>}
     */
    async _loadShardStateContents(state, existingFile = null) {
        let file = existingFile;
        if (file === null) {
            try {
                file = await state.fileHandle.getFile();
            } catch (_) {
                return false;
            }
        }
        state.fileLength = file.size;
        if (file.size <= 0) {
            return false;
        }
        let header = new Uint8Array(0);
        if (file.size >= BINARY_HEADER_PREFIX_BYTES) {
            try {
                header = await this._readFileRange(file, 0, BINARY_HEADER_PREFIX_BYTES);
            } catch (_) {
                return false;
            }
        }
        const dictionaryName = this._decodeDictionaryNameFromShardFileName(state.fileName);
        if (this._isBinaryFormat(header) && dictionaryName !== null) {
            if (!await this._tryLoadPersistentDictionaryIndex(dictionaryName)) { return false; }
            const chunks = (this._persistentRecordChunksByDictionary.get(dictionaryName) ?? [])
                .filter((chunk) => chunk.fileName === state.fileName);
            const recordCount = chunks.reduce((sum, chunk) => sum + chunk.count, 0);
            if (recordCount === 0 || recordCount >= PERSISTED_ONLY_IMPORT_ROW_THRESHOLD) { return recordCount > 0; }
            const ids = new Array(recordCount);
            let cursor = 0;
            for (const chunk of chunks) {
                for (let id = chunk.firstId; id < chunk.firstId + chunk.count; ++id) {
                    ids[cursor++] = id;
                }
            }
            return (await this.getByIdsAsync(ids)).size === recordCount;
        }
        await this._discardInvalidShardState(state);
        if (dictionaryName !== null) {
            this.markDictionaryReimportRequired(dictionaryName, 'Dictionary record data is damaged');
        }
        return false;
    }

    /**
     * @param {TermRecordShardState} state
     * @returns {Promise<void>}
     */
    async _discardInvalidShardState(state) {
        if (!this._invalidShardFileNames.includes(state.fileName)) {
            this._invalidShardFileNames.push(state.fileName);
        }
        if (this._recordsDirectoryHandle !== null) {
            try {
                await this._closeShardWritable(state);
                await this._removeStorageFileOrTruncate(state.fileName, true);
                await this._removeStorageFileOrTruncate(`${state.fileName}${LOOKUP_INDEX_FILE_SUFFIX}`, true);
            } catch (error) {
                // Keep the invalid state registered so deletion/reimport can
                // retry cleanup instead of appending to a hidden stale file.
                reportDiagnostics('term-record-invalid-shard-cleanup-failed', {
                    fileName: state.fileName,
                    error: error instanceof Error ? error.message : String(error),
                });
                return;
            }
        }
        this._shardStateByFileName.delete(state.fileName);
        this._activeAppendShardStateByKey.delete(state.logicalKey);
    }

    /**
     * @param {Array<{state: TermRecordShardState, file: File}>} states
     * @returns {Promise<void>}
     */
    async _loadShardStatesContents(states) {
        if (states.length === 0) {
            return;
        }
        let nextIndex = 0;
        const workerCount = Math.min(SHARD_LOAD_CONCURRENCY, states.length);
        const workers = [];
        for (let i = 0; i < workerCount; ++i) {
            workers.push((async () => {
                while (nextIndex < states.length) {
                    const {state, file} = states[nextIndex++];
                    await this._loadShardStateContents(state, file);
                }
            })());
        }
        await Promise.all(workers);
    }

    /**
     * Lists logical shard pairs, including an index-only orphan whose descriptor
     * is currently missing. Startup can recover such a descriptor from the
     * lookup index, so cleanup must treat the pair as live storage identity.
     * @returns {Promise<Array<{descriptorFileName: string, hasDescriptor: boolean, hasIndex: boolean}>>}
     */
    async _listShardStorageFiles() {
        const storageFileNames = await this._listTermRecordStorageFileNames();
        /** @type {Map<string, {descriptorFileName: string, hasDescriptor: boolean, hasIndex: boolean}>} */
        const byDescriptor = new Map();
        for (const storageFileName of storageFileNames) {
            const isIndex = storageFileName.endsWith(`${SHARD_FILE_SUFFIX}${LOOKUP_INDEX_FILE_SUFFIX}`);
            const descriptorFileName = isIndex ?
                storageFileName.slice(0, -LOOKUP_INDEX_FILE_SUFFIX.length) :
                storageFileName;
            if (!this._isShardFileName(descriptorFileName)) { continue; }
            let pair = byDescriptor.get(descriptorFileName);
            if (typeof pair === 'undefined') {
                pair = {descriptorFileName, hasDescriptor: false, hasIndex: false};
                byDescriptor.set(descriptorFileName, pair);
            }
            if (isIndex) {
                pair.hasIndex = true;
            } else {
                pair.hasDescriptor = true;
            }
        }
        return [...byDescriptor.values()];
    }

    /**
     * @returns {Promise<string[]>}
     */
    async _listTermRecordStorageFileNames() {
        if (this._recordsDirectoryHandle === null) { return []; }
        const entriesMethod = /** @type {unknown} */ (Reflect.get(this._recordsDirectoryHandle, 'entries'));
        if (typeof entriesMethod !== 'function') { return []; }
        const entries = /** @type {() => AsyncIterable<[string, FileSystemHandle]>} */ (entriesMethod).call(this._recordsDirectoryHandle);
        const names = [];
        for await (const entry of entries) {
            const name = String(entry[0] ?? '');
            const fileSystemHandle = /** @type {FileSystemHandle} */ (/** @type {unknown} */ (entry[1]));
            if (
                fileSystemHandle.kind === 'file' &&
                (this._isShardFileName(name) || name.endsWith(`${SHARD_FILE_SUFFIX}${LOOKUP_INDEX_FILE_SUFFIX}`))
            ) {
                names.push(name);
            }
        }
        return names;
    }

    /**
     * @returns {boolean}
     */
    _hasPendingShardWrites() {
        for (const state of this._shardStateByFileName.values()) {
            if (
                state.writable !== null ||
                state.pendingWriteBytes > 0 ||
                state.pendingWriteChunks.length > 0 ||
                state.pendingLookupIndexChunks.length > 0 ||
                state.lookupIndexWritable !== null ||
                state.lookupIndexWritePromise !== null
            ) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param {string} dictionaryName
     * @param {string} [contentDictName='raw']
     * @returns {Promise<TermRecordShardState|null>}
     */
    async _getOrCreateShardState(dictionaryName, contentDictName = 'raw') {
        this._registerDictionaryMutation(dictionaryName);
        if (this._recordsDirectoryHandle === null) {
            return null;
        }
        const normalizedContentDictName = this._normalizeContentDictName(contentDictName);
        const logicalKey = this._getShardFileName(dictionaryName, normalizedContentDictName);
        this._assertShardAcceptsAppend(dictionaryName, normalizedContentDictName);
        const existing = this._activeAppendShardStateByKey.get(logicalKey);
        if (typeof existing !== 'undefined') {
            if (existing.fileLength < MAX_SHARD_SEGMENT_FILE_BYTES) {
                return existing;
            }
            const nextSegmentIndex = existing.segmentIndex + 1;
            const nextFileName = this._getShardSegmentFileName(dictionaryName, normalizedContentDictName, nextSegmentIndex);
            const nextFileHandle = await this._recordsDirectoryHandle.getFileHandle(nextFileName, {create: true});
            const created = this._createShardState(
                nextFileName,
                nextFileHandle,
                this._importSessionActive ? 0 : (await nextFileHandle.getFile()).size,
                normalizedContentDictName,
                nextSegmentIndex,
                logicalKey,
            );
            this._shardStateByFileName.set(nextFileName, created);
            this._activeAppendShardStateByKey.set(logicalKey, created);
            return created;
        }
        const fileName = this._getShardSegmentFileName(dictionaryName, normalizedContentDictName, 0);
        const fileHandle = await this._recordsDirectoryHandle.getFileHandle(fileName, {create: true});
        const created = this._createShardState(
            fileName,
            fileHandle,
            this._importSessionActive ? 0 : (await fileHandle.getFile()).size,
            normalizedContentDictName,
            0,
            logicalKey,
        );
        this._shardStateByFileName.set(fileName, created);
        this._activeAppendShardStateByKey.set(logicalKey, created);
        return created;
    }

    /**
     * @param {string} dictionaryName
     * @param {string} [contentDictName='raw']
     * @throws {Error} If the target is an immutable finalized container.
     */
    _assertShardAcceptsAppend(dictionaryName, contentDictName = 'raw') {
        if (this._pendingDictionaryDeletionNames.has(dictionaryName)) {
            throw new Error(`Cannot append to retired term records until deletion cleanup succeeds: ${dictionaryName}`);
        }
        const logicalKey = this._getShardFileName(dictionaryName, contentDictName);
        const state = this._activeAppendShardStateByKey.get(logicalKey);
        if (typeof state === 'undefined') { return; }
        if (state.queuedWriteError !== null) { throw state.queuedWriteError; }
        if (state.lookupIndexWriteError !== null) { throw state.lookupIndexWriteError; }
        const finalized = this._importSessionActive ?
            state.initialFileLength > 0 :
            state.fileLength > 0;
        if (finalized) {
            throw new Error(`Cannot append to finalized authoritative term records: ${state.fileName}`);
        }
    }

    /**
     * @param {TermRecordShardState} state
     * @returns {Promise<void>}
     */
    async _flushPendingWritesForShard(state) {
        if (state.pendingWriteBytes <= 0 || state.pendingWriteChunks.length === 0) {
            return;
        }
        if (state.writable === null) {
            state.writable = await state.fileHandle.createWritable({keepExistingData: true});
            const seekOffset = state.fileLength - state.pendingWriteBytes;
            await state.writable.seek(Math.max(0, seekOffset));
        }
        const writeStartOffset = state.fileLength - state.pendingWriteBytes;
        const chunks = this._coalescePendingChunks(state.pendingWriteChunks);
        state.pendingWriteChunks = [];
        state.pendingWriteBytes = 0;
        if (this._importSessionActive) {
            this._queueWriteChunksForShard(state, chunks);
            if (state.queuedWriteBytes >= this._queuedWriteBudgetBytes) {
                const rotated = await this._rotateActiveShardSegmentAfterQueuePressure(state);
                if (!rotated) {
                    await this._awaitQueuedWritesForShard(state);
                }
            }
            return;
        }
        if (state.queuedWritePromise !== null) {
            this._queueWriteChunksForShard(state, chunks);
            await this._awaitQueuedWritesForShard(state);
            return;
        }
        await this._writeChunksForShard(state, chunks, writeStartOffset);
    }

    /**
     * @param {TermRecordShardState} state
     * @param {Uint8Array[]} chunks
     * @returns {void}
     * @throws {Error} If an earlier queued write failed.
     */
    _queueWriteChunksForShard(state, chunks) {
        if (chunks.length === 0) {
            return;
        }
        if (state.queuedWriteError !== null) {
            throw state.queuedWriteError;
        }
        state.importWriteStarted = true;
        for (const chunk of chunks) {
            if (chunk.byteLength <= 0) { continue; }
            state.queuedWriteChunks.push(chunk);
            state.queuedWriteBytes += chunk.byteLength;
        }
        if (state.queuedWritePromise !== null) {
            return;
        }
        state.queuedWritePromise = this._drainQueuedWritesForShard(state);
        // Own early rejection until finalization observes the original promise
        // or the sticky write error recorded by the drain.
        void state.queuedWritePromise.catch(() => {});
    }

    /**
     * @param {TermRecordShardState} state
     * @returns {Promise<void>}
     */
    async _awaitQueuedWritesForShard(state) {
        if (state.queuedWriteError !== null) {
            throw state.queuedWriteError;
        }
        const promise = state.queuedWritePromise;
        if (promise === null) {
            return;
        }
        await promise;
    }

    /**
     * @param {TermRecordShardState} state
     * @returns {Promise<boolean>}
     */
    async _rotateActiveShardSegmentAfterQueuePressure(state) {
        const logicalKey = state.logicalKey;
        if (logicalKey === null) {
            return false;
        }
        const active = this._activeAppendShardStateByKey.get(logicalKey);
        if (active !== state) {
            return false;
        }
        const nextSegmentIndex = state.segmentIndex + 1;
        const decodedShardInfo = this._decodeShardInfoFromShardFileName(state.logicalKey ?? state.fileName);
        const dictionaryName = decodedShardInfo?.dictionaryName ?? this._decodeShardInfoFromShardFileName(state.fileName)?.dictionaryName ?? '';
        const sharedContentDictName = String(state.sharedContentDictName ?? 'raw');
        const nextFileName = this._getShardSegmentFileName(dictionaryName, sharedContentDictName, nextSegmentIndex);
        const nextFileHandle = await this._recordsDirectoryHandle?.getFileHandle(nextFileName, {create: true});
        if (typeof nextFileHandle === 'undefined') {
            return false;
        }
        const created = this._createShardState(
            nextFileName,
            nextFileHandle,
            0,
            state.sharedContentDictName,
            nextSegmentIndex,
            logicalKey,
        );
        this._shardStateByFileName.set(nextFileName, created);
        this._activeAppendShardStateByKey.set(logicalKey, created);
        return true;
    }

    /**
     * @param {TermRecordShardState} state
     * @returns {Promise<void>}
     */
    async _drainQueuedWritesForShard(state) {
        try {
            ++this._writeDrainMetrics.drainCycleCount;
            while (state.queuedWriteChunks.length > 0) {
                const chunks = state.queuedWriteChunks;
                const writeStartOffset = state.fileLength - state.pendingWriteBytes - state.queuedWriteBytes;
                state.queuedWriteChunks = [];
                state.queuedWriteBytes = 0;
                await this._writeChunksForShard(state, chunks, writeStartOffset);
            }
        } catch (error) {
            state.queuedWriteError = error instanceof Error ? error : new Error(String(error));
            state.queuedWriteChunks = [];
            state.queuedWriteBytes = 0;
            throw error;
        } finally {
            state.queuedWritePromise = null;
        }
    }

    /**
     * @param {TermRecordShardState} state
     * @param {Uint8Array[]} chunks
     * @param {number} writeStartOffset Stable logical offset captured before queued writes can admit a later suffix.
     * @returns {Promise<void>}
     */
    async _writeChunksForShard(state, chunks, writeStartOffset) {
        if (state.writable === null) {
            return;
        }
        let writtenBytes = 0;
        for (const chunk of chunks) {
            if (chunk.byteLength <= 0) { continue; }
            try {
                await /** @type {FileSystemWritableFileStream} */ (state.writable).write(chunk);
                writtenBytes += chunk.byteLength;
            } catch (error) {
                if (!this._isClosingWritableStreamError(error)) {
                    throw error;
                }
                state.writable = null;
                const seekOffset = writeStartOffset + writtenBytes;
                await this._reopenShardWritable(state, seekOffset);
                if (state.writable === null) {
                    throw error;
                }
                await /** @type {FileSystemWritableFileStream} */ (state.writable).write(chunk);
                writtenBytes += chunk.byteLength;
            }
        }
    }

    /**
     * @param {string} dictionaryName
     * @returns {Promise<void>}
     */
    async _deleteShardByDictionary(dictionaryName) {
        if (this._recordsDirectoryHandle === null) {
            return;
        }
        this._pendingDictionaryDeletionNames.add(dictionaryName);
        /** @type {Error[]} */
        const errors = [];
        try {
            // Settle every owned writer before unlinking or retiring its state.
            for (const state of this._shardStateByFileName.values()) {
                if (this._decodeDictionaryNameFromShardFileName(state.fileName) !== dictionaryName) { continue; }
                try {
                    await this._flushPendingWritesForShard(state);
                } catch (error) {
                    errors.push(toError(error));
                }
                const writes = await Promise.allSettled([state.queuedWritePromise, state.lookupIndexWritePromise]);
                for (const write of writes) {
                    if (write.status === 'rejected') { errors.push(toError(write.reason)); }
                }
                try {
                    await this._closeShardWritable(state);
                } catch (error) {
                    errors.push(toError(error));
                }
                if (state.lookupIndexWritable !== null) {
                    try {
                        await state.lookupIndexWritable.close();
                    } catch (error) {
                        errors.push(toError(error));
                    } finally {
                        state.lookupIndexWritable = null;
                    }
                }
            }
            if (errors.length > 0) {
                throw new AggregateError(errors, `Failed to close deleted term-record storage: ${dictionaryName}`);
            }
            const shardFiles = await this._listShardStorageFiles();
            for (const {descriptorFileName: fileName, hasDescriptor} of shardFiles) {
                if (this._decodeDictionaryNameFromShardFileName(fileName) !== dictionaryName) { continue; }
                if (hasDescriptor) {
                    try {
                        await this._removeStorageFileOrTruncate(fileName, false);
                    } catch (error) {
                        errors.push(toError(error));
                    }
                }
                try {
                    await this._removeStorageFileOrTruncate(`${fileName}${LOOKUP_INDEX_FILE_SUFFIX}`, true);
                } catch (error) {
                    errors.push(toError(error));
                }
            }
            if (errors.length > 0) {
                throw new AggregateError(errors, `Failed to delete term-record storage: ${dictionaryName}`);
            }
            this._pendingDictionaryDeletionNames.delete(dictionaryName);
        } finally {
            // Orphan files are not live lookup/append state, even when OPFS fails.
            for (const [fileName, state] of this._shardStateByFileName) {
                if (this._decodeDictionaryNameFromShardFileName(fileName) !== dictionaryName) { continue; }
                this._shardStateByFileName.delete(fileName);
                if (this._activeAppendShardStateByKey.get(state.logicalKey) === state) {
                    this._activeAppendShardStateByKey.delete(state.logicalKey);
                }
            }
            this._invalidatePersistentLookupState(dictionaryName);
        }
    }

    /**
     * Removes a storage file, or truncates it when another browser runtime
     * temporarily prevents unlinking an open OPFS handle.
     * @param {string} fileName
     * @param {boolean} allowMissing
     * @returns {Promise<void>}
     * @throws {Error}
     */
    async _removeStorageFileOrTruncate(fileName, allowMissing) {
        if (this._recordsDirectoryHandle === null) { return; }
        try {
            await this._recordsDirectoryHandle.removeEntry(fileName);
            return;
        } catch (removeError) {
            let fileHandle;
            try {
                fileHandle = await this._recordsDirectoryHandle.getFileHandle(fileName, {create: false});
            } catch (lookupError) {
                const lookupErrorName = typeof lookupError === 'object' && lookupError !== null ?
                    /** @type {unknown} */ (Reflect.get(lookupError, 'name')) :
                    null;
                if (allowMissing && lookupErrorName === 'NotFoundError') { return; }
                throw new AggregateError(
                    [removeError, lookupError],
                    `Failed to remove or open term-record storage file ${fileName}`,
                );
            }
            try {
                const writable = await fileHandle.createWritable({keepExistingData: true});
                try {
                    await writable.truncate(0);
                } finally {
                    await writable.close();
                }
                const file = await fileHandle.getFile();
                if (file.size > 0) {
                    throw new Error(`Truncated term-record storage file is not empty: ${fileName}`);
                }
                reportDiagnostics('term-record-store-delete-truncated-open-file', {
                    fileName,
                    removeError: removeError instanceof Error ? removeError.message : String(removeError),
                });
            } catch (truncateError) {
                throw new AggregateError(
                    [removeError, truncateError],
                    `Failed to remove or truncate term-record storage file ${fileName}`,
                );
            }
        }
    }

    /**
     * @param {string} fileName
     * @param {FileSystemFileHandle} fileHandle
     * @param {number} fileLength
     * @param {string|null} [sharedContentDictName]
     * @param {number} [segmentIndex=0]
     * @param {string|null} [logicalKey=null]
     * @returns {TermRecordShardState}
     */
    _createShardState(fileName, fileHandle, fileLength, sharedContentDictName = null, segmentIndex = 0, logicalKey = null) {
        return {
            fileName,
            fileHandle,
            writable: null,
            fileLength,
            pendingWriteBytes: 0,
            pendingWriteChunks: [],
            queuedWriteBytes: 0,
            queuedWritePromise: null,
            queuedWriteError: null,
            queuedWriteChunks: [],
            importWriteStarted: false,
            sharedContentDictName,
            segmentIndex,
            logicalKey: logicalKey ?? fileName,
            initialFileLength: fileLength,
            pendingLookupIndexChunks: [],
            pendingLookupIndexBytes: 0,
            pendingLookupIndexRecordCount: 0,
            lookupIndexFileHandle: null,
            lookupIndexWritable: null,
            lookupIndexChunkCount: 0,
            lookupIndexRecordCount: 0,
            lookupIndexQueuedBytes: 0,
            lookupIndexMaxQueuedBytes: 0,
            lookupIndexWritePromise: null,
            lookupIndexWriteError: null,
            appendFormatValidated: fileLength === 0,
            generationId: this._createShardGenerationId(),
        };
    }

    /**
     * Prevents a new-format chunk from being appended to an older shard header.
     * @param {TermRecordShardState} state
     * @returns {Promise<void>}
     */
    async _validateShardAppendFormat(state) {
        if (state.appendFormatValidated) { return; }
        const file = await state.fileHandle.getFile();
        if (file.size < BINARY_HEADER_PREFIX_BYTES) {
            throw new Error(`Cannot append to truncated term-record shard: ${state.fileName}`);
        }
        const headerBytes = await this._readFileRange(file, 0, BINARY_HEADER_PREFIX_BYTES);
        const magic = this._textDecoder.decode(headerBytes.subarray(0, BINARY_MAGIC_BYTES));
        if (magic !== BINARY_MAGIC_TEXT) {
            throw new Error(`Cannot append ${BINARY_MAGIC_TEXT} records to ${magic || 'unknown'} shard: ${state.fileName}`);
        }
        state.generationId = new Uint8Array(headerBytes.subarray(BINARY_MAGIC_BYTES));
        state.appendFormatValidated = true;
    }

    /**
     * @param {string} dictionaryName
     * @returns {string|null}
     */
    /**
     * @returns {number}
     */
    _computeFlushThresholdBytes() {
        /** @type {number|null} */
        let memoryGiB = null;
        try {
            const rawValue = /** @type {unknown} */ (Reflect.get(globalThis.navigator ?? {}, 'deviceMemory'));
            if (typeof rawValue === 'number' && Number.isFinite(rawValue) && rawValue > 0) {
                memoryGiB = rawValue;
            }
        } catch (_) {
            // NOP
        }
        if (memoryGiB !== null) {
            if (memoryGiB <= 4) {
                return LOW_MEMORY_FLUSH_THRESHOLD_BYTES;
            }
            if (memoryGiB >= 8) {
                return HIGH_MEMORY_FLUSH_THRESHOLD_BYTES;
            }
        }
        return DEFAULT_FLUSH_THRESHOLD_BYTES;
    }

    /**
     * @returns {number}
     */
    _computeQueuedWriteBudgetBytes() {
        /** @type {number|null} */
        let memoryGiB = null;
        try {
            const rawValue = /** @type {unknown} */ (Reflect.get(globalThis.navigator ?? {}, 'deviceMemory'));
            if (typeof rawValue === 'number' && Number.isFinite(rawValue) && rawValue > 0) {
                memoryGiB = rawValue;
            }
        } catch (_) {
            // NOP
        }
        if (memoryGiB !== null) {
            if (memoryGiB <= 4) {
                return LOW_MEMORY_QUEUED_WRITE_BUDGET_BYTES;
            }
            if (memoryGiB >= 8) {
                return HIGH_MEMORY_QUEUED_WRITE_BUDGET_BYTES;
            }
        }
        return DEFAULT_QUEUED_WRITE_BUDGET_BYTES;
    }


    /**
     * @returns {number}
     */
    _computeWriteCoalesceTargetBytes() {
        if (
            this._expectedImportBytes !== null &&
            this._expectedImportBytes >= LARGE_IMPORT_EXPECTED_BYTES_THRESHOLD
        ) {
            return LARGE_IMPORT_WRITE_COALESCE_TARGET_BYTES;
        }
        /** @type {number|null} */
        let memoryGiB = null;
        try {
            const rawValue = /** @type {unknown} */ (Reflect.get(globalThis.navigator ?? {}, 'deviceMemory'));
            if (typeof rawValue === 'number' && Number.isFinite(rawValue) && rawValue > 0) {
                memoryGiB = rawValue;
            }
        } catch (_) {
            // NOP
        }
        if (memoryGiB !== null) {
            if (memoryGiB <= 4) {
                return LOW_MEMORY_WRITE_COALESCE_TARGET_BYTES;
            }
            if (memoryGiB >= 8) {
                return HIGH_MEMORY_WRITE_COALESCE_TARGET_BYTES;
            }
        }
        return DEFAULT_WRITE_COALESCE_TARGET_BYTES;
    }

    /**
     * @param {Uint8Array[]} chunks
     * @returns {Uint8Array[]}
     */
    _coalescePendingChunks(chunks) {
        const targetBytes = this._writeCoalesceTargetBytes;
        if (chunks.length <= 1 || targetBytes <= 0) {
            if (chunks.length === 1 && chunks[0].byteLength > 0) {
                this._recordWriteDrainGroupMetrics(chunks[0].byteLength, 1, false);
            }
            return chunks;
        }
        /** @type {Uint8Array[]} */
        const result = [];
        /** @type {Uint8Array[]} */
        let group = [];
        let groupBytes = 0;
        for (const chunk of chunks) {
            const chunkBytes = chunk.byteLength;
            if (chunkBytes <= 0) { continue; }
            if (groupBytes > 0 && (groupBytes + chunkBytes > targetBytes || group.length >= WRITE_COALESCE_MAX_CHUNKS)) {
                this._recordWriteDrainGroupMetrics(groupBytes, group.length, group.length > 1);
                result.push(this._mergeChunks(group, groupBytes));
                group = [];
                groupBytes = 0;
            }
            if (chunkBytes >= targetBytes) {
                if (groupBytes > 0) {
                    this._recordWriteDrainGroupMetrics(groupBytes, group.length, group.length > 1);
                    result.push(this._mergeChunks(group, groupBytes));
                    group = [];
                    groupBytes = 0;
                }
                this._recordWriteDrainGroupMetrics(chunkBytes, 1, false);
                result.push(chunk);
                continue;
            }
            group.push(chunk);
            groupBytes += chunkBytes;
        }
        if (groupBytes > 0) {
            this._recordWriteDrainGroupMetrics(groupBytes, group.length, group.length > 1);
            result.push(this._mergeChunks(group, groupBytes));
        }
        return result;
    }

    /**
     * @param {number} byteLength
     * @param {number} chunkCount
     * @param {boolean} merged
     * @returns {void}
     */
    _recordWriteDrainGroupMetrics(byteLength, chunkCount, merged) {
        if (byteLength <= 0 || chunkCount <= 0) { return; }
        ++this._writeDrainMetrics.writeCallCount;
        this._writeDrainMetrics.totalWriteBytes += byteLength;
        if (byteLength > this._writeDrainMetrics.maxWriteBytes) {
            this._writeDrainMetrics.maxWriteBytes = byteLength;
        }
        if (this._writeDrainMetrics.minWriteBytes === 0 || byteLength < this._writeDrainMetrics.minWriteBytes) {
            this._writeDrainMetrics.minWriteBytes = byteLength;
        }
        if (!merged) {
            ++this._writeDrainMetrics.singleChunkWriteCount;
            return;
        }
        ++this._writeDrainMetrics.mergedWriteCount;
        this._writeDrainMetrics.mergedWriteBytes += byteLength;
        this._writeDrainMetrics.mergedGroupChunkCount += chunkCount;
        if (chunkCount > this._writeDrainMetrics.maxMergedGroupChunkCount) {
            this._writeDrainMetrics.maxMergedGroupChunkCount = chunkCount;
        }
        if (
            this._writeDrainMetrics.minMergedGroupChunkCount === 0 ||
            chunkCount < this._writeDrainMetrics.minMergedGroupChunkCount
        ) {
            this._writeDrainMetrics.minMergedGroupChunkCount = chunkCount;
        }
    }

    /**
     * @returns {{drainCycleCount: number, writeCallCount: number, singleChunkWriteCount: number, mergedWriteCount: number, totalWriteBytes: number, mergedWriteBytes: number, maxWriteBytes: number, minWriteBytes: number, mergedGroupChunkCount: number, maxMergedGroupChunkCount: number, minMergedGroupChunkCount: number, writeCoalesceTargetBytes: number}}
     */
    _createEmptyWriteDrainMetrics() {
        return {
            drainCycleCount: 0,
            writeCallCount: 0,
            singleChunkWriteCount: 0,
            mergedWriteCount: 0,
            totalWriteBytes: 0,
            mergedWriteBytes: 0,
            maxWriteBytes: 0,
            minWriteBytes: 0,
            mergedGroupChunkCount: 0,
            maxMergedGroupChunkCount: 0,
            minMergedGroupChunkCount: 0,
            writeCoalesceTargetBytes: this._writeCoalesceTargetBytes,
        };
    }

    /**
     * @returns {{writeCallCount: number, writeBytes: number, awaitMs: number, maxQueuedBytes: number}}
     */
    _createEmptyLookupIndexWriteMetrics() {
        return {
            writeCallCount: 0,
            writeBytes: 0,
            awaitMs: 0,
            maxQueuedBytes: 0,
        };
    }

    /**
     * @param {Uint8Array[]} chunks
     * @param {number} totalBytes
     * @returns {Uint8Array}
     */
    _mergeChunks(chunks, totalBytes) {
        if (chunks.length === 1) {
            return chunks[0];
        }
        const output = new Uint8Array(totalBytes);
        let offset = 0;
        for (const chunk of chunks) {
            output.set(chunk, offset);
            offset += chunk.byteLength;
        }
        return output;
    }

    /**
     * @param {string} dictionaryName
     * @param {string} [contentDictName='raw']
     * @returns {string}
     */
    _getShardFileName(dictionaryName, contentDictName = 'raw') {
        const normalizedContentDictName = this._normalizeContentDictName(contentDictName);
        const encodedDictionaryName = encodeURIComponent(dictionaryName);
        if (normalizedContentDictName === 'raw') {
            return `${SHARD_FILE_PREFIX}${encodedDictionaryName}${SHARD_FILE_SUFFIX}`;
        }
        const encodedContentDictName = encodeURIComponent(normalizedContentDictName);
        return `${SHARD_FILE_PREFIX}${encodedDictionaryName.length}${SHARD_FILE_CONTENT_DICT_SEPARATOR}${encodedDictionaryName}${encodedContentDictName}${SHARD_FILE_SUFFIX}`;
    }

    /**
     * @param {string} dictionaryName
     * @param {string} [contentDictName='raw']
     * @param {number} [segmentIndex=0]
     * @returns {string}
     * @throws {RangeError} If the segment index is outside the safe integer range.
     */
    _getShardSegmentFileName(dictionaryName, contentDictName = 'raw', segmentIndex = 0) {
        if (!Number.isSafeInteger(segmentIndex) || segmentIndex < 0) {
            throw new RangeError('Term-record shard segment index exceeds the safe integer range');
        }
        const baseFileName = this._getShardFileName(dictionaryName, contentDictName);
        if (segmentIndex === 0) {
            return baseFileName;
        }
        return `${baseFileName.slice(0, -SHARD_FILE_SUFFIX.length)}${SHARD_FILE_SEGMENT_SEPARATOR}${segmentIndex}${SHARD_FILE_SUFFIX}`;
    }

    /**
     * @param {string} fileName
     * @returns {boolean}
     */
    _isShardFileName(fileName) {
        return fileName.startsWith(SHARD_FILE_PREFIX) && fileName.endsWith(SHARD_FILE_SUFFIX);
    }

    /**
     * @param {string} fileName
     * @returns {boolean}
     */
    _isCanonicalTermRecordStorageFileName(fileName) {
        const descriptorFileName = fileName.endsWith(`${SHARD_FILE_SUFFIX}${LOOKUP_INDEX_FILE_SUFFIX}`) ?
            fileName.slice(0, -LOOKUP_INDEX_FILE_SUFFIX.length) :
            fileName;
        const shardInfo = this._decodeShardInfoFromShardFileName(descriptorFileName);
        if (shardInfo === null) { return false; }
        const canonicalDescriptor = this._getShardSegmentFileName(
            shardInfo.dictionaryName,
            shardInfo.contentDictName,
            shardInfo.segmentIndex,
        );
        if (descriptorFileName !== canonicalDescriptor) { return false; }
        return fileName === descriptorFileName || fileName === `${descriptorFileName}${LOOKUP_INDEX_FILE_SUFFIX}`;
    }

    /**
     * @param {string} fileName
     * @returns {string|null}
     */
    _decodeDictionaryNameFromShardFileName(fileName) {
        if (!this._isShardFileName(fileName)) {
            return null;
        }
        return this._decodeShardInfoFromShardFileName(fileName)?.dictionaryName ?? null;
    }

    /**
     * @param {string|null|undefined} contentDictName
     * @returns {string}
     */
    _normalizeContentDictName(contentDictName) {
        return (typeof contentDictName === 'string' && contentDictName.length > 0) ? contentDictName : 'raw';
    }

    /**
     * @param {string} fileName
     * @returns {{dictionaryName: string, contentDictName: string, segmentIndex: number}|null}
     */
    _decodeShardInfoFromShardFileName(fileName) {
        if (!this._isShardFileName(fileName)) {
            return null;
        }
        let encoded = fileName.slice(SHARD_FILE_PREFIX.length, fileName.length - SHARD_FILE_SUFFIX.length);
        let segmentIndex = 0;
        const segmentSeparatorIndex = encoded.lastIndexOf(SHARD_FILE_SEGMENT_SEPARATOR);
        if (segmentSeparatorIndex > 0) {
            const segmentValue = encoded.slice(segmentSeparatorIndex + SHARD_FILE_SEGMENT_SEPARATOR.length);
            const parsedSegmentIndex = parseCanonicalSafeInteger(segmentValue);
            if (parsedSegmentIndex === null || parsedSegmentIndex <= 0) {
                return null;
            }
            segmentIndex = parsedSegmentIndex;
            encoded = encoded.slice(0, segmentSeparatorIndex);
        }
        const separatorIndex = encoded.indexOf(SHARD_FILE_CONTENT_DICT_SEPARATOR);
        try {
            if (separatorIndex <= 0) {
                const dictionaryName = decodeURIComponent(encoded);
                return dictionaryName.length > 0 ? {dictionaryName, contentDictName: 'raw', segmentIndex} : null;
            }
            const dictionaryLength = parseCanonicalSafeInteger(encoded.slice(0, separatorIndex));
            if (dictionaryLength === null) {
                return null;
            }
            const payload = encoded.slice(separatorIndex + SHARD_FILE_CONTENT_DICT_SEPARATOR.length);
            if (payload.length < dictionaryLength) {
                return null;
            }
            const dictionaryName = decodeURIComponent(payload.slice(0, dictionaryLength));
            const contentDictName = decodeURIComponent(payload.slice(dictionaryLength));
            if (dictionaryName.length === 0) {
                return null;
            }
            return {
                dictionaryName,
                contentDictName: contentDictName.length > 0 ? contentDictName : 'raw',
                segmentIndex,
            };
        } catch (_) {
            return null;
        }
    }

    /**
     * @param {TermRecordShardState} state
     * @returns {void}
     */
    _setActiveAppendShardState(state) {
        const existing = this._activeAppendShardStateByKey.get(state.logicalKey);
        if (typeof existing === 'undefined' || existing.segmentIndex <= state.segmentIndex) {
            this._activeAppendShardStateByKey.set(state.logicalKey, state);
        }
    }

    /** */
    _ensureIndexesReady() {
        if (!this._indexDirty) {
            return;
        }
        this._indexByDictionary.clear();
        this._indexDirty = false;
    }

    /** */
    _rebuildIndexesFromRecords() {
        this._indexByDictionary.clear();
        for (const record of this._recordsById.values()) {
            this._addToIndex(record);
        }
        this._indexDirty = false;
    }

    /**
     * @param {TermRecord} record
     */
    _addToIndex(record) {
        this._addRecordToDictionaryIndex(this._getOrCreateDictionaryIndex(record.dictionary), record);
    }

    /**
     * @param {string} dictionaryName
     * @param {{expression: Map<string, number[]>, reading: Map<string, number[]>, expressionReverse: Map<string, number[]>, readingReverse: Map<string, number[]>, sequence: Map<number, number[]>}} index
     */
    _addDictionaryRecordsToIndex(dictionaryName, index) {
        const ids = this._getLiveRecordIdsForDictionary(dictionaryName);
        if (typeof ids !== 'undefined') {
            const records = this._recordsById.getRawRecords();
            for (let i = 0, ii = ids.length; i < ii; ++i) {
                const record = records[ids[i]];
                if (typeof record !== 'undefined') {
                    this._addRecordToDictionaryIndex(index, record);
                }
            }
            return;
        }
        for (const record of this._recordsById.values()) {
            if (record.dictionary === dictionaryName) {
                this._addRecordToDictionaryIndex(index, record);
            }
        }
    }

    /**
     * @param {string} dictionaryName
     * @param {{expressionReverse: Map<string, number[]>, readingReverse: Map<string, number[]>}} index
     */
    _addDictionaryRecordsToReverseIndex(dictionaryName, index) {
        const ids = this._getLiveRecordIdsForDictionary(dictionaryName);
        if (typeof ids !== 'undefined') {
            const records = this._recordsById.getRawRecords();
            for (let i = 0, ii = ids.length; i < ii; ++i) {
                const record = records[ids[i]];
                if (typeof record !== 'undefined') {
                    this._addRecordReverseToDictionaryIndex(index, record);
                }
            }
            return;
        }
        for (const record of this._recordsById.values()) {
            if (record.dictionary === dictionaryName) {
                this._addRecordReverseToDictionaryIndex(index, record);
            }
        }
    }

    /**
     * @param {{expressionReverse: Map<string, number[]>, readingReverse: Map<string, number[]>}} index
     * @param {TermRecord} record
     */
    _addRecordReverseToDictionaryIndex(index, record) {
        this._ensureDecodedRecordStrings(record);
        const expression = record.expression ?? '';
        const reading = record.reading ?? expression;
        if (record.expressionReverse === null || typeof record.expressionReverse === 'undefined') {
            record.expressionReverse = this._reverseString(expression);
        }
        if (record.expressionReverse !== null) {
            const expressionReverseList = index.expressionReverse.get(record.expressionReverse);
            if (typeof expressionReverseList === 'undefined') {
                index.expressionReverse.set(record.expressionReverse, [record.id]);
            } else {
                expressionReverseList.push(record.id);
            }
        }
        if (reading !== expression && (record.readingReverse === null || typeof record.readingReverse === 'undefined')) {
            record.readingReverse = this._reverseString(reading);
        }
        if (reading !== expression && record.readingReverse !== null && typeof record.readingReverse !== 'undefined') {
            const readingReverseList = index.readingReverse.get(record.readingReverse);
            if (typeof readingReverseList === 'undefined') {
                index.readingReverse.set(record.readingReverse, [record.id]);
            } else {
                readingReverseList.push(record.id);
            }
        }
    }

    /**
     * @param {{expression: Map<string, number[]>, reading: Map<string, number[]>, expressionReverse: Map<string, number[]>, readingReverse: Map<string, number[]>, sequence: Map<number, number[]>}} index
     * @param {TermRecord} record
     */
    _addRecordToDictionaryIndex(index, record) {
        this._ensureDecodedRecordStrings(record);
        const expression = record.expression ?? '';
        const reading = record.reading ?? expression;
        this._addDecodedRecordToDictionaryIndex(index, record, expression, reading);
    }

    /**
     * @param {{expression: Map<string, number[]>, reading: Map<string, number[]>, expressionReverse: Map<string, number[]>, readingReverse: Map<string, number[]>, sequence: Map<number, number[]>}} index
     * @param {TermRecord} record
     * @param {string} expression
     * @param {string} reading
     */
    _addDecodedRecordToDictionaryIndex(index, record, expression, reading) {
        const expressionList = index.expression.get(expression);
        if (typeof expressionList === 'undefined') {
            index.expression.set(expression, [record.id]);
        } else {
            expressionList.push(record.id);
        }

        if (reading !== expression) {
            const readingList = index.reading.get(reading);
            if (typeof readingList === 'undefined') {
                index.reading.set(reading, [record.id]);
            } else {
                readingList.push(record.id);
            }
        }
        if (this._reverseIndexReady.has(index)) {
            this._addRecordReverseToDictionaryIndex(index, record);
        }
        if (typeof record.sequence === 'number' && record.sequence >= 0) {
            const sequenceList = index.sequence.get(record.sequence);
            if (typeof sequenceList === 'undefined') {
                index.sequence.set(record.sequence, [record.id]);
            } else {
                sequenceList.push(record.id);
            }
        }
    }

    /**
     * @param {TermRecord} record
     * @returns {void}
     */
    _ensureDecodedRecordStrings(record) {
        if ((typeof record.expression !== 'string' || record.expression.length === 0) && record.expressionBytes instanceof Uint8Array && record.expressionBytes.byteLength > 0) {
            record.expression = this._decodeString(record.expressionBytes, 0, record.expressionBytes.byteLength);
        }
        if (typeof record.expression !== 'string') {
            record.expression = '';
        }
        if (typeof record.reading !== 'string' || record.reading.length === 0) {
            if (record.readingEqualsExpression === true) {
                record.reading = record.expression;
            } else if (record.readingBytes instanceof Uint8Array && record.readingBytes.byteLength > 0) {
                record.reading = this._decodeString(record.readingBytes, 0, record.readingBytes.byteLength);
            } else if (typeof record.reading !== 'string') {
                record.reading = '';
            }
        }
    }
}
