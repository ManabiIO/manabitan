#!/usr/bin/env python3
"""Record pinned sources and classify existing block sizes; never execute Zstd."""

import argparse
import datetime
import hashlib
import json
from pathlib import Path
import struct
import subprocess


BASELINE = 'bde55dfbee1451edc32051f8bf51e8a870d5c72c'
UPSTREAM = '82d322c4973d9e2968d94047a40892bc6d9a9bdf'
MANIFEST_SHA256 = '4629920d51385465dfa1d5afd3230c88d0bc3a7d3ccf23d5e0379d1b1425ab39'
DICT_SHA256 = 'f384a821c2f122bde518ee8a513ea76cbe9876c3534fc1fff4cacdf1ecc509cb'
BASELINE_PATHS = [
    'dev/bin/build-zstd-wasm.js',
    'dev/data/zstd-wasm.PROVENANCE.md',
    'dev/data/zstd-block-envelope.c',
    'dev/data/zstd-dicts/jmdict.zdict',
    'dev/data/zstd-simd.wasm',
    'dev/lib/zstd-wasm.js',
    'dev/lib/zstd-simd-module.js',
    'dev/lib/zstd-simd-module.d.ts',
    'ext/js/dictionary/zstd-term-content.js',
    'ext/js/dictionary/zstd-term-content-compression-worker.js',
    'ext/js/dictionary/term-content-block-store.js',
]
UPSTREAM_PATHS = [
    'lib/zstd.h',
    'lib/compress/zstd_compress.c',
    'lib/compress/zstd_compress_internal.h',
    'lib/compress/zstd_fast.c',
    'lib/compress/clevels.h',
    'build/single_file_libs/create_single_file_library.sh',
    'LICENSE',
]


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args])


def record_sources(repo, revision, repository, paths):
    result = {}
    for relative in paths:
        content = git(repo, 'show', revision + ':' + relative)
        if (repo / relative).read_bytes() != content:
            raise ValueError('Working source differs from audited Git object: ' + relative)
        result[relative] = {
            'gitBlob': git(repo, 'rev-parse', revision + ':' + relative).decode().strip(),
            'sha256': sha256(content),
            'bytes': len(content),
            'url': f'https://github.com/{repository}/blob/{revision}/{relative}',
            'workingBytesMatchPinnedObject': True,
        }
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline-root', type=Path, required=True)
    parser.add_argument('--upstream-root', type=Path, required=True)
    parser.add_argument('--fixture-manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError('Refusing to overwrite an earlier audit receipt')
    manifest_bytes = args.fixture_manifest.read_bytes()
    if sha256(manifest_bytes) != MANIFEST_SHA256:
        raise ValueError('Frozen fixture manifest differs')
    manifest = json.loads(manifest_bytes)
    if manifest['sourceCommit'] != BASELINE or len(manifest['blocks']) != 28:
        raise ValueError('Unexpected fixture source or block count')
    dictionary = git(args.baseline_root, 'show', BASELINE + ':dev/data/zstd-dicts/jmdict.zdict')
    if sha256(dictionary) != DICT_SHA256 or len(dictionary) != 16384:
        raise ValueError('Unexpected pinned dictionary')
    dictionary_magic, dictionary_id = struct.unpack_from('<II', dictionary)
    if dictionary_magic != 0xec30a437:
        raise ValueError('Expected full Zstd dictionary magic')
    baseline_sources = record_sources(args.baseline_root, BASELINE, 'ManabiIO/manabitan', BASELINE_PATHS)
    upstream_sources = record_sources(args.upstream_root, UPSTREAM, 'facebook/zstd', UPSTREAM_PATHS)
    if git(args.upstream_root, 'rev-parse', 'HEAD').decode().strip() != UPSTREAM:
        raise ValueError('Wrong upstream checkout')
    if git(args.upstream_root, 'status', '--porcelain').strip():
        raise ValueError('Upstream audit checkout changed')

    # These constants and the OR predicate transcribe the pinned C source at
    # zstd_compress.c:5256-5285. The state below is standard createCDict(dict,-1)
    # followed by the one-shot compress_usingCDict API, not advanced CDict use.
    cutoff = 128 * 1024
    multiplier = 6
    blocks = []
    for index, block in enumerate(manifest['blocks']):
        source_size = block['uncompressedLength']
        if not isinstance(source_size, int) or source_size <= 0:
            raise ValueError('Invalid decoded block length')
        predicates = {
            'sourceStrictlyBelow128KiB': source_size < cutoff,
            'sourceStrictlyBelowSixDictionaryLengths': source_size < len(dictionary) * multiplier,
            'unknownPledgedSourceSize': False,
            'storedCompressionLevelZero': False,
        }
        reuses_prepared_state = any(predicates.values())
        blocks.append({
            'index': index,
            'sourceBytes': source_size,
            'compressedEnvelopeBytes': block['length'],
            'sourceSha256': block['uncompressedSha256'],
            'predicates': predicates,
            'standardCDictReusesPreparedState': reuses_prepared_state,
            'path': 'resetCCtx_usingCDict' if reuses_prepared_state else 'resetCCtx_internal + compress_insertDictionary',
        })
    lengths = [block['sourceBytes'] for block in blocks]
    script = Path(__file__).resolve()
    report = script.with_name('compression-audit.md')
    result = {
        'schemaVersion': 1,
        'recordedAt': datetime.datetime.now(datetime.UTC).isoformat(),
        'scope': 'Read-only source audit and classification of frozen metadata; no compression, build, byte-parity experiment, or performance measurement',
        'baseline': {'commit': BASELINE, 'tree': git(args.baseline_root, 'rev-parse', BASELINE + '^{tree}').decode().strip(), 'sources': baseline_sources},
        'upstream': {'commit': UPSTREAM, 'tree': git(args.upstream_root, 'rev-parse', UPSTREAM + '^{tree}').decode().strip(), 'clean': True, 'sources': upstream_sources},
        'dictionary': {'bytes': len(dictionary), 'sha256': DICT_SHA256, 'magic': hex(dictionary_magic), 'dictId': dictionary_id, 'compressionLevel': -1},
        'fixture': {
            'manifestSha256': MANIFEST_SHA256,
            'manifestBytes': len(manifest_bytes),
            'archiveSha256': manifest['archiveSha256'],
            'storeSha256': manifest['storeSha256'],
            'scope': manifest['scope'],
            'blockCount': len(blocks),
            'decodedBytes': sum(lengths),
            'minimumDecodedBlockBytes': min(lengths),
            'maximumDecodedBlockBytes': max(lengths),
            'standardCDictPreparedReuseBlockCount': sum(block['standardCDictReusesPreparedState'] for block in blocks),
            'blocks': blocks,
        },
        'conditionAssumptions': {
            'nonemptyCDict': True,
            'forceLoadDisabled': True,
            'oneShotKnownSourceSize': True,
            'ordinaryCreateCDictStoredLevel': -1,
            'sourceCutoffBytes': cutoff,
            'dictionaryMultiplier': multiplier,
            'dictionaryCutoffBytes': len(dictionary) * multiplier,
            'comparisonsAreStrict': True,
            'advancedCDictExcluded': True,
        },
        'files': {script.name: {'sha256': sha256(script.read_bytes()), 'bytes': script.stat().st_size}, report.name: {'sha256': sha256(report.read_bytes()), 'bytes': report.stat().st_size}},
        'limitations': [
            'Seven-bank component grouping is not the browser import planner.',
            'No compressed-byte equivalence or timing result is claimed.',
            'The source condition rules out dictionary-state reuse, not every possible dictionary-copy optimization.',
            'Advanced CDict and custom initial-state reuse remain different designs with unresolved exact-byte, ownership, memory and toolchain requirements.',
        ],
    }
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'output': str(args.output), 'sha256': sha256(args.output.read_bytes()), 'blockCount': len(blocks), 'preparedReuseBlockCount': result['fixture']['standardCDictPreparedReuseBlockCount'], 'decodedBytes': sum(lengths)}, indent=2))


if __name__ == '__main__':
    main()
