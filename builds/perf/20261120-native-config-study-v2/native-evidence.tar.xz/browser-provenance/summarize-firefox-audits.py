#!/usr/bin/env python3
"""Bind the two audited cells and job logs without combining timing samples."""

import datetime
import hashlib
import json
from pathlib import Path
import zipfile


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    root = Path(__file__).resolve().parent
    output = root / 'firefox-audits-receipt.json'
    assert not output.exists(), 'Refusing to replace the completed evidence receipt'
    cells = {}
    audits = {}
    package_maps = {}
    for direction in ('forward', 'reverse'):
        directory = root / f'firefox-{direction}'
        audit_path = directory / 'independent-audit-001.json'
        audit = json.loads(audit_path.read_text())
        download = json.loads((directory / 'download.json').read_text())
        logs = json.loads((directory / 'job-log-receipt.json').read_text())
        archive_path = Path(download['originalZip'])
        log_path = directory / f'job-{logs["jobId"]}.log'
        assert audit['ok'] and download['ok']
        assert digest(directory / 'independent-audit-001.py') == audit['auditScriptSha256']
        assert digest(archive_path) == audit['archiveSha256'] == download['sha256']
        assert digest(log_path) == logs['jobLogSha256']
        assert download['job']['id'] == logs['jobId']
        assert not audit['commandFailures']
        with zipfile.ZipFile(archive_path) as archive:
            cohort_path = next(name for name in archive.namelist() if name == 'cohort.json' or name.endswith('/cohort.json'))
            prefix = cohort_path[:-len('cohort.json')]
            cohort = json.loads(archive.read(cohort_path))
            package_maps[direction] = {arm: json.loads(archive.read(prefix + arm + '-package-entries.json')) for arm in 'ABCD'}
        printed_observations = []
        for line in log_path.read_text().splitlines():
            start = line.find('{')
            if start < 0:
                continue
            try:
                record = json.loads(line[start:])
            except json.JSONDecodeError:
                continue
            if isinstance(record, dict) and 'observation' in record:
                printed_observations.append(record)
        expected = [{'observation': item['label'], 'ms': item['totalImportMs'], 'error': None} for item in cohort['observations']]
        assert len(printed_observations) == 104 and printed_observations == expected, 'Job log and artifact observations differ'
        cells[direction] = {
            'artifactId': download['artifact']['id'],
            'archivePath': str(archive_path), 'archiveSha256': digest(archive_path),
            'archiveBytes': archive_path.stat().st_size,
            'auditPath': str(audit_path), 'auditSha256': digest(audit_path),
            'auditScriptSha256': audit['auditScriptSha256'],
            'jobId': logs['jobId'], 'jobLogSha256': logs['jobLogSha256'],
            'jobLogObservationCrossCheck': {'matched': 104, 'errors': 0},
            'observations': audit['observations'], 'measured': audit['measured'], 'warmups': audit['warmups'],
            'commandReceipts': audit['commandReceipts'], 'commandFailures': len(audit['commandFailures']), 'diagnosticErrors': audit['diagnosticErrors'],
            'variantCounts': {key: len(audit[key]) for key in ('productionEnvironmentVariants', 'effectiveExperimentVariants', 'termWorkVariants', 'finalizationWorkVariants')},
            'armTimings': audit['armTimings'],
            'comparisons': {label: {key: value for key, value in comparison.items() if key != 'pairedChangesPercent'} for label, comparison in audit['comparisons'].items()},
            'dedupCanonicalScanMedianMs': {arm: audit['termPhaseMedians'][arm]['dedupCanonicalScanMs'] for arm in 'ABCD'},
            'dedupScanMedianMs': {arm: audit['termPhaseMedians'][arm]['dedupScanMs'] for arm in 'ABCD'},
            'contentCompressionMedianMs': {arm: audit['termPhaseMedians'][arm]['contentCompressMs'] for arm in 'ABCD'},
        }
        audits[direction] = audit
    shared = ('browserRuntime', 'browserVersion', 'manifestSha256', 'toolingCommit', 'semanticDigest', 'storageSampleDigest', 'immutableProductFileHashes', 'runtimeJsonSha256', 'runtimeSourceArtifactReceiptSha256')
    for key in shared:
        assert audits['forward'][key] == audits['reverse'][key], f'Cross-cell identity/work differs: {key}'
    assert package_maps['forward'] == package_maps['reverse'], 'Cross-cell package content entries differ'
    receipt = {
        'schemaVersion': 1, 'completedAt': datetime.datetime.now(datetime.UTC).isoformat(),
        'scope': 'Independent Firefox artifact audits. All timings remain separate by cell and comparison; no pooling or control subtraction.',
        'summaryScriptSha256': digest(Path(__file__)),
        'runId': 44729808376, 'cells': cells,
        'sharedIdentity': {key: audits['forward'][key] for key in ('browserVersion', 'manifestSha256', 'toolingCommit', 'semanticDigest', 'storageSampleDigest')},
        'crossCellPackageContentEntriesIdentical': True,
        'crossCellWorkEnvironmentAndFlagsEqual': {key: audits['forward'][key] == audits['reverse'][key] for key in ('termWorkVariants', 'finalizationWorkVariants', 'productionEnvironmentVariants', 'effectiveExperimentVariants')},
        'eachCell': {'observations': 104, 'measured': 96, 'warmups': 8, 'freshProfiles': 104, 'sourceDerivedProbesPerReloadPhase': 12, 'reloadChangesExtensionRealm': True, 'browserProcessRestartedForReload': False},
        'interpretation': 'C/A and D/B are separate same-source controls. B/A and D/A compare the same native candidate with baseline A. All cells and comparisons remain separate; no pooling or control subtraction. Phase timers are diagnostic and are not added or substituted for total time.',
        'limitations': audits['forward']['limitations'],
        'runtimeArchiveDownloadedLocally': False,
        'originalResultArtifactDownloadCountPerCell': 1,
    }
    with output.open('x') as stream:
        stream.write(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'ok': True, 'receipt': str(output), 'sha256': digest(output), 'cells': list(cells)}, indent=2))


if __name__ == '__main__':
    main()
