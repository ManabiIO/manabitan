#!/usr/bin/env python3
"""Collect two already audited cells without pooling observations or statistics."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/scratch/f34c9c9fae89/manabitan-native-config-study')
OUTPUT=ROOT/'chromium-summary.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert not OUTPUT.exists(),'Refusing to overwrite summary'
    cells={}
    native_keys=['dedupNativeCallCount','dedupNativeScannedRows','dedupNativeBulkPendingRows',
                 'dedupNativeExactCandidates','dedupNativeCopiedInputBytes','dedupNativeCopiedOutputBytes',
                 'dedupNativeSnapshotBytes','dedupNativeFallbackCount','dedupNativeFallbackEligibilityCount',
                 'dedupNativeFallbackAssetCount','dedupNativeFallbackUnsupportedCount','parserMaxWasmHeapBytes']
    native_expected=[12,364869,360859,4010,16741613,32080,0,0,0,0,0,38928384]
    for replication in ['forward','reverse']:
        directory=ROOT/('chromium-'+replication)
        audit=json.loads((directory/'independent-audit-001.json').read_text())
        download=json.loads((directory/'download.json').read_text())
        job=json.loads((directory/'job.json').read_text())
        assert audit['complete'] and not audit['failures']
        assert audit['attemptedObservations']==104 and audit['measuredObservations']==96 and audit['attemptedCommands']==119
        native=[{key:record[key] for key in native_keys} for record in audit['termCounterRecords']]
        assert all([record[key] for key in native_keys]==native_expected for record in native)
        cells[replication]={
            'jobId':job['id'],'artifactId':download['artifact']['id'],
            'originalZipSha256':download['sha256'],'originalZipBytes':download['bytes'],
            'originalZipPayloadFiles':download['filePayloads'],
            'auditSha256':sha(directory/'independent-audit-001.json'),
            'jobLogSha256':sha(directory/f"job-{job['id']}.log"),
            'host':audit['host'],'browserRuntime':audit['browserRuntime'],
            'attemptedObservations':104,'measuredObservations':96,'warmups':8,'completedCommands':119,
            'harnessInputsVerified':audit['harnessInputsVerified'],
            'sharedInputsVerifiedPerArm':audit['sharedProductInputsVerifiedPerArm'],
            'sourceIdentities':audit['sourceIdentities'],'packageSha256':audit['packageSha256'],
            'packageEntryCount':audit['packageEntryCount'],
            'sameSourcePackageEntryEquality':audit['sameSourcePackageEntryEquality'],
            'candidatePackageChanges':audit['candidatePackageChanges'],
            'armTimingsMs':audit['armTimingsMs'],'comparisons':audit['comparisons'],
            'selectedPhaseMediansMs':{arm:{key:columns[key] for key in ['dedupCanonicalScanMs','dedupScanMs','dedupExactCompareMs','finalizationTotalMs']} for arm,columns in audit['phaseMediansMs'].items()},
            'allPhaseMediansMs':audit['phaseMediansMs'],
            'termCounterRecordCount':len(audit['termCounterRecords']),
            'finalizationCounterRecordCount':len(audit['finalizationCounterRecords']),
            'nativeCounterRecords':native,'exactAndRecentSourceHits':audit['exactAndRecentSourceHits'],
            'sampledContentDigests':audit['sampledContentDigests'],'verifiedProbeExpressions':audit['verifiedProbeExpressions'],
            'observedDirtyFlags':audit['observedDirtyFlags'],'limits':audit['limits'],
        }
    database='ext/js/dictionary/dictionary-database.js'
    source_sha=hashlib.sha256(subprocess.check_output(['git','show','bde55dfbee1451edc32051f8bf51e8a870d5c72c:'+database],cwd=REPO)).hexdigest()
    result={'study':'native-config-v2','toolingCommit':'72b8ab5471fc68e369a54d884efbbea933699d7c',
            'toolingTree':'e50ac7c7f7cf892a0e8dc666f5176f97e8800455','workflowRunId':44729808376,
            'manifestSha256':'66062489217d31a117ee7892c4f51190ccb51b837886f2c1cdaef857e6b2afa7',
            'auditorSha256':sha(ROOT/'audit-chromium.py'),'summaryGeneratorSha256':sha(Path(__file__)),
            'auditorPreparationReceiptSha256':sha(ROOT/'chromium-auditor-preparation.json'),
            'countsOnlyAcrossCells':{'observations':208,'measured':192,'warmups':16,'completedCommands':238,'failures':0},
            'cells':cells,
            'phaseDefinitions':{
                'source':{'commit':'bde55dfbee1451edc32051f8bf51e8a870d5c72c','path':database,'sha256':source_sha},
                'dedupScanMs':'Wall span around _resolveArtifactTermContentDedup plus the following result/metrics bookkeeping; it includes nested work.',
                'dedupCanonicalScanMs':'Canonical-scanning wall span minus accumulated dedupExactCompareMs, clamped at zero; it includes adapter and surrounding work and is not isolated native kernel time.',
                'dedupExactCompareMs':'Accumulated wall spans resolving exact candidate groups, including their resolution bookkeeping.',
                'interpretation':'Phase medians are descriptive and nested; do not add/subtract them to estimate independent stage savings or complete-import effects.'},
            'conclusion':'Neither Chromium cell establishes a whole-import benefit. Both candidate intervals in each cell include zero; candidate point estimates are comparable to same-source control movement. Static removal of configuration loads does not establish a native or complete-import saving.',
            'limits':['No pooling, control subtraction, retries, sample extension or discarded tails. Each comparison retains all 24 paired changes and its worst pair.',
                      'Chromium source probes verify bounds, readability and previews for 12 expressions before and after a full browser restart; they do not compare full expected reading/glossary tuples or all persisted bytes.',
                      'Positive native counters establish 12 native calls scanning 364,869 rows in every observation; all executed work/counter records and worker timing projections were checked.',
                      'The reported 38,928,384-byte maximum is one parser WASM heap, not process peak memory.',
                      'Every exact-match check hit recent-source cache; no uncached exact-match read is observed. Reader hash-helper invocation counts are not instrumented; zero writer envelope timers do not prove reader nonexecution.',
                      'Firefox cells remain separate and were not used in this summary.']}
    OUTPUT.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'output':str(OUTPUT),'sha256':sha(OUTPUT),'counts':result['countsOnlyAcrossCells'],
                      'auditSha256':{name:cell['auditSha256'] for name,cell in cells.items()},'conclusion':result['conclusion']},indent=2))


if __name__=='__main__':
    main()
