#!/usr/bin/env python3
"""Create one independently hashed analysis copy of an audited Firefox ZIP."""

import argparse
import datetime
import hashlib
import json
from pathlib import Path
import stat
import traceback
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('cell', type=Path)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    receipt_path = args.cell / 'analysis-extraction-receipt.json'
    assert not receipt_path.exists() and not args.destination.exists(), 'Refusing to replace an extraction or receipt'
    download_path = args.cell / 'download.json'
    audit_path = args.cell / 'independent-audit-001.json'
    download = json.loads(download_path.read_text())
    audit = json.loads(audit_path.read_text())
    assert download['ok'] and audit['ok'], 'Only a fully audited original artifact may be extracted'
    archive_path = Path(download['originalZip'])
    archive_bytes = archive_path.read_bytes()
    archive_hash = digest(archive_bytes)
    assert archive_hash == download['sha256'] == audit['archiveSha256']
    receipt = {
        'schemaVersion': 1,
        'startedAt': datetime.datetime.now(datetime.UTC).isoformat(),
        'scriptSha256': digest(Path(__file__).read_bytes()),
        'originalZip': str(archive_path),
        'archiveSha256': archive_hash,
        'archiveBytes': len(archive_bytes),
        'downloadReceiptSha256': digest(download_path.read_bytes()),
        'independentAuditSha256': digest(audit_path.read_bytes()),
        'destination': str(args.destination),
        'scope': 'Separate analysis copy; the original ZIP and independently audited evidence remain unchanged. Every extracted regular-file payload is compared byte-for-byte with its ZIP member.',
    }
    try:
        with zipfile.ZipFile(archive_path) as archive:
            members = archive.infolist()
            assert len(members) == len({member.filename for member in members}), 'Duplicate ZIP members'
            matches = [member.filename for member in members if not member.is_dir() and (member.filename == 'cohort.json' or member.filename.endswith('/cohort.json'))]
            assert len(matches) == 1, 'Expected one cohort root'
            prefix = matches[0][:-len('cohort.json')]
            files = []
            for member in members:
                name = member.filename
                parts = name.rstrip('/').split('/')
                assert name and not name.startswith('/') and '\\' not in name and '\x00' not in name, 'Unsafe ZIP path'
                assert all(part not in ('', '.', '..') for part in parts) and ':' not in parts[0], 'Unsafe ZIP path components'
                kind = stat.S_IFMT(member.external_attr >> 16)
                if member.is_dir():
                    assert kind in (0, stat.S_IFDIR), 'Non-directory ZIP directory entry'
                    continue
                assert kind in (0, stat.S_IFREG), 'Non-regular ZIP payload'
                assert not member.flag_bits & 1, 'Encrypted ZIP payload'
                assert name.startswith(prefix), 'Payload lies outside the cohort root'
                relative = name[len(prefix):]
                assert relative, 'Empty relative payload path'
                files.append((relative, member))
            assert len(files) == audit['payloadFiles'] == download['filePayloads'], 'Payload count differs from audited original'
            assert len(files) == len({relative for relative, _ in files}), 'Duplicate relative payload paths'
            args.destination.mkdir(parents=True, exist_ok=False)
            records = []
            for relative, member in sorted(files):
                data = archive.read(member)
                assert len(data) == member.file_size, 'ZIP payload length mismatch'
                target = args.destination / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as output:
                    output.write(data)
                extracted = target.read_bytes()
                assert extracted == data, 'Extracted payload differs from original ZIP member'
                records.append({'member': member.filename, 'path': relative, 'bytes': len(data), 'sha256': digest(data)})
            receipt['payloadFiles'] = len(records)
            receipt['payloadBytes'] = sum(record['bytes'] for record in records)
            receipt['files'] = records
            receipt['payloadTreeSha256'] = digest(json.dumps(records, sort_keys=True, separators=(',', ':')).encode())
        receipt['archiveSha256After'] = digest(archive_path.read_bytes())
        assert receipt['archiveSha256After'] == archive_hash, 'Original ZIP changed during extraction'
        receipt['ok'] = True
    except Exception as error:
        receipt.update({'ok': False, 'error': str(error), 'traceback': traceback.format_exc()})
        raise
    finally:
        receipt['endedAt'] = datetime.datetime.now(datetime.UTC).isoformat()
        with receipt_path.open('x') as output:
            output.write(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ('ok', 'archiveSha256', 'payloadFiles', 'payloadBytes', 'payloadTreeSha256', 'destination')}, indent=2))


if __name__ == '__main__':
    main()
