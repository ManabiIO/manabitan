#!/usr/bin/env python3
"""Derive the observer's twelve expression probes from the locked source ZIP."""
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

archive, lock_path, output = map(Path, sys.argv[1:])
assert not output.exists(), 'Do not overwrite a source receipt'
fixture = json.loads(lock_path.read_text())['dictionaries']['jmdict']
with archive.open('rb') as stream:
    archive_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
assert archive_hash == fixture['sha256'] and archive.stat().st_size == fixture['sizeBytes']
probes, seen = [], set()
with zipfile.ZipFile(archive) as source:
    banks = sorted((name for name in source.namelist() if re.fullmatch(r'term_bank_\d+\.json', name)),
                   key=lambda name: int(re.search(r'\d+', name).group()))
    assert len(banks) == 53
    for bank in [banks[0], banks[len(banks) // 2], banks[-1]]:
        rows = json.loads(source.read(bank))
        for sample in range(4):
            start = (len(rows) - 1) * sample // 3
            for offset in range(len(rows)):
                row_index = (start + offset) % len(rows)
                term = str(rows[row_index][0] or '').strip()
                if not term or len(term.encode('utf-16-le')) // 2 > 40 or term in seen:
                    continue
                seen.add(term)
                probes.append({'bank': bank, 'rowIndex': row_index, 'expression': term})
                break
assert len(probes) == 12
receipt = {'archiveSha256': archive_hash, 'archiveBytes': archive.stat().st_size,
           'fixtureLockSha256': hashlib.sha256(lock_path.read_bytes()).hexdigest(),
           'generatorSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'banks': len(banks), 'probes': probes,
           'scope': 'Expression-selection oracle only; the Chromium observer does not compare archive-derived readings or full glossaries.'}
output.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({'output': str(output), 'expressions': [p['expression'] for p in probes]}, ensure_ascii=False))
