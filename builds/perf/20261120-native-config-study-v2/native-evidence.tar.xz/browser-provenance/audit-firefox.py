#!/usr/bin/env python3
"""Independent, read-only audit of one frozen Firefox browser-study ZIP."""

import argparse
import collections
import datetime
import functools
import hashlib
import json
import math
from pathlib import Path
import random
import re
import statistics
import subprocess
import traceback
import zipfile


TOOLING_COMMIT = '72b8ab5471fc68e369a54d884efbbea933699d7c'
TOOLING_TREE = 'e50ac7c7f7cf892a0e8dc666f5176f97e8800455'
RUN_ID = 44729808376
MANIFEST_SHA256 = '66062489217d31a117ee7892c4f51190ccb51b837886f2c1cdaef857e6b2afa7'
FIXTURE_SHA256 = '7681ee09f9edfef48a5e50773565da237424eb750bdb0e1e59660784ecd53e8a'
SOURCE_IDS = {
    'baseline': ('bde55dfbee1451edc32051f8bf51e8a870d5c72c', 'd6df511865f88246b21aa4688ff40cc455c719c4'),
    'native-config': ('19b13a550d9b7f2a53f37d74aa36b2ee9c3e7472', 'c8f0aace6e3b11355220f22dfff8e668df97673b'),
}
EXPECTED_ARMS = {'A': 'baseline', 'B': 'native-config', 'C': 'baseline', 'D': 'native-config'}
EXPECTED_PAIRS = {'C/A': ['A', 'C'], 'D/B': ['B', 'D'], 'B/A': ['A', 'B'], 'D/A': ['A', 'D']}
C_SOURCE = 'ext/js/dictionary/wasm/term-content-canonical-scan-v1.c'
WASM_SOURCE = 'dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm'
EXPECTED_PACKAGE_DELTA = ['js/dictionary/wasm/term-content-canonical-scan-v1.c', 'lib/term-content-canonical-scan-v1.wasm']
EXPECTED_EXPERIMENTS = {
    'experimentalGenericSpanCompression': True,
    'experimentalParserWorkers3': True,
    'experimentalSkipFusedParse': False,
    'experimentalLookupScratchReuse': True,
    'experimentalNativeSegmentedLookup': True,
    'experimentalDirectLookupArena': False,
    'experimentalSinglePassLookupCompaction': False,
    'experimentalTermBankSpans': False,
    'experimentalNativeEscapedKeys': False,
    'experimentalValidatedGlossaryReuse': True,
    'experimentalFusedSingleBank': False,
    'experimentalGlobalExactContentReuse': False,
    'experimentalFastGlossaryNormalization': False,
}


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


@functools.cache
def git_hash(repo, revision, relative):
    return sha256(subprocess.check_output(['git', '-C', str(repo), 'show', revision + ':' + relative]))


def stable_json(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def json_digest(value):
    return sha256(stable_json(value).encode())


def close(actual, expected):
    if isinstance(actual, dict):
        return isinstance(expected, dict) and actual.keys() == expected.keys() and all(close(value, expected[key]) for key, value in actual.items())
    if isinstance(actual, list):
        return isinstance(expected, list) and len(actual) == len(expected) and all(close(a, b) for a, b in zip(actual, expected))
    if type(actual) is float:
        return type(expected) in (int, float) and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-10)
    return actual == expected


def schedule(replication):
    result = []
    for warmup, order in enumerate(['ABCD', 'DCBA']):
        if replication == 'reverse':
            order = order[::-1]
        result.extend({'label': f'warmup-{warmup + 1}-{arm}', 'arm': arm, 'warmup': True, 'block': warmup} for arm in order)
    for block in range(24):
        order = ['ABCD', 'BDAC', 'CADB', 'DCBA'][block % 4]
        if replication == 'reverse':
            order = order[::-1]
        result.extend({'label': f'block-{block + 1:02d}-{arm}', 'arm': arm, 'warmup': False, 'block': block} for arm in order)
    return result


def pair_statistics(pairs):
    changes = [100 * (candidate / baseline - 1) for baseline, candidate in pairs]
    rng = random.Random(20261119)
    resamples = sorted(statistics.median(rng.choices(changes, k=len(changes))) for _ in range(10000))
    return {
        'pairs': len(pairs), 'pairedChangesPercent': changes,
        'medianPairedChangePercent': statistics.median(changes),
        'equalWorkChangePercent': 100 * (sum(candidate for _, candidate in pairs) / sum(baseline for baseline, _ in pairs) - 1),
        'fasterPairs': sum(candidate < baseline for baseline, candidate in pairs),
        'worstPairPercent': max(changes),
        'descriptiveBootstrap95Percent': [resamples[250], resamples[9749]],
    }


def distribution(values):
    values = sorted(values)
    return {'count': len(values), 'min': values[0], 'median': statistics.median(values), 'p95': values[math.ceil(0.95 * len(values)) - 1], 'max': values[-1]}


def source_probes(path):
    data = path.read_bytes()
    check(sha256(data) == FIXTURE_SHA256 and len(data) == 15587032, 'Local oracle fixture identity differs')
    probes = []
    expressions = set()
    with zipfile.ZipFile(path) as archive:
        names = sorted((name for name in archive.namelist() if name.startswith('term_bank_') and name.endswith('.json')), key=lambda name: int(name[10:-5]))
        check(len(names) == 53, 'Wrong fixture bank count')
        for bank_index in [0, len(names) // 2, len(names) - 1]:
            bank = names[bank_index]
            rows = json.loads(archive.read(bank))
            for sample in range(4):
                start = math.floor((len(rows) - 1) * sample / 3)
                for offset in range(len(rows)):
                    row_index = (start + offset) % len(rows)
                    row = rows[row_index]
                    expression = row[0]
                    if not isinstance(expression, str) or not expression or len(expression.encode('utf-16-le')) // 2 > 40 or expression in expressions:
                        continue
                    if not isinstance(row[5], list) or not all(isinstance(item, str) for item in row[5]):
                        continue
                    expressions.add(expression)
                    probes.append({'bank': bank, 'rowIndex': row_index, 'expression': expression, 'reading': row[1] or expression, 'glossary': row[5]})
                    break
    check(len(probes) == 12, 'Source probe selection incomplete')
    return probes


def audit(args):
    check(re.fullmatch(r'[0-9a-f]{40}', TOOLING_COMMIT) is not None and RUN_ID > 0, 'Bind the published v2 head/run before auditing any result')
    probes = source_probes(args.fixture)
    expected_semantics = [{key: probe[key] for key in ('expression', 'reading', 'glossary')} for probe in probes]
    with zipfile.ZipFile(args.archive) as archive:
        names = archive.namelist()
        check(len(names) == len(set(names)), 'Duplicate archive members')
        check(archive.testzip() is None, 'ZIP CRC validation failed')
        matches = [name for name in names if name == 'cohort.json' or name.endswith('/cohort.json')]
        check(len(matches) == 1, 'Expected one cohort.json')
        prefix = matches[0][:-len('cohort.json')]
        read_bytes = lambda relative: archive.read(prefix + relative)
        read = lambda relative: json.loads(read_bytes(relative))
        manifest = read('manifest.json')
        preparation = read('preparation.json')
        cohort = read('cohort.json')
        check(sha256(read_bytes('manifest.json')) == MANIFEST_SHA256, 'Unexpected measured manifest')
        check(preparation['manifestSha256'] == cohort['manifestSha256'] == MANIFEST_SHA256, 'Manifest receipt mismatch')
        check(preparation['diagnosticCommit'] == TOOLING_COMMIT, 'Wrong measured tooling commit')
        check(preparation['complete'] and cohort['complete'] and not cohort['failures'], 'Incomplete or failed cohort')
        check((preparation['browser'], preparation['replication'], preparation['dictionary']) == ('firefox', args.replication, 'jmdict'), 'Wrong preparation cell')
        check((cohort['browser'], cohort['replication'], cohort['dictionary']) == ('firefox', args.replication, 'jmdict'), 'Wrong cohort cell')
        check(preparation['node'] == manifest['node'] == 'v22.22.0', 'Unexpected Node version')
        check(manifest['arms'] == EXPECTED_ARMS, 'Arm assignment changed')
        check(manifest['comparisonPairs'] == EXPECTED_PAIRS, 'Comparison set changed')
        check(len(manifest['harnessSha256']) == 54 and len(manifest['sharedProductInputs']) == 34, 'Frozen input counts changed')
        for source, expected in SOURCE_IDS.items():
            check((manifest['sources'][source]['commit'], manifest['sources'][source]['tree']) == expected, f'Wrong source identity: {source}')
        for relative, expected in manifest['harnessSha256'].items():
            check(sha256(read_bytes('tooling/' + relative)) == expected == git_hash(args.repo, TOOLING_TREE, relative), f'Missing or changed immutable harness input: {relative}')
        check(sha256(read_bytes('driver.py')) == manifest['harnessSha256']['dev/perf/jmdict-native-config-study-v2/run.py'], 'Top-level driver differs')
        check(sha256(read_bytes('workflow.yml')) == manifest['harnessSha256'][manifest['workflow']], 'Top-level workflow differs')

        packages = {arm: read(f'{arm}-package-entries.json') for arm in 'ABCD'}
        check(packages['A'] == packages['C'] and packages['B'] == packages['D'], 'Same-source package entries differ')
        immutable_source_hashes = {}
        for arm_id in 'ABCD':
            arm = preparation['arms'][arm_id]
            role = EXPECTED_ARMS[arm_id]
            source = manifest['sources'][role]
            check((arm['commit'], arm['tree']) == SOURCE_IDS[role], f'Wrong prepared source: {arm_id}')
            actual_source_delta = subprocess.check_output(['git', '-C', str(args.repo), 'diff', '--name-only', SOURCE_IDS['baseline'][0], arm['commit']], text=True).splitlines()
            check(sorted(actual_source_delta) == sorted(source['sourcePaths']), f'Source path declaration differs from immutable Git: {arm_id}')
            immutable_source_hashes[arm_id] = {}
            for relative in sorted(set(source['sourcePaths']) | {C_SOURCE, WASM_SOURCE, 'dev/data/dictionary-wasm/manifest.json'}):
                expected = git_hash(args.repo, arm['commit'], relative)
                immutable_source_hashes[arm_id][relative] = expected
                check(arm['frozenFiles'][relative] == expected, f'Source-dependent file differs from immutable Git: {arm_id}/{relative}')
            for relative, expected in manifest['sharedProductInputs'].items():
                check(arm['frozenFiles'][relative] == expected == git_hash(args.repo, arm['commit'], relative), f'Shared source input changed: {arm_id}/{relative}')
                if relative.startswith('ext/'):
                    check(packages[arm_id][relative.removeprefix('ext/')] == expected, f'Packaged shared runtime input changed: {arm_id}/{relative}')
            for package_name, source_name in {'js/dictionary/wasm/term-content-canonical-scan-v1.c': C_SOURCE, 'lib/term-content-canonical-scan-v1.wasm': WASM_SOURCE, 'lib/term-bank-parser.wasm': 'dev/data/dictionary-wasm/term-bank-parser.wasm'}.items():
                check(packages[arm_id][package_name] == git_hash(args.repo, arm['commit'], source_name), f'Packaged bytes differ from immutable source: {arm_id}/{package_name}')
            check(arm['frozenFiles']['ext/lib/term-content-canonical-scan-v1.wasm'] == packages[arm_id]['lib/term-content-canonical-scan-v1.wasm'], f'Generated WASM differs from package: {arm_id}')
            check(packages[arm_id]['legal-npm.html'] == arm['commonGeneratedOverlay']['ext/legal-npm.html'], f'Common generated overlay not packaged: {arm_id}')
            actual = sorted(name for name in packages['A'].keys() | packages[arm_id].keys() if packages['A'].get(name) != packages[arm_id].get(name))
            expected = [] if role == 'baseline' else EXPECTED_PACKAGE_DELTA
            check(actual == sorted(source['packagePaths']) == expected, f'Unexpected package changes: {arm_id}')
            if role != 'baseline':
                check(arm['changedPackageEntries'] == expected, f'Package difference receipt changed: {arm_id}')
        runtime = preparation['browserRuntime']
        bootstrap = json.loads(args.bootstrap.read_text())
        check(bootstrap['verified'] is True and bootstrap['workflowRunId'] == RUN_ID and bootstrap['sourceToolingCommit'] == TOOLING_COMMIT and bootstrap['runtime'] == runtime, 'Runtime differs from this study verified reuse job')
        runtime_lock = manifest['browserRuntimes']['firefox']
        check(sha256(read_bytes('firefox-runtime.json')) == runtime_lock['receiptSha256'] == bootstrap['runtimeJsonSha256'] == '42ada420f9c7ab4e395a7de94c8a9ec5d435b0e359a5efb4af7fffbac7f2b826', 'Reused runtime JSON byte hash differs')
        check(read('firefox-runtime.json') == runtime, 'Copied runtime receipt differs from preparation')
        runtime_source_artifact = read('firefox-runtime-source-artifact.json')
        check(runtime_source_artifact == bootstrap['sourceArtifactMetadata'], 'Copied source-artifact receipt differs from independent source metadata')
        check(runtime_source_artifact['id'] == runtime_lock['sourceArtifactId'] == 14621448317 and runtime_source_artifact['workflow_run']['id'] == runtime_lock['sourceRunId'] == 44720953991, 'Wrong reused source artifact/run')
        check(runtime_source_artifact['workflow_run']['head_sha'] == runtime_lock['sourceToolingCommit'] == '007f16306b9f8036a9930b653fbffca3c750068e', 'Wrong runtime source tooling commit')
        check(runtime_source_artifact['digest'] == 'sha256:' + runtime_lock['sourceArtifactSha256'] and runtime_source_artifact['size_in_bytes'] == runtime_lock['sourceArtifactBytes'] and runtime_source_artifact['name'] == runtime_lock['sourceArtifactName'] and runtime_source_artifact['expired'] is False, 'Runtime source artifact identity changed')
        check(runtime['officialMozillaBuild'] is True and runtime['schemaVersion'] == 1, 'Missing official Mozilla verification')
        check(runtime['geckodriver']['version'] == '0.37.1', 'Unexpected geckodriver release')
        check(runtime['geckodriver']['archiveSha256'] == 'e815130ea95983e162ae91843b48d3a3ce991735635fce83a647afde21e09f7e', 'Unexpected driver archive')
        check(runtime['geckodriver']['binarySha256'] == preparation['geckodriverSha256'], 'Driver binary receipt differs')
        check(runtime['resolvedUrl'].startswith(('https://archive.mozilla.org/pub/devedition/releases/', 'https://download-installer.cdn.mozilla.net/pub/devedition/releases/')), 'Unexpected official runtime URL')
        expected_schedule = schedule(args.replication)
        check(len(expected_schedule) == len(cohort['observations']) == 104 and cohort['planned'] == expected_schedule, 'Schedule incomplete or changed')
        fixture = preparation['fixture']
        check(fixture['sha256'] == FIXTURE_SHA256 and fixture['termRows'] == 526942, 'Wrong fixture')
        all_command_receipts = [name[len(prefix):] for name in names if name.startswith(prefix + 'commands/') and name.endswith('/command.json')]
        command_failures = []
        for relative in all_command_receipts:
            command = read(relative)
            if command.get('complete') is not True or command.get('exitCode') != 0 or command.get('timedOut') or command.get('error'):
                command_failures.append({'path': relative, 'receipt': command})
        check(not command_failures, 'At least one preparation/observation command failed')

        profiles = set()
        versions = set()
        semantics_digests = set()
        storage_digests = set()
        environments = collections.Counter()
        effective_flags = collections.Counter()
        term_work = collections.Counter()
        final_work = collections.Counter()
        by_arm = {arm: [] for arm in 'ABCD'}
        term_timers = {arm: collections.defaultdict(list) for arm in 'ABCD'}
        final_timers = {arm: collections.defaultdict(list) for arm in 'ABCD'}
        observed_hosts = {}
        diagnostic_errors = []
        for planned, observation in zip(expected_schedule, cohort['observations']):
            label = planned['label']
            arm_id = planned['arm']
            arm = preparation['arms'][arm_id]
            check(all(observation[key] == value for key, value in planned.items()) and not observation.get('error'), f'Wrong observation order/status: {label}')
            check((arm['commit'], arm['tree']) == SOURCE_IDS[manifest['arms'][arm_id]], f'Wrong observed source declaration: {label}')
            command = read(observation['command'])
            check(command['command'] == ['node', 'test/firefox/jmdict-import-observation.js'], f'Wrong observer command: {label}')
            check(command['cwd'] == arm['root'], f'Wrong observer working directory: {label}')
            summary = read(observation['directory'] + '/summary.json')
            check(summary['schemaVersion'] == 1 and summary['completed'] and summary['authoritativeTiming'] and not summary['skippedVerification'], f'Incomplete helper: {label}')
            check(summary['error'] is None and summary['cleanupErrors'] == [], f'Helper or cleanup failure: {label}')
            diagnostic_errors.extend({'label': label, 'error': error} for error in summary['diagnosticErrors'])
            source = summary['source']
            check((source['commit'], source['tree']) == (arm['commit'], arm['tree']), f'Observed source mismatch: {label}')
            check(source['commonGeneratedOverlay'] == arm['commonGeneratedOverlay'], f'Legal overlay mismatch: {label}')
            check(source['packageLockSha256'] == arm['frozenFiles']['package-lock.json'], f'Dependency lock mismatch: {label}')
            check(summary['package']['sha256'] == arm['packageSha256'], f'Package mismatch: {label}')
            check(all(summary['fixture'][key] == value for key, value in fixture.items()), f'Fixture receipt mismatch: {label}')
            check(summary['fixture']['probes'] == probes, f'Independent archive probe derivation mismatch: {label}')
            check(summary['fixture']['lockSha256'] == arm['frozenFiles']['test/perf/dictionaries.lock.json'], f'Fixture lock mismatch: {label}')
            check(summary['runtime']['node'] == 'v22.22.0' and summary['runtime']['headless'] is False, f'Runtime configuration changed: {label}')
            check(summary['runtime']['binarySha256'] == runtime['binarySha256'] and summary['runtime']['geckodriverSha256'] == preparation['geckodriverSha256'], f'Runtime identity changed: {label}')
            check(summary['tooling']['helperSha256'] == manifest['harnessSha256']['test/firefox/jmdict-import-observation.js'], f'Observer changed: {label}')
            check(summary['tooling']['timingFileSha256'] == manifest['harnessSha256']['test/e2e/import-timing.js'], f'Timing instrumentation changed: {label}')
            browser = summary['browser']
            check(browser['freshProfile'] is True and browser['suppliedProfile'] is False and browser['profile'] not in profiles, f'Profile reused: {label}')
            profiles.add(browser['profile'])
            versions.add(browser['version'])
            timing = summary['timing']
            check(timing['trigger'] == 'file-input-change' and timing['sequence'] > timing['sequenceBefore'] >= 0 and timing['errorCount'] == 0, f'Invalid current-operation timing: {label}')
            duration = timing['completedAtMs'] - timing['startedAtMs']
            check(math.isfinite(duration) and duration > 0 and duration == summary['totalImportMs'] == observation['totalImportMs'], f'Timing boundary mismatch: {label}')
            reload = summary['reload']
            check(reload['kind'] == 'addon-manager-reload-from-browser-chrome' and reload['priorOrigin'] != reload['nextOrigin'] and reload['browserRestarted'] is False and reload['reimported'] is False, f'Reload realm was not changed: {label}')
            for phase in ('beforeReload', 'afterReload'):
                persisted = summary[phase]
                check(persisted['probeCount'] == 12 and persisted['semantics'] == expected_semantics, f'Expected expression/reading/full glossary mismatch: {label}/{phase}')
                check(persisted['semanticDigest'] == json_digest(persisted['semantics']), f'Semantic digest mismatch: {label}/{phase}')
                check(persisted['storageSampleDigest'] == json_digest(persisted['samples']), f'Storage sample digest mismatch: {label}/{phase}')
                check(persisted['counts']['counts'][0]['terms'] == 526942, f'Persisted row count mismatch: {label}/{phase}')
                check(len(persisted['dictionaryInfo']) == 1 and persisted['dictionaryInfo'][0]['title'] == fixture['expectedTitle'] and persisted['dictionaryInfo'][0]['revision'] == fixture['revision'], f'Persisted dictionary identity mismatch: {label}/{phase}')
                check(persisted['storage']['usesFallbackStorage'] is False and persisted['storage']['openStorageDiagnostics']['mode'] == 'opfs-sahpool', f'Persisted storage path changed: {label}/{phase}')
                check([sample['expression'] for sample in persisted['samples']] == [probe['expression'] for probe in probes], f'Storage samples refer to different terms: {label}/{phase}')
                for sample in persisted['samples']:
                    check(sample['totalLength'] > 0 and sample['rows'], f'Empty persisted sample: {label}/{phase}')
                    for row in sample['rows']:
                        check(row['offset'] >= 0 and row['length'] > 0 and row['offset'] + row['length'] <= sample['totalLength'], f'Persisted row out of bounds: {label}/{phase}')
                        check(row['glossaryLength'] > 0 and row['rawContentPreview'] not in (None, '', '<read-null>', '<read-failed>'), f'Unreadable persisted content: {label}/{phase}')
            before = summary['beforeReload']
            after = summary['afterReload']
            check(before['semanticDigest'] == after['semanticDigest'] and before['storageSampleDigest'] == after['storageSampleDigest'] and before['counts'] == after['counts'], f'Persistence changed across reload: {label}')
            check(summary['validation'] == observation['validation'] and summary['validation']['extensionReloadVerified'] is True, f'Validation projection mismatch: {label}')
            check(summary['validation']['termRows'] == 526942 and summary['validation']['probeCount'] == 12 and summary['validation']['semanticDigest'] == before['semanticDigest'] and summary['validation']['storageSampleDigest'] == before['storageSampleDigest'], f'Validation digest/count mismatch: {label}')
            semantics_digests.add(before['semanticDigest'])
            storage_digests.add(before['storageSampleDigest'])
            environment = summary['productionEnvironment']
            check(environment['flags'] is None and environment['profiling'] is False and environment['useSession'] is not False and environment['disableIntegrityCounts'] is not True and environment['sharedArrayBuffer'] is True, f'Production environment altered: {label}')
            environments[stable_json(environment)] += 1
            effective_flags[stable_json(summary['effectiveExperiments'])] += 1
            check(summary['effectiveExperiments'] == EXPECTED_EXPERIMENTS, f'Effective production flags changed: {label}')
            term_work[stable_json(summary['termFileWork'])] += 1
            final_work[stable_json(summary['finalizationWork'])] += 1
            debug = summary['importResult']['debug']
            check(debug == observation['importDebug'], f'Import diagnostics projection differs: {label}')
            check(summary['importResult']['timing'] == timing and not summary['importResult'].get('error'), f'Import result timing/status mismatch: {label}')
            check(debug['hasResult'] is True and debug['resultTitle'] == fixture['expectedTitle'] and debug['errorCount'] == 0 and debug['addSettingsErrorCount'] == 0, f'Import completion status failed: {label}')
            check(debug['usesFallbackStorage'] is False and debug['openStorageDiagnostics']['mode'] == 'opfs-sahpool', f'Non-native storage path: {label}')
            worker_phases = [phase for phase in debug['localPhaseTimings'] if phase['phase'] == 'worker-import-dictionary']
            check(len(worker_phases) == 1 and math.isfinite(worker_phases[0]['elapsedMs']) and worker_phases[0]['elapsedMs'] > 0, f'Worker timing missing or invalid: {label}')
            check(worker_phases[0]['elapsedMs'] == summary['workerImportMs'] == observation['workerImportMs'], f'Worker timing projection differs: {label}')
            phases = debug['importerPhaseTimings']
            reported_experiments = [value for phase in phases for key, value in phase.get('details', {}).items() if key in ('parserExperiments', 'fastPathParserExperiments', 'fastPathParserEffectiveExperiments', 'compressionExperiments')]
            check(len(reported_experiments) >= 2 and all(value == EXPECTED_EXPERIMENTS for value in reported_experiments), f'Executed production flags changed: {label}')
            terms = [phase for phase in phases if phase['phase'].startswith('term-file')]
            check(terms and all(phase['phase'].startswith('term-file-fast-path:') for phase in terms), f'Non-native term path: {label}')
            for key, expected in {'rows': 526942, 'parserSourceCompressedBytes': 15574114, 'parserSourceTransferredBytes': 15574114, 'parserSourceUncompressedBytes': 171092992}.items():
                check(sum(phase['details'].get(key, 0) for phase in terms) == expected, f'Wrong work counter {key}: {label}')
            for term in terms:
                check(all(term['details'].get(key) == 0 for key in ('parserFusedFallbacks', 'dedupNativeFallbackCount', 'parserDiscardedFusedRows', 'sourceInitialPrefetchFileCount', 'sourceInitialPrefetchEstimatedBytes')), f'Fallback/discard/prefetch policy changed: {label}')
            finalization = [phase['details'] for phase in phases if phase['phase'] == 'bulk-finalization']
            check(len(finalization) == 1 and finalization[0]['ok'] is True and finalization[0]['published'] is True and finalization[0]['housekeepingErrors'] == [], f'Publication failed: {label}')
            projected_term_work = [{'phase': phase['phase'], 'counters': {key: value for key, value in phase['details'].items() if type(value) in (int, float) and not key.endswith('Ms') and re.search(r'(?:Count|Bytes|Rows|Fallbacks)$|^(?:rows|chunkCount)$', key)}} for phase in terms]
            projected_final_work = {key: value for key, value in finalization[0].items() if type(value) in (int, float) and not key.endswith('Ms')}
            check(projected_term_work == summary['termFileWork'] and projected_final_work == summary['finalizationWork'], f'Work counter projection differs from executed diagnostics: {label}')
            if not planned['warmup']:
                by_arm[arm_id].append({'block': planned['block'], 'totalImportMs': duration, 'workerImportMs': summary['workerImportMs']})
                counters = collections.defaultdict(float)
                for term in terms:
                    for key, value in term['details'].items():
                        if key.endswith('Ms') and type(value) in (int, float):
                            counters[key] += value
                for key, value in counters.items():
                    term_timers[arm_id][key].append(value)
                for key, value in finalization[0].items():
                    if key.endswith('Ms') and type(value) in (int, float):
                        final_timers[arm_id][key].append(value)
            observed_hosts.setdefault(arm_id, summary['hostBefore'])

        check(len(profiles) == 104 and len(versions) == len(semantics_digests) == len(storage_digests) == 1, 'Cross-arm profile/version/content identity mismatch')
        comparisons = {}
        indexed = {(observation['block'], arm): observation for arm, observations in by_arm.items() for observation in observations}
        check(len(indexed) == 96, 'Duplicate or missing measured observation')
        for label, (baseline, candidate) in EXPECTED_PAIRS.items():
            comparisons[label] = pair_statistics([(indexed[(block, baseline)]['totalImportMs'], indexed[(block, candidate)]['totalImportMs']) for block in range(24)])
            check(close(comparisons[label], cohort['statistics'][label]), f'Independent paired statistics differ: {label}')
        return {
            'ok': True, 'browser': 'firefox', 'replication': args.replication,
            'toolingCommit': TOOLING_COMMIT, 'toolingTree': TOOLING_TREE, 'workflowRunId': RUN_ID, 'manifestSha256': MANIFEST_SHA256,
            'archiveSha256': sha256(args.archive.read_bytes()), 'archiveBytes': args.archive.stat().st_size,
            'payloadFiles': sum(not item.is_dir() for item in archive.infolist()),
            'embeddedHarnessInputs': len(manifest['harnessSha256']),
            'sourceIdentities': {arm: {key: preparation['arms'][arm][key] for key in ('source', 'commit', 'tree', 'packageSha256', 'commonGeneratedOverlay')} for arm in 'ABCD'},
            'immutableProductFileHashes': immutable_source_hashes,
            'runtimeBootstrapReceiptSha256': sha256(args.bootstrap.read_bytes()),
            'runtimeJsonSha256': sha256(read_bytes('firefox-runtime.json')), 'runtimeSourceArtifactReceiptSha256': sha256(read_bytes('firefox-runtime-source-artifact.json')), 'runtimeSourceArtifact': runtime_source_artifact,
            'browserRuntime': runtime, 'browserVersion': next(iter(versions)), 'freshProfiles': len(profiles),
            'observations': 104, 'measured': 96, 'warmups': 8, 'commandReceipts': len(all_command_receipts), 'commandFailures': command_failures,
            'semanticDigest': next(iter(semantics_digests)), 'storageSampleDigest': next(iter(storage_digests)),
            'independentlyDerivedSourceProbes': probes, 'reloadType': 'extension realm reload; not browser restart',
            'productionEnvironmentVariants': {key: count for key, count in environments.items()},
            'effectiveExperimentVariants': {key: count for key, count in effective_flags.items()},
            'termWorkVariants': {key: count for key, count in term_work.items()},
            'finalizationWorkVariants': {key: count for key, count in final_work.items()},
            'diagnosticErrors': diagnostic_errors, 'hosts': observed_hosts,
            'armTimings': {arm: distribution([observation['totalImportMs'] for observation in observations]) for arm, observations in by_arm.items()},
            'comparisons': comparisons,
            'termPhaseMedians': {arm: {key: statistics.median(values) for key, values in counters.items()} for arm, counters in term_timers.items()},
            'finalizationPhaseMedians': {arm: {key: statistics.median(values) for key, values in counters.items()} for arm, counters in final_timers.items()},
            'limitations': ['No browser/order/arm pooling or control subtraction; C/A and D/B are separate same-source controls.', 'Intervals are descriptive and do not correct temporal dependence or multiple comparisons.', 'Twelve exact source-derived terms and storage samples are not an exhaustive persisted-byte oracle.', 'Reload changes the extension realm, not the browser process.', 'Runtime identity is audited from the verified bootstrap and observed binary receipts; the large runtime archive is not redownloaded.', 'Nested phase timers are not additive whole-import savings.'],
        }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('archive', type=Path)
    parser.add_argument('replication', choices=['forward', 'reverse'])
    parser.add_argument('--fixture', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--bootstrap', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    check(not args.output.exists(), 'Refusing to overwrite an earlier audit attempt')
    receipt = {'auditedAt': datetime.datetime.now(datetime.UTC).isoformat(), 'auditScriptSha256': sha256(Path(__file__).read_bytes()), 'archive': str(args.archive)}
    try:
        receipt.update(audit(args))
    except Exception as error:
        receipt.update({'ok': False, 'error': str(error), 'traceback': traceback.format_exc()})
        args.output.write_text(json.dumps(receipt, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
        raise
    args.output.write_text(json.dumps(receipt, ensure_ascii=False, indent=2, allow_nan=False) + '\n')
    print(json.dumps({key: receipt[key] for key in ('ok', 'replication', 'archiveSha256', 'observations', 'measured', 'freshProfiles', 'embeddedHarnessInputs', 'comparisons')}, indent=2))


if __name__ == '__main__':
    main()
