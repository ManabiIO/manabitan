from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import time

root = Path('/workspace/scratch/f34c9c9fae89/manabitan')
workspace = root.parent
baseline = workspace / 'manabitan-baseline'
cache = root / 'builds/e2e-dictionary-cache'
outdir = root / 'builds/perf/20261119'
cases = {}

def add(name, runner, fixture, candidate, order='AB', extra=()):
    source = baseline if candidate == 'baseline' else workspace / ('manabitan-' + candidate)
    args = ['node', str(runner), fixture, '--source-root', str(source), '--baseline-root', str(baseline), '--pairs', '8', '--initial-order', order]
    args.extend(extra)
    args.extend(['--out', str(outdir / (name + '.json'))])
    cases[name] = args

lookup = root / 'dev/perf/import-lookup-screen.js'
dedup = root / 'dev/perf/import-dedup-screen.js'
keys = workspace / 'manabitan-keys/dev/perf/term-key-reuse-screen.js'
lookup_extra = ['--cache-dir', str(cache), '--flags', '{}', '--passes', '3']
dedup_extra = ['--cache-dir', str(cache)]
add('parser-aa3-jmdict', lookup, 'jmdict', 'baseline', extra=lookup_extra)
for candidate, order in [('keys', 'AB'), ('escapes', 'BA')]:
    for dictionary in ['jmdict', 'jmnedict', 'jitendex']:
        add(candidate + '-screen-' + dictionary, lookup, dictionary, candidate, order, lookup_extra)
add('dedup-aa-jmdict', dedup, 'jmdict', 'baseline', 'BA', dedup_extra)
for dictionary in ['jmdict', 'jmnedict', 'jitendex']:
    add('dedup-screen-' + dictionary, dedup, dictionary, 'storage', 'AB', dedup_extra)
add('dedup-high-memory-jmdict', dedup, 'jmdict', 'storage', 'BA', dedup_extra + ['--device-memory-gib', '8'])
for lane in ['runs', 'unique', 'shared-prefix', 'escaped-runs']:
    add('keys-control-' + lane, keys, lane, 'keys')

selected = sys.argv[1:] or list(cases)
for name in selected:
    command = cases[name]
    output = outdir / (name + '.json')
    if output.exists():
        raise RuntimeError('Refusing to overwrite prior observations: ' + str(output))
    log = outdir / (name + '.log')
    receipt = {'name': name, 'command': command, 'startedAt': datetime.now(timezone.utc).isoformat(), 'runnerSha256': hashlib.sha256(Path(command[1]).read_bytes()).hexdigest()}
    receipt_path = outdir / (name + '.command.json')
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(receipt['startedAt'], 'START', name, flush=True)
    started = time.monotonic()
    with log.open('w') as stream:
        proc = subprocess.run(command, cwd=root, stdout=stream, stderr=subprocess.STDOUT)
    receipt['exitCode'] = proc.returncode
    receipt['durationSeconds'] = time.monotonic() - started
    receipt['completedAt'] = datetime.now(timezone.utc).isoformat()
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    if proc.returncode:
        print(log.read_text()[-6000:], flush=True)
        raise SystemExit(proc.returncode)
    result = json.loads(output.read_text())
    if result.get('complete') is False or result.get('failures'):
        raise RuntimeError('Incomplete cohort: ' + name)
    print(receipt['completedAt'], 'DONE', name, json.dumps(result.get('summary')), flush=True)
