#!/usr/bin/env python3
"""Audit retained native-study v1 preparation failures; no speed estimates exist."""
import argparse
import datetime
import functools
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import traceback
import zipfile

REPOSITORY=Path('/workspace/scratch/f34c9c9fae89/manabitan-native-config-study')
TOOLING='5e2dea241ac11ef7b75c407c2ee1c878e1fd4091'
TREE='0918840aa460073311dc15fed9e693e82c4c9546'
RUN=44727365554
MANIFEST='4fe26bbb5c9f6235b36ec10c1e19adb68733cbbd9d6c58b34ca3775b32384776'
SOURCES={'baseline':('bde55dfbee1451edc32051f8bf51e8a870d5c72c','d6df511865f88246b21aa4688ff40cc455c719c4'),
         'native-config':('19b13a550d9b7f2a53f37d74aa36b2ee9c3e7472','c8f0aace6e3b11355220f22dfff8e668df97673b')}
ARMS={'A':'baseline','B':'native-config','C':'baseline','D':'native-config'}
PAIRS={'C/A':['A','C'],'D/B':['B','D'],'B/A':['A','B'],'D/A':['A','D']}
C_SOURCE='ext/js/dictionary/wasm/term-content-canonical-scan-v1.c'
WASM='dev/data/dictionary-wasm/term-content-canonical-scan-v1.wasm'
C_ENTRY=C_SOURCE.removeprefix('ext/')
WASM_ENTRY='lib/term-content-canonical-scan-v1.wasm'
ACTUAL_DELTA=[C_ENTRY,WASM_ENTRY]
FAILURE="Unexpected packaged product differences for B: ['js/dictionary/wasm/term-content-canonical-scan-v1.c', 'lib/term-content-canonical-scan-v1.wasm']"


def check(value,message):
    if not value:
        raise RuntimeError(message)


def read(path):
    return json.loads(path.read_text())


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


@functools.cache
def git_hash(revision,name):
    return hashlib.sha256(subprocess.check_output(['git','show',revision+':'+name],cwd=REPOSITORY)).hexdigest()


def audit(root,replication):
    download=read(root/'download.json')
    job=read(root/'job.json')
    artifact=download['artifact']
    directory=root/'evidence'
    archive=Path(download['originalZip'])
    manifest=read(directory/'manifest.json')
    prep=read(directory/'preparation.json')
    check(artifact['workflow_run']['id']==job['run_id']==RUN,'Wrong workflow run')
    check(artifact['workflow_run']['head_sha']==TOOLING,'Wrong artifact source')
    check(artifact['name']=='jmdict-native-config-study-chromium-'+replication,'Wrong artifact cell')
    check(job['status']=='completed' and job['conclusion']=='failure','Job was not the completed failure')
    check(job['name']=='chromium / '+replication,'Wrong job cell')
    expected_job=136258192364 if replication=='forward' else 136258192573
    check(job['id']==expected_job,'Wrong job id')
    log_path=root/f'job-{expected_job}.log'
    log=log_path.read_text()
    check(FAILURE in log and 'run.py", line 240, in prepare' in log,'Missing precise preparation failure')
    stages={step['name']:step['conclusion'] for step in job['steps']}
    check(stages['Prepare and verify all four packages before timing']=='failure','Wrong failed stage')
    check(stages['Measure fixed Chromium schedule']=='skipped','Measurement was not skipped')
    check(digest(archive)==download['sha256']==artifact['digest'].removeprefix('sha256:'),'Changed original ZIP')
    check(archive.stat().st_size==download['bytes']==artifact['size_in_bytes'],'ZIP size mismatch')
    with zipfile.ZipFile(archive) as payload:
        check(payload.testzip() is None,'ZIP CRC failure')
        files=[entry for entry in payload.infolist() if not entry.is_dir()]
        check(len({entry.filename for entry in files})==len(files),'Duplicate ZIP paths')
        for entry in files:
            name=PurePosixPath(entry.filename)
            check(not name.is_absolute() and '..' not in name.parts,'Unsafe ZIP path')
            extracted=directory.joinpath(*name.parts)
            check(extracted.is_file() and digest(extracted)==hashlib.sha256(payload.read(entry)).hexdigest(),'Changed payload: '+entry.filename)
        archive_inventory={'sha256':digest(archive),'bytes':archive.stat().st_size,'filePayloads':len(files),
                           'uncompressedBytes':sum(entry.file_size for entry in files)}
    check(digest(directory/'manifest.json')==MANIFEST==prep['manifestSha256'],'Wrong frozen manifest')
    check(prep['diagnosticCommit']==TOOLING and prep['complete'] is False,'Wrong/inconsistent preparation identity')
    check(prep['browser']=='chromium' and prep['replication']==replication and prep['dictionary']=='jmdict','Wrong preparation cell')
    check(prep['node']==manifest['node']=='v22.22.0','Wrong Node runtime')
    check(manifest['arms']==ARMS and manifest['comparisonPairs']==PAIRS,'Wrong arms/controls')
    check(manifest['blocks']==24 and manifest['warmupsPerArm']==2,'Changed fixed schedule')
    check(len(manifest['harnessSha256'])==51 and len(manifest['sharedProductInputs'])==34,'Wrong input counts')
    for name,sha in manifest['harnessSha256'].items():
        check(digest(directory/'tooling'/name)==sha==git_hash(TREE,name),'Wrong harness input: '+name)
    check(digest(directory/'driver.py')==manifest['harnessSha256']['dev/perf/jmdict-native-config-study/run.py'],'Changed driver')
    check(digest(directory/'workflow.yml')==manifest['harnessSha256'][manifest['workflow']],'Changed workflow')
    commands={'verify-source-bundle','import-source-bundle','prepare-fixtures'}|{f'{stage}-{arm}' for arm in ARMS for stage in ['worktree','libraries','package']}
    check({p.name for p in (directory/'commands').iterdir()}==commands,'Extra or missing commands')
    command_receipts={}
    for label in sorted(commands):
        path=directory/'commands'/label
        command=read(path/'command.json')
        check(command['complete'] is True and command['exitCode']==0 and not command.get('timedOut') and not command.get('error'),'Unexpected command failure: '+label)
        check((path/'stdout.log').is_file() and (path/'stderr.log').is_file(),'Missing command logs')
        check(command['completedAt']>=command['startedAt'] and command['elapsedSeconds']>=0,'Invalid command timing')
        command_receipts[label]={'exitCode':command['exitCode'],'commandSha256':digest(path/'command.json'),
                                 'stdoutSha256':digest(path/'stdout.log'),'stderrSha256':digest(path/'stderr.log')}
    check(not (directory/'cohort.json').exists(),'Unexpected measurement cohort')
    check(not (directory/'observations').exists(),'Unexpected import observations')
    check('browserRuntime' not in prep,'Runtime-binding stage was unexpectedly reached')
    entries={arm:read(directory/(arm+'-package-entries.json')) for arm in ARMS}
    check(entries['A']==entries['C'] and entries['B']==entries['D'],'Same-source package controls differ')
    changed_packages={}
    overlays=set()
    for arm,role in ARMS.items():
        source=manifest['sources'][role]
        commit,tree=SOURCES[role]
        receipt=prep['arms'][arm]
        check((source['commit'],source['tree'])==(commit,tree),'Wrong declared source')
        check((receipt['commit'],receipt['tree'],receipt['source'])==(commit,tree,role),'Wrong prepared source')
        check(receipt['buildTarget']=='chrome' and receipt['expectedInitialPrefetchFileCount']==0,'Wrong product policy')
        actual_source=subprocess.check_output(['git','diff','--name-only',SOURCES['baseline'][0],commit],cwd=REPOSITORY,text=True).splitlines()
        check(sorted(actual_source)==sorted(source['sourcePaths']),'Unexpected tracked source changes')
        for name,sha in manifest['sharedProductInputs'].items():
            check(receipt['frozenFiles'][name]==sha==git_hash(commit,name),'Wrong shared input: '+name)
        for name in set(source['sourcePaths'])|{C_SOURCE,WASM,'dev/data/dictionary-wasm/manifest.json'}:
            check(receipt['frozenFiles'][name]==git_hash(commit,name),'Wrong source-dependent file: '+name)
        for package_name,source_name in {C_ENTRY:C_SOURCE,WASM_ENTRY:WASM,'lib/term-bank-parser.wasm':'dev/data/dictionary-wasm/term-bank-parser.wasm'}.items():
            check(entries[arm][package_name]==git_hash(commit,source_name),'Packaged bytes differ from committed source: '+package_name)
        check(receipt['frozenFiles']['ext/'+WASM_ENTRY]==entries[arm][WASM_ENTRY],'Built WASM differs from package entry')
        overlay=receipt['commonGeneratedOverlay']['ext/legal-npm.html']
        check(receipt['frozenFiles']['ext/legal-npm.html']==entries[arm]['legal-npm.html']==overlay,'Wrong legal overlay')
        overlays.add(overlay)
        changed=sorted(name for name in entries['A'].keys()|entries[arm].keys() if entries['A'].get(name)!=entries[arm].get(name))
        expected=[] if role=='baseline' else ACTUAL_DELTA
        check(changed==expected,'Unexpected actual package delta beyond documented omission')
        check(source['packagePaths']==([] if role=='baseline' else [WASM_ENTRY]),'Frozen v1 package declaration changed')
        changed_packages[arm]={'actual':changed,'declared':source['packagePaths'],'manifestMatchesActual':changed==source['packagePaths'],
                               'packageEntryCount':len(entries[arm]),'packageSha256':receipt['packageSha256']}
    check(len(overlays)==1,'Legal overlays differ')
    fixture_lock=read(directory/'tooling/test/perf/dictionaries.lock.json')
    check(prep['fixture']==fixture_lock['dictionaries']['jmdict'],'Fixture declaration differs')
    return {'auditComplete':True,'auditPassed':True,'studyComplete':False,'measurementStatus':'failed-before-observations',
            'browser':'chromium','replication':replication,'sourceToolingCommit':TOOLING,'sourceToolingTree':TREE,
            'workflowRunId':RUN,'jobId':job['id'],'artifactId':artifact['id'],'manifestSha256':MANIFEST,
            'originalArchive':archive_inventory,'jobLogSha256':digest(log_path),'preparationSha256':digest(directory/'preparation.json'),
            'harnessInputsVerified':51,'sharedInputsVerified':34,'completedSetupCommands':15,'commandReceipts':command_receipts,
            'plannedObservations':104,'attemptedObservations':0,'warmupObservations':0,'measuredObservations':0,
            'sourceCommits':{arm:SOURCES[role][0] for arm,role in ARMS.items()},'packageContents':changed_packages,
            'sameSourceEntryEquality':{'A/C':True,'B/D':True},'fixture':prep['fixture'],
            'failure':{'stage':'prepare/package-difference-validation','message':FAILURE,
                       'cause':'The frozen v1 package map omitted the normally packaged native C source entry.'},
            'comparisons':{pair:None for pair in PAIRS},'performanceConclusion':'No browser import observations; no performance, correctness-probe, executed-import-path or memory inference is available.',
            'limits':['All four packages built; package entry maps and source hashes were retained, but package ZIPs were not embedded.',
                      'The preparation guard stopped before browser-runtime receipt binding, warmups, persistence probes or timing.',
                      'The 104 artifact payload files are preparation evidence, not 104 observations.',
                      'This failure auditor was written after completed failure logs were observed; it performs no performance analysis.']}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',required=True,type=Path)
    parser.add_argument('--replication',required=True,choices=['forward','reverse'])
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    check(not args.output.exists(),'Refusing to overwrite audit receipt')
    source=Path(__file__).read_bytes()
    snapshot=args.output.with_suffix('.py')
    check(not snapshot.exists(),'Refusing to overwrite auditor snapshot')
    snapshot.write_bytes(source)
    receipt={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'auditorSha256':hashlib.sha256(source).hexdigest(),
             'evidenceRoot':str(args.root),'auditComplete':False,'auditPassed':False}
    try:
        receipt.update(audit(args.root,args.replication))
    except Exception as error:
        receipt['error']=str(error)
        receipt['traceback']=traceback.format_exc()
    receipt['completedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    args.output.write_text(json.dumps(receipt,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'output':str(args.output),'auditPassed':receipt['auditPassed'],'error':receipt.get('error'),
                      'attemptedObservations':receipt.get('attemptedObservations'),'failure':receipt.get('failure')}))
    raise SystemExit(0 if receipt['auditPassed'] else 1)


if __name__=='__main__':
    main()
