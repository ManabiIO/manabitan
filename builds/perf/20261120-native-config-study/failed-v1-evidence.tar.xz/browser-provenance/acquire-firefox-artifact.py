#!/usr/bin/env python3
"""Persist one returned artifact transfer exactly once, retaining failed bytes."""

import argparse
import datetime
import hashlib
import io
import json
from pathlib import Path
import urllib.request
import zipfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('replication', choices=['forward', 'reverse'])
    parser.add_argument('directory', type=Path)
    parser.add_argument('transfer_url')
    parser.add_argument('metadata_json')
    parser.add_argument('job_json')
    parser.add_argument('file_id')
    args = parser.parse_args()
    artifact = json.loads(args.metadata_json)
    job = json.loads(args.job_json)
    expected_job = {'forward': 136258192398, 'reverse': 136258192390}[args.replication]
    assert artifact['name'] == f'jmdict-native-config-study-firefox-{args.replication}'
    assert artifact['workflow_run']['id'] == 44727365554
    assert artifact['workflow_run']['head_sha'] == '5e2dea241ac11ef7b75c407c2ee1c878e1fd4091'
    assert not artifact['expired']
    assert job['id'] == expected_job and job['status'] == 'completed' and job['conclusion'] in ('success', 'failure')
    args.directory.mkdir(parents=True, exist_ok=True)
    destination = args.directory / f'original-{artifact["id"]}.zip'
    receipt_path = args.directory / 'download.json'
    assert not destination.exists() and not receipt_path.exists(), 'Refusing an artifact transfer retry or overwrite'
    receipt = {
        'downloadStartedAt': datetime.datetime.now(datetime.UTC).isoformat(),
        'artifact': artifact,
        'job': job,
        'transferFileId': args.file_id,
        'originalZip': str(destination),
        'acquisitionScriptSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'note': 'Artifact download tool called once; returned bytes transferred once. Signed transfer URL intentionally not retained.'
    }
    try:
        with urllib.request.urlopen(args.transfer_url, timeout=60) as response:
            data = response.read()
        with destination.open('xb') as output:
            output.write(data)
        receipt['sha256'] = hashlib.sha256(data).hexdigest()
        receipt['bytes'] = len(data)
        assert artifact['digest'] == 'sha256:' + receipt['sha256'], 'Artifact SHA256 differs from REST receipt'
        assert artifact['size_in_bytes'] == len(data), 'Artifact length differs from REST receipt'
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            assert archive.testzip() is None, 'ZIP member CRC failed'
            receipt['filePayloads'] = sum(not item.is_dir() for item in archive.infolist())
            receipt['uncompressedBytes'] = sum(item.file_size for item in archive.infolist())
        receipt['zipCrc'] = 'passed'
        receipt['ok'] = True
    except Exception as error:
        receipt['ok'] = False
        receipt['error'] = str(error)
        raise
    finally:
        receipt['downloadEndedAt'] = datetime.datetime.now(datetime.UTC).isoformat()
        with receipt_path.open('x') as output:
            output.write(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({key: receipt[key] for key in ('ok', 'sha256', 'bytes', 'filePayloads', 'zipCrc', 'originalZip')}, indent=2))


if __name__ == '__main__':
    main()
