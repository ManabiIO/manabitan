#!/usr/bin/env python3
"""Deterministically preserve audited originals, excluding only product ZIPs."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile
import zipfile

REPO = Path('/workspace/scratch/5a86d1e7822a/parser-inlining')
RAW = Path('/tmp/manabitan-session-5a86/inline-hosted')
LOCAL = Path('/tmp/manabitan-session-5a86/inline-local')
OUT = REPO / 'builds/perf/parser-inline-20261128-5a86'
OUT.mkdir(parents=True, exist_ok=True)
BASELINE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CANDIDATE = 'ed09ddbd9c20352e4690ade354e91a9bd70392a4'
ARTIFACTS = {
    'AB': (15247255708, 'ead6e407f3c52389e0c120823212b395a40a2c42312d36001a445f04e1fefb9a'),
    'BA': (15246947741, 'bbd66314ff1bf848817857fa7a95f8fdd5edb1494556f4b138874082f304f20a'),
    'validation': (15246695933, '2e63bd8c0e6b3f14ddf2d01fb409193810ee6d0d8137674a4ce60877782fe9f9'),
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


files, originals = {}, {}
for name, (artifact_id, expected) in ARTIFACTS.items():
    data = (RAW / (name + '.zip')).read_bytes()
    assert sha(data) == expected
    members, omitted = {}, []
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        assert len(archive.namelist()) == len(set(archive.namelist()))
        assert archive.testzip() is None
        for info in archive.infolist():
            payload = archive.read(info)
            members[info.filename] = {'bytes': len(payload), 'sha256': sha(payload), 'crc32': info.CRC}
            if info.filename.endswith(('/package-A.zip', '/package-B.zip')):
                arm = info.filename[-5]
                identity = json.loads(archive.read(name + '/source-identities.json'))['arms'][arm]
                assert sha(payload) == identity['packageSha256']
                with zipfile.ZipFile(io.BytesIO(payload)) as package:
                    assert len(package.namelist()) == len(set(package.namelist())) and package.testzip() is None
                    entries = {entry.filename: sha(package.read(entry)) for entry in package.infolist() if not entry.is_dir()}
                assert entries == identity['entries'] and len(entries) == 554
                omitted.append(info.filename)
            elif name != 'validation':
                files['hosted/' + info.filename] = payload
    if name == 'validation':
        assert omitted == []
        files['validation.zip'] = data
    else:
        assert set(omitted) == {name + '/package-A.zip', name + '/package-B.zip'}
    originals[name] = {'artifactId': artifact_id, 'sizeBytes': len(data), 'sha256': expected,
                       'url': f'https://github.com/ManabiIO/manabitan/actions/runs/46102590692/artifacts/{artifact_id}',
                       'members': members, 'omittedMembers': omitted}
for source in sorted(LOCAL.iterdir()):
    if source.is_file():
        files['local/' + source.name] = source.read_bytes()
for filename in ('audit.py', 'audit-AB.json', 'audit-BA.json'):
    files['original-independent-audit/' + filename] = (RAW / filename).read_bytes()
for name in ('AB', 'BA', 'validation'):
    files['job-logs/' + name + '.log'] = (RAW / ('job-' + name + '.log')).read_bytes()
files['packager.py'] = Path(__file__).read_bytes()
support = {}
for name in ('audit_memory.py', 'chromium_memory.py', 'protocol.py', 'qualification_receipts.py'):
    data = (REPO / 'dev/perf/import-memory-20261125-a7f7' / name).read_bytes()
    files['audit-support/' + name] = data
    support[name] = sha(data)
for name, relative in {
    'acquisition-driver.py': 'dev/perf/parser-inline-screen-5a86.py',
    'acquisition-workflow.yml': '.github/workflows/parser-inline-screen-5a86.yml',
    'full-qualifier.py': 'dev/perf/import-qualification-20261125-a7f7.py',
    'component-runner.js': 'dev/perf/import-lookup-screen.js',
    'dictionaries.lock.json': 'test/perf/dictionaries.lock.json',
}.items():
    files['source/' + name] = (REPO / relative).read_bytes()

archive_bytes = io.BytesIO()
with gzip.GzipFile(filename='', mode='wb', fileobj=archive_bytes, mtime=0, compresslevel=9) as compressed:
    with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for name, payload in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size = len(payload)
            info.mode = 0o644
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            archive.addfile(info, io.BytesIO(payload))
packed = archive_bytes.getvalue()
(OUT / 'observations.tar.gz').write_bytes(packed)
hosts = {}
for order in ('AB', 'BA'):
    audited = json.loads((RAW / ('audit-' + order + '.json')).read_text())
    hosts[order] = {key: audited[key] for key in ('imports', 'commonReceiptSha256', 'browser', 'policy', 'analysis', 'memoryAudit')}
local = json.loads((LOCAL / 'jmdict-component-ab-corrected-cache.json').read_text())
summary = {'schema': 1, 'baseline': BASELINE, 'candidate': CANDIDATE,
           'run': 'https://github.com/ManabiIO/manabitan/actions/runs/46102590692',
           'decision': 'No replicated material complete-import gain; retain negative result, no PR and no further acquisition.',
           'hosts': hosts,
           'localComponent': {'failedInitialObservations': 0, 'completedObservations': 12, 'summary': local['summary'],
                              'scope': 'Fixed seven-bank component grouping, not the production planner or a complete import'},
           'validation': {'unitFilesPassed': 669, 'unitTestsPassed': 15135, 'unitTestsSkipped': 47,
                          'observerReceiptTestsPassed': 32, 'pinnedCompilerAndLinker': '21.1.8',
                          'sevenBuildTargets': 'passed', 'jsonFormat': 'passed'},
           'limits': 'Browser semantic checks are sampled plus exact row counts/restart/lookups; separate local component verifies every emitted row/index digest. Sampled process peaks are not exact peaks or a memory reduction claim. Hosts remain separate.'}
summary_bytes = encode(summary)
(OUT / 'summary.json.txt').write_bytes(summary_bytes)
manifest = {'schema': 1, 'baseline': BASELINE, 'candidate': CANDIDATE,
            'baselineTree': 'd99ea4d04658f7ec1c76acdc5f3684594212a471',
            'candidateTree': 'e99da38d8f3d061f1f243f249f83f01470b5424c',
            'run': summary['run'], 'originalArtifacts': originals,
            'jobLogs': {'AB': 'https://github.com/ManabiIO/manabitan/actions/runs/46102590692/job/140850216828',
                        'BA': 'https://github.com/ManabiIO/manabitan/actions/runs/46102590692/job/140850216806',
                        'validation': 'https://github.com/ManabiIO/manabitan/actions/runs/46102590692/job/140848153613'},
            'fixture': json.loads((REPO / 'test/perf/dictionaries.lock.json').read_text())['dictionaries']['jmdict'],
            'retainedArchive': {'path': 'observations.tar.gz', 'sizeBytes': len(packed), 'sha256': sha(packed),
                                'members': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())}},
            'frozenAuditSupport': support,
            'auditorSha256': sha((REPO / 'dev/perf/verify-parser-inline-20261128-5a86.py').read_bytes()),
            'summarySha256': sha(summary_bytes),
            'omissionPolicy': 'Only the four independently verified reproducible product ZIP payloads are omitted from hosted artifacts. Original outer ZIP hashes/sizes, every original member hash/size/CRC, all554 release-member hashes per arm, source/toolchain recipes and original artifact links are retained. The original outer ZIP bytes cannot be rehashed from this compact bundle without downloading those original artifacts. Validation ZIP is retained verbatim.',
            'sourceIdentityPolicy': 'This evidence-only follow-up does not change or rerun the measured candidate. Every measurement remains bound to ed09ddbd9c20352e4690ade354e91a9bd70392a4.'}
(OUT / 'manifest.json.txt').write_bytes(encode(manifest))
print(json.dumps({'retainedFiles': len(files), 'retainedBytes': sum(map(len, files.values())),
                  'archiveBytes': len(packed), 'archiveSha256': sha(packed),
                  'manifestBytes': (OUT / 'manifest.json.txt').stat().st_size}, indent=2))
