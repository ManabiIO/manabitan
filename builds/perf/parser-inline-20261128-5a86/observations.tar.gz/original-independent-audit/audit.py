#!/usr/bin/env python3
"""Reconcile frozen inline-study originals; never run another import."""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import random
import statistics
import sys
import zipfile

ROOT = Path('/workspace/scratch/5a86d1e7822a/manabitan')
sys.path.insert(0, str(ROOT / 'dev/perf/import-memory-20261125-a7f7'))
from qualification_receipts import validate_import_summary, require_matching_receipts
from audit_memory import audit_cell

BASELINE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CANDIDATE = 'ed09ddbd9c20352e4690ade354e91a9bd70392a4'
PARSER = {'A': '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee',
          'B': '1cb15eda380145fe66c98e2b8397d1146552fc520dfdb600f22a0e478d7f6245'}
PACKAGE_DELTA = {'js/dictionary/wasm/term-bank-parser.c', 'lib/term-bank-parser.wasm'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('archive', type=Path)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--order', choices=('AB', 'BA'), required=True)
    args = parser.parse_args()
    actual_archive_sha = sha(args.archive.read_bytes())
    assert actual_archive_sha == args.sha256
    unpacked = args.archive.parent / ('unpacked-' + args.order)
    unpacked.mkdir(exist_ok=False)
    package_receipts = {}
    with zipfile.ZipFile(args.archive) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        assert archive.testzip() is None
        for name in names:
            relative = PurePosixPath(name)
            assert not relative.is_absolute() and '..' not in relative.parts
            if name.endswith('/package-A.zip') or name.endswith('/package-B.zip'):
                data = archive.read(name)
                arm = name[-5]
                with zipfile.ZipFile(io.BytesIO(data)) as package:
                    assert len(package.namelist()) == len(set(package.namelist()))
                    assert package.testzip() is None
                    entries = {entry.filename: sha(package.read(entry)) for entry in package.infolist() if not entry.is_dir()}
                package_receipts[arm] = {'sha256': sha(data), 'entries': entries}
                continue
            archive.extract(name, unpacked)
    evidence = unpacked / args.order
    invocation = read(unpacked / (args.order + '-driver') / 'invocation.json')
    assert invocation['status'] == 'complete' and invocation['exitCode'] == 0
    assert invocation['candidate'] == CANDIDATE and invocation['baseline'] == BASELINE
    assert invocation['flags'] == {} and invocation['pairs'] == 6 and invocation['retries'] == 0
    plan = read(evidence / 'registered-plan.json')
    assert plan['baseline'] == BASELINE and plan['candidate'] == CANDIDATE
    assert plan['initialOrder'] == args.order and plan['pairs'] == 6 and plan['flags'] == {}
    assert set(plan['expectedPackageEntries']) == PACKAGE_DELTA
    observed = read(evidence / 'observations.json')
    assert len(plan['schedule']) == len(observed) == 20
    for prescribed, item in zip(plan['schedule'], observed):
        assert all(item[key] == value for key, value in prescribed.items())
    identities = read(evidence / 'source-identities.json')
    assert set(identities['changedPackageEntries']) == PACKAGE_DELTA
    for arm in ('A', 'B'):
        identity = identities['arms'][arm]
        assert identity['sha'] == (BASELINE if arm == 'A' else CANDIDATE)
        assert package_receipts[arm]['sha256'] == identity['packageSha256']
        assert package_receipts[arm]['entries'] == identity['entries']
        assert identity['entries']['lib/term-bank-parser.wasm'] == PARSER[arm]
    assert set(package_receipts['A']['entries']) == set(package_receipts['B']['entries'])
    assert {key for key in package_receipts['A']['entries'] if package_receipts['A']['entries'][key] != package_receipts['B']['entries'][key]} == PACKAGE_DELTA
    browser = read(evidence / 'browser-identity.json')
    fixture = read(ROOT / 'test/perf/dictionaries.lock.json')['dictionaries']['jmdict']
    expected = [(item['id'], 'B' if item['arm'] == 'B' else 'A', 'sample', False) for item in observed]
    expected += [('exhaustive-media-' + arm, arm, 'all', False) for arm in args.order]
    expected += [('memory/' + item['name'], item['arm'], 'sample', True) for item in plan['memorySchedule']]
    assert len(expected) == 26
    receipts = []
    policy = set()
    common_sha = set()
    for name, arm, media, memory in expected:
        directory = evidence / name
        summary, report = read(directory / 'summary.json'), read(directory / 'run-1.json')
        identity = identities['arms'][arm]
        hashes = identity['sourceHashes'].copy()
        if memory:
            hashes['test/chromium/extension-two-dictionary-import.e2e.js'] = sha((evidence / 'memory/harness-instrumented.js').read_bytes())
        rebuilt = validate_import_summary(summary, report, dictionary='jmdict', fixture=fixture,
            source_sha=identity['sha'], package_sha256=identity['packageSha256'],
            browser_version=browser['version'], import_flags=None, source_hashes=hashes,
            source_dirty=memory, media_check=media)
        assert rebuilt == read(directory / 'canonical-receipt.json')
        if receipts:
            require_matching_receipts(receipts[0], rebuilt, compare_media=media == 'sample')
        receipts.append(rebuilt)
        common_sha.add(sha(json.dumps(rebuilt['common'], sort_keys=True).encode()))
        for dictionary in summary['runs'][0]['step4Breakdown']['dictionaries']:
            policy.add((dictionary['parserWorkerCount'], dictionary['parserGroupCount']))
        item = next((item for item in observed if item['id'] == name), None)
        if item is not None:
            assert summary['runs'][0]['totalImportMs'] == item['totalImportMs']
    assert len(common_sha) == 1 and policy == {(3, 12)}
    analysis = read(evidence / 'analysis.json')
    for kind, output_key, right in [('candidate', 'candidateVsBaseline', 'B'), ('control', 'identicalCodeControl', 'C')]:
        pairs = {}
        for item in observed:
            if item['kind'] == kind:
                pairs.setdefault(item['pair'], {})[item['arm']] = item['totalImportMs']
        assert len(pairs) == (6 if kind == 'candidate' else 2)
        assert all(set(pair) == {'A', right} for pair in pairs.values())
        ratios = [pair[right] / pair['A'] for pair in pairs.values()]
        rng = random.Random(897)
        bootstrap = sorted(statistics.median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
        expected_analysis = {'count': len(pairs), 'ratios': ratios,
            'medianPairedChangePercent': (statistics.median(ratios) - 1) * 100,
            'equalWorkChangePercent': (sum(pair[right] for pair in pairs.values()) / sum(pair['A'] for pair in pairs.values()) - 1) * 100,
            'worstPairChangePercent': (max(ratios) - 1) * 100,
            'descriptiveBootstrap95Percent': [(bootstrap[i] - 1) * 100 for i in (249, 9749)],
            'fasterPairs': sum(value < 1 for value in ratios)}
        assert analysis[output_key] == expected_analysis
    memory_audit = audit_cell(evidence / 'memory')
    assert memory_audit == read(evidence / 'memory/memory-audit.json')
    assert memory_audit['passesProspectiveMemoryScreen']
    assert analysis['status'] == 'correctness-memory-passed' and analysis['memoryPassed']
    result = {'status': 'PASS', 'order': args.order, 'artifactSha256': actual_archive_sha,
        'archiveMembers': len(names), 'imports': len(receipts), 'sourceAndPackagesVerified': True,
        'packageMembersPerArm': {arm: len(value['entries']) for arm, value in package_receipts.items()},
        'fixture': fixture, 'browser': browser, 'policy': sorted(policy),
        'commonReceiptSha256': next(iter(common_sha)), 'analysis': analysis, 'memoryAudit': memory_audit,
        'limits': 'Independent reconciliation of original complete-import cohort only; no replacement observations or cohort extension.'}
    target = args.archive.parent / ('audit-' + args.order + '.json')
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
