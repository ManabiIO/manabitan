import {readFile} from 'node:fs/promises';
const proposal=JSON.parse(await readFile(new URL('./overlap-consumer-wall-metrics-proposal.json',import.meta.url),'utf8'));
async function runConsumerMetricChecks(proposal) {
 const assert=(condition,message)=>{if(!condition)throw new Error(message);};
 const equal=(actual,expected,message)=>assert(JSON.stringify(actual)===JSON.stringify(expected),message+": "+JSON.stringify(actual)+" != "+JSON.stringify(expected));
 const gate=()=>{let resolve,reject;const promise=new Promise((a,b)=>{resolve=a;reject=b;});void promise.catch(()=>{});return{promise,resolve,reject};};
 const flush=async()=>{for(let i=0;i<12;i++)await Promise.resolve();};
 const make=()=>{
  let now=0,reads=0;
  const jobs=new Map(),yieldGates=[],yieldEvents=[];
  const aggregationError=new Error("metric aggregation failed");
  const clock={now:()=>{reads++;return now;}};
  const processTermChunk=async(_file,rows)=>await jobs.get(rows[0]).promise;
  const eventLoopYielder={yield:async()=>{yieldEvents.push(now);const next=yieldGates.shift();if(next)await next.promise;}};
  const addTermImportMetrics=(_out,metrics)=>{if(metrics?.failAggregation)throw aggregationError;};
  const body=proposal.stateDeclaration+"\nconst artifactMetrics={};\n"+
   "function createConsumer(termListChunk, requirementsChunk=null){\n"+
   "const sourceTermFileForProcessing={filename:'term_bank_1.json'}, streamProgress={}, streamedProgressStartIndex=0, sourceTermFileProgressAllowance=1;\n"+
   proposal.consumer+"\nreturn consume;\n}\n"+
   "return {createConsumer,metrics:()=>({sum:streamChunkWorkMs,wall:streamChunkWorkWallMs,active:activeStreamChunkWorkCount,count:streamedFastPathChunkCount})};";
  const tracker=new Function("Date","processTermChunk","eventLoopYielder","addTermImportMetrics",body)(clock,processTermChunk,eventLoopYielder,addTermImportMetrics);
  return{
   time:v=>{now=v;},jobs,yieldGates,yieldEvents,aggregationError,
   start:id=>{const job=gate();jobs.set(id,job);const rows=[id], requirements=["pending"];const completion=tracker.createConsumer(rows,requirements)(null);void completion.catch(()=>{});return{job,rows,requirements,completion};},
   metrics:tracker.metrics,reads:()=>reads
  };
 };
 const results=[];
 const run=async(name,fn)=>{await fn();results.push({name,status:"passed"});};
 await run("forward overlap: sums stay additive, wall counts union",async()=>{
  const h=make();h.time(0);const a=h.start(0);h.time(10);const b=h.start(1);
  h.time(20);a.job.resolve({});await flush();equal(h.metrics(),{sum:20,wall:0,active:1,count:2},"first completion");
  h.time(30);b.job.resolve({});await Promise.all([a.completion,b.completion]);
  equal(h.metrics(),{sum:40,wall:30,active:0,count:2},"overlap final");
  equal(h.reads(),4,"reuse exactly one start and one end clock read per successful consumer");
 });
 await run("reverse completion closes interval only when last owner ends",async()=>{
  const h=make();h.time(0);const a=h.start(0);h.time(10);const b=h.start(1);
  h.time(20);b.job.resolve({});await flush();equal(h.metrics(),{sum:10,wall:0,active:1,count:2},"nested completion");
  h.time(30);a.job.resolve({});await Promise.all([a.completion,b.completion]);
  equal(h.metrics(),{sum:40,wall:30,active:0,count:2},"reverse final");
 });
 await run("disjoint consumers preserve idle/parse gaps",async()=>{
  const h=make();h.time(0);const a=h.start(0);h.time(10);a.job.resolve({});await a.completion;
  h.time(30);const b=h.start(1);h.time(50);b.job.resolve({});await b.completion;
  equal(h.metrics(),{sum:30,wall:30,active:0,count:2},"disjoint union");
  equal(Math.max(0,50-h.metrics().wall),20,"remaining enclosing wall time");
 });
 await run("successor failure retires interval and preserves original success-only sum",async()=>{
  const h=make(),failure=new Error("successor failed");h.time(0);const a=h.start(0);h.time(10);const b=h.start(1);
  h.time(20);b.job.reject(failure);await flush();equal(h.metrics(),{sum:0,wall:0,active:1,count:2},"failed successor");
  h.time(30);a.job.resolve({});const statuses=await Promise.allSettled([a.completion,b.completion]);
  equal(h.metrics(),{sum:30,wall:30,active:0,count:2},"failure union");
  assert(statuses[1].status==="rejected"&&statuses[1].reason===failure,"original rejection identity");
  equal(b.rows.length,1,"failed callback retains original cleanup behavior");
 });
 await run("last-owner failure closes union after earlier success",async()=>{
  const h=make(),failure=new Error("predecessor failed");h.time(0);const a=h.start(0);h.time(10);const b=h.start(1);
  h.time(20);b.job.resolve({});await b.completion;h.time(30);a.job.reject(failure);await a.completion.catch(()=>{});
  equal(h.metrics(),{sum:10,wall:30,active:0,count:2},"last failure union");
 });
 await run("metric aggregation failure cannot leave active count open",async()=>{
  const h=make();h.time(5);const a=h.start(0);h.time(15);a.job.resolve({failAggregation:true});
  let error;try{await a.completion;}catch(e){error=e;}
  assert(error===h.aggregationError,"aggregation error identity");
  equal(h.metrics(),{sum:0,wall:10,active:0,count:1},"aggregation failure retirement");
 });
 await run("event-loop yielding and clearing stay outside measured consumer work",async()=>{
  const h=make(),y1=gate(),y2=gate();h.yieldGates.push(y1,y2);
  h.time(0);const a=h.start(0);h.time(10);a.job.resolve({});await flush();
  equal(h.metrics(),{sum:10,wall:10,active:0,count:1},"first yielder exclusion");
  equal([a.rows.length,a.requirements.length],[0,0],"clearing follows timing");
  h.time(25);const b=h.start(1);h.time(35);b.job.resolve({});await flush();
  equal(h.metrics(),{sum:20,wall:20,active:0,count:2},"disjoint work while earlier yield pending");
  h.time(100);y1.resolve();y2.resolve();await Promise.all([a.completion,b.completion]);
  equal(h.metrics(),{sum:20,wall:20,active:0,count:2},"yield end does not affect timing");
  equal(h.yieldEvents,[10,35],"yield boundaries");
 });
 await run("simultaneous intervals counted once",async()=>{
  const h=make();h.time(0);const a=h.start(0),b=h.start(1);h.time(10);a.job.resolve({});b.job.resolve({});await Promise.all([a.completion,b.completion]);
  equal(h.metrics(),{sum:20,wall:10,active:0,count:2},"simultaneous union");
 });
 await run("backward clock remains nonnegative like existing counters",async()=>{
  const h=make();h.time(10);const a=h.start(0);h.time(5);a.job.resolve({});await a.completion;
  equal(h.metrics(),{sum:0,wall:0,active:0,count:1},"clock clamp");
 });
 return {scope:"Exact proposed consume callback evaluated with deterministic dependency gates; not full importer/browser qualification",baseSha256:proposal.baseSha256,proposedSha256:proposal.proposedSha256,checks:results};
}
console.log(JSON.stringify(await runConsumerMetricChecks(proposal),null,2));

