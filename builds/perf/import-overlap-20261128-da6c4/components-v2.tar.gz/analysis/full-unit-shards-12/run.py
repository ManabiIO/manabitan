from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import time

here = Path(__file__).resolve().parent
root = here.parent.parent / 'startup-experiment'
plan = json.loads((here / 'plan.json').read_text())
assert plan['shardCount'] == 12 and plan['totalFiles'] == 674

def utc():
    return datetime.now(timezone.utc).isoformat()

manifest = {
    'scope': 'Complete existing Vitest unit suite partitioned into 12 sequential fresh processes; no extra filters or exclusions; stop at first failed process or completeness mismatch.',
    'startedAt': utc(),
    'root': str(root),
    'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
    'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip(),
    'node': subprocess.check_output(['node', '--version'], cwd=root, text=True).strip(),
    'planSha256': hashlib.sha256((here / 'plan.json').read_bytes()).hexdigest(),
    'shardCount': 12,
    'expectedFileCount': plan['totalFiles'],
    'complete': False,
    'allPassed': False,
    'results': [],
}
for shard in plan['shards']:
    index = shard['index']
    manifest['results'].append({
        'index': index,
        'command': ['npm', 'run', 'test:unit', '--', '--maxWorkers=1', f'--shard={index}/12'],
        'expectedFiles': len(shard['files']),
        'logPath': str(here / f'shard-{index:02d}.log'),
        'status': 'not-run',
    })

def save():
    target = here / 'results.json'
    temporary = here / 'results.tmp.json'
    temporary.write_text(json.dumps(manifest, indent=2) + '\n')
    temporary.replace(target)

save()
for result in manifest['results']:
    index = result['index']
    result['startedAt'] = utc()
    result['status'] = 'running'
    save()
    print(f'START shard {index}/12; expected files={result["expectedFiles"]}', flush=True)
    started = time.monotonic()
    with Path(result['logPath']).open('w') as log:
        process = subprocess.run(result['command'], cwd=root, stdout=log, stderr=subprocess.STDOUT)
    result['wallSeconds'] = time.monotonic() - started
    result['finishedAt'] = utc()
    result['returnCode'] = process.returncode
    result['exitCode'] = process.returncode if process.returncode >= 0 else 128 - process.returncode
    text = Path(result['logPath']).read_text()
    result['logSha256'] = hashlib.sha256(Path(result['logPath']).read_bytes()).hexdigest()
    clean = re.sub(r'\x1b\[[0-9;]*m', '', text)
    file_match = re.search(r'Test Files\s+([^\n]+)\((\d+)\)', clean)
    test_match = re.search(r'\bTests\s+([^\n]+)\((\d+)\)', clean)
    result['fileSummary'] = file_match.group(0) if file_match else None
    result['testSummary'] = test_match.group(0) if test_match else None
    result['reportedFiles'] = int(file_match.group(2)) if file_match else None
    result['reportedTests'] = int(test_match.group(2)) if test_match else None
    result['status'] = 'passed' if process.returncode == 0 and result['reportedFiles'] == result['expectedFiles'] else 'failed'
    save()
    print(f'DONE shard {index}/12: status={result["status"]}; exit={result["exitCode"]}; files={result["reportedFiles"]}; tests={result["reportedTests"]}; wall={result["wallSeconds"]:.2f}s', flush=True)
    if result['status'] != 'passed':
        manifest['stoppedAt'] = utc()
        manifest['stoppedOnShard'] = index
        manifest['failureReason'] = 'process failure' if process.returncode != 0 else 'reported file count differs from fixed installed-sequencer partition'
        save()
        print(f'STOPPED without retry; raw log={result["logPath"]}', flush=True)
        sys.exit(1)

manifest['complete'] = True
manifest['allPassed'] = True
manifest['finishedAt'] = utc()
manifest['reportedFileCount'] = sum(result['reportedFiles'] for result in manifest['results'])
manifest['reportedTestCount'] = sum(result['reportedTests'] for result in manifest['results'])
assert manifest['reportedFileCount'] == manifest['expectedFileCount']
save()
print(json.dumps({'complete': True, 'allPassed': True, 'files': manifest['reportedFileCount'], 'tests': manifest['reportedTestCount']}), flush=True)
