#!/usr/bin/env python3
"""Decode retained Chrome tracing CPU profiles; does not run application code.

Join Profile and ProfileChunk by (pid, id), because sample chunks can be
emitted on profiler-processing threads instead of the profiled thread. Trace
sample deltas can be negative; preserve those raw observations, reconstruct
absolute timestamps, then sort the complete samples before assigning adjacent
wall-clock intervals. These intervals are sampled elapsed-time weights, not
thread CPU durations and not exact function invocation boundaries.
"""

import argparse
import hashlib
import json
from pathlib import Path


def decode_profiles(events):
    thread_names = {
        (event['pid'], event['tid']): event.get('args', {}).get('name')
        for event in events if event.get('name') == 'thread_name'
    }
    profiles = {}
    for ordinal, event in enumerate(events):
        if event.get('name') != 'Profile':
            continue
        key = (event['pid'], event['id'])
        assert key not in profiles, ('duplicate Profile', key)
        data = event['args']['data']
        profiles[key] = {
            'pid': event['pid'], 'id': event['id'], 'tid': event['tid'],
            'threadName': thread_names.get((event['pid'], event['tid'])),
            'profileStartTraceEvent': event,
            'startTimeUs': data['startTime'], 'endTimeUs': None,
            'nodes': {}, 'samples': [], 'chunks': [],
        }
    for ordinal, event in enumerate(events):
        if event.get('name') != 'ProfileChunk':
            continue
        key = (event['pid'], event['id'])
        assert key in profiles, ('missing Profile', key)
        profiles[key]['chunks'].append((ordinal, event))
    for key, profile in profiles.items():
        timestamp = profile['startTimeUs']
        nodes = profile['nodes']
        samples = profile['samples']
        chunks = sorted(profile['chunks'], key=lambda item: (item[1]['ts'], item[0]))
        emitted_tids = set()
        negative_deltas = 0
        for trace_ordinal, event in chunks:
            emitted_tids.add(event['tid'])
            data = event['args']['data']
            cpu_profile = data.get('cpuProfile', {})
            for node in cpu_profile.get('nodes', []):
                node_id = node['id']
                assert node_id not in nodes or nodes[node_id] == node, ('inconsistent node', key, node_id)
                nodes[node_id] = node
            node_ids = cpu_profile.get('samples', [])
            deltas = data.get('timeDeltas', [])
            lines, columns = data.get('lines', []), data.get('columns', [])
            assert len(node_ids) == len(deltas), ('sample/delta count', key, trace_ordinal)
            assert not lines or len(lines) == len(node_ids), ('sample/line count', key, trace_ordinal)
            assert not columns or len(columns) == len(node_ids), ('sample/column count', key, trace_ordinal)
            for local_index, (node_id, delta) in enumerate(zip(node_ids, deltas)):
                timestamp += delta
                negative_deltas += delta < 0
                samples.append({
                    'timestampUs': timestamp, 'nodeId': node_id,
                    'rawDeltaUs': delta, 'rawOrdinal': len(samples),
                    'chunkTraceOrdinal': trace_ordinal,
                    'line': lines[local_index] if lines else None,
                    'column': columns[local_index] if columns else None,
                })
            if 'endTime' in data:
                assert profile['endTimeUs'] is None, ('duplicate end time', key)
                profile['endTimeUs'] = data['endTime']
        for node_id, node in nodes.items():
            assert 'parent' not in node or node['parent'] in nodes, ('missing parent', key, node_id)
        for sample in samples:
            assert sample['nodeId'] in nodes, ('missing sample node', key, sample['nodeId'])
        samples.sort(key=lambda sample: (sample['timestampUs'], sample['rawOrdinal']))
        assert not samples or profile['endTimeUs'] is None or samples[-1]['timestampUs'] <= profile['endTimeUs']
        for index, sample in enumerate(samples):
            following = samples[index + 1]['timestampUs'] if index + 1 < len(samples) else profile['endTimeUs']
            previous = samples[index - 1]['timestampUs'] if index else profile['startTimeUs']
            sample['followingWallWeightUs'] = following - sample['timestampUs'] if following is not None else None
            sample['precedingWallWeightUs'] = sample['timestampUs'] - previous
        profile['chunkCount'] = len(chunks)
        profile['chunkEmitterTids'] = sorted(emitted_tids)
        profile['negativeRawDeltaCount'] = negative_deltas
        profile['firstSampleGapUs'] = samples[0]['timestampUs'] - profile['startTimeUs'] if samples else None
        profile.pop('chunks')
    return profiles


def ancestors(profile, node_id):
    nodes = profile['nodes']
    seen = set()
    while node_id is not None:
        assert node_id not in seen, ('parent cycle', node_id)
        seen.add(node_id)
        yield node_id
        node_id = nodes[node_id].get('parent')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('trace')
    parser.add_argument('output')
    parser.add_argument('--pid', type=int, default=3084)
    parser.add_argument('--profile-id', default='0x4')
    args = parser.parse_args()
    source = Path(args.trace)
    data = source.read_bytes()
    trace = json.loads(data)
    profiles = decode_profiles(trace['traceEvents'])
    selected = profiles[(args.pid, args.profile_id)]
    result = {
        'tracePath': str(source), 'traceSha256': hashlib.sha256(data).hexdigest(),
        'traceEventCount': len(trace['traceEvents']), 'profileCount': len(profiles),
        'decoderSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope': 'Retained trace decode only. Adjacent sample intervals are wall-clock weights, not exact CPU durations or exact function invocation boundaries. Original negative deltas are preserved; reconstructed samples are sorted chronologically.',
        'profile': selected,
    }
    Path(args.output).write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({
        'output': args.output, 'traceSha256': result['traceSha256'],
        'profiles': len(profiles), 'nodes': len(selected['nodes']),
        'samples': len(selected['samples']), 'negativeRawDeltas': selected['negativeRawDeltaCount'],
        'startUs': selected['startTimeUs'], 'endUs': selected['endTimeUs'],
    }))


if __name__ == '__main__':
    main()
