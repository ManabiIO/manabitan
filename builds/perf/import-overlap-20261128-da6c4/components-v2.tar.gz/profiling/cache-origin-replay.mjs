// Isolated cache-method replay of exact JMdict pending spans. No parser, DB,
// compression, storage, browser, or cold-import timing claim.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile, rename} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import os from 'node:os';

const directory = '/workspace/scratch/da6c4dbd0097/profiling';
const planPath = path.join(directory, 'cache-origin-replay-plan.json');
const outputPath = path.join(directory, 'cache-origin-replay.json');
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const bytesOf = (view) => new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
const planBytes = await readFile(planPath);
const plan = JSON.parse(planBytes);
assert.equal(sha(await readFile(new URL(import.meta.url))), plan.scriptSha256);
const manifestBytes = await readFile(plan.manifestPath);
const manifest = JSON.parse(manifestBytes);
assert(manifest.complete);
assert.equal(sha(manifestBytes), plan.manifestSha256);
const baselineReceiptBytes = await readFile(plan.baselineReceiptPath);
assert.equal(sha(baselineReceiptBytes), plan.baselineReceiptSha256);
const fullBaseline = JSON.parse(baselineReceiptBytes).arms.baseline;
const rowCount = fullBaseline.metadata.denseCount;
const capacity = fullBaseline.metadata.columns.StateTable.bytes;
assert.equal(rowCount, 362032);
assert.equal(fullBaseline.metadata.count, rowCount);
assert.equal(fullBaseline.metadata.pendingCount, 0);
const publishedState = new Uint8Array(capacity);
publishedState.fill(1, 0, rowCount);
assert.equal(sha(publishedState), fullBaseline.metadata.columns.StateTable.sha256);
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {deviceMemory: 8}});

const roots = {baseline: plan.baselineRoot, candidate: plan.candidateRoot};
const modules = {};
const sources = {};
for (const [arm, root] of Object.entries(roots)) {
    const load = (file) => import(pathToFileURL(path.join(root, file)));
    const {DictionaryDatabase} = await load('ext/js/dictionary/dictionary-database.js');
    const ownership = await load('ext/js/dictionary/term-content-ownership.js');
    const {createTermImportMetrics} = await load('ext/js/dictionary/term-import-metrics.js');
    modules[arm] = {DictionaryDatabase, ownership, createTermImportMetrics};
    const bytes = await readFile(path.join(root, 'ext/js/dictionary/dictionary-database.js'));
    sources[arm] = {root, databaseSha256: sha(bytes), methodSha256: sha(DictionaryDatabase.prototype._cacheRecentPublishedTermContentSources.toString())};
    assert.equal(sources[arm].databaseSha256, plan.sourceHashes[arm]);
    const method = DictionaryDatabase.prototype._cacheRecentPublishedTermContentSources.toString();
    const source = bytes.toString('utf8');
    assert.equal(source.split(method).length, 2);
    sources[arm].withoutMethodSha256 = sha(source.replace(method, '<CACHE_METHOD>'));
}
assert.equal(sources.baseline.withoutMethodSha256, sources.candidate.withoutMethodSha256);

const groups = [];
const expectedOffsets = new Uint32Array(rowCount);
const expectedBatchIds = new Uint32Array(capacity);
let denseStart = 0;
for (const group of manifest.groups) {
    assert.equal(group.dedupMetrics.dedupNativeBulkPendingRows, group.uniqueContentCount);
    assert.equal(group.dedupMetrics.dedupNativeFallbackCount, 0);
    const parent = path.dirname(plan.manifestPath);
    const raw = await readFile(path.join(parent, group.sourceFile));
    const offsetBytes = await readFile(path.join(parent, group.offsetsFile));
    const lengthBytes = await readFile(path.join(parent, group.lengthsFile));
    assert.equal(sha(raw), group.sourceSha256);
    assert.equal(sha(offsetBytes), group.offsetsSha256);
    assert.equal(sha(lengthBytes), group.lengthsSha256);
    const source = new Uint8Array(new SharedArrayBuffer(raw.byteLength));
    source.set(raw);
    const offsets = Uint32Array.from(new Uint32Array(offsetBytes.buffer, offsetBytes.byteOffset, offsetBytes.byteLength / 4));
    const lengths = Uint32Array.from(new Uint32Array(lengthBytes.buffer, lengthBytes.byteOffset, lengthBytes.byteLength / 4));
    const indexes = Int32Array.from({length: offsets.length}, (_, index) => denseStart + index);
    let minimum = Infinity;
    let maximum = 0;
    for (let i = 0; i < offsets.length; ++i) { minimum = Math.min(minimum, offsets[i]); maximum = Math.max(maximum, offsets[i] + lengths[i]); }
    expectedOffsets.set(offsets, denseStart);
    expectedBatchIds.fill(group.index + 1, denseStart, denseStart + offsets.length);
    groups.push({index: group.index, source, offsets, lengths, indexes, denseStart, count: indexes.length, minimum, maximum, extent: maximum - minimum, sourceSha256: group.sourceSha256});
    denseStart += indexes.length;
}
assert.equal(denseStart, rowCount);
const expectedOffsetSha256 = sha(bytesOf(expectedOffsets));
const expectedBatchIdsSha256 = sha(bytesOf(expectedBatchIds));
const expectedPayloadBytes = groups.reduce((sum, group) => sum + group.extent, 0);
assert.equal(expectedPayloadBytes, 101143281);

const report = {
    schemaVersion: 1, complete: false, plan, planSha256: sha(planBytes), sources,
    node: process.version, host: {cpu: os.cpus()[0]?.model, parallelism: os.availableParallelism(), loadavg: os.loadavg()},
    scope: 'Warm isolated production cache-method replay. Exact original-JMdict pending content spans; contiguous metadata IDs reconstructed from native reservations and final dense-state hash. Ownership registration is explicit. Per-group cache call only is timed; reset, state publication, ownership registration and verification are excluded. No real browser activation, whole-import speed or peak-memory claim.',
    groups: groups.map(({index, count, denseStart, minimum, maximum, extent, source}) => ({index, count, denseStart, minimum, maximum, extent, sourceBytes: source.byteLength})),
    capacity, rows: rowCount, expectedPayloadBytes, warmups: [], observations: [], verifications: [], failures: [],
};
await writeFile(outputPath, JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
const save = async () => { const tmp = outputPath + '.checkpoint.tmp'; await writeFile(tmp, JSON.stringify(report, null, 2) + '\n'); await rename(tmp, outputPath); };

function createOwner(mode) {
    const arm = mode === 'candidate' ? 'candidate' : 'baseline';
    const module = modules[arm];
    const db = new module.DictionaryDatabase();
    assert.equal(db._recentTermContentSourceCacheMaxBytes, plan.cacheBudgetBytes);
    db._termEntryContentMetaStateTable = new Uint8Array(capacity);
    db._termEntryContentMetaRecentSourceBatchIdTable = new Uint32Array(capacity);
    db._termEntryContentMetaRecentSourceOffsetTable = new Uint32Array(capacity);
    return {db, module, canonicalOffsets: new Uint32Array(rowCount)};
}

function resetOwner(db) {
    db._termEntryContentMetaStateTable.fill(0);
    db._termEntryContentMetaRecentSourceBatchIdTable.fill(0);
    db._termEntryContentMetaRecentSourceOffsetTable.fill(0);
    db._recentTermContentSourceBatches.clear();
    db._recentTermContentSourceBatchBytes = 0;
    db._recentTermContentBoundaryBatchId = 0;
    db._nextRecentTermContentSourceBatchId = 1;
}

function runPass(mode, owner, verifyEveryReference) {
    const {db, module, canonicalOffsets} = owner;
    resetOwner(db);
    const metrics = module.createTermImportMetrics();
    const perGroupMs = [];
    const outcomes = [];
    let payloadBytes = 0;
    let checkedReferences = 0;
    let newlyBulkMappedEntries = 0;
    for (const group of groups) {
        db._termEntryContentMetaStateTable.fill(1, group.denseStart, group.denseStart + group.count);
        assert(module.ownership.registerOwnedTermContent(group.source));
        const staged = {indexes: group.indexes, active: true};
        const spans = {buffer: group.source, offsets: group.offsets, lengths: group.lengths};
        const start = performance.now();
        const payload = db._cacheRecentPublishedTermContentSources(staged, spans, metrics);
        perGroupMs.push(performance.now() - start);
        payloadBytes += payload;
        assert.equal(payload, group.extent);
        assert.equal(module.ownership.takeOwnedTermContent(group.source), false, 'Expected actual cache adoption');
        const batchId = group.index + 1;
        const view = db._recentTermContentSourceBatches.get(batchId);
        assert(view);
        assert.equal(view.buffer, group.source.buffer);
        const expectedBase = mode === 'candidate' ? 0 : group.minimum;
        assert.equal(view.byteOffset, expectedBase);
        if (group.minimum !== 0 && view.byteOffset === 0) { newlyBulkMappedEntries += group.count; }
        for (let i = 0; i < group.count; ++i) {
            const index = group.denseStart + i;
            canonicalOffsets[index] = view.byteOffset + db._termEntryContentMetaRecentSourceOffsetTable[index];
            if (verifyEveryReference) {
                const reference = db._findRecentTermContentSource({tableIndex: index, length: group.lengths[i]});
                assert(reference);
                assert.equal(reference.buffer.buffer, group.source.buffer);
                assert.equal(reference.buffer.byteOffset + reference.offset, group.offsets[i]);
                assert.equal(reference.length, group.lengths[i]);
                ++checkedReferences;
            }
        }
        const retainedBytes = [...db._recentTermContentSourceBatches.values()].reduce((sum, item) => sum + item.buffer.byteLength, 0);
        assert.equal(retainedBytes, db._recentTermContentSourceBatchBytes);
        assert(retainedBytes <= plan.cacheBudgetBytes);
        outcomes.push({group: group.index, cachedBatchIds: [...db._recentTermContentSourceBatches.keys()], retainedBackingBytes: retainedBytes, payloadBytes: payload, adoptedPayloadBytes: metrics.dedupRecentSourceAdoptedBytes});
    }
    assert.equal(sha(bytesOf(canonicalOffsets)), expectedOffsetSha256);
    assert.equal(sha(bytesOf(db._termEntryContentMetaRecentSourceBatchIdTable)), expectedBatchIdsSha256);
    assert.equal(sha(db._termEntryContentMetaStateTable), fullBaseline.metadata.columns.StateTable.sha256);
    assert.equal(payloadBytes, expectedPayloadBytes);
    assert.equal(metrics.dedupRecentSourceAdoptedBytes, expectedPayloadBytes);
    assert.equal(newlyBulkMappedEntries, mode === 'candidate' ? 89237 : 0);
    return {elapsedMs: perGroupMs.reduce((sum, ms) => sum + ms, 0), perGroupMs, payloadBytes, adoptedPayloadBytes: metrics.dedupRecentSourceAdoptedBytes, newlyBulkMappedEntries, checkedReferences, canonicalOffsetSha256: expectedOffsetSha256, batchIdSha256: expectedBatchIdsSha256, outcomes};
}

let referenceOutcomes;
function observe(mode, passes, label, verify = false) {
    const owner = createOwner(mode);
    globalThis.gc?.();
    const results = [];
    for (let pass = 0; pass < passes; ++pass) {
        const result = runPass(mode, owner, verify);
        if (typeof referenceOutcomes === 'undefined') { referenceOutcomes = result.outcomes; }
        assert.deepEqual(result.outcomes, referenceOutcomes);
        results.push(result);
    }
    owner.db._recentTermContentSourceBatches.clear();
    const elapsedMs = results.reduce((sum, result) => sum + result.elapsedMs, 0);
    const result = {mode, label, passes, elapsedMs, perCorpusMs: elapsedMs / passes, passMs: results.map((item) => item.elapsedMs), perGroupMs: groups.map((_, index) => results.reduce((sum, item) => sum + item.perGroupMs[index], 0) / passes), verification: results.at(-1)};
    console.log(JSON.stringify({mode, label, passes, perCorpusMs: result.perCorpusMs, newlyBulkMappedEntries: result.verification.newlyBulkMappedEntries, checkedReferences: result.verification.checkedReferences}));
    return result;
}

try {
    for (const mode of plan.modes) { report.verifications.push(observe(mode, 1, 'full-reference-verification', true)); await save(); }
    for (const mode of plan.modes) { report.warmups.push(observe(mode, plan.passesPerObservation, 'warmup')); await save(); }
    for (const [round, order] of plan.orders.entries()) {
        for (const mode of order) { report.observations.push({round, order, ...observe(mode, plan.passesPerObservation, `round-${round}`)}); await save(); }
    }
    for (const group of groups) {
        assert.equal(sha(group.source), group.sourceSha256);
        assert.equal(sha(bytesOf(group.offsets)), manifest.groups[group.index].offsetsSha256);
        assert.equal(sha(bytesOf(group.lengths)), manifest.groups[group.index].lengthsSha256);
    }
    for (const [arm, root] of Object.entries(roots)) {
        assert.equal(sha(await readFile(path.join(root, 'ext/js/dictionary/dictionary-database.js'))), sources[arm].databaseSha256);
    }
    report.complete = true;
    await save();
} catch (error) {
    report.failures.push({message: String(error), stack: error.stack});
    await save();
    throw error;
}
