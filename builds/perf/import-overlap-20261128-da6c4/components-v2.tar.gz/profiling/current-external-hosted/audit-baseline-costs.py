import hashlib, json, pathlib, re, statistics, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
PIN = "9e10d3b3fcf66d344ab31bc42c9b522fa5215da2"
LOCK = "60aa981791f3b60ca17588212aea5bd3536fb8f59288855e5accd019c6e4cf89"
CASES = [
    ("jmdict", "BA", "externalCurrentJmdictBA.zip", 15247701210, 12, 528299, "3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f"),
    ("jitendex", "AB", "externalCurrentJitendexScreen.zip", 15245794690, 6, 436555, "e914c76596220dffc6ee0c069cd05992f03adb2988c12c3cebe817a3ac271356"),
    ("vndb", "AB", "externalCurrentVndbScreen.zip", 15247862019, 6, 6648310, "da5baed5332761513dcef8d0b07ad0d9201cdd7f37831dea37e7162994ec3792"),
]
results = []
for dictionary, order, archive, artifact_id, expected, rows, fixture_sha in CASES:
    path = ROOT / archive
    with zipfile.ZipFile(path) as z:
        identity_name = next(n for n in z.namelist() if n.endswith("/source-identities.json"))
        identities = json.loads(z.read(identity_name))
        identity = identities["arms"]["A"]
        assert identity["sha"] == PIN and identity["fixtureLockSha256"] == LOCK
        members = sorted(n for n in z.namelist() if re.search(r"/pair-\d+-A/summary\.json$", n))
        assert len(members) == expected, (archive, len(members))
        target = ROOT / f"baseline-{dictionary}-{order}"
        target.mkdir(exist_ok=True)
        (target / "source-identities.json").write_bytes(z.read(identity_name))
        qualification = {"jobConclusion": "success"}
        if dictionary == "vndb":
            prefix = identity_name.rsplit("/", 1)[0]
            analysis = json.loads(z.read(prefix + "/analysis.json"))
            memory = json.loads(z.read(prefix + "/memory/memory-comparison.json"))
            semantic_failures = json.loads(z.read(prefix + "/memory/semantic-failures.json"))
            assert analysis["status"] == "memory-or-semantics-failed" and analysis["memoryPassed"] is False
            assert semantic_failures == []
            qualification = {
                "jobId": 140847948407, "jobConclusion": "failure", "status": analysis["status"],
                "reason": "Separate sampled-memory observation A2 failed the fixed coverage bound; all six ordinary A reports pass their own semantic/restart validation.",
                "memoryCoverage": [{k: o[k] for k in ["name", "benchmarkExitCode", "qualifiedForWholeTreePss", "qualificationFailures", "maximumCoveredSampleGapMs", "maxSampledPssKiB", "maxSampledPrivateKiB"]} for o in memory["observations"]],
                "memorySemanticFailures": semantic_failures,
                "passesProspectiveMemoryScreen": memory["passesProspectiveMemoryScreen"],
            }
            for suffix in ["analysis.json", "memory/memory-comparison.json", "memory/semantic-failures.json", "memory/memory-audit.json"]:
                (target / suffix.replace("/", "-")).write_bytes(z.read(prefix + "/" + suffix))
        observations = []
        for member in members:
            raw = z.read(member)
            summary = json.loads(raw)
            run = summary["runs"][0]
            report = json.loads(z.read(member.rsplit("/", 1)[0] + "/run-1.json"))
            assert len(summary["runs"]) == 1
            assert summary["dictionary"] == dictionary
            assert summary["gitSha"] == PIN and summary["source"]["gitSha"] == PIN
            assert summary["source"]["dirty"] is False
            assert summary["source"]["sha256"]["test/perf/dictionaries.lock.json"] == LOCK
            assert summary["fixture"]["sha256"] == fixture_sha and summary["fixture"]["termRows"] == rows
            assert summary["buildTarget"] == "chrome" and summary["traceEnabled"] is False
            assert summary["authoritativeTiming"] is True and summary["importFlags"] is None
            assert run["packageSha256"] == identity["packageSha256"]
            assert report["packageSha256"] == identity["packageSha256"]
            assert report["status"] == "success" and report["skippedVerification"] is False
            benchmark = report["benchmark"]
            assert benchmark["productionImportDefaults"] is True and benchmark["traceEnabled"] is False
            assert benchmark["phaseProfiling"] is False and benchmark["phaseScreenshots"] is False and benchmark["processSampling"] is False
            debug = run["importDebug"]
            assert debug["hasResult"] is True and debug["errorCount"] == 0 and debug["addSettingsErrorCount"] == 0 and debug["usesFallbackStorage"] is False
            v = run["validation"]
            assert v["termRows"] == rows and v["contentReadable"] is True and v["probeCount"] == 12
            assert v["restart"]["termRows"] == rows and v["restart"]["contentReadable"] is True
            assert len(v["lookup"]["observations"]) == 72
            phases = debug["importerPhaseTimings"]
            fast = [p for p in phases if p["phase"].startswith("term-file-fast-path:")]
            final = [p for p in phases if p["phase"] == "bulk-finalization"]
            assert len(fast) == len(final) == 1 and fast[0]["details"]["rows"] == rows
            name = member.rsplit("/", 2)[-2]
            (target / (name + ".summary.json")).write_bytes(raw)
            observations.append({
                "id": name, "archiveMember": member,
                "summarySha256": hashlib.sha256(raw).hexdigest(),
                "totalImportMs": run["totalImportMs"], "workerImportMs": run["workerImportMs"],
                "phaseElapsedMs": {p["phase"]: p["elapsedMs"] for p in phases},
                "fastPath": fast[0]["details"], "finalization": final[0]["details"],
                "localPhases": debug["localPhaseTimings"],
                "host": summary["hostEnvironment"], "browserVersion": summary["browserVersion"],
                "mediaCheck": summary["mediaCheck"],
            })
        def summaries(field):
            keys = sorted(set.intersection(*(set(x[field]) for x in observations)))
            return {k: {
                "median": statistics.median([x[field][k] for x in observations]),
                "min": min(x[field][k] for x in observations),
                "max": max(x[field][k] for x in observations),
            } for k in keys if all(isinstance(x[field][k], (int, float)) and not isinstance(x[field][k], bool) for x in observations)}
        result = {
            "scope": "Descriptive cost profile of baseline A only from an existing fixed cohort. No new acquisition, candidate comparison, speedup claim, or pooling with other hosts/cohorts.",
            "dictionary": dictionary, "cohortOrder": order, "runId": 46102526376,
            "artifactId": artifact_id, "artifactSha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "cohortQualification": qualification,
            "source": PIN, "baselineIdentity": identity,
            "observations": observations,
            "totalImportMs": {"median": statistics.median(x["totalImportMs"] for x in observations), "min": min(x["totalImportMs"] for x in observations), "max": max(x["totalImportMs"] for x in observations)},
            "phaseElapsedMs": summaries("phaseElapsedMs"),
            "fastPath": summaries("fastPath"), "finalization": summaries("finalization"),
            "limits": ["All baseline A pair observations retained; scheduled warmups, C controls, candidate B, exhaustive-media and sampled-memory observations are excluded from this descriptive profile by role, not outcome.",
                       "Parallel worker, source, sink, media, and persistence timers overlap and must not be summed.",
                       "Timed reports use the cohort's original media-check setting; separate exhaustive-media observations remain in the immutable archive.",
                       "Raw full reports and every candidate/control observation remain in the downloaded archive; this file is not an independent audit of the other experiment's performance claim."],
        }
        if dictionary == "vndb":
            result["limits"].append("The source cohort job failed its separate memory-coverage qualification. Its failure is retained explicitly; this baseline-only ordinary cost description does not relabel the cohort as passed or claim memory nonregression.")
        (target / "cost-profile.json").write_text(json.dumps(result, indent=2) + "\n")
        results.append(result)
for r in results:
    print(json.dumps({
        "dictionary": r["dictionary"], "cohort": r["cohortOrder"], "observations": len(r["observations"]),
        "totalImportMs": r["totalImportMs"], "phases": r["phaseElapsedMs"],
        "fastPathMs": dict(sorted(((k, v) for k, v in r["fastPath"].items() if k.endswith("Ms") and v["median"] > 0), key=lambda x: -x[1]["median"])),
        "counts": {k: r["fastPath"].get(k) for k in ["chunkCount", "parserBorrowedContentResultCount", "dedupRecentSourceAdoptedBytes", "dedupRecentSourceCacheBytes", "dedupRecentSourceHitCount"]},
        "finalizationMs": dict(sorted(((k,v) for k,v in r["finalization"].items() if k.endswith("Ms") and v["median"] > 0), key=lambda x: -x[1]["median"])),
    }, separators=(",", ":")))

