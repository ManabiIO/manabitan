#!/usr/bin/env python3
"""Attribute retained JMdict trace finalization; no benchmark or product edits."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
decoded = json.loads((ROOT / 'profiling/cache-trace-import-worker-profile.json').read_text())
profile = decoded['profile']
assert (profile['pid'], profile['tid'], profile['id']) == (3084, 3107, '0x4')
nodes = profile['nodes']
samples = profile['samples']
trace_path = Path(decoded['tracePath'])
trace_bytes = trace_path.read_bytes()
assert hashlib.sha256(trace_bytes).hexdigest() == decoded['traceSha256']
events = json.loads(trace_bytes)['traceEvents']
summary = json.loads((HERE / 'jmdict-trace/summary.json').read_text())
ordinary = json.loads((HERE / 'baseline-jmdict-BA/cost-profile.json').read_text())
assert summary['source']['gitSha'] == SOURCE and not summary['source']['dirty']
assert summary['traceEnabled'] is True and summary['importFlags'] is None
assert ordinary['source'] == SOURCE and len(ordinary['observations']) == 12

def ancestors(node_id):
    result = []
    while node_id:
        node = nodes[str(node_id)]
        result.append({'id': node_id, **node['callFrame']})
        node_id = node.get('parent')
    return result

native_flush_nodes = [int(key) for key, node in nodes.items()
    if node['callFrame'].get('functionName') == 'flush'
    and any(a.get('url', '').endswith('/term-record-import-index-writer.js') for a in ancestors(int(key)))]
assert native_flush_nodes == [671], native_flush_nodes
flush_indexes = [i for i, sample in enumerate(samples) if sample['nodeId'] == native_flush_nodes[0]]
assert len(flush_indexes) == 1
at = flush_indexes[0]
before, flush, after = samples[at-1:at+2]
assert nodes[str(before['nodeId'])]['callFrame']['functionName'] == '_flushLookupIndexFile'
assert nodes[str(after['nodeId'])]['callFrame']['functionName'] == 'close'

enclosing = [e for e in events
    if e.get('pid') == profile['pid'] and e.get('tid') == profile['tid']
    and e.get('ph') == 'X' and e.get('name') in ('RunTask', 'RunMicrotasks')
    and e['ts'] <= before['timestampUs'] and e['ts'] + e.get('dur', 0) >= after['timestampUs']]
assert len(enclosing) == 2 and all('tdur' in e for e in enclosing)
native = {'nodeId': native_flush_nodes[0], 'ancestors': ancestors(native_flush_nodes[0]),
    'previousSample': {**before, 'frame': nodes[str(before['nodeId'])]['callFrame']},
    'flushSample': flush,
    'nextSample': {**after, 'frame': nodes[str(after['nodeId'])]['callFrame']},
    'gapBeforeFlushSampleMs': (flush['timestampUs'] - before['timestampUs']) / 1000,
    'enclosingTimelineSpans': enclosing}
source_receipts = {}
for name in ['term-record-import-index-writer.js', 'term-record-opfs-store.js']:
    rel = f'ext/js/dictionary/{name}'
    actual = (ROOT / 'baseline' / rel).read_bytes()
    frozen = subprocess.check_output(['git', '-C', str(ROOT / 'baseline'), 'show', f'{SOURCE}:{rel}'])
    assert actual == frozen, rel
    source_receipts[rel] = hashlib.sha256(actual).hexdigest()
final_phase = next(p for p in summary['runs'][0]['importDebug']['importerPhaseTimings'] if p['phase'] == 'bulk-finalization')
out = {
    'scope': 'Read-only attribution of a source-identical diagnostic trace. No timing comparison or speedup claim.',
    'source': SOURCE, 'sourceSha256': source_receipts,
    'trace': {'runId': 46102526376, 'jobId': 140847948145, 'artifactId': 15245663705,
        'artifactSha256': '5d47cd51ab6db9d4bf3e952a7481f5efe650acba724857676f2df925741bb847',
        'path': str(trace_path), 'sha256': decoded['traceSha256'], 'profileId': profile['id'],
        'pid': profile['pid'], 'originalTid': profile['tid'], 'threadName': profile['threadName'],
        'decoderSha256': decoded['decoderSha256'], 'negativeRawDeltaCount': profile['negativeRawDeltaCount'],
        'firstSampleGapUs': profile['firstSampleGapUs'], 'packageSha256': summary['runs'][0]['packageSha256'],
        'browserVersion': summary['browserVersion'], 'hostEnvironment': summary['hostEnvironment']},
    'tracedFinalizationPhase': final_phase,
    'separateOrdinaryBaseline': {k: ordinary[k] for k in ['runId', 'artifactId', 'artifactSha256', 'source', 'totalImportMs', 'finalization']},
    'nativeFlushEvidence': native,
    'inference': 'The synchronous local lookup-index final flush dominates this finalization region. The enclosing task has 117.691 ms wall duration but only 1.820 ms thread CPU, and the next recorded native sample is flush under the index writer. The source joins descriptor and index finalizers concurrently on this same worker. Treating the record-close metric as independent descriptor I/O or the sample gap as JavaScript CPU would misattribute the tail.',
    'limits': [
        'No FileSystem-specific span or kernel trace measures exact native flush duration; the 116.866 ms sample gap is a bracket, not an exact operation timer.',
        'The traced observation is diagnostic only and is not pooled with the 12 ordinary observations from another fixed cohort.',
        'Samples are merged by (pid,id), not sampler tid. Negative raw deltas are retained, timestamps reconstructed, and samples sorted chronologically.',
        'Adjacent sample wall weights are not CPU weights. Following-interval weighting attaches the 116.866 ms gap to _flushLookupIndexFile; preceding weighting attaches it to flush.',
        'Nested RunTask and RunMicrotasks clocks must not be added; other import phase clocks also overlap.',
        'No absolute mapping between epoch phase markers and trace clock is assumed.',
        'Current attribution reproduces the mechanism already found by closed diagnostic PR 868. Broad I/O worker use and checkpoint policies already have retained unsuccessful JMdict experiments; no fresh optimization is qualified.'
    ]
}
destination = HERE / 'jmdict-finalization-attribution.json'
destination.write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'output': str(destination), 'source': SOURCE, 'gapBeforeFlushSampleMs': native['gapBeforeFlushSampleMs'], 'enclosingSpans': [{'name': e['name'], 'wallMs': e['dur']/1000, 'threadCpuMs': e['tdur']/1000} for e in enclosing], 'ordinaryRecordClose': ordinary['finalization']['termRecordEndImportSessionCloseWritableMs'], 'traceRecordCloseMs': final_phase['details']['termRecordEndImportSessionCloseWritableMs']}))
