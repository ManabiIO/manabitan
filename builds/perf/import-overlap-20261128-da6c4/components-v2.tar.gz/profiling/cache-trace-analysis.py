#!/usr/bin/env python3
"""Read-only attribution of the retained frozen JMdict browser cache trace."""

import collections
import hashlib
import importlib.util
import json
import statistics
from pathlib import Path


ROOT = Path('/workspace/scratch/da6c4dbd0097')
OUT = ROOT / 'profiling'
TRACE = Path('/home/agent/manabitan-da6c4dbd0097/current-external-hosted/jmdict-trace/run-1.trace.json')
SUMMARY = OUT / 'current-external-hosted/jmdict-trace/summary.json'
BASELINE_DB = ROOT / 'baseline/ext/js/dictionary/dictionary-database.js'

spec = importlib.util.spec_from_file_location('trace_profile_decode', OUT / 'trace-profile-decode.py')
decoder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(decoder)
trace_bytes = TRACE.read_bytes()
trace = json.loads(trace_bytes)
events = trace['traceEvents']
profiles = decoder.decode_profiles(events)
owner = profiles[(3084, '0x4')]
nodes = owner['nodes']
samples = owner['samples']
cache_ids = {
    node_id for node_id, node in nodes.items()
    if node['callFrame'].get('functionName') == '_cacheRecentPublishedTermContentSources'
}
assert cache_ids == {418}
caller_id = nodes[418]['parent']
assert nodes[caller_id]['callFrame']['functionName'] == '_publishArtifactTermContentMetadata'
source_lines = BASELINE_DB.read_text().splitlines()
assert '_cacheRecentPublishedTermContentSources(' in source_lines[nodes[418]['callFrame']['lineNumber']]
call_line = next(index + 1 for index, line in enumerate(source_lines) if 'const recentSourceCacheBytes = this._cacheRecentPublishedTermContentSources(' in line)
assert call_line == 10065
cache_descendants = {
    node_id for node_id in nodes
    if cache_ids.intersection(decoder.ancestors(owner, node_id))
}
assert cache_descendants == cache_ids


def direct(sample):
    return sample['nodeId'] in cache_descendants


def callsite(sample):
    return sample['nodeId'] == caller_id and sample['line'] == call_line


def selected(sample):
    return direct(sample) or callsite(sample)


def weights(items):
    return {
        'samples': len(items),
        'precedingWallWeightMs': sum(sample['precedingWallWeightUs'] for sample in items) / 1000,
        'followingWallWeightMs': sum(sample['followingWallWeightUs'] for sample in items) / 1000,
    }


# A burst continues through runtime-only samples but ends when another known
# JavaScript/idle frame is sampled. It is a sampled region, not a proven full
# invocation boundary. Runtime samples are retained for GC visibility.
bursts = []
last_selected_index = None
for index, sample in enumerate(samples):
    if not selected(sample):
        continue
    intervening = samples[last_selected_index + 1:index] if last_selected_index is not None else []
    can_join = last_selected_index is not None and all(
        nodes[item['nodeId']]['callFrame'].get('functionName') in {'(program)', '(garbage collector)'}
        for item in intervening
    )
    if not can_join:
        bursts.append([])
    bursts[-1].append(index)
    last_selected_index = index

owner_events = [event for event in events if event.get('ph') == 'X' and event.get('pid') == owner['pid'] and event.get('tid') == owner['tid']]


def overlap(event, start, end):
    return event['ts'] < end and event['ts'] + event['dur'] > start


def compact_event(event):
    return {key: event[key] for key in ['name', 'cat', 'pid', 'tid', 'ts', 'dur', 'tts', 'tdur'] if key in event}


burst_results = []
for number, indices in enumerate(bursts):
    observed = [samples[index] for index in indices]
    start, end = observed[0]['timestampUs'], observed[-1]['timestampUs']
    anchors = []
    for event in owner_events:
        if 'tts' not in event:
            continue
        if start <= event['ts'] <= end:
            anchors.append({'wallUs': event['ts'], 'threadCpuUs': event['tts'], 'name': event['name'], 'edge': 'start'})
        if 'tdur' in event and start <= event['ts'] + event['dur'] <= end:
            anchors.append({'wallUs': event['ts'] + event['dur'], 'threadCpuUs': event['tts'] + event['tdur'], 'name': event['name'], 'edge': 'end'})
    anchors.sort(key=lambda anchor: (anchor['wallUs'], anchor['threadCpuUs']))
    span = None
    if len(anchors) > 1 and anchors[-1]['wallUs'] > anchors[0]['wallUs']:
        span = {
            'first': anchors[0], 'last': anchors[-1],
            'elapsedMs': (anchors[-1]['wallUs'] - anchors[0]['wallUs']) / 1000,
            'threadCpuMs': (anchors[-1]['threadCpuUs'] - anchors[0]['threadCpuUs']) / 1000,
            'scope': 'Two recorded thread-clock endpoints lying inside the sampled burst. Not a whole cache invocation measurement.',
        }
    runtime = [event for event in owner_events if overlap(event, start, end) and ('GC' in event['name'] or 'Interrupt' in event['name'] or 'StackGuard' in event['name'])]
    containing_tasks = [event for event in owner_events if event['name'] == 'RunTask' and event['ts'] <= start and event['ts'] + event['dur'] >= end]
    burst_results.append({
        'index': number, 'firstSampleUs': start, 'lastSampleUs': end,
        'sampledRangeMs': (end - start) / 1000,
        **weights(observed),
        'directSamples': sum(direct(sample) for sample in observed),
        'callsiteSamples': sum(callsite(sample) for sample in observed),
        'runtimeSamplesBetween': [
            sample for sample in samples[indices[0]:indices[-1] + 1] if not selected(sample)
        ],
        'threadClockSpan': span,
        'overlappingGcEvents': [compact_event(event) for event in runtime if 'GC' in event['name']],
        'overlappingRuntimeEvents': [compact_event(event) for event in runtime],
        'containingTasks': [compact_event(event) for event in containing_tasks],
    })

summary_bytes = SUMMARY.read_bytes()
summary = json.loads(summary_bytes)
details = next(phase['details'] for phase in summary['runs'][0]['importDebug']['importerPhaseTimings'] if 'dedupRecentSourceCacheMs' in phase.get('details', {}))
replay_bytes = (OUT / 'cache-origin-replay.json').read_bytes()
replay = json.loads(replay_bytes)
db_replay_path = OUT / 'db-parity-full-baseline.json'
db_replay_bytes = db_replay_path.read_bytes()
db_replay = json.loads(db_replay_bytes)
ordinary_paths = sorted((OUT / 'current-external-hosted/baseline-jmdict-BA').glob('pair-*-A.summary.json'))
ordinary = []
for filename in ordinary_paths:
    report = json.loads(filename.read_bytes())
    metrics = next(phase['details'] for phase in report['runs'][0]['importDebug']['importerPhaseTimings'] if 'dedupRecentSourceCacheMs' in phase.get('details', {}))
    assert report['gitSha'] == summary['gitSha']
    ordinary.append({'path': str(filename), 'cacheMs': metrics['dedupRecentSourceCacheMs'], 'adoptedBytes': metrics['dedupRecentSourceAdoptedBytes'], 'cacheBytes': metrics['dedupRecentSourceCacheBytes'], 'borrowedGroups': metrics['parserBorrowedContentResultCount']})

line_groups = {
    'extent_state_length_validation': lambda line: 6851 <= line <= 6863,
    'contiguous_index_proof': lambda line: 6928 <= line <= 6934,
    'bulk_mapping_fill_set': lambda line: 6937 <= line <= 6938,
    'scalar_mapping': lambda line: 6940 <= line <= 6944,
    'sampling_policy': lambda line: line == 6829,
}
direct_samples = [sample for sample in samples if direct(sample)]
interrupt = next(event for event in owner_events if event['name'] == 'V8.BytecodeBudgetInterruptWithStackCheck' and event['ts'] == 240131647)
result = {
    'scope': 'Read-only diagnostic of one retained traced browser import and prior cache replay receipts. No new timing, candidate change, exact cache CPU total, or whole-import optimization claim.',
    'tracePath': str(TRACE), 'traceSha256': hashlib.sha256(trace_bytes).hexdigest(),
    'summaryPath': str(SUMMARY), 'summarySha256': hashlib.sha256(summary_bytes).hexdigest(),
    'baselineSourceSha': summary['gitSha'], 'baselineDbSha256': hashlib.sha256(BASELINE_DB.read_bytes()).hexdigest(),
    'browserVersion': summary['browserVersion'], 'browserHost': summary['hostEnvironment'],
    'packageSha256': summary['runs'][0]['packageSha256'],
    'traceIsAuthoritativeTiming': summary['authoritativeTiming'],
    'tracedTotalImportMs': summary['runs'][0]['totalImportMs'],
    'tracedCacheWallCounterMs': details['dedupRecentSourceCacheMs'],
    'tracedCacheBytes': details['dedupRecentSourceCacheBytes'],
    'tracedAdoptedBytes': details['dedupRecentSourceAdoptedBytes'],
    'tracedBorrowedGroups': details['parserBorrowedContentResultCount'],
    'ordinaryBaselineCohort': {'observations': ordinary, 'medianCacheMs': statistics.median(item['cacheMs'] for item in ordinary)},
    'ownerProfile': {'pid': owner['pid'], 'tid': owner['tid'], 'id': owner['id'], 'threadName': owner['threadName'], 'nodeCount': len(nodes), 'sampleCount': len(samples), 'negativeRawDeltaCount': owner['negativeRawDeltaCount'], 'firstSampleGapUs': owner['firstSampleGapUs']},
    'cacheNode': nodes[418], 'callerNode': nodes[caller_id], 'callerCacheLine': call_line,
    'directCacheSamples': weights(direct_samples),
    'callerCacheCallsiteSamples': weights([sample for sample in samples if callsite(sample)]),
    'combinedSelectedSamples': weights([sample for sample in samples if selected(sample)]),
    'directSampleLineGroups': {name: weights([sample for sample in direct_samples if predicate(sample['line'])]) for name, predicate in line_groups.items()},
    'bursts': burst_results,
    'runtimeCounterexampleToWallEqualsCpu': compact_event(interrupt),
    'traceEventNames': dict(collections.Counter(event.get('name') for event in events)),
    'traceCategories': dict(collections.Counter(event.get('cat') for event in events)),
    'compileOrOptimizationEventNames': dict(collections.Counter(event.get('name') for event in events if any(word in event.get('name', '').lower() for word in ['compil', 'deopt', 'optim', 'tier', 'osr']))),
    'retainedReplay': {
        'path': str(OUT / 'cache-origin-replay.json'), 'sha256': hashlib.sha256(replay_bytes).hexdigest(),
        'node': replay['node'], 'host': replay['host'],
        'warmBaselineMedianMs': statistics.median(item['perCorpusMs'] for item in replay['observations'] if item['mode'] == 'baseline'),
        'beforeScheduledWarmup': [
            {'mode': item['mode'], 'label': item['label'], 'perCorpusMs': item['perCorpusMs'], 'perGroupMs': item['perGroupMs']}
            for item in replay['verifications'] if item['mode'] in {'baseline', 'control'}
        ],
        'limitations': 'Earlier verification calls were not a prospectively designed cold-performance cohort. Exact byte-reference validation occurs between cache calls, outside their timers. They demonstrate execution-history sensitivity without quantifying browser JIT or scheduler effects.',
    },
    'retainedFullDbCorrectnessReplay': {
        'path': str(db_replay_path), 'sha256': hashlib.sha256(db_replay_bytes).hexdigest(),
        'node': db_replay['node'],
        'completedGroups': len(db_replay['arms']['baseline']['groups']),
        'cacheWallCounterMs': sum(group['metrics']['dedupRecentSourceCacheMs'] for group in db_replay['arms']['baseline']['groups']),
        'perGroupCacheWallCounterMs': [group['metrics']['dedupRecentSourceCacheMs'] for group in db_replay['arms']['baseline']['groups']],
        'limitations': 'Diagnostic counters from the earlier source-bound actual DB correctness replay, not a designed timing comparison. All twelve groups completed and persisted before a negative-sequence probe-oracle failure; the original receipt is retained unchanged and later independent reopen verification corrected that harness expectation. These counters are not pooled with browser or warm replay observations.',
    },
}
output = OUT / 'cache-trace-attribution.json'
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({
    'output': str(output), 'cacheCounterMs': result['tracedCacheWallCounterMs'],
    'direct': result['directCacheSamples'], 'caller': result['callerCacheCallsiteSamples'],
    'combined': result['combinedSelectedSamples'], 'bursts': len(bursts),
    'burstThreadClocks': [item['threadClockSpan'] for item in burst_results if item['threadClockSpan'] is not None],
    'overlappingGcEvents': sum(len(item['overlappingGcEvents']) for item in burst_results),
}, indent=2))
