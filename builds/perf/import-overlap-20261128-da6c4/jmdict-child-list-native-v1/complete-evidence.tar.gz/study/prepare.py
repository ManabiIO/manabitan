from pathlib import Path
import hashlib
import json
import re
import struct
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
A = Path('/tmp/manabitan-da6c4-current-glossary')
B = Path('/tmp/manabitan-da6c4-child-list')
ZIP = Path('/workspace/scratch/b9cacc3542c2/fixtures/JMdict.zip')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def dependency_paths(root):
    pending = ['ext/js/dictionary/term-bank-wasm-parser.js']
    paths = set()
    while pending:
        name = pending.pop()
        if name in paths: continue
        paths.add(name)
        source = (root / name).read_text()
        for target in re.findall(r"(?:from\s+|import\s*)['\"]([^'\"]+\.js)['\"]", source):
            if target.startswith('.'):
                path = (root / name).parent / target
                relative = path.resolve().relative_to(root).as_posix()
                assert (root / relative).is_file(), relative
                pending.append(relative)
    # These two source files establish ordinary option/ownership policy but are
    # not imported or executed in this serial component.
    paths.update(['ext/js/dictionary/term-bank-wasm-parser-worker.js', 'ext/js/dictionary/dictionary-importer.js', 'ext/js/dictionary/wasm/term-bank-parser.c', 'ext/js/dictionary/wasm/term-bank-inflate.c', 'dev/data/dictionary-wasm/manifest.json', 'dev/data/dictionary-wasm/term-bank-parser.wasm', 'test/perf/dictionaries.lock.json', 'package-lock.json'])
    return sorted(paths)

data = ZIP.read_bytes()
assert len(data) == 15645766 and sha(data) == '3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f'
banks = []
with zipfile.ZipFile(ZIP) as archive:
    names = sorted((name for name in archive.namelist() if re.fullmatch(r'term_bank_\d+\.json', name)), key=lambda name: int(name[10:-5]))
    assert len(names) == 53
    for name in names:
        entry = archive.getinfo(name)
        offset = entry.header_offset
        assert data[offset:offset + 4] == b'PK\x03\x04'
        name_size, extra_size = struct.unpack_from('<HH', data, offset + 26)
        start = offset + 30 + name_size + extra_size
        raw = archive.read(name)
        banks.append({'filename': name, 'offset': start, 'compressedSize': entry.compress_size, 'uncompressedSize': entry.file_size, 'signature': entry.CRC, 'compressionMethod': entry.compress_type, 'compressedSha256': sha(data[start:start + entry.compress_size]), 'sourceSha256': sha(raw), 'rows': len(json.loads(raw))})
        del raw
assert sum(bank['uncompressedSize'] for bank in banks) == 171617523
assert sum(bank['rows'] for bank in banks) == 528299
paths = dependency_paths(A)
identities = {arm: {name: sha((root / name).read_bytes()) for name in paths} for arm, root in [('A', A), ('B', B)]}
diffs = [name for name in paths if identities['A'][name] != identities['B'][name]]
assert diffs == sorted(['dev/data/dictionary-wasm/manifest.json', 'dev/data/dictionary-wasm/term-bank-parser.wasm', 'ext/js/dictionary/wasm/term-bank-parser.c']), diffs
for root in [A, B]:
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16'
snapshot = {'schemaVersion': 1, 'source': 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16', 'fixture': {'path': str(ZIP), 'bytes': len(data), 'sha256': sha(data)}, 'roots': {'A': str(A), 'B': str(B), 'C': str(A)}, 'sourceFiles': paths, 'identities': identities, 'packagedDifference': diffs, 'banks': banks, 'groupPolicy': {'source': 'Exact partitionSourceBanks/getPartitionSourceByteLength functions extracted from the frozen parser source; recorded Chromium4 logical CPUs yields3workers and no-media policy4groups/worker.', 'workers': 3, 'groupsPerWorker': 4, 'requestedGroups': 12, 'expectedGroupBankCounts': [5,4,4,4,5,5,4,5,4,4,4,5]}, 'options': {'singleChunk': True, 'maxPendingChunks': 1, 'emitTermByteLists': False, 'computeContentHashes': True, 'emitContentSlab': True, 'emitTokenBinaryContent': True, 'mediaHintFastScan': False, 'validateGlossaryTypes': True, 'prepareLookupIndexes': True, 'prepareLookupRoute': True, 'compactContentMetadata': True}, 'optionBasis': ['Pinned lock reports0media, so ordinary importer useMediaHintFastScan=false.', 'Current source171617523B >= MIN_EXACT_LOOKUP_SOURCE_BYTES=134217728; route preparation is on.', 'Parser worker performs native compressed inflate then strict fused parsing and copy with singleChunk and compact metadata; defaults come from snapshotTermBankExperiments.'], 'counterWasm': {'path': str(HERE / 'counter-parser.wasm'), 'sha256': sha((HERE / 'counter-parser.wasm').read_bytes())}}
(HERE / 'inputs.json').write_text(json.dumps(snapshot, indent=2) + '\n')
print(json.dumps({'inputsSha256': sha((HERE / 'inputs.json').read_bytes()), 'sourceFiles': len(paths), 'differentFiles': diffs, 'banks': len(banks), 'rows': sum(bank['rows'] for bank in banks)}))
