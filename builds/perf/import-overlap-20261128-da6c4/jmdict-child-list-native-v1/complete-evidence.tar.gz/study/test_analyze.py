import unittest
from analyze import assess, percentile


def fixture(change=-10, wall_change=-2):
    result = []
    for block in range(12):
        base = 100 + block * 0.5
        for arm in ['A', 'B', 'C']:
            result.append({'round': block, 'arm': arm, 'nativeFusedMs': base * (1 + (change if arm == 'B' else 0) / 100), 'fullGroupMs': 250 * (1 + (wall_change if arm == 'B' else 0) / 100)})
    return result


class Tests(unittest.TestCase):
    def test_clear_gain_passes(self):
        result = assess(fixture(), resamples=300)
        self.assertTrue(result['advance'])
        self.assertEqual(result['metrics']['A']['fasterPairs'], 12)
    def test_regression_fails(self):
        self.assertFalse(assess(fixture(10), resamples=300)['advance'])
    def test_small_gain_fails(self):
        self.assertFalse(assess(fixture(-2), resamples=300)['advance'])
    def test_wall_regression_fails(self):
        self.assertFalse(assess(fixture(-10, 1.1), resamples=300)['advance'])
    def test_exact_wall_boundary_passes(self):
        self.assertTrue(assess(fixture(-10, 1), resamples=300)['advance'])
    def test_controls_can_block_gain(self):
        values = fixture(-10)
        for row in values:
            if row['arm'] == 'C': row['nativeFusedMs'] *= 0.96
        result = assess(values, resamples=300)
        self.assertFalse(result['advance'])
        self.assertFalse(result['checks']['control.nativePairedMedianBelowHalfSmallerSaving'])
    def test_pair_count_and_interval(self):
        values = fixture(-10)
        for row in values:
            if row['arm'] == 'B' and row['round'] >= 8: row['nativeFusedMs'] *= 2
        result = assess(values, resamples=300)
        self.assertFalse(result['advance'])
        self.assertEqual(result['metrics']['A']['fasterPairs'], 8)
    def test_missing_duplicate_and_nan_fail(self):
        for values in [fixture()[:-1], fixture() + [fixture()[0]]]:
            with self.assertRaises(AssertionError): assess(values, resamples=3)
        values = fixture(); values[0]['nativeFusedMs'] = float('nan')
        with self.assertRaises(AssertionError): assess(values, resamples=3)
    def test_type7_percentiles(self):
        self.assertEqual(percentile([0, 10], .25), 2.5)
        self.assertEqual(percentile([0, 10], .975), 9.75)


if __name__ == '__main__': unittest.main()
