from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT = Path('/tmp/manabitan-da6c4-child-list')
HERE = Path(__file__).resolve().parent
source = (ROOT / 'ext/js/dictionary/wasm/term-bank-parser.c').read_text()
original_sha = hashlib.sha256(source.encode()).hexdigest()
marker = 'static int parse_compact_glossary_child_list(\n    const uint8_t*, uint32_t, uint32_t, uint32_t*, int, uint32_t\n);'
assert source.count(marker) == 1
source = source.replace(marker, 'static uint32_t child_census_stats[4];\n' + marker)
header = '    int media_hints, uint32_t available_depth\n) {\n'
assert source.count(header) == 1
source = source.replace(header, header + '    ++child_census_stats[0];\n')
start = source.index('/* Match the same list grammar inside a larger structured value.')
end = source.index('/* Strict source validation has exactly eight fields', start)
part = source[start:end]
tail = '    *out_end = pos;\n    return 1;'
assert part.count(tail) == 1
part = part.replace(tail, '    ++child_census_stats[1];\n    child_census_stats[2] += pos - start;\n' + tail)
source = source[:start] + part + source[end:]
header = "    const int validate_top_level_objects = validate_glossary_types && src[start] == '[';"
assert source.count(header) == 1
source = source.replace(header, '    ++child_census_stats[3];\n' + header)
source += '\n__attribute__((visibility("default")))\nuint32_t census_child_stats_ptr(void) { return (uint32_t)(uintptr_t)child_census_stats; }\n__attribute__((visibility("default")))\nvoid census_child_stats_reset(void) { for (uint32_t i = 0u; i < 4u; ++i) { child_census_stats[i] = 0u; } }\n'
(HERE / 'counter-parser.c').write_text(source)
target = next(item for item in json.loads((ROOT / 'dev/data/dictionary-wasm/manifest.json').read_text())['targets'] if item['name'] == 'term-bank-parser.wasm')
llvm = Path('/tmp/manabitan-c27-llvm/root/usr/lib/llvm-21/bin')
argv = [str(llvm / 'clang'), '-fuse-ld=' + str(llvm / 'wasm-ld'), *target['arguments'], '-Wl,--export=census_child_stats_ptr', '-Wl,--export=census_child_stats_reset', '-o', str(HERE / 'counter-parser.wasm'), str(HERE / 'counter-parser.c'), str(ROOT / target['sources'][1])]
env = {**os.environ, 'LD_LIBRARY_PATH': '/tmp/manabitan-c27-llvm/root/usr/lib/x86_64-linux-gnu'}
result = subprocess.run(argv, env=env, capture_output=True, text=True)
(HERE / 'counter-build.log').write_text(result.stdout + result.stderr)
(HERE / 'counter-build.json').write_text(json.dumps({'argv': argv, 'exitCode': result.returncode, 'candidateSourceSha256': original_sha, 'counterSourceSha256': hashlib.sha256(source.encode()).hexdigest(), 'counterOnly': True}, indent=2) + '\n')
result.check_returncode()
