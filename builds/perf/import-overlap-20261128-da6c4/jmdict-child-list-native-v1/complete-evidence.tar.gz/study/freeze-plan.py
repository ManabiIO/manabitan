from collections import Counter
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
sha = lambda data: hashlib.sha256(data).hexdigest()
inputs_bytes = (HERE / 'inputs.json').read_bytes()
inputs = json.loads(inputs_bytes)
preflight = json.loads((HERE / 'preflight-A-final.json').read_text())
receipt = json.loads((HERE / 'final-preflight-receipt.json').read_text())
assert receipt['complete'] and preflight['complete']
assert receipt['inputSha256'] == sha(inputs_bytes) == preflight['inputSha256']
assert preflight['before'] == preflight['after'] == inputs['identities']['A']
assert receipt['counterTotals'] == {'attempts': 212262, 'hits': 66897, 'bytes': 11977682, 'compositeCalls': 208562}
schedule = ['ABC', 'BCA', 'CAB', 'ACB', 'CBA', 'BAC', 'CBA', 'ACB', 'BAC', 'CAB', 'BCA', 'ABC']
assert len(schedule) == 12 and set(Counter(schedule).values()) == {2}
assert all(Counter(order[position] for order in schedule) == Counter({'A': 4, 'B': 4, 'C': 4}) for position in range(3))
files = ['component-arm.mjs', 'run.py', 'prepare.py', 'analyze.py', 'test_analyze.py', 'native-differential.mjs', 'build-counter.py', 'freeze-plan.py']
bindings = [
    ('ext/js/dictionary/wasm/term-bank-parser.c', 'e9c67572ff11532585556463ec17902f64cdb7c9'),
    ('dev/data/dictionary-wasm/term-bank-parser.wasm', '410040d7d4b6fe208556d20671e1d866cb05d495'),
    ('dev/data/dictionary-wasm/manifest.json', '573facecb5e409c8b2bf4112749b8f5ce668e8f8'),
    ('test/term-bank-compact-child-list.test.js', 'ef1ae532a1bed8116c6236d3b45e585c79ce344c'),
]
product = []
for name, git_blob in bindings:
    data = (Path(inputs['roots']['B']) / name).read_bytes()
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == git_blob
    product.append({'path': name, 'bytes': len(data), 'sha256': sha(data), 'blob': git_blob})
plan = {
    'schemaVersion': 1,
    'cohort': 'jmdict-embedded-compact-list-native-20261128-da6c4-v1',
    'frozenUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'timingAcquiredAtFreeze': False,
    'scope': 'Native component only; no complete-import performance claim',
    'source': inputs['source'],
    'laterDevelopContext': 'f28c2801fcfd9416f220b46b9cbafeee901c1cb2 changed database/storage/ownership paths, not this C/WASM baseline. This native cohort remains frozen to dcfc; future browser qualification requires a separately frozen current base.',
    'inputSha256': sha(inputs_bytes),
    'fixture': inputs['fixture'],
    'sourceBindings': inputs['identities'],
    'candidateProduct': product,
    'node': subprocess.check_output(['node', '--version'], text=True).strip(),
    'harnessSha256': {name: sha((HERE / name).read_bytes()) for name in files},
    'schedule': schedule,
    'arms': {'A': 'Unmodified frozen baseline', 'B': 'Exact guarded embedded compact-list C/WASM candidate', 'C': 'Identical baseline control; same root and module bytes as A'},
    'freshProcessPerObservation': True,
    'warmupSweepsPerObservation': 2,
    'measuredSweepsPerObservation': 1,
    'banksPerSweep': 53,
    'rowsPerSweep': 528299,
    'sourceBytesPerSweep': 171617523,
    'nativeCallsPerSweep': 12,
    'groupGeometry': preflight['groupGeometry'],
    'partitionFunctionSha256': preflight['partitionFunctionSha256'],
    'byteLengthFunctionSha256': preflight['byteLengthFunctionSha256'],
    'experimentSnapshot': preflight['experiments'],
    'parserOptions': inputs['options'],
    'sourceGroupPolicy': inputs['groupPolicy'],
    'primaryEndpoint': 'Sum of the 12 complete parse_and_encode_term_bank_token_binary_dedup native calls, including original native allocation/growth, strict parsing, interning, token-binary encoding and bank-local dedup. A common JavaScript wrapper times unchanged native calls with performance.now.',
    'secondaryEndpoint': 'Sum of 12 group wall intervals starting before unchanged compressed-source inflation and ending after strict parser, CRC verification, lookup/route work and actual cacheable-owned result copy. Verification hashes run after each group interval, before its heap can be reused.',
    'outsideTiming': ['Fixture/module loading and hashing; WebAssembly compilation/initialization; two fixed complete warmup sweeps; one explicit GC after warmups; source/output hashing and report I/O.', 'Output verification after each measured group; no output re-encoding or counter instrumentation in any timed arm.'],
    'outputOracle': receipt['outputOracle'],
    'preflightReceiptSha256': sha((HERE / 'final-preflight-receipt.json').read_bytes()),
    'actualPostReuseCoverage': receipt['counterTotals'],
    'advanceGate': {
        'all36CompleteAndExact': True,
        'pairedNativeMedianSavingPercentVsEachControlAtLeast': 3,
        'fasterPairsVsEachControlAtLeast': 9,
        'nativeEqualWorkSumsStrictlyLowerThanEachControl': True,
        'pairedNativeBootstrap95UpperBoundsForMsAndPercentVsEachControlStrictlyBelowZero': True,
        'fullGroupWallEqualWorkRatioVsEachControlAtMost': 1.01,
        'absoluteControlNativePairedMedianPercentStrictlyBelowHalfSmallerCandidateSaving': True,
        'absoluteControlNativeEqualWorkPercentStrictlyBelowHalfSmallerCandidateSaving': True,
        'bootstrap': {'resamples': 20000, 'generator': 'xorshift32', 'seed': 0x000da6c4, 'sharedRoundIndexesForBothComparisonsAndMetrics': True, 'percentiles': [0.025, 0.975], 'percentileMethod': 'type7'},
    },
    'stopping': 'Run exactly these 36 fresh observations once, in schedule order. Retain all attempts, logs, failures, timings and output hashes. Stop on any setup, source, output, runtime or timeout failure; no exclusions, resampling of observations, replacement runs or post-hoc threshold change. A failed performance or drift gate stops promotion of this cohort. Full-browser correctness/time/memory qualification remains required for any PR.',
    'command': 'python3 run.py plan.json measured-v1',
    'childCommand': 'node --expose-gc --max-old-space-size=512 component-arm.mjs inputs.json ARM measure FRESH_OUTPUT.json',
    'priorUntimedFailuresPreserved': [
        'Initial nonexistent-workdir launch: process never started.',
        'prepare dependency closure initially followed unexecuted importer dependencies to absent generated zip.js; narrowed to executed parser closure plus policy source binding.',
        'Initial manually transcribed group bank counts did not match unchanged partition function; fixed to its exact 12-group geometry before native acquisition.',
        'One extended unit test expected an incorrect plain structured-content normalization hint; fixed expectation, runtime unchanged.',
        'One synthetic statistics exact-1% boundary exposed binary64 percent conversion; gate now compares original sums against the exact ratio; no performance data existed.',
    ],
    'limitations': [
        'Serial native component, not an actual three-parser/four-compression-worker import, worker transport or database/storage/finalization endpoint.',
        'Two warmed full sweeps per fresh process isolate this code path; cold first-use and actual browser scheduling remain unqualified.',
        'Hash verification between groups is outside recorded intervals but can alter later cache/GC state; it is identical in all arms.',
        'Max RSS is diagnostic child process accounting, not separate browser memory qualification.',
        'Local Node24 cohort is distinct from earlier Node22 browser or other-host cohorts and is never pooled with them.',
        'Current helper activation is 66,897 post-reuse hits / 11,977,682 bytes, not the raw morphology census 73,626 rows / 42,940,646 bytes.',
    ],
}
destination = HERE / 'plan.json'
assert not destination.exists()
destination.write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps({'planSha256': sha(destination.read_bytes()), 'inputSha256': sha(inputs_bytes), 'observations': 36, 'nativeModuleA': inputs['identities']['A']['dev/data/dictionary-wasm/term-bank-parser.wasm'], 'nativeModuleB': inputs['identities']['B']['dev/data/dictionary-wasm/term-bank-parser.wasm'], 'product': product}, indent=2))
