from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
SOURCE = Path('/tmp/manabitan-da6c4-child-list')
LOGS = Path('/tmp/manabitan-da6c4-glossary-census')
excluded = {'evidence-v1.tar.gz', 'evidence-v1-index.json', 'evidence-v1-archive.json'}
members = {}
for path in sorted(HERE.rglob('*')):
    if path.is_file() and '__pycache__' not in path.parts and path.name not in excluded:
        members[f'study/{path.relative_to(HERE).as_posix()}'] = path.read_bytes()
for path in sorted(LOGS.glob('child-list-*.log')):
    members[f'validation/{path.name}'] = path.read_bytes()
for name in ['ext/js/dictionary/wasm/term-bank-parser.c', 'dev/data/dictionary-wasm/term-bank-parser.wasm', 'dev/data/dictionary-wasm/manifest.json', 'test/term-bank-compact-child-list.test.js']:
    members[f'product/{name}'] = (SOURCE / name).read_bytes()
members['product/patch.diff'] = subprocess.check_output(['git', 'diff', '--', 'ext/js/dictionary/wasm/term-bank-parser.c', 'dev/data/dictionary-wasm/manifest.json'], cwd=SOURCE)
index = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in members.items()}
index_bytes = (json.dumps({'schemaVersion': 1, 'members': index}, indent=2) + '\n').encode()
(HERE / 'evidence-v1-index.json').write_bytes(index_bytes)
members['evidence-index.json'] = index_bytes
archive = HERE / 'evidence-v1.tar.gz'
assert not archive.exists()
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
data = archive.read_bytes()
receipt = {'path': str(archive), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'memberCount': len(members), 'indexSha256': hashlib.sha256(index_bytes).hexdigest()}
(HERE / 'evidence-v1-archive.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
