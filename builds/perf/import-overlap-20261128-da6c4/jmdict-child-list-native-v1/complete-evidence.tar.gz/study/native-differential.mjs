import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';

const rootA = '/tmp/manabitan-da6c4-current-glossary';
const rootB = '/tmp/manabitan-da6c4-child-list';
const sha = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
const modules = await Promise.all([rootA, rootB].map(async (root) => {
    const bytes = fs.readFileSync(`${root}/dev/data/dictionary-wasm/term-bank-parser.wasm`);
    const {instance} = await WebAssembly.instantiate(bytes, {});
    return {native: instance.exports, sha256: sha(bytes)};
}));
const encode = new TextEncoder();
const list = (text) => JSON.stringify({content: Array.isArray(text) ? text.map((content) => ({content, tag: 'li'})) : {content: text, tag: 'li'}, data: {content: 'glossary'}, lang: 'en', style: {listStyleType: 'circle'}, tag: 'ul'});
const glossary = (content) => `[{"content":${content},"type":"structured-content"}]`;
const cases = [];
const add = (name, value) => cases.push({name, value});
for (const [kind, texts] of [['single', 'definition'], ['multiple', ['quote "', 'slash \\', '日本語']]]) {
    const child = list(texts);
    for (const [name, content] of [['first', `[${child},{"content":"note","tag":"span"}]`], ['last', `[{"content":"note","tag":"span"},${child}]`], ['twice', `[${child},${child}]`], ['object', `[{"other":${child},"tag":"span"},"sibling"]`]]) { add(`${kind}-${name}`, glossary(content)); }
    add(`${kind}-outer-type-first`, `[{"type":"structured-content","content":[${child},"sibling"]}]`);
    add(`${kind}-late-valid-type`, `[{"type":"text","content":[${child},"sibling"],"type":"structured-content"}]`);
    add(`${kind}-late-invalid-type`, `[{"type":"structured-content","content":[${child},"sibling"],"type":"text"}]`);
    add(`${kind}-late-null-content`, `[{"type":"structured-content","content":[${child},"sibling"],"content":null}]`);
    add(`${kind}-missing-type`, `[{"content":[${child},"sibling"]}]`);
    add(`${kind}-top-list`, `[${child}]`);
    for (const name of ['image', 'img', '\\u0069mage', '\\u0069mg']) { add(`${kind}-marker-${name}`, glossary(`[${list('placeholder').replace('placeholder', name)},"sibling"]`)); }
    for (const [name, change] of [
        ['language', (x) => x.replace('"lang":"en"', '"lang":"ja"')],
        ['style', (x) => x.replace('"circle"', '"disc"')],
        ['leaf-tag', (x) => x.replace('"tag":"li"', '"tag":"span"')],
        ['extra-key', (x) => x.replace('"data":', '"extra":0,"data":')],
        ['duplicate-key', (x) => x.replace('"lang":"en"', '"lang":"ja","lang":"en"')],
        ['whitespace', (x) => x.replaceAll(',', ', ')],
        ['bad-escape', (x) => x.replace('"content":', '"content":').replace('"tag":"li"', '"tag":"bad\\q"')],
        ['missing-comma', (x) => x.replace(',"tag":"li"', '"tag":"li"')],
        ['trailing-comma', (x) => x.replace('"tag":"ul"}', '"tag":"ul",}')],
        ['mismatched-style', (x) => x.replace('"circle"}', '"circle"]')],
    ]) { add(`${kind}-${name}`, glossary(`[${change(child)},"sibling"]`)); }
    for (const note of ['{"tag":"img","path":"image.webp"}', '{"type":"text","text":"note"}']) {
        add(`${kind}-hint-before-${note}`, glossary(`[ ${note},${child}]`));
        add(`${kind}-hint-after-${note}`, glossary(`[${child}, ${note}]`));
    }
    const suffix = child.indexOf(',"data":');
    for (let end = suffix; end < child.length; end++) { add(`${kind}-truncated-${end}`, glossary(`[${child.slice(0, end)},"sibling"]`)); }
    const limit = kind === 'single' ? 252 : 251;
    for (const depth of [limit - 1, limit, limit + 1]) { add(`${kind}-depth-${depth}`, glossary('['.repeat(depth) + child + ']'.repeat(depth))); }
}

function parse(native, bytes, strict, media) {
    native.wasm_reset_heap();
    const source = native.wasm_alloc(bytes.length);
    const metas = native.wasm_alloc(2 * 17 * 4);
    new Uint8Array(native.memory.buffer, source, bytes.length).set(bytes);
    const parseFunction = media ? native.parse_term_bank_with_media_hints : native.parse_term_bank;
    const count = parseFunction(source, bytes.length, metas, 2, 0, 0, strict ? 1 : 0);
    if (count < 0) { return {count}; }
    assert.equal(count, 2);
    const metadata = Array.from(new Uint32Array(native.memory.buffer, metas, count * 17));
    const capacity = bytes.length * 2 + 4096;
    const output = native.wasm_alloc(capacity);
    const rowMeta = native.wasm_alloc(count * 4 * 4);
    const written = native.encode_term_content_token_binary(source, metas, count, output, capacity, rowMeta);
    assert(written >= 0);
    return {count, metadata, contentMeta: Array.from(new Uint32Array(native.memory.buffer, rowMeta, count * 4)), bytes: Buffer.from(new Uint8Array(native.memory.buffer, output, written))};
}

const result = {schemaVersion: 1, complete: false, baselineWasm: modules[0].sha256, candidateWasm: modules[1].sha256, sourceCases: cases.length, checked: 0, valid: 0, invalid: 0, strictModes: [false, true], mediaModes: [false, true], caseReceipts: []};
for (const {name, value} of cases) {
    const bytes = encode.encode(`[["first","",null,"",0,${value},1,""],["following","",null,"",0,["tail"],2,""]]`);
    for (const strict of [false, true]) {
        for (const media of [false, true]) {
            const a = parse(modules[0].native, bytes, strict, media);
            const b = parse(modules[1].native, bytes, strict, media);
            assert.deepEqual(b, a, `${name}, strict=${strict}, media=${media}`);
            result.checked++;
            result[a.count >= 0 ? 'valid' : 'invalid']++;
            result.caseReceipts.push({name, sourceSha256: sha(bytes), strict, media, count: a.count, outputSha256: a.bytes ? sha(a.bytes) : null});
        }
    }
}
result.complete = true;
fs.writeFileSync(new URL('./native-differential.json', import.meta.url), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({...result, caseReceipts: undefined}));
