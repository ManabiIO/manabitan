import assert from 'node:assert/strict';
import fs from 'node:fs';
import crypto from 'node:crypto';

const [root, probePath, bankPath] = process.argv.slice(2);
const sha = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
const bytes = fs.readFileSync(bankPath);
const sourceRows = JSON.parse(bytes.toString('utf8'));
assert(sourceRows.length > 0 && sourceRows.length <= 10000);
const baselineBytes = fs.readFileSync(`${root}/dev/data/dictionary-wasm/term-bank-parser.wasm`);
assert.equal(sha(baselineBytes), '5d216041823936521f8a70b721472fb8c42052d165d771a92b59ed967d8d2695');
const probeBytes = fs.readFileSync(probePath);

async function parse(moduleBytes) {
    const {instance} = await WebAssembly.instantiate(moduleBytes, {});
    const native = instance.exports;
    native.wasm_reset_heap();
    const sourcePointer = native.wasm_alloc(bytes.length);
    const metadataPointer = native.wasm_alloc(sourceRows.length * 17 * 4);
    assert(sourcePointer && metadataPointer);
    new Uint8Array(native.memory.buffer, sourcePointer, bytes.length).set(bytes);
    const count = native.parse_term_bank_with_media_hints(sourcePointer, bytes.length, metadataPointer, sourceRows.length, 0, 0, 1);
    assert.equal(count, sourceRows.length);
    const metadata = new Uint32Array(native.memory.buffer, metadataPointer, count * 17).slice();
    return {native, sourcePointer, metadata};
}

function shape(value, key = '') {
    if (typeof value === 'string') {
        return ['tag', 'type', 'lang', 'listStyleType'].includes(key) ? JSON.stringify(value) : 'string';
    }
    if (value === null || typeof value !== 'object') { return JSON.stringify(value); }
    if (Array.isArray(value)) {
        const runs = [];
        for (const child of value) {
            const kind = shape(child);
            if (runs.length && runs.at(-1).kind === kind) { runs.at(-1).count++; }
            else { runs.push({kind, count: 1}); }
        }
        return `[${runs.map(({kind, count}) => kind + (count > 1 ? '+' : '')).join(',')}]`;
    }
    return `{${Object.entries(value).map(([name, child]) => `${JSON.stringify(name)}:${shape(child, name)}`).join(',')}}`;
}

const baseline = await parse(baselineBytes);
const probe = await parse(probeBytes);
assert.deepEqual(probe.metadata, baseline.metadata);
const report = {
    schemaVersion: 1,
    complete: false,
    scope: 'Raw source glossary morphology and exact existing compact-helper acceptance. No timing, no whole-import performance claim, no production dedup/witness execution count.',
    parserSha256: sha(baselineBytes), probeSha256: sha(probeBytes),
    bankBytes: bytes.length, bankSha256: sha(bytes), rows: sourceRows.length,
    metadataSha256: sha(new Uint8Array(baseline.metadata.buffer)),
    glossaryBytes: 0, compactRows: 0, compactBytes: 0, mediaHintDeclines: 0,
    hints: {mediaRows: 0, normalizationRows: 0, textNormalizationRows: 0},
    missShapes: {}, acceptedShapes: {},
};
for (let index = 0; index < sourceRows.length; index++) {
    const offset = baseline.metadata[index * 17 + 9];
    const length = baseline.metadata[index * 17 + 10];
    assert(length && offset <= bytes.length && length <= bytes.length - offset);
    const glossaryBytes = bytes.subarray(offset, offset + length);
    const glossary = JSON.parse(glossaryBytes.toString('utf8'));
    assert.deepEqual(glossary, sourceRows[index][5]);
    const end = probe.native.census_compact_glossary(probe.sourcePointer, bytes.length, offset, 1);
    const withoutMedia = probe.native.census_compact_glossary(probe.sourcePointer, bytes.length, offset, 0);
    assert(end === 0 || end === offset + length);
    assert(withoutMedia === 0 || withoutMedia === offset + length);
    const accepted = end !== 0;
    report.glossaryBytes += length;
    if (accepted) { report.compactRows++; report.compactBytes += length; }
    if (!accepted && withoutMedia !== 0) { report.mediaHintDeclines++; }
    report.hints.mediaRows += Number(baseline.metadata[index * 17 + 14] !== 0);
    report.hints.normalizationRows += Number(baseline.metadata[index * 17 + 15] !== 0);
    report.hints.textNormalizationRows += Number(baseline.metadata[index * 17 + 16] !== 0);
    const key = shape(glossary);
    const table = accepted ? report.acceptedShapes : report.missShapes;
    const entry = table[key] ??= {rows: 0, bytes: 0, example: {row: index, offset, length, sha256: sha(glossaryBytes), text: glossaryBytes.length <= 8192 ? glossaryBytes.toString('utf8') : null, prefix: glossaryBytes.subarray(0, 500).toString('utf8')}};
    entry.rows++; entry.bytes += length;
}
report.complete = true;
process.stdout.write(JSON.stringify(report));
