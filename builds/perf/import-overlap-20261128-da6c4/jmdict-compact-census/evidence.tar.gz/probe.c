#include "/tmp/manabitan-da6c4-current-glossary/ext/js/dictionary/wasm/term-bank-parser.c"
__attribute__((visibility("default")))
uint32_t census_compact_glossary(uint32_t source, uint32_t length, uint32_t start, uint32_t media_hints) {
    uint32_t end = 0u;
    if (!parse_compact_glossary_list((const uint8_t*)(uintptr_t)source, length, start, &end, media_hints != 0u)) { return 0u; }
    return end;
}
