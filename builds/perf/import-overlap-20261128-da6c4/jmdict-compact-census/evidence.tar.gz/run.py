import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import zipfile

ROOT = Path('/tmp/manabitan-da6c4-current-glossary')
HERE = Path(__file__).resolve().parent
FIXTURE = Path('/workspace/scratch/b9cacc3542c2/fixtures/JMdict.zip')
LLVM = Path('/tmp/manabitan-c27-llvm/root/usr/lib/llvm-21/bin')
EXPECTED = '3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f'

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def run():
    parser = argparse.ArgumentParser()
    parser.add_argument('--all', action='store_true')
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    output = Path(args.output)
    output.mkdir(exist_ok=False)
    report = {'schemaVersion': 1, 'complete': False, 'scope': 'Untimed bounded serial raw glossary morphology; existing compact helper acceptance, not production dedup execution counts.', 'source': 'dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16', 'fixture': {'path': str(FIXTURE), 'bytes': FIXTURE.stat().st_size, 'sha256': digest(FIXTURE)}, 'banks': []}
    (output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
    assert report['fixture']['bytes'] == 15645766 and report['fixture']['sha256'] == EXPECTED
    tracked = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
    assert not tracked.strip(), tracked
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == report['source']
    paths = ['ext/js/dictionary/wasm/term-bank-parser.c', 'ext/js/dictionary/wasm/term-bank-inflate.c', 'dev/data/dictionary-wasm/manifest.json', 'dev/data/dictionary-wasm/term-bank-parser.wasm']
    report['sourceBefore'] = {name: digest(ROOT / name) for name in paths}
    report['harness'] = {name: digest(HERE / name) for name in ['probe.c', 'analyze-bank.mjs', 'run.py']}
    env = {**os.environ, 'LD_LIBRARY_PATH': '/tmp/manabitan-c27-llvm/root/usr/lib/x86_64-linux-gnu'}
    report['toolchain'] = {name: subprocess.check_output([str(LLVM / name), '--version'], env=env, text=True) for name in ['clang', 'wasm-ld']}
    assert 'clang version 21.1.8' in report['toolchain']['clang'] and 'LLD 21.1.8' in report['toolchain']['wasm-ld']
    target = next(item for item in json.loads((ROOT / 'dev/data/dictionary-wasm/manifest.json').read_text())['targets'] if item['name'] == 'term-bank-parser.wasm')
    command = [str(LLVM / 'clang'), f'-fuse-ld={LLVM / "wasm-ld"}', *target['arguments'], '-Wl,--export=census_compact_glossary', '-o', str(output / 'probe.wasm'), str(HERE / 'probe.c'), str(ROOT / target['sources'][1])]
    report['buildCommand'] = command
    with (output / 'build.log').open('w') as log:
        subprocess.run(command, env=env, check=True, stdout=log, stderr=subprocess.STDOUT)
    report['node'] = subprocess.check_output(['node', '--version'], text=True).strip()
    with zipfile.ZipFile(FIXTURE) as archive:
        banks = sorted([name for name in archive.namelist() if name.startswith('term_bank_') and name.endswith('.json')], key=lambda name: int(name[10:-5]))
        assert len(banks) == 53
        if not args.all: banks = banks[:1]
        for name in banks:
            data = archive.read(name)  # zipfile checks this original member's CRC.
            bank_path = output / 'current-bank.json'
            bank_path.write_bytes(data)
            del data
            result = subprocess.run(['node', '--max-old-space-size=256', str(HERE / 'analyze-bank.mjs'), str(ROOT), str(output / 'probe.wasm'), str(bank_path)], check=True, capture_output=True, text=True)
            bank = json.loads(result.stdout)
            assert bank['complete'] is True
            bank['name'] = name
            (output / f'{name}.census.json').write_text(json.dumps(bank, indent=2) + '\n')
            report['banks'].append({key: bank[key] for key in ['name', 'bankBytes', 'bankSha256', 'rows', 'metadataSha256', 'glossaryBytes', 'compactRows', 'compactBytes', 'mediaHintDeclines', 'hints']})
            print(json.dumps(report['banks'][-1]), flush=True)
            bank_path.unlink()
            (output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
    report['sourceAfter'] = {name: digest(ROOT / name) for name in paths}
    assert report['sourceAfter'] == report['sourceBefore']
    report['complete'] = True
    (output / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')

if __name__ == '__main__':
    run()
