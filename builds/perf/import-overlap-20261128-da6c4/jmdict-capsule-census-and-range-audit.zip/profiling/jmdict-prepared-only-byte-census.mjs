// Untimed JMdict prepared-column census. Source-unchanged native worker and transfer.
// Derived from jitendex-media-ownership-census.mjs SHA256 fb1419ae606eabbc2a6bea68b76677cd8f6944535943ab4192fbf9279eb6c1d8.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile, rename} from 'node:fs/promises';
import {createReadStream, openAsBlob} from 'node:fs';
import {Worker} from 'node:worker_threads';
import {pathToFileURL} from 'node:url';
import path from 'node:path';

const root = '/workspace/scratch/da6c4dbd0097/baseline';
const manifestPath = '/workspace/scratch/da6c4dbd0097/profiling/compression-groups/jmdict/manifest.json';
const fixtureDirectory = '/home/agent/manabitan-da6c4dbd0097/fixtures';
const out = '/workspace/scratch/da6c4dbd0097/analysis/jmdict-prepared-only-byte-census.json';
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const load = (file) => import(pathToFileURL(path.join(root, file)));
const manifestBytes = await readFile(manifestPath);
const manifest = JSON.parse(manifestBytes);
assert(manifest.complete && manifest.dictionary === 'jmdict');
const identityFiles = ['ext/js/dictionary/term-bank-wasm-parser.js', 'ext/js/dictionary/term-bank-wasm-parser-worker.js', 'ext/js/dictionary/term-bank-experiments.js', 'ext/js/dictionary/term-content-ownership.js', 'ext/js/dictionary/dictionary-importer.js', 'ext/lib/term-bank-parser.wasm', 'ext/js/dictionary/term-lookup-index.js', 'ext/js/dictionary/term-lookup-index-preparation.js', 'ext/js/dictionary/term-record-preinterned-plan.js', 'ext/js/dictionary/term-record-opfs-store.js'];
const sourceHashes = {};
for (const file of identityFiles) {
    sourceHashes[file] = sha(await readFile(path.join(root, file)));
    if (file in manifest.sourceHashes) { assert.equal(sourceHashes[file], manifest.sourceHashes[file]); }
}
const fixturePath = path.join(fixtureDirectory, manifest.fixture.cacheFile);
const fixtureHash = createHash('sha256');
let fixtureBytes = 0;
for await (const bytes of createReadStream(fixturePath)) { fixtureHash.update(bytes); fixtureBytes += bytes.byteLength; }
assert.equal(fixtureBytes, manifest.fixture.sizeBytes);
assert.equal(fixtureHash.digest('hex'), manifest.fixture.sha256);
const {BlobReader, ZipReader} = await load('node_modules/@zip.js/zip.js/index.js');
const {RawZipPayloadReader} = await load('ext/js/dictionary/term-bank-source-pipeline.js');
const {readDenseZipDirectory} = await load('ext/js/dictionary/dense-zip-directory.js');
const {parsePersistedTermLookupIndex, getPersistedTermSequence} = await load('ext/js/dictionary/term-lookup-index.js');
const {shouldOwnTermContentBytes, shouldBorrowProjectedTermContent} = await load('ext/js/dictionary/term-content-ownership.js');
const archive = await openAsBlob(fixturePath);
const raw = new RawZipPayloadReader(archive);
let zip;
const entries = await readDenseZipDirectory(archive) ?? await (zip = new ZipReader(new BlobReader(archive), {useWebWorkers: false})).getEntries();
const terms = entries.filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)));
assert.equal(terms.length, manifest.sourceBanks);
assert.equal(terms.reduce((sum, entry) => sum + entry.uncompressedSize, 0), manifest.totalSourceBytes);
// Same ordinary import settings for this media corpus below the 1 GiB native
// projection/forced-ownership threshold. The worker itself derives borrowing.
const parserOptions = {
    copyContentBytes: false, includeContentMetadata: true, initialContentBytesPerRow: 48,
    minimalDecode: true, reuseExpressionForReadingDecode: true, preallocateChunkRows: true,
    skipTagRuleDecode: false, lazyGlossaryDecode: true, mediaHintFastScan: false,
    projectImagePaths: false, validateGlossaryTypes: true, computeContentHashes: true,
    emitContentSlab: true, emitTokenBinaryContent: true, emitTermByteLists: false,
    prepareLookupIndexes: true, prepareLookupRoute: false, maxPendingChunks: 2,
    ownContentBytes: false, experimentalNativeEscapedKeys: false,
};
assert(manifest.totalSourceBytes < 1024 * 1024 * 1024);
const report = {
    schemaVersion: 1, complete: false, node: process.version, source: manifest.gitSha,
    scope: 'Admission census only: checksum-fixed compressed ZIP inputs, exact existing production three-worker group boundaries, unchanged actual parser-worker entry and ordinary no-media JMdict options over Node message transport. One worker processes groups serially and each result is inspected before its next parse; no source is recopied or registered as owned. Worker ownership/borrowing flags and real shared WASM view shapes are observed. No DB, compression, media extraction, final persistence, browser transport scheduling or timing claim. A strict decoder reconstructs fallback key/read/sequence values outside any timing. Counted private buffers are current receiver allocations/copies; a prepared-only protocol remains hypothetical.',
    manifestSha256: sha(manifestBytes), sourceHashes, fixture: manifest.fixture,
    harnessSha256: sha(await readFile(new URL(import.meta.url))),
    bridgeSha256: sha(await readFile(new URL('./parser-worker-node-bridge.mjs', import.meta.url))),
    parserOptions, groupPartitionWorkers: 3, executingWorkers: 1,
    admission: 'mediaRows.length === 0 AND explicit worker ownsContentBytes AND !borrowsWorkerMemory AND complete whole owned source view AND contentRowStart === 0 AND plan.sourceRowCount === chunk.rowCount',
    groups: [], failures: [],
};
await writeFile(out, JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
const save = async () => { const temporary = out + '.checkpoint.tmp'; await writeFile(temporary, JSON.stringify(report, null, 2) + '\n'); await rename(temporary, out); };
const worker = new Worker(new URL('./parser-worker-node-bridge.mjs', import.meta.url), {workerData: {entry: String(pathToFileURL(path.join(root, 'ext/js/dictionary/term-bank-wasm-parser-worker.js')))}, execArgv: []});
let pending;
let workerFailure;
let terminationRequested = false;
const terminalFailures = [];
worker.on('message', (message) => {
    assert(pending, 'Unexpected parser worker message');
    const {resolve, reject} = pending; pending = null;
    if (message.type === 'parse-error' || message.type === 'initialization-error') { reject(new Error(JSON.stringify(message))); }
    else { resolve(message); }
});
worker.on('error', (error) => { terminalFailures.push({type: 'error', message: String(error)}); workerFailure = error; pending?.reject(error); pending = null; });
worker.on('exit', (code) => { if (!terminationRequested) { terminalFailures.push({type: 'unexpected-exit', code}); } if (pending) { pending.reject(new Error(`Worker exited while pending: ${code}`)); pending = null; } });
function request(message, transfer = []) {
    if (workerFailure) { throw workerFailure; }
    assert(!pending);
    const response = new Promise((resolve, reject) => { pending = {resolve, reject}; });
    worker.postMessage(message, transfer);
    return response;
}
function streaks(predicate) {
    const result = [];
    for (const group of report.groups) {
        if (!predicate(group)) { continue; }
        const previous = result.at(-1);
        if (previous && previous.end + 1 === group.index) { previous.end = group.index; ++previous.groups; previous.rows += group.rows; }
        else { result.push({start: group.index, end: group.index, groups: 1, rows: group.rows}); }
    }
    return result;
}
try {
    const module = await WebAssembly.compile(await readFile(path.join(root, 'ext/lib/term-bank-parser.wasm')));
    assert.equal((await request({type: 'initialize', module})).type, 'ready');
    for (const group of manifest.groups) {
        const first = terms.findIndex((entry) => entry.filename === group.firstBank);
        const last = terms.findIndex((entry) => entry.filename === group.lastBank);
        assert(first >= 0 && last >= first);
        const sourceBuffers = [];
        const sourceMetadata = [];
        for (const entry of terms.slice(first, last + 1)) {
            const bytes = await raw.read(entry, new AbortController().signal);
            sourceBuffers.push(bytes.byteOffset === 0 && bytes.byteLength === bytes.buffer.byteLength && bytes.buffer instanceof ArrayBuffer ? bytes.buffer : Uint8Array.from(bytes).buffer);
            sourceMetadata.push({filename: entry.filename, compressionMethod: entry.compressionMethod, compressedSize: entry.compressedSize, uncompressedSize: entry.uncompressedSize, signature: entry.signature});
        }
        const result = await request({type: 'parse', id: group.index, version: 3, chunkSize: 12000, sourceBuffers, sourceMetadata, options: parserOptions}, sourceBuffers);
        assert.equal(result.type, 'result'); assert.equal(result.id, group.index);
        const {chunk, profile, ownsContentBytes, borrowsWorkerMemory} = result;
        assert(chunk); assert.equal(chunk.rowCount, group.rows); assert.equal(profile.rowCount, group.rows);
        const source = chunk.contentBytesBuffer, plan = chunk.contentDedupPlan;
        assert(source instanceof Uint8Array); assert(plan);
        const contentRowStart = chunk.contentRowStart ?? 0;
        const fullBackingView = source.byteOffset === 0 && source.byteLength > 0 && source.byteLength === source.buffer.byteLength;
        const completeOwnedShape = ownsContentBytes === true && borrowsWorkerMemory === false && fullBackingView && contentRowStart === 0 && plan.sourceRowCount === chunk.rowCount;
        const prepared = chunk.preparedLookupIndexes;
        assert(prepared instanceof Map && prepared.size === 1);
        const entry = prepared.get(`0:${chunk.rowCount}`);
        assert(entry && entry.preinternedPlan === chunk.termRecordPreinternedPlan);
        const lookupPlan = chunk.termRecordPreinternedPlan;
        const index = parsePersistedTermLookupIndex(entry.bytes);
        assert.equal(index.expressionKeys.length, chunk.rowCount);
        assert.equal(index.keyBytes.length, lookupPlan.stringsBuffer.length);
        assert.deepEqual(index.keyBytes, lookupPlan.stringsBuffer);
        assert.equal(index.keyOffsets.length, lookupPlan.stringLengths.length + 1);
        for (let i = 0; i < lookupPlan.stringLengths.length; ++i) {
            assert.equal(index.keyOffsets[i + 1] - index.keyOffsets[i], lookupPlan.stringLengths[i]);
        }
        let readingExpressionRecoveryMatches = 0;
        let readingSentinelRecoveryMatches = 0;
        let directReadingRows = 0;
        let sequenceRawRecoveryMatches = 0;
        const negativeSequenceValues = new Set();
        for (let i = 0; i < chunk.rowCount; ++i) {
            assert.equal(index.expressionKeys[i], lookupPlan.expressionIndexes[i]);
            const equal = chunk.readingEqualsExpressionList[i] === 1;
            assert.equal(index.readingKeys[i] === 0xffff, equal);
            if (equal) {
                if (lookupPlan.readingIndexes[i] === index.expressionKeys[i]) { ++readingExpressionRecoveryMatches; }
                if (lookupPlan.readingIndexes[i] === 0xffffffff) { ++readingSentinelRecoveryMatches; }
            } else {
                assert.equal(index.readingKeys[i], lookupPlan.readingIndexes[i]);
                ++directReadingRows;
            }
            const persisted = getPersistedTermSequence(index, i);
            const original = chunk.sequenceList[i];
            assert.equal(persisted, original >= 0 ? original : null);
            if (original < 0) { negativeSequenceValues.add(original); }
            if (Object.is(persisted ?? -1, original)) { ++sequenceRawRecoveryMatches; }
        }
        const kept = new Set();
        const views = [];
        const keep = (value) => { if (ArrayBuffer.isView(value)) { kept.add(value.buffer); } };
        for (const [key, value] of Object.entries(chunk)) {
            if (!['termRecordPreinternedPlan', 'preparedLookupIndexes', 'sequenceList', 'readingEqualsExpressionList'].includes(key)) {
                keep(value);
                if (Array.isArray(value)) { for (const item of value) { keep(item); } }
            }
        }
        for (const value of Object.values(chunk.contentDedupPlan)) { keep(value); }
        for (const value of prepared.values()) { keep(value.bytes); keep(value.routeFilter); }
        const planBuffers = new Set();
        for (const [key, value] of Object.entries(lookupPlan)) {
            if (!ArrayBuffer.isView(value)) { continue; }
            if (!kept.has(value.buffer)) { planBuffers.add(value.buffer); }
            views.push({field: `plan.${key}`, type: value.constructor.name, bytes: value.byteLength, backingBytes: value.buffer.byteLength, alreadyNeededByPreparedOrOtherFields: kept.has(value.buffer)});
        }
        const allFallbackBuffers = new Set(planBuffers);
        for (const key of ['sequenceList', 'readingEqualsExpressionList']) {
            const value = chunk[key];
            if (!kept.has(value.buffer)) { allFallbackBuffers.add(value.buffer); }
            views.push({field: key, type: value.constructor.name, bytes: value.byteLength, backingBytes: value.buffer.byteLength, alreadyNeededByPreparedOrOtherFields: kept.has(value.buffer)});
        }
        const sumBuffers = (buffers) => [...buffers].reduce((sum, buffer) => sum + buffer.byteLength, 0);
        const lookupCensus = {
            wholePreparedEntries: 1, keyCount: lookupPlan.stringLengths.length, preparedBytes: entry.bytes.byteLength,
            currentPlanExclusiveBackingBytes: sumBuffers(planBuffers),
            currentPlanAndSequenceFlagsExclusiveBackingBytes: sumBuffers(allFallbackBuffers),
            beyondExistingOwnedKeyExpressionReuseBytes: lookupPlan.readingIndexes.byteLength + chunk.sequenceList.byteLength + chunk.readingEqualsExpressionList.byteLength,
            readingExpressionRecoveryMatches, readingSentinelRecoveryMatches, directReadingRows,
            readingEqualRows: chunk.rowCount - directReadingRows,
            sequenceRawRecoveryMatches, negativeSequenceValues: [...negativeSequenceValues].sort((a, b) => a - b),
            allKeysAndExpressionsByteExact: true, allNormalizedSequencesExact: true,
            rawSequenceRecoveryExact: sequenceRawRecoveryMatches === chunk.rowCount,
            views,
        };
        const item = {
            lookupCensus,
            index: group.index, firstBank: group.firstBank, lastBank: group.lastBank, rows: chunk.rowCount,
            mediaRows: chunk.mediaRows.length, mediaHintRowsSkipped: profile.mediaHintRowsSkipped,
            projectedMediaRows: chunk.mediaRows.filter((item) => Array.isArray(item.imagePaths) && item.imagePaths.length > 0).length,
            sourceBytes: source.byteLength, sourceSha256: sha(source), contentBytesLength: chunk.contentBytesLength,
            sourceByteOffset: source.byteOffset, backingBytes: source.buffer.byteLength,
            sourceShared: source.buffer instanceof SharedArrayBuffer, fullBackingView,
            contentRowStart, sourceRowCount: plan.sourceRowCount, uniqueCount: plan.uniqueCount,
            averageBytesPerUnique: source.byteLength / plan.uniqueCount,
            shouldOwnTermContentBytes: shouldOwnTermContentBytes(chunk.contentBytesLength, plan.uniqueCount, plan.sourceRowCount, chunk.rowCount),
            shouldBorrowProjectedTermContent: shouldBorrowProjectedTermContent(chunk.contentBytesLength, plan.uniqueCount, plan.sourceRowCount, chunk.rowCount),
            ownsContentBytes, borrowsWorkerMemory, borrowedContentResultCount: profile.borrowedContentResultCount,
            completeOwnedShape, emptyMediaOwnedEligible: chunk.mediaRows.length === 0 && completeOwnedShape,
            nativeCounters: Object.fromEntries(Object.entries(profile).filter(([key, value]) => typeof value === 'number' && !key.endsWith('Ms'))),
        };
        assert.equal(item.sourceBytes, group.sourceBytes);
        assert.equal(item.sourceSha256, group.sourceSha256);
        assert.equal(item.nativeCounters.recentContentDedupHitCount, group.parseProfile.recentContentDedupHitCount);
        report.groups.push(item);
        await save();
        console.log(JSON.stringify({group: item.index, rows: item.rows, mediaRows: item.mediaRows, owned: ownsContentBytes, borrowed: borrowsWorkerMemory, sourceBytes: item.sourceBytes, completeOwnedShape}));
    }
    const empty = streaks((group) => group.mediaRows === 0);
    const eligible = streaks((group) => group.emptyMediaOwnedEligible);
    report.summary = {
        groups: report.groups.length, rows: report.groups.reduce((sum, group) => sum + group.rows, 0),
        mediaRows: report.groups.reduce((sum, group) => sum + group.mediaRows, 0),
        ownedGroups: report.groups.filter((group) => group.ownsContentBytes).length,
        borrowedGroups: report.groups.filter((group) => group.borrowsWorkerMemory).length,
        emptyMediaGroups: report.groups.filter((group) => group.mediaRows === 0).length,
        emptyMediaStreaks: empty, emptyMediaAdjacentPairs: empty.reduce((sum, item) => sum + item.groups - 1, 0),
        eligibleGroups: report.groups.filter((group) => group.emptyMediaOwnedEligible).length,
        eligibleStreaks: eligible, eligibleAdjacentPairs: eligible.reduce((sum, item) => sum + item.groups - 1, 0),
    };
    assert.equal(report.summary.rows, manifest.fixture.termRows);
    report.summary.lookupCensus = {
        currentPlanExclusiveBackingBytes: report.groups.reduce((sum, g) => sum + g.lookupCensus.currentPlanExclusiveBackingBytes, 0),
        currentPlanAndSequenceFlagsExclusiveBackingBytes: report.groups.reduce((sum, g) => sum + g.lookupCensus.currentPlanAndSequenceFlagsExclusiveBackingBytes, 0),
        beyondExistingOwnedKeyExpressionReuseBytes: report.groups.reduce((sum, g) => sum + g.lookupCensus.beyondExistingOwnedKeyExpressionReuseBytes, 0),
        maximumGroupPlanAndSequenceFlagsExclusiveBackingBytes: Math.max(...report.groups.map((g) => g.lookupCensus.currentPlanAndSequenceFlagsExclusiveBackingBytes)),
        rawSequenceRecoveryExact: report.groups.every((g) => g.lookupCensus.rawSequenceRecoveryExact),
        allKeysAndExpressionsByteExact: true,
        allNormalizedSequencesExact: true,
    };
    report.complete = true;
} catch (error) {
    report.failures.push({name: error.name, message: error.message, stack: error.stack});
    process.exitCode = 1;
} finally {
    terminationRequested = true;
    try { report.terminationCode = await worker.terminate(); } catch (error) { terminalFailures.push({type: 'termination', message: String(error)}); }
    report.terminalFailures = terminalFailures;
    if (terminalFailures.length || workerFailure) { report.complete = false; process.exitCode = 1; }
    await zip?.close(); await save();
    console.log(JSON.stringify({complete: report.complete, ...report.summary, failures: report.failures}));
}
