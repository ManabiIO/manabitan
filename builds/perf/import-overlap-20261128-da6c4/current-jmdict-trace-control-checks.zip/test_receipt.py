import copy
import importlib.util
import json
import pathlib
import unittest


DIRECTORY = pathlib.Path(__file__).resolve().parent
ROOT = DIRECTORY.parents[1]
SPEC = importlib.util.spec_from_file_location('trace_receipt', DIRECTORY / 'receipt.py')
RECEIPT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(RECEIPT)
HELPER_SPEC = importlib.util.spec_from_file_location('qualification_receipts', ROOT / 'baseline/dev/perf/import-memory-20261125-a7f7/qualification_receipts.py')
HELPER = importlib.util.module_from_spec(HELPER_SPEC)
HELPER_SPEC.loader.exec_module(HELPER)


def fixture():
    return {'traceEvents': [
        {'name': 'thread_name', 'pid': 1, 'tid': 2, 'args': {'name': 'DedicatedWorker thread'}},
        {'name': 'Profile', 'pid': 1, 'tid': 2, 'id': '0x1', 'args': {'data': {'startTime': 100}}},
        {'name': 'ProfileChunk', 'pid': 1, 'tid': 9, 'id': '0x1', 'args': {'data': {
            'cpuProfile': {'nodes': [
                {'id': 1, 'callFrame': {'functionName': '(root)', 'url': '', 'lineNumber': -1}},
                {'id': 2, 'parent': 1, 'callFrame': {'functionName': 'parse', 'url': 'chrome-extension://id/js/dictionary/term-bank-wasm-parser-worker.js', 'lineNumber': 99}},
            ], 'samples': [2, 2]}, 'timeDeltas': [5, -1],
        }}},
    ]}


class TraceReceiptTests(unittest.TestCase):
    def test_historical_trace_coverage_only(self):
        trace = json.loads((ROOT / 'profiling/current-profile-jmdict/trace/run-1.trace.json').read_bytes())
        rows = RECEIPT.inventory_trace(trace)
        self.assertEqual({role: sum(row['role'] == role for row in rows) for role in ['parser', 'compression', 'import']},
                         {'parser': 3, 'compression': 4, 'import': 1})
        self.assertTrue(all(row['sampleCount'] for row in rows))

    def test_emitter_thread_and_negative_deltas(self):
        row = RECEIPT.inventory_trace(fixture())[0]
        self.assertEqual((row['role'], row['tid'], row['sampleCount'], row['negativeRawDeltaCount']), ('parser', 2, 2, 1))

    def test_missing_sample_node(self):
        trace = fixture()
        trace['traceEvents'][2]['args']['data']['cpuProfile']['samples'][0] = 77
        with self.assertRaisesRegex(ValueError, 'Missing sampled node'):
            RECEIPT.inventory_trace(trace)

    def test_missing_parent(self):
        trace = fixture()
        trace['traceEvents'][2]['args']['data']['cpuProfile']['nodes'][1]['parent'] = 88
        with self.assertRaisesRegex(ValueError, 'Missing profile parent'):
            RECEIPT.inventory_trace(trace)

    def test_sample_delta_mismatch(self):
        trace = fixture()
        trace['traceEvents'][2]['args']['data']['timeDeltas'].pop()
        with self.assertRaisesRegex(ValueError, 'Sample/delta mismatch'):
            RECEIPT.inventory_trace(trace)

    def test_duplicate_profile(self):
        trace = fixture()
        trace['traceEvents'].insert(2, copy.deepcopy(trace['traceEvents'][1]))
        with self.assertRaisesRegex(ValueError, 'Duplicate profile identity'):
            RECEIPT.inventory_trace(trace)

    def test_conflicting_node(self):
        trace = fixture()
        entry = copy.deepcopy(trace['traceEvents'][2])
        entry['args']['data']['cpuProfile']['nodes'][1]['callFrame']['functionName'] = 'changed'
        trace['traceEvents'].append(entry)
        with self.assertRaisesRegex(ValueError, 'Changed profile node'):
            RECEIPT.inventory_trace(trace)

    def test_identical_node_repeat(self):
        trace = fixture()
        trace['traceEvents'].append(copy.deepcopy(trace['traceEvents'][2]))
        self.assertEqual(RECEIPT.inventory_trace(trace)[0]['sampleCount'], 4)

    def test_ambiguous_role(self):
        trace = fixture()
        trace['traceEvents'][2]['args']['data']['cpuProfile']['nodes'].append({
            'id': 3, 'parent': 1, 'callFrame': {'functionName': 'compress', 'url': 'chrome-extension://id/js/dictionary/zstd-term-content-compression-worker.js', 'lineNumber': 9},
        })
        with self.assertRaisesRegex(ValueError, 'Ambiguous worker profile'):
            RECEIPT.inventory_trace(trace)

    def validation(self):
        report = json.loads((ROOT / 'profiling/current-profile-jmdict/trace/run-1.json').read_bytes())
        validation = report['benchmark']['validation']
        # Pure verifier fixture: this historical source has zero media. It is
        # never relabeled as a current acquisition or timing observation.
        self.assertEqual(validation['media']['totalFiles'], 0)
        validation['media']['mode'] = 'all'
        fixture = json.loads((DIRECTORY / 'plan.json').read_text())['fixture']
        return validation, fixture

    def test_existing_full_semantic_gate(self):
        validation, corpus = self.validation()
        result = HELPER.canonicalize_validation(validation, dictionary='jmdict', fixture=corpus, media_check='all')
        self.assertEqual(len(result['lookup']['observations']), 72)

    def test_semantic_gate_rejects_missing_lookup(self):
        validation, corpus = self.validation()
        validation['lookup']['observations'].pop()
        with self.assertRaisesRegex(ValueError, '72 lookup'):
            HELPER.canonicalize_validation(validation, dictionary='jmdict', fixture=corpus, media_check='all')

    def test_semantic_gate_rejects_wrong_media_mode(self):
        validation, corpus = self.validation()
        validation['media']['mode'] = 'sample'
        with self.assertRaisesRegex(ValueError, 'media.mode'):
            HELPER.canonicalize_validation(validation, dictionary='jmdict', fixture=corpus, media_check='all')


if __name__ == '__main__':
    unittest.main(verbosity=2)
