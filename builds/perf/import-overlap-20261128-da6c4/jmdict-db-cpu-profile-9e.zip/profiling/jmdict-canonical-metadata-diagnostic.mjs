// Source-unchanged diagnostic replay; phase wrappers add observation overhead and establish no performance gain.
// Derived from db-pipeline-parity.mjs SHA256 7268e9a8a1e05e13a44d977ccf923529578354147de0ad4ed4ac941f2606e8c7.
// Scratch correctness replay. Production DB content/record methods and codecs;
// Node OPFS/Worker transports and an already-active empty bulk-session bootstrap.
// No SQLite setup/publication, browser scheduling, or elapsed-time claim.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream} from 'node:fs';
import {readFile, writeFile, mkdir, readdir, rename} from 'node:fs/promises';
import {Worker as NodeWorker} from 'node:worker_threads';
import {pathToFileURL, fileURLToPath} from 'node:url';
import {parseArgs} from 'node:util';
import {execFileSync} from 'node:child_process';
import path from 'node:path';
import {loadProductionGroups} from './production-group-loader.mjs';
import {createReplayOpfs} from './replay-node-opfs.mjs';

const {values} = parseArgs({options: {
    baseline: {type: 'string', default: '/workspace/scratch/da6c4dbd0097/baseline'},
    candidate: {type: 'string', default: '/workspace/scratch/da6c4dbd0097/startup-experiment'},
    manifest: {type: 'string', default: '/workspace/scratch/da6c4dbd0097/profiling/compression-groups/jmdict/manifest.json'},
    cache: {type: 'string', default: '/workspace/scratch/da6c4dbd0097/fixtures'},
    groups: {type: 'string', default: '12'},
    arm: {type: 'string', default: 'baseline'},
    out: {type: 'string', default: '/workspace/scratch/da6c4dbd0097/analysis/jmdict-canonical-metadata-diagnostic.json'},
    'force-overlap': {type: 'boolean', default: false},
}});
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const viewBytes = (view) => new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
const manifestBytes = await readFile(values.manifest);
const manifest = JSON.parse(manifestBytes);
assert.equal(manifest.dictionary, 'jmdict');
assert(manifest.complete);
const groupCount = Number(values.groups);
assert(Number.isInteger(groupCount) && groupCount >= 3 && groupCount <= manifest.groups.length);
assert(['both', 'baseline', 'candidate'].includes(values.arm));
const sourceFiles = [...new Set([
    ...Object.keys(manifest.sourceHashes),
    'ext/js/dictionary/term-record-opfs-store.js',
    'ext/js/dictionary/term-content-opfs-store.js',
    'ext/js/dictionary/term-content-ownership.js',
    'ext/js/dictionary/term-record-import-index-writer.js',
    'ext/js/dictionary/artifact-term-chunk-pipeline.js',
])];
async function sourceIdentity(root) {
    const hashes = {};
    for (const file of sourceFiles) {
        try { hashes[file] = sha(await readFile(path.join(root, file))); } catch (error) {
            if (error.code !== 'ENOENT') { throw error; }
            hashes[file] = null;
        }
    }
    return {root, head: execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim(), hashes};
}
const report = {
    schemaVersion: 1, complete: false, node: process.version,
    scope: 'Correctness component: native original-ZIP inflate/parser, complete owned columns, actual DB canonical dedup/metadata/record encoding, production four-worker Zstd and actual 1 MiB DB block target, real stores over Node file-backed OPFS. Empty active bulk state bootstrapped; SQLite setup, journal and COMMIT, browser IPC/UI and browser OPFS are excluded. No latency or peak-memory claim.',
    configurationCorrection: 'Earlier preserved 31-block/12-round codec study used standalone 4 MiB blocks. That is not the current DB production default and establishes no production-default gain. This replay leaves the actual DB 1 MiB target unchanged.',
    fixture: manifest.fixture, groups: groupCount, armSelection: values.arm, manifestSha256: sha(manifestBytes),
    harnessHashes: {}, arms: {}, failures: [],
};
for (const file of ['jmdict-canonical-metadata-diagnostic.mjs', 'db-pipeline-parity.mjs', 'production-group-loader.mjs', 'compression-worker-node-bridge.mjs', 'replay-node-opfs.mjs']) {
    report.harnessHashes[file] = sha(await readFile(new URL(file, import.meta.url)));
}
const save = async () => {
    const temporary = values.out + '.checkpoint.tmp';
    await writeFile(temporary, JSON.stringify(report, null, 2) + '\n');
    await rename(temporary, values.out);
};
await mkdir(path.dirname(values.out), {recursive: true});
await writeFile(values.out, JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
const archiveHash = createHash('sha256');
let archiveBytes = 0;
for await (const bytes of createReadStream(path.join(values.cache, manifest.fixture.cacheFile))) { archiveHash.update(bytes); archiveBytes += bytes.length; }
assert.equal(archiveBytes, manifest.fixture.sizeBytes);
assert.equal(archiveHash.digest('hex'), manifest.fixture.sha256);

const originalFetch = globalThis.fetch;
globalThis.fetch = async (input, options) => {
    const url = input instanceof URL ? input : new URL(typeof input === 'string' ? input : input.url);
    if (url.protocol !== 'file:') { return originalFetch(input, options); }
    return new Response(await readFile(url), {headers: {'Content-Type': url.pathname.endsWith('.wasm') ? 'application/wasm' : 'application/octet-stream'}});
};

function expectedProbes(chunk, firstId) {
    const plan = chunk.termRecordPreinternedPlan;
    const offsets = plan.stringOffsets ?? new Uint32Array(plan.stringLengths.length);
    if (!plan.stringOffsets) { let offset = 0; for (let i = 0; i < offsets.length; ++i) { offsets[i] = offset; offset += plan.stringLengths[i]; } }
    const decoder = new TextDecoder('utf-8', {ignoreBOM: true});
    const key = (index) => decoder.decode(plan.stringsBuffer.subarray(offsets[index], offsets[index] + plan.stringLengths[index]));
    return [...new Set([0, Math.floor(chunk.rowCount / 2), chunk.rowCount - 1])].map((row) => {
        const unique = chunk.contentUniqueIndexList[row];
        const metaIndex = (chunk.contentMetaByUniqueIndex ? unique : row) * 4;
        const start = chunk.contentBytesBaseOffset + chunk.contentMetaList[metaIndex];
        const content = chunk.contentBytesBuffer.subarray(start, start + chunk.contentMetaList[metaIndex + 1]);
        const expression = key(plan.expressionIndexes[row]);
        const reading = chunk.readingEqualsExpressionList[row] ? expression : key(plan.readingIndexes[row]);
        return {id: firstId + row, expression, reading,
            sequence: typeof chunk.sequenceList[row] === 'number' && chunk.sequenceList[row] >= 0 ? chunk.sequenceList[row] : null,
            score: chunk.scoreList[row], scoreNegativeZero: Object.is(chunk.scoreList[row], -0),
            contentLength: content.byteLength, contentSha256: sha(content)};
    });
}

async function storedFiles(rootPath) {
    const files = [];
    async function visit(directory, prefix) {
        for (const entry of await readdir(directory, {withFileTypes: true})) {
            const name = path.posix.join(prefix, entry.name);
            if (entry.isDirectory()) { await visit(path.join(directory, entry.name), name); } else { files.push(name); }
        }
    }
    await visit(rootPath, '');
    files.sort();
    const bytesByName = new Map();
    for (const name of files) { bytesByName.set(name, await readFile(path.join(rootPath, name))); }
    const result = [];
    for (const [name, bytes] of bytesByName) {
        const normalized = Buffer.from(bytes);
        const masks = [];
        if (name.endsWith('.mbtr')) {
            assert.equal(bytes.subarray(0, 8).toString(), 'MBTRD16X');
            const index = bytesByName.get(name + '.mbti');
            assert(index, 'Descriptor lacks authoritative index');
            assert.deepEqual(bytes.subarray(8, 24), index.subarray(24, 40));
            assert(bytes.subarray(8, 24).some((value) => value !== 0));
            normalized.fill(0, 8, 24); masks.push({offset: 8, length: 16, reason: 'random generation ID, validated against paired authoritative index'});
        } else if (name.endsWith('.mbti')) {
            assert.equal(bytes.subarray(0, 8).toString(), 'MBTIDX11');
            assert(bytesByName.has(name.slice(0, -5)));
            normalized.fill(0, 24, 40); masks.push({offset: 24, length: 16, reason: 'random generation ID, validated against paired descriptor'});
        }
        result.push({name, bytes: bytes.byteLength, rawSha256: sha(bytes), normalizedSha256: sha(normalized), masks});
    }
    return result;
}

async function runArm(arm, root) {
    const result = {source: await sourceIdentity(root), complete: false, groups: [], events: [], jobs: [], probes: [], maxPendingOwners: 0, maxPendingOwnedSourceBytes: 0, forcedResponseHoldCount: 0};
    report.arms[arm] = result;
    await save();
    const load = (file) => import(pathToFileURL(path.join(root, file)));
    const filesystem = await createReplayOpfs(values.baseline);
    result.opfsDirectory = filesystem.rootPath;
    Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: 4, deviceMemory: 8, storage: {getDirectory: async () => filesystem.root}}});
    result.phaseDiagnostics = {scope: 'One sequential, instrumented Node component; nested wall clocks, including observation overhead; no A/B or browser gain claim.', native: [], syncMethods: [], recordChunks: []};
    const sourceGroups = new WeakMap();
    const workerFailures = [];
    let diagnosticGroup = -1;
    const workers = [];
    const heldMessages = [];
    let gateReleased = arm !== 'candidate' || !values['force-overlap'];
    let observeGate;
    const gateObserved = new Promise((resolve) => { observeGate = resolve; });
    let eventOrdinal = 0;
    const event = (type, group, details = {}) => result.events.push({ordinal: ++eventOrdinal, type, group, ...details});
    const releaseGate = () => {
        gateReleased = true;
        for (const deliver of heldMessages.splice(0)) { deliver(); }
    };
    class BrowserWorkerAdapter {
        constructor(entry) {
            assert(new URL(entry).pathname.endsWith('/zstd-term-content-compression-worker.js'), 'Unexpected worker route in JMdict replay');
            this.index = workers.length;
            this.listeners = new Map();
            this.jobs = new Map();
            this.terminationRequested = false;
            this.worker = new NodeWorker(new URL('./compression-worker-node-bridge.mjs', import.meta.url), {workerData: {entry: String(entry)}, execArgv: []});
            workers.push(this);
            this.worker.on('message', (message) => {
                const deliver = () => {
                    if (message.compressed instanceof ArrayBuffer) {
                        const job = this.jobs.get(message.id);
                        assert(job);
                        job.outputBytes = message.compressed.byteLength;
                        job.outputSha256 = sha(new Uint8Array(message.compressed));
                        event('compressed', job.group, {job: message.id, worker: this.index});
                    }
                    for (const listener of this.listeners.get('message') ?? []) { listener({data: message}); }
                };
                if (!gateReleased && message.compressed instanceof ArrayBuffer && this.jobs.get(message.id)?.group === 1) {
                    ++result.forcedResponseHoldCount;
                    heldMessages.push(deliver);
                    observeGate();
                } else { deliver(); }
            });
            this.worker.on('exit', (code) => {
                if (!this.terminationRequested) { workerFailures.push({worker: this.index, type: 'unexpected-exit', code}); }
            });
            this.worker.on('error', (error) => {
                workerFailures.push({worker: this.index, type: 'error', message: String(error)});
                for (const listener of this.listeners.get('error') ?? []) { listener({error, message: error.message}); }
            });
        }
        addEventListener(type, listener) { if (!this.listeners.has(type)) { this.listeners.set(type, new Set()); } this.listeners.get(type).add(listener); }
        removeEventListener(type, listener) { this.listeners.get(type)?.delete(listener); }
        postMessage(message, transfer) {
            const group = sourceGroups.get(message.source?.buffer);
            assert(Number.isInteger(group), 'Compression source lacks original group identity');
            const job = {id: message.id, group, worker: this.index, inputBytes: message.contentBytes};
            this.jobs.set(message.id, job); result.jobs.push(job);
            event('compression-dispatched', group, {job: message.id, worker: this.index});
            this.worker.postMessage(message, transfer);
            if (!gateReleased && group === 2) { event('response-gate-released', group); releaseGate(); }
        }
        terminate() { this.terminationRequested = true; return this.worker.terminate(); }
    }
    globalThis.Worker = BrowserWorkerAdapter;
    const {DictionaryDatabase} = await load('ext/js/dictionary/dictionary-database.js');
    const {NativeCanonicalScanner} = await load('ext/js/dictionary/term-content-canonical-scan.js');
    const {registerOwnedTermContent} = await load('ext/js/dictionary/term-content-ownership.js');
    const codec = await load('ext/js/dictionary/zstd-term-content.js');
    await codec.initializeTermContentZstd();
    const db = new DictionaryDatabase();
    db.setImportOptimizationFlags({termContentStorageMode: 'raw-bytes', queueTermContentWrites: true, rawTermBankSourceBytes: manifest.totalSourceBytes, termContentBlockTargetBytes: null});
    db.setTermEntryContentDedupEnabled(true);
    result.actualBlockTargetBytes = db._termContentBlockStore._blockTargetBytes;
    assert.equal(result.actualBlockTargetBytes, 1048576);
    const canonicalModule = await WebAssembly.compile(await readFile(path.join(root, 'ext/lib/term-content-canonical-scan-v1.wasm')));
    let nativeDiagnostic = null;
    let segment = null;
    const phaseNow = () => performance.now();
    const scanner = new NativeCanonicalScanner({
        loadModule: async () => {
            if (nativeDiagnostic !== null) { nativeDiagnostic.moduleRequestedMs = phaseNow(); }
            return canonicalModule;
        },
        hooks: {
            beforeNative({a, beforeDense, beforePending}) {
                const now = phaseNow();
                segment = {beforeNativeMs: now, beforeDense, beforePending, arenaBytes: a.memory.buffer.byteLength};
                nativeDiagnostic.segments.push(segment);
            },
            beforeOutputView({header, column}) {
                if (column === 0) {
                    segment.nativeReturnMs = phaseNow();
                    segment.nativeMs = segment.nativeReturnMs - segment.beforeNativeMs;
                    segment.pendingRows = header[2];
                    segment.exactRows = header[3];
                }
            },
            beforeAdopt() { segment.beforeAdoptMs = phaseNow(); },
            afterPendingCopy() {
                segment.afterPendingCopyMs = phaseNow();
                segment.pendingCopyMs = segment.afterPendingCopyMs - segment.beforeAdoptMs;
            },
        },
    });
    const scan = scanner.scan;
    scanner.scan = async function(owner, context, metrics) {
        const diagnostic = {group: diagnosticGroup, startMs: phaseNow(), segments: [], exact: [], uniqueRows: context.lastUniqueIndex - context.firstUniqueIndex};
        nativeDiagnostic = diagnostic;
        result.phaseDiagnostics.native.push(diagnostic);
        const resolve = context.resolveExactCandidates;
        const observedContext = {...context, resolveExactCandidates: async () => {
            const startMs = phaseNow();
            try { return await resolve(); } finally { diagnostic.exact.push({startMs, endMs: phaseNow()}); }
        }};
        try { return await scan.call(this, owner, observedContext, metrics); }
        finally {
            diagnostic.endMs = phaseNow();
            diagnostic.totalMs = diagnostic.endMs - diagnostic.startMs;
            diagnostic.beforeFirstNativeMs = diagnostic.segments[0].beforeNativeMs - diagnostic.startMs;
            diagnostic.stats = {...this.stats};
            nativeDiagnostic = null;
            segment = null;
        }
    };
    db._nativeCanonicalScanner = scanner;
    function observeSync(owner, method) {
        const implementation = owner[method];
        assert.equal(typeof implementation, 'function', method);
        owner[method] = function(...args) {
            const observation = {group: diagnosticGroup, method, startMs: phaseNow()};
            let returned;
            try {
                returned = implementation.apply(this, args);
                return returned;
            } finally {
                observation.endMs = phaseNow();
                observation.elapsedMs = observation.endMs - observation.startMs;
                if (typeof returned === 'boolean') { observation.returnedBoolean = returned; }
                if (method === '_encodeArtifactRecordFields' && returned instanceof Uint8Array) {
                    observation.rows = args[0].rowCount;
                    observation.encodedBytes = returned.byteLength;
                    observation.encodedSha256 = sha(returned);
                }
                result.phaseDiagnostics.syncMethods.push(observation);
            }
        };
    }
    for (const method of [
        '_ensureTermEntryContentMetaHashPairCapacity',
        '_registerInFlightTermContentSources',
        '_publishResolvedArtifactTermContentPlan',
        '_tryPublishContiguousArtifactTermContentMetadata',
        '_publishArtifactTermContentMetadata',
        '_cacheRecentPublishedTermContentSources',
    ]) { observeSync(db, method); }
    observeSync(db._termRecordStore, '_encodeArtifactRecordFields');
    const encode = db._termRecordStore._encodeAndAppendArtifactChunkForState;
    db._termRecordStore._encodeAndAppendArtifactChunkForState = async function(...args) {
        const observation = {group: diagnosticGroup, rows: args[1].rowCount, startMs: phaseNow()};
        try {
            const metrics = await encode.apply(this, args);
            observation.metrics = metrics;
            return metrics;
        } finally {
            observation.endMs = phaseNow();
            observation.elapsedMs = observation.endMs - observation.startMs;
            result.phaseDiagnostics.recordChunks.push(observation);
        }
    };
    await db._termContentStore.prepare();
    await db._termRecordStore.prepare();
    await db._termContentStore.beginImportSession();
    await db._termRecordStore.beginImportSession();
    db._bulkImportState = 'active';
    db._bulkImportTransactionOpen = true;
    db._bulkImportJournalRecord = {sessionId: `component-${arm}`};
    db._deferTermsVirtualTableSync = true;
    db._termContentZstdInitialized = true;
    db._termContentBlockImportSession = db._termContentBlockStore.beginImportSession();
    const inputHash = createHash('sha256');
    const activeOwners = new Map();
    const tickets = [];
    let previous = null;
    let rows = 0;
    let timer;
    const gateTimeout = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Deterministic compression response gate was not exercised')), 15000); });
    void gateTimeout.catch(() => {});
    try {
        for await (const {group, profile, chunk} of loadProductionGroups({root, manifestPath: values.manifest, cache: values.cache})) {
            if (group.index >= groupCount) { break; }
            diagnosticGroup = group.index;
            assert.equal(chunk.contentRowStart, 0);
            assert.equal(chunk.contentDedupPlan.sourceRowCount, chunk.rowCount);
            assert(chunk.useResolvedContentReferences);
            assert(registerOwnedTermContent(chunk.contentBytesBuffer));
            sourceGroups.set(chunk.contentBytesBuffer.buffer, group.index);
            inputHash.update(String(chunk.rowCount));
            for (const field of ['readingEqualsExpressionList', 'scoreList', 'sequenceList', 'contentMetaList', 'contentUniqueIndexList', 'contentBytesBuffer']) { inputHash.update(viewBytes(chunk[field])); }
            for (const [key, prepared] of chunk.preparedLookupIndexes) { inputHash.update(key); inputHash.update(prepared.bytes); }
            result.probes.push(...expectedProbes(chunk, rows + 1));
            const groupResult = {index: group.index, rows: chunk.rowCount, sourceBytes: chunk.contentBytesBuffer.byteLength, inputSourceSha256: sha(chunk.contentBytesBuffer), parserProfile: profile};
            result.groups.push(groupResult);
            rows += chunk.rowCount;
            event('begin', group.index);
            activeOwners.set(group.index, chunk.contentBytesBuffer.byteLength);
            result.maxPendingOwners = Math.max(result.maxPendingOwners, activeOwners.size);
            result.maxPendingOwnedSourceBytes = Math.max(result.maxPendingOwnedSourceBytes, [...activeOwners.values()].reduce((sum, bytes) => sum + bytes, 0));
            assert(activeOwners.size <= (arm === 'candidate' ? 2 : 1));
            const operation = arm === 'candidate' ? db.beginBulkAddArtifactTermsChunk(chunk, `component-${arm}`) : {
                published: null,
                completion: db.bulkAddArtifactTermsChunk(chunk).then(() => db.getLastBulkAddTermsMetrics()),
            };
            const completion = operation.completion.then((metrics) => {
                groupResult.metrics = metrics;
                assert.equal(metrics.dedupNativeFallbackCount, 0);
                assert.equal(metrics.dedupUniqueCount, manifest.groups[group.index].uniqueContentCount);
                event('completed', group.index);
            }).finally(() => { activeOwners.delete(group.index); });
            void completion.catch(() => {});
            tickets.push(completion);
            if (arm === 'candidate') {
                await operation.published;
                event('published', group.index);
                if (group.index === 1 && !gateReleased) { await Promise.race([gateObserved, gateTimeout]); }
                if (previous !== null) { await previous; }
                previous = completion;
            } else { await completion; }
            await save();
            globalThis.gc?.();
            console.log(JSON.stringify({arm, group: group.index, rows, pendingOwners: activeOwners.size, memory: process.memoryUsage()}));
            if (group.index + 1 >= groupCount) { break; }
        }
        await Promise.all(tickets);
        if (arm === 'candidate') { await db._artifactTermChunkPipeline.close(); }
        assert.equal(activeOwners.size, 0);
        assert.equal(db._inFlightTermContentSourceBatches.size, 0);
        if (arm === 'candidate' && values['force-overlap']) {
            assert(result.forcedResponseHoldCount > 0);
            const nextDispatch = result.events.find((entry) => entry.type === 'compression-dispatched' && entry.group === 2);
            const previousCompletion = result.events.find((entry) => entry.type === 'completed' && entry.group === 1);
            assert(nextDispatch && previousCompletion && nextDispatch.ordinal < previousCompletion.ordinal);
        }
        result.metadata = {count: db._termEntryContentMetaHashPairCount, denseCount: db._termEntryContentMetaDenseCount, pendingCount: db._termEntryContentMetaHashPairPendingCount, columns: {}};
        for (const field of ['HashPairTable', 'Hash1Table', 'Hash2Table', 'StateTable', 'IdTable', 'OffsetTable', 'LengthTable', 'DictNameIdTable', 'SignaturePresentTable', 'Signature1Table', 'Signature2Table', 'Signature3Table']) {
            const array = db[`_termEntryContentMeta${field}`];
            result.metadata.columns[field] = {bytes: array.byteLength, sha256: sha(viewBytes(array))};
        }
        result.inputSha256 = inputHash.digest('hex');
        result.rows = rows;
        result.workerCount = workers.length;
        result.blockCount = result.jobs.length;
        assert.equal(workers.length, 4);
        assert.equal(result.blockCount, [9, 9, 9, 9, 9, 9, 7, 8, 8, 8, 8, 10].slice(0, groupCount).reduce((sum, count) => sum + count, 0));
        await Promise.all([db._termContentStore.endImportSession(), db._termRecordStore.endImportSession()]);
        db._termContentBlockImportSession.close();
        assert.equal(filesystem.locks.size, 0);
        result.files = await storedFiles(filesystem.rootPath);
        result.storageOperations = filesystem.operations;
        const reopened = new DictionaryDatabase();
        reopened._termContentZstdInitialized = true;
        await reopened._termContentStore.prepare();
        await reopened._termRecordStore.prepare();
        await reopened._termRecordStore.ensureDictionariesLoaded([manifest.fixture.expectedTitle]);
        const records = await reopened._termRecordStore.getByIdsAsync(result.probes.map(({id}) => id));
        for (const expected of result.probes) {
            const record = records.get(expected.id);
            assert(record, `Missing persisted record ${expected.id}`);
            assert.equal(record.expression, expected.expression); assert.equal(record.reading, expected.reading);
            assert.equal(record.sequence, expected.sequence); assert.equal(record.score, expected.score);
            assert.equal(Object.is(record.score, -0), expected.scoreNegativeZero);
            const content = await reopened._readTermEntryContentBytesDetailed(record.entryContentOffset, record.entryContentLength, record.entryContentDictName);
            assert.equal(content.status, 'ok');
            assert.equal(content.bytes.byteLength, expected.contentLength); assert.equal(sha(content.bytes), expected.contentSha256);
        }
        result.reopenedProbeCount = result.probes.length;
        result.integrity = await reopened._termRecordStore.verifyIntegrity();
        assert.equal(result.integrity.invalidShardPayloadCount, 0);
        assert.equal(result.integrity.missingShardCount, 0);
        assert.equal(result.integrity.orphanShardCount, 0);
        assert.deepEqual(await sourceIdentity(root), result.source);
        result.complete = true;
        console.log(JSON.stringify({arm, complete: true, rows, groups: groupCount, blocks: result.blockCount, owners: result.maxPendingOwners, forcedHoldCount: result.forcedResponseHoldCount, files: result.files.map(({name, bytes, normalizedSha256}) => ({name, bytes, normalizedSha256}))}));
    } finally {
        clearTimeout(timer);
        releaseGate();
        await Promise.allSettled(tickets);
        const termination = await Promise.allSettled(workers.map((worker) => worker.terminate()));
        result.phaseDiagnostics.workerFailures = workerFailures;
        result.phaseDiagnostics.workerTermination = termination.map((entry) => ({status: entry.status, ...(entry.status === 'fulfilled' ? {code: entry.value} : {reason: String(entry.reason)})}));
        if (workerFailures.length || termination.some((entry) => entry.status === 'rejected')) { result.complete = false; }
        assert.deepEqual(workerFailures, []);
        assert(termination.every((entry) => entry.status === 'fulfilled'));
        await save();
    }
}

try {
    if (values.arm !== 'candidate') { await runArm('baseline', path.resolve(values.baseline)); globalThis.gc?.(); }
    if (values.arm !== 'baseline') { await runArm('candidate', path.resolve(values.candidate)); }
    if (values.arm !== 'both') {
        report.complete = true;
        report.parity = {singleArmOnly: true, requiresOtherArmComparison: true};
        await save();
        process.exit(0);
    }
    const a = report.arms.baseline, b = report.arms.candidate;
    assert(a.complete && b.complete);
    assert.equal(a.inputSha256, b.inputSha256);
    assert.equal(a.rows, b.rows);
    assert.deepEqual(a.metadata, b.metadata);
    assert.deepEqual(a.probes, b.probes);
    assert.deepEqual(a.files.map(({name, bytes, normalizedSha256, masks}) => ({name, bytes, normalizedSha256, masks})), b.files.map(({name, bytes, normalizedSha256, masks}) => ({name, bytes, normalizedSha256, masks})));
    const orderedJobs = (arm) => [...arm.jobs].sort((x, y) => x.id - y.id).map(({id, group, inputBytes, outputBytes, outputSha256}) => ({id, group, inputBytes, outputBytes, outputSha256}));
    assert.deepEqual(orderedJobs(a), orderedJobs(b));
    const metrics = ['dedupPendingHitCount', 'dedupPersistedHitCount', 'dedupUniqueCount', 'dedupExactFallbackCount', 'dedupNativeCallCount', 'dedupNativeFallbackCount'];
    assert.deepEqual(a.groups.map((group) => metrics.map((field) => group.metrics[field])), b.groups.map((group) => metrics.map((field) => group.metrics[field])));
    report.parity = {allSourceInputs: true, allMetadataColumns: true, everyCompressedBlock: true, everyPersistedFileAfterValidatedGenerationMask: true, rowCounts: true, nativeDedupCounts: true, reopenedSourceProbes: true};
    report.complete = true;
    await save();
} catch (error) {
    report.failures.push({message: String(error), stack: error.stack});
    await save();
    throw error;
}
