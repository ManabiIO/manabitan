// Scratch-only clock alignment for a source-unchanged --cpu-prof replay.
import {writeFileSync, readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const output = process.env.MANABITAN_CPU_PROFILE_CLOCK;
if (!output) { throw new Error('MANABITAN_CPU_PROFILE_CLOCK is required'); }
const report = {schemaVersion: 1, node: process.version, pid: process.pid, intervalUs: 500, clocks: [], argv: process.argv, execArgv: process.execArgv, sourceSha256: createHash('sha256').update(readFileSync(new URL(import.meta.url))).digest('hex')};
function capture(phase) {
    const beforeNs = process.hrtime.bigint();
    const performanceMs = performance.now();
    const afterNs = process.hrtime.bigint();
    report.clocks.push({phase, beforeNs: String(beforeNs), afterNs: String(afterNs), midpointUs: Number((beforeNs + afterNs) / 2n) / 1000, performanceMs, timeOriginMs: performance.timeOrigin, epochMs: Date.now()});
}
capture('preload');
process.once('beforeExit', () => { capture('beforeExit'); });
process.once('exit', (code) => { capture('exit'); report.exitCode = code; writeFileSync(output, JSON.stringify(report, null, 2) + '\n'); });
