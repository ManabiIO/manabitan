#!/usr/bin/env python3
"""Exact retained V8 CPU-profile aggregation; no latency or speed-up estimate."""
import argparse,collections,hashlib,json,pathlib,statistics
p=argparse.ArgumentParser();p.add_argument('--profile',required=True);p.add_argument('--clock',required=True);p.add_argument('--report',required=True);p.add_argument('--out',required=True);a=p.parse_args()
def read(path):
 data=pathlib.Path(path).read_bytes();return json.loads(data),{'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
d,di=read(a.profile);clock,ci=read(a.clock);report,ri=read(a.report)
assert report['complete'] and not report['failures'] and clock['exitCode']==0
assert len(d['samples'])==len(d['timeDeltas']) and d['endTime']>d['startTime']
nodes={n['id']:n for n in d['nodes']};parent={c:n['id'] for n in d['nodes'] for c in n.get('children',[])}
assert len(parent)==len(nodes)-1
chains={}
def chain(i):
 if i not in chains: chains[i]=[i]+(chain(parent[i]) if i in parent else [])
 return chains[i]
def label(i):
 f=nodes[i]['callFrame'];return (f['functionName'] or '(anonymous)',f['url'],f['lineNumber']+1)
def key(i):return '\n'.join(map(str,label(i)))
self_time=collections.Counter();inclusive=collections.Counter();self_count=collections.Counter();grouped_self=collections.Counter();grouped_count=collections.Counter();nearest_runtime=collections.Counter();wasm_callers=collections.Counter()
anchor=clock['clocks'][0];offset=anchor['midpointUs']/1000-anchor['performanceMs'];offsets=[x['midpointUs']/1000-x['performanceMs'] for x in clock['clocks']]
assert max(offsets)-min(offsets)<1,('Unstable hrtime/performance offset',offsets)
assert d['startTime']<=anchor['midpointUs']<=d['endTime'],('V8 clock basis mismatch',d['startTime'],anchor,d['endTime'])
assert clock['clocks'][-1]['midpointUs']<=d['endTime']+100000
arm=report['arms']['baseline'];diag=arm['phaseDiagnostics'];phases=[]
for item in diag['syncMethods']:
 phases.append({'kind':'sync','method':item['method'],'group':item['group'],'startMs':item['startMs'],'endMs':item['endMs'],'wallMs':item['elapsedMs'],'sampleUs':0,'self':collections.Counter(),'samples':0})
for item in diag['native']:
 phases.append({'kind':'native-scan','method':'NativeCanonicalScanner.scan','group':item['group'],'startMs':item['startMs'],'endMs':item['endMs'],'wallMs':item['totalMs'],'sampleUs':0,'self':collections.Counter(),'samples':0})
for item in diag['recordChunks']:
 phases.append({'kind':'record-sink','method':'_encodeAndAppendArtifactChunkForState','group':item['group'],'startMs':item['startMs'],'endMs':item['endMs'],'wallMs':item['elapsedMs'],'sampleUs':0,'self':collections.Counter(),'samples':0})
t=d['startTime'];sample_times=[]
for node_id,delta in zip(d['samples'],d['timeDeltas']):
 assert delta>=0
 t+=delta;sample_times.append(t);frames=chain(node_id);self_time[node_id]+=delta;self_count[node_id]+=1
 for i in frames:inclusive[i]+=delta
 k=key(node_id);grouped_self[k]+=delta;grouped_count[k]+=1
 runtime=next((i for i in frames if '/ext/js/' in nodes[i]['callFrame']['url']),None)
 if runtime is not None:nearest_runtime[key(runtime)]+=delta
 f=nodes[node_id]['callFrame'];name=f['functionName'];url=f['url']
 if url.startswith('wasm:') or name.startswith('wasm-function'):
  js=next((i for i in frames if '/ext/js/' in nodes[i]['callFrame']['url']),None)
  wasm_callers[key(js) if js is not None else '(no runtime JS caller)']+=delta
 perf=t/1000-offset
 for phase in phases:
  if phase['startMs']<=perf<=phase['endMs']:
   phase['sampleUs']+=delta;phase['self'][k]+=delta;phase['samples']+=1

def serialize(counter,counts=None,limit=40):
 out=[]
 for k,us in counter.most_common(limit):
  parts=k.split('\n');row={'function':parts[0],'url':parts[1] if len(parts)>1 else '', 'line':int(parts[2]) if len(parts)>2 else None,'sampleMs':us/1000}
  if counts is not None:row['samples']=counts[k]
  out.append(row)
 return out
phase_summary={}
for phase in phases:
 method=phase['method'];s=phase_summary.setdefault(method,{'calls':0,'wallMsSum':0,'sampleUsSum':0,'samples':0,'self':collections.Counter()})
 s['calls']+=1;s['wallMsSum']+=phase['wallMs'];s['sampleUsSum']+=phase['sampleUs'];s['samples']+=phase['samples'];s['self'].update(phase['self'])
 phase['topSelf']=serialize(phase.pop('self'),limit=12);phase['sampleMs']=phase.pop('sampleUs')/1000
for s in phase_summary.values():s['sampleMsSum']=s.pop('sampleUsSum')/1000;s['topSelf']=serialize(s.pop('self'),limit=20)
result={'schemaVersion':1,'scope':'One instrumented sequential Node replay. V8 sampled self time is not CPU utilization or a benchmark gain. Main-thread native parsing occurs serially in this harness; real browser parser workers differ. Worker adapters opt out of inherited execArgv so compression-worker CPU is excluded. Nested phase windows and inclusive/self attributions overlap and must not be added. Hashing, file-backed OPFS, strict verification and instrumentation remain present; their frames are reported explicitly.','source':arm['source'],'fixture':report['fixture'],'inputs':{'profile':di,'clock':ci,'diagnostic':ri},'complete':True,'rows':sum(g['rows'] for g in arm['groups']),'groups':len(arm['groups']),'jobs':len(arm['jobs']),'workerFailures':arm.get('workerFailures'),'clockAlignment':{'performanceOffsetMs':offset,'offsetRangeMs':max(offsets)-min(offsets),'profileStartUs':d['startTime'],'profileEndUs':d['endTime'],'firstSampleUs':sample_times[0],'lastSampleUs':sample_times[-1]},'sampleStats':{'count':len(d['samples']),'reportedIntervalUs':clock['intervalUs'],'deltaMedianUs':statistics.median(d['timeDeltas']),'deltaMaxUs':max(d['timeDeltas']),'sampledMs':sum(d['timeDeltas'])/1000,'durationMs':(d['endTime']-d['startTime'])/1000},'topLeafSelf':serialize(grouped_self,grouped_count,100),'nearestRuntimeLeafAttribution':serialize(nearest_runtime,limit=60),'wasmNearestRuntimeCaller':serialize(wasm_callers,limit=30),'phaseWindows':phases,'phaseSummary':phase_summary}
pathlib.Path(a.out).write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'complete':True,'sampleStats':result['sampleStats'],'topLeafSelf':result['topLeafSelf'][:25],'phaseSummary':{m:{k:v for k,v in s.items() if k!='topSelf'} for m,s in phase_summary.items()}},indent=2))
