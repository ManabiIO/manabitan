import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
const root='/workspace/scratch/da6c4dbd0097';
const sourceRoot=path.join(root,'baseline');
const directory=path.join(root,'profiling/compression-groups/jmdict');
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const originalBytes=await readFile(path.join(directory,'manifest.json'));
const manifest=JSON.parse(originalBytes);
assert(manifest.complete);
const blockSource=await readFile(path.join(sourceRoot,'ext/js/dictionary/term-content-block-store.js'),'utf8');
const databaseSource=await readFile(path.join(sourceRoot,'ext/js/dictionary/dictionary-database.js'),'utf8');
const constant=/^const TERM_CONTENT_BLOCK_TARGET_BYTES = (.*);$/m.exec(databaseSource);
assert(constant&&/^[0-9 *]+$/.test(constant[1]),'Frozen database target must be a numeric expression');
const targetBytes=new Function('return '+constant[1])();
assert.equal(targetBytes,1048576);
const start=blockSource.indexOf('function planContentSpansIntoSlabs(sourceLengths, targetBytes) {');
const end=blockSource.indexOf('\n}\n',start)+3;
assert(start>0&&end>start);
const plannerSource=blockSource.slice(start,end);
const plan=new Function(plannerSource+'\nreturn planContentSpansIntoSlabs;')();
manifest.originalManifestSha256=sha(originalBytes);
manifest.blockTargetBytes=targetBytes;
manifest.blockPlanOrigin={source:'ext/js/dictionary/term-content-block-store.js',sourceSha256:sha(blockSource),functionSha256:sha(plannerSource),configuration:'ext/js/dictionary/dictionary-database.js',configurationSha256:sha(databaseSource)};
manifest.scope='Existing exact native parser/canonical dedup pending spans replanned with the frozen production database 1MiB target and exact production block planner. The original 4MiB manifest remains unchanged. No import timing claim.';
const perWorker=[0,0,0,0];
for(const group of manifest.groups){
 const [raw,offsetBytes,lengthBytes]=await Promise.all([readFile(path.join(directory,group.sourceFile)),readFile(path.join(directory,group.offsetsFile)),readFile(path.join(directory,group.lengthsFile))]);
 assert.equal(sha(raw),group.sourceSha256);assert.equal(sha(offsetBytes),group.offsetsSha256);assert.equal(sha(lengthBytes),group.lengthsSha256);
 const offsets=new Uint32Array(offsetBytes.buffer,offsetBytes.byteOffset,offsetBytes.byteLength/4);
 const lengths=new Uint32Array(lengthBytes.buffer,lengthBytes.byteOffset,lengthBytes.byteLength/4);
 const {packedChunkLengths,blockStartIndexes}=plan(lengths,targetBytes);
 group.blockLengths=[...packedChunkLengths];group.blockStartIndexes=[...blockStartIndexes];group.inputBlockSha256=[];
 for(let block=0;block<packedChunkLengths.length;block++){
  const hash=createHash('sha256');let bytes=0;
  for(let i=blockStartIndexes[block];i<blockStartIndexes[block+1];i++){assert(offsets[i]+lengths[i]<=raw.byteLength);hash.update(raw.subarray(offsets[i],offsets[i]+lengths[i]));bytes+=lengths[i];}
  assert.equal(bytes,packedChunkLengths[block]);group.inputBlockSha256.push(hash.digest('hex'));perWorker[block%4]+=bytes;
 }
}
assert.deepEqual(manifest.groups.map(g=>g.blockLengths.length),[9,9,9,9,9,9,7,8,8,8,8,10]);
await writeFile(path.join(directory,'manifest-db-1m.json'),JSON.stringify(manifest,null,2)+'\n',{flag:'wx'});
let replay=await readFile(path.join(root,'profiling/compression-scheduling-replay.mjs'),'utf8');
replay=replay.replace('span order and 4MiB block boundaries unchanged','span order and 1MiB block boundaries computed using the frozen production database target and block planner');
replay=replay.replace('schemaVersion:2,complete:false','schemaVersion:3,blockTargetBytes:manifest.blockTargetBytes,blockPlanOrigin:manifest.blockPlanOrigin,complete:false');
replay=replay.replace('utilization:workerBusyMs.map','workerWallTimeFractions:workerBusyMs.map');
await writeFile(path.join(root,'profiling/compression-scheduling-db-1m-replay.mjs'),replay,{flag:'wx'});
console.log(JSON.stringify({targetBytes,groups:manifest.groups.length,blocks:manifest.groups.reduce((n,g)=>n+g.blockLengths.length,0),inputBytes:manifest.groups.reduce((n,g)=>n+g.uniqueContentBytes,0),perWorker,originalManifestSha256:manifest.originalManifestSha256}));
