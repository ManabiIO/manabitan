// Node transport for the unchanged production compression worker entry.
import {parentPort,workerData} from 'node:worker_threads';
import {readFile} from 'node:fs/promises';
const starts=new Map();
const originalFetch=globalThis.fetch;
globalThis.fetch=async(input,options)=>{
 const url=input instanceof URL?input:new URL(typeof input==='string'?input:input.url);
 if(url.protocol!=='file:')return originalFetch(input,options);
 return new Response(await readFile(url),{headers:{'Content-Type':url.pathname.endsWith('.wasm')?'application/wasm':'application/octet-stream'}});
};
globalThis.self={
 addEventListener(type,listener){if(type==='message')parentPort.on('message',data=>{starts.set(data.id,process.hrtime.bigint().toString());listener({data});});},
 postMessage(message,transfer=[]){
  const result=typeof message.id==='number'&&('compressed'in message||'error'in message)?{...message,__componentMetrics:{startedNs:starts.get(message.id),endedNs:process.hrtime.bigint().toString()}}:message;
  parentPort.postMessage(result,transfer);
  if(result.__componentMetrics)starts.delete(message.id);
 },
};
await import(workerData.entry);
