// Compare exact full-corpus component receipts. Baseline's originally failed
// negative-sequence oracle was separately corrected by a read-only reopen run.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';
import {parseArgs} from 'node:util';
import path from 'node:path';

const {values} = parseArgs({options: {
    baseline: {type: 'string'}, verification: {type: 'string'}, candidate: {type: 'string'},
    'baseline-log': {type: 'string'}, 'candidate-log': {type: 'string'}, out: {type: 'string'},
}});
for (const key of ['baseline', 'verification', 'candidate', 'baseline-log', 'candidate-log', 'out']) { assert(values[key], key); }
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const inputs = {};
const documents = {};
for (const key of ['baseline', 'verification', 'candidate']) {
    const bytes = await readFile(values[key]);
    inputs[key] = {path: path.resolve(values[key]), bytes: bytes.byteLength, sha256: sha(bytes)};
    documents[key] = JSON.parse(bytes);
}
const originalBaseline = documents.baseline;
const verification = documents.verification;
const candidate = documents.candidate;
const a = originalBaseline.arms.baseline;
const b = candidate.arms.candidate;
const report = {
    schemaVersion: 1, complete: false, node: process.version,
    scope: originalBaseline.scope, configurationCorrection: originalBaseline.configurationCorrection,
    inputs, originalBaselineFailedOraclePreserved: originalBaseline.failures,
    baselineCompletionRecoveredByIndependentReadOnlyVerification: false,
    harnessSha256: sha(await readFile(new URL(import.meta.url))), failures: [],
};
await writeFile(values.out, JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
const save = () => writeFile(values.out, JSON.stringify(report, null, 2) + '\n');
try {
    assert.equal(originalBaseline.groups, 12);
    assert.equal(candidate.groups, 12);
    assert(verification.complete);
    assert(verification.allFilesUnchanged && verification.sourcesUnchanged);
    assert.equal(verification.originalReceiptSha256, inputs.baseline.sha256);
    assert.equal(verification.originalReceipt, inputs.baseline.path);
    assert.equal(verification.opfsDirectory, a.opfsDirectory);
    assert.deepEqual(verification.source, a.source);
    assert(candidate.complete && b.complete);
    assert.deepEqual(candidate.failures, []);
    assert.equal(a.inputSha256, b.inputSha256);
    assert.equal(a.rows, originalBaseline.fixture.termRows);
    assert.equal(a.rows, b.rows);
    assert.equal(a.actualBlockTargetBytes, 1048576);
    assert.equal(b.actualBlockTargetBytes, 1048576);
    assert.equal(a.blockCount, 103);
    assert.equal(b.blockCount, 103);
    assert.equal(a.workerCount, 4);
    assert.equal(b.workerCount, 4);
    assert.equal(a.maxPendingOwners, 1);
    assert.equal(b.maxPendingOwners, 2);
    assert(b.forcedResponseHoldCount > 0);
    assert.deepEqual(a.metadata, b.metadata);
    const normalizeProbes = (probes) => probes.map((probe) => ({...probe, sequence: typeof probe.sequence === 'number' && probe.sequence >= 0 ? probe.sequence : null}));
    assert.deepEqual(normalizeProbes(a.probes), b.probes);
    assert.equal(verification.reopenedProbeCount, 36);
    assert.equal(b.reopenedProbeCount, 36);
    assert.deepEqual(verification.integrity, b.integrity);
    const files = (arm) => arm.files.map(({name, bytes, normalizedSha256, masks}) => ({name, bytes, normalizedSha256, masks}));
    assert.deepEqual(files(a), files(b));
    const orderedJobs = (arm) => [...arm.jobs].sort((x, y) => x.id - y.id).map(({id, group, inputBytes, outputBytes, outputSha256}) => ({id, group, inputBytes, outputBytes, outputSha256}));
    assert.deepEqual(orderedJobs(a), orderedJobs(b));
    const metrics = ['dedupPendingHitCount', 'dedupPersistedHitCount', 'dedupUniqueCount', 'dedupExactFallbackCount', 'dedupNativeCallCount', 'dedupNativeFallbackCount'];
    assert.deepEqual(a.groups.map((group) => metrics.map((field) => group.metrics[field])), b.groups.map((group) => metrics.map((field) => group.metrics[field])));
    assert(a.groups.every((group) => group.metrics.dedupNativeFallbackCount === 0));
    const start = b.events.find((entry) => entry.type === 'compression-dispatched' && entry.group === 2);
    const completion = b.events.find((entry) => entry.type === 'completed' && entry.group === 1);
    assert(start && completion && start.ordinal < completion.ordinal);
    report.parity = {allSourceInputs: true, allMetadataColumns: true, everyCompressedBlock: true, everyPersistedFileAfterValidatedGenerationMask: true, rowCounts: true, nativeDedupCounts: true, reopenedSourceProbes: true, recordStoreIntegrity: true};
    report.rows = a.rows;
    report.groups = 12;
    report.actualBlockTargetBytes = 1048576;
    report.blocks = 103;
    report.canonicalMetadataCount = a.metadata.count;
    report.files = files(a);
    report.arms = {};
    for (const [name, arm] of [['baseline', a], ['candidate', b]]) {
        const log = await readFile(values[`${name}-log`], 'utf8');
        const observations = log.split('\n').flatMap((line) => {
            try { const item = JSON.parse(line); return item.memory ? [{group: item.group, rssBytes: item.memory.rss}] : []; } catch { return []; }
        });
        report.arms[name] = {
            source: arm.source, maxPendingOwners: arm.maxPendingOwners,
            maxPendingOwnedSourceBytes: arm.maxPendingOwnedSourceBytes,
            forcedResponseHoldCount: arm.forcedResponseHoldCount,
            peakReportedRssBytes: Math.max(...observations.map((item) => item.rssBytes)),
            memoryObservationCount: observations.length,
            memoryScope: 'Maximum of per-group diagnostic RSS samples, not measured process peak, browser memory or a comparative memory claim.',
            log: {path: path.resolve(values[`${name}-log`]), sha256: sha(log)},
        };
    }
    report.overlapWitness = {successorDispatchOrdinal: start.ordinal, predecessorCompletionOrdinal: completion.ordinal};
    report.baselineCompletionRecoveredByIndependentReadOnlyVerification = true;
    report.complete = true;
    await save();
    console.log(JSON.stringify({complete: true, rows: report.rows, groups: report.groups, blocks: report.blocks, metadata: report.canonicalMetadataCount, parity: report.parity, owners: Object.fromEntries(Object.entries(report.arms).map(([name, arm]) => [name, arm.maxPendingOwners]))}));
} catch (error) {
    report.failures.push({message: String(error), stack: error.stack});
    await save();
    throw error;
}
