// Scratch-only component capture. It does not reproduce browser scheduling or OPFS persistence.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createReadStream, openAsBlob, readSync, openSync, closeSync, readFileSync} from 'node:fs';
import {readFile, writeFile, mkdir, unlink} from 'node:fs/promises';
import {deflateRawSync,inflateRawSync} from 'node:zlib';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import {parseArgs} from 'node:util';
import {execFileSync} from 'node:child_process';

const {values, positionals} = parseArgs({allowPositionals: true, options: {
  root: {type:'string',default:'/workspace/scratch/da6c4dbd0097/baseline'},
  cache: {type:'string',default:'/workspace/scratch/da6c4dbd0097/fixtures'},
  out: {type:'string',default:'/workspace/scratch/da6c4dbd0097/profiling/compression-groups'},
  workers: {type:'string',default:'3'},
  'compressed-spool': {type:'boolean',default:false},
  'plan-only': {type:'boolean',default:false},
}});
const root = path.resolve(values.root);
const out = path.resolve(values.out);
const workers = Number(values.workers);
assert([2,3,5].includes(workers));
const load = (file) => import(pathToFileURL(path.join(root,file)));
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const bytesOf = (array) => new Uint8Array(array.buffer,array.byteOffset,array.byteLength);
const {BlobReader, ZipReader} = await load('node_modules/@zip.js/zip.js/index.js');
const {readDenseZipDirectory} = await load('ext/js/dictionary/dense-zip-directory.js');
const {RawZipPayloadReader} = await load('ext/js/dictionary/term-bank-source-pipeline.js');
const {DictionaryDatabase} = await load('ext/js/dictionary/dictionary-database.js');
const {NativeCanonicalScanner} = await load('ext/js/dictionary/term-content-canonical-scan.js');
const {RAW_TERM_CONTENT_TOKEN_DICT_NAME} = await load('ext/js/dictionary/raw-term-content.js');
const parser = await load('ext/js/dictionary/term-bank-wasm-parser.js');
const parserBytes = await readFile(path.join(root,'ext/lib/term-bank-parser.wasm'));
parser.setTermBankWasmModule(await WebAssembly.compile(parserBytes));
const canonicalModule = await WebAssembly.compile(await readFile(path.join(root,'ext/lib/term-content-canonical-scan-v1.wasm')));
const lockBytes = await readFile(path.join(root,'test/perf/dictionaries.lock.json'));
const fixtures = JSON.parse(lockBytes).dictionaries;
const identityFiles = [
 'ext/js/dictionary/term-bank-wasm-parser.js','ext/js/dictionary/term-bank-experiments.js',
 'ext/js/dictionary/dictionary-database.js','ext/js/dictionary/term-content-canonical-scan.js',
 'ext/js/dictionary/term-content-block-store.js','ext/js/dictionary/zstd-term-content.js',
 'ext/js/dictionary/zstd-term-content-compression-worker.js','ext/lib/term-bank-parser.wasm',
 'ext/lib/term-content-canonical-scan-v1.wasm','ext/lib/zstd.wasm','ext/lib/zstd-wasm.js',
 'ext/lib/zstd-dicts/jmdict.zdict',
];
const identity = {};
for (const file of identityFiles) identity[file] = sha(await readFile(path.join(root,file)));

// Same byte-balanced group partition used by the existing source-bound corpus replays.
function partition(entries,groupsPerWorker) {
 const total = entries.reduce((sum,e)=>sum+e.uncompressedSize,0);
 const groupCount = Math.min(entries.length,Math.max(workers*groupsPerWorker,Math.ceil(total/(24*1024*1024))));
 const groups=[];let start=0,consumed=0;
 for(let index=0;index<groupCount-1;++index){
  const remaining=groupCount-index,target=(total-consumed)/remaining,maxEnd=entries.length-(remaining-1);
  let end=start+1,bytes=entries[start].uncompressedSize;
  while(end<maxEnd){const next=bytes+entries[end].uncompressedSize;if(Math.abs(next-target)>Math.abs(bytes-target))break;bytes=next;++end;}
  groups.push(entries.slice(start,end));start=end;consumed+=bytes;
 }
 groups.push(entries.slice(start));return groups;
}

// Exact current planContentSpansIntoSlabs loop, checked against the source hash above.
// Compression replay also verifies every packed block length and input digest.
function blockPlan(lengths) {
 const packedChunkLengths=[],blockStartIndexes=[0];let start=0;
 while(start<lengths.length){let total=0,end=start;while(end<lengths.length){const n=lengths[end];if(total>0&&total+n>4*1024*1024&&n>0)break;total+=n;++end;}assert(total<=0xffffffff);packedChunkLengths.push(total);blockStartIndexes.push(end);start=end;}
 return {blockLengths:packedChunkLengths,blockStartIndexes};
}

for(const dictionary of positionals.length?positionals:['jmdict']) {
 const fixture=fixtures[dictionary];assert(fixture);
 const archivePath=path.join(values.cache,fixture.cacheFile),directory=path.join(out,dictionary);
 await mkdir(directory,{recursive:true});
 const hash=createHash('sha256');let zipBytes=0;
 for await(const bytes of createReadStream(archivePath)){hash.update(bytes);zipBytes+=bytes.length;}
 assert.equal(hash.digest('hex'),fixture.sha256);assert.equal(zipBytes,fixture.sizeBytes);
 const blob=await openAsBlob(archivePath),rawReader=new RawZipPayloadReader(blob);
 let zipReader;const allEntries=await readDenseZipDirectory(blob)??await (zipReader=new ZipReader(new BlobReader(blob),{useWebWorkers:false})).getEntries();
 const entries=allEntries.filter(e=>/^term_bank_\d+\.json$/.test(e.filename)).sort((a,b)=>Number(a.filename.slice(10,-5))-Number(b.filename.slice(10,-5)));
 const hasImages=(fixture.mediaFiles??0)>0,groups=partition(entries,hasImages?3:4);
 const totalSourceBytes=entries.reduce((s,e)=>s+e.uncompressedSize,0),projectImagePaths=hasImages&&totalSourceBytes>=1024*1024*1024;
 const experiments=projectImagePaths?{experimentalNativeEscapedKeys:true}:{};
 const report={schemaVersion:1,dictionary,complete:false,root,gitSha:execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim(),node:process.version,
  scope:'Native ZIP inflate/parser plus owned output copy, actual ordered native canonical dedup/stage/publication. Synthetic raw content offsets and file-backed exact reads; term-record encoding, compression, media handling, and OPFS are not executed. Group partition follows explicit three-worker byte-balancing policy; group processing is serial.',
  sourceHashes:identity,lockSha256:sha(lockBytes),fixture,workers,sourceBanks:entries.length,totalSourceBytes,groups:[],limits:['Captured storage offsets are synthetic and do not claim persistent artifact parity.','Block plans use the exact source loop with unchanged 4MiB target.','Capture timings include file output and are diagnostic only.']};
 const save=()=>writeFile(path.join(directory,'manifest.json'),JSON.stringify(report,null,2));
 const db=new DictionaryDatabase();db._bulkImportTransactionOpen=true;db._deferTermsVirtualTableSync=true;db._termContentZstdInitialized=false;
 db._nativeCanonicalScanner=new NativeCanonicalScanner({loadModule:async()=>canonicalModule});
 const descriptors=[],readCache=new Map();let current=null;
 db._readTermEntryContentBytesDetailed=async(offset,length)=>{
  const group=Math.floor(offset/2**32)-1,start=offset%(2**32);assert(group>=0&&group<descriptors.length);
  if(descriptors[group].compressed){let raw=readCache.get(group);if(!raw){raw=inflateRawSync(readFileSync(descriptors[group].sourcePath));readCache.set(group,raw);while(readCache.size>2)readCache.delete(readCache.keys().next().value);}assert(start+length<=raw.byteLength);return {status:'ok',bytes:raw.subarray(start,start+length)};}
  const handle=openSync(descriptors[group].sourcePath,'r'),bytes=Buffer.alloc(length);
  try {assert.equal(readSync(handle,bytes,0,length,start),length);}finally{closeSync(handle);}
  return {status:'ok',bytes};
 };
 db._persistArtifactTermContent=async(_dictionary,pendingBytes,dictNames,uniform,spans)=>{
  assert(current&&spans);assert.equal(dictNames,null);assert.equal(uniform,RAW_TERM_CONTENT_TOKEN_DICT_NAME);
  const source=spans.buffer,index=report.groups.length;
  const sourcePath=path.join(directory,`group-${index}.source.${values['compressed-spool']?'deflate':'bin'}`),offsetPath=path.join(directory,`group-${index}.offsets.bin`),lengthPath=path.join(directory,`group-${index}.lengths.bin`);
  const storedSource=values['compressed-spool']?deflateRawSync(source,{level:1}):source;
  await writeFile(sourcePath,storedSource);await writeFile(offsetPath,bytesOf(spans.offsets));await writeFile(lengthPath,bytesOf(spans.lengths));
  descriptors.push({sourcePath,compressed:values['compressed-spool']});
  const plan=blockPlan(spans.lengths),inputs=[];
  for(let i=0;i<plan.blockLengths.length;++i){const h=createHash('sha256');for(let j=plan.blockStartIndexes[i];j<plan.blockStartIndexes[i+1];++j)h.update(source.subarray(spans.offsets[j],spans.offsets[j]+spans.lengths[j]));inputs.push(h.digest('hex'));}
  Object.assign(current,{sourceFile:path.basename(sourcePath),sourceEncoding:values['compressed-spool']?'deflate-raw':'raw',storedSourceSha256:sha(storedSource),storedSourceBytes:storedSource.byteLength,offsetsFile:path.basename(offsetPath),lengthsFile:path.basename(lengthPath),sourceBytes:source.byteLength,sourceSha256:sha(source),offsetsSha256:sha(bytesOf(spans.offsets)),lengthsSha256:sha(bytesOf(spans.lengths)),uniqueContentCount:spans.lengths.length,uniqueContentBytes:plan.blockLengths.reduce((s,n)=>s+n,0),...plan,inputBlockSha256:inputs});
  return {pendingOffsets:Float64Array.from(spans.offsets,n=>(index+1)*2**32+n),pendingLengths:spans.lengths,pendingResolvedDictNames:RAW_TERM_CONTENT_TOKEN_DICT_NAME,blockProfile:null};
 };
 const rowDigest=createHash('sha256');
 db._termRecordStore={appendBatchFromArtifactChunkResolvedContent:async(chunk,offsets,lengths,names)=>{
  // All source row identity/field columns, lookup sidecar bytes and resolved-reference plans are witnessed.
  rowDigest.update(String(chunk.rowCount));
  for(const key of ['readingEqualsExpressionList','scoreList','sequenceList','contentUniqueIndexList'])if(ArrayBuffer.isView(chunk[key]))rowDigest.update(bytesOf(chunk[key]));
  for(const [key,value] of chunk.preparedLookupIndexes??[]){rowDigest.update(key);rowDigest.update(value.bytes);}
  rowDigest.update(typeof names==='string'?names:JSON.stringify(names));
  if(offsets.length)rowDigest.update(bytesOf(offsets));if(lengths.length)rowDigest.update(bytesOf(lengths));
  return {buildRecordsMs:0,encodeMs:0,appendWriteMs:0,internMs:0,packLengthsMs:0,heapCopyMs:0,recordFieldEncodeMs:0,validationMs:0,lookupIndexEncodeMs:0};
 }};
 let totalRows=0;
 try {
  for(const [index,group] of groups.entries()) {
   const t0=performance.now();
   const sources=[];for(const entry of group)sources.push({...entry,bytes:await rawReader.read(entry,new AbortController().signal)});
   const preloaded=await parser.inflateCompressedTermBankSourcesWasm(sources,experiments,true);
   let owned=null;
   await parser.parseTermBankWithWasmColumnChunks(new Uint8Array(0),3,chunk=>{
    assert.equal(owned,null);owned=parser.copyWasmBackedColumnChunk(chunk,false,projectImagePaths,true,preloaded);
   },2048,{singleChunk:true,maxPendingChunks:1,emitTermByteLists:false,computeContentHashes:true,emitContentSlab:true,emitTokenBinaryContent:true,mediaHintFastScan:hasImages,validateGlossaryTypes:true,prepareLookupIndexes:true,compactContentMetadata:true,preloadedSource:preloaded,...experiments});
   assert(owned);const parseProfile=parser.consumeLastTermBankWasmParseProfile();
   const shared=new Uint8Array(new SharedArrayBuffer(owned.contentBytesBuffer.byteLength));shared.set(owned.contentBytesBuffer);owned.contentBytesBuffer=shared;
   current={index,firstBank:group[0].filename,lastBank:group.at(-1).filename,rows:owned.rowCount,sourceZipUncompressedBytes:group.reduce((s,e)=>s+e.uncompressedSize,0),sourceZipCompressedBytes:group.reduce((s,e)=>s+e.compressedSize,0),parseProfile};
   await db._bulkAddArtifactTermsChunkWithContentDedup({...owned,dictionary:fixture.expectedTitle,dictionaryTotalRows:fixture.termRows,contentDictNameList:null,uniformContentDictName:RAW_TERM_CONTENT_TOKEN_DICT_NAME});
   assert(current.sourceFile,'Expected pending content in every pinned group');current.dedupMetrics=db._lastBulkAddTermsMetrics;current.captureWallMs=performance.now()-t0;
   report.groups.push(current);totalRows+=owned.rowCount;await save();
   console.log(JSON.stringify({dictionary,group:index,rows:owned.rowCount,unique:current.uniqueContentCount,blocks:current.blockLengths,canonicalCalls:current.dedupMetrics.dedupNativeCallCount,canonicalFallbacks:current.dedupMetrics.dedupNativeFallbackCount,memory:process.memoryUsage()}));
   owned=null;globalThis.gc?.();
  }
  assert.equal(totalRows,fixture.termRows);report.totalRows=totalRows;report.rowWitnessSha256=rowDigest.digest('hex');report.complete=true;await save();
  if(values['plan-only']){for(const g of report.groups)for(const key of ['sourceFile','offsetsFile','lengthsFile'])await unlink(path.join(directory,g[key]));report.retainedSpans=false;report.retentionReason='Plan-only capture: source hashes and per-group/block plans retained, reproducible from checksum-fixed source ZIP.';await save();}
 }finally{await zipReader?.close();}
 for(const file of identityFiles)assert.equal(sha(await readFile(path.join(root,file))),identity[file]);
}
