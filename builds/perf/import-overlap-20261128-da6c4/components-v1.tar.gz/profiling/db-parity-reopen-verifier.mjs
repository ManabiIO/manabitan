// Read-only recovery of a completed component import whose original reopen oracle
// incorrectly expected negative source sequence values to survive normalization.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
import {parseArgs} from 'node:util';

const {values} = parseArgs({options: {
    receipt: {type: 'string'}, out: {type: 'string'},
}});
assert(values.receipt && values.out);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const receiptBytes = await readFile(values.receipt);
const receipt = JSON.parse(receiptBytes);
const armNames = Object.keys(receipt.arms);
assert.equal(armNames.length, 1);
const arm = receipt.arms[armNames[0]];
assert.equal(arm.rows, receipt.fixture.termRows);
assert.equal(arm.groups.length, 12);
assert.equal(arm.blockCount, 103);
assert(arm.jobs.every((job) => typeof job.outputSha256 === 'string'));
assert.equal(receipt.failures.length, 1);
assert(receipt.failures[0].message.includes('null !== -1627880'));
const root = arm.source.root;
const load = (file) => import(pathToFileURL(path.join(root, file)));
const report = {
    complete: false, node: process.version, originalReceipt: path.resolve(values.receipt),
    originalReceiptSha256: sha(receiptBytes), arm: armNames[0],
    scope: 'Fresh-process read-only reopen verification of all completed baseline component import artifacts; original failed receipt is unchanged. Production absent-sequence semantics normalize source negative sequence to null. No performance claim.',
    source: arm.source, opfsDirectory: arm.opfsDirectory, checks: [], failures: [],
    normalizedExpectedSequenceCount: arm.probes.filter((probe) => typeof probe.sequence === 'number' && probe.sequence < 0).length,
    harnessSha256: sha(await readFile(new URL(import.meta.url))),
};
await writeFile(values.out, JSON.stringify(report, null, 2) + '\n', {flag: 'wx'});
const save = () => writeFile(values.out, JSON.stringify(report, null, 2) + '\n');
async function verifySources() {
    for (const [file, expected] of Object.entries(arm.source.hashes)) {
        try { assert.equal(sha(await readFile(path.join(root, file))), expected, file); } catch (error) {
            if (expected !== null || error.code !== 'ENOENT') { throw error; }
        }
    }
}
async function verifyFiles() {
    for (const file of arm.files) {
        const bytes = await readFile(path.join(arm.opfsDirectory, file.name));
        assert.equal(bytes.byteLength, file.bytes);
        assert.equal(sha(bytes), file.rawSha256, file.name);
    }
}
const originalFetch = globalThis.fetch;
globalThis.fetch = async (input, options) => {
    const url = input instanceof URL ? input : new URL(typeof input === 'string' ? input : input.url);
    if (url.protocol !== 'file:') { return originalFetch(input, options); }
    return new Response(await readFile(url), {headers: {'Content-Type': url.pathname.endsWith('.wasm') ? 'application/wasm' : 'application/octet-stream'}});
};
const {createNodeOpfs} = await load('test/fixtures/fused-score/node-opfs-adapter.mjs');
const filesystem = await createNodeOpfs();
const artifactRoot = new filesystem.root.constructor(arm.opfsDirectory);
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {
    hardwareConcurrency: 4, deviceMemory: 8,
    storage: {getDirectory: async () => artifactRoot},
}});
try {
    await verifySources();
    await verifyFiles();
    const codec = await load('ext/js/dictionary/zstd-term-content.js');
    await codec.initializeTermContentZstd();
    const {DictionaryDatabase} = await load('ext/js/dictionary/dictionary-database.js');
    const db = new DictionaryDatabase();
    db._termContentZstdInitialized = true;
    await db._termContentStore.prepare();
    await db._termRecordStore.prepare();
    await db._termRecordStore.ensureDictionariesLoaded([receipt.fixture.expectedTitle]);
    const records = await db._termRecordStore.getByIdsAsync(arm.probes.map(({id}) => id));
    for (const probe of arm.probes) {
        const expected = {...probe, sequence: typeof probe.sequence === 'number' && probe.sequence >= 0 ? probe.sequence : null};
        const record = records.get(expected.id);
        assert(record, `Missing record ${expected.id}`);
        assert.equal(record.expression, expected.expression);
        assert.equal(record.reading, expected.reading);
        assert.equal(record.sequence, expected.sequence);
        assert.equal(record.score, expected.score);
        assert.equal(Object.is(record.score, -0), expected.scoreNegativeZero);
        const content = await db._readTermEntryContentBytesDetailed(record.entryContentOffset, record.entryContentLength, record.entryContentDictName);
        assert.equal(content.status, 'ok');
        assert.equal(content.bytes.byteLength, expected.contentLength);
        assert.equal(sha(content.bytes), expected.contentSha256);
        report.checks.push({id: expected.id, expression: true, reading: true, sequence: true, score: true, sourceContentBytes: true});
    }
    report.integrity = await db._termRecordStore.verifyIntegrity();
    assert.equal(report.integrity.invalidShardPayloadCount, 0);
    assert.equal(report.integrity.missingShardCount, 0);
    assert.equal(report.integrity.orphanShardCount, 0);
    await verifyFiles();
    await verifySources();
    assert.deepEqual(filesystem.operations, []);
    report.reopenedProbeCount = report.checks.length;
    report.allFilesUnchanged = true;
    report.sourcesUnchanged = true;
    report.memory = process.memoryUsage();
    report.complete = true;
    await save();
    console.log(JSON.stringify({complete: true, probes: report.reopenedProbeCount, normalizedSequences: report.normalizedExpectedSequenceCount, integrity: report.integrity, memory: report.memory}));
} catch (error) {
    report.failures.push({message: String(error), stack: error.stack});
    await save();
    throw error;
} finally {
    await filesystem.dispose();
}
