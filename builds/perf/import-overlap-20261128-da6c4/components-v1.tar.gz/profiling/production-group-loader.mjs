// Scratch helper: serial replay of actual compressed input/native parser with production-like grouping.
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {openAsBlob} from 'node:fs';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';

export async function* loadProductionGroups({root,manifestPath,cache='/workspace/scratch/da6c4dbd0097/fixtures'}) {
 const manifest=JSON.parse(await readFile(manifestPath));assert(manifest.complete);
 const load=file=>import(pathToFileURL(path.join(root,file)));
 const {BlobReader,ZipReader}=await load('node_modules/@zip.js/zip.js/index.js');
 const {RawZipPayloadReader}=await load('ext/js/dictionary/term-bank-source-pipeline.js');
 const {readDenseZipDirectory}=await load('ext/js/dictionary/dense-zip-directory.js');
 const {RAW_TERM_CONTENT_TOKEN_DICT_NAME}=await load('ext/js/dictionary/raw-term-content.js');
 const parser=await load('ext/js/dictionary/term-bank-wasm-parser.js');
 const wasmBytes=await readFile(path.join(root,'ext/lib/term-bank-parser.wasm'));
 assert.equal(createHash('sha256').update(wasmBytes).digest('hex'),manifest.sourceHashes['ext/lib/term-bank-parser.wasm']);
 parser.setTermBankWasmModule(await WebAssembly.compile(wasmBytes));
 const archive=await openAsBlob(path.join(cache,manifest.fixture.cacheFile)),raw=new RawZipPayloadReader(archive);
 let zip;const entries=await readDenseZipDirectory(archive)??await(zip=new ZipReader(new BlobReader(archive),{useWebWorkers:false})).getEntries();
 const terms=entries.filter(e=>/^term_bank_\d+\.json$/.test(e.filename)).sort((a,b)=>Number(a.filename.slice(10,-5))-Number(b.filename.slice(10,-5)));
 const hasImages=(manifest.fixture.mediaFiles??0)>0,projectImagePaths=hasImages&&manifest.totalSourceBytes>=1024*1024*1024;
 const experiments=projectImagePaths?{experimentalNativeEscapedKeys:true}:{};
 try {
  for(const group of manifest.groups){
   const first=terms.findIndex(e=>e.filename===group.firstBank),last=terms.findIndex(e=>e.filename===group.lastBank);assert(first>=0&&last>=first);
   const sources=[];for(const entry of terms.slice(first,last+1))sources.push({...entry,bytes:await raw.read(entry,new AbortController().signal)});
   const preloadedSource=await parser.inflateCompressedTermBankSourcesWasm(sources,experiments,true);
   let owned;
   await parser.parseTermBankWithWasmColumnChunks(new Uint8Array(0),3,chunk=>{
    assert.equal(owned,undefined);
    owned=parser.copyWasmBackedColumnChunk(chunk,false,projectImagePaths,true,preloadedSource);
   },2048,{singleChunk:true,maxPendingChunks:1,emitTermByteLists:false,computeContentHashes:true,emitContentSlab:true,emitTokenBinaryContent:true,mediaHintFastScan:hasImages,validateGlossaryTypes:true,prepareLookupIndexes:true,compactContentMetadata:true,preloadedSource,...experiments});
   assert(owned);assert.equal(owned.rowCount,group.rows);
   // Stable independent ownership before advancing the reusable parser heap.
   const shared=new Uint8Array(new SharedArrayBuffer(owned.contentBytesBuffer.byteLength));shared.set(owned.contentBytesBuffer);owned.contentBytesBuffer=shared;
   if(owned.contentDedupPlan){owned.contentDedupPlan={...owned.contentDedupPlan,uniqueRowIndexes:new Uint32Array(owned.contentDedupPlan.uniqueRowIndexes),uniqueSignatures:new Uint32Array(owned.contentDedupPlan.uniqueSignatures)};assert(owned.contentDedupPlan.resolutionDeferred);}
   yield {group,profile:parser.consumeLastTermBankWasmParseProfile(),chunk:{...owned,dictionary:manifest.fixture.expectedTitle,dictionaryTotalRows:manifest.fixture.termRows,contentDictNameList:null,uniformContentDictName:RAW_TERM_CONTENT_TOKEN_DICT_NAME}};
  }
 }finally{await zip?.close();}
}
