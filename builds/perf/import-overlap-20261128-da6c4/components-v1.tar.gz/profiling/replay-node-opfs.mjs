// Scratch transport only: the repository's file-backed OPFS adapter plus a
// Node descriptor for the production synchronous import-index writer route.
import assert from 'node:assert/strict';
import {openSync, writeSync, ftruncateSync, fsyncSync, closeSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
import path from 'node:path';

export async function createReplayOpfs(root) {
    const {createNodeOpfs} = await import(pathToFileURL(path.join(root, 'test/fixtures/fused-score/node-opfs-adapter.mjs')));
    const filesystem = await createNodeOpfs();
    const locks = new Set();
    const wrapHandle = (handle) => ({
        kind: handle.kind,
        name: handle.name,
        getFile: () => handle.getFile(),
        async createWritable(options) {
            assert(!locks.has(handle.location), 'Exclusive OPFS handle already held');
            locks.add(handle.location);
            let stream;
            try { stream = await handle.createWritable(options); } catch (error) { locks.delete(handle.location); throw error; }
            return {
                seek: (offset) => stream.seek(offset),
                truncate: (size) => stream.truncate(size),
                write: (bytes) => stream.write(bytes),
                async close() { try { await stream.close(); } finally { locks.delete(handle.location); } },
                async abort() { try { await stream.abort(); } finally { locks.delete(handle.location); } },
            };
        },
        async createSyncAccessHandle() {
            assert(!locks.has(handle.location), 'Exclusive OPFS handle already held');
            locks.add(handle.location);
            let descriptor;
            try { descriptor = openSync(handle.location, 'r+'); } catch (error) { locks.delete(handle.location); throw error; }
            let closed = false;
            const check = () => assert(!closed, 'Synchronous OPFS handle closed');
            filesystem.operations.push({type: 'sync-open', name: handle.name});
            return {
                write(bytes, {at = 0} = {}) {
                    check();
                    const count = writeSync(descriptor, bytes, 0, bytes.byteLength, at);
                    filesystem.operations.push({type: 'sync-write', name: handle.name, length: count, at});
                    return count;
                },
                truncate(size) { check(); ftruncateSync(descriptor, size); filesystem.operations.push({type: 'sync-truncate', name: handle.name, size}); },
                flush() { check(); fsyncSync(descriptor); filesystem.operations.push({type: 'sync-flush', name: handle.name}); },
                close() {
                    check();
                    try { closeSync(descriptor); } finally { closed = true; locks.delete(handle.location); }
                    filesystem.operations.push({type: 'sync-close', name: handle.name});
                },
            };
        },
    });
    const wrapDirectory = (directory) => ({
        kind: directory.kind,
        name: directory.name,
        getDirectoryHandle: async (...args) => wrapDirectory(await directory.getDirectoryHandle(...args)),
        getFileHandle: async (...args) => wrapHandle(await directory.getFileHandle(...args)),
        removeEntry: (...args) => directory.removeEntry(...args),
        async *entries() {
            for await (const [name, entry] of directory.entries()) {
                yield [name, entry.kind === 'directory' ? wrapDirectory(entry) : wrapHandle(entry)];
            }
        },
    });
    return {...filesystem, root: wrapDirectory(filesystem.root), locks};
}
