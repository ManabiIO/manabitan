"""Read-only independent audit of downloaded import qualification receipts."""

import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import sys

ROOT = Path(os.environ.get('MANABITAN_STUDY_ROOT', '/workspace/scratch/63aba8f8e231')).resolve()
sys.path.insert(0, str(ROOT / 'baseline/dev/perf/import-memory-20261125-a7f7'))
from audit_memory import audit_cell
from protocol import memory_overlay

BASELINE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
SOURCES = {
    'lazy-ids': ('1e502491b6875e45f8c56f98eea7f28ff59cbcfb', 'f17102bac19688f1115d1d630720838abf0df00c', 'js/dictionary/dictionary-database.js'),
    'lazy-ids-final': ('b6f02628da0289316f6b811095dd9a93913a756f', 'da03aa70f88d4b0616eeab8ed251f48a17f8de13', 'js/dictionary/dictionary-database.js'),
    'compression-pool-two': ('f71fcf4c0f252a47d872e8064d5f33b012f086ba', '9473396dd2d396248f7e0b156497e3f67c28eb6f', 'js/dictionary/zstd-term-content.js'),
}


def read(path):
    return json.loads(path.read_text())


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def source_digest(commit, package_path):
    data = subprocess.check_output(['git', 'show', f'{commit}:ext/{package_path}'], cwd=ROOT / 'baseline')
    return hashlib.sha256(data).hexdigest()


def summarize(observations, kind, left, right):
    pairs = {}
    for item in observations:
        if item['kind'] == kind:
            pair = pairs.setdefault(item['pair'], {})
            assert item['arm'] not in pair, 'Duplicate arm observation'
            pair[item['arm']] = item['totalImportMs']
    complete = list(pairs.values())
    assert complete and all(set(pair) == {left, right} for pair in complete)
    ratios = [pair[right] / pair[left] for pair in complete]
    rng = random.Random(897)
    samples = sorted(statistics.median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
    return {
        'count': len(complete),
        'ratios': ratios,
        'medianPairedChangePercent': (statistics.median(ratios) - 1) * 100,
        'equalWorkChangePercent': (sum(pair[right] for pair in complete) / sum(pair[left] for pair in complete) - 1) * 100,
        'worstPairChangePercent': (max(ratios) - 1) * 100,
        'descriptiveBootstrap95Percent': [(samples[index] - 1) * 100 for index in (249, 9749)],
        'fasterPairs': sum(ratio < 1 for ratio in ratios),
    }


def audit(root):
    group, dictionary, order = root.relative_to(ROOT / 'hosted-studies').parts
    remote, local, changed = SOURCES[group]
    plan = read(root / 'registered-plan.json')
    retrieval = read(root / 'retrieval-digest.json')
    assert plan['baseline'] == BASELINE
    assert plan['candidate'] == remote
    assert plan['dictionary'] == dictionary and plan['initialOrder'] == order
    assert plan['expectedPackageEntries'] == [changed]
    identity = read(root / 'source-identities.json')
    a, b = identity['arms']['A'], identity['arms']['B']
    assert a['sha'] == BASELINE and b['sha'] == remote
    assert a['fixtureLockSha256'] == b['fixtureLockSha256']
    assert a['lockSha256'] == b['lockSha256']
    assert set(a['entries']) == set(b['entries'])
    actual_changes = sorted(key for key in a['entries'] if a['entries'][key] != b['entries'][key])
    assert actual_changes == [changed] == identity['changedPackageEntries']
    assert a['entries'][changed] == source_digest(BASELINE, changed)
    assert b['entries'][changed] == source_digest(local, changed)
    observations = read(root / 'observations.json')
    assert [{k: v for k, v in row.items() if k != 'totalImportMs'} for row in observations] == plan['schedule']
    analysis = read(root / 'analysis.json')
    candidate = summarize(observations, 'candidate', 'A', 'B')
    control = summarize(observations, 'control', 'A', 'C')
    assert candidate == analysis['candidateVsBaseline']
    assert control == analysis['identicalCodeControl']
    receipts = [read(root / row['id'] / 'canonical-receipt.json') for row in observations]
    assert all(receipt == receipts[0] for receipt in receipts), 'Ordinary semantic receipts differ'
    media_a = read(root / 'exhaustive-media-A/canonical-receipt.json')
    media_b = read(root / 'exhaustive-media-B/canonical-receipt.json')
    assert media_a == media_b, 'Exhaustive media receipts differ'
    assert media_a['common'] == receipts[0]['common']
    failures = read(root / 'memory/semantic-failures.json')
    memory_plan = read(root / 'memory/plan.json')
    assert memory_plan['sourceHashes'] == identity['arms']
    original_harness = (ROOT / 'baseline/test/chromium/extension-two-dictionary-import.e2e.js').read_text()
    original_harness_sha = hashlib.sha256(original_harness.encode()).hexdigest()
    for arm in (a, b):
        assert arm['sourceHashes']['test/chromium/extension-two-dictionary-import.e2e.js'] == original_harness_sha
    instrumented_harness = memory_overlay(original_harness)
    instrumented_harness_sha = hashlib.sha256(instrumented_harness.encode()).hexdigest()
    assert memory_plan['overlaySha256'] == instrumented_harness_sha
    retained_harness = (root / 'memory/harness-original.js').exists()
    assert retained_harness == (root / 'memory/harness-instrumented.js').exists()
    if retained_harness:
        assert (root / 'memory/harness-original.js').read_text() == original_harness
        assert (root / 'memory/harness-instrumented.js').read_text() == instrumented_harness
    elif group != 'lazy-ids':
        raise AssertionError('Final-source/diagnostic cohort is missing retained harness bytes')
    memory = audit_cell(root / 'memory')
    assert memory == read(root / 'memory/memory-audit.json')
    memory_observations = read(root / 'memory/observations.json')
    for item in memory_observations:
        r = read(root / 'memory' / item['name'] / 'canonical-receipt.json')
        assert r == receipts[0], 'Instrumented semantic receipt differs'
    assert analysis['memoryPassed'] == (memory['passesProspectiveMemoryScreen'] and not failures)
    host = read(root / observations[0]['id'] / 'host-before.json')
    return {
        'cohort': str(root.relative_to(ROOT / 'hosted-studies')),
        'candidateRemoteCommit': remote,
        'candidateProductCommit': local,
        'archiveSha256': retrieval['archiveSha256'],
        'packageMembers': len(a['entries']),
        'changedPackageEntries': actual_changes,
        'candidateProductSha256': b['entries'][changed],
        'fixtureLockSha256': a['fixtureLockSha256'],
        'sourceAndPackageIdentityPassed': True,
        'declaredHarnessIdentityAndOverlayPassed': True,
        'harnessOverlaySha256': instrumented_harness_sha,
        'retainedHarnessBytesChecked': retained_harness,
        'ordinaryReceiptCount': len(receipts),
        'ordinaryReceiptSha256': digest(receipts[0]),
        'commonReceiptSha256': digest(receipts[0]['common']),
        'exhaustiveMediaReceiptSha256': digest(media_a),
        'semanticFailures': failures,
        'cpuModel': host['cpuModel'],
        'logicalCpuCount': host['logicalCpuCount'],
        'nodeVersion': host['nodeVersion'],
        'browserVersion': receipts[0]['browserVersion'],
        'candidateVsBaseline': candidate,
        'identicalCodeControl': control,
        'memoryAudit': memory,
        'memoryObservationFailures': [
            {'name': item['name'], 'exitCode': item['benchmarkExitCode'],
             'qualificationFailures': item['qualificationFailures'],
             'maximumCoveredSampleGapMs': item['maximumCoveredSampleGapMs']}
            for item in memory_observations if not item['qualifiedForWholeTreePss'] or item['benchmarkExitCode'] != 0
        ],
        'status': analysis['status'],
        'interpretation': 'Independent per-host receipt audit. Confidence intervals are descriptive; passing a prospective memory bound is not a peak-memory reduction claim.',
    }


if __name__ == '__main__':
    results = []
    for path in sys.argv[1:]:
        root = Path(path).resolve()
        try:
            result = audit(root)
        except Exception as error:
            result = {'cohort': str(root), 'auditError': f'{type(error).__name__}: {error}'}
        results.append(result)
    print(json.dumps(results, indent=2) + '\n')
