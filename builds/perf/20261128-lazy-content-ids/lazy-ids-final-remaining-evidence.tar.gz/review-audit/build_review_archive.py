"""Preserve exact review receipts in a deterministic, verified Git-sized archive."""

import argparse
import gzip
import hashlib
import io
import json
import pathlib
import tarfile


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("manifest", type=pathlib.Path)
parser.add_argument("output", type=pathlib.Path)
args = parser.parse_args()
request = json.loads(args.manifest.read_text())
files = {}
for item in request["inputs"]:
    source = pathlib.Path(item["source"])
    label = pathlib.PurePosixPath(item["label"])
    if label.is_absolute() or ".." in label.parts:
        raise ValueError(f"Unsafe archive label: {label}")
    if not source.exists():
        raise FileNotFoundError(source)
    paths = sorted(source.rglob("*")) if source.is_dir() else [source]
    for path in paths:
        if not path.is_file():
            continue
        name = str(label / path.relative_to(source)) if source.is_dir() else str(label)
        if name in files:
            raise ValueError(f"Duplicate archive member: {name}")
        files[name] = path

index = {"scope": request["scope"], "files": []}
args.output.parent.mkdir(parents=True, exist_ok=True)
with args.output.open("wb") as raw:
    with gzip.GzipFile(filename="", fileobj=raw, mode="wb", mtime=0, compresslevel=9) as compressed:
        with tarfile.open(fileobj=compressed, mode="w|") as archive:
            for name, path in sorted(files.items()):
                data = path.read_bytes()
                digest = hashlib.sha256(data).hexdigest()
                index["files"].append({"path": name, "bytes": len(data), "sha256": digest})
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                archive.addfile(info, io.BytesIO(data))
            data = (json.dumps(index, indent=2, sort_keys=True) + "\n").encode()
            info = tarfile.TarInfo("receipt-index.json")
            info.size = len(data)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(data))

with tarfile.open(args.output, "r:gz") as archive:
    expected = {item["path"]: item for item in index["files"]}
    assert len(archive.getmembers()) == len(expected) + 1
    for name, item in expected.items():
        recovered = archive.extractfile(name).read()
        assert len(recovered) == item["bytes"]
        assert hashlib.sha256(recovered).hexdigest() == item["sha256"]
    assert json.load(archive.extractfile("receipt-index.json")) == index

receipt = {
    "archive": str(args.output),
    "archiveSha256": hashlib.sha256(args.output.read_bytes()).hexdigest(),
    "archiveBytes": args.output.stat().st_size,
    "members": len(index["files"]),
    "rawBytes": sum(item["bytes"] for item in index["files"]),
    "verifiedEveryRecoveredMember": True,
}
args.output.with_suffix(args.output.suffix + ".json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt))
