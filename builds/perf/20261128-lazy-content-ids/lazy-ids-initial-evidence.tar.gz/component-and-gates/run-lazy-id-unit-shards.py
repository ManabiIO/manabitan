import datetime
import json
import pathlib
import subprocess


ROOT = pathlib.Path('/tmp/manabitan-lazy-ids-63aba8')
OUTPUT = pathlib.Path('/workspace/scratch/63aba8f8e231/current-baseline-artifacts')
EXPECTED_COMMIT = 'da03aa70f88d4b0616eeab8ed251f48a17f8de13'
VITEST = ['node', 'node_modules/vitest/vitest.mjs']
RECEIPT = OUTPUT / 'lazy-ids-unit-shards-receipt.json'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def capture(command):
    return subprocess.check_output(command, cwd=ROOT, text=True).strip()


assert capture(['git', 'rev-parse', 'HEAD']) == EXPECTED_COMMIT
assert not capture(['git', 'diff', '--name-only', 'HEAD'])
discovered = json.loads((OUTPUT / 'lazy-ids-all-unit-files.json').read_text())
expected_files = {item['file'] for item in discovered}
receipt = {
    'sourceCommit': EXPECTED_COMMIT,
    'node': capture(['node', '--version']),
    'startedAt': now(),
    'unitFileManifest': str(OUTPUT / 'lazy-ids-all-unit-files.json'),
    'discoveredFileCount': len(expected_files),
    'shardCount': 8,
    'maxWorkers': 1,
    'shards': [],
    'complete': False,
}


def save():
    RECEIPT.write_text(json.dumps(receipt, indent=2) + '\n')


save()
for index in range(1, 9):
    prefix = OUTPUT / f'lazy-ids-unit-shard-{index}-of-8'
    report = prefix.with_suffix('.json')
    log = prefix.with_suffix('.log')
    command = VITEST + ['run', '--maxWorkers=1', f'--shard={index}/8',
                        '--reporter=default', '--reporter=json', f'--outputFile.json={report}']
    item = {'shard': index, 'command': command, 'startedAt': now(),
            'log': str(log), 'report': str(report), 'status': 'running'}
    receipt['shards'].append(item)
    save()
    print(json.dumps({'shard': index, 'status': 'started', 'time': item['startedAt']}), flush=True)
    with log.open('w') as output:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    item.update({'returncode': result.returncode, 'finishedAt': now(),
                 'status': 'passed' if result.returncode == 0 else 'failed'})
    if report.exists():
        data = json.loads(report.read_text())
        item['counts'] = {key: data.get(key) for key in [
            'numTotalTests', 'numPassedTests', 'numFailedTests',
            'numPendingTests', 'numTodoTests', 'success']}
        item['files'] = [{
            'file': file['name'], 'status': file['status'],
            'testCount': len(file.get('assertionResults', [])),
            'failedTests': [test['fullName'] for test in file.get('assertionResults', [])
                            if test['status'] == 'failed'],
            'message': file.get('message', ''),
        } for file in data['testResults']]
    save()
    print(json.dumps({'shard': index, 'status': item['status'], 'returncode': result.returncode,
                      'counts': item.get('counts'), 'files': len(item.get('files', []))}), flush=True)

observed = [file['file'] for item in receipt['shards'] for file in item.get('files', [])]
actual_files = set(observed)
receipt['coverage'] = {
    'reportedFileCount': len(observed),
    'uniqueReportedFileCount': len(actual_files),
    'missingFiles': sorted(expected_files - actual_files),
    'unexpectedFiles': sorted(actual_files - expected_files),
    'duplicateFiles': sorted(file for file in actual_files if observed.count(file) > 1),
}
receipt['complete'] = expected_files == actual_files and len(observed) == len(actual_files)
receipt['allPassed'] = receipt['complete'] and all(item['status'] == 'passed' for item in receipt['shards'])
receipt['finishedAt'] = now()
save()
print(json.dumps({'complete': receipt['complete'], 'allPassed': receipt['allPassed'],
                  'coverage': receipt['coverage']}), flush=True)
