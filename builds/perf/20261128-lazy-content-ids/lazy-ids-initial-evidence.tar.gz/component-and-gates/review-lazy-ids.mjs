import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {DictionaryDatabase as Baseline} from '../baseline/ext/js/dictionary/dictionary-database.js'
import {DictionaryDatabase as Candidate} from '/tmp/manabitan-lazy-ids-63aba8/ext/js/dictionary/dictionary-database.js'
import {registerOwnedTermContent as ownBaseline} from '../baseline/ext/js/dictionary/term-content-ownership.js'
import {registerOwnedTermContent as ownCandidate} from '/tmp/manabitan-lazy-ids-63aba8/ext/js/dictionary/term-content-ownership.js'

const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
let operations = 0
let comparisons = 0
let implicitStates = 0
let materializedStates = 0
for (let seed = 1; seed <= 30; ++seed) {
    let randomState = seed
    const random = (limit) => {
        randomState ^= randomState << 13
        randomState ^= randomState >>> 17
        randomState ^= randomState << 5
        return (randomState >>> 0) % limit
    }
    const databases = [new Baseline(), new Candidate()]
    const ownership = [ownBaseline, ownCandidate]
    let groups = []
    let hashes = new Set()
    let nextHash = 100
    const compare = () => {
        const [a, b] = databases
        assert.equal(b._termEntryContentMetaHashPairCount, a._termEntryContentMetaHashPairCount)
        assert.equal(b._termEntryContentMetaHashPairPendingCount, a._termEntryContentMetaHashPairPendingCount)
        assert.equal(b._recentTermContentSourceBatchBytes, a._recentTermContentSourceBatchBytes)
        assert.equal(b._recentTermContentSourceBatches.size, a._recentTermContentSourceBatches.size)
        assert.deepEqual(b._termEntryContentMetaFreeIndexes, a._termEntryContentMetaFreeIndexes)
        for (const hash of hashes) {
            const metadata = databases.map((database) => database._getTermEntryContentMetaByHashPair(hash, hash))
            assert.deepEqual(metadata[1], metadata[0], `metadata ${seed}/${operations}/${hash}`)
            const sources = databases.map((database, i) => {
                if (typeof metadata[i] === 'undefined') { return null }
                const span = database._findRecentTermContentSource(metadata[i])
                return typeof span === 'undefined' ? null : sha(span.buffer.subarray(span.offset, span.offset + span.length))
            })
            assert.equal(sources[1], sources[0], `source ${seed}/${operations}/${hash}`)
            ++comparisons
        }
        if (b._termEntryContentMetaIdTable.length === 0) { ++implicitStates }
        if (b._termEntryContentMetaIdTable.length > 0) { ++materializedStates }
    }
    const publish = (group) => {
        for (let j = 0; j < 2; ++j) {
            const {spans, staged} = group.pairs[j]
            databases[j]._publishArtifactTermContentMetadata({
                count: group.count,
                contentOffsets: new Float64Array(group.count),
                contentLengths: new Uint32Array(group.count),
                resolvedContentDictNames: 'raw',
                pendingRowToUniqueIndex: Int32Array.from({length: group.count}, (_, i) => i),
                pendingContentBytes: [],
                pendingContentHash1s: group.hashes,
                pendingContentHash2s: group.hashes,
                pendingOffsets: Float64Array.from(group.hashes, (hash) => hash * 17),
                pendingLengths: spans.lengths,
                pendingResolvedDictNames: 'raw',
                pendingContentSpans: spans,
                stagedContentMetadata: staged,
            })
        }
        group.published = true
        for (const {spans} of group.pairs) {
            spans.offsets.fill(0xffffffff)
            if (!group.owned) { spans.buffer.fill(0) }
        }
    }
    for (let step = 0; step < 250; ++step) {
        ++operations
        const choice = random(100)
        if (choice < 5) {
            for (const database of databases) { database._clearTermEntryContentMetaCaches() }
            groups = []
            hashes = new Set()
        } else if (choice < 12) {
            const capacity = 16 << random(5)
            for (const database of databases) { database._ensureTermEntryContentMetaDenseCapacity(capacity) }
        } else if (choice < 30 && groups.some((group) => group.active)) {
            const live = groups.filter((group) => group.active)
            const group = live[random(live.length)]
            for (let j = 0; j < 2; ++j) { databases[j]._rollbackStagedArtifactTermContentMetadata(group.pairs[j].staged) }
            group.active = false
        } else if (choice < 43) {
            const published = [...hashes].filter((hash) => typeof databases[0]._getTermEntryContentMetaByHashPair(hash, hash) !== 'undefined')
            const hash = published.length > 0 && random(2) === 0 ? published[random(published.length)] : nextHash++
            hashes.add(hash)
            const id = [0, -0, 1, 0x100000001, Number.MAX_SAFE_INTEGER][random(5)]
            for (const database of databases) {
                database._setTermEntryContentMetaByHashPair(hash, hash, {id, offset: 1000 + hash, length: 1, dictName: 'raw'})
            }
        } else if (choice < 55 && groups.some((group) => group.active && !group.published)) {
            const pending = groups.filter((group) => group.active && !group.published)
            publish(pending[random(pending.length)])
        } else {
            const count = 1 + random(8)
            const lengths = Uint32Array.from({length: count}, () => [1, 2, 4, 13, 37, 600][random(6)])
            const offsets = new Uint32Array(count)
            let byteLength = random(8)
            for (let i = 0; i < count; ++i) { offsets[i] = byteLength; byteLength += lengths[i] + random(5) }
            const values = Uint8Array.from({length: byteLength + random(8)}, (_, i) => (i + nextHash) & 255)
            const batchHashes = Uint32Array.from({length: count}, (_, i) => nextHash + i)
            if (count > 1 && random(8) === 0) { batchHashes[1] = batchHashes[0] }
            nextHash += count + 10
            for (const hash of batchHashes) { hashes.add(hash) }
            const owned = random(3) === 0
            const shared = !owned && random(3) === 0
            const budget = [64, 256, 4096, 16384][random(4)]
            for (const database of databases) { database._recentTermContentSourceCacheMaxBytes = budget }
            const group = {active: true, published: false, count, hashes: batchHashes, owned, pairs: []}
            for (let j = 0; j < 2; ++j) {
                const buffer = shared ? new Uint8Array(new SharedArrayBuffer(values.length + 5), 5) : new Uint8Array(values.length)
                buffer.set(values)
                if (owned) { assert(ownership[j](buffer)) }
                const spans = {buffer, offsets: offsets.slice(), lengths: lengths.slice()}
                const staged = databases[j]._stageArtifactTermContentMetadata(batchHashes, batchHashes, [], spans)
                group.pairs.push({spans, staged})
            }
            groups.push(group)
            if (random(3) > 0) { publish(group) }
        }
        compare()
    }
}
console.log(JSON.stringify({seeds: 30, operations, comparisons, implicitStates, materializedStates, result: 'exact baseline metadata IDs, publication and cached-source parity'}, null, 2))
