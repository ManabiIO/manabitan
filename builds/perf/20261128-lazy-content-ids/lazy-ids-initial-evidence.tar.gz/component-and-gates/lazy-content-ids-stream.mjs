/*
 * Copyright (C) 2026 Manabitan authors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
/* eslint @stylistic/semi: ["error", "never"] */

import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {createReadStream, openAsBlob, openSync, writeSync, readSync, closeSync, unlinkSync} from 'node:fs'
import {readFile, writeFile} from 'node:fs/promises'
import {join, resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
import {Worker as ThreadWorker} from 'node:worker_threads'
import {BlobReader, Uint8ArrayWriter, ZipReader} from '@zip.js/zip.js'

// Replay the actual source planner and parser workers. Only persistence is
// intercepted. Resolved spans use native content lengths at deterministic
// offsets; this checks record bytes, not compression or whole-database parity.
const [parentPath, candidatePath, cachePath, outputPath, dictionary = 'jmdict', cpus = '4', memory = '8', pairsArg = '0'] = process.argv.slice(2)
assert(parentPath && candidatePath && cachePath && outputPath)
const parentRoot = resolve(parentPath)
const candidateRoot = resolve(candidatePath)
// The CLI explicitly selects the two local source trees to compare.
// eslint-disable-next-line no-unsanitized/method
const localImport = (root, filename) => import(pathToFileURL(join(root, filename)))
const parser = await localImport(candidateRoot, 'ext/js/dictionary/term-bank-wasm-parser.js')
const pipelineModule = await localImport(candidateRoot, 'ext/js/dictionary/term-bank-source-pipeline.js')
const parents = await localImport(parentRoot, 'ext/js/dictionary/dictionary-database.js')
const candidates = await localImport(candidateRoot, 'ext/js/dictionary/dictionary-database.js')
const parentOwnership = await localImport(parentRoot, 'ext/js/dictionary/term-content-ownership.js')
const candidateOwnership = await localImport(candidateRoot, 'ext/js/dictionary/term-content-ownership.js')
const fetchOriginal = globalThis.fetch
globalThis.fetch = async (input, options) => {
    if (String(input).startsWith('file:')) { return new Response(await readFile(new URL(input))) }
    return fetchOriginal(input, options)
}
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const lockBytes = await readFile(join(candidateRoot, 'test/perf/dictionaries.lock.json'))
assert.deepEqual(lockBytes, await readFile(join(parentRoot, 'test/perf/dictionaries.lock.json')))
const fixture = JSON.parse(lockBytes).dictionaries[dictionary]
assert(fixture)
const archivePath = join(cachePath, fixture.cacheFile)
const archiveHash = createHash('sha256')
for await (const bytes of createReadStream(archivePath)) { archiveHash.update(bytes) }
assert.equal(archiveHash.digest('hex'), fixture.sha256)
const archive = await openAsBlob(archivePath)
assert.equal(archive.size, fixture.sizeBytes)
const wasm = await readFile(join(candidateRoot, 'ext/lib/term-bank-parser.wasm'))
assert.deepEqual(wasm, await readFile(join(parentRoot, 'ext/lib/term-bank-parser.wasm')))
parser.setTermBankWasmModule(await WebAssembly.compile(wasm))
const sourceHashes = {baseline: sha(await readFile(join(parentRoot, 'ext/js/dictionary/dictionary-database.js'))), candidate: sha(await readFile(join(candidateRoot, 'ext/js/dictionary/dictionary-database.js'))), parser: sha(wasm)}

const terminations = []
const sourceGroups = []
class BrowserWorker extends EventTarget {
    constructor(url) {
        super()
        this.worker = new ThreadWorker(pathToFileURL(join(candidateRoot, 'test/fixtures/parser-settlement/worker-node.mjs')), {workerData: {url: url.href}})
        this.worker.on('message', (data) => this.dispatchEvent(new MessageEvent('message', {data})))
        this.worker.on('error', (error) => {
            const event = new Event('error')
            Object.defineProperty(event, 'message', {value: error.message})
            this.dispatchEvent(event)
        })
        this.worker.on('messageerror', () => this.dispatchEvent(new MessageEvent('messageerror')))
    }

    postMessage(data, transfer) {
        if (data.type === 'parse') {
            sourceGroups.push({id: data.id, files: data.sourceMetadata?.map(({filename}) => filename) ?? null, bytes: data.sourceBuffers.map((buffer) => buffer.byteLength)})
        }
        this.worker.postMessage(data, transfer)
    }

    terminate() { terminations.push(this.worker.terminate()) }
}
globalThis.Worker = BrowserWorker
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: Number(cpus), deviceMemory: Number(memory)}})

const reader = new ZipReader(new BlobReader(archive))
const entries = await reader.getEntries()
const termFiles = entries.filter(({filename}) => /^term_bank_\d+\.json$/.test(filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
const rawReader = new pipelineModule.RawZipPayloadReader(archive)
const sourcePipeline = new pipelineModule.TermBankSourcePipeline({
    termFiles,
    enabled: true,
    read: async (file) => await file.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}),
    readCompressed: async (file, signal) => await rawReader.read(file, signal),
})
const backingPath = outputPath + '.content.bin'
const backingFd = openSync(backingPath, 'wx+')
let backingCursor = 0
const profiles = []
const results = []
let rowCount = 0
function readStored(state, offset, length) {
    const group = state.storedGroups.findLast((item) => item.start <= offset)
    assert(group && offset < group.start + group.lengths.length)
    const i = offset - group.start
    assert.equal(group.lengths[i], length)
    const bytes = Buffer.allocUnsafe(length)
    let read = 0
    while (read < length) {
        const count = readSync(backingFd, bytes, read, length - read, group.fileOffset + group.offsets[i] + read)
        assert(count > 0)
        read += count
    }
    return bytes
}
function createState(module, ownership) {
    const database = new module.DictionaryDatabase()
    const state = {database, ownership, storedGroups: [], storageCursor: 1, peakCacheIndexBytes: 0, peakCacheSourceBytes: 0, peakIdColumnBytes: 0, exactReads: 0, observations: [], digest: createHash('sha256')}
    database._readTermEntryContentBytesDetailedBatch = async (requests) => {
        state.exactReads += requests.length
        return requests.map(({contentOffset,contentLength}) => ({status:'ok', bytes:readStored(state,contentOffset,contentLength)}))
    }
    return state
}
const states = {baseline: createState(parents,parentOwnership), candidate:createState(candidates,candidateOwnership)}
async function consumeArm(state, sourceChunk, fileOffset) {
    const {database,ownership} = state
    const chunk = {...sourceChunk, contentDedupPlan:structuredClone(sourceChunk.contentDedupPlan)}
    if (ownership.shouldOwnTermContentBytes(chunk.contentBytesBuffer.byteLength,chunk.contentDedupPlan.uniqueCount,chunk.contentDedupPlan.sourceRowCount,chunk.rowCount)) {
        ownership.registerOwnedTermContent(chunk.contentBytesBuffer)
    }
    const dedup = await database._resolveArtifactTermContentDedup(chunk,true)
    assert(dedup.contentDedupPlan && dedup.pendingContentSpans)
    const pendingOffsets = Float64Array.from({length:dedup.pendingContentCount},(_,i)=>state.storageCursor+i)
    const pendingLengths = new Uint32Array(dedup.pendingContentSpans.lengths)
    state.storedGroups.push({start:state.storageCursor,fileOffset,offsets:new Uint32Array(dedup.pendingContentSpans.offsets),lengths:pendingLengths})
    state.storageCursor += dedup.pendingContentCount
    database._publishResolvedArtifactTermContentPlan(dedup.contentDedupPlan,dedup.pendingPlanUniqueStart,dedup.pendingPlanUniqueIndexes,pendingOffsets,pendingLengths,'raw')
    database._publishArtifactTermContentMetadata({...dedup,count:chunk.rowCount,pendingOffsets,pendingLengths,pendingResolvedDictNames:'raw',contentUniqueIndexList:chunk.contentUniqueIndexList,metadataValidated:true,useResolvedContentReferences:true})
    for (const array of [dedup.contentDedupPlan.resolvedFlags,dedup.contentDedupPlan.resolvedOffsets,dedup.contentDedupPlan.resolvedLengths]) {
        state.digest.update(new Uint8Array(array.buffer,array.byteOffset,array.byteLength))
    }
    const rangeBytes = (database._recentTermContentSourceRanges ?? []).reduce((sum,range)=>sum+range.offsets.byteLength,0)
    const denseBytes = database._termEntryContentMetaRecentSourceBatchIdTable.byteLength+database._termEntryContentMetaRecentSourceOffsetTable.byteLength
    state.peakCacheIndexBytes = Math.max(state.peakCacheIndexBytes,denseBytes+rangeBytes)
    state.peakCacheSourceBytes = Math.max(state.peakCacheSourceBytes,database._recentTermContentSourceBatchBytes)
    state.peakIdColumnBytes = Math.max(state.peakIdColumnBytes, database._termEntryContentMetaIdTable.byteLength)
    const observation = {idColumnBytes: database._termEntryContentMetaIdTable.byteLength, pending:dedup.pendingContentCount,hit:dedup.persistedHitCount,exact:dedup.exactFallbackCount,recent:dedup.recentSourceHitCount,denseCapacity:database._termEntryContentMetaStateTable.length,ranges:database._recentTermContentSourceRanges?.length ?? 0,denseBytes,rangeBytes,sourceBytes:database._recentTermContentSourceBatchBytes}
    state.observations.push(observation)
    return {observation,flags:dedup.contentDedupPlan.resolvedFlags,offsets:dedup.contentDedupPlan.resolvedOffsets,lengths:dedup.contentDedupPlan.resolvedLengths}
}
async function consume(source) {
    const chunk = {
        rowCount:source.rowCount,dictionary:fixture.expectedTitle,dictionaryTotalRows:fixture.termRows,
        contentBytesBuffer:new Uint8Array(source.contentBytesBuffer),contentBytesBaseOffset:source.contentBytesBaseOffset,
        contentMetaByUniqueIndex:source.contentMetaByUniqueIndex,contentMetaList:source.contentMetaList,
        contentRowStart:source.contentRowStart,contentUniqueIndexList:source.contentUniqueIndexList,
        contentDedupPlan:source.contentDedupPlan,useResolvedContentReferences:true,
        uniformContentDictName:source.uniformContentDictName ?? 'raw',contentHash1List:new Uint32Array(0),contentHash2List:new Uint32Array(0),
    }
    const fileOffset=backingCursor
    let written = 0
    while (written < chunk.contentBytesBuffer.length) {
        const count = writeSync(backingFd,chunk.contentBytesBuffer,written,chunk.contentBytesBuffer.length-written,backingCursor+written)
        assert(count > 0)
        written += count
    }
    backingCursor+=chunk.contentBytesBuffer.length
    const before=await consumeArm(states.baseline,chunk,fileOffset)
    const after=await consumeArm(states.candidate,chunk,fileOffset)
    for (const name of ['flags','offsets','lengths']) { assert.deepEqual(after[name],before[name],name) }
    for (const name of ['pending','hit','exact','recent','sourceBytes']) { assert.equal(after.observation[name],before.observation[name],name) }
    assert.equal(before.observation.idColumnBytes, before.observation.denseCapacity * Float64Array.BYTES_PER_ELEMENT)
    assert.equal(after.observation.idColumnBytes, 0)
    rowCount+=chunk.rowCount
    process.stderr.write(`${dictionary} ${rowCount}/${fixture.termRows} rows: ID column ${before.observation.idColumnBytes} -> ${after.observation.idColumnBytes}B\n`)
}
const media = fixture.mediaFiles > 0
const options = {
    emitTermByteLists: false,
    computeContentHashes: true,
    emitContentSlab: true,
    emitTokenBinaryContent: true,
    mediaHintFastScan: media,
    projectImagePaths: media,
    validateGlossaryTypes: true,
    prepareLookupIndexes: true,
    maxPendingChunks: 2,
}
let complete = false
let error = null
try {
    for (let start = 0; start < termFiles.length;) {
        const compressedPlan = sourcePipeline.createCompressedImportRunPlan(start)
        if (compressedPlan !== null) {
            assert.equal(await parser.parseTermBankWithWasmColumnChunksParallelCompressedLazy(compressedPlan.loaders, compressedPlan.estimatedByteLengths, 3, consume, options), true)
            profiles.push(parser.consumeLastTermBankWasmParseProfile())
            sourcePipeline.releaseBatch(compressedPlan.files)
            start += compressedPlan.files.length
        } else {
            const files = sourcePipeline.getBatch(start)
            const batch = await sourcePipeline.readBatch(files)
            if (batch?.promises) {
                assert.equal(await parser.parseTermBankWithWasmColumnChunksParallelDeferred(batch.promises, batch.estimatedByteLengths, 3, consume, options), true)
            } else {
                await parser.parseTermBankWithWasmColumnChunks(batch, 3, consume, 2048, {...options, singleChunk: true})
            }
            profiles.push(parser.consumeLastTermBankWasmParseProfile())
            sourcePipeline.releaseBatch(files)
            start += files.length
        }
    }
    assert.equal(rowCount, fixture.termRows)
    complete = true
} catch (failure) {
    error = String(failure)
    throw failure
} finally {
    await sourcePipeline.dispose()
    await parser.disposeParallelTermBankParser()
    await Promise.all(terminations)
    await reader.close()

}

try {
    assert(complete)
    for (const [arm,state] of Object.entries(states)) {
        let cacheEntries=0
        const cacheDigest=createHash('sha256')
        for(let i=0;i<state.database._termEntryContentMetaDenseCount;++i) {
            const meta=state.database._readTermEntryContentMetaHashPairIndex(i)
            assert(meta)
            assert.equal(Object.is(meta.id, 0), true)
            const recent=state.database._findRecentTermContentSource(meta)
            if(!recent) { continue }
            ++cacheEntries
            const bytes=recent.buffer.subarray(recent.offset,recent.offset+recent.length)
            const persisted=readStored(state,meta.offset,meta.length)
            assert.equal(Buffer.compare(Buffer.from(bytes.buffer,bytes.byteOffset,bytes.byteLength),persisted),0)
            cacheDigest.update(String(i))
            cacheDigest.update(bytes)
        }
        results.push({arm,metadataEntries:state.database._termEntryContentMetaDenseCount,peakIdColumnBytes:state.peakIdColumnBytes,peakCacheIndexBytes:state.peakCacheIndexBytes,peakCacheSourceBytes:state.peakCacheSourceBytes,exactReads:state.exactReads,cacheEntries,cacheDigest:cacheDigest.digest('hex'),metadataDigest:state.digest.digest('hex'),observations:state.observations})
    }
    for(const name of ['metadataEntries','peakCacheSourceBytes','exactReads','cacheEntries','cacheDigest','metadataDigest']) {assert.deepEqual(results[0][name],results[1][name],name)}
    await writeFile(outputPath,JSON.stringify({complete,error,node:process.version,dictionary,fixture,rowCount,sourceGroups,profiles,sourceHashes,scope:'Streaming real native parser groups through exact dedup and metadata publication. All metadata IDs are verified positive zero. Deterministic persisted offsets and a temporary byte file replace compression/OPFS; no timing claims.',results},null,2)+'\n',{flag:'wx'})
    console.log(JSON.stringify({complete,error,dictionary,rowCount,groups:sourceGroups.length,baselineIdBytes:results[0].peakIdColumnBytes,candidateIdBytes:results[1].peakIdColumnBytes,metadataEntries:results[0].metadataEntries}))
} finally {
    closeSync(backingFd)
    unlinkSync(backingPath)
}
