"""Read-only decomposition of the frozen lazy-ID VNDB AB coverage failures."""

import hashlib
import importlib.util
import json
import math
import pathlib
import statistics

ROOT = pathlib.Path('/workspace/scratch/63aba8f8e231')
COHORT = ROOT / 'hosted-studies/lazy-ids-final/vndb/AB/memory'
OBSERVER = ROOT / 'baseline/dev/perf/import-memory-20261125-a7f7/chromium_memory.py'
spec = importlib.util.spec_from_file_location('frozen_memory_observer', OBSERVER)
observer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(observer)


def digest(value):
    return hashlib.sha256(value).hexdigest()


def describe(samples, index, window_start):
    if not isinstance(index, int):
        return {'boundary': index}
    sample = samples[index]
    return {
        'rawScanIndexZeroBased': index,
        'startedAtMonotonicNs': sample['startedAtMonotonicNs'],
        'finishedAtMonotonicNs': sample['finishedAtMonotonicNs'],
        'startRelativeToImportMs': (sample['startedAtMonotonicNs'] - window_start) / 1e6,
        'finishRelativeToImportMs': (sample['finishedAtMonotonicNs'] - window_start) / 1e6,
        'durationMs': (sample['finishedAtMonotonicNs'] - sample['startedAtMonotonicNs']) / 1e6,
        'qualifiedForWholeTreePss': sample['qualifiedForWholeTreePss'],
        'qualificationFailures': sample['qualificationFailures'],
        'processCount': len(sample['processes']),
        'processes': [{'pid': p['pid'], 'role': p['role']} for p in sample['processes']],
    }


result = {
    'scope': 'Read-only attribution; all raw observations, thresholds and qualification results remain unchanged. No replacement observation, observer modification or new study.',
    'cohort': str(COHORT.relative_to(ROOT)),
    'observerSourceSha256': digest(OBSERVER.read_bytes()),
    'rule': 'Use only qualified complete scans wholly inside the two import markers. Maximum gap is computed across import-start, each covered scan midpoint, and import-end. Separate pre/post brackets must also be within 250 ms.',
    'decomposition': 'For adjacent covered scans: midpoint gap = left scan finish minus its midpoint + next scan start minus left scan finish + right scan midpoint minus its start. The two scan terms include elapsed observer work and any scheduling inside that work; no per-operation CPU timestamps exist.',
    'observations': {},
}
for name in ['A1', 'B1', 'B2', 'A2']:
    raw = (COHORT / name / 'memory.json').read_bytes()
    original = json.loads(raw)
    samples = original['samples']
    markers = original['windowMarkers']
    start, end = [int(marker['monotonicNs']) for marker in markers]
    reproduced = observer.summarize_import_window(samples, markers, original['benchmarkExitCode'])
    for field in ['qualificationFailures', 'qualifiedForWholeTreePss', 'maxSampledPssKiB', 'maxSampledPrivateKiB', 'fullyContainedImportSampleCount', 'stableFullyReadImportSampleCount', 'maximumCoveredSampleGapMs', 'preImportBracketGapMs', 'postImportBracketGapMs']:
        assert reproduced[field] == original[field], (name, field)
    assert original['qualificationFailures'] == ['covered-import-scan-gap-over-250ms']
    assert original['qualifiedForWholeTreePss'] is False
    covered = [(i, sample) for i, sample in enumerate(samples)
               if sample['startedAtMonotonicNs'] >= start and sample['finishedAtMonotonicNs'] <= end
               and sample['qualifiedForWholeTreePss']]
    midpoint = lambda sample: (sample['startedAtMonotonicNs'] + sample['finishedAtMonotonicNs']) // 2
    points = [('start', start)] + [(i, midpoint(sample)) for i, sample in covered] + [('end', end)]
    gaps = []
    for left, right in zip(points, points[1:]):
        gap = {'gapMs': (right[1] - left[1]) / 1e6,
               'left': describe(samples, left[0], start), 'right': describe(samples, right[0], start)}
        if isinstance(left[0], int) and isinstance(right[0], int):
            a, b = samples[left[0]], samples[right[0]]
            gap['classification'] = 'interior-covered-scans'
            gap['leftScanRemainingHalfMs'] = (a['finishedAtMonotonicNs'] - left[1]) / 1e6
            gap['betweenScanEndToStartMs'] = (b['startedAtMonotonicNs'] - a['finishedAtMonotonicNs']) / 1e6
            gap['rightScanLeadingHalfMs'] = (right[1] - b['startedAtMonotonicNs']) / 1e6
            gap['aboveConfigured25msWaitMs'] = gap['betweenScanEndToStartMs'] - 25
            gap['interveningExcludedScans'] = [describe(samples, i, start) for i in range(left[0] + 1, right[0])]
            assert math.isclose(gap['gapMs'], gap['leftScanRemainingHalfMs'] + gap['betweenScanEndToStartMs'] + gap['rightScanLeadingHalfMs'], abs_tol=1e-9)
        else:
            gap['classification'] = 'import-marker-boundary'
        gaps.append(gap)
    gaps.sort(key=lambda value: value['gapMs'], reverse=True)
    assert gaps[0]['gapMs'] == original['maximumCoveredSampleGapMs']
    exceeded = [gap for gap in gaps if gap['gapMs'] > 250]
    assert all(gap['classification'] == 'interior-covered-scans' and not gap['interveningExcludedScans'] for gap in exceeded)
    durations = [(sample['finishedAtMonotonicNs'] - sample['startedAtMonotonicNs']) / 1e6 for _, sample in covered]
    waits = [(b['startedAtMonotonicNs'] - a['finishedAtMonotonicNs']) / 1e6 for (_, a), (_, b) in zip(covered, covered[1:])]
    observation = {
        'rawReceiptSha256': digest(raw),
        'markersSha256': digest((COHORT / name / 'markers.jsonl').read_bytes()),
        'qualificationReproducedExactly': True,
        'qualifiedForWholeTreePss': False,
        'qualificationFailures': original['qualificationFailures'],
        'qualifiedPssMaximum': None,
        'qualifiedPrivateMaximum': None,
        'importDurationMs': original['windowDurationMs'],
        'coveredScanCount': len(covered),
        'overlappingScanCount': original['overlappingImportSampleCount'],
        'allOverlappingScansFullyRead': original['stableFullyReadTreeSampleCount'] == original['overlappingImportSampleCount'],
        'preImportBracketGapMs': original['preImportBracketGapMs'],
        'postImportBracketGapMs': original['postImportBracketGapMs'],
        'importStartToFirstMidpointMs': (points[1][1] - start) / 1e6,
        'lastMidpointToImportEndMs': (end - points[-2][1]) / 1e6,
        'scanDurationMs': {'minimum': min(durations), 'median': statistics.median(durations), 'maximum': max(durations)},
        'betweenScanEndToStartMs': {'minimum': min(waits), 'median': statistics.median(waits), 'maximum': max(waits)},
        'thresholdExceededGapCount': len(exceeded),
        'maximumGap': gaps[0],
        'everyThresholdExceededGap': exceeded,
    }
    result['observations'][name] = observation
    gap = gaps[0]
    print(name, json.dumps({'maxGapMs': gap['gapMs'], 'leftScanDurationMs': gap['left']['durationMs'], 'betweenScansMs': gap['betweenScanEndToStartMs'], 'rightScanDurationMs': gap['right']['durationMs'], 'exceededInteriorGapCount': len(exceeded)}))
result['conclusion'] = 'Every failing maximum is between consecutive fully qualified, wholly in-window scans of nine Chromium processes. No omitted/invalid scan or marker-boundary interval causes the failures. Elapsed scan durations dominate; the intervals between scans remain near the configured 25 ms wait. All four observations correctly remain unqualified under the unchanged protocol.'
result['limits'] = 'Raw receipts time each whole scan, not the two process inventories, individual smaps reads, CPU consumption or preemption within the scan. The data therefore cannot distinguish intrinsic /proc work from scheduling/blocking during a scan, nor establish a candidate memory regression or saving. This is a concrete temporal-coverage limitation on this host/corpus for both baseline and candidate; prequeue memory remains subject to its own unchanged full-process qualification.'
destination = ROOT / 'current-baseline-artifacts/lazy-vndb-ab-sampling-gap-attribution.json'
destination.write_text(json.dumps(result, indent=2) + '\n')
