import assert from 'node:assert/strict'
import {execFileSync} from 'node:child_process'
import {createHash} from 'node:crypto'
import {readFileSync} from 'node:fs'
import {createRequire} from 'node:module'
import {join, resolve} from 'node:path'

const root = resolve(process.argv[2] ?? '/tmp/manabitan-lazy-ids-63aba8')
const beforeCommit = 'da03aa70f88d4b0616eeab8ed251f48a17f8de13'
const afterCommit = 'b0a4532ed4209ad289aa28ac58a92a10e9d54841'
const runtime = 'ext/js/dictionary/dictionary-database.js'
const changedRuntimePaths = execFileSync('git', ['-C', root, 'diff', '--name-only', beforeCommit, afterCommit, '--', 'ext'], {encoding: 'utf8'})
    .trim().split('\n').filter(Boolean)
assert.deepEqual(changedRuntimePaths, [runtime], 'The runtime delta includes an unverified file')
const acorn = createRequire(join(root, 'package.json'))('acorn')
const source = (commit) => execFileSync('git', ['-C', root, 'show', `${commit}:${runtime}`], {encoding: 'utf8'})
const before = source(beforeCommit)
const after = source(afterCommit)
assert.equal(readFileSync(join(root, runtime), 'utf8'), after, 'Working runtime does not match the frozen style follow-up')
const removedAstFields = ['start', 'end', 'loc', 'range']
const canonical = (code) => JSON.stringify(
    acorn.parse(code, {ecmaVersion: 'latest', sourceType: 'module'}),
    (key, value) => removedAstFields.includes(key) ? undefined : value,
)
const beforeAst = canonical(before)
const afterAst = canonical(after)
assert.equal(beforeAst, afterAst, 'Runtime AST changed')
const sha256 = (bytes) => createHash('sha256').update(bytes).digest('hex')
console.log(JSON.stringify({
    scope: 'Complete runtime AST comparison for the whitespace-only product follow-up; test-only style changes are separate',
    beforeCommit,
    afterCommit,
    runtime,
    changedRuntimePaths,
    beforeSha256: sha256(before),
    afterSha256: sha256(after),
    parser: 'acorn',
    parserVersion: acorn.version,
    ecmaVersion: 'latest',
    sourceType: 'module',
    removedAstFields,
    astSha256: sha256(beforeAst),
    astByteLength: Buffer.byteLength(beforeAst),
    astExactlyEqual: true,
}, null, 2))
