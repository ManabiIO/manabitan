#!/usr/bin/env python3
"""Preserve exact measured/review source IDs without copying baseline history."""
from pathlib import Path
import hashlib
import json
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE_REPO = ROOT / 'baseline'
BASELINE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
REFS = {
    'refs/heads/lazy-ids-initial': 'f17102bac19688f1115d1d630720838abf0df00c',
    'refs/heads/lazy-ids-measured': 'da03aa70f88d4b0616eeab8ed251f48a17f8de13',
    'refs/heads/lazy-ids-review': 'b0a4532ed4209ad289aa28ac58a92a10e9d54841',
}
BUNDLE = ROOT / 'experiments/lazy-ids-source-f171-da03-b0a.bundle'
RUNTIME = 'ext/js/dictionary/dictionary-database.js'
DEPENDENCIES = Path('/workspace/scratch/f34c9c9fae89/manabitan/node_modules')
BASELINE_STORE = Path('/home/agent/manabitan-baseline-only-63aba8.git')

def run(repo, *args, input=None):
    return subprocess.run(['git', '-C', str(repo), *args], input=input,
                          check=True, capture_output=True).stdout

def text(repo, *args):
    return run(repo, *args).decode().strip()

def digest(data):
    return hashlib.sha256(data).hexdigest()

assert BASELINE_STORE.exists()
assert text(BASELINE_STORE, 'rev-list', '--all').splitlines() == [BASELINE]
assert not (BASELINE_STORE / 'objects/info/alternates').exists()
baseline_object_count = len(text(BASELINE_STORE, 'rev-list', '--objects', '--all').splitlines())
objects = Path(text(SOURCE_REPO, 'rev-parse', '--git-path', 'objects'))
if not objects.is_absolute():
    objects = (SOURCE_REPO / objects).resolve()

with tempfile.TemporaryDirectory(prefix='lazy-id-bundle-63aba8-', dir='/home/agent') as directory:
    temporary = Path(directory)
    staging = temporary / 'staging.git'
    verified = temporary / 'verified'
    if not BUNDLE.exists():
        subprocess.run(['git', 'init', '--bare', '-q', str(staging)], check=True)
        (staging / 'objects/info/alternates').write_text(str(objects) + '\n')
        for ref, commit in REFS.items():
            run(staging, 'update-ref', ref, commit)
        run(staging, 'bundle', 'create', str(BUNDLE), *REFS, '^' + BASELINE)

    subprocess.run(['git', 'init', '-q', str(verified)], check=True)
    # Borrow only the independently verified baseline-only store. It contains
    # no candidate commits and receives no writes during this verification.
    (verified / '.git/objects/info/alternates').write_text(str(BASELINE_STORE / 'objects') + '\n')
    (verified / '.git/shallow').write_text(BASELINE + '\n')
    run(verified, 'update-ref', 'refs/heads/baseline', BASELINE)
    absent_before = {}
    for commit in REFS.values():
        absent_before[commit] = subprocess.run(
            ['git', '-C', str(verified), 'cat-file', '-e', commit], capture_output=True,
        ).returncode != 0
    assert all(absent_before.values())
    verification = subprocess.run(
        ['git', '-C', str(verified), 'bundle', 'verify', str(BUNDLE)],
        check=True, capture_output=True, text=True,
    )
    run(verified, 'fetch', '--no-tags', str(BUNDLE), *[f'{ref}:{ref}' for ref in REFS])
    imported = {ref: text(verified, 'rev-parse', ref) for ref in REFS}
    assert imported == REFS
    fsck = subprocess.run(['git', '-C', str(verified), 'fsck', '--full', '--strict', '--no-dangling'],
                          check=True, capture_output=True, text=True)
    assert all(subprocess.run(['git', '-C', str(BASELINE_STORE), 'cat-file', '-e', commit],
                              capture_output=True).returncode != 0 for commit in REFS.values())
    runtime_hashes = {}
    for commit in REFS.values():
        expected = run(SOURCE_REPO, 'show', f'{commit}:{RUNTIME}')
        actual = run(verified, 'show', f'{commit}:{RUNTIME}')
        assert actual == expected
        runtime_hashes[commit] = digest(actual)
    review = REFS['refs/heads/lazy-ids-review']
    runtime_path = verified / RUNTIME
    runtime_path.parent.mkdir(parents=True)
    runtime_path.write_bytes(run(verified, 'show', f'{review}:{RUNTIME}'))
    (verified / 'package.json').write_bytes(run(verified, 'show', f'{BASELINE}:package.json'))
    (verified / 'node_modules').symlink_to(DEPENDENCIES, target_is_directory=True)
    ast = json.loads(subprocess.check_output([
        'node', str(ROOT / 'current-baseline-artifacts/verify-lazy-ids-lint-ast.mjs'), str(verified),
    ]))
    assert ast['astExactlyEqual']
    heads = text(verified, 'bundle', 'list-heads', str(BUNDLE)).splitlines()
    body = BUNDLE.read_bytes()
    header = body.split(b'\n\n', 1)[0].decode()
    prerequisites = [line[1:].split(' ', 1)[0] for line in header.splitlines() if line.startswith('-')]
    assert prerequisites == [BASELINE]
    receipt = {
        'bundle': str(BUNDLE.relative_to(ROOT)),
        'bundleSha256': digest(body),
        'bundleBytes': len(body),
        'prerequisiteCommits': prerequisites,
        'containedRefs': REFS,
        'listHeads': heads,
        'runtimeSha256ByCommit': runtime_hashes,
        'verification': {
            'seededBaselineObjectCount': baseline_object_count,
            'seedDescription': 'Independent temporary repository borrows only a complete shallow baseline-only store, which has no alternates and no candidate objects. Candidate absence is asserted before bundle import and rechecked in the unchanged shared store afterward.',
            'baselineOnlyStore': str(BASELINE_STORE),
            'baselineOnlyStoreReceipt': 'experiments/baseline-only-object-store.json',
            'candidateObjectsAbsentBeforeImport': absent_before,
            'bundleVerifyStdout': verification.stdout,
            'bundleVerifyStderr': verification.stderr,
            'importedRefs': imported,
            'allImportedRuntimeBytesMatchSource': True,
            'fullStrictFsckPassed': True,
            'fsckLog': fsck.stdout + fsck.stderr,
            'runtimeAstProofInImportedRepository': ast,
            'temporaryVerificationRepositoryRemoved': True,
        },
        'scope': 'Exact local source commit preservation. Remote study wrapper commits have distinct Git IDs and are not substituted for these source commits.',
        'reproduction': [
            'Use an existing repository that contains baseline 9e10d3b3fcf66d344ab31bc42c9b522fa5215da2 and its normal source objects.',
            'Verify the bundle SHA-256 against this manifest, then run git bundle verify PATH/lazy-ids-source-f171-da03-b0a.bundle.',
            'Run git fetch PATH/lazy-ids-source-f171-da03-b0a.bundle refs/heads/lazy-ids-initial:refs/heads/receipt/lazy-ids-initial refs/heads/lazy-ids-measured:refs/heads/receipt/lazy-ids-measured refs/heads/lazy-ids-review:refs/heads/receipt/lazy-ids-review.',
            'Create a detached worktree at b0a4532ed4209ad289aa28ac58a92a10e9d54841, install the pinned package-lock dependencies, and run node PATH/verify-lazy-ids-lint-ast.mjs WORKTREE.',
            'Keep da03aa7 measured package receipts unchanged; AST equivalence links the whitespace-only review delta without rewriting measured source identity.',
        ],
    }
manifest = BUNDLE.with_suffix('.bundle.manifest.json')
manifest.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'bundle': str(BUNDLE), 'sha256': receipt['bundleSha256'], 'bytes': len(body), 'baselineObjects': baseline_object_count, 'importedRefs': imported, 'astExactlyEqual': ast['astExactlyEqual'], 'manifest': str(manifest)}))
