// SPDX-License-Identifier: GPL-3.0-or-later
// Untimed source-bound work model. No WASM module is instantiated by this file.
import assert from 'node:assert/strict';
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {inflateRawSync, crc32} from 'node:zlib';
import path from 'node:path';

const HERE=path.dirname(fileURLToPath(import.meta.url));
const REPO='/workspace/scratch/5a86d1e7822a/manabitan';
const EVIDENCE='/home/agent/manabitan-startup-followup-5a86/builds/perf/import-analysis-20261128-5a86';
const BASE='9e10d3b3fcf66d344ab31bc42c9b522fa5215da2';
const MASK='2cdcc90241fa19221b7fc4e5d793eb70896c3258';
const sha=(b)=>createHash('sha256').update(b).digest('hex');
const isSpace=(b)=>b===32||b===9||b===10||b===13;
const special=(b)=>b===34||b===92||b<32;
const hex=(b)=>(b>=48&&b<=57)||(b>=65&&b<=70)||(b>=97&&b<=102);
function skipSpace(b,i){while(i<b.length&&isSpace(b[i]))++i;return i;}
function stringEnd(b,start){
 assert.equal(b[start],34);
 let p=start+1;
 while(p<b.length){
  const q=b.indexOf(34,p);assert(q>=0,'unterminated string');
  let n=0;for(let k=q-1;k>start&&b[k]===92;--k)++n;
  if(!(n&1))return q+1;p=q+1;
 }
 throw Error('unterminated string');
}
function valueEnd(b,start){
 if(b[start]===34)return stringEnd(b,start);
 if(b[start]===91||b[start]===123){
  const stack=[b[start]];
  for(let i=start+1;i<b.length;++i){
   const c=b[i];
   if(c===34)i=stringEnd(b,i)-1;
   else if(c===91||c===123)stack.push(c);
   else if(c===93||c===125){
    assert.equal(stack.pop(),c===93?91:123);
    if(stack.length===0)return i+1;
   }
  }
  throw Error('unterminated composite');
 }
 let i=start;while(i<b.length&&b[i]!==44&&b[i]!==93&&b[i]!==125&&!isSpace(b[i]))++i;
 assert(i>start);return i;
}
function* scanBank(bytes){
 const semantics=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
 assert(Array.isArray(semantics));
 let i=skipSpace(bytes,0),rowIndex=0;assert.equal(bytes[i++],91);
 while(true){
  i=skipSpace(bytes,i);if(bytes[i]===93){++i;break;}
  assert.equal(bytes[i++],91);
  const fields=[],starts=[],ends=[];
  for(let f=0;f<8;++f){
   i=skipSpace(bytes,i);const start=i;i=valueEnd(bytes,i);
   starts.push(start);ends.push(i);fields.push(bytes.subarray(start,i));
   i=skipSpace(bytes,i);if(f<7)assert.equal(bytes[i++],44);
  }
  assert.equal(bytes[i++],93);
  const semantic=semantics[rowIndex++];
  assert(Array.isArray(semantic)&&semantic.length===8);
  assert(Array.isArray(semantic[5]));
  assert.equal(typeof semantic[0],'string');assert.equal(typeof semantic[1],'string');
  assert(semantic[2]===null||typeof semantic[2]==='string');
  assert.equal(typeof semantic[3],'string');assert.equal(typeof semantic[7],'string');
  assert(Number.isInteger(semantic[4])&&!Object.is(semantic[4],-0));
  assert(semantic[6]===null||Number.isInteger(semantic[6]));
  for(const v of semantic[5]){
   if(v!==null&&typeof v==='object'&&!Array.isArray(v)){
    const required=v.type==='text'?'text':v.type==='image'?'path':v.type==='structured-content'?'content':null;
    assert(required!==null,'unsupported top-level glossary object');
    assert(typeof v[required]==='string'||(required==='content'&&v[required]!==null&&typeof v[required]==='object'));
   }
  }
  yield {bytes,fields,starts,ends,rowIndex};
  i=skipSpace(bytes,i);
  if(bytes[i]===44)++i;else assert.equal(bytes[i],93);
 }
 assert.equal(skipSpace(bytes,i),bytes.length);assert.equal(rowIndex,semantics.length);
}
function scannerCounts(){
 return {calls:0,tokenBytes:0,iterations:0,word8Loads:0,word8Plain:0,word8Special:0,
  byteVisits:0,scalarPlainSteps:0,shortEscapes:0,unicodeEscapes:0,quoteReturns:0,
  rangeLowerChecks:0,rangeUpperChecks:0,cacheHits:0,crossStringCacheHits:0,sameStringCacheHits:0,
  cacheHitWith16ByteRoom:0,cacheHitNearBankEnd:0,cachedZeroMasks:0,cachedSpecialMasks:0,
  fresh16Tests:0,fresh16Loads:0,fresh16ZeroMasks:0,fresh16SpecialMasks:0,
  fallback8Entries:0,callsWithEntryCacheHit:0,callsWithAnyCacheHit:0,callsWithoutFresh16:0,
  callsEntirelyFromPriorWindow:0,loadsCrossingGlossaryEnd:0};
}
function escapeAdvance(b,len,i,c){
 assert(i+1<len);
 const e=b[i+1];
 if(e===117){
  assert(i+6<=len);for(let j=i+2;j<i+6;++j)assert(hex(b[j]));
  ++c.unicodeEscapes;return i+6;
 }
 assert([34,92,47,98,102,110,114,116].includes(e));++c.shortEscapes;return i+2;
}
function word8(b,i,c,glossaryEnd){
 ++c.word8Loads;if(i+8>glossaryEnd)++c.loadsCrossingGlossaryEnd;
 for(let n=0;n<8;++n)if(special(b[i+n])){++c.word8Special;return n;}
 ++c.word8Plain;return -1;
}
function baselineString(b,len,start,c,glossaryEnd){
 assert(start<len&&b[start]===34);++c.calls;
 let i=start+1;
 while(i<len){
  ++c.iterations;
  while(i+8<=len){const n=word8(b,i,c,glossaryEnd);if(n>=0){i+=n;break;}i+=8;}
  if(i>=len)break;
  ++c.byteVisits;const v=b[i];
  if(v===92){i=escapeAdvance(b,len,i,c);continue;}
  assert(v>=32);
  if(v===34){++c.quoteReturns;c.tokenBytes+=i+1-start;return i+1;}
  ++c.scalarPlainSteps;++i;
 }
 throw Error('baseline unterminated');
}
function maskString(b,len,start,c,w,id,glossaryEnd){
 assert(start<len&&b[start]===34);++c.calls;
 const initialFresh=c.fresh16Loads,initial8=c.word8Loads,initialHits=c.cacheHits;
 let i=start+1,entry=true,entryHit=false,entryWindowEnd=0;
 while(i<len){
  ++c.iterations;++c.rangeLowerChecks;
  let hit=false;
  if(i>=w.start){++c.rangeUpperChecks;hit=i<w.end;}
  if(hit){
   ++c.cacheHits;if(w.owner===id)++c.sameStringCacheHits;else ++c.crossStringCacheHits;
   if(len-i>=16)++c.cacheHitWith16ByteRoom;else ++c.cacheHitNearBankEnd;
   if(entry){entryHit=true;entryWindowEnd=w.end;++c.callsWithEntryCacheHit;}
   const shifted=w.mask>>>(i-w.start);
   if(shifted===0){++c.cachedZeroMasks;i=w.end;entry=false;continue;}
   ++c.cachedSpecialMasks;i+=31-Math.clz32(shifted&-shifted);
  }else{
   ++c.fresh16Tests;
   if(len-i>=16){
    ++c.fresh16Loads;if(i+16>glossaryEnd)++c.loadsCrossingGlossaryEnd;
    let mask=0;for(let n=0;n<16;++n)if(special(b[i+n]))mask|=1<<n;
    w.start=i;w.end=i+16;w.mask=mask;w.owner=id;
    if(mask===0){++c.fresh16ZeroMasks;i+=16;entry=false;continue;}
    ++c.fresh16SpecialMasks;i+=31-Math.clz32(mask&-mask);
   }else{
    ++c.fallback8Entries;
    while(len-i>=8){const n=word8(b,i,c,glossaryEnd);if(n>=0){i+=n;break;}i+=8;}
    if(i>=len)break;
   }
  }
  entry=false;++c.byteVisits;const v=b[i];
  if(v===92){i=escapeAdvance(b,len,i,c);continue;}
  assert(v>=32);
  if(v===34){
   ++c.quoteReturns;c.tokenBytes+=i+1-start;
   if(c.cacheHits>initialHits)++c.callsWithAnyCacheHit;
   if(c.fresh16Loads===initialFresh)++c.callsWithoutFresh16;
   if(entryHit&&i<entryWindowEnd&&c.fresh16Loads===initialFresh&&c.word8Loads===initial8)++c.callsEntirelyFromPriorWindow;
   return i+1;
  }
  ++c.scalarPlainSteps;++i;
 }
 throw Error('candidate unterminated');
}
function walkCounts(){
 return {compositeCalls:0,genericStringCalls:0,commonContentKeys:0,commonTagKeys:0,
  shortTagValueShortcuts:0,allRawStringTokens:0,rawStringBytes:0,
  textNormalizationTriggers:0,textNormalizationRows:0,normalizationRows:0,maxContainerDepth:0,
  baseline:scannerCounts(),mask:scannerCounts(),resetEachString:scannerCounts()};
}
const CONTENT=Buffer.from('"content"'),TAG=Buffer.from('"tag"');
const TAGS=['div','span','ruby','rt','ul','li','a'].map(x=>Buffer.from('"'+x+'"'));
function walkGlossary(b,start,end,c){
 ++c.compositeCalls;
 const w={start:0,end:0,mask:0,owner:0};
 let stringId=0,textHint=false,normalization=false;
 const ws=(i)=>{const j=skipSpace(b,i);if(j>i)normalization=true;return j;};
 const generic=(i,expected)=>{
  ++c.genericStringCalls;++stringId;
  assert.equal(baselineString(b,b.length,i,c.baseline,end),expected);
  assert.equal(maskString(b,b.length,i,c.mask,w,stringId,end),expected);
  assert.equal(maskString(b,b.length,i,c.resetEachString,{start:0,end:0,mask:0,owner:0},stringId,end),expected);
 };
 const rawString=(i)=>{const e=stringEnd(b,i);++c.allRawStringTokens;c.rawStringBytes+=e-i;return e;};
 const walk=(i,depth,bypassString=false)=>{
  const first=b[i];
  if(first===34){const e=rawString(i);if(!bypassString)generic(i,e);return e;}
  if(first!==91&&first!==123){
   const e=valueEnd(b,i);assert(/^(null|true|false|-?(?:0|[1-9][0-9]*)(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?)$/.test(b.toString('utf8',i,e)));return e;
  }
  ++depth;c.maxContainerDepth=Math.max(c.maxContainerDepth,depth);assert(depth<=256);
  const close=first===91?93:125;i=ws(i+1);
  if(b[i]===close)return i+1;
  while(true){
   if(first===123){
    assert.equal(b[i],34);const keyStart=i,keyEnd=rawString(i);
    const key=b.subarray(i,keyEnd);
    let common=0;
    if(key.equals(CONTENT)){common=1;++c.commonContentKeys;}
    else if(key.equals(TAG)){common=2;++c.commonTagKeys;}
    else generic(i,keyEnd);
    i=ws(keyEnd);assert.equal(b[i++],58);i=ws(i);
    // Source type_text_pair_at examines every raw key, including duplicates,
    // at any object depth. It runs until the monotonic text hint is set.
    if(common===0&&(b[keyStart+1]===116||b[keyStart+1]===92)&&!textHint&&
       JSON.parse(key.toString('utf8'))==='type'&&b[i]===34){
      const valueStringEnd=stringEnd(b,i);
      if(JSON.parse(b.toString('utf8',i,valueStringEnd))==='text'){
       textHint=true;++c.textNormalizationTriggers;normalization=true;
      }
    }
    let bypass=false;
    if(common===2&&b[keyEnd]===58){
     let value=keyEnd+1;if(b[value]===32)++value;
     if(b.length-value>=4){
      for(const tag of TAGS){
       if(value+tag.length<b.length&&b.subarray(value,value+tag.length).equals(tag)&&b[value+tag.length]===44){
        assert.equal(value,i);bypass=true;++c.shortTagValueShortcuts;break;
       }
      }
     }
    }
    i=walk(i,depth,bypass);
   }else i=walk(i,depth);
   i=ws(i);if(b[i]===close)return i+1;
   assert.equal(b[i++],44);i=ws(i);assert.notEqual(b[i],close);
  }
 };
 assert.equal(b[start],91);assert.equal(walk(start,0),end);
 if(textHint)++c.textNormalizationRows;if(normalization)++c.normalizationRows;
 return {textHint,normalization};
}
function selfTest(){
 const fixtures=[
  '["a","b","c"]',
  '[{"content":["a","b"],"tag":"li","type":"structured-content"}]',
  '[{"tag": "span","content":"x\\\\u0041y\\\\\\\"z","type":"structured-content"}]',
  '[{"tag" : "span", "content":"x", "type":"structured-content"}]',
  '[{"type":"text","type":"structured-content","content":"x"}]',
  '[{"content":{"type":"text","type":"other"},"type":"structured-content"}]',
  '[{"\\u0074ype":"\\u0074ext","text":"x"}]',
  '[{"type":"structured-content","content":"type text"}]',
 ];
 for(const raw of fixtures){
  const b=Buffer.from(raw+',1,""]');const c=walkCounts();const h=walkGlossary(b,0,Buffer.byteLength(raw),c);
  assert.equal(c.genericStringCalls,c.baseline.calls);assert.equal(c.baseline.calls,c.mask.calls);
  assert.equal(c.mask.calls,c.resetEachString.calls);assert.equal(c.baseline.tokenBytes,c.mask.tokenBytes);
  assert.equal(c.allRawStringTokens,c.genericStringCalls+c.commonContentKeys+c.commonTagKeys+c.shortTagValueShortcuts);
  if(raw.includes('"type":"text"')||raw.includes('"\\u0074ype"'))assert(h.textHint);
 }
 // A near-bank-end scalar tail is not fully covered by the entry cache.
 {
  const b=Buffer.from('["1234567890","abcdef"]');const c=walkCounts();walkGlossary(b,0,b.length,c);
  assert.equal(c.mask.callsWithEntryCacheHit,1);
  assert.equal(c.mask.callsWithoutFresh16,1);
  assert.equal(c.mask.callsEntirelyFromPriorWindow,0);
 }
 // Natural scalar/SIMD boundaries and escaped continuations; independent end scanner.
 for(let n=0;n<=65;++n)for(const tail of ['','\\n','\\u0041','\\"','\\\\']){
  const raw='"'+'x'.repeat(n)+tail+'"';
  for(let slack=0;slack<=17;++slack){
   const b=Buffer.from(raw+' '.repeat(slack));const c=scannerCounts(),d=scannerCounts();
   const e=stringEnd(b,0);assert.equal(baselineString(b,b.length,0,c,e),e);
   assert.equal(maskString(b,b.length,0,d,{start:0,end:0,mask:0,owner:0},1,e),e);
  }
 }
 return {validGlossaries:fixtures.length+1,scannerBoundaryCases:66*5*18,noCorpus:true,noWasmInstantiation:true};
}
function partition(entries){
 const total=entries.reduce((s,e)=>s+e.uncompressedSize,0);
 const count=Math.min(entries.length,Math.max(3*4,Math.ceil(total/(24*1024*1024))));
 const groups=[];let start=0,consumed=0;
 for(let index=0;index<count-1;++index){
  const remaining=count-index,target=(total-consumed)/remaining;
  let stop=start+1,bytes=entries[start].uncompressedSize;
  while(stop<entries.length-(remaining-1)){
   const next=bytes+entries[stop].uncompressedSize;
   if(Math.abs(next-target)>Math.abs(bytes-target))break;
   bytes=next;++stop;
  }
  groups.push(entries.slice(start,stop));start=stop;consumed+=bytes;
 }
 groups.push(entries.slice(start));return groups;
}
function zipEntries(zip){
 let eocd=-1;for(let p=zip.length-22;p>=Math.max(0,zip.length-65557);--p)if(zip.readUInt32LE(p)===0x06054b50){eocd=p;break;}
 assert(eocd>=0);assert.equal(zip.readUInt16LE(eocd+4),0);assert.equal(zip.readUInt16LE(eocd+6),0);
 const n=zip.readUInt16LE(eocd+10),size=zip.readUInt32LE(eocd+12);let p=zip.readUInt32LE(eocd+16),start=p;const entries=[];
 for(let i=0;i<n;++i){
  assert.equal(zip.readUInt32LE(p),0x02014b50);
  const nameLength=zip.readUInt16LE(p+28),extra=zip.readUInt16LE(p+30),comment=zip.readUInt16LE(p+32);
  const filename=zip.toString('utf8',p+46,p+46+nameLength);
  const e={filename,flags:zip.readUInt16LE(p+8),method:zip.readUInt16LE(p+10),crc:zip.readUInt32LE(p+16),
   compressedSize:zip.readUInt32LE(p+20),uncompressedSize:zip.readUInt32LE(p+24),localOffset:zip.readUInt32LE(p+42)};
  if(/^term_bank_\d+\.json$/.test(filename))entries.push(e);
  p+=46+nameLength+extra+comment;
 }
 assert.equal(p-start,size);assert.equal(p,eocd);
 return entries.sort((a,b)=>Number(a.filename.slice(10,-5))-Number(b.filename.slice(10,-5)));
}
function readBank(zip,e){
 const p=e.localOffset;assert.equal(zip.readUInt32LE(p),0x04034b50);assert.equal(e.flags&1,0);
 assert.equal(zip.readUInt16LE(p+8),8);assert.equal(e.method,8);
 assert.equal(zip.readUInt16LE(p+6),e.flags);
 const nameLength=zip.readUInt16LE(p+26),extra=zip.readUInt16LE(p+28);
 assert.equal(zip.toString('utf8',p+30,p+30+nameLength),e.filename);
 const from=p+30+nameLength+extra,to=from+e.compressedSize;assert(to<=zip.length);
 const compressed=zip.subarray(from,to),result=inflateRawSync(compressed,{info:true});
 assert.equal(result.engine.bytesWritten,e.compressedSize);assert.equal(result.buffer.length,e.uncompressedSize);
 assert.equal(crc32(result.buffer),e.crc);
 return {bytes:result.buffer,compressedSha256:sha(compressed)};
}
function merge(to,from){
 for(const [k,v] of Object.entries(from)){
  if(typeof v==='number')to[k]=k==='maxContainerDepth'?Math.max(to[k],v):to[k]+v;
  else merge(to[k],v);
 }
}
function conclusions(c){
 return {scope:'Source-operation counts only, not native counters, instructions, memory traffic or time.',
  baselineWord8Classifications:c.baseline.word8Loads,
  baselineClassifiedByteSum:c.baseline.word8Loads*8,
  actualFresh16Classifications:c.mask.fresh16Loads,
  actualClassifiedByteSum:c.mask.fresh16Loads*16+c.mask.word8Loads*8,
  resetEachStringFresh16Classifications:c.resetEachString.fresh16Loads,
  crossStringPersistenceFresh16Difference:c.resetEachString.fresh16Loads-c.mask.fresh16Loads,
  cacheHitRatio:c.mask.cacheHits/c.mask.iterations,
  crossStringHitRatio:c.mask.crossStringCacheHits/c.mask.iterations,
  fullyCoveredByPriorWindowCalls:c.mask.callsEntirelyFromPriorWindow,
  zeroMaskFreshClassifications:c.mask.fresh16ZeroMasks,
  sourceWindowFieldInitializations:c.compositeCalls*3,
  sourceWindowFieldAssignments:c.mask.fresh16Loads*3,
  sourceZeroMaskFieldAssignments:c.mask.fresh16ZeroMasks*3,
  sourceRangeComparisons:c.mask.rangeLowerChecks+c.mask.rangeUpperChecks,
  sourceMaskShifts:c.mask.cacheHits,
  sourceCtzOperations:c.mask.cachedSpecialMasks+c.mask.fresh16SpecialMasks+c.mask.word8Special,
  bytecodeCaveat:'Exact frozen WASM scalar-replaces the cache into locals; these field assignments are not linear-memory stores. No follow-up store-elision candidate is proposed.'};
}
async function main(){
 const self=selfTest();
 if(process.argv.includes('--self-test')){console.log(JSON.stringify(self));return;}
 const out=path.join(HERE,'result');await mkdir(out,{recursive:false});
 const runner=await readFile(fileURLToPath(import.meta.url));
 const sourcePath='ext/js/dictionary/wasm/term-bank-parser.c';
 const source=(commit,file)=>execFileSync('git',['show',commit+':'+file],{cwd:REPO});
 const baseline=source(BASE,sourcePath),candidate=source(MASK,sourcePath);
 assert.equal(sha(baseline),'5a8257cb77d061694b6b2d247057aebb53ea2f49521d8d9893b3af175f145d8a');
 assert.equal(sha(candidate),'3c5c6d89a44356e2f0c3af8636f82a4a77a1f7212891161707e4465acaa2ca5e');
 const lock=source(BASE,'test/perf/dictionaries.lock.json');assert.equal(sha(lock),'60aa981791f3b60ca17588212aea5bd3536fb8f59288855e5accd019c6e4cf89');
 const spec=JSON.parse(lock).dictionaries.jmdict;
 const oracleBytes=await readFile(path.join(EVIDENCE,'census/jmdict-suffix-production-groups.json'));
 assert.equal(sha(oracleBytes),'5d809c6ac68e083f48003e711b576d080d82d0a067c32dc606180b907e0c4904');
 const oracle=JSON.parse(oracleBytes);
 const zip=await readFile(path.join(REPO,'builds/e2e-dictionary-cache',spec.cacheFile));
 assert.equal(sha(zip),spec.sha256);assert.equal(zip.length,spec.sizeBytes);
 const groups=partition(zipEntries(zip));assert.equal(groups.length,12);
 assert.deepEqual(groups.map(g=>g.length),[5,4,4,4,5,5,4,5,4,4,4,5]);
 const report={schema:1,complete:false,kind:'Untimed exact-input scanner work-count model',
  noWasmInstantiation:true,noPerformanceObservation:true,node:process.version,selfTests:self,
  source:{baseline:BASE,mask:MASK,baselineC:sha(baseline),maskC:sha(candidate)},
  provenance:{runnerSha256:sha(runner),fixtureSha256:spec.sha256,fixtureBytes:zip.length,
   fixtureLockSha256:sha(lock),existingExactGroupCensusSha256:sha(oracleBytes)},
  scope:'Primary strict format-3 glossary validation only, conditional on zero text-normalization hints and the existing no-media/no-fallback production receipts. Every raw key is traversed, including duplicate and escaped type keys. Exact common-key and short-tag shortcuts bypass string helpers. Cache remains local to one composite and uses complete logical bank bounds. Existing validation reuse and recent-content admission are modeled per production group; no flags, policies, WASM or runtime sources change. A per-string-reset16-byte model isolates cross-string cache persistence but is not a production candidate or speed comparison.',
  policy:{parserWorkers:3,groupsPerWorker:4,targetBytes:24*1024*1024,priorRows:4,previousGlossaryMinBytes:512,admissionStreak:4,probeBudget:4},
  totals:{banks:0,rows:0,sourceBytes:0,validatedGlossaryReuseRows:0,recentContentHits:0},
  counts:walkCounts(),groups:[],failure:null};
 const save=()=>writeFile(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');
 await save();
 try{
  for(const [index,entries] of groups.entries()){
   const prior=[];let budget=0,streak=0;
   const g={index,banks:[],rows:0,sourceBytes:0,validatedGlossaryReuseRows:0,recentContentHits:0,counts:walkCounts()};
   report.groups.push(g);
   const expected=oracle.groups[index];assert.equal(entries[0].filename,expected.firstBank);assert.equal(entries.at(-1).filename,expected.lastBank);
   for(const e of entries){
    const {bytes,compressedSha256}=readBank(zip,e);
    const expectedBank=expected.bankInputs.find(x=>x.filename===e.filename);assert(expectedBank);
    assert.equal(sha(bytes),expectedBank.sha256);assert.equal(bytes.length,expectedBank.sourceBytes);assert.equal(e.crc,expectedBank.crc32);
    const bank={name:e.filename,rows:0,bytes:bytes.length,sha256:sha(bytes),compressedSha256,crc32:e.crc};g.banks.push(bank);
    for(const row of scanBank(bytes)){
     const lookback=budget>0?4:(prior.length>0&&prior.at(-1).fields[5].length>=512?1:0);
     let witness=0,rawMatch=0;
     for(let d=1;d<=Math.min(prior.length,4);++d){
      const p=prior.at(-d);
      if(!witness&&d<=lookback&&row.fields[5].equals(p.fields[5]))witness=d;
      if(!rawMatch&&[5,3,2,7].every(f=>row.fields[f].equals(p.fields[f])))rawMatch=d;
     }
     if(witness){
      ++g.validatedGlossaryReuseRows;row.hints=prior.at(-witness).hints;budget=4;
     }else{
      row.hints=walkGlossary(bytes,row.starts[5],row.ends[5],g.counts);
      assert.equal(row.hints.textHint,false,'Unmodeled general text-normalization route: stop rather than omit composite calls');
      if(budget>0)--budget;
     }
     assert.equal(row.hints.textHint,false);
     if(rawMatch){++g.recentContentHits;if(streak>=4||++streak>=4)budget=4;}else streak=0;
     ++g.rows;++bank.rows;prior.push(row);if(prior.length>4)prior.shift();
    }
    assert.equal(bank.rows,expectedBank.rows);g.sourceBytes+=bytes.length;await save();
   }
   assert.equal(g.rows,expected.rows);assert.equal(g.sourceBytes,expected.sourceBytes);
   assert.equal(g.validatedGlossaryReuseRows,expected.baselineReuseRows);
   assert.equal(g.recentContentHits,expected.rawContentMatches);
   assert.equal(g.counts.compositeCalls,g.rows-g.validatedGlossaryReuseRows);
   assert.equal(g.counts.allRawStringTokens,g.counts.genericStringCalls+g.counts.commonContentKeys+g.counts.commonTagKeys+g.counts.shortTagValueShortcuts);
   assert.equal(g.counts.baseline.calls,g.counts.mask.calls);assert.equal(g.counts.mask.calls,g.counts.resetEachString.calls);
   assert.equal(g.counts.baseline.tokenBytes,g.counts.mask.tokenBytes);assert.equal(g.counts.mask.tokenBytes,g.counts.resetEachString.tokenBytes);
   assert.equal(g.counts.mask.quoteReturns,g.counts.mask.calls);
   merge(report.counts,g.counts);
   report.totals.banks+=g.banks.length;report.totals.rows+=g.rows;report.totals.sourceBytes+=g.sourceBytes;
   report.totals.validatedGlossaryReuseRows+=g.validatedGlossaryReuseRows;report.totals.recentContentHits+=g.recentContentHits;
   g.analysis=conclusions(g.counts);await save();
   console.log(JSON.stringify({group:index,rows:g.rows,genericStrings:g.counts.genericStringCalls,actualFresh16:g.counts.mask.fresh16Loads,crossStringHits:g.counts.mask.crossStringCacheHits}));
  }
  assert.deepEqual(report.totals,{banks:53,rows:528299,sourceBytes:171617523,validatedGlossaryReuseRows:54641,recentContentHits:154416});
  assert.equal(report.counts.compositeCalls,473658);assert.equal(report.counts.textNormalizationRows,0);
  report.analysis=conclusions(report.counts);report.complete=true;await save();
  console.log(JSON.stringify({complete:true,totals:report.totals,counts:report.counts,analysis:report.analysis}));
 }catch(error){report.failure={message:error.message,stack:error.stack};await save();throw error;}
}
await main();

