"""Read-only reconciliation of retained source-model results; never run the model."""
from pathlib import Path
import hashlib
import json
import struct
import subprocess
import zipfile

ROOT = Path('/home/agent/manabitan-mask-census-5a86')
REPO = Path('/workspace/scratch/5a86d1e7822a/manabitan')
BASE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
MASK = '2cdcc90241fa19221b7fc4e5d793eb70896c3258'
ORACLE = Path('/home/agent/manabitan-startup-followup-5a86/builds/perf/import-analysis-20261128-5a86/census/jmdict-suffix-production-groups.json')
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(p.read_bytes())


def counters(c):
    assert c['allRawStringTokens'] == sum(c[k] for k in ('genericStringCalls', 'commonContentKeys', 'commonTagKeys', 'shortTagValueShortcuts'))
    assert c['shortTagValueShortcuts'] == c['textNormalizationTriggers'] == c['textNormalizationRows'] == c['normalizationRows'] == 0
    modes = [c[k] for k in ('baseline', 'mask', 'resetEachString')]
    assert all(x['calls'] == x['quoteReturns'] == c['genericStringCalls'] for x in modes)
    for key in ('tokenBytes', 'byteVisits', 'shortEscapes', 'unicodeEscapes', 'scalarPlainSteps'):
        assert len({x[key] for x in modes}) == 1
    assert c['rawStringBytes'] == c['baseline']['tokenBytes'] + c['commonContentKeys'] * 9 + c['commonTagKeys'] * 5
    for x in modes:
        assert x['byteVisits'] == x['quoteReturns'] + x['shortEscapes'] + x['unicodeEscapes'] + x['scalarPlainSteps']
        assert x['word8Loads'] == x['word8Plain'] + x['word8Special']
    assert c['baseline']['iterations'] == c['baseline']['byteVisits']
    for kind in ('mask', 'resetEachString'):
        x = c[kind]
        assert x['iterations'] == x['cacheHits'] + x['fresh16Tests']
        assert x['fresh16Tests'] == x['fresh16Loads'] + x['fallback8Entries']
        assert x['fresh16Loads'] == x['fresh16ZeroMasks'] + x['fresh16SpecialMasks']
        assert x['cacheHits'] == x['crossStringCacheHits'] + x['sameStringCacheHits'] == x['cachedZeroMasks'] + x['cachedSpecialMasks']
        assert x['cacheHits'] == x['cacheHitWith16ByteRoom'] + x['cacheHitNearBankEnd']
        assert x['iterations'] == x['byteVisits'] + x['fresh16ZeroMasks'] + x['cachedZeroMasks']
        assert x['rangeLowerChecks'] == x['rangeUpperChecks'] == x['iterations']
        assert x['callsEntirelyFromPriorWindow'] <= x['callsWithEntryCacheHit'] <= x['calls']
        assert x['fallback8Entries'] == x['word8Loads'] == 0
    assert c['resetEachString']['crossStringCacheHits'] == c['resetEachString']['callsWithEntryCacheHit'] == c['resetEachString']['callsEntirelyFromPriorWindow'] == 0


def analysis(c):
    m = c['mask']
    return {
        'baselineWord8Classifications': c['baseline']['word8Loads'],
        'baselineClassifiedByteSum': c['baseline']['word8Loads'] * 8,
        'actualFresh16Classifications': m['fresh16Loads'],
        'actualClassifiedByteSum': m['fresh16Loads'] * 16 + m['word8Loads'] * 8,
        'resetEachStringFresh16Classifications': c['resetEachString']['fresh16Loads'],
        'crossStringPersistenceFresh16Difference': c['resetEachString']['fresh16Loads'] - m['fresh16Loads'],
        'cacheHitRatio': m['cacheHits'] / m['iterations'],
        'crossStringHitRatio': m['crossStringCacheHits'] / m['iterations'],
        'fullyCoveredByPriorWindowCalls': m['callsEntirelyFromPriorWindow'],
        'zeroMaskFreshClassifications': m['fresh16ZeroMasks'],
        'sourceWindowFieldInitializations': c['compositeCalls'] * 3,
        'sourceWindowFieldAssignments': m['fresh16Loads'] * 3,
        'sourceZeroMaskFieldAssignments': m['fresh16ZeroMasks'] * 3,
        'sourceRangeComparisons': m['rangeLowerChecks'] + m['rangeUpperChecks'],
        'sourceMaskShifts': m['cacheHits'],
        'sourceCtzOperations': m['cachedSpecialMasks'] + m['fresh16SpecialMasks'] + m['word8Special'],
    }


def merged(values, key=None):
    if isinstance(values[0], dict):
        return {k: merged([x[k] for x in values], k) for k in values[0]}
    assert all(type(x) is int for x in values)
    return max(values) if key == 'maxContainerDepth' else sum(values)


def main():
    assert __debug__
    raw = (ROOT / 'result/report.json').read_bytes()
    assert sha(raw) == '0e72c3481928dd8213b62814cfd4ef3e0cb5a6754030bc6ce6f18ffa50cf7a39'
    report = json.loads(raw)
    plan, receipt, history = [read(ROOT / x) for x in ('plan.json', 'census-receipt.json', 'preflight-history.json')]
    runner = (ROOT / 'scan-window-census.mjs').read_bytes()
    assert sha(runner) == plan['runnerSha256'] == report['provenance']['runnerSha256'] == history['correctedRunnerSha256'] == 'f4592074cb5e16a17e8ef206002beb4b5868d1d10ecec8944ecf21a6b358f02a'
    assert sha((ROOT / 'preflight-1-runner.mjs').read_bytes()) == history['originalRunnerSha256']
    assert sha((ROOT / 'conditional-call-path-review.json').read_bytes()) == plan['pathAuditSha256']
    assert receipt['exitCode'] == 0 and receipt['signal'] is None and sha((ROOT / 'census.log').read_bytes()) == receipt['logSha256']
    assert report['complete'] is True and report['failure'] is None and report['noWasmInstantiation'] is True and report['noPerformanceObservation'] is True
    assert report['selfTests'] == {'validGlossaries': 9, 'scannerBoundaryCases': 5940, 'noCorpus': True, 'noWasmInstantiation': True}
    logs = [json.loads(line) for line in (ROOT / 'census.log').read_text().splitlines()]
    assert len(logs) == 13 and [row['group'] for row in logs[:-1]] == list(range(12))
    assert logs[-1] == {k: report[k] for k in ('complete', 'totals', 'counts', 'analysis')}
    oracle_raw = ORACLE.read_bytes(); assert sha(oracle_raw) == report['provenance']['existingExactGroupCensusSha256']
    oracle = json.loads(oracle_raw)
    assert len(report['groups']) == len(oracle['groups']) == plan['expected']['groups'] == 12
    assert [len(g['banks']) for g in report['groups']] == [5, 4, 4, 4, 5, 5, 4, 5, 4, 4, 4, 5]
    rows = []
    for index, (group, old) in enumerate(zip(report['groups'], oracle['groups'])):
        assert group['index'] == index == old['groupIndex']
        assert (group['banks'][0]['name'], group['banks'][-1]['name']) == (old['firstBank'], old['lastBank'])
        assert group['rows'] == old['rows'] == sum(b['rows'] for b in group['banks'])
        assert group['sourceBytes'] == old['sourceBytes'] == sum(b['bytes'] for b in group['banks'])
        assert group['validatedGlossaryReuseRows'] == old['baselineReuseRows']
        assert group['recentContentHits'] == old['rawContentMatches']
        assert group['counts']['compositeCalls'] == group['rows'] - group['validatedGlossaryReuseRows']
        for bank, previous in zip(group['banks'], old['bankInputs']):
            assert {k: bank[k] for k in ('rows', 'sha256', 'crc32')} == {k: previous[k] for k in ('rows', 'sha256', 'crc32')}
            assert bank['name'] == previous['filename'] and bank['bytes'] == previous['sourceBytes']
        counters(group['counts'])
        assert analysis(group['counts']) == {k: v for k, v in group['analysis'].items() if k not in ('scope', 'bytecodeCaveat')}
        assert logs[index] == {'group': index, 'rows': group['rows'], 'genericStrings': group['counts']['genericStringCalls'], 'actualFresh16': group['counts']['mask']['fresh16Loads'], 'crossStringHits': group['counts']['mask']['crossStringCacheHits']}
        rows.append({k: group[k] for k in ('index', 'rows', 'sourceBytes', 'validatedGlossaryReuseRows', 'recentContentHits')})
    assert report['counts'] == merged([g['counts'] for g in report['groups']])
    counters(report['counts'])
    assert analysis(report['counts']) == {k: v for k, v in report['analysis'].items() if k not in ('scope', 'bytecodeCaveat')}
    assert report['totals'] == {'banks': 53, 'rows': 528299, 'sourceBytes': 171617523, 'validatedGlossaryReuseRows': 54641, 'recentContentHits': 154416}
    assert report['totals']['rows'] - report['totals']['validatedGlossaryReuseRows'] == report['counts']['compositeCalls'] == 473658
    for field in ('rows', 'sourceBytes', 'validatedGlossaryReuseRows', 'recentContentHits'):
        assert sum(g[field] for g in report['groups']) == report['totals'][field]
    source_records = {}
    for label, commit in (('baseline', BASE), ('mask', MASK)):
        for extension, relative in (('c', 'ext/js/dictionary/wasm/term-bank-parser.c'), ('wasm', 'dev/data/dictionary-wasm/term-bank-parser.wasm')):
            data = (ROOT / (label + '.' + extension)).read_bytes()
            assert data == subprocess.check_output(['git', 'show', commit + ':' + relative], cwd=REPO)
            source_records[label + '.' + extension] = {'bytes': len(data), 'sha256': sha(data)}
    fixture = REPO / 'builds/e2e-dictionary-cache/JMdict.zip'
    digest = hashlib.sha256()
    with fixture.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''): digest.update(block)
    assert fixture.stat().st_size == report['provenance']['fixtureBytes'] == 15645766
    assert digest.hexdigest() == report['provenance']['fixtureSha256']
    banks = [b for g in report['groups'] for b in g['banks']]
    assert [b['name'] for b in banks] == [f'term_bank_{i}.json' for i in range(1, 54)]
    with zipfile.ZipFile(fixture) as archive, fixture.open('rb') as stream:
        for bank in banks:
            entry = archive.getinfo(bank['name'])
            assert entry.file_size == bank['bytes'] and entry.CRC == bank['crc32'] and entry.compress_type == 8
            stream.seek(entry.header_offset); header = stream.read(30)
            assert header[:4] == b'PK\x03\x04'
            name_size, extra_size = struct.unpack_from('<HH', header, 26)
            assert stream.read(name_size).decode() == bank['name']
            stream.seek(entry.header_offset + 30 + name_size + extra_size)
            assert sha(stream.read(entry.compress_size)) == bank['compressedSha256']
    bytecode = read(ROOT / 'mask-bytecode.json')
    lines = [line for chunk in bytecode['chunks'] for line in chunk['lines']]
    assert bytecode['sha256'] == source_records['mask.wasm']['sha256']
    assert len(lines) == bytecode['totalNumberOfLines'] == 32653
    assert (ROOT / 'mask.wat').read_text() == '\n'.join(lines) + '\n'
    positions = [i for i, line in enumerate(lines) if line.strip() == 'i8x16.bitmask']
    assert len(positions) == 1
    window = '\n'.join(lines[positions[0] - 50:positions[0] + 24])
    assert all(x in window for x in ('local.set $var24', 'local.tee $var23', 'local.set $var25', 'local.get $var23', 'local.get $var24', 'local.get $var25'))
    assert '.store' not in window
    result = {
        'status': 'PASS_READ_ONLY_RECONCILIATION', 'noModelRerun': True, 'noWasmCompilationOrInstantiation': True, 'noTimingAcquisition': True,
        'reportSha256': sha(raw), 'runnerSha256': sha(runner), 'planSha256': sha((ROOT / 'plan.json').read_bytes()),
        'sourceRecords': source_records, 'groups': rows, 'totals': report['totals'], 'counterFamiliesReconciled': ['all generic tokens and shortcuts', 'quote/escape endpoints', 'cache-hit and fresh-window classifications', 'all twelve group sums', 'all derived analysis arithmetic'],
        'rawArchiveAndCompressedBankHashesChecked': 53,
        'endpointEvidence': 'The frozen runner asserts every generic-string endpoint against an independently located quote endpoint in all three models. Successful retained receipt/log and complete report bind that execution. This review rechecks aggregate identities and inputs, and does not reexecute those per-string assertions.',
        'sourceReview': 'Full logical bank bounds, one cache per composite, exact literal key/tag shortcuts, raw duplicate/escaped type keys, four-row admission/budget state and zero text-normalization gate match the inspected C call paths.',
        'bytecodeReview': {'bitmaskLine': positions[0] + 1, 'cacheLocals': {'special': '$var23', 'end': '$var24', 'start': '$var25'}, 'inspectedRegionHasLinearMemoryStore': False},
        'scope': 'Source-operation model only. Classified-byte sums are not physical memory traffic; C field assignments are not native stores or instruction counts. Per-string reset is a counterfactual model, not a production candidate. No import latency, peak-memory, or new correctness qualification follows.',
        'followup': 'Zero-mask store-elision remains held; this review makes no product proposal.',
    }
    output = ROOT / 'storage-independent-review.json'; output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'path': str(output), 'bytes': output.stat().st_size, 'sha256': sha(output.read_bytes())}))


if __name__ == '__main__':
    main()
