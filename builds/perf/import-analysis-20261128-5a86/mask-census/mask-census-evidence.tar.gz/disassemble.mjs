import inspector from 'node:inspector';
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root='/home/agent/manabitan-mask-census-5a86';
await mkdir(root,{recursive:true});
const input=process.argv[2];
const bytes=await readFile(input);
const sha256=createHash('sha256').update(bytes).digest('hex');
const session=new inspector.Session();
session.connect();
const post=(method,params={})=>new Promise((resolve,reject)=>session.post(method,params,(error,result)=>error?reject(error):resolve(result)));
const modules=[];
session.on('Debugger.scriptParsed',({params})=>{if(params.scriptLanguage==='WebAssembly'||params.url.startsWith('wasm:'))modules.push(params)});
try{
 await post('Debugger.enable');
 await WebAssembly.compile(bytes);
 if(modules.length!==1)throw Error('Expected one WebAssembly script; found '+modules.length);
 const initial=await post('Debugger.disassembleWasmModule',{scriptId:modules[0].scriptId});
 const chunks=[initial.chunk];
 if(initial.streamId){
   while(chunks.reduce((sum,c)=>sum+c.lines.length,0)<initial.totalNumberOfLines){
     const next=await post('Debugger.nextWasmDisassemblyChunk',{streamId:initial.streamId});
     chunks.push(next.chunk); if(!next.chunk.lines.length)break;
   }
 }
 const report={kind:'Exact WebAssembly bytecode formatting only; no module instantiation or exported function invocation',input,sha256,node:process.version,api:'Debugger.disassembleWasmModule',script:modules[0],totalNumberOfLines:initial.totalNumberOfLines,functionBodyOffsets:initial.functionBodyOffsets,chunks};
 const output=root+'/mask-bytecode.json';
 await writeFile(output,JSON.stringify(report,null,2)+'\n');
 await writeFile(root+'/mask.wat',chunks.flatMap(c=>c.lines).join('\n')+'\n');
 console.log(JSON.stringify({output,sha256,lines:chunks.reduce((sum,c)=>sum+c.lines.length,0),functions:initial.functionBodyOffsets.length/2}));
}finally{session.disconnect()}

