(module
  (memory $memory (;0;) (export "memory") 2 65536 shared)
  (global $global0 (mut i32) (i32.const 104256))
  (global $global1 (mut i32) (i32.const 0))
  (start $func0)
  (func $func0
    block $label2
      block $label1
        block $label0
          i32.const 38716
          i32.const 0
          i32.const 1
          i32.atomic.rmw.cmpxchg
          br_table $label0 $label1 $label2
        end $label0
        i32.const 1024
        i32.const 0
        i32.const 1520
        memory.init 0
        i32.const 2544
        i32.const 0
        i32.const 36172
        memory.fill
        i32.const 38716
        i32.const 2
        i32.atomic.store
        i32.const 38716
        i32.const -1
        memory.atomic.notify
        drop
        br $label2
      end $label1
      i32.const 38716
      i32.const 1
      i64.const -1
      memory.atomic.wait32
      drop
    end $label2
    data.drop 0
  )
  (func $inflate_and_join_term_banks (;1;) (export "inflate_and_join_term_banks") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (param $var8 i32) (param $var9 i32) (param $var10 i32) (param $var11 i32) (result i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i32)
    i32.const -1
    local.set $var12
    block $label0
      local.get $var7
      i32.eqz
      br_if $label0
      local.get $var9
      i32.const 2
      i32.lt_u
      br_if $label0
      block $label1
        local.get $var10
        br_if $label1
        local.get $var11
        br_if $label0
      end $label1
      block $label2
        local.get $var10
        br_if $label2
        local.get $var8
        i32.const 91
        i32.store8
      end $label2
      local.get $var10
      i32.eqz
      local.set $var13
      local.get $var8
      i32.const 1
      i32.add
      local.set $var14
      i32.const 0
      local.set $var15
      i32.const 0
      local.set $var16
      loop $label22
        i32.const -1
        local.set $var12
        local.get $var1
        local.get $var2
        local.get $var16
        i32.const 2
        i32.shl
        local.tee $var17
        i32.add
        i32.load
        local.tee $var18
        i32.lt_u
        br_if $label0
        local.get $var3
        local.get $var17
        i32.add
        i32.load
        local.tee $var19
        local.get $var1
        local.get $var18
        i32.sub
        i32.gt_u
        br_if $label0
        local.get $var4
        local.get $var17
        i32.add
        i32.load
        local.tee $var20
        local.get $var9
        local.get $var13
        i32.sub
        i32.gt_u
        br_if $label0
        local.get $var8
        local.get $var13
        i32.add
        local.set $var21
        i32.const -1
        local.set $var12
        block $label6
          block $label4
            block $label3
              local.get $var5
              local.get $var17
              i32.add
              i32.load
              br_table $label3 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label4 $label0
            end $label3
            block $label5
              local.get $var19
              local.get $var20
              i32.eq
              br_if $label5
              i32.const -3
              return
            end $label5
            local.get $var19
            i32.eqz
            br_if $label6
            local.get $var21
            local.get $var0
            local.get $var18
            i32.add
            local.get $var19
            memory.copy
            br $label6
          end $label4
          local.get $var0
          local.get $var18
          i32.add
          local.get $var19
          local.get $var21
          local.get $var20
          call $func50
          local.tee $var12
          br_if $label0
        end $label6
        block $label7
          local.get $var11
          br_if $label7
          local.get $var21
          local.get $var20
          call $func2
          local.get $var6
          local.get $var17
          i32.add
          i32.load
          i32.eq
          br_if $label7
          i32.const -4
          return
        end $label7
        local.get $var20
        local.set $var17
        local.get $var20
        local.set $var18
        block $label8
          local.get $var20
          i32.eqz
          br_if $label8
          i32.const 0
          local.set $var17
          block $label9
            loop $label10
              local.get $var21
              local.get $var17
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var18
              i32.const 23
              i32.gt_u
              br_if $label9
              i32.const 1
              local.get $var18
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label9
              local.get $var20
              local.get $var17
              i32.const 1
              i32.add
              local.tee $var17
              i32.ne
              br_if $label10
            end $label10
            local.get $var20
            local.set $var17
            local.get $var20
            local.set $var18
            br $label8
          end $label9
          block $label11
            local.get $var20
            local.get $var17
            i32.gt_u
            br_if $label11
            local.get $var20
            local.set $var18
            br $label8
          end $label11
          local.get $var21
          i32.const -1
          i32.add
          local.set $var19
          local.get $var20
          local.set $var18
          loop $label12
            local.get $var19
            local.get $var18
            i32.add
            i32.load8_u
            i32.const -9
            i32.add
            local.tee $var12
            i32.const 23
            i32.gt_u
            br_if $label8
            i32.const 1
            local.get $var12
            i32.shl
            i32.const 8388627
            i32.and
            i32.eqz
            br_if $label8
            local.get $var18
            i32.const -1
            i32.add
            local.tee $var18
            local.get $var17
            i32.gt_u
            br_if $label12
          end $label12
          local.get $var17
          local.set $var18
        end $label8
        i32.const -5
        local.set $var12
        local.get $var18
        local.get $var17
        i32.sub
        i32.const 2
        i32.lt_u
        br_if $label0
        local.get $var21
        local.get $var17
        i32.add
        i32.load8_u
        i32.const 91
        i32.ne
        br_if $label0
        local.get $var21
        local.get $var18
        i32.add
        i32.const -1
        i32.add
        i32.load8_u
        i32.const 93
        i32.ne
        br_if $label0
        block $label13
          local.get $var10
          br_if $label13
          block $label16
            block $label14
              local.get $var17
              i32.const 1
              i32.add
              local.tee $var12
              local.get $var18
              i32.const -1
              i32.add
              local.tee $var20
              i32.ge_u
              br_if $label14
              local.get $var14
              local.get $var13
              i32.add
              local.set $var12
              local.get $var18
              i32.const -2
              i32.add
              local.set $var19
              block $label15
                loop $label17
                  local.get $var12
                  local.get $var17
                  i32.add
                  i32.load8_u
                  i32.const -9
                  i32.add
                  local.tee $var18
                  i32.const 23
                  i32.gt_u
                  br_if $label15
                  i32.const 1
                  local.get $var18
                  i32.shl
                  i32.const 8388627
                  i32.and
                  i32.eqz
                  br_if $label15
                  local.get $var19
                  local.get $var17
                  i32.const 1
                  i32.add
                  local.tee $var17
                  i32.eq
                  br_if $label16
                  br $label17
                end $label17
              end $label15
              local.get $var17
              i32.const 1
              i32.add
              local.set $var12
            end $label14
            block $label18
              local.get $var20
              local.get $var12
              i32.le_u
              br_if $label18
              loop $label19
                local.get $var21
                local.get $var20
                i32.add
                i32.const -1
                i32.add
                i32.load8_u
                i32.const -9
                i32.add
                local.tee $var17
                i32.const 23
                i32.gt_u
                br_if $label18
                i32.const 1
                local.get $var17
                i32.shl
                i32.const 8388627
                i32.and
                i32.eqz
                br_if $label18
                local.get $var20
                i32.const -1
                i32.add
                local.tee $var20
                local.get $var12
                i32.gt_u
                br_if $label19
                br $label16
              end $label19
            end $label18
            local.get $var20
            local.get $var12
            i32.eq
            br_if $label16
            block $label20
              local.get $var15
              i32.eqz
              br_if $label20
              local.get $var21
              i32.const 44
              i32.store8
              local.get $var13
              i32.const 1
              i32.add
              local.set $var13
            end $label20
            local.get $var20
            local.get $var12
            i32.sub
            local.set $var17
            block $label21
              local.get $var8
              local.get $var13
              i32.add
              local.tee $var18
              local.get $var21
              local.get $var12
              i32.add
              local.tee $var20
              i32.eq
              br_if $label21
              local.get $var17
              i32.eqz
              br_if $label21
              local.get $var18
              local.get $var20
              local.get $var17
              memory.copy
            end $label21
            local.get $var15
            i32.const 1
            i32.add
            local.set $var15
            local.get $var13
            local.get $var17
            i32.add
            local.set $var13
          end $label16
          local.get $var16
          i32.const 1
          i32.add
          local.tee $var16
          local.get $var7
          i32.ne
          br_if $label22
          i32.const -1
          local.set $var12
          local.get $var13
          local.get $var9
          i32.ge_u
          br_if $label0
          local.get $var8
          local.get $var13
          i32.add
          i32.const 93
          i32.store8
          local.get $var13
          i32.const 1
          i32.add
          local.set $var12
          br $label0
        end $label13
        local.get $var10
        local.get $var16
        i32.const 3
        i32.shl
        i32.add
        local.tee $var17
        local.get $var20
        i32.store offset=4
        local.get $var17
        local.get $var13
        i32.store
        local.get $var20
        local.get $var13
        i32.add
        local.tee $var13
        local.set $var12
        local.get $var16
        i32.const 1
        i32.add
        local.tee $var16
        local.get $var7
        i32.ne
        br_if $label22
      end $label22
    end $label0
    local.get $var12
  )
  (func $func2 (param $var0 i32) (param $var1 i32) (result i32)
    (local $var2 v128)
    (local $var3 i32)
    (local $var4 v128)
    (local $var5 v128)
    (local $var6 v128)
    (local $var7 v128)
    (local $var8 v128)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i64)
    block $label0
      i32.const 0
      i32.load8_u offset=2556
      br_if $label0
      v128.const i32x4 0x00000000 0x00000001 0x00000002 0x00000003
      local.set $var2
      i32.const -1024
      local.set $var3
      loop $label1
        local.get $var3
        i32.const 3584
        i32.add
        local.get $var2
        v128.const i32x4 0x00000002 0x00000002 0x00000002 0x00000002
        v128.and
        v128.const i32x4 0x00000000 0x00000000 0x00000000 0x00000000
        local.tee $var4
        i32x4.ne
        v128.const i32x4 0xEDB88320 0xEDB88320 0xEDB88320 0xEDB88320
        local.tee $var5
        v128.and
        local.get $var2
        v128.const i32x4 0x00000001 0x00000001 0x00000001 0x00000001
        v128.and
        local.get $var4
        i32x4.ne
        local.get $var5
        v128.and
        local.get $var2
        i32.const 1
        i32x4.shr_u
        v128.xor
        local.tee $var6
        i32.const 1
        i32x4.shr_u
        v128.xor
        local.tee $var7
        v128.const i32x4 0x00000020 0x00000020 0x00000020 0x00000020
        local.tee $var8
        v128.and
        local.get $var4
        i32x4.ne
        local.get $var5
        v128.and
        local.get $var6
        local.get $var8
        v128.and
        local.get $var4
        i32x4.ne
        v128.const i32x4 0x76DC4190 0x76DC4190 0x76DC4190 0x76DC4190
        v128.and
        local.get $var2
        local.get $var8
        v128.and
        local.get $var4
        i32x4.ne
        v128.const i32x4 0x3B6E20C8 0x3B6E20C8 0x3B6E20C8 0x3B6E20C8
        v128.and
        local.get $var2
        v128.const i32x4 0x00000010 0x00000010 0x00000010 0x00000010
        v128.and
        local.get $var4
        i32x4.ne
        v128.const i32x4 0x1DB71064 0x1DB71064 0x1DB71064 0x1DB71064
        v128.and
        local.get $var2
        v128.const i32x4 0x00000008 0x00000008 0x00000008 0x00000008
        v128.and
        local.get $var4
        i32x4.ne
        v128.const i32x4 0x0EDB8832 0x0EDB8832 0x0EDB8832 0x0EDB8832
        v128.and
        local.get $var2
        v128.const i32x4 0x00000004 0x00000004 0x00000004 0x00000004
        local.tee $var5
        v128.and
        local.get $var4
        i32x4.ne
        v128.const i32x4 0x076DC419 0x076DC419 0x076DC419 0x076DC419
        v128.and
        local.get $var7
        i32.const 6
        i32x4.shr_u
        v128.xor
        v128.xor
        v128.xor
        v128.xor
        v128.xor
        v128.xor
        v128.store
        local.get $var2
        local.get $var5
        i32x4.add
        local.set $var2
        local.get $var3
        i32.const 16
        i32.add
        local.tee $var3
        br_if $label1
      end $label1
      i32.const -1024
      local.set $var3
      loop $label2
        local.get $var3
        i32.const 4608
        i32.add
        local.get $var3
        i32.const 3584
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 4612
        i32.add
        local.get $var3
        i32.const 3588
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label2
      end $label2
      i32.const -1024
      local.set $var3
      loop $label3
        local.get $var3
        i32.const 5632
        i32.add
        local.get $var3
        i32.const 4608
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 5636
        i32.add
        local.get $var3
        i32.const 4612
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label3
      end $label3
      i32.const -1024
      local.set $var3
      loop $label4
        local.get $var3
        i32.const 6656
        i32.add
        local.get $var3
        i32.const 5632
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 6660
        i32.add
        local.get $var3
        i32.const 5636
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label4
      end $label4
      i32.const -1024
      local.set $var3
      loop $label5
        local.get $var3
        i32.const 7680
        i32.add
        local.get $var3
        i32.const 6656
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 7684
        i32.add
        local.get $var3
        i32.const 6660
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label5
      end $label5
      i32.const -1024
      local.set $var3
      loop $label6
        local.get $var3
        i32.const 8704
        i32.add
        local.get $var3
        i32.const 7680
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8708
        i32.add
        local.get $var3
        i32.const 7684
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label6
      end $label6
      i32.const -1024
      local.set $var3
      loop $label7
        local.get $var3
        i32.const 9728
        i32.add
        local.get $var3
        i32.const 8704
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 9732
        i32.add
        local.get $var3
        i32.const 8708
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label7
      end $label7
      i32.const -1024
      local.set $var3
      loop $label8
        local.get $var3
        i32.const 10752
        i32.add
        local.get $var3
        i32.const 9728
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 10756
        i32.add
        local.get $var3
        i32.const 9732
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label8
      end $label8
      i32.const -1024
      local.set $var3
      loop $label9
        local.get $var3
        i32.const 11776
        i32.add
        local.get $var3
        i32.const 10752
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 11780
        i32.add
        local.get $var3
        i32.const 10756
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label9
      end $label9
      i32.const -1024
      local.set $var3
      loop $label10
        local.get $var3
        i32.const 12800
        i32.add
        local.get $var3
        i32.const 11776
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 12804
        i32.add
        local.get $var3
        i32.const 11780
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label10
      end $label10
      i32.const -1024
      local.set $var3
      loop $label11
        local.get $var3
        i32.const 13824
        i32.add
        local.get $var3
        i32.const 12800
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 13828
        i32.add
        local.get $var3
        i32.const 12804
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label11
      end $label11
      i32.const -1024
      local.set $var3
      loop $label12
        local.get $var3
        i32.const 14848
        i32.add
        local.get $var3
        i32.const 13824
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 14852
        i32.add
        local.get $var3
        i32.const 13828
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label12
      end $label12
      i32.const -1024
      local.set $var3
      loop $label13
        local.get $var3
        i32.const 15872
        i32.add
        local.get $var3
        i32.const 14848
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 15876
        i32.add
        local.get $var3
        i32.const 14852
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label13
      end $label13
      i32.const -1024
      local.set $var3
      loop $label14
        local.get $var3
        i32.const 16896
        i32.add
        local.get $var3
        i32.const 15872
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 16900
        i32.add
        local.get $var3
        i32.const 15876
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label14
      end $label14
      i32.const -1024
      local.set $var3
      loop $label15
        local.get $var3
        i32.const 17920
        i32.add
        local.get $var3
        i32.const 16896
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 17924
        i32.add
        local.get $var3
        i32.const 16900
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label15
      end $label15
      i32.const -1024
      local.set $var3
      loop $label16
        local.get $var3
        i32.const 18944
        i32.add
        local.get $var3
        i32.const 17920
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 18948
        i32.add
        local.get $var3
        i32.const 17924
        i32.add
        i32.load
        local.tee $var9
        i32.const 8
        i32.shr_u
        local.get $var9
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        i32.xor
        i32.store
        local.get $var3
        i32.const 8
        i32.add
        local.tee $var3
        br_if $label16
      end $label16
      i32.const 0
      i32.const 1
      i32.store8 offset=2556
    end $label0
    block $label40
      block $label19
        block $label21
          block $label17
            local.get $var1
            i32.const 262143
            i32.gt_u
            br_if $label17
            block $label18
              local.get $var1
              i32.const 16
              i32.ge_u
              br_if $label18
              i32.const 0
              local.set $var9
              i32.const -1
              local.set $var3
              br $label19
            end $label18
            i32.const -1
            local.set $var3
            local.get $var1
            local.set $var10
            local.get $var0
            local.set $var9
            loop $label20
              local.get $var9
              i32.load align=1
              local.get $var3
              i32.xor
              local.tee $var3
              i32.const 6
              i32.shr_u
              i32.const 1020
              i32.and
              i32.load offset=16896
              local.get $var3
              i32.const 255
              i32.and
              i32.const 2
              i32.shl
              i32.load offset=17920
              i32.xor
              local.get $var3
              i32.const 14
              i32.shr_u
              i32.const 1020
              i32.and
              i32.load offset=15872
              i32.xor
              local.get $var3
              i32.const 22
              i32.shr_u
              i32.const 1020
              i32.and
              i32.load offset=14848
              i32.xor
              local.get $var9
              i32.const 4
              i32.add
              i32.load align=1
              local.tee $var3
              i32.const 255
              i32.and
              i32.const 2
              i32.shl
              i32.load offset=13824
              i32.xor
              local.get $var3
              i32.const 6
              i32.shr_u
              i32.const 1020
              i32.and
              i32.load offset=12800
              i32.xor
              local.get $var3
              i32.const 14
              i32.shr_u
              i32.const 1020
              i32.and
              i32.load offset=11776
              i32.xor
              local.get $var3
              i32.const 22
              i32.shr_u
              i32.const 1020
              i32.and
              i32.load offset=10752
              i32.xor
              local.get $var9
              i32.const 8
              i32.add
              i32.load align=1
              local.tee $var3
              i32.const 255
              i32.and
              i32.const 2
              i32.shl
              i32.load offset=9728
              i32.xor
              local.get $var3
              i32.const 6
              i32.shr_u
              i32.const 1020
              i32.and
              i32.load offset=8704
              i32.xor
              local.get $var3
              i32.const 14
              i32.shr_u
              i32.const 1020
              i32.and
              i32.load offset=7680
              i32.xor
              local.get $var3
              i32.const 22
              i32.shr_u
              i32.const 1020
              i32.and
              i32.load offset=6656
              i32.xor
              local.get $var9
              i32.const 12
              i32.add
              i32.load align=1
              local.tee $var3
              i32.const 255
              i32.and
              i32.const 2
              i32.shl
              i32.load offset=5632
              i32.xor
              local.get $var3
              i32.const 6
              i32.shr_u
              i32.const 1020
              i32.and
              i32.load offset=4608
              i32.xor
              local.get $var3
              i32.const 14
              i32.shr_u
              i32.const 1020
              i32.and
              i32.load offset=3584
              i32.xor
              local.get $var3
              i32.const 22
              i32.shr_u
              i32.const 1020
              i32.and
              i32.load offset=2560
              i32.xor
              local.set $var3
              local.get $var9
              i32.const 16
              i32.add
              local.set $var9
              local.get $var10
              i32.const -16
              i32.add
              local.tee $var10
              i32.const 15
              i32.gt_u
              br_if $label20
              br $label21
            end $label20
          end $label17
          i32.const 0
          local.set $var10
          block $label22
            i32.const 0
            i32.load8_u offset=18944
            br_if $label22
            loop $label24
              local.get $var10
              i32.const 2
              i32.shl
              local.tee $var11
              i32.load offset=2560
              local.set $var3
              i32.const 56
              local.set $var9
              loop $label23
                local.get $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.set $var3
                local.get $var9
                i32.const -4
                i32.add
                local.tee $var9
                br_if $label23
              end $label23
              local.get $var11
              local.get $var3
              i32.store offset=18960
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              i32.const 256
              i32.ne
              br_if $label24
            end $label24
            i32.const 0
            local.set $var10
            loop $label26
              local.get $var10
              i32.const 2
              i32.shl
              local.tee $var11
              i32.load offset=3584
              local.set $var3
              i32.const 56
              local.set $var9
              loop $label25
                local.get $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.set $var3
                local.get $var9
                i32.const -4
                i32.add
                local.tee $var9
                br_if $label25
              end $label25
              local.get $var11
              local.get $var3
              i32.store offset=19984
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              i32.const 256
              i32.ne
              br_if $label26
            end $label26
            i32.const 0
            local.set $var10
            loop $label28
              local.get $var10
              i32.const 2
              i32.shl
              local.tee $var11
              i32.load offset=4608
              local.set $var3
              i32.const 56
              local.set $var9
              loop $label27
                local.get $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.set $var3
                local.get $var9
                i32.const -4
                i32.add
                local.tee $var9
                br_if $label27
              end $label27
              local.get $var11
              local.get $var3
              i32.store offset=21008
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              i32.const 256
              i32.ne
              br_if $label28
            end $label28
            i32.const 0
            local.set $var10
            loop $label30
              local.get $var10
              i32.const 2
              i32.shl
              local.tee $var11
              i32.load offset=5632
              local.set $var3
              i32.const 56
              local.set $var9
              loop $label29
                local.get $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.set $var3
                local.get $var9
                i32.const -4
                i32.add
                local.tee $var9
                br_if $label29
              end $label29
              local.get $var11
              local.get $var3
              i32.store offset=22032
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              i32.const 256
              i32.ne
              br_if $label30
            end $label30
            i32.const 0
            local.set $var10
            loop $label32
              local.get $var10
              i32.const 2
              i32.shl
              local.tee $var11
              i32.load offset=6656
              local.set $var3
              i32.const 56
              local.set $var9
              loop $label31
                local.get $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.set $var3
                local.get $var9
                i32.const -4
                i32.add
                local.tee $var9
                br_if $label31
              end $label31
              local.get $var11
              local.get $var3
              i32.store offset=23056
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              i32.const 256
              i32.ne
              br_if $label32
            end $label32
            i32.const 0
            local.set $var10
            loop $label34
              local.get $var10
              i32.const 2
              i32.shl
              local.tee $var11
              i32.load offset=7680
              local.set $var3
              i32.const 56
              local.set $var9
              loop $label33
                local.get $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.set $var3
                local.get $var9
                i32.const -4
                i32.add
                local.tee $var9
                br_if $label33
              end $label33
              local.get $var11
              local.get $var3
              i32.store offset=24080
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              i32.const 256
              i32.ne
              br_if $label34
            end $label34
            i32.const 0
            local.set $var10
            loop $label36
              local.get $var10
              i32.const 2
              i32.shl
              local.tee $var11
              i32.load offset=8704
              local.set $var3
              i32.const 56
              local.set $var9
              loop $label35
                local.get $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.set $var3
                local.get $var9
                i32.const -4
                i32.add
                local.tee $var9
                br_if $label35
              end $label35
              local.get $var11
              local.get $var3
              i32.store offset=25104
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              i32.const 256
              i32.ne
              br_if $label36
            end $label36
            i32.const 0
            local.set $var10
            loop $label38
              local.get $var10
              i32.const 2
              i32.shl
              local.tee $var11
              i32.load offset=9728
              local.set $var3
              i32.const 56
              local.set $var9
              loop $label37
                local.get $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.tee $var3
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.load offset=2560
                local.get $var3
                i32.const 8
                i32.shr_u
                i32.xor
                local.set $var3
                local.get $var9
                i32.const -4
                i32.add
                local.tee $var9
                br_if $label37
              end $label37
              local.get $var11
              local.get $var3
              i32.store offset=26128
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              i32.const 256
              i32.ne
              br_if $label38
            end $label38
            i32.const 0
            i32.const 1
            i32.store8 offset=18944
          end $label22
          local.get $var1
          i32.const -64
          i32.and
          local.tee $var12
          i32.const -64
          i32.add
          local.set $var13
          i32.const -1
          local.set $var11
          i32.const 0
          local.set $var14
          i32.const 0
          local.set $var15
          i32.const 0
          local.set $var16
          i32.const 0
          local.set $var17
          i32.const 0
          local.set $var18
          i32.const 0
          local.set $var19
          i32.const 0
          local.set $var20
          i32.const 0
          local.set $var10
          loop $label39
            local.get $var11
            local.get $var0
            local.get $var10
            i32.add
            local.tee $var3
            i64.load align=1
            local.tee $var21
            i32.wrap_i64
            i32.xor
            local.tee $var9
            i32.const 6
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=25104
            local.get $var9
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=26128
            i32.xor
            local.get $var9
            i32.const 14
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=24080
            i32.xor
            local.get $var9
            i32.const 22
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=23056
            i32.xor
            local.get $var21
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=22032
            i32.xor
            local.get $var21
            i64.const 40
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=21008
            i32.xor
            local.get $var21
            i64.const 48
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=19984
            i32.xor
            local.get $var21
            i64.const 56
            i64.shr_u
            i32.wrap_i64
            i32.const 2
            i32.shl
            i32.load offset=18960
            i32.xor
            local.set $var11
            local.get $var14
            local.get $var3
            i32.const 56
            i32.add
            i64.load align=1
            local.tee $var21
            i32.wrap_i64
            i32.xor
            local.tee $var9
            i32.const 6
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=25104
            local.get $var9
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=26128
            i32.xor
            local.get $var9
            i32.const 14
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=24080
            i32.xor
            local.get $var9
            i32.const 22
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=23056
            i32.xor
            local.get $var21
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=22032
            i32.xor
            local.get $var21
            i64.const 40
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=21008
            i32.xor
            local.get $var21
            i64.const 48
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=19984
            i32.xor
            local.get $var21
            i64.const 56
            i64.shr_u
            i32.wrap_i64
            i32.const 2
            i32.shl
            i32.load offset=18960
            i32.xor
            local.set $var14
            local.get $var15
            local.get $var3
            i32.const 48
            i32.add
            i64.load align=1
            local.tee $var21
            i32.wrap_i64
            i32.xor
            local.tee $var9
            i32.const 6
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=25104
            local.get $var9
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=26128
            i32.xor
            local.get $var9
            i32.const 14
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=24080
            i32.xor
            local.get $var9
            i32.const 22
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=23056
            i32.xor
            local.get $var21
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=22032
            i32.xor
            local.get $var21
            i64.const 40
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=21008
            i32.xor
            local.get $var21
            i64.const 48
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=19984
            i32.xor
            local.get $var21
            i64.const 56
            i64.shr_u
            i32.wrap_i64
            i32.const 2
            i32.shl
            i32.load offset=18960
            i32.xor
            local.set $var15
            local.get $var16
            local.get $var3
            i32.const 40
            i32.add
            i64.load align=1
            local.tee $var21
            i32.wrap_i64
            i32.xor
            local.tee $var9
            i32.const 6
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=25104
            local.get $var9
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=26128
            i32.xor
            local.get $var9
            i32.const 14
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=24080
            i32.xor
            local.get $var9
            i32.const 22
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=23056
            i32.xor
            local.get $var21
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=22032
            i32.xor
            local.get $var21
            i64.const 40
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=21008
            i32.xor
            local.get $var21
            i64.const 48
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=19984
            i32.xor
            local.get $var21
            i64.const 56
            i64.shr_u
            i32.wrap_i64
            i32.const 2
            i32.shl
            i32.load offset=18960
            i32.xor
            local.set $var16
            local.get $var17
            local.get $var3
            i32.const 32
            i32.add
            i64.load align=1
            local.tee $var21
            i32.wrap_i64
            i32.xor
            local.tee $var9
            i32.const 6
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=25104
            local.get $var9
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=26128
            i32.xor
            local.get $var9
            i32.const 14
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=24080
            i32.xor
            local.get $var9
            i32.const 22
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=23056
            i32.xor
            local.get $var21
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=22032
            i32.xor
            local.get $var21
            i64.const 40
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=21008
            i32.xor
            local.get $var21
            i64.const 48
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=19984
            i32.xor
            local.get $var21
            i64.const 56
            i64.shr_u
            i32.wrap_i64
            i32.const 2
            i32.shl
            i32.load offset=18960
            i32.xor
            local.set $var17
            local.get $var18
            local.get $var3
            i32.const 24
            i32.add
            i64.load align=1
            local.tee $var21
            i32.wrap_i64
            i32.xor
            local.tee $var9
            i32.const 6
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=25104
            local.get $var9
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=26128
            i32.xor
            local.get $var9
            i32.const 14
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=24080
            i32.xor
            local.get $var9
            i32.const 22
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=23056
            i32.xor
            local.get $var21
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=22032
            i32.xor
            local.get $var21
            i64.const 40
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=21008
            i32.xor
            local.get $var21
            i64.const 48
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=19984
            i32.xor
            local.get $var21
            i64.const 56
            i64.shr_u
            i32.wrap_i64
            i32.const 2
            i32.shl
            i32.load offset=18960
            i32.xor
            local.set $var18
            local.get $var19
            local.get $var3
            i32.const 16
            i32.add
            i64.load align=1
            local.tee $var21
            i32.wrap_i64
            i32.xor
            local.tee $var9
            i32.const 6
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=25104
            local.get $var9
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=26128
            i32.xor
            local.get $var9
            i32.const 14
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=24080
            i32.xor
            local.get $var9
            i32.const 22
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=23056
            i32.xor
            local.get $var21
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=22032
            i32.xor
            local.get $var21
            i64.const 40
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=21008
            i32.xor
            local.get $var21
            i64.const 48
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=19984
            i32.xor
            local.get $var21
            i64.const 56
            i64.shr_u
            i32.wrap_i64
            i32.const 2
            i32.shl
            i32.load offset=18960
            i32.xor
            local.set $var19
            local.get $var20
            local.get $var3
            i32.const 8
            i32.add
            i64.load align=1
            local.tee $var21
            i32.wrap_i64
            i32.xor
            local.tee $var3
            i32.const 6
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=25104
            local.get $var3
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=26128
            i32.xor
            local.get $var3
            i32.const 14
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=24080
            i32.xor
            local.get $var3
            i32.const 22
            i32.shr_u
            i32.const 1020
            i32.and
            i32.load offset=23056
            i32.xor
            local.get $var21
            i64.const 32
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=22032
            i32.xor
            local.get $var21
            i64.const 40
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=21008
            i32.xor
            local.get $var21
            i64.const 48
            i64.shr_u
            i32.wrap_i64
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=19984
            i32.xor
            local.get $var21
            i64.const 56
            i64.shr_u
            i32.wrap_i64
            i32.const 2
            i32.shl
            i32.load offset=18960
            i32.xor
            local.set $var20
            local.get $var10
            i32.const 64
            i32.add
            local.tee $var10
            local.get $var13
            i32.lt_u
            br_if $label39
          end $label39
          local.get $var11
          local.get $var0
          local.get $var13
          i32.add
          local.tee $var3
          i64.load align=1
          local.tee $var21
          i32.wrap_i64
          i32.xor
          local.tee $var9
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=9728
          local.get $var9
          i32.const 6
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=8704
          i32.xor
          local.get $var9
          i32.const 14
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=7680
          i32.xor
          local.get $var9
          i32.const 22
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=6656
          i32.xor
          local.get $var21
          i64.const 32
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=5632
          i32.xor
          local.get $var21
          i64.const 40
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=4608
          i32.xor
          local.get $var21
          i64.const 48
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=3584
          i32.xor
          local.get $var21
          i64.const 56
          i64.shr_u
          i32.wrap_i64
          i32.const 2
          i32.shl
          i32.load offset=2560
          i32.xor
          local.get $var3
          i64.load offset=8 align=1
          local.tee $var21
          i32.wrap_i64
          i32.xor
          local.get $var20
          i32.xor
          local.tee $var9
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=9728
          local.get $var9
          i32.const 6
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=8704
          i32.xor
          local.get $var9
          i32.const 14
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=7680
          i32.xor
          local.get $var9
          i32.const 22
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=6656
          i32.xor
          local.get $var21
          i64.const 32
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=5632
          i32.xor
          local.get $var21
          i64.const 40
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=4608
          i32.xor
          local.get $var21
          i64.const 48
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=3584
          i32.xor
          local.get $var21
          i64.const 56
          i64.shr_u
          i32.wrap_i64
          i32.const 2
          i32.shl
          i32.load offset=2560
          i32.xor
          local.get $var3
          i64.load offset=16 align=1
          local.tee $var21
          i32.wrap_i64
          i32.xor
          local.get $var19
          i32.xor
          local.tee $var9
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=9728
          local.get $var9
          i32.const 6
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=8704
          i32.xor
          local.get $var9
          i32.const 14
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=7680
          i32.xor
          local.get $var9
          i32.const 22
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=6656
          i32.xor
          local.get $var21
          i64.const 32
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=5632
          i32.xor
          local.get $var21
          i64.const 40
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=4608
          i32.xor
          local.get $var21
          i64.const 48
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=3584
          i32.xor
          local.get $var21
          i64.const 56
          i64.shr_u
          i32.wrap_i64
          i32.const 2
          i32.shl
          i32.load offset=2560
          i32.xor
          local.get $var3
          i64.load offset=24 align=1
          local.tee $var21
          i32.wrap_i64
          i32.xor
          local.get $var18
          i32.xor
          local.tee $var9
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=9728
          local.get $var9
          i32.const 6
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=8704
          i32.xor
          local.get $var9
          i32.const 14
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=7680
          i32.xor
          local.get $var9
          i32.const 22
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=6656
          i32.xor
          local.get $var21
          i64.const 32
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=5632
          i32.xor
          local.get $var21
          i64.const 40
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=4608
          i32.xor
          local.get $var21
          i64.const 48
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=3584
          i32.xor
          local.get $var21
          i64.const 56
          i64.shr_u
          i32.wrap_i64
          i32.const 2
          i32.shl
          i32.load offset=2560
          i32.xor
          local.get $var3
          i64.load offset=32 align=1
          local.tee $var21
          i32.wrap_i64
          i32.xor
          local.get $var17
          i32.xor
          local.tee $var9
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=9728
          local.get $var9
          i32.const 6
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=8704
          i32.xor
          local.get $var9
          i32.const 14
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=7680
          i32.xor
          local.get $var9
          i32.const 22
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=6656
          i32.xor
          local.get $var21
          i64.const 32
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=5632
          i32.xor
          local.get $var21
          i64.const 40
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=4608
          i32.xor
          local.get $var21
          i64.const 48
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=3584
          i32.xor
          local.get $var21
          i64.const 56
          i64.shr_u
          i32.wrap_i64
          i32.const 2
          i32.shl
          i32.load offset=2560
          i32.xor
          local.get $var3
          i64.load offset=40 align=1
          local.tee $var21
          i32.wrap_i64
          i32.xor
          local.get $var16
          i32.xor
          local.tee $var9
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=9728
          local.get $var9
          i32.const 6
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=8704
          i32.xor
          local.get $var9
          i32.const 14
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=7680
          i32.xor
          local.get $var9
          i32.const 22
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=6656
          i32.xor
          local.get $var21
          i64.const 32
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=5632
          i32.xor
          local.get $var21
          i64.const 40
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=4608
          i32.xor
          local.get $var21
          i64.const 48
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=3584
          i32.xor
          local.get $var21
          i64.const 56
          i64.shr_u
          i32.wrap_i64
          i32.const 2
          i32.shl
          i32.load offset=2560
          i32.xor
          local.get $var3
          i64.load offset=48 align=1
          local.tee $var21
          i32.wrap_i64
          i32.xor
          local.get $var15
          i32.xor
          local.tee $var9
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=9728
          local.get $var9
          i32.const 6
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=8704
          i32.xor
          local.get $var9
          i32.const 14
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=7680
          i32.xor
          local.get $var9
          i32.const 22
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=6656
          i32.xor
          local.get $var21
          i64.const 32
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=5632
          i32.xor
          local.get $var21
          i64.const 40
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=4608
          i32.xor
          local.get $var21
          i64.const 48
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=3584
          i32.xor
          local.get $var21
          i64.const 56
          i64.shr_u
          i32.wrap_i64
          i32.const 2
          i32.shl
          i32.load offset=2560
          i32.xor
          local.get $var3
          i64.load offset=56 align=1
          local.tee $var21
          i32.wrap_i64
          i32.xor
          local.get $var14
          i32.xor
          local.tee $var3
          i32.const 6
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=8704
          local.get $var3
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=9728
          i32.xor
          local.get $var3
          i32.const 14
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=7680
          i32.xor
          local.get $var3
          i32.const 22
          i32.shr_u
          i32.const 1020
          i32.and
          i32.load offset=6656
          i32.xor
          local.get $var21
          i64.const 32
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=5632
          i32.xor
          local.get $var21
          i64.const 40
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=4608
          i32.xor
          local.get $var21
          i64.const 48
          i64.shr_u
          i32.wrap_i64
          i32.const 255
          i32.and
          i32.const 2
          i32.shl
          i32.load offset=3584
          i32.xor
          local.get $var21
          i64.const 56
          i64.shr_u
          i32.wrap_i64
          i32.const 2
          i32.shl
          i32.load offset=2560
          i32.xor
          local.set $var3
          local.get $var12
          local.get $var1
          i32.eq
          br_if $label40
          loop $label41
            local.get $var0
            local.get $var12
            i32.add
            i32.load8_u
            local.get $var3
            i32.xor
            i32.const 255
            i32.and
            i32.const 2
            i32.shl
            i32.load offset=2560
            local.get $var3
            i32.const 8
            i32.shr_u
            i32.xor
            local.set $var3
            local.get $var12
            i32.const 1
            i32.add
            local.tee $var12
            local.get $var1
            i32.lt_u
            br_if $label41
            br $label40
          end $label41
        end $label21
        local.get $var1
        i32.const 262128
        i32.and
        local.set $var9
      end $label19
      local.get $var9
      local.get $var1
      i32.ge_u
      br_if $label40
      local.get $var9
      i32.const 1
      i32.or
      local.set $var10
      block $label42
        local.get $var1
        i32.const 1
        i32.and
        i32.eqz
        br_if $label42
        local.get $var0
        local.get $var9
        i32.add
        i32.load8_u
        local.get $var3
        i32.xor
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        local.get $var3
        i32.const 8
        i32.shr_u
        i32.xor
        local.set $var3
        local.get $var10
        local.set $var9
      end $label42
      local.get $var1
      local.get $var10
      i32.eq
      br_if $label40
      local.get $var1
      local.get $var9
      i32.sub
      local.set $var10
      local.get $var0
      local.get $var9
      i32.add
      local.set $var9
      loop $label43
        local.get $var9
        i32.const 1
        i32.add
        i32.load8_u
        local.get $var9
        i32.load8_u
        local.get $var3
        i32.xor
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        local.get $var3
        i32.const 8
        i32.shr_u
        i32.xor
        local.tee $var3
        i32.xor
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        local.get $var3
        i32.const 8
        i32.shr_u
        i32.xor
        local.set $var3
        local.get $var9
        i32.const 2
        i32.add
        local.set $var9
        local.get $var10
        i32.const -2
        i32.add
        local.tee $var10
        br_if $label43
      end $label43
    end $label40
    local.get $var3
    i32.const -1
    i32.xor
  )
  (func $inflate_zip_media_batch (;3;) (export "inflate_zip_media_batch") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (param $var8 i32) (param $var9 i32) (param $var10 i32) (result i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    block $label0
      local.get $var7
      br_if $label0
      i32.const -1
      return
    end $label0
    i32.const 0
    local.set $var11
    local.get $var10
    local.set $var12
    loop $label17
      block $label1
        local.get $var1
        local.get $var2
        i32.load
        local.tee $var13
        i32.ge_u
        br_if $label1
        i32.const -1
        return
      end $label1
      block $label2
        local.get $var3
        i32.load
        local.tee $var14
        local.get $var1
        local.get $var13
        i32.sub
        i32.le_u
        br_if $label2
        i32.const -1
        return
      end $label2
      block $label3
        local.get $var4
        i32.load
        local.tee $var15
        local.get $var11
        i32.const 2147483647
        i32.xor
        i32.le_u
        br_if $label3
        i32.const -1
        return
      end $label3
      block $label5
        block $label4
          local.get $var10
          br_if $label4
          i32.const 0
          local.set $var16
          br $label5
        end $label4
        block $label6
          local.get $var9
          local.get $var11
          i32.ge_u
          br_if $label6
          i32.const -1
          return
        end $label6
        block $label7
          local.get $var15
          local.get $var9
          local.get $var11
          i32.sub
          i32.le_u
          br_if $label7
          i32.const -1
          return
        end $label7
        local.get $var12
        local.get $var11
        i32.store
        local.get $var11
        local.set $var16
      end $label5
      local.get $var0
      local.get $var13
      i32.add
      local.set $var17
      local.get $var8
      local.get $var16
      i32.add
      local.set $var13
      i32.const -1
      local.set $var16
      block $label9
        block $label13
          block $label10
            block $label8
              local.get $var5
              i32.load
              br_table $label8 $label9 $label9 $label9 $label9 $label9 $label9 $label9 $label10 $label9
            end $label8
            block $label11
              local.get $var14
              local.get $var15
              i32.eq
              br_if $label11
              i32.const -3
              return
            end $label11
            block $label12
              local.get $var10
              br_if $label12
              local.get $var17
              local.set $var13
              br $label13
            end $label12
            local.get $var14
            i32.eqz
            br_if $label13
            local.get $var13
            local.get $var17
            local.get $var14
            memory.copy
            br $label13
          end $label10
          block $label14
            local.get $var10
            br_if $label14
            block $label15
              local.get $var14
              i32.const 5
              i32.lt_u
              br_if $label15
              local.get $var14
              i32.const -5
              i32.add
              local.get $var15
              i32.ne
              br_if $label15
              local.get $var15
              i32.const 65535
              i32.gt_u
              br_if $label15
              local.get $var17
              i32.load8_u
              i32.const 7
              i32.and
              i32.const 1
              i32.ne
              br_if $label15
              local.get $var17
              i32.load16_u offset=1 align=1
              local.get $var15
              i32.ne
              br_if $label15
              local.get $var17
              i32.load16_u offset=3 align=1
              local.get $var15
              i32.xor
              i32.const 65535
              i32.ne
              br_if $label15
              local.get $var17
              i32.const 5
              i32.add
              local.set $var13
              br $label13
            end $label15
            local.get $var15
            local.get $var9
            i32.le_u
            br_if $label14
            i32.const -1
            return
          end $label14
          local.get $var17
          local.get $var14
          local.get $var13
          local.get $var15
          call $func50
          local.tee $var16
          br_if $label9
        end $label13
        block $label16
          local.get $var13
          local.get $var15
          call $func2
          local.get $var6
          i32.load
          i32.eq
          br_if $label16
          i32.const -4
          return
        end $label16
        local.get $var2
        i32.const 4
        i32.add
        local.set $var2
        local.get $var3
        i32.const 4
        i32.add
        local.set $var3
        local.get $var4
        i32.const 4
        i32.add
        local.set $var4
        local.get $var12
        i32.const 4
        i32.add
        local.set $var12
        local.get $var5
        i32.const 4
        i32.add
        local.set $var5
        local.get $var6
        i32.const 4
        i32.add
        local.set $var6
        local.get $var15
        local.get $var11
        i32.add
        local.tee $var11
        local.set $var16
        local.get $var7
        i32.const -1
        i32.add
        local.tee $var7
        br_if $label17
      end $label9
    end $label17
    local.get $var16
  )
  (func $verify_term_bank_source_crcs (;4;) (export "verify_term_bank_source_crcs") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (param $var8 i32) (result i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 i32)
    (local $var23 i32)
    (local $var24 i32)
    (local $var25 i32)
    (local $var26 i32)
    (local $var27 i32)
    (local $var28 i32)
    (local $var29 i32)
    (local $var30 i32)
    (local $var31 i32)
    (local $var32 i32)
    (local $var33 i32)
    (local $var34 i32)
    (local $var35 i32)
    (local $var36 i32)
    global.get $global0
    i32.const 528
    i32.sub
    local.tee $var9
    global.set $global0
    i32.const -1
    local.set $var10
    block $label0
      local.get $var0
      i32.eqz
      br_if $label0
      local.get $var2
      i32.eqz
      br_if $label0
      local.get $var3
      i32.eqz
      br_if $label0
      local.get $var4
      i32.eqz
      br_if $label0
      block $label5
        block $label3
          block $label2
            block $label1
              local.get $var6
              i32.eqz
              br_if $label1
              local.get $var5
              i32.eqz
              br_if $label0
              local.get $var7
              i32.eqz
              br_if $label0
              i32.const -1
              local.set $var10
              local.get $var9
              i32.const -1
              i32.store offset=12
              local.get $var0
              i32.const 0
              call $func2
              drop
              local.get $var9
              i32.const 464
              i32.add
              local.set $var11
              local.get $var9
              i32.const 400
              i32.add
              local.set $var12
              local.get $var9
              i32.const 336
              i32.add
              local.set $var13
              local.get $var9
              i32.const 272
              i32.add
              local.set $var14
              local.get $var9
              i32.const 208
              i32.add
              local.set $var15
              local.get $var9
              i32.const 144
              i32.add
              local.set $var16
              local.get $var9
              i32.const 12
              i32.add
              i32.const 68
              i32.add
              local.set $var17
              local.get $var9
              i32.const 16
              i32.add
              local.set $var18
              i32.const 0
              local.set $var19
              i32.const 0
              local.set $var20
              i32.const 0
              local.set $var21
              i32.const 0
              local.set $var22
              i32.const 0
              local.set $var23
              i32.const -1
              local.set $var24
              br $label2
            end $label1
            i32.const -1
            local.set $var10
            local.get $var9
            i32.const -1
            i32.store offset=12
            i32.const 0
            local.set $var25
            local.get $var0
            i32.const 0
            call $func2
            drop
            loop $label4
              local.get $var2
              i32.load
              local.tee $var20
              local.get $var25
              i32.ne
              br_if $label0
              local.get $var1
              local.get $var20
              i32.lt_u
              br_if $label0
              local.get $var2
              i32.const 4
              i32.add
              i32.load
              local.tee $var26
              local.get $var1
              local.get $var20
              i32.sub
              i32.gt_u
              br_if $label0
              local.get $var0
              local.get $var25
              i32.add
              local.get $var26
              call $func2
              local.get $var4
              i32.load
              i32.ne
              br_if $label3
              local.get $var2
              i32.const 8
              i32.add
              local.set $var2
              local.get $var4
              i32.const 4
              i32.add
              local.set $var4
              local.get $var26
              local.get $var25
              i32.add
              local.set $var25
              local.get $var3
              i32.const -1
              i32.add
              local.tee $var3
              br_if $label4
            end $label4
            i32.const 0
            local.set $var22
            i32.const 0
            local.set $var21
            i32.const 0
            local.set $var19
            br $label5
          end $label2
          loop $label16
            local.get $var2
            local.get $var23
            i32.const 3
            i32.shl
            i32.add
            local.tee $var27
            i32.load
            local.tee $var26
            local.get $var20
            i32.ne
            br_if $label0
            local.get $var1
            local.get $var26
            i32.lt_u
            br_if $label0
            local.get $var27
            i32.load offset=4
            local.tee $var27
            local.get $var1
            local.get $var26
            i32.sub
            i32.gt_u
            br_if $label0
            local.get $var27
            local.get $var20
            i32.add
            local.set $var25
            i32.const 0
            local.set $var26
            block $label6
              local.get $var19
              local.get $var6
              i32.ge_u
              br_if $label6
              i32.const 0
              local.set $var26
              loop $label15
                local.get $var25
                local.get $var5
                local.get $var19
                i32.const 68
                i32.mul
                i32.add
                local.tee $var27
                i32.load offset=36
                local.tee $var28
                i32.le_u
                br_if $label6
                local.get $var28
                local.get $var20
                i32.lt_u
                br_if $label0
                local.get $var27
                i32.load offset=40
                local.tee $var29
                i32.eqz
                br_if $label0
                local.get $var29
                local.get $var25
                local.get $var28
                i32.sub
                i32.gt_u
                br_if $label0
                local.get $var26
                local.get $var0
                local.get $var20
                i32.add
                local.get $var28
                local.get $var20
                i32.sub
                call $func5
                local.set $var30
                block $label8
                  block $label7
                    local.get $var7
                    local.get $var19
                    i32.const 2
                    i32.shl
                    i32.add
                    local.tee $var26
                    i32.load
                    local.tee $var20
                    i32.const -1
                    i32.ne
                    br_if $label7
                    local.get $var0
                    local.get $var28
                    i32.add
                    local.get $var29
                    call $func2
                    local.set $var31
                    br $label8
                  end $label7
                  local.get $var20
                  local.get $var19
                  i32.ge_u
                  br_if $label0
                  local.get $var5
                  local.get $var20
                  i32.const 68
                  i32.mul
                  i32.add
                  i32.load offset=40
                  local.get $var29
                  i32.ne
                  br_if $label0
                  local.get $var22
                  i32.const 1
                  i32.add
                  local.set $var22
                  local.get $var29
                  local.get $var21
                  i32.add
                  local.set $var21
                  local.get $var7
                  local.get $var20
                  i32.const 2
                  i32.shl
                  i32.add
                  i32.load
                  local.set $var31
                end $label8
                local.get $var26
                local.get $var31
                i32.store
                block $label9
                  local.get $var24
                  local.get $var29
                  i32.eq
                  br_if $label9
                  i32.const -2147483648
                  local.set $var24
                  i32.const 8388608
                  local.set $var27
                  local.get $var29
                  local.set $var32
                  loop $label14
                    block $label11
                      block $label10
                        local.get $var32
                        i32.const 1
                        i32.and
                        br_if $label10
                        local.get $var24
                        local.set $var33
                        br $label11
                      end $label10
                      i32.const 0
                      local.set $var33
                      i32.const -2147483648
                      local.set $var20
                      local.get $var27
                      local.set $var26
                      loop $label12
                        i32.const 0
                        local.get $var26
                        i32.const 1
                        i32.and
                        i32.sub
                        i32.const -306674912
                        i32.and
                        local.get $var26
                        i32.const 1
                        i32.shr_u
                        i32.xor
                        local.tee $var34
                        i32.const 0
                        local.get $var20
                        i32.const 1
                        i32.shr_u
                        local.get $var24
                        i32.and
                        select
                        local.get $var26
                        i32.const 0
                        local.get $var20
                        local.get $var24
                        i32.and
                        select
                        local.get $var33
                        i32.xor
                        i32.xor
                        local.set $var33
                        local.get $var20
                        i32.const 3
                        i32.gt_u
                        local.set $var35
                        local.get $var20
                        i32.const 2
                        i32.shr_u
                        local.set $var20
                        local.get $var26
                        i32.const 30
                        i32.shl
                        i32.const 31
                        i32.shr_s
                        i32.const -306674912
                        i32.and
                        local.get $var34
                        i32.const 1
                        i32.shr_u
                        i32.xor
                        local.set $var26
                        local.get $var35
                        br_if $label12
                      end $label12
                    end $label11
                    i32.const 0
                    local.set $var24
                    i32.const -2147483648
                    local.set $var20
                    local.get $var27
                    local.set $var26
                    loop $label13
                      i32.const 0
                      local.get $var26
                      i32.const 1
                      i32.and
                      i32.sub
                      i32.const -306674912
                      i32.and
                      local.get $var26
                      i32.const 1
                      i32.shr_u
                      i32.xor
                      local.tee $var34
                      i32.const 0
                      local.get $var20
                      i32.const 1
                      i32.shr_u
                      local.get $var27
                      i32.and
                      select
                      local.get $var26
                      i32.const 0
                      local.get $var20
                      local.get $var27
                      i32.and
                      select
                      local.get $var24
                      i32.xor
                      i32.xor
                      local.set $var24
                      local.get $var20
                      i32.const 3
                      i32.gt_u
                      local.set $var35
                      local.get $var20
                      i32.const 2
                      i32.shr_u
                      local.set $var20
                      local.get $var26
                      i32.const 30
                      i32.shl
                      i32.const 31
                      i32.shr_s
                      i32.const -306674912
                      i32.and
                      local.get $var34
                      i32.const 1
                      i32.shr_u
                      i32.xor
                      local.set $var26
                      local.get $var35
                      br_if $label13
                    end $label13
                    local.get $var32
                    i32.const 2
                    i32.lt_u
                    local.set $var20
                    local.get $var24
                    local.set $var27
                    local.get $var33
                    local.set $var24
                    local.get $var32
                    i32.const 1
                    i32.shr_u
                    local.set $var32
                    local.get $var20
                    i32.eqz
                    br_if $label14
                  end $label14
                  local.get $var9
                  i32.const 0
                  i32.store offset=464
                  local.get $var9
                  i32.const 0
                  i32.store offset=400
                  local.get $var9
                  i32.const 0
                  i32.store offset=336
                  local.get $var9
                  i32.const 0
                  i32.store offset=272
                  local.get $var9
                  i32.const 0
                  i32.store offset=208
                  local.get $var9
                  i32.const 0
                  i32.store offset=144
                  local.get $var9
                  i32.const 0
                  i32.store offset=80
                  local.get $var9
                  i32.const 0
                  i32.store offset=16
                  local.get $var9
                  local.get $var33
                  i32.store offset=496
                  local.get $var9
                  i32.const 0
                  local.get $var33
                  i32.const 1
                  i32.and
                  i32.sub
                  i32.const -306674912
                  i32.and
                  local.get $var33
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var26
                  i32.store offset=480
                  local.get $var9
                  local.get $var33
                  local.get $var26
                  i32.xor
                  local.tee $var24
                  i32.store offset=512
                  local.get $var9
                  local.get $var33
                  i32.const 30
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var26
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var27
                  i32.store offset=472
                  local.get $var9
                  local.get $var24
                  local.get $var27
                  i32.xor
                  local.tee $var34
                  i32.store offset=520
                  local.get $var9
                  local.get $var33
                  i32.const 29
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var27
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var20
                  i32.store offset=468
                  local.get $var9
                  local.get $var34
                  local.get $var20
                  i32.xor
                  i32.store offset=524
                  local.get $var9
                  local.get $var24
                  local.get $var20
                  i32.xor
                  i32.store offset=516
                  local.get $var9
                  local.get $var33
                  local.get $var27
                  i32.xor
                  local.tee $var24
                  i32.store offset=504
                  local.get $var9
                  local.get $var24
                  local.get $var20
                  i32.xor
                  i32.store offset=508
                  local.get $var9
                  local.get $var33
                  local.get $var20
                  i32.xor
                  i32.store offset=500
                  local.get $var9
                  local.get $var26
                  local.get $var27
                  i32.xor
                  local.tee $var24
                  i32.store offset=488
                  local.get $var9
                  local.get $var24
                  local.get $var20
                  i32.xor
                  i32.store offset=492
                  local.get $var9
                  local.get $var26
                  local.get $var20
                  i32.xor
                  i32.store offset=484
                  local.get $var9
                  local.get $var27
                  local.get $var20
                  i32.xor
                  i32.store offset=476
                  local.get $var9
                  local.get $var33
                  i32.const 28
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var20
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var34
                  i32.store offset=432
                  local.get $var9
                  local.get $var33
                  i32.const 27
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var34
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var35
                  i32.store offset=416
                  local.get $var9
                  local.get $var34
                  local.get $var35
                  i32.xor
                  local.tee $var32
                  i32.store offset=448
                  local.get $var9
                  local.get $var33
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var35
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var24
                  i32.store offset=408
                  local.get $var9
                  local.get $var32
                  local.get $var24
                  i32.xor
                  local.tee $var33
                  i32.store offset=456
                  local.get $var9
                  local.get $var26
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var24
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var26
                  i32.store offset=404
                  local.get $var9
                  local.get $var33
                  local.get $var26
                  i32.xor
                  i32.store offset=460
                  local.get $var9
                  local.get $var32
                  local.get $var26
                  i32.xor
                  i32.store offset=452
                  local.get $var9
                  local.get $var34
                  local.get $var24
                  i32.xor
                  local.tee $var33
                  i32.store offset=440
                  local.get $var9
                  local.get $var33
                  local.get $var26
                  i32.xor
                  i32.store offset=444
                  local.get $var9
                  local.get $var34
                  local.get $var26
                  i32.xor
                  i32.store offset=436
                  local.get $var9
                  local.get $var35
                  local.get $var24
                  i32.xor
                  local.tee $var33
                  i32.store offset=424
                  local.get $var9
                  local.get $var33
                  local.get $var26
                  i32.xor
                  i32.store offset=428
                  local.get $var9
                  local.get $var35
                  local.get $var26
                  i32.xor
                  i32.store offset=420
                  local.get $var9
                  local.get $var24
                  local.get $var26
                  i32.xor
                  i32.store offset=412
                  local.get $var9
                  local.get $var27
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var26
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var33
                  i32.store offset=368
                  local.get $var9
                  local.get $var20
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var33
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var32
                  i32.store offset=352
                  local.get $var9
                  local.get $var33
                  local.get $var32
                  i32.xor
                  local.tee $var36
                  i32.store offset=384
                  local.get $var9
                  local.get $var34
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var32
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var27
                  i32.store offset=344
                  local.get $var9
                  local.get $var36
                  local.get $var27
                  i32.xor
                  local.tee $var34
                  i32.store offset=392
                  local.get $var9
                  local.get $var35
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var27
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var20
                  i32.store offset=340
                  local.get $var9
                  local.get $var34
                  local.get $var20
                  i32.xor
                  i32.store offset=396
                  local.get $var9
                  local.get $var36
                  local.get $var20
                  i32.xor
                  i32.store offset=388
                  local.get $var9
                  local.get $var33
                  local.get $var27
                  i32.xor
                  local.tee $var34
                  i32.store offset=376
                  local.get $var9
                  local.get $var34
                  local.get $var20
                  i32.xor
                  i32.store offset=380
                  local.get $var9
                  local.get $var33
                  local.get $var20
                  i32.xor
                  i32.store offset=372
                  local.get $var9
                  local.get $var32
                  local.get $var27
                  i32.xor
                  local.tee $var34
                  i32.store offset=360
                  local.get $var9
                  local.get $var34
                  local.get $var20
                  i32.xor
                  i32.store offset=364
                  local.get $var9
                  local.get $var32
                  local.get $var20
                  i32.xor
                  i32.store offset=356
                  local.get $var9
                  local.get $var27
                  local.get $var20
                  i32.xor
                  i32.store offset=348
                  local.get $var9
                  local.get $var24
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var20
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var34
                  i32.store offset=304
                  local.get $var9
                  local.get $var26
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var34
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var35
                  i32.store offset=288
                  local.get $var9
                  local.get $var34
                  local.get $var35
                  i32.xor
                  local.tee $var36
                  i32.store offset=320
                  local.get $var9
                  local.get $var33
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var35
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var24
                  i32.store offset=280
                  local.get $var9
                  local.get $var36
                  local.get $var24
                  i32.xor
                  local.tee $var33
                  i32.store offset=328
                  local.get $var9
                  local.get $var32
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var24
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var26
                  i32.store offset=276
                  local.get $var9
                  local.get $var33
                  local.get $var26
                  i32.xor
                  i32.store offset=332
                  local.get $var9
                  local.get $var36
                  local.get $var26
                  i32.xor
                  i32.store offset=324
                  local.get $var9
                  local.get $var34
                  local.get $var24
                  i32.xor
                  local.tee $var33
                  i32.store offset=312
                  local.get $var9
                  local.get $var33
                  local.get $var26
                  i32.xor
                  i32.store offset=316
                  local.get $var9
                  local.get $var34
                  local.get $var26
                  i32.xor
                  i32.store offset=308
                  local.get $var9
                  local.get $var35
                  local.get $var24
                  i32.xor
                  local.tee $var33
                  i32.store offset=296
                  local.get $var9
                  local.get $var33
                  local.get $var26
                  i32.xor
                  i32.store offset=300
                  local.get $var9
                  local.get $var35
                  local.get $var26
                  i32.xor
                  i32.store offset=292
                  local.get $var9
                  local.get $var24
                  local.get $var26
                  i32.xor
                  i32.store offset=284
                  local.get $var9
                  local.get $var27
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var26
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var33
                  i32.store offset=240
                  local.get $var9
                  local.get $var20
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var33
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var32
                  i32.store offset=224
                  local.get $var9
                  local.get $var33
                  local.get $var32
                  i32.xor
                  local.tee $var36
                  i32.store offset=256
                  local.get $var9
                  local.get $var34
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var32
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var27
                  i32.store offset=216
                  local.get $var9
                  local.get $var36
                  local.get $var27
                  i32.xor
                  local.tee $var34
                  i32.store offset=264
                  local.get $var9
                  local.get $var35
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var27
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var20
                  i32.store offset=212
                  local.get $var9
                  local.get $var34
                  local.get $var20
                  i32.xor
                  i32.store offset=268
                  local.get $var9
                  local.get $var36
                  local.get $var20
                  i32.xor
                  i32.store offset=260
                  local.get $var9
                  local.get $var33
                  local.get $var27
                  i32.xor
                  local.tee $var34
                  i32.store offset=248
                  local.get $var9
                  local.get $var34
                  local.get $var20
                  i32.xor
                  i32.store offset=252
                  local.get $var9
                  local.get $var33
                  local.get $var20
                  i32.xor
                  i32.store offset=244
                  local.get $var9
                  local.get $var32
                  local.get $var27
                  i32.xor
                  local.tee $var34
                  i32.store offset=232
                  local.get $var9
                  local.get $var34
                  local.get $var20
                  i32.xor
                  i32.store offset=236
                  local.get $var9
                  local.get $var32
                  local.get $var20
                  i32.xor
                  i32.store offset=228
                  local.get $var9
                  local.get $var27
                  local.get $var20
                  i32.xor
                  i32.store offset=220
                  local.get $var9
                  local.get $var24
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var20
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var34
                  i32.store offset=176
                  local.get $var9
                  local.get $var26
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var34
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var35
                  i32.store offset=160
                  local.get $var9
                  local.get $var34
                  local.get $var35
                  i32.xor
                  local.tee $var36
                  i32.store offset=192
                  local.get $var9
                  local.get $var33
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var35
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var24
                  i32.store offset=152
                  local.get $var9
                  local.get $var36
                  local.get $var24
                  i32.xor
                  local.tee $var33
                  i32.store offset=200
                  local.get $var9
                  local.get $var32
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var24
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var26
                  i32.store offset=148
                  local.get $var9
                  local.get $var33
                  local.get $var26
                  i32.xor
                  i32.store offset=204
                  local.get $var9
                  local.get $var36
                  local.get $var26
                  i32.xor
                  i32.store offset=196
                  local.get $var9
                  local.get $var34
                  local.get $var24
                  i32.xor
                  local.tee $var33
                  i32.store offset=184
                  local.get $var9
                  local.get $var33
                  local.get $var26
                  i32.xor
                  i32.store offset=188
                  local.get $var9
                  local.get $var34
                  local.get $var26
                  i32.xor
                  i32.store offset=180
                  local.get $var9
                  local.get $var35
                  local.get $var24
                  i32.xor
                  local.tee $var33
                  i32.store offset=168
                  local.get $var9
                  local.get $var33
                  local.get $var26
                  i32.xor
                  i32.store offset=172
                  local.get $var9
                  local.get $var35
                  local.get $var26
                  i32.xor
                  i32.store offset=164
                  local.get $var9
                  local.get $var24
                  local.get $var26
                  i32.xor
                  i32.store offset=156
                  local.get $var9
                  local.get $var27
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var26
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var27
                  i32.store offset=112
                  local.get $var9
                  local.get $var20
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var27
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var33
                  i32.store offset=96
                  local.get $var9
                  local.get $var27
                  local.get $var33
                  i32.xor
                  local.tee $var32
                  i32.store offset=128
                  local.get $var9
                  local.get $var34
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var33
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var34
                  i32.store offset=88
                  local.get $var9
                  local.get $var32
                  local.get $var34
                  i32.xor
                  local.tee $var36
                  i32.store offset=136
                  local.get $var9
                  local.get $var35
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var34
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var20
                  i32.store offset=84
                  local.get $var9
                  local.get $var36
                  local.get $var20
                  i32.xor
                  i32.store offset=140
                  local.get $var9
                  local.get $var32
                  local.get $var20
                  i32.xor
                  i32.store offset=132
                  local.get $var9
                  local.get $var27
                  local.get $var34
                  i32.xor
                  local.tee $var35
                  i32.store offset=120
                  local.get $var9
                  local.get $var35
                  local.get $var20
                  i32.xor
                  i32.store offset=124
                  local.get $var9
                  local.get $var27
                  local.get $var20
                  i32.xor
                  i32.store offset=116
                  local.get $var9
                  local.get $var33
                  local.get $var34
                  i32.xor
                  local.tee $var35
                  i32.store offset=104
                  local.get $var9
                  local.get $var35
                  local.get $var20
                  i32.xor
                  i32.store offset=108
                  local.get $var9
                  local.get $var33
                  local.get $var20
                  i32.xor
                  i32.store offset=100
                  local.get $var9
                  local.get $var34
                  local.get $var20
                  i32.xor
                  i32.store offset=92
                  local.get $var9
                  local.get $var24
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var20
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var24
                  i32.store offset=48
                  local.get $var9
                  local.get $var26
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var24
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var34
                  i32.store offset=32
                  local.get $var9
                  local.get $var24
                  local.get $var34
                  i32.xor
                  local.tee $var35
                  i32.store offset=64
                  local.get $var9
                  local.get $var27
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var34
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var26
                  i32.store offset=24
                  local.get $var9
                  local.get $var35
                  local.get $var26
                  i32.xor
                  local.tee $var27
                  i32.store offset=72
                  local.get $var9
                  local.get $var33
                  i32.const 26
                  i32.shl
                  i32.const 31
                  i32.shr_s
                  i32.const -306674912
                  i32.and
                  local.get $var26
                  i32.const 1
                  i32.shr_u
                  i32.xor
                  local.tee $var20
                  i32.store offset=20
                  local.get $var9
                  local.get $var27
                  local.get $var20
                  i32.xor
                  i32.store offset=76
                  local.get $var9
                  local.get $var35
                  local.get $var20
                  i32.xor
                  i32.store offset=68
                  local.get $var9
                  local.get $var24
                  local.get $var26
                  i32.xor
                  local.tee $var27
                  i32.store offset=56
                  local.get $var9
                  local.get $var27
                  local.get $var20
                  i32.xor
                  i32.store offset=60
                  local.get $var9
                  local.get $var24
                  local.get $var20
                  i32.xor
                  i32.store offset=52
                  local.get $var9
                  local.get $var34
                  local.get $var26
                  i32.xor
                  local.tee $var27
                  i32.store offset=40
                  local.get $var9
                  local.get $var27
                  local.get $var20
                  i32.xor
                  i32.store offset=44
                  local.get $var9
                  local.get $var34
                  local.get $var20
                  i32.xor
                  i32.store offset=36
                  local.get $var9
                  local.get $var26
                  local.get $var20
                  i32.xor
                  i32.store offset=28
                  local.get $var9
                  local.get $var29
                  i32.store offset=12
                  local.get $var29
                  local.set $var24
                end $label9
                local.get $var18
                local.get $var30
                i32.const 15
                i32.and
                i32.const 2
                i32.shl
                i32.add
                i32.load
                local.get $var17
                local.get $var30
                i32.const 2
                i32.shr_u
                i32.const 60
                i32.and
                i32.add
                i32.load
                i32.xor
                local.get $var16
                local.get $var30
                i32.const 6
                i32.shr_u
                i32.const 60
                i32.and
                i32.add
                i32.load
                i32.xor
                local.get $var15
                local.get $var30
                i32.const 10
                i32.shr_u
                i32.const 60
                i32.and
                i32.add
                i32.load
                i32.xor
                local.get $var14
                local.get $var30
                i32.const 14
                i32.shr_u
                i32.const 60
                i32.and
                i32.add
                i32.load
                i32.xor
                local.get $var13
                local.get $var30
                i32.const 18
                i32.shr_u
                i32.const 60
                i32.and
                i32.add
                i32.load
                i32.xor
                local.get $var12
                local.get $var30
                i32.const 22
                i32.shr_u
                i32.const 60
                i32.and
                i32.add
                i32.load
                i32.xor
                local.get $var11
                local.get $var30
                i32.const 26
                i32.shr_u
                i32.const 60
                i32.and
                i32.add
                i32.load
                i32.xor
                local.get $var31
                i32.xor
                local.set $var26
                local.get $var29
                local.get $var28
                i32.add
                local.set $var20
                local.get $var19
                i32.const 1
                i32.add
                local.tee $var19
                local.get $var6
                i32.ne
                br_if $label15
              end $label15
              local.get $var6
              local.set $var19
            end $label6
            local.get $var26
            local.get $var0
            local.get $var20
            i32.add
            local.get $var25
            local.get $var20
            i32.sub
            call $func5
            local.get $var4
            local.get $var23
            i32.const 2
            i32.shl
            i32.add
            i32.load
            i32.ne
            br_if $label3
            local.get $var25
            local.set $var20
            local.get $var23
            i32.const 1
            i32.add
            local.tee $var23
            local.get $var3
            i32.eq
            br_if $label5
            br $label16
          end $label16
        end $label3
        i32.const -4
        local.set $var10
        br $label0
      end $label5
      i32.const -1
      local.set $var10
      local.get $var25
      local.get $var1
      i32.ne
      br_if $label0
      local.get $var19
      local.get $var6
      i32.ne
      br_if $label0
      i32.const 0
      local.set $var10
      local.get $var8
      i32.eqz
      br_if $label0
      local.get $var8
      local.get $var22
      i32.store offset=8
      local.get $var8
      local.get $var21
      i32.store offset=4
      local.get $var8
      local.get $var1
      local.get $var21
      i32.sub
      i32.store
    end $label0
    local.get $var9
    i32.const 528
    i32.add
    global.set $global0
    local.get $var10
  )
  (func $func5 (param $var0 i32) (param $var1 i32) (param $var2 i32) (result i32)
    (local $var3 i32)
    (local $var4 i32)
    local.get $var0
    i32.const -1
    i32.xor
    local.set $var3
    i32.const 0
    local.set $var0
    block $label0
      local.get $var2
      i32.const 16
      i32.lt_u
      br_if $label0
      local.get $var2
      local.set $var4
      local.get $var1
      local.set $var0
      loop $label1
        local.get $var0
        i32.load align=1
        local.get $var3
        i32.xor
        local.tee $var3
        i32.const 6
        i32.shr_u
        i32.const 1020
        i32.and
        i32.load offset=16896
        local.get $var3
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=17920
        i32.xor
        local.get $var3
        i32.const 14
        i32.shr_u
        i32.const 1020
        i32.and
        i32.load offset=15872
        i32.xor
        local.get $var3
        i32.const 22
        i32.shr_u
        i32.const 1020
        i32.and
        i32.load offset=14848
        i32.xor
        local.get $var0
        i32.const 4
        i32.add
        i32.load align=1
        local.tee $var3
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=13824
        i32.xor
        local.get $var3
        i32.const 6
        i32.shr_u
        i32.const 1020
        i32.and
        i32.load offset=12800
        i32.xor
        local.get $var3
        i32.const 14
        i32.shr_u
        i32.const 1020
        i32.and
        i32.load offset=11776
        i32.xor
        local.get $var3
        i32.const 22
        i32.shr_u
        i32.const 1020
        i32.and
        i32.load offset=10752
        i32.xor
        local.get $var0
        i32.const 8
        i32.add
        i32.load align=1
        local.tee $var3
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=9728
        i32.xor
        local.get $var3
        i32.const 6
        i32.shr_u
        i32.const 1020
        i32.and
        i32.load offset=8704
        i32.xor
        local.get $var3
        i32.const 14
        i32.shr_u
        i32.const 1020
        i32.and
        i32.load offset=7680
        i32.xor
        local.get $var3
        i32.const 22
        i32.shr_u
        i32.const 1020
        i32.and
        i32.load offset=6656
        i32.xor
        local.get $var0
        i32.const 12
        i32.add
        i32.load align=1
        local.tee $var3
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=5632
        i32.xor
        local.get $var3
        i32.const 6
        i32.shr_u
        i32.const 1020
        i32.and
        i32.load offset=4608
        i32.xor
        local.get $var3
        i32.const 14
        i32.shr_u
        i32.const 1020
        i32.and
        i32.load offset=3584
        i32.xor
        local.get $var3
        i32.const 22
        i32.shr_u
        i32.const 1020
        i32.and
        i32.load offset=2560
        i32.xor
        local.set $var3
        local.get $var0
        i32.const 16
        i32.add
        local.set $var0
        local.get $var4
        i32.const -16
        i32.add
        local.tee $var4
        i32.const 15
        i32.gt_u
        br_if $label1
      end $label1
      local.get $var2
      i32.const -16
      i32.and
      local.set $var0
    end $label0
    block $label2
      local.get $var0
      local.get $var2
      i32.ge_u
      br_if $label2
      local.get $var0
      i32.const 1
      i32.or
      local.set $var4
      block $label3
        local.get $var2
        i32.const 1
        i32.and
        i32.eqz
        br_if $label3
        local.get $var1
        local.get $var0
        i32.add
        i32.load8_u
        local.get $var3
        i32.xor
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        local.get $var3
        i32.const 8
        i32.shr_u
        i32.xor
        local.set $var3
        local.get $var4
        local.set $var0
      end $label3
      local.get $var2
      local.get $var4
      i32.eq
      br_if $label2
      local.get $var2
      local.get $var0
      i32.sub
      local.set $var4
      local.get $var1
      local.get $var0
      i32.add
      local.set $var0
      loop $label4
        local.get $var0
        i32.const 1
        i32.add
        i32.load8_u
        local.get $var0
        i32.load8_u
        local.get $var3
        i32.xor
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        local.get $var3
        i32.const 8
        i32.shr_u
        i32.xor
        local.tee $var3
        i32.xor
        i32.const 255
        i32.and
        i32.const 2
        i32.shl
        i32.load offset=2560
        local.get $var3
        i32.const 8
        i32.shr_u
        i32.xor
        local.set $var3
        local.get $var0
        i32.const 2
        i32.add
        local.set $var0
        local.get $var4
        i32.const -2
        i32.add
        local.tee $var4
        br_if $label4
      end $label4
    end $label2
    local.get $var3
    i32.const -1
    i32.xor
  )
  (func $wasm_reset_heap (;6;) (export "wasm_reset_heap")
    i32.const 0
    i32.const 104256
    i32.store offset=2544
  )
  (func $wasm_alloc (;7;) (export "wasm_alloc") (param $var0 i32) (result i32)
    (local $var1 i32)
    (local $var2 i32)
    (local $var3 i32)
    (local $var4 i32)
    i32.const 0
    local.set $var1
    block $label0
      i32.const 0
      i32.load offset=2544
      local.tee $var2
      br_if $label0
      i32.const 104256
      local.set $var2
      i32.const 0
      i32.const 104256
      i32.store offset=2544
    end $label0
    block $label1
      local.get $var0
      i32.const -8
      i32.gt_u
      br_if $label1
      local.get $var2
      i32.const 7
      i32.add
      i32.const -8
      i32.and
      local.tee $var2
      local.get $var0
      i32.const 7
      i32.add
      i32.const -8
      i32.and
      local.tee $var0
      i32.const -1
      i32.xor
      i32.gt_u
      br_if $label1
      i32.const 0
      local.set $var1
      block $label2
        local.get $var2
        local.get $var0
        i32.add
        local.tee $var0
        i32.const 16
        i32.shr_u
        local.get $var0
        i32.const 65528
        i32.and
        i32.const 0
        i32.ne
        i32.add
        local.tee $var3
        memory.size
        local.tee $var4
        i32.le_u
        br_if $label2
        local.get $var3
        local.get $var4
        i32.sub
        memory.grow
        i32.const 0
        i32.lt_s
        br_if $label1
      end $label2
      i32.const 0
      local.get $var0
      i32.store offset=2544
      local.get $var2
      local.set $var1
    end $label1
    local.get $var1
  )
  (func $wasm_get_last_parse_capacity (;8;) (export "wasm_get_last_parse_capacity") (result i32)
    i32.const 0
    i32.load offset=2548
  )
  (func $wasm_get_last_content_capacity (;9;) (export "wasm_get_last_content_capacity") (result i32)
    i32.const 0
    i32.load offset=2552
  )
  (func $project_single_glossary_image_path (;10;) (export "project_single_glossary_image_path") (param $var0 i32) (param $var1 i32) (result i64)
    (local $var2 i32)
    (local $var3 i64)
    (local $var4 i32)
    (local $var5 i32)
    global.get $global0
    i32.const 16
    i32.sub
    local.tee $var2
    global.set $global0
    i64.const 0
    local.set $var3
    block $label0
      local.get $var1
      i64.extend_i32_u
      local.get $var0
      i64.extend_i32_u
      i64.add
      memory.size
      i64.extend_i32_u
      i64.const 16
      i64.shl
      i64.gt_u
      br_if $label0
      i32.const 0
      local.set $var4
      block $label1
        local.get $var1
        i32.eqz
        br_if $label1
        loop $label2
          local.get $var0
          local.get $var4
          i32.add
          i32.load8_u
          i32.const -9
          i32.add
          local.tee $var5
          i32.const 23
          i32.gt_u
          br_if $label1
          i32.const 1
          local.get $var5
          i32.shl
          i32.const 8388627
          i32.and
          i32.eqz
          br_if $label1
          local.get $var1
          local.get $var4
          i32.const 1
          i32.add
          local.tee $var4
          i32.ne
          br_if $label2
          br $label0
        end $label2
      end $label1
      local.get $var4
      local.get $var1
      i32.ge_u
      br_if $label0
      local.get $var0
      local.get $var4
      i32.add
      i32.load8_u
      i32.const 91
      i32.ne
      br_if $label0
      i64.const 0
      local.set $var3
      local.get $var0
      local.get $var1
      local.get $var4
      i32.const 0
      i32.const 0
      local.get $var2
      local.get $var2
      i32.const 4
      i32.add
      call $func11
      i32.eqz
      br_if $label0
      block $label3
        local.get $var2
        i32.load
        local.tee $var4
        local.get $var1
        i32.ge_u
        br_if $label3
        loop $label4
          local.get $var0
          local.get $var4
          i32.add
          i32.load8_u
          i32.const -9
          i32.add
          local.tee $var5
          i32.const 23
          i32.gt_u
          br_if $label3
          i32.const 1
          local.get $var5
          i32.shl
          i32.const 8388627
          i32.and
          i32.eqz
          br_if $label3
          local.get $var1
          local.get $var4
          i32.const 1
          i32.add
          local.tee $var4
          i32.ne
          br_if $label4
        end $label4
        local.get $var1
        local.set $var4
      end $label3
      local.get $var4
      local.get $var1
      i32.ne
      br_if $label0
      local.get $var2
      i32.load offset=4
      i32.const 1
      i32.ne
      br_if $label0
      local.get $var2
      i64.load32_u offset=8
      i64.const 32
      i64.shl
      local.get $var2
      i64.load32_u offset=12
      i64.or
      local.set $var3
    end $label0
    local.get $var2
    i32.const 16
    i32.add
    global.set $global0
    local.get $var3
  )
  (func $func11 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (result i32)
    (local $var7 i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 i32)
    (local $var23 i64)
    (local $var24 i32)
    (local $var25 i32)
    (local $var26 i32)
    (local $var27 i32)
    (local $var28 i32)
    global.get $global0
    i32.const 16
    i32.sub
    local.tee $var7
    global.set $global0
    local.get $var6
    i32.const 0
    i32.store offset=8
    local.get $var6
    i64.const 0
    i64.store align=4
    block $label1
      block $label0
        local.get $var2
        local.get $var1
        i32.lt_u
        br_if $label0
        i32.const 0
        local.set $var8
        br $label1
      end $label0
      block $label2
        local.get $var0
        local.get $var2
        i32.add
        i32.load8_u
        local.tee $var8
        i32.const 223
        i32.and
        i32.const 91
        i32.eq
        br_if $label2
        local.get $var0
        local.get $var1
        local.get $var2
        local.get $var5
        call $func12
        local.set $var8
        br $label1
      end $label2
      block $label3
        local.get $var4
        i32.const 255
        i32.le_u
        br_if $label3
        i32.const 0
        local.set $var8
        br $label1
      end $label3
      block $label8
        block $label4
          local.get $var8
          i32.const 91
          i32.ne
          br_if $label4
          block $label5
            local.get $var3
            i32.const 1
            i32.ne
            br_if $label5
            local.get $var0
            local.get $var1
            local.get $var2
            local.get $var5
            i32.const 0
            i32.const 0
            i32.const 0
            i32.const 0
            call $func13
            local.set $var8
            br $label1
          end $label5
          block $label6
            local.get $var2
            i32.const 1
            i32.add
            local.tee $var2
            local.get $var1
            i32.ge_u
            br_if $label6
            loop $label7
              local.get $var0
              local.get $var2
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var8
              i32.const 23
              i32.gt_u
              br_if $label6
              i32.const 1
              local.get $var8
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label6
              local.get $var1
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var2
              i32.ne
              br_if $label7
            end $label7
            local.get $var1
            local.set $var2
            br $label8
          end $label6
          local.get $var2
          local.get $var1
          i32.ge_u
          br_if $label8
          local.get $var0
          local.get $var2
          i32.add
          i32.load8_u
          i32.const 93
          i32.ne
          br_if $label8
          i32.const 1
          local.set $var8
          local.get $var5
          local.get $var2
          i32.const 1
          i32.add
          i32.store
          br $label1
        end $label4
        i32.const 0
        local.set $var8
        local.get $var3
        i32.eqz
        br_if $label1
        local.get $var7
        i32.const 8
        i32.add
        i32.const 0
        i32.store
        local.get $var7
        i64.const 0
        i64.store
        block $label11
          block $label9
            local.get $var2
            i32.const 1
            i32.add
            local.tee $var9
            local.get $var1
            i32.ge_u
            br_if $label9
            loop $label10
              local.get $var0
              local.get $var9
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var2
              i32.const 23
              i32.gt_u
              br_if $label9
              i32.const 1
              local.get $var2
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label9
              local.get $var1
              local.get $var9
              i32.const 1
              i32.add
              local.tee $var9
              i32.ne
              br_if $label10
            end $label10
            local.get $var1
            local.set $var9
            br $label11
          end $label9
          local.get $var9
          local.get $var1
          i32.ge_u
          br_if $label11
          local.get $var0
          local.get $var9
          i32.add
          i32.load8_u
          i32.const 125
          i32.ne
          br_if $label11
          i32.const 1
          local.set $var8
          local.get $var5
          local.get $var9
          i32.const 1
          i32.add
          i32.store
          br $label1
        end $label11
        local.get $var0
        i32.const 5
        i32.add
        local.set $var10
        local.get $var0
        i32.const 4
        i32.add
        local.set $var11
        local.get $var0
        i32.const 3
        i32.add
        local.set $var12
        local.get $var0
        i32.const 2
        i32.add
        local.set $var13
        local.get $var0
        i32.const 1
        i32.add
        local.set $var14
        local.get $var0
        i32.const 8
        i32.add
        local.set $var15
        local.get $var0
        i32.const 6
        i32.add
        local.set $var16
        local.get $var4
        i32.const 1
        i32.add
        local.set $var17
        i32.const 0
        local.set $var18
        i32.const 0
        local.set $var19
        i32.const 0
        local.set $var20
        i32.const 0
        local.set $var21
        loop $label86
          block $label12
            local.get $var9
            local.get $var1
            i32.lt_u
            br_if $label12
            i32.const 0
            local.set $var8
            br $label1
          end $label12
          block $label13
            local.get $var0
            local.get $var9
            i32.add
            i32.load8_u
            i32.const 34
            i32.eq
            br_if $label13
            i32.const 0
            local.set $var8
            br $label1
          end $label13
          block $label14
            local.get $var9
            i32.const 1
            i32.add
            local.tee $var22
            local.get $var1
            i32.lt_u
            br_if $label14
            i32.const 0
            local.set $var8
            br $label1
          end $label14
          local.get $var22
          local.set $var4
          block $label28
            loop $label16
              block $label15
                local.get $var4
                local.tee $var2
                i32.const 8
                i32.add
                local.tee $var4
                local.get $var1
                i32.gt_u
                br_if $label15
                local.get $var0
                local.get $var2
                i32.add
                i64.load align=1
                local.tee $var23
                i64.const -1
                i64.xor
                local.get $var23
                i64.const 2459565876494606882
                i64.xor
                i64.const -72340172838076673
                i64.add
                local.get $var23
                i64.const 6655295901103053916
                i64.xor
                i64.const -72340172838076673
                i64.add
                i64.or
                local.get $var23
                i64.const -2314885530818453536
                i64.add
                i64.or
                i64.and
                i64.const -9187201950435737472
                i64.and
                local.tee $var23
                i64.eqz
                br_if $label16
                local.get $var23
                i64.ctz
                i32.wrap_i64
                i32.const 3
                i32.shr_u
                local.get $var2
                i32.add
                local.set $var2
              end $label15
              block $label17
                local.get $var2
                local.get $var1
                i32.lt_u
                br_if $label17
                i32.const 0
                local.set $var8
                br $label1
              end $label17
              block $label23
                block $label18
                  local.get $var0
                  local.get $var2
                  i32.add
                  i32.load8_u
                  local.tee $var8
                  i32.const 92
                  i32.ne
                  br_if $label18
                  block $label19
                    local.get $var2
                    i32.const 1
                    i32.add
                    local.tee $var4
                    local.get $var1
                    i32.lt_u
                    br_if $label19
                    i32.const 0
                    local.set $var8
                    br $label1
                  end $label19
                  i32.const 0
                  local.set $var8
                  block $label20
                    block $label21
                      local.get $var0
                      local.get $var4
                      i32.add
                      i32.load8_u
                      i32.const -34
                      i32.add
                      br_table $label20 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label20 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label20 $label1 $label1 $label1 $label1 $label1 $label20 $label1 $label1 $label1 $label20 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label20 $label1 $label1 $label1 $label20 $label1 $label20 $label21 $label1
                    end $label21
                    block $label22
                      local.get $var2
                      i32.const 6
                      i32.add
                      local.tee $var4
                      local.get $var1
                      i32.le_u
                      br_if $label22
                      i32.const 0
                      local.set $var8
                      br $label1
                    end $label22
                    local.get $var2
                    i32.const 2
                    i32.add
                    local.tee $var8
                    local.get $var4
                    i32.ge_u
                    br_if $label23
                    block $label24
                      local.get $var0
                      local.get $var8
                      i32.add
                      i32.load8_u
                      local.tee $var8
                      i32.const -58
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 245
                      i32.gt_u
                      br_if $label24
                      local.get $var8
                      i32.const -33
                      i32.and
                      i32.const -71
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 250
                      i32.ge_u
                      br_if $label24
                      i32.const 0
                      local.set $var8
                      br $label1
                    end $label24
                    block $label25
                      local.get $var12
                      local.get $var2
                      i32.add
                      i32.load8_u
                      local.tee $var8
                      i32.const -58
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 245
                      i32.gt_u
                      br_if $label25
                      local.get $var8
                      i32.const -33
                      i32.and
                      i32.const -71
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 250
                      i32.ge_u
                      br_if $label25
                      i32.const 0
                      local.set $var8
                      br $label1
                    end $label25
                    block $label26
                      local.get $var11
                      local.get $var2
                      i32.add
                      i32.load8_u
                      local.tee $var8
                      i32.const -58
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 245
                      i32.gt_u
                      br_if $label26
                      local.get $var8
                      i32.const -33
                      i32.and
                      i32.const -71
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 250
                      i32.ge_u
                      br_if $label26
                      i32.const 0
                      local.set $var8
                      br $label1
                    end $label26
                    local.get $var10
                    local.get $var2
                    i32.add
                    i32.load8_u
                    local.tee $var2
                    i32.const -58
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 245
                    i32.gt_u
                    br_if $label23
                    local.get $var2
                    i32.const -33
                    i32.and
                    i32.const -71
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 250
                    i32.ge_u
                    br_if $label23
                    i32.const 0
                    local.set $var8
                    br $label1
                  end $label20
                  local.get $var2
                  i32.const 2
                  i32.add
                  local.set $var4
                  br $label23
                end $label18
                block $label27
                  local.get $var8
                  i32.const 32
                  i32.ge_u
                  br_if $label27
                  i32.const 0
                  local.set $var8
                  br $label1
                end $label27
                local.get $var2
                i32.const 1
                i32.add
                local.set $var4
                local.get $var8
                i32.const 34
                i32.eq
                br_if $label28
              end $label23
              local.get $var4
              local.get $var1
              i32.lt_u
              br_if $label16
            end $label16
            i32.const 0
            local.set $var8
            br $label1
          end $label28
          block $label30
            block $label29
              local.get $var2
              local.get $var9
              i32.ge_u
              br_if $label29
              i32.const 0
              local.set $var24
              i32.const 1
              local.set $var25
              i32.const 0
              local.set $var26
              br $label30
            end $label29
            local.get $var2
            local.get $var9
            i32.sub
            local.set $var8
            i32.const 0
            local.set $var24
            block $label31
              local.get $var2
              local.get $var9
              i32.eq
              br_if $label31
              block $label32
                local.get $var0
                local.get $var22
                i32.add
                i32.load8_u
                local.tee $var25
                i32.const 92
                i32.eq
                br_if $label32
                local.get $var25
                i32.const 99
                i32.ne
                br_if $label31
                local.get $var8
                i32.const 1
                i32.eq
                br_if $label31
                block $label33
                  local.get $var13
                  local.get $var9
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label32 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label33 $label31
                end $label33
                local.get $var8
                i32.const 2
                i32.eq
                br_if $label31
                block $label34
                  local.get $var12
                  local.get $var9
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label32 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label34 $label31
                end $label34
                local.get $var8
                i32.const 3
                i32.eq
                br_if $label31
                local.get $var11
                local.get $var9
                i32.add
                i32.load8_u
                local.tee $var25
                i32.const 92
                i32.eq
                br_if $label32
                local.get $var25
                i32.const 116
                i32.ne
                br_if $label31
                local.get $var8
                i32.const 4
                i32.eq
                br_if $label31
                block $label35
                  local.get $var10
                  local.get $var9
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label32 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label35 $label31
                end $label35
                local.get $var8
                i32.const 5
                i32.eq
                br_if $label31
                block $label36
                  local.get $var16
                  local.get $var9
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label32 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label31 $label36 $label31
                end $label36
                local.get $var8
                i32.const 6
                i32.eq
                br_if $label31
                local.get $var0
                local.get $var9
                i32.const 7
                i32.add
                local.tee $var26
                i32.add
                i32.load8_u
                local.tee $var25
                i32.const 92
                i32.eq
                br_if $label32
                local.get $var25
                i32.const 116
                i32.ne
                br_if $label31
                local.get $var26
                local.get $var2
                i32.ge_u
                br_if $label31
                local.get $var15
                local.get $var9
                i32.add
                i32.load8_u
                i32.const 34
                i32.eq
                local.set $var24
                br $label31
              end $label32
              local.get $var0
              local.get $var9
              local.get $var4
              i32.const 1040
              i32.const 7
              call $func14
              local.set $var24
            end $label31
            i32.const 0
            local.get $var8
            local.get $var8
            local.get $var2
            i32.gt_u
            select
            local.set $var27
            local.get $var9
            i32.const 4
            i32.add
            local.set $var28
            i32.const 1
            local.set $var25
            block $label37
              local.get $var2
              local.get $var9
              i32.gt_u
              local.tee $var8
              i32.eqz
              br_if $label37
              block $label38
                local.get $var0
                local.get $var22
                i32.add
                i32.load8_u
                local.tee $var26
                i32.const 92
                i32.eq
                br_if $label38
                local.get $var26
                i32.const 112
                i32.ne
                br_if $label37
                local.get $var27
                i32.const 1
                i32.eq
                br_if $label37
                block $label39
                  local.get $var13
                  local.get $var9
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label38 $label37 $label37 $label37 $label37 $label39 $label37
                end $label39
                local.get $var27
                i32.const 2
                i32.eq
                br_if $label37
                local.get $var12
                local.get $var9
                i32.add
                i32.load8_u
                local.tee $var26
                i32.const 92
                i32.eq
                br_if $label38
                local.get $var26
                i32.const 116
                i32.ne
                br_if $label37
                local.get $var27
                i32.const 3
                i32.eq
                br_if $label37
                block $label40
                  local.get $var0
                  local.get $var28
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label38 $label37 $label37 $label37 $label37 $label37 $label37 $label37 $label37 $label37 $label37 $label37 $label40 $label37
                end $label40
                local.get $var28
                local.get $var2
                i32.ge_u
                br_if $label37
                local.get $var10
                local.get $var9
                i32.add
                i32.load8_u
                i32.const 34
                i32.ne
                local.set $var25
                br $label37
              end $label38
              local.get $var0
              local.get $var9
              local.get $var4
              i32.const 1048
              i32.const 4
              call $func14
              i32.eqz
              local.set $var25
            end $label37
            block $label42
              block $label43
                block $label41
                  local.get $var3
                  i32.const 1
                  i32.ne
                  br_if $label41
                  i32.const 0
                  local.set $var26
                  local.get $var8
                  i32.eqz
                  br_if $label30
                  local.get $var0
                  local.get $var22
                  i32.add
                  i32.load8_u
                  local.tee $var8
                  i32.const 92
                  i32.eq
                  br_if $label42
                  local.get $var8
                  i32.const 116
                  i32.ne
                  br_if $label30
                  local.get $var27
                  i32.const 1
                  i32.ne
                  br_if $label43
                  br $label30
                end $label41
                i32.const 0
                local.set $var26
                local.get $var8
                i32.eqz
                br_if $label30
                block $label44
                  local.get $var0
                  local.get $var22
                  i32.add
                  i32.load8_u
                  local.tee $var8
                  i32.const 92
                  i32.eq
                  br_if $label44
                  local.get $var8
                  i32.const 116
                  i32.ne
                  br_if $label30
                  local.get $var27
                  i32.const 1
                  i32.eq
                  br_if $label30
                  block $label45
                    local.get $var13
                    local.get $var9
                    i32.add
                    i32.load8_u
                    i32.const -92
                    i32.add
                    br_table $label44 $label30 $label30 $label30 $label30 $label45 $label30
                  end $label45
                  local.get $var27
                  i32.const 2
                  i32.eq
                  br_if $label30
                  block $label46
                    local.get $var0
                    local.get $var9
                    i32.const 3
                    i32.add
                    local.tee $var8
                    i32.add
                    i32.load8_u
                    i32.const -92
                    i32.add
                    br_table $label44 $label30 $label30 $label30 $label30 $label30 $label30 $label30 $label30 $label30 $label30 $label46 $label30
                  end $label46
                  local.get $var8
                  local.get $var2
                  i32.ge_u
                  br_if $label30
                  local.get $var11
                  local.get $var9
                  i32.add
                  i32.load8_u
                  i32.const 34
                  i32.eq
                  local.set $var26
                  br $label30
                end $label44
                local.get $var0
                local.get $var9
                local.get $var4
                i32.const 1057
                i32.const 3
                call $func14
                local.set $var26
                br $label30
              end $label43
              local.get $var13
              local.get $var9
              i32.add
              i32.load8_u
              local.tee $var8
              i32.const 92
              i32.eq
              br_if $label42
              local.get $var8
              i32.const 121
              i32.ne
              br_if $label30
              local.get $var27
              i32.const 2
              i32.eq
              br_if $label30
              local.get $var12
              local.get $var9
              i32.add
              i32.load8_u
              local.tee $var8
              i32.const 92
              i32.eq
              br_if $label42
              local.get $var8
              i32.const 112
              i32.ne
              br_if $label30
              local.get $var27
              i32.const 3
              i32.eq
              br_if $label30
              block $label47
                local.get $var0
                local.get $var28
                i32.add
                i32.load8_u
                i32.const -92
                i32.add
                br_table $label42 $label30 $label30 $label30 $label30 $label30 $label30 $label30 $label30 $label47 $label30
              end $label47
              local.get $var28
              local.get $var2
              i32.ge_u
              br_if $label30
              local.get $var10
              local.get $var9
              i32.add
              i32.load8_u
              i32.const 34
              i32.eq
              local.set $var26
              br $label30
            end $label42
            local.get $var0
            local.get $var9
            local.get $var4
            i32.const 1061
            i32.const 4
            call $func14
            local.set $var26
          end $label30
          block $label48
            local.get $var4
            local.get $var1
            i32.ge_u
            br_if $label48
            loop $label49
              local.get $var0
              local.get $var4
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var2
              i32.const 23
              i32.gt_u
              br_if $label48
              i32.const 1
              local.get $var2
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label48
              local.get $var1
              local.get $var4
              i32.const 1
              i32.add
              local.tee $var4
              i32.ne
              br_if $label49
            end $label49
            i32.const 0
            local.set $var8
            br $label1
          end $label48
          i32.const 0
          local.set $var8
          local.get $var4
          local.get $var1
          i32.ge_u
          br_if $label1
          local.get $var0
          local.get $var4
          i32.add
          i32.load8_u
          i32.const 58
          i32.ne
          br_if $label1
          block $label50
            local.get $var4
            i32.const 1
            i32.add
            local.tee $var2
            local.get $var1
            i32.ge_u
            br_if $label50
            loop $label51
              local.get $var0
              local.get $var2
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var8
              i32.const 23
              i32.gt_u
              br_if $label50
              i32.const 1
              local.get $var8
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label50
              local.get $var1
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var2
              i32.ne
              br_if $label51
            end $label51
            local.get $var1
            local.set $var2
          end $label50
          block $label53
            block $label52
              local.get $var24
              i32.eqz
              br_if $label52
              local.get $var0
              local.get $var1
              local.get $var2
              i32.const 2
              local.get $var17
              local.get $var7
              i32.const 12
              i32.add
              local.get $var7
              call $func11
              br_if $label53
              i32.const 0
              local.set $var8
              br $label1
            end $label52
            local.get $var0
            local.get $var1
            local.get $var2
            local.get $var7
            i32.const 12
            i32.add
            call $func12
            br_if $label53
            i32.const 0
            local.set $var8
            br $label1
          end $label53
          block $label54
            local.get $var25
            br_if $label54
            i32.const 0
            local.set $var18
            i32.const 0
            local.set $var19
            i32.const 0
            local.set $var20
            local.get $var0
            local.get $var2
            i32.add
            i32.load8_u
            i32.const 34
            i32.ne
            br_if $label54
            local.get $var7
            i32.load offset=12
            local.get $var2
            i32.sub
            local.set $var18
            i32.const 1
            local.set $var20
            local.get $var2
            local.set $var19
          end $label54
          local.get $var7
          i32.load offset=12
          local.set $var9
          block $label55
            local.get $var26
            i32.eqz
            br_if $label55
            block $label57
              block $label58
                block $label64
                  block $label56
                    local.get $var3
                    i32.const 1
                    i32.ne
                    br_if $label56
                    local.get $var2
                    local.get $var9
                    i32.ge_u
                    br_if $label57
                    local.get $var0
                    local.get $var2
                    i32.add
                    i32.load8_u
                    i32.const 34
                    i32.ne
                    br_if $label57
                    local.get $var2
                    i32.const 6
                    i32.add
                    local.set $var4
                    local.get $var9
                    local.get $var2
                    i32.const -1
                    i32.xor
                    i32.add
                    local.tee $var8
                    i32.eqz
                    br_if $label58
                    block $label63
                      block $label59
                        local.get $var14
                        local.get $var2
                        i32.add
                        i32.load8_u
                        local.tee $var22
                        i32.const 92
                        i32.eq
                        br_if $label59
                        local.get $var22
                        i32.const 105
                        i32.ne
                        br_if $label58
                        local.get $var8
                        i32.const 1
                        i32.eq
                        br_if $label58
                        block $label60
                          local.get $var13
                          local.get $var2
                          i32.add
                          i32.load8_u
                          i32.const -92
                          i32.add
                          br_table $label59 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label60 $label58
                        end $label60
                        local.get $var8
                        i32.const 2
                        i32.eq
                        br_if $label58
                        block $label61
                          local.get $var12
                          local.get $var2
                          i32.add
                          i32.load8_u
                          i32.const -92
                          i32.add
                          br_table $label59 $label58 $label58 $label58 $label58 $label61 $label58
                        end $label61
                        local.get $var8
                        i32.const 3
                        i32.eq
                        br_if $label58
                        block $label62
                          local.get $var11
                          local.get $var2
                          i32.add
                          i32.load8_u
                          i32.const -92
                          i32.add
                          br_table $label59 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label62 $label58
                        end $label62
                        local.get $var8
                        i32.const 4
                        i32.eq
                        br_if $label58
                        local.get $var10
                        local.get $var2
                        i32.add
                        i32.load8_u
                        i32.const -92
                        i32.add
                        br_table $label59 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label58 $label63 $label58
                      end $label59
                      local.get $var0
                      local.get $var2
                      local.get $var9
                      i32.const 1066
                      i32.const 5
                      call $func14
                      i32.eqz
                      br_if $label58
                      i32.const 1
                      local.set $var21
                      br $label55
                    end $label63
                    local.get $var4
                    local.get $var9
                    i32.lt_u
                    br_if $label64
                    br $label58
                  end $label56
                  i32.const 0
                  local.set $var21
                  local.get $var2
                  local.get $var9
                  i32.ge_u
                  br_if $label55
                  local.get $var0
                  local.get $var2
                  i32.add
                  i32.load8_u
                  i32.const 34
                  i32.ne
                  br_if $label55
                  local.get $var9
                  local.get $var2
                  i32.const -1
                  i32.xor
                  i32.add
                  local.tee $var8
                  i32.eqz
                  br_if $label55
                  block $label65
                    local.get $var14
                    local.get $var2
                    i32.add
                    i32.load8_u
                    local.tee $var4
                    i32.const 92
                    i32.eq
                    br_if $label65
                    local.get $var4
                    i32.const 105
                    i32.ne
                    br_if $label55
                    local.get $var8
                    i32.const 1
                    i32.eq
                    br_if $label55
                    block $label66
                      local.get $var13
                      local.get $var2
                      i32.add
                      i32.load8_u
                      i32.const -92
                      i32.add
                      br_table $label65 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label66 $label55
                    end $label66
                    local.get $var8
                    i32.const 2
                    i32.eq
                    br_if $label55
                    block $label67
                      local.get $var12
                      local.get $var2
                      i32.add
                      i32.load8_u
                      i32.const -92
                      i32.add
                      br_table $label65 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label55 $label67 $label55
                    end $label67
                    local.get $var2
                    i32.const 4
                    i32.add
                    local.tee $var2
                    local.get $var9
                    i32.ge_u
                    br_if $label55
                    local.get $var0
                    local.get $var2
                    i32.add
                    i32.load8_u
                    i32.const 34
                    i32.eq
                    local.set $var21
                    br $label55
                  end $label65
                  local.get $var0
                  local.get $var2
                  local.get $var9
                  i32.const 1053
                  i32.const 3
                  call $func14
                  local.set $var21
                  br $label55
                end $label64
                local.get $var0
                local.get $var4
                i32.add
                i32.load8_u
                i32.const 34
                i32.ne
                br_if $label58
                i32.const 1
                local.set $var21
                br $label55
              end $label58
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var8
              local.get $var9
              i32.ge_u
              br_if $label57
              block $label68
                local.get $var0
                local.get $var8
                i32.add
                i32.load8_u
                local.tee $var8
                i32.const 92
                i32.eq
                br_if $label68
                local.get $var8
                i32.const 115
                i32.ne
                br_if $label57
                local.get $var2
                i32.const 2
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                local.get $var0
                local.get $var8
                i32.add
                i32.load8_u
                local.tee $var8
                i32.const 92
                i32.eq
                br_if $label68
                local.get $var8
                i32.const 116
                i32.ne
                br_if $label57
                local.get $var2
                i32.const 3
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                local.get $var0
                local.get $var8
                i32.add
                i32.load8_u
                local.tee $var8
                i32.const 92
                i32.eq
                br_if $label68
                local.get $var8
                i32.const 114
                i32.ne
                br_if $label57
                local.get $var2
                i32.const 4
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                local.get $var0
                local.get $var8
                i32.add
                i32.load8_u
                local.tee $var8
                i32.const 92
                i32.eq
                br_if $label68
                local.get $var8
                i32.const 117
                i32.ne
                br_if $label57
                local.get $var2
                i32.const 5
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                block $label69
                  local.get $var0
                  local.get $var8
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label68 $label57 $label57 $label57 $label57 $label57 $label57 $label69 $label57
                end $label69
                local.get $var4
                local.get $var9
                i32.ge_u
                br_if $label57
                local.get $var0
                local.get $var4
                i32.add
                i32.load8_u
                local.tee $var8
                i32.const 92
                i32.eq
                br_if $label68
                local.get $var8
                i32.const 116
                i32.ne
                br_if $label57
                local.get $var2
                i32.const 7
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                local.get $var0
                local.get $var8
                i32.add
                i32.load8_u
                local.tee $var8
                i32.const 92
                i32.eq
                br_if $label68
                local.get $var8
                i32.const 117
                i32.ne
                br_if $label57
                local.get $var2
                i32.const 8
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                local.get $var0
                local.get $var8
                i32.add
                i32.load8_u
                local.tee $var8
                i32.const 92
                i32.eq
                br_if $label68
                local.get $var8
                i32.const 114
                i32.ne
                br_if $label57
                local.get $var2
                i32.const 9
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                block $label70
                  local.get $var0
                  local.get $var8
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label68 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label70 $label57
                end $label70
                local.get $var2
                i32.const 10
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                block $label71
                  local.get $var0
                  local.get $var8
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label68 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label71 $label57
                end $label71
                local.get $var2
                i32.const 11
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                local.get $var0
                local.get $var8
                i32.add
                i32.load8_u
                local.tee $var8
                i32.const 92
                i32.eq
                br_if $label68
                local.get $var8
                i32.const 45
                i32.ne
                br_if $label57
                local.get $var2
                i32.const 12
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                block $label72
                  local.get $var0
                  local.get $var8
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label68 $label57 $label57 $label57 $label57 $label57 $label57 $label72 $label57
                end $label72
                local.get $var2
                i32.const 13
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                block $label73
                  local.get $var0
                  local.get $var8
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label68 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label73 $label57
                end $label73
                local.get $var2
                i32.const 14
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                block $label74
                  local.get $var0
                  local.get $var8
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label68 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label74 $label57
                end $label74
                local.get $var2
                i32.const 15
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                local.get $var0
                local.get $var8
                i32.add
                i32.load8_u
                local.tee $var8
                i32.const 92
                i32.eq
                br_if $label68
                local.get $var8
                i32.const 116
                i32.ne
                br_if $label57
                local.get $var2
                i32.const 16
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                block $label75
                  local.get $var0
                  local.get $var8
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label68 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label75 $label57
                end $label75
                local.get $var2
                i32.const 17
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                block $label76
                  local.get $var0
                  local.get $var8
                  i32.add
                  i32.load8_u
                  i32.const -92
                  i32.add
                  br_table $label68 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label57 $label76 $label57
                end $label76
                local.get $var2
                i32.const 18
                i32.add
                local.tee $var8
                local.get $var9
                i32.ge_u
                br_if $label57
                local.get $var0
                local.get $var8
                i32.add
                i32.load8_u
                local.tee $var8
                i32.const 92
                i32.eq
                br_if $label68
                local.get $var8
                i32.const 116
                i32.ne
                br_if $label57
                local.get $var2
                i32.const 19
                i32.add
                local.tee $var2
                local.get $var9
                i32.ge_u
                br_if $label57
                local.get $var0
                local.get $var2
                i32.add
                i32.load8_u
                i32.const 34
                i32.ne
                br_if $label57
                i32.const 2
                local.set $var21
                br $label55
              end $label68
              local.get $var0
              local.get $var2
              local.get $var9
              i32.const 1029
              i32.const 18
              call $func14
              i32.eqz
              br_if $label57
              i32.const 2
              local.set $var21
              br $label55
            end $label57
            i32.const 0
            local.set $var21
          end $label55
          block $label77
            local.get $var9
            local.get $var1
            i32.ge_u
            br_if $label77
            loop $label78
              local.get $var0
              local.get $var9
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var2
              i32.const 23
              i32.gt_u
              br_if $label77
              i32.const 1
              local.get $var2
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label77
              local.get $var1
              local.get $var9
              i32.const 1
              i32.add
              local.tee $var9
              i32.ne
              br_if $label78
            end $label78
            i32.const 0
            local.set $var8
            br $label1
          end $label77
          i32.const 0
          local.set $var8
          local.get $var9
          local.get $var1
          i32.ge_u
          br_if $label1
          block $label79
            local.get $var0
            local.get $var9
            i32.add
            i32.load8_u
            local.tee $var2
            i32.const 44
            i32.eq
            br_if $label79
            local.get $var2
            i32.const 125
            i32.ne
            br_if $label1
            block $label81
              block $label80
                local.get $var21
                i32.const 1
                i32.ne
                br_if $label80
                local.get $var6
                local.get $var18
                i32.store offset=8
                local.get $var6
                local.get $var19
                i32.store offset=4
                local.get $var6
                local.get $var20
                i32.store
                br $label81
              end $label80
              block $label83
                block $label82
                  local.get $var3
                  i32.const 2
                  i32.eq
                  br_if $label82
                  local.get $var21
                  i32.const 2
                  i32.ne
                  br_if $label83
                end $label82
                local.get $var6
                local.get $var7
                i64.load
                i64.store align=4
                local.get $var6
                i32.const 8
                i32.add
                local.get $var7
                i32.const 8
                i32.add
                i32.load
                i32.store
                br $label81
              end $label83
              local.get $var6
              i32.const 0
              i32.store offset=8
              local.get $var6
              i64.const 0
              i64.store align=4
            end $label81
            i32.const 1
            local.set $var8
            local.get $var5
            local.get $var9
            i32.const 1
            i32.add
            i32.store
            br $label1
          end $label79
          block $label84
            local.get $var9
            i32.const 1
            i32.add
            local.tee $var9
            local.get $var1
            i32.ge_u
            br_if $label84
            loop $label85
              local.get $var0
              local.get $var9
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var2
              i32.const 23
              i32.gt_u
              br_if $label84
              i32.const 1
              local.get $var2
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label84
              local.get $var1
              local.get $var9
              i32.const 1
              i32.add
              local.tee $var9
              i32.ne
              br_if $label85
              br $label1
            end $label85
          end $label84
          local.get $var9
          local.get $var1
          i32.ge_u
          br_if $label1
          i32.const 0
          local.set $var8
          local.get $var0
          local.get $var9
          i32.add
          i32.load8_u
          i32.const 125
          i32.ne
          br_if $label86
          br $label1
        end $label86
      end $label8
      i32.const 2
      i32.const 1
      local.get $var3
      select
      local.set $var3
      local.get $var4
      i32.const 1
      i32.add
      local.set $var4
      loop $label95
        block $label87
          local.get $var2
          local.get $var1
          i32.lt_u
          br_if $label87
          i32.const 0
          local.set $var8
          br $label1
        end $label87
        i32.const 0
        local.set $var8
        local.get $var0
        local.get $var1
        local.get $var2
        local.get $var3
        local.get $var4
        local.get $var7
        i32.const 12
        i32.add
        local.get $var7
        call $func11
        i32.eqz
        br_if $label1
        block $label88
          local.get $var7
          i32.load
          i32.eqz
          br_if $label88
          block $label89
            local.get $var6
            i32.load
            br_if $label89
            local.get $var6
            local.get $var7
            i64.load align=4
            i64.store align=4
            local.get $var6
            i32.const 8
            i32.add
            local.get $var7
            i32.const 8
            i32.add
            i32.load
            i32.store
            br $label88
          end $label89
          local.get $var6
          i32.const 2
          i32.store
        end $label88
        block $label90
          local.get $var7
          i32.load offset=12
          local.tee $var2
          local.get $var1
          i32.ge_u
          br_if $label90
          loop $label91
            local.get $var0
            local.get $var2
            i32.add
            i32.load8_u
            i32.const -9
            i32.add
            local.tee $var9
            i32.const 23
            i32.gt_u
            br_if $label90
            i32.const 1
            local.get $var9
            i32.shl
            i32.const 8388627
            i32.and
            i32.eqz
            br_if $label90
            local.get $var1
            local.get $var2
            i32.const 1
            i32.add
            local.tee $var2
            i32.ne
            br_if $label91
            br $label1
          end $label91
        end $label90
        local.get $var2
        local.get $var1
        i32.ge_u
        br_if $label1
        block $label92
          local.get $var0
          local.get $var2
          i32.add
          i32.load8_u
          local.tee $var9
          i32.const 44
          i32.eq
          br_if $label92
          local.get $var9
          i32.const 93
          i32.ne
          br_if $label1
          i32.const 1
          local.set $var8
          local.get $var5
          local.get $var2
          i32.const 1
          i32.add
          i32.store
          br $label1
        end $label92
        block $label93
          local.get $var2
          i32.const 1
          i32.add
          local.tee $var2
          local.get $var1
          i32.ge_u
          br_if $label93
          loop $label94
            local.get $var0
            local.get $var2
            i32.add
            i32.load8_u
            i32.const -9
            i32.add
            local.tee $var9
            i32.const 23
            i32.gt_u
            br_if $label93
            i32.const 1
            local.get $var9
            i32.shl
            i32.const 8388627
            i32.and
            i32.eqz
            br_if $label93
            local.get $var1
            local.get $var2
            i32.const 1
            i32.add
            local.tee $var2
            i32.ne
            br_if $label94
            br $label1
          end $label94
        end $label93
        local.get $var2
        local.get $var1
        i32.ge_u
        br_if $label1
        i32.const 0
        local.set $var8
        local.get $var0
        local.get $var2
        i32.add
        i32.load8_u
        i32.const 93
        i32.ne
        br_if $label95
      end $label95
    end $label1
    local.get $var7
    i32.const 16
    i32.add
    global.set $global0
    local.get $var8
  )
  (func $func12 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (result i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    (local $var8 i32)
    (local $var9 i64)
    (local $var10 i32)
    i32.const 0
    local.set $var4
    block $label0
      local.get $var2
      local.get $var1
      i32.ge_u
      br_if $label0
      block $label1
        local.get $var0
        local.get $var2
        i32.add
        i32.load8_u
        local.tee $var5
        i32.const 34
        i32.ne
        br_if $label1
        local.get $var2
        i32.const 1
        i32.add
        local.tee $var5
        local.get $var1
        i32.ge_u
        br_if $label0
        local.get $var0
        i32.const 5
        i32.add
        local.set $var6
        local.get $var0
        i32.const 4
        i32.add
        local.set $var7
        local.get $var0
        i32.const 3
        i32.add
        local.set $var8
        loop $label3
          block $label2
            local.get $var5
            local.tee $var2
            i32.const 8
            i32.add
            local.tee $var5
            local.get $var1
            i32.gt_u
            br_if $label2
            local.get $var0
            local.get $var2
            i32.add
            i64.load align=1
            local.tee $var9
            i64.const -1
            i64.xor
            local.get $var9
            i64.const 2459565876494606882
            i64.xor
            i64.const -72340172838076673
            i64.add
            local.get $var9
            i64.const 6655295901103053916
            i64.xor
            i64.const -72340172838076673
            i64.add
            i64.or
            local.get $var9
            i64.const -2314885530818453536
            i64.add
            i64.or
            i64.and
            i64.const -9187201950435737472
            i64.and
            local.tee $var9
            i64.eqz
            br_if $label3
            local.get $var9
            i64.ctz
            i32.wrap_i64
            i32.const 3
            i32.shr_u
            local.get $var2
            i32.add
            local.set $var2
          end $label2
          local.get $var2
          local.get $var1
          i32.ge_u
          br_if $label0
          block $label7
            block $label5
              block $label4
                local.get $var0
                local.get $var2
                i32.add
                i32.load8_u
                local.tee $var10
                i32.const 92
                i32.ne
                br_if $label4
                local.get $var2
                i32.const 1
                i32.add
                local.tee $var5
                local.get $var1
                i32.ge_u
                br_if $label0
                block $label6
                  local.get $var0
                  local.get $var5
                  i32.add
                  i32.load8_u
                  i32.const -34
                  i32.add
                  br_table $label5 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label5 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label5 $label0 $label0 $label0 $label0 $label0 $label5 $label0 $label0 $label0 $label5 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label5 $label0 $label0 $label0 $label5 $label0 $label5 $label6 $label0
                end $label6
                local.get $var2
                i32.const 6
                i32.add
                local.tee $var5
                local.get $var1
                i32.gt_u
                br_if $label0
                local.get $var2
                i32.const 2
                i32.add
                local.tee $var10
                local.get $var5
                i32.ge_u
                br_if $label7
                block $label8
                  local.get $var0
                  local.get $var10
                  i32.add
                  i32.load8_u
                  local.tee $var10
                  i32.const -58
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 245
                  i32.gt_u
                  br_if $label8
                  local.get $var10
                  i32.const -33
                  i32.and
                  i32.const -71
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 250
                  i32.lt_u
                  br_if $label0
                end $label8
                block $label9
                  local.get $var8
                  local.get $var2
                  i32.add
                  i32.load8_u
                  local.tee $var10
                  i32.const -58
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 245
                  i32.gt_u
                  br_if $label9
                  local.get $var10
                  i32.const -33
                  i32.and
                  i32.const -71
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 250
                  i32.lt_u
                  br_if $label0
                end $label9
                block $label10
                  local.get $var7
                  local.get $var2
                  i32.add
                  i32.load8_u
                  local.tee $var10
                  i32.const -58
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 245
                  i32.gt_u
                  br_if $label10
                  local.get $var10
                  i32.const -33
                  i32.and
                  i32.const -71
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 250
                  i32.lt_u
                  br_if $label0
                end $label10
                local.get $var6
                local.get $var2
                i32.add
                i32.load8_u
                local.tee $var2
                i32.const -58
                i32.add
                i32.const 255
                i32.and
                i32.const 245
                i32.gt_u
                br_if $label7
                local.get $var2
                i32.const -33
                i32.and
                i32.const -71
                i32.add
                i32.const 255
                i32.and
                i32.const 250
                i32.ge_u
                br_if $label7
                br $label0
              end $label4
              local.get $var10
              i32.const 32
              i32.lt_u
              br_if $label0
              local.get $var2
              i32.const 1
              i32.add
              local.set $var5
              local.get $var10
              i32.const 34
              i32.ne
              br_if $label7
              local.get $var3
              local.get $var5
              i32.store
              i32.const 1
              return
            end $label5
            local.get $var2
            i32.const 2
            i32.add
            local.set $var5
          end $label7
          local.get $var5
          local.get $var1
          i32.lt_u
          br_if $label3
          br $label0
        end $label3
      end $label1
      block $label11
        local.get $var5
        i32.const 223
        i32.and
        i32.const 91
        i32.ne
        br_if $label11
        local.get $var0
        local.get $var1
        local.get $var2
        local.get $var3
        i32.const 0
        i32.const 0
        i32.const 0
        i32.const 0
        call $func13
        return
      end $label11
      local.get $var0
      local.get $var1
      local.get $var2
      local.get $var3
      call $func47
      local.set $var4
    end $label0
    local.get $var4
  )
  (func $func13 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (result i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 i32)
    (local $var23 i32)
    (local $var24 i32)
    (local $var25 i32)
    (local $var26 i32)
    (local $var27 i32)
    (local $var28 i32)
    (local $var29 i64)
    (local $var30 i32)
    (local $var31 v128)
    (local $var32 i32)
    (local $var33 i32)
    (local $var34 i32)
    global.get $global0
    i32.const 272
    i32.sub
    local.tee $var8
    global.set $global0
    i32.const 0
    local.set $var9
    block $label0
      local.get $var2
      local.get $var1
      i32.ge_u
      br_if $label0
      local.get $var0
      local.get $var2
      i32.add
      i32.load8_u
      local.tee $var10
      i32.const 32
      i32.or
      i32.const 123
      i32.ne
      br_if $label0
      i32.const 0
      local.set $var9
      local.get $var2
      i32.const 1
      i32.add
      local.tee $var11
      local.get $var1
      i32.ge_u
      br_if $label0
      local.get $var7
      i32.const 0
      i32.ne
      local.get $var10
      i32.const 91
      i32.eq
      local.tee $var2
      i32.and
      local.set $var12
      local.get $var0
      i32.const 1
      i32.add
      local.set $var13
      i32.const 0
      i32.const 3
      local.get $var2
      select
      local.set $var14
      local.get $var0
      i32.const 4
      i32.add
      local.set $var15
      local.get $var0
      i32.const 3
      i32.add
      local.set $var16
      local.get $var0
      i32.const 2
      i32.add
      local.set $var17
      local.get $var0
      i32.const 5
      i32.add
      local.set $var18
      i32.const 1
      local.set $var19
      i32.const 0
      local.set $var20
      i32.const 0
      local.set $var21
      i32.const 0
      local.set $var22
      i32.const 0
      local.set $var23
      i32.const 0
      local.set $var24
      i32.const 0
      local.set $var25
      block $label46
        loop $label158
          block $label10
            block $label99
              block $label62
                block $label63
                  block $label11
                    block $label16
                      block $label2
                        block $label5
                          block $label4
                            block $label45
                              block $label8
                                block $label7
                                  block $label3
                                    block $label1
                                      block $label6
                                        local.get $var0
                                        local.get $var11
                                        i32.add
                                        local.tee $var26
                                        i32.load8_u
                                        local.tee $var2
                                        i32.const -9
                                        i32.add
                                        br_table $label1 $label1 $label2 $label2 $label1 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label1 $label2 $label3 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label4 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label5 $label6
                                      end $label6
                                      local.get $var2
                                      i32.const 93
                                      i32.eq
                                      br_if $label7
                                      local.get $var2
                                      i32.const 125
                                      i32.ne
                                      br_if $label2
                                      i32.const 0
                                      local.set $var9
                                      local.get $var14
                                      i32.const 255
                                      i32.and
                                      i32.const -3
                                      i32.add
                                      br_table $label8 $label0 $label0 $label8 $label0
                                    end $label1
                                    block $label9
                                      local.get $var5
                                      i32.eqz
                                      br_if $label9
                                      local.get $var5
                                      i32.load
                                      br_if $label9
                                      local.get $var5
                                      i32.const 1
                                      i32.store
                                    end $label9
                                    local.get $var11
                                    i32.const 1
                                    i32.add
                                    local.set $var11
                                    br $label10
                                  end $label3
                                  local.get $var14
                                  i32.const 251
                                  i32.and
                                  local.tee $var27
                                  i32.const 3
                                  i32.ne
                                  local.tee $var28
                                  br_if $label11
                                  block $label15
                                    block $label13
                                      block $label14
                                        block $label12
                                          local.get $var1
                                          local.get $var11
                                          i32.sub
                                          local.tee $var2
                                          i32.const 9
                                          i32.lt_u
                                          br_if $label12
                                          local.get $var26
                                          i64.load align=1
                                          local.tee $var29
                                          i64.const 8389754706581218082
                                          i64.eq
                                          br_if $label13
                                          local.get $var29
                                          i32.wrap_i64
                                          local.set $var2
                                          br $label14
                                        end $label12
                                        local.get $var2
                                        i32.const 5
                                        i32.lt_u
                                        br_if $label11
                                        local.get $var26
                                        i32.load align=1
                                        local.set $var2
                                      end $label14
                                      local.get $var2
                                      i32.const 1734439970
                                      i32.ne
                                      br_if $label11
                                      local.get $var26
                                      i32.const 4
                                      i32.add
                                      i32.load8_u
                                      i32.const 34
                                      i32.eq
                                      br_if $label15
                                      br $label11
                                    end $label13
                                    local.get $var26
                                    i32.const 8
                                    i32.add
                                    i32.load8_u
                                    i32.const 34
                                    i32.ne
                                    br_if $label11
                                    local.get $var11
                                    i32.const 9
                                    i32.add
                                    local.set $var2
                                    i32.const 1
                                    local.set $var9
                                    i32.const 4
                                    local.set $var7
                                    br $label16
                                  end $label15
                                  i32.const 0
                                  local.set $var7
                                  block $label17
                                    local.get $var11
                                    i32.const 5
                                    i32.add
                                    local.tee $var2
                                    local.get $var1
                                    i32.lt_u
                                    br_if $label17
                                    i32.const 0
                                    local.set $var9
                                    br $label16
                                  end $label17
                                  i32.const 0
                                  local.set $var7
                                  block $label18
                                    local.get $var0
                                    local.get $var2
                                    i32.add
                                    i32.load8_u
                                    i32.const 58
                                    i32.eq
                                    br_if $label18
                                    i32.const 0
                                    local.set $var9
                                    br $label16
                                  end $label18
                                  block $label19
                                    local.get $var11
                                    i32.const 6
                                    i32.add
                                    local.tee $var10
                                    local.get $var1
                                    i32.ge_u
                                    br_if $label19
                                    local.get $var11
                                    i32.const 7
                                    i32.add
                                    local.get $var10
                                    local.get $var0
                                    local.get $var10
                                    i32.add
                                    i32.load8_u
                                    i32.const 32
                                    i32.eq
                                    select
                                    local.set $var10
                                  end $label19
                                  i32.const 0
                                  local.set $var7
                                  block $label20
                                    local.get $var1
                                    local.get $var10
                                    i32.sub
                                    local.tee $var9
                                    i32.const 4
                                    i32.ge_u
                                    br_if $label20
                                    i32.const 0
                                    local.set $var9
                                    br $label16
                                  end $label20
                                  i32.const 0
                                  local.set $var7
                                  block $label31
                                    block $label24
                                      block $label22
                                        block $label21
                                          local.get $var0
                                          local.get $var10
                                          i32.add
                                          local.tee $var14
                                          i32.load align=1
                                          local.tee $var11
                                          i32.const 740450593
                                          i32.gt_s
                                          br_if $label21
                                          local.get $var11
                                          i32.const 577334306
                                          i32.eq
                                          br_if $label22
                                          local.get $var11
                                          i32.const 577533218
                                          i32.eq
                                          br_if $label22
                                          local.get $var11
                                          i32.const 578056738
                                          i32.eq
                                          br_if $label22
                                          i32.const 0
                                          local.set $var9
                                          br $label16
                                        end $label21
                                        block $label26
                                          block $label25
                                            block $label23
                                              local.get $var11
                                              i32.const 1651864097
                                              i32.gt_s
                                              br_if $label23
                                              local.get $var11
                                              i32.const 740450594
                                              i32.eq
                                              br_if $label24
                                              local.get $var11
                                              i32.const 1634759458
                                              i32.eq
                                              br_if $label25
                                              i32.const 0
                                              local.set $var9
                                              br $label16
                                            end $label23
                                            local.get $var11
                                            i32.const 1651864098
                                            i32.eq
                                            br_if $label26
                                            block $label27
                                              local.get $var11
                                              i32.const 1986618402
                                              i32.eq
                                              br_if $label27
                                              i32.const 0
                                              local.set $var9
                                              br $label16
                                            end $label27
                                            i32.const 0
                                            local.set $var7
                                            block $label28
                                              local.get $var9
                                              i32.const 6
                                              i32.ge_u
                                              br_if $label28
                                              i32.const 0
                                              local.set $var9
                                              br $label16
                                            end $label28
                                            i32.const 0
                                            local.set $var7
                                            block $label29
                                              local.get $var14
                                              i32.const 4
                                              i32.add
                                              i32.load8_u
                                              i32.const 34
                                              i32.eq
                                              br_if $label29
                                              i32.const 0
                                              local.set $var9
                                              br $label16
                                            end $label29
                                            i32.const 0
                                            local.set $var7
                                            block $label30
                                              local.get $var14
                                              i32.const 5
                                              i32.add
                                              i32.load8_u
                                              i32.const 44
                                              i32.eq
                                              br_if $label30
                                              i32.const 0
                                              local.set $var9
                                              br $label16
                                            end $label30
                                            local.get $var10
                                            i32.const 6
                                            i32.add
                                            local.set $var11
                                            br $label31
                                          end $label25
                                          i32.const 0
                                          local.set $var7
                                          block $label32
                                            local.get $var9
                                            i32.const 7
                                            i32.ge_u
                                            br_if $label32
                                            i32.const 0
                                            local.set $var9
                                            br $label16
                                          end $label32
                                          i32.const 0
                                          local.set $var7
                                          block $label33
                                            local.get $var14
                                            i32.const 4
                                            i32.add
                                            i32.load8_u
                                            i32.const 110
                                            i32.eq
                                            br_if $label33
                                            i32.const 0
                                            local.set $var9
                                            br $label16
                                          end $label33
                                          i32.const 0
                                          local.set $var7
                                          block $label34
                                            local.get $var14
                                            i32.const 5
                                            i32.add
                                            i32.load8_u
                                            i32.const 34
                                            i32.eq
                                            br_if $label34
                                            i32.const 0
                                            local.set $var9
                                            br $label16
                                          end $label34
                                          i32.const 0
                                          local.set $var7
                                          block $label35
                                            local.get $var14
                                            i32.const 6
                                            i32.add
                                            i32.load8_u
                                            i32.const 44
                                            i32.eq
                                            br_if $label35
                                            i32.const 0
                                            local.set $var9
                                            br $label16
                                          end $label35
                                          local.get $var10
                                          i32.const 7
                                          i32.add
                                          local.set $var11
                                          br $label31
                                        end $label26
                                        i32.const 0
                                        local.set $var7
                                        block $label36
                                          local.get $var9
                                          i32.const 7
                                          i32.ge_u
                                          br_if $label36
                                          i32.const 0
                                          local.set $var9
                                          br $label16
                                        end $label36
                                        i32.const 0
                                        local.set $var7
                                        block $label37
                                          local.get $var14
                                          i32.const 4
                                          i32.add
                                          i32.load8_u
                                          i32.const 121
                                          i32.eq
                                          br_if $label37
                                          i32.const 0
                                          local.set $var9
                                          br $label16
                                        end $label37
                                        i32.const 0
                                        local.set $var7
                                        block $label38
                                          local.get $var14
                                          i32.const 5
                                          i32.add
                                          i32.load8_u
                                          i32.const 34
                                          i32.eq
                                          br_if $label38
                                          i32.const 0
                                          local.set $var9
                                          br $label16
                                        end $label38
                                        i32.const 0
                                        local.set $var7
                                        block $label39
                                          local.get $var14
                                          i32.const 6
                                          i32.add
                                          i32.load8_u
                                          i32.const 44
                                          i32.eq
                                          br_if $label39
                                          i32.const 0
                                          local.set $var9
                                          br $label16
                                        end $label39
                                        local.get $var10
                                        i32.const 7
                                        i32.add
                                        local.set $var11
                                        br $label31
                                      end $label22
                                      i32.const 0
                                      local.set $var7
                                      block $label40
                                        local.get $var9
                                        i32.const 4
                                        i32.ne
                                        br_if $label40
                                        i32.const 0
                                        local.set $var9
                                        br $label16
                                      end $label40
                                      i32.const 0
                                      local.set $var7
                                      block $label41
                                        local.get $var14
                                        i32.const 4
                                        i32.add
                                        i32.load8_u
                                        i32.const 44
                                        i32.eq
                                        br_if $label41
                                        i32.const 0
                                        local.set $var9
                                        br $label16
                                      end $label41
                                      local.get $var10
                                      i32.const 5
                                      i32.add
                                      local.set $var11
                                      br $label31
                                    end $label24
                                    local.get $var10
                                    i32.const 4
                                    i32.add
                                    local.set $var11
                                  end $label31
                                  block $label42
                                    local.get $var11
                                    br_if $label42
                                    i32.const 0
                                    local.set $var7
                                    i32.const 0
                                    local.set $var9
                                    br $label16
                                  end $label42
                                  block $label43
                                    local.get $var5
                                    i32.eqz
                                    br_if $label43
                                    local.get $var13
                                    local.get $var2
                                    i32.add
                                    i32.load8_u
                                    i32.const 32
                                    i32.ne
                                    br_if $label43
                                    local.get $var5
                                    i32.const 1
                                    i32.store
                                  end $label43
                                  i32.const 0
                                  local.get $var20
                                  local.get $var19
                                  i32.const 2
                                  i32.eq
                                  select
                                  local.get $var20
                                  local.get $var12
                                  select
                                  local.set $var20
                                  i32.const 7
                                  local.set $var14
                                  local.get $var11
                                  local.get $var1
                                  i32.ge_u
                                  br_if $label10
                                  local.get $var0
                                  local.get $var11
                                  i32.add
                                  i32.load8_u
                                  i32.const 32
                                  i32.ne
                                  br_if $label10
                                  block $label44
                                    local.get $var5
                                    i32.eqz
                                    br_if $label44
                                    local.get $var5
                                    i32.const 1
                                    i32.store
                                  end $label44
                                  local.get $var11
                                  i32.const 1
                                  i32.add
                                  local.set $var11
                                  br $label10
                                end $label7
                                local.get $var14
                                i32.const 255
                                i32.and
                                i32.const 1
                                i32.le_u
                                br_if $label45
                                br $label46
                              end $label8
                              local.get $var12
                              local.get $var19
                              i32.const 2
                              i32.eq
                              i32.and
                              i32.const 1
                              i32.ne
                              br_if $label45
                              local.get $var21
                              local.get $var22
                              i32.and
                              i32.eqz
                              br_if $label0
                            end $label45
                            local.get $var11
                            i32.const 1
                            i32.add
                            local.set $var11
                            block $label47
                              local.get $var19
                              i32.const -1
                              i32.add
                              local.tee $var2
                              br_if $label47
                              local.get $var3
                              local.get $var11
                              i32.store
                              i32.const 1
                              local.set $var9
                              br $label0
                            end $label47
                            local.get $var19
                            local.get $var8
                            i32.const 16
                            i32.add
                            i32.add
                            i32.const -2
                            i32.add
                            i32.load8_u
                            local.set $var14
                            local.get $var2
                            local.set $var19
                            br $label10
                          end $label4
                          local.get $var14
                          i32.const 255
                          i32.and
                          local.set $var2
                          i32.const 2
                          local.set $var14
                          i32.const 0
                          local.set $var9
                          block $label48
                            block $label49
                              local.get $var2
                              i32.const -1
                              i32.add
                              br_table $label48 $label0 $label0 $label0 $label0 $label49 $label0
                            end $label49
                            i32.const 7
                            local.set $var14
                          end $label48
                          block $label50
                            local.get $var11
                            i32.const 1
                            i32.add
                            local.tee $var2
                            local.get $var1
                            i32.lt_u
                            br_if $label50
                            local.get $var2
                            local.set $var11
                            br $label10
                          end $label50
                          block $label51
                            local.get $var0
                            local.get $var2
                            i32.add
                            i32.load8_u
                            i32.const 32
                            i32.eq
                            br_if $label51
                            local.get $var2
                            local.set $var11
                            br $label10
                          end $label51
                          block $label52
                            local.get $var5
                            i32.eqz
                            br_if $label52
                            local.get $var5
                            i32.const 1
                            i32.store
                          end $label52
                          local.get $var11
                          i32.const 2
                          i32.add
                          local.set $var11
                          br $label10
                        end $label5
                        local.get $var14
                        i32.const 255
                        i32.and
                        i32.const 4
                        i32.ne
                        br_if $label46
                        i32.const 5
                        local.set $var14
                        block $label53
                          local.get $var11
                          i32.const 1
                          i32.add
                          local.tee $var2
                          local.get $var1
                          i32.lt_u
                          br_if $label53
                          local.get $var2
                          local.set $var11
                          br $label10
                        end $label53
                        block $label54
                          local.get $var0
                          local.get $var2
                          i32.add
                          i32.load8_u
                          i32.const 32
                          i32.eq
                          br_if $label54
                          local.get $var2
                          local.set $var11
                          br $label10
                        end $label54
                        block $label55
                          local.get $var5
                          i32.eqz
                          br_if $label55
                          local.get $var5
                          i32.const 1
                          i32.store
                        end $label55
                        local.get $var11
                        i32.const 2
                        i32.add
                        local.set $var11
                        br $label10
                      end $label2
                      block $label60
                        block $label57
                          block $label56
                            local.get $var14
                            i32.const 253
                            i32.and
                            br_if $label56
                            i32.const 1
                            local.set $var14
                            br $label57
                          end $label56
                          local.get $var14
                          i32.const 255
                          i32.and
                          i32.const 5
                          i32.ne
                          br_if $label46
                          i32.const 6
                          local.set $var14
                          local.get $var12
                          local.get $var19
                          i32.const 2
                          i32.eq
                          i32.and
                          i32.const 1
                          i32.ne
                          br_if $label57
                          i32.const 0
                          local.set $var7
                          block $label59
                            block $label58
                              local.get $var20
                              i32.const -4
                              i32.add
                              br_table $label58 $label59 $label59 $label59 $label60 $label59
                            end $label58
                            local.get $var2
                            i32.const 223
                            i32.and
                            i32.const 91
                            i32.ne
                            br_if $label59
                            local.get $var22
                            i32.const 4
                            i32.or
                            local.set $var22
                            br $label57
                          end $label59
                          local.get $var22
                          local.get $var20
                          i32.const -1
                          i32.xor
                          i32.and
                          local.set $var22
                        end $label57
                        local.get $var21
                        local.set $var7
                      end $label60
                      block $label61
                        local.get $var2
                        i32.const 32
                        i32.or
                        i32.const 123
                        i32.ne
                        br_if $label61
                        local.get $var19
                        i32.const 255
                        i32.gt_u
                        br_if $label46
                        local.get $var19
                        local.get $var8
                        i32.const 16
                        i32.add
                        i32.add
                        i32.const -1
                        i32.add
                        local.get $var14
                        i32.store8
                        i32.const 0
                        local.get $var20
                        local.get $var12
                        local.get $var19
                        i32.const 1
                        i32.eq
                        i32.and
                        local.get $var2
                        i32.const 123
                        i32.eq
                        i32.and
                        local.tee $var10
                        select
                        local.set $var20
                        i32.const 0
                        local.get $var7
                        local.get $var10
                        select
                        local.set $var21
                        i32.const 0
                        local.get $var22
                        local.get $var10
                        select
                        local.set $var22
                        i32.const 0
                        i32.const 3
                        local.get $var2
                        i32.const 91
                        i32.eq
                        select
                        local.set $var14
                        br $label62
                      end $label61
                      local.get $var8
                      i32.const 0
                      i32.store offset=12
                      local.get $var0
                      local.get $var1
                      local.get $var11
                      local.get $var8
                      i32.const 12
                      i32.add
                      call $func47
                      i32.eqz
                      br_if $label46
                      local.get $var8
                      i32.load offset=12
                      local.set $var11
                      local.get $var7
                      local.set $var21
                      br $label10
                    end $label16
                    local.get $var7
                    local.get $var20
                    local.get $var12
                    local.get $var19
                    i32.const 2
                    i32.eq
                    i32.and
                    local.tee $var30
                    select
                    local.set $var20
                    br $label63
                  end $label11
                  i32.const 0
                  local.set $var9
                  local.get $var11
                  i32.const 1
                  i32.add
                  local.tee $var30
                  local.get $var1
                  i32.ge_u
                  br_if $label0
                  local.get $var30
                  local.set $var2
                  loop $label153
                    block $label69
                      block $label68
                        block $label65
                          block $label64
                            local.get $var2
                            local.get $var25
                            i32.lt_u
                            br_if $label64
                            local.get $var2
                            local.get $var24
                            i32.ge_u
                            br_if $label64
                            local.get $var23
                            local.get $var2
                            local.get $var25
                            i32.sub
                            i32.shr_u
                            local.tee $var7
                            br_if $label65
                            local.get $var24
                            local.set $var2
                            local.get $var24
                            local.get $var1
                            i32.ge_u
                            br_if $label0
                          end $label64
                          block $label66
                            local.get $var1
                            local.get $var2
                            i32.sub
                            local.tee $var7
                            i32.const 15
                            i32.le_u
                            br_if $label66
                            local.get $var2
                            i32.const 16
                            i32.add
                            local.set $var24
                            block $label67
                              local.get $var0
                              local.get $var2
                              i32.add
                              v128.load align=1
                              local.tee $var31
                              v128.const i32x4 0x20202020 0x20202020 0x20202020 0x20202020
                              i8x16.lt_u
                              local.get $var31
                              v128.const i32x4 0x22222222 0x22222222 0x22222222 0x22222222
                              i8x16.eq
                              local.get $var31
                              v128.const i32x4 0x5C5C5C5C 0x5C5C5C5C 0x5C5C5C5C 0x5C5C5C5C
                              i8x16.eq
                              v128.or
                              v128.or
                              i8x16.bitmask
                              local.tee $var23
                              i32.eqz
                              br_if $label67
                              local.get $var23
                              i32.ctz
                              local.get $var2
                              i32.add
                              local.set $var7
                              local.get $var2
                              local.set $var25
                              br $label68
                            end $label67
                            i32.const 0
                            local.set $var23
                            local.get $var2
                            local.set $var25
                            local.get $var24
                            local.set $var2
                            br $label69
                          end $label66
                          block $label71
                            loop $label72
                              block $label70
                                local.get $var7
                                i32.const 8
                                i32.ge_u
                                br_if $label70
                                local.get $var2
                                local.set $var7
                                br $label71
                              end $label70
                              local.get $var0
                              local.get $var2
                              i32.add
                              local.set $var10
                              local.get $var7
                              i32.const -8
                              i32.add
                              local.set $var7
                              local.get $var2
                              i32.const 8
                              i32.add
                              local.set $var2
                              local.get $var10
                              i64.load align=1
                              local.tee $var29
                              i64.const -1
                              i64.xor
                              local.get $var29
                              i64.const 2459565876494606882
                              i64.xor
                              i64.const -72340172838076673
                              i64.add
                              local.get $var29
                              i64.const 6655295901103053916
                              i64.xor
                              i64.const -72340172838076673
                              i64.add
                              i64.or
                              local.get $var29
                              i64.const -2314885530818453536
                              i64.add
                              i64.or
                              i64.and
                              i64.const -9187201950435737472
                              i64.and
                              local.tee $var29
                              i64.eqz
                              local.tee $var10
                              br_if $label72
                            end $label72
                            i32.const 8
                            local.get $var29
                            i64.ctz
                            i32.wrap_i64
                            i32.const 3
                            i32.shr_u
                            local.get $var10
                            select
                            local.get $var2
                            i32.add
                            i32.const -8
                            i32.add
                            local.set $var7
                          end $label71
                          local.get $var7
                          local.get $var1
                          i32.lt_u
                          br_if $label68
                          br $label0
                        end $label65
                        local.get $var7
                        i32.ctz
                        local.get $var2
                        i32.add
                        local.set $var7
                      end $label68
                      block $label73
                        local.get $var0
                        local.get $var7
                        i32.add
                        local.tee $var2
                        i32.load8_u
                        local.tee $var10
                        i32.const 92
                        i32.ne
                        br_if $label73
                        local.get $var1
                        local.get $var7
                        i32.sub
                        local.tee $var10
                        i32.const 2
                        i32.lt_u
                        br_if $label0
                        block $label74
                          block $label75
                            local.get $var2
                            i32.const 1
                            i32.add
                            i32.load8_u
                            i32.const -34
                            i32.add
                            br_table $label74 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label74 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label74 $label0 $label0 $label0 $label0 $label0 $label74 $label0 $label0 $label0 $label74 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label74 $label0 $label0 $label0 $label74 $label0 $label74 $label75 $label0
                          end $label75
                          local.get $var10
                          i32.const 6
                          i32.lt_u
                          br_if $label0
                          local.get $var7
                          i32.const 2
                          i32.add
                          local.tee $var10
                          local.get $var7
                          i32.const 6
                          i32.add
                          local.tee $var2
                          i32.ge_u
                          br_if $label69
                          block $label76
                            local.get $var0
                            local.get $var10
                            i32.add
                            i32.load8_u
                            local.tee $var10
                            i32.const -58
                            i32.add
                            i32.const 255
                            i32.and
                            i32.const 245
                            i32.gt_u
                            br_if $label76
                            local.get $var10
                            i32.const -33
                            i32.and
                            i32.const -71
                            i32.add
                            i32.const 255
                            i32.and
                            i32.const 250
                            i32.lt_u
                            br_if $label0
                          end $label76
                          block $label77
                            local.get $var16
                            local.get $var7
                            i32.add
                            i32.load8_u
                            local.tee $var10
                            i32.const -58
                            i32.add
                            i32.const 255
                            i32.and
                            i32.const 245
                            i32.gt_u
                            br_if $label77
                            local.get $var10
                            i32.const -33
                            i32.and
                            i32.const -71
                            i32.add
                            i32.const 255
                            i32.and
                            i32.const 250
                            i32.lt_u
                            br_if $label0
                          end $label77
                          block $label78
                            local.get $var15
                            local.get $var7
                            i32.add
                            i32.load8_u
                            local.tee $var10
                            i32.const -58
                            i32.add
                            i32.const 255
                            i32.and
                            i32.const 245
                            i32.gt_u
                            br_if $label78
                            local.get $var10
                            i32.const -33
                            i32.and
                            i32.const -71
                            i32.add
                            i32.const 255
                            i32.and
                            i32.const 250
                            i32.lt_u
                            br_if $label0
                          end $label78
                          local.get $var18
                          local.get $var7
                          i32.add
                          i32.load8_u
                          local.tee $var7
                          i32.const -58
                          i32.add
                          i32.const 255
                          i32.and
                          i32.const 245
                          i32.gt_u
                          br_if $label69
                          local.get $var7
                          i32.const -33
                          i32.and
                          i32.const -71
                          i32.add
                          i32.const 255
                          i32.and
                          i32.const 250
                          i32.ge_u
                          br_if $label69
                          br $label0
                        end $label74
                        local.get $var7
                        i32.const 2
                        i32.add
                        local.set $var2
                        br $label69
                      end $label73
                      local.get $var10
                      i32.const 32
                      i32.lt_u
                      br_if $label0
                      local.get $var7
                      i32.const 1
                      i32.add
                      local.set $var2
                      local.get $var10
                      i32.const 34
                      i32.ne
                      br_if $label69
                      local.get $var26
                      i32.const 1
                      i32.add
                      local.set $var10
                      block $label79
                        local.get $var4
                        i32.eqz
                        br_if $label79
                        local.get $var10
                        i32.load8_u
                        local.tee $var32
                        i32.const 105
                        i32.eq
                        local.get $var32
                        i32.const 92
                        i32.eq
                        local.tee $var33
                        i32.or
                        i32.eqz
                        br_if $label79
                        local.get $var11
                        local.get $var2
                        i32.ge_u
                        br_if $label79
                        local.get $var4
                        i32.load
                        br_if $label79
                        local.get $var11
                        i32.const 4
                        i32.add
                        local.set $var34
                        block $label84
                          block $label80
                            local.get $var7
                            local.get $var11
                            i32.eq
                            br_if $label80
                            block $label81
                              local.get $var33
                              br_if $label81
                              local.get $var7
                              local.get $var11
                              i32.sub
                              local.tee $var33
                              i32.const 1
                              i32.eq
                              br_if $label80
                              local.get $var32
                              i32.const 105
                              i32.ne
                              br_if $label80
                              block $label82
                                local.get $var26
                                i32.load8_u offset=2
                                i32.const -92
                                i32.add
                                br_table $label81 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label82 $label80
                              end $label82
                              local.get $var33
                              i32.const 2
                              i32.eq
                              br_if $label80
                              block $label83
                                local.get $var26
                                i32.load8_u offset=3
                                i32.const -92
                                i32.add
                                br_table $label81 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label80 $label83 $label80
                              end $label83
                              local.get $var34
                              local.get $var2
                              i32.ge_u
                              br_if $label80
                              local.get $var0
                              local.get $var34
                              i32.add
                              i32.load8_u
                              i32.const 34
                              i32.ne
                              br_if $label80
                              br $label84
                            end $label81
                            local.get $var0
                            local.get $var11
                            local.get $var2
                            i32.const 1053
                            i32.const 3
                            call $func14
                            br_if $label84
                          end $label80
                          local.get $var30
                          local.get $var2
                          i32.ge_u
                          br_if $label79
                          block $label85
                            block $label86
                              local.get $var32
                              i32.const -92
                              i32.add
                              br_table $label85 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label86 $label79
                            end $label86
                            local.get $var11
                            i32.const 2
                            i32.add
                            local.tee $var32
                            local.get $var2
                            i32.ge_u
                            br_if $label79
                            block $label87
                              local.get $var0
                              local.get $var32
                              i32.add
                              i32.load8_u
                              i32.const -92
                              i32.add
                              br_table $label85 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label87 $label79
                            end $label87
                            local.get $var11
                            i32.const 3
                            i32.add
                            local.tee $var32
                            local.get $var2
                            i32.ge_u
                            br_if $label79
                            block $label88
                              local.get $var0
                              local.get $var32
                              i32.add
                              i32.load8_u
                              i32.const -92
                              i32.add
                              br_table $label85 $label79 $label79 $label79 $label79 $label88 $label79
                            end $label88
                            local.get $var34
                            local.get $var2
                            i32.ge_u
                            br_if $label79
                            block $label89
                              local.get $var0
                              local.get $var34
                              i32.add
                              i32.load8_u
                              i32.const -92
                              i32.add
                              br_table $label85 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label89 $label79
                            end $label89
                            local.get $var11
                            i32.const 5
                            i32.add
                            local.tee $var32
                            local.get $var2
                            i32.ge_u
                            br_if $label79
                            block $label90
                              local.get $var0
                              local.get $var32
                              i32.add
                              i32.load8_u
                              i32.const -92
                              i32.add
                              br_table $label85 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label79 $label90 $label79
                            end $label90
                            local.get $var11
                            i32.const 6
                            i32.add
                            local.tee $var32
                            local.get $var2
                            i32.ge_u
                            br_if $label79
                            local.get $var0
                            local.get $var32
                            i32.add
                            i32.load8_u
                            i32.const 34
                            i32.eq
                            br_if $label84
                            br $label79
                          end $label85
                          local.get $var0
                          local.get $var11
                          local.get $var2
                          i32.const 1066
                          i32.const 5
                          call $func14
                          i32.eqz
                          br_if $label79
                        end $label84
                        local.get $var4
                        i32.const 1
                        i32.store
                      end $label79
                      block $label92
                        block $label93
                          block $label94
                            block $label97
                              block $label91
                                local.get $var28
                                br_if $label91
                                local.get $var12
                                local.get $var19
                                i32.const 2
                                i32.eq
                                i32.and
                                local.tee $var30
                                i32.const 1
                                i32.ne
                                br_if $label92
                                local.get $var11
                                local.get $var2
                                i32.ge_u
                                br_if $label93
                                local.get $var26
                                i32.load8_u
                                i32.const 34
                                i32.ne
                                br_if $label93
                                local.get $var11
                                i32.const 5
                                i32.add
                                local.set $var20
                                local.get $var7
                                local.get $var11
                                i32.eq
                                br_if $label94
                                block $label96
                                  block $label95
                                    local.get $var13
                                    local.get $var11
                                    i32.add
                                    i32.load8_u
                                    local.tee $var9
                                    i32.const 92
                                    i32.eq
                                    br_if $label95
                                    local.get $var9
                                    i32.const 116
                                    i32.ne
                                    br_if $label94
                                    local.get $var7
                                    local.get $var11
                                    i32.sub
                                    local.tee $var9
                                    i32.const 1
                                    i32.eq
                                    br_if $label94
                                    local.get $var17
                                    local.get $var11
                                    i32.add
                                    i32.load8_u
                                    local.tee $var14
                                    i32.const 92
                                    i32.eq
                                    br_if $label95
                                    local.get $var14
                                    i32.const 121
                                    i32.ne
                                    br_if $label94
                                    local.get $var9
                                    i32.const 2
                                    i32.eq
                                    br_if $label94
                                    local.get $var16
                                    local.get $var11
                                    i32.add
                                    i32.load8_u
                                    local.tee $var14
                                    i32.const 92
                                    i32.eq
                                    br_if $label95
                                    local.get $var14
                                    i32.const 112
                                    i32.ne
                                    br_if $label94
                                    local.get $var9
                                    i32.const 3
                                    i32.eq
                                    br_if $label94
                                    local.get $var15
                                    local.get $var11
                                    i32.add
                                    i32.load8_u
                                    i32.const -92
                                    i32.add
                                    br_table $label95 $label94 $label94 $label94 $label94 $label94 $label94 $label94 $label94 $label96 $label94
                                  end $label95
                                  local.get $var0
                                  local.get $var11
                                  local.get $var2
                                  i32.const 1061
                                  i32.const 4
                                  call $func14
                                  i32.eqz
                                  br_if $label94
                                  i32.const 8
                                  local.set $var20
                                  br $label92
                                end $label96
                                local.get $var20
                                local.get $var2
                                i32.lt_u
                                br_if $label97
                                br $label94
                              end $label91
                              block $label105
                                block $label111
                                  block $label98
                                    local.get $var14
                                    i32.const 255
                                    i32.and
                                    i32.const 5
                                    i32.ne
                                    br_if $label98
                                    i32.const 6
                                    local.set $var10
                                    i32.const 7
                                    local.set $var14
                                    local.get $var12
                                    local.get $var19
                                    i32.const 2
                                    i32.eq
                                    i32.and
                                    i32.const 1
                                    i32.ne
                                    br_if $label99
                                    block $label100
                                      local.get $var20
                                      i32.const 8
                                      i32.ne
                                      br_if $label100
                                      i32.const 8
                                      local.set $var20
                                      i32.const 0
                                      local.set $var21
                                      local.get $var11
                                      local.get $var2
                                      i32.ge_u
                                      br_if $label99
                                      local.get $var26
                                      i32.load8_u
                                      i32.const 34
                                      i32.ne
                                      br_if $label99
                                      local.get $var11
                                      i32.const 5
                                      i32.add
                                      local.set $var9
                                      block $label101
                                        local.get $var7
                                        local.get $var11
                                        i32.eq
                                        br_if $label101
                                        block $label102
                                          local.get $var0
                                          local.get $var30
                                          i32.add
                                          i32.load8_u
                                          local.tee $var26
                                          i32.const 92
                                          i32.eq
                                          br_if $label102
                                          local.get $var26
                                          i32.const 116
                                          i32.ne
                                          br_if $label101
                                          local.get $var7
                                          local.get $var11
                                          i32.sub
                                          local.tee $var7
                                          i32.const 1
                                          i32.eq
                                          br_if $label101
                                          block $label103
                                            local.get $var17
                                            local.get $var11
                                            i32.add
                                            i32.load8_u
                                            i32.const -92
                                            i32.add
                                            br_table $label102 $label101 $label101 $label101 $label101 $label101 $label101 $label101 $label101 $label103 $label101
                                          end $label103
                                          local.get $var7
                                          i32.const 2
                                          i32.eq
                                          br_if $label101
                                          local.get $var16
                                          local.get $var11
                                          i32.add
                                          i32.load8_u
                                          local.tee $var26
                                          i32.const 92
                                          i32.eq
                                          br_if $label102
                                          local.get $var26
                                          i32.const 120
                                          i32.ne
                                          br_if $label101
                                          local.get $var7
                                          i32.const 3
                                          i32.eq
                                          br_if $label101
                                          local.get $var15
                                          local.get $var11
                                          i32.add
                                          i32.load8_u
                                          local.tee $var7
                                          i32.const 92
                                          i32.eq
                                          br_if $label102
                                          local.get $var7
                                          i32.const 116
                                          i32.ne
                                          br_if $label101
                                          local.get $var9
                                          local.get $var2
                                          i32.ge_u
                                          br_if $label101
                                          local.get $var0
                                          local.get $var9
                                          i32.add
                                          i32.load8_u
                                          i32.const 34
                                          i32.ne
                                          br_if $label101
                                          i32.const 1
                                          local.set $var21
                                          br $label99
                                        end $label102
                                        local.get $var0
                                        local.get $var11
                                        local.get $var2
                                        i32.const 1024
                                        i32.const 4
                                        call $func14
                                        i32.eqz
                                        br_if $label101
                                        i32.const 1
                                        local.set $var21
                                        br $label99
                                      end $label101
                                      i32.const 6
                                      local.set $var10
                                      local.get $var30
                                      local.get $var2
                                      i32.ge_u
                                      br_if $label99
                                      local.get $var11
                                      i32.const 6
                                      i32.add
                                      local.set $var28
                                      block $label110
                                        block $label104
                                          block $label106
                                            local.get $var0
                                            local.get $var30
                                            i32.add
                                            local.tee $var7
                                            i32.load8_u
                                            i32.const -92
                                            i32.add
                                            br_table $label104 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label106 $label105
                                          end $label106
                                          local.get $var11
                                          i32.const 2
                                          i32.add
                                          local.tee $var26
                                          local.get $var2
                                          i32.ge_u
                                          br_if $label105
                                          block $label107
                                            local.get $var0
                                            local.get $var26
                                            i32.add
                                            i32.load8_u
                                            i32.const -92
                                            i32.add
                                            br_table $label104 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label107 $label105
                                          end $label107
                                          local.get $var11
                                          i32.const 3
                                          i32.add
                                          local.tee $var26
                                          local.get $var2
                                          i32.ge_u
                                          br_if $label105
                                          block $label108
                                            local.get $var0
                                            local.get $var26
                                            i32.add
                                            i32.load8_u
                                            i32.const -92
                                            i32.add
                                            br_table $label104 $label105 $label105 $label105 $label105 $label108 $label105
                                          end $label108
                                          local.get $var11
                                          i32.const 4
                                          i32.add
                                          local.tee $var26
                                          local.get $var2
                                          i32.ge_u
                                          br_if $label105
                                          block $label109
                                            local.get $var0
                                            local.get $var26
                                            i32.add
                                            i32.load8_u
                                            i32.const -92
                                            i32.add
                                            br_table $label104 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label109 $label105
                                          end $label109
                                          local.get $var9
                                          local.get $var2
                                          i32.ge_u
                                          br_if $label105
                                          local.get $var0
                                          local.get $var9
                                          i32.add
                                          i32.load8_u
                                          i32.const -92
                                          i32.add
                                          br_table $label104 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label105 $label110 $label105
                                        end $label104
                                        local.get $var0
                                        local.get $var11
                                        local.get $var2
                                        i32.const 1066
                                        i32.const 5
                                        call $func14
                                        i32.eqz
                                        br_if $label105
                                        i32.const 2
                                        local.set $var21
                                        br $label99
                                      end $label110
                                      local.get $var28
                                      local.get $var2
                                      i32.lt_u
                                      br_if $label111
                                      br $label105
                                    end $label100
                                    local.get $var20
                                    local.get $var22
                                    i32.or
                                    local.set $var22
                                    br $label99
                                  end $label98
                                  local.get $var14
                                  i32.const 253
                                  i32.and
                                  br_if $label0
                                  i32.const 1
                                  local.set $var10
                                  i32.const 2
                                  local.set $var14
                                  br $label99
                                end $label111
                                local.get $var0
                                local.get $var28
                                i32.add
                                i32.load8_u
                                i32.const 34
                                i32.ne
                                br_if $label105
                                i32.const 2
                                local.set $var21
                                br $label99
                              end $label105
                              i32.const 1
                              local.set $var26
                              block $label117
                                block $label113
                                  block $label114
                                    block $label112
                                      local.get $var7
                                      i32.load8_u
                                      local.tee $var7
                                      i32.const 115
                                      i32.eq
                                      br_if $label112
                                      local.get $var7
                                      i32.const 92
                                      i32.ne
                                      br_if $label113
                                      br $label114
                                    end $label112
                                    local.get $var11
                                    i32.const 2
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label99
                                    local.get $var0
                                    local.get $var7
                                    i32.add
                                    i32.load8_u
                                    local.tee $var7
                                    i32.const 92
                                    i32.eq
                                    br_if $label114
                                    local.get $var7
                                    i32.const 116
                                    i32.ne
                                    br_if $label113
                                    local.get $var11
                                    i32.const 3
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label99
                                    local.get $var0
                                    local.get $var7
                                    i32.add
                                    i32.load8_u
                                    local.tee $var7
                                    i32.const 92
                                    i32.eq
                                    br_if $label114
                                    local.get $var7
                                    i32.const 114
                                    i32.ne
                                    br_if $label113
                                    local.get $var11
                                    i32.const 4
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label99
                                    local.get $var0
                                    local.get $var7
                                    i32.add
                                    i32.load8_u
                                    local.tee $var7
                                    i32.const 92
                                    i32.eq
                                    br_if $label114
                                    local.get $var7
                                    i32.const 117
                                    i32.ne
                                    br_if $label113
                                    local.get $var9
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label99
                                    block $label115
                                      local.get $var0
                                      local.get $var9
                                      i32.add
                                      i32.load8_u
                                      i32.const -92
                                      i32.add
                                      br_table $label114 $label113 $label113 $label113 $label113 $label113 $label113 $label115 $label113
                                    end $label115
                                    local.get $var28
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label99
                                    local.get $var0
                                    local.get $var28
                                    i32.add
                                    i32.load8_u
                                    local.tee $var7
                                    i32.const 92
                                    i32.eq
                                    br_if $label114
                                    local.get $var7
                                    i32.const 116
                                    i32.ne
                                    br_if $label113
                                    block $label116
                                      local.get $var11
                                      i32.const 7
                                      i32.add
                                      local.tee $var7
                                      local.get $var2
                                      i32.lt_u
                                      br_if $label116
                                      i32.const 7
                                      local.set $var14
                                      br $label99
                                    end $label116
                                    local.get $var0
                                    local.get $var7
                                    i32.add
                                    i32.load8_u
                                    local.tee $var7
                                    i32.const 92
                                    i32.eq
                                    br_if $label114
                                    local.get $var7
                                    i32.const 117
                                    i32.ne
                                    br_if $label113
                                    local.get $var11
                                    i32.const 8
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label117
                                    local.get $var0
                                    local.get $var7
                                    i32.add
                                    i32.load8_u
                                    local.tee $var7
                                    i32.const 92
                                    i32.eq
                                    br_if $label114
                                    local.get $var7
                                    i32.const 114
                                    i32.ne
                                    br_if $label113
                                    local.get $var11
                                    i32.const 9
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label117
                                    block $label118
                                      local.get $var0
                                      local.get $var7
                                      i32.add
                                      i32.load8_u
                                      i32.const -92
                                      i32.add
                                      br_table $label114 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label118 $label113
                                    end $label118
                                    local.get $var11
                                    i32.const 10
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label117
                                    block $label119
                                      local.get $var0
                                      local.get $var7
                                      i32.add
                                      i32.load8_u
                                      i32.const -92
                                      i32.add
                                      br_table $label114 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label119 $label113
                                    end $label119
                                    local.get $var11
                                    i32.const 11
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label117
                                    local.get $var0
                                    local.get $var7
                                    i32.add
                                    i32.load8_u
                                    local.tee $var7
                                    i32.const 92
                                    i32.eq
                                    br_if $label114
                                    local.get $var7
                                    i32.const 45
                                    i32.ne
                                    br_if $label113
                                    local.get $var11
                                    i32.const 12
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label117
                                    block $label120
                                      local.get $var0
                                      local.get $var7
                                      i32.add
                                      i32.load8_u
                                      i32.const -92
                                      i32.add
                                      br_table $label114 $label113 $label113 $label113 $label113 $label113 $label113 $label120 $label113
                                    end $label120
                                    local.get $var11
                                    i32.const 13
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label117
                                    block $label121
                                      local.get $var0
                                      local.get $var7
                                      i32.add
                                      i32.load8_u
                                      i32.const -92
                                      i32.add
                                      br_table $label114 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label121 $label113
                                    end $label121
                                    local.get $var11
                                    i32.const 14
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label117
                                    block $label122
                                      local.get $var0
                                      local.get $var7
                                      i32.add
                                      i32.load8_u
                                      i32.const -92
                                      i32.add
                                      br_table $label114 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label122 $label113
                                    end $label122
                                    local.get $var11
                                    i32.const 15
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label117
                                    local.get $var0
                                    local.get $var7
                                    i32.add
                                    i32.load8_u
                                    local.tee $var7
                                    i32.const 92
                                    i32.eq
                                    br_if $label114
                                    local.get $var7
                                    i32.const 116
                                    i32.ne
                                    br_if $label113
                                    local.get $var11
                                    i32.const 16
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label117
                                    block $label123
                                      local.get $var0
                                      local.get $var7
                                      i32.add
                                      i32.load8_u
                                      i32.const -92
                                      i32.add
                                      br_table $label114 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label123 $label113
                                    end $label123
                                    local.get $var11
                                    i32.const 17
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label117
                                    block $label124
                                      local.get $var0
                                      local.get $var7
                                      i32.add
                                      i32.load8_u
                                      i32.const -92
                                      i32.add
                                      br_table $label114 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label113 $label124 $label113
                                    end $label124
                                    local.get $var11
                                    i32.const 18
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label117
                                    local.get $var0
                                    local.get $var7
                                    i32.add
                                    i32.load8_u
                                    local.tee $var7
                                    i32.const 92
                                    i32.eq
                                    br_if $label114
                                    local.get $var7
                                    i32.const 116
                                    i32.ne
                                    br_if $label113
                                    local.get $var11
                                    i32.const 19
                                    i32.add
                                    local.tee $var7
                                    local.get $var2
                                    i32.ge_u
                                    br_if $label117
                                    local.get $var0
                                    local.get $var7
                                    i32.add
                                    i32.load8_u
                                    i32.const 34
                                    i32.ne
                                    local.set $var26
                                    br $label113
                                  end $label114
                                  local.get $var0
                                  local.get $var11
                                  local.get $var2
                                  i32.const 1029
                                  i32.const 18
                                  call $func14
                                  i32.eqz
                                  local.set $var26
                                end $label113
                                i32.const 0
                                i32.const 4
                                local.get $var26
                                i32.const 1
                                i32.and
                                select
                                local.set $var21
                                br $label99
                              end $label117
                              i32.const 8
                              local.set $var20
                              i32.const 7
                              local.set $var14
                              br $label99
                            end $label97
                            local.get $var0
                            local.get $var20
                            i32.add
                            i32.load8_u
                            i32.const 34
                            i32.ne
                            br_if $label94
                            i32.const 8
                            local.set $var20
                            br $label92
                          end $label94
                          block $label125
                            local.get $var11
                            i32.const 1
                            i32.add
                            local.tee $var14
                            local.get $var2
                            i32.lt_u
                            local.tee $var9
                            i32.eqz
                            br_if $label125
                            block $label126
                              local.get $var0
                              local.get $var14
                              i32.add
                              i32.load8_u
                              local.tee $var28
                              i32.const 92
                              i32.eq
                              br_if $label126
                              local.get $var28
                              i32.const 116
                              i32.ne
                              br_if $label125
                              local.get $var11
                              i32.const 2
                              i32.add
                              local.tee $var28
                              local.get $var2
                              i32.ge_u
                              br_if $label125
                              block $label127
                                local.get $var0
                                local.get $var28
                                i32.add
                                i32.load8_u
                                i32.const -92
                                i32.add
                                br_table $label126 $label125 $label125 $label125 $label125 $label125 $label125 $label125 $label125 $label127 $label125
                              end $label127
                              local.get $var11
                              i32.const 3
                              i32.add
                              local.tee $var28
                              local.get $var2
                              i32.ge_u
                              br_if $label125
                              local.get $var0
                              local.get $var28
                              i32.add
                              i32.load8_u
                              local.tee $var28
                              i32.const 92
                              i32.eq
                              br_if $label126
                              local.get $var28
                              i32.const 120
                              i32.ne
                              br_if $label125
                              local.get $var11
                              i32.const 4
                              i32.add
                              local.tee $var28
                              local.get $var2
                              i32.ge_u
                              br_if $label125
                              local.get $var0
                              local.get $var28
                              i32.add
                              i32.load8_u
                              local.tee $var28
                              i32.const 92
                              i32.eq
                              br_if $label126
                              local.get $var28
                              i32.const 116
                              i32.ne
                              br_if $label125
                              local.get $var20
                              local.get $var2
                              i32.ge_u
                              br_if $label125
                              local.get $var0
                              local.get $var20
                              i32.add
                              i32.load8_u
                              i32.const 34
                              i32.ne
                              br_if $label125
                              i32.const 1
                              local.set $var20
                              br $label92
                            end $label126
                            local.get $var0
                            local.get $var11
                            local.get $var2
                            i32.const 1024
                            i32.const 4
                            call $func14
                            i32.eqz
                            br_if $label125
                            i32.const 1
                            local.set $var20
                            br $label92
                          end $label125
                          block $label128
                            local.get $var9
                            i32.eqz
                            br_if $label128
                            block $label129
                              local.get $var0
                              local.get $var14
                              i32.add
                              i32.load8_u
                              local.tee $var28
                              i32.const 92
                              i32.eq
                              br_if $label129
                              local.get $var28
                              i32.const 112
                              i32.ne
                              br_if $label128
                              local.get $var11
                              i32.const 2
                              i32.add
                              local.tee $var28
                              local.get $var2
                              i32.ge_u
                              br_if $label128
                              block $label130
                                local.get $var0
                                local.get $var28
                                i32.add
                                i32.load8_u
                                i32.const -92
                                i32.add
                                br_table $label129 $label128 $label128 $label128 $label128 $label130 $label128
                              end $label130
                              local.get $var11
                              i32.const 3
                              i32.add
                              local.tee $var28
                              local.get $var2
                              i32.ge_u
                              br_if $label128
                              local.get $var0
                              local.get $var28
                              i32.add
                              i32.load8_u
                              local.tee $var28
                              i32.const 92
                              i32.eq
                              br_if $label129
                              local.get $var28
                              i32.const 116
                              i32.ne
                              br_if $label128
                              local.get $var11
                              i32.const 4
                              i32.add
                              local.tee $var28
                              local.get $var2
                              i32.ge_u
                              br_if $label128
                              block $label131
                                local.get $var0
                                local.get $var28
                                i32.add
                                i32.load8_u
                                i32.const -92
                                i32.add
                                br_table $label129 $label128 $label128 $label128 $label128 $label128 $label128 $label128 $label128 $label128 $label128 $label128 $label131 $label128
                              end $label131
                              local.get $var20
                              local.get $var2
                              i32.ge_u
                              br_if $label128
                              local.get $var0
                              local.get $var20
                              i32.add
                              i32.load8_u
                              i32.const 34
                              i32.ne
                              br_if $label128
                              i32.const 2
                              local.set $var20
                              br $label92
                            end $label129
                            local.get $var0
                            local.get $var11
                            local.get $var2
                            i32.const 1048
                            i32.const 4
                            call $func14
                            i32.eqz
                            br_if $label128
                            i32.const 2
                            local.set $var20
                            br $label92
                          end $label128
                          local.get $var9
                          i32.eqz
                          br_if $label93
                          block $label132
                            block $label133
                              local.get $var0
                              local.get $var14
                              i32.add
                              i32.load8_u
                              i32.const -92
                              i32.add
                              br_table $label132 $label93 $label93 $label93 $label93 $label93 $label93 $label133 $label93
                            end $label133
                            local.get $var11
                            i32.const 2
                            i32.add
                            local.tee $var9
                            local.get $var2
                            i32.ge_u
                            br_if $label93
                            block $label134
                              local.get $var0
                              local.get $var9
                              i32.add
                              i32.load8_u
                              i32.const -92
                              i32.add
                              br_table $label132 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label134 $label93
                            end $label134
                            local.get $var11
                            i32.const 3
                            i32.add
                            local.tee $var9
                            local.get $var2
                            i32.ge_u
                            br_if $label93
                            block $label135
                              local.get $var0
                              local.get $var9
                              i32.add
                              i32.load8_u
                              i32.const -92
                              i32.add
                              br_table $label132 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label135 $label93
                            end $label135
                            local.get $var11
                            i32.const 4
                            i32.add
                            local.tee $var9
                            local.get $var2
                            i32.ge_u
                            br_if $label93
                            local.get $var0
                            local.get $var9
                            i32.add
                            i32.load8_u
                            local.tee $var9
                            i32.const 92
                            i32.eq
                            br_if $label132
                            local.get $var9
                            i32.const 116
                            i32.ne
                            br_if $label93
                            local.get $var20
                            local.get $var2
                            i32.ge_u
                            br_if $label93
                            block $label136
                              local.get $var0
                              local.get $var20
                              i32.add
                              i32.load8_u
                              i32.const -92
                              i32.add
                              br_table $label132 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label136 $label93
                            end $label136
                            local.get $var11
                            i32.const 6
                            i32.add
                            local.tee $var9
                            local.get $var2
                            i32.ge_u
                            br_if $label93
                            block $label137
                              local.get $var0
                              local.get $var9
                              i32.add
                              i32.load8_u
                              i32.const -92
                              i32.add
                              br_table $label132 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label93 $label137 $label93
                            end $label137
                            local.get $var11
                            i32.const 7
                            i32.add
                            local.tee $var9
                            local.get $var2
                            i32.ge_u
                            br_if $label93
                            local.get $var0
                            local.get $var9
                            i32.add
                            i32.load8_u
                            local.tee $var9
                            i32.const 92
                            i32.eq
                            br_if $label132
                            local.get $var9
                            i32.const 116
                            i32.ne
                            br_if $label93
                            local.get $var11
                            i32.const 8
                            i32.add
                            local.tee $var9
                            local.get $var2
                            i32.ge_u
                            br_if $label93
                            local.get $var0
                            local.get $var9
                            i32.add
                            i32.load8_u
                            i32.const 34
                            i32.ne
                            br_if $label93
                            i32.const 4
                            local.set $var20
                            br $label92
                          end $label132
                          local.get $var0
                          local.get $var11
                          local.get $var2
                          i32.const 1040
                          i32.const 7
                          call $func14
                          i32.eqz
                          br_if $label93
                          i32.const 4
                          local.set $var20
                          br $label92
                        end $label93
                        i32.const 0
                        local.set $var20
                      end $label92
                      i32.const 0
                      local.set $var9
                      block $label138
                        local.get $var10
                        i32.load8_u
                        local.tee $var10
                        i32.const 116
                        i32.eq
                        br_if $label138
                        local.get $var10
                        i32.const 92
                        i32.ne
                        br_if $label63
                      end $label138
                      block $label141
                        block $label140
                          block $label139
                            local.get $var5
                            i32.eqz
                            br_if $label139
                            local.get $var5
                            i32.load
                            i32.eqz
                            br_if $label140
                          end $label139
                          local.get $var6
                          i32.eqz
                          br_if $label63
                          local.get $var11
                          local.get $var2
                          i32.ge_u
                          br_if $label63
                          local.get $var6
                          i32.load
                          i32.eqz
                          br_if $label141
                          br $label63
                        end $label140
                        local.get $var11
                        local.get $var2
                        i32.ge_u
                        br_if $label63
                      end $label141
                      local.get $var26
                      i32.load8_u
                      i32.const 34
                      i32.ne
                      br_if $label63
                      local.get $var7
                      local.get $var11
                      i32.eq
                      br_if $label63
                      block $label144
                        block $label142
                          local.get $var10
                          i32.const 92
                          i32.eq
                          br_if $label142
                          local.get $var7
                          local.get $var11
                          i32.sub
                          local.tee $var7
                          i32.const 1
                          i32.eq
                          br_if $label63
                          local.get $var10
                          i32.const 116
                          i32.ne
                          br_if $label63
                          local.get $var26
                          i32.load8_u offset=2
                          local.tee $var10
                          i32.const 92
                          i32.eq
                          br_if $label142
                          local.get $var10
                          i32.const 121
                          i32.ne
                          br_if $label63
                          local.get $var7
                          i32.const 2
                          i32.eq
                          br_if $label63
                          local.get $var26
                          i32.load8_u offset=3
                          local.tee $var10
                          i32.const 92
                          i32.eq
                          br_if $label142
                          local.get $var10
                          i32.const 112
                          i32.ne
                          br_if $label63
                          local.get $var7
                          i32.const 3
                          i32.eq
                          br_if $label63
                          block $label143
                            local.get $var26
                            i32.load8_u offset=4
                            i32.const -92
                            i32.add
                            br_table $label142 $label63 $label63 $label63 $label63 $label63 $label63 $label63 $label63 $label143 $label63
                          end $label143
                          local.get $var11
                          i32.const 5
                          i32.add
                          local.tee $var7
                          local.get $var2
                          i32.ge_u
                          br_if $label63
                          local.get $var0
                          local.get $var7
                          i32.add
                          i32.load8_u
                          i32.const 34
                          i32.eq
                          br_if $label144
                          br $label63
                        end $label142
                        local.get $var0
                        local.get $var11
                        local.get $var2
                        i32.const 1061
                        i32.const 4
                        call $func14
                        i32.eqz
                        br_if $label63
                      end $label144
                      local.get $var2
                      local.set $var7
                      block $label145
                        local.get $var2
                        local.get $var1
                        i32.ge_u
                        br_if $label145
                        local.get $var2
                        local.set $var7
                        loop $label146
                          local.get $var0
                          local.get $var7
                          i32.add
                          i32.load8_u
                          i32.const -9
                          i32.add
                          local.tee $var10
                          i32.const 23
                          i32.gt_u
                          br_if $label145
                          i32.const 1
                          local.get $var10
                          i32.shl
                          i32.const 8388627
                          i32.and
                          i32.eqz
                          br_if $label145
                          local.get $var1
                          local.get $var7
                          i32.const 1
                          i32.add
                          local.tee $var7
                          i32.ne
                          br_if $label146
                          br $label63
                        end $label146
                      end $label145
                      local.get $var7
                      local.get $var1
                      i32.ge_u
                      br_if $label63
                      local.get $var0
                      local.get $var7
                      i32.add
                      i32.load8_u
                      i32.const 58
                      i32.ne
                      br_if $label63
                      block $label147
                        local.get $var7
                        i32.const 1
                        i32.add
                        local.tee $var7
                        local.get $var1
                        i32.ge_u
                        br_if $label147
                        loop $label148
                          local.get $var0
                          local.get $var7
                          i32.add
                          i32.load8_u
                          i32.const -9
                          i32.add
                          local.tee $var10
                          i32.const 23
                          i32.gt_u
                          br_if $label147
                          i32.const 1
                          local.get $var10
                          i32.shl
                          i32.const 8388627
                          i32.and
                          i32.eqz
                          br_if $label147
                          local.get $var1
                          local.get $var7
                          i32.const 1
                          i32.add
                          local.tee $var7
                          i32.ne
                          br_if $label148
                          br $label63
                        end $label148
                      end $label147
                      local.get $var7
                      local.get $var1
                      i32.ge_u
                      br_if $label63
                      local.get $var0
                      local.get $var7
                      i32.add
                      local.tee $var10
                      i32.load8_u
                      i32.const 34
                      i32.ne
                      br_if $label63
                      local.get $var1
                      local.get $var7
                      i32.const -1
                      i32.xor
                      i32.add
                      local.tee $var11
                      i32.eqz
                      br_if $label63
                      block $label151
                        block $label149
                          local.get $var10
                          i32.load8_u offset=1
                          local.tee $var14
                          i32.const 92
                          i32.eq
                          br_if $label149
                          local.get $var11
                          i32.const 1
                          i32.eq
                          br_if $label63
                          local.get $var14
                          i32.const 116
                          i32.ne
                          br_if $label63
                          block $label150
                            local.get $var10
                            i32.load8_u offset=2
                            i32.const -92
                            i32.add
                            br_table $label149 $label63 $label63 $label63 $label63 $label63 $label63 $label63 $label63 $label150 $label63
                          end $label150
                          local.get $var11
                          i32.const 2
                          i32.eq
                          br_if $label63
                          local.get $var10
                          i32.load8_u offset=3
                          local.tee $var14
                          i32.const 92
                          i32.eq
                          br_if $label149
                          local.get $var14
                          i32.const 120
                          i32.ne
                          br_if $label63
                          local.get $var11
                          i32.const 3
                          i32.eq
                          br_if $label63
                          local.get $var10
                          i32.load8_u offset=4
                          local.tee $var10
                          i32.const 92
                          i32.eq
                          br_if $label149
                          local.get $var10
                          i32.const 116
                          i32.ne
                          br_if $label63
                          local.get $var7
                          i32.const 5
                          i32.add
                          local.tee $var7
                          local.get $var1
                          i32.ge_u
                          br_if $label63
                          local.get $var0
                          local.get $var7
                          i32.add
                          i32.load8_u
                          i32.const 34
                          i32.eq
                          br_if $label151
                          br $label63
                        end $label149
                        local.get $var0
                        local.get $var7
                        local.get $var1
                        i32.const 1024
                        i32.const 4
                        call $func14
                        i32.eqz
                        br_if $label63
                      end $label151
                      block $label152
                        local.get $var5
                        i32.eqz
                        br_if $label152
                        local.get $var5
                        i32.const 1
                        i32.store
                      end $label152
                      local.get $var6
                      i32.eqz
                      br_if $label63
                      local.get $var6
                      i32.const 1
                      i32.store
                      br $label63
                    end $label69
                    local.get $var2
                    local.get $var1
                    i32.lt_u
                    br_if $label153
                    br $label0
                  end $label153
                end $label63
                i32.const 4
                local.set $var10
                i32.const 2
                local.set $var14
                local.get $var2
                local.get $var1
                i32.ge_u
                br_if $label99
                local.get $var0
                local.get $var2
                i32.add
                i32.load8_u
                i32.const 58
                i32.ne
                br_if $label99
                block $label154
                  local.get $var2
                  i32.const 1
                  i32.add
                  local.tee $var11
                  local.get $var1
                  i32.ge_u
                  br_if $label154
                  local.get $var0
                  local.get $var11
                  i32.add
                  i32.load8_u
                  i32.const 32
                  i32.ne
                  br_if $label154
                  block $label155
                    local.get $var5
                    i32.eqz
                    br_if $label155
                    local.get $var5
                    i32.const 1
                    i32.store
                  end $label155
                  local.get $var2
                  i32.const 2
                  i32.add
                  local.set $var11
                end $label154
                i32.const 5
                local.set $var14
                local.get $var9
                local.get $var11
                local.get $var1
                i32.lt_u
                i32.and
                i32.const 1
                i32.ne
                br_if $label10
                local.get $var0
                local.get $var11
                i32.add
                i32.load8_u
                local.tee $var2
                i32.const 32
                i32.or
                i32.const 123
                i32.ne
                br_if $label10
                local.get $var19
                i32.const 255
                i32.gt_u
                br_if $label46
                local.get $var19
                local.get $var8
                i32.const 16
                i32.add
                i32.add
                i32.const -1
                i32.add
                i32.const 6
                i32.store8
                i32.const 0
                i32.const 3
                local.get $var2
                i32.const 91
                i32.eq
                select
                local.set $var14
                local.get $var22
                i32.const 4
                i32.or
                local.get $var22
                local.get $var30
                select
                local.set $var22
              end $label62
              local.get $var11
              i32.const 1
              i32.add
              local.set $var11
              local.get $var19
              i32.const 1
              i32.add
              local.set $var19
              br $label10
            end $label99
            block $label156
              local.get $var27
              i32.const 3
              i32.eq
              br_if $label156
              local.get $var2
              local.get $var1
              i32.ge_u
              br_if $label156
              local.get $var0
              local.get $var2
              i32.add
              i32.load8_u
              i32.const 44
              i32.ne
              br_if $label156
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var11
              local.get $var1
              i32.ge_u
              br_if $label10
              local.get $var0
              local.get $var11
              i32.add
              i32.load8_u
              i32.const 32
              i32.ne
              br_if $label10
              block $label157
                local.get $var5
                i32.eqz
                br_if $label157
                local.get $var5
                i32.const 1
                i32.store
              end $label157
              local.get $var2
              i32.const 2
              i32.add
              local.set $var11
              br $label10
            end $label156
            local.get $var10
            local.set $var14
            local.get $var2
            local.set $var11
          end $label10
          local.get $var11
          local.get $var1
          i32.lt_u
          br_if $label158
        end $label158
      end $label46
      i32.const 0
      local.set $var9
    end $label0
    local.get $var8
    i32.const 272
    i32.add
    global.set $global0
    local.get $var9
  )
  (func $func14 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (result i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    i32.const 0
    local.set $var5
    block $label0
      local.get $var1
      local.get $var2
      i32.ge_u
      br_if $label0
      local.get $var0
      local.get $var1
      i32.add
      i32.load8_u
      i32.const 34
      i32.ne
      br_if $label0
      local.get $var1
      i32.const 1
      i32.add
      local.tee $var1
      local.get $var2
      i32.ge_u
      br_if $label0
      i32.const 0
      local.set $var6
      loop $label17
        local.get $var1
        i32.const 1
        i32.add
        local.set $var7
        block $label2
          block $label1
            local.get $var0
            local.get $var1
            i32.add
            i32.load8_u
            local.tee $var8
            i32.const 92
            i32.eq
            br_if $label1
            local.get $var7
            local.set $var1
            br $label2
          end $label1
          i32.const 0
          local.set $var5
          local.get $var2
          local.get $var7
          i32.sub
          i32.const 5
          i32.lt_u
          br_if $label0
          local.get $var0
          local.get $var7
          i32.add
          local.tee $var7
          i32.load8_u
          i32.const 117
          i32.ne
          br_if $label0
          i32.const -48
          local.set $var9
          i32.const -48
          local.set $var10
          block $label6
            block $label3
              local.get $var7
              i32.load8_u offset=1
              local.tee $var8
              i32.const -48
              i32.add
              i32.const 255
              i32.and
              i32.const 10
              i32.lt_u
              br_if $label3
              block $label4
                local.get $var8
                i32.const -97
                i32.add
                i32.const 255
                i32.and
                i32.const 6
                i32.ge_u
                br_if $label4
                i32.const -87
                local.set $var10
                br $label3
              end $label4
              block $label5
                local.get $var8
                i32.const -65
                i32.add
                i32.const 255
                i32.and
                i32.const 5
                i32.le_u
                br_if $label5
                i32.const -1
                local.set $var8
                br $label6
              end $label5
              i32.const -55
              local.set $var10
            end $label3
            block $label7
              local.get $var7
              i32.load8_u offset=2
              local.tee $var5
              i32.const -48
              i32.add
              i32.const 255
              i32.and
              i32.const 10
              i32.lt_u
              br_if $label7
              block $label8
                local.get $var5
                i32.const -97
                i32.add
                i32.const 255
                i32.and
                i32.const 6
                i32.ge_u
                br_if $label8
                i32.const -87
                local.set $var9
                br $label7
              end $label8
              block $label9
                local.get $var5
                i32.const -65
                i32.add
                i32.const 255
                i32.and
                i32.const 5
                i32.le_u
                br_if $label9
                i32.const -1
                local.set $var8
                br $label6
              end $label9
              i32.const -55
              local.set $var9
            end $label7
            i32.const -48
            local.set $var11
            i32.const -48
            local.set $var12
            block $label10
              local.get $var7
              i32.load8_u offset=3
              local.tee $var13
              i32.const -48
              i32.add
              i32.const 255
              i32.and
              i32.const 10
              i32.lt_u
              br_if $label10
              block $label11
                local.get $var13
                i32.const -97
                i32.add
                i32.const 255
                i32.and
                i32.const 6
                i32.ge_u
                br_if $label11
                i32.const -87
                local.set $var12
                br $label10
              end $label11
              block $label12
                local.get $var13
                i32.const -65
                i32.add
                i32.const 255
                i32.and
                i32.const 5
                i32.le_u
                br_if $label12
                i32.const -1
                local.set $var8
                br $label6
              end $label12
              i32.const -55
              local.set $var12
            end $label10
            block $label13
              local.get $var7
              i32.load8_u offset=4
              local.tee $var7
              i32.const -48
              i32.add
              i32.const 255
              i32.and
              i32.const 10
              i32.lt_u
              br_if $label13
              block $label14
                local.get $var7
                i32.const -97
                i32.add
                i32.const 255
                i32.and
                i32.const 6
                i32.ge_u
                br_if $label14
                i32.const -87
                local.set $var11
                br $label13
              end $label14
              block $label15
                local.get $var7
                i32.const -65
                i32.add
                i32.const 255
                i32.and
                i32.const 5
                i32.le_u
                br_if $label15
                i32.const -1
                local.set $var8
                br $label6
              end $label15
              i32.const -55
              local.set $var11
            end $label13
            local.get $var11
            local.get $var7
            i32.add
            local.get $var9
            local.get $var5
            i32.add
            i32.const 4
            i32.shl
            local.get $var10
            local.get $var8
            i32.add
            i32.const 8
            i32.shl
            i32.or
            local.get $var12
            local.get $var13
            i32.add
            i32.or
            i32.const 4
            i32.shl
            i32.or
            local.set $var8
          end $label6
          local.get $var1
          i32.const 6
          i32.add
          local.set $var1
        end $label2
        i32.const 0
        local.set $var5
        local.get $var8
        local.get $var3
        local.get $var6
        i32.add
        i32.load8_u
        i32.ne
        br_if $label0
        block $label16
          local.get $var6
          i32.const 1
          i32.add
          local.tee $var6
          local.get $var4
          i32.ge_u
          br_if $label16
          local.get $var1
          local.get $var2
          i32.lt_u
          br_if $label17
        end $label16
      end $label17
      local.get $var6
      local.get $var4
      i32.lt_u
      br_if $label0
      local.get $var1
      local.get $var2
      i32.ge_u
      br_if $label0
      local.get $var0
      local.get $var1
      i32.add
      i32.load8_u
      i32.const 34
      i32.eq
      local.set $var5
    end $label0
    local.get $var5
  )
  (func $parse_term_bank (;15;) (export "parse_term_bank") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (result i32)
    local.get $var0
    local.get $var1
    local.get $var2
    local.get $var3
    i32.const 0
    local.get $var4
    local.get $var5
    local.get $var6
    i32.const 0
    i32.ne
    call $func16
  )
  (func $func16 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (result i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    global.get $global0
    i32.const 32
    i32.sub
    local.tee $var8
    global.set $global0
    block $label1
      block $label6
        block $label0
          local.get $var5
          br_if $label0
          i32.const -1
          local.set $var9
          local.get $var6
          br_if $label1
          local.get $var0
          i32.eqz
          br_if $label1
          local.get $var1
          i32.eqz
          br_if $label1
          local.get $var2
          i32.eqz
          br_if $label1
          local.get $var3
          i32.eqz
          br_if $label1
          i32.const 0
          local.set $var10
          i32.const 0
          local.get $var3
          i32.store offset=2548
          block $label2
            loop $label3
              local.get $var0
              local.get $var10
              i32.add
              i32.load8_u
              local.tee $var6
              i32.const -9
              i32.add
              local.tee $var5
              i32.const 23
              i32.gt_u
              br_if $label2
              i32.const 1
              local.get $var5
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label2
              local.get $var1
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              i32.ne
              br_if $label3
              br $label1
            end $label3
          end $label2
          local.get $var10
          local.get $var1
          i32.ge_u
          br_if $label1
          local.get $var6
          i32.const 91
          i32.ne
          br_if $label1
          block $label4
            local.get $var10
            i32.const 1
            i32.add
            local.tee $var10
            local.get $var1
            i32.ge_u
            br_if $label4
            loop $label5
              local.get $var0
              local.get $var10
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var5
              i32.const 23
              i32.gt_u
              br_if $label4
              i32.const 1
              local.get $var5
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label4
              local.get $var1
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              i32.ne
              br_if $label5
            end $label5
            local.get $var1
            local.set $var10
            br $label6
          end $label4
          local.get $var10
          local.get $var1
          i32.ge_u
          br_if $label6
          local.get $var0
          local.get $var10
          i32.add
          i32.load8_u
          i32.const 93
          i32.ne
          br_if $label6
          block $label7
            local.get $var10
            i32.const 1
            i32.add
            local.tee $var3
            local.get $var1
            i32.ge_u
            br_if $label7
            loop $label8
              local.get $var0
              local.get $var3
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var10
              i32.const 23
              i32.gt_u
              br_if $label7
              i32.const 1
              local.get $var10
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label7
              local.get $var1
              local.get $var3
              i32.const 1
              i32.add
              local.tee $var3
              i32.ne
              br_if $label8
            end $label8
            local.get $var1
            local.set $var3
          end $label7
          i32.const -1
          i32.const 0
          local.get $var3
          local.get $var1
          i32.ne
          select
          local.set $var9
          br $label1
        end $label0
        i32.const -1
        local.set $var9
        local.get $var0
        i32.eqz
        br_if $label1
        local.get $var1
        i32.eqz
        br_if $label1
        local.get $var2
        i32.eqz
        br_if $label1
        local.get $var3
        i32.eqz
        br_if $label1
        local.get $var6
        i32.eqz
        br_if $label1
        i32.const 0
        local.set $var10
        i32.const 0
        local.get $var3
        i32.store offset=2548
        local.get $var8
        i32.const 0
        i32.store offset=28
        local.get $var8
        i64.const 0
        i64.store offset=20 align=4
        local.get $var8
        local.get $var6
        i32.store offset=16
        local.get $var8
        local.get $var1
        i32.store offset=12
        local.get $var8
        local.get $var5
        i32.store offset=8
        local.get $var8
        local.get $var0
        i32.store offset=4
        block $label9
          local.get $var8
          i32.const 4
          i32.add
          call $func17
          local.tee $var5
          i32.const 1
          i32.lt_s
          br_if $label9
          local.get $var2
          local.set $var1
          i32.const 0
          local.set $var10
          loop $label14
            block $label10
              local.get $var10
              local.get $var3
              i32.lt_u
              br_if $label10
              i32.const -2
              local.set $var9
              local.get $var3
              i32.const 63161282
              i32.gt_u
              br_if $label1
              local.get $var2
              local.get $var3
              i32.const 68
              i32.mul
              i32.const 7
              i32.add
              i32.const -8
              i32.and
              local.tee $var6
              i32.const -1
              i32.xor
              i32.gt_u
              br_if $label1
              i32.const 0
              i32.load offset=2544
              local.get $var6
              local.get $var2
              i32.add
              local.tee $var5
              i32.ne
              br_if $label1
              i32.const 63161283
              local.get $var3
              i32.const 1
              i32.shr_u
              local.tee $var11
              i32.const 8192
              local.get $var11
              i32.const 8192
              i32.gt_u
              select
              local.tee $var11
              local.get $var3
              i32.add
              local.get $var3
              i32.const 63161283
              local.get $var11
              i32.sub
              i32.gt_u
              select
              local.tee $var3
              i32.const 68
              i32.mul
              local.get $var6
              i32.sub
              i32.const 7
              i32.add
              local.set $var11
              local.get $var5
              local.set $var6
              block $label11
                local.get $var5
                br_if $label11
                i32.const 104256
                local.set $var6
                i32.const 0
                i32.const 104256
                i32.store offset=2544
              end $label11
              local.get $var6
              i32.const 7
              i32.add
              i32.const -8
              i32.and
              local.tee $var6
              local.get $var11
              i32.const -8
              i32.and
              local.tee $var11
              i32.const -1
              i32.xor
              i32.gt_u
              br_if $label1
              block $label12
                local.get $var6
                local.get $var11
                i32.add
                local.tee $var11
                i32.const 16
                i32.shr_u
                local.get $var11
                i32.const 65528
                i32.and
                i32.const 0
                i32.ne
                i32.add
                local.tee $var12
                memory.size
                local.tee $var13
                i32.le_u
                br_if $label12
                local.get $var12
                local.get $var13
                i32.sub
                memory.grow
                i32.const 0
                i32.lt_s
                br_if $label1
              end $label12
              i32.const 0
              local.get $var11
              i32.store offset=2544
              local.get $var6
              i32.eqz
              br_if $label1
              local.get $var6
              local.get $var5
              i32.ne
              br_if $label1
              i32.const 0
              local.get $var3
              i32.store offset=2548
            end $label10
            local.get $var8
            i32.const 0
            i32.store
            block $label13
              local.get $var0
              local.get $var8
              i32.load offset=24
              local.get $var8
              i32.load offset=28
              local.get $var1
              local.get $var4
              local.get $var8
              i32.const 0
              i32.const 0
              i32.const 0
              i32.const 0
              local.get $var7
              i32.const 0
              call $func18
              br_if $label13
              i32.const -1
              local.set $var9
              br $label1
            end $label13
            local.get $var1
            i32.const 68
            i32.add
            local.set $var1
            local.get $var10
            i32.const 1
            i32.add
            local.set $var10
            local.get $var8
            i32.const 4
            i32.add
            local.get $var8
            i32.load
            call $func19
            local.tee $var5
            i32.const 0
            i32.gt_s
            br_if $label14
          end $label14
        end $label9
        i32.const -1
        local.get $var10
        local.get $var5
        select
        local.set $var9
        br $label1
      end $label6
      i32.const 0
      local.set $var6
      loop $label26
        block $label15
          local.get $var10
          local.get $var1
          i32.lt_u
          br_if $label15
          i32.const -1
          local.set $var9
          br $label1
        end $label15
        block $label16
          local.get $var6
          local.get $var3
          i32.lt_u
          br_if $label16
          i32.const -2
          local.set $var9
          local.get $var3
          i32.const 63161282
          i32.gt_u
          br_if $label1
          local.get $var2
          local.get $var3
          i32.const 68
          i32.mul
          i32.const 7
          i32.add
          i32.const -8
          i32.and
          local.tee $var11
          i32.const -1
          i32.xor
          i32.gt_u
          br_if $label1
          i32.const 0
          i32.load offset=2544
          local.get $var11
          local.get $var2
          i32.add
          local.tee $var5
          i32.ne
          br_if $label1
          i32.const 63161283
          local.get $var3
          i32.const 1
          i32.shr_u
          local.tee $var12
          i32.const 8192
          local.get $var12
          i32.const 8192
          i32.gt_u
          select
          local.tee $var12
          local.get $var3
          i32.add
          local.get $var3
          i32.const 63161283
          local.get $var12
          i32.sub
          i32.gt_u
          select
          local.tee $var3
          i32.const 68
          i32.mul
          local.get $var11
          i32.sub
          i32.const 7
          i32.add
          local.set $var12
          local.get $var5
          local.set $var11
          block $label17
            local.get $var5
            br_if $label17
            i32.const 104256
            local.set $var11
            i32.const 0
            i32.const 104256
            i32.store offset=2544
          end $label17
          local.get $var11
          i32.const 7
          i32.add
          i32.const -8
          i32.and
          local.tee $var11
          local.get $var12
          i32.const -8
          i32.and
          local.tee $var12
          i32.const -1
          i32.xor
          i32.gt_u
          br_if $label1
          block $label18
            local.get $var11
            local.get $var12
            i32.add
            local.tee $var12
            i32.const 16
            i32.shr_u
            local.get $var12
            i32.const 65528
            i32.and
            i32.const 0
            i32.ne
            i32.add
            local.tee $var13
            memory.size
            local.tee $var14
            i32.le_u
            br_if $label18
            local.get $var13
            local.get $var14
            i32.sub
            memory.grow
            i32.const 0
            i32.lt_s
            br_if $label1
          end $label18
          i32.const 0
          local.get $var12
          i32.store offset=2544
          local.get $var11
          i32.eqz
          br_if $label1
          local.get $var11
          local.get $var5
          i32.ne
          br_if $label1
          i32.const 0
          local.get $var3
          i32.store offset=2548
        end $label16
        local.get $var8
        i32.const 0
        i32.store offset=4
        i32.const -1
        local.set $var9
        local.get $var0
        local.get $var1
        local.get $var10
        local.get $var2
        local.get $var6
        i32.const 68
        i32.mul
        i32.add
        local.get $var4
        local.get $var8
        i32.const 4
        i32.add
        i32.const 0
        i32.const 0
        i32.const 0
        i32.const 0
        local.get $var7
        i32.const 0
        call $func18
        i32.eqz
        br_if $label1
        block $label19
          local.get $var8
          i32.load offset=4
          local.tee $var10
          local.get $var1
          i32.ge_u
          br_if $label19
          loop $label20
            local.get $var0
            local.get $var10
            i32.add
            i32.load8_u
            i32.const -9
            i32.add
            local.tee $var5
            i32.const 23
            i32.gt_u
            br_if $label19
            i32.const 1
            local.get $var5
            i32.shl
            i32.const 8388627
            i32.and
            i32.eqz
            br_if $label19
            local.get $var1
            local.get $var10
            i32.const 1
            i32.add
            local.tee $var10
            i32.ne
            br_if $label20
            br $label1
          end $label20
        end $label19
        local.get $var10
        local.get $var1
        i32.ge_u
        br_if $label1
        local.get $var6
        i32.const 1
        i32.add
        local.set $var6
        block $label21
          local.get $var0
          local.get $var10
          i32.add
          i32.load8_u
          local.tee $var5
          i32.const 44
          i32.eq
          br_if $label21
          local.get $var5
          i32.const 93
          i32.ne
          br_if $label1
          block $label22
            local.get $var10
            i32.const 1
            i32.add
            local.tee $var3
            local.get $var1
            i32.ge_u
            br_if $label22
            loop $label23
              local.get $var0
              local.get $var3
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var10
              i32.const 23
              i32.gt_u
              br_if $label22
              i32.const 1
              local.get $var10
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label22
              local.get $var1
              local.get $var3
              i32.const 1
              i32.add
              local.tee $var3
              i32.ne
              br_if $label23
            end $label23
            local.get $var1
            local.set $var3
          end $label22
          local.get $var6
          i32.const -1
          local.get $var3
          local.get $var1
          i32.eq
          select
          local.set $var9
          br $label1
        end $label21
        block $label24
          local.get $var10
          i32.const 1
          i32.add
          local.tee $var10
          local.get $var1
          i32.ge_u
          br_if $label24
          loop $label25
            local.get $var0
            local.get $var10
            i32.add
            i32.load8_u
            i32.const -9
            i32.add
            local.tee $var5
            i32.const 23
            i32.gt_u
            br_if $label24
            i32.const 1
            local.get $var5
            i32.shl
            i32.const 8388627
            i32.and
            i32.eqz
            br_if $label24
            local.get $var1
            local.get $var10
            i32.const 1
            i32.add
            local.tee $var10
            i32.ne
            br_if $label25
            br $label1
          end $label25
        end $label24
        local.get $var10
        local.get $var1
        i32.ge_u
        br_if $label1
        i32.const -1
        local.set $var9
        local.get $var0
        local.get $var10
        i32.add
        i32.load8_u
        i32.const 93
        i32.ne
        br_if $label26
      end $label26
    end $label1
    local.get $var8
    i32.const 32
    i32.add
    global.set $global0
    local.get $var9
  )
  (func $func17 (param $var0 i32) (result i32)
    (local $var1 i32)
    (local $var2 i32)
    (local $var3 i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    i32.const 0
    local.set $var1
    block $label0
      local.get $var0
      i32.load offset=16
      local.tee $var2
      local.get $var0
      i32.load offset=12
      local.tee $var3
      i32.ge_u
      br_if $label0
      local.get $var0
      i32.const 8
      i32.add
      local.set $var4
      local.get $var0
      i32.load offset=4
      local.tee $var5
      i32.const 4
      i32.add
      local.set $var6
      local.get $var0
      i32.load offset=20
      local.set $var7
      loop $label17
        local.get $var0
        local.get $var2
        i32.const 1
        i32.add
        local.tee $var8
        i32.store offset=16
        local.get $var2
        i32.const 3
        i32.shl
        local.set $var9
        block $label2
          block $label1
            local.get $var5
            br_if $label1
            i32.const 0
            local.set $var2
            br $label2
          end $label1
          local.get $var5
          local.get $var9
          i32.add
          i32.load
          local.set $var2
        end $label2
        block $label3
          local.get $var2
          local.get $var7
          i32.ge_u
          br_if $label3
          i32.const -1
          return
        end $label3
        block $label4
          local.get $var4
          i32.load
          local.tee $var10
          local.get $var2
          i32.ge_u
          br_if $label4
          i32.const -1
          return
        end $label4
        block $label5
          local.get $var6
          local.get $var9
          i32.add
          local.get $var4
          local.get $var5
          select
          i32.load
          local.tee $var9
          local.get $var10
          local.get $var2
          i32.sub
          i32.le_u
          br_if $label5
          i32.const -1
          return
        end $label5
        local.get $var0
        local.get $var9
        local.get $var2
        i32.add
        local.tee $var7
        i32.store offset=20
        local.get $var0
        i32.load
        local.set $var10
        block $label6
          local.get $var2
          local.get $var7
          i32.ge_u
          br_if $label6
          loop $label7
            local.get $var10
            local.get $var2
            i32.add
            i32.load8_u
            i32.const -9
            i32.add
            local.tee $var1
            i32.const 23
            i32.gt_u
            br_if $label6
            i32.const 1
            local.get $var1
            i32.shl
            i32.const 8388627
            i32.and
            i32.eqz
            br_if $label6
            i32.const -1
            local.set $var1
            local.get $var2
            i32.const 1
            i32.add
            local.set $var2
            local.get $var9
            i32.const -1
            i32.add
            local.tee $var9
            br_if $label7
            br $label0
          end $label7
        end $label6
        block $label8
          local.get $var2
          local.get $var7
          i32.lt_u
          br_if $label8
          i32.const -1
          return
        end $label8
        block $label9
          local.get $var10
          local.get $var2
          i32.add
          i32.load8_u
          i32.const 91
          i32.eq
          br_if $label9
          i32.const -1
          return
        end $label9
        block $label10
          local.get $var2
          i32.const 1
          i32.add
          local.tee $var2
          local.get $var7
          i32.ge_u
          br_if $label10
          loop $label11
            local.get $var10
            local.get $var2
            i32.add
            i32.load8_u
            i32.const -9
            i32.add
            local.tee $var9
            i32.const 23
            i32.gt_u
            br_if $label10
            i32.const 1
            local.get $var9
            i32.shl
            i32.const 8388627
            i32.and
            i32.eqz
            br_if $label10
            local.get $var7
            local.get $var2
            i32.const 1
            i32.add
            local.tee $var2
            i32.ne
            br_if $label11
          end $label11
          i32.const -1
          return
        end $label10
        block $label12
          local.get $var2
          local.get $var7
          i32.lt_u
          br_if $label12
          i32.const -1
          return
        end $label12
        block $label13
          local.get $var10
          local.get $var2
          i32.add
          i32.load8_u
          i32.const 93
          i32.eq
          br_if $label13
          local.get $var0
          local.get $var2
          i32.store offset=24
          i32.const 1
          return
        end $label13
        block $label16
          block $label14
            local.get $var2
            i32.const 1
            i32.add
            local.tee $var2
            local.get $var7
            i32.ge_u
            br_if $label14
            loop $label15
              local.get $var10
              local.get $var2
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var9
              i32.const 23
              i32.gt_u
              br_if $label14
              i32.const 1
              local.get $var9
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label14
              local.get $var7
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var2
              i32.ne
              br_if $label15
              br $label16
            end $label15
          end $label14
          i32.const -1
          local.set $var1
          local.get $var2
          local.get $var7
          i32.ne
          br_if $label0
        end $label16
        i32.const 0
        local.set $var1
        local.get $var8
        local.set $var2
        local.get $var8
        local.get $var3
        i32.ne
        br_if $label17
      end $label17
    end $label0
    local.get $var1
  )
  (func $func18 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (param $var8 i32) (param $var9 i32) (param $var10 i32) (param $var11 i32) (result i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i64)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 v128)
    (local $var23 i32)
    (local $var24 i32)
    (local $var25 i32)
    (local $var26 i32)
    (local $var27 i32)
    global.get $global0
    i32.const 16
    i32.sub
    local.tee $var12
    global.set $global0
    block $label1
      block $label36
        block $label0
          local.get $var10
          i32.eqz
          br_if $label0
          i32.const 0
          local.set $var13
          local.get $var2
          local.get $var1
          i32.ge_u
          br_if $label1
          local.get $var0
          local.get $var2
          i32.add
          i32.load8_u
          i32.const 91
          i32.ne
          br_if $label1
          block $label2
            local.get $var2
            i32.const 1
            i32.add
            local.tee $var14
            local.get $var1
            i32.ge_u
            br_if $label2
            loop $label3
              local.get $var0
              local.get $var14
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var2
              i32.const 23
              i32.gt_u
              br_if $label2
              i32.const 1
              local.get $var2
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label2
              local.get $var1
              local.get $var14
              i32.const 1
              i32.add
              local.tee $var14
              i32.ne
              br_if $label3
            end $label3
            i32.const 0
            local.set $var13
            br $label1
          end $label2
          i32.const 0
          local.set $var13
          local.get $var14
          local.get $var1
          i32.ge_u
          br_if $label1
          local.get $var0
          local.get $var14
          i32.add
          i32.load8_u
          i32.const 34
          i32.ne
          br_if $label1
          local.get $var14
          i32.const 1
          i32.add
          local.tee $var2
          local.get $var1
          i32.ge_u
          br_if $label1
          local.get $var0
          i32.const 5
          i32.add
          local.set $var15
          local.get $var0
          i32.const 4
          i32.add
          local.set $var16
          local.get $var0
          i32.const 3
          i32.add
          local.set $var17
          i32.const 0
          local.set $var18
          loop $label6
            block $label5
              block $label4
                local.get $var2
                i32.const 8
                i32.add
                local.tee $var10
                local.get $var1
                i32.le_u
                br_if $label4
                local.get $var2
                local.set $var10
                br $label5
              end $label4
              local.get $var0
              local.get $var2
              i32.add
              local.set $var13
              local.get $var10
              local.set $var2
              local.get $var13
              i64.load align=1
              local.tee $var19
              i64.const -1
              i64.xor
              local.get $var19
              i64.const 6655295901103053916
              i64.xor
              i64.const -72340172838076673
              i64.add
              local.get $var19
              i64.const -2314885530818453536
              i64.add
              i64.or
              local.get $var19
              i64.const 2459565876494606882
              i64.xor
              i64.const -72340172838076673
              i64.add
              i64.or
              i64.and
              i64.const -9187201950435737472
              i64.and
              local.tee $var19
              i64.eqz
              br_if $label6
              local.get $var19
              i64.ctz
              i32.wrap_i64
              i32.const 3
              i32.shr_u
              local.get $var10
              i32.add
              i32.const -8
              i32.add
              local.set $var10
            end $label5
            i32.const 0
            local.set $var13
            local.get $var10
            local.get $var1
            i32.ge_u
            br_if $label1
            block $label14
              block $label10
                block $label7
                  local.get $var0
                  local.get $var10
                  i32.add
                  i32.load8_u
                  local.tee $var20
                  i32.const 92
                  i32.ne
                  br_if $label7
                  local.get $var10
                  i32.const 1
                  i32.add
                  local.tee $var2
                  local.get $var1
                  i32.ge_u
                  br_if $label1
                  block $label8
                    block $label9
                      local.get $var0
                      local.get $var2
                      i32.add
                      i32.load8_u
                      i32.const -34
                      i32.add
                      br_table $label8 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label8 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label8 $label1 $label1 $label1 $label1 $label1 $label8 $label1 $label1 $label1 $label8 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label8 $label1 $label1 $label1 $label8 $label1 $label8 $label9 $label1
                    end $label9
                    local.get $var10
                    i32.const 6
                    i32.add
                    local.tee $var2
                    local.get $var1
                    i32.gt_u
                    br_if $label1
                    i32.const 1
                    local.set $var18
                    local.get $var10
                    i32.const 2
                    i32.add
                    local.tee $var20
                    local.get $var2
                    i32.ge_u
                    br_if $label10
                    block $label11
                      local.get $var0
                      local.get $var20
                      i32.add
                      i32.load8_u
                      local.tee $var20
                      i32.const -58
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 245
                      i32.gt_u
                      br_if $label11
                      local.get $var20
                      i32.const -33
                      i32.and
                      i32.const -71
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 250
                      i32.lt_u
                      br_if $label1
                    end $label11
                    block $label12
                      local.get $var17
                      local.get $var10
                      i32.add
                      i32.load8_u
                      local.tee $var20
                      i32.const -58
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 245
                      i32.gt_u
                      br_if $label12
                      local.get $var20
                      i32.const -33
                      i32.and
                      i32.const -71
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 250
                      i32.lt_u
                      br_if $label1
                    end $label12
                    block $label13
                      local.get $var16
                      local.get $var10
                      i32.add
                      i32.load8_u
                      local.tee $var20
                      i32.const -58
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 245
                      i32.gt_u
                      br_if $label13
                      local.get $var20
                      i32.const -33
                      i32.and
                      i32.const -71
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 250
                      i32.lt_u
                      br_if $label1
                    end $label13
                    local.get $var15
                    local.get $var10
                    i32.add
                    i32.load8_u
                    local.tee $var10
                    i32.const -58
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 245
                    i32.gt_u
                    br_if $label10
                    local.get $var10
                    i32.const -33
                    i32.and
                    i32.const -71
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 250
                    i32.ge_u
                    br_if $label10
                    br $label1
                  end $label8
                  local.get $var10
                  i32.const 2
                  i32.add
                  local.set $var2
                  i32.const 1
                  local.set $var18
                  br $label10
                end $label7
                local.get $var20
                i32.const 32
                i32.lt_u
                br_if $label1
                local.get $var10
                i32.const 1
                i32.add
                local.set $var2
                local.get $var20
                i32.const 34
                i32.eq
                br_if $label14
              end $label10
              local.get $var2
              local.get $var1
              i32.lt_u
              br_if $label6
              br $label1
            end $label14
          end $label6
          local.get $var3
          local.get $var14
          i32.store
          local.get $var3
          local.get $var2
          local.get $var14
          i32.sub
          i32.store offset=4
          block $label15
            local.get $var2
            local.get $var1
            i32.ge_u
            br_if $label15
            loop $label16
              local.get $var0
              local.get $var2
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var10
              i32.const 23
              i32.gt_u
              br_if $label15
              i32.const 1
              local.get $var10
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label15
              local.get $var1
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var2
              i32.ne
              br_if $label16
              br $label1
            end $label16
          end $label15
          local.get $var2
          local.get $var1
          i32.ge_u
          br_if $label1
          local.get $var0
          local.get $var2
          i32.add
          i32.load8_u
          i32.const 44
          i32.ne
          br_if $label1
          block $label17
            local.get $var2
            i32.const 1
            i32.add
            local.tee $var14
            local.get $var1
            i32.ge_u
            br_if $label17
            loop $label18
              local.get $var0
              local.get $var14
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var2
              i32.const 23
              i32.gt_u
              br_if $label17
              i32.const 1
              local.get $var2
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label17
              local.get $var1
              local.get $var14
              i32.const 1
              i32.add
              local.tee $var14
              i32.ne
              br_if $label18
              br $label1
            end $label18
          end $label17
          local.get $var14
          local.get $var1
          i32.ge_u
          br_if $label1
          local.get $var0
          local.get $var14
          i32.add
          i32.load8_u
          i32.const 34
          i32.ne
          br_if $label1
          local.get $var14
          i32.const 1
          i32.add
          local.tee $var2
          local.get $var1
          i32.ge_u
          br_if $label1
          i32.const 0
          local.set $var21
          loop $label21
            block $label20
              block $label19
                local.get $var2
                i32.const 8
                i32.add
                local.tee $var10
                local.get $var1
                i32.le_u
                br_if $label19
                local.get $var2
                local.set $var10
                br $label20
              end $label19
              local.get $var0
              local.get $var2
              i32.add
              local.set $var13
              local.get $var10
              local.set $var2
              local.get $var13
              i64.load align=1
              local.tee $var19
              i64.const -1
              i64.xor
              local.get $var19
              i64.const 6655295901103053916
              i64.xor
              i64.const -72340172838076673
              i64.add
              local.get $var19
              i64.const -2314885530818453536
              i64.add
              i64.or
              local.get $var19
              i64.const 2459565876494606882
              i64.xor
              i64.const -72340172838076673
              i64.add
              i64.or
              i64.and
              i64.const -9187201950435737472
              i64.and
              local.tee $var19
              i64.eqz
              br_if $label21
              local.get $var19
              i64.ctz
              i32.wrap_i64
              i32.const 3
              i32.shr_u
              local.get $var10
              i32.add
              i32.const -8
              i32.add
              local.set $var10
            end $label20
            i32.const 0
            local.set $var13
            local.get $var10
            local.get $var1
            i32.ge_u
            br_if $label1
            block $label29
              block $label25
                block $label22
                  local.get $var0
                  local.get $var10
                  i32.add
                  i32.load8_u
                  local.tee $var20
                  i32.const 92
                  i32.ne
                  br_if $label22
                  local.get $var10
                  i32.const 1
                  i32.add
                  local.tee $var2
                  local.get $var1
                  i32.ge_u
                  br_if $label1
                  block $label23
                    block $label24
                      local.get $var0
                      local.get $var2
                      i32.add
                      i32.load8_u
                      i32.const -34
                      i32.add
                      br_table $label23 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label23 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label23 $label1 $label1 $label1 $label1 $label1 $label23 $label1 $label1 $label1 $label23 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label23 $label1 $label1 $label1 $label23 $label1 $label23 $label24 $label1
                    end $label24
                    local.get $var10
                    i32.const 6
                    i32.add
                    local.tee $var2
                    local.get $var1
                    i32.gt_u
                    br_if $label1
                    i32.const 1
                    local.set $var21
                    local.get $var10
                    i32.const 2
                    i32.add
                    local.tee $var20
                    local.get $var2
                    i32.ge_u
                    br_if $label25
                    block $label26
                      local.get $var0
                      local.get $var20
                      i32.add
                      i32.load8_u
                      local.tee $var20
                      i32.const -58
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 245
                      i32.gt_u
                      br_if $label26
                      local.get $var20
                      i32.const -33
                      i32.and
                      i32.const -71
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 250
                      i32.lt_u
                      br_if $label1
                    end $label26
                    block $label27
                      local.get $var17
                      local.get $var10
                      i32.add
                      i32.load8_u
                      local.tee $var20
                      i32.const -58
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 245
                      i32.gt_u
                      br_if $label27
                      local.get $var20
                      i32.const -33
                      i32.and
                      i32.const -71
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 250
                      i32.lt_u
                      br_if $label1
                    end $label27
                    block $label28
                      local.get $var16
                      local.get $var10
                      i32.add
                      i32.load8_u
                      local.tee $var20
                      i32.const -58
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 245
                      i32.gt_u
                      br_if $label28
                      local.get $var20
                      i32.const -33
                      i32.and
                      i32.const -71
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 250
                      i32.lt_u
                      br_if $label1
                    end $label28
                    local.get $var15
                    local.get $var10
                    i32.add
                    i32.load8_u
                    local.tee $var10
                    i32.const -58
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 245
                    i32.gt_u
                    br_if $label25
                    local.get $var10
                    i32.const -33
                    i32.and
                    i32.const -71
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 250
                    i32.ge_u
                    br_if $label25
                    br $label1
                  end $label23
                  local.get $var10
                  i32.const 2
                  i32.add
                  local.set $var2
                  i32.const 1
                  local.set $var21
                  br $label25
                end $label22
                local.get $var20
                i32.const 32
                i32.lt_u
                br_if $label1
                local.get $var10
                i32.const 1
                i32.add
                local.set $var2
                local.get $var20
                i32.const 34
                i32.eq
                br_if $label29
              end $label25
              local.get $var2
              local.get $var1
              i32.lt_u
              br_if $label21
              br $label1
            end $label29
          end $label21
          local.get $var3
          local.get $var14
          i32.store offset=8
          local.get $var3
          local.get $var2
          local.get $var14
          i32.sub
          i32.store offset=12
          block $label30
            local.get $var11
            i32.eqz
            br_if $label30
            local.get $var11
            local.get $var21
            i32.const 1
            i32.shl
            local.get $var18
            i32.or
            i32.store
          end $label30
          block $label31
            local.get $var2
            local.get $var1
            i32.ge_u
            br_if $label31
            loop $label32
              local.get $var0
              local.get $var2
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var10
              i32.const 23
              i32.gt_u
              br_if $label31
              i32.const 1
              local.get $var10
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label31
              local.get $var1
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var2
              i32.ne
              br_if $label32
              br $label1
            end $label32
          end $label31
          local.get $var2
          local.get $var1
          i32.ge_u
          br_if $label1
          local.get $var0
          local.get $var2
          i32.add
          i32.load8_u
          i32.const 44
          i32.ne
          br_if $label1
          block $label33
            local.get $var2
            i32.const 1
            i32.add
            local.tee $var2
            local.get $var1
            i32.ge_u
            br_if $label33
            loop $label34
              local.get $var0
              local.get $var2
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var10
              i32.const 23
              i32.gt_u
              br_if $label33
              i32.const 1
              local.get $var10
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label33
              local.get $var1
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var2
              i32.ne
              br_if $label34
              br $label1
            end $label34
          end $label33
          local.get $var1
          local.get $var2
          i32.le_u
          br_if $label1
          block $label35
            local.get $var0
            local.get $var2
            i32.add
            local.tee $var14
            i32.load8_u
            local.tee $var10
            i32.const 110
            i32.ne
            br_if $label35
            local.get $var1
            local.get $var2
            i32.sub
            i32.const 4
            i32.lt_u
            br_if $label1
            local.get $var14
            i32.const 1
            i32.add
            i32.load8_u
            i32.const 117
            i32.ne
            br_if $label1
            local.get $var14
            i32.const 2
            i32.add
            i32.load8_u
            i32.const 108
            i32.ne
            br_if $label1
            local.get $var14
            i32.const 3
            i32.add
            i32.load8_u
            i32.const 108
            i32.ne
            br_if $label1
            local.get $var2
            i32.const 4
            i32.add
            local.set $var14
            br $label36
          end $label35
          local.get $var10
          i32.const 34
          i32.ne
          br_if $label1
          local.get $var2
          i32.const 1
          i32.add
          local.tee $var14
          local.get $var1
          i32.ge_u
          br_if $label1
          loop $label38
            block $label37
              local.get $var14
              local.tee $var10
              i32.const 8
              i32.add
              local.tee $var14
              local.get $var1
              i32.gt_u
              br_if $label37
              local.get $var0
              local.get $var10
              i32.add
              i64.load align=1
              local.tee $var19
              i64.const -1
              i64.xor
              local.get $var19
              i64.const 6655295901103053916
              i64.xor
              i64.const -72340172838076673
              i64.add
              local.get $var19
              i64.const -2314885530818453536
              i64.add
              i64.or
              local.get $var19
              i64.const 2459565876494606882
              i64.xor
              i64.const -72340172838076673
              i64.add
              i64.or
              i64.and
              i64.const -9187201950435737472
              i64.and
              local.tee $var19
              i64.eqz
              br_if $label38
              local.get $var19
              i64.ctz
              i32.wrap_i64
              i32.const 3
              i32.shr_u
              local.get $var10
              i32.add
              local.set $var10
            end $label37
            local.get $var10
            local.get $var1
            i32.ge_u
            br_if $label1
            block $label42
              block $label39
                local.get $var0
                local.get $var10
                i32.add
                i32.load8_u
                local.tee $var11
                i32.const 92
                i32.ne
                br_if $label39
                local.get $var10
                i32.const 1
                i32.add
                local.tee $var14
                local.get $var1
                i32.ge_u
                br_if $label1
                block $label40
                  block $label41
                    local.get $var0
                    local.get $var14
                    i32.add
                    i32.load8_u
                    i32.const -34
                    i32.add
                    br_table $label40 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label40 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label40 $label1 $label1 $label1 $label1 $label1 $label40 $label1 $label1 $label1 $label40 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label40 $label1 $label1 $label1 $label40 $label1 $label40 $label41 $label1
                  end $label41
                  local.get $var10
                  i32.const 6
                  i32.add
                  local.tee $var14
                  local.get $var1
                  i32.gt_u
                  br_if $label1
                  local.get $var10
                  i32.const 2
                  i32.add
                  local.tee $var11
                  local.get $var14
                  i32.ge_u
                  br_if $label42
                  block $label43
                    local.get $var0
                    local.get $var11
                    i32.add
                    i32.load8_u
                    local.tee $var11
                    i32.const -58
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 245
                    i32.gt_u
                    br_if $label43
                    local.get $var11
                    i32.const -33
                    i32.and
                    i32.const -71
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 250
                    i32.lt_u
                    br_if $label1
                  end $label43
                  block $label44
                    local.get $var17
                    local.get $var10
                    i32.add
                    i32.load8_u
                    local.tee $var11
                    i32.const -58
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 245
                    i32.gt_u
                    br_if $label44
                    local.get $var11
                    i32.const -33
                    i32.and
                    i32.const -71
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 250
                    i32.lt_u
                    br_if $label1
                  end $label44
                  block $label45
                    local.get $var16
                    local.get $var10
                    i32.add
                    i32.load8_u
                    local.tee $var11
                    i32.const -58
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 245
                    i32.gt_u
                    br_if $label45
                    local.get $var11
                    i32.const -33
                    i32.and
                    i32.const -71
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 250
                    i32.lt_u
                    br_if $label1
                  end $label45
                  local.get $var15
                  local.get $var10
                  i32.add
                  i32.load8_u
                  local.tee $var10
                  i32.const -58
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 245
                  i32.gt_u
                  br_if $label42
                  local.get $var10
                  i32.const -33
                  i32.and
                  i32.const -71
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 250
                  i32.ge_u
                  br_if $label42
                  br $label1
                end $label40
                local.get $var10
                i32.const 2
                i32.add
                local.set $var14
                br $label42
              end $label39
              local.get $var11
              i32.const 32
              i32.lt_u
              br_if $label1
              local.get $var10
              i32.const 1
              i32.add
              local.set $var14
              local.get $var11
              i32.const 34
              i32.eq
              br_if $label36
            end $label42
            local.get $var14
            local.get $var1
            i32.lt_u
            br_if $label38
            br $label1
          end $label38
        end $label0
        i32.const 0
        local.set $var13
        local.get $var2
        local.get $var1
        i32.ge_u
        br_if $label1
        local.get $var0
        local.get $var2
        i32.add
        i32.load8_u
        i32.const 91
        i32.ne
        br_if $label1
        local.get $var3
        v128.const i32x4 0x00000000 0x00000000 0x00000000 0x00000000
        local.tee $var22
        v128.store align=4
        local.get $var3
        local.get $var22
        v128.store offset=48 align=4
        local.get $var3
        i32.const 32
        i32.add
        i64.const 0
        i64.store align=4
        local.get $var3
        i32.const 16
        i32.add
        local.get $var22
        v128.store align=4
        local.get $var3
        i32.const 40
        i32.add
        i64.const -4294967296
        i64.store align=4
        local.get $var3
        i32.const 64
        i32.add
        local.tee $var23
        i32.const 0
        i32.store
        block $label46
          local.get $var11
          i32.eqz
          br_if $label46
          local.get $var11
          i32.const 3
          i32.store
        end $label46
        local.get $var3
        i32.const 48
        i32.add
        local.set $var24
        local.get $var3
        i32.const 56
        i32.add
        i32.const 0
        local.get $var4
        select
        local.set $var25
        local.get $var0
        i32.const 5
        i32.add
        local.set $var15
        local.get $var0
        i32.const 4
        i32.add
        local.set $var16
        local.get $var0
        i32.const 3
        i32.add
        local.set $var17
        local.get $var3
        i32.const 60
        i32.add
        local.set $var26
        local.get $var0
        i32.const -1
        i32.add
        local.set $var21
        local.get $var2
        i32.const 1
        i32.add
        local.set $var2
        i32.const 0
        local.set $var18
        loop $label99
          i32.const 0
          local.set $var13
          local.get $var2
          local.get $var1
          i32.ge_u
          br_if $label1
          block $label47
            loop $label48
              local.get $var0
              local.get $var2
              i32.add
              local.tee $var4
              i32.load8_u
              local.tee $var14
              i32.const -9
              i32.add
              local.tee $var10
              i32.const 23
              i32.gt_u
              br_if $label47
              i32.const 1
              local.get $var10
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label47
              local.get $var1
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var2
              i32.ne
              br_if $label48
              br $label1
            end $label48
          end $label47
          local.get $var2
          local.get $var1
          i32.ge_u
          br_if $label1
          block $label49
            local.get $var14
            i32.const 93
            i32.ne
            br_if $label49
            local.get $var5
            local.get $var2
            i32.const 1
            i32.add
            i32.store
            local.get $var3
            i32.load offset=4
            i32.const 0
            i32.ne
            local.set $var13
            br $label1
          end $label49
          local.get $var12
          i32.const 0
          i32.store offset=4
          block $label75
            block $label72
              block $label62
                block $label50
                  local.get $var11
                  i32.eqz
                  br_if $label50
                  local.get $var18
                  i32.const 1
                  i32.gt_u
                  br_if $label50
                  i32.const 0
                  local.set $var13
                  local.get $var14
                  i32.const 34
                  i32.ne
                  br_if $label1
                  local.get $var2
                  i32.const 1
                  i32.add
                  local.tee $var10
                  local.get $var1
                  i32.ge_u
                  br_if $label1
                  i32.const 0
                  local.set $var27
                  loop $label53
                    block $label52
                      block $label51
                        local.get $var10
                        i32.const 8
                        i32.add
                        local.tee $var13
                        local.get $var1
                        i32.le_u
                        br_if $label51
                        local.get $var10
                        local.set $var14
                        br $label52
                      end $label51
                      local.get $var0
                      local.get $var10
                      i32.add
                      local.set $var14
                      local.get $var13
                      local.set $var10
                      local.get $var14
                      i64.load align=1
                      local.tee $var19
                      i64.const -1
                      i64.xor
                      local.get $var19
                      i64.const 2459565876494606882
                      i64.xor
                      i64.const -72340172838076673
                      i64.add
                      local.get $var19
                      i64.const 6655295901103053916
                      i64.xor
                      i64.const -72340172838076673
                      i64.add
                      i64.or
                      local.get $var19
                      i64.const -2314885530818453536
                      i64.add
                      i64.or
                      i64.and
                      i64.const -9187201950435737472
                      i64.and
                      local.tee $var19
                      i64.eqz
                      br_if $label53
                      local.get $var19
                      i64.ctz
                      i32.wrap_i64
                      i32.const 3
                      i32.shr_u
                      local.get $var13
                      i32.add
                      i32.const -8
                      i32.add
                      local.set $var14
                    end $label52
                    i32.const 0
                    local.set $var13
                    local.get $var14
                    local.get $var1
                    i32.ge_u
                    br_if $label1
                    block $label61
                      block $label57
                        block $label54
                          local.get $var0
                          local.get $var14
                          i32.add
                          i32.load8_u
                          local.tee $var20
                          i32.const 92
                          i32.ne
                          br_if $label54
                          local.get $var14
                          i32.const 1
                          i32.add
                          local.tee $var10
                          local.get $var1
                          i32.ge_u
                          br_if $label1
                          block $label55
                            block $label56
                              local.get $var0
                              local.get $var10
                              i32.add
                              i32.load8_u
                              i32.const -34
                              i32.add
                              br_table $label55 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label55 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label55 $label1 $label1 $label1 $label1 $label1 $label55 $label1 $label1 $label1 $label55 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label55 $label1 $label1 $label1 $label55 $label1 $label55 $label56 $label1
                            end $label56
                            local.get $var14
                            i32.const 6
                            i32.add
                            local.tee $var10
                            local.get $var1
                            i32.gt_u
                            br_if $label1
                            i32.const 1
                            local.set $var27
                            local.get $var14
                            i32.const 2
                            i32.add
                            local.tee $var20
                            local.get $var10
                            i32.ge_u
                            br_if $label57
                            block $label58
                              local.get $var0
                              local.get $var20
                              i32.add
                              i32.load8_u
                              local.tee $var20
                              i32.const -58
                              i32.add
                              i32.const 255
                              i32.and
                              i32.const 245
                              i32.gt_u
                              br_if $label58
                              local.get $var20
                              i32.const -33
                              i32.and
                              i32.const -71
                              i32.add
                              i32.const 255
                              i32.and
                              i32.const 250
                              i32.lt_u
                              br_if $label1
                            end $label58
                            block $label59
                              local.get $var17
                              local.get $var14
                              i32.add
                              i32.load8_u
                              local.tee $var20
                              i32.const -58
                              i32.add
                              i32.const 255
                              i32.and
                              i32.const 245
                              i32.gt_u
                              br_if $label59
                              local.get $var20
                              i32.const -33
                              i32.and
                              i32.const -71
                              i32.add
                              i32.const 255
                              i32.and
                              i32.const 250
                              i32.lt_u
                              br_if $label1
                            end $label59
                            block $label60
                              local.get $var16
                              local.get $var14
                              i32.add
                              i32.load8_u
                              local.tee $var20
                              i32.const -58
                              i32.add
                              i32.const 255
                              i32.and
                              i32.const 245
                              i32.gt_u
                              br_if $label60
                              local.get $var20
                              i32.const -33
                              i32.and
                              i32.const -71
                              i32.add
                              i32.const 255
                              i32.and
                              i32.const 250
                              i32.lt_u
                              br_if $label1
                            end $label60
                            local.get $var15
                            local.get $var14
                            i32.add
                            i32.load8_u
                            local.tee $var14
                            i32.const -58
                            i32.add
                            i32.const 255
                            i32.and
                            i32.const 245
                            i32.gt_u
                            br_if $label57
                            local.get $var14
                            i32.const -33
                            i32.and
                            i32.const -71
                            i32.add
                            i32.const 255
                            i32.and
                            i32.const 250
                            i32.ge_u
                            br_if $label57
                            br $label1
                          end $label55
                          local.get $var14
                          i32.const 2
                          i32.add
                          local.set $var10
                          i32.const 1
                          local.set $var27
                          br $label57
                        end $label54
                        local.get $var20
                        i32.const 32
                        i32.lt_u
                        br_if $label1
                        local.get $var14
                        i32.const 1
                        i32.add
                        local.set $var10
                        local.get $var20
                        i32.const 34
                        i32.eq
                        br_if $label61
                      end $label57
                      local.get $var10
                      local.get $var1
                      i32.lt_u
                      br_if $label53
                      br $label1
                    end $label61
                  end $label53
                  local.get $var12
                  local.get $var10
                  i32.store offset=4
                  local.get $var27
                  br_if $label62
                  local.get $var11
                  local.get $var11
                  i32.load
                  i32.const -2
                  local.get $var18
                  i32.rotl
                  i32.and
                  i32.store
                  br $label62
                end $label50
                block $label69
                  block $label63
                    local.get $var18
                    i32.const -3
                    i32.and
                    i32.const 4
                    i32.ne
                    br_if $label63
                    local.get $var2
                    local.set $var14
                    block $label65
                      loop $label68
                        block $label64
                          local.get $var1
                          local.get $var14
                          local.tee $var10
                          i32.ne
                          br_if $label64
                          local.get $var1
                          local.set $var10
                          br $label65
                        end $label64
                        block $label66
                          block $label67
                            local.get $var0
                            local.get $var10
                            i32.add
                            i32.load8_u
                            local.tee $var13
                            i32.const -10
                            i32.add
                            br_table $label65 $label66 $label66 $label65 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label65 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label66 $label65 $label67
                          end $label67
                          local.get $var13
                          i32.const 93
                          i32.eq
                          br_if $label65
                          local.get $var13
                          i32.const 125
                          i32.eq
                          br_if $label65
                        end $label66
                        local.get $var10
                        i32.const 1
                        i32.add
                        local.set $var14
                        local.get $var13
                        i32.const 9
                        i32.ne
                        br_if $label68
                      end $label68
                    end $label65
                    local.get $var10
                    local.get $var2
                    i32.ne
                    br_if $label69
                    i32.const 0
                    local.set $var13
                    br $label1
                  end $label63
                  block $label70
                    local.get $var18
                    i32.const 5
                    i32.ne
                    br_if $label70
                    block $label71
                      local.get $var8
                      i32.eqz
                      br_if $label71
                      local.get $var0
                      local.get $var1
                      local.get $var2
                      local.get $var6
                      local.get $var7
                      local.get $var3
                      local.get $var12
                      i32.const 4
                      i32.add
                      local.get $var8
                      local.get $var9
                      call $func42
                      br_if $label72
                      local.get $var4
                      i32.load8_u
                      local.set $var14
                    end $label71
                    block $label74
                      block $label73
                        local.get $var14
                        i32.const 223
                        i32.and
                        i32.const 91
                        i32.ne
                        br_if $label73
                        local.get $var0
                        local.get $var1
                        local.get $var2
                        local.get $var12
                        i32.const 4
                        i32.add
                        local.get $var25
                        local.get $var26
                        local.get $var23
                        i32.const 0
                        call $func13
                        local.set $var10
                        br $label74
                      end $label73
                      local.get $var0
                      local.get $var1
                      local.get $var2
                      local.get $var12
                      i32.const 4
                      i32.add
                      call $func12
                      local.set $var10
                    end $label74
                    local.get $var10
                    br_if $label72
                    i32.const 0
                    local.set $var13
                    br $label1
                  end $label70
                  local.get $var0
                  local.get $var1
                  local.get $var2
                  local.get $var12
                  i32.const 4
                  i32.add
                  call $func12
                  br_if $label62
                  i32.const 0
                  local.set $var13
                  br $label1
                end $label69
                local.get $var12
                local.get $var10
                i32.store offset=4
              end $label62
              local.get $var18
              i32.const 8
              i32.lt_u
              br_if $label72
              local.get $var12
              i32.load offset=4
              local.set $var10
              br $label75
            end $label72
            i32.const 0
            local.set $var20
            block $label76
              i32.const 0
              local.get $var12
              i32.load offset=4
              local.tee $var10
              local.get $var2
              i32.sub
              local.tee $var13
              local.get $var13
              local.get $var10
              i32.gt_u
              select
              local.tee $var14
              i32.const 2
              i32.lt_u
              br_if $label76
              local.get $var4
              i32.load8_u
              i32.const 34
              i32.ne
              br_if $label76
              local.get $var21
              local.get $var10
              i32.add
              i32.load8_u
              i32.const 34
              i32.eq
              local.set $var20
            end $label76
            block $label86
              block $label84
                block $label83
                  block $label82
                    block $label81
                      block $label80
                        block $label79
                          block $label78
                            block $label77
                              local.get $var18
                              br_table $label77 $label78 $label79 $label80 $label81 $label82 $label83 $label84 $label77
                            end $label77
                            block $label85
                              local.get $var20
                              br_if $label85
                              i32.const 0
                              local.set $var13
                              br $label1
                            end $label85
                            local.get $var3
                            local.get $var2
                            i32.store
                            i32.const 4
                            local.set $var13
                            br $label86
                          end $label78
                          block $label87
                            local.get $var20
                            br_if $label87
                            i32.const 0
                            local.set $var13
                            br $label1
                          end $label87
                          local.get $var3
                          local.get $var2
                          i32.store offset=8
                          i32.const 12
                          local.set $var13
                          br $label86
                        end $label79
                        block $label88
                          local.get $var20
                          br_if $label88
                          i32.const 0
                          local.set $var13
                          local.get $var14
                          i32.const 4
                          i32.ne
                          br_if $label1
                          local.get $var4
                          i32.load8_u
                          i32.const 110
                          i32.ne
                          br_if $label1
                          local.get $var4
                          i32.const 1
                          i32.add
                          i32.load8_u
                          i32.const 117
                          i32.ne
                          br_if $label1
                          local.get $var4
                          i32.const 2
                          i32.add
                          i32.load8_u
                          i32.const 108
                          i32.ne
                          br_if $label1
                          local.get $var4
                          i32.const 3
                          i32.add
                          i32.load8_u
                          i32.const 108
                          i32.ne
                          br_if $label1
                        end $label88
                        local.get $var3
                        local.get $var2
                        i32.store offset=16
                        i32.const 20
                        local.set $var13
                        br $label86
                      end $label80
                      block $label89
                        local.get $var20
                        br_if $label89
                        i32.const 0
                        local.set $var13
                        br $label1
                      end $label89
                      local.get $var3
                      local.get $var2
                      i32.store offset=24
                      i32.const 28
                      local.set $var13
                      br $label86
                    end $label81
                    block $label90
                      local.get $var0
                      local.get $var2
                      local.get $var10
                      call $func43
                      i32.eqz
                      br_if $label90
                      i32.const 32
                      local.set $var13
                      local.get $var2
                      local.set $var14
                      br $label86
                    end $label90
                    i32.const 0
                    local.set $var13
                    br $label1
                  end $label82
                  local.get $var3
                  local.get $var2
                  i32.store offset=36
                  i32.const 40
                  local.set $var13
                  br $label86
                end $label83
                block $label91
                  local.get $var14
                  i32.const 4
                  i32.ne
                  br_if $label91
                  local.get $var4
                  i32.load8_u
                  i32.const 110
                  i32.ne
                  br_if $label91
                  local.get $var4
                  i32.const 1
                  i32.add
                  i32.load8_u
                  i32.const 117
                  i32.ne
                  br_if $label91
                  local.get $var4
                  i32.const 2
                  i32.add
                  i32.load8_u
                  i32.const 108
                  i32.ne
                  br_if $label91
                  local.get $var4
                  i32.const 3
                  i32.add
                  i32.load8_u
                  i32.const 108
                  i32.ne
                  br_if $label91
                  i32.const -1
                  local.set $var14
                  i32.const 44
                  local.set $var13
                  br $label86
                end $label91
                block $label92
                  local.get $var0
                  local.get $var2
                  local.get $var10
                  call $func43
                  i32.eqz
                  br_if $label92
                  i32.const 44
                  local.set $var13
                  local.get $var2
                  local.set $var14
                  br $label86
                end $label92
                i32.const 0
                local.set $var13
                br $label1
              end $label84
              block $label93
                local.get $var20
                br_if $label93
                i32.const 0
                local.set $var13
                br $label1
              end $label93
              local.get $var24
              local.get $var2
              i32.store
              i32.const 52
              local.set $var13
            end $label86
            local.get $var3
            local.get $var13
            i32.add
            local.get $var14
            i32.store
          end $label75
          block $label94
            local.get $var10
            local.get $var1
            i32.ge_u
            br_if $label94
            loop $label95
              local.get $var0
              local.get $var10
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var2
              i32.const 23
              i32.gt_u
              br_if $label94
              i32.const 1
              local.get $var2
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label94
              local.get $var1
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              i32.ne
              br_if $label95
            end $label95
            i32.const 0
            local.set $var13
            br $label1
          end $label94
          i32.const 0
          local.set $var13
          local.get $var10
          local.get $var1
          i32.ge_u
          br_if $label1
          block $label96
            local.get $var0
            local.get $var10
            i32.add
            i32.load8_u
            local.tee $var2
            i32.const 44
            i32.eq
            br_if $label96
            local.get $var2
            i32.const 93
            i32.ne
            br_if $label1
            local.get $var5
            local.get $var10
            i32.const 1
            i32.add
            i32.store
            local.get $var3
            i32.load offset=4
            i32.const 0
            i32.ne
            local.set $var13
            br $label1
          end $label96
          block $label97
            local.get $var10
            i32.const 1
            i32.add
            local.tee $var2
            local.get $var1
            i32.ge_u
            br_if $label97
            loop $label98
              local.get $var0
              local.get $var2
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var10
              i32.const 23
              i32.gt_u
              br_if $label97
              i32.const 1
              local.get $var10
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label97
              local.get $var1
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var2
              i32.ne
              br_if $label98
              br $label1
            end $label98
          end $label97
          local.get $var2
          local.get $var1
          i32.ge_u
          br_if $label1
          local.get $var18
          i32.const 1
          i32.add
          local.set $var18
          i32.const 0
          local.set $var13
          local.get $var0
          local.get $var2
          i32.add
          i32.load8_u
          i32.const 93
          i32.ne
          br_if $label99
          br $label1
        end $label99
      end $label36
      local.get $var3
      local.get $var2
      i32.store offset=16
      local.get $var12
      local.get $var14
      i32.store offset=12
      local.get $var3
      local.get $var14
      local.get $var2
      i32.sub
      i32.store offset=20
      local.get $var0
      local.get $var1
      local.get $var12
      i32.const 12
      i32.add
      call $func44
      i32.eqz
      br_if $label1
      local.get $var12
      i32.load offset=12
      local.tee $var11
      local.get $var1
      i32.ge_u
      br_if $label1
      local.get $var0
      local.get $var11
      i32.add
      i32.load8_u
      i32.const 34
      i32.ne
      br_if $label1
      local.get $var11
      i32.const 1
      i32.add
      local.tee $var10
      local.get $var1
      i32.ge_u
      br_if $label1
      loop $label101
        block $label100
          local.get $var10
          local.tee $var2
          i32.const 8
          i32.add
          local.tee $var10
          local.get $var1
          i32.gt_u
          br_if $label100
          local.get $var0
          local.get $var2
          i32.add
          i64.load align=1
          local.tee $var19
          i64.const -1
          i64.xor
          local.get $var19
          i64.const 6655295901103053916
          i64.xor
          i64.const -72340172838076673
          i64.add
          local.get $var19
          i64.const -2314885530818453536
          i64.add
          i64.or
          local.get $var19
          i64.const 2459565876494606882
          i64.xor
          i64.const -72340172838076673
          i64.add
          i64.or
          i64.and
          i64.const -9187201950435737472
          i64.and
          local.tee $var19
          i64.eqz
          br_if $label101
          local.get $var19
          i64.ctz
          i32.wrap_i64
          i32.const 3
          i32.shr_u
          local.get $var2
          i32.add
          local.set $var2
        end $label100
        local.get $var2
        local.get $var1
        i32.ge_u
        br_if $label1
        block $label109
          block $label105
            block $label102
              local.get $var0
              local.get $var2
              i32.add
              i32.load8_u
              local.tee $var14
              i32.const 92
              i32.ne
              br_if $label102
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var10
              local.get $var1
              i32.ge_u
              br_if $label1
              block $label103
                block $label104
                  local.get $var0
                  local.get $var10
                  i32.add
                  i32.load8_u
                  i32.const -34
                  i32.add
                  br_table $label103 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label103 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label103 $label1 $label1 $label1 $label1 $label1 $label103 $label1 $label1 $label1 $label103 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label103 $label1 $label1 $label1 $label103 $label1 $label103 $label104 $label1
                end $label104
                local.get $var2
                i32.const 6
                i32.add
                local.tee $var10
                local.get $var1
                i32.gt_u
                br_if $label1
                local.get $var2
                i32.const 2
                i32.add
                local.tee $var14
                local.get $var10
                i32.ge_u
                br_if $label105
                block $label106
                  local.get $var0
                  local.get $var14
                  i32.add
                  i32.load8_u
                  local.tee $var14
                  i32.const -58
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 245
                  i32.gt_u
                  br_if $label106
                  local.get $var14
                  i32.const -33
                  i32.and
                  i32.const -71
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 250
                  i32.lt_u
                  br_if $label1
                end $label106
                block $label107
                  local.get $var17
                  local.get $var2
                  i32.add
                  i32.load8_u
                  local.tee $var14
                  i32.const -58
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 245
                  i32.gt_u
                  br_if $label107
                  local.get $var14
                  i32.const -33
                  i32.and
                  i32.const -71
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 250
                  i32.lt_u
                  br_if $label1
                end $label107
                block $label108
                  local.get $var16
                  local.get $var2
                  i32.add
                  i32.load8_u
                  local.tee $var14
                  i32.const -58
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 245
                  i32.gt_u
                  br_if $label108
                  local.get $var14
                  i32.const -33
                  i32.and
                  i32.const -71
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 250
                  i32.lt_u
                  br_if $label1
                end $label108
                local.get $var15
                local.get $var2
                i32.add
                i32.load8_u
                local.tee $var2
                i32.const -58
                i32.add
                i32.const 255
                i32.and
                i32.const 245
                i32.gt_u
                br_if $label105
                local.get $var2
                i32.const -33
                i32.and
                i32.const -71
                i32.add
                i32.const 255
                i32.and
                i32.const 250
                i32.ge_u
                br_if $label105
                br $label1
              end $label103
              local.get $var2
              i32.const 2
              i32.add
              local.set $var10
              br $label105
            end $label102
            local.get $var14
            i32.const 32
            i32.lt_u
            br_if $label1
            local.get $var2
            i32.const 1
            i32.add
            local.set $var10
            local.get $var14
            i32.const 34
            i32.eq
            br_if $label109
          end $label105
          local.get $var10
          local.get $var1
          i32.lt_u
          br_if $label101
          br $label1
        end $label109
      end $label101
      local.get $var3
      local.get $var11
      i32.store offset=24
      local.get $var3
      local.get $var10
      local.get $var11
      i32.sub
      i32.store offset=28
      local.get $var12
      local.get $var10
      i32.store offset=8
      local.get $var12
      local.get $var10
      i32.store offset=12
      local.get $var0
      local.get $var1
      local.get $var12
      i32.const 12
      i32.add
      call $func44
      i32.eqz
      br_if $label1
      local.get $var0
      local.get $var1
      local.get $var12
      i32.load offset=12
      local.tee $var2
      local.get $var12
      i32.const 8
      i32.add
      call $func37
      i32.eqz
      br_if $label1
      local.get $var0
      local.get $var2
      local.get $var12
      i32.load offset=8
      local.tee $var10
      call $func43
      i32.eqz
      br_if $label1
      local.get $var3
      local.get $var2
      i32.store offset=32
      local.get $var12
      local.get $var10
      i32.store offset=12
      local.get $var0
      local.get $var1
      local.get $var12
      i32.const 12
      i32.add
      call $func44
      i32.eqz
      br_if $label1
      local.get $var0
      local.get $var12
      i32.load offset=12
      local.tee $var2
      i32.add
      i32.load8_u
      i32.const 91
      i32.ne
      br_if $label1
      i32.const 0
      local.set $var13
      local.get $var3
      i32.const 0
      i32.store offset=64
      local.get $var3
      i64.const 0
      i64.store offset=56 align=4
      block $label111
        block $label110
          local.get $var8
          i32.eqz
          br_if $label110
          local.get $var0
          local.get $var1
          local.get $var2
          local.get $var6
          local.get $var7
          local.get $var3
          local.get $var12
          i32.const 8
          i32.add
          local.get $var8
          local.get $var9
          call $func42
          br_if $label111
        end $label110
        local.get $var0
        local.get $var1
        local.get $var2
        local.get $var12
        i32.const 8
        i32.add
        local.get $var3
        i32.const 56
        i32.add
        i32.const 0
        local.get $var4
        select
        local.get $var3
        i32.const 60
        i32.add
        local.get $var3
        i32.const 64
        i32.add
        i32.const 1
        call $func45
        i32.eqz
        br_if $label1
      end $label111
      local.get $var3
      local.get $var2
      i32.store offset=36
      local.get $var3
      local.get $var12
      i32.load offset=8
      local.tee $var10
      local.get $var2
      i32.sub
      i32.store offset=40
      local.get $var12
      local.get $var10
      i32.store offset=12
      i32.const 0
      local.set $var13
      local.get $var0
      local.get $var1
      local.get $var12
      i32.const 12
      i32.add
      call $func44
      i32.eqz
      br_if $label1
      local.get $var0
      local.get $var1
      local.get $var12
      i32.load offset=12
      local.tee $var2
      local.get $var12
      i32.const 8
      i32.add
      call $func37
      i32.eqz
      br_if $label1
      block $label113
        block $label112
          local.get $var12
          i32.load offset=8
          local.tee $var10
          local.get $var2
          i32.sub
          i32.const 4
          i32.ne
          br_if $label112
          local.get $var0
          local.get $var2
          i32.add
          local.tee $var4
          i32.load8_u
          i32.const 110
          i32.ne
          br_if $label112
          local.get $var4
          i32.const 1
          i32.add
          i32.load8_u
          i32.const 117
          i32.ne
          br_if $label112
          local.get $var4
          i32.const 2
          i32.add
          i32.load8_u
          i32.const 108
          i32.ne
          br_if $label112
          i32.const -1
          local.set $var14
          local.get $var4
          i32.const 3
          i32.add
          i32.load8_u
          i32.const 108
          i32.eq
          br_if $label113
        end $label112
        local.get $var2
        local.set $var14
        local.get $var0
        local.get $var2
        local.get $var10
        call $func43
        i32.eqz
        br_if $label1
      end $label113
      local.get $var3
      local.get $var14
      i32.store offset=44
      local.get $var12
      local.get $var10
      i32.store offset=12
      local.get $var0
      local.get $var1
      local.get $var12
      i32.const 12
      i32.add
      call $func44
      i32.eqz
      br_if $label1
      local.get $var12
      i32.load offset=12
      local.tee $var4
      local.get $var1
      i32.ge_u
      br_if $label1
      local.get $var0
      local.get $var4
      i32.add
      i32.load8_u
      i32.const 34
      i32.ne
      br_if $label1
      local.get $var4
      i32.const 1
      i32.add
      local.tee $var10
      local.get $var1
      i32.ge_u
      br_if $label1
      loop $label115
        block $label114
          local.get $var10
          local.tee $var2
          i32.const 8
          i32.add
          local.tee $var10
          local.get $var1
          i32.gt_u
          br_if $label114
          local.get $var0
          local.get $var2
          i32.add
          i64.load align=1
          local.tee $var19
          i64.const -1
          i64.xor
          local.get $var19
          i64.const 6655295901103053916
          i64.xor
          i64.const -72340172838076673
          i64.add
          local.get $var19
          i64.const -2314885530818453536
          i64.add
          i64.or
          local.get $var19
          i64.const 2459565876494606882
          i64.xor
          i64.const -72340172838076673
          i64.add
          i64.or
          i64.and
          i64.const -9187201950435737472
          i64.and
          local.tee $var19
          i64.eqz
          br_if $label115
          local.get $var19
          i64.ctz
          i32.wrap_i64
          i32.const 3
          i32.shr_u
          local.get $var2
          i32.add
          local.set $var2
        end $label114
        local.get $var2
        local.get $var1
        i32.ge_u
        br_if $label1
        block $label123
          block $label119
            block $label116
              local.get $var0
              local.get $var2
              i32.add
              i32.load8_u
              local.tee $var14
              i32.const 92
              i32.ne
              br_if $label116
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var10
              local.get $var1
              i32.ge_u
              br_if $label1
              block $label117
                block $label118
                  local.get $var0
                  local.get $var10
                  i32.add
                  i32.load8_u
                  i32.const -34
                  i32.add
                  br_table $label117 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label117 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label117 $label1 $label1 $label1 $label1 $label1 $label117 $label1 $label1 $label1 $label117 $label1 $label1 $label1 $label1 $label1 $label1 $label1 $label117 $label1 $label1 $label1 $label117 $label1 $label117 $label118 $label1
                end $label118
                local.get $var2
                i32.const 6
                i32.add
                local.tee $var10
                local.get $var1
                i32.gt_u
                br_if $label1
                local.get $var2
                i32.const 2
                i32.add
                local.tee $var14
                local.get $var10
                i32.ge_u
                br_if $label119
                block $label120
                  local.get $var0
                  local.get $var14
                  i32.add
                  i32.load8_u
                  local.tee $var14
                  i32.const -58
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 245
                  i32.gt_u
                  br_if $label120
                  local.get $var14
                  i32.const -33
                  i32.and
                  i32.const -71
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 250
                  i32.lt_u
                  br_if $label1
                end $label120
                block $label121
                  local.get $var17
                  local.get $var2
                  i32.add
                  i32.load8_u
                  local.tee $var14
                  i32.const -58
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 245
                  i32.gt_u
                  br_if $label121
                  local.get $var14
                  i32.const -33
                  i32.and
                  i32.const -71
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 250
                  i32.lt_u
                  br_if $label1
                end $label121
                block $label122
                  local.get $var16
                  local.get $var2
                  i32.add
                  i32.load8_u
                  local.tee $var14
                  i32.const -58
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 245
                  i32.gt_u
                  br_if $label122
                  local.get $var14
                  i32.const -33
                  i32.and
                  i32.const -71
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 250
                  i32.lt_u
                  br_if $label1
                end $label122
                local.get $var15
                local.get $var2
                i32.add
                i32.load8_u
                local.tee $var2
                i32.const -58
                i32.add
                i32.const 255
                i32.and
                i32.const 245
                i32.gt_u
                br_if $label119
                local.get $var2
                i32.const -33
                i32.and
                i32.const -71
                i32.add
                i32.const 255
                i32.and
                i32.const 250
                i32.ge_u
                br_if $label119
                br $label1
              end $label117
              local.get $var2
              i32.const 2
              i32.add
              local.set $var10
              br $label119
            end $label116
            local.get $var14
            i32.const 32
            i32.lt_u
            br_if $label1
            local.get $var2
            i32.const 1
            i32.add
            local.set $var10
            local.get $var14
            i32.const 34
            i32.eq
            br_if $label123
          end $label119
          local.get $var10
          local.get $var1
          i32.lt_u
          br_if $label115
          br $label1
        end $label123
      end $label115
      local.get $var3
      local.get $var4
      i32.store offset=48
      local.get $var3
      local.get $var10
      local.get $var4
      i32.sub
      i32.store offset=52
      block $label124
        local.get $var10
        local.get $var1
        i32.ge_u
        br_if $label124
        loop $label125
          local.get $var0
          local.get $var10
          i32.add
          i32.load8_u
          i32.const -9
          i32.add
          local.tee $var2
          i32.const 23
          i32.gt_u
          br_if $label124
          i32.const 1
          local.get $var2
          i32.shl
          i32.const 8388627
          i32.and
          i32.eqz
          br_if $label124
          local.get $var1
          local.get $var10
          i32.const 1
          i32.add
          local.tee $var10
          i32.ne
          br_if $label125
          br $label1
        end $label125
      end $label124
      local.get $var10
      local.get $var1
      i32.ge_u
      br_if $label1
      local.get $var0
      local.get $var10
      i32.add
      i32.load8_u
      i32.const 93
      i32.ne
      br_if $label1
      i32.const 1
      local.set $var13
      local.get $var5
      local.get $var10
      i32.const 1
      i32.add
      i32.store
    end $label1
    local.get $var12
    i32.const 16
    i32.add
    global.set $global0
    local.get $var13
  )
  (func $func19 (param $var0 i32) (param $var1 i32) (result i32)
    (local $var2 i32)
    (local $var3 i32)
    (local $var4 i32)
    (local $var5 i32)
    local.get $var0
    i32.load
    local.set $var2
    block $label0
      local.get $var1
      local.get $var0
      i32.load offset=20
      local.tee $var3
      i32.ge_u
      br_if $label0
      loop $label1
        local.get $var2
        local.get $var1
        i32.add
        i32.load8_u
        i32.const -9
        i32.add
        local.tee $var4
        i32.const 23
        i32.gt_u
        br_if $label0
        i32.const 1
        local.get $var4
        i32.shl
        i32.const 8388627
        i32.and
        i32.eqz
        br_if $label0
        local.get $var3
        local.get $var1
        i32.const 1
        i32.add
        local.tee $var1
        i32.ne
        br_if $label1
      end $label1
      i32.const -1
      return
    end $label0
    i32.const -1
    local.set $var5
    block $label2
      local.get $var1
      local.get $var3
      i32.ge_u
      br_if $label2
      block $label3
        local.get $var2
        local.get $var1
        i32.add
        i32.load8_u
        local.tee $var4
        i32.const 44
        i32.eq
        br_if $label3
        local.get $var4
        i32.const 93
        i32.ne
        br_if $label2
        block $label6
          block $label4
            local.get $var1
            i32.const 1
            i32.add
            local.tee $var1
            local.get $var3
            i32.ge_u
            br_if $label4
            loop $label5
              local.get $var2
              local.get $var1
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var4
              i32.const 23
              i32.gt_u
              br_if $label4
              i32.const 1
              local.get $var4
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label4
              local.get $var3
              local.get $var1
              i32.const 1
              i32.add
              local.tee $var1
              i32.ne
              br_if $label5
              br $label6
            end $label5
          end $label4
          local.get $var1
          local.get $var3
          i32.ne
          br_if $label2
        end $label6
        local.get $var0
        call $func17
        return
      end $label3
      block $label7
        local.get $var1
        i32.const 1
        i32.add
        local.tee $var1
        local.get $var3
        i32.ge_u
        br_if $label7
        loop $label8
          local.get $var2
          local.get $var1
          i32.add
          i32.load8_u
          i32.const -9
          i32.add
          local.tee $var4
          i32.const 23
          i32.gt_u
          br_if $label7
          i32.const 1
          local.get $var4
          i32.shl
          i32.const 8388627
          i32.and
          i32.eqz
          br_if $label7
          local.get $var3
          local.get $var1
          i32.const 1
          i32.add
          local.tee $var1
          i32.ne
          br_if $label8
          br $label2
        end $label8
      end $label7
      local.get $var1
      local.get $var3
      i32.ge_u
      br_if $label2
      local.get $var2
      local.get $var1
      i32.add
      i32.load8_u
      i32.const 93
      i32.eq
      br_if $label2
      local.get $var0
      local.get $var1
      i32.store offset=24
      i32.const 1
      local.set $var5
    end $label2
    local.get $var5
  )
  (func $parse_term_bank_with_media_hints (;20;) (export "parse_term_bank_with_media_hints") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (result i32)
    local.get $var0
    local.get $var1
    local.get $var2
    local.get $var3
    i32.const 1
    local.get $var4
    local.get $var5
    local.get $var6
    i32.const 0
    i32.ne
    call $func16
  )
  (func $encode_term_content (;21;) (export "encode_term_content") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (result i32)
    local.get $var0
    local.get $var1
    local.get $var2
    local.get $var3
    local.get $var4
    local.get $var5
    i32.const 1
    call $func22
  )
  (func $func22 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (result i32)
    (local $var7 i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 i32)
    (local $var23 i32)
    global.get $global0
    i32.const 16
    i32.sub
    local.tee $var7
    global.set $global0
    i32.const -1
    local.set $var8
    block $label0
      local.get $var0
      i32.eqz
      br_if $label0
      local.get $var1
      i32.eqz
      br_if $label0
      local.get $var3
      i32.eqz
      br_if $label0
      local.get $var5
      i32.eqz
      br_if $label0
      i32.const 0
      local.set $var8
      i32.const 0
      local.get $var4
      i32.store offset=2552
      local.get $var2
      i32.eqz
      br_if $label0
      i32.const 0
      local.set $var8
      i32.const 0
      local.set $var9
      loop $label19
        local.get $var8
        local.tee $var10
        i32.const 11
        i32.add
        local.set $var11
        local.get $var3
        local.get $var10
        i32.const 9
        i32.add
        local.tee $var12
        i32.add
        local.set $var13
        local.get $var1
        local.get $var9
        i32.const 68
        i32.mul
        i32.add
        local.set $var14
        local.get $var10
        i32.const -10
        i32.gt_u
        local.set $var15
        local.get $var3
        local.get $var10
        i32.add
        local.tee $var16
        i32.const 8
        i32.add
        local.set $var17
        local.get $var12
        i32.const -3
        i32.gt_u
        local.set $var18
        block $label15
          block $label14
            loop $label18
              local.get $var7
              i32.const 0
              i32.store offset=12
              local.get $var7
              i32.const 0
              i32.store offset=8
              block $label1
                local.get $var15
                br_if $label1
                local.get $var12
                local.get $var4
                i32.gt_u
                br_if $label1
                local.get $var17
                i32.const 0
                i32.load8_u offset=1106
                i32.store8
                local.get $var16
                i32.const 0
                i64.load offset=1098 align=1
                i64.store align=1
                block $label4
                  block $label2
                    local.get $var14
                    i32.load offset=28
                    local.tee $var19
                    i32.eqz
                    br_if $label2
                    local.get $var14
                    i32.load offset=24
                    local.set $var20
                    block $label3
                      local.get $var19
                      i32.const 4
                      i32.ne
                      br_if $label3
                      local.get $var0
                      local.get $var20
                      i32.add
                      local.tee $var21
                      i32.load8_u
                      i32.const 110
                      i32.ne
                      br_if $label3
                      local.get $var21
                      i32.const 1
                      i32.add
                      i32.load8_u
                      i32.const 117
                      i32.ne
                      br_if $label3
                      local.get $var21
                      i32.const 2
                      i32.add
                      i32.load8_u
                      i32.const 108
                      i32.ne
                      br_if $label3
                      local.get $var21
                      i32.const 3
                      i32.add
                      i32.load8_u
                      i32.const 108
                      i32.eq
                      br_if $label2
                    end $label3
                    local.get $var19
                    local.get $var12
                    i32.add
                    local.tee $var21
                    local.get $var19
                    i32.lt_u
                    br_if $label1
                    local.get $var21
                    local.get $var4
                    i32.gt_u
                    br_if $label1
                    local.get $var19
                    i32.eqz
                    br_if $label4
                    local.get $var13
                    local.get $var0
                    local.get $var20
                    i32.add
                    local.get $var19
                    memory.copy
                    br $label4
                  end $label2
                  local.get $var18
                  br_if $label1
                  local.get $var11
                  local.get $var4
                  i32.gt_u
                  br_if $label1
                  local.get $var13
                  i32.const 8738
                  i32.store16 align=1
                  local.get $var11
                  local.set $var21
                end $label4
                local.get $var21
                i32.const -19
                i32.gt_u
                br_if $label1
                local.get $var21
                i32.const 18
                i32.add
                local.tee $var20
                local.get $var4
                i32.gt_u
                br_if $label1
                local.get $var3
                local.get $var21
                i32.add
                local.tee $var19
                i32.const 0
                v128.load offset=1120
                v128.store align=1
                local.get $var19
                i32.const 16
                i32.add
                i32.const 0
                i32.load16_u offset=1136
                i32.store16 align=1
                block $label7
                  block $label5
                    local.get $var14
                    i32.load offset=20
                    local.tee $var19
                    i32.eqz
                    br_if $label5
                    local.get $var14
                    i32.load offset=16
                    local.set $var8
                    block $label6
                      local.get $var19
                      i32.const 4
                      i32.ne
                      br_if $label6
                      local.get $var0
                      local.get $var8
                      i32.add
                      local.tee $var22
                      i32.load8_u
                      i32.const 110
                      i32.ne
                      br_if $label6
                      local.get $var22
                      i32.const 1
                      i32.add
                      i32.load8_u
                      i32.const 117
                      i32.ne
                      br_if $label6
                      local.get $var22
                      i32.const 2
                      i32.add
                      i32.load8_u
                      i32.const 108
                      i32.ne
                      br_if $label6
                      local.get $var22
                      i32.const 3
                      i32.add
                      i32.load8_u
                      i32.const 108
                      i32.eq
                      br_if $label5
                    end $label6
                    local.get $var19
                    local.get $var20
                    i32.add
                    local.tee $var21
                    local.get $var19
                    i32.lt_u
                    br_if $label1
                    local.get $var21
                    local.get $var4
                    i32.gt_u
                    br_if $label1
                    local.get $var19
                    i32.eqz
                    br_if $label7
                    local.get $var3
                    local.get $var20
                    i32.add
                    local.get $var0
                    local.get $var8
                    i32.add
                    local.get $var19
                    memory.copy
                    br $label7
                  end $label5
                  local.get $var20
                  i32.const -3
                  i32.gt_u
                  br_if $label1
                  local.get $var21
                  i32.const 20
                  i32.add
                  local.tee $var21
                  local.get $var4
                  i32.gt_u
                  br_if $label1
                  local.get $var3
                  local.get $var20
                  i32.add
                  i32.const 8738
                  i32.store16 align=1
                end $label7
                local.get $var21
                i32.const -13
                i32.gt_u
                br_if $label1
                local.get $var21
                i32.const 12
                i32.add
                local.tee $var20
                local.get $var4
                i32.gt_u
                br_if $label1
                local.get $var3
                local.get $var21
                i32.add
                local.tee $var19
                i32.const 0
                i64.load offset=1085 align=1
                i64.store align=1
                local.get $var19
                i32.const 8
                i32.add
                i32.const 0
                i32.load offset=1093 align=1
                i32.store align=1
                block $label10
                  block $label8
                    local.get $var14
                    i32.load offset=52
                    local.tee $var19
                    i32.eqz
                    br_if $label8
                    local.get $var14
                    i32.load offset=48
                    local.set $var8
                    block $label9
                      local.get $var19
                      i32.const 4
                      i32.ne
                      br_if $label9
                      local.get $var0
                      local.get $var8
                      i32.add
                      local.tee $var22
                      i32.load8_u
                      i32.const 110
                      i32.ne
                      br_if $label9
                      local.get $var22
                      i32.const 1
                      i32.add
                      i32.load8_u
                      i32.const 117
                      i32.ne
                      br_if $label9
                      local.get $var22
                      i32.const 2
                      i32.add
                      i32.load8_u
                      i32.const 108
                      i32.ne
                      br_if $label9
                      local.get $var22
                      i32.const 3
                      i32.add
                      i32.load8_u
                      i32.const 108
                      i32.eq
                      br_if $label8
                    end $label9
                    local.get $var19
                    local.get $var20
                    i32.add
                    local.tee $var21
                    local.get $var19
                    i32.lt_u
                    br_if $label1
                    local.get $var21
                    local.get $var4
                    i32.gt_u
                    br_if $label1
                    local.get $var19
                    i32.eqz
                    br_if $label10
                    local.get $var3
                    local.get $var20
                    i32.add
                    local.get $var0
                    local.get $var8
                    i32.add
                    local.get $var19
                    memory.copy
                    br $label10
                  end $label8
                  local.get $var20
                  i32.const -3
                  i32.gt_u
                  br_if $label1
                  local.get $var21
                  i32.const 14
                  i32.add
                  local.tee $var21
                  local.get $var4
                  i32.gt_u
                  br_if $label1
                  local.get $var3
                  local.get $var20
                  i32.add
                  i32.const 8738
                  i32.store16 align=1
                end $label10
                local.get $var21
                i32.const -13
                i32.gt_u
                br_if $label1
                local.get $var21
                i32.const 12
                i32.add
                local.tee $var19
                local.get $var4
                i32.gt_u
                br_if $label1
                local.get $var3
                local.get $var21
                i32.add
                local.tee $var20
                i32.const 0
                i64.load offset=1072 align=1
                i64.store align=1
                local.get $var20
                i32.const 8
                i32.add
                i32.const 0
                i32.load offset=1080 align=1
                i32.store align=1
                local.get $var7
                local.get $var19
                i32.store offset=4
                block $label13
                  block $label11
                    local.get $var14
                    i32.load offset=40
                    local.tee $var20
                    i32.eqz
                    br_if $label11
                    block $label12
                      local.get $var14
                      i32.load offset=60
                      br_if $label12
                      local.get $var20
                      local.get $var19
                      i32.add
                      local.tee $var21
                      local.get $var20
                      i32.lt_u
                      br_if $label1
                      local.get $var21
                      local.get $var4
                      i32.gt_u
                      br_if $label1
                      local.get $var20
                      i32.eqz
                      br_if $label13
                      local.get $var3
                      local.get $var19
                      i32.add
                      local.get $var0
                      local.get $var14
                      i32.load offset=36
                      i32.add
                      local.get $var20
                      memory.copy
                      br $label13
                    end $label12
                    local.get $var0
                    local.get $var14
                    i32.load offset=36
                    local.tee $var19
                    local.get $var20
                    i32.add
                    local.tee $var21
                    local.get $var19
                    local.get $var21
                    local.get $var3
                    local.get $var4
                    local.get $var7
                    i32.const 4
                    i32.add
                    call $func23
                    i32.eqz
                    br_if $label1
                    local.get $var7
                    i32.load offset=4
                    local.set $var21
                    br $label13
                  end $label11
                  local.get $var19
                  i32.const -3
                  i32.gt_u
                  br_if $label1
                  local.get $var21
                  i32.const 14
                  i32.add
                  local.tee $var21
                  local.get $var4
                  i32.gt_u
                  br_if $label1
                  local.get $var3
                  local.get $var19
                  i32.add
                  i32.const 23899
                  i32.store16 align=1
                end $label13
                local.get $var21
                local.get $var4
                i32.ge_u
                br_if $label1
                local.get $var3
                local.get $var21
                i32.add
                i32.const 125
                i32.store8
                local.get $var7
                local.get $var21
                i32.const 1
                i32.add
                local.tee $var8
                i32.store offset=4
                local.get $var8
                local.get $var10
                i32.sub
                local.set $var21
                local.get $var6
                br_if $label14
                i32.const 0
                local.set $var20
                i32.const 0
                local.set $var12
                br $label15
              end $label1
              local.get $var7
              local.get $var10
              i32.store offset=4
              i32.const -2
              local.set $var8
              local.get $var4
              i32.const 2147483646
              i32.gt_u
              br_if $label0
              local.get $var3
              local.get $var4
              i32.const 7
              i32.add
              i32.const -8
              i32.and
              local.tee $var21
              i32.const -1
              i32.xor
              i32.gt_u
              br_if $label0
              i32.const 0
              i32.load offset=2544
              local.get $var21
              local.get $var3
              i32.add
              local.tee $var19
              i32.ne
              br_if $label0
              i32.const 2147483647
              local.get $var4
              i32.const 1
              i32.shr_u
              local.tee $var20
              i32.const 1048576
              local.get $var20
              i32.const 1048576
              i32.gt_u
              select
              local.tee $var20
              local.get $var4
              i32.add
              local.get $var4
              local.get $var20
              i32.const 2147483647
              i32.xor
              i32.gt_u
              select
              local.tee $var4
              local.get $var21
              i32.sub
              i32.const 7
              i32.add
              local.set $var20
              local.get $var19
              local.set $var21
              block $label16
                local.get $var19
                br_if $label16
                i32.const 104256
                local.set $var21
                i32.const 0
                i32.const 104256
                i32.store offset=2544
              end $label16
              local.get $var21
              i32.const 7
              i32.add
              i32.const -8
              i32.and
              local.tee $var21
              local.get $var20
              i32.const -8
              i32.and
              local.tee $var20
              i32.const -1
              i32.xor
              i32.gt_u
              br_if $label0
              block $label17
                local.get $var21
                local.get $var20
                i32.add
                local.tee $var20
                i32.const 16
                i32.shr_u
                local.get $var20
                i32.const 65528
                i32.and
                i32.const 0
                i32.ne
                i32.add
                local.tee $var22
                memory.size
                local.tee $var23
                i32.le_u
                br_if $label17
                local.get $var22
                local.get $var23
                i32.sub
                memory.grow
                i32.const 0
                i32.lt_s
                br_if $label0
              end $label17
              i32.const 0
              local.get $var20
              i32.store offset=2544
              local.get $var21
              i32.eqz
              br_if $label0
              local.get $var21
              local.get $var19
              i32.ne
              br_if $label0
              i32.const 0
              local.get $var4
              i32.store offset=2552
              br $label18
            end $label18
          end $label14
          local.get $var16
          local.get $var21
          local.get $var7
          i32.const 12
          i32.add
          local.get $var7
          i32.const 8
          i32.add
          call $func24
          local.get $var7
          i32.load offset=12
          local.tee $var19
          i32.const 1
          local.get $var19
          local.get $var7
          i32.load offset=8
          local.tee $var12
          i32.or
          select
          local.set $var20
        end $label15
        local.get $var5
        local.get $var9
        i32.const 4
        i32.shl
        i32.add
        local.tee $var19
        local.get $var12
        i32.store offset=12
        local.get $var19
        local.get $var20
        i32.store offset=8
        local.get $var19
        local.get $var21
        i32.store offset=4
        local.get $var19
        local.get $var10
        i32.store
        local.get $var9
        i32.const 1
        i32.add
        local.tee $var9
        local.get $var2
        i32.ne
        br_if $label19
      end $label19
    end $label0
    local.get $var7
    i32.const 16
    i32.add
    global.set $global0
    local.get $var8
  )
  (func $func23 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (result i32)
    (local $var7 i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 i64)
    (local $var23 i32)
    (local $var24 i32)
    (local $var25 i32)
    (local $var26 i32)
    (local $var27 i32)
    global.get $global0
    i32.const 16
    i32.sub
    local.tee $var7
    global.set $global0
    i32.const 0
    local.set $var8
    block $label0
      local.get $var3
      local.get $var2
      i32.le_u
      br_if $label0
      block $label17
        block $label2
          block $label1
            local.get $var0
            local.get $var2
            i32.add
            local.tee $var9
            i32.load8_u
            local.tee $var10
            i32.const 123
            i32.eq
            br_if $label1
            local.get $var10
            i32.const 91
            i32.ne
            br_if $label2
            local.get $var6
            i32.load
            local.tee $var10
            local.get $var5
            i32.ge_u
            br_if $label0
            local.get $var4
            local.get $var10
            i32.add
            i32.const 91
            i32.store8
            local.get $var6
            local.get $var6
            i32.load
            i32.const 1
            i32.add
            local.tee $var11
            i32.store
            block $label3
              local.get $var2
              i32.const 1
              i32.add
              local.tee $var10
              local.get $var3
              i32.ge_u
              br_if $label3
              i32.const 0
              local.set $var11
              loop $label12
                block $label4
                  local.get $var10
                  local.get $var1
                  i32.ge_u
                  br_if $label4
                  loop $label5
                    local.get $var0
                    local.get $var10
                    i32.add
                    i32.load8_u
                    i32.const -9
                    i32.add
                    local.tee $var2
                    i32.const 23
                    i32.gt_u
                    br_if $label4
                    i32.const 1
                    local.get $var2
                    i32.shl
                    i32.const 8388627
                    i32.and
                    i32.eqz
                    br_if $label4
                    local.get $var1
                    local.get $var10
                    i32.const 1
                    i32.add
                    local.tee $var10
                    i32.ne
                    br_if $label5
                  end $label5
                  local.get $var1
                  local.set $var10
                end $label4
                i32.const 0
                local.set $var8
                local.get $var10
                local.get $var3
                i32.ge_u
                br_if $label0
                block $label6
                  local.get $var0
                  local.get $var10
                  i32.add
                  i32.load8_u
                  i32.const 93
                  i32.eq
                  br_if $label6
                  local.get $var7
                  i32.const 0
                  i32.store offset=8
                  local.get $var0
                  local.get $var1
                  local.get $var10
                  local.get $var7
                  i32.const 8
                  i32.add
                  call $func12
                  i32.eqz
                  br_if $label0
                  block $label7
                    local.get $var11
                    i32.const 1
                    i32.and
                    i32.eqz
                    br_if $label7
                    local.get $var6
                    i32.load
                    local.tee $var2
                    local.get $var5
                    i32.ge_u
                    br_if $label0
                    local.get $var4
                    local.get $var2
                    i32.add
                    i32.const 44
                    i32.store8
                    local.get $var6
                    local.get $var6
                    i32.load
                    i32.const 1
                    i32.add
                    i32.store
                  end $label7
                  local.get $var0
                  local.get $var1
                  local.get $var10
                  local.get $var7
                  i32.load offset=8
                  local.tee $var2
                  local.get $var4
                  local.get $var5
                  local.get $var6
                  call $func23
                  i32.eqz
                  br_if $label0
                  block $label8
                    local.get $var2
                    local.get $var1
                    i32.ge_u
                    br_if $label8
                    loop $label9
                      local.get $var0
                      local.get $var2
                      i32.add
                      i32.load8_u
                      i32.const -9
                      i32.add
                      local.tee $var10
                      i32.const 23
                      i32.gt_u
                      br_if $label8
                      i32.const 1
                      local.get $var10
                      i32.shl
                      i32.const 8388627
                      i32.and
                      i32.eqz
                      br_if $label8
                      local.get $var1
                      local.get $var2
                      i32.const 1
                      i32.add
                      local.tee $var2
                      i32.ne
                      br_if $label9
                    end $label9
                    local.get $var1
                    local.set $var2
                  end $label8
                  block $label11
                    block $label10
                      local.get $var2
                      local.get $var3
                      i32.lt_u
                      br_if $label10
                      local.get $var2
                      local.set $var10
                      br $label11
                    end $label10
                    local.get $var2
                    local.get $var0
                    local.get $var2
                    i32.add
                    i32.load8_u
                    i32.const 44
                    i32.eq
                    i32.add
                    local.set $var10
                  end $label11
                  i32.const 1
                  local.set $var11
                  local.get $var10
                  local.get $var3
                  i32.lt_u
                  br_if $label12
                end $label6
              end $label12
              local.get $var6
              i32.load
              local.set $var11
            end $label3
            i32.const 0
            local.set $var8
            local.get $var11
            local.get $var5
            i32.ge_u
            br_if $label0
            local.get $var4
            local.get $var11
            i32.add
            i32.const 93
            i32.store8
            i32.const 1
            local.set $var8
            local.get $var6
            local.get $var6
            i32.load
            i32.const 1
            i32.add
            i32.store
            br $label0
          end $label1
          local.get $var3
          local.get $var1
          i32.gt_u
          br_if $label2
          block $label13
            local.get $var2
            i32.const 1
            i32.add
            local.tee $var10
            local.get $var3
            i32.ge_u
            br_if $label13
            loop $label14
              local.get $var0
              local.get $var10
              i32.add
              i32.load8_u
              i32.const -9
              i32.add
              local.tee $var1
              i32.const 23
              i32.gt_u
              br_if $label13
              i32.const 1
              local.get $var1
              i32.shl
              i32.const 8388627
              i32.and
              i32.eqz
              br_if $label13
              local.get $var3
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              i32.ne
              br_if $label14
              br $label2
            end $label14
          end $label13
          local.get $var10
          local.get $var3
          i32.ge_u
          br_if $label2
          local.get $var0
          i32.const 1
          i32.add
          local.set $var12
          local.get $var0
          i32.const 2
          i32.add
          local.set $var13
          local.get $var0
          i32.const 5
          i32.add
          local.set $var14
          local.get $var0
          i32.const 4
          i32.add
          local.set $var15
          local.get $var0
          i32.const 3
          i32.add
          local.set $var16
          i32.const 0
          local.set $var17
          i32.const 0
          local.set $var18
          i32.const 0
          local.set $var19
          i32.const 0
          local.set $var20
          loop $label49
            block $label15
              local.get $var0
              local.get $var10
              i32.add
              i32.load8_u
              local.tee $var1
              i32.const 34
              i32.eq
              br_if $label15
              local.get $var1
              i32.const 125
              i32.ne
              br_if $label2
              local.get $var20
              i32.eqz
              br_if $label2
              local.get $var19
              i32.eqz
              br_if $label2
              i32.const 0
              local.set $var8
              local.get $var6
              i32.load
              local.tee $var10
              local.get $var17
              i32.add
              local.tee $var2
              local.get $var10
              i32.lt_u
              br_if $label0
              local.get $var2
              local.get $var5
              i32.gt_u
              br_if $label0
              block $label16
                local.get $var17
                i32.eqz
                br_if $label16
                local.get $var4
                local.get $var10
                i32.add
                local.get $var0
                local.get $var18
                i32.add
                local.get $var17
                memory.copy
              end $label16
              local.get $var6
              local.get $var2
              i32.store
              br $label17
            end $label15
            local.get $var10
            i32.const 1
            i32.add
            local.tee $var21
            local.get $var3
            i32.ge_u
            br_if $label2
            local.get $var21
            local.set $var11
            loop $label19
              block $label18
                local.get $var11
                local.tee $var1
                i32.const 8
                i32.add
                local.tee $var11
                local.get $var3
                i32.gt_u
                br_if $label18
                local.get $var0
                local.get $var1
                i32.add
                i64.load align=1
                local.tee $var22
                i64.const -1
                i64.xor
                local.get $var22
                i64.const 6655295901103053916
                i64.xor
                i64.const -72340172838076673
                i64.add
                local.get $var22
                i64.const -2314885530818453536
                i64.add
                i64.or
                local.get $var22
                i64.const 2459565876494606882
                i64.xor
                i64.const -72340172838076673
                i64.add
                i64.or
                i64.and
                i64.const -9187201950435737472
                i64.and
                local.tee $var22
                i64.eqz
                br_if $label19
                local.get $var22
                i64.ctz
                i32.wrap_i64
                i32.const 3
                i32.shr_u
                local.get $var1
                i32.add
                local.set $var1
              end $label18
              local.get $var1
              local.get $var3
              i32.ge_u
              br_if $label2
              block $label27
                block $label23
                  block $label20
                    local.get $var0
                    local.get $var1
                    i32.add
                    i32.load8_u
                    local.tee $var23
                    i32.const 92
                    i32.ne
                    br_if $label20
                    local.get $var1
                    i32.const 1
                    i32.add
                    local.tee $var11
                    local.get $var3
                    i32.ge_u
                    br_if $label2
                    block $label21
                      block $label22
                        local.get $var0
                        local.get $var11
                        i32.add
                        i32.load8_u
                        i32.const -34
                        i32.add
                        br_table $label21 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label21 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label21 $label2 $label2 $label2 $label2 $label2 $label21 $label2 $label2 $label2 $label21 $label2 $label2 $label2 $label2 $label2 $label2 $label2 $label21 $label2 $label2 $label2 $label21 $label2 $label21 $label22 $label2
                      end $label22
                      local.get $var1
                      i32.const 6
                      i32.add
                      local.tee $var11
                      local.get $var3
                      i32.gt_u
                      br_if $label2
                      local.get $var1
                      i32.const 2
                      i32.add
                      local.tee $var23
                      local.get $var11
                      i32.ge_u
                      br_if $label23
                      block $label24
                        local.get $var0
                        local.get $var23
                        i32.add
                        i32.load8_u
                        local.tee $var23
                        i32.const -58
                        i32.add
                        i32.const 255
                        i32.and
                        i32.const 245
                        i32.gt_u
                        br_if $label24
                        local.get $var23
                        i32.const -33
                        i32.and
                        i32.const -71
                        i32.add
                        i32.const 255
                        i32.and
                        i32.const 250
                        i32.lt_u
                        br_if $label2
                      end $label24
                      block $label25
                        local.get $var16
                        local.get $var1
                        i32.add
                        i32.load8_u
                        local.tee $var23
                        i32.const -58
                        i32.add
                        i32.const 255
                        i32.and
                        i32.const 245
                        i32.gt_u
                        br_if $label25
                        local.get $var23
                        i32.const -33
                        i32.and
                        i32.const -71
                        i32.add
                        i32.const 255
                        i32.and
                        i32.const 250
                        i32.lt_u
                        br_if $label2
                      end $label25
                      block $label26
                        local.get $var15
                        local.get $var1
                        i32.add
                        i32.load8_u
                        local.tee $var23
                        i32.const -58
                        i32.add
                        i32.const 255
                        i32.and
                        i32.const 245
                        i32.gt_u
                        br_if $label26
                        local.get $var23
                        i32.const -33
                        i32.and
                        i32.const -71
                        i32.add
                        i32.const 255
                        i32.and
                        i32.const 250
                        i32.lt_u
                        br_if $label2
                      end $label26
                      local.get $var14
                      local.get $var1
                      i32.add
                      i32.load8_u
                      local.tee $var1
                      i32.const -58
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 245
                      i32.gt_u
                      br_if $label23
                      local.get $var1
                      i32.const -33
                      i32.and
                      i32.const -71
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 250
                      i32.ge_u
                      br_if $label23
                      br $label2
                    end $label21
                    local.get $var1
                    i32.const 2
                    i32.add
                    local.set $var11
                    br $label23
                  end $label20
                  local.get $var23
                  i32.const 32
                  i32.lt_u
                  br_if $label2
                  local.get $var1
                  i32.const 1
                  i32.add
                  local.set $var11
                  local.get $var23
                  i32.const 34
                  i32.eq
                  br_if $label27
                end $label23
                local.get $var11
                local.get $var3
                i32.lt_u
                br_if $label19
                br $label2
              end $label27
            end $label19
            i32.const 0
            local.set $var23
            i32.const 0
            local.set $var24
            block $label28
              local.get $var1
              local.get $var10
              i32.lt_u
              br_if $label28
              local.get $var10
              i32.const 5
              i32.add
              local.set $var25
              i32.const 0
              local.set $var24
              i32.const 0
              local.set $var23
              block $label29
                local.get $var1
                local.get $var10
                i32.eq
                br_if $label29
                block $label30
                  local.get $var0
                  local.get $var21
                  i32.add
                  i32.load8_u
                  local.tee $var26
                  i32.const 92
                  i32.eq
                  br_if $label30
                  i32.const 0
                  local.set $var23
                  local.get $var1
                  local.get $var10
                  i32.sub
                  local.tee $var27
                  i32.const 1
                  i32.eq
                  br_if $label29
                  i32.const 0
                  local.set $var23
                  local.get $var26
                  i32.const 116
                  i32.ne
                  br_if $label29
                  local.get $var13
                  local.get $var10
                  i32.add
                  i32.load8_u
                  local.tee $var26
                  i32.const 92
                  i32.eq
                  br_if $label30
                  i32.const 0
                  local.set $var23
                  local.get $var26
                  i32.const 121
                  i32.ne
                  br_if $label29
                  i32.const 0
                  local.set $var23
                  local.get $var27
                  i32.const 2
                  i32.eq
                  br_if $label29
                  local.get $var16
                  local.get $var10
                  i32.add
                  i32.load8_u
                  local.tee $var26
                  i32.const 92
                  i32.eq
                  br_if $label30
                  i32.const 0
                  local.set $var23
                  local.get $var26
                  i32.const 112
                  i32.ne
                  br_if $label29
                  i32.const 0
                  local.set $var23
                  local.get $var27
                  i32.const 3
                  i32.eq
                  br_if $label29
                  i32.const 0
                  local.set $var23
                  block $label31
                    local.get $var15
                    local.get $var10
                    i32.add
                    i32.load8_u
                    i32.const -92
                    i32.add
                    br_table $label30 $label29 $label29 $label29 $label29 $label29 $label29 $label29 $label29 $label31 $label29
                  end $label31
                  i32.const 0
                  local.set $var23
                  local.get $var25
                  local.get $var1
                  i32.gt_u
                  br_if $label29
                  local.get $var0
                  local.get $var25
                  i32.add
                  i32.load8_u
                  i32.const 34
                  i32.eq
                  local.set $var23
                  br $label29
                end $label30
                local.get $var0
                local.get $var10
                local.get $var11
                i32.const 1061
                i32.const 4
                call $func14
                local.set $var23
              end $label29
              local.get $var1
              local.get $var10
              i32.le_u
              br_if $label28
              block $label33
                block $label32
                  local.get $var0
                  local.get $var21
                  i32.add
                  i32.load8_u
                  local.tee $var21
                  i32.const 116
                  i32.ne
                  br_if $label32
                  local.get $var10
                  i32.const 2
                  i32.add
                  local.tee $var21
                  local.get $var1
                  i32.gt_u
                  br_if $label28
                  block $label34
                    local.get $var0
                    local.get $var21
                    i32.add
                    i32.load8_u
                    i32.const -92
                    i32.add
                    br_table $label33 $label28 $label28 $label28 $label28 $label28 $label28 $label28 $label28 $label34 $label28
                  end $label34
                  local.get $var10
                  i32.const 3
                  i32.add
                  local.tee $var21
                  local.get $var1
                  i32.gt_u
                  br_if $label28
                  local.get $var0
                  local.get $var21
                  i32.add
                  i32.load8_u
                  local.tee $var21
                  i32.const 92
                  i32.eq
                  br_if $label33
                  local.get $var21
                  i32.const 120
                  i32.ne
                  br_if $label28
                  local.get $var10
                  i32.const 4
                  i32.add
                  local.tee $var21
                  local.get $var1
                  i32.gt_u
                  br_if $label28
                  local.get $var0
                  local.get $var21
                  i32.add
                  i32.load8_u
                  local.tee $var21
                  i32.const 92
                  i32.eq
                  br_if $label33
                  local.get $var21
                  i32.const 116
                  i32.ne
                  br_if $label28
                  local.get $var25
                  local.get $var1
                  i32.gt_u
                  br_if $label28
                  local.get $var0
                  local.get $var25
                  i32.add
                  i32.load8_u
                  i32.const 34
                  i32.eq
                  local.set $var24
                  br $label28
                end $label32
                local.get $var21
                i32.const 92
                i32.ne
                br_if $label28
              end $label33
              local.get $var0
              local.get $var10
              local.get $var11
              i32.const 1024
              i32.const 4
              call $func14
              local.set $var24
            end $label28
            block $label35
              local.get $var23
              br_if $label35
              local.get $var24
              i32.eqz
              br_if $label2
            end $label35
            block $label36
              local.get $var11
              local.get $var3
              i32.ge_u
              br_if $label36
              loop $label37
                local.get $var0
                local.get $var11
                i32.add
                i32.load8_u
                i32.const -9
                i32.add
                local.tee $var10
                i32.const 23
                i32.gt_u
                br_if $label36
                i32.const 1
                local.get $var10
                i32.shl
                i32.const 8388627
                i32.and
                i32.eqz
                br_if $label36
                local.get $var3
                local.get $var11
                i32.const 1
                i32.add
                local.tee $var11
                i32.ne
                br_if $label37
                br $label2
              end $label37
            end $label36
            local.get $var11
            local.get $var3
            i32.ge_u
            br_if $label2
            local.get $var0
            local.get $var11
            i32.add
            i32.load8_u
            i32.const 58
            i32.ne
            br_if $label2
            block $label38
              local.get $var11
              i32.const 1
              i32.add
              local.tee $var1
              local.get $var3
              i32.ge_u
              br_if $label38
              loop $label39
                local.get $var0
                local.get $var1
                i32.add
                i32.load8_u
                i32.const -9
                i32.add
                local.tee $var10
                i32.const 23
                i32.gt_u
                br_if $label38
                i32.const 1
                local.get $var10
                i32.shl
                i32.const 8388627
                i32.and
                i32.eqz
                br_if $label38
                local.get $var3
                local.get $var1
                i32.const 1
                i32.add
                local.tee $var1
                i32.ne
                br_if $label39
              end $label39
              local.get $var3
              local.set $var1
            end $label38
            local.get $var7
            i32.const 0
            i32.store offset=12
            local.get $var0
            local.get $var3
            local.get $var1
            local.get $var7
            i32.const 12
            i32.add
            call $func12
            i32.eqz
            br_if $label2
            local.get $var7
            i32.load offset=12
            local.set $var10
            block $label41
              block $label42
                block $label43
                  block $label40
                    local.get $var23
                    i32.eqz
                    br_if $label40
                    i32.const 0
                    local.set $var20
                    local.get $var10
                    local.get $var1
                    i32.le_u
                    br_if $label41
                    local.get $var0
                    local.get $var1
                    i32.add
                    i32.load8_u
                    i32.const 34
                    i32.ne
                    br_if $label41
                    local.get $var10
                    local.get $var1
                    i32.const -1
                    i32.xor
                    i32.add
                    local.tee $var11
                    i32.eqz
                    br_if $label41
                    local.get $var12
                    local.get $var1
                    i32.add
                    i32.load8_u
                    local.tee $var23
                    i32.const 92
                    i32.eq
                    br_if $label42
                    local.get $var11
                    i32.const 1
                    i32.eq
                    br_if $label41
                    local.get $var23
                    i32.const 116
                    i32.ne
                    br_if $label41
                    local.get $var13
                    local.get $var1
                    i32.add
                    i32.load8_u
                    i32.const -92
                    i32.add
                    br_table $label42 $label41 $label41 $label41 $label41 $label41 $label41 $label41 $label41 $label43 $label41
                  end $label40
                  i32.const 0
                  local.set $var19
                  block $label44
                    local.get $var10
                    local.get $var1
                    i32.le_u
                    br_if $label44
                    local.get $var0
                    local.get $var1
                    i32.add
                    i32.load8_u
                    i32.const 34
                    i32.eq
                    local.set $var19
                  end $label44
                  local.get $var10
                  local.get $var1
                  i32.sub
                  local.set $var17
                  local.get $var1
                  local.set $var18
                  br $label41
                end $label43
                local.get $var11
                i32.const 2
                i32.eq
                br_if $label41
                local.get $var16
                local.get $var1
                i32.add
                i32.load8_u
                local.tee $var23
                i32.const 92
                i32.eq
                br_if $label42
                local.get $var23
                i32.const 120
                i32.ne
                br_if $label41
                local.get $var11
                i32.const 3
                i32.eq
                br_if $label41
                local.get $var15
                local.get $var1
                i32.add
                i32.load8_u
                local.tee $var11
                i32.const 92
                i32.eq
                br_if $label42
                local.get $var11
                i32.const 116
                i32.ne
                br_if $label41
                local.get $var1
                i32.const 5
                i32.add
                local.tee $var1
                local.get $var10
                i32.ge_u
                br_if $label41
                local.get $var0
                local.get $var1
                i32.add
                i32.load8_u
                i32.const 34
                i32.eq
                local.set $var20
                br $label41
              end $label42
              local.get $var0
              local.get $var1
              local.get $var10
              i32.const 1024
              i32.const 4
              call $func14
              local.set $var20
            end $label41
            block $label45
              local.get $var10
              local.get $var3
              i32.ge_u
              br_if $label45
              loop $label46
                local.get $var0
                local.get $var10
                i32.add
                i32.load8_u
                i32.const -9
                i32.add
                local.tee $var1
                i32.const 23
                i32.gt_u
                br_if $label45
                i32.const 1
                local.get $var1
                i32.shl
                i32.const 8388627
                i32.and
                i32.eqz
                br_if $label45
                local.get $var3
                local.get $var10
                i32.const 1
                i32.add
                local.tee $var10
                i32.ne
                br_if $label46
                br $label2
              end $label46
            end $label45
            local.get $var10
            local.get $var3
            i32.ge_u
            br_if $label2
            block $label47
              local.get $var0
              local.get $var10
              i32.add
              i32.load8_u
              local.tee $var1
              i32.const 125
              i32.eq
              br_if $label47
              local.get $var1
              i32.const 44
              i32.ne
              br_if $label2
              local.get $var10
              i32.const 1
              i32.add
              local.tee $var10
              local.get $var3
              i32.ge_u
              br_if $label47
              loop $label48
                local.get $var0
                local.get $var10
                i32.add
                i32.load8_u
                i32.const -9
                i32.add
                local.tee $var1
                i32.const 23
                i32.gt_u
                br_if $label47
                i32.const 1
                local.get $var1
                i32.shl
                i32.const 8388627
                i32.and
                i32.eqz
                br_if $label47
                local.get $var3
                local.get $var10
                i32.const 1
                i32.add
                local.tee $var10
                i32.ne
                br_if $label48
                br $label2
              end $label48
            end $label47
            local.get $var10
            local.get $var3
            i32.lt_u
            br_if $label49
          end $label49
        end $label2
        local.get $var6
        i32.load
        local.tee $var10
        local.get $var3
        local.get $var2
        i32.sub
        local.tee $var2
        i32.add
        local.tee $var0
        local.get $var10
        i32.lt_u
        br_if $label0
        local.get $var0
        local.get $var5
        i32.gt_u
        br_if $label0
        block $label50
          local.get $var2
          i32.eqz
          br_if $label50
          local.get $var4
          local.get $var10
          i32.add
          local.get $var9
          local.get $var2
          memory.copy
        end $label50
        local.get $var6
        local.get $var0
        i32.store
      end $label17
      i32.const 1
      local.set $var8
    end $label0
    local.get $var7
    i32.const 16
    i32.add
    global.set $global0
    local.get $var8
  )
  (func $func24 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 v128)
    (local $var7 v128)
    (local $var8 v128)
    (local $var9 v128)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    local.get $var0
    local.get $var1
    i32.add
    local.set $var4
    block $label2
      block $label0
        local.get $var1
        i32.const -64
        i32.add
        i32.const 448
        i32.gt_u
        br_if $label0
        local.get $var4
        i32.const -16
        i32.add
        local.set $var5
        v128.const i32x4 0xA53FE1ED 0x0708683C 0x811C9DC5 0xE2E52414
        local.set $var6
        v128.const i32x4 0xC25ABDE1 0x24234430 0x9E3779B9 0x00000008
        local.set $var7
        loop $label1
          local.get $var0
          v128.load align=1
          v128.const i32x4 0x85EBCA77 0x85EBCA77 0x85EBCA77 0x85EBCA77
          i32x4.mul
          local.tee $var8
          local.get $var7
          i32x4.add
          local.tee $var7
          i32.const 13
          i32x4.shl
          local.get $var7
          i32.const 19
          i32x4.shr_u
          v128.or
          v128.const i32x4 0x9E3779B1 0x9E3779B1 0x9E3779B1 0x9E3779B1
          local.tee $var9
          i32x4.mul
          local.set $var7
          local.get $var8
          local.get $var6
          i32x4.add
          local.tee $var6
          i32.const 13
          i32x4.shl
          local.get $var6
          i32.const 19
          i32x4.shr_u
          v128.or
          local.get $var9
          i32x4.mul
          local.set $var6
          local.get $var0
          i32.const 16
          i32.add
          local.tee $var0
          local.get $var5
          i32.le_u
          br_if $label1
        end $label1
        local.get $var7
        i32x4.extract_lane 0
        i32.const 1
        i32.rotl
        local.get $var7
        i32x4.extract_lane 1
        i32.const 7
        i32.rotl
        i32.add
        local.get $var7
        i32x4.extract_lane 2
        i32.const 12
        i32.rotl
        i32.add
        local.get $var7
        i32x4.extract_lane 3
        i32.const 18
        i32.rotl
        i32.add
        local.set $var5
        local.get $var6
        i32x4.extract_lane 0
        i32.const 1
        i32.rotl
        local.get $var6
        i32x4.extract_lane 1
        i32.const 7
        i32.rotl
        i32.add
        local.get $var6
        i32x4.extract_lane 2
        i32.const 12
        i32.rotl
        i32.add
        local.get $var6
        i32x4.extract_lane 3
        i32.const 18
        i32.rotl
        i32.add
        local.set $var10
        br $label2
      end $label0
      block $label3
        local.get $var1
        i32.const 16
        i32.ge_u
        br_if $label3
        i32.const -1754069642
        local.set $var10
        i32.const -1265770134
        local.set $var5
        br $label2
      end $label3
      local.get $var4
      i32.const -16
      i32.add
      local.set $var11
      i32.const -1640531527
      local.set $var5
      i32.const 606290992
      local.set $var10
      i32.const -1034240543
      local.set $var12
      i32.const -488299500
      local.set $var13
      i32.const -2128831035
      local.set $var14
      i32.const 117991484
      local.set $var15
      i32.const -1522540051
      local.set $var16
      i32.const 8
      local.set $var17
      loop $label4
        local.get $var0
        i32.load align=1
        i32.const -2048144777
        i32.mul
        local.tee $var18
        local.get $var12
        i32.add
        i32.const 13
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var12
        local.get $var18
        local.get $var16
        i32.add
        i32.const 13
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var16
        local.get $var0
        i32.const 12
        i32.add
        i32.load align=1
        i32.const -2048144777
        i32.mul
        local.tee $var18
        local.get $var17
        i32.add
        i32.const 13
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var17
        local.get $var18
        local.get $var13
        i32.add
        i32.const 13
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var13
        local.get $var0
        i32.const 8
        i32.add
        i32.load align=1
        i32.const -2048144777
        i32.mul
        local.tee $var18
        local.get $var5
        i32.add
        i32.const 13
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var5
        local.get $var18
        local.get $var14
        i32.add
        i32.const 13
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var14
        local.get $var0
        i32.const 4
        i32.add
        i32.load align=1
        i32.const -2048144777
        i32.mul
        local.tee $var18
        local.get $var10
        i32.add
        i32.const 13
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var10
        local.get $var18
        local.get $var15
        i32.add
        i32.const 13
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var15
        local.get $var0
        i32.const 16
        i32.add
        local.tee $var0
        local.get $var11
        i32.le_u
        br_if $label4
      end $label4
      local.get $var10
      i32.const 7
      i32.rotl
      local.get $var12
      i32.const 1
      i32.rotl
      i32.add
      local.get $var5
      i32.const 12
      i32.rotl
      i32.add
      local.get $var17
      i32.const 18
      i32.rotl
      i32.add
      local.set $var5
      local.get $var15
      i32.const 7
      i32.rotl
      local.get $var16
      i32.const 1
      i32.rotl
      i32.add
      local.get $var14
      i32.const 12
      i32.rotl
      i32.add
      local.get $var13
      i32.const 18
      i32.rotl
      i32.add
      local.set $var10
    end $label2
    local.get $var5
    local.get $var1
    i32.add
    local.set $var5
    local.get $var10
    local.get $var1
    i32.add
    local.set $var10
    block $label6
      block $label5
        local.get $var0
        i32.const 4
        i32.add
        local.get $var4
        i32.le_u
        br_if $label5
        local.get $var0
        local.set $var12
        br $label6
      end $label5
      loop $label7
        local.get $var0
        i32.load align=1
        i32.const -1028477379
        i32.mul
        local.tee $var12
        local.get $var5
        i32.add
        i32.const 17
        i32.rotl
        i32.const 668265263
        i32.mul
        local.set $var5
        local.get $var12
        local.get $var10
        i32.add
        i32.const 17
        i32.rotl
        i32.const 668265263
        i32.mul
        local.set $var10
        local.get $var0
        i32.const 8
        i32.add
        local.set $var13
        local.get $var0
        i32.const 4
        i32.add
        local.tee $var12
        local.set $var0
        local.get $var13
        local.get $var4
        i32.le_u
        br_if $label7
      end $label7
    end $label6
    block $label8
      local.get $var12
      local.get $var4
      i32.ge_u
      br_if $label8
      local.get $var12
      i32.const 1
      i32.add
      local.set $var0
      block $label9
        local.get $var4
        local.get $var12
        i32.sub
        i32.const 1
        i32.and
        i32.eqz
        br_if $label9
        local.get $var12
        i32.load8_u
        i32.const 374761393
        i32.mul
        local.tee $var12
        local.get $var5
        i32.add
        i32.const 11
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var5
        local.get $var12
        local.get $var10
        i32.add
        i32.const 11
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var10
        local.get $var0
        local.set $var12
      end $label9
      local.get $var4
      local.get $var0
      i32.eq
      br_if $label8
      loop $label10
        local.get $var12
        i32.const 1
        i32.add
        i32.load8_u
        i32.const 374761393
        i32.mul
        local.tee $var0
        local.get $var12
        i32.load8_u
        i32.const 374761393
        i32.mul
        local.tee $var13
        local.get $var5
        i32.add
        i32.const 11
        i32.rotl
        i32.const -1640531535
        i32.mul
        i32.add
        i32.const 11
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var5
        local.get $var0
        local.get $var13
        local.get $var10
        i32.add
        i32.const 11
        i32.rotl
        i32.const -1640531535
        i32.mul
        i32.add
        i32.const 11
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var10
        local.get $var12
        i32.const 2
        i32.add
        local.tee $var12
        local.get $var4
        i32.ne
        br_if $label10
      end $label10
    end $label8
    local.get $var2
    local.get $var10
    i32.const 15
    i32.shr_u
    local.get $var10
    i32.xor
    i32.const -2048144777
    i32.mul
    local.tee $var0
    i32.const 13
    i32.shr_u
    local.get $var0
    i32.xor
    i32.const -1028477379
    i32.mul
    local.tee $var0
    i32.const 16
    i32.shr_u
    local.get $var0
    i32.xor
    i32.store
    local.get $var3
    local.get $var5
    i32.const 15
    i32.shr_u
    local.get $var5
    i32.xor
    i32.const -2048144777
    i32.mul
    local.tee $var0
    i32.const 13
    i32.shr_u
    local.get $var0
    i32.xor
    i32.const -1028477379
    i32.mul
    local.tee $var0
    i32.const 16
    i32.shr_u
    local.get $var0
    i32.xor
    i32.store
  )
  (func $encode_term_content_no_hash (;25;) (export "encode_term_content_no_hash") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (result i32)
    local.get $var0
    local.get $var1
    local.get $var2
    local.get $var3
    local.get $var4
    local.get $var5
    i32.const 0
    call $func22
  )
  (func $encode_term_content_token_binary (;26;) (export "encode_term_content_token_binary") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (result i32)
    (local $var6 i32)
    (local $var7 i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    global.get $global0
    i32.const 16
    i32.sub
    local.tee $var6
    global.set $global0
    i32.const -1
    local.set $var7
    block $label0
      local.get $var0
      i32.eqz
      br_if $label0
      local.get $var1
      i32.eqz
      br_if $label0
      local.get $var3
      i32.eqz
      br_if $label0
      local.get $var5
      i32.eqz
      br_if $label0
      i32.const 0
      local.set $var7
      i32.const 0
      local.get $var4
      i32.store offset=2552
      local.get $var6
      i32.const 0
      i32.store offset=12
      local.get $var2
      i32.eqz
      br_if $label0
      i32.const 0
      local.set $var8
      i32.const 0
      local.set $var9
      loop $label7
        local.get $var6
        i32.const 0
        i32.store offset=8
        local.get $var6
        i32.const 0
        i32.store offset=4
        block $label1
          local.get $var0
          local.get $var1
          local.get $var9
          i32.const 68
          i32.mul
          i32.add
          local.tee $var10
          local.get $var3
          local.get $var4
          local.get $var6
          i32.const 12
          i32.add
          local.get $var6
          i32.const 8
          i32.add
          local.get $var6
          i32.const 4
          i32.add
          i32.const 0
          i32.const 0
          call $func27
          br_if $label1
          loop $label6
            local.get $var6
            local.get $var8
            i32.store offset=12
            block $label5
              block $label2
                local.get $var4
                i32.const 2147483646
                i32.gt_u
                br_if $label2
                local.get $var3
                local.get $var4
                i32.const 7
                i32.add
                i32.const -8
                i32.and
                local.tee $var11
                i32.const -1
                i32.xor
                i32.gt_u
                br_if $label2
                i32.const 0
                i32.load offset=2544
                local.get $var11
                local.get $var3
                i32.add
                local.tee $var7
                i32.ne
                br_if $label2
                i32.const 2147483647
                local.get $var4
                i32.const 1
                i32.shr_u
                local.tee $var12
                i32.const 1048576
                local.get $var12
                i32.const 1048576
                i32.gt_u
                select
                local.tee $var12
                local.get $var4
                i32.add
                local.get $var4
                local.get $var12
                i32.const 2147483647
                i32.xor
                i32.gt_u
                select
                local.tee $var4
                local.get $var11
                i32.sub
                i32.const 7
                i32.add
                local.set $var12
                local.get $var7
                local.set $var11
                block $label3
                  local.get $var7
                  br_if $label3
                  i32.const 104256
                  local.set $var11
                  i32.const 0
                  i32.const 104256
                  i32.store offset=2544
                end $label3
                local.get $var11
                i32.const 7
                i32.add
                i32.const -8
                i32.and
                local.tee $var11
                local.get $var12
                i32.const -8
                i32.and
                local.tee $var12
                i32.const -1
                i32.xor
                i32.gt_u
                br_if $label2
                block $label4
                  local.get $var11
                  local.get $var12
                  i32.add
                  local.tee $var12
                  i32.const 16
                  i32.shr_u
                  local.get $var12
                  i32.const 65528
                  i32.and
                  i32.const 0
                  i32.ne
                  i32.add
                  local.tee $var13
                  memory.size
                  local.tee $var14
                  i32.le_u
                  br_if $label4
                  local.get $var13
                  local.get $var14
                  i32.sub
                  memory.grow
                  i32.const 0
                  i32.lt_s
                  br_if $label2
                end $label4
                i32.const 0
                local.get $var12
                i32.store offset=2544
                local.get $var11
                i32.eqz
                br_if $label2
                local.get $var11
                local.get $var7
                i32.eq
                br_if $label5
              end $label2
              i32.const -2
              local.set $var7
              br $label0
            end $label5
            i32.const 0
            local.get $var4
            i32.store offset=2552
            local.get $var0
            local.get $var10
            local.get $var3
            local.get $var4
            local.get $var6
            i32.const 12
            i32.add
            local.get $var6
            i32.const 8
            i32.add
            local.get $var6
            i32.const 4
            i32.add
            i32.const 0
            i32.const 0
            call $func27
            i32.eqz
            br_if $label6
          end $label6
        end $label1
        local.get $var5
        local.get $var9
        i32.const 4
        i32.shl
        i32.add
        local.tee $var11
        local.get $var8
        i32.store
        local.get $var11
        local.get $var6
        i32.load offset=12
        local.tee $var7
        local.get $var8
        i32.sub
        i32.store offset=4
        local.get $var11
        local.get $var6
        i32.load offset=8
        i32.store offset=8
        local.get $var11
        local.get $var6
        i32.load offset=4
        i32.store offset=12
        local.get $var7
        local.set $var8
        local.get $var9
        i32.const 1
        i32.add
        local.tee $var9
        local.get $var2
        i32.ne
        br_if $label7
      end $label7
    end $label0
    local.get $var6
    i32.const 16
    i32.add
    global.set $global0
    local.get $var7
  )
  (func $func27 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (param $var8 i32) (result i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 i32)
    (local $var23 i32)
    (local $var24 i32)
    (local $var25 i32)
    (local $var26 i32)
    (local $var27 i32)
    (local $var28 i32)
    (local $var29 i32)
    (local $var30 i32)
    (local $var31 i64)
    (local $var32 i32)
    (local $var33 i32)
    (local $var34 i32)
    (local $var35 i32)
    (local $var36 i32)
    global.get $global0
    i32.const 16
    i32.sub
    local.tee $var9
    global.set $global0
    i32.const 0
    local.set $var10
    block $label0
      local.get $var4
      i32.load
      local.tee $var11
      i32.const -5
      i32.gt_u
      br_if $label0
      local.get $var11
      i32.const 4
      i32.add
      local.tee $var12
      local.get $var3
      i32.gt_u
      br_if $label0
      local.get $var2
      local.get $var11
      i32.add
      local.tee $var13
      i32.const 911360589
      i32.store align=1
      local.get $var4
      local.get $var12
      i32.store
      local.get $var1
      i32.load offset=52
      local.set $var14
      local.get $var1
      i32.load offset=20
      local.set $var15
      local.get $var1
      i32.load offset=48
      local.set $var16
      local.get $var1
      i32.load offset=16
      local.set $var17
      local.get $var1
      i32.load offset=24
      local.set $var18
      block $label4
        block $label1
          block $label2
            block $label3
              local.get $var1
              i32.load offset=28
              local.tee $var19
              br_table $label1 $label2 $label2 $label2 $label3 $label2
            end $label3
            local.get $var0
            local.get $var18
            i32.add
            local.tee $var20
            i32.load8_u
            i32.const 110
            i32.ne
            br_if $label2
            local.get $var20
            i32.const 1
            i32.add
            i32.load8_u
            i32.const 117
            i32.ne
            br_if $label2
            local.get $var20
            i32.const 2
            i32.add
            i32.load8_u
            i32.const 108
            i32.ne
            br_if $label2
            local.get $var20
            i32.const 3
            i32.add
            i32.load8_u
            i32.const 108
            i32.eq
            br_if $label1
          end $label2
          local.get $var12
          local.get $var19
          i32.add
          local.tee $var20
          local.get $var12
          i32.lt_u
          br_if $label0
          local.get $var20
          local.get $var3
          i32.gt_u
          br_if $label0
          local.get $var19
          i32.eqz
          br_if $label4
          local.get $var2
          local.get $var12
          i32.add
          local.get $var0
          local.get $var18
          i32.add
          local.get $var19
          memory.copy
          br $label4
        end $label1
        local.get $var12
        i32.const -3
        i32.gt_u
        br_if $label0
        local.get $var11
        i32.const 6
        i32.add
        local.tee $var20
        local.get $var3
        i32.gt_u
        br_if $label0
        local.get $var2
        local.get $var12
        i32.add
        i32.const 8738
        i32.store16 align=1
      end $label4
      local.get $var4
      local.get $var20
      i32.store
      local.get $var20
      local.get $var3
      i32.ge_u
      br_if $label0
      i32.const 0
      local.set $var10
      local.get $var2
      local.get $var20
      i32.add
      i32.const 0
      i32.store8
      local.get $var4
      local.get $var4
      i32.load
      local.tee $var20
      i32.const 1
      i32.add
      local.tee $var12
      i32.store
      block $label8
        block $label5
          block $label6
            block $label7
              local.get $var15
              br_table $label5 $label6 $label6 $label6 $label7 $label6
            end $label7
            local.get $var0
            local.get $var17
            i32.add
            local.tee $var19
            i32.load8_u
            i32.const 110
            i32.ne
            br_if $label6
            local.get $var19
            i32.const 1
            i32.add
            i32.load8_u
            i32.const 117
            i32.ne
            br_if $label6
            local.get $var19
            i32.const 2
            i32.add
            i32.load8_u
            i32.const 108
            i32.ne
            br_if $label6
            local.get $var19
            i32.const 3
            i32.add
            i32.load8_u
            i32.const 108
            i32.eq
            br_if $label5
          end $label6
          local.get $var12
          local.get $var15
          i32.add
          local.tee $var20
          local.get $var12
          i32.lt_u
          br_if $label0
          local.get $var20
          local.get $var3
          i32.gt_u
          br_if $label0
          local.get $var15
          i32.eqz
          br_if $label8
          local.get $var2
          local.get $var12
          i32.add
          local.get $var0
          local.get $var17
          i32.add
          local.get $var15
          memory.copy
          br $label8
        end $label5
        local.get $var12
        i32.const -3
        i32.gt_u
        br_if $label0
        local.get $var20
        i32.const 3
        i32.add
        local.tee $var20
        local.get $var3
        i32.gt_u
        br_if $label0
        local.get $var2
        local.get $var12
        i32.add
        i32.const 8738
        i32.store16 align=1
      end $label8
      local.get $var4
      local.get $var20
      i32.store
      local.get $var20
      local.get $var3
      i32.ge_u
      br_if $label0
      i32.const 0
      local.set $var10
      local.get $var2
      local.get $var20
      i32.add
      i32.const 0
      i32.store8
      local.get $var4
      local.get $var4
      i32.load
      local.tee $var20
      i32.const 1
      i32.add
      local.tee $var12
      i32.store
      block $label12
        block $label9
          block $label10
            block $label11
              local.get $var14
              br_table $label9 $label10 $label10 $label10 $label11 $label10
            end $label11
            local.get $var0
            local.get $var16
            i32.add
            local.tee $var19
            i32.load8_u
            i32.const 110
            i32.ne
            br_if $label10
            local.get $var19
            i32.const 1
            i32.add
            i32.load8_u
            i32.const 117
            i32.ne
            br_if $label10
            local.get $var19
            i32.const 2
            i32.add
            i32.load8_u
            i32.const 108
            i32.ne
            br_if $label10
            local.get $var19
            i32.const 3
            i32.add
            i32.load8_u
            i32.const 108
            i32.eq
            br_if $label9
          end $label10
          local.get $var12
          local.get $var14
          i32.add
          local.tee $var20
          local.get $var12
          i32.lt_u
          br_if $label0
          local.get $var20
          local.get $var3
          i32.gt_u
          br_if $label0
          local.get $var14
          i32.eqz
          br_if $label12
          local.get $var2
          local.get $var12
          i32.add
          local.get $var0
          local.get $var16
          i32.add
          local.get $var14
          memory.copy
          br $label12
        end $label9
        local.get $var12
        i32.const -3
        i32.gt_u
        br_if $label0
        local.get $var20
        i32.const 3
        i32.add
        local.tee $var20
        local.get $var3
        i32.gt_u
        br_if $label0
        local.get $var2
        local.get $var12
        i32.add
        i32.const 8738
        i32.store16 align=1
      end $label12
      local.get $var4
      local.get $var20
      i32.store
      local.get $var20
      local.get $var3
      i32.ge_u
      br_if $label0
      i32.const 0
      local.set $var10
      local.get $var2
      local.get $var20
      i32.add
      i32.const 0
      i32.store8
      local.get $var4
      local.get $var4
      i32.load
      local.tee $var19
      i32.const 1
      i32.add
      local.tee $var12
      i32.store
      block $label16
        block $label13
          local.get $var1
          i32.load offset=40
          local.tee $var20
          i32.eqz
          br_if $label13
          block $label14
            local.get $var1
            i32.load offset=64
            br_if $label14
            i32.const 0
            local.set $var10
            local.get $var12
            local.get $var20
            i32.add
            local.tee $var8
            local.get $var12
            i32.lt_u
            br_if $label0
            local.get $var8
            local.get $var3
            i32.gt_u
            br_if $label0
            block $label15
              local.get $var20
              i32.eqz
              br_if $label15
              local.get $var2
              local.get $var12
              i32.add
              local.get $var0
              local.get $var1
              i32.load offset=36
              i32.add
              local.get $var20
              memory.copy
            end $label15
            local.get $var4
            local.get $var8
            i32.store
            br $label16
          end $label14
          block $label17
            local.get $var7
            i32.const 16
            i32.and
            i32.eqz
            br_if $label17
            i32.const 1
            local.set $var19
            block $label18
              local.get $var1
              i32.load offset=36
              local.tee $var10
              local.get $var10
              local.get $var20
              i32.add
              local.tee $var20
              i32.ge_u
              br_if $label18
              local.get $var0
              local.get $var10
              i32.add
              i32.load8_u
              i32.const 91
              i32.ne
              br_if $label18
              i32.const 1
              local.set $var19
              block $label19
                local.get $var12
                local.get $var3
                i32.ge_u
                br_if $label19
                local.get $var2
                local.get $var12
                i32.add
                i32.const 91
                i32.store8
                i32.const 1
                local.set $var19
                local.get $var4
                local.get $var4
                i32.load
                i32.const 1
                i32.add
                local.tee $var18
                i32.store
                local.get $var10
                i32.const 1
                i32.add
                local.tee $var10
                local.get $var20
                i32.ge_u
                br_if $label19
                local.get $var0
                i32.const 1
                i32.add
                local.set $var21
                local.get $var0
                i32.const 2
                i32.add
                local.set $var22
                local.get $var0
                i32.const 5
                i32.add
                local.set $var23
                local.get $var0
                i32.const 4
                i32.add
                local.set $var24
                local.get $var0
                i32.const 3
                i32.add
                local.set $var25
                i32.const 0
                local.set $var17
                loop $label69
                  block $label20
                    local.get $var10
                    local.get $var20
                    i32.ge_u
                    br_if $label20
                    loop $label21
                      local.get $var0
                      local.get $var10
                      i32.add
                      i32.load8_u
                      i32.const -9
                      i32.add
                      local.tee $var19
                      i32.const 23
                      i32.gt_u
                      br_if $label20
                      i32.const 1
                      local.get $var19
                      i32.shl
                      i32.const 8388627
                      i32.and
                      i32.eqz
                      br_if $label20
                      i32.const 1
                      local.set $var19
                      local.get $var20
                      local.get $var10
                      i32.const 1
                      i32.add
                      local.tee $var10
                      i32.ne
                      br_if $label21
                      br $label19
                    end $label21
                  end $label20
                  i32.const 1
                  local.set $var19
                  local.get $var10
                  local.get $var20
                  i32.ge_u
                  br_if $label19
                  block $label22
                    local.get $var0
                    local.get $var10
                    i32.add
                    local.tee $var16
                    i32.load8_u
                    local.tee $var7
                    i32.const 93
                    i32.ne
                    br_if $label22
                    local.get $var18
                    local.get $var3
                    i32.ge_u
                    br_if $label19
                    local.get $var2
                    local.get $var18
                    i32.add
                    i32.const 93
                    i32.store8
                    local.get $var4
                    i32.load
                    i32.const 1
                    i32.add
                    local.set $var12
                    i32.const 0
                    local.set $var19
                    br $label19
                  end $label22
                  local.get $var9
                  i32.const 0
                  i32.store offset=8
                  block $label30
                    block $label61
                      block $label23
                        local.get $var7
                        i32.const 123
                        i32.ne
                        br_if $label23
                        block $label26
                          block $label24
                            local.get $var10
                            i32.const 1
                            i32.add
                            local.tee $var7
                            local.get $var20
                            i32.ge_u
                            br_if $label24
                            loop $label25
                              local.get $var0
                              local.get $var7
                              i32.add
                              i32.load8_u
                              i32.const -9
                              i32.add
                              local.tee $var18
                              i32.const 23
                              i32.gt_u
                              br_if $label24
                              i32.const 1
                              local.get $var18
                              i32.shl
                              i32.const 8388627
                              i32.and
                              i32.eqz
                              br_if $label24
                              local.get $var20
                              local.get $var7
                              i32.const 1
                              i32.add
                              local.tee $var7
                              i32.ne
                              br_if $label25
                              br $label26
                            end $label25
                          end $label24
                          local.get $var7
                          local.get $var20
                          i32.ge_u
                          br_if $label26
                          i32.const 0
                          local.set $var26
                          i32.const 0
                          local.set $var27
                          i32.const 0
                          local.set $var14
                          i32.const 0
                          local.set $var28
                          i32.const 0
                          local.set $var29
                          loop $label60
                            block $label27
                              local.get $var7
                              local.get $var20
                              i32.ge_u
                              br_if $label27
                              loop $label28
                                local.get $var0
                                local.get $var7
                                i32.add
                                i32.load8_u
                                i32.const -9
                                i32.add
                                local.tee $var18
                                i32.const 23
                                i32.gt_u
                                br_if $label27
                                i32.const 1
                                local.get $var18
                                i32.shl
                                i32.const 8388627
                                i32.and
                                i32.eqz
                                br_if $label27
                                local.get $var20
                                local.get $var7
                                i32.const 1
                                i32.add
                                local.tee $var7
                                i32.ne
                                br_if $label28
                                br $label26
                              end $label28
                            end $label27
                            local.get $var7
                            local.get $var20
                            i32.ge_u
                            br_if $label26
                            block $label29
                              local.get $var0
                              local.get $var7
                              i32.add
                              i32.load8_u
                              local.tee $var18
                              i32.const 125
                              i32.ne
                              br_if $label29
                              local.get $var27
                              i32.const 2
                              i32.ne
                              br_if $label26
                              local.get $var26
                              i32.eqz
                              br_if $label26
                              local.get $var29
                              i32.eqz
                              br_if $label26
                              local.get $var16
                              i32.load8_u
                              i32.const 91
                              i32.eq
                              br_if $label19
                              i32.const 1
                              local.set $var18
                              local.get $var7
                              i32.const 1
                              i32.add
                              local.set $var7
                              br $label30
                            end $label29
                            local.get $var27
                            i32.const 1
                            i32.gt_u
                            br_if $label26
                            local.get $var18
                            i32.const 34
                            i32.ne
                            br_if $label26
                            local.get $var7
                            i32.const 1
                            i32.add
                            local.tee $var30
                            local.get $var20
                            i32.ge_u
                            br_if $label26
                            local.get $var30
                            local.set $var15
                            loop $label32
                              block $label31
                                local.get $var15
                                local.tee $var18
                                i32.const 8
                                i32.add
                                local.tee $var15
                                local.get $var20
                                i32.gt_u
                                br_if $label31
                                local.get $var0
                                local.get $var18
                                i32.add
                                i64.load align=1
                                local.tee $var31
                                i64.const -1
                                i64.xor
                                local.get $var31
                                i64.const 6655295901103053916
                                i64.xor
                                i64.const -72340172838076673
                                i64.add
                                local.get $var31
                                i64.const -2314885530818453536
                                i64.add
                                i64.or
                                local.get $var31
                                i64.const 2459565876494606882
                                i64.xor
                                i64.const -72340172838076673
                                i64.add
                                i64.or
                                i64.and
                                i64.const -9187201950435737472
                                i64.and
                                local.tee $var31
                                i64.eqz
                                br_if $label32
                                local.get $var31
                                i64.ctz
                                i32.wrap_i64
                                i32.const 3
                                i32.shr_u
                                local.get $var18
                                i32.add
                                local.set $var18
                              end $label31
                              local.get $var18
                              local.get $var20
                              i32.ge_u
                              br_if $label26
                              block $label40
                                block $label36
                                  block $label33
                                    local.get $var0
                                    local.get $var18
                                    i32.add
                                    i32.load8_u
                                    local.tee $var32
                                    i32.const 92
                                    i32.ne
                                    br_if $label33
                                    local.get $var18
                                    i32.const 1
                                    i32.add
                                    local.tee $var15
                                    local.get $var20
                                    i32.ge_u
                                    br_if $label26
                                    block $label34
                                      block $label35
                                        local.get $var0
                                        local.get $var15
                                        i32.add
                                        i32.load8_u
                                        i32.const -34
                                        i32.add
                                        br_table $label34 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label34 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label34 $label26 $label26 $label26 $label26 $label26 $label34 $label26 $label26 $label26 $label34 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label34 $label26 $label26 $label26 $label34 $label26 $label34 $label35 $label26
                                      end $label35
                                      local.get $var18
                                      i32.const 6
                                      i32.add
                                      local.tee $var15
                                      local.get $var20
                                      i32.gt_u
                                      br_if $label26
                                      local.get $var18
                                      i32.const 2
                                      i32.add
                                      local.tee $var32
                                      local.get $var15
                                      i32.ge_u
                                      br_if $label36
                                      block $label37
                                        local.get $var0
                                        local.get $var32
                                        i32.add
                                        i32.load8_u
                                        local.tee $var32
                                        i32.const -58
                                        i32.add
                                        i32.const 255
                                        i32.and
                                        i32.const 245
                                        i32.gt_u
                                        br_if $label37
                                        local.get $var32
                                        i32.const -33
                                        i32.and
                                        i32.const -71
                                        i32.add
                                        i32.const 255
                                        i32.and
                                        i32.const 250
                                        i32.lt_u
                                        br_if $label26
                                      end $label37
                                      block $label38
                                        local.get $var25
                                        local.get $var18
                                        i32.add
                                        i32.load8_u
                                        local.tee $var32
                                        i32.const -58
                                        i32.add
                                        i32.const 255
                                        i32.and
                                        i32.const 245
                                        i32.gt_u
                                        br_if $label38
                                        local.get $var32
                                        i32.const -33
                                        i32.and
                                        i32.const -71
                                        i32.add
                                        i32.const 255
                                        i32.and
                                        i32.const 250
                                        i32.lt_u
                                        br_if $label26
                                      end $label38
                                      block $label39
                                        local.get $var24
                                        local.get $var18
                                        i32.add
                                        i32.load8_u
                                        local.tee $var32
                                        i32.const -58
                                        i32.add
                                        i32.const 255
                                        i32.and
                                        i32.const 245
                                        i32.gt_u
                                        br_if $label39
                                        local.get $var32
                                        i32.const -33
                                        i32.and
                                        i32.const -71
                                        i32.add
                                        i32.const 255
                                        i32.and
                                        i32.const 250
                                        i32.lt_u
                                        br_if $label26
                                      end $label39
                                      local.get $var23
                                      local.get $var18
                                      i32.add
                                      i32.load8_u
                                      local.tee $var18
                                      i32.const -58
                                      i32.add
                                      i32.const 255
                                      i32.and
                                      i32.const 245
                                      i32.gt_u
                                      br_if $label36
                                      local.get $var18
                                      i32.const -33
                                      i32.and
                                      i32.const -71
                                      i32.add
                                      i32.const 255
                                      i32.and
                                      i32.const 250
                                      i32.ge_u
                                      br_if $label36
                                      br $label26
                                    end $label34
                                    local.get $var18
                                    i32.const 2
                                    i32.add
                                    local.set $var15
                                    br $label36
                                  end $label33
                                  local.get $var32
                                  i32.const 32
                                  i32.lt_u
                                  br_if $label26
                                  local.get $var18
                                  i32.const 1
                                  i32.add
                                  local.set $var15
                                  local.get $var32
                                  i32.const 34
                                  i32.eq
                                  br_if $label40
                                end $label36
                                local.get $var15
                                local.get $var20
                                i32.lt_u
                                br_if $label32
                                br $label26
                              end $label40
                            end $label32
                            i32.const 0
                            local.set $var32
                            i32.const 0
                            local.set $var33
                            block $label41
                              local.get $var18
                              local.get $var7
                              i32.lt_u
                              br_if $label41
                              local.get $var7
                              i32.const 5
                              i32.add
                              local.set $var34
                              i32.const 0
                              local.set $var33
                              i32.const 0
                              local.set $var32
                              block $label42
                                local.get $var18
                                local.get $var7
                                i32.eq
                                br_if $label42
                                block $label43
                                  local.get $var0
                                  local.get $var30
                                  i32.add
                                  i32.load8_u
                                  local.tee $var35
                                  i32.const 92
                                  i32.eq
                                  br_if $label43
                                  i32.const 0
                                  local.set $var32
                                  local.get $var18
                                  local.get $var7
                                  i32.sub
                                  local.tee $var36
                                  i32.const 1
                                  i32.eq
                                  br_if $label42
                                  i32.const 0
                                  local.set $var32
                                  local.get $var35
                                  i32.const 116
                                  i32.ne
                                  br_if $label42
                                  local.get $var22
                                  local.get $var7
                                  i32.add
                                  i32.load8_u
                                  local.tee $var35
                                  i32.const 92
                                  i32.eq
                                  br_if $label43
                                  i32.const 0
                                  local.set $var32
                                  local.get $var35
                                  i32.const 121
                                  i32.ne
                                  br_if $label42
                                  i32.const 0
                                  local.set $var32
                                  local.get $var36
                                  i32.const 2
                                  i32.eq
                                  br_if $label42
                                  local.get $var25
                                  local.get $var7
                                  i32.add
                                  i32.load8_u
                                  local.tee $var35
                                  i32.const 92
                                  i32.eq
                                  br_if $label43
                                  i32.const 0
                                  local.set $var32
                                  local.get $var35
                                  i32.const 112
                                  i32.ne
                                  br_if $label42
                                  i32.const 0
                                  local.set $var32
                                  local.get $var36
                                  i32.const 3
                                  i32.eq
                                  br_if $label42
                                  i32.const 0
                                  local.set $var32
                                  block $label44
                                    local.get $var24
                                    local.get $var7
                                    i32.add
                                    i32.load8_u
                                    i32.const -92
                                    i32.add
                                    br_table $label43 $label42 $label42 $label42 $label42 $label42 $label42 $label42 $label42 $label44 $label42
                                  end $label44
                                  i32.const 0
                                  local.set $var32
                                  local.get $var34
                                  local.get $var18
                                  i32.gt_u
                                  br_if $label42
                                  local.get $var0
                                  local.get $var34
                                  i32.add
                                  i32.load8_u
                                  i32.const 34
                                  i32.eq
                                  local.set $var32
                                  br $label42
                                end $label43
                                local.get $var0
                                local.get $var7
                                local.get $var15
                                i32.const 1061
                                i32.const 4
                                call $func14
                                local.set $var32
                              end $label42
                              local.get $var18
                              local.get $var7
                              i32.le_u
                              br_if $label41
                              block $label46
                                block $label45
                                  local.get $var0
                                  local.get $var30
                                  i32.add
                                  i32.load8_u
                                  local.tee $var30
                                  i32.const 116
                                  i32.ne
                                  br_if $label45
                                  local.get $var7
                                  i32.const 2
                                  i32.add
                                  local.tee $var30
                                  local.get $var18
                                  i32.gt_u
                                  br_if $label41
                                  block $label47
                                    local.get $var0
                                    local.get $var30
                                    i32.add
                                    i32.load8_u
                                    i32.const -92
                                    i32.add
                                    br_table $label46 $label41 $label41 $label41 $label41 $label41 $label41 $label41 $label41 $label47 $label41
                                  end $label47
                                  local.get $var7
                                  i32.const 3
                                  i32.add
                                  local.tee $var30
                                  local.get $var18
                                  i32.gt_u
                                  br_if $label41
                                  local.get $var0
                                  local.get $var30
                                  i32.add
                                  i32.load8_u
                                  local.tee $var30
                                  i32.const 92
                                  i32.eq
                                  br_if $label46
                                  local.get $var30
                                  i32.const 120
                                  i32.ne
                                  br_if $label41
                                  local.get $var7
                                  i32.const 4
                                  i32.add
                                  local.tee $var30
                                  local.get $var18
                                  i32.gt_u
                                  br_if $label41
                                  local.get $var0
                                  local.get $var30
                                  i32.add
                                  i32.load8_u
                                  local.tee $var30
                                  i32.const 92
                                  i32.eq
                                  br_if $label46
                                  local.get $var30
                                  i32.const 116
                                  i32.ne
                                  br_if $label41
                                  local.get $var34
                                  local.get $var18
                                  i32.gt_u
                                  br_if $label41
                                  local.get $var0
                                  local.get $var34
                                  i32.add
                                  i32.load8_u
                                  i32.const 34
                                  i32.eq
                                  local.set $var33
                                  br $label41
                                end $label45
                                local.get $var30
                                i32.const 92
                                i32.ne
                                br_if $label41
                              end $label46
                              local.get $var0
                              local.get $var7
                              local.get $var15
                              i32.const 1024
                              i32.const 4
                              call $func14
                              local.set $var33
                            end $label41
                            block $label48
                              local.get $var32
                              br_if $label48
                              local.get $var33
                              i32.eqz
                              br_if $label26
                            end $label48
                            block $label49
                              local.get $var15
                              local.get $var20
                              i32.ge_u
                              br_if $label49
                              loop $label50
                                local.get $var0
                                local.get $var15
                                i32.add
                                i32.load8_u
                                i32.const -9
                                i32.add
                                local.tee $var7
                                i32.const 23
                                i32.gt_u
                                br_if $label49
                                i32.const 1
                                local.get $var7
                                i32.shl
                                i32.const 8388627
                                i32.and
                                i32.eqz
                                br_if $label49
                                local.get $var20
                                local.get $var15
                                i32.const 1
                                i32.add
                                local.tee $var15
                                i32.ne
                                br_if $label50
                                br $label26
                              end $label50
                            end $label49
                            local.get $var15
                            local.get $var20
                            i32.ge_u
                            br_if $label26
                            local.get $var0
                            local.get $var15
                            i32.add
                            i32.load8_u
                            i32.const 58
                            i32.ne
                            br_if $label26
                            block $label51
                              local.get $var15
                              i32.const 1
                              i32.add
                              local.tee $var18
                              local.get $var20
                              i32.ge_u
                              br_if $label51
                              loop $label52
                                local.get $var0
                                local.get $var18
                                i32.add
                                i32.load8_u
                                i32.const -9
                                i32.add
                                local.tee $var7
                                i32.const 23
                                i32.gt_u
                                br_if $label51
                                i32.const 1
                                local.get $var7
                                i32.shl
                                i32.const 8388627
                                i32.and
                                i32.eqz
                                br_if $label51
                                local.get $var20
                                local.get $var18
                                i32.const 1
                                i32.add
                                local.tee $var18
                                i32.ne
                                br_if $label52
                              end $label52
                              local.get $var20
                              local.set $var18
                            end $label51
                            local.get $var9
                            i32.const 0
                            i32.store offset=12
                            local.get $var0
                            local.get $var20
                            local.get $var18
                            local.get $var9
                            i32.const 12
                            i32.add
                            call $func12
                            i32.eqz
                            br_if $label26
                            local.get $var9
                            i32.load offset=12
                            local.tee $var7
                            local.get $var20
                            i32.gt_u
                            br_if $label26
                            block $label56
                              block $label53
                                local.get $var32
                                i32.eqz
                                br_if $label53
                                local.get $var7
                                local.get $var18
                                i32.le_u
                                br_if $label26
                                local.get $var0
                                local.get $var18
                                i32.add
                                i32.load8_u
                                i32.const 34
                                i32.ne
                                br_if $label26
                                local.get $var7
                                local.get $var18
                                i32.const -1
                                i32.xor
                                i32.add
                                local.tee $var15
                                i32.eqz
                                br_if $label26
                                block $label54
                                  local.get $var21
                                  local.get $var18
                                  i32.add
                                  i32.load8_u
                                  local.tee $var32
                                  i32.const 92
                                  i32.eq
                                  br_if $label54
                                  local.get $var15
                                  i32.const 1
                                  i32.eq
                                  br_if $label26
                                  local.get $var32
                                  i32.const 116
                                  i32.ne
                                  br_if $label26
                                  block $label55
                                    local.get $var22
                                    local.get $var18
                                    i32.add
                                    i32.load8_u
                                    i32.const -92
                                    i32.add
                                    br_table $label54 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label26 $label55 $label26
                                  end $label55
                                  local.get $var15
                                  i32.const 2
                                  i32.eq
                                  br_if $label26
                                  local.get $var25
                                  local.get $var18
                                  i32.add
                                  i32.load8_u
                                  local.tee $var32
                                  i32.const 92
                                  i32.eq
                                  br_if $label54
                                  local.get $var32
                                  i32.const 120
                                  i32.ne
                                  br_if $label26
                                  local.get $var15
                                  i32.const 3
                                  i32.eq
                                  br_if $label26
                                  local.get $var24
                                  local.get $var18
                                  i32.add
                                  i32.load8_u
                                  local.tee $var15
                                  i32.const 92
                                  i32.eq
                                  br_if $label54
                                  local.get $var15
                                  i32.const 116
                                  i32.ne
                                  br_if $label26
                                  local.get $var18
                                  i32.const 5
                                  i32.add
                                  local.tee $var18
                                  local.get $var7
                                  i32.ge_u
                                  br_if $label26
                                  local.get $var0
                                  local.get $var18
                                  i32.add
                                  i32.load8_u
                                  i32.const 34
                                  i32.ne
                                  br_if $label26
                                  i32.const 1
                                  local.set $var26
                                  br $label56
                                end $label54
                                local.get $var0
                                local.get $var18
                                local.get $var7
                                i32.const 1024
                                i32.const 4
                                call $func14
                                i32.eqz
                                br_if $label26
                                i32.const 1
                                local.set $var26
                                br $label56
                              end $label53
                              local.get $var7
                              local.get $var18
                              i32.le_u
                              br_if $label26
                              local.get $var0
                              local.get $var18
                              i32.add
                              i32.load8_u
                              i32.const 34
                              i32.ne
                              br_if $label26
                              local.get $var7
                              local.get $var18
                              i32.sub
                              local.set $var14
                              i32.const 1
                              local.set $var29
                              local.get $var18
                              local.set $var28
                            end $label56
                            block $label57
                              local.get $var7
                              local.get $var20
                              i32.ge_u
                              br_if $label57
                              loop $label58
                                local.get $var0
                                local.get $var7
                                i32.add
                                i32.load8_u
                                i32.const -9
                                i32.add
                                local.tee $var18
                                i32.const 23
                                i32.gt_u
                                br_if $label57
                                i32.const 1
                                local.get $var18
                                i32.shl
                                i32.const 8388627
                                i32.and
                                i32.eqz
                                br_if $label57
                                local.get $var20
                                local.get $var7
                                i32.const 1
                                i32.add
                                local.tee $var7
                                i32.ne
                                br_if $label58
                                br $label26
                              end $label58
                            end $label57
                            block $label59
                              local.get $var7
                              local.get $var20
                              i32.ge_u
                              br_if $label59
                              local.get $var7
                              local.get $var0
                              local.get $var7
                              i32.add
                              i32.load8_u
                              i32.const 44
                              i32.eq
                              i32.add
                              local.set $var7
                            end $label59
                            local.get $var27
                            i32.const 1
                            i32.add
                            local.set $var27
                            local.get $var7
                            local.get $var20
                            i32.lt_u
                            br_if $label60
                          end $label60
                        end $label26
                        local.get $var16
                        i32.load8_u
                        i32.const 32
                        i32.or
                        i32.const 123
                        i32.ne
                        br_if $label61
                        br $label19
                      end $label23
                      local.get $var7
                      i32.const 223
                      i32.and
                      i32.const 91
                      i32.eq
                      br_if $label19
                    end $label61
                    local.get $var0
                    local.get $var20
                    local.get $var10
                    local.get $var9
                    i32.const 8
                    i32.add
                    call $func12
                    i32.eqz
                    br_if $label19
                    i32.const 0
                    local.set $var28
                    i32.const 0
                    local.set $var14
                    i32.const 0
                    local.set $var18
                    local.get $var9
                    i32.load offset=8
                    local.tee $var7
                    local.get $var20
                    i32.gt_u
                    br_if $label19
                  end $label30
                  block $label62
                    local.get $var17
                    i32.const 1
                    i32.and
                    i32.eqz
                    br_if $label62
                    local.get $var4
                    i32.load
                    local.tee $var15
                    local.get $var3
                    i32.ge_u
                    br_if $label19
                    local.get $var2
                    local.get $var15
                    i32.add
                    i32.const 44
                    i32.store8
                    local.get $var4
                    local.get $var4
                    i32.load
                    i32.const 1
                    i32.add
                    i32.store
                  end $label62
                  block $label64
                    block $label63
                      local.get $var18
                      i32.eqz
                      br_if $label63
                      local.get $var4
                      i32.load
                      local.tee $var10
                      local.get $var14
                      i32.add
                      local.tee $var18
                      local.get $var10
                      i32.lt_u
                      br_if $label19
                      local.get $var18
                      local.get $var3
                      i32.gt_u
                      br_if $label19
                      local.get $var14
                      i32.eqz
                      br_if $label64
                      local.get $var2
                      local.get $var10
                      i32.add
                      local.get $var0
                      local.get $var28
                      i32.add
                      local.get $var14
                      memory.copy
                      br $label64
                    end $label63
                    local.get $var4
                    i32.load
                    local.tee $var15
                    local.get $var7
                    local.get $var10
                    i32.sub
                    local.tee $var10
                    i32.add
                    local.tee $var18
                    local.get $var15
                    i32.lt_u
                    br_if $label19
                    local.get $var18
                    local.get $var3
                    i32.gt_u
                    br_if $label19
                    local.get $var10
                    i32.eqz
                    br_if $label64
                    local.get $var2
                    local.get $var15
                    i32.add
                    local.get $var16
                    local.get $var10
                    memory.copy
                  end $label64
                  local.get $var4
                  local.get $var18
                  i32.store
                  block $label65
                    local.get $var7
                    local.get $var20
                    i32.ge_u
                    br_if $label65
                    loop $label66
                      local.get $var0
                      local.get $var7
                      i32.add
                      i32.load8_u
                      i32.const -9
                      i32.add
                      local.tee $var10
                      i32.const 23
                      i32.gt_u
                      br_if $label65
                      i32.const 1
                      local.get $var10
                      i32.shl
                      i32.const 8388627
                      i32.and
                      i32.eqz
                      br_if $label65
                      local.get $var20
                      local.get $var7
                      i32.const 1
                      i32.add
                      local.tee $var7
                      i32.ne
                      br_if $label66
                      br $label19
                    end $label66
                  end $label65
                  block $label68
                    block $label67
                      local.get $var7
                      local.get $var20
                      i32.lt_u
                      br_if $label67
                      local.get $var7
                      local.set $var10
                      br $label68
                    end $label67
                    local.get $var7
                    local.get $var0
                    local.get $var7
                    i32.add
                    i32.load8_u
                    i32.const 44
                    i32.eq
                    i32.add
                    local.set $var10
                  end $label68
                  i32.const 1
                  local.set $var17
                  local.get $var10
                  local.get $var20
                  i32.lt_u
                  br_if $label69
                end $label69
                i32.const 1
                local.set $var19
              end $label19
              local.get $var4
              local.get $var12
              i32.store
            end $label18
            block $label70
              local.get $var8
              i32.eqz
              br_if $label70
              block $label71
                local.get $var19
                br_if $label71
                local.get $var8
                local.get $var8
                i32.load offset=12
                i32.const 1
                i32.add
                i32.store offset=12
                br $label16
              end $label71
              local.get $var8
              local.get $var8
              i32.load offset=16
              i32.const 1
              i32.add
              i32.store offset=16
              br $label17
            end $label70
            local.get $var19
            i32.eqz
            br_if $label16
          end $label17
          local.get $var0
          local.get $var1
          i32.load offset=40
          local.get $var1
          i32.load offset=36
          local.tee $var1
          i32.add
          local.tee $var12
          local.get $var1
          local.get $var12
          local.get $var2
          local.get $var3
          local.get $var4
          call $func23
          br_if $label16
          i32.const 0
          local.set $var10
          br $label0
        end $label13
        local.get $var12
        i32.const -3
        i32.gt_u
        br_if $label0
        local.get $var19
        i32.const 3
        i32.add
        local.tee $var1
        local.get $var3
        i32.gt_u
        br_if $label0
        local.get $var2
        local.get $var12
        i32.add
        i32.const 23899
        i32.store16 align=1
        local.get $var4
        local.get $var1
        i32.store
      end $label16
      local.get $var4
      i32.load
      local.set $var1
      local.get $var9
      i32.const 0
      i32.store offset=12
      local.get $var9
      i32.const 0
      i32.store offset=8
      local.get $var13
      local.get $var1
      local.get $var11
      i32.sub
      local.get $var9
      i32.const 12
      i32.add
      local.get $var9
      i32.const 8
      i32.add
      call $func24
      i32.const 1
      local.set $var10
      local.get $var5
      local.get $var9
      i32.load offset=12
      local.tee $var1
      i32.const 1
      local.get $var1
      local.get $var9
      i32.load offset=8
      local.tee $var4
      i32.or
      select
      i32.store
      local.get $var6
      local.get $var4
      i32.store
    end $label0
    local.get $var9
    i32.const 16
    i32.add
    global.set $global0
    local.get $var10
  )
  (func $build_term_string_plan (;28;) (export "build_term_string_plan") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (param $var8 i32) (param $var9 i32) (param $var10 i32) (param $var11 i32) (param $var12 i32) (param $var13 i32) (result i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 v128)
    (local $var17 v128)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 i32)
    (local $var23 i32)
    (local $var24 i32)
    (local $var25 i32)
    (local $var26 i32)
    (local $var27 i32)
    (local $var28 i32)
    (local $var29 i32)
    (local $var30 i32)
    (local $var31 i32)
    (local $var32 i32)
    (local $var33 i32)
    (local $var34 i32)
    (local $var35 i32)
    (local $var36 i32)
    (local $var37 i32)
    (local $var38 i32)
    global.get $global0
    i32.const 32
    i32.sub
    local.tee $var14
    global.set $global0
    i32.const -1
    local.set $var15
    block $label0
      local.get $var0
      i32x4.splat
      local.get $var1
      i32x4.replace_lane 1
      local.get $var4
      i32x4.replace_lane 2
      local.get $var6
      i32x4.replace_lane 3
      v128.const i32x4 0x00000000 0x00000000 0x00000000 0x00000000
      local.tee $var16
      i32x4.eq
      v128.const i32x4 0x0000FFFF 0x0000FFFF 0x0000FFFF 0x0000FFFF
      local.tee $var17
      v128.and
      local.get $var7
      i32x4.splat
      local.get $var8
      i32x4.replace_lane 1
      local.get $var9
      i32x4.replace_lane 2
      local.get $var10
      i32x4.replace_lane 3
      local.get $var16
      i32x4.eq
      local.get $var17
      v128.and
      i16x8.narrow_i32x4_u
      v128.any_true
      br_if $label0
      local.get $var11
      i32.eqz
      br_if $label0
      local.get $var13
      i32.eqz
      br_if $label0
      local.get $var12
      i32.eqz
      br_if $label0
      i32.const -1
      local.set $var15
      local.get $var12
      local.get $var12
      i32.const -1
      i32.add
      local.tee $var18
      i32.and
      br_if $label0
      block $label2
        block $label1
          local.get $var3
          br_if $label1
          i32.const 0
          local.set $var19
          i32.const 0
          local.set $var20
          br $label2
        end $label1
        local.get $var3
        i32.const 1
        i32.shl
        local.set $var21
        local.get $var1
        local.get $var2
        i32.const 68
        i32.mul
        i32.add
        local.set $var22
        i32.const 0
        local.set $var20
        i32.const 0
        local.set $var19
        i32.const 0
        local.set $var23
        loop $label28
          local.get $var14
          local.get $var22
          local.get $var23
          i32.const 68
          i32.mul
          i32.add
          local.tee $var15
          i32.load
          local.tee $var1
          i32.store offset=28
          local.get $var14
          local.get $var15
          i32.load offset=8
          local.tee $var2
          i32.store offset=24
          local.get $var14
          local.get $var15
          i32.load offset=4
          local.tee $var24
          i32.store offset=20
          local.get $var14
          local.get $var15
          i32.load offset=12
          local.tee $var15
          i32.store offset=16
          local.get $var14
          i32.const 0
          i32.store offset=8
          local.get $var14
          i32.const 0
          i32.store offset=4
          i32.const 0
          local.set $var25
          block $label3
            local.get $var15
            i32.const 2
            i32.ne
            br_if $label3
            i32.const 0
            local.set $var25
            local.get $var0
            local.get $var2
            i32.add
            local.tee $var26
            i32.load8_u
            i32.const 34
            i32.ne
            br_if $label3
            local.get $var26
            i32.const 1
            i32.add
            i32.load8_u
            i32.const 34
            i32.eq
            local.set $var25
          end $label3
          block $label4
            local.get $var25
            br_if $label4
            local.get $var24
            local.get $var15
            i32.ne
            br_if $label4
            local.get $var24
            i32.const -1
            i32.add
            local.set $var26
            i32.const 0
            local.set $var15
            local.get $var0
            local.get $var1
            i32.add
            local.tee $var27
            local.set $var1
            local.get $var0
            local.get $var2
            i32.add
            local.tee $var28
            local.set $var2
            block $label6
              loop $label7
                block $label5
                  local.get $var15
                  i32.const 8
                  i32.add
                  local.tee $var29
                  local.get $var24
                  i32.le_u
                  br_if $label5
                  local.get $var15
                  local.get $var24
                  i32.lt_u
                  br_if $label6
                  i32.const 1
                  local.set $var25
                  br $label4
                end $label5
                local.get $var28
                local.get $var15
                i32.add
                local.set $var30
                local.get $var27
                local.get $var15
                i32.add
                local.set $var31
                local.get $var1
                i32.const 8
                i32.add
                local.set $var1
                local.get $var2
                i32.const 8
                i32.add
                local.set $var2
                local.get $var26
                i32.const -8
                i32.add
                local.set $var26
                local.get $var29
                local.set $var15
                local.get $var31
                i64.load align=1
                local.get $var30
                i64.load align=1
                i64.eq
                br_if $label7
              end $label7
              i32.const 0
              local.set $var25
              br $label4
            end $label6
            loop $label8
              local.get $var1
              i32.load8_u
              local.tee $var15
              local.get $var2
              i32.load8_u
              local.tee $var29
              i32.eq
              local.set $var25
              local.get $var15
              local.get $var29
              i32.ne
              br_if $label4
              local.get $var26
              i32.const 0
              i32.ne
              local.set $var15
              local.get $var1
              i32.const 1
              i32.add
              local.set $var1
              local.get $var2
              i32.const 1
              i32.add
              local.set $var2
              local.get $var26
              i32.const -1
              i32.add
              local.set $var26
              local.get $var15
              br_if $label8
            end $label8
          end $label4
          local.get $var14
          i32.const 28
          i32.add
          local.set $var1
          local.get $var14
          i32.const 20
          i32.add
          local.set $var26
          local.get $var14
          i32.const 8
          i32.add
          local.set $var32
          i32.const 1
          local.set $var33
          i32.const 0
          local.set $var15
          block $label10
            loop $label27
              block $label9
                local.get $var25
                local.get $var15
                i32.and
                i32.const 1
                i32.ne
                br_if $label9
                local.get $var14
                local.get $var14
                i32.load offset=8
                i32.store offset=4
                br $label10
              end $label9
              local.get $var1
              i32.load
              local.set $var2
              block $label14
                block $label12
                  block $label11
                    local.get $var26
                    i32.load
                    local.tee $var26
                    i32.const 2
                    i32.lt_u
                    br_if $label11
                    local.get $var0
                    local.get $var2
                    i32.add
                    i32.load8_u
                    i32.const 34
                    i32.ne
                    br_if $label11
                    local.get $var0
                    local.get $var2
                    local.get $var26
                    i32.add
                    i32.const -1
                    i32.add
                    local.tee $var29
                    i32.add
                    i32.load8_u
                    i32.const 34
                    i32.ne
                    br_if $label11
                    local.get $var26
                    i32.const -2
                    i32.add
                    local.set $var30
                    local.get $var2
                    i32.const 1
                    i32.add
                    local.set $var31
                    local.get $var2
                    i32.const 1
                    i32.add
                    local.set $var15
                    loop $label13
                      local.get $var15
                      local.get $var29
                      i32.ge_u
                      br_if $label12
                      local.get $var0
                      local.get $var15
                      i32.add
                      local.set $var1
                      local.get $var15
                      i32.const 1
                      i32.add
                      local.set $var15
                      local.get $var1
                      i32.load8_u
                      i32.const 92
                      i32.ne
                      br_if $label13
                    end $label13
                  end $label11
                  local.get $var19
                  local.set $var31
                  local.get $var4
                  local.set $var34
                  local.get $var0
                  local.get $var2
                  i32.add
                  local.get $var26
                  local.get $var4
                  local.get $var19
                  i32.add
                  local.get $var5
                  local.get $var19
                  i32.sub
                  call $func29
                  local.tee $var30
                  i32.const 65536
                  i32.lt_u
                  br_if $label14
                  i32.const -4
                  local.set $var15
                  br $label0
                end $label12
                local.get $var0
                local.set $var34
                local.get $var30
                i32.const 65535
                i32.le_u
                br_if $label14
                i32.const -5
                local.set $var15
                br $label0
              end $label14
              local.get $var34
              local.get $var31
              i32.add
              local.tee $var35
              local.get $var30
              i32.const -2128831035
              call $func30
              local.tee $var36
              local.get $var30
              i32.const -2048144789
              i32.mul
              i32.xor
              local.tee $var15
              i32.const 16
              i32.shr_u
              local.get $var15
              i32.xor
              local.get $var18
              i32.and
              local.set $var27
              i32.const 0
              local.set $var37
              block $label21
                block $label15
                  loop $label25
                    local.get $var11
                    local.get $var27
                    i32.const 2
                    i32.shl
                    i32.add
                    i32.load
                    local.tee $var15
                    i32.eqz
                    br_if $label15
                    block $label16
                      local.get $var15
                      i32.const -1
                      i32.add
                      local.tee $var28
                      local.get $var20
                      i32.lt_u
                      br_if $label16
                      i32.const -3
                      local.set $var15
                      br $label0
                    end $label16
                    block $label17
                      local.get $var8
                      local.get $var28
                      i32.const 2
                      i32.shl
                      local.tee $var15
                      i32.add
                      i32.load
                      local.get $var36
                      i32.ne
                      br_if $label17
                      local.get $var30
                      local.get $var6
                      local.get $var28
                      i32.const 1
                      i32.shl
                      i32.add
                      i32.load16_u
                      i32.ne
                      br_if $label17
                      i32.const 0
                      local.set $var2
                      local.get $var4
                      local.get $var7
                      local.get $var15
                      i32.add
                      i32.load
                      i32.add
                      local.tee $var38
                      local.set $var15
                      local.get $var35
                      local.set $var1
                      loop $label24
                        block $label18
                          local.get $var30
                          local.get $var2
                          i32.add
                          i32.const 31
                          i32.gt_u
                          br_if $label18
                          i32.const 0
                          local.set $var26
                          local.get $var30
                          local.set $var29
                          block $label20
                            loop $label22
                              block $label19
                                local.get $var2
                                local.get $var29
                                i32.add
                                i32.const 7
                                i32.gt_u
                                br_if $label19
                                local.get $var26
                                local.get $var2
                                i32.sub
                                local.tee $var15
                                local.get $var30
                                i32.lt_u
                                br_if $label20
                                br $label21
                              end $label19
                              local.get $var1
                              local.get $var26
                              i32.add
                              local.set $var31
                              local.get $var15
                              local.get $var26
                              i32.add
                              local.set $var24
                              local.get $var29
                              i32.const -8
                              i32.add
                              local.set $var29
                              local.get $var26
                              i32.const 8
                              i32.add
                              local.set $var26
                              local.get $var24
                              i64.load align=1
                              local.get $var31
                              i64.load align=1
                              i64.eq
                              br_if $label22
                              br $label17
                            end $label22
                          end $label20
                          loop $label23
                            local.get $var38
                            local.get $var15
                            i32.add
                            i32.load8_u
                            local.get $var35
                            local.get $var15
                            i32.add
                            i32.load8_u
                            i32.ne
                            br_if $label17
                            local.get $var15
                            i32.const 1
                            i32.add
                            local.tee $var15
                            local.get $var30
                            i32.ge_u
                            br_if $label21
                            br $label23
                          end $label23
                        end $label18
                        local.get $var15
                        i32.const 16
                        i32.add
                        local.set $var26
                        local.get $var1
                        i32.const 16
                        i32.add
                        local.set $var29
                        local.get $var15
                        v128.load align=1
                        local.set $var16
                        local.get $var1
                        v128.load align=1
                        local.set $var17
                        local.get $var15
                        i32.const 32
                        i32.add
                        local.set $var15
                        local.get $var1
                        i32.const 32
                        i32.add
                        local.set $var1
                        local.get $var2
                        i32.const -32
                        i32.add
                        local.set $var2
                        local.get $var29
                        v128.load align=1
                        local.get $var26
                        v128.load align=1
                        v128.xor
                        local.get $var17
                        local.get $var16
                        v128.xor
                        v128.or
                        v128.any_true
                        i32.eqz
                        br_if $label24
                      end $label24
                    end $label17
                    local.get $var27
                    i32.const 1
                    i32.add
                    local.get $var18
                    i32.and
                    local.set $var27
                    local.get $var37
                    i32.const 1
                    i32.add
                    local.tee $var37
                    local.get $var12
                    i32.ne
                    br_if $label25
                  end $label25
                end $label15
                i32.const -2
                local.set $var15
                local.get $var20
                local.get $var21
                i32.ge_u
                br_if $label0
                local.get $var11
                local.get $var27
                i32.const 2
                i32.shl
                i32.add
                local.tee $var1
                i32.load
                br_if $label0
                local.get $var30
                local.get $var19
                i32.add
                local.tee $var2
                local.get $var5
                i32.gt_u
                br_if $label0
                block $label26
                  local.get $var34
                  local.get $var4
                  i32.eq
                  br_if $label26
                  local.get $var4
                  local.get $var19
                  i32.add
                  local.get $var35
                  local.get $var30
                  call $func31
                  br_if $label26
                  i32.const -4
                  local.set $var15
                  br $label0
                end $label26
                local.get $var7
                local.get $var20
                i32.const 2
                i32.shl
                local.tee $var15
                i32.add
                local.get $var19
                i32.store
                local.get $var8
                local.get $var15
                i32.add
                local.get $var36
                i32.store
                local.get $var6
                local.get $var20
                i32.const 1
                i32.shl
                i32.add
                local.get $var30
                i32.store16
                local.get $var1
                local.get $var20
                i32.const 1
                i32.add
                local.tee $var15
                i32.store
                local.get $var20
                local.set $var28
                local.get $var2
                local.set $var19
                local.get $var15
                local.set $var20
              end $label21
              local.get $var32
              local.get $var28
              i32.store
              i32.const 1
              local.set $var15
              local.get $var33
              i32.const 1
              i32.and
              local.set $var2
              local.get $var14
              i32.const 24
              i32.add
              local.set $var1
              local.get $var14
              i32.const 16
              i32.add
              local.set $var26
              local.get $var14
              i32.const 4
              i32.add
              local.set $var32
              i32.const 0
              local.set $var33
              local.get $var2
              br_if $label27
            end $label27
          end $label10
          local.get $var9
          local.get $var23
          i32.const 2
          i32.shl
          local.tee $var15
          i32.add
          local.get $var14
          i32.load offset=8
          i32.store
          local.get $var10
          local.get $var15
          i32.add
          local.get $var14
          i32.load offset=4
          i32.store
          local.get $var23
          i32.const 1
          i32.add
          local.tee $var23
          local.get $var3
          i32.ne
          br_if $label28
        end $label28
      end $label2
      local.get $var13
      local.get $var20
      i32.store
      local.get $var19
      local.set $var15
    end $label0
    local.get $var14
    i32.const 32
    i32.add
    global.set $global0
    local.get $var15
  )
  (func $func29 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (result i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    i32.const -1
    local.set $var4
    block $label0
      local.get $var1
      i32.const 2
      i32.lt_u
      br_if $label0
      local.get $var0
      i32.load8_u
      i32.const 34
      i32.ne
      br_if $label0
      i32.const -1
      local.set $var4
      local.get $var0
      local.get $var1
      i32.const -1
      i32.add
      local.tee $var5
      i32.add
      i32.load8_u
      i32.const 34
      i32.ne
      br_if $label0
      i32.const 0
      local.set $var4
      local.get $var5
      i32.const 2
      i32.lt_u
      br_if $label0
      local.get $var3
      i32.const 65535
      local.get $var3
      i32.const 65535
      i32.lt_u
      select
      local.set $var6
      local.get $var0
      i32.const 3
      i32.add
      local.set $var7
      local.get $var0
      i32.const 2
      i32.add
      local.set $var8
      local.get $var2
      i32.const 1
      i32.add
      local.set $var9
      i32.const 0
      local.set $var4
      i32.const 1
      local.set $var1
      loop $label41
        local.get $var4
        local.set $var10
        local.get $var1
        i32.const 1
        i32.add
        local.set $var11
        block $label12
          block $label1
            local.get $var0
            local.get $var1
            i32.add
            local.tee $var12
            i32.load8_u
            local.tee $var3
            i32.const 92
            i32.eq
            br_if $label1
            i32.const -1
            local.set $var4
            local.get $var3
            i32.const 32
            i32.lt_u
            br_if $label0
            local.get $var3
            i32.const 34
            i32.eq
            br_if $label0
            block $label11
              block $label10
                block $label2
                  local.get $var3
                  i32.extend8_s
                  i32.const -1
                  i32.gt_s
                  br_if $label2
                  i32.const 0
                  local.set $var13
                  block $label4
                    block $label3
                      local.get $var3
                      i32.const 62
                      i32.add
                      i32.const 255
                      i32.and
                      i32.const 30
                      i32.lt_u
                      local.tee $var14
                      i32.eqz
                      br_if $label3
                      i32.const 2
                      local.set $var15
                      br $label4
                    end $label3
                    block $label5
                      local.get $var3
                      i32.const 240
                      i32.and
                      i32.const 224
                      i32.ne
                      br_if $label5
                      i32.const 3
                      local.set $var15
                      i32.const 1
                      local.set $var13
                      br $label4
                    end $label5
                    i32.const 4
                    local.set $var15
                    local.get $var3
                    i32.const 16
                    i32.add
                    i32.const 255
                    i32.and
                    i32.const 4
                    i32.gt_u
                    br_if $label0
                  end $label4
                  i32.const -1
                  local.set $var4
                  local.get $var15
                  i32.const -1
                  i32.add
                  local.tee $var12
                  local.get $var5
                  local.get $var11
                  i32.sub
                  i32.gt_u
                  br_if $label0
                  local.get $var0
                  local.get $var11
                  i32.add
                  local.tee $var11
                  i32.load8_u
                  local.set $var16
                  block $label6
                    local.get $var3
                    i32.const 224
                    i32.ne
                    br_if $label6
                    local.get $var16
                    i32.const 255
                    i32.and
                    i32.const 160
                    i32.lt_u
                    br_if $label0
                  end $label6
                  block $label7
                    local.get $var3
                    i32.const 237
                    i32.ne
                    br_if $label7
                    local.get $var16
                    i32.const 255
                    i32.and
                    i32.const 159
                    i32.gt_u
                    br_if $label0
                  end $label7
                  block $label8
                    local.get $var3
                    i32.const 240
                    i32.ne
                    br_if $label8
                    local.get $var16
                    i32.const 255
                    i32.and
                    i32.const 144
                    i32.lt_u
                    br_if $label0
                  end $label8
                  block $label9
                    local.get $var3
                    i32.const 244
                    i32.ne
                    br_if $label9
                    local.get $var16
                    i32.const 255
                    i32.and
                    i32.const 143
                    i32.gt_u
                    br_if $label0
                  end $label9
                  local.get $var11
                  i32.load8_s
                  i32.const -64
                  i32.ge_s
                  br_if $label0
                  local.get $var12
                  i32.const 1
                  i32.eq
                  br_if $label10
                  local.get $var11
                  i32.const 1
                  i32.add
                  i32.load8_s
                  i32.const -65
                  i32.gt_s
                  br_if $label0
                  local.get $var12
                  i32.const 2
                  i32.eq
                  br_if $label10
                  local.get $var11
                  i32.const 2
                  i32.add
                  i32.load8_s
                  i32.const -65
                  i32.gt_s
                  br_if $label0
                  local.get $var15
                  local.get $var6
                  local.get $var10
                  i32.sub
                  i32.le_u
                  br_if $label11
                  br $label0
                end $label2
                local.get $var6
                local.get $var10
                i32.eq
                br_if $label0
                local.get $var2
                local.get $var10
                i32.add
                local.get $var3
                i32.store8
                local.get $var10
                i32.const 1
                i32.add
                local.set $var4
                local.get $var11
                local.set $var1
                br $label12
              end $label10
              local.get $var15
              local.get $var6
              local.get $var10
              i32.sub
              i32.gt_u
              br_if $label0
            end $label11
            local.get $var2
            local.get $var10
            i32.add
            local.get $var3
            i32.store8
            local.get $var9
            local.get $var10
            i32.add
            local.get $var11
            i32.load8_u
            i32.store8
            local.get $var10
            i32.const 2
            i32.add
            local.set $var4
            local.get $var15
            local.get $var1
            i32.add
            local.set $var3
            block $label13
              local.get $var14
              i32.eqz
              br_if $label13
              local.get $var3
              local.set $var1
              br $label12
            end $label13
            local.get $var2
            local.get $var4
            i32.add
            local.get $var8
            local.get $var1
            i32.add
            i32.load8_u
            i32.store8
            local.get $var10
            i32.const 3
            i32.add
            local.set $var4
            block $label14
              local.get $var13
              i32.eqz
              br_if $label14
              local.get $var3
              local.set $var1
              br $label12
            end $label14
            local.get $var2
            local.get $var4
            i32.add
            local.get $var7
            local.get $var1
            i32.add
            i32.load8_u
            i32.store8
            local.get $var10
            i32.const 4
            i32.add
            local.set $var4
            local.get $var3
            local.set $var1
            br $label12
          end $label1
          i32.const -1
          local.set $var4
          local.get $var5
          local.get $var11
          i32.le_u
          br_if $label0
          local.get $var1
          i32.const 2
          i32.add
          local.set $var16
          i32.const 1
          local.set $var15
          block $label15
            block $label21
              block $label20
                block $label19
                  block $label18
                    block $label17
                      block $label16
                        local.get $var0
                        local.get $var11
                        i32.add
                        i32.load8_u
                        local.tee $var11
                        i32.const -34
                        i32.add
                        br_table $label15 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label15 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label15 $label0 $label0 $label0 $label0 $label0 $label16 $label0 $label0 $label0 $label17 $label0 $label0 $label0 $label0 $label0 $label0 $label0 $label18 $label0 $label0 $label0 $label19 $label0 $label20 $label21 $label0
                      end $label16
                      i32.const 8
                      local.set $var11
                      br $label15
                    end $label17
                    i32.const 12
                    local.set $var11
                    br $label15
                  end $label18
                  i32.const 10
                  local.set $var11
                  br $label15
                end $label19
                i32.const 13
                local.set $var11
                br $label15
              end $label20
              i32.const 9
              local.set $var11
              br $label15
            end $label21
            local.get $var5
            local.get $var16
            i32.sub
            i32.const 4
            i32.lt_u
            br_if $label0
            i32.const -48
            local.set $var17
            i32.const -48
            local.set $var13
            block $label22
              local.get $var0
              local.get $var16
              i32.add
              local.tee $var3
              i32.load8_u
              local.tee $var11
              i32.const -48
              i32.add
              i32.const 255
              i32.and
              i32.const 10
              i32.lt_u
              br_if $label22
              block $label23
                local.get $var11
                i32.const -97
                i32.add
                i32.const 255
                i32.and
                i32.const 6
                i32.ge_u
                br_if $label23
                i32.const -87
                local.set $var13
                br $label22
              end $label23
              local.get $var11
              i32.const -65
              i32.add
              i32.const 255
              i32.and
              i32.const 5
              i32.gt_u
              br_if $label0
              i32.const -55
              local.set $var13
            end $label22
            block $label24
              local.get $var3
              i32.load8_u offset=1
              local.tee $var16
              i32.const -48
              i32.add
              i32.const 255
              i32.and
              i32.const 10
              i32.lt_u
              br_if $label24
              block $label25
                local.get $var16
                i32.const -97
                i32.add
                i32.const 255
                i32.and
                i32.const 6
                i32.ge_u
                br_if $label25
                i32.const -87
                local.set $var17
                br $label24
              end $label25
              local.get $var16
              i32.const -65
              i32.add
              i32.const 255
              i32.and
              i32.const 5
              i32.gt_u
              br_if $label0
              i32.const -55
              local.set $var17
            end $label24
            i32.const -48
            local.set $var18
            i32.const -48
            local.set $var19
            block $label26
              local.get $var3
              i32.load8_u offset=2
              local.tee $var14
              i32.const -48
              i32.add
              i32.const 255
              i32.and
              i32.const 10
              i32.lt_u
              br_if $label26
              block $label27
                local.get $var14
                i32.const -97
                i32.add
                i32.const 255
                i32.and
                i32.const 6
                i32.ge_u
                br_if $label27
                i32.const -87
                local.set $var19
                br $label26
              end $label27
              local.get $var14
              i32.const -65
              i32.add
              i32.const 255
              i32.and
              i32.const 5
              i32.gt_u
              br_if $label0
              i32.const -55
              local.set $var19
            end $label26
            block $label28
              local.get $var3
              i32.load8_u offset=3
              local.tee $var3
              i32.const -48
              i32.add
              i32.const 255
              i32.and
              i32.const 10
              i32.lt_u
              br_if $label28
              block $label29
                local.get $var3
                i32.const -97
                i32.add
                i32.const 255
                i32.and
                i32.const 6
                i32.ge_u
                br_if $label29
                i32.const -87
                local.set $var18
                br $label28
              end $label29
              local.get $var3
              i32.const -65
              i32.add
              i32.const 255
              i32.and
              i32.const 5
              i32.gt_u
              br_if $label0
              i32.const -55
              local.set $var18
            end $label28
            i32.const -1
            local.set $var4
            local.get $var18
            local.get $var3
            i32.add
            local.get $var17
            local.get $var16
            i32.add
            i32.const 4
            i32.shl
            local.get $var13
            local.get $var11
            i32.add
            i32.const 8
            i32.shl
            i32.or
            local.get $var19
            local.get $var14
            i32.add
            i32.or
            i32.const 4
            i32.shl
            i32.or
            local.tee $var3
            i32.const -1
            i32.eq
            br_if $label0
            local.get $var1
            i32.const 6
            i32.add
            local.set $var16
            i32.const 65533
            local.set $var11
            block $label30
              local.get $var3
              i32.const -1024
              i32.and
              local.tee $var4
              i32.const 56320
              i32.ne
              br_if $label30
              i32.const 3
              local.set $var15
              br $label15
            end $label30
            block $label31
              local.get $var4
              i32.const 55296
              i32.ne
              br_if $label31
              block $label32
                local.get $var5
                local.get $var16
                i32.sub
                i32.const 6
                i32.ge_u
                br_if $label32
                i32.const 3
                local.set $var15
                br $label15
              end $label32
              block $label33
                local.get $var0
                local.get $var16
                i32.add
                local.tee $var4
                i32.load8_u
                i32.const 92
                i32.eq
                br_if $label33
                i32.const 3
                local.set $var15
                br $label15
              end $label33
              block $label34
                local.get $var12
                i32.const 7
                i32.add
                i32.load8_u
                i32.const 117
                i32.eq
                br_if $label34
                i32.const 3
                local.set $var15
                br $label15
              end $label34
              i32.const 3
              local.set $var15
              local.get $var4
              i32.const 2
              i32.add
              call $func33
              local.tee $var4
              i32.const -1024
              i32.and
              i32.const 56320
              i32.ne
              br_if $label15
              local.get $var1
              i32.const 12
              i32.add
              local.set $var16
              local.get $var3
              i32.const 10
              i32.shl
              local.get $var4
              i32.add
              i32.const -56613888
              i32.add
              local.set $var11
              i32.const 4
              local.set $var15
              br $label15
            end $label31
            block $label35
              local.get $var3
              i32.const 128
              i32.lt_u
              br_if $label35
              i32.const 2
              local.set $var15
              local.get $var3
              i32.const 2048
              i32.lt_u
              br_if $label35
              i32.const 3
              i32.const 4
              local.get $var3
              i32.const 65536
              i32.lt_u
              select
              local.set $var15
            end $label35
            local.get $var3
            local.set $var11
          end $label15
          i32.const -1
          local.set $var4
          local.get $var15
          local.get $var6
          local.get $var10
          i32.sub
          i32.gt_u
          br_if $label0
          i32.const 192
          local.set $var4
          block $label39
            block $label37
              block $label38
                block $label36
                  local.get $var15
                  i32.const -1
                  i32.add
                  local.tee $var3
                  br_table $label36 $label37 $label38
                end $label36
                local.get $var2
                local.get $var10
                i32.add
                local.get $var11
                i32.store8
                local.get $var10
                i32.const 1
                i32.add
                local.set $var4
                br $label39
              end $label38
              i32.const 224
              i32.const 240
              local.get $var15
              i32.const 3
              i32.eq
              select
              local.set $var4
            end $label37
            local.get $var2
            local.get $var10
            i32.add
            local.get $var4
            local.get $var11
            local.get $var15
            i32.const 6
            i32.mul
            local.tee $var1
            i32.const -6
            i32.add
            i32.shr_u
            i32.or
            i32.store8
            local.get $var10
            i32.const 1
            i32.add
            local.set $var4
            local.get $var1
            i32.const -12
            i32.add
            local.set $var1
            loop $label40
              local.get $var2
              local.get $var4
              i32.add
              local.get $var11
              local.get $var1
              i32.shr_u
              i32.const 63
              i32.and
              i32.const 128
              i32.or
              i32.store8
              local.get $var1
              i32.const -6
              i32.add
              local.set $var1
              local.get $var4
              i32.const 1
              i32.add
              local.set $var4
              local.get $var3
              i32.const -1
              i32.add
              local.tee $var3
              br_if $label40
            end $label40
          end $label39
          local.get $var16
          local.set $var1
        end $label12
        local.get $var1
        local.get $var5
        i32.lt_u
        br_if $label41
      end $label41
    end $label0
    local.get $var4
  )
  (func $func30 (param $var0 i32) (param $var1 i32) (param $var2 i32) (result i32)
    (local $var3 i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    local.get $var0
    local.get $var1
    i32.add
    local.set $var3
    block $label2
      block $label0
        local.get $var1
        i32.const 16
        i32.lt_u
        br_if $label0
        local.get $var2
        i32.const 1640531535
        i32.add
        local.set $var4
        local.get $var2
        i32.const -2048144777
        i32.add
        local.set $var5
        local.get $var2
        i32.const 606290984
        i32.add
        local.set $var6
        local.get $var3
        i32.const -16
        i32.add
        local.set $var7
        loop $label1
          local.get $var0
          i32.load align=1
          i32.const -2048144777
          i32.mul
          local.get $var6
          i32.add
          i32.const 13
          i32.rotl
          i32.const -1640531535
          i32.mul
          local.set $var6
          local.get $var0
          i32.const 12
          i32.add
          i32.load align=1
          i32.const -2048144777
          i32.mul
          local.get $var4
          i32.add
          i32.const 13
          i32.rotl
          i32.const -1640531535
          i32.mul
          local.set $var4
          local.get $var0
          i32.const 8
          i32.add
          i32.load align=1
          i32.const -2048144777
          i32.mul
          local.get $var2
          i32.add
          i32.const 13
          i32.rotl
          i32.const -1640531535
          i32.mul
          local.set $var2
          local.get $var0
          i32.const 4
          i32.add
          i32.load align=1
          i32.const -2048144777
          i32.mul
          local.get $var5
          i32.add
          i32.const 13
          i32.rotl
          i32.const -1640531535
          i32.mul
          local.set $var5
          local.get $var0
          i32.const 16
          i32.add
          local.tee $var0
          local.get $var7
          i32.le_u
          br_if $label1
        end $label1
        local.get $var5
        i32.const 7
        i32.rotl
        local.get $var6
        i32.const 1
        i32.rotl
        i32.add
        local.get $var2
        i32.const 12
        i32.rotl
        i32.add
        local.get $var4
        i32.const 18
        i32.rotl
        i32.add
        local.set $var2
        br $label2
      end $label0
      local.get $var2
      i32.const 374761393
      i32.add
      local.set $var2
    end $label2
    local.get $var2
    local.get $var1
    i32.add
    local.set $var2
    block $label4
      block $label3
        local.get $var0
        i32.const 4
        i32.add
        local.get $var3
        i32.le_u
        br_if $label3
        local.get $var0
        local.set $var4
        br $label4
      end $label3
      loop $label5
        local.get $var0
        i32.load align=1
        i32.const -1028477379
        i32.mul
        local.get $var2
        i32.add
        i32.const 17
        i32.rotl
        i32.const 668265263
        i32.mul
        local.set $var2
        local.get $var0
        i32.const 8
        i32.add
        local.set $var5
        local.get $var0
        i32.const 4
        i32.add
        local.tee $var4
        local.set $var0
        local.get $var5
        local.get $var3
        i32.le_u
        br_if $label5
      end $label5
    end $label4
    block $label6
      local.get $var4
      local.get $var3
      i32.ge_u
      br_if $label6
      local.get $var4
      i32.const 1
      i32.add
      local.set $var0
      block $label7
        local.get $var3
        local.get $var4
        i32.sub
        i32.const 1
        i32.and
        i32.eqz
        br_if $label7
        local.get $var4
        i32.load8_u
        i32.const 374761393
        i32.mul
        local.get $var2
        i32.add
        i32.const 11
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var2
        local.get $var0
        local.set $var4
      end $label7
      local.get $var3
      local.get $var0
      i32.eq
      br_if $label6
      loop $label8
        local.get $var4
        i32.const 1
        i32.add
        i32.load8_u
        i32.const 374761393
        i32.mul
        local.get $var4
        i32.load8_u
        i32.const 374761393
        i32.mul
        local.get $var2
        i32.add
        i32.const 11
        i32.rotl
        i32.const -1640531535
        i32.mul
        i32.add
        i32.const 11
        i32.rotl
        i32.const -1640531535
        i32.mul
        local.set $var2
        local.get $var4
        i32.const 2
        i32.add
        local.tee $var4
        local.get $var3
        i32.ne
        br_if $label8
      end $label8
    end $label6
    local.get $var2
    i32.const 15
    i32.shr_u
    local.get $var2
    i32.xor
    i32.const -2048144777
    i32.mul
    local.tee $var0
    i32.const 13
    i32.shr_u
    local.get $var0
    i32.xor
    i32.const -1028477379
    i32.mul
    local.tee $var0
    i32.const 16
    i32.shr_u
    local.get $var0
    i32.xor
  )
  (func $func31 (param $var0 i32) (param $var1 i32) (param $var2 i32) (result i32)
    (local $var3 i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    block $label4
      block $label0
        local.get $var2
        i32.eqz
        br_if $label0
        i32.const 0
        local.set $var3
        loop $label11
          local.get $var0
          local.get $var3
          i32.add
          local.get $var1
          local.get $var3
          i32.add
          i32.load8_s
          local.tee $var4
          i32.store8
          local.get $var3
          i32.const 1
          i32.add
          local.set $var5
          block $label2
            block $label1
              local.get $var4
              i32.const -1
              i32.le_s
              br_if $label1
              local.get $var5
              local.set $var3
              br $label2
            end $label1
            block $label8
              block $label6
                block $label3
                  local.get $var4
                  i32.const -16
                  i32.and
                  i32.const -32
                  i32.ne
                  br_if $label3
                  i32.const 0
                  local.set $var6
                  local.get $var2
                  local.get $var5
                  i32.sub
                  i32.const 2
                  i32.lt_u
                  br_if $label4
                  local.get $var1
                  local.get $var5
                  i32.add
                  i32.load8_s
                  local.tee $var7
                  i32.const -65
                  i32.gt_s
                  br_if $label4
                  local.get $var1
                  local.get $var3
                  i32.const 2
                  i32.add
                  local.tee $var8
                  i32.add
                  i32.load8_s
                  local.tee $var9
                  i32.const -65
                  i32.gt_s
                  br_if $label4
                  block $label5
                    local.get $var4
                    i32.const -32
                    i32.ne
                    br_if $label5
                    local.get $var7
                    i32.const -96
                    i32.lt_u
                    br_if $label4
                  end $label5
                  i32.const 3
                  local.set $var10
                  local.get $var4
                  i32.const -19
                  i32.ne
                  br_if $label6
                  local.get $var7
                  i32.const -97
                  i32.le_u
                  br_if $label6
                  br $label4
                end $label3
                block $label7
                  local.get $var4
                  i32.const 62
                  i32.add
                  i32.const 255
                  i32.and
                  i32.const 29
                  i32.gt_u
                  br_if $label7
                  i32.const 0
                  local.set $var6
                  local.get $var2
                  local.get $var5
                  i32.le_u
                  br_if $label4
                  i32.const 2
                  local.set $var10
                  local.get $var5
                  local.set $var8
                  local.get $var1
                  local.get $var5
                  i32.add
                  i32.load8_s
                  local.tee $var9
                  i32.const -64
                  i32.lt_s
                  br_if $label8
                  br $label4
                end $label7
                i32.const 0
                local.set $var6
                local.get $var4
                i32.const 11
                i32.add
                i32.const 255
                i32.and
                i32.const 251
                i32.lt_u
                br_if $label4
                local.get $var2
                local.get $var5
                i32.sub
                i32.const 3
                i32.lt_u
                br_if $label4
                local.get $var1
                local.get $var5
                i32.add
                i32.load8_s
                local.tee $var10
                i32.const -65
                i32.gt_s
                br_if $label4
                local.get $var1
                local.get $var3
                i32.const 2
                i32.add
                local.tee $var11
                i32.add
                i32.load8_s
                local.tee $var7
                i32.const -65
                i32.gt_s
                br_if $label4
                local.get $var1
                local.get $var3
                i32.const 3
                i32.add
                local.tee $var8
                i32.add
                i32.load8_s
                local.tee $var9
                i32.const -65
                i32.gt_s
                br_if $label4
                block $label9
                  local.get $var4
                  i32.const -16
                  i32.ne
                  br_if $label9
                  local.get $var10
                  i32.const -112
                  i32.lt_u
                  br_if $label4
                end $label9
                block $label10
                  local.get $var4
                  i32.const -12
                  i32.ne
                  br_if $label10
                  local.get $var10
                  i32.const -113
                  i32.gt_u
                  br_if $label4
                end $label10
                local.get $var0
                local.get $var5
                i32.add
                local.get $var10
                i32.store8
                i32.const 4
                local.set $var10
                local.get $var11
                local.set $var5
              end $label6
              local.get $var0
              local.get $var5
              i32.add
              local.get $var7
              i32.store8
            end $label8
            local.get $var0
            local.get $var8
            i32.add
            local.get $var9
            i32.store8
            local.get $var3
            local.get $var10
            i32.add
            local.set $var3
          end $label2
          local.get $var3
          local.get $var2
          i32.lt_u
          br_if $label11
        end $label11
      end $label0
      i32.const 1
      local.set $var6
    end $label4
    local.get $var6
  )
  (func $func32 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (result i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 i32)
    local.get $var0
    local.get $var2
    i32.add
    local.set $var4
    local.get $var0
    local.get $var1
    i32.add
    local.set $var5
    i32.const 0
    local.set $var0
    block $label5
      block $label4
        block $label2
          loop $label3
            block $label0
              local.get $var0
              i32.const 8
              i32.add
              local.tee $var2
              local.get $var3
              i32.le_u
              br_if $label0
              block $label1
                local.get $var3
                local.get $var0
                i32.gt_u
                br_if $label1
                i32.const 1
                return
              end $label1
              local.get $var3
              local.get $var0
              i32.sub
              local.set $var1
              local.get $var5
              local.get $var0
              i32.add
              local.set $var2
              local.get $var4
              local.get $var0
              i32.add
              local.set $var0
              br $label2
            end $label0
            local.get $var4
            local.get $var0
            i32.add
            local.set $var1
            local.get $var5
            local.get $var0
            i32.add
            local.set $var6
            local.get $var2
            local.set $var0
            local.get $var6
            i64.load align=1
            local.get $var1
            i64.load align=1
            i64.eq
            br_if $label3
            br $label4
          end $label3
        end $label2
        loop $label6
          local.get $var2
          i32.load8_u
          local.get $var0
          i32.load8_u
          i32.ne
          br_if $label4
          i32.const 1
          local.set $var6
          local.get $var0
          i32.const 1
          i32.add
          local.set $var0
          local.get $var2
          i32.const 1
          i32.add
          local.set $var2
          local.get $var1
          i32.const -1
          i32.add
          local.tee $var1
          i32.eqz
          br_if $label5
          br $label6
        end $label6
      end $label4
      i32.const 0
      local.set $var6
    end $label5
    local.get $var6
  )
  (func $func33 (param $var0 i32) (result i32)
    (local $var1 i32)
    (local $var2 i32)
    (local $var3 i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    i32.const -48
    local.set $var1
    i32.const -48
    local.set $var2
    block $label0
      local.get $var0
      i32.load8_u
      local.tee $var3
      i32.const -48
      i32.add
      i32.const 255
      i32.and
      i32.const 10
      i32.lt_u
      br_if $label0
      block $label1
        local.get $var3
        i32.const -97
        i32.add
        i32.const 255
        i32.and
        i32.const 6
        i32.ge_u
        br_if $label1
        i32.const -87
        local.set $var2
        br $label0
      end $label1
      block $label2
        local.get $var3
        i32.const -65
        i32.add
        i32.const 255
        i32.and
        i32.const 5
        i32.le_u
        br_if $label2
        i32.const -1
        return
      end $label2
      i32.const -55
      local.set $var2
    end $label0
    block $label3
      local.get $var0
      i32.load8_u offset=1
      local.tee $var4
      i32.const -48
      i32.add
      i32.const 255
      i32.and
      i32.const 10
      i32.lt_u
      br_if $label3
      block $label4
        local.get $var4
        i32.const -97
        i32.add
        i32.const 255
        i32.and
        i32.const 6
        i32.ge_u
        br_if $label4
        i32.const -87
        local.set $var1
        br $label3
      end $label4
      block $label5
        local.get $var4
        i32.const -65
        i32.add
        i32.const 255
        i32.and
        i32.const 5
        i32.le_u
        br_if $label5
        i32.const -1
        return
      end $label5
      i32.const -55
      local.set $var1
    end $label3
    i32.const -48
    local.set $var5
    i32.const -48
    local.set $var6
    block $label6
      local.get $var0
      i32.load8_u offset=2
      local.tee $var7
      i32.const -48
      i32.add
      i32.const 255
      i32.and
      i32.const 10
      i32.lt_u
      br_if $label6
      block $label7
        local.get $var7
        i32.const -97
        i32.add
        i32.const 255
        i32.and
        i32.const 6
        i32.ge_u
        br_if $label7
        i32.const -87
        local.set $var6
        br $label6
      end $label7
      block $label8
        local.get $var7
        i32.const -65
        i32.add
        i32.const 255
        i32.and
        i32.const 5
        i32.le_u
        br_if $label8
        i32.const -1
        return
      end $label8
      i32.const -55
      local.set $var6
    end $label6
    block $label9
      local.get $var0
      i32.load8_u offset=3
      local.tee $var0
      i32.const -48
      i32.add
      i32.const 255
      i32.and
      i32.const 10
      i32.lt_u
      br_if $label9
      block $label10
        local.get $var0
        i32.const -97
        i32.add
        i32.const 255
        i32.and
        i32.const 6
        i32.ge_u
        br_if $label10
        i32.const -87
        local.set $var5
        br $label9
      end $label10
      block $label11
        local.get $var0
        i32.const -65
        i32.add
        i32.const 255
        i32.and
        i32.const 5
        i32.le_u
        br_if $label11
        i32.const -1
        return
      end $label11
      i32.const -55
      local.set $var5
    end $label9
    local.get $var5
    local.get $var0
    i32.add
    local.get $var6
    local.get $var7
    i32.add
    local.get $var2
    local.get $var3
    i32.add
    i32.const 8
    i32.shl
    local.get $var1
    local.get $var4
    i32.add
    i32.const 4
    i32.shl
    i32.or
    i32.or
    i32.const 4
    i32.shl
    i32.or
  )
  (func $encode_term_lookup_index (;34;) (export "encode_term_lookup_index") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (param $var8 i32) (param $var9 i32) (param $var10 i32) (param $var11 i32) (param $var12 i32) (param $var13 i32) (param $var14 i32) (param $var15 i32) (param $var16 i32) (result i32)
    (local $var17 i32)
    (local $var18 v128)
    (local $var19 v128)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 i32)
    (local $var23 i32)
    (local $var24 i32)
    (local $var25 i32)
    (local $var26 i32)
    (local $var27 i32)
    (local $var28 i32)
    (local $var29 i32)
    (local $var30 i32)
    (local $var31 i64)
    (local $var32 i64)
    (local $var33 i32)
    (local $var34 i32)
    (local $var35 i32)
    (local $var36 i64)
    (local $var37 i32)
    (local $var38 i32)
    (local $var39 i32)
    (local $var40 i32)
    (local $var41 i64)
    (local $var42 i32)
    (local $var43 i32)
    (local $var44 i32)
    (local $var45 i32)
    (local $var46 i32)
    (local $var47 i32)
    (local $var48 i32)
    (local $var49 i32)
    (local $var50 i32)
    i32.const -1
    local.set $var17
    block $label0
      local.get $var0
      i32x4.splat
      local.get $var2
      i32x4.replace_lane 1
      local.get $var3
      i32x4.replace_lane 2
      local.get $var4
      i32x4.replace_lane 3
      v128.const i32x4 0x00000000 0x00000000 0x00000000 0x00000000
      local.tee $var18
      i32x4.eq
      local.get $var6
      i32x4.splat
      local.get $var7
      i32x4.replace_lane 1
      local.get $var8
      i32x4.replace_lane 2
      local.get $var9
      i32x4.replace_lane 3
      local.get $var18
      i32x4.eq
      i8x16.shuffle 0 1 4 5 8 9 12 13 16 17 20 21 24 25 28 29
      local.tee $var19
      local.get $var11
      i32x4.splat
      local.get $var13
      i32x4.replace_lane 1
      local.get $var14
      i32x4.replace_lane 2
      local.get $var15
      i32x4.replace_lane 3
      local.get $var18
      i32x4.eq
      local.get $var18
      i8x16.shuffle 0 1 4 5 8 9 12 13 0 1 0 1 0 1 0 1
      v128.or
      local.get $var19
      i8x16.shuffle 0 1 2 3 4 5 6 7 24 25 26 27 28 29 30 31
      v128.any_true
      br_if $label0
      local.get $var10
      i32.const -65535
      i32.add
      i32.const -65534
      i32.lt_u
      br_if $label0
      local.get $var5
      i32.const -65535
      i32.add
      i32.const -65534
      i32.lt_u
      br_if $label0
      local.get $var16
      local.get $var10
      i32.lt_u
      br_if $label0
      i32.const -1
      local.set $var17
      local.get $var16
      local.get $var16
      i32.const -1
      i32.add
      local.tee $var20
      i32.and
      br_if $label0
      local.get $var16
      i32.const 1
      i32.shl
      local.set $var21
      i32.const 0
      local.set $var22
      i32.const 0
      local.set $var23
      i32.const 0
      local.set $var16
      i32.const -1
      local.set $var24
      i32.const 0
      local.set $var25
      i32.const 0
      local.set $var26
      i32.const 0
      local.set $var27
      loop $label15
        local.get $var16
        local.set $var28
        i32.const -2
        local.set $var17
        local.get $var6
        local.get $var27
        i32.const 2
        i32.shl
        local.tee $var16
        i32.add
        i32.load
        local.get $var5
        i32.ge_u
        br_if $label0
        local.get $var8
        local.get $var27
        i32.add
        i32.load8_u
        local.tee $var29
        i32.const 1
        i32.gt_u
        br_if $label0
        block $label1
          local.get $var29
          br_if $label1
          local.get $var7
          local.get $var16
          i32.add
          i32.load
          local.get $var5
          i32.ge_u
          br_if $label0
        end $label1
        block $label3
          block $label2
            local.get $var9
            local.get $var16
            i32.add
            i32.load
            local.tee $var30
            i32.const -1
            i32.gt_s
            br_if $label2
            local.get $var14
            local.get $var27
            i32.const 1
            i32.shl
            i32.add
            i32.const 65535
            i32.store16
            br $label3
          end $label2
          block $label4
            local.get $var30
            local.get $var24
            i32.eq
            br_if $label4
            block $label5
              local.get $var26
              br_if $label5
              local.get $var30
              local.get $var24
              i32.le_s
              br_if $label5
              block $label6
                local.get $var22
                i32.const 65534
                i32.le_u
                br_if $label6
                i32.const -3
                return
              end $label6
              local.get $var13
              local.get $var22
              i32.const 2
              i32.shl
              i32.add
              local.get $var30
              i32.store
              i32.const 0
              local.set $var26
              local.get $var22
              local.set $var25
              local.get $var30
              local.set $var24
              local.get $var22
              i32.const 1
              i32.add
              local.set $var22
              br $label4
            end $label5
            block $label7
              local.get $var26
              br_if $label7
              block $label8
                local.get $var21
                i32.eqz
                br_if $label8
                local.get $var15
                i32.const 0
                local.get $var21
                memory.fill
              end $label8
              local.get $var22
              i32.eqz
              br_if $label7
              i32.const 0
              local.set $var24
              loop $label10
                local.get $var13
                local.get $var24
                i32.const 2
                i32.shl
                i32.add
                i32.load
                local.tee $var17
                i32.const 255
                i32.and
                i32.const -2128831035
                i32.xor
                i32.const 16777619
                i32.mul
                local.get $var17
                i32.const 8
                i32.shr_u
                i32.const 255
                i32.and
                i32.xor
                i32.const 16777619
                i32.mul
                local.get $var17
                i32.const 16
                i32.shr_u
                i32.const 255
                i32.and
                i32.xor
                i32.const 16777619
                i32.mul
                local.get $var17
                i32.const 24
                i32.shr_u
                i32.xor
                i32.const 16777619
                i32.mul
                local.set $var17
                loop $label9
                  local.get $var17
                  local.get $var20
                  i32.and
                  local.tee $var16
                  i32.const 1
                  i32.add
                  local.set $var17
                  local.get $var15
                  local.get $var16
                  i32.const 1
                  i32.shl
                  i32.add
                  local.tee $var16
                  i32.load16_u
                  br_if $label9
                end $label9
                local.get $var16
                local.get $var24
                i32.const 1
                i32.add
                local.tee $var24
                i32.store16
                local.get $var24
                local.get $var22
                i32.ne
                br_if $label10
              end $label10
            end $label7
            local.get $var15
            local.get $var30
            i32.const 255
            i32.and
            i32.const -2128831035
            i32.xor
            i32.const 16777619
            i32.mul
            local.get $var30
            i32.const 8
            i32.shr_u
            i32.const 255
            i32.and
            i32.xor
            i32.const 16777619
            i32.mul
            local.get $var30
            i32.const 16
            i32.shr_u
            i32.const 255
            i32.and
            i32.xor
            i32.const 16777619
            i32.mul
            local.get $var30
            i32.const 24
            i32.shr_u
            i32.xor
            i32.const 16777619
            i32.mul
            local.get $var20
            i32.and
            local.tee $var24
            i32.const 1
            i32.shl
            i32.add
            local.set $var17
            loop $label14
              block $label11
                local.get $var17
                i32.load16_u
                local.tee $var16
                br_if $label11
                block $label12
                  local.get $var22
                  i32.const 65534
                  i32.le_u
                  br_if $label12
                  i32.const -3
                  return
                end $label12
                i32.const 1
                local.set $var26
                local.get $var17
                local.get $var22
                i32.const 1
                i32.add
                local.tee $var16
                i32.store16
                local.get $var13
                local.get $var22
                i32.const 2
                i32.shl
                i32.add
                local.get $var30
                i32.store
                local.get $var22
                local.set $var25
                local.get $var30
                local.set $var24
                local.get $var16
                local.set $var22
                br $label4
              end $label11
              block $label13
                local.get $var13
                local.get $var16
                i32.const 65535
                i32.and
                i32.const -1
                i32.add
                local.tee $var25
                i32.const 2
                i32.shl
                i32.add
                i32.load
                local.get $var30
                i32.eq
                br_if $label13
                local.get $var15
                local.get $var24
                i32.const 1
                i32.add
                local.get $var20
                i32.and
                local.tee $var24
                i32.const 1
                i32.shl
                i32.add
                local.set $var17
                br $label14
              end $label13
            end $label14
            i32.const 1
            local.set $var26
            local.get $var30
            local.set $var24
          end $label4
          local.get $var14
          local.get $var27
          i32.const 1
          i32.shl
          i32.add
          local.get $var25
          i32.store16
          local.get $var23
          i32.const 1
          i32.add
          local.set $var23
        end $label3
        local.get $var28
        local.get $var29
        i32.const 1
        i32.xor
        local.tee $var30
        i32.add
        local.set $var16
        local.get $var27
        i32.const 1
        i32.add
        local.tee $var27
        local.get $var10
        i32.ne
        br_if $label15
      end $label15
      local.get $var5
      i32.const 3
      i32.add
      i32.const 2
      i32.shr_u
      local.set $var17
      i32.const 1
      local.set $var27
      loop $label16
        local.get $var27
        local.tee $var15
        i32.const 1
        i32.shl
        local.set $var27
        local.get $var15
        local.get $var17
        i32.lt_u
        br_if $label16
      end $label16
      local.get $var22
      i32.const 3
      i32.add
      i32.const 2
      i32.shr_u
      local.set $var17
      i32.const 1
      local.set $var24
      loop $label17
        local.get $var24
        local.tee $var20
        i32.const 1
        i32.shl
        local.set $var24
        local.get $var20
        local.get $var17
        i32.lt_u
        br_if $label17
      end $label17
      i32.const -4
      local.set $var17
      local.get $var1
      i64.extend_i32_u
      i64.const 3
      i64.add
      local.tee $var31
      i64.const 8589934588
      i64.and
      local.tee $var32
      local.get $var10
      i32.const 3
      i32.mul
      local.get $var5
      i32.add
      i32.const 1
      i32.shl
      i32.const 3
      i32.add
      local.tee $var33
      i32.const 2147483644
      i32.and
      local.tee $var34
      i64.extend_i32_u
      i64.add
      local.get $var22
      i32.const 2
      i32.shl
      local.tee $var35
      i64.extend_i32_u
      i64.add
      i64.const 32
      i64.add
      local.tee $var36
      local.get $var5
      i32.const 1
      i32.add
      local.tee $var37
      i32.const 1
      i32.shl
      local.tee $var38
      local.get $var5
      i32.add
      local.get $var10
      i32.add
      local.get $var16
      i32.add
      local.get $var23
      i32.add
      local.get $var22
      i32.add
      local.get $var22
      i32.const 1
      i32.add
      local.tee $var39
      i32.add
      local.get $var15
      i32.add
      local.get $var20
      i32.add
      i32.const 1
      i32.shl
      i32.const 3
      i32.add
      i32.const -4
      i32.and
      i32.const 32
      i32.add
      local.tee $var40
      i64.extend_i32_u
      i64.add
      i64.const 16
      i64.add
      local.tee $var41
      local.get $var12
      i64.extend_i32_u
      i64.gt_u
      br_if $label0
      local.get $var41
      i64.const 2147483647
      i64.gt_u
      br_if $label0
      local.get $var11
      i64.const 0
      i64.store offset=40 align=4
      local.get $var11
      local.get $var16
      i32.store offset=36
      local.get $var11
      local.get $var22
      i32.store offset=32
      local.get $var11
      i32.const 7
      i32.store offset=28
      local.get $var11
      local.get $var1
      i32.store offset=24
      local.get $var11
      local.get $var5
      i32.store offset=20
      local.get $var11
      local.get $var10
      i32.store offset=16
      local.get $var11
      local.get $var40
      i32.store offset=12
      local.get $var11
      i64.const 30992321613
      i64.store align=4
      local.get $var11
      local.get $var36
      i32.wrap_i64
      local.tee $var42
      i32.store offset=8
      local.get $var11
      i32.const 48
      i32.add
      local.set $var17
      block $label18
        local.get $var1
        i32.eqz
        br_if $label18
        local.get $var17
        local.get $var0
        local.get $var1
        memory.copy
      end $label18
      i32.const 0
      local.set $var29
      block $label19
        local.get $var32
        i32.wrap_i64
        local.tee $var43
        local.get $var1
        i32.sub
        local.tee $var25
        i32.eqz
        br_if $label19
        local.get $var17
        local.get $var1
        i32.add
        i32.const 0
        local.get $var25
        memory.fill
      end $label19
      local.get $var11
      i32.const 16
      i32.add
      local.set $var21
      block $label20
        local.get $var10
        i32.const 1
        i32.shl
        local.tee $var44
        local.get $var43
        i32.const 32
        i32.add
        local.tee $var25
        local.get $var5
        i32.const 1
        i32.shl
        local.tee $var45
        i32.add
        i32.add
        local.tee $var0
        local.get $var44
        i32.add
        local.tee $var12
        local.get $var44
        i32.add
        local.tee $var17
        i32.const 3
        i32.add
        i32.const -4
        i32.and
        local.tee $var9
        local.get $var17
        i32.sub
        local.tee $var26
        i32.eqz
        br_if $label20
        local.get $var21
        local.get $var17
        i32.add
        i32.const 0
        local.get $var26
        memory.fill
      end $label20
      block $label21
        local.get $var35
        i32.eqz
        br_if $label21
        local.get $var21
        local.get $var9
        i32.add
        local.get $var13
        local.get $var35
        memory.copy
      end $label21
      local.get $var21
      local.get $var25
      i32.add
      local.set $var9
      local.get $var21
      local.get $var0
      i32.add
      local.set $var26
      local.get $var21
      local.get $var12
      i32.add
      local.set $var12
      local.get $var41
      i32.wrap_i64
      local.set $var46
      local.get $var5
      local.set $var0
      loop $label22
        i32.const -5
        local.set $var17
        local.get $var3
        i32.load
        local.get $var29
        i32.ne
        br_if $label0
        local.get $var2
        i32.load16_u
        local.tee $var25
        i32.const 1
        i32.add
        i32.const 65535
        i32.and
        i32.const 2
        i32.lt_u
        br_if $label0
        local.get $var1
        local.get $var29
        i32.lt_u
        br_if $label0
        local.get $var1
        local.get $var29
        i32.sub
        local.get $var25
        i32.lt_u
        br_if $label0
        local.get $var9
        local.get $var25
        i32.store16
        local.get $var3
        i32.const 4
        i32.add
        local.set $var3
        local.get $var2
        i32.const 2
        i32.add
        local.set $var2
        local.get $var9
        i32.const 2
        i32.add
        local.set $var9
        local.get $var29
        local.get $var25
        i32.add
        local.set $var29
        local.get $var0
        i32.const -1
        i32.add
        local.tee $var0
        br_if $label22
      end $label22
      local.get $var29
      local.get $var1
      i32.ne
      br_if $label0
      local.get $var21
      local.get $var42
      i32.add
      local.tee $var2
      i32.const 7
      i32.store offset=28
      local.get $var2
      local.get $var23
      i32.store offset=24
      local.get $var2
      local.get $var22
      i32.store offset=20
      local.get $var2
      local.get $var16
      i32.store offset=16
      local.get $var2
      local.get $var20
      i32.store offset=12
      local.get $var2
      local.get $var15
      i32.store offset=8
      local.get $var2
      local.get $var5
      i32.store offset=4
      local.get $var2
      local.get $var10
      i32.store
      i32.const 0
      local.set $var17
      block $label23
        local.get $var40
        local.get $var24
        local.get $var27
        i32.const 32
        i32.add
        local.tee $var47
        local.get $var45
        i32.add
        local.tee $var9
        local.get $var38
        i32.add
        local.tee $var1
        local.get $var44
        i32.add
        local.tee $var0
        local.get $var38
        i32.add
        local.tee $var42
        local.get $var16
        i32.const 1
        i32.shl
        i32.add
        local.tee $var3
        i32.add
        local.tee $var48
        local.get $var22
        i32.const 1
        i32.shl
        i32.add
        local.tee $var49
        local.get $var39
        i32.const 1
        i32.shl
        local.tee $var25
        i32.add
        local.tee $var50
        local.get $var23
        i32.const 1
        i32.shl
        i32.add
        local.tee $var29
        i32.sub
        local.tee $var23
        i32.eqz
        br_if $label23
        local.get $var2
        local.get $var29
        i32.add
        i32.const 0
        local.get $var23
        memory.fill
      end $label23
      local.get $var2
      i32.const 32
      i32.add
      local.set $var29
      block $label24
        local.get $var27
        i32.eqz
        br_if $label24
        local.get $var29
        i32.const 255
        local.get $var27
        memory.fill
      end $label24
      local.get $var2
      local.get $var3
      i32.add
      local.set $var3
      block $label25
        local.get $var24
        i32.eqz
        br_if $label25
        local.get $var3
        i32.const 255
        local.get $var24
        memory.fill
      end $label25
      local.get $var2
      local.get $var9
      i32.add
      local.set $var21
      block $label26
        local.get $var38
        i32.eqz
        local.tee $var27
        br_if $label26
        local.get $var21
        i32.const 0
        local.get $var38
        memory.fill
      end $label26
      local.get $var2
      local.get $var0
      i32.add
      local.set $var40
      block $label27
        local.get $var27
        br_if $label27
        local.get $var40
        i32.const 0
        local.get $var38
        memory.fill
      end $label27
      local.get $var2
      local.get $var49
      i32.add
      local.set $var23
      block $label28
        local.get $var25
        i32.eqz
        br_if $label28
        local.get $var23
        i32.const 0
        local.get $var25
        memory.fill
      end $label28
      local.get $var5
      i32.const 1
      i32.and
      local.set $var38
      local.get $var15
      i32.const -1
      i32.add
      local.set $var25
      block $label29
        local.get $var5
        i32.const 1
        i32.eq
        br_if $label29
        local.get $var34
        local.get $var43
        i32.add
        local.get $var11
        i32.add
        local.get $var35
        i32.add
        local.get $var15
        i32.const 1
        i32.shl
        i32.add
        i32.const 82
        i32.add
        local.set $var27
        i32.const 0
        local.get $var5
        i32.const 65534
        i32.and
        i32.sub
        local.set $var0
        i32.const 1
        local.set $var17
        local.get $var4
        local.set $var24
        loop $label30
          local.get $var27
          i32.const -2
          i32.add
          local.get $var29
          local.get $var24
          i32.load
          local.get $var25
          i32.and
          i32.const 1
          i32.shl
          i32.add
          local.tee $var9
          i32.load16_u
          i32.store16
          local.get $var9
          local.get $var17
          i32.const -1
          i32.add
          i32.store16
          local.get $var27
          local.get $var29
          local.get $var24
          i32.const 4
          i32.add
          i32.load
          local.get $var25
          i32.and
          i32.const 1
          i32.shl
          i32.add
          local.tee $var9
          i32.load16_u
          i32.store16
          local.get $var9
          local.get $var17
          i32.store16
          local.get $var27
          i32.const 4
          i32.add
          local.set $var27
          local.get $var24
          i32.const 8
          i32.add
          local.set $var24
          local.get $var0
          local.get $var17
          i32.const 2
          i32.add
          local.tee $var17
          i32.add
          i32.const 1
          i32.ne
          br_if $label30
        end $label30
        local.get $var17
        i32.const -1
        i32.add
        local.set $var17
      end $label29
      block $label31
        local.get $var38
        i32.eqz
        br_if $label31
        local.get $var2
        local.get $var47
        i32.add
        local.get $var17
        i32.const 1
        i32.shl
        i32.add
        local.get $var29
        local.get $var4
        local.get $var17
        i32.const 2
        i32.shl
        i32.add
        i32.load
        local.get $var25
        i32.and
        i32.const 1
        i32.shl
        i32.add
        local.tee $var27
        i32.load16_u
        i32.store16
        local.get $var27
        local.get $var17
        i32.store16
      end $label31
      block $label32
        local.get $var22
        i32.eqz
        br_if $label32
        local.get $var2
        local.get $var48
        i32.add
        local.set $var27
        local.get $var20
        i32.const -1
        i32.add
        local.set $var29
        i32.const 0
        local.set $var24
        loop $label33
          local.get $var27
          local.get $var3
          local.get $var13
          i32.load
          local.tee $var17
          i32.const 255
          i32.and
          i32.const -2128831035
          i32.xor
          i32.const 16777619
          i32.mul
          local.get $var17
          i32.const 8
          i32.shr_u
          i32.const 255
          i32.and
          i32.xor
          i32.const 16777619
          i32.mul
          local.get $var17
          i32.const 16
          i32.shr_u
          i32.const 255
          i32.and
          i32.xor
          i32.const 16777619
          i32.mul
          local.get $var17
          i32.const 24
          i32.shr_u
          i32.xor
          i32.const 16777619
          i32.mul
          local.get $var29
          i32.and
          i32.const 1
          i32.shl
          i32.add
          local.tee $var17
          i32.load16_u
          i32.store16
          local.get $var17
          local.get $var24
          i32.store16
          local.get $var27
          i32.const 2
          i32.add
          local.set $var27
          local.get $var13
          i32.const 4
          i32.add
          local.set $var13
          local.get $var22
          local.get $var24
          i32.const 1
          i32.add
          local.tee $var24
          i32.ne
          br_if $label33
        end $label33
      end $label32
      local.get $var2
      local.get $var1
      i32.add
      local.set $var3
      local.get $var2
      local.get $var42
      i32.add
      local.set $var0
      local.get $var2
      local.get $var50
      i32.add
      local.set $var4
      local.get $var23
      i32.const 2
      i32.add
      local.set $var1
      local.get $var40
      i32.const 2
      i32.add
      local.set $var9
      local.get $var21
      i32.const 2
      i32.add
      local.set $var24
      local.get $var11
      local.get $var43
      local.get $var45
      i32.add
      i32.add
      local.set $var2
      i32.const 0
      local.set $var17
      local.get $var10
      local.set $var13
      loop $label37
        local.get $var2
        local.get $var17
        i32.add
        i32.const 48
        i32.add
        local.tee $var29
        local.get $var6
        i32.load
        i32.store16
        i32.const 65535
        local.set $var27
        block $label34
          local.get $var8
          i32.load8_u
          br_if $label34
          local.get $var7
          i32.load
          local.set $var27
        end $label34
        local.get $var26
        local.get $var17
        i32.add
        local.tee $var25
        local.get $var27
        i32.store16
        local.get $var12
        local.get $var17
        i32.add
        local.get $var14
        local.get $var17
        i32.add
        i32.load16_u
        local.tee $var27
        i32.store16
        local.get $var24
        local.get $var29
        i32.load16_u
        i32.const 1
        i32.shl
        i32.add
        local.tee $var29
        local.get $var29
        i32.load16_u
        i32.const 1
        i32.add
        i32.store16
        block $label35
          local.get $var25
          i32.load16_u
          local.tee $var29
          i32.const 65535
          i32.eq
          br_if $label35
          local.get $var9
          local.get $var29
          i32.const 1
          i32.shl
          i32.add
          local.tee $var29
          local.get $var29
          i32.load16_u
          i32.const 1
          i32.add
          i32.store16
        end $label35
        block $label36
          local.get $var27
          i32.const 65535
          i32.eq
          br_if $label36
          local.get $var1
          local.get $var27
          i32.const 1
          i32.shl
          i32.add
          local.tee $var27
          local.get $var27
          i32.load16_u
          i32.const 1
          i32.add
          i32.store16
        end $label36
        local.get $var6
        i32.const 4
        i32.add
        local.set $var6
        local.get $var8
        i32.const 1
        i32.add
        local.set $var8
        local.get $var7
        i32.const 4
        i32.add
        local.set $var7
        local.get $var17
        i32.const 2
        i32.add
        local.set $var17
        local.get $var13
        i32.const -1
        i32.add
        local.tee $var13
        br_if $label37
      end $label37
      i32.const 1
      local.set $var17
      local.get $var37
      i32.const 2
      local.get $var37
      i32.const 2
      i32.gt_u
      select
      i32.const -1
      i32.add
      local.tee $var27
      i32.const 1
      i32.and
      local.set $var2
      block $label38
        local.get $var5
        i32.const 2
        i32.lt_u
        br_if $label38
        local.get $var11
        local.get $var34
        local.get $var43
        i32.add
        i32.add
        local.get $var35
        i32.add
        local.get $var15
        i32.const 1
        i32.shl
        i32.add
        local.set $var17
        local.get $var27
        i32.const -2
        i32.and
        local.set $var8
        local.get $var5
        i32.const 2
        i32.shl
        local.get $var44
        i32.add
        local.set $var7
        i32.const 0
        local.set $var6
        loop $label39
          local.get $var17
          local.get $var45
          i32.add
          local.tee $var27
          i32.const 82
          i32.add
          local.tee $var13
          local.get $var27
          i32.const 80
          i32.add
          i32.load16_u
          local.get $var13
          i32.load16_u
          i32.add
          i32.store16
          local.get $var17
          local.get $var7
          i32.add
          local.tee $var29
          i32.const 84
          i32.add
          local.tee $var25
          local.get $var29
          i32.const 82
          i32.add
          i32.load16_u
          local.get $var25
          i32.load16_u
          i32.add
          i32.store16
          local.get $var27
          i32.const 84
          i32.add
          local.tee $var27
          local.get $var13
          i32.load16_u
          local.get $var27
          i32.load16_u
          i32.add
          i32.store16
          local.get $var29
          i32.const 86
          i32.add
          local.tee $var27
          local.get $var25
          i32.load16_u
          local.get $var27
          i32.load16_u
          i32.add
          i32.store16
          local.get $var17
          i32.const 4
          i32.add
          local.set $var17
          local.get $var8
          local.get $var6
          i32.const 2
          i32.add
          local.tee $var6
          i32.ne
          br_if $label39
        end $label39
        local.get $var6
        i32.const 1
        i32.add
        local.set $var17
      end $label38
      block $label40
        local.get $var2
        i32.eqz
        br_if $label40
        local.get $var21
        local.get $var17
        i32.const 1
        i32.shl
        local.tee $var17
        i32.add
        local.tee $var27
        local.get $var21
        local.get $var17
        i32.const -2
        i32.add
        local.tee $var13
        i32.add
        i32.load16_u
        local.get $var27
        i32.load16_u
        i32.add
        i32.store16
        local.get $var40
        local.get $var17
        i32.add
        local.tee $var17
        local.get $var40
        local.get $var13
        i32.add
        i32.load16_u
        local.get $var17
        i32.load16_u
        i32.add
        i32.store16
      end $label40
      block $label41
        local.get $var22
        i32.eqz
        br_if $label41
        i32.const 1
        local.set $var17
        local.get $var11
        local.get $var33
        i32.const 2147483644
        i32.and
        local.get $var31
        i32.wrap_i64
        local.tee $var8
        i32.add
        i32.const -4
        i32.and
        i32.add
        local.get $var5
        local.get $var22
        i32.add
        local.tee $var2
        i32.const 6
        i32.mul
        local.tee $var25
        i32.add
        local.get $var10
        local.get $var28
        i32.add
        local.get $var30
        i32.add
        local.get $var15
        i32.add
        local.get $var20
        i32.add
        local.tee $var7
        i32.const 1
        i32.shl
        i32.add
        i32.const 84
        i32.add
        i32.load16_u
        local.set $var27
        local.get $var39
        i32.const 2
        local.get $var39
        i32.const 2
        i32.gt_u
        select
        local.tee $var29
        i32.const -1
        i32.add
        local.tee $var6
        i32.const 3
        i32.and
        local.set $var13
        block $label42
          local.get $var29
          i32.const -2
          i32.add
          i32.const 3
          i32.lt_u
          br_if $label42
          local.get $var11
          local.get $var33
          i32.const 2
          i32.shr_u
          local.get $var8
          i32.const 2
          i32.shr_u
          i32.add
          i32.const 2
          i32.shl
          i32.add
          local.get $var25
          i32.add
          local.get $var7
          i32.const 1
          i32.shl
          i32.add
          local.set $var17
          local.get $var6
          i32.const -4
          i32.and
          local.set $var6
          i32.const 0
          local.set $var29
          loop $label43
            local.get $var17
            i32.const 86
            i32.add
            local.tee $var25
            local.get $var27
            local.get $var25
            i32.load16_u
            i32.add
            local.tee $var27
            i32.store16
            local.get $var17
            i32.const 88
            i32.add
            local.tee $var25
            local.get $var27
            local.get $var25
            i32.load16_u
            i32.add
            local.tee $var27
            i32.store16
            local.get $var17
            i32.const 90
            i32.add
            local.tee $var25
            local.get $var27
            local.get $var25
            i32.load16_u
            i32.add
            local.tee $var27
            i32.store16
            local.get $var17
            i32.const 92
            i32.add
            local.tee $var25
            local.get $var27
            local.get $var25
            i32.load16_u
            i32.add
            local.tee $var27
            i32.store16
            local.get $var17
            i32.const 8
            i32.add
            local.set $var17
            local.get $var6
            local.get $var29
            i32.const 4
            i32.add
            local.tee $var29
            i32.ne
            br_if $label43
          end $label43
          local.get $var29
          i32.const 1
          i32.add
          local.set $var17
        end $label42
        local.get $var13
        i32.eqz
        br_if $label41
        local.get $var33
        i32.const 2
        i32.shr_u
        local.get $var8
        i32.const 2
        i32.shr_u
        i32.add
        i32.const 2
        i32.shl
        local.get $var17
        i32.const 1
        i32.shl
        i32.add
        local.get $var11
        i32.add
        local.get $var2
        i32.const 6
        i32.mul
        i32.add
        local.get $var7
        i32.const 1
        i32.shl
        i32.add
        i32.const 84
        i32.add
        local.set $var17
        loop $label44
          local.get $var17
          local.get $var27
          local.get $var17
          i32.load16_u
          i32.add
          local.tee $var27
          i32.store16
          local.get $var17
          i32.const 2
          i32.add
          local.set $var17
          local.get $var13
          i32.const -1
          i32.add
          local.tee $var13
          br_if $label44
        end $label44
      end $label41
      local.get $var10
      i32.const -1
      i32.add
      local.set $var27
      local.get $var44
      local.get $var14
      i32.add
      i32.const -2
      i32.add
      local.set $var29
      local.get $var43
      local.get $var44
      i32.add
      local.get $var45
      i32.add
      local.get $var11
      i32.add
      i32.const 46
      i32.add
      local.set $var25
      local.get $var10
      i32.const 2
      i32.shl
      local.get $var43
      i32.add
      local.get $var45
      i32.add
      local.get $var11
      i32.add
      i32.const 46
      i32.add
      local.set $var6
      i32.const 0
      local.set $var17
      loop $label47
        local.get $var24
        local.get $var25
        local.get $var17
        i32.add
        i32.load16_u
        i32.const 1
        i32.shl
        i32.add
        local.tee $var13
        local.get $var13
        i32.load16_u
        i32.const -1
        i32.add
        local.tee $var13
        i32.store16
        local.get $var3
        local.get $var13
        i32.const 65535
        i32.and
        i32.const 1
        i32.shl
        i32.add
        local.get $var27
        i32.store16
        block $label45
          local.get $var6
          local.get $var17
          i32.add
          i32.load16_u
          local.tee $var13
          i32.const 65535
          i32.eq
          br_if $label45
          local.get $var9
          local.get $var13
          i32.const 1
          i32.shl
          i32.add
          local.tee $var13
          local.get $var13
          i32.load16_u
          i32.const -1
          i32.add
          local.tee $var13
          i32.store16
          local.get $var0
          local.get $var13
          i32.const 65535
          i32.and
          i32.const 1
          i32.shl
          i32.add
          local.get $var27
          i32.store16
        end $label45
        block $label46
          local.get $var29
          local.get $var17
          i32.add
          i32.load16_u
          local.tee $var13
          i32.const 65535
          i32.eq
          br_if $label46
          local.get $var23
          local.get $var13
          i32.const 1
          i32.shl
          i32.add
          local.tee $var13
          local.get $var13
          i32.load16_u
          local.tee $var13
          i32.const 1
          i32.add
          i32.store16
          local.get $var4
          local.get $var13
          i32.const 1
          i32.shl
          i32.add
          local.get $var27
          i32.store16
        end $label46
        local.get $var17
        i32.const -2
        i32.add
        local.set $var17
        local.get $var27
        i32.const -1
        i32.add
        local.tee $var27
        i32.const -1
        i32.ne
        br_if $label47
      end $label47
      block $label48
        local.get $var5
        i32.const 2
        i32.lt_u
        br_if $label48
        i32.const 1
        local.set $var25
        block $label49
          local.get $var5
          i32.const 17
          i32.lt_u
          br_if $label49
          i32.const 1
          local.set $var25
          local.get $var10
          local.get $var5
          i32.add
          i32.const 8
          i32.lt_u
          br_if $label49
          local.get $var11
          local.get $var34
          local.get $var31
          i32.wrap_i64
          i32.const -4
          i32.and
          i32.add
          local.tee $var27
          local.get $var5
          i32.const 2
          i32.shl
          i32.add
          local.get $var44
          i32.add
          i32.add
          local.get $var35
          i32.add
          local.set $var17
          local.get $var15
          i32.const 1
          i32.shl
          local.set $var24
          local.get $var5
          i32.const -1
          i32.add
          local.tee $var8
          i32.const -8
          i32.and
          local.tee $var6
          i32.const 1
          i32.or
          local.set $var25
          local.get $var11
          local.get $var27
          local.get $var45
          i32.add
          i32.add
          local.get $var35
          i32.add
          local.set $var27
          local.get $var6
          local.set $var13
          loop $label50
            local.get $var27
            local.get $var24
            i32.add
            local.tee $var29
            i32.const 82
            i32.add
            local.get $var29
            i32.const 84
            i32.add
            v128.load align=2
            v128.store align=2
            local.get $var17
            local.get $var24
            i32.add
            local.tee $var29
            i32.const 84
            i32.add
            local.get $var29
            i32.const 86
            i32.add
            v128.load align=2
            v128.store align=2
            local.get $var27
            i32.const 16
            i32.add
            local.set $var27
            local.get $var17
            i32.const 16
            i32.add
            local.set $var17
            local.get $var13
            i32.const -8
            i32.add
            local.tee $var13
            br_if $label50
          end $label50
          local.get $var8
          local.get $var6
          i32.eq
          br_if $label48
        end $label49
        local.get $var25
        i32.const 1
        i32.add
        local.set $var17
        block $label51
          local.get $var5
          i32.const 1
          i32.and
          br_if $label51
          local.get $var21
          local.get $var25
          i32.const 1
          i32.shl
          local.tee $var27
          i32.add
          local.get $var21
          local.get $var25
          i32.const 1
          i32.add
          local.tee $var25
          i32.const 1
          i32.shl
          local.tee $var24
          i32.add
          i32.load16_u
          i32.store16
          local.get $var40
          local.get $var27
          i32.add
          local.get $var40
          local.get $var24
          i32.add
          i32.load16_u
          i32.store16
        end $label51
        local.get $var5
        local.get $var17
        i32.eq
        br_if $label48
        local.get $var11
        local.get $var34
        local.get $var31
        i32.wrap_i64
        i32.const -4
        i32.and
        i32.add
        local.tee $var27
        local.get $var45
        i32.add
        i32.add
        local.get $var35
        i32.add
        local.get $var15
        i32.const 1
        i32.shl
        local.tee $var24
        i32.add
        local.set $var17
        local.get $var11
        local.get $var27
        local.get $var5
        i32.const 2
        i32.shl
        i32.add
        local.get $var44
        i32.add
        i32.add
        local.get $var35
        i32.add
        local.get $var24
        i32.add
        local.set $var27
        local.get $var25
        i32.const 1
        i32.shl
        local.set $var29
        local.get $var5
        local.get $var25
        i32.sub
        local.set $var25
        loop $label52
          local.get $var17
          local.get $var29
          i32.add
          local.tee $var24
          i32.const 80
          i32.add
          local.get $var24
          i32.const 82
          i32.add
          local.tee $var6
          i32.load16_u
          i32.store16
          local.get $var27
          local.get $var29
          i32.add
          local.tee $var13
          i32.const 82
          i32.add
          local.get $var13
          i32.const 84
          i32.add
          local.tee $var8
          i32.load16_u
          i32.store16
          local.get $var6
          local.get $var24
          i32.const 84
          i32.add
          i32.load16_u
          i32.store16
          local.get $var8
          local.get $var13
          i32.const 86
          i32.add
          i32.load16_u
          i32.store16
          local.get $var17
          i32.const 4
          i32.add
          local.set $var17
          local.get $var27
          i32.const 4
          i32.add
          local.set $var27
          local.get $var25
          i32.const -2
          i32.add
          local.tee $var25
          br_if $label52
        end $label52
      end $label48
      local.get $var21
      local.get $var5
      i32.const 1
      i32.shl
      local.tee $var17
      i32.add
      local.get $var10
      i32.store16
      local.get $var40
      local.get $var17
      i32.add
      local.get $var16
      i32.store16
      block $label53
        local.get $var22
        i32.eqz
        br_if $label53
        local.get $var22
        local.set $var16
        block $label54
          local.get $var22
          i32.const 8
          i32.lt_u
          br_if $label54
          local.get $var5
          i32.const 6
          i32.mul
          local.get $var33
          i32.const 2
          i32.shr_u
          local.get $var31
          i32.wrap_i64
          i32.const 2
          i32.shr_u
          i32.add
          i32.const 2
          i32.shl
          i32.add
          local.get $var11
          i32.add
          local.get $var22
          i32.const 3
          i32.shl
          i32.add
          local.get $var10
          local.get $var28
          i32.add
          local.get $var30
          i32.add
          local.get $var15
          i32.add
          local.get $var20
          i32.add
          i32.const 1
          i32.shl
          i32.add
          i32.const 70
          i32.add
          local.set $var17
          local.get $var22
          i32.const 7
          i32.and
          local.set $var16
          local.get $var22
          i32.const -8
          i32.and
          local.tee $var24
          local.set $var27
          loop $label55
            local.get $var17
            local.get $var17
            i32.const -2
            i32.add
            v128.load align=2
            v128.store align=2
            local.get $var17
            i32.const -16
            i32.add
            local.set $var17
            local.get $var27
            i32.const -8
            i32.add
            local.tee $var27
            br_if $label55
          end $label55
          local.get $var22
          local.get $var24
          i32.eq
          br_if $label53
        end $label54
        local.get $var33
        i32.const 2
        i32.shr_u
        local.get $var31
        i32.wrap_i64
        i32.const 2
        i32.shr_u
        i32.add
        i32.const 2
        i32.shl
        local.get $var16
        i32.const 1
        i32.shl
        i32.add
        local.get $var11
        i32.add
        local.get $var5
        local.get $var22
        i32.add
        i32.const 6
        i32.mul
        i32.add
        local.get $var10
        local.get $var28
        i32.add
        local.get $var30
        i32.add
        local.get $var15
        i32.add
        local.get $var20
        i32.add
        i32.const 1
        i32.shl
        i32.add
        i32.const 84
        i32.add
        local.set $var17
        loop $label56
          local.get $var17
          local.get $var17
          i32.const -2
          i32.add
          local.tee $var15
          i32.load16_u
          i32.store16
          local.get $var15
          local.set $var17
          local.get $var16
          i32.const -1
          i32.add
          local.tee $var16
          br_if $label56
        end $label56
      end $label53
      local.get $var23
      i32.const 0
      i32.store16
      local.get $var46
      local.set $var17
    end $label0
    local.get $var17
  )
  (func $encode_term_content_token_binary_dedup (;35;) (export "encode_term_content_token_binary_dedup") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (param $var8 i32) (param $var9 i32) (result i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 v128)
    (local $var13 v128)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 i32)
    (local $var23 i32)
    (local $var24 i32)
    (local $var25 i32)
    (local $var26 i32)
    (local $var27 i32)
    (local $var28 i32)
    (local $var29 i32)
    (local $var30 i32)
    (local $var31 i32)
    (local $var32 i32)
    (local $var33 i32)
    (local $var34 i32)
    global.get $global0
    i32.const 16
    i32.sub
    local.tee $var10
    global.set $global0
    i32.const -1
    local.set $var11
    block $label0
      local.get $var0
      i32x4.splat
      local.get $var1
      i32x4.replace_lane 1
      local.get $var3
      i32x4.replace_lane 2
      local.get $var5
      i32x4.replace_lane 3
      v128.const i32x4 0x00000000 0x00000000 0x00000000 0x00000000
      local.tee $var12
      i32x4.eq
      v128.const i32x4 0x0000FFFF 0x0000FFFF 0x0000FFFF 0x0000FFFF
      local.tee $var13
      v128.and
      local.get $var6
      i32x4.splat
      local.get $var8
      i32x4.replace_lane 1
      local.get $var9
      i32x4.replace_lane 2
      local.get $var7
      i32x4.replace_lane 3
      local.get $var12
      i32x4.eq
      local.get $var13
      v128.and
      i16x8.narrow_i32x4_u
      v128.any_true
      br_if $label0
      i32.const -1
      local.set $var11
      local.get $var7
      local.get $var7
      i32.const -1
      i32.add
      local.tee $var14
      i32.and
      br_if $label0
      i32.const 0
      local.set $var15
      i32.const 0
      local.get $var4
      i32.store offset=2552
      local.get $var10
      i32.const 0
      i32.store offset=12
      i32.const 0
      local.set $var16
      block $label1
        local.get $var2
        i32.eqz
        br_if $label1
        i32.const 0
        local.set $var15
        i32.const 0
        local.set $var16
        i32.const 0
        local.set $var17
        loop $label16
          local.get $var10
          i32.const 0
          i32.store offset=8
          local.get $var10
          i32.const 0
          i32.store offset=4
          block $label2
            local.get $var0
            local.get $var1
            local.get $var17
            i32.const 68
            i32.mul
            i32.add
            local.tee $var18
            local.get $var3
            local.get $var4
            local.get $var10
            i32.const 12
            i32.add
            local.get $var10
            i32.const 8
            i32.add
            local.get $var10
            i32.const 4
            i32.add
            i32.const 0
            i32.const 0
            call $func27
            br_if $label2
            loop $label5
              local.get $var10
              local.get $var15
              i32.store offset=12
              i32.const -2
              local.set $var11
              local.get $var4
              i32.const 2147483646
              i32.gt_u
              br_if $label0
              local.get $var3
              local.get $var4
              i32.const 7
              i32.add
              i32.const -8
              i32.and
              local.tee $var19
              i32.const -1
              i32.xor
              i32.gt_u
              br_if $label0
              i32.const 0
              i32.load offset=2544
              local.get $var19
              local.get $var3
              i32.add
              local.tee $var20
              i32.ne
              br_if $label0
              i32.const 2147483647
              local.get $var4
              i32.const 1
              i32.shr_u
              local.tee $var21
              i32.const 1048576
              local.get $var21
              i32.const 1048576
              i32.gt_u
              select
              local.tee $var21
              local.get $var4
              i32.add
              local.get $var4
              local.get $var21
              i32.const 2147483647
              i32.xor
              i32.gt_u
              select
              local.tee $var4
              local.get $var19
              i32.sub
              i32.const 7
              i32.add
              local.set $var21
              local.get $var20
              local.set $var19
              block $label3
                local.get $var20
                br_if $label3
                i32.const 104256
                local.set $var19
                i32.const 0
                i32.const 104256
                i32.store offset=2544
              end $label3
              local.get $var19
              i32.const 7
              i32.add
              i32.const -8
              i32.and
              local.tee $var19
              local.get $var21
              i32.const -8
              i32.and
              local.tee $var21
              i32.const -1
              i32.xor
              i32.gt_u
              br_if $label0
              block $label4
                local.get $var19
                local.get $var21
                i32.add
                local.tee $var21
                i32.const 16
                i32.shr_u
                local.get $var21
                i32.const 65528
                i32.and
                i32.const 0
                i32.ne
                i32.add
                local.tee $var22
                memory.size
                local.tee $var23
                i32.le_u
                br_if $label4
                local.get $var22
                local.get $var23
                i32.sub
                memory.grow
                i32.const 0
                i32.lt_s
                br_if $label0
              end $label4
              i32.const 0
              local.get $var21
              i32.store offset=2544
              local.get $var19
              i32.eqz
              br_if $label0
              local.get $var19
              local.get $var20
              i32.ne
              br_if $label0
              i32.const 0
              local.get $var4
              i32.store offset=2552
              local.get $var0
              local.get $var18
              local.get $var3
              local.get $var4
              local.get $var10
              i32.const 12
              i32.add
              local.get $var10
              i32.const 8
              i32.add
              local.get $var10
              i32.const 4
              i32.add
              i32.const 0
              i32.const 0
              call $func27
              i32.eqz
              br_if $label5
            end $label5
          end $label2
          local.get $var17
          i32.const 2
          i32.shl
          local.set $var24
          local.get $var10
          i32.load offset=4
          local.tee $var25
          i32.const -1640531535
          i32.mul
          local.get $var10
          i32.load offset=8
          local.tee $var26
          i32.xor
          local.tee $var11
          i32.const 16
          i32.shr_u
          local.get $var11
          i32.xor
          local.get $var14
          i32.and
          local.set $var27
          local.get $var3
          local.get $var15
          i32.add
          local.set $var28
          local.get $var10
          i32.load offset=12
          local.tee $var29
          local.get $var15
          i32.sub
          local.set $var30
          i32.const 0
          local.set $var31
          block $label15
            block $label11
              block $label6
                loop $label14
                  local.get $var6
                  local.get $var27
                  i32.const 2
                  i32.shl
                  i32.add
                  i32.load
                  local.tee $var11
                  i32.eqz
                  br_if $label6
                  block $label7
                    local.get $var11
                    i32.const -1
                    i32.add
                    local.tee $var32
                    local.get $var17
                    i32.lt_u
                    br_if $label7
                    i32.const -3
                    local.set $var11
                    br $label0
                  end $label7
                  block $label8
                    local.get $var5
                    local.get $var32
                    i32.const 4
                    i32.shl
                    i32.add
                    local.tee $var20
                    i32.load offset=8
                    local.get $var26
                    i32.ne
                    br_if $label8
                    local.get $var20
                    i32.load offset=12
                    local.get $var25
                    i32.ne
                    br_if $label8
                    local.get $var20
                    i32.load offset=4
                    local.get $var30
                    i32.ne
                    br_if $label8
                    i32.const 0
                    local.set $var11
                    local.get $var3
                    local.get $var20
                    i32.load
                    local.tee $var33
                    i32.add
                    local.tee $var34
                    local.set $var20
                    local.get $var28
                    local.set $var19
                    local.get $var30
                    local.set $var21
                    block $label10
                      loop $label12
                        block $label9
                          local.get $var11
                          i32.const 8
                          i32.add
                          local.tee $var18
                          local.get $var30
                          i32.le_u
                          br_if $label9
                          local.get $var11
                          local.get $var30
                          i32.lt_u
                          br_if $label10
                          br $label11
                        end $label9
                        local.get $var28
                        local.get $var11
                        i32.add
                        local.set $var22
                        local.get $var34
                        local.get $var11
                        i32.add
                        local.set $var23
                        local.get $var20
                        i32.const 8
                        i32.add
                        local.set $var20
                        local.get $var19
                        i32.const 8
                        i32.add
                        local.set $var19
                        local.get $var21
                        i32.const -8
                        i32.add
                        local.set $var21
                        local.get $var18
                        local.set $var11
                        local.get $var23
                        i64.load align=1
                        local.get $var22
                        i64.load align=1
                        i64.eq
                        br_if $label12
                        br $label8
                      end $label12
                    end $label10
                    loop $label13
                      local.get $var20
                      i32.load8_u
                      local.get $var19
                      i32.load8_u
                      i32.ne
                      br_if $label8
                      local.get $var20
                      i32.const 1
                      i32.add
                      local.set $var20
                      local.get $var19
                      i32.const 1
                      i32.add
                      local.set $var19
                      local.get $var21
                      i32.const -1
                      i32.add
                      local.tee $var21
                      i32.eqz
                      br_if $label11
                      br $label13
                    end $label13
                  end $label8
                  local.get $var27
                  i32.const 1
                  i32.add
                  local.get $var14
                  i32.and
                  local.set $var27
                  local.get $var31
                  i32.const 1
                  i32.add
                  local.tee $var31
                  local.get $var7
                  i32.ne
                  br_if $label14
                end $label14
              end $label6
              i32.const -3
              local.set $var11
              local.get $var6
              local.get $var27
              i32.const 2
              i32.shl
              i32.add
              local.tee $var20
              i32.load
              br_if $label0
              local.get $var16
              i32.const -1
              i32.eq
              br_if $label0
              local.get $var5
              local.get $var24
              i32.const 2
              i32.shl
              i32.add
              local.tee $var11
              local.get $var25
              i32.store offset=12
              local.get $var11
              local.get $var26
              i32.store offset=8
              local.get $var11
              local.get $var30
              i32.store offset=4
              local.get $var11
              local.get $var15
              i32.store
              local.get $var8
              local.get $var24
              i32.add
              local.get $var16
              i32.store
              local.get $var20
              local.get $var17
              i32.const 1
              i32.add
              local.tee $var17
              i32.store
              local.get $var16
              i32.const 1
              i32.add
              local.set $var16
              local.get $var29
              local.set $var15
              br $label15
            end $label11
            local.get $var5
            local.get $var24
            i32.const 2
            i32.shl
            i32.add
            local.tee $var11
            local.get $var25
            i32.store offset=12
            local.get $var11
            local.get $var26
            i32.store offset=8
            local.get $var11
            local.get $var30
            i32.store offset=4
            local.get $var11
            local.get $var33
            i32.store
            local.get $var8
            local.get $var24
            i32.add
            local.get $var8
            local.get $var32
            i32.const 2
            i32.shl
            i32.add
            i32.load
            i32.store
            local.get $var10
            local.get $var15
            i32.store offset=12
            local.get $var17
            i32.const 1
            i32.add
            local.set $var17
          end $label15
          local.get $var17
          local.get $var2
          i32.ne
          br_if $label16
        end $label16
      end $label1
      local.get $var9
      local.get $var16
      i32.store
      local.get $var15
      local.set $var11
    end $label0
    local.get $var10
    i32.const 16
    i32.add
    global.set $global0
    local.get $var11
  )
  (func $parse_and_encode_term_bank_token_binary_dedup (;36;) (export "parse_and_encode_term_bank_token_binary_dedup") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (param $var8 i32) (param $var9 i32) (param $var10 i32) (param $var11 i32) (param $var12 i32) (param $var13 i32) (param $var14 i32) (param $var15 i32) (param $var16 i32) (param $var17 i32) (param $var18 i32) (param $var19 i32) (param $var20 i32) (param $var21 i32) (param $var22 i32) (param $var23 i32) (param $var24 i32) (param $var25 i32) (param $var26 i32) (param $var27 i32) (param $var28 i32) (param $var29 i32) (param $var30 i32) (param $var31 i32) (param $var32 i32) (param $var33 i32) (param $var34 i32) (param $var35 i32) (param $var36 i32) (param $var37 i32) (param $var38 i32) (result i32)
    (local $var39 i32)
    (local $var40 i32)
    (local $var41 v128)
    (local $var42 v128)
    (local $var43 i32)
    (local $var44 i32)
    (local $var45 i32)
    (local $var46 i32)
    (local $var47 i32)
    (local $var48 i32)
    (local $var49 i32)
    (local $var50 i32)
    (local $var51 i32)
    (local $var52 i32)
    (local $var53 i32)
    (local $var54 i32)
    (local $var55 i32)
    (local $var56 i32)
    (local $var57 i32)
    (local $var58 i32)
    (local $var59 i32)
    (local $var60 i32)
    (local $var61 i32)
    (local $var62 i32)
    (local $var63 i32)
    (local $var64 i32)
    (local $var65 i32)
    (local $var66 i32)
    (local $var67 i32)
    (local $var68 i32)
    (local $var69 i32)
    (local $var70 i32)
    (local $var71 i32)
    (local $var72 i32)
    (local $var73 i32)
    (local $var74 i32)
    (local $var75 i32)
    (local $var76 i32)
    (local $var77 i32)
    (local $var78 i32)
    (local $var79 i32)
    (local $var80 i32)
    (local $var81 i32)
    (local $var82 i32)
    global.get $global0
    i32.const 112
    i32.sub
    local.tee $var39
    global.set $global0
    i32.const -1
    local.set $var40
    block $label0
      local.get $var0
      i32x4.splat
      local.get $var1
      i32x4.replace_lane 1
      local.get $var2
      i32x4.replace_lane 2
      local.get $var3
      i32x4.replace_lane 3
      v128.const i32x4 0x00000000 0x00000000 0x00000000 0x00000000
      local.tee $var41
      i32x4.eq
      local.get $var4
      i32x4.splat
      local.get $var6
      i32x4.replace_lane 1
      local.get $var7
      i32x4.replace_lane 2
      local.get $var9
      i32x4.replace_lane 3
      local.get $var41
      i32x4.eq
      i8x16.shuffle 0 4 8 12 16 20 24 28 0 0 0 0 0 0 0 0
      local.get $var10
      i32x4.splat
      local.get $var11
      i32x4.replace_lane 1
      local.get $var12
      i32x4.replace_lane 2
      local.get $var13
      i32x4.replace_lane 3
      local.get $var41
      i32x4.eq
      local.tee $var42
      i32x4.extract_lane 0
      i8x16.replace_lane 8
      local.get $var42
      i32x4.extract_lane 1
      i8x16.replace_lane 9
      local.get $var42
      i32x4.extract_lane 2
      i8x16.replace_lane 10
      local.get $var42
      i32x4.extract_lane 3
      i8x16.replace_lane 11
      local.get $var15
      i32x4.splat
      local.get $var16
      i32x4.replace_lane 1
      local.get $var17
      i32x4.replace_lane 2
      local.get $var18
      i32x4.replace_lane 3
      local.get $var41
      i32x4.eq
      local.tee $var42
      i32x4.extract_lane 0
      i8x16.replace_lane 12
      local.get $var42
      i32x4.extract_lane 1
      i8x16.replace_lane 13
      local.get $var42
      i32x4.extract_lane 2
      i8x16.replace_lane 14
      local.get $var42
      i32x4.extract_lane 3
      i8x16.replace_lane 15
      local.tee $var42
      local.get $var19
      i32x4.splat
      local.get $var20
      i32x4.replace_lane 1
      local.get $var22
      i32x4.replace_lane 2
      local.get $var23
      i32x4.replace_lane 3
      local.get $var41
      i32x4.eq
      local.get $var24
      i32x4.splat
      local.get $var25
      i32x4.replace_lane 1
      local.get $var26
      i32x4.replace_lane 2
      local.get $var27
      i32x4.replace_lane 3
      local.get $var41
      i32x4.eq
      i8x16.shuffle 0 4 8 12 16 20 24 28 0 0 0 0 0 0 0 0
      v128.or
      local.get $var42
      i8x16.shuffle 0 1 2 3 4 5 6 7 24 25 26 27 28 29 30 31
      v128.any_true
      br_if $label0
      local.get $var8
      i32.eqz
      br_if $label0
      i32.const -1
      local.set $var40
      local.get $var8
      local.get $var8
      i32.const -1
      i32.add
      local.tee $var43
      i32.and
      br_if $label0
      local.get $var21
      i32.eqz
      br_if $label0
      i32.const -1
      local.set $var40
      local.get $var21
      local.get $var21
      i32.const -1
      i32.add
      local.tee $var44
      i32.and
      br_if $label0
      local.get $var30
      i32.const 0
      i32.ne
      local.get $var31
      i32.eqz
      i32.eq
      br_if $label0
      block $label1
        local.get $var29
        i32.const 1
        i32.and
        br_if $label1
        local.get $var31
        br_if $label0
      end $label1
      block $label2
        local.get $var29
        i32.const 8
        i32.and
        local.tee $var45
        i32.eqz
        br_if $label2
        local.get $var34
        i32.eqz
        br_if $label0
        local.get $var33
        i32.eqz
        br_if $label0
        local.get $var35
        i32.eqz
        br_if $label0
        local.get $var34
        i32.popcnt
        i32.const 1
        i32.gt_u
        br_if $label0
      end $label2
      block $label3
        local.get $var32
        i32.eqz
        br_if $label3
        local.get $var32
        v128.const i32x4 0x00000000 0x00000000 0x00000000 0x00000000
        v128.store align=4
        local.get $var32
        i32.const 16
        i32.add
        i32.const 0
        i32.store
      end $label3
      i32.const 0
      local.get $var3
      i32.store offset=2548
      i32.const 0
      local.get $var5
      i32.store offset=2552
      local.get $var39
      i32.const 0
      i32.store offset=108
      local.get $var39
      i32.const 0
      i32.store offset=76
      local.get $var39
      i64.const 0
      i64.store offset=68 align=4
      local.get $var39
      local.get $var31
      i32.const 1
      local.get $var31
      i32.const 1
      i32.gt_u
      select
      i32.store offset=64
      local.get $var39
      local.get $var1
      i32.store offset=60
      local.get $var39
      local.get $var30
      i32.store offset=56
      local.get $var39
      local.get $var0
      i32.store offset=52
      local.get $var28
      i32.eqz
      local.set $var46
      block $label5
        block $label4
          local.get $var39
          i32.const 52
          i32.add
          call $func17
          local.tee $var1
          i32.const 1
          i32.ge_s
          br_if $label4
          i32.const 0
          local.set $var47
          i32.const 0
          local.set $var48
          i32.const 0
          local.set $var49
          i32.const 0
          local.set $var50
          i32.const 0
          local.set $var51
          i32.const 0
          local.set $var52
          br $label5
        end $label4
        i32.const 0
        local.get $var34
        i32.const -1
        i32.add
        local.tee $var40
        local.get $var40
        local.get $var34
        i32.gt_u
        select
        local.set $var53
        local.get $var2
        i32.const -28
        i32.add
        local.set $var54
        local.get $var29
        i32.const 4
        i32.and
        local.set $var55
        local.get $var2
        i32.const -68
        i32.add
        local.set $var56
        local.get $var3
        i32.const 1
        i32.shl
        local.set $var57
        local.get $var29
        i32.const 2
        i32.and
        local.set $var58
        local.get $var0
        i32.const 1
        i32.add
        local.set $var59
        local.get $var36
        i32.const 0
        i32.ne
        local.set $var60
        local.get $var28
        i32.const 0
        i32.ne
        local.set $var61
        i32.const -1
        local.set $var62
        i32.const 0
        local.set $var47
        i32.const 0
        local.set $var52
        i32.const 0
        local.set $var51
        i32.const 0
        local.set $var50
        i32.const 0
        local.set $var49
        i32.const 0
        local.set $var48
        i32.const 0
        local.set $var31
        i32.const 0
        local.set $var63
        loop $label96
          block $label6
            local.get $var49
            local.get $var3
            i32.ne
            br_if $label6
            local.get $var12
            local.get $var3
            i32.store
            i32.const -4
            local.set $var40
            br $label0
          end $label6
          i32.const 0
          local.set $var40
          local.get $var39
          i32.const 0
          i32.store offset=48
          local.get $var39
          i32.const -1
          i32.store offset=44
          i32.const 0
          local.set $var1
          block $label7
            local.get $var55
            i32.const 0
            i32.ne
            local.get $var49
            i32.const 0
            i32.ne
            i32.and
            local.tee $var30
            i32.const 1
            i32.ne
            br_if $label7
            block $label8
              local.get $var31
              i32.eqz
              br_if $label8
              i32.const 4
              local.set $var1
              local.get $var39
              i32.const 44
              i32.add
              local.set $var40
              br $label7
            end $label8
            local.get $var39
            i32.const 44
            i32.add
            i32.const 0
            local.get $var54
            local.get $var49
            i32.const 68
            i32.mul
            i32.add
            i32.load
            i32.const 511
            i32.gt_u
            local.tee $var1
            select
            local.set $var40
          end $label7
          block $label9
            local.get $var0
            local.get $var39
            i32.load offset=72
            local.tee $var64
            local.get $var39
            i32.load offset=76
            local.get $var2
            local.get $var49
            i32.const 68
            i32.mul
            i32.add
            local.tee $var65
            local.get $var61
            local.get $var39
            i32.const 48
            i32.add
            local.get $var2
            local.get $var49
            local.get $var40
            local.get $var1
            local.get $var60
            local.get $var39
            i32.const 40
            i32.add
            call $func18
            br_if $label9
            i32.const -1
            local.set $var40
            br $label0
          end $label9
          local.get $var39
          i32.load offset=44
          local.set $var66
          block $label10
            local.get $var37
            i32.eqz
            br_if $label10
            local.get $var37
            local.get $var49
            i32.const 2
            i32.shl
            i32.add
            local.get $var66
            i32.store
          end $label10
          block $label11
            local.get $var32
            i32.eqz
            br_if $label11
            local.get $var66
            i32.const -1
            i32.eq
            br_if $label11
            local.get $var32
            local.get $var32
            i32.load offset=4
            i32.const 1
            i32.add
            i32.store offset=4
          end $label11
          block $label13
            block $label12
              local.get $var30
              br_if $label12
              local.get $var31
              local.set $var67
              br $label13
            end $label12
            i32.const 4
            local.set $var67
            local.get $var66
            i32.const -1
            i32.ne
            br_if $label13
            i32.const 0
            local.get $var31
            i32.const -1
            i32.add
            local.tee $var40
            local.get $var40
            local.get $var31
            i32.gt_u
            select
            local.set $var67
          end $label13
          local.get $var65
          i32.load offset=56
          local.set $var68
          local.get $var39
          local.get $var65
          i32.load
          local.tee $var30
          i32.store offset=36
          local.get $var39
          local.get $var65
          i32.load offset=8
          local.tee $var1
          i32.store offset=32
          local.get $var39
          local.get $var65
          i32.load offset=4
          local.tee $var36
          i32.store offset=28
          local.get $var39
          local.get $var65
          i32.load offset=12
          local.tee $var40
          i32.store offset=24
          i32.const 0
          local.set $var69
          local.get $var39
          i32.const 0
          i32.store offset=16
          local.get $var39
          i32.const 0
          i32.store offset=12
          block $label14
            local.get $var40
            i32.const 2
            i32.ne
            br_if $label14
            local.get $var0
            local.get $var1
            i32.add
            local.tee $var31
            i32.load8_u
            i32.const 34
            i32.ne
            br_if $label14
            local.get $var31
            i32.const 1
            i32.add
            i32.load8_u
            i32.const 34
            i32.eq
            local.set $var69
          end $label14
          block $label15
            local.get $var69
            br_if $label15
            local.get $var36
            local.get $var40
            i32.ne
            br_if $label15
            i32.const 0
            local.set $var31
            local.get $var0
            local.get $var30
            i32.add
            local.tee $var70
            local.set $var40
            local.get $var0
            local.get $var1
            i32.add
            local.tee $var71
            local.set $var1
            loop $label21
              block $label16
                local.get $var36
                local.get $var31
                i32.add
                i32.const 31
                i32.gt_u
                br_if $label16
                i32.const 0
                local.set $var30
                local.get $var36
                local.set $var28
                block $label18
                  loop $label19
                    block $label17
                      local.get $var31
                      local.get $var28
                      i32.add
                      i32.const 7
                      i32.gt_u
                      br_if $label17
                      local.get $var30
                      local.get $var31
                      i32.sub
                      local.tee $var40
                      local.get $var36
                      i32.lt_u
                      br_if $label18
                      i32.const 1
                      local.set $var69
                      br $label15
                    end $label17
                    local.get $var1
                    local.get $var30
                    i32.add
                    local.set $var72
                    local.get $var40
                    local.get $var30
                    i32.add
                    local.set $var73
                    local.get $var28
                    i32.const -8
                    i32.add
                    local.set $var28
                    local.get $var30
                    i32.const 8
                    i32.add
                    local.set $var30
                    local.get $var73
                    i64.load align=1
                    local.get $var72
                    i64.load align=1
                    i64.eq
                    br_if $label19
                  end $label19
                  i32.const 0
                  local.set $var69
                  br $label15
                end $label18
                loop $label20
                  local.get $var70
                  local.get $var40
                  i32.add
                  i32.load8_u
                  local.tee $var1
                  local.get $var71
                  local.get $var40
                  i32.add
                  i32.load8_u
                  local.tee $var31
                  i32.eq
                  local.set $var69
                  local.get $var1
                  local.get $var31
                  i32.ne
                  br_if $label15
                  local.get $var40
                  i32.const 1
                  i32.add
                  local.tee $var40
                  local.get $var36
                  i32.lt_u
                  br_if $label20
                  br $label15
                end $label20
              end $label16
              local.get $var40
              i32.const 16
              i32.add
              local.set $var30
              local.get $var1
              i32.const 16
              i32.add
              local.set $var28
              local.get $var40
              v128.load align=1
              local.set $var41
              local.get $var1
              v128.load align=1
              local.set $var42
              local.get $var40
              i32.const 32
              i32.add
              local.set $var40
              local.get $var1
              i32.const 32
              i32.add
              local.set $var1
              local.get $var31
              i32.const -32
              i32.add
              local.set $var31
              local.get $var28
              v128.load align=1
              local.get $var30
              v128.load align=1
              v128.xor
              local.get $var42
              local.get $var41
              v128.xor
              v128.or
              v128.any_true
              i32.eqz
              br_if $label21
            end $label21
            i32.const 0
            local.set $var69
          end $label15
          local.get $var68
          local.get $var46
          i32.or
          local.set $var46
          local.get $var2
          local.get $var49
          i32.const -1
          i32.add
          local.tee $var74
          i32.const 68
          i32.mul
          i32.add
          local.set $var75
          i32.const 0
          local.set $var73
          local.get $var39
          i32.const 36
          i32.add
          local.set $var40
          local.get $var39
          i32.const 28
          i32.add
          local.set $var1
          local.get $var39
          i32.const 16
          i32.add
          local.set $var76
          i32.const 1
          local.set $var77
          local.get $var39
          i32.load offset=40
          local.set $var78
          block $label76
            block $label63
              block $label70
                block $label67
                  block $label62
                    block $label33
                      block $label23
                        loop $label49
                          block $label22
                            local.get $var69
                            local.get $var73
                            i32.and
                            i32.const 1
                            i32.ne
                            br_if $label22
                            local.get $var39
                            local.get $var39
                            i32.load offset=16
                            i32.store offset=12
                            br $label23
                          end $label22
                          local.get $var1
                          i32.load
                          local.tee $var68
                          i32.const -2
                          i32.add
                          local.set $var36
                          local.get $var40
                          i32.load
                          local.set $var79
                          block $label43
                            block $label29
                              block $label25
                                block $label24
                                  local.get $var49
                                  i32.eqz
                                  br_if $label24
                                  local.get $var36
                                  i32.const 32
                                  i32.gt_u
                                  br_if $label24
                                  local.get $var68
                                  local.get $var75
                                  i32.const 4
                                  i32.const 12
                                  local.get $var77
                                  i32.const 1
                                  i32.and
                                  local.tee $var80
                                  select
                                  i32.add
                                  i32.load
                                  i32.ne
                                  br_if $label25
                                  local.get $var0
                                  local.get $var79
                                  i32.add
                                  local.set $var28
                                  local.get $var59
                                  local.get $var79
                                  i32.add
                                  local.set $var70
                                  local.get $var0
                                  local.get $var75
                                  i32.const 0
                                  i32.const 8
                                  local.get $var80
                                  select
                                  i32.add
                                  i32.load
                                  local.tee $var40
                                  i32.add
                                  local.set $var72
                                  local.get $var59
                                  local.get $var40
                                  i32.add
                                  local.set $var71
                                  i32.const 17
                                  local.set $var1
                                  local.get $var36
                                  local.set $var40
                                  loop $label32
                                    block $label26
                                      local.get $var40
                                      i32.const 31
                                      i32.gt_u
                                      br_if $label26
                                      local.get $var1
                                      i32.const -17
                                      i32.add
                                      local.set $var1
                                      block $label28
                                        loop $label30
                                          block $label27
                                            local.get $var40
                                            i32.const 7
                                            i32.gt_u
                                            br_if $label27
                                            local.get $var1
                                            local.get $var36
                                            i32.lt_u
                                            br_if $label28
                                            br $label29
                                          end $label27
                                          local.get $var71
                                          local.get $var1
                                          i32.add
                                          local.set $var31
                                          local.get $var70
                                          local.get $var1
                                          i32.add
                                          local.set $var30
                                          local.get $var40
                                          i32.const -8
                                          i32.add
                                          local.set $var40
                                          local.get $var1
                                          i32.const 8
                                          i32.add
                                          local.set $var1
                                          local.get $var30
                                          i64.load align=1
                                          local.get $var31
                                          i64.load align=1
                                          i64.eq
                                          br_if $label30
                                          br $label24
                                        end $label30
                                      end $label28
                                      loop $label31
                                        local.get $var70
                                        local.get $var1
                                        i32.add
                                        i32.load8_u
                                        local.get $var71
                                        local.get $var1
                                        i32.add
                                        i32.load8_u
                                        i32.ne
                                        br_if $label24
                                        local.get $var1
                                        i32.const 1
                                        i32.add
                                        local.tee $var1
                                        local.get $var36
                                        i32.ge_u
                                        br_if $label29
                                        br $label31
                                      end $label31
                                    end $label26
                                    local.get $var28
                                    local.get $var1
                                    i32.add
                                    local.set $var31
                                    local.get $var72
                                    local.get $var1
                                    i32.add
                                    local.set $var30
                                    local.get $var40
                                    i32.const -32
                                    i32.add
                                    local.set $var40
                                    local.get $var1
                                    i32.const 32
                                    i32.add
                                    local.set $var1
                                    local.get $var30
                                    v128.load align=1
                                    local.get $var31
                                    v128.load align=1
                                    v128.xor
                                    local.get $var30
                                    i32.const -16
                                    i32.add
                                    v128.load align=1
                                    local.get $var31
                                    i32.const -16
                                    i32.add
                                    v128.load align=1
                                    v128.xor
                                    v128.or
                                    v128.any_true
                                    i32.eqz
                                    br_if $label32
                                  end $label32
                                end $label24
                                local.get $var68
                                i32.const 2
                                i32.lt_u
                                br_if $label33
                              end $label25
                              block $label35
                                block $label34
                                  local.get $var78
                                  local.get $var73
                                  i32.shr_u
                                  i32.const 1
                                  i32.and
                                  br_if $label34
                                  local.get $var79
                                  i32.const 1
                                  i32.add
                                  local.set $var40
                                  local.get $var0
                                  local.set $var81
                                  br $label35
                                end $label34
                                local.get $var58
                                i32.eqz
                                br_if $label33
                                local.get $var0
                                local.get $var79
                                i32.add
                                local.get $var68
                                local.get $var13
                                local.get $var50
                                i32.add
                                local.get $var14
                                local.get $var50
                                i32.sub
                                call $func29
                                local.tee $var36
                                i32.const 0
                                i32.lt_s
                                br_if $label33
                                block $label36
                                  local.get $var32
                                  i32.eqz
                                  br_if $label36
                                  local.get $var32
                                  local.get $var32
                                  i32.load
                                  i32.const 1
                                  i32.add
                                  i32.store
                                end $label36
                                local.get $var50
                                local.set $var40
                                local.get $var13
                                local.set $var81
                              end $label35
                              local.get $var36
                              i32.const 65535
                              i32.gt_u
                              br_if $label33
                              local.get $var81
                              local.get $var40
                              i32.add
                              local.tee $var79
                              local.get $var36
                              i32.const -2128831035
                              call $func30
                              local.tee $var82
                              local.get $var36
                              i32.const -2048144789
                              i32.mul
                              i32.xor
                              local.tee $var40
                              i32.const 16
                              i32.shr_u
                              local.get $var40
                              i32.xor
                              local.get $var44
                              i32.and
                              local.set $var70
                              i32.const 0
                              local.set $var68
                              block $label37
                                loop $label47
                                  local.get $var20
                                  local.get $var70
                                  i32.const 2
                                  i32.shl
                                  i32.add
                                  i32.load
                                  local.tee $var40
                                  i32.eqz
                                  br_if $label37
                                  block $label38
                                    local.get $var40
                                    i32.const -1
                                    i32.add
                                    local.tee $var71
                                    local.get $var51
                                    i32.lt_u
                                    br_if $label38
                                    i32.const -3
                                    local.set $var40
                                    br $label0
                                  end $label38
                                  block $label39
                                    local.get $var17
                                    local.get $var71
                                    i32.const 2
                                    i32.shl
                                    local.tee $var40
                                    i32.add
                                    i32.load
                                    local.get $var82
                                    i32.ne
                                    br_if $label39
                                    local.get $var36
                                    local.get $var15
                                    local.get $var71
                                    i32.const 1
                                    i32.shl
                                    i32.add
                                    i32.load16_u
                                    i32.ne
                                    br_if $label39
                                    i32.const 0
                                    local.set $var31
                                    local.get $var13
                                    local.get $var16
                                    local.get $var40
                                    i32.add
                                    i32.load
                                    i32.add
                                    local.tee $var80
                                    local.set $var40
                                    local.get $var79
                                    local.set $var1
                                    loop $label46
                                      block $label40
                                        local.get $var36
                                        local.get $var31
                                        i32.add
                                        i32.const 31
                                        i32.gt_u
                                        br_if $label40
                                        i32.const 0
                                        local.set $var30
                                        local.get $var36
                                        local.set $var28
                                        block $label42
                                          loop $label44
                                            block $label41
                                              local.get $var31
                                              local.get $var28
                                              i32.add
                                              i32.const 7
                                              i32.gt_u
                                              br_if $label41
                                              local.get $var30
                                              local.get $var31
                                              i32.sub
                                              local.tee $var40
                                              local.get $var36
                                              i32.lt_u
                                              br_if $label42
                                              br $label43
                                            end $label41
                                            local.get $var1
                                            local.get $var30
                                            i32.add
                                            local.set $var72
                                            local.get $var40
                                            local.get $var30
                                            i32.add
                                            local.set $var73
                                            local.get $var28
                                            i32.const -8
                                            i32.add
                                            local.set $var28
                                            local.get $var30
                                            i32.const 8
                                            i32.add
                                            local.set $var30
                                            local.get $var73
                                            i64.load align=1
                                            local.get $var72
                                            i64.load align=1
                                            i64.eq
                                            br_if $label44
                                            br $label39
                                          end $label44
                                        end $label42
                                        loop $label45
                                          local.get $var80
                                          local.get $var40
                                          i32.add
                                          i32.load8_u
                                          local.get $var79
                                          local.get $var40
                                          i32.add
                                          i32.load8_u
                                          i32.ne
                                          br_if $label39
                                          local.get $var40
                                          i32.const 1
                                          i32.add
                                          local.tee $var40
                                          local.get $var36
                                          i32.ge_u
                                          br_if $label43
                                          br $label45
                                        end $label45
                                      end $label40
                                      local.get $var40
                                      i32.const 16
                                      i32.add
                                      local.set $var30
                                      local.get $var1
                                      i32.const 16
                                      i32.add
                                      local.set $var28
                                      local.get $var40
                                      v128.load align=1
                                      local.set $var41
                                      local.get $var1
                                      v128.load align=1
                                      local.set $var42
                                      local.get $var40
                                      i32.const 32
                                      i32.add
                                      local.set $var40
                                      local.get $var1
                                      i32.const 32
                                      i32.add
                                      local.set $var1
                                      local.get $var31
                                      i32.const -32
                                      i32.add
                                      local.set $var31
                                      local.get $var28
                                      v128.load align=1
                                      local.get $var30
                                      v128.load align=1
                                      v128.xor
                                      local.get $var42
                                      local.get $var41
                                      v128.xor
                                      v128.or
                                      v128.any_true
                                      i32.eqz
                                      br_if $label46
                                    end $label46
                                  end $label39
                                  local.get $var70
                                  i32.const 1
                                  i32.add
                                  local.get $var44
                                  i32.and
                                  local.set $var70
                                  local.get $var68
                                  i32.const 1
                                  i32.add
                                  local.tee $var68
                                  local.get $var21
                                  i32.ne
                                  br_if $label47
                                end $label47
                              end $label37
                              local.get $var51
                              local.get $var57
                              i32.ge_u
                              br_if $label33
                              local.get $var20
                              local.get $var70
                              i32.const 2
                              i32.shl
                              i32.add
                              local.tee $var40
                              i32.load
                              br_if $label33
                              local.get $var36
                              local.get $var50
                              i32.add
                              local.tee $var1
                              local.get $var14
                              i32.gt_u
                              br_if $label33
                              block $label48
                                local.get $var81
                                local.get $var13
                                i32.eq
                                br_if $label48
                                local.get $var13
                                local.get $var50
                                i32.add
                                local.get $var79
                                local.get $var36
                                call $func31
                                i32.eqz
                                br_if $label33
                              end $label48
                              local.get $var16
                              local.get $var51
                              i32.const 2
                              i32.shl
                              local.tee $var31
                              i32.add
                              local.get $var50
                              i32.store
                              local.get $var17
                              local.get $var31
                              i32.add
                              local.get $var82
                              i32.store
                              local.get $var15
                              local.get $var51
                              i32.const 1
                              i32.shl
                              i32.add
                              local.get $var36
                              i32.store16
                              local.get $var40
                              local.get $var51
                              i32.const 1
                              i32.add
                              local.tee $var31
                              i32.store
                              local.get $var51
                              local.set $var71
                              local.get $var1
                              local.set $var50
                              local.get $var31
                              local.set $var51
                              br $label43
                            end $label29
                            local.get $var18
                            local.get $var19
                            local.get $var80
                            select
                            local.get $var74
                            i32.const 2
                            i32.shl
                            i32.add
                            i32.load
                            local.set $var71
                          end $label43
                          local.get $var76
                          local.get $var71
                          i32.store
                          i32.const 1
                          local.set $var73
                          local.get $var77
                          i32.const 1
                          i32.and
                          local.set $var31
                          local.get $var39
                          i32.const 32
                          i32.add
                          local.set $var40
                          local.get $var39
                          i32.const 24
                          i32.add
                          local.set $var1
                          local.get $var39
                          i32.const 12
                          i32.add
                          local.set $var76
                          i32.const 0
                          local.set $var77
                          local.get $var31
                          br_if $label49
                        end $label49
                      end $label23
                      local.get $var18
                      local.get $var49
                      i32.const 2
                      i32.shl
                      local.tee $var72
                      i32.add
                      local.get $var39
                      i32.load offset=16
                      i32.store
                      local.get $var19
                      local.get $var72
                      i32.add
                      local.get $var39
                      i32.load offset=12
                      i32.store
                      local.get $var24
                      local.get $var49
                      i32.add
                      local.get $var69
                      i32.store8
                      local.get $var65
                      i32.load offset=32
                      local.tee $var36
                      local.get $var64
                      i32.ge_u
                      br_if $label33
                      local.get $var36
                      local.set $var31
                      block $label51
                        loop $label54
                          block $label50
                            local.get $var64
                            local.get $var31
                            local.tee $var40
                            i32.ne
                            br_if $label50
                            local.get $var64
                            local.set $var40
                            br $label51
                          end $label50
                          block $label52
                            block $label53
                              local.get $var0
                              local.get $var40
                              i32.add
                              i32.load8_u
                              local.tee $var1
                              i32.const -10
                              i32.add
                              br_table $label51 $label52 $label52 $label51 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label51 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label52 $label51 $label53
                            end $label53
                            local.get $var1
                            i32.const 93
                            i32.eq
                            br_if $label51
                            local.get $var1
                            i32.const 125
                            i32.eq
                            br_if $label51
                          end $label52
                          local.get $var40
                          i32.const 1
                          i32.add
                          local.set $var31
                          local.get $var1
                          i32.const 9
                          i32.ne
                          br_if $label54
                        end $label54
                      end $label51
                      local.get $var40
                      local.get $var36
                      i32.eq
                      br_if $label33
                      block $label60
                        block $label56
                          block $label55
                            local.get $var40
                            local.get $var36
                            i32.sub
                            i32.const 4
                            i32.ne
                            br_if $label55
                            local.get $var0
                            local.get $var36
                            i32.add
                            local.tee $var1
                            i32.load8_u
                            i32.const 110
                            i32.ne
                            br_if $label55
                            local.get $var1
                            i32.const 1
                            i32.add
                            i32.load8_u
                            i32.const 117
                            i32.ne
                            br_if $label55
                            local.get $var1
                            i32.const 2
                            i32.add
                            i32.load8_u
                            i32.const 108
                            i32.ne
                            br_if $label55
                            local.get $var1
                            i32.const 3
                            i32.add
                            i32.load8_u
                            i32.const 108
                            i32.eq
                            br_if $label56
                          end $label55
                          i32.const 1
                          local.set $var73
                          local.get $var36
                          local.set $var31
                          block $label57
                            local.get $var40
                            local.get $var36
                            i32.le_u
                            br_if $label57
                            local.get $var0
                            local.get $var36
                            i32.add
                            i32.load8_u
                            local.tee $var1
                            i32.const 45
                            i32.ne
                            local.set $var73
                            local.get $var36
                            local.get $var1
                            i32.const 45
                            i32.eq
                            i32.add
                            local.set $var31
                          end $label57
                          local.get $var40
                          local.get $var31
                          i32.le_u
                          br_if $label33
                          local.get $var0
                          local.get $var31
                          i32.add
                          local.tee $var1
                          i32.load8_u
                          local.tee $var30
                          i32.const -58
                          i32.add
                          i32.const 255
                          i32.and
                          i32.const 246
                          i32.lt_u
                          br_if $label33
                          block $label58
                            local.get $var31
                            i32.const 1
                            i32.add
                            local.get $var40
                            i32.ge_u
                            br_if $label58
                            local.get $var30
                            i32.const 255
                            i32.and
                            i32.const 48
                            i32.eq
                            br_if $label33
                          end $label58
                          i32.const 2147483647
                          i32.const -2147483648
                          local.get $var73
                          select
                          local.set $var28
                          local.get $var40
                          local.get $var31
                          i32.sub
                          local.set $var30
                          i32.const 0
                          local.set $var40
                          loop $label59
                            local.get $var1
                            i32.load8_u
                            local.tee $var31
                            i32.const -58
                            i32.add
                            i32.const 255
                            i32.and
                            i32.const 246
                            i32.lt_u
                            br_if $label33
                            local.get $var40
                            local.get $var28
                            local.get $var31
                            i32.const -48
                            i32.add
                            local.tee $var31
                            i32.sub
                            i32.const 10
                            i32.div_u
                            i32.gt_u
                            br_if $label33
                            local.get $var1
                            i32.const 1
                            i32.add
                            local.set $var1
                            local.get $var31
                            local.get $var40
                            i32.const 10
                            i32.mul
                            i32.add
                            local.set $var40
                            local.get $var30
                            i32.const -1
                            i32.add
                            local.tee $var30
                            br_if $label59
                          end $label59
                          local.get $var40
                          i32.const 0
                          local.get $var40
                          i32.sub
                          local.get $var73
                          select
                          local.tee $var40
                          br_if $label60
                          local.get $var0
                          local.get $var36
                          i32.add
                          i32.load8_u
                          i32.const 45
                          i32.eq
                          br_if $label33
                        end $label56
                        i32.const 0
                        local.set $var40
                      end $label60
                      local.get $var25
                      local.get $var72
                      i32.add
                      local.get $var40
                      i32.store
                      i32.const -1
                      local.set $var40
                      local.get $var39
                      i32.const -1
                      i32.store offset=8
                      block $label61
                        local.get $var65
                        i32.load offset=44
                        local.tee $var1
                        i32.const -1
                        i32.eq
                        br_if $label61
                        local.get $var39
                        i32.const 0
                        i32.store offset=4
                        local.get $var0
                        local.get $var64
                        local.get $var1
                        local.get $var39
                        i32.const 4
                        i32.add
                        call $func37
                        i32.eqz
                        br_if $label33
                        local.get $var0
                        local.get $var1
                        local.get $var39
                        i32.load offset=4
                        i32.const -1
                        local.get $var39
                        i32.const 8
                        i32.add
                        call $func38
                        i32.eqz
                        br_if $label33
                        local.get $var39
                        i32.load offset=8
                        local.set $var40
                      end $label61
                      local.get $var26
                      local.get $var72
                      i32.add
                      local.get $var40
                      i32.store
                      local.get $var45
                      i32.eqz
                      br_if $label62
                      local.get $var35
                      local.get $var72
                      i32.add
                      local.get $var0
                      local.get $var65
                      call $func39
                      local.tee $var30
                      i32.store
                      local.get $var34
                      i32.eqz
                      br_if $label63
                      local.get $var34
                      local.set $var1
                      local.get $var30
                      local.set $var40
                      loop $label68
                        block $label64
                          local.get $var33
                          local.get $var40
                          local.get $var53
                          i32.and
                          local.tee $var31
                          i32.const 2
                          i32.shl
                          i32.add
                          local.tee $var28
                          i32.load
                          local.tee $var40
                          br_if $label64
                          local.get $var28
                          local.get $var49
                          i32.const 1
                          i32.add
                          i32.store
                          br $label63
                        end $label64
                        block $label65
                          local.get $var40
                          i32.const -1
                          i32.add
                          local.tee $var40
                          local.get $var49
                          i32.lt_u
                          br_if $label65
                          i32.const -3
                          local.set $var40
                          br $label0
                        end $label65
                        block $label66
                          local.get $var35
                          local.get $var40
                          i32.const 2
                          i32.shl
                          i32.add
                          i32.load
                          local.get $var30
                          i32.ne
                          br_if $label66
                          local.get $var0
                          local.get $var65
                          local.get $var2
                          local.get $var40
                          i32.const 68
                          i32.mul
                          i32.add
                          local.get $var40
                          local.get $var66
                          i32.eq
                          call $func40
                          i32.eqz
                          br_if $label66
                          local.get $var32
                          i32.eqz
                          br_if $label67
                          local.get $var32
                          local.get $var32
                          i32.load offset=8
                          i32.const 1
                          i32.add
                          i32.store offset=8
                          br $label67
                        end $label66
                        local.get $var31
                        i32.const 1
                        i32.add
                        local.set $var40
                        local.get $var1
                        i32.const -1
                        i32.add
                        local.tee $var1
                        br_if $label68
                        br $label63
                      end $label68
                    end $label33
                    local.get $var12
                    local.get $var49
                    i32.store
                    i32.const -5
                    local.set $var40
                    br $label0
                  end $label62
                  block $label69
                    local.get $var66
                    i32.const -1
                    i32.eq
                    br_if $label69
                    local.get $var0
                    local.get $var65
                    local.get $var2
                    local.get $var66
                    i32.const 68
                    i32.mul
                    i32.add
                    i32.const 1
                    call $func40
                    i32.eqz
                    br_if $label69
                    local.get $var39
                    i32.const 80
                    i32.add
                    local.get $var49
                    i32.const 3
                    i32.and
                    i32.const 2
                    i32.shl
                    i32.or
                    local.get $var39
                    i32.const 80
                    i32.add
                    local.get $var66
                    i32.const 3
                    i32.and
                    i32.const 2
                    i32.shl
                    i32.or
                    i32.load
                    i32.store
                    local.get $var66
                    local.set $var40
                    br $label67
                  end $label69
                  local.get $var0
                  local.get $var65
                  call $func41
                  local.set $var30
                  local.get $var56
                  local.set $var1
                  local.get $var62
                  local.set $var40
                  local.get $var49
                  i32.const 0
                  local.get $var49
                  i32.const -4
                  i32.add
                  local.tee $var31
                  local.get $var31
                  local.get $var49
                  i32.gt_u
                  select
                  local.tee $var28
                  i32.le_u
                  br_if $label70
                  block $label72
                    loop $label73
                      block $label71
                        local.get $var39
                        i32.const 80
                        i32.add
                        local.get $var40
                        i32.const 3
                        i32.and
                        i32.const 2
                        i32.shl
                        i32.or
                        i32.load
                        local.get $var30
                        i32.ne
                        br_if $label71
                        local.get $var0
                        local.get $var65
                        local.get $var1
                        local.get $var66
                        local.get $var40
                        i32.eq
                        call $func40
                        br_if $label72
                      end $label71
                      local.get $var1
                      i32.const -68
                      i32.add
                      local.set $var1
                      local.get $var40
                      local.get $var28
                      i32.gt_u
                      local.set $var31
                      local.get $var40
                      i32.const -1
                      i32.add
                      local.set $var40
                      local.get $var31
                      i32.eqz
                      br_if $label70
                      br $label73
                    end $label73
                  end $label72
                  local.get $var39
                  i32.const 80
                  i32.add
                  local.get $var49
                  i32.const 3
                  i32.and
                  i32.const 2
                  i32.shl
                  i32.or
                  local.get $var30
                  i32.store
                end $label67
                block $label75
                  block $label74
                    local.get $var55
                    br_if $label74
                    local.get $var67
                    local.set $var31
                    br $label75
                  end $label74
                  i32.const 4
                  local.set $var31
                  local.get $var63
                  i32.const 3
                  i32.gt_u
                  br_if $label75
                  i32.const 4
                  local.get $var67
                  local.get $var63
                  i32.const 3
                  i32.eq
                  select
                  local.set $var31
                  local.get $var63
                  i32.const 1
                  i32.add
                  local.set $var63
                end $label75
                local.get $var6
                local.get $var72
                i32.const 2
                i32.shl
                i32.add
                local.get $var6
                local.get $var40
                i32.const 4
                i32.shl
                i32.add
                v128.load align=4
                v128.store align=4
                local.get $var9
                local.get $var72
                i32.add
                local.get $var9
                local.get $var40
                i32.const 2
                i32.shl
                i32.add
                i32.load
                i32.store
                local.get $var48
                i32.const 1
                i32.add
                local.set $var48
                br $label76
              end $label70
              local.get $var39
              i32.const 80
              i32.add
              local.get $var49
              i32.const 3
              i32.and
              i32.const 2
              i32.shl
              i32.or
              local.get $var30
              i32.store
            end $label63
            local.get $var39
            i32.const 0
            i32.store offset=4
            local.get $var39
            i32.const 0
            i32.store
            block $label77
              local.get $var0
              local.get $var65
              local.get $var4
              local.get $var5
              local.get $var39
              i32.const 108
              i32.add
              local.get $var39
              i32.const 4
              i32.add
              local.get $var39
              local.get $var29
              local.get $var32
              call $func27
              br_if $label77
              loop $label80
                local.get $var39
                local.get $var47
                i32.store offset=108
                i32.const -2
                local.set $var40
                local.get $var5
                i32.const 2147483646
                i32.gt_u
                br_if $label0
                local.get $var4
                local.get $var5
                i32.const 7
                i32.add
                i32.const -8
                i32.and
                local.tee $var31
                i32.const -1
                i32.xor
                i32.gt_u
                br_if $label0
                i32.const 0
                i32.load offset=2544
                local.get $var31
                local.get $var4
                i32.add
                local.tee $var1
                i32.ne
                br_if $label0
                i32.const 2147483647
                local.get $var5
                i32.const 1
                i32.shr_u
                local.tee $var30
                i32.const 1048576
                local.get $var30
                i32.const 1048576
                i32.gt_u
                select
                local.tee $var30
                local.get $var5
                i32.add
                local.get $var5
                local.get $var30
                i32.const 2147483647
                i32.xor
                i32.gt_u
                select
                local.tee $var5
                local.get $var31
                i32.sub
                i32.const 7
                i32.add
                local.set $var30
                local.get $var1
                local.set $var31
                block $label78
                  local.get $var1
                  br_if $label78
                  i32.const 104256
                  local.set $var31
                  i32.const 0
                  i32.const 104256
                  i32.store offset=2544
                end $label78
                local.get $var31
                i32.const 7
                i32.add
                i32.const -8
                i32.and
                local.tee $var31
                local.get $var30
                i32.const -8
                i32.and
                local.tee $var30
                i32.const -1
                i32.xor
                i32.gt_u
                br_if $label0
                block $label79
                  local.get $var31
                  local.get $var30
                  i32.add
                  local.tee $var30
                  i32.const 16
                  i32.shr_u
                  local.get $var30
                  i32.const 65528
                  i32.and
                  i32.const 0
                  i32.ne
                  i32.add
                  local.tee $var28
                  memory.size
                  local.tee $var36
                  i32.le_u
                  br_if $label79
                  local.get $var28
                  local.get $var36
                  i32.sub
                  memory.grow
                  i32.const 0
                  i32.lt_s
                  br_if $label0
                end $label79
                i32.const 0
                local.get $var30
                i32.store offset=2544
                local.get $var31
                i32.eqz
                br_if $label0
                local.get $var31
                local.get $var1
                i32.ne
                br_if $label0
                i32.const 0
                local.get $var5
                i32.store offset=2552
                local.get $var0
                local.get $var65
                local.get $var4
                local.get $var5
                local.get $var39
                i32.const 108
                i32.add
                local.get $var39
                i32.const 4
                i32.add
                local.get $var39
                local.get $var29
                local.get $var32
                call $func27
                i32.eqz
                br_if $label80
              end $label80
            end $label77
            local.get $var39
            i32.load
            local.tee $var73
            i32.const -1640531535
            i32.mul
            local.get $var39
            i32.load offset=4
            local.tee $var28
            i32.xor
            local.tee $var40
            i32.const 16
            i32.shr_u
            local.get $var40
            i32.xor
            local.get $var43
            i32.and
            local.set $var1
            local.get $var39
            i32.load offset=108
            local.tee $var70
            local.get $var47
            i32.sub
            local.set $var36
            local.get $var8
            local.set $var31
            block $label89
              block $label86
                block $label87
                  block $label84
                    block $label81
                      loop $label85
                        local.get $var7
                        local.get $var1
                        i32.const 2
                        i32.shl
                        i32.add
                        i32.load
                        local.tee $var40
                        i32.eqz
                        br_if $label81
                        block $label82
                          local.get $var40
                          i32.const -1
                          i32.add
                          local.tee $var40
                          local.get $var49
                          i32.lt_u
                          br_if $label82
                          i32.const -3
                          local.set $var40
                          br $label0
                        end $label82
                        block $label83
                          local.get $var6
                          local.get $var40
                          i32.const 4
                          i32.shl
                          i32.add
                          local.tee $var30
                          i32.load offset=8
                          local.get $var28
                          i32.ne
                          br_if $label83
                          local.get $var30
                          i32.load offset=12
                          local.get $var73
                          i32.ne
                          br_if $label83
                          local.get $var30
                          i32.load offset=4
                          local.get $var36
                          i32.ne
                          br_if $label83
                          local.get $var4
                          local.get $var30
                          i32.load
                          local.tee $var30
                          local.get $var47
                          local.get $var36
                          call $func32
                          br_if $label84
                        end $label83
                        local.get $var1
                        i32.const 1
                        i32.add
                        local.get $var43
                        i32.and
                        local.set $var1
                        local.get $var31
                        i32.const -1
                        i32.add
                        local.tee $var31
                        br_if $label85
                      end $label85
                    end $label81
                    i32.const -3
                    local.set $var40
                    local.get $var7
                    local.get $var1
                    i32.const 2
                    i32.shl
                    i32.add
                    local.tee $var68
                    i32.load
                    br_if $label0
                    local.get $var52
                    i32.const -1
                    i32.eq
                    br_if $label0
                    local.get $var6
                    local.get $var72
                    i32.const 2
                    i32.shl
                    i32.add
                    local.tee $var40
                    local.get $var73
                    i32.store offset=12
                    local.get $var40
                    local.get $var28
                    i32.store offset=8
                    local.get $var40
                    local.get $var36
                    i32.store offset=4
                    local.get $var40
                    local.get $var47
                    i32.store
                    local.get $var9
                    local.get $var72
                    i32.add
                    local.get $var52
                    i32.store
                    i32.const 0
                    local.set $var31
                    i32.const 0
                    local.get $var36
                    i32.const -4
                    i32.add
                    local.tee $var40
                    local.get $var40
                    local.get $var36
                    i32.gt_u
                    select
                    local.set $var72
                    local.get $var4
                    local.get $var47
                    i32.add
                    local.set $var71
                    i32.const 0
                    local.set $var30
                    local.get $var70
                    local.get $var47
                    i32.eq
                    br_if $label86
                    local.get $var36
                    i32.const 3
                    i32.gt_u
                    br_if $label87
                    i32.const 0
                    local.set $var40
                    local.get $var71
                    local.set $var1
                    local.get $var36
                    local.set $var28
                    i32.const 0
                    local.set $var30
                    loop $label88
                      local.get $var1
                      i32.load8_u
                      local.get $var40
                      i32.shl
                      local.get $var30
                      i32.or
                      local.set $var30
                      local.get $var1
                      i32.const 1
                      i32.add
                      local.set $var1
                      local.get $var40
                      i32.const 8
                      i32.add
                      local.set $var40
                      local.get $var28
                      i32.const -1
                      i32.add
                      local.tee $var28
                      br_if $label88
                      br $label86
                    end $label88
                  end $label84
                  local.get $var6
                  local.get $var72
                  i32.const 2
                  i32.shl
                  i32.add
                  local.tee $var1
                  local.get $var73
                  i32.store offset=12
                  local.get $var1
                  local.get $var28
                  i32.store offset=8
                  local.get $var1
                  local.get $var36
                  i32.store offset=4
                  local.get $var1
                  local.get $var30
                  i32.store
                  local.get $var9
                  local.get $var72
                  i32.add
                  local.get $var9
                  local.get $var40
                  i32.const 2
                  i32.shl
                  i32.add
                  i32.load
                  i32.store
                  local.get $var39
                  local.get $var47
                  i32.store offset=108
                  i32.const 0
                  local.set $var63
                  br $label89
                end $label87
                local.get $var71
                i32.load align=1
                local.set $var30
              end $label86
              local.get $var11
              local.get $var52
              i32.const 12
              i32.mul
              i32.add
              local.tee $var73
              local.get $var30
              i32.store
              block $label90
                local.get $var36
                local.get $var72
                i32.const 1
                i32.shr_u
                local.tee $var1
                i32.le_u
                br_if $label90
                local.get $var71
                local.get $var1
                i32.add
                local.set $var40
                block $label91
                  local.get $var36
                  local.get $var1
                  i32.sub
                  local.tee $var30
                  i32.const 3
                  i32.gt_u
                  br_if $label91
                  i32.const 0
                  local.set $var1
                  i32.const 0
                  local.set $var31
                  loop $label92
                    local.get $var40
                    i32.load8_u
                    local.get $var1
                    i32.shl
                    local.get $var31
                    i32.or
                    local.set $var31
                    local.get $var40
                    i32.const 1
                    i32.add
                    local.set $var40
                    local.get $var1
                    i32.const 8
                    i32.add
                    local.set $var1
                    local.get $var30
                    i32.const -1
                    i32.add
                    local.tee $var30
                    br_if $label92
                    br $label90
                  end $label92
                end $label91
                local.get $var40
                i32.load align=1
                local.set $var31
              end $label90
              local.get $var73
              i32.const 4
              i32.add
              local.get $var31
              i32.store
              i32.const 0
              local.set $var63
              i32.const 0
              local.set $var31
              block $label93
                local.get $var36
                local.get $var72
                i32.le_u
                br_if $label93
                block $label94
                  local.get $var36
                  local.get $var72
                  i32.sub
                  local.tee $var1
                  i32.const 3
                  i32.gt_u
                  br_if $label94
                  local.get $var4
                  local.get $var70
                  i32.add
                  local.set $var28
                  i32.const 0
                  local.set $var40
                  i32.const 0
                  local.get $var1
                  i32.sub
                  local.set $var1
                  i32.const 0
                  local.set $var31
                  loop $label95
                    local.get $var28
                    local.get $var1
                    i32.add
                    i32.load8_u
                    local.get $var40
                    i32.shl
                    local.get $var31
                    i32.or
                    local.set $var31
                    local.get $var40
                    i32.const 8
                    i32.add
                    local.set $var40
                    local.get $var1
                    i32.const 1
                    i32.add
                    local.tee $var30
                    local.set $var1
                    local.get $var30
                    br_if $label95
                    br $label93
                  end $label95
                end $label94
                local.get $var71
                local.get $var72
                i32.add
                i32.load align=1
                local.set $var31
              end $label93
              local.get $var73
              i32.const 8
              i32.add
              local.get $var31
              i32.store
              local.get $var68
              local.get $var49
              i32.const 1
              i32.add
              i32.store
              local.get $var52
              i32.const 1
              i32.add
              local.set $var52
              local.get $var70
              local.set $var47
            end $label89
            local.get $var67
            local.set $var31
          end $label76
          local.get $var56
          i32.const 68
          i32.add
          local.set $var56
          local.get $var62
          i32.const 1
          i32.add
          local.set $var62
          local.get $var49
          i32.const 1
          i32.add
          local.set $var49
          local.get $var39
          i32.const 52
          i32.add
          local.get $var39
          i32.load offset=48
          call $func19
          local.tee $var1
          i32.const 0
          i32.gt_s
          br_if $label96
        end $label96
      end $label5
      i32.const -1
      local.set $var40
      local.get $var1
      i32.const 0
      i32.lt_s
      br_if $label0
      local.get $var10
      local.get $var52
      i32.store
      local.get $var12
      local.get $var49
      i32.store
      local.get $var22
      local.get $var51
      i32.store
      local.get $var23
      local.get $var50
      i32.store
      local.get $var27
      local.get $var48
      i32.store
      block $label97
        local.get $var38
        i32.eqz
        br_if $label97
        local.get $var38
        local.get $var46
        i32.store
      end $label97
      local.get $var47
      local.set $var40
    end $label0
    local.get $var39
    i32.const 112
    i32.add
    global.set $global0
    local.get $var40
  )
  (func $func37 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (result i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    i32.const 0
    local.set $var4
    block $label0
      local.get $var2
      local.get $var1
      i32.ge_u
      br_if $label0
      local.get $var2
      local.set $var5
      block $label2
        loop $label5
          block $label1
            local.get $var1
            local.get $var5
            local.tee $var6
            i32.ne
            br_if $label1
            local.get $var1
            local.set $var6
            br $label2
          end $label1
          block $label3
            block $label4
              local.get $var0
              local.get $var6
              i32.add
              i32.load8_u
              local.tee $var7
              i32.const -10
              i32.add
              br_table $label2 $label3 $label3 $label2 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label2 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label2 $label4
            end $label4
            local.get $var7
            i32.const 93
            i32.eq
            br_if $label2
            local.get $var7
            i32.const 125
            i32.eq
            br_if $label2
          end $label3
          local.get $var6
          i32.const 1
          i32.add
          local.set $var5
          local.get $var7
          i32.const 9
          i32.ne
          br_if $label5
        end $label5
      end $label2
      local.get $var6
      local.get $var2
      i32.eq
      br_if $label0
      local.get $var3
      local.get $var6
      i32.store
      i32.const 1
      local.set $var4
    end $label0
    local.get $var4
  )
  (func $func38 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (result i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    block $label3
      block $label1
        block $label0
          local.get $var2
          local.get $var1
          i32.sub
          i32.const 4
          i32.ne
          br_if $label0
          local.get $var0
          local.get $var1
          i32.add
          local.tee $var5
          i32.load8_u
          i32.const 110
          i32.ne
          br_if $label0
          local.get $var5
          i32.const 1
          i32.add
          i32.load8_u
          i32.const 117
          i32.ne
          br_if $label0
          local.get $var5
          i32.const 2
          i32.add
          i32.load8_u
          i32.const 108
          i32.ne
          br_if $label0
          local.get $var5
          i32.const 3
          i32.add
          i32.load8_u
          i32.const 108
          i32.eq
          br_if $label1
        end $label0
        i32.const 1
        local.set $var6
        block $label2
          local.get $var2
          local.get $var1
          i32.le_u
          br_if $label2
          local.get $var0
          local.get $var1
          i32.add
          i32.load8_u
          local.tee $var3
          i32.const 45
          i32.ne
          local.set $var6
          local.get $var1
          local.get $var3
          i32.const 45
          i32.eq
          i32.add
          local.set $var1
        end $label2
        i32.const 0
        local.set $var5
        local.get $var2
        local.get $var1
        i32.le_u
        br_if $label3
        local.get $var0
        local.get $var1
        i32.add
        local.tee $var0
        i32.load8_u
        local.tee $var3
        i32.const -58
        i32.add
        i32.const 255
        i32.and
        i32.const 246
        i32.lt_u
        br_if $label3
        block $label4
          local.get $var1
          i32.const 1
          i32.add
          local.get $var2
          i32.ge_u
          br_if $label4
          local.get $var3
          i32.const 255
          i32.and
          i32.const 48
          i32.eq
          br_if $label3
        end $label4
        i32.const 2147483647
        i32.const -2147483648
        local.get $var6
        select
        local.set $var7
        local.get $var2
        local.get $var1
        i32.sub
        local.set $var3
        i32.const 0
        local.set $var5
        i32.const 0
        local.set $var1
        loop $label5
          local.get $var0
          i32.load8_u
          local.tee $var2
          i32.const -58
          i32.add
          i32.const 255
          i32.and
          i32.const 246
          i32.lt_u
          br_if $label3
          local.get $var1
          local.get $var7
          local.get $var2
          i32.const -48
          i32.add
          local.tee $var2
          i32.sub
          i32.const 10
          i32.div_u
          i32.gt_u
          br_if $label3
          local.get $var0
          i32.const 1
          i32.add
          local.set $var0
          local.get $var2
          local.get $var1
          i32.const 10
          i32.mul
          i32.add
          local.set $var1
          local.get $var3
          i32.const -1
          i32.add
          local.tee $var3
          br_if $label5
        end $label5
        local.get $var1
        i32.const 0
        local.get $var1
        i32.sub
        local.get $var6
        select
        local.set $var3
      end $label1
      local.get $var4
      local.get $var3
      i32.store
      i32.const 1
      local.set $var5
    end $label3
    local.get $var5
  )
  (func $func39 (param $var0 i32) (param $var1 i32) (result i32)
    (local $var2 i32)
    (local $var3 i32)
    (local $var4 i32)
    local.get $var0
    local.get $var1
    i32.load offset=36
    i32.add
    local.get $var1
    i32.load offset=40
    i32.const -2128831035
    call $func30
    local.set $var2
    local.get $var0
    local.get $var1
    i32.load offset=24
    i32.add
    local.get $var1
    i32.load offset=28
    i32.const -1640531527
    call $func30
    local.set $var3
    local.get $var0
    local.get $var1
    i32.load offset=16
    i32.add
    local.get $var1
    i32.load offset=20
    i32.const -2048144789
    call $func30
    local.set $var4
    i32.const 1
    local.get $var0
    local.get $var1
    i32.load offset=48
    i32.add
    local.get $var1
    i32.load offset=52
    i32.const -1028477387
    call $func30
    i32.const 17
    i32.rotl
    local.tee $var1
    local.get $var2
    local.get $var3
    i32.const 5
    i32.rotl
    i32.xor
    local.get $var4
    i32.const 11
    i32.rotl
    i32.xor
    local.tee $var0
    i32.xor
    local.tee $var2
    i32.const 16
    i32.shr_u
    local.get $var2
    i32.xor
    local.get $var0
    local.get $var1
    i32.eq
    select
  )
  (func $func40 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (result i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i64)
    (local $var11 i64)
    (local $var12 i32)
    i32.const 0
    local.set $var4
    block $label0
      local.get $var1
      i32.load offset=40
      local.tee $var5
      local.get $var2
      i32.load offset=40
      i32.ne
      br_if $label0
      block $label6
        block $label1
          local.get $var3
          br_if $label1
          local.get $var0
          local.get $var2
          i32.load offset=36
          i32.add
          local.set $var6
          local.get $var0
          local.get $var1
          i32.load offset=36
          i32.add
          local.set $var7
          i32.const 0
          local.set $var3
          local.get $var5
          local.set $var8
          loop $label8
            block $label2
              local.get $var8
              i32.const 31
              i32.gt_u
              br_if $label2
              i32.const 0
              local.get $var3
              i32.sub
              local.set $var8
              local.get $var6
              local.get $var3
              i32.add
              local.set $var9
              local.get $var7
              local.get $var3
              i32.add
              local.set $var3
              block $label4
                loop $label5
                  block $label3
                    local.get $var5
                    local.get $var8
                    i32.add
                    i32.const 7
                    i32.gt_u
                    br_if $label3
                    i32.const 0
                    local.get $var8
                    i32.sub
                    local.tee $var3
                    local.get $var5
                    i32.ge_u
                    br_if $label1
                    br $label4
                  end $label3
                  local.get $var8
                  i32.const -8
                  i32.add
                  local.set $var8
                  local.get $var9
                  i64.load align=1
                  local.set $var10
                  local.get $var3
                  i64.load align=1
                  local.set $var11
                  local.get $var3
                  i32.const 8
                  i32.add
                  local.set $var3
                  local.get $var9
                  i32.const 8
                  i32.add
                  local.set $var9
                  local.get $var11
                  local.get $var10
                  i64.eq
                  br_if $label5
                  br $label6
                end $label5
              end $label4
              loop $label7
                local.get $var7
                local.get $var3
                i32.add
                i32.load8_u
                local.get $var6
                local.get $var3
                i32.add
                i32.load8_u
                i32.ne
                br_if $label6
                local.get $var3
                i32.const 1
                i32.add
                local.tee $var3
                local.get $var5
                i32.ge_u
                br_if $label1
                br $label7
              end $label7
            end $label2
            local.get $var7
            local.get $var3
            i32.add
            local.set $var9
            local.get $var6
            local.get $var3
            i32.add
            local.set $var12
            local.get $var8
            i32.const -32
            i32.add
            local.set $var8
            local.get $var3
            i32.const 32
            i32.add
            local.set $var3
            local.get $var12
            i32.const 16
            i32.add
            v128.load align=1
            local.get $var9
            i32.const 16
            i32.add
            v128.load align=1
            v128.xor
            local.get $var12
            v128.load align=1
            local.get $var9
            v128.load align=1
            v128.xor
            v128.or
            v128.any_true
            i32.eqz
            br_if $label8
            br $label6
          end $label8
        end $label1
        local.get $var1
        i32.load offset=28
        local.tee $var5
        local.get $var2
        i32.load offset=28
        i32.ne
        br_if $label0
        local.get $var0
        local.get $var2
        i32.load offset=24
        i32.add
        local.set $var6
        local.get $var0
        local.get $var1
        i32.load offset=24
        i32.add
        local.set $var7
        i32.const 0
        local.set $var3
        local.get $var5
        local.set $var8
        loop $label28
          block $label9
            local.get $var8
            i32.const 31
            i32.gt_u
            br_if $label9
            i32.const 0
            local.get $var3
            i32.sub
            local.set $var8
            local.get $var6
            local.get $var3
            i32.add
            local.set $var9
            local.get $var7
            local.get $var3
            i32.add
            local.set $var3
            block $label11
              block $label12
                loop $label13
                  block $label10
                    local.get $var5
                    local.get $var8
                    i32.add
                    i32.const 7
                    i32.gt_u
                    br_if $label10
                    i32.const 0
                    local.set $var4
                    i32.const 0
                    local.get $var8
                    i32.sub
                    local.tee $var3
                    local.get $var5
                    i32.ge_u
                    br_if $label11
                    br $label12
                  end $label10
                  local.get $var8
                  i32.const -8
                  i32.add
                  local.set $var8
                  local.get $var9
                  i64.load align=1
                  local.set $var10
                  local.get $var3
                  i64.load align=1
                  local.set $var11
                  local.get $var3
                  i32.const 8
                  i32.add
                  local.set $var3
                  local.get $var9
                  i32.const 8
                  i32.add
                  local.set $var9
                  local.get $var11
                  local.get $var10
                  i64.eq
                  br_if $label13
                  br $label6
                end $label13
              end $label12
              loop $label14
                local.get $var7
                local.get $var3
                i32.add
                i32.load8_u
                local.get $var6
                local.get $var3
                i32.add
                i32.load8_u
                i32.ne
                br_if $label0
                local.get $var3
                i32.const 1
                i32.add
                local.tee $var3
                local.get $var5
                i32.lt_u
                br_if $label14
              end $label14
            end $label11
            local.get $var1
            i32.load offset=20
            local.tee $var5
            local.get $var2
            i32.load offset=20
            i32.ne
            br_if $label0
            local.get $var0
            local.get $var2
            i32.load offset=16
            i32.add
            local.set $var6
            local.get $var0
            local.get $var1
            i32.load offset=16
            i32.add
            local.set $var7
            i32.const 0
            local.set $var3
            local.get $var5
            local.set $var8
            loop $label27
              block $label15
                local.get $var8
                i32.const 31
                i32.gt_u
                br_if $label15
                i32.const 0
                local.get $var3
                i32.sub
                local.set $var8
                local.get $var6
                local.get $var3
                i32.add
                local.set $var9
                local.get $var7
                local.get $var3
                i32.add
                local.set $var3
                block $label17
                  block $label18
                    loop $label19
                      block $label16
                        local.get $var5
                        local.get $var8
                        i32.add
                        i32.const 7
                        i32.gt_u
                        br_if $label16
                        i32.const 0
                        local.set $var4
                        i32.const 0
                        local.get $var8
                        i32.sub
                        local.tee $var3
                        local.get $var5
                        i32.ge_u
                        br_if $label17
                        br $label18
                      end $label16
                      local.get $var8
                      i32.const -8
                      i32.add
                      local.set $var8
                      local.get $var9
                      i64.load align=1
                      local.set $var10
                      local.get $var3
                      i64.load align=1
                      local.set $var11
                      i32.const 0
                      local.set $var4
                      local.get $var3
                      i32.const 8
                      i32.add
                      local.set $var3
                      local.get $var9
                      i32.const 8
                      i32.add
                      local.set $var9
                      local.get $var11
                      local.get $var10
                      i64.eq
                      br_if $label19
                      br $label0
                    end $label19
                  end $label18
                  loop $label20
                    local.get $var7
                    local.get $var3
                    i32.add
                    i32.load8_u
                    local.get $var6
                    local.get $var3
                    i32.add
                    i32.load8_u
                    i32.ne
                    br_if $label0
                    local.get $var3
                    i32.const 1
                    i32.add
                    local.tee $var3
                    local.get $var5
                    i32.lt_u
                    br_if $label20
                  end $label20
                end $label17
                local.get $var1
                i32.load offset=52
                local.tee $var5
                local.get $var2
                i32.load offset=52
                i32.ne
                br_if $label0
                local.get $var0
                local.get $var2
                i32.load offset=48
                i32.add
                local.set $var6
                local.get $var0
                local.get $var1
                i32.load offset=48
                i32.add
                local.set $var7
                i32.const 0
                local.set $var3
                local.get $var5
                local.set $var8
                loop $label26
                  block $label21
                    local.get $var8
                    i32.const 31
                    i32.gt_u
                    br_if $label21
                    i32.const 0
                    local.get $var3
                    i32.sub
                    local.set $var8
                    local.get $var6
                    local.get $var3
                    i32.add
                    local.set $var9
                    local.get $var7
                    local.get $var3
                    i32.add
                    local.set $var3
                    block $label23
                      loop $label24
                        block $label22
                          local.get $var5
                          local.get $var8
                          i32.add
                          i32.const 7
                          i32.gt_u
                          br_if $label22
                          i32.const 0
                          local.get $var8
                          i32.sub
                          local.tee $var3
                          local.get $var5
                          i32.lt_u
                          br_if $label23
                          i32.const 1
                          return
                        end $label22
                        local.get $var8
                        i32.const -8
                        i32.add
                        local.set $var8
                        local.get $var9
                        i64.load align=1
                        local.set $var10
                        local.get $var3
                        i64.load align=1
                        local.set $var11
                        i32.const 0
                        local.set $var4
                        local.get $var3
                        i32.const 8
                        i32.add
                        local.set $var3
                        local.get $var9
                        i32.const 8
                        i32.add
                        local.set $var9
                        local.get $var11
                        local.get $var10
                        i64.eq
                        br_if $label24
                        br $label0
                      end $label24
                    end $label23
                    loop $label25
                      local.get $var7
                      local.get $var3
                      i32.add
                      i32.load8_u
                      local.get $var6
                      local.get $var3
                      i32.add
                      i32.load8_u
                      i32.ne
                      br_if $label6
                      i32.const 1
                      local.set $var4
                      local.get $var3
                      i32.const 1
                      i32.add
                      local.tee $var3
                      local.get $var5
                      i32.ge_u
                      br_if $label0
                      br $label25
                    end $label25
                  end $label21
                  local.get $var7
                  local.get $var3
                  i32.add
                  local.set $var9
                  local.get $var6
                  local.get $var3
                  i32.add
                  local.set $var12
                  local.get $var8
                  i32.const -32
                  i32.add
                  local.set $var8
                  local.get $var3
                  i32.const 32
                  i32.add
                  local.set $var3
                  i32.const 0
                  local.set $var4
                  local.get $var12
                  i32.const 16
                  i32.add
                  v128.load align=1
                  local.get $var9
                  i32.const 16
                  i32.add
                  v128.load align=1
                  v128.xor
                  local.get $var12
                  v128.load align=1
                  local.get $var9
                  v128.load align=1
                  v128.xor
                  v128.or
                  v128.any_true
                  i32.eqz
                  br_if $label26
                  br $label0
                end $label26
              end $label15
              local.get $var7
              local.get $var3
              i32.add
              local.set $var9
              local.get $var6
              local.get $var3
              i32.add
              local.set $var12
              local.get $var8
              i32.const -32
              i32.add
              local.set $var8
              local.get $var3
              i32.const 32
              i32.add
              local.set $var3
              i32.const 0
              local.set $var4
              local.get $var12
              i32.const 16
              i32.add
              v128.load align=1
              local.get $var9
              i32.const 16
              i32.add
              v128.load align=1
              v128.xor
              local.get $var12
              v128.load align=1
              local.get $var9
              v128.load align=1
              v128.xor
              v128.or
              v128.any_true
              i32.eqz
              br_if $label27
              br $label0
            end $label27
          end $label9
          local.get $var7
          local.get $var3
          i32.add
          local.set $var9
          local.get $var6
          local.get $var3
          i32.add
          local.set $var12
          local.get $var8
          i32.const -32
          i32.add
          local.set $var8
          local.get $var3
          i32.const 32
          i32.add
          local.set $var3
          local.get $var12
          i32.const 16
          i32.add
          v128.load align=1
          local.get $var9
          i32.const 16
          i32.add
          v128.load align=1
          v128.xor
          local.get $var12
          v128.load align=1
          local.get $var9
          v128.load align=1
          v128.xor
          v128.or
          v128.any_true
          i32.eqz
          br_if $label28
        end $label28
      end $label6
      i32.const 0
      local.set $var4
    end $label0
    local.get $var4
  )
  (func $func41 (param $var0 i32) (param $var1 i32) (result i32)
    (local $var2 i32)
    (local $var3 i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    i32.const 0
    local.set $var2
    block $label1
      block $label0
        local.get $var1
        i32.load offset=40
        local.tee $var3
        br_if $label0
        i32.const 0
        local.set $var4
        i32.const 0
        local.set $var5
        br $label1
      end $label0
      local.get $var0
      local.get $var1
      i32.load offset=36
      local.tee $var6
      i32.add
      local.set $var7
      block $label3
        block $label2
          local.get $var3
          i32.const 3
          i32.gt_u
          br_if $label2
          local.get $var7
          i32.load8_u
          local.set $var2
          local.get $var3
          i32.const 1
          i32.eq
          br_if $label3
          local.get $var7
          i32.const 1
          i32.add
          i32.load8_u
          i32.const 8
          i32.shl
          local.get $var2
          i32.or
          local.set $var2
          local.get $var3
          i32.const 2
          i32.eq
          br_if $label3
          local.get $var7
          i32.const 2
          i32.add
          i32.load8_u
          i32.const 16
          i32.shl
          local.get $var2
          i32.or
          local.set $var2
          br $label3
        end $label2
        local.get $var7
        i32.load align=1
        local.set $var4
        block $label4
          local.get $var3
          i32.const 4
          i32.ne
          br_if $label4
          local.get $var4
          local.set $var2
          local.get $var4
          local.set $var5
          br $label1
        end $label4
        i32.const 0
        local.get $var3
        i32.const -4
        i32.add
        local.tee $var2
        local.get $var2
        local.get $var3
        i32.gt_u
        select
        local.set $var8
        i32.const 0
        local.set $var5
        i32.const 0
        local.set $var2
        block $label5
          local.get $var3
          local.get $var8
          i32.const 1
          i32.shr_u
          local.tee $var9
          i32.le_u
          br_if $label5
          local.get $var7
          local.get $var9
          i32.add
          local.set $var10
          block $label6
            local.get $var3
            local.get $var9
            i32.sub
            local.tee $var11
            i32.const 3
            i32.gt_u
            br_if $label6
            i32.const 0
            local.set $var9
            i32.const 0
            local.set $var2
            loop $label7
              local.get $var10
              i32.load8_u
              local.get $var9
              i32.shl
              local.get $var2
              i32.or
              local.set $var2
              local.get $var10
              i32.const 1
              i32.add
              local.set $var10
              local.get $var9
              i32.const 8
              i32.add
              local.set $var9
              local.get $var11
              i32.const -1
              i32.add
              local.tee $var11
              br_if $label7
              br $label5
            end $label7
          end $label6
          local.get $var10
          i32.load align=1
          local.set $var2
        end $label5
        local.get $var3
        local.get $var8
        i32.le_u
        br_if $label1
        block $label8
          local.get $var3
          local.get $var8
          i32.sub
          local.tee $var5
          i32.const 3
          i32.gt_u
          br_if $label8
          i32.const 0
          local.set $var10
          i32.const 0
          local.get $var5
          i32.sub
          local.set $var9
          local.get $var0
          local.get $var3
          local.get $var6
          i32.add
          i32.add
          local.set $var0
          i32.const 0
          local.set $var5
          loop $label9
            local.get $var0
            local.get $var9
            i32.add
            i32.load8_u
            local.get $var10
            i32.shl
            local.get $var5
            i32.or
            local.set $var5
            local.get $var10
            i32.const 8
            i32.add
            local.set $var10
            local.get $var9
            i32.const 1
            i32.add
            local.tee $var11
            local.set $var9
            local.get $var11
            br_if $label9
            br $label1
          end $label9
        end $label8
        local.get $var7
        local.get $var8
        i32.add
        i32.load align=1
        local.set $var5
        br $label1
      end $label3
      local.get $var2
      local.set $var4
      local.get $var2
      local.set $var5
    end $label1
    local.get $var4
    local.get $var3
    i32.const -1640531535
    i32.mul
    i32.xor
    local.get $var1
    i32.load offset=28
    i32.const -2048144789
    i32.mul
    i32.xor
    local.get $var1
    i32.load offset=20
    i32.const -1028477387
    i32.mul
    i32.xor
    local.get $var1
    i32.load offset=52
    i32.const 668265263
    i32.mul
    i32.xor
    i32.const 13
    i32.rotl
    local.get $var2
    i32.const 374761393
    i32.mul
    i32.xor
    i32.const 11
    i32.rotl
    local.get $var5
    i32.xor
  )
  (func $func42 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (param $var8 i32) (result i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 i32)
    (local $var23 i32)
    (local $var24 i32)
    (local $var25 i32)
    (local $var26 v128)
    (local $var27 v128)
    i32.const 0
    local.set $var9
    block $label0
      local.get $var1
      local.get $var2
      i32.le_u
      br_if $label0
      local.get $var0
      local.get $var2
      i32.add
      local.tee $var10
      i32.load8_u
      local.tee $var11
      i32.const 32
      i32.or
      i32.const 123
      i32.ne
      br_if $label0
      i32.const 0
      local.set $var9
      local.get $var4
      i32.const 0
      local.get $var4
      local.get $var8
      i32.sub
      local.tee $var8
      local.get $var8
      local.get $var4
      i32.gt_u
      select
      local.tee $var12
      i32.le_u
      br_if $label0
      local.get $var0
      local.get $var2
      i32.add
      local.set $var13
      local.get $var1
      local.get $var2
      i32.sub
      local.set $var14
      loop $label15
        block $label1
          local.get $var3
          local.get $var4
          i32.const -1
          i32.add
          local.tee $var4
          i32.const 68
          i32.mul
          i32.add
          local.tee $var15
          i32.load offset=40
          local.tee $var16
          i32.const -1
          i32.add
          local.get $var14
          i32.ge_u
          br_if $label1
          local.get $var11
          local.get $var0
          local.get $var15
          i32.load offset=36
          local.tee $var17
          i32.add
          local.tee $var1
          i32.load8_u
          i32.ne
          br_if $label1
          local.get $var16
          i32.const 8
          local.get $var16
          i32.const 8
          i32.lt_u
          select
          local.set $var18
          local.get $var17
          local.get $var16
          i32.add
          local.set $var19
          local.get $var16
          local.get $var2
          i32.add
          local.set $var20
          block $label2
            local.get $var16
            i32.const 7
            i32.gt_u
            local.tee $var21
            i32.eqz
            br_if $label2
            local.get $var0
            local.get $var20
            local.get $var18
            i32.sub
            i32.add
            i64.load align=1
            local.get $var0
            local.get $var19
            local.get $var18
            i32.sub
            i32.add
            i64.load align=1
            i64.ne
            br_if $label1
          end $label2
          block $label3
            local.get $var18
            i32.const 8
            i32.and
            local.tee $var22
            local.get $var18
            i32.eq
            local.tee $var23
            br_if $label3
            local.get $var13
            local.get $var16
            i32.add
            local.set $var24
            local.get $var22
            local.get $var18
            i32.sub
            local.set $var8
            local.get $var0
            local.get $var19
            i32.add
            local.set $var19
            loop $label4
              local.get $var24
              local.get $var8
              i32.add
              i32.load8_u
              local.get $var19
              local.get $var8
              i32.add
              i32.load8_u
              i32.ne
              br_if $label1
              local.get $var8
              i32.const 1
              i32.add
              local.tee $var8
              br_if $label4
            end $label4
          end $label3
          local.get $var16
          local.get $var18
          i32.sub
          i32.const 1
          i32.shr_u
          local.set $var8
          block $label5
            local.get $var21
            i32.eqz
            br_if $label5
            local.get $var10
            local.get $var8
            i32.add
            i64.load align=1
            local.get $var1
            local.get $var8
            i32.add
            i64.load align=1
            i64.ne
            br_if $label1
          end $label5
          block $label6
            local.get $var23
            br_if $label6
            local.get $var18
            local.get $var22
            i32.sub
            local.set $var19
            local.get $var13
            local.get $var8
            local.get $var22
            i32.add
            local.tee $var24
            i32.add
            local.set $var8
            local.get $var0
            local.get $var24
            local.get $var17
            i32.add
            i32.add
            local.set $var24
            loop $label7
              local.get $var8
              i32.load8_u
              local.get $var24
              i32.load8_u
              i32.ne
              br_if $label1
              local.get $var8
              i32.const 1
              i32.add
              local.set $var8
              local.get $var24
              i32.const 1
              i32.add
              local.set $var24
              local.get $var19
              i32.const -1
              i32.add
              local.tee $var19
              br_if $label7
            end $label7
          end $label6
          i32.const 0
          local.set $var24
          local.get $var16
          local.set $var19
          local.get $var10
          local.set $var8
          block $label11
            loop $label14
              block $label8
                local.get $var16
                local.get $var24
                i32.add
                i32.const 31
                i32.gt_u
                br_if $label8
                i32.const 0
                local.set $var18
                local.get $var8
                local.set $var17
                local.get $var1
                local.set $var21
                local.get $var16
                local.set $var22
                block $label10
                  loop $label12
                    block $label9
                      local.get $var24
                      local.get $var22
                      i32.add
                      i32.const 7
                      i32.gt_u
                      br_if $label9
                      local.get $var18
                      local.get $var24
                      i32.sub
                      local.get $var16
                      i32.lt_u
                      br_if $label10
                      br $label11
                    end $label9
                    local.get $var1
                    local.get $var18
                    i32.add
                    local.set $var23
                    local.get $var8
                    local.get $var18
                    i32.add
                    local.set $var25
                    local.get $var17
                    i32.const 8
                    i32.add
                    local.set $var17
                    local.get $var21
                    i32.const 8
                    i32.add
                    local.set $var21
                    local.get $var19
                    i32.const -8
                    i32.add
                    local.set $var19
                    local.get $var22
                    i32.const -8
                    i32.add
                    local.set $var22
                    local.get $var18
                    i32.const 8
                    i32.add
                    local.set $var18
                    local.get $var25
                    i64.load align=1
                    local.get $var23
                    i64.load align=1
                    i64.ne
                    br_if $label1
                    br $label12
                  end $label12
                end $label10
                loop $label13
                  local.get $var17
                  i32.load8_u
                  local.get $var21
                  i32.load8_u
                  i32.ne
                  br_if $label1
                  local.get $var17
                  i32.const 1
                  i32.add
                  local.set $var17
                  local.get $var21
                  i32.const 1
                  i32.add
                  local.set $var21
                  local.get $var19
                  i32.const -1
                  i32.add
                  local.tee $var19
                  i32.eqz
                  br_if $label11
                  br $label13
                end $label13
              end $label8
              local.get $var8
              i32.const 16
              i32.add
              local.set $var18
              local.get $var1
              i32.const 16
              i32.add
              local.set $var17
              local.get $var8
              v128.load align=1
              local.set $var26
              local.get $var1
              v128.load align=1
              local.set $var27
              local.get $var19
              i32.const -32
              i32.add
              local.set $var19
              local.get $var8
              i32.const 32
              i32.add
              local.set $var8
              local.get $var1
              i32.const 32
              i32.add
              local.set $var1
              local.get $var24
              i32.const -32
              i32.add
              local.set $var24
              local.get $var17
              v128.load align=1
              local.get $var18
              v128.load align=1
              v128.xor
              local.get $var27
              local.get $var26
              v128.xor
              v128.or
              v128.any_true
              br_if $label1
              br $label14
            end $label14
          end $label11
          local.get $var5
          local.get $var15
          i64.load offset=56 align=4
          i64.store offset=56 align=4
          local.get $var5
          local.get $var15
          i32.load offset=64
          i32.store offset=64
          local.get $var6
          local.get $var20
          i32.store
          local.get $var7
          local.get $var4
          i32.store
          i32.const 1
          local.set $var9
          br $label0
        end $label1
        local.get $var4
        local.get $var12
        i32.gt_u
        br_if $label15
      end $label15
    end $label0
    local.get $var9
  )
  (func $func43 (param $var0 i32) (param $var1 i32) (param $var2 i32) (result i32)
    (local $var3 i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    block $label0
      local.get $var1
      local.get $var2
      i32.ge_u
      br_if $label0
      local.get $var1
      local.get $var0
      local.get $var1
      i32.add
      i32.load8_u
      i32.const 45
      i32.eq
      i32.add
      local.set $var1
    end $label0
    i32.const 0
    local.set $var3
    block $label1
      local.get $var1
      local.get $var2
      i32.ge_u
      br_if $label1
      block $label5
        block $label3
          block $label2
            local.get $var0
            local.get $var1
            i32.add
            i32.load8_u
            local.tee $var4
            i32.const 48
            i32.ne
            br_if $label2
            local.get $var1
            i32.const 1
            i32.add
            local.tee $var4
            local.get $var2
            i32.ge_u
            br_if $label3
            local.get $var0
            local.get $var4
            i32.add
            i32.load8_u
            i32.const -48
            i32.add
            i32.const 255
            i32.and
            i32.const 10
            i32.ge_u
            br_if $label3
            br $label1
          end $label2
          local.get $var4
          i32.const -58
          i32.add
          i32.const 255
          i32.and
          i32.const 247
          i32.lt_u
          br_if $label1
          local.get $var0
          i32.const 1
          i32.add
          local.set $var5
          local.get $var2
          i32.const -1
          i32.add
          local.set $var6
          loop $label6
            block $label4
              local.get $var6
              local.get $var1
              i32.ne
              br_if $label4
              local.get $var2
              local.set $var4
              br $label5
            end $label4
            local.get $var5
            local.get $var1
            i32.add
            local.set $var7
            local.get $var1
            i32.const 1
            i32.add
            local.tee $var4
            local.set $var1
            local.get $var7
            i32.load8_u
            i32.const -48
            i32.add
            i32.const 255
            i32.and
            i32.const 10
            i32.lt_u
            br_if $label6
          end $label6
        end $label3
        block $label7
          local.get $var4
          local.get $var2
          i32.ge_u
          br_if $label7
          local.get $var0
          local.get $var4
          i32.add
          i32.load8_u
          i32.const 46
          i32.ne
          br_if $label7
          local.get $var4
          i32.const 1
          i32.add
          local.tee $var1
          local.get $var2
          i32.ge_u
          br_if $label1
          local.get $var1
          local.set $var4
          block $label8
            loop $label9
              local.get $var0
              local.get $var4
              i32.add
              i32.load8_u
              i32.const -48
              i32.add
              i32.const 255
              i32.and
              i32.const 9
              i32.gt_u
              br_if $label8
              local.get $var2
              local.get $var4
              i32.const 1
              i32.add
              local.tee $var4
              i32.ne
              br_if $label9
            end $label9
            local.get $var2
            local.set $var4
          end $label8
          local.get $var4
          local.get $var1
          i32.eq
          br_if $label1
        end $label7
        local.get $var4
        local.get $var2
        i32.ge_u
        br_if $label5
        local.get $var0
        local.get $var4
        i32.add
        i32.load8_u
        i32.const 32
        i32.or
        i32.const 101
        i32.ne
        br_if $label5
        block $label10
          local.get $var4
          i32.const 1
          i32.add
          local.tee $var1
          local.get $var2
          i32.ge_u
          br_if $label10
          block $label11
            local.get $var0
            local.get $var1
            i32.add
            i32.load8_u
            i32.const -43
            i32.add
            br_table $label11 $label10 $label11 $label10
          end $label11
          local.get $var4
          i32.const 2
          i32.add
          local.set $var1
        end $label10
        local.get $var1
        local.get $var2
        i32.ge_u
        br_if $label1
        local.get $var1
        local.set $var4
        block $label12
          loop $label13
            local.get $var0
            local.get $var4
            i32.add
            i32.load8_u
            i32.const -48
            i32.add
            i32.const 255
            i32.and
            i32.const 9
            i32.gt_u
            br_if $label12
            local.get $var2
            local.get $var4
            i32.const 1
            i32.add
            local.tee $var4
            i32.ne
            br_if $label13
          end $label13
          local.get $var2
          local.set $var4
        end $label12
        local.get $var4
        local.get $var1
        i32.eq
        br_if $label1
      end $label5
      local.get $var4
      local.get $var2
      i32.eq
      local.set $var3
    end $label1
    local.get $var3
  )
  (func $func44 (param $var0 i32) (param $var1 i32) (param $var2 i32) (result i32)
    (local $var3 i32)
    (local $var4 i32)
    (local $var5 i32)
    block $label0
      local.get $var2
      i32.load
      local.tee $var3
      local.get $var1
      i32.ge_u
      br_if $label0
      loop $label1
        local.get $var0
        local.get $var3
        i32.add
        i32.load8_u
        i32.const -9
        i32.add
        local.tee $var4
        i32.const 23
        i32.gt_u
        br_if $label0
        i32.const 1
        local.get $var4
        i32.shl
        i32.const 8388627
        i32.and
        i32.eqz
        br_if $label0
        local.get $var1
        local.get $var3
        i32.const 1
        i32.add
        local.tee $var3
        i32.ne
        br_if $label1
      end $label1
      i32.const 0
      return
    end $label0
    i32.const 0
    local.set $var5
    block $label2
      local.get $var3
      local.get $var1
      i32.ge_u
      br_if $label2
      local.get $var0
      local.get $var3
      i32.add
      i32.load8_u
      i32.const 44
      i32.ne
      br_if $label2
      block $label3
        local.get $var3
        i32.const 1
        i32.add
        local.tee $var3
        local.get $var1
        i32.ge_u
        br_if $label3
        loop $label4
          local.get $var0
          local.get $var3
          i32.add
          i32.load8_u
          i32.const -9
          i32.add
          local.tee $var4
          i32.const 23
          i32.gt_u
          br_if $label3
          i32.const 1
          local.get $var4
          i32.shl
          i32.const 8388627
          i32.and
          i32.eqz
          br_if $label3
          local.get $var1
          local.get $var3
          i32.const 1
          i32.add
          local.tee $var3
          i32.ne
          br_if $label4
          br $label2
        end $label4
      end $label3
      local.get $var3
      local.get $var1
      i32.ge_u
      br_if $label2
      local.get $var2
      local.get $var3
      i32.store
      i32.const 1
      local.set $var5
    end $label2
    local.get $var5
  )
  (func $func45 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (result i32)
    (local $var8 i32)
    i32.const 0
    local.set $var8
    block $label0
      local.get $var2
      local.get $var1
      i32.ge_u
      br_if $label0
      block $label1
        local.get $var0
        local.get $var2
        i32.add
        i32.load8_u
        i32.const 223
        i32.and
        i32.const 91
        i32.ne
        br_if $label1
        local.get $var0
        local.get $var1
        local.get $var2
        local.get $var3
        local.get $var4
        local.get $var5
        local.get $var6
        local.get $var7
        call $func13
        return
      end $label1
      local.get $var0
      local.get $var1
      local.get $var2
      local.get $var3
      call $func12
      local.set $var8
    end $label0
    local.get $var8
  )
  (func $compact_term_lookup_keys (;46;) (export "compact_term_lookup_keys") (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (param $var8 i32) (param $var9 i32) (param $var10 i32) (param $var11 i32) (param $var12 i32) (param $var13 i32) (param $var14 i32) (param $var15 i32) (param $var16 i32) (param $var17 i32) (param $var18 i32) (param $var19 i32) (result i32)
    (local $var20 i32)
    (local $var21 v128)
    (local $var22 v128)
    (local $var23 i32)
    (local $var24 i32)
    (local $var25 i32)
    (local $var26 i32)
    (local $var27 i32)
    (local $var28 i32)
    (local $var29 i32)
    i32.const -1
    local.set $var20
    block $label0
      local.get $var5
      i32x4.splat
      local.get $var0
      i32x4.replace_lane 1
      local.get $var2
      i32x4.replace_lane 2
      local.get $var3
      i32x4.replace_lane 3
      v128.const i32x4 0x00000000 0x00000000 0x00000000 0x00000000
      local.tee $var21
      i32x4.eq
      v128.const i32x4 0x000000FF 0x000000FF 0x000000FF 0x000000FF
      local.tee $var22
      v128.and
      local.get $var4
      i32x4.splat
      local.get $var6
      i32x4.replace_lane 1
      local.get $var7
      i32x4.replace_lane 2
      local.get $var8
      i32x4.replace_lane 3
      local.get $var21
      i32x4.eq
      local.get $var22
      v128.and
      i16x8.narrow_i32x4_u
      local.get $var10
      i32x4.splat
      local.get $var19
      i32x4.replace_lane 1
      local.get $var11
      i32x4.replace_lane 2
      local.get $var12
      i32x4.replace_lane 3
      local.get $var21
      i32x4.eq
      local.get $var22
      v128.and
      local.get $var13
      i32x4.splat
      local.get $var14
      i32x4.replace_lane 1
      local.get $var15
      i32x4.replace_lane 2
      local.get $var16
      i32x4.replace_lane 3
      local.get $var21
      i32x4.eq
      local.get $var22
      v128.and
      i16x8.narrow_i32x4_u
      i8x16.narrow_i16x8_u
      v128.any_true
      br_if $label0
      local.get $var18
      i32.const 65534
      i32.gt_u
      br_if $label0
      local.get $var5
      i32.const 1073741823
      i32.gt_u
      br_if $label0
      local.get $var9
      i32.const -65535
      i32.add
      i32.const -65534
      i32.lt_u
      br_if $label0
      i32.const 0
      local.set $var23
      local.get $var3
      local.set $var24
      local.get $var2
      local.set $var25
      local.get $var5
      local.set $var26
      loop $label1
        i32.const -2
        local.set $var20
        local.get $var1
        local.get $var23
        i32.lt_u
        br_if $label0
        local.get $var24
        i32.load
        local.get $var23
        i32.ne
        br_if $label0
        local.get $var1
        local.get $var23
        i32.sub
        local.get $var25
        i32.load16_u
        local.tee $var27
        i32.lt_u
        br_if $label0
        local.get $var24
        i32.const 4
        i32.add
        local.set $var24
        local.get $var25
        i32.const 2
        i32.add
        local.set $var25
        local.get $var23
        local.get $var27
        i32.add
        local.set $var23
        local.get $var26
        i32.const -1
        i32.add
        local.tee $var26
        br_if $label1
      end $label1
      local.get $var23
      local.get $var1
      i32.ne
      br_if $label0
      i32.const 0
      local.set $var23
      block $label2
        local.get $var5
        i32.const 2
        i32.shl
        local.tee $var24
        i32.eqz
        br_if $label2
        local.get $var10
        i32.const 0
        local.get $var24
        memory.fill
      end $label2
      i32.const 0
      local.set $var25
      block $label3
        local.get $var9
        i32.eqz
        br_if $label3
        i32.const 0
        local.set $var25
        i32.const 0
        local.set $var23
        loop $label12
          block $label4
            local.get $var8
            i32.load8_u
            local.tee $var24
            i32.const 1
            i32.le_u
            br_if $label4
            i32.const -3
            return
          end $label4
          block $label5
            local.get $var6
            i32.load
            local.tee $var1
            local.get $var5
            i32.lt_u
            br_if $label5
            i32.const -3
            return
          end $label5
          block $label6
            local.get $var2
            local.get $var1
            i32.const 1
            i32.shl
            i32.add
            local.tee $var27
            i32.load16_u
            local.tee $var26
            br_if $label6
            i32.const -3
            return
          end $label6
          local.get $var6
          local.get $var7
          local.get $var24
          select
          i32.load
          local.set $var24
          block $label7
            local.get $var10
            local.get $var1
            i32.const 2
            i32.shl
            local.tee $var28
            i32.add
            local.tee $var29
            i32.load
            local.tee $var1
            br_if $label7
            i32.const -4
            local.set $var20
            local.get $var23
            local.get $var18
            i32.ge_u
            br_if $label0
            local.get $var17
            local.get $var25
            i32.sub
            local.get $var26
            i32.lt_u
            br_if $label0
            local.get $var12
            local.get $var23
            i32.const 2
            i32.shl
            local.tee $var1
            i32.add
            local.get $var25
            i32.store
            local.get $var13
            local.get $var1
            i32.add
            local.get $var4
            local.get $var28
            i32.add
            i32.load
            i32.store
            local.get $var11
            local.get $var23
            i32.const 1
            i32.shl
            i32.add
            local.get $var26
            i32.store16
            block $label8
              local.get $var27
              i32.load16_u
              local.tee $var1
              i32.eqz
              br_if $label8
              local.get $var16
              local.get $var25
              i32.add
              local.get $var0
              local.get $var3
              local.get $var28
              i32.add
              i32.load
              i32.add
              local.get $var1
              memory.copy
            end $label8
            local.get $var29
            local.get $var23
            i32.const 1
            i32.add
            local.tee $var23
            i32.store
            local.get $var25
            local.get $var27
            i32.load16_u
            i32.add
            local.set $var25
            local.get $var23
            local.set $var1
          end $label7
          local.get $var14
          local.get $var1
          i32.const -1
          i32.add
          i32.store
          block $label9
            local.get $var24
            local.get $var5
            i32.lt_u
            br_if $label9
            i32.const -3
            return
          end $label9
          i32.const -3
          local.set $var20
          local.get $var2
          local.get $var24
          i32.const 1
          i32.shl
          i32.add
          local.tee $var26
          i32.load16_u
          local.tee $var1
          i32.eqz
          br_if $label0
          block $label10
            local.get $var10
            local.get $var24
            i32.const 2
            i32.shl
            local.tee $var27
            i32.add
            local.tee $var28
            i32.load
            local.tee $var24
            br_if $label10
            i32.const -4
            local.set $var20
            local.get $var23
            local.get $var18
            i32.ge_u
            br_if $label0
            local.get $var17
            local.get $var25
            i32.sub
            local.get $var1
            i32.lt_u
            br_if $label0
            local.get $var12
            local.get $var23
            i32.const 2
            i32.shl
            local.tee $var24
            i32.add
            local.get $var25
            i32.store
            local.get $var13
            local.get $var24
            i32.add
            local.get $var4
            local.get $var27
            i32.add
            i32.load
            i32.store
            local.get $var11
            local.get $var23
            i32.const 1
            i32.shl
            i32.add
            local.get $var1
            i32.store16
            block $label11
              local.get $var26
              i32.load16_u
              local.tee $var24
              i32.eqz
              br_if $label11
              local.get $var16
              local.get $var25
              i32.add
              local.get $var0
              local.get $var3
              local.get $var27
              i32.add
              i32.load
              i32.add
              local.get $var24
              memory.copy
            end $label11
            local.get $var28
            local.get $var23
            i32.const 1
            i32.add
            local.tee $var23
            i32.store
            local.get $var25
            local.get $var26
            i32.load16_u
            i32.add
            local.set $var25
            local.get $var23
            local.set $var24
          end $label10
          local.get $var15
          local.get $var24
          i32.const -1
          i32.add
          i32.store
          local.get $var8
          i32.const 1
          i32.add
          local.set $var8
          local.get $var6
          i32.const 4
          i32.add
          local.set $var6
          local.get $var14
          i32.const 4
          i32.add
          local.set $var14
          local.get $var15
          i32.const 4
          i32.add
          local.set $var15
          local.get $var7
          i32.const 4
          i32.add
          local.set $var7
          local.get $var9
          i32.const -1
          i32.add
          local.tee $var9
          br_if $label12
        end $label12
      end $label3
      local.get $var19
      local.get $var25
      i32.store
      local.get $var23
      local.set $var20
    end $label0
    local.get $var20
  )
  (func $func47 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (result i32)
    (local $var4 i32)
    (local $var5 i32)
    (local $var6 i32)
    (local $var7 i32)
    i32.const 0
    local.set $var4
    block $label0
      local.get $var2
      local.get $var1
      i32.ge_u
      br_if $label0
      local.get $var2
      local.set $var5
      block $label2
        loop $label5
          block $label1
            local.get $var1
            local.get $var5
            local.tee $var6
            i32.ne
            br_if $label1
            local.get $var1
            local.set $var6
            br $label2
          end $label1
          block $label3
            block $label4
              local.get $var0
              local.get $var6
              i32.add
              i32.load8_u
              local.tee $var7
              i32.const -10
              i32.add
              br_table $label2 $label3 $label3 $label2 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label2 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label3 $label2 $label4
            end $label4
            local.get $var7
            i32.const 93
            i32.eq
            br_if $label2
            local.get $var7
            i32.const 125
            i32.eq
            br_if $label2
          end $label3
          local.get $var6
          i32.const 1
          i32.add
          local.set $var5
          local.get $var7
          i32.const 9
          i32.ne
          br_if $label5
        end $label5
      end $label2
      local.get $var6
      local.get $var2
      i32.eq
      br_if $label0
      block $label10
        block $label7
          block $label8
            block $label6
              block $label9
                local.get $var0
                local.get $var2
                i32.add
                local.tee $var7
                i32.load8_u
                i32.const -102
                i32.add
                br_table $label6 $label7 $label7 $label7 $label7 $label7 $label7 $label7 $label8 $label7 $label7 $label7 $label7 $label7 $label9 $label7
              end $label9
              local.get $var6
              local.get $var2
              i32.sub
              i32.const 4
              i32.ne
              br_if $label0
              local.get $var7
              i32.load8_u
              i32.const 116
              i32.ne
              br_if $label0
              local.get $var7
              i32.const 1
              i32.add
              i32.load8_u
              i32.const 114
              i32.ne
              br_if $label0
              local.get $var7
              i32.const 2
              i32.add
              i32.load8_u
              i32.const 117
              i32.ne
              br_if $label0
              local.get $var7
              i32.const 3
              i32.add
              i32.load8_u
              i32.const 101
              i32.eq
              br_if $label10
              br $label0
            end $label6
            local.get $var6
            local.get $var2
            i32.sub
            i32.const 5
            i32.ne
            br_if $label0
            local.get $var7
            i32.load8_u
            i32.const 102
            i32.ne
            br_if $label0
            local.get $var7
            i32.const 1
            i32.add
            i32.load8_u
            i32.const 97
            i32.ne
            br_if $label0
            local.get $var7
            i32.const 2
            i32.add
            i32.load8_u
            i32.const 108
            i32.ne
            br_if $label0
            local.get $var7
            i32.const 3
            i32.add
            i32.load8_u
            i32.const 115
            i32.ne
            br_if $label0
            local.get $var7
            i32.const 4
            i32.add
            i32.load8_u
            i32.const 101
            i32.eq
            br_if $label10
            br $label0
          end $label8
          local.get $var6
          local.get $var2
          i32.sub
          i32.const 4
          i32.ne
          br_if $label0
          local.get $var7
          i32.load8_u
          i32.const 110
          i32.ne
          br_if $label0
          local.get $var7
          i32.const 1
          i32.add
          i32.load8_u
          i32.const 117
          i32.ne
          br_if $label0
          local.get $var7
          i32.const 2
          i32.add
          i32.load8_u
          i32.const 108
          i32.ne
          br_if $label0
          local.get $var7
          i32.const 3
          i32.add
          i32.load8_u
          i32.const 108
          i32.eq
          br_if $label10
          br $label0
        end $label7
        local.get $var0
        local.get $var2
        local.get $var6
        call $func43
        i32.eqz
        br_if $label0
      end $label10
      local.get $var3
      local.get $var6
      i32.store
      i32.const 1
      local.set $var4
    end $label0
    local.get $var4
  )
  (func $func48 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (result i32)
    (local $var7 i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 i64)
    (local $var23 i32)
    (local $var24 i32)
    (local $var25 i64)
    (local $var26 i32)
    (local $var27 i64)
    (local $var28 i32)
    (local $var29 i32)
    (local $var30 i32)
    (local $var31 i32)
    (local $var32 i32)
    (local $var33 i64)
    (local $var34 i64)
    (local $var35 i64)
    local.get $var1
    local.get $var2
    i32.add
    local.tee $var7
    local.get $var2
    i32.const 25
    local.get $var2
    i32.const 25
    i32.lt_u
    select
    i32.sub
    local.set $var8
    local.get $var3
    local.get $var4
    i32.add
    local.tee $var9
    local.get $var4
    i32.const 299
    local.get $var4
    i32.const 299
    i32.lt_u
    select
    i32.sub
    local.set $var10
    local.get $var0
    i32.const 256
    i32.add
    local.set $var11
    local.get $var0
    i32.const 144
    i32.add
    local.set $var12
    local.get $var0
    i32.const 11556
    i32.add
    local.set $var13
    local.get $var0
    i32.const 9368
    i32.add
    local.set $var14
    local.get $var0
    i32.const 10976
    i32.add
    local.set $var15
    local.get $var0
    i32.const 460
    i32.add
    local.set $var16
    local.get $var0
    i32.const 280
    i32.add
    local.set $var17
    local.get $var0
    i32.const 288
    i32.add
    local.tee $var18
    i32.const 24
    i32.add
    local.set $var19
    i32.const 0
    local.set $var20
    i32.const 0
    local.set $var21
    i64.const 0
    local.set $var22
    local.get $var1
    local.set $var23
    local.get $var3
    local.set $var24
    block $label93
      block $label4
        loop $label90
          block $label1
            block $label0
              local.get $var7
              local.get $var23
              i32.sub
              i32.const 7
              i32.gt_u
              br_if $label0
              local.get $var22
              local.set $var25
              local.get $var21
              i32.const 255
              i32.and
              local.tee $var2
              i32.const 55
              i32.gt_u
              br_if $label1
              loop $label5
                block $label3
                  block $label2
                    local.get $var23
                    local.get $var7
                    i32.eq
                    br_if $label2
                    local.get $var23
                    i64.load8_u
                    local.get $var2
                    i64.extend_i32_u
                    i64.shl
                    local.get $var25
                    i64.or
                    local.set $var25
                    local.get $var23
                    i32.const 1
                    i32.add
                    local.set $var23
                    br $label3
                  end $label2
                  i32.const 1
                  local.set $var26
                  local.get $var20
                  i32.const 1
                  i32.add
                  local.tee $var20
                  i32.const 8
                  i32.gt_u
                  br_if $label4
                end $label3
                local.get $var21
                i32.const 8
                i32.add
                local.tee $var21
                i32.const 255
                i32.and
                local.tee $var2
                i32.const 56
                i32.lt_u
                br_if $label5
                br $label1
              end $label5
            end $label0
            local.get $var21
            i32.const 3
            i32.shr_u
            local.set $var2
            local.get $var23
            i64.load align=1
            local.get $var21
            i32.const 255
            i32.and
            i64.extend_i32_u
            i64.shl
            local.get $var22
            i64.or
            local.set $var25
            local.get $var21
            i32.const 56
            i32.or
            local.set $var21
            local.get $var23
            local.get $var2
            i32.const 7
            i32.and
            i32.sub
            i32.const 7
            i32.add
            local.set $var23
          end $label1
          i32.const 1
          local.set $var26
          block $label20
            block $label21
              block $label24
                block $label10
                  block $label9
                    block $label7
                      block $label6
                        block $label8
                          local.get $var25
                          i32.wrap_i64
                          local.tee $var2
                          i32.const 1
                          i32.shr_u
                          i32.const 3
                          i32.and
                          br_table $label6 $label7 $label8 $label4 $label6
                        end $label8
                        local.get $var0
                        i32.const 0
                        i32.store8 offset=11552
                        local.get $var0
                        local.get $var2
                        i32.const 17
                        i32.shr_u
                        i32.const 7
                        i32.and
                        i32.store8 offset=16
                        local.get $var21
                        i32.const -20
                        i32.add
                        local.set $var21
                        local.get $var25
                        i64.const 20
                        i64.shr_u
                        local.set $var27
                        local.get $var7
                        local.get $var23
                        i32.sub
                        i32.const 7
                        i32.gt_u
                        br_if $label9
                        local.get $var21
                        i32.const 255
                        i32.and
                        local.tee $var4
                        i32.const 55
                        i32.gt_u
                        br_if $label10
                        loop $label13
                          block $label12
                            block $label11
                              local.get $var23
                              local.get $var7
                              i32.eq
                              br_if $label11
                              local.get $var23
                              i64.load8_u
                              local.get $var4
                              i64.extend_i32_u
                              i64.shl
                              local.get $var27
                              i64.or
                              local.set $var27
                              local.get $var23
                              i32.const 1
                              i32.add
                              local.set $var23
                              br $label12
                            end $label11
                            i32.const 1
                            local.set $var26
                            local.get $var20
                            i32.const 1
                            i32.add
                            local.tee $var20
                            i32.const 8
                            i32.gt_u
                            br_if $label4
                          end $label12
                          local.get $var21
                          i32.const 8
                          i32.add
                          local.tee $var21
                          i32.const 255
                          i32.and
                          local.tee $var4
                          i32.const 56
                          i32.lt_u
                          br_if $label13
                          br $label10
                        end $label13
                      end $label6
                      block $label14
                        local.get $var20
                        local.get $var21
                        i32.const 253
                        i32.add
                        i32.const 3
                        i32.shr_u
                        i32.const 31
                        i32.and
                        local.tee $var2
                        i32.le_u
                        br_if $label14
                        i32.const 1
                        return
                      end $label14
                      block $label15
                        local.get $var7
                        local.get $var23
                        local.get $var20
                        local.get $var2
                        i32.sub
                        i32.add
                        local.tee $var4
                        i32.sub
                        i32.const 4
                        i32.ge_s
                        br_if $label15
                        i32.const 1
                        return
                      end $label15
                      block $label16
                        local.get $var4
                        i32.load16_u offset=2 align=1
                        local.get $var4
                        i32.load16_u align=1
                        local.tee $var2
                        i32.xor
                        i32.const 65535
                        i32.and
                        i32.const 65535
                        i32.eq
                        br_if $label16
                        i32.const 1
                        return
                      end $label16
                      block $label17
                        local.get $var9
                        local.get $var24
                        i32.sub
                        local.get $var2
                        i32.ge_s
                        br_if $label17
                        i32.const 3
                        return
                      end $label17
                      block $label18
                        local.get $var7
                        local.get $var4
                        i32.const 4
                        i32.add
                        local.tee $var4
                        i32.sub
                        local.get $var2
                        i32.ge_s
                        br_if $label18
                        i32.const 1
                        return
                      end $label18
                      block $label19
                        local.get $var2
                        i32.eqz
                        br_if $label19
                        local.get $var24
                        local.get $var4
                        local.get $var2
                        memory.copy
                      end $label19
                      local.get $var24
                      local.get $var2
                      i32.add
                      local.set $var24
                      local.get $var4
                      local.get $var2
                      i32.add
                      local.set $var23
                      i64.const 0
                      local.set $var22
                      i32.const 0
                      local.set $var20
                      i32.const 0
                      local.set $var21
                      br $label20
                    end $label7
                    local.get $var21
                    i32.const -3
                    i32.add
                    local.set $var2
                    local.get $var25
                    i64.const 3
                    i64.shr_u
                    local.set $var27
                    local.get $var0
                    i32.load8_u offset=11552
                    br_if $label21
                    local.get $var0
                    i32.const 1
                    i32.store8 offset=11552
                    block $label22
                      i32.const 144
                      i32.eqz
                      br_if $label22
                      local.get $var0
                      i32.const 8
                      i32.const 144
                      memory.fill
                    end $label22
                    block $label23
                      i32.const 112
                      i32.eqz
                      br_if $label23
                      local.get $var12
                      i32.const 9
                      i32.const 112
                      memory.fill
                    end $label23
                    local.get $var11
                    i32.const 16
                    i32.add
                    i64.const 506381209866536711
                    i64.store align=1
                    local.get $var11
                    i32.const 8
                    i32.add
                    i64.const 506381209866536711
                    i64.store align=1
                    local.get $var11
                    i64.const 506381209866536711
                    i64.store align=1
                    local.get $var17
                    i64.const 578721382704613384
                    i64.store align=1
                    local.get $var18
                    i64.const 361700864190383365
                    i64.store align=1
                    local.get $var18
                    i32.const 8
                    i32.add
                    i64.const 361700864190383365
                    i64.store align=1
                    local.get $var18
                    i32.const 16
                    i32.add
                    i64.const 361700864190383365
                    i64.store align=1
                    local.get $var19
                    i64.const 361700864190383365
                    i64.store align=1
                    i32.const 32
                    local.set $var28
                    i32.const 288
                    local.set $var29
                    br $label24
                  end $label9
                  local.get $var21
                  i32.const 3
                  i32.shr_u
                  local.set $var4
                  local.get $var23
                  i64.load align=1
                  local.get $var21
                  i32.const 255
                  i32.and
                  i64.extend_i32_u
                  i64.shl
                  local.get $var27
                  i64.or
                  local.set $var27
                  local.get $var21
                  i32.const 56
                  i32.or
                  local.set $var21
                  local.get $var23
                  local.get $var4
                  i32.const 7
                  i32.and
                  i32.sub
                  i32.const 7
                  i32.add
                  local.set $var23
                end $label10
                local.get $var2
                i32.const 8
                i32.shr_u
                i32.const 31
                i32.and
                i32.const 1
                i32.add
                local.set $var28
                local.get $var2
                i32.const 3
                i32.shr_u
                i32.const 31
                i32.and
                i32.const 257
                i32.add
                local.set $var29
                local.get $var2
                i32.const 13
                i32.shr_u
                i32.const 15
                i32.and
                local.tee $var30
                i32.const 3
                i32.add
                local.tee $var26
                i32.const 30
                i32.and
                local.set $var31
                local.get $var26
                i32.const 1
                i32.and
                local.set $var32
                i32.const 0
                local.set $var2
                loop $label25
                  local.get $var0
                  local.get $var2
                  i32.const 1153
                  i32.add
                  i32.load8_u
                  i32.add
                  local.get $var27
                  i32.wrap_i64
                  local.tee $var4
                  i32.const 7
                  i32.and
                  i32.store8
                  local.get $var0
                  local.get $var2
                  i32.const 1154
                  i32.add
                  i32.load8_u
                  i32.add
                  local.get $var4
                  i32.const 3
                  i32.shr_u
                  i32.const 7
                  i32.and
                  i32.store8
                  local.get $var27
                  i64.const 6
                  i64.shr_u
                  local.set $var27
                  local.get $var31
                  local.get $var2
                  i32.const 2
                  i32.add
                  local.tee $var2
                  i32.ne
                  br_if $label25
                end $label25
                block $label27
                  block $label26
                    local.get $var32
                    br_if $label26
                    local.get $var2
                    local.set $var4
                    br $label27
                  end $label26
                  local.get $var2
                  i32.const 1
                  i32.add
                  local.set $var4
                  local.get $var0
                  local.get $var2
                  i32.const 1153
                  i32.add
                  i32.load8_u
                  i32.add
                  local.get $var27
                  i32.wrap_i64
                  i32.const 7
                  i32.and
                  i32.store8
                  local.get $var27
                  i64.const 3
                  i64.shr_u
                  local.set $var27
                end $label27
                block $label28
                  local.get $var4
                  i32.const 17
                  i32.gt_u
                  br_if $label28
                  loop $label29
                    local.get $var0
                    local.get $var26
                    i32.const 1153
                    i32.add
                    i32.load8_u
                    i32.add
                    i32.const 0
                    i32.store8
                    local.get $var26
                    i32.const 1
                    i32.add
                    local.tee $var26
                    i32.const 18
                    i32.lt_u
                    br_if $label29
                  end $label29
                end $label28
                block $label30
                  local.get $var16
                  local.get $var0
                  i32.const 19
                  i32.const 1184
                  i32.const 7
                  i32.const 7
                  local.get $var15
                  i32.const 0
                  call $func49
                  br_if $label30
                  i32.const 1
                  return
                end $label30
                local.get $var30
                i32.const -3
                i32.mul
                local.get $var21
                i32.add
                i32.const -9
                i32.add
                local.set $var2
                local.get $var29
                local.get $var28
                i32.add
                local.set $var32
                i32.const 0
                local.set $var4
                loop $label45
                  block $label32
                    block $label31
                      local.get $var2
                      i32.const 255
                      i32.and
                      local.tee $var26
                      i32.const 13
                      i32.le_u
                      br_if $label31
                      local.get $var2
                      local.set $var31
                      br $label32
                    end $label31
                    block $label33
                      local.get $var7
                      local.get $var23
                      i32.sub
                      i32.const 7
                      i32.gt_u
                      br_if $label33
                      local.get $var2
                      local.set $var31
                      loop $label36
                        block $label35
                          block $label34
                            local.get $var23
                            local.get $var7
                            i32.eq
                            br_if $label34
                            local.get $var23
                            i64.load8_u
                            local.get $var26
                            i64.extend_i32_u
                            i64.shl
                            local.get $var27
                            i64.or
                            local.set $var27
                            local.get $var23
                            i32.const 1
                            i32.add
                            local.set $var23
                            br $label35
                          end $label34
                          i32.const 1
                          local.set $var26
                          local.get $var20
                          i32.const 1
                          i32.add
                          local.tee $var20
                          i32.const 8
                          i32.gt_u
                          br_if $label4
                        end $label35
                        local.get $var31
                        i32.const 8
                        i32.add
                        local.tee $var31
                        i32.const 255
                        i32.and
                        local.tee $var26
                        i32.const 56
                        i32.lt_u
                        br_if $label36
                        br $label32
                      end $label36
                    end $label33
                    local.get $var2
                    i32.const 56
                    i32.or
                    local.set $var31
                    local.get $var23
                    i64.load align=1
                    local.get $var26
                    i64.extend_i32_u
                    i64.shl
                    local.get $var27
                    i64.or
                    local.set $var27
                    local.get $var23
                    local.get $var2
                    i32.const 3
                    i32.shr_u
                    i32.const 7
                    i32.and
                    i32.sub
                    i32.const 7
                    i32.add
                    local.set $var23
                  end $label32
                  local.get $var16
                  local.get $var27
                  i32.wrap_i64
                  i32.const 127
                  i32.and
                  i32.const 2
                  i32.shl
                  i32.add
                  i32.load
                  local.tee $var26
                  i32.const 16
                  i32.shr_u
                  local.set $var21
                  local.get $var31
                  local.get $var26
                  i32.sub
                  local.set $var2
                  local.get $var27
                  local.get $var26
                  i32.const 255
                  i32.and
                  i64.extend_i32_u
                  i64.shr_u
                  local.set $var27
                  block $label38
                    block $label37
                      local.get $var26
                      i32.const 1048575
                      i32.gt_u
                      br_if $label37
                      local.get $var0
                      local.get $var4
                      i32.add
                      local.get $var21
                      i32.store8
                      local.get $var4
                      i32.const 1
                      i32.add
                      local.set $var4
                      br $label38
                    end $label37
                    block $label43
                      block $label41
                        block $label40
                          block $label39
                            local.get $var21
                            i32.const -16
                            i32.add
                            br_table $label39 $label40 $label41
                          end $label39
                          block $label42
                            local.get $var4
                            br_if $label42
                            i32.const 1
                            return
                          end $label42
                          local.get $var0
                          local.get $var4
                          i32.add
                          local.tee $var26
                          local.get $var26
                          i32.const -1
                          i32.add
                          i32.load8_u
                          local.tee $var31
                          i32.store8 offset=5
                          local.get $var26
                          local.get $var31
                          i32.store8 offset=4
                          local.get $var26
                          local.get $var31
                          i32.store8 offset=3
                          local.get $var26
                          local.get $var31
                          i32.store8 offset=2
                          local.get $var26
                          local.get $var31
                          i32.store8 offset=1
                          local.get $var26
                          local.get $var31
                          i32.store8
                          local.get $var2
                          i32.const -2
                          i32.add
                          local.set $var2
                          local.get $var27
                          i32.wrap_i64
                          i32.const 3
                          i32.and
                          i32.const 3
                          i32.add
                          local.set $var26
                          local.get $var27
                          i64.const 2
                          i64.shr_u
                          local.set $var27
                          br $label43
                        end $label40
                        local.get $var0
                        local.get $var4
                        i32.add
                        local.tee $var26
                        i32.const 0
                        i32.store16 offset=8 align=1
                        local.get $var26
                        i64.const 0
                        i64.store align=1
                        local.get $var2
                        i32.const -3
                        i32.add
                        local.set $var2
                        local.get $var27
                        i32.wrap_i64
                        i32.const 7
                        i32.and
                        i32.const 3
                        i32.add
                        local.set $var26
                        local.get $var27
                        i64.const 3
                        i64.shr_u
                        local.set $var27
                        br $label43
                      end $label41
                      block $label44
                        local.get $var27
                        i32.wrap_i64
                        i32.const 127
                        i32.and
                        i32.const 11
                        i32.add
                        local.tee $var26
                        i32.eqz
                        br_if $label44
                        local.get $var0
                        local.get $var4
                        i32.add
                        i32.const 0
                        local.get $var26
                        memory.fill
                      end $label44
                      local.get $var2
                      i32.const -7
                      i32.add
                      local.set $var2
                      local.get $var27
                      i64.const 7
                      i64.shr_u
                      local.set $var27
                    end $label43
                    local.get $var26
                    local.get $var4
                    i32.add
                    local.set $var4
                  end $label38
                  local.get $var4
                  local.get $var32
                  i32.lt_u
                  br_if $label45
                end $label45
                local.get $var4
                local.get $var32
                i32.eq
                br_if $label24
                i32.const 1
                return
              end $label24
              block $label46
                local.get $var14
                local.get $var0
                local.get $var29
                i32.add
                local.get $var28
                i32.const 1264
                i32.const 8
                i32.const 15
                local.get $var15
                i32.const 0
                call $func49
                br_if $label46
                i32.const 1
                return
              end $label46
              local.get $var0
              local.get $var0
              local.get $var29
              i32.const 1392
              i32.const 11
              i32.const 15
              local.get $var15
              local.get $var13
              call $func49
              br_if $label21
              i32.const 1
              return
            end $label21
            i64.const -1
            local.get $var13
            i64.load32_u
            i64.shl
            i64.const -1
            i64.xor
            local.set $var33
            block $label69
              block $label47
                local.get $var23
                local.get $var8
                i32.ge_u
                br_if $label47
                local.get $var24
                local.get $var10
                i32.ge_u
                br_if $label47
                local.get $var2
                i32.const 56
                i32.or
                local.set $var21
                local.get $var23
                local.get $var2
                i32.const 3
                i32.shr_u
                i32.const 7
                i32.and
                i32.sub
                i32.const 7
                i32.add
                local.set $var32
                local.get $var0
                local.get $var23
                i64.load align=1
                local.get $var2
                i32.const 255
                i32.and
                i64.extend_i32_u
                i64.shl
                local.get $var27
                i64.or
                local.tee $var27
                local.get $var33
                i64.and
                i32.wrap_i64
                i32.const 2
                i32.shl
                i32.add
                i32.load
                local.set $var31
                loop $label70
                  local.get $var21
                  local.get $var31
                  i32.sub
                  local.set $var21
                  local.get $var27
                  local.get $var31
                  i32.const 255
                  i32.and
                  i64.extend_i32_u
                  i64.shr_u
                  local.set $var34
                  block $label56
                    block $label53
                      block $label51
                        block $label49
                          block $label48
                            local.get $var31
                            i32.const -1
                            i32.le_s
                            br_if $label48
                            local.get $var34
                            local.set $var22
                            br $label49
                          end $label48
                          local.get $var24
                          local.get $var31
                          i32.const 16
                          i32.shr_u
                          i32.store8
                          local.get $var21
                          local.get $var0
                          local.get $var34
                          local.get $var33
                          i64.and
                          i32.wrap_i64
                          i32.const 2
                          i32.shl
                          i32.add
                          i32.load
                          local.tee $var31
                          i32.sub
                          local.set $var21
                          local.get $var34
                          local.get $var31
                          i32.const 255
                          i32.and
                          i64.extend_i32_u
                          i64.shr_u
                          local.set $var22
                          block $label50
                            local.get $var31
                            i32.const -1
                            i32.le_s
                            br_if $label50
                            local.get $var24
                            i32.const 1
                            i32.add
                            local.set $var24
                            local.get $var34
                            local.set $var27
                            br $label49
                          end $label50
                          local.get $var24
                          local.get $var31
                          i32.const 16
                          i32.shr_u
                          i32.store8 offset=1
                          local.get $var21
                          local.get $var0
                          local.get $var22
                          local.get $var33
                          i64.and
                          i32.wrap_i64
                          i32.const 2
                          i32.shl
                          i32.add
                          i32.load
                          local.tee $var31
                          i32.sub
                          local.set $var21
                          local.get $var22
                          local.get $var31
                          i32.const 255
                          i32.and
                          i64.extend_i32_u
                          i64.shr_u
                          local.set $var34
                          local.get $var31
                          i32.const -1
                          i32.le_s
                          br_if $label51
                          local.get $var24
                          i32.const 2
                          i32.add
                          local.set $var24
                          local.get $var22
                          local.set $var27
                          local.get $var34
                          local.set $var22
                        end $label49
                        block $label52
                          local.get $var31
                          i32.const 32768
                          i32.and
                          br_if $label52
                          local.get $var31
                          i32.const 255
                          i32.and
                          i64.extend_i32_u
                          local.set $var35
                          local.get $var22
                          local.set $var34
                          br $label53
                        end $label52
                        block $label54
                          local.get $var31
                          i32.const 8192
                          i32.and
                          i32.eqz
                          br_if $label54
                          local.get $var32
                          local.set $var23
                          br $label20
                        end $label54
                        local.get $var21
                        local.get $var0
                        local.get $var31
                        i32.const 16
                        i32.shr_u
                        local.get $var22
                        i64.const -1
                        local.get $var31
                        i32.const 8
                        i32.shr_u
                        i32.const 31
                        i32.and
                        i64.extend_i32_u
                        i64.shl
                        i64.const -1
                        i64.xor
                        i64.and
                        i32.wrap_i64
                        i32.add
                        i32.const 2
                        i32.shl
                        i32.add
                        i32.load
                        local.tee $var31
                        i32.sub
                        local.set $var21
                        local.get $var22
                        local.get $var31
                        i32.const 255
                        i32.and
                        i64.extend_i32_u
                        local.tee $var35
                        i64.shr_u
                        local.set $var34
                        block $label55
                          local.get $var31
                          i32.const -1
                          i32.gt_s
                          br_if $label55
                          local.get $var24
                          local.get $var31
                          i32.const 16
                          i32.shr_u
                          i32.store8
                          local.get $var24
                          i32.const 1
                          i32.add
                          local.set $var24
                          local.get $var32
                          i64.load align=1
                          local.get $var21
                          i32.const 255
                          i32.and
                          i64.extend_i32_u
                          i64.shl
                          local.get $var34
                          i64.or
                          local.set $var27
                          local.get $var0
                          local.get $var34
                          local.get $var33
                          i64.and
                          i32.wrap_i64
                          i32.const 2
                          i32.shl
                          i32.add
                          i32.load
                          local.set $var31
                          local.get $var32
                          local.get $var21
                          i32.const 3
                          i32.shr_u
                          i32.const 7
                          i32.and
                          i32.sub
                          i32.const 7
                          i32.add
                          local.set $var32
                          br $label56
                        end $label55
                        local.get $var22
                        local.set $var27
                        local.get $var31
                        i32.const 8192
                        i32.and
                        i32.eqz
                        br_if $label53
                        local.get $var34
                        local.set $var22
                        local.get $var32
                        local.set $var23
                        br $label20
                      end $label51
                      local.get $var24
                      local.get $var31
                      i32.const 16
                      i32.shr_u
                      i32.store8 offset=2
                      local.get $var24
                      i32.const 3
                      i32.add
                      local.set $var24
                      local.get $var32
                      i64.load align=1
                      local.get $var21
                      i32.const 255
                      i32.and
                      i64.extend_i32_u
                      i64.shl
                      local.get $var34
                      i64.or
                      local.set $var27
                      local.get $var0
                      local.get $var34
                      local.get $var33
                      i64.and
                      i32.wrap_i64
                      i32.const 2
                      i32.shl
                      i32.add
                      i32.load
                      local.set $var31
                      local.get $var32
                      local.get $var21
                      i32.const 3
                      i32.shr_u
                      i32.const 7
                      i32.and
                      i32.sub
                      i32.const 7
                      i32.add
                      local.set $var32
                      br $label56
                    end $label53
                    local.get $var21
                    i32.const 255
                    i32.and
                    local.set $var2
                    block $label60
                      block $label57
                        local.get $var14
                        local.get $var34
                        i32.wrap_i64
                        i32.const 255
                        i32.and
                        i32.const 2
                        i32.shl
                        i32.add
                        i32.load
                        local.tee $var4
                        i32.const 32768
                        i32.and
                        i32.eqz
                        br_if $label57
                        block $label59
                          block $label58
                            local.get $var2
                            i32.const 37
                            i32.le_u
                            br_if $label58
                            local.get $var21
                            local.set $var26
                            br $label59
                          end $label58
                          local.get $var21
                          i32.const 56
                          i32.or
                          local.set $var26
                          local.get $var32
                          i64.load align=1
                          local.get $var2
                          i64.extend_i32_u
                          i64.shl
                          local.get $var34
                          i64.or
                          local.set $var34
                          local.get $var32
                          local.get $var21
                          i32.const 3
                          i32.shr_u
                          i32.const 7
                          i32.and
                          i32.sub
                          i32.const 7
                          i32.add
                          local.set $var32
                        end $label59
                        local.get $var14
                        local.get $var4
                        i32.const 16
                        i32.shr_u
                        local.get $var34
                        i64.const 8
                        i64.shr_u
                        local.tee $var34
                        i64.const -1
                        local.get $var4
                        i32.const 8
                        i32.shr_u
                        i32.const 63
                        i32.and
                        i64.extend_i32_u
                        i64.shl
                        i64.const -1
                        i64.xor
                        i64.and
                        i32.wrap_i64
                        i32.add
                        i32.const 2
                        i32.shl
                        i32.add
                        i32.load
                        local.set $var4
                        local.get $var26
                        i32.const -8
                        i32.add
                        local.set $var26
                        br $label60
                      end $label57
                      block $label61
                        local.get $var2
                        i32.const 30
                        i32.le_u
                        br_if $label61
                        local.get $var21
                        local.set $var26
                        br $label60
                      end $label61
                      local.get $var21
                      i32.const 56
                      i32.or
                      local.set $var26
                      local.get $var32
                      i64.load align=1
                      local.get $var2
                      i64.extend_i32_u
                      i64.shl
                      local.get $var34
                      i64.or
                      local.set $var34
                      local.get $var32
                      local.get $var21
                      i32.const 3
                      i32.shr_u
                      i32.const 7
                      i32.and
                      i32.sub
                      i32.const 7
                      i32.add
                      local.set $var32
                    end $label60
                    block $label62
                      local.get $var4
                      i32.const 16
                      i32.shr_u
                      local.tee $var23
                      local.get $var34
                      i64.const -1
                      local.get $var4
                      i32.const 255
                      i32.and
                      i64.extend_i32_u
                      local.tee $var22
                      i64.shl
                      i64.const -1
                      i64.xor
                      i64.and
                      local.get $var4
                      i32.const 8
                      i32.shr_u
                      i32.const 255
                      i32.and
                      i64.extend_i32_u
                      i64.shr_u
                      i32.wrap_i64
                      local.tee $var29
                      i32.add
                      local.tee $var2
                      local.get $var24
                      local.get $var3
                      i32.sub
                      i32.le_u
                      br_if $label62
                      i32.const 1
                      return
                    end $label62
                    local.get $var27
                    i64.const -1
                    local.get $var35
                    i64.shl
                    i64.const -1
                    i64.xor
                    i64.and
                    local.set $var35
                    local.get $var32
                    i64.load align=1
                    local.get $var26
                    local.get $var4
                    i32.sub
                    local.tee $var21
                    i32.const 255
                    i32.and
                    i64.extend_i32_u
                    i64.shl
                    local.get $var34
                    local.get $var22
                    i64.shr_u
                    local.tee $var34
                    i64.or
                    local.set $var27
                    local.get $var24
                    local.get $var2
                    i32.sub
                    local.set $var26
                    local.get $var24
                    local.get $var31
                    i32.const 16
                    i32.shr_u
                    i32.add
                    local.get $var35
                    local.get $var31
                    i32.const 8
                    i32.shr_u
                    i32.const 255
                    i32.and
                    i64.extend_i32_u
                    i64.shr_u
                    i32.wrap_i64
                    i32.add
                    local.set $var4
                    local.get $var32
                    local.get $var21
                    i32.const 3
                    i32.shr_u
                    i32.const 7
                    i32.and
                    i32.sub
                    i32.const 7
                    i32.add
                    local.set $var32
                    local.get $var0
                    local.get $var34
                    local.get $var33
                    i64.and
                    i32.wrap_i64
                    i32.const 2
                    i32.shl
                    i32.add
                    i32.load
                    local.set $var31
                    block $label64
                      block $label63
                        local.get $var2
                        i32.const 8
                        i32.lt_u
                        br_if $label63
                        local.get $var24
                        local.get $var26
                        i64.load align=1
                        i64.store align=1
                        local.get $var24
                        local.get $var26
                        i64.load offset=8 align=1
                        i64.store offset=8 align=1
                        local.get $var24
                        local.get $var26
                        i64.load offset=16 align=1
                        i64.store offset=16 align=1
                        local.get $var24
                        local.get $var26
                        i64.load offset=24 align=1
                        i64.store offset=24 align=1
                        local.get $var24
                        local.get $var26
                        i64.load offset=32 align=1
                        i64.store offset=32 align=1
                        local.get $var24
                        i32.const 40
                        i32.add
                        local.get $var4
                        i32.ge_u
                        br_if $label64
                        i32.const 0
                        local.get $var2
                        i32.sub
                        local.set $var23
                        loop $label65
                          local.get $var24
                          i32.const 40
                          i32.add
                          local.tee $var26
                          local.get $var24
                          local.get $var23
                          i32.add
                          local.tee $var2
                          i32.const 40
                          i32.add
                          i64.load align=1
                          i64.store align=1
                          local.get $var24
                          i32.const 48
                          i32.add
                          local.get $var2
                          i32.const 48
                          i32.add
                          i64.load align=1
                          i64.store align=1
                          local.get $var24
                          i32.const 56
                          i32.add
                          local.get $var2
                          i32.const 56
                          i32.add
                          i64.load align=1
                          i64.store align=1
                          local.get $var24
                          i32.const 64
                          i32.add
                          local.get $var2
                          i32.const 64
                          i32.add
                          i64.load align=1
                          i64.store align=1
                          local.get $var24
                          i32.const 72
                          i32.add
                          local.get $var2
                          i32.const 72
                          i32.add
                          i64.load align=1
                          i64.store align=1
                          local.get $var24
                          i32.const 80
                          i32.add
                          local.set $var2
                          local.get $var26
                          local.set $var24
                          local.get $var2
                          local.get $var4
                          i32.lt_u
                          br_if $label65
                          br $label64
                        end $label65
                      end $label63
                      block $label66
                        local.get $var2
                        i32.const 1
                        i32.ne
                        br_if $label66
                        local.get $var24
                        local.get $var26
                        i64.load8_u
                        i64.const 72340172838076673
                        i64.mul
                        local.tee $var34
                        i64.store offset=24 align=1
                        local.get $var24
                        local.get $var34
                        i64.store offset=16 align=1
                        local.get $var24
                        local.get $var34
                        i64.store offset=8 align=1
                        local.get $var24
                        local.get $var34
                        i64.store align=1
                        local.get $var24
                        i32.const 32
                        i32.add
                        local.tee $var2
                        local.get $var4
                        i32.ge_u
                        br_if $label64
                        loop $label67
                          local.get $var2
                          local.get $var34
                          i64.store align=1
                          local.get $var2
                          i32.const 24
                          i32.add
                          local.get $var34
                          i64.store align=1
                          local.get $var2
                          i32.const 16
                          i32.add
                          local.get $var34
                          i64.store align=1
                          local.get $var2
                          i32.const 8
                          i32.add
                          local.get $var34
                          i64.store align=1
                          local.get $var2
                          i32.const 32
                          i32.add
                          local.tee $var2
                          local.get $var4
                          i32.lt_u
                          br_if $label67
                          br $label64
                        end $label67
                      end $label66
                      local.get $var24
                      local.get $var26
                      i64.load align=1
                      local.tee $var34
                      i64.store align=1
                      local.get $var24
                      local.get $var2
                      i32.add
                      local.get $var34
                      i64.store align=1
                      local.get $var23
                      i32.const 1
                      i32.shl
                      local.get $var29
                      i32.const 1
                      i32.shl
                      i32.add
                      local.set $var26
                      local.get $var2
                      i32.const 3
                      i32.mul
                      local.set $var29
                      loop $label68
                        local.get $var24
                        local.get $var26
                        i32.add
                        local.get $var24
                        local.get $var2
                        i32.add
                        local.tee $var23
                        i64.load align=1
                        local.tee $var34
                        i64.store align=1
                        local.get $var24
                        local.get $var29
                        i32.add
                        local.get $var34
                        i64.store align=1
                        local.get $var23
                        local.get $var2
                        i32.add
                        local.tee $var24
                        local.get $var26
                        i32.add
                        local.get $var4
                        i32.lt_u
                        br_if $label68
                      end $label68
                    end $label64
                    local.get $var4
                    local.set $var24
                  end $label56
                  local.get $var21
                  i32.const 56
                  i32.or
                  local.set $var21
                  local.get $var32
                  local.get $var8
                  i32.ge_u
                  br_if $label69
                  local.get $var24
                  local.get $var10
                  i32.lt_u
                  br_if $label70
                  br $label69
                end $label70
              end $label47
              local.get $var2
              local.set $var21
              local.get $var23
              local.set $var32
            end $label69
            loop $label80
              block $label72
                block $label71
                  local.get $var7
                  local.get $var32
                  i32.sub
                  i32.const 7
                  i32.gt_u
                  br_if $label71
                  local.get $var21
                  i32.const 255
                  i32.and
                  local.tee $var2
                  i32.const 55
                  i32.gt_u
                  br_if $label72
                  loop $label75
                    block $label74
                      block $label73
                        local.get $var32
                        local.get $var7
                        i32.eq
                        br_if $label73
                        local.get $var32
                        i64.load8_u
                        local.get $var2
                        i64.extend_i32_u
                        i64.shl
                        local.get $var27
                        i64.or
                        local.set $var27
                        local.get $var32
                        i32.const 1
                        i32.add
                        local.set $var32
                        br $label74
                      end $label73
                      i32.const 1
                      local.set $var26
                      local.get $var20
                      i32.const 1
                      i32.add
                      local.tee $var20
                      i32.const 8
                      i32.gt_u
                      br_if $label4
                    end $label74
                    local.get $var21
                    i32.const 8
                    i32.add
                    local.tee $var21
                    i32.const 255
                    i32.and
                    local.tee $var2
                    i32.const 56
                    i32.lt_u
                    br_if $label75
                    br $label72
                  end $label75
                end $label71
                local.get $var21
                i32.const 3
                i32.shr_u
                local.set $var2
                local.get $var32
                i64.load align=1
                local.get $var21
                i32.const 255
                i32.and
                i64.extend_i32_u
                i64.shl
                local.get $var27
                i64.or
                local.set $var27
                local.get $var21
                i32.const 56
                i32.or
                local.set $var21
                local.get $var32
                local.get $var2
                i32.const 7
                i32.and
                i32.sub
                i32.const 7
                i32.add
                local.set $var32
              end $label72
              local.get $var21
              local.get $var0
              local.get $var27
              local.get $var33
              i64.and
              i32.wrap_i64
              i32.const 2
              i32.shl
              i32.add
              i32.load
              local.tee $var2
              i32.sub
              local.set $var21
              local.get $var27
              local.get $var2
              i32.const 255
              i32.and
              i64.extend_i32_u
              i64.shr_u
              local.set $var34
              block $label77
                block $label76
                  local.get $var2
                  i32.const 16384
                  i32.and
                  br_if $label76
                  local.get $var27
                  local.set $var22
                  local.get $var34
                  local.set $var27
                  br $label77
                end $label76
                local.get $var21
                local.get $var0
                local.get $var2
                i32.const 16
                i32.shr_u
                local.get $var34
                i64.const -1
                local.get $var2
                i32.const 8
                i32.shr_u
                i32.const 63
                i32.and
                i64.extend_i32_u
                i64.shl
                i64.const -1
                i64.xor
                i64.and
                i32.wrap_i64
                i32.add
                i32.const 2
                i32.shl
                i32.add
                i32.load
                local.tee $var2
                i32.sub
                local.set $var21
                local.get $var34
                local.get $var2
                i32.const 255
                i32.and
                i64.extend_i32_u
                i64.shr_u
                local.set $var27
                local.get $var34
                local.set $var22
              end $label77
              local.get $var2
              i32.const 16
              i32.shr_u
              local.set $var4
              block $label78
                local.get $var2
                i32.const -1
                i32.gt_s
                br_if $label78
                block $label79
                  local.get $var24
                  local.get $var9
                  i32.ne
                  br_if $label79
                  i32.const 3
                  return
                end $label79
                local.get $var24
                local.get $var4
                i32.store8
                local.get $var24
                i32.const 1
                i32.add
                local.set $var24
                br $label80
              end $label78
              block $label81
                local.get $var2
                i32.const 8192
                i32.and
                i32.eqz
                br_if $label81
                local.get $var27
                local.set $var22
                local.get $var32
                local.set $var23
                br $label20
              end $label81
              block $label82
                local.get $var4
                local.get $var22
                i64.const -1
                local.get $var2
                i32.const 255
                i32.and
                i64.extend_i32_u
                i64.shl
                i64.const -1
                i64.xor
                i64.and
                local.get $var2
                i32.const 8
                i32.shr_u
                i32.const 223
                i32.and
                i64.extend_i32_u
                i64.shr_u
                i32.wrap_i64
                local.tee $var26
                i32.add
                local.tee $var31
                local.get $var9
                local.get $var24
                i32.sub
                i32.le_u
                br_if $label82
                i32.const 3
                return
              end $label82
              block $label83
                local.get $var14
                local.get $var27
                i32.wrap_i64
                i32.const 255
                i32.and
                i32.const 2
                i32.shl
                i32.add
                i32.load
                local.tee $var2
                i32.const 32768
                i32.and
                i32.eqz
                br_if $label83
                local.get $var14
                local.get $var2
                i32.const 16
                i32.shr_u
                local.get $var27
                i64.const 8
                i64.shr_u
                local.tee $var27
                i64.const -1
                local.get $var2
                i32.const 8
                i32.shr_u
                i32.const 63
                i32.and
                i64.extend_i32_u
                i64.shl
                i64.const -1
                i64.xor
                i64.and
                i32.wrap_i64
                i32.add
                i32.const 2
                i32.shl
                i32.add
                i32.load
                local.set $var2
                local.get $var21
                i32.const -8
                i32.add
                local.set $var21
              end $label83
              block $label84
                local.get $var2
                i32.const 16
                i32.shr_u
                local.get $var27
                i64.const -1
                local.get $var2
                i32.const 255
                i32.and
                i64.extend_i32_u
                local.tee $var34
                i64.shl
                i64.const -1
                i64.xor
                i64.and
                local.get $var2
                i32.const 8
                i32.shr_u
                i32.const 255
                i32.and
                i64.extend_i32_u
                i64.shr_u
                i32.wrap_i64
                i32.add
                local.tee $var23
                local.get $var24
                local.get $var3
                i32.sub
                i32.le_u
                br_if $label84
                i32.const 1
                return
              end $label84
              local.get $var21
              local.get $var2
              i32.sub
              local.set $var21
              local.get $var27
              local.get $var34
              i64.shr_u
              local.set $var27
              local.get $var24
              local.get $var24
              local.get $var23
              i32.sub
              local.tee $var2
              i32.load8_u
              i32.store8
              local.get $var24
              local.get $var2
              i32.load8_u offset=1
              i32.store8 offset=1
              local.get $var4
              local.get $var24
              i32.add
              local.get $var26
              i32.add
              local.tee $var4
              local.get $var24
              i32.const 3
              i32.add
              local.tee $var26
              local.get $var4
              local.get $var26
              i32.gt_u
              select
              local.get $var24
              i32.sub
              local.set $var4
              local.get $var24
              i32.const 2
              i32.add
              local.set $var26
              local.get $var24
              local.get $var31
              i32.add
              local.set $var24
              local.get $var2
              i32.const 2
              i32.add
              local.set $var2
              block $label86
                block $label85
                  local.get $var4
                  i32.const -2
                  i32.add
                  local.tee $var29
                  i32.const 16
                  i32.ge_u
                  br_if $label85
                  local.get $var26
                  local.set $var4
                  br $label86
                end $label85
                block $label87
                  local.get $var23
                  i32.const 16
                  i32.ge_u
                  br_if $label87
                  local.get $var26
                  local.set $var4
                  br $label86
                end $label87
                i32.const 0
                local.get $var23
                i32.sub
                local.set $var31
                local.get $var26
                local.get $var29
                i32.const -16
                i32.and
                local.tee $var28
                i32.add
                local.set $var4
                local.get $var2
                local.get $var28
                i32.add
                local.set $var2
                local.get $var28
                local.set $var23
                loop $label88
                  local.get $var26
                  local.get $var26
                  local.get $var31
                  i32.add
                  v128.load align=1
                  v128.store align=1
                  local.get $var26
                  i32.const 16
                  i32.add
                  local.set $var26
                  local.get $var23
                  i32.const -16
                  i32.add
                  local.tee $var23
                  br_if $label88
                end $label88
                local.get $var29
                local.get $var28
                i32.eq
                br_if $label80
              end $label86
              loop $label89
                local.get $var4
                local.get $var2
                i32.load8_u
                i32.store8
                local.get $var2
                i32.const 1
                i32.add
                local.set $var2
                local.get $var4
                i32.const 1
                i32.add
                local.tee $var4
                local.get $var24
                i32.lt_u
                br_if $label89
                br $label80
              end $label89
            end $label80
          end $label20
          local.get $var25
          i64.const 1
          i64.and
          i64.eqz
          br_if $label90
        end $label90
        i32.const 1
        local.set $var26
        local.get $var20
        local.get $var21
        i32.const 3
        i32.shr_u
        i32.const 31
        i32.and
        local.tee $var2
        i32.gt_u
        br_if $label4
        block $label91
          local.get $var5
          i32.eqz
          br_if $label91
          local.get $var5
          local.get $var23
          local.get $var20
          local.get $var2
          i32.sub
          i32.add
          local.get $var1
          i32.sub
          i32.store
        end $label91
        block $label92
          local.get $var6
          i32.eqz
          br_if $label92
          local.get $var6
          local.get $var24
          local.get $var3
          i32.sub
          i32.store
          br $label93
        end $label92
        local.get $var24
        local.get $var9
        i32.eq
        br_if $label93
        i32.const 2
        local.set $var26
      end $label4
      local.get $var26
      return
    end $label93
    i32.const 0
  )
  (func $func49 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (param $var4 i32) (param $var5 i32) (param $var6 i32) (param $var7 i32) (result i32)
    (local $var8 i32)
    (local $var9 i32)
    (local $var10 i32)
    (local $var11 i32)
    (local $var12 i32)
    (local $var13 i32)
    (local $var14 i32)
    (local $var15 i32)
    (local $var16 i32)
    (local $var17 i32)
    (local $var18 i32)
    (local $var19 i32)
    (local $var20 i32)
    (local $var21 i32)
    (local $var22 i32)
    global.get $global0
    i32.const 128
    i32.sub
    local.set $var8
    block $label0
      local.get $var5
      i32.const 2
      i32.shl
      i32.const 4
      i32.add
      local.tee $var9
      i32.eqz
      br_if $label0
      local.get $var8
      i32.const 64
      i32.add
      i32.const 0
      local.get $var9
      memory.fill
    end $label0
    block $label1
      local.get $var2
      i32.eqz
      br_if $label1
      local.get $var2
      i32.const 3
      i32.and
      local.set $var10
      i32.const 0
      local.set $var11
      block $label2
        local.get $var2
        i32.const 4
        i32.lt_u
        br_if $label2
        local.get $var2
        i32.const -4
        i32.and
        local.set $var12
        i32.const 0
        local.set $var11
        loop $label3
          local.get $var8
          i32.const 64
          i32.add
          local.get $var1
          local.get $var11
          i32.add
          local.tee $var9
          i32.load8_u
          i32.const 2
          i32.shl
          i32.add
          local.tee $var13
          local.get $var13
          i32.load
          i32.const 1
          i32.add
          i32.store
          local.get $var8
          i32.const 64
          i32.add
          local.get $var9
          i32.const 1
          i32.add
          i32.load8_u
          i32.const 2
          i32.shl
          i32.add
          local.tee $var13
          local.get $var13
          i32.load
          i32.const 1
          i32.add
          i32.store
          local.get $var8
          i32.const 64
          i32.add
          local.get $var9
          i32.const 2
          i32.add
          i32.load8_u
          i32.const 2
          i32.shl
          i32.add
          local.tee $var13
          local.get $var13
          i32.load
          i32.const 1
          i32.add
          i32.store
          local.get $var8
          i32.const 64
          i32.add
          local.get $var9
          i32.const 3
          i32.add
          i32.load8_u
          i32.const 2
          i32.shl
          i32.add
          local.tee $var9
          local.get $var9
          i32.load
          i32.const 1
          i32.add
          i32.store
          local.get $var12
          local.get $var11
          i32.const 4
          i32.add
          local.tee $var11
          i32.ne
          br_if $label3
        end $label3
      end $label2
      local.get $var10
      i32.eqz
      br_if $label1
      local.get $var1
      local.get $var11
      i32.add
      local.set $var9
      loop $label4
        local.get $var8
        i32.const 64
        i32.add
        local.get $var9
        i32.load8_u
        i32.const 2
        i32.shl
        i32.add
        local.tee $var11
        local.get $var11
        i32.load
        i32.const 1
        i32.add
        i32.store
        local.get $var9
        i32.const 1
        i32.add
        local.set $var9
        local.get $var10
        i32.const -1
        i32.add
        local.tee $var10
        br_if $label4
      end $label4
    end $label1
    local.get $var8
    i32.const 64
    i32.add
    local.get $var5
    i32.const 2
    i32.shl
    i32.add
    local.set $var9
    block $label6
      loop $label7
        block $label5
          local.get $var9
          i32.load
          i32.eqz
          br_if $label5
          local.get $var5
          local.set $var11
          br $label6
        end $label5
        local.get $var9
        i32.const -4
        i32.add
        local.set $var9
        i32.const 1
        local.set $var11
        local.get $var5
        i32.const -1
        i32.add
        local.tee $var5
        i32.const 1
        i32.gt_u
        br_if $label7
      end $label7
    end $label6
    block $label8
      local.get $var7
      i32.eqz
      br_if $label8
      local.get $var7
      local.get $var4
      local.get $var11
      local.get $var4
      local.get $var11
      i32.lt_u
      select
      local.tee $var4
      i32.store
    end $label8
    i32.const 0
    local.set $var14
    local.get $var8
    i32.const 0
    i32.store
    local.get $var8
    local.get $var8
    i32.load offset=64
    local.tee $var13
    i32.store offset=4
    i32.const 0
    local.set $var9
    block $label9
      local.get $var11
      i32.const 2
      i32.lt_u
      br_if $label9
      i32.const 1
      local.set $var9
      local.get $var11
      i32.const -1
      i32.add
      local.tee $var5
      i32.const 1
      i32.and
      local.set $var15
      block $label11
        block $label10
          local.get $var11
          i32.const 2
          i32.ne
          br_if $label10
          i32.const 0
          local.set $var5
          br $label11
        end $label10
        local.get $var5
        i32.const -2
        i32.and
        local.set $var16
        local.get $var8
        i32.const 64
        i32.add
        i32.const 8
        i32.or
        local.set $var9
        local.get $var8
        i32.const 12
        i32.or
        local.set $var5
        i32.const 0
        local.set $var10
        i32.const 0
        local.set $var12
        loop $label12
          local.get $var5
          i32.const -4
          i32.add
          local.get $var9
          i32.const -4
          i32.add
          i32.load
          local.tee $var7
          local.get $var13
          i32.add
          local.tee $var13
          i32.store
          local.get $var5
          local.get $var9
          i32.load
          local.tee $var17
          local.get $var13
          i32.add
          local.tee $var13
          i32.store
          local.get $var17
          local.get $var10
          i32.const 2
          i32.shl
          local.get $var7
          i32.const 1
          i32.shl
          i32.add
          i32.add
          local.set $var10
          local.get $var9
          i32.const 8
          i32.add
          local.set $var9
          local.get $var5
          i32.const 8
          i32.add
          local.set $var5
          local.get $var16
          local.get $var12
          i32.const 2
          i32.add
          local.tee $var12
          i32.ne
          br_if $label12
        end $label12
        local.get $var12
        i32.const 1
        i32.add
        local.set $var9
        local.get $var10
        i32.const 1
        i32.shl
        local.set $var5
      end $label11
      block $label13
        local.get $var15
        i32.eqz
        br_if $label13
        local.get $var9
        i32.const 2
        i32.shl
        local.tee $var9
        local.get $var8
        i32.add
        i32.const 4
        i32.add
        local.get $var8
        i32.const 64
        i32.add
        local.get $var9
        i32.add
        i32.load
        local.tee $var9
        local.get $var13
        i32.add
        i32.store
        local.get $var9
        local.get $var5
        i32.add
        local.set $var10
      end $label13
      local.get $var10
      i32.const 1
      i32.shl
      local.set $var9
    end $label9
    local.get $var8
    i32.const 64
    i32.add
    local.get $var11
    i32.const 2
    i32.shl
    i32.add
    i32.load
    local.get $var9
    i32.add
    local.set $var17
    block $label14
      local.get $var2
      i32.eqz
      br_if $label14
      local.get $var2
      i32.const 1
      i32.and
      local.set $var7
      i32.const 0
      local.set $var9
      block $label15
        local.get $var2
        i32.const 1
        i32.eq
        br_if $label15
        local.get $var2
        i32.const -2
        i32.and
        local.set $var12
        i32.const 0
        local.set $var9
        loop $label16
          local.get $var6
          local.get $var8
          local.get $var1
          local.get $var9
          i32.add
          local.tee $var5
          i32.load8_u
          i32.const 2
          i32.shl
          i32.add
          local.tee $var10
          i32.load
          local.tee $var13
          i32.const 1
          i32.shl
          i32.add
          local.get $var9
          i32.store16
          local.get $var10
          local.get $var13
          i32.const 1
          i32.add
          i32.store
          local.get $var8
          local.get $var5
          i32.const 1
          i32.add
          i32.load8_u
          i32.const 2
          i32.shl
          i32.add
          local.tee $var5
          local.get $var5
          i32.load
          local.tee $var5
          i32.const 1
          i32.add
          i32.store
          local.get $var6
          local.get $var5
          i32.const 1
          i32.shl
          i32.add
          local.get $var9
          i32.const 1
          i32.add
          i32.store16
          local.get $var12
          local.get $var9
          i32.const 2
          i32.add
          local.tee $var9
          i32.ne
          br_if $label16
        end $label16
      end $label15
      block $label17
        local.get $var7
        i32.eqz
        br_if $label17
        local.get $var8
        local.get $var1
        local.get $var9
        i32.add
        i32.load8_u
        i32.const 2
        i32.shl
        i32.add
        local.tee $var5
        local.get $var5
        i32.load
        local.tee $var5
        i32.const 1
        i32.add
        i32.store
        local.get $var6
        local.get $var5
        i32.const 1
        i32.shl
        i32.add
        local.get $var9
        i32.store16
      end $label17
      local.get $var8
      i32.load
      local.set $var14
    end $label14
    block $label19
      block $label18
        local.get $var17
        i32.const 1
        local.get $var11
        i32.shl
        local.tee $var9
        i32.le_u
        br_if $label18
        i32.const 0
        local.set $var10
        br $label19
      end $label18
      local.get $var6
      local.get $var14
      i32.const 1
      i32.shl
      i32.add
      local.set $var7
      block $label23
        block $label22
          block $label20
            local.get $var17
            local.get $var9
            i32.lt_u
            br_if $label20
            local.get $var8
            i32.const 64
            i32.add
            i32.const 4
            i32.or
            local.set $var9
            i32.const 0
            local.set $var12
            loop $label21
              local.get $var12
              i32.const 1
              i32.add
              local.set $var12
              local.get $var9
              i32.load
              local.set $var1
              local.get $var9
              i32.const 4
              i32.add
              local.set $var9
              local.get $var1
              i32.eqz
              br_if $label21
            end $label21
            i32.const 0
            local.set $var15
            local.get $var12
            local.get $var4
            i32.le_u
            br_if $label22
            i32.const 0
            local.set $var13
            br $label23
          end $label20
          block $label25
            block $label24
              local.get $var17
              br_if $label24
              i32.const 0
              local.set $var9
              br $label25
            end $label24
            i32.const 0
            local.set $var10
            local.get $var17
            i32.const 1
            local.get $var11
            i32.const -1
            i32.add
            i32.shl
            i32.ne
            br_if $label19
            local.get $var8
            i32.load offset=68
            i32.const 1
            i32.ne
            br_if $label19
            local.get $var7
            i32.load16_u
            local.set $var9
          end $label25
          local.get $var3
          local.get $var9
          i32.const 2
          i32.shl
          i32.add
          i32.load
          i32.const 257
          i32.add
          local.set $var5
          i32.const 1
          local.set $var10
          i32.const 1
          local.set $var9
          loop $label26
            local.get $var0
            local.get $var5
            i32.store
            local.get $var0
            i32.const 4
            i32.add
            local.set $var0
            local.get $var9
            local.get $var4
            i32.shr_u
            local.set $var8
            local.get $var9
            i32.const 1
            i32.add
            local.set $var9
            local.get $var8
            i32.eqz
            br_if $label26
            br $label19
          end $label26
        end $label22
        i32.const 1
        local.get $var12
        i32.shl
        local.set $var5
        local.get $var8
        i32.const 64
        i32.add
        i32.const 4
        i32.or
        local.set $var6
        i32.const 0
        local.set $var13
        loop $label37
          local.get $var5
          i32.const -1
          i32.add
          local.set $var9
          local.get $var12
          i32.const 257
          i32.mul
          local.set $var10
          loop $label33
            local.get $var0
            local.get $var13
            i32.const 2
            i32.shl
            i32.add
            local.get $var10
            local.get $var3
            local.get $var7
            i32.load16_u
            i32.const 2
            i32.shl
            i32.add
            i32.load
            i32.add
            i32.store
            block $label27
              local.get $var13
              local.get $var9
              i32.ne
              br_if $label27
              i32.const 1
              local.set $var10
              local.get $var4
              local.get $var12
              i32.le_u
              br_if $label19
              local.get $var12
              i32.const 1
              i32.add
              local.set $var9
              block $label28
                local.get $var4
                local.get $var12
                i32.sub
                i32.const 1
                i32.and
                i32.eqz
                br_if $label28
                block $label29
                  local.get $var5
                  i32.const 2
                  i32.shl
                  local.tee $var8
                  i32.eqz
                  br_if $label29
                  local.get $var0
                  local.get $var8
                  i32.add
                  local.get $var0
                  local.get $var8
                  memory.copy
                end $label29
                local.get $var12
                i32.const 1
                i32.add
                local.set $var12
                local.get $var5
                i32.const 1
                i32.shl
                local.set $var5
              end $label28
              local.get $var4
              local.get $var9
              i32.eq
              br_if $label19
              local.get $var4
              local.get $var12
              i32.sub
              local.set $var8
              loop $label32
                block $label30
                  local.get $var5
                  i32.const 2
                  i32.shl
                  local.tee $var9
                  i32.eqz
                  br_if $label30
                  local.get $var0
                  local.get $var9
                  i32.add
                  local.get $var0
                  local.get $var9
                  memory.copy
                end $label30
                block $label31
                  local.get $var5
                  i32.const 3
                  i32.shl
                  local.tee $var5
                  i32.eqz
                  br_if $label31
                  local.get $var0
                  local.get $var5
                  i32.add
                  local.get $var0
                  local.get $var5
                  memory.copy
                end $label31
                local.get $var9
                local.set $var5
                local.get $var8
                i32.const -2
                i32.add
                local.tee $var8
                i32.eqz
                br_if $label19
                br $label32
              end $label32
            end $label27
            i32.const 1
            local.get $var13
            local.get $var9
            i32.xor
            i32.clz
            i32.const 31
            i32.xor
            i32.shl
            local.tee $var11
            i32.const -1
            i32.add
            local.get $var13
            i32.and
            local.get $var11
            i32.or
            local.set $var13
            local.get $var7
            i32.const 2
            i32.add
            local.set $var7
            local.get $var1
            i32.const -1
            i32.add
            local.tee $var1
            br_if $label33
          end $label33
          local.get $var6
          local.get $var12
          i32.const 2
          i32.shl
          i32.add
          local.set $var9
          loop $label36
            block $label34
              local.get $var12
              i32.const 1
              i32.add
              local.tee $var12
              local.get $var4
              i32.gt_u
              br_if $label34
              block $label35
                local.get $var5
                i32.const 2
                i32.shl
                local.tee $var11
                i32.eqz
                br_if $label35
                local.get $var0
                local.get $var11
                i32.add
                local.get $var0
                local.get $var11
                memory.copy
              end $label35
              local.get $var5
              i32.const 1
              i32.shl
              local.set $var5
            end $label34
            local.get $var9
            i32.load
            local.set $var1
            local.get $var9
            i32.const 4
            i32.add
            local.set $var9
            local.get $var1
            i32.eqz
            br_if $label36
          end $label36
          local.get $var12
          local.get $var4
          i32.le_u
          br_if $label37
        end $label37
      end $label23
      local.get $var4
      i32.const 49152
      i32.or
      local.set $var18
      i32.const 1
      local.get $var4
      i32.shl
      local.tee $var16
      i32.const -1
      i32.add
      local.set $var19
      local.get $var8
      i32.const 64
      i32.add
      i32.const 4
      i32.or
      local.set $var20
      i32.const -1
      local.set $var9
      loop $label46
        local.get $var20
        local.get $var12
        i32.const 2
        i32.shl
        i32.add
        local.set $var17
        i32.const -1
        local.get $var12
        i32.shl
        i32.const -1
        i32.xor
        local.set $var14
        local.get $var12
        local.get $var4
        i32.sub
        local.tee $var21
        i32.const 257
        i32.mul
        local.set $var22
        i32.const 1
        local.get $var21
        i32.shl
        local.tee $var11
        i32.const 2
        i32.shl
        local.set $var6
        loop $label44
          block $label39
            block $label38
              local.get $var13
              local.get $var19
              i32.and
              local.tee $var2
              local.get $var9
              i32.ne
              br_if $label38
              local.get $var16
              local.set $var5
              local.get $var9
              local.set $var2
              br $label39
            end $label38
            local.get $var21
            local.set $var8
            local.get $var11
            local.set $var10
            block $label40
              local.get $var1
              local.get $var11
              i32.ge_u
              br_if $label40
              local.get $var17
              local.set $var9
              local.get $var21
              local.set $var8
              local.get $var1
              local.set $var5
              loop $label41
                local.get $var9
                i32.load
                local.set $var10
                local.get $var9
                i32.const 4
                i32.add
                local.set $var9
                local.get $var10
                local.get $var5
                i32.const 1
                i32.shl
                i32.add
                local.tee $var5
                i32.const 1
                local.get $var8
                i32.const 1
                i32.add
                local.tee $var8
                i32.shl
                local.tee $var10
                i32.lt_u
                br_if $label41
              end $label41
            end $label40
            local.get $var0
            local.get $var2
            i32.const 2
            i32.shl
            i32.add
            local.get $var16
            i32.const 16
            i32.shl
            local.get $var8
            i32.const 8
            i32.shl
            i32.or
            local.get $var18
            i32.or
            i32.store
            local.get $var10
            local.get $var16
            i32.add
            local.set $var5
            local.get $var16
            local.set $var15
          end $label39
          local.get $var0
          local.get $var15
          local.get $var13
          local.get $var4
          i32.shr_u
          i32.add
          local.tee $var8
          i32.const 2
          i32.shl
          i32.add
          local.set $var9
          local.get $var22
          local.get $var3
          local.get $var7
          i32.load16_u
          i32.const 2
          i32.shl
          i32.add
          i32.load
          i32.add
          local.set $var10
          loop $label42
            local.get $var9
            local.get $var10
            i32.store
            local.get $var9
            local.get $var6
            i32.add
            local.set $var9
            local.get $var8
            local.get $var11
            i32.add
            local.tee $var8
            local.get $var5
            i32.lt_u
            br_if $label42
          end $label42
          block $label43
            local.get $var13
            local.get $var14
            i32.ne
            br_if $label43
            i32.const 1
            return
          end $label43
          i32.const 1
          local.get $var13
          local.get $var14
          i32.xor
          i32.clz
          i32.const 31
          i32.xor
          i32.shl
          local.tee $var9
          i32.const -1
          i32.add
          local.get $var13
          i32.and
          local.get $var9
          i32.or
          local.set $var13
          local.get $var7
          i32.const 2
          i32.add
          local.set $var7
          local.get $var5
          local.set $var16
          local.get $var2
          local.set $var9
          local.get $var1
          i32.const -1
          i32.add
          local.tee $var1
          br_if $label44
        end $label44
        loop $label45
          local.get $var12
          i32.const 1
          i32.add
          local.set $var12
          local.get $var17
          i32.load
          local.set $var1
          local.get $var17
          i32.const 4
          i32.add
          local.set $var17
          local.get $var1
          i32.eqz
          br_if $label45
        end $label45
        local.get $var5
        local.set $var16
        local.get $var2
        local.set $var9
        br $label46
      end $label46
    end $label19
    local.get $var10
  )
  (func $func50 (param $var0 i32) (param $var1 i32) (param $var2 i32) (param $var3 i32) (result i32)
    (local $var4 i32)
    global.get $global0
    i32.const 16
    i32.sub
    local.tee $var4
    global.set $global0
    local.get $var4
    i32.const 0
    i32.store offset=12
    local.get $var4
    i32.const 0
    i32.store offset=8
    block $label1
      block $label0
        i32.const 27152
        local.get $var0
        local.get $var1
        local.get $var2
        local.get $var3
        local.get $var4
        i32.const 12
        i32.add
        local.get $var4
        i32.const 8
        i32.add
        call $func48
        i32.eqz
        br_if $label0
        i32.const -2
        local.set $var3
        br $label1
      end $label0
      block $label2
        local.get $var4
        i32.load offset=8
        local.get $var3
        i32.eq
        br_if $label2
        i32.const -3
        local.set $var3
        br $label1
      end $label2
      i32.const 0
      i32.const -6
      local.get $var4
      i32.load offset=12
      local.get $var1
      i32.eq
      select
      local.set $var3
    end $label1
    local.get $var4
    i32.const 16
    i32.add
    global.set $global0
    local.get $var3
  )
  (data "text\00structured-content\00path\00img\00tag\00type\00image\00,\22glossary\22:\00,\22termTags\22:\00{\22rules\22:\00\00\00\00\00\00\00\00\00\00\00\00\00,\22definitionTags\22:\00\00\00\00\00\00\00\00\00\00\00\00\00\00\10\11\12\00\08\07\09\06\0a\05\0b\04\0c\03\0d\02\0e\01\0f\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\00\01\00\00\00\02\00\00\00\03\00\00\00\04\00\00\00\05\00\00\00\06\00\00\00\07\00\00\00\08\00\00\00\09\00\00\00\0a\00\00\00\0b\00\00\00\0c\00\00\00\0d\00\00\00\0e\00\00\00\0f\00\00\00\10\00\00\00\11\00\00\00\12\00\00\00\00\00\00\00\01\00\00\00\02\00\00\00\03\00\00\00\04\00\01\00\05\00\01\00\07\00\02\00\09\00\02\00\0d\00\03\00\11\00\03\00\19\00\04\00!\00\04\001\00\05\00A\00\05\00a\00\06\00\81\00\06\00\c1\00\07\00\01\01\07\00\81\01\08\00\01\02\08\00\01\03\09\00\01\04\09\00\01\06\0a\00\01\08\0a\00\01\0c\0b\00\01\10\0b\00\01\18\0c\00\01 \0c\00\010\0d\00\01@\0d\00\01`\0d\00\01`\0d\00\01`\00\00\00\80\00\00\01\80\00\00\02\80\00\00\03\80\00\00\04\80\00\00\05\80\00\00\06\80\00\00\07\80\00\00\08\80\00\00\09\80\00\00\0a\80\00\00\0b\80\00\00\0c\80\00\00\0d\80\00\00\0e\80\00\00\0f\80\00\00\10\80\00\00\11\80\00\00\12\80\00\00\13\80\00\00\14\80\00\00\15\80\00\00\16\80\00\00\17\80\00\00\18\80\00\00\19\80\00\00\1a\80\00\00\1b\80\00\00\1c\80\00\00\1d\80\00\00\1e\80\00\00\1f\80\00\00 \80\00\00!\80\00\00\22\80\00\00#\80\00\00$\80\00\00%\80\00\00&\80\00\00'\80\00\00(\80\00\00)\80\00\00*\80\00\00+\80\00\00,\80\00\00-\80\00\00.\80\00\00/\80\00\000\80\00\001\80\00\002\80\00\003\80\00\004\80\00\005\80\00\006\80\00\007\80\00\008\80\00\009\80\00\00:\80\00\00;\80\00\00<\80\00\00=\80\00\00>\80\00\00?\80\00\00@\80\00\00A\80\00\00B\80\00\00C\80\00\00D\80\00\00E\80\00\00F\80\00\00G\80\00\00H\80\00\00I\80\00\00J\80\00\00K\80\00\00L\80\00\00M\80\00\00N\80\00\00O\80\00\00P\80\00\00Q\80\00\00R\80\00\00S\80\00\00T\80\00\00U\80\00\00V\80\00\00W\80\00\00X\80\00\00Y\80\00\00Z\80\00\00[\80\00\00\5c\80\00\00]\80\00\00^\80\00\00_\80\00\00`\80\00\00a\80\00\00b\80\00\00c\80\00\00d\80\00\00e\80\00\00f\80\00\00g\80\00\00h\80\00\00i\80\00\00j\80\00\00k\80\00\00l\80\00\00m\80\00\00n\80\00\00o\80\00\00p\80\00\00q\80\00\00r\80\00\00s\80\00\00t\80\00\00u\80\00\00v\80\00\00w\80\00\00x\80\00\00y\80\00\00z\80\00\00{\80\00\00|\80\00\00}\80\00\00~\80\00\00\7f\80\00\00\80\80\00\00\81\80\00\00\82\80\00\00\83\80\00\00\84\80\00\00\85\80\00\00\86\80\00\00\87\80\00\00\88\80\00\00\89\80\00\00\8a\80\00\00\8b\80\00\00\8c\80\00\00\8d\80\00\00\8e\80\00\00\8f\80\00\00\90\80\00\00\91\80\00\00\92\80\00\00\93\80\00\00\94\80\00\00\95\80\00\00\96\80\00\00\97\80\00\00\98\80\00\00\99\80\00\00\9a\80\00\00\9b\80\00\00\9c\80\00\00\9d\80\00\00\9e\80\00\00\9f\80\00\00\a0\80\00\00\a1\80\00\00\a2\80\00\00\a3\80\00\00\a4\80\00\00\a5\80\00\00\a6\80\00\00\a7\80\00\00\a8\80\00\00\a9\80\00\00\aa\80\00\00\ab\80\00\00\ac\80\00\00\ad\80\00\00\ae\80\00\00\af\80\00\00\b0\80\00\00\b1\80\00\00\b2\80\00\00\b3\80\00\00\b4\80\00\00\b5\80\00\00\b6\80\00\00\b7\80\00\00\b8\80\00\00\b9\80\00\00\ba\80\00\00\bb\80\00\00\bc\80\00\00\bd\80\00\00\be\80\00\00\bf\80\00\00\c0\80\00\00\c1\80\00\00\c2\80\00\00\c3\80\00\00\c4\80\00\00\c5\80\00\00\c6\80\00\00\c7\80\00\00\c8\80\00\00\c9\80\00\00\ca\80\00\00\cb\80\00\00\cc\80\00\00\cd\80\00\00\ce\80\00\00\cf\80\00\00\d0\80\00\00\d1\80\00\00\d2\80\00\00\d3\80\00\00\d4\80\00\00\d5\80\00\00\d6\80\00\00\d7\80\00\00\d8\80\00\00\d9\80\00\00\da\80\00\00\db\80\00\00\dc\80\00\00\dd\80\00\00\de\80\00\00\df\80\00\00\e0\80\00\00\e1\80\00\00\e2\80\00\00\e3\80\00\00\e4\80\00\00\e5\80\00\00\e6\80\00\00\e7\80\00\00\e8\80\00\00\e9\80\00\00\ea\80\00\00\eb\80\00\00\ec\80\00\00\ed\80\00\00\ee\80\00\00\ef\80\00\00\f0\80\00\00\f1\80\00\00\f2\80\00\00\f3\80\00\00\f4\80\00\00\f5\80\00\00\f6\80\00\00\f7\80\00\00\f8\80\00\00\f9\80\00\00\fa\80\00\00\fb\80\00\00\fc\80\00\00\fd\80\00\00\fe\80\00\00\ff\80\00\a0\00\00\00\00\03\00\00\00\04\00\00\00\05\00\00\00\06\00\00\00\07\00\00\00\08\00\00\00\09\00\00\00\0a\00\01\00\0b\00\01\00\0d\00\01\00\0f\00\01\00\11\00\02\00\13\00\02\00\17\00\02\00\1b\00\02\00\1f\00\03\00#\00\03\00+\00\03\003\00\03\00;\00\04\00C\00\04\00S\00\04\00c\00\04\00s\00\05\00\83\00\05\00\a3\00\05\00\c3\00\05\00\e3\00\00\00\02\01\00\00\02\01\00\00\02\01")
)
