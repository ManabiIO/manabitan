// Independent receipt/source audit. Does not import or execute either parser.
import assert from 'node:assert/strict';
import {readFileSync, writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import vm from 'node:vm';
import path from 'node:path';
const root = '/home/agent/manabitan-suffix-evidence-5a86';
const results = path.join(root, 'adversarial-results');
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const raw = (name) => readFileSync(path.join(results, name));
const preflight = JSON.parse(raw('preflight.json'));
const summary = JSON.parse(raw('summary.json'));
const observationsBytes = raw('observations.jsonl');
const records = observationsBytes.toString('utf8').trimEnd().split('\n').map((line) => JSON.parse(line));
const observerBytes = readFileSync(path.join(root, 'adversarial-replay.mjs'));
const observer = observerBytes.toString('utf8');
assert.equal(summary.runnerSha256, sha(observerBytes));
assert.equal(preflight.runnerSha256, summary.runnerSha256);
assert.equal(summary.observationsSha256, sha(observationsBytes));
assert.equal(summary.status, 'passed');
assert.equal(summary.node, 'v22.22.0');
assert.equal(records.length, 6720);
for (const key of ['startedUtc', 'node', 'runnerSha256', 'heads', 'wasmHashes', 'identities', 'plannedValidCases', 'mutationsPerCase', 'scope']) {
  assert.deepEqual(preflight[key], summary[key]);
}
for (const key of ['observations', 'valid', 'malformed', 'emittedRows', 'additionalReuse', 'casesWithAdditionalReuse', 'negativeZeroSequenceCases']) {
  assert.equal(preflight[key], 0);
}
const invocation = JSON.parse(readFileSync(path.join(root, 'adversarial-first-invocation.json')));
assert.equal(invocation.returncode, 0);
assert.equal(invocation.command[2], path.join(root, 'adversarial-replay.mjs'));
assert.ok(Date.parse(invocation.startedUtc) <= Date.parse(preflight.startedUtc));
assert.ok(Date.parse(summary.completedUtc) <= Date.parse(invocation.completedUtc));
// Re-evaluate only the frozen source generator to bind each receipt's input
// hash and prospective order. No capture(), parser import, or native call runs.
const start = observer.indexOf('const spaces =');
const end = observer.indexOf('assert.equal(cases.length, initial.plannedValidCases);');
assert.ok(start >= 0 && end > start);
const sandbox = {};
vm.runInNewContext(observer.slice(start, end) + '\nglobalThis.captured = {cases, group, row, mutationNames};', sandbox, {timeout: 1000});
const {cases, group, row, mutationNames} = sandbox.captured;
assert.equal(cases.length, 480);
assert.equal(mutationNames.length, 12);
const normalized = (value) => JSON.parse(JSON.stringify(value));
let cursor = 0;
const totals = {observations: 0, valid: 0, malformed: 0, emittedRows: 0, additionalReuse: 0,
  casesWithAdditionalReuse: 0, negativeZeroSequenceCases: 0, fusedSuccessValidCases: 0,
  fallbackValidCases: 0, fusedSuccessAdditionalReuse: 0, fallbackAdditionalReuse: 0};
const kindCounts = {};
const distanceCounts = {};
const errors = {};
for (const test of cases) {
  const f = test.fields;
  const s = test.space;
  const mutations = [test.target.slice(0, -1), test.target.slice(0, -1) + '}', row([...f, '"extra"'], s),
    test.target.slice(0, -1) + ',]', row(f.slice(0, 7), s), row([...f.slice(0, 6), '1e', f[7]], s),
    row([...f.slice(0, 6), 'null0', f[7]], s), row([...f.slice(0, 7), '"\\q"'], s),
    row([...f.slice(0, 5), 'null', ...f.slice(6)], s), row([...f.slice(0, 5), f[5].slice(0, -1), ...f.slice(6)], s),
    `[${s}${f.slice(0, 5).join(`${s},${s}`)}${s}${f.slice(5).join(`${s},${s}`)}${s}]`, test.target + 'x'];
  const ordered = [['valid', test.target], ...mutationNames.map((kind, i) => [kind, mutations[i]])];
  for (const [kind, target] of ordered) {
    const record = records[cursor++];
    assert.equal(record.kind, kind);
    assert.deepEqual(record.options, normalized(test.options));
    const sources = group([...test.rows, target], test.options.split, test.space, test.options.empties);
    const sourceSha = sha(JSON.stringify(sources));
    assert.equal(record.sourceSha256, sourceSha);
    kindCounts[kind] = (kindCounts[kind] ?? 0) + 1;
    ++totals.observations;
    if (kind === 'valid') {
      assert.equal(record.A.ok, true); assert.equal(record.B.ok, true);
      assert.equal(record.A.rows, test.options.distance + 1);
      assert.equal(record.B.rows, record.A.rows);
      assert.equal(record.A.indexes, 1); assert.equal(record.B.indexes, 1);
      assert.equal(record.A.attempts, 1); assert.equal(record.B.attempts, 1);
      assert.equal(record.A.fallback, test.options.id % 11 === 0 ? 1 : 0);
      assert.equal(record.B.fallback, record.A.fallback);
      assert.equal(record.A.bankSpanCount, test.options.empties ? 4 : 2);
      assert.equal(record.B.bankSpanCount, record.A.bankSpanCount);
      assert.match(record.aOutputSha256, /^[0-9a-f]{64}$/);
      assert.equal(record.aOutputSha256, record.bOutputSha256);
      assert.ok(record.B.reuse >= record.A.reuse);
      const oracle = records[cursor++];
      assert.equal(oracle.kind, 'no-reuse-oracle');
      assert.deepEqual(oracle.options, normalized(test.options));
      assert.equal(oracle.sourceSha256, sourceSha);
      assert.equal(oracle.ok, true); assert.equal(oracle.reuse, 0);
      assert.equal(oracle.outputSha256, record.aOutputSha256);
      kindCounts[oracle.kind] = (kindCounts[oracle.kind] ?? 0) + 1;
      const extra = record.B.reuse - record.A.reuse;
      assert.ok(extra === 0 || extra === 1);
      if (test.options.distance === 5) assert.equal(extra, 0);
      const dist = distanceCounts[test.options.distance] ??= {cases: 0, additionalReuse: 0};
      ++dist.cases; dist.additionalReuse += extra;
      ++totals.valid; totals.emittedRows += record.A.rows; totals.additionalReuse += extra;
      if (extra > 0) ++totals.casesWithAdditionalReuse;
      if (test.options.numeric === 3) ++totals.negativeZeroSequenceCases;
      const fused = record.B.fallback === 0;
      ++totals[fused ? 'fusedSuccessValidCases' : 'fallbackValidCases'];
      totals[fused ? 'fusedSuccessAdditionalReuse' : 'fallbackAdditionalReuse'] += extra;
    } else {
      for (const arm of ['A', 'B']) {
        assert.equal(record[arm].ok, false);
        assert.equal(record[arm].name, 'Error');
        assert.match(record[arm].message, /^(fused )?term-bank parser failed with code -1$/);
      }
      assert.equal(record.aOutputSha256, null); assert.equal(record.bOutputSha256, null);
      assert.equal(record.A.message, record.B.message);
      errors[record.A.message] = (errors[record.A.message] ?? 0) + 1;
      ++totals.malformed;
    }
  }
}
assert.equal(cursor, records.length);
for (const key of ['observations', 'valid', 'malformed', 'emittedRows', 'additionalReuse', 'casesWithAdditionalReuse', 'negativeZeroSequenceCases']) {
  assert.equal(summary[key], totals[key]);
}
assert.deepEqual(totals, {observations:6240, valid:480, malformed:5760, emittedRows:1920, additionalReuse:353,
  casesWithAdditionalReuse:353, negativeZeroSequenceCases:120, fusedSuccessValidCases:436,
  fallbackValidCases:44, fusedSuccessAdditionalReuse:319, fallbackAdditionalReuse:34});
const sourceChecks = {};
for (const [arm, checkout] of Object.entries({A:'/workspace/scratch/5a86d1e7822a/manabitan', B:'/home/agent/manabitan-suffix-5a86'})) {
  const expectedHead = summary.heads[arm];
  assert.equal(execFileSync('git', ['rev-parse','HEAD'], {cwd:checkout,encoding:'utf8'}).trim(), expectedHead);
  execFileSync('git', ['diff','--exit-code','HEAD','--','ext/js','dev/data/dictionary-wasm'], {cwd:checkout});
  const sourceTree = execFileSync('git', ['rev-parse','HEAD^{tree}'], {cwd:checkout,encoding:'utf8'}).trim();
  for (const [name, hash] of Object.entries(summary.identities[arm].files)) {
    const bytes=readFileSync(path.join(checkout,name));
    assert.equal(sha(bytes), hash);
    assert.deepEqual(bytes,execFileSync('git',['show',expectedHead+':'+name],{cwd:checkout,maxBuffer:4*1024*1024}));
  }
  assert.equal(sha(readFileSync(path.join(checkout,'ext/lib/term-bank-parser.wasm'))), summary.wasmHashes[arm]);
  sourceChecks[arm] = {head: expectedHead, tree: sourceTree, trackedRuntimeCleanAtReview: true};
}
const report = {status:'PASS_WITH_SCOPE_NOTES', auditorSha256:sha(readFileSync(new URL(import.meta.url))),
  observerSha256:summary.runnerSha256, observationsSha256:summary.observationsSha256,
  preflightSha256:sha(raw('preflight.json')), summarySha256:sha(raw('summary.json')),
  records:records.length, kindCounts, totals, distanceCounts, malformedErrorCounts:errors, sourceChecks,
  byteCaptureReview: [
    'Each content range is computed from this complete chunk\'s row metadata plus the native slab base, copied with Uint8Array.slice, and normalized synchronously before the callback returns.',
    'Prepared lookup map values in the pinned API are objects with a Uint8Array bytes field. normalize() converts complete bytes immediately to a base64 string. No live native view survives into later comparisons.',
    'Scores preserve negative zero explicitly, sequences and reading-equality flags are included, and canonical content bytes include definition tags/rules/glossary/term tags. Per-row hashes, content IDs and projected media rows are compared.',
    'Baseline and candidate modules are imported from distinct file URLs and explicitly bound to separately compiled pinned WASM bytes. Each invocation checks input bytes are unchanged, including errors.',
    'The successful observer performs deep equality before writing each no-reuse oracle receipt; all480 oracle digests independently match both arm digests.'
  ],
  scopeNotes:[
    'There are6240 A/B comparison observations plus480 no-reuse-oracle receipts,6720 JSONL records. Count them separately.',
    '44 cases intentionally include a negative-zero score and fall back in both arms.319 extra reuse observations occur in successful fused cases;34 occur before eventual fallback.353 is not an all-fused success count.',
    '120 cases spell sequence as raw -0, distinct from negative-zero score fallback.',
    'The low-level parser builds prepared index bytes but does not build the optional routeFilter; that occurs in copyWasmBackedColumnChunk. This diagnostic is not a route-filter oracle.',
    'The observer compares complete materialized row/index bytes in memory and retains their SHA256 values, not full output-byte payloads. Its independently reusable evidence is source-bound digests plus the frozen generator, not exhaustive persisted-database bytes.',
    'Preflight binds the main parser JS, C, experiments JS and WASM, and asserts Node version. This review additionally observes tracked runtime cleanliness; it cannot retroactively strengthen the preflight to a Node executable hash or a complete imported-module hash manifest.',
    'This replay uses explicit native escaped-key admission and generated raw banks; it is a diagnostic grammar/offset/hint replay, not default-policy production grouping, ZIP CRC, compression, storage, browser, memory or performance qualification.'
  ]};
writeFileSync('/home/agent/manabitan-suffix-review-5a86/adversarial-review.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({status:report.status, totals, sourceChecks, reportSha256:sha(JSON.stringify(report,null,2)+'\n')},null,2));
