// Diagnostic correctness replay. No timed performance comparison.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {readFile, writeFile, mkdir, open} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
import path from 'node:path';

const roots = {
  A: '/workspace/scratch/5a86d1e7822a/manabitan',
  B: '/home/agent/manabitan-suffix-5a86',
};
const heads = {
  A: '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2',
  B: '38031a752b26c9b630e5f2f1d45e780786656c74',
};
const wasmHashes = {
  A: '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee',
  B: 'a9e15a67b2f72adf2288f4c981c0fb78362273953d94440706c41cf44515292f',
};
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', {ignoreBOM: true});
const output = '/home/agent/manabitan-suffix-evidence-5a86/adversarial-results';
await mkdir(output, {recursive: true});
const log = await open(path.join(output, 'observations.jsonl'), 'wx');
const initial = {startedUtc: new Date().toISOString(), node: process.version,
  runnerSha256: sha(await readFile(new URL(import.meta.url))),
  heads, wasmHashes, plannedValidCases: 480, mutationsPerCase: 12,
  scope: 'Public native column parser; generated source; source validity, complete semantic row bytes and prepared-index bytes; no browser, compression, persistence or timing claim',
  identities: {}, observations: 0, valid: 0, malformed: 0, emittedRows: 0,
  additionalReuse: 0, casesWithAdditionalReuse: 0, negativeZeroSequenceCases: 0};
assert.equal(process.version, 'v22.22.0');
const modules = {};
for (const arm of ['A', 'B']) {
  const root = roots[arm];
  const actualHead = execFileSync('git', ['rev-parse', 'HEAD'], {cwd: root, encoding: 'utf8'}).trim();
  assert.equal(actualHead, heads[arm]);
  const wasm = await readFile(path.join(root, 'ext/lib/term-bank-parser.wasm'));
  assert.equal(sha(wasm), wasmHashes[arm]);
  const files = {};
  for (const file of ['ext/js/dictionary/term-bank-wasm-parser.js', 'ext/js/dictionary/wasm/term-bank-parser.c', 'ext/js/dictionary/term-bank-experiments.js']) {
    const bytes = await readFile(path.join(root, file));
    const expected = execFileSync('git', ['show', `${heads[arm]}:${file}`], {cwd: root, maxBuffer: 4 * 1024 * 1024});
    assert.deepEqual(bytes, expected);
    files[file] = sha(bytes);
  }
  initial.identities[arm] = {head: actualHead, files, wasmSha256: sha(wasm)};
  const parser = await import(pathToFileURL(path.join(root, 'ext/js/dictionary/term-bank-wasm-parser.js')).href);
  parser.setTermBankWasmModule(await WebAssembly.compile(wasm));
  modules[arm] = parser;
}
assert.equal(initial.identities.A.files['ext/js/dictionary/term-bank-wasm-parser.js'], initial.identities.B.files['ext/js/dictionary/term-bank-wasm-parser.js']);

function normalize(value) {
  if (ArrayBuffer.isView(value)) {
    return {type: value.constructor.name, bytes: Buffer.from(value.buffer, value.byteOffset, value.byteLength).toString('base64')};
  }
  if (value === undefined) { return {$undefined: true}; }
  if (typeof value === 'number' && Object.is(value, -0)) { return {$negativeZero: true}; }
  if (Array.isArray(value)) { return value.map(normalize); }
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, v]) => [key, normalize(v)]));
  }
  return value;
}

async function capture(arm, sources, reuse = true) {
  const parser = modules[arm];
  const rows = [];
  const indexes = [];
  const sourceBytes = sources.map((s) => encoder.encode(s));
  const before = sourceBytes.map(sha);
  try {
    await parser.parseTermBankWithWasmColumnChunks(sourceBytes, 3, (chunk) => {
      const plan = chunk.termRecordPreinternedPlan;
      const lengths = plan.stringLengths;
      const offsets = plan.stringOffsets;
      assert.ok(offsets && chunk.contentMetaList && chunk.contentBytesBuffer);
      const strings = Array.from(lengths, (n, i) => decoder.decode(plan.stringsBuffer.subarray(offsets[i], offsets[i] + n)));
      const meta = chunk.contentMetaList;
      for (let i = 0; i < chunk.rowCount; ++i) {
        const m = i * 4;
        const offset = meta[m] + (chunk.contentBytesBaseOffset ?? 0);
        rows.push(normalize({expression: strings[plan.expressionIndexes[i]],
          reading: strings[plan.readingIndexes[i]], readingEquals: chunk.readingEqualsExpressionList[i],
          score: chunk.scoreList[i], sequence: chunk.sequenceList[i],
          contentId: chunk.contentUniqueIndexList?.[i],
          content: chunk.contentBytesBuffer.slice(offset, offset + meta[m + 1]),
          hashes: [meta[m + 2], meta[m + 3]],
          media: chunk.mediaRows.filter((entry) => entry.index === i).map(({index, row, imagePaths}) => ({index, row, imagePaths}))}));
      }
      if (chunk.preparedLookupIndexes) {
        for (const [key, value] of chunk.preparedLookupIndexes) {
          indexes.push(normalize({key, bytes: value.bytes, routeFilter: value.routeFilter}));
        }
      }
    }, 8192, {singleChunk: true, emitTermByteLists: false, computeContentHashes: true,
      emitContentSlab: true, emitTokenBinaryContent: true, mediaHintFastScan: true,
      validateGlossaryTypes: true, prepareLookupIndexes: true, prepareLookupRoute: true,
      experimentalNativeEscapedKeys: true, experimentalValidatedGlossaryReuse: reuse});
    const profile = parser.consumeLastTermBankWasmParseProfile();
    assert.deepEqual(sourceBytes.map(sha), before);
    return {ok: true, rows, indexes,
      reuse: profile?.validatedGlossaryReuseCount ?? 0,
      fallback: profile?.fusedParseFallbacks ?? 0,
      attempts: profile?.fusedParseAttempts ?? 0,
      bankSpanCount: profile?.bankSpanCount ?? 0};
  } catch (error) {
    parser.consumeLastTermBankWasmParseProfile();
    assert.deepEqual(sourceBytes.map(sha), before);
    return {ok: false, name: error.name, message: error.message};
  }
}

const spaces = ['', ' ', '\r\n\t', '\t \n'];
const sequences = ['null', '0', '2147483647', '-0'];
const glossaries = [
  '[]',
  '["plain \\u8272","quote \\" and slash \\\\","nul \\u0000"]',
  '[{"type":"text","text":"text \\uD83D\\uDE00"}]',
  '[{"type":"image","path":"a.webp","width":12},{"type":"text","text":"caption"}]',
  '[{"type":"structured-content","content":[{"tag":"span","content":"色"},{"tag":"img","path":"b.webp"}],"extra":null}]',
  JSON.stringify([{type: 'structured-content', content: [{tag: 'div', content: 'a'.repeat(4112) + 'X' + 'b'.repeat(4096)}]}]),
];
for (const glossary of glossaries) { JSON.parse(glossary); }
function row(fields, space) { return `[${space}${fields.join(`${space},${space}`)}${space}]`; }
function group(rows, split, space, empties) {
  const banks = [`[${space}${rows.slice(0, split).join(`${space},${space}`)}${space}]`,
    `[${space}${rows.slice(split).join(`${space},${space}`)}${space}]`];
  if (empties) { banks.splice(1, 0, '[]', '[ \r\n\t ]'); }
  return banks;
}
const mutationNames = ['missing-row-close', 'wrong-row-close', 'extra-field', 'trailing-comma',
  'missing-tag', 'invalid-sequence', 'sequence-null-suffix', 'invalid-tag-escape',
  'non-array-glossary', 'unclosed-glossary', 'missing-field-delimiter', 'junk-after-row'];
const cases = [];
for (let distance = 1; distance <= 5; ++distance) {
  for (let shape = 0; shape < glossaries.length; ++shape) {
    for (let whitespace = 0; whitespace < spaces.length; ++whitespace) {
      for (let numeric = 0; numeric < sequences.length; ++numeric) {
        const id = cases.length;
        const space = spaces[whitespace];
        const sequence = sequences[numeric];
        const glossary = glossaries[shape];
        const tags = id % 2 === 0 ? '"tag\\u0000value"' : '"\\u8272\\\\tail"';
        const prefix = ['"\\u524d-key"', '"reading"', 'null', '"v1"', '17'];
        const tail = [glossary, sequence, tags];
        const sourceRows = [row([...prefix, ...tail], space)];
        for (let gap = 1; gap < distance; ++gap) {
          sourceRows.push(row([JSON.stringify(`gap${gap}`), '""', '"noun"', '""', `${gap}`,
            JSON.stringify([`different${gap}`]), '42', '""'], spaces[(whitespace + gap) % spaces.length]));
        }
        const targetPrefix = ['"last\\\\key"', '"reading\\n一"', '"adj"', '"v5"', id % 11 === 0 ? '-0' : '23'];
        let targetTail = tail;
        // Equal sample/length shapes with one interior difference must still
        // pass a complete comparison before any old grammar can be reused.
        if (shape === 5 && id % 3 === 0) {
          targetTail = [glossary.replace('X', 'Y'), sequence, tags];
        }
        const targetFields = [...targetPrefix, ...targetTail];
        const target = row(targetFields, space);
        const split = id % 2 === 0 ? sourceRows.length : Math.max(1, sourceRows.length - 1);
        const options = {id, distance, shape, whitespace, numeric, split, empties: id % 3 === 0};
        cases.push({options, rows: sourceRows, fields: targetFields, target, space});
      }
    }
  }
}
assert.equal(cases.length, initial.plannedValidCases);
await writeFile(path.join(output, 'preflight.json'), JSON.stringify(initial, null, 2) + '\n', {flag: 'wx'});

async function verify(test, kind, target, expectedValid) {
  const sources = group([...test.rows, target], test.options.split, test.space, test.options.empties);
  const sourceSha256 = sha(JSON.stringify(sources));
  const a = await capture('A', sources);
  const b = await capture('B', sources);
  const comparison = {options: test.options, kind, sourceSha256,
    A: {...a, rows: a.ok ? a.rows.length : undefined, indexes: a.ok ? a.indexes.length : undefined},
    B: {...b, rows: b.ok ? b.rows.length : undefined, indexes: b.ok ? b.indexes.length : undefined},
    aOutputSha256: a.ok ? sha(JSON.stringify({rows: a.rows, indexes: a.indexes})) : null,
    bOutputSha256: b.ok ? sha(JSON.stringify({rows: b.rows, indexes: b.indexes})) : null};
  await log.write(JSON.stringify(comparison) + '\n');
  ++initial.observations;
  try {
    assert.equal(a.ok, expectedValid, `baseline validity differs in ${kind}`);
    assert.equal(b.ok, expectedValid, `candidate validity differs in ${kind}`);
    if (expectedValid) {
      assert.deepEqual(b.rows, a.rows);
      assert.deepEqual(b.indexes, a.indexes);
      assert.equal(b.fallback, a.fallback);
      assert.equal(b.attempts, a.attempts);
      assert.equal(b.bankSpanCount, a.bankSpanCount);
      assert.ok(b.reuse >= a.reuse);
      const noReuse = await capture('A', sources, false);
      assert.equal(noReuse.ok, true);
      assert.deepEqual(b.rows, noReuse.rows);
      assert.deepEqual(b.indexes, noReuse.indexes);
      await log.write(JSON.stringify({options: test.options, kind: 'no-reuse-oracle', sourceSha256,
        ok: true, reuse: noReuse.reuse, outputSha256: sha(JSON.stringify({rows: noReuse.rows, indexes: noReuse.indexes}))}) + '\n');
      ++initial.valid;
      initial.emittedRows += a.rows.length;
      initial.additionalReuse += b.reuse - a.reuse;
      if (b.reuse > a.reuse) { ++initial.casesWithAdditionalReuse; }
      if (test.options.numeric === 3) { ++initial.negativeZeroSequenceCases; }
    } else { ++initial.malformed; }
  } catch (error) {
    await writeFile(path.join(output, `failure-${test.options.id}-${kind}.json`), JSON.stringify({sources, a, b, error: error.stack}, null, 2) + '\n');
    throw error;
  }
}

try {
  for (const test of cases) {
    await verify(test, 'valid', test.target, true);
    const f = test.fields;
    const s = test.space;
    const mutations = [
      test.target.slice(0, -1),
      test.target.slice(0, -1) + '}',
      row([...f, '"extra"'], s),
      test.target.slice(0, -1) + ',]',
      row(f.slice(0, 7), s),
      row([...f.slice(0, 6), '1e', f[7]], s),
      row([...f.slice(0, 6), 'null0', f[7]], s),
      row([...f.slice(0, 7), '"\\q"'], s),
      row([...f.slice(0, 5), 'null', ...f.slice(6)], s),
      row([...f.slice(0, 5), f[5].slice(0, -1), ...f.slice(6)], s),
      `[${s}${f.slice(0, 5).join(`${s},${s}`)}${s}${f.slice(5).join(`${s},${s}`)}${s}]`,
      test.target + 'x',
    ];
    assert.equal(mutations.length, mutationNames.length);
    for (let i = 0; i < mutations.length; ++i) {
      await verify(test, mutationNames[i], mutations[i], false);
    }
    if ((test.options.id + 1) % 60 === 0) {
      process.stdout.write(JSON.stringify({completedValid: initial.valid, completedMalformed: initial.malformed}) + '\n');
    }
  }
  assert.equal(initial.valid, 480);
  assert.equal(initial.malformed, 5760);
  assert.ok(initial.casesWithAdditionalReuse > 0);
  initial.status = 'passed';
} catch (error) {
  initial.status = 'failed';
  initial.error = error.stack;
  process.exitCode = 1;
} finally {
  initial.completedUtc = new Date().toISOString();
  await log.close();
  initial.observationsSha256 = sha(await readFile(path.join(output, 'observations.jsonl')));
  await writeFile(path.join(output, 'summary.json'), JSON.stringify(initial, null, 2) + '\n', {flag: 'wx'});
  process.stdout.write(JSON.stringify(initial, null, 2) + '\n');
}
