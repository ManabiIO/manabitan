from pathlib import Path
import hashlib,json,subprocess,sys,traceback
ROOT=Path('/tmp/manabitan-2754-memory')
TOOLING=Path('/workspace/scratch/2754d3e3fa09/memory')
DIRECTORY='dev/perf/import-memory-20261124-3aac'
sys.path.insert(0,str(TOOLING/DIRECTORY))
from audit_memory import audit_cell
from verify_receipts import verify
from protocol import receipt_comparison_key,digest
expected_sources={
 'A':{'commit':'7d1643e6147a10cb2165e9744cf0e63b59e46632','tree':'99d23f16e973c7ae9feba77ca3643d1c27dfb93d'},
 'B':{'commit':'7a8b25a44a3fe165107ed816377cc72bb0fac67d','tree':'093a0be94fcf336ab5a0113b80fae7481855935a'}
}
report={'schemaVersion':1,'workflowRun':'45642179064','sourceIdentities':expected_sources,'scope':'Independent read-only raw-scan, package, source and correctness audit; no new acquisition or retries','frozenObserver':{},'artifacts':[],'crossReplicationReceiptEquality':{}}
for name in ['chromium_memory.py','audit_memory.py']:
 original=subprocess.check_output(['git','show',f'f2f08c8ee74cdea548c5c1b494ec15bf10360b46:dev/perf/import-memory-20261123-72c24/{name}'],cwd=TOOLING)
 current=(TOOLING/DIRECTORY/name).read_bytes()
 assert current==original,name
 report['frozenObserver'][name]={'unchanged':True,'sha256':hashlib.sha256(current).hexdigest()}
receipts={}
for artifact in [15035921814,15036925291,15036831091,15035433747]:
 location=ROOT/str(artifact)
 plan=json.loads((location/'plan.json').read_text())
 assert plan['sourceIdentities']==expected_sources
 assert str(plan['workflowRun'])==report['workflowRun']
 for name,expected in plan['sourceFiles'].items():
  assert digest(TOOLING/name)==expected,('live-tool-source',name)
 row={'artifactId':artifact,'dictionary':plan['dictionary'],'replication':plan['replication'],'schedule':[x['name'] for x in plan['schedule']],'archiveSha256':digest(ROOT/f'{artifact}.zip'),'sourceAndAuditToolHashesMatch':True}
 try:
  row['rawScanAudit']=audit_cell(location)
  assert row['rawScanAudit']==json.loads((location/'memory-audit.json').read_text())
  row['receiptAudit']=verify(location)
  assert row['receiptAudit']==json.loads((location/'receipt-audit.json').read_text())
  row['auditReconciliation']='passed'
 except Exception as error:
  row['auditReconciliation']='failed'
  row['auditError']=repr(error)
  row['auditTraceback']=traceback.format_exc()
  report['artifacts'].append(row)
  continue
 comp=json.loads((location/'memory-comparison.json').read_text())
 row['pairs']=comp['pairs']
 row['metrics']=comp['metrics']
 row['qualification']=json.loads((location/'qualification.json').read_text())
 assert row['qualification']['correctnessPassed']==row['receiptAudit']['allCorrectnessPassed']
 assert row['qualification']['memoryScreenPassed']==row['rawScanAudit']['passesProspectiveMemoryScreen']
 assert row['qualification']['retriedObservations']==0
 assert row['qualification']['status']==('passed' if row['qualification']['correctnessPassed'] and row['qualification']['memoryScreenPassed'] else 'failed')
 row['observations']=[]
 for observation in plan['schedule']:
  name=observation['name']
  memory=json.loads((location/name/'memory.json').read_text())
  correct=json.loads((location/name/'correctness.json').read_text())
  sample_keys=['qualifiedForWholeTreePss','qualificationFailures','benchmarkExitCode','allObservedSampleCount','fullyContainedImportSampleCount','stableFullyReadImportSampleCount','maximumCoveredSampleGapMs','preImportBracketGapMs','postImportBracketGapMs','maxSampledPssKiB','maxSampledPrivateKiB','samplesWithUnavailableSmaps','samplesWithUnreadableAddressSpaces','confirmedExitedZombieIdentityCount','observedProcessCountRange']
  obs={**observation,**{k:memory[k] for k in sample_keys},'correctnessStatus':correct['status']}
  if correct['status']=='passed':
   receipt=correct['receipt']
   key=receipt_comparison_key(receipt)
   receipts.setdefault(plan['dictionary'],[]).append(key)
   obs['activeSahFileBytes']=receipt['storage']['sahPool']['activeFileBytes']
   obs['rawStorageBytes']=receipt['storage']['rawStorageBytes']
   obs['nonSahBytes']=receipt['storage']['nonSahBytes']
  row['observations'].append(obs)
 row['packages']={arm:{k:json.loads((location/f'{arm}-identity.json').read_text())[k] for k in ['commit','tree','packageSha256']} for arm in ['A','B']}
 row['host']=json.loads((location/'A1/host-before.json').read_text())
 row['retainedFailure']=json.loads((location/'failure.json').read_text()) if (location/'failure.json').exists() else None
 report['artifacts'].append(row)
for dictionary,values in receipts.items():
 report['crossReplicationReceiptEquality'][dictionary]={'observations':len(values),'allEqual':all(v==values[0] for v in values),'browserVersion':values[0]['browserVersion']}
 assert len(values)==8 and report['crossReplicationReceiptEquality'][dictionary]['allEqual']
report['allAuditReconciliationsPassed']=all(row['auditReconciliation']=='passed' for row in report['artifacts'])
report['allCorrectnessPassed']=all(row.get('receiptAudit',{}).get('allCorrectnessPassed',False) for row in report['artifacts'])
report['promotionMemoryPass']=all(row.get('rawScanAudit',{}).get('passesProspectiveMemoryScreen',False) for row in report['artifacts'])
report['totalRawScans']=sum(row.get('rawScanAudit',{}).get('rawScanCount',0) for row in report['artifacts'])
output=ROOT/'independent-current-media-audit.json'
output.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'report':str(output),'allAuditReconciliationsPassed':report['allAuditReconciliationsPassed'],'allCorrectnessPassed':report['allCorrectnessPassed'],'promotionMemoryPass':report['promotionMemoryPass'],'totalRawScans':report['totalRawScans'],'artifacts':[{'artifactId':r['artifactId'],'dictionary':r['dictionary'],'replication':r['replication'],'auditReconciliation':r['auditReconciliation'],'auditError':r.get('auditError'),'qualification':r.get('qualification'),'metrics':r.get('metrics'),'observations':r.get('observations')} for r in report['artifacts']]},indent=2))
