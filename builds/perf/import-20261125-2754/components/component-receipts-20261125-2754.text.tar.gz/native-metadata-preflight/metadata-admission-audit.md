# Metadata publication admission audit

**Decision: stop this candidate and retain the measured whole-import regression.** This bounded read-only audit found no concrete structural admission defect and no justified corrective change. No new acquisition, product edit, threshold adjustment or test was performed.

## Exact source and evidence scope

Frozen study candidate `b2e816c4714f42f87cbb6a1ebc7fe1a2d2fd863b`, tree `be5b6a8d9c24915516d6edd8167a071e0449d793`, baseline `7d1643e6147a10cb2165e9744cf0e63b59e46632`. Reviewed local source is `60a8a9c1daeb1873017194f852ce6f7fef736d05`, tree `dcaa01db1e3cb790275ea71543e1cd607cb46be9`. All reviewed production files match the frozen tree byte for byte except canonical-scan formatting, whose previously retained exact normalized-AST equivalence receipt is included in the accompanying JSON. Later local test-only changes do not alter production code.

The analysis reopens all 18 timed JMdict summaries: six observations per arm. Warmups and media diagnostics are excluded according to the original cohort. Original summary paths and SHA-256 digests, all per-observation values, source hashes and exact comparison results are preserved in `metadata-admission-audit.json`.

The unchanged complete-import screen remains decisive: candidate B/A is +1.471% and B/C is +1.724%, with zero faster pairs against either baseline. This report does not reinterpret or replace that negative result.

## Ownership and scheduling

1. `adoptPendingColumns` copies the scanner's borrowed WASM OUT views into owned pending arrays. Hashes and staged IDs use newly allocated ordinary typed arrays; span offsets/lengths use plan-owned `Uint32Array` scratch allocated by `getOrCreateTermContentPlanScratch`. These columns are not views of the canonical arena.
2. The enclosing `scan()` releases `activeScratch` in `finally` before its promise resolves. `_resolveArtifactTermContentDedup` awaits it before returning. `_bulkAddArtifactTermsChunkWithContentDedup` then awaits dedup and persistence before metadata publication. The production worker pipeline's ordered sink awaits each full callback, so the next chunk's scan is not active during current publication. Exact-match callbacks resolve or append pending descriptors; they do not publish metadata.
3. Normal block persistence sets `VALIDATED_TERM_CONTENT_METADATA`, creates an exact-sized ordinary `Float64Array` for offsets and returns the owned `Uint32Array` length column. The returned staged-index slice is also exact-sized. Successful native canonical eligibility bounds chunk/unique counts to the existing 100,000-row ABI, so pending publication does not need a new threshold.
4. Arena construction puts native authoritative tables after the reserved prefix and keeps IDs, offsets, dictionary IDs and recent-source output arrays in distinct ordinary buffers. The normal completed-reservation path neither retargets those tables nor resizes the arena before publication. Thus the alias and scratch guards do not systematically exclude production.

Raw persistence with numeric arrays, collision/unreserved IDs, missing instances, malformed private inputs and actual reentry remain intended fallback cases. There is no justification to weaken those guards.

**Evidence limit:** the retained reports have canonical-scan counters, but no publication-preflight admission/success/fallback counter. The code establishes reachability and excludes the proposed universal-alias/active-scratch explanation; it does not establish an observed native publisher call count.

## Existing report checks

Every timed summary records 12 chunks, 12 native canonical calls, 366,030 scanned unique representatives, 362,032 native pending rows, 3,998 exact candidates, zero native scanner fallbacks and zero separate metadata staging time. These are scanner counters, not publisher-success counters.

The existing `contentMetadataIndexPublishMs` timer includes recent-source caching. The table subtracts its nested `dedupRecentSourceCacheMs` within each observation. Values are milliseconds and remain descriptive diagnostic phase measurements.

| Block | A baseline | B candidate | C identical baseline |
|---|---:|---:|---:|
| 1 | 45.900 | 9.500 | 38.200 |
| 2 | 27.800 | 14.400 | 32.100 |
| 3 | 30.700 | 13.800 | 21.600 |
| 4 | 32.100 | 20.500 | 16.700 |
| 5 | 21.400 | 24.400 | 21.000 |
| 6 | 29.100 | 15.200 | 21.900 |
| Median | 29.900 | 14.800 | 21.750 |

The smaller candidate median is consistent with useful work in this phase; it is not a direct admission counter or a complete-import benefit. Other existing medians are:

| Timer | A | B | C |
|---|---:|---:|---:|
| Content store | 337.550 | 372.050 | 350.150 |
| Content compression | 284.150 | 317.700 | 298.800 |

These timers overlap other work. They cannot be added to explain the end-to-end difference, and they do not establish why the candidate regressed.

## Why the component result does not qualify this candidate

The component harness uses 14 fixed four-bank groups with a fresh database per group; production uses 12 byte-balanced worker groups and one persistent metadata owner. The harness sets `dictionaryTotalRows` to the current group's row count, suppressing the production whole-dictionary preallocation hint. It replaces compression/OPFS persistence with immediately resolving fake storage and runs without concurrent production workers.

Its timer surrounds only `_tryPublishContiguousArtifactTermContentMetadata`, so new scanner ownership bookkeeping and the rest of the import are outside the measured boundary. The control correctly disables only `validateReservedMetadata` by returning null; both arms retain existing bulk publication. Recorded component admission is 13 successful native calls and 358,990 rows, which applies only to that component setup.

The component evidence establishes local correctness and a bounded validation improvement. The full-browser frozen result establishes a regression for the intended import. No structural fix was established, so the recommendation is to stop this candidate and preserve both results.
