import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import {performance} from 'node:perf_hooks'
import {DictionaryDatabase} from '../jmdict/ext/js/dictionary/dictionary-database.js'
import {NativeCanonicalScanner} from '../jmdict/ext/js/dictionary/term-content-canonical-scan.js'

const module = await WebAssembly.compile(await fs.readFile(new URL('../jmdict/ext/lib/term-content-canonical-scan-v1.wasm', import.meta.url)))
const results = []
for (const n of [10000, 50000, 100000]) {
    const db = new DictionaryDatabase()
    db._nativeCanonicalScanner = new NativeCanonicalScanner({loadModule: async () => module})
    const ids = Uint32Array.from({length: n}, (_, i) => i)
    const bytes = new Uint8Array(n * 4)
    const meta = new Uint32Array(n * 4)
    for (let i = 0; i < n; ++i) {
        bytes.set([i & 255, (i >>> 8) & 255, 7, 9], i * 4)
        meta.set([i * 4, 4, i + 1, (i ^ 0x9e3779b9) >>> 0], i * 4)
    }
    const plan = {
        uniqueCount: n, sourceRowCount: n, uniqueRowIndexes: ids.slice(),
        uniqueSignatures: new Uint32Array(n * 3), resolvedFlags: new Uint8Array(n),
        resolvedOffsets: new Float64Array(n), resolvedLengths: new Uint32Array(n),
        resolvedDictNames: new Array(n), pendingEpochs: null, pendingIndexes: null,
        nextEpoch: 1, persistedLookupRequired: true,
    }
    const chunk = {
        rowCount: n, contentRowStart: 0, contentBytesList: [],
        contentHash1List: new Uint32Array(), contentHash2List: new Uint32Array(),
        contentBytesBuffer: bytes, contentBytesBaseOffset: 0, contentMetaList: meta,
        contentUniqueIndexList: ids, contentDedupPlan: plan, contentDictNameList: null,
        uniformContentDictName: 'raw', useResolvedContentReferences: true,
    }
    const reservation = await db._resolveArtifactTermContentDedup(chunk, true)
    const indexes = reservation.stagedContentMetadata.indexes
    const hash1s = reservation.pendingContentHash1s
    const hash2s = reservation.pendingContentHash2s
    const offsets = Float64Array.from({length: n}, (_, i) => i * 4)
    const lengths = new Uint32Array(n).fill(4)
    assert.equal(indexes.length, n)
    assert.equal(db._nativeCanonicalScanner.stats.calls, 1)
    const nativeMethod = db._nativeCanonicalScanner.validateReservedMetadata
    const jsMethod = () => null
    const samples = {native: [], js: []}
    for (let round = 0; round < 110; ++round) {
        for (const mode of round % 2 ? ['js', 'native'] : ['native', 'js']) {
            db._termEntryContentMetaStateTable.fill(2, 0, n)
            db._termEntryContentMetaHashPairPendingCount = n
            db._termEntryContentMetaHashPairCount = 0
            db._nativeCanonicalScanner.validateReservedMetadata = mode === 'native' ? nativeMethod : jsMethod
            const start = performance.now()
            assert.equal(db._tryPublishContiguousArtifactTermContentMetadata(
                reservation.stagedContentMetadata, hash1s, hash2s, offsets, lengths, 0, true,
            ), true)
            const elapsed = performance.now() - start
            if (round >= 10) samples[mode].push(elapsed)
        }
    }
    for (const mode of ['native', 'js']) samples[mode].sort((a, b) => a - b)
    const nativeMs = samples.native[50]
    const jsMs = samples.js[50]
    results.push({rows: n, nativeMs, jsMs, deltaPercent: (nativeMs / jsMs - 1) * 100,
        nativeP95Ms: samples.native[95], jsP95Ms: samples.js[95],
        addedScratchCopyBytes: n * 16, addedRetainedBytes: 0})
}
console.log(JSON.stringify({kind: 'Node component screen, not complete import evidence', node: process.version, results}, null, 2))
