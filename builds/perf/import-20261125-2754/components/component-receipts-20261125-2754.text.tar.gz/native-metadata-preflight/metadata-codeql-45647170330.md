# Final JMdict head: CodeQL failure receipt

**Failure phase established; exact root cause remains unresolved.** The retained evidence does not justify classifying this as a source defect or an environment-only failure. CodeQL remains failed and unqualified.

- PR: [#914](https://github.com/ManabiIO/manabitan/pull/914).
- Head: `b273513dab4fa409a0213a2db470e52b4a0f559c`, tree `dcaa01db1e3cb790275ea71543e1cd607cb46be9`.
- Workflow: [CodeQL run 45647170330](https://github.com/ManabiIO/manabitan/actions/runs/45647170330), attempt 1, completed with `failure`.
- Job: [Analyze (javascript)](https://github.com/ManabiIO/manabitan/actions/runs/45647170330/job/139321163431), `139321163431`.
- Failed step: `Perform CodeQL Analysis`; checkout, initialization and autobuild passed.

## Observed boundary

All 89 query evaluations report completion. At `2026-11-25T16:04:13.9782357Z`, the job records successful SARIF export. At `16:04:14.0534703Z`, it logs `Uploading results`. The next relevant entry is post-job cleanup at `16:04:41.4037396Z`; cleanup later confirms the job status was failure.

The complete decoded job log contains no explicit error annotation, HTTP failure, fatal/termination message or process exit code explaining that transition. The associated check run has null title/summary/text and zero annotations. The run exposes no artifacts, so the generated SARIF and diagnostic files referenced during cleanup are unavailable for inspection.

This localizes the observed failure to after analysis and SARIF generation, at or after upload begins. It does **not** establish whether upload/service behavior, runner execution or a source-related result caused it. Successful SARIF generation also does not prove an absence of security findings.

The workflow is byte-identical to baseline `7d1643e6147a10cb2165e9744cf0e63b59e46632`. It uses CodeQL action `95e58e9a2cdfd71adc6e0353d5c52f41a045d225`; the job reports CLI 2.27.6 and `SecurityEvents: write`. These observations are retained without inferring a permission failure.

## Preserved evidence

`metadata-codeql-45647170330.json` contains run/job/step identities, exact timestamped excerpts with original line numbers, check-run output, observed artifact availability, source/workflow identities and explicit limitations. `metadata-codeql-45647170330-job.log` retains the complete decoded job log (691,953 bytes; SHA-256 `e8c8d4807d6d4206c817d5cebe28ff872dc0a9716dd290a2f5b8b161611fc96d`).

This was a bounded read-only inspection. No workflow rerun, new scan, product edit or settings change was performed.
