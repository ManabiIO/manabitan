import assert from 'node:assert/strict'
import {readFile, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {inflateRawSync} from 'node:zlib'
import {performance} from 'node:perf_hooks'
import {ZipReader, Uint8ArrayReader} from '../manabitan/node_modules/@zip.js/zip.js/index.js'
import {DictionaryDatabase} from '../jmdict/ext/js/dictionary/dictionary-database.js'
import {TermRecordOpfsStore} from '../jmdict/ext/js/dictionary/term-record-opfs-store.js'
import {NativeCanonicalScanner} from '../jmdict/ext/js/dictionary/term-content-canonical-scan.js'
import {readDenseZipDirectory} from '../jmdict/ext/js/dictionary/dense-zip-directory.js'
import * as parser from '../jmdict/ext/js/dictionary/term-bank-wasm-parser.js'

const name = process.argv[2] ?? 'jmdict'
const root = new URL('../jmdict/', import.meta.url)
const locks = JSON.parse(await readFile(new URL('test/perf/dictionaries.lock.json', root), 'utf8')).dictionaries
const spec = locks[name]
const hash = (bytes) => createHash('sha256').update(bytes).digest('hex')
const archive = await readFile(new URL(`../manabitan/builds/e2e-dictionary-cache/${spec.cacheFile}`, root))
assert.equal(archive.byteLength, spec.sizeBytes)
assert.equal(hash(archive), spec.sha256)
const blob = {size: archive.byteLength, slice(start, end = archive.byteLength) {
    return {arrayBuffer: async () => archive.buffer.slice(archive.byteOffset + start, archive.byteOffset + end)}
}}
let entries = await readDenseZipDirectory(blob)
if (entries === null) {
    const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive.buffer, archive.byteOffset, archive.byteLength)))
    entries = await reader.getEntries()
    await reader.close()
}
entries = entries.filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename))
    .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
const canonicalBytes = await readFile(new URL('ext/lib/term-content-canonical-scan-v1.wasm', root))
const canonicalModule = await WebAssembly.compile(canonicalBytes)
const parserBytes = await readFile(new URL('ext/lib/term-bank-parser.wasm', root))
parser.setTermBankWasmModule(await WebAssembly.compile(parserBytes))
const options = {singleChunk: true, emitTermByteLists: false, computeContentHashes: true,
    emitContentSlab: true, emitTokenBinaryContent: true, mediaHintFastScan: true,
    validateGlossaryTypes: true, prepareLookupIndexes: true, prepareLookupRoute: true}
const fields = ['HashPairTable', 'Hash1Table', 'Hash2Table', 'StateTable', 'IdTable', 'OffsetTable',
    'LengthTable', 'DictNameIdTable', 'SignaturePresentTable', 'Signature1Table', 'Signature2Table',
    'Signature3Table', 'RecentSourceBatchIdTable', 'RecentSourceOffsetTable']
function updateView(digest, view) { digest.update(new Uint8Array(view.buffer, view.byteOffset, view.byteLength)) }
async function owner(source, native) {
    const db = new DictionaryDatabase()
    const scanner = new NativeCanonicalScanner({loadModule: async () => canonicalModule})
    db._nativeCanonicalScanner = scanner
    let nativeCalls = 0
    let nativeRows = 0
    const validate = scanner.validateReservedMetadata
    scanner.validateReservedMetadata = (...args) => {
        if (!native) return null
        const result = validate.apply(scanner, args)
        if (result === true) { ++nativeCalls; nativeRows += args[6] }
        return result
    }
    const plan = source.contentDedupPlan
    assert.ok(plan)
    const chunk = {...source, dictionary: 'component-fixture', dictionaryTotalRows: source.rowCount,
        contentDictNameList: null, uniformContentDictName: 'raw', releaseBorrowedContent: undefined,
        preparedLookupIndexes: source.preparedLookupIndexes ? new Map(source.preparedLookupIndexes) : undefined,
        contentDedupPlan: {...plan, resolvedFlags: new Uint8Array(plan.uniqueCount),
            resolvedOffsets: new Float64Array(plan.uniqueCount), resolvedLengths: new Uint32Array(plan.uniqueCount),
            resolvedDictNames: null, resolvedUniformDictName: undefined, pendingEpochs: null, pendingIndexes: null,
            nextEpoch: 1, nextUnresolvedUniqueIndex: 0, persistedLookupRequired: true}}
    db._bulkImportTransactionOpen = true
    db._deferTermsVirtualTableSync = true
    db._termContentZstdInitialized = true
    const content = createHash('sha256')
    const records = createHash('sha256')
    const metadata = createHash('sha256')
    const storedContent = new Map()
    let next = 0
    let contentRows = 0
    db._readTermEntryContentBytesDetailed = async (offset) => ({status: 'ok', bytes: storedContent.get(offset)})
    db._termContentBlockImportSession = {tryBeginAppendSpans(_dict, buffer, offsets, lengths) {
        const contentOffsets = new Float64Array(offsets.length)
        const contentLengths = lengths.slice()
        for (let i = 0; i < offsets.length; ++i) {
            contentOffsets[i] = next
            const bytes = buffer.subarray(offsets[i], offsets[i] + lengths[i])
            content.update(bytes)
            storedContent.set(next, bytes)
            next += bytes.length
            ++contentRows
        }
        const stored = {contentOffsets, contentLengths, contentDictName: 'raw'}
        return {initialSelection: false, storage: Promise.resolve(stored), sourceConsumed: Promise.resolve(),
            completion: Promise.resolve({...stored, packMs: 0, compressMs: 0, envelopeMs: 0, referenceMs: 0, opfsAppendMs: 0})}
    }}
    const encoder = new TermRecordOpfsStore()
    db._termRecordStore = {async appendBatchFromArtifactChunkResolvedContent(value) {
        const encoded = await encoder._encodeArtifactChunkRecords(value, new Float64Array(), new Uint32Array(), value.termRecordPreinternedPlan)
        records.update(JSON.stringify([encoded.contentOffsetBase, encoded.recordFieldsFormat]))
        updateView(records, encoded.recordFields)
        updateView(records, encoded.lookupIndexBytes)
        const refs = value.resolvedContentReferences
        updateView(records, refs.uniqueIndexList)
        updateView(records, refs.offsets)
        updateView(records, refs.lengths)
        return {buildRecordsMs: 0, encodeMs: 0, appendWriteMs: 0}
    }}
    let publicationMs = 0
    const publish = db._tryPublishContiguousArtifactTermContentMetadata
    db._tryPublishContiguousArtifactTermContentMetadata = (...args) => {
        const start = performance.now()
        try { return publish.apply(db, args) } finally { publicationMs += performance.now() - start }
    }
    await db._bulkAddArtifactTermsChunkWithContentDedup(chunk)
    for (const field of fields) updateView(metadata, db[`_termEntryContentMeta${field}`])
    metadata.update(JSON.stringify([db._termEntryContentMetaHashPairCount, db._termEntryContentMetaHashPairPendingCount,
        db._termEntryContentMetaDenseCount, db._termEntryContentMetaDictNames, [...db._termEntryContentMetaCollisionsByHashPair]]))
    assert.equal(db._termEntryContentMetaHashPairPendingCount, 0)
    return {digest: [content.digest('hex'), records.digest('hex'), metadata.digest('hex')],
        contentRows, contentBytes: next, nativeCalls, nativeRows, publicationMs}
}
const groups = []
let rows = 0
for (let start = 0; start < entries.length; start += 4) {
    const sources = entries.slice(start, start + 4).map((entry) => {
        assert.equal(archive.readUInt32LE(entry.offset), 0x04034b50)
        const begin = entry.offset + 30 + archive.readUInt16LE(entry.offset + 26) + archive.readUInt16LE(entry.offset + 28)
        const bytes = archive.subarray(begin, begin + entry.compressedSize)
        const result = entry.compressionMethod === 0 ? bytes : inflateRawSync(bytes)
        assert.equal(result.byteLength, entry.uncompressedSize)
        return new Uint8Array(result.buffer, result.byteOffset, result.byteLength)
    })
    await parser.parseTermBankWithWasmColumnChunks(sources, 3, async (chunk) => {
        const order = groups.length % 2 ? [true, false] : [false, true]
        const result = {}
        for (const native of order) result[native ? 'native' : 'js'] = await owner(chunk, native)
        assert.deepEqual(result.native.digest, result.js.digest)
        assert.equal(result.native.contentRows, result.js.contentRows)
        assert.equal(result.native.contentBytes, result.js.contentBytes)
        rows += chunk.rowCount
        groups.push({start, rows: chunk.rowCount, ...result})
    }, 2048, options)
    globalThis.gc?.()
}
assert.equal(rows, spec.termRows)
const summary = {scope: 'component parity, fixed groups of four banks, fresh metadata owner per group; fake persistence plus production record/index encoder; not browser import timing',
    dictionary: name, archiveSha256: spec.sha256, canonicalWasmSha256: hash(canonicalBytes), parserWasmSha256: hash(parserBytes),
    node: process.version, rows, groups: groups.length,
    nativeCalls: groups.reduce((sum, group) => sum + group.native.nativeCalls, 0),
    nativeRows: groups.reduce((sum, group) => sum + group.native.nativeRows, 0),
    nativePublicationMs: groups.reduce((sum, group) => sum + group.native.publicationMs, 0),
    jsPublicationMs: groups.reduce((sum, group) => sum + group.js.publicationMs, 0),
    outputDigest: hash(JSON.stringify(groups.map((group) => group.native.digest))),
    lifetimeMaxRssKiB: process.resourceUsage().maxRSS}
assert.ok(summary.nativeCalls > 0)
await writeFile(new URL(`${name}-publish-real-parity.json`, import.meta.url), JSON.stringify({...summary, observations: groups}, null, 2) + '\n')
console.log(JSON.stringify(summary, null, 2))
