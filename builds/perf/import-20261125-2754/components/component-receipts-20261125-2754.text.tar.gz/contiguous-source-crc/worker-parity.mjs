import assert from 'node:assert/strict'
import {readFile, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {pathToFileURL} from 'node:url'
import {Worker as ThreadWorker} from 'node:worker_threads'
import {ZipReader, Uint8ArrayReader} from '@zip.js/zip.js'

const workspace = '/workspace/scratch/2754d3e3fa09'
const [dictionary = 'jitendex', arm = 'jitendex', mode = 'parallel'] = process.argv.slice(2)
assert.ok(['manabitan', 'jitendex'].includes(arm))
const root = `${workspace}/${arm}`
const spec = JSON.parse(await readFile(`${root}/test/perf/dictionaries.lock.json`, 'utf8')).dictionaries[dictionary]
const archive = await readFile(`${workspace}/manabitan/builds/e2e-dictionary-cache/${spec.cacheFile}`)
const sha256 = data => createHash('sha256').update(data).digest('hex')
assert.equal(archive.byteLength, spec.sizeBytes)
assert.equal(sha256(archive), spec.sha256)
let reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive.buffer, archive.byteOffset, archive.byteLength)))
const entries = []
for await (const entry of reader.getEntriesGenerator()) {
    if (/^term_bank_\d+\.json$/.test(entry.filename)) entries.push(entry)
}
entries.sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
await reader.close()
reader = null
const termination = []
const profiles = []
class BrowserWorker extends EventTarget {
    constructor(url) {
        super()
        this.worker = new ThreadWorker(pathToFileURL(`${root}/test/fixtures/parser-settlement/worker-node.mjs`), {workerData: {url: url.href}})
        this.worker.on('message', data => {
            if (data.type === 'result') profiles.push({id: data.id, profile: data.profile})
            this.dispatchEvent(new MessageEvent('message', {data}))
        })
        this.worker.on('error', error => {
            const event = new Event('error')
            Object.defineProperty(event, 'message', {value: error.message})
            this.dispatchEvent(event)
        })
        this.worker.on('messageerror', () => this.dispatchEvent(new MessageEvent('messageerror')))
    }
    postMessage(data, transfer) { this.worker.postMessage(data, transfer) }
    terminate() { termination.push(this.worker.terminate()) }
}
globalThis.Worker = BrowserWorker
Object.defineProperty(globalThis, 'navigator', {value: {hardwareConcurrency: 4, deviceMemory: 8}, configurable: true})
const parser = await import(pathToFileURL(`${root}/ext/js/dictionary/term-bank-wasm-parser.js`).href)
const wasm = await readFile(`${root}/ext/lib/term-bank-parser.wasm`)
parser.setTermBankWasmModule(await WebAssembly.compile(wasm))
function update(hash, value) {
    if (typeof value === 'function') return
    if (value === undefined || value === null) { hash.update(`${value}\n`); return }
    if (ArrayBuffer.isView(value)) {
        hash.update(`${value.constructor.name}:${value.byteLength}\n`)
        hash.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength))
    } else if (value instanceof Map) {
        for (const [key, entry] of value) { hash.update(`${key}\n`); update(hash, entry) }
    } else if (typeof value === 'object') {
        for (const key of Object.keys(value).sort()) { hash.update(`${key}\n`); update(hash, value[key]) }
    } else { hash.update(`${value}\n`) }
}
const hash = createHash('sha256')
let rows = 0, contentBytes = 0, groups = 0
const options = {computeContentHashes: true, emitContentSlab: true, emitTokenBinaryContent: true, emitTermByteLists: false,
    prepareLookupIndexes: true, prepareLookupRoute: true, validateGlossaryTypes: true, projectImagePaths: true, mediaHintFastScan: true}
const consume = chunk => {
    rows += chunk.rowCount
    contentBytes += chunk.contentBytesLength
    groups++
    const {contentBytesBuffer, contentBytesBaseOffset = 0, releaseBorrowedContent, preparedLookupIndexEncodeMs, ...metadata} = chunk
    update(hash, metadata)
    update(hash, contentBytesBuffer.subarray(contentBytesBaseOffset, contentBytesBaseOffset + chunk.contentBytesLength))
}
const load = entry => {
    assert.equal(archive.readUInt32LE(entry.offset), 0x04034b50)
    const start = entry.offset + 30 + archive.readUInt16LE(entry.offset + 26) + archive.readUInt16LE(entry.offset + 28)
    return {bytes: new Uint8Array(archive.subarray(start, start + entry.compressedSize)), compressionMethod: entry.compressionMethod,
        compressedSize: entry.compressedSize, uncompressedSize: entry.uncompressedSize, signature: entry.signature, filename: entry.filename}
}
try {
    if (mode === 'bounded') {
        const total = entries.reduce((sum, entry) => sum + entry.uncompressedSize, 0)
        const groupCount = Math.min(entries.length, Math.max(9, Math.ceil(total / (24 * 1024 * 1024))))
        const partitions = []
        let start = 0, consumedBytes = 0
        // Same production byte-balancing algorithm and full-corpus group count.
        for (let groupIndex = 0; groupIndex < groupCount - 1; groupIndex++) {
            const remainingGroups = groupCount - groupIndex
            const target = (total - consumedBytes) / remainingGroups
            let end = start + 1, bytes = entries[start].uncompressedSize
            const maxEnd = entries.length - (remainingGroups - 1)
            while (end < maxEnd) {
                const nextBytes = bytes + entries[end].uncompressedSize
                if (Math.abs(nextBytes - target) > Math.abs(bytes - target)) break
                bytes = nextBytes; end++
            }
            partitions.push(entries.slice(start, end)); start = end; consumedBytes += bytes
        }
        partitions.push(entries.slice(start))
        const module = await WebAssembly.compile(wasm)
        let worker
        const request = (message, transfer = []) => new Promise((resolve, reject) => {
            const timeout = setTimeout(() => reject(new Error('Bounded replay timeout')), 30000)
            worker.once('error', reject)
            worker.once('message', result => { clearTimeout(timeout); worker.removeListener('error', reject); resolve(result) })
            worker.postMessage(message, transfer)
        })
        try {
            for (const [index, entries] of partitions.entries()) {
                if (index % 20 === 0) {
                    if (worker) await worker.terminate()
                    worker = new ThreadWorker(pathToFileURL(`${root}/test/fixtures/parser-settlement/worker-node.mjs`), {
                        workerData: {url: pathToFileURL(`${root}/ext/js/dictionary/term-bank-wasm-parser-worker.js`).href},
                    })
                    assert.equal((await request({type: 'initialize', module})).type, 'ready')
                }
                const sources = entries.map(load)
                const sourceBuffers = sources.map(source => source.bytes.buffer)
                const sourceMetadata = sources.map(({bytes, ...metadata}) => metadata)
                const result = await request({type: 'parse', id: index + 1, sourceBuffers, sourceMetadata, version: 3, chunkSize: 2048,
                    options: {...options, ownContentBytes: total >= 512 * 1024 * 1024, experimentalNativeEscapedKeys: total >= 512 * 1024 * 1024}}, sourceBuffers)
                assert.equal(result.type, 'result', JSON.stringify(result.error))
                assert.equal(result.id, index + 1)
                profiles.push({id: index + 1, profile: result.profile})
                consume(result.chunk)
            }
        } finally { if (worker) await worker.terminate() }
    } else {
        const ok = await parser.parseTermBankWithWasmColumnChunksParallelCompressedLazy(entries.map(entry => async () => load(entry)),
            entries.map(entry => entry.uncompressedSize), 3, consume, options)
        assert.equal(ok, true)
    }
    assert.equal(rows, spec.termRows)
    const report = {dictionary, arm, rows, groups, contentBytes, digest: hash.digest('hex'), node: process.version,
        archiveSha: spec.sha256, wasmSha: sha256(wasm), mode, scope: 'untimed exact production compressed-worker chunk output parity',
        profile: parser.consumeLastTermBankWasmParseProfile(), groupsProfiles: profiles.sort((a,b)=>a.id-b.id),
        lifetimeMaxRssKiB: process.resourceUsage().maxRSS, settledMemory: process.memoryUsage()}
    await writeFile(`${workspace}/jitendex/builds/perf/${dictionary}-${arm}-${mode}-worker-parity.json`, JSON.stringify(report, null, 2) + '\n')
    console.log(JSON.stringify({...report, profile: undefined, groupsProfiles: undefined}))
} finally {
    await parser.disposeParallelTermBankParser()
    await Promise.all(termination)
}
