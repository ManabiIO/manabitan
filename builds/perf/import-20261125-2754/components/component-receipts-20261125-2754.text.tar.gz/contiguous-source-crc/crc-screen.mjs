import assert from 'node:assert/strict'
import {readFile, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {pathToFileURL} from 'node:url'
import {ZipReader, Uint8ArrayReader} from '@zip.js/zip.js'

const root = '/workspace/scratch/2754d3e3fa09'
const dictionary = process.argv[2] ?? 'jitendex'
const count = Number(process.argv[3] ?? 1)
const locked = JSON.parse(await readFile(`${root}/jitendex/test/perf/dictionaries.lock.json`, 'utf8')).dictionaries[dictionary]
const archive = await readFile(`${root}/manabitan/builds/e2e-dictionary-cache/${locked.cacheFile}`)
const sha = bytes => createHash('sha256').update(bytes).digest('hex')
assert.equal(sha(archive), locked.sha256)
assert.equal(archive.length, locked.sizeBytes)
const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)))
const entries = (await reader.getEntries()).filter(entry => /^term_bank_\d+\.json$/.test(entry.filename))
    .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
const sources = entries.map(entry => {
    assert.equal(archive.readUInt32LE(entry.offset), 0x04034b50)
    const start = entry.offset + 30 + archive.readUInt16LE(entry.offset + 26) + archive.readUInt16LE(entry.offset + 28)
    return {bytes: new Uint8Array(archive.subarray(start, start + entry.compressedSize)), compressionMethod: entry.compressionMethod,
        compressedSize: entry.compressedSize, uncompressedSize: entry.uncompressedSize, signature: entry.signature, filename: entry.filename}
})
await reader.close()
const arms = []
for (const directory of ['manabitan', 'jitendex']) {
    const parser = await import(pathToFileURL(`${root}/${directory}/ext/js/dictionary/term-bank-wasm-parser.js`).href)
    const wasm = await readFile(`${root}/${directory}/ext/lib/term-bank-parser.wasm`)
    parser.setTermBankWasmModule(await WebAssembly.compile(wasm))
    arms.push({directory, parser, wasmSha: sha(wasm)})
}
const options = {singleChunk: true, computeContentHashes: true, emitContentSlab: true, emitTokenBinaryContent: true,
    emitTermByteLists: false, prepareLookupIndexes: true, prepareLookupRoute: true, validateGlossaryTypes: true,
    projectImagePaths: true, mediaHintFastScan: true}
const groupSize = dictionary === 'jmdict' ? 7 : dictionary === 'jitendex' ? 10 : 4
function update(hash, value) {
    if (value === undefined || value === null) { hash.update(`${value}\n`); return }
    if (ArrayBuffer.isView(value)) {
        hash.update(`${value.constructor.name}:${value.byteLength}\n`)
        hash.update(new Uint8Array(value.buffer, value.byteOffset, value.byteLength))
    } else if (value instanceof Map) {
        for (const [key, entry] of value) { hash.update(`${key}\n`); update(hash, entry) }
    } else if (typeof value === 'object') {
        for (const key of Object.keys(value).sort()) {
            if (['byteOffset', 'baseOffset', 'buffer', 'provenance', 'owned'].includes(key)) continue
            hash.update(`${key}\n`); update(hash, value[key])
        }
    } else { hash.update(`${value}\n`) }
}
async function execute(arm, limit = sources.length, verify = true) {
    let elapsed = 0, rows = 0, reused = 0, scanned = 0, crcMs = 0, parseMs = 0, inflateMs = 0
    const hash = createHash('sha256')
    for (let start = 0; start < limit; start += groupSize) {
        const group = sources.slice(start, Math.min(start + groupSize, limit))
        let chunk
        const before = performance.now()
        const preloadedSource = await arm.parser.inflateCompressedTermBankSourcesWasm(group, options, true)
        await arm.parser.parseTermBankWithWasmColumnChunks(new Uint8Array(0), 3, value => { assert.equal(chunk, undefined); chunk = value }, 2048, {...options, preloadedSource})
        elapsed += performance.now() - before
        assert.ok(chunk)
        rows += chunk.rowCount
        const profile = arm.parser.consumeLastTermBankWasmParseProfile()
        reused += preloadedSource.crcReusedBytes ?? 0
        scanned += preloadedSource.crcScannedBytes ?? 0
        crcMs += preloadedSource.crcMs ?? 0
        parseMs += profile?.parseBankMs ?? 0
        inflateMs += preloadedSource.inflateMs ?? 0
        if (!verify) continue
        update(hash, chunk.preparedLookupIndexes)
        update(hash, chunk.termRecordPreinternedPlan)
        for (const field of ['readingEqualsExpressionList', 'scoreList', 'sequenceList', 'mediaRows']) update(hash, chunk[field])
        assert.ok(chunk.contentMetaList && chunk.contentBytesBuffer)
        for (let row = 0; row < chunk.rowCount; row++) {
            const offset = (chunk.contentBytesBaseOffset ?? 0) + chunk.contentMetaList[row * 4]
            update(hash, chunk.contentBytesBuffer.subarray(offset, offset + chunk.contentMetaList[row * 4 + 1]))
            update(hash, chunk.contentMetaList.subarray(row * 4 + 1, row * 4 + 4))
        }
    }
    return {arm: arm.directory, wasmSha: arm.wasmSha, rows, elapsed, reused, scanned, crcMs, parseMs, inflateMs, digest: verify ? hash.digest('hex') : null}
}
for (let warmup = 0; warmup < 2; warmup++) {
    for (const arm of arms) await execute(arm, sources.length, false)
}
const results = []
for (let pair = 0; pair < count; pair++) {
    for (const arm of pair % 2 ? [...arms].reverse() : arms) {
        globalThis.gc?.()
        const result = await execute(arm)
        assert.equal(result.rows, locked.termRows)
        results.push({pair, ...result})
        console.log(JSON.stringify({pair, ...result}))
    }
    assert.equal(results.at(-1).digest, results.at(-2).digest)
}
await writeFile(`${root}/jitendex/builds/perf/${dictionary}-crc-screen-${arms[1].wasmSha.slice(0,8)}.json`, JSON.stringify({dictionary, source: locked.sha256, scope: 'compressed parser component, excludes workers/database/storage/UI; diagnostics only', results}, null, 2) + '\n')
