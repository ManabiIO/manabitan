import assert from 'node:assert/strict'
import {readFile, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {Worker as ThreadWorker} from 'node:worker_threads'
import {ZipReader, Uint8ArrayReader} from '@zip.js/zip.js'
import * as parser from '../../ext/js/dictionary/term-bank-wasm-parser.js'

const root = new URL('../../', import.meta.url)
const dictionary = process.argv[2] ?? 'jitendex'
const locks = JSON.parse(await readFile(new URL('test/perf/dictionaries.lock.json', root), 'utf8')).dictionaries
const spec = locks[dictionary]
const archive = await readFile(new URL(`../manabitan/builds/e2e-dictionary-cache/${spec.cacheFile}`, root))
assert.equal(archive.byteLength, spec.sizeBytes)
assert.equal(createHash('sha256').update(archive).digest('hex'), spec.sha256)
const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)))
const entries = (await reader.getEntries()).filter(entry => /^term_bank_\d+\.json$/.test(entry.filename))
    .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
const termination = []
const profiles = []
class BrowserWorker extends EventTarget {
    constructor(url) {
        super()
        this.worker = new ThreadWorker(new URL('test/fixtures/parser-settlement/worker-node.mjs', root), {workerData: {url: url.href}})
        this.worker.on('message', data => {
            if (data.type === 'result') profiles.push({id: data.id, profile: data.profile})
            this.dispatchEvent(new MessageEvent('message', {data}))
        })
        this.worker.on('error', error => {
            const event = new Event('error')
            Object.defineProperty(event, 'message', {value: error.message})
            this.dispatchEvent(event)
        })
        this.worker.on('messageerror', () => this.dispatchEvent(new MessageEvent('messageerror')))
    }
    postMessage(data, transfer) { this.worker.postMessage(data, transfer) }
    terminate() { termination.push(this.worker.terminate()) }
}
globalThis.Worker = BrowserWorker
Object.defineProperty(globalThis, 'navigator', {value: {hardwareConcurrency: 4, deviceMemory: 8}, configurable: true})
parser.setTermBankWasmModule(await WebAssembly.compile(await readFile(new URL('ext/lib/term-bank-parser.wasm', root))))
let rows = 0
let bytes = 0
const options = {computeContentHashes: true, emitContentSlab: true, emitTokenBinaryContent: true, emitTermByteLists: false,
    prepareLookupIndexes: true, prepareLookupRoute: true, validateGlossaryTypes: true, projectImagePaths: true, mediaHintFastScan: true}
try {
    const start = performance.now()
    const ok = await parser.parseTermBankWithWasmColumnChunksParallelCompressedLazy(entries.map(entry => async () => {
        assert.equal(archive.readUInt32LE(entry.offset), 0x04034b50)
        const start = entry.offset + 30 + archive.readUInt16LE(entry.offset + 26) + archive.readUInt16LE(entry.offset + 28)
        return {bytes: new Uint8Array(archive.subarray(start, start + entry.compressedSize)), compressionMethod: entry.compressionMethod,
            compressedSize: entry.compressedSize, uncompressedSize: entry.uncompressedSize, signature: entry.signature, filename: entry.filename}
    }), entries.map(entry => entry.uncompressedSize), 3, chunk => {
        rows += chunk.rowCount
        bytes += chunk.contentBytesLength
    }, options)
    assert.equal(ok, true)
    assert.equal(rows, spec.termRows)
    const report = {dictionary, rows, bytes, node: process.version, elapsed: performance.now() - start,
        profile: parser.consumeLastTermBankWasmParseProfile(), groups: profiles.sort((a,b)=>a.id-b.id),
        scope: 'diagnostic only: production compressed parser workers, no database/compression/storage/UI sink'}
    await writeFile(new URL(`builds/perf/${dictionary}-parser-profile.json`, root), JSON.stringify(report, null, 2) + '\n')
    console.log(JSON.stringify({...report, groups: undefined}, null, 2))
} finally {
    await reader.close()
    await parser.disposeParallelTermBankParser()
    await Promise.all(termination)
}
