# CRC PR #910: final-head CodeQL failure review

## Finding

The failure is localized to the results-upload stage, after JavaScript extraction, all 89 query evaluations, result interpretation, and SARIF export completed. The retrieved job log does not contain the underlying error, HTTP status, exception, or check annotation. **The exact cause remains unresolved.** The evidence does not establish a source-code defect, but it also does not justify declaring the failure an environmental incident or a false alarm. The final-head CodeQL gate remains failed.

This was a bounded, read-only inspection. No workflow rerun, product edit, workflow edit, setting change, or alternate acquisition was performed.

## Identity

- Repository: `ManabiIO/manabitan`; PR `910`.
- Final head: `2fe47fa3db04342d04eb4f309c5d74ef45eef9e3`.
- Product/test tree: `18f2494dbb185f189c59efb8ba2b1bf96855eeb8`.
- Workflow run: [45650131540](https://github.com/ManabiIO/manabitan/actions/runs/45650131540), attempt 1, `completed` / `failure`.
- Job: [139332071455](https://github.com/ManabiIO/manabitan/actions/runs/45650131540/job/139332071455), `Analyze (javascript)`, `completed` / `failure`.
- Failed step: `Perform CodeQL Analysis`, step 5. Checkout, CodeQL initialization and autobuild passed; all post-job steps passed.
- Runner: Ubuntu 26.04.1, image `ubuntu-26.04` version `20261116.202.1`, runner `2.338.2`.
- CodeQL action `4.35.2`, pinned action commit `95e58e9a2cdfd71adc6e0353d5c52f41a045d225`; CodeQL CLI `2.27.6`, JavaScript queries `2.5.2`.
- The job log lists `SecurityEvents: write`. That observation alone does not establish that a particular upload was accepted or authorized.

The retained `.github/workflows/codeql.yml` is unchanged between baseline `7d1643e6147a10cb2165e9744cf0e63b59e46632` and the final tree. Its matrix analyzes JavaScript only. This job does not qualify the native C implementation.

## Observed sequence

| UTC time on 2026-11-25 | Evidence |
| --- | --- |
| 16:10:23–16:11:59 | Database extraction/finalization, 89 query evaluation completions, and result interpretation appear in the retained log. |
| 16:12:00.4591745 | `Exported results to SARIF (208ms).` |
| 16:12:00.4896665 | Post-processing `/home/runner/work/manabitan/results/javascript.sarif`. |
| 16:12:00.4961498 | `Uploading code scanning results` group begins. |
| 16:12:00.5390491 | `Uploading results`. This is the last analysis-step log line. |
| 16:12:25.1399980 | Post-job cleanup begins, without a logged upload response or explicit error in between. |
| 16:12:28.4815470 | Cleanup exports diagnostic SARIF for the failed run. |
| 16:12:29.2224340 | Cleanup attempts to upload the failed-run diagnostic SARIF. |
| 16:12:29.2372809 | `CodeQL job status was failure.` |

The complete decoded job log has 5,028 nonempty-or-content lines plus its final newline and contains no `##[error]` marker. Diagnostic-query names such as `ExtractionErrors.ql` are names of standard queries; their occurrence does not establish that an extraction error was reported. Likewise, interpreting security queries does not establish a security finding. No SARIF artifact was retained by this run, so the content of its result and diagnostic files cannot be inspected through its artifacts.

## Evidence limits

The supported GitHub connector returned full run metadata, all job/step summaries, and the complete decoded job log. The run has no artifacts. Direct check-run/annotation endpoints are unsupported by the enabled connector (`INVALID_ARGUMENT`); the public job-page fetch was unavailable (`DisabledError`). The combined legacy commit-status endpoint returned no entries and cannot replace the failed Actions check. No credentials or permissions were changed to obtain more data.

Consequently, this review cannot distinguish a service/network upload failure, upload/configuration rejection, or another upload-stage condition. It cannot establish the absence of source findings. Keep the gate failed and the cause unresolved until the missing upload/check annotation is available through an authorized capability.

## Retained receipts

- `run-and-jobs.json`: source identity, attempt, statuses, timestamps, step conclusions, and explicit retrieval limitations.
- `job-139332071455.log`: complete decoded log, SHA-256 `7b8eb6af8419fcb5e16f3c64bdf11b2d68f87fce4b0aace20ddcd8ed71605f4a`.
- `codeql-workflow.yml`: exact workflow from the matching final local tree, SHA-256 `078631d9b8b0d2ff433cc7e799874b9e0325f4360ed731e2247028f441dfbac4`.
- `failure-review.json`: machine-readable classification, decisive log excerpts, file hashes, and limits.

The separate main CI and Chromium restart workflows are outside this bounded review. Their statuses must be reported from their own receipts.
