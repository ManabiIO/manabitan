import {openAsBlob} from 'node:fs'
import {readFile, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {performance} from 'node:perf_hooks'
import assert from 'node:assert/strict'
import {readDenseZipDirectory as baseline} from '../manabitan/ext/js/dictionary/dense-zip-directory.js'
import {readDenseZipDirectory as candidate} from '../vndb/ext/js/dictionary/dense-zip-directory.js'

const fixture = '/workspace/scratch/2754d3e3fa09/manabitan/builds/e2e-dictionary-cache/vndb_characters_by_bee.zip'
const archive = await openAsBlob(fixture)
const expectedSha256 = 'da5baed5332761513dcef8d0b07ad0d9201cdd7f37831dea37e7162994ec3792'
assert.equal(createHash('sha256').update(await readFile(fixture)).digest('hex'), expectedSha256)
const report = {node: process.version, expectedSha256, archiveBytes: archive.size, warmups: 2, pairs: 12, observations: []}
let a = await baseline(archive)
let b = await candidate(archive)
assert.deepEqual(b, a)
report.entries = a.length
report.filenameBytes = a[0].rawFilename.buffer.byteLength
report.metadataSha256 = createHash('sha256').update(JSON.stringify(a)).digest('hex')
console.log(JSON.stringify({parity: 'pass', entries: report.entries, filenameBytes: report.filenameBytes}))
a = null
b = null
for (const parse of [baseline, candidate]) {
    for (let i = 0; i < report.warmups; ++i) { await parse(archive) }
}
for (let pair = 0; pair < report.pairs; ++pair) {
    const order = pair % 2 === 0 ? ['baseline', 'candidate'] : ['candidate', 'baseline']
    for (const arm of order) {
        await new Promise((resolve) => setImmediate(resolve))
        global.gc()
        const heapBefore = process.memoryUsage().heapUsed
        const start = performance.now()
        let entries = await (arm === 'baseline' ? baseline : candidate)(archive)
        const ms = performance.now() - start
        await new Promise((resolve) => setImmediate(resolve))
        global.gc()
        const retainedHeap = process.memoryUsage().heapUsed - heapBefore
        assert.equal(entries.length, report.entries)
        report.observations.push({pair, arm, ms, retainedHeap})
        entries = null
    }
}
const median = (values) => {
    const sorted = values.toSorted((x, y) => x - y)
    return (sorted[Math.floor((sorted.length - 1) / 2)] + sorted[Math.floor(sorted.length / 2)]) / 2
}
report.summary = Object.fromEntries(['baseline', 'candidate'].map((arm) => [arm, {
    medianMs: median(report.observations.filter((x) => x.arm === arm).map((x) => x.ms)),
    medianRetainedHeap: median(report.observations.filter((x) => x.arm === arm).map((x) => x.retainedHeap)),
}]))
await writeFile('/workspace/scratch/2754d3e3fa09/vndb-evidence/directory-screen.json', JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report.summary))
