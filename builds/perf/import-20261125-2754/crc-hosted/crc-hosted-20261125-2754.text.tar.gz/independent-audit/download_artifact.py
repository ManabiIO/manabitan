#!/usr/bin/env python3
"""Download an existing artifact, verify its service digest, and extract safely."""
import fcntl
import hashlib
import json
from pathlib import Path
import stat
import sys
import urllib.request
import zipfile

root = Path('/tmp/manabitan-2754-crc-audit')
kind, artifact_id, name, run, expected_digest, url = sys.argv[1:]
assert kind in ('timing', 'memory') and artifact_id.isdecimal()
directory = root / kind / artifact_id
archive = root / kind / (artifact_id + '.zip')
archive.parent.mkdir(parents=True, exist_ok=True)
assert not directory.exists() and not archive.exists(), 'Refusing to replace retained evidence'
temporary = archive.with_suffix('.part')
digest = hashlib.sha256()
with urllib.request.urlopen(url, timeout=120) as response, temporary.open('wb') as output:
    while block := response.read(1024 * 1024):
        output.write(block)
        digest.update(block)
actual = 'sha256:' + digest.hexdigest()
assert actual == expected_digest, (actual, expected_digest)
temporary.rename(archive)
with zipfile.ZipFile(archive) as source:
    for member in source.infolist():
        relative = Path(member.filename)
        assert not relative.is_absolute() and '..' not in relative.parts
        assert not stat.S_ISLNK(member.external_attr >> 16)
    directory.mkdir()
    source.extractall(directory)
record = {'id': int(artifact_id), 'name': name, 'kind': kind, 'run': run,
          'directory': str(directory), 'archive': str(archive),
          'serviceDigest': expected_digest, 'archiveSha256': digest.hexdigest(),
          'archiveBytes': archive.stat().st_size}
with (root / 'artifacts.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    index = root / 'artifacts.json'
    records = json.loads(index.read_text()) if index.exists() else []
    assert all(row['id'] != record['id'] for row in records)
    records.append(record)
    index.write_text(json.dumps(sorted(records, key=lambda row: (row['kind'], row['name'])), indent=2) + '\n')
print(json.dumps(record))
