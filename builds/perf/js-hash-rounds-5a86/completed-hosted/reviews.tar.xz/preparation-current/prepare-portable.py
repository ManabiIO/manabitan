#!/usr/bin/env python3
"""Prepare a bounded JS-study adaptation of already reviewed evidence tools."""
from pathlib import Path
import difflib
import hashlib
import json

SOURCE = Path('/home/agent/manabitan-suffix-browser-audit-5a86')
TARGET = Path(__file__).parent
OLD_CANDIDATE = '38031a752b26c9b630e5f2f1d45e780786656c74'
CANDIDATE = 'baca22e773e835f6729d4fc5198f2445afac4535'
OLD_TREE = 'a05ece005d9fb4931cb1fc24f0cb67ceb109a7f5'
TREE = 'abf507137e441b76acf8a746bd05b7583f676588'
OLD_AUDITOR = 'd5857d4f14b27941ef657c1f0c2c1c89425caf3491e6f2d4101a4d859667f86d'
AUDITOR = 'f2da37b26929fb9eac55b81a887a4abc6673b1c4e786604ce0ca031eda7e3230'
OLD_REPO = '/workspace/scratch/5a86d1e7822a/manabitan'
REPO = '/home/agent/manabitan-js-hash-source-5a86.git'
ENTRIES = "('js/dictionary/term-key-hash.js', 'js/dictionary/wasm/term-bank-parser.c', 'lib/term-bank-parser.wasm')"


def sha(value):
    return hashlib.sha256(value).hexdigest()


def once(text, before, after):
    if text.count(before) != 1:
        raise ValueError('Unexpected adaptation boundary: ' + before)
    return text.replace(before, after)


def common(text):
    return (text.replace(OLD_CANDIDATE, CANDIDATE).replace(OLD_TREE, TREE)
            .replace('46104813593', '46107975597').replace('suffix-window-', 'js-hash-rounds-')
            .replace('suffix-cohort-', 'js-hash-cohort-').replace('suffix-git-source-', 'js-hash-git-source-'))


history = TARGET / 'portable-adaptation-history'
history.mkdir(exist_ok=False)
records = []
for original_name, output_name in (
    ('verify-suffix-cohort.py', 'verify-js-hash-cohort.py'),
    ('pack-cell.py', 'pack-cell.py'),
    ('build-source-proof.py', 'build-source-proof.py'),
):
    raw = (SOURCE / original_name).read_bytes()
    if original_name == 'verify-suffix-cohort.py':
        assert sha(raw) == '6cbf0035c62485ea4e5074a1d00d7665292f3a8003e414e552181f23e7c65bab'
    (history / original_name).write_bytes(raw)
    original = raw.decode()
    text = common(original)
    if original_name == 'verify-suffix-cohort.py':
        text = once(text, 'Verify a preserved suffix cohort', 'Verify a preserved JS hash cohort')
        text = once(text, "ORIGINAL_AUDITOR = '" + OLD_AUDITOR + "'", "ORIGINAL_AUDITOR = '" + AUDITOR + "'\nRETAINED_PACKAGE_ENTRIES = " + ENTRIES)
        text = text.replace('exact changed package members, Git-verified source bytes,', 'the exact hash module and unchanged native C/WASM members, Git-verified source bytes,')
        text = once(text, "for name in identities['changedPackageEntries']:", 'for name in RETAINED_PACKAGE_ENTRIES:')
        text = once(text, "repo=Path('" + OLD_REPO + "')", "repo=Path('" + REPO + "')")
        text = once(text, "for packaged,source_path in [('js/dictionary/wasm/term-bank-parser.c','ext/js/dictionary/wasm/term-bank-parser.c'),('lib/term-bank-parser.wasm','dev/data/dictionary-wasm/term-bank-parser.wasm')]:", "for packaged,source_path in [('js/dictionary/term-key-hash.js','ext/js/dictionary/term-key-hash.js'),('js/dictionary/wasm/term-bank-parser.c','ext/js/dictionary/wasm/term-bank-parser.c'),('lib/term-bank-parser.wasm','dev/data/dictionary-wasm/term-bank-parser.wasm')]:")
        text = once(text, "            assert entries['lib/term-bank-parser.wasm']==expected_modules[arm]", "            assert entries['js/dictionary/term-key-hash.js']==expected_modules[arm]\n            assert entries['lib/term-bank-parser.wasm']=='8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee'")
        text = once(text, 'retained native C/WASM bytes,', 'retained hash-module/native C/WASM bytes,')
    elif original_name == 'pack-cell.py':
        text = once(text, 'Preserve one original suffix cohort', 'Preserve one original JS hash cohort')
        text = once(text, "    repo = Path('" + OLD_REPO + "')", "    repo = Path('" + REPO + "')")
        text = once(text, 'def sha(data):', 'RETAINED_PACKAGE_ENTRIES = ' + ENTRIES + '\n\n\ndef sha(data):')
        text = once(text, "    archive_bytes = (root / 'artifact.zip').read_bytes()", "    if (audit['artifactMetadata'] != metadata or audit['dictionary'] != args.dictionary or\n            audit['order'] != args.order or audit['archiveSha256'] != metadata['digest'].removeprefix('sha256:')):\n        raise ValueError('Original audit identity mismatch')\n    archive_bytes = (root / 'artifact.zip').read_bytes()")
        text = once(text, "for name in identities['changedPackageEntries']:", 'for name in RETAINED_PACKAGE_ENTRIES:')
        text = once(text, "            source_paths.update({\n", "            source_paths.update({\n                'ext/js/dictionary/term-key-hash.js',\n")
        text = text.replace('exact changed package members, Git-verified source bytes,', 'the exact hash module and unchanged native C/WASM members, Git-verified source bytes,')
        text = once(text, "'audit-command-receipt.json', 'audit.stdout', 'audit.stderr', 'frozen-source-identities.json'):", "'audit-command-receipt.json', 'audit.stdout', 'audit.stderr', 'frozen-source-identities.json',\n                     'download-receipt.json', 'job-log-receipt.json', 'auditor-source-review.json'):")
        text = once(text, "('audit-hosted.py', 'adaptation-receipt.json', 'storage-adaptation-review.json', 'pack-cell.py'):", "('audit-hosted.py', 'adaptation.diff', 'preparation.json', 'root-review.json', 'prepared-cells.json', 'pack-cell.py'):")
    else:
        text = once(text, "REPO = Path('" + OLD_REPO + "')", "REPO = Path('" + REPO + "')")
        text = once(text, "ROOT = Path('/home/agent/manabitan-suffix-jitendex-ab-audit-5a86')", "ROOT = Path('/home/agent/manabitan-js-hash-jmdict-ab-audit-5a86')")
        text = once(text, "ROOT / 'jitendex-AB/source-identities.json'", "ROOT / 'jmdict-AB/source-identities.json'")
        text = once(text, "        paths.update({\n", "        paths.update({\n            'ext/js/dictionary/term-key-hash.js',\n")
    compile(text, output_name, 'exec')
    output = TARGET / output_name
    assert not output.exists(), output
    output.write_text(text)
    difference = ''.join(difflib.unified_diff(original.splitlines(keepends=True), text.splitlines(keepends=True), fromfile=original_name, tofile=output_name))
    (history / (output_name + '.diff')).write_text(difference)
    records.append({'original': original_name, 'originalSha256': sha(raw), 'adapted': output_name,
                    'adaptedSha256': sha(text.encode()), 'diffSha256': sha(difference.encode())})
assert sha((TARGET / 'audit-hosted.py').read_bytes()) == AUDITOR
receipt = {'noNewAcquisition': True, 'baseline': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2',
           'candidate': CANDIDATE, 'candidateTree': TREE, 'unchangedOriginalAuditorSha256': AUDITOR,
           'changes': 'Study identity, frozen source closure, and all three existing JS-auditor package checks; receipt/statistics/memory logic remains the exact f2da auditor. Only Git-verified helper files enter the replay import path.',
           'files': records}
(TARGET / 'portable-preparation.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
