#!/usr/bin/env python3
"""Preserve one original JS hash cohort without reacquiring any observation."""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import zipfile


RETAINED_PACKAGE_ENTRIES = ('js/dictionary/term-key-hash.js', 'js/dictionary/wasm/term-bank-parser.c', 'lib/term-bank-parser.wasm')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('root', type=Path)
    parser.add_argument('dictionary', choices=('jmdict', 'jitendex', 'vndb'))
    parser.add_argument('order', choices=('AB', 'BA'))
    args = parser.parse_args()
    root = args.root.resolve()
    repo = Path('/home/agent/manabitan-js-hash-source-5a86.git')
    prefix = args.dictionary + '-' + args.order
    metadata = json.loads((root / 'artifact-metadata.json').read_bytes())
    audit = json.loads((root / 'independent-audit.json').read_bytes())
    if audit['status'] != 'PASS' or audit['semanticReceiptCount'] != 42:
        raise ValueError('The complete independent original-archive audit is required')
    if (audit['artifactMetadata'] != metadata or audit['dictionary'] != args.dictionary or
            audit['order'] != args.order or audit['archiveSha256'] != metadata['digest'].removeprefix('sha256:')):
        raise ValueError('Original audit identity mismatch')
    archive_bytes = (root / 'artifact.zip').read_bytes()
    if len(archive_bytes) != metadata['size_in_bytes'] or 'sha256:' + sha(archive_bytes) != metadata['digest']:
        raise ValueError('Original artifact identity changed')
    members = {}

    def add(name, data):
        path = PurePosixPath(name)
        if path.is_absolute() or '..' in path.parts or path.as_posix() != name or name in members:
            raise ValueError('Unsafe or duplicate member: ' + name)
        members[name] = data

    inventory = []
    package_proofs = {}
    source_bindings = {}
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as original:
        if len(original.namelist()) != len(set(original.namelist())):
            raise ValueError('Duplicate original archive member')
        omitted = {prefix + '/package-' + arm + '.zip' for arm in ('A', 'B')}
        identities = json.loads(original.read(prefix + '/source-identities.json'))
        for name in sorted(original.namelist()):
            data = original.read(name)
            retained = name not in omitted
            inventory.append({'path': name, 'bytes': len(data), 'sha256': sha(data), 'retained': retained})
            if retained:
                add('original/' + name, data)
        if {entry['path'] for entry in inventory if not entry['retained']} != omitted:
            raise ValueError('Unexpected omission')
        for arm in ('A', 'B'):
            identity = identities['arms'][arm]
            data = original.read(prefix + '/package-' + arm + '.zip')
            if sha(data) != identity['packageSha256']:
                raise ValueError('Changed product package')
            with zipfile.ZipFile(io.BytesIO(data)) as package:
                entries = {name: sha(package.read(name)) for name in package.namelist() if not name.endswith('/')}
                if len(package.namelist()) != len(set(package.namelist())) or entries != identity['entries']:
                    raise ValueError('Package inventory mismatch')
                package_proofs[arm] = {'bytes': len(data), 'sha256': sha(data), 'entries': entries}
                for name in RETAINED_PACKAGE_ENTRIES:
                    add('verified-package-source/' + arm + '/' + name, package.read(name))
            source_paths = {path for path in identity['sourceHashes'] if not path.startswith('builds/')}
            source_paths.update({
                'ext/js/dictionary/term-key-hash.js',
                'ext/js/dictionary/wasm/term-bank-parser.c',
                'dev/data/dictionary-wasm/term-bank-parser.wasm',
                'dev/data/dictionary-wasm/manifest.json',
            })
            for relative in sorted(source_paths):
                data = subprocess.check_output(['git', 'show', identity['sha'] + ':' + relative], cwd=repo)
                if relative in identity['sourceHashes'] and sha(data) != identity['sourceHashes'][relative]:
                    raise ValueError('Source binding changed')
                name = 'git-source/' + arm + '/' + relative
                add(name, data)
                source_bindings[name] = {
                    'commit': identity['sha'], 'tree': identity['tree'],
                    'path': relative, 'bytes': len(data), 'sha256': sha(data),
                    'gitBlob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
                }
    proof = {
        'artifactMetadata': metadata, 'originalMembers': inventory,
        'packages': package_proofs, 'sourceBindings': source_bindings,
        'limitation': 'The original artifact ZIP and its two product ZIP payloads are not embedded. All other original members are losslessly retained, together with all package member hashes, the exact hash module and unchanged native C/WASM members, Git-verified source bytes, and the successful original full-package audit. Compact verification cannot repeat omitted package-byte checks without the original artifact.',
    }
    add('original-artifact-proof.json', (json.dumps(proof, indent=2) + '\n').encode())
    for relative in ('artifact-metadata.json', 'original-job.log', 'independent-audit.json',
                     'audit-command-receipt.json', 'audit.stdout', 'audit.stderr', 'frozen-source-identities.json',
                     'download-receipt.json', 'job-log-receipt.json', 'auditor-source-review.json'):
        add('review/' + relative, (root / relative).read_bytes())
    for path in sorted((root / 'frozen-source').rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add('frozen-source/' + path.relative_to(root / 'frozen-source').as_posix(), path.read_bytes())
    for relative in ('audit-hosted.py', 'adaptation.diff', 'preparation.json', 'root-review.json', 'prepared-cells.json', 'pack-cell.py'):
        add('review/' + relative, (Path(__file__).parent / relative).read_bytes())
    output = root / 'durable'
    output.mkdir(exist_ok=True)
    packed = output / 'evidence.tar.xz'
    with tarfile.open(packed, 'w:xz', format=tarfile.USTAR_FORMAT, preset=6) as archive:
        for name, data in sorted(members.items()):
            item = tarfile.TarInfo(name)
            item.size = len(data)
            item.mode = 0o644
            item.uid = item.gid = item.mtime = 0
            archive.addfile(item, io.BytesIO(data))
    packed_bytes = packed.read_bytes()
    manifest = {
        'schemaVersion': 1, 'run': 46107975597,
        'baseline': '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2',
        'candidate': 'baca22e773e835f6729d4fc5198f2445afac4535',
        'dictionary': args.dictionary, 'order': args.order,
        'originalArtifact': metadata, 'originalAuditSha256': sha((root / 'independent-audit.json').read_bytes()),
        'archive': {'file': 'evidence.tar.xz', 'bytes': len(packed_bytes), 'sha256': sha(packed_bytes),
                    'members': len(members), 'uncompressedBytes': sum(map(len, members.values()))},
        'members': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())},
        'packageLimitation': proof['limitation'],
        'scope': 'Original twelve-pair cohort, four control pairs, four warmups, two exhaustive-media and four sampled-memory imports. No new acquisition, discarded observations, control subtraction, or cross-host pooling.',
    }
    (output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'status': 'PACKED', 'output': str(output), 'archive': manifest['archive'],
                      'manifestSha256': sha((output / 'manifest.json').read_bytes())}))


if __name__ == '__main__':
    main()
