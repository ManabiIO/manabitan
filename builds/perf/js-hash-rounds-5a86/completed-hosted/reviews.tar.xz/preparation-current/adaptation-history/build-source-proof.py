#!/usr/bin/env python3
"""Package the exact Git objects needed to verify frozen observer/source paths."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile
import zlib

REPO = Path('/workspace/scratch/5a86d1e7822a/manabitan')
OUT = Path(__file__).parent / 'source-proof'
ROOT = Path('/home/agent/manabitan-suffix-jitendex-ab-audit-5a86')
BASE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CAND = '38031a752b26c9b630e5f2f1d45e780786656c74'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    OUT.mkdir(exist_ok=True)
    identities = json.loads((ROOT / 'jitendex-AB/source-identities.json').read_bytes())
    frozen = json.loads((ROOT / 'frozen-source-identities.json').read_bytes())
    objects = {}
    files = {}

    def add_object(oid):
        if oid in objects:
            return
        kind = git('cat-file', '-t', oid).decode().strip()
        data = git('cat-file', kind, oid)
        encoded = kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data
        if hashlib.sha1(encoded).hexdigest() != oid:
            raise ValueError('Git object identity mismatch')
        objects[oid] = {'type': kind, 'rawBytes': len(data), 'loose': zlib.compress(encoded)}

    for arm, revision in (('A', BASE), ('B', CAND)):
        add_object(revision)
        paths = {path for path in identities['arms'][arm]['sourceHashes'] if not path.startswith('builds/')}
        paths.update({
            'ext/js/dictionary/wasm/term-bank-parser.c',
            'dev/data/dictionary-wasm/term-bank-parser.wasm',
            'dev/data/dictionary-wasm/manifest.json',
        })
        paths.update(path for path in frozen if arm == 'B' or 'suffix-window-screen' not in path)
        for path in sorted(paths):
            tree = git('rev-parse', revision + '^{tree}').decode().strip()
            parts = path.split('/')
            for index, part in enumerate(parts):
                add_object(tree)
                entry = git('ls-tree', '-z', tree, '--', part)
                records = [item for item in entry.split(b'\0') if item]
                if len(records) != 1:
                    raise ValueError('Missing or ambiguous exact Git path')
                info, actual_name = records[0].split(b'\t', 1)
                mode, kind, oid = info.decode().split()
                if actual_name.decode() != part or kind not in ('tree', 'blob'):
                    raise ValueError('Unexpected Git entry')
                add_object(oid)
                if index == len(parts) - 1:
                    if kind != 'blob':
                        raise ValueError('Final Git path is not a blob')
                    data = git('show', revision + ':' + path)
                    files[revision + ':' + path] = {'blob': oid, 'bytes': len(data), 'sha256': sha(data)}
                else:
                    if kind != 'tree':
                        raise ValueError('Intermediate Git path is not a tree')
                    tree = oid
    payloads = {
        'HEAD': b'ref: refs/heads/evidence\n',
        'refs/heads/evidence': CAND.encode() + b'\n',
        'config': b'[core]\n\trepositoryformatversion = 0\n\tbare = true\n',
    }
    for oid, record in objects.items():
        payloads['objects/' + oid[:2] + '/' + oid[2:]] = record['loose']
    packed = OUT / 'git-proof.tar.xz'
    with tarfile.open(packed, 'w:xz', format=tarfile.USTAR_FORMAT, preset=6) as archive:
        for name, data in sorted(payloads.items()):
            item = tarfile.TarInfo(name)
            item.size = len(data)
            item.mode = 0o644
            archive.addfile(item, io.BytesIO(data))
    data = packed.read_bytes()
    manifest = {
        'schemaVersion': 1, 'baseline': BASE, 'candidate': CAND,
        'trees': {rev: git('rev-parse', rev + '^{tree}').decode().strip() for rev in (BASE, CAND)},
        'archive': {'file': packed.name, 'bytes': len(data), 'sha256': sha(data), 'members': len(payloads)},
        'members': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(payloads.items())},
        'objects': {oid: {key: value for key, value in record.items() if key != 'loose'} for oid, record in sorted(objects.items())},
        'files': files,
        'scope': 'Partial read-only Git object closure for the two exact commits and every source/observer path used by the cohort audit. Commit parents and unrelated file blobs are intentionally absent. All included tree, blob and commit object IDs are verified from canonical Git object bytes; no fetch, checkout or runtime acquisition is required.',
    }
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'status': 'PACKED', 'objects': len(objects), 'sourceFiles': len(files), 'archive': manifest['archive']}))


if __name__ == '__main__':
    main()
