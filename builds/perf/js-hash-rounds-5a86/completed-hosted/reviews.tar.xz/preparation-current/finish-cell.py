#!/usr/bin/env python3
"""Preserve and replay one already audited hosted cell; no import acquisition."""
import argparse
import base64
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if not __debug__:
        raise RuntimeError('Assertions must remain enabled')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('dictionary', choices=('jmdict', 'jitendex', 'vndb'))
    parser.add_argument('order', choices=('AB', 'BA'))
    args = parser.parse_args()
    master = Path(__file__).resolve().parent
    root = Path('/home/agent') / ('manabitan-js-hash-' + args.dictionary + '-' + args.order.lower() + '-audit-5a86')
    required = {
        'pack-cell.py': '4da8a4bc4a65aaa55b258dcc6d25209ebd2d47e583605d976305ec7cce04d750',
        'verify-js-hash-cohort.py': '9db55be83c00249677b7c45b0c514cfe050d0cb4dbcf672ce5c08fd8044d744d',
        'audit-hosted.py': 'f2da37b26929fb9eac55b81a887a4abc6673b1c4e786604ce0ca031eda7e3230',
    }
    for name, digest in required.items():
        assert sha((master / name).read_bytes()) == digest
    assert not (root / 'durable').exists(), 'Do not replace a historical pack'
    records = []

    def run(label, command):
        record = {'label': label, 'command': command, 'noNewAcquisition': True,
                  'startedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
        with (root / (label + '.stdout')).open('xb') as out, (root / (label + '.stderr')).open('xb') as error:
            result = subprocess.run(command, stdout=out, stderr=error, cwd=root)
        record.update({'completedUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                       'exitCode': result.returncode,
                       'stdoutSha256': sha((root / (label + '.stdout')).read_bytes()),
                       'stderrSha256': sha((root / (label + '.stderr')).read_bytes())})
        records.append(record)
        (root / 'preservation-command-receipts.json').write_text(json.dumps(records, indent=2) + '\n')
        print(json.dumps(record), flush=True)
        if result.returncode != 0:
            raise RuntimeError(label + ' failed: ' + (root / (label + '.stderr')).read_text())

    run('packing', [sys.executable, '-I', '-B', str(master / 'pack-cell.py'), str(root), args.dictionary, args.order])
    manifest = json.loads((root / 'durable/manifest.json').read_bytes())
    data = (root / 'durable/evidence.tar.xz').read_bytes()
    assert len(data) == manifest['archive']['bytes'] and sha(data) == manifest['archive']['sha256']
    wrapper = {'format': 'js-hash-cohort-evidence-v1', 'encoding': 'base64',
               'manifest': manifest, 'archive': base64.b64encode(data).decode()}
    target = root / 'durable' / ('hosted-' + args.dictionary + '-' + args.order + '.json.txt')
    target.write_text(json.dumps(wrapper, indent=2) + '\n')
    command = [sys.executable, '-I', '-B', str(master / 'verify-js-hash-cohort.py'),
               '--evidence', str(target), '--source-proof', str(master / 'source-proof/source-proof.json.txt')]
    run('portable-full', command + ['--original-artifact', str(root / 'artifact.zip')])
    run('portable-compact', command)
    full = json.loads((root / 'portable-full.stdout').read_bytes())
    compact = json.loads((root / 'portable-compact.stdout').read_bytes())
    assert full.pop('originalProductZipBytesRechecked') is True
    assert compact.pop('originalProductZipBytesRechecked') is False
    assert full == compact
    result = {'status': 'PASS', 'noNewAcquisition': True, 'dictionary': args.dictionary,
              'order': args.order, 'originalAuditSha256': full['originalAuditSha256'],
              'semanticReceipts': full['semanticReceipts'], 'rawMemoryScans': full['rawMemoryScans'],
              'originalNonProductMembersLosslesslyRechecked': True,
              'allThreePackageModulesRecheckedAgainstGit': True,
              'completeProductZipOmissionRemainsExplicit': True,
              'fullCompactOnlyAvailabilityDifference': True,
              'archive': manifest['archive'], 'wrapperSha256': sha(target.read_bytes())}
    (root / 'preservation-result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
