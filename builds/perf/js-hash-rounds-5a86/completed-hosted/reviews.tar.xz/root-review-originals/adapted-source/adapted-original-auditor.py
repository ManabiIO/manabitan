from pathlib import Path, PurePosixPath
import hashlib, io, json, random, statistics, subprocess, sys, zipfile

if not __debug__:
    raise RuntimeError('Do not run with optimized Python (-O)')

repo=Path(sys.argv[5]).resolve()
root=Path(sys.argv[1]).resolve()
expected_archive_sha=sys.argv[2]
expected_order=sys.argv[3]
dictionary=sys.argv[4]
assert dictionary in ('jmdict','jitendex','vndb')
assert expected_order in ('AB','BA')
frozen=root/'frozen-source'
checker_dir=frozen/'dev/perf/import-memory-20261125-a7f7'
sys.path.insert(0,str(checker_dir))
from qualification_receipts import validate_import_summary, require_matching_receipts
from audit_memory import audit_cell
from protocol import memory_overlay, schedule as memory_schedule
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda path:json.loads(path.read_text())
def file_sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()
class RetainedArchive:
    def __init__(self,root,proof):self.root=root;self.proof=proof
    def __enter__(self):return self
    def __exit__(self,*args):return False
    def namelist(self):return [entry['path'] for entry in self.proof['originalMembers']]
    def read(self,name):
        entry=next(entry for entry in self.proof['originalMembers'] if entry['path']==name)
        if not entry['retained']:raise ValueError('Original product ZIP is omitted')
        return (self.root/name).read_bytes()

try:
    proof=read(root/'original-artifact-proof.json')
    assert proof['artifactMetadata']['digest']=='sha256:'+expected_archive_sha
    metadata=read(root/'artifact-metadata.json')
    assert metadata==proof['artifactMetadata'] and metadata['digest']=='sha256:'+expected_archive_sha
    assert metadata['name']=='js-hash-rounds-'+dictionary+'-'+expected_order+'-5a86'
    assert metadata['workflow_run']['id']==46107975597 and metadata['workflow_run']['head_sha']=='baca22e773e835f6729d4fc5198f2445afac4535'
    prefix=dictionary+'-'+expected_order+'/'
    with RetainedArchive(root,proof) as z:
        assert len(z.namelist())==len(set(z.namelist()))
        for name in z.namelist():
            if not name.startswith(prefix):continue
            relative=PurePosixPath(name)
            assert not relative.is_absolute() and '..' not in relative.parts
            if name.endswith(('.json','.jsonl','.js')):
                target=root/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
        evidence=root/prefix
        plan=read(evidence/'registered-plan.json');obs=read(evidence/'observations.json');ids=read(evidence/'source-identities.json');browser=read(evidence/'browser-identity.json')
        assert plan['baseline']=='9e10d3b3fcf66d344ab31bc42c9b522fa5215da2' and plan['candidate']=='baca22e773e835f6729d4fc5198f2445afac4535'
        assert plan['dictionary']==dictionary and plan['pairs']==12 and plan['initialOrder']==expected_order and plan['flags']=={}
        expected_entries=['js/dictionary/term-key-hash.js']
        assert sorted(plan['expectedPackageEntries'])==sorted(ids['changedPackageEntries'])==sorted(expected_entries)
        assert plan['expectedWorkers'] is None
        allocation={'unitBytes':4096,'rangeUnits':[37,37],'origin':'explicit'} if dictionary=='vndb' else None
        assert plan['vndbSahAllocationPolicy']==allocation
        assert plan['memorySchedule']==memory_schedule(1 if expected_order=='AB' else 2)
        prescribed=[]
        for pair,order in enumerate((expected_order,expected_order[::-1]),1):
            for arm in order:prescribed.append({'id':f'warmup-{pair}-{arm}','kind':'warmup','pair':pair,'arm':arm})
        for pair in range(1,13):
            for arm in (expected_order if pair%2 else expected_order[::-1]):prescribed.append({'id':f'pair-{pair:02d}-{arm}','kind':'candidate','pair':pair,'arm':arm})
            if pair%3==0:
                cp=pair//3
                for arm in ('AC' if (cp+(expected_order=='BA'))%2 else 'CA'):prescribed.append({'id':f'control-{cp:02d}-{arm}','kind':'control','pair':cp,'arm':arm})
        assert plan['schedule']==prescribed
        assert browser['version']=='153.0.8010.12' and browser['sha256']=='8c599d43aec53f2460a31ae2f4af6bd863f8258b34ff519564bc5d4726bfaa1e'
        assert len(obs)==36 and [{k:v for k,v in item.items() if k!='totalImportMs'} for item in obs]==plan['schedule']
        assert sha((checker_dir/'qualification_receipts.py').read_bytes())=='4f7b4eee4f8ff71e821c9162e57524460c48f01f409487f638523a3a27aa8f51'
        expected_trees={'A':'d99ea4d04658f7ec1c76acdc5f3684594212a471','B':'abf507137e441b76acf8a746bd05b7583f676588'}
        expected_sources={'A':plan['baseline'],'B':plan['candidate']}
        expected_modules={'A':'c2d4ed2a04f4c5dcd8a5f5865d49f7cbdade87fd95ab4fff92f3a9bb0181d208','B':'a2b92c62a893056bf16b563cde8f842136321e2954860c8828385b6d0788c6bb'}
        frozen_identities=read(root/'frozen-source-identities.json')
        expected_frozen={
            'dev/perf/import-memory-20261125-a7f7/'+name for name in
            ('qualification_receipts.py','audit_memory.py','protocol.py','chromium_memory.py')
        } | {'test/perf/dictionaries.lock.json','test/chromium/extension-two-dictionary-import.e2e.js',
             'dev/perf/import-qualification-20261125-a7f7.py',
             '.github/workflows/js-hash-rounds-screen-5a86.yml','dev/perf/js-hash-rounds-screen-5a86.py'}
        assert set(frozen_identities)==expected_frozen
        for relative,identity in frozen_identities.items():
            content=(frozen/relative).read_bytes();assert sha(content)==identity['sha256'] and len(content)==identity['bytes']
            revision=plan['candidate'] if relative in ('.github/workflows/js-hash-rounds-screen-5a86.yml','dev/perf/js-hash-rounds-screen-5a86.py') else plan['baseline']
            assert content==subprocess.check_output(['git','show',revision+':'+relative],cwd=repo)
            if revision==plan['baseline']:
                assert content==subprocess.check_output(['git','show',plan['candidate']+':'+relative],cwd=repo)
        invocation=json.loads(z.read(prefix[:-1]+'-driver/invocation.json'))
        assert invocation['baseline']==plan['baseline'] and invocation['candidate']==plan['candidate'] and invocation['dictionary']==dictionary and invocation['order']==expected_order
        assert type(invocation['exitCode']) is int and invocation['status']==('complete' if invocation['exitCode']==0 else 'failed')
        assert invocation['pairs']==12 and invocation['flags']=={} and invocation['retries']==0
        command=invocation['command']
        expected_command=['dev/perf/import-qualification-20261125-a7f7.py','--baseline',plan['baseline'],'--candidate',plan['candidate'],'--dictionary',dictionary,'--initial-order',expected_order,'--pairs','12','--evidence',command[13]]
        if dictionary=='vndb':expected_command.extend(['--vndb-sah-allocation-units','37','37'])
        for entry in expected_entries:expected_command.extend(['--expected-package-entry',entry])
        assert command[1:]==expected_command
        assert Path(command[13]).name==dictionary+'-'+expected_order
        assert invocation['sourceIdentity']['candidateTree']==expected_trees['B'] and invocation['sourceIdentity']['vndbSahAllocationUnits']==[37,37]
        assert invocation['sourceIdentity']['packageEntries']==expected_entries
        assert invocation['sourceIdentity']['hashModules']=={'A':{'bytes':5175,'sha256':expected_modules['A']},'B':{'bytes':5524,'sha256':expected_modules['B']}}
        package_entries={}
        for arm in ('A','B'):
            identity=ids['arms'][arm]
            assert identity['sha']==expected_sources[arm] and identity['tree']==expected_trees[arm]
            assert set(identity['sourceHashes'])=={'builds/manabitan-chrome-dev.zip','builds/manabitan-chrome.zip','dev/perf/benchmark-support.js','dev/perf/dictionary-fixtures.js','dev/perf/import-benchmark.js','ext/js/pages/settings/dictionary-import-controller.js','package-lock.json','test/chromium/extension-two-dictionary-import.e2e.js','test/chromium/import-flags-ab-benchmark.js','test/e2e/import-timing.js','test/perf/dictionaries.lock.json'}
            for relative,digest in identity['sourceHashes'].items():
                if not relative.startswith('builds/'):
                    source=subprocess.check_output(['git','show',identity['sha']+':'+relative],cwd=repo)
                    assert sha(source)==digest,(arm,relative)
            package_proof=proof['packages'][arm]
            assert package_proof['sha256']==identity['packageSha256']
            entries=package_proof['entries']
            assert entries==identity['entries']
            for packaged,source_path in [('js/dictionary/term-key-hash.js','ext/js/dictionary/term-key-hash.js'),('js/dictionary/wasm/term-bank-parser.c','ext/js/dictionary/wasm/term-bank-parser.c'),('lib/term-bank-parser.wasm','dev/data/dictionary-wasm/term-bank-parser.wasm')]:
                module=(root.parent/'verified-package-source'/arm/packaged).read_bytes()
                source=subprocess.check_output(['git','show',identity['sha']+':'+source_path],cwd=repo)
                assert module==source and sha(module)==entries[packaged],(arm,packaged)
            assert entries['js/dictionary/term-key-hash.js']==expected_modules[arm]
            assert entries['lib/term-bank-parser.wasm']=='8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee'
            package_entries[arm]=entries
        assert sorted(k for k in package_entries['A'].keys()|package_entries['B'].keys() if package_entries['A'].get(k)!=package_entries['B'].get(k))==sorted(plan['expectedPackageEntries'])
    fixture=read(frozen/'test/perf/dictionaries.lock.json')['dictionaries'][dictionary]
    original=(evidence/'memory/harness-original.js').read_text();overlay=(evidence/'memory/harness-instrumented.js').read_text()
    assert original==(frozen/'test/chromium/extension-two-dictionary-import.e2e.js').read_text()
    assert overlay==memory_overlay(original)
    assert read(evidence/'memory/plan.json')=={'authoritativeTiming':False,'dictionary':dictionary,'overlaySha256':sha(overlay.encode()),'replication':1 if expected_order=='AB' else 2,'schedule':plan['memorySchedule'],'sourceHashes':ids['arms']}
    reference=None;bindings=[]
    def verify(path,arm,media_check='sample',is_memory=False):
        global reference
        summary=read(path/'summary.json');report=read(path/'run-1.json');identity=ids['arms'][arm];hashes=identity['sourceHashes'].copy()
        if is_memory:hashes['test/chromium/extension-two-dictionary-import.e2e.js']=sha(overlay.encode())
        dictionaries=summary['runs'][0]['step4Breakdown']['dictionaries'];assert len(dictionaries)==1
        assert (dictionaries[0]['parserWorkerCount'],dictionaries[0]['parserGroupCount'])=={'jmdict':(3,12),'jitendex':(3,22),'vndb':(3,170)}[dictionary]
        receipt=validate_import_summary(summary,report,dictionary=dictionary,fixture=fixture,source_sha=identity['sha'],package_sha256=identity['packageSha256'],browser_version=browser['version'],import_flags=None,source_hashes=hashes,source_dirty=is_memory,media_check=media_check,vndb_sah_allocation_units=(37,37) if dictionary=='vndb' else None)
        assert receipt==read(path/'canonical-receipt.json')
        if reference is None:reference=receipt
        else:require_matching_receipts(reference,receipt,compare_media=media_check=='sample')
        bindings.append({'id':str(path.relative_to(evidence)),'receiptSha256':sha((path/'canonical-receipt.json').read_bytes()),'commonSha256':sha(json.dumps(receipt['common'],sort_keys=True).encode()),'termRows':receipt['common']['validation']['termRows'],'media':receipt['media']})
        return summary,receipt
    for item in obs:
        summary,_=verify(evidence/item['id'],'B' if item['arm']=='B' else 'A')
        assert summary['runs'][0]['totalImportMs']==item['totalImportMs']
    media=[]
    for arm in ('A','B'):media.append(verify(evidence/f'exhaustive-media-{arm}',arm,'all')[1])
    require_matching_receipts(*media)
    for item in plan['memorySchedule']:verify(evidence/'memory'/item['name'],item['arm'],is_memory=True)
    assert len(bindings)==42 and len({x['commonSha256'] for x in bindings})==1
    expected_names={item['id'] for item in bindings}
    assert {str(p.parent.relative_to(evidence)) for p in evidence.rglob('summary.json')}==expected_names
    assert {str(p.parent.relative_to(evidence)) for p in evidence.rglob('canonical-receipt.json')}==expected_names
    memory=audit_cell(evidence/'memory');assert memory==read(evidence/'memory/memory-audit.json')
    assert memory['observations']==4 and type(memory['everyObservationQualified']) is bool
    assert read(evidence/'memory/semantic-failures.json')==[]
    def paired(kind,left,right):
        groups={}
        for item in obs:
            if item['kind']==kind:groups.setdefault(item['pair'],{})[item['arm']]=item['totalImportMs']
        assert all(set(x)=={left,right} for x in groups.values())
        values=list(groups.values());ratios=[x[right]/x[left] for x in values]
        rng=random.Random(897);samples=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
        return {'count':len(values),'ratios':ratios,'medianPairedChangePercent':100*(statistics.median(ratios)-1),'equalWorkChangePercent':100*(sum(x[right] for x in values)/sum(x[left] for x in values)-1),'worstPairChangePercent':100*(max(ratios)-1),'descriptiveBootstrap95Percent':[100*(samples[i]-1) for i in (249,9749)],'fasterPairs':sum(x<1 for x in ratios)}
    analysis=read(evidence/'analysis.json')
    for key,kind,left,right in [('candidateVsBaseline','candidate','A','B'),('identicalCodeControl','control','A','C')]:assert paired(kind,left,right)==analysis[key]
    assert analysis['memoryPassed']==memory['passesProspectiveMemoryScreen']
    assert analysis['status']==('correctness-memory-passed' if analysis['memoryPassed'] else 'memory-or-semantics-failed')
    assert (invocation['exitCode']==0)==analysis['memoryPassed']
    result={'status':'PASS','noNewAcquisition':True,'artifactMetadata':metadata,'prescribedObservationsVerified':42,'dictionary':dictionary,'packageEntriesChecked':{arm:len(entries) for arm,entries in package_entries.items()},'driverInvocation':invocation,'order':expected_order,'archiveSha256':expected_archive_sha,'source':{arm:{k:v for k,v in identity.items() if k!='entries'} for arm,identity in ids['arms'].items()},'packageChangedEntries':ids['changedPackageEntries'],'rawOrdinaryObservationCount':len(obs),'semanticReceiptCount':len(bindings),'bindings':bindings,'memoryRawAudit':memory,'analysisRecomputed':analysis,'limits':'One complete fixed twelve-pair host. Same-code controls remain separate. Passing correctness and sampled-memory gates is not a latency improvement claim.'}
    (root/'independent-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','order':expected_order,'semanticReceiptCount':len(bindings),'rawScans':memory['rawScanCount'],'analysis':analysis,'auditSha256':sha((root/'independent-audit.json').read_bytes())}))
except BaseException as error:
    (root/'independent-audit-failure.json').write_text(json.dumps({'type':type(error).__name__,'message':str(error)},indent=2)+'\n')
    raise
