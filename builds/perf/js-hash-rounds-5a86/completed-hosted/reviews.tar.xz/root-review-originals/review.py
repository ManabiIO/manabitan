from pathlib import Path
import ast
import base64
import hashlib
import io
import json
import runpy
import subprocess
import sys
import tarfile
import time
import zlib

ROOT = Path(__file__).parent
SOURCE = Path('/home/agent/manabitan-js-hash-browser-audit-5a86')
CELL = Path('/home/agent/manabitan-js-hash-jmdict-ab-audit-5a86')
VERIFIER = SOURCE / 'verify-js-hash-cohort.py'
EVIDENCE = CELL / 'durable/hosted-jmdict-AB.json.txt'
PROOF = SOURCE / 'source-proof/source-proof.json.txt'
sha = lambda b: hashlib.sha256(b).hexdigest()

assert sha(VERIFIER.read_bytes()) == '9db55be83c00249677b7c45b0c514cfe050d0cb4dbcf672ce5c08fd8044d744d'
predecessor = SOURCE / 'portable-adaptation-history/verify-suffix-cohort.py'
assert sha(predecessor.read_bytes()) == '6cbf0035c62485ea4e5074a1d00d7665292f3a8003e414e552181f23e7c65bab'
assert sha(EVIDENCE.read_bytes()) == '8570f2d23e4eae7b93a50e10a8d2e98a79fa8acb8ba75b99b5273006ec6a4c73'
original = (SOURCE / 'audit-hosted.py').read_bytes()
assert sha(original) == 'f2da37b26929fb9eac55b81a887a4abc6673b1c4e786604ce0ca031eda7e3230'

# The archive, Git-specification and path safety functions are unchanged.
trees = [ast.parse(p.read_text()) for p in (predecessor, VERIFIER)]
functions = [{n.name: ast.dump(n, include_attributes=False) for n in t.body
              if isinstance(n, ast.FunctionDef)} for t in trees]
unchanged = ('require', 'sha', 'read', 'safe', 'unpack', 'check_git_proof')
assert all(functions[0][n] == functions[1][n] for n in unchanged)
source = VERIFIER.read_text()
for fragment in ("require(not verified_source.exists()", "for relative in sorted(expected_frozen):",
                 "[sys.executable, '-I', '-B', str(script)"):
    assert fragment in source

# Resolve the new source closure without Git or either verifier implementation.
wrapper = json.loads(PROOF.read_bytes())
manifest = wrapper['manifest']
packed = base64.b64decode(wrapper['archive'], validate=True)
assert sha(packed) == manifest['archive']['sha256'] == '5540c32391bf66ee57638fc3274953dbfb73e749e18ef2e2ead206f15f027267'
with tarfile.open(fileobj=io.BytesIO(packed), mode='r:xz') as archive:
    payloads = {item.name: archive.extractfile(item).read() for item in archive}
assert len(payloads) == len(manifest['members']) == 51
for name, identity in manifest['members'].items():
    assert len(payloads[name]) == identity['bytes'] and sha(payloads[name]) == identity['sha256']
objects = {}
for oid, identity in manifest['objects'].items():
    raw = zlib.decompress(payloads['objects/' + oid[:2] + '/' + oid[2:]])
    header, data = raw.split(b'\0', 1)
    assert header == identity['type'].encode() + b' ' + str(len(data)).encode()
    assert len(data) == identity['rawBytes'] and hashlib.sha1(raw).hexdigest() == oid
    objects[oid] = (identity['type'], data)
assert len(objects) == 48 and len(manifest['files']) == 38

def entries(oid):
    kind, data = objects[oid]
    assert kind == 'tree'
    result = {}
    cursor = 0
    while cursor < len(data):
        space = data.index(b' ', cursor)
        zero = data.index(b'\0', space)
        name = data[space + 1:zero].decode()
        assert name not in result
        result[name] = data[zero + 1:zero + 21].hex()
        cursor = zero + 21
    assert cursor == len(data)
    return result

for revision, expected_tree in manifest['trees'].items():
    kind, data = objects[revision]
    assert kind == 'commit' and data.split(b'\n', 1)[0] == b'tree ' + expected_tree.encode()
for spec, identity in manifest['files'].items():
    revision, relative = spec.split(':', 1)
    oid = manifest['trees'][revision]
    for part in relative.split('/'):
        oid = entries(oid)[part]
    kind, data = objects[oid]
    assert kind == 'blob' and oid == identity['blob']
    assert len(data) == identity['bytes'] and sha(data) == identity['sha256']

# Preserve the derived source without executing it; its receipt/statistics tail
# must remain byte-identical to the original independently reviewed auditor.
adapt_root = ROOT / 'adapted-source'
(adapt_root / 'review').mkdir(parents=True)
(adapt_root / 'review/audit-hosted.py').write_bytes(original)
module = runpy.run_path(str(VERIFIER))
derived = module['adapted_auditor'](adapt_root).read_bytes()
tail = b"    fixture=read(frozen/'test/perf/dictionaries.lock.json')"
assert original[original.index(tail):] == derived[derived.index(tail):]

commands = []
def run(name, extra=(), evidence=EVIDENCE, optimize=False):
    command = [sys.executable, '-I', '-B']
    if optimize:
        command.append('-O')
    command += [str(VERIFIER), '--evidence', str(evidence), '--source-proof', str(PROOF), *extra]
    started = time.time()
    completed = subprocess.run(command, capture_output=True)
    (ROOT / (name + '.stdout')).write_bytes(completed.stdout)
    (ROOT / (name + '.stderr')).write_bytes(completed.stderr)
    commands.append({'name': name, 'command': command, 'exitCode': completed.returncode,
                     'startedUnix': started, 'endedUnix': time.time(), 'newAcquisition': False,
                     'stdoutSha256': sha(completed.stdout), 'stderrSha256': sha(completed.stderr)})
    return completed

compact = run('compact')
full = run('full-original', ('--original-artifact', str(CELL / 'artifact.zip')))
assert compact.returncode == full.returncode == 0
c, f = json.loads(compact.stdout), json.loads(full.stdout)
assert c.pop('originalProductZipBytesRechecked') is False
assert f.pop('originalProductZipBytesRechecked') is True
assert c == f and c['semanticReceipts'] == 42 and c['rawMemoryScans'] == 258
assert c['originalAuditSha256'] == 'b3f250a7da9d10a03f658bee34181ac5097779ea94f8be750c412f6d98e261ee'
assert c['analysis'] == json.loads((CELL / 'independent-audit.json').read_bytes())['analysisRecomputed']
optimized = run('optimized-rejected', optimize=True)
assert optimized.returncode != 0 and b'Do not use optimized Python' in optimized.stderr

# The new JS package policy additionally retains unchanged native bytes. Check
# that rebinding the outer archive/member hashes cannot hide a changed C member.
mutant = json.loads(EVIDENCE.read_bytes())
with tarfile.open(fileobj=io.BytesIO(base64.b64decode(mutant['archive'])), mode='r:xz') as archive:
    data_by_name = {item.name: archive.extractfile(item).read() for item in archive}
name = 'verified-package-source/B/js/dictionary/wasm/term-bank-parser.c'
data_by_name[name] += b'\n'
mutant['manifest']['members'][name] = {'bytes': len(data_by_name[name]), 'sha256': sha(data_by_name[name])}
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w:xz', format=tarfile.USTAR_FORMAT, preset=6) as archive:
    for name, data in sorted(data_by_name.items()):
        item = tarfile.TarInfo(name); item.size = len(data); item.mode = 0o644
        item.uid = item.gid = item.mtime = 0
        archive.addfile(item, io.BytesIO(data))
packed = buffer.getvalue()
mutant['archive'] = base64.b64encode(packed).decode()
mutant['manifest']['archive'].update(bytes=len(packed), sha256=sha(packed),
                                     uncompressedBytes=sum(map(len, data_by_name.values())))
mutated_path = ROOT / 'rebound-native-member.json.txt'
mutated_path.write_text(json.dumps(mutant, sort_keys=True, separators=(',', ':')) + '\n')
negative = run('rebound-native-rejected', evidence=mutated_path)
assert negative.returncode != 0 and b'Retained package source changed' in negative.stderr

(ROOT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
report = {
    'status': 'PASS_BOUNDED_PORTABLE_ADAPTATION_REVIEW', 'noNewAcquisition': True,
    'verifierSha256': sha(VERIFIER.read_bytes()), 'reviewedPredecessorSha256': sha(predecessor.read_bytes()),
    'originalAuditorSha256': sha(original), 'derivedAuditorSha256': sha(derived),
    'originalReceiptMemoryAndStatisticsTailUnchanged': True, 'unchangedSafetyFunctionsAst': list(unchanged),
    'sourceClosureObjects': 48, 'sourcePathBindings': 38,
    'sourceClosureArchiveSha256': manifest['archive']['sha256'],
    'sourceClosureIndependentlyResolvedWithoutGit': True,
    'cohortWrapperSha256': sha(EVIDENCE.read_bytes()),
    'fullAndCompactReproduceOriginalAudit': c['originalAuditSha256'],
    'imports': 42, 'rawMemoryScans': 258,
    'rejectedChecks': ['optimized Python', 'rebound retained native C member'],
    'reviewedChanges': ['Exact baca commit/tree/run and JS artifact naming',
                        'Required retained JS hash plus unchanged native C/WASM for both arms',
                        'Explicit complete-product-ZIP omission policy',
                        'Nine Git-verified source/helper files and inherited fresh selective isolated imports'],
    'scope': 'Source adaptation and one already acquired JMdict AB cohort only. The complete original ZIP was rechecked, with all 313 retained original members and the fixed 42-observation audit. No benchmark or product test was run, and no import gain is claimed.',
}
(ROOT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'reviewSha256': sha((ROOT / 'review.json').read_bytes()),
                  'reviewBytes': (ROOT / 'review.json').stat().st_size}))
