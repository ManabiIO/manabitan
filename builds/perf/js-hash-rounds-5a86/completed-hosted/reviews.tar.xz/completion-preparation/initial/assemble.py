#!/usr/bin/env python3
"""Preserve the six already completed JS cohorts; no product code is executed."""
import hashlib
import io
import json
import lzma
from pathlib import Path
import shutil
import tarfile

HERE = Path(__file__).resolve().parent
PERSIST = HERE.parent / 'js-hash-reset-recovery'
MASTER = Path('/home/agent/manabitan-js-hash-browser-audit-5a86')
STATS = HERE.parent / 'js-independent-stats-checkpoint'
STAGE = HERE / 'publication'
DEST = STAGE / 'builds/perf/js-hash-rounds-5a86/completed-hosted'
BASELINE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CANDIDATE = 'baca22e773e835f6729d4fc5198f2445afac4535'
PARENT = 'b85683e2f1a92a1d80af969776645d088443da94'
VERIFIER = '9db55be83c00249677b7c45b0c514cfe050d0cb4dbcf672ce5c08fd8044d744d'
WRAPPERS = {
    'jmdict-AB': '8570f2d23e4eae7b93a50e10a8d2e98a79fa8acb8ba75b99b5273006ec6a4c73',
    'jmdict-BA': 'fd6d63e821f2dfd25e0f4b3f6da045dec6b6e39aaaa99d34607a0db3db368e60',
    'jitendex-AB': '31b6011f5c2226c63e9725b3b6aff02c5b5b1ddc07d5e97eea938ee256250127',
    'jitendex-BA': 'd4ad167d7859d6f9f5c16869b28e10b20d6a6c36ae36e07ce45d3b7722ca3f55',
    'vndb-AB': '5b4baa87073942aeae03ba51f6a5ccc89a2bb0790326b75ac0adfb8ca4c5e325',
    'vndb-BA': 'd7e93ebd45a9dd91b93cb6d24353328c595a3cb32c4fb209662806f5b17bb2ad',
}
JOBS = {'jmdict-AB': 140882747021, 'jmdict-BA': 140882747016,
        'jitendex-AB': 140882747026, 'jitendex-BA': 140882747003,
        'vndb-AB': 140882747103, 'vndb-BA': 140882747024}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def record(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': digest(data)}


def read_json(path):
    return json.loads(path.read_bytes())


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    assert __debug__
    DEST.mkdir(parents=True, exist_ok=False)
    assert record(MASTER / 'verify-js-hash-cohort.py')['sha256'] == VERIFIER
    verifier_path = STAGE / 'dev/perf/verify-js-hash-cohort-5a86.py'
    verifier_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(MASTER / 'verify-js-hash-cohort.py', verifier_path)
    proof = PERSIST / 'source-proof.json.txt'
    assert record(proof)['sha256'] == '91f1022f9029c814baf9cedb7c568850dc72c7fd4a85da55c1ce6634323175f2'
    shutil.copyfile(proof, DEST / proof.name)
    prior = read_json(STATS / 'six-host-review.json')
    assert record(STATS / 'six-host-review.json')['sha256'] == '595b0e53843c43e3e50c36f16f21e5da0febbea4c7f172a840aad2f9dd6179bf'
    assert prior['status'] == 'PASS_INDEPENDENT_SIX_HOST_REVIEW'
    assert prior['baseline'] == BASELINE and prior['candidate'] == CANDIDATE
    assert prior['observationCounts']['total'] == 252 and prior['observationCounts']['rawMemoryScans'] == 2183
    assert prior['memoryCoverageFailedHosts'] == ['vndb-BA'] and prior['allCandidateIntervalsContainZero'] is True
    hosts = {host['host']: host for host in prior['hosts']}
    assert set(hosts) == set(WRAPPERS)
    jobs = read_json(HERE / 'final-jobs.json')['jobs']
    assert {job['id'] for job in jobs} == set(JOBS.values()) | {140864895314}
    for job in jobs:
        assert job['status'] == 'completed'
        assert job['conclusion'] == ('failure' if job['id'] == JOBS['vndb-BA'] else 'success')
    run = read_json(HERE / 'final-run-api.json')
    assert run['id'] == 46107975597 and run['head_sha'] == CANDIDATE and run['run_attempt'] == 1
    assert run['status'] == 'completed' and run['conclusion'] == 'failure'
    cells = []
    payloads = {}

    def retain(name, path):
        assert name not in payloads and not Path(name).is_absolute() and '..' not in Path(name).parts
        payloads[name] = path.read_bytes()

    for name, expected in WRAPPERS.items():
        wrapper = PERSIST / ('hosted-' + name + '.json.txt')
        assert record(wrapper)['sha256'] == expected
        shutil.copyfile(wrapper, DEST / wrapper.name)
        wrapped = read_json(wrapper)
        manifest = wrapped['manifest']
        root = Path('/home/agent/manabitan-js-hash-' + name.lower() + '-audit-5a86')
        audit = read_json(root / 'independent-audit.json')
        assert record(root / 'independent-audit.json')['sha256'] == manifest['originalAuditSha256'] == hosts[name]['originalAuditSha256']
        assert audit['status'] == 'PASS' and audit['semanticReceiptCount'] == 42
        assert audit['analysisRecomputed']['candidateVsBaseline'] == hosts[name]['candidateVsBaseline']
        assert audit['analysisRecomputed']['identicalCodeControl'] == hosts[name]['identicalCodeControl']
        assert audit['memoryRawAudit']['rawScanCount'] == hosts[name]['observations']['rawMemoryScans']
        assert audit['analysisRecomputed']['memoryPassed'] == hosts[name]['memory']['passesProspectiveMemoryScreen']
        assert audit['artifactMetadata'] == hosts[name]['artifact']
        assert manifest['candidate'] == CANDIDATE and manifest['baseline'] == BASELINE
        assert len(manifest['members']) == 371
        for item in root.iterdir():
            if item.is_file() and item.name != 'artifact.zip' and item.name != 'original-job.log' and (item.suffix in ('.json', '.stdout', '.stderr') or item.name == 'audit-hosted.py'):
                retain('cell-verification/' + name + '/' + item.name, item)
        cells.append({
            'host': name, 'jobId': JOBS[name], 'jobConclusion': 'failure' if name == 'vndb-BA' else 'success',
            'evidence': {'path': wrapper.name, **record(wrapper)},
            'originalArtifact': audit['artifactMetadata'],
            'originalAudit': record(root / 'independent-audit.json'),
            'originalFullJobLog': record(root / 'original-job.log'),
            'candidateVsBaseline': hosts[name]['candidateVsBaseline'],
            'identicalCodeControl': hosts[name]['identicalCodeControl'],
            'observations': hosts[name]['observations'],
            'memory': hosts[name]['memory'],
            'originalGateStatus': hosts[name]['originalGateStatus'],
            'independentStatisticsReviewSha256': hosts[name]['independentReviewSha256'],
            'packageEntriesChecked': audit['packageEntriesChecked'],
            'retainedOriginalNonPackageMembers': 313, 'omittedOriginalProductZipPayloads': 2,
            'totalRetainedPackMembers': len(manifest['members']),
        })
    assert sum(cell['observations']['total'] for cell in cells) == 252
    assert sum(cell['observations']['rawMemoryScans'] for cell in cells) == 2183
    root_originals = PERSIST / 'root-review-originals'
    inventory = read_json(root_originals / 'original-directory-inventory.json')
    assert len(inventory) == 15
    missing = []
    for name, expected in inventory.items():
        path = root_originals / name
        if not path.exists():
            missing.append({'path': 'root-review-originals/' + name, **expected})
            continue
        assert record(path) == expected
        retain('root-review-originals/' + name, path)
    assert missing == [{'path': 'root-review-originals/commands.json', 'bytes': 3251, 'sha256': '960e4a60e68a768ea1f1e532ef928503e05fbea7f52e583d5f44d0e9baf93a61'}]
    retain('root-review-recovery/original-directory-inventory.json', root_originals / 'original-directory-inventory.json')
    for name in ['reset-ledger.json', 'source-recovery.json', 'first-wrapper-recovery.json', 'root-review-recovery-status.json', 'root-review-exact-recovery.json', 'root-review-final-recovery-inventory.json', 'recovered-text-checkpoint.json', 'preparation-evidence-index.json', 'jitendex-BA-recovery-audit-command-receipt.json', 'jitendex-BA-recovery-download-receipt.json', 'vndb-BA-failure-scope-review.json']:
        retain('reset-recovery/' + name, PERSIST / name)
    for path in (PERSIST / 'preparation-evidence').rglob('*'):
        if path.is_file():
            retain('preparation/' + str(path.relative_to(PERSIST / 'preparation-evidence')), path)
    for name in ['portable-history-recovery.json', 'prepare-portable.py', 'portable-preparation.json', 'build-source-proof.py', 'pack-cell.py', 'finish-cell.py']:
        retain('preparation-current/' + name, MASTER / name)
    for path in (MASTER / 'portable-adaptation-history').rglob('*'):
        if path.is_file():
            retain('preparation-current/adaptation-history/' + str(path.relative_to(MASTER / 'portable-adaptation-history')), path)
    for path in STATS.iterdir():
        if path.is_file():
            retain('independent-statistics/' + path.name, path)
    for name in ['final-run-api.json', 'final-jobs.json', 'prior-evidence-publication.json', 'decision-and-recovery-checkpoint.json', 'handoff-before.md', 'assemble.py']:
        retain('completion-preparation/' + name, HERE / name)
    raw_tar = io.BytesIO()
    with tarfile.open(fileobj=raw_tar, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for name, raw in sorted(payloads.items()):
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            archive.addfile(info, io.BytesIO(raw))
    compressed = lzma.compress(raw_tar.getvalue(), preset=9)
    (DEST / 'reviews.tar.xz').write_bytes(compressed)
    review_manifest = {
        'schemaVersion': 1, 'scope': 'Original independent reviews and original/recovered verification history for the completed six-host study, plus separately labelled new preservation records. No observations were reacquired.',
        'archive': {'path': 'reviews.tar.xz', **record(DEST / 'reviews.tar.xz'), 'members': len(payloads), 'uncompressedPayloadBytes': sum(map(len, payloads.values())), 'format': 'USTAR regular files in lexical order, mode0644, zero uid/gid/mtime and empty owners; XZ preset9'},
        'members': {name: {'bytes': len(raw), 'sha256': digest(raw)} for name, raw in sorted(payloads.items())},
        'unavailableOriginalReviewFiles': missing,
        'lossScope': 'Only one original root portable-review commands.json with per-command timestamps remains unavailable after the transient reset. Fourteen other root review files were recovered exactly against pre-reset hashes. The absent file is not a CI observation. Original CI observations, cohort logs and source identities are preserved. Do not treat newly labelled recovery receipts as the unavailable original timestamp file.',
        'priorIndependentSixHostReview': {'archivePath': 'independent-statistics/six-host-reviews.tar.xz', 'archiveSha256': 'e1f67044104278086b3700aefad35cc3c87cc8aa2e2a3b7958ed702c6a7e2ddd', 'summaryPath': 'independent-statistics/six-host-review.json', 'summarySha256': '595b0e53843c43e3e50c36f16f21e5da0febbea4c7f172a840aad2f9dd6179bf'},
    }
    write_json(DEST / 'review-manifest.json', review_manifest)
    index = {
        'schemaVersion': 1, 'status': 'STOP_NO_PR_NO_FURTHER_UNCHANGED_ACQUISITION', 'baseline': BASELINE, 'candidate': CANDIDATE,
        'candidateTree': 'abf507137e441b76acf8a746bd05b7583f676588', 'runId': 46107975597, 'runAttempt': 1,
        'runConclusion': 'failure', 'reason': 'The six original host cohorts do not establish an import gain worth review. Both JMdict estimates remain uncertain, Jitendex has no replicated improvement, VNDB estimates have opposite signs, and VNDB BA memory coverage is unqualified.',
        'noNewAcquisition': True, 'noProductOrWorkflowChangesInThisPublication': True, 'expectedParent': PARENT,
        'observations': prior['observationCounts'], 'allCandidateIntervalsContainZero': True, 'memoryQualifiedHosts': 5, 'memoryCoverageFailedHosts': ['vndb-BA'],
        'statisticsPolicy': prior['statisticsScope'], 'timingScope': prior['timingScope'],
        'coldComponentDisposition': 'The earlier approximately 1.75–2.23ms cold-only hash saving remains component-only evidence. Its mixed warmed/tiering results and all original failures remain in the existing measured-source evidence; they do not establish a whole-import gain.',
        'sourceValidation': {'evidenceCommit': PARENT, 'path': '../source-validation-checkpoint', 'sourceGateJob': 140864895314, 'conclusion': 'success', 'archiveSha256': 'db5c3b60697e2bd041a480523eb5712e2af8fd2fda3ec405a3e1675e211e8c71', 'unchanged': True},
        'portableVerifier': {'path': '../../../../dev/perf/verify-js-hash-cohort-5a86.py', 'sha256': VERIFIER, 'originalAuditorSha256': 'f2da37b26929fb9eac55b81a887a4abc6673b1c4e786604ce0ca031eda7e3230', 'preparationRootReviewSha256': '15b41973643e9fa061fe8a56ab72b8d4103a1673d834742e2f5e360d8841de71'},
        'sourceProof': {'path': 'source-proof.json.txt', **record(DEST / 'source-proof.json.txt'), 'rawGitObjects': 48, 'resolvedSourcePaths': 38},
        'reviewArchive': review_manifest['archive'], 'reviewManifest': {'path': 'review-manifest.json', **record(DEST / 'review-manifest.json')},
        'originalPackageLimitation': read_json(PERSIST / 'hosted-jmdict-AB.json.txt')['manifest']['packageLimitation'],
        'missingReviewFile': missing[0], 'cells': cells,
    }
    write_json(DEST / 'evidence-index.json', index)
    table = ['| Dictionary / host | Paired median | Equal-work total | Descriptive 95% interval | Faster pairs | Same-code median | Memory screen |', '| --- | ---: | ---: | ---: | ---: | ---: | --- |']
    for cell in cells:
        x, control = cell['candidateVsBaseline'], cell['identicalCodeControl']
        lo, hi = x['descriptiveBootstrap95Percent']
        table.append(f"| {cell['host']} | {x['medianPairedChangePercent']:+.4f}% | {x['equalWorkChangePercent']:+.4f}% | [{lo:+.4f}%, {hi:+.4f}%] | {x['fasterPairs']}/12 | {control['medianPairedChangePercent']:+.4f}% | {'Pass' if cell['memory']['passesProspectiveMemoryScreen'] else 'Unqualified coverage (0/4)'} |")
    table_text = '\n'.join(table)
    readme = f'''# Completed JavaScript large-hash qualification: STOP

The measured source is `{CANDIDATE}` against `{BASELINE}` in [original run 46107975597](https://github.com/ManabiIO/manabitan/actions/runs/46107975597). These are the six original, independently reviewed cohorts. This evidence publication changes no product, workflow, observations, thresholds or acquisition policy. No PR is proposed.

Every host's descriptive interval includes zero. Both JMdict estimates are small; Jitendex does not establish a replicated advantage; VNDB estimates have opposite signs. The earlier cold-only component saving of approximately 1.75–2.23ms remains component evidence, with its mixed prescribed warmed results and tiering caveat retained in the existing handoff.

Negative percentages favor the candidate. AB and BA identify independent hosts with opposite initial order; they are not pooled. Same-code movement is reported separately and is not subtracted.

{table_text}

Each host retained twelve candidate pairs, four same-code control pairs, four warmups, two exhaustive-media imports and four separate sampled-memory imports: 42 complete semantic imports per host, 252 overall, with 2,183 raw memory scans. All semantic receipts, default-policy checks, source/package bindings and full media checks passed. Five memory cohorts qualified. VNDB BA retains all four coverage failures: maximum covered-scan gaps B1 = 268.173684 ms, A1 = 277.503958 ms, A2 = 263.562157 ms, B2 = 307.072375 ms against the unchanged 250 ms bound. Its zero qualified pairs and null aggregate PSS/private deltas are preserved; this does not establish a memory regression or a memory pass. The original overall workflow and that cell remain failed.

The timer spans browser file-input change through the post-UI import-complete event. Physical display paint is outside this endpoint. There are no replacements, filtered tails, retries, control subtraction or cross-host pooling. The unchanged seed 897 / 10,000 resamples produce the descriptive intervals.

## Offline verification

From the repository root, use the unchanged reviewed verifier for each compact original cohort:

```sh
python3 -I -B dev/perf/verify-js-hash-cohort-5a86.py --evidence builds/perf/js-hash-rounds-5a86/completed-hosted/hosted-jmdict-AB.json.txt --source-proof builds/perf/js-hash-rounds-5a86/completed-hosted/source-proof.json.txt
```

Repeat with the five other explicitly listed `hosted-*.json.txt` files in `evidence-index.json`. This verifies original receipts, schedules, clocks, all memory observations, source/observer bindings and recomputed statistics. `PASS` means that the retained evidence is faithful; it preserves the failed VNDB BA memory qualification.

Each wrapper preserves 313 of 315 original artifact members exactly, omitting only the two product ZIP payloads. The original artifact ZIP is also omitted. All package member hashes and the exact JS hash module plus unchanged native C/WASM members for both arms are retained and Git-bound. The complete original packages were checked before compact preservation. Supply `--original-artifact /absolute/path/to/original-artifact.zip` to repeat the omitted byte checks; without it the compact verifier explicitly reports that limitation. All six original artifact IDs, sizes and SHA256 values are in `evidence-index.json` and the individual wrappers.

The partial offline Git proof contains 48 raw commit/tree/blob objects resolving 38 exact source paths. It is not a full repository or ancestor history. The verifier rejects unsafe Git paths, disabled assertions, altered retained members and false completeness claims, and loads only isolated, verified helper files. It is byte-identical to the reviewed 9db55be8 verifier; the original per-host auditor remains f2da37b2.

## Review and recovery history

`reviews.tar.xz` and `review-manifest.json` retain the independent six-host numerical review, its earlier checkpoints and original preparation-only failure, the root verifier/adaptation review and negative checks, per-cell preservation commands, reset/recovery records and final run/job metadata. Every retained member is listed by exact length and SHA256. The six-host review rederives every candidate/control ratio, tail, median, equal-work total, bootstrap interval and memory disposition; it proposes no pooled effect.

One original local reviewer timestamp file remains unavailable after the transient filesystem reset: root `commands.json`, 3251 bytes, SHA256 `960e4a60e68a768ea1f1e532ef928503e05fbea7f52e583d5f44d0e9baf93a61`. The other 14 original root review files were recovered exactly against their pre-reset identities. The lost file is not a CI observation. Original CI ZIPs/logs were recovered by exact recorded hashes; all original measurements remain preserved. Newly labelled recovery command receipts are not replacements for the absent historical timestamp file.

The earlier source-validation checkpoint remains unchanged in `../source-validation-checkpoint`; it includes full units, all four type scopes, JS lint, native reproduction, observer checks and seven dry builds. Existing cold-component evidence and local failures remain unchanged at the measured source and in the earlier handoff.
'''
    (DEST / 'README.md').write_text(readme)
    old = (HERE / 'handoff-before.md').read_bytes()
    assert hashlib.sha1(b'blob ' + str(len(old)).encode() + b'\0' + old).hexdigest() == '9d94e0464bfe6aa109cf7336ced750301f6f26ba'
    title, body = old.decode().split('\n\n', 1)
    insertion = f'''## November 28, 2026: completed JavaScript large-hash study — STOP / no PR

The fixed six-host study is complete. Measured source `{CANDIDATE}` against frozen `{BASELINE}` in run [46107975597](https://github.com/ManabiIO/manabitan/actions/runs/46107975597) does not establish an import gain worth review. Do not open a performance PR from this candidate or restart unchanged acquisition. The tiny signed-round rewrite remains only on its experimental branch. This follow-up preserves evidence without changing product, workflow, thresholds or observations.

All six original cells were independently reconstructed from raw receipts and separately reviewed numerically. Each retained twelve candidate pairs, four same-code control pairs, four warmups, two exhaustive-media imports and four separate memory observations: 252 semantic imports and 2,183 raw memory scans overall. Negative percentages favor the candidate; independent AB/BA hosts and same-code movement are never pooled or subtracted.

{table_text}

Every candidate interval crosses zero. JMdict's modest paired estimates do not exceed the observed uncertainty; equal-work changes are only −0.5246% and −0.2342%. Jitendex has no established replicated gain. VNDB points in opposite directions across the two hosts. All semantic/source/package/default-policy/media checks passed, and five memory screens passed. VNDB BA retains all four covered-scan failures (B1 = 268.173684 ms, A1 = 277.503958 ms, A2 = 263.562157 ms, B2 = 307.072375 ms; unchanged 250 ms bound), zero qualified pairs and null aggregate PSS/private deltas. This is unqualified coverage, not an established memory regression or a pass. Its original job and overall run remain failed. No observation, tail or control was discarded or replaced.

The earlier approximately 1.75–2.23ms cold first-hash component saving remains component-only. The modeled record offsets, mixed prescribed warmed/tiering results, all local failures and capture provenance note remain in the original evidence below; they do not establish a whole-import improvement. The complete source-validation checkpoint at `builds/perf/js-hash-rounds-5a86/source-validation-checkpoint/` remains unchanged.

Durable completed evidence is at `builds/perf/js-hash-rounds-5a86/completed-hosted/`: machine summary `evidence-index.json`, all six lossless non-package cohort wrappers, 48-object / 38-path source proof, and the full review/recovery archive with member manifest. `dev/perf/verify-js-hash-cohort-5a86.py` is the unchanged reviewed 9db55be8 portable verifier and retains the original f2da37b2 auditor's receipt/statistic logic. See the adjacent README for exact offline commands and optional original-ZIP checks. Each original 315-member artifact retains 313 members; the two product ZIP payloads and original outer ZIP are omitted explicitly. Complete package checks were performed, and exact JS hash plus unchanged native C/WASM bytes for both arms remain Git-bound. Compact verification alone cannot repeat omitted package-byte checks.

The independent numerical summary is SHA256 `595b0e53843c43e3e50c36f16f21e5da0febbea4c7f172a840aad2f9dd6179bf`; every ratio/tail/control/seed 897 bootstrap and memory disposition reproduces. Its previous checkpoints and initial reviewer-only failure remain retained. Root verifier review 15b41973 and 14 exact original support files were recovered after the transient reset. One original local timestamp file, root`commands.json` (3251bytes, SHA256 `960e4a60e68a768ea1f1e532ef928503e05fbea7f52e583d5f44d0e9baf93a61`), is unavailable and is not fabricated. It is not a CI observation; original artifacts/logs were recovered by their exact hashes, without acquisition. Recovery receipts are labelled separately.

'''
    # Keep the prior prospective/component/source-validation text byte-for-byte.
    new = (title + '\n\n' + insertion + body).encode()
    assert new.replace(insertion.encode(), b'', 1) == old
    handoff = STAGE / 'dev/perf/import-experiments-20260914.md'
    handoff.write_bytes(new)
    (HERE / 'handoff-insertion.md').write_text(insertion)
    files = []
    for path in sorted(STAGE.rglob('*')):
        if path.is_file():
            raw = path.read_bytes()
            files.append({'path': str(path.relative_to(STAGE)), **record(path), 'gitBlobSha': hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()})
    trigger_paths = ['.github/workflows/js-hash-rounds-screen-5a86.yml', 'dev/perf/js-hash-rounds-screen-5a86.py', 'ext/js/dictionary/term-key-hash.js', 'test/term-key-hash.test.js']
    assert not set(trigger_paths) & {entry['path'] for entry in files}
    assert len(files) == 13
    write_json(HERE / 'publication-index.json', {'expectedParent': PARENT, 'baseTree': '7fb1ece93fd1b2cdde03bf57162d2aee6f9c5d51', 'paths': files, 'handoffInsertionOnly': True, 'missesUnchangedAcquisitionPaths': trigger_paths, 'runtimeAndWorkflowUnchanged': True})
    with tarfile.open(fileobj=io.BytesIO(compressed), mode='r:xz') as archive:
        assert archive.getnames() == sorted(payloads)
        for name, expected in payloads.items():
            assert archive.extractfile(name).read() == expected
    print(json.dumps({'status': 'PREPARED', 'paths': len(files), 'reviewMembers': len(payloads), 'reviewArchive': review_manifest['archive'], 'semanticImports': 252, 'memoryScans': 2183, 'sourceProof': index['sourceProof'], 'publicationIndex': record(HERE / 'publication-index.json')}, sort_keys=True))


if __name__ == '__main__':
    main()
