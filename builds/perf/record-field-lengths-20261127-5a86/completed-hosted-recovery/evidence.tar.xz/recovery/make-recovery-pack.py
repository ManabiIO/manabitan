#!/usr/bin/env python3
"""Repackage original CI receipts and published component bytes; no acquisition."""
import argparse
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import tarfile
import zipfile

BASELINE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
CANDIDATE = 'ab116fa90777cd64b067d4858318923f0f4e3ee7'
MODULE = 'js/dictionary/term-record-opfs-store.js'
ARTIFACTS = {
    'AB': {'id': 15247854574, 'bytes': 35001825, 'sha256': '3c253d47260b91bb5d8b1bad06446cb80aad65fb4973278089417f6f3ab0775c'},
    'BA': {'id': 15248767297, 'bytes': 34942141, 'sha256': '67159673a6cb6cc3b579e9d01ee82334094c40a3e6932876fffd812df5f68d66'},
    'validation': {'id': 15247200027, 'bytes': 47132, 'sha256': '0115dae32253c88b5a8ca8ef2496971e2e1f2379df6de4be40e53f2048bab8d9'},
}
AUDITS = {'AB': '5d1244116a999f9eef544c5a58a6190c5cd3f9fd4324335d345691d10e40bad2',
          'BA': '20413b00c230974f8776074f7230da4b8e5be5a5ccdd4074426cf296d5c883e4'}
BLOBS = {'A': 'be14a6a920584c942a4304079ebb3fc5c624a0ae', 'B': '89dce0bcd56505053c39fea31a60ac5ea331afe7'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def put(root, name, data):
    logical = PurePosixPath(name)
    assert not logical.is_absolute() and '..' not in logical.parts and logical.as_posix() == name
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def main():
    assert __debug__
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--inputs', type=Path, required=True)
    ap.add_argument('--repository', type=Path, required=True)
    ap.add_argument('--out', type=Path, required=True)
    args = ap.parse_args()
    root = args.inputs.resolve()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    payload = out / 'payload'
    payload.mkdir()
    for order in ['AB', 'BA']:
        identity = ARTIFACTS[order]
        original = root / ('hosted-' + order) / 'artifact.zip'
        assert original.stat().st_size == identity['bytes'] and file_sha(original) == identity['sha256']
        base = 'hosted-' + order + '/'
        with zipfile.ZipFile(original) as archive:
            names = archive.namelist()
            assert len(names) == len(set(names)) == 203
            source = json.loads(archive.read('record-field-lengths-jmdict/source-identities.json'))
            inventory = []
            for name in names:
                omitted = name in ['record-field-lengths-jmdict/package-A.zip', 'record-field-lengths-jmdict/package-B.zip']
                data = archive.read(name)
                inventory.append({'path': name, 'bytes': len(data), 'sha256': sha(data), 'retained': not omitted})
                if not omitted:
                    put(payload, base + name, data)
            proof = {'originalArtifact': identity, 'entries': sorted(inventory, key=lambda row: row['path']),
                     'originalAuditorSha256': 'cf2b18b91d005217c59fdde6e749955734b9e8337f01f50246a20ef06a67a4f9',
                     'reproducedOriginalAuditSha256': AUDITS[order], 'packages': {}}
            for arm in ['A', 'B']:
                data = archive.read('record-field-lengths-jmdict/package-' + arm + '.zip')
                assert sha(data) == source['arms'][arm]['packageSha256']
                with zipfile.ZipFile(io.BytesIO(data)) as package:
                    entries = {name: sha(package.read(name)) for name in package.namelist() if not name.endswith('/')}
                    assert entries == source['arms'][arm]['entries'] and len(entries) == 554
                    module = package.read(MODULE)
                    blob = hashlib.sha1(b'blob ' + str(len(module)).encode() + b'\0' + module).hexdigest()
                    assert blob == BLOBS[arm]
                    put(payload, base + 'verified-module-' + arm + '.js', module)
                    proof['packages'][arm] = {'bytes': len(data), 'sha256': sha(data), 'entries': entries,
                                              'moduleGitBlob': blob, 'moduleSha256': sha(module)}
            write_json(payload / (base + 'package-and-artifact-proof.json'), proof)
        audit = root / ('hosted-' + order) / 'independent-audit.json'
        assert file_sha(audit) == AUDITS[order]
        put(payload, base + 'reproduced-original-audit.json', audit.read_bytes())
        for extension in ['stdout.log', 'stderr.log']:
            name = 'recovery-audit-' + order + '.' + extension
            put(payload, 'recovery/' + name, (root / name).read_bytes())
    validation = root / 'validation/artifact.zip'
    assert validation.stat().st_size == ARTIFACTS['validation']['bytes'] and file_sha(validation) == ARTIFACTS['validation']['sha256']
    put(payload, 'validation/original.zip', validation.read_bytes())
    with zipfile.ZipFile(validation) as archive:
        for name in archive.namelist():
            put(payload, 'validation/' + name, archive.read(name))
    for name in ['original-audit-hosted.py', 'connector-snapshots.json', 'lost-prepared-index.json',
                 'initial-failed-job-retrieved.log', 'published-component-index.json',
                 'packaging-first-attempt.json', 'packaging-first-attempt-manifest.json']:
        put(payload, 'recovery/' + name, (root / name).read_bytes())
    put(payload, 'recovery/make-recovery-pack.py', Path(__file__).read_bytes())
    published = json.loads((root / 'published-component-index.json').read_bytes())
    for record in published['files']:
        data = (root / 'published-component' / record['path']).read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert len(data) == record['bytes'] and blob == record['sha']
        put(payload, 'published-component/' + record['path'], data)
    frozen = ['dev/perf/import-memory-20261125-a7f7/' + name for name in
              ['qualification_receipts.py', 'audit_memory.py', 'protocol.py', 'chromium_memory.py']]
    frozen += ['test/perf/dictionaries.lock.json', 'test/chromium/extension-two-dictionary-import.e2e.js',
               'dev/perf/import-qualification-20261125-a7f7.py']
    frozen_hashes = {}
    for name in frozen:
        data = subprocess.check_output(['git', 'show', BASELINE + ':' + name], cwd=args.repository)
        put(payload, 'frozen-repository/' + name, data)
        frozen_hashes[name] = sha(data)
    members = {}
    archive_path = out / 'evidence.tar.xz'
    with tarfile.open(archive_path, 'w:xz', preset=6, format=tarfile.USTAR_FORMAT) as archive:
        for path in sorted((p for p in payload.rglob('*') if p.is_file()),
                           key=lambda p: p.relative_to(payload).as_posix()):
            name = path.relative_to(payload).as_posix()
            size = path.stat().st_size
            members[name] = {'bytes': size, 'sha256': file_sha(path)}
            info = tarfile.TarInfo(name)
            info.size = size
            info.mode = 0o644
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            with path.open('rb') as stream:
                archive.addfile(info, stream)
    manifest = {
        'schemaVersion': 1, 'baseline': BASELINE, 'candidate': CANDIDATE, 'runId': 46102823858,
        'disposition': 'STOP: no demonstrated JMdict gain; no PR, expansion or unchanged-candidate retry',
        'noNewAcquisition': True, 'originalArtifacts': ARTIFACTS, 'reproducedOriginalAudits': AUDITS,
        'archive': {'file': 'evidence.tar.xz', 'bytes': archive_path.stat().st_size, 'sha256': file_sha(archive_path),
                    'memberCount': len(members), 'uncompressedBytes': sum(row['bytes'] for row in members.values())},
        'members': members, 'frozenSourceHashes': frozen_hashes,
        'recovery': {
            'cause': 'Executor replacement removed /tmp and /home/agent after the first complete pack was reviewed but before publication.',
            'method': 'Download the exact original AB, BA and corrected-validation CI ZIPs; recover the original audit source from V8; audit only original receipts; reproduce both prior audit output hashes; recover all21 published local files by exact Git blob; create a new byte-exact archive of recovered payloads.',
            'originalAuditorBytes': 7360, 'originalAuditorSha256': 'cf2b18b91d005217c59fdde6e749955734b9e8337f01f50246a20ef06a67a4f9',
            'priorPreparedIndex': 'recovery/lost-prepared-index.json',
            'missingPriorFiles': 'The first compressed pack, its new portable verifier and independent packaging-review files are unavailable. Their recorded sizes/SHA256/Git blob identities remain in the index. This archive does not represent replacement files as those originals.',
            'failedSourceJob': {'runId': 46102040540, 'jobId': 140846425703,
                                'log': 'recovery/initial-failed-job-retrieved.log',
                                'provenance': 'Fresh retrieval of the same original GitHub job log. Prior decoded log length was247770bytes, but its individual prior SHA was not retained; no pre-loss byte-equality claim.'},
        },
        'packageLimitation': 'Original artifact and product ZIP bytes were verified in full. Only the four product ZIPs are omitted from the compact pack; archive/member hashes, exact changed modules, original source identities and reproduced complete-package audits remain. Omitted ZIP bytes cannot be recreated or independently rehashed from this compact pack.',
    }
    verifier = root / 'verify-recovered-evidence.py'
    assert verifier.is_file()
    shutil.copyfile(verifier, out / verifier.name)
    manifest['verifier'] = {'file': verifier.name, 'bytes': verifier.stat().st_size, 'sha256': file_sha(verifier)}
    write_json(out / 'manifest.json', manifest)
    print(json.dumps({'archive': manifest['archive'], 'manifestSha256': file_sha(out / 'manifest.json')}))


if __name__ == '__main__':
    main()
