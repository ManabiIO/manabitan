from pathlib import Path, PurePosixPath
import hashlib, io, json, random, statistics, sys, zipfile

repo=Path('/workspace/scratch/5a86d1e7822a/manabitan')
root=Path(sys.argv[1]).resolve()
expected_archive_sha=sys.argv[2]
expected_order=sys.argv[3]
checker_dir=repo/'dev/perf/import-memory-20261125-a7f7'
sys.path.insert(0,str(checker_dir))
from qualification_receipts import validate_import_summary, require_matching_receipts
from audit_memory import audit_cell
from protocol import memory_overlay
sha=lambda data:hashlib.sha256(data).hexdigest()
read=lambda path:json.loads(path.read_text())
try:
    archive=root/'artifact.zip';assert sha(archive.read_bytes())==expected_archive_sha
    prefix='record-field-lengths-jmdict/'
    with zipfile.ZipFile(archive) as z:
        for name in z.namelist():
            if not name.startswith(prefix):continue
            relative=PurePosixPath(name)
            assert not relative.is_absolute() and '..' not in relative.parts
            if name.endswith(('.json','.jsonl','.js')):
                target=root/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
        evidence=root/prefix
        plan=read(evidence/'registered-plan.json');obs=read(evidence/'observations.json');ids=read(evidence/'source-identities.json');browser=read(evidence/'browser-identity.json')
        assert plan['baseline']=='9e10d3b3fcf66d344ab31bc42c9b522fa5215da2' and plan['candidate']=='ab116fa90777cd64b067d4858318923f0f4e3ee7'
        assert plan['dictionary']=='jmdict' and plan['pairs']==6 and plan['initialOrder']==expected_order and plan['flags']=={}
        assert plan['expectedPackageEntries']==ids['changedPackageEntries']==['js/dictionary/term-record-opfs-store.js']
        assert len(obs)==20 and [{k:v for k,v in item.items() if k!='totalImportMs'} for item in obs]==plan['schedule']
        assert sha((checker_dir/'qualification_receipts.py').read_bytes())=='4f7b4eee4f8ff71e821c9162e57524460c48f01f409487f638523a3a27aa8f51'
        blob_ids={'A':'be14a6a920584c942a4304079ebb3fc5c624a0ae','B':'89dce0bcd56505053c39fea31a60ac5ea331afe7'}
        package_entries={}
        for arm in ('A','B'):
            data=z.read(prefix+f'package-{arm}.zip');assert sha(data)==ids['arms'][arm]['packageSha256']
            with zipfile.ZipFile(io.BytesIO(data)) as package:
                entries={n:sha(package.read(n)) for n in package.namelist() if not n.endswith('/')}
                assert entries==ids['arms'][arm]['entries']
                module=package.read('js/dictionary/term-record-opfs-store.js')
                blob=hashlib.sha1(b'blob '+str(len(module)).encode()+b'\0'+module).hexdigest()
                assert blob==blob_ids[arm],(arm,blob)
                package_entries[arm]=entries
        assert sorted(k for k in package_entries['A'].keys()|package_entries['B'].keys() if package_entries['A'].get(k)!=package_entries['B'].get(k))==plan['expectedPackageEntries']
    fixture=read(repo/'test/perf/dictionaries.lock.json')['dictionaries']['jmdict']
    original=(evidence/'memory/harness-original.js').read_text();overlay=(evidence/'memory/harness-instrumented.js').read_text()
    assert original==(repo/'test/chromium/extension-two-dictionary-import.e2e.js').read_text()
    assert overlay==memory_overlay(original)
    reference=None;bindings=[]
    def verify(path,arm,media_check='sample',is_memory=False):
        global reference
        summary=read(path/'summary.json');report=read(path/'run-1.json');identity=ids['arms'][arm];hashes=identity['sourceHashes'].copy()
        if is_memory:hashes['test/chromium/extension-two-dictionary-import.e2e.js']=sha(overlay.encode())
        receipt=validate_import_summary(summary,report,dictionary='jmdict',fixture=fixture,source_sha=identity['sha'],package_sha256=identity['packageSha256'],browser_version=browser['version'],import_flags=None,source_hashes=hashes,source_dirty=is_memory,media_check=media_check,vndb_sah_allocation_units=None)
        assert receipt==read(path/'canonical-receipt.json')
        if reference is None:reference=receipt
        else:require_matching_receipts(reference,receipt,compare_media=media_check=='sample')
        bindings.append({'id':str(path.relative_to(evidence)),'receiptSha256':sha((path/'canonical-receipt.json').read_bytes()),'commonSha256':sha(json.dumps(receipt['common'],sort_keys=True).encode()),'termRows':receipt['common']['validation']['termRows'],'media':receipt['media']})
        return summary,receipt
    for item in obs:
        summary,_=verify(evidence/item['id'],'B' if item['arm']=='B' else 'A')
        assert summary['runs'][0]['totalImportMs']==item['totalImportMs']
    media=[]
    for arm in ('A','B'):media.append(verify(evidence/f'exhaustive-media-{arm}',arm,'all')[1])
    require_matching_receipts(*media)
    for item in plan['memorySchedule']:verify(evidence/'memory'/item['name'],item['arm'],is_memory=True)
    assert len(bindings)==26 and len({x['commonSha256'] for x in bindings})==1
    memory=audit_cell(evidence/'memory');assert memory==read(evidence/'memory/memory-audit.json') and memory['passesProspectiveMemoryScreen']
    assert read(evidence/'memory/semantic-failures.json')==[]
    def paired(kind,left,right):
        groups={}
        for item in obs:
            if item['kind']==kind:groups.setdefault(item['pair'],{})[item['arm']]=item['totalImportMs']
        assert all(set(x)=={left,right} for x in groups.values())
        values=list(groups.values());ratios=[x[right]/x[left] for x in values]
        rng=random.Random(897);samples=sorted(statistics.median(rng.choices(ratios,k=len(ratios))) for _ in range(10000))
        return {'count':len(values),'ratios':ratios,'medianPairedChangePercent':100*(statistics.median(ratios)-1),'equalWorkChangePercent':100*(sum(x[right] for x in values)/sum(x[left] for x in values)-1),'worstPairChangePercent':100*(max(ratios)-1),'descriptiveBootstrap95Percent':[100*(samples[i]-1) for i in (249,9749)],'fasterPairs':sum(x<1 for x in ratios)}
    analysis=read(evidence/'analysis.json')
    for key,kind,left,right in [('candidateVsBaseline','candidate','A','B'),('identicalCodeControl','control','A','C')]:assert paired(kind,left,right)==analysis[key]
    assert analysis['memoryPassed'] is True and analysis['status']=='correctness-memory-passed'
    result={'status':'PASS','order':expected_order,'archiveSha256':expected_archive_sha,'source':{arm:{k:v for k,v in identity.items() if k!='entries'} for arm,identity in ids['arms'].items()},'packageChangedEntries':ids['changedPackageEntries'],'rawOrdinaryObservationCount':len(obs),'semanticReceiptCount':len(bindings),'bindings':bindings,'memoryRawAudit':memory,'analysisRecomputed':analysis,'limits':'One complete fixed six-pair host. Same-code controls remain separate. Passing correctness and sampled-memory gates is not a latency improvement claim.'}
    (root/'independent-audit.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','order':expected_order,'semanticReceiptCount':len(bindings),'rawScans':memory['rawScanCount'],'analysis':analysis,'auditSha256':sha((root/'independent-audit.json').read_bytes())}))
except BaseException as error:
    (root/'independent-audit-failure.json').write_text(json.dumps({'type':type(error).__name__,'message':str(error)},indent=2)+'\n')
    raise
