#!/usr/bin/env python3
"""Freeze an evidence-only checkpoint from already reviewed immutable inputs."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import re
import statistics
import tarfile

ROOT = Path('/workspace/scratch/c563d487c718/experiments')
STAGE = Path(__file__).resolve().parent
TREE = STAGE / 'tree'
PREFIX_REL = 'builds/perf/import-study-c563d487/proof-consumer-full-results'
PREFIX = TREE / PREFIX_REL
PARENT = '16f8ae5d39bd8c1c41be489fd1ab5386b332b93d'
PARENT_TREE = 'a85c9e138350e4ec50b796e7c2e81ab692fadf83'
PARENT_DOC = ROOT / 'import-study-proof-consumer-20261128/tree/dev/perf/import-experiments-20260914.md'
FULL = ROOT / 'numeric-suffix-proof-consumer-982-full-evidence'
TOOLS = ROOT / 'numeric-suffix-proof-consumer-982-full-audit'


def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'gitBlobSha1': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def ref(relative):
    path = PREFIX / relative
    assert path.is_file() and not path.is_symlink()
    return {'path': str(path.relative_to(TREE)), **identity(path)}


def load(path):
    return json.loads(path.read_text())


def main():
    assert not (STAGE / 'publication-manifest.json').exists()
    assert not (PREFIX / 'index.json').exists()
    source_rows = load(STAGE / 'common-staging-1.json')['files'] + load(STAGE / 'terminal-inputs-staging.json')['files'] + [load(STAGE / 'root-decision-v2-staging.json')]
    origins = {row['path']: row for row in source_rows}
    for row in source_rows:
        path = TREE / row['path']
        assert identity(path) == {key: row[key] for key in ('bytes', 'sha256', 'gitBlobSha1')}
        if 'sourceRelativeToExperiments' in row:
            assert path.read_bytes() == (ROOT / row['sourceRelativeToExperiments']).read_bytes()

    # Keep the pre-freeze wording beforeimages and exact source for this assembly.
    prose_sources = [STAGE / name for name in ('canonical-insertion-before-precision-1.md',
        'canonical-insertion-before-scope-2.md', 'canonical-precision-amendment.json',
        'canonical-scope-amendment.json', 'canonical-insertion.md', 'finalize-checkpoint.py')]
    archive = PREFIX / 'canonical-preparation-history.tar.gz'
    members = []
    with archive.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as bundle:
                for path in sorted(prose_sources):
                    data = path.read_bytes()
                    name = str(path.relative_to(ROOT))
                    entry = tarfile.TarInfo(name)
                    entry.size = len(data); entry.mode = 0o644; entry.mtime = 0
                    bundle.addfile(entry, io.BytesIO(data))
                    members.append({'path': name, **identity(path)})
    with tarfile.open(archive, 'r:gz') as bundle:
        assert bundle.getnames() == [row['path'] for row in members]
        for row in members:
            data = bundle.extractfile(row['path']).read()
            assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    member_path = PREFIX / 'canonical-preparation-history-members.json'
    member_path.write_text(json.dumps({'schemaVersion': 1, 'representation': 'New deterministic lossless storage representation of exact pre-freeze prose/source bytes.',
        'archive': ref('canonical-preparation-history.tar.gz'), 'memberCount': len(members),
        'rawMemberBytes': sum(row['bytes'] for row in members), 'members': members, 'roundTripExact': True}, indent=2) + '\n')

    prior = PARENT_DOC.read_bytes()
    assert len(prior) == 165996 and hashlib.sha256(prior).hexdigest() == '124eb59e5a456553e374ff055b95de42b133063add309d1353bad952ea5b4d1a'
    addition = (STAGE / 'canonical-insertion.md').read_bytes()
    assert hashlib.sha256(addition).hexdigest() == '4c937d13ee8fb8935fd588e41a1e7f27b6300b0e0255935078ec7661c676ab19'
    header = b'# Codex instructions: import optimization experiments\n\n'
    assert prior.startswith(header) and len(header) == 55 and addition.endswith(b'\n\n')
    new_doc = prior[:len(header)] + addition + prior[len(header):]
    assert new_doc[:len(header)] + new_doc[len(header) + len(addition):] == prior
    doc = TREE / 'dev/perf/import-experiments-20260914.md'
    doc.parent.mkdir(parents=True, exist_ok=True)
    assert not doc.exists(); doc.write_bytes(new_doc)

    replay = load(PREFIX / 'analysis/independent-paired-result-review-v2.json')
    primary = load(PREFIX / 'combined-primary-index.json')
    raw = load(PREFIX / 'all-six-independent-raw-index.json')
    expected = load(TOOLS / 'independent-complete-import-expected.json')
    binding = load(TOOLS / 'publication-binding.json')
    package = load(PREFIX / 'package-byte-deltas.json')
    assert replay['allEvidenceReconciliationChecksPass'] is True
    assert primary['totals'] == {'primaryRecords': 330, 'reports': 252, 'candidatePairs': 72,
        'identicalCodePairs': 24, 'memoryObservations': 24, 'qualifiedMemoryObservations': 22, 'rawScans': 2108}
    assert raw['totals']['archiveMembers'] == 1896 and raw['totals']['qualifiedMemoryObservations'] == 22
    assert primary['completeRegisteredPlanPresent'] is True
    assert primary['allPrimaryChecksPass'] is False and primary['allMemoryGatesPass'] is False
    assert primary['bothTargetMechanicalThresholdsPass'] is False
    assert package['commonCompressedArchiveSizes'] == {'baselineBytes': 17060417, 'candidateBytes': 17061961, 'deltaBytes': 1544}
    cells = []
    for cell in replay['cells']:
        name = cell['cell']; candidate = cell['candidateVsBaseline']; control = cell['identicalCodeControl']
        absolute_controls = [abs(pair['changePercent']) for pair in control['pairs']]
        raw_cell = next(row for row in raw['cells'] if row['cell'] == name)
        cells.append({'cell': name, 'jobId': cell['jobId'], 'jobConclusion': 'failure' if name == 'vndb-AB' else 'success',
            'reportCount': 42, 'primaryRecordCount': 55, 'rawArchiveMemberCount': raw_cell['memberCount'],
            'primaryAudit': ref(f'cells/{name}/primary-log-audit.json'),
            'rawAudit': ref(f'cells/{name}/independent-raw-evidence-audit.json'),
            'rawArchive': ref(f'cells/{name}/raw-evidence.zip'),
            'recoveryReceipt': ref(f'cells/{name}/raw-archive-recovery.json'),
            'originalLogAndMetadataArchive': ref(f'cells/{name}/original-logs-and-postprocessing-records.tar.gz'),
            'originalLogAndMetadataMembers': ref(f'cells/{name}/original-logs-and-postprocessing-records-members.json'),
            'candidatePairedStatistics': candidate, 'identicalCodeStatistics': control,
            'identicalCodeChangePercentRange': cell['controlChangePercentRange'],
            'descriptiveAbsoluteControlMedianPercent': statistics.median(absolute_controls),
            'descriptiveAbsoluteControlPairsExceedingAbsoluteCandidateMedian': sum(value > abs(candidate['medianPairedChangePercent']) for value in absolute_controls),
            'controlComparisonIsDescriptiveNotNewGate': True,
            'originalPrimaryAllChecksPass': cell['originalPrimaryAllChecksPass'],
            'reproducedPrimaryQualificationErrors': cell['independentlyReproducedQualificationErrors'],
            'memory': cell['memorySummaryArithmetic'], 'rawScanCount': raw_cell['memory']['rawScanCount'],
            'storageBytes': cell['primaryStorageBytes'], 'semanticReceiptSha256': cell['primarySemanticSha256'],
            'mechanicalTargetThresholdPass': cell['mechanicalTargetThresholdPass'],
            'mechanicalNonTargetHoldSignal': cell['mechanicalNonTargetHoldSignal']})
    assert sum(row['rawScanCount'] for row in cells) == 2108
    assert sum(row['rawArchive']['bytes'] for row in cells) == 13557952
    ba = next(row for row in cells if row['cell'] == 'vndb-BA')
    assert ba['candidatePairedStatistics']['medianPairedChangePercent'] == -1.995784404609613
    assert ba['descriptiveAbsoluteControlPairsExceedingAbsoluteCandidateMedian'] == 3
    old_index_path = ROOT / 'import-study-proof-consumer-20261128/tree/builds/perf/import-study-c563d487/proof-consumer-study/index.json'
    prior_index = load(old_index_path)
    prior_refs = [row for row in prior_index['evidenceFiles'] if any(fragment in row['path'] for fragment in
        ('a300-full-auditor-preparation-history', 'current-a300/full-auditor/', 'current-a300/full-qualification-binding', 'current-a300/full-initial-run-identity'))]

    evidence_files = []
    for path in sorted(PREFIX.rglob('*')):
        if not path.is_file(): continue
        assert not path.is_symlink()
        rel = str(path.relative_to(TREE))
        assert re.fullmatch(r'[A-Za-z0-9._/-]+', rel) and '..' not in Path(rel).parts
        item = {'path': rel, **identity(path)}
        origin = origins.get(rel)
        if origin:
            item.update({key: origin[key] for key in ('sourceRelativeToExperiments', 'storage') if key in origin})
        else:
            item['storage'] = 'new-lossless-prose-history' if path.suffix == '.gz' else 'new-prose-history-member-manifest'
        evidence_files.append(item)

    index = {'schemaVersion': 1, 'recordedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'kind': 'Final source-bound full-browser qualification and no-PR disposition; complete observations with failed qualification.',
        'evidenceParent': {'commit': PARENT, 'tree': PARENT_TREE, 'allExistingFilesPreserved': True},
        'canonical': {'path': str(doc.relative_to(TREE)), **identity(doc), 'parent': {'commit': PARENT, **identity(PARENT_DOC)},
            'pureInsertion': True, 'insertionOffsetBytes': len(header), 'insertionBytes': len(addition),
            'insertionSha256': hashlib.sha256(addition).hexdigest(), 'parentBytesReconstructExactly': True},
        'source': {'runId': 46141233321, 'attempt': 1, 'workflowCommit': binding['workflowCommit'],
            'workflowTree': binding['workflowTree'], 'workflowSha256': expected['workflowSha256'],
            'baseline': expected['baseline'], 'candidate': expected['candidate'], 'sourceTrees': expected['sourceTrees'],
            'productFiles': binding['productFiles'], 'criteriaSha256': expected['criteriaSha256'],
            'observerSha256': expected['observerSha256'], 'nodeVersion': expected['nodeVersion'], 'browser': expected['browser'],
            'fixtures': expected['fixtures'], 'fixtureLockSha256': expected['fixtureLockSha256'], 'dependencyLockSha256': expected['lockSha256'],
            'productionFlagsUnchanged': True, 'oldSourceCohortsPooledOrTransferred': False},
        'protocol': {'jobCells': 6, 'physicalHostIndependenceEstablished': False,
            'inheritedOriginalAuditHostWording': 'Original primary audits retain their inherited independent-hosts wording. The final interpretation establishes separately scheduled AB/BA job cells only.',
            'candidatePairsPerCell': 12, 'identicalCodePairsPerCell': 4, 'excludedWarmupsPerCell': 4,
            'exhaustiveMediaReportsPerCell': 2, 'separateMemoryReportsPerCell': 4,
            'timingScope': 'Original browser completedAtMs minus startedAtMs; no diagnostic, component or automation duration substituted.',
            'newAcquisitionOrReplacement': False, 'outliersDropped': False, 'controlSubtraction': False, 'cellPooling': False},
        'totals': {**primary['totals'], 'archiveMembers': 1896, 'originalInnerZipBytes': 13557952,
            'unqualifiedMemoryObservations': 2, 'unattemptedReports': 0, 'completeRegisteredPlanPresent': True},
        'cells': cells,
        'decision': {'productPerformancePr': 'Do not create for this exact candidate/cohort', 'performanceQualificationPassed': False,
            'targetRuleUnchanged': 'Each VNDB cell requires at least 2% median reduction, at least 9/12 faster pairs, descriptive upper interval below 0, materially smaller A/A variation and every required non-timing gate.',
            'vndbAB': 'Latency target passes; original baseline A1/A2 coverage gaps of 286.319545/265.378713 ms exceed 250 ms. Qualified PSS/private pair aggregates remain null. Job failure is retained despite all 42 reports.',
            'vndbBA': 'Exact 1.995784404609613% reduction is below 2%; rounding cannot change the gate. Three of four absolute A/A changes exceed that effect, with median absolute change of 2.3023505587978055%.',
            'jmdict': 'No demonstrated complete-import gain. BA has a one-cell adverse numerical signal, larger same-cell controls and no matching AB signal. No non-regression/equivalence claim.',
            'jitendex': 'Both intervals cross zero; adverse equal-work direction and all large outliers remain. No gain or non-regression/equivalence claim.',
            'memoryFailureMeaning': 'Incomplete required baseline coverage; not an established candidate memory regression.',
            'rootFinalDecision': ref('root-qualification-decision-v2.json'),
            'rootHistoricalBeforeimage': ref('root-qualification-decision.json'),
            'rootProvenanceAmendment': 'Earlier scope wording used past tense while the supplemental replay was pending. Final v2 binds actual completed replay 022922; statistics/disposition are unchanged.',
            'derivedDecision': ref('final-qualification-decision.json'), 'jmdictPriority': ref('jmdict-frontier-and-proof-scope.json')},
        'integrityAndQualification': {'originalArchiveIntegrityPassed': True, 'additionalEvidenceReconciliationPassed': True,
            'allOriginalPrimaryChecksPass': primary['allPrimaryChecksPass'], 'allMemoryQualificationGatesPass': primary['allMemoryGatesPass'],
            'bothTargetNumericalGatesPass': primary['bothTargetMechanicalThresholdsPass'],
            'replicatedNonTargetMechanicalHoldSignals': primary['replicatedNonTargetMechanicalHoldSignals'],
            'logicalStorageBytes': expected['storageBytes'], 'vndbSahAllocationUnits': [77, 77],
            'observedSahFileCount': 8, 'observed4096ByteReserveFiles': 7,
            'storageComparisonScope': 'Logical file sizes, paths and validation receipts.',
            'browserOutputComparisonScope': 'Declared row-count, lookup, restart and media probes.',
            'packageEntryCount': 582, 'unchangedPackageEntryCount': 580,
            'packageAccounting': ref('package-byte-deltas.json'), 'rawGateSummary': ref('final-raw-gate-summary.json')},
        'machineEvidence': {'primaryIndex': ref('combined-primary-index.json'), 'rawIndex': ref('all-six-independent-raw-index.json'),
            'additionalReplay': ref('analysis/independent-paired-result-review-v2.json'),
            'terminalAcquisitionApi': ref('terminal-acquisition-api.json'), 'firstFourHistoricalSnapshot': ref('history/first-four-independent-raw-index.json')},
        'postprocessingHistory': {'rawFilenameCorrection': ref('postprocessing/criteria-member-name-amendment.json'),
            'rawFilenamePeerReview': ref('postprocessing/criteria-member-name-independent-review.json'),
            'rawFilenameRootReviewIncludingWrongV1SourceComparison': ref('postprocessing/root-filename-review.json'),
            'rawAuditorV3': ref('postprocessing/raw-evidence-audit-v3.py'),
            'sourceBeforeimages': ref('postprocessor-source-history-members.json'),
            'firstActualRawV2Failure': {'archive': ref('cells/jmdict-BA/original-logs-and-postprocessing-records.tar.gz'),
                'member': 'numeric-suffix-proof-consumer-982-full-evidence/jmdict-BA/raw-recovery-1/raw-evidence-audit-failure-20261128T115319113368.json',
                'sha256': 'c4c246a0982fbc176ef652158bb3a09412da4044ccec55509efa1cc0248e71aa'},
            'additionalReviewerOriginalFailureAndReviewedV2': ref('checkpoint-replay-sources-members.json'),
            'additionalReviewerRootReview': ref('analysis/root-reviewer-qualification-separation-review.json'),
            'allOriginalAuditsPreserved': True, 'noMeasurementOrCriteriaChange': True},
        'durablePriorInputs': {'commit': PARENT, 'index': {'path': 'builds/perf/import-study-c563d487/proof-consumer-study/index.json', **identity(old_index_path)},
            'files': prior_refs, 'purpose': 'Reuse already durable exact frozen observer/auditor/binding/correctness/criteria inputs rather than duplicate them.'},
        'replay': {'originalRun': 'https://github.com/ManabiIO/manabitan/actions/runs/46141233321',
            'readOriginalLogCommand': 'gh run view 46141233321 --repo ManabiIO/manabitan --log',
            'originalToolingCommit': binding['workflowCommit'],
            'offlineRestoration': 'Per-cell gzip/tar member paths are relative to the recorded experiments root; restore their exact bytes and direct-copy sourceRelativeToExperiments mappings. Restore the unchanged auditor inputs from the prior checkpoint source archive. Use a separate new output directory because replay tools refuse overwrites.',
            'additionalReviewerSource': ref('analysis/review-original-paired-results-v2.py'),
            'primaryIndexAssembler': ref('analysis/assemble-primary-index.py'),
            'rawIndexCollector': ref('analysis/build-final-raw-index-v2.py'),
            'noReplayPerformedByCheckpointAssembly': True,
            'newMeasurementPolicy': 'Any future acquisition is a separate source-bound study; this exact completed cohort is not retried or replaced.'},
        'evidenceFileCount': len(evidence_files), 'evidenceBytes': sum(row['bytes'] for row in evidence_files),
        'evidenceFiles': evidence_files}
    index_path = PREFIX / 'index.json'
    index_path.write_text(json.dumps(index, indent=2, ensure_ascii=False) + '\n')

    files = []
    for path in sorted(TREE.rglob('*')):
        if not path.is_file(): continue
        assert not path.is_symlink()
        rel = str(path.relative_to(TREE))
        assert rel == 'dev/perf/import-experiments-20260914.md' or rel.startswith(PREFIX_REL + '/')
        assert re.fullmatch(r'[A-Za-z0-9._/-]+', rel) and '..' not in Path(rel).parts
        encoded = 'base64' if path.suffix in ('.zip', '.gz') else 'utf-8'
        if encoded == 'utf-8': path.read_text()
        files.append({'repositoryPath': rel, 'stagedPath': str(path), **identity(path), 'encoding': encoded, 'mode': '100644'})
    assert len(files) == len(evidence_files) + 2
    manifest = {'schemaVersion': 1, 'recordedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'purpose': 'Evidence-only final complete-observation/failed-qualification checkpoint. No product edit or ref mutation.',
        'repository': 'ManabiIO/manabitan', 'branch': 'perf/import-study-evidence-20261128-c563d487',
        'expectedParentCommit': PARENT, 'expectedParentTree': PARENT_TREE, 'fileCount': len(files),
        'totalBytes': sum(row['bytes'] for row in files), 'canonical': index['canonical'],
        'index': {'repositoryPath': str(index_path.relative_to(TREE)), **identity(index_path)},
        'files': files, 'plainPortablePaths': True, 'symlinks': 0, 'unlistedFiles': 0,
        'runtimeSourceChanged': False, 'referenceMutationPerformed': False}
    m = STAGE / 'publication-manifest.json'
    m.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
    receipt = {'schemaVersion': 1, 'manifest': identity(m), 'canonical': identity(doc), 'index': identity(index_path),
        'fileCount': len(files), 'evidenceFileCount': len(evidence_files), 'totalBytes': manifest['totalBytes'],
        'parentCanonicalReconstructsExactly': True, 'allFilesAndOriginsHashVerified': True,
        'allLosslessArchivesRoundTripVerified': True, 'scope': 'Read-only evidence assembly and byte verification only; no tests, builds, browser, native execution, acquisition or publication.'}
    q = STAGE / 'final-local-verification.json'; q.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
