#!/usr/bin/env python3
"""Stage immutable completed evidence; no source mutation, measurement or publication."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import os
import tarfile

ROOT = Path('/workspace/scratch/c563d487c718/experiments')
STAGE = Path(__file__).resolve().parent
TREE = STAGE / 'tree'
PREFIX = TREE / 'builds/perf/import-study-c563d487/proof-consumer-full-results'
FULL = ROOT / 'numeric-suffix-proof-consumer-982-full-evidence'
TOOLS = ROOT / 'numeric-suffix-proof-consumer-982-full-audit'
CELLS = ('jmdict-AB', 'jmdict-BA', 'jitendex-AB', 'jitendex-BA', 'vndb-AB', 'vndb-BA')
RECEIPT = STAGE / 'terminal-inputs-staging.json'


def identity(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
            'gitBlobSha1': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}


def exact(source, relative):
    assert source.is_file() and not source.is_symlink(), str(source)
    dest = PREFIX / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        assert dest.read_bytes() == source.read_bytes(), str(dest)
    else:
        os.link(source, dest)
    return {'path': str(dest.relative_to(TREE)), 'sourceRelativeToExperiments': str(source.relative_to(ROOT)),
            **identity(dest), 'storage': 'exact-hardlinked-local-copy'}


def archive(paths, name):
    target = PREFIX / (name + '.tar.gz')
    members_path = PREFIX / (name + '-members.json')
    assert not target.exists() and not members_path.exists()
    members = []
    with target.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output, mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as bundle:
                for path in sorted(set(paths)):
                    assert path.is_file() and not path.is_symlink(), str(path)
                    data = path.read_bytes()
                    assert len(data) <= 16 * 1024 * 1024, 'Unexpected large non-ZIP input'
                    relative = str(path.relative_to(ROOT))
                    entry = tarfile.TarInfo(relative)
                    entry.size = len(data)
                    entry.mtime = 0
                    entry.mode = 0o644
                    entry.uid = entry.gid = 0
                    entry.uname = entry.gname = ''
                    bundle.addfile(entry, io.BytesIO(data))
                    members.append({'path': relative, **identity(path)})
    with tarfile.open(target, 'r:gz') as bundle:
        assert bundle.getnames() == [member['path'] for member in members]
        for member in members:
            data = bundle.extractfile(member['path']).read()
            assert len(data) == member['bytes'] and hashlib.sha256(data).hexdigest() == member['sha256']
    manifest = {'schemaVersion': 1, 'representation': 'New deterministic lossless gzip/tar storage representation of exact original files; no observation serialization.',
                'sourceRoot': str(ROOT), 'archive': {'path': str(target.relative_to(TREE)), **identity(target)},
                'memberCount': len(members), 'rawMemberBytes': sum(member['bytes'] for member in members),
                'members': members, 'roundTripExact': True}
    members_path.write_text(json.dumps(manifest, indent=2) + '\n')
    return [{'path': str(target.relative_to(TREE)), **identity(target), 'storage': 'new-lossless-archive'},
            {'path': str(members_path.relative_to(TREE)), **identity(members_path), 'storage': 'new-archive-member-manifest'}]


def main():
    assert not RECEIPT.exists(), 'Never overwrite an earlier staged terminal snapshot'
    paired = json.loads((STAGE / 'independent-paired-result-review-v2.json').read_text())
    assert paired['allEvidenceReconciliationChecksPass'] is True and len(paired['cells']) == 6
    combined = FULL / 'combined-primary-index.json'
    all_raw = FULL / 'all-six-independent-raw-index.json'
    assert combined.is_file() and all_raw.is_file(), 'Require both independently completed six-cell indices'
    raw = json.loads(all_raw.read_text())
    assert raw['totals']['completedCells'] == 6 and raw['totals']['rawReports'] == 252
    files = []
    source_map = [
        (combined, 'combined-primary-index.json'),
        (all_raw, 'all-six-independent-raw-index.json'),
        (FULL / 'final-qualification-decision.json', 'final-qualification-decision.json'),
        (FULL / 'final-raw-gate-summary.json', 'final-raw-gate-summary.json'),
        (FULL / 'terminal-acquisition-api.json', 'terminal-acquisition-api.json'),
        (ROOT / 'root-remote-continuation-20261128/a300-full-root-qualification-decision.json', 'root-qualification-decision.json'),
        (ROOT / 'root-remote-continuation-20261128/a300-final-reviewer-qualification-separation-root-review.json', 'analysis/root-reviewer-qualification-separation-review.json'),
        (FULL / 'package-byte-deltas.json', 'package-byte-deltas.json'),
        (FULL / 'jmdict-frontier-and-proof-scope.json', 'jmdict-frontier-and-proof-scope.json'),
        (FULL / 'jmdict-frontier-independent-review.json', 'analysis/jmdict-frontier-independent-review.json'),
        (FULL / 'assemble-package-byte-deltas.py', 'analysis/assemble-package-byte-deltas.py'),
        (FULL / 'package-accounting-independent-source-review.json', 'analysis/package-accounting-independent-source-review.json'),
        (STAGE / 'review-original-paired-results-v2.py', 'analysis/review-original-paired-results-v2.py'),
        (STAGE / 'independent-paired-result-review-v2.json', 'analysis/independent-paired-result-review-v2.json'),
        (STAGE / 'benchmark-terminal-replay-source-review.json', 'analysis/benchmark-terminal-replay-source-review.json'),
        (TOOLS / 'build-final-raw-index-v2.py', 'analysis/build-final-raw-index-v2.py'),
        (TOOLS / 'build-final-raw-index-independent-review.json', 'analysis/build-final-raw-index-independent-review.json'),
    ]
    for source, dest in source_map:
        files.append(exact(source, dest))
    for cell in CELLS:
        metadata = []
        directory = FULL / cell
        raw_directory = directory / 'raw-recovery-1'
        files.append(exact(raw_directory / 'raw-evidence.zip', f'cells/{cell}/raw-evidence.zip'))
        files.append(exact(directory / 'primary-log-audit.json', f'cells/{cell}/primary-log-audit.json'))
        files.append(exact(raw_directory / 'independent-raw-evidence-audit.json', f'cells/{cell}/independent-raw-evidence-audit.json'))
        files.append(exact(raw_directory / 'raw-archive-recovery.json', f'cells/{cell}/raw-archive-recovery.json'))
        for path in directory.rglob('*'):
            if not path.is_file():
                continue
            assert not path.is_symlink()
            if path == raw_directory / 'raw-evidence.zip':
                continue
            assert path.suffix in ('.json', '.jsonl', '.log'), f'Unexpected cell input: {path}'
            metadata.append(path)
        files.extend(archive(metadata, 'cells/' + cell + '/original-logs-and-postprocessing-records'))
    files.extend(archive([TOOLS / 'raw-evidence-audit-v2.py', TOOLS / 'build-final-raw-index.py',
                          TOOLS / 'final-index-identity-check-amendment.json',
                          TOOLS / 'final-index-identity-check-amendment.patch'], 'postprocessor-source-history'))
    reviewer_history = [STAGE / 'initial-preparation.json', STAGE / 'common-staging-1.json',
                        Path(__file__), STAGE / 'review-original-paired-results.py',
                        STAGE / 'paired-replay-qualification-amendment.json',
                        STAGE / 'paired-replay-qualification-amendment.patch']
    reviewer_history += list(STAGE.glob('paired-replay-command-*'))
    reviewer_history += list(STAGE.glob('*replay*review*.json'))
    files.extend(archive(reviewer_history, 'checkpoint-replay-sources'))
    result = {'schemaVersion': 1, 'recordedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'parentCommit': '16f8ae5d39bd8c1c41be489fd1ab5386b332b93d',
              'scope': 'All six terminal original browser evidence cells, original postprocessing history and independent indices. Canonical conclusion and publication manifest remain separate review steps.',
              'files': files, 'rawReports': 252, 'primaryRecords': 330,
              'newAcquisition': False, 'sourceEdited': False, 'referenceMutation': False,
              'priorCheckpointChanged': False}
    RECEIPT.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'receipt': str(RECEIPT), **identity(RECEIPT), 'newStagedFiles': len(files),
                      'bytes': sum(row['bytes'] for row in files)}))


if __name__ == '__main__':
    main()
