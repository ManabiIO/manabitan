    } else {
        const caseId=plan.caseId,prefix="negative-case-"+caseId+"-";
        equal(plan.studyCasesOrder,[1,2,3,4,5,6],"Frozen six synthetic case order");
        check(plan.measuredObservationCount===16,"Frozen sixteen negative children in this cell");
        equal(plan.prospectiveProtocol,expected.negativeProtocol,"Exact prospective negative protocol");
        equal(plan.fixtureManifest,expected.negativeManifest,"Exact independently generated fixture manifest");
        check(plan.fixtureManifestSha256===expected.negativeManifestSha256,"Frozen complete fixture-manifest byte hash");
        const fixture=expected.negativeManifest.cases.find(x=>x.id===caseId);
        const target=expected.negativeExpected.cases.find(x=>x.id===caseId);
        check(!!fixture&&!!target,"Known synthetic fixture");
        const compact=get("PREFIX_NEGATIVE_OBSERVATION"),diagnostics=get("PREFIX_NEGATIVE_DIAGNOSTIC");
        equal(compact.map(({caseId,pair,arm})=>({caseId,pair,arm})),schedule.map(s=>({caseId,...s})),"Complete fixed observed case schedule");
        equal(receipts.map(r=>r.label),[prefix+"baseline-verification",prefix+"diagnostic",...schedule.map(s=>prefix+"pair-"+s.pair+"-"+s.arm)],"All eighteen raw negative children including two excluded preflights in exact order");
        const baseline=child(prefix+"baseline-verification","A",false,true),diagnostic=child(prefix+"diagnostic","B",true);
        const perPassBytes=fixture.banks.reduce((s,b)=>s+b.uncompressedSize,0);
        for(const key of ["expectedUniqueCount","expectedMechanics","expectedPublic","expectedShadow"])equal(fixture[key],target[key],"Independent fixture static expectation "+key);
        function verify(data,label,excluded) {
            if(!data)return;
            check(data.complete===true&&data.caseId===caseId,label+" successful exact case identity");
            check(data.excludedOnly===excluded&&data.measuredRepetitions===(excluded?0:16),label+" measured/excluded role");
            check(data.repetitions?.length===(excluded?1:16)&&data.warmups?.length===(excluded?0:2),label+" every per-pass receipt retained");
            equal(data.bankIdentities,fixture.banks,label+" exact raw/compressed/CRC bank identities");
            check(data.fixtureManifestSha256===expected.negativeManifestSha256,label+" exact fixture-manifest hash");
            check(data.generatorSha256===expected.toolingHashes["negative-fixtures.mjs"]&&data.outputDigestSha256===expected.toolingHashes["output-digest.mjs"],label+" generator and output-digest observer identities");
            check(data.perPassRows===20000&&data.perPassUniqueCount===target.expectedUniqueCount,label+" full rows and unique work");
            for(const key of ["elapsedMs","cpuMs","inflateMs","inflateCpuMs","parseMs","lookupMs","nativeParseMs","rows","indexBytes"]){
                check(data.repetitions.every(r=>finite(r[key])),label+" every repetition has finite numeric "+key);
                check(data[key]===data.repetitions.reduce((s,r)=>s+r[key],0),label+" exact sequential binary64 repetition sum "+key);
            }
            for(const [kind,passes]of [["warmup",data.warmups],["measured",data.repetitions]])for(const [i,pass]of passes.entries()) {
                check(pass.repetition===i,label+" "+kind+" fixed repetition index");
                if(kind==="warmup")check(pass.excluded===true,label+" warmup excluded");
                check(pass.rows===20000&&pass.uniqueCount===target.expectedUniqueCount,label+" "+kind+" full rows/unique count "+i);
                for(const [key,value]of Object.entries(target.expectedPublic))check(pass[key]===value,label+" "+kind+" exact public work "+key+" "+i);
                check(pass.crcReusedBytes===0&&pass.crcVerifiedBytes===perPassBytes,label+" complete uncached CRC byte work "+i);
                check(pass.digest===baseline?.digest&&pass.indexBytes===baseline?.perPassIndexBytes,label+" full rich output/index parity "+i);
                for(const metric of ["elapsedMs","cpuMs","inflateMs","inflateCpuMs","parseMs","lookupMs","nativeParseMs"])check(finite(pass[metric])&&pass[metric]>=0,label+" "+kind+" finite nonnegative "+metric+" "+i);
            }
            equal(data.digest,baseline?.digest,label+" baseline rich digest");
            equal(data.perPassIndexBytes,baseline?.perPassIndexBytes,label+" baseline index byte count");
        }
        verify(baseline,prefix+"baseline-verification",true);verify(diagnostic,prefix+"diagnostic",true);
        if(diagnostic) {
            checkMechanics(diagnostic.diagnostic,"Excluded case"+caseId+" diagnostic");
            mechanics[caseId]=diagnostic.diagnostic;
            equal(diagnostic.diagnostic,target.expectedMechanics,"All forty-eight independent static mechanical expectations");
            check(diagnostic.wasmSha256===plan.diagnosticWasmSha256,"Plan-bound external diagnostic binary");
            check(diagnostics.length===1&&diagnostics[0]?.caseId===caseId,"Single correct compact diagnostic");
            equal(diagnostics[0]?.counts,diagnostic.diagnostic,"Compact/raw mechanics");
        }
        for(const step of schedule) {
            const label=prefix+"pair-"+step.pair+"-"+step.arm,data=child(label,step.arm);
            verify(data,label,false);if(!data)continue;
            rawObservations.push({caseId,...step,result:data});
            const short=compact.find(x=>x.caseId===caseId&&x.pair===step.pair&&x.arm===step.arm);
            for(const [key,value]of Object.entries(short??{}))if(!["caseId","pair","arm"].includes(key))equal(data[key],value,label+" compact/raw "+key);
        }
        check(rawObservations.length===16,"All sixteen measured child sums retained");
        const stats=summarize(rawObservations,final?.summary,"Case "+caseId);statistics[caseId]=stats;
        const candidate=stats["candidate.elapsedMs"],control=stats["identicalControl.elapsedMs"];
        const triggered=!!candidate&&!!control&&candidate.medianPairedChangePercent>3&&candidate.slowerPairs===4&&candidate.medianPairedChangePercent>control.largestAbsoluteChangePercent;
        check(final?.assessment?.clearSlowdownRuleTriggered===triggered,"Exact preregistered one-host negative risk rule");
        check(near(final?.assessment?.largestAbsoluteControlChangePercent,control?.largestAbsoluteChangePercent),"Exact largest absolute A/A paired change");
        stats.prospectiveNegativeAssessment={clearSlowdownRuleTriggered:triggered,interpretation:triggered?"Hold/reject exact candidate":"No automatic pass: ambiguous negatives remain a hold/qualification limitation; not an equivalence proof"};
        check(final?.observations===16&&final?.complete===true&&final?.caseId===caseId,"Complete sixteen-observation fixed negative cell");
    }
    // Check child command shape independently of output metadata. No additional switches are accepted.
    for(const receipt of receipts) {
        const data=receipt.result;
        const command=receipt.command??[],args=command.slice(5);
        equal(command.slice(0,3),["node","--expose-gc","--max-old-space-size=512"],receipt.label+" exact Node argument prefix");
        check(command[3]?.endsWith("/"+(negative?"negative-screen.mjs":"screen.mjs")),receipt.label+" exact child entrypoint");
        check(command[4]===String(negative?plan.caseId:plan.dictionary),receipt.label+" exact workload argument");
        check(args[0]==="--source-root"&&args[1]===data?.sourceRoot,receipt.label+" exact selected source argument");
        check(args[2]===(negative?"--fixtures-dir":"--cache-dir")&&typeof args[3]==="string",receipt.label+" exact fixture argument");
        const tail=args.slice(4);
        if(data?.diagnosticWasm!==null)equal(tail,["--diagnostic-wasm",data?.diagnosticWasm],receipt.label+" only excluded diagnostic option");
        else if(negative&&receipt.label.endsWith("baseline-verification"))equal(tail,["--verify-only"],receipt.label+" only baseline verification option");
        else equal(tail,[],receipt.label+" production timing switches unchanged");
    }
    return {schemaVersion:1,scope:negative?"One fixed synthetic child-sum component cell":"One locked dictionary native component cell",
        dictionary:plan.dictionary??null,caseId:plan.caseId??null,negative,complete:final?.complete===true,allLogChecksPass:errors.length===0,errors,
        source:{baseline:plan.baseline,candidate:plan.candidate,tooling:plan.tooling,runtime:plan.runtime},
        artifactBindingPass,measuredObservationCount:rawObservations.length,rawChildReceiptCount:receipts.length,mechanics,statistics,rawObservations,failures,
        limits:["Original artifact/source compilation, native17-word oracle and smoke/correctness audits remain separately mandatory.","No complete browser import or process-memory qualification.","Frozen9e10 source only; develop advanced to dcfc02a0, so no current-source gain transfer.","No pooling corpora/hosts, subtraction, trimming, replacement or retries."]};
}

function auditPriorStreakLog(parsed,expected,artifactBinding=null) {
    const records=parsed.records??parsed,errors=[...(parsed.parseErrors??[]).map(x=>"JSON parse error: "+JSON.stringify(x))];
    const check=(condition,label)=>{if(!condition)errors.push(label);};
    const isPlan=r=>r.kind==="PRIOR_STREAK_SELECTOR_PLAN"||r.kind==="PREFIX_NEGATIVE_PLAN";
    const starts=records.map((r,i)=>isPlan(r)?i:-1).filter(i=>i>=0);
    const cells=[],seen=[];
    for(let i=0;i<starts.length;i++) {
        const segment=records.slice(starts[i],starts[i+1]??records.length),p=segment[0].value;
        const id=p.dictionary??"negative-"+p.caseId;
        seen.push(id);
        try{cells.push({id,...auditPriorStreakCell({records:segment,parseErrors:[]},expected,artifactBinding)});}
        catch(e){cells.push({id,complete:false,allLogChecksPass:false,errors:["Audit could not complete this retained segment: "+String(e)],rawSegment:segment});}
    }
    check(prefixEqual(seen,expected.cellOrder),"Every one of the nine declared cells appears once in fixed serial order; missing/failed preflights are incomplete");
    const candidateIds=cells.filter(c=>c.source).map(c=>c.source.candidate);
    for(const id of candidateIds)check(prefixEqual(id,candidateIds[0]),"One exact candidate source/binary/manifest identity across all observed cells");
    const baselineIds=cells.filter(c=>c.source).map(c=>c.source.baseline);
    for(const id of baselineIds)check(prefixEqual(id,baselineIds[0]),"One exact baseline source/binary identity across all observed cells");
    const measured=cells.reduce((s,c)=>s+(c.measuredObservationCount??0),0);
    check(measured===144,"Exactly 144 fixed measured child observations");
    for(const c of cells)if(!c.allLogChecksPass)errors.push(c.id+": cell audit incomplete/failed; see retained errors and raw receipts");
    return {schemaVersion:1,runId:expected.runId,jobId:expected.jobId,toolingHead:expected.toolingHead,scope:"Read-only independent reconstruction of one nine-cell native component screen; no new execution or measurements",complete:cells.length===9&&cells.every(c=>c.complete),allLogChecksPass:errors.length===0,errors,cellOrder:seen,measuredObservationCount:measured,plannedMeasuredObservations:144,cells,artifactBindingPass:artifactBinding===null?null:cells.every(c=>c.artifactBindingPass===true),recordCount:records.length,parseErrors:parsed.parseErrors??[],prePlanRecords:records.slice(0,starts[0]??records.length),interpretation:"A component target signal is insufficient without every prospective control/correctness gate and separate source-bound artifact audit. Current-develop and complete-import qualification remain separate."};
}
