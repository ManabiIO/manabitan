"""Prepare a separate read-only log auditor; never acquire or alter a cohort."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent
old = (root / 'jmdict-prefix-selector-corrected-audit/independent-prefix-corrected-log-audit.js').read_text()
text = old[:old.index('    } else {\n        equal(plan.casesOrder')]

def change(first, second):
    global text
    assert text.count(first) == 1, first
    text = text.replace(first, second)

change('function parsePrefixLog(log)', 'function parsePriorStreakLog(log)')
change(r'(PREFIX_(?:CHILD_(?:RECEIPT|STATUS|PROGRESS)|SELECTOR_(?:PLAN|DIAGNOSTIC|OBSERVATION|RESULT|FAILED)|NEGATIVE_(?:PLAN|DIAGNOSTIC|OBSERVATION|CASE_RESULT|RESULT|FAILED)))', r'((?:PREFIX_(?:CHILD_(?:RECEIPT|STATUS|PROGRESS)|NEGATIVE_(?:PLAN|DIAGNOSTIC|OBSERVATION|RESULT|FAILED))|PRIOR_STREAK_SELECTOR_(?:PLAN|DIAGNOSTIC|OBSERVATION|RESULT|FAILED)))')
change('records.push({kind:match[1],value:JSON.parse(match[2])})', 'records.push({kind:match[1],value:JSON.parse(match[2]),line:index+1})')
change('function auditPrefixCorrectedLog(parsed,expected)', 'function auditPriorStreakCell(parsed,expected,artifactBinding=null)')
change('    check(plan.runtime?.browser===null,"Component scope has no browser");', '''    check(plan.runtime?.browser===null,"Component scope has no browser");
    check(/clang version 21\\.1\\.8/.test(plan.runtime?.compiler??""),"Pinned Clang21.1.8 receipt");
    check(/LLD 21\\.1\\.8/.test(plan.runtime?.linker??""),"Pinned LLD21.1.8 receipt");''')
change('negative?"PREFIX_NEGATIVE_":"PREFIX_SELECTOR_"', 'negative?"PREFIX_NEGATIVE_":"PRIOR_STREAK_SELECTOR_"')
change('check(negative || ["jmdict","vndb"].includes(plan.dictionary),"Corrected cohort contains only JMdict, VNDB and negative controls");', 'check(negative ? [1,2,3,4,5,6].includes(plan.caseId) : ["jmdict","jitendex","vndb"].includes(plan.dictionary),"Exact declared cell identity");')
change('    check(plan.candidate?.wasmSha256===expected.candidateWasm,"Candidate WASM unchanged from original cohort");\n    check(plan.candidate?.manifestSha256===expected.candidateManifest,"Candidate manifest unchanged from original cohort");', '''    check(plan.baseline?.manifestSha256===expected.baselineSourceHashes["dev/data/dictionary-wasm/manifest.json"],"Baseline generated manifest");
    let artifactBindingPass=null;
    if(artifactBinding!==null) {
        artifactBindingPass=artifactBinding.candidateC===expected.candidateC&&artifactBinding.candidateWasm===plan.candidate?.wasmSha256&&artifactBinding.candidateManifest===plan.candidate?.manifestSha256&&artifactBinding.originalArtifactAuditPassed===true;
        check(artifactBindingPass,"Separate original-artifact source and compiled binary binding");
    }''')
change('negative?/^negative-case-[123]-(?:baseline-verification|diagnostic|pair-[0-3]-[ABCD])$/:/^(?:diagnostic|pair-[0-3]-[ABCD])$/', 'negative?new RegExp("^negative-case-"+plan.caseId+"-(?:baseline-verification|diagnostic|pair-[0-3]-[ABCD])$"):/^(?:diagnostic|pair-[0-3]-[ABCD])$/')
change('    check(byLabel.size===receipts.length,"No duplicate child receipt labels");', '''    check(byLabel.size===receipts.length,"No duplicate child receipt labels");
    check(allReceipts.length===receipts.length&&allStatuses.length===statuses.length,"No unplanned child labels in the cell");
    check(statuses.length===receipts.length,"Every raw child receipt has one status and no orphan status");''')
change('        for(const path of [coreC,coreManifest,"ext/js/dictionary/term-bank-wasm-parser.js","package-lock.json"])check(path in (data.sourceHashes??{}),label+" mandatory source hash "+path);', '''        const expectedSourcePaths=Object.keys(expected.baselineSourceHashes).filter(path=>!negative||!["ext/js/dictionary/term-bank-source-pipeline.js","ext/js/dictionary/dense-zip-directory.js"].includes(path));
        equal(Object.keys(data.sourceHashes??{}).sort(),expectedSourcePaths.sort(),label+" complete exact source hash inventory");''')
change('const compact=get("PREFIX_SELECTOR_OBSERVATION"),diagnostics=get("PREFIX_SELECTOR_DIAGNOSTIC");', 'const compact=get("PRIOR_STREAK_SELECTOR_OBSERVATION"),diagnostics=get("PRIOR_STREAK_SELECTOR_DIAGNOSTIC");')
change('    const rawObservations=[],statistics={},mechanics={};', '''    function checkMechanics(c,label) {
        check(c&&typeof c==="object",label+" diagnostics present");
        if(!c)return;
        equal(Object.keys(c).sort(),[...expected.diagnosticFields].sort(),label+" exact 48-field diagnostic schema");
        for(const k of expected.diagnosticFields)check(Number.isSafeInteger(c[k])&&c[k]>=0,label+" nonnegative integer "+k);
        const sum=names=>names.reduce((s,k)=>s+c[k],0);
        check(c.admissions===c.noPrefixCandidate+c.selected,label+" admission partition");
        check(c.candidateRecordsInspected===sum(["definitionLengthRejected","rulesLengthRejected","definitionSignatureRejected","rulesSignatureRejected","selected"]),label+" header-stage partition");
        check(c.selected===sum(["boundsRejected","openerRejected","tailRejected","middleRejected","fullRejected","hits"]),label+" exact proof-stage partition");
        check(c.selected===sum([1,2,3,4].map(i=>"selectedDistance"+i)),label+" selection distance partition");
        check(c.hits===sum([1,2,3,4].map(i=>"hitDistance"+i)),label+" proof hit distance partition");
        check(c.fullBytesOffered===c.hitBytes+c.failedFullBytesOffered,label+" full comparison range partition");
        check(c.totalGlossaryReuses===c.originalGlossaryReuses+c.hits,label+" original/new witness partition");
        check(c.selected<=c.admissions&&c.admissions<=c.keyPredicateRows&&c.keyPredicateRows<=c.priorStreakLookbackZeroRows&&c.priorStreakLookbackZeroRows<=c.originalLookbackZeroRows,label+" prior-streak admission chain");
        check(c.admissions===c.expressionMatches+c.readingMatches,label+" read-only adjacent-key predicate matches");
        check(c.expressionMatches+c.readingMatches+c.readingIneligibleRows+c.readingAliasRejected<=c.keyPredicateRows,label+" key predicate disposition bound");
        check(c.keyComparisonCalls<=3*c.keyPredicateRows&&c.keyComparisonBytesOffered<=32*c.keyComparisonCalls&&c.maxKeyComparisonBytes<=32,label+" at most three bounded comparisons, 32 bytes per comparison");
        if(c.keyComparisonCalls===0)check(c.keyComparisonBytesOffered===0&&c.maxKeyComparisonBytes===0,label+" no comparison bytes without calls");
    }
    const rawObservations=[],statistics={},mechanics={};''')
change('        if(diagnostic) {\n            check(diagnostic.rows===fixture?.rows', '        if(diagnostic) {\n            checkMechanics(diagnostic.diagnostic,"Excluded dictionary diagnostic");\n            check(diagnostic.rows===fixture?.rows')
change('        equal(final?.mechanicalCounts,diagnostic?.diagnostic,"Final mechanics unchanged");', '''        equal(final?.mechanicalCounts,diagnostic?.diagnostic,"Final mechanics unchanged");
        if(dictionary==="jmdict") {
            const s=statistics[dictionary]["candidate.elapsedMs"],c=statistics[dictionary]["identicalControl.elapsedMs"];
            statistics[dictionary].prospectiveComponentAssessment={target:true,mechanicalGatePass:!!s&&!!c&&s.medianPairedChangePercent<=-1&&s.fasterPairs===4&&-s.medianPairedChangePercent>c.largestAbsoluteChangePercent,interpretation:"Component gate only; every negative/non-target and original-artifact correctness gate remains required. No browser/current-develop gain claim."};
        } else {
            const s=statistics[dictionary]["candidate.elapsedMs"],c=statistics[dictionary]["identicalControl.elapsedMs"];
            statistics[dictionary].prospectiveComponentAssessment={target:false,clearSlowdownRuleTriggered:!!s&&!!c&&s.medianPairedChangePercent>3&&s.slowerPairs===4&&s.medianPairedChangePercent>c.largestAbsoluteChangePercent,interpretation:"No automatic pass: inconclusive non-target observations remain uncertainty."};
        }''')

text += (Path(__file__).parent / 'negative-and-wrapper.js').read_text()
out = Path(__file__).parent / 'independent-prior-streak-log-audit.js'
out.write_text(text)
print(json.dumps({'path':str(out),'bytes':len(text.encode()),'sha256':hashlib.sha256(text.encode()).hexdigest()}))
