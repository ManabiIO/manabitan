// Artificial offline inputs only; this never imports or executes product code.
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const here=path.dirname(fileURLToPath(import.meta.url)),snapshot=path.join(here,'auditor-01e324');
const code=await readFile(path.join(snapshot,'independent-prior-streak-log-audit.js'),'utf8');
const expected=JSON.parse(await readFile(path.join(snapshot,'expected.json'),'utf8'));
const sha=x=>createHash('sha256').update(x).digest('hex');
const api=Function(code+'\nreturn {auditPriorStreakLog,parsePriorStreakLog};')();
const original=JSON.parse(await readFile(path.join(here,'artificial-original-fixture.json'),'utf8'));
const base=JSON.parse(await readFile(path.join(here,'artificial-feasible-fixture.json'),'utf8'));
const witnesses=JSON.parse(await readFile(path.join(here,'accepted-corruption-witnesses.json'),'utf8'));
const clone=x=>JSON.parse(JSON.stringify(x));
const positive=api.auditPriorStreakLog(base,expected);
assert(positive.allLogChecksPass&&positive.complete);
assert(positive.artifactBindingPass===null);
const checks=[];
for(const witness of witnesses.acceptedCorruptions){
  const fixture=clone(base);
  for(const edit of witness.edits){let target=fixture;for(const key of edit.path.slice(0,-1))target=target[key];const key=edit.path.at(-1);assert.deepEqual(target[key],edit.before);target[key]=edit.after;}
  assert.equal(sha(JSON.stringify(fixture)),witness.inputSha256);
  const result=api.auditPriorStreakLog(fixture,expected);
  assert(!result.allLogChecksPass,witness.name);
  checks.push({name:witness.name,exactPreservedInputSha256:witness.inputSha256,rejected:true,failedCells:result.cells.filter(c=>!c.allLogChecksPass).map(c=>({id:c.id,errors:c.errors}))});
}
const impossible=api.auditPriorStreakLog(original,expected);
assert(!impossible.allLogChecksPass);
assert(impossible.cells[0].errors.some(x=>x.includes('eligible helper disposition')));
const tagged=base.records.map(r=>'2026-11-28T00:00:00Z '+r.kind+' '+JSON.stringify(r.value)).join('\n');
const roundtrip=api.auditPriorStreakLog(api.parsePriorStreakLog(tagged),expected);
assert(roundtrip.allLogChecksPass);
const fail=clone(base),next=fail.records.findIndex(r=>r.kind==='PREFIX_NEGATIVE_PLAN'&&r.value.caseId===1);
fail.records.splice(next,0,{kind:'PRIOR_STREAK_SELECTOR_FAILED',value:{dictionary:'jmdict',error:'ARTIFICIAL retained failure witness'}});
const failed=api.auditPriorStreakLog(fail,expected);
assert(!failed.allLogChecksPass&&failed.cells[0].failures.length===1);
const incomplete=clone(base),stop=incomplete.records.findIndex(r=>r.kind==='PREFIX_CHILD_RECEIPT'&&r.value.label==='pair-1-D'&&r.value.result.dictionary==='vndb');
incomplete.records=incomplete.records.slice(0,stop);
const partial=api.auditPriorStreakLog(incomplete,expected);
assert(!partial.allLogChecksPass&&!partial.complete);
const output={scope:'Independent artificial postprocessor replay only; no actual candidate logs, native code, corpus/model execution, or measurements',status:'pass',auditorSha256:sha(code),expectedSha256:sha(await readFile(path.join(snapshot,'expected.json'))),positive:{allLogChecksPass:true,complete:true,cells:positive.cells.length,measuredChildren:positive.measuredObservationCount,rawChildReceipts:positive.cells.reduce((sum,c)=>sum+c.rawChildReceiptCount,0),artifactBindingPass:positive.artifactBindingPass},preservedCorruptions:checks,sourceImpossibleCostFixtureRejected:true,sourceImpossibleCostErrors:impossible.cells[0].errors.filter(x=>x.includes('eligible helper disposition')),taggedRoundtripPassed:true,failurePreservationPassed:true,incompletePreservationPassed:true};
await writeFile(path.join(here,'corrected-replay-review.json'),JSON.stringify(output,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({status:'pass',auditorSha256:output.auditorSha256,preservedCorruptionsRejected:checks.length,sourceImpossibleCostFixtureRejected:true,positive:output.positive,receiptSha256:sha(JSON.stringify(output,null,2)+'\n')}));
