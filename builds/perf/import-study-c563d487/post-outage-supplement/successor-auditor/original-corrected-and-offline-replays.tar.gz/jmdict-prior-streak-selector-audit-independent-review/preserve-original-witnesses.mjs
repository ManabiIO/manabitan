// Artificial offline audit witnesses only; no parser, corpus, native code, or measurements.
import assert from 'node:assert/strict';
import {readFile, writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const here=path.dirname(fileURLToPath(import.meta.url));
const old=path.join(here,'auditor-a933');
const code=await readFile(path.join(old,'independent-prior-streak-log-audit.js'),'utf8');
const fixtureCode=await readFile(path.join(old,'review-fixtures.js'),'utf8');
const expected=JSON.parse(await readFile(path.join(old,'expected.json'),'utf8'));
const sha=s=>createHash('sha256').update(s).digest('hex');
const clone=x=>JSON.parse(JSON.stringify(x));
const api=Function(code+'\n'+fixtureCode+'\nreturn {makePriorStreakAuditFixture,auditPriorStreakLog};')();
const original=api.makePriorStreakAuditFixture(expected);
const originalAudit=api.auditPriorStreakLog(original,expected);
assert(originalAudit.allLogChecksPass);
const diagnosticIndex=original.records.findIndex(r=>r.kind==='PREFIX_CHILD_RECEIPT'&&r.value.label==='diagnostic'&&r.value.result.dictionary==='jmdict');
const impossible=original.records[diagnosticIndex].value.result.diagnostic;
assert(impossible.keyComparisonCalls < impossible.keyPredicateRows-impossible.readingIneligibleRows);
// Make only artificial unknown helper fields feasible before independent label/chain mutations.
const base=clone(original),diag=base.records[diagnosticIndex].value.result;
const fields=['readingIneligibleRows','readingAliasRejected','keyComparisonCalls','keyComparisonBytesOffered','maxKeyComparisonBytes'];
const cumulative=Object.fromEntries(fields.map(k=>[k,0]));
for(const g of diag.groupReceipts){
  const helpers=g.diagnosticAfter.keyPredicateRows-g.diagnosticBefore.keyPredicateRows;
  const admissions=g.diagnosticAfter.admissions-g.diagnosticBefore.admissions;
  for(const k of fields)g.diagnosticBefore[k]=cumulative[k];
  cumulative.readingIneligibleRows+=helpers-admissions;
  cumulative.keyComparisonCalls+=admissions;
  cumulative.keyComparisonBytesOffered+=4*admissions;
  if(admissions)cumulative.maxKeyComparisonBytes=4;
  for(const k of fields)g.diagnosticAfter[k]=cumulative[k];
}
Object.assign(diag.diagnostic,cumulative);
for(const r of base.records){
  if(r.value.dictionary==='jmdict'&&['PRIOR_STREAK_SELECTOR_DIAGNOSTIC','PRIOR_STREAK_SELECTOR_RESULT'].includes(r.kind))Object.assign(r.value.mechanicalCounts,cumulative);
}
const baseline=api.auditPriorStreakLog(base,expected);
assert(baseline.allLogChecksPass);
const edits=[];
const apply=(value,parts,after)=>{let target=value;for(const p of parts.slice(0,-1))target=target[p];const key=parts.at(-1);edits.push({path:parts,before:clone(target[key]),after:clone(after)});target[key]=after;};
const locate=(f,kind,predicate)=>f.records.findIndex(r=>r.kind===kind&&predicate(r.value));
const cases=[
 ['diagnostic cumulative group chain',f=>{
   for(const side of ['diagnosticBefore','diagnosticAfter']){
     const parts=['records',diagnosticIndex,'value','result','groupReceipts',3,side,'originalLookbackZeroRows'];
     apply(f,parts,f.records[diagnosticIndex].value.result.groupReceipts[3][side].originalLookbackZeroRows+7);
   }
 }],
 ['raw child dictionary identity',f=>{const i=locate(f,'PREFIX_CHILD_RECEIPT',r=>r.label==='pair-0-A'&&r.result.dictionary==='jmdict');apply(f,['records',i,'value','result','dictionary'],'vndb');}],
 ['compact observation dictionary identity',f=>{const i=locate(f,'PRIOR_STREAK_SELECTOR_OBSERVATION',r=>r.dictionary==='jmdict'&&r.pair===0&&r.arm==='A');apply(f,['records',i,'value','dictionary'],'vndb');}],
 ['compact diagnostic identity and output',f=>{const i=locate(f,'PRIOR_STREAK_SELECTOR_DIAGNOSTIC',r=>r.dictionary==='jmdict');for(const [k,v]of [['dictionary','vndb'],['rows',1],['digest','0'.repeat(64)]])apply(f,['records',i,'value',k],v);}],
 ['final dictionary identity and output',f=>{const i=locate(f,'PRIOR_STREAK_SELECTOR_RESULT',r=>r.dictionary==='jmdict');for(const [k,v]of [['dictionary','vndb'],['rows',1],['digest','0'.repeat(64)]])apply(f,['records',i,'value',k],v);}]
];
const witnesses=[];
for(const [name,mutate]of cases){
  edits.length=0;const value=clone(base);mutate(value);
  const audit=api.auditPriorStreakLog(value,expected);
  assert(audit.allLogChecksPass,name+' was expected to demonstrate the frozen auditor gap');
  witnesses.push({name,inputSha256:sha(JSON.stringify(value)),edits:clone(edits),acceptedByOriginalAuditor:true,errors:audit.errors,artifactBindingPass:audit.artifactBindingPass});
}
const failed=clone(base),next=locate(failed,'PREFIX_NEGATIVE_PLAN',r=>r.caseId===1);
failed.records.splice(next,0,{kind:'PRIOR_STREAK_SELECTOR_FAILED',value:{dictionary:'jmdict',error:'ARTIFICIAL retained failure witness'}});
const failedAudit=api.auditPriorStreakLog(failed,expected);
assert(!failedAudit.allLogChecksPass&&failedAudit.cells[0].failures.length===1);
const incomplete=clone(base);
const stop=locate(incomplete,'PREFIX_CHILD_RECEIPT',r=>r.label==='pair-1-D'&&r.result.dictionary==='vndb');
incomplete.records=incomplete.records.slice(0,stop);
const incompleteAudit=api.auditPriorStreakLog(incomplete,expected);
assert(!incompleteAudit.allLogChecksPass&&!incompleteAudit.complete);
assert(baseline.artifactBindingPass===null);
const originalText=JSON.stringify(original),baseText=JSON.stringify(base);
await writeFile(path.join(here,'artificial-original-fixture.json'),originalText+'\n',{flag:'wx'});
await writeFile(path.join(here,'artificial-feasible-fixture.json'),baseText+'\n',{flag:'wx'});
const output={scope:'Artificial offline auditor review only; no actual candidate data, parser/corpus/native execution, or new measurements',auditorSha256:sha(code),expectedSha256:sha(await readFile(path.join(old,'expected.json'))),fixtureCodeSha256:sha(fixtureCode),originalFixtureSha256:sha(originalText+'\n'),feasibleFixtureSha256:sha(baseText+'\n'),originalPositiveAccepted:true,feasiblePositiveAccepted:true,sourceImpossibleKeyCostWitness:{acceptedByOriginalAuditor:true,keyPredicateRows:impossible.keyPredicateRows,readingIneligibleRows:impossible.readingIneligibleRows,keyComparisonCalls:impossible.keyComparisonCalls,admissions:impossible.admissions,requiredLowerBound:'keyComparisonCalls >= keyPredicateRows - readingIneligibleRows'},acceptedCorruptions:witnesses,failureRetained:{allLogChecksPass:failedAudit.allLogChecksPass,failures:failedAudit.cells[0].failures},incompleteRetained:{complete:incompleteAudit.complete,allLogChecksPass:incompleteAudit.allLogChecksPass,measuredObservationCount:incompleteAudit.measuredObservationCount},artifactBindingStillNull:baseline.artifactBindingPass===null};
await writeFile(path.join(here,'accepted-corruption-witnesses.json'),JSON.stringify(output,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({auditorSha256:output.auditorSha256,acceptedCorruptionCases:witnesses.length,sourceImpossibleKeyCostWitness:output.sourceImpossibleKeyCostWitness,failureRetained:true,incompleteRetained:true,artifactBindingStillNull:true,witnessReceiptSha256:sha(JSON.stringify(output,null,2)+'\n')}));
