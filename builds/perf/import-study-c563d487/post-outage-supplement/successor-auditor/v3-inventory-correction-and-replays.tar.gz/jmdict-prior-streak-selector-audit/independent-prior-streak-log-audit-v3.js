/* Independent audit of frozen component logs; never executes product or timing code. */
function prefixStable(value) {
    if (Array.isArray(value)) return value.map(prefixStable);
    if (value && typeof value === "object") return Object.fromEntries(Object.keys(value).sort().map(k=>[k,prefixStable(value[k])]));
    return value;
}
function prefixEqual(a,b) { return JSON.stringify(prefixStable(a))===JSON.stringify(prefixStable(b)); }
function prefixMedian(values) { const s=[...values].sort((a,b)=>a-b),m=s.length>>1; return s.length%2?s[m]:(s[m-1]+s[m])/2; }
function prefixStats(first,second) {
    const changes=first.map((x,i)=>100*(second[i]/x-1));
    return {firstValues:first,secondValues:second,pairedChangesPercent:changes,medianPairedChangePercent:prefixMedian(changes),
        equalWorkChangePercent:100*(second.reduce((a,b)=>a+b,0)/first.reduce((a,b)=>a+b,0)-1),
        fasterPairs:changes.filter(x=>x<0).length,slowerPairs:changes.filter(x=>x>0).length,
        minimumChangePercent:Math.min(...changes),maximumChangePercent:Math.max(...changes),largestAbsoluteChangePercent:Math.max(...changes.map(Math.abs))};
}
function parsePriorStreakLog(log) {
    const records=[],parseErrors=[];
    for(const [index,line] of log.split("\n").entries()) {
        const match=/\b((?:PREFIX_(?:CHILD_(?:RECEIPT|STATUS|PROGRESS)|NEGATIVE_(?:PLAN|DIAGNOSTIC|OBSERVATION|RESULT|FAILED))|PRIOR_STREAK_SELECTOR_(?:PLAN|DIAGNOSTIC|OBSERVATION|RESULT|FAILED))) (\{.*\})\s*$/.exec(line);
        if(!match)continue;
        try{records.push({kind:match[1],value:JSON.parse(match[2]),line:index+1});}catch(error){parseErrors.push({line:index+1,kind:match[1],error:String(error)});}
    }
    return {records,parseErrors};
}
function auditPriorStreakCell(parsed,expected,artifactBinding=null) {
    const records=parsed.records??parsed,errors=[...(parsed.parseErrors??[]).map(x=>"JSON parse error: "+JSON.stringify(x))];
    const check=(condition,label)=>{if(!condition)errors.push(label);};
    const equal=(a,b,label)=>check(prefixEqual(a,b),label);
    const finite=(n)=>typeof n==="number"&&Number.isFinite(n);
    const hash=(s)=>typeof s==="string"&&/^[a-f0-9]{64}$/.test(s);
    const near=(a,b)=>finite(a)&&finite(b)&&Math.abs(a-b)<=1e-9*Math.max(1,Math.abs(a),Math.abs(b));
    const get=(kind)=>records.filter(r=>r.kind===kind).map(r=>r.value);
    const negative=get("PREFIX_NEGATIVE_PLAN").length>0;
    const family=negative?"PREFIX_NEGATIVE_":"PRIOR_STREAK_SELECTOR_";
    const plans=get(family+"PLAN"),finals=get(family+"RESULT"),failures=get(family+"FAILED");
    check(plans.length===1,"Exactly one acquisition plan");check(finals.length===1,"Exactly one completed result");
    check(failures.length===0,"Acquisition failure retained");
    if(plans.length!==1)return {complete:false,errors,failures,records:records.length,scope:"No source-bound acquisition plan; inspect retained setup/failure logs"};
    const plan=plans[0],final=finals[0],schedule=[];
    check(negative ? [1,2,3,4,5,6].includes(plan.caseId) : ["jmdict","jitendex","vndb"].includes(plan.dictionary),"Exact declared cell identity");
    for(let pair=0;pair<4;pair++)for(const arm of (pair%2?"DCBA":"ABCD"))schedule.push({pair,arm});
    equal(negative?plan.schedulePerCase:plan.schedule,schedule,"Frozen 4-pair ABCD/DCBA schedule");
    equal(plan.tooling?.hashes,expected.toolingHashes,"Exact frozen observer file hashes");
    check(plan.tooling?.head===expected.toolingHead,"Tooling commit");
    check(plan.tooling?.fixtureLockSha256===expected.fixtureLockSha256,"Tooling fixture lock");
    check(plan.runtime?.node===expected.node,"Pinned Node runtime");
    check(plan.runtime?.browser===null,"Component scope has no browser");
    check(/clang version 21\.1\.8/.test(plan.runtime?.compiler??""),"Pinned Clang21.1.8 receipt");
    check(/LLD 21\.1\.8/.test(plan.runtime?.linker??""),"Pinned LLD21.1.8 receipt");
    const identities={A:plan.baseline,B:plan.candidate,C:plan.baseline,D:plan.baseline};
    for(const [arm,id] of [["A",plan.baseline],["B",plan.candidate]]) {
        check(id?.head===expected.baseline&&id?.tree===expected.baselineTree,arm+" frozen base worktree");
        check(id?.cSha256===(arm==="A"?expected.baselineC:expected.candidateC),arm+" frozen C source");
        check(id?.dependencyLockSha256===expected.dependencyLockSha256,arm+" dependency lock");
        check(hash(id?.wasmSha256)&&id?.trackedWasmSha256===id?.wasmSha256,arm+" tracked/runtime WASM equality");
        check(hash(id?.manifestSha256),arm+" generated manifest identity");
    }
    check(plan.baseline?.wasmSha256===expected.baselineWasm,"Baseline WASM");
    check(plan.candidate?.wasmSha256!==expected.baselineWasm,"Candidate generated WASM differs");
    check(plan.baseline?.manifestSha256===expected.baselineSourceHashes["dev/data/dictionary-wasm/manifest.json"],"Baseline generated manifest");
    let artifactBindingPass=null;
    if(artifactBinding!==null) {
        artifactBindingPass=artifactBinding.candidateC===expected.candidateC&&artifactBinding.candidateWasm===plan.candidate?.wasmSha256&&artifactBinding.candidateManifest===plan.candidate?.manifestSha256&&artifactBinding.originalArtifactAuditPassed===true;
        check(artifactBindingPass,"Separate original-artifact source and compiled binary binding");
    }
    check(plan.baseline?.trackedChanges==="","Baseline clean");
    const changed=(plan.candidate?.trackedChanges??"").split("\n").filter(Boolean).map(x=>x.trim().split(/\s+/).slice(1).join(" ")).sort();
    equal(changed,["dev/data/dictionary-wasm/manifest.json","dev/data/dictionary-wasm/term-bank-parser.wasm","ext/js/dictionary/wasm/term-bank-parser.c"],"Exact intentional candidate component overlay");
    const allReceipts=get("PREFIX_CHILD_RECEIPT"),allStatuses=get("PREFIX_CHILD_STATUS");
    const selectedLabels=negative?new RegExp("^negative-case-"+plan.caseId+"-(?:baseline-verification|diagnostic|pair-[0-3]-[ABCD])$"):/^(?:diagnostic|pair-[0-3]-[ABCD])$/;
    const receipts=allReceipts.filter(r=>selectedLabels.test(r.label)),statuses=allStatuses.filter(r=>selectedLabels.test(r.label));
    const byLabel=new Map(receipts.map(r=>[r.label,r]));
    check(byLabel.size===receipts.length,"No duplicate child receipt labels");
    check(allReceipts.length===receipts.length&&allStatuses.length===statuses.length,"No unplanned child labels in the cell");
    check(statuses.length===receipts.length,"Every raw child receipt has one status and no orphan status");
    const coreC="ext/js/dictionary/wasm/term-bank-parser.c",coreManifest="dev/data/dictionary-wasm/manifest.json";
    function child(label,arm,diagnostic=false,verification=false) {
        const receipt=byLabel.get(label),data=receipt?.result,id=identities[arm];
        check(!!data,label+" raw child receipt");
        const status=statuses.filter(s=>s.label===label);
        check(status.length===1&&status[0].status==="completed"&&status[0].exitCode===0,label+" successful child status");
        if(!data)return null;
        equal(receipt.command,status[0]?.command,label+" command identity");
        check(receipt.startedEpoch===status[0]?.startedEpoch&&receipt.finishedEpoch===status[0]?.finishedEpoch,label+" status timestamps");
        check(receipt.finishedEpoch>=receipt.startedEpoch,label+" completed timestamp order");
        check(data.sourceRoot===id.root&&data.gitHead===id.head&&data.gitTree===id.tree,label+" selected source root/commit/tree");
        check(data.trackedChanges===id.trackedChanges,label+" tracked overlay identity");
        check(data.node===expected.node,label+" Node version");
        if(!negative)check(data.dictionary===plan.dictionary,label+" raw child dictionary identity");
        check(data.validateGlossaryTypes===true,label+" strict glossary workload");
        equal(data.flags,negative?{}:(plan.dictionary==="vndb"?{experimentalNativeEscapedKeys:true}:{}),label+" frozen flags");
        check(data.runnerSha256===expected.toolingHashes[negative?"negative-screen.mjs":"screen.mjs"],label+" runner hash");
        check(data.diagnosticFieldsSha256===expected.toolingHashes["diagnostic-fields.json"],label+" diagnostic schema hash");
        check(hash(data.digest),label+" output digest");
        check(hash(data.wasmSha256),label+" WASM identity format");
        if(diagnostic)check(data.diagnosticWasm!==null&&data.wasmSha256!==id.wasmSha256&&!!data.diagnostic,label+" separate diagnostic artifact");
        else check(data.diagnosticWasm===null&&data.wasmSha256===id.wasmSha256&&data.diagnostic===null,label+" uninstrumented timing artifact");
        const expectedSourcePaths=Object.keys(expected.baselineSourceHashes).filter(path=>negative?!["ext/js/dictionary/term-bank-source-pipeline.js","ext/js/dictionary/dense-zip-directory.js"].includes(path):path!=="ext/js/dictionary/term-bank-source-crc.js");
        equal(Object.keys(data.sourceHashes??{}).sort(),expectedSourcePaths.sort(),label+" complete exact source hash inventory");
        for(const [path,digest]of Object.entries(data.sourceHashes??{})) {
            const wanted=path===coreC?id.cSha256:path===coreManifest?id.manifestSha256:expected.baselineSourceHashes[path];
            check(!!wanted&&digest===wanted,label+" exact source hash "+path);
        }
        check(data.warmupPasses===(diagnostic||verification?0:2),label+" excluded warmup count");
        for(const key of ["elapsedMs","cpuMs","inflateMs","inflateCpuMs","parseMs","lookupMs","nativeParseMs","rows","indexBytes"])check(finite(data[key])&&data[key]>=0,label+" finite nonnegative "+key);
        return data;
    }
    function summarize(observations,reported,label) {
        const statistics={};
        for(const metric of ["elapsedMs","cpuMs","parseMs","nativeParseMs","lookupMs"])for(const [kind,a,b]of [["candidate","A","B"],["identicalControl","C","D"]]) {
            const first=[],second=[];
            for(let pair=0;pair<4;pair++) {
                const x=observations.find(o=>o.pair===pair&&o.arm===a)?.result?.[metric];
                const y=observations.find(o=>o.pair===pair&&o.arm===b)?.result?.[metric];
                check(finite(x)&&x>0&&finite(y)&&y>0,label+" positive paired "+metric);
                first.push(x);second.push(y);
            }
            if(first.some(x=>!finite(x))||second.some(x=>!finite(x)))continue;
            const name=kind+"."+metric,s=prefixStats(first,second);statistics[name]=s;
            const published=reported?.[name];
            check(!!published,label+" reported "+name);
            for(const key of ["medianPairedChangePercent","equalWorkChangePercent","fasterPairs"])check(near(s[key],published?.[key]),label+" independently reconstructed "+name+" "+key);
            check(s.pairedChangesPercent.every((x,i)=>near(x,published?.pairedChangesPercent?.[i])),label+" independently reconstructed "+name+" raw pair changes");
        }
        return statistics;
    }
    function verifyDictionaryGroupRoutes(data,label,diagnostic=false) {
        const groups=data.groupReceipts;
        check(Array.isArray(groups)&&groups.length>0,label+" group inventory");
        if(!Array.isArray(groups))return;
        let expectedAttempts=0,expectedDiagnosticRows=0;
        for(const [index,group]of groups.entries()) {
            const bankCount=group.banks?.length;
            if(diagnostic) {
                if(index===0)check(group.diagnosticBefore===null||prefixEqual(group.diagnosticBefore,Object.fromEntries(expected.diagnosticFields.map(k=>[k,0]))),label+" initial counters absent before lazy instance or exactly zero");
                else equal(group.diagnosticBefore,groups[index-1].diagnosticAfter,label+" cumulative diagnostic chain "+index);
                checkMechanics(group.diagnosticAfter,label+" cumulative diagnostic group "+index);
            }
            check(group.group===index&&Number.isSafeInteger(bankCount)&&bankCount>0&&bankCount<=data.filesPerGroup,label+" fixed group bank count/index "+index);
            if(index<groups.length-1)check(bankCount===data.filesPerGroup,label+" full nonfinal group "+index);
            const expectedAttempt=bankCount>1?1:0;
            check(group.fusedAttempts===expectedAttempt&&group.fusedFallbacks===0,label+" explicit per-group fused/normal route "+index);
            expectedAttempts+=expectedAttempt;
            if(expectedAttempt)expectedDiagnosticRows+=group.rows;
            else {
                check(group.glossaryReuseCount===0&&group.recentContentDedupHitCount===0,label+" singleton normal-route counters "+index);
                if(diagnostic)equal(group.diagnosticBefore,group.diagnosticAfter,label+" singleton leaves fused diagnostic counters unchanged "+index);
            }
        }
        check(data.fusedAttempts===expectedAttempts&&data.fusedFallbacks===0,label+" exact aggregate route counts");
        if(diagnostic) {
            check(data.diagnostic?.rows===expectedDiagnosticRows,label+" fused diagnostic row domain");
            equal(data.diagnostic,groups[groups.length-1]?.diagnosticAfter,label+" final counters equal last completed group");
        }
    }
    function checkMechanics(c,label) {
        check(c&&typeof c==="object",label+" diagnostics present");
        if(!c)return;
        equal(Object.keys(c).sort(),[...expected.diagnosticFields].sort(),label+" exact 48-field diagnostic schema");
        for(const k of expected.diagnosticFields)check(Number.isSafeInteger(c[k])&&c[k]>=0,label+" nonnegative integer "+k);
        const sum=names=>names.reduce((s,k)=>s+c[k],0);
        check(c.admissions===c.noPrefixCandidate+c.selected,label+" admission partition");
        check(c.candidateRecordsInspected===sum(["definitionLengthRejected","rulesLengthRejected","definitionSignatureRejected","rulesSignatureRejected","selected"]),label+" header-stage partition");
        check(c.selected===sum(["boundsRejected","openerRejected","tailRejected","middleRejected","fullRejected","hits"]),label+" exact proof-stage partition");
        check(c.selected===sum([1,2,3,4].map(i=>"selectedDistance"+i)),label+" selection distance partition");
        check(c.hits===sum([1,2,3,4].map(i=>"hitDistance"+i)),label+" proof hit distance partition");
        check(c.fullBytesOffered===c.hitBytes+c.failedFullBytesOffered,label+" full comparison range partition");
        check(c.totalGlossaryReuses===c.originalGlossaryReuses+c.hits,label+" original/new witness partition");
        check(c.selected<=c.admissions&&c.admissions<=c.keyPredicateRows&&c.keyPredicateRows<=c.priorStreakLookbackZeroRows&&c.priorStreakLookbackZeroRows<=c.originalLookbackZeroRows,label+" prior-streak admission chain");
        check(c.admissions===c.expressionMatches+c.readingMatches,label+" read-only adjacent-key predicate matches");
        check(c.expressionMatches+c.readingMatches+c.readingIneligibleRows+c.readingAliasRejected<=c.keyPredicateRows,label+" key predicate disposition bound");
        check(c.keyComparisonCalls>=c.keyPredicateRows-c.readingIneligibleRows,label+" every eligible helper disposition performs a counted equality comparison");
        check(c.keyComparisonCalls<=3*c.keyPredicateRows&&c.keyComparisonBytesOffered<=32*c.keyComparisonCalls&&c.maxKeyComparisonBytes<=32,label+" at most three bounded comparisons, 32 bytes per comparison");
        if(c.keyComparisonCalls===0)check(c.keyComparisonBytesOffered===0&&c.maxKeyComparisonBytes===0,label+" no comparison bytes without calls");
    }
    const rawObservations=[],statistics={},mechanics={};
    if(!negative) {
        const dictionary=plan.dictionary,fixture=expected.fixtures[dictionary];
        check(!!fixture,"Known locked corpus");
        const compact=get("PRIOR_STREAK_SELECTOR_OBSERVATION"),diagnostics=get("PRIOR_STREAK_SELECTOR_DIAGNOSTIC");
        equal(compact.map(({pair,arm})=>({pair,arm})),schedule,"Raw observed dictionary schedule");
        check(compact.every(row=>row.dictionary===dictionary),"Every compact observation dictionary matches the plan");
        equal(receipts.map(r=>r.label),["diagnostic",...schedule.map(s=>"pair-"+s.pair+"-"+s.arm)],"Raw dictionary child order including excluded diagnostic");
        const diagnostic=child("diagnostic","B",true);
        if(diagnostic) {
            checkMechanics(diagnostic.diagnostic,"Excluded dictionary diagnostic");
            check(diagnostic.rows===fixture?.rows&&diagnostic.archiveSha256===fixture?.sha256,"Diagnostic locked corpus");
            check(diagnostic.lockSha256===expected.fixtureLockSha256,"Diagnostic fixture lock");
            check(diagnostic.filesPerGroup==={jmdict:7,jitendex:10,vndb:4}[dictionary],"Frozen component grouping");
            verifyDictionaryGroupRoutes(diagnostic,"Excluded dictionary diagnostic",true);
            check(diagnostics.length===1,"Single diagnostic mechanics report");
            equal(diagnostic.diagnostic,diagnostics[0]?.mechanicalCounts,"Full and compact diagnostic counts");
            check(diagnostics[0]?.dictionary===dictionary&&diagnostics[0]?.rows===diagnostic.rows&&diagnostics[0]?.digest===diagnostic.digest,"Compact diagnostic workload identity/rows/digest");
            mechanics[dictionary]=diagnostic.diagnostic;
            if(dictionary==="jmdict") {
                equal(plan.expectedMechanics,expected.mechanics,"Independent frozen JMdict mechanics registration");
                for(const [key,value]of Object.entries(expected.mechanics.jmdict.total))check(diagnostic.diagnostic?.[key]===value,"Independent JMdict mechanics "+key);
                check(diagnostic.groupReceipts?.length===expected.mechanics.jmdict.groups.length,"Independent JMdict group count");
                for(const [i,wanted]of expected.mechanics.jmdict.groups.entries()) {
                    const actual=diagnostic.groupReceipts?.[i],before=actual?.diagnosticBefore??{},after=actual?.diagnosticAfter??{};
                    check(actual?.group===wanted.group,"Independent JMdict diagnostic group "+i);
                    for(const [key,value]of Object.entries(wanted.expected))check(after[key]===(key.startsWith("max")?Math.max(before[key]??0,value):(before[key]??0)+value),"Independent JMdict group "+i+" "+key);
                }
            }
        }
        for(const step of schedule) {
            const label="pair-"+step.pair+"-"+step.arm,data=child(label,step.arm);
            if(!data)continue;
            rawObservations.push({...step,result:data});
            const short=compact.find(r=>r.pair===step.pair&&r.arm===step.arm);
            for(const [key,value]of Object.entries(short??{}))if(!["dictionary","pair","arm"].includes(key))equal(data[key],value,label+" compact/raw "+key);
            if(!diagnostic)continue;
            for(const key of ["rows","digest","indexBytes","archiveSha256","lockSha256","flags","filesPerGroup","recentContentDedupHitCount"])equal(data[key],diagnostic[key],label+" equal work/output "+key);
            const reuseKey=step.arm==="B"?"totalGlossaryReuses":"originalGlossaryReuses";
            check(data.glossaryReuseCount===diagnostic.diagnostic[reuseKey],label+" predicted glossary reuse");
            verifyDictionaryGroupRoutes(data,label);
            check(data.groupReceipts?.length===diagnostic.groupReceipts.length,label+" complete group count");
            for(const key of ["rows","fusedAttempts","fusedFallbacks","glossaryReuseCount","recentContentDedupHitCount"])check(data[key]===data.groupReceipts.reduce((s,g)=>s+g[key],0),label+" group sum "+key);
            for(const [i,group]of data.groupReceipts.entries()) {
                const reference=diagnostic.groupReceipts[i];
                for(const key of ["group","banks","rows","fusedAttempts","fusedFallbacks","recentContentDedupHitCount"])equal(group[key],reference[key],label+" group "+i+" "+key);
                check(group.glossaryReuseCount===reference.diagnosticAfter[reuseKey]-(reference.diagnosticBefore?.[reuseKey]??0),label+" group reuse delta "+i);
            }
        }
        check(rawObservations.length===16,"All 16 dictionary measurements retained");
        statistics[dictionary]=summarize(rawObservations,final?.summary,dictionary);
        check(final?.complete===true,"Dictionary acquisition complete");
        equal(final?.mechanicalCounts,diagnostic?.diagnostic,"Final mechanics unchanged");
        check(final?.dictionary===dictionary&&final?.rows===diagnostic?.rows&&final?.digest===diagnostic?.digest,"Final compact workload identity/rows/digest");
        if(dictionary==="jmdict") {
            const s=statistics[dictionary]["candidate.elapsedMs"],c=statistics[dictionary]["identicalControl.elapsedMs"];
            statistics[dictionary].prospectiveComponentAssessment={target:true,mechanicalGatePass:!!s&&!!c&&s.medianPairedChangePercent<=-1&&s.fasterPairs===4&&-s.medianPairedChangePercent>c.largestAbsoluteChangePercent,interpretation:"Component gate only; every negative/non-target and original-artifact correctness gate remains required. No browser/current-develop gain claim."};
        } else {
            const s=statistics[dictionary]["candidate.elapsedMs"],c=statistics[dictionary]["identicalControl.elapsedMs"];
            statistics[dictionary].prospectiveComponentAssessment={target:false,clearSlowdownRuleTriggered:!!s&&!!c&&s.medianPairedChangePercent>3&&s.slowerPairs===4&&s.medianPairedChangePercent>c.largestAbsoluteChangePercent,interpretation:"No automatic pass: inconclusive non-target observations remain uncertainty."};
        }
    } else {
        const caseId=plan.caseId,prefix="negative-case-"+caseId+"-";
        equal(plan.studyCasesOrder,[1,2,3,4,5,6],"Frozen six synthetic case order");
        check(plan.measuredObservationCount===16,"Frozen sixteen negative children in this cell");
        equal(plan.prospectiveProtocol,expected.negativeProtocol,"Exact prospective negative protocol");
        equal(plan.fixtureManifest,expected.negativeManifest,"Exact independently generated fixture manifest");
        check(plan.fixtureManifestSha256===expected.negativeManifestSha256,"Frozen complete fixture-manifest byte hash");
        const fixture=expected.negativeManifest.cases.find(x=>x.id===caseId);
        const target=expected.negativeExpected.cases.find(x=>x.id===caseId);
        check(!!fixture&&!!target,"Known synthetic fixture");
        const compact=get("PREFIX_NEGATIVE_OBSERVATION"),diagnostics=get("PREFIX_NEGATIVE_DIAGNOSTIC");
        equal(compact.map(({caseId,pair,arm})=>({caseId,pair,arm})),schedule.map(s=>({caseId,...s})),"Complete fixed observed case schedule");
        equal(receipts.map(r=>r.label),[prefix+"baseline-verification",prefix+"diagnostic",...schedule.map(s=>prefix+"pair-"+s.pair+"-"+s.arm)],"All eighteen raw negative children including two excluded preflights in exact order");
        const baseline=child(prefix+"baseline-verification","A",false,true),diagnostic=child(prefix+"diagnostic","B",true);
        const perPassBytes=fixture.banks.reduce((s,b)=>s+b.uncompressedSize,0);
        for(const key of ["expectedUniqueCount","expectedMechanics","expectedPublic","expectedShadow"])equal(fixture[key],target[key],"Independent fixture static expectation "+key);
        function verify(data,label,excluded) {
            if(!data)return;
            check(data.complete===true&&data.caseId===caseId,label+" successful exact case identity");
            check(data.excludedOnly===excluded&&data.measuredRepetitions===(excluded?0:16),label+" measured/excluded role");
            check(data.repetitions?.length===(excluded?1:16)&&data.warmups?.length===(excluded?0:2),label+" every per-pass receipt retained");
            equal(data.bankIdentities,fixture.banks,label+" exact raw/compressed/CRC bank identities");
            check(data.fixtureManifestSha256===expected.negativeManifestSha256,label+" exact fixture-manifest hash");
            check(data.generatorSha256===expected.toolingHashes["negative-fixtures.mjs"]&&data.outputDigestSha256===expected.toolingHashes["output-digest.mjs"],label+" generator and output-digest observer identities");
            check(data.perPassRows===20000&&data.perPassUniqueCount===target.expectedUniqueCount,label+" full rows and unique work");
            for(const key of ["elapsedMs","cpuMs","inflateMs","inflateCpuMs","parseMs","lookupMs","nativeParseMs","rows","indexBytes"]){
                check(data.repetitions.every(r=>finite(r[key])),label+" every repetition has finite numeric "+key);
                check(data[key]===data.repetitions.reduce((s,r)=>s+r[key],0),label+" exact sequential binary64 repetition sum "+key);
            }
            for(const [kind,passes]of [["warmup",data.warmups],["measured",data.repetitions]])for(const [i,pass]of passes.entries()) {
                check(pass.repetition===i,label+" "+kind+" fixed repetition index");
                if(kind==="warmup")check(pass.excluded===true,label+" warmup excluded");
                check(pass.rows===20000&&pass.uniqueCount===target.expectedUniqueCount,label+" "+kind+" full rows/unique count "+i);
                for(const [key,value]of Object.entries(target.expectedPublic))check(pass[key]===value,label+" "+kind+" exact public work "+key+" "+i);
                check(pass.crcReusedBytes===0&&pass.crcVerifiedBytes===perPassBytes,label+" complete uncached CRC byte work "+i);
                check(pass.digest===baseline?.digest&&pass.indexBytes===baseline?.perPassIndexBytes,label+" full rich output/index parity "+i);
                for(const metric of ["elapsedMs","cpuMs","inflateMs","inflateCpuMs","parseMs","lookupMs","nativeParseMs"])check(finite(pass[metric])&&pass[metric]>=0,label+" "+kind+" finite nonnegative "+metric+" "+i);
            }
            equal(data.digest,baseline?.digest,label+" baseline rich digest");
            equal(data.perPassIndexBytes,baseline?.perPassIndexBytes,label+" baseline index byte count");
        }
        verify(baseline,prefix+"baseline-verification",true);verify(diagnostic,prefix+"diagnostic",true);
        if(diagnostic) {
            checkMechanics(diagnostic.diagnostic,"Excluded case"+caseId+" diagnostic");
            mechanics[caseId]=diagnostic.diagnostic;
            equal(diagnostic.diagnostic,target.expectedMechanics,"All forty-eight independent static mechanical expectations");
            check(diagnostic.wasmSha256===plan.diagnosticWasmSha256,"Plan-bound external diagnostic binary");
            check(diagnostics.length===1&&diagnostics[0]?.caseId===caseId,"Single correct compact diagnostic");
            equal(diagnostics[0]?.counts,diagnostic.diagnostic,"Compact/raw mechanics");
        }
        for(const step of schedule) {
            const label=prefix+"pair-"+step.pair+"-"+step.arm,data=child(label,step.arm);
            verify(data,label,false);if(!data)continue;
            rawObservations.push({caseId,...step,result:data});
            const short=compact.find(x=>x.caseId===caseId&&x.pair===step.pair&&x.arm===step.arm);
            for(const [key,value]of Object.entries(short??{}))if(!["caseId","pair","arm"].includes(key))equal(data[key],value,label+" compact/raw "+key);
        }
        check(rawObservations.length===16,"All sixteen measured child sums retained");
        const stats=summarize(rawObservations,final?.summary,"Case "+caseId);statistics[caseId]=stats;
        const candidate=stats["candidate.elapsedMs"],control=stats["identicalControl.elapsedMs"];
        const triggered=!!candidate&&!!control&&candidate.medianPairedChangePercent>3&&candidate.slowerPairs===4&&candidate.medianPairedChangePercent>control.largestAbsoluteChangePercent;
        check(final?.assessment?.clearSlowdownRuleTriggered===triggered,"Exact preregistered one-host negative risk rule");
        check(near(final?.assessment?.largestAbsoluteControlChangePercent,control?.largestAbsoluteChangePercent),"Exact largest absolute A/A paired change");
        stats.prospectiveNegativeAssessment={clearSlowdownRuleTriggered:triggered,interpretation:triggered?"Hold/reject exact candidate":"No automatic pass: ambiguous negatives remain a hold/qualification limitation; not an equivalence proof"};
        check(final?.observations===16&&final?.complete===true&&final?.caseId===caseId,"Complete sixteen-observation fixed negative cell");
    }
    // Check child command shape independently of output metadata. No additional switches are accepted.
    for(const receipt of receipts) {
        const data=receipt.result;
        const command=receipt.command??[],args=command.slice(5);
        equal(command.slice(0,3),["node","--expose-gc","--max-old-space-size=512"],receipt.label+" exact Node argument prefix");
        check(command[3]?.endsWith("/"+(negative?"negative-screen.mjs":"screen.mjs")),receipt.label+" exact child entrypoint");
        check(command[4]===String(negative?plan.caseId:plan.dictionary),receipt.label+" exact workload argument");
        check(args[0]==="--source-root"&&args[1]===data?.sourceRoot,receipt.label+" exact selected source argument");
        check(args[2]===(negative?"--fixtures-dir":"--cache-dir")&&typeof args[3]==="string",receipt.label+" exact fixture argument");
        const tail=args.slice(4);
        if(data?.diagnosticWasm!==null)equal(tail,["--diagnostic-wasm",data?.diagnosticWasm],receipt.label+" only excluded diagnostic option");
        else if(negative&&receipt.label.endsWith("baseline-verification"))equal(tail,["--verify-only"],receipt.label+" only baseline verification option");
        else equal(tail,[],receipt.label+" production timing switches unchanged");
    }
    return {schemaVersion:1,scope:negative?"One fixed synthetic child-sum component cell":"One locked dictionary native component cell",
        dictionary:plan.dictionary??null,caseId:plan.caseId??null,negative,complete:final?.complete===true,allLogChecksPass:errors.length===0,errors,
        source:{baseline:plan.baseline,candidate:plan.candidate,tooling:plan.tooling,runtime:plan.runtime},
        artifactBindingPass,measuredObservationCount:rawObservations.length,rawChildReceiptCount:receipts.length,mechanics,statistics,rawObservations,failures,
        limits:["Original artifact/source compilation, native17-word oracle and smoke/correctness audits remain separately mandatory.","No complete browser import or process-memory qualification.","Frozen9e10 source only; develop advanced to dcfc02a0, so no current-source gain transfer.","No pooling corpora/hosts, subtraction, trimming, replacement or retries."]};
}

function auditPriorStreakLog(parsed,expected,artifactBinding=null) {
    const records=parsed.records??parsed,errors=[...(parsed.parseErrors??[]).map(x=>"JSON parse error: "+JSON.stringify(x))];
    const check=(condition,label)=>{if(!condition)errors.push(label);};
    const isPlan=r=>r.kind==="PRIOR_STREAK_SELECTOR_PLAN"||r.kind==="PREFIX_NEGATIVE_PLAN";
    const starts=records.map((r,i)=>isPlan(r)?i:-1).filter(i=>i>=0);
    const cells=[],seen=[];
    for(let i=0;i<starts.length;i++) {
        const segment=records.slice(starts[i],starts[i+1]??records.length),p=segment[0].value;
        const id=p.dictionary??"negative-"+p.caseId;
        seen.push(id);
        try{cells.push({id,...auditPriorStreakCell({records:segment,parseErrors:[]},expected,artifactBinding)});}
        catch(e){cells.push({id,complete:false,allLogChecksPass:false,errors:["Audit could not complete this retained segment: "+String(e)],rawSegment:segment});}
    }
    check(prefixEqual(seen,expected.cellOrder),"Every one of the nine declared cells appears once in fixed serial order; missing/failed preflights are incomplete");
    const candidateIds=cells.filter(c=>c.source).map(c=>c.source.candidate);
    for(const id of candidateIds)check(prefixEqual(id,candidateIds[0]),"One exact candidate source/binary/manifest identity across all observed cells");
    const baselineIds=cells.filter(c=>c.source).map(c=>c.source.baseline);
    for(const id of baselineIds)check(prefixEqual(id,baselineIds[0]),"One exact baseline source/binary identity across all observed cells");
    const measured=cells.reduce((s,c)=>s+(c.measuredObservationCount??0),0);
    check(measured===144,"Exactly 144 fixed measured child observations");
    for(const c of cells)if(!c.allLogChecksPass)errors.push(c.id+": cell audit incomplete/failed; see retained errors and raw receipts");
    return {schemaVersion:1,runId:expected.runId,jobId:expected.jobId,toolingHead:expected.toolingHead,scope:"Read-only independent reconstruction of one nine-cell native component screen; no new execution or measurements",complete:cells.length===9&&cells.every(c=>c.complete),allLogChecksPass:errors.length===0,errors,cellOrder:seen,measuredObservationCount:measured,plannedMeasuredObservations:144,cells,artifactBindingPass:artifactBinding===null?null:cells.every(c=>c.artifactBindingPass===true),recordCount:records.length,parseErrors:parsed.parseErrors??[],prePlanRecords:records.slice(0,starts[0]??records.length),interpretation:"A component target signal is insufficient without every prospective control/correctness gate and separate source-bound artifact audit. Current-develop and complete-import qualification remain separate."};
}
