/* Artificial offline auditor fixtures only. Never product execution or measured evidence. */
function makePriorStreakAuditFixture(expected) {
    const clone=x=>JSON.parse(JSON.stringify(x)),zeros=()=>Object.fromEntries(expected.diagnosticFields.map(k=>[k,0]));
    const identity=(candidate)=>({root:candidate?"/audit-fixture/candidate":"/audit-fixture/baseline",head:expected.baseline,tree:expected.baselineTree,trackedChanges:candidate?"M dev/data/dictionary-wasm/manifest.json\n M dev/data/dictionary-wasm/term-bank-parser.wasm\n M ext/js/dictionary/wasm/term-bank-parser.c":"",cSha256:candidate?expected.candidateC:expected.baselineC,wasmSha256:candidate?"1".repeat(64):expected.baselineWasm,trackedWasmSha256:candidate?"1".repeat(64):expected.baselineWasm,manifestSha256:candidate?"2".repeat(64):expected.baselineSourceHashes["dev/data/dictionary-wasm/manifest.json"],dependencyLockSha256:expected.dependencyLockSha256});
    const baseline=identity(false),candidate=identity(true),tooling={head:expected.toolingHead,fixtureLockSha256:expected.fixtureLockSha256,hashes:expected.toolingHashes},runtime={node:expected.node,browser:null,compiler:"clang version 21.1.8",linker:"LLD 21.1.8",host:"ARTIFICIAL OFFLINE AUDITOR FIXTURE",python:"synthetic"};
    const schedule=Array.from({length:4},(_,pair)=>[...pair%2?"DCBA":"ABCD"].map(arm=>({pair,arm}))).flat();
    const records=[];let epoch=1;
    const emit=(kind,value)=>records.push({kind,value:clone(value)});
    function common(arm,negative,diagnostic=false,verification=false) {
        const id=arm==="B"?candidate:baseline,sourceHashes=clone(expected.baselineSourceHashes);
        sourceHashes["ext/js/dictionary/wasm/term-bank-parser.c"]=id.cSha256;
        sourceHashes["dev/data/dictionary-wasm/manifest.json"]=id.manifestSha256;
        if(negative)for(const path of ["ext/js/dictionary/term-bank-source-pipeline.js","ext/js/dictionary/dense-zip-directory.js"])delete sourceHashes[path];
        else delete sourceHashes["ext/js/dictionary/term-bank-source-crc.js"];
        return {sourceRoot:id.root,gitHead:id.head,gitTree:id.tree,trackedChanges:id.trackedChanges,node:expected.node,validateGlossaryTypes:true,flags:{},runnerSha256:expected.toolingHashes[negative?"negative-screen.mjs":"screen.mjs"],diagnosticFieldsSha256:expected.toolingHashes["diagnostic-fields.json"],digest:"3".repeat(64),wasmSha256:diagnostic?"4".repeat(64):id.wasmSha256,diagnosticWasm:diagnostic?"/audit-fixture/diagnostic.wasm":null,diagnostic:diagnostic?zeros():null,sourceHashes,warmupPasses:diagnostic||verification?0:2};
    }
    function receipt(label,data,negative,workload,verification=false) {
        const command=["node","--expose-gc","--max-old-space-size=512","/audit-fixture/hosted/"+(negative?"negative-screen.mjs":"screen.mjs"),String(workload),"--source-root",data.sourceRoot,negative?"--fixtures-dir":"--cache-dir","/audit-fixture/inputs"];
        if(data.diagnosticWasm!==null)command.push("--diagnostic-wasm",data.diagnosticWasm);
        if(verification)command.push("--verify-only");
        const shared={label,command,startedEpoch:epoch++,finishedEpoch:epoch++};
        emit("PREFIX_CHILD_STATUS",{...shared,status:"completed",exitCode:0});
        emit("PREFIX_CHILD_RECEIPT",{...shared,result:data});
    }
    function summarize(observations) {
        const result={};
        for(const metric of ["elapsedMs","cpuMs","parseMs","nativeParseMs","lookupMs"])for(const [kind,a,b]of [["candidate","A","B"],["identicalControl","C","D"]]) {
            const first=[],second=[];
            for(let pair=0;pair<4;pair++){first.push(observations.find(o=>o.pair===pair&&o.arm===a).result[metric]);second.push(observations.find(o=>o.pair===pair&&o.arm===b).result[metric]);}
            result[kind+"."+metric]=prefixStats(first,second);
        }
        return result;
    }
    for(const cell of expected.cellOrder) {
        const negative=cell.startsWith("negative-");
        if(!negative) {
            const dictionary=cell,spec=expected.fixtures[dictionary],filesPerGroup={jmdict:7,jitendex:10,vndb:4}[dictionary],totalBanks=Math.ceil(spec.rows/10000);
            let remaining=spec.rows,cumulative=zeros();const groups=[];
            for(let start=0;start<totalBanks;start+=filesPerGroup) {
                const banks=Array.from({length:Math.min(filesPerGroup,totalBanks-start)},(_,i)=>"term_bank_"+(start+i+1)+".json"),rows=Math.min(remaining,banks.length*10000),fused=banks.length>1;
                const before=clone(cumulative),delta=dictionary==="jmdict"?{...zeros(),...expected.mechanics.jmdict.groups[groups.length].expected}:zeros();
                if(dictionary!=="jmdict")delta.rows=fused?rows:0;
                else {
                    // Feasible artificial values only; the five actual counters remain observed-only.
                    delta.readingIneligibleRows=delta.keyPredicateRows-delta.admissions;
                    delta.keyComparisonCalls=delta.admissions;
                    delta.keyComparisonBytesOffered=4*delta.keyComparisonCalls;
                    delta.maxKeyComparisonBytes=delta.keyComparisonCalls>0?4:0;
                }
                for(const key of expected.diagnosticFields)cumulative[key]=key.startsWith("max")?Math.max(cumulative[key],delta[key]):cumulative[key]+delta[key];
                groups.push({group:groups.length,banks,rows,fusedAttempts:fused?1:0,fusedFallbacks:0,glossaryReuseCount:delta.totalGlossaryReuses,recentContentDedupHitCount:delta.recentContentHits,diagnosticBefore:before,diagnosticAfter:clone(cumulative)});remaining-=rows;
            }
            const plan={dictionary,schedule,baseline,candidate,tooling,runtime,expectedMechanics:expected.mechanics};
            emit("PRIOR_STREAK_SELECTOR_PLAN",plan);
            function data(arm,diagnostic=false) {
                const d=common(arm,false,diagnostic),value=arm==="B"?98:100;
                Object.assign(d,{dictionary,rows:spec.rows,indexBytes:spec.rows*4,elapsedMs:value,cpuMs:value/2,inflateMs:value/10,inflateCpuMs:value/20,parseMs:value/2,lookupMs:value/4,nativeParseMs:value/3,maxWasmHeapBytes:1000000,archiveSha256:spec.sha256,lockSha256:expected.fixtureLockSha256,filesPerGroup,fusedAttempts:groups.reduce((s,g)=>s+g.fusedAttempts,0),fusedFallbacks:0,glossaryReuseCount:cumulative[arm==="B"?"totalGlossaryReuses":"originalGlossaryReuses"],recentContentDedupHitCount:cumulative.recentContentHits,groupReceipts:groups.map(g=>({...clone(g),glossaryReuseCount:g.diagnosticAfter[arm==="B"?"totalGlossaryReuses":"originalGlossaryReuses"]-g.diagnosticBefore[arm==="B"?"totalGlossaryReuses":"originalGlossaryReuses"]}))});
                if(dictionary==="vndb")d.flags={experimentalNativeEscapedKeys:true};
                if(diagnostic)d.diagnostic=clone(cumulative);
                else for(const g of d.groupReceipts)g.diagnosticBefore=g.diagnosticAfter=null;
                return d;
            }
            const diagnostic=data("B",true);receipt("diagnostic",diagnostic,false,dictionary);
            emit("PRIOR_STREAK_SELECTOR_DIAGNOSTIC",{dictionary,mechanicalCounts:diagnostic.diagnostic,rows:diagnostic.rows,digest:diagnostic.digest});
            const observations=[];
            for(const step of schedule){const d=data(step.arm);receipt("pair-"+step.pair+"-"+step.arm,d,false,dictionary);observations.push({...step,result:d});emit("PRIOR_STREAK_SELECTOR_OBSERVATION",{dictionary,...step,...Object.fromEntries(["rows","digest","elapsedMs","cpuMs","inflateMs","inflateCpuMs","parseMs","lookupMs","nativeParseMs","fusedAttempts","fusedFallbacks","glossaryReuseCount","maxWasmHeapBytes"].map(k=>[k,d[k]]))});}
            emit("PRIOR_STREAK_SELECTOR_RESULT",{dictionary,complete:true,summary:summarize(observations),mechanicalCounts:diagnostic.diagnostic,rows:diagnostic.rows,digest:diagnostic.digest});
        } else {
            const caseId=Number(cell.split("-")[1]),fixture=expected.negativeManifest.cases.find(x=>x.id===caseId),target=expected.negativeExpected.cases.find(x=>x.id===caseId),prefix="negative-case-"+caseId+"-";
            emit("PREFIX_NEGATIVE_PLAN",{caseId,studyCasesOrder:[1,2,3,4,5,6],schedulePerCase:schedule,measuredObservationCount:16,baseline,candidate,tooling,runtime,prospectiveProtocol:expected.negativeProtocol,fixtureManifest:expected.negativeManifest,fixtureManifestSha256:expected.negativeManifestSha256,diagnosticWasmSha256:"4".repeat(64)});
            function data(arm,diagnostic=false,verification=false) {
                const d=common(arm,true,diagnostic,verification),excluded=diagnostic||verification,value=arm==="B"?0.98:1;
                function pass(repetition,warmup=false) {return{repetition,...(warmup?{excluded:true}:{}),rows:20000,uniqueCount:target.expectedUniqueCount,indexBytes:target.expectedUniqueCount*4,digest:d.digest,elapsedMs:value,cpuMs:value/2,inflateMs:value/10,inflateCpuMs:value/20,parseMs:value/2,lookupMs:value/4,nativeParseMs:value/3,...target.expectedPublic,crcReusedBytes:0,crcVerifiedBytes:fixture.banks.reduce((s,b)=>s+b.uncompressedSize,0)};}
                Object.assign(d,{complete:true,caseId,excludedOnly:excluded,verificationOnly:verification,measuredRepetitions:excluded?0:16,repetitions:Array.from({length:excluded?1:16},(_,i)=>pass(i)),warmups:excluded?[]:[pass(0,true),pass(1,true)],bankIdentities:fixture.banks,fixtureManifestSha256:expected.negativeManifestSha256,generatorSha256:expected.toolingHashes["negative-fixtures.mjs"],outputDigestSha256:expected.toolingHashes["output-digest.mjs"],perPassRows:20000,perPassUniqueCount:target.expectedUniqueCount,perPassIndexBytes:target.expectedUniqueCount*4,maxWasmHeapBytes:1000000});
                for(const metric of ["elapsedMs","cpuMs","inflateMs","inflateCpuMs","parseMs","lookupMs","nativeParseMs","rows","indexBytes"])d[metric]=d.repetitions.reduce((s,r)=>s+r[metric],0);
                if(diagnostic)d.diagnostic=clone(target.expectedMechanics);
                return d;
            }
            const b=data("A",false,true),diag=data("B",true);receipt(prefix+"baseline-verification",b,true,caseId,true);receipt(prefix+"diagnostic",diag,true,caseId);
            emit("PREFIX_NEGATIVE_DIAGNOSTIC",{caseId,digest:diag.digest,counts:diag.diagnostic});
            const observations=[];
            for(const step of schedule){const d=data(step.arm);receipt(prefix+"pair-"+step.pair+"-"+step.arm,d,true,caseId);observations.push({...step,result:d});emit("PREFIX_NEGATIVE_OBSERVATION",{caseId,...step,...Object.fromEntries(["rows","digest","perPassUniqueCount","measuredRepetitions","elapsedMs","cpuMs","inflateMs","parseMs","lookupMs","nativeParseMs","maxWasmHeapBytes"].map(k=>[k,d[k]]))});}
            emit("PREFIX_NEGATIVE_RESULT",{complete:true,caseId,observations:16,summary:summarize(observations),assessment:{clearSlowdownRuleTriggered:false,largestAbsoluteControlChangePercent:0}});
        }
    }
    return {records,parseErrors:[],label:"Artificial offline auditor fixture: no measurements, execution or product evidence"};
}
