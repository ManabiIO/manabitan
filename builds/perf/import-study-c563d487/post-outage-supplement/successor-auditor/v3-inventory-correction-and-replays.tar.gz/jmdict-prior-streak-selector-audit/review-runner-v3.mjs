// Offline artificial receipts only. This script never imports or executes product code.
import {readFile, writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const here=path.dirname(fileURLToPath(import.meta.url));
const code=await readFile(path.join(here,'independent-prior-streak-log-audit-v3.js'),'utf8');
const fixtureCode=await readFile(path.join(here,'review-fixtures-v3.js'),'utf8');
const expected=JSON.parse(await readFile(path.join(here,'expected.json'),'utf8'));
const api=Function(code+'\n'+fixtureCode+'\nreturn {makePriorStreakAuditFixture,auditPriorStreakLog,parsePriorStreakLog};')();
const base=api.makePriorStreakAuditFixture(expected),clone=x=>JSON.parse(JSON.stringify(x));
const child=(f,pred)=>f.records.find(r=>r.kind==='PREFIX_CHILD_RECEIPT'&&pred(r.value)).value;
const cases=[
 ['source C',f=>{child(f,r=>r.label==='pair-0-B').result.sourceHashes['ext/js/dictionary/wasm/term-bank-parser.c']='0'.repeat(64);}],
 ['missing source hash',f=>{delete child(f,r=>r.label==='pair-0-A').result.sourceHashes['package-lock.json'];}],
 ['compiler mismatch',f=>{f.records.find(r=>r.kind==='PRIOR_STREAK_SELECTOR_PLAN').value.runtime.compiler='clang version 22.0.0';}],
 ['extra import flag',f=>{child(f,r=>r.label==='pair-0-A').result.flags={allowPartial:true};}],
 ['missing warmup',f=>{child(f,r=>r.label==='negative-case-4-pair-0-A').result.warmups.pop();}],
 ['binary64 aggregate',f=>{const d=child(f,r=>r.label==='negative-case-4-pair-0-A').result;d.cpuMs+=Number.EPSILON*d.cpuMs;}],
 ['numeric string repetition',f=>{const d=child(f,r=>r.label==='negative-case-4-pair-0-A').result;d.repetitions[0].cpuMs=String(d.repetitions[0].cpuMs);}],
 ['negative public recent count',f=>{child(f,r=>r.label==='negative-case-4-pair-0-A').result.repetitions[0].recentContentDedupHitCount++;}],
 ['new proof diagnostic',f=>{child(f,r=>r.label==='diagnostic'&&r.result.dictionary==='jmdict').result.diagnostic.hits++;}],
 ['VNDB singleton route',f=>{child(f,r=>r.label==='pair-0-A'&&r.result.dictionary==='vndb').result.groupReceipts.at(-1).fusedAttempts=1;}],
 ['reported summary',f=>{f.records.find(r=>r.kind==='PREFIX_NEGATIVE_RESULT').value.summary['candidate.elapsedMs'].medianPairedChangePercent=0;}],
 ['extra child option',f=>{child(f,r=>r.label==='pair-0-A').command.push('--phase-profile');}],
 ['extra child receipt',f=>{const r=clone(f.records.find(r=>r.kind==='PREFIX_CHILD_RECEIPT'));r.value.label='unplanned';f.records.splice(2,0,r);}],
 ['missing cell plan',f=>{f.records=f.records.filter(r=>!(r.kind==='PREFIX_NEGATIVE_PLAN'&&r.value.caseId===2));}],
 ['wrong pinned fixture manifest',f=>{f.records.find(r=>r.kind==='PREFIX_NEGATIVE_PLAN').value.fixtureManifestSha256='0'.repeat(64);}],
 ['wrong candidate binary metadata',f=>{const r=f.records.find(r=>r.kind==='PREFIX_NEGATIVE_PLAN');r.value.candidate.wasmSha256='5'.repeat(64);r.value.candidate.trackedWasmSha256='5'.repeat(64);}],
 ['original four-window regression',f=>{child(f,r=>r.label==='negative-case-6-diagnostic').result.diagnostic.selectedDistance3--;}]
];
const checks=[];
for(const[name,mutate]of cases){const f=clone(base);mutate(f);const r=api.auditPriorStreakLog(f,expected);checks.push({name,rejected:!r.allLogChecksPass,errorCount:r.errors.length,failedCells:r.cells.filter(x=>!x.allLogChecksPass).map(x=>x.id)});}
const logged=base.records.map(r=>'2026-11-28T00:00:00Z '+r.kind+' '+JSON.stringify(r.value)).join('\n');
const positive=api.auditPriorStreakLog(base,expected),roundtrip=api.auditPriorStreakLog(api.parsePriorStreakLog(logged),expected);
const riskCode=fixtureCode.replace('value=arm==="B"?0.98:1','value=arm==="B"?(caseId===4?1.06:0.98):1').replace('assessment:{clearSlowdownRuleTriggered:false,largestAbsoluteControlChangePercent:0}','assessment:{clearSlowdownRuleTriggered:caseId===4,largestAbsoluteControlChangePercent:0}');
const riskApi=Function(code+'\n'+riskCode+'\nreturn {makePriorStreakAuditFixture,auditPriorStreakLog};')();
const risk=riskApi.auditPriorStreakLog(riskApi.makePriorStreakAuditFixture(expected),expected);
const artifactBad=api.auditPriorStreakLog(base,expected,{candidateC:expected.candidateC,candidateWasm:'7'.repeat(64),candidateManifest:'2'.repeat(64),originalArtifactAuditPassed:true});
const output={schemaVersion:1,scope:'Artificial offline auditor witnesses only; no product execution, acquisition, performance evidence or source changes',recordedAtUtc:new Date().toISOString(),positiveNineCellFixture:{pass:positive.allLogChecksPass,measuredChildCount:144,rawChildCount:positive.cells.reduce((s,c)=>s+c.rawChildReceiptCount,0)},taggedLogRoundtripPassed:roundtrip.allLogChecksPass,mutationChecks:checks,everyMutationRejected:checks.every(c=>c.rejected),negativeRiskWitness:{pass:risk.allLogChecksPass,case4:risk.cells.find(c=>c.id==='negative-4').statistics[4].prospectiveNegativeAssessment},badArtifactBindingRejected:!artifactBad.allLogChecksPass,artifactBindingRemainsRequired:roundtrip.artifactBindingPass===null,emptyLogRejected:!api.auditPriorStreakLog({records:[],parseErrors:[]},expected).allLogChecksPass};
if(process.argv[2])await writeFile(path.resolve(process.argv[2]),JSON.stringify(output,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({pass:output.positiveNineCellFixture.pass&&output.taggedLogRoundtripPassed&&output.everyMutationRejected&&output.negativeRiskWitness.pass&&output.negativeRiskWitness.case4.clearSlowdownRuleTriggered&&output.badArtifactBindingRejected&&output.artifactBindingRemainsRequired&&output.emptyLogRejected,mutations:checks.length,measuredChildFixtureCount:144}));
