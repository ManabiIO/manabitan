"""Audit original hosted artifacts without executing native or benchmark code."""
import collections
import datetime
import hashlib
import json
import math
import pathlib
import re
import statistics
import subprocess
import zipfile
import zlib

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[1]
TOOLS = ROOT / 'experiments/jmdict-prior-streak-selector-hosted'
BASE = ROOT / 'manabitan'
SHA = lambda data: hashlib.sha256(data).hexdigest()
load = lambda path: json.loads(path.read_bytes())
archive = HERE / 'original-artifact.zip'
assert archive.stat().st_size == 2878668
assert SHA(archive.read_bytes()) == 'e1752357f7354360eb0b1f20abb090a21fda0f0696c904da9a1c56f5e1b336d0'
z = zipfile.ZipFile(archive)
members = {}
for item in z.infolist():
    name = pathlib.PurePosixPath(item.filename)
    assert not name.is_absolute() and '..' not in name.parts
    assert ((item.external_attr >> 16) & 0o170000) != 0o120000
    digest = hashlib.sha256()
    size = 0
    with z.open(item) as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
            size += len(block)
    assert size == item.file_size
    members[item.filename] = {'sha256': digest.hexdigest(), 'bytes': size, 'crc32': item.CRC}
assert len(members) == 560
read = lambda name: json.loads(z.read(name))
first = read('jmdict/result.json')
baseline, candidate, tooling = first['baseline'], first['candidate'], first['tooling']
native = ['dev/data/dictionary-wasm/manifest.json', 'dev/data/dictionary-wasm/term-bank-parser.wasm', 'ext/js/dictionary/wasm/term-bank-parser.c']
assert tooling['head'] == '24ae6bb44f5f055eb06fe2fdf478017a7b01ed82'
assert baseline['head'] == candidate['head'] == '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
assert baseline['tree'] == candidate['tree'] == 'd99ea4d04658f7ec1c76acdc5f3684594212a471'
assert baseline['trackedChanges'] == ''
assert sorted(x.strip()[2:] for x in candidate['trackedChanges'].splitlines()) == native
assert candidate['cSha256'] == 'f622f057b7de9db9082d79c6d67eb7d93b86d74cb5ec9b1674d8e9a67f6456fb'
assert candidate['wasmSha256'] == candidate['trackedWasmSha256'] == 'e59fc0246710b64d81cef5b5b8b82c1d76784af88f2b9c9948ba89dfb754a837'
assert candidate['manifestSha256'] == '68c7a2fe25c627475f32c7cb86965ecda15b6f7e363b54794134f3650e71f275'
for name, digest in tooling['hashes'].items():
    source_path = (ROOT / 'experiments/jmdict-prior-streak-selector/qualification' / pathlib.PurePosixPath(name).name) if name.startswith('../qualification/') else TOOLS / name
    assert SHA(source_path.read_bytes()) == digest, name
fields = load(TOOLS / 'diagnostic-fields.json')
assert len(fields) == 48
diagnostic_build = read('diagnostic-build.json')
diagnostic_hash = members['diagnostic.wasm']['sha256']
assert diagnostic_hash == diagnostic_build['diagnosticWasmSha256'] == 'b26566cdd1aa0b8342442d1a605891b7ace3d5ae810963efd7e894990c152129'
assert members['diagnostic-source.c']['sha256'] == diagnostic_build['diagnosticSourceSha256'] == '236fd5bb7648c8167e25f720a501c0ed752b511a241bded92abb537faa54eef1'
assert diagnostic_build['productSourceSha256'] == candidate['cSha256']
assert diagnostic_build['fields'] == fields
assert diagnostic_build['fieldsSha256'] == tooling['hashes']['diagnostic-fields.json']
assert diagnostic_build['preparerSha256'] == tooling['hashes']['prepare.py']
assert not diagnostic_build['sourceOnly'] and '21.1.8' in diagnostic_build['compiler'] and '21.1.8' in diagnostic_build['linker']
# Recover the exact three production files from the original Git binary patch.
product = HERE / 'compiled-product'
already_recovered = product.exists()
product.mkdir(exist_ok=True)
for name, identity_key in zip(native, ['manifestSha256', 'wasmSha256', 'cSha256']):
    data = (BASE / name).read_bytes()
    assert SHA(data) == baseline[identity_key]
    path = product / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if not already_recovered:
        path.write_bytes(data)
patch = HERE / 'rebuilt-candidate.diff'
patch.write_bytes(z.read('rebuilt-candidate.diff'))
assert sorted(re.findall(r'^diff --git a/(\S+) b/\S+$', patch.read_text(), re.M)) == native
for check in (() if already_recovered else (True, False)):
    command = ['git', 'apply'] + (['--check'] if check else []) + [str(patch)]
    call = subprocess.run(command, cwd=product, capture_output=True)
    assert call.returncode == 0, call.stderr.decode()
for name, identity_key in zip(native, ['manifestSha256', 'wasmSha256', 'cSha256']):
    assert SHA((product / name).read_bytes()) == candidate[identity_key]
manifest = load(product / native[0])
source_rows = []
for path in sorted((BASE / 'ext/js/dictionary/wasm').rglob('*')):
    if path.suffix.lower() not in ('.c', '.h'):
        continue
    name = path.relative_to(BASE).as_posix()
    data = (product / name).read_bytes() if name == native[2] else path.read_bytes()
    source_rows.append((name, SHA(data)))
digest = SHA(''.join(name + '\0' + value + '\n' for name, value in source_rows).encode())
assert len(source_rows) == manifest['sourceFileCount'] == 14 and digest == manifest['sourceDigest']
assert next(x for x in manifest['targets'] if x['name'] == 'term-bank-parser.wasm')['sha256'] == candidate['wasmSha256']
assert manifest['toolchain'] == {'compilerVersion': '21.1.8', 'linkerVersion': '21.1.8'}
schedule = [{'pair': p, 'arm': a} for p in range(4) for a in ('ABCD' if p % 2 == 0 else 'DCBA')]
assert first['schedule'] == schedule
primary = []
for line in (HERE / 'primary-records.jsonl').read_text().splitlines():
    if line.strip():
        tag, payload = line.split(' ', 1)
        primary.append((tag, json.loads(payload)))
assert len(primary) == 495
reconstructed = []
children = []
negative_passes = 0
mechanical_checks = 0
dict_summaries = []
negative_summaries = []
oracle_summaries = []

def emit(tag, value):
    reconstructed.append((tag, value))

def child(prefix, with_receipt=True):
    status = read(prefix + '.child-status.json')
    assert status['status'] == 'completed' and status['exitCode'] == 0
    assert status['finishedEpoch'] >= status['startedEpoch']
    assert status['label'] == pathlib.PurePosixPath(prefix).name
    data = read(prefix + '.stdout.json')
    assert 'observationStartedEpoch' not in data
    data['observationStartedEpoch'] = status['startedEpoch']
    emit('PREFIX_CHILD_STATUS', status)
    if with_receipt:
        emit('PREFIX_CHILD_RECEIPT', {key: status[key] for key in ['label', 'command', 'startedEpoch', 'finishedEpoch']} | {'result': data})
        children.append({'prefix': prefix, 'status': status, 'stdoutSha256': members[prefix + '.stdout.json']['sha256']})
    return data

def common(data, plan, arm, diagnostic, negative=False):
    selected = candidate if arm == 'B' or diagnostic else baseline
    assert plan['baseline'] == baseline and plan['candidate'] == candidate and plan['tooling'] == tooling
    assert plan['runtime']['node'] == data['node'] == 'v22.22.0'
    assert plan['runtime']['browser'] is None
    assert '21.1.8' in plan['runtime']['compiler'] and '21.1.8' in plan['runtime']['linker']
    assert data['gitHead'] == selected['head'] and data['gitTree'] == selected['tree']
    assert data['sourceRoot'] == selected['root'] and data['trackedChanges'] == selected['trackedChanges']
    assert data['wasmSha256'] == (diagnostic_hash if diagnostic else selected['wasmSha256'])
    assert data['runnerSha256'] == tooling['hashes']['negative-screen.mjs' if negative else 'screen.mjs']
    assert data['diagnosticFieldsSha256'] == tooling['hashes']['diagnostic-fields.json']
    assert data['validateGlossaryTypes'] is True
    assert len(data['sourceHashes']) == (10 if negative else 11)
    for name, value in data['sourceHashes'].items():
        expected = selected['cSha256'] if name == native[2] else selected['manifestSha256'] if name == native[0] else SHA((BASE / name).read_bytes())
        assert value == expected, name
    for key in ['elapsedMs', 'cpuMs', 'inflateMs', 'inflateCpuMs', 'parseMs', 'lookupMs', 'nativeParseMs']:
        assert isinstance(data[key], (float, int)) and math.isfinite(data[key]) and data[key] >= 0

def mechanical(d):
    assert set(d) == set(fields) and all(isinstance(v, int) and v >= 0 for v in d.values())
    assert d['admissions'] == d['noPrefixCandidate'] + d['selected']
    assert d['candidateRecordsInspected'] == sum(d[x] for x in ['definitionLengthRejected', 'rulesLengthRejected', 'definitionSignatureRejected', 'rulesSignatureRejected', 'selected'])
    assert d['selected'] == sum(d[x] for x in ['boundsRejected', 'openerRejected', 'tailRejected', 'middleRejected', 'fullRejected', 'hits'])
    assert d['selected'] == sum(d['selectedDistance' + str(i)] for i in range(1, 5))
    assert d['hits'] == sum(d['hitDistance' + str(i)] for i in range(1, 5))
    assert d['fullBytesOffered'] == d['hitBytes'] + d['failedFullBytesOffered']
    assert d['totalGlossaryReuses'] == d['originalGlossaryReuses'] + d['hits']
    assert d['selected'] <= d['admissions'] <= d['keyPredicateRows'] <= d['priorStreakLookbackZeroRows'] <= d['originalLookbackZeroRows']
    assert d['admissions'] == d['expressionMatches'] + d['readingMatches']
    assert d['keyComparisonCalls'] <= 3 * d['keyPredicateRows']
    assert d['keyComparisonBytesOffered'] <= 32 * d['keyComparisonCalls'] and d['maxKeyComparisonBytes'] <= 32

# The six complete smoke files independently bind the aggregate report's retained content.
smoke_modes = ['baseline', 'candidate', 'diagnostic', 'disabled-baseline', 'disabled-candidate', 'disabled-diagnostic']
smoke_reference = None
smoke_counts = []
for mode in smoke_modes:
    d = child('smoke-' + mode, with_receipt=False)
    assert d['complete'] and (d['validCases'], d['malformedCases'], d['fallbackCases']) == (67, 16, 3)
    assert len(d['results']) == 73 and len(d['diagnostics']) == 83
    assert d['diagnosticFields'] == fields and d['disabledReuse'] == mode.startswith('disabled-')
    assert d['baseline'] == mode.endswith('baseline')
    selected = baseline if d['baseline'] else candidate
    assert d['sourceHash'] == selected['cSha256']
    assert d['wasmHash'] == (diagnostic_hash if mode.endswith('diagnostic') else selected['wasmSha256'])
    assert d['harnessHash'] == tooling['hashes']['smoke.mjs']
    assert d['fixtureHash'] == SHA((TOOLS.parent / 'jmdict-prior-streak-selector/qualification/term-bank-prior-streak-selector-fixtures.js').read_bytes())
    if smoke_reference is None:
        smoke_reference = d['results']
    assert d['results'] == smoke_reference
    for case in d['diagnostics'][:67]:
        assert case['actualReuses'] == case['expectedReuses']
    for case in d['diagnostics'][67:]:
        assert case['rejected'] and case['publishedRows'] == 0
    if mode == 'diagnostic':
        assert d['nativeDiagnostics']['hits'] > 0 and d['nativeDiagnostics']['originalGlossaryReuses'] > 0
    if mode == 'disabled-diagnostic':
        assert all(d['nativeDiagnostics'][key] == 0 for key in fields if key not in ['rows', 'recentContentHits'])
    smoke_counts.append({'mode': mode, 'sourceSha256': d['sourceHash'], 'wasmSha256': d['wasmHash'], 'valid': 67, 'malformed': 16, 'fallback': 3})

expected = load(TOOLS / 'expected-mechanics.json')
fixture = read('negative-fixtures/manifest.json')
assert members['negative-fixtures/manifest.json']['sha256'] == '7291d348f059862bbb51df976902d0cd21cb2115757e49d0020e59ae4483be54'
assert members['negative-fixtures/state-model-result.json']['sha256'] == fixture['modelReceiptSha256'] == 'fbd0863047d88d3f358b7ee54de924c4caf18e201e52f196918df3c8a12f10dd'
assert read('negative-fixtures/state-model-result.json')['complete']
for name, value in fixture['sourceHashes'].items():
    assert value == tooling['hashes'][name] == members['negative-fixtures/source-' + name]['sha256']
expected_negative = load(TOOLS / 'expected-counts.json')
for case, target in zip(fixture['cases'], expected_negative['cases']):
    assert case['id'] == target['id']
    for key in ['expectedUniqueCount', 'expectedMechanics', 'expectedPublic', 'expectedShadow']:
        assert case[key] == target[key]
    for bank in case['banks']:
        assert members['negative-fixtures/' + bank['rawFile']]['sha256'] == bank['rawSha256']
        assert members['negative-fixtures/' + bank['compressedFile']]['sha256'] == bank['compressedSha256']
        compressed = z.read('negative-fixtures/' + bank['compressedFile'])
        assert len(compressed) == bank['compressedSize']
        # One bank at a time, bytes only: no JSON/native parser or timer invocation.
        raw = zlib.decompress(compressed, -15)
        assert len(raw) == bank['uncompressedSize'] and SHA(raw) == bank['rawSha256']
        assert zlib.crc32(raw) == bank['signature']
        del raw

def dictionary(name):
    global mechanical_checks
    plan = read(name + '/result.json')
    assert plan['complete'] and plan['schedule'] == schedule and len(plan['observations']) == 16
    assert plan['expectedMechanics'] == expected
    initial = {k: v for k, v in plan.items() if k not in ['observations', 'summary']}
    initial.update(complete=False, diagnostic=None)
    emit('PRIOR_STREAK_SELECTOR_PLAN', initial)
    d = child(name + '/diagnostic')
    assert d == plan['diagnostic']
    common(d, plan, 'B', True)
    mechanical(d['diagnostic'])
    assert members[name + '/diagnostic.wasm']['sha256'] == diagnostic_hash
    assert d['warmupPasses'] == 0 and d['filesPerGroup'] == {'jmdict': 7, 'jitendex': 10, 'vndb': 4}[name]
    assert d['flags'] == ({'experimentalNativeEscapedKeys': True} if name == 'vndb' else {})
    assert d['rows'] == {'jmdict': 528299, 'jitendex': 436555, 'vndb': 6648310}[name]
    if name == 'jmdict':
        assert d['archiveSha256'] == expected['archiveSha256']
        for key, value in expected['jmdict']['total'].items():
            assert d['diagnostic'][key] == value, key
            mechanical_checks += 1
        assert len(d['groupReceipts']) == len(expected['jmdict']['groups']) == 8
        for actual, target in zip(d['groupReceipts'], expected['jmdict']['groups']):
            assert actual['group'] == target['group']
            before, after = actual['diagnosticBefore'] or {}, actual['diagnosticAfter']
            for key, value in target['expected'].items():
                assert after[key] == (max(before.get(key, 0), value) if key.startswith('max') else before.get(key, 0) + value)
                mechanical_checks += 1
    emit('PRIOR_STREAK_SELECTOR_DIAGNOSTIC', {'dictionary': name, 'mechanicalCounts': d['diagnostic'], 'rows': d['rows'], 'digest': d['digest']})
    for step, observation in zip(schedule, plan['observations']):
        assert {k: observation[k] for k in step} == step
        data = child(f"{name}/pair-{step['pair']}-{step['arm']}")
        assert data == observation['result']
        common(data, plan, step['arm'], False)
        assert data['warmupPasses'] == 2 and data['diagnostic'] is None and data['diagnosticWasm'] is None
        for key in ['rows', 'digest', 'indexBytes', 'archiveSha256', 'lockSha256', 'flags', 'filesPerGroup', 'recentContentDedupHitCount']:
            assert data[key] == d[key], key
        counter = 'totalGlossaryReuses' if step['arm'] == 'B' else 'originalGlossaryReuses'
        assert data['glossaryReuseCount'] == d['diagnostic'][counter]
        assert len(data['groupReceipts']) == len(d['groupReceipts'])
        attempts = 0
        for actual, reference in zip(data['groupReceipts'], d['groupReceipts']):
            for key in ['group', 'banks', 'rows', 'fusedAttempts', 'fusedFallbacks', 'recentContentDedupHitCount']:
                assert actual[key] == reference[key]
            assert actual['fusedAttempts'] == (1 if len(actual['banks']) > 1 else 0) and actual['fusedFallbacks'] == 0
            attempts += actual['fusedAttempts']
            assert actual['glossaryReuseCount'] == reference['diagnosticAfter'][counter] - (reference['diagnosticBefore'] or {}).get(counter, 0)
        assert data['fusedAttempts'] == attempts and data['fusedFallbacks'] == 0
        emit('PRIOR_STREAK_SELECTOR_OBSERVATION', {'dictionary': name, **step, **{key: data[key] for key in ['rows', 'digest', 'elapsedMs', 'cpuMs', 'inflateMs', 'inflateCpuMs', 'parseMs', 'lookupMs', 'nativeParseMs', 'fusedAttempts', 'fusedFallbacks', 'glossaryReuseCount', 'maxWasmHeapBytes']}})
    emit('PRIOR_STREAK_SELECTOR_RESULT', {'dictionary': name, 'complete': True, 'scope': plan['scope'], 'summary': plan['summary'], 'mechanicalCounts': d['diagnostic'], 'rows': d['rows'], 'digest': d['digest']})
    # Raw parser oracle receipts include every capacity attempt, partial-error digest and final row17-word digest.
    oracle = read(name + '/native-oracle/native-oracle.json')
    records_name = name + '/native-oracle/native-oracle-records.jsonl'
    assert oracle['complete'] and oracle['failures'] == [] and oracle['oracleSha256'] == tooling['hashes']['native-oracle.mjs']
    assert oracle['recordsSha256'] == members[records_name]['sha256']
    assert oracle['archiveSha256'] == d['archiveSha256'] and oracle['fixtureLockSha256'] == d['lockSha256']
    for arm, identity in [('baseline', baseline), ('candidate', candidate)]:
        assert oracle['sources'][arm]['wasmSha256'] == identity['wasmSha256'] and oracle['sources'][arm]['sourceSha256'] == identity['cSha256']
    counts = collections.Counter()
    row_counts = collections.Counter()
    errors = attempts = 0
    for line in z.read(records_name).decode().splitlines():
        r = json.loads(line)
        assert r['baseline'] == r['candidate'] and r['baseline']
        attempts += len(r['baseline'])
        counts[(r['kind'], r['exportName'])] += 1
        for attempt in r['baseline']:
            assert re.fullmatch('[0-9a-f]{64}', attempt['digest']) and attempt['words'] >= 0
        final = r['baseline'][-1]
        if r['kind'] == 'lockedBank':
            assert final['result'] >= 0 and final['words'] == final['result'] * 17
            row_counts[r['exportName']] += final['result']
        elif final['result'] < 0:
            errors += 1
    for export_name in ['parse_term_bank', 'parse_term_bank_with_media_hints']:
        assert counts[('synthetic', export_name)] == oracle['synthetic']['cases'] == 1112
        assert counts[('lockedBank', export_name)] == oracle['corpus'][export_name]['banks']
        assert row_counts[export_name] == oracle['corpus'][export_name]['rows'] == d['rows']
    assert oracle['synthetic']['exportComparisons'] == 2224
    oracle_summaries.append({'dictionary': name, 'summarySha256': members[name + '/native-oracle/native-oracle.json']['sha256'], 'recordsSha256': oracle['recordsSha256'], 'recordCount': sum(counts.values()), 'capacityAttemptsPerArm': attempts, 'partialErrorComparisons': errors, 'corpus': oracle['corpus'], 'synthetic': oracle['synthetic']})
    dict_summaries.append({'dictionary': name, 'rows': d['rows'], 'groups': len(d['groupReceipts']), 'digest': d['digest'], 'diagnostic': d['diagnostic'], 'summary': plan['summary']})

def negative(case_id):
    global negative_passes
    directory = f'negative-case-{case_id}'
    plan = read(directory + '/negative-result.json')
    assert plan['complete'] and plan['caseId'] == case_id and plan['schedulePerCase'] == schedule
    assert plan['fixtureManifest'] == fixture and plan['fixtureManifestSha256'] == members['negative-fixtures/manifest.json']['sha256']
    assert plan['prospectiveProtocol'] == load(TOOLS / 'negative-protocol.json')
    assert plan['diagnosticWasmSha256'] == diagnostic_hash == members[directory + '/diagnostic.wasm']['sha256']
    record = plan['cases'][0]
    assert len(plan['cases']) == 1 and record['id'] == case_id and record['complete'] and len(record['observations']) == 16
    target = fixture['cases'][case_id - 1]
    initial = {k: v for k, v in plan.items() if k != 'cases'}
    initial['complete'] = False
    emit('PREFIX_NEGATIVE_PLAN', initial)

    def observation(label, arm, diagnostic=False, verify=False):
        nonlocal target
        global negative_passes
        prefix = f'{directory}/{directory}-{label}'
        data = child(prefix)
        common(data, plan, arm, diagnostic, True)
        excluded = diagnostic or verify
        assert data['complete'] and data['caseId'] == case_id
        assert data['excludedOnly'] == excluded and data['verificationOnly'] == verify
        assert data['warmupPasses'] == (0 if excluded else 2) and len(data['warmups']) == data['warmupPasses']
        assert data['measuredRepetitions'] == (0 if excluded else 16) and len(data['repetitions']) == (1 if excluded else 16)
        assert data['flags'] == {} and data['fixtureManifestSha256'] == plan['fixtureManifestSha256']
        assert data['generatorSha256'] == fixture['generatorSha256'] and data['bankIdentities'] == target['banks']
        assert data['perPassRows'] == 20000 and data['perPassUniqueCount'] == target['expectedUniqueCount']
        assert data['outputDigestSha256'] == tooling['hashes']['output-digest.mjs']
        for key in ['elapsedMs', 'cpuMs', 'inflateMs', 'inflateCpuMs', 'parseMs', 'lookupMs', 'nativeParseMs', 'rows', 'indexBytes']:
            total = 0.0
            for item in data['repetitions']:
                total += item[key]
            assert data[key] == total, (case_id, label, key)
        progress = []
        starts = []
        for line in z.read(prefix + '.stderr.log').decode().splitlines():
            if line.startswith('PREFIX_NEGATIVE_PASS '):
                progress.append(json.loads(line.split(' ', 1)[1]))
            elif line.startswith('PREFIX_NEGATIVE_CHILD_START '):
                starts.append(json.loads(line.split(' ', 1)[1]))
            assert not line.startswith('PREFIX_NEGATIVE_CHILD_FAILED ')
        assert len(starts) == 1
        for key in starts[0]:
            assert starts[0][key] == data[key], key
        expected_progress = []
        for phase, items in [('warmup', data['warmups']), ('measured', data['repetitions'])]:
            for item in items:
                assert item['rows'] == 20000 and item['uniqueCount'] == target['expectedUniqueCount']
                for key, value in target['expectedPublic'].items():
                    assert item[key] == value
                assert item['crcReusedBytes'] == 0 and item['crcVerifiedBytes'] == sum(b['uncompressedSize'] for b in target['banks'])
                assert item['digest'] == data['digest'] and item['indexBytes'] == data['perPassIndexBytes']
                expected_progress.append({'caseId': case_id, 'phase': 'untimed-verification' if excluded else phase, **item})
        assert progress == expected_progress, (case_id, label, 'stderr pass receipts')
        negative_passes += len(progress)
        return data

    reference = observation('baseline-verification', 'A', verify=True)
    assert reference == record['baselineVerification']
    d = observation('diagnostic', 'B', diagnostic=True)
    assert d == record['diagnostic']
    mechanical(d['diagnostic'])
    assert d['diagnostic'] == target['expectedMechanics']
    parity = ['digest', 'perPassRows', 'perPassUniqueCount', 'perPassIndexBytes', 'bankIdentities', 'flags']
    assert all(d[k] == reference[k] for k in parity)
    emit('PREFIX_NEGATIVE_DIAGNOSTIC', {'caseId': case_id, 'digest': d['digest'], 'counts': d['diagnostic']})
    for step, observed in zip(schedule, record['observations']):
        assert {k: observed[k] for k in step} == step
        data = observation(f"pair-{step['pair']}-{step['arm']}", step['arm'])
        assert data == observed['result'] and data['diagnostic'] is None and data['diagnosticWasm'] is None
        assert all(data[k] == reference[k] for k in parity)
        emit('PREFIX_NEGATIVE_OBSERVATION', {'caseId': case_id, **step, **{key: data[key] for key in ['rows', 'digest', 'perPassUniqueCount', 'measuredRepetitions', 'elapsedMs', 'cpuMs', 'inflateMs', 'parseMs', 'lookupMs', 'nativeParseMs', 'maxWasmHeapBytes']}})
    candidate_summary = record['summary']['candidate.elapsedMs']
    aa = record['summary']['identicalControl.elapsedMs']
    threshold = max(abs(x) for x in aa['pairedChangesPercent'])
    rule = candidate_summary['medianPairedChangePercent'] > 3 and all(x > 0 for x in candidate_summary['pairedChangesPercent']) and candidate_summary['medianPairedChangePercent'] > threshold
    assert record['prospectiveNegativeAssessment']['clearSlowdownRuleTriggered'] == rule
    assert record['prospectiveNegativeAssessment']['largestAbsoluteControlChangePercent'] == threshold
    emit('PREFIX_NEGATIVE_RESULT', {'complete': True, 'caseId': case_id, 'observations': 16, 'summary': record['summary'], 'assessment': record['prospectiveNegativeAssessment']})
    negative_summaries.append({'caseId': case_id, 'digest': d['digest'], 'expectedUniqueCount': target['expectedUniqueCount'], 'mechanics': d['diagnostic'], 'summary': record['summary'], 'assessment': record['prospectiveNegativeAssessment']})

dictionary('jmdict')
for case_id in range(1, 7):
    negative(case_id)
dictionary('jitendex')
dictionary('vndb')
assert len(children) == 159 and negative_passes == 1740 and mechanical_checks == 387
assert reconstructed == primary, next((i for i, (a, b) in enumerate(zip(reconstructed, primary)) if a != b), 'length')
assert len(reconstructed) == 495
for earlier, later in zip(children, children[1:]):
    assert earlier['status']['finishedEpoch'] <= later['status']['startedEpoch']
focused = re.sub(r'\x1b\[[0-9;]*m', '', z.read('focused-tests.log').decode())
assert re.search(r'Test Files\s+7 passed\s+\(7\)', focused) and re.search(r'Tests\s+803 passed\s+\(803\)', focused)
lint = read('scoped-eslint.json')
assert len(lint) == 2 and all(x['errorCount'] == x['warningCount'] == 0 for x in lint)
assert 'tsc --noEmit' in z.read('test-types.log').decode()
primary_audit = load(HERE / 'primary-log-audit.json')
audit = {
    'schema': 1, 'complete': True, 'auditedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Independent original ZIP/source/fixture/correctness/raw-output audit, with all495 primary records reconstructed exactly from original artifacts. No native/parser/benchmark execution or corpus download.',
    'runId': 46124542684, 'jobId': 140916123863, 'artifactId': 15255629754,
    'artifactSha256': SHA(archive.read_bytes()), 'artifactBytes': archive.stat().st_size,
    'retention': 'Complete original ZIP retained losslessly, including all12 raw and compressed generated banks, every smoke/native/error/capacity receipt and all timing/pass/stderr outputs; no member removed.',
    'memberCount': len(members), 'uncompressedBytes': sum(x['bytes'] for x in members.values()),
    'product': candidate, 'baseline': baseline, 'manifestSourceDigest': digest,
    'compiledProductRecoveredByExactGitBinaryPatch': True, 'rebuiltDiffSha256': members['rebuilt-candidate.diff']['sha256'],
    'diagnosticBuild': diagnostic_build, 'tooling': tooling,
    'correctness': {'focusedSuites': 7, 'focusedTests': 803, 'scopedLintFiles': 2, 'scopedLintErrors': 0, 'scopedLintWarnings': 0, 'testTypes': 'Original clean log and successful preflight/job; no local rerun', 'smoke': smoke_counts, 'nativeOracles': oracle_summaries},
    'negativeFixtureManifestSha256': members['negative-fixtures/manifest.json']['sha256'],
    'negativeFixtureModelSha256': fixture['modelReceiptSha256'], 'all12BankHashesAndDecompressedCrcsVerified': True,
    'measuredObservations': 144, 'rawChildren': 159, 'primaryRecords': 495, 'negativePassReceipts': negative_passes,
    'primaryTagCounts': dict(collections.Counter(t for t, _ in primary)), 'allPrimaryRecordsExactlyReconstructed': True,
    'primaryRecordsSha256': SHA((HERE / 'primary-records.jsonl').read_bytes()),
    'independentPrimaryStatisticsAuditSha256': SHA((HERE / 'primary-log-audit.json').read_bytes()),
    'jmExpectedMechanicsChecks': mechanical_checks, 'negativeExpectedMechanicsChecks': 6 * 48,
    'dictionaryCells': dict_summaries, 'negativeCells': negative_summaries,
    'decision': 'No full promotion: frozen JMdict component target criterion failed (3of4 faster, median -2.1224%, maximum absolute A/A7.4818%). No negative formal all4 rule triggered; adverse ambiguity retained, not equivalence proof.',
    'limitations': ['Component-only; no browser/storage/process-memory/release qualification.', 'Oracle artifact stores source-bound comparison receipts and hashes, not complete raw17-word arrays; its reviewed native implementation checked every word, with every capacity/error attempt retained.', 'Timing statistics independently recomputed by the primary-log auditor; this audit cross-binds every original value and verifies exact per-child negative aggregates and fixed admission expectations.', 'Initial primary postprocessor inventory failure and amendment remain separate immutable files; original acquisition unchanged.'],
    'auditorSha256': SHA(pathlib.Path(__file__).read_bytes()), 'members': members}
(HERE / 'independent-artifact-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps({'complete': True, 'auditSha256': SHA((HERE / 'independent-artifact-audit.json').read_bytes()), 'members': len(members), 'children': len(children), 'primaryRecords': len(primary), 'negativePasses': negative_passes, 'jmExpectations': mechanical_checks, 'product': candidate, 'diagnosticWasmSha256': diagnostic_hash}))
