"""Read-only original artifact audit; no compiler, parser or benchmark execution."""
import collections
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import zipfile

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SHA = lambda data: hashlib.sha256(data).hexdigest()
archive = HERE / 'original-artifact.zip'
assert SHA(archive.read_bytes()) == '8ddf1aca49709b03a17fa2e46aae67ce7de43fd8c303ef82e0c47fa07845e4db'
z = zipfile.ZipFile(archive)
members = {}
for item in z.infolist():
    path = pathlib.PurePosixPath(item.filename)
    assert not path.is_absolute() and '..' not in path.parts
    assert ((item.external_attr >> 16) & 0o170000) != 0o120000
    data = z.read(item)
    members[item.filename] = {'bytes': len(data), 'sha256': SHA(data), 'crc32': item.CRC}
assert len(members) == 44
read = lambda name: json.loads(z.read(name))
start, binding, result = read('preparation-start.json'), read('compiled-source-binding.json'), read('result.json')
local_binding = ROOT / 'experiments/numeric-suffix-972-build/binding.json'
assert SHA(local_binding.read_bytes()) == start['bindingSha256'] == '331f3ecafe5aeff9bea6c2415772d6c8b26b6620f5cb21bfdbbb0219202c9b05'
assert start['binding'] == json.loads(local_binding.read_bytes())
assert start['toolingHead'] == 'd28d74f9c1047491670942ec6e0414cc9c823101'
assert start['toolingTree'] == '169ea236aa1ba9a17583878be0b11d5f5cd795f9'
assert start['node'] == 'v22.22.0' and '21.1.8' in start['compiler'] and '21.1.8' in start['linker']
assert binding['baseline'] == start['binding']['baseline'] == result['baseline']
assert binding['candidateSource'] == start['binding']['candidateCSourceSha256']
assert binding['productFilesSha256'] == result['productFilesSha256']
assert len(binding['productFilesSha256']) == 6
product = HERE / 'product'
product.mkdir(exist_ok=True)
for name, digest in binding['productFilesSha256'].items():
    data = z.read('product/' + name)
    assert SHA(data) == digest
    if name.startswith('test/'):
        assert digest == start['binding']['qualificationFiles'][pathlib.PurePosixPath(name).name]
    path = product / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data
    else:
        path.write_bytes(data)
native = ['dev/data/dictionary-wasm/manifest.json', 'dev/data/dictionary-wasm/term-bank-parser.wasm', 'ext/js/dictionary/wasm/term-bank-parser.c']
assert sorted(x.strip()[2:] for x in binding['candidateTrackedChanges'].splitlines()) == native
assert binding['extWasmSha256'] == binding['productFilesSha256'][native[1]]
assert SHA(z.read('rebuilt-candidate.diff')) == binding['rebuiltDiffSha256']
assert sorted(re.findall(r'^diff --git a/(\S+) b/\S+$', z.read('rebuilt-candidate.diff').decode(), re.M)) == native
manifest = read('product/' + native[0])
assert manifest['toolchain'] == {'compilerVersion': '21.1.8', 'linkerVersion': '21.1.8'}
targets = {t['name']: t for t in manifest['targets']}
assert targets['term-bank-parser.wasm']['sha256'] == binding['extWasmSha256']
baseline_repo = ROOT / 'manabitan'
sources = sorted(p for p in (baseline_repo / 'ext/js/dictionary/wasm').rglob('*') if p.suffix.lower() in ('.c', '.h'))
source_rows = []
for path in sources:
    name = path.relative_to(baseline_repo).as_posix()
    data = z.read('product/' + name) if name == native[2] else path.read_bytes()
    source_rows.append((name, SHA(data)))
source_digest = SHA(''.join(name + '\0' + digest + '\n' for name, digest in source_rows).encode())
assert len(source_rows) == manifest['sourceFileCount'] == 14 and source_digest == manifest['sourceDigest']
# Independently reverse the preserved binary diff in a scratch copy to verify its baseline binding.
reverse = HERE / 'reverse-patch-verification-final'
assert not reverse.exists()
reverse.mkdir()
for name in native:
    path = reverse / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(z.read('product/' + name))
patch = HERE / 'rebuilt-candidate.diff'
patch.write_bytes(z.read('rebuilt-candidate.diff'))
for check in (True, False):
    command = ['git', 'apply', '--reverse'] + (['--check'] if check else []) + [str(patch)]
    call = subprocess.run(command, cwd=reverse, capture_output=True)
    assert call.returncode == 0, call.stderr.decode()
assert SHA((reverse / native[2]).read_bytes()) == binding['baseline']['cSha256']
assert SHA((reverse / native[1]).read_bytes()) == binding['baseline']['wasmSha256']
primary_path = HERE / 'primary-job.log'
primary = primary_path.read_text()
records = []
for line in primary.splitlines():
    m = re.search(r'\b(NUMERIC_972_BUILD_[A-Z]+) (\{.*)$', line)
    if m:
        records.append((m[1], json.loads(m[2])))
steps = {d['label']: d for tag, d in records if tag == 'NUMERIC_972_BUILD_STEP'}
receipts = [read(n) for n in members if n.endswith('.receipt.json')]
assert len(steps) == len(receipts) == 17
for receipt in receipts:
    assert receipt == steps[receipt['label']]
    assert receipt['exitCode'] == 0 and receipt['finishedEpoch'] >= receipt['startedEpoch']
    assert receipt['logSha256'] == SHA(z.read(receipt['label'] + '.log'))
assert len(records) == 18  # Producer logs17 command receipts and final result; start binding is artifact-only.
assert [d for tag, d in records if tag == 'NUMERIC_972_BUILD_RESULT'] == [result]
for name, expected in [('reproduce-baseline', binding['baseline']['wasmSha256']), ('build-native-candidate', binding['extWasmSha256']), ('reproduce-candidate', binding['extWasmSha256'])]:
    text = z.read(name + '.log').decode()
    payload = json.loads(text[text.index('{'):])
    assert payload['toolchain'] == manifest['toolchain']
    assert next(t['sha256'] for t in payload['targets'] if t['name'] == 'term-bank-parser.wasm') == expected
unit = re.sub(r'\x1b\[[0-9;]*m', '', z.read('complete-unit-suite.log').decode())
assert re.search(r'Test Files\s+671 passed\s+\(671\)', unit)
assert re.search(r'Tests\s+15180 passed\s+\|\s+47 skipped\s+\(15227\)', unit)
assert 'test/term-bank-row-suffix-reuse.test.js (32 tests)' in unit
assert 'test/term-bank-row-suffix-token-ends.test.js (9 tests)' in unit
options = re.sub(r'\x1b\[[0-9;]*m', '', z.read('options-unit-suite.log').decode())
assert re.search(r'Tests\s+32 passed\s+\(32\)', options)
dry = z.read('all-dry-build-targets.log').decode()
dry_targets = re.findall(r'^Building (.+)\.\.\.$', dry, re.M)
assert dry_targets == ['chrome', 'chrome-dev', 'chrome-playwright', 'firefox', 'firefox-dev', 'firefox-android', 'edge']
audit = {
    'schema': 1, 'complete': True, 'auditedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Original build-only ZIP, all44 members, exact six product files, source-digest/binary-diff and primary-log reconciliation; no local compilation/native execution/timing',
    'runId': 46126462448, 'jobId': 140922033124, 'artifactId': 15256173851,
    'artifactSha256': SHA(archive.read_bytes()), 'artifactBytes': archive.stat().st_size,
    'toolingHead': start['toolingHead'], 'toolingTree': start['toolingTree'], 'bindingSha256': start['bindingSha256'],
    'baseline': binding['baseline'], 'productFilesSha256': binding['productFilesSha256'],
    'runtimeWasmSha256': binding['extWasmSha256'], 'sourceDigest': source_digest, 'sourceFileCount': len(sources),
    'reversedDiffMatchesBaselineCAndWasm': True, 'rebuiltDiffSha256': binding['rebuiltDiffSha256'],
    'primaryLogSha256': SHA(primary_path.read_bytes()), 'primaryRecordCounts': dict(collections.Counter(t for t, _ in records)),
    'all17CommandReceiptsExactlyMatchPrimary': True, 'all17LogsHashVerified': True,
    'unit': {'files': 671, 'passed': 15180, 'skipped': 47, 'originalSuffixCases': 32, 'newTokenEndCases': 9},
    'optionsPassed': 32, 'dryBuildTargets': dry_targets,
    'scopedLint': 'Exit0; unchanged vendor/esbuild commonjs-variable-in-esm warning retained',
    'strictMainAndTestTypes': 'Both original command receipts exit0',
    'compiler': start['compiler'], 'linker': start['linker'], 'node': start['node'],
    'performanceObserved': False, 'currentBaseFullQualificationStillRequired': True,
    'members': members, 'auditorSha256': SHA(pathlib.Path(__file__).read_bytes())}
(HERE / 'independent-artifact-audit.json').write_text(json.dumps(audit, indent=2) + '\n')
print(json.dumps({'complete': True, 'auditSha256': SHA((HERE / 'independent-artifact-audit.json').read_bytes()), 'product': binding['productFilesSha256'], 'primaryRecords': len(records)}))
