#!/usr/bin/env python3
"""Author two isolated source-only ports. No compiler or parser is executed."""
import difflib
import hashlib
import json
import pathlib
import subprocess

base = pathlib.Path('/workspace/scratch/c563d487c718')
root = pathlib.Path(__file__).resolve().parent
merged = (root / 'merged-term-bank-parser.c').read_text()
numeric = (base / 'experiments/row-suffix-numeric-original-preflight/reconstructed-source/ext/js/dictionary/wasm/term-bank-parser.c').read_text()
selector = (base / 'experiments/jmdict-prior-streak-selector/term-bank-parser.c').read_text()
sha_text = lambda value: hashlib.sha256(value.encode()).hexdigest()
assert sha_text(merged) == '7e836d21cb68165dc0fd6fe8aec074d50b77706debe2360b352b9cc34a67d24a'
assert sha_text(numeric) == '461021621f35788899ab4b5b62603423f54e0ee766ff8f1ca20529fca4da1372'
assert sha_text(selector) == 'f622f057b7de9db9082d79c6d67eb7d93b86d74cb5ec9b1674d8e9a67f6456fb'

def once(source, old, new):
    assert source.count(old) == 1, (old, source.count(old))
    return source.replace(old, new, 1)

def function(source, name):
    start = source.index('static int ' + name + '(')
    end = source.index('\n}\n', start) + 3
    return source[start:end]

def inside_function(source, name, old, new):
    original = function(source, name)
    return once(source, original, once(original, old, new))

def interner_numeric(source):
    start = source.index('        const TermRowMeta* parsed_row = &rows[row_count];')
    last = '        sequences[row_count] = sequence;'
    end = source.index(last, start) + len(last)
    return source[start:end]

helper_start = numeric.index('/* The current expression and reading have their own validation and identity.')
helper_end = numeric.index('/* Strict source validation has exactly eight fields', helper_start)
helper = numeric[helper_start:helper_end]
composed = once(merged,
    '/* The witness array comes only from reuse_validated_glossary: each ID proves\n * full raw-byte equality with a previously parsed glossary in this invocation.',
    '/* Glossary and strict-row-suffix reuse supply the witness array: each ID\n * proves full raw-byte equality with an earlier glossary in this invocation.')
marker = '/* Strict source validation has exactly eight fields'
composed = once(composed, marker, helper + marker)
old = '    uint32_t* score_token_end,\n    uint32_t* sequence_token_end\n) {'
new = '    uint32_t* score_token_end,\n    uint32_t* sequence_token_end,\n    int reuse_row_suffix\n) {'
assert composed.count(old) == 2
composed = composed.replace(old, new)
hook = "    if (src[i] == 'n') {\n        if (len - i < 4u || !is_null_token(src, i, 4u)) { return 0; }"
branch = '''    if (reuse_row_suffix && prior_count > 0u && reuse_validated_format3_suffix(src, len, i, &prior_rows[prior_count - 1u], meta, out_next)) {
        // The full suffix proof validates both numbers, but the fused caller
        // also consumes their token ends. Recreate only those bounded spans.
        if (score_token_end != 0 && !scan_scalar_span(src, len, meta->score_start, score_token_end)) { return 0; }
        if (sequence_token_end != 0 && meta->sequence_start != 0xffffffffu &&
            !scan_scalar_span(src, len, meta->sequence_start, sequence_token_end)) { return 0; }
        if (glossary_witness != 0) { *glossary_witness = prior_count - 1u; }
        return 1;
    }

'''
composed = once(composed, hook, branch + hook)
# The generic permissive parser has its own occurrence; change strict mode only.
composed = inside_function(composed, 'parse_format3_row',
    '!(glossary_witness != 0 && reuse_validated_glossary(',
    '!(glossary_lookback > 0u && glossary_witness != 0 && reuse_validated_glossary(')
composed = once(composed, '            score_token_end, sequence_token_end\n',
    '            score_token_end, sequence_token_end, reuse_row_suffix\n')
for start in ['src, json_len, i, &rows[row_count]', 'src, source.end, source.position, &rows[row_count]']:
    old = f'parse_row_single_pass({start}, media_hints, &row_end, 0, 0u, 0, 0u, validate_glossary_types, 0, 0, 0)'
    composed = once(composed, old, old[:-1] + ', 0)')
start = numeric.index('        // A preceding exact full-content reuse and equal adjacent numeric')
end = numeric.index('        if (!parse_row_single_pass(', start)
admission = numeric[start:end]
composed = once(composed, '        uint32_t sequence_token_end = 0u;\n        if (!parse_row_single_pass(',
    '        uint32_t sequence_token_end = 0u;\n' + admission + '        if (!parse_row_single_pass(')
old_call = '''                rows, row_count, glossary_lookback > 0u ? &glossary_witness : 0, glossary_lookback,
                validate_glossary_types != 0u, &key_escape_mask, &score_token_end, &sequence_token_end)) {'''
new_call = '''                rows, row_count, (glossary_lookback > 0u || reuse_row_suffix) ? &glossary_witness : 0,
                glossary_lookback, validate_glossary_types != 0u, &key_escape_mask,
                &score_token_end, &sequence_token_end, reuse_row_suffix)) {'''
composed = once(composed, old_call, new_call)
assert function(composed, 'reuse_validated_format3_suffix') == function(numeric, 'reuse_validated_format3_suffix')
assert function(composed, 'parse_compact_glossary_list') == function(merged, 'parse_compact_glossary_list')
assert interner_numeric(composed) == interner_numeric(merged)

# The selector port is a separate candidate, never combined with suffix reuse.
start = selector.index('/* Admit a glossary probe without changing the interner')
end = selector.index('/* Samples only reject candidates.', start)
selected = once(merged, '/* Samples only reject candidates.', selector[start:end] + '/* Samples only reject candidates.')
start = selector.index('    if (glossary_witness != 0 && glossary_lookback == 0u && prior_count > 0u')
end = selector.index('    if (\n        !(glossary_witness != 0 && glossary_lookback > 0u', start)
selection = selector[start:end]
selected = once(selected,
    '    meta->glossary_requires_text_normalization = 0u;\n    if (\n        !(glossary_witness != 0 && reuse_validated_glossary(',
    '    meta->glossary_requires_text_normalization = 0u;\n' + selection + '    if (\n        !(glossary_witness != 0 && glossary_lookback > 0u && reuse_validated_glossary(')
new_call = '''                rows, row_count, glossary_lookback > 0u ||
                    (validated_glossary_reuse_enabled && validate_glossary_types != 0u && row_count > 0u && recent_content_match_streak != 0u) ?
                    &glossary_witness : 0, glossary_lookback,
                validate_glossary_types != 0u, &key_escape_mask, &score_token_end, &sequence_token_end)) {'''
selected = once(selected, old_call, new_call)
selected = once(selected,
    '            if (glossary_witness != 0xffffffffu) {\n                glossary_reuse_probe_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;',
    '            if (glossary_witness != 0xffffffffu && glossary_lookback > 0u) {\n                glossary_reuse_probe_budget = VALIDATED_GLOSSARY_REUSE_PROBE_BUDGET;')
selected = once(selected,
    '            // The glossary witness is the newest matching raw glossary. If the\n            // remaining fields match too, it is the newest full-content match.',
    '            // Newer rows skipped by prefix selection fail a necessary content\n            // condition. If the remaining fields match, this witness is still\n            // the newest full-content match.')
assert function(selected, 'adjacent_key_matches') == function(selector, 'adjacent_key_matches')
assert function(selected, 'parse_compact_glossary_list') == function(merged, 'parse_compact_glossary_list')
assert interner_numeric(selected) == interner_numeric(merged)
assert 'reuse_validated_format3_suffix' not in selected and 'adjacent_key_matches' not in composed

files = []
for label, value in [('numeric-suffix', composed), ('prior-streak-selector', selected)]:
    target = root / (label + '-on-dcfc02a0.c')
    target.write_text(value)
    difference = 'diff --git a/ext/js/dictionary/wasm/term-bank-parser.c b/ext/js/dictionary/wasm/term-bank-parser.c\n' + ''.join(difflib.unified_diff(
        merged.splitlines(True), value.splitlines(True), fromfile='a/ext/js/dictionary/wasm/term-bank-parser.c', tofile='b/ext/js/dictionary/wasm/term-bank-parser.c'))
    patch = root / (label + '-on-dcfc02a0.patch')
    patch.write_text(difference)
    result = subprocess.run(['git', 'apply', '--check', str(patch)], cwd=root / 'source-audit-base', capture_output=True, text=True)
    assert result.returncode == 0, result.stderr
    files.append({'candidate': label, 'sourceFile': target.name, 'sourceSha256': sha_text(value),
        'patchFile': patch.name, 'patchSha256': sha_text(difference), 'patchAppliesToExactMergedSource': True,
        'compactListFunctionUnchanged': True, 'lateInternerAndNumericBlockUnchanged': True,
        'addedLines': sum(line.startswith('+') and not line.startswith('+++') for line in difference.splitlines()),
        'removedLines': sum(line.startswith('-') and not line.startswith('---') for line in difference.splitlines())})
receipt = {'scope': 'Two separate source-only compositions for dcfc02a0; no compiler, native execution, timing, artifact generation, branch or PR',
    'mergedSourceSha256': sha_text(merged), 'numericOriginalSourceSha256': sha_text(numeric), 'selectorOriginalSourceSha256': sha_text(selector),
    'duplicateConceptCheck': {'mergedContainsSuffixHelper': 'reuse_validated_format3_suffix' in merged,
        'mergedContainsSuffixAdmission': 'reuse_row_suffix' in merged, 'mergedContainsSelectorHelper': 'adjacent_key_matches' in merged,
        'mergedContainsPrefixSelector': 'tags_prefix' in merged}, 'changes': files,
    'numericComposition': 'After exact full-row suffix proof only, scan current score and non-null sequence token bounds into existing out-pointers; preserve normal merged number writes and compact-list path; unchanged suffix proof/admission',
    'selectorComposition': 'Only context/call-signature adaptation; exact frozen helper/selector and caller old-budget isolation; retain merged normal token-end writes and compact-list path',
    'lateInternerAndNumericBlockSha256': sha_text(interner_numeric(merged)),
    'compactListFunctionSha256': sha_text(function(merged, 'parse_compact_glossary_list'))}
(root / 'composition-source-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
