import {readFileSync, writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import * as espree from 'espree';
import * as fixtures from './test/term-bank-row-suffix-token-end-fixtures.js';
const names = ['term-bank-row-suffix-token-end-fixtures.js', 'term-bank-row-suffix-token-ends.test.js', 'term-bank-row-suffix-reuse.test.js'];
const hash = (value) => createHash('sha256').update(value).digest('hex');
function normalize(value) {
    if (Array.isArray(value)) { return value.map(normalize); }
    if (value !== null && typeof value === 'object') {
        return Object.fromEntries(Object.entries(value).filter(([key]) => !['start', 'end', 'loc', 'range'].includes(key)).map(([key, item]) => [key, normalize(item)]));
    }
    return value;
}
const files = Object.fromEntries(names.map((name) => {
    const source = readFileSync(new URL(`./test/${name}`, import.meta.url), 'utf8');
    const ast = normalize(espree.parse(source, {ecmaVersion: 'latest', sourceType: 'module'}));
    return [name, {sourceSha256: hash(source), astSha256: hash(JSON.stringify(ast)), ast}];
}));
const fixtureExports = JSON.parse(JSON.stringify(fixtures));
writeFileSync(process.argv[2], JSON.stringify({scope: 'Pure fixture-data import and source AST comparison only; test modules are parsed, never imported; no native parser or timing', files, fixtureExports, fixtureExportsSha256: hash(JSON.stringify(fixtureExports))}, null, 2) + '\n');
