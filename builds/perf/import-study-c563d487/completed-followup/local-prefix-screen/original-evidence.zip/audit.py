#!/usr/bin/env python3
"""Independently replay all local raw receipts; never invoke the parser."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import subprocess

root = Path(__file__).resolve().parent
output = root / 'observations'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):
    return json.loads(path.read_text())
plan_path = root / 'preregistration.json'
report_path = output / 'result.json'
assert sha(plan_path) == 'fa0e1589823ed0a50211072b2ac7f423538f4021e85a7b8fc76d4902a28b0549'
assert sha(root / 'controller.py') == 'adb7cf2d45a471c211c774a33048e11c0ab10555fbb680c2e7ef889310b95c4a'
assert sha(root / 'independent-review.json') == 'be16e840f1abd8017c0511d97ad2cb46033468ff2f5dd5ad4365f756f370f5ee'
assert sha(report_path) == '60066ddbfb3291bc184cc7f73f4afce25fe3903f903b828bcb9636199947e78a'
plan, report = read(plan_path), read(report_path)
assert report['complete'] and len(report['observations']) == len(report['children']) == 16
assert report['plan'] == plan and report['preregistrationSha256'] == sha(plan_path)
assert len(report['resourceSnapshots']) == 34
assert all(v is None for snap in report['resourceSnapshots'] for v in snap['snapshot']['cgroup'].values())
assert report['runtime']['localCompilationPerformed'] is False and report['runtime']['localCompilerVersionClaimed'] is False
assert report['runtime']['lscpu']['exitCode'] == 1 and report['runtime']['affinity'] == list(range(9))
assert report['runtime']['procCpuinfoSummary']['processors'] == 9
for name in ['NODE_OPTIONS', 'NODE_COMPILE_CACHE', 'NODE_DISABLE_COMPILE_CACHE']:
    assert report['runtime']['inheritedEnvironmentInfluenceHashes'][name] == {'present': False, 'valueSha256': None}
inventory = read(root / 'source-lib-inventory.json')
assert sha(root / 'source-lib-inventory.json') == plan['inventorySha256']
for arm, identity in plan['sources'].items():
    source = Path(identity['root'])
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=source, text=True).strip() == identity['head']
    assert subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=source, text=True).strip() == identity['trackedChanges']
    for name, value in inventory[arm].items():
        path = source / name
        assert path.stat().st_size == value['bytes'] and sha(path) == value['sha256'], (arm, name)
reference_path = Path(plan['priorExcludedMechanics']['rawReceipt'])
assert sha(reference_path) == plan['priorExcludedMechanics']['rawReceiptSha256']
reference = read(reference_path)
schedule = [{'pair': i, 'arm': arm} for i in range(4) for arm in ('ABCD' if i % 2 == 0 else 'DCBA')]
assert plan['schedule'] == schedule
assert len(list(output.glob('pair-*.stdout.json'))) == len(list(output.glob('pair-*.stderr.log'))) == len(list(output.glob('pair-*.child-status.json'))) == 16
data_by_key = {}
raw_identities = []
last_end = None
for step, embedded, child in zip(schedule, report['observations'], report['children']):
    assert {k: embedded[k] for k in ['pair', 'arm']} == step
    label = f"pair-{step['pair']}-{step['arm']}"
    stdout, stderr, status_path = [output / (label + suffix) for suffix in ['.stdout.json', '.stderr.log', '.child-status.json']]
    raw, status = read(stdout), read(status_path)
    assert raw == embedded['result'] and status == child
    assert status['status'] == 'completed' and status['exitCode'] == 0
    assert status['stdoutSha256'] == sha(stdout) and status['stderrSha256'] == sha(stderr)
    assert status['finishedEpoch'] > status['startedEpoch']
    if last_end is not None:
        assert status['startedEpoch'] > last_end
    last_end = status['finishedEpoch']
    role = 'candidate' if step['arm'] == 'B' else 'baseline'
    identity = plan['sources'][role]
    assert status['command'] == [plan['node']['path'], '--expose-gc', '--max-old-space-size=512', plan['runner']['path'], 'jmdict',
                                 '--source-root', identity['root'], '--cache-dir', plan['cacheDir']]
    assert raw['sourceRoot'] == identity['root'] and raw['gitHead'] == identity['head'] and raw['gitTree'] == identity['tree']
    assert raw['trackedChanges'] == identity['trackedChanges'] and raw['wasmSha256'] == identity['wasmSha256']
    for name, value in raw['sourceHashes'].items():
        assert value == inventory[role][name]['sha256']
    assert raw['node'] == 'v22.22.0' and raw['warmupPasses'] == 2
    assert raw['diagnostic'] is None and raw['diagnosticWasm'] is None
    assert raw['runnerSha256'] == plan['runner']['sha256'] and raw['diagnosticFieldsSha256'] == plan['diagnosticFields']['sha256']
    assert raw['dictionary'] == 'jmdict' and raw['flags'] == {} and raw['validateGlossaryTypes'] is True
    assert raw['filesPerGroup'] == 7 and raw['rows'] == 528299
    assert raw['fusedAttempts'] == 8 and raw['fusedFallbacks'] == 0 and len(raw['groupReceipts']) == 8
    for key in ['rows', 'digest', 'indexBytes', 'archiveSha256', 'lockSha256', 'flags', 'filesPerGroup', 'recentContentDedupHitCount']:
        assert raw[key] == reference[key]
    counter = 'totalGlossaryReuses' if role == 'candidate' else 'originalGlossaryReuses'
    assert raw['glossaryReuseCount'] == reference['diagnostic'][counter]
    for group, original in zip(raw['groupReceipts'], reference['groupReceipts']):
        for key in ['group', 'banks', 'rows', 'fusedAttempts', 'fusedFallbacks', 'recentContentDedupHitCount']:
            assert group[key] == original[key]
        assert group['diagnosticBefore'] is None and group['diagnosticAfter'] is None
        assert group['glossaryReuseCount'] == original['diagnosticAfter'][counter] - (original['diagnosticBefore'] or {}).get(counter, 0)
    before, after = report['resourceSnapshots'][1 + 2 * len(raw_identities):3 + 2 * len(raw_identities)]
    assert before['phase'] == 'before-child' and after['phase'] == 'after-child' and before['label'] == after['label'] == label
    data_by_key[(step['pair'], step['arm'])] = raw
    raw_identities.append({**step, 'label': label, 'stdoutSha256': sha(stdout), 'stderrSha256': sha(stderr),
                           'stderrBytes': stderr.stat().st_size, 'statusSha256': sha(status_path),
                           'startedEpoch': status['startedEpoch'], 'finishedEpoch': status['finishedEpoch']})
metrics = {}
for metric in plan['analysis']['metrics']:
    for name, a, b in [('candidate', 'A', 'B'), ('identicalControl', 'C', 'D')]:
        left = [data_by_key[(i, a)][metric] for i in range(4)]
        right = [data_by_key[(i, b)][metric] for i in range(4)]
        assert all(math.isfinite(value) and value > 0 for value in left + right)
        changes = [(new - old) / old * 100 for old, new in zip(left, right)]
        ordered = sorted(changes)
        derived = {'baselineValues': left, 'comparisonValues': right, 'pairedChangesPercent': changes,
                   'medianPairedChangePercent': (ordered[1] + ordered[2]) / 2,
                   'fasterPairs': sum(value < 0 for value in changes),
                   'equalWorkChangePercent': (sum(right) - sum(left)) / sum(left) * 100}
        stored = report['summary'][name + '.' + metric]
        for key, value in derived.items():
            first, second = (value, stored[key]) if isinstance(value, list) else ([value], [stored[key]])
            assert len(first) == len(second) and all(math.isclose(x, y, rel_tol=0, abs_tol=1e-9) for x, y in zip(first, second))
        metrics[name + '.' + metric] = derived
candidate = metrics['candidate.elapsedMs']
control = metrics['identicalControl.elapsedMs']
assert candidate['fasterPairs'] == 3
assert max(abs(v) for v in control['pairedChangesPercent']) > abs(candidate['medianPairedChangePercent'])
result = {
    'schema': 1, 'completeAudit': True, 'recordedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Separate local sequential component only, every fixed raw child retained; no browser/import/memory/PR qualification and no pooling with hosted results',
    'decision': 'Inconclusive: same-code variation is much larger than the candidate median. No timing gain is established and no rerun is authorized.',
    'plannedObservations': 16, 'acceptedObservations': 16, 'freshChildren': 16, 'warmupsPerChild': 2,
    'replacementChildren': 0, 'rowsPerObservation': 528299, 'groupsPerObservation': 8,
    'digest': reference['digest'], 'allRichOutputAndPerGroupMechanicsMatch': True,
    'baselineGlossaryReuses': 54629, 'candidateGlossaryReuses': 134731,
    'planSha256': sha(plan_path), 'controllerSha256': sha(root / 'controller.py'),
    'preregisteredIndependentReviewSha256': sha(root / 'independent-review.json'),
    'preMeasurementResourceSha256': sha(root / 'pre-measurement-resources.json'),
    'originalResultSha256': sha(report_path), 'sourceLibInventorySha256': sha(root / 'source-lib-inventory.json'),
    'sourceLibFilesPerArm': {name: len(files) for name, files in inventory.items()},
    'sources': plan['sources'], 'nodeSha256': plan['node']['sha256'], 'archiveSha256': plan['archive']['sha256'],
    'rawChildren': raw_identities, 'metrics': metrics,
    'maxWasmHeapBytesByArm': {arm: sorted({value['maxWasmHeapBytes'] for (pair, name), value in data_by_key.items() if name == arm}) for arm in 'ABCD'},
    'resourceSnapshots': len(report['resourceSnapshots']), 'resourceLimit': 'lscpu/cgroup visibility unavailable; process list limited to current namespace. No whole-host quietness claim.',
    'allOutliersRetained': True, 'controlSubtractionApplied': False, 'hostedOriginalAndCorrectedCohortsUnchanged': True,
    'auditorSha256': sha(Path(__file__)),
}
target = root / 'independent-raw-audit.json'
assert not target.exists()
target.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'completeAudit': True, 'observations': 16, 'decision': result['decision'],
                  'auditSha256': sha(target), 'elapsedMedian': candidate['medianPairedChangePercent'],
                  'controlElapsedMedian': control['medianPairedChangePercent'],
                  'maxWasmHeapBytesByArm': result['maxWasmHeapBytesByArm']}))
