#!/usr/bin/env python3
"""Prepare a bounded, source-bound local screen without running the parser."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess

root = Path(__file__).resolve().parent
experiments = root.parent
base = experiments.parent / 'manabitan'
candidate = root / 'candidate'
source = experiments / 'jmdict-prefix-selector-evidence/jmdict/reconstructed-product'
hosted = experiments / 'jmdict-prefix-selector/hosted'
archive = experiments / 'sequence-probe-opportunity/JMdict.zip'
baseline = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
hashes = {
    'ext/js/dictionary/wasm/term-bank-parser.c': '358428813d7452f55dfd084ee84cc1437e944bd790acaed41adf1634d477cf68',
    'dev/data/dictionary-wasm/term-bank-parser.wasm': 'b188cd7ca5ba1802eec6edf18b71f0ed3a98a471cab7c59dc2e5ae473999a6de',
    'dev/data/dictionary-wasm/manifest.json': '2c4f561f03e2b97b44747bcd18529388ef40876d24d1a42f40d9a6740eeb74ff',
}
def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            h.update(chunk)
    return h.hexdigest()

assert not candidate.exists()
assert sha(archive) == '3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f'
assert archive.stat().st_size == 15645766
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=base, text=True).strip() == baseline
assert subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=base, text=True).strip() == ''
for name, expected in hashes.items():
    assert sha(source / name) == expected
record = {'schema': 1, 'complete': False, 'preparedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Preparation only; no compile, dependency install, parser invocation or timing acquisition',
          'baseline': str(base), 'candidate': str(candidate), 'baselineCommit': baseline,
          'diskAvailableBeforeBytes': shutil.disk_usage(root).free, 'newDiskBudgetBytes': 30 * 1024 * 1024,
          'commands': [], 'copiedProductHashes': hashes}
target = root / 'preparation.json'
assert not target.exists()
def save():
    target.write_text(json.dumps(record, indent=2) + '\n')
def git(cwd, *args):
    result = subprocess.run(['git', *args], cwd=cwd, text=True, capture_output=True)
    record['commands'].append({'argv': ['git', *args], 'cwd': str(cwd), 'exitCode': result.returncode,
                               'stdout': result.stdout, 'stderr': result.stderr})
    save()
    assert result.returncode == 0
    return result.stdout.strip()
save()
try:
    git(base, 'worktree', 'add', '--detach', '--no-checkout', str(candidate), baseline)
    git(candidate, 'sparse-checkout', 'set', '--no-cone', '--no-sparse-index', '/ext/js/', '/dev/data/dictionary-wasm/',
        '/package.json', '/package-lock.json', '/AGENTS.md')
    git(candidate, 'read-tree', '-mu', 'HEAD')
    assert git(candidate, 'status', '--porcelain', '--untracked-files=no') == ''
    assert git(candidate, 'rev-parse', 'HEAD') == baseline
    for name, expected in hashes.items():
        shutil.copyfile(source / name, candidate / name)
        assert sha(candidate / name) == expected
    # Runtime dependencies are read-only hard links. Never overwrite the shared
    # parser link: remove that directory entry before copying candidate bytes.
    lib = candidate / 'ext/lib'
    lib.mkdir()
    linked = []
    for current in sorted((base / 'ext/lib').rglob('*')):
        relative = current.relative_to(base / 'ext/lib')
        dest = lib / relative
        if current.is_dir():
            dest.mkdir(exist_ok=True)
        elif current.is_symlink():
            dest.symlink_to(os.readlink(current))
        elif current.is_file():
            dest.parent.mkdir(parents=True, exist_ok=True)
            os.link(current, dest)
            linked.append(str(relative))
    runtime = lib / 'term-bank-parser.wasm'
    assert runtime.stat().st_ino == (base / 'ext/lib/term-bank-parser.wasm').stat().st_ino
    runtime.unlink()
    shutil.copyfile(candidate / 'dev/data/dictionary-wasm/term-bank-parser.wasm', runtime)
    assert runtime.stat().st_ino != (base / 'ext/lib/term-bank-parser.wasm').stat().st_ino
    assert sha(runtime) == hashes['dev/data/dictionary-wasm/term-bank-parser.wasm']
    assert sha(base / 'ext/lib/term-bank-parser.wasm') == '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee'
    (candidate / 'node_modules').symlink_to(base / 'node_modules', target_is_directory=True)
    record['hardlinkedRuntimeFiles'] = linked
    record['candidateParserIsIndependentInode'] = True

    runner_root = root / 'runner'
    runner_dir = runner_root / 'dev/perf/x/hosted'
    runner_dir.mkdir(parents=True)
    (runner_root / 'test/perf').mkdir(parents=True)
    for name in ['screen.mjs', 'diagnostic-fields.json']:
        shutil.copyfile(hosted / name, runner_dir / name)
        assert sha(runner_dir / name) == sha(hosted / name)
    assert sha(runner_dir / 'screen.mjs') == '8519bfea747260803f87c1358a34f1d4a1ff431de891ffa3603ca70a422a19fa'
    shutil.copyfile(base / 'test/perf/dictionaries.lock.json', runner_root / 'test/perf/dictionaries.lock.json')
    (runner_root / 'node_modules').symlink_to(base / 'node_modules', target_is_directory=True)
    cache = root / 'cache'
    cache.mkdir()
    (cache / 'JMdict.zip').symlink_to(archive)
    changed = git(candidate, 'diff', '--name-only').splitlines()
    assert set(changed) == set(hashes)
    assert git(base, 'status', '--porcelain', '--untracked-files=no') == ''
    record.update(complete=True, candidateTrackedChanges=git(candidate, 'status', '--porcelain', '--untracked-files=no'),
                  candidateHead=git(candidate, 'rev-parse', 'HEAD'), candidateTree=git(candidate, 'rev-parse', 'HEAD^{tree}'),
                  sparsePatterns=(Path(git(candidate, 'rev-parse', '--git-path', 'info/sparse-checkout'))).read_text(),
                  diskAvailableAfterBytes=shutil.disk_usage(root).free, driverSha256=sha(Path(__file__)))
    save()
    print(json.dumps({'complete': True, 'newTrackedChanges': changed, 'diskAvailableBytes': record['diskAvailableAfterBytes'],
                      'receiptSha256': sha(target)}))
except Exception as error:
    record['error'] = {'type': type(error).__name__, 'message': str(error)}
    save()
    raise
