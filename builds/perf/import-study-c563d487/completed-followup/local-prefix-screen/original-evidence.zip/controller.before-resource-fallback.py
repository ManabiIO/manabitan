#!/usr/bin/env python3
"""An explicitly reviewed local cohort; no build, download, tuning, or retry."""
import argparse
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import shutil
import statistics
import subprocess
import time

HERE = Path(__file__).resolve().parent
BASE_COMMIT = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
TREE = 'd99ea4d04658f7ec1c76acdc5f3684594212a471'
CHANGED = {'ext/js/dictionary/wasm/term-bank-parser.c', 'dev/data/dictionary-wasm/term-bank-parser.wasm',
           'dev/data/dictionary-wasm/manifest.json'}
METRICS = ['elapsedMs', 'cpuMs', 'inflateMs', 'inflateCpuMs', 'parseMs', 'nativeParseMs', 'lookupMs']

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def git(root, *args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

def identity(root):
    root = Path(root)
    return {'root': str(root), 'head': git(root, 'rev-parse', 'HEAD'), 'tree': git(root, 'rev-parse', 'HEAD^{tree}'),
            'trackedChanges': git(root, 'status', '--porcelain', '--untracked-files=no'),
            'changedPaths': sorted(git(root, 'diff', '--name-only').splitlines()),
            'cSha256': sha(root / 'ext/js/dictionary/wasm/term-bank-parser.c'),
            'wasmSha256': sha(root / 'ext/lib/term-bank-parser.wasm'),
            'trackedWasmSha256': sha(root / 'dev/data/dictionary-wasm/term-bank-parser.wasm'),
            'manifestSha256': sha(root / 'dev/data/dictionary-wasm/manifest.json'),
            'dependencyLockSha256': sha(root / 'package-lock.json')}

def file_inventory(root):
    root = Path(root)
    files = [root / 'package.json', root / 'package-lock.json']
    for relative in ['ext/js', 'ext/lib', 'dev/data/dictionary-wasm']:
        files.extend(p for p in (root / relative).rglob('*') if p.is_file())
    return {str(p.relative_to(root)): {'bytes': p.stat().st_size, 'sha256': sha(p),
             'symlinkTarget': os.readlink(p) if p.is_symlink() else None} for p in sorted(files)}

def snapshot():
    values = {}
    for name in ['memory.current', 'memory.max', 'memory.events', 'memory.pressure', 'cpu.max', 'cpu.stat',
                 'cpu.pressure', 'io.pressure', 'cpuset.cpus.effective']:
        path = Path('/sys/fs/cgroup') / name
        values[name] = path.read_text().strip() if path.exists() else None
    meminfo = {}
    for line in Path('/proc/meminfo').read_text().splitlines():
        name, value = line.split(':', 1)
        if name in ['MemTotal', 'MemAvailable', 'SwapTotal', 'SwapFree']:
            meminfo[name] = value.strip()
    return {'atUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'processesWithoutArguments': subprocess.check_output(['ps', '-eo', 'pid,ppid,comm,state,pcpu,pmem'], text=True),
            'cgroup': values, 'memory': meminfo, 'loadAverage': list(os.getloadavg()),
            'diskAvailableBytes': shutil.disk_usage(HERE).free}

def environment():
    selected = {}
    for name in ['NODE_OPTIONS', 'NODE_COMPILE_CACHE', 'NODE_DISABLE_COMPILE_CACHE', 'NODE_USE_ENV_PROXY',
                 'NODE_PATH', 'UV_THREADPOOL_SIZE', 'LD_PRELOAD', 'HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'NO_PROXY']:
        value = os.environ.get(name)
        selected[name] = {'present': value is not None,
                          'valueSha256': None if value is None else hashlib.sha256(value.encode()).hexdigest()}
    return selected

def runtime():
    return {'python': platform.python_version(), 'uname': list(platform.uname()),
            'cpuDescription': subprocess.check_output(['lscpu'], text=True),
            'inheritedEnvironmentInfluenceHashes': environment(), 'browser': None,
            'localCompilationPerformed': False, 'localCompilerVersionClaimed': False}

def summarize(observations):
    by_key = {(o['pair'], o['arm']): o['result'] for o in observations}
    assert len(by_key) == 16
    result = {}
    for metric in METRICS:
        for name, first, second in [('candidate', 'A', 'B'), ('identicalControl', 'C', 'D')]:
            a = [by_key[(i, first)][metric] for i in range(4)]
            b = [by_key[(i, second)][metric] for i in range(4)]
            assert all(math.isfinite(value) and value > 0 for value in a + b)
            ratios = [100 * (right / left - 1) for left, right in zip(a, b)]
            result[name + '.' + metric] = {'baselineValues': a, 'comparisonValues': b, 'pairedChangesPercent': ratios,
                'medianPairedChangePercent': statistics.median(ratios), 'fasterPairs': sum(x < 0 for x in ratios),
                'equalWorkChangePercent': 100 * (sum(b) / sum(a) - 1)}
    candidate = result['candidate.elapsedMs']
    control = result['identicalControl.elapsedMs']
    result['descriptiveControlComparison'] = {
        'largestAbsoluteSameCodeChangePercent': max(abs(x) for x in control['pairedChangesPercent']),
        'allFourCandidatePairsFaster': candidate['fasterPairs'] == 4,
        'absoluteCandidateMedianExceedsLargestAbsoluteControlChange': abs(candidate['medianPairedChangePercent']) > max(abs(x) for x in control['pairedChangesPercent']),
        'scope': 'Descriptive local component comparison only. Noisy or overlapping controls leave attribution inconclusive; this is not an equivalence, browser, complete-import, memory or PR gate.'}
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan-sha', required=True, help='Exact independently reviewed preregistration SHA-256')
    args = parser.parse_args()
    plan_path = HERE / 'preregistration.json'
    assert sha(plan_path) == args.plan_sha
    plan = read(plan_path)
    assert sha(__file__) == plan['controllerSha256']
    assert plan['measurementCount'] == 16 and plan['schedule'] == [
        {'pair': i, 'arm': arm} for i in range(4) for arm in ('ABCD' if i % 2 == 0 else 'DCBA')]
    output = HERE / 'observations'
    assert not output.exists(), 'A local cohort cannot be replaced or resumed selectively'
    output.mkdir()
    report_path = output / 'result.json'
    report = {'schema': 1, 'complete': False, 'preregistrationSha256': args.plan_sha, 'plan': plan,
              'runtime': runtime(), 'scope': plan['scope'], 'observations': [], 'children': [],
              'resourceSnapshots': [{'phase': 'before-cohort', 'snapshot': snapshot()}]}
    def save():
        report_path.write_text(json.dumps(report, indent=2) + '\n')
    save()
    baseline = Path(plan['sources']['baseline']['root'])
    candidate = Path(plan['sources']['candidate']['root'])
    runner = Path(plan['runner']['path'])
    node = Path(plan['node']['path'])
    inventory_path = HERE / 'source-lib-inventory.json'
    assert sha(inventory_path) == plan['inventorySha256']
    inventories = read(inventory_path)
    reference = read(plan['priorExcludedMechanics']['rawReceipt'])
    assert sha(plan['priorExcludedMechanics']['rawReceipt']) == plan['priorExcludedMechanics']['rawReceiptSha256']

    def check_inputs():
        assert sha(plan_path) == args.plan_sha and sha(__file__) == plan['controllerSha256']
        for arm, root in [('baseline', baseline), ('candidate', candidate)]:
            assert identity(root) == plan['sources'][arm], arm
            assert file_inventory(root) == inventories[arm], arm
        for entry in [plan['runner'], plan['diagnosticFields'], plan['node'], plan['lock'], plan['archive']]:
            assert sha(entry['path']) == entry['sha256'], entry['path']
        assert (candidate / 'ext/lib/term-bank-parser.wasm').stat().st_ino != (baseline / 'ext/lib/term-bank-parser.wasm').stat().st_ino
        assert environment() == report['runtime']['inheritedEnvironmentInfluenceHashes']

    try:
        for step in plan['schedule']:
            check_inputs()
            source_root = candidate if step['arm'] == 'B' else baseline
            label = f"pair-{step['pair']}-{step['arm']}"
            command = [str(node), '--expose-gc', '--max-old-space-size=512', str(runner), 'jmdict',
                       '--source-root', str(source_root), '--cache-dir', plan['cacheDir']]
            report['resourceSnapshots'].append({'phase': 'before-child', 'label': label, 'snapshot': snapshot()})
            status = {'label': label, 'command': command, 'status': 'running', 'startedEpoch': time.time()}
            report['children'].append(status)
            save()
            stdout_path, stderr_path = output / (label + '.stdout.json'), output / (label + '.stderr.log')
            try:
                with stdout_path.open('w') as stdout, stderr_path.open('w') as stderr:
                    process = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=180)
                status.update(status='completed', exitCode=process.returncode, finishedEpoch=time.time())
            except subprocess.TimeoutExpired:
                status.update(status='timeout', finishedEpoch=time.time(), timeoutSeconds=180)
                raise
            finally:
                status['stdoutSha256'] = sha(stdout_path)
                status['stderrSha256'] = sha(stderr_path)
                (output / (label + '.child-status.json')).write_text(json.dumps(status, indent=2) + '\n')
                report['resourceSnapshots'].append({'phase': 'after-child', 'label': label, 'snapshot': snapshot()})
                save()
            assert process.returncode == 0, (label, process.returncode)
            data = read(stdout_path)
            identity_expected = plan['sources']['candidate' if step['arm'] == 'B' else 'baseline']
            assert data['sourceRoot'] == str(source_root) and data['gitHead'] == BASE_COMMIT and data['gitTree'] == TREE
            assert data['trackedChanges'] == identity_expected['trackedChanges']
            assert data['wasmSha256'] == identity_expected['wasmSha256']
            assert data['sourceHashes']['ext/js/dictionary/wasm/term-bank-parser.c'] == identity_expected['cSha256']
            assert data['sourceHashes']['dev/data/dictionary-wasm/manifest.json'] == identity_expected['manifestSha256']
            for name, value in data['sourceHashes'].items():
                assert value == inventories['candidate' if step['arm'] == 'B' else 'baseline'][name]['sha256'], name
            assert data['node'] == 'v22.22.0' and data['warmupPasses'] == 2
            assert data['diagnostic'] is None and data['diagnosticWasm'] is None
            assert data['runnerSha256'] == plan['runner']['sha256'] and data['diagnosticFieldsSha256'] == plan['diagnosticFields']['sha256']
            assert data['dictionary'] == 'jmdict' and data['flags'] == {} and data['validateGlossaryTypes'] is True
            assert data['filesPerGroup'] == 7 and data['rows'] == 528299
            assert data['fusedAttempts'] == 8 and data['fusedFallbacks'] == 0
            assert len(data['groupReceipts']) == 8
            for key in ['rows', 'digest', 'indexBytes', 'archiveSha256', 'lockSha256', 'flags', 'filesPerGroup', 'recentContentDedupHitCount']:
                assert data[key] == reference[key], (label, key)
            reuse_field = 'totalGlossaryReuses' if step['arm'] == 'B' else 'originalGlossaryReuses'
            assert data['glossaryReuseCount'] == reference['diagnostic'][reuse_field]
            for actual, expected in zip(data['groupReceipts'], reference['groupReceipts']):
                for key in ['group', 'banks', 'rows', 'fusedAttempts', 'fusedFallbacks', 'recentContentDedupHitCount']:
                    assert actual[key] == expected[key], (label, actual['group'], key)
                assert actual['glossaryReuseCount'] == expected['diagnosticAfter'][reuse_field] - (expected['diagnosticBefore'] or {}).get(reuse_field, 0)
                assert actual['diagnosticBefore'] is None and actual['diagnosticAfter'] is None
            check_inputs()
            report['observations'].append({**step, 'result': data})
            save()
            print('LOCAL_PREFIX_OBSERVATION ' + json.dumps({**step, 'rows': data['rows'], 'digest': data['digest'],
                **{key: data[key] for key in METRICS}, 'glossaryReuseCount': data['glossaryReuseCount']}, separators=(',', ':')), flush=True)
        assert len(report['observations']) == 16
        report['summary'] = summarize(report['observations'])
        report.update(complete=True, finishedAtUtc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        report['resourceSnapshots'].append({'phase': 'after-cohort', 'snapshot': snapshot()})
        save()
        print('LOCAL_PREFIX_COMPLETE ' + json.dumps({'complete': True, 'observations': 16, 'summary': report['summary'],
            'resultSha256': sha(report_path)}, separators=(',', ':')), flush=True)
    except Exception as error:
        report['failure'] = {'type': type(error).__name__, 'message': str(error), 'acceptedObservations': len(report['observations'])}
        save()
        print('LOCAL_PREFIX_FAILED ' + json.dumps(report['failure'], separators=(',', ':')), flush=True)
        raise

if __name__ == '__main__':
    main()
