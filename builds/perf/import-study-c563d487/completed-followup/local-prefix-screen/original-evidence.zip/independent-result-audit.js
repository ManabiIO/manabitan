function auditLocalPrefixScreen(bundle) {
  const {report:r,rawChildChecks:children,reference:ref}=bundle, errors=[];
  const check=(v,m)=>{if(!v)errors.push(m);}, eq=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
  const near=(a,b)=>Number.isFinite(a)&&Number.isFinite(b)&&Math.abs(a-b)<=1e-9;
  const median=a=>{const b=[...a].sort((x,y)=>x-y);return (b[1]+b[2])/2;};
  const sum=a=>a.reduce((x,y)=>x+y,0);
  const metrics=['elapsedMs','cpuMs','inflateMs','inflateCpuMs','parseMs','nativeParseMs','lookupMs'];
  const schedule=Array.from({length:4},(_,pair)=>[...((pair%2)===0?'ABCD':'DCBA')].map(arm=>({pair,arm}))).flat();
  check(bundle.resultSha256==='60066ddbfb3291bc184cc7f73f4afce25fe3903f903b828bcb9636199947e78a','Original result SHA');
  check(r.preregistrationSha256==='fa0e1589823ed0a50211072b2ac7f423538f4021e85a7b8fc76d4902a28b0549','Frozen preregistration');
  check(bundle.controllerSha256==='adb7cf2d45a471c211c774a33048e11c0ab10555fbb680c2e7ef889310b95c4a','Frozen controller');
  check(bundle.inventorySha256==='ae8abde1dd1b149b3796203aa804777ef79061624726cfdc7e95edd157d0a914','Frozen inventory');
  check(r.complete===true&&!r.failure,'Complete without failure');
  check(r.observations.length===16&&r.children.length===16&&children.length===16,'Exactly16 raw/accepted children');
  check(eq(r.plan.schedule,schedule),'Fixed schedule');
  check(eq(r.plan.childPolicy.fixedMeasuredExecArgv,['--expose-gc','--max-old-space-size=512']),'Original child options');
  const by={}, records=[];
  for(let n=0;n<r.observations.length;n++) {
    const o=r.observations[n],d=o.result,st=children[n],role=schedule[n],candidate=o.arm==='B',identity=r.plan.sources[candidate?'candidate':'baseline'];
    check(o.pair===role.pair&&o.arm===role.arm,'Role/order '+n);
    check(!by[o.pair+o.arm],'Unique role '+n);by[o.pair+o.arm]=d;
    check(st.label==='pair-'+o.pair+'-'+o.arm&&st.status.label===st.label,'Raw child label '+n);
    check(eq(st.status,r.children[n]),'Independent status matches report '+n);
    check(st.status.status==='completed'&&st.status.exitCode===0,'Raw child completed '+n);
    check(st.status.finishedEpoch>=st.status.startedEpoch,'Monotonic process chronology '+n);
    if(n)check(st.status.startedEpoch>=children[n-1].status.finishedEpoch,'No overlapping children '+n);
    check(eq(st.status.command,[r.plan.node.path,'--expose-gc','--max-old-space-size=512',r.plan.runner.path,'jmdict','--source-root',identity.root,'--cache-dir',r.plan.cacheDir]),'Fixed invocation '+n);
    check(st.sourceHashInventoryParity===true,'Raw source inventory parity '+n);
    check(d.sourceRoot===identity.root&&d.gitHead===identity.head&&d.gitTree===identity.tree&&d.trackedChanges===identity.trackedChanges,'Truthful source identity '+n);
    check(d.wasmSha256===identity.wasmSha256&&identity.wasmSha256===identity.trackedWasmSha256,'Runtime/tracked WASM '+n);
    check(d.sourceHashes['ext/js/dictionary/wasm/term-bank-parser.c']===identity.cSha256&&d.sourceHashes['dev/data/dictionary-wasm/manifest.json']===identity.manifestSha256,'C and manifest '+n);
    check(Object.keys(d.sourceHashes).length===11,'All source hash fields '+n);
    check(d.node==='v22.22.0'&&d.warmupPasses===2&&d.diagnostic===null&&d.diagnosticWasm===null,'Runtime/warmups/no instrumentation '+n);
    check(d.runnerSha256===r.plan.runner.sha256&&d.diagnosticFieldsSha256===r.plan.diagnosticFields.sha256,'Exact observer '+n);
    check(d.dictionary==='jmdict'&&eq(d.flags,{})&&d.validateGlossaryTypes===true&&d.filesPerGroup===7,'Production component workload '+n);
    check(d.rows===528299&&d.fusedAttempts===8&&d.fusedFallbacks===0&&d.groupReceipts.length===8,'Complete route/rows '+n);
    for(const key of ['rows','digest','indexBytes','archiveSha256','lockSha256','flags','filesPerGroup','recentContentDedupHitCount'])check(eq(d[key],ref[key]),'Baseline work/digest '+n+' '+key);
    const field=candidate?'totalGlossaryReuses':'originalGlossaryReuses';
    check(d.glossaryReuseCount===ref.diagnostic[field],'Expected total reuse '+n);
    for(let g=0;g<d.groupReceipts.length;g++){
      const a=d.groupReceipts[g],e=ref.groupReceipts[g];
      for(const key of ['group','banks','rows','fusedAttempts','fusedFallbacks','recentContentDedupHitCount'])check(eq(a[key],e[key]),'Exact group '+n+' '+g+' '+key);
      check(a.glossaryReuseCount===e.diagnosticAfter[field]-(e.diagnosticBefore?.[field]??0),'Exact group reuse '+n+' '+g);
      check(a.diagnosticBefore===null&&a.diagnosticAfter===null,'Uninstrumented group '+n+' '+g);
    }
    for(const key of metrics)check(Number.isFinite(d[key])&&d[key]>0,'Valid raw metric '+n+' '+key);
    records.push({pair:o.pair,arm:o.arm,values:Object.fromEntries(metrics.map(k=>[k,d[k]])),stdoutSha256:st.stdoutSha256,stderrSha256:st.stderrSha256,rows:d.rows,digest:d.digest,glossaryReuseCount:d.glossaryReuseCount});
  }
  const stats={};
  for(const metric of metrics)for(const [kind,a,b] of [['candidate','A','B'],['identicalControl','C','D']]){
    const av=[0,1,2,3].map(i=>by[i+a]?.[metric]),bv=[0,1,2,3].map(i=>by[i+b]?.[metric]);
    const changes=av.map((x,i)=>100*(bv[i]/x-1));
    const calculated={baselineValues:av,comparisonValues:bv,pairedChangesPercent:changes,medianPairedChangePercent:median(changes),fasterPairs:changes.filter(x=>x<0).length,equalWorkChangePercent:100*(sum(bv)/sum(av)-1)};
    const original=r.summary?.[kind+'.'+metric];check(!!original,'Summary metric '+kind+'.'+metric);
    if(original){for(const k of ['baselineValues','comparisonValues'])check(eq(original[k],calculated[k]),'Exact summary raw values '+kind+'.'+metric+' '+k);
      check(original.pairedChangesPercent.every((x,i)=>near(x,changes[i])),'Paired recomputation '+kind+'.'+metric);
      for(const k of ['medianPairedChangePercent','equalWorkChangePercent'])check(near(original[k],calculated[k]),'Summary recomputation '+kind+'.'+metric+' '+k);
      check(original.fasterPairs===calculated.fasterPairs,'Win count '+kind+'.'+metric);
    }
    stats[kind+'.'+metric]=calculated;
  }
  check(r.resourceSnapshots.length===34,'All34 resource snapshots');
  check(r.resourceSnapshots[0].phase==='before-cohort'&&r.resourceSnapshots.at(-1).phase==='after-cohort','Cohort resource endpoints');
  for(let n=0;n<16;n++){check(r.resourceSnapshots[2*n+1].phase==='before-child'&&r.resourceSnapshots[2*n+2].phase==='after-child','Resource placement '+n);check(r.resourceSnapshots[2*n+1].label===children[n].label&&r.resourceSnapshots[2*n+2].label===children[n].label,'Resource label '+n);}
  const maxControl=Math.max(...stats['identicalControl.elapsedMs'].pairedChangesPercent.map(Math.abs));
  const signal=Math.abs(stats['candidate.elapsedMs'].medianPairedChangePercent);
  check(near(r.summary.descriptiveControlComparison.largestAbsoluteSameCodeChangePercent,maxControl),'Control envelope');
  check(r.summary.descriptiveControlComparison.absoluteCandidateMedianExceedsLargestAbsoluteControlChange===(signal>maxControl),'Control comparison');
  return {schema:1,scope:'Independent replay of separately registered local JMdict component; no full-import or memory qualification',passed:errors.length===0,errors,preregistrationSha256:r.preregistrationSha256,resultSha256:bundle.resultSha256,controllerSha256:bundle.controllerSha256,inventorySha256:bundle.inventorySha256,observations:records,statistics:stats,controls:{largestAbsoluteElapsedChangePercent:maxControl,absoluteCandidateMedianPercent:signal,candidateEffectExceedsControls:signal>maxControl},resourceSnapshotCount:r.resourceSnapshots.length,runtime:r.runtime,decision:signal<=maxControl?'Inconclusive under frozen same-code controls; no gain qualification, no rerun.':'Local component signal only; still requires independent hosted and full-import gates.',limitations:['Shared local host and namespace-limited process/cgroup visibility do not establish isolation.','All candidate and control outliers are retained; no pooling, subtraction, replacement or retry.','All sixteen raw stdout/status/digest records were independently reconciled; source and workload parity do not make noisy latency causal.']};
}
