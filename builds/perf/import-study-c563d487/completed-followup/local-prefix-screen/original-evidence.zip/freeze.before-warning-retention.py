#!/usr/bin/env python3
"""Freeze one local plan and identities without acquiring an observation."""
from pathlib import Path
import datetime
import importlib.util
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
root = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('local_prefix_controller', root / 'controller.py')
controller = importlib.util.module_from_spec(spec)
spec.loader.exec_module(controller)
sha, read = controller.sha, controller.read
experiments = root.parent
base = experiments.parent / 'manabitan'
candidate = root / 'candidate'
prior = experiments / 'jmdict-prefix-selector-evidence/jmdict'
hosted = experiments / 'jmdict-prefix-selector/hosted'
runner_root = root / 'runner'
runner = runner_root / 'dev/perf/x/hosted/screen.mjs'
node = experiments / 'node-v22.22.0-linux-x64/bin/node'
archive = experiments / 'sequence-probe-opportunity/JMdict.zip'
assert not (root / 'preregistration.json').exists()
assert not (root / 'observations').exists()
preparation = read(root / 'preparation.json')
assert preparation['complete'] and sha(root / 'preparation.json') == 'be43fcf2f810ae0125c69dceca39406f16b01b5e7f2233fd07d9dfbf9cdc6696'
sources = {name: controller.identity(path) for name, path in [('baseline', base), ('candidate', candidate)]}
for name, source in sources.items():
    assert source['head'] == controller.BASE_COMMIT and source['tree'] == controller.TREE
    assert source['trackedWasmSha256'] == source['wasmSha256']
assert sources['baseline']['changedPaths'] == [] and sources['baseline']['trackedChanges'] == ''
assert set(sources['candidate']['changedPaths']) == controller.CHANGED
assert sources['baseline']['wasmSha256'] == '8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee'
assert sources['candidate']['wasmSha256'] == 'b188cd7ca5ba1802eec6edf18b71f0ed3a98a471cab7c59dc2e5ae473999a6de'
assert sources['candidate']['cSha256'] == '358428813d7452f55dfd084ee84cc1437e944bd790acaed41adf1634d477cf68'
assert sources['candidate']['manifestSha256'] == '2c4f561f03e2b97b44747bcd18529388ef40876d24d1a42f40d9a6740eeb74ff'
inventory = {name: controller.file_inventory(path) for name, path in [('baseline', base), ('candidate', candidate)]}
assert inventory['baseline'].keys() == inventory['candidate'].keys()
for name in inventory['baseline']:
    if name not in controller.CHANGED | {'ext/lib/term-bank-parser.wasm'}:
        assert inventory['baseline'][name] == inventory['candidate'][name], name
inventory_path = root / 'source-lib-inventory.json'
if inventory_path.exists():
    assert read(inventory_path) == inventory
else:
    inventory_path.write_text(json.dumps(inventory, indent=2) + '\n')
source_diff = subprocess.check_output(['git', 'diff', '--binary', '--abbrev=9'], cwd=candidate)
(root / 'recovered-candidate.diff').write_bytes(source_diff)
assert sha(root / 'recovered-candidate.diff') == 'b618db944dbd79c11bd68e857717902f68c1364f6b9de546dd3c94880b3d48b4'
assert sha(prior / 'independent-preflight-audit.json') == 'c699d570792f790661266efee765deaf15afb7a0a7f70e76b3efdb7303dfb808'
assert sha(prior / 'download-receipt.json') == 'aa05422712c613f9c4e6be8ea6dd054ce65d71c7e18da6bdafdefd2d4145f2ad'
assert sha(prior.with_suffix('.zip')) == '5400984f61fd9d6dca019f0ab35cbefcb50a5088fbe487a1fa09b380cb41ab6b'
assert sha(runner) == '8519bfea747260803f87c1358a34f1d4a1ff431de891ffa3603ca70a422a19fa'
assert sha(archive) == '3a614c92cfa747946de8422fc408d6d93926ba76541df66e434b24976a10160f'
assert archive.stat().st_size == 15645766
node_probe = read(root / 'node-preparation-probe.json')
assert node_probe['exitCode'] == 0 and node_probe['stderr'] == ''
assert node_probe['stdout']['version'] == 'v22.22.0' and node_probe['stdout']['execPath'] == str(node)
assert node_probe['stdout']['execArgv'][:2] == ['--expose-gc', '--max-old-space-size=512']
for name in ['nodeOptions', 'nodeCompileCache', 'nodeDisableCompileCache']:
    assert node_probe['stdout'][name] is None
assert os.environ.get('NODE_OPTIONS') is None and os.environ.get('NODE_COMPILE_CACHE') is None and os.environ.get('NODE_DISABLE_COMPILE_CACHE') is None
prior_raw = experiments / 'jmdict-prefix-selector-jmdict-rehearsal/diagnostic.stdout.json'
prior_audit = experiments / 'jmdict-prefix-selector-jmdict-rehearsal/audit.json'
assert sha(prior_raw) == 'e81a9517eea7dd22fb01254f9f01dd6cae6757de9f80ace9714f633279ee3301'
assert sha(prior_audit) == '2f51e348645e6e75524e736ebf83b077993365662e63c11afdd38454fbfffa76'
assert sha(hosted / 'expected-mechanics.json') == '83df64e419d9e72f4af1d799b326b6ee0acf9497bcb4837c2f6d6ee86cee4e83'
assert read(prior_audit)['complete'] and read(prior_audit)['allFrozenExpectedMechanicsMatch']
resource_path = root / 'preparation-resources.json'
resource_path.write_text(json.dumps({'purpose': 'Preparation snapshot only; a fresh resource check and independent approval are required before measurement',
                                   'runtime': controller.runtime(), 'snapshot': controller.snapshot()}, indent=2) + '\n')
def binding(path):
    return {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}

# Shared hardlinks and symlinks consume no new dependency/archive content. Count
# our own file blocks plus the new worktree metadata, not those existing bytes.
shared = {(p.stat().st_dev, p.stat().st_ino) for p in (base / 'ext/lib').rglob('*') if p.is_file()}
seen = set()
new_blocks = 0
for p in root.rglob('*'):
    if p.is_symlink() or not p.is_file():
        continue
    info = p.stat()
    key = (info.st_dev, info.st_ino)
    if key not in shared and key not in seen:
        new_blocks += info.st_blocks * 512
        seen.add(key)
git_dir = Path(controller.git(candidate, 'rev-parse', '--absolute-git-dir'))
metadata_blocks = sum(p.stat().st_blocks * 512 for p in git_dir.rglob('*') if p.is_file())
assert new_blocks + metadata_blocks < 30 * 1024 * 1024
plan = {
    'schema': 1, 'study': 'Separately preregistered local JMdict prefix-selector component screen',
    'preregisteredAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Local sequential native compressed-source inflation + per-bank CRC + strict parsing + completed lookup component only. No complete browser import, storage, compression, UI, release, process-memory, equivalence or PR claim.',
    'authorizationBoundary': 'Preparation only. The exact plan/controller and a fresh no-arguments resource snapshot require parent plus independent benchmark review before invocation. No observation exists at freezing.',
    'measurementCount': 16,
    'schedule': [{'pair': i, 'arm': arm} for i in range(4) for arm in ('ABCD' if i % 2 == 0 else 'DCBA')],
    'roles': {'A': 'baseline', 'B': 'candidate', 'C': 'baseline same-code control', 'D': 'baseline same-code control'},
    'childPolicy': {'freshNodePerArm': True, 'heapMiB': 512, 'warmupFullCorpusPasses': 2, 'measuredFullCorpusPasses': 1,
                    'timeoutSeconds': 180, 'fixedMeasuredExecArgv': ['--expose-gc', '--max-old-space-size=512'],
                    'diagnosticModuleInTimedChildren': False, 'gcBetweenWarmupsAndMeasuredPass': 'Unchanged runner calls exposed globalThis.gc once outside its clocks'},
    'workload': {'dictionary': 'jmdict', 'rows': 528299, 'banks': 53, 'filesPerGroup': 7, 'groups': 8,
                 'flags': {}, 'validateGlossaryTypes': True, 'inputCache': 'Existing verified compressed archive via a filename symlink; no new archive or decoded-corpus copies'},
    'boundary': {'included': ['native decompression', 'CRC verification', 'strict parsing', 'completed lookup construction'],
                 'excluded': ['archive I/O', 'compilation', 'two full warmups', 'explicit GC', 'all-row output/index/dedup/media digest', 'controller provenance/resource checks', 'browser/workers/storage/compression/UI']},
    'analysis': {'unit': 'One complete measured corpus pass in one fresh child', 'pairsPerComparison': 4,
                 'statistics': ['all four paired percent changes', 'median paired percent change', 'equal-work sum ratio', 'faster pair count', 'all same-code changes and largest absolute control change'],
                 'metrics': controller.METRICS, 'primary': 'elapsedMs', 'cpuAndInternalProfiles': 'Descriptive only',
                 'controls': 'Retain every outlier. Noisy or overlapping same-code changes make attribution inconclusive; no control subtraction or adjusted speed claim.',
                 'noPoolingWith': ['original hosted prefix run46110806989', 'corrected hosted prefix run46119683668', 'numeric suffix cohorts', 'excluded local rehearsals'],
                 'adaptiveRetuningOrRetry': False, 'selectedObservationReplacement': False, 'timingDirectedEarlyStop': False,
                 'failures': 'Keep every raw stdout/stderr/status, completed observation and resource snapshot. A failure stops this cohort as incomplete; never replace or silently resume a child.'},
    'sources': sources, 'inventorySha256': sha(inventory_path), 'inventoryFilesPerArm': {key: len(value) for key, value in inventory.items()},
    'sourceAndLibChecks': 'Verify both Git identities, complete materialized source/lib inventory, runner/lock/archive/Node hashes and inherited Node environment before and after every child. Abort on drift without replacement.',
    'runner': binding(runner), 'diagnosticFields': binding(runner.parent / 'diagnostic-fields.json'),
    'runnerProvenance': {'unchangedFromToolingCommit': '268296d7ddd1933cb756fcd9794a89ba40386e23',
                         'alsoUnchangedInCorrectedToolingCommit': '59530bb6db9320063c955d0a42219690bcabb47d',
                         'localControllerHasNoGitToolingHeadClaim': True},
    'controllerSha256': sha(root / 'controller.py'), 'freezeScriptSha256': sha(Path(__file__)),
    'initialPreparationDiffFormattingFailure': binding(root / 'initial-freeze-formatting-failure.json'),
    'node': binding(node), 'nodeVersion': 'v22.22.0', 'nodePreparationProbe': binding(root / 'node-preparation-probe.json'),
    'nodeEnvironment': {'NODE_OPTIONS': None, 'NODE_COMPILE_CACHE': None, 'NODE_DISABLE_COMPILE_CACHE': None,
                        'probeOnlyExtraArgv': ['--input-type=module', '-e', 'read-only identity script; not used by measured children']},
    'lock': binding(runner_root / 'test/perf/dictionaries.lock.json'), 'archive': binding(archive), 'cacheDir': str(root / 'cache'),
    'compileProvenance': {'localBuildPerformed': False, 'localCompilerVersionClaimed': False,
        'origin': 'Exact recovered Git binary diff from original hosted candidate build; uninstrumented bytes copied without compiling locally',
        'hostedRun': 46110806989, 'hostedJob': 140873688700, 'artifactId': 15252152901,
        'verifiedArtifact': binding(prior.with_suffix('.zip')), 'recoveryAudit': binding(prior / 'independent-preflight-audit.json'),
        'downloadReceipt': binding(prior / 'download-receipt.json'), 'exactRecoveredDiff': binding(root / 'recovered-candidate.diff'),
        'manifestToolchain': read(candidate / 'dev/data/dictionary-wasm/manifest.json')['toolchain'],
        'provenanceLimit': 'Original build/six smoke modes passed but that original job later failed lint; this recovery does not turn that job into a completed qualification.'},
    'priorExcludedMechanics': {'reusedWithoutAnotherInvocation': True, 'rawReceipt': str(prior_raw), 'rawReceiptSha256': sha(prior_raw),
        'audit': binding(prior_audit), 'frozenExpectedMechanics': binding(hosted / 'expected-mechanics.json'),
        'expectedCandidateReuses': 134731, 'expectedBaselineReuses': 54629, 'expectedNewProofs': 80102,
        'allRowRichDigest': '2f8e0f8b55166fe47a30dcc09a2cdcef68b5ff27bd586acc3f0753f15de18b11',
        'scope': 'Mechanics/output expectation only, not a timed observation or a clean candidate product run'},
    'resourcePolicy': {'singleLocalCohort': True, 'teamLocalCpuWorkSuspendedDuringMeasurements': 'Parent, benchmark reviewer and glossary investigator must acknowledge the window before invocation',
        'backgroundVisibility': 'Process names/states and cgroup counters only, no command arguments or environment-secret dump; shared-host contention may still occur and remains a limitation',
        'snapshots': 'Before/after every child and cohort; retain all without selecting or replacing timings',
        'preparationSnapshot': binding(resource_path), 'newDiskBudgetBytes': 30 * 1024 * 1024,
        'newUniqueFileBlocksBytesAtFreeze': new_blocks, 'newWorktreeMetadataBlocksBytesAtFreeze': metadata_blocks},
    'hostedCohortsUnchanged': {'originalRun': 46110806989, 'correctedRun': 46119683668,
        'modified': False, 'replaced': False, 'resultsNotPooled': True},
}
path = root / 'preregistration.json'
path.write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps({'preparedOnly': True, 'observations': 0, 'preregistrationSha256': sha(path),
                  'controllerSha256': plan['controllerSha256'], 'inventorySha256': plan['inventorySha256'],
                  'resourceReceiptSha256': sha(resource_path), 'inventoryFilesPerArm': plan['inventoryFilesPerArm'],
                  'newUniqueBlocksBytesIncludingMetadata': new_blocks + metadata_blocks}))
