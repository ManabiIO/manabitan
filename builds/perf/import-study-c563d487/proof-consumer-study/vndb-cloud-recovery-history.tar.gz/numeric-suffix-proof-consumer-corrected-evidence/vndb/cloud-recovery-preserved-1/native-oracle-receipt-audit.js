// Supplemental read-only audit of already recovered original VNDB native-oracle receipts.
// No parser, WASM, tests, decompression, or timing is executed here.
return function auditNativeOracleReceipts(recovered, helpers) {
  const check = (ok, message) => { if (!ok) { throw new Error(message); } };
  const expectedExports = ['parse_term_bank', 'parse_term_bank_with_media_hints'];
  const file = recovered.files['original-members/native-oracle/native-oracle-records.jsonl'];
  const bytes = helpers.from64(file.base64);
  const report = recovered.originalNativeOracle;
  check(bytes.length === 1776831 && file.bytes === bytes.length, 'records byte length');
  check(helpers.sha256(bytes) === '2a0decbc96401edd279c78dd842f91c03f662dd284852ec71048cdec041a03e7', 'records exact SHA');
  check(report.recordsSha256 === file.sha256, 'report-to-records hash');
  check(report.complete === true && report.dictionary === 'vndb' && report.failures.length === 0, 'original oracle completion');
  check(report.oracleSha256 === 'fca3d561d443aec6623fe5e2864228157e16eb74d5cc477804bfea6f6b4d323d', 'oracle source');
  check(report.fixtureLockSha256 === '60aa981791f3b60ca17588212aea5bd3536fb8f59288855e5accd019c6e4cf89', 'fixture lock');
  check(report.archiveSha256 === 'da5baed5332761513dcef8d0b07ad0d9201cdd7f37831dea37e7162994ec3792', 'locked archive');
  check(report.sources.baseline.sourceSha256 === '7e836d21cb68165dc0fd6fe8aec074d50b77706debe2360b352b9cc34a67d24a', 'baseline C');
  check(report.sources.baseline.wasmSha256 === '5d216041823936521f8a70b721472fb8c42052d165d771a92b59ed967d8d2695', 'baseline WASM');
  check(report.sources.candidate.sourceSha256 === 'ae886af90a3313c219b59fe7fe25a38705de47c2e2e2763135fcfaf61dbf91cc', 'candidate C');
  check(report.sources.candidate.wasmSha256 === '9a1dd618597f5ca5ec85e620621f0fb9167b3486a708d9dc82292bd099c45554', 'candidate WASM');
  const text = helpers.decode(bytes);
  check(text.endsWith('\n'), 'records final newline');
  const records = text.slice(0, -1).split('\n').map(JSON.parse);
  check(records.length === 3554, 'record count');
  const seen = new Set(), cases = new Map(), bankTotals = Object.fromEntries(expectedExports.map(x => [x, {banks: 0, rows: 0, words: 0, bytes: 0}]));
  let syntheticComparisons = 0, syntheticInvalid = 0, syntheticValid = 0, syntheticWords = 0, attempts = 0;
  for (const r of records) {
    check(r.kind === 'synthetic' || r.kind === 'lockedBank', 'record kind');
    check(expectedExports.includes(r.exportName), 'strict export domain');
    check(typeof r.name === 'string' && /^[a-f0-9]{64}$/.test(r.sourceSha256), 'source receipt');
    check(Number.isSafeInteger(r.bytes) && r.bytes >= 0, 'input length');
    const id = JSON.stringify([r.kind, r.name, r.exportName]);
    check(!seen.has(id), 'duplicate case/export');
    seen.add(id);
    check(Array.isArray(r.baseline) && r.baseline.length === 1, 'actual recorded attempt count');
    check(JSON.stringify(r.baseline) === JSON.stringify(r.candidate), 'baseline/candidate entire attempt receipt parity');
    const a = r.baseline[0];
    check(Object.keys(a).sort().join(',') === 'capacity,digest,reportedCapacity,result,words', 'attempt schema');
    for (const k of ['capacity', 'reportedCapacity', 'result', 'words']) { check(Number.isSafeInteger(a[k]), 'integer attempt ' + k); }
    check(a.capacity > 0 && a.reportedCapacity > 0 && a.words >= 0, 'attempt domains');
    check(/^[a-f0-9]{64}$/.test(a.digest), 'metadata digest domain');
    check(a.result === -1 || a.result >= 0, 'terminal parse result');
    check(a.words === (a.result >= 0 ? a.result : a.capacity) * 17, 'all 17 words or prefilled error span');
    ++attempts;
    const caseKey = JSON.stringify([r.kind, r.name]);
    const previous = cases.get(caseKey);
    if (previous) {
      check(previous.bytes === r.bytes && previous.sourceSha256 === r.sourceSha256, 'same source through both exports');
      previous.exports.push(r.exportName);
    } else {
      cases.set(caseKey, {bytes: r.bytes, sourceSha256: r.sourceSha256, exports: [r.exportName]});
    }
    if (r.kind === 'synthetic') {
      check(a.capacity === 32 && a.reportedCapacity <= a.capacity, 'synthetic prefilled bounds');
      ++syntheticComparisons;
      syntheticWords += a.words;
      if (a.result < 0) { ++syntheticInvalid; } else { ++syntheticValid; }
    } else {
      check(/^term_bank_[1-9][0-9]*\.json$/.test(r.name), 'locked bank name');
      check(a.capacity === 1024 && a.result >= 0 && a.result <= a.reportedCapacity, 'locked native growth receipt');
      const t = bankTotals[r.exportName];
      ++t.banks; t.rows += a.result; t.words += a.words; t.bytes += r.bytes;
    }
  }
  for (const c of cases.values()) { check(c.exports.slice().sort().join(',') === expectedExports.slice().sort().join(','), 'both exports exactly once'); }
  check(syntheticComparisons === 2224 && report.synthetic.exportComparisons === syntheticComparisons && report.synthetic.cases === 1112, 'synthetic counts');
  check(syntheticValid === 44 && syntheticInvalid === 2180 && syntheticWords === 1186974, 'synthetic outcomes');
  for (const exportName of expectedExports) {
    const t = bankTotals[exportName];
    check(t.banks === 665 && t.rows === 6648310 && t.words === 113021270 && t.bytes === 4267992967, 'all locked rows and spans');
    check(report.corpus[exportName].banks === t.banks && report.corpus[exportName].rows === t.rows, 'corpus summary count');
    for (let n = 1; n <= 665; ++n) { check(seen.has(JSON.stringify(['lockedBank', 'term_bank_' + n + '.json', exportName])), 'contiguous locked bank inventory'); }
  }
  return {
    schema: 1,
    scope: 'Supplemental read-only reconciliation of original native-oracle JSONL receipts; no native execution, metadata reconstruction, or performance acquisition.',
    complete: true,
    originalRunId: 46136965050,
    originalJobId: 140955527816,
    originalArtifactId: 15260432499,
    originalArtifactSha256: '6630e77afbb10681aee5faef58bd0b4aad47cd52b94715e93b346041ff18b3f5',
    cloudByteBridgeGitBlob: 'd5d2ac37a09e0898483d0955fd03509d9e374796',
    records: {bytes: bytes.length, sha256: file.sha256, gitBlobSha1: file.gitBlobSha1, count: records.length, pairedAttempts: attempts},
    synthetic: {cases: 1112, comparisons: syntheticComparisons, validComparisons: syntheticValid, invalidComparisons: syntheticInvalid, wordsRepresented: syntheticWords},
    corpus: bankTotals,
    checks: ['Exact immutable source/WASM/fixture/archive bindings', 'All 3,554 original baseline/candidate attempt arrays exactly equal', 'Each unique input appears once through each strict export', 'All 17 words per valid row and all prefilled words on each synthetic failure represented by original hashes', 'Every locked bank 1..665 present; row, span and summary counts reconcile'],
    limitations: ['Raw metadata words are not present in the retained JSONL; aggregate metadata digests are not recomputed from words in this replay.', 'Exact word equality was performed by the frozen original native oracle during acquisition, as its source and successful receipts record.', 'These strict exports exercise the unchanged raw parser; fused proof activation is independently covered by original smoke, counters and rich-output parity.', 'The original frozen Python component auditor 6e007d90 was not run on VNDB during the executor outage; this supplement does not relabel it as executed.']
  };
};