
const {utf8,from64,to64,decode,sha256,gitBlob}=helpers;
function require(ok, message){if(!ok)throw new Error(message);}
function same(a,b){return JSON.stringify(sort(a))===JSON.stringify(sort(b));}
function sort(x){if(Array.isArray(x))return x.map(sort);if(x&&typeof x==="object")return Object.fromEntries(Object.keys(x).sort().map(k=>[k,sort(x[k])]));return x;}
function id(bytes){return {bytes:bytes.length,sha256:sha256(bytes),gitBlobSha1:gitBlob(bytes)};}
function safeName(name){return typeof name==="string"&&name.length>0&&!/[\x00-\x1f\\]/.test(name)&&!name.startsWith("/")&&name.split("/").every(x=>x&&x!=="."&&x!=="..");}
require(terminal.id===140959659830&&terminal.status==="completed"&&terminal.conclusion==="success","Successful exact recovery job required");
const tagPattern=/^\uFEFF?\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z SUFFIX_PROOF_ORIGINAL_RECOVERY_(START|FILE|CHUNK|COMPLETE|FAILURE) (.*)\r?$/;
const tags=[];
for(const [lineIndex,line] of log.split("\n").entries()){
 const m=tagPattern.exec(line);
 if(m)tags.push({tag:m[1],data:JSON.parse(m[2]),line:lineIndex+1});
 else if(line.includes("SUFFIX_PROOF_ORIGINAL_RECOVERY_"))throw new Error("Unrecognized recovery tag framing at line"+(lineIndex+1));
}
require(tags[0]?.tag==="START"&&tags.at(-1)?.tag==="COMPLETE","Complete ordered recovery framing");
require(tags.filter(x=>x.tag==="START").length===1&&tags.filter(x=>x.tag==="COMPLETE").length===1&&!tags.some(x=>x.tag==="FAILURE"),"One successful export");
const start=tags[0].data, complete=tags.at(-1).data;
require(start.schema===1&&start.files===69&&start.chunkBytes===6144&&start.originalRunId===46136965050,"Original export protocol");
require(start.recoveryHead==="55676ce568881d8f177a4f5b26d6b25781aafb38","Recovery source commit");
require(start.recoverySource.sha256==="71abc32cb48ec9259c6bb186f05aed13c98c724e4956b79a9918f81ec43f03ed"&&start.recoverySource.gitBlobSha1==="c5c97fae0609b0398205d96702c62afcb52d2720","Recovery source bytes");
require(complete.primaryAgrees===true&&complete.frozenAuditorExecuted===false,"Explicit terminal primary agreement and audit scope");
const files={}, metas={}, order=[];let current=null, parts=[], chunkCount=0;
function finish(){
 if(current===null)return;
 require(parts.length===current.chunks&&current.chunks===Math.ceil(current.bytes/6144),"Every declared chunk present:"+current.path);
 const bytes=new Uint8Array(current.bytes);let offset=0;
 for(const part of parts){bytes.set(part,offset);offset+=part.length;}
 require(offset===bytes.length,"Exact reconstructed length:"+current.path);
 require(same(id(bytes),{bytes:current.bytes,sha256:current.sha256,gitBlobSha1:current.gitBlobSha1}),"Exact byte/hash/blob identity:"+current.path);
 files[current.path]=bytes;metas[current.path]=current;order.push(current.path);current=null;parts=[];
}
for(const record of tags.slice(1,-1)){
 const value=record.data;
 if(record.tag==="FILE"){
  finish();require(safeName(value.path)&&!(value.path in files),"Unique safe export path");
  require(Number.isSafeInteger(value.bytes)&&value.bytes>=0&&value.bytes<=16*1024*1024,"Bounded export bytes");
  current=value;
 }else if(record.tag==="CHUNK"){
  require(current!==null&&value.path===current.path&&value.index===parts.length&&value.offset===parts.length*6144,"Ordered complete chunk index");
  const bytes=from64(value.base64);
  require(bytes.length===value.bytes&&bytes.length>0&&bytes.length<=6144,"Exact base64 chunk size");
  require(value.offset+bytes.length<=current.bytes,"Bounded chunk extent");
  require(bytes.length===Math.min(6144,current.bytes-value.offset),"No short interior chunk");
  parts.push(bytes);++chunkCount;
 }else throw new Error("Unexpected inner recovery tag");
}
finish();
require(order.length===start.files&&order.length===complete.files&&chunkCount===complete.chunks,"All export counts");
require(same(order,[...order].sort()),"Deterministic exported file order");
const labels=[];for(let pair=0;pair<4;pair++)for(const arm of(pair%2===0?"ABCD":"DCBA"))labels.push("pair-"+pair+"-"+arm);labels.push("diagnostic");
const members=labels.flatMap(label=>["stdout.json","stderr.log","child-status.json"].map(s=>label+"."+s)).concat([
 "result.json","component-setup.json","compiled-source-binding.json","correctness-result.json","diagnostic.wasm","diagnostic-source.c","diagnostic-build.json","smoke-parity.json",
 "native-oracle/native-oracle.json","native-oracle/native-oracle-records.jsonl"
]).sort();
const expected=members.map(n=>"original-members/"+n).concat(["original-artifact.zip","recovered-original-files.zip","primary-job.log","recovery-manifest.json","recovery-source.py","original-api/artifact.json","original-api/run.json","original-api/job.json"]).sort();
require(same(order,expected)&&members.length===61,"Exact source-defined61-member inventory and provenance");
require(files["original-artifact.zip"].length===281122&&sha256(files["original-artifact.zip"])==="6630e77afbb10681aee5faef58bd0b4aad47cd52b94715e93b346041ff18b3f5","Independent API-bound original ZIP identity");
require(same(id(files["original-artifact.zip"]),start.originalArtifact)&&same(id(files["original-artifact.zip"]),complete.originalArtifact),"Original ZIP export agreement");
require(same(id(files["recovered-original-files.zip"]),complete.recoveredZip)&&same(id(files["recovery-manifest.json"]),complete.manifest),"Derived ZIP/manifest bytes");
require(same(id(files["recovery-source.py"]),start.recoverySource),"Exact reviewed recovery script");
require(files["primary-job.log"].length===136612&&sha256(files["primary-job.log"])==="13372cf23c1684c9f35eb55a31caf30e074bc57d0b46e5e2a25958056c18a86b","Original primary bytes independently agree");
const json=name=>JSON.parse(decode(files[name]));
const manifest=json("recovery-manifest.json");
require(manifest.originalRunId===46136965050&&manifest.originalRunAttempt===1&&manifest.originalJobId===140955527816&&manifest.originalHead==="2c6761f83bd88a8d88b269ef31e5e15fa6840c22"&&manifest.artifactId===15260432499,"Original manifest identities");
require(manifest.frozenIndependentComponentAuditorExecutedHere===false&&manifest.primaryLogMatchesPriorConnectorBytes===true,"No frozen-auditor substitution");
require(manifest.originalRegularMemberCount===61&&same(Object.keys(manifest.originalMembers).sort(),members),"Manifest original inventory");
for(const name of members)require(same(id(files["original-members/"+name]),manifest.originalMembers[name]),"Every original member matches manifest:"+name);
for(const name of ["original-api/artifact.json","original-api/run.json","original-api/job.json"])require(same(id(files[name]),manifest.sourceApiResponses[name]),"Original API response exact bytes");
const artifact=json("original-api/artifact.json"), run=json("original-api/run.json"), job=json("original-api/job.json");
require(artifact.id===15260432499&&artifact.size_in_bytes===281122&&artifact.digest==="sha256:6630e77afbb10681aee5faef58bd0b4aad47cd52b94715e93b346041ff18b3f5"&&artifact.workflow_run.id===46136965050&&artifact.workflow_run.head_sha===manifest.originalHead,"Original artifact API independently bound");
require(run.id===46136965050&&run.head_sha===manifest.originalHead&&run.run_attempt===1&&run.conclusion==="success"&&job.id===140955527816&&job.run_id===run.id&&job.head_sha===run.head_sha&&job.conclusion==="success","Original completed run/job API bound");
// Independently parse original ZIP central and local headers and verify CRC32
// and sizes against every recovered original member; DEFLATE is not rerun here.
const crcTable=Array.from({length:256},(_,i)=>{let c=i;for(let k=0;k<8;k++)c=(c&1)?(0xedb88320^(c>>>1)):(c>>>1);return c>>>0;});
function crc32(b){let c=0xffffffff;for(const v of b)c=crcTable[(c^v)&255]^(c>>>8);return(c^0xffffffff)>>>0;}
require(crc32(utf8("123456789"))===0xcbf43926,"CRC32 known vector");
const zip=files["original-artifact.zip"], view=new DataView(zip.buffer,zip.byteOffset,zip.byteLength);
const u16=p=>{require(p>=0&&p+2<=zip.length,"ZIP u16 bound");return view.getUint16(p,true);};
const u32=p=>{require(p>=0&&p+4<=zip.length,"ZIP u32 bound");return view.getUint32(p,true);};
let eocd=-1;for(let p=zip.length-22;p>=Math.max(0,zip.length-22-65535);p--)if(u32(p)===0x06054b50&&p+22+u16(p+20)===zip.length){eocd=p;break;}
require(eocd>=0&&u16(eocd+4)===0&&u16(eocd+6)===0&&u16(eocd+8)===u16(eocd+10),"Single-disk bounded ZIP EOCD");
const entries=u16(eocd+10),cdSize=u32(eocd+12),cdStart=u32(eocd+16);require(cdStart+cdSize===eocd,"Original central directory geometry");
let at=cdStart;const central={};const extents=[];
for(let i=0;i<entries;i++){
 require(u32(at)===0x02014b50,"Central entry signature");
 const flags=u16(at+8),method=u16(at+10),crc=u32(at+16),compressed=u32(at+20),uncompressed=u32(at+24),nameLen=u16(at+28),extra=u16(at+30),comment=u16(at+32),local=u32(at+42);
 require(at+46+nameLen+extra+comment<=eocd&&!(flags&1)&&[0,8].includes(method),"Central entry bounds/method");
 const name=decode(zip.slice(at+46,at+46+nameLen));
 require(!(name in central),"Unique central entry");
 require(u32(local)===0x04034b50&&u16(local+6)===flags&&u16(local+8)===method,"Matching local header");
 const localName=u16(local+26),localExtra=u16(local+28),payload=local+30+localName+localExtra;
 require(decode(zip.slice(local+30,local+30+localName))===name&&payload+compressed<=cdStart,"Local name/data bounds");
 if(!(flags&8))require(u32(local+14)===crc&&u32(local+18)===compressed&&u32(local+22)===uncompressed,"Exact local CRC/lengths");
 central[name]={crc32:crc,compressedBytes:compressed,bytes:uncompressed,method};
 if(!name.endsWith("/")){require(safeName(name)&&members.includes(name),"Central member belongs to original allowlist");const b=files["original-members/"+name];require(b.length===uncompressed&&crc32(b)===crc,"Original central CRC and length:"+name);}
 else require(uncompressed===0,"Empty original directory");
 extents.push([local,payload+compressed]);at+=46+nameLen+extra+comment;
}
require(at===eocd&&same(Object.keys(central).filter(n=>!n.endsWith("/")).sort(),members),"Complete central inventory");
extents.sort((a,b)=>a[0]-b[0]);for(let i=1;i<extents.length;i++)require(extents[i-1][1]<=extents[i][0],"Non-overlapping original member extents");
const primary=decode(files["primary-job.log"]);const primaryTags=[];
for(const [lineIndex,line] of primary.split("\n").entries()){
 const m=/^\uFEFF?\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d+Z (SUFFIX_PROOF_[A-Z_]+) (.*)\r?$/.exec(line);
 if(m)primaryTags.push({tag:m[1],data:JSON.parse(m[2]),line:lineIndex+1});
}
function all(tag){return primaryTags.filter(x=>x.tag===tag).map(x=>x.data);}
function one(tag){const a=all(tag);require(a.length===1,"Exactly one primary "+tag);return a[0];}
const statuses=all("SUFFIX_PROOF_CHILD_STATUS"),children=all("SUFFIX_PROOF_CHILD_RECEIPT"),observations=all("SUFFIX_PROOF_OBSERVATION");
require(statuses.length===17&&children.length===17&&observations.length===16,"All17 original raw children and16 observations");
const raw={};
for(let i=0;i<labels.length;i++){
 const label=labels[i],status=json("original-members/"+label+".child-status.json"),data=json("original-members/"+label+".stdout.json");
 require(same(status,statuses[i])&&status.label===label&&status.status==="completed"&&status.exitCode===0,"Original status equals primary:"+label);
 require(status.stdoutSha256===sha256(files["original-members/"+label+".stdout.json"])&&status.stderrSha256===sha256(files["original-members/"+label+".stderr.log"]),"Original child hashes:"+label);
 const child=children[i];require(child.label===label&&same(child.command,status.command)&&child.startedEpoch===status.startedEpoch&&child.finishedEpoch===status.finishedEpoch&&same(child.result,data),"Original stdout object equals independently fetched primary:"+label);
 raw[label]=data;
}
const result=json("original-members/result.json"),setup=json("original-members/component-setup.json");
require(result.complete===true&&result.dictionary==="vndb"&&result.observations.length===16&&result.toolingHead===manifest.originalHead&&result.bindingSha256==="61d7d54b12c709e2c5275d187c11bf4370d5edaebc21c9ede8ee93cf57aff880","Original final result binding");
require(same(setup,one("SUFFIX_PROOF_COMPONENT_SETUP"))&&setup.sourceArtifactId==="15260257444"&&setup.sourceArtifactDigest.replace(/^sha256:/,"")==="8f48ef25c5c8a9283981192db8402fadcdbba7cc3a02290b278c3d229470c1ee","Original setup/correctness artifact matches primary");
for(let i=0;i<16;i++){
 const label=labels[i], augmented={...raw[label],observationStartedEpoch:statuses[i].startedEpoch};
 const [,pairText,arm]=label.split("-");const step={pair:Number(pairText),arm};
 require(same(result.observations[i],{...step,result:augmented}),"Full raw child equals original accepted result:"+label);
 const projected={dictionary:"vndb",...step};
 for(const key of["rows","digest","elapsedMs","cpuMs","inflateMs","inflateCpuMs","parseMs","lookupMs","nativeParseMs","fusedAttempts","fusedFallbacks","maxWasmHeapBytes"])projected[key]=augmented[key];
 require(same(observations[i],projected),"Exact producer-defined primary observation projection:"+label);
}
require(same(result.diagnostic,{...raw.diagnostic,observationStartedEpoch:statuses[16].startedEpoch}),"Separate original diagnostic child");
const final=one("SUFFIX_PROOF_RESULT");
require(final.complete===true&&final.dictionary==="vndb"&&same(final.summary,result.summary)&&same(final.componentGate,result.componentGate)&&same(final.mechanicalCounts,raw.diagnostic.diagnostic)&&final.rows===raw[labels[0]].rows&&final.digest===raw[labels[0]].digest,"Original final primary summary/counters equality");
const initial={...result};for(const k of["summary","diagnostic","componentGate","observations"])delete initial[k];initial.complete=false;require(same(initial,one("SUFFIX_PROOF_PLAN")),"Original initial plan preserved");
require(sha256(files["original-members/compiled-source-binding.json"])===setup.compiledSourceBindingSha256&&sha256(files["original-members/correctness-result.json"])===setup.correctnessResultSha256,"Exact compiled/correctness receipt crosslinks");
const oracle=json("original-members/native-oracle/native-oracle.json");
require(oracle.complete===true,"Original native metadata oracle completed");
return {
 files:Object.fromEntries(Object.entries(files).map(([name,b])=>[name,{...id(b),base64:to64(b)}])),
 rawChildren:raw, originalResult:result, originalNativeOracle:oracle,
 receipt:{schema:1,complete:true,recoveryRunId:46138708170,recoveryJobId:terminal.id,recoveryConclusion:terminal.conclusion,
 recoveryLog:id(utf8(log)),recoveryToolingHead:start.recoveryHead,recoverySource:start.recoverySource,
 originalRunId:46136965050,originalJobId:140955527816,originalHead:manifest.originalHead,artifactId:15260432499,
 originalZip:id(files["original-artifact.zip"]),derivedZip:id(files["recovered-original-files.zip"]),originalPrimary:id(files["primary-job.log"]),
 recoveredFiles:order.length,recoveredChunks:chunkCount,originalMembers:members.length,originalChildren:17,measuredObservations:16,separateDiagnosticChildren:1,
 everyFileByteSha256AndGitBlobVerified:true,everyOriginalZipCentralCrcAndLengthVerified:true,originalZipDeflateRerunInCloud:false,
 everyRawChildAndStatusEqualsOriginalPrimary:true,originalPlanAndFinalResultEqualsPrimary:true,
 originalDiagnosticCounters:raw.diagnostic.diagnostic,primaryRecordCounts:Object.fromEntries([...new Set(primaryTags.map(r=>r.tag))].map(t=>[t,all(t).length])),
 noNativeTestsBenchmarksOrCorpusExecution:true,originalFrozen6e00AuditorExecuted:false,
 scope:"Additional independent cloud byte/CRC/inventory and raw-child-to-primary reconciliation. The original frozen6e00 replay remains not-run; original observations and controls are unchanged.",
 recoveredFileIdentities:Object.fromEntries(Object.entries(files).map(([n,b])=>[n,id(b)]))}
};
