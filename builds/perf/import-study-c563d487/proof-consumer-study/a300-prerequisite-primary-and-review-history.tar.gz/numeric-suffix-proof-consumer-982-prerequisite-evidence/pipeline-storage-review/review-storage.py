#!/usr/bin/env python3
"""Read-only reconstruction and source-bound review of three excluded storage observations."""
import base64
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import zipfile
import qualification_receipts as receipts

ROOT = Path(__file__).resolve().parent.parent
OLD = ROOT.parent / "numeric-suffix-972-full-evidence"
OUT = Path(__file__).resolve().parent
BASE = "a300da36d00df8e353c5679b1528b50a1299b75f"
CANDIDATE = "61ac55c50d9ade7b90dbeb9299de18e094e25044"
TOOLING = "4b1d90e0cfbc4d19322105a92b1b3c0d9792436c"
BINDING = "c9da17e30c264ea31b10367294a9d31f431de705d52e3c9a3bedeee584a942f3"
SOURCE_INVENTORY = "8bb3036aa3916061d4b7fa30339505d591fc2eee80b262fb0d57a9a3ee492c87"
OBSERVER = "cad1b3fb25766cbd22a1c4260718a0b92353e87276751217ca18dc9eea29c6ef"
BROWSER = "8c599d43aec53f2460a31ae2f4af6bd863f8258b34ff519564bc5d4726bfaa1e"
EXPECTED = {
 "jmdict": {"job":140962634770, "logSha256":"cb1529bebaa7e2f3bafdc519be339c4df4e8b567acd8299d39a7cb03c005b5d1", "zipSha256":"dc2cdd0aa49e6397d80440e42d59eaa32a99037d03054089f643bef9f0cbdfae", "active":339968, "total":43684317},
 "jitendex": {"job":140962634795, "logSha256":"adc502e29f268fd460368add60751e373c486a2caa4fa436950523452363d6ea", "zipSha256":"913fb896be3c78043aa731f5e17fd8f9689270bddbf25f366fa9ed9277be5055", "active":5623808, "total":67630172},
 "vndb": {"job":140962634718, "logSha256":"f322e023fa8a63df461b4dd7baa0d92b7cc568c64505444b45fea8f39df44aaf", "zipSha256":"872f60b2e061580e85a8e48745de351b4cc54def10776d274a49d53edb178313", "active":315392, "total":609340619},
}
def digest(raw):
 return hashlib.sha256(raw).hexdigest()
def identity(raw):
 return {"bytes":len(raw), "sha256":digest(raw), "gitBlobSha1":hashlib.sha1(b"blob "+str(len(raw)).encode()+b"\0"+raw).hexdigest()}
def require(condition, message):
 if not condition: raise ValueError(message)
def parse_tags(text, prefix):
 return [(m.group(1), json.loads(m.group(2))) for line in text.splitlines() if (m:=re.search(r"\b"+prefix+r"([A-Z_]+) (\{.*\})\s*$",line))]
def only(tags, name):
 values=[v for k,v in tags if k==name]
 require(len(values)==1, "Expected one "+name)
 return values[0]
def products(canonical):
 return [v for v in canonical["files"] if v["path"]!=receipts.SQLITE_PATH]
def active(canonical):
 sizes=[v["bytes"] for v in canonical["files"] if v["path"]==receipts.SQLITE_PATH and v["bytes"]!=4096]
 require(len(sizes)==1, "Expected one active allocation")
 return sizes[0]

require(digest((OUT/"qualification_receipts.py").read_bytes())=="4f7b4eee4f8ff71e821c9162e57524460c48f01f409487f638523a3a27aa8f51", "Canonicalizer bytes changed")
results=[]
for dictionary, expected in EXPECTED.items():
 rawlog=(ROOT/dictionary/"primary-job.log").read_bytes()
 require(digest(rawlog)==expected["logSha256"], "Local log differs from independently fetched primary log")
 tags=parse_tags(rawlog.decode("utf-8"), "MANABITAN_EVIDENCE_ARCHIVE_")
 start=only(tags,"START"); complete=only(tags,"COMPLETE")
 require(not any(k=="FAILED" for k,v in tags), "Archive emitter failed")
 members=[v for k,v in tags if k=="MEMBER"]; excluded=[v for k,v in tags if k=="EXCLUDED"]; chunks=[v for k,v in tags if k=="CHUNK"]
 require(start["complete"] is True and start["chunkBytes"]==6144 and len(members)==29, "Unexpected archive contract")
 require([v["index"] for v in chunks]==list(range(start["chunkCount"])), "Chunk order/count mismatch")
 blocks=[base64.b64decode(v["data"],validate=True) for v in chunks]
 require(all(len(v)==6144 for v in blocks[:-1]) and 0<len(blocks[-1])<=6144, "Chunk size mismatch")
 rawzip=b"".join(blocks)
 require(identity(rawzip)==start["archive"] and digest(rawzip)==expected["zipSha256"], "Archive byte identity mismatch")
 require(complete=={"complete":True,"archive":start["archive"],"chunkCount":len(chunks),"memberCount":len(members),"excludedCount":len(excluded),"manifestSha256":start["manifestSha256"],"acquisitionOrObservationsChanged":False}, "Complete receipt mismatch")
 require(len(excluded)==1 and excluded[0]["path"]=="package-A.zip" and start["excludedNames"]==["package-A.zip","package-B.zip"], "Unexpected excluded bytes")
 manifest={"schemaVersion":1,"complete":True,"scope":start["scope"],"sourceDirectory":start["sourceDirectory"],"archiveFile":start["archiveFile"],"archive":{k:start["archive"][k] for k in ["bytes","sha256","gitBlobSha1"]},"members":[{k:v[k] for k in ["path","bytes","sha256"]} for v in members],"excluded":[{k:v[k] for k in ["path","bytes","sha256","reason"]} for v in excluded],"memberCount":len(members),"excludedNames":start["excludedNames"],"chunkBytes":6144,"chunkCount":len(chunks),"acquisitionOrObservationsChanged":False}
 manifest_bytes=(json.dumps(manifest,indent=2,allow_nan=False)+"\n").encode()
 require(digest(manifest_bytes)==start["manifestSha256"], "Original manifest reconstruction mismatch")
 with zipfile.ZipFile(io.BytesIO(rawzip)) as archive:
  require(archive.namelist()==[v["path"] for v in members] and len(set(archive.namelist()))==29, "ZIP member inventory mismatch")
  data={}
  for item in members:
   path=PurePosixPath(item["path"]); info=archive.getinfo(str(path))
   require(not path.is_absolute() and ".." not in path.parts and not info.is_dir() and info.external_attr>>16==0o100644, "Unsafe member")
   value=archive.read(info)
   require(len(value)==item["bytes"] and digest(value)==item["sha256"], "Member SHA/size/CRC mismatch: "+str(path))
   data[str(path)]=value
  def obj(name): return json.loads(data[name])
  primary=parse_tags(rawlog.decode("utf-8"),"MANABITAN_A300_PREREQUISITE_")
  primary_start=only(primary,"START"); result=only(primary,"RESULT"); inventory=only(primary,"STORAGE_INVENTORY")
  require(primary_start==obj("start.json") and result==obj("result.json") and inventory==obj("storage-inventory.json"), "Primary/original member discrepancy")
  require(inventory==json.loads((ROOT/dictionary/"primary-storage-inventory.json").read_bytes()), "Local inventory differs")
  require(primary_start["workflowHead"]==TOOLING and primary_start["runId"]=="46139360578" and primary_start["runAttempt"]=="1", "Unexpected workflow identity")
  require(primary_start["bindingSha256"]==BINDING and digest(data["source-binding.json"])==BINDING, "Binding mismatch")
  proof=obj("source-proof.json"); binding=obj("source-binding.json")
  require(proof==primary_start["source"] and proof["baseline"]["commit"]==BASE and proof["candidate"]["commit"]==CANDIDATE and proof["requiredSameCount"]==39, "Source proof mismatch")
  require(digest(data["a300-source-inventory.json"])==SOURCE_INVENTORY and proof["sourceInventorySha256"]==SOURCE_INVENTORY, "Source inventory mismatch")
  require(result["status"]=="complete" and result["observations"]==1 and result["candidateObservations"]==0 and result["retried"] is False and result["comparison"] is False and result["fullQualificationLaunched"] is False, "Observation scope mismatch")
  require(result["storageCompatibilityAccepted"] is False and result["manualStructuralReviewRequired"] is True, "Preflight accepted storage automatically")
  require(len(result["commandReceipts"])==5, "Unexpected preflight command count")
  for label, receipt_sha in result["commandReceipts"].items():
   require(digest(data[label+".receipt.json"])==receipt_sha, "Command receipt hash mismatch")
   receipt=obj(label+".receipt.json")
   require(receipt["exitCode"]==0, "Preflight command failed")
  browser=obj("browser-identity.json")
  require(browser["versionOutput"]=="Google Chrome for Testing 153.0.8010.12" and browser["sha256"]==BROWSER, "Browser pin mismatch")
  report=obj("baseline-only/run-1.json"); summary=obj("baseline-only/summary.json"); plan=obj("observation-plan.json")
  require(report["status"]=="success" and inventory["reportStatus"]=="success", "Import failed")
  require(summary["gitSha"]==BASE and inventory["summaryGitSha"]==BASE and inventory["summarySource"]==summary["source"], "Baseline source mismatch")
  require(summary["dictionary"]==dictionary and summary["browserVersion"]=="153.0.8010.12" and summary["traceEnabled"] is False and summary["importFlags"] is None and summary["mediaCheck"]=="sample", "Unexpected import flags")
  require(plan["observations"]==1 and plan["candidateObservations"]==0 and plan["flags"]=={} and plan["comparison"] is False and plan["allocationBound"] is None and plan["authoritativeTiming"] is False, "Excluded baseline scope mismatch")
  require(plan["sourceOverlay"]["originalSha256"]==digest(data["harness-original.js"]) and plan["sourceOverlay"]["instrumentedSha256"]==digest(data["harness-instrumented.js"]), "Overlay byte mismatch")
  require(summary["source"]["sha256"][plan["sourceOverlay"]["path"]]==digest(data["harness-instrumented.js"]), "Source overlay hash mismatch")
  require(report["packageSha256"]==summary["source"]["sha256"]["builds/manabitan-chrome.zip"]==plan["packageSha256"]==excluded[0]["sha256"], "Package identity mismatch")
  for name,sha in inventory["files"].items(): require(digest(data["baseline-only/"+name])==sha,"Raw input hash mismatch")
  validation=report["benchmark"]["validation"]
  require(validation==inventory["validation"], "Raw report storage/semantic inventory mismatch")
  canonical=receipts.canonicalize_storage(validation["storage"], dictionary, vndb_sah_allocation_units=(77,77))
  receipts.canonicalize_validation(validation,dictionary=dictionary,fixture=summary["fixture"],media_check="sample",vndb_sah_allocation_units=(77,77))
  require(canonical["bytes"]==expected["total"] and active(canonical)==expected["active"], "Actual storage differs")
  if dictionary=="vndb":
   try: receipts.canonicalize_storage(validation["storage"],dictionary,vndb_sah_allocation_units=(37,37))
   except ValueError: old37_rejects=True
   else: raise ValueError("Historical 37/37 unexpectedly accepted changed inventory")
  memory=obj("baseline-only/memory.json"); sampled=obj("sampled-summary.json")
  require({k:v for k,v in memory.items() if k!="samples"}==sampled, "Sampled summary projection mismatch")
  require(only(primary,"SAMPLED_BASELINE")=={"authoritativeTiming":False,"dictionary":dictionary,"value":sampled}, "Primary memory envelope differs")
  require(memory["benchmarkExitCode"]==0 and memory["qualifiedForWholeTreePss"] is True and memory["qualificationFailures"]==[], "Memory observation unqualified")
  require(len(memory["samples"])==memory["allObservedSampleCount"], "Raw memory sample count mismatch")
  oldpath=OLD/(dictionary+"-AB")/"raw-recovery-v2/raw-evidence.zip";oldraw=oldpath.read_bytes()
  with zipfile.ZipFile(io.BytesIO(oldraw)) as oldzip:
   oldreport_bytes=oldzip.read("control-01-A/run-1.json")
   oldreport=json.loads(oldreport_bytes);oldsummary=json.loads(oldzip.read("control-01-A/summary.json"))
  require(oldsummary["gitSha"]=="dcfc02a0a5534929b1e9fa1f2801ec7a0784ea16", "Prior source differs")
  require(summary["fixture"]==oldsummary["fixture"], "Locked fixture changed")
  oldcanonical=receipts.canonicalize_storage(oldreport["benchmark"]["validation"]["storage"],dictionary,vndb_sah_allocation_units=(37,37))
  require(products(canonical)==products(oldcanonical), "Non-SAH paths or exact sizes changed")
  require(validation["outputDigestSha256"]==oldreport["benchmark"]["validation"]["outputDigestSha256"], "Content output changed")
  require(active(canonical)-active(oldcanonical)==163840 and canonical["bytes"]-oldcanonical["bytes"]==163840, "Cross-source allocation delta differs")
  results.append({"dictionary":dictionary,"jobId":expected["job"],"primaryLog":identity(rawlog),"selectedArchive":start["archive"],"originalManifestSha256":start["manifestSha256"],"members":members,"excluded":excluded,"all29MemberShaSizeAndCrcChecksPassed":True,"rawReport":identity(data["baseline-only/run-1.json"]),"rawSummary":identity(data["baseline-only/summary.json"]),"inventory":identity(data["storage-inventory.json"]),"sourceProof":identity(data["source-proof.json"]),"fixture":summary["fixture"],"browser":browser,"canonicalStorage":canonical,"activeSahBytes":active(canonical),"activeSahAllocationUnits4096":active(canonical)//4096,"rawMemorySamples":len(memory["samples"]),"memoryQualified":True,"maximumCoveredSampleGapMs":memory["maximumCoveredSampleGapMs"],"priorStorageReference":{"source":oldsummary["gitSha"],"selectedArchive":identity(oldraw),"member":"control-01-A/run-1.json","memberSha256":digest(oldreport_bytes),"activeSahBytes":active(oldcanonical),"nonSahPathsAndExactSizesUnchanged":True,"outputDigestUnchanged":True,"activeAndTotalDifferenceBytes":163840,"allocationUnitBytes":4096,"allocationUnitDifference":40},"observationClass":"One excluded baseline-only storage prerequisite; no candidate observation or performance comparison."})
output={"schemaVersion":1,"recordedAtUtc":datetime.now(timezone.utc).isoformat(),"kind":"independent-original-storage-preflight-and-prospective-contract-review","reviewer":"pipeline_audit","source":{"baseline":BASE,"candidate":CANDIDATE,"tooling":TOOLING,"runId":46139360578,"bindingSha256":BINDING,"sourceInventorySha256":SOURCE_INVENTORY,"unchangedCanonicalizerSha256":digest((OUT/"qualification_receipts.py").read_bytes()),"reviewScript":identity(Path(__file__).read_bytes())},"cells":results,"decision":{"sourceAndRawStorageContractReviewed":True,"recommendedProspectiveVndbSahAllocationUnits":[77,77],"keepEightSahSeven4096ReserveRule":True,"keepAllKnownProductPathsAndExactCrossObservationBytes":True,"changeProductionSourceObserverTimersFlagsOrOtherGates":False,"candidateStorageObserved":False,"fullQualificationAuthorizedByThisReceipt":False},"limits":["Three single excluded baseline observations establish the observed source-specific contract, not its frequency or candidate nonregression.","The forty 4096-byte allocation units are an exact observed size difference; this review does not identify forty SQLite pages or attribute every unit to a particular table.","a300 source creates new metadata and preserves the minimum/reserve-eight SAH configuration; exact sizes come from these original reports.","Legacy product paths do not independently prove the optimizer/root epoch at the later post-restart inventory.","The raw benchmark retains its normal authoritativeTiming field, but these prerequisite observations are excluded from candidate timing analyses and no durations were evaluated.","Only original non-package evidence was reconstructed; the outer transport/release package was not downloaded. Its excluded digest/size and complete package-entry map remain preserved.","Future full observations must independently pass all original source, workload, semantic, package, memory, eight-SAH and exact cross-observation storage gates; mismatches remain failures, not permission to widen the bound."]}
target=OUT/"independent-storage-preflight-review.json"
with target.open("x") as stream: json.dump(output,stream,indent=2,allow_nan=False);stream.write("\n")
print(json.dumps({"review":str(target),"identity":identity(target.read_bytes()),"cells":[{"dictionary":r["dictionary"],"activeSahAllocationUnits4096":r["activeSahAllocationUnits4096"],"bytes":r["canonicalStorage"]["bytes"],"members":len(r["members"])} for r in results]}))

