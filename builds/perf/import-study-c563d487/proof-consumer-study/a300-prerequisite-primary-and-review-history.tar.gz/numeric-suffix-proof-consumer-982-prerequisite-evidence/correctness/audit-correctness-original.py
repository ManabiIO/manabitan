"""Read-only replay of the exact original a300 prerequisite correctness artifact."""
import argparse
import base64
import collections
import datetime
import hashlib
import io
import json
from pathlib import Path
import re
import stat
import traceback
import zipfile

P = Path(__file__).resolve().parent
SOURCE = P.parent.parent / "benchmark-prerequisite-982-recovered"
OUTER_SHA = "3d17262def25c405f1add4f4923694059479bbae83af4e9a93960985a4ba48a7"
INNER_SHA = "cfd7653e7f7d05d0c89bac72164468b2e4534cd6dba6996be8fa63c5bb0246cd"
BINDING_SHA = "c9da17e30c264ea31b10367294a9d31f431de705d52e3c9a3bedeee584a942f3"
HEAD = "4b1d90e0cfbc4d19322105a92b1b3c0d9792436c"
BASE = "a300da36d00df8e353c5679b1528b50a1299b75f"
CANDIDATE = "61ac55c50d9ade7b90dbeb9299de18e094e25044"
TREE = "b8f6cfa6a83a87c2c494224a26804c95b7221f3f"
PREFIX = "suffix-proof-982-prerequisite-correctness"
LABELS = ["create-candidate", "dependencies", "build-libraries", "license-page",
          "reproduce-native", "scoped-lint", "strict-main-types", "strict-test-types",
          "complete-unit-suite", "options-unit-suite", "all-dry-build-targets"]
ROOT = "/home/runner/work/manabitan/manabitan"
TARGET = "/home/runner/work/manabitan/suffix-proof-982-correctness-candidate"


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def identity(data):
    return {"bytes": len(data), "sha256": sha(data),
            "gitBlobSha1": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}


def safe_zip(data, expected_count):
    result, inventory = {}, {}
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        infos = archive.infolist()
        check(len(infos) == expected_count, "Exact ZIP inventory count")
        check(sum(x.file_size for x in infos) < 4 * 1024 * 1024, "Bounded total ZIP size")
        for info in infos:
            name = info.filename
            check(not info.is_dir() and name and not name.startswith("/") and "\\" not in name,
                  "Regular relative ZIP member")
            check(all(part not in ("", ".", "..") for part in name.split("/")), "Safe ZIP path")
            check(name not in result and not info.flag_bits & 1, "Unique unencrypted ZIP member")
            check(stat.S_IFMT(info.external_attr >> 16) in (0, stat.S_IFREG), "No nonregular ZIP member")
            check(info.file_size <= 1024 * 1024, "Bounded ZIP member")
            body = archive.read(info)
            check(len(body) == info.file_size, "ZIP length/CRC checked by original ZIP reader")
            result[name] = body
            inventory[name] = identity(body) | {"crc32": info.CRC, "compressedBytes": info.compress_size}
    return result, inventory


def json_bytes(data):
    return json.loads(data)


def one(records, tag):
    found = [r["value"] for r in records if r["tag"] == tag]
    check(len(found) == 1, "Exactly one " + tag)
    return found[0]


def values(records, tag):
    return [r["value"] for r in records if r["tag"] == tag]


def plain(data):
    return re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", data.decode("utf-8"))


parser = argparse.ArgumentParser()
parser.add_argument("--output", required=True, type=Path)
args = parser.parse_args()
check(not args.output.exists(), "Never replace an earlier audit")
args.output.mkdir()
report = {"schema": 1, "complete": False,
          "scope": "Independent original ZIP/member, source and eleven receipt/log replay; no downloaded code, native parser, tests or benchmark is executed.",
          "auditedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          "auditor": identity(Path(__file__).read_bytes())}
try:
    outer_bytes = (P / "original-artifact.zip").read_bytes()
    check(len(outer_bytes) == 146783 and sha(outer_bytes) == OUTER_SHA, "Exact original API ZIP bytes")
    api = json_bytes((P / "original-artifact-api.json").read_bytes())
    check(api["id"] == 15261456718 and api["size_in_bytes"] == len(outer_bytes)
          and api["digest"] == "sha256:" + OUTER_SHA, "Original artifact API identity")
    check(api["workflow_run"]["id"] == 46139360578 and api["workflow_run"]["head_sha"] == HEAD,
          "Original artifact run/source head")
    job = json_bytes((P / "original-job-api.json").read_bytes())
    check(job["id"] == 140961651044 and job["run_id"] == 46139360578
          and job["status"] == "completed" and job["conclusion"] == "success", "Original terminal job")
    outer, outer_inventory = safe_zip(outer_bytes, 32)
    manifest_name = PREFIX + ".raw-evidence-manifest.json"
    inner_name = PREFIX + ".raw-evidence.zip"
    manifest_bytes = outer[manifest_name]
    manifest = json_bytes(manifest_bytes)
    check(manifest["complete"] is True and manifest["sourceDirectory"] == PREFIX
          and manifest["archiveFile"] == inner_name, "Original inner archive scope")
    check(manifest["excluded"] == [] and manifest["excludedNames"] == ["package-A.zip", "package-B.zip"],
          "No packages existed or were omitted in correctness")
    check(manifest["memberCount"] == 30 and manifest["chunkBytes"] == 6144
          and manifest["chunkCount"] == 12 and manifest["acquisitionOrObservationsChanged"] is False,
          "Exact archive geometry and unchanged acquisition")
    inner_bytes = outer[inner_name]
    check(len(inner_bytes) == 72633 and sha(inner_bytes) == INNER_SHA, "Exact original inner ZIP")
    check(identity(inner_bytes) == manifest["archive"], "Inner SHA/size/Git blob")
    members, member_inventory = safe_zip(inner_bytes, 30)
    expected_names = {label + suffix for label in LABELS for suffix in (".log", ".receipt.json")}
    expected_names |= {"a300-source-inventory.json", "compiler-identity.json", "command-plan.json",
                       "prospective-review-criteria.json", "result.json", "source-binding.json",
                       "source-proof.json", "start.json"}
    check(set(members) == expected_names, "Exact thirty original correctness members")
    check(set(outer) == {PREFIX + "/" + name for name in members} | {manifest_name, inner_name},
          "Exact outer layout; no unbound original members")
    for name, body in members.items():
        check(outer[PREFIX + "/" + name] == body, "Inner/outer exact bytes: " + name)
    manifest_members = [{"path": name, "bytes": len(members[name]), "sha256": sha(members[name])}
                        for name in sorted(members)]
    check(manifest["members"] == manifest_members, "Every original member manifest")
    raw_log = (P / "primary-job.log").read_bytes()
    check(sha(raw_log) == "d04c52d83c1b788c6ad030170ee75244be8883b94c5bfb76f25337b6a050ee73",
          "Exact original primary log")
    tag_pattern = re.compile(r"^\ufeff?(?:\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z\s+)?(MANABITAN_(?:A300_PREREQUISITE|EVIDENCE_ARCHIVE)_[A-Z_]+) (\{.*\})$")
    records = []
    for line_number, line in enumerate(raw_log.decode("utf-8").splitlines(), 1):
        match = tag_pattern.fullmatch(line)
        if match:
            records.append({"line": line_number, "tag": match[1], "value": json.loads(match[2])})
    check(records == json_bytes((P / "primary-records.json").read_bytes()), "Independent original primary parser")
    expected_tags = ["MANABITAN_A300_PREREQUISITE_START"]
    expected_tags += [x for _ in LABELS for x in ("MANABITAN_A300_PREREQUISITE_COMMAND_START", "MANABITAN_A300_PREREQUISITE_COMMAND")]
    expected_tags += ["MANABITAN_A300_PREREQUISITE_RESULT", "MANABITAN_EVIDENCE_ARCHIVE_START"]
    expected_tags += ["MANABITAN_EVIDENCE_ARCHIVE_MEMBER"] * 30
    expected_tags += ["MANABITAN_EVIDENCE_ARCHIVE_CHUNK"] * 12 + ["MANABITAN_EVIDENCE_ARCHIVE_COMPLETE"]
    check([r["tag"] for r in records] == expected_tags, "Every original event in exact order")
    archive_start = one(records, "MANABITAN_EVIDENCE_ARCHIVE_START")
    check(archive_start == {k: v for k, v in manifest.items() if k not in ("members", "excluded")} |
          {"manifestSha256": sha(manifest_bytes)}, "Original archive start projection")
    check(values(records, "MANABITAN_EVIDENCE_ARCHIVE_MEMBER") == manifest_members, "All original member log records")
    chunks = values(records, "MANABITAN_EVIDENCE_ARCHIVE_CHUNK")
    rebuilt = []
    for index, chunk in enumerate(chunks):
        check(set(chunk) == {"index", "data"} and chunk["index"] == index, "Original ordered unique chunks")
        data = base64.b64decode(chunk["data"], validate=True)
        check(len(data) == (6144 if index < 11 else 72633 - 11 * 6144), "Original fixed chunk geometry")
        rebuilt.append(data)
    check(b"".join(rebuilt) == inner_bytes, "All original logged archive bytes")
    check(one(records, "MANABITAN_EVIDENCE_ARCHIVE_COMPLETE") == {
        "complete": True, "archive": manifest["archive"], "manifestSha256": sha(manifest_bytes),
        "memberCount": 30, "excludedCount": 0, "chunkCount": 12, "acquisitionOrObservationsChanged": False},
        "Original archive completion")
    source_files = {}
    for name, expected_blob in [
        ("prerequisite.py", "34ecffaaaa8142ea1b67b666e3b1b1a2dc02d6b9"),
        ("source-binding.json", "2a84523b47528a92f29e638a6d16604808c3d112"),
        ("workflow.yml", "4330483d22843fafec37ccc856340862eb19a93e")]:
        data = (SOURCE / name).read_bytes()
        check(identity(data)["gitBlobSha1"] == expected_blob, "Exact published source: " + name)
        source_files[name] = identity(data)
    check(members["source-binding.json"] == (SOURCE / "source-binding.json").read_bytes()
          and sha(members["source-binding.json"]) == BINDING_SHA, "Original source binding")
    binding = json_bytes(members["source-binding.json"])
    check(binding["baseline"]["commit"] == BASE and binding["candidate"]["commit"] == CANDIDATE
          and binding["candidate"]["tree"] == TREE and binding["candidate"]["soleParent"] == BASE,
          "Frozen current source and direct parent")
    check(sha(members["a300-source-inventory.json"]) == binding["sourceInventory"]["sha256"]
          == "8bb3036aa3916061d4b7fa30339505d591fc2eee80b262fb0d57a9a3ee492c87", "Source inventory")
    check(sha(members["prospective-review-criteria.json"]) == binding["criteria"]["sha256"]
          == "7812d2e91515ae2ed2038acecac3617661a40152d33501fe54f089bd2e8cdb9d", "Unchanged prospective criteria")
    proof = json_bytes(members["source-proof.json"])
    check(proof == {
        "baseline": binding["baseline"], "candidate": binding["candidate"],
        "changedProductPaths": sorted(x["path"] for x in binding["productFiles"]),
        "productFiles": {x["path"]: {k: x[k] for k in ("bytes", "sha256", "gitBlobSha1")} for x in binding["productFiles"]},
        "requiredSameCount": 39, "sourceInventorySha256": binding["sourceInventory"]["sha256"],
        "criteriaSha256": binding["criteria"]["sha256"]}, "Original source proof")
    start = json_bytes(members["start.json"])
    check(start == one(records, "MANABITAN_A300_PREREQUISITE_START"), "Original start receipt")
    check(start["mode"] == "correctness" and start["dictionary"] is None and start["source"] == proof
          and start["bindingSha256"] == BINDING_SHA and start["scriptSha256"] == source_files["prerequisite.py"]["sha256"]
          and start["workflowHead"] == HEAD and start["runId"] == "46139360578"
          and start["runAttempt"] == "1" and start["nodeVersion"] == "v22.22.0"
          and start["timingIsAuthoritative"] is False, "Current prerequisite provenance")
    tests = [x["path"] for x in binding["productFiles"] if x["path"].startswith("test/")]
    commands = [
        ["git", "worktree", "add", "--detach", TARGET, CANDIDATE], ["npm", "ci"],
        ["npm", "run", "build:libs"], ["npm", "run", "license-report:html"],
        ["npm", "run", "build:dictionary-wasm", "--", "--check"], ["npx", "eslint", *tests],
        ["npm", "run", "test:ts:main"], ["npm", "run", "test:ts:test"],
        ["npm", "run", "test:unit", "--", "--maxWorkers=2"],
        ["npm", "run", "test:unit:options", "--", "--maxWorkers=2"], ["npm", "run", "test:build"]]
    plan = [{"label": label, "command": argv, "cwd": ROOT if index == 0 else TARGET}
            for index, (label, argv) in enumerate(zip(LABELS, commands))]
    check(json_bytes(members["command-plan.json"]) == plan, "Original eleven command argv/cwd")
    receipts = values(records, "MANABITAN_A300_PREREQUISITE_COMMAND")
    command_starts = values(records, "MANABITAN_A300_PREREQUISITE_COMMAND_START")
    prior_finish = None
    for index, item in enumerate(plan):
        label = item["label"]
        receipt = json_bytes(members[label + ".receipt.json"])
        check(receipt == receipts[index], "Original receipt equals primary: " + label)
        check({k: receipt[k] for k in ("label", "command", "cwd")} == item, "Receipt command: " + label)
        check(command_starts[index] == item | {"scope": "Prerequisite only; no comparison observation"},
              "Command start event: " + label)
        check(receipt["exitCode"] == 0 and receipt["exception"] is None and receipt["retried"] is False,
              "Original successful command: " + label)
        check(receipt["logSha256"] == sha(members[label + ".log"]), "Every original log SHA: " + label)
        check(receipt["startedEpoch"] <= receipt["finishedEpoch"]
              and (prior_finish is None or receipt["startedEpoch"] >= prior_finish), "Serial command chronology")
        prior_finish = receipt["finishedEpoch"]
    result = json_bytes(members["result.json"])
    check(result == one(records, "MANABITAN_A300_PREREQUISITE_RESULT"), "Original result equals primary")
    check(result["commandReceipts"] == {label: sha(members[label + ".receipt.json"]) for label in LABELS},
          "Every original command receipt SHA")
    check(result["correctnessPass"] is True and result["commandCount"] == 11
          and result["status"] == "complete" and result["sourceClean"] is True and result["retried"] is False
          and result["freshExactHead"] == CANDIDATE and result["freshExactTree"] == TREE
          and result["performanceObservations"] == 0 and result["bindingSha256"] == BINDING_SHA,
          "Fresh complete exact-source correctness; zero performance observations")
    compiler = json_bytes(members["compiler-identity.json"])
    check(result["compilerIdentity"] == compiler and all(re.search(r"\b21\.1\.8\b", x) for x in compiler.values()),
          "Pinned original compiler and linker")
    native_log = plain(members["reproduce-native.log"])
    native = json.loads(native_log[native_log.index("{"):])
    check(native["mode"] == "check" and native["toolchain"] == {"compilerVersion": "21.1.8", "linkerVersion": "21.1.8"},
          "Native check mode and toolchain")
    targets = {x["name"]: x["sha256"] for x in native["targets"]}
    check(targets["term-bank-parser.wasm"] == "9a1dd618597f5ca5ec85e620621f0fb9167b3486a708d9dc82292bd099c45554",
          "Original reproducibility checked exact product WASM")
    unit = plain(members["complete-unit-suite.log"])
    check(re.findall(r"Test Files\s+(\d+) passed \((\d+)\)", unit) == [("701", "701")], "Complete test-file outcome")
    check(re.findall(r"Tests\s+(\d+) passed \| (\d+) skipped \((\d+)\)", unit)
          == [("15921", "47", "15968")], "Complete unit-test outcome")
    for name, count in [("term-bank-row-suffix-reuse.test.js", 32),
                        ("term-bank-row-suffix-token-ends.test.js", 9),
                        ("term-bank-row-suffix-proof-consumer.test.js", 17)]:
        check(len(re.findall(re.escape("test/" + name) + r" \(" + str(count) + r" tests\)", unit)) == 1,
              "All focused cases included in full suite: " + name)
    options = plain(members["options-unit-suite.log"])
    check(re.findall(r"Tests\s+(\d+) passed \((\d+)\)", options) == [("32", "32")], "Options suite")
    builds = re.findall(r"^Building ([a-z-]+)\.\.\.$", plain(members["all-dry-build-targets.log"]), re.M)
    check(builds == ["chrome", "chrome-dev", "chrome-playwright", "firefox", "firefox-dev", "firefox-android", "edge"],
          "All seven dry-build target names")
    report.update(complete=True, originalArtifact=identity(outer_bytes) | {"artifactId": api["id"], "runId": 46139360578,
                  "jobId": 140961651044, "headSha": HEAD}, outerMembers=outer_inventory,
                  originalInnerArchive=identity(inner_bytes), originalInnerManifest=identity(manifest_bytes),
                  originalMembers=member_inventory, sourceFiles=source_files,
                  primaryLog=identity(raw_log), primaryRecordCounts=dict(collections.Counter(r["tag"] for r in records)),
                  sourceProof=proof, commandPlan=plan, commandReceipts=receipts, originalResult=result,
                  unit={"files": 701, "passed": 15921, "skipped": 47, "focusedCases": 58},
                  options={"passed": 32}, dryBuildTargets=builds, nativeCheck=native,
                  noNewAcquisition=True,
                  limitations=["This artifact contains command/source receipts and logs, not new product file copies; the exact eight product identities are bound by the published source proof and prior recovered bytes.",
                               "This is correctness evidence only; all performance and storage qualification remains separate."])
    (args.output / "original-inner-evidence.zip").write_bytes(inner_bytes)
    (args.output / "original-member-hashes.json").write_text(json.dumps(outer_inventory, indent=2) + "\n")
except Exception as error:
    report["failure"] = {"type": type(error).__name__, "message": str(error), "traceback": traceback.format_exc()}
    raise
finally:
    (args.output / "independent-original-correctness-audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"complete": report["complete"], "output": str(args.output),
                      "failure": report.get("failure", {}).get("message")}))

