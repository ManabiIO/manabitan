"""Independent original component archive/log replay; never acquire measurements."""
import argparse
import collections
import datetime
import json
import pathlib
import re
import traceback

from evidence_core import (Archive, finite, integer, native_oracle, one, pair_stats,
                           parse_json, primary_records, require, sha, tracked_native, values)

parser = argparse.ArgumentParser()
for name in ('expected', 'metadata', 'archive', 'primary', 'build-audit', 'output'):
    parser.add_argument('--' + name, required=True, type=pathlib.Path)
parser.add_argument('--dictionary', required=True, choices=('jmdict', 'jitendex', 'vndb'))
args = parser.parse_args()
require(not args.output.exists(), 'Never replace an earlier audit')
args.output.mkdir(parents=True)
audit = {'schema': 1, 'complete': False, 'dictionary': args.dictionary,
         'scope': 'Independent exact original ZIP, child stdout/stderr/status and primary-log replay; component only. No parser, native module, acquisition or timing execution.',
         'auditedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'auditorSha256': sha(pathlib.Path(__file__).read_bytes()),
         'coreSha256': sha(pathlib.Path(__file__).with_name('evidence_core.py').read_bytes())}
archive = None
try:
    expected = parse_json(args.expected.read_bytes())
    require(expected['finalized'] is True and expected['publication']['runId'] is not None, 'Frozen published expectations')
    binding = expected['binding']
    require(binding['finalized'] is True, 'Frozen producer binding')
    metadata = parse_json(args.metadata.read_bytes())
    require(metadata['cell'] == args.dictionary, 'Original artifact cell')
    archive = Archive(args.archive, metadata, expected)
    audit.update(artifact=metadata, expectedSha256=sha(args.expected.read_bytes()), members=archive.members)
    (args.output / 'original-member-hashes.json').write_text(json.dumps(archive.members, indent=2) + '\n')
    raw_primary, records = primary_records(args.primary)
    audit['primaryLogSha256'] = sha(raw_primary)
    (args.output / 'primary-records.jsonl').write_text(''.join(json.dumps(r, separators=(',', ':')) + '\n' for r in records))
    audit['primaryRecordCounts'] = dict(collections.Counter(r['tag'] for r in records))
    build = parse_json(args.build_audit.read_bytes())
    require(build['complete'] is True and build['correctnessPass'] is True, 'Successful independently audited correctness')
    require(build['expectedSha256'] == sha(args.expected.read_bytes()), 'Same source/tooling expectation for build and component')
    product = build['product']
    product_files = build['productFilesSha256']
    setup = archive.json('component-setup.json')
    require(setup == one(records, 'SUFFIX_PROOF_COMPONENT_SETUP'), 'Original setup receipt equals primary')
    require(setup['complete'] is True and setup['correctnessReceiptCount'] == 26, 'All correctness receipts restored')
    require(setup['sourceArtifactId'] == str(build['artifact']['artifactId']), 'Original successful source artifact ID')
    require(setup['sourceArtifactDigest'].removeprefix('sha256:') == build['artifact']['sha256'], 'Original source artifact API digest')
    require(setup['productFilesSha256'] == product_files, 'Restored exact product map')
    require(setup['toolingHead'] == expected['publication']['commit'] and setup['toolingTree'] == expected['publication']['tree'], 'Setup tooling source')
    require(setup['bindingSha256'] == expected['bindingSha256'], 'Setup binding bytes')
    require(setup['baseline'] == binding['baseline'], 'Setup baseline')
    require(archive.file_sha('compiled-source-binding.json') == build['compiledSourceBindingSha256'] == setup['compiledSourceBindingSha256'], 'Original compiled binding copied exactly')
    require(archive.file_sha('correctness-result.json') == build['correctnessResultSha256'] == setup['correctnessResultSha256'], 'Original correctness result copied exactly')
    for name, digest in build['sharedComponentFiles'].items():
        require(archive.file_sha(name) == digest, 'Original successful shared bytes: ' + name)
    plan = archive.json('result.json')
    if plan.get('complete') is not True:
        audit['preservedIncomplete'] = {'acceptedObservations': len(plan.get('observations', [])),
            'error': plan.get('error'), 'remaining': plan.get('unattemptedOrUnacceptedSchedule'),
            'statuses': values(records, 'SUFFIX_PROOF_CHILD_STATUS'),
            'rawChildren': [name for name in archive.members if name.endswith('.stdout.json')]}
        raise AssertionError('Original cohort incomplete; all raw members retained, no promotion')
    dictionary = args.dictionary
    fixture = expected['fixtures'][dictionary]
    require(plan['dictionary'] == dictionary and plan['node'] == 'v22.22.0' and plan['browser'] is None, 'Component runtime/scope')
    require(plan['python'] == setup['python'], 'Same-host Python arithmetic provenance')
    require(plan['toolingHead'] == expected['publication']['commit'] and plan['toolingTree'] == expected['publication']['tree'], 'Plan tooling source')
    require(plan['bindingSha256'] == expected['bindingSha256'] and plan['criteriaSha256'] == binding['criteriaSha256'], 'Plan binding and prospective criteria')
    require(plan['toolingFiles'] == binding['toolingFiles'], 'Plan exact tooling map')
    require(plan['runnerSha256'] == binding['toolingFiles']['run.py'] and plan['screenSha256'] == binding['toolingFiles']['screen.mjs'], 'Exact controller and child')
    require(plan['patchSha256'] == binding['candidatePatchSha256'] and plan['fixtureLockSha256'] == binding['fixtureLockSha256'], 'Patch and fixture lock')
    require(plan['compiledSourceBindingSha256'] == build['compiledSourceBindingSha256'], 'Plan compiled source receipt')
    require(plan['originalCorrectnessReceiptSha256'] == build['correctnessResultSha256'], 'Plan successful correctness receipt')
    native_paths = expected['nativePaths']
    for arm in ('baseline', 'candidate'):
        identity = plan[arm]
        require(identity['head'] == binding['baseline']['commit'] and identity['tree'] == binding['baseline']['tree'], 'Detached exact base worktree: ' + arm)
        bound = binding['baseline'] if arm == 'baseline' else product
        for field in ('cSha256', 'wasmSha256', 'manifestSha256'):
            require(identity[field] == bound[field], 'Native product identity: ' + arm + '/' + field)
        require(identity['trackedWasmSha256'] == identity['wasmSha256'], 'Tracked/runtime WASM equality')
        require(identity['dependencyLockSha256'] == binding['dependencyLockSha256'], 'Dependency lock')
        if arm == 'baseline':
            require(identity['trackedChanges'] == '', 'Clean baseline')
        else:
            tracked_native(identity['trackedChanges'], native_paths)
    schedule = [{'pair': pair, 'arm': arm} for pair in range(4) for arm in ('ABCD' if pair % 2 == 0 else 'DCBA')]
    require(plan['schedule'] == schedule and len(plan['observations']) == 16, 'All16 fixed observations in order')
    initial = dict(plan)
    for field in ('summary', 'diagnostic', 'componentGate', 'observations'):
        initial.pop(field)
    initial['complete'] = False
    require(initial == one(records, 'SUFFIX_PROOF_PLAN'), 'Initial plan unchanged apart from declared result fields')
    statuses = values(records, 'SUFFIX_PROOF_CHILD_STATUS')
    children = values(records, 'SUFFIX_PROOF_CHILD_RECEIPT')
    observations = values(records, 'SUFFIX_PROOF_OBSERVATION')
    require(len(statuses) == len(children) == 17 and len(observations) == 16, 'All17 original children and16 measured receipts')
    labels = [f"pair-{step['pair']}-{step['arm']}" for step in schedule] + ['diagnostic']
    require([s['label'] for s in statuses] == [s['label'] for s in children] == labels, 'Exact chronological child labels')
    expected_tags = ['SUFFIX_PROOF_COMPONENT_SETUP', 'SUFFIX_PROOF_NATIVE_ORACLE', 'SUFFIX_PROOF_PLAN']
    expected_tags += [tag for _ in range(16) for tag in ('SUFFIX_PROOF_CHILD_STATUS', 'SUFFIX_PROOF_CHILD_RECEIPT', 'SUFFIX_PROOF_OBSERVATION')]
    expected_tags += ['SUFFIX_PROOF_CHILD_STATUS', 'SUFFIX_PROOF_CHILD_RECEIPT', 'SUFFIX_PROOF_RESULT']
    require([r['tag'] for r in records] == expected_tags, 'Original primary event order, no repeated or extra acquisition')
    first = None
    raw = {}
    stderr_inventory = []
    prior_finish = None
    all_children = []
    for index, label in enumerate(labels):
        diagnostic = label == 'diagnostic'
        arm = 'B' if diagnostic else schedule[index]['arm']
        identity = plan['candidate' if arm == 'B' else 'baseline']
        actual = archive.json(label + '.stdout.json')
        status = archive.json(label + '.child-status.json')
        require(status == statuses[index], 'Original child status equals primary: ' + label)
        require(status['status'] == 'completed' and status['exitCode'] == 0, 'Successful child: ' + label)
        require(status['stdoutSha256'] == archive.file_sha(label + '.stdout.json') and status['stderrSha256'] == archive.file_sha(label + '.stderr.log'), 'All original child output bytes: ' + label)
        finite(status['startedEpoch'], label + '/start', True)
        finite(status['finishedEpoch'], label + '/finish', True)
        require(status['finishedEpoch'] >= status['startedEpoch'] and (prior_finish is None or status['startedEpoch'] >= prior_finish), 'Serial child intervals')
        prior_finish = status['finishedEpoch']
        child = children[index]
        require(child == {key: status[key] for key in ('label', 'command', 'startedEpoch', 'finishedEpoch')} | {'result': actual}, 'Original parsed stdout equals primary child receipt')
        command = status['command']
        require(command[:3] == ['node', '--expose-gc', '--max-old-space-size=512'], 'Unchanged Node invocation')
        require(command[3].endswith('/dev/perf/numeric-suffix-proof-consumer-c563d487/screen.mjs'), 'Bound child path')
        require(command[4:7] == [dictionary, '--source-root', identity['root']] and command[7] == '--cache-dir', 'Bound source and corpus command')
        require(len(command) == (11 if diagnostic else 9), 'No additional child arguments')
        if diagnostic:
            require(command[9] == '--diagnostic-wasm' and command[10].endswith('/diagnostic.wasm'), 'Separate diagnostic override')
        require(actual['sourceRoot'] == identity['root'] and actual['gitHead'] == identity['head'] and actual['gitTree'] == identity['tree'] and actual['trackedChanges'] == identity['trackedChanges'], 'Child worktree identity')
        require(actual['dictionary'] == dictionary and actual['node'] == 'v22.22.0', 'Child dictionary/runtime')
        require(actual['runnerSha256'] == plan['screenSha256'] and actual['lockSha256'] == binding['fixtureLockSha256'], 'Child script/fixture lock')
        require(actual['archiveSha256'] == fixture['sha256'] and actual['rows'] == fixture['termRows'], 'Complete locked archive and row count')
        require(actual['flags'] == expected['criteria']['componentPlan']['flags'][dictionary] and actual['filesPerGroup'] == expected['criteria']['componentPlan']['filesPerGroup'][dictionary], 'Unchanged component options/grouping')
        require(actual['validateGlossaryTypes'] is True and actual['warmupPasses'] == (0 if diagnostic else 2), 'Strict validation and excluded warmups')
        source_map = dict(expected['baselineScreenSourceHashes'])
        if arm == 'B':
            source_map['ext/js/dictionary/wasm/term-bank-parser.c'] = product['cSha256']
            source_map['dev/data/dictionary-wasm/manifest.json'] = product['manifestSha256']
        require(actual['sourceHashes'] == source_map, 'Every11 exact source-hash columns')
        expected_wasm = build['diagnosticWasmSha256'] if diagnostic else identity['wasmSha256']
        require(actual['wasmSha256'] == expected_wasm, 'Product versus separate diagnostic WASM')
        require(actual['diagnosticWasm'] == (command[10] if diagnostic else None), 'Diagnostic route cannot enter timings')
        require(actual['diagnostic'] is not None if diagnostic else actual['diagnostic'] is None, 'Separate diagnostic state')
        require(re.fullmatch('[0-9a-f]{64}', actual['digest']), 'Complete-output digest shape')
        for metric in ('elapsedMs', 'cpuMs', 'inflateMs', 'inflateCpuMs', 'parseMs', 'nativeParseMs', 'lookupMs'):
            finite(actual[metric], label + '/' + metric, positive=metric in ('elapsedMs', 'cpuMs', 'parseMs'))
        for field in ('rows', 'indexBytes', 'fusedAttempts', 'fusedFallbacks', 'glossaryReuseCount', 'maxWasmHeapBytes', 'nativeSegments', 'ownedCompactExpressionRows', 'directArenaSegments', 'validationPasses', 'scratchReusedBytes', 'scratchReuseMisses', 'lifetimeMaxRssKiB'):
            integer(actual[field], label + '/' + field)
        require(actual['indexBytes'] > 0, 'Nonempty completed lookup output')
        require(set(actual['afterVerificationMemory']) == {'rss', 'heapTotal', 'heapUsed', 'external', 'arrayBuffers'}, 'Declared post-verification memory fields')
        for field, value in actual['afterVerificationMemory'].items():
            integer(value, 'Post-verification memory ' + field)
        require(actual['fusedAttempts'] == fixture['fusedGroups'] and actual['fusedFallbacks'] == 0, 'Expected multi-bank native route, including singleton exception')
        if first is None:
            first = actual
        for field in ('rows', 'digest', 'indexBytes', 'nativeSegments', 'ownedCompactExpressionRows', 'directArenaSegments', 'validationPasses', 'sourceRoute', 'flags', 'routeOptions'):
            require(actual[field] == first[field], 'Every-row/index/media/dedup workload parity: ' + field)
        stderr_inventory.append({'label': label, **archive.members[label + '.stderr.log']})
        all_children.append({'label': label, 'stdoutSha256': status['stdoutSha256'], 'stderrSha256': status['stderrSha256'],
                             'statusSha256': archive.file_sha(label + '.child-status.json'), 'measured': not diagnostic})
        if diagnostic:
            embedded = dict(plan['diagnostic'])
        else:
            step = schedule[index]
            observed = plan['observations'][index]
            require({key: observed[key] for key in ('pair', 'arm')} == step, 'Exact plan observation role/order')
            embedded = dict(observed['result'])
            raw[(step['pair'], arm)] = actual
            projection = {'dictionary': dictionary, **step, **{key: actual[key] for key in ('rows', 'digest', 'elapsedMs', 'cpuMs', 'inflateMs', 'inflateCpuMs', 'parseMs', 'lookupMs', 'nativeParseMs', 'fusedAttempts', 'fusedFallbacks', 'maxWasmHeapBytes')}}
            require(observations[index] == projection, 'Compact observation equals original child')
        require(embedded.pop('observationStartedEpoch') == status['startedEpoch'] and embedded == actual, 'Embedded result preserves every original value')
    metrics = {}
    for metric in ('elapsedMs', 'cpuMs', 'parseMs', 'nativeParseMs', 'lookupMs'):
        for name, left_arm, right_arm in (('candidate', 'A', 'B'), ('identicalControl', 'C', 'D')):
            left = [raw[(pair, left_arm)][metric] for pair in range(4)]
            right = [raw[(pair, right_arm)][metric] for pair in range(4)]
            summary = pair_stats(left, right, plan['python'])
            require(summary == plan['summary'][name + '.' + metric], 'Exact producer arithmetic: ' + name + '.' + metric)
            metrics[name + '.' + metric] = {'baselineValues': left, 'comparisonValues': right, **summary}
    require(len(plan['summary']) == 10, 'Exact five metrics for both comparisons')
    counts = plan['diagnostic']['diagnostic']
    require(plan['diagnostic']['glossaryReuseCount'] == raw[(0, 'B')]['glossaryReuseCount'], 'Instrumented and production grammar reuse totals')
    require(set(counts) == set(expected['diagnosticFields']), 'All16 actual diagnostic slots')
    for name, value in counts.items():
        integer(value, 'Diagnostic ' + name)
    require(counts['numericRejected'] <= counts['eligibleStreakRows'], 'Numeric admission rejection bound')
    require(counts['attempts'] <= counts['eligibleStreakRows'] - counts['numericRejected'], 'Admitted suffix attempt bound')
    require(counts['hits'] + counts['tailRejected'] + counts['fullRejected'] == counts['boundedRanges'] <= counts['attempts'], 'Complete proof outcome partition')
    require(counts['hits'] == counts['actualSuffixSuccessRows'] == counts['scoreTokenEndScansAvoided'] == counts['numericCopyRows'] == counts['scoreConversionsAvoided'] == counts['ordinaryContentComparisonsAvoided'], 'Positive proofs reach each declared ordinary consumer on valid corpus')
    require(counts['sequenceTokenEndScansAvoided'] == counts['sequenceConversionsAvoided'] <= counts['numericCopyRows'], 'Non-null sequence scans/conversions skipped')
    require(counts['hitBytes'] <= counts['potentialRangeBytes'], 'Proof byte bounds')
    if dictionary == 'vndb':
        require(counts['hits'] > 0, 'Target actually exercises positive proof/consumers')
    effect = metrics['candidate.elapsedMs']['medianPairedChangePercent']
    changes = metrics['candidate.elapsedMs']['pairedChangesPercent']
    control = max(abs(x) for x in metrics['identicalControl.elapsedMs']['pairedChangesPercent'])
    target = expected['criteria']['componentTargetPromotion']
    risk = expected['criteria']['componentNonTargetRisk']
    gate = {'targetPromotionSignal': dictionary == target['dictionary'] and effect <= -target['minimumMedianPairedReductionPercent'] and sum(x < 0 for x in changes) == target['requiredFasterPairs'] and -effect > control,
            'nonTargetRiskSignal': dictionary in risk['dictionaries'] and effect > risk['strictlyGreaterMedianPairedSlowdownPercent'] and sum(x > 0 for x in changes) == risk['requiredSlowerPairs'] and effect > control,
            'largestAbsoluteControlChangePercent': control}
    require(all(plan['componentGate'][key] == value for key, value in gate.items()), 'Prospective component decision arithmetic')
    compact = one(records, 'SUFFIX_PROOF_RESULT')
    require(compact == {'dictionary': dictionary, 'complete': True, 'scope': plan['scope'], 'summary': plan['summary'], 'componentGate': plan['componentGate'], 'mechanicalCounts': counts, 'rows': first['rows'], 'digest': first['digest']}, 'Terminal primary summary equals raw plan')
    oracle = native_oracle(archive, 'native-oracle', expected, product, dictionary)
    require(archive.json('native-oracle/native-oracle.json') == one(records, 'SUFFIX_PROOF_NATIVE_ORACLE'), 'Original oracle report equals primary')
    expected_members = {label + suffix for label in labels for suffix in ('.stdout.json', '.stderr.log', '.child-status.json')}
    expected_members.update(['result.json', 'component-setup.json', 'compiled-source-binding.json', 'correctness-result.json', 'diagnostic.wasm', 'diagnostic-source.c', 'diagnostic-build.json', 'smoke-parity.json', 'native-oracle/native-oracle.json', 'native-oracle/native-oracle-records.jsonl'])
    require(set(archive.members) == expected_members, 'Complete exact original member inventory')
    audit.update(complete=True, observations=16, diagnosticChildren=1, originalChildren=all_children,
                 allOutliersRetained=True, stderrInventory=stderr_inventory,
                 product=product, rowsPerObservation=first['rows'], digest=first['digest'], indexBytes=first['indexBytes'],
                 metrics=metrics, producerPython=plan['python'], mechanicalCounts=counts, componentGate=gate,
                 nativeMetadataOracle=oracle, buildAuditSha256=sha(args.build_audit.read_bytes()),
                 rawResultSha256=archive.file_sha('result.json'),
                 maxWasmHeapBytesByArm={arm: [raw[(pair, arm)]['maxWasmHeapBytes'] for pair in range(4)] for arm in 'ABCD'},
                 interpretation='Separate component evidence only; no pooling, control subtraction, dropped outliers, full-import or process-memory qualification.')
except Exception as error:
    audit['error'] = str(error)
    audit['failureType'] = type(error).__name__
    (args.output / 'failure-traceback.txt').write_text(traceback.format_exc())
finally:
    if archive is not None:
        archive.zip.close()
    path = args.output / 'independent-component-audit.json'
    path.write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps({'complete': audit['complete'], 'path': str(path), 'sha256': sha(path.read_bytes()),
                      'dictionary': args.dictionary, 'error': audit.get('error')}, separators=(',', ':')))
if not audit['complete']:
    raise SystemExit(1)
