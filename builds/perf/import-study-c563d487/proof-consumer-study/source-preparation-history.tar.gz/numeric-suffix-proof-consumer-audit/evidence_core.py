"""Read-only evidence utilities. Never execute a native module or artifact code."""
import base64
import collections
import hashlib
import json
import math
import pathlib
import re
import stat
import zipfile


class AuditFailure(AssertionError):
    pass


def require(condition, label):
    if not condition:
        raise AuditFailure(label)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def _object_pairs(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'Duplicate JSON key: ' + key)
        result[key] = value
    return result


def parse_json(data):
    def invalid(value):
        raise AuditFailure('Nonfinite JSON constant: ' + value)
    return json.loads(data, object_pairs_hook=_object_pairs, parse_constant=invalid)


def integer(value, label):
    require(type(value) is int and value >= 0, label + ': expected nonnegative integer')


def finite(value, label, positive=False):
    require(type(value) in (int, float) and math.isfinite(value), label + ': expected finite number')
    require(value > 0 if positive else value >= 0, label + ': unexpected sign')


def relative_path(name):
    path = pathlib.PurePosixPath(name)
    require(name and not path.is_absolute() and '..' not in path.parts and '\\' not in name,
            'Unsafe evidence member: ' + name)
    require(path.as_posix() == name, 'Noncanonical evidence member: ' + name)
    return path


class Archive:
    def __init__(self, path, metadata, expected):
        self.path = pathlib.Path(path)
        self.metadata = metadata
        require(self.path.stat().st_size == metadata['sizeBytes'], 'Original API artifact size')
        with self.path.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        require(digest == metadata['sha256'], 'Original API artifact SHA-256')
        publication = expected['publication']
        require(metadata['runId'] == publication['runId'] and metadata['runAttempt'] == 1,
                'Original run/attempt identity')
        require(metadata['headSha'] == publication['commit'], 'Original artifact source head')
        self.zip = zipfile.ZipFile(path)
        self.members = {}
        for item in self.zip.infolist():
            if item.is_dir():
                relative_path(item.filename.rstrip('/'))
                continue
            relative_path(item.filename)
            require(item.filename not in self.members, 'Duplicate ZIP member: ' + item.filename)
            require(stat.S_IFMT(item.external_attr >> 16) != stat.S_IFLNK,
                    'Symlink ZIP member: ' + item.filename)
            digest = hashlib.sha256()
            size = 0
            with self.zip.open(item) as stream:
                while block := stream.read(65536):
                    digest.update(block)
                    size += len(block)
            require(size == item.file_size, 'ZIP length: ' + item.filename)
            self.members[item.filename] = {'bytes': size, 'sha256': digest.hexdigest(), 'crc32': item.CRC}
        self.sha256 = metadata['sha256']

    def read(self, name):
        require(name in self.members, 'Missing original member: ' + name)
        return self.zip.read(name)

    def json(self, name):
        return parse_json(self.read(name))

    def file_sha(self, name):
        require(name in self.members, 'Missing original member: ' + name)
        return self.members[name]['sha256']


TAG = re.compile(r'^\ufeff?(?:\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d+Z\s+)?(SUFFIX_PROOF_[A-Z_]+) (\{.*\})$')


def primary_records(path):
    raw = pathlib.Path(path).read_bytes()
    records = []
    for number, line in enumerate(raw.decode('utf-8').splitlines(), 1):
        match = TAG.fullmatch(line)
        if match:
            records.append({'tag': match[1], 'value': parse_json(match[2]), 'line': number,
                            'lineSha256': sha(line.encode())})
    return raw, records


def values(records, tag):
    return [record['value'] for record in records if record['tag'] == tag]


def one(records, tag):
    selected = values(records, tag)
    require(len(selected) == 1, 'Exactly one primary ' + tag)
    return selected[0]


def tracked_native(value, native_paths):
    rows = [line.strip().split(maxsplit=1) for line in value.splitlines()]
    require(all(len(row) == 2 and row[0] == 'M' for row in rows), 'Only modified tracked native paths')
    require(len(rows) == len(native_paths) and {row[1] for row in rows} == set(native_paths),
            'Exact tracked native path set')


def python_sum(values_, runtime):
    """Replay the producer's CPython sum, not JavaScript's sequential reduce."""
    require(runtime['implementation'] == 'cpython', 'Unsupported producer sum implementation')
    version = runtime['versionInfo']
    require(version[0] == 3 and 11 <= version[1] <= 14, 'Unreviewed producer Python sum version')
    require(all(type(x) in (int, float) and math.isfinite(x) and abs(x) < 2**53 for x in values_), 'Finite bounded producer sum values')
    if version[1] < 12:
        total = 0
        for value in values_:
            total += value
        return total
    # CPython 3.12+ keeps integer accumulation until the first float, then uses
    # its compensated hi/lo update. This matters for secondary equal-work sums;
    # it never rewrites any original JavaScript-measured scalar.
    prefix = 0
    iterator = iter(values_)
    for value in iterator:
        if type(value) is int:
            prefix += value
        else:
            initial_float = float(prefix) + value
            pending = list(iterator)
            break
    else:
        return prefix
    high, low = initial_float, 0.0
    for value in pending:
        if version[1] < 14 and type(value) is int:
            # CPython 3.12/3.13 add a subsequent fitting integer directly;
            # 3.14 sends that value through the compensated helper as well.
            high += float(value)
            continue
        value = float(value)
        total = high + value
        low += ((high - total) + value) if abs(high) >= abs(value) else ((value - total) + high)
        high = total
    return high + low if low and math.isfinite(low) else high


def pair_stats(left, right, runtime):
    require(len(left) == len(right) == 4, 'Four fixed paired observations')
    for value in left + right:
        finite(value, 'paired metric', positive=True)
    changes = [100 * (second / first - 1) for first, second in zip(left, right)]
    ordered = sorted(changes)
    return {'pairedChangesPercent': changes,
            'medianPairedChangePercent': (ordered[1] + ordered[2]) / 2,
            'equalWorkChangePercent': 100 * (python_sum(right, runtime) / python_sum(left, runtime) - 1),
            'fasterPairs': sum(change < 0 for change in changes)}


def native_oracle(archive, prefix, expected, product, dictionary):
    report = archive.json(prefix + '/native-oracle.json')
    records_name = prefix + '/native-oracle-records.jsonl'
    require(report['complete'] is True and report['failures'] == [], 'Native oracle complete without failures')
    require(report['node'] == 'v22.22.0', 'Native oracle Node')
    require(report['oracleSha256'] == expected['binding']['toolingFiles']['native-oracle.mjs'], 'Native oracle code')
    require(report['dictionary'] == dictionary, 'Native oracle dictionary')
    require(report['recordsSha256'] == archive.file_sha(records_name), 'Every native oracle record byte')
    for arm in ('baseline', 'candidate'):
        bound = expected['binding']['baseline'] if arm == 'baseline' else product
        require(report['sources'][arm]['sourceSha256'] == bound['cSha256'], 'Oracle C binding: ' + arm)
        require(report['sources'][arm]['wasmSha256'] == bound['wasmSha256'], 'Oracle WASM binding: ' + arm)
    seen = {}
    synthetic = 0
    for line in archive.read(records_name).splitlines():
        record = parse_json(line)
        require(record['baseline'] == record['candidate'], 'Every raw native attempt metadata hash/word/result')
        require(record['exportName'] in expected['strictExports'], 'Declared strict native export')
        require(record['baseline'], 'Native oracle attempt retained')
        for attempt in record['baseline']:
            integer(attempt['capacity'], 'Native capacity')
            integer(attempt['reportedCapacity'], 'Native reported capacity')
            require(attempt['words'] == (attempt['result'] if attempt['result'] >= 0 else attempt['capacity']) * 17,
                    'All17 words, including partial error capacity')
            require(re.fullmatch('[0-9a-f]{64}', attempt['digest']), 'Native metadata digest shape')
        if record['kind'] == 'synthetic':
            synthetic += 1
        else:
            require(record['kind'] == 'lockedBank' and dictionary is not None, 'Locked native record route')
            key = (record['name'], record['exportName'])
            require(key not in seen, 'No duplicate native bank/export')
            last = record['baseline'][-1]
            require(last['result'] >= 0, 'Locked native rows fully accepted')
            seen[key] = last['result']
    require(synthetic == report['synthetic']['exportComparisons'] == report['synthetic']['cases'] * 2,
            'Synthetic native case/export inventory')
    require(report['synthetic']['cases'] == expected['syntheticOracleCases'], 'Frozen synthetic case count')
    for name in expected['strictExports']:
        rows = [count for (_, export), count in seen.items() if export == name]
        cell = report['corpus'][name]
        require(len(rows) == cell['banks'] and sum(rows) == cell['rows'], 'Native corpus bank/row totals')
        if dictionary is not None:
            require(cell['rows'] == expected['fixtures'][dictionary]['termRows'], 'Every locked corpus row')
            require(cell['banks'] == expected['fixtures'][dictionary]['termBanks'], 'Every locked term bank')
    if dictionary is not None:
        require(report['archiveSha256'] == expected['fixtures'][dictionary]['sha256'], 'Native oracle archive')
        require(report['fixtureLockSha256'] == expected['binding']['fixtureLockSha256'], 'Native oracle lock')
    return {'syntheticCases': report['synthetic']['cases'], 'syntheticComparisons': synthetic,
            'corpus': report['corpus'], 'recordsSha256': report['recordsSha256'],
            'scope': 'Producer compares all17 words through both raw strict exports. This replay validates every archived attempt hash/length/result and source binding; raw word arrays are not archived. Fused proof activation is separate.'}


def build_bytes(archive, records):
    start = one(records, 'SUFFIX_PROOF_BUILD_BYTES_START')
    end = one(records, 'SUFFIX_PROOF_BUILD_BYTES_COMPLETE')
    manifest_name = 'post-correctness-byte-manifest.json'
    require(start == archive.json(manifest_name), 'Original post-correctness byte manifest')
    require(end['complete'] is True and end['sourceOrAcquisitionChanged'] is False, 'Byte emission completion')
    require(end['manifestSha256'] == archive.file_sha(manifest_name), 'Byte manifest SHA')
    require(start['fileCount'] == end['fileCount'] == len(start['files']), 'Byte emission file count')
    require(start['bytes'] == end['bytes'] == sum(x['bytes'] for x in start['files']), 'Byte emission size')
    require(values(records, 'SUFFIX_PROOF_BUILD_FILE') == start['files'], 'Ordered file announcements')
    chunks = values(records, 'SUFFIX_PROOF_BUILD_CHUNK')
    cursor = 0
    for file in start['files']:
        data = bytearray()
        require(file['chunkBytes'] == 6144 and file['chunkCount'] == (file['bytes'] + 6143) // 6144,
                'Fixed byte chunk geometry')
        for index in range(file['chunkCount']):
            require(cursor < len(chunks), 'Missing original byte chunk')
            chunk = chunks[cursor]
            cursor += 1
            require(chunk['path'] == file['path'] and chunk['index'] == index, 'Ordered unique byte chunks')
            part = base64.b64decode(chunk['base64'], validate=True)
            require(len(part) == min(6144, file['bytes'] - index * 6144), 'Byte chunk exact length')
            data.extend(part)
        data = bytes(data)
        require(len(data) == file['bytes'] and sha(data) == file['sha256'] and git_blob(data) == file['gitBlobSha1'],
                'Recovered exact file SHA/size/Git blob')
        require(data == archive.read(file['path']), 'Primary recovered bytes equal original artifact')
    require(cursor == len(chunks), 'No extra byte chunks')
    return {'files': start['fileCount'], 'chunks': cursor, 'bytes': start['bytes'],
            'manifestSha256': end['manifestSha256'], 'allBytesMatchOriginalArtifact': True}
