"""Original build/correctness artifact audit. No compiler, module or test execution."""
import argparse
import collections
import copy
import datetime
import json
import pathlib
import re
import subprocess
import tempfile
import traceback

from evidence_core import (Archive, build_bytes, finite, git_blob, integer, native_oracle,
                           one, parse_json, primary_records, require, sha, tracked_native, values)

parser = argparse.ArgumentParser()
for name in ('expected', 'metadata', 'archive', 'primary', 'output'):
    parser.add_argument('--' + name, type=pathlib.Path, required=True)
args = parser.parse_args()
require(not args.output.exists(), 'Never replace an earlier build audit')
args.output.mkdir(parents=True)
audit = {'schema': 1, 'complete': False, 'correctnessPass': False,
         'auditedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'scope': 'Independent original build ZIP and primary logs, exact native/test bytes, command receipts and raw oracles. No compilation, native/test execution, corpus acquisition or timings.',
         'auditorSha256': sha(pathlib.Path(__file__).read_bytes()),
         'coreSha256': sha(pathlib.Path(__file__).with_name('evidence_core.py').read_bytes())}
archive = None
try:
    expected = parse_json(args.expected.read_bytes())
    require(expected['finalized'] is True and expected['publication']['runId'] is not None, 'Frozen published expectations')
    binding = expected['binding']
    require(binding['finalized'] is True, 'Reviewed producer binding')
    metadata = parse_json(args.metadata.read_bytes())
    require(metadata['cell'] == 'build', 'Original build artifact role')
    archive = Archive(args.archive, metadata, expected)
    audit.update(artifact=metadata, expectedSha256=sha(args.expected.read_bytes()), members=archive.members)
    (args.output / 'original-member-hashes.json').write_text(json.dumps(archive.members, indent=2) + '\n')
    primary_raw, records = primary_records(args.primary)
    audit['primaryLogSha256'] = sha(primary_raw)
    audit['primaryRecordCounts'] = dict(collections.Counter(row['tag'] for row in records))
    (args.output / 'primary-records.jsonl').write_text(''.join(json.dumps(row, separators=(',', ':')) + '\n' for row in records))
    start = archive.json('preparation-start.json')
    require(start['binding'] == binding and start['bindingSha256'] == expected['bindingSha256'], 'Original reviewed binding bytes')
    require(start['toolingHead'] == expected['publication']['commit'] and start['toolingTree'] == expected['publication']['tree'], 'Original build tooling source')
    require(start['node'] == 'v22.22.0' and '21.1.8' in start['compiler'] and '21.1.8' in start['linker'], 'Pinned build runtime/toolchain')
    if 'result.json' not in archive.members:
        audit['preservedIncomplete'] = {'commandReceipts': [archive.json(name) for name in archive.members if name.endswith('.receipt.json')],
                                      'reason': 'Original preparation has no successful result; no promotion or reconstructed success.'}
        raise AssertionError('Original build/correctness preparation incomplete')
    result = archive.json('result.json')
    require(result['complete'] is True and result['correctnessPass'] is True, 'All declared correctness gates succeeded')
    require(result == one(records, 'SUFFIX_PROOF_BUILD_RESULT'), 'Original final correctness result equals primary')
    compiled = archive.json('compiled-source-binding.json')
    require(result['baseline'] == compiled['baseline'] == binding['baseline'], 'Exact baseline native identity')
    require(result['bindingSha256'] == expected['bindingSha256'], 'Correctness result binding')
    require(compiled['candidateSource'] == binding['candidateCSourceSha256'], 'Reviewed candidate C')
    products = result['productFilesSha256']
    require(products == compiled['productFilesSha256'], 'Compiled and tested product maps identical')
    expected_products = set(expected['nativePaths']) | {'test/' + name for name in binding['qualificationFiles']}
    require(set(products) == expected_products and len(products) == 8, 'Exact three native plus five qualification files')
    product_blob_ids = {}
    for name, digest in products.items():
        require(archive.file_sha('product/' + name) == digest, 'Original product SHA: ' + name)
        product_blob_ids[name] = git_blob(archive.read('product/' + name))
        if name.startswith('test/'):
            require(digest == binding['qualificationFiles'][pathlib.PurePosixPath(name).name], 'Reviewed qualification bytes')
    c_path, wasm_path, manifest_path = expected['nativePaths']
    require(products[c_path] == binding['candidateCSourceSha256'], 'Actual reviewed source bytes')
    require(archive.read('product/' + wasm_path)[:8] == b'\0asm\1\0\0\0', 'Actual WebAssembly module header')
    require(compiled['extWasmSha256'] == products[wasm_path], 'Runtime/tracked WASM byte equality')
    tracked_native(compiled['candidateTrackedChanges'], expected['nativePaths'])
    manifest = archive.json('product/' + manifest_path)
    source_map = dict(expected['baselineNativeSourceHashes'])
    source_map[c_path] = products[c_path]
    source_digest = sha(''.join(name + '\0' + source_map[name] + '\n' for name in sorted(source_map)).encode())
    require(manifest['sourceFileCount'] == len(source_map) == 14 and manifest['sourceDigest'] == source_digest, 'All native C/header source-digest inputs')
    normalized = copy.deepcopy(manifest)
    normalized['sourceDigest'] = expected['baselineManifest']['sourceDigest']
    targets = [item for item in normalized['targets'] if item['name'] == 'term-bank-parser.wasm']
    require(len(targets) == 1 and targets[0]['sha256'] == products[wasm_path], 'Manifest pins actual candidate WASM')
    targets[0]['sha256'] = binding['baseline']['wasmSha256']
    require(normalized == expected['baselineManifest'], 'Exact pinned compiler arguments/exports/other target unchanged')
    rebuilt = archive.read('rebuilt-candidate.diff')
    require(sha(rebuilt) == compiled['rebuiltDiffSha256'], 'Original binary diff hash')
    pairs = re.findall(r'^diff --git a/(\S+) b/(\S+)$', rebuilt.decode(), re.M)
    require(len(pairs) == 3 and {a for a, b in pairs if a == b} == set(expected['nativePaths']), 'Only three allowed native paths in binary diff')
    # Git applies a bounded data-only diff in a fresh temporary directory. No
    # artifact-provided executable or command is ever invoked.
    with tempfile.TemporaryDirectory(prefix='suffix-proof-reverse-') as temporary:
        root = pathlib.Path(temporary)
        for name in expected['nativePaths']:
            target = root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(archive.read('product/' + name))
        patch = root / 'original.diff'
        patch.write_bytes(rebuilt)
        for flag in (['--check'], []):
            call = subprocess.run(['git', 'apply', '--reverse', *flag, str(patch)], cwd=root, capture_output=True)
            require(call.returncode == 0, 'Exact original diff reversal: ' + call.stderr.decode(errors='replace'))
        for name, field in ((c_path, 'cSha256'), (wasm_path, 'wasmSha256'), (manifest_path, 'manifestSha256')):
            require(sha((root / name).read_bytes()) == binding['baseline'][field], 'Reversed diff exact baseline: ' + name)
    product = {'cSha256': products[c_path], 'wasmSha256': products[wasm_path],
               'manifestSha256': products[manifest_path], 'wasmBytes': archive.members['product/' + wasm_path]['bytes']}
    labels = expected['buildCommandLabels']
    require(len(labels) == len(set(labels)) == 26, 'Frozen command inventory')
    steps = values(records, 'SUFFIX_PROOF_BUILD_STEP')
    require([row['label'] for row in steps] == labels, 'All26 original primary command receipts in execution order')
    require(set(result['commandReceiptSha256']) == {name + '.receipt.json' for name in labels}, 'All26 final command receipt hashes')
    receipts = {name: archive.json(name + '.receipt.json') for name in labels}
    repo = receipts['fetch-baseline']['cwd']
    baseline = receipts['create-baseline']['command'][4]
    candidate = receipts['create-candidate']['command'][4]
    tooling = repo + '/dev/perf/numeric-suffix-proof-consumer-c563d487'
    output = receipts['build-counter-only-module']['command'][3]
    commands = {
        'fetch-baseline': (repo, ['git', 'fetch', '--no-tags', 'origin', binding['baseline']['commit']]),
        'create-baseline': (repo, ['git', 'worktree', 'add', '--detach', baseline, binding['baseline']['commit']]),
        'create-candidate': (repo, ['git', 'worktree', 'add', '--detach', candidate, binding['baseline']['commit']]),
        'dependencies-baseline': (repo, ['cp', '-a', repo + '/node_modules', baseline + '/node_modules']),
        'dependencies-candidate': (repo, ['cp', '-a', repo + '/node_modules', candidate + '/node_modules']),
        'reproduce-baseline': (baseline, ['npm', 'run', 'build:dictionary-wasm', '--', '--check']),
        'build-baseline-libraries': (baseline, ['npm', 'run', 'build:libs']),
        'apply-check': (candidate, ['git', 'apply', '--check', tooling + '/candidate.patch']),
        'apply-patch': (candidate, ['git', 'apply', tooling + '/candidate.patch']),
        'build-native-candidate': (candidate, ['npm', 'run', 'build:dictionary-wasm', '--', '--write']),
        'build-candidate-libraries': (candidate, ['npm', 'run', 'build:libs']),
        'reproduce-candidate': (candidate, ['npm', 'run', 'build:dictionary-wasm', '--', '--check']),
        'scoped-lint': (candidate, ['npx', 'eslint', *['test/' + name for name in binding['qualificationFiles']]]),
        'strict-main-types': (candidate, ['npm', 'run', 'test:ts:main']),
        'strict-test-types': (candidate, ['npm', 'run', 'test:ts:test']),
        'complete-unit-suite': (candidate, ['npm', 'run', 'test:unit', '--', '--maxWorkers=2']),
        'options-unit-suite': (candidate, ['npm', 'run', 'test:unit:options', '--', '--maxWorkers=2']),
        'all-dry-build-targets': (candidate, ['npm', 'run', 'test:build']),
        'build-counter-only-module': (repo, ['python3', tooling + '/prepare-diagnostic.py', candidate, output]),
        'synthetic-raw-native-oracle': (repo, ['node', tooling + '/native-oracle.mjs', '--baseline', baseline,
                                            '--candidate', candidate, '--output', output + '/synthetic-native-oracle', '--synthetic-only']),
    }
    smoke_labels = ['baseline', 'candidate', 'diagnostic', 'disabled-baseline', 'disabled-candidate', 'disabled-diagnostic']
    for label in smoke_labels:
        selected = baseline if label.endswith('baseline') else candidate
        command = ['node', tooling + '/smoke.mjs', selected]
        if label.endswith('diagnostic'):
            command.append(output + '/diagnostic.wasm')
        if label.startswith('disabled-'):
            command.append('--disabled-reuse')
        commands['smoke-' + label] = (repo, command)
    prior_finish = None
    for label, primary in zip(labels, steps):
        receipt = receipts[label]
        require(receipt == primary, 'Original command receipt equals primary: ' + label)
        require(archive.file_sha(label + '.receipt.json') == result['commandReceiptSha256'][label + '.receipt.json'], 'Final command receipt byte binding')
        require(receipt['exitCode'] == 0, 'Required correctness command succeeded: ' + label)
        require((receipt['cwd'], receipt['command']) == commands[label], 'Exact required command and working directory: ' + label)
        finite(receipt['startedEpoch'], label + '/start', True)
        finite(receipt['finishedEpoch'], label + '/finish', True)
        require(receipt['finishedEpoch'] >= receipt['startedEpoch'] and (prior_finish is None or receipt['startedEpoch'] >= prior_finish), 'Serial correctness commands')
        prior_finish = receipt['finishedEpoch']
        if label.startswith('smoke-'):
            require(archive.file_sha(label + '.json') == receipt['stdoutSha256'] and archive.file_sha(label + '.stderr.log') == receipt['stderrSha256'], 'Original smoke stdout/stderr')
        else:
            require(archive.file_sha(label + '.log') == receipt['logSha256'], 'Every original command log')
    require(result['diagnosticWasmSha256'] == archive.file_sha('diagnostic.wasm'), 'Separate instrumented WASM identity')
    require(result['diagnosticSourceSha256'] == archive.file_sha('diagnostic-source.c') == expected['diagnosticSourceSha256'], 'Reviewed separate diagnostic source')
    require(result['diagnosticBuildSha256'] == archive.file_sha('diagnostic-build.json'), 'Diagnostic build receipt bytes')
    diagnostic = archive.json('diagnostic-build.json')
    require(diagnostic['sourceOnly'] is False and diagnostic['productSourceSha256'] == product['cSha256'], 'Actual source-bound diagnostic build')
    require(diagnostic['diagnosticFields'] == expected['diagnosticFields'] and diagnostic['diagnosticFieldsSha256'] == binding['toolingFiles']['diagnostic-fields.json'], 'Exact16 diagnostic slots')
    require(diagnostic['diagnosticSourceSha256'] == result['diagnosticSourceSha256'] and diagnostic['diagnosticWasmSha256'] == result['diagnosticWasmSha256'], 'Diagnostic source/artifact correspondence')
    require('21.1.8' in diagnostic['compiler'] and '21.1.8' in diagnostic['linker'], 'Pinned diagnostic compiler')
    term_target = next(t for t in manifest['targets'] if t['name'] == 'term-bank-parser.wasm')
    command = diagnostic['command']
    require(pathlib.PurePosixPath(command[0]).name == 'clang-21' and command[1].startswith('-fuse-ld=') and pathlib.PurePosixPath(command[1][9:]).name == 'wasm-ld-21', 'Pinned diagnostic command tools')
    require(command[2:] == term_target['arguments'] + ['-Wl,--export=row_suffix_diag_get', '-o', output + '/diagnostic.wasm', output + '/diagnostic-source.c', candidate + '/' + term_target['sources'][1], '-I' + candidate + '/ext/js/dictionary/wasm'], 'Exact original arguments plus diagnostic getter only')
    smoke_reports = [archive.json('smoke-' + label + '.json') for label in smoke_labels]
    require(all(report['results'] == smoke_reports[0]['results'] for report in smoke_reports), 'All six complete smoke output representations equal')
    for label, report in zip(smoke_labels, smoke_reports):
        require(report['disabledReuse'] == label.startswith('disabled-'), 'Smoke enabled/disabled identity')
        require(report['validCases'] == 34 and report['originalValidCases'] == 18 and report['proofConsumerCases'] == 16 and report['malformedCases'] == 13 and len(report['results']) == 35, 'Exact original plus new smoke inventory')
        require([row['name'] for row in report['results']] == expected['smokeValidNames'] + ['fresh-valid-input-after-all-failures'], 'Exact ordered smoke result cases')
        diagnostic_mode = label.endswith('diagnostic')
        require(len(report['diagnostics']) == (47 if diagnostic_mode else 0), 'Every valid/malformed diagnostic receipt')
        if not diagnostic_mode:
            require(report['diagnosticHits'] is None and report['diagnosticAttempts'] is None, 'No product diagnostic getter')
            continue
        by_name = {row['name']: row for row in report['diagnostics']}
        require(len(by_name) == 47, 'Unique diagnostic fixture names')
        require([row['name'] for row in report['diagnostics']] == expected['smokeValidNames'] + expected['smokeMalformedNames'], 'Every diagnostic case in the frozen order')
        for row in report['diagnostics']:
            require(set(row) == {'name', *expected['diagnosticFields']}, 'Complete per-case16-counter delta')
            for field in expected['diagnosticFields']:
                integer(row[field], 'Per-case diagnostic ' + field)
            require(row['hits'] == row['actualSuffixSuccessRows'] == row['scoreTokenEndScansAvoided'], 'Per-case proof status/end-scan attribution')
            require(row['numericCopyRows'] == row['scoreConversionsAvoided'] <= row['hits'], 'Per-case post-key numeric attribution')
            require(row['sequenceConversionsAvoided'] <= row['numericCopyRows'] and row['sequenceTokenEndScansAvoided'] <= row['hits'], 'Per-case nullable sequence attribution')
            require(row['ordinaryContentComparisonsAvoided'] <= row['numericCopyRows'], 'Per-case ordinary/global attribution')
        for fixture in expected['proofFixtureExpectations']:
            row = by_name[fixture['name']]
            disabled = report['disabledReuse'] or fixture['disabled']
            proof = 0 if disabled else fixture['proofs']
            require(row['hits'] == proof and row['sequenceTokenEndScansAvoided'] == (0 if fixture['allNullSequences'] else proof), 'Frozen proof/boundary expectation: ' + fixture['name'])
            require(row['numericCopyRows'] == (0 if disabled else fixture['numericReuseRows']), 'Frozen numeric consumer expectation')
            require(row['sequenceConversionsAvoided'] == (0 if disabled else fixture['sequenceConversionsAvoided']), 'Frozen non-null conversion expectation')
            require(row['ordinaryContentComparisonsAvoided'] == (0 if disabled else fixture['ordinaryComparisonSkips']), 'Frozen ordinary comparison skip expectation')
        require(report['diagnosticHits'] == sum(row['hits'] for row in report['diagnostics']) and report['diagnosticAttempts'] == sum(row['attempts'] for row in report['diagnostics']), 'Cumulative smoke proof counts include all failures and fresh call')
        if report['disabledReuse']:
            require(all(row[field] == 0 for row in report['diagnostics'] for field in expected['diagnosticFields']), 'Reuse opt-out leaves every suffix counter zero across calls/failures')
        else:
            require(report['diagnosticHits'] > 0, 'Smoke positive full-proof activation')
    parity = archive.json('smoke-parity.json')
    require(parity['passed'] is True and parity['validCases'] == 34 and parity['malformedCases'] == 13 and parity['resultRecords'] == 35, 'Frozen smoke parity receipt')
    require(parity['diagnosticHits'] == smoke_reports[2]['diagnosticHits'] and parity['disabledAttempts'] == parity['disabledHits'] == 0, 'Smoke positive/disabled summaries')
    require(result['smokeParitySha256'] == archive.file_sha('smoke-parity.json'), 'Original smoke parity bytes')
    oracle = native_oracle(archive, 'synthetic-native-oracle', expected, product, None)
    require(result['syntheticNativeOracleSha256'] == archive.file_sha('synthetic-native-oracle/native-oracle.json'), 'Original synthetic oracle report bytes')
    for label, desired in [('reproduce-baseline', binding['baseline']['wasmSha256']),
                           ('build-native-candidate', product['wasmSha256']), ('reproduce-candidate', product['wasmSha256'])]:
        log = archive.read(label + '.log').decode()
        payloads = []
        for match in re.finditer(r'^\{', log, re.M):
            try:
                payload = parse_json(log[match.start():])
            except (ValueError, AssertionError):
                continue
            if type(payload) is dict and 'toolchain' in payload and 'targets' in payload:
                payloads.append(payload)
        require(len(payloads) == 1, 'One original native build/reproduction result: ' + label)
        payload = payloads[0]
        require(payload['toolchain'] == manifest['toolchain'], 'Native log pinned toolchain: ' + label)
        require(next(item['sha256'] for item in payload['targets'] if item['name'] == 'term-bank-parser.wasm') == desired,
                'Native build/reproduction log exact module: ' + label)
    unit = re.sub(r'\x1b\[[0-9;]*m', '', archive.read('complete-unit-suite.log').decode())
    for name, count in [('term-bank-row-suffix-reuse.test.js', 32), ('term-bank-row-suffix-token-ends.test.js', 9), ('term-bank-row-suffix-proof-consumer.test.js', 17)]:
        require('test/' + name + f' ({count} tests)' in unit, 'All focused cases in successful complete suite: ' + name)
    unit_totals = re.findall(r'Tests\s+(\d+) passed(?:\s+\|\s+(\d+) skipped)?\s+\((\d+)\)', unit)
    require(len(unit_totals) == 1, 'Original complete unit summary')
    options = re.sub(r'\x1b\[[0-9;]*m', '', archive.read('options-unit-suite.log').decode())
    require(re.search(r'Tests\s+32 passed\s+\(32\)', options), 'Original options suite32 passed')
    targets = re.findall(r'^Building (.+)\.\.\.$', archive.read('all-dry-build-targets.log').decode(), re.M)
    require(targets == ['chrome', 'chrome-dev', 'chrome-playwright', 'firefox', 'firefox-dev', 'firefox-android', 'edge'], 'All seven dry build targets')
    byte_proof = build_bytes(archive, records)
    shared = {name: archive.file_sha(name) for name in ('compiled-source-binding.json', 'diagnostic.wasm', 'diagnostic-source.c', 'diagnostic-build.json', 'smoke-parity.json')}
    expected_members = {'product/' + name for name in products}
    expected_members.update(['preparation-start.json', 'compiled-source-binding.json', 'result.json', 'rebuilt-candidate.diff', 'diagnostic.wasm', 'diagnostic-source.c', 'diagnostic-build.json', 'smoke-parity.json', 'post-correctness-byte-manifest.json', 'synthetic-native-oracle/native-oracle.json', 'synthetic-native-oracle/native-oracle-records.jsonl'])
    for label in labels:
        expected_members.add(label + '.receipt.json')
        expected_members.update([label + '.json', label + '.stderr.log'] if label.startswith('smoke-') else [label + '.log'])
    require(set(archive.members) == expected_members, 'Every original successful build member accounted for')
    audit.update(complete=True, correctnessPass=True, product=product, productFilesSha256=products,
                 productGitBlobSha1=product_blob_ids, compiledSourceBindingSha256=archive.file_sha('compiled-source-binding.json'),
                 correctnessResultSha256=archive.file_sha('result.json'), diagnosticWasmSha256=result['diagnosticWasmSha256'],
                 sharedComponentFiles=shared, sourceDigest=source_digest, nativeSourceFileCount=14,
                 exactBinaryDiffReversedToBaseline=True, all26CommandReceiptsAndLogsMatchPrimary=True,
                 allSixSmokeOutputsEqual=True, focusedCases=58, rawSyntheticOracle=oracle,
                 originalUnitTotals=unit_totals[0], optionsPassed=32, dryBuildTargets=targets,
                 postCorrectnessExactByteProof=byte_proof, buildPython=start['python'],
                 interpretation='Build/correctness only. All component and any future full-import gates remain separate.')
except Exception as error:
    audit['error'] = str(error)
    audit['failureType'] = type(error).__name__
    (args.output / 'failure-traceback.txt').write_text(traceback.format_exc())
finally:
    if archive is not None:
        archive.zip.close()
    path = args.output / 'independent-build-audit.json'
    path.write_text(json.dumps(audit, indent=2) + '\n')
    print(json.dumps({'complete': audit['complete'], 'path': str(path), 'sha256': sha(path.read_bytes()),
                      'error': audit.get('error')}, separators=(',', ':')))
if not audit['complete']:
    raise SystemExit(1)
