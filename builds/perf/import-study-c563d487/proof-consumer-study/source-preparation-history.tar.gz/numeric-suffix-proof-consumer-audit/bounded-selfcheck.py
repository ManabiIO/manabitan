"""Small data-parser and producer-arithmetic checks; no native or measurement work."""
import datetime
import hashlib
import json
import pathlib
import stat
import warnings
import zipfile

from evidence_core import Archive, AuditFailure, one, pair_stats, parse_json, primary_records, python_sum, require, sha

root = pathlib.Path(__file__).resolve().parent
output = root / 'bounded-selfcheck-1'
require(not output.exists(), 'Retain every selfcheck attempt')
output.mkdir()
checks = []


def check(name, action, rejection=False):
    try:
        action()
    except Exception as error:
        if not rejection:
            raise
        checks.append({'name': name, 'outcome': 'rejected', 'type': type(error).__name__, 'message': str(error)})
        return
    require(not rejection, 'Accepted deliberate corruption: ' + name)
    checks.append({'name': name, 'outcome': 'accepted'})


check('duplicate JSON key', lambda: parse_json('{"a":1,"a":2}'), True)
check('nonfinite JSON constant', lambda: parse_json('{"a":NaN}'), True)
metadata = {'runId': 1, 'runAttempt': 1, 'artifactId': 1, 'jobId': 1, 'cell': 'synthetic', 'headSha': 'a' * 40}
expected = {'publication': {'runId': 1, 'commit': 'a' * 40}}


def make_zip(name, paths, symlink=False):
    path = output / (name + '.zip')
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', UserWarning)
        with zipfile.ZipFile(path, 'w') as z:
            for entry in paths:
                item = zipfile.ZipInfo(entry)
                item.create_system = 3
                item.external_attr = ((stat.S_IFLNK if symlink else stat.S_IFREG) | 0o644) << 16
                z.writestr(item, b'{"synthetic":true}\n')
    return path, {**metadata, 'sizeBytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}


def open_zip(path, meta):
    archive = Archive(path, meta, expected)
    archive.zip.close()


valid_path, valid_meta = make_zip('valid', ['data.json'])
check('exact small original ZIP byte binding', lambda: open_zip(valid_path, valid_meta))
for name, entries, symlink in [('duplicate ZIP member', ['data.json', 'data.json'], False),
                                ('parent traversal ZIP member', ['../data.json'], False),
                                ('symlink ZIP member', ['data.json'], True)]:
    path, meta = make_zip(name.replace(' ', '-'), entries, symlink)
    check(name, lambda path=path, meta=meta: open_zip(path, meta), True)
check('wrong original ZIP digest', lambda: open_zip(valid_path, {**valid_meta, 'sha256': '0' * 64}), True)
check('wrong original ZIP length', lambda: open_zip(valid_path, {**valid_meta, 'sizeBytes': valid_meta['sizeBytes'] + 1}), True)
check('wrong source head binding', lambda: open_zip(valid_path, {**valid_meta, 'headSha': 'b' * 40}), True)
for label, prefix, should_pass in [('plain', '', True), ('single-leading-BOM', '\ufeff', True), ('double-leading-BOM', '\ufeff\ufeff', False), ('unanchored-source-text', 'print(', False)]:
    path = output / (label + '.log')
    path.write_text(prefix + '2026-11-28T10:00:00.0000000Z SUFFIX_PROOF_PLAN {"synthetic":true}\n')
    check('primary tag ' + label, lambda path=path: require(one(primary_records(path)[1], 'SUFFIX_PROOF_PLAN') == {'synthetic': True}, 'exact tagged value'), not should_pass)

runtime = lambda minor: {'versionInfo': [3, minor, 0, 'final', 0], 'implementation': 'cpython'}
large = float(2**52)
check('3.11 sequential float sum', lambda: require(python_sum([large, 0.5, 0.5], runtime(11)) == large, '3.11 source semantics'))
check('3.12 compensated float sum', lambda: require(python_sum([large, 0.5, 0.5], runtime(12)) == large + 1, '3.12 source semantics'))
check('3.13 integer additions are direct after float transition', lambda: require(python_sum([large, large, 1, 1], runtime(13)) == 2 * large, '3.13 source semantics'))
check('3.14 integer additions also compensate', lambda: require(python_sum([large, large, 1, 1], runtime(14)) == 2 * large + 2, '3.14 source semantics'))
check('first integer-to-float transition is ordinary addition', lambda: require(python_sum([2**52, 0.5, 0.25, 0.25], runtime(14)) == large, 'first-float source semantics'))
check('numeric string never coerced in producer sum', lambda: python_sum([1.0, '2.0'], runtime(14)), True)

reference = root.parent / 'row-suffix-numeric-corrected-evidence/jmdict/result.json'
original = parse_json(reference.read_bytes())
raw = {(row['pair'], row['arm']): row['result'] for row in original['observations']}
for metric in ('elapsedMs', 'cpuMs', 'parseMs', 'nativeParseMs', 'lookupMs'):
    for name, left_arm, right_arm in (('candidate', 'A', 'B'), ('identicalControl', 'C', 'D')):
        left = [raw[(pair, left_arm)][metric] for pair in range(4)]
        right = [raw[(pair, right_arm)][metric] for pair in range(4)]
        check('retained original arithmetic ' + name + '.' + metric,
              lambda left=left, right=right, name=name, metric=metric: require(pair_stats(left, right, runtime(14)) == original['summary'][name + '.' + metric], 'all original summary scalars exact'))
result = {'schema': 1, 'complete': True, 'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Bounded synthetic archive/log parsing and exact secondary arithmetic using already-retained old raw scalars. No parser/native/corpus execution, no new timing or qualification inference.',
          'checks': checks, 'accepted': sum(x['outcome'] == 'accepted' for x in checks),
          'rejected': sum(x['outcome'] == 'rejected' for x in checks),
          'referenceRawResultSha256': sha(reference.read_bytes()),
          'sourceReferencesSha256': sha((root / 'cpython-sum-source-reference.json').read_bytes()),
          'sourceSha256': sha(pathlib.Path(__file__).read_bytes()),
          'coreSha256': sha((root / 'evidence_core.py').read_bytes())}
path = output / 'result.json'
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'complete': True, 'accepted': result['accepted'], 'rejected': result['rejected'],
                  'sha256': sha(path.read_bytes()), 'path': str(path)}))
