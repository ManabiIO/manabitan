"""Freeze source/fixture/schema expectations before component acquisition."""
from pathlib import Path
import datetime
import hashlib
import json
import re

root = Path(__file__).resolve().parent
host = root.parent / 'numeric-suffix-proof-consumer-hosted'
read = lambda path: json.loads(path.read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
binding = read(host / 'binding.json')
assert sha(host / 'binding.json') == '5c22870daa3bd61b35c822f990dd9c12e93fe51daa05f253e24e8e5af475cd28'
assert binding['finalized'] and not binding['pending']
for name, digest in binding['toolingFiles'].items():
    assert sha(host / name) == digest, name
for name, digest in binding['qualificationFiles'].items():
    assert sha(host / 'qualification' / name) == digest, name
source = read(root / 'baseline-source-binding.json')
criteria = read(host / 'prospective-review-criteria.json')
lock_path = root.parents[1] / 'manabitan/test/perf/dictionaries.lock.json'
assert sha(lock_path) == binding['fixtureLockSha256']
locks = read(lock_path)['dictionaries']
fixtures = {}
for name in ('jmdict', 'jitendex', 'vndb'):
    prior_path = root.parent / 'composite-hints-evidence' / name / 'native-oracle.json'
    prior = read(prior_path)
    spec = locks[name]
    assert prior['complete'] and prior['archiveSha256'] == spec['sha256']
    banks = prior['corpus']['parse_term_bank']['banks']
    assert all(item['banks'] == banks and item['rows'] == spec['termRows'] for item in prior['corpus'].values())
    width = criteria['componentPlan']['filesPerGroup'][name]
    fixtures[name] = {**spec, 'termBanks': banks, 'componentGroups': (banks + width - 1) // width,
                      'fusedGroups': banks // width + int(banks % width > 1),
                      'bankInventoryReceipt': {'path': str(prior_path), 'sha256': sha(prior_path)}}
smoke = (host / 'smoke.mjs').read_text()
old_names = re.findall(r"\{name: '([^']+)'", smoke.split('const valid = [', 1)[1].split('const malformed = [', 1)[0])
malformed_names = re.findall(r"\{name: '([^']+)'", smoke.split('const malformed = [', 1)[1].split('const results = [];', 1)[0])
assert len(old_names) == 18 and len(malformed_names) == 13
proofs = read(root / 'proof-fixture-expectations.json')
labels = ['fetch-baseline', 'create-baseline', 'create-candidate', 'dependencies-baseline', 'dependencies-candidate',
          'reproduce-baseline', 'build-baseline-libraries', 'apply-check', 'apply-patch', 'build-native-candidate',
          'build-candidate-libraries', 'reproduce-candidate', 'scoped-lint', 'strict-main-types', 'strict-test-types',
          'complete-unit-suite', 'options-unit-suite', 'all-dry-build-targets', 'build-counter-only-module',
          'synthetic-raw-native-oracle', 'smoke-baseline', 'smoke-candidate', 'smoke-diagnostic',
          'smoke-disabled-baseline', 'smoke-disabled-candidate', 'smoke-disabled-diagnostic']
expected = {
    'schema': 1, 'finalized': True, 'recordedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Prospective independent post-acquisition replay; no source/gate change or new measurements',
    'publication': {'runId': 46135694884, 'runAttempt': 1,
                    'commit': 'c9583864b4185470f1e043fd49799a08369b258a',
                    'tree': '69257c47755062c6759b68332454e4427bf7902d',
                    'branch': 'perf/numeric-suffix-proof-consumer-screen-20261128-c563d487',
                    'workflowPath': '.github/workflows/import-suffix-proof-component-c563d487.yml'},
    'bindingSha256': sha(host / 'binding.json'), 'binding': binding, 'criteria': criteria,
    'baselineSourceBindingSha256': sha(root / 'baseline-source-binding.json'),
    'baselineScreenSourceHashes': {name: item['sha256'] for name, item in source['screenSources'].items()},
    'baselineManifest': source['baselineManifest'], 'baselineNativeSourceHashes': source['nativeSourceSha256'],
    'nativePaths': ['ext/js/dictionary/wasm/term-bank-parser.c', 'dev/data/dictionary-wasm/term-bank-parser.wasm', 'dev/data/dictionary-wasm/manifest.json'],
    'fixtures': fixtures, 'diagnosticFields': read(host / 'diagnostic-fields.json'),
    'diagnosticSourceSha256': sha(host / 'source-only-diagnostic-1/diagnostic-source.c'),
    'strictExports': ['parse_term_bank', 'parse_term_bank_with_media_hints'], 'syntheticOracleCases': 1112,
    'buildCommandLabels': labels, 'proofFixtureExpectations': proofs,
    'smokeValidNames': old_names + [item['name'] for item in proofs], 'smokeMalformedNames': malformed_names,
    'rawOracleScope': 'Producer compares all17 metadata words through both strict exports; archived attempt receipts retain hashes/lengths/results, not every raw word array. Independent replay checks every receipt and source binding without rerunning native code.',
    'arithmeticPolicy': 'Original JS scalars preserved. Recompute exact quotient-first paired changes and medians; equal-work uses reported CPython3.11 sequential or3.12/13 compensated-float/direct-int or3.14 compensated-float/int sums. No tolerance, control subtraction or pooling.',
    'runtimeArtifactPolicy': 'Actual candidate WASM/manifest/artifact IDs bind only through the independently audited original successful build. No speculative hashes.',
}
path = root / 'expected.json'
assert not path.exists()
path.write_text(json.dumps(expected, indent=2) + '\n')
print(json.dumps({'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size,
                  'fusedGroups': {name: item['fusedGroups'] for name, item in fixtures.items()}}))
