import {readFile, writeFile} from 'node:fs/promises'
import {createHash} from 'node:crypto'
import {performance} from 'node:perf_hooks'
import {ZipReader, Uint8ArrayReader, Uint8ArrayWriter} from './manabitan/node_modules/@zip.js/zip.js/index.js'

const [dictionary, candidateRoot, output, roundsString = '8'] = process.argv.slice(2)
const baselineRoot = '/workspace/scratch/ef009a302ea8/manabitan'
const filesPerGroup = {jmdict: 7, jitendex: 10, vndb: 32}[dictionary]
const rounds = Number(roundsString)
if (!filesPerGroup || !candidateRoot || !output || !Number.isSafeInteger(rounds) || rounds < 2) { throw new Error('Invalid args') }
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const lockBytes = await readFile(`${baselineRoot}/test/perf/dictionaries.lock.json`)
const lock = JSON.parse(lockBytes).dictionaries[dictionary]
const zip = await readFile(`${baselineRoot}/builds/e2e-dictionary-cache/${lock.cacheFile}`)
if (sha(zip) !== lock.sha256 || zip.length !== lock.sizeBytes) { throw new Error('Archive differs from lock') }
const reader = new ZipReader(new Uint8ArrayReader(new Uint8Array(zip)))
const banks = []
try {
    const entries = (await reader.getEntries()).filter((x) => /^term_bank_\d+\.json$/.test(x.filename))
        .sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
    for (const entry of entries) { banks.push(await entry.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true})) }
} finally { await reader.close() }
const arms = {}
for (const [arm, root] of [['A', baselineRoot], ['B', candidateRoot]]) {
    const bytes = await readFile(`${root}/ext/lib/term-bank-parser.wasm`)
    arms[arm] = {root, hash: sha(bytes), wasm: (await WebAssembly.instantiate(bytes)).instance.exports}
}
const power2 = (n) => {
    let result = 1
    while (result < n) { result *= 2 }
    return result
}
function prepare(wasm, sources) {
    wasm.wasm_reset_heap()
    const jsonLength = sources.reduce((sum, bytes) => sum + bytes.length, 0)
    const capacity = Math.max(8192, sources.length * 10000)
    const contentTableSize = power2(capacity * 2)
    const stringTableSize = power2(capacity * 4)
    const stringsCapacity = Math.max(1024 * 1024, Math.min(jsonLength, capacity * 64))
    const contentCapacity = Math.max(1024 * 1024, capacity * 192)
    const alloc = (n) => {
        const p = wasm.wasm_alloc(n)
        if (!p) { throw new Error(`Allocation failed for ${n}`) }
        return p
    }
    const pointers = {
        json: alloc(jsonLength), spans: alloc(sources.length * 8),
        meta: alloc(capacity * 68), contentMeta: alloc(capacity * 16),
        contentTable: alloc(contentTableSize * 4), uniqueIndexes: alloc(capacity * 4),
        uniqueCount: alloc(4), uniqueSignatures: alloc(capacity * 12), rowCount: alloc(4),
        strings: alloc(stringsCapacity), lengths: alloc(capacity * 4), offsets: alloc(capacity * 8),
        hashes: alloc(capacity * 8), expressions: alloc(capacity * 4), readings: alloc(capacity * 4),
        stringTable: alloc(stringTableSize * 4), stringCount: alloc(4), stringBytes: alloc(4),
        equals: alloc(capacity), scores: alloc(capacity * 4), sequences: alloc(capacity * 4),
        recentHits: alloc(4), stats: alloc(20), content: alloc(contentCapacity),
    }
    const heap = new Uint8Array(wasm.memory.buffer)
    const spans = new Uint32Array(wasm.memory.buffer, pointers.spans, sources.length * 2)
    let cursor = 0
    for (const [i, source] of sources.entries()) {
        spans[i * 2] = cursor
        spans[i * 2 + 1] = source.length
        heap.set(source, pointers.json + cursor)
        cursor += source.length
    }
    new Uint32Array(wasm.memory.buffer, pointers.contentTable, contentTableSize).fill(0)
    new Uint32Array(wasm.memory.buffer, pointers.stringTable, stringTableSize).fill(0)
    for (const name of ['uniqueCount', 'rowCount', 'stringCount', 'stringBytes', 'recentHits']) {
        new Uint32Array(wasm.memory.buffer, pointers[name], 1)[0] = 0
    }
    const p = pointers
    return {pointers, args: [
        p.json, jsonLength, p.meta, capacity, p.content, contentCapacity, p.contentMeta,
        p.contentTable, contentTableSize, p.uniqueIndexes, p.uniqueCount, p.uniqueSignatures,
        p.rowCount, p.strings, stringsCapacity, p.lengths, p.offsets, p.hashes,
        p.expressions, p.readings, p.stringTable, stringTableSize, p.stringCount, p.stringBytes,
        p.equals, p.scores, p.sequences, p.recentHits, 1,
        5, p.spans, sources.length, p.stats, 0, 0, 0, 1, 0,
    ]}
}
function execute(arm, verify) {
    const {wasm} = arms[arm]
    let wallMs = 0
    let cpuMs = 0
    let rows = 0
    let maxHeapBytes = 0
    const digest = createHash('sha256')
    for (let start = 0; start < banks.length; start += filesPerGroup) {
        const {pointers: p, args} = prepare(wasm, banks.slice(start, start + filesPerGroup))
        const cpuStart = process.cpuUsage()
        const startTime = performance.now()
        const contentBytes = wasm.parse_and_encode_term_bank_token_binary_dedup(...args)
        wallMs += performance.now() - startTime
        const cpu = process.cpuUsage(cpuStart)
        cpuMs += (cpu.user + cpu.system) / 1000
        if (contentBytes < 0) { throw new Error(`Native fused parser declined group ${start}: ${contentBytes}`) }
        const memory = wasm.memory.buffer
        const get32 = (pointer) => new Uint32Array(memory, pointer, 1)[0]
        const count = get32(p.rowCount)
        const stringCount = get32(p.stringCount)
        rows += count
        maxHeapBytes = Math.max(maxHeapBytes, memory.byteLength)
        if (verify) {
            for (const [pointer, length] of [
                [p.meta, count * 68], [p.contentMeta, count * 16], [p.uniqueIndexes, count * 4],
                [p.uniqueSignatures, get32(p.uniqueCount) * 12], [p.content, contentBytes],
                [p.strings, get32(p.stringBytes)], [p.lengths, stringCount * 2],
                [p.offsets, stringCount * 4], [p.hashes, stringCount * 4],
                [p.expressions, count * 4], [p.readings, count * 4], [p.equals, count],
                [p.scores, count * 4], [p.sequences, count * 4], [p.stats, 20],
            ]) { digest.update(new Uint8Array(memory, pointer, length)) }
        }
    }
    if (rows !== lock.termRows) { throw new Error(`Row count ${rows} != ${lock.termRows}`) }
    return {wallMs, cpuMs, rows, maxHeapBytes, digest: verify ? digest.digest('hex') : null}
}
console.log(JSON.stringify({phase: 'warmup', dictionary, banks: banks.length}))
for (let i = 0; i < 3; ++i) {
    execute('A', false)
    execute('B', false)
}
globalThis.gc?.()
const observations = []
for (let round = 0; round < rounds; ++round) {
    for (const arm of (round % 2 === 0 ? 'AB' : 'BA')) {
        const result = execute(arm, true)
        observations.push({round, arm, ...result})
        console.log(JSON.stringify({round, arm, wallMs: result.wallMs, cpuMs: result.cpuMs}))
    }
}
const median = (values) => {
    values.sort((a, b) => a - b)
    return (values[Math.floor((values.length - 1) / 2)] + values[Math.floor(values.length / 2)]) / 2
}
const pairs = []
for (let round = 0; round < rounds; ++round) {
    const a = observations.find((r) => r.round === round && r.arm === 'A')
    const b = observations.find((r) => r.round === round && r.arm === 'B')
    if (a.digest !== b.digest) { throw new Error('Native output mismatch') }
    pairs.push({wallChangePercent: 100 * (b.wallMs / a.wallMs - 1), cpuChangePercent: 100 * (b.cpuMs / a.cpuMs - 1)})
}
const report = {dictionary, node: process.version, rounds, filesPerGroup,
    boundary: 'Native fused parse+encode only; resident verified decoded banks; excludes allocation, input copying, inflation, lookup construction, IPC, compression, persistence, UI.',
    baseline: {root: arms.A.root, wasmSha256: arms.A.hash}, candidate: {root: arms.B.root, wasmSha256: arms.B.hash},
    archiveSha256: lock.sha256, lockSha256: sha(lockBytes), observations, pairs,
    summary: {medianWallChangePercent: median(pairs.map((p) => p.wallChangePercent)), medianCpuChangePercent: median(pairs.map((p) => p.cpuChangePercent))}}
await writeFile(output, JSON.stringify(report, null, 2) + '\n')
console.log(JSON.stringify(report.summary))
