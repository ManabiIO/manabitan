#!/usr/bin/env python3
"""Independent, read-only validation of the six frozen record-validation browser cells."""

import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import random
import subprocess
import zipfile
from statistics import median


ROOT = Path(__file__).resolve().parent.parent
CELLS = ROOT / "r2-evidence/record-browser-45124794707"
PUBLISHED = ROOT / "qualification/r2-published-runtime-blobs-with-record.json"
BASELINE = "5e1f8c12f7ff798ba407323aff675cb23b22af02"
RESEARCH = "c0c2fdc79c9b4364e1a7fdfc915e5fd13ef332bc"
CANDIDATES = {
    "record-validation": {"sha": "cf1e18d59d08da729d4b2fe45c7a07021f42360a", "phase": "termRecordValidationMs", "pr": 822},
}
CORPORA = {"jmdict": (526942, 53, 12), "jitendex": (435448, 218, 22), "vndb": (6648310, 665, 170)}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def expected_schedule(reverse):
    observations = []
    for number in (1, 2):
        order = "CBA" if reverse else "ABC"
        observations.extend({"kind": "warmup", "warmup": True, "block": number,
                             "order": order, "arm": arm, "name": f"warmup-{number:02d}-{arm}"}
                            for arm in order)
    for number in range(1, 13):
        order = "BA" if (number % 2 == 0) != reverse else "AB"
        observations.extend({"kind": "candidate", "warmup": False, "block": number,
                             "order": order, "arm": arm, "name": f"candidate-{number:02d}-{arm}"}
                            for arm in order)
        if number % 2 == 0:
            control = number // 2
            order = "CA" if (control % 2 == 0) != reverse else "AC"
            observations.extend({"kind": "control", "warmup": False, "block": control,
                                 "order": order, "arm": arm, "name": f"control-{control:02d}-{arm}"}
                                for arm in order)
    return observations


def paired(rows, kind, metric, bootstrap=False):
    other = "B" if kind == "candidate" else "C"
    count = 12 if kind == "candidate" else 6
    values = []
    for number in range(1, count + 1):
        pair = {row["arm"]: row[metric] for row in rows if row["kind"] == kind and row["block"] == number}
        check(set(pair) == {"A", other}, "Malformed pair")
        check(all(type(value) in (float, int) and math.isfinite(value) and value > 0 for value in pair.values()), "Invalid metric")
        values.append((pair["A"], pair[other]))
    changes = [100 * (candidate / baseline - 1) for baseline, candidate in values]
    result = {
        "pairs": count,
        "baselineMs": [value[0] for value in values], "comparisonMs": [value[1] for value in values],
        "pairedPercentChanges": changes, "medianPairedPercent": median(changes),
        "equalWorkPercent": 100 * (sum(value[1] for value in values) / sum(value[0] for value in values) - 1),
        "fasterPairs": sum(value < 0 for value in changes), "worstPairPercent": max(changes),
        "minPairPercent": min(changes),
    }
    if bootstrap:
        rng = random.Random(20261123)
        distribution = sorted(median(rng.choices(changes, k=count)) for _ in range(5000))
        result["descriptiveBootstrap95"] = [distribution[124], distribution[4874]]
    return result


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--allow-incomplete", action="store_true", help="Audit only already-complete cells; write a separately named partial report")
args = parser.parse_args()
published = read(PUBLISHED)["runtimes"]
artifact_records = {}
for api in sorted(CELLS.glob("api-artifacts*.json")):
    for record in read(api)["artifacts"]:
        previous = artifact_records.get(record["name"])
        check(previous is None or previous == record, "Provider artifact metadata changed")
        artifact_records[record["name"]] = record
study_repo = ROOT / "manabitan-r2-study"
def git_blob(path):
    return subprocess.check_output(["git", "-C", str(study_repo), "show", RESEARCH + ":" + path])
research_tree = subprocess.check_output(["git", "-C", str(study_repo), "rev-parse", RESEARCH + "^{tree}"], text=True).strip()
committed_research = {name: git_blob(name) for name in (
    "dev/perf/import-r2-qualification-20261123.py",
    "dev/perf/import-r2-qualification-20261123.json",
    "test/import-r2-qualification-20261123.test.py",
)}

def archive_receipt(folder):
    archive = folder.with_suffix(".zip")
    record = artifact_records[folder.name]
    actual_sha = sha(archive)
    check(record["digest"] == "sha256:" + actual_sha, "Provider archive SHA mismatch")
    check(record["size_in_bytes"] == archive.stat().st_size, "Provider archive size mismatch")
    check(record["workflow_run"]["id"] == 45124794707 and record["workflow_run"]["head_sha"] == RESEARCH, "Wrong provider source/run")
    with zipfile.ZipFile(archive) as z:
        names = [name for name in z.namelist() if not name.endswith("/")]
        check(len(names) == len(set(names)), "Repeated archive member")
        check(set(names) == {str(path.relative_to(folder)) for path in folder.rglob("*") if path.is_file()}, "Expanded archive roster differs")
        for name in names:
            check(z.read(name) == (folder / name).read_bytes(), "Expanded archive bytes differ: " + name)
    return {"artifactId": record["id"], "archiveSha256": actual_sha, "archiveBytes": archive.stat().st_size, "verifiedFiles": len(names)}

expected_names = {f"import-r2-qualification-{candidate}-{dictionary}-{direction}"
                  for candidate in CANDIDATES for dictionary in CORPORA for direction in ("forward", "reverse")}
actual = {path.name for path in CELLS.iterdir() if path.is_dir()}
check(actual <= expected_names if args.allow_incomplete else actual == expected_names, "The downloaded directory roster differs from the declared six cells")
all_results = []
common_fixture_receipts = {}
common_runtime = None
for candidate, specification in CANDIDATES.items():
    for dictionary, (row_count, banks, groups) in CORPORA.items():
        for direction in ("forward", "reverse"):
            case = f"{candidate}-{dictionary}"
            folder = CELLS / f"import-r2-qualification-{case}-{direction}"
            if args.allow_incomplete and folder.name not in actual:
                continue
            provider = archive_receipt(folder)
            preparation = read(folder / "preparation.json")
            config = read(folder / "config.json")
            complete = read(folder / "cohort-complete.json")
            retained_analysis = read(folder / "analysis.json")
            observations = read(folder / "observations.json")
            schedule = expected_schedule(direction == "reverse")
            for document in (preparation, complete, retained_analysis):
                check((document["case"], document["dictionary"], document["direction"]) == (case, dictionary, direction), "Mislabeled cell")
            check(not any((folder / name).exists() for name in ("prepare-failure.json", "run-failure.json", "analyze-failure.json")), "Failed cell retained")
            check(retained_analysis["complete"] is True, "Analysis is incomplete")
            check(read(folder / "schedule.json") == schedule and len(observations) == 42, "Unexpected schedule or import count")
            check([{key: observation[key] for key in item} for observation, item in zip(observations, schedule, strict=True)] == schedule, "Observation schedule mismatch")
            check(Counter(row["arm"] for row in observations[6:]) == {"A": 18, "B": 12, "C": 6}, "Wrong measured arm counts")
            for name in ("preparation", "config", "schedule", "observations"):
                check(sha(folder / f"{name}.json") == complete[f"{name}Sha256"], "Completion receipt mismatch")
            check(preparation["researchSha"] == RESEARCH == (folder / "research-sha.txt").read_text().strip(), "Wrong research source")
            check(preparation["researchTree"] == research_tree == (folder / "research-tree.txt").read_text().strip(), "Wrong research tree")
            for name, committed_bytes in committed_research.items():
                check((folder / "research-sources" / name).read_bytes() == committed_bytes, "Frozen research source differs from git: " + name)
            check(preparation["measurementControls"] == {
                "buildTarget": "chrome", "freshProfilePerImport": True, "processSampling": False,
                "productionDefaults": True, "profiling": False, "screenshots": False, "strictRuntime": True,
            }, "Measurement controls changed")
            research = folder / "research-sources/dev/perf"
            check(sha(research / "import-r2-qualification-20261123.py") == preparation["runnerSha256"], "Runner bytes mismatch")
            check(sha(research / "import-r2-qualification-20261123.json") == preparation["configSha256"], "Config bytes mismatch")
            check(read(research / "import-r2-qualification-20261123.json") == config, "Retained config mismatch")
            check(config["baseline"] == BASELINE and config["cases"][case]["sha"] == specification["sha"], "Incorrect frozen runtime SHA")
            check(config["cases"][case]["dictionary"] == dictionary, "Wrong case dictionary")
            identities = preparation["identities"]
            check(identities["A"]["sha"] == BASELINE and identities["B"]["sha"] == specification["sha"], "Wrong built runtime SHA")
            check(identities["A"]["overlaySha256"] == identities["B"]["overlaySha256"], "Asymmetric overlay")
            for key in ("trackedDiffSha256", "packageLockSha256", "originalFixtureLockSha256"):
                check(identities["A"][key] == identities["B"][key], "Asymmetric setup: " + key)
            for name, digest in identities["A"]["overlaySha256"].items():
                check(sha(folder / "overlay" / name) == digest, "Overlay bytes changed")
            maps = {arm: read(folder / f"package-entries-{arm}.json") for arm in "ABC"}
            check(maps["A"] == maps["C"], "Control package differs")
            changes = sorted(name for name in maps["A"].keys() | maps["B"].keys() if maps["A"].get(name) != maps["B"].get(name))
            check(changes == ["js/dictionary/term-record-opfs-store.js"], "Unexpected record-validation package changes")
            check(changes == sorted(config["cases"][case]["packageDifferences"]) == preparation["packageDifferences"] == read(folder / "package-differences.json"), "Package declaration mismatch")
            for arm in ("A", "B"):
                expected_source = published[identities[arm]["sha"]]
                check(identities[arm]["tree"] == expected_source["tree"], "Published runtime tree mismatch")
                for name, file in expected_source["files"].items():
                    check(maps[arm][name] == file["sha256"], "Packaged code differs from published blob: " + name)
            check(maps["A"]["lib/term-bank-parser.wasm"] == maps["B"]["lib/term-bank-parser.wasm"], "Native binary changed")
            fixture = preparation["fixture"]
            lock = read(folder / "overlay/test/perf/dictionaries.lock.json")
            check(fixture == lock["dictionaries"][dictionary] and fixture["termRows"] == row_count, "Wrong fixture lock/rows")
            check(preparation["fixtures"][dictionary] == {key: fixture[key] for key in ("sha256", "sizeBytes")}, "Actual fixture checksum/size mismatch")
            runtime = preparation["runtime"]
            check(runtime["node"] == "v22.22.0" and runtime["browserVersion"] == "153.0.8010.12", "Unexpected runtime version")
            if common_runtime is None:
                common_runtime = runtime
            check(runtime == common_runtime, "Browser/Node executable identities differ between cells")
            cell_work = None
            cell_output = None
            cell_flags = None
            reconstructed = []
            check(len({row["name"] for row in observations}) == 42, "Repeated observation")
            check({path.name for path in (folder / "observations").iterdir() if path.is_dir()} == {row["name"] for row in observations}, "Unrecorded or missing observation folder")
            previous_end = None
            host_snapshots = []
            for row in observations:
                check(row["startedUnixTime"] < row["endedUnixTime"], "Invalid process interval")
                check(previous_end is None or row["startedUnixTime"] >= previous_end, "Overlapping observation processes")
                previous_end = row["endedUnixTime"]
                check(row["status"] == "success", "Failed observation")
                raw = folder / "observations" / row["name"]
                summary, report = read(raw / "summary.json"), read(raw / "run-1.json")
                for moment in ("before", "after"):
                    host = read(raw / f"host-{moment}.json")
                    check(host["nodeVersion"] == runtime["node"] and host["platform"] == "linux" and host["arch"] == "x64" and host["logicalCpuCount"] == 4, "Unexpected host/runtime")
                    host_snapshots.append(host)
                check(report["packageSha256"] == row["packageSha256"] and report["buildTarget"] == "chrome", "Raw report package/build mismatch")
                check(len(list(raw.glob("run-*.json"))) == 1, "Extra raw run report")
                arm = "A" if row["arm"] == "C" else row["arm"]
                source = identities[arm]
                check(summary["gitSha"] == source["sha"] and summary["fixture"] == fixture and summary["dictionary"] == dictionary, "Wrong observed source/fixture")
                check(summary["authoritativeTiming"] is True and summary["traceEnabled"] is False and summary["importFlags"] is None and summary["buildTarget"] == "chrome", "Wrong timing controls")
                check(report["status"] == "success" and report["skippedVerification"] is False, "Verification failed/skipped")
                benchmark = report["benchmark"]
                check(benchmark["dictionary"] == dictionary and benchmark["pinnedDictionaries"] is True and benchmark["productionImportDefaults"] is True and benchmark["authoritativeTiming"] is True and benchmark["importFlags"] is None, "Wrong raw benchmark settings")
                check(all(benchmark[key] is False for key in ("traceEnabled", "phaseProfiling", "phaseScreenshots", "processSampling")), "Instrumented measurement")
                check(summary["browserVersion"] == report["browserVersion"] == row["browserVersion"] == runtime["browserVersion"], "Wrong observed browser")
                check(summary["hostEnvironment"]["nodeVersion"] == runtime["node"], "Wrong observed Node")
                hashes = summary["source"]["sha256"]
                check(hashes["builds/manabitan-chrome.zip"] == row["packageSha256"] == source["packageSha256"], "Wrong observed package")
                check(hashes["package-lock.json"] == source["packageLockSha256"], "Wrong observed dependency lock")
                check(all(hashes[name] == value for name, value in source["overlaySha256"].items()), "Wrong observed overlay")
                check(len(summary["runs"]) == 1, "Hidden import attempt")
                run = summary["runs"][0]
                raw_phases = [phase for phase in report["phases"] if isinstance(phase.get("data"), dict) and phase["data"].get("kind") == "dictionary-import"]
                check(len(raw_phases) == 1, "Ambiguous raw import timing")
                data = raw_phases[0]["data"]
                timing, debug = data["browserTiming"], data["importDebug"]
                check(timing["trigger"] == "file-input-change" and type(timing["sequence"]) is int and type(timing["sequenceBefore"]) is int and timing["sequence"] == timing["sequenceBefore"] + 1 and timing["errorCount"] == 0, "Wrong raw import operation")
                start, end = timing["startedAtMs"], timing["completedAtMs"]
                check(all(type(value) in (int, float) and math.isfinite(value) for value in (start, end)) and 0 <= start < end, "Bad browser clock")
                frame = timing.get("nextFrameAtMs")
                check(frame is None or (type(frame) in (int, float) and math.isfinite(frame) and frame >= end), "Bad optional frame")
                duration = end - start
                check(duration == row["totalImportMs"] == run["totalImportMs"] and run["packageSha256"] == source["packageSha256"], "Wrong duration/package")
                check(debug == run["importDebug"] and debug["hasResult"] is True and debug["resultTitle"] == fixture["expectedTitle"] and debug["errorCount"] == debug["addSettingsErrorCount"] == 0 and debug["usesFallbackStorage"] is False, "Raw import error/fallback")
                check(report["runtimeDiagnostics"]["openStorageMode"] == "opfs-sahpool", "Wrong runtime storage")
                check(debug["useImportSession"] is True and debug["finalizeImportSession"] is True and debug["openStorageDiagnostics"]["mode"] == "opfs-sahpool", "Storage/import-session policy changed")
                validation = benchmark["validation"]
                check(run["validation"] == validation, "Summary readback differs from raw report")
                for result in (validation, validation["restart"]):
                    check(result["title"] == fixture["expectedTitle"] and result["revision"] == fixture["revision"] and result["termRows"] == row_count and result["contentReadable"] is True and result["probeCount"] == 12, "Readback/restart contract failure")
                check(len(validation["probeTerms"]) == len(set(validation["probeTerms"])) == 12, "Repeated/missing source probes")
                output = validation["outputDigestSha256"]
                check(output == row["outputDigestSha256"] and len(output) == 64, "Probe digest mismatch")
                phases = debug["importerPhaseTimings"]
                parsing = [phase["details"] for phase in phases if phase["phase"].startswith("term-file-fast-path:")]
                final = [phase["details"] for phase in phases if phase["phase"] == "bulk-finalization"]
                check(parsing and len(final) == 1 and final[0]["published"] is True, "Missing native/publication work")
                # Baseline getParallelSourcePipelineGroupsPerWorker: plain sources
                # use four groups; media-aware sources use three. These fixtures
                # exercise the plain JMdict path and media-aware Jitendex/VNDB.
                pipeline_groups = 4 if dictionary == "jmdict" else 3
                check(all(part["parserParallelWorkerCount"] == 3 and part["parserParallelPipelineGroupsPerWorker"] == pipeline_groups and part["parserFusedFallbacks"] == part["dedupNativeFallbackCount"] == part["parserNativeSegmentedLookupFallbacks"] == 0 for part in parsing), "Worker/native path changed")
                work = {key: sum(part[key] for part in parsing) for key in ("rows", "chunkCount", "parserFusedAttempts", "parserBankSpanCount", "parserSourceCompressedBytes", "parserSourceUncompressedBytes")}
                work.update({key: final[0][key] for key in ("termContentTotalWriteBytes", "termRecordTotalWriteBytes", "termRecordLookupIndexWriteBytes")})
                check(work["rows"] == row_count and work["parserBankSpanCount"] == banks and work["chunkCount"] == work["parserFusedAttempts"] == groups, "Work/partition counts changed")
                check(work == row["workReceipt"] and all(type(value) is int and value > 0 for value in work.values()), "Wrong work receipt")
                flags = [part["parserExperiments"] for part in parsing]
                if cell_work is None:
                    cell_work, cell_output, cell_flags = work, output, flags
                check(work == cell_work and output == cell_output and flags == cell_flags, "Within-cell work/output/flags changed")
                metrics = {key: sum(part[key] for part in parsing) for key in ("parserSourceInflateMs", "parserParseBankMs", "parserLookupIndexPrepareMs", "parserResultCopyMs", "termRecordValidationMs", "termRecordFieldEncodeMs", "importerChunkSinkMs")}
                reconstructed.append({**row, "totalImportMs": duration, **metrics})
            check(complete["completedUnixTime"] >= previous_end, "Completion predates last import")
            candidate_result = paired(reconstructed, "candidate", "totalImportMs", True)
            control_result = paired(reconstructed, "control", "totalImportMs", True)
            for actual_result, retained in ((candidate_result, retained_analysis["candidateVsBaseline"]), (control_result, retained_analysis["sameCodeControl"])):
                check(all(actual_result[key] == value for key, value in retained.items()), "Retained arithmetic differs from independent recomputation")
            corpus_receipt = {"fixture": fixture, "work": cell_work, "outputDigestSha256": cell_output, "flags": cell_flags}
            if dictionary not in common_fixture_receipts:
                common_fixture_receipts[dictionary] = corpus_receipt
            check(common_fixture_receipts[dictionary] == corpus_receipt, "Across-cell corpus/work/output identity differs")
            result = {
                "candidate": candidate, "pr": specification["pr"], "dictionary": dictionary, "direction": direction,
                "root": str(folder), "provider": provider, "imports": 42, "warmups": 6, "measured": 36,
                "candidateSha": specification["sha"], "baselineSha": BASELINE,
                "completionSha256": sha(folder / "cohort-complete.json"), "observationsSha256": sha(folder / "observations.json"),
                "candidateVsBaseline": candidate_result, "sameCodeControl": control_result,
                "hostSnapshotRanges": {
                    "freeMemoryBytes": [min(row["freeMemoryBytes"] for row in host_snapshots), max(row["freeMemoryBytes"] for row in host_snapshots)],
                    "loadAverageOneMinute": [min(row["loadAverage"][0] for row in host_snapshots), max(row["loadAverage"][0] for row in host_snapshots)],
                    "cpuModels": sorted({row["cpuModel"] for row in host_snapshots}),
                },
                "pairOrderGroups": {
                    order: [100 * (pair["B"] / pair["A"] - 1) for number in range(1, 13)
                            if next(row["order"] for row in reconstructed if row["kind"] == "candidate" and row["block"] == number) == order
                            for pair in [{row["arm"]: row["totalImportMs"] for row in reconstructed if row["kind"] == "candidate" and row["block"] == number}]]
                    for order in ("AB", "BA")
                },
                "mechanismMetric": specification["phase"],
                "mechanismCandidateVsBaseline": paired(reconstructed, "candidate", specification["phase"]),
                "mechanismSameCodeControl": paired(reconstructed, "control", specification["phase"]),
            }
            all_results.append(result)
            print(json.dumps({key: result[key] for key in ("candidate", "dictionary", "direction")} | {
                "median": candidate_result["medianPairedPercent"], "equalWork": candidate_result["equalWorkPercent"],
                "controlMedian": control_result["medianPairedPercent"],
                "phaseMedian": result["mechanismCandidateVsBaseline"]["medianPairedPercent"],
                "phaseEqualWork": result["mechanismCandidateVsBaseline"]["equalWorkPercent"],
                "phaseControlMedian": result["mechanismSameCodeControl"]["medianPairedPercent"],
            }))

result = {"schemaVersion": 1, "complete": actual == expected_names, "independentReviewerSha256": sha(Path(__file__)),
          "publishedManifestSha256": sha(PUBLISHED), "source": str(CELLS), "workflowRun": 45124794707, "researchSha": RESEARCH, "researchTree": research_tree,
          "verifiedCells": len(all_results), "verifiedImports": sum(row["imports"] for row in all_results),
          "runtime": common_runtime, "corpora": common_fixture_receipts, "cells": all_results,
          "limits": ["Each cell is an independent host; no pooled host estimates or control subtraction.",
                     "Stored probe digests cover 12 source-derived probes, not exhaustive persisted-content readback.",
                     "Existing importer phase counters overlap; the validation phase is not an isolated timer or additive critical-path decomposition.",
                     "No record fast-path activation-hit counter is present; production eligibility follows source inspection and typed owned-reference flow, not a direct observed hit receipt.",
                     "No whole-browser peak memory or reopened lookup latency comparison was run for this candidate."]}
result["recommendation"] = "HOLD" if result["complete"] else "PENDING_COMPLETE_ROSTER"
result["reason"] = "Evaluate every independent direction against same-code variation and the material complete-import gate; no pooled host estimate or phase-only promotion."
output = ROOT / ("qualification/r2-record-browser-review.partial.json" if args.allow_incomplete else "qualification/r2-record-browser-review.json")
check(not output.exists(), "Use a new output; independent review already recorded")
output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"verifiedCells": result["verifiedCells"], "verifiedImports": result["verifiedImports"], "output": str(output)}))
