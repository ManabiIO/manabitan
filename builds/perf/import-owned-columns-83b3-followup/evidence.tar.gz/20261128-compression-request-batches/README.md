# Shared-span compression request batching: HOLD

This isolated prototype did not establish a useful compression latency gain. It
must not be promoted on its lower request count. The fixed component cohort is
complete; no optional timing followup was run to search for a favorable subset.

The implementation starts from develop
`9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. It batches only shared-span request
envelopes by the existing round-robin compression worker. Every native block,
worker assignment, worker-local block order, job ID, 60-second timer, individual
source-consumed reply, individual result/error reply, and all-reader failure
barrier is retained. Packed/private block dispatch is unchanged. An atomic
batch-post failure retries the exact original requests under their existing IDs
and deadlines; individual post failures retain the original drain behavior.

## Current-source workload

The diagnostic capture uses the actual current native parser worker and
canonical content sink. It processes all 528,299 locked JMdict rows, using the
current 3-parser-worker grouping policy executed sequentially. The sink uses the
repository's Node filesystem adapter; compression during capture uses an explicit
local codec transport. Capture and filesystem timings are not performance data.

The original capture adapter omitted the real parser parent's owned-content
registration. A later corrected canonical-sink diagnostic reproduced that
receipt and verified every source window, descriptor and compressed block
against this capture. Therefore the fixed compression input oracle remains
valid, but the original capture's recent-source cache-copy counters and sink
timings must not be interpreted as production attribution. The corrected path
adopts the existing owned bytes without that extra copy. The original capture
script and raw receipt are preserved unchanged.

- 12 source groups and 12 shared-span compression operations.
- 366,030 group-unique contents scanned natively, with zero native scan fallback.
- 3,998 exact cross-group hits; 362,032 pending spans reach compression.
- 100,300,626 bytes in 103 unchanged compressed blocks.
- 101,143,289 bytes of staged source windows. Windows retain the original span
  offsets modulo eight; only unreferenced outer bytes are omitted.
- Every block has a frozen native compressed-byte oracle and each captured source
  and descriptor buffer has a SHA-256 identity.

The actual baseline dispatches 103 requests; the candidate dispatches 48. Both
produce 103 source-consumed acknowledgements and 103 result replies. Therefore
the candidate removes 55 request envelopes, or 53.4% of requests and 17.8% of
these compression request/reply messages. This is a work-count result, not a
measured import speedup. The earlier historical 102-block figure was not used as
the current workload.

## Registered component protocol

`replay.mjs` writes its protocol before measurement. It uses Node 22.22.0 and the
actual source `TermContentCompressionPool` plus actual compression worker entry
point for each arm. Each arm gets a fresh four-worker pool and one full-corpus
warmup, then one full-corpus measurement. Worker initialization and warmup are
outside the measured interval.

There are 12 rounds: all six permutations of A/B/C, repeated twice. A is baseline,
B is candidate, and C is the identical baseline source with a fresh pool. All
groups remain sequential. Dispatch-call durations, source-consumed latency and
all-completion latency are retained per group and summed over the complete
corpus. The total corpus wall interval is also retained. Every block is hashed
after all timers stop. All warmups, measurements, orderings and outliers remain
in `cohort-1/results.json`; no observations were removed.

The replay freezes both runtime files and all measured-path codec, block-envelope
and experiment modules. Shared library hashes are also checked against the
capture. Source bytes are checked again after the full cohort. This is warmed
Node component evidence; it does not reproduce browser worker scheduling, parser
overlap, OPFS, SQLite, backend adoption or visible import completion.

## Results

All 36 measurements and all 36 warmups passed every native block hash, source
acknowledgement count, completion count and expected dispatch count. Sources and
code identities remained unchanged.

| Whole-corpus measurement           | A baseline | B candidate | C identical baseline |
| ---------------------------------- | ---------: | ----------: | -------------------: |
| Mean wall time                     |  81.172 ms |   85.808 ms |            80.312 ms |
| Median wall time                   |  83.589 ms |   85.410 ms |            83.376 ms |
| Median synchronous dispatch total  |   3.187 ms |    3.135 ms |             3.144 ms |
| Mean source-consumed latency total |  57.854 ms |   62.838 ms |            59.465 ms |
| Mean all-completion latency total  |  81.084 ms |   85.744 ms |            80.243 ms |

Paired by round, candidate wall time minus the mean of its two controls has a
median of **+3.154 ms (+4.24%)**. Candidate is slower than that control mean in
9 of 12 rounds and beats both controls in only 1 of 12 rounds. The identical-code
C-minus-A wall difference ranges from -18.222 to +20.399 ms. This variation
precludes a strong claim about the precise regression size, and there is no
positive latency result to qualify.

The paired B-minus-A dispatch median is -0.015 ms; the identical-code
C-minus-A dispatch median is +0.171 ms. The request reduction did not produce a
useful repeatable dispatch saving. Front-loading block registration and changing
worker task/microtask scheduling are possible tradeoffs, but this experiment
does not isolate their contribution.

Raw results SHA-256:
`c535ffd673ae593d885942611344886fa345704c4ddd51a3d77619a901b28291`.
`cohort-1/analysis.json` contains descriptive statistics computed from the full
corpus totals, including every round and both controls. Subgroup medians are not
pooled into a claimed import effect.

## Correctness and validation

The targeted tests cover original worker assignment/order and metadata snapshots,
source release before delayed results, malformed sibling replies, per-block
timeouts, concurrent batches, and partial failure when a batch post is retried
as individual requests. Actual Node workers verify unchanged packed/shared
native frames, envelopes, output ownership after later reuse, and processing of
valid siblings after a malformed middle block.

All 62 focused cases passed across two runs. The first five-file run reported
61 passes and one unexpected Vitest worker exit while the real native worker
case was unresolved. The isolated real-worker case then passed in 12.862 seconds.
The earlier process-exit failure is preserved in `validation.json`; it
is not silently counted as a clean full-suite pass. Scoped strict TypeScript,
ESLint and whitespace checks passed. The existing pako CommonJS warning appeared
during lint. Full unit/build suites and browser qualification were not run for
this held prototype.

Independent read-only reviews found no blocking protocol, failure-drain or
measurement-boundary defect. The ownership optimization worktree and its hosted
qualification were kept separate and unchanged. The runtime candidate was not
promoted. This evidence preserves the complete held result for review.

## Raw staging reclamation

After the fixed negative cohort, corrected sink diagnostic and checksum-input
capture completed, 104,040,417 bytes of this experiment's raw source/descriptor
staging were reclaimed under the parent task's disk-pressure instruction.
`staging-reclaimed.json` lists every removed file and size. The original
capture manifest, per-file/native oracles, protocol, all observations, source
hashes and reproduction scripts remain. Regenerate staging with the unchanged
`capture.mjs` and locked fixture before replaying or using its descriptor oracle.
No captured timing observations or product source were deleted.

## Publication layout

The full two-runtime/three-test diff against the pinned base is
[`prototype-and-tests.patch`](prototype-and-tests.patch). The original frozen
`prototype-initial.patch`, `prototype-tested.patch` and `prototype-complete.patch`
are retained unchanged. `prototype-complete.patch` also includes the
capture/replay scripts; the new five-file patch isolates implementation and tests.

Local and proposed publication paths use the sibling-folder layout documented
in the [bundle map](../20261128-held-import-evidence/README.md). The original
absolute execution paths in raw JSON are provenance, not public link targets.
