// Diagnostic capture only: current parser worker + canonical storage sink.
// The local codec transport and Node filesystem adapter are not timing evidence.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {openAsBlob, writeFileSync} from 'node:fs';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {BlobReader, TextWriter, ZipReader} from '@zip.js/zip.js';

const sourceRoot = path.resolve(process.argv[2]);
const output = path.resolve(process.argv[3]);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const sourceModule = (name) => import(pathToFileURL(path.join(sourceRoot, name)).href);
const sourceFiles = [
    'ext/js/dictionary/term-bank-wasm-parser.js',
    'ext/js/dictionary/term-bank-wasm-parser-worker.js',
    'ext/js/dictionary/dictionary-database.js',
    'ext/js/dictionary/term-content-canonical-scan.js',
    'ext/js/dictionary/term-content-block-store.js',
    'ext/js/dictionary/zstd-term-content.js',
    'ext/lib/term-bank-parser.wasm',
    'ext/lib/term-content-canonical-scan-v1.wasm',
    'ext/lib/zstd-wasm.js',
    'ext/lib/zstd.wasm',
    'ext/lib/zstd-dicts/jmdict.zdict',
];
const identity = async () => Object.fromEntries(await Promise.all(sourceFiles.map(async (file) => [file, sha(await readFile(path.join(sourceRoot, file)))])));
const initialIdentity = await identity();
await mkdir(output, {recursive: true});
const lockBytes = await readFile(path.join(sourceRoot, 'test/perf/dictionaries.lock.json'));
const fixture = JSON.parse(lockBytes).dictionaries.jmdict;
const archivePath = path.join(sourceRoot, 'builds/e2e-dictionary-cache', fixture.cacheFile);
const archiveBytes = await readFile(archivePath);
assert.equal(archiveBytes.byteLength, fixture.sizeBytes);
assert.equal(sha(archiveBytes), fixture.sha256);
globalThis.fetch = async (input) => {
    const url = new URL(String(input));
    assert.equal(url.protocol, 'file:');
    return new Response(await readFile(url), {headers: {'Content-Type': 'application/wasm'}});
};
const api = await sourceModule('ext/js/dictionary/zstd-term-content.js');
let compressionRequests = 0;
let compressionReplies = 0;
const codecWorkers = [];
class LocalCodecWorker extends EventTarget {
    constructor(entry) {
        super();
        assert(String(entry).endsWith('/zstd-term-content-compression-worker.js'));
        codecWorkers.push(this);
        queueMicrotask(() => this.dispatchEvent(new MessageEvent('message', {data: {type: 'ready'}})));
    }
    postMessage(raw, transfer = []) {
        const data = structuredClone(raw, {transfer});
        ++compressionRequests;
        assert.equal(typeof data.id, 'number');
        assert(data.source instanceof Uint8Array);
        const prepared = api.prepareWrappedTermContentZstdSpans(data.source, data.sourceOffsets, data.sourceLengths, data.contentBytes, data.dictName, data.compressionExperiments);
        const result = api.finishWrappedTermContentZstdSpans(prepared);
        queueMicrotask(() => {
            ++compressionReplies;
            this.dispatchEvent(new MessageEvent('message', {data: {type: 'source-consumed', id: data.id}}));
            this.dispatchEvent(new MessageEvent('message', {data: {id: data.id, compressed: Uint8Array.from(result.bytes).buffer, envelopeMs: result.envelopeMs}}));
        });
    }
    terminate() {}
}
globalThis.Worker = LocalCodecWorker;
const {createNodeOpfs} = await sourceModule('test/fixtures/opfs-continuation/node-opfs-adapter.mjs');
const env = await createNodeOpfs();
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: 8, deviceMemory: 8, storage: {getDirectory: async () => env.root}}});
const captures = [];
let currentGroup = -1;
const originalBegin = api.TermContentCompressionPool.prototype.beginCompressWrappedSpans;
api.TermContentCompressionPool.prototype.beginCompressWrappedSpans = function (source, offsets, lengths, starts, blocks, dictName, options) {
    assert.equal(dictName, 'jmdict');
    let lower = source.byteLength;
    let upper = 0;
    for (let index = 0; index < offsets.length; ++index) {
        lower = Math.min(lower, offsets[index]);
        upper = Math.max(upper, offsets[index] + lengths[index]);
    }
    lower -= lower % 8;
    assert(upper > lower);
    const index = captures.length;
    const sourceName = `source-${index}.bin`;
    const sourceView = source.subarray(lower, upper);
    writeFileSync(path.join(output, sourceName), sourceView);
    const columns = [Uint32Array.from(offsets, (offset) => offset - lower), lengths.slice(), starts.slice(), blocks.slice()];
    const descriptorName = `descriptors-${index}.bin`;
    const descriptors = Buffer.concat(columns.map((column) => Buffer.from(column.buffer, column.byteOffset, column.byteLength)));
    writeFileSync(path.join(output, descriptorName), descriptors);
    const capture = {index, group: currentGroup, sourceName, sourceBytes: sourceView.byteLength, sourceSha256: sha(sourceView), descriptorName, descriptorSha256: sha(descriptors), columnLengths: columns.map((column) => column.length), dictName, options, originalSourceBytes: source.byteLength, originalLower: lower, spanCount: offsets.length, blockLengths: [...blocks], expectedBlockHashes: null};
    captures.push(capture);
    const operation = originalBegin.call(this, source, offsets, lengths, starts, blocks, dictName, options);
    void operation.completion.then((result) => { capture.expectedBlockHashes = result.chunks.map(sha); });
    return operation;
};
let parserListener;
let parserReply;
globalThis.self = {
    addEventListener(type, listener) { assert.equal(type, 'message'); parserListener = listener; },
    postMessage(message, transfer = []) { const reply = parserReply; parserReply = null; reply(structuredClone(message, {transfer})); },
};
await sourceModule('ext/js/dictionary/term-bank-wasm-parser-worker.js');
async function parseRequest(message) {
    assert.equal(typeof parserReply === 'function', false);
    const reply = new Promise((resolve) => { parserReply = resolve; });
    parserListener({data: message});
    const result = await reply;
    assert(!result.error, JSON.stringify(result.error));
    return result;
}
const {DictionaryDatabase} = await sourceModule('ext/js/dictionary/dictionary-database.js');
const {compileCanonicalScanModule} = await sourceModule('ext/js/dictionary/term-content-canonical-scan.js');
const {RawZipPayloadReader} = await sourceModule('ext/js/dictionary/term-bank-source-pipeline.js');
const archive = await openAsBlob(archivePath);
const zip = new ZipReader(new BlobReader(archive), {useWebWorkers: false});
let database;
try {
    const entries = await zip.getEntries();
    const index = JSON.parse(await entries.find((entry) => entry.filename === 'index.json').getData(new TextWriter(), {useWebWorkers: false}));
    assert.equal(index.title, fixture.expectedTitle);
    assert.equal(index.revision, fixture.revision);
    const banks = entries.filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)));
    const totalBytes = banks.reduce((total, bank) => total + bank.uncompressedSize, 0);
    const groupCount = Math.min(banks.length, Math.max(3 * 4, Math.ceil(totalBytes / (24 * 1024 * 1024))));
    const groups = [];
    let start = 0;
    let consumed = 0;
    for (let groupIndex = 0; groupIndex < groupCount - 1; ++groupIndex) {
        const remaining = groupCount - groupIndex;
        const target = (totalBytes - consumed) / remaining;
        let end = start + 1;
        let bytes = banks[start].uncompressedSize;
        const maxEnd = banks.length - remaining + 1;
        while (end < maxEnd) {
            const next = bytes + banks[end].uncompressedSize;
            if (Math.abs(next - target) > Math.abs(bytes - target)) { break; }
            bytes = next;
            ++end;
        }
        groups.push(banks.slice(start, end));
        start = end;
        consumed += bytes;
    }
    groups.push(banks.slice(start));
    await parseRequest({type: 'initialize', module: await WebAssembly.compile(await readFile(path.join(sourceRoot, 'ext/lib/term-bank-parser.wasm')))});
    await api.initializeTermContentZstd();
    await compileCanonicalScanModule();
    database = new DictionaryDatabase();
    database.setImportOptimizationFlags({termContentStorageMode: 'raw-bytes', queueTermContentWrites: true, rawTermBankSourceBytes: totalBytes});
    database._bulkImportTransactionOpen = true;
    database._deferTermsVirtualTableSync = true;
    database._termContentZstdInitialized = true;
    await database._termContentStore.prepare();
    await database._termRecordStore.prepare();
    await database._termContentStore.beginImportSession();
    await database._termRecordStore.beginImportSession();
    database._termContentBlockImportSession = database._termContentBlockStore.beginImportSession();
    const payloads = new RawZipPayloadReader(archive);
    const options = {copyContentBytes: false, includeContentMetadata: true, initialContentBytesPerRow: 48, minimalDecode: true, reuseExpressionForReadingDecode: true, preallocateChunkRows: true, skipTagRuleDecode: false, lazyGlossaryDecode: true, mediaHintFastScan: false, projectImagePaths: false, validateGlossaryTypes: true, computeContentHashes: true, emitContentSlab: true, emitTokenBinaryContent: true, emitTermByteLists: false, prepareLookupIndexes: true, prepareLookupRoute: totalBytes >= 128 * 1024 * 1024, ownContentBytes: false};
    const groupResults = [];
    let rows = 0;
    let estimatedRows = 0;
    for (currentGroup = 0; currentGroup < groups.length; ++currentGroup) {
        const group = groups[currentGroup];
        const sourceBuffers = [];
        for (const bank of group) {
            const bytes = await payloads.read(bank, new AbortController().signal);
            sourceBuffers.push(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
        }
        const {chunk} = await parseRequest({type: 'parse', id: currentGroup, version: 3, sourceBuffers, sourceMetadata: group.map(({filename, compressedSize, uncompressedSize, compressionMethod, signature}) => ({filename, compressedSize, uncompressedSize, compressionMethod, signature})), chunkSize: 8192, options});
        assert(chunk);
        const groupBytes = group.reduce((sum, bank) => sum + bank.uncompressedSize, 0);
        if (currentGroup === 0) { estimatedRows = Math.max(chunk.rowCount, Math.round(chunk.rowCount * totalBytes / groupBytes)); }
        rows += chunk.rowCount;
        await database._bulkAddArtifactTermsChunkWithContentDedup({...chunk, dictionary: index.title, dictionaryTotalRows: currentGroup + 1 === groups.length ? rows : Math.max(rows, estimatedRows), isFinalTermChunk: currentGroup + 1 === groups.length, contentDictNameList: null, uniformContentDictName: 'raw-v6'});
        groupResults.push({index: currentGroup, banks: group.map(({filename}) => filename), rows: chunk.rowCount, metrics: {...database._lastBulkAddTermsMetrics}});
        process.stderr.write(`Captured canonical JMdict group ${currentGroup + 1}/${groups.length}\n`);
    }
    assert.equal(rows, fixture.termRows);
    database._termContentBlockImportSession.close();
    database._termContentBlockImportSession = null;
    await Promise.all([database._termContentStore.endImportSession(), database._termRecordStore.endImportSession()]);
    assert.deepEqual(await identity(), initialIdentity);
    assert(captures.length > 0);
    assert(captures.every((capture) => capture.expectedBlockHashes?.length === capture.blockLengths.length));
    assert.equal(compressionRequests, compressionReplies);
    assert.equal(compressionRequests, captures.reduce((total, capture) => total + capture.blockLengths.length, 0));
    const report = {schemaVersion: 1, boundary: 'Current production parser worker and canonical content sink; explicit sequential 3-parser-policy grouping; local codec transport and Node OPFS adapter; setup only, no timing claim', sourceRoot, sourceIdentity: initialIdentity, fixtureSha256: fixture.sha256, lockSha256: sha(lockBytes), captureScriptSha256: sha(await readFile(new URL(import.meta.url))), rows, totalBytes, parserWorkersPolicy: 3, compressionWorkers: codecWorkers.length, compressionRequests, groupResults, captures};
    await writeFile(path.join(output, 'capture.json'), JSON.stringify(report, null, 2));
    console.log(JSON.stringify({rows, groups: groups.length, captures: captures.length, compressionRequests, capturedSourceBytes: captures.reduce((total, capture) => total + capture.sourceBytes, 0)}));
} finally {
    database?._termContentBlockImportSession?.close();
    await zip.close();
    await env.dispose();
}
