// Component evidence only: actual source pools/workers and captured native blocks.
// Node transport, warmed workers, sequential groups; no browser import claim.
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {performance} from 'node:perf_hooks';
import {pathToFileURL} from 'node:url';
import {Worker} from 'node:worker_threads';

const [baselineRoot, candidateRoot, captureDirectory, outputDirectory] = process.argv.slice(2).map((value) => path.resolve(value));
assert.equal(process.version, 'v22.22.0', 'The registered component protocol uses Node 22.22.0');
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const protocol = {
    rounds: 12,
    permutations: [['A', 'B', 'C'], ['B', 'C', 'A'], ['C', 'A', 'B'], ['A', 'C', 'B'], ['C', 'B', 'A'], ['B', 'A', 'C']],
    arms: {A: 'baseline', B: 'candidate', C: 'identical baseline source in a fresh pool'},
    workerCount: 4,
    warmupPassesPerPool: 1,
    measuredPassesPerPool: 1,
    boundary: 'Complete captured JMdict compression corpus per arm; fresh actual worker pool, initialization and one corpus warmup excluded; sequential original groups; native output hashes checked after all timers',
    decision: 'Retain every fixed run, control and outlier. No optional followup timing if candidate effect is within identical-code control noise.',
};
await mkdir(outputDirectory, {recursive: true});
await writeFile(path.join(outputDirectory, 'protocol.json'), JSON.stringify(protocol, null, 2), {flag: 'wx'});
const manifestBytes = await readFile(path.join(captureDirectory, 'capture.json'));
const manifest = JSON.parse(manifestBytes);
assert.equal(manifest.rows, 528299);
assert.equal(manifest.compressionWorkers, protocol.workerCount);
const corpus = [];
for (const capture of manifest.captures) {
    const bytes = await readFile(path.join(captureDirectory, capture.sourceName));
    const descriptors = await readFile(path.join(captureDirectory, capture.descriptorName));
    assert.equal(sha(bytes), capture.sourceSha256);
    assert.equal(sha(descriptors), capture.descriptorSha256);
    const source = new Uint8Array(new SharedArrayBuffer(bytes.byteLength));
    source.set(bytes);
    const columns = [];
    let cursor = 0;
    for (const count of capture.columnLengths) {
        const column = new Uint32Array(count);
        new Uint8Array(column.buffer).set(descriptors.subarray(cursor, cursor + column.byteLength));
        columns.push(column);
        cursor += column.byteLength;
    }
    assert.equal(cursor, descriptors.byteLength);
    const [offsets, lengths, starts, blocks] = columns;
    assert.deepEqual([...blocks], capture.blockLengths);
    corpus.push({...capture, source, offsets, lengths, starts, blocks});
}
const sourceFiles = ['ext/js/dictionary/zstd-term-content.js', 'ext/js/dictionary/zstd-term-content-compression-worker.js', 'ext/lib/zstd-wasm.js', 'ext/lib/zstd.wasm', 'ext/lib/zstd-dicts/jmdict.zdict', 'ext/js/dictionary/term-content-block-envelope.js', 'ext/js/dictionary/term-bank-experiments.js'];
const identify = async (root) => Object.fromEntries(await Promise.all(sourceFiles.map(async (file) => [file, sha(await readFile(path.join(root, file)))])));
const sources = {baseline: await identify(baselineRoot), candidate: await identify(candidateRoot)};
for (const file of sourceFiles.slice(2)) { assert.equal(sources.baseline[file], sources.candidate[file]); }
for (const file of sourceFiles) {
    if (Object.hasOwn(manifest.sourceIdentity, file)) { assert.equal(sources.baseline[file], manifest.sourceIdentity[file], `Captured source changed: ${file}`); }
}
const apis = {
    A: await import(pathToFileURL(path.join(baselineRoot, sourceFiles[0])).href),
    B: await import(pathToFileURL(path.join(candidateRoot, sourceFiles[0])).href),
};
apis.C = apis.A;
const roots = {A: baselineRoot, B: candidateRoot, C: baselineRoot};
const bridge = `
    import {parentPort, workerData} from 'node:worker_threads';
    import {readFile} from 'node:fs/promises';
    globalThis.self = {
        addEventListener(type, listener) {
            if (type !== 'message') throw Error('Unexpected worker listener');
            parentPort.on('message', (data) => listener({data}));
        },
        postMessage(message, transfer = []) { parentPort.postMessage(message, transfer); },
    };
    globalThis.fetch = async (input) => {
        const url = new URL(String(input));
        if (url.protocol !== 'file:') throw Error('Worker cannot fetch network resources');
        return new Response(await readFile(url), {headers: {'Content-Type': 'application/wasm'}});
    };
    await import(workerData.entry);
`;
const bridgeUrl = new URL(`data:text/javascript,${encodeURIComponent(bridge)}`);

async function createPool(arm) {
    const entry = pathToFileURL(path.join(roots[arm], sourceFiles[1])).href;
    const stats = {requests: 0, jobs: 0, sourceConsumed: 0, completions: 0};
    const workers = [];
    const ready = [];
    for (let index = 0; index < protocol.workerCount; ++index) {
        const native = new Worker(bridgeUrl, {workerData: {entry}});
        const listeners = new Map();
        const adapter = {
            terminated: false,
            native,
            addEventListener(type, callback) {
                const values = listeners.get(type) ?? [];
                values.push(callback);
                listeners.set(type, values);
            },
            postMessage(message, transfer) {
                ++stats.requests;
                stats.jobs += message.type === 'span-batch' ? message.requests.length : 1;
                native.postMessage(message, transfer);
            },
            terminate() { this.terminated = true; this.termination ??= native.terminate(); },
        };
        workers.push(adapter);
        const emit = (type, event) => { for (const listener of listeners.get(type) ?? []) { listener(event); } };
        ready.push(new Promise((resolve, reject) => {
            const timer = setTimeout(() => reject(Error('Compression worker initialization timed out')), 30_000);
            native.once('error', (error) => { clearTimeout(timer); reject(error); });
            native.once('message', (message) => {
                clearTimeout(timer);
                if (message.type === 'ready') { resolve(); } else { reject(Error(JSON.stringify(message))); }
            });
        }));
        native.on('message', (data) => {
            if (data.type === 'source-consumed') { ++stats.sourceConsumed; }
            if (data.compressed instanceof ArrayBuffer) { ++stats.completions; }
            emit('message', {data});
        });
        native.on('error', (error) => emit('error', {message: error.message}));
        native.on('messageerror', (error) => emit('messageerror', {message: error.message}));
        native.on('exit', (code) => { if (!adapter.terminated) { emit('error', {message: `Unexpected worker exit ${code}`}); } });
    }
    try {
        await Promise.all(ready);
    } catch (error) {
        for (const worker of workers) { worker.terminate(); }
        await Promise.all(workers.map((worker) => worker.termination));
        throw error;
    }
    const pool = new apis[arm].TermContentCompressionPool(workers);
    return {pool, stats, close: async () => { pool.close(); await Promise.all(workers.map((worker) => worker.termination)); }};
}

async function pass(pool, stats, arm) {
    const before = {...stats};
    const results = [];
    const groups = [];
    const cpuStart = process.cpuUsage();
    const started = performance.now();
    for (const group of corpus) {
        const groupStart = performance.now();
        const operation = pool.beginCompressWrappedSpans(group.source, group.offsets, group.lengths, group.starts, group.blocks, group.dictName, group.options);
        const dispatchMs = performance.now() - groupStart;
        const consumed = operation.sourceConsumed.then(() => performance.now() - groupStart);
        const completed = operation.completion.then((result) => ({result, completionMs: performance.now() - groupStart}));
        const [sourceConsumedMs, {result, completionMs}] = await Promise.all([consumed, completed]);
        results.push(result);
        groups.push({group: group.group, blocks: group.blocks.length, dispatchMs, sourceConsumedMs, completionMs});
    }
    const wallMs = performance.now() - started;
    const cpu = process.cpuUsage(cpuStart);
    const counts = Object.fromEntries(Object.entries(stats).map(([key, value]) => [key, value - before[key]]));
    // Every output is checked outside the measured interval; all arms use the
    // same frozen baseline native-byte oracle and the same captured sources.
    for (let index = 0; index < corpus.length; ++index) {
        assert.equal(results[index].wrapped, true);
        assert.deepEqual(results[index].chunks.map(sha), corpus[index].expectedBlockHashes, `Native output mismatch in ${arm}, group ${index}`);
    }
    const jobs = corpus.reduce((total, group) => total + group.blocks.length, 0);
    assert.equal(counts.jobs, jobs);
    assert.equal(counts.sourceConsumed, jobs);
    assert.equal(counts.completions, jobs);
    assert.equal(counts.requests, arm === 'B' ? corpus.reduce((total, group) => total + Math.min(group.blocks.length, protocol.workerCount), 0) : jobs);
    return {wallMs, dispatchMs: groups.reduce((total, group) => total + group.dispatchMs, 0), sourceConsumedMs: groups.reduce((total, group) => total + group.sourceConsumedMs, 0), completionMs: groups.reduce((total, group) => total + group.completionMs, 0), cpuUserMs: cpu.user / 1000, cpuSystemMs: cpu.system / 1000, counts, groups};
}

const report = {schemaVersion: 1, protocol, node: process.version, execArgv: process.execArgv, baselineRoot, candidateRoot, captureManifestSha256: sha(manifestBytes), sourceIdentity: sources, runnerSha256: sha(await readFile(new URL(import.meta.url))), capturedRows: manifest.rows, capturedGroups: corpus.length, capturedBlocks: corpus.reduce((total, group) => total + group.blocks.length, 0), capturedSpans: corpus.reduce((total, group) => total + group.spanCount, 0), capturedCompressionBytes: corpus.reduce((total, group) => total + group.blockLengths.reduce((sum, length) => sum + length, 0), 0), runs: []};
const reportPath = path.join(outputDirectory, 'results.json');
await writeFile(reportPath, JSON.stringify(report, null, 2), {flag: 'wx'});
for (let round = 0; round < protocol.rounds; ++round) {
    const order = protocol.permutations[round % protocol.permutations.length];
    for (const arm of order) {
        const run = {round: round + 1, order: order.join(''), arm, status: 'starting'};
        report.runs.push(run);
        let context;
        try {
            context = await createPool(arm);
            run.warmup = await pass(context.pool, context.stats, arm);
            globalThis.gc?.();
            run.measurement = await pass(context.pool, context.stats, arm);
            run.status = 'passed';
            process.stderr.write(`Round ${round + 1}/${protocol.rounds}, arm ${arm}: parity and reply counts passed\n`);
        } catch (error) {
            run.status = 'failed';
            run.error = String(error?.stack ?? error);
            throw error;
        } finally {
            await context?.close();
            await writeFile(reportPath, JSON.stringify(report, null, 2));
        }
    }
}
assert.deepEqual(await identify(baselineRoot), sources.baseline);
assert.deepEqual(await identify(candidateRoot), sources.candidate);
for (const group of corpus) { assert.equal(sha(group.source), group.sourceSha256); }
report.completed = true;
await writeFile(reportPath, JSON.stringify(report, null, 2));
console.log(JSON.stringify({reportPath, runs: report.runs.length, capturedBlocks: report.capturedBlocks, baselineRequests: report.capturedBlocks, candidateRequests: corpus.reduce((total, group) => total + Math.min(group.blocks.length, protocol.workerCount), 0)}));
