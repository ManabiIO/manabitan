# Metadata publication and record append: read-only follow-up

This review uses unchanged develop
`9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` and the already retained
[corrected sink diagnostic](run-1/result.json). It did not add a profiling run,
timing cohort or product change. The result is a map of remaining work and
existing ownership, not a newly established optimization.

## Exact diagnostic boundary

The [diagnostic README](README.md) describes one Node 22.22.0 run of the public
database sink for all 528,299 JMdict rows, with sequential production-policy
parser groups and four actual codec workers. Parser execution is outside main
CPU profiles. Node OPFS, absent SQLite/journal work and missing browser overlap
prevent interpreting the measurements as complete-import latency.

All 12 real-parent ownership receipts were reproduced. Existing code adopted
101,143,281 content bytes, eliminating the extra copy caused by the earlier
capture adapter's missing receipt. Original source windows, descriptors and all
103 native compressed blocks matched that older capture. Its fixed compression
oracle remains valid, but its cache-copy counters and sink timings do not
describe the production ownership path.

Inclusive V8 sample totals overlap. Inspector `post` contributes 332.778 ms on
main and the local Node OPFS adapter's `write` contributes 154.377 ms; neither is
a product target. The important product entries include canonical scan at
99.824 sampled ms inclusive, metadata publication at 71.284, record append at
68.525, recent-source caching at 29.099, in-flight registration at 28.796 leaf,
and lookup integrity hashing at 20.657 inclusive. These values must not be
summed into an elapsed import time.

## Publisher attribution correction

`_publishArtifactTermContentMetadata` has 69 available source-position ticks in
the retained main profiles. **58 are at line 10065**, its call to
`_cacheRecentPublishedTermContentSources`; eight are at its contiguous
publication call. Therefore its apparent approximately 28.6 ms leaf total does
not establish a separate costly scalar publication loop. The current code
starts that fallback loop at `pendingOffsets.length` after successful bulk
publication, so it performs no iterations in that case. The cache call and
publisher self samples must not be counted as independent optimization budgets.

The source-position counts were derived only from the existing
`run-1/sink-group-*.cpuprofile` files; no second profile was collected.

## Source and prior-work review

| Area | Current mechanism and review result |
| --- | --- |
| Metadata publication | Consecutive reservations already use typed-array fills and copies after synchronous validation. #759/#837 own that work; #764 owns broader related variants. |
| Recent-source caching | Owned storage is already adopted. #876 tried passing the successful synchronous publication proof into cache admission to avoid repeated scans; it did not establish a useful full-import gain. |
| In-flight sources | The exact validation fast path is already owned by #830. Removing registration would also affect concurrent reads and failure drain behavior. |
| Content-reference validation | Current code selects stable factory-origin columns once per synchronous run, rechecks after awaits, and skips consecutive aliases. #809/#822 cover these mechanisms. |
| Record-field encoding | Current code writes final offset/length columns directly for trusted synchronous references (#849). #855 owns independent content/score run handling; the earlier score-only and uniform-score variants did not qualify. |
| Record materialization | The current large-import path already bypasses per-row retained record construction. This review found no extra materialization pass in JMdict's sink path. |
| Compact-field validation | The writer validates score keys and content references after relevant await boundaries. No cached producer proof was introduced that could accept mutated caller data. |
| Lookup checksum reader | The separately preserved aligned-word experiment completed its fixed cold/warm controls without a useful gain; its runtime was not promoted. |

The narrow [cache-origin proposal](cache-origin-screen.md) was distinct from
those earlier mechanisms but affected only 89,237 proved JMdict pending rows.
Preserving the existing bounded visible view would require origin metadata and
translation, so the coordinator declined implementation. Jitendex has no
eligible owned parser groups. VNDB ownership is recorded, but the existing
receipts do not identify nonzero cache origins or pending unique span counts;
term row counts cannot substitute for that missing coverage.

No further metadata or record-append implementation was selected from this
review. The source and ownership audit prevented reimplementing already held
mechanisms or treating profiler/adapter work as an available product saving.
