# Corrected JMdict canonical sink CPU diagnostic

This is one diagnostic run against unchanged develop
`9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`, using Node 22.22.0. It identifies
work to investigate; it is not a latency comparison, a browser import benchmark,
or evidence of a speedup. No product change was made for this diagnostic.

## Boundary and correctness

The harness executes the actual parser worker entry point through a local
message adapter, using actual structured-clone transfer. Parser execution is
outside the main CPU profile. It then calls the public database content sink for
each of the 12 groups from the current 3-parser-worker policy. Four actual Node
worker threads run the unchanged compression worker entry point and have their
own CPU profiles. The sink uses the repository's Node OPFS adapter; SQLite,
journaling, concurrent parser scheduling and visible browser completion are
outside the experiment.

The receipt reproduces the parent parser's owned-content registration before
calling the sink. All 12 groups have `ownsContentBytes=true`, no borrowed-memory
lease, and resolved content references. The recent-source cache adopts
**101,143,281 bytes**. Receiver-owned content and compression source offsets are
all eight-byte aligned. These observations do not measure the producer's native
allocation address or its earlier copy cost.

All 528,299 rows pass through the current native canonical scanner with no
fallback. There are 366,030 group-unique rows, 3,998 exact cross-group matches,
362,032 pending content spans and 103 native compressed blocks. Every source
window, normalized span descriptor and compressed block matches the earlier
fixed capture. Verification and source hashing are outside the sampled main
intervals. Original profiles, source identities, geometry and per-group metrics
are retained. There was no failed diagnostic attempt.

The earlier batching capture omitted the owned-content registration. Its
logical compression input oracle remains valid, as the equality checks above
establish, but its cache-copy counters and sink timings are not production
attribution. In particular, the earlier roughly 101 MB cache copy is eliminated
by applying the existing ownership contract; it is not a new optimization.

## Attribution

The table gives sums of V8 sample intervals, not exclusive phase stopwatches.
Inclusive entries overlap and must not be added together. The main profiler
starts and stops around each public sink call, while worker profiles also
contain idle time between groups. Those idle intervals are not codec work.

| Main-thread product area | Sampled ms | Scope |
| --- | ---: | --- |
| Canonical scanner adapter | 99.824 | Inclusive; native scan and copies included |
| Native `scan_canonical` | 65.568 | Leaf; current WASM export index 4 is proven |
| Content metadata publication | 71.284 | Inclusive; includes recent-source cache |
| Record append | 68.525 | Inclusive; includes encoding and lookup packaging |
| In-flight source registration | 28.796 | Leaf |
| Recent-source cache | 29.099 | Inclusive; owned bytes adopted |
| Lookup integrity hash chain | 20.657 | Inclusive |

Inspector `post` contributes 332.778 sampled ms on main and is instrumentation
overhead. The Node OPFS adapter's `write` contributes another 154.377 sampled ms;
this adapter copies its backing buffers and does not model browser OPFS cost.
Neither is an eligible product optimization target from this profile.

Across the four codec workers, the wrapped compression finish path has 379.292
sampled CPU ms, versus 25.577 ms for preparation. This is aggregate worker CPU,
not critical-path wall time. The negative request-batching experiment already
showed that reducing request count alone did not provide a useful gain.

## Next bounded opportunities

The large lookup integrity hash path is a small but directly attributed,
isolatable target. It currently reads 32-bit words through a little-endian
`DataView`. A separate experiment could compare an aligned `Uint32Array` reader
with the current code, preserving the 1 KiB threshold, endianness, unaligned
fallback, invalid-range behavior and every persisted checksum. The current
profile supplies an approximate 21 ms sampled upper bound for removing that
entire chain; a load-only change can save only a fraction of it. This was a
hypothesis, not an established gain. The subsequent fixed cold/warm
[checksum screen](../20261128-lookup-word-loads/README.md) did not establish a
useful gain, and its runtime candidate was not promoted. Historical #627
introduced the current DataView implementation, and #877 separately owns moving
integrity work into an I/O worker. The reviewed #73 checksum experiment also
used DataView. No exact
word-array screen was found in that history audit.

In-flight source registration is another visible CPU area, but most of its
loop establishes bounds, ordering, duplicate and concurrent-source invariants.
The exact validation fast path is already owned by open #830. It is not
reimplemented here. Removing it or replacing it with a producer proof would also
require preserving mutation, concurrency and error behavior.

The native canonical loop is substantial, but metadata publication, scanner
snapshots, signature omission and cache proof reuse intersect prior experiments
or correctness constraints. The profile alone does not establish a new safe
elimination of work in that loop. Existing bulk publication and ownership paths
are already active.

## Reproduction and preservation

Run `profile.mjs` from this worktree with three arguments: the clean source root,
an output directory, and the unchanged compression capture directory. The
frozen run used `node --max-old-space-size=768`, Node 22.22.0, the locked JMdict
fixture and four codec workers. It requires the existing source-window capture
as an independent byte oracle; do not replace that capture with newly generated
expected bytes.

Run `python3 analyze.py <output-directory>` to derive `attribution.json`. This
operation only reads the retained profiles and current pinned canonical WASM;
it does not run the workload. It verifies the WASM identity and parses its
export section to bind native function 4 to `scan_canonical`. Other private
native function numbers are deliberately not inferred from older binaries.

Run receipt SHA-256:
`1b7d938c604de4cf9c05b4f45cc226b36ea4d54f9a077ad09e9dd3647ca52e39`.
Frozen diagnostic script SHA-256:
`87916f409795677a332c727681fc5585284ea4935333b9e138cd77a55becfd31`.
No browser timing or new PR is claimed by these artifacts.

## Review bundle and follow-up source screens

The actual raw receipt, profiles and attribution are in [`run-1/`](run-1/).
Inclusive timings overlap; the
[metadata and record review](metadata-record-screen.md) also explains why
publisher self samples at its cache call are not a second scalar publication
loop. The [cache-origin review](cache-origin-screen.md) was declined before
implementation, and the [inflater review](inflater-source-screen.md) identified
no new independently grounded change. Neither screen ran another corpus.

See the [bundle map](../20261128-held-import-evidence/README.md) for publication
paths, checks and reproduction boundaries. The preserved analyzer uses the
sourceRoot in the historical raw receipt for its pinned WASM export proof;
regenerating the diagnostic in another checkout records that checkout
automatically. No historical raw source path was rewritten.
