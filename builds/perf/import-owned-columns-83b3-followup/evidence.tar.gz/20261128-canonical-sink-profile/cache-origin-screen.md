# Recent-source cache origin: declined after read-only review

The corrected sink profile shows recent-source cache work after the existing
owned-content adoption. Source-position ticks also place most of the apparent
publisher leaf samples at its cache call, rather than an extra scalar metadata
publication loop. Contiguous publication already skips the scalar fallback.

A narrow candidate was to keep an adopted source's original visible view, so
its existing absolute span offsets could use the cache's dense `.fill`/`.set`
path even when the first retained span starts after byte zero. The current code
instead retains a trimmed subview, charges its full backing allocation, and
stores offsets relative to that trimmed view. Nonzero origins use scalar writes.

Existing JMdict receipts prove three affected groups: 32,256, 31,330 and 25,651
pending rows, totaling **89,237**. The excluded leading ranges are 49, 289 and
366 bytes, totaling **704**. All other JMdict groups already start at zero.
No backing-memory allocation or copy is removed; the proposed saving is only
the scalar offset-subtraction/publication work for those groups.

The visible trimming is a contract, not just an allocation choice. The recent
source reader bounds candidate lengths against the trimmed view, and tests
explicitly require the trimmed returned view and relative offsets. Exposing
the whole source could accept a candidate extending into previously excluded
prefix/suffix bytes. Original logical retained-byte counters also use the
trimmed view length, while eviction and rollback charge the full backing.

A compatible representation would retain the same bounded view and add origin
metadata, translate copied absolute offsets back on lookup, and reject negative
translated offsets. It would preserve collision comparison, one-use ownership,
FIFO eviction and rollback behavior, but add representation/bookkeeping for a
small proved JMdict opportunity. Complete owned-source admission already
requires byteOffset zero and the whole backing allocation; unmarked subviews
and boundary-only snapshots must retain their existing copy behavior.

Current production-policy receipts show:

| Dictionary | Owned parser results | Demonstrably affected cache rows |
| --- | --- | --- |
| JMdict | 12 groups / 528,299 rows | 3 groups / 89,237 pending rows |
| Jitendex | None; all 22 groups / 436,555 rows borrow | Zero |
| VNDB | 170 groups / 6,648,310 rows | Unknown; receipts lack unique-span counts and minimum offsets |

VNDB's total term rows cannot be substituted for cache-publication rows. No
new corpus capture was run just to fill that evidence gap.

The ownership audit found no exact earlier origin variant. Merged #824 owns
the bounded adopted subview, #727 the zero-origin bulk mapping, and held #876
reuses publication proof without changing origin. #764 owns different cache
and metadata variants. The coordinator declined implementation because the
small proved JMdict scope does not justify a new cache representation. No code,
timing cohort or publication was performed for this idea.
