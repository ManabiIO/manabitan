# Current libdeflate source screen: no new implementation selected

This read-only screen examines develop
`9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` and its pinned parser WASM
`8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee`.
No product source, vendor configuration, compiler flag or dictionary fixture was
changed. No additional timing cohort or corpus run was performed.

The retained dependency is libdeflate v1.26. The current integration already
provides the principal WASM-specific mechanisms that source inspection would
otherwise suggest:

- `machine_word_t` is uint64 on wasm32, retaining 32-bit pointer/length ABI.
  This selects the wide bit reservoir, multiple fast literals and wide history
  words. Merged #664 owns this adaptation.
- The upstream unaligned-access predicate explicitly includes WebAssembly, so
  refill uses an unaligned word and the branchless refill path.
- One static per-instance decompressor persists across calls; there is no
  allocation/reconstruction per bank. Static Huffman tables are reused until a
  dynamic block changes them.
- The portable implementation is selected directly at compile time. There is
  no per-call CPU dispatcher, architecture probing or gzip wrapper.
- The pinned build already uses `-O3`, bulk memory and SIMD support. Historical
  #640 builtin memcpy/memset cleanup produced identical WASM, so it is not a
  new source-level opportunity.

The fast history-copy loop is a visible throughput mechanism, but open #812
already owns its 128-bit load/store variant. That experiment preserves overlap
and tail behavior and is held after mixed complete-import controls. It must not
be reintroduced as a new candidate. Older #22/#28 bit-buffer experiments concern
the superseded miniz backend, while the current wide libdeflate path is already
present.

The wrapper's apparent JSON-interior memmove is not executed for current
multi-bank parser groups. The JS loader supplies a bank-span table whenever
there is more than one source; the native function preserves each complete
inflated bank and continues before the compaction branch. All 12 current JMdict
groups contain multiple banks. The two wrapper whitespace scans inspect only
the outer boundary. Exact compressed consumption, expected decoded length and
CRC remain required archive-integrity checks. The deferred-CRC error retry is
an error-ordering path, not normal repeated decompression.

Source alone does not establish another safe elimination in the Huffman decode
loop. Decode-table caching, bitfield-expression specialization or table-size
tuning would require new attribution and a concrete work-count rationale; they
are not promoted from an assumed hot loop. In particular, no vendor version or
configuration tuning was selected.

The existing decoder-inclusive phase estimate is not enough to distinguish
Huffman table construction, token decoding/history expansion and CRC. The newly
proven current symbol map provides a useful attribution boundary:

| Native function index | Exact current function |
| --- | --- |
| 2 | `crc32_bytes` |
| 48 | `libdeflate_deflate_decompress_ex` |
| 49 | `build_decode_table` |
| 50 | `term_bank_inflate` |

Those names are bound by the independent exact-release rebuild and identical
noncustom sections in the preserved
[native symbol proof](provenance/native-symbol-proof.json).
The older decoded-source worker profiles exclude ZIP inflation, so they cannot
answer this attribution question. A separate raw-inflate CPU diagnostic could
use these names without a new compiler build if the coordinator chooses that
next step. This screen itself identified **no independently grounded new
inflater optimization**.

Reviewed source: `term-bank-inflate.c`, `term-bank-parser.c`,
`term-bank-wasm-parser.js`, the pinned build manifest, and the retained
libdeflate `common_defs.h`, `deflate_decompress.c` and `decompress_template.h`.
