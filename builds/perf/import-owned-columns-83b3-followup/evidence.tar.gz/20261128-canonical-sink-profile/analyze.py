#!/usr/bin/env python3
"""Deterministic attribution of retained V8 CPU profiles; never runs the import."""

import collections
import hashlib
import json
import pathlib
import sys


def digest(data):
    return hashlib.sha256(data).hexdigest()


def frame_key(node):
    frame = node["callFrame"]
    return (frame["functionName"], frame["url"], frame["lineNumber"])


def summarize(directory, names):
    leaf = collections.defaultdict(lambda: [0, 0])
    inclusive = collections.defaultdict(lambda: [0, 0])
    receipts = []
    for name in names:
        raw = (directory / name).read_bytes()
        profile = json.loads(raw)
        nodes = {node["id"]: node for node in profile["nodes"]}
        parents = {
            child: node["id"]
            for node in profile["nodes"]
            for child in node.get("children", [])
        }
        assert len(profile["samples"]) == len(profile["timeDeltas"])
        for node_id, micros in zip(profile["samples"], profile["timeDeltas"]):
            key = frame_key(nodes[node_id])
            leaf[key][0] += micros
            leaf[key][1] += 1
            seen = set()
            while node_id is not None:
                key = frame_key(nodes[node_id])
                if key not in seen:
                    inclusive[key][0] += micros
                    inclusive[key][1] += 1
                    seen.add(key)
                node_id = parents.get(node_id)
        receipts.append({
            "file": name,
            "profileMs": (profile["endTime"] - profile["startTime"]) / 1000,
            "samples": len(profile["samples"]),
            "sha256": digest(raw),
        })

    def ordered(values):
        return [
            {"function": key[0], "source": key[1], "line": key[2],
             "sampledMs": value[0] / 1000, "samples": value[1]}
            for key, value in sorted(values.items(), key=lambda item: (-item[1][0], item[0]))
        ]

    return {"profiles": receipts, "leaf": ordered(leaf), "inclusive": ordered(inclusive)}


def wasm_exports(raw):
    assert raw[:8] == b"\0asm\x01\0\0\0"
    cursor = 8

    def uleb():
        nonlocal cursor
        value = shift = 0
        while True:
            byte = raw[cursor]
            cursor += 1
            value |= (byte & 127) << shift
            if byte < 128:
                return value
            shift += 7

    while cursor < len(raw):
        section = raw[cursor]
        cursor += 1
        size = uleb()
        end = cursor + size
        if section == 7:
            result = []
            for _ in range(uleb()):
                size = uleb()
                name = raw[cursor:cursor + size].decode("utf-8")
                cursor += size
                kind = raw[cursor]
                cursor += 1
                result.append({"name": name, "kind": kind, "index": uleb()})
            assert cursor == end
            return result
        cursor = end
    raise AssertionError("WASM export section absent")


directory = pathlib.Path(sys.argv[1]).resolve()
result_raw = (directory / "result.json").read_bytes()
result = json.loads(result_raw)
metrics = collections.defaultdict(float)
for group in result["groupResults"]:
    for key, value in group["metrics"].items():
        if isinstance(value, (int, float)):
            metrics[key] += value
canonical_path = "ext/lib/term-content-canonical-scan-v1.wasm"
canonical_raw = (pathlib.Path(result["sourceRoot"]) / canonical_path).read_bytes()
assert digest(canonical_raw) == result["sourceIdentity"][canonical_path]
exports = wasm_exports(canonical_raw)
assert {"name": "scan_canonical", "kind": 0, "index": 4} in exports
report = {
    "schemaVersion": 1,
    "method": "Sum V8 timeDeltas at leaves; inclusive frames counted once per sample. Values include profiler and adapter frames, are overlapping CPU samples, and are not elapsed import times.",
    "resultSha256": digest(result_raw),
    "analysisScriptSha256": digest(pathlib.Path(__file__).read_bytes()),
    "groups": [{key: group[key] for key in ("index", "rows", "ownsContentBytes", "receivedSourceByteOffsetModulo8")} for group in result["groupResults"]],
    "main": summarize(directory, result["measuredScopes"]),
    "codec": summarize(directory, result["workerProfiles"]),
    "metricsTotals": dict(sorted(metrics.items())),
    "canonicalExportProof": {"path": canonical_path, "sha256": digest(canonical_raw), "exports": exports},
}
(directory / "attribution.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"resultSha256": report["resultSha256"], "mainProfiles": len(report["main"]["profiles"]), "codecProfiles": len(report["codec"]["profiles"]), "canonicalScanFunctionIndex": 4}))
