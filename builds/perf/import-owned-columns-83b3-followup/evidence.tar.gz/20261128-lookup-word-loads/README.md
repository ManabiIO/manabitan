# Aligned lookup checksum word reader: HOLD

The fixed component screen did not establish a useful gain. First-use results
were effectively tied within the identical-code control variation, while the
warmed candidate tended to be slower. The runtime candidate remains held and
was not promoted; this evidence preserves the result for review. No extra
timing rounds or alternative word-reader variants were run after seeing these
results.

## Hypothesis and isolated change

The corrected JMdict sink CPU diagnostic attributed approximately 20.7 sampled
milliseconds to the persisted lookup integrity hash chain. Current develop
`9e10d3b3fcf66d344ab31bc42c9b522fa5215da2` uses a little-endian DataView reader
for valid ranges of at least 1,024 bytes. The prototype tries one Uint32Array
reader when the platform is little-endian and `bytes.byteOffset + start` is
four-byte aligned. The existing DataView fallback, range admission, 1,024-byte
threshold, small-key implementation, arithmetic and persisted checksums remain
unchanged.

The source change is 44 added lines in `ext/js/dictionary/term-key-hash.js`.
Its separate hot loop avoids a per-word dispatch branch. This was one chosen
variant; Int32Array and other alternatives were not screened. The prior-work
audit found that merged #627 introduced the current DataView path, historical
#73 also tried DataView, and open #877 separately owns moving checksum work into
an I/O worker. No exact prior aligned word-array screen was found.

## Actual workload and correctness

`capture.mjs` uses unchanged current source, the locked JMdict archive, the
actual parser worker entry point with transferred output, the exact parent
owned-content receipt, the public database sink, and four actual native codec
workers. The Node OPFS adapter and sequential parser policy are explicit
diagnostic adapters. Capture is untimed. It preserves the corrected sink's
source-window, descriptor and compressed-byte oracle checks.

The wrapper calls the original `_createLookupIndexChunk` first, then snapshots
its base, derived and authoritative record-field inputs, together with the
original persisted checksum from header offsets 24, 28 and 32. The captured
workload has 528,299 rows, 12 groups and **36 checksum spans totaling 23,748,240
bytes**. Every span is an ordinary buffer, at least 1,024 bytes and absolutely
four-byte aligned. Candidate coverage is therefore 100% of this workload.

All 12 parent ownership receipts and all 103 native compressed block hashes
pass. The cache adopts 101,143,281 existing owned bytes. All captured source and
descriptor hashes match the earlier fixed compression oracle. This capture
does not reintroduce the older adapter's missing owned-content registration.

The independent fixed XXH32 vector suite passes all 151 cases, including shared
and ordinary backing, subview and range offsets, and tails around the 1 KiB
threshold. Another 64 differential cases preserve the existing behavior for
negative, fractional, reversed, out-of-bounds and NaN ranges. All 2,592 checksum
values from the measured cold/warm passes match the original writer's headers.

## Registered protocol

The runner writes `protocol.json` before starting any timed child. There are 12
rounds with orders ABC, BCA, CAB, ACB, CBA and BAC, repeated twice. Every arm uses
a fresh Node 22.22.0 child with `--max-old-space-size=256`. A and C import the
identical pinned baseline file; B imports the frozen candidate.

Each child loads and SHA-verifies the same 36 inputs outside measurement.
Original byte offsets and the shared base/derived backing within each writer
chunk are reconstructed; record fields retain a separate backing. Unreferenced
header/padding bytes are zero-filled and never hashed. The child then imports
the helper without calling it, measures its first full-corpus pass, and measures
exactly one warmed full-corpus pass. The first recorded pass is the sole warmup.
This is first-call/JIT cold, with materialized input bytes; it is not a hardware
cache-cold test or a browser import timing.

Both conditions retain each span's role and duration, whole-corpus elapsed and
CPU totals, and all returned checksums. Assertions, file hashing and report
allocations are outside the intervals. Host resource snapshots, child exit
status, stderr, complete orderings and all outliers are retained. Sources and
inputs are checked again after measurement. Whole-corpus totals are primary;
medians of differently sized spans are not pooled into an import claim.

## Results

All 36 children exited successfully. All 36 cold and 36 warm corpus passes
matched every expected checksum, and all frozen source/input identities stayed
unchanged. There was no failed timing attempt and no observation was removed.

| Whole-corpus condition | A baseline mean | B candidate mean | C identical baseline mean |
| --- | ---: | ---: | ---: |
| First helper pass | 20.729 ms | 21.032 ms | 21.368 ms |
| Warmed pass | 12.122 ms | 12.659 ms | 12.231 ms |

For the first pass, candidate minus the mean of its paired controls has a median
of **-0.0366 ms (-0.182%)** and mean of -0.0160 ms. Candidate beats both controls
in only 4 of 12 rounds. The identical-code C-minus-A difference ranges from
-4.870 to +9.082 ms. This does not establish a useful first-use saving.

For the warmed pass, the paired median is **+0.6591 ms (+5.73%)**, with a mean
of +0.4825 ms. Candidate beats both controls in 3 of 12 rounds. The identical-code
C-minus-A difference ranges from -4.177 to +4.270 ms. These observations do not
justify a precise regression estimate, but they provide no positive result to
promote. The independent controls prevent interpreting the candidate's lower
unpaired first-pass median as an established improvement.

## Validation and limits

The existing 151-vector test file passed; scoped strict TypeScript, syntax and
whitespace checks passed. The initial test command used an unsupported
`--minWorkers` flag and failed before executing tests; the corrected command
passed. Two initial lint attempts were blocked by a missing data file in the
sparse checkout. After restoring that tracked file, the actual ESLint process
was killed with exit 137 after the existing pako CommonJS warning, without
reporting a source violation. It is recorded as incomplete, not a pass.

Independent read-only review found no blocker in the runtime word/tail loop,
alignment/endian fallback, original-writer capture, cold/warm timing boundaries,
control isolation or result retention. Full unit/build suites and browser
qualification were not run for this held variant. The runtime was not changed
after its correctness checks or after freezing the cohort.

## Reproduction and identities

`capture.mjs` accepts the clean source root, output directory and original
compression capture directory. Recreate that earlier capture from its preserved
script and locked fixture if the raw staging was reclaimed. The original
capture JSON and native oracles remain unchanged. `replay.mjs` accepts baseline
root, candidate root, checksum capture directory and a new output directory.
`analyze.py <results.json>` only summarizes the retained observations.

The exact checksum inputs are retained with their per-file SHA-256 identities.
The runtime patch, source/capture/protocol hashes, complete results and validation
receipt accompany this report.

| Artifact | SHA-256 |
| --- | --- |
| Baseline hash helper | `c2d4ed2a04f4c5dcd8a5f5865d49f7cbdade87fd95ab4fff92f3a9bb0181d208` |
| Candidate hash helper | `c9dc7d77d376cc25612489ba397ba444f227551ac3188654bd85d1120b5e50eb` |
| Capture script | `7a637a2fa87458057d422e942690309734258ed1a807890ec7135c1e1d2d7828` |
| Capture manifest | `ff9a1176c67a307401f5b4467299a0201b45df259ab9d9189bcc801e9bc92670` |
| Frozen replay runner | `18b7d8591db2c4ceb2b72d3c587729df373fba443dc9d627c81a0a9bf8ae0064` |
| Raw results | `18402a0ab3af8429d361f444c767ef196b40c3af2198f0f997420bb19e40909e` |

## Publication layout

Reports and the exact input archive remain in [`evidence/`](evidence/). The
archive is included once in the bundle; publication does not require copying
or recompressing it. The [bundle map](../20261128-held-import-evidence/README.md)
defines local and public paths. Original absolute paths in the frozen protocol
and receipts record the execution environment and remain unchanged.
