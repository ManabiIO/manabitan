// Capture actual checksum inputs from the unchanged public JMdict content sink.
// No timing. Actual parser receipts, native codec workers and Node OPFS adapter.
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {openAsBlob} from 'node:fs';
import {Worker} from 'node:worker_threads';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {BlobReader, TextWriter, ZipReader} from '@zip.js/zip.js';

const sourceRoot = path.resolve(process.argv[2]);
const output = path.resolve(process.argv[3]);
const oracleDirectory = path.resolve(process.argv[4]);
assert.equal(process.version, 'v22.22.0');
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const sourceModule = (name) => import(pathToFileURL(path.join(sourceRoot, name)).href);
const sourceFiles = [
    'ext/js/dictionary/term-bank-wasm-parser.js',
    'ext/js/dictionary/term-bank-wasm-parser-worker.js',
    'ext/js/dictionary/dictionary-database.js',
    'ext/js/dictionary/dictionary-importer.js',
    'ext/js/dictionary/term-content-ownership.js',
    'ext/js/dictionary/term-content-opfs-store.js',
    'ext/js/dictionary/term-record-opfs-store.js',
    'ext/js/dictionary/term-key-hash.js',
    'ext/js/dictionary/term-lookup-index.js',
    'ext/js/dictionary/term-content-block-envelope.js',
    'ext/js/dictionary/term-bank-experiments.js',
    'ext/js/dictionary/raw-term-content.js',
    'ext/js/dictionary/zstd-term-content-compression-worker.js',
    'test/fixtures/opfs-continuation/node-opfs-adapter.mjs',
    'ext/js/dictionary/term-content-canonical-scan.js',
    'ext/js/dictionary/term-content-block-store.js',
    'ext/js/dictionary/zstd-term-content.js',
    'ext/lib/term-bank-parser.wasm',
    'ext/lib/term-content-canonical-scan-v1.wasm',
    'ext/lib/zstd-wasm.js',
    'ext/lib/zstd.wasm',
    'ext/lib/zstd-dicts/jmdict.zdict',
];
const identity = async () => Object.fromEntries(await Promise.all(sourceFiles.map(async (file) => [file, sha(await readFile(path.join(sourceRoot, file)))])));
const initialIdentity = await identity();
const sourceCommit = execFileSync('git', ['-C', sourceRoot, 'rev-parse', 'HEAD'], {encoding: 'utf8'}).trim();
const sourceDiff = execFileSync('git', ['-C', sourceRoot, 'diff', 'HEAD', '--binary']);
assert.equal(sourceCommit, '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2');
assert.equal(sourceDiff.byteLength, 0, 'Profile baseline must have no tracked source changes');
const oracleBytes = await readFile(path.join(oracleDirectory, 'capture.json'));
const oracle = JSON.parse(oracleBytes);
for (const [file, digest] of Object.entries(oracle.sourceIdentity)) { assert.equal(initialIdentity[file], digest, `Oracle source changed: ${file}`); }
const expectedAdoptedBytes = [];
for (const capture of oracle.captures) {
    const data = await readFile(path.join(oracleDirectory, capture.descriptorName));
    assert.equal(sha(data), capture.descriptorSha256);
    const offsets = new Uint32Array(data.buffer, data.byteOffset, capture.columnLengths[0]);
    const lengths = new Uint32Array(data.buffer, data.byteOffset + offsets.byteLength, capture.columnLengths[1]);
    let lower = Infinity;
    let upper = 0;
    for (let index = 0; index < offsets.length; ++index) { lower = Math.min(lower, offsets[index]); upper = Math.max(upper, offsets[index] + lengths[index]); }
    expectedAdoptedBytes.push(upper - lower);
}
await mkdir(output, {recursive: true});
const lockBytes = await readFile(path.join(sourceRoot, 'test/perf/dictionaries.lock.json'));
const fixture = JSON.parse(lockBytes).dictionaries.jmdict;
const archivePath = path.join(sourceRoot, 'builds/e2e-dictionary-cache', fixture.cacheFile);
const archiveBytes = await readFile(archivePath);
assert.equal(archiveBytes.byteLength, fixture.sizeBytes);
assert.equal(sha(archiveBytes), fixture.sha256);
globalThis.fetch = async (input) => {
    const url = new URL(String(input));
    assert.equal(url.protocol, 'file:');
    return new Response(await readFile(url), {headers: {'Content-Type': 'application/wasm'}});
};
const api = await sourceModule('ext/js/dictionary/zstd-term-content.js');
let compressionRequests = 0;
let compressionReplies = 0;
let sourceConsumedReplies = 0;
const codecWorkers = [];
const requestOrder = [];
const completedBlocks = new Map();
const bridge = `
    import {parentPort, workerData} from 'node:worker_threads';
    import {readFile} from 'node:fs/promises';
    globalThis.self = {
        addEventListener(type, listener) {
            if (type !== 'message') throw Error('Unexpected codec worker listener');
            parentPort.on('message', (data) => listener({data}));
        },
        postMessage(message, transfer = []) { parentPort.postMessage(message, transfer); },
    };
    globalThis.fetch = async (input) => {
        const url = new URL(String(input));
        if (url.protocol !== 'file:') throw Error('Codec profile cannot fetch network resources');
        return new Response(await readFile(url), {headers: {'Content-Type': 'application/wasm'}});
    };
    await import(workerData.entry);
`;
class CaptureCodecWorker extends EventTarget {
    constructor(entry) {
        super();
        assert.equal(String(entry), pathToFileURL(path.join(sourceRoot, 'ext/js/dictionary/zstd-term-content-compression-worker.js')).href);
        this.index = codecWorkers.length;
        this.terminated = false;
        this.ready = new Promise((resolve, reject) => { this.resolveReady = resolve; this.rejectReady = reject; });
        this.thread = new Worker(new URL(`data:text/javascript,${encodeURIComponent(bridge)}`), {workerData: {entry: String(entry)}});
        codecWorkers.push(this);
        this.thread.on('message', (data) => {
            if (data.type === 'ready') { this.resolveReady(); }
            if (data.type === 'initialization-error') { this.rejectReady(Error(String(data.error))); }
            if (data.type === 'source-consumed') { ++sourceConsumedReplies; }
            if (data.compressed instanceof ArrayBuffer) { ++compressionReplies; completedBlocks.set(data.id, data.compressed); }
            this.dispatchEvent(new MessageEvent('message', {data}));
        });
        const fail = (error) => {
            this.rejectReady(error);
            const event = new Event('error');
            Object.defineProperty(event, 'message', {value: String(error.message)});
            this.dispatchEvent(event);
        };
        this.thread.on('error', fail);
        this.thread.on('messageerror', () => this.dispatchEvent(new MessageEvent('messageerror')));
        this.thread.on('exit', (code) => { if (!this.terminated) { fail(Error(`Unexpected codec worker exit ${code}`)); } });
    }
    postMessage(data, transfer = []) {
        ++compressionRequests;
        assert.equal(typeof data.id, 'number');
        assert(data.source instanceof Uint8Array);
        requestOrder.push({id: data.id, group: currentGroup, bytes: data.contentBytes, spans: data.sourceOffsets.length, worker: this.index});
        this.thread.postMessage(data, transfer);
    }
    terminate() { this.terminated = true; this.termination ??= this.thread.terminate(); }
}
globalThis.Worker = CaptureCodecWorker;
const {createNodeOpfs} = await sourceModule('test/fixtures/opfs-continuation/node-opfs-adapter.mjs');
const env = await createNodeOpfs();
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: 8, deviceMemory: 8, storage: {getDirectory: async () => env.root}}});
const captures = [];
let pendingCapture = null;
let currentGroup = -1;
const originalBegin = api.TermContentCompressionPool.prototype.beginCompressWrappedSpans;
api.TermContentCompressionPool.prototype.beginCompressWrappedSpans = function (source, offsets, lengths, starts, blocks, dictName, options) {
    assert.equal(pendingCapture, null);
    pendingCapture = {source, offsets, lengths, starts, blocks};
    captures.push({group: currentGroup, sourceBytes: source.byteLength, sourceByteOffsetModulo8: source.byteOffset % 8, spanCount: offsets.length, blockLengths: [...blocks], dictName});
    return originalBegin.call(this, source, offsets, lengths, starts, blocks, dictName, options);
};
const {registerOwnedTermContent} = await sourceModule('ext/js/dictionary/term-content-ownership.js');
const {RAW_TERM_CONTENT_TOKEN_DICT_NAME} = await sourceModule('ext/js/dictionary/raw-term-content.js');
let parserListener;
let parserReply;
globalThis.self = {
    addEventListener(type, listener) { assert.equal(type, 'message'); parserListener = listener; },
    postMessage(message, transfer = []) { const reply = parserReply; parserReply = null; reply(structuredClone(message, {transfer})); },
};
await sourceModule('ext/js/dictionary/term-bank-wasm-parser-worker.js');
async function parseRequest(message) {
    assert.equal(typeof parserReply === 'function', false);
    const reply = new Promise((resolve) => { parserReply = resolve; });
    parserListener({data: message});
    const result = await reply;
    assert(!result.error, JSON.stringify(result.error));
    return result;
}
const {TermRecordOpfsStore} = await sourceModule('ext/js/dictionary/term-record-opfs-store.js');
const {splitPersistedTermLookupIndex} = await sourceModule('ext/js/dictionary/term-lookup-index.js');
const checksumPayloads = [];
const originalCreateLookup = TermRecordOpfsStore.prototype._createLookupIndexChunk;
TermRecordOpfsStore.prototype._createLookupIndexChunk = function (...args) {
    const result = originalCreateLookup.apply(this, args);
    const [firstId, count, contentOffsetBase, payload, recordFields, recordFieldsFormat] = args;
    const {base, derived} = splitPersistedTermLookupIndex(payload);
    const header = new DataView(result.buffer, result.byteOffset, result.byteLength);
    for (const [role, bytes, headerOffset] of [['base', base, 24], ['derived', derived, 28], ['recordFields', recordFields, 32]]) {
        checksumPayloads.push({group: currentGroup, firstId, count, contentOffsetBase, recordFieldsFormat, role, byteLength: bytes.byteLength, byteOffset: bytes.byteOffset, byteOffsetModulo4: bytes.byteOffset % 4, shared: bytes.buffer instanceof SharedArrayBuffer, expectedHash: header.getUint32(headerOffset, true), bytes: new Uint8Array(bytes)});
    }
    return result;
};
const {DictionaryDatabase} = await sourceModule('ext/js/dictionary/dictionary-database.js');
const {compileCanonicalScanModule} = await sourceModule('ext/js/dictionary/term-content-canonical-scan.js');
const {RawZipPayloadReader} = await sourceModule('ext/js/dictionary/term-bank-source-pipeline.js');
const archive = await openAsBlob(archivePath);
const zip = new ZipReader(new BlobReader(archive), {useWebWorkers: false});
let database;
try {
    const entries = await zip.getEntries();
    const index = JSON.parse(await entries.find((entry) => entry.filename === 'index.json').getData(new TextWriter(), {useWebWorkers: false}));
    assert.equal(index.title, fixture.expectedTitle);
    assert.equal(index.revision, fixture.revision);
    const banks = entries.filter((entry) => /^term_bank_\d+\.json$/.test(entry.filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)));
    const totalBytes = banks.reduce((total, bank) => total + bank.uncompressedSize, 0);
    const groupCount = Math.min(banks.length, Math.max(3 * 4, Math.ceil(totalBytes / (24 * 1024 * 1024))));
    const groups = [];
    let start = 0;
    let consumed = 0;
    for (let groupIndex = 0; groupIndex < groupCount - 1; ++groupIndex) {
        const remaining = groupCount - groupIndex;
        const target = (totalBytes - consumed) / remaining;
        let end = start + 1;
        let bytes = banks[start].uncompressedSize;
        const maxEnd = banks.length - remaining + 1;
        while (end < maxEnd) {
            const next = bytes + banks[end].uncompressedSize;
            if (Math.abs(next - target) > Math.abs(bytes - target)) { break; }
            bytes = next;
            ++end;
        }
        groups.push(banks.slice(start, end));
        start = end;
        consumed += bytes;
    }
    groups.push(banks.slice(start));
    await parseRequest({type: 'initialize', module: await WebAssembly.compile(await readFile(path.join(sourceRoot, 'ext/lib/term-bank-parser.wasm')))});
    await api.initializeTermContentZstd();
    assert.equal(codecWorkers.length, 4);
    await Promise.all(codecWorkers.map((worker) => worker.ready));
    await compileCanonicalScanModule();
    database = new DictionaryDatabase();
    database.setImportOptimizationFlags({termContentStorageMode: 'raw-bytes', queueTermContentWrites: true, rawTermBankSourceBytes: totalBytes});
    database._bulkImportTransactionOpen = true;
    database._deferTermsVirtualTableSync = true;
    database._termContentZstdInitialized = true;
    await database._termContentStore.prepare();
    await database._termRecordStore.prepare();
    await database._termContentStore.beginImportSession();
    await database._termRecordStore.beginImportSession();
    database._termContentBlockImportSession = database._termContentBlockStore.beginImportSession();
    const payloads = new RawZipPayloadReader(archive);
    const options = {copyContentBytes: false, includeContentMetadata: true, initialContentBytesPerRow: 48, minimalDecode: true, reuseExpressionForReadingDecode: true, preallocateChunkRows: true, skipTagRuleDecode: false, lazyGlossaryDecode: true, mediaHintFastScan: false, projectImagePaths: false, validateGlossaryTypes: true, computeContentHashes: true, emitContentSlab: true, emitTokenBinaryContent: true, emitTermByteLists: false, prepareLookupIndexes: true, prepareLookupRoute: totalBytes >= 128 * 1024 * 1024, ownContentBytes: false};
    const groupResults = [];
    let rows = 0;
    let estimatedRows = 0;
    for (currentGroup = 0; currentGroup < groups.length; ++currentGroup) {
        const group = groups[currentGroup];
        const sourceBuffers = [];
        for (const bank of group) {
            const bytes = await payloads.read(bank, new AbortController().signal);
            sourceBuffers.push(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
        }
        const parsed = await parseRequest({type: 'parse', id: currentGroup, version: 3, sourceBuffers, sourceMetadata: group.map(({filename, compressedSize, uncompressedSize, compressionMethod, signature}) => ({filename, compressedSize, uncompressedSize, compressionMethod, signature})), chunkSize: 8192, options});
        const chunk = parsed.chunk;
        parsed.chunk = null;
        assert(chunk);
        assert.equal(chunk.rowCount, parsed.rowCount);
        // Exact receipt established by runParallelParserJob in the real parent.
        const ownsContentBytes = parsed.ownsContentBytes === true && parsed.borrowsWorkerMemory !== true && registerOwnedTermContent(chunk?.contentBytesBuffer);
        assert.equal(ownsContentBytes, true, 'Every JMdict result must carry its actual owned content receipt');
        assert.equal(chunk.useResolvedContentReferences, true);
        assert.equal(typeof chunk.releaseBorrowedContent, 'undefined');
        assert(chunk.preparedLookupIndexes instanceof Map);
        const {mediaRows, ...columnPayload} = chunk;
        assert.equal(mediaRows.length, 0);
        const groupBytes = group.reduce((sum, bank) => sum + bank.uncompressedSize, 0);
        if (currentGroup === 0) { estimatedRows = Math.max(chunk.rowCount, Math.round(chunk.rowCount * totalBytes / groupBytes)); }
        rows += chunk.rowCount;
        const payload = {...columnPayload, dictionary: index.title, dictionaryTotalRows: currentGroup + 1 === groups.length ? rows : Math.max(rows, estimatedRows), contentDictNameList: null, uniformContentDictName: RAW_TERM_CONTENT_TOKEN_DICT_NAME};
        await database.bulkAddArtifactTermsChunk(payload);
        assert(pendingCapture);
        const {source, offsets, lengths, starts, blocks} = pendingCapture;
        pendingCapture = null;
        let lower = source.byteLength;
        let upper = 0;
        for (let index = 0; index < offsets.length; ++index) {
            lower = Math.min(lower, offsets[index]);
            upper = Math.max(upper, offsets[index] + lengths[index]);
        }
        lower -= lower % 8;
        const expectedCapture = oracle.captures[currentGroup];
        assert.equal(sha(source.subarray(lower, upper)), expectedCapture.sourceSha256);
        const columns = [Uint32Array.from(offsets, (offset) => offset - lower), lengths, starts, blocks];
        const descriptorHash = createHash('sha256');
        for (const column of columns) { descriptorHash.update(new Uint8Array(column.buffer, column.byteOffset, column.byteLength)); }
        assert.equal(descriptorHash.digest('hex'), expectedCapture.descriptorSha256);
        captures.at(-1).sourceAndDescriptorParity = true;
        const metrics = {...database._lastBulkAddTermsMetrics};
        assert.equal(metrics.dedupRecentSourceAdoptedBytes, expectedAdoptedBytes[currentGroup], `Owned source adoption differs in group ${currentGroup}`);
        assert.equal(metrics.dedupNativeFallbackCount, 0);
        groupResults.push({index: currentGroup, banks: group.map(({filename}) => filename), rows: chunk.rowCount, ownsContentBytes, borrowsWorkerMemory: parsed.borrowsWorkerMemory, registeredSourceBytes: chunk.contentBytesBuffer.byteLength, receivedSourceByteOffsetModulo8: chunk.contentBytesBuffer.byteOffset % 8, useResolvedContentReferences: chunk.useResolvedContentReferences, metrics});
        await writeFile(path.join(output, 'checkpoint.json'), JSON.stringify({groupResults, compressionRequests, compressionReplies, sourceConsumedReplies}));
        process.stderr.write(`Captured checksum inputs from JMdict group ${currentGroup + 1}/${groups.length}\n`);
    }
    assert.equal(rows, fixture.termRows);
    database._termContentBlockImportSession.close();
    database._termContentBlockImportSession = null;
    await Promise.all([database._termContentStore.endImportSession(), database._termRecordStore.endImportSession()]);
    assert.deepEqual(await identity(), initialIdentity);
    assert(captures.length > 0);
    assert.equal(captures.length, oracle.captures.length);
    for (let index = 0; index < captures.length; ++index) {
        assert.equal(captures[index].group, oracle.captures[index].group);
        assert.equal(captures[index].spanCount, oracle.captures[index].spanCount);
        assert.deepEqual(captures[index].blockLengths, oracle.captures[index].blockLengths);
    }
    const expectedHashes = oracle.captures.flatMap((capture) => capture.expectedBlockHashes);
    assert.equal(requestOrder.length, expectedHashes.length);
    for (let index = 0; index < requestOrder.length; ++index) { assert.equal(sha(new Uint8Array(completedBlocks.get(requestOrder[index].id))), expectedHashes[index], `Native block mismatch: ${index}`); }
    assert.equal(sourceConsumedReplies, compressionRequests);
    assert.equal(compressionRequests, compressionReplies);
    assert.equal(compressionRequests, captures.reduce((total, capture) => total + capture.blockLengths.length, 0));
    const checksumInputs = [];
    for (let index = 0; index < checksumPayloads.length; ++index) {
        const {bytes, ...metadata} = checksumPayloads[index];
        const file = `checksum-${index}.bin`;
        await writeFile(path.join(output, file), bytes);
        checksumInputs.push({...metadata, file, sha256: sha(bytes)});
    }
    const report = {schemaVersion: 1, boundary: 'Capture only: actual unchanged public database sink with owned parser receipt and four native codec workers. Each checksum input is snapshotted after the original writer computes its persisted checksum. No timing claim.', sourceRoot, sourceCommit, sourceDiffSha256: sha(sourceDiff), sourceIdentity: initialIdentity, fixtureSha256: fixture.sha256, lockSha256: sha(lockBytes), scriptSha256: sha(await readFile(new URL(import.meta.url))), oracleSha256: sha(oracleBytes), node: process.version, execArgv: process.execArgv, rows, totalBytes, parserWorkersPolicy: 3, compressionWorkers: codecWorkers.length, compressionRequests, compressionReplies, sourceConsumedReplies, groupResults, captures, requestOrder, sourceOwnershipCorrection: 'Unlike the old capture adapter, apply the exact real-parent owned-content registration before the public sink; every group must adopt the expected source span. Old capture cache timing/copy counters are not production attribution.', checksumInputs};
    await writeFile(path.join(output, 'capture.json'), JSON.stringify(report, null, 2));
    console.log(JSON.stringify({rows, groups: groups.length, captures: captures.length, compressionRequests, ownedReceipts: groupResults.filter((group) => group.ownsContentBytes).length, adoptedBytes: groupResults.reduce((total, group) => total + group.metrics.dedupRecentSourceAdoptedBytes, 0), nativeByteParity: true, checksumInputs: checksumInputs.length, checksumBytes: checksumInputs.reduce((total, input) => total + input.byteLength, 0), alignedEligibleBytes: checksumInputs.reduce((total, input) => total + (input.byteLength >= 1024 && input.byteOffsetModulo4 === 0 ? input.byteLength : 0), 0)}));
} catch (error) {
    await writeFile(path.join(output, 'failure.json'), JSON.stringify({error: String(error?.stack ?? error), group: currentGroup, compressionRequests, compressionReplies, sourceConsumedReplies, checksumInputs: checksumPayloads.length, sourceIdentity: initialIdentity, scriptSha256: sha(await readFile(new URL(import.meta.url)))}, null, 2));
    throw error;
} finally {
    for (const worker of codecWorkers) { worker.terminate(); }
    await Promise.all(codecWorkers.map((worker) => worker.termination));
    database?._termContentBlockImportSession?.close();
    await zip.close();
    await env.dispose();
}
