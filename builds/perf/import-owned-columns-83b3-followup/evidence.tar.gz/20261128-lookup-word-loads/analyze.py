#!/usr/bin/env python3
"""Analyze complete fixed cold/warm checksum cohorts without running code."""

import hashlib
import json
import pathlib
import statistics
import sys


def summarize(values):
    return {
        "n": len(values),
        "mean": statistics.mean(values),
        "median": statistics.median(values),
        "min": min(values),
        "max": max(values),
        "stdev": statistics.stdev(values),
    }


path = pathlib.Path(sys.argv[1]).resolve()
raw = path.read_bytes()
result = json.loads(raw)
records = result["records"]
assert result["complete"] and len(records) == 36
assert all(record["exitCode"] == 0 and record["signal"] is None for record in records)
assert all(record["result"]["exactHashesPassed"] == 36 for record in records)
analysis = {
    "resultsSha256": hashlib.sha256(raw).hexdigest(),
    "analysisScriptSha256": hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
    "interpretation": "Whole-corpus elapsed milliseconds; cold and warm are separate conditions. All rounds and outliers retained. The cold helper pass is the sole warmup. No whole-import or hardware-cache-cold claim.",
    "conditions": {},
}
for condition in ("cold", "warm"):
    arms = {
        arm: [record["result"][condition]["elapsedMs"] for record in records if record["arm"] == arm]
        for arm in "ABC"
    }
    pairs = []
    for round_index in range(12):
        values = {
            record["arm"]: record["result"][condition]["elapsedMs"]
            for record in records if record["round"] == round_index
        }
        a, b, c = (values[arm] for arm in "ABC")
        pairs.append({
            "round": round_index,
            "order": result["protocol"]["orders"][round_index],
            "A": a, "B": b, "C": c,
            "BminusControlMean": b - (a + c) / 2,
            "BpercentVsControlMean": 100 * (b / ((a + c) / 2) - 1),
            "BminusA": b - a,
            "CminusA": c - a,
            "BbeatsBoth": b < a and b < c,
        })
    analysis["conditions"][condition] = {
        "arms": {arm: summarize(values) for arm, values in arms.items()},
        "paired": {
            key: summarize([pair[key] for pair in pairs])
            for key in ("BminusControlMean", "BpercentVsControlMean", "BminusA", "CminusA")
        },
        "candidateBeatsBoth": sum(pair["BbeatsBoth"] for pair in pairs),
        "candidateFasterThanControlMean": sum(pair["BminusControlMean"] < 0 for pair in pairs),
        "pairs": pairs,
    }
path.with_name("analysis.json").write_text(json.dumps(analysis, indent=2) + "\n")
print(json.dumps({condition: {
    "pairedMedianMs": values["paired"]["BminusControlMean"]["median"],
    "pairedMedianPercent": values["paired"]["BpercentVsControlMean"]["median"],
    "candidateBeatsBoth": values["candidateBeatsBoth"],
} for condition, values in analysis["conditions"].items()}))
