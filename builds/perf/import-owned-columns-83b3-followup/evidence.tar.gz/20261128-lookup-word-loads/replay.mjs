// One fixed cold/warm scalar-checksum screen; no adaptive rounds or variants.
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {mkdir, readFile, writeFile} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath, pathToFileURL} from 'node:url';
import {performance} from 'node:perf_hooks';

assert.equal(process.version, 'v22.22.0');
const runnerPath = fileURLToPath(import.meta.url);
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex');
const modulePath = 'ext/js/dictionary/term-key-hash.js';
const orders = ['ABC', 'BCA', 'CAB', 'ACB', 'CBA', 'BAC', 'ABC', 'BCA', 'CAB', 'ACB', 'CBA', 'BAC'];
const childExecArgv = ['--max-old-space-size=256'];

function hostSnapshot() {
    return {
        timestamp: new Date().toISOString(),
        platform: process.platform,
        architecture: process.arch,
        release: os.release(),
        cpuModel: os.cpus()[0]?.model,
        logicalCpus: os.cpus().length,
        availableParallelism: os.availableParallelism(),
        loadAverage: os.loadavg(),
        freeMemory: os.freemem(),
        totalMemory: os.totalmem(),
        processMemory: process.memoryUsage(),
        processResourceUsage: process.resourceUsage(),
    };
}

async function readCapture(directory, expectedHash) {
    const bytes = await readFile(path.join(directory, 'capture.json'));
    if (expectedHash) { assert.equal(sha(bytes), expectedHash); }
    const capture = JSON.parse(bytes);
    assert.equal(capture.rows, 528299);
    assert.equal(capture.checksumInputs.length, 36);
    assert.equal(capture.checksumInputs.reduce((total, input) => total + input.byteLength, 0), 23748240);
    return {bytes, capture};
}

async function verifyInputFiles(directory, inputs) {
    for (const input of inputs) {
        assert.equal(path.basename(input.file), input.file);
        const bytes = await readFile(path.join(directory, input.file));
        assert.equal(bytes.byteLength, input.byteLength);
        assert.equal(sha(bytes), input.sha256);
    }
}

async function loadInputs(directory, descriptions) {
    const lookupBackings = new Map();
    for (const description of descriptions) {
        assert.equal(description.shared, false, 'Captured JMdict writer inputs use ordinary buffers');
        assert.equal(description.byteOffset % 4, description.byteOffsetModulo4);
        if (description.role === 'recordFields') { continue; }
        const existing = lookupBackings.get(description.group) ?? 0;
        lookupBackings.set(description.group, Math.max(existing, description.byteOffset + description.byteLength));
    }
    for (const [group, length] of lookupBackings) { lookupBackings.set(group, new ArrayBuffer(length)); }
    const result = [];
    for (const description of descriptions) {
        const source = await readFile(path.join(directory, description.file));
        assert.equal(source.byteLength, description.byteLength);
        assert.equal(sha(source), description.sha256);
        const backing = description.role === 'recordFields' ?
            new ArrayBuffer(description.byteOffset + description.byteLength) :
            lookupBackings.get(description.group);
        const bytes = new Uint8Array(backing, description.byteOffset, description.byteLength);
        bytes.set(source);
        result.push({...description, bytes});
    }
    for (const group of new Set(result.map((input) => input.group))) {
        const entries = result.filter((input) => input.group === group);
        assert.deepEqual(entries.map((input) => input.role), ['base', 'derived', 'recordFields']);
        assert.equal(entries[0].bytes.buffer, entries[1].bytes.buffer);
        assert.notEqual(entries[0].bytes.buffer, entries[2].bytes.buffer);
    }
    return result;
}

function measure(hash, inputs) {
    const hashes = new Uint32Array(inputs.length);
    const spans = new Float64Array(inputs.length);
    const cpuBefore = process.cpuUsage();
    const before = performance.now();
    for (let index = 0; index < inputs.length; ++index) {
        const spanBefore = performance.now();
        const value = hash(inputs[index].bytes);
        const spanAfter = performance.now();
        hashes[index] = value;
        spans[index] = spanAfter - spanBefore;
    }
    const elapsedMs = performance.now() - before;
    const cpu = process.cpuUsage(cpuBefore);
    // Every assertion, report allocation and checksum comparison is outside timers.
    for (let index = 0; index < inputs.length; ++index) { assert.equal(hashes[index], inputs[index].expectedHash); }
    return {
        elapsedMs,
        cpuUserMs: cpu.user / 1000,
        cpuSystemMs: cpu.system / 1000,
        spans: inputs.map((input, index) => ({index, group: input.group, role: input.role, bytes: input.byteLength, elapsedMs: spans[index], hash: hashes[index]})),
    };
}

async function child(config) {
    assert.deepEqual(process.execArgv, childExecArgv);
    const {capture} = await readCapture(config.captureDirectory, config.captureSha256);
    const source = await readFile(config.sourcePath);
    assert.equal(sha(source), config.sourceSha256);
    const inputs = await loadInputs(config.captureDirectory, capture.checksumInputs);
    const {hashTermKeyBytes} = await import(pathToFileURL(config.sourcePath).href);
    const before = hostSnapshot();
    // The helper has not been called in this fresh child before the cold pass.
    // That recorded cold pass is the sole warmup for the next recorded pass.
    const cold = measure(hashTermKeyBytes, inputs);
    const warm = measure(hashTermKeyBytes, inputs);
    const after = hostSnapshot();
    for (const input of inputs) { assert.equal(sha(input.bytes), input.sha256); }
    assert.equal(sha(await readFile(config.sourcePath)), config.sourceSha256);
    assert.equal(sha(await readFile(runnerPath)), config.runnerSha256);
    process.stdout.write(JSON.stringify({schemaVersion: 1, arm: config.arm, round: config.round, sourceSha256: config.sourceSha256, captureSha256: config.captureSha256, runnerSha256: config.runnerSha256, node: process.version, execArgv: process.execArgv, before, cold, warm, after, exactHashesPassed: inputs.length}));
}

async function runChild(config) {
    return await new Promise((resolve, reject) => {
        const processChild = spawn(process.execPath, [...childExecArgv, runnerPath, '--child', JSON.stringify(config)], {stdio: ['ignore', 'pipe', 'pipe']});
        let stdout = '';
        let stderr = '';
        processChild.stdout.setEncoding('utf8');
        processChild.stderr.setEncoding('utf8');
        processChild.stdout.on('data', (text) => { stdout += text; });
        processChild.stderr.on('data', (text) => { stderr += text; });
        processChild.on('error', reject);
        processChild.on('close', (exitCode, signal) => {
            let result = null;
            let parseError = null;
            try { result = JSON.parse(stdout); } catch (error) { parseError = String(error); }
            resolve({exitCode, signal, stderr, stdoutOnFailure: exitCode === 0 ? null : stdout, parseError, result});
        });
    });
}

async function parent() {
    const [baselineRoot, candidateRoot, captureInput, outputInput] = process.argv.slice(2).map((value) => path.resolve(value));
    const captureDirectory = captureInput;
    const outputDirectory = outputInput;
    const {bytes: captureBytes, capture} = await readCapture(captureDirectory);
    const captureSha256 = sha(captureBytes);
    const runnerSha256 = sha(await readFile(runnerPath));
    const baselineSourcePath = path.join(baselineRoot, modulePath);
    const candidateSourcePath = path.join(candidateRoot, modulePath);
    const baselineSha256 = sha(await readFile(baselineSourcePath));
    const candidateSha256 = sha(await readFile(candidateSourcePath));
    assert.equal(baselineSha256, capture.sourceIdentity[modulePath]);
    assert.notEqual(candidateSha256, baselineSha256);
    await verifyInputFiles(captureDirectory, capture.checksumInputs);
    const arms = {
        A: {sourcePath: baselineSourcePath, sourceSha256: baselineSha256},
        B: {sourcePath: candidateSourcePath, sourceSha256: candidateSha256},
        C: {sourcePath: baselineSourcePath, sourceSha256: baselineSha256},
    };
    await mkdir(outputDirectory);
    const protocol = {
        schemaVersion: 1,
        boundary: 'Node scalar helper component only; fresh-child first-call/JIT cold and warmed conditions reported separately. Initialization excluded. Not hardware-cache cold or browser import timing.',
        rounds: orders.length,
        orders,
        arms,
        node: process.version,
        parentExecArgv: process.execArgv,
        childExecArgv,
        runnerSha256,
        captureDirectory,
        captureSha256,
        captureScriptSha256: capture.scriptSha256,
        corpusCalls: capture.checksumInputs.length,
        corpusBytes: capture.checksumInputs.reduce((sum, input) => sum + input.byteLength, 0),
        eligibleCalls: capture.checksumInputs.filter((input) => input.byteLength >= 1024 && input.byteOffsetModulo4 === 0).length,
        eligibleBytes: capture.checksumInputs.reduce((sum, input) => sum + (input.byteLength >= 1024 && input.byteOffsetModulo4 === 0 ? input.byteLength : 0), 0),
        inputs: capture.checksumInputs,
        passes: ['One complete first helper pass (cold); retained as primary condition and sole warmup', 'One complete warmed helper pass'],
        invariants: ['36 original writer inputs in original base/derived/record-fields order', 'Original byteOffsets; base and derived retain one backing per writer chunk; fields use a separate backing', 'All 36 persisted checksum values and every input SHA checked outside intervals', 'A and C use identical source in separate fresh children', 'Whole-corpus totals are primary; per-span role observations retained without pooling unequal medians', 'No adaptive repetitions, variants, outlier removal or chosen subruns'],
        before: hostSnapshot(),
    };
    await writeFile(path.join(outputDirectory, 'protocol.json'), JSON.stringify(protocol, null, 2));
    const records = [];
    try {
        for (let round = 0; round < orders.length; ++round) {
            for (const arm of orders[round]) {
                const result = await runChild({round, arm, captureDirectory, captureSha256, runnerSha256, ...arms[arm]});
                records.push({round, order: orders[round], arm, ...result});
                await writeFile(path.join(outputDirectory, 'checkpoint.json'), JSON.stringify({protocol, records}, null, 2));
                assert.equal(result.exitCode, 0, `Child ${round}/${arm} exited: ${result.stderr}`);
                assert.equal(result.signal, null);
                assert.equal(result.parseError, null);
                assert.equal(result.result.exactHashesPassed, 36);
            }
            process.stderr.write(`Completed fixed checksum round ${round + 1}/${orders.length}\n`);
        }
        await verifyInputFiles(captureDirectory, capture.checksumInputs);
        assert.equal(sha(await readFile(baselineSourcePath)), baselineSha256);
        assert.equal(sha(await readFile(candidateSourcePath)), candidateSha256);
        assert.equal(sha(await readFile(runnerPath)), runnerSha256);
        await writeFile(path.join(outputDirectory, 'results.json'), JSON.stringify({protocol, records, complete: true, after: hostSnapshot()}, null, 2));
        process.stdout.write(JSON.stringify({rounds: orders.length, children: records.length, coldCorpora: records.length, warmCorpora: records.length, exactHashesPassed: records.length * 2 * capture.checksumInputs.length, captureSha256, runnerSha256}));
    } catch (error) {
        await writeFile(path.join(outputDirectory, 'failure.json'), JSON.stringify({error: String(error?.stack ?? error), protocol, records, after: hostSnapshot()}, null, 2));
        throw error;
    }
}

if (process.argv[2] === '--child') {
    await child(JSON.parse(process.argv[3]));
} else {
    await parent();
}
