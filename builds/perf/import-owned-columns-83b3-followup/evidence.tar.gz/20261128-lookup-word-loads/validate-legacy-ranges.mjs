// Differential check of existing invalid-range behavior outside all timing.
import assert from 'node:assert/strict';
import path from 'node:path';
import {pathToFileURL} from 'node:url';

const file = 'ext/js/dictionary/term-key-hash.js';
const {hashTermKeyByteRange: baseline} = await import(pathToFileURL(path.resolve(process.argv[2], file)).href);
const {hashTermKeyByteRange: candidate} = await import(pathToFileURL(path.resolve(process.argv[3], file)).href);
const ranges = [[-1, 1024], [0, 1100], [0, 1024.5], [0.5, 1030], [20, 10], [0, NaN], [NaN, 1030], [-0.5, 1040]];
let count = 0;
for (const shared of [false, true]) {
    for (const offset of [0, 1, 3, 7]) {
        const buffer = shared ? new SharedArrayBuffer(1057 + offset) : new ArrayBuffer(1057 + offset);
        const bytes = new Uint8Array(buffer, offset);
        for (let index = 0; index < bytes.length; ++index) { bytes[index] = index * 131; }
        for (const [start, end] of ranges) {
            assert.equal(candidate(bytes, start, end), baseline(bytes, start, end));
            ++count;
        }
    }
}
console.log(JSON.stringify({legacyInvalidRangeDifferentialCases: count, passed: true}));
