#!/usr/bin/env python3
"""Verify a manifest-backed evidence bundle without running an experiment."""

import hashlib
import json
import pathlib
import re
import sys


manifest_path = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "manifest.json").resolve()
manifest = json.loads(manifest_path.read_text())
base = manifest_path.parent.parent
total = 0
for entry in manifest["files"]:
    relative = pathlib.PurePosixPath(entry["path"])
    assert not relative.is_absolute() and ".." not in relative.parts
    path = base.joinpath(*relative.parts)
    size = path.stat().st_size
    assert size == entry["bytes"], (entry["path"], "size")
    sha256 = hashlib.sha256()
    blob = hashlib.sha1(b"blob " + str(size).encode("ascii") + b"\0")
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            sha256.update(chunk)
            blob.update(chunk)
    assert sha256.hexdigest() == entry["sha256"], (entry["path"], "sha256")
    assert blob.hexdigest() == entry["gitBlobSha"], (entry["path"], "git blob")
    if path.suffix == ".md":
        text = path.read_text()
        for target in re.findall(r"\]\(([^)]+)\)", text):
            if "://" in target or target.startswith("#"):
                continue
            target = target.split("#", 1)[0]
            assert (path.parent / target).exists(), (entry["path"], "missing link", target)
    total += size
assert total == manifest["payloadTotalBytes"]
print(json.dumps({"files": len(manifest["files"]), "payloadBytes": total,
                  "sha256Passed": True, "gitBlobShaPassed": True,
                  "relativeLinksPassed": True, "experimentExecution": False}))
