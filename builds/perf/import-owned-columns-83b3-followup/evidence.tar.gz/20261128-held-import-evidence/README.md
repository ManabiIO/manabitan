# Held import experiments and corrected sink diagnostic

This is an evidence bundle for two completed experiments and one CPU diagnostic
against develop `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`.
**Neither runtime candidate was promoted.** The material is retained so future
work can reuse the controls, exact inputs, failure receipts and source review.
It contains no proposed change to the separate ownership PR's runtime.

## Results and boundaries

| Study | Result | Measurement boundary |
| --- | --- | --- |
| [Compression request batching](../20261128-compression-request-batches/README.md) | HOLD: 103 requests became 48, but the fixed controls did not establish a useful latency gain. | Warmed actual Node codec-worker component; initialization and one whole-corpus warmup excluded. |
| [Aligned lookup checksum reader](../20261128-lookup-word-loads/README.md) | HOLD: cold paired median −0.0366 ms; warmed paired median +0.6591 ms, with broader identical-code variation. | Fresh-child first helper pass and one warmed pass, reported separately; materialized input, not hardware-cache-cold or browser timing. |
| [Corrected canonical sink profile](../20261128-canonical-sink-profile/README.md) | Diagnostic attribution only; existing owned-content registration removes the earlier adapter's extra cache copy. | Main public sink calls plus four separately profiled native codec workers, with explicit Node storage and scheduling adapters. |

The [metadata/record review](../20261128-canonical-sink-profile/metadata-record-screen.md)
explains the publisher/cache source-position attribution correction and existing
work. The [cache-origin screen](../20261128-canonical-sink-profile/cache-origin-screen.md)
was declined before implementation. The
[inflater source screen](../20261128-canonical-sink-profile/inflater-source-screen.md)
identified no new independently grounded decoder change. These reviews added
no timing observations.

## One explicit local/public path mapping

Each `path` in `manifest.json` is relative to the parent of this directory;
`absoluteLocalPath` identifies the existing workspace file. Preserve the
following sibling layout under the chosen publication prefix or within a
compact evidence archive. The relative Markdown links work in that expanded
layout. If only an archive is published, its internal links require extraction;
they do not imply individual files are visible on GitHub. No report is silently
relocated from `cohort-1` to an `evidence` directory.

| Relative directory | Local source under `manabitan/builds/perf/` | Contents |
| --- | --- | --- |
| `20261128-held-import-evidence/` | Same name | This index, verifier and manifest. |
| `20261128-compression-request-batches/` | Same name | Reports in `cohort-1/`; capture, scripts, validation and patches at the directory root. |
| `20261128-canonical-sink-profile/` | Same name | Raw receipt, CPU profiles and attribution in `run-1/`; all three source-screen notes at the root. |
| `20261128-lookup-word-loads/` | Same name | Reports, exact input archive and validation in `evidence/`; scripts at the root. |

The new batching
[prototype-and-tests.patch](../20261128-compression-request-batches/prototype-and-tests.patch)
contains exactly two runtime files and three test files against the pinned base.
The original initial, tested and complete patches remain unchanged.
`prototype-complete.patch` additionally includes the capture/replay scripts.
The checksum [runtime patch](../20261128-lookup-word-loads/evidence/prototype.patch)
is also retained as evidence, not an active product change.

The 36 exact checksum inputs appear once in
[inputs.tar.gz](../20261128-lookup-word-loads/evidence/inputs.tar.gz), with the
[archive receipt](../20261128-lookup-word-loads/evidence/input-archive.json) and
[individual input identities](../20261128-lookup-word-loads/evidence/capture.json).
The manifest references the existing 11 MB archive directly. No new worktree,
copy or recompression is needed for integration, and its existing Git blob can
be reused when publishing.

## Preservation and reproduction

The manifest records each file's relative and absolute local paths, byte length,
SHA-256 and Git blob SHA, alongside source/candidate identities and the checks
performed during integration. Run `python3 verify-bundle.py manifest.json` from
this directory to
check the listed files without executing an experiment. The manifest excludes
its own bytes to avoid a self-hash cycle; its identity is reported separately
in the handoff.

Raw JSON retains the original absolute execution paths and source hashes. Those
paths are historical provenance, not public link destinations. Reproduction
scripts accept checkout/output paths as documented in each study. The preserved
canonical analyzer uses the source root recorded in the historical receipt for
its pinned WASM export proof; rerunning the diagnostic in another checkout
records the new root. The native name proof is included
[here](../20261128-canonical-sink-profile/provenance/native-symbol-proof.json).

Original compression source/descriptor staging was reclaimed only after the
negative cohort and corrected diagnostic completed. Its manifest, all hashes,
native frame oracles, original script and
[reclamation receipt](../20261128-compression-request-batches/staging-reclaimed.json)
remain. Regenerate that staging from the unchanged capture script and locked
dictionary fixture before replaying it. The checksum inputs remain archived
exactly and need not be regenerated to review their cohort.

## Failures and checks

The original [batch validation receipt](../20261128-compression-request-batches/validation.json)
retains the unexpected Vitest worker exit and the subsequent isolated native
case pass. It is not relabeled as a clean full-suite pass. The
[checksum validation receipt](../20261128-lookup-word-loads/evidence/validation.json)
retains the unsupported CLI flag, sparse-checkout lint setup failures and final
ESLint exit 137. No source violation was reported before that process was
killed; lint is incomplete. Standalone complete console logs for those early
test/lint failures were not archived at execution time, so this bundle retains
their original recorded receipts rather than inventing a reconstruction.

All original cohort observations, orderings, controls, outliers, checkpoints
and child stderr/exit statuses that were captured are included unchanged. There
were no failed timing attempts in either completed fixed cohort. Full unit,
build and browser qualification were not run for these held runtime variants.

Integration performs only relative-link existence, whitespace, artifact/source
identity and patch-application checks. It adds no timing runs, tests, performance
claims or runtime promotion. Publication of this evidence is separate from
qualification or promotion of a runtime candidate.
