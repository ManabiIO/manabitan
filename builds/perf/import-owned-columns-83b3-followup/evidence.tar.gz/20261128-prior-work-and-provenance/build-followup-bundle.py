#!/usr/bin/env python3
"""Package existing import evidence without executing any experiment."""

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile


def identity(data):
    return {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "gitBlobSha": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    }


def encode(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    perf = workspace / "manabitan/builds/perf"
    out = args.out.resolve()
    sources = {}

    def add(path, source):
        relative = PurePosixPath(path)
        assert not relative.is_absolute() and ".." not in relative.parts
        assert path not in sources, path
        assert source.is_file() and not source.is_symlink(), source
        sources[path] = source

    held_path = perf / "20261128-held-import-evidence/manifest.json"
    held = json.loads(held_path.read_text())
    for item in held["files"]:
        source = Path(item["absoluteLocalPath"])
        found = identity(source.read_bytes())
        assert all(found[key] == item[key] for key in found), item["path"]
        add(item["path"], source)
    add("20261128-held-import-evidence/manifest.json", held_path)

    for root in (
        "20261128-native-symbols-83b3",
        "20261128-compressed-worker-profile-83b3",
        "import-owned-columns-83b3-analysis-source",
    ):
        for source in sorted((perf / root).rglob("*")):
            if source.is_file() and "__pycache__" not in source.parts and source.suffix != ".pyc":
                add(str(source.relative_to(perf)), source)

    for name in (
        "prior-work-audit-20261128.md",
        "zstd-export-map-20261128.py",
        "zstd-export-map-20261128.json",
        "reclaimed-fixture-cache-20261128.json",
        "JMdict-source-index.json",
        "build-followup-bundle.py",
    ):
        add("20261128-prior-work-and-provenance/" + name, workspace / "qualification-draft" / name)

    add("README.md", out / "README.md")
    add("verify-archive.py", out / "verify-archive.py")
    files = [{"path": path, **identity(source.read_bytes())} for path, source in sorted(sources.items())]
    contents = {
        "schemaVersion": 1,
        "repository": "ManabiIO/manabitan",
        "sourceCommit": "9e10d3b3fcf66d344ab31bc42c9b522fa5215da2",
        "ownershipCandidateCommit": "f65f4ef97ebf2f37a5b1b79ca7733d7b362ec963",
        "kind": "evidence-only-import-followup",
        "experimentExecutionDuringPackaging": False,
        "contentsSelfExcluded": True,
        "fileCount": len(files),
        "totalBytes": sum(item["bytes"] for item in files),
        "files": files,
    }
    contents_data = encode(contents)
    out.mkdir(parents=True, exist_ok=True)
    archive_path = out / "evidence.tar.gz"
    with archive_path.open("wb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for path, source in sorted(sources.items()):
                    data = source.read_bytes()
                    expected = next(item for item in files if item["path"] == path)
                    assert identity(data)["sha256"] == expected["sha256"], (path, "changed during packaging")
                    member = tarfile.TarInfo(path)
                    member.size = len(data)
                    member.mode = 0o644
                    archive.addfile(member, io.BytesIO(data))
                member = tarfile.TarInfo("CONTENTS.json")
                member.size = len(contents_data)
                member.mode = 0o644
                archive.addfile(member, io.BytesIO(contents_data))
    manifest = {
        **contents,
        "archive": {"path": "evidence.tar.gz", **identity(archive_path.read_bytes())},
        "embeddedContents": {"path": "CONTENTS.json", **identity(contents_data)},
    }
    (out / "manifest.json").write_bytes(encode(manifest))
    print(json.dumps({"fileCount": len(files), "payloadBytes": contents["totalBytes"], "archive": manifest["archive"]}))


if __name__ == "__main__":
    main()
