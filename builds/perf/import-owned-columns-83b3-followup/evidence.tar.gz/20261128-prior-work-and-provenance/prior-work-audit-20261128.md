# Import optimization ownership and negative evidence audit

Read-only audit against develop `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`, updated 2026-11-28. This is an integration note for the existing experiment handoff, not another acquisition or performance claim. PR state is a snapshot; exact heads below identify the reviewed evidence. Do not pool historical cohorts, component timings, or independently hosted jobs.

## Areas already implemented or owned

| Cost or idea | Existing owner and current inclusion | Evidence and disposition |
| --- | --- | --- |
| Whole native lookup key/length ownership; added compact expression IDs | [#820](https://github.com/ManabiIO/manabitan/pull/820), revised draft head `f65f4ef97ebf2f37a5b1b79ca7733d7b362ec963`; preserves original `8fe5926` ancestry and old HOLD. Not in develop. | Current full-corpus transfer proof removes 251,096,942 cumulative allocation bytes; 30,452,656 are the new expression portion. Keep original key/length work attributed to old #820. Browser speed and sampled peak memory remain unqualified pending the separately queued cohorts. |
| Segmented compact expression IDs | [#939](https://github.com/ManabiIO/manabitan/pull/939), closed original PR, implementation integrated by [#970](https://github.com/ManabiIO/manabitan/pull/970) and present in current source. | Native whole-index corpora normally do not activate segmentation. The existing plan contract intentionally keeps actual reading IDs, not persisted equal-reading sentinels. |
| Independent concurrent whole-column ownership proposal | Branch `perf/owned-whole-lookup-plan-20261128-92c09`, head `9eef39ef86e1fc41d0f6e8ed64fa685d0fc4abbc`; no PR found as of this audit. | Same keys/lengths/expressions and retained-key-arena safeguard, with a one-use callback receipt. [Run 46103716468](https://github.com/ManabiIO/manabitan/actions/runs/46103716468) source verification passed; six browser cells were queued. Its results belong to that source, not #820. |
| Typed in-flight source registration | [#830](https://github.com/ManabiIO/manabitan/pull/830), OPEN draft head `a628c6c7915576dcf280e98bc9129a508f2f9644`; not in develop. | Exact overlap with lifting repeated typed-column checks in `_registerInFlightTermContentSources`. Private origin WeakSet, intrinsic type/private fixed backing checks, shared length identity, strictly increasing safe persisted offsets and per-row bounds. 220 focused tests. Preliminary pre-hardening warmed saving only about 3.7 ms/full historical JMdict; no final-source timing or browser gain. Do not implement another copy. |
| Native publication preflight | [#914](https://github.com/ManabiIO/manabitan/pull/914), OPEN/HOLD head `b273513dab4fa409a0213a2db470e52b4a0f559c`; not in develop. | Distinct from in-flight registration: copies four columns into existing native scratch to validate reservation IDs/state/hash/length. JMdict slower 6/6 against both controls, paired medians +1.471%/+1.724%; no corrective structural defect found. Stop this candidate. |
| Zstd module/dictionary startup overlap | [#938](https://github.com/ManabiIO/manabitan/pull/938), integrated through [#968](https://github.com/ManabiIO/manabitan/pull/968), present in current source. | Already overlaps module and dictionary acquisition. Original JMdict whole-import screen did not establish improvement; old Jitendex/VNDB receipt failures must not be treated as candidate results. |
| Share compiled Zstd module and loaded dictionary with workers | [#974](https://github.com/ManabiIO/manabitan/pull/974), OPEN head `ab00fae7cdf7f32ad5100fd2101f3e7ce7202af1`; not in develop. | Owns 5-to-1 loads of module/dictionary; private instances/heaps/contexts remain. Corrected component cohort shows reduced startup RSS, not established import latency or browser peak memory. Do not duplicate startup sharing. |
| Remove unused decoder context in compression workers / reuse decoder context | [#891](https://github.com/ManabiIO/manabitan/pull/891), [#925](https://github.com/ManabiIO/manabitan/pull/925), [#933](https://github.com/ManabiIO/manabitan/pull/933), integrated/current. | Avoided decoder allocator work is already present; it does not shrink the initial 16.9 MiB linear-memory reservation. |
| Compression gather alignment and recent-source cache copies | [#46](https://github.com/ManabiIO/manabitan/pull/46), [#766](https://github.com/ManabiIO/manabitan/pull/766), [#784](https://github.com/ManabiIO/manabitan/pull/784), [#824](https://github.com/ManabiIO/manabitan/pull/824), current. | These have different ownership boundaries: shared source to private compression/cache destination, intentional owned parser SABs, and immutable slab adoption with complete backing allocation charged. Historical word-width helpers were not consistently better than alignment-only behavior. |
| Earlier borrowed-content release | [#955](https://github.com/ManabiIO/manabitan/pull/955), OPEN head `bc94ee31a5dbfc1b29766cb9dee3a6fe6b54ea54`; not in develop. | Owns replacing in-flight raw source references with pending persistence promises after gather/publication/record preparation. Collision reads then wait for storage. Do not mix into ownership-only #820. |
| Coalesced compression descriptors and reader checksum/copy fusion | [#764](https://github.com/ManabiIO/manabitan/pull/764), OPEN head `1e82e1a237410c5a850661c1c361c444fa624546`; partially superseded by integrated bulk publication. | Already covers descriptor coalescing and checksum verification in native private input. Whole-import screen inconclusive. Reader component used historical 4 MiB blocks, not current 1 MiB settings. |
| Paired native content hash SIMD | [#623](https://github.com/ManabiIO/manabitan/pull/623), MERGED/current, original head `e3b0f39d5d9a5a451ab76ffeabbd0bab33f93ffd`. | Current C already uses dual-seed SIMD for 64–512 B. Unbounded large-input SIMD was explicitly rejected after Chromium regression. Component gains 22–53% in selected range; whole-import claim inconclusive. |
| Fuse long glossary copy and native paired hash | [#840](https://github.com/ManabiIO/manabitan/pull/840), OPEN/HOLD head `44686ef6ebaafa624e6d228494719bbed4cb8ef4`; not in develop. | Owns the >512B case. All 7.613 M rows parity; Node component −8.51%, but Jitendex browser confirmation +1.140%/+1.059% against controls and only 4/12 faster. Do not rediscover it as an unowned gain. |
| Large lookup integrity checksum word reads | [#627](https://github.com/ManabiIO/manabitan/pull/627), MERGED/current, head `b160c766c432ca05b446bf6566d2b691fa24b8fb`. | Current hash path uses little-endian DataView for valid ranges >=1 KiB. Large-hash component improvement 47–65%; full imports mixed. The earlier rejected 234-import study retained in [#73](https://github.com/ManabiIO/manabitan/pull/73) also used DataView, verified by decoding its SHA-checked transport patch. No older exact DataView-to-aligned-Uint32Array comparison was found; the current session tested that distinct idea and rejected it below. |
| Move owned lookup envelope hashing/copy work into I/O worker | [#877](https://github.com/ManabiIO/manabitan/pull/877), OPEN head `1a04064bcc33565537c47f8047dacd03b3e89b24`; not in develop. | Owns transfer of header/payload/record fields into existing ordered worker, with private full-buffer ownership guards and eager fallback. Diagnostic motivation was mainly VNDB, not a proven JMdict win. Do not duplicate the scheduling mechanism while screening scalar loads. |
| Structured glossary parse shortcut | [#972](https://github.com/ManabiIO/manabitan/pull/972), OPEN draft head `32c643f9be41f04a6e824ca40d3a0649da87a050`; not in baseline 9e10. | Owns compact structured-list parsing and validated numeric token ends. The six-pair JMdict screen reports import −9.2 ms, total −9.0 ms and 5/6 total wins: a modest positive candidate worth source/evidence review, not a blanket negative HOLD. No raw-receipt link, same-code drift, interval or independent host replication is supplied in the current PR discussion, so this audit cannot qualify materiality. VNDB import +137.5 ms remains visible. Exact-head CI and functional auxiliary workflows pass; media proof is still explicitly pending. No dedicated running qualification was found at this head. Score/sequence token ends are already ephemeral per-row stack values returned through out-parameters; `TermRowMeta` gains no fields or retained arrays. Moving those values out of persistent metadata therefore offers no new saving. |
| Consecutive closing-container dispatch | [#797](https://github.com/ManabiIO/manabitan/pull/797), OPEN/HOLD head `2663832da942d3ce0ccefb5609ef17b7d0ae9371`; not in develop. | Exact patch validates adjacent `]`/`}` frames inside one loop. 252 successful imports in six separate dictionary/order cohorts did not establish repeatable speedup; JMdict forward B/A −0.188%, reverse +1.190%. Keep the negative/uncertain result and do not reimplement. |
| Child-close followed by adjacent comma | [#892](https://github.com/ManabiIO/manabitan/pull/892), OPEN draft head `b8f6eb5785ac31b71f4b177834b988a15edea370`; not in develop. | Exact six-line change consumes an adjacent comma after restoring the parent, via `advance_glossary_delimiter`; it is distinct from #797. Full Jitendex parity, 99 focused cases and all 15 CI lanes passed. Diagnostic counted 4,115,698 avoided dispatches. Combined browser screen B/A +2.276%, B/C +0.542%, only 2/6 faster each; does not isolate this PR or establish a gain. Root declined a duplicate prototype. |

## Newly considered and declined without source changes

### Persisted Uint16 reading IDs

The main prepared-index encoder, whole-plan validator, and normal storage compactor mask equality flags before reading an ID. That is insufficient to change the general plan representation safely:

- `PreinternedTermRecordPlan` explicitly promises actual reading IDs. `selectTermRecordPreinternedPlan` copies readings into Uint32 without normalization, losing a width-based sentinel marker. `sliceTermRecordPreinternedPlan` currently rejects Uint16 readings.
- Public `compactTermRecordPreinternedPlan` allows omitted equality flags; then it directly indexes `readingIndexes`. A Uint16 `0xffff` sentinel would be an invalid key reference. The builder similarly promises actual IDs, with no equality parameter.
- Generic wider plans can legitimately reference actual key ID 65535. Reinterpreting that value globally would corrupt this case; a separate representation/discriminator and normalization boundary would be needed.
- Native encoder/segment entry points assume four-byte reading pointer arithmetic. If the shared type is widened, explicit Uint32 reading guards are required, just as #939 added expression guards.
- In-memory record materialization requires Uint32 readings in its stable-slice admission. Projected media keys, default copy snapshots and artifact decoding/normalization also use actual reading IDs. They cannot be silently given a sentinel column.

This could be designed as a broader representation change, but it is not a narrow ownership-only follow-up. Root declined another prototype and kept qualifying #820 unchanged. Existing tests already cover compact expression limits, optional-equality compaction, typed subviews, transfer/detachment, malformed plans, materialization with empty fallback lists and builder pre-narrowing validation.

### Parser-owned SharedArrayBuffer copy width

No exact same-capacity shared-destination word-view comparison was found. Root checked Node 22.22 V8 primary source: same-element-kind Uint8/Uint32 `set` routes through the same relaxed memmove by byte count; aligned source/destination uses word copies regardless of view width. Changing view width alone has no established mechanism. Actual offset/alignment was assigned to the native audit; no width-only timing cohort was started.

### Compression request envelopes

The isolated fixed 12-round three-arm component preserved all 36 measurements, 36 warmups and native frame hashes. It reduced 103 requests to 48 but was slower in 9/12 rounds against average identical controls; median +3.15 ms/+4.24%. Dispatch paired median change was only −0.015 ms. Held locally, no publication or additional optional timing.

The original capture adapter omitted the parser-parent owned-content receipt, affecting recent-cache copies outside the timed compression replay. A corrected sink profile was acquired separately; do not turn the earlier component into a full importer claim.

### Tiny score loop restoration

Accepted #944 code was lost during integration. A two-line restoration passes focused validation but saves only about 0.9 ms/full current JMdict record-field replay. No standalone performance PR; excluded from #820.

### Aligned Uint32 lookup-checksum loads

The corrected sink profile attributed material CPU samples to large lookup-integrity hashing. A separate one-file prototype retained the existing >=1 KiB threshold, small-key implementation, unaligned DataView fallback, exact XXH32 algorithm and output. It added a module-level endian probe and used a Uint32 view only for aligned ranges on little-endian hosts.

Capture used the unchanged current public sink, actual parser-owned content receipt and four native codec workers. It saved all 36 writer checksum inputs (23,748,240 bytes) across 12 JMdict groups after the original writer computed the persisted checksum. Every input was eligible. Base/derived sharing and original offsets were preserved in replay. Captured compression inputs, span descriptors and native frames matched the original oracle; owned source adoption was also checked.

The fixed cohort used 12 rounds, all six ABC permutations repeated twice, and one fresh Node 22.22 child for each arm. A and C were identical baseline sources. Each child ran one complete first-helper-pass corpus and one warmed corpus; the first pass was the sole warmup. All 36 children and 2,592 expected checksum values passed, with hashes and assertions outside the measurement intervals. Independent recomputation gave:

| Condition | Median B minus mean(A,C) | Median paired percent | B beats both controls | Unchanged C minus A range |
| --- | ---: | ---: | ---: | ---: |
| First helper pass / JIT cold | −0.036606 ms | −0.181608% | 4/12 | −4.870474 to +9.082049 ms |
| Warmed helper pass | +0.659122 ms | +5.730014% | 3/12 | −4.177491 to +4.269827 ms |

Disposition: no useful gain, no promotion, no extra rounds or variants. This is a helper component with already materialized corpus bytes; it is not hardware-cache-cold, browser timing, whole-import timing or peak memory. Broad controls remain visible. The adverse warmed estimate is not a whole-import regression claim.

Raw results SHA-256: `18402a0ab3af8429d361f444c767ef196b40c3af2198f0f997420bb19e40909e`. Frozen runner SHA-256: `18b7d8591db2c4ceb2b72d3c587729df373fba443dc9d627c81a0a9bf8ae0064`; capture manifest SHA-256: `ff9a1176c67a307401f5b4467299a0201b45df259ab9d9189bcc801e9bc92670`. Local experiment commit `888c444f05fd7290db2be2b37e6acbd44c123ed2` retains the candidate, exact inputs, protocol, reports and controls. The existing 151 independent hash vectors, focused type check and 64 malformed-range differentials passed; the scoped lint attempt was killed with exit 137 and is not called a pass. This unsuccessful experiment remains outside published product source.

## Source and interpretation boundaries

Current JMdict compressed-content production already writes the 12-byte envelope and checksums in the native destination, then makes one owned HEAPU8 slice and transfers it. Generic JavaScript envelope copying/hashing is not the ordinary production compression path. Decoded-source parser profiles exclude inflate, IPC, storage and UI completion; cold component counters are not causal comparisons. Phase timers can overlap and must not be added.

In-flight registration correctness includes zero-length spans, exact length equality, safe persisted offsets, sorted and unsorted references, duplicate detection within and across active batches, and no partial registration on failure. Plain `instanceof` alone does not prove typed-array element kind or fixed private backing. Accessors/proxies can introduce side effects or change error order; shared/resizable metadata cannot support a cached value proof across awaits. #830 already contains these safeguards and tests.

### Symbol mapping now proven for the pinned native binary

The profiling agent rebuilt the pinned parser with exact LLVM 21.1.8. Release bytes matched the pinned binary; every non-custom section also matched the names-enabled build. Thus the following mapping belongs to this exact binary, rather than an inferred compiler layout:

| WASM function | Proven name | Prior decoded-source Node CPU sample self time |
| --- | --- | ---: |
| 13 | `parse_composite_span_impl` | 165.36 ms |
| 18 | `parse_row_single_pass` | 35.8 ms |
| 24 | `hash_content_xxh32_pair` | 42.36 ms |
| 27 | `encode_term_content_token_binary_row` | 30.06 ms |
| Export 36 | fused parse export | 101.75 ms |
| Export 34 | lookup index encode export | 14.73 ms |

These are prior sample attributions, not new comparative timings or independent additive stages. The largest scanner cost overlaps #972's existing proposal; native paired hash overlaps #623/#840. Proof receipt was produced at `/tmp/manabitan-llvm21-83b3/proof/symbol-proof.json` and must be preserved with the profiling evidence before temporary files expire.

## Further exact overlaps and completed sink audit

### Sixteen-byte SIMD string scan: explicitly excluded

[#19](https://github.com/ManabiIO/manabitan/pull/19), closed and unmerged at `61588714864a58b22793dc8f17de4878ae29b315`, already replaced the scalar eight-byte special-character detector with a sixteen-byte WASM SIMD load, quote/backslash/control masks, bitmask and count-trailing-zeros selection. This is the exact proposed scanner mechanism. Its patch also changed overlapping compaction to `memmove`, so its whole-import data do not isolate the scanner.

The original favorable browser measurements were withdrawn because the timing boundary was invalid. Corrected JMdict observations were all slower in three pairs, with a +10.94% median under load; Jitendex was mixed. #25 restored the production C to #18 while retaining compatibility regressions. Current accepted #44 scalar first-special-byte jumping and #45 inlining are different changes. Current `dev/perf/import-experiments-20260914.md` explicitly excludes reviving rejected SIMD hashing/scanning, and `dev/perf/bounded-on-develop-20260909.md` records #19 as rejected. No new SIMD scanner census, build or timing was authorized or run.

### Input-independent CRC polynomial powers: already owned by #910

The current deferred source verifier rebuilds the polynomial powers during each changed glossary length. [#910](https://github.com/ManabiIO/manabitan/pull/910), open draft at `2fe47fa3db04342d04eb4f309c5d74ef45eef9e3`, already adds `crc32_shift_powers[32]`, initializes `x^8` and the 31 squared powers once, and selects factors from that table inside `crc32_prepare_shift`. This is an exact source overlap, bundled there with contiguous source runs and broader reuse eligibility.

The broader #910 candidate remains HOLD: VNDB paired medians are +0.859% against A and +0.131% against C; both VNDB memory replications fail the existing sample-coverage gate. That does not isolate or disprove the polynomial-table subchange, but it prevents treating it as an unowned discovery or inheriting a passing performance claim. Earlier merged [#664](https://github.com/ManabiIO/manabitan/pull/664) cached powers in the older matrix representation; the current polynomial representation was introduced later. No new duplicate prototype was made.

### Metadata publication and record encoding

| Proposed repeated work | Existing owner/current behavior | Consequence for another experiment |
| --- | --- | --- |
| Reuse contiguous-publication proof in recent-cache registration | [#876](https://github.com/ManabiIO/manabitan/pull/876), closed/unmerged head `cdb23a11d991a72f860e400d0d81bb0747a5b4f9`. JMdict B/A −0.4756%, B/C +1.3890%; no useful repeatable gain. | Exact proof-reuse proposal has already been screened and held. Do not skip the same validation again under a new name. |
| Scalar metadata publication after successful bulk publication | Current `_publishArtifactTermContentMetadata` initializes its scalar loop at `pendingOffsets.length` when contiguous publication succeeds. | There are zero scalar-loop iterations on this route; no remaining full-loop cost to remove. |
| Final record offset/length column encoding | [#849](https://github.com/ManabiIO/manabitan/pull/849), merged/current head `5b19312bcf71ca69ebaddcb3922740191798d923`. Factory-private columns already encode directly and defer Float64 scratch. | Do not claim removal of an already absent six-byte-per-row temporary. |
| Validate repeated canonical IDs once per run | [#809](https://github.com/ManabiIO/manabitan/pull/809), merged/current head `77123e6cdb3101d7c0a3ef22ace4ebb2c004f72e`. | The PR body retains an older Proxy HOLD, but current code contains factory admission checks. Historical prose does not prove a current unresolved defect. |
| Resolve reference mode once in a synchronous record run | [#822](https://github.com/ManabiIO/manabitan/pull/822), original closed head `cf1e18d59d08da729d4b2fe45c7a07021f42360a`; its `getSynchronousResolvedContentReferences` mechanism is present in current code through integration. | Current code already avoids repeated selection and revalidates after an awaited append. |
| Separate content runs from score runs | [#855](https://github.com/ManabiIO/manabitan/pull/855), open head `bb1073961bb5adaa190e32943c94d063a18aa8bd`. Full-corpus field parity and normal CI pass; all whole-import intervals include zero. Earlier staged-column [#854](https://github.com/ManabiIO/manabitan/pull/854) is closed/unmerged. | Existing owner; do not blindly restore the older joint-run representation over #849. |
| Avoid a uniform-score temporary column | [#949](https://github.com/ManabiIO/manabitan/pull/949), closed/withdrawn head `97273b91c94a6385800bc5179afc684c818a786f`. | All complete source banks across the pinned corpora were nonuniform; smaller writer-chunk activation was not demonstrated. No established import gain. |
| Avoid unused pending lookup writes and eagerly resolved reserved spans | [#667](https://github.com/ManabiIO/manabitan/pull/667), merged/current head `37fa35b1377c5ce53e38ab36905ce17792e7b79f`. | Current code already defers source-span reads to collision fallback and removes repeated pending checks. |
| Copy only used dense metadata on growth | [#964](https://github.com/ManabiIO/manabitan/pull/964), original closed head `65fe8a7b7a8686406b637023ebb8afab6f7eb7a5`; integrated/current. | `arena.copyFrom(previous, denseCount, preserveSlots)` already avoids unused capacity copies and redundant fresh zeroing. |
| Skip retained JavaScript term records in real large OPFS imports | Current record store skips materialization when the active import total is at least 250,000 rows; all three pinned imports take this route. Active OPFS import also skips retained-row caching. | The suggested `_cacheAppendedArtifactChunkRecords` helper does not exist at baseline 9e10. Do not optimize materialization that the measured route does not execute. |

### Declined small lead: preserve owned recent-cache source origin

No exact existing implementation was found for retaining the original owned source view instead of trimming its logical prefix/suffix, while keeping the current full-backing-allocation budget. #824 introduced the trimming subview; #727 introduced dense zero-origin cache `fill`/`set`; #876 changes validation reuse instead of source origin. The candidate would preserve validation and permit the already existing dense writes when a genuine owned whole-cache source has a nonzero minimum published offset.

The current JMdict census found only three affected groups, containing 89,237 pending rows, and 704 total trimmed bytes. This is a limited work bound, not a timing gain. The native reviewer found that simply expanding the view changes the membership bounds enforced by `_findRecentTermContentSource`: requests that exceed the retained logical span could start succeeding. Preserving the original bound would require explicit origin/extent metadata and changed consumers, in addition to retaining nonzero source-view offsets, copied boundary snapshots, full-backing eviction charges, and unchanged logical-byte metrics. Root declined this broader contract change for the small target. No prototype or timing result was produced.

### Local browser launch boundary

The preserved local baseline attempt failed before import in Chromium `ProcessSingleton`, with `socket() failed: Operation not permitted`. It already used Playwright's debugging pipe. Current qualification launches Chromium through `launchPersistentContext` with a fresh profile; the frozen driver disables headed fallback, and the launch-options helper is a Linux no-op. No supported alternate CLI backend was found that would preserve this protocol and avoid the process-singleton failure. No browser was relaunched, no flags or sandbox policy were changed, and current permissions were not retested. Hosted qualification remains separate from component evidence.

### Native inflater ownership and exclusions

Current source uses the portable full-buffer libdeflate v1.26 subset. Six retained upstream files are unchanged; `common_defs.h` has the accepted WASM `uint64_t machine_word_t` adaptation from #664. That type already controls the bit buffer and word-copy loop. The wrapper owns one static decoder per instance, preserving its static-code tables across calls; there is no per-bank decoder allocation to eliminate. #642 removed the inactive libdeflate experiment switch because both branches had become identical. #640's freestanding memory-helper cleanup generated identical WASM and is not a new performance mechanism. #725 owns pinned LLVM 21.1.8 reproduction.

[#812](https://github.com/ManabiIO/manabitan/pull/812), open HOLD at `5555f3efd3e0c8baa99e93b4c14e7f1889c30383`, owns SIMD history copying in the current `decompress_template.h` fast loop. Matches with distance at least 16 use interleaved 16-byte loads/stores, advancing 32 bytes; forward order preserves overlap at distances 16–31, and at most 31 excess bytes remain inside the existing fast-loop bound. Short-distance copies, bounded tails, validation and non-WASM code are unchanged. Its complete 252-import study found JMdict −1.97% forward / +0.64% reversed, Jitendex −0.65% / +0.90%, and VNDB +1.33% / +0.13%; every candidate interval crosses zero. This is already owned and not a repeatable whole-import winner.

Earlier [#22](https://github.com/ManabiIO/manabitan/pull/22) and [#28](https://github.com/ManabiIO/manabitan/pull/28) changed the obsolete miniz bit reader/history-copy path. #22 was merged as a small functionally verified component change with noisy approximately flat whole imports. #28 remains rejected: its final old-stack JMnedict cohort was +6.35% by paired median and +8.57% across equal work, slower 6/6. Their source does not implement a current libdeflate optimization. No separate exact current libdeflate bit-reader specialization or decoder-table fast-path owner was found in this bounded search; any later idea still needs a measured cost and exact-loop audit before implementation.

### Prepared Zstandard compression dictionaries: withheld screens exist

No published runtime CDict implementation or qualified full-import CDict result was found. Current compression calls `ZSTD_compress_usingDict` per block and the shipped module does not expose the prepared-CDict API. Two prior investigations must nevertheless be retained before considering another experiment:

- [#903](https://github.com/ManabiIO/manabitan/pull/903), head `3d7b4528c295a3e0f9cf97e8d6967896c51d2310`, archives a native libzstd 1.5.7 comparison of 50 actual canonical Jitendex blocks, 51,564,333 input bytes from 56,555 rows. The two APIs produced identical per-block bytes and 4,203,636 total compressed bytes. CDict added 47,680 bytes while each context remained 549,920 bytes. Excluding round zero, six pairs were mixed with a −1.08% median in a loop that also hashes output. It had no identical-code controls and was not a WASM/compression-only benchmark. This was rejected as insufficient to justify new exports/toolchain work; it is not a proven whole-import regression. Raw compact record SHA-256: `988427defb37eeafabed7df736c2d34aa9a30ae50309fadff293f684f998b5bb`.
- The current baseline retains `dev/perf/import-qualification-evidence-20261125-a7f7/jitendex-investigation/cdict-feasibility.json.txt`, introduced by evidence commit `dd7be31`. Actual Jitendex source prefixes at 1,024, 16,384 and 65,536 bytes produced different compressed outputs; the 1,024-byte case grew from 442 to 443 bytes. Tested prefixes at least 131,072 bytes were identical. Prepared dictionaries retained another 47,680 bytes per context. No supported production WASM build or full-import improvement was established.

These observations mean a generic CDict replacement cannot simply assume exact encoded-byte equality for small inputs. They also do not attribute the current codec's total CPU time to dictionary setup. No new export, compiler acquisition, prototype or timing was performed for this idea during the ownership audit.

The subsequent read-only export mapping is retained in [the derivation script](zstd-export-map-20261128.py) and [the exact JSON receipt](zstd-export-map-20261128.json), receipt SHA-256 `00d52afceffb94ce86d6828674fc3aa53ce2c7f93bc9b50389173d46f02358d4`. It binds all four original raw profile hashes, the profile result/attribution hashes, generated loader assignments and the exact shipped Zstd WASM `ad3a18c197d72167262d01fd202976325f57a6697bca627f4527c96d4dbbcfcc`. Every observed WASM function's code offset falls within its exact binary body. The independently recomputed sample totals agree with the existing attribution.

| Proven boundary | Self samples | Inclusive samples |
| --- | ---: | ---: |
| JavaScript `finishPreparedSpanCompression` | 28.762 ms | 377.715 ms |
| Exported `ZSTD_compress_usingDict`, function 185 | 6.804 ms | 334.909 ms |
| Private, unnamed function 133 | 1.459 ms | 321.823 ms |
| Exported block-envelope writer, function 179 | 4.920 ms | 4.920 ms |

These are overlapping aggregate codec-worker samples from the existing diagnostic, not elapsed import time. **The 13.086 ms difference between functions 185 and 133 cannot bound dictionary setup:** function 133 is private and unclassified, and setup may occur inside it. The binary contains no name section; no private symbols were guessed from another build. The JavaScript wrapper copies dictionary bytes in `prepareSpanCompression` before `finish`; finish performs compression, error checks, native envelope generation and the owned result slice. Its self samples do not isolate those operations. CDict remains unproven and deferred; no new toolchain/export work is justified by this mapping alone.
