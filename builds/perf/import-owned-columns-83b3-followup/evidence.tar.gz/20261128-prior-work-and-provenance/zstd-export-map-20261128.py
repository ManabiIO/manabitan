#!/usr/bin/env python3
"""Read frozen codec bytes/profiles; map only proven public exports, never private symbols."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

BASELINE = '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
WASM_SHA = 'ad3a18c197d72167262d01fd202976325f57a6697bca627f4527c96d4dbbcfcc'
FROZEN = {
    'result.json': '1b7d938c604de4cf9c05b4f45cc226b36ea4d54f9a077ad09e9dd3647ca52e39',
    'attribution.json': '92bc4b58de40fe6ab99bbec96a90ccad7c3e6aa264a64e14e7e4b14cc0615b23',
    'codec-worker-0.cpuprofile': '423e9e52f406cd14852157028f31732ee835d1d0c673721752dd7b4738e3a296',
    'codec-worker-1.cpuprofile': 'e5fe5079e6f933d58bb8b4d7ec699f160339ffe84de542fc08e33641007f191d',
    'codec-worker-2.cpuprofile': '0521f7cd2840618b0607ec336f9fea75c59c19ab6d147ab691989d711435e8c4',
    'codec-worker-3.cpuprofile': '36b2a8ea2c66ce71898c1151c3c4d7234e627fa63fda6768b1434e27eab7478a',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def leb(data, pos):
    value = shift = 0
    while True:
        byte = data[pos]
        pos += 1
        value |= (byte & 127) << shift
        if byte < 128:
            return value, pos
        shift += 7
        require(shift < 64, 'Unbounded LEB')


def string(data, pos):
    size, pos = leb(data, pos)
    return data[pos:pos + size].decode(), pos + size


def decode_module(data):
    require(data[:8] == b'\x00asm\x01\x00\x00\x00', 'Unexpected WASM header')
    position = 8
    exports, bodies, custom = {}, {}, []
    imported_functions = 0
    while position < len(data):
        section = data[position]
        size, position = leb(data, position + 1)
        end = position + size
        require(end <= len(data), 'Section exceeds module')
        if section == 0:
            name, _ = string(data, position)
            custom.append(name)
        elif section == 2:
            count, cursor = leb(data, position)
            for _ in range(count):
                _, cursor = string(data, cursor)
                _, cursor = string(data, cursor)
                kind = data[cursor]
                cursor += 1
                require(kind == 0, 'Frozen codec imports changed kind')
                _, cursor = leb(data, cursor)
                imported_functions += 1
            require(cursor == end, 'Import section mismatch')
        elif section == 7:
            count, cursor = leb(data, position)
            for _ in range(count):
                name, cursor = string(data, cursor)
                kind = data[cursor]
                index, cursor = leb(data, cursor + 1)
                if kind == 0:
                    exports[name] = index
            require(cursor == end, 'Export section mismatch')
        elif section == 10:
            count, cursor = leb(data, position)
            for index in range(imported_functions, imported_functions + count):
                size, cursor = leb(data, cursor)
                bodies[index] = (cursor, cursor + size)
                cursor += size
            require(cursor == end, 'Code section mismatch')
        position = end
    return exports, bodies, custom


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    root = args.repo.resolve()
    profiles = root / 'builds/perf/20261128-canonical-sink-profile/run-1'
    inputs = {}

    def read(path, expected=None):
        data = path.read_bytes()
        actual = digest(data)
        require(expected is None or actual == expected, 'Input changed: ' + str(path))
        inputs[str(path.relative_to(root))] = {'sha256': actual, 'bytes': len(data)}
        return data

    result = json.loads(read(profiles / 'result.json', FROZEN['result.json']))
    old_analysis = json.loads(read(profiles / 'attribution.json', FROZEN['attribution.json']))
    require(result['sourceCommit'] == BASELINE, 'Wrong source commit')
    raw = read(root / 'dev/data/zstd-simd.wasm', WASM_SHA)
    require(raw == read(root / 'ext/lib/zstd.wasm', result['sourceIdentity']['ext/lib/zstd.wasm']), 'Runtime binary differs')
    read(root / 'ext/lib/zstd-wasm.js', result['sourceIdentity']['ext/lib/zstd-wasm.js'])
    loaders = [read(root / path).decode() for path in ('dev/lib/zstd-simd-module.js', 'ext/lib/zstd-simd-module.js')]
    pattern = r'Module\["(_[^\"]+)"\]\s*=\s*wasmExports\d*\["([^\"]+)"\]'
    assignments = [dict(re.findall(pattern, text)) for text in loaders]
    require(assignments[0] == assignments[1], 'Generated loader mappings differ')
    exports, bodies, custom = decode_module(raw)
    mapping = {name: {'export': tag, 'functionIndex': exports[tag]} for name, tag in assignments[0].items()}
    require(mapping['_ZSTD_compress_usingDict']['functionIndex'] == 185, 'Compressor export changed')
    require(mapping['_manabitan_write_block_envelope']['functionIndex'] == 179, 'Envelope export changed')
    leaf, inclusive, stacks = Counter(), Counter(), Counter()
    checked_frames = set()
    for name in FROZEN:
        if not name.endswith('.cpuprofile'):
            continue
        profile = json.loads(read(profiles / name, FROZEN[name]))
        require(len(profile['samples']) == len(profile['timeDeltas']), 'Sample count mismatch')
        nodes = {node['id']: node for node in profile['nodes']}
        parents = {child: node['id'] for node in profile['nodes'] for child in node.get('children', [])}
        frames = {key: (node['callFrame']['functionName'], node['callFrame']['url']) for key, node in nodes.items()}
        for node in nodes.values():
            frame = node['callFrame']
            match = re.fullmatch(r'wasm-function\[(\d+)\]', frame['functionName'])
            if match:
                index = int(match[1])
                require(frame['url'] == 'wasm://wasm/001a777e', 'Unexpected WASM module')
                start, end = bodies[index]
                require(start <= frame['columnNumber'] < end, 'Profile function offset differs from frozen module')
                checked_frames.add((index, frame['columnNumber']))
        for sample, delta in zip(profile['samples'], profile['timeDeltas']):
            leaf[frames[sample]] += delta
            seen, chain = set(), []
            current = sample
            while current is not None:
                frame = frames[current]
                if frame not in seen:
                    inclusive[frame] += delta
                    seen.add(frame)
                if frame[1].startswith('wasm:'):
                    chain.append(frame[0])
                current = parents.get(current)
            if chain:
                stacks[tuple(chain)] += delta
    rows = [{'function': frame[0], 'source': frame[1], 'selfMs': leaf[frame] / 1000, 'inclusiveMs': value / 1000}
            for frame, value in inclusive.items()
            if frame[1].startswith('wasm:') or frame[0] in ('finishPreparedSpanCompression', 'prepareSpanCompression')]
    rows.sort(key=lambda row: row['selfMs'], reverse=True)
    for row in rows:
        old = [entry for entry in old_analysis['codec']['inclusive']
               if entry['function'] == row['function'] and entry['source'] == row['source']]
        require(len(old) == 1 and abs(old[0]['sampledMs'] - row['inclusiveMs']) < 0.000001,
                'Independent attribution disagrees: ' + row['function'])
    report = {
        'schemaVersion': 1, 'sourceCommit': BASELINE,
        'method': 'Sum raw V8 timeDeltas at leaves; count each inclusive frame once per sample across four existing codec-worker profiles.',
        'inputs': inputs, 'scriptSha256': digest(Path(__file__).read_bytes()),
        'publicExportMapping': mapping, 'moduleCustomSections': custom,
        'profileFunctionOffsetsVerified': [{'functionIndex': i, 'profileOffset': offset, 'bodyRange': bodies[i]} for i, offset in sorted(checked_frames)],
        'aggregateSamples': rows,
        'observedWasmStacks': [{'leafToRoot': list(chain), 'sampledMs': value / 1000} for chain, value in stacks.most_common()],
        'limits': [
            'No new execution, build, acquisition, candidate, browser measurement or speed comparison.',
            'Only public symbols are mapped. Private function 133 and its descendants remain unclassified.',
            '334.909 minus 321.823 = 13.086 ms is sampled usingDict work outside private function 133; it CANNOT bound dictionary setup, which may be inside 133.',
            'Inclusive times overlap and are aggregate worker CPU samples, not elapsed import time or independent additive stages.',
            'JS prepare copies dictionary bytes before finish; finish performs usingDict, envelope, checks and the owned result slice. Self samples cannot isolate those individual JS operations.',
        ],
    }
    require(not args.output.exists(), 'Refusing to overwrite receipt')
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'output': str(args.output), 'sha256': digest(args.output.read_bytes()), 'exports': mapping, 'frames': len(rows)}, indent=2))


if __name__ == '__main__':
    main()
