# Current pinned native symbol proof

This archive binds private WASM function names to the unchanged native parser at baseline `9e10d3b3fcf66d344ab31bc42c9b522fa5215da2`. It also annotates the existing JMdict and Jitendex Node inspector diagnostics. It contains no new timing experiment and makes no browser import speed claim.

## Identity and proof

- Pinned parser: `8ae00698649c5a3e41039b13c5ffe1dff2d4e69948cba2e3c063f381250031ee`.
- Native source identity: `3a57887352cbc53a62bd3bda797f6513a72634515e6ea65a9a4ae9120739a1b6`, covering all 14 C/header inputs.
- Exact compiler and linker: Debian LLVM 21.1.8, package version `1:21.1.8~++20251221032947+2078da43e25a-1~exp1~20251221153113.67`.
- Both pinned release modules rebuilt byte-for-byte from the manifest arguments. The second builds omitted only `-Wl,--strip-all`; all nine parser noncustom sections and all seven canonical scanner noncustom sections then matched the pinned releases byte-for-byte.
- Source hashes, the manifest, and tracked Git status remained unchanged before and after the builds. Tool binary/library hashes, commands, exact section hashes, and the complete name maps are in `proof/symbol-proof.json`.

The seven package downloads came from the official `https://apt.llvm.org/bookworm/` repository. Their published lengths and SHA-256 values were checked before extraction. The complete selected metadata and compressed package index are preserved under `toolchain/`. Extraction used `dpkg-deb -x` into `/tmp/manabitan-llvm21-83b3/root`; no package installation or system configuration changed. The seven compressed copies were removed after verified extraction. Large extracted compiler/library binaries are intentionally outside this evidence archive.

## Reproduction

The exact executed scripts are preserved without rewriting their original task paths:

```sh
python3 /tmp/manabitan-llvm21-83b3/bootstrap.py
python3 /tmp/manabitan-llvm21-83b3/prove-symbols.py
python3 /tmp/manabitan-llvm21-83b3/archive-proof.py
```

`bootstrap.py` requires Python 3, HTTPS access to the official package URLs, and `dpkg-deb`. `prove-symbols.py` requires the baseline checkout at `/workspace/scratch/83b3b3bfba02/manabitan`. Both fail closed on identity mismatches and preserve failures. They require fresh task output directories; they do not overwrite a previous proof. For another machine, place the scripts at the same paths or explicitly record any path-only adaptation separately. All exact compiler commands are in the proof receipt.

The extracted binaries can be regenerated without installing them. Set process-local `LD_LIBRARY_PATH` to the prefix's `usr/lib/x86_64-linux-gnu` and `usr/lib/llvm-21/lib` directories, and use the absolute `usr/lib/llvm-21/bin/clang` and `usr/lib/llvm-21/bin/wasm-ld` paths. Their versions and resolved dependencies are preserved in the corresponding logs.

## Temporary payload cleanup

At 04:09:32 UTC on 2026-11-28, the idle `/tmp/manabitan-llvm21-83b3/root` payload was removed under temporary-disk pressure. The archive's 33 pre-cleanup entries were rechecked against their manifest first, and no running executable used the payload. The removed allocation was 253,244 KiB; observed free space increased by 259,321,856 bytes. `toolchain/cleanup.json` records the exact check and cleanup. The installer, package metadata, named modules, release modules, proof and logs remain preserved.

To regenerate the exact toolchain and proof in a fresh temporary directory from this checkout:

```sh
native_rebuild_dir=$(mktemp -d /tmp/manabitan-llvm21-rebuild.XXXXXX)
cp builds/perf/20261128-native-symbols-83b3/toolchain/bootstrap.py "$native_rebuild_dir/"
cp builds/perf/20261128-native-symbols-83b3/toolchain/prove-symbols.py "$native_rebuild_dir/"
python3 "$native_rebuild_dir/bootstrap.py"
python3 "$native_rebuild_dir/prove-symbols.py"
```

These are regeneration instructions, not a second execution receipt. They retain the frozen package checksums and fail if the baseline source or pinned release identity differs.

## Existing profile attribution

`jmdict-named-attribution.json` and `jitendex-named-attribution.json` add proven native names to the original self-sample records. The original raw `.cpuprofile`, counter result, hotspots, and profile runner are preserved under `original-profiles/` and bound by SHA-256 in the derived reports.

| Native function                                 | Index | JMdict sampled self ms | Jitendex sampled self ms |
| ----------------------------------------------- | ----: | ---------------------: | -----------------------: |
| `parse_composite_span_impl`                     |    13 |                 165.36 |                   360.32 |
| `parse_and_encode_term_bank_token_binary_dedup` |    36 |                 101.75 |                   104.42 |
| `hash_content_xxh32_pair`                       |    24 |                  42.36 |                   107.65 |
| `parse_row_single_pass`                         |    18 |                  35.80 |                    30.66 |
| `encode_term_content_token_binary_row`          |    27 |                  30.06 |                    31.25 |
| `encode_term_lookup_index`                      |    34 |                  14.73 |                    13.00 |

These are sampled self times from Node 22.22.0, not complete import timings or prospective savings. The diagnostics use production policy-3 grouping with execution concurrency one, decoded source bytes, and a local worker adapter. They exclude ZIP inflation, actual worker transport, and storage. The outer elapsed timer includes adapter input slices. Inclusive native/parser counters overlap and must not be added together. Harness slicing, SHA verification, inspector shutdown, and garbage collection remain visible in the raw profiles; they are not assigned to product changes. These profiles predate owned-column adoption.

The largest native scanner area overlaps the existing scanner work in PR #972; the mapping alone is not evidence of a new, unowned optimization.
