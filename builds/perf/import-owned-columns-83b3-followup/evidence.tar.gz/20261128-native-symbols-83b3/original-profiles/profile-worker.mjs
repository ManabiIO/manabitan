// Diagnostic-only replay of the actual source parser worker through an explicit
// local message adapter. Sequential groups; not browser/import timing.
import fs from 'node:fs/promises';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {performance} from 'node:perf_hooks';
import {Session} from 'node:inspector';
import {pathToFileURL} from 'node:url';
import {ZipReader, Uint8ArrayReader, Uint8ArrayWriter} from '@zip.js/zip.js';
const root='/workspace/scratch/83b3b3bfba02/manabitan';
const dictionary=process.argv[2]??'jmdict';
const out=path.resolve(process.argv[3]??`builds/perf/20261127-baseline/${dictionary}-worker`);
const profileEnabled=process.argv.includes('--profile');
const sha=b=>createHash('sha256').update(b).digest('hex');
const lockBytes=await fs.readFile(path.join(root,'test/perf/dictionaries.lock.json'));
const spec=JSON.parse(lockBytes).dictionaries[dictionary];
const archive=await fs.readFile(path.join(root,'builds/e2e-dictionary-cache',spec.cacheFile));
if(archive.length!==spec.sizeBytes||sha(archive)!==spec.sha256)throw Error('fixture mismatch');
const reader=new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)));
let sources=[];
try {
 const entries=(await reader.getEntries()).filter(e=>/^term_bank_\d+\.json$/.test(e.filename)).sort((a,b)=>Number(a.filename.slice(10,-5))-Number(b.filename.slice(10,-5)));
 for(const e of entries)sources.push(await e.getData(new Uint8ArrayWriter(),{useWebWorkers:false,checkSignature:true}));
}finally{await reader.close();}
const totalBytes=sources.reduce((s,x)=>s+x.length,0);
const hasMedia=(spec.mediaFiles??0)>0;
const workerCount=3;
const targetGroups=Math.max(workerCount*(hasMedia?3:4),Math.ceil(totalBytes/(24*1024*1024)));
// Verbatim policy from partitionSourceBanks; this replay uses Uint8Array sizes.
function partition(contentBytes,totalBytes,requestedGroupCount){
 const groupCount=Math.min(requestedGroupCount,contentBytes.length);const groups=[];let start=0;let consumedBytes=0;
 for(let groupIndex=0;groupIndex<groupCount-1;++groupIndex){const remainingGroups=groupCount-groupIndex;const targetBytes=(totalBytes-consumedBytes)/remainingGroups;let end=start+1;let bytes=contentBytes[start].byteLength;const maxEnd=contentBytes.length-(remainingGroups-1);while(end<maxEnd){const nextBytes=bytes+contentBytes[end].byteLength;if(Math.abs(nextBytes-targetBytes)>Math.abs(bytes-targetBytes))break;bytes=nextBytes;++end;}groups.push(contentBytes.slice(start,end));start=end;consumedBytes+=bytes;}
 groups.push(contentBytes.slice(start));return groups;
}
const groups=partition(sources,totalBytes,targetGroups);
let callback;let pending;
globalThis.self={addEventListener(type,fn){if(type==='message')callback=fn;},postMessage(msg,transfer=[]){const resolve=pending;pending=null;resolve({message:msg,transferBytes:transfer.reduce((s,b)=>s+b.byteLength,0),transferBuffers:transfer.length});}};
await import(pathToFileURL(path.join(root,'ext/js/dictionary/term-bank-wasm-parser-worker.js')).href);
async function send(data){const p=new Promise(resolve=>{if(pending)throw Error('concurrent replay');pending=resolve;});callback({data});const r=await p;if(r.message.type==='parse-error'||r.message.type==='init-error')throw Error(JSON.stringify(r.message));return r;}
const wasm=await fs.readFile(path.join(root,'ext/lib/term-bank-parser.wasm'));
await send({type:'initialize',module:await WebAssembly.compile(wasm)});
const projectImagePaths=hasMedia&&totalBytes>=1024*1024*1024;
const options={copyContentBytes:false,includeContentMetadata:true,initialContentBytesPerRow:48,minimalDecode:true,reuseExpressionForReadingDecode:true,preallocateChunkRows:true,skipTagRuleDecode:hasMedia,lazyGlossaryDecode:true,mediaHintFastScan:hasMedia,projectImagePaths,validateGlossaryTypes:true,computeContentHashes:true,emitContentSlab:true,emitTokenBinaryContent:true,emitTermByteLists:false,prepareLookupIndexes:true,prepareLookupRoute:totalBytes>=128*1024*1024,ownContentBytes:projectImagePaths&&totalBytes>=512*1024*1024};
async function execute(verify){const observations=[];const digest=createHash('sha256');let rows=0;for(let i=0;i<groups.length;i++){
 const group=groups[i];console.error(JSON.stringify({phase:verify?"measurement":"warmup",group:i,banks:group.length}));const t=performance.now();const r=await send({type:'parse',id:i,version:3,sourceBuffers:group.map(b=>b.buffer.slice(b.byteOffset,b.byteOffset+b.byteLength)),chunkSize:8192,options});const elapsedMs=performance.now()-t;const {chunk,profile,borrowsWorkerMemory,ownsContentBytes}=r.message;
 if(!chunk)throw Error('missing chunk');rows+=chunk.rowCount;
 const p=chunk.termRecordPreinternedPlan;const indexes=chunk.preparedLookupIndexes;
 const whole=indexes?.size===1&&[...indexes.values()][0].preinternedPlan===p;
 observations.push({index:i,banks:group.length,sourceBytes:group.reduce((s,b)=>s+b.byteLength,0),rows:chunk.rowCount,elapsedMs,borrowsWorkerMemory,ownsContentBytes,transferBytes:r.transferBytes,transferBuffers:r.transferBuffers,wholeIndex:whole,indexCount:indexes?.size??0,keyBytes:p.stringsBuffer.byteLength,keyLengthsBytes:p.stringLengths.byteLength,expressionBytes:p.expressionIndexes.byteLength,contentMetaByUniqueIndex:chunk.contentMetaByUniqueIndex===true,contentMetaBytes:chunk.contentMetaList?.byteLength,profile});
 if(verify){const update=v=>{if(v)digest.update(new Uint8Array(v.buffer,v.byteOffset,v.byteLength));};for(const [key,e] of indexes){digest.update(key);update(e.bytes);update(e.routeFilter);}for(const v of [chunk.scoreList,chunk.sequenceList,chunk.readingEqualsExpressionList,chunk.contentUniqueIndexList,chunk.contentMetaList])update(v);if(chunk.contentBytesBuffer)update(chunk.contentBytesBuffer);}
 }
 await fs.writeFile(path.join(out,verify?'checkpoint-measurement.json':'checkpoint-warmup.json'),JSON.stringify({rows,observations}));
 if(rows!==spec.termRows)throw Error(`rows ${rows}`);
 return {rows,observations,digest:verify?digest.digest('hex'):null};}
await fs.mkdir(out,{recursive:true});
await execute(false);
globalThis.gc?.();
let session;const post=(method,params={})=>new Promise((resolve,reject)=>session.post(method,params,(e,r)=>e?reject(e):resolve(r)));
if(profileEnabled){session=new Session();session.connect();await post('Profiler.enable');await post('Profiler.setSamplingInterval',{interval:250});await post('Profiler.start');}
const result=await execute(true);
let cpu;if(profileEnabled){cpu=(await post('Profiler.stop')).profile;session.disconnect();}
await fs.mkdir(out,{recursive:true});
const resultPath=path.join(out,'result.json');
await fs.writeFile(resultPath,JSON.stringify({dictionary,authoritativeBrowserTiming:false,workerCountPolicy:workerCount,workerParallelism:1,rawInput:'decoded source bytes; ZIP native inflation and worker transport excluded',sourceRoot:root,sourceSha:'9e10d3b3fcf66d344ab31bc42c9b522fa5215da2',wasmSha256:sha(wasm),archiveSha256:spec.sha256,lockSha256:sha(lockBytes),runnerSha256:sha(await fs.readFile(new URL(import.meta.url))),node:process.version,profileEnabled,totalBytes,banks:sources.length,groups:groups.length,options,...result},null,2));
if(cpu)await fs.writeFile(path.join(out,'worker.cpuprofile'),JSON.stringify(cpu));
console.log(JSON.stringify({resultPath,rows:result.rows,groups:groups.length,totalBytes,wholeIndexRows:result.observations.filter(x=>x.wholeIndex).reduce((s,x)=>s+x.rows,0),sumWorkerMs:result.observations.reduce((s,x)=>s+x.elapsedMs,0),sumCopyMs:result.observations.reduce((s,x)=>s+(x.profile.resultCopyMs??0),0)}));
