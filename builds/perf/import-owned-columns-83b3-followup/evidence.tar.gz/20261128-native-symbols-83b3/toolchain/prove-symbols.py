#!/usr/bin/env python3
"""Bind private WASM names to unchanged pinned executable sections."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import traceback

BASE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/83b3b3bfba02/manabitan')
PREFIX = BASE / 'root'
OUT = BASE / 'proof'
CLANG = PREFIX / 'usr/lib/llvm-21/bin/clang'
LINKER = PREFIX / 'usr/lib/llvm-21/bin/wasm-ld'
ENV = dict(os.environ)
ENV['LD_LIBRARY_PATH'] = str(PREFIX / 'usr/lib/x86_64-linux-gnu') + ':' + str(PREFIX / 'usr/lib/llvm-21/lib')
report = {'format': 1, 'complete': False, 'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'repository': str(REPO), 'commands': [], 'targets': [],
          'meaning': 'Names are accepted only after exact pinned release rebuild and byte equality of every noncustom section.'}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def file_identity(file):
    data = file.read_bytes()
    return {'path': str(file), 'resolvedPath': str(file.resolve()), 'bytes': len(data), 'sha256': digest(data)}

def save():
    (OUT / 'symbol-proof.json').write_text(json.dumps(report, indent=2) + '\n')

def run(argv, log_name):
    command = [str(value) for value in argv]
    report['commands'].append({'argv': command, 'cwd': str(REPO), 'environment': {'LD_LIBRARY_PATH': ENV['LD_LIBRARY_PATH']}, 'log': log_name})
    save()
    result = subprocess.run(command, cwd=REPO, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (OUT / log_name).write_text(result.stdout)
    report['commands'][-1]['exitCode'] = result.returncode
    save()
    if result.returncode:
        raise RuntimeError(f'{command[0]} exited {result.returncode}; see {log_name}')
    return result.stdout

def source_identity():
    files = sorted(file for file in (REPO / 'ext/js/dictionary/wasm').rglob('*') if file.is_file() and file.suffix.lower() in ('.c', '.h'))
    value = hashlib.sha256()
    entries = []
    for file in files:
        assert not file.is_symlink(), file
        relative = str(file.relative_to(REPO))
        sha = digest(file.read_bytes())
        value.update((relative + '\0' + sha + '\n').encode())
        entries.append({'path': relative, 'sha256': sha, 'bytes': file.stat().st_size})
    return {'digest': value.hexdigest(), 'count': len(files), 'files': entries}

def uleb(data, offset):
    result = 0
    shift = 0
    for _ in range(5):
        assert offset < len(data), 'Truncated ULEB'
        byte = data[offset]
        offset += 1
        result |= (byte & 0x7f) << shift
        if not byte & 0x80:
            return result, offset
        shift += 7
    raise AssertionError('Invalid ULEB32')

def utf8(data, offset):
    length, offset = uleb(data, offset)
    end = offset + length
    assert end <= len(data), 'Truncated UTF8 field'
    return data[offset:end].decode('utf-8'), end

def sections(data):
    assert data[:8] == b'\0asm\x01\0\0\0', 'Invalid WASM header'
    result = []
    offset = 8
    while offset < len(data):
        start = offset
        section_id = data[offset]
        size, payload = uleb(data, offset + 1)
        end = payload + size
        assert end <= len(data), 'Truncated section'
        result.append({'id': section_id, 'raw': data[start:end], 'payload': data[payload:end]})
        offset = end
    assert offset == len(data)
    return result

def function_names(module_sections):
    result = {}
    for section in module_sections:
        if section['id'] != 0:
            continue
        data = section['payload']
        custom_name, offset = utf8(data, 0)
        if custom_name != 'name':
            continue
        while offset < len(data):
            subsection_id = data[offset]
            size, payload = uleb(data, offset + 1)
            end = payload + size
            assert end <= len(data)
            if subsection_id == 1:
                count, cursor = uleb(data, payload)
                for _ in range(count):
                    index, cursor = uleb(data, cursor)
                    name, cursor = utf8(data, cursor)
                    assert index not in result, index
                    result[index] = name
                assert cursor == end
            offset = end
    assert result, 'No function-name map'
    return result

try:
    OUT.mkdir(exist_ok=False)
    manifest_file = REPO / 'dev/data/dictionary-wasm/manifest.json'
    manifest = json.loads(manifest_file.read_text())
    assert manifest['toolchain'] == {'compilerVersion': '21.1.8', 'linkerVersion': '21.1.8'}
    report['toolchainPackageManifest'] = file_identity(BASE / 'manifest.json')
    package_manifest = json.loads((BASE / 'manifest.json').read_text())
    assert package_manifest['complete'] is True
    assert all(record['verified'] and record['extracted'] for record in package_manifest['packages'])
    report['manifest'] = file_identity(manifest_file)
    report['packageLock'] = file_identity(REPO / 'package-lock.json')
    report['sourceBefore'] = source_identity()
    assert report['sourceBefore']['digest'] == manifest['sourceDigest']
    assert report['sourceBefore']['count'] == manifest['sourceFileCount']
    report['gitHead'] = run(['git', 'rev-parse', 'HEAD'], 'git-head.log').strip()
    assert report['gitHead'] == '9e10d3b3fcf66d344ab31bc42c9b522fa5215da2'
    report['gitStatusBefore'] = run(['git', 'status', '--porcelain', '--untracked-files=no'], 'git-status-before.log')
    report['toolBinaries'] = [file_identity(CLANG), file_identity(LINKER)]
    report['toolLibraries'] = [file_identity(file) for file in sorted((PREFIX / 'usr/lib/x86_64-linux-gnu').glob('*.so*')) if file.is_file() and not file.is_symlink()]
    for tool, name in [(CLANG, 'clang'), (LINKER, 'wasm-ld')]:
        dependencies = run(['ldd', str(tool)], name + '-ldd.log')
        assert 'not found' not in dependencies, dependencies
    compiler_version = run([CLANG, '--version'], 'clang-version.log')
    linker_version = run([LINKER, '--version'], 'wasm-ld-version.log')
    assert re.search(r'\bclang version (\d+\.\d+\.\d+)\b', compiler_version)[1] == '21.1.8'
    assert re.search(r'\bLLD (\d+\.\d+\.\d+)\b', linker_version)[1] == '21.1.8'
    report['runtimeVersions'] = {'compiler': compiler_version, 'linker': linker_version}
    for target in manifest['targets']:
        release_file = OUT / ('release-' + target['name'])
        pinned_file = REPO / 'dev/data/dictionary-wasm' / target['name']
        pinned = pinned_file.read_bytes()
        assert digest(pinned) == target['sha256']
        record = {'name': target['name'], 'pinned': file_identity(pinned_file), 'releaseExactMatch': False, 'allNoncustomSectionsEqual': False}
        report['targets'].append(record)
        command = [CLANG, '-fuse-ld=' + str(LINKER), *target['arguments'], '-o', release_file, *[REPO / source for source in target['sources']]]
        run(command, target['name'] + '-release-build.log')
        release = release_file.read_bytes()
        record['release'] = file_identity(release_file)
        record['releaseExactMatch'] = release == pinned
        save()
        assert record['releaseExactMatch'], 'Pinned release mismatch; refusing to build/interpret names'
    for target, record in zip(manifest['targets'], report['targets']):
        names_file = OUT / ('names-' + target['name'])
        arguments = [argument for argument in target['arguments'] if argument != '-Wl,--strip-all']
        assert len(arguments) == len(target['arguments']) - 1
        command = [CLANG, '-fuse-ld=' + str(LINKER), *arguments, '-o', names_file, *[REPO / source for source in target['sources']]]
        run(command, target['name'] + '-names-build.log')
        release = (OUT / ('release-' + target['name'])).read_bytes()
        names_bytes = names_file.read_bytes()
        release_sections = sections(release)
        names_sections = sections(names_bytes)
        actual_noncustom = [section for section in names_sections if section['id'] != 0]
        expected_noncustom = [section for section in release_sections if section['id'] != 0]
        assert len(actual_noncustom) == len(expected_noncustom)
        record['namesBuild'] = file_identity(names_file)
        record['noncustomSections'] = []
        for position, (expected, actual) in enumerate(zip(expected_noncustom, actual_noncustom)):
            comparison = {'position': position, 'id': expected['id'], 'bytes': len(expected['raw']), 'releaseSha256': digest(expected['raw']), 'namesSha256': digest(actual['raw']), 'equal': expected['raw'] == actual['raw']}
            record['noncustomSections'].append(comparison)
            assert expected['id'] == actual['id'] and comparison['equal'], comparison
        record['allNoncustomSectionsEqual'] = True
        record['functionNames'] = function_names(names_sections)
        save()
    report['sourceAfter'] = source_identity()
    assert report['sourceAfter'] == report['sourceBefore']
    assert file_identity(manifest_file) == report['manifest']
    report['gitStatusAfter'] = run(['git', 'status', '--porcelain', '--untracked-files=no'], 'git-status-after.log')
    assert report['gitStatusBefore'] == report['gitStatusAfter']
    report['script'] = file_identity(Path(__file__))
    report['complete'] = True
    report['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    parser = next(target for target in report['targets'] if target['name'] == 'term-bank-parser.wasm')
    print(json.dumps({'complete': True, 'report': str(OUT / 'symbol-proof.json'), 'allReleaseTargetsExact': all(target['releaseExactMatch'] for target in report['targets']), 'allNoncustomSectionsEqual': all(target['allNoncustomSectionsEqual'] for target in report['targets']), 'parserNames': {index: parser['functionNames'].get(index) for index in [13, 18, 24, 27, 34, 36, 46]}}, indent=2), flush=True)
except BaseException as error:
    report['error'] = str(error)
    report['traceback'] = traceback.format_exc()
    save()
    print(report['traceback'], flush=True)
    raise
