#!/usr/bin/env python3
"""Extract exact official LLVM 21.1.8 packages without installing them."""
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback
import urllib.request

BASE = Path(__file__).resolve().parent
PREFIX = BASE / 'root'
ARCHIVES = BASE / 'archives'
VERSION = '21.1.8~++20251221032947+2078da43e25a-1~exp1~20251221153113.67'
INDEX_URL = 'https://apt.llvm.org/bookworm/dists/llvm-toolchain-bookworm-21/main/binary-amd64/Packages.gz'
PACKAGE_BASE = 'https://apt.llvm.org/bookworm/'
PACKAGES = [
    ('clang-21', 168580, 519, '43167d4912316e591f4dc122bd8e9cd0c2db95c31edcc47cde97e89a496c2024'),
    ('libclang-common-21-dev', 799264, 14696, '8b5d26e30f336b0f5727f506b9d3e31890d225efc1a5eb1f73ab4e253ced9da6'),
    ('libclang-cpp21', 12811140, 59606, '2e04f5de6f6f877f505a7abee85e1210d71b3b07d380ec5ebfaec45efe5a7fea'),
    ('libclang1-21', 7719268, 32411, '9ba73f312d5e76875363f493287ad6a5ee6754c22bbca3a07061ae07c1129659'),
    ('libllvm21', 28223636, 135581, '06646d519de58f391ca049b8a47bbd678c929540f4cb8a73caac29818c5cf720'),
    ('lld-21', 1455916, 5823, '498f0690630be48f0f11e3c62bedc0d646ed2951c10c707e388a322cd9b93a0f'),
    ('llvm-21-linker-tools', 1273488, 4230, 'd7a8b99bf09cfd75f9b2dc9bc016fd2da5bada6b55722485f632615cc972c4c0'),
]
manifest = {
    'format': 1,
    'purpose': 'Isolated exact-version native symbol proof; no system installation or product/pin mutation.',
    'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'version': '1:' + VERSION,
    'indexUrl': INDEX_URL,
    'prefix': str(PREFIX),
    'complete': False,
    'commands': [],
    'packages': [],
}

def save():
    (BASE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

def say(message):
    print(message, flush=True)
    with (BASE / 'bootstrap.log').open('a') as stream:
        stream.write(message + '\n')

def sha256_file(file):
    digest = hashlib.sha256()
    with file.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()

try:
    BASE.mkdir(parents=True, exist_ok=True)
    PREFIX.mkdir(exist_ok=False)
    ARCHIVES.mkdir(exist_ok=False)
    required = sum(row[1] + row[2] * 1024 for row in PACKAGES) + 64 * 1024 * 1024
    available = os.statvfs(BASE).f_bavail * os.statvfs(BASE).f_frsize
    manifest['initialAvailableBytes'] = available
    manifest['conservativeRequiredBytes'] = required
    assert available >= required, (available, required)
    with urllib.request.urlopen(INDEX_URL, timeout=45) as response:
        assert response.status == 200, response.status
        index_bytes = response.read(1024 * 1024)
        assert response.read(1) == b'', 'Unexpectedly large package index'
    (BASE / 'Packages.gz').write_bytes(index_bytes)
    manifest['indexSha256'] = hashlib.sha256(index_bytes).hexdigest()
    stanzas = {}
    for stanza in gzip.decompress(index_bytes).decode().split('\n\n'):
        fields = {}
        for line in stanza.splitlines():
            if line and not line[0].isspace() and ': ' in line:
                key, value = line.split(': ', 1)
                fields[key] = value
        if fields.get('Package') in {row[0] for row in PACKAGES}:
            stanzas[fields['Package']] = (fields, stanza)
    selected_stanzas = []
    for name, size, installed_kib, expected_sha in PACKAGES:
        fields, stanza = stanzas[name]
        filename = f'pool/main/l/llvm-toolchain-21/{name}_{VERSION}_amd64.deb'
        assert fields['Version'] == '1:' + VERSION, (name, fields['Version'])
        assert fields['Filename'] == filename, (name, fields['Filename'])
        assert int(fields['Size']) == size, (name, fields['Size'])
        assert int(fields['Installed-Size']) == installed_kib, (name, fields['Installed-Size'])
        assert fields['SHA256'] == expected_sha, (name, fields['SHA256'])
        selected_stanzas.append(stanza)
        manifest['packages'].append({
            'package': name, 'version': fields['Version'], 'url': PACKAGE_BASE + filename,
            'downloadBytes': size, 'installedSizeKiB': installed_kib, 'sha256': expected_sha,
            'depends': fields.get('Depends', ''), 'verified': False, 'extracted': False,
        })
    (BASE / 'selected-package-metadata.txt').write_text('\n\n'.join(selected_stanzas) + '\n')
    save()
    for record in manifest['packages']:
        file = ARCHIVES / (record['package'] + '.deb')
        digest = hashlib.sha256()
        length = 0
        with urllib.request.urlopen(record['url'], timeout=45) as response, file.open('xb') as output:
            assert response.status == 200, response.status
            for chunk in iter(lambda: response.read(1024 * 1024), b''):
                length += len(chunk)
                assert length <= record['downloadBytes'], (record['package'], length)
                digest.update(chunk)
                output.write(chunk)
        assert length == record['downloadBytes'], (record['package'], length)
        assert digest.hexdigest() == record['sha256'], (record['package'], digest.hexdigest())
        record['verified'] = True
        record['observedBytes'] = length
        record['observedSha256'] = digest.hexdigest()
        save()
        say('Verified ' + record['package'] + ' ' + str(length) + ' bytes')
    for record in manifest['packages']:
        file = ARCHIVES / (record['package'] + '.deb')
        assert sha256_file(file) == record['sha256']
        command = ['/usr/bin/dpkg-deb', '-x', str(file), str(PREFIX)]
        manifest['commands'].append(command)
        with (BASE / 'bootstrap.log').open('a') as log:
            subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=True)
        record['extracted'] = True
        save()
        file.unlink()
        record['compressedCopyRemovedAfterVerifiedExtraction'] = True
        save()
        say('Extracted ' + record['package'])
    manifest['complete'] = True
    manifest['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    manifest['bootstrapSha256'] = sha256_file(Path(__file__))
    save()
    say('Extraction complete; no system installation performed.')
except BaseException as error:
    manifest['error'] = str(error)
    manifest['traceback'] = traceback.format_exc()
    save()
    say(manifest['traceback'])
    raise
