#!/usr/bin/env python3
"""Archive exact symbol proof and annotate existing diagnostic profiles."""
import hashlib
import json
from pathlib import Path
import re
import shutil

BASE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/83b3b3bfba02/manabitan')
OUT = REPO / 'builds/perf/20261128-native-symbols-83b3'
OUT.mkdir(exist_ok=False)

def identity(file):
    data = file.read_bytes()
    return {'path': str(file.relative_to(OUT)), 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def copy(source, relative):
    target = OUT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    return target

for name in ['bootstrap.py', 'bootstrap.log', 'manifest.json', 'Packages.gz', 'selected-package-metadata.txt', 'prove-symbols.py', 'archive-proof.py']:
    copy(BASE / name, 'toolchain/' + name)
for file in sorted((BASE / 'proof').iterdir()):
    if file.is_file():
        copy(file, 'proof/' + file.name)
copy(REPO / 'builds/perf/20261127-baseline/profile-worker.mjs', 'original-profiles/profile-worker.mjs')
proof_file = OUT / 'proof/symbol-proof.json'
proof = json.loads(proof_file.read_text())
assert proof['complete'] is True
target = next(target for target in proof['targets'] if target['name'] == 'term-bank-parser.wasm')
assert target['releaseExactMatch'] and target['allNoncustomSectionsEqual']
names = target['functionNames']
counter_fields = ['parseBankMs', 'lookupIndexPrepareMs', 'lookupIndexEncodeMs', 'lookupIndexCompactMs', 'resultCopyMs', 'copyJsonMs', 'bufferSetupMs', 'chunkDispatchMs', 'rowDecodeMs', 'recentContentDedupHitCount', 'validatedGlossaryReuseCount', 'nativeLookupScratchReusedBytes', 'nativeSegmentedLookupSegments', 'compactContentMetadataGroups', 'compactContentMetadataBytesAvoided']
for dictionary, directory in [('jmdict', 'jmdict-worker-retry'), ('jitendex', 'jitendex-worker')]:
    source = REPO / 'builds/perf/20261127-baseline' / directory
    files = {}
    for name in ['result.json', 'hotspots.json', 'worker.cpuprofile']:
        files[name] = copy(source / name, f'original-profiles/{dictionary}/{name}')
    result = json.loads(files['result.json'].read_text())
    hotspots = json.loads(files['hotspots.json'].read_text())
    assert result['wasmSha256'] == target['pinned']['sha256']
    assert result['sourceSha'] == proof['gitHead']
    observations = result['observations']
    for row in hotspots:
        match = re.fullmatch(r'wasm-function\[(\d+)\]', row['function'])
        if match:
            index = match[1]
            assert index in names, index
            row['nativeFunctionIndex'] = int(index)
            row['nativeFunctionName'] = names[index]
    report = {
        'format': 1,
        'dictionary': dictionary,
        'authoritativeBrowserTiming': False,
        'comparativeTiming': False,
        'scope': 'Names applied to an already-recorded baseline Node inspector diagnostic; no new performance run.',
        'boundaries': [
            'Policy3 grouping, executionConcurrency1; no concurrent worker scheduling claim.',
            'Decoded source input; ZIP inflation, real worker IPC, storage and complete import excluded.',
            'Outer adapter elapsed includes input slices; do not label it production parser elapsed.',
            'Self-sample times are sampling estimates; inclusive product counters overlap and must not be summed.',
            'Harness input slicing, SHA oracle, inspector stop and garbage collection remain visible and are not attributed to a candidate.',
            'Profile predates owned-column adoption; no post-adoption CPU claim.',
        ],
        'sourceSha': result['sourceSha'], 'wasmSha256': result['wasmSha256'],
        'archiveSha256': result['archiveSha256'], 'lockSha256': result['lockSha256'],
        'runnerSha256': result['runnerSha256'], 'node': result['node'],
        'symbolProof': identity(proof_file),
        'originalFiles': [identity(file) for file in files.values()],
        'rows': result['rows'], 'banks': result['banks'], 'groups': result['groups'],
        'decodedSourceBytes': result['totalBytes'],
        'workerCountPolicy': result['workerCountPolicy'], 'executionConcurrency': result['workerParallelism'],
        'wholeIndexGroups': sum(bool(row['wholeIndex']) for row in observations),
        'compactMetadataGroups': sum(bool(row['contentMetaByUniqueIndex']) for row in observations),
        'elapsedSumMsIncludesAdapterInputSlices': sum(row['elapsedMs'] for row in observations),
        'counterSumsDoNotAddTogether': {field: sum(row['profile'].get(field, 0) for row in observations) for field in counter_fields},
        'maxWasmHeapBytes': max(row['profile'].get('maxWasmHeapBytes', 0) for row in observations),
        'selfSamples': hotspots,
    }
    (OUT / (dictionary + '-named-attribution.json')).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'dictionary': dictionary, 'rows': result['rows'], 'groups': result['groups'], 'counterSums': report['counterSumsDoNotAddTogether'], 'topNativeSelfSamples': [row for row in hotspots if 'nativeFunctionName' in row][:8]}), flush=True)
entries = [identity(file) for file in sorted(OUT.rglob('*')) if file.is_file()]
(OUT / 'MANIFEST.json').write_text(json.dumps({'format': 1, 'purpose': 'Pinned native symbol proof and attributed baseline diagnostics', 'entries': entries}, indent=2) + '\n')
print(json.dumps({'destination': str(OUT), 'files': len(entries), 'bytes': sum(entry['bytes'] for entry in entries)}), flush=True)
