#!/usr/bin/env python3
"""Package exact readback bytes; no workload or browser acquisition."""

import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob_sha(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


root = Path(__file__).resolve().parent
names = ["README.md", "SAMPLING-NOTE.md", "analyze.py", "analyze-v1-failed-mapper.py",
         "audit-sampling-gaps.py", "build-archive.py", "verify-archive.py",
         "compressed-profile-gap-audit.json", "canonical-profile-gap-audit.json",
         "independent-readback-v2.json", "readback-v1.log", "readback-v2.log",
         "readback-v1/analysis-failure.json"]
names += [str(path.relative_to(root)) for dirname in ["readback-v2", "references"]
          for path in (root / dirname).rglob("*") if path.is_file()]
assert len(names) == len(set(names))
entries = []
for name in sorted(names):
    path = root / name
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    entries.append({"path": name, "bytes": len(data), "sha256": sha(data), "gitBlobSha": blob_sha(data)})
contents = {"schemaVersion": 1, "complete": True, "newAcquisition": False,
            "scope": "Existing browser baseline trace, exact readback, independent audit, primary references, and additive Node endpoint correction",
            "files": entries, "fileCount": len(entries), "payloadBytes": sum(entry["bytes"] for entry in entries),
            "exclusions": ["Original two product ZIPs (complete hashes and inventories retained)",
                           "Original outer ZIP (fixed source artifact identity retained)",
                           "Duplicate raw members from the failed first offline mapper invocation"]}
contents_bytes = (json.dumps(contents, indent=2, sort_keys=True) + "\n").encode()
archive_path = root / "evidence.tar.gz"
assert not archive_path.exists() and not (root / "ARCHIVE-MANIFEST.json").exists()
with archive_path.open("xb") as output:
    with gzip.GzipFile(fileobj=output, mode="wb", filename="", mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.USTAR_FORMAT) as archive:
            for name in ["CONTENTS.json"] + [entry["path"] for entry in entries]:
                data = contents_bytes if name == "CONTENTS.json" else (root / name).read_bytes()
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                info.uid = info.gid = 0
                archive.addfile(info, io.BytesIO(data))
archive_bytes = archive_path.read_bytes()
manifest = {**contents, "contentsSha256": sha(contents_bytes), "archive": {
    "path": archive_path.name, "bytes": len(archive_bytes), "sha256": sha(archive_bytes), "gitBlobSha": blob_sha(archive_bytes)}}
(root / "ARCHIVE-MANIFEST.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
print(json.dumps({"fileCount": len(entries), "payloadBytes": contents["payloadBytes"], "archive": manifest["archive"]}))
