# JMdict owned task-turn overlap candidate — 2026-11-19

## Evidence motivating the candidate

The source for these descriptive numbers is `qualification-readonly/handoff-jmdict-receipts.json`, observations A1–A12 only. Every selected observation identifies baseline `d829f5b6e6a75ee8859d38d537d224ec33c4930e`, authoritative timing, no tracing, Chromium 153.0.8010.12, and the locked 15,587,032-byte JMdict ZIP with 526,942 rows. Candidate, warmup, trace, and identical-code control observations are excluded from this phase inventory. This inventory is not a new performance experiment.

| Baseline metric | Median | Observed range |
| --- | ---: | ---: |
| Complete browser import | 1,056.75 ms | 1,009.8–1,085.3 ms |
| Term fast path | 936.5 ms | 889–972 ms |
| Importer chunk sinks | 609.5 ms | 562–689 ms |
| Bulk term addition | 572 ms | 536–645 ms |
| Within-report sink minus bulk residual | 38.5 ms | 26–46 ms |
| Archive and index | 11 ms | 10–13 ms |
| Bulk setup interval before term fast path | 8.5 ms | 7–10 ms |

There are twelve ordered sink callbacks per ordinary import. The importer currently posts and awaits a MessageChannel task after each callback's storage work finishes. Materialization, media work, and serialization are zero or negligible in these observations. The 38.5 ms residual is an **upper bound on the possible post-sink task opportunity**, not an isolated measurement of channel latency. It also includes callback cleanup, progress, bookkeeping, task service, and timer granularity. It must not be advertised as saved work.

Source timing is nested. The 399.9 ms compression median contains waiting while metadata publication and record work proceed. Parser/inflation totals are summed across workers; ordered-sink waiting overlaps work already counted elsewhere. None can be added to the whole-import total. The current startup interval offers little additional headroom beyond the separately studied source prefetch.

## Proposed scheduling change

Only `dictionary-importer.js` changes at runtime. The first native callback keeps its established late task turn. Each subsequent callback starts the same owned turn before its sink and joins both using `Promise.allSettled`. A synchronous, cached, fully deduplicated, or fallback sink cannot complete the callback until its turn runs. No assumption about Worker availability, compression metrics, OPFS, or whether an arbitrary Promise actually suspended execution is used.

The normal multi-block compression path does resolve through Worker message events, but a one-block path uses a microtask around synchronous compression. Failed/unavailable worker pools can fall back to synchronous compression, fully deduplicated chunks need no compression, and queued OPFS appends can return before physical I/O. Those paths rule out a broad flag-based yield removal.

Sink failure has priority over turn failure, and both owners settle before callback completion. Cancellation is checked at chunk entry and completion. A private per-read `successfulOverlap` witness is cleared at callback entry and set only after that callback successfully overlaps its turn. Trailing empty groups leave it intact. While it is true, the importer retains a terminal turn before source release and any later publication, including when the parser subsequently rejects. A later failed sink clears the witness and retains its original error without acquiring a new terminal turn. A failure of that error-path fence cannot replace the original read/parser/sink error. The existing outer catch gives cancellation precedence once its task has actually delivered it.

Zero-callback reads still post zero tasks; one-callback reads still post exactly one late task. A successful twelve-callback read posts thirteen tasks: the first late turn, eleven overlapped turns, and the terminal fence. This changes scheduling without increasing source lead, worker counts, cache budgets, chunk sizes, or compression levels. No source-prefetch candidate code is included.

## Responsiveness and lifetime argument

Every successful callback still completes a genuine owned MessageChannel turn. If a turn runs while its sink is awaiting I/O, the remaining sink continuation and the next callback's synchronous prefix can run before the next mandatory turn. Thus a cancellation queued just after an early turn may allow one additional sink to be admitted compared with a late-turn policy. The path cannot drain arbitrarily many ready chunks through Promise microtasks. Existing bounded chunks remain unchanged, and delivered cancellation is checked before another callback completes. This is a bounded task-opportunity argument, not a hard wall-clock responsiveness guarantee.

The final fence preserves a cancellation-delivery opportunity when the last successful callback was not the final parser group, including empty trailing groups and an already-ready trailing parser error. Parser loans remain owned until each sink and turn drain. The source pipeline, archive and import session remain owned through the terminal fence. No publication is allowed past a delivered cancellation.

The isolated integration tests use real ZIP parsing, importer callbacks, cancellation and session cleanup. Native computation is replaced with already-ready chunk callbacks whose loans are observed until callback completion; a controlled MessageChannel queue separates tasks from microtasks. Existing parser tests supply real worker/loan coverage. The tests cover zero/one-callback turn counts, ready sinks, pending sinks, entry and late cancellation, empty trailing groups, error-path final fencing, and original-error precedence.

## Qualification and limits

No candidate benchmark has run. Complete browser import timing remains authoritative. The importer chunk-sink counter will exclude the final fence outside the native reader, although the term-fast-path and complete import boundaries include it; phase shifts alone cannot establish improvement. Synchronous multi-callback imports can pay an additional terminal turn and therefore need a negative-control lane. Memory, persistence/reopen, recovery, exact rows/content, cross-browser performance and representative fallback behavior still require qualification.

The open-PR inventory was checked through GitHub GET reads. PRs 758–764 cover cache copies/publication, native row/key reuse, component tooling, exact-cache preflight, final-cache-copy avoidance, and resolved record-field dispatch. None implements this task-turn scheduling change. PR 765 contains the separate source-copy/prefetch study. No candidate code or raw results from those experiments are pooled with this proposal.

Validation receipts in this directory retain all commands and outcomes, including exploratory formatting failures and an initially undelivered test-only failure fence. Final verification and source hashes are recorded separately when the candidate freezes.

## Frozen local validation

Commit `52a0108053837ff7a504c256606570e397ab93b0`, tree `92b35a642477e5a8161298e8c2e5d1881430508a`, has exactly one changed product file plus its regression test. Seven focused files pass 331 tests, including 17 new cases. Scoped ESLint, main TypeScript, the required test TypeScript project, all seven dry-build targets, and source/artifact checks pass. All five bundled WASM files equal baseline. Five deliberately altered implementations fail their expected regression assertions: the original late-turn source, missing per-chunk task, missing success fence, missing failure fence, and sticky success witness. Candidate bytes were restored and verified before the local commit. The full unit suite completed at 23:39:06 UTC: 617 files, 13,683 tests passed, 47 skipped, exit 0. It used Node v24.22.3 and the pinned LLVM/LLD 21.1.8 environment with one worker. Commit/tree, both changed source hashes, and all five baseline-equal WASM files were verified again after the suite. Browser qualification remains pending.
