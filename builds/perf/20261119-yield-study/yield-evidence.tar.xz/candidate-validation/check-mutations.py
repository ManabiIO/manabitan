from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess


root = Path(__file__).resolve().parents[4]
out = Path(__file__).resolve().parent
source = root / 'ext/js/dictionary/dictionary-importer.js'
candidate = source.read_bytes()
text = candidate.decode()
baseline = subprocess.check_output([
    'git', 'show',
    'd829f5b6e6a75ee8859d38d537d224ec33c4930e:ext/js/dictionary/dictionary-importer.js',
], cwd=root)

per_chunk = 'const pendingTurn = streamedFastPathChunkCount > 1 ? eventLoopYielder.yield() : null'
terminal = '''                        if (successfulOverlap) {
                            await eventLoopYielder.yield()
                            this._throwIfCancelled()
                        }
'''
failure = '''                            if (successfulOverlap) {
                                // Keep the original failure'''
assert text.count(per_chunk) == 1
assert text.count(terminal) == 1
assert text.count(failure) == 1
reset = '                                successfulOverlap = false\n'
assert text.count(reset) == 1

mutations = [
    ('baseline-late-turn', baseline, 'overlaps the turn with an asynchronous sink'),
    ('missing-per-chunk-turn', text.replace(per_chunk, per_chunk.replace('eventLoopYielder.yield()', 'Promise.resolve()')).encode(), 'ready sinks cannot drain'),
    ('missing-success-terminal', text.replace(terminal, '').encode(), 'retains a terminal cancellation opportunity'),
    ('missing-failure-terminal', text.replace(failure, failure.replace('if (successfulOverlap)', 'if (false)')).encode(), 'delivers queued cancellation before reporting a trailing ready parser failure'),
    ('sticky-success-witness', text.replace(reset, '').encode(), 'a later failed sink preserves its error without acquiring a new terminal turn'),
]
receipts = []
try:
    for name, mutated, selection in mutations:
        source.write_bytes(mutated)
        command = [
            'node', '--max-old-space-size=1536', 'node_modules/vitest/vitest.mjs',
            'run', '--maxWorkers', '1', 'test/dictionary-importer-task-turn.test.js',
            '-t', selection,
        ]
        receipt = {
            'purpose': 'regression sensitivity; not performance evidence',
            'mutation': name,
            'command': command,
            'cwd': str(root),
            'candidateSourceSha256': hashlib.sha256(candidate).hexdigest(),
            'mutatedSourceSha256': hashlib.sha256(mutated).hexdigest(),
            'expectedExitCode': 1,
            'startedAt': datetime.now(timezone.utc).isoformat(),
            'status': 'running',
            'output': name + '.log',
        }
        path = out / (name + '.command.json')
        path.write_text(json.dumps(receipt, indent=2) + '\n')
        with (out / (name + '.log')).open('w') as log:
            result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT, timeout=30)
        output = (out / (name + '.log')).read_text(errors='replace')
        receipt.update(
            status='completed',
            completedAt=datetime.now(timezone.utc).isoformat(),
            exitCode=result.returncode,
            expectedAssertionFailureObserved=result.returncode == 1 and 'AssertionError' in output,
        )
        path.write_text(json.dumps(receipt, indent=2) + '\n')
        receipts.append(receipt)
        print(name, 'expected assertion failure:', receipt['expectedAssertionFailureObserved'], flush=True)
        if not receipt['expectedAssertionFailureObserved']:
            print(output, flush=True)
            raise SystemExit(1)
finally:
    source.write_bytes(candidate)
    (out / 'mutation-summary.json').write_text(json.dumps({
        'candidateRestored': source.read_bytes() == candidate,
        'candidateSourceSha256': hashlib.sha256(candidate).hexdigest(),
        'checks': receipts,
    }, indent=2) + '\n')
