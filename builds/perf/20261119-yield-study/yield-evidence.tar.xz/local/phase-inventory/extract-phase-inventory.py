#!/usr/bin/env python3
"""Extract existing first-study A receipts; does not launch or time imports."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
import zipfile


BASE_COMMIT = "d829f5b6e6a75ee8859d38d537d224ec33c4930e"
BASE_TREE = "841406cd33f6871ab24aee771c1a7881d9e465f0"
FIXTURE_SHA256 = "7681ee09f9edfef48a5e50773565da237424eb750bdb0e1e59660784ecd53e8a"
ARCHIVES = (
    ("chromium-forward", "jmdict-study-chromium-forward-44633675935.zip", "0cdfc9d2680bcb21fa38f13fe2a90f93ecd271ca372d077a22c2063c41130186"),
    ("chromium-reverse", "jmdict-study-chromium-reverse-44633675935.zip", "5632cd6eef0b471f17097f1b841710068c9f0d67453826a62c2395d4e55db88a"),
    ("firefox-forward", "firefox-forward-14585921242.zip", "d93ac4f3bc206544eb5c0180c107848f70a23470b471e75f19a7689397b58da4"),
    ("firefox-reverse", "firefox-reverse-14585631194.zip", "480a103c2d6523ab8e2dd137ccf7c4f462f30eb4f237b491848fe6de92d24e4e"),
)
HOST_KEYS = (
    "cpuModel", "logicalCpuCount", "availableParallelism", "totalMemoryBytes",
    "nodeVersion", "v8Version", "platform", "arch", "cgroupCpuMax",
    "cgroupCpuQuotaCores", "cgroupMemoryMaxBytes",
)
METRIC_NOTES = {
    "totalImportMs": "Authoritative complete UI import boundary for this browser helper; compare only within its cell/protocol.",
    "workerImportMs": "Nested worker import wall time; not additive with complete import.",
    "termFastPathMs": "Nested complete term-reader phase including ordered sinks and parser waits.",
    "setupBeforeTermMs": "Difference of term phase and import-data-banks start epochs; a descriptive interval, not an isolated setup function timer.",
    "importerChunkSinkMs": "Sum of serialized importer callback durations; contains bulk term addition, bookkeeping and late task turns.",
    "bulkAddTermsMs": "Nested bulk term sink wall time; content and record work overlap inside it.",
    "sinkMinusBulkMs": "Per-observation subtraction before summary; upper bound on non-bulk callback work, not isolated MessageChannel latency or saved work.",
    "dedupScanMs": "Dedup resolution wall time before this chunk's content persistence begins; contains capacity, canonical and exact-match work.",
    "dedupCanonicalScanMs": "Canonical wrapper wall time minus exact-match time; includes module load/instantiation, input staging, native scan/reservation and output adoption. These subphases are not timed separately.",
    "dedupExactCompareMs": "Nested exact-match wall time, including recent/in-flight source checks and persisted-reader fallback; does not isolate I/O, checksum or decompression.",
    "termRecordValidationMs": "Run validation plus encoder-reported validation; record branch can overlap content compression. Entire phase is an optimization ceiling, not a measured exposed saving.",
    "contentCompressMs": "Compression wall time includes waiting while metadata and record work proceed; not exclusive CPU time.",
    "contentAppendMs": "Nested content branch boundary; can overlap record append and includes earlier dedup resolution.",
    "contentMetadataIndexPublishMs": "Contains recent-source cache publication; do not add dedupRecentSourceCacheMs to it.",
    "bulkMinusContentAppendMs": "Per-observation subtraction; residual includes work outside the content branch and bookkeeping, not an isolated record-validation tail.",
    "metadataPublishMinusIndexMs": "Per-observation subtraction; not isolated in-flight validation and includes other publication work covered by concurrent PRs.",
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def digest_file(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def numeric(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def summarize(values):
    require(len(values) == 24 and all(numeric(x) for x in values), "Expected 24 finite values")
    return {
        "n": len(values),
        "median": statistics.median(values),
        "observedRange": {"min": min(values), "max": max(values)},
        "intervalKind": "observed-min-max-not-confidence-interval",
    }


def only_phase(phases, predicate):
    matches = [phase for phase in phases if predicate(phase["phase"])]
    require(len(matches) == 1, "Expected exactly one matching phase")
    return matches[0]


def normalize(summary):
    require(summary["authoritativeTiming"] is True, "Non-authoritative observation")
    fixture = summary["fixture"]
    require(fixture["sha256"] == FIXTURE_SHA256, "Fixture hash changed")
    require(fixture["sizeBytes"] == 15587032 and fixture["termRows"] == 526942, "Fixture work changed")
    if "runs" in summary:
        require(len(summary["runs"]) == 1, "Expected one Chromium run")
        require(summary["gitSha"] == BASE_COMMIT and summary["source"]["gitSha"] == BASE_COMMIT, "Chromium source changed")
        require(summary["traceEnabled"] is False and summary["importFlags"] is None, "Chromium policy changed")
        run = summary["runs"][0]
        return {
            "phases": run["importDebug"]["importerPhaseTimings"],
            "totalImportMs": run["totalImportMs"],
            "workerImportMs": run["workerImportMs"],
            "browserVersion": summary["browserVersion"],
            "host": summary["hostEnvironment"],
            "source": summary["source"],
            "packageSha256": run["packageSha256"],
            "productionEnvironment": {"importFlags": summary["importFlags"], "traceEnabled": summary["traceEnabled"]},
        }
    require(summary["completed"] is True and summary["error"] is None, "Firefox run did not complete successfully")
    require(summary["skippedVerification"] is False, "Firefox verification skipped")
    require(summary["source"]["commit"] == BASE_COMMIT and summary["source"]["tree"] == BASE_TREE, "Firefox source changed")
    environment = summary["productionEnvironment"]
    require(environment["profiling"] is False and environment["flags"] is None, "Firefox policy changed")
    return {
        "phases": summary["importResult"]["debug"]["importerPhaseTimings"],
        "totalImportMs": summary["totalImportMs"],
        "workerImportMs": summary["workerImportMs"],
        "browserVersion": summary["browser"]["version"],
        "host": summary["hostBefore"],
        "source": summary["source"],
        "packageSha256": summary["package"]["sha256"],
        "productionEnvironment": environment,
    }


def extract_cell(archive_dir, cell_id, filename, expected_sha256):
    path = archive_dir / filename
    actual_sha256 = digest_file(path)
    require(actual_sha256 == expected_sha256, f"Archive changed: {filename}")
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), "Duplicate ZIP member names")
        cohort_raw = archive.read("cohort.json")
        cohort = json.loads(cohort_raw)
        preparation_raw = archive.read("preparation.json")
        preparation = json.loads(preparation_raw)
        require(cohort["complete"] is True and cohort["failures"] == [], "Incomplete or failed cohort")
        require(preparation["complete"] is True, "Incomplete preparation")
        require(cell_id == f"{cohort['browser']}-{cohort['replication']}", "Cell identity changed")
        arm = preparation["arms"]["A"]
        require(arm["commit"] == BASE_COMMIT and arm["tree"] == BASE_TREE, "Preparation baseline changed")
        expected_labels = {f"block-{i:02d}-A" for i in range(1, 25)}
        selected = [item for item in cohort["observations"] if item["arm"] == "A" and item["warmup"] is False]
        planned = [item for item in cohort["planned"] if item["arm"] == "A" and item["warmup"] is False]
        require(len(selected) == 24 and {item["label"] for item in selected} == expected_labels, "Measured A observations changed")
        require(len(planned) == 24 and {item["label"] for item in planned} == expected_labels, "Planned A observations changed")
        observations = []
        for item in sorted(selected, key=lambda x: x["block"]):
            require(item["label"] == f"block-{item['block'] + 1:02d}-A", "Block identity changed")
            require(item["directory"] == f"observations/{item['label']}", "Observation directory changed")
            member = item["directory"] + "/summary.json"
            raw = archive.read(member)
            run = normalize(json.loads(raw))
            require(run["packageSha256"] == arm["packageSha256"], "Observation package differs from preparation")
            require(run["totalImportMs"] == item["totalImportMs"], "Cohort timing differs from raw summary")
            phases = run.pop("phases")
            term = only_phase(phases, lambda p: p.startswith("term-file-fast-path:"))
            banks = only_phase(phases, lambda p: p == "import-data-banks")
            finalization = only_phase(phases, lambda p: p == "bulk-finalization")
            details = term["details"]
            require(details["rows"] == 526942 and details["chunkCount"] == 12 and details["batchedFileCount"] == 53, "Term work changed")
            require(details["sourceInitialPrefetchFileCount"] == 0, "A unexpectedly prefetched first source")
            metrics = {key: value for key, value in details.items() if key.endswith("Ms") and numeric(value)}
            metrics.update({
                "totalImportMs": run["totalImportMs"],
                "workerImportMs": run["workerImportMs"],
                "termFastPathMs": term["elapsedMs"],
                "archiveAndIndexMs": only_phase(phases, lambda p: p == "archive-and-index")["elapsedMs"],
                "bulkFinalizationMs": finalization["elapsedMs"],
                "setupBeforeTermMs": term["startEpochMs"] - banks["startEpochMs"],
                "sinkMinusBulkMs": details["importerChunkSinkMs"] - details["bulkAddTermsMs"],
                "bulkMinusContentAppendMs": details["bulkAddTermsMs"] - details["contentAppendMs"],
                "metadataPublishMinusIndexMs": details["contentMetadataPublishMs"] - details["contentMetadataIndexPublishMs"],
            })
            metrics.update({f"finalization.{key}": value for key, value in finalization["details"].items() if key.endswith("Ms") and numeric(value)})
            counters = {key: value for key, value in details.items() if not key.endswith("Ms") and numeric(value)}
            counters["successfulPersistedMatchesNotRecentSourceHits"] = details["dedupPersistedHitCount"] - details["dedupRecentSourceHitCount"]
            observations.append({
                "label": item["label"], "block": item["block"], "arm": "A", "warmup": False,
                "summaryMember": member, "summarySha256": sha256(raw),
                "metricsMs": metrics, "counters": counters,
                "host": run["host"], "browserVersion": run["browserVersion"],
                "source": run["source"], "packageSha256": run["packageSha256"],
                "productionEnvironment": run["productionEnvironment"],
                "parserExperiments": details["parserExperiments"],
            })
        for field in ("metricsMs", "counters"):
            expected_keys = set(observations[0][field])
            require(all(set(x[field]) == expected_keys for x in observations), f"{field} schema changed within cell")
        host_identities = {json.dumps({key: x["host"].get(key) for key in HOST_KEYS}, sort_keys=True) for x in observations}
        require(len(host_identities) == 1, "Multiple host identities within cell")
        browser_versions = sorted({x["browserVersion"] for x in observations})
        require(len(browser_versions) == 1, "Multiple browser versions within cell")
        return {
            "cellId": cell_id, "browser": cohort["browser"], "replication": cohort["replication"],
            "selection": {"arm": "A", "warmup": False, "n": 24, "blocks": list(range(1, 25))},
            "archive": {"filename": filename, "sizeBytes": path.stat().st_size, "sha256": actual_sha256},
            "cohortSha256": sha256(cohort_raw), "preparationSha256": sha256(preparation_raw),
            "manifestSha256": cohort["manifestSha256"], "preparedBaseline": arm,
            "boundary": cohort["boundary"], "policy": cohort["policy"],
            "hostIdentity": json.loads(next(iter(host_identities))), "browserVersions": browser_versions,
            "summaryMs": {key: summarize([x["metricsMs"][key] for x in observations]) for key in sorted(observations[0]["metricsMs"])},
            "descriptivePhaseFractionPercent": {
                key: summarize([x["metricsMs"][key] / x["metricsMs"]["totalImportMs"] * 100 for x in observations])
                for key in ("dedupCanonicalScanMs", "dedupExactCompareMs", "termRecordValidationMs")
            },
            "counterValues": {key: sorted({x["counters"][key] for x in observations}) for key in sorted(observations[0]["counters"])},
            "observations": observations,
        }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--archive-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = {
        "schemaVersion": 1,
        "study": "first-study-round2-source-copy-and-prefetch-baseline-phase-inventory",
        "analysisKind": "read-only-descriptive-extraction-no-new-timing",
        "extractorSha256": digest_file(Path(__file__)),
        "baseline": {"commit": BASE_COMMIT, "tree": BASE_TREE},
        "fixture": {"sha256": FIXTURE_SHA256, "sizeBytes": 15587032, "termRows": 526942},
        "selectionPolicy": "Exactly 24 non-warmup A observations per cell; no B/C/D or warmups; no host/browser/order pooling.",
        "statisticsPolicy": "Median and observed min-max from raw values; ranges are not confidence intervals. Subtractions and fractions are calculated per observation before summarizing.",
        "interpretation": {
            "timers": "Durations are nested wall/aggregate counters, not additive exclusive costs. A phase duration is at most an optimization ceiling, not expected savings.",
            "workerTimers": "Parser worker counters can sum overlapping workers; do not add them to whole import.",
            "canonicalAttribution": "Existing metrics do not isolate module compilation/instantiation, input staging, native scan or output adoption.",
            "adoptionCopyCaveat": "dedupNativeCopiedOutputBytes counts the exact-descriptor slice only. Pending-column adoption also copies owned columns; adoptedColumnBytes is internal and not exported by CANONICAL_SCAN_METRICS.",
            "cachePathCaveat": "Persisted hits minus recent-source hits identifies successful matches outside the recent-source cache; it is not a file-read count, block count or isolated decompression cost.",
            "chromiumSourceMarker": "Chromium source.dirty is retained verbatim. Preparation commit/tree, package hashes and frozen-input receipts are preserved; this extraction does not relabel the source clean.",
        },
        "metricNotes": METRIC_NOTES,
        "cells": [extract_cell(args.archive_dir, *item) for item in ARCHIVES],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"output": str(args.output), "sha256": digest_file(args.output), "cells": len(result["cells"]), "observationsPerCell": 24}))


if __name__ == "__main__":
    main()
