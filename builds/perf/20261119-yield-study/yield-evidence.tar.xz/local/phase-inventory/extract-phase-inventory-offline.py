#!/usr/bin/env python3
"""Reproduce the frozen inventory from verified tar payloads, without ZIP files.

The compatibility layer exposes the original ZIP's *recorded identity* to the
frozen extractor. It never claims to hash a ZIP container that is not present.
The actual tar container and every consumed member are hashed independently.
"""

import argparse
import hashlib
import json
from pathlib import Path
import sys
import tarfile
import types
import zlib


EXPECTED_TAR_SHA256 = "e7f8be4c29ff90c212bac8960ec119b3432e9cf4e47531492849d77f008c047c"
EXPECTED_EXTRACTOR_SHA256 = "dfa23c5c17fd1eda7024fddfdfebe55274d44ddd29c37ccf12e1934fdb5ee397"
EXPECTED_INVENTORY_SHA256 = "56f9b30e48d76cd75767044082138156056d51be5a994bacf7582d866548b500"
PREFIXES = ("chromium-forward", "chromium-reverse", "firefox-forward", "firefox-reverse")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def file_sha256(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


class RecordedZipIdentity:
    """Historical container metadata authenticated by the preserved tar index."""

    def __init__(self, source):
        self.source = source

    def stat(self):
        return types.SimpleNamespace(st_size=self.source["bytes"])


class PayloadDirectory:
    def __init__(self, identities):
        self.identities = identities

    def __truediv__(self, filename):
        return self.identities[filename]


class VerifiedPayloadArchive:
    def __init__(self, identity, index, payloads):
        require(isinstance(identity, RecordedZipIdentity), "An actual ZIP path was not expected")
        self.prefix = identity.source["prefix"]
        self.payloads = payloads
        self.entries = [
            entry["source"]["entry"] for entry in index["files"].values()
            if entry.get("source", {}).get("zip") == self.prefix
        ]

    def __enter__(self):
        return self

    def __exit__(self, *_):
        return False

    def namelist(self):
        return self.entries

    def read(self, entry):
        return self.payloads[f"{self.prefix}/{entry}"]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path, required=True)
    parser.add_argument("--evidence-receipt", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--verification-output", type=Path, required=True)
    parser.add_argument("--extractor", type=Path, default=Path(__file__).with_name("extract-phase-inventory.py"))
    parser.add_argument("--expected-inventory", type=Path, default=Path(__file__).with_name("phase-inventory.json"))
    args = parser.parse_args()
    original_argv = list(sys.argv)
    require(args.output.resolve() != args.expected_inventory.resolve(), "Do not overwrite the frozen inventory")
    require(args.verification_output.resolve() != args.expected_inventory.resolve(), "Do not overwrite the frozen inventory")

    receipt_bytes = args.evidence_receipt.read_bytes()
    receipt = json.loads(receipt_bytes)
    actual_tar_sha256 = file_sha256(args.evidence)
    require(actual_tar_sha256 == EXPECTED_TAR_SHA256 == receipt["archiveSha256"], "Evidence tar hash changed")
    require(args.evidence.stat().st_size == receipt["archiveBytes"], "Evidence tar size changed")
    source_code = args.extractor.read_bytes()
    require(sha256(source_code) == EXPECTED_EXTRACTOR_SHA256, "Frozen extractor changed")
    module = types.ModuleType("frozen_phase_extractor")
    module.__file__ = str(args.extractor.resolve())
    exec(compile(source_code, module.__file__, "exec"), module.__dict__)

    required = {
        f"{prefix}/{entry}" for prefix in PREFIXES
        for entry in ["cohort.json", "preparation.json"] + [f"observations/block-{i:02d}-A/summary.json" for i in range(1, 25)]
    }
    index_name = receipt["indexMember"]
    payloads = {}
    member_names = set()
    index_bytes = None
    with tarfile.open(args.evidence, "r|xz") as archive:
        for member in archive:
            require(member.name not in member_names, "Duplicate tar member")
            require(member.isfile(), "Non-file tar member is not supported")
            member_names.add(member.name)
            if member.name == index_name or member.name in required:
                handle = archive.extractfile(member)
                require(handle is not None, "Missing tar member payload")
                with handle:
                    data = handle.read()
                require(len(data) == member.size, "Truncated tar member")
                if member.name == index_name:
                    index_bytes = data
                else:
                    payloads[member.name] = data
    require(index_bytes is not None, "Missing evidence index")
    index = json.loads(index_bytes)
    require(member_names == set(index["files"]) | {index_name}, "Missing or extra indexed tar members")
    require(set(payloads) == required, "Missing required phase payloads")
    require(len(index["files"]) == receipt["payloadFiles"], "Payload inventory count differs from receipt")
    require(sum(x["bytes"] for x in index["files"].values()) == receipt["payloadBytes"], "Payload inventory size differs from receipt")

    payload_checks = {}
    for name, data in sorted(payloads.items()):
        item = index["files"][name]
        prefix, entry = name.split("/", 1)
        require(item["source"]["zip"] == prefix and item["source"]["entry"] == entry, "Payload source mapping changed")
        digest = sha256(data)
        require(len(data) == item["bytes"] and digest == item["sha256"], "Payload size/hash changed")
        require(zlib.crc32(data) & 0xffffffff == item["source"]["crc32"], "Recorded ZIP-entry CRC changed")
        payload_checks[name] = {"bytes": len(data), "sha256": digest, "sha256AndCrc32Verified": True}

    sources = [source for source in index["sources"] if source["kind"] == "zip"]
    require(sources == receipt["sourceZips"], "Recorded original ZIP identities disagree")
    identities = {Path(source["path"]).name: RecordedZipIdentity(source) for source in sources}
    require(len(identities) == 4, "Expected exactly four original ZIP identities")
    for prefix, filename, expected_hash in module.ARCHIVES:
        source = identities[filename].source
        require(source["prefix"] == prefix and source["sha256"] == expected_hash, "Recorded ZIP identity changed")

    # Reuse every selection, source, fixture, package, metric and summary check.
    # Only file transport is adapted. Returning recorded ZIP metadata here is
    # intentional; the separate receipt labels it as recorded, not rehashed.
    original_digest = module.digest_file
    module.digest_file = lambda path: path.source["sha256"] if isinstance(path, RecordedZipIdentity) else original_digest(path)
    module.zipfile = types.SimpleNamespace(ZipFile=lambda identity: VerifiedPayloadArchive(identity, index, payloads))
    original_extract_cell = module.extract_cell
    directory = PayloadDirectory(identities)
    module.extract_cell = lambda _unused_directory, *spec: original_extract_cell(directory, *spec)
    try:
        sys.argv = [str(args.extractor), "--archive-dir", "verified-tar-payloads", "--output", str(args.output)]
        module.main()
    finally:
        sys.argv = original_argv

    reproduced = args.output.read_bytes()
    require(sha256(reproduced) == EXPECTED_INVENTORY_SHA256, "Reproduced inventory differs from frozen digest")
    expected_bytes = args.expected_inventory.read_bytes()
    require(sha256(expected_bytes) == EXPECTED_INVENTORY_SHA256, "Expected frozen inventory changed")
    require(reproduced == expected_bytes, "Reproduction is not byte-for-byte equal")
    result = {
        "schemaVersion": 1,
        "activity": "Offline reproduction from preserved payloads; no imports, timing cohorts, network access or original ZIP opens",
        "command": original_argv,
        "adapterSha256": file_sha256(Path(__file__)),
        "frozenExtractorSha256": EXPECTED_EXTRACTOR_SHA256,
        "evidenceTar": {"file": args.evidence.name, "sha256": actual_tar_sha256, "verification": "directly hashed preserved tar container"},
        "evidenceReceiptSha256": sha256(receipt_bytes),
        "index": {"member": index_name, "sha256": sha256(index_bytes), "authentication": "contained in the directly hash-verified tar"},
        "originalZipIdentities": [{**source, "verification": "historical ZIP container identity recorded in authenticated index; ZIP container bytes are absent and were not rehashed"} for source in sources],
        "requiredPayloadCount": len(payload_checks),
        "requiredPayloads": payload_checks,
        "archiveStructure": "all member names match the index; no duplicate, missing, extra or non-file members",
        "originalZipContainersOpened": 0,
        "zipContainersReconstructed": False,
        "inventorySha256": sha256(reproduced),
        "byteForByteEqual": True,
        "provenanceFormatDifferences": [],
        "provenanceNote": "Inventory bytes retain the historical original-ZIP identity fields. This companion receipt records that reproduction authenticated tar/member payloads rather than directly hashing original ZIP containers.",
        "exitCode": 0,
    }
    args.verification_output.parent.mkdir(parents=True, exist_ok=True)
    args.verification_output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"offlineReproduction": "byte-for-byte equal", "payloadsVerified": len(payload_checks), "verification": str(args.verification_output)}))


if __name__ == "__main__":
    main()
