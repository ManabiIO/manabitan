#!/usr/bin/env python3
"""Read one retained Firefox yield-study artifact; validate receipts and all four comparisons."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import statistics
import zipfile


parser = argparse.ArgumentParser()
parser.add_argument("archive", type=Path)
parser.add_argument("--sha256", required=True)
args = parser.parse_args()
archive_digest = hashlib.sha256(args.archive.read_bytes()).hexdigest()
assert archive_digest == args.sha256
with zipfile.ZipFile(args.archive) as archive:
    assert archive.testzip() is None
    read = lambda name: json.loads(archive.read(name))
    cohort = read("cohort.json")
    preparation = read("preparation.json")
    manifest = read("manifest.json")
    assert cohort["complete"] is True and cohort["failures"] == []
    assert preparation["complete"] is True
    assert preparation["diagnosticCommit"] == "999c08aded15c901e6862e04f7bd36922e3fd51f"
    assert len(cohort["observations"]) == len(cohort["planned"]) == 104
    assert [o["label"] for o in cohort["observations"]] == [o["label"] for o in cohort["planned"]]
    assert hashlib.sha256(archive.read("manifest.json")).hexdigest() == cohort["manifestSha256"] == preparation["manifestSha256"]
    archived_names = set(archive.namelist())
    missing_tooling = sorted(name for name in manifest["harnessSha256"] if f"tooling/{name}" not in archived_names)
    assert set(missing_tooling) <= {".github/actions/setup/action.yml", manifest["workflow"]}
    for name, expected_hash in manifest["harnessSha256"].items():
        if name not in missing_tooling:
            assert hashlib.sha256(archive.read(f"tooling/{name}")).hexdigest() == expected_hash
    assert hashlib.sha256(archive.read("workflow.yml")).hexdigest() == manifest["harnessSha256"][manifest["workflow"]]
    supplement_receipt = None
    if missing_tooling:
        supplement_root = args.archive.parent / "measured-tooling-supplement"
        supplement_path = supplement_root / "sources.json"
        supplement = json.loads(supplement_path.read_text())
        assert supplement["measuredCommit"] == preparation["diagnosticCommit"]
        assert supplement["measuredTree"] == "5d65b96a2fdbb14023c6596341a7e6ace75f9942"
        assert supplement["manifestSha256"] == cohort["manifestSha256"]
        for name in missing_tooling:
            item = supplement["files"][name]
            contents = (supplement_root / item["supplementFile"]).read_bytes()
            assert len(contents) == item["bytes"]
            assert hashlib.sha256(contents).hexdigest() == item["sha256"] == manifest["harnessSha256"][name]
            assert hashlib.sha1(f"blob {len(contents)}\0".encode() + contents).hexdigest() == item["gitBlob"]
        supplement_receipt = {"path": str(supplement_path.resolve()),
            "sha256": hashlib.sha256(supplement_path.read_bytes()).hexdigest(),
            "measuredCommit": supplement["measuredCommit"], "measuredTree": supplement["measuredTree"],
            "filesVerified": missing_tooling, "embeddedInOriginalArchive": False}
    assert manifest["arms"] == {"A": "baseline", "B": "yield", "C": "baseline", "D": "yield"}
    assert manifest["sources"]["baseline"]["commit"] == "d829f5b6e6a75ee8859d38d537d224ec33c4930e"
    assert manifest["sources"]["yield"]["commit"] == "52a0108053837ff7a504c256606570e397ab93b0"
    runtime = preparation["browserRuntime"]
    package_entries = {arm: read(f"{arm}-package-entries.json") for arm in "ABCD"}
    assert package_entries["A"] == package_entries["C"]
    assert package_entries["B"] == package_entries["D"]
    for arm in ("B", "D"):
        changed = sorted(key for key in set(package_entries["A"]) | set(package_entries[arm])
                         if package_entries["A"].get(key) != package_entries[arm].get(key))
        expected_changes = ["js/dictionary/dictionary-importer.js"]
        assert changed == expected_changes
    summaries = []
    profiles = set()
    for observation in cohort["observations"]:
        label, arm = observation["label"], observation["arm"]
        expected = preparation["arms"][arm]
        summary = read(f"observations/{label}/summary.json")
        command = read(f"commands/{label}/command.json")
        assert command["complete"] is True and command["exitCode"] == 0
        assert summary["completed"] is True and summary["phase"] == "complete"
        assert summary["authoritativeTiming"] is True and summary["skippedVerification"] is False
        assert summary["error"] is None and summary["cleanupErrors"] == [] and summary["diagnosticErrors"] == []
        assert not observation.get("error")
        assert summary["totalImportMs"] == observation["totalImportMs"]
        assert summary["source"]["commit"] == expected["commit"]
        assert summary["source"]["tree"] == expected["tree"]
        assert summary["source"]["packageLockSha256"] == manifest["sharedProductInputs"]["package-lock.json"]
        assert summary["source"]["commonGeneratedOverlay"] == expected["commonGeneratedOverlay"]
        assert summary["package"]["sha256"] == expected["packageSha256"]
        assert summary["runtime"]["binarySha256"] == runtime["binarySha256"]
        assert summary["runtime"]["geckodriverSha256"] == runtime["geckodriver"]["binarySha256"]
        assert summary["runtime"]["node"] == manifest["node"] and summary["runtime"]["headless"] is False
        assert summary["fixture"]["sha256"] == preparation["fixture"]["sha256"]
        assert summary["fixture"]["lockSha256"] == manifest["sharedProductInputs"]["test/perf/dictionaries.lock.json"]
        assert summary["browser"]["freshProfile"] is True and summary["browser"]["suppliedProfile"] is False
        assert summary["browser"]["profile"] not in profiles
        profiles.add(summary["browser"]["profile"])
        assert summary["reload"]["kind"] == "addon-manager-reload-from-browser-chrome"
        assert summary["reload"]["priorOrigin"] != summary["reload"]["nextOrigin"]
        assert summary["reload"]["reimported"] is False
        assert summary["validation"]["extensionReloadVerified"] is True
        assert summary["validation"]["title"] == summary["fixture"]["expectedTitle"]
        assert summary["validation"]["revision"] == summary["fixture"]["revision"]
        expected_semantics = [{k: p[k] for k in ("expression", "reading", "glossary")} for p in summary["fixture"]["probes"]]
        assert len(expected_semantics) == 12
        for phase in ("beforeReload", "afterReload"):
            result = summary[phase]
            assert result["semantics"] == expected_semantics
            assert result["counts"]["counts"][0]["terms"] == 526942
            assert result["probeCount"] == 12
            assert result["storage"]["usesFallbackStorage"] is False
            assert result["storage"]["openStorageDiagnostics"]["mode"] == "opfs-sahpool"
            for digest_name in ("semanticDigest", "storageSampleDigest"):
                assert result[digest_name] == summary["validation"][digest_name]
        environment = summary["productionEnvironment"]
        assert environment["flags"] is None and environment["profiling"] is False
        assert environment["deviceMemory"] is None and environment["hardwareConcurrency"] == 4
        assert len(summary["termFileWork"]) == 1
        counters = summary["termFileWork"][0]["counters"]
        for key in ("parserFusedFallbacks", "parserDiscardedFusedRows", "dedupNativeFallbackCount"):
            assert counters[key] == 0
        assert counters["rows"] == 526942
        assert counters["parserSourceCompressedBytes"] == counters["parserSourceTransferredBytes"] == 15574114
        assert counters["parserSourceUncompressedBytes"] == 171092992
        assert counters.get("sourceInitialPrefetchFileCount", 0) == expected["expectedInitialPrefetchFileCount"]
        summaries.append((observation, summary))
    measured = {(o["block"], o["arm"]): o for o in cohort["observations"] if not o["warmup"]}
    statistics_by_arm = {}
    for label, baseline_arm, arm in (("C/A", "A", "C"), ("D/B", "B", "D"), ("B/A", "A", "B"), ("D/A", "A", "D")):
        baseline = [measured[(block, baseline_arm)]["totalImportMs"] for block in range(24)]
        candidate = [measured[(block, arm)]["totalImportMs"] for block in range(24)]
        changes = [(b / a - 1) * 100 for a, b in zip(baseline, candidate)]
        derived = {
            "medianPairedChangePercent": statistics.median(changes),
            "equalWorkChangePercent": (sum(candidate) / sum(baseline) - 1) * 100,
            "fasterPairs": sum(b < a for a, b in zip(baseline, candidate)),
            "worstPairPercent": max(changes),
        }
        for key, value in derived.items():
            assert math.isclose(value, cohort["statistics"][label][key], abs_tol=1e-10)
        statistics_by_arm[label] = {**derived, "pairs": 24,
            "descriptiveBootstrap95Percent": cohort["statistics"][label]["descriptiveBootstrap95Percent"]}
    for key in ("semanticDigest", "storageSampleDigest"):
        assert len({s["validation"][key] for _, s in summaries}) == 1
    first = summaries[0][1]
    receipt = {
        "archive": str(args.archive.resolve()), "archiveSha256": archive_digest,
        "browser": cohort["browser"], "replication": cohort["replication"],
        "complete": True, "verifiedObservations": len(summaries),
        "warmups": sum(o["warmup"] for o in cohort["observations"]),
        "measured": len(measured), "distinctProfiles": len(profiles),
        "manifestSha256": cohort["manifestSha256"], "diagnosticCommit": preparation["diagnosticCommit"],
        "harnessArchiveCoverage": {"declaredInputs": len(manifest["harnessSha256"]),
            "embeddedDeclaredInputs": len(manifest["harnessSha256"]) - len(missing_tooling),
            "missingToolingPaths": missing_tooling, "embeddedTopLevelWorkflowHashVerified": True,
            "separateSourceSupplement": supplement_receipt,
            "supplementPolicy": "Any measured-source supplement is separate from, and was not embedded in, the unchanged original archive."},
        "baselineControlPackageEntryParity": True,
        "candidateControlPackageEntryParity": True,
        "packageEntryCount": len(package_entries["A"]),
        "sources": {a: {k: p[k] for k in ("commit", "tree", "packageSha256")} for a, p in preparation["arms"].items()},
        "runtime": runtime, "productionEnvironment": first["productionEnvironment"],
        "host": {k: first["hostBefore"][k] for k in ("cpuModel", "logicalCpuCount", "totalMemoryBytes")},
        "validation": first["validation"],
        "firstWarmup": {"label": cohort["observations"][0]["label"], "totalImportMs": first["totalImportMs"], "reload": first["reload"]},
        "largestParserWasmHeapBytes": sorted({s["largestParserWasmHeapBytes"] for _, s in summaries}),
        "statistics": statistics_by_arm,
        "qualification": "Frozen d829f5b baseline and 52a0108 candidate only; effects on current develop are untested. One complete cell; do not pool across hosts or subtract either same-source control. RSS snapshots are not peak-memory evidence."
    }
    destination = args.archive.with_suffix("")
    destination.mkdir(exist_ok=True)
    for name in ("cohort.json", "preparation.json", "manifest.json", "workflow.yml", "driver.py"):
        (destination / name).write_bytes(archive.read(name))
    (destination / "first-warmup-summary.json").write_text(json.dumps(first, indent=2) + "\n")
    output = destination / "independent-audit.json"
    output.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"audit": str(output.resolve()), "observations": len(summaries), "statistics": statistics_by_arm}, indent=2))
