#!/usr/bin/env python3
"""Independently verify the two fixed Chromium cells without pooling samples."""

import argparse
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPOSITORY = ROOT.parents[2] / "manabitan-yield-study"
HEAD = "999c08aded15c901e6862e04f7bd36922e3fd51f"
LOCAL_TOOLING = "999c08aded15c901e6862e04f7bd36922e3fd51f"
MANIFEST_SHA256 = "cbe2f907c567ff3a44e5fc0c43d95757abcfeeecf3aa46e2a482e9dbb2424743"
PRODUCTS = {
    "A": "d829f5b6e6a75ee8859d38d537d224ec33c4930e",
    "B": "52a0108053837ff7a504c256606570e397ab93b0",
    "C": "d829f5b6e6a75ee8859d38d537d224ec33c4930e",
    "D": "52a0108053837ff7a504c256606570e397ab93b0",
}
SOURCE_HASHES = {}


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def check_source(commit, filename, observed):
    key = (commit, filename)
    if key not in SOURCE_HASHES:
        SOURCE_HASHES[key] = sha256(subprocess.check_output(["git", "show", f"{commit}:{filename}"], cwd=REPOSITORY))
    assert observed == SOURCE_HASHES[key], (commit, filename)


def describe(values):
    return {"median": statistics.median(values), "mean": statistics.mean(values), "minimum": min(values), "maximum": max(values)}


def contrast(baseline, candidate):
    changes = [100 * (b / a - 1) for a, b in zip(baseline, candidate)]
    rng = random.Random(20261119)
    boot = sorted(statistics.median(rng.choices(changes, k=24)) for _ in range(10_000))
    return {"pairs": 24, "pairedChangesPercent": changes,
            "medianPairedChangePercent": statistics.median(changes),
            "equalWorkChangePercent": 100 * (sum(candidate) / sum(baseline) - 1),
            "fasterPairs": sum(b < a for a, b in zip(baseline, candidate)),
            "worstPairPercent": max(changes), "descriptiveBootstrap95Percent": [boot[250], boot[9749]]}


def analyze(replication, archive_sha256):
    archive = ROOT / f"jmdict-yield-study-chromium-{replication}-44640155099.zip"
    assert sha256(archive.read_bytes()) == archive_sha256
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        read = lambda name: json.loads(zipped.read(name))
        command_names = [name for name in zipped.namelist() if name.startswith("commands/") and name.endswith("/command.json")]
        for command_name in command_names:
            receipt = read(command_name)
            assert receipt["complete"] is True and receipt["exitCode"] == 0 and not receipt.get("timedOut"), command_name
            assert not receipt.get("error"), command_name
            directory = command_name.removesuffix("command.json")
            assert directory + "stdout.log" in zipped.namelist() and directory + "stderr.log" in zipped.namelist()
        manifest = read("manifest.json")
        preparation = read("preparation.json")
        cohort = read("cohort.json")
        assert preparation["complete"] is True and cohort["complete"] is True
        assert cohort["failures"] == [] and preparation["diagnosticCommit"] == HEAD
        assert preparation["node"] == manifest["node"] == "v22.22.0"
        assert cohort["browser"] == preparation["browser"] == "chromium"
        assert cohort["replication"] == preparation["replication"] == replication
        assert cohort["dictionary"] == preparation["dictionary"] == manifest["dictionary"] == "jmdict"
        assert cohort["manifestSha256"] == preparation["manifestSha256"] == sha256(zipped.read("manifest.json")) == MANIFEST_SHA256
        assert sha256(zipped.read("driver.py")) == manifest["harnessSha256"]["dev/perf/jmdict-yield-study/run.py"]
        assert sha256(zipped.read("workflow.yml")) == manifest["harnessSha256"][manifest["workflow"]]
        unarchived_harness = {}
        allowed_unarchived = {".github/actions/setup/action.yml", manifest["workflow"]}
        for name, expected_hash in manifest["harnessSha256"].items():
            archived_name = "tooling/" + name
            if archived_name in zipped.namelist():
                assert sha256(zipped.read(archived_name)) == expected_hash, name
            else:
                assert name in allowed_unarchived, name
                unarchived_harness[name] = expected_hash
            check_source(LOCAL_TOOLING, name, expected_hash)
        assert set(unarchived_harness) == allowed_unarchived
        entries = {arm: read(f"{arm}-package-entries.json") for arm in "ABCD"}
        assert entries["A"] == entries["C"]
        assert entries["B"] == entries["D"]
        for arm in "ABCD":
            source = manifest["sources"][manifest["arms"][arm]]
            prepared = preparation["arms"][arm]
            assert source["commit"] == prepared["commit"] == PRODUCTS[arm]
            assert source["tree"] == prepared["tree"] == subprocess.check_output(["git", "rev-parse", PRODUCTS[arm] + "^{tree}"], cwd=REPOSITORY, text=True).strip()
            assert source["productPaths"] == (["ext/js/dictionary/dictionary-importer.js"] if arm in "BD" else [])
            assert prepared["buildTarget"] == "chrome"
            assert prepared["expectedInitialPrefetchFileCount"] == 0
            assert all(prepared["frozenFiles"][p] == h for p, h in manifest["sharedProductInputs"].items())
            assert prepared["commonGeneratedOverlay"]["ext/legal-npm.html"] == entries[arm]["legal-npm.html"]
            changed = sorted(p for p in entries["A"].keys() | entries[arm].keys() if entries["A"].get(p) != entries[arm].get(p))
            assert changed == sorted(p.removeprefix("ext/") for p in source["productPaths"])
        expected = []
        for warmup, order in enumerate(("ABCD", "DCBA")):
            for arm in order[::-1] if replication == "reverse" else order:
                expected.append({"label": f"warmup-{warmup + 1}-{arm}", "arm": arm, "warmup": True, "block": warmup})
        for block in range(24):
            order = ("ABCD", "BDAC", "CADB", "DCBA")[block % 4]
            for arm in order[::-1] if replication == "reverse" else order:
                expected.append({"label": f"block-{block + 1:02d}-{arm}", "arm": arm, "warmup": False, "block": block})
        assert expected == cohort["planned"] and len(cohort["observations"]) == 104
        fixture = preparation["fixture"]
        rows = {}
        versions, digests, experiments = set(), set(), set()
        host_profiles = set()
        phase_fields = ("sourceArchiveReadMs", "parserSourcePreparationMs", "parserSourceDeliveryMs", "parserParallelWorkerWallMs", "importerChunkSinkMs", "dedupRecentSourceCacheMs", "contentPackMs")
        phase_samples = {arm: {key: [] for key in phase_fields} for arm in "ABCD"}
        path_samples = {arm: {} for arm in "ABCD"}
        previous_command_end = 0
        for item, observation in zip(expected, cohort["observations"]):
            assert all(observation[k] == value for k, value in item.items()) and not observation.get("error")
            arm = observation["arm"]
            prepared = preparation["arms"][arm]
            command = read(observation["command"])
            assert command["complete"] is True and command["exitCode"] == 0 and not command.get("timedOut")
            assert command["startedAt"] >= previous_command_end
            previous_command_end = command["completedAt"]
            summary = read(observation["directory"] + "/summary.json")
            assert summary["schemaVersion"] == 3 and summary["dictionary"] == "jmdict" and summary["buildTarget"] == "chrome"
            assert summary["authoritativeTiming"] is True and summary["traceEnabled"] is False and summary["importFlags"] is None
            assert summary["gitSha"] == summary["source"]["gitSha"] == PRODUCTS[arm]
            assert summary["fixture"] == fixture and len(summary["runs"]) == 1
            for filename, value in summary["source"]["sha256"].items():
                if filename.startswith("builds/"):
                    if filename.endswith("manabitan-chrome.zip"):
                        assert value == prepared["packageSha256"]
                else:
                    check_source(PRODUCTS[arm], filename, value)
            run = summary["runs"][0]
            assert run["tracePath"] is None and run["packageSha256"] == prepared["packageSha256"]
            report = read(observation["directory"] + "/" + Path(run["reportJsonPath"]).name)
            assert report["status"] == "success" and report["skippedVerification"] is False
            assert report["packageSha256"] == prepared["packageSha256"] and report["buildTarget"] == "chrome"
            benchmark = report["benchmark"]
            for flag, value in {"dictionary": "jmdict", "pinnedDictionaries": True, "productionImportDefaults": True,
                                "traceEnabled": False, "authoritativeTiming": True, "phaseProfiling": False,
                                "phaseScreenshots": False, "processSampling": False, "importFlags": None}.items():
                assert benchmark[flag] == value
            phases = [p for p in report["phases"] if (p.get("data") or {}).get("kind") == "dictionary-import"]
            assert len(phases) == 1
            timing = phases[0]["data"]["browserTiming"]
            assert timing["trigger"] == "file-input-change" and timing["sequence"] > timing["sequenceBefore"] and timing["errorCount"] == 0
            elapsed = timing["completedAtMs"] - timing["startedAtMs"]
            assert math.isfinite(elapsed) and elapsed > 0 and elapsed == run["totalImportMs"] == observation["totalImportMs"]
            validation = run["validation"]
            assert validation == observation["validation"] == benchmark["validation"]
            for tested in (validation, validation["restart"]):
                assert tested["title"] == fixture["expectedTitle"] and tested["revision"] == fixture["revision"]
                assert tested["termRows"] == fixture["termRows"] == 526942 and tested["probeCount"] == 12 and tested["contentReadable"] is True
            digests.add(validation["outputDigestSha256"])
            versions.add(summary["browserVersion"])
            debug = run["importDebug"]
            assert debug == observation["importDebug"] == phases[0]["data"]["importDebug"]
            assert debug["hasResult"] is True and debug["resultTitle"] == fixture["expectedTitle"]
            assert debug["errorCount"] == debug["addSettingsErrorCount"] == 0
            assert debug["usesFallbackStorage"] is False and debug["openStorageDiagnostics"]["mode"] == "opfs-sahpool"
            terms = [p for p in debug["importerPhaseTimings"] if p["phase"].startswith("term-file")]
            assert len(terms) == 1 and terms[0]["phase"].startswith("term-file-fast-path:")
            details = terms[0]["details"]
            for field, value in {"rows": 526942, "parserSourceCompressedBytes": 15574114,
                                 "parserSourceTransferredBytes": 15574114, "parserSourceUncompressedBytes": 171092992,
                                 "parserFusedFallbacks": 0, "parserDiscardedFusedRows": 0, "dedupNativeFallbackCount": 0,
                                 "sourceInitialPrefetchFileCount": 0,
                                 "sourceInitialPrefetchEstimatedBytes": 0}.items():
                assert details[field] == value
            finalization = [p["details"] for p in debug["importerPhaseTimings"] if p["phase"] == "bulk-finalization"]
            assert len(finalization) == 1 and finalization[0]["ok"] is True and finalization[0]["published"] is True and finalization[0]["housekeepingErrors"] == []
            experiments.add(json.dumps(details["parserExperiments"], sort_keys=True))
            environment = summary["hostEnvironment"]
            host_profiles.add(json.dumps({k: environment[k] for k in ("nodeVersion", "platform", "cpuModel", "logicalCpuCount", "availableParallelism", "cgroupCpuMax", "cgroupMemoryMaxBytes")}, sort_keys=True))
            if not observation["warmup"]:
                rows[(observation["block"], arm)] = elapsed
                for field in phase_fields:
                    phase_samples[arm][field].append(details[field])
                for field in ("chunkCount", "parserBorrowedContentResultCount", "parserParallelWorkerCount", "parserParallelGroupCount", "parserFusedAttempts", "dedupNativeCallCount", "parserMaxWasmHeapBytes", "sourcePrefetchMaxBytes", "dedupNativeExactCandidates", "dedupRecentSourceHitCount", "dedupRecentSourceCacheBytes"):
                    path_samples[arm].setdefault(field, set()).add(details[field])
        assert len(versions) == len(digests) == len(experiments) == len(host_profiles) == 1
        totals = {arm: [rows[(block, arm)] for block in range(24)] for arm in "ABCD"}
        comparisons = {"C/A": contrast(totals["A"], totals["C"]),
                       "D/B": contrast(totals["B"], totals["D"]),
                       "B/A": contrast(totals["A"], totals["B"]),
                       "D/A": contrast(totals["A"], totals["D"])}
        assert set(cohort["statistics"]) == set(comparisons)
        for label, statistics_for_pair in comparisons.items():
            observed = cohort["statistics"][label]
            for key, value in statistics_for_pair.items():
                if isinstance(value, list):
                    assert len(value) == len(observed[key]) and all(math.isclose(a, b, rel_tol=0, abs_tol=1e-10) for a, b in zip(value, observed[key]))
                else:
                    assert math.isclose(value, observed[key], rel_tol=0, abs_tol=1e-10)
        extracted = ROOT / f"chromium-{replication}-evidence"
        extracted.mkdir(exist_ok=True)
        for name in ("cohort.json", "preparation.json", "manifest.json", "driver.py", "workflow.yml", *(f"{arm}-package-entries.json" for arm in "ABCD")):
            target = extracted / name
            data = zipped.read(name)
            if target.exists():
                assert target.read_bytes() == data, f"Changed preserved evidence: {target}"
            else:
                with target.open("xb") as stream:
                    stream.write(data)
        result = {"replication": replication, "browser": "chromium", "complete": True,
                  "sourceRun": 44640155099, "diagnosticCommit": HEAD, "archive": archive.name,
                  "archiveSha256": archive_sha256, "observations": 104, "excludedWarmups": 8, "timedObservations": 96,
                  "rawCommandReceiptsValidated": len(command_names),
                  "harnessCoverage": {"declared": len(manifest["harnessSha256"]), "embeddedAndHashVerified": len(manifest["harnessSha256"]) - len(unarchived_harness), "allVerifiedAgainstImmutableToolingCommit": LOCAL_TOOLING, "unarchivedInputs": unarchived_harness, "note": "Both tooling/.github inputs were omitted from the uploaded ZIP. The workflow is independently embedded as workflow.yml and hash-verified. The setup action is verified from the immutable tooling Git object; its bytes are not embedded in the evidence ZIP."},
                  "validation": "All raw command, summary and browser reports verified; no observations dropped; independent statistics equal driver output",
                  "contentDigest": next(iter(digests)), "browserVersion": next(iter(versions)),
                  "correctnessCoverage": "Pinned row/title/revision counts plus 12 archive-derived persisted readability, bounds and sample-preview probes and a matching sampled digest after full browser restart. Chromium does not compare expected reading/full-glossary values to the archive. This is not a full-dictionary byte oracle.",
                  "browserRuntime": preparation["browserRuntime"], "hostEnvironment": json.loads(next(iter(host_profiles))),
                  "products": PRODUCTS, "armTimesMs": {arm: describe(values) for arm, values in totals.items()},
                  "qualificationScope": {"baseline": PRODUCTS["A"], "candidate": PRODUCTS["B"], "currentDevelopEffectTested": False, "laterDevelopMerges": {"759": "594f7fde31c6a69262115ccce733c17a3382b2c8", "766": "e8a927ab5401c19e6119a95de6a8f53eb92302ec"}, "note": "The study remains frozen to d829. Later develop changes are outside this qualification; a positive result cannot justify promotion on current develop without new qualification."},
                  "comparisons": comparisons,
                  "pathReceipts": {arm: {field: sorted(values) for field, values in metrics.items()} for arm, metrics in path_samples.items()},
                  "diagnosticPhaseMediansMs": {arm: {field: statistics.median(values) for field, values in metrics.items()} for arm, metrics in phase_samples.items()},
                  "interpretation": "Each cell remains separate. C/A and D/B are distinct same-source controls; no noise subtraction or arm pooling. B/A and D/A share A. Phase durations overlap and are not summed. Cache-copy byte counters are cumulative, not live retained memory. No peak-memory evidence."}
        analysis_path = ROOT / f"chromium-{replication}-independent-analysis.json"
        analysis_text = json.dumps(result, indent=2, allow_nan=False) + "\n"
        if analysis_path.exists():
            assert analysis_path.read_text() == analysis_text, f"Changed reproduced analysis: {analysis_path}"
        else:
            with analysis_path.open("x") as stream:
                stream.write(analysis_text)
        print(json.dumps({"replication": replication, "allChecksPassed": True,
                          "armTimesMs": result["armTimesMs"], "hostEnvironment": result["hostEnvironment"],
                          "comparisons": {arm: {k: v for k, v in values.items() if k != "pairedChangesPercent"} for arm, values in comparisons.items()}}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--replication", choices=("forward", "reverse"), required=True)
    parser.add_argument("--sha256", required=True, help="Exact SHA256 from the GitHub artifact metadata")
    arguments = parser.parse_args()
    assert len(arguments.sha256) == 64 and all(c in "0123456789abcdef" for c in arguments.sha256)
    analyze(arguments.replication, arguments.sha256)
