# Original private-reservation qualification: JMdict and Jitendex audit

Only original workflow run **45862057912**, acquired from
`7e6dda05470da6e29af2b06bc50dde26f14633fb`, is authoritative here. The frozen
product comparison is baseline `0143e9596cd8f790d5e166d4ba6a2425fbc57f14` against
candidate `5a667ed90e2f92a8d7140ec751ee63e34b40b500`. No browser observation was
rerun, replaced, excluded, or acquired by these audit scripts. Acquisition and
original validation rules remain unchanged.

## Outcome

Both JMdict cells pass the original correctness and sampled-memory gates.
Their latency results remain inconclusive. Both Jitendex cells stop at the
first warmup because the existing benchmark receipt validator has a stale
native-projection threshold. The failed Jitendex cells remain failed; neither
contains an acquired comparative timing or memory cohort.

| JMdict host order | A/B pairs | Paired median change | Descriptive 95% interval | Equal-work change | A/C control median |
| --- | ---: | ---: | --- | ---: | ---: |
| AB | 6 | -1.402566% | [-3.593577%, +1.569052%] | -1.160169% | +0.097780% |
| BA | 6 | -1.053456% | [-6.727582%, +1.740906%] | -2.147830% | +0.803708% |

Each host has two interleaved identical-code A/C control pairs. The original
10,000 complete-pair percentile bootstrap, seed 897, was recomputed exactly.
Both candidate intervals include zero. Hosts are kept separate, and no import
speedup is claimed.

| JMdict host order | Memory imports | Original raw scans | PSS paired median | Maximum PSS pair | Private-byte paired median | Maximum private-byte pair |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| AB | 4 | 384 | -3.277504% | -1.974944% | -3.905512% | -2.124263% |
| BA | 4 | 268 | +0.773202% | +2.599386% | +0.837626% | +2.847989% |

All eight memory observations meet the unchanged whole-process-tree coverage
rules and prospective regression screen. These are sampled PSS and private-byte
maxima, not exact process peaks. Their timings are excluded from the import
comparison. The differing directions do not establish a memory reduction.

## Exact identity and semantic checks

The retained-data auditor passes 185 checks in each JMdict cell. It reconstructs
all 26 receipts per cell: four warmups, twelve candidate/baseline timings, four
identical-code controls, two exhaustive-media checks, and four separate memory
observations. The original receipt rules cover fixture identity, import
completion, restart, twelve distinct lookup probes across six passes, content
digest, exact logical storage sizes, and media receipts. JMdict has no media.

The independent source/route supplement additionally verifies:

- All four outer artifact ZIPs against GitHub run, source, byte-count, and
  SHA-256 metadata, and all 438 extracted files against their original ZIP
  contents. Reading every ZIP member also checks its CRC.
- All eight actual product ZIPs and their 552-member hash inventories. Each
  arm's runtime members are identical across all four cells. Per-host ZIP
  digests differ because ZIP metadata differs; member bytes do not.
- Frozen Git commit/tree identities and every exposed source hash, including
  dependency and fixture locks. The sole runtime package difference is
  `js/dictionary/dictionary-database.js`, byte-bound to each frozen source.
- All 54 raw browser reports: the 52 complete JMdict observations plus the two
  original failed-extraction Jitendex warmups. Raw semantic comparison of those
  two Jitendex reports is diagnostic evidence, not qualification.

All 52 JMdict observations have the same canonical semantic receipt across both
hosts. Exact logical storage is **43,520,477 bytes**. The content output digest is
`e88726c0d84ad9f6e9b7cf4455783fee169a41bf0cbfe3252386cec59791117d`.
Only validated random storage basenames and lookup elapsed times are normalized.
No storage-size tolerance is substituted for observed bytes.

The raw fixture ZIP cache became unavailable locally during this audit. Fixture
identity is bound to the frozen lock and the earlier completed source census,
which verified archive SHA-256/size, index and every decoded term bank's CRC,
title, and row count. That CRC statement does not cover unread media members;
the complete-archive SHA-256 covers their bytes. No fixture was downloaded again.

## Jitendex failure: stale receipt policy

AB stops in `warmup-1-A` (baseline); BA stops in `warmup-1-B` (candidate). Both
browser reports say success and contain equal canonical semantic receipts, but
the original benchmark extractor then throws:

```text
Import experiment receipt mismatch: parserExperiments
```

At the frozen baseline source, the conflicting rules are:

- `dev/perf/benchmark-support.js`, lines 117–129, infers automatically enabled
  `experimentalNativeEscapedKeys` from media/native worker receipts when source
  bytes reach 512 MiB.
- `ext/js/dictionary/dictionary-importer.js`, lines 96–109, admits native image
  projection only at 1 GiB; line 5414 passes that admission to the parser.
- `ext/js/dictionary/term-bank-wasm-parser.js`, lines 2841–2848, enables the key
  automatically only when native image projection is actually enabled.

Jitendex has **538,927,310 uncompressed term-source bytes**: above 512 MiB and
below 1 GiB. Both raw reports show three workers, no parallel fallback, media
enabled, and `experimentalNativeEscapedKeys: false`, consistent with production.
The older validator expects true. `source-route-audit.json` includes exact
source hashes, line-numbered excerpts, and the observed predicate values.

Each failure artifact contains its first raw report, logs, plan, and both product
packages. There is no completed `summary.json`, `observations.json`, exhaustive
media cohort, or memory cohort. Their absence follows the registered stop on
first failure rule. Missing-stage errors in the retained auditor are recorded
as evidence of that incomplete acquisition; they are not silently repaired.

## Route and activation limits

Every JMdict observation reports three workers, twelve groups, 362,032 unique
content items, 101,143,985 owned content bytes, zero borrowed-result groups, and
one successful initial reservation. The two Jitendex raw reports each show
three workers, twenty-two groups, 363,243 unique content items, twenty-two
borrowed-result groups, zero owned content bytes, and one initial reservation.

An owned slab can be a `SharedArrayBuffer`: the worker deliberately allocates
such owned slabs for cacheable small definitions. Ownership bytes are therefore
not a private-buffer activation counter. Similarly,
`contentInitialReservationCount` counts successful initial reservations, not
rejected attempts or avoided validation scans. These receipts do not measure a
skipped-prepass count for either dictionary. Source-route reasoning is retained
separately from measured counters; no fabricated activation total is reported.

## Reproduction and files

`retained-auditor/audit_retained_cell.py` reconstructs the original strict
receipts, package inventories, schedule, paired statistics, media checks, and
raw process-memory audit for one extracted cell. Its adjacent helper modules
are exact original acquisition-source files. It is shared audit tooling from
the independent VNDB reviewer; source and routing were additionally audited by
`audit_sources_and_routes.py`.

```sh
python3 retained-auditor/audit_retained_cell.py /path/to/jmdict-AB \
  --dictionary jmdict --order AB \
  --fixture-lock /path/to/repo/test/perf/dictionaries.lock.json \
  --baseline-root /path/to/baseline --candidate-root /path/to/candidate \
  --output retained-jmdict-AB.json

python3 audit_sources_and_routes.py \
  --repo /path/to/repo-with-frozen-commits \
  --acquisition /path/to/import-acquisition-45862057912 \
  --metadata artifacts.json --fixture-census /path/to/source-score-census.json \
  --cells jmdict-AB jmdict-BA jitendex-AB jitendex-BA \
  --output source-route-audit.json
```

The supplementary audit expects original outer ZIPs alongside their extracted
cell directories. It uses Python's standard library and reads frozen Git
objects. It writes only its requested audit output. `--fixture-cache` may be
supplied when exact source ZIPs are retained; otherwise the earlier verified
census is required and the absence of a fresh raw-archive rehash stays explicit.

The four `retained-*.json` reports preserve complete per-cell findings.
`source-route-audit.json` binds artifacts, sources, raw semantics, counters, and
the stale-threshold diagnosis. `artifacts.json` is the complete original-run
GitHub metadata snapshot; the earlier three-artifact snapshot and both failed
Jitendex outer job logs are also retained. No replacement workflow is included.
