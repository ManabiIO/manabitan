#!/usr/bin/env python3
"""Audit original artifact bytes, frozen source identities and observed routes.

This only reads retained evidence. It never launches a browser, synthesizes an
import summary, reruns an observation, or changes original qualification gates.
"""

import argparse
import functools
import hashlib
import json
from pathlib import Path
import random
import statistics
import subprocess
import types
import zipfile


TOOLING = '7e6dda05470da6e29af2b06bc50dde26f14633fb'
SOURCES = {'A': '0143e9596cd8f790d5e166d4ba6a2425fbc57f14', 'B': '5a667ed90e2f92a8d7140ec751ee63e34b40b500'}
RUN = 45862057912
CHANGED_ENTRY = 'js/dictionary/dictionary-database.js'
METRICS = [
    'parserSourceUncompressedBytes', 'parserParallelWorkerCount',
    'parserParallelPipelineGroupsPerWorker', 'parserParallelGroupCount',
    'parserParallelOwnedContentBytes', 'parserBorrowedContentResultCount',
    'parserEncodedContentBytes', 'contentInitialReservationCount',
    'contentInitialReservationSavingsMissCount', 'dedupUniqueCount',
]

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', required=True, type=Path)
parser.add_argument('--acquisition', required=True, type=Path)
parser.add_argument('--metadata', required=True, type=Path)
parser.add_argument('--fixture-cache', type=Path)
parser.add_argument('--fixture-census', type=Path)
parser.add_argument('--cells', nargs='+', default=['jmdict-BA', 'jitendex-AB', 'jitendex-BA'])
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()


def json_bytes(value):
    return json.dumps(value, sort_keys=True, allow_nan=False, separators=(',', ':')).encode()


def read(path):
    return json.loads(path.read_bytes())


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


@functools.cache
def git_blob(commit, name):
    return subprocess.check_output(['git', '-C', str(args.repo), 'show', f'{commit}:{name}'])


def same(actual, expected, label):
    if json_bytes(actual) != json_bytes(expected):
        raise AssertionError(label)


def paired(rows, kind, left, right):
    groups = {}
    for row in rows:
        if row['kind'] == kind:
            groups.setdefault(row['pair'], {})[row['arm']] = row['totalImportMs']
    values = list(groups.values())
    assert values and all(set(pair) == {left, right} for pair in values)
    ratios = [pair[right] / pair[left] for pair in values]
    rng = random.Random(897)
    bootstrap = sorted(statistics.median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
    return {
        'count': len(values), 'ratios': ratios,
        'medianPairedChangePercent': (statistics.median(ratios) - 1) * 100,
        'equalWorkChangePercent': (sum(pair[right] for pair in values) / sum(pair[left] for pair in values) - 1) * 100,
        'worstPairChangePercent': (max(ratios) - 1) * 100,
        'descriptiveBootstrap95Percent': [(bootstrap[index] - 1) * 100 for index in (249, 9749)],
        'fasterPairs': sum(ratio < 1 for ratio in ratios),
    }


receipt_source = git_blob(TOOLING, 'dev/perf/import-memory-20261125-a7f7/qualification_receipts.py')
receipts = types.ModuleType('frozen_qualification_receipts')
exec(compile(receipt_source, f'{TOOLING}:qualification_receipts.py', 'exec'), receipts.__dict__)
lock_bytes = git_blob(TOOLING, 'test/perf/dictionaries.lock.json')
fixtures = json.loads(lock_bytes)['dictionaries']
artifacts = {item['name']: item for item in read(args.metadata)['artifacts']}
census = read(args.fixture_census) if args.fixture_census is not None else None
output = {
    'schemaVersion': 1, 'runId': RUN, 'acquisitionCommit': TOOLING,
    'productSources': SOURCES,
    'scope': 'Read-only independent source/artifact/route supplement. Failed original warmups stay failed. No replacement observations or pooled hosts.',
    'validatorSourceSha256': digest(receipt_source), 'fixtureLockSha256': digest(lock_bytes),
    'cells': {},
}
references = {}
sample_media_references = {}
full_media_references = {}
package_references = {}

for cell_name in args.cells:
    dictionary, order = cell_name.rsplit('-', 1)
    assert dictionary in ('jmdict', 'jitendex') and order in ('AB', 'BA')
    cell = args.acquisition / cell_name
    archive_path = args.acquisition / f'{cell_name}.zip'
    artifact = artifacts[f'private-content-reservations-{cell_name}-c951']
    same(artifact['workflow_run']['id'], RUN, 'Wrong acquisition run')
    same(artifact['workflow_run']['head_sha'], TOOLING, 'Wrong acquisition source')
    same(archive_path.stat().st_size, artifact['size_in_bytes'], 'Artifact byte count')
    same('sha256:' + file_digest(archive_path), artifact['digest'], 'Artifact digest')
    file_hashes = {}
    with zipfile.ZipFile(archive_path) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names))
        for item in archive.infolist():
            if item.is_dir():
                continue
            path = Path(item.filename)
            assert not path.is_absolute() and '..' not in path.parts
            h = hashlib.sha256()
            with archive.open(item) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    h.update(block)
            value = h.hexdigest()
            same(file_digest(cell / path), value, f'Extracted file differs: {path}')
            file_hashes[item.filename] = value
    fixture = fixtures[dictionary]
    fixture_path = args.fixture_cache / fixture['cacheFile'] if args.fixture_cache is not None else None
    if fixture_path is not None and fixture_path.is_file():
        same(file_digest(fixture_path), fixture['sha256'], 'Local locked corpus digest')
        fixture_receipt = {'mode': 'Raw archive independently rehashed in this audit', 'sha256': fixture['sha256']}
    else:
        assert census is not None, 'Raw fixture unavailable; an earlier completed verified census is required'
        same(census['complete'], True, 'Complete earlier corpus census')
        same(census['lockSha256'], digest(lock_bytes), 'Earlier census uses exact frozen fixture lock')
        entry = census['dictionaries'][dictionary]
        same(entry['fixture'], fixture, 'Earlier census fixture identity')
        same(entry['archiveSha256'], fixture['sha256'], 'Earlier census archive digest')
        same(entry['rows'], fixture['termRows'], 'Earlier census exact row total')
        fixture_receipt = {
            'mode': 'Earlier complete SHA/size/CRC-verified source census; raw ZIP unavailable locally during this audit',
            'sha256': fixture['sha256'], 'censusSha256': file_digest(args.fixture_census),
            'rawArchiveRehashedInThisAudit': False,
        }
    identity = read(cell / 'source-identities.json')
    packages = {}
    for arm, commit in SOURCES.items():
        record = identity['arms'][arm]
        same(record['sha'], commit, 'Frozen product source')
        tree = subprocess.check_output(['git', '-C', str(args.repo), 'rev-parse', f'{commit}^{{tree}}'], text=True).strip()
        same(record['tree'], tree, 'Frozen product tree')
        same(record['fixtureLockSha256'], digest(lock_bytes), 'Fixture lock source')
        same(record['lockSha256'], digest(git_blob(commit, 'package-lock.json')), 'Dependency lock source')
        for name, value in record['sourceHashes'].items():
            expected = None if name == 'builds/manabitan-chrome-dev.zip' else (
                file_digest(cell / f'package-{arm}.zip') if name == 'builds/manabitan-chrome.zip' else digest(git_blob(commit, name)))
            same(value, expected, f'Frozen exposed source hash: {arm}/{name}')
        with zipfile.ZipFile(cell / f'package-{arm}.zip') as package:
            assert len(package.namelist()) == len(set(package.namelist()))
            members = {item.filename: digest(package.read(item)) for item in package.infolist() if not item.is_dir()}
        same(members, record['entries'], 'Actual package entry inventory')
        same(file_digest(cell / f'package-{arm}.zip'), record['packageSha256'], 'Actual package digest')
        same(members[CHANGED_ENTRY], digest(git_blob(commit, 'ext/' + CHANGED_ENTRY)), 'Changed package source bytes')
        if arm in package_references:
            same(members, package_references[arm], 'Identical runtime package members across cells')
        else:
            package_references[arm] = members
        packages[arm] = members
    same(sorted(packages['A']), sorted(packages['B']), 'Package member sets')
    same([key for key in sorted(packages['A']) if packages['A'][key] != packages['B'][key]], [CHANGED_ENTRY], 'Only allowed package delta')
    rows = []
    for report_path in sorted(cell.rglob('run-1.json')):
        relative = str(report_path.parent.relative_to(cell))
        arm = 'B' if relative.endswith('-B') or relative.startswith('memory/B') else 'A'
        report = read(report_path)
        same(report['status'], 'success', f'Browser report status: {relative}')
        same(report['skippedVerification'], False, 'Browser verification was not skipped')
        same(report['hostEnvironment']['nodeVersion'], 'v22.22.0', 'Pinned Node')
        same(report['packageSha256'], identity['arms'][arm]['packageSha256'], 'Raw report product package')
        same(report['benchmark']['importFlags'], None, 'Production defaults')
        mode = report['benchmark']['mediaCheck']
        canonical = receipts.canonicalize_validation(report['benchmark']['validation'], dictionary=dictionary, fixture=fixture, media_check=mode)
        media = canonical.pop('media')
        common_hash = digest(json_bytes(canonical))
        if dictionary in references:
            same(common_hash, references[dictionary], 'Cross-observation and cross-host raw semantics')
        else:
            references[dictionary] = common_hash
        if mode == 'all':
            if dictionary in full_media_references:
                same(media, full_media_references[dictionary], 'Exhaustive media cross-arm parity')
            else:
                full_media_references[dictionary] = media
        else:
            if dictionary in sample_media_references:
                same(media, sample_media_references[dictionary], 'Sampled media cross-observation parity')
            else:
                sample_media_references[dictionary] = media
        phase_data = [(phase.get('data') or {}) for phase in report['phases'] if (phase.get('data') or {}).get('kind') == 'dictionary-import']
        assert len(phase_data) == 1
        importer_phases = phase_data[0]['importDebug']['importerPhaseTimings']
        fast = [phase['details'] for phase in importer_phases if phase['phase'].startswith('term-file-fast-path:')]
        assert len(fast) == 1
        details = fast[0]
        bank = [phase['details'] for phase in importer_phases if phase['phase'] == 'import-data-banks']
        assert len(bank) == 1
        policy = {
            'useMediaPipeline': bank[0].get('useMediaPipeline'),
            'hasArchiveImageMediaFiles': bank[0].get('hasArchiveImageMediaFiles'),
            'parserParallelSkipReason': details['parserParallelSkipReason'],
            'sourceMeetsProduction1GiBProjectionGate': details['parserSourceUncompressedBytes'] >= 1024 * 1024 * 1024,
            'sourceMeetsOriginalValidator512MiBInference': details['parserSourceUncompressedBytes'] >= 512 * 1024 * 1024,
        }
        rows.append({
            'name': relative, 'arm': arm, 'browserStatus': report['status'],
            'summaryPresent': (report_path.parent / 'summary.json').is_file(),
            'sourcePackageSha256': report['packageSha256'], 'browserVersion': report['browserVersion'],
            'canonicalRawValidationSha256': common_hash, 'media': media,
            'parserExperiments': details['parserExperiments'],
            'nativeProjectionPolicyEvidence': policy,
            'routeMetrics': {key: details.get(key) for key in METRICS},
        })
    analysis = read(cell / 'analysis.json') if (cell / 'analysis.json').is_file() else None
    statistics_result = None
    if analysis is not None:
        observations = read(cell / 'observations.json')
        same(len(observations), 20, 'Full warmup/timing/control observation count')
        statistics_result = {'candidateVsBaseline': paired(observations, 'candidate', 'A', 'B'), 'identicalCodeControl': paired(observations, 'control', 'A', 'C')}
        for key, value in statistics_result.items():
            same(value, analysis[key], 'Recomputed paired statistics')
        same(len(rows), 26, 'All timed/media/memory receipts')
    else:
        same(dictionary, 'jitendex', 'Unexpected incomplete cell')
        same(len(rows), 1, 'Only first failed original warmup')
        same(rows[0]['name'], f'warmup-1-{order[0]}', 'Original failure slot')
        same(rows[0]['summaryPresent'], False, 'Failed extraction must not become a qualified summary')
        log = (cell / rows[0]['name'] / 'run.log').read_text()
        assert 'Import experiment receipt mismatch: parserExperiments' in log
        same(rows[0]['parserExperiments']['experimentalNativeEscapedKeys'], False, 'Production Jitendex native-key flag')
        same(rows[0]['nativeProjectionPolicyEvidence'], {
            'useMediaPipeline': True, 'hasArchiveImageMediaFiles': True,
            'parserParallelSkipReason': None,
            'sourceMeetsProduction1GiBProjectionGate': False,
            'sourceMeetsOriginalValidator512MiBInference': True,
        }, 'Exact conditions establishing stale native-key expectation')
        assert rows[0]['routeMetrics']['parserParallelWorkerCount'] > 0
        size = rows[0]['routeMetrics']['parserSourceUncompressedBytes']
        assert 512 * 1024 * 1024 <= size < 1024 * 1024 * 1024
    output['cells'][cell_name] = {
        'artifact': artifact, 'artifactFilesVerified': len(file_hashes), 'fileHashes': file_hashes,
        'fixtureVerification': fixture_receipt,
        'frozenSourceHashesVerified': True, 'productPackageEntryCount': len(packages['A']),
        'productPackageSha256': {arm: identity['arms'][arm]['packageSha256'] for arm in SOURCES},
        'rawReportsVerified': len(rows), 'observations': rows, 'statistics': statistics_result,
        'originalQualificationStatus': analysis['status'] if analysis else 'failed-first-warmup; no complete comparison',
        'failureReason': None if analysis else 'Stale benchmark receipt condition expects native escaped keys above 512 MiB while production native-image projection is gated at 1 GiB. Original failure retained; no summary synthesized.',
    }

output['semanticDigestByDictionary'] = references
output['crossCellPackageMemberInventorySha256'] = {arm: digest(json_bytes(members)) for arm, members in package_references.items()}
output['sourceRules'] = []
for name, intervals, meaning in [
    ('dev/perf/benchmark-support.js', [(95, 132)], 'Original receipt validator infers automatic native escaped keys at 512 MiB without the later 1 GiB native-projection gate'),
    ('ext/js/dictionary/dictionary-importer.js', [(96, 110), (5404, 5420)], 'Production native image projection requires 1 GiB source size before the parser option is enabled'),
    ('ext/js/dictionary/term-bank-wasm-parser.js', [(67, 67), (2841, 2848)], 'Parser automatic key behavior requires the actual native image projection option'),
    ('ext/js/dictionary/term-bank-experiments.js', [(29, 46)], 'The default native escaped-key switch is false'),
    ('ext/js/dictionary/term-bank-wasm-parser-worker.js', [(138, 179)], 'Owned small-definition slabs can remain SharedArrayBuffer-backed; ownership is not private-buffer proof'),
]:
    source = git_blob(SOURCES['A'], name)
    lines = source.decode().splitlines()
    output['sourceRules'].append({
        'commit': SOURCES['A'], 'path': name, 'sha256': digest(source), 'meaning': meaning,
        'excerpts': [{'firstLine': start, 'lastLine': end, 'text': '\n'.join(lines[start - 1:end])} for start, end in intervals],
    })
output['activationLimits'] = [
    'Owned parser content can be backed by SharedArrayBuffer. It is not a private-buffer activation counter.',
    'contentInitialReservationCount reports successful initial reservations, not rejected attempts or avoided validation loops.',
    'JMdict and Jitendex below 1 GiB keep native-image projection disabled. Observed shared/borrowed routes remain distinct from VNDB private-content opportunities.',
    'Jitendex first warmups completed browser-side verification but failed original extraction. Their durations are not a paired comparison or qualification.',
]
args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
print(json.dumps({'cells': list(output['cells']), 'verifiedReports': sum(item['rawReportsVerified'] for item in output['cells'].values()), 'output': str(args.output)}))
