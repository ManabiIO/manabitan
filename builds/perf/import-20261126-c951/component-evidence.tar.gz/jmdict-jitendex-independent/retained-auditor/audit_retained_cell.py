#!/usr/bin/env python3
"""Read original retained qualification artifacts without rerunning an import."""

import argparse
import hashlib
import json
import pathlib
import random
import re
import statistics
import zipfile

from audit_memory import audit_cell
from protocol import memory_comparison, memory_overlay, schedule as memory_schedule
from qualification_receipts import require_matching_receipts, validate_import_summary


FROZEN = {
    "A": {"sha": "0143e9596cd8f790d5e166d4ba6a2425fbc57f14", "tree": "004fa8fde0055379ffbf22f9bbb60ae50f99114a"},
    "B": {"sha": "5a667ed90e2f92a8d7140ec751ee63e34b40b500", "tree": "89da905d084881b4b428e944f285a5c7727b0634"},
}
EXPECTED_ENTRY = "js/dictionary/dictionary-database.js"
HARNESS_PATH = "test/chromium/extension-two-dictionary-import.e2e.js"
ACQUISITION = "7e6dda05470da6e29af2b06bc50dde26f14633fb"

arguments = argparse.ArgumentParser(description=__doc__)
arguments.add_argument("root", type=pathlib.Path, help="Extracted original artifact directory")
arguments.add_argument("--dictionary", required=True, choices=("jmdict", "jitendex", "vndb"))
arguments.add_argument("--order", required=True, choices=("AB", "BA"))
arguments.add_argument("--fixture-lock", required=True, type=pathlib.Path)
arguments.add_argument("--baseline-root", type=pathlib.Path)
arguments.add_argument("--candidate-root", type=pathlib.Path)
arguments.add_argument("--output", required=True, type=pathlib.Path)
args = arguments.parse_args()
root = args.root.resolve()
errors = []
passed = []
observed = []


def read_json(path):
    return json.loads(path.read_bytes())


def sha(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def same(actual, expected, label):
    if json.dumps(actual, sort_keys=True, allow_nan=False) != json.dumps(expected, sort_keys=True, allow_nan=False):
        raise ValueError(f"{label}: values differ")


def check(label, callback):
    try:
        result = callback()
        passed.append(label)
        return result
    except Exception as error:
        errors.append({"check": label, "type": type(error).__name__, "error": str(error)})
        return None


def expected_schedule(first, pairs=6):
    result = []
    for pair, order in enumerate((first, first[::-1]), 1):
        for arm in order:
            result.append({"id": f"warmup-{pair}-{arm}", "kind": "warmup", "pair": pair, "arm": arm})
    for pair in range(1, pairs + 1):
        for arm in first if pair % 2 else first[::-1]:
            result.append({"id": f"pair-{pair:02d}-{arm}", "kind": "candidate", "pair": pair, "arm": arm})
        if pair % 3 == 0:
            control_pair = pair // 3
            order = "AC" if (control_pair + (first == "BA")) % 2 else "CA"
            for arm in order:
                result.append({"id": f"control-{control_pair:02d}-{arm}", "kind": "control", "pair": control_pair, "arm": arm})
    return result


def package_members(path):
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        if len(names) != len(set(names)):
            raise ValueError("Duplicate package members")
        result = {}
        for info in infos:
            if info.is_dir():
                continue
            digest = hashlib.sha256()
            with archive.open(info) as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                    digest.update(chunk)
            result[info.filename] = digest.hexdigest()
        return result


def route_metrics(value, prefix=""):
    result = {}
    if isinstance(value, dict):
        for key, item in value.items():
            path = f"{prefix}.{key}" if prefix else key
            if isinstance(item, (dict, list)):
                result.update(route_metrics(item, path))
            elif re.search(r"dedup|reserv|span|parserWorkerCount|fastPath|columnChunk|contentStoreMs|contentPackMs|contentCompressMs", key, re.I):
                result[path] = item
    elif isinstance(value, list):
        for index, item in enumerate(value):
            result.update(route_metrics(item, f"{prefix}[{index}]"))
    return result


def paired_summary(rows, kind, left, right):
    pairs = {}
    for item in rows:
        if item["kind"] == kind:
            pairs.setdefault(item["pair"], {})[item["arm"]] = item["totalImportMs"]
    if any(left not in values or right not in values for values in pairs.values()):
        raise ValueError("Incomplete paired observations")
    values = list(pairs.values())
    ratios = [pair[right] / pair[left] for pair in values]
    rng = random.Random(897)
    resampled = sorted(statistics.median(rng.choices(ratios, k=len(ratios))) for _ in range(10000))
    return {
        "count": len(values), "ratios": ratios,
        "medianPairedChangePercent": (statistics.median(ratios) - 1) * 100,
        "equalWorkChangePercent": (sum(pair[right] for pair in values) / sum(pair[left] for pair in values) - 1) * 100,
        "worstPairChangePercent": (max(ratios) - 1) * 100,
        "descriptiveBootstrap95Percent": [(resampled[index] - 1) * 100 for index in (249, 9749)],
        "fasterPairs": sum(ratio < 1 for ratio in ratios),
    }


fixture = read_json(args.fixture_lock)["dictionaries"][args.dictionary]
plan = check("registered-plan-readable", lambda: read_json(root / "registered-plan.json"))
identity_record = check("source-identities-readable", lambda: read_json(root / "source-identities.json"))
browser = check("browser-identity-readable", lambda: read_json(root / "browser-identity.json"))
expected = expected_schedule(args.order)
replication = 1 if args.order == "AB" else 2
identities = identity_record.get("arms", {}) if identity_record else {}
member_maps = {}

if plan is not None:
    for key, value in {
        "baseline": FROZEN["A"]["sha"], "candidate": FROZEN["B"]["sha"],
        "dictionary": args.dictionary, "initialOrder": args.order, "pairs": 6,
        "flags": {}, "schedule": expected, "expectedWorkers": None,
        "expectedPackageEntries": [EXPECTED_ENTRY], "memorySchedule": memory_schedule(replication),
    }.items():
        check(f"registered-plan:{key}", lambda key=key, value=value: same(plan.get(key), value, key))

for arm in ("A", "B"):
    identity = identities.get(arm)
    if not isinstance(identity, dict):
        errors.append({"check": f"identity:{arm}", "error": "Missing arm identity"})
        continue
    for key, expected_value in FROZEN[arm].items():
        check(f"source:{arm}:{key}", lambda key=key, value=expected_value: same(identity.get(key), value, key))
    archive = root / f"package-{arm}.zip"
    check(f"package:{arm}:sha256", lambda: same(sha(archive), identity["packageSha256"], "package digest"))
    entries = check(f"package:{arm}:members-readable", lambda: package_members(archive))
    if entries is not None:
        member_maps[arm] = entries
        check(f"package:{arm}:member-hashes", lambda: same(entries, identity["entries"], "package member hashes"))
    check(f"source:{arm}:fixture-lock", lambda: same(identity["fixtureLockSha256"], sha(args.fixture_lock), "fixture lock digest"))
    local_root = args.baseline_root if arm == "A" else args.candidate_root
    if local_root is not None and entries is not None:
        check(f"package:{arm}:changed-entry-source-bytes", lambda: same(entries[EXPECTED_ENTRY], sha(local_root / "ext" / EXPECTED_ENTRY), "changed entry matches independently checked source"))

if len(member_maps) == 2:
    check("packages:identical-member-set", lambda: same(sorted(member_maps["A"]), sorted(member_maps["B"]), "package member set"))
    changed = sorted(key for key in member_maps["A"] if member_maps["A"].get(key) != member_maps["B"].get(key))
    check("packages:only-frozen-product-delta", lambda: same(changed, [EXPECTED_ENTRY], "changed entries"))
    check("packages:recorded-delta", lambda: same(sorted(identity_record["changedPackageEntries"]), changed, "recorded changed entries"))

reference = None
full_media_reference = None


def inspect_observation(name, arm, kind, media_check="sample", overlay=None):
    global reference, full_media_reference
    location = root / name
    row = {"name": name, "arm": arm, "kind": kind, "exists": location.is_dir()}
    observed.append(row)
    if not location.is_dir():
        row["acquired"] = False
        return None
    row["acquired"] = True
    summary = check(f"{name}:summary-readable", lambda: read_json(location / "summary.json"))
    report = check(f"{name}:raw-report-readable", lambda: read_json(location / "run-1.json"))
    if report is not None:
        row["status"] = report.get("status")
        row["rawFailureDetails"] = {key: value for key, value in report.items() if re.search(r"error|fail|message", key, re.I)}
    if summary is None or report is None:
        row["files"] = sorted(str(path.relative_to(location)) for path in location.rglob("*") if path.is_file()) if location.is_dir() else []
        return None
    runs = summary.get("runs", [])
    run = runs[0] if len(runs) == 1 else {}
    row["totalImportMs"] = run.get("totalImportMs")
    row["routeMetrics"] = route_metrics(run.get("step4Breakdown", {}))
    row["sourceSha"] = summary.get("gitSha")
    row["packageSha256"] = run.get("packageSha256")
    row["status"] = report.get("status")
    row["validation"] = run.get("validation")
    identity = identities.get(arm)
    if identity is None or browser is None:
        return None
    hashes = identity["sourceHashes"].copy()
    if overlay is not None:
        hashes[HARNESS_PATH] = hashlib.sha256(overlay.encode()).hexdigest()
    receipt = check(f"{name}:strict-raw-summary-receipt", lambda: validate_import_summary(
        summary, report, dictionary=args.dictionary, fixture=fixture,
        source_sha=FROZEN[arm]["sha"], package_sha256=identity["packageSha256"],
        browser_version=browser["version"], import_flags=None, source_hashes=hashes,
        source_dirty=overlay is not None, media_check=media_check,
    ))
    if receipt is None:
        return None
    check(f"{name}:retained-canonical-receipt", lambda: same(read_json(location / "canonical-receipt.json"), receipt, "canonical receipt"))
    if reference is None:
        reference = receipt
    else:
        check(f"{name}:cross-observation-receipt", lambda: require_matching_receipts(reference, receipt, compare_media=media_check == "sample"))
    if media_check == "all":
        if full_media_reference is None:
            full_media_reference = receipt
        else:
            check(f"{name}:complete-media-parity", lambda: require_matching_receipts(full_media_reference, receipt))
    return row


retained_timings = check("timing-observations-readable", lambda: read_json(root / "observations.json"))
timed = []
for item in expected:
    arm = "B" if item["arm"] == "B" else "A"
    row = inspect_observation(item["id"], arm, item["kind"])
    if row is not None:
        timed.append({**item, "totalImportMs": row["totalImportMs"]})
if retained_timings is not None:
    check("timing:all-original-observations-retained", lambda: same(retained_timings, timed, "retained observations"))
    check("timing:fixed-full-schedule", lambda: same([{key: row[key] for key in ("id", "kind", "pair", "arm")} for row in retained_timings], expected, "schedule coverage"))

for arm in args.order:
    inspect_observation(f"exhaustive-media-{arm}", arm, "exhaustive-media", media_check="all")

memory_root = root / "memory"
memory_plan = check("memory:plan-readable", lambda: read_json(memory_root / "plan.json"))
overlay = None
if memory_plan is not None:
    check("memory:fixed-schedule", lambda: same(memory_plan["schedule"], memory_schedule(replication), "memory schedule"))
    check("memory:dictionary", lambda: same(memory_plan["dictionary"], args.dictionary, "memory dictionary"))
    check("memory:non-authoritative-timing", lambda: same(memory_plan["authoritativeTiming"], False, "memory timing status"))
    check("memory:source-identities", lambda: same(memory_plan["sourceHashes"], identities, "memory source identities"))
    original = check("memory:original-harness-readable", lambda: (memory_root / "harness-original.js").read_text())
    overlay = check("memory:overlay-readable", lambda: (memory_root / "harness-instrumented.js").read_text())
    if original is not None and overlay is not None:
        check("memory:original-harness-hash", lambda: same(hashlib.sha256(original.encode()).hexdigest(), identities["A"]["sourceHashes"][HARNESS_PATH], "original harness hash"))
        check("memory:only-original-marker-overlay", lambda: same(memory_overlay(original), overlay, "memory marker overlay"))
        check("memory:overlay-hash", lambda: same(hashlib.sha256(overlay.encode()).hexdigest(), memory_plan["overlaySha256"], "overlay hash"))
    if overlay is not None:
        for item in memory_schedule(replication):
            inspect_observation(f"memory/{item['name']}", item["arm"], "memory", overlay=overlay)

memory_audit = check("memory:raw-scans-markers-and-gates", lambda: audit_cell(memory_root))
memory_observations = check("memory:observations-readable", lambda: read_json(memory_root / "observations.json"))
memory_recomputed = None
if memory_observations is not None:
    memory_recomputed = check("memory:recomputed-comparison", lambda: memory_comparison(memory_observations, args.dictionary, replication, memory_schedule))
    if memory_recomputed is not None:
        check("memory:retained-comparison", lambda: same(read_json(memory_root / "memory-comparison.json"), memory_recomputed, "memory comparison"))
semantic_failures = check("memory:semantic-failures-readable", lambda: read_json(memory_root / "semantic-failures.json"))
analysis = check("analysis-readable", lambda: read_json(root / "analysis.json"))
timing_analysis = {}
if retained_timings is not None and len(retained_timings) == len(expected):
    for key, kind, left, right in (("candidateVsBaseline", "candidate", "A", "B"), ("identicalCodeControl", "control", "A", "C")):
        value = check(f"timing:{key}:recomputed", lambda: paired_summary(retained_timings, kind, left, right))
        timing_analysis[key] = value
        if analysis is not None and value is not None:
            check(f"timing:{key}:retained-summary", lambda: same(analysis[key], value, key))

if analysis is not None and memory_recomputed is not None and semantic_failures is not None:
    memory_passed = memory_recomputed["passesProspectiveMemoryScreen"] and not semantic_failures and memory_audit is not None
    check("analysis:memory-verdict", lambda: same(analysis["memoryPassed"], memory_passed, "memory verdict"))
    check("analysis:status", lambda: same(analysis["status"], "correctness-memory-passed" if memory_passed else "memory-or-semantics-failed", "analysis status"))

report = {
    "schemaVersion": 1, "acquisitionCommit": ACQUISITION, "runId": 45862057912,
    "dictionary": args.dictionary, "initialOrder": args.order, "root": str(root),
    "originalExpectedProductSources": FROZEN, "fixture": fixture,
    "scope": "Independent audit of retained original artifacts only. Original strict receipt and memory rules are unchanged. No import reruns, observation exclusions, or cross-host pooling.",
    "passedCheckCount": len(passed), "passedChecks": passed, "errors": errors,
    "completeWithoutAuditErrors": not errors, "observations": observed,
    "originalQualificationPassed": not errors and analysis is not None and analysis.get("status") == "correctness-memory-passed",
    "notAcquiredObservationNames": [row["name"] for row in observed if not row.get("acquired")],
    "timingAnalysis": timing_analysis, "memoryAudit": memory_audit,
    "memoryComparison": memory_recomputed, "originalAnalysis": analysis,
    "explicitSkippedReservationCounterRequired": "A dedupUniqueCount is directly reported work, not itself a direct measurement of skipped reservation calls; any relationship must be justified from observed routes and source.",
}
args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
print(json.dumps({"dictionary": args.dictionary, "order": args.order, "passedCheckCount": len(passed), "errors": errors, "timingAnalysis": timing_analysis, "memoryAudit": memory_audit}, indent=2))
raise SystemExit(1 if errors else 0)
