"""Count raw source scores with only one JSON term bank decoded at a time."""

import collections
import hashlib
import json
import math
from pathlib import Path
import resource
import sys
import zipfile


repo, cache, output = map(Path, sys.argv[1:4])
lock_bytes = (repo / "test/perf/dictionaries.lock.json").read_bytes()
lock = json.loads(lock_bytes)
report = {
    "scope": "Full locked ZIP source census, one raw term bank decoded at a time. This does not measure persisted compact-field eligibility, native group counts, or import timing.",
    "lockSha256": hashlib.sha256(lock_bytes).hexdigest(),
    "python": sys.version,
    "dictionaries": {},
}

for name in ["jmdict", "jitendex", "vndb"]:
    fixture = lock["dictionaries"][name]
    archive_path = cache / fixture["cacheFile"]
    assert archive_path.stat().st_size == fixture["sizeBytes"]
    digest = hashlib.sha256()
    with archive_path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    archive_sha = digest.hexdigest()
    assert archive_sha == fixture["sha256"]
    counts = collections.Counter()
    types = collections.Counter()
    banks = []
    rows_total = 0
    source_bytes = 0
    source_digest = hashlib.sha256()
    with zipfile.ZipFile(archive_path) as archive:
        index = json.loads(archive.read("index.json"))
        assert index["title"] == fixture["expectedTitle"]
        files = sorted(
            (
                entry for entry in archive.infolist()
                if entry.filename.startswith("term_bank_")
                and entry.filename.endswith(".json")
            ),
            key=lambda entry: int(entry.filename[10:-5]),
        )
        for bank_index, entry in enumerate(files):
            # ZipFile.read consumes the entry and verifies its CRC before parsing.
            source = archive.read(entry)
            source_bytes += len(source)
            source_digest.update(source)
            rows = json.loads(source)
            del source
            assert isinstance(rows, list)
            bank_counts = collections.Counter()
            bank_types = collections.Counter()
            for row in rows:
                assert isinstance(row, list) and len(row) >= 8
                score = row[4]
                score_type = type(score).__name__
                assert type(score) in (int, float)
                assert math.isfinite(score)
                key = f"{score_type}:{score!r}"
                bank_counts[key] += 1
                bank_types[score_type] += 1
            row_count = len(rows)
            rows_total += row_count
            counts.update(bank_counts)
            types.update(bank_types)
            banks.append({
                "filename": entry.filename,
                "rows": row_count,
                "uncompressedBytes": entry.file_size,
                "scoreTypeCounts": dict(bank_types),
                "scoreCardinality": len(bank_counts),
                "uniformScore": next(iter(bank_counts)) if len(bank_counts) == 1 else None,
            })
            del rows
            if (bank_index + 1) % 50 == 0 or bank_index + 1 == len(files):
                print(f"{name}: {rows_total}/{fixture['termRows']} rows, {bank_index + 1}/{len(files)} banks", file=sys.stderr, flush=True)
    assert rows_total == fixture["termRows"]
    census = {
        "fixture": fixture,
        "archiveSha256": archive_sha,
        "rows": rows_total,
        "termBanks": len(banks),
        "uncompressedTermSourceBytes": source_bytes,
        "concatenatedRawTermBanksSha256": source_digest.hexdigest(),
        "scoreTypeCounts": dict(types),
        "scoreValueCounts": dict(sorted(counts.items())),
        "scoreCardinality": len(counts),
        "uniformScore": next(iter(counts)) if len(counts) == 1 else None,
        "uniformRawBankCount": sum(bank["uniformScore"] is not None for bank in banks),
        "uniformRawBankRows": sum(bank["rows"] for bank in banks if bank["uniformScore"] is not None),
        "banks": banks,
    }
    report["dictionaries"][name] = census
    print(json.dumps({key: value for key, value in census.items() if key not in ("banks", "fixture", "scoreValueCounts")}), flush=True)

report["complete"] = True
report["peakResidentKiB"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
with output.open("x") as stream:
    json.dump(report, stream, indent=2)
    stream.write("\n")
