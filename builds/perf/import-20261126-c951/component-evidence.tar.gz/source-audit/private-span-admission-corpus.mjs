/*
 * Copyright (C) 2026 Manabitan authors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
/* eslint @stylistic/semi: ["error", "never"] */

import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {createReadStream, openAsBlob} from 'node:fs'
import {readFile, writeFile} from 'node:fs/promises'
import {join, resolve} from 'node:path'
import {pathToFileURL} from 'node:url'
import {Worker as ThreadWorker} from 'node:worker_threads'
import {BlobReader, Uint8ArrayWriter, ZipReader} from '@zip.js/zip.js'

// Actual production source planning and native workers; only the reservation
// admission is replayed. Per-group unique descriptors precede database-wide
// content deduplication, so these counts are not full-import persistence counts.
const [beforePath, afterPath, cachePath, outputPath, dictionary = 'jitendex', cpus = '4', memory = '8'] = process.argv.slice(2)
assert(beforePath && afterPath && cachePath && outputPath)
const beforeRoot = resolve(beforePath)
const afterRoot = resolve(afterPath)
const localImport = (root, filename) => import(pathToFileURL(join(root, filename)))
const parser = await localImport(beforeRoot, 'ext/js/dictionary/term-bank-wasm-parser.js')
const pipelineModule = await localImport(beforeRoot, 'ext/js/dictionary/term-bank-source-pipeline.js')
const beforeModule = await localImport(beforeRoot, 'ext/js/dictionary/dictionary-database.js')
const afterModule = await localImport(afterRoot, 'ext/js/dictionary/dictionary-database.js')
const {TermContentBlockStore} = await localImport(beforeRoot, 'ext/js/dictionary/term-content-block-store.js')
const {TermContentOpfsStore} = await localImport(beforeRoot, 'ext/js/dictionary/term-content-opfs-store.js')
const {resolveTermContentZstdDictName} = await localImport(beforeRoot, 'ext/js/dictionary/zstd-term-content.js')
const {isNativeImageProjectionSourceSizeEligible} = await localImport(beforeRoot, 'ext/js/dictionary/dictionary-importer.js')
const sha = (bytes) => createHash('sha256').update(bytes).digest('hex')
const lockBytes = await readFile(join(beforeRoot, 'test/perf/dictionaries.lock.json'))
assert.deepEqual(lockBytes, await readFile(join(afterRoot, 'test/perf/dictionaries.lock.json')))
const fixture = JSON.parse(lockBytes).dictionaries[dictionary]
assert(fixture)
const archivePath = join(cachePath, fixture.cacheFile)
const archiveHash = createHash('sha256')
for await (const bytes of createReadStream(archivePath)) { archiveHash.update(bytes) }
assert.equal(archiveHash.digest('hex'), fixture.sha256)
const archive = await openAsBlob(archivePath)
assert.equal(archive.size, fixture.sizeBytes)
const wasm = await readFile(join(beforeRoot, 'ext/lib/term-bank-parser.wasm'))
assert.deepEqual(wasm, await readFile(join(afterRoot, 'ext/lib/term-bank-parser.wasm')))
parser.setTermBankWasmModule(await WebAssembly.compile(wasm))

const terminations = []
const sourceGroups = []
class BrowserWorker extends EventTarget {
    constructor(url) {
        super()
        this.worker = new ThreadWorker(pathToFileURL(join(beforeRoot, 'test/fixtures/parser-settlement/worker-node.mjs')), {workerData: {url: url.href}})
        this.worker.on('message', (data) => this.dispatchEvent(new MessageEvent('message', {data})))
        this.worker.on('error', (error) => {
            const event = new Event('error')
            Object.defineProperty(event, 'message', {value: error.message})
            this.dispatchEvent(event)
        })
        this.worker.on('messageerror', () => this.dispatchEvent(new MessageEvent('messageerror')))
    }

    postMessage(data, transfer) {
        if (data.type === 'parse') {
            sourceGroups.push({id: data.id, files: data.sourceMetadata?.map(({filename}) => filename) ?? null, bytes: data.sourceBuffers.map((buffer) => buffer.byteLength)})
        }
        this.worker.postMessage(data, transfer)
    }

    terminate() { terminations.push(this.worker.terminate()) }
}
globalThis.Worker = BrowserWorker
Object.defineProperty(globalThis, 'navigator', {configurable: true, value: {hardwareConcurrency: Number(cpus), deviceMemory: Number(memory)}})

const reader = new ZipReader(new BlobReader(archive))
const entries = await reader.getEntries()
const termFiles = entries.filter(({filename}) => /^term_bank_\d+\.json$/.test(filename)).sort((a, b) => Number(a.filename.slice(10, -5)) - Number(b.filename.slice(10, -5)))
const rawTermBankSourceBytes = termFiles.reduce((sum, entry) => sum + entry.uncompressedSize, 0)
const rawReader = new pipelineModule.RawZipPayloadReader(archive)
const sourcePipeline = new pipelineModule.TermBankSourcePipeline({
    termFiles,
    enabled: true,
    read: async (file) => await file.getData(new Uint8ArrayWriter(), {useWebWorkers: false, checkSignature: true}),
    readCompressed: async (file, signal) => await rawReader.read(file, signal),
})
const groups = []
const profiles = []
const fullDigest = createHash('sha256')
const summary = {
    rows: 0,
    groups: 0,
    groupUniqueSpans: 0,
    privateGroups: 0,
    sharedGroups: 0,
    rejectedReservationGroups: 0,
    unchangedEligibleGroups: 0,
    beforeRejectedReservationCalls: 0,
    afterRejectedReservationCalls: 0,
    beforeRejectedSpanValidations: 0,
    afterRejectedSpanValidations: 0,
    uniformInt32ScoreGroups: 0,
    uniformInt32ScoreRows: 0,
}
const publicStore = new TermContentBlockStore(new TermContentOpfsStore())
let current = null
function createReplayDatabase(module, label) {
    const database = new module.DictionaryDatabase()
    database._termContentZstdInitialized = true
    database._termContentBlockImportSession = {
        tryBeginAppendSpans(title, source, offsets, lengths, name) {
            assert.equal(title, fixture.expectedTitle)
            assert(current !== null)
            ++current[`${label}Calls`]
            if (current.ineligible) {
                current[`${label}SpanValidations`] += offsets.length
                // This is the production public validator and admission path.
                // The known ineligible route cannot reserve or compress.
                return publicStore.tryBeginAppendSpans(source, offsets, lengths, name)
            }
            // Shared JMdict remains eligible in both versions. Do not begin
            // compression in this admission-only replay.
            return null
        },
    }
    return database
}
const before = createReplayDatabase(beforeModule, 'before')
const after = createReplayDatabase(afterModule, 'after')

async function consume(chunk) {
    const plan = chunk.contentDedupPlan
    const source = chunk.contentBytesBuffer
    assert(plan && source instanceof Uint8Array && chunk.contentMetaList instanceof Uint32Array)
    const offsets = new Uint32Array(plan.uniqueCount)
    const lengths = new Uint32Array(plan.uniqueCount)
    for (let i = 0; i < plan.uniqueCount; ++i) {
        const meta = (chunk.contentMetaByUniqueIndex ? i : plan.uniqueRowIndexes[i]) * 4
        offsets[i] = (chunk.contentBytesBaseOffset ?? 0) + chunk.contentMetaList[meta]
        lengths[i] = chunk.contentMetaList[meta + 1]
    }
    const shared = source.buffer instanceof SharedArrayBuffer
    const ineligible = resolveTermContentZstdDictName(fixture.expectedTitle) !== 'jmdict' || !shared
    const scores = new Set(chunk.scoreList.subarray(0, chunk.rowCount))
    const uniformInt32Score = chunk.scoreList instanceof Int32Array && chunk.rowCount > 5 && scores.size === 1
    current = {rows: chunk.rowCount, uniqueSpans: plan.uniqueCount, shared, ineligible, beforeCalls: 0, afterCalls: 0, beforeSpanValidations: 0, afterSpanValidations: 0, scoreCardinality: scores.size, uniformInt32Score, firstScore: chunk.scoreList[0]}
    const sourceBefore = sha(source)
    const offsetsBefore = offsets.slice()
    const lengthsBefore = lengths.slice()
    const spans = {buffer: source, offsets, lengths}
    assert.equal(before._tryBeginPersistArtifactTermContent(fixture.expectedTitle, spans), null)
    assert.equal(after._tryBeginPersistArtifactTermContent(fixture.expectedTitle, spans), null)
    assert.equal(sha(source), sourceBefore)
    assert.deepEqual(offsets, offsetsBefore)
    assert.deepEqual(lengths, lengthsBefore)
    assert.equal(current.beforeCalls, 1)
    assert.equal(current.afterCalls, ineligible ? 0 : 1)
    fullDigest.update(source)
    fullDigest.update(offsets)
    fullDigest.update(lengths)
    groups.push(current)
    summary.rows += chunk.rowCount
    ++summary.groups
    summary.groupUniqueSpans += plan.uniqueCount
    ++summary[shared ? 'sharedGroups' : 'privateGroups']
    ++summary[ineligible ? 'rejectedReservationGroups' : 'unchangedEligibleGroups']
    if (ineligible) {
        summary.beforeRejectedReservationCalls += current.beforeCalls
        summary.afterRejectedReservationCalls += current.afterCalls
        summary.beforeRejectedSpanValidations += current.beforeSpanValidations
        summary.afterRejectedSpanValidations += current.afterSpanValidations
    }
    if (uniformInt32Score) {
        ++summary.uniformInt32ScoreGroups
        summary.uniformInt32ScoreRows += chunk.rowCount
    }
    current = null
    if (summary.groups % 10 === 0 || summary.rows === fixture.termRows) {
        process.stderr.write(`${dictionary}: ${summary.rows}/${fixture.termRows} rows in ${summary.groups} groups\n`)
    }
}

const media = fixture.mediaFiles > 0
const options = {
    emitTermByteLists: false,
    computeContentHashes: true,
    emitContentSlab: true,
    emitTokenBinaryContent: true,
    mediaHintFastScan: media,
    projectImagePaths: media && isNativeImageProjectionSourceSizeEligible(rawTermBankSourceBytes),
    validateGlossaryTypes: true,
    prepareLookupIndexes: true,
    maxPendingChunks: 2,
}
let complete = false
let error = null
try {
    for (let start = 0; start < termFiles.length;) {
        const compressedPlan = sourcePipeline.createCompressedImportRunPlan(start)
        if (compressedPlan !== null) {
            assert.equal(await parser.parseTermBankWithWasmColumnChunksParallelCompressedLazy(compressedPlan.loaders, compressedPlan.estimatedByteLengths, 3, consume, options), true)
            profiles.push(parser.consumeLastTermBankWasmParseProfile())
            sourcePipeline.releaseBatch(compressedPlan.files)
            start += compressedPlan.files.length
        } else {
            const files = sourcePipeline.getBatch(start)
            const batch = await sourcePipeline.readBatch(files)
            if (batch?.promises) {
                assert.equal(await parser.parseTermBankWithWasmColumnChunksParallelDeferred(batch.promises, batch.estimatedByteLengths, 3, consume, options), true)
            } else {
                await parser.parseTermBankWithWasmColumnChunks(batch, 3, consume, 2048, {...options, singleChunk: true})
            }
            profiles.push(parser.consumeLastTermBankWasmParseProfile())
            sourcePipeline.releaseBatch(files)
            start += files.length
        }
    }
    assert.equal(summary.rows, fixture.termRows)
    complete = true
} catch (failure) {
    error = String(failure)
    throw failure
} finally {
    await sourcePipeline.dispose()
    await parser.disposeParallelTermBankParser()
    await Promise.all(terminations)
    await reader.close()
    const report = {
        complete,
        error,
        node: process.version,
        dictionary,
        hardwareConcurrency: Number(cpus),
        deviceMemory: Number(memory),
        fixture,
        rawTermBankSourceBytes,
        parserOptions: options,
        lockSha256: sha(lockBytes),
        parserWasmSha256: sha(wasm),
        beforeDatabaseSourceSha256: sha(await readFile(join(beforeRoot, 'ext/js/dictionary/dictionary-database.js'))),
        afterDatabaseSourceSha256: sha(await readFile(join(afterRoot, 'ext/js/dictionary/dictionary-database.js'))),
        scope: 'Actual source planner and native worker output, with pre-persistence unique descriptors through real rejected-reservation validation. No database-wide dedup, output-compression, whole-import timing, or persisted score-key allocation claim.',
        summary,
        unchangedInputBytesAndSpansSha256: fullDigest.digest('hex'),
        groups,
        sourceGroups,
        profiles,
    }
    await writeFile(outputPath, `${JSON.stringify(report, null, 2)}\n`, {flag: 'wx'})
    console.log(JSON.stringify({complete, error, ...summary}))
}
