# Uniform score-key staging: bounded encoder evidence

This bundle accompanies [Manabitan PR #949](https://github.com/ManabiIO/manabitan/pull/949).
It compares the actual production record-field encoder at the baseline and
candidate sources on deterministic synthetic inputs. All 28 comparisons produce
identical output bytes. It is not a dictionary-import benchmark.

**Outcome: withdrawn without merging after the corpus reach audit.** None of the
locked source banks in the three requested dictionaries is uniform, and reach
in smaller actual writer chunks was not established. The component result does
not justify shipping this candidate for those imports. This bundle is retained
as diagnostic evidence, including the negative result.

## Source identity

| Role | Commit | Tree |
| --- | --- | --- |
| Baseline | `0143e9596cd8f790d5e166d4ba6a2425fbc57f14` | `004fa8fde0055379ffbf22f9bbb60ae50f99114a` |
| Candidate, published | `97273b91c94a6385800bc5179afc684c818a786f` | `803fd3a06ee6cd275418a74655799d647b81b59a` |
| Candidate, local tested commit | `6d2cef5cb4a0f946bdfe6cd00e1284609287de3a` | `803fd3a06ee6cd275418a74655799d647b81b59a` |

`source-identities.json` records the file's Git blob and SHA-256 identities.
The replay checks both source hashes before importing either module. The local
and published candidate commits differ in commit metadata and share the exact
same tree.

## Reproduction

Prepare separate checkouts of the baseline and published candidate, with their
normal repository dependencies installed. Run with Node.js; the recorded run
used Node `v24.22.3`.

```sh
node replay.mjs /path/to/baseline /path/to/candidate /path/to/replayed-result.json
```

The output path is optional and defaults to `result.json` beside the script.
The script uses the production chunk factory in each checkout so each direct
reference case has the correct module's private origin proof. Generic-reference
cases remove that proof by spreading the chunk. It imports and calls the actual
production `_encodeArtifactRecordFields` method in both versions.

## Cases and measured work

| Input family | Cases | Purpose |
| --- | ---: | --- |
| Uniform scores `0`, `-200`, `-10200`, signed integer minimum and maximum | 10 | Both reference paths, inline table and map scores |
| A second score first appears at row 1, 63, or 127 | 6 | Earlier implicit zero keys and later mixed-score keys |
| 64, 65,535, or 65,536 distinct scores | 6 | Existing compact-size and reserved-score-count fallbacks |
| Content length 65,535, 65,536, or `0xffffffff` | 6 | Existing legacy field fallback |

Every comparison asserts full byte equality and records the resulting output
SHA-256. During each synchronous call, the script counts calls and source bytes
passed to the native `Uint16Array.prototype.set`; it restores the method in a
`finally` block before the next call.

Each uniform case contains 1,024 rows and saves one score-key copy of 2,048 bytes.
All ten uniform cases together avoid 20,480 copied bytes. Generic-reference cases
still copy their existing staged content lengths, as expected. The published
source also omits the `Uint16Array(rowCount)` scratch allocation for these
uniform-score chunks: two scratch bytes per row. This allocation reduction is
established by the changed source and its branch conditions; the script does
not measure process peak memory.

## Validation and limits

Eight newly added Vitest tests passed locally, including independent score
header and zero-key-column assertions. The full 23-case focused file lost its
worker after 11 passing tests without an assertion failure in that corrected
run. A scoped ESLint process exited 137. Hosted CI was still queued when the PR
was closed. Full-suite, lint, build, and browser validation are not established;
the local interrupted runs are not passes.

This bundle does not exercise native parsing, dictionary grouping, compression,
actual content offsets, OPFS or IndexedDB persistence, recovery, browser memory,
or whole-import latency. It does not prove how many real dictionary rows reach
the compact uniform-score branch. The separately collected full locked-corpus
source census found zero uniform raw banks in JMdict (53 banks, 528,299 rows),
Jitendex (219 banks, 436,555 rows), and VNDB (665 banks, 6,648,310 rows). VNDB uses
three scores, 50, 75, and 100. These bank-level observations do not establish
native record-chunk activation; no real-corpus allocation reduction is claimed.
Actual writer-chunk reach and import effects would need to be established before
this approach could be reconsidered. No synthetic timing for this candidate was
used as a shipping gate.

`negative-experiments.md` records the two discarded approaches and the local
resource-related interruptions. The `rejected` directory preserves their
patches and the noisy score-remapping screen so those results cannot be
mistaken for evidence about the published lazy-allocation candidate.
