# Rejected approaches and incomplete validation

Neither discarded patch below is part of PR #949. They were restored before
the reviewed lazy-allocation source and tests were committed. Their generated
native files are also absent from that candidate commit. PR #949 was later
withdrawn without merging because real-corpus activation was not established.

## Native unique-metadata staging

The prototype added a native entry point intended to reuse original row
metadata columns instead of staging arrays for each unique content item.
Inspection of the actual admission condition showed that it applied only when
`uniqueCount * 2 < rowCount`. The analyzed locked JMdict groups had a much larger
unique-content ratio, so this was not an executed JMdict opportunity. For very
high-duplication VNDB groups, passing complete original identity columns could
also increase the amount copied relative to the existing unique-row staging.

The prototype was rejected before a timing claim or full-corpus validation.
Its source patch is preserved at `rejected/unique-metadata-staging.patch.txt`.
The first native build also encountered ENOSPC in the shared workspace; the
baseline manifest was restored and a subsequent prototype build succeeded.
No native source or generated asset changed in the reviewed candidate commit.

## Direct score-key output with a second map pass

The second prototype avoided the score-key scratch buffer by looking up every
score key again while writing the final direct-reference columns. It introduced
extra map lookups and score reads. The reviewed lazy-allocation patch instead
retains the original single score scan and map lookup order.

An exploratory synthetic field-encoder screen used 30,000-row inputs, 16 calls
per arm and block, and eight alternating blocks. The raw observations are
preserved at `rejected/score-remapping-screen.json`. Its medians were 230.39 ms
for baseline and 325.15 ms for the discarded candidate. Individual observations
varied from tens of milliseconds to more than 11 seconds on the contended host.
This screen supplied no credible performance qualification; it gave no reason
to retain the extra lookup work. These timings must not be attributed to the
published lazy-allocation candidate or described as whole-import results.

A real production planner/native-worker JMdict replay of this discarded
candidate reached 480,000 rows with equal record/index bytes before the process
was killed with exit 137. It did not complete the 528,299-row corpus, and no
completed replay report was produced. That partial run is not final-candidate
or full-corpus evidence. Its patch is preserved at
`rejected/score-remapping.patch.txt`.

## Reviewed lazy-allocation candidate: interruptions and withdrawal

The first added uniform-score tests tried to spy on the global `Uint16Array`
constructor and then its prototype's `set` method. The constructor spy obscured
the native prototype, causing five harness errors before encoding. Removing the
constructor spy fixed the harness; the native `set` spy and independent byte
assertions remain. The eight new cases then passed.

The corrected full focused Vitest run ended with an unexpected worker exit
after 11 passing tests. The scoped ESLint command was killed with exit 137.
Neither interrupted command is reported as successful. The separate bounded
production-encoder replay completed all 28 comparisons, including the large
score-cardinality cases, without Vitest and without timing measurements.

The lazy-allocation candidate received independent source review from both
sibling agents. The completed locked-source census then found zero uniform raw
banks in all three requested dictionaries. Uniform smaller writer slices remain
possible but unproven. The PR was closed without merging, and the component
allocation/copy improvement is retained solely as diagnostic evidence. Hosted
checks were still queued when it closed; full hosted correctness, lint, type
checking, build, and actual browser import qualification were not established.
