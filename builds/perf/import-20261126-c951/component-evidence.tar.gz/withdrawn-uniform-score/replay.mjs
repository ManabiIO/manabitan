import assert from 'node:assert/strict'
import {createHash} from 'node:crypto'
import {readFile, writeFile} from 'node:fs/promises'
import path from 'node:path'
import {pathToFileURL} from 'node:url'

const [baselineRoot, candidateRoot, outputFile] = process.argv.slice(2)
if (!baselineRoot || !candidateRoot) {
    console.error('Usage: node replay.mjs BASELINE_ROOT CANDIDATE_ROOT [OUTPUT_JSON]')
    process.exit(2)
}
const sourcePath = 'ext/js/dictionary/term-record-opfs-store.js'
const identities = JSON.parse(await readFile(new URL('./source-identities.json', import.meta.url), 'utf8'))
const sources = {}
const modules = []
for (const [name, root] of [['baseline', baselineRoot], ['candidate', candidateRoot]]) {
    const filename = path.resolve(root, sourcePath)
    const sha256 = createHash('sha256').update(await readFile(filename)).digest('hex')
    assert.equal(sha256, identities[name].sourceSha256, `${name}: unexpected source file`)
    sources[name] = {path: sourcePath, sha256}
    modules.push(await import(pathToFileURL(filename).href))
}
const [baseline, candidate] = modules

const results = []

function make(module, count, scoreAt, generic, largeLength) {
    const chunk = module.createArtifactTermRecordChunkWithResolvedContent(
        {rowCount: count, scoreList: Int32Array.from({length: count}, (_, row) => scoreAt(row))},
        Uint32Array.from({length: count}, (_, row) => (row * 17) % count),
        Float64Array.from({length: count}, (_, row) => 2 ** 40 + row * 19),
        Uint32Array.from({length: count}, (_, row) => row % 31),
    )
    if (largeLength !== undefined) chunk.resolvedContentReferences.lengths[0] = largeLength
    return generic ? {...chunk} : chunk
}

function encode(module, chunk) {
    const original = Uint16Array.prototype.set
    let copies = 0
    let copiedBytes = 0
    Uint16Array.prototype.set = function (source, offset) {
        copies += 1
        copiedBytes += source.length * 2
        return original.call(this, source, offset)
    }
    try {
        const bytes = new module.TermRecordOpfsStore()._encodeArtifactRecordFields(chunk, [], [], 2 ** 40)
        return {bytes, copies, copiedBytes}
    } finally {
        Uint16Array.prototype.set = original
    }
}

function check(name, count, scoreAt, {generic = false, largeLength, uniform = false} = {}) {
    const before = encode(baseline, make(baseline, count, scoreAt, generic, largeLength))
    const after = encode(candidate, make(candidate, count, scoreAt, generic, largeLength))
    assert.deepEqual(after.bytes, before.bytes, name)
    if (uniform) {
        assert.equal(before.copies - after.copies, 1, `${name}: score-key copies`)
        assert.equal(before.copiedBytes - after.copiedBytes, count * 2, `${name}: copied bytes`)
        assert.equal(new DataView(after.bytes.buffer).getUint32(8, true), 1, `${name}: score count`)
    }
    results.push({name, count, generic, byteLength: after.bytes.byteLength, baselineCopies: before.copies, candidateCopies: after.copies, baselineCopiedBytes: before.copiedBytes, candidateCopiedBytes: after.copiedBytes, sha256: createHash('sha256').update(after.bytes).digest('hex')})
}

for (const generic of [false, true]) {
    for (const score of [0, -200, -10200, -2147483648, 2147483647]) {
        check(`uniform-${score}-${generic}`, 1024, () => score, {generic, uniform: true})
    }
    for (const firstChange of [1, 63, 127]) {
        check(`second-score-at-${firstChange}-${generic}`, 128, (row) => row === firstChange ? 999800 : -200, {generic})
    }
    for (const count of [64, 65535, 65536]) {
        check(`score-count-${count}-${generic}`, count, (row) => row - 32768, {generic})
    }
    for (const largeLength of [65535, 65536, 0xffffffff]) {
        check(`large-content-${largeLength}-${generic}`, 128, () => -200, {generic, largeLength})
    }
}

const output = {kind: 'actual production encoder component parity; deterministic synthetic input; no whole-import timing claim', node: process.version, sources, cases: results}
await writeFile(outputFile ? path.resolve(outputFile) : new URL('./result.json', import.meta.url), `${JSON.stringify(output, null, 2)}\n`)
console.log(JSON.stringify({cases: results.length, byteParity: true, uniformCases: results.filter((item) => item.name.startsWith('uniform')).length, uniformCopyBytesAvoided: results.filter((item) => item.name.startsWith('uniform')).reduce((total, item) => total + item.baselineCopiedBytes - item.candidateCopiedBytes, 0)}))
