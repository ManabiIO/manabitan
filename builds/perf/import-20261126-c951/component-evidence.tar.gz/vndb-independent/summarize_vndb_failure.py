#!/usr/bin/env python3
"""Describe original failed VNDB receipts; do not change qualification gates."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import zipfile

from qualification_receipts import GENERATION_MEDIA_PATH, GENERATION_MEDIA_RE, SQLITE_FILE_RE, SQLITE_PREFIX


artifacts_root = Path(sys.argv[1])
metadata_path = Path(sys.argv[2])
output_path = Path(sys.argv[3])
metadata = json.loads(metadata_path.read_bytes())
cells = []
source_identities = {}


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def normalized_non_sah(files):
    """A descriptive projection only; the original failing SAH gate still applies."""
    result = []
    for item in files:
        path = item["path"]
        if path.startswith(SQLITE_PREFIX):
            assert SQLITE_FILE_RE.fullmatch(path)
            continue
        if path.startswith("manabitan-dictionary-media-v1/"):
            assert GENERATION_MEDIA_RE.fullmatch(path)
            path = GENERATION_MEDIA_PATH
        result.append({"path": path, "bytes": item["bytes"]})
    return sorted(result, key=lambda item: item["path"])


def semantic_fields_without_storage(validation):
    """Compare the retained semantic data without reclassifying invalid storage."""
    result = deepcopy(validation)
    del result["storage"]
    for row in result["lookup"]["observations"]:
        del row["elapsedMs"]
    result["lookup"]["observations"].sort(key=lambda row: (row["pass"], row["term"]))
    return result


for order, arm in (("AB", "A"), ("BA", "B")):
    cell = f"vndb-{order}"
    root = artifacts_root / cell
    source_identities[order] = json.loads((root / "source-identities.json").read_bytes())["arms"]
    archive = artifacts_root / f"{cell}.zip"
    expected = next(item for item in metadata if item["name"] == f"private-content-reservations-{cell}-c951")
    archive_sha = digest(archive)
    assert archive_sha == expected["digest"].removeprefix("sha256:")
    assert archive.stat().st_size == expected["size_in_bytes"]
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        members = zipped.namelist()
        assert len(set(members)) == len(members)
    warmup = root / f"warmup-1-{arm}"
    summary = json.loads((warmup / "summary.json").read_bytes())
    raw = json.loads((warmup / "run-1.json").read_bytes())
    run = summary["runs"][0]
    validation = run["validation"]
    assert validation == raw["benchmark"]["validation"]
    imports = [phase for phase in raw["phases"] if phase.get("name") == "VNDB: total import"]
    assert len(imports) == 1
    phase_data = imports[0]["data"]
    assert run["importDebug"] == phase_data["importDebug"]
    assert run["step4Breakdown"] == phase_data["step4Breakdown"]
    timing = phase_data["browserTiming"]
    assert abs(run["totalImportMs"] - (timing["completedAtMs"] - timing["startedAtMs"])) <= 0.001
    assert timing["trigger"] == "file-input-change" and timing["errorCount"] == 0
    assert timing["sequence"] > timing["sequenceBefore"]
    assert summary["source"]["dirty"] is False
    assert raw["status"] == "success" and raw["skippedVerification"] is False
    assert raw["launchMode"] == "headless" and raw["browserFlavor"] == "chromium"
    assert raw["hostEnvironment"]["nodeVersion"] == "v22.22.0"
    assert raw["benchmark"]["productionImportDefaults"] is True
    assert raw["benchmark"]["pinnedDictionaries"] is True
    assert raw["benchmark"]["importFlags"] is None
    files = validation["storage"]["files"]
    assert validation["storage"]["bytes"] == sum(item["bytes"] for item in files)
    sah = sorted(item["bytes"] for item in files if item["path"].startswith(SQLITE_PREFIX))
    assert len(sah) == 8 and sah.count(4096) == 7
    active = next(size for size in sah if size != 4096)
    assert active % 4096 == 0
    phases = run["importDebug"]["importerPhaseTimings"]
    source_phases = [phase for phase in phases if phase["phase"].startswith("term-file-fast-path:")]
    metrics = [phase["details"] for phase in source_phases]
    source_keys = [
        "rows", "chunkCount", "parserParallelWorkerCount", "parserParallelPipelineGroupsPerWorker",
        "parserParallelGroupCount", "parserFusedAttempts", "parserFusedFallbacks",
        "parserCompactContentMetadataGroups", "parserBorrowedContentResultCount",
        "parserParallelOwnedContentBytes", "parserEncodedContentBytes", "dedupNativeCallCount",
        "dedupNativeScannedRows", "dedupNativeBulkPendingRows", "dedupNativeExactCandidates",
        "dedupNativeFallbackCount", "dedupPendingHitCount", "dedupPersistedHitCount",
        "dedupUniqueCount", "dedupExactFallbackCount", "contentInitialReservationCount",
        "contentInitialReservationSavingsMissCount",
    ]
    selected = [{key: metric.get(key) for key in source_keys} for metric in metrics]
    cells.append({
        "cell": cell, "initialOrder": order, "armActuallyObserved": arm,
        "artifactId": expected["id"], "artifactSha256": archive_sha,
        "artifactSizeBytes": archive.stat().st_size, "artifactCrcPassed": True,
        "artifactMembers": members, "sourceSha": summary["gitSha"],
        "packageSha256": run["packageSha256"], "browserVersion": raw["browserVersion"],
        "rawBenchmarkStatus": raw["status"], "qualified": False,
        "observedWarmupOnlyMsNotComparable": run["totalImportMs"],
        "failure": "VNDB active SAH allocation is outside 129–131 pages",
        "originalActiveSahRequiredPages": [129, 131],
        "originalActiveSahRequiredBytes": [129 * 4096, 131 * 4096],
        "actualActiveSahPages": active // 4096, "actualActiveSahBytes": active,
        "allSahFileSizes": sah,
        "reportedStorageBytes": validation["storage"]["bytes"],
        "nonSahStorageInventory": normalized_non_sah(files),
        "reportedOutputDigestSha256": validation["outputDigestSha256"],
        "lookupObservationCount": len(validation["lookup"]["observations"]),
        "sampleMedia": validation["media"], "restart": validation["restart"],
        "semanticFieldsWithoutStorageOrLookupTimings": semantic_fields_without_storage(validation),
        "useImportSession": run["importDebug"]["useImportSession"],
        "finalizeImportSession": run["importDebug"]["finalizeImportSession"],
        "sourcePhaseMetrics": selected,
        "reportedPendingUniqueDescriptors": sum(metric["dedupUniqueCount"] for metric in metrics),
        "explicitRejectedReservationCounterPresent": any("rejected" in key.lower() and "reservation" in key.lower() for metric in metrics for key in metric),
        "remainingTimingObservationsAcquired": False,
        "exhaustiveMediaAcquired": False, "memoryAcquired": False,
    })

a, b = cells
same_semantics = a["semanticFieldsWithoutStorageOrLookupTimings"] == b["semanticFieldsWithoutStorageOrLookupTimings"]
same_product = a["nonSahStorageInventory"] == b["nonSahStorageInventory"]
same_sah = a["allSahFileSizes"] == b["allSahFileSizes"]
cross_cell_packages = {}
for arm in ("A", "B"):
    first = source_identities["AB"][arm]
    second = source_identities["BA"][arm]
    cross_cell_packages[arm] = {
        "memberCount": len(first["entries"]),
        "allMemberHashesEqual": first["entries"] == second["entries"],
        "zipBytesEqual": first["packageSha256"] == second["packageSha256"],
        "packageSha256AB": first["packageSha256"],
        "packageSha256BA": second["packageSha256"],
        "sourceHashDifferences": [key for key in first["sourceHashes"] if first["sourceHashes"][key] != second["sourceHashes"].get(key)],
    }
report = {
    "schemaVersion": 1, "runId": 45862057912,
    "acquisitionCommit": "7e6dda05470da6e29af2b06bc50dde26f14633fb",
    "scope": "Descriptive comparison of the only acquired original warmups. Both remain unqualified under the unchanged original storage gate. No paired speedup, full-media parity, or memory conclusion is available.",
    "bothOriginalQualificationCellsFailed": True,
    "originalStorageGateUnchanged": True,
    "reportedSemanticFieldsEqualExcludingStorageAndLookupElapsedMs": same_semantics,
    "allNonSahProductStorageSizesEqualAfterOnlyGenerationUuidNormalization": same_product,
    "allSahSizeMultisetsEqual": same_sah,
    "reportedTotalStorageBytesEqual": a["reportedStorageBytes"] == b["reportedStorageBytes"],
    "crossCellPackageIdentity": cross_cell_packages,
    "cells": cells,
    "activationInterpretation": "The generic dictionary is rejected by the old reservation predicate, so removing its scan is supported by source reasoning on the reported native route and pending unique descriptors. No explicit rejected-attempt counter was acquired. These are failed-cell diagnostic metrics, not qualifying latency measurements.",
}
output_path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
print(json.dumps({key: value for key, value in report.items() if key != "cells"}, indent=2))
