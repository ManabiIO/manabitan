# Canonical adapter phase diagnostic

The six fixed alternating pairs completed with twelve retained measured observations. All row, reference, canonical-byte, exact-descriptor and path-count oracles agree, and source, runner, archive and WASM identities are unchanged. The original harness verifies two warmups within each child but does not export their raw timers. No exclusions or retries occurred.

Instrumented medians over the complete dictionary component replay are 24.20 ms in the native call, 2.86 ms in input staging, 9.47 ms in output/adoption, 0.09 ms in arena/instance setup, and 0.07 ms in the resolved module await. The native call accounts for a median 56.1% of resolver time after subtracting its own exact-comparison timer. These sequential nested phases are not exhaustive or additive whole-import measurements.

The source groups 53 banks into eight seven-bank groups, unlike the browser planner. It scans 364,609 unique rows, adopts 360,859 pending rows and queues 3,750 exact descriptors; 2,915 use recent sources and 835 use exact-byte virtual storage. No OPFS, checksum or decompression cost is modeled. The 48 MiB cache policy is unchanged.

A read-only reviewer found no success-path timer overlap or rollback change. Error-path accounting is incomplete: early free-ID/missing-arena errors, failed staging, hooks and rollback are outside some phase timers. Module compilation is outside timing, and the module await includes promise scheduling.

A/B elapsed differences reflect instrumentation and host variation, not an optimization. This diagnostic supports a separately measured immutable-config candidate while retaining every volatile header store and journal barrier.
