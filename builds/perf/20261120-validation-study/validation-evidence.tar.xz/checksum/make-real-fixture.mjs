import fs from 'node:fs/promises'
import path from 'node:path'
import assert from 'node:assert/strict'
import {fileURLToPath,pathToFileURL} from 'node:url'
import {createHash} from 'node:crypto'
import {ZipReader,Uint8ArrayReader,Uint8ArrayWriter} from '@zip.js/zip.js'
const target=new URL('./real-fixture/',import.meta.url)
const sourceRoot='/workspace/scratch/f34c9c9fae89/manabitan'
const archivePath='/workspace/scratch/f34c9c9fae89/fixtures/JMdict.zip'
const sha=b=>createHash('sha256').update(b).digest('hex')
const load=rel=>import(pathToFileURL(path.join(sourceRoot,rel)))
const originalFetch=globalThis.fetch
globalThis.fetch=async(input,init)=>{
 const url=new URL(String(input))
 return url.protocol==='file:'?new Response(await fs.readFile(url),{headers:{'Content-Type':'application/wasm'}}):await originalFetch(input,init)
}
const parser=await load('ext/js/dictionary/term-bank-wasm-parser.js')
const {TermContentOpfsStore}=await load('ext/js/dictionary/term-content-opfs-store.js')
const {TermContentBlockStore}=await load('ext/js/dictionary/term-content-block-store.js')
const {initializeTermContentZstd}=await load('ext/js/dictionary/zstd-term-content.js')
const {decodeRawTermContentCompactBlockReference,RAW_TERM_CONTENT_COMPACT_BLOCK_REFERENCE_BYTES}=await load('ext/js/dictionary/raw-term-content.js')
const archive=await fs.readFile(archivePath)
assert.equal(sha(archive),'7681ee09f9edfef48a5e50773565da237424eb750bdb0e1e59660784ecd53e8a')
await initializeTermContentZstd()
const wasm=await fs.readFile(path.join(sourceRoot,'ext/lib/term-bank-parser.wasm'))
parser.setTermBankWasmModule(await WebAssembly.compile(wasm))
const reader=new ZipReader(new Uint8ArrayReader(new Uint8Array(archive)))
const entries=(await reader.getEntries()).filter(e=>/^term_bank_\d+\.json$/.test(e.filename)).sort((a,b)=>Number(a.filename.slice(10,-5))-Number(b.filename.slice(10,-5)))
const store=new TermContentOpfsStore()
const blockStore=new TermContentBlockStore(store)
const captured=[]
const allWrites=[]
const expectedBlocks=new Map()
let lastDerivedWrites=[]
const append=store.appendBatchWithDerivedChunks.bind(store)
store.appendBatchWithDerivedChunks=async(primary,derive)=>{
 let derived
 const result=await append(primary,(offsets,lengths)=>{
  derived=derive(offsets,lengths)
  return derived
 })
 for(let i=0;i<primary.length;i++){
  const bytes=new Uint8Array(primary[i])
  captured.push({offset:result.primaryOffsets[i],bytes})
  allWrites.push({offset:result.primaryOffsets[i],bytes})
 }
 lastDerivedWrites=derived.map((bytes,index)=>({offset:result.derivedOffsets[index],bytes}))
 for(let i=0;i<derived.length;i++)allWrites.push({offset:result.derivedOffsets[i],bytes:new Uint8Array(derived[i])})
 return result
}
const requests=[]
const groups=[]
let totalRows=0
let totalUnique=0
for(let start=0;start<entries.length;start+=7){
 const group=entries.slice(start,start+7)
 const sources=[]
 for(const entry of group)sources.push(await entry.getData(new Uint8ArrayWriter(),{useWebWorkers:false,checkSignature:true}))
 await parser.parseTermBankWithWasmColumnChunks(sources,3,async chunk=>{
  assert.equal(chunk.contentRowStart,0)
  assert.ok(chunk.contentDedupPlan)
  const uniqueRows=chunk.contentDedupPlan.uniqueRowIndexes
  const offsets=Uint32Array.from(uniqueRows,row=>chunk.contentBytesBaseOffset+chunk.contentMetaList[row*4])
  const lengths=Uint32Array.from(uniqueRows,row=>chunk.contentMetaList[row*4+1])
  const result=await blockStore.tryAppendSpans(chunk.contentBytesBuffer,offsets,lengths,'jmdict')
  assert.ok(result)
  let slabIndex=0
  for(let index=0;index<uniqueRows.length;index++){
   const address=result.contentOffsets[index]
   while(address>=lastDerivedWrites[slabIndex].offset+lastDerivedWrites[slabIndex].bytes.length)slabIndex++
   const slab=lastDerivedWrites[slabIndex]
   const local=address-slab.offset
   const reference=decodeRawTermContentCompactBlockReference(slab.bytes.subarray(local,local+RAW_TERM_CONTENT_COMPACT_BLOCK_REFERENCE_BYTES),result.contentLengths[index])
   assert.ok(reference)
   let expected=expectedBlocks.get(reference.blockOffset)
   if(!expected){
    expected={hasher:createHash('sha256'),length:0,reference,context:{contentOffset:address,contentLength:result.contentLengths[index],contentDictName:result.contentDictName}}
    expectedBlocks.set(reference.blockOffset,expected)
   }
   assert.equal(reference.entryOffset,expected.length)
   const bytes=chunk.contentBytesBuffer.subarray(offsets[index],offsets[index]+lengths[index])
   expected.hasher.update(bytes)
   expected.length+=bytes.length
  }
  const selected=[]
  for(let index=0;index<uniqueRows.length;index+=512)selected.push(index)
  if(selected.at(-1)!==uniqueRows.length-1)selected.push(uniqueRows.length-1)
  for(const index of selected){
   const request={contentOffset:result.contentOffsets[index],contentLength:result.contentLengths[index],contentDictName:result.contentDictName}
   const refBytes=await store.readSlice(request.contentOffset,RAW_TERM_CONTENT_COMPACT_BLOCK_REFERENCE_BYTES)
   const reference=decodeRawTermContentCompactBlockReference(refBytes,request.contentLength)
   assert.ok(reference)
   const expected=chunk.contentBytesBuffer.subarray(offsets[index],offsets[index]+lengths[index])
   requests.push({...request,expectedSha256:sha(expected),group:start/7,uniqueIndex:index,blockOffset:reference.blockOffset})
  }
  groups.push({banks:group.map(e=>e.filename),rows:chunk.rowCount,unique:uniqueRows.length,compressedBytes:result.compressedBytes,uncompressedBytes:result.uncompressedBytes,selected:selected.length})
  totalRows+=chunk.rowCount
  totalUnique+=uniqueRows.length
 },2048,{singleChunk:true,emitTermByteLists:false,computeContentHashes:true,emitContentSlab:true,emitTokenBinaryContent:true,mediaHintFastScan:true,validateGlossaryTypes:true,prepareLookupIndexes:true})
}
await reader.close()
assert.equal(totalRows,526942)
const seen=new Set(requests.map(r=>r.blockOffset))
assert.equal(seen.size,captured.length)
const imageLength=Math.max(...allWrites.map(w=>w.offset+w.bytes.byteLength))
const image=new Uint8Array(imageLength)
for(const w of allWrites)image.set(w.bytes,w.offset)
await fs.mkdir(target,{recursive:true})
await fs.writeFile(new URL('store.bin',target),image)
const manifest={scope:'JMdict-derived component corpus; seven-bank parser grouping, per-group unique content, no cross-group content deduplication; normal 4 MiB production packer and JMdict Zstd compression; not a full import',sourceRoot,sourceCommit:'bde55dfbee1451edc32051f8bf51e8a870d5c72c',archiveSha256:sha(archive),wasmSha256:sha(wasm),storeSha256:sha(image),storeBytes:imageLength,totalRows,totalUnique,groups,blocks:captured.map(({offset,bytes})=>{
 const expected=expectedBlocks.get(offset)
 assert.equal(expected.length,expected.reference.blockUncompressedLength)
 return {offset,length:bytes.byteLength,sha256:sha(bytes),payloadSha256:sha(bytes.subarray(12)),uncompressedLength:expected.length,uncompressedSha256:expected.hasher.digest('hex'),reference:expected.reference,context:expected.context}
}),requests}
await fs.writeFile(new URL('manifest.json',target),JSON.stringify(manifest,null,2)+'\n')
console.log(JSON.stringify({storeBytes:imageLength,groups:groups.length,totalRows,totalUnique,blocks:captured.length,requests:requests.length,storeSha256:manifest.storeSha256}))
