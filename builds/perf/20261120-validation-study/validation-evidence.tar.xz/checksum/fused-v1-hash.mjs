/*
 * Copyright (C) 2026  Manabitan authors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */


const HEX_BYTE_TABLE = Array.from({length: 256}, (_, i) => i.toString(16).padStart(2, '0'));

/**
 * @param {number} h1
 * @param {number} h2
 * @returns {string}
 */
export function hashPairToHex(h1, h2) {
    const a = h1 >>> 0;
    const b = h2 >>> 0;
    return (
        HEX_BYTE_TABLE[(a >>> 24) & 0xff] +
        HEX_BYTE_TABLE[(a >>> 16) & 0xff] +
        HEX_BYTE_TABLE[(a >>> 8) & 0xff] +
        HEX_BYTE_TABLE[a & 0xff] +
        HEX_BYTE_TABLE[(b >>> 24) & 0xff] +
        HEX_BYTE_TABLE[(b >>> 16) & 0xff] +
        HEX_BYTE_TABLE[(b >>> 8) & 0xff] +
        HEX_BYTE_TABLE[b & 0xff]
    );
}

/**
 * @param {Uint8Array} bytes
 * @returns {[number, number]}
 */
export function hashTermEntryContentBytesPair(bytes) {
    return hashContentXxh32Pair(bytes)
}

/**
 * @param {Uint8Array} bytes
 * @returns {string}
 */
export function hashTermEntryContentBytes(bytes) {
    const [h1, h2] = hashTermEntryContentBytesPair(bytes);
    return hashPairToHex(h1, h2);
}

/**
 * @param {number} value
 * @param {number} amount
 * @returns {number}
 */
function rotateLeft32(value, amount) {
    return (((value << amount) >>> 0) | (value >>> (32 - amount))) >>> 0;
}

/**
 * @param {Uint8Array} bytes
 * @param {number} offset
 * @returns {number}
 */
function readUint32Le(bytes, offset) {
    return (
        bytes[offset] |
        (bytes[offset + 1] << 8) |
        (bytes[offset + 2] << 16) |
        (bytes[offset + 3] << 24)
    ) >>> 0;
}

/**
 * @param {number} accumulator
 * @param {number} input
 * @returns {number}
 */
function xxh32Round(accumulator, input) {
    accumulator = (accumulator + Math.imul(input >>> 0, 2246822519)) >>> 0;
    accumulator = rotateLeft32(accumulator, 13);
    return Math.imul(accumulator, 2654435761) >>> 0;
}

/**
 * @param {Uint8Array} bytes
 * @returns {[number, number]}
 */
function hashContentXxh32Pair(bytes) {
    let offset = 0
    const length = bytes.length
    const seed1 = 0x811c9dc5
    const seed2 = 0x9e3779b9
    let h1
    let h2
    if (length >= 16) {
        const limit = length - 16
        let a1 = (seed1 + 2654435761 + 2246822519) >>> 0
        let a2 = (seed1 + 2246822519) >>> 0
        let a3 = seed1 >>> 0
        let a4 = (seed1 - 2654435761) >>> 0
        let b1 = (seed2 + 2654435761 + 2246822519) >>> 0
        let b2 = (seed2 + 2246822519) >>> 0
        let b3 = seed2 >>> 0
        let b4 = (seed2 - 2654435761) >>> 0
        do {
            const input1 = readUint32Le(bytes, offset)
            const input2 = readUint32Le(bytes, offset + 4)
            const input3 = readUint32Le(bytes, offset + 8)
            const input4 = readUint32Le(bytes, offset + 12)
            a1 = xxh32Round(a1, input1)
            a2 = xxh32Round(a2, input2)
            a3 = xxh32Round(a3, input3)
            a4 = xxh32Round(a4, input4)
            b1 = xxh32Round(b1, input1)
            b2 = xxh32Round(b2, input2)
            b3 = xxh32Round(b3, input3)
            b4 = xxh32Round(b4, input4)
            offset += 16
        } while (offset <= limit)
        h1 = (
            rotateLeft32(a1, 1) +
            rotateLeft32(a2, 7) +
            rotateLeft32(a3, 12) +
            rotateLeft32(a4, 18)
        ) >>> 0
        h2 = (
            rotateLeft32(b1, 1) +
            rotateLeft32(b2, 7) +
            rotateLeft32(b3, 12) +
            rotateLeft32(b4, 18)
        ) >>> 0
    } else {
        h1 = (seed1 + 374761393) >>> 0
        h2 = (seed2 + 374761393) >>> 0
    }
    h1 = (h1 + length) >>> 0
    h2 = (h2 + length) >>> 0
    while ((offset + 4) <= length) {
        const input = Math.imul(readUint32Le(bytes, offset), 3266489917)
        h1 = (h1 + input) >>> 0
        h2 = (h2 + input) >>> 0
        h1 = Math.imul(rotateLeft32(h1, 17), 668265263) >>> 0
        h2 = Math.imul(rotateLeft32(h2, 17), 668265263) >>> 0
        offset += 4
    }
    while (offset < length) {
        const input = Math.imul(bytes[offset], 374761393)
        h1 = (h1 + input) >>> 0
        h2 = (h2 + input) >>> 0
        h1 = Math.imul(rotateLeft32(h1, 11), 2654435761) >>> 0
        h2 = Math.imul(rotateLeft32(h2, 11), 2654435761) >>> 0
        ++offset
    }
    h1 = finishHash(h1)
    h2 = finishHash(h2)
    if ((h1 | h2) === 0) { h1 = 1 }
    return [h1, h2]
}

/**
 * @param {number} h32
 * @returns {number}
 */
function finishHash(h32) {
    h32 ^= h32 >>> 15;
    h32 = Math.imul(h32, 2246822519) >>> 0;
    h32 ^= h32 >>> 13;
    h32 = Math.imul(h32, 3266489917) >>> 0;
    h32 ^= h32 >>> 16;
    return h32 >>> 0;
}
