import fs from 'node:fs/promises'
import os from 'node:os'
import {performance} from 'node:perf_hooks'
import {hashTermEntryContentBytesPair as candidate} from '../../../ext/js/dictionary/term-entry-content-hash.js'
import {hashTermEntryContentBytesPair as baseline} from './baseline-hash.mjs'
const functions={A:baseline,B:candidate}
const cases=[4097,16384,65537,262144].map(length=>({length,bytes:Uint8Array.from({length},(_,i)=>(i*131+length*17+(i>>3))&255)}))
const observations=[]
for(const c of cases){
 const repetitions=Math.max(2,Math.floor(16*1024*1024/c.length))
 const run=arm=>{
  const start=performance.now()
  let witness=0
  for(let i=0;i<repetitions;i++){
   const [a,b]=functions[arm](c.bytes)
   witness=(witness^a^b)>>>0
  }
  return {arm,ms:performance.now()-start,witness}
 }
 for(let i=0;i<4;i++){run('A');run('B')}
 for(let block=0;block<8;block++){
  for(const arm of block%2===0?['A','B','B','A']:['B','A','A','B'])observations.push({length:c.length,repetitions,block,...run(arm)})
 }
}
const med=x=>{const s=[...x].sort((a,b)=>a-b);return(s[s.length/2-1]+s[s.length/2])/2}
const summary=cases.map(c=>{
 const a=observations.filter(x=>x.length===c.length&&x.arm==='A')
 const b=observations.filter(x=>x.length===c.length&&x.arm==='B')
 return {length:c.length,baselineMs:med(a.map(x=>x.ms)),candidateMs:med(b.map(x=>x.ms)),ratio:med(b.map(x=>x.ms))/med(a.map(x=>x.ms))}
})
const result={scope:'synthetic screen only; not whole-import evidence',node:process.version,host:os.cpus()[0].model,summary,observations}
await fs.writeFile('builds/perf/20261120-hash-pair/synthetic-results.json',JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({summary}))
