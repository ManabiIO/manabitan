# JMdict checksum candidate, November 20

## Frozen source

- Baseline: `bde55dfbee1451edc32051f8bf51e8a870d5c72c`.
- Candidate: `025596858e4e176d92c8f7f016057317c60c2793`; tree `cbd4e38c90b1776094185633649e924ef2b03a09`.
- One runtime file changes: `ext/js/dictionary/term-entry-content-hash.js`; one independent-vector test file is added.
- Baseline hash source SHA256: `3a661e6875bf8dcb4c3b9f301e79506539b27d83cb069b3d5566e9bad9346620`.
- Candidate hash source SHA256: `99429f2a812ccac6538c914555775895c5a1115325dd9b0eb42886d23fbca23d`.

The pair used to scan each payload twice. The candidate shares each 32-bit input load and its first XXH32 multiplication while maintaining independent per-seed accumulators, tails, avalanche and zero-pair reservation. Owned and stable shared inputs remain unchanged. Concurrent mutation is not a coherent hash contract.

A read-only independent reviewer checked unsigned arithmetic, rotations, loop boundaries, tails, byte offsets, ownership and the sentinel and found no blocker. The fixed tests use upstream libxxhash 0.8.3 values, not writer/reader self-consistency alone.

## Component evidence

`frozen-cohort.json`, `real-component-results.json` and `real-component-summary.json` retain the protocol and every observation. There are two separate stages, 24 balanced four-arm blocks per stage, two warmups per arm: 208 observations / 192 measured. A/C are the same baseline; B/D the same candidate. No retries, exclusions, pooling or control subtraction.

The corpus uses the locked JMdict archive, all 526,942 source rows, seven-bank component grouping and per-group unique content, without cross-group deduplication. The actual production packer produces 28 blocks with 12,256,060 compressed payload bytes. Store image: 19,548,576 bytes, SHA256 `4cee541ed8c6869e9ad8ec4c400f9fb61fcbf00f6e995a0a5df6d274fcd586f0`.

Standalone real-payload checksums: median paired B/A -46.93%, D/A -46.49%; controls C/A -1.04%, D/B -2.42%. Production block reader, backed by memory storage: B/A -8.86%, D/A -6.46%; controls C/A -2.78%, D/B +0.02%. Reader arm medians A/B/C/D: 91.49/83.44/86.43/84.22 ms. These are component observations, not browser import improvements. In particular, the reader baseline control also moved favorably.

Every decoded block (100,671,677 bytes total) matches SHA256 values assembled from the original parser content spans; all 725 selected public-reader references match expected source bytes. Both source readers agree on five corrupted magic/hash/payload/frame cases. `real-reader-parity.json` records this validation outside timing. The source, runner, input manifest and store image are checked before/after the fixed cohort. Explicit GC occurs outside each timed observation.

No OPFS file I/O, production cache-miss frequency, browser engine behavior, concurrent compression, or peak memory is measured by this component test. Source construction, parsing, compression and verification are outside time.

## Retained exploration and remaining checks

The first helper-based fusion was 2.1–5.2 times slower in a preliminary synthetic V8 screen and was rejected. `fused-v1-hash.mjs` and `synthetic-v1-results.json` retain that source/result identity. The second synthetic screen suggested a gain but preceded cosmetic source freeze; it is exploratory and is not source-pinned qualification. The fixed real-block cohort above supplies the qualified component source identity.

The supplemental small-input cohort is frozen separately in `small-frozen-cohort.json`: 31 independent cases, including 27 boundary lengths and four actual canonical-entry buckets. It completed in an isolated host interval on the same frozen source, from 10:38:37 to 10:38:56 UTC, after both correctness suites finished. All 962 payloads have independent native XXH32 values. There were 3,224 observations, of which 2,976 were measured, with no retries or exclusions. B/A and D/A median paired changes were favorable in every case; B/A ranged from -25.57% to -44.50%. Same-source control medians across cases ranged from about -6.50% to +6.14% and were not subtracted. The four actual-entry buckets improved by -37.00% to -41.91% for B/A. These results remain separate from the real-block cohort and cover local V8 only; they do not qualify Firefox or whole imports. Raw and summarized results are in `small-component-results.json` and `small-component-summary.json`.

Six focused files passed 353 tests. Required main and test types, all seven dry-build targets and the full suite passed: 620 files, 13,866 passed, 47 skipped, completed at 10:37:27 UTC. `required-validation.json` records the exact commands and complete log identities. All five generated WASM assets are copied unchanged from the baseline and checked before/after validation. Initial setup failures and corrections are summarized in `setup-attempts.json`.

## Pipeline audit and next measurements

Since the earlier d829 baseline, develop merged publication runs, shared-source cache copies, key-escape hints, and adjacent bounded-key reuse. Canonical scanning and exact block-reader logic are otherwise unchanged in the inspected diff.

The exact-match path already batches reference reads, groups requests by compressed block, shares in-flight loads, checks the stored checksum, bounds decompression, and preserves ordered collision matching. Basic batching is already present. No cache budget, durability, compression, worker, cancellation or storage-format policy is changed here.

For a separate diagnostic build, attribute canonical scan time to module/arena setup, input staging, native call and pending-column adoption. Attribute uncached exact matching to reference reads, compressed-block read, checksum, decompression and equality. Aggregate nested timings separately; do not sum them into whole-import time.

A further native-code lead is repeated configuration access in `scan_canonical` around the insertion memory barrier. The configuration words are immutable within a synchronous call on nonshared memory, so explicit local snapshots are a possible separate hypothesis. All volatile header progress, especially the committed journal count before mutation, would remain intact. Local header counters would be a separate, more invasive idea and are not proposed for this iteration. Any native candidate first requires measured native subphase cost and adversarial rollback validation. No native edit was made in this study; the read-only audit and diagnostic plan are in `canonical-header-audit.md`.
