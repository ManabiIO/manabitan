from pathlib import Path
import json
import ctypes
import ctypes.util
import base64
import hashlib

root = Path(__file__).resolve().parent
library = ctypes.CDLL(ctypes.util.find_library('xxhash'))
library.XXH_versionNumber.restype = ctypes.c_uint
assert library.XXH_versionNumber() == 803
library.XXH32.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_uint]
library.XXH32.restype = ctypes.c_uint
seeds = [0x811c9dc5, 0x9e3779b9]


def hashes(payload):
    pointer = ctypes.create_string_buffer(payload)
    result = [library.XXH32(pointer, len(payload), seed) for seed in seeds]
    if not any(result):
        result[0] = 1
    return result


lengths = [0, 1, 3, 4, 7, 8, 15, 16, 17, 31, 32, 33, 63, 64, 65, 127, 128, 129, 255, 256, 257, 511, 512, 513, 1023, 1024, 1025]
cases = []
for length in lengths:
    payloads = []
    for variant in range(32):
        payload = bytes((i * 131 + 17 * length + (i >> 3) + 23 * variant) & 255 for i in range(length))
        payloads.append({
            'bytes': base64.b64encode(payload).decode(),
            'sha256': hashlib.sha256(payload).hexdigest(),
            'expected': hashes(payload),
            'viewOffset': [0, 1, 3, 7][variant % 4],
        })
    cases.append({'name': f'synthetic-{length}', 'kind': 'synthetic-boundary', 'payloads': payloads})
source = json.loads((root / 'small-canonical-source.json').read_text())
for case in source['cases']:
    for index, item in enumerate(case['payloads']):
        payload = base64.b64decode(item['bytes'])
        item['expected'] = hashes(payload)
        item['viewOffset'] = [0, 1, 3, 7][index % 4]
    cases.append({**case, 'kind': 'actual-canonical'})
fixture = {
    'oracle': 'system libxxhash0.8.3 XXH32',
    'seeds': seeds,
    'sourceStoreSha256': source['storeSha256'],
    'archiveSha256': source['archiveSha256'],
    'cases': cases,
}
(root / 'small-fixture.json').write_text(json.dumps(fixture, indent=2) + '\n')
print(json.dumps({
    'cases': len(cases),
    'payloads': sum(len(case['payloads']) for case in cases),
    'sha256': hashlib.sha256((root / 'small-fixture.json').read_bytes()).hexdigest(),
}))
