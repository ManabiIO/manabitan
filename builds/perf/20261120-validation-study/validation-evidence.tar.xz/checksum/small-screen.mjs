import fs from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import assert from 'node:assert/strict'
import {pathToFileURL,fileURLToPath} from 'node:url'
import {createHash} from 'node:crypto'
import {performance} from 'node:perf_hooks'
const here=fileURLToPath(new URL('./',import.meta.url))
const baselineRoot='/workspace/scratch/f34c9c9fae89/manabitan'
const candidateRoot=fileURLToPath(new URL('../../../',import.meta.url))
const hashPath='ext/js/dictionary/term-entry-content-hash.js'
const sha=b=>createHash('sha256').update(b).digest('hex')
const files={runner:fileURLToPath(import.meta.url),fixture:path.join(here,'small-fixture.json'),baseline:path.join(baselineRoot,hashPath),candidate:path.join(candidateRoot,hashPath)}
const identities={}
for(const [key,p] of Object.entries(files))identities[key]=sha(await fs.readFile(p))
const fixture=JSON.parse(await fs.readFile(files.fixture,'utf8'))
const baseline=await import(pathToFileURL(files.baseline))
const candidate=await import(pathToFileURL(files.candidate))
const functions={A:baseline.hashTermEntryContentBytesPair,B:candidate.hashTermEntryContentBytesPair,C:baseline.hashTermEntryContentBytesPair,D:candidate.hashTermEntryContentBytesPair}
assert.equal(typeof globalThis.gc,'function','Use --expose-gc')
const cases=fixture.cases.map(c=>{
 const payloads=c.payloads.map(p=>{
  const bytes=Buffer.from(p.bytes,'base64')
  assert.equal(sha(bytes),p.sha256)
  const owner=new Uint8Array(p.viewOffset+bytes.length+13).fill(0xd9)
  owner.set(bytes,p.viewOffset)
  const view=owner.subarray(p.viewOffset,p.viewOffset+bytes.length)
  assert.deepEqual(functions.A(view),p.expected)
  assert.deepEqual(functions.B(view),p.expected)
  return {owner,view,expected:p.expected,beforeSha256:sha(owner)}
 })
 assert.equal(payloads.length&(payloads.length-1),0)
 const maxLength=Math.max(...payloads.map(p=>p.view.length))
 const minLength=Math.min(...payloads.map(p=>p.view.length))
 const repetitions=Math.max(4096,Math.floor(4*1024*1024/(maxLength+64)))
 const mask=payloads.length-1
 let witness=0
 for(let i=0;i<repetitions;i++){
  const [a,b]=payloads[i&mask].expected
  witness=((witness+a)^b)>>>0
 }
 return {name:c.name,kind:c.kind,payloads,repetitions,mask,expectedWitness:witness,minLength,maxLength}
})
const plans=[['A','B','C','D'],['B','D','A','C'],['C','A','D','B'],['D','C','B','A']]
const observations=[]
function run(c,arm,block,warmup){
 const fn=functions[arm]
 let witness=0
 globalThis.gc()
 const before=performance.now()
 for(let i=0;i<c.repetitions;i++){
  const [a,b]=fn(c.payloads[i&c.mask].view)
  witness=((witness+a)^b)>>>0
 }
 const ms=performance.now()-before
 assert.equal(witness,c.expectedWitness)
 observations.push({case:c.name,arm,block,warmup,repetitions:c.repetitions,ms,witness})
}
const startedAt=new Date().toISOString()
for(const c of cases){
 for(let warmup=0;warmup<2;warmup++)for(const arm of ['A','B','C','D'])run(c,arm,warmup,true)
 for(let block=0;block<24;block++)for(const arm of plans[block%4])run(c,arm,block,false)
 for(const p of c.payloads)assert.equal(sha(p.owner),p.beforeSha256)
}
for(const [key,p] of Object.entries(files))assert.equal(sha(await fs.readFile(p)),identities[key])
const median=x=>{const s=[...x].sort((a,b)=>a-b);const m=Math.floor(s.length/2);return s.length%2?s[m]:(s[m-1]+s[m])/2}
const comparisons=[]
for(const c of cases)for(const [numerator,denominator] of [['C','A'],['D','B'],['B','A'],['D','A']]){
 const a=observations.filter(x=>x.case===c.name&&!x.warmup&&x.arm===denominator)
 const b=observations.filter(x=>x.case===c.name&&!x.warmup&&x.arm===numerator)
 const changes=b.map((x,i)=>100*(x.ms/a[i].ms-1))
 comparisons.push({case:c.name,kind:c.kind,minLength:c.minLength,maxLength:c.maxLength,comparison:`${numerator}/${denominator}`,pairs:a.length,medianPairedPercent:median(changes),equalWorkPercent:100*(b.reduce((s,x)=>s+x.ms,0)/a.reduce((s,x)=>s+x.ms,0)-1),faster:changes.filter(x=>x<0).length,baselineMedianNs:median(a.map(x=>x.ms))*1e6/c.repetitions,candidateMedianNs:median(b.map(x=>x.ms))*1e6/c.repetitions,changes})
}
const result={scope:'Supplemental generic-small-input performance risk screen. Same frozen source as real-block cohort; does not measure browser imports. Each case remains separate.',startedAt,finishedAt:new Date().toISOString(),node:process.version,v8:process.versions.v8,host:{platform:os.platform(),arch:os.arch(),cpus:os.cpus().map(c=>c.model),release:os.release()},identities,sourceRoots:{baseline:baselineRoot,candidate:candidateRoot},fixtureMetadata:{oracle:fixture.oracle,seeds:fixture.seeds,sourceStoreSha256:fixture.sourceStoreSha256,archiveSha256:fixture.archiveSha256,cases:cases.map(c=>({name:c.name,kind:c.kind,payloads:c.payloads.length,minLength:c.minLength,maxLength:c.maxLength,repetitions:c.repetitions,expectedWitness:c.expectedWitness}))},protocol:{blocks:24,plans,warmupsPerArm:2,arms:{A:'baseline',B:'candidate',C:'baseline',D:'candidate'},explicitGcBeforeObservation:true,postTimingWitnessValidation:true,noRetries:true,noDroppedTails:true},observations,comparisons}
await fs.writeFile(path.join(here,'small-component-results.json'),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({cases:cases.length,observations:observations.length,comparisons:comparisons.map(({changes,...r})=>r)}))
