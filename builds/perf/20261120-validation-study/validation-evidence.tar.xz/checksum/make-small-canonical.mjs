import fs from 'node:fs/promises'
import {pathToFileURL} from 'node:url'
import {createHash} from 'node:crypto'
import assert from 'node:assert/strict'
const dir=new URL('./',import.meta.url)
const input=JSON.parse(await fs.readFile(new URL('real-fixture/manifest.json',dir),'utf8'))
const image=new Uint8Array(await fs.readFile(new URL('real-fixture/store.bin',dir)))
const sha=bytes=>createHash('sha256').update(bytes).digest('hex')
assert.equal(sha(image),input.storeSha256)
const sourceRoot='/workspace/scratch/f34c9c9fae89/manabitan'
const load=rel=>import(pathToFileURL(`${sourceRoot}/${rel}`))
const originalFetch=globalThis.fetch
globalThis.fetch=async(resource,init)=>{
 const url=new URL(String(resource))
 return url.protocol==='file:'?new Response(await fs.readFile(url),{headers:{'Content-Type':'application/wasm'}}):await originalFetch(resource,init)
}
const {initializeTermContentZstd}=await load('ext/js/dictionary/zstd-term-content.js')
const {TermContentOpfsStore}=await load('ext/js/dictionary/term-content-opfs-store.js')
const {TermContentBlockStore}=await load('ext/js/dictionary/term-content-block-store.js')
await initializeTermContentZstd()
const store=new TermContentOpfsStore()
await store.appendBatch([image])
const blocks=new TermContentBlockStore(store)
const buckets=[{name:'actual-0-32',min:0,max:32},{name:'actual-33-128',min:33,max:128},{name:'actual-129-512',min:129,max:512},{name:'actual-513-1024',min:513,max:1024}]
const cases=[]
for(const bucket of buckets){
 const refs=input.requests.filter(r=>r.contentLength>=bucket.min&&r.contentLength<=bucket.max).slice(0,32)
 assert.ok(refs.length>0)
 const results=await blocks.readDetailedBatch(refs)
 const payloads=results.map((result,index)=>{
  assert.equal(result.status,'ok')
  assert.equal(sha(result.bytes),refs[index].expectedSha256)
  return {bytes:Buffer.from(result.bytes).toString('base64'),sha256:sha(result.bytes),sourceReference:refs[index]}
 })
 cases.push({...bucket,payloads})
}
await fs.writeFile(new URL('small-canonical-source.json',dir),JSON.stringify({storeSha256:input.storeSha256,archiveSha256:input.archiveSha256,cases},null,2)+'\n')
console.log(JSON.stringify(cases.map(c=>({name:c.name,payloads:c.payloads.length}))))
