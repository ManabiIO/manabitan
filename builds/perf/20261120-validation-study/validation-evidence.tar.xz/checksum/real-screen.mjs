import fs from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import assert from 'node:assert/strict'
import {fileURLToPath,pathToFileURL} from 'node:url'
import {createHash} from 'node:crypto'
import {performance} from 'node:perf_hooks'
const root=fileURLToPath(new URL('../../../',import.meta.url))
const baselineRoot='/workspace/scratch/f34c9c9fae89/manabitan'
const outputDir=new URL('./',import.meta.url)
const sha=b=>createHash('sha256').update(b).digest('hex')
const inputBytes=await fs.readFile(new URL('real-fixture/manifest.json',outputDir))
const input=JSON.parse(inputBytes.toString())
const image=new Uint8Array(await fs.readFile(new URL('real-fixture/store.bin',outputDir)))
assert.equal(sha(image),input.storeSha256)
const hashPath='ext/js/dictionary/term-entry-content-hash.js'
const runnerBytes=await fs.readFile(fileURLToPath(import.meta.url))
const inputManifestSha256=sha(inputBytes)
const runnerSha256=sha(runnerBytes)
const hashes={A:sha(await fs.readFile(path.join(baselineRoot,hashPath))),B:sha(await fs.readFile(path.join(root,hashPath)))}
const sourceRoots={A:baselineRoot,B:root,C:baselineRoot,D:root}
const originalFetch=globalThis.fetch
globalThis.fetch=async(inputValue,init)=>{
 const url=new URL(String(inputValue))
 return url.protocol==='file:'?new Response(await fs.readFile(url),{headers:{'Content-Type':'application/wasm'}}):await originalFetch(inputValue,init)
}
const modules={}
for(const arm of ['A','B']){
 const dir=sourceRoots[arm]
 const load=rel=>import(pathToFileURL(path.join(dir,rel)))
 const hash=await load(hashPath)
 const {TermContentOpfsStore}=await load('ext/js/dictionary/term-content-opfs-store.js')
 const {TermContentBlockStore}=await load('ext/js/dictionary/term-content-block-store.js')
 const {initializeTermContentZstd}=await load('ext/js/dictionary/zstd-term-content.js')
 await initializeTermContentZstd()
 modules[arm]={hash:hash.hashTermEntryContentBytesPair,TermContentOpfsStore,TermContentBlockStore}
}
modules.C=modules.A
modules.D=modules.B
async function makeReader(arm,bytes=image){
 const {TermContentOpfsStore,TermContentBlockStore}=modules[arm]
 const store=new TermContentOpfsStore()
 await store.appendBatch([bytes])
 return new TermContentBlockStore(store)
}
function verifyResults(results){
 assert.equal(results.length,input.requests.length)
 for(let i=0;i<results.length;i++){
  assert.equal(results[i].status,'ok')
  assert.equal(sha(results[i].bytes),input.requests[i].expectedSha256)
 }
}
const parity={validRequests:input.requests.length,blocks:input.blocks.length,validSourceDigests:{},fullBlockDigests:{},corruptCases:[]}
for(const arm of ['A','B']){
 const reader=await makeReader(arm)
 parity.fullBlockDigests[arm]=[]
 for(const block of input.blocks){
  const decoded=await reader._loadBlock(`oracle:${block.offset}`,block.reference,'jmdict',block.context)
  assert.equal(decoded.byteLength,block.uncompressedLength)
  assert.equal(sha(decoded),block.uncompressedSha256)
  parity.fullBlockDigests[arm].push({offset:block.offset,bytes:decoded.byteLength,sha256:sha(decoded)})
 }
 reader.clearCache()
 const results=await reader.readDetailedBatch(input.requests)
 verifyResults(results)
 parity.validSourceDigests[arm]=sha(Buffer.concat(results.map(r=>r.bytes)))
}
assert.equal(parity.validSourceDigests.A,parity.validSourceDigests.B)
assert.deepEqual(parity.fullBlockDigests.A,parity.fullBlockDigests.B)
const firstRequest=input.requests[0]
const firstBlock=input.blocks.find(b=>b.offset===firstRequest.blockOffset)
assert.ok(firstBlock)
for(const kind of ['magic','hash1','hash2','payload','rehash-invalid-frame']){
 const damaged=new Uint8Array(image)
 const offset=firstBlock.offset
 if(kind==='magic')damaged[offset]^=1
 if(kind==='hash1')damaged[offset+4]^=1
 if(kind==='hash2')damaged[offset+8]^=1
 if(kind==='payload'||kind==='rehash-invalid-frame')damaged[offset+12]^=255
 if(kind==='rehash-invalid-frame'){
  const payload=damaged.subarray(offset+12,offset+firstBlock.length)
  const pair=modules.A.hash(payload)
  assert.deepEqual(modules.B.hash(payload),pair)
  const view=new DataView(damaged.buffer,damaged.byteOffset+offset,firstBlock.length)
  view.setUint32(4,pair[0],true)
  view.setUint32(8,pair[1],true)
 }
 const results={}
 for(const arm of ['A','B']){
  const reader=await makeReader(arm,damaged)
  results[arm]=(await reader.readDetailedBatch([firstRequest]))[0]
  assert.equal(results[arm].status,'corrupt')
 }
 assert.deepEqual(results.A,results.B)
 parity.corruptCases.push({kind,...results.A})
}
await fs.writeFile(new URL('real-reader-parity.json',outputDir),JSON.stringify({scope:'Actual production block-reader code and Zstd decoder over an in-memory store image. No OPFS file I/O is included.',hashes,inputStoreSha256:input.storeSha256,...parity},null,2)+'\n')
if(process.argv.includes('--parity-only')){
 console.log(JSON.stringify({parity}))
 process.exit(0)
}
assert.equal(typeof globalThis.gc,'function','Run the fixed cohort with --expose-gc')
const readers={}
for(const arm of ['A','B','C','D'])readers[arm]=await makeReader(arm)
const payloads=input.blocks.map(b=>image.subarray(b.offset+12,b.offset+b.length))
const expectedHashes=payloads.map(bytes=>modules.A.hash(bytes))
for(let i=0;i<payloads.length;i++)assert.deepEqual(modules.B.hash(payloads[i]),expectedHashes[i])
const plans=[['A','B','C','D'],['B','D','A','C'],['C','A','D','B'],['D','C','B','A']]
const observations=[]
async function run(stage,arm,block,warmup){
 const reader=readers[arm]
 reader.clearCache()
 globalThis.gc?.()
 let value
 const start=performance.now()
 if(stage==='hash'){
  value=payloads.map(bytes=>modules[arm].hash(bytes))
 }else{
  value=await reader.readDetailedBatch(input.requests)
 }
 const ms=performance.now()-start
 if(stage==='hash')assert.deepEqual(value,expectedHashes)
 else verifyResults(value)
 observations.push({stage,arm,block,warmup,ms})
}
for(const stage of ['hash','reader']){
 for(let warmup=0;warmup<2;warmup++)for(const arm of ['A','B','C','D'])await run(stage,arm,warmup,true)
 for(let block=0;block<24;block++)for(const arm of plans[block%4])await run(stage,arm,block,false)
}
assert.equal(sha(image),input.storeSha256)
assert.equal(sha(await fs.readFile(new URL('real-fixture/store.bin',outputDir))),input.storeSha256)
assert.equal(sha(await fs.readFile(new URL('real-fixture/manifest.json',outputDir))),inputManifestSha256)
assert.equal(sha(await fs.readFile(fileURLToPath(import.meta.url))),runnerSha256)
assert.equal(sha(await fs.readFile(path.join(baselineRoot,hashPath))),hashes.A)
assert.equal(sha(await fs.readFile(path.join(root,hashPath))),hashes.B)
const median=x=>{const s=[...x].sort((a,b)=>a-b),m=Math.floor(s.length/2);return s.length%2?s[m]:(s[m-1]+s[m])/2}
const comparisons=[]
for(const stage of ['hash','reader'])for(const [numerator,denominator] of [['C','A'],['D','B'],['B','A'],['D','A']]){
 const a=observations.filter(x=>x.stage===stage&&!x.warmup&&x.arm===denominator)
 const b=observations.filter(x=>x.stage===stage&&!x.warmup&&x.arm===numerator)
 const changes=b.map((x,i)=>100*(x.ms/a[i].ms-1))
 comparisons.push({stage,comparison:`${numerator}/${denominator}`,pairs:a.length,medianPairedPercent:median(changes),equalWorkPercent:100*(b.reduce((s,x)=>s+x.ms,0)/a.reduce((s,x)=>s+x.ms,0)-1),faster:changes.filter(x=>x<0).length,baselineMedianMs:median(a.map(x=>x.ms)),candidateMedianMs:median(b.map(x=>x.ms)),changes})
}
const result={scope:'Component qualification only: full production block reader with memory-backed storage, all28 JMdict-derived production-packed blocks. Does not measure browser imports, OPFS file I/O, cache-miss frequency, compression parallelism, or peak memory.',protocol:{blocks:24,plans,warmupsPerArm:2,arms:{A:'baseline',B:'candidate',C:'baseline',D:'candidate'},stages:['hash','reader'],explicitGcBeforeObservation:true,postTimingValidation:true,noRetries:true,noDroppedTails:true},sourceRoots,hashes,fixture:input,parity,node:process.version,v8:process.versions.v8,host:{platform:os.platform(),arch:os.arch(),cpus:os.cpus().map(c=>c.model),release:os.release()},runnerSha256,inputManifestSha256,observations,comparisons}
await fs.writeFile(new URL('real-component-results.json',outputDir),JSON.stringify(result,null,2)+'\n')
console.log(JSON.stringify({comparisons:comparisons.map(({changes,...rest})=>rest)}))
