# Canonical scanner header audit

Read-only review against `bde55dfbee1451edc32051f8bf51e8a870d5c72c`. No C, WASM, cache, storage, cancellation, or worker policy was changed.

## Ownership and observation

`TermContentMetadataArena` creates `WebAssembly.Memory({initial: pages, maximum: pages})` without `shared`. Its production owner replaces the arena and copies/rehashes columns; neither the arena class, canonical adapter nor database calls `memory.grow` on it. The native module is instantiated with only `env.memory`. `scan_canonical` contains no host calls. Therefore JavaScript, cancellation handlers and test hooks cannot run during the synchronous native invocation, and another worker cannot concurrently access this non-shared memory.

The adapter's test hooks run before native entry or after native return. `resolveExactCandidates()` is awaited only after the native segment's borrowed output columns have been synchronously copied into the pending owner and exact descriptors have been copied. At every later segment, the adapter reloads the current arena, verifies no free IDs appeared, refreshes pending/dense bases and recopies inputs if the arena generation changed. Borrowed views never cross that await.

The 22 configuration words at byte1088 are immutable for one native call. Table pointers, capacities, row bounds, byte bounds, lookup/reservation flags and the fault-injection limit can be snapshotted into local scalars before the row loop. Config lives below the8MiB prefix; authoritative table pointers must be at or above that prefix. Actual arena columns are disjoint. Do not introduce `restrict`: the low-level ABI checks do not independently prove that every hostile table-pointer combination is mutually disjoint.

## Header fields

The pointer for the entire seven-word header at byte1024 is declared volatile. The source comment specifically explains the journal count's requirement; it does not identify a cross-thread observer for other fields.

| Index | Meaning | Mutation | Consumer/invariant |
| --- | --- | --- | --- |
| 0 | Committed insertion-journal entries | Published before each authoritative insertion | Synchronous rollback reads this even after a native trap; keep progress publication and the insertion memory barrier |
| 1 | Next row cursor | Advanced before processing each validated row | Successful segment resume position, including the4096-exact-candidate early return |
| 2 | Pending output row count | Incremented for each pending descriptor | Length of all six borrowed output-column views |
| 3 | Exact descriptor count | Incremented for each persisted candidate | Exact descriptor copy length and bounded early-return condition |
| 4 | Already-resolved count | Incremented when a source flag is already resolved | Accumulated successful result count |
| 5 | Next dense metadata ID | Advanced after each insertion | Published dense-count update before pending adoption; IDs must remain stable |
| 6 | Reserved | Set to zero, then unchanged | ABI-reserved output |

The JS success path consumes these values only after a nonnegative native return. Its synchronous failure path uses header[0] to walk the journal backward, restoring slot predecessors, state/hash/length/signature columns, exact-descriptor length and the prior database dense/pending counts. The ordinary outer owner handles already accepted earlier segments. A later exact-read failure must not rewind earlier accepted IDs or resolved flags.

The `journal count -> compiler memory barrier -> authoritative stores` ordering is essential. The journal entries must be available when a later mutation traps. Removing the barrier or deferring header[0] until return would invalidate that guarantee.

The current tests inject native traps; first/second output-view failures; partial pending/staged/hash-column copies; descriptor failures; failures in a later segment; arena replacement during exact awaits; free-ID retries; row/identity/bounds failures; and storage/record failures after acceptance. They also compare full metadata, encoded content references, records and lookup bytes to the JS route. Hooks expose the header only on the successful native-return path. I did not find a test that asserts every nonjournal header word immediately after a native trap. That absence is not permission to alter error-visible ABI state casually: any future local-counter change should preserve or explicitly test normal, negative-return and injected-trap header snapshots.

## Lower-risk first hypothesis

If native elapsed time is material, first test explicit immutable config locals while leaving all volatile header writes, journal writes and the barrier unchanged. The memory-clobber barrier can prevent the compiler from retaining values loaded indirectly from config; explicit scalar snapshots state their actual within-call immutability. This is a hypothesis, not a measured cost or a speedup.

Moving pending/dense/cursor counters into locals would be a separate, more invasive candidate. It must preserve every successful exit's header, the4096-candidate boundary, trap rollback and earlier-segment acceptance. Do not combine the two hypotheses in one measurement.

## Small diagnostic proposal

Use a separate baseline diagnostic build with unchanged C and unchanged WASM. Add five aggregate elapsed counters in the JS adapter, with no new awaits or retained views:

1. Module wait: around the existing `_loadModule()` await. Keep it separate because first-use compilation and cached calls differ.
2. Arena/instance setup: the existing capacity initialization and instance-cache/ABI-check section, excluding input copies.
3. Input staging: metadata/identity/row/signature/flag copies and header/config preparation.
4. Native call: immediately around `native()` alone; preserve the original exception while recording a failure's elapsed span.
5. Output/adoption: output-view creation, exact-descriptor ownership copy, count publication and synchronous `adoptPendingColumns` callback, stopping before `resolveExactCandidates()`.

Existing `dedupExactCompareMs` remains separate. Preserve call/row/copied-byte/adopted-byte/fallback counters and report raw per-import totals. These elapsed counters are nested diagnostics, may include host preemption, and must not be added to total import time or interpreted as CPU cycles. Their residual against `dedupCanonicalScanMs` includes eligibility/loop/counter overhead and timer resolution.

Run the unchanged locked JMdict archive through the existing browser import observer with production groups and policies. Label these runs diagnostic/non-authoritative for whole-import comparisons. A short fixed diagnostic sample is sufficient to decide whether native code, copies or adoption dominates; a later runtime candidate still needs its own source-frozen functional and whole-browser qualification. An optional Node replay using the same parser-produced metadata can screen native-only hypotheses, but must disclose different grouping and any absence of cross-group publication/exact matches.

The earlier51–55ms canonical-stage totals cannot identify the native share, and the checksum candidate's component gain says nothing about this separate stage.
