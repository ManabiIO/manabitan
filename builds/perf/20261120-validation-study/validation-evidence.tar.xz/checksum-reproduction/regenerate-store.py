#!/usr/bin/env python3
"""Reproduce the frozen checksum corpus without editing the measured generator.

The output directory must be new and below the baseline checkout, so the copied
ESM generator resolves the checkout's installed Node dependencies. Only the two
historical absolute source/archive literals are changed in that copy. The store
must match the measured SHA-256; all manifest fields must match after restoring
the historical source-root label. No component timing is performed here.
"""

import argparse
import datetime
import hashlib
import json
from pathlib import Path
import subprocess


BASELINE = "bde55dfbee1451edc32051f8bf51e8a870d5c72c"
GENERATOR_SHA = "99c6e95b3c184fc408bf7e6665083dd3e4fd592264310b5d7bef104632427543"
MANIFEST_SHA = "4629920d51385465dfa1d5afd3230c88d0bc3a7d3ccf23d5e0379d1b1425ab39"
ARCHIVE_SHA = "7681ee09f9edfef48a5e50773565da237424eb750bdb0e1e59660784ecd53e8a"
STORE_SHA = "4cee541ed8c6869e9ad8ec4c400f9fb61fcbf00f6e995a0a5df6d274fcd586f0"
HISTORICAL_ROOT = "/workspace/scratch/f34c9c9fae89/manabitan"
HISTORICAL_ARCHIVE = "/workspace/scratch/f34c9c9fae89/fixtures/JMdict.zip"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(root, *args):
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()


def verify_source(root, wasm):
    assert git(root, "rev-parse", "HEAD") == BASELINE, "Use the exact baseline checkout"
    subprocess.run(
        ["git", "-C", str(root), "diff", "--exit-code", "HEAD", "--", "ext/js", "ext/lib", "dev/data/dictionary-wasm", "package.json", "package-lock.json"],
        check=True, capture_output=True,
    )
    for name, expected in wasm.items():
        assert digest(root / name) == expected, f"Generated WASM changed: {name}"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence-dir", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--archive", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    evidence = args.evidence_dir.resolve()
    root = args.source_root.resolve()
    archive = args.archive.resolve()
    output = args.output_dir.resolve()
    assert output.is_relative_to(root / "builds"), "Output must be under baseline builds/"
    assert not output.exists(), "Refusing to overwrite an existing result directory"
    generator = evidence / "make-real-fixture.mjs"
    original_manifest_path = evidence / "real-fixture/manifest.json"
    assert digest(generator) == GENERATOR_SHA, "Measured generator identity changed"
    assert digest(original_manifest_path) == MANIFEST_SHA, "Measured manifest identity changed"
    assert archive.stat().st_size == 15587032 and digest(archive) == ARCHIVE_SHA
    validation = json.loads((evidence / "required-validation.json").read_text())
    assert validation["allPassed"] is True
    wasm = validation["baselineWasm"]
    assert wasm == validation["wasmBefore"] == validation["wasmAfter"]
    verify_source(root, wasm)

    original = generator.read_text()
    source_literal = f"const sourceRoot='{HISTORICAL_ROOT}'"
    archive_literal = f"const archivePath='{HISTORICAL_ARCHIVE}'"
    assert original.count(source_literal) == original.count(archive_literal) == 1
    relocated = original.replace(source_literal, "const sourceRoot=" + json.dumps(str(root)))
    relocated = relocated.replace(archive_literal, "const archivePath=" + json.dumps(str(archive)))
    output.mkdir(parents=True)
    copied_generator = output / "make-real-fixture.relocated.mjs"
    copied_generator.write_text(relocated)
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(["node", str(copied_generator)], cwd=root, capture_output=True, text=True)
    (output / "generator.stdout.log").write_text(result.stdout)
    (output / "generator.stderr.log").write_text(result.stderr)
    result.check_returncode()
    store = output / "real-fixture/store.bin"
    regenerated_manifest_path = output / "real-fixture/manifest.json"
    assert store.stat().st_size == 19548576 and digest(store) == STORE_SHA
    original_manifest = json.loads(original_manifest_path.read_text())
    regenerated_manifest = json.loads(regenerated_manifest_path.read_text())
    assert regenerated_manifest["sourceRoot"] == str(root)
    regenerated_manifest["sourceRoot"] = HISTORICAL_ROOT
    assert regenerated_manifest == original_manifest, "Regenerated corpus manifest differs"
    assert digest(generator) == GENERATOR_SHA
    assert digest(original_manifest_path) == MANIFEST_SHA
    assert digest(archive) == ARCHIVE_SHA
    verify_source(root, wasm)
    receipt = {
        "scope": "Store-image regeneration only; no new performance measurement",
        "startedAt": started,
        "finishedAt": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "baselineCommit": BASELINE,
        "sourceRoot": str(root),
        "node": subprocess.check_output(["node", "--version"], text=True).strip(),
        "originalGeneratorSha256": GENERATOR_SHA,
        "relocatedGeneratorSha256": digest(copied_generator),
        "originalManifestSha256": MANIFEST_SHA,
        "regeneratedManifestSha256": digest(regenerated_manifest_path),
        "archiveSha256": ARCHIVE_SHA,
        "storeSha256": STORE_SHA,
        "storeBytes": store.stat().st_size,
        "allManifestFieldsEqualAfterSourceRootLabelNormalization": True,
        "wasmSha256": wasm,
    }
    (output / "regeneration-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
